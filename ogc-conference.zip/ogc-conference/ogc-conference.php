<?php
/**
 * Plugin Name: OGBBC Annual Conference
 * Description: The Annual Conference page, the guide, the schedule and packet, sign-ups, and the Committee of Arrangements' year.
 * Version: 0.1.0
 * Requires at least: 6.5
 * Requires PHP: 7.4
 * Author: ogbbc.org webmasters
 * Text Domain: ogc-conference
 *
 * Every file in includes/ is loaded: core*.php first (the foundation), then the areas' module*.php,
 * each in name order. An area adds a module by adding a file; nothing here needs to change.
 * DEV.md says how to run it, the tables, the REST routes and who owns which file.
 */

defined( 'ABSPATH' ) || exit;

define( 'OGC_VERSION', '0.1.0' );
// Bump when a table in any ogc_schema filter changes; the schema is applied again (dbDelta).
define( 'OGC_DB_VERSION', '1' );
define( 'OGC_FILE', __FILE__ );
define( 'OGC_DIR', plugin_dir_path( __FILE__ ) );
define( 'OGC_URL', plugin_dir_url( __FILE__ ) );
// Local development only (tools/wp-local.sh defines it true). Turns on the dev sign-in, the dev
// routes and the Pages navigator. Never defined on ogbbc.org.
if ( ! defined( 'OGC_DEV' ) ) {
	define( 'OGC_DEV', false );
}

( function () {
	$files = glob( OGC_DIR . 'includes/*.php' );
	if ( ! $files ) {
		return;
	}
	$core = array();
	$rest = array();
	foreach ( $files as $f ) {
		if ( 0 === strpos( basename( $f ), 'core' ) ) {
			$core[] = $f;
		} else {
			$rest[] = $f;
		}
	}
	sort( $core );
	sort( $rest );
	foreach ( array_merge( $core, $rest ) as $f ) {
		require_once $f;
	}
} )();

register_activation_hook( __FILE__, 'ogc_activate' );
register_deactivation_hook( __FILE__, 'ogc_deactivate' );
