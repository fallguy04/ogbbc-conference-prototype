/*
 * year.js — the Committee of Arrangements' year (/annual-conference/year/), on the server.
 *
 * A new COA member meets this page first, once a year, and has never seen it before
 * (memory once-a-year-users). So it teaches itself:
 *   - ?year=2027 is the year: where it stands, the next thing due, its seven parts in the order they
 *     happen (each with its state and due date), and Members;
 *   - ?part=… is one part, always built the same way: name, owner (the COA's choice; none until
 *     chosen), state, due · What to do (steps that tick themselves from the data or from a
 *     "Looks right" on the thing itself; a few by hand; each stamped with who and when) · last
 *     year's notes · the part · Made from it · Notes for next year · History;
 *   - one primary action per view, and it follows the state (Check 19 rows → Publish);
 *   - nothing is public until a person publishes or schedules it, and the server says so too.
 *
 * Saving (DEV.md's contract): files through ogc-store.js (O.edits); the COA's own state, publish
 * stamps, registration facts, requests' answers, dates, campus and members through the year area's
 * routes (includes/module-coa*.php), which check, stamp and log. The bar's status follows the server
 * (Saving · Saved · Offline · Not saved), and two people changing different rows never clash.
 */
(function () {
  'use strict';
  const O = window.OGC, esc = O.esc, E = O.edits, SU = O.signups, W = window.OGC_WP || {};
  const root = document.getElementById('ogc-year');
  if (!root || !W.api) return;
  const BASE = root.dataset.base;
  const q = new URLSearchParams(location.search);
  const NOT_YET = '9999-12-31';
  const DEV = !!W.dev;
  const api = (m, p, b) => W.api(m, p, b);
  const svg = d => '<svg class="wk-i" viewBox="0 0 24 24" aria-hidden="true"><path d="' + d + '" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  const I = {
    check: svg('m5.5 12.5 4 4 9-9'), x: svg('m7 7 10 10M17 7 7 17'), plus: svg('M12 5v14M5 12h14'),
    clock: svg('M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18ZM12 7.5V12l3 2'), eye: svg('M2.5 12S6 5.5 12 5.5 21.5 12 21.5 12 18 18.5 12 18.5 2.5 12 2.5 12ZM12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6Z'),
    download: svg('M12 4v10.5M7.5 10 12 14.5 16.5 10M5 19.5h14'), upload: svg('M12 15V4.5M7.5 9 12 4.5 16.5 9M5 19.5h14'), down: svg('m6 9.5 6 6 6-6'), chevUp: svg('M7 13.5 12 8.5l5 5'),
    undo: svg('M9 7.5 5 11.5l4 4M5.5 11.5H15a4 4 0 0 1 0 8h-2.5'), edit: svg('M4.5 19.5h4.2l10-10-4.2-4.2-10 10ZM13.3 6.5l4.2 4.2'),
    pin: svg('M12 20.5s-6.5-5.4-6.5-10.8a6.5 6.5 0 0 1 13 0c0 5.4-6.5 10.8-6.5 10.8ZM12 12a2.3 2.3 0 1 0 0-4.6 2.3 2.3 0 0 0 0 4.6Z'),
    back: svg('M14.5 5.5 8 12l6.5 6.5'), go: svg('M9.5 5.5 16 12l-6.5 6.5'), mail: svg('M4 6.5h16v11H4zM4.5 7l7.5 6 7.5-6'),
    phone: svg('M8.6 4.5 6.4 4.8c-.8.1-1.5.9-1.4 1.8.6 6.6 5.8 11.8 12.4 12.4.9.1 1.7-.6 1.8-1.4l.3-2.2a1 1 0 0 0-.7-1.1l-2.6-.9a1 1 0 0 0-1.1.3l-1.1 1.3a9.5 9.5 0 0 1-4.4-4.4l1.3-1.1a1 1 0 0 0 .3-1.1l-.9-2.6a1 1 0 0 0-1.1-.7Z'),
    list: svg('M9 7h10M9 12h10M9 17h10M5 7h.01M5 12h.01M5 17h.01'), note: svg('M5 5.5h14v10H10l-4 3.5v-3.5H5z'), sheet: svg('M4.5 5.5h15v13h-15zM4.5 10h15M4.5 14.5h15M10 5.5v13'),
    out: svg('M14 5h5v5M19 5l-8 8M17 14v4.5a.5.5 0 0 1-.5.5h-11a.5.5 0 0 1-.5-.5v-11a.5.5 0 0 1 .5-.5H10'),
    globe: svg('M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18ZM3.5 9h17M3.5 15h17M12 3c2.5 2.6 3.7 5.6 3.7 9s-1.2 6.4-3.7 9c-2.5-2.6-3.7-5.6-3.7-9S9.5 5.6 12 3Z'),
    cal: svg('M5 6.5h14v13H5zM5 10.5h14M9 4.5v4M15 4.5v4'), info: svg('M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18ZM12 11v5.5M12 7.8v.2'),
    up: svg('M12 19V6M6.5 11.5 12 6l5.5 5.5'), dn: svg('M12 5v13M6.5 12.5 12 18l5.5-5.5'), hist: svg('M4.5 12a7.5 7.5 0 1 0 2.2-5.3M4.5 4.5v3.7h3.7M12 8.5V12l2.5 1.5'),
    search: svg('M10.5 17a6.5 6.5 0 1 0 0-13 6.5 6.5 0 0 0 0 13ZM15.5 15.5 20 20'), retry: svg('M19.5 12a7.5 7.5 0 1 1-2.2-5.3M19.5 4.5v3.7h-3.7'),
    more: '<svg class="wk-i" viewBox="0 0 24 24" aria-hidden="true"><path d="M6 12h.01M12 12h.01M18 12h.01" fill="none" stroke="currentColor" stroke-width="3.2" stroke-linecap="round"/></svg>'
  };
  const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  const DAYS = ['Friday', 'Saturday', 'Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday'];
  const AUD = ['Conference', 'Preteens', 'Young Folks', 'All'];
  const STATES = { IN: 'Indiana', OH: 'Ohio', OR: 'Oregon', PA: 'Pennsylvania', KS: 'Kansas', CA: 'California', MI: 'Michigan', TN: 'Tennessee', NM: 'New Mexico' };
  // The files the year page reads, and the column each row is known by.
  const KEYOF = { settings: 'key', registration: 'key', schedule: 'title', guide: 'id', help: 'need', menus: 'day', shifts: 'role', tournaments: 'id', places: 'code', nearby: 'name', rooms: 'hall', notices: 'text', notes: 'text', needs: 'item', committees: 'name' };
  const FILES = ['schedule', 'guide', 'help', 'menus', 'shifts', 'tournaments', 'places', 'nearby', 'rooms', 'notices', 'notes', 'needs', 'committees'];
  // Default due dates, in days from the arrival Friday, from the COA's own calendar (docs/16, docs/20):
  // the announcement about Nov 1; the master schedule early January; requests to the campus Jan 15;
  // registration about 13 weeks before; volunteer sign-ups Mar 15; tournaments and the packet in May.
  const DUE = { conference: -208, schedule: -143, requests: -133, registration: -91, helping: -74, youngfolks: -21, packet: -14 };

  const state = {
    years: [], year: '', part: q.get('part') || '', tool: q.get('tool') || '', needsOpen: q.get('open') || '',
    row: null, cur: null, ov: null, members: null, open: '', folds: {}, menuDraft: null, hist: [], fut: [], last: '', see: '',
    panel: '', pendingCampus: null, pendingDates: null, upload: null, editNeed: '', askNeed: '', confirmRemove: '', status: '', pinFor: '', pinQ: ''
  };
  // A preview of a later date (the mockup's ?as-of) changes what's drawn, never what's saved: every
  // stamp comes from the server's own today.
  const today = () => (q.get('as-of') || '').slice(0, 10) || (state.ov && state.ov.today) || O.wallNow('America/Indiana/Indianapolis').date;

  /* ------------------------------------------------------------ loading */

  const text = (folder, name) => fetch(folder + name + '.csv', { cache: 'no-store' }).then(r => r.ok ? r.text() : '').catch(() => '');
  const clean = rows => rows.filter(r => !Object.values(r).some(v => /^#/.test(String(v || ''))));
  let uid = 0;
  const newId = p => (p || 'n') + Date.now().toString(36) + (uid++);
  async function loadYear(y) {
    const folder = BASE + y.data + '/', out = { y };
    const names = Object.keys(KEYOF), texts = await Promise.all(names.map(n => text(folder, n)));
    names.forEach((n, i) => { out[n] = E.merge(y.year, n, clean(O.csvToObjects(texts[i]))).filter(r => r[KEYOF[n]]); });
    out.S = {}; out.settings.forEach(r => { out.S[r.key] = r.value; });
    out.R = {}; out.registration.forEach(r => { out.R[r.key] = r.value; });
    // Each row known by an id that's the same in every browser (the first save keeps it), so two
    // people's changes to different rows can be told apart.
    FILES.forEach(n => out[n].forEach((r, i) => { if (!r._id) r._id = n.slice(0, 2) + (i + 1); }));
    const planRows = E.merge(y.year, 'plans', clean(O.csvToObjects(await text(folder, 'plans'))));
    out.plans = Array.from(new Set(planRows.filter(r => r.hall).map(r => r.hall)));
    out.campus = O.map ? O.map.campus(E.merge(y.year, 'campus', O.csvToObjects(await text(folder, 'campus')))) : null;
    if (out.campus && !out.campus.items.length) out.campus = null;
    return out;
  }
  async function load() {
    await (O.ready || Promise.resolve());
    const t = await fetch(BASE + 'years.csv', { cache: 'no-store' }).then(r => r.text());
    state.years = E.mergeYears(O.csvToObjects(t)).filter(y => /^\d{4}$/.test(y.year)).sort((a, b) => b.year - a.year);
    const mine = W.webmaster ? null : (W.member || []).map(String);
    const withData = state.years.filter(y => y.data && (!mine || mine.indexOf(y.year) > -1));
    const asked = state.years.find(y => y.year === q.get('year') && (!mine || mine.indexOf(y.year) > -1));
    const next = withData.slice().reverse().find(y => !y.end || y.end >= today());
    state.row = asked || next || withData[0];
    if (!state.row) throw Object.assign(new Error('No year'), { none: true });
    state.year = state.row.year;
    if (!state.row.data) state.row.data = state.year;
    const [ov, cur] = await Promise.all([api('GET', 'coa/' + state.year), loadYear(state.row)]);
    state.ov = ov; state.cur = cur;
    if (!state.cur.committees.length) state.cur.committees = derivedCommittees();
    state.last = snapshot();
    Object.keys(state.cur).forEach(n => { if (Array.isArray(state.cur[n]) && FILES.indexOf(n) > -1) base[n] = JSON.stringify(state.cur[n].map(strip)); });
  }
  // The overview again (after an action: steps, stamps, history).
  async function refresh() {
    try { state.ov = await api('GET', 'coa/' + state.year); chrome(); } catch (e) { /* the page keeps what it had */ }
  }
  const pk = () => (state.ov && state.ov.picked) || { parts: {} };
  const coa = () => (state.ov && state.ov.coa) || { steps: {}, checks: {}, notes_done: {}, pub: {}, sent: {}, due: {} };

  /* ------------------------------------------------------------ dates */

  const firstDay = () => state.cur.S.first_day || state.row.start || '';
  // Short dates in status words ("Oct 12", "Due Jan 15"); a date shows its year whenever it isn't in
  // the Conference's own year ("Feb 25, 2027" on 2028's page).
  const SHORT = new Intl.DateTimeFormat('en-US', { month: 'short', day: 'numeric', timeZone: 'UTC' });
  const md = iso => O.parseISODate(iso) ? SHORT.format(new Date(iso + 'T12:00:00Z')) : '';
  const mdY = iso => !O.parseISODate(iso) ? '' : iso.slice(0, 4) === String(state.year) ? md(iso) : md(iso) + ', ' + iso.slice(0, 4);
  const dayDate = iso => O.parseISODate(iso) ? new Intl.DateTimeFormat('en-US', { weekday: 'short', month: 'short', day: 'numeric', timeZone: 'UTC' }).format(new Date(iso + 'T12:00:00Z')) : '';
  const weekday = iso => O.parseISODate(iso) ? new Intl.DateTimeFormat('en-US', { weekday: 'long', timeZone: 'UTC' }).format(new Date(iso + 'T12:00:00Z')) : '';
  // "May 21", "may 21", "5/21", Excel's "7-May", "2027-05-07" → a date in the year given (default this one).
  function parseMD(v, inYear) {
    const s = String(v).trim();
    let mi, d, y = inYear || +state.year;
    const a = s.match(/^([A-Za-z]{3,9})\.?[\s-]+(\d{1,2})(?:st|nd|rd|th)?(?:,?[\s-]+(\d{4}))?$/), b = s.match(/^(\d{1,2})\/(\d{1,2})(?:\/(\d{2,4}))?$/);
    const c = s.match(/^(\d{1,2})[\s-]+([A-Za-z]{3,9})\.?(?:[\s-]+(\d{4}))?$/), e = s.match(/^(\d{4})-(\d{1,2})-(\d{1,2})$/);
    const mon = w => MONTHS.findIndex(x => x.toLowerCase().startsWith(w.toLowerCase()));
    if (a) { mi = mon(a[1]); d = +a[2]; if (a[3]) y = +a[3]; }
    else if (b) { mi = +b[1] - 1; d = +b[2]; if (b[3]) y = b[3].length === 2 ? 2000 + +b[3] : +b[3]; }
    else if (c) { mi = mon(c[2]); d = +c[1]; if (c[3]) y = +c[3]; }
    else if (e) { y = +e[1]; mi = +e[2] - 1; d = +e[3]; }
    else return '';
    if (mi < 0 || mi > 11 || d < 1 || d > new Date(Date.UTC(y, mi + 1, 0)).getUTCDate()) return '';
    return y + '-' + String(mi + 1).padStart(2, '0') + '-' + String(d).padStart(2, '0');
  }
  // A registration date is in the months before the Conference: "Feb 25" on 2028's page is Feb 25, 2028;
  // a credit deadline after it, in the same year.
  const parseRegDate = v => parseMD(v, +state.year);
  const cityOf = c => String(c || '').replace(/,\s*([A-Z]{2})$/, (m, s) => ', ' + (STATES[s] || s));

  /* ------------------------------------------------------------ saving */

  // What's saved: the rows as they are, less what only this page needs.
  function strip(r) { const o = Object.assign({}, r); delete o._new; delete o._chg; return o; }
  const base = {};            // file → its rows as the server last had them, here (for merging)
  const dirty = new Set();
  let timer = 0, own = 0, storeState = 'saved', touched = false, failed = null;
  // The bar's status: nothing until the first change, then Saving · Saved · Offline · Not saved.
  function status() {
    const el = root.querySelector('.ws-status');
    if (!el) return;
    let h = '';
    if (state.clash) h = '<span class="yr-err">Not saved</span> · ' + esc(SU.plural(state.clash.rows.length, 'clash', 'clashes'));
    else if (failed && failed.status === 401) h = '<span class="yr-err">Signed out</span> <a class="yr-link" href="' + esc((W.signin || '/annual-conference/signin/') + '?return=' + encodeURIComponent(location.pathname + location.search)) + '">Sign in</a>';
    else if (failed) h = '<span class="yr-err" title="' + esc(failed.msg || '') + '">Not saved</span> <button type="button" class="yr-link" data-retry>' + I.retry + 'Retry</button>';
    else if (storeState === 'offline') h = '<span class="yr-err">Offline</span> · Retrying';
    else if (own || storeState === 'saving' || (dirty.size && !state.clash)) h = 'Saving';
    else if (touched) h = I.check + 'Saved';
    el.innerHTML = h;
  }
  window.addEventListener('ogc:save', e => {
    const d = e.detail || {};
    storeState = d.state === 'error' ? storeState : d.state;
    if (d.state === 'error' && d.op && String(d.op.year) === state.year) failed = { status: d.status, msg: 'Refused (' + d.status + ')', op: d.op };
    if (d.state === 'saved' && !d.pending) {
      storeState = 'saved';
      // What this browser sent is now the server's: the base for the next merge.
      sent.forEach(n => { if (state.cur && state.cur[n]) base[n] = JSON.stringify(state.cur[n].map(strip)); });
      sent.clear();
    }
    status();
  });
  const sent = new Set();
  // Something changed: saved a moment after the typing stops (each pause is one step of ⌘Z).
  function touch(what) { dirty.add(what); touched = true; failed = null; status(); clearTimeout(timer); timer = setTimeout(flush, 500); }
  function flush() {
    clearTimeout(timer);
    if (!dirty.size) return;
    const y = state.year, wait = [];
    dirty.forEach(w => {
      const i = w.indexOf(':'), kind = w.slice(0, i), k = w.slice(i + 1);
      // A file with a clash open waits until each row is settled.
      if (kind === 'file' && state.clash && state.clash.name === k) { wait.push(w); return; }
      if (kind === 'file') { E.saveFile(y, k, state.cur[k].map(strip)); sent.add(k); }
      else if (kind === 'S') E.setKey(y, 'settings', k, state.cur.S[k]);
      else if (kind === 'R') saveReg(k);
      else if (kind === 'Y') E.setYear(y, k, state.row[k]);
      else if (kind === 'note') { const n = state.cur.notes.find(x => x._id === k); E.saveRow(y, 'notes', n ? strip(n) : { _id: k, _gone: 1 }); }
    });
    dirty.clear(); wait.forEach(w => dirty.add(w));
    record();
    status();
  }
  // A COA action on the server: counted in the status; a refusal comes back to the caller (to show
  // at the field) and as "Not saved".
  async function call(method, path, body) {
    own++; touched = true; failed = null; status();
    try { return await api(method, 'coa/' + state.year + (path ? '/' + path : ''), body); }
    catch (e) {
      if (e.status === 401 || e.status === 403 && /nonce|cookie/i.test(e.message || '')) failed = { status: 401 };
      else if (!e.status || e.status >= 500) failed = { status: e.status || 0, msg: e.message || 'Offline' };
      throw e;
    }
    finally { own--; status(); }
  }
  // A registration fact: checked on the server; a refusal shows at the field ("Whole dollars, like 65").
  function saveReg(k) {
    const v = state.cur.R[k] == null ? '' : String(state.cur.R[k]);
    call('POST', 'reg', { key: k, value: v }).then(() => { markField('reg.' + k, ''); if (k === 'closes') state.cur.S.registration_closes = v; },
      e => { if (e.status === 400 || e.status === 403) markField('reg.' + k, e.message); });
  }
  function markField(k, msg) {
    const el = root.querySelector('[data-k="' + CSS.escape(k) + '"]');
    if (!el) return;
    el.classList.toggle('is-flag', !!msg); el.setAttribute('aria-invalid', String(!!msg));
    const box = el.closest('td, label, .yr-field') || el.parentNode;
    let m = box.querySelector('.yr-fielderr');
    if (!msg) { if (m) m.remove(); return; }
    if (!m) { m = document.createElement('small'); m.className = 'yr-fielderr'; m.setAttribute('role', 'alert'); box.appendChild(m); }
    m.textContent = msg;
  }

  // Two people, one file. When someone else saved it since this browser read it (ogc-store.js sends
  // ogc:conflict), the rows each changed are told apart by their ids: different rows merge without a
  // word; the same row asks plainly which to keep. Nothing typed here is lost either way.
  // Rows by id; a row the server has without one gets the same id this page gives it on loading.
  const ids = (rows, name) => { const m = {}; (rows || []).forEach((r, i) => { const k = r._id || r.id || (name ? name.slice(0, 2) + (i + 1) : '#' + i); m[k] = Object.assign({}, r, { _id: k }); }); return m; };
  const changedIds = (a, b) => { const out = new Set(); Object.keys(a).forEach(k => { if (JSON.stringify(a[k]) !== JSON.stringify(b[k])) out.add(k); }); Object.keys(b).forEach(k => { if (!(k in a)) out.add(k); }); return out; };
  window.addEventListener('ogc:conflict', e => {
    const d = e.detail || {};
    if (!state.cur || String(d.year) !== state.year || !Array.isArray(d.theirs) || !state.cur[d.name] || !base[d.name]) return;
    const name = d.name, B = ids(JSON.parse(base[name]), name), M = ids(state.cur[name].map(strip), name), T = ids(d.theirs, name);
    const mine = changedIds(M, B), theirs = changedIds(T, B), both = Array.from(mine).filter(k => theirs.has(k));
    e.preventDefault();
    base[name] = JSON.stringify(d.theirs);
    // Theirs, with this browser's other changes put back in. A row both changed keeps what's typed
    // here until a person chooses (nothing in this file is saved meanwhile).
    const merged = Object.keys(T).map(k => T[k]);
    mine.forEach(k => {
      const i = merged.findIndex(r => (r._id || r.id) === k);
      if (!M[k]) { if (i > -1 && both.indexOf(k) < 0) merged.splice(i, 1); return; }
      if (i > -1) { merged[i] = Object.assign({}, M[k]); return; }
      const order = state.cur[name].map(r => r._id || r.id), at = order.indexOf(k), before = at > 0 ? order[at - 1] : null;
      const j = before ? merged.findIndex(r => (r._id || r.id) === before) : -1;
      merged.splice(j + 1, 0, Object.assign({}, M[k]));
    });
    state.cur[name] = merged;
    if (both.length) {
      state.clash = { name, who: whoChanged(name), rows: both.map(k => ({ id: k, theirs: T[k] || null, mine: M[k] || null })) };
      redrawFile(name); chrome();
      refresh().then(() => { if (state.clash && state.clash.name === name && !state.clash.who) { state.clash.who = whoChanged(name) || 'Another member'; chrome(); } });
      return;
    }
    // After ogc-store.js has taken theirs in (it does so once this event returns).
    setTimeout(() => { E.saveFile(state.year, name, state.cur[name].map(strip)); sent.add(name); }, 0);
    redrawFile(name);
  });
  function whoChanged(name) {
    const h = ((state.ov && state.ov.history) || []).find(x => x.action === 'change' && x.target === name && !x.mine);
    return h ? h.who : '';
  }
  // A clashing row by its name ("Help · I need a ride"), and its fields as each person has them.
  const rowName = r => r ? String(r.need || r.title || r.role || r.name || r.item || r.hall || r.code || r.text || '').slice(0, 60) : '';
  const FIELDWORD = { need: 'Title', text: 'Text', phone: 'Phone', link: 'Link', hours: 'Hours', kind: 'Kind', title: 'Title', summary: 'In one line', role: 'Shift', day: 'Day', last_day: 'Last day', start: 'Start', end: 'End', needed: 'People', place: 'Where', rule: 'Who can', audience: 'For', call_in: 'Call-in', from: 'From', to: 'Until', contact_email: 'Contact' };
  function clashFields(c) {
    const a = c.theirs || {}, b = c.mine || {};
    return Array.from(new Set(Object.keys(a).concat(Object.keys(b)))).filter(k => !/^_/.test(k) && String(a[k] == null ? '' : a[k]) !== String(b[k] == null ? '' : b[k]));
  }
  function clashBar() {
    const c = state.clash;
    if (!c) return '';
    const who = c.who || '…', what = FILEWORD[c.name] || c.name;
    const val = v => v == null || v === '' ? '<i class="yr-dim">Empty</i>' : esc(v);
    return '<div class="yr-clash" role="alert"><p class="yr-clash__h"><b>' + esc(who + ' changed ' + what + ' just now') + '</b> · ' + esc(SU.plural(c.rows.length, 'row') + ' you changed too') + '</p>' +
      c.rows.map(r => {
        const nm = rowName(r.mine) || rowName(r.theirs) || 'A row';
        const body = !r.theirs ? '<p class="yr-clash__gone">' + esc(who + ' removed it') + '</p>' : !r.mine ? '<p class="yr-clash__gone">You removed it</p>'
          : '<dl class="yr-clash__cmp">' + clashFields(r).map(k => '<dt>' + esc(FIELDWORD[k] || k.replace(/_/g, ' ')) + '</dt><dd><span class="yr-clash__k">' + esc(who) + '</span>' + val(r.theirs[k]) + '</dd><dd class="is-mine"><span class="yr-clash__k">Yours</span>' + val(r.mine[k]) + '</dd>').join('') + '</dl>';
        return '<section class="yr-clash__row" data-clashrow="' + esc(r.id) + '"><p class="yr-clash__name"><b>' + esc(what + ' · ' + nm) + '</b> <button type="button" class="yr-link" data-clashshow="' + esc(r.id) + '">Show</button></p>' + body +
          '<p class="yr-btnrow"><button type="button" class="wk-btn wk-btn--line wk-btn--small" data-clash="theirs" data-cid="' + esc(r.id) + '">Keep theirs</button><button type="button" class="wk-btn wk-btn--line wk-btn--small" data-clash="mine" data-cid="' + esc(r.id) + '">Use mine</button></p></section>';
      }).join('') + '</div>';
  }
  // One clashing row settled; when none is left, the file is saved as it now stands.
  function settleClash(id, pick) {
    const c = state.clash; if (!c) return;
    const r = c.rows.find(x => x.id === id); if (!r) return;
    const list = state.cur[c.name], i = list.findIndex(x => (x._id || x.id) === id), want = pick === 'theirs' ? r.theirs : r.mine;
    if (!want && i > -1) list.splice(i, 1);
    else if (want && i > -1) list[i] = Object.assign({}, want);
    else if (want) list.push(Object.assign({}, want));
    c.rows = c.rows.filter(x => x !== r);
    if (!c.rows.length) { state.clash = null; E.saveFile(state.year, c.name, list.map(strip)); sent.add(c.name); dirty.delete('file:' + c.name); toast('Saved'); }
    redrawFile(c.name); chrome();
  }
  // Where a row is drawn, to show it.
  function rowEl(name, id) {
    const i = (state.cur[name] || []).findIndex(x => (x._id || x.id) === id);
    return root.querySelector('tr[data-id="' + CSS.escape(id) + '"]') || (name === 'help' && i > -1 ? root.querySelector('[data-help="' + i + '"]') : null) ||
      (name === 'guide' && i > -1 ? root.querySelector('[data-gi="' + i + '"]') : null) || (name === 'committees' ? root.querySelector('[data-com="' + CSS.escape(id) + '"]') : null) || root.querySelector('#s-' + (FILE_SEC[name] || ''));
  }

  // ⌘Z: this person's own changes, one pause at a time. A restored file that someone else has changed
  // since merges like any save (their rows stay).
  const UNDO_FILES = FILES.filter(n => n !== 'needs' && n !== 'notes');
  const ROWKEYS = ['start', 'end', 'venue', 'city', 'hosts'];
  function snapshot() {
    const files = {}; UNDO_FILES.forEach(n => { files[n] = state.cur[n]; });
    const row = {}; ROWKEYS.forEach(k => { row[k] = state.row[k] || ''; });
    return JSON.stringify({ files, S: state.cur.S, R: state.cur.R, row });
  }
  function record() {
    const s = snapshot();
    if (s === state.last) return;
    state.hist.push(state.last); if (state.hist.length > 200) state.hist.shift();
    state.fut = []; state.last = s;
  }
  function restore(s) {
    const o = JSON.parse(s), y = state.year;
    UNDO_FILES.forEach(n => { if (JSON.stringify(o.files[n]) !== JSON.stringify(state.cur[n])) { state.cur[n] = o.files[n]; E.saveFile(y, n, o.files[n].map(strip)); sent.add(n); } });
    Object.keys(o.S).forEach(k => { if (state.cur.S[k] !== o.S[k]) { state.cur.S[k] = o.S[k]; E.setKey(y, 'settings', k, o.S[k]); } });
    Object.keys(o.R).forEach(k => { if (state.cur.R[k] !== o.R[k]) { state.cur.R[k] = o.R[k]; saveReg(k); } });
    ROWKEYS.forEach(k => { if ((state.row[k] || '') !== o.row[k]) { state.row[k] = o.row[k]; E.setYear(y, k, o.row[k]); } });
    render(true);
  }
  function undo() { flush(); if (!state.hist.length) { toast('Nothing to undo'); return; } state.fut.push(state.last); state.last = state.hist.pop(); restore(state.last); toast('Undone'); }
  function redo() { flush(); if (!state.fut.length) return; state.hist.push(state.last); state.last = state.fut.pop(); restore(state.last); toast('Redone'); }

  /* ------------------------------------------------------------ what's public, and the year's committees */

  const held = () => !!(state.row.end && today() > state.row.end);
  const undated = () => !state.row.start;
  const isHeld = v => !v || v === NOT_YET;
  const posted = v => !!v && v !== NOT_YET && v <= today();
  const stampOf = part => coa().pub[part] || null;
  const byLine = s => s ? ' · ' + esc(s.by || '') : '';
  // Each part's public state, in one place.
  function pubOf(id) {
    const S = state.cur.S, R = state.cur.R, r = state.row;
    if (id === 'conference') { const v = r.coa_announced; return { on: posted(v), when: v, later: !!v && !posted(v) && v !== NOT_YET }; }
    if (id === 'schedule') return { on: posted(S.schedule_posted), when: S.schedule_posted };
    if (id === 'packet') return { on: posted(S.packet_posted), when: S.packet_posted };
    if (id === 'helping') return { on: posted(S.signups_posted), when: S.signups_posted, closed: posted(S.signups_closed) ? S.signups_closed : '' };
    if (id === 'registration') {
      const o = R.opens && R.opens !== NOT_YET ? R.opens : '', closed = posted(S.registration_closed) ? S.registration_closed : (R.closes && today() > R.closes ? R.closes : '');
      return { scheduled: !!o, on: posted(o) && !closed, when: o, closed };
    }
    if (id === 'youngfolks') {
      const o = state.cur.tournaments.map(t => t.opens).filter(v => O.parseISODate(v)).sort()[0] || '';
      return { scheduled: S.tournaments_held !== 'yes', on: S.tournaments_held !== 'yes' && posted(o) && !posted(S.tournaments_closed), when: o, closed: posted(S.tournaments_closed) ? S.tournaments_closed : '' };
    }
    return { on: false };
  }
  // The year's committees: one list every part uses (owners, requests, shifts, members). Until the
  // COA saves it, the names its requests and shifts use.
  function derivedCommittees() {
    const seen = {}, out = [];
    ['needs', 'shifts'].forEach(n => (state.cur[n] || []).forEach(r => { const c = String(r.committee || '').trim(); if (c && !/^#/.test(c) && !seen[c.toLowerCase()]) { seen[c.toLowerCase()] = 1; out.push({ _id: 'co' + (out.length + 1), name: c, contact_email: '', _derived: '1' }); } }));
    return out;
  }
  const committeeNames = () => state.cur.committees.map(c => c.name).filter(Boolean);
  const onList = name => committeeNames().some(c => c.toLowerCase() === String(name || '').trim().toLowerCase());
  function saveCommittees() { state.cur.committees.forEach(c => { delete c._derived; }); touch('file:committees'); }

  /* ------------------------------------------------------------ the sheets (lists you type into) */

  const audLabel = a => /young/i.test(a) ? 'Young Folks' : /preteen/i.test(a) ? 'Preteens' : /^all$/i.test(a) ? 'All' : 'Conference';
  const dayName = v => { const t = String(v || '').trim().toLowerCase().slice(0, 3); return t ? DAYS.find(d => d.toLowerCase().startsWith(t)) || '' : ''; };
  const timeText = r => {
    if (!r.start && !r.end && /all day/i.test(r.display || '')) return 'All day';
    const a = O.parseTime(r.start), b = O.parseTime(r.end);
    if (a != null) return b != null ? O.formatRange(a, b <= a ? b + 1440 : b) : O.formatTime(a) + (r.end ? ' – ' + r.end : '');
    return [r.start, r.end].filter(Boolean).join(' – ');
  };
  // "7–8 PM", "7:00 PM – 8:00 PM", "After Communion – 10 PM", "2 PM – ?"
  function setTime(r, v) {
    const s = String(v).trim();
    if (/^all day$/i.test(s)) { r.start = ''; r.end = ''; r.display = 'all day'; return; }
    if (/all day/i.test(r.display || '')) r.display = '';
    const parts = s.split(/\s*(?:–|—|\bto\b|-(?=\s*\d|\s*\?|\s*[A-Za-z]))\s*/i);
    let a = (parts[0] || '').trim(), b = parts.slice(1).join(' – ').trim();
    const mer = x => (String(x).match(/([ap])\.?\s*m\.?$/i) || [])[1];
    if (b && /^\d/.test(a) && !mer(a) && mer(b)) {
      const tb = O.parseTime(b), ta = O.parseTime(a + ' ' + mer(b) + 'm');
      a = a + ' ' + (ta != null && tb != null && ta > tb ? (mer(b).toLowerCase() === 'p' ? 'AM' : 'PM') : mer(b).toUpperCase() + 'M');
    }
    const fmt = x => { const t = O.parseTime(x); return t != null ? O.formatTime(t) : x; };
    r.start = fmt(a); r.end = b ? (b === '?' ? '?' : fmt(b)) : '';
  }
  const daysText = r => r.last_day && r.last_day !== r.day ? r.day + '–' + r.last_day : (r.day || '');
  function setDays(r, v) { const [a, b] = String(v).split(/\s*(?:–|-|\bto\b|\bthrough\b)\s*/i); r.day = dayName(a) || (a || '').trim(); r.last_day = b ? dayName(b) || b.trim() : ''; }
  const sizeText = t => t.solo === 'yes' && !t.min ? 'Solo' : (t.min && t.max && t.min !== t.max ? t.min + '–' + t.max : (t.min || t.max || '')) + (t.solo === 'yes' && t.min ? ' · solo OK' : '');
  function setSize(t, v) { const n = String(v).match(/\d+/g) || []; t.solo = /own|solo/i.test(v) ? 'yes' : ''; t.min = n[0] || ''; t.max = n[1] || n[0] || ''; }
  const closesText = t => [t.closes_day, t.closes_time].filter(Boolean).join(' ');
  function setCloses(t, v) { const m = String(v).trim().match(/^(\S+)\s*(.*)$/) || []; const d = dayName(m[1]); t.closes_day = d || ''; t.closes_time = d ? (m[2] || '') : String(v).trim(); }
  const roomsText = r => r.first && r.last && r.first !== r.last ? r.first + '–' + r.last : (r.first || '');
  function setRooms(r, v) { const [a, b] = String(v).split(/\s*[–-]\s*/); r.first = (a || '').trim(); r.last = (b || a || '').trim(); }
  const dateCol = k => ({ get: r => mdY(r[k]) || r[k] || '', set: (r, v) => { r[k] = parseMD(v) || v; }, check: r => r[k] && !O.parseISODate(r[k]) ? 'Not a date: try "May 21"' : '' });
  const placeCheck = r => r.place && !placesMap()[String(r.place).toUpperCase()] && !placesMap()[String(r.place).split('/')[0].toUpperCase()] ? 'Not a place at this campus' : '';
  function placesMap() { const m = {}; state.cur.places.forEach(p => { m[String(p.code).toUpperCase()] = p; }); return m; }

  const SHEETS = {
    week: { file: 'schedule', group: 'day', what: 'row', cols: [
      { c: 'time', label: 'Time', w: 'yr-w-time', get: timeText, set: setTime },
      { c: 'title', label: 'What', w: 'yr-serif' },
      { c: 'place', label: 'Where', w: 'yr-w-code yr-code', check: placeCheck, title: r => (placesMap()[String(r.place || '').toUpperCase()] || {}).name || '' },
      { c: 'audience', label: 'For', w: 'yr-w-for', pill: AUD, get: r => audLabel(r.audience) },
      { c: 'call_in', label: 'Call-in', w: 'yr-w-line', toggle: 'On the call-in line', get: r => O.yes(r.call_in) ? 'yes' : '', set: (r, v) => { r.call_in = /^(y|yes|true|1|x|✓|on)/i.test(String(v).trim()) ? 'yes' : ''; } }] },
    shifts: { file: 'shifts', group: 'committee', what: 'shift', cols: [
      { c: 'role', label: 'Shift', w: 'yr-serif' },
      { c: 'days', label: 'Days', w: 'yr-w-days', get: daysText, set: setDays },
      { c: 'time', label: 'Time', w: 'yr-w-time', get: timeText, set: setTime },
      { c: 'needed', label: 'People', w: 'yr-w-num', num: true },
      { c: 'place', label: 'Where', w: 'yr-w-code yr-code', check: placeCheck },
      { c: 'rule', label: 'Who can', w: 'yr-w-rule' }] },
    tournaments: { file: 'tournaments', what: 'tournament', cols: [
      { c: 'name', label: 'Tournament', w: 'yr-serif', set: (t, v) => { t.name = v; if (!t.id || t._new) t.id = O.slug(v); } },
      { c: 'size', label: 'Team size', short: 'Team', w: 'yr-w-size', get: sizeText, set: setSize },
      Object.assign({ c: 'opens', label: 'Opens', short: 'Opens', w: 'yr-w-date' }, dateCol('opens')),
      { c: 'closes', label: 'Closes', short: 'Closes', w: 'yr-w-close', get: closesText, set: setCloses }] },
    places: { file: 'places', what: 'room', cols: [
      { c: 'code', label: 'Code', w: 'yr-w-code yr-code' }, { c: 'name', label: 'Name', w: 'yr-serif' }, { c: 'building', label: 'Building' }] },
    rooms: { file: 'rooms', what: 'floor', cols: [
      { c: 'hall', label: 'Hall', w: 'yr-serif' }, { c: 'rooms', label: 'Rooms', w: 'yr-w-days', get: roomsText, set: setRooms },
      { c: 'floor', label: 'Floor', w: 'yr-w-num', num: true }, { c: 'beds', label: 'Beds', w: 'yr-w-num', num: true }, { c: 'for', label: 'For' }] },
    nearby: { file: 'nearby', what: 'place', cols: [
      { c: 'kind', label: 'Kind', w: 'yr-w-days' }, { c: 'name', label: 'Name', w: 'yr-serif' }, { c: 'phone', label: 'Phone', w: 'yr-w-phone' }, { c: 'hours', label: 'Hours' }] },
    notices: { file: 'notices', what: 'notice', cols: [
      { c: 'text', label: 'Notice', w: 'yr-serif' },
      Object.assign({ c: 'from', label: 'From', w: 'yr-w-date' }, dateCol('from')),
      Object.assign({ c: 'to', label: 'Until', w: 'yr-w-date' }, dateCol('to'))] }
  };
  const colOf = (name, c) => SHEETS[name].cols.find(x => x.c === c);
  const valOf = (col, r) => col.get ? col.get(r) : (r[col.c] || '');
  const dayIdx = d => { const ds = (state.cur.S.days || DAYS.join('|')).split('|'); const i = ds.indexOf(d); return i > -1 ? i : 9 + DAYS.indexOf(d); };
  const sortKey = r => { const t = O.parseTime(r.start), s = O.parseTime(r.sort_time); return r._new && t == null ? 99999 : t != null ? t : s != null ? s : 0; };
  const dateOf = day => { const f = firstDay(), i = DAYS.indexOf(day); return f && i > -1 ? O.isoAddDays(f, i) : ''; };

  function cell(name, col, r) {
    const v = valOf(col, r);
    // On the call-in line: a word, not a colour (Line · + Line).
    if (col.toggle) return '<td class="' + col.w + (r._chg && (' ' + r._chg + ' ').indexOf(' ' + col.c + ' ') > -1 ? ' is-chg' : '') + '"><button type="button" class="yr-tog" data-tog="' + col.c + '" aria-pressed="' + !!v + '" title="' + esc(col.toggle) + '">' + (v ? I.phone + 'Line' : I.plus + 'Line') + '</button></td>';
    if (col.pill) return '<td class="' + col.w + '"><button type="button" class="yr-pill" data-pill="' + col.c + '" title="Change who it’s for">' + esc(v) + '</button></td>';
    const flag = col.check ? col.check(r) : '', tip = flag || (col.title ? col.title(r) : ''), chg = r._chg && (' ' + r._chg + ' ').indexOf(' ' + col.c + ' ') > -1;
    return '<td class="' + [col.w || '', flag ? 'is-flag' : '', chg ? 'is-chg' : ''].join(' ').trim() + '" contenteditable="plaintext-only" spellcheck="' + (/serif/.test(col.w || '') ? 'true' : 'false') + '" data-c="' + col.c + '" aria-label="' + esc(col.label) + '"' + (col.short ? ' data-lab="' + esc(col.short) + '"' : '') + (tip ? ' title="' + esc(tip) + '"' : '') + '>' + esc(v) + '</td>';
  }
  function rowHtml(name, r) {
    const look = name === 'week' && r._look;
    const act = look ? '<button type="button" class="yr-keep" data-keep title="Kept this year">' + I.check + 'Looks right</button><button type="button" class="yr-del" data-del title="Not this year">' + I.x + '<span class="ogc-sr">Remove</span></button>'
      : '<button type="button" class="yr-del" data-del title="Remove">' + I.x + '<span class="ogc-sr">Remove</span></button>';
    const cls = [look ? 'is-look' : '', r._new || r._chg ? 'is-new' : ''].filter(Boolean).join(' ');
    return '<tr data-id="' + esc(r._id) + '"' + (cls ? ' class="' + cls + '"' : '') + '>' + SHEETS[name].cols.map(c => cell(name, c, r)).join('') + '<td class="yr-act">' + act + '</td></tr>';
  }
  function sheet(name, only) {
    const sp = SHEETS[name], all = only ? state.cur[sp.file].filter(only) : state.cur[sp.file], n = sp.cols.length + 1;
    const head = '<thead><tr>' + sp.cols.map(c => '<th class="' + (c.w || '') + '" scope="col"' + (c.toggle ? ' title="' + esc(c.toggle) + '"' : '') + '>' + esc(c.label) + '</th>').join('') + '<th class="yr-act"><span class="ogc-sr">Remove</span></th></tr></thead>';
    const add = g => '<tr class="yr-addrow"><td colspan="' + n + '"><button type="button" class="yr-add" data-add="' + esc(g || '') + '">' + I.plus + 'Add ' + sp.what + '</button></td></tr>';
    let body;
    if (sp.group) {
      const groups = Array.from(new Set(all.map(r => r[sp.group]).filter(Boolean)));
      body = groups.map(g => '<tbody data-group="' + esc(g) + '"><tr class="yr-grp"><th colspan="' + n + '" scope="rowgroup"><span class="yr-grp__in">' + esc(g) + '</span></th></tr>' +
        all.filter(r => r[sp.group] === g).map(r => rowHtml(name, r)).join('') + add(g) + '</tbody>').join('');
    } else body = '<tbody>' + all.map(r => rowHtml(name, r)).join('') + add() + '</tbody>';
    const own = name === 'tournaments' && (state.cur.S.tournaments_online || '') === 'no';
    return '<div class="yr-sheetwrap"><table class="yr-sheet yr-sheet--' + name + (own ? ' is-own' : '') + '" data-sheet="' + name + '">' + (all.length ? head : '') + body + '</table></div>';
  }

  /* ------------------------------------------------------------ pieces of a part's page */

  const y = () => esc(state.year);
  const pv = path => '../' + path + (path.indexOf('?') > -1 ? '&' : '?') + 'year=' + state.year + '&preview=1';
  // "See it" opens the real page beside the part (laptops) or over it (phones and tablets).
  const SEEN = [[/schedule-hub\/\?view=full/, 'The full schedule', 'schedule'], [/schedule-hub\//, 'The Conference page', 'conference'], [/register\//, 'The form', 'registration'], [/packet\//, 'The packet', 'packet'],
    [/guide\/\?view=help/, 'The guide · Help', 'packet'], [/guide\/\?view=places/, 'The guide · Places', 'conference'], [/volunteer\//, 'Volunteer sign-ups', 'helping'], [/tournaments\//, 'Tournaments', 'youngfolks']];
  const seeOf = href => SEEN.find(x => x[0].test(href.replace(/index\.html/, ''))) || [0, 'The page', ''];
  const see = (href, label) => '<a class="yr-see" href="' + esc(href) + '" target="_blank" rel="noopener" data-see>' + I.eye + esc(label || 'Preview') + '</a>';
  const head = (id, title, href) => {
    const p = partOf(id);
    if (p && p.secs.length === 1) return '';
    if (p && href === pv(p.see)) href = '';
    return '<div class="yr-sechead"><h2 class="yr-h" id="h-' + id + '">' + esc(title) + '</h2>' + (href ? see(href) : '') + '</div>';
  };
  const sec = (id, html) => '<section class="yr-sec" id="s-' + id + '"' + (html.indexOf('id="h-' + id + '"') > -1 ? ' aria-labelledby="h-' + id + '"' : ' aria-label="' + esc((SECTIONS.find(x => x[0] === id) || [0, ''])[1]) + '"') + '>' + html + '</section>';
  // One facts table everywhere: label, value, and (when there is one) a group heading row.
  const facts = rows => '<table class="yr-facts"><tbody>' + rows.filter(Boolean).map(r => r.grp != null ? '<tr class="yr-facts__grp"><th colspan="2" scope="rowgroup">' + r.grp + '</th></tr>'
    : '<tr' + (r[3] ? ' class="' + r[3] + '"' : '') + '><th scope="row">' + esc(r[0]) + '</th><td>' + r[1] + '</td></tr>' + (r[2] || '')).join('') + '</tbody></table>';
  const grp = (t, more) => ({ grp: '<span class="yr-facts__gh">' + esc(t) + '</span>' + (more || '') });
  const pills = (k, value, opts, label, attr) => '<span class="yr-pills" role="group" aria-label="' + esc(label) + '">' + opts.map(o => '<button type="button" class="yr-opt" ' + (attr || 'data-opt') + '="' + esc(k) + '" data-v="' + esc(o[0]) + '" aria-pressed="' + (o[0] === value) + '">' + esc(o[1]) + '</button>').join('') + '</span>';
  const help = t => '<small class="yr-help-t">' + esc(t) + '</small>';
  // A value typed where it reads: a real input (the right keyboard on a phone, 44 px to tap), drawn
  // like the value. kinds: money ($ inside), count, tel, text, date (takes "May 21"; a calendar beside).
  function field(k, v, kind, label, extra) {
    const o = extra || {};
    const attrs = kind === 'money' ? ' inputmode="decimal" pattern="[0-9.]*"' : kind === 'count' ? ' inputmode="numeric" pattern="[0-9]*"' : kind === 'tel' ? ' type="tel" autocomplete="off"' : '';
    const size = o.size || (kind === 'money' || kind === 'count' ? 5 : kind === 'date' ? 9 : kind === 'tel' ? 13 : Math.max(8, Math.min(34, String(v || '').length + 2)));
    const shown = kind === 'date' ? (mdY(v) || (v === NOT_YET ? '' : v || '')) : (v == null ? '' : v);
    // An address: lines, kept in the file with "|" between them (the form and the emails read it so).
    if (kind === 'area') return '<span class="yr-field yr-field--area"><textarea class="yr-in yr-in--area" data-k="' + esc(k) + '" data-kind="area" rows="3" aria-label="' + esc(label) + '" spellcheck="false" autocomplete="off">' + esc(String(shown).split('|').join('\n')) + '</textarea></span>';
    return '<span class="yr-field yr-field--' + kind + (o.moved ? ' is-moved' : '') + '">' + (kind === 'money' ? '<span class="yr-field__pre" aria-hidden="true">$</span>' : '') +
      '<input class="yr-in" data-k="' + esc(k) + '" data-kind="' + kind + '"' + (kind !== 'tel' ? ' type="text"' : '') + attrs + ' size="' + size + '" value="' + esc(shown) + '" aria-label="' + esc(label) + '"' + (o.ph ? ' placeholder="' + esc(o.ph) + '"' : '') + ' spellcheck="false" autocomplete="off">' +
      (kind === 'date' ? '<button type="button" class="yr-cal" data-cal="' + esc(k) + '" title="Calendar">' + I.cal + '<span class="ogc-sr">Choose ' + esc(label) + ' on a calendar</span></button>' : '') + '</span>';
  }
  // "Looks right" on the thing itself: stamps who and when; the step ticks itself from it.
  function looks(id, what, extra) {
    const c = coa().checks[id], more = extra && extra.length ? ' data-also="' + esc(extra.join(',')) + '"' : '';
    if (c) return '<p class="yr-looks is-done">' + I.check + '<span>Looks right · ' + esc(c.by || '') + ' · ' + esc(md(c.at)) + '</span><button type="button" class="yr-link" data-look="' + esc(id) + '" data-done=""' + more + ' title="Not checked after all">Undo</button></p>';
    return '<p class="yr-looks"><button type="button" class="yr-keepall" data-look="' + esc(id) + '" data-done="1"' + more + ' title="' + esc(what ? 'You’ve checked ' + what : 'You’ve checked it') + '">' + I.check + 'Looks right</button></p>';
  }
  // A carried value nobody has confirmed: not shown to the public until it is.
  const fromMark = id => { const p = pk(); return p.from && (p.confirm || []).indexOf(id) > -1 && !coa().checks[id] ? ' <small class="yr-from" title="Carried from ' + esc(p.from) + ' · Not public until checked">From ' + esc(p.from) + '</small>' : ''; };
  const confirmed = id => !((pk().confirm || []).indexOf(id) > -1 && !coa().checks[id]);

  /* ------------------------------------------------------------ The Conference */

  function datesRow() {
    const r = state.row, pd = state.pendingDates;
    if (state.open !== 'dates') {
      if (undated()) return ['Dates', '<button type="button" class="wk-btn wk-btn--small" data-open="dates">' + I.cal + 'Set the dates</button>' + (pk().from ? help('Last year’s dates move with them, once') : '')];
      const services = r.end ? O.fmtDateSpan(O.isoAddDays(r.start, 1), r.end) : '';
      return ['Dates', '<span class="yr-val-t">Arrival ' + esc(dayDate(r.start)) + (services ? ' · Services ' + esc(services) : '') + '</span> <button type="button" class="yr-link" data-open="dates">Change</button>'];
    }
    const fri = r.start || '', warn = [];
    if (pd && pd.start && weekday(pd.start) !== 'Friday') {
      const back = (5 - new Date(pd.start + 'T12:00:00Z').getUTCDay() + 7) % 7, f = O.isoAddDays(pd.start, back > 3 ? back - 7 : back);
      warn.push('<span class="yr-err">Not a Friday</span> <button type="button" class="yr-link" data-usefri="' + f + '">Use ' + esc(dayDate(f)) + '</button>');
    }
    let moves = '';
    if (pd && pd.plan) {
      const p = pd.plan, list = [p.registration && SU.plural(p.registration, 'registration date'), p.packet && SU.plural(p.packet, 'date') + ' in the packet', p.tournaments && SU.plural(p.tournaments, 'tournament')].filter(Boolean);
      const by = p.d ? Math.abs(p.d) + (Math.abs(p.d) === 1 ? ' day ' : ' days ') + (p.d < 0 ? 'earlier' : 'later') : '';
      const people = signedUp();
      moves = '<p class="yr-moves">' + (list.length ? 'Moves ' + esc(list.join(', ').replace(/, ([^,]*)$/, ' and $1')) + (by && r.start ? ' ' + esc(by) : '') : 'Nothing else moves') +
        (p.empty_days && p.empty_days.length ? '<br><span class="yr-err">' + esc(p.empty_days.join(', ')) + ' · no rows on the schedule</span>' : '') +
        (p.dropped_days && p.dropped_days.length ? '<br><span class="yr-err">' + esc(p.dropped_days.join(', ')) + ' · not in the new dates; its rows stay to move</span>' : '') +
        (people && pubOf('helping').on ? '<br>' + esc(SU.plural(people, 'volunteer') + ' signed up · their shifts move too') : '') + '</p>' +
        '<p class="yr-btnrow"><button type="button" class="wk-btn wk-btn--line wk-btn--small" data-datesgo>' + (list.length ? 'Move' : 'Save') + '</button><button type="button" class="yr-link" data-open="">Cancel</button></p>';
    }
    return ['Dates', '<span class="yr-dates">' +
      '<label class="yr-lab">Arrival (Friday)' + field('date.start', pd ? pd.start : fri, 'date', 'Arrival (Friday)', { ph: 'May 28' }) + '</label>' +
      '<label class="yr-lab">Last day' + field('date.end', pd ? pd.end : (r.end || ''), 'date', 'Last day', { ph: 'June 1' }) + '</label></span>' +
      (warn.length ? '<p class="yr-moves">' + warn.join('<br>') + '</p>' : '') + moves +
      (!pd || !pd.plan ? '<p class="yr-btnrow"><button type="button" class="yr-link" data-open="">Cancel</button></p>' : '')];
  }
  // How many, never who: counts come with the year's overview (GET coa/{y}); the page loads nobody's record.
  const counts = () => (state.ov && state.ov.counts) || { registrations: 0, signups: 0, shifts: {}, teams: {} };
  const signedUp = () => counts().signups || 0;
  function placeRows() {
    const r = state.row, S = state.cur.S, cur = S.venue || r.venue || '';
    const rows = [];
    const undoIt = state.ov.undo;
    const restore = undoIt ? '<p class="yr-dim">' + esc('Changed ' + (undoIt.from ? 'from ' + undoIt.from + ' ' : '') + md(undoIt.at) + ' · ' + (undoIt.by || '')) + ' <button type="button" class="yr-link" data-campusundo>Restore</button></p>' : '';
    if (state.open !== 'place' && state.open !== 'newcampus') {
      rows.push(['Place', (cur ? '<span class="yr-val-t">' + esc(cur) + '</span> <small class="yr-dim">' + esc(cityOf(S.city || r.city)) + '</small> ' : '<span class="yr-dim">No campus yet</span> ') + '<button type="button" class="yr-link" data-open="place">' + (cur ? 'Change' : 'Choose') + '</button>' + restore]);
      return rows;
    }
    if (state.pendingCampus) {
      const p = state.pendingCampus.plan, b = p.brings, rp = p.replaces;
      const brings = [b.places && SU.plural(b.places, 'building and room', 'buildings and rooms'), b.halls && SU.plural(b.halls, 'dorm hall'), b.help && SU.plural(b.help, 'Help card'), b.nearby && 'care nearby', b.prices && b.prices.length && 'its prices', b.map && 'the campus map', b.packet && b.packet.length && 'the packet’s ' + b.packet.join(', '), b.needs && SU.plural(b.needs, 'request')].filter(Boolean);
      const loses = [rp.pins && SU.plural(rp.pins, 'map pin'), rp.places && SU.plural(rp.places, 'place'), rp.halls && SU.plural(rp.halls, 'hall')].filter(Boolean);
      rows.push(['Place', '<div class="yr-confirm" role="group" aria-label="Change campus"><p><b>Use ' + esc(p.venue) + '?</b></p>' +
        '<p>' + (p.new ? 'A new campus: its buildings, halls and map start blank' : esc('From ' + p.venue.replace(/ University$/, '') + ' ' + p.from + ': ' + (brings.join(', ') || 'nothing kept there yet'))) + '</p>' +
        (loses.length ? '<p class="yr-err">' + esc('Replaces ' + loses.join(', ') + (rp.venue ? ' at ' + rp.venue : '')) + '</p>' : '') +
        (p.unmatched.schedule || p.unmatched.shifts ? '<p>' + esc([p.unmatched.schedule && SU.plural(p.unmatched.schedule, 'schedule row'), p.unmatched.shifts && SU.plural(p.unmatched.shifts, 'shift')].filter(Boolean).join(' and ') + ' · places to choose') + '</p>' : '') +
        (rp.needs_answered ? '<p>' + esc(SU.plural(rp.needs_answered, 'request') + ' answered · requests kept') + '</p>' : '') +
        '<p class="yr-btnrow"><button type="button" class="wk-btn wk-btn--line wk-btn--small" data-campusgo>Change campus</button><button type="button" class="yr-link" data-campuscancel>Cancel</button></p></div>']);
      return rows;
    }
    if (state.open === 'newcampus') {
      rows.push(['Place', '<form class="yr-newcampus" data-newcampus><label>Name<input name="venue" required autocomplete="off"></label><label>Town, State<input name="city" autocomplete="off"></label><label>Street address<input name="address" autocomplete="off"></label>' +
        '<p class="yr-btnrow"><button type="submit" class="wk-btn wk-btn--line wk-btn--small">' + I.plus + 'Add campus</button><button type="button" class="yr-link" data-open="place">Cancel</button></p></form>']);
      return rows;
    }
    const vs = []; state.years.slice().reverse().forEach(z => { if (z.venue && !vs.some(v => v.venue === z.venue)) vs.push({ venue: z.venue, city: z.city, n: state.years.filter(w => w.venue === z.venue).length }); });
    rows.push(['Place', '<div class="yr-places" role="group" aria-label="Campus">' + vs.sort((a, b) => b.n - a.n).map(v => { const on = v.venue === cur; return '<button type="button" class="yr-place' + (on ? ' is-on' : '') + '" data-place="' + esc(v.venue) + '" aria-pressed="' + on + '"' + (on ? ' title="Already chosen"' : '') + '><b>' + esc(v.venue) + '</b><small>' + esc(cityOf(v.city) + ' · ' + SU.plural(v.n, 'Conference')) + (on ? ' · Chosen' : '') + '</small></button>'; }).join('') +
      '<button type="button" class="yr-place yr-place--new" data-open="newcampus"><b>' + I.plus + 'New campus</b><small>Not used before</small></button></div>' +
      help('Buildings, halls, Help and prices come from its last Conference') + '<p class="yr-btnrow"><button type="button" class="yr-link" data-open="">Cancel</button></p>']);
    return rows;
  }
  function confSec() {
    const r = state.row, S = state.cur.S, hold = undated() && pk().from;
    return sec('conf', head('conf', 'Dates and place', pv('schedule-hub/')) + facts([
      datesRow(),
      ...placeRows(),
      ['Hosts', 'The ' + field('hosts', S.hosts || r.hosts || '', 'text', 'Hosts', { size: 28 })],
      ['Call-in line', field('call_in_number', S.call_in_number || '', 'tel', 'Call-in number', { ph: '717-555-0100' }) + ' <span class="yr-dim">PIN</span> ' + field('call_in_pin', S.call_in_pin || '', 'count', 'PIN', { size: 9 }) + fromMark('conf:callin') +
        help('Phone only · Services aren’t streamed')]
    ]) + (hold ? '' : looks('conf:callin', 'the hosts and the call-in line')));
  }
  function campusSec() {
    const c = state.cur, S = c.S, from = (pk().parts.places || {}).from;
    const floors = c.rooms.filter(r => r.hall).length, halls = Array.from(new Set(c.rooms.map(r => r.hall).filter(Boolean))).length;
    const rooms = c.places.filter(r => r.code), pinned = rooms.filter(r => r.x !== '' && r.x != null && !isNaN(+r.x)).length, byB = rooms.filter(r => buildingOfPlace(r)).length;
    const edit = what => '<a class="yr-link" href="' + esc(editHref(what, 'conference')) + '">' + I.edit + 'Edit</a>';
    const row = (label, val, act) => '<tr><th scope="row">' + esc(label) + '</th><td>' + val + '</td><td class="yr-list__go">' + (act || '') + '</td></tr>';
    const none = t => '<span class="yr-dim">' + esc(t) + '</span>';
    if (!S.venue && !state.row.venue) return sec('campus', head('campus', 'The campus') + '<div class="ws-blank"><p class="ws-blank__h">No campus yet</p><p class="ws-blank__p">Choose it under Dates and place</p></div>');
    const addr = state.open === 'address' ? '<form class="yr-inlineform" data-address>' + '<label class="ogc-sr" for="yr-addr">Street address</label><input id="yr-addr" name="address" value="' + esc(S.address || '') + '" autocomplete="off"><button type="submit" class="wk-btn wk-btn--line wk-btn--small">Save</button><button type="button" class="yr-link" data-open="">Cancel</button></form>'
      : (S.address ? '<small class="yr-dim">' + esc(S.address) + '</small> ' : '') + '<button type="button" class="yr-link" data-open="address">' + (S.address ? 'Change' : 'Add address') + '</button>';
    return sec('campus', head('campus', 'The campus', pv('guide/?view=places')) +
      '<p class="yr-lede">' + esc(S.venue || state.row.venue || '') + ' ' + addr + '</p>' + (from ? '<p class="yr-dim yr-kept">From ' + esc(from) + '</p>' : '') +
      '<table class="yr-list"><tbody>' +
        row('Buildings and rooms', c.places.length ? SU.plural(c.places.length, 'place') : none('None yet'), edit('places')) +
        row('Dorm halls', floors ? SU.plural(halls, 'hall') + ' · ' + SU.plural(floors, 'floor') + (c.plans && c.plans.length ? ' · ' + c.plans.length + ' on the map' : '') + ' <small class="yr-dim" title="Which halls, the floors and the room numbers are samples until Lodging gets the university’s plans">· Sample</small>' : none('None yet'), edit('rooms')) +
        row('Campus map', c.campus ? 'Ready' : none(W.webmaster ? 'None yet' : 'None yet · the webmasters add it'), '') +
        row('Map pins', c.campus ? esc(pinWord(rooms)) : none('No map'), c.campus ? '<a class="yr-link" href="' + esc(partHref('conference') + '&tool=pins') + '" title="Where each room on the schedule is: by its door, or tapped on the map">' + I.pin + 'Pin</a>' : '') +
        row('Care nearby', c.nearby.length ? SU.plural(c.nearby.length, 'place') : none('None yet'), edit('nearby')) +
      '</tbody></table>' + looks('conf:campus', 'the campus: buildings, halls and care nearby'));
  }
  // The year's committees: one list, carried from last year, that every part reads.
  function committeesSec() {
    const l = state.cur.committees, derived = l.some(c => c._derived);
    const stray = Array.from(new Set(state.cur.needs.concat(state.cur.shifts).map(r => String(r.committee || '').trim()).filter(c => c && !/^#/.test(c) && !onList(c))));
    return sec('committees', head('committees', 'Committees') +
      '<ul class="yr-coms">' + l.map(c => '<li data-com="' + esc(c._id) + '"><input class="yr-in yr-in--com" data-comname="' + esc(c._id) + '" value="' + esc(c.name) + '" aria-label="Committee name" size="' + Math.max(8, c.name.length + 1) + '" autocomplete="off">' +
        '<input class="yr-in yr-in--contact" data-comcontact="' + esc(c._id) + '" value="' + esc(c.contact_email || '') + '" aria-label="' + esc(c.name + ' contact') + '" placeholder="Contact email" type="email" autocomplete="off" title="A role inbox or a member’s email · Members only">' +
        '<button type="button" class="yr-del" data-comdel="' + esc(c._id) + '" title="Remove">' + I.x + '<span class="ogc-sr">Remove ' + esc(c.name) + '</span></button></li>').join('') + '</ul>' +
      (stray.length ? '<p class="yr-ask"><span>' + esc('Used in requests or shifts, not on the list: ' + stray.join(', ')) + '</span>' + (stray.length > 1 ? '<button type="button" class="yr-keepall" data-comadd="' + esc(stray.join('|')) + '">' + I.plus + 'Add all ' + stray.length + '</button>' : '<button type="button" class="yr-link" data-comadd="' + esc(stray[0]) + '">Add ' + esc(stray[0]) + '</button>') + '</p>' : '') +
      '<p class="yr-under"><button type="button" class="yr-link" data-comnew>' + I.plus + 'Add committee</button>' + (derived ? help('From the requests and shifts · Renaming one renames it everywhere') : help('Renaming one renames it everywhere')) + '</p>');
  }
  function noticesSec() {
    const n = state.cur.notices;
    if (!n.length) return sec('notices', head('notices', 'Notices', pv('schedule-hub/')) + '<div class="ws-blank"><p class="ws-blank__h">No notices</p><p class="ws-blank__p">One line under the Conference page’s title, between two dates</p><p class="ws-blank__btn"><button type="button" class="wk-btn wk-btn--line wk-btn--small" data-addnotice>' + I.plus + 'Add notice</button></p></div>');
    return sec('notices', head('notices', 'Notices', pv('schedule-hub/')) + sheet('notices'));
  }

  /* ------------------------------------------------------------ The schedule */

  // The schedule is edited in its own full-screen editor (Oct 8, Michael: a sheet here was "very
  // constricting and fiddly"). Here: the week at a glance, what's left to check, and the way in.
  const editHref = (what, back) => '../admin/?role=coa&year=' + encodeURIComponent(state.year) + '&edit=' + encodeURIComponent(what) + '&back=' + encodeURIComponent(back || state.part || '');
  const lookRows = () => state.cur.schedule.filter(r => r._look);
  const firstLookDay = () => { const ds = (state.cur.S.days || '').split('|'); return lookRows().map(r => r.day).sort((a, b) => ds.indexOf(a) - ds.indexOf(b))[0] || ''; };
  const phone = () => matchMedia('(max-width: 719px)').matches;
  const checkHref = () => phone() ? partHref('schedule') + '&tool=check' : editHref('schedule:' + firstLookDay(), 'schedule') + '&check=1';
  function weekSec() {
    const all = state.cur.schedule, days = (state.cur.S.days || '').split('|').filter(Boolean), last = days[days.length - 1];
    const rows = days.map((d, i) => {
      const rs = all.filter(r => r.day === d && r.title), date = state.row.start ? O.isoAddDays(state.row.start, i) : '', calls = rs.filter(r => O.yes(r.call_in)).length, chk = rs.filter(r => r._look).length, place = rs.filter(r => r._look === 'place').length;
      if (!rs.length) return '<li><span class="yr-day is-empty"><b>' + esc(d) + '</b><small>' + esc(date ? dayDate(date) : '') + '</small><span class="yr-day__n yr-err">No rows</span><span class="yr-day__x"></span></span></li>';
      return '<li><a class="yr-day" href="' + esc(editHref('schedule:' + d, 'schedule')) + '"><b>' + esc(d) + (d === last && days.length > 5 ? ' <span class="yr-dim">· check-out</span>' : '') + '</b><small>' + esc(date ? md(date) : '') + '</small>' +
        '<span class="yr-day__n">' + SU.plural(rs.length, 'row') + '</span>' +
        '<span class="yr-day__x">' + (calls ? '<i title="On the call-in line">' + I.phone + calls + ' on the line</i>' : '') + (chk ? '<i class="is-check" title="From ' + esc(pk().from || 'last year') + ', varies each year">' + (chk - place) + ' to check</i>' : '') + (place ? '<i class="is-check" title="Not a place at this campus">' + place + ' places to choose</i>' : '') + '</span>' + I.go + '</a></li>';
    }).join('');
    return sec('week', head('week', 'The week', pv('schedule-hub/?view=full') + '&pv-at=.wk-bar') +
      (all.length ? '' : '<div class="ws-blank"><p class="ws-blank__h">No rows yet</p><p class="ws-blank__p">Type a day’s rows in the editor, or paste them from a spreadsheet</p></div>') +
      '<p class="yr-bigbtn"><a class="wk-btn wk-btn--line" href="' + esc(editHref('schedule', 'schedule')) + '">' + I.edit + 'Edit schedule</a></p>' +
      '<ol class="yr-days">' + rows + '</ol>' +
      '<p class="yr-under">' + outLink('week') + '</p>');
  }
  // On a phone: the rows to check as a plain list, each with Looks right (the editor is for a laptop).
  function checkTool() {
    const rows = lookRows().slice().sort((a, b) => dayIdx(a.day) - dayIdx(b.day) || sortKey(a) - sortKey(b));
    return '<div class="yr-body yr-body--part"><div class="yr-doc"><div class="yr-sheetpage"><header class="yr-dochead yr-parthead"><div class="yr-parthead__row"><h1 class="yr-title">Rows to check</h1></div>' +
      '<p class="yr-meta">' + esc(rows.length ? SU.plural(rows.length, 'row') + ' · from ' + (pk().from || 'last year') : 'All checked') + '</p></header>' +
      (rows.length ? '<ul class="yr-checks">' + rows.map(r => '<li data-id="' + esc(r._id) + '"><p class="yr-checks__when">' + esc(r.day + ' · ' + (timeText(r) || 'No time')) + '</p><p class="yr-checks__t">' + esc(r.title) + '</p>' +
        '<p class="yr-checks__where">' + esc([r.place, audLabel(r.audience)].filter(Boolean).join(' · ')) + (r._look === 'place' ? ' · <span class="yr-err">Place to choose</span>' : '') + '</p>' +
        '<p class="yr-btnrow"><button type="button" class="wk-btn wk-btn--line wk-btn--small" data-keep2="' + esc(r._id) + '"' + (r._look === 'place' ? ' disabled title="Choose its place first"' : '') + '>' + I.check + 'Looks right</button><a class="yr-link" href="' + esc(editHref('schedule:' + r.day, 'schedule') + '&check=1') + '">Edit on a laptop</a></p></li>').join('') + '</ul>'
        : '<div class="ws-blank"><p class="ws-blank__h">All checked</p></div>') + '</div></div></div>';
  }

  /* ------------------------------------------------------------ Registration */

  const MONEY = ['room_price', 'linen_price', 'mattress_price', 'camper_price', 'key_fee', 'bed_fee'];
  function regSec() {
    const R = state.cur.R, S = state.cur.S, p = pk(), moved = (p.parts.registration || {}).moved || [], sug = p.suggest || {};
    if (!Object.keys(R).length) return sec('reg', '<div class="ws-blank"><p class="ws-blank__h">Not set up</p></div>');
    // registration_mode is what the Conference page's Register button follows (site · link · none).
    const own = S.registration_mode === 'link';
    const tool = ['Tool', pills('registration_mode', own ? 'link' : 'site', [['site', 'This site'], ['link', 'Another tool']], 'Registration tool', 'data-sopt') +
      (own ? '<br>' + field('registration_url', S.registration_url || '', 'text', 'Link to the form', { size: 34, ph: 'https://' }) + help('The Register button goes there') : '')];
    if (own) return sec('reg', facts([tool]));
    const was = k => { const m = moved.find(x => x.k === k); return m && m.from && R[k] === m.to ? ' <small class="yr-was">' + esc(m.from.slice(0, 4) + ': ' + md(m.from)) + '</small>' : ''; };
    const date = (k, label) => field('reg.' + k, R[k] === NOT_YET ? '' : R[k], 'date', label, { moved: moved.some(x => x.k === k && R[k] === x.to), ph: undated() ? 'With the dates' : 'Date' }) + was(k);
    const money = (k, label) => field('reg.' + k, R[k] || '', 'money', label);
    const count = (k, label) => field('reg.' + k, R[k] || '', 'count', label);
    const pub = pubOf('registration'), st = stampOf('registration');
    const opens = pub.scheduled ? '<span class="yr-val-t">' + esc(mdY(pub.when)) + (R.opens_time ? ' · ' + esc(R.opens_time) : '') + '</span>' + (st ? ' <small class="yr-dim">' + esc('Scheduled · ' + (st.by || '')) + '</small>' : '') + ' <button type="button" class="yr-link" data-panel="registration">Change</button>'
      : undated() ? '<span class="yr-dim">Set with the dates</span>' + (sug.opens && sug.opens.from ? ' <small class="yr-was">' + esc(sug.opens.from.slice(0, 4) + ': ' + md(sug.opens.from)) + '</small>' : '')
      : '<span class="yr-dim">Not scheduled</span>' + (sugOpens() ? ' · <span>' + esc(mdY(sugOpens())) + ' suggested</span>' : '');
    const nights = String(R.nights || '').split('|'), early = String(R.early_nights || '').split('|');
    const days = (S.days || DAYS.slice(0, 5).join('|')).split('|').filter(d => d !== 'Wednesday' || nights.indexOf(d) > -1);
    const nightDate = d => state.row.start ? ' ' + O.fmtDate(O.isoAddDays(state.row.start, DAYS.indexOf(d)), 'day') : '';
    const mattress = !!R.mattress_price || R.mattress_offered === 'yes';
    const n = regCount();
    const fees = campusRules(R);
    return sec('reg', facts([
      tool,
      grp('When'),
      ['Opens', opens],
      ['Opens at', field('reg.opens_time', R.opens_time || '', 'text', 'Opening time', { size: 8, ph: 'Time' }) + ' <small class="yr-dim">' + esc(state.cur.S.timezone_label || 'campus time') + '</small>'],
      ['Closes', date('closes', 'Closes') + help('After that, at check-in')],
      ['Nights', '<span class="yr-pills" role="group" aria-label="Nights">' + days.map(d => '<button type="button" class="yr-opt" data-night="' + esc(d) + '" aria-pressed="' + (nights.indexOf(d) > -1) + '">' + esc(d.slice(0, 3)) + esc(nightDate(d)) + '</button>').join('') + '</span>'],
      ['Early nights', '<span class="yr-pills" role="group" aria-label="Early nights">' + ['Wednesday', 'Thursday'].map(d => { const on = early.indexOf(d) > -1; return '<button type="button" class="yr-opt" data-early="' + d + '" aria-pressed="' + on + '">' + esc(d.slice(0, 3)) + (state.row.start ? ' ' + O.fmtDate(SU.earlyDate(d, state.row.start), 'day') : '') + '</button>'; }).join('') + '</span>' + help('For committees and helpers who come early · priced as nights')],
      // Every price carried from last year waits for one "Looks right" on the whole block.
      grp('Prices', fromMark('reg:prices') + looks('reg:prices', 'the prices, and the linens and mattresses on hand')),
      ['Dorm rooms', money('room_price', 'Room price') + ' <span class="yr-dim">a night ·</span> ' + count('room_beds', 'Beds to a room') + ' <span class="yr-dim">beds to a room</span><br>' + pills('price_basis', R.price_basis === 'person' ? 'person' : 'room', [['room', 'Per room'], ['person', 'Per person']], 'The campus charges', 'data-opt')],
      ['Rooms held', field('reg.rooms_held', R.rooms_held || '', 'count', 'Rooms held', { size: 6 }) + help('Rooms the campus is holding · the form stops there')],
      ['Linen packets', money('linen_price', 'Linen price') + ' <span class="yr-dim">·</span> ' + count('linen_stock', 'Linen packets on hand') + ' <span class="yr-dim">on hand</span>'],
      ['Air mattresses', pills('mattress_offered', mattress ? 'yes' : 'no', [['yes', 'Offered'], ['no', 'Not offered']], 'Air mattresses', 'data-mattress') + (mattress ? '<br>' + money('mattress_price', 'Air mattress price') + ' <span class="yr-dim">·</span> ' + count('mattress_stock', 'Air mattresses on hand') + ' <span class="yr-dim">on hand</span>' : '')],
      ['Camper lot', money('camper_price', 'Camper price') + ' ' + pills('camper_per', R.camper_per, [['night', 'a night'], ['stay', 'for the stay']], 'Camper price is')],
      ...fees.filter(f => f[2] === 'fee').map(f => [f[0], f[1]]),
      grp('On the form'),
      ['Meals', pills('meals_free', R.meals_free, [['yes', 'Provided'], ['no', 'Paid on the form']], 'Meals')],
      ['Preteens’ medical notes', pills('preteen_details', R.preteen_details, [['online', 'On the form'], ['paper', 'On paper at check-in']], 'Preteens’ medical notes')],
      ['Credit for unused nights', 'Asked by ' + date('refunds_by', 'Credit asked by')],
      ['Cancel by', date('cancel_by', 'Cancel by') + help('Full refund before this date')],
      ['Checks', '<span class="yr-lab-t">Payable to</span> ' + field('reg.check_payee', R.check_payee || '', 'text', 'Checks payable to', { size: 30 }) + '<br><span class="yr-lab-t">Mail to</span> ' + field('reg.check_address', R.check_address || '', 'area', 'Mail checks to')],
      ['Paper forms', pills('paper_forms', R.paper_forms === 'yes' ? 'yes' : 'no', [['yes', 'Lodging enters them'], ['no', 'None']], 'Paper forms') + help('For households without email')],
      ['A gift for', field('reg.gift_for', R.gift_for || '', 'text', 'What the form’s gift is for', { size: 24, ph: 'What it’s for' }) + help('Optional on the form')],
      ['Rooms given by', pills('room_choice', R.room_choice === 'households' ? 'households' : 'lodging', [['lodging', 'Lodging'], ['households', 'Each household']], 'Rooms given by') + (state.cur.plans && state.cur.plans.length ? ' <span class="yr-dim" title="' + esc(state.cur.plans.join(', ')) + '">· ' + SU.plural(state.cur.plans.length, 'hall') + ' on the map</span>' : '')],
      ...fees.filter(f => f[2] !== 'fee'),
      ['Names cleared', W.webmaster ? count('clear_after_days', 'Days after the Conference') + ' <span class="yr-dim">days after</span>' + (state.row.end ? ' <span class="yr-dim">· ' + esc(mdY(O.isoAddDays(state.row.end, +R.clear_after_days || 60))) + '</span>' : '')
        : esc((R.clear_after_days || 60) + ' days after') + (state.row.end ? ' · ' + esc(mdY(O.isoAddDays(state.row.end, +R.clear_after_days || 60))) : '') + help('Set by the webmasters')]
    ]) + (n ? '<p class="yr-dim">' + esc(SU.plural(n, 'household') + ' registered · a changed price applies to new registrations') + '</p>' : '') +
      (p.parts.registration && p.parts.registration.campus ? '<p class="yr-dim yr-kept">Prices and the campus’s rules from ' + esc(p.parts.registration.campus) + ', the last Conference at ' + esc(state.cur.S.venue || state.row.venue || 'this campus') + '</p>' : ''));
  }
  const sugOpens = () => { const s = (pk().suggest || {}).opens; return s && s.to ? s.to : (state.row.start ? O.isoAddDays(state.row.start, DUE.registration) : ''); };
  const regCount = () => counts().registrations || 0;
  // A campus's own fees and rules, shown only where the campus has them.
  function campusRules(R) {
    const out = [];
    if (R.key_fee) out.push(['Lost key', field('reg.key_fee', R.key_fee, 'money', 'Lost key fee') + ' <span class="yr-dim">each key or fob</span>', 'fee']);
    if (R.bed_fee) out.push(['Beds moved', field('reg.bed_fee', R.bed_fee, 'money', 'Fee for beds not put back') + ' <span class="yr-dim">if not put back</span>', 'fee']);
    if ('yf_age_split' in R) out.push(['Young Folks rooms', pills('yf_age_split', R.yf_age_split === 'yes' ? 'yes' : 'no', [['yes', 'All under 18, or all 18 and over'], ['no', 'Any ages']], 'Young Folks rooms')]);
    return out;
  }

  /* ------------------------------------------------------------ The packet */

  const partIds = () => Array.from(new Set(state.cur.guide.map(r => r.id)));
  const partChecks = () => partIds().map(id => 'packet:' + id);
  // Prices written into the packet that disagree with Registration (change it once: Registration's
  // value is the one the form charges).
  const FACTS = [['linen_price', /linen/i, 'Linen packets'], ['room_price', /\b(dorm|room)s?\b/i, 'Dorm rooms'], ['camper_price', /\b(camper|RV)/i, 'Camper lot'], ['mattress_price', /mattress/i, 'Air mattresses']];
  function factsCheck() {
    const out = [], R = state.cur.R;
    state.cur.guide.forEach((r, i) => ['summary', 'text'].forEach(f => {
      const t = String(r[f] || ''), re = /\$\s?\d+(?:\.\d{2})?/g;
      let m;
      while ((m = re.exec(t))) {
        // The item a price belongs to is the nearest one named just before it ("linen packets are $27").
        const before = t.slice(Math.max(0, m.index - 60), m.index);
        let best = null, at = -1;
        FACTS.forEach(fc => { const g = new RegExp(fc[1].source, 'gi'); let x; while ((x = g.exec(before))) { if (x.index > at) { at = x.index; best = fc; } } });
        if (!best || !R[best[0]]) continue;
        const v = m[0].replace(/[$\s]/g, '').replace(/\.00$/, '');
        if (v !== String(R[best[0]]).replace(/\.00$/, '')) out.push({ i, f, k: best[0], label: best[2], was: m[0], to: '$' + R[best[0]], part: (state.cur.guide.find(g => g.id === r.id && g.title) || {}).title || r.id });
      }
    }));
    return out.slice(0, 8);
  }
  function packetSec() {
    const g = state.cur.guide, ids = partIds(), moved = (pk().parts.packet || {}).moved || [];
    const mark = (t, id) => {
      let h = esc(t); const done = {};
      moved.filter(m => m.id === id && !done[m.to] && (done[m.to] = 1)).forEach(m => { h = h.split(esc(m.to)).join('<mark class="yr-moved" title="Moved with the Conference · was ' + esc(m.from) + '">' + esc(m.to) + '</mark>'); });
      return h;
    };
    const fc = factsCheck();
    const parts = ids.map((id, k) => {
      const rows = g.map((r, i) => Object.assign({ i }, r)).filter(r => r.id === id), first = rows.find(r => r.title) || rows[0], c = coa().checks['packet:' + id], from = rows.some(r => r._from);
      return '<article class="yr-part" id="pp-' + esc(id) + '" data-part="' + esc(id) + '"><div class="yr-part__bar">' +
        (c ? '<span class="yr-part__ok">' + I.check + esc('Looks right · ' + (c.by || '') + ' · ' + md(c.at)) + '</span>' : '<button type="button" class="yr-keep" data-look="packet:' + esc(id) + '" data-done="1" data-part2="packet">' + I.check + 'Looks right</button>') +
        (from ? '<small class="yr-from">From ' + esc(rows.find(r => r._from)._from) + ' · this campus</small>' : '') +
        '<span class="yr-part__tools"><button type="button" class="yr-iconbtn" data-mvpart="' + esc(id) + '" data-dir="-1"' + (k ? '' : ' disabled') + ' title="Move up">' + I.up + '<span class="ogc-sr">Move ' + esc(first.title || 'part') + ' up</span></button>' +
        '<button type="button" class="yr-iconbtn" data-mvpart="' + esc(id) + '" data-dir="1"' + (k < ids.length - 1 ? '' : ' disabled') + ' title="Move down">' + I.dn + '<span class="ogc-sr">Move ' + esc(first.title || 'part') + ' down</span></button>' +
        '<button type="button" class="yr-iconbtn" data-rmpart="' + esc(id) + '" title="Remove">' + I.x + '<span class="ogc-sr">Remove ' + esc(first.title || 'part') + '</span></button></span></div>' +
        '<h3 contenteditable="plaintext-only" data-gi="' + first.i + '" data-gf="title" aria-label="Part title">' + esc(first.title || '') + '</h3>' +
        '<p class="yr-part__sum" contenteditable="plaintext-only" data-gi="' + first.i + '" data-gf="summary" aria-label="In one line" data-empty="In one line">' + mark(first.summary || '', id) + '</p>' +
        rows.map(r => '<p contenteditable="plaintext-only" data-gi="' + r.i + '" data-gf="text" aria-label="Paragraph">' + mark(r.text, id) + '</p>').join('') + '</article>' +
        '<p class="yr-addbetween' + (k === ids.length - 1 ? ' is-last' : '') + '"><button type="button" class="yr-add" data-addpart="' + esc(id) + '">' + I.plus + 'Add part</button></p>';
    }).join('');
    const contents = ids.length > 2 ? '<nav class="yr-contents" aria-label="The packet’s parts"><p class="yr-contents__h">Contents</p><ol>' + ids.map(id => { const f = g.find(r => r.id === id && r.title) || {}; return '<li><a href="#pp-' + esc(id) + '">' + (coa().checks['packet:' + id] ? I.check : '<span class="yr-dot" aria-hidden="true"></span>') + '<span>' + esc(f.title || id) + '</span></a></li>'; }).join('') + '</ol></nav>' : '';
    return sec('packet', head('packet', 'Parts', pv('packet/')) +
      (fc.length ? '<div class="yr-ask yr-ask--facts"><span><b>' + esc(SU.plural(fc.length, 'price') + (fc.length === 1 ? ' differs' : ' differ') + ' from Registration') + '</b></span><ul>' + fc.map((x, j) => '<li>' + esc(x.label + ': ' + x.was + ' in “' + x.part + '” · Registration says ' + x.to) + ' <button type="button" class="yr-link" data-fixfact="' + j + '">Use ' + esc(x.to) + '</button></li>').join('') + '</ul></div>' : '') +
      '<div class="yr-packet">' + contents + '<div class="yr-packet__doc">' + (ids.length ? '<p class="yr-addbetween is-first"><button type="button" class="yr-add" data-addpart="">' + I.plus + 'Add part</button></p>' + parts : '<div class="ws-blank"><p class="ws-blank__h">No parts yet</p><p class="ws-blank__btn"><button type="button" class="wk-btn wk-btn--line wk-btn--small" data-addpart="">' + I.plus + 'Add part</button></p></div>') + '</div></div>');
  }
  // The card's one action: a number to call, a text to send, or a link; its hours; its kind.
  function helpSec() {
    const h = state.cur.help, from = (pk().parts.help || {}).from;
    const blocks = h.map((c, i) => {
      const sms = /^sms:/i.test(c.link || ''), act = c.phone ? 'call' : sms ? 'text' : c.link ? 'link' : '', more = state.folds['help' + c._id];
      // A text is a number and a message, not a raw "sms:" link.
      const sm = sms ? String(c.link).match(/^sms:([^?]*)(?:\?(?:&)?body=(.*))?$/i) || [] : [];
      const smsBody = sm[2] ? (() => { try { return decodeURIComponent(sm[2]); } catch (x) { return sm[2]; } })() : '';
      return '<div class="yr-help' + (c.kind === 'emergency' ? ' is-emergency' : '') + '" data-help="' + i + '"><h3 contenteditable="plaintext-only" data-hi="' + i + '" data-hf="need" aria-label="Card title">' + esc(c.need) + '</h3>' +
        '<p contenteditable="plaintext-only" data-hi="' + i + '" data-hf="text" aria-label="What it says" data-empty="What it says">' + esc(c.text || '') + '</p>' +
        '<p class="yr-help__act">' + (act === 'call' ? '<span class="yr-lab-t">Call</span> ' + field('help.' + i + '.phone', c.phone || '', 'tel', c.need + ' phone')
          : act === 'text' ? '<span class="yr-lab-t">Text</span> ' + field('help.' + i + '.smsnum', sm[1] || '', 'tel', c.need + ' text number', { size: 10 }) + ' <span class="yr-lab-t">Message</span> ' + field('help.' + i + '.smsbody', smsBody, 'text', c.need + ' message', { size: 18 })
          : act === 'link' ? '<span class="yr-lab-t">Link</span> ' + field('help.' + i + '.link', c.link || '', 'text', c.need + ' link', { size: 24, ph: 'https://' })
          : '<span class="yr-dim">No action</span> <button type="button" class="yr-link" data-helpact="' + esc(c._id) + '">Add</button>') +
        (c.phone && (pk().confirm || []).indexOf('help:' + c._id) > -1 && !coa().checks['help:' + c._id] && !coa().checks['packet:help'] ? fromMark('help:' + c._id) : '') + '</p>' +
        '<details class="yr-fold yr-fold--more" data-fold="help' + esc(c._id) + '"' + (more ? ' open' : '') + '><summary>' + I.down + '<span>More</span></summary><div class="yr-more-in">' +
          '<p><span class="yr-lab-t">Kind</span> ' + pills('help.' + i + '.kind', c.kind === 'emergency' ? 'emergency' : '', [['', 'Usual'], ['emergency', 'Emergency']], 'Kind', 'data-hopt') + '</p>' +
          '<p><span class="yr-lab-t">Action</span> ' + pills('help.' + i + '.act', act, [['call', 'Call'], ['text', 'Text'], ['link', 'Link'], ['', 'None']], 'Action', 'data-hopt') + '</p>' +
          '<p><label class="yr-lab-t" for="yr-hours-' + i + '">Hours</label> <input class="yr-in" id="yr-hours-' + i + '" data-k="help.' + i + '.hours" data-kind="text" value="' + esc(c.hours || '') + '" size="22" placeholder="Fri 5 PM–11 PM" autocomplete="off"></p></div></details>' +
        '<button type="button" class="yr-del yr-del--block" data-delhelp="' + i + '" title="Remove">' + I.x + '<span class="ogc-sr">Remove ' + esc(c.need) + '</span></button></div>';
    }).join('');
    const phones = h.filter(c => c.phone && (pk().confirm || []).indexOf('help:' + c._id) > -1).map(c => 'help:' + c._id);
    return sec('help', head('help', 'Help during the week', pv('guide/?view=help')) + (from ? '<p class="yr-dim yr-kept" title="Kept with the campus">From ' + esc(from) + '</p>' : '') + '<div class="yr-helps">' + blocks + '</div>' +
      '<p class="yr-under"><button type="button" class="yr-link" data-addhelp>' + I.plus + 'Add card</button></p>' + looks('packet:help', 'the Help cards and their numbers', phones));
  }
  // Menus: nothing until the caterer's arrives (never last year's as a stand-in). It's pasted or
  // brought as a text or CSV file; reading a PDF or a photo needs a service the Advisors haven't decided on.
  function menuSec() {
    const m = state.cur.menus, dft = state.menuDraft;
    const byDay = rows => { const out = {}; rows.forEach(r => { ((out[r.day] = out[r.day] || {})[r.meal] = out[r.day][r.meal] || []).push(r); }); return out; };
    const view = (rows, draft) => {
      const b = byDay(rows);
      return '<div class="yr-menu' + (draft ? ' is-draft' : '') + '">' + Object.keys(b).sort((a, c) => dayIdx(a) - dayIdx(c)).map(day => '<div><h3>' + esc(day) + '</h3>' +
        Object.keys(b[day]).map(meal => '<p><b>' + esc(meal) + '</b> ' + b[day][meal].map(r => (r.station ? '<i>' + esc(r.station) + ':</i> ' : '') + esc(r.items)).join(' · ') + '</p>').join('') + '</div>').join('') + '</div>';
    };
    let body;
    if (dft) body = '<p class="yr-ask"><span>' + esc('From ' + dft.name + ': ' + SU.plural(dft.rows.length, 'line') + ' · ' + SU.plural(Object.keys(byDay(dft.rows)).length, 'day')) + '</span><button type="button" class="yr-keepall" data-menuuse>' + I.check + 'Use this menu</button><button type="button" class="yr-link" data-menudrop>Cancel</button></p>' + view(dft.rows, true);
    else if (m.length) body = view(m) + '<p class="yr-under"><button type="button" class="yr-link" data-menupaste>' + I.edit + 'Paste a newer menu</button><button type="button" class="yr-link" data-bring>' + I.upload + 'Choose a file</button></p>';
    else body = '<div class="yr-wait"><p class="yr-wait__h">' + I.clock + 'Waiting for the caterer’s menu</p><p>Paste it, or choose a text or CSV file</p>' +
      '<p class="yr-btns"><button type="button" class="wk-btn wk-btn--line wk-btn--small" data-menupaste>' + I.edit + 'Paste</button><button type="button" class="yr-link" data-bring>' + I.upload + 'Choose a file</button>' + (DEV ? '<button type="button" class="ogc-mock" data-mockmenu>Mockup: a sample menu</button>' : '') + '</p></div>';
    if (state.open === 'menupaste') body += '<form class="yr-paste" data-menupasteform><label for="yr-menu-in">The menu, as the caterer sent it</label><textarea id="yr-menu-in" rows="8" placeholder="FRIDAY&#10;Supper&#10;Main: Baked chicken, green beans"></textarea><p class="yr-btnrow"><button type="submit" class="wk-btn wk-btn--line wk-btn--small">Read it</button><button type="button" class="yr-link" data-open="">Cancel</button></p></form>';
    return sec('menus', head('menus', 'Menus', m.length ? pv('packet/') : '') + body);
  }

  /* ------------------------------------------------------------ Volunteer shifts, Young Folks */

  // A shift with no number of people ("any") is open to all: counted apart, never as "13 of 0".
  const openToAll = r => !/^\d+$/.test(String(r.needed || '').trim()) || +r.needed === 0;
  const daysOf = r => Math.max(1, (DAYS.indexOf(r.last_day) - DAYS.indexOf(r.day) + 1) || 1);
  const placesOf = rs => rs.filter(r => !openToAll(r)).reduce((k, r) => k + (+r.needed || 0) * daysOf(r), 0);
  // How full a committee's shifts are: sign-ups by the shift's lasting uid (the volunteer area's).
  function fillOf(rs) {
    const n = counts().shifts || {};
    let f = 0, any = 0;
    rs.forEach(r => { const k = r.uid ? n[r.uid] || 0 : 0; if (openToAll(r)) any += k; else f += k; });
    return { filled: f, any, places: placesOf(rs), allAny: rs.length > 0 && rs.every(openToAll) };
  }
  function shiftsSec() {
    const sh = state.cur.shifts, S = state.cur.S, own = S.tool_helping === 'own', ps = pubOf('helping'), pub = ps.on;
    const coms = Array.from(new Set(sh.map(r => r.committee).filter(Boolean)));
    const tool = ['Tool', pills('tool_helping', own ? 'own' : 'site', [['site', 'This site'], ['own', 'Another tool']], 'Volunteer sign-ups tool', 'data-sopt') + (own ? '<br>' + field('volunteer_url', S.volunteer_url || '', 'text', 'Link to the sign-ups', { size: 34, ph: 'https://' }) + help('The Volunteer button goes there') : '')];
    if (own) return sec('shifts', facts([tool]));
    // Names on the volunteer page are the Advisors' call: shown, not chosen here.
    const names = ['Names', '<span class="yr-val-t">' + (S.volunteer_names === 'count' ? 'Count only' : 'First L.') + '</span> <small class="yr-dim" title="Whether the volunteer page shows names is the Website Advisors’ decision">Pending the Advisors</small>' + help('On the volunteer page · Committee heads always see names')];
    // Open or closed, and the way to close: here, beside what it closes (not in the bar).
    const open = pub ? ['Sign-ups', '<span class="yr-val-t">' + esc(ps.closed ? 'Closed ' + mdY(ps.closed) : 'Open since ' + mdY(ps.when)) + '</span> <button type="button" class="yr-link" data-panel="helping">' + (ps.closed ? 'Reopen' : 'Close') + '</button>'] : null;
    const cell = f => pub ? (f.allAny ? esc(f.any + ' · open to all') : '<span class="yr-meter" aria-hidden="true"><i style="width:' + Math.min(100, Math.round(f.filled / Math.max(1, f.places) * 100)) + '%"></i></span>' + esc(f.filled + ' of ' + f.places) + (f.any ? ' <small class="yr-dim">· ' + esc(f.any + ' open to all') + '</small>' : ''))
      : f.allAny ? 'Open to all' : String(f.places);
    const short = (rs, f) => SU.plural(rs.length, 'shift') + ' · ' + (pub ? (f.allAny ? f.any + ' · open to all' : f.filled + ' of ' + f.places) : f.allAny ? 'open to all' : SU.plural(f.places, 'place'));
    return sec('shifts', head('shifts', 'Volunteer shifts', pv('volunteer/')) + facts([tool, names, open]) +
      (coms.length ? '<table class="yr-list yr-shiftlist"><thead><tr><th scope="col">Committee</th><th scope="col" class="is-num">Shifts</th><th scope="col" class="is-num">' + (pub ? 'Filled' : 'Places') + '</th><th scope="col">Checked</th><th scope="col"><span class="ogc-sr">Open</span></th></tr></thead><tbody>' +
        coms.map(c => {
          const rs = sh.filter(r => r.committee === c), f = fillOf(rs), ck = coa().checks['shifts:' + c];
          return '<tr><th scope="row">' + esc(c) + (onList(c) ? '' : ' <small class="yr-q" title="Not on the committee list">?</small>') + '<small class="yr-shiftlist__m">' + esc(short(rs, f)) + '</small></th><td class="is-num">' + rs.length + '</td><td class="is-num">' + cell(f) + '</td>' +
            '<td>' + (ck ? '<span class="yr-okline" title="' + esc(md(ck.at)) + '">' + I.check + esc(ck.by || '') + '</span> <button type="button" class="yr-link" data-look="shifts:' + esc(c) + '" data-done="" data-part2="helping">Undo</button>' : '<button type="button" class="yr-keep" data-look="shifts:' + esc(c) + '" data-done="1" data-part2="helping">' + I.check + 'Looks right</button>') + '</td>' +
            '<td class="yr-list__go"><a class="yr-link" href="' + esc(editHref('shifts:' + c, 'helping')) + '">' + I.edit + 'Edit</a>' + (pub ? '<a class="yr-link" href="../volunteer/?year=' + y() + '&view=lead&committee=' + encodeURIComponent(c) + '">Sign-ups</a>' : '') + '</td></tr>';
        }).join('') + '</tbody></table>' : '<div class="ws-blank"><p class="ws-blank__h">No shifts yet</p></div>') +
      '<p class="yr-under"><a class="yr-add" href="' + esc(editHref('shifts', 'helping')) + '">' + I.plus + 'Add committee</a>' + outLink('shifts') + '</p>');
  }
  function tourSec() {
    const S = state.cur.S, on = (S.tournaments_online || '') !== 'no';
    return sec('tournaments', head('tournaments', 'Young Folks tournaments', pv('tournaments/')) +
      facts([['Sign-ups', pills('tournaments_online', on ? 'yes' : 'no', [['yes', 'Online'], ['no', 'Not online']], 'Tournament sign-ups', 'data-sopt') + help(on ? 'Teams sign up on the site' : 'The site shows times and places only')]]) +
      sheet('tournaments') + '<p class="yr-under">' + outLink('tournaments') + '</p>' + looks('yf:tournaments', 'the tournaments, team sizes and closing times'));
  }
  const teamsFor = id => (counts().teams || {})[id] || 0;

  /* ------------------------------------------------------------ Requests to the campus */

  // Oct 8, Michael: the equipment requests "come from all the committees and are a process to round
  // up". Each committee's rows from the last Conference at this campus, grouped the way committees and
  // the venue think of them, by event ("Preteen devotions · Fri 7–8 PM · PPAC Auditorium"), each item
  // answered Keep, Not sure or Remove, or edited (Change). Every answer is stamped with who and when.
  const ANSWER = { keep: 'Kept', change: 'Changed', remove: 'Removed', notsure: 'Not sure', new: 'New' };
  const ANSWER_IN = { keep: 'keep', kept: 'keep', yes: 'keep', change: 'change', changed: 'change', remove: 'remove', removed: 'remove', drop: 'remove', no: 'remove', 'not sure': 'notsure', notsure: 'notsure', '?': 'notsure', new: 'new', add: 'new' };
  const needsLeft = (rows) => (rows || state.cur.needs).filter(r => !r.answer).length;
  const needsUnsure = (rows) => (rows || state.cur.needs).filter(r => r.answer === 'notsure').length;
  // "RWC 137/242" → building RWC, room 137/242; "Chapel Auditorium" → the building alone.
  const splitWhere = w => { const m = String(w || '').trim().match(/^(.*?)\s+(\d[\w/-]*)$/); return m ? { building: m[1], room: m[2] } : { building: String(w || '').trim(), room: '' }; };
  const needWhere = r => [r.building, r.room].filter(Boolean).join(' ');
  const needDays = r => r.last_day && r.last_day !== r.first_day ? r.first_day + '–' + r.last_day : (r.first_day || '');
  const shortDays = r => !r.first_day ? '' : r.last_day && r.last_day !== r.first_day ? r.first_day.slice(0, 3) + '–' + r.last_day.slice(0, 3) : r.first_day.slice(0, 3);
  const needTime = r => { const a = O.parseTime(r.start), b = O.parseTime(r.end); return a != null && b != null ? O.formatRange(a, b <= a ? b + 1440 : b) : a != null ? O.formatTime(a) : ''; };
  const eventKey = r => [r.for, r.first_day, r.last_day, r.start, r.end, r.building, r.room].map(x => String(x || '').trim().toLowerCase()).join('|');
  function needsCommittees() {
    const all = state.cur.needs, names = Array.from(new Set(all.map(r => r.committee).filter(Boolean)));
    const order = committeeNames().map(c => c.toLowerCase());
    return names.sort((a, b) => { const i = order.indexOf(a.toLowerCase()), j = order.indexOf(b.toLowerCase()); return (i < 0 ? 999 : i) - (j < 0 ? 999 : j) || a.localeCompare(b); });
  }
  const contactOf = c => (state.cur.committees.find(x => x.name.toLowerCase() === String(c).toLowerCase()) || {}).contact_email || '';
  // A request's fingerprint, as the server makes it (what the campus would set up from it).
  const hash = t => { let h = 5381; String(t).split('').forEach(c => { h = ((h << 5) + h + c.charCodeAt(0)) | 0; }); return (h >>> 0).toString(36); };
  const needFp = r => hash(['item', 'qty', 'for', 'first_day', 'last_day', 'start', 'end', 'building', 'room', 'notes'].map(k => String(r[k] == null ? '' : r[k]).trim()).join('|'));
  function sinceSent() {
    const s = coa().sent.needs;
    if (!s) return null;
    const out = { added: [], changed: [], removed: [] }, now = {};
    state.cur.needs.filter(r => r.answer !== 'remove' && r.id).forEach(r => { now[r.id] = 1; if (!(r.id in s.rows)) out.added.push(r); else if (s.rows[r.id] !== needFp(r)) out.changed.push(r); });
    Object.keys(s.rows).forEach(id => { if (!now[id]) out.removed.push(state.cur.needs.find(r => r.id === id) || { id }); });
    out.n = out.added.length + out.changed.length + out.removed.length;
    return out;
  }

  // Answering, on the server (stamped there); shown here at once.
  function answerNeeds(rows, answer, extra) {
    if (!rows.length) return Promise.resolve();
    const me = state.ov.me || {}, ops = rows.map(r => Object.assign({ id: r.id, answer }, extra && extra.fields ? { fields: extra.fields } : {}, extra && extra.question != null ? { question: extra.question } : {}));
    rows.forEach(r => { r.answer = answer; r.answered_by = answer ? me.name : ''; r.answered_as = answer ? me.committee : ''; r.answered_at = answer ? today() : ''; if (extra && extra.fields) Object.assign(r, extra.fields); if (extra && extra.question != null) r.question = extra.question; });
    return sendNeeds({ ops });
  }
  function sendNeeds(body) {
    return call('POST', 'needs', body).then(d => { takeNeeds(d.rows); return d; }, e => { toast('Not saved · ' + (e.message || 'Retry')); refreshNeeds(); throw e; });
  }
  // The server's rows (theirs and mine): taken in without moving whatever is being typed.
  function takeNeeds(rows) {
    if (!Array.isArray(rows)) return;
    const typing = document.activeElement && root.contains(document.activeElement) && document.activeElement.closest('.yr-neededit');
    if (typing) return;
    state.cur.needs = rows.map(r => Object.assign({}, r));
    base.needs = JSON.stringify(state.cur.needs);
    redraw('needs'); chrome();
  }
  const refreshNeeds = () => api('GET', 'years/' + state.year + '/files/needs?format=json').then(d => takeNeeds(d.rows), () => {});

  function answerHtml(r) {
    if (r.answer && ANSWER[r.answer]) {
      const coaSaid = r.answered_as !== undefined && r.answered_by && (!r.answered_as || r.answered_as.toLowerCase() !== String(r.committee || '').toLowerCase());
      return '<span class="yr-ans is-' + r.answer + '">' + (r.answer === 'remove' ? I.x : r.answer === 'notsure' ? I.phone : I.check) + esc(ANSWER[r.answer]) + '</span>' +
        '<small class="yr-ans__by">' + esc([r.answered_by, md(r.answered_at)].filter(Boolean).join(' · ') + (coaSaid ? ' · for the committee' : '')) + '</small>' +
        '<button type="button" class="yr-link" data-answer="" title="Answer again">Change</button>';
    }
    return '<button type="button" class="yr-ansbtn is-keep" data-answer="keep">' + I.check + 'Keep</button><button type="button" class="yr-ansbtn" data-answer="notsure">Not sure</button><button type="button" class="yr-ansbtn is-remove" data-answer="remove">' + I.x + 'Remove</button>';
  }
  const SUPPLIED = () => Array.from(new Set(state.cur.needs.map(r => r.supplied_by).filter(Boolean).concat(['We bring'])));
  function needEditForm(r, isEvent) {
    const f = (k, label, v, o) => '<label class="yr-ne"><span>' + esc(label) + '</span><input class="yr-in" name="' + k + '" value="' + esc(v || '') + '"' + (o || '') + ' autocomplete="off"></label>';
    return '<form class="yr-neededit" data-needform="' + esc(isEvent ? 'ev:' + eventKey(r) : r.id) + '">' +
      (isEvent ? '' : f('item', 'Item', r.item) + f('qty', 'Qty', r.qty, ' inputmode="numeric" size="4"')) +
      f('for', 'Used for', r.for) + f('days', 'Days', needDays(r), ' placeholder="Friday–Tuesday"') + f('start', 'Start', r.start, ' placeholder="8:00 AM" size="9"') + f('end', 'End', r.end, ' placeholder="9:00 PM" size="9"') +
      f('where', 'Where', needWhere(r), ' list="yr-places-list"') +
      (isEvent ? '' : '<p class="yr-ne"><span>From</span>' + pills('supplied_by', r.supplied_by || '', SUPPLIED().map(s => [s, s.replace(/^IWU |^Cedarville /, '')]), 'Supplied by', 'data-nsup') + '</p>' + f('notes', 'Notes', r.notes)) +
      '<p class="yr-btnrow"><button type="submit" class="wk-btn wk-btn--line wk-btn--small">Save</button><button type="button" class="yr-link" data-neededit="">Cancel</button></p></form>';
  }
  // Words compared loosely: case, "×"/"x", 8' and 8ft, plurals, one slip of a letter ("Easles").
  const lev = (a, b) => { if (Math.abs(a.length - b.length) > 2) return 9; const d = Array.from({ length: b.length + 1 }, (_, i) => i); for (let i = 1; i <= a.length; i++) { let pr = d[0]; d[0] = i; for (let j = 1; j <= b.length; j++) { const t = d[j]; d[j] = Math.min(d[j] + 1, d[j - 1] + 1, pr + (a[i - 1] === b[j - 1] ? 0 : 1)); pr = t; } } return d[b.length]; };
  const loose = x => String(x || '').toLowerCase().replace(/×/g, ' x ').replace(/(\d+)\s*(?:ft\b|feet\b|foot\b|'|’)/g, '$1 ').replace(/[^a-z0-9]+/g, ' ').trim();
  const sing = w => w.length > 3 ? w.replace(/ies$/, 'y').replace(/(?:es|s)$/, '') : w;
  // Does a request's detail only say its item again ("6 Seater Golf Cart x 7" for "Golf Cart – 6 seater", 7)?
  function restates(detail, item, qty) {
    const toks = x => loose(x).split(' ').filter(w => w && w !== 'x' && w !== 'or' && w !== 'and' && w !== String(qty || '')).map(sing);
    const a = toks(detail), b = toks(item);
    if (!a.length) return true;
    if (a.every(w => b.some(v => w === v || (w.length >= 4 && v.length >= 4 && lev(w, v) <= 1)))) return true;
    const ja = a.join(''), jb = b.join('');
    return ja === jb || jb.indexOf(ja) > -1;
  }
  // A committee's name as the year has it ("PreTeen", "YF" → Preteens, Young Folks).
  const ALIAS = { yf: 'young folks', pt: 'preteens' };
  function comCanon(n) {
    const t = ALIAS[loose(n)] || loose(n);
    return committeeNames().find(c => loose(c) === t || sing(loose(c)) === sing(t)) || '';
  }
  // "1-Nursery, 2-PreTeen · 6-Transportation" → "For Nursery 1 · Preteens 2 · Transportation 6" (each once).
  function forLine(t) {
    const bits = String(t || '').split(/[,;·]+/).map(x => x.trim()).filter(Boolean), seen = {}, out = [];
    if (!bits.length) return '';
    for (const x of bits) {
      const m = x.match(/^(\d+)\s*-\s*(.+)$/);
      if (!m) return '';
      const c = comCanon(m[2]) || m[2].trim();
      if (!seen[c.toLowerCase()]) { seen[c.toLowerCase()] = 1; out.push(c + ' ' + m[1]); }
    }
    return 'For ' + out.join(' · ');
  }
  // A request names a building as the campus does ("PPAC", "BSC", "Chapel Auditorium"): matched by
  // name, code, or the name's initials; the campus itself ("IWU", "All week") is a place too. Only
  // what isn't a building here is asked about.
  function placeKnown(text) {
    const t = String(text).toLowerCase().trim(), first = t.split(/[\s/-]+/)[0];
    const ini = n => String(n || '').replace(/&|\band\b|\bof\b/gi, ' ').split(/\s+/).filter(Boolean).map(w => w[0]).join('').toLowerCase();
    const venue = state.cur.S.venue || state.row.venue || '';
    if (/^(campus|all week|everywhere|all over campus)$/.test(t) || (venue && (t === venue.toLowerCase() || t === ini(venue)))) return true;
    return state.cur.places.some(p => [p.name, p.building].some(n => { const l = String(n || '').toLowerCase(); return l && (t.indexOf(l) > -1 || l.indexOf(t) > -1 || ini(n) === first || l.split(/\s+/)[0] === first); }) || String(p.code || '').toLowerCase() === first);
  }
  function needItem(r, evSup) {
    const cls = ['yr-need', r.answer ? 'is-' + r.answer : 'is-open', r.answer === 'new' ? 'is-new' : ''].join(' ');
    // What it adds to the item, said once: no restated item, a breakdown by committee as one line.
    const detail = r.detail && !restates(r.detail, r.item, r.qty) ? r.detail : '';
    const notes = forLine(r.notes) || String(r.notes || '').replace(/^[\s,;·]+|[\s,;·]+$/g, '');
    const sup = r.supplied_by && r.supplied_by !== evSup ? ' <small class="yr-need__from">' + esc(r.supplied_by.replace(/^IWU |^Cedarville /, '')) + '</small>' : '';
    return '<li class="' + cls + '" data-nid="' + esc(r.id) + '"><div class="yr-need__main"><p class="yr-need__item"><b>' + esc(r.item) + '</b> <span class="yr-need__qty">× ' + esc(r.qty || '1') + '</span>' + sup + '</p>' +
      (detail || notes ? '<p class="yr-need__note">' + esc([detail, notes].filter(Boolean).join(' · ')) + '</p>' : '') +
      (r.answer === 'notsure' && r.question ? '<p class="yr-need__q">“' + esc(r.question) + '”</p>' : '') + '</div>' +
      '<div class="yr-need__ans">' + answerHtml(r) + (r.answer !== 'remove' ? '<button type="button" class="yr-link" data-neededit="' + esc(r.id) + '">Edit</button>' : '') + '</div>' +
      (state.askNeed === r.id ? '<form class="yr-needask" data-needask="' + esc(r.id) + '"><label for="yr-q-' + esc(r.id) + '">What’s unclear?</label><input class="yr-in" id="yr-q-' + esc(r.id) + '" name="q" value="' + esc(r.question || '') + '" autocomplete="off"><button type="submit" class="wk-btn wk-btn--line wk-btn--small">Save</button><button type="button" class="yr-link" data-needask="">Skip</button></form>' : '') +
      (state.editNeed === r.id ? needEditForm(r) : '') + '</li>';
  }
  function needEvents(c) {
    const rows = state.cur.needs.filter(r => r.committee === c), groups = [];
    rows.forEach(r => { const k = eventKey(r); let g = groups.find(x => x.k === k); if (!g) groups.push(g = { k, rows: [] }); g.rows.push(r); });
    groups.sort((a, b) => dayIdx(a.rows[0].first_day) - dayIdx(b.rows[0].first_day) || (O.parseTime(a.rows[0].start) || 0) - (O.parseTime(b.rows[0].start) || 0));
    return groups.map(g => {
      const r = g.rows[0], left = g.rows.filter(x => !x.answer), when = [shortDays(r) || '', needTime(r)].filter(Boolean).join(' ');
      // Questions are asked once, on the event, in the accent colour (red is for errors).
      const place = r.building && state.cur.places.length && !placeKnown(r.building) ? ' <small class="yr-q" title="Not a building at this campus">Place?</small>' : '';
      const sups = Array.from(new Set(g.rows.map(x => x.supplied_by || ''))), evSup = sups.length === 1 ? sups[0] : '';
      return '<section class="yr-ev"><header class="yr-ev__h"><div><p class="yr-ev__t">' + esc(r.for || 'All week') + '</p>' +
        '<p class="yr-ev__m">' + (when ? esc(when) : '<i class="yr-q">Which days?</i>') + (needWhere(r) ? ' · ' + esc(needWhere(r)) : '') + place + (evSup ? ' · ' + esc(evSup.replace(/^IWU |^Cedarville /, '')) : '') + '</p></div>' +
        '<p class="yr-ev__acts">' + (left.length > 1 ? '<button type="button" class="yr-keep" data-keepev="' + esc(g.k) + '">' + I.check + 'Keep ' + left.length + '</button>' : '') + '<button type="button" class="yr-link" data-neededit="ev:' + esc(g.k) + '" title="Change the event’s days, time or place for every item in it">Edit event</button></p></header>' +
        (state.editNeed === 'ev:' + g.k ? needEditForm(r, true) : '') +
        '<ul class="yr-ev__items">' + g.rows.map(x => needItem(x, evSup)).join('') + '</ul>' +
        '<p class="yr-ev__add"><button type="button" class="yr-add" data-addneed="' + esc(g.k) + '">' + I.plus + 'Add item</button></p></section>';
    }).join('');
  }
  function statusCell(rows) {
    const l = needsLeft(rows), ns = needsUnsure(rows), done = rows.length - l;
    return (!done ? '<span>' + esc(rows.length + ' to answer') + '</span>' : l ? '<span class="yr-meter" aria-hidden="true"><i style="width:' + Math.round(done / rows.length * 100) + '%"></i></span>' + esc(done + ' of ' + rows.length) : '<span class="yr-okline">' + I.check + 'Done</span>') +
      (ns ? ' · <span class="yr-left">' + ns + ' not sure</span>' : '');
  }
  function uploadPreview() {
    const u = state.upload;
    if (!u) return '';
    const lines = Object.keys(u.per).map(c => { const x = u.per[c]; return '<li><b>' + esc(c) + '</b>: ' + esc([x.changed && x.changed + ' changed', x.added && x.added + ' new', x.keep && x.keep + ' kept', x.notsure && x.notsure + ' not sure', x.remove && x.remove + ' removed'].filter(Boolean).join(', ') || 'no changes') + '</li>'; }).join('');
    const chg = u.changes.slice(0, 12).map(x => '<li>' + esc(x.label) + ': ' + x.diffs.map(d => esc(d.k + ' ' + (d.to || '—')) + ' <small class="yr-was">was ' + esc(d.from || '—') + '</small>').join(', ') + '</li>').join('');
    // The nearest name first; adding a new committee last.
    const unknown = Object.keys(u.unknown).map(n => { const nr = (u.near || {})[n], names = (nr ? [nr] : []).concat(committeeNames().filter(c => c !== nr)).slice(0, 14); return '<li>' + esc(n) + ' · ' + pills('upcom:' + n, u.unknown[n], names.map(c => [c, c]).concat([[n, 'Add ' + n]]), 'Which committee for ' + n, 'data-upcom') + '</li>'; }).join('');
    const missing = u.missing.map(r => '<li><label class="yr-chk"><input type="checkbox" data-upmiss="' + esc(r.id) + '"' + (u.drop[r.id] ? ' checked' : '') + '> ' + esc(r.committee + ' · ' + r.item + (r.for ? ' · ' + r.for : '')) + '</label></li>').join('');
    return '<div class="yr-upload" role="region" aria-label="Upload"><p class="yr-upload__h"><b>' + esc('From ' + u.file) + '</b></p><ul>' + lines + '</ul>' +
      (chg ? '<p class="yr-dim">Changed</p><ul class="yr-upload__chg">' + chg + (u.changes.length > 12 ? '<li>' + esc('and ' + (u.changes.length - 12) + ' more') + '</li>' : '') + '</ul>' : '') +
      (unknown ? '<p class="yr-dim">Which committee?</p><ul>' + unknown + '</ul>' : '') +
      (missing ? '<p class="yr-dim">Not in the file · Remove?</p><ul>' + missing + '</ul>' : '') +
      '<p class="yr-btnrow"><button type="button" class="wk-btn wk-btn--line wk-btn--small" data-upgo>Apply</button><button type="button" class="yr-link" data-upcancel>Cancel</button></p></div>';
  }
  function needsSec() {
    const all = state.cur.needs, from = (pk().parts.needs || {}).from, S = state.cur.S, own = S.tool_requests === 'own';
    const tool = ['Tool', pills('tool_requests', own ? 'own' : 'site', [['site', 'This site'], ['own', 'Another tool']], 'Requests tool', 'data-sopt') + (own ? '<br>' + field('requests_url', S.requests_url || '', 'text', 'Link to the sheet', { size: 34, ph: 'https://' }) + help('Where committees answer this year · Import its sheet here when it’s done') : '')];
    if (!all.length) return sec('needs', facts([tool]) + uploadPreview() + '<div class="ws-blank"><p class="ws-blank__h">No requests yet</p><p class="ws-blank__p">A new campus starts blank · Upload a filled-in sheet, or add a committee’s first request</p><p class="ws-blank__btn"><button type="button" class="wk-btn wk-btn--line wk-btn--small" data-bring>' + I.upload + 'Upload</button></p></div>');
    const coms = needsCommittees(), open = state.needsOpen, ss = sinceSent(), sent = coa().sent.needs;
    const sentLine = sent ? '<p class="yr-sentline">' + I.check + esc('Sent ' + mdY(sent.at) + ' · ' + (sent.by || '')) + (ss && ss.n ? ' · <b>' + esc(SU.plural(ss.n, 'change') + ' since') + '</b> <button type="button" class="yr-link" data-campus="changes">' + I.download + 'Export changes</button>' : '') + '</p>' : '';
    const unsure = all.filter(r => r.answer === 'notsure');
    const calls = unsure.length ? '<div class="yr-calls"><p class="yr-calls__h">Not sure · ' + unsure.length + '</p><ul>' + unsure.map(r => '<li><b>' + esc(r.committee) + '</b> · ' + esc(r.item) + (r.question ? ' · “' + esc(r.question) + '”' : '') + ' <small class="yr-dim">' + esc([r.answered_by, contactOf(r.committee)].filter(Boolean).join(' · ')) + '</small></li>').join('') + '</ul></div>' : '';
    const list = '<ul class="yr-coml">' + coms.map(c => {
      const rs = all.filter(r => r.committee === c), isOpen = open === c;
      return '<li class="' + (isOpen ? 'is-open' : '') + '"><button type="button" class="yr-coml__b" data-needopen="' + esc(isOpen ? '' : c) + '" aria-expanded="' + isOpen + '"><span class="yr-coml__n">' + esc(c) + (onList(c) ? '' : ' <small class="yr-q" title="Not on the committee list">?</small>') + '</span><span class="yr-coml__s">' + statusCell(rs) + '</span>' + (isOpen ? I.chevUp : I.down) + '</button>' +
        (isOpen ? openCommittee(c, rs) : '') + '</li>';
    }).join('') + '</ul>';
    // Template and Upload live in each committee's own list; one Template for everyone sits under the list.
    return sec('needs', facts([tool]) + sentLine + uploadPreview() +
      (from ? '<p class="yr-dim yr-kept">' + esc('What each committee asked for at ' + (state.cur.S.venue || 'this campus') + ' in ' + from) + '</p>' : '') +
      calls + '<div class="yr-comlhead" aria-hidden="true"><span>Committee</span><span>Status</span></div>' + list +
      '<p class="yr-under"><button type="button" class="yr-link" data-needtpl="" title="Every committee’s rows in one Excel sheet, with an Answer column">' + I.sheet + 'Template for everyone</button><button type="button" class="yr-link" data-bring title="A filled-in Template (Excel or CSV)">' + I.upload + 'Upload</button></p>' + stockSec());
  }
  function openCommittee(c, rs) {
    const l = needsLeft(rs);
    return '<div class="yr-needrows">' +
      '<p class="yr-needrows__top">' + (l ? '<button type="button" class="yr-keepall yr-keepall--wide" data-keepcom="' + esc(c) + '">' + I.check + (l === rs.length ? 'Keep all ' + l : 'Keep the other ' + l) + '</button>' : '') +
      '<button type="button" class="yr-link" data-needtpl="' + esc(c) + '">' + I.sheet + 'Template</button><button type="button" class="yr-link" data-bring>' + I.upload + 'Upload</button>' +
      (contactOf(c) ? '<small class="yr-dim">' + esc(contactOf(c)) + '</small>' : '') + '</p>' +
      needEvents(c) + '<p class="yr-ev__add"><button type="button" class="yr-add" data-addevent="' + esc(c) + '">' + I.plus + 'Add event</button></p></div>';
  }
  // What the campus needs on hand: the most of each item in use at one time, each day (two sessions
  // that use the same mic at noon and at 5 PM need one, not two). "We bring" isn't the campus's.
  function stock() {
    const days = (state.cur.S.days || 'Friday|Saturday|Sunday|Monday|Tuesday').split('|').filter(d => d !== 'Wednesday' || true), out = {}, ours = {};
    let noDay = 0;
    state.cur.needs.filter(r => r.answer !== 'remove' && r.item).forEach(r => {
      const a = days.indexOf(r.first_day), b = r.last_day ? days.indexOf(r.last_day) : a, qn = +r.qty || 1;
      if (a < 0) { noDay++; return; }
      const into = /we bring/i.test(r.supplied_by || '') ? ours : out;
      const s = O.parseTime(r.start), e = O.parseTime(r.end), span = s != null && e != null ? [s, e <= s ? e + 1440 : e] : [0, 1440];
      for (let i = a; i <= Math.max(a, b); i++) ((into[r.item] = into[r.item] || days.map(() => []))[i]).push([span[0], span[1], qn]);
    });
    const peak = list => { const ev = []; list.forEach(([s, e, n]) => { ev.push([s, n], [e, -n]); }); ev.sort((x, y) => x[0] - y[0] || x[1] - y[1]); let c = 0, m = 0; ev.forEach(([, n]) => { c += n; m = Math.max(m, c); }); return m; };
    const rowsOf = o => Object.keys(o).sort().map(k => { const n = o[k].map(peak); return { item: k, n, most: Math.max.apply(null, n) }; }).filter(x => x.most > 0);
    return { days, rows: rowsOf(out), ours: rowsOf(ours), noDay };
  }
  function stockSec() {
    const st = stock();
    if (!st.rows.length) return '';
    const table = rows => '<div class="yr-sheetwrap"><table class="yr-sheet yr-stock"><thead><tr><th scope="col">Item</th>' + st.days.map(x => '<th scope="col" class="yr-w-num">' + esc(x.slice(0, 3)) + '</th>').join('') + '<th scope="col" class="yr-w-num">Most</th></tr></thead><tbody>' +
      rows.map(x => '<tr><th scope="row">' + esc(x.item) + '</th>' + x.n.map(k => '<td class="yr-w-num">' + (k || '<span class="yr-dim">·</span>') + '</td>').join('') + '<td class="yr-w-num"><b>' + x.most + '</b></td></tr>').join('') + '</tbody></table></div>';
    return '<details class="yr-fold" data-fold="stock"' + (state.folds.stock ? ' open' : '') + '><summary>' + I.down + '<span>Most at once, by day · ' + esc(SU.plural(st.rows.length, 'item')) + '</span></summary>' +
      (st.noDay ? '<p class="yr-err">' + esc(SU.plural(st.noDay, 'request') + ' · day to set') + '</p>' : '') + table(st.rows) +
      (st.ours.length ? '<p class="yr-dim">We bring</p>' + table(st.ours) : '') + '</details>';
  }

  /* ------------------------------------------------------------ files out (Excel) and back */

  const fileSlug = s => String(s).toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
  function saveXlsx(sheets, name) {
    if (!O.xlsx) { SU.save('﻿' + SU.csv(sheets[0].rows), 'text/csv', name + '.csv'); return; }
    // Every cell is text, and one typed like a formula is written with an apostrophe first.
    const safe = v => { v = String(v == null ? '' : v); return /^[=+\-@\t\r]/.test(v) && !/^-?\d+(\.\d+)?$/.test(v) ? "'" + v : v; };
    const blob = O.xlsx.write(sheets.map(s => Object.assign({}, s, { rows: s.rows.map(r => r.map(safe)) })));
    const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = name + '.xlsx'; document.body.appendChild(a); a.click(); setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 1000);
  }
  // The Template (Oct 8, Michael: "a template spreadsheet that you can download and then re-upload in
  // the same format and it will basically fill it out"): each row keeps its ID, so it comes back to the
  // same row; empty rows at each committee's end are for new items.
  const TPL = ['ID', 'Committee', 'Used for', 'Item', 'Qty', 'Where', 'Days', 'Start', 'End', 'From', 'Answer', 'Notes'];
  function needsTemplate(c) {
    const coms = c ? [c] : needsCommittees(), rows = [TPL];
    coms.forEach(cm => {
      state.cur.needs.filter(r => r.committee === cm).forEach(r => rows.push([r.id || '', cm, r.for || '', r.item || '', r.qty || '', needWhere(r), needDays(r), r.start || '', r.end || '', r.supplied_by || '', r.answer ? ({ keep: 'Keep', change: 'Change', remove: 'Remove', notsure: 'Not sure', new: 'New' })[r.answer] : '', r.notes || '']));
      for (let i = 0; i < 3; i++) rows.push(['', cm, '', '', '', '', '', '', '', '', '', '']);
    });
    const how = [['How to fill it in'], ['Answer each row: Keep · Change (and change the row) · Remove · Not sure'], ['A new item: an empty row with its committee, Answer New'], ['Leave the ID as it is · Save, then Upload it on the year page'], ['Downloaded ' + today()]];
    saveXlsx([{ name: 'Requests', rows, widths: [7, 16, 22, 26, 5, 18, 18, 10, 10, 16, 10, 30] }, { name: 'How to fill it in', rows: how, widths: [70], bold: true }], 'requests ' + (c ? fileSlug(c) + ' ' : '') + state.year);
    toast('Downloaded · Upload it back here');
  }
  // A filled-in Template (Excel or CSV): matched by ID first, then by committee, item, used for, day
  // and start time, never one row twice. Nothing is applied until Apply.
  function planUpload(all, file) {
    if (all.length < 2) return false;
    const head = all[0].map(h => String(h || '').trim().toLowerCase()), at = (...hs) => { for (const h of hs) { const i = head.indexOf(h); if (i > -1) return i; } return -1; };
    if (at('item') < 0 || at('committee') < 0) return false;
    const col = { id: at('id'), committee: at('committee'), for: at('used for', 'for'), item: at('item'), qty: at('qty'), where: at('where'), days: at('days'), start: at('start'), end: at('end'), from: at('from', 'supplied by'), answer: at('answer'), notes: at('notes') };
    const v = (row, k) => col[k] > -1 ? String(row[col[k]] == null ? '' : row[col[k]]).trim() : null;
    const norm = x => String(x || '').trim().toLowerCase().replace(/\s+/g, ' ');
    const used = new Set(), u = { file, per: {}, ops: [], add: [], changes: [], missing: [], drop: {}, unknown: {}, coms: new Set() };
    const bump = (c, k) => { const p = u.per[c] = u.per[c] || {}; p[k] = (p[k] || 0) + 1; };
    const r0 = id => id ? state.cur.needs.find(x => x.id === id && !used.has(x)) : null;
    // "Preteen" or "YF" is plainly the year's Preteens or Young Folks; a closer slip is asked, with the
    // nearest name chosen first.
    const comName = c => (state.cur.needs.find(r => norm(r.committee) === norm(c)) || {}).committee || comCanon(c) || c;
    const nearest = c => { let best = '', d0 = 3; committeeNames().forEach(n => { const d = lev(loose(n), loose(c)); if (d < d0) { d0 = d; best = n; } }); return best; };
    all.slice(1).forEach(row => {
      let c = v(row, 'committee'), item = v(row, 'item');
      if (!c || /^#/.test(c) || !item) return;
      c = comName(c); u.coms.add(c);
      if (!state.cur.needs.some(r => r.committee === c) && !onList(c)) { u.unknown[c] = u.unknown[c] || nearest(c) || c; u.near = u.near || {}; u.near[c] = nearest(c); }
      const said = ANSWER_IN[norm(v(row, 'answer'))] || '';
      const id = v(row, 'id'), days = v(row, 'days');
      const first = days != null ? dayName(String(days).split(/\s*(?:–|-|\bto\b|\bthrough\b)\s*/i)[0]) : null;
      let r = id ? r0(id) : null;
      if (!r) r = state.cur.needs.find(x => !used.has(x) && x.committee === c && norm(x.item) === norm(item) && norm(x.for) === norm(v(row, 'for')) && (first == null || norm(x.first_day) === norm(first)) && (v(row, 'start') == null || norm(x.start) === norm(v(row, 'start'))));
      if (!r) r = state.cur.needs.find(x => !used.has(x) && x.committee === c && norm(x.item) === norm(item) && norm(x.for) === norm(v(row, 'for')));
      const next = {};
      if (v(row, 'for') != null) next.for = v(row, 'for');
      if (v(row, 'qty') != null) next.qty = v(row, 'qty').replace(/[^\d]/g, '');
      if (v(row, 'start') != null) next.start = v(row, 'start');
      if (v(row, 'end') != null) next.end = v(row, 'end');
      if (v(row, 'notes') != null) next.notes = v(row, 'notes');
      if (v(row, 'from') != null) next.supplied_by = v(row, 'from');
      // Where: compared as written ("RWC 137/242"); split into building and room only when it changed.
      const where = v(row, 'where');
      if (days != null) { const [a, b] = String(days).split(/\s*(?:–|-|\bto\b|\bthrough\b)\s*/i); next.first_day = dayName(a) || (a || '').trim(); next.last_day = b ? dayName(b) || b.trim() : ''; }
      if (!r) {
        if (said === 'remove') return;
        u.add.push(Object.assign({ committee: c, item, qty: next.qty || '1' }, next, where != null ? splitWhere(where) : {})); bump(c, 'added'); return;
      }
      used.add(r);
      // Where is one place ("RWC 137/242"), compared whole, however the file splits it.
      if (where != null && norm(where) !== norm(needWhere(r))) next.where = where;
      const LABEL = { where: 'Where', for: 'Used for', qty: 'Qty', start: 'Start', end: 'End', notes: 'Notes', supplied_by: 'From', building: 'Where', room: 'Room', first_day: 'Days', last_day: 'Last day' };
      const was = k => k === 'where' ? needWhere(r) : r[k];
      const diffs = Object.keys(next).filter(k => norm(next[k]) !== norm(was(k)) && !(k === 'last_day' && norm(next[k]) === norm(r.first_day) && !r.last_day) && !(k === 'last_day' && !next[k] && norm(r.last_day) === norm(r.first_day)));
      const ans = said === 'remove' || said === 'notsure' ? said : diffs.length ? 'change' : said === 'new' ? 'keep' : said;
      if (!diffs.length && (!ans || ans === r.answer)) return;
      const op = { id: r.id };
      if (diffs.length && ans !== 'remove') { op.fields = {}; diffs.forEach(k => { if (k === 'where') Object.assign(op.fields, splitWhere(next.where)); else op.fields[k] = next[k]; }); u.changes.push({ label: c + ' · ' + r.item, diffs: diffs.map(k => ({ k: LABEL[k] || k, from: was(k), to: next[k] })) }); }
      if (ans && ans !== r.answer) op.answer = ans;
      if (op.fields || op.answer) { u.ops.push(op); bump(c, !op.answer || op.answer === 'change' ? 'changed' : op.answer); }
    });
    // A committee's rows left out of its own file: perhaps removed in Excel. Asked, not assumed.
    u.missing = state.cur.needs.filter(r => u.coms.has(r.committee) && !used.has(r) && r.answer !== 'remove');
    return u;
  }
  function applyUpload() {
    const u = state.upload;
    if (!u) return;
    const ops = u.ops.slice(), add = u.add.map(a => Object.assign({}, a, { committee: u.unknown[a.committee] || a.committee }));
    Object.keys(u.drop).filter(k => u.drop[k]).forEach(id => ops.push({ id, answer: 'remove' }));
    // A committee named in the file that the year doesn't have yet joins the list.
    Object.values(u.unknown).forEach(n => { if (!onList(n)) { state.cur.committees.push({ _id: newId('co'), name: n, contact_email: '', contact_phone: '', heads: '', weekly: 'yes', order: '' }); saveCommittees(); } });
    state.upload = null;
    sendNeeds({ ops, add }).then(d => toast(esc(SU.plural(ops.length, 'row') + ' answered · ' + SU.plural((d.added || []).length, 'new request')), false));
  }
  // Export for campus: only what's asked for (kept, changed, new); anything not confirmed goes in its
  // own block, marked. Exporting is sending: the date and who are kept, and later changes are counted.
  function downloadCampus(only) {
    const S = state.cur.S, venue = S.venue || state.row.venue || 'the campus';
    const head = ['Status', 'Committee', 'Used for', 'Item', 'Qty', 'Detail', 'From', 'First day', 'Last day', 'Start', 'End', 'Building', 'Room', 'Notes'];
    const line = (r, st) => [st, r.committee, r.for, r.item, r.qty, r.detail, r.supplied_by, r.first_day, r.last_day || r.first_day, r.start, r.end, r.building, r.room, r.notes];
    let rows;
    if (only === 'changes') {
      const ss = sinceSent();
      rows = [head].concat(ss.added.map(r => line(r, 'New')), ss.changed.map(r => line(r, 'Changed')), ss.removed.map(r => line(r, 'Removed')));
    } else {
      const ok = state.cur.needs.filter(r => ['keep', 'change', 'new'].indexOf(r.answer) > -1), not = state.cur.needs.filter(r => !r.answer || r.answer === 'notsure');
      rows = [head].concat(ok.map(r => line(r, ANSWER[r.answer])));
      if (not.length) rows = rows.concat([[], ['Not confirmed'], head], not.map(r => line(r, r.answer === 'notsure' ? 'Not sure' : 'To answer')));
    }
    const st = stock(), most = [['Item'].concat(st.days, ['Most at once'])].concat(st.rows.map(x => [x.item].concat(x.n, [x.most])));
    saveXlsx([{ name: only === 'changes' ? 'Changes' : 'Requests', rows, widths: [10, 16, 22, 26, 5, 22, 16, 11, 11, 10, 10, 14, 7, 30] }, { name: 'Most at once', rows: most, widths: [30].concat(st.days.map(() => 6), [12]) }], state.year + ' requests to ' + venue + (only === 'changes' ? ' (changes)' : ''));
    // Downloading isn't sending: the person marks it sent once it's gone to the campus.
    toast('Downloaded', false, { label: 'Mark as sent', attr: 'data-marksent' });
  }
  function markSent(done) {
    call('POST', 'sent', { what: 'needs', done }).then(c => { state.ov.coa = c; chrome(); redraw('needs'); toast(done ? 'Marked sent' : 'Not marked sent'); refresh(); }, () => { chrome(); });
  }

  // Any other list out to Excel and back (the week, shifts, tournaments, buildings, halls, care
  // nearby), matched row by row with what's here.
  const OUT = {
    week: { group: 'Day', name: 'Conference week', key: r => (r.day + '|' + r.title).toLowerCase().trim() },
    shifts: { group: 'Committee', name: 'volunteer shifts', key: r => (r.committee + '|' + r.role + '|' + daysText(r)).toLowerCase().trim() },
    tournaments: { name: 'tournaments', key: r => String(r.name || '').toLowerCase().trim() },
    places: { name: 'buildings and rooms', key: r => String(r.code || '').toLowerCase().trim() },
    rooms: { name: 'dorm floors', key: r => (r.hall + '|' + roomsText(r)).toLowerCase().trim() },
    nearby: { name: 'care nearby', key: r => String(r.name || '').toLowerCase().trim() }
  };
  const outLink = name => '<button type="button" class="yr-link" data-out="' + name + '" title="An Excel sheet">' + I.download + 'Export</button><button type="button" class="yr-link" data-bring title="The sheet, changed and saved (Excel or CSV)">' + I.upload + 'Import</button>';
  const outHead = name => (OUT[name].group ? [OUT[name].group] : []).concat(SHEETS[name].cols.map(c => c.label));
  function download(name) {
    const sp = SHEETS[name], o = OUT[name], rows = state.cur[sp.file].slice();
    if (name === 'week') rows.sort((a, b) => dayIdx(a.day) - dayIdx(b.day) || sortKey(a) - sortKey(b));
    const body = rows.map(r => (o.group ? [r[sp.group] || ''] : []).concat(sp.cols.map(c => valOf(c, r))));
    saveXlsx([{ name: o.name, rows: [outHead(name)].concat(body) }], state.year + ' ' + o.name);
    toast('Downloaded · Import it back here');
  }
  function fromSheet(all, file) {
    if (all.length < 2) return false;
    const head = all[0].map(h => String(h || '').trim().toLowerCase());
    const name = Object.keys(OUT).find(n => outHead(n).slice(0, 3).every(h => head.indexOf(h.toLowerCase()) > -1));
    if (!name) return false;
    const owner = partOf(sectionOf(name)), here = part();
    if (owner && here && owner !== here) { toast('“' + file + '” belongs to ' + owner.name); return true; }
    const sp = SHEETS[name], o = OUT[name], list = state.cur[sp.file], at = h => head.indexOf(h.toLowerCase());
    const put = (r, col, v) => { if (col.pill) r[col.c] = audLabel(v); else if (col.set) col.set(r, v); else r[col.c] = col.num ? String(v).replace(/[^\d]/g, '') : v; };
    const rows = all.slice(1).map(line => {
      const r = {}, raw = {};
      if (o.group) { const g = String(line[at(o.group)] || '').trim(); r[sp.group] = name === 'week' ? dayName(g) || g : g; }
      sp.cols.forEach(col => { const i = at(col.label); if (i < 0) return; raw[col.c] = String(line[i] == null ? '' : line[i]).trim(); put(r, col, raw[col.c]); });
      return { r, raw };
    }).filter(x => sp.cols.some(c => x.raw[c.c]));
    const groups = o.group ? new Set(rows.map(x => x.r[sp.group])) : null, used = new Set(), added = [];
    const grp = r => o.group ? String(r[sp.group] || '') : '', same = (r, x) => grp(r) === grp(x.r) && sp.cols.every(c => x.raw[c.c] == null || valOf(c, r) === valOf(c, x.r));
    rows.forEach(x => { const m = list.find(r => !used.has(r) && same(r, x)); if (m) { used.add(m); x.done = true; } });
    let changed = 0;
    rows.filter(x => !x.done).forEach(x => {
      let m = list.find(r => !used.has(r) && o.key(r) === o.key(x.r));
      if (!m && name === 'week') m = list.find(r => !used.has(r) && r.day === x.r.day && timeText(r) === timeText(x.r) && !rows.some(z => o.key(z.r) === o.key(r)));
      if (!m) { added.push(x.r); return; }
      used.add(m);
      const chg = sp.cols.filter(c => x.raw[c.c] != null && valOf(c, m) !== valOf(c, x.r));
      if (!chg.length) return;
      chg.forEach(c => put(m, c, x.raw[c.c]));
      m._chg = chg.map(c => c.c).join(' '); delete m._look; changed++;
    });
    const gone = list.filter(r => !used.has(r) && (!groups || groups.has(r[sp.group])));
    if (!changed && !added.length && !gone.length) { toast('No changes'); return true; }
    gone.forEach(r => list.splice(list.indexOf(r), 1));
    added.forEach(r => list.push(Object.assign(name === 'week' ? { kind: '', call_in: '', display: '', note: '', sort_time: '' } : {}, r, { _id: newId(), _new: '1' })));
    touch('file:' + sp.file); flush(); redraw(sectionOf(name)); jump(sectionOf(name));
    toast([changed && changed + ' changed', added.length && added.length + ' added', gone.length && gone.length + ' removed'].filter(Boolean).join(', '), true);
    return true;
  }
  const MEALS = ['Breakfast', 'Lunch', 'Dinner', 'Supper'];
  function menuFromText(t) {
    const out = []; let day = '', meal = '';
    String(t).split(/\r?\n/).map(l => l.trim()).filter(Boolean).forEach(l => {
      const d = DAYS.find(x => new RegExp('^' + x + '\\b', 'i').test(l));
      if (d) { day = d; meal = ''; const rest = l.slice(d.length).replace(/^[,\s]+/, ''); const mm = MEALS.find(x => new RegExp('^' + x + '\\b', 'i').test(rest)); if (mm) meal = mm === 'Dinner' ? 'Supper' : mm; return; }
      const mm = MEALS.find(x => new RegExp('^' + x + '\\b', 'i').test(l));
      if (mm && l.length < 24) { meal = mm === 'Dinner' ? 'Supper' : mm; return; }
      if (!day || !meal) return;
      const s = l.match(/^([^:]{2,30}):\s*(.+)$/);
      out.push({ day, meal, station: s ? s[1].trim() : '', items: (s ? s[2] : l).trim() });
    });
    return out;
  }
  // A file brought to the part it belongs to (no global "Bring a file"): its rows, as text.
  function bringRows(all, name, raw) {
    const p = part();
    if (!p) { toast('Open the part it’s for'); return; }
    if (p.id === 'requests') { const u = planUpload(all, name); if (u) { if (!u.ops.length && !u.add.length && !u.missing.length) { toast('No changes'); return; } state.upload = u; redraw('needs'); jump('needs'); return; } }
    if (fromSheet(all, name)) return;
    if (p.id === 'packet' && raw) { const menu = menuFromText(raw); if (menu.length) { state.menuDraft = { name, rows: menu }; redraw('menus'); jump('menus'); return; } }
    toast(p.id === 'packet' ? 'Nothing in it looked like a menu' : p.id === 'requests' ? 'Upload takes a filled-in Template' : 'Import takes a sheet from Export');
  }
  async function bringFile(f) {
    if (!f) return;
    try {
      if (/\.xlsx$/i.test(f.name)) { bringRows(await O.xlsx.read(await f.arrayBuffer()), f.name, ''); return; }
      if (/\.(xls|numbers|ods|pdf|docx?|png|jpe?g|heic)$/i.test(f.name)) { toast('Save it as Excel (.xlsx) or CSV'); return; }
      const buf = await f.arrayBuffer();
      let t;
      // Excel's plain "CSV" is often in the old Windows letters, not UTF-8: read it either way.
      try { t = new TextDecoder('utf-8', { fatal: true }).decode(buf); } catch (x) { t = new TextDecoder('windows-1252').decode(buf); }
      t = t.replace(/^﻿/, '').replace(/\r\n?/g, '\n');
      bringRows(/[,\t]/.test(t.split('\n')[0]) ? O.parseCSV(t.indexOf('\t') > -1 && t.split('\n')[0].indexOf(',') < 0 ? t.replace(/\t/g, ',') : t) : [], f.name, t);
    } catch (e) { toast('Couldn’t read ' + f.name); console.error(e); }
  }

  /* ------------------------------------------------------------ the year's seven parts */

  const SECTIONS = [['conf', 'Dates and place', confSec], ['campus', 'The campus', campusSec], ['committees', 'Committees', committeesSec], ['notices', 'Notices', noticesSec],
    ['week', 'The week', weekSec], ['needs', 'Requests to the campus', needsSec], ['reg', 'Registration', regSec], ['shifts', 'Volunteer shifts', shiftsSec], ['tournaments', 'Tournaments', tourSec],
    ['packet', 'Parts', packetSec], ['help', 'Help', helpSec], ['menus', 'Menus', menuSec]];
  const PARTS = [
    { id: 'conference', name: 'The Conference', secs: ['conf', 'campus', 'committees', 'notices'], see: 'schedule-hub/' },
    { id: 'schedule', name: 'The schedule', secs: ['week'], see: 'schedule-hub/?view=full', at: '.wk-bar' },
    { id: 'requests', name: 'Requests to the campus', secs: ['needs'] },
    { id: 'registration', name: 'Registration', secs: ['reg'], see: 'register/' },
    { id: 'helping', name: 'Volunteer shifts', secs: ['shifts'], see: 'volunteer/' },
    { id: 'youngfolks', name: 'Young Folks', secs: ['tournaments'], see: 'tournaments/' },
    { id: 'packet', name: 'The packet', secs: ['packet', 'help', 'menus'], see: 'packet/' }
  ];
  const part = () => PARTS.find(p => p.id === state.part) || null;
  const partOf = s => PARTS.find(p => p.secs.indexOf(s) > -1) || null;
  const partHref = id => '?year=' + encodeURIComponent(state.year) + (id ? '&part=' + id : '');
  const seeHref = p => p.see ? pv(p.see) + (p.at ? '&pv-at=' + p.at : '') : '';
  const sectionOf = name => ({ week: 'week', shifts: 'shifts', tournaments: 'tournaments', places: 'campus', rooms: 'campus', nearby: 'campus', notices: 'notices', needs: 'needs' })[name];
  const FILE_SEC = { schedule: 'week', shifts: 'shifts', tournaments: 'tournaments', places: 'campus', rooms: 'campus', nearby: 'campus', notices: 'notices', needs: 'needs', guide: 'packet', help: 'help', menus: 'menus', committees: 'committees' };
  const ownerOf = p => (state.cur.S['owner_' + p.id] || '').trim();
  const toolOwn = id => id === 'registration' ? state.cur.S.registration_mode === 'link' : id === 'helping' ? state.cur.S.tool_helping === 'own' : id === 'requests' ? state.cur.S.tool_requests === 'own' : false;

  // A part's due date: the COA's own, or counted from the arrival Friday.
  const dueOf = p => coa().due[p.id] || (state.row.start ? O.isoAddDays(state.row.start, DUE[p.id]) : '');
  const daysTo = iso => O.parseISODate(iso) ? O.daysBetween(today(), iso) : null;

  // What to do. A step ticks itself where the data can tell (dates set, rows checked, "Looks right"
  // on the thing, published); the rest are ticked by hand. Every tick says who and when.
  function steps(p) {
    const S = state.cur.S, r = state.row, C = coa(), look = lookRows().length;
    const hand = (id, t, go) => { const s = C.steps[p.id + ':' + id]; return { id, t, go, hand: true, done: !!s, stamp: s }; };
    const chk = (id, t, go, cid) => { const s = C.checks[cid]; return { id, t, go, done: !!s, stamp: s }; };
    // Publish (or, for what opens on its own date, Schedule): done once a person has done it.
    const pubStep = t => { const ps = pubOf(p.id), done = p.id === 'registration' || p.id === 'youngfolks' ? !!ps.scheduled : !!(ps.on || ps.later); return { id: 'pub', t, done, stamp: done ? stampOf(p.id) : null, pub: true }; };
    if (held()) return [{ id: 'notes', t: 'Write notes for ' + (+state.year + 1), go: 'next', done: state.cur.notes.some(n => partOfNote(n) === p.id && n.text) }];
    if (undated() && p.id !== 'conference') return [{ id: 'wait', t: 'Waits for the dates', done: false, wait: true }];
    if (p.id === 'conference') return [
      { id: 'dates', t: undated() ? 'Set the dates' : 'Set the dates and the campus', go: 'conf', done: !!(r.start && (S.venue || r.venue)) },
      chk('callin', 'Check the hosts and the call-in line', 'conf', 'conf:callin'),
      chk('campus', 'Check the campus: buildings, halls and care nearby', 'campus', 'conf:campus'),
      pubStep('Announce it')];
    if (toolOwn(p.id)) return [hand('link', 'Check the link', '')];
    if (p.id === 'schedule') {
      const places = state.cur.schedule.filter(x => x._look === 'place').length;
      return [
        { id: 'look', t: 'Check the rows that vary each year', href: look ? checkHref() : '', done: !look, count: look ? SU.plural(look, 'row') + ' left' + (places ? ' · ' + places + ' places to choose' : '') : '' },
        hand('new', 'Add this year’s special meetings', 'week'),
        hand('callin', 'Mark what goes on the call-in line', 'week'),
        pubStep('Publish the schedule')];
    }
    if (p.id === 'requests') {
      const left = needsLeft(), unsure = needsUnsure(), n = state.cur.needs.length, first = needsCommittees().find(c => state.cur.needs.some(x => x.committee === c && !x.answer)) || '';
      return [
        { id: 'answer', t: 'Each committee answers its requests', href: left ? partHref('requests') + '&open=' + encodeURIComponent(first) + '#s-needs' : '', done: !left && n > 0 },
        { id: 'calls', t: 'Call about any marked Not sure', go: unsure ? 'needs' : '', done: !left && !unsure && n > 0, count: unsure ? unsure + ' not sure' : '' },
        // Sending is the person's act (the file goes by email, by hand): marked here, not by a download.
        { id: 'send', t: 'Send the list to the campus', done: !!C.sent.needs, stamp: C.sent.needs, mark: 'sent' }];
    }
    if (p.id === 'registration') return [
      chk('prices', 'Check the prices, and the linens and mattresses on hand', 'reg', 'reg:prices'),
      pubStep(pubOf('registration').scheduled ? 'Opening scheduled' : 'Schedule the opening')];
    if (p.id === 'helping') {
      const coms = Array.from(new Set(state.cur.shifts.map(x => x.committee).filter(Boolean))), n = coms.filter(c => C.checks['shifts:' + c]).length;
      return [{ id: 'shifts', t: 'Each committee checks its shifts', go: 'shifts', done: coms.length > 0 && n === coms.length, count: coms.length ? n + ' of ' + coms.length : '' }, pubStep('Publish sign-ups')];
    }
    if (p.id === 'youngfolks') {
      if ((S.tournaments_online || '') === 'no') return [chk('check', 'Check the tournaments’ times and places', 'tournaments', 'yf:tournaments')];
      return [chk('check', 'Check the tournaments, team sizes and closing times', 'tournaments', 'yf:tournaments'), pubStep(pubOf('youngfolks').scheduled ? 'Sign-ups scheduled' : 'Schedule sign-ups')];
    }
    const ids = partIds(), n = ids.filter(id => C.checks['packet:' + id]).length;
    return [
      { id: 'read', t: 'Read each part through', go: 'packet', done: ids.length > 0 && n === ids.length, count: ids.length ? n + ' of ' + ids.length : '' },
      chk('help', 'Check the Help cards and their numbers', 'help', 'packet:help'),
      { id: 'menu', t: 'Bring the caterer’s menu', go: 'menus', done: state.cur.menus.length > 0 },
      pubStep('Publish the packet')];
  }
  const stepCount = p => { const st = steps(p).filter(x => !x.wait); return { n: st.filter(x => x.done).length, of: st.length }; };
  // Done: every step, or public and nothing late.
  const partDone = p => { const c = stepCount(p); return c.of > 0 && c.n === c.of; };

  // A part's state in a few status words: on its card, and under its name.
  function stateOf(p) {
    const ps = pubOf(p.id), st = stampOf(p.id);
    if (held()) {
      const c = state.cur, notes = c.notes.filter(n => partOfNote(n) === p.id && n.text).length;
      const base0 = ({ conference: 'Ended ' + md(state.row.end), schedule: SU.plural(c.schedule.filter(r => r.title).length, 'row'), requests: SU.plural(c.needs.length, 'request'), registration: 'Closed', helping: SU.plural(c.shifts.filter(r => r.role).length, 'shift'), youngfolks: SU.plural(c.tournaments.length, 'tournament'), packet: SU.plural(partIds().length, 'part') })[p.id];
      return base0 + (notes ? ' · ' + SU.plural(notes, 'note') + ' for ' + (+state.year + 1) : '');
    }
    if (p.id !== 'conference' && undated()) return 'No dates yet';
    if (toolOwn(p.id)) return 'Another tool';
    if (p.id === 'conference') return ps.on ? 'Announced ' + mdY(ps.when) : ps.later ? 'Announced · shows ' + mdY(ps.when) : undated() ? 'No dates yet' : !(state.cur.S.venue || state.row.venue) ? 'No campus yet' : 'Not announced';
    if (p.id === 'schedule') { const look = lookRows().length; return ps.on ? 'Public since ' + mdY(ps.when) : look ? look + ' rows to check' : 'Ready to publish'; }
    if (p.id === 'requests') { const left = needsLeft(), unsure = needsUnsure(), n = state.cur.needs.length, ss = sinceSent(); return !n ? 'No requests yet' : coa().sent.needs ? 'Sent ' + md(coa().sent.needs.at) + (ss && ss.n ? ' · ' + ss.n + ' changed since' : '') : left ? (left === n ? n + ' to answer' : left + ' of ' + n + ' to answer') : unsure ? unsure + ' not sure' : 'Ready for the campus'; }
    if (p.id === 'registration') { const n = regCount(); return ps.closed ? 'Closed ' + mdY(ps.closed) : ps.on ? 'Open · ' + SU.plural(n, 'household') : ps.scheduled ? 'Opens ' + mdY(ps.when) : 'Not scheduled'; }
    if (p.id === 'helping') {
      if (!state.cur.shifts.length) return 'No shifts yet';
      if (!ps.on) return SU.plural(state.cur.shifts.length, 'shift') + ' · not public';
      const f = fillOf(state.cur.shifts);
      return (ps.closed ? 'Closed' : 'Open') + ' · ' + (!f.places ? 'open to all' : f.filled ? Math.round(f.filled / f.places * 100) + '% filled' : SU.plural(f.places, 'place'));
    }
    if (p.id === 'youngfolks') { const off = (state.cur.S.tournaments_online || '') === 'no', n = state.cur.tournaments.length; return !n ? 'No tournaments yet' : SU.plural(n, 'tournament') + (off ? ' · Not online' : ps.closed ? ' · Closed' : ps.on ? ' · Open' : ps.scheduled ? ' · Opens ' + mdY(ps.when) : ' · Not scheduled'); }
    const ids = partIds(), n = ids.filter(id => coa().checks['packet:' + id]).length;
    return ps.on ? 'Public since ' + mdY(ps.when) : (n ? n + ' of ' + SU.plural(ids.length, 'part') + ' checked' : SU.plural(ids.length, 'part') + ' to check') + (state.cur.menus.length ? '' : ' · Menus to come');
  }
  function dueText(p) {
    const ps = pubOf(p.id);
    if (held() || partDone(p) || ps.on || ps.later || ((p.id === 'registration' || p.id === 'youngfolks') && ps.scheduled)) return '';
    const d = dueOf(p), n = daysTo(d);
    if (n == null) return '';
    return n < 0 ? 'Late · due ' + mdY(d) : n === 0 ? 'Due today' : n <= 21 ? 'Due in ' + SU.plural(n, 'day') : 'Due ' + mdY(d);
  }
  const dueSoon = p => { const n = daysTo(dueOf(p)); return n != null && n <= 21 && !!dueText(p); };
  // Next: the unfinished part due soonest (undated: The Conference).
  function nextPart() {
    if (held()) return null;
    if (undated()) return PARTS[0];
    return PARTS.filter(p => !partDone(p) && !pubOf(p.id).on).sort((a, b) => (dueOf(a) || '9') < (dueOf(b) || '9') ? -1 : 1)[0] || null;
  }

  // Under the title: the state and the due date, nothing more (owner first when the COA chose one).
  // Changing them is one quiet menu; who changed what is in History, at the end.
  function partHead(p) {
    const who = ownerOf(p), due = dueText(p), canDue = !held() && !!dueOf(p), canOwner = p.id !== 'conference' && !held();
    const meta = [who ? '<span class="yr-meta__owner">' + esc(who) + '</span>' : '', esc(stateOf(p)), due ? '<span class="' + (dueSoon(p) ? 'yr-soon' : '') + '">' + esc(due) + '</span>' : ''].filter(Boolean).join(' · ');
    const more = canDue || canOwner ? ' <span class="yr-menu-w"><button type="button" class="yr-iconbtn yr-more" data-open="partmenu" aria-expanded="' + (state.open === 'partmenu') + '" title="Change due date or owner">' + I.more + '<span class="ogc-sr">Change due date or owner</span></button>' +
      (state.open === 'partmenu' ? '<span class="yr-menu" role="menu">' + (canDue ? '<button type="button" role="menuitem" data-open="due">Change due date</button>' : '') + (canOwner ? '<button type="button" role="menuitem" data-open="owner">' + (who ? 'Change owner' : 'Choose owner') + '</button>' : '') + '</span>' : '') + '</span>' : '';
    let form = '';
    if (state.open === 'due') form = '<form class="yr-inlineform" data-dueform><label class="yr-lab-t" for="yr-due-in">Due</label>' + field('due', dueOf(p), 'date', 'Due') + '<button type="submit" class="wk-btn wk-btn--line wk-btn--small">Save</button><button type="button" class="yr-link" data-open="">Cancel</button>' + (coa().due[p.id] ? '<button type="button" class="yr-link" data-duereset>Counted from the Friday</button>' : '') + '</form>';
    if (state.open === 'owner') form = ownerForm(p.id);
    return '<header class="yr-dochead yr-parthead"><div class="yr-parthead__row"><h1 class="yr-title">' + esc(p.name) + '</h1>' + (p.see ? see(seeHref(p), 'Preview') : '') + '</div>' +
      '<p class="yr-meta">' + meta + more + '</p>' + form + '</header>';
  }
  // Who does a part: typed, or a committee tapped (saved on the tap). The COA's choice; none until then.
  function ownerForm(pid) {
    const who = (state.cur.S['owner_' + pid] || '').trim(), sug = state.ov.prevOwners && state.ov.prevOwners[pid];
    return '<form class="yr-owners" data-ownerform="' + esc(pid) + '"><label class="yr-lab-t" for="yr-owner-' + esc(pid) + '">Who does it</label><input id="yr-owner-' + esc(pid) + '" class="yr-in" value="' + esc(who) + '" autocomplete="off" spellcheck="false" list="yr-com-list" placeholder="A committee">' +
      '<span class="yr-pills" role="group" aria-label="Committees">' + ['Committee of Arrangements'].concat(committeeNames()).map(c => '<button type="button" class="yr-opt" data-setowner="' + esc(c) + '" data-pid="' + esc(pid) + '" aria-pressed="' + (c === who) + '">' + esc(c === 'Committee of Arrangements' ? 'The COA' : c) + '</button>').join('') + '</span>' +
      (sug ? help(sug) : '') + '<p class="yr-btnrow"><button type="button" class="yr-link" data-open="">Done</button>' + (who ? '<button type="button" class="yr-link" data-setowner="" data-pid="' + esc(pid) + '">No owner</button>' : '') + '</p></form>';
  }
  // What to do. A step done by hand has a real checkbox ("Mark done"); the others tick themselves, and
  // say how far along they are ("2 of 7") or who did them.
  function todo(p) {
    const st = steps(p), real = st.filter(x => !x.wait), n = real.filter(x => x.done).length;
    const circle = '<span class="yr-tick__o">' + I.check + '</span>';
    return '<section class="yr-todo" aria-labelledby="yr-todo-h"><div class="yr-todo__top"><h2 class="yr-todo__h" id="yr-todo-h">' + (held() ? 'After the Conference' : 'What to do') + '</h2>' + (real.length ? '<p class="yr-todo__n">' + (n === real.length ? I.check + 'All done' : n + ' of ' + real.length + ' done') + '</p>' : '') + '</div><ol>' +
      st.map(x => {
        const sr = '<span class="ogc-sr">' + (x.wait ? '' : x.done ? 'Done: ' : 'Not done: ') + '</span>';
        const tick = x.wait ? '<span class="yr-tick is-wait" aria-hidden="true">' + I.clock + '</span>' : '<span class="yr-tick' + (x.hand || x.mark ? ' is-hand' : '') + '" aria-hidden="true">' + circle + '</span>';
        const body = x.href && !x.done ? '<a class="yr-todo__t is-go" href="' + esc(x.href) + '">' + sr + esc(x.t) + I.go + '</a>' : x.go && !x.done ? '<a class="yr-todo__t is-go" href="#' + (x.go === 'next' ? 'yr-next' : 's-' + x.go) + '">' + sr + esc(x.t) + I.go + '</a>' : '<span class="yr-todo__t">' + sr + esc(x.t) + '</span>';
        const by = x.stamp ? '<small class="yr-todo__by">' + esc((x.stamp.by || '') + ' · ' + md(x.stamp.at)) + '</small>' : '';
        let tag = '';
        if (x.hand || x.mark) {
          const attr = x.hand ? 'data-tick="' + esc(p.id + ':' + x.id) + '"' : 'data-mark="' + x.mark + '"';
          tag = '<label class="yr-markdone"><input type="checkbox" ' + attr + (x.done ? ' checked' : '') + ' aria-label="' + esc(x.t) + '"><span>' + (x.done ? 'Done' : 'Mark done') + '</span></label>' + by;
        } else if (!x.wait) tag = by || (x.count && !x.done ? '<small class="yr-todo__n2">' + esc(x.count) + '</small>' : '');
        return '<li' + (x.done ? ' class="is-done"' : '') + '>' + tick + body + tag + '</li>';
      }).join('') + '</ol></section>';
  }

  /* ------------------------------------------------------------ notes for next year */

  // docs/14 idea 7: "the previous year's knowledge vanished" is the most repeated line in every final
  // report. A note carries the lesson; last year's show where the work starts until they're Done.
  const partOfNote = n => (PARTS.find(p => p.id === n.part || p.secs.indexOf(n.part) > -1) || {}).id || '';
  const heard = (p, done) => (state.ov.notes || []).filter(n => partOfNote(n) === p.id && !!coa().notes_done[n.hash] === !!done);
  // Last year's notes for this part, in one block named for who wrote them; those marked Done fold
  // away inside it. No notes, no block.
  function heardBlock(p) {
    const open = heard(p, false), done = heard(p, true), all = open.concat(done);
    if (!all.length) return '<div class="yr-heard" hidden></div>';
    const years = Array.from(new Set(all.map(n => n.year))).sort().reverse();
    const note = (n, isDone) => '<div class="yr-note is-from">' + (n.still || n.by ? '<p class="yr-note__k">' + esc([n.still ? 'Still open from ' + n.year : '', n.by].filter(Boolean).join(' · ')) + '</p>' : '') + '<p>' + esc(n.text) + '</p>' +
      (isDone ? '<p class="yr-note__done">' + esc('Done · ' + (coa().notes_done[n.hash].by || '') + ' · ' + md(coa().notes_done[n.hash].at)) + ' <button type="button" class="yr-link" data-notedone="' + esc(n.hash) + '" data-done="">Bring back</button></p>'
        : '<button type="button" class="yr-note__btn" data-notedone="' + esc(n.hash) + '" data-done="1" title="It’s taken care of">' + I.check + 'Done</button>') + '</div>';
    return '<section class="yr-heard" aria-labelledby="yr-heard-h"><h2 class="yr-heard__h" id="yr-heard-h">From the ' + esc(years[0]) + ' COA</h2>' + (open.length ? '<div class="yr-notes">' + open.map(n => note(n, false)).join('') + '</div>' : '') +
      (done.length ? '<details class="yr-fold" data-fold="done-' + p.id + '"' + (state.folds['done-' + p.id] ? ' open' : '') + '><summary>' + I.down + '<span>Done · ' + done.length + '</span></summary><div class="yr-notes">' + done.map(n => note(n, true)).join('') + '</div></details>' : '') + '</section>';
  }
  const contactLike = t => /@|\b\d{3}[-.\s]\d{3}[-.\s]\d{4}\b/.test(t);
  function nextNotes(p) {
    const mine = state.cur.notes.filter(n => partOfNote(n) === p.id), ny = +state.year + 1;
    return '<section class="yr-next" id="yr-next" aria-labelledby="yr-next-h"><div class="yr-next__top"><h2 class="yr-next__h" id="yr-next-h" title="Shown at the top of this page to the ' + ny + ' COA">Notes for ' + ny + '</h2>' +
      '<button type="button" class="yr-link" data-note="' + p.id + '" title="What next year’s committee should know">' + I.plus + 'Add note</button></div>' +
      (mine.length ? '<div class="yr-notes">' + mine.map(n => '<div class="yr-note"><p contenteditable="plaintext-only" data-ni="' + esc(n._id) + '" aria-label="Note for ' + ny + '" data-empty="What should next year’s committee know?">' + esc(n.text) + '</p>' +
        (n.by ? '<p class="yr-note__k yr-note__k--by">' + esc(n.by + (n.at ? ' · ' + md(n.at) : '')) + '</p>' : '') + (contactLike(n.text) ? '<p class="yr-err">By role, not by name: no phones or emails</p>' : '') +
        '<button type="button" class="yr-note__btn yr-note__x" data-notedel="' + esc(n._id) + '" title="Remove">' + I.x + '<span class="ogc-sr">Remove the note</span></button></div>').join('') + '</div>' : '') + '</section>';
  }
  // What a part makes: the committees' own pages and lists, each with a live count where there is one.
  function madeFrom(p) {
    const Y = encodeURIComponent(state.year), calls = state.cur.schedule.filter(r => O.yes(r.call_in)).length, to = path => '../' + path + (path.indexOf('?') > -1 ? '&' : '?') + 'year=' + Y, n = regCount();
    const L = {
      schedule: ['Lists', [['The call-in list', to('lists/?view=callin'), calls ? calls + ' on the line' : 'The rows marked for the line'], ['The printed schedule', '../schedule/?data=' + Y + '&print=preview&preview=1', 'One sheet, both sides']]],
      registration: ['Lists', [['Rooms and check-in', to('lodging/'), n ? SU.plural(n, 'household') : 'Rooms, keys and linens'], ['Meal counts', to('lists/'), 'Each meal, by age'], ['Communion', to('lists/?view=communion'), 'How many will commune'],
        ['Preteens', to('lists/?view=preteens'), 'Who may pick each one up'], ['Payments', to('lists/?view=credits'), 'Checks to come · credits']]],
      helping: ['Lists', [['Who’s signed up', to('volunteer/?view=lead'), signedUp() ? SU.plural(signedUp(), 'sign-up') : 'Names and phones, by committee and day']]],
      youngfolks: ['Lists', [['Teams by tournament', to('tournaments/?view=teams'), (() => { const n = Object.values(counts().teams || {}).reduce((a, b) => a + b, 0); return n ? SU.plural(n, 'team') : 'Each team and who’s on it'; })()]]],
      packet: ['Lists', [['The packet, to print', pv('packet/'), 'With Help, care nearby and menus'], ['Help in the guide', pv('guide/?view=help'), 'On phones, during the week']]]
    }[p.id];
    if (!L) return '';
    return '<section class="yr-made" aria-labelledby="yr-made-h"><h2 class="yr-made__h" id="yr-made-h">' + esc(L[0]) + '</h2><ul>' +
      L[1].map(l => '<li><a href="' + esc(l[1]) + '"><b>' + esc(l[0]) + '</b><small>' + esc(l[2]) + '</small>' + I.go + '</a></li>').join('') + '</ul></section>';
  }

  /* ------------------------------------------------------------ who changed what (History) */

  const KEYWORD = { room_price: 'Room price', linen_price: 'Linen price', mattress_price: 'Air mattress price', camper_price: 'Camper price', room_beds: 'Beds to a room', linen_stock: 'Linen packets', mattress_stock: 'Air mattresses', opens: 'Opens', closes: 'Closes', refunds_by: 'Credit asked by', cancel_by: 'Cancel by', meals_free: 'Meals', preteen_details: 'Preteens’ notes', room_choice: 'Rooms given by', early_nights: 'Early nights', nights: 'Nights', gift_for: 'Gift for', hosts: 'Hosts', call_in_number: 'Call-in number', call_in_pin: 'PIN', schedule_posted: 'Schedule public', packet_posted: 'Packet public', signups_posted: 'Sign-ups public', tournaments_online: 'Tournament sign-ups', volunteer_names: 'Volunteer names', venue: 'Campus', address: 'Address', first_day: 'First day', days: 'Days', opens_time: 'Opens at', price_basis: 'Pricing', rooms_held: 'Rooms held', paper_forms: 'Paper forms', check_payee: 'Checks payable to', check_address: 'Checks mailed to' };
  const FILEWORD = { schedule: 'The week', guide: 'The packet', help: 'Help cards', menus: 'Menus', shifts: 'Shifts', tournaments: 'Tournaments', places: 'Buildings and rooms', nearby: 'Care nearby', rooms: 'Dorm halls', notices: 'Notices', needs: 'Requests', committees: 'Committees', notes: 'Notes for next year', plans: 'Floor plans', campus: 'Campus map' };
  const PUBWORD = { 'conference:announce': 'Announced the Conference', 'conference:unannounce': 'Took back the announcement', 'schedule:publish': 'Published the schedule', 'schedule:unpublish': 'Unpublished the schedule', 'packet:publish': 'Published the packet', 'packet:unpublish': 'Unpublished the packet',
    'helping:publish': 'Opened volunteer sign-ups', 'helping:close': 'Closed volunteer sign-ups', 'helping:reopen': 'Reopened volunteer sign-ups', 'helping:unpublish': 'Unpublished volunteer sign-ups', 'registration:schedule': 'Scheduled registration', 'registration:unschedule': 'Unscheduled registration', 'registration:close': 'Closed registration', 'registration:reopen': 'Reopened registration',
    'youngfolks:schedule': 'Scheduled tournament sign-ups', 'youngfolks:unschedule': 'Unscheduled tournament sign-ups', 'youngfolks:close': 'Closed tournament sign-ups', 'youngfolks:reopen': 'Reopened tournament sign-ups' };
  const stepText = id => { const [pid, sid] = String(id).split(':'), p = PARTS.find(x => x.id === pid); const s = p && steps(p).find(x => x.id === sid); return s ? s.t : sid; };
  function sentence(h) {
    const d = h.detail || {};
    if (h.action === 'change') {
      if (d.keys) return d.keys.map(k => (KEYWORD[k[0]] || k[0].replace(/_/g, ' ')) + (k.length > 2 ? ' ' + (k[1] || '—') + ' → ' + (k[2] || '—') : ' changed')).join(' · ');
      const what = FILEWORD[h.target] || h.target, n = [d.added && d.added + ' added', d.changed && d.changed + ' changed', d.removed && d.removed + ' removed'].filter(Boolean).join(', ');
      // What happened to each row, when the server could say ("Renamed Food → Dining hall", "Added Nursery").
      if (d.said && d.said.length) {
        const SAID0 = { added: 'Added ', removed: 'Removed ', changed: 'Changed ' }, total = (d.added || 0) + (d.changed || 0) + (d.removed || 0);
        return what + ': ' + d.said.map(x => x[0] === 'renamed' ? 'Renamed ' + x[1] + ' → ' + x[2] : SAID0[x[0]] + x[1]).join(' · ') + (total > d.said.length ? ' · ' + (total - d.said.length) + ' more' : '');
      }
      return what + ': ' + n + (d.labels && d.labels.length ? ' (' + d.labels.join(', ') + ')' : '');
    }
    if (h.action === 'coa') {
      if (d.what === 'step') return (d.done ? 'Ticked “' : 'Unticked “') + stepText(d.id) + '”';
      if (d.what === 'check') return (d.done ? 'Looks right: ' : 'Took back Looks right: ') + (d.n > 1 ? SU.plural(d.n, 'thing') : String(d.id || '').replace(/^[a-z]+:/, ''));
      if (d.what === 'publish') return (PUBWORD[d.part + ':' + d.act] || 'Published') + (d.reason ? ' · ' + d.reason : '');
      if (d.what === 'needs') { const t = d.tally || {}; return Object.keys(t).map(c => c + ': ' + Object.keys(t[c]).map(k => t[c][k] + ' ' + (ANSWER[k] || k).toLowerCase()).join(', ')).join(' · ') || 'Requests changed'; }
      if (d.what === 'sent') return d.undone ? 'Took back “Sent to the campus”' : 'Marked the requests sent to the campus · ' + SU.plural(d.n || 0, 'row');
      if (d.what === 'owner') return 'Owner: ' + (d.owner || 'none');
      if (d.what === 'note') return d.done ? 'Marked a note Done' : 'Brought back a note';
      if (d.what === 'due') return 'Due date: ' + (md(d.date) || 'counted from the Friday');
    }
    if (h.action === 'year_pickup') return 'Picked up from ' + d.from + (d.early ? ' (before it ended)' : '');
    if (h.action === 'year_start') return 'Started the year';
    if (h.action === 'dates') return 'Dates set: ' + O.fmtDateSpan(d.start, d.end);
    if (h.action === 'campus') return d.what === 'restore' ? 'Campus restored: ' + (d.to || 'none') : 'Campus changed: ' + d.to;
    if (h.action === 'year_set') return 'Changed ' + (d.fields || []).map(f => KEYWORD[f] || f).join(', ');
    if (h.action === 'member') return ({ invite: 'Invited ', remove: 'Removed ', resend: 'Sent a new link to ', set: 'Changed ' })[d.what] + SU.plural(d.n || 1, 'member');
    return h.action;
  }
  // Consecutive changes by the same person to the same thing within a quarter hour read as one.
  function historyOf(pid) {
    const out = [];
    ((state.ov && state.ov.history) || []).filter(h => !pid || h.part === pid || (pid === 'conference' && !h.part && h.action !== 'member')).forEach(h => {
      const last = out[out.length - 1];
      if (last && last.who === h.who && last.target === h.target && last.action === h.action && h.action === 'change' && Math.abs(new Date(last.at.replace(' ', 'T') + 'Z') - new Date(h.at.replace(' ', 'T') + 'Z')) < 15 * 60000) { last.n = (last.n || 1) + 1; return; }
      out.push(Object.assign({}, h));
    });
    return out;
  }
  const lastChange = pid => historyOf(pid)[0] || null;
  function ago(at) {
    const t = new Date(String(at).replace(' ', 'T') + 'Z'), s = (Date.now() - t) / 1000;
    if (s < 90) return 'just now';
    if (s < 3600) return Math.round(s / 60) + ' min ago';
    if (s < 86400) return Math.round(s / 3600) + ' h ago';
    return md(t.toISOString().slice(0, 10));
  }
  // Who changed what: quiet, at the end of the part; its summary says the last change.
  const whoAs = x => (x.who || 'The site') + (x.as ? ' (' + x.as + ')' : '');
  function historySec(p) {
    const h = historyOf(p.id).slice(0, 20);
    if (!h.length) return '';
    return '<details class="yr-fold yr-history" id="yr-history" data-fold="history"' + (state.folds.history ? ' open' : '') + '><summary>' + I.hist + '<span>History</span><small class="yr-dim">' + esc('Edited ' + ago(h[0].at) + ' · ' + whoAs(h[0])) + '</small></summary><ol class="yr-hist">' +
      h.map(x => '<li><span class="yr-hist__who">' + esc(whoAs(x)) + '</span><span class="yr-hist__what">' + esc(sentence(x)) + (x.n > 1 ? ' <small class="yr-dim">· ' + x.n + ' saves</small>' : '') + '</span><time class="yr-dim" datetime="' + esc(x.at) + 'Z">' + esc(ago(x.at)) + '</time></li>').join('') + '</ol></details>';
  }

  /* ------------------------------------------------------------ the year's page */

  function homeHead() {
    const p = pk(), r = state.row, S = state.cur.S, span = O.fmtDateSpan(r.start, r.end), venue = S.venue || r.venue, hosts = S.hosts || r.hosts;
    const notes = (state.ov.notes || []).filter(n => !coa().notes_done[n.hash]).length, prev = state.ov.prev;
    let moved = '';
    if (p.from && prev && prev.start && r.start) moved = ' · dates moved from ' + md(prev.start) + ' to ' + md(r.start);
    const meta = [moved ? moved.replace(/^ · d/, 'D') : '', notes ? SU.plural(notes, 'note') + ' from the ' + (prev ? prev.year : '') + ' COA' : ''].filter(Boolean).join(' · ');
    const came = p.from ? Object.keys(p.parts).length : 0;
    return '<header class="yr-homehead"><h1 class="yr-title">The ' + y() + ' Annual Conference</h1>' +
      '<p class="yr-homehead__facts">' + esc([span || 'No dates yet', venue || 'No campus yet'].join(' · ')) + (hosts ? ' · hosted by the ' + esc(hosts) : '') + '</p>' +
      (meta ? '<p class="yr-meta">' + esc(meta) + '</p>' : '') +
      (came ? '<details class="yr-fold yr-came" data-fold="came"' + (state.folds.came ? ' open' : '') + '><summary>' + I.down + '<span>' + esc('Copied from ' + p.from + (p.at ? ' · ' + mdY(p.at) : '')) + '</span></summary><p class="yr-came__t">' + esc(cameOver(p)) + '</p></details>' : '') +
      myLine() + '</header>';
  }
  function cameOver(p) {
    const x = p.parts, out = [];
    if (x.schedule) out.push(SU.plural(x.schedule.n, 'schedule row') + (x.schedule.look ? ' (' + x.schedule.look + ' to check)' : ''));
    if (x.shifts) out.push(SU.plural(x.shifts.n, 'shift'));
    if (x.tournaments) out.push(SU.plural(x.tournaments.n, 'tournament'));
    if (x.packet) out.push('the packet' + (x.packet.moved && x.packet.moved.length ? ' (' + SU.plural(x.packet.moved.length, 'date') + ' moved)' : ''));
    if (x.registration) out.push('registration’s prices and rules');
    if (x.needs) out.push(SU.plural(x.needs.n, 'request') + ' from ' + x.needs.from);
    if (x.places || x.rooms) out.push('the campus from ' + ((x.places || x.rooms).from || p.campus));
    if (x.committees) out.push(SU.plural(x.committees.n, 'committee'));
    out.push('menus wait for the caterer');
    return out.join(' · ');
  }
  // A member who said which committee they're on sees their own tools first.
  function myLine() {
    const c = (state.ov.me || {}).committee;
    if (!c) return '';
    const n = state.cur.needs.filter(r => r.committee.toLowerCase() === c.toLowerCase() && !r.answer).length;
    const tools = /lodging/i.test(c) ? [['Rooms and check-in', '../lodging/?year=' + state.year]] : /young/i.test(c) ? [['Young Folks', partHref('youngfolks')]] : [];
    return '<p class="yr-mine"><b>' + esc(c) + ':</b> ' + tools.map(t => '<a href="' + esc(t[1]) + '">' + esc(t[0]) + '</a>').join(' · ') + (n ? (tools.length ? ' · ' : '') + '<a href="' + esc(partHref('requests') + '&open=' + encodeURIComponent(c) + '#s-needs') + '">' + esc(SU.plural(n, 'request') + ' to answer') + '</a>' : '') + '</p>';
  }
  function intro() {
    if (state.ov.me.intro || state.introClosed) return '<p class="yr-introlink"><button type="button" class="yr-link yr-link--quiet" data-introopen>' + I.info + 'How this works</button></p>';
    return '<section class="yr-intro" aria-labelledby="yr-intro-h"><h2 id="yr-intro-h">How this works</h2><ol><li>Each part is one job, in the order they happen</li><li>Most steps tick themselves as the work gets done</li><li>Nothing is public until you publish it</li></ol>' +
      '<button type="button" class="wk-btn wk-btn--line wk-btn--small" data-intro>Close</button></section>';
  }
  // A year started before the last Conference ended has its facts only; its parts come over when asked.
  // Only for a year that has nothing of its own yet (no first day, no schedule) and hasn't been held:
  // never a finished year's record pulling in the year before.
  function pickupCard() {
    const p = pk(), prev = state.ov.prev;
    if (p.from || !prev || held() || state.cur.S.first_day || state.cur.schedule.length) return '';
    const over = prev.end && today() > prev.end;
    return '<section class="yr-pickup"><h2 class="yr-h">Pick up from ' + esc(prev.year) + '</h2><p>' + esc(over ? 'The ' + prev.year + ' Conference as it was held: the week, registration, the packet, shifts and tournaments, each to check' : 'The ' + prev.year + ' Conference isn’t over · its parts can come over now, as they stand, or after ' + md(prev.end)) + '</p>' +
      '<p class="yr-btnrow"><button type="button" class="wk-btn' + (over ? '' : ' wk-btn--line') + ' wk-btn--small" data-pickup' + (over ? '' : ' data-early') + '>Pick up from ' + esc(prev.year) + '</button></p></section>';
  }
  function partsGrid() {
    const next = nextPart();
    return '<ol class="yr-parts">' + PARTS.map((p, i) => {
      const c = stepCount(p), notes = heard(p, false).length, done = !held() && partDone(p), owner = ownerOf(p), due = dueText(p);
      const foot = [due, c.of && !held() ? c.n + ' of ' + c.of + ' steps' : '', owner && owner !== 'Committee of Arrangements' ? owner : '', notes ? SU.plural(notes, 'note') : ''].filter(Boolean);
      return '<li><a class="yr-card' + (p === next ? ' is-next' : '') + (done ? ' is-done' : '') + '" href="' + esc(partHref(p.id)) + '">' +
        '<span class="yr-card__name"><span class="yr-card__num" aria-hidden="true">' + (i + 1) + '</span>' + esc(p.name) + '</span>' +
        '<span class="yr-card__state">' + esc(stateOf(p)) + '</span>' +
        '<span class="yr-card__foot">' + (p === next ? '<span class="yr-card__tag">Next</span>' : done ? '<span class="yr-card__tag is-done">' + I.check + 'Done</span>' : '') +
        '<span class="yr-card__meta' + (dueSoon(p) ? ' is-soon' : '') + '">' + foot.map(f => '<span>' + esc(f) + '</span>').join('<span aria-hidden="true"> · </span>') + '</span><span class="yr-card__go">' + I.go + '</span></span></a></li>';
    }).join('') + '</ol>';
  }
  // After the Conference: the hand-off (docs/14: the most repeated line in every final report is that
  // the last year's knowledge vanished).
  function afterSec() {
    if (!held()) return '';
    const R = state.cur.R, clear = state.row.end ? O.isoAddDays(state.row.end, +R.clear_after_days || 60) : '', n = state.cur.notes.filter(x => x.text).length;
    return '<section class="yr-after"><h2 class="yr-h">After the Conference</h2><ul class="yr-after__l">' +
      '<li>' + esc(n ? SU.plural(n, 'note') + ' for ' + (+state.year + 1) : 'No notes for ' + (+state.year + 1) + ' yet') + ' <small class="yr-dim">In each part, at its end</small></li>' +
      '<li><button type="button" class="wk-btn wk-btn--small" data-record>' + I.download + 'Export the record</button> <small class="yr-dim">Every list, one Excel file, for the Conference folder</small></li>' +
      (clear ? '<li>' + esc((clear > today() ? 'Names clear ' : 'Names cleared ') + mdY(clear)) + ' <small class="yr-dim">Automatic · by the webmasters’ rule</small></li>' : '') + '</ul></section>';
  }
  // Members: the signin area's component (assets/signin/ogc-members.js) fills this slot from the
  // server's list: invite, resend, renew, remove, each as the server allows this person.
  const peopleSec = () => '<section class="yr-people" data-ogc-members="' + y() + '" aria-label="Members"></section>';
  function lastLine() {
    const h = historyOf('').find(x => x.part);
    return h ? '<p class="yr-lastchange">' + esc('Last change: ' + (PARTS.find(p => p.id === h.part) || {}).name + ' · ' + whoAs(h) + ' · ' + ago(h.at)) + '</p>' : '';
  }
  // Who does what: each part's owner, chosen once here (the COA's choice; nothing is assumed).
  function whoSec() {
    if (held()) return '<section class="yr-who" hidden></section>';
    const rows = PARTS.filter(p => p.id !== 'conference').map(p => {
      const who = ownerOf(p), open = state.whoOpen === p.id;
      return '<li class="' + (open ? 'is-open' : '') + '"><span class="yr-who__p">' + esc(p.name) + '</span><span class="yr-who__o">' + (who ? esc(who === 'Committee of Arrangements' ? 'The COA' : who) : '') + '</span>' +
        '<button type="button" class="yr-link" data-whoopen="' + p.id + '" aria-expanded="' + open + '">' + (open ? 'Close' : who ? 'Change' : 'Choose') + '</button>' + (open ? ownerForm(p.id) : '') + '</li>';
    }).join('');
    return '<section class="yr-who" id="yr-who" aria-labelledby="yr-who-h"><h2 class="yr-h" id="yr-who-h" title="Each part’s owner is the COA’s choice">Who does what</h2><ul class="yr-who__l">' + rows + '</ul></section>';
  }
  function homePage() { return '<div class="yr-home">' + homeHead() + intro() + pickupCard() + afterSec() + partsGrid() + whoSec() + peopleSec() + lastLine() + '</div>'; }

  /* ------------------------------------------------------------ the bar, its one action, and the panel */

  const notDone = p => steps(p).filter(x => !x.done && !x.pub && !x.wait);
  // The part's one action follows its state: the next real thing (Check 19 rows), then Publish.
  function act(p) {
    const ps = pubOf(p.id), st = stampOf(p.id), by = st ? ' · ' + (st.by || '') : '';
    const state0 = (t, on) => '<p class="yr-state' + (on ? ' is-on' : '') + '">' + (on ? I.check : I.clock) + esc(t) + '</p>';
    const btn = (label, attrs, line) => '<button type="button" class="wk-btn wk-btn--small yr-pubbtn' + (line ? ' wk-btn--line' : '') + '" ' + attrs + '>' + esc(label) + '</button>';
    const quiet = (label, attrs) => '<button type="button" class="yr-link" ' + attrs + '>' + esc(label) + '</button>';
    if (held()) return state0('Ended ' + mdY(state.row.end), false);
    if (toolOwn(p.id)) return state0('Another tool', false);
    if (p.id === 'conference') {
      if (ps.on) return state0('Announced ' + mdY(ps.when) + by, true) + quiet('Unannounce', 'data-panel="conference"');
      if (ps.later) return state0('Shows ' + mdY(ps.when) + by, true) + quiet('Unannounce', 'data-panel="conference"');
      if (undated() || !(state.cur.S.venue || state.row.venue)) return state0('Dates and campus first', false);
      return btn('Announce', 'data-panel="conference"');
    }
    if (p.id === 'schedule') {
      if (ps.on) return state0('Public since ' + mdY(ps.when) + by, true) + quiet('Unpublish', 'data-panel="schedule"');
      const look = lookRows().length;
      if (undated()) return '';
      if (look) return '<a class="wk-btn wk-btn--small yr-pubbtn" href="' + esc(checkHref()) + '">' + esc('Check ' + SU.plural(look, 'row')) + '</a>' + quiet('Publish', 'data-panel="schedule"');
      return btn('Publish', 'data-panel="schedule"');
    }
    if (p.id === 'requests') {
      const n = state.cur.needs.length, left = needsLeft(), sent = coa().sent.needs, ss = sinceSent();
      if (!n) return '';
      if (sent) return state0('Sent ' + mdY(sent.at) + ' · ' + (sent.by || ''), true) + (ss && ss.n ? btn('Export changes', 'data-campus="changes"') : quiet('Export again', 'data-campus=""'));
      // Nothing answered yet: nothing to send, so no export (rather than "Export anyway").
      const kept = state.cur.needs.filter(r => ['keep', 'change', 'new'].indexOf(r.answer) > -1).length;
      const exp = kept ? quiet('Export for campus', 'data-campus=""') : '<button type="button" class="yr-link" disabled title="Nothing answered yet">Export for campus</button>';
      if (left) { const first = needsCommittees().find(c => state.cur.needs.some(x => x.committee === c && !x.answer)); return '<a class="wk-btn wk-btn--small yr-pubbtn" href="' + esc(partHref('requests') + '&open=' + encodeURIComponent(first || '') + '#s-needs') + '">' + esc('Answer ' + left) + '</a>' + exp; }
      return btn('Export for campus', 'data-campus=""');
    }
    if (p.id === 'registration') {
      if (undated()) return '';
      if (ps.closed) return state0('Closed ' + mdY(ps.closed), false) + quiet('Reopen', 'data-panel="registration"');
      if (ps.on) return state0('Open since ' + mdY(ps.when) + by, true) + quiet('Close', 'data-panel="registration"');
      if (ps.scheduled) return state0('Opens ' + mdY(ps.when) + by, true) + quiet('Change', 'data-panel="registration"');
      return btn('Schedule', 'data-panel="registration"', !coa().checks['reg:prices']);
    }
    if (p.id === 'helping') {
      if (!state.cur.shifts.length) return '';
      // Open: the bar says so and leads to who's signed up; Close and Reopen sit in the part itself.
      const lead = '<a class="yr-link" href="../volunteer/?year=' + y() + '&view=lead">Who’s signed up</a>';
      if (ps.closed) return state0('Closed ' + mdY(ps.closed), false) + lead;
      if (ps.on) return state0(stateOf(p) + by, true) + lead;
      return btn('Publish', 'data-panel="helping"');
    }
    if (p.id === 'youngfolks') {
      if ((state.cur.S.tournaments_online || '') === 'no' || !state.cur.tournaments.length) return '';
      if (ps.closed) return state0('Closed', false) + quiet('Reopen', 'data-panel="youngfolks"');
      if (ps.scheduled) return state0((ps.on ? 'Open' : 'Opens ' + mdY(ps.when)) + by, true) + quiet(ps.on ? 'Close' : 'Change', 'data-panel="youngfolks"');
      return btn('Schedule sign-ups', 'data-panel="youngfolks"');
    }
    if (ps.on) return state0('Public since ' + mdY(ps.when) + by, true) + quiet('Unpublish', 'data-panel="packet"');
    return undated() ? '' : btn('Publish', 'data-panel="packet"');
  }
  // One tap on the action opens this: what goes public and to whom, what isn't done (each a link),
  // then the act itself or Cancel. Taking something back asks for a reason, and is logged.
  function panel() {
    const id = state.panel;
    if (!id) return '';
    const p = PARTS.find(x => x.id === id), ps = p ? pubOf(p.id) : {}, left = p ? notDone(p) : [];
    const leftHtml = left.length ? '<p class="yr-panel__left"><b>Not done:</b> ' + left.map(x => x.href ? '<a href="' + esc(x.href) + '">' + esc(x.t) + '</a>' : x.go ? '<a href="#s-' + esc(x.go) + '" data-panelgo>' + esc(x.t) + '</a>' : esc(x.t)).join(' · ') + '</p>' : '';
    const go = (label, a, line) => '<button type="button" class="wk-btn wk-btn--small' + (line ? ' wk-btn--line' : '') + '" data-pub="' + esc(id) + '" data-act="' + a + '">' + esc(label) + '</button>';
    const cancel = '<button type="button" class="yr-link" data-panel="">Cancel</button>';
    const reason = '<label class="yr-lab">Reason <small class="yr-dim">optional · kept in History</small><input class="yr-in" data-reason autocomplete="off"></label>';
    let h = '';
    if (id === 'campus') {
      h = '<p><b>' + esc('Export with ' + [needsLeft() && needsLeft() + ' to answer', needsUnsure() && needsUnsure() + ' not sure'].filter(Boolean).join(' and ') + '?') + '</b></p><p>They go in a separate block, marked Not confirmed</p><p class="yr-btnrow"><button type="button" class="wk-btn wk-btn--line wk-btn--small" data-campus="" data-sure="1">Export anyway</button>' + cancel + '</p>';
    } else if (id === 'conference') {
      const ahead = state.years.find(z => +z.year < +state.year && z.end && z.end >= today());
      h = ps.on || ps.later ? '<p><b>Unannounce?</b> The Conference page goes back to the year before</p>' + reason + '<p class="yr-btnrow">' + go('Unannounce', 'unannounce', true) + cancel + '</p>'
        : '<p><b>Announce the ' + y() + ' Conference?</b></p><p>' + esc((ahead ? 'On ' + mdY(O.isoAddDays(ahead.end, 1)) + ', after the ' + ahead.year + ' Conference' : 'Now') + ' · The Conference page shows ' + state.year + (state.ov.prev ? ' · ' + state.ov.prev.year + ' moves to past years' : '')) + '</p>' + leftHtml + '<p class="yr-btnrow">' + go(left.length ? 'Announce anyway' : 'Announce', 'announce') + cancel + '</p>';
    } else if (id === 'schedule' || id === 'packet') {
      const where = id === 'schedule' ? 'the Conference page, the guide and the printout' : 'the Conference page and the printed packet';
      h = ps.on ? '<p><b>Unpublish?</b> It comes off ' + where + '</p>' + reason + '<p class="yr-btnrow">' + go('Unpublish', 'unpublish', true) + cancel + '</p>'
        : '<p><b>' + (id === 'schedule' ? 'The schedule' : 'The packet') + ' goes on ' + where + ', for everyone</b></p>' + leftHtml + '<p class="yr-btnrow">' + go(left.length ? 'Publish anyway' : 'Publish', 'publish') + cancel + '</p>';
    } else if (id === 'helping') {
      h = ps.closed ? '<p><b>Reopen sign-ups?</b></p><p class="yr-btnrow">' + go('Reopen', 'reopen') + cancel + '</p>'
        : ps.on ? '<p><b>Close sign-ups?</b> Volunteers keep their shifts; nobody new can join</p>' + reason + '<p class="yr-btnrow">' + go('Close', 'close', true) + cancel + '</p>'
        : '<p><b>Anyone can sign up for a shift</b> · on the volunteer page and Your sign-ups</p>' + leftHtml + '<p class="yr-btnrow">' + go(left.length ? 'Publish anyway' : 'Publish', 'publish') + cancel + '</p>';
    } else if (id === 'registration') {
      const R = state.cur.R;
      if (ps.closed) h = '<p><b>Reopen registration?</b></p><p class="yr-btnrow">' + go('Reopen', 'reopen') + cancel + '</p>';
      else if (ps.on) h = '<p><b>Close registration?</b> Households already registered keep their rooms</p>' + reason + '<p class="yr-btnrow">' + go('Close', 'close', true) + cancel + '</p>';
      else h = '<p><b>The form opens to everyone</b> · ' + esc((R.opens_time || '') + ' ' + (state.cur.S.timezone_label || '')).trim() + '</p>' +
        '<p class="yr-dates"><label class="yr-lab">Opens' + field('sched.opens', ps.scheduled ? ps.when : sugOpens(), 'date', 'Opens') + '</label><label class="yr-lab">Closes' + field('sched.closes', R.closes && R.closes !== NOT_YET ? R.closes : '', 'date', 'Closes') + '</label></p>' +
        (state.panelErr ? '<p class="yr-fielderr" role="alert">' + esc(state.panelErr) + '</p>' : '') + leftHtml +
        '<p class="yr-btnrow">' + go(ps.scheduled ? 'Save' : left.length ? 'Schedule anyway' : 'Schedule', 'schedule') + cancel + (ps.scheduled ? '<button type="button" class="yr-link" data-pub="registration" data-act="unschedule">Unschedule</button>' : '') + '</p>';
    } else if (id === 'youngfolks') {
      if (ps.closed) h = '<p><b>Reopen tournament sign-ups?</b></p><p class="yr-btnrow">' + go('Reopen', 'reopen') + cancel + '</p>';
      else if (ps.scheduled) h = '<p><b>' + (ps.on ? 'Close tournament sign-ups?' : 'Unschedule tournament sign-ups?') + '</b></p><p class="yr-btnrow">' + go(ps.on ? 'Close' : 'Unschedule', ps.on ? 'close' : 'unschedule', true) + cancel + '</p>';
      else h = '<p><b>Teams can sign up' + (ps.when ? ' from ' + esc(mdY(ps.when)) : '') + '</b> · each tournament opens on its own date</p>' + leftHtml + '<p class="yr-btnrow">' + go(left.length ? 'Schedule anyway' : 'Schedule', 'schedule') + cancel + '</p>';
    }
    // Its first line is its heading, and takes the focus (never the act itself: one Enter mustn't publish).
    h = h.replace(/^<p><b>([\s\S]*?)<\/b>(?:\s*·\s*)?/, '<h2 class="yr-panel__h" id="yr-panel-h" tabindex="-1">$1</h2><p>').replace(/<p>\s*<\/p>/g, '');
    return '<div class="yr-panel" role="dialog" aria-modal="true" aria-labelledby="yr-panel-h">' + h + '</div>';
  }
  function bar() {
    const p = part();
    // Come from a printout (the packet's or the schedule's Edit, with return=): Back goes there.
    const ret = q.get('return'), back = ret && /^\/(?!\/)[^\s\\]*$/.test(ret) ? ret : '';
    const crumb = back && p && !state.tool ? '<a class="yr-back" href="' + esc(back) + '">' + I.back + '<span>' + esc(/\/packet\//.test(back) ? 'Information packet' : /\/schedule\//.test(back) ? 'Printable schedule' : 'Back') + '</span></a>'
      : p && state.tool ? '<a class="yr-back" href="' + esc(partHref(p.id)) + '">' + I.back + '<span>' + esc(p.name) + '</span></a>'
      : p ? '<a class="yr-back" href="' + esc(partHref('')) + '">' + I.back + '<span><b>' + y() + '</b></span></a>' : '<span class="yr-crumb__t">Committee of Arrangements</span>';
    return '<header class="ws-bar ws-bar--year"><div class="ws-bar__in"><p class="yr-crumb">' + crumb + '</p>' +
      '<p class="ws-status" role="status" aria-live="polite"></p>' +
      '<div class="yr-actions">' + (p && !state.tool ? act(p) : !p ? '<a class="yr-tool" href="' + esc(pv('schedule-hub/')) + '" target="_blank" rel="noopener" data-see>' + I.eye + '<span>Preview</span></a>' : '') + '</div></div>' + clashBar() + '</header>';
  }
  // Phones: the part's one action in reach of a thumb, with its state word.
  function dock() {
    const p = part();
    if (!p || state.tool) return '';
    const a = act(p);
    return a ? '<div class="yr-dock">' + a + '</div>' : '';
  }

  /* ------------------------------------------------------------ drawing */

  function partPage(p) {
    if (state.tool === 'pins' && p.id === 'conference') return '<div class="yr-body yr-body--part yr-body--wide"><div class="yr-doc"><div class="yr-sheetpage"><header class="yr-dochead yr-parthead"><div class="yr-parthead__row"><h1 class="yr-title">Map pins</h1></div>' +
      '<p class="yr-meta">Rooms on the schedule</p>' + '' + '</header>' + pinsFold() + '</div></div></div>';
    if (state.tool === 'check' && p.id === 'schedule') return checkTool();
    return '<div class="yr-body yr-body--part"><div class="yr-doc"><div class="yr-sheetpage">' + partHead(p) + todo(p) + heardBlock(p) +
      p.secs.map(id => SECTIONS.find(x => x[0] === id)[2]()).join('') + madeFrom(p) + nextNotes(p) + historySec(p) + '</div></div></div>';
  }
  function lists() {
    return '<datalist id="yr-places-list">' + state.cur.places.map(p => '<option value="' + esc(p.name || p.code) + '">').join('') + '</datalist>' +
      '<datalist id="yr-com-list">' + committeeNames().map(c => '<option value="' + esc(c) + '">').join('') + '</datalist>';
  }
  function render(keepFocus) {
    const f = keepFocus ? focusKey(document.activeElement) : '', p = part();
    root.innerHTML = '<div class="wk yr ws ' + (p ? 'yr--part' : 'yr--home') + (state.panel ? ' has-panel' : '') + '">' + bar() + panel() + (p ? partPage(p) : homePage()) + dock() + lists() +
      '<input type="file" class="yr-file" accept=".xlsx,.csv,.tsv,.txt,text/plain,text/csv" hidden>' +
      '<div class="yr-toast" role="status" hidden></div><div class="yr-dropover" hidden><p>' + I.upload + 'Drop to import</p></div></div>';
    document.title = (p ? p.name + ' – ' : '') + state.year + ' Annual Conference – Committee of Arrangements';
    status();
    if (f) refocus(f);
    markSeen();
    mountPins();
  }
  function redraw(id) {
    const s = SECTIONS.find(x => x[0] === id), el = root.querySelector('#s-' + id);
    const inside = el && el.contains(document.activeElement), f = inside ? focusKey(document.activeElement) : '';
    if (s && el) { const t = document.createElement('div'); t.innerHTML = s[2](); el.replaceWith(t.firstChild); }
    chrome();
    if (f) refocus(f);
    markSeen();
    if (id === 'campus') mountPins();
  }
  const redrawFile = name => { const s = FILE_SEC[name]; if (s) redraw(s); else chrome(); };
  // What counts on the page: the bar, the panel, the part's head, what to do, the notes, History; or the year's cards.
  function chrome() {
    const p = part();
    swapBar();
    const pn = root.querySelector('.yr-panel'), want = panel();
    if (pn && !want) pn.remove(); else if (want && !(pn && pn.contains(document.activeElement))) { if (pn) swap('.yr-panel', want); else root.querySelector('.ws-bar').insertAdjacentHTML('afterend', want); }
    const dk = root.querySelector('.yr-dock'), dw = dock();
    if (dk && dw) swap('.yr-dock', dw); else if (dk) dk.remove(); else if (dw) root.querySelector('.yr').insertAdjacentHTML('beforeend', dw);
    root.querySelector('.yr') && root.querySelector('.yr').classList.toggle('has-panel', !!state.panel);
    if (p && !state.tool) { swap('.yr-parthead', partHead(p), true); swap('.yr-todo', todo(p)); swap('.yr-heard', heardBlock(p)); swap('.yr-next', nextNotes(p), true); const hs = root.querySelector('.yr-history'), hw = historySec(p); if (hs && hw) swap('.yr-history', hw); else if (!hs && hw) { const n = root.querySelector('.yr-next'); if (n) n.insertAdjacentHTML('afterend', hw); } }
    else if (!p) { swap('.yr-homehead', homeHead()); swap('.yr-parts', partsGrid()); swap('.yr-who', whoSec(), true); swap('.yr-lastchange', lastLine()); }
    status();
  }
  // The bar's own parts only: the account mark (signin area) stays where it is.
  function swapBar() {
    const p = part(), a = root.querySelector('.yr-actions'), c = root.querySelector('.yr-clash'), want = clashBar();
    const html = p && !state.tool ? act(p) : !p ? '<a class="yr-tool" href="' + esc(pv('schedule-hub/')) + '" target="_blank" rel="noopener" data-see>' + I.eye + '<span>Preview</span></a>' : '';
    if (a && a.innerHTML !== html && !a.contains(document.activeElement)) a.innerHTML = html;
    if (c && !want) c.remove(); else if (want) { if (c) c.outerHTML = want; else root.querySelector('.ws-bar').insertAdjacentHTML('beforeend', want); }
  }
  // A part being typed in isn't redrawn under the typing (a focused button is fine to redraw).
  const typingIn = el => el.contains(document.activeElement) && document.activeElement.matches('input, textarea, [contenteditable]');
  function swap(sel, html, typing) { const el = root.querySelector(sel); if (el && !(typing && typingIn(el))) { const t = document.createElement('div'); t.innerHTML = html; if (t.firstChild) el.replaceWith(t.firstChild); } }
  // Where the typing was, to come back to it after a re-draw.
  function focusKey(el) {
    if (!el || !el.closest || !root.contains(el)) return '';
    const tr = el.closest('tr[data-id]'), sh = el.closest('[data-sheet]');
    if (tr && sh && el.dataset.c) return '[data-sheet="' + sh.dataset.sheet + '"] tr[data-id="' + tr.dataset.id + '"] [data-c="' + el.dataset.c + '"]';
    for (const a of ['data-k', 'data-gi', 'data-hi', 'data-ni', 'data-comname', 'data-comcontact', 'data-needopen', 'data-look', 'data-tick', 'data-answer']) if (el.hasAttribute(a)) {
      const li = el.closest('[data-nid]');
      return (li ? '[data-nid="' + li.dataset.nid + '"] ' : '') + '[' + a + '="' + CSS.escape(el.getAttribute(a)) + '"]' + (el.dataset.gf ? '[data-gf="' + el.dataset.gf + '"]' : el.dataset.hf ? '[data-hf="' + el.dataset.hf + '"]' : '');
    }
    return '';
  }
  function refocus(sel) { const el = root.querySelector(sel); if (el) { el.focus({ preventScroll: true }); if (el.isContentEditable) caretEnd(el); } }
  // A short status line; with Undo when it can be taken back. It stays 10 seconds, longer while
  // it's pointed at or focused.
  function toast(t, undoable, action) {
    const el = root.querySelector('.yr-toast');
    if (!el) return;
    el.textContent = '';
    const s = document.createElement('span'); s.textContent = t; el.appendChild(s);
    if (undoable) { const b = document.createElement('button'); b.type = 'button'; b.dataset.undo = ''; b.innerHTML = I.undo + 'Undo'; el.appendChild(b); }
    // A next step the toast offers ("Downloaded · Mark as sent").
    if (action) { const b = document.createElement('button'); b.type = 'button'; b.setAttribute(action.attr, ''); b.textContent = action.label; el.appendChild(b); }
    el.hidden = false;
    const hide = () => { clearTimeout(toast.t); toast.t = setTimeout(() => { if (!el.matches(':hover, :focus-within')) el.hidden = true; else hide(); }, undoable || action ? 10000 : 4000); };
    hide();
  }
  const caretEnd = el => { const s = getSelection(), r = document.createRange(); r.selectNodeContents(el); r.collapse(false); s.removeAllRanges(); s.addRange(r); };
  const caret = el => { const s = getSelection(); if (!s.rangeCount) return el.textContent.length; const r = s.getRangeAt(0).cloneRange(); r.selectNodeContents(el); r.setEnd(s.getRangeAt(0).endContainer, s.getRangeAt(0).endOffset); return r.toString().length; };
  const selectAll = el => { const s = getSelection(), r = document.createRange(); r.selectNodeContents(el); s.removeAllRanges(); s.addRange(r); };
  const jump = id => { const s = root.querySelector('#s-' + id); if (s) s.scrollIntoView({ behavior: matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth', block: 'start' }); };

  /* ------------------------------------------------------------ Preview, beside or over the page */

  // Andrew, Oct 7: "if people cant see where the information they entered is going they get so lost".
  // On a laptop the real page opens beside the part, at a phone's width, and follows the typing; on a
  // phone or tablet it opens over the page, in the same tab, with Back at its top (a new tab loses people).
  const WIDE = matchMedia('(min-width: 1240px)');
  let pane = null;
  function openSee(href) {
    if (!pane) {
      pane = document.createElement('aside');
      pane.className = 'ogc wk yr-pv';
      pane.setAttribute('aria-label', 'Preview');
      document.body.appendChild(pane);
      pane.addEventListener('click', e => { if (e.target.closest('[data-seeclose]')) closeSee(true); });
    }
    const s = seeOf(href), ps = s[2] ? pubOf(s[2]) : null;
    const st = !ps ? 'Preview' : ps.on ? 'Public' : ps.scheduled && ps.when ? 'Opens ' + mdY(ps.when) : 'Not public yet';
    const full = !WIDE.matches;
    pane.classList.toggle('is-full', full);
    pane.innerHTML = '<header class="yr-pv__bar">' + (full ? '<button type="button" class="yr-pv__btn" data-seeclose title="Back">' + I.back + '<span class="ogc-sr">Back</span></button>' : '') + '<p><b>' + esc(s[1]) + '</b><small>' + esc(st) + '</small></p>' +
      (full ? '' : '<button type="button" class="yr-pv__btn" data-seeclose title="Close">' + I.x + '<span class="ogc-sr">Close</span></button>') + '</header>' +
      '<div class="yr-pv__page"><iframe src="' + esc(href) + '" title="' + esc(s[1]) + ', as it will look"></iframe></div>';
    const b = root.querySelector('.ws-bar');
    pane.style.top = full ? '0px' : (b ? Math.round(b.getBoundingClientRect().bottom) : 0) + 'px';
    pane.hidden = false;
    state.see = href;
    document.documentElement.classList.add(full ? 'yr-has-pvfull' : 'yr-has-pv');
    markSeen();
    if (full) { const c = pane.querySelector('[data-seeclose]'); if (c) c.focus(); }
  }
  function closeSee(back) {
    if (!pane || pane.hidden) return;
    const href = state.see;
    pane.hidden = true; pane.innerHTML = ''; state.see = '';
    document.documentElement.classList.remove('yr-has-pv', 'yr-has-pvfull');
    markSeen();
    if (back) { const a = Array.from(root.querySelectorAll('a[data-see]')).find(x => x.getAttribute('href') === href); if (a) a.focus({ preventScroll: true }); }
  }
  function markSeen() { root.querySelectorAll('a[data-see]').forEach(a => { a.setAttribute('aria-expanded', String(!!state.see && a.getAttribute('href') === state.see)); }); }
  root.addEventListener('click', e => {
    const a = e.target.closest('a[data-see]');
    if (!a || e.metaKey || e.ctrlKey || e.shiftKey) return;
    e.preventDefault();
    if (state.see === a.getAttribute('href')) closeSee(); else openSee(a.getAttribute('href'));
  });
  WIDE.addEventListener('change', () => closeSee());

  /* ------------------------------------------------------------ map pins (The Conference › Pin) */

  // Every place on the schedule is on the campus map by its building (the code before the slash); a
  // room inside one is pinned on the walk-through (Pin here, standing at its door) or by tapping the map.
  const buildingOfPlace = r => {
    const c = state.cur.campus, code = String(r.code || '').split('/')[0].toUpperCase();
    const main = state.cur.places.find(x => String(x.code).toUpperCase() === code);
    return c && (c.items.find(i => i.code && i.code.toUpperCase() === code) || c.items.find(i => [r.building, main && main.building, main && main.name].indexOf(i.name) > -1));
  };
  const hasPin = r => r.x !== '' && r.x != null && !isNaN(+r.x);
  // Map area: what's left to pin, said truthfully (rooms and outdoor places; never "All on the map" with none pinned).
  const pinWord = rs => { const w = rs.filter(r => String(r.code).indexOf('/') > -1 || r.outdoor === 'yes'), n = w.filter(hasPin).length; return !w.length ? 'No rooms' : n === w.length ? 'All ' + w.length + ' pinned' : n ? n + ' of ' + w.length + ' pinned' : w.length + ' to pin'; };
  function pinsFold() {
    // The map area's walk-through (shared/ogc-map-pins.js): rooms, doors, outdoors, halls, closures, kept per campus.
    if (O.map && O.map.pins) return '<section class="yr-sec yr-sec--pins" id="s-pins" aria-label="Map pins"><div id="yr-pinmap"></div></section>';
    const c = state.cur.campus;
    if (!c) return '<div class="ws-blank"><p class="ws-blank__h">No campus map</p></div>';
    const qq = state.pinQ.toLowerCase(), rows = state.cur.places.filter(r => r.code && (!qq || (r.name + ' ' + r.code).toLowerCase().indexOf(qq) > -1));
    const all = state.cur.places.filter(r => r.code), pinned = all.filter(hasPin).length;
    const list = rows.map(r => {
      const b = buildingOfPlace(r), has = hasPin(r), on = state.pinFor === r.code;
      return '<li class="yr-pin' + (on ? ' is-on' : '') + '"><span class="yr-pin__n"><b>' + esc(r.name) + '</b><code>' + esc(r.code) + '</code></span>' +
        '<span class="yr-pin__s">' + (on ? 'Tap the map' : has ? I.check + 'Pinned' : b ? 'By building' : 'Not on the map') + '</span>' +
        '<span class="yr-pin__b">' + (on ? '<button type="button" class="yr-link" data-pincancel>Cancel</button>' :
          '<button type="button" class="wk-btn wk-btn--line wk-btn--small yr-pin__here" data-pinnow="' + esc(r.code) + '" title="Your location, standing at its door">' + I.pin + 'Pin here</button><button type="button" class="yr-link" data-pinfor="' + esc(r.code) + '" title="Then tap the map">On map</button>' + (has ? '<button type="button" class="yr-link" data-pinclear="' + esc(r.code) + '">Clear</button>' : '')) + '</span></li>';
    }).join('');
    return '<section class="yr-sec yr-sec--pins" id="s-pins" aria-label="Map pins"><p class="yr-dim">' + esc(SU.plural(all.length, 'room') + ' · ' + all.filter(r => buildingOfPlace(r)).length + ' by building · ' + pinned + ' pinned') + (state.pinMsg ? ' · <span class="yr-err">' + esc(state.pinMsg) + '</span>' : '') + '</p>' +
      '<div class="yr-pinmap"><div class="yr-pinmap__map' + (state.pinFor ? ' is-pinning' : '') + '" id="yr-pinmap"></div><div><label class="yr-search">' + I.search + '<span class="ogc-sr">Find a room</span><input class="yr-in" data-pinq type="search" value="' + esc(state.pinQ) + '" placeholder="Find a room" autocomplete="off"></label><ul class="yr-pins">' + list + '</ul></div></div></section>';
  }
  function mountPins() {
    if (O.map && O.map.pins) {
      const at = root.querySelector('#yr-pinmap');
      if (!at || !state.cur) return;
      if (!state.pinTool || state.pinTool.year !== state.year) state.pinTool = O.map.pins({ year: state.year, places: state.cur.places, onSaved: r => { const p = state.cur.places.find(x => String(x.code).toUpperCase() === String(r.code).toUpperCase()); if (p && 'x' in r) { p.x = r.x; p.y = r.y; } } });
      state.pinTool.mount(at);
      return;
    }
    const slot = root.querySelector('#yr-pinmap'), c = state.cur && state.cur.campus;
    if (!slot || !c || !O.map) return;
    if (!state.pinEl || state.pinYear !== state.year) {
      state.pinEl = document.createElement('div'); state.pinEl.className = 'yr-pinmap__box'; state.pinYear = state.year;
      slot.appendChild(state.pinEl);
      state.pinMap = O.map.viewer(state.pinEl, c, { title: 'Campus map', start: c.items.filter(i => ['dining', 'worship', 'venue', 'hall'].indexOf(i.kind) > -1 && i.code !== 'TF').map(i => i.name), onTap: (pt, b) => {
        if (!state.pinFor) return;
        const r = state.cur.places.find(x => x.code === state.pinFor);
        if (!r) return;
        r.x = pt.x.toFixed(1); r.y = pt.y.toFixed(1); touch('file:places');
        toast(r.name + ' pinned' + (b ? ' · ' + b : ''), true);
        state.pinFor = ''; render(true);
      } });
    } else slot.appendChild(state.pinEl);
    state.pinMap.draw();
    state.pinMap.pins(state.cur.places.filter(hasPin).map(r => ({ x: +r.x, y: +r.y, kind: 'room', label: r.code })));
    const f = state.pinFor && state.cur.places.find(x => x.code === state.pinFor), b = f && buildingOfPlace(f);
    state.pinMap.select(b ? b.name : '');
    if (b) state.pinMap.fit(O.map.boxOf(c, [b.name], 40));
  }

  /* ------------------------------------------------------------ actions on the server */

  const pinged = () => { try { localStorage.setItem('ogc-saved', String(Date.now())); } catch (x) { /* not framed */ } };
  // After an action that changed many files at once (dates, campus, pickup): the year read again.
  async function reloadYear(msg, undoable) {
    if (O.store && O.store.flush) await O.store.flush();
    state.cur = null;
    await load().catch(() => {});
    render();
    pinged();
    if (msg) toast(msg, undoable);
  }
  function takePub(d) {
    if (d.coa) state.ov.coa = d.coa;
    if (d.year) Object.assign(state.row, d.year);
    if (d.settings) Object.assign(state.cur.S, d.settings);
    if (d.registration) Object.assign(state.cur.R, d.registration);
  }
  const SAID = { 'conference:announce': 'Announced', 'conference:unannounce': 'Unannounced', 'schedule:publish': 'The schedule is public', 'schedule:unpublish': 'Unpublished', 'packet:publish': 'The packet is public', 'packet:unpublish': 'Unpublished',
    'helping:publish': 'Sign-ups are open', 'helping:close': 'Sign-ups closed', 'helping:reopen': 'Sign-ups reopened', 'registration:schedule': 'Registration scheduled', 'registration:unschedule': 'Not scheduled', 'registration:close': 'Registration closed', 'registration:reopen': 'Registration reopened',
    'youngfolks:schedule': 'Tournament sign-ups scheduled', 'youngfolks:unschedule': 'Not scheduled', 'youngfolks:close': 'Tournament sign-ups closed', 'youngfolks:reopen': 'Reopened' };
  function publish(pid, a) {
    const body = { part: pid, act: a };
    const rs = root.querySelector('.yr-panel [data-reason]'); if (rs && rs.value.trim()) body.reason = rs.value.trim();
    if (pid === 'registration' && a === 'schedule') {
      const o = root.querySelector('.yr-panel [data-k="sched.opens"]'), c = root.querySelector('.yr-panel [data-k="sched.closes"]');
      body.opens = parseRegDate(o ? o.value : ''); body.closes = c && c.value.trim() ? parseRegDate(c.value) : '';
      if (!body.opens) { state.panelErr = 'Opens: not a date, try "Feb 25"'; chrome(); return; }
    }
    flush();
    call('POST', 'publish', body).then(d => {
      takePub(d); state.panel = ''; state.panelErr = '';
      render(true); pinged(); refresh();
      toast(SAID[pid + ':' + a] + (d.stamp && d.stamp.shows && d.stamp.shows > today() ? ' · shows ' + mdY(d.stamp.shows) : ''));
    }, e => { state.panelErr = e.message || 'Not saved'; chrome(); });
  }
  function setCheck(id, done, also, partId) {
    const all = [id].concat(also || []), me = state.ov.me || {};
    all.forEach(k => { if (done) coa().checks[k] = { by: me.name, at: today() }; else delete coa().checks[k]; });
    render(true);
    call('POST', 'check', { ids: all, done, part: partId || state.part }).then(c => { state.ov.coa = c; pinged(); refresh(); }, () => refresh());
  }
  function tick(id, done) {
    const me = state.ov.me || {};
    if (done) coa().steps[id] = { by: me.name, at: today() }; else delete coa().steps[id];
    chrome();
    const b = root.querySelector('input[data-tick="' + CSS.escape(id) + '"]'); if (b) b.focus({ preventScroll: true });
    call('POST', 'step', { id, done }).then(c => { state.ov.coa = c; refresh(); }, () => refresh());
  }
  function previewDates() {
    const pd = state.pendingDates;
    if (!pd || !pd.start) return;
    call('POST', 'dates', { start: pd.start, end: pd.endTyped ? pd.end || '' : '' }).then(plan => { if (state.pendingDates === pd) { pd.plan = plan; if (!pd.endTyped) pd.end = plan.end; redraw('conf'); } },
      e => { markField('date.' + ((e.data && e.data.field) || 'start'), e.message); });
  }
  function previewCampus(body) {
    call('POST', 'campus', body).then(plan => { state.pendingCampus = { body, plan }; render(true); const b = root.querySelector('[data-campusgo]'); if (b) b.focus(); },
      e => toast(e.message || 'Not saved'));
  }
  // Renaming a committee renames it everywhere the year uses it: shifts, requests, owners.
  function renameCommittee(c, name) {
    const old = c.name;
    if (!name || name === old) return;
    if (onList(name) && name.toLowerCase() !== old.toLowerCase()) { markField('', ''); toast('Already on the list: ' + name); return; }
    c.name = name; saveCommittees();
    let n = 0;
    state.cur.shifts.forEach(r => { if (r.committee === old) { r.committee = name; n++; } });
    if (n) touch('file:shifts');
    PARTS.forEach(p => { if (state.cur.S['owner_' + p.id] === old) { state.cur.S['owner_' + p.id] = name; call('POST', 'owner', { part: p.id, owner: name }).catch(() => {}); } });
    const nr = state.cur.needs.filter(r => r.committee === old);
    if (nr.length) sendNeeds({ ops: nr.map(r => ({ id: r.id, fields: { committee: name } })) }).catch(() => {});
    toast('Renamed · ' + SU.plural(n + nr.length, 'row'));
  }
  // The year's record for the Conference folder: every list in one Excel file (contacts left out).
  // The households and volunteers are fetched for this file only, when asked (the page itself holds none).
  async function exportRecord() {
    let got = {};
    try { got = await api('GET', 'years/' + state.year + '/records?kinds=registrations,signups'); } catch (e) { toast('Couldn’t load the sign-ups · Retry'); return; }
    const c = state.cur, regs = (got.registrations || []).filter(x => !x._pub), sign = (got.signups || []).filter(x => !x._pub);
    const sheets = [
      { name: 'Schedule', rows: [['Day', 'Time', 'What', 'Where', 'For']].concat(c.schedule.slice().sort((a, b) => dayIdx(a.day) - dayIdx(b.day) || sortKey(a) - sortKey(b)).map(r => [r.day, timeText(r), r.title, r.place, audLabel(r.audience)])) },
      { name: 'Requests', rows: [['Committee', 'Used for', 'Item', 'Qty', 'Days', 'Start', 'End', 'Where', 'Answer']].concat(c.needs.map(r => [r.committee, r.for, r.item, r.qty, needDays(r), r.start, r.end, needWhere(r), ANSWER[r.answer] || ''])) },
      { name: 'Shifts', rows: [['Committee', 'Shift', 'Days', 'Time', 'People']].concat(c.shifts.map(r => [r.committee, r.role, daysText(r), timeText(r), r.needed])) },
      { name: 'Tournaments', rows: [['Tournament', 'Team size', 'Closes']].concat(c.tournaments.map(t => [t.name, sizeText(t), closesText(t)])) },
      { name: 'Households', rows: [['Household', 'People', 'Nights']].concat(regs.map(h => [SU.householdName ? SU.householdName(h) : (h.household && h.household.name) || '', (h.people || []).length, String((h.stay && h.stay.nights) || '').replace(/\|/g, ', ')])) },
      { name: 'Volunteers', rows: [['Shift', 'Name']].concat(sign.map(s => [String(s.id || '').replace(/\|/g, ' · '), s.name || ''])) }
    ];
    saveXlsx(sheets, state.year + ' Annual Conference record');
    toast('Downloaded');
  }

  /* ------------------------------------------------------------ events */

  root.addEventListener('click', e => {
    // The part's small menu closes on any tap outside it.
    if (state.open === 'partmenu' && !(e.target.closest && e.target.closest('.yr-menu-w'))) { state.open = ''; chrome(); }
    const t = e.target.closest('button, a[href^="#s-"], a[href="#yr-history"], a[href="#yr-next"]');
    if (!t) return;
    const d = t.dataset;
    if (t.matches('a[href^="#"]')) { e.preventDefault(); const id = t.getAttribute('href').slice(1); if (id === 'yr-history') state.folds.history = true; if (d.panelgo != null) { state.panel = ''; chrome(); } const el = root.querySelector('#' + id); if (el) { if (el.tagName === 'DETAILS') el.open = true; el.scrollIntoView({ behavior: matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth', block: 'start' }); } return; }
    if (d.retry != null) { failed = null; FILES.forEach(n => { if (state.cur[n] && base[n] && JSON.stringify(state.cur[n].map(strip)) !== base[n] && n !== 'needs' && n !== 'notes') { E.saveFile(state.year, n, state.cur[n].map(strip)); sent.add(n); } }); status(); return; }
    if (d.clash) { settleClash(d.cid, d.clash); return; }
    if (d.clashshow) {
      const el = state.clash && rowEl(state.clash.name, d.clashshow);
      if (el) { const f = el.closest('details'); if (f) f.open = true; el.scrollIntoView({ block: 'center', behavior: matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth' }); el.classList.add('is-clash'); setTimeout(() => el.classList.remove('is-clash'), 2400); }
      return;
    }
    if (d.introopen != null) { state.ov.me.intro = false; state.introClosed = false; render(true); const h = root.querySelector('.yr-intro h2'); if (h) { h.tabIndex = -1; h.focus(); } return; }
    if (d.intro != null) { state.introClosed = true; state.ov.me.intro = true; const el = root.querySelector('.yr-intro'); if (el) el.remove(); call('POST', 'intro', {}).catch(() => {}); const h = root.querySelector('.yr-title'); if (h) { h.tabIndex = -1; h.focus(); } return; }
    if (d.panel != null) { state.panelFrom = t; state.panel = state.panel === d.panel ? '' : d.panel; state.panelErr = ''; chrome(); const b = root.querySelector('#yr-panel-h'); if (b) b.focus(); return; }
    if (d.pub) { publish(d.pub, d.act); return; }
    if (d.campus != null) {
      if (!d.sure && d.campus !== 'changes' && (needsLeft() || needsUnsure())) { state.panel = 'campus'; chrome(); const b = root.querySelector('#yr-panel-h'); if (b) b.focus(); return; }
      state.panel = ''; chrome(); downloadCampus(d.campus); return;
    }
    if (d.tick) { tick(d.tick, t.getAttribute('aria-pressed') !== 'true'); return; }
    if (d.look) { setCheck(d.look, !!d.done, d.also ? d.also.split(',') : [], d.part2); return; }
    if (d.notedone) {
      const h = d.notedone, done = !!d.done, me = state.ov.me || {};
      if (done) coa().notes_done[h] = { by: me.name, at: today() }; else delete coa().notes_done[h];
      chrome(); toast(done ? 'Done' : 'Brought back');
      call('POST', 'note', { hash: h, done, part: state.part }).then(c => { state.ov.coa = c; }, () => refresh());
      return;
    }
    if (d.setowner != null) {
      const pid = d.pid || (part() || {}).id; if (!pid) return;
      state.cur.S['owner_' + pid] = d.setowner; state.open = ''; state.whoOpen = '';
      chrome();
      const f = root.querySelector(part() ? '.yr-more' : '[data-whoopen="' + pid + '"]'); if (f) f.focus();
      toast(d.setowner ? (PARTS.find(x => x.id === pid) || {}).name + ' · ' + d.setowner : 'No owner');
      call('POST', 'owner', { part: pid, owner: d.setowner }).then(() => { pinged(); refresh(); }, () => {});
      return;
    }
    if (d.whoopen != null) { state.whoOpen = state.whoOpen === d.whoopen ? '' : d.whoopen; swap('.yr-who', whoSec()); const f = root.querySelector('.yr-who .yr-owners input'); if (f) f.focus(); return; }
    if (d.duereset != null) { const p = part(); if (!p) return; delete coa().due[p.id]; state.open = ''; chrome(); call('POST', 'due', { part: p.id, date: '' }).then(c => { state.ov.coa = c; refresh(); }, () => {}); return; }
    if (d.open != null) {
      state.open = state.open === d.open ? '' : d.open;
      if (d.open === 'dates') state.pendingDates = { start: state.row.start || '', end: state.row.end || '', endTyped: false };
      if (d.open === '' || d.open === 'place') state.pendingCampus = null;
      if (d.open === '') state.pendingDates = null;
      state.inviteErr = '';
      render(true);
      const f = root.querySelector('.yr-menu button, .yr-inline input, .yr-dates input, .yr-places .yr-place, .yr-owners input, .yr-newcampus input, [data-dueform] input, .yr-people__add input, [data-address] input, .yr-paste textarea');
      if (f && d.open) f.focus();
      return;
    }
    if (d.usefri) { state.pendingDates.start = d.usefri; state.pendingDates.plan = null; redraw('conf'); previewDates(); return; }
    if (d.datesgo != null) {
      const pd = state.pendingDates;
      call('POST', 'dates', { start: pd.start, end: pd.end || '', apply: true }).then(r => { state.open = ''; state.pendingDates = null; reloadYear('Dates set · ' + O.fmtDateSpan(r.start, r.end)); }, e => toast(e.message || 'Not saved'));
      return;
    }
    if (d.place) { if (t.classList.contains('is-on')) { toast('Already chosen'); return; } previewCampus({ venue: d.place }); return; }
    if (d.campusgo != null) {
      const b = Object.assign({}, state.pendingCampus.body, { apply: true });
      call('POST', 'campus', b).then(p => { state.open = ''; state.pendingCampus = null; reloadYear('Campus changed · ' + p.venue); }, e => toast(e.message || 'Not saved'));
      return;
    }
    if (d.campuscancel != null) { state.pendingCampus = null; state.open = 'place'; render(true); return; }
    if (d.campusundo != null) { call('POST', 'campus-restore', {}).then(r => reloadYear('Restored · ' + (r.restored || 'no campus')), e => toast(e.message || 'Not saved')); return; }
    if (d.pickup != null) {
      if (d.early != null && !state.confirmPickup) { state.confirmPickup = true; t.textContent = 'Pick up now'; t.classList.remove('wk-btn--line'); return; }
      call('POST', 'pickup', { force: d.early != null }).then(() => reloadYear('Picked up from ' + state.ov.prev.year), e => toast(e.message || 'Not saved'));
      return;
    }
    if (d.needtpl != null) { needsTemplate(d.needtpl); return; }
    if (d.marksent != null) { const el = root.querySelector('.yr-toast'); if (el) el.hidden = true; markSent(true); return; }
    if (d.needopen != null) {
      state.needsOpen = d.needopen; state.editNeed = ''; state.askNeed = ''; redraw('needs');
      const x = root.querySelector('[data-needopen="' + CSS.escape(d.needopen ? '' : '') + '"]') && (d.needopen ? root.querySelector('.yr-coml li.is-open .yr-coml__b') : null);
      if (x) { x.focus({ preventScroll: true }); x.scrollIntoView({ block: 'start', behavior: matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth' }); }
      try { history.replaceState(null, '', partHref('requests') + (d.needopen ? '&open=' + encodeURIComponent(d.needopen) : '')); } catch (x2) { /* fine */ }
      return;
    }
    const li = t.closest('[data-nid]'), nr = li && state.cur.needs.find(r => r.id === li.dataset.nid);
    if (d.answer != null && nr) {
      if (d.answer === 'notsure') state.askNeed = nr.id;
      answerNeeds([nr], d.answer).catch(() => {});
      redraw('needs');
      const nx = root.querySelector(d.answer === 'notsure' ? '[data-needask] input' : '[data-nid="' + CSS.escape(nr.id) + '"] [data-answer]');
      if (nx) nx.focus({ preventScroll: true });
      return;
    }
    if (d.neededit != null) { state.editNeed = state.editNeed === d.neededit ? '' : d.neededit; redraw('needs'); const f = root.querySelector('.yr-neededit input'); if (f) f.focus(); return; }
    if (d.needask != null) { state.askNeed = ''; redraw('needs'); return; }
    if (d.keepev) { const rows = state.cur.needs.filter(r => r.committee === state.needsOpen && eventKey(r) === d.keepev && !r.answer); answerNeeds(rows, 'keep').catch(() => {}); redraw('needs'); toast(SU.plural(rows.length, 'request') + ' kept'); return; }
    if (d.keepcom) {
      const rows = state.cur.needs.filter(r => !r.answer && r.committee === d.keepcom);
      answerNeeds(rows, 'keep').catch(() => {});
      const cs = needsCommittees(), from = cs.indexOf(d.keepcom), next = cs.slice(from + 1).concat(cs.slice(0, from)).find(c => state.cur.needs.some(r => r.committee === c && !r.answer)) || '';
      state.needsOpen = next; redraw('needs'); chrome();
      const x = next && root.querySelector('.yr-coml li.is-open .yr-coml__b'); if (x) { x.focus({ preventScroll: true }); x.scrollIntoView({ block: 'start' }); }
      toast(d.keepcom + ': ' + SU.plural(rows.length, 'request') + ' kept' + (next ? ' · ' + next + ' next' : ' · all answered'));
      return;
    }
    if (d.addneed || d.addevent) {
      const c = d.addevent || state.needsOpen, proto = d.addneed ? state.cur.needs.find(r => r.committee === c && eventKey(r) === d.addneed) || {} : { for: 'New event' };
      sendNeeds({ add: [{ committee: c, item: 'New item', qty: '1', for: proto.for || '', first_day: proto.first_day || '', last_day: proto.last_day || '', start: proto.start || '', end: proto.end || '', building: proto.building || '', room: proto.room || '' }] })
        .then(r => { state.editNeed = (r.added || [])[0] || ''; redraw('needs'); const f = root.querySelector('.yr-neededit input'); if (f) { f.focus(); f.select(); } }, () => {});
      return;
    }
    if (d.nsup != null) { t.parentNode.querySelectorAll('button').forEach(b => b.setAttribute('aria-pressed', String(b === t && t.getAttribute('aria-pressed') !== 'true'))); return; }
    if (d.upgo != null) { applyUpload(); return; }
    if (d.upcancel != null) { state.upload = null; redraw('needs'); return; }
    if (d.upcom) { state.upload.unknown[d.upcom.slice(6)] = d.v; redraw('needs'); return; }
    if (d.out) { download(d.out); return; }
    if (d.bring != null) { root.querySelector('.yr-file').click(); return; }
    if (d.record != null) { exportRecord(); return; }
    // The packet.
    if (d.addpart != null) {
      const g = state.cur.guide, id = 'part-' + Date.now().toString(36), at = d.addpart ? g.map(r => r.id).lastIndexOf(d.addpart) + 1 : 0;
      g.splice(at, 0, { id, title: 'A new part', summary: '', text: '', _id: newId('gu') });
      touch('file:guide'); redraw('packet');
      const h = root.querySelector('[data-part="' + id + '"] h3'); if (h) { h.focus(); selectAll(h); }
      return;
    }
    if (d.mvpart) {
      const ids0 = partIds(), i = ids0.indexOf(d.mvpart), j = i + (+d.dir);
      if (j < 0 || j >= ids0.length) return;
      ids0.splice(j, 0, ids0.splice(i, 1)[0]);
      state.cur.guide = ids0.reduce((a, id) => a.concat(state.cur.guide.filter(r => r.id === id)), []);
      touch('file:guide'); redraw('packet');
      const b = root.querySelector('[data-mvpart="' + CSS.escape(d.mvpart) + '"][data-dir="' + d.dir + '"]'); if (b && !b.disabled) b.focus(); else { const h = root.querySelector('[data-part="' + CSS.escape(d.mvpart) + '"] h3'); if (h) h.focus(); }
      return;
    }
    if (d.rmpart) { const tt = (state.cur.guide.find(r => r.id === d.rmpart && r.title) || {}).title || 'Part'; state.cur.guide = state.cur.guide.filter(r => r.id !== d.rmpart); touch('file:guide'); flush(); redraw('packet'); toast('“' + tt + '” removed', true); return; }
    if (d.fixfact != null) { const x = factsCheck()[+d.fixfact]; if (x) { const r = state.cur.guide[x.i]; r[x.f] = String(r[x.f]).replace(x.was, x.to); touch('file:guide'); flush(); redraw('packet'); toast('Changed to ' + x.to, true); } return; }
    if (d.helpact) { state.folds['help' + d.helpact] = true; redraw('help'); const f = root.querySelector('[data-fold="help' + CSS.escape(d.helpact) + '"] [data-hopt]'); if (f) f.focus(); return; }
    if (d.addhelp != null) { state.cur.help.push({ need: 'A new card', text: '', phone: '', _id: newId('he') }); touch('file:help'); redraw('help'); const hs = root.querySelectorAll('[data-hf="need"]'), h = hs[hs.length - 1]; if (h) { h.focus(); selectAll(h); } return; }
    if (d.delhelp != null) { const c = state.cur.help.splice(+d.delhelp, 1)[0]; touch('file:help'); flush(); redraw('help'); toast('“' + c.need + '” removed', true); return; }
    if (d.hopt) {
      const [, i, what] = d.hopt.split('.'), c = state.cur.help[+i];
      if (what === 'kind') c.kind = d.v;
      if (what === 'act') { if (d.v === 'call') { c.link = ''; } else if (d.v === 'text') { c.link = /^sms:/.test(c.link || '') ? c.link : 'sms:' + (c.phone || ''); c.phone = ''; } else if (d.v === 'link') { c.link = /^https?:/.test(c.link || '') ? c.link : 'https://'; c.phone = ''; } else { c.link = ''; c.phone = ''; } }
      state.folds['help' + c._id] = true; touch('file:help'); redraw('help'); return;
    }
    if (d.menupaste != null) { state.open = 'menupaste'; redraw('menus'); const f = root.querySelector('.yr-paste textarea'); if (f) f.focus(); return; }
    if (d.menuuse != null) { state.cur.menus = state.menuDraft.rows.map(r => Object.assign({ _id: newId('me') }, r)); state.menuDraft = null; touch('file:menus'); flush(); redraw('menus'); toast('Menus saved', true); return; }
    if (d.menudrop != null) { state.menuDraft = null; redraw('menus'); return; }
    if (d.mockmenu != null) { state.menuDraft = { name: 'a sample menu', rows: [{ day: 'Friday', meal: 'Supper', station: 'Main', items: 'Baked chicken, green beans, rolls' }, { day: 'Saturday', meal: 'Breakfast', station: '', items: 'Eggs, sausage, fruit' }, { day: 'Saturday', meal: 'Lunch', station: 'Grill', items: 'Burgers, chips' }] }; redraw('menus'); return; }
    if (d.addnotice != null) { state.cur.notices.push({ text: '', from: '', to: '', _id: newId('nt'), _new: '1' }); touch('file:notices'); redraw('notices'); const c = root.querySelector('[data-sheet="notices"] tr:last-of-type [data-c], [data-sheet="notices"] tbody tr[data-id] [data-c]'); if (c) c.focus(); return; }
    // Committees.
    if (d.comnew != null || d.comadd) { const names = d.comadd ? d.comadd.split('|') : ['']; names.forEach(name => state.cur.committees.push({ _id: newId('co'), name, contact_email: '', contact_phone: '', heads: '', weekly: 'yes', order: '' })); saveCommittees(); redraw('committees'); if (!d.comadd) { const ins = root.querySelectorAll('[data-comname]'); const f = ins[ins.length - 1]; if (f) f.focus(); } return; }
    if (d.comdel) { const i = state.cur.committees.findIndex(c => c._id === d.comdel); if (i > -1) { const c = state.cur.committees.splice(i, 1)[0]; saveCommittees(); redraw('committees'); toast(c.name + ' removed from the list', true); } return; }
    // Notes for next year.
    if (d.note) { const me = state.ov.me || {}, n = { part: d.note, text: '', _id: newId('no'), by: me.name || '', at: today() }; state.cur.notes.push(n); chrome(); const el = root.querySelector('[data-ni="' + n._id + '"]'); if (el) el.focus(); return; }
    if (d.notedel) { state.cur.notes = state.cur.notes.filter(n => n._id !== d.notedel); touch('note:' + d.notedel); flush(); chrome(); toast('Note removed'); return; }
    // Sheets (tournaments, notices).
    if (d.tog) { const x = rowOf(t); if (!x) return; const col = colOf(x.name, d.tog), on = !valOf(col, x.r); col.set(x.r, on ? 'yes' : ''); t.outerHTML = cell(x.name, col, x.r).replace(/^<td[^>]*>|<\/td>$/g, ''); touch('file:' + x.sp.file); return; }
    if (d.pill) { const x = rowOf(t); if (!x) return; const col = colOf(x.name, d.pill), i = col.pill.indexOf(valOf(col, x.r)); x.r[d.pill] = col.pill[(i + 1) % col.pill.length]; t.textContent = x.r[d.pill]; touch('file:' + x.sp.file); return; }
    if (d.keep2) { const r = state.cur.schedule.find(x => x._id === d.keep2); if (r) { delete r._look; touch('file:schedule'); flush(); render(true); toast('Looks right · ' + r.title, true); const nb = root.querySelector('[data-keep2]'); if (nb) nb.focus(); } return; }
    if (d.del != null) {
      const x = rowOf(t); if (!x) return;
      if (x.name === 'tournaments') { const n = teamsFor(x.r.id); if (n && !d.sure) { t.dataset.sure = '1'; t.classList.add('is-ask'); t.innerHTML = esc(SU.plural(n, 'team') + ' signed up · Cancel tournament'); return; } }
      const list = state.cur[x.sp.file]; list.splice(list.indexOf(x.r), 1);
      touch('file:' + x.sp.file); flush(); redraw(sectionOf(x.name));
      toast('“' + (x.r.title || x.r.role || x.r.name || x.r.text || x.r.code || 'Row') + '” removed', true);
      return;
    }
    if (d.add != null) { const sh = t.closest('[data-sheet]').dataset.sheet, sp = SHEETS[sh]; const r = Object.assign(sp.group ? { [sp.group]: d.add } : {}, { _id: newId(), _new: '1' }); state.cur[sp.file].push(r); touch('file:' + sp.file); redraw(sectionOf(sh)); const c = root.querySelector('[data-sheet="' + sh + '"] tr[data-id="' + r._id + '"] [data-c]'); if (c) c.focus(); return; }
    if (d.cal) { openCal(t); return; }
    if (d.mattress) { state.cur.R.mattress_offered = d.v; touch('R:mattress_offered'); if (d.v === 'no' && state.cur.R.mattress_price) { state.cur.R.mattress_price = ''; touch('R:mattress_price'); } flush(); redraw('reg'); return; }
    if (d.opt) { state.cur.R[d.opt] = d.v; touch('R:' + d.opt); flush(); t.parentNode.querySelectorAll('button').forEach(b => b.setAttribute('aria-pressed', String(b === t))); return; }
    if (d.sopt) {
      state.cur.S[d.sopt] = d.v; touch('S:' + d.sopt); flush(); t.parentNode.querySelectorAll('button').forEach(b => b.setAttribute('aria-pressed', String(b === t)));
      if (/^tool_|^registration_mode$|^tournaments_online$/.test(d.sopt)) render(true);
      return;
    }
    if (d.early) { const ns = String(state.cur.R.early_nights || '').split('|').filter(Boolean), i = ns.indexOf(d.early); if (i > -1) ns.splice(i, 1); else ns.push(d.early); state.cur.R.early_nights = ['Wednesday', 'Thursday'].filter(x => ns.indexOf(x) > -1).join('|'); touch('R:early_nights'); flush(); t.setAttribute('aria-pressed', String(i < 0)); return; }
    if (d.night) { const ns = String(state.cur.R.nights || '').split('|').filter(Boolean), i = ns.indexOf(d.night); if (i > -1) ns.splice(i, 1); else ns.push(d.night); state.cur.R.nights = DAYS.filter(x => ns.indexOf(x) > -1).join('|'); touch('R:nights'); flush(); t.setAttribute('aria-pressed', String(i < 0)); return; }
    // Pins.
    if (d.pinfor) { state.pinFor = d.pinfor; state.pinMsg = ''; render(true); return; }
    if (d.pincancel != null) { state.pinFor = ''; render(true); return; }
    if (d.pinclear) { const r = state.cur.places.find(x => x.code === d.pinclear); if (r) { r.x = ''; r.y = ''; touch('file:places'); render(true); toast(r.name + ' unpinned', true); } return; }
    if (d.pinnow) {
      const r = state.cur.places.find(x => x.code === d.pinnow), c = state.cur.campus;
      if (!r || !navigator.geolocation) { state.pinMsg = 'Location off · allow it in Settings › Privacy › Location'; render(true); return; }
      t.textContent = 'Finding you…';
      navigator.geolocation.getCurrentPosition(pos => {
        const pt = O.map.toMap(c, pos.coords.latitude, pos.coords.longitude), acc = Math.round(pos.coords.accuracy || 0);
        if (!pt || !O.map.onCampus(c, pt, 50)) { state.pinMsg = 'Not on campus'; render(true); return; }
        r.x = pt.x.toFixed(1); r.y = pt.y.toFixed(1); touch('file:places'); state.pinFor = ''; state.pinMsg = ''; render(true); toast(r.name + ' pinned · ±' + acc + ' m', true);
      }, () => { state.pinMsg = 'Location off · allow it in Settings › Privacy › Location'; render(true); }, { enableHighAccuracy: true, timeout: 15000 });
      return;
    }
    if (d.undo != null) undo();
  });
  // A date field's calendar: the phone's own date picker, put back as "May 21".
  function openCal(btn) {
    const inp = btn.parentNode.querySelector('input'), pick = document.createElement('input');
    pick.type = 'date'; pick.className = 'yr-calpick'; pick.value = parseMD(inp.value) || '';
    btn.parentNode.appendChild(pick);
    pick.addEventListener('change', () => { if (pick.value) { inp.value = mdY(pick.value) || pick.value; inp.dispatchEvent(new Event('change', { bubbles: true })); } pick.remove(); inp.focus(); });
    pick.addEventListener('blur', () => setTimeout(() => pick.remove(), 300));
    try { pick.showPicker(); } catch (x) { pick.focus(); }
  }
  const rowOf = el => {
    const tr = el.closest('tr[data-id]'), sh = el.closest('[data-sheet]');
    if (!tr || !sh) return null;
    const name = sh.dataset.sheet;
    return { name, sp: SHEETS[name], r: state.cur[SHEETS[name].file].find(x => x._id === tr.dataset.id) };
  };
  root.addEventListener('toggle', e => { const f = e.target.closest && e.target.closest('[data-fold]'); if (f) state.folds[f.dataset.fold] = f.open; }, true);

  // Typing in the document and the sheets: saved a moment after it stops.
  root.addEventListener('input', e => {
    const t = e.target;
    if (t.matches('[data-c]')) {
      const x = rowOf(t); if (!x || !x.r) return;
      const col = colOf(x.name, t.dataset.c), v = t.textContent.trim();
      if (col.set) col.set(x.r, v); else x.r[col.c] = col.num ? v.replace(/[^\d]/g, '') : v;
      const flag = col.check ? col.check(x.r) : '';
      t.classList.toggle('is-flag', !!flag); if (flag) t.title = flag; else t.removeAttribute('title');
      touch('file:' + x.sp.file); return;
    }
    if (t.matches('[data-gi]')) { state.cur.guide[+t.dataset.gi][t.dataset.gf] = t.textContent; touch('file:guide'); return; }
    if (t.matches('[data-hi]')) { state.cur.help[+t.dataset.hi][t.dataset.hf] = t.textContent.trim(); touch('file:help'); return; }
    if (t.matches('[data-ni]')) { const n = state.cur.notes.find(x => x._id === t.dataset.ni); if (n) { n.text = t.textContent.trim(); touch('note:' + n._id); } return; }
    if (t.matches('[data-pinq]')) { state.pinQ = t.value; const box = root.querySelector('.yr-pins'); if (box) { const tmp = document.createElement('div'); tmp.innerHTML = pinsFold(); const nl = tmp.querySelector('.yr-pins'); if (nl) box.replaceWith(nl); } return; }
    if (t.matches('input[data-k]') && t.getAttribute('aria-invalid') === 'true') markField(t.dataset.k, '');
  });
  // A value committed (leaving the field, or Enter): checked here and on the server, then saved.
  const URL_OK = v => !v || /^https:\/\/[^\s]+\.[^\s]+/.test(v);
  root.addEventListener('change', e => {
    const t = e.target;
    if (t.matches('.yr-file')) { bringFile(t.files[0]); t.value = ''; return; }
    if (t.matches('[data-upmiss]')) { state.upload.drop[t.dataset.upmiss] = t.checked; return; }
    if (t.matches('input[data-tick]')) { tick(t.dataset.tick, t.checked); return; }
    if (t.matches('input[data-mark="sent"]')) { markSent(t.checked); return; }
    if (t.matches('[data-comname]')) { const c = state.cur.committees.find(x => x._id === t.dataset.comname); if (c) { const v = t.value.trim(); if (!c.name) { c.name = v; saveCommittees(); redraw('committees'); } else renameCommittee(c, v); } return; }
    if (t.matches('[data-comcontact]')) { const c = state.cur.committees.find(x => x._id === t.dataset.comcontact), v = t.value.trim(); if (v && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(v)) { t.setAttribute('aria-invalid', 'true'); toast('Not an email: ' + v); return; } t.removeAttribute('aria-invalid'); if (c) { c.contact_email = v; saveCommittees(); } return; }
    if (!t.matches('input[data-k], textarea[data-k]')) return;
    const k = t.dataset.k, kind = t.dataset.kind, v = kind === 'area' ? t.value.split(/\r?\n/).map(x => x.trim().replace(/\|/g, ' ')).filter(Boolean).join('|') : t.value.trim();
    if (/^sched\./.test(k)) { const iso = parseRegDate(v); markField(k, v && !iso ? 'Not a date: try "Feb 25"' : ''); if (iso) t.value = mdY(iso); return; }
    if (k === 'due') return;
    if (/^date\./.test(k)) {
      const iso = parseMD(v, +state.year);
      if (v && !iso) { markField(k, 'Not a date: try "May 28"'); return; }
      const pd = state.pendingDates || (state.pendingDates = { start: state.row.start, end: state.row.end });
      pd[k.slice(5)] = iso; pd.plan = null; if (k === 'date.end') pd.endTyped = true;
      if (k === 'date.end' && pd.start && iso && iso < pd.start) { markField(k, 'After the first day'); return; }
      redraw('conf'); previewDates(); return;
    }
    if (/^reg\./.test(k)) {
      const rk = k.slice(4);
      if (kind === 'date') { const iso = v ? parseRegDate(v) : ''; if (v && !iso) { markField(k, 'Not a date: try "May 21"'); return; } state.cur.R[rk] = iso; t.value = mdY(iso); }
      else if (kind === 'money') { if (v && !/^\d{1,4}(\.\d{2})?$/.test(v.replace(/^\$/, ''))) { markField(k, 'Whole dollars, like 65'); return; } state.cur.R[rk] = v.replace(/^\$/, ''); }
      else if (kind === 'count') { if (v && !/^\d{1,5}$/.test(v)) { markField(k, 'A number, like 120'); return; } state.cur.R[rk] = v; }
      else state.cur.R[rk] = v;
      markField(k, ''); touch('R:' + rk); flush();
      if (MONEY.indexOf(rk) > -1 && regCount()) markField(k, '');
      return;
    }
    if (/^help\./.test(k)) {
      const [, i, f] = k.split('.'), c = state.cur.help[+i];
      if (f === 'phone' && v && !/^[\d\s().+-]{3,20}$/.test(v)) { markField(k, 'A phone number, like 765-555-0100'); return; }
      if (f === 'link' && v && !/^(https:\/\/|sms:|tel:)/.test(v)) { markField(k, 'Starts https://'); return; }
      if (f === 'smsnum' || f === 'smsbody') {
        if (f === 'smsnum' && v && !/^[\d\s().+-]{3,20}$/.test(v)) { markField(k, 'A number, like 226787'); return; }
        const box = t.closest('.yr-help'), num = (f === 'smsnum' ? v : (box.querySelector('[data-k$=".smsnum"]') || {}).value || '').replace(/[^\d+]/g, ''), body = f === 'smsbody' ? v : ((box.querySelector('[data-k$=".smsbody"]') || {}).value || '').trim();
        c.link = 'sms:' + num + (body ? '?&body=' + encodeURIComponent(body) : ''); markField(k, ''); touch('file:help'); return;
      }
      c[f] = v; markField(k, ''); touch('file:help'); return;
    }
    if (k === 'hosts') { state.cur.S.hosts = v; state.row.hosts = v; touch('S:hosts'); touch('Y:hosts'); flush(); return; }
    if (k === 'call_in_number') { if (v && !/^[\d\s().+-]{7,20}$/.test(v)) { markField(k, 'A phone number, like 717-555-0100'); return; } markField(k, ''); state.cur.S[k] = v; touch('S:' + k); flush(); return; }
    if (k === 'call_in_pin') { if (v && !/^\d{1,12}$/.test(v)) { markField(k, 'Numbers only'); return; } markField(k, ''); state.cur.S[k] = v; touch('S:' + k); flush(); return; }
    if (/_url$/.test(k)) { if (!URL_OK(v)) { markField(k, 'A web address, starting https://'); return; } markField(k, ''); state.cur.S[k] = v; touch('S:' + k); flush(); return; }
    state.cur.S[k] = v; touch('S:' + k); flush();
  });
  root.addEventListener('focusout', e => {
    const t = e.target;
    if (t.matches && t.matches('[data-c]')) { const x = rowOf(t); if (x && x.r) { const col = colOf(x.name, t.dataset.c), v = valOf(col, x.r); if (col.get && t.textContent !== v) t.textContent = v; } }
    if (t.matches && t.matches('[data-ni]') && !t.textContent.trim()) {
      const id = t.dataset.ni; state.cur.notes = state.cur.notes.filter(n => n._id !== id); touch('note:' + id); flush();
      setTimeout(chrome, 0);
      return;
    }
    if (t.matches && t.matches('[contenteditable], [data-c]')) flush();
  });
  root.addEventListener('submit', e => {
    const f = e.target;
    e.preventDefault();
    if (f.matches('[data-ownerform]')) { const v = f.querySelector('input').value.trim(), b = document.createElement('button'); b.type = 'button'; b.dataset.setowner = v; b.dataset.pid = f.dataset.ownerform; f.appendChild(b); b.click(); return; }
    if (f.matches('[data-dueform]')) {
      const inp = f.querySelector('[data-k="due"]'), iso = parseMD(inp.value, +state.year) || parseMD(inp.value, +state.year - 1);
      if (inp.value.trim() && !iso) { markField('due', 'Not a date: try "Jan 15"'); return; }
      const p = part(); if (!p) return;
      if (iso) coa().due[p.id] = iso; else delete coa().due[p.id];
      state.open = ''; chrome(); call('POST', 'due', { part: p.id, date: iso || '' }).then(c => { state.ov.coa = c; refresh(); }, () => {});
      return;
    }
    if (f.matches('[data-newcampus]')) { const name = f.venue.value.trim(); if (!name) { f.venue.setAttribute('aria-invalid', 'true'); f.venue.focus(); return; } previewCampus({ new: { name, city: f.city.value.trim(), address: f.address.value.trim() } }); return; }
    if (f.matches('[data-address]')) { state.cur.S.address = f.address.value.trim(); touch('S:address'); flush(); state.open = ''; redraw('campus'); return; }
    if (f.matches('[data-menupasteform]')) { const rows = menuFromText(f.querySelector('textarea').value); if (!rows.length) { toast('Nothing in it looked like a menu · a day, then a meal, then its dishes'); return; } state.open = ''; state.menuDraft = { name: 'the pasted menu', rows }; redraw('menus'); return; }
    if (f.matches('[data-needask]')) { const r = state.cur.needs.find(x => x.id === f.dataset.needask), q0 = f.q.value.trim(); state.askNeed = ''; if (r) answerNeeds([r], 'notsure', { question: q0 }).catch(() => {}); redraw('needs'); return; }
    if (f.matches('[data-needform]')) {
      const key = f.dataset.needform, val = n => f.elements[n] ? f.elements[n].value.trim() : null, fields = {};
      ['item', 'qty', 'for', 'start', 'end', 'notes'].forEach(n => { if (val(n) != null) fields[n] = n === 'qty' ? val(n).replace(/[^\d]/g, '') : val(n); });
      if (val('where') != null) Object.assign(fields, splitWhere(val('where')));
      if (val('days') != null) { const [a, b] = val('days').split(/\s*(?:–|-|\bto\b|\bthrough\b)\s*/i); fields.first_day = dayName(a) || (a || '').trim(); fields.last_day = b ? dayName(b) || b.trim() : ''; }
      const sup = f.querySelector('[data-nsup][aria-pressed="true"]'); if (f.querySelector('[data-nsup]')) fields.supplied_by = sup ? sup.dataset.v : '';
      const rows = /^ev:/.test(key) ? state.cur.needs.filter(r => r.committee === state.needsOpen && eventKey(r) === key.slice(3)) : state.cur.needs.filter(r => r.id === key);
      state.editNeed = '';
      const ops = rows.map(r => ({ id: r.id, fields, answer: r.answer === 'new' ? 'new' : 'change' }));
      rows.forEach(r => Object.assign(r, fields));
      redraw('needs');
      sendNeeds({ ops }).then(() => toast(rows.length > 1 ? SU.plural(rows.length, 'request') + ' changed' : 'Changed'), () => {});
      return;
    }
  });

  // Keys: Enter and ↑ ↓ move between rows like a sheet; Enter commits a field; ⌘Z undoes.
  document.addEventListener('keydown', e => {
    const mod = e.metaKey || e.ctrlKey;
    if (mod && !e.altKey && (e.key === 'z' || e.key === 'Z') && !(e.target.matches && e.target.matches('input, textarea'))) { e.preventDefault(); if (e.shiftKey) redo(); else undo(); return; }
    if (e.key === 'Escape') {
      if (state.see) { closeSee(true); return; }
      if (state.panel) { state.panel = ''; chrome(); return; }
      if (state.open && !(e.target.closest && e.target.closest('[contenteditable]'))) { state.open = ''; state.pendingDates = null; state.pendingCampus = null; render(true); return; }
    }
    const t = e.target;
    if (!root.contains(t)) return;
    if (t.matches('input[data-k]') && e.key === 'Enter' && !t.closest('form')) { e.preventDefault(); t.blur(); return; }
    if (t.matches('[data-gf="text"]') && e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); splitPara(t); return; }
    if (t.matches('[data-gf="text"]') && e.key === 'Backspace' && caret(t) === 0 && !getSelection().toString()) { if (joinPara(t)) e.preventDefault(); return; }
    if (t.matches('[data-gf="title"], [data-gf="summary"], [data-hi], [data-ni]') && e.key === 'Enter') { e.preventDefault(); t.blur(); return; }
    if (!t.matches('[data-c]')) return;
    const tr = t.closest('tr'), c = t.dataset.c, table = t.closest('table');
    const go = dir => {
      const rows = Array.from(table.querySelectorAll('tr[data-id]')), i = rows.indexOf(tr), nx = rows[i + dir];
      if (nx) { const cell0 = nx.querySelector('[data-c="' + c + '"]'); if (cell0) { cell0.focus(); caretEnd(cell0); } return true; }
      return false;
    };
    if (e.key === 'Enter') { e.preventDefault(); if (!go(1)) t.blur(); }
    else if (e.key === 'ArrowDown') { e.preventDefault(); go(1); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); go(-1); }
    else if (e.key === 'Escape') t.blur();
  });
  function splitPara(el) {
    const i = +el.dataset.gi, g = state.cur.guide, r = g[i], at = caret(el), full = el.textContent;
    r.text = full.slice(0, at).replace(/\s+$/, '');
    g.splice(i + 1, 0, { id: r.id, title: '', summary: '', text: full.slice(at).replace(/^\s+/, ''), _id: newId('gu') });
    touch('file:guide'); flush(); redraw('packet');
    const nx = root.querySelector('[data-gi="' + (i + 1) + '"][data-gf="text"]');
    if (nx) { nx.focus(); const s = getSelection(), rg = document.createRange(); rg.setStart(nx.firstChild || nx, 0); rg.collapse(true); s.removeAllRanges(); s.addRange(rg); }
  }
  // Backspace at the start of a paragraph joins it to the one before (as in a document).
  function joinPara(el) {
    const i = +el.dataset.gi, g = state.cur.guide, r = g[i], prev = g[i - 1];
    if (!prev || prev.id !== r.id || r.title) return false;
    const at = (prev.text || '').length;
    prev.text = (prev.text || '') + (prev.text && r.text ? ' ' : '') + (r.text || '');
    g.splice(i, 1); touch('file:guide'); flush(); redraw('packet');
    const pv0 = root.querySelector('[data-gi="' + (i - 1) + '"][data-gf="text"]');
    if (pv0) { pv0.focus(); const s = getSelection(), rg = document.createRange(); const node = pv0.firstChild || pv0; try { rg.setStart(node, Math.min(at, (node.textContent || '').length)); } catch (x) { rg.selectNodeContents(pv0); rg.collapse(false); } rg.collapse(true); s.removeAllRanges(); s.addRange(rg); }
    return true;
  }
  // Pasting: several lines into a sheet become rows; anything else pastes as plain text.
  root.addEventListener('paste', e => {
    const t = e.target.closest && e.target.closest('[data-c]');
    const txt = (e.clipboardData || window.clipboardData).getData('text');
    if (t && /[\t\n]/.test(txt.trim())) {
      e.preventDefault();
      const x = rowOf(t), sp = x.sp, g = sp.group ? x.r[sp.group] : '';
      const rows = txt.split(/\r?\n/).filter(l => l.trim()).map(l => { const c = l.split('\t'), r = sp.group ? { [sp.group]: g } : {}; sp.cols.forEach((col, i) => { const v = (c[i] || '').trim(); if (!v) return; if (col.pill) r[col.c] = audLabel(v); else if (col.set) col.set(r, v); else r[col.c] = v; }); return Object.assign(r, { _id: newId(), _new: '1' }); });
      const list = state.cur[sp.file], at = list.indexOf(x.r);
      list.splice(at + 1, 0, ...rows); touch('file:' + sp.file); flush(); redraw(sectionOf(x.name));
      toast(SU.plural(rows.length, 'row') + ' added', true);
      return;
    }
    if (e.target.closest && e.target.closest('[contenteditable]')) { e.preventDefault(); document.execCommand('insertText', false, txt.replace(/\r?\n/g, ' ')); }
  });
  // A file dropped anywhere on the page goes to the part that's open.
  let depth = 0;
  root.addEventListener('dragenter', e => { if (Array.from(e.dataTransfer.types || []).indexOf('Files') < 0) return; depth++; const o = root.querySelector('.yr-dropover'); if (o) o.hidden = false; });
  root.addEventListener('dragleave', e => { if (Array.from(e.dataTransfer.types || []).indexOf('Files') < 0) return; depth = Math.max(0, depth - 1); const o = root.querySelector('.yr-dropover'); if (!depth && o) o.hidden = true; });
  root.addEventListener('dragover', e => { if (Array.from(e.dataTransfer.types || []).indexOf('Files') > -1) e.preventDefault(); });
  root.addEventListener('drop', e => { if (!e.dataTransfer.files.length) return; e.preventDefault(); depth = 0; const o = root.querySelector('.yr-dropover'); if (o) o.hidden = true; bringFile(e.dataTransfer.files[0]); });
  addEventListener('pagehide', flush);
  addEventListener('beforeunload', e => { flush(); if (own) { e.preventDefault(); e.returnValue = ''; } });

  /* ------------------------------------------------------------ start */

  // While the year loads: the page's shape, not "Loading…".
  function skeleton() {
    const p = part();
    root.innerHTML = '<div class="wk yr ws yr--' + (p ? 'part' : 'home') + ' is-loading" aria-busy="true"><header class="ws-bar ws-bar--year"><div class="ws-bar__in"><p class="yr-crumb"><span class="yr-crumb__t">Committee of Arrangements</span></p></div></header>' +
      (p ? '<div class="yr-body yr-body--part"><div class="yr-doc"><div class="yr-sheetpage"><span class="yr-sk yr-sk--h"></span><span class="yr-sk yr-sk--box"></span><span class="yr-sk yr-sk--box"></span></div></div></div>'
        : '<div class="yr-home"><span class="yr-sk yr-sk--h"></span><span class="yr-sk yr-sk--line"></span><ol class="yr-parts">' + PARTS.map(() => '<li><span class="yr-card yr-sk--card"></span></li>').join('') + '</ol></div>') + '<p class="ogc-sr" role="status">Loading</p></div>';
  }
  // An address with a place on the page (#pp-meals, #s-help: the printouts' Edit): there, once drawn,
  // its fold opened.
  function arrive() {
    const id = decodeURIComponent(location.hash.slice(1));
    const el = id && /^[\w-]+$/.test(id) ? root.querySelector('#' + id) : null;
    if (!el) return;
    const f = el.closest('details'); if (f) f.open = true;
    el.scrollIntoView({ block: 'start' });
    if (!el.hasAttribute('tabindex')) el.setAttribute('tabindex', '-1');
    el.focus({ preventScroll: true });
  }
  function start() {
    skeleton();
    load().then(() => { render(); arrive(); }).catch(err => {
      const y0 = q.get('year') || '';
      root.innerHTML = '<div class="wk yr ws"><div class="ws ws--center"><div class="adm-card"><p class="wk-kicker">Committee of Arrangements</p><h1 class="adm-card__h">' + esc(err.none ? 'No year yet' : navigator.onLine ? 'Couldn’t load ' + y0 : 'Offline') + '</h1>' +
        '<p class="wk-sheet__btns"><button type="button" class="wk-btn wk-btn--line" data-reload>Retry</button></p></div></div></div>';
      const b = root.querySelector('[data-reload]'); if (b) b.addEventListener('click', () => location.reload());
      console.error(err);
    });
  }
  start();
})();
