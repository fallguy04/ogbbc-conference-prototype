/*
 * year-xlsx.js — Excel files in and out, with nothing to install (docs/17: "everything prints, and
 * downloads to Excel"; Excel turns days into "7-May" and drops leading zeros in a CSV).
 *
 *   OGC.xlsx.write([{ name, rows: [[cell, …], …], widths?: [chars…] }]) → Blob (.xlsx)
 *   OGC.xlsx.read(arrayBuffer) → Promise of the first sheet's rows, as text: [[cell, …], …]
 *
 * Writing: a zip with its parts stored (no compression), cells as inline text, so a number stays as
 * typed ("007") and a formula is never made (every cell is text). Reading: the zip's parts inflated
 * with the browser's own DecompressionStream, shared strings and inline strings both read.
 */
(function () {
  'use strict';
  const O = window.OGC = window.OGC || {};
  const enc = new TextEncoder();

  /* ------------------------------------------------------------ zip (stored) */

  const CRC = (() => { const t = new Uint32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
  const crc32 = b => { let c = 0xFFFFFFFF; for (let i = 0; i < b.length; i++) c = CRC[(c ^ b[i]) & 0xFF] ^ (c >>> 8); return (c ^ 0xFFFFFFFF) >>> 0; };
  function zip(files) {
    const parts = [], dir = [];
    let off = 0;
    files.forEach(f => {
      const name = enc.encode(f.name), data = typeof f.data === 'string' ? enc.encode(f.data) : f.data, crc = crc32(data);
      const h = new DataView(new ArrayBuffer(30));
      h.setUint32(0, 0x04034b50, true); h.setUint16(4, 20, true); h.setUint16(6, 0x0800, true); h.setUint16(8, 0, true);
      h.setUint32(14, crc, true); h.setUint32(18, data.length, true); h.setUint32(22, data.length, true); h.setUint16(26, name.length, true);
      parts.push(new Uint8Array(h.buffer), name, data);
      const c = new DataView(new ArrayBuffer(46));
      c.setUint32(0, 0x02014b50, true); c.setUint16(4, 20, true); c.setUint16(6, 20, true); c.setUint16(8, 0x0800, true);
      c.setUint32(16, crc, true); c.setUint32(20, data.length, true); c.setUint32(24, data.length, true); c.setUint16(28, name.length, true); c.setUint32(42, off, true);
      dir.push(new Uint8Array(c.buffer), name);
      off += 30 + name.length + data.length;
    });
    const size = dir.reduce((n, p) => n + p.length, 0), e = new DataView(new ArrayBuffer(22));
    e.setUint32(0, 0x06054b50, true); e.setUint16(8, files.length, true); e.setUint16(10, files.length, true); e.setUint32(12, size, true); e.setUint32(16, off, true);
    return new Blob(parts.concat(dir, [new Uint8Array(e.buffer)]), { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
  }

  /* ------------------------------------------------------------ writing */

  const x = s => String(s == null ? '' : s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c]).replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, '');
  const col = n => { let s = ''; n++; while (n) { const m = (n - 1) % 26; s = String.fromCharCode(65 + m) + s; n = Math.floor((n - 1) / 26); } return s; };
  function sheetXml(rows, widths, bold) {
    const cols = widths && widths.length ? '<cols>' + widths.map((w, i) => '<col min="' + (i + 1) + '" max="' + (i + 1) + '" width="' + w + '" customWidth="1"/>').join('') + '</cols>' : '';
    const body = rows.map((r, i) => '<row r="' + (i + 1) + '">' + r.map((v, j) => v == null || v === '' ? '' :
      '<c r="' + col(j) + (i + 1) + '" t="inlineStr"' + (i === 0 && bold ? ' s="1"' : '') + '><is><t xml:space="preserve">' + x(v) + '</t></is></c>').join('') + '</row>').join('');
    return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">' +
      (bold ? '<sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews>' : '') + cols + '<sheetData>' + body + '</sheetData></worksheet>';
  }
  function write(sheets) {
    const n = sheets.length, safe = s => String(s || 'Sheet').replace(/[\\/?*[\]:]/g, ' ').slice(0, 31);
    const files = [
      { name: '[Content_Types].xml', data: '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>' +
        sheets.map((s, i) => '<Override PartName="/xl/worksheets/sheet' + (i + 1) + '.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>').join('') + '</Types>' },
      { name: '_rels/.rels', data: '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>' },
      { name: 'xl/workbook.xml', data: '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>' +
        sheets.map((s, i) => '<sheet name="' + x(safe(s.name)) + '" sheetId="' + (i + 1) + '" r:id="rId' + (i + 1) + '"/>').join('') + '</sheets></workbook>' },
      { name: 'xl/_rels/workbook.xml.rels', data: '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' +
        sheets.map((s, i) => '<Relationship Id="rId' + (i + 1) + '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet' + (i + 1) + '.xml"/>').join('') +
        '<Relationship Id="rId' + (n + 1) + '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>' },
      { name: 'xl/styles.xml', data: '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="2"><font><sz val="11"/><name val="Calibri"/></font><font><b/><sz val="11"/><name val="Calibri"/></font></fonts><fills count="2"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill></fills><borders count="1"><border/></borders><cellStyleXfs count="1"><xf/></cellStyleXfs><cellXfs count="2"><xf numFmtId="49" applyNumberFormat="1"/><xf numFmtId="49" fontId="1" applyFont="1" applyNumberFormat="1"/></cellXfs></styleSheet>' }
    ];
    sheets.forEach((s, i) => files.push({ name: 'xl/worksheets/sheet' + (i + 1) + '.xml', data: sheetXml(s.rows, s.widths, s.bold !== false) }));
    return zip(files);
  }

  /* ------------------------------------------------------------ reading */

  async function inflate(bytes) {
    const ds = new DecompressionStream('deflate-raw');
    const out = new Response(new Blob([bytes]).stream().pipeThrough(ds));
    return new Uint8Array(await out.arrayBuffer());
  }
  async function unzip(buf) {
    const b = new Uint8Array(buf), v = new DataView(buf), out = {};
    let e = b.length - 22;
    while (e >= 0 && v.getUint32(e, true) !== 0x06054b50) e--;
    if (e < 0) throw new Error('Not an Excel file');
    let p = v.getUint32(e + 16, true);
    const n = v.getUint16(e + 10, true), dec = new TextDecoder();
    for (let i = 0; i < n; i++) {
      if (v.getUint32(p, true) !== 0x02014b50) break;
      const method = v.getUint16(p + 10, true), csize = v.getUint32(p + 20, true), nl = v.getUint16(p + 28, true), xl = v.getUint16(p + 30, true), cl = v.getUint16(p + 32, true), lo = v.getUint32(p + 42, true);
      const name = dec.decode(b.subarray(p + 46, p + 46 + nl));
      const start = lo + 30 + v.getUint16(lo + 26, true) + v.getUint16(lo + 28, true), data = b.subarray(start, start + csize);
      out[name] = () => method === 0 ? Promise.resolve(data) : inflate(data);
      p += 46 + nl + xl + cl;
    }
    return out;
  }
  const xmlOf = async (parts, name) => parts[name] ? new DOMParser().parseFromString(new TextDecoder().decode(await parts[name]()), 'application/xml') : null;
  const colIdx = ref => { const m = /^([A-Z]+)/.exec(ref || ''); if (!m) return -1; let n = 0; for (const ch of m[1]) n = n * 26 + ch.charCodeAt(0) - 64; return n - 1; };
  const textOf = el => Array.from(el.getElementsByTagName('t')).map(t => t.textContent).join('');
  async function read(buf) {
    const parts = await unzip(buf);
    const ss = await xmlOf(parts, 'xl/sharedStrings.xml'), shared = ss ? Array.from(ss.getElementsByTagName('si')).map(textOf) : [];
    // The first sheet in the workbook's order.
    let sheet = 'xl/worksheets/sheet1.xml';
    const wb = await xmlOf(parts, 'xl/workbook.xml'), rels = await xmlOf(parts, 'xl/_rels/workbook.xml.rels');
    if (wb && rels) {
      const first = wb.getElementsByTagName('sheet')[0], rid = first && (first.getAttribute('r:id') || first.getAttributeNS('http://schemas.openxmlformats.org/officeDocument/2006/relationships', 'id'));
      const rel = Array.from(rels.getElementsByTagName('Relationship')).find(r => r.getAttribute('Id') === rid);
      if (rel) sheet = 'xl/' + rel.getAttribute('Target').replace(/^\/?xl\//, '').replace(/^\//, '');
    }
    const doc = await xmlOf(parts, sheet);
    if (!doc) throw new Error('No sheet in it');
    const rows = [];
    Array.from(doc.getElementsByTagName('row')).forEach(r => {
      const ri = (+r.getAttribute('r') || rows.length + 1) - 1, line = [];
      Array.from(r.getElementsByTagName('c')).forEach((c, k) => {
        const t = c.getAttribute('t'), i = c.getAttribute('r') ? colIdx(c.getAttribute('r')) : k;
        const vEl = c.getElementsByTagName('v')[0];
        let val = t === 's' ? shared[+(vEl ? vEl.textContent : 0)] || '' : t === 'inlineStr' ? textOf(c) : vEl ? vEl.textContent : '';
        // A date Excel stored as a number (a "Days" or "Opens" cell typed as a date): as "May 7".
        const s = +c.getAttribute('s');
        if (t !== 's' && t !== 'inlineStr' && t !== 'str' && /^\d{5}(\.\d+)?$/.test(val) && s) {
          const d = new Date(Date.UTC(1899, 11, 30) + Math.round(+val * 86400000));
          val = d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', timeZone: 'UTC' });
        }
        line[i] = val;
      });
      rows[ri] = Array.from(line, v => v == null ? '' : v);
    });
    return Array.from(rows, r => r || []);
  }

  O.xlsx = { write, read };
})();
