/*
 * lodging.js — Lodging's page (lodging area, Oct 10): the frame, the year's data and the saving that
 * every tab shares. The tabs draw themselves (lodging-board.js: Rooms; lodging-lists.js: Youngfolks,
 * Campers, Check-in; lodging-import.js: Import), the planner and the checks are in lodging-plan.js.
 *
 *   ?year=2027              the year (a member's own; a year that isn't there says so, never another's)
 *   ?view=yf|campers|checkin|import
 *   ?as-of=YYYY-MM-DD       a preview date (local site and webmasters only)
 *
 * Households are the year's registrations (O.records, the register area's). What Lodging adds lives on
 * the server, one row per household, Youngfolk or room (module-lodging.php), each saved as it's made
 * with a version: Undo and ⌘Z put a change back (after a reload too), and a change someone else made
 * first is shown, never overwritten. Nothing is kept only in this browser.
 */
(function () {
  'use strict';
  const O = window.OGC, esc = O.esc, SU = O.signups, W = window.OGC_WP || {};
  const root = document.getElementById('ogc-lodging');
  const BASE = root.dataset.base;
  const q = new URLSearchParams(location.search);
  const svg = d => '<svg class="wk-i" viewBox="0 0 24 24" aria-hidden="true"><path d="' + d + '" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  const I = {
    check: svg('m5.5 12.5 4 4 9-9'), close: svg('m6.5 6.5 11 11M17.5 6.5l-11 11'),
    print: svg('M7 9V4h10v5M7 17H5a1.5 1.5 0 0 1-1.5-1.5v-5A1.5 1.5 0 0 1 5 9h14a1.5 1.5 0 0 1 1.5 1.5v5A1.5 1.5 0 0 1 19 17h-2M7 14h10v6H7z'),
    down: svg('M12 4v10.5M7.5 10 12 14.5 16.5 10M5 19.5h14'),
    up: svg('M12 15.5V5M7.5 9.5 12 5l4.5 4.5M5 19.5h14'),
    info: svg('M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18zM12 11v5.5M12 7.6v.1'),
    grip: svg('M9 6h.01M15 6h.01M9 12h.01M15 12h.01M9 18h.01M15 18h.01'),
    phone: svg('M5 4.5h3.5l1.5 4-2 1.5a11 11 0 0 0 6 6l1.5-2 4 1.5V19a1.5 1.5 0 0 1-1.5 1.5A15.5 15.5 0 0 1 3.5 6 1.5 1.5 0 0 1 5 4.5z'),
    mail: svg('M4 6.5h16v11H4zM4.5 7l7.5 6 7.5-6'),
    search: svg('M10.5 17a6.5 6.5 0 1 0 0-13 6.5 6.5 0 0 0 0 13zM15.5 15.5 20 20'),
    plus: svg('M12 5v14M5 12h14'),
    note: svg('M5 4.5h10l4 4v11H5zM15 4.5v4h4M8 12.5h8M8 16h5'),
    key: svg('M14.5 9.5a4 4 0 1 1-1.2-2.9M13.3 6.6 20 13.3l-1.8 1.8-1.5-1.5-1.5 1.5-1.5-1.5'),
    back: svg('M14.5 5.5 8 12l6.5 6.5')
  };
  const VIEWS = [['rooms', 'Rooms'], ['yf', 'Youngfolks'], ['campers', 'Campers'], ['checkin', 'Check-in']];

  const S = {
    year: q.get('year') || '', view: q.get('view') || 'rooms', asOf: (q.get('as-of') || '').slice(0, 10),
    row: null, model: null, cfg: {}, settings: {}, rooms: [], floors: [], plans: {}, campus: null,
    hh: [], byRid: {}, rows: {}, ver: {}, undo: [], phase: {}, me: '', seen: '', prev: null, carry: null, numbers: null, imported: null,
    loaded: false, pending: 0, ui: {}
  };
  const L = { S, I, esc, SU, O, views: {}, root };
  L.lateOk = () => !(S.phase && S.phase.cleared);
  O.lodging = L;

  /* ================================================================ words */

  const plural = SU.plural;
  L.plural = plural;
  L.first = n => String(n || '').trim().split(/\s+/)[0];
  L.money = cents => SU.money((+cents || 0) / 100);
  L.md = iso => iso ? O.fmtDate(String(iso).slice(0, 10), 'mdShort') : '';
  L.time = at => {
    if (!at) return '';
    const d = new Date(String(at).replace(' ', 'T') + (/Z|[+-]\d\d:?\d\d$/.test(at) ? '' : 'Z'));
    return isNaN(d) ? '' : d.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', timeZone: S.model && S.model.tz || 'America/Indiana/Indianapolis' });
  };
  L.when = at => at ? L.md(String(at).slice(0, 10)) + (String(at).length > 10 ? ', ' + L.time(at) : '') : '';
  // "Since Tuesday" / "Since Mar 9".
  L.since = at => {
    if (!at) return '';
    const d = String(at).slice(0, 10), days = O.daysBetween ? O.daysBetween(d, S.phase.today) : 99;
    return days <= 6 && days >= 1 ? O.fmtDate(d, 'weekday') : L.md(d);
  };
  L.floorName = n => O.map ? O.map.floorName(n) : (+n === 1 ? 'Ground floor' : 'Floor ' + n);
  L.hallShort = h => String(h || '').replace(/\s+Hall$/i, '');
  L.roomWords = id => { const r = L.room(id); return r ? L.hallShort(r.hall) + ' ' + r.num : String(id).replace('|', ' '); };
  // "Carmin 209 and 210" / "Carmin 209, Reed 101".
  L.roomsWords = ids => {
    const by = [];
    (ids || []).map(L.room).filter(Boolean).forEach(r => { let g = by.find(x => x.hall === r.hall); if (!g) by.push(g = { hall: r.hall, nums: [] }); g.nums.push(r.num); });
    return by.map(g => L.hallShort(g.hall) + ' ' + (g.nums.length === 2 ? g.nums.join(' and ') : g.nums.join(', '))).join(' · ');
  };
  L.nightSpan = ns => SU.nightSpan(ns || [], SU.nightsOf(S.cfg)).replace('–', '–');
  // Nights only when they aren't the regular ones.
  L.someNights = ns => { const main = SU.mainNights(S.cfg); return ns && ns.length && ns.join('|') !== main.join('|') ? L.nightSpan(ns) : ''; };
    // Payment as the Form says it, or as the site's own ledger has it: "Pending · on the Form".
    L.payWords = h => {
      if (h.source === 'form') return h.formPay === 'paid' ? 'Paid · on the Form' : h.formPay === 'pending' ? 'Pending · on the Form' : h.formPay ? (h.formPayText || 'See the Form') + ' · on the Form' : 'Payment · on the Form';
      const m = h.money;
      return m && m.due > 0 ? L.money(m.due) + (m.check >= m.due ? ' · check to come' : ' due') : m ? 'Paid' : '';
    };
    // What the desk should collect or ask about: "$65 due", "Pending · on the Form"; '' when settled.
    L.owes = h => h.source === 'form' ? (h.formPay === 'pending' ? 'Pending · on the Form' : '') : (h.money && h.money.due > 0 ? L.payWords(h) : '');
    // An (i) that works by tap, keyboard and screen reader, not only by hover: a button that shows its
    // note in line (polish 1: nothing for a newcomer hides behind a hover).
    L.info = (text, key) => {
      const k = key || String(text).slice(0, 40), open = !!(S.ui.info && S.ui.info[k]);
      return '<button type="button" class="lod-i" data-info="' + esc(k) + '" aria-expanded="' + open + '" aria-label="' + (open ? 'Hide note' : 'More') + '">' + I.info + '</button>' +
        '<span class="lod-inote"' + (open ? '' : ' hidden') + '>' + esc(text) + '</span>';
    };

  /* ================================================================ households */

  const MOBILITY = /\b(walker|wheel\s?chair|scooter|cane|crutches|can'?t (do |climb |manage )?stairs|no stairs|knee|hip replacement)\b/i;
  const NOT = /\b(no|not|without|doesn'?t (need|use)) (a )?(walker|wheel\s?chair|scooter|cane)\b/i;
  // A registration as the board sees it.
  function norm(d) {
    const s = d.stay || {}, people = (d.people || []).filter(p => p.name);
    const kind = p => p.kind || (p.yf ? 'yf' : p.band === 'adult' && !p.preteen ? 'adult' : 'child');
    const inHall = p => !!p.yf && (s.type === 'yf' || p.sleeps !== 'family');
    const adults = people.filter(p => kind(p) === 'adult');
    const sur = String((d.household && (d.household.name || '')) || '').replace(/^the\s+/i, '').replace(/\s+(family|household)$/i, '').trim() || String(d.household && d.household.contact || '').split(/\s+/).pop() || 'Household';
    const firsts = adults.map(p => L.first(p.name));
    const fl = firsts.length ? (firsts.length === 1 ? firsts[0] : firsts.slice(0, -1).join(', ') + ' and ' + firsts[firsts.length - 1]) : '';
    const note = String(s.needs || '').trim();
    const rid = String(d.rid || d.id || '');
    return {
      rid, d, sur, firsts: fl,
      label: sur + (fl ? ' · ' + fl : ''),           // "Hammond · Levi and Ruth" (one form everywhere)
      short: (firsts[0] ? firsts[0].charAt(0) + '. ' : '') + sur,   // "L. Hammond" (the plan)
      type: s.type || 'dorm', status: d.status || 'registered',
      active: (s.type || 'dorm') === 'dorm' && d.status !== 'cancelled',
      gone: d.status === 'cancelled',
      people, adults, kind, inHall,
      inRooms: people.filter(p => !inHall(p)), yfs: people.filter(inHall),
      sleepers: people.filter(p => !inHall(p) && p.band !== 'baby'),
      nights: s.nights || [], asked: s.type === 'dorm' ? Math.max(1, +s.rooms || 1) : 0,
      ground: !!s.ground, walker: !!s.walker || (MOBILITY.test(note) && !NOT.test(note)), walkerFromNote: !s.walker && MOBILITY.test(note) && !NOT.test(note),
      nearW: !!s.nearW, nearM: !!s.nearM, nearText: String(s.near || '').trim(), note,
      linens: +s.linens || 0, mattresses: +s.mattresses || 0,
      source: d.source || 'online', at: d.created || d.at || '', sample: !!d.sample,
      money: d.money || null, phone: (d.household && d.household.phone) || '', email: (d.household && d.household.email) || '',
            // What the Google Form said about payment, as it said it ('' when its file had no such column).
            formPay: d.source === 'form' ? String((d.form && d.form.pay) || '') : '', formPayText: String((d.form && d.form.payText) || ''),
      mine: !!d.mine
    };
  }
  L.norm = norm;
  function buildHouseholds() {
    const list = SU.households(S.year, S.cfg).map(norm).filter(h => h.rid);
    S.hh = list.sort((a, b) => a.sur.localeCompare(b.sur) || a.firsts.localeCompare(b.firsts));
    S.byRid = {};
    S.hh.forEach(h => { S.byRid[h.rid] = h; });
    // Same surname twice: the second line says which (the board never relies on a surname alone).
    const n = {};
    S.hh.forEach(h => { n[h.sur] = (n[h.sur] || 0) + 1; });
    S.hh.forEach(h => { h.common = n[h.sur] > 1; });
  }
  L.byRid = rid => S.byRid[rid] || null;
  L.dorm = () => S.hh.filter(h => h.active);

  /* ================================================================ rows (Lodging's own, on the server) */

  L.data = key => (S.rows[key] && S.rows[key].data) || null;
  L.hrow = h => L.data('hh:' + (h.rid || h)) || {};
  L.given = h => { const r = L.hrow(h); return (r.rooms || []).filter(id => L.room(id)); };
  L.older = h => !!L.hrow(h).older;
  L.firstGroup = h => h.walker || h.ground || L.older(h);
  // A room's own facts: this year's, or carried from the last year at this campus.
  L.fact = id => Object.assign({}, (S.carry && S.carry.rooms && S.carry.rooms[id]) || {}, L.data('room:' + id) || {});
  L.room = id => S.roomBy[id] || null;
  L.beds = id => +(L.fact(id).beds) || (L.room(id) || {}).beds || 2;
  // Rooms given to households in dorm rooms now (a household gone to the camper lot frees its rooms).
  L.assign = () => {
    const a = {};
    L.dorm().forEach(h => { const g = L.given(h); if (g.length) a[h.rid] = g; });
    return a;
  };
  // Who has each room: { roomId: rid } (Youngfolks' rooms as "yf").
  L.taken = except => {
    const t = {};
    L.dorm().forEach(h => { if (h.rid !== except) L.given(h).forEach(id => { t[id] = h.rid; }); });
    Object.keys(S.rows).forEach(k => { if (/^yf:/.test(k) && S.rows[k].data && S.rows[k].data.room) t[S.rows[k].data.room] = 'yf'; });
    return t;
  };

  /* ================================================================ talking to the server */

  const asOf = () => S.asOf ? (S.asOf.length === 10 ? '?as_of=' + S.asOf : '') : '';
  L.api = (method, path, body) => W.api(method, 'years/' + S.year + '/lodging' + path + (method === 'GET' || asOf() ? asOf() : ''), body);

  // Change rows together. Shown at once; saved in order; a refusal puts the page back as the server
  // has it and says why. ops: [{ key, data }] (data null removes). o.label: the toast's words.
  // S.ver: each row's version as the server last said; pend: changes not answered yet, per row.
  let chain = Promise.resolve();
  const pend = {};
  const take = rows => Object.keys(rows || {}).forEach(k => {
    const r = rows[k];
    S.ver[k] = r ? r.v : 0;
    if (pend[k]) return;                       // a later change of this row is still on its way
    if (r) S.rows[k] = r; else delete S.rows[k];
  });
  L.take = take;
  L.save = function (ops, o) {
  o = o || {};
  // After the Conference rooms no longer move; the desk (o.late) and notes go on until names are cleared.
  if (L.ro && !(o.late && L.lateOk())) return Promise.resolve(false);
  S.changed = true;
    const before = {};
    ops.forEach(op => {
      before[op.key] = S.rows[op.key] || null;
      pend[op.key] = (pend[op.key] || 0) + 1;
      if (op.data == null) delete S.rows[op.key];
      else S.rows[op.key] = { data: op.data, v: S.ver[op.key] || 0, by: S.me, at: '' };
    });
    S.pending++;
    status('saving');
    if (!o.quiet) L.redraw();
    const run = () => {
      const body = ops.map(op => ({ key: op.key, data: op.data == null ? null : op.data, v: S.ver[op.key] || 0 }));
      return L.api('POST', '/ops', { ops: body, label: o.label || '' }).then(res => {
        ops.forEach(op => { pend[op.key]--; });
        take(res.rows);
        if (res.undo) { res.undo.at = new Date().toISOString(); res.undo.sitting = true; S.undo.unshift(res.undo); S.undo = S.undo.slice(0, 12); }
        S.pending--; status('saved');
        if (o.label && !o.silent) L.toast(o.toast || o.label, res.undo ? { undo: res.undo.id } : null);
        if (o.done) o.done(res);
        L.redraw();
        return true;
      }, err => {
        ops.forEach(op => { pend[op.key]--; });
        S.pending--;
        const rows = err.data && err.data.data && err.data.data.rows;
        // Put back what this change touched: as the server has it now, or as it was.
        Object.keys(before).forEach(k => { if (!pend[k]) { if (before[k]) S.rows[k] = before[k]; else delete S.rows[k]; } });
        if (rows) take(rows);
        status(err.status ? 'error' : 'offline');
        L.toast(err.status === 409 ? (err.message || 'Changed by another member · Reload') : err.status === 403 ? (err.message || 'Not allowed') : err.status ? 'Not saved · ' + (err.message || 'Retry') : 'Offline · Not saved', err.status ? null : { retry: () => L.save(ops, o) });
        L.redraw();
        if (err.status === 409) refresh(true);
        return false;
      });
    };
    chain = chain.then(run, run);
    return chain;
  };
  // A household's row with some fields changed.
  L.hhSave = (h, change, o) => {
    const cur = Object.assign({}, L.hrow(h));
    Object.keys(change).forEach(k => { if (change[k] == null || change[k] === false) delete cur[k]; else cur[k] = change[k]; });
    if (cur.rooms && !cur.rooms.length) delete cur.rooms;
    return L.save([{ key: 'hh:' + h.rid, data: Object.keys(cur).length ? cur : null }], o);
  };
  // ⌘Z undoes this member's own last change from this sitting only (polish 1: a stray ⌘Z at the desk
  // quietly reversed a check-in from hours before). The toast's Undo names its own change.
  L.undoLast = function (id) {
  const u = id ? S.undo.find(x => x.id === id) : S.undo.find(x => x.mine && x.sitting);
  if (!u) { L.toast('Nothing to undo'); return; }
    S.pending++;
    L.api('POST', '/undo', { id: u.id }).then(res => {
      S.pending--;
      S.undo = S.undo.filter(x => x.id !== u.id);
      take(res.rows);
      L.toast(undoneWords(res.label || u.label));
      L.redraw();
    }, err => { S.pending--; L.toast(err.message || 'Can’t undo'); refresh(true); });
  };

  // "Check-in · Adams" → "Check-in undone · Adams"; anything else "Undone · Abbott · Reed 104".
  function undoneWords(label) {
  const m = /^(Check-in|Keys back|Keys out|Note) · (.+)$/.exec(label || '');
  return m ? m[1] + ' undone · ' + m[2] : 'Undone · ' + (label || '');
  }
  // Saving · Saved, in the header (the year page's words), only once something was changed here.
  function status(st) {
  const el = root.querySelector('.ws-status');
  if (!el) return;
  if (!S.changed && !S.pending && st === 'saved') { el.textContent = ''; return; }
    el.textContent = st === 'saving' || S.pending ? 'Saving' : st === 'offline' ? 'Offline' : st === 'error' ? 'Not saved' : 'Saved';
    el.dataset.state = S.pending ? 'saving' : st;
  }
  window.addEventListener('beforeunload', e => { if (S.pending) { e.preventDefault(); e.returnValue = ''; } });

  /* ================================================================ the toast (Undo where you're looking) */

  const toastEl = document.createElement('div');
  toastEl.className = 'lod-toast';
  toastEl.setAttribute('role', 'status');
  toastEl.setAttribute('aria-live', 'polite');
  document.body.appendChild(toastEl);
  let toastT = 0, toastAct = null;
  L.toast = function (msg, o) {
    o = o || {};
    clearTimeout(toastT);
    toastAct = o;
    toastEl.innerHTML = '<span>' + esc(msg) + '</span>' + (o.undo ? '<button type="button" data-tundo>Undo</button>' : '') + (o.retry ? '<button type="button" data-tretry>Retry</button>' : '') +
      (o.action ? '<button type="button" data-tact>' + esc(o.action[0]) + '</button>' : '') + '<button type="button" class="lod-toast__x" data-tx aria-label="Close">' + I.close + '</button>';
    toastEl.classList.add('is-on');
    const hide = () => { if (!toastEl.matches(':hover, :focus-within')) toastEl.classList.remove('is-on'); else toastT = setTimeout(hide, 3000); };
    toastT = setTimeout(hide, o.undo || o.action ? 9000 : 5000);
  };
  toastEl.addEventListener('click', e => {
    if (e.target.closest('[data-tundo]')) { toastEl.classList.remove('is-on'); L.undoLast(toastAct.undo); }
    else if (e.target.closest('[data-tretry]')) { toastEl.classList.remove('is-on'); toastAct.retry(); }
    else if (e.target.closest('[data-tact]')) { toastEl.classList.remove('is-on'); toastAct.action[1](); }
    else if (e.target.closest('[data-tx]')) toastEl.classList.remove('is-on');
  });
  const live = document.createElement('p');
  live.className = 'ogc-sr';
  live.setAttribute('aria-live', 'polite');
  root.after(live);
  L.say = t => { live.textContent = ''; setTimeout(() => { live.textContent = t; }, 30); };

  /* ================================================================ the frame */

  L.go = view => {
    S.view = view;
    const u = new URL(location.href);
    if (view === 'rooms') u.searchParams.delete('view'); else u.searchParams.set('view', view);
    history.replaceState(null, '', u);
    L.render();
    const t = root.querySelector('[data-view="' + view + '"]');
    if (t) t.focus({ preventScroll: true });
  };
  // Who owns Lodging this year (the COA's choice; nothing until they choose).
  L.owner = () => SU.ownerOf(S.settings, 'lodging') || SU.ownerOf(S.settings, 'registration');
  L.conf = () => S.year + ' Annual Conference';
  L.nextYear = () => +S.year + 1;

  function head(extra) {
  const y = esc(S.year);
  const tools = [];
  if (!L.ro && S.view !== 'import' && S.hh.length) tools.push('<a href="?year=' + y + '&view=import' + (S.asOf ? '&as-of=' + esc(S.asOf) : '') + '" title="Responses from the registration Google Form, as a CSV">' + I.up + 'Import</a>');
  if (S.view !== 'import') tools.push('<a href="../register/?year=' + y + '&preview=1" title="The registration form, as households see it">View form</a>');
  let h = SU.wsHead({ year: S.year, kicker: L.owner() || '', title: extra || 'Lodging', tools: tools.join('') });
  // From Import, back goes to Lodging, not the year.
  if (S.view === 'import') h = h.replace(/<a class="ws-back" href="[^"]*">([\s\S]*?)<span>[^<]*<\/span><\/a>/, '<a class="ws-back" href="?year=' + y + (S.asOf ? '&as-of=' + esc(S.asOf) : '') + '">$1<span>Lodging</span></a>');
  // The status words sit in the bar (Saving · Saved), as on the year's pages: empty until a change.
  return h.replace('</div></header>', (L.ro && !L.lateOk() ? '' : '<p class="ws-status" aria-live="polite"></p>') + '</div></header>');
  }
  L.head = head;

  // The tabs that have something true to show (never a zero), each with what's left there, said in
  // words to a screen reader and on hover ("6 to do").
  L.tabHas = v => v === 'rooms' || (v === 'yf' ? S.hh.some(h => !h.gone && h.yfs.length) : v === 'campers' ? S.hh.some(h => h.type === 'camper' && !h.gone) : v === 'checkin' ? L.dorm().length > 0 : true);
  function tabs() {
  const n = L.counts ? L.counts() : {};
  const list = VIEWS.filter(v => L.tabHas(v[0]) || S.view === v[0]);
  if (list.length < 2) return '';
  return '<div class="lod-tabs-v" role="tablist" aria-label="Lodging">' + list.map(v => '<button type="button" role="tab" data-view="' + v[0] + '" aria-selected="' + (S.view === v[0]) + '" tabindex="' + (S.view === v[0] ? 0 : -1) + '"' + (n[v[0]] ? ' title="' + esc(n[v[0]][1]) + '"' : '') + '>' + v[1] + (n[v[0]] && n[v[0]][0] ? '<small aria-hidden="true">' + esc(n[v[0]][0]) + '</small><span class="ogc-sr"> · ' + esc(n[v[0]][1]) + '</span>' : '') + '</button>').join('') + '</div>';
  }

  L.render = function () {
    if (!S.loaded) return;
    const v = L.views[S.view] || L.views.rooms;
    if (S.view === 'import' && L.views.import) {
      root.innerHTML = '<div class="wk vol lod ws">' + head('Import') + '<div class="ws-body ws-body--page lod-body">' + L.views.import.html() + '</div></div>';
    } else {
      root.innerHTML = '<div class="wk vol lod ws">' + head() + '<div class="ws-body ws-body--page lod-body">' + tabs() + lastNotes() + '<div class="lod-view" data-v="' + esc(S.view) + '">' + v.html() + '</div>' + notesBlock() + footer() + '</div></div>';
    }
    root.removeAttribute('aria-busy');
    document.title = (S.view === 'import' ? 'Import' : (VIEWS.find(x => x[0] === S.view) || VIEWS[0])[1]) + ' – Lodging – ' + L.conf();
    if (v.after) v.after();
    status(S.pending ? 'saving' : 'saved');
  };
  // Redraw without losing the place: the scroll, the focused control, the queue's own scroll.
  L.redraw = function () {
    if (!S.loaded) return;
    const a = document.activeElement, sel = a && a !== document.body ? keyOf(a) : null;
    const qs = root.querySelector('.lod-queue'), qTop = qs ? qs.scrollTop : 0, y = window.scrollY;
    const typing = a && a.matches && a.matches('input[type="search"], textarea, input[type="text"]') ? { v: a.value, s: a.selectionStart } : null;
    L.render();
    const q2 = root.querySelector('.lod-queue'); if (q2) q2.scrollTop = qTop;
    window.scrollTo(0, y);
    if (sel) { const b = root.querySelector(sel); if (b) { b.focus({ preventScroll: true }); if (typing && b.setSelectionRange) { b.value = typing.v; try { b.setSelectionRange(typing.s, typing.s); } catch (e) { /* not text */ } } } }
  };
  function keyOf(el) {
    for (const k of ['data-sel', 'data-older', 'data-list', 'data-view', 'data-find', 'data-room', 'data-ci', 'data-act', 'data-yfh', 'data-hall', 'data-floor', 'data-note']) {
      const v = el.getAttribute && el.getAttribute(k);
      if (v != null) return '[' + k + (v === '' ? '' : '="' + CSS.escape(v) + '"') + ']';
    }
    return el.id ? '#' + CSS.escape(el.id) : null;
  }

  /* ================================================================ Notes for next year */

  // Last year's notes at the top of the tab they were written on, with Done.
  function lastNotes() {
    const P = S.prev, done = L.data('meta:notes_done') || {};
    if (!P || !P.notes || !P.notes.length || (L.ro && !L.lateOk())) return '';
    const list = P.notes.filter(n => (n.tab || 'rooms') === S.view && !done[n.id]);
    if (!list.length) return '';
    return '<section class="lod-last" aria-label="Notes from ' + esc(S.prevYear) + '"><p class="wk-kicker">Notes from ' + esc(S.prevYear) + '</p><ul>' + list.map(n => '<li><p>' + esc(n.text) + '</p><p class="lod-last__by">' + esc([n.by, L.md(n.at)].filter(Boolean).join(' · ')) + ' <button type="button" class="wk-linklike" data-notedone="' + esc(n.id) + '">Done</button></p></li>').join('') + '</ul></section>';
  }
  function notesBlock() {
    const mine = Object.keys(S.rows).filter(k => /^note:/.test(k) && (S.rows[k].data.tab || 'rooms') === S.view).map(k => Object.assign({ id: k.slice(5) }, S.rows[k].data));
    const ro = L.ro && !L.lateOk();
    if (ro && !mine.length) return '';
    const open = S.ui.noteOpen;
    return '<section class="lod-notes"><h2 class="lod-notes__h">Notes for ' + L.nextYear() + ' ' + L.info('For next year’s Lodging: what to keep, what to change. They see it at the top of this tab.', 'notes') + '</h2>' +
      (mine.length ? '<ul class="lod-notes__list">' + mine.map(n => '<li><p>' + esc(n.text) + '</p><p class="lod-last__by">' + esc([n.by, L.md(n.at)].filter(Boolean).join(' · ')) + (ro ? '' : ' <button type="button" class="wk-linklike" data-noterm="' + esc(n.id) + '">Remove</button>') + '</p></li>').join('') + '</ul>' : '') +
      (ro ? '' : open ? '<div class="lod-notes__add"><label class="ogc-sr" for="lod-note">Note for ' + L.nextYear() + '</label><textarea id="lod-note" rows="3" maxlength="600" placeholder="What next year’s Lodging should know"></textarea><p class="lod-btns"><button type="button" class="wk-btn wk-btn--line wk-btn--small" data-noteadd>Add</button><button type="button" class="wk-linklike" data-notecancel>Cancel</button></p></div>'
        : '<p><button type="button" class="wk-linklike lod-addnote" data-noteopen>' + I.plus + 'Add note</button></p>') + '</section>';
  }
  function footer() {
    const P = S.phase;
    // Said once the Conference is over (the names are about to go), not on every visit before.
    if (!P.clear || !P.held) return '';
    return P.clear ? '<p class="lod-foot" title="Names, phones and emails are cleared ' + esc(S.cfg.clear_after_days || 60) + ' days after the Conference; counts stay">' + I.info + 'Names cleared ' + esc(O.fmtDate(P.clear, 'md')) + '</p>' : '';
  }

  /* ================================================================ events every tab shares */

  root.addEventListener('click', e => {
    const t = e.target.closest('[data-info], [data-view], [data-notedone], [data-noterm], [data-noteadd], [data-noteopen], [data-notecancel], [data-retry]');
    if (!t) return;
    const ds = t.dataset;
    if (ds.info != null) {
      // The (i): its note shows in line, and stays open across redraws.
      S.ui.info = S.ui.info || {};
      const open = !S.ui.info[ds.info];
      S.ui.info[ds.info] = open;
      t.setAttribute('aria-expanded', String(open)); t.setAttribute('aria-label', open ? 'Hide note' : 'More');
      const n = t.nextElementSibling; if (n && n.classList.contains('lod-inote')) n.hidden = !open;
      return;
    }
    if (ds.view) L.go(ds.view);
    else if (ds.notedone) { const d = Object.assign({}, L.data('meta:notes_done') || {}); d[ds.notedone] = true; L.save([{ key: 'meta:notes_done', data: d }], { label: 'Note done', late: true }); }
    else if (ds.noterm) L.save([{ key: 'note:' + ds.noterm, data: null }], { label: 'Note removed', late: true });
    else if (t.hasAttribute('data-noteopen')) { S.ui.noteOpen = true; L.render(); const x = root.querySelector('#lod-note'); if (x) x.focus(); }
    else if (t.hasAttribute('data-notecancel')) { S.ui.noteOpen = false; L.render(); }
    else if (t.hasAttribute('data-noteadd')) {
      const x = root.querySelector('#lod-note'), v = x ? x.value.trim() : '';
      if (!v) { x.focus(); return; }
      S.ui.noteOpen = false;
      L.save([{ key: 'note:' + Date.now().toString(36), data: { text: v, tab: S.view } }], { label: 'Note added', late: true });
    }
    else if (t.hasAttribute('data-retry')) location.reload();
  });
  root.addEventListener('keydown', e => {
    // Arrow keys move between the tabs (a tablist).
    const tab = e.target.closest && e.target.closest('[role="tab"]');
    if (tab && (e.key === 'ArrowRight' || e.key === 'ArrowLeft')) {
      const all = Array.from(root.querySelectorAll('[role="tab"]')), i = all.indexOf(tab), n = all[(i + (e.key === 'ArrowRight' ? 1 : all.length - 1)) % all.length];
      e.preventDefault(); L.go(n.dataset.view);
    }
  });
  document.addEventListener('keydown', e => {
    if ((e.metaKey || e.ctrlKey) && !e.shiftKey && e.key.toLowerCase() === 'z' && !(e.target.matches && e.target.matches('input, textarea'))) { e.preventDefault(); L.undoLast(); }
  });

  /* ================================================================ keeping up with the others */

  // Every 25 seconds while the page is in view: other members' changes, said in the toast.
  let lastPoll = 0;
  function refresh(force) {
    if (!S.loaded || (S.pending && !force) || document.hidden) return Promise.resolve();
    lastPoll = Date.now();
    return L.api('GET', '').then(B => {
      const mine = S.me, news = [];
      Object.keys(B.rows || {}).forEach(k => {
        const r = B.rows[k], old = S.rows[k];
        if ((!old || old.v !== r.v) && r.by && r.by !== mine && /^hh:/.test(k)) { const h = L.byRid(k.slice(3)); if (h) news.push([r.by, h]); }
      });
      S.rows = Array.isArray(B.rows) ? {} : (B.rows || {});
      S.ver = {};
      Object.keys(S.rows).forEach(k => { S.ver[k] = S.rows[k].v; });
      const sat = new Set(S.undo.filter(x => x.sitting).map(x => x.id));
      S.undo = (B.undo || []).map(x => sat.has(x.id) ? Object.assign(x, { sitting: true }) : x);
      S.imported = B.import;
      if (news.length && !force) L.toast(news.length === 1 ? news[0][0] + ' · ' + news[0][1].sur : news[0][0] + ' · ' + plural(news.length, 'change'), news.length === 1 ? { action: ['Show', () => L.show && L.show(news[0][1].rid)] } : null);
      L.redraw();
    }).catch(() => { /* next time */ });
  }
  L.refresh = refresh;
  setInterval(() => { if (Date.now() - lastPoll > 24000) refresh(); }, 5000);
  // New and changed registrations, every two minutes.
  setInterval(() => {
    if (!S.loaded || document.hidden || !O.records) return;
    O.records.load(S.year, ['registrations'], true).then(() => { buildHouseholds(); L.redraw(); }).catch(() => {});
  }, 120000);
  document.addEventListener('visibilitychange', () => { if (!document.hidden && Date.now() - lastPoll > 10000) refresh(); });

  /* ================================================================ the year */

  function card(h, p, extra) {
    return '<section class="ws-blank lod-blank"><p class="ws-blank__h">' + h + '</p>' + (p ? '<p class="ws-blank__p">' + p + '</p>' : '') + (extra || '') + '</section>';
  }
  L.card = card;
  function frame(body) {
    root.innerHTML = '<div class="wk vol lod ws">' + head() + '<div class="ws-body ws-body--page lod-body">' + body + '</div></div>';
    root.removeAttribute('aria-busy');
    document.title = 'Lodging – ' + L.conf();
  }

  // The year's halls, as v3 reads them (rooms.csv), in the plan's order (rooms side by side).
  function readHalls(roomsCsv, plansCsv, campusCsv) {
    if (O.map) { const c = O.map.campus(SU.withEdits(S.year, 'campus', O.csvToObjects(campusCsv))); S.campus = c.items.length ? c : null; }
    S.plans = O.map ? O.map.plans(SU.withEdits(S.year, 'plans', O.csvToObjects(plansCsv))) : {};
    const R = SU.readRooms(SU.withEdits(S.year, 'rooms', O.csvToObjects(roomsCsv)));
    S.rooms = R.rooms; S.floors = R.floors;
    if (O.map) O.map.orderFloors(S.floors, S.plans);
    S.roomBy = {};
    S.rooms.forEach(r => { S.roomBy[r.id] = r; });
  }

  (O.ready || Promise.resolve()).then(() => fetch(BASE + 'years.csv', { cache: 'no-store' })).then(r => r.text()).then(async text => {
    const years = O.csvToObjects(text).filter(y => y.year).sort((a, b) => b.year - a.year);
    const mine = (W.member || []).map(String);
    // No year asked: the newest year this member has.
    if (!S.year) S.year = (mine.find(y => years.some(x => x.year === y && x.data)) || (years.find(y => y.data) || {}).year || '');
    S.row = years.find(y => y.year === S.year) || null;
    S.prevYear = String(+S.year - 1);
    if (!S.row || !S.row.data) {
      S.loaded = true;
      frame(card(esc(S.year || 'This year') + ' · Not started', W.webmaster ? '<a href="../admin/?role=web">Start ' + esc(S.year) + '</a>' : '<a href="../year/?year=' + esc(S.year) + '">' + esc(S.year) + ' Annual Conference</a>'));
      return;
    }
    const folder = BASE + S.row.data + '/';
    S.model = await O.loadSchedule(folder);
    S.settings = S.model.settings || {};
    const [cfgText, roomsCsv, plansCsv, campusCsv] = await Promise.all(['registration', 'rooms', 'plans', 'campus'].map(f => fetch(folder + f + '.csv', { cache: 'no-store' }).then(r => r.ok ? r.text() : '')));
    S.cfg = SU.settings(SU.withEdits(S.year, 'registration', O.csvToObjects(cfgText)));
    readHalls(roomsCsv, plansCsv, campusCsv);
    const B = await L.api('GET', '');
    Object.assign(S, { rows: B.rows || {}, undo: B.undo || [], phase: B.phase || {}, me: B.me || '', seen: B.seen || '', prev: B.prev, prevYear: String(B.prev_year || +S.year - 1), carry: B.carry, numbers: B.numbers, imported: B.import });
    if (Array.isArray(S.rows)) S.rows = {};
    S.ver = {};
    Object.keys(S.rows).forEach(k => { S.ver[k] = S.rows[k].v; });
    // Held: the Conference is over, rooms no longer move. The desk and notes go on until names are cleared.
    L.ro = !!S.phase.held;
    if (O.records) await O.records.load(S.year, ['registrations']).catch(() => {});
    buildHouseholds();
    S.loaded = true;
    lastPoll = Date.now();
    if (!S.hh.length && !S.floors.some(f => f.for === 'families')) { frame(card('No dorm halls · No registrations', '<a href="../year/?year=' + esc(S.year) + '&part=conference">' + esc(S.year) + ' · The Conference</a>')); return; }
    if (!S.cfg.nights) { frame(card('Registration not set up', '<a href="../year/?year=' + esc(S.year) + '&part=registration">Registration</a>')); return; }
    // Once names are due to be cleared the page draws the year in counts only, whatever this browser loaded.
    if (S.phase.cleared && L.views.held) { root.innerHTML = '<div class="wk vol lod ws">' + head() + '<div class="ws-body ws-body--page lod-body">' + L.views.held.html() + '</div></div>'; root.removeAttribute('aria-busy'); document.title = 'Lodging – ' + L.conf(); return; }
    if (!VIEWS.some(v => v[0] === S.view) && S.view !== 'import') S.view = 'rooms';
    // During the week the page opens on the desk.
    if (!q.get('view') && L.deskOn && L.deskOn()) S.view = 'checkin';
    L.render();
  }).catch(err => {
    console.error(err);
    S.loaded = false;
    root.removeAttribute('aria-busy');
    root.innerHTML = '<div class="wk vol lod ws">' + SU.wsHead({ year: S.year, kicker: S.year, title: 'Lodging' }) + '<div class="ws-body ws-body--page lod-body">' +
      card(err && err.status === 403 ? (err.data && err.data.code === 'ogc_lodging_only' ? 'Lodging only' : 'Members only') : 'Couldn’t load', err && err.status === 403 ? '' : '<button type="button" class="wk-btn wk-btn--line wk-btn--small" data-retry>Retry</button><p class="lod-help">If it keeps happening, tell the webmasters</p>') + '</div></div>';
  });
})();
