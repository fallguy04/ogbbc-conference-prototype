/*
 * lodging-board.js — the Rooms tab: from the whole list of households to everyone in a room (Oct 8,
 * Michael: "from huge list of people to… a room"), reworked Oct 10 from two audits and polished from
 * the critic's round.
 *
 *   What to do      the steps in order, ticking themselves (Import · Mark older · Assign all · Review ·
 *                   Publish · Final counts · Print check-in); one row, folded after the first sitting
 *   The list        Unassigned · Review (what doesn't fit, and what changed since) · Assigned, and one
 *                   search over every household and person
 *   The household   chosen: first the decision (its asks, what's wrong, Assign · Reed 325), the rest
 *                   folded under More; its rooms on the plan beside it. Every tap saves at once (Undo)
 *   The plan        a hall's floor as drawn (or a schematic), fitted to its box with numbers never under
 *                   11 px (a wing at a time when the box is narrow); names are in each room's title and
 *                   the list, never squeezed onto the plan; drag a household onto a room, a room onto
 *                   another (move, or swap); a free room with no one chosen says who'd fit it
 * On a phone the list is the page and a household opens full screen with its floor below.
 * One filled button at a time, chosen by where the work stands.
 */
(function () {
  'use strict';
  const L = window.OGC.lodging, O = window.OGC, SU = L.SU, S = L.S, I = L.I, esc = L.esc, root = L.root;
  const U = S.ui;
  Object.assign(U, { sel: '', list: '', find: '', hall: '', floor: 0, room: '', older: false });
  const narrow = () => window.matchMedia('(max-width: 759px)').matches;
  const touch = () => window.matchMedia('(pointer: coarse)').matches;
  const plural = L.plural;
  // A line of words that never breaks inside a part ("Fri–Mon" stays whole).
  const parts = list => list.filter(Boolean).map(x => '<span class="lod-nw">' + esc(x) + '</span>').join(' · ');

  /* ================================================================ where the work stands */

  // Review is one list: what the rooms don't meet, and what changed since they were given (a household
  // cancelled or gone to the camper lot still holding rooms is in it too). One number everywhere.
  function tally() {
    const d = L.dorm(), waiting = [], given = [];
    d.forEach(h => { if (L.given(h).length) given.push(h); else waiting.push(h); });
    const changed = L.changed();
    const review = given.filter(h => L.toReview(h).length || changed.indexOf(h) > -1).concat(changed.filter(h => !h.active));
    const pub = L.data('meta:published');
    return { d, waiting, review, given, changes: changed, pub: pub && pub.date ? pub : null, pubChanged: L.pubChanged(), rooms: familyRooms() };
  }
  L.tally = tally;
  const familyRooms = () => L.familyFloors().reduce((k, f) => k + f.rooms.length, 0);
  const isNew = h => !!S.seen && String(h.at) > S.seen && !L.given(h).length;

  L.counts = function () {
    if (!S.hh.length || L.ro) return {};
    const t = tally(), left = t.waiting.length + t.review.length;
    const out = { rooms: left ? [String(left), left + ' to do · ' + [t.waiting.length ? t.waiting.length + ' to assign' : '', t.review.length ? t.review.length + ' to review' : ''].filter(Boolean).join(' · ')] : null };
    if (L.listCounts) Object.assign(out, L.listCounts());
    return out;
  };

  /* ================================================================ What to do */

  function steps(t) {
    const st = L.data('meta:steps') || {}, start = S.phase.start;
    const forms = S.hh.some(h => h.source === 'form') || (S.imported && !S.imported.undone);
    const marked = t.d.filter(L.older).length;
    const list = [];
    if (forms) list.push({ id: 'import', t: 'Import', done: !!S.imported && !S.imported.undone, note: S.imported ? L.md(S.imported.at) : '', act: 'import', tip: 'The Google Form’s responses, as a CSV' });
    // Older is ticked only by Done, on purpose ("None" when nobody was marked).
    list.push({ id: 'older', t: 'Mark older', done: !!st.older, note: marked ? marked + ' marked' : st.older ? 'None' : '', act: 'older', tip: 'Before Assign all: older households go first, onto ground floors near the dining hall' });
    list.push({ id: 'assign', t: 'Assign all', done: t.d.length > 0 && !t.waiting.length, note: t.waiting.length ? plural(t.waiting.length, 'household') : '', act: 'assign', tip: 'Suggests a room for everyone waiting; nobody already placed moves' });
    list.push({ id: 'review', t: 'Review', done: t.given.length > 0 && !t.waiting.length && !t.review.length, note: t.review.length ? String(t.review.length) : '', act: 'review', tip: 'Requests the rooms don’t meet, and changes since rooms were given' });
    // A later step is done only when the ones before it are: published early says what's left.
    const before = !t.waiting.length && !t.review.length;
    const pubOk = !!t.pub && !t.pubChanged.length;
    list.push({ id: 'publish', t: 'Publish', done: pubOk && before, note: t.pub ? (t.pubChanged.length ? t.pubChanged.length + ' changed' : before ? L.md(t.pub.date) : 'Published · ' + (t.waiting.length + t.review.length) + ' to finish') : '', act: 'publish', tip: 'Households see their rooms in Your sign-ups' });
    list.push({ id: 'counts', t: 'Final counts', done: !!st.counts, note: st.counts ? L.md(st.counts.at) : start ? 'By ' + L.md(O.isoAddDays(start, -14)) : '', act: 'counts', tip: 'Rooms per night, linens, mattresses and keys, to the campus two weeks before' });
    list.push({ id: 'print', t: 'Print check-in', done: !!st.print, note: st.print ? L.md(st.print.at) : '', act: 'print', tip: 'The Lodging Desk’s list, the week before' });
    const next = list.find(s => !s.done);
    // Open on a first sitting; after that it folds to its Next line (open on demand).
    const open = U.stepsOpen != null ? U.stepsOpen : !S.seen && !narrow();
    return '<details class="lod-steps"' + (open && next && !L.ro ? ' open' : '') + ' data-steps><summary><span class="wk-kicker">What to do</span>' +
      (next ? '<span class="lod-steps__next">Next · ' + esc(next.t) + '</span>' + (next.tip ? '<span class="lod-steps__tip">' + esc(next.tip) + '</span>' : '') : '<span class="lod-steps__ok">' + I.check + 'Done</span>') + '</summary><ol>' +
      list.map((s, i) => '<li class="' + (s.done ? 'is-done' : s === next ? 'is-next' : '') + '"><button type="button" data-step="' + s.act + '"' + (s.tip ? ' title="' + esc(s.tip) + '"' : '') + '><span class="lod-steps__n">' + (s.done ? I.check : i + 1) + '</span><span><b>' + esc(s.t) + '</b>' + (s.note ? '<small>' + esc(s.note) + '</small>' : '') + '</span></button></li>').join('') + '</ol></details>';
  }

  /* ================================================================ the view */

  L.views.rooms = { html: roomsHtml, after: afterRender };

  function roomsHtml() {
    if (!L.familyFloors().length) return L.card('No dorm halls', '<a href="../year/?year=' + esc(S.year) + '&part=conference">Add halls</a>');
    const t = tally();
    if (!t.d.length) {
      const opens = S.cfg.opens && S.cfg.opens > S.phase.today ? 'Opens ' + O.fmtDate(S.cfg.opens, 'md') : '';
      const halls = Array.from(new Set(L.familyFloors().map(f => L.hallShort(f.hall))));
      return L.card(S.hh.length ? 'No households in dorm rooms' : 'No registrations yet', esc(S.hh.length ? '' : opens),
        '<p class="lod-blank__fact">' + plural(t.rooms, 'family room') + ' in ' + esc(halls.length === 2 ? halls.join(' and ') : halls.join(', ')) + '</p>' + (L.ro ? '' : '<p><a class="wk-linklike" href="?year=' + esc(S.year) + '&view=import">' + I.up + 'Import from the Form</a></p>'));
    }
    if (!U.list) U.list = t.waiting.length ? 'todo' : t.review.length ? 'review' : 'done';
    if (U.list === 'todo' && !t.waiting.length) U.list = t.review.length ? 'review' : 'done';
    if (U.list === 'changes') U.list = 'review';
    return (L.ro ? '' : steps(t)) + since(t) + top(t) +
      '<div class="lod-board' + (U.sel || U.room ? ' has-sel' : '') + '"><div class="lod-queue">' + queue(t) + '</div><div class="lod-side" id="lod-side">' + (narrow() ? phoneHalls() : side(t)) + '</div></div>' +
      (narrow() && U.sel ? sheet(t) : '');
  }

  // "Since Tuesday: 4 new · 2 changed".
  function since(t) {
    if (!S.seen || L.ro) return '';
    const n = t.d.filter(isNew).length, c = t.changes.length;
    if (!n && !c) return '';
    return '<p class="lod-since">Since ' + esc(L.since(S.seen)) + ' · ' + (n ? '<button type="button" class="wk-linklike" data-list="todo">' + n + ' new</button>' : '') + (n && c ? ' · ' : '') + (c ? '<button type="button" class="wk-linklike" data-list="review">' + c + ' changed</button>' : '') + '</p>';
  }

  // The status line and the one filled button.
  function primary(t) {
    if (L.ro) return null;
    if (t.waiting.length) return { act: 'assignall', t: 'Assign all', n: t.waiting.length, tip: 'Older, step-free and ground-floor requests first, nearest the dining hall; households asking to be near each other together; a family’s rooms side by side. Nobody already placed is moved.' };
    if (t.review.length) return { act: 'reviewnext', t: 'Review', n: t.review.length };
    if (!t.pub && t.given.length) return { act: 'publish', t: 'Publish', tip: 'Households see their rooms in Your sign-ups' };
    if (t.pub && t.pubChanged.length) return { act: 'update', t: 'Send update', n: t.pubChanged.length, tip: 'The households whose rooms changed since ' + L.md(t.pub.date) };
    return null;
  }
  function top(t) {
    const asked = t.d.reduce((k, h) => k + h.asked, 0), full = asked / Math.max(1, t.rooms);
    // While a household is open, or Mark older is, that work holds the one filled button.
    const p = primary(t), filled = !U.sel && !U.older && !U.room;
    const links = [];
    if (t.given.length) links.push('<button type="button" class="wk-linklike" data-act="export" title="For the campus: one line a room, arrival and departure dates">' + I.down + 'Export rooming list</button>');
    if (!L.ro) links.push('<a class="wk-linklike" href="../register/?year=' + esc(S.year) + '&another=1" title="Register a household that called, wrote or came to the desk (the same form)">' + I.plus + 'Add household</a>');
    const pub = t.pub ? '<p class="lod-pub">' + I.check + esc('Published ' + L.md(t.pub.date) + (t.pubChanged.length ? ' · ' + t.pubChanged.length + ' changed since' : '')) +
      (L.ro ? '' : ' ' + L.info('Households see their rooms in Your sign-ups. Moves after this wait for Send update.', 'pub') + '<span class="lod-pubmore"><button type="button" class="wk-linklike" data-act="unpublish">Unpublish</button></span>') + '</p>' : '';
    return '<div class="lod-top"><div class="lod-top__s"><p class="lod-status"><b>' + t.given.length + '</b> of ' + t.d.length + ' assigned' +
      ' · <span class="' + (full >= .9 ? 'lod-full' : '') + '">Rooms asked · ' + asked + ' of ' + t.rooms + '</span> ' +
      L.info('Rooms asked for, against the family rooms in the halls · ' + stockWords() + (S.phase.clear ? ' · Names cleared ' + O.fmtDate(S.phase.clear, 'md') : ''), 'status') + '</p>' + pub + '</div>' +
      (p ? '<button type="button" class="wk-btn' + (filled ? '' : ' wk-btn--line') + ' lod-primary" data-act="' + p.act + '"' + (p.tip ? ' title="' + esc(p.tip) + '"' : '') + '>' + esc(p.t) + (p.n ? ' · ' + p.n : '') + '</button>' : '') +
      (links.length ? '<p class="lod-links">' + links.join('') + '</p>' : '') + '</div>';
  }
  function stockWords() {
    const used = { l: 0, m: 0 };
    S.hh.filter(h => !h.gone).forEach(h => { used.l += h.linens; used.m += h.mattresses; });
    return ['Linen packets ' + used.l + (S.cfg.linen_stock ? ' of ' + S.cfg.linen_stock : ''), 'Air mattresses ' + used.m + (S.cfg.mattress_stock ? ' of ' + S.cfg.mattress_stock : '')].join(' · ');
  }

  /* ================================================================ the list */

  const LISTS = [['todo', 'Unassigned'], ['review', 'Review'], ['done', 'Assigned']];
  function listOf(t, k) {
    if (k === 'todo') return t.waiting.slice().sort((a, b) => (isNew(b) - isNew(a)) || (L.firstGroup(b) - L.firstGroup(a)) || (String(a.at) < String(b.at) ? -1 : 1));
    if (k === 'review') return t.review;
    if (k === 'older') return t.d;
    return t.given.slice().sort((a, b) => a.sur.localeCompare(b.sur) || a.firsts.localeCompare(b.firsts));
  }
  function where(h) {
    if (!h.active) return h.gone ? 'Cancelled' : h.type === 'camper' ? 'Camper lot' : h.type === 'yf' ? 'Youngfolks halls' : 'Elsewhere';
    const g = L.given(h);
    return g.length ? L.roomsWords(g) : 'Unassigned';
  }
  L.where = where;
  // One search over every household and every person in it, a registration number, a phone's last digits.
  function search(f) {
    f = f.trim().toLowerCase();
    const digits = f.replace(/\D/g, '');
    return S.hh.filter(h => {
      if ((h.label + ' ' + h.rid).toLowerCase().indexOf(f) > -1) return true;
      if (h.people.some(p => p.name.toLowerCase().indexOf(f) > -1)) return true;
      if (digits.length >= 3 && h.phone.replace(/\D/g, '').slice(-digits.length) === digits) return true;
      return L.given(h).some(id => L.roomWords(id).toLowerCase().indexOf(f) > -1);
    });
  }
  function queue(t) {
    if (U.older) return olderPass(t);
    const plan = U.list === 'todo' ? L.plan(t.waiting) : {};
    const n = { todo: t.waiting.length, review: t.review.length, done: t.given.length };
    const chips = '<div class="lod-chips" role="group" aria-label="List">' + LISTS.filter(c => n[c[0]] || U.list === c[0]).map(c => '<button type="button" data-list="' + c[0] + '" aria-pressed="' + (U.list === c[0] && !U.find) + '">' + c[1] + ' <b>' + n[c[0]] + '</b></button>').join('') + '</div>';
    const find = '<label class="lod-find"><span class="ogc-sr">Search</span>' + I.search + '<input type="search" data-find placeholder="Search" title="Anyone’s name, a room, R-number or phone · /" value="' + esc(U.find) + '" autocomplete="off"></label>';
    const hint = touch() && !narrow() && !L.ro && U.list === 'todo' ? '<p class="lod-help lod-hint">Tap a household, then a room</p>' : '';
    let items;
    if (U.find.trim()) {
      const hits = search(U.find);
      items = hits.length ? hits.map(h => qItem(h, null, where(h))).join('') : '<li class="lod-none">No matches</li>';
    } else {
      const l = listOf(t, U.list);
      items = l.length ? l.map(h => qItem(h, plan[h.rid])).join('') : '<li class="lod-none">' + (U.list === 'review' ? 'Nothing to review' : 'None') + '</li>';
    }
    return chips + find + hint + '<ul class="lod-q" data-given>' + items + '</ul>';
  }
  // Mark older, in one pass: every household in dorm rooms with its adults, one check box each.
  const olderBox = (h, inline) => '<button type="button" class="lod-older' + (inline ? ' lod-older--inline' : '') + '" data-older="' + esc(h.rid) + '" aria-pressed="' + L.older(h) + '" aria-label="Older: ' + esc(h.label) + '" title="Lodging’s own mark: placed first, on a ground floor near the dining hall">' +
    '<span class="lod-box" aria-hidden="true">' + (L.older(h) ? I.check : '') + '</span>Older</button>';
  function olderPass(t) {
    const l = listOf(t, 'older'), n = l.filter(L.older).length;
    return '<div class="lod-olderhead"><p class="wk-kicker">Mark older</p><p class="lod-help">' + (n ? plural(n, 'household') + ' marked' : 'None marked') + '</p><button type="button" class="wk-btn wk-btn--small" data-act="olderdone">Done</button>' +
      '<p class="lod-help lod-olderwhy">They go first, onto ground floors near the dining hall. Lodging’s own mark; never shown to anyone else.</p></div>' +
      '<ul class="lod-olderlist">' + l.map(h => '<li><span><b>' + esc(h.sur) + '</b>' + (h.firsts ? ' · ' + esc(h.firsts) : '') + '<small>' + parts([h.walker ? (h.walkerFromNote ? 'Note mentions stairs' : 'Step-free') : '', h.ground ? 'Ground floor' : '', L.given(h).length ? L.roomsWords(L.given(h)) : '']) + '</small></span>' + olderBox(h) + '</li>').join('') + '</ul>';
  }
  function tagsOf(h) {
    const c = L.nearCands(h);
    return [h.walker ? (h.walkerFromNote ? 'Note mentions stairs' : 'Step-free') : '', h.ground ? 'Ground floor' : '', h.nearW ? 'Near women’s restroom' : '', h.nearM ? 'Near men’s restroom' : '',
      h.nearText ? 'Near ' + (c.length === 1 ? c[0].sur : h.nearText.replace(/^near\s+/i, '')) : ''].filter(Boolean);
  }
  function metaList(h) {
    const yf = h.yfs.length, n = h.inRooms.length;
    return [h.active && yf ? n + ' in rooms' : plural(n || h.people.length, 'person', 'people'), yf ? plural(yf, 'Youngfolk') : '', h.active ? plural(h.asked, 'room') : '', L.someNights(h.nights), h.source === 'form' ? 'Form' : h.source === 'desk' ? 'Desk' : ''];
  }
  const metaOf = h => metaList(h).filter(Boolean).join(' · ');
  L.metaOf = metaOf;
  function qItem(h, sug, status) {
    const on = U.sel === h.rid, mine = L.given(h), rv = L.toReview(h), ch = L.changes(h);
    const review = U.list === 'review' && !U.find && !L.ro && (rv.length || ch.length);
    const tags = tagsOf(h), drag = !L.ro && !narrow() && h.active && !touch();
    const roomLine = status ? esc(status) : mine.length ? '<b>' + esc(L.roomsWords(mine)) + '</b>' : sug ? 'Suggested · ' + esc(L.roomsWords(sug)) : h.active ? '<span class="lod-why">' + esc(L.whyNot(h)) + '</span>' : '';
    const aria = [h.label, metaOf(h), tags.join(', '), rv.map(x => x.text).join(', '), ch.map(x => x.text).join(', '), mine.length ? L.roomsWords(mine) : sug ? 'suggested ' + L.roomsWords(sug) : ''].filter(Boolean).join(', ');
    // The card's corner: Looks right on a Review card (it belongs to this card), Older elsewhere (not
    // while the household is open: its panel has it).
    const corner = review ? '<button type="button" class="lod-ok" data-' + (rv.length ? 'ok' : 'seen') + '="' + esc(h.rid) + '">' + I.check + 'Looks right</button>'
      : L.ro || !h.active || on ? '' : olderBox(h);
    return '<li class="lod-qi' + (review ? ' lod-qi--review' : '') + '"' + (drag ? ' draggable="true" data-drag="' + esc(h.rid) + '"' : '') + '>' +
      '<button type="button" class="lod-hh' + (on ? ' is-sel' : '') + (rv.length ? ' is-look' : '') + '" data-sel="' + esc(h.rid) + '" aria-pressed="' + on + '" aria-label="' + esc(aria) + '">' +
      (drag ? '<span class="lod-grip" aria-hidden="true">' + I.grip + '</span>' : '') +
      '<span class="lod-hh__n"><b>' + esc(h.sur) + '</b>' + (h.firsts ? '<span> · ' + esc(h.firsts) + '</span>' : '') + (isNew(h) ? ' <span class="lod-new">New</span>' : '') + '</span>' +
      '<span class="lod-hh__m">' + parts(metaList(h)) + '</span>' +
      (rv.length || ch.length || tags.length ? '<span class="lod-hh__f">' + rv.map(x => '<i class="is-warn"' + (x.title ? ' title="' + esc(x.title) + '"' : '') + '>' + esc(x.text) + '</i>').join('') + ch.map(x => '<i class="is-change">' + esc(x.text) + '</i>').join('') + tags.map(x => '<i>' + esc(x) + '</i>').join('') + '</span>' : '') +
      (roomLine ? '<span class="lod-hh__r">' + roomLine + '</span>' : '') + '</button>' + corner +
      (review ? '<div class="lod-fixes">' + fixButtons(h, rv) + (ch.some(x => x.free) ? '<button type="button" class="lod-fix" data-free="' + esc(h.rid) + '">Free ' + esc(L.roomsWords(mine)) + '</button>' : '') + '</div>' : '') +
      '</li>';
  }

  /* ================================================================ fixes for what's in Review */

  // One tap that fixes an issue, when there's an obvious one.
  function fixFor(h, x) {
    const g = L.given(h);
    if (x.k === 'group') { const s = groupMove(h); return s ? { t: 'Move to ' + L.roomsWords(s) + ' with the others', act: 'move', v: s.join(',') } : null; }
    if (['ground', 'older', 'restroom', 'apart', 'near', 'bath', 'kept', 'outroom'].indexOf(x.k) > -1) {
      const s = moveSuggestion(h);
      return s ? { t: 'Move to ' + L.roomsWords(s) + (x.k === 'ground' || x.k === 'older' ? ' · ground floor' : ''), act: 'move', v: s.join(',') } : null;
    }
    if (x.k === 'short' || x.k === 'over') { const s = addRoom(h); return s ? { t: 'Add ' + L.roomWords(s), act: 'add', v: s } : null; }
    if (x.k === 'extra') return { t: 'Free ' + L.roomWords(g[g.length - 1]), act: 'drop', v: g[g.length - 1] };
    if (x.k === 'keys') { const o = h.adults.find(p => !p.nights || !p.nights.length || p.nights.indexOf(h.nights[0]) > -1); return o ? { t: 'Keys to ' + L.first(o.name), act: 'keys', v: x.room + '|' + o.name } : null; }
    return null;
  }
  function fixButtons(h, rv) {
    const out = [];
    rv.forEach(x => {
      // Which household "near the Shaffers" means: each with where it is, in plain words.
      if (x.k === 'nearpick') { L.nearCands(h).slice(0, 4).forEach(c => out.push('<button type="button" class="wk-linklike lod-pickone" data-fix="link" data-rid="' + esc(h.rid) + '" data-v="' + esc(c.rid) + '">' + esc(c.label + ' · ' + where(c)) + '</button>')); return; }
      const f = fixFor(h, x);
      if (f && !out.some(o => o.indexOf('data-v="' + esc(f.v) + '"') > -1)) out.push('<button type="button" class="lod-fix" data-fix="' + f.act + '" data-rid="' + esc(h.rid) + '" data-v="' + esc(f.v) + '">' + esc(f.t) + '</button>');
    });
    return out.join('');
  }
  // Where it would go if planned again on its own (its rooms freed for the planning).
  function moveSuggestion(h) {
    const keep = L.hrow(h).rooms;
    const row = S.rows['hh:' + h.rid];
    if (row) row.data = Object.assign({}, row.data, { rooms: [] });
    const p = L.plan([h])[h.rid];
    if (row) row.data = Object.assign({}, row.data, { rooms: keep });
    return p && p.join('|') !== (keep || []).join('|') ? p : null;
  }
  // A group split over floors: free rooms on the floor most of the group is on.
  function groupMove(h) {
    const floor = L.groupFloor(h);
    if (!floor) return null;
    // Never away from a ground floor someone asked for.
    if (L.firstGroup(h) && +floor.split('|')[1] !== 1) return null;
    const t = L.taken(h.rid), need = Math.max(1, L.given(h).length || h.asked);
    const f = S.floors.find(x => x.hall + '|' + x.floor === floor);
    if (!f) return null;
    for (let i = 0; i + need <= f.rooms.length; i++) {
      const run = f.rooms.slice(i, i + need);
      if (run.every((r, k) => !t[r.id] && L.usable(r.id) && (k === 0 || !r.gap))) return run.map(r => r.id);
    }
    return null;
  }
  // A free room beside its rooms.
  function addRoom(h) {
    const g = L.given(h).map(L.room).filter(Boolean), t = L.taken();
    for (const r of g) {
      const f = S.floors.find(x => x.rooms.indexOf(r) > -1), i = f.rooms.indexOf(r);
      for (const j of [i + 1, i - 1]) { const o = f.rooms[j]; if (o && !t[o.id] && L.usable(o.id) && !(j > i ? o.gap : r.gap)) return o.id; }
    }
    const p = L.plan([Object.assign({}, h, { asked: 1, rid: h.rid + '~' })]);
    return (p[h.rid + '~'] || [])[0] || null;
  }

  /* ================================================================ the chosen household */

  function side(t) {
    const h = U.sel && L.byRid(U.sel);
    return '<div class="lod-sidegrid' + (h || U.room ? ' has-panel' : '') + '">' + (h ? detail(h, t) : U.room ? roomPanel(U.room, t) : '') + planPanel(h) + '</div>';
  }
  // On a phone with no one open: the halls, folded, so a room's facts can be reached here too.
  function phoneHalls() {
    if (U.sel || !planHalls().length) return '';
    return '<details class="lod-halls"' + (U.hallsOpen ? ' open' : '') + ' data-halls><summary>Halls</summary>' + (U.room ? roomPanel(U.room, tally()) : '') + planPanel(null) + '</details>';
  }
  // On a phone: the chosen household full screen, with its floor below.
  function sheet(t) {
    const h = L.byRid(U.sel);
    if (!h) return '';
    return '<div class="lod-full" role="dialog" aria-modal="true" aria-labelledby="lod-dh"><div class="lod-full__bar"><button type="button" class="lod-full__x" data-act="close" aria-label="Close">' + I.close + '</button><p>' + esc(where(h)) + '</p></div>' +
      '<div class="lod-full__in">' + detail(h, t, true) + '</div>' + (L.ro || !h.active ? '' : '<div class="lod-full__foot">' + actions(h, t, true) + '</div>') + '</div>';
  }
  function suggestionOf(h) {
    if (!h.active || L.given(h).length) return null;
    return L.plan(L.dorm().filter(x => !L.given(x).length))[h.rid] || null;
  }
  function actions(h, t, phone) {
    const g = L.given(h), sug = suggestionOf(h);
    const out = [];
    if (!g.length) {
      out.push('<button type="button" class="wk-btn lod-assign" data-act="assign" data-rid="' + esc(h.rid) + '"' + (sug ? '' : ' disabled') + ' title="' + esc(sug ? 'Then the next household' : L.whyNot(h)) + '">' + esc(sug ? 'Assign · ' + L.roomsWords(sug) : 'Assign') + '</button>');
      if (!sug) out.push('<button type="button" class="wk-btn wk-btn--line wk-btn--small" data-act="apart" data-rid="' + esc(h.rid) + '">Assign apart</button>');
    } else {
      out.push('<button type="button" class="wk-linklike" data-act="unassign" data-rid="' + esc(h.rid) + '">Unassign</button>');
    }
    if (!phone) out.push('<button type="button" class="wk-linklike" data-act="close">Close</button>');
    return '<p class="lod-acts">' + out.join('') + '</p>';
  }
  // First the decision (who, what they asked, what's wrong, Assign); the rest folded under More, so the
  // plan beside it stays in view.
  function detail(h, t, phone) {
    const g = L.given(h), rv = L.issues(h), ch = L.changes(h), sug = suggestionOf(h), row = L.hrow(h);
    const tags = tagsOf(h), okd = row.ok && row.ok.sig === L.sig(rv);
    const ppl = h.people.map(p => {
      const k = h.kind(p), bits = [];
      if (k === 'child' && p.age) bits.push(p.age);
      if (k === 'yf') bits.push('Youngfolk' + (h.inHall(p) ? ' · ' + (p.yfHall === 'women' ? 'young women’s hall' : p.yfHall === 'men' ? 'young men’s hall' : 'hall not set') : ''));
      if (p.band === 'baby') bits.push('baby');
      const ns = L.someNights(p.nights && p.nights.length ? p.nights : null);
      if (ns) bits.push(ns);
      if (g.length > 1 && p.room != null && !h.inHall(p) && p.band !== 'baby') bits.push(L.roomWords(g[Math.min(p.room, g.length - 1)]) || '');
      return '<li><span>' + esc(p.name) + '</span>' + (bits.length ? '<small>' + esc(bits.filter(Boolean).join(' · ')) + '</small>' : '') + '</li>';
    }).join('');
    const keys = h.active ? L.keysOf(h).map((n, i) => (g.length > 1 || h.asked > 1 ? (g[i] ? L.roomWords(g[i]) : 'Room ' + (i + 1)) + ' · ' : '') + n).join(' · ') : '';
    const bal = L.payWords(h);
    const contact = [h.phone ? '<a href="tel:' + esc(h.phone.replace(/[^\d+]/g, '')) + '">' + I.phone + esc(h.phone) + '</a>' : '', h.email ? '<a href="mailto:' + esc(h.email) + '">' + I.mail + 'Email</a>' : '<span>No email</span>'].filter(Boolean).join('');
    const hist = (h.d.history || []).slice(-6).reverse().map(x => L.md(x.at) + ' · ' + x.what).concat(row.given ? [L.md(row.given.at) + ' · Rooms given · ' + row.given.by] : []);
    const fixes = !L.ro && L.toReview(h).length ? fixButtons(h, rv) + '<button type="button" class="lod-ok lod-ok--inline" data-ok="' + esc(h.rid) + '">' + I.check + 'Looks right</button>' : '';
    const chFix = ch.length && !L.ro ? (ch.some(x => x.free) ? '<button type="button" class="lod-fix" data-free="' + esc(h.rid) + '">Free ' + esc(L.roomsWords(g)) + '</button>' : '') + '<button type="button" class="lod-ok lod-ok--inline" data-seen="' + esc(h.rid) + '">' + I.check + 'Looks right</button>' : '';
    const more = '<dl class="lod-dl">' +
      '<dt>Coming</dt><dd><ul class="lod-people">' + ppl + '</ul></dd>' +
      (keys ? '<dt>Keys</dt><dd>' + esc(keys) + '</dd>' : '') +
      (h.linens || h.mattresses ? '<dt>Bedding</dt><dd>' + esc([h.linens ? plural(h.linens, 'linen packet') : '', h.mattresses ? plural(h.mattresses, 'air mattress', 'air mattresses') : ''].filter(Boolean).join(' · ')) + '</dd>' : '') +
      '<dt>Contact</dt><dd class="lod-contact">' + esc(h.d.household && h.d.household.contact || '') + contact + '</dd>' +
      '<dt>Registered</dt><dd>' + esc([L.md(h.at), h.source === 'form' ? 'Form' : h.source === 'desk' ? 'Desk' : h.source === 'helper' ? 'Helper' : 'Online', h.rid].filter(Boolean).join(' · ')) + '</dd>' +
      (bal ? '<dt>Payment</dt><dd>' + esc(bal) + '</dd>' : '') +
      (h.active ? '<dt>Older</dt><dd>' + (L.ro ? (L.older(h) ? 'Yes' : 'No') : olderBox(h, true)) + (row.older && row.older.by ? ' <small class="lod-by">' + esc(row.older.by + ' · ' + L.md(row.older.at)) + '</small>' : '') + '</dd>' : '') +
      '<dt>Lodging’s note</dt><dd>' + (L.ro ? esc(row.note || '') : '<label class="ogc-sr" for="lod-hnote">Lodging’s note</label><textarea id="lod-hnote" data-hnote="' + esc(h.rid) + '" rows="2" maxlength="500" placeholder="Add note" title="For Lodging only; cleared with the names">' + esc(row.note || '') + '</textarea>') + '</dd>' +
      '</dl>' + (hist.length ? '<details class="lod-hist"><summary>History · ' + hist.length + '</summary><ul>' + hist.map(x => '<li>' + esc(x) + '</li>').join('') + '</ul></details>' : '');
    return '<section class="lod-detail" aria-labelledby="lod-dh">' +
      '<h2 class="lod-detail__h" id="lod-dh"><b>' + esc(h.sur) + '</b>' + (h.firsts ? ' · ' + esc(h.firsts) : '') + '</h2>' +
      '<p class="lod-detail__m">' + parts([where(h)].concat(metaList(h))) + '</p>' +
      (tags.length ? '<p class="lod-tags">' + tags.map(x => '<i>' + esc(x) + '</i>').join('') + '</p>' : '') +
      (h.note ? '<blockquote class="lod-quote"><span class="wk-kicker">Note for Lodging</span>' + esc(h.note) + '</blockquote>' : '') +
      (rv.length && !L.ro ? '<ul class="lod-issues">' + rv.map(x => '<li class="' + (okd ? 'is-ok' : '') + '"><span' + (x.title ? ' title="' + esc(x.title) + '"' : '') + '>' + esc(x.text) + '</span></li>').join('') + '</ul>' +
        (fixes ? '<div class="lod-fixes">' + fixes + '</div>' : '<p class="lod-help">' + I.check + 'Looks right · ' + esc(row.ok.by) + '</p>') : '') +
      (ch.length && !L.ro ? '<ul class="lod-issues is-change">' + ch.map(x => '<li>' + esc(x.text) + '</li>').join('') + '</ul><div class="lod-fixes">' + chFix + '</div>' : '') +
      (L.ro || !h.active || phone ? '' : actions(h, t, false)) +
      (sug && phone ? '<p class="lod-sug">Suggested · <b>' + esc(L.roomsWords(sug)) + '</b>' + esc(sugWords(sug, h)) + '</p>' : sug ? '<p class="lod-sug">' + esc(sugWords(sug, h).replace(/^ · /, '')) + '</p>' : '') +
      (phone ? '</section>' + planPanel(h) + '<section class="lod-detail lod-detail--more" aria-label="Details">' + more + '</section>'
        : '<details class="lod-more"' + (U.moreOpen ? ' open' : '') + ' data-more><summary>More</summary>' + more + '</details></section>');
  }
  // " · ground floor · shares a bath with Turner".
  function sugWords(ids, h) {
    const rs = ids.map(L.room).filter(Boolean), out = [];
    if (rs.every(L.stepFree)) out.push('ground floor');
    if (rs.length === 1) { const m = L.bathMate(rs[0].id), w = m && L.taken(h.rid)[m]; if (w && L.byRid(w)) out.push('shares a bath with ' + L.byRid(w).sur); }
    else if (rs.length === 2 && L.bathMate(rs[0].id) === rs[1].id) out.push('their own bath');
    return out.length ? ' · ' + out.join(' · ') : '';
  }

  /* ================================================================ a room with no one chosen */

  function roomPanel(id, t) {
    const r = L.room(id);
    if (!r) return '';
    const f = L.fact(id), who = L.taken()[id];
    if (who) return '';
    const head = '<h2 class="lod-detail__h">Room ' + r.num + ' <span>' + esc(f.out ? 'Out of service' : f.hold ? 'Kept · ' + f.hold : 'Free') + '</span></h2><p class="lod-detail__m">' + esc(r.hall + ' · ' + L.floorName(r.floor)) + '</p>';
    const near = O.map && S.plans[r.hall] ? (() => { const fl = S.plans[r.hall].floors[r.floor], sh = fl && fl.rooms.find(s => s.label === String(r.num)); return sh ? O.map.near(fl, sh) : []; })() : [];
    // Who'd fit it: step-free asks for a ground-floor room, one-room households for a single, two-room ones when its bath mate is free.
    const mate = L.bathMate(id), mateFree = mate && !L.taken()[mate] && L.usable(mate);
    const fits = t.waiting.map(h => {
      let sc = 0;
      if (L.stepFree(r)) sc += L.firstGroup(h) ? 50 : -20;
      else sc += L.firstGroup(h) ? -60 : 0;
      if (h.asked === 1) sc += 10; else if (h.asked === 2 && mateFree) sc += 12; else sc -= 30;
      return { h, sc };
    }).sort((a, b) => b.sc - a.sc);
    const q = (U.giveFind || '').trim().toLowerCase();
    const list = (q ? fits.filter(x => x.h.label.toLowerCase().indexOf(q) > -1 || x.h.people.some(p => p.name.toLowerCase().indexOf(q) > -1)) : fits.slice(0, 4));
    const give = f.out || L.ro ? '' : '<p class="lod-sub">Give to</p>' + (t.waiting.length > 4 ? '<label class="lod-find lod-find--small"><span class="ogc-sr">Search households</span>' + I.search + '<input type="search" data-givefind placeholder="Search" value="' + esc(U.giveFind || '') + '" autocomplete="off"></label>' : '') +
      (list.length ? '<ul class="lod-give">' + list.map(x => { const both = x.h.asked === 2 && mateFree; return '<li><button type="button" data-give="' + esc(x.h.rid) + '" data-room="' + esc(id) + '"><b>' + esc(x.h.sur) + '</b>' + (x.h.firsts ? ' · ' + esc(x.h.firsts) : '') + '<small>' + parts([metaOf(x.h), both ? 'Gets ' + r.num + ' and ' + L.room(mate).num : '', L.firstGroup(x.h) ? 'ground floor asked' : '']) + '</small></button></li>'; }).join('') + '</ul>' : '<p class="lod-help">' + (t.waiting.length ? 'No matches' : 'Everyone has rooms') + '</p>');
    const facts = L.ro ? '' : '<details class="lod-roomfacts"' + (U.factsOpen ? ' open' : '') + ' data-facts><summary>This room</summary>' +
      '<label class="lod-hold"><span>Hold for</span><input type="text" data-hold="' + esc(id) + '" value="' + esc(f.hold || '') + '" maxlength="30" placeholder="COA, speakers, walk-ins" title="Kept back: Assign all leaves it free"></label>' +
      '<p class="lod-toggles">' + [['out', 'Out of service'], ['access', 'Accessible']].map(x => '<button type="button" class="lod-tog" data-fact="' + x[0] + '" data-room="' + esc(id) + '" aria-pressed="' + !!f[x[0]] + '"><span class="lod-box" aria-hidden="true">' + (f[x[0]] ? I.check : '') + '</span>' + x[1] + '</button>').join('') +
      '<span class="lod-beds"><span>Beds</span><button type="button" data-beds="-1" data-room="' + esc(id) + '" aria-label="Fewer beds">−</button><b>' + L.beds(id) + '</b><button type="button" data-beds="1" data-room="' + esc(id) + '" aria-label="More beds">+</button></span></p></details>';
    return '<section class="lod-detail lod-roompanel">' + head + (near.length ? '<p class="lod-detail__m">' + esc(near.join(' · ')) + '</p>' : '') + give + facts + '<p class="lod-acts"><button type="button" class="wk-linklike" data-act="closeroom">Close</button></p></section>';
  }

  /* ================================================================ the plan */

  const planHalls = () => Array.from(new Set(L.familyFloors().map(f => f.hall))).filter(h => S.plans[h] && S.plans[h].list.length);
  // The smallest scale (px a foot) that keeps a 16 ft room's number at 11 px or more.
  const MIN_K = 2;
  function planPanel(h) {
    const halls = planHalls();
    if (!halls.length) return '';
    const g = h ? L.given(h) : [], sug = h ? (suggestionOf(h) || []) : [];
    // The hall and floor: the chosen household's (or its suggestion's), else where the person was.
    const at = L.room(g[0] || sug[0]);
    if (at && (U.followed !== (h && h.rid))) { U.hall = at.hall; U.floor = at.floor; U.followed = h && h.rid; }
    const hall = halls.indexOf(U.hall) > -1 ? U.hall : halls[0], P = S.plans[hall];
    const fl = P.list.find(x => x.floor === U.floor) || P.list[0];
    U.hall = hall; U.floor = fl.floor;
    const t = L.taken(h ? h.rid : null), partner = h && L.nearOf(h), pr = partner ? L.given(partner) : [];
    const freeIn = rooms => rooms.filter(r => L.room(r.id) && !t[r.id] && g.indexOf(r.id) < 0 && L.usable(r.id)).length;
    const st = r => {
      if (g.indexOf(r.id) > -1) return 'sel';
      if (!L.room(r.id)) return 'off';
      const f = L.fact(r.id);
      if (f.out) return 'off';
      if (t[r.id]) return pr.indexOf(r.id) > -1 ? 'other' : 'taken';
      if (sug.indexOf(r.id) > -1) return 'sug';
      if (f.hold) return 'held';
      if (U.room === r.id) return 'sug';
      return 'free';
    };
    // Who's in a room is in its title (hover, a screen reader) and in the list beside it, never squeezed
    // onto the drawing (polish 1: names shrunk to 5 px and cut by the bath marks).
    const label = (r, s) => {
      const w = t[r.id], x = w && L.byRid(w);
      return 'Room ' + r.label + ', ' + ({ sel: 'given to ' + (h ? h.label : ''), off: L.fact(r.id).out ? 'out of service' : 'not ours', taken: x ? x.label + (x.walker ? ' · step-free' : L.older(x) ? ' · older' : '') : 'Youngfolks', other: (x ? x.label : '') + ', near request', sug: 'suggested', held: 'kept · ' + L.fact(r.id).hold, free: 'free' })[s];
    };
    const minutes = x => { const m = L.hallRank(x); return m < 99 ? ' · ' + m + ' min to dining' : ''; };
    const hallTabs = halls.length > 1 ? '<div class="lod-ptabs" role="group" aria-label="Hall">' + halls.map(x => '<button type="button" data-hall="' + esc(x) + '" aria-pressed="' + (x === hall) + '">' + esc(L.hallShort(x)) + '<small>' + freeIn([].concat.apply([], S.plans[x].list.map(f => f.rooms))) + ' free' + esc(minutes(x)) + '</small></button>').join('') + '</div>' : '';
    const floorTabs = '<div class="lod-ptabs lod-ptabs--floors" role="group" aria-label="Floor">' + P.list.map(f => {
      const here = h && g.concat(sug).some(id => L.room(id) && L.room(id).hall === hall && L.room(id).floor === f.floor);
      return '<button type="button" data-floor="' + f.floor + '" aria-pressed="' + (f.floor === fl.floor) + '">' + esc(f.floor === 1 ? 'Ground' : L.floorName(f.floor).replace(' floor', '')) + '<small>' + freeIn(f.rooms) + ' free' + (here ? ' · ' + esc(h.sur) + ' here' : '') + '</small></button>';
    }).join('') + '</div>';
    const states = {};
    fl.rooms.forEach(r => { states[st(r)] = 1; });
    // A key only when the floor shows more than one kind of room (a lone "Free" read as a check box).
    const legend = Object.keys(states).length < 2 ? '' : '<ul class="lod-legend" aria-hidden="true">' + [['free', 'Free'], ['taken', 'Taken'], ['sel', h ? h.sur : 'Chosen'], ['sug', U.room && !h ? 'Open' : 'Suggested'], ['other', 'Near request'], ['held', 'Kept'], ['off', 'Out of service']].filter(x => states[x[0]]).map(x => '<li><i class="is-' + x[0] + '"></i>' + esc(x[1]) + '</li>').join('') + '</ul>';
    const zoom = narrow() ? '' : '<p class="lod-zoom" role="group" aria-label="Zoom"><button type="button" data-zoom="-1" aria-label="Zoom out">−</button><button type="button" data-zoom="1" aria-label="Zoom in">+</button></p>';
    const band = narrow() || !!U.band;
    return '<section class="lod-planbox" aria-label="Floor plan">' + hallTabs + '<div class="lod-planhead">' + floorTabs + zoom + '</div><div class="lod-plan' + (band ? ' is-band' : '') + '" data-hallplan="' + esc(hall) + '">' +
      O.map.floorSvg(fl, { state: st, label, pick: !L.ro, pickAll: true, turn: O.map.turnFor(fl, band), narrow: band, beds: r => L.beds(r.id), title: hall + ', ' + L.floorName(fl.floor) }) + '</div>' + legend + '</section>';
  }
  // Fitted to its box at every width, never so small a room's number drops under 11 px: when the
  // whole floor can't fit at that, the hall is drawn a wing at a time (as on a phone), each wing fitted.
  function sizePlan() {
    const box = root.querySelector('.lod-plan');
    if (!box) return;
    const hall = box.dataset.hallplan, P = S.plans[hall];
    if (!P) return;
    const avail = box.clientWidth - 26, zoom = Math.pow(1.25, U.zoom || 0);
    if (!narrow()) {
      const widest = Math.max.apply(null, P.list.map(f => (O.map.turnFor(f, false) ? f.bounds.h : f.bounds.w))) + 12;
      const fits = avail / widest >= MIN_K;
      if (fits === !!U.band) { U.band = !fits; L.redraw(); return; }
    }
    box.querySelectorAll('svg.pl-floor').forEach(s => {
      const vb = s.viewBox.baseVal;
      const k = Math.max(MIN_K, Math.min(7, avail / vb.width)) * zoom;
      s.style.width = Math.round(vb.width * k) + 'px'; s.style.maxWidth = 'none';
    });
    // One tab stop for the whole plan: arrow keys move between its rooms.
    const rooms = Array.from(box.querySelectorAll('[data-room][role="button"]'));
    const h = U.sel && L.byRid(U.sel), first = h && L.given(h)[0];
    rooms.forEach(g => g.setAttribute('tabindex', '-1'));
    const on = rooms.find(g => g.dataset.room === (U.focusRoom || first)) || rooms[0];
    if (on) on.setAttribute('tabindex', '0');
    if (first || U.focusRoom) O.map.reveal(box, U.focusRoom || first);
  }

  function afterRender() {
    sizePlan();
    document.documentElement.classList.toggle('lod-noscroll', narrow() && !!U.sel);
    const s = root.querySelector('.lod-full');
    if (s && !s.contains(document.activeElement)) { const x = s.querySelector('.lod-full__x'); if (x) x.focus({ preventScroll: true }); }
  }

  /* ================================================================ doing things */

  L.show = rid => { U.sel = rid; U.room = ''; U.find = ''; U.followed = ''; const h = L.byRid(rid); if (h) U.list = L.given(h).length ? (tally().review.indexOf(h) > -1 ? 'review' : 'done') : 'todo'; if (S.view !== 'rooms') L.go('rooms'); else L.render(); };
  function pick(rid) {
    U.sel = U.sel === rid ? '' : rid; U.room = ''; U.followed = ''; U.focusRoom = '';
    L.redraw();
    if (!narrow()) { const sd = root.querySelector('#lod-side'); if (sd && U.sel && sd.getBoundingClientRect().top < 0) sd.scrollIntoView({ block: 'start' }); }
    L.say(U.sel ? L.byRid(rid).label + ' · ' + where(L.byRid(rid)) : 'Closed');
  }
  // The next household waiting, after this one.
  function nextAfter(rid) {
    const t = tally(), l = listOf(t, 'todo').filter(x => x.rid !== rid);
    return l[0] || null;
  }
  function setRooms(h, ids, label) {
    return L.hhSave(h, { rooms: ids && ids.length ? ids : null }, { label: label || (ids && ids.length ? h.sur + ' · ' + L.roomsWords(ids) : h.sur + ' · Unassigned') });
  }
  function assignOne(h) {
    const sug = suggestionOf(h);
    if (!sug) { L.toast(L.whyNot(h)); return; }
    const nx = nextAfter(h.rid);
    setRooms(h, sug);
    U.sel = nx ? nx.rid : ''; U.followed = '';
    L.redraw();
    const b = root.querySelector(nx ? '[data-sel="' + CSS.escape(nx.rid) + '"]' : '.lod-status');
    if (b) b.focus && b.focus({ preventScroll: true });
    L.say(h.sur + ' · ' + L.roomsWords(sug) + (nx ? ' · Next · ' + nx.label : ''));
  }
  function assignAll() {
    const t = tally(), plan = L.plan(t.waiting);
    const ops = Object.keys(plan).map(rid => { const cur = Object.assign({}, L.hrow(rid), { rooms: plan[rid] }); return { key: 'hh:' + rid, data: cur }; });
    if (!ops.length) { L.toast('No rooms free'); return; }
    const notPlaced = t.waiting.length - ops.length;
    U.older = false;
    L.save(ops, { label: plural(ops.length, 'household') + ' assigned', silent: true, done: res => {
      const after = tally();
      L.toast([ops.length + ' assigned', notPlaced ? notPlaced + ' not placed' : '', after.review.length ? after.review.length + ' to review' : ''].filter(Boolean).join(' · '), res.undo ? { undo: res.undo.id } : null);
      U.list = after.review.length ? 'review' : after.waiting.length ? 'todo' : 'done';
      U.sel = '';
      L.redraw();
      const s = root.querySelector('.lod-status'); if (s) { s.setAttribute('tabindex', '-1'); s.focus({ preventScroll: true }); }
    } });
  }
  // A room tapped on the plan.
  function tapRoom(id) {
    const r = L.room(id);
    if (!r || L.ro) return;
    U.focusRoom = id;
    const h = U.sel && L.byRid(U.sel), owner = L.taken(h ? h.rid : null)[id];
    if (owner && owner !== 'yf') { if (!h || owner !== h.rid) { pick(owner); return; } }
    if (owner === 'yf') { L.toast(L.roomWords(id) + ' · Youngfolks'); return; }
    if (h && h.active) {
      const g = L.given(h), i = g.indexOf(id);
      if (L.fact(id).out && i < 0) { L.toast(L.roomWords(id) + ' is out of service'); return; }
      const next = i > -1 ? g.filter(x => x !== id) : g.concat(id).sort((a, b) => S.rooms.indexOf(L.room(a)) - S.rooms.indexOf(L.room(b)));
      setRooms(h, next, i > -1 ? h.sur + ' · ' + L.roomWords(id) + ' freed' : h.sur + ' · ' + L.roomWords(id) + (L.fact(id).hold ? ' (kept · ' + L.fact(id).hold + ')' : ''));
      return;
    }
    U.room = U.room === id ? '' : id; U.giveFind = '';
    L.redraw();
  }
  // The rooms a household would take starting at a room: it and the free ones beside it.
  function runAt(h, id) {
    const r = L.room(id), t = L.taken(h.rid);
    if (!r || t[id]) return null;
    const f = S.floors.find(x => x.rooms.indexOf(r) > -1), need = Math.max(1, h.asked || 1);
    const run = [r];
    if (f && need > 1) {
      const i = f.rooms.indexOf(r);
      for (let k = i + 1; k < f.rooms.length && run.length < need && !f.rooms[k].gap && !t[f.rooms[k].id] && L.usable(f.rooms[k].id); k++) run.push(f.rooms[k]);
      for (let k = i - 1; k >= 0 && run.length < need && !f.rooms[k + 1].gap && !t[f.rooms[k].id] && L.usable(f.rooms[k].id); k--) run.unshift(f.rooms[k]);
    }
    return run.map(x => x.id);
  }
  // Dropped on a room: there (free), or swapped with whoever has it.
  function dropOn(rid, id) {
    const h = L.byRid(rid), owner = L.taken(rid)[id];
    if (!h || !L.room(id) || !h.active) return;
    if (owner === 'yf') { L.toast(L.roomWords(id) + ' · Youngfolks'); return; }
    if (owner) {
      const o = L.byRid(owner), mine = L.given(h), theirs = L.given(o);
      if (!mine.length) { L.toast('Room ' + L.room(id).num + ' is taken · ' + o.label); return; }
      L.save([{ key: 'hh:' + h.rid, data: Object.assign({}, L.hrow(h), { rooms: theirs }) }, { key: 'hh:' + o.rid, data: Object.assign({}, L.hrow(o), { rooms: mine }) }], { label: 'Swapped ' + h.sur + ' and ' + o.sur });
      return;
    }
    const run = runAt(h, id);
    if (run) { U.sel = h.rid; U.followed = ''; setRooms(h, run); }
  }

  /* ================================================================ publish, export */

  const dlg = document.createElement('dialog');
  dlg.className = 'ogc wk-sheet lod-dlg';
  dlg.setAttribute('aria-labelledby', 'lod-dlg-h');
  document.body.appendChild(dlg);
  function confirmPublish(mode) {
    const t = tally(), names = t.pubChanged.map(L.byRid).filter(Boolean);
    const left = [t.waiting.length ? t.waiting.length + ' unassigned' : '', t.review.length ? t.review.length + ' to review' : ''].filter(Boolean);
    const n = Object.keys(L.assign()).length, shown = t.pub ? Object.keys(t.pub.snap || {}).length : 0;
    const forms = Object.keys(L.assign()).map(L.byRid).filter(h => h && h.source === 'form').length;
    const h = mode === 'update' ? 'Send update' : mode === 'unpublish' ? 'Unpublish' : 'Publish rooms';
    const body = mode === 'unpublish' ? '<p>' + plural(shown, 'household') + ' stop seeing their rooms</p>'
      : mode === 'update' ? '<p>' + plural(names.length, 'household') + ' · rooms changed since ' + esc(L.md(t.pub.date)) + '</p><ul class="lod-dlg__list">' + names.slice(0, 8).map(x => '<li>' + esc(x.label + ' · ' + (L.given(x).length ? L.roomsWords(L.given(x)) : 'no rooms')) + '</li>').join('') + (names.length > 8 ? '<li>' + (names.length - 8) + ' more</li>' : '') + '</ul>'
        : '<p>' + plural(n, 'household') + ' · rooms in Your sign-ups</p>' + (forms ? '<p class="lod-help">' + plural(forms, 'household') + ' from the Form see theirs when they sign in with the email they used, or at the desk</p>' : '');
    dlg.innerHTML = '<div class="wk-sheet__in"><h2 class="wk-sheet__h" id="lod-dlg-h">' + h + '</h2>' + body +
      (mode !== 'unpublish' && left.length ? '<p class="lod-dlg__warn">' + esc(left.join(' · ')) + '</p>' : '') +
      (mode !== 'unpublish' ? '<label class="lod-check"><input type="checkbox" data-email> <span>Email them <small>' + (mode === 'update' ? 'Your rooms changed' : 'Your rooms are posted') + '</small></span></label>' : '') +
      '<p class="wk-sheet__btns"><button type="button" class="wk-btn' + (mode === 'unpublish' ? ' wk-btn--line' : '') + '" data-go="' + mode + '">' + (mode === 'publish' && left.length ? 'Publish anyway' : h) + '</button><button type="button" class="wk-linklike" data-cancel>Cancel</button></p></div>';
    dlg.showModal();
    // Undoing everyone's rooms is never the default: Cancel has the focus there.
    dlg.querySelector(mode === 'unpublish' ? '[data-cancel]' : '[data-go]').focus();
  }
  dlg.addEventListener('click', e => {
    if (e.target === dlg || e.target.closest('[data-cancel]')) { dlg.close(); return; }
    const go = e.target.closest('[data-go]');
    if (!go) return;
    const mode = go.dataset.go, email = !!(dlg.querySelector('[data-email]') || {}).checked;
    go.disabled = true;
    L.api('POST', '/publish', { mode, email }).then(res => {
      dlg.close();
      S.rows['meta:published'] = { data: res.published, v: 0, by: S.me, at: '' };
      L.toast(mode === 'unpublish' ? 'Unpublished' : (mode === 'update' ? 'Update sent · ' : 'Published · ') + plural(res.changed || 0, 'household') + (res.notified ? ' · ' + res.notified + ' emailed' : ''));
      L.refresh(true);
    }, err => { go.disabled = false; L.toast(err.message || 'Not published'); });
  });

  // A night's date (an early night: the last day of that name before the first).
  L.nightDate = n => {
    const days = (S.model && S.model.days) || [];
    if (SU.isEarly(n)) return SU.earlyDate(n, days[0] && days[0].date);
    const d = days.find(x => x.name.slice(0, 3).toLowerCase() === String(n).slice(0, 3).toLowerCase());
    return d ? d.date : '';
  };
  L.arrive = ns => ns && ns.length ? L.nightDate(ns[0]) : '';
  L.depart = ns => { const d = ns && ns.length ? L.nightDate(ns[ns.length - 1]) : ''; return d ? O.isoAddDays(d, 1) : ''; };
  L.dateShort = iso => iso ? O.fmtDate(iso, 'mdShort') : '';
  // A spreadsheet file: UTF-8 with a byte-order mark (Excel on Windows reads it right), and logged.
  L.download = (rows, name, list) => {
    SU.save('﻿' + SU.csv(rows), 'text/csv;charset=utf-8', name);
    L.api('POST', '/log', { what: 'export', list, rows: rows.length - 1 }).catch(() => {});
  };
  L.stamp = () => O.wallNow((S.model && S.model.tz) || 'America/Indiana/Indianapolis').date;
  // The rooming list for the campus: one line a room; who sleeps in it, arrival and departure dates, keys.
  function roomingCsv() {
    const rows = [['Hall', 'Floor', 'Room', 'Household', 'People', 'Names', 'Arrive', 'Depart', 'Keys', 'Key holder', 'Linen packets', 'Air mattresses', 'Needs']];
    const perPerson = S.cfg.keys_per === 'person', a = L.assign();
    S.rooms.forEach(r => {
      const rid = Object.keys(a).find(k => a[k].indexOf(r.id) > -1), h = rid && L.byRid(rid);
      if (!h) return;
      const ids = a[rid], i = ids.indexOf(r.id), n = ids.length, share = v => Math.floor(v / n) + (i < v % n ? 1 : 0);
      const setup = (L.hrow(h).setup || {})[r.id];
      const here = L.inRoom(h, i);
      const ns = here.length ? Array.from(new Set([].concat.apply([], here.map(p => p.nights && p.nights.length ? p.nights : h.nights)))) : h.nights;
      const ord = SU.nightsOf(S.cfg), nsSorted = ns.slice().sort((x, y) => ord.indexOf(x) - ord.indexOf(y));
      rows.push([r.hall, r.floor, r.num, h.sur + (h.firsts ? ', ' + h.firsts : ''), here.length, here.map(p => p.name).join('; '), L.arrive(nsSorted), L.depart(nsSorted), perPerson ? here.filter(p => p.band !== 'baby').length : 1, L.keysOf(h)[i] || '',
        setup ? setup.l : share(h.linens) || '', setup ? setup.m : share(h.mattresses) || '', h.walker ? 'Step-free' : h.ground ? 'Ground floor' : '']);
    });
    L.download(rows, (S.settings.venue || 'Campus') + ' rooming list ' + S.year + ' ' + L.stamp() + '.csv', 'rooming');
    L.toast('Rooming list · ' + plural(rows.length - 1, 'room'));
  }

  /* ================================================================ events */

  root.addEventListener('toggle', e => {
    const d = e.target;
    if (!d || !d.matches) return;
    if (d.matches('[data-steps]')) U.stepsOpen = d.open;
    else if (d.matches('[data-more]')) U.moreOpen = d.open;
    else if (d.matches('[data-facts]')) U.factsOpen = d.open;
    else if (d.matches('[data-halls]')) { U.hallsOpen = d.open; if (d.open) sizePlan(); }
  }, true);
  root.addEventListener('click', e => {
    if (S.view !== 'rooms') return;
    const el = e.target.closest('[data-sel], [data-list], [data-older], [data-act], [data-step], [data-ok], [data-seen], [data-free], [data-fix], [data-hall], [data-floor], [data-give], [data-fact], [data-beds], [data-zoom], .lod-plan [data-room]');
    if (!el) return;
    const ds = el.dataset;
    if (ds.sel) { pick(ds.sel); return; }
    if (ds.list) { U.list = ds.list; U.find = ''; U.older = false; L.redraw(); return; }
    if (ds.older) { const h = L.byRid(ds.older); L.hhSave(h, { older: !L.older(h) }, { label: h.sur + (L.older(h) ? ' · Not older' : ' · Older') }); return; }
    if (ds.ok) { const h = L.byRid(ds.ok); L.hhSave(h, { ok: { sig: L.sig(L.issues(h)) } }, { label: h.sur + ' · Looks right' }); return; }
    if (ds.seen) { const h = L.byRid(ds.seen), patch = { snap: true }; if (L.toReview(h).length) patch.ok = { sig: L.sig(L.issues(h)) }; L.hhSave(h, patch, { label: h.sur + ' · Looks right' }); return; }
    if (ds.free) { const h = L.byRid(ds.free); setRooms(h, null, h.sur + ' · ' + L.roomsWords(L.given(h)) + ' freed'); return; }
    if (ds.fix) {
      const h = L.byRid(ds.rid), v = ds.v;
      if (ds.fix === 'move') setRooms(h, v.split(','));
      else if (ds.fix === 'add') setRooms(h, L.given(h).concat(v));
      else if (ds.fix === 'drop') setRooms(h, L.given(h).filter(x => x !== v), h.sur + ' · ' + L.roomWords(v) + ' freed');
      else if (ds.fix === 'link') L.hhSave(h, { near: v }, { label: h.sur + ' · Near ' + L.byRid(v).sur });
      else if (ds.fix === 'keys') { const [i, n] = v.split('|'); const k = Object.assign({}, L.hrow(h).keys || {}); k[i] = n; L.hhSave(h, { keys: k }, { label: h.sur + ' · Keys to ' + L.first(n) }); }
      return;
    }
    if (ds.hall) { U.hall = ds.hall; U.floor = 0; U.followed = U.sel; U.focusRoom = ''; L.redraw(); return; }
    if (ds.floor) { U.floor = +ds.floor; U.followed = U.sel; U.focusRoom = ''; L.redraw(); return; }
    if (ds.zoom) { U.zoom = Math.max(-2, Math.min(4, (U.zoom || 0) + (+ds.zoom))); sizePlan(); return; }
    if (ds.give) { const h = L.byRid(ds.give), mate = L.bathMate(ds.room), both = h.asked === 2 && mate && !L.taken()[mate] && L.usable(mate); U.room = ''; setRooms(h, both ? [ds.room, mate] : [ds.room]); return; }
    if (ds.fact) { const f = Object.assign({}, L.data('room:' + ds.room) || {}); f[ds.fact] = !L.fact(ds.room)[ds.fact]; if (!f[ds.fact]) delete f[ds.fact]; L.save([{ key: 'room:' + ds.room, data: Object.keys(f).length ? f : null }], { label: L.roomWords(ds.room) + (f[ds.fact] ? ' · ' : ' · Not ') + (ds.fact === 'out' ? 'out of service' : 'accessible') }); return; }
    if (ds.beds) { const f = Object.assign({}, L.data('room:' + ds.room) || {}), b = Math.max(1, Math.min(8, L.beds(ds.room) + (+ds.beds))); f.beds = b; L.save([{ key: 'room:' + ds.room, data: f }], { label: L.roomWords(ds.room) + ' · ' + plural(b, 'bed') }); return; }
    if (ds.room && el.closest('.lod-plan')) { tapRoom(ds.room); return; }
    if (ds.step) {
      const a = ds.step;
      if (a === 'import') location.href = '?year=' + S.year + '&view=import' + (S.asOf ? '&as-of=' + S.asOf : '');
      else if (a === 'older') { U.older = true; U.sel = ''; U.room = ''; L.redraw(); }
      else if (a === 'assign') { U.list = 'todo'; U.older = false; L.redraw(); }
      else if (a === 'review') { U.list = 'review'; U.older = false; L.redraw(); }
      else if (a === 'publish') { const t = tally(); if (t.given.length) confirmPublish(t.pub ? 'update' : 'publish'); }
      else if (a === 'counts' || a === 'print') { S.ui.ci = a === 'counts' ? 'counts' : 'desk'; L.go('checkin'); }
      return;
    }
    const a = ds.act;
    if (a === 'assignall') assignAll();
    else if (a === 'reviewnext') { const t = tally(); U.list = 'review'; U.older = false; const f = t.review[0]; if (f) { U.sel = f.rid; U.followed = ''; } L.redraw(); }
    else if (a === 'publish') confirmPublish('publish');
    else if (a === 'update') confirmPublish('update');
    else if (a === 'unpublish') confirmPublish('unpublish');
    else if (a === 'export') roomingCsv();
    else if (a === 'assign') assignOne(L.byRid(ds.rid));
    else if (a === 'apart') { const h = L.byRid(ds.rid), p = L.plan([h], { apart: true })[h.rid]; if (p) setRooms(h, p); else L.toast('No rooms free'); }
    else if (a === 'unassign') { const h = L.byRid(ds.rid); setRooms(h, null); }
    else if (a === 'close') { const was = U.sel; U.sel = ''; L.redraw(); const b = was && root.querySelector('[data-sel="' + CSS.escape(was) + '"]'); if (b) b.focus({ preventScroll: true }); }
    else if (a === 'closeroom') { U.room = ''; L.redraw(); }
    else if (a === 'olderdone') { U.older = false; const st = Object.assign({}, L.data('meta:steps') || {}); st.older = true; L.save([{ key: 'meta:steps', data: st }], { label: 'Mark older · Done' }); }
  });
  // Typing: the search (redraws only the list), a hold's words and Lodging's note (saved on leaving the field).
  root.addEventListener('input', e => {
    if (S.view !== 'rooms') return;
    if (e.target.matches('[data-find]')) {
      U.find = e.target.value;
      const t = tally(), ul = root.querySelector('[data-given]');
      if (!ul) return;
      const tmp = document.createElement('div');
      tmp.innerHTML = queue(t);
      const nu = tmp.querySelector('[data-given]');
      ul.innerHTML = nu.innerHTML;
      root.querySelectorAll('.lod-chips [data-list]').forEach(b => b.setAttribute('aria-pressed', String(!U.find.trim() && b.dataset.list === U.list)));
    } else if (e.target.matches('[data-givefind]')) {
      U.giveFind = e.target.value;
      L.redraw();
    }
  });
  root.addEventListener('change', e => {
    if (S.view !== 'rooms') return;
    const x = e.target;
    if (x.matches('[data-hold]')) { const id = x.dataset.hold, f = Object.assign({}, L.data('room:' + id) || {}), v = x.value.trim(); if ((f.hold || '') === v) return; if (v) f.hold = v; else delete f.hold; L.save([{ key: 'room:' + id, data: Object.keys(f).length ? f : null }], { label: L.roomWords(id) + (v ? ' · Kept · ' + v : ' · Not kept') }); }
    else if (x.matches('[data-hnote]')) { const h = L.byRid(x.dataset.hnote), v = x.value.trim(); if ((L.hrow(h).note || '') === v) return; L.hhSave(h, { note: v || null }, { label: h.sur + ' · Note saved', quiet: true }); }
  });
  root.addEventListener('keydown', e => {
    if (S.view !== 'rooms') return;
    const g = e.target.closest && e.target.closest('.lod-plan [data-room][role="button"]');
    if (g) {
      if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); tapRoom(g.dataset.room); return; }
      if (/^Arrow/.test(e.key)) {
        e.preventDefault();
        const all = Array.from(root.querySelectorAll('.lod-plan [data-room][role="button"]')), a = g.getBoundingClientRect();
        const dir = { ArrowRight: [1, 0], ArrowLeft: [-1, 0], ArrowDown: [0, 1], ArrowUp: [0, -1] }[e.key];
        let best = null, bd = Infinity;
        all.forEach(o => { if (o === g) return; const b = o.getBoundingClientRect(), dx = (b.left + b.width / 2) - (a.left + a.width / 2), dy = (b.top + b.height / 2) - (a.top + a.height / 2); const along = dx * dir[0] + dy * dir[1]; if (along <= 2) return; const d = along + Math.abs(dx * dir[1] + dy * dir[0]) * 2; if (d < bd) { bd = d; best = o; } });
        if (best) { g.setAttribute('tabindex', '-1'); best.setAttribute('tabindex', '0'); best.focus(); U.focusRoom = best.dataset.room; }
      }
      return;
    }
    const card = e.target.closest && e.target.closest('.lod-q [data-sel]');
    if (card && (e.key === 'ArrowDown' || e.key === 'ArrowUp')) {
      e.preventDefault();
      const all = Array.from(root.querySelectorAll('.lod-q [data-sel]')), i = all.indexOf(card), n = all[i + (e.key === 'ArrowDown' ? 1 : -1)];
      if (n) n.focus();
    }
  });
  document.addEventListener('keydown', e => {
    if (S.view !== 'rooms' || !S.loaded) return;
    const typing = e.target.matches && e.target.matches('input, textarea');
    if (e.key === 'Escape' && dlg.open) return;
    if (e.key === 'Escape' && (U.sel || U.room || U.older)) { e.preventDefault(); const was = U.sel; U.sel = ''; U.room = ''; U.older = false; L.redraw(); const b = was && root.querySelector('[data-sel="' + CSS.escape(was) + '"]'); if (b) b.focus({ preventScroll: true }); return; }
    if (typing) return;
    if (e.key === '/') { const f = root.querySelector('[data-find]'); if (f) { e.preventDefault(); f.focus(); } }
    else if ((e.key === 'n' || e.key === 'N') && !e.metaKey && !e.ctrlKey) { const l = tally().review; if (l.length) { const i = l.findIndex(h => h.rid === U.sel), n = l[(i + 1) % l.length]; U.list = 'review'; U.sel = n.rid; U.followed = ''; L.redraw(); } }
  });

  // Dragging a household from the list onto a room (laptop).
  root.addEventListener('dragstart', e => { const li = e.target.closest && e.target.closest('[data-drag]'); if (!li || S.view !== 'rooms') return; e.dataTransfer.setData('text/x-lodging', li.dataset.drag); e.dataTransfer.effectAllowed = 'move'; U.drag = li.dataset.drag; root.classList.add('is-dragging'); });
  const clearDrop = () => root.querySelectorAll('.pl-room.is-drop').forEach(g => g.classList.remove('is-drop'));
  root.addEventListener('dragend', () => { root.classList.remove('is-dragging'); clearDrop(); U.drag = ''; });
  root.addEventListener('dragover', e => {
    const g = e.target.closest && e.target.closest('.lod-plan [data-room]');
    if (!g || !U.drag) return;
    e.preventDefault(); e.dataTransfer.dropEffect = 'move';
    clearDrop();
    const h = L.byRid(U.drag), run = h && (L.taken(h.rid)[g.dataset.room] ? [g.dataset.room] : runAt(h, g.dataset.room));
    (run || []).forEach(id => { const x = root.querySelector('.lod-plan [data-room="' + CSS.escape(id) + '"]'); if (x) x.classList.add('is-drop'); });
  });
  root.addEventListener('drop', e => {
    const g = e.target.closest && e.target.closest('.lod-plan [data-room]');
    if (!g || !U.drag) return;
    e.preventDefault(); root.classList.remove('is-dragging'); clearDrop();
    const rid = U.drag; U.drag = '';
    dropOn(rid, g.dataset.room);
  });
  // Dragging a taken room onto another room: that household moves there (or the two swap).
  let pdrag = null;
  root.addEventListener('pointerdown', e => {
    const g = e.target.closest && e.target.closest('.lod-plan .pl-room.is-taken, .lod-plan .pl-room.is-sel, .lod-plan .pl-room.is-other');
    if (!g || L.ro || narrow() || e.button !== 0 || e.pointerType === 'touch') return;
    const owner = L.taken()[g.dataset.room];
    if (!owner || owner === 'yf') return;
    pdrag = { rid: owner, from: g.dataset.room, x: e.clientX, y: e.clientY, on: false };
  });
  window.addEventListener('pointermove', e => {
    if (!pdrag) return;
    if (!pdrag.on && Math.hypot(e.clientX - pdrag.x, e.clientY - pdrag.y) < 8) return;
    pdrag.on = true;
    root.classList.add('is-dragging');
    clearDrop();
    const el = document.elementFromPoint(e.clientX, e.clientY), g = el && el.closest && el.closest('.lod-plan [data-room]');
    if (g) g.classList.add('is-drop');
  });
  window.addEventListener('pointerup', e => {
    if (!pdrag) return;
    const d = pdrag; pdrag = null;
    if (!d.on) return;
    root.classList.remove('is-dragging'); clearDrop();
    const el = document.elementFromPoint(e.clientX, e.clientY), g = el && el.closest && el.closest('.lod-plan [data-room]');
    if (!g || g.dataset.room === d.from) return;
    // The click that follows a drag isn't a tap.
    const stop = ev => { ev.stopPropagation(); ev.preventDefault(); window.removeEventListener('click', stop, true); };
    window.addEventListener('click', stop, true);
    setTimeout(() => window.removeEventListener('click', stop, true), 50);
    const h = L.byRid(d.rid), owner = L.taken(d.rid)[g.dataset.room];
    if (owner && owner !== 'yf') { dropOn(d.rid, g.dataset.room); return; }
    // Its rooms move together, starting at the room it was dropped on.
    const run = runAt(Object.assign({}, h, { asked: Math.max(1, L.given(h).length) }), g.dataset.room);
    if (run) setRooms(h, run, h.sur + ' · moved to ' + L.roomsWords(run));
  });

  let wasNarrow = narrow(), rsT = 0;
  window.addEventListener('resize', () => {
    clearTimeout(rsT);
    rsT = setTimeout(() => { const n = narrow(); if (S.view !== 'rooms') return; if (n !== wasNarrow) { wasNarrow = n; L.redraw(); } else sizePlan(); }, 120);
  });
})();
