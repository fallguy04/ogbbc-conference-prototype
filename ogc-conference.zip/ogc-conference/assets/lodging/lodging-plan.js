/*
 * lodging-plan.js — how Lodging's board suggests rooms and what it asks Lodging to look at (no drawing).
 *
 * The planner (Oct 8, Michael: Lodging places "some of the older folks where they want"; Oct 10 audit):
 *   - Older, step-free and ground-floor requests go first, onto ground floors (or rooms marked
 *     accessible), nearest the dining hall; everyone else fills the upper floors first, so ground
 *     floors stay for those who ask;
 *   - a household asking to be near another shares its floor (and its wall where it can); a group name
 *     shared by several households keeps them on one floor;
 *   - a family's rooms side by side (a two-room family gets a suite's two rooms);
 *   - a one-room household in IWU's suites shares a bath with its near-request first, then a household
 *     its own size; a single person isn't put beside a family;
 *   - near the restroom asked for, where the plan has restrooms;
 *   - rooms kept (Hold) or out of service are never suggested.
 * Assign all never moves anyone already placed. Everything here is a suggestion: Lodging changes any of it.
 */
(function () {
  'use strict';
  const L = window.OGC.lodging, O = window.OGC, SU = L.SU, S = L.S;

  /* ================================================================ the halls */

  const familyFloors = () => S.floors.filter(f => f.for === 'families');
  L.familyFloors = familyFloors;
  L.yfFloors = hall => S.floors.filter(f => /^young/.test(f.for) && (!hall || f.for.indexOf(hall) > -1));
  const usable = id => { const f = L.fact(id); return !f.hold && !f.out; };
  L.usable = usable;
  // Step-free: the ground floor, or a room Lodging marked accessible.
  L.stepFree = r => r && (r.floor === 1 || !!L.fact(r.id).access);

  // Which room shares each room's bath, and which restrooms each room is near (from the hall's plan).
  let near = null;
  function nearOf() {
    if (near) return near;
    near = { mate: {}, w: {}, m: {} };
    Object.keys(S.plans || {}).forEach(hall => (S.plans[hall].list || []).forEach(f => f.rooms.forEach(sh => {
      const words = O.map.near(f, sh), id = hall + '|' + sh.label;
      words.forEach(w => {
        const m = /^Shared bath with (\S+)/.exec(w);
        if (m) near.mate[id] = hall + '|' + m[1];
        if (/women’s restroom/.test(w)) near.w[id] = true;
        else if (/men’s restroom/.test(w)) near.m[id] = true;
      });
    })));
    return near;
  }
  L.bathMate = id => nearOf().mate[id] || '';
  L.nearRestroom = (id, which) => !!nearOf()[which][id];
  L.hallHasRestrooms = hall => { const n = nearOf(); return Object.keys(n.w).concat(Object.keys(n.m)).some(id => id.indexOf(hall + '|') === 0); };

  // Minutes from a hall to the dining hall (the campus map), for those placed first.
  const ranks = {};
  L.hallRank = hall => {
    if (hall in ranks) return ranks[hall];
    const c = S.campus, din = c && c.items.find(i => i.kind === 'dining');
    const m = din && O.map ? O.map.walkMin(c, hall, din.name) : null;
    return (ranks[hall] = m == null ? 99 : m);
  };

  /* ================================================================ who asked to be near whom */

  const plain = t => String(t || '').toLowerCase().replace(/[’']s\b/g, '').replace(/^the\s+/, '').replace(/\s+(family|families|household|folks)$/, '').replace(/[^a-z0-9 ]+/g, ' ').replace(/\s+/g, ' ').trim();
  // The households a household's "near" words could mean: Lodging's own link first; else every
  // household whose surname, name or contact the words name; else the others who wrote the same words
  // (2025's "group name").
  L.nearCands = h => {
    const link = L.hrow(h).near;
    if (link && L.byRid(link)) return [L.byRid(link)];
    const w = plain(h.nearText);
    if (!w) return [];
    const others = L.dorm().filter(x => x !== h);
    // "the Florys", "Dale Flory", "Dale and Ann Flory", "Flory family".
    const words = w.split(' ').filter(x => ['and', 'near', 'the', 'by', 'with', 'to', 'our', 'my', 'family', 'families', 'folks', 'friends', 'please', 'room', 'rooms'].indexOf(x) < 0);
    const is = (word, sur) => word === sur || word === sur + 's' || word === sur + 'es';
    const byName = others.filter(x => {
      const sur = plain(x.sur);
      if (plain(x.d.household && x.d.household.contact) === w) return true;
      const at = words.findIndex(word => is(word, sur));
      if (at < 0 || words.length > 4) return false;
      const firsts = words.filter((word, i) => i !== at);
      return !firsts.length || firsts.some(f => x.adults.some(p => plain(L.first(p.name)) === f));
    });
    if (byName.length) return byName;
    return others.filter(x => plain(x.nearText) === w);
  };
  // The one household it's near, or null (none, or more than one until Lodging chooses).
  L.nearOf = h => { const c = L.nearCands(h); return c.length === 1 ? c[0] : null; };
  L.isGroup = h => { const w = plain(h.nearText); return !!w && !L.hrow(h).near && L.dorm().some(x => x !== h && plain(x.nearText) === w) && !L.dorm().some(x => x !== h && plain(x.sur) === w); };

  /* ================================================================ the planner */

  const size = h => h.sleepers.length <= 1 ? 1 : h.sleepers.length === 2 ? 2 : 3;
  // Rooms for every household in the list, planned together so no two get the same room. Returns
  // { rid: [roomIds] }; changes nothing.
  L.plan = function (list, o) {
    o = o || {};
    const t = Object.assign({}, L.taken()), plan = {}, who = {};
    Object.keys(t).forEach(id => { who[id] = t[id]; });
    const floors = familyFloors();
    const first = h => L.firstGroup(h);
    const grp = h => plain(h.nearText);
    const order = list.slice().sort((a, b) => (first(b) - first(a)) || (b.asked - a.asked) || (String(a.at) < String(b.at) ? -1 : 1));
    const placedFloor = rid => { const ids = plan[rid] || L.given(rid); const r = ids && ids.length && L.room(ids[0]); return r ? r.hall + '|' + r.floor : ''; };
    order.forEach(h => {
      const need = Math.max(1, h.asked || 1), ground = first(h);
      const partner = L.nearOf(h), pf = partner ? placedFloor(partner.rid) : '';
      // A group's first placed member decides its floor.
      let gf = '';
      if (!pf && grp(h)) { const m = L.dorm().find(x => x !== h && grp(x) === grp(h) && placedFloor(x.rid)); if (m) gf = placedFloor(m.rid); }
      let best = null;
      floors.forEach(f => {
        const fk = f.hall + '|' + f.floor, rank = L.hallRank(f.hall);
        for (let i = 0; i + need <= f.rooms.length; i++) {
          const run = f.rooms.slice(i, i + need);
          if (!run.every((r, k) => !t[r.id] && usable(r.id) && (k === 0 || !r.gap))) continue;
          let sc = 0;
          const sf = run.every(L.stepFree);
          if (ground) sc += sf ? 1000 - rank * 6 : -800;
          else sc += f.floor === 1 ? -300 : 0;
          if (pf === fk || gf === fk) sc += 400;
          // Beside its partner: a room next to one of theirs.
          if (partner) { const pr = plan[partner.rid] || L.given(partner); const idx = run.map(r => f.rooms.indexOf(r)); if (pr && pr.some(id => { const j = f.rooms.indexOf(L.room(id)); return j > -1 && idx.some(x => Math.abs(x - j) === 1); })) sc += 150; }
          // A whole suite for a family of two rooms.
          if (need === 2 && L.bathMate(run[0].id) === run[1].id) sc += 60;
          if (need === 1) {
            const mate = L.bathMate(run[0].id), mw = mate && who[mate];
            if (mate && !t[mate]) sc += 12;   // its bath to itself for now
            else if (mw && partner && mw === partner.rid) sc += 250;
            else if (mw && mw !== 'yf' && L.byRid(mw)) { const s1 = size(h), s2 = size(L.byRid(mw)); sc += s1 === s2 ? 25 : (s1 === 1 && s2 === 3) || (s1 === 3 && s2 === 1) ? -120 : 0; }
          }
          if (h.nearW && run.some(r => L.nearRestroom(r.id, 'w'))) sc += 40;
          if (h.nearM && run.some(r => L.nearRestroom(r.id, 'm'))) sc += 40;
          sc -= i * 0.01;   // otherwise in room order
          if (!best || sc > best.sc) best = { sc, ids: run.map(r => r.id) };
        }
      });
      // No rooms free together: the free rooms nearest each other on one floor ("Assign apart").
      if (!best && o.apart) {
        floors.forEach(f => { const free = f.rooms.filter(r => !t[r.id] && usable(r.id)); if (!best && free.length >= need) best = { sc: 0, ids: free.slice(0, need).map(r => r.id), apart: true }; });
      }
      if (best) { plan[h.rid] = best.ids; best.ids.forEach(id => { t[id] = h.rid; who[id] = h.rid; }); }
    });
    return plan;
  };
  // Why a household couldn't be placed, in words: "No 3 rooms together · 2 free on Reed 2nd floor".
  L.whyNot = h => {
    const t = L.taken(), need = Math.max(1, h.asked);
    const fl = familyFloors().map(f => ({ f, n: f.rooms.filter(r => !t[r.id] && usable(r.id)).length })).sort((a, b) => b.n - a.n)[0];
    const sfFree = familyFloors().reduce((k, f) => k + f.rooms.filter(r => !t[r.id] && usable(r.id) && L.stepFree(r)).length, 0);
    if (L.firstGroup(h) && sfFree < need) return 'No ground floor rooms free';
    return 'No ' + (need > 1 ? need + ' rooms together' : 'room free') + (fl && fl.n ? ' · ' + fl.n + ' free on ' + L.hallShort(fl.f.hall) + ' ' + L.floorName(fl.f.floor).toLowerCase() : '');
  };

  /* ================================================================ what needs a look */

  const nightIn = (p, h) => (p.nights && p.nights.length ? p.nights : h.nights);
  // Requests the rooms don't meet, and other things Lodging would want to know. Each: { k, text, title }.
  L.issues = function (h) {
    const ids = L.given(h), rs = ids.map(L.room).filter(Boolean), out = [];
    if (!rs.length || !h.active) return out;
    if ((h.ground || h.walker) && rs.some(r => !L.stepFree(r))) out.push({ k: 'ground', text: h.walker ? 'Step-free · upper floor' : 'Not ground floor' });
    else if (L.older(h) && rs.some(r => !L.stepFree(r))) out.push({ k: 'older', text: 'Older · upper floor' });
    if (rs.length < h.asked) out.push({ k: 'short', text: 'Short ' + L.plural(h.asked - rs.length, 'room'), title: L.plural(h.asked, 'room') + ' asked · ' + rs.length + ' given' });
    // A room added because they didn't fit isn't "extra" (polish: the two checks undid each other).
    const capOf = list => list.reduce((k, r) => k + L.beds(r.id) + 1, 0);
    if (rs.length > h.asked && h.sleepers.length <= capOf(rs.slice(0, Math.max(1, h.asked)))) out.push({ k: 'extra', text: 'Extra room', title: L.plural(h.asked, 'room') + ' asked · ' + rs.length + ' given' });
    if (rs.length > 1) {
      const f = S.floors.find(x => x.rooms.indexOf(rs[0]) > -1), idx = rs.map(r => f ? f.rooms.indexOf(r) : -1).sort((a, b) => a - b);
      if (!f || idx.some(i => i < 0) || idx.some((v, k) => k && (v !== idx[k - 1] + 1 || f.rooms[v].gap))) out.push({ k: 'apart', text: 'Rooms apart' });
    }
    const c = L.nearCands(h);
    if (h.nearText && !L.hrow(h).near && c.length > 1 && !L.isGroup(h)) {
      const surs = Array.from(new Set(c.map(x => x.sur)));
      out.push({ k: 'nearpick', text: 'Near · which ' + (surs.length === 1 ? surs[0] + (/s$/.test(surs[0]) ? 'es' : 's') : 'household') + '?', title: '“' + h.nearText + '” fits ' + c.length + ' households' });
    }
    else {
      const n = L.nearOf(h), nr = n && L.given(n).map(L.room).filter(Boolean)[0];
      if (nr && !rs.some(r => r.hall === nr.hall && r.floor === nr.floor)) out.push({ k: 'near', text: 'Not near ' + n.sur });
    }
    // A group (the same "group name") split over floors.
    // Said on the households away from where most of the group is (all of them when it's even).
    if (L.isGroup(h)) {
      const w = plain(h.nearText), n = {};
      L.dorm().filter(x => plain(x.nearText) === w).forEach(x => { const r = L.room(L.given(x)[0]); if (r) n[r.hall + '|' + r.floor] = (n[r.hall + '|' + r.floor] || 0) + 1; });
      const keys = Object.keys(n), top = Math.max.apply(null, keys.map(k => n[k])), mine = rs[0].hall + '|' + rs[0].floor;
      if (keys.length > 1 && (n[mine] < top || keys.filter(k => n[k] === top).length > 1)) out.push({ k: 'group', text: 'Group split · ' + keys.length + ' floors', title: h.nearText });
    }
    // (Children in a room of their own are a quiet line in the household's details, never Review:
    // L.quiet. Polish: it filled the Review list, fired for a suite's second room, and for splits the
    // importer made itself. lodging-assumptions B18.)
    // Fire code: beds + 1 a room; babies don't count.
    const total = h.sleepers.length, cap = capOf(rs);
    if (total > cap) out.push({ k: 'over', text: 'Over capacity', title: total + ' sleeping · room for ' + cap + ' (beds + 1 a room)' });
    if ((h.nearW || h.nearM) && L.hallHasRestrooms(rs[0].hall) && !rs.some(r => L.nearRestroom(r.id, h.nearW ? 'w' : 'm'))) out.push({ k: 'restroom', text: 'Far from restroom' });
    // A single person beside a family in a suite (or the other way round), unless they asked.
    if (rs.length === 1) {
      const mate = L.bathMate(rs[0].id), mw = mate && L.taken(h.rid)[mate], other = mw && L.byRid(mw);
      if (other && size(h) !== size(other) && (size(h) === 1 || size(other) === 1) && Math.abs(size(h) - size(other)) > 1 && L.nearOf(h) !== other && L.nearOf(other) !== h) out.push({ k: 'bath', text: 'Shared bath', title: 'Shares a bath with ' + other.label });
    }
    rs.forEach(r => { const f = L.fact(r.id); if (f.out) out.push({ k: 'outroom', text: L.roomWords(r.id) + ' out of service' }); else if (f.hold) out.push({ k: 'kept', text: L.roomWords(r.id) + ' kept · ' + f.hold }); });
    // Keys: each room's key holder is there its first night.
    const keys = L.keysOf(h), first = h.nights[0];
    keys.forEach((name, i) => {
      const p = h.people.find(x => x.name === name);
      if (p && first && p.nights && p.nights.length && p.nights.indexOf(first) < 0) out.push({ k: 'keys', text: 'Keys: ' + L.first(name) + ' arrives ' + SU.nightShort(p.nights[0]), room: i });
    });
    const offered = SU.nightsOf(S.cfg);
    if (h.nights.some(n => offered.indexOf(n) < 0)) out.push({ k: 'night', text: 'Night not offered', title: h.nights.filter(n => offered.indexOf(n) < 0).join(', ') });
    // No "on 2 registrations": households are never compared by people's names (docs/26 decision 6).
    // What didn't read on the Google Form, carried onto the household (polish: it vanished after the import).
    (h.formProblems || []).forEach((t, i) => out.push({ k: 'form' + i, text: 'From the Form', title: t }));
    return out;
  };
  // Things worth knowing that aren't a problem to fix: a room with only children in it, unless it's
  // a suite's second room or next door to a grown-up's, or the importer made the split.
  L.quiet = function (h) {
    const ids = L.given(h), out = [];
    if (ids.length < 2 || h.source === 'form') return out;
    ids.forEach((id, i) => {
      const here = L.inRoom(h, i);
      if (!here.length || here.some(p => h.kind(p) === 'adult' || (h.kind(p) === 'yf' && !p.minor))) return;
      const r = L.room(id), f = S.floors.find(x => x.rooms.indexOf(r) > -1);
      const beside = ids.some((o, j) => j !== i && (L.bathMate(id) === o || (f && Math.abs(f.rooms.indexOf(L.room(o)) - f.rooms.indexOf(r)) === 1)));
      if (!beside) out.push('Children on their own in ' + L.roomWords(id) + ' · ' + here.map(p => L.first(p.name)).join(', '));
    });
    return out;
  };
  const sig = list => list.map(x => x.k + ':' + x.text).join('|');
  // Who sleeps in a household's room i (the form's own split; one room: everyone not in a hall).
  L.inRoom = (h, i) => { const n = Math.max(1, L.given(h).length || h.asked); return h.inRooms.filter(p => (p.room == null ? 0 : Math.min(+p.room, n - 1)) === i); };
  // The floor most of a group (the same "group name") is on: "Reed Hall|3".
  L.groupFloor = h => {
    const w = plain(h.nearText), n = {}, own = L.room(L.given(h)[0]);
    L.dorm().filter(x => x !== h && plain(x.nearText) === w).forEach(x => { const r = L.room(L.given(x)[0]); if (r) n[r.hall + '|' + r.floor] = (n[r.hall + '|' + r.floor] || 0) + 1; });
    const best = Object.keys(n).sort((a, b) => n[b] - n[a])[0] || '';
      return own && best === own.hall + '|' + own.floor ? '' : best;
  };
  L.sig = sig;
  // Issues Lodging hasn't said Looks right to (a new issue brings it back).
  L.toReview = h => { const is = L.issues(h); if (!is.length) return []; const ok = L.hrow(h).ok; return ok && ok.sig === sig(is) ? [] : is; };

  // The person also on another registration (likeliest a Youngfolk entered twice).
  let dupIndex = null, dupFor = null;
  L.dupOf = h => {
    if (dupFor !== S.hh) {
      dupFor = S.hh; dupIndex = {};
      S.hh.filter(x => !x.gone).forEach(x => x.people.forEach(p => { const k = p.name.toLowerCase().replace(/\s+/g, ' '); (dupIndex[k] = dupIndex[k] || []).push({ x, p }); }));
    }
    // The same name twice is only the same person when it's a Youngfolk on one of them (entered by the
    // parents and on their own), or the two registrations share an email or a phone: names repeat.
    const same = (a, b) => (a.email && a.email === b.email) || (a.phone && a.phone.replace(/\D/g, '') === b.phone.replace(/\D/g, ''));
    for (const p of h.people) {
      const l = dupIndex[p.name.toLowerCase().replace(/\s+/g, ' ')] || [];
      const o = l.find(y => y.x !== h && (p.yf || y.p.yf || same(h, y.x)));
      if (o) return { p, h: o.x };
    }
    return null;
  };

  // Who gets each room's keys: Lodging's choice, else the household's.
  L.keysOf = h => { const own = (h.d.stay && h.d.stay.keys) || [], over = L.hrow(h).keys || {}; return Array.from({ length: Math.max(1, L.given(h).length || h.asked) }, (_, i) => over[i] || own[i] || own[0] || (h.d.household && h.d.household.contact) || ''); };

  /* ================================================================ what changed since rooms were given */

  L.changes = function (h) {
    const r = L.hrow(h), s = r.snap;
    if (!s || !(r.rooms || []).length) return [];
    const out = [], TY = { dorm: 'Dorm', camper: 'Camper lot', elsewhere: 'Elsewhere', yf: 'Youngfolks halls' };
    if (h.gone && s.status !== 'cancelled') out.push({ k: 'cancel', text: 'Cancelled', free: true });
    else if (h.type !== s.type) out.push({ k: 'type', text: 'Moved to the ' + (TY[h.type] || h.type).toLowerCase().replace('elsewhere', 'elsewhere'), free: true });
    if (!h.gone && h.type === 'dorm') {
      if ((s.nights || []).join('|') !== h.nights.join('|')) out.push({ k: 'nights', text: 'Nights ' + (L.nightSpan(s.nights) || 'none') + ' → ' + (L.nightSpan(h.nights) || 'none') });
      if (s.rooms !== h.asked) out.push({ k: 'rooms', text: 'Rooms ' + s.rooms + ' → ' + h.asked });
      if (s.n !== h.people.length) out.push({ k: 'people', text: 'People ' + s.n + ' → ' + h.people.length });
      if (!s.ground && (h.ground || !!(h.d.stay && h.d.stay.walker))) out.push({ k: 'ground', text: 'Ground floor asked' });
    }
    return out;
  };
  // Households that changed since their rooms were given (and those gone, still holding rooms).
  L.changed = () => S.hh.filter(h => L.changes(h).length);

  // Since the rooms were published: who would see something different.
  L.pubSnap = () => { const p = L.data('meta:published'); return p && p.date && p.snap ? p.snap : null; };
  L.pubChanged = () => {
    const snap = L.pubSnap();
    if (!snap) return [];
    const now = L.assign(), out = [];
    Object.keys(Object.assign({}, snap, now)).forEach(rid => { if ((snap[rid] || []).join('|') !== (now[rid] || []).join('|')) out.push(rid); });
    return out;
  };
})();
