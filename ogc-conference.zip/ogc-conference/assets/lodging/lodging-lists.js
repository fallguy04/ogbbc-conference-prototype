/*
 * lodging-lists.js — Lodging's other tabs (Oct 10, polished after the critic's round):
 *
 *   Young Folks   each Young Folks hall: pairs as one line, only the exceptions said (one-way asks, a
 *                 name nobody registered under, ages mixed where the campus has that rule, a minor's
 *                 approval), then who has no roommate. Suggest pairs (same hall, same nights, close ages)
 *                 turns the unpaired into a list to look over; Pair, tap two, for the rest. Assign rooms
 *                 puts each pair in a room of its hall; the hall's list prints for its lobby.
 *   Campers       the camper lot: who's arriving together, campers a night, phones quietly; prints for
 *                 the camper host.
 *   Check-in      Desk: search anyone (a Young Folk says their hall), arrivals by day; from the first
 *                 arrival Check in (keys to whom, how many), and from a household's last morning Keys
 *                 back, until names are cleared. Room setup: rooms and counts only, in walking order.
 *                 Counts: rooms per night by hall, Young Folks, campers, linens, mattresses and keys,
 *                 the final count for the campus. Everything prints (dated, "Lodging only") and downloads.
 *   (held)        a year whose names are cleared: the year in counts, to print and keep.
 */
(function () {
  'use strict';
  const L = window.OGC.lodging, O = window.OGC, SU = L.SU, S = L.S, I = L.I, esc = L.esc, root = L.root;
  const U = S.ui, plural = L.plural;
  U.ci = U.ci || 'desk';

  // The venue's time, with its zone said once ("2:44 PM EDT"): Lodging may work from another state.
  const tz = () => (S.model && S.model.tz) || 'America/Indiana/Indianapolis';
  const zone = () => { try { return (new Intl.DateTimeFormat('en-US', { timeZone: tz(), timeZoneName: 'short' }).formatToParts(new Date()).find(p => p.type === 'timeZoneName') || {}).value || ''; } catch (e) { return ''; } };
  const printHead = (what, n) => '<p class="lod-printhead">' + esc(L.conf() + ' · ' + what + ' · Printed ' + O.fmtDate(L.stamp(), 'md') + ', ' + L.time(new Date().toISOString()) + ' ' + zone() + (n ? ' · ' + n : '')) + '</p>';
  const tools = list => '<p class="lod-btns"><button type="button" class="wk-btn wk-btn--line wk-btn--small" data-print="' + list + '">' + I.print + 'Print</button><button type="button" class="wk-btn wk-btn--line wk-btn--small" data-csv="' + list + '">' + I.down + 'Download</button></p>';
  const nameLine = h => '<b>' + esc(h.sur) + '</b>' + (h.firsts ? ' · ' + esc(h.firsts) : '');
  const listName = h => h.sur + (h.firsts ? ', ' + h.firsts : '');
  const today = () => S.phase.today;

  /* ================================================================ Young Folks */

  const yfHalls = () => {
    const out = [];
    S.floors.filter(f => /^young/.test(f.for)).forEach(f => {
      const key = /women/.test(f.for) ? 'women' : 'men';
      let g = out.find(x => x.hall === f.hall);
      if (!g) out.push(g = { hall: f.hall, key, floors: [] });
      g.floors.push(f);
    });
    return out;
  };
  L.yfHallOf = key => (yfHalls().find(g => g.key === key) || {}).hall || '';
  // Every Young Folk staying in a hall.
  function everyYf() {
    const out = [];
    S.hh.filter(h => !h.gone).forEach(h => h.yfs.forEach(p => out.push({ p, h, pid: p.pid || (h.rid + ':' + p.name), key: p.yfHall || '' })));
    return out;
  }
  L.everyYf = everyYf;
  // Names only: never a phone number or an email someone typed into the box (2025's form had them).
  const words = t => String(t || '').toLowerCase().replace(/\S+@\S+/g, '').replace(/\+?\d[\d\s().-]{5,}\d/g, '').split(/\s*(?:,|;|&|\/|\band\b)\s*/).map(x => x.replace(/\(.*?\)/g, '').replace(/[^a-z .'’-]/g, '').trim()).filter(Boolean);
  // A name as written: the whole name, "Joy H.", or a first name that only one person has.
  function findMate(t, i, all) {
    const tw = t.split(/\s+/), last = (tw[tw.length - 1] || '').replace(/\./g, '');
    const same = all.filter(x => x !== i && x.key === i.key);
    const n = x => x.p.name.toLowerCase();
    let hit = same.find(x => n(x) === t);
    if (!hit && tw.length > 1 && last.length === 1) hit = same.find(x => n(x).split(' ')[0] === tw[0] && n(x).split(' ').pop().charAt(0) === last);
    if (!hit && tw.length === 1) { const f = same.filter(x => n(x).split(' ')[0] === tw[0]); if (f.length === 1) hit = f[0]; }
    return hit || null;
  }
  // Pairs: Lodging's own first, then both asked, then one asked; the rest unpaired.
  function pairsOf(all) {
    const byPid = {}, used = new Set(), pairs = [];
    all.forEach(i => { byPid[i.pid] = i; i.asks = words(i.p.rooming).map(t => ({ t, m: findMate(t, i, all) })); i.row = L.data('yf:' + i.pid) || {}; });
    const add = (a, b, how) => { used.add(a); used.add(b); pairs.push({ a, b, how }); };
    all.forEach(i => { const m = i.row.mate && byPid[i.row.mate]; if (m && !used.has(i) && !used.has(m)) add(i, m, 'lodging'); });
    // Unpaired by Lodging (mate "none"): their asks no longer pair them.
    const free = i => !used.has(i) && i.row.mate !== 'none';
    all.forEach(i => { if (!free(i)) return; const m = i.asks.map(x => x.m).find(m => m && free(m) && m.asks.some(y => y.m === i)); if (m) add(i, m, 'both'); });
    all.forEach(i => { if (!free(i)) return; const m = i.asks.map(x => x.m).find(m => m && free(m)); if (m) add(i, m, 'one'); });
    return { pairs, single: all.filter(i => !used.has(i)) };
  }
  const minorAlone = i => i.p.minor && !i.h.adults.length;
  function approval(i) {
    if (!minorAlone(i)) return '';
    const a = i.h.d.approval;
    if (a && a.state === 'approved') return { t: 'Approved ' + L.md(a.at), ok: true };
    if (a && a.state === 'waiting') return { t: 'Approval pending · sent ' + L.md(a.sent_at) };
    if (a && a.state === 'declined') return { t: 'Declined', warn: true };
    return { t: i.h.d.stay && i.h.d.stay.parentEmail ? 'Approval pending' : 'No parent email', warn: !(i.h.d.stay && i.h.d.stay.parentEmail) };
  }
  const yfNights = i => i.p.nights && i.p.nights.length ? i.p.nights : i.h.nights.length ? i.h.nights : SU.mainNights(S.cfg);
  const ageOf = i => +i.p.age || (i.p.minor ? 17 : 19);
  const mixed = list => S.cfg.yf_age_split === 'yes' && list.length > 1 && list.some(i => i.p.minor) && list.some(i => !i.p.minor);
  function yfFlags(list) {
    const out = [];
    list.forEach(i => {
      const ns = L.someNights(yfNights(i));
      if (ns) out.push(list.length > 1 ? L.first(i.p.name) + ' ' + ns : ns);
      const ap = approval(i);
      if (ap) out.push((list.length > 1 ? L.first(i.p.name) + ' · ' : '') + ap.t);
    });
    if (mixed(list)) out.unshift('<warn>Ages mixed');
    return out;
  }
  const flagHtml = f => f.map(x => /^<warn>/.test(x) ? '<i class="is-warn" title="' + esc((S.cfg.yf_age_rule || 'Ohio') + ': all 17 and under, or all 18 and over, in a room') + '">' + esc(x.slice(6)) + '</i>' : '<i>' + esc(x) + '</i>').join('');
  // Pairs to suggest among the unpaired of a hall: the same nights first, then the closest ages, never
  // mixing ages where the campus has that rule.
  function suggestPairs(single) {
    const skip = U.yfSkip || [], out = [], left = single.filter(i => !i.row.room && skip.indexOf(i.pid) < 0);
    const score = (a, b) => (yfNights(a).join('|') === yfNights(b).join('|') ? 0 : 10) + Math.abs(ageOf(a) - ageOf(b)) + (mixed([a, b]) ? 100 : 0);
    while (left.length > 1) {
      let best = null;
      for (let x = 0; x < left.length; x++) for (let y = x + 1; y < left.length; y++) { const s = score(left[x], left[y]); if (!best || s < best.s) best = { s, x, y }; }
      if (best.s >= 100) break;
      const a = left[best.x], b = left[best.y];
      out.push([a, b]);
      left.splice(best.y, 1); left.splice(best.x, 1);
    }
    return out;
  }

  function yfHtml() {
    const halls = yfHalls(), all = everyYf();
    if (!all.length) return L.card('No Young Folks yet', '');
    const st = pairsOf(all);
    const assignN = st.pairs.filter(x => !x.a.row.room && !x.b.row.room).length;
    const sugg = {};
    halls.forEach(g => { sugg[g.key] = suggestPairs(st.single.filter(i => i.key === g.key)); });
    const suggN = Object.keys(sugg).reduce((k, x) => k + sugg[x].length, 0);
    const unset = all.filter(i => !i.key);
    // One filled button: Suggest pairs while the unpaired can be paired, then Assign rooms.
    let btn = '';
    if (!L.ro && U.yfSuggest) btn = '<button type="button" class="wk-btn lod-primary" data-yfpairall>Pair these · ' + suggN + '</button><button type="button" class="wk-linklike" data-yfsuggest="off">Cancel</button>';
    else if (!L.ro && suggN) btn = '<button type="button" class="wk-btn lod-primary" data-yfsuggest="on" title="Same hall, same nights, closest ages; you look them over before anything is saved">Suggest pairs · ' + suggN + '</button>' + (assignN && halls.length ? '<button type="button" class="wk-btn wk-btn--line lod-primary" data-yfassign title="Each pair in a room of its hall, in room order. Nobody already in a room is moved.">Assign rooms · ' + assignN + '</button>' : '');
    else if (!L.ro && assignN && halls.length) btn = '<button type="button" class="wk-btn lod-primary" data-yfassign title="Each pair in a room of its hall, in room order. Nobody already in a room is moved.">Assign rooms · ' + assignN + '</button>';
    const top = '<div class="lod-top"><div class="lod-top__s"><p class="lod-status"><b>' + all.length + '</b> Young Folks · ' + plural(st.pairs.length, 'pair') + (st.single.length ? ' · ' + st.single.length + ' unpaired' : '') + '</p><p class="lod-help">Check-in · each hall’s lobby · their own key</p></div>' +
      btn + tools('yf') + '</div>';
    const sections = halls.map(g => {
      const mine = all.filter(i => i.key === g.key), pairs = st.pairs.filter(x => x.a.key === g.key), single = st.single.filter(i => i.key === g.key);
      const rooms = g.floors.reduce((k, f) => k + f.rooms.length, 0), used = new Set(mine.map(i => i.row.room).filter(Boolean)).size;
      const per = SU.mainNights(S.cfg).map(n => n.slice(0, 3) + ' ' + mine.filter(i => yfNights(i).indexOf(n) > -1).length).join(' · ');
      const sg = U.yfSuggest ? sugg[g.key] : [];
      const inSug = new Set([].concat.apply([], sg));
      return '<section class="lod-yfhall">' + printHead(g.hall + ' · ' + (g.key === 'women' ? 'young women' : 'young men'), plural(mine.length, 'staying', 'staying')) +
        '<h2 class="lod-h">' + esc(g.hall) + ' <small>' + esc((g.key === 'women' ? 'Young women' : 'Young men') + ' · ' + mine.length + ' staying · ' + (used ? used + ' of ' + rooms + ' rooms' : rooms + ' rooms')) + ' ' + L.info('Staying each night · ' + per, 'yfper-' + g.key) + '</small></h2>' +
        (sg.length ? '<h3 class="lod-sub">Suggested · ' + sg.length + '</h3><ul class="lod-pairs lod-pairs--sug">' + sg.map(x => '<li class="lod-pair"><span class="lod-pair__n"><b>' + esc(x[0].p.name) + '</b> and <b>' + esc(x[1].p.name) + '</b><span class="lod-hh__f">' + flagHtml(yfFlags(x).concat([ageOf(x[0]) === ageOf(x[1]) ? 'Both ' + ageOf(x[0]) : ageOf(x[0]) + ' and ' + ageOf(x[1])])) + '</span></span><span class="lod-pair__r"><button type="button" class="wk-linklike" data-yfskip="' + esc(x[0].pid) + '">Skip</button></span></li>').join('') + '</ul>' : '') +
        (pairs.length ? '<ul class="lod-pairs">' + pairs.map(x => pairRow(x, g)).join('') + '</ul>' : '') +
        (single.length ? '<h3 class="lod-sub">Unpaired · ' + single.length + '</h3><ul class="lod-pairs lod-pairs--single">' + single.filter(i => !inSug.has(i)).map(i => singleRow(i)).join('') + '</ul>' : '') + '</section>';
    }).join('');
    const noHall = unset.length ? '<section class="lod-yfhall"><h2 class="lod-h">Hall not set <small>' + unset.length + '</small></h2><p class="lod-help">The hall is the household’s answer: change it on their registration</p><ul class="lod-pairs lod-pairs--single">' + unset.map(i => '<li><span><b>' + esc(i.p.name) + '</b><small>' + esc(i.h.label) + '</small></span></li>').join('') + '</ul></section>' : '';
    return top + '<div class="lod-cols">' + sections + '</div>' + noHall;
  }
  function pairRow(x, g) {
    const room = x.a.row.room || x.b.row.room, flags = yfFlags([x.a, x.b]);
    if (x.how === 'one') flags.unshift('Only ' + L.first(x.a.p.name) + ' asked');
    const pick = U.yfMove === x.a.pid;
    return '<li class="lod-pair"><span class="lod-pair__n"><b>' + esc(x.a.p.name) + '</b> and <b>' + esc(x.b.p.name) + '</b>' + (flags.length ? '<span class="lod-hh__f">' + flagHtml(flags) + '</span>' : '') + '</span>' +
      '<span class="lod-pair__r">' + (room ? '<b>' + esc(L.roomWords(room)) + '</b>' : '') + (L.ro ? '' : '<button type="button" class="wk-linklike" data-yfmove="' + esc(x.a.pid) + '">' + (room ? 'Change' : 'Room') + '</button><button type="button" class="wk-linklike" data-yfunpair="' + esc(x.a.pid) + '|' + esc(x.b.pid) + '">Unpair</button>') + '</span>' +
      (pick ? tiles(g, [x.a, x.b], room) : '') + '</li>';
  }
  function singleRow(i) {
    const asks = i.asks.filter(a => !a.m).map(a => a.t.replace(/\b\w/g, c => c.toUpperCase()));
    const flags = yfFlags([i]).concat(asks.map(a => a + ' · not registered'));
    const on = U.yfPair === i.pid, chosen = U.yfPair && everyYf().find(x => x.pid === U.yfPair);
    // "Pair with Adam" only in the chosen person's own hall; elsewhere a plain Pair (which chooses anew).
    const label = on ? 'Choose another' : chosen && chosen.key === i.key ? 'Pair with ' + L.first(chosen.p.name) : 'Pair';
    return '<li class="' + (on ? 'is-sel' : '') + '"><span><b>' + esc(i.p.name) + '</b>' + (flags.length ? '<span class="lod-hh__f">' + flagHtml(flags) + '</span>' : '') + (i.row.room ? '<small>' + esc(L.roomWords(i.row.room)) + '</small>' : '') + '</span>' +
      (L.ro ? '' : '<button type="button" class="wk-linklike lod-pairbtn" data-yfpair="' + esc(i.pid) + '" aria-pressed="' + on + '">' + esc(label) + '</button>') + '</li>';
  }
  // The hall's free rooms as tiles, to choose a pair's room.
  function tiles(g, who, cur) {
    const t = L.taken();
    return '<div class="lod-tiles">' + g.floors.map(f => '<p class="lod-fl">' + esc(L.floorName(f.floor)) + '</p><ul class="lod-grid">' + f.rooms.filter(r => (!t[r.id] || r.id === cur) && L.usable(r.id)).slice(0, 40).map(r => '<li><button type="button" class="lod-room' + (r.id === cur ? ' is-sel' : '') + '" data-yfroom="' + esc(r.id) + '" data-pids="' + esc(who.map(i => i.pid).join('|')) + '"><b>' + r.num + '</b></button></li>').join('') + '</ul>').join('') + '</div>';
  }
  // Each pair without a room, into its hall's rooms in order (free, not kept).
  function yfAssign() {
    const st = pairsOf(everyYf()), t = L.taken(), ops = [];
    yfHalls().forEach(g => {
      const free = [].concat.apply([], g.floors.map(f => f.rooms)).filter(r => !t[r.id] && L.usable(r.id));
      st.pairs.filter(x => x.a.key === g.key && !x.a.row.room && !x.b.row.room).forEach(x => {
        const r = free.shift();
        if (!r) return;
        [x.a, x.b].forEach(i => ops.push({ key: 'yf:' + i.pid, data: Object.assign({}, i.row, { room: r.id, mate: (i === x.a ? x.b : x.a).pid }) }));
      });
    });
    if (!ops.length) { L.toast('No rooms free'); return; }
    L.save(ops, { label: plural(ops.length / 2, 'pair') + ' · rooms given' });
  }

  /* ================================================================ Campers */

  const LEN = { short: 'Short', mid: 'Medium', long: 'Long' }, ARR = { afternoon: 'Afternoon', evening: 'Evening', late: 'Late' };
  function campers() { return S.hh.filter(h => h.type === 'camper' && !h.gone).sort((a, b) => a.sur.localeCompare(b.sur)); }
  const nCampers = h => +(h.d.stay && h.d.stay.campers) || 1;
  // Those who asked to be near each other arrive together (2026 packet: they must).
  function together(list) {
    const groups = [], seen = new Set();
    list.forEach(h => {
      if (seen.has(h)) return;
      const g = [h];
      seen.add(h);
      for (let k = 0; k < g.length; k++) {
        const x = g[k], w = x.nearText.toLowerCase();
        list.forEach(y => { if (!seen.has(y) && ((w && (w.indexOf(y.sur.toLowerCase()) > -1 || w === y.nearText.toLowerCase())) || (y.nearText && y.nearText.toLowerCase().indexOf(x.sur.toLowerCase()) > -1))) { seen.add(y); g.push(y); } });
      }
      groups.push(g);
    });
    return groups;
  }
  function campersHtml() {
    const list = campers();
    if (!list.length) return L.card('No campers', '');
    const ns = SU.nightsOf(S.cfg).filter(n => !SU.isEarly(n) || list.some(h => h.nights.indexOf(n) > -1));
    const per = ns.map(n => list.reduce((k, h) => k + (h.nights.indexOf(n) > -1 ? nCampers(h) : 0), 0)), max = Math.max.apply(null, per);
    const total = list.reduce((k, h) => k + nCampers(h), 0);
    // "Sat–Mon 10 a night": the nights with the most, said as a span when they run together.
    const at = ns.filter((n, i) => per[i] === max), run = at.length > 1 && at.every((n, i) => !i || ns.indexOf(n) === ns.indexOf(at[i - 1]) + 1);
    const most = per.every(k => k === per[0]) ? max + ' every night' : (at.length === 1 ? SU.nightShort(at[0]) : run ? SU.nightShort(at[0]) + '–' + SU.nightShort(at[at.length - 1]) : at.map(SU.nightShort).join(', ')) + ' · ' + max + ' a night';
    const groups = together(list);
    const row = h => { const s = h.d.stay || {}; return '<li class="lod-row"><div class="lod-who"><p class="lod-name">' + nameLine(h) + '</p><p class="lod-meta">' + esc([plural(h.people.length, 'person', 'people'), nCampers(h) > 1 ? nCampers(h) + ' campers' : '', LEN[s.camperLen] ? LEN[s.camperLen] + ' camper' : '', ARR[s.arrive] ? 'Arrives ' + ARR[s.arrive].toLowerCase() : '', L.someNights(h.nights)].filter(Boolean).join(' · ')) + '</p>' +
      (h.phone ? '<p class="lod-meta lod-quiet"><a class="lod-tel" href="tel:' + esc(h.phone.replace(/[^\d+]/g, '')) + '">' + I.phone + esc(h.phone) + '</a></p>' : '') + '</div></li>'; };
    return '<div class="lod-top"><div class="lod-top__s"><p class="lod-status"><b>' + plural(total, 'camper') + '</b> · ' + esc(most) + '</p><p class="lod-help">Check-in · camper host</p></div>' + tools('campers') + '</div>' +
      (per.every(k => k === per[0]) ? '' : '<ul class="lod-nights" aria-label="Campers each night">' + ns.map((n, i) => '<li><span>' + esc(SU.nightShort(n)) + '</span><b>' + per[i] + '</b><small>' + (per[i] === 1 ? 'camper' : 'campers') + '</small></li>').join('') + '</ul>') +
      printHead('Camper lot', plural(total, 'camper')) +
      groups.filter(g => g.length > 1).map(g => '<h3 class="lod-sub">Arriving together</h3><ul class="lod-list lod-list--group">' + g.map(row).join('') + '</ul>').join('') +
      '<ul class="lod-list">' + groups.filter(g => g.length === 1).map(g => row(g[0])).join('') + '</ul>';
  }

  /* ================================================================ Check-in */

  // The Lodging Desk is open from the first night anyone arrives through check-out morning (the
  // morning after the last night); Keys back keeps working after that, until names are cleared.
  const firstNight = () => { const ns = SU.nightsOf(S.cfg).filter(n => L.dorm().some(h => h.nights.indexOf(n) > -1)); return ns[0] ? L.nightDate(ns[0]) : S.phase.start; };
  L.deskOn = () => !S.phase.cleared && today() >= (firstNight() || S.phase.start || '9999') && (!S.phase.checkout || today() <= S.phase.checkout);
  const deskLate = () => !S.phase.cleared && today() >= (firstNight() || S.phase.start || '9999');
  function checkedIn(h) { return L.hrow(h).checkin || null; }
  const keysPer = (h, i) => S.cfg.keys_per === 'person' ? Math.max(1, L.inRoom(h, i).filter(p => p.band !== 'baby').length) : 1;
  const keysOut = (h, id, i) => { const k = L.hrow(h).keysout || {}; return k[id] != null ? +k[id] : keysPer(h, i); };
  function keysLine(h) {
    const g = L.given(h), k = L.keysOf(h), ci = checkedIn(h), back = L.hrow(h).back || {};
    if (!g.length) return '<span class="lod-rk">' + I.key + '<span>keys: ' + esc(Array.from(new Set(k)).map(L.first).join(', ')) + '</span></span>';
    return g.map((id, i) => '<span class="lod-rk"><b>' + esc(L.roomWords(id)) + '</b> · ' + I.key + '<span>keys: ' + esc(L.first((ci && ci.keys && ci.keys[id]) || k[i] || k[0])) + '</span>' + (back[id] ? ' · <small>keys back</small>' : '') + '</span>').join('');
  }
  // A Young Folk asked for at the desk: where they check in.
  function yfAnswer(f) {
    if (!f) return '';
    const hits = everyYf().filter(i => i.p.name.toLowerCase().indexOf(f) > -1).slice(0, 4);
    return hits.length ? '<ul class="lod-yfhits">' + hits.map(i => '<li><b>' + esc(i.p.name) + '</b> · ' + esc((i.key === 'women' ? 'Young women’s hall' : i.key === 'men' ? 'Young men’s hall' : 'Young Folks halls') + (L.yfHallOf(i.key) ? ' (' + L.hallShort(L.yfHallOf(i.key)) + ')' : '') + ' · checks in at its lobby' + (i.row && i.row.room ? ' · ' + L.roomWords(i.row.room) : '')) + '</li>').join('') + '</ul>' : '';
  }
  function deskRow(h, owes) {
    const ci = checkedIn(h), g = L.given(h), back = L.hrow(h).back || {}, allBack = g.length && g.every(id => back[id]);
    const ns = L.someNights(h.nights), open = U.ciOpen === h.rid, leaves = L.depart(h.nights);
    let act = '';
    if (g.length && !L.ro) {
      if (!ci && L.deskOn()) act = '<button type="button" class="lod-act" data-checkin="' + esc(h.rid) + '">Check in</button>';
      // Keys back only from the household's last morning, so a tap on arrival day can't record it.
      else if (ci && !allBack && deskLate() && leaves && today() >= leaves) act = '<button type="button" class="lod-act" data-keysback="' + esc(h.rid) + '" title="Credit for nights not used needs the keys back">Keys back</button>';
    } else if (g.length && ci && !allBack && deskLate() && leaves && today() >= leaves) act = '<button type="button" class="lod-act" data-keysback="' + esc(h.rid) + '">Keys back</button>';
    const n = ci ? g.reduce((k, id, i) => k + keysOut(h, id, i), 0) : 0;
    const status = ci ? '<small class="lod-ci">' + I.check + 'Checked in ' + esc(L.time(ci.at)) + ' · ' + plural(n, 'key') + (allBack ? ' · keys back' : '') + '</small>' : '';
    const more = open ? '<tr class="lod-ciopen"><td colspan="' + (owes ? 5 : 4) + '">' + ciMore(h) + '</td></tr>' : '';
    return '<tr class="' + (ci ? 'is-in' : '') + (open ? ' is-open' : '') + '" data-cirow="' + esc(h.rid) + '"><td data-label="Household"><button type="button" class="lod-tname" data-ciopen="' + esc(h.rid) + '" aria-expanded="' + open + '">' + nameLine(h) + '</button>' + status + '</td><td data-label="Rooms · keys">' + keysLine(h) + '</td><td data-label="Nights">' + esc(ns) + '</td>' + (owes ? '<td data-label="Balance">' + (L.owes(h) ? '<span class="lod-due">' + esc(L.owes(h)) + '</span>' : '') + '</td>' : '') + '<td class="lod-tact">' + act + '</td>' +
      '<td class="lod-tick" aria-hidden="true"></td><td class="lod-tick" aria-hidden="true"></td><td class="lod-tick" aria-hidden="true"></td></tr>' + more;
  }
  // A row opened at the desk: who's coming (a Young Folk with their hall), and the keys handed out.
  function ciMore(h) {
    const g = L.given(h), ci = checkedIn(h);
    const ppl = h.people.map(p => esc(p.name) + (h.inHall(p) ? ' <small>· ' + esc(p.yfHall === 'women' ? 'young women’s hall' : 'young men’s hall') + '</small>' : '')).join(' · ');
    const keys = ci && !L.ro ? '<p class="lod-keysout">' + g.map((id, i) => '<span>' + esc(L.roomWords(id)) + ' · keys out <button type="button" data-keysout="-1" data-rid="' + esc(h.rid) + '" data-room="' + esc(id) + '" aria-label="Fewer keys">−</button><b>' + keysOut(h, id, i) + '</b><button type="button" data-keysout="1" data-rid="' + esc(h.rid) + '" data-room="' + esc(id) + '" aria-label="More keys">+</button></span>').join('') + '</p>' : '';
    return '<p class="lod-meta">' + ppl + '</p>' + keys;
  }
  function deskHtml() {
    const list = L.dorm(), given = list.filter(h => L.given(h).length);
    const f = (U.ciFind || '').trim().toLowerCase();
    const hit = h => !f || (h.label + ' ' + h.rid).toLowerCase().indexOf(f) > -1 || h.people.some(p => !h.inHall(p) && p.name.toLowerCase().indexOf(f) > -1) || L.given(h).some(id => L.roomWords(id).toLowerCase().indexOf(f) > -1);
    // By arrival: each night's households, the first night first.
    const order = SU.nightsOf(S.cfg), groups = {};
    list.filter(hit).forEach(h => { const n = h.nights[0] || order[0]; (groups[n] = groups[n] || []).push(h); });
    const ins = list.filter(checkedIn).length;
    // The Balance column only when someone owes something (never a column of blanks).
    const owes = list.some(h => L.owes(h));
    const top = '<div class="lod-top"><div class="lod-top__s"><p class="lod-status">' + (L.deskOn() ? '<b>' + ins + '</b> of ' + given.length + ' checked in' : '<b>' + list.length + '</b> households · Lodging Desk') + '</p>' +
      (given.length < list.length ? '<p class="lod-help">' + (given.length ? (list.length - given.length) + ' without rooms · ' : 'Rooms not assigned · ') + '<button type="button" class="wk-linklike" data-view="rooms">Rooms</button></p>' : '') + '</div>' + tools('checkin') + '</div>';
    const find = '<label class="lod-find lod-find--desk"><span class="ogc-sr">Search</span>' + I.search + '<input type="search" data-cifind placeholder="Search" title="Anyone’s name, a room or R-number" value="' + esc(U.ciFind || '') + '" autocomplete="off"></label>';
    const cols = owes ? 5 : 4;
    const body = order.filter(n => groups[n]).map(n => '<tbody><tr class="lod-tgroup"><th colspan="' + (cols + 3) + '">' + esc(n + ' · ' + groups[n].length) + '</th></tr>' + groups[n].sort((a, b) => a.sur.localeCompare(b.sur)).map(h => deskRow(h, owes)).join('') + '</tbody>').join('');
    const yf = yfAnswer(f);
    return top + find + yf + printHead('Check-in', plural(list.length, 'household')) +
      (body ? '<table class="lod-table lod-desk"><thead><tr><th>Household</th><th>Rooms · keys</th><th>Nights</th>' + (owes ? '<th>Balance</th>' : '') + '<th><span class="ogc-sr">Check in</span></th><th class="lod-tick">In</th><th class="lod-tick">Keys out</th><th class="lod-tick">Keys back</th></tr></thead>' + body + '</table>' : yf ? '' : '<p class="lod-none">No matches</p>');
  }
  // Linens and air mattresses go in the rooms before arrival: rooms and counts only, hall by hall, floor by floor.
  function setupRows() {
    const rows = [];
    L.dorm().forEach(h => {
      const ids = L.given(h), n = ids.length, set = L.hrow(h).setup || {};
      ids.forEach((id, i) => {
        const share = t => Math.floor(t / n) + (i < t % n ? 1 : 0), s = set[id];
        const l = s ? s.l : share(h.linens), m = s ? s.m : share(h.mattresses);
        const here = L.inRoom(h, i), ns = here.length && here.some(p => p.nights && p.nights.length) ? here.map(p => p.nights && p.nights.length ? p.nights : h.nights).sort((a, b) => SU.nightsOf(S.cfg).indexOf(a[0]) - SU.nightsOf(S.cfg).indexOf(b[0]))[0] : h.nights;
        if (l || m || s) rows.push({ r: L.room(id), h, l, m, arrives: ns[0] || '' });
      });
    });
    return rows.sort((a, b) => S.rooms.indexOf(a.r) - S.rooms.indexOf(b.r));
  }
  function setupHtml() {
    const rows = setupRows();
    if (!L.dorm().some(h => L.given(h).length)) return '<p class="lod-help lod-gap">Rooms not assigned · <button type="button" class="wk-linklike" data-view="rooms">Rooms</button></p>';
    const l = rows.reduce((k, x) => k + x.l, 0), m = rows.reduce((k, x) => k + x.m, 0);
    let last = '';
    // Plain numbers, blank for none; a tap on one edits it.
    const cell = (x, k, v) => {
      const key = x.h.rid + '~' + x.r.id + '~' + k, lab = (k === 'l' ? 'Linen packets' : 'Air mattresses') + ', room ' + x.r.num;
      if (U.setupEdit === key && !L.ro) return '<input type="number" min="0" max="24" inputmode="numeric" data-setup="' + esc(key) + '" value="' + (v || 0) + '" aria-label="' + esc(lab) + '">';
      return L.ro ? String(v || '') : '<button type="button" class="lod-num" data-setupedit="' + esc(key) + '" aria-label="' + esc(lab + ': ' + (v || 'none')) + '">' + (v || '') + '</button>';
    };
    return '<div class="lod-top"><div class="lod-top__s"><p class="lod-status">' + esc([plural(rows.length, 'room') + ' to set up', plural(l, 'linen packet'), m ? plural(m, 'air mattress', 'air mattresses') : ''].filter(Boolean).join(' · ')) + '</p></div>' + tools('setup') + '</div>' + printHead('Room setup', plural(rows.length, 'room')) +
      '<table class="lod-table lod-setup"><thead><tr><th>Room</th><th>Arrives</th><th>Linen packets</th><th>Air mattresses</th></tr></thead><tbody>' +
      rows.map(x => { const fl = x.r.hall + '|' + x.r.floor, head = fl !== last ? '<tr class="lod-tgroup"><th colspan="4">' + esc(x.r.hall + ' · ' + L.floorName(x.r.floor)) + '</th></tr>' : ''; last = fl;
        return head + '<tr><td data-label="Room"><b>' + x.r.num + '</b></td><td data-label="Arrives">' + esc(SU.nightShort(x.arrives)) + '</td><td data-label="Linen packets">' + cell(x, 'l', x.l) + '</td><td data-label="Air mattresses">' + cell(x, 'm', x.m) + '</td></tr>'; }).join('') + '</tbody></table>';
  }
  // Linen packets, said the same way everywhere: those in rooms (Room setup's), those for Young Folks
  // in their halls, and those of households without rooms yet.
  function linens() {
    const rooms = setupRows().reduce((k, x) => k + x.l, 0);
    const yf = S.hh.filter(h => !h.gone && h.type === 'yf').reduce((k, h) => k + h.linens, 0);
    const waiting = L.dorm().filter(h => !L.given(h).length).reduce((k, h) => k + h.linens, 0);
    return { rooms, yf, waiting };
  }
  // The final count for the campus: each night, rooms by hall, Young Folks by hall, campers.
  function countsRows() {
    const ns = SU.nightsOf(S.cfg), halls = Array.from(new Set(L.familyFloors().map(f => f.hall)));
    const yh = yfHalls(), yf = everyYf(), camp = S.hh.filter(h => h.type === 'camper' && !h.gone);
    const head = ['Night', 'Date'].concat(halls.map(h => L.hallShort(h) + ' · rooms'), yh.map(g => L.hallShort(g.hall) + ' · Young Folks'), camp.length ? ['Camper lot · campers'] : []);
    const rows = ns.filter(n => !SU.isEarly(n) || L.dorm().some(h => h.nights.indexOf(n) > -1)).map(n => [n, L.dateShort(L.nightDate(n))]
      .concat(halls.map(hall => L.dorm().reduce((k, h) => k + (h.nights.indexOf(n) > -1 ? L.given(h).filter(id => L.room(id).hall === hall).length : 0), 0)),
        yh.map(g => yf.filter(i => i.key === g.key && yfNights(i).indexOf(n) > -1).length),
        camp.length ? [camp.reduce((k, h) => k + (h.nights.indexOf(n) > -1 ? nCampers(h) : 0), 0)] : []));
    const d = L.dorm(), keys = d.reduce((k, h) => k + L.given(h).reduce((j, id, i) => j + keysPer(h, i), 0), 0) + yf.length, ln = linens();
    // Linen packets as Room setup counts them (in rooms), and those for the Young Folks halls apart.
    const totals = [['Rooms given', d.reduce((k, h) => k + L.given(h).length, 0)], ['Linen packets', ln.rooms]].concat(ln.yf ? [['Linen packets · Young Folks halls', ln.yf]] : [], [['Air mattresses', d.reduce((k, h) => k + h.mattresses, 0)], ['Keys', keys]]);
    return { head, rows, totals, ln };
  }
  function countsHtml() {
    const C = countsRows(), st = L.data('meta:steps') || {}, ln = C.ln;
    const why = ln.waiting ? 'In rooms, as Room setup has them · ' + ln.waiting + ' more for households without rooms yet' : '';
    return '<div class="lod-top"><div class="lod-top__s">' +
      (st.counts ? '<p class="lod-pub">' + I.check + 'Sent ' + esc(L.md(st.counts.at) + ' · ' + st.counts.by) + '</p>' : S.phase.start ? '<p class="lod-help">To the campus by ' + esc(O.fmtDate(O.isoAddDays(S.phase.start, -14), 'md')) + '</p>' : '') + '</div>' +
      (!L.ro && !st.counts ? '<button type="button" class="wk-btn wk-btn--line wk-btn--small" data-countsent title="Marks the step done in What to do">Mark sent</button>' : '') + tools('counts') + '</div>' + printHead('Counts', '') +
      '<ul class="lod-totals">' + C.totals.map(x => '<li><b>' + x[1] + '</b> ' + esc(x[0].toLowerCase().replace('young folks', 'Young Folks')) + (x[0] === 'Linen packets' && why ? ' ' + L.info(why, 'linens') : '') + '</li>').join('') + '</ul>' +
      '<div class="lod-scroll"><table class="lod-table lod-counts"><thead><tr>' + C.head.map(h => '<th>' + esc(h) + '</th>').join('') + '</tr></thead><tbody>' + C.rows.map(r => '<tr>' + r.map((v, i) => '<td data-label="' + esc(C.head[i]) + '">' + (i === 0 ? '<b>' + esc(v) + '</b>' : esc(v || '')) + '</td>').join('') + '</tr>').join('') + '</tbody></table></div>';
  }
  function checkinHtml() {
    if (!L.dorm().length) return L.card('No households in dorm rooms', '');
    const seg = '<div class="lod-seg" role="group" aria-label="List">' + [['desk', 'Desk'], ['setup', 'Room setup'], ['counts', 'Counts']].map(m => '<button type="button" data-ci="' + m[0] + '" aria-pressed="' + (U.ci === m[0]) + '">' + m[1] + '</button>').join('') + '</div>';
    return seg + (U.ci === 'setup' ? setupHtml() : U.ci === 'counts' ? countsHtml() : deskHtml());
  }

  /* ================================================================ a year whose names are cleared */

  L.views.held = {
    html() {
      const N = S.numbers || {}, P = S.phase, halls = Object.keys(N.by_hall || {});
      const nights = N.nights || [], when = O.fmtDateSpan(N.start || P.start, N.end || P.end);
      const totals = [[N.households, 'households in dorm rooms'], [N.rooms, 'rooms given'], [(N.linens || 0) + (N.yf_linens || 0), 'linen packets'], [N.mattresses, 'air mattresses'], [N.yf_rooms, 'Young Folks rooms']].filter(x => x[0]);
      return '<section class="lod-heldcard"><p class="wk-kicker">Over · names cleared ' + esc(O.fmtDate(P.clear, 'md')) + '</p><h2 class="lod-h">' + esc([when, N.rooms ? plural(N.rooms, 'room') : ''].filter(Boolean).join(' · ')) + '</h2>' +
        '<ul class="lod-totals">' + totals.map(x => '<li><b>' + x[0] + '</b> ' + esc(x[1]) + '</li>').join('') + '</ul>' + (halls.length ? tools('held') : '') + '</section>' +
        printHead('The year in counts', '') +
        (halls.length ? '<div class="lod-scroll"><table class="lod-table lod-counts"><thead><tr><th>Night</th>' + halls.map(h => '<th>' + esc(L.hallShort(h) + ' · rooms') + '</th>').join('') + '<th>Camper lot · campers</th></tr></thead><tbody>' +
          nights.map(n => '<tr><td><b>' + esc(n) + '</b></td>' + halls.map(h => '<td>' + ((N.per_night[n] || {})[h] || '') + '</td>').join('') + '<td>' + ((N.campers || {})[n] || '') + '</td></tr>').join('') + '</tbody></table></div>' : '');
    }
  };

  /* ================================================================ tab counts */

  L.listCounts = () => {
    const out = {};
    const all = everyYf();
    if (all.length) { const st = pairsOf(all); out.yf = st.single.length ? [String(st.single.length), st.single.length + ' unpaired'] : null; }
    if (L.deskOn()) { const d = L.dorm().filter(h => L.given(h).length); out.checkin = [d.filter(h => checkedIn(h)).length + '/' + d.length, 'checked in']; }
    return out;
  };

  L.views.yf = { html: yfHtml };
  L.views.campers = { html: campersHtml };
  L.views.checkin = { html: checkinHtml };

  /* ================================================================ print and download */

  function csvOf(list) {
    if (list === 'checkin') {
      const rows = [['Household', 'Registration', 'Rooms', 'Keys to', 'Arrive', 'Depart', 'Balance', 'Checked in', 'Keys out']];
      L.dorm().sort((a, b) => a.sur.localeCompare(b.sur)).forEach(h => { const g = L.given(h), k = L.keysOf(h), ci = checkedIn(h); rows.push([listName(h), h.rid, g.map(L.roomWords).join('; '), g.length ? g.map((id, i) => k[i] || k[0]).join('; ') : Array.from(new Set(k)).join('; '), L.arrive(h.nights), L.depart(h.nights), L.owes(h), ci ? L.when(ci.at) : '', ci ? g.reduce((j, id, i) => j + keysOut(h, id, i), 0) : '']); });
      return rows;
    }
    if (list === 'setup') return [['Hall', 'Floor', 'Room', 'Arrives', 'Linen packets', 'Air mattresses']].concat(setupRows().map(x => [x.r.hall, x.r.floor, x.r.num, x.arrives ? L.dateShort(L.nightDate(x.arrives)) : '', x.l || '', x.m || '']));
    if (list === 'counts') { const C = countsRows(); return [C.head].concat(C.rows, [[]], C.totals); }
    if (list === 'held') {
      const N = S.numbers || {}, halls = Object.keys(N.by_hall || {});
      return [['Night'].concat(halls.map(h => L.hallShort(h) + ' rooms'), ['Campers'])].concat((N.nights || []).map(n => [n].concat(halls.map(h => (N.per_night[n] || {})[h] || ''), [(N.campers || {})[n] || '']))).concat([[], ['Households in dorm rooms', N.households || 0], ['Rooms given', N.rooms || 0], ['Linen packets', (N.linens || 0) + (N.yf_linens || 0)], ['Air mattresses', N.mattresses || 0], ['Young Folks rooms', N.yf_rooms || 0]]);
    }
    if (list === 'campers') return [['Household', 'People', 'Campers', 'Length', 'Arrive', 'Nights', 'Phone', 'Together with']].concat(together(campers()).reduce((a, g) => a.concat(g.map(h => [listName(h), h.people.length, nCampers(h), LEN[h.d.stay.camperLen] || '', ARR[h.d.stay.arrive] || '', L.nightSpan(h.nights).replace('–', '-'), h.phone, g.filter(x => x !== h).map(x => x.sur).join('; ')])), []));
    if (list === 'yf') {
      const st = pairsOf(everyYf()), rows = [['Hall', 'Room', 'Name', 'Rooming with', 'Nights', 'Under 18', 'Approval', 'Key out', 'Key back']];
      yfHalls().forEach(g => {
        st.pairs.filter(x => x.a.key === g.key).forEach(x => [x.a, x.b].forEach(i => rows.push([g.hall, i.row.room ? L.room(i.row.room).num : '', i.p.name, (i === x.a ? x.b : x.a).p.name, L.nightSpan(yfNights(i)).replace('–', '-'), i.p.minor ? 'Yes' : '', (approval(i) || {}).t || '', '', ''])));
        st.single.filter(i => i.key === g.key).forEach(i => rows.push([g.hall, i.row.room ? L.room(i.row.room).num : '', i.p.name, '', L.nightSpan(yfNights(i)).replace('–', '-'), i.p.minor ? 'Yes' : '', (approval(i) || {}).t || '', '', '']));
      });
      return rows;
    }
    return [];
  }
  const fileName = { checkin: 'Check-in', setup: 'Room setup', counts: 'Counts', campers: 'Camper lot', yf: 'Young Folks halls', held: 'Lodging counts' };

  /* ================================================================ events */

  root.addEventListener('click', e => {
    if (['yf', 'campers', 'checkin'].indexOf(S.view) < 0 && !(S.phase.cleared && e.target.closest('[data-print], [data-csv]'))) return;
    const el = e.target.closest('[data-print], [data-csv], [data-ci], [data-checkin], [data-keysback], [data-keysout], [data-ciopen], [data-setupedit], [data-countsent], [data-yfassign], [data-yfsuggest], [data-yfpairall], [data-yfskip], [data-yfpair], [data-yfmove], [data-yfroom], [data-yfunpair]');
    if (!el) return;
    const ds = el.dataset;
    if (ds.print) { L.api('POST', '/log', { what: 'print', list: ds.print }).then(() => { if (ds.print === 'checkin') L.refresh(true); }).catch(() => {}); window.print(); }
    else if (ds.csv) L.download(csvOf(ds.csv), fileName[ds.csv] + ' ' + S.year + ' ' + L.stamp() + '.csv', ds.csv);
    else if (ds.ci) { U.ci = ds.ci; L.redraw(); }
    else if (ds.ciopen) { U.ciOpen = U.ciOpen === ds.ciopen ? '' : ds.ciopen; L.redraw(); }
    else if (ds.setupedit) {
      U.setupEdit = ds.setupedit; L.redraw();
      // After the click has finished (the button it came from is gone), the number is chosen, ready to type over.
      requestAnimationFrame(() => { const x = root.querySelector('[data-setup="' + CSS.escape(ds.setupedit) + '"]'); if (x) { x.focus(); x.select(); } });
    }
    else if (ds.checkin) {
      const h = L.byRid(ds.checkin), g = L.given(h), k = L.keysOf(h), keys = {}, n = {};
      g.forEach((id, i) => { keys[id] = k[i] || k[0]; n[id] = keysPer(h, i); });
      const who = Array.from(new Set(Object.values(keys))).map(L.first).join(' and ');
      L.hhSave(h, { checkin: { keys }, keysout: n }, { label: 'Check-in · ' + h.sur, toast: h.sur + ' · Checked in · keys: ' + who, late: true });
    } else if (ds.keysback) {
      const h = L.byRid(ds.keysback), b = {};
      L.given(h).forEach(id => { b[id] = true; });
      L.hhSave(h, { back: Object.assign({}, L.hrow(h).back || {}, b) }, { label: 'Keys back · ' + h.sur, late: true });
    } else if (ds.keysout) {
      // A room's id has a bar in it ("Reed Hall|330"): household and room come as their own attributes.
      const id = ds.room, d = ds.keysout, h = L.byRid(ds.rid), i = L.given(h).indexOf(id), cur = keysOut(h, id, i);
      const k = Object.assign({}, L.hrow(h).keysout || {}); k[id] = Math.max(0, Math.min(12, cur + (+d)));
      L.hhSave(h, { keysout: k }, { label: 'Keys out · ' + h.sur, toast: L.roomWords(id) + ' · ' + plural(k[id], 'key') + ' out', late: true });
    } else if (el.hasAttribute('data-countsent')) { const st = Object.assign({}, L.data('meta:steps') || {}); st.counts = true; L.save([{ key: 'meta:steps', data: st }], { label: 'Counts sent', late: true }); }
    else if (el.hasAttribute('data-yfassign')) yfAssign();
    else if (ds.yfsuggest) { U.yfSuggest = ds.yfsuggest === 'on'; U.yfPair = ''; L.redraw(); }
    else if (ds.yfskip) { U.yfSkip = (U.yfSkip || []).concat(ds.yfskip); L.redraw(); }
    else if (el.hasAttribute('data-yfpairall')) {
      const all = everyYf(), st = pairsOf(all), ops = [];
      yfHalls().forEach(g => suggestPairs(st.single.filter(i => i.key === g.key)).forEach(x => x.forEach((i, k) => ops.push({ key: 'yf:' + i.pid, data: Object.assign({}, i.row, { mate: x[1 - k].pid }) }))));
      U.yfSuggest = false;
      if (ops.length) L.save(ops, { label: plural(ops.length / 2, 'pair') + ' · paired' }); else L.redraw();
    }
    else if (ds.yfpair) {
      const all = everyYf(), A = U.yfPair && all.find(i => i.pid === U.yfPair), B = all.find(i => i.pid === ds.yfpair);
      // The first tap, the same one again, or one in the other hall: that one is chosen now.
      if (!A || A === B || !B || A.key !== B.key) { U.yfPair = A === B ? '' : ds.yfpair; L.redraw(); return; }
      U.yfPair = '';
      L.save([{ key: 'yf:' + A.pid, data: Object.assign({}, L.data('yf:' + A.pid) || {}, { mate: B.pid }) }, { key: 'yf:' + B.pid, data: Object.assign({}, L.data('yf:' + B.pid) || {}, { mate: A.pid }) }], { label: L.first(A.p.name) + ' and ' + L.first(B.p.name) + ' · Paired' });
    } else if (ds.yfunpair) {
      // Both stay unpaired (their asks no longer pair them) until Lodging pairs them again; the room is freed.
      const [a, b] = ds.yfunpair.split('|'), strip = k => { const d = Object.assign({}, L.data('yf:' + k) || {}); delete d.room; d.mate = 'none'; return d; };
      L.save([{ key: 'yf:' + a, data: strip(a) }, { key: 'yf:' + b, data: strip(b) }], { label: 'Unpaired · room freed' });
    } else if (ds.yfmove) { U.yfMove = U.yfMove === ds.yfmove ? '' : ds.yfmove; L.redraw(); }
    else if (ds.yfroom) {
      const pids = ds.pids.split('|'), ops = pids.map((p, i) => ({ key: 'yf:' + p, data: Object.assign({}, L.data('yf:' + p) || {}, { room: ds.yfroom, mate: pids[1 - i] || '' }) }));
      U.yfMove = '';
      L.save(ops, { label: L.roomWords(ds.yfroom) + ' · ' + plural(pids.length, 'Young Folk') });
    }
  });
  root.addEventListener('input', e => {
    if (S.view !== 'checkin' || !e.target.matches('[data-cifind]')) return;
    U.ciFind = e.target.value;
    L.redraw();
  });
  root.addEventListener('change', e => {
    if (S.view !== 'checkin' || !e.target.matches('[data-setup]')) return;
    const [rid, id, k] = e.target.dataset.setup.split('~'), h = L.byRid(rid), v = Math.max(0, Math.min(24, +e.target.value || 0));
    const rows = setupRows(), cur = rows.find(x => x.h === h && x.r.id === id) || { l: 0, m: 0 };
    const set = Object.assign({}, L.hrow(h).setup || {});
    set[id] = { l: k === 'l' ? v : cur.l, m: k === 'm' ? v : cur.m };
    U.setupEdit = '';
    L.hhSave(h, { setup: set }, { label: L.roomWords(id) + ' · ' + (k === 'l' ? plural(v, 'linen packet') : plural(v, 'air mattress', 'air mattresses')) });
  });
  root.addEventListener('keydown', e => {
    if (S.view === 'checkin' && e.key === 'Escape' && U.setupEdit) { U.setupEdit = ''; L.redraw(); }
  });
})();
