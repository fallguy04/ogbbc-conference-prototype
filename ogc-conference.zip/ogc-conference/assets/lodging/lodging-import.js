/*
 * lodging-import.js — Import from the Google Form (docs/20's middle path), ?view=import: File › Columns ›
 * Check, then the households are on the board, marked Form.
 *
 *   File      the responses as a CSV (Google Sheets › File › Download › Comma-separated values, or Excel's
 *             re-saved CSV: its Windows text and "7-May" dates read too), chosen or dropped anywhere on
 *             the page. An .xlsx says to save it as CSV. Nothing is kept on the server but the answers.
 *   Columns   each of the file's columns, two of its answers, and what it fills on the board: matched by
 *             its words (Matched, Check, Not used), changed in a type-ahead box (no dropdown). Columns
 *             not used are named, never dropped quietly. Remembered for the next upload and next year.
 *   Check     what will happen before anything is saved: households, responses merged (Combine · Keep
 *             newest · Keep both), cells that didn't read and why, and on a later upload what changed and
 *             who isn't in this file (Remove, only when asked). Then one Import. Undo import until the next.
 */
(function () {
  'use strict';
  const L = window.OGC.lodging, O = window.OGC, S = L.S, I = L.I, esc = L.esc, root = L.root, W = window.OGC_WP || {};
  const plural = L.plural;
  const M = S.ui.imp = { step: 'file', text: '', name: '', cols: [], fields: [], mapping: {}, check: null, choices: {}, remove: {}, busy: false, err: '' };

  const STATES = { matched: 'Matched', check: 'Check', unused: 'Not used' };
  const stepper = () => '<ol class="lod-stepper" aria-label="Steps">' + [['file', 'File'], ['columns', 'Columns'], ['check', 'Check']].map((s, i, a) => {
    const at = a.findIndex(x => x[0] === M.step), done = i < at;
    return '<li class="' + (s[0] === M.step ? 'is-on' : done ? 'is-done' : '') + '"' + (s[0] === M.step ? ' aria-current="step"' : '') + '><span>' + (done ? I.check : i + 1) + '</span>' + s[1] + '</li>';
  }).join('') + '</ol>';

  // Undo import is offered once, in the toast after an import, and only while nothing has been done
  // with those households since (the server refuses after that, and says why).
  function fileStep() {
  const last = S.imported, coarse = window.matchMedia('(pointer: coarse)').matches;
  return '<div class="lod-drop" data-dropzone><p class="lod-drop__h">' + I.up + (coarse ? 'Choose the responses file' : 'Drop the responses file') + '</p><p class="lod-help">CSV · Google Sheets › File › Download › Comma-separated values</p>' +
      '<p class="lod-btns"><label class="wk-btn lod-filebtn">Choose file<input type="file" accept=".csv,text/csv,.tsv,.txt,.xlsx,.xls" data-impfile hidden></label>' +
      (W.dev ? '<button type="button" class="ogc-mock" data-impsample title="Local only: a made-up 2026-style export">Mockup: sample file</button>' : '') + '</p>' +
      (M.err ? '<p class="lod-err" role="alert">' + esc(M.err) + '</p>' : '') + '</div>' +
      (last ? '<p class="lod-lastimp">' + esc('Last import · ' + L.when(last.at) + ' · ' + last.by + ' · ' + plural((last.summary || {}).rows || 0, 'row') + ((last.summary || {}).created ? ' · ' + last.summary.created + ' added' : '') + (last.undone ? ' · Undone' : '')) + '</p>' : '');
  }

  function columnsStep() {
    const byId = {};
    M.fields.forEach(f => { byId[f.id] = f; });
    const used = M.cols.filter(c => M.mapping[c.i]), unused = M.cols.filter(c => !M.mapping[c.i]);
    const dl = '<datalist id="lod-fields">' + M.fields.map(f => '<option value="' + esc(f.label) + '">').join('') + '<option value="Not used"></datalist>';
    return '<p class="lod-status"><b>' + esc(M.name) + '</b> · ' + plural(M.rows, 'response') + ' · ' + plural(M.cols.length, 'column') + (M.saved ? ' · <span title="The columns as last time' + (M.from ? ' (' + M.from + ')' : '') + '">Mapping kept</span>' : '') + '</p>' + dl +
      '<table class="lod-table lod-map"><thead><tr><th>Column in the file</th><th>Fills</th><th><span class="ogc-sr">Match</span></th></tr></thead><tbody>' +
      M.cols.map(c => {
        const f = byId[M.mapping[c.i]], st = M.state[c.i] || (f ? 'matched' : 'unused');
        return '<tr class="is-' + st + '"><td data-label="Column"><b>' + esc(c.h || '(no heading)') + '</b><small>' + (c.ex.length ? c.ex.map(esc).join(' · ') : 'Blank in every response') + '</small></td>' +
          '<td data-label="Fills"><input type="text" list="lod-fields" data-map="' + c.i + '" value="' + esc(f ? f.label : '') + '" placeholder="Not used" aria-label="' + esc('What “' + (c.h || '') + '” fills') + '" autocomplete="off"' + (f ? ' title="' + esc(f.help) + '"' : '') + '></td>' +
          '<td><span class="lod-state is-' + st + '">' + STATES[st] + '</span></td></tr>';
      }).join('') + '</tbody></table>' +
      (unused.length ? '<p class="lod-help" title="Kept out of the board: these answers aren’t saved">Not imported · ' + esc(unused.map(c => c.h).filter(Boolean).join(' · ')) + '</p>' : '') +
      '<p class="lod-btns lod-impnext"><button type="button" class="wk-btn" data-impnext' + (used.length ? '' : ' disabled') + '>Next</button><button type="button" class="wk-linklike lod-sans" data-impback="file">Back</button></p>';
  }

  function checkStep() {
    const C = M.check, s = C.summary;
    const again = s.changed + s.same + s.missing > 0;
    const line = [plural(s.rows, 'row'), plural(s.households, 'household'), s.merged ? s.merged + ' merged' : '', s.check ? s.check + ' to check' : ''].filter(Boolean).join(' · ');
    const line2 = again ? [s.new + ' new', s.changed + ' changed', s.same + ' unchanged', s.missing ? s.missing + ' not in this file' : ''].filter(Boolean).join(' · ') : '';
    const n = s.new + s.changed + Object.keys(M.remove).filter(k => M.remove[k]).length;
    // The columns as last time, said in one line (Change opens them).
    const used = M.cols.filter(c => M.mapping[c.i]).length;
    const cols = M.folded ? '<p class="lod-help">Columns · ' + used + ' matched · ' + (M.cols.length - used) + ' not used · <button type="button" class="wk-linklike lod-sans" data-impback="columns">Change</button></p>' : '';
    const choice = g => [['combine', 'Combine', 'One household: people together, rooms added up'], ['newest', 'Keep newest', 'A resubmission: the newest replaces the rest'], ['both', 'Keep both', 'Separate households']].map(x => '<button type="button" data-choice="' + esc(g.gid) + '|' + x[0] + '" aria-pressed="' + (g.choice === x[0]) + '" title="' + esc(x[2]) + '">' + x[1] + '</button>').join('');
    // Several responses from one email: each line with who's on it; what differs from the first is marked.
    const rowLine = (r, first) => {
      const bits = [['when', r.when || r.at], ['names', r.names], ['stay', r.type === 'dorm' ? plural(r.rooms || 1, 'room') : r.type === 'camper' ? 'Camper lot' : 'Elsewhere'], ['nights', r.nights]];
      return '<li><span class="lod-impline">Line ' + r.line + '</span>' + bits.filter(x => x[1]).map(x => '<span class="' + (first && x[0] !== 'when' && first[x[0]] !== r[x[0]] && !(x[0] === 'stay' && first.type === r.type && first.rooms === r.rooms) ? 'lod-diff' : '') + '">' + esc(x[1]) + '</span>').join(' · ') + '</li>';
    };
    return '<p class="lod-status"><b>' + esc(M.name) + '</b> · ' + esc(line) + '</p>' + (line2 ? '<p class="lod-help">' + esc(line2) + '</p>' : '') + cols +
      (C.groups.length ? '<section class="lod-impsec"><h2 class="lod-sub">Several responses · ' + C.groups.length + '</h2><ul class="lod-impgroups">' + C.groups.map(g => '<li><p><b>' + esc(g.label) + '</b><small>' + plural(g.n, 'response') + (g.suggest !== 'one' ? ' · ' + (g.suggest === 'newest' ? 'same people · likely a change' : 'different people · likely more rooms') : '') + '</small></p>' +
        '<ul class="lod-improws">' + g.rows.map((r, i) => rowLine(r, i ? g.rows[0] : null)).join('') + '</ul>' +
        '<p class="lod-pills" role="group" aria-label="' + esc(g.label) + '">' + choice(g) + '</p></li>').join('') + '</ul></section>' : '') +
      (C.problems.length ? '<section class="lod-impsec"><h2 class="lod-sub">To check · ' + C.problems.length + '</h2><p class="lod-help">Imported anyway, as each line says; nothing is dropped</p><ul class="lod-impprobs">' + C.problems.map(p => '<li><span class="lod-impline">Line ' + p.line + '</span><span><b>' + esc(p.label || '') + '</b><small>' + esc(p.col + (p.cell ? ' · “' + p.cell + '”' : '')) + '</small><small class="lod-impwhy">' + esc(p.reason) + '</small></span></li>').join('') + '</ul></section>' : '') +
      (C.changes.length ? '<section class="lod-impsec"><h2 class="lod-sub">Changed · ' + C.changes.length + '</h2><ul class="lod-impprobs">' + C.changes.map(c => '<li><span><b>' + esc(c.label) + '</b><small>' + esc(c.what.join(' · ')) + '</small></span></li>').join('') + '</ul></section>' : '') +
      (C.missing.length ? '<section class="lod-impsec"><h2 class="lod-sub">Not in this file · ' + C.missing.length + '</h2><p class="lod-help">Kept unless Remove is ticked: a response deleted from the Form, or a newer file without it</p><ul class="lod-impprobs">' + C.missing.map(m => '<li><span><b>' + esc(m.label) + '</b><small>' + esc(m.rid) + '</small></span><label class="lod-check"><input type="checkbox" data-impremove="' + esc(m.rid) + '"' + (M.remove[m.rid] ? ' checked' : '') + '> Remove</label></li>').join('') + '</ul></section>' : '') +
      (C.new.length ? '<details class="lod-impsec"><summary class="lod-sub">New · ' + C.new.length + '</summary><ul class="lod-impprobs">' + C.new.map(x => '<li><span class="lod-impline">Line ' + x.line + '</span><span>' + esc(x.label) + '</span></li>').join('') + '</ul></details>' : '') +
      '<p class="lod-btns lod-impnext"><button type="button" class="wk-btn" data-impgo' + (n ? '' : ' disabled') + '>' + (again ? 'Import · ' + n : 'Import ' + plural(s.new, 'household')) + '</button><button type="button" class="wk-linklike lod-sans" data-impback="' + (M.folded ? 'file' : 'columns') + '">Back</button></p>';
  }

  L.views.import = {
    html() {
      if (L.ro) return L.card('Held · No imports', '');
      return '<div class="lod-imp">' + stepper() + (M.busy ? '<p class="lod-status" role="status">' + (M.busy === 'apply' ? 'Importing' : 'Reading') + '</p>' : M.step === 'columns' ? columnsStep() : M.step === 'check' && M.check ? checkStep() : fileStep()) + '</div>';
    }
  };

  /* ================================================================ talking to the server */

  function call(step, extra) {
    M.busy = step === 'apply' ? 'apply' : true; M.err = ''; L.render();
    return L.api('POST', '/import', Object.assign({ step, text: M.text, name: M.name }, extra || {})).then(res => { M.busy = false; return res; }, err => { M.busy = false; M.err = err.message || 'Couldn’t read'; L.render(); throw err; });
  }
  function readColumns() {
    return call('columns').then(res => {
      M.step = 'columns'; M.rows = res.rows; M.cols = res.cols; M.fields = res.fields; M.saved = res.saved; M.from = res.from;
      M.mapping = {}; M.state = {};
      res.cols.forEach(c => { M.mapping[c.i] = c.field; M.state[c.i] = c.state; });
      M.check = null; M.choices = {}; M.remove = {};
      // The columns as last time, with nothing to check: straight on to Check, the columns in one line.
      M.folded = !!res.saved && !res.cols.some(c => c.state === 'check');
      if (M.folded) return readCheck();
      L.render();
    }, () => { M.step = 'file'; L.render(); });
  }
  function readCheck() {
    return call('check', { mapping: M.mapping, choices: M.choices }).then(res => {
      M.step = 'check'; M.check = res;
      L.render();
      const h = root.querySelector('.lod-imp .lod-status'); if (h) { h.setAttribute('tabindex', '-1'); h.focus({ preventScroll: true }); }
      }, () => { M.step = 'columns'; M.folded = false; L.render(); });
  }
  function apply() {
    const remove = Object.keys(M.remove).filter(k => M.remove[k]);
    return call('apply', { mapping: M.mapping, choices: M.choices, remove }).then(res => {
      const s = res.summary;
      Object.assign(M, { step: 'file', text: '', check: null });
      S.imported = { id: res.id, at: new Date().toISOString().slice(0, 19).replace('T', ' '), by: res.by, summary: s };
      reloadRecords().then(() => {
        L.go('rooms');
        L.toast(['Imported', s.created ? s.created + ' new' : '', s.updated ? s.updated + ' changed' : '', s.removed ? s.removed + ' removed' : ''].filter(Boolean).join(' · '), { action: ['Undo import', () => undoImport(res.id)] });
      });
    }, () => { M.step = 'check'; L.render(); });
  }
  function reloadRecords() {
    return (O.records ? O.records.load(S.year, ['registrations'], true) : Promise.resolve()).then(() => {
      // The households again, from the fresh records (lodging.js builds them the same way at load).
      const list = L.SU.households(S.year, S.cfg).map(L.norm).filter(h => h.rid);
      S.hh = list.sort((a, b) => a.sur.localeCompare(b.sur) || a.firsts.localeCompare(b.firsts));
      S.byRid = {};
      S.hh.forEach(h => { S.byRid[h.rid] = h; });
      return L.refresh(true);
    });
  }
  function undoImport(id) {
    L.api('POST', '/import/undo', { id }).then(() => { if (S.imported) S.imported.undone = true; reloadRecords().then(() => L.toast('Import undone')); }, err => L.toast(err.message || 'Can’t undo'));
  }

  // The file's text: UTF-8, or Excel's Windows text; a spreadsheet file itself says to save as CSV.
  function readFile(file) {
    if (!file) return;
    M.err = '';
    if (file.size > 3 * 1024 * 1024) { M.err = 'File too large'; L.render(); return; }
    file.arrayBuffer().then(buf => {
      const b = new Uint8Array(buf);
      if (b[0] === 0x50 && b[1] === 0x4b) { M.err = 'Excel file · Save as CSV (File › Save As › CSV) and choose it again'; M.step = 'file'; L.render(); return; }
      let text;
      try { text = new TextDecoder('utf-8', { fatal: true }).decode(b); } catch (e) { text = new TextDecoder('windows-1252').decode(b); }
      M.text = text; M.name = file.name || 'responses.csv';
      readColumns();
    });
  }
  L.importFile = file => { if (S.view !== 'import') L.go('import'); readFile(file); };

  /* ================================================================ events */

  root.addEventListener('click', e => {
    if (S.view !== 'import') return;
    const el = e.target.closest('[data-impsample], [data-impnext], [data-impback], [data-choice], [data-impgo], [data-impundo]');
    if (!el) return;
    const ds = el.dataset;
    // Local only: the made-up export (seed/dev/), from a route that exists only on a local site.
    if (el.hasAttribute('data-impsample')) L.api('GET', '/sample').then(r => { M.text = r.text; M.name = r.name; readColumns(); }, err => { M.err = err.message || 'No sample'; L.render(); });
    else if (el.hasAttribute('data-impnext')) readCheck();
    else if (ds.impback) { if (ds.impback === 'columns') M.folded = false; M.step = ds.impback; L.render(); }
    else if (ds.choice) { const [g, c] = ds.choice.split('|'); M.choices[g] = c; readCheck(); }
    else if (el.hasAttribute('data-impgo')) apply();
    else if (ds.impundo) undoImport(ds.impundo);
  });
  root.addEventListener('change', e => {
    if (S.view !== 'import') return;
    const x = e.target;
    if (x.matches('[data-impfile]')) readFile(x.files && x.files[0]);
    else if (x.matches('[data-impremove]')) { M.remove[x.dataset.impremove] = x.checked; L.redraw(); }
    else if (x.matches('[data-map]')) {
      const v = x.value.trim().toLowerCase(), f = M.fields.find(y => y.label.toLowerCase() === v);
      const i = x.dataset.map;
      if (!v || v === 'not used') { M.mapping[i] = ''; M.state[i] = 'unused'; }
      else if (f) {
        // One column a field (the note may collect several): the other column lets go.
        if (!f.multi) Object.keys(M.mapping).forEach(k => { if (k !== i && M.mapping[k] === f.id) { M.mapping[k] = ''; M.state[k] = 'unused'; } });
        M.mapping[i] = f.id; M.state[i] = 'matched';
      }
      L.redraw();
    }
  });

  // A file dropped anywhere on Lodging's page goes to Import (a CSV is the Form's responses).
  let over = 0;
  const hasFile = e => e.dataTransfer && Array.from(e.dataTransfer.types || []).indexOf('Files') > -1;
  window.addEventListener('dragenter', e => { if (!hasFile(e) || L.ro || !S.loaded) return; over++; root.classList.add('is-filedrop'); });
  window.addEventListener('dragleave', e => { if (!hasFile(e)) return; over = Math.max(0, over - 1); if (!over) root.classList.remove('is-filedrop'); });
  window.addEventListener('dragover', e => { if (hasFile(e) && !L.ro && S.loaded) e.preventDefault(); });
  window.addEventListener('drop', e => {
    if (!hasFile(e) || L.ro || !S.loaded) return;
    e.preventDefault(); over = 0; root.classList.remove('is-filedrop');
    const f = e.dataTransfer.files[0];
    if (!f) return;
    if (!/\.(csv|tsv|txt|xlsx|xls)$/i.test(f.name)) { L.toast('Not a spreadsheet · Import takes the Form’s responses as CSV'); return; }
    L.importFile(f);
  });
})();
