/*
 * packet.js — the information packet, made from the year's own data (Caleb: the data is made on the
 * site and the packet comes from it; paper stays for those without internet).
 *
 * The page is the paper itself, as /schedule/ is: the laid-out pages (scaled to fit on a laptop, two
 * thumbnails across on a phone, a tap opening one at full size), one Print button, "10 pages · Print
 * both sides", and With schedule. Reading it on screen is the Conference page's packet and the guide's
 * Help, not a third copy here. For the year's members each page has its parts beside it, each with
 * Edit (to the year page at that part) and the checks that are on that page.
 *
 * The paper is laid out here, page by page, in fixed Letter pages (as print.js lays out the sheet),
 * so the page numbers are known and the same in every browser, and the Contents can say where each
 * part is:
 *   1    the cover: the facts, what's open now, the QR code, the 911 line, the Contents with pages;
 *   2    Help and Care nearby (what someone grabs the packet for), then whole parts that fit;
 *   3–4  the one-sheet schedule, the same pages /schedule/ prints, starting on an odd page so it
 *        is one sheet printed both sides and can be pulled out;
 *   5–   the parts, the campus map with its places, the menus. Each page has a footer and its number.
 *
 * Parts written by the year's committees stay as written, with a light structure for paper: a line
 * starting "## " is a sub-heading, "- " a bullet, "> " a set-apart line (a theme or a verse). The site
 * adds the parts that come from its own rows (tournaments, the year's meetings, listening by phone)
 * and the lines that are true now (Register by …, Volunteer), so nothing is retyped.
 */
(function () {
  'use strict';
  const O = window.OGC, PR = window.OGC_PRINT, esc = O.esc;
  const W = window.OGC_WP || {}, P = W.print || {};
  const root = document.getElementById('pk-root');
  if (!root || P.state !== 'ok' || !PR) return;
  const q = new URLSearchParams(location.search);
  const asOf = O.parseAsOf(q.get('as-of'));
  const svg = d => '<svg class="wk-i" viewBox="0 0 24 24" aria-hidden="true"><path d="' + d + '" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  const I = {
    print: svg('M7 9V4h10v5M7 17H5a1.5 1.5 0 0 1-1.5-1.5v-5A1.5 1.5 0 0 1 5 9h14a1.5 1.5 0 0 1 1.5 1.5v5A1.5 1.5 0 0 1 19 17h-2M7 14h10v6H7z'),
    cal: svg('M4 6.5h16v13H4zM4 10h16M8 4v4M16 4v4'),
    pin: svg('M12 21s-6.5-6.2-6.5-11.2a6.5 6.5 0 0 1 13 0C18.5 14.8 12 21 12 21ZM12 7.5a2.3 2.3 0 1 0 0 4.6 2.3 2.3 0 0 0 0-4.6Z'),
    people: svg('M8.5 11a3 3 0 1 0 0-6 3 3 0 0 0 0 6ZM3 19.5c.6-3 2.8-5 5.5-5s4.9 2 5.5 5M16 11a2.6 2.6 0 1 0 0-5.2M17.5 14.6c1.8.6 3 2.4 3.5 4.9'),
    hand: svg('M7 11.5V6.8a1.4 1.4 0 0 1 2.8 0v4M9.8 10.5V5.4a1.4 1.4 0 0 1 2.8 0v5M12.6 10.5V6.2a1.4 1.4 0 0 1 2.8 0v5.3M15.4 11.5V8.6a1.4 1.4 0 0 1 2.8 0v5.2c0 3.6-2.5 6.7-6.2 6.7-2.4 0-4-1.1-5.3-3l-2.4-3.6a1.4 1.4 0 0 1 2.3-1.6L7 13.9'),
    phone: svg('M6.6 3.5h2.6l1.5 4-2 1.3a11 11 0 0 0 6.5 6.5l1.3-2 4 1.5v2.6a2 2 0 0 1-2.2 2A16.5 16.5 0 0 1 4.6 5.7a2 2 0 0 1 2-2.2Z'),
    down: svg('M6 9l6 6 6-6')
  };

  let c;
  try {
    c = PR.prepare(P, { today: asOf ? asOf.date : '' });
  } catch (e) {
    root.removeAttribute('aria-busy');
    root.innerHTML = '<div class="wk-wrap"><p class="pp-wait__h">Couldn’t draw the packet</p></div>';
    console.error(e);
    return;
  }
  const m = c.m, s = c.s, F = P.files || {}, today = c.today;
  const short = P.urls.short;
  const updated = PR.updatedLabel(P.updated && P.updated.packet, s.revised, P.posted && P.posted.packet);
  const sheetOk = !!((F.schedule || []).length && (P.draft || P.posted.schedule));
  const tick = '<svg class="wk-i" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>';

  /* ------------------------------------------------------------- words */

  // Times read as the sheet writes them: "3:00 PM" is "3 PM", "9 PM–11 PM" is "9–11 PM". A time range
  // keeps together on its line (never breaks before PM or at the dash).
  const tidyTimes = t => String(t == null ? '' : t)
    .replace(/\b(\d{1,2}):00(\s?(?:AM|PM))/g, '$1$2')
    .replace(/\b(\d{1,2}(?::\d{2})?)\s?(AM|PM)\s?([–-])\s?(\d{1,2}(?::\d{2})?)\s?(AM|PM)\b/g, (w, a, x, d, b, y) => x === y && +a.split(':')[0] !== 12 && +b.split(':')[0] !== 12 ? a + '–' + b + ' ' + y : a + ' ' + x + '–' + b + ' ' + y);
  const keep = t => esc(tidyTimes(t))
    .replace(/(\d{1,2}(?::\d{2})?(?:\s?(?:AM|PM|a\.m\.|p\.m\.))?\s?[–-]\s?\d{1,2}(?::\d{2})?\s?(?:AM|PM|a\.m\.|p\.m\.))/g, '<span class="pr-nw">$1</span>')
    .replace(/(\d) (AM|PM|a\.m\.|p\.m\.)/g, '$1 $2');
  // A number to call: a tap on a phone, bold on paper.
  const tel = (n, pin) => n ? '<a class="pk-tel" href="' + esc(O.telHref(n, pin)) + '">' + esc(n) + '</a>' : '';
  const shortUrl = u => String(u || '').replace(/^https?:\/\/(www\.)?/, '').replace(/\?.*$/, '').replace(/\/$/, '');
  const T = (mm, o) => PR.T(mm, o);
  const dayShort = d => O.fmtDate(d.date, 'weekdayShort');

  // A part's paragraphs, as written; "## ", "- " and "> " give it shape on paper. On paper, a line that
  // says to call someone but gives no number points to Help's page ("Call the golf-cart line").
  const callNoNumber = t => /\b(call|phone|ring)\b/i.test(t) && !/\d{3}[\s.-]\d{4}|\b911\b/.test(t);
  function prose(paras, paper) {
    let h = '', list = false;
    paras.forEach(p => {
      let t = String(p);
      const xref = paper && callNoNumber(t) ? ' <span class="pkp-xref-in" data-xref="help">(Help, page <span>00</span>)</span>' : '';
      if (/^-\s+/.test(t)) { if (!list) { h += '<ul class="pk-ul">'; list = true; } h += '<li>' + keep(t.replace(/^-\s+/, '')) + xref + '</li>'; return; }
      if (list) { h += '</ul>'; list = false; }
      if (/^##\s+/.test(t)) h += '<h3 class="pk-h3">' + keep(t.replace(/^##\s+/, '')) + '</h3>';
      else if (/^>\s+/.test(t)) h += '<blockquote class="pk-quote">' + keep(t.replace(/^>\s+/, '')) + '</blockquote>';
      else h += '<p>' + keep(t) + xref + '</p>';
    });
    return h + (list ? '</ul>' : '');
  }

  // A place, named the same way everywhere: its code and its short name ("Y/LA Luckey Arena"). On
  // screen it opens the guide's map at that place.
  const shortName = (p, b) => p.name.replace(/\s*\(([^)]*)\)\s*$/, (w, inner) => inner.toLowerCase().indexOf((b.split(/\s+/)[0] || '').toLowerCase().slice(0, 3)) > -1 ? '' : w);
  function placeRef(p, paper) {
    if (!p) return '';
    const label = '<b class="pk-code">' + esc(p.code) + '</b> ' + esc(shortName(p, p.building || p.name));
    return paper || p.unknown ? '<span class="pk-place">' + label + '</span>' : '<a class="pk-place" href="' + esc(P.urls.places + '&to=' + encodeURIComponent(p.code)) + '">' + label + '</a>';
  }

  /* ------------------------------------------------------------- the parts the site makes */

  const scheduleItem = title => {
    for (const d of m.days) { const it = d.items.find(x => O.slug(x.title) === O.slug(title)); if (it) return { d, it }; }
    return null;
  };

  // Tournaments from tournaments.csv and the schedule: size, when sign-ups close, when and where.
  // When the Youngfolks run them their own way, the times and places only.
  function tournaments(paper) {
    const rows = (F.tournaments || []).filter(t => t.name && !/^#/.test(t.id || ''));
    if (!rows.length) return '';
    const own = /^yes$/i.test(s.tournaments_held || '') || /^no$/i.test(s.tournaments_online || '');
    const body = rows.map(t => {
      const hit = scheduleItem(t.schedule_title || t.name);
      const when = hit ? dayShort(hit.d) + ' ' + (hit.it.start != null ? PR.cap(T(hit.it.start)) : hit.it.startText) : '';
      const size = +t.max === 1 ? 'One player' : t.min && t.max && t.min !== t.max ? 'Teams of ' + t.min + '–' + t.max : t.max ? 'Teams of ' + t.max : '';
      const closes = t.closes_day ? 'Sign-ups close ' + t.closes_day.slice(0, 3) + ' ' + (T(O.parseTime(t.closes_time)) || t.closes_time || '') : '';
      return '<tr><th scope="row">' + esc(t.name) + '</th><td>' + keep(when) + (hit && hit.it.place ? (when ? ' · ' : '') + placeRef(hit.it.place, paper) : '') +
        (own ? '' : '<small>' + esc([size, closes].filter(Boolean).join(' · ')) + '</small>') + (t.note && !own ? '<small>' + esc(t.note) + '</small>' : '') + '</td></tr>';
    }).join('');
    return '<h3 class="pk-h3">Tournaments</h3>' + (own ? '<p>With the Youngfolks committee.</p>' : '') + '<table class="pk-table pk-table--tight"><tbody>' + body + '</tbody></table>';
  }

  // The year's meetings and teaching (the part that's new each year): when, where, what it is.
  function meetings(paper) {
    const rows = [];
    m.days.forEach(d => d.items.forEach(it => {
      if ((it.kind === 'meeting' || it.kind === 'teaching') && (it.audience === 'conference' || it.audience === 'all')) rows.push({ d, it });
    }));
    if (!rows.length) return '';
    return '<table class="pk-table"><tbody>' + rows.map(x => '<tr><th scope="row">' + esc(x.it.title) + '</th><td>' +
      keep(dayShort(x.d) + ' ' + PR.whole(x.it)) + (x.it.place ? ' · ' + placeRef(x.it.place, paper) : '') +
      (x.it.note ? '<small>' + keep(x.it.note) + '</small>' : '') + '</td></tr>').join('') + '</tbody></table>';
  }

  // For those listening at home: the services on the line, by day, with the number and PIN.
  function listening() {
    if (!s.call_in_number) return '';
    const days = m.days.map(d => ({ d, its: d.items.filter(it => it.callIn) })).filter(x => x.its.length);
    if (!days.length) return '';
    const z = PR.zones(c);
    return '<p>Call ' + tel(s.call_in_number, s.call_in_pin) + (s.call_in_pin ? ', PIN <b>' + esc(s.call_in_pin) + '</b>' : '') + '. Times are ' + esc(c.tzName) + (z ? ' (' + esc(z) + ' hours)' : '') + '.</p>' +
      '<table class="pk-table pk-table--tight"><tbody>' + days.map(x => '<tr><th scope="row">' + esc(O.fmtDate(x.d.date, 'weekday')) + '</th><td>' +
        x.its.map(it => keep(PR.cap(T(it.start)) + ' ' + it.title)).join(' · ') + '</td></tr>').join('') + '</tbody></table>';
  }

  // Help: the same cards as the guide. The Lodging Desk's hours come from the schedule's desk rows;
  // a card that only repeats a place in Care nearby is left to Care nearby.
  // Hours read one way, typed or made: "Fri 5–11 PM · Sat–Tue 8 AM–11 PM", "noon" except to start.
  const hoursText = t => String(t || '').replace(/\s*;\s*/g, ' · ').replace(/\b(Noon|Midnight)\b/g, (w, x, i) => i === 0 ? w : w.toLowerCase());
  function deskHours(kind) {
    return hoursText(m.days.filter(d => d.desk.some(x => x.kind === kind)).map(d => dayShort(d) + ' ' + d.desk.filter(x => x.kind === kind).map(x => PR.whole(x)).join(', ')).join(' · '));
  }
  function helpRows() {
    const near = new Set((m.nearby || []).map(n => String(n.phone || '').replace(/\D/g, '')).filter(Boolean));
    return m.help.filter(h => h.kind !== 'emergency' && !(h.phone && near.has(h.phone.replace(/\D/g, ''))));
  }
  function help() {
    const rows = helpRows();
    if (!rows.length && !(P.draft && heldOf('help'))) return '';
    // A card left to Care nearby (a doctor off campus) says where it went, with its page; a member's
    // draft says what the public's paper leaves out.
    const care = (m.nearby || []).length ? '<p class="pkp-xref" data-xref="nearby" data-notsame="help">Doctors, urgent care, pharmacies · Care nearby, page <span>00</span></p>' : '';
    const held = P.draft && heldOf('help') ? '<p class="pk-held"><i>◆</i> ' + esc(heldOf('help').what) + ' · Not confirmed</p>' : '';
    return '<p class="pk-911">In an emergency, call <b>911</b> first.</p>' + held + (rows.length ? '<table class="pk-table"><tbody>' + rows.map(h => {
      // The desk's own card: when it's open, and when this number is on call (never the open hours
      // under "when it's closed, call", which read as the phone's hours).
      const open = h.hours === 'desk' && deskHours('open'), onCall = h.hours === 'desk' && deskHours('on_call');
      const hours = h.hours === 'desk' ? [open ? 'Desk open: ' + open : '', onCall ? 'On call: ' + onCall : ''].filter(Boolean) : h.hours ? [hoursText(h.hours)] : [];
      const link = !h.phone && h.link && /^https?:/.test(h.link) ? '<small><a href="' + esc(h.link) + '" rel="noopener">' + esc(h.action || 'Open') + '</a><span class="pk-paper"> · ' + esc(shortUrl(h.link)) + '</span></small>' : '';
      return '<tr><th scope="row">' + esc(h.need) + '</th><td>' + keep(h.text) + hours.map(x => '<small>' + keep(x) + '</small>').join('') + link + '</td><td class="pk-num">' + tel(h.phone, h.pin) + '</td></tr>';
    }).join('') + '</tbody></table>' : '') + care;
  }
  const heldOf = k => (P.held || []).find(h => h.key === k);

  function nearby() {
    const held = P.draft && heldOf('nearby') ? '<p class="pk-held"><i>◆</i> ' + esc(heldOf('nearby').what) + ' · Not confirmed</p>' : '';
    if (!(m.nearby || []).length) return held;
    return held + '<table class="pk-table"><tbody>' + m.nearby.map(n => '<tr><th scope="row">' + esc(n.kind) + '</th><td>' + esc(n.name) +
      '<small>' + keep([n.address, n.hours, n.distance].filter(Boolean).join(' · ')) + '</small></td><td class="pk-num">' + tel(n.phone) + '</td></tr>').join('') + '</tbody></table>';
  }

  // The campus map (the map area's packet map: codes on the buildings, the halls, a key). On screen
  // it opens the guide's own map.
  let mapHtml = null;
  function campus() {
    if (mapHtml != null) return mapHtml;
    mapHtml = '';
    if (!O.map || !(F.campus || []).length) return mapHtml;
    const cm = O.map.campus(F.campus);
    if (!cm.items.length) return mapHtml;
    const named = new Set();
    Object.values(m.places).forEach(p => { const b = O.map.buildingFor(cm, p, m.places); if (b) named.add(b.name); });
    // Which halls the Conference uses is a sample until Lodging confirms them (a hall's rows confirmed,
    // or the campus's own "stay = yes"): only confirmed ones are drawn as halls. Any other hall is drawn
    // as any other building, or, when a schedule row meets there (Sunrise service, the evening social),
    // as a Conference building, so no reader takes it for where people sleep.
    const sure = new Set();
    (F.rooms || []).forEach(r => { if (r.hall && !/^#/.test(r.hall) && r.confirmed) { named.add(r.hall); sure.add(r.hall); } });
    cm.items.forEach(i => { if (i.kind === 'hall' && !i.stayOk && !sure.has(i.name)) i.kind = 'other'; });
    // Fitted to where Conference happens; a building far from the rest gets an edge arrow instead
    // of shrinking the whole map.
    const its = Array.from(named).map(n => cm.items.find(i => i.name === n && i.lab)).filter(Boolean);
    const med = xs => xs.slice().sort((a, b) => a - b)[Math.floor(xs.length / 2)] || 0;
    const mx = med(its.map(i => i.cx)), my = med(its.map(i => i.cy)), dist = i => Math.hypot(i.cx - mx, i.cy - my), md = med(its.map(dist));
    const fit = its.filter(i => dist(i) <= Math.max(md * 2.5, 180)).map(i => i.name);
    const map = O.map.packetMap ? O.map.packetMap(cm, { places: m.places, named: Array.from(named), fit })
      : O.map.campusSvg(cm, { named: Array.from(named), fit, labelPx: 11, widthPx: 740, title: 'Campus map' });
    // On paper, a hall the Conference doesn't use (or hasn't confirmed) is drawn as any other building:
    // no name, no tint, no "Halls" in the key, so a sample hall is never printed as the real one.
    const t = document.createElement('template');
    t.innerHTML = map;
    t.content.querySelectorAll('text.pl-lab.is-hall:not(.is-used)').forEach(e => e.remove());
    t.content.querySelectorAll('path.pl-bld.is-hall:not(.is-used)').forEach(e => { e.classList.remove('is-hall'); e.classList.add('is-other'); });
    if (!t.content.querySelector('.pl-bld.is-hall')) t.content.querySelectorAll('.pl-key i.is-hall').forEach(e => e.closest('li').remove());
    // A building off the map's edge: how far it is, as the crow flies from the middle of the Conference
    // and marked as an estimate ("Troyer · about 0.7 mi"), never a walking time the paths may not bear out.
    t.content.querySelectorAll('g.pl-far').forEach(g => {
      const nm = g.querySelector('title'), lab = g.querySelector('text');
      const it = nm && cm.items.find(i => i.name === nm.textContent && i.lab);
      if (!it || !lab) return;
      const mi = Math.hypot(it.cx - mx, it.cy - my) / 1609.34;
      lab.textContent = lab.textContent.replace(/\s·\s.*$/, '') + ' · ' + (mi < .2 ? 'about ' + Math.round(mi * 5280 / 50) * 50 + ' ft' : 'about ' + mi.toFixed(1) + ' mi');
    });
    const div = document.createElement('div');
    div.appendChild(t.content);
    return (mapHtml = '<a class="pk-map" href="' + esc(P.urls.places) + '" title="Open the map in the Conference app">' + div.innerHTML + '</a>');
  }

  // Places by building: the building's own code in its heading ("B Barnes Student Center"), then its
  // rooms, one a line, the codes in one column.
  function placesList(paper) {
    const all = Object.values(m.places), solo = p => p.code.indexOf('/') < 0;
    const groups = new Map();
    all.forEach(p => {
      const b = p.building || p.name;
      if (!groups.has(b)) groups.set(b, []);
      groups.get(b).push(p);
    });
    if (!groups.size) return '';
    const topOf = b => all.find(p => solo(p) && p.name === b) || all.find(p => solo(p) && p.building === b && all.some(x => x.code.indexOf(p.code + '/') === 0)) || null;
    const ref = (p, b) => '<b class="pk-code">' + esc(p.code) + '</b><span>' + esc(shortName(p, b)) + '</span>';
    const to = p => esc(P.urls.places + '&to=' + encodeURIComponent(p.code));
    return '<div class="pk-places">' + Array.from(groups.entries()).map(([b, ps]) => {
      const top = topOf(b), rest = ps.filter(p => p !== top);
      const name = top ? top.name : b;
      const head = top ? '<b class="pk-code">' + esc(top.code) + '</b><span>' + esc(name) + '</span>' : '<span>' + esc(name) + '</span>';
      return '<div class="pk-pg"><h3 class="pk-h3 pk-pg__h">' + (top && !paper ? '<a href="' + to(top) + '">' + head + '</a>' : head) + '</h3>' +
        (rest.length ? '<ul>' + rest.map(p => '<li>' + (paper ? '<span class="pk-pl">' + ref(p, b) + '</span>' : '<a class="pk-pl" href="' + to(p) + '">' + ref(p, b) + '</a>') + '</li>').join('') + '</ul>' : '') + '</div>';
    }).join('') + '</div>';
  }

  // Menus: each meal with its time and place from the schedule. On screen they fold by day (the day
  // being lived open during the week); on paper they're all there, packed in columns.
  function menus(paper) {
    const days = m.days.map(d => ({ d, meals: d.items.filter(it => it.menu && it.menu.length) })).filter(x => x.meals.length);
    if (!days.length) return '';
    const meal = (d, it, withDay) => '<div class="pk-meal"><h3>' + esc(withDay ? O.fmtDate(d.date, 'weekday') + ' ' + it.title.toLowerCase() : it.title) +
      ' <span>' + keep(PR.whole(it)) + (it.place ? ' · ' + esc(it.place.code) : '') + '</span></h3>' +
      it.menu.map(mm => '<p>' + (mm.station ? '<b>' + esc(mm.station) + ':</b> ' : '') + mm.items.map(esc).join(', ') + '</p>').join('') + '</div>';
    if (paper) return '<div class="pk-menus">' + days.map(x => x.meals.map(it => meal(x.d, it, true)).join('')).join('') + '</div>';
    const inWeek = today && m.dayByDate(today);
    return days.map(x => '<details class="pk-mday"' + (inWeek && inWeek.key === x.d.key ? ' open' : '') + '><summary>' + esc(O.fmtDate(x.d.date, 'weekday')) +
      ' <span>' + esc(O.fmtDate(x.d.date, 'md')) + '</span>' + I.down + '</summary><div class="pk-menus">' + x.meals.map(it => meal(x.d, it, false)).join('') + '</div></details>').join('');
  }

  /* ------------------------------------------------------------- the parts, in order */

  // Each part once, for the screen or for paper: {key, title, html, part (the Packet editor's
  // section, for a member's Edit), front (printed on page 2)}.
  function parts(paper) {
    const out = [];
    const add = (key, title, html, part, front) => { if (html) out.push({ key, title, html, part: part || '', front: !!front }); };
    // One order on screen and on paper: Help and Care nearby first (what someone opens the packet
    // for during the week), then the parts.
    add('help', 'Help', help(), 'help', true);
    const guides = Object.keys(m.guides).map(k => m.guides[k]).filter(g => g.title && g.paras.length);
    // Getting around (the golf-cart ride, parking, campus alerts) is help too: it follows Help on page 2.
    const near = g => g.id === 'getting_around';
    guides.filter(near).forEach(g => add(g.id, g.title, prose(g.paras, paper), g.id, true));
    add('nearby', 'Care nearby', nearby(), '', true);
    guides.filter(g => !near(g)).forEach(g => {
      let h = prose(g.paras, paper) + (g.id === 'youngfolks' ? tournaments(paper) : '');
      // The part about meals says where its menus are, only once there are menus: the page on paper
      // (filled in once the pages are laid out), a link on screen.
      if (g.id === 'meals' && menus(true)) h += paper ? '<p class="pkp-xref" data-xref="menus">Menus · page <span>00</span></p>' : '<p class="pk-xref"><a href="#pk-menus">Menus</a></p>';
      add(g.id, g.title, h, g.id);
    });
    if (!guides.some(g => g.id === 'youngfolks')) add('tournaments', 'Tournaments', tournaments(paper));
    add('meetings', 'Meetings and teaching', meetings(paper));
    add('listening', 'Listening by phone', listening());
    add('map', 'Campus map', campus());
    add('places', 'Places', placesList(paper));
    add('menus', 'Menus', menus(paper), 'menus');
    return out;
  }

  /* ------------------------------------------------------------- the page */

  // What's open now: registration while it's open, volunteering while sign-ups are. On screen a link
  // says what it is; on paper, the short address to type.
  function openNow(paper) {
    const out = [];
    const regOpen = s.registration_opens && s.registration_opens <= today && (!s.registration_closes || today <= s.registration_closes) && !s.registration_closed;
    const by = s.registration_closes ? ' by ' + esc(O.fmtDate(s.registration_closes, 'md')) : '';
    if (regOpen) out.push('<li>' + I.cal + '<span>' + (paper ? 'Register' + by + ' · <b>' + esc(short + '/register') + '</b>' : '<a href="' + esc(P.urls.register) + '">Register</a>' + by) + '</span></li>');
    const volOpen = s.signups_posted && s.signups_posted !== '9999-12-31' && s.signups_posted <= today && today < c.conf.start && !s.signups_closed;
    if (volOpen) out.push('<li>' + I.hand + '<span>' + (paper ? 'Volunteer · <b>' + esc(short + '/volunteer') + '</b>' : '<a href="' + esc(P.urls.volunteer) + '">Volunteer</a>') + '</span></li>');
    return out.join('');
  }

  function facts(paper) {
    return '<ul class="wk-facts pk-facts">' +
      '<li>' + I.cal + '<span>' + esc(c.span) + '</span></li>' +
      (s.venue ? '<li>' + I.pin + '<span>' + esc(s.venue) + (s.address ? '<small>' + esc(s.address) + '</small>' : '') + '</span></li>' : '') +
      (s.hosts ? '<li>' + I.people + '<span>Hosted by the ' + esc(s.hosts) + '</span></li>' : '') +
      (s.call_in_number ? '<li>' + I.phone + '<span>Call-in line · ' + tel(s.call_in_number, s.call_in_pin) + (s.call_in_pin ? ' · PIN ' + esc(s.call_in_pin) : '') + '</span></li>'
        : P.draft && heldOf('callin') ? '<li>' + I.phone + '<span class="pk-held"><i>◆</i> Call-in line · Not confirmed</span></li>' : '') +
      openNow(paper) + '</ul>';
  }

  /* ------------------------------------------------------------- the paper, page by page */

  const node = h => { const t = document.createElement('template'); t.innerHTML = h.trim(); return t.content.firstElementChild; };
  const footLeft = () => [P.year + ' Annual Conference', 'Information packet', updated, P.draft ? 'Draft · Not posted' : ''].filter(Boolean).join(' · ');

  function coverHtml() {
    // The QR opens this packet on screen, as its label says (in the prototype, at its ogbbc.org address:
    // urls.qr, core-dev.php).
    const qr = PR.qr((P.urls.qr && P.urls.qr.packet) || P.urls.packet || P.urls.conference);
    return '<section class="pkp-page pkp-cover' + (P.draft ? ' is-draft' : '') + '"><div class="pkp-in">' +
      '<p class="pkp-church">Old German Baptist Brethren Church, New Conference</p>' +
      '<p class="pkp-kicker">' + esc(P.year) + ' Annual Conference</p><p class="pkp-title" role="heading" aria-level="2">Information packet</p>' +
      (P.draft ? '<p class="pkp-draft">Draft · Not posted</p>' : '') +
      facts(true) +
      c.notices.map(n => '<p class="pkp-notice">' + keep(n.text) + '</p>').join('') +
      // The printed address opens what the label says (the packet); it keeps no year, so the label does.
      (qr ? '<div class="pkp-qr">' + qr + '<p>Latest ' + esc(P.year) + ' packet<br><b class="pr-nw">' + esc(shortUrl(P.urls.packetShort || (short + '/packet'))) + '</b>' + (updated ? '<br>' + esc(updated) : '') + '</p></div>' : '') +
      '<p class="pkp-911"><b>Emergency: call 911 first.</b><span data-helpat></span></p>' +
      '<h2 class="pkp-k">Contents</h2><ol class="pkp-contents"></ol>' +
      (s.print_required ? '<p class="pkp-req">' + esc(s.print_required) + '</p>' : '') +
      '</div></section>';
  }

  // Lay the packet out. → {pages, at: {part key → first page}}
  function layout(box, withSheet) {
    box.textContent = '';
    const list = parts(true);
    const pages = [];
    let cur = null;
    box.appendChild(node(coverHtml()));
    pages.push({ kind: 'cover', el: box.lastElementChild });
    const newPage = () => {
      const el = node('<section class="pkp-page' + (P.draft ? ' is-draft' : '') + '"><div class="pkp-in"><div class="pkp-body"></div><footer class="pkp-foot"><p class="pkp-foot__l">&nbsp;</p><p class="pkp-foot__r">&nbsp;</p></footer></div></section>');
      box.appendChild(el);
      cur = { kind: 'body', el, body: el.querySelector('.pkp-body') };
      pages.push(cur);
      return cur;
    };
    const over = () => cur.body.scrollHeight > cur.body.clientHeight + 1;
    // Where each part starts (page), and in what order the parts went down, for the Contents.
    const at = {}, pos = {};
    let seq = 0;
    const mark = p => { at[p.key] = pages.length; if (pos[p.key] == null) pos[p.key] = ++seq; };
    const shell = (p, cont) => node('<section class="pk-sec pkp-sec' + (cont ? ' is-cont' : '') + '" data-key="' + esc(p.key) + '">' + (cont ? '<p class="pkp-cont">' + esc(p.title) + ', continued</p>' : '') + '</section>');

    // A list's pieces can go to the next page: a table's rows, a list's items, the menus' meals and
    // the places' buildings (in columns). Anything else moves whole.
    function splitter(el) {
      if (el.tagName === 'TABLE' && el.tBodies[0]) return { items: Array.from(el.tBodies[0].rows), make: () => { const t = el.cloneNode(false); Array.from(el.children).forEach(ch => { if (ch.tagName !== 'TBODY') t.appendChild(ch.cloneNode(true)); }); const tb = el.tBodies[0].cloneNode(false); t.appendChild(tb); return { wrap: t, holder: tb }; } };
      if (el.tagName === 'UL' || el.tagName === 'OL') return { items: Array.from(el.children), make: () => { const u = el.cloneNode(false); return { wrap: u, holder: u }; } };
      if (el.classList.contains('pk-menus') || el.classList.contains('pk-places')) return { cols: true, items: Array.from(el.children), make: () => { const d = el.cloneNode(false); return { wrap: d, holder: d }; } };
      return null;
    }
    // Columns fill down to the page's foot, then across; the last piece is balanced.
    const sizeCols = pc => { pc.holder.style.height = Math.max(0, cur.body.getBoundingClientRect().bottom - pc.holder.getBoundingClientRect().top - 1) + 'px'; pc.holder.style.columnFill = 'auto'; };
    const balance = pc => { pc.holder.style.height = ''; pc.holder.style.columnFill = 'balance'; };
    const overPiece = pc => over() || (pc.cols && pc.holder.scrollWidth > pc.holder.clientWidth + 1);

    function place(p) {
      const whole = node(shell(p).outerHTML);
      whole.innerHTML = '<h2>' + esc(p.title) + '</h2>' + p.html;
      cur.body.appendChild(whole);
      if (!over()) { mark(p); return; }
      // A short part (under half a page) starts on the next page, unless a quarter of this page or
      // more is still free: then it runs on, split between paragraphs (never a page left mostly empty).
      const h = whole.offsetHeight, top = whole.offsetTop - cur.body.offsetTop;
      const free = cur.body.clientHeight - top, page = cur.body.clientHeight;
      whole.remove();
      if (cur.body.childElementCount && h <= page * 0.5 && free < page * 0.25) {
        newPage();
        cur.body.appendChild(whole);
        if (!over()) { mark(p); return; }
        whole.remove();
      }
      flowParts(p, whole);
    }

    function flowParts(p, whole) {
      const kids = Array.from(whole.children);
      const head = kids.shift();
      let box2 = shell(p), started = false, fresh = false;
      box2.appendChild(head);
      cur.body.appendChild(box2);
      mark(p);
      // The heading goes to the next page with whatever has to follow it there.
      const restart = () => {
        box2.remove();
        newPage();
        box2 = shell(p);
        box2.appendChild(head);
        cur.body.appendChild(box2);
        mark(p);
        fresh = true;
      };
      const carry = () => { newPage(); box2 = shell(p, true); cur.body.appendChild(box2); fresh = true; };
      for (let k = 0; k < kids.length; k++) {
        const kid = kids[k];
        box2.appendChild(kid);
        if (!over()) { started = true; fresh = false; continue; }
        kid.remove();
        const sp = splitter(kid);
        if (!sp) {
          // A sub-heading never stays at the foot of a page without what it heads.
          const prev = box2.lastElementChild;
          const takeH3 = prev && prev !== head && prev.matches('h3');
          if (takeH3) prev.remove();
          if (!started || box2.childElementCount <= 1) restart(); else carry();
          if (takeH3) box2.appendChild(prev);
          box2.appendChild(kid);
          started = true;
          fresh = false;
          continue;
        }
        let pc = Object.assign({ cols: !!sp.cols }, sp.make());
        box2.appendChild(pc.wrap);
        if (pc.cols) sizeCols(pc);
        let here = 0;
        for (let i = 0; i < sp.items.length; i++) {
          pc.holder.appendChild(sp.items[i]);
          // On a fresh page a piece taller than the page stays (and is reported), rather than looping.
          if (!overPiece(pc) || (fresh && !here)) { here++; fresh = false; continue; }
          sp.items[i].remove();
          if (here < 2 && !started) {
            // Keep the heading with the first two: everything so far starts on the next page.
            for (let j = 0; j < here; j++) pc.holder.lastElementChild.remove();
            i -= here + 1;
            restart();
            pc = Object.assign({ cols: !!sp.cols }, sp.make());
            box2.appendChild(pc.wrap);
            if (pc.cols) sizeCols(pc);
            here = 0;
            started = true;
            continue;
          }
          // Never leave one row alone on the next page.
          if (sp.items.length - i === 1 && here > 2) { pc.holder.lastElementChild.remove(); i--; }
          if (!here) pc.wrap.remove();
          carry();
          pc = Object.assign({ cols: !!sp.cols }, sp.make());
          box2.appendChild(pc.wrap);
          if (pc.cols) sizeCols(pc);
          here = 0;
          i--;
          started = true;
        }
        if (pc.cols) balance(pc);
        started = true;
      }
    }

    // Page 2: Help, then the other front parts only if each fits whole there (Care nearby otherwise
    // keeps its place among the parts), so the sheet can still start on page 3.
    const front = list.filter(p => p.front);
    const fits = p => {
      const probe = node(shell(p).outerHTML);
      probe.innerHTML = '<h2>' + esc(p.title) + '</h2>' + p.html;
      cur.body.appendChild(probe);
      const ok = !over();
      probe.remove();
      return ok;
    };
    newPage();
    const onTwo = new Set();
    front.forEach((p, i) => { if (!i || fits(p)) { place(p); onTwo.add(p.key); } });
    const rest = list.filter(p => !onTwo.has(p.key));
    // The sheet starts on an odd page, so it's one sheet when printed both sides: whole parts fill
    // the rest of an even page, and it goes in where one doesn't fit.
    let sheetAt = 0;
    const putSheet = () => {
      if (!withSheet || sheetAt) return;
      if (pages.length % 2 === 1) newPage();          // an odd page last: a page of parts first
      sheetAt = pages.length + 1;
      pages.push({ kind: 'sheet' }, { kind: 'sheet' });
      cur = null;
    };
    rest.forEach(p => {
      if (withSheet && !sheetAt && cur && pages.length % 2 === 0 && !fits(p)) putSheet();
      if (!cur) newPage();
      place(p);
    });
    putSheet();
    return { pages, at, pos, sheetAt, list };
  }

  /* ------------------------------------------------------------- the page: the paper itself */

  const phone = matchMedia('(max-width: 767px)'), wide = matchMedia('(min-width: 1180px)'), printing = matchMedia('print');
  const here = () => location.pathname + location.search;
  // A member's Edit goes to the year page at the part, and its Back comes here (return=).
  const toYear = (u, hash) => u ? u + '&return=' + encodeURIComponent(here()) + (hash ? '#' + hash : '') : '';
  const U = P.urls || {};
  // Where each part is made, for a member: its editor, and for the parts the site makes from other
  // rows, where they come from.
  function editOf(p) {
    if (p.key === 'sheet') return { from: '', href: U.edit ? U.edit + '&return=' + encodeURIComponent(here()) : '', label: 'Edit schedule' };
    if (p.key === 'help') return { from: '', href: toYear(U.packetPart, 's-help'), label: 'Edit' };
    if (p.key === 'menus') return { from: '', href: toYear(U.packetPart, 's-menus'), label: 'Edit' };
    if (p.key === 'nearby') return { from: 'From the campus', href: toYear(U.conferencePart, 's-campus'), label: 'Edit' };
    if (p.key === 'map' || p.key === 'places') return { from: 'From the campus', href: toYear(U.conferencePart, 's-campus'), label: 'Edit' };
    if (p.key === 'meetings' || p.key === 'listening') return { from: 'From the schedule', href: U.edit ? U.edit + '&return=' + encodeURIComponent(here()) : '', label: 'Edit schedule' };
    if (p.key === 'tournaments') return { from: 'From Youngfolks', href: toYear(U.youngfolksPart), label: 'Edit' };
    return { from: '', href: p.part ? toYear(U.packetPart, 'pp-' + p.part) : '', label: 'Edit' };
  }
  // Every check for this packet, once, with the page it's on and the part it belongs to (at): the held
  // lines (what the public's paper leaves out), the server's checks, and the sheet's rows still marked
  // ◆. The To check card counts them and gives their pages; the details sit beside each page.
  function checkItems() {
    if (!P.member || !L) return [];
    const out = [];
    const add = (k, pg, at) => out.push(Object.assign({}, k, { pg: pg || 0, at: at || '' }));
    const sheet = L.sheetAt && withSheet && sheetOk;
    const partOf = k => L.list.find(x => k.where === x.title || k.where.indexOf(x.title + ' ·') === 0 || (x.key === 'help' && /^Help ·/.test(k.where)));
    (P.checks || []).forEach(k => {
      if (k.key === 'callin') return add(k, 1, 'cover');
      if (k.key === 'help' || k.key === 'nearby') return add(k, L.at[k.key], k.key);
      if (k.key === 'preteens') return;
      if (k.part === 'packet') {
        if (k.where === 'Cover') return add(k, 1, 'cover');
        const p = partOf(k);
        return add(k, p ? L.at[p.key] : 0, p ? p.key : '');
      }
      // The sheet's own checks, once (the campus line is already the cover's).
      if (k.part === 'schedule' && sheet && k.key !== 'campus_line') add(k, L.sheetAt, 'sheet');
    });
    if (sheet && P.draft && c.look.size) {
      let n = 0, first = null;
      m.days.forEach(d => d.allDay.concat(d.items).forEach(it => { if (c.look.has(PR.itemKey(it))) { n++; first = first || { it, d }; } }));
      const href = phone.matches && U.checkPhone ? U.checkPhone : U.edit && first ? U.edit.replace('edit=schedule', 'edit=' + encodeURIComponent('schedule:' + first.d.name)) + (first.it.row ? '&row=' + encodeURIComponent(first.it.row) : '') + '&check=1&return=' + encodeURIComponent(here()) : '';
      if (n) add({ what: n + (n === 1 ? ' row' : ' rows') + ' to check', where: 'Schedule', tip: 'Marked ◆ on the schedule’s pages', href }, L.sheetAt, 'sheet');
    }
    return out;
  }
  const flag = k => '<p class="pk-pn__f"><i aria-hidden="true">◆</i> ' + (k.href ? '<a href="' + esc(k.href) + '">' + esc(k.what) + '</a>' : esc(k.what)) + (k.tip ? '<small>' + esc(k.tip) + '</small>' : '') + '</p>';

  const sheetParam = () => q.get('sheet') !== '0';
  let withSheet = sheetParam();

  function render() {
    const fact = [c.span, s.venue].filter(Boolean).join(' · ');
    const links = [];
    // The packet to read on screen is the Conference page's own (its first part opens).
    const first = Object.keys(m.guides).map(k => m.guides[k]).find(g => g.title && g.paras.length);
    if (P.member && U.packetPart) links.push('<a class="pp-link" href="' + esc(toYear(U.packetPart)) + '">Edit packet</a>');
    // At its first part only while the Conference page shows the packet (not before it's posted, nor
    // after the Conference), else the Conference page alone.
    else links.push('<a class="pp-link" href="' + esc((U.packetOnScreen || U.conference) + (first && U.packetShown ? '#g-' + first.id : '')) + '">Conference page</a>');
    links.push('<a class="pp-link" href="' + esc(U.schedule) + '">Printable schedule</a>');
    root.innerHTML =
      '<header class="wk-hero pp-hero pk-hero"><div class="wk-wrap">' +
        '<p class="wk-kicker">' + esc(P.year) + ' Annual Conference</p><h1 class="pp-title">Information packet</h1>' +
        // From 768 px the cover just below says the dates and the place, so the line is for a phone only.
        (fact ? '<p class="pp-fact pp-fact--paper">' + esc(fact) + '</p>' : '') +
        (P.draft ? '<p class="pp-draft" title="Only the year’s committee sees this until the packet is published">Draft · Not posted</p>' : '') +
        '<div class="pp-tools">' +
          (sheetOk ? '<div class="pp-pick" role="group" aria-label="Printout"><button type="button" class="pp-pill" data-with aria-pressed="' + withSheet + '" title="The one-sheet schedule after the cover">' + tick + '<span>With schedule</span></button></div>' : '') +
          '<div class="pp-act"><button type="button" class="wk-btn" data-print title="Print, or save as a PDF">' + I.print + 'Print</button>' +
            '<p class="pp-status" id="pk-status" role="status" aria-live="polite"></p>' +
            '<p class="pp-links">' + links.join('') + '</p></div>' +
        '</div>' +
      '</div></header>' +
      '<section class="pp-paper" aria-label="The packet as it prints">' +
        (P.member ? '<div class="pp-checks" id="pk-checks" hidden></div>' : '') +
        '<div class="pk-sheets" id="pk-paper" aria-busy="true"></div>' +
        (P.member ? '<div class="pk-parts" id="pk-parts" hidden></div>' : '') +
      '</section>';
    root.removeAttribute('aria-busy');
    document.title = 'Information packet – ' + P.year + ' Annual Conference';
  }

  // Draw the paper: the sheet (print.js), the pages, then the numbers that depend on them.
  let paperDrawn = false, L = null;
  function drawPaper() {
    const box = document.getElementById('pk-paper');
    if (!box) return;
    box.setAttribute('aria-busy', 'true');
    const want = sheetOk && withSheet;
    let sheet = [];
    if (want) {
      const stage = document.createElement('div');
      stage.className = 'pk-stage';
      document.body.appendChild(stage);
      c.rowLinks = false;
      PR.draw(c, stage, PR.editions(c)[0]);
      sheet = Array.from(stage.querySelectorAll('.pr-page'));
      stage.remove();
    }
    // Laid out unscaled, page by page, in the box itself (the measure is the page's, not the screen's).
    box.classList.remove('is-thumbs');
    box.textContent = '';
    L = layout(box, want && sheet.length === 2);
    const n = L.pages.length;
    // The sheet's own pages go where the layout kept them.
    if (L.sheetAt && sheet.length) {
      const after = box.children[L.sheetAt - 2];
      sheet.slice().reverse().forEach(pg => after.after(pg));
    }
    const all = Array.from(box.children);
    // Footers and numbers: not on the cover. The sheet's pages keep their own footer, with the
    // packet's numbers ("3 of 10"), so the packet counts one way throughout.
    all.forEach((pg, k) => {
      if (pg.classList.contains('pkp-cover')) return;
      if (pg.classList.contains('pr-page')) {
        const r = pg.querySelector('.pr-foot__r');
        if (r) r.textContent = [(k + 1) + ' of ' + n, c.updated].filter(Boolean).join(' · ');
        return;
      }
      pg.querySelector('.pkp-foot__l').textContent = footLeft();
      pg.querySelector('.pkp-foot__r').textContent = (k + 1) + ' of ' + n;
    });
    // The Contents, with the page each part starts on, in the order the parts go down the pages.
    // Help or Care nearby with nothing confirmed yet (a member's draft) holds only its "Not confirmed"
    // line: not a part to list.
    const heldOnly = p => (p.key === 'help' && !helpRows().length) || (p.key === 'nearby' && !(m.nearby || []).length);
    const rows = L.list.filter(p => L.at[p.key] && !heldOnly(p)).map(p => [p.title, L.at[p.key], L.pos[p.key]]);
    if (L.sheetAt) rows.push(['Schedule', L.sheetAt, 0]);
    rows.sort((a, b) => a[1] - b[1] || a[2] - b[2]);
    const cont = box.querySelector('.pkp-contents');
    if (cont) cont.innerHTML = rows.map(r => '<li><span>' + esc(r[0]) + '</span><b>' + r[1] + '</b></li>').join('');
    const helpAt = box.querySelector('[data-helpat]');
    if (helpAt && L.at.help && helpRows().length) helpAt.textContent = ' Help’s numbers are on page ' + L.at.help + '.';
    // Page references; one to the page it's already on says nothing.
    box.querySelectorAll('[data-xref]').forEach(x => {
      const own = all.indexOf(x.closest('.pkp-page, .pr-page')) + 1;
      const pg = L.at[x.dataset.xref], same = pg === own || (x.dataset.notsame && L.at[x.dataset.notsame] === pg);
      if (pg && !same) x.querySelector('span').textContent = pg; else x.remove();
    });
    // Anything that still didn't fit a page is said, not cut off quietly.
    const cut = Array.from(box.querySelectorAll('.pkp-body')).some(b => b.scrollHeight > b.clientHeight + 1);
    const st = document.getElementById('pk-status');
    if (st) {
      st.textContent = n + ' pages · Print both sides' + (cut ? ' · Something didn’t fit' : '');
      st.classList.toggle('is-over', cut);
    }
    // The map's words are sized for the paper, once, while the pages are at their own size; then the
    // map leaves the map module's watch, which would size them for the scaled thumbnail (huge words,
    // on screen and in the PDF).
    if (O.map && O.map.fitText) box.querySelectorAll('svg.pl-fit').forEach(svg => { O.map.fitText(svg); svg.classList.remove('pl-fit'); svg.classList.add('pk-fit'); });
    // On screen: each page in its frame, scaled (two across on a phone, a tap opening one).
    // On a phone each thumbnail says what's on it ("Page 2 · Help").
    PR.wrapPages(box, '*', { tap: phone.matches, caption: pg => {
      if (pg.classList.contains('pkp-cover')) return 'Cover';
      if (pg.classList.contains('pr-page')) return 'Schedule';
      const sec = pg.querySelector('.pk-sec[data-key]'), p = sec && L.list.find(x => x.key === sec.dataset.key);
      return p ? p.title : '';
    } });
    box.classList.toggle('is-thumbs', phone.matches);
    // A thumbnail's links and words aren't reachable (19 × 5 px taps in the tab order): only its Open
    // button is. The full-size page (a copy) is.
    box.querySelectorAll('.pp-pw > *:first-child').forEach(pg => { pg.inert = phone.matches; if (phone.matches) pg.setAttribute('aria-hidden', 'true'); else pg.removeAttribute('aria-hidden'); });
    scale();
    box.removeAttribute('aria-busy');
    paperDrawn = true;
    pageParts();
    checks();
  }
  const scale = () => { const box = document.getElementById('pk-paper'); if (box) PR.scalePages(box, phone.matches ? 2 : 1); };

  // For a member: beside each page (a laptop) or after the pages (a phone), the parts on it, each
  // with where it's made and Edit, and the checks that are on it.
  function pageParts() {
    const box = document.getElementById('pk-paper'), list = document.getElementById('pk-parts');
    if (!P.member || !box || !L) return;
    const byPage = {}, items = checkItems();
    const put = (pg, x) => { (byPage[pg] = byPage[pg] || []).push(x); };
    L.list.forEach(p => { if (L.at[p.key]) put(L.at[p.key], p); });
    if (L.sheetAt) put(L.sheetAt, { key: 'sheet', title: 'Schedule' });
    const note = (pg) => {
      const parts = (byPage[pg] || []).map(p => {
        const e = editOf(p);
        return '<li><p class="pk-pn__t"><b>' + esc(p.title) + '</b>' + (e.from ? '<span>' + esc(e.from) + '</span>' : '') +
          (e.href ? '<a href="' + esc(e.href) + '" aria-label="' + esc(e.label + ' · ' + p.title) + '">' + esc(e.label) + '</a>' : '') + '</p>' +
          items.filter(k => k.pg === pg && k.at === p.key).map(flag).join('') + '</li>';
      });
      const cover = items.filter(k => k.pg === pg && k.at === 'cover');
      if (cover.length) parts.unshift('<li><p class="pk-pn__t"><b>Cover</b></p>' + cover.map(flag).join('') + '</li>');
      return parts.length ? '<div class="pk-pn" id="pk-pn-' + pg + '"><p class="pk-pn__k">Page ' + pg + '</p><ul>' + parts.join('') + '</ul></div>' : '';
    };
    const pws = Array.from(box.querySelectorAll('.pp-pw'));
    if (phone.matches) {
      list.hidden = false;
      list.innerHTML = '<h2 class="pp-checks__h">Parts</h2>' + pws.map((w, i) => note(i + 1)).join('');
      return;
    }
    list.hidden = true;
    list.innerHTML = '';
    // A row a page: the page, then its note (beside it when there's room, else under it).
    pws.forEach((w, i) => {
      const row = document.createElement('div');
      row.className = 'pk-prow';
      w.replaceWith(row);
      row.appendChild(w);
      row.insertAdjacentHTML('beforeend', note(i + 1) || '<div class="pk-pn is-empty"></div>');
    });
    box.classList.add('has-notes');
    scale();
  }

  // A member's To check: how many, and on which pages, each page a link to its note (beside the page
  // on a laptop, in Parts on a phone), where the details and Edit are. Only a check with no page of
  // its own is written out here.
  function checks() {
    const box = document.getElementById('pk-checks');
    if (!box || !L) return;
    const items = checkItems();
    box.hidden = !items.length;
    if (!items.length) { box.innerHTML = ''; return; }
    const pages = Array.from(new Set(items.map(k => k.pg).filter(Boolean))).sort((a, b) => a - b);
    const loose = items.filter(k => !k.pg);
    box.innerHTML = '<div class="pp-checks__card"><h2 class="pp-checks__h">To check</h2><p class="pp-checks__rows"><b>' + items.length + ' to check</b>' +
      (pages.length ? ' · ' + (pages.length > 1 ? 'Pages ' : 'Page ') + pages.map(pg => '<a class="pk-pgl" href="#pk-pn-' + pg + '" aria-label="' + esc('Page ' + pg) + '">' + pg + '</a>').join(' ') : '') + '</p>' +
      PR.checkList(loose) + '</div>';
  }

  root.addEventListener('click', e => {
    if (e.target.closest('[data-print]')) ready.then(() => { if (!paperDrawn) drawPaper(); window.print(); });
    const w = e.target.closest('[data-with]');
    if (w) {
      withSheet = !withSheet;
      w.setAttribute('aria-pressed', String(withSheet));
      // Kept in the address, so the choice can be shared and survives Reload.
      const u = new URL(location.href);
      if (withSheet) u.searchParams.delete('sheet'); else u.searchParams.set('sheet', '0');
      history.replaceState(null, '', u);
      drawPaper();
    }
    const o = e.target.closest('[data-open]');
    if (o) {
      const box = document.getElementById('pk-paper');
      PR.viewer(() => Array.from(box.querySelectorAll('.pp-pw > *:first-child')), +o.dataset.open, k => box.querySelectorAll('.pp-open')[k]);
    }
  });

  // Cmd+P, or Print before the fonts arrived: the paper is drawn first, whatever it takes.
  let title0 = document.title;
  addEventListener('beforeprint', () => { if (!paperDrawn) drawPaper(); title0 = document.title; document.title = P.year + ' Information packet'; });
  addEventListener('afterprint', () => { document.title = title0; });

  render();
  // The theme around the packet doesn't print: only the path down to the paper is kept.
  const paper = document.getElementById('pk-paper');
  document.body.classList.add('ogc-print-doc');
  paper.classList.add('pp-print-root');
  for (let n = paper.parentElement; n && n !== document.body; n = n.parentElement) n.classList.add('pp-path');

  const ready = PR.fontsReady().then(drawPaper);
  // A font that arrives late changes the measure: lay out again. Phone ↔ laptop: thumbnails or not.
  // (Printing changes the width the media queries see: the paper is never redrawn while it prints.)
  let t = 0;
  if (document.fonts) document.fonts.addEventListener('loadingdone', () => { if (paperDrawn && !printing.matches) { clearTimeout(t); t = setTimeout(drawPaper, 150); } });
  if (phone.addEventListener) phone.addEventListener('change', () => { if (paperDrawn && !printing.matches) drawPaper(); });
  addEventListener('resize', () => { if (printing.matches) return; clearTimeout(t); t = setTimeout(scale, 80); });
})();
