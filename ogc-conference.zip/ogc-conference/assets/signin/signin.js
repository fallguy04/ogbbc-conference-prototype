/*
 * signin.js — the sign-in page's small helps (signin area). The page works without it: every form
 * posts to the server and comes back. This adds:
 *   - errors at the field ("Enter an email", "Check the email") instead of the browser's bubble;
 *   - "Did you mean ruth@gmail.com?" for a common domain typed wrong (a built-in list, no service);
  *   - Send code reads "Sending" and can't be pressed twice;
  *   - the code signs in by itself at six digits ("482 913" with a space works too), through REST, so a
  *     wrong one keeps its digits in the field, selected, with "Code not valid" under it;
  *   - Resend waits for the server's own limits ("Resend in 0:45", then "Resend in 14 min");
 *   - a tab still waiting moves on when another tab of this browser signs in.
 */
(function () {
  'use strict';
  const root = document.getElementById('ogc-signin');
  if (!root) return;
  const W = window.OGC_WP || {};
  const state = root.dataset.state;
  const live = document.getElementById('si-live');
  const say = t => { if (live) { live.textContent = ''; setTimeout(() => { live.textContent = t; }, 30); } };
  const h1 = document.getElementById('si-h');

  // "Did you mean ruth@gmail.com?": the one list, in ogc-account.js (loaded on this page too).
  const suggestion = email => (window.OGC_AUTH && OGC_AUTH.suggest ? OGC_AUTH.suggest(email) : '');
  const clean = v => String(v || '').trim().replace(/\.+$/, '').replace(/\s+/g, '');
  const valid = v => /^[^\s@]+@[^\s@.]+(\.[^\s@.]+)+$/.test(v);

  /* ------------------------------------------------------------ the email form */

  const send = root.querySelector('form[data-si="send"]');
  if (send) {
    const inp = send.querySelector('#si-email'), err = send.querySelector('#si-email-err'), sug = send.querySelector('.si-suggest'), btn = send.querySelector('.si-go');
    let offered = '';
    const showErr = t => { err.textContent = t; err.hidden = !t; if (t) inp.setAttribute('aria-invalid', 'true'); else inp.removeAttribute('aria-invalid'); };
    const offer = () => {
      const s = suggestion(clean(inp.value));
      if (!s) { sug.hidden = true; sug.textContent = ''; return ''; }
      sug.textContent = 'Did you mean ';
      const b = document.createElement('button');
      b.type = 'button'; b.textContent = s;
      b.addEventListener('click', () => { inp.value = s; sug.hidden = true; offered = ''; inp.focus(); say('Changed to ' + s); });
      sug.appendChild(b); sug.appendChild(document.createTextNode('?'));
      sug.hidden = false;
      return s;
    };
    inp.addEventListener('blur', () => { if (clean(inp.value)) offer(); });
    inp.addEventListener('input', () => { if (!err.hidden) showErr(''); if (!sug.hidden && !suggestion(clean(inp.value))) sug.hidden = true; });
    send.addEventListener('submit', e => {
      const v = clean(inp.value);
      inp.value = v;
      if (!v) { e.preventDefault(); showErr('Enter an email'); inp.focus(); return; }
      if (!valid(v)) { e.preventDefault(); showErr('Check the email'); inp.focus(); return; }
      // A likely typo: say so once; a second press sends it as typed.
      const s = suggestion(v);
      if (s && offered !== v) { e.preventDefault(); offered = v; offer(); say('Did you mean ' + s + '?'); return; }
      btn.style.minWidth = btn.offsetWidth + 'px';
      btn.textContent = 'Sending';
      btn.disabled = true;
      // Keep the button off for a moment even if the page is slow to answer.
      setTimeout(() => { btn.disabled = false; btn.textContent = 'Send code'; }, 15000);
    });
    // Reached by a tap on Sign in: the field is ready on a laptop. (On a phone, the keyboard would cover the card.)
    if ((state === 'form' || state === 'invalid') && window.matchMedia('(min-width: 768px)').matches && !inp.value) inp.focus();
  }

  /* ------------------------------------------------------------ the code */

  const codeForm = root.querySelector('form[data-si="code"]');
  if (codeForm) {
    const c = codeForm.querySelector('#si-code'), err = codeForm.querySelector('#si-code-err'), btn = codeForm.querySelector('.si-go');
    let busy = false;
    const showErr = t => { err.textContent = t; err.hidden = !t; if (t) c.setAttribute('aria-invalid', 'true'); else c.removeAttribute('aria-invalid'); };
    const done = () => { busy = false; btn.disabled = false; btn.textContent = 'Sign in'; };
    // Through REST when it can (the page stays, the digits stay); the form posts by itself otherwise.
    const go = async () => {
      if (busy) return;
      const d = c.value.replace(/\D/g, '');
      if (d.length !== 6) { showErr(d ? 'Code not valid' : 'Enter the code'); c.focus(); return; }
      busy = true; btn.disabled = true; btn.textContent = 'Signing in';
      if (!W.api) { codeForm.submit(); return; }
      try {
        const r = await W.api('POST', 'auth/code', { code: d });
        location.href = r.go || '/';
      } catch (e) {
        done();
        if (!e.status || e.status >= 500) { codeForm.submit(); return; }
        // "Code not valid · 3 tries left", "Too many tries · Send a new code".
        showErr((e.data && e.data.message) || 'Code not valid');
        say((e.data && e.data.message) || 'Code not valid');
        c.focus(); c.select();
        // Expired, or too many tries: Resend is the way on.
        if (e.data && /ogc_code_(gone|tries)/.test(e.data.code || '')) { const r = root.querySelector('[data-resend]'); if (r && !r.disabled) r.focus(); }
      }
    };
    c.addEventListener('input', () => {
      const d = c.value.replace(/\D/g, '');
      if (!err.hidden) showErr('');
      if (d.length === 6) go();
    });
    codeForm.addEventListener('submit', e => { e.preventDefault(); go(); });
    // Back from a wrong code (no script, or the server's redirect): the digits as typed, selected.
    if (!err.hidden) { c.focus(); c.select(); }
  }

  /* ------------------------------------------------------------ Resend follows the server's limits */

  const resend = root.querySelector('[data-resend]');
  if (resend) {
    const at = +resend.dataset.at || 0, skew = (+resend.dataset.now || 0) - Math.floor(Date.now() / 1000);
    const tick = () => {
      const left = at - (Math.floor(Date.now() / 1000) + skew);
      if (left > 300) {
        // A wait in words, the same in every time zone ("Resend in 14 min", "Resend in 3 hours").
        resend.disabled = true;
        resend.textContent = 'Resend in ' + (left < 5400 ? Math.ceil(left / 60) + ' min' : Math.round(left / 3600) + ' hours');
        setTimeout(tick, 15000);
      } else if (left > 0) {
        resend.disabled = true;
        resend.textContent = 'Resend in ' + Math.floor(left / 60) + ':' + String(left % 60).padStart(2, '0');
        setTimeout(tick, 1000);
      } else {
        resend.disabled = false;
        resend.textContent = 'Resend';
      }
    };
    if (at) tick();
  }

  /* ------------------------------------------------------------ the sent state */

  // A laptop: straight into the code field (the email form does the same). A phone: the heading, so
  // the keyboard doesn't cover "Check your email" before it's read.
  if (state === 'sent' && !(codeForm && codeForm.querySelector('[aria-invalid]'))) {
    const code = root.querySelector('#si-code');
    if (code && window.matchMedia('(min-width: 768px)').matches) code.focus(); else if (h1) h1.focus();
  }
  // Another tab of this browser signed in (a link opened there): carry on here too.
  if (state === 'sent') {
    window.addEventListener('storage', e => {
      if (e.key !== 'ogc-signed-in' || !e.newValue) return;
      const ret = root.dataset.return || '';
      location.href = (W.signin || root.dataset.base + 'signin/') + '?continue=1' + (ret ? '&return=' + encodeURIComponent(ret) : '');
    });
  }
  // Signed out: what this browser kept for a person not signed in goes too.
  if (/[?&]out=1/.test(location.search)) {
    try { localStorage.removeItem('ogc-me-pending'); } catch (e) { /* nothing kept */ }
    say('Signed out');
  }
})();
