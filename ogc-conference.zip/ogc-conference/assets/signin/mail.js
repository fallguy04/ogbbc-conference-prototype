/*
 * mail.js — the Mail log's tabs (Email · Text), its width (a phone's 390 or a laptop's 600), and a
 * confirm before Clear (local site only).
 */
(function () {
  'use strict';
  document.addEventListener('click', e => {
    const t = e.target.closest('[data-ml-tab]');
    if (t) {
      document.querySelectorAll('[data-ml-tab]').forEach(b => b.setAttribute('aria-selected', String(b === t)));
      document.querySelectorAll('[data-ml-pane]').forEach(p => { p.hidden = p.dataset.mlPane !== t.dataset.mlTab; });
      return;
    }
    const w = e.target.closest('[data-ml-w]');
    if (w) {
      document.querySelectorAll('[data-ml-w]').forEach(b => b.setAttribute('aria-pressed', String(b === w)));
      const f = document.querySelector('.ml-frame');
      if (f) f.classList.toggle('is-390', w.dataset.mlW === '390');
    }
  });
  document.addEventListener('submit', e => {
    if (e.target.matches('[data-ml-clear]') && !window.confirm('Clear every email in the log?')) e.preventDefault();
  });
})();
