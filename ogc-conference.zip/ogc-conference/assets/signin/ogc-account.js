/*
 * ogc-account.js — who's signed in, on every page that has an editors' bar (signin area).
 *
 * At the right end of each cream bar (.ws-bar__in): a round mark with the person's initials, and their
 * name as "Ruth K." (or their email until a name is known). It opens a small menu: the name and email,
 * Your sign-ups, All years (webmasters), the other year for someone in two, Sign out, Sign out other
 * devices (asked first, in a small dialog), and a Shared device switch with its meaning written under
 * it. On a phone only the mark shows (a 44 px tap) and the menu is a sheet from the bottom, with a
 * Close row; a tap on the dim backdrop closes it too, and focus goes back to the mark. The sheet and
 * its backdrop are moved to the end of the page while open: inside a sticky bar (its own stacking
 * layer) the backdrop, on the page, would sit over the sheet and swallow every tap.
 * Someone in two years sees "Open 2028" beside the mark (nothing hidden behind a hover).
 *
 * Confirm it's you: when a members' route answers 401 ogc_reauth (a sign-in older than 30 days),
 * OGC_WP.api waits on OGC_AUTH.reauth(): a small sheet over the page sends a code, takes it, and the
 * call goes on with the new sign-in. Nothing typed on the page is lost; closing the sheet leaves a
 * "Confirm it's you" pill to open it again. Opening a members' page after 30 days draws the page's own
 * empty frame ([data-ogc-reauth], module-auth.php) with the same dialog, and reloads it once done.
 *
 * Also, on any page: the short status after signing in ("Signed in"), after signing out other devices,
 * or after "Not me" (the ogc_flash cookie the server sets), and window.OGC_AUTH for other areas:
 *   OGC_AUTH.signinUrl(ret)   the sign-in page, coming back to ret (default: here)
 *   OGC_AUTH.notYouUrl(ret)   sign out, then sign in again, coming back to ret
 *   OGC_AUTH.reauth()         a Promise that resolves once this person has confirmed with a code
 *   OGC_AUTH.suggest(email)   "ruth@gmail.com" for "ruth@gmial.com" (common domains only), else ''
 */
(function () {
  'use strict';
  const W = window.OGC_WP || {};
  const base = W.base || '/annual-conference/';
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
  const here = () => location.pathname + location.search;
  const signinUrl = ret => (W.signin || base + 'signin/') + '?return=' + encodeURIComponent(ret || here());

  // Common address domains, and the ways they're mistyped ("gmial.com", "yahoo.con"): the sign-in page
  // and Invite both ask "Did you mean gmail.com?" (a built-in list, no outside service).
  const DOMAINS = ['gmail.com', 'yahoo.com', 'outlook.com', 'hotmail.com', 'aol.com', 'icloud.com', 'comcast.net', 'live.com', 'msn.com', 'me.com', 'att.net', 'verizon.net', 'sbcglobal.net', 'bellsouth.net', 'charter.net', 'cox.net', 'frontier.com', 'windstream.net', 'protonmail.com', 'ymail.com'];
  const dist = (a, b) => {
    const m = a.length, n = b.length, d = Array.from({ length: m + 1 }, (_, i) => [i].concat(Array(n).fill(0)));
    for (let j = 1; j <= n; j++) d[0][j] = j;
    for (let i = 1; i <= m; i++) for (let j = 1; j <= n; j++) {
      d[i][j] = Math.min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
      if (i > 1 && j > 1 && a[i - 1] === b[j - 2] && a[i - 2] === b[j - 1]) d[i][j] = Math.min(d[i][j], d[i - 2][j - 2] + 1);
    }
    return d[m][n];
  };
  // The address as it was probably meant ("ruth@gmail.com"), or '' when it looks right.
  function suggest(email) {
    email = String(email || '');
    const at = email.lastIndexOf('@');
    if (at < 1) return '';
    const dom = email.slice(at + 1).toLowerCase();
    if (!dom || DOMAINS.indexOf(dom) >= 0) return '';
    let best = '', bd = 3;
    DOMAINS.forEach(d => { const x = dist(dom, d); if (x < bd && x > 0) { bd = x; best = d; } });
    if (!best) { const stem = dom.replace(/\.(con|cmo|cm|co|om|comm)$/, '.com'); if (stem !== dom && DOMAINS.indexOf(stem) >= 0) best = stem; }
    if (!best && DOMAINS.indexOf(dom + '.com') >= 0) best = dom + '.com';
    return best ? email.slice(0, at + 1) + best : '';
  }

  window.OGC_AUTH = {
    signinUrl,
    notYouUrl: ret => W.me && W.logout ? W.logout + '&return=' + encodeURIComponent(ret || here()) : signinUrl(ret),
    reauth,
    suggest
  };

  /* ------------------------------------------------------------ the status after a sign-in */

  function cookie(name) {
    const m = document.cookie.match(new RegExp('(?:^|; )' + name + '=([^;]*)'));
    return m ? decodeURIComponent(m[1]) : '';
  }
  function toast(t) {
    const el = document.createElement('p');
    el.className = 'ogc ogc-acct-toast';
    el.setAttribute('role', 'status');
    el.textContent = t;
    document.body.appendChild(el);
    requestAnimationFrame(() => el.classList.add('is-on'));
    setTimeout(() => { el.classList.remove('is-on'); setTimeout(() => el.remove(), 400); }, 2500);
  }
  // Focus the page's heading once it's drawn (pages draw after their data arrives): watch for it for up
  // to 5 seconds, else the bar's title, which exists at once.
  function focusHeading() {
    const pick = () => document.querySelector('main h1:not(.ws-bar h1), .ws-body h1, main h1') || null;
    const put = h => { if (!h.hasAttribute('tabindex')) h.setAttribute('tabindex', '-1'); h.focus({ preventScroll: true }); };
    const now = pick();
    if (now && now.offsetParent !== null) { put(now); return; }
    let done = false;
    const mo = new MutationObserver(() => { const h = pick(); if (h && h.offsetParent !== null && !done) { done = true; mo.disconnect(); put(h); } });
    mo.observe(document.body, { childList: true, subtree: true });
    setTimeout(() => { if (done) return; done = true; mo.disconnect(); const h = pick() || document.querySelector('.ws-bar h1, h1'); if (h) put(h); }, 5000);
  }
  const FLASH = { signedin: 'Signed in', others: 'Other devices signed out', removed: 'Sign-up removed', shared: 'Signs out when the browser closes', unshared: 'Stays signed in on this device' };
  const flash = cookie('ogc_flash');
  if (flash) {
    document.cookie = 'ogc_flash=; Max-Age=0; path=/; SameSite=Lax';
    const go = () => {
      if (FLASH[flash]) toast(FLASH[flash]);
      if (flash === 'signedin') {
        // A tab still waiting on "Check your email" moves on (signin.js listens).
        try { localStorage.setItem('ogc-signed-in', String(Date.now())); } catch (e) { /* not kept */ }
        focusHeading();
      }
    };
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', go); else go();
  }

  /* ------------------------------------------------------------ Confirm it's you (over the page) */

  let waiting = null;
  function reauth() {
    if (waiting) { openSheet(); return waiting; }
    waiting = new Promise(resolve => { sheetDone = resolve; });
    openSheet();
    return waiting;
  }
  let sheetDone = null, dlg = null, pill = null;
  // The dialogs' one filled button in the page's own style: the app's (.ap-btn, app.css) inside the app,
  // which doesn't load week.css (Oct 28: Send code and Confirm were the browser's grey buttons there).
  const filled = () => document.documentElement.classList.contains('ogc-appshell') ? 'ap-btn ap-btn--primary ap-btn--big' : 'wk-btn';
  function openSheet() {
    if (pill) { pill.remove(); pill = null; }
    if (!dlg) {
      dlg = document.createElement('dialog');
      dlg.className = 'ogc ogc-reauth'; // .ogc carries the site's colours (it sits outside the page's block)
      dlg.setAttribute('aria-labelledby', 'ogc-reauth-h');
      document.body.appendChild(dlg);
      dlg.addEventListener('cancel', e => { e.preventDefault(); hideSheet(); });
      dlg.addEventListener('click', e => { if (e.target === dlg || e.target.closest('[data-ra-x]')) hideSheet(); });
      drawAsk();
    }
    if (!dlg.open) dlg.showModal();
    const f = dlg.querySelector('input, .ogc-reauth__btns button'); if (f) f.focus();
  }
  // Closed without confirming: the page's changes wait, and a pill opens the sheet again.
  function hideSheet() {
    if (dlg && dlg.open) dlg.close();
    if (!waiting || pill) return;
    pill = document.createElement('button');
    pill.type = 'button';
    pill.className = 'ogc ogc-reauth-pill';
    pill.textContent = 'Confirm it’s you';
    pill.title = 'Changes wait until you confirm';
    pill.addEventListener('click', openSheet);
    document.body.appendChild(pill);
  }
  const masked = () => { const e = (W.me && W.me.email) || ''; return e; };
  function frame(body) {
    return '<div class="ogc-reauth__in"><div class="ogc-reauth__top"><h2 id="ogc-reauth-h">Confirm it’s you</h2><button type="button" class="ogc-reauth__x" data-ra-x aria-label="Close">×</button></div>' + body + '</div>';
  }
  function drawAsk(msg) {
    dlg.innerHTML = frame('<p class="ogc-reauth__addr">' + esc(masked()) + '</p><p class="ogc-reauth__help">Committee pages ask every 30 days</p>' +
      '<p class="ogc-reauth__btns"><button type="button" class="' + filled() + '" data-ra-send>Send code</button></p>' +
      '<p class="ogc-reauth__err" role="alert"' + (msg ? '' : ' hidden') + '>' + esc(msg || '') + '</p>' +
      '<p class="ogc-reauth__links"><a href="' + esc(W.logout || signinUrl()) + '">Sign out</a></p>');
    dlg.querySelector('[data-ra-send]').addEventListener('click', send);
  }
  async function send(e) {
    const b = e.currentTarget;
    b.disabled = true; b.textContent = 'Sending';
    try {
      await W.api('POST', 'auth/send', { email: (W.me && W.me.email) || '', return: here() });
      drawCode();
    } catch (x) {
      // Over a limit: a code already sent still works.
      if (x.status === 429) { drawCode((x.data && x.data.message) || ''); return; }
      drawAsk('Couldn’t send · Retry');
    }
  }
  function drawCode(note) {
    dlg.innerHTML = frame('<p class="ogc-reauth__addr">' + esc(masked()) + '</p>' +
      '<label class="ogc-reauth__label" for="ogc-ra-code">Code</label><input id="ogc-ra-code" class="ogc-reauth__code" type="text" inputmode="numeric" autocomplete="one-time-code" maxlength="9" aria-describedby="ogc-ra-err ogc-ra-help">' +
      '<p class="ogc-reauth__err" id="ogc-ra-err" role="alert"' + (note ? '' : ' hidden') + '>' + esc(note || '') + '</p>' +
      '<p class="ogc-reauth__help" id="ogc-ra-help"><span style="display:block">Code or link in the email</span> <span style="display:block">From ' + esc(W.mailFrom || 'conference@ogbbc.org') + ' · <span style="white-space:nowrap">Check spam</span></span></p>' +
      '<p class="ogc-reauth__btns"><button type="button" class="' + filled() + '" data-ra-go>Confirm</button></p>' +
      '<p class="ogc-reauth__links"><button type="button" data-ra-again>Resend</button></p>');
    const c = dlg.querySelector('#ogc-ra-code'), err = dlg.querySelector('#ogc-ra-err'), go = dlg.querySelector('[data-ra-go]');
    dlg.querySelector('[data-ra-again]').addEventListener('click', send);
    let busy = false;
    const submit = async () => {
      const d = c.value.replace(/\D/g, '');
      if (d.length !== 6 || busy) { if (!busy) { err.textContent = d ? 'Code not valid' : 'Enter the code'; err.hidden = false; c.focus(); } return; }
      busy = true; go.disabled = true; go.textContent = 'Confirming';
      try {
        const r = await W.api('POST', 'auth/code', { code: d });
        if (r.nonce) W.nonce = r.nonce;
        confirmed();
      } catch (x) {
        busy = false; go.disabled = false; go.textContent = 'Confirm';
        err.textContent = (x.data && x.data.message) || 'Code not valid'; err.hidden = false;
        c.setAttribute('aria-invalid', 'true');
        c.focus(); c.select();
        if (x.data && /ogc_code_(gone|tries)/.test(x.data.code || '')) drawAsk(err.textContent);
      }
    };
    c.addEventListener('input', () => { err.hidden = true; c.removeAttribute('aria-invalid'); if (c.value.replace(/\D/g, '').length === 6) submit(); });
    c.addEventListener('keydown', ev => { if (ev.key === 'Enter') { ev.preventDefault(); submit(); } });
    go.addEventListener('click', submit);
    c.focus();
  }
  // Confirmed (a code here, or a link opened in another tab): the dialog goes and the page carries on.
  function confirmed() {
    // The server's "Signed in" note is for a new page; this one carries on.
    document.cookie = 'ogc_flash=; Max-Age=0; path=/; SameSite=Lax';
    if (dlg) { if (dlg.open) dlg.close(); dlg.remove(); dlg = null; }
    if (pill) { pill.remove(); pill = null; }
    const done = sheetDone; waiting = null; sheetDone = null;
    toast('Confirmed');
    if (done) done();
  }
  // The dialog says "Or open the link in the email": a link opened in another tab (or the email's
  // button on this browser) signs this browser in again. The waiting dialog asks the server when that
  // tab says so, and whenever this one comes back into view; its saved-up changes then go through.
  let checking = false;
  async function recheck() {
    if (!waiting || checking) return;
    checking = true;
    try {
      const r = await fetch((W.signin || base + 'signin/') + '?session=1', { credentials: 'same-origin', headers: { Accept: 'application/json' } });
      const j = await r.json();
      if (j && j.fresh && W.me && j.email === W.me.email) { if (j.nonce) W.nonce = j.nonce; confirmed(); }
    } catch (x) { /* still waiting */ }
    checking = false;
  }
  window.addEventListener('storage', e => { if (e.key === 'ogc-signed-in' && e.newValue) recheck(); });
  window.addEventListener('focus', recheck);
  document.addEventListener('visibilitychange', () => { if (!document.hidden) recheck(); });

  // Every call through OGC_WP.api: a 401 ogc_reauth waits for the code, then goes once more.
  if (W.api && !W.api.__reauth) {
    const call = W.api;
    W.api = async function (method, path, body) {
      try { return await call(method, path, body); }
      catch (e) {
        if (e.status !== 401 || !e.data || e.data.code !== 'ogc_reauth' || /^auth\//.test(String(path))) throw e;
        await reauth();
        return call(method, path, body);
      }
    };
    W.api.__reauth = true;
  }
  // A members' page opened after 30 days: its own frame, the dialog over it, then the page itself.
  const reauthPage = () => { if (document.querySelector('[data-ogc-reauth]')) reauth().then(() => location.reload()); };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', reauthPage); else reauthPage();

  /* ------------------------------------------------------------ a small question over the page */

  // "Sign out other devices?" in the page's own dialog (never the browser's window.confirm).
  function ask(q, yes) {
    return new Promise(resolve => {
      const d = document.createElement('dialog');
      d.className = 'ogc ogc-reauth ogc-ask';
      d.setAttribute('aria-labelledby', 'ogc-ask-h');
      d.innerHTML = '<div class="ogc-reauth__in"><div class="ogc-reauth__top"><h2 id="ogc-ask-h">' + esc(q) + '</h2><button type="button" class="ogc-reauth__x" data-no aria-label="Close">×</button></div>' +
        '<p class="ogc-reauth__btns"><button type="button" class="' + filled() + '" data-yes>' + esc(yes) + '</button></p><p class="ogc-reauth__links"><button type="button" data-no>Cancel</button></p></div>';
      document.body.appendChild(d);
      const done = v => { if (d.open) d.close(); d.remove(); resolve(v); };
      d.addEventListener('cancel', e => { e.preventDefault(); done(false); });
      d.addEventListener('click', e => { if (e.target === d || e.target.closest('[data-no]')) done(false); else if (e.target.closest('[data-yes]')) done(true); });
      d.showModal();
      d.querySelector('[data-yes]').focus();
    });
  }

  /* ------------------------------------------------------------ the mark */

  if (!W.me || !W.me.email) return;
  const name = String(W.me.name || '').trim();
  const words = name.split(/\s+/).filter(Boolean);
  // A full name reads "Ruth K."; without one (a household that only typed its email, or a one-word
  // name), the address is the label and "Sign out" is written beside the mark, never a lone letter.
  const fullName = words.length > 1;
  const short = fullName ? words[0] + ' ' + words[words.length - 1].charAt(0) + '.' : W.me.email;
  const initials = (words.length ? (words[0].charAt(0) + (words.length > 1 ? words[words.length - 1].charAt(0) : '')) : W.me.email.charAt(0)).toUpperCase();
  const years = (W.member || []).map(Number);
  const q = new URLSearchParams(location.search);
  const yearHere = +q.get('year') || 0;
  // Someone in two years (2027's Lodging and 2028's COA): the other year, one tap away. Nobody else
  // sees a year choice.
  const others = !W.webmaster && years.length > 1 ? years.filter(y => y !== yearHere) : [];
  const sheetMq = window.matchMedia('(max-width: 600px)');

  function menuHtml() {
    const items = [];
    items.push('<a role="menuitem" href="' + esc(W.mine || base + 'register/?view=mine') + '">Your sign-ups</a>');
    // A page's own rows (the Conference app's Places: Share the app, Conference page; docs/35 §6 Q2),
    // drawn again each time the menu opens.
    items.push('<div class="ogc-acct__extra" data-acct-xrows hidden></div>');
    if (W.webmaster) items.push('<a role="menuitem" href="' + esc(base + 'admin/?role=web') + '">All years</a>');
    others.forEach(y => items.push('<a role="menuitem" href="' + esc(base + 'year/?year=' + y) + '">Open ' + esc(y) + '</a>'));
    return '<div class="ogc-acct__head"><b>' + esc(name || W.me.email) + '</b>' + (name ? '<span>' + esc(W.me.email) + '</span>' : '') + (W.webmaster ? '<span class="ogc-acct__role">Webmaster</span>' : '') + '</div>' +
      items.join('') +
      '<hr><a role="menuitem" href="' + esc(W.logout || '#') + '" data-acct-out>Sign out</a>' +
      (W.signoutAll ? '<a role="menuitem" class="ogc-acct__quiet" href="' + esc(W.signoutAll) + '" data-acct-others>Sign out other devices</a>' : '') +
      // Not this person's own device (the desk's laptop): a switch, its meaning written under it (a phone
      // has no hover), and off again restores the year-long sign-in.
      (W.sharedUrl ? '<a role="menuitemcheckbox" aria-checked="' + (W.sharedDevice ? 'true' : 'false') + '" class="ogc-acct__switch" href="' + esc(W.sharedDevice ? W.sharedUrl.replace(/([?&])shared=1/, '$1shared=0') : W.sharedUrl) + '">' +
        '<span class="ogc-acct__sw" aria-hidden="true"></span><span><b>Shared device</b><small>Signs out when the browser closes</small></span></a>' : '') +
      // A page's own line at the foot (the Conference app's "Saved for offline · 2:45 PM", round 3), drawn
      // again each time the menu opens.
      '<p class="ogc-acct__foot" data-acct-foot hidden></p>' +
      '<button type="button" role="menuitem" class="ogc-acct__close" data-acct-close>Close</button>';
  }

  // Signing out from any page: what this browser kept for the person goes too (a pending email, and the
  // registration form's draft in this tab), as the form's own Sign out does.
  function forget() {
    try { localStorage.removeItem('ogc-me-pending'); } catch (x) { /* nothing kept */ }
    try { Object.keys(sessionStorage).filter(k => k.indexOf('ogc-register-draft-') === 0).forEach(k => sessionStorage.removeItem(k)); } catch (x) { /* nothing kept */ }
  }

  let seq = 0;
  function mount(bar) {
    if (bar.querySelector('.ogc-acct')) return;
    // Your sign-ups' line under its heading ("a@example.com · Sign out") becomes the same control as
    // every other page's: the mark, the name (or the address), the menu.
    const line = bar.classList.contains('rf-who');
    if (line) { bar.textContent = ''; bar.classList.add('ogc-acct-line'); }
    const id = 'ogc-acct-menu-' + (++seq);
    const el = document.createElement('div');
    el.className = 'ogc-acct' + (line ? ' ogc-acct--line' : '') + (fullName ? '' : ' ogc-acct--noname');
    el.innerHTML = (others.length === 1 ? '<a class="ogc-acct__year" href="' + esc(base + 'year/?year=' + others[0]) + '">Open ' + esc(others[0]) + '</a>' : '') +
      '<button type="button" class="ogc-acct__btn" aria-haspopup="true" aria-expanded="false" aria-controls="' + id + '" title="' + esc(W.me.email) + '">' +
      '<span class="ogc-acct__mark" aria-hidden="true">' + esc(initials) + '</span><span class="ogc-acct__name">' + esc(short) + '</span><span class="ogc-sr">Account</span></button>' +
      // No name yet (a household that only typed its email): "Sign out" in words beside the mark, never
      // a lone letter.
      (fullName ? '' : '<a class="ogc-acct__out" href="' + esc(W.logout || '#') + '" data-acct-out>Sign out</a>') +
      '<div class="ogc-acct__menu" id="' + id + '" role="menu" hidden>' + menuHtml() + '</div>';
    bar.appendChild(el);
    el.addEventListener('click', e => { if (e.target.closest('.ogc-acct__out')) forget(); });
    const btn = el.querySelector('.ogc-acct__btn'), menu = el.querySelector('.ogc-acct__menu');
    // The phone's sheet: its dim backdrop and the sheet itself both go to the end of the page while
    // open. The bar is sticky with a z-index, so anything inside it is layered with the bar: a backdrop
    // on the page would sit over the sheet. Put side by side at the page's end, the sheet is on top.
    let shade = null, xrows = [];
    const extra = bar.hasAttribute('data-acct-extra');
    // The Conference app's menu (round 3, docs/35 §3.4): the name, then Your sign-ups, the app's rows, Sign
    // out and the foot's line. Its address, Sign out other devices and Shared device stay on the other pages'
    // menus (a person's own phone; the desk's laptop signs in on the site).
    if (extra) { el.classList.add('ogc-acct--app'); menu.classList.add('is-app'); }
    const drawExtra = () => {
      const box = menu.querySelector('[data-acct-xrows]');
      if (!box) return;
      xrows = extra && typeof window.OGC_ACCT_EXTRA === 'function' ? (window.OGC_ACCT_EXTRA() || []) : [];
      box.innerHTML = xrows.map((r, i) => r.href ? '<a role="menuitem" href="' + esc(r.href) + '"' + (r.blank ? ' target="_blank" rel="noopener"' : '') + '>' + esc(r.label) + '</a>'
        : '<a role="menuitem" href="#" data-acct-x="' + i + '">' + esc(r.label) + '</a>').join('');
      box.hidden = !xrows.length;
      // The foot's line, as words (window.OGC_ACCT_FOOT: a page's text, or nothing), with the tick before it.
      const foot = menu.querySelector('[data-acct-foot]');
      if (foot) {
        const t = extra && typeof window.OGC_ACCT_FOOT === 'function' ? String(window.OGC_ACCT_FOOT() || '') : '';
        foot.innerHTML = t ? '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m5.5 12.5 4 4 9-9" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg><span>' + esc(t) + '</span>' : '';
        foot.hidden = !t;
      }
    };
    // On the Conference app (O.layers, docs/35 §2.7), the phone's sheet is a layer: Back closes it and stays
    // on the page. fromBack: Back closed it (its entry is gone already).
    let layer = null;
    // The Conference app and page on a phone (round 3, docs/35 §3.4): the menu is the app's one modal sheet
    // (O.sheet.modal: its grabber and ×, a drag down closes it, Back and Esc too), the name in its top
    // row. Every other page keeps its own sheet below.
    let modal = null;
    const modalOk = () => sheetMq.matches && !!(window.OGC && window.OGC.sheet && window.OGC.sheet.modal);
    function openModal() {
      drawExtra();
      menu.hidden = false;
      btn.setAttribute('aria-expanded', 'true');
      el.classList.add('is-open');
      menu.classList.add('is-modal');
      const m = modal = window.OGC.sheet.modal('', {
        head: '<h2 class="ogc-sheet__h">' + esc(name || W.me.email) + '</h2>', node: menu, opener: btn, className: 'ogc-acct-msheet',
        onClose: () => {
          if (modal === m) modal = null;
          menu.classList.remove('is-modal');
          menu.hidden = true;
          el.appendChild(menu);
          btn.setAttribute('aria-expanded', 'false');
          el.classList.remove('is-open');
        }
      });
    }
    const set = (open, back, fromBack) => {
      if (open && modalOk()) { if (!modal) openModal(); return; }
      if (!open && modal) { const m = modal; modal = null; m.close(back ? 'x' : 'go'); return; }
      if (open) drawExtra();
      menu.hidden = !open;
      btn.setAttribute('aria-expanded', String(open));
      el.classList.toggle('is-open', open);
      const sheet = open && sheetMq.matches;
      const L = window.OGC && window.OGC.layers;
      if (sheet && L && !layer) layer = L.push('menu', { close: () => { layer = null; set(false, true, true); } });
      if (!open && layer) { const l = layer; layer = null; if (!fromBack && L && L.top() === l) L.pop(1); }
      document.documentElement.classList.toggle('ogc-acct-sheet', sheet);
      if (sheet && !shade) {
        shade = document.createElement('div');
        shade.className = 'ogc-acct-shade';
        shade.addEventListener('click', () => set(false, true));
        document.body.appendChild(shade);
        menu.classList.add('ogc', 'is-sheet');
        document.body.appendChild(menu);
      }
      if (!sheet && shade) { shade.remove(); shade = null; menu.classList.remove('ogc', 'is-sheet'); el.appendChild(menu); }
      if (open) { const f = menu.querySelector('a'); if (f) f.focus(); }
      else if (back) btn.focus();
    };
    btn.addEventListener('click', e => { e.stopPropagation(); set(menu.hidden, true); });
    menu.addEventListener('click', e => {
      if (e.target.closest('[data-acct-close]')) { set(false, true); return; }
      const a = e.target.closest('a');
      if (a && a.hasAttribute('data-acct-x')) {
        e.preventDefault();
        const r = xrows[+a.getAttribute('data-acct-x')];
        // The focus back on the account's button first, so what the row opens (Share) gives it back there;
        // and once the menu's own Back entry has gone.
        set(false, true);
        const L = window.OGC && window.OGC.layers;
        if (r && r.run) { if (L && L.after) L.after(r.run); else r.run(); }
        return;
      }
      if (a && a.hasAttribute('data-acct-others')) {
        e.preventDefault();
        set(false);
        ask('Sign out other devices?', 'Sign out').then(y => { if (y) location.href = a.href; else btn.focus(); });
        return;
      }
      if (a && a.hasAttribute('data-acct-out')) forget();
      // A row that leaves the page from the phone's sheet (Your sign-ups, the Conference page, Sign out): the
      // sheet's Back entry goes first, so Back from there lands on the page, not on the menu open again
      // (round 3's check).
      const L = window.OGC && window.OGC.layers;
      const leaving = a && !a.target && a.getAttribute('href') && a.getAttribute('href') !== '#' && !e.metaKey && !e.ctrlKey && !e.shiftKey && !e.altKey;
      if (leaving && L && L.after && (modal || layer)) { e.preventDefault(); const href = a.href; set(false); L.after(() => location.assign(href)); }
    });
    menu.addEventListener('keydown', e => {
      const links = Array.from(menu.querySelectorAll('a, button')).filter(x => x.offsetParent !== null), i = links.indexOf(document.activeElement);
      if (e.key === 'ArrowDown') { e.preventDefault(); links[(i + 1) % links.length].focus(); }
      if (e.key === 'ArrowUp') { e.preventDefault(); links[(i - 1 + links.length) % links.length].focus(); }
      if (e.key === 'Escape') { e.preventDefault(); set(false, true); }
      // (In the modal sheet the focus stays inside it: Tab goes on to its ×.)
      if (e.key === 'Tab' && !e.shiftKey && i === links.length - 1 && !modal) set(false);
    });
    // (The modal sheet closes itself: its ×, a tap on the scrim, a drag.)
    // Turned to a laptop's width with the sheet open: back into the bar.
    // (Heard by the module's one listener each, for the controls on the page now: the app's bar is drawn
    // again with each tab and each minute, and a listener a mount left the piled up; round 3's check.)
    mounted.push({ el, menu,
      outside: e => { if (!modal && !menu.hidden && !el.contains(e.target) && !menu.contains(e.target)) set(false); },
      turned: () => { if (!menu.hidden) set(false); } });
  }
  // The controls mounted, while they're on the page (or their menu is still open); one document listener
  // and one media listener for them all.
  const mounted = [];
  const live = () => { for (let i = mounted.length - 1; i >= 0; i--) { const c = mounted[i]; if (!c.el.isConnected && (c.menu.hidden || !c.menu.isConnected)) mounted.splice(i, 1); } return mounted.slice(); };
  document.addEventListener('click', e => live().forEach(c => c.outside(e)));
  sheetMq.addEventListener('change', () => live().forEach(c => c.turned()));

  // The pages draw their bars after their data arrives, and again when they change: mount each time.
  let queued = false;
  const scan = () => { queued = false; document.querySelectorAll('.ws-bar__in, .rf-who:not(.rf-who--form)').forEach(mount); };
  const watch = new MutationObserver(() => { if (!queued) { queued = true; requestAnimationFrame(scan); } });
  const start = () => { scan(); watch.observe(document.body, { childList: true, subtree: true }); };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start); else start();
})();
