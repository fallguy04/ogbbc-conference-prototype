/*
 * ogc-account.js — who's signed in, on every page that has an editors' bar (signin area).
 *
 * At the right end of each cream bar (.ws-bar__in): a round mark with the person's initials, and their
 * name as "Ruth K." (or their email until a name is known). It opens a small menu: the name and email,
 * Your sign-ups, All years (webmasters), the other year for someone in two, Sign out, Sign out other
 * devices (asked first, in a small dialog), and a Shared device switch with its meaning written under
 * it. On a phone only the mark shows (a 44 px tap) and the menu is a sheet from the bottom, with a
 * Close row; a tap on the dim backdrop closes it too, and focus goes back to the mark. The sheet and
 * its backdrop are moved to the end of the page while open: inside a sticky bar (its own stacking
 * layer) the backdrop, on the page, would sit over the sheet and swallow every tap.
 * Someone in two years sees "Open 2028" beside the mark (nothing hidden behind a hover).
 *
 * Confirm it's you: when a members' route answers 401 ogc_reauth (a sign-in older than 30 days),
 * OGC_WP.api waits on OGC_AUTH.reauth(): a small sheet over the page sends a code, takes it, and the
 * call goes on with the new sign-in. Nothing typed on the page is lost; closing the sheet leaves a
 * "Confirm it's you" pill to open it again. Opening a members' page after 30 days draws the page's own
 * empty frame ([data-ogc-reauth], module-auth.php) with the same dialog, and reloads it once done.
 *
 * Also, on any page: the short status after signing in ("Signed in"), after signing out other devices,
 * or after "Not me" (the ogc_flash cookie the server sets), and window.OGC_AUTH for other areas:
 *   OGC_AUTH.signinUrl(ret)   the sign-in page, coming back to ret (default: here)
 *   OGC_AUTH.notYouUrl(ret)   sign out, then sign in again, coming back to ret
 *   OGC_AUTH.reauth()         a Promise that resolves once this person has confirmed with a code
 *   OGC_AUTH.suggest(email)   "ruth@gmail.com" for "ruth@gmial.com" (common domains only), else ''
 */
(function () {
  'use strict';
  const W = window.OGC_WP || {};
  const base = W.base || '/annual-conference/';
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
  const here = () => location.pathname + location.search;
  const signinUrl = ret => (W.signin || base + 'signin/') + '?return=' + encodeURIComponent(ret || here());

  // Common address domains, and the ways they're mistyped ("gmial.com", "yahoo.con"): the sign-in page
  // and Invite both ask "Did you mean gmail.com?" (a built-in list, no outside service).
  const DOMAINS = ['gmail.com', 'yahoo.com', 'outlook.com', 'hotmail.com', 'aol.com', 'icloud.com', 'comcast.net', 'live.com', 'msn.com', 'me.com', 'att.net', 'verizon.net', 'sbcglobal.net', 'bellsouth.net', 'charter.net', 'cox.net', 'frontier.com', 'windstream.net', 'protonmail.com', 'ymail.com'];
  const dist = (a, b) => {
    const m = a.length, n = b.length, d = Array.from({ length: m + 1 }, (_, i) => [i].concat(Array(n).fill(0)));
    for (let j = 1; j <= n; j++) d[0][j] = j;
    for (let i = 1; i <= m; i++) for (let j = 1; j <= n; j++) {
      d[i][j] = Math.min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
      if (i > 1 && j > 1 && a[i - 1] === b[j - 2] && a[i - 2] === b[j - 1]) d[i][j] = Math.min(d[i][j], d[i - 2][j - 2] + 1);
    }
    return d[m][n];
  };
  // The address as it was probably meant ("ruth@gmail.com"), or '' when it looks right.
  function suggest(email) {
    email = String(email || '');
    const at = email.lastIndexOf('@');
    if (at < 1) return '';
    const dom = email.slice(at + 1).toLowerCase();
    if (!dom || DOMAINS.indexOf(dom) >= 0) return '';
    let best = '', bd = 3;
    DOMAINS.forEach(d => { const x = dist(dom, d); if (x < bd && x > 0) { bd = x; best = d; } });
    if (!best) { const stem = dom.replace(/\.(con|cmo|cm|co|om|comm)$/, '.com'); if (stem !== dom && DOMAINS.indexOf(stem) >= 0) best = stem; }
    if (!best && DOMAINS.indexOf(dom + '.com') >= 0) best = dom + '.com';
    return best ? email.slice(0, at + 1) + best : '';
  }

  window.OGC_AUTH = {
    signinUrl,
    notYouUrl: ret => W.me && W.logout ? W.logout + '&return=' + encodeURIComponent(ret || here()) : signinUrl(ret),
    reauth,
    suggest
  };

  /* ------------------------------------------------------------ the status after a sign-in */

  function cookie(name) {
    const m = document.cookie.match(new RegExp('(?:^|; )' + name + '=([^;]*)'));
    return m ? decodeURIComponent(m[1]) : '';
  }
  function toast(t) {
    const el = document.createElement('p');
    el.className = 'ogc ogc-acct-toast';
    el.setAttribute('role', 'status');
    el.textContent = t;
    document.body.appendChild(el);
    requestAnimationFrame(() => el.classList.add('is-on'));
    setTimeout(() => { el.classList.remove('is-on'); setTimeout(() => el.remove(), 400); }, 2500);
  }
  // Focus the page's heading once it's drawn (pages draw after their data arrives): watch for it for up
  // to 5 seconds, else the bar's title, which exists at once.
  function focusHeading() {
    const pick = () => document.querySelector('main h1:not(.ws-bar h1), .ws-body h1, main h1') || null;
    const put = h => { if (!h.hasAttribute('tabindex')) h.setAttribute('tabindex', '-1'); h.focus({ preventScroll: true }); };
    const now = pick();
    if (now && now.offsetParent !== null) { put(now); return; }
    let done = false;
    const mo = new MutationObserver(() => { const h = pick(); if (h && h.offsetParent !== null && !done) { done = true; mo.disconnect(); put(h); } });
    mo.observe(document.body, { childList: true, subtree: true });
    setTimeout(() => { if (done) return; done = true; mo.disconnect(); const h = pick() || document.querySelector('.ws-bar h1, h1'); if (h) put(h); }, 5000);
  }
  const FLASH = { signedin: 'Signed in', others: 'Other devices signed out', removed: 'Sign-up removed', shared: 'Signs out when the browser closes', unshared: 'Stays signed in on this device' };
  const flash = cookie('ogc_flash');
  if (flash) {
    document.cookie = 'ogc_flash=; Max-Age=0; path=/; SameSite=Lax';
    const go = () => {
      if (FLASH[flash]) toast(FLASH[flash]);
      if (flash === 'signedin') {
        // A tab still waiting on "Check your email" moves on (signin.js listens).
        try { localStorage.setItem('ogc-signed-in', String(Date.now())); } catch (e) { /* not kept */ }
        focusHeading();
      }
    };
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', go); else go();
  }

  /* ------------------------------------------------------------ Confirm it's you (over the page) */

  let waiting = null;
  function reauth() {
    if (waiting) { openSheet(); return waiting; }
    waiting = new Promise(resolve => { sheetDone = resolve; });
    openSheet();
    return waiting;
  }
  let sheetDone = null, dlg = null, pill = null;
  function openSheet() {
    if (pill) { pill.remove(); pill = null; }
    if (!dlg) {
      dlg = document.createElement('dialog');
      dlg.className = 'ogc ogc-reauth'; // .ogc carries the site's colours (it sits outside the page's block)
      dlg.setAttribute('aria-labelledby', 'ogc-reauth-h');
      document.body.appendChild(dlg);
      dlg.addEventListener('cancel', e => { e.preventDefault(); hideSheet(); });
      dlg.addEventListener('click', e => { if (e.target === dlg || e.target.closest('[data-ra-x]')) hideSheet(); });
      drawAsk();
    }
    if (!dlg.open) dlg.showModal();
    const f = dlg.querySelector('input, .wk-btn'); if (f) f.focus();
  }
  // Closed without confirming: the page's changes wait, and a pill opens the sheet again.
  function hideSheet() {
    if (dlg && dlg.open) dlg.close();
    if (!waiting || pill) return;
    pill = document.createElement('button');
    pill.type = 'button';
    pill.className = 'ogc ogc-reauth-pill';
    pill.textContent = 'Confirm it’s you';
    pill.title = 'Changes wait until you confirm';
    pill.addEventListener('click', openSheet);
    document.body.appendChild(pill);
  }
  const masked = () => { const e = (W.me && W.me.email) || ''; return e; };
  function frame(body) {
    return '<div class="ogc-reauth__in"><div class="ogc-reauth__top"><h2 id="ogc-reauth-h">Confirm it’s you</h2><button type="button" class="ogc-reauth__x" data-ra-x aria-label="Close">×</button></div>' + body + '</div>';
  }
  function drawAsk(msg) {
    dlg.innerHTML = frame('<p class="ogc-reauth__addr">' + esc(masked()) + '</p><p class="ogc-reauth__help">Committee pages ask every 30 days</p>' +
      '<p class="ogc-reauth__btns"><button type="button" class="wk-btn" data-ra-send>Send code</button></p>' +
      '<p class="ogc-reauth__err" role="alert"' + (msg ? '' : ' hidden') + '>' + esc(msg || '') + '</p>' +
      '<p class="ogc-reauth__links"><a href="' + esc(W.logout || signinUrl()) + '">Sign out</a></p>');
    dlg.querySelector('[data-ra-send]').addEventListener('click', send);
  }
  async function send(e) {
    const b = e.currentTarget;
    b.disabled = true; b.textContent = 'Sending';
    try {
      await W.api('POST', 'auth/send', { email: (W.me && W.me.email) || '', return: here() });
      drawCode();
    } catch (x) {
      // Over a limit: a code already sent still works.
      if (x.status === 429) { drawCode((x.data && x.data.message) || ''); return; }
      drawAsk('Couldn’t send · Retry');
    }
  }
  function drawCode(note) {
    dlg.innerHTML = frame('<p class="ogc-reauth__addr">' + esc(masked()) + '</p>' +
      '<label class="ogc-reauth__label" for="ogc-ra-code">Code</label><input id="ogc-ra-code" class="ogc-reauth__code" type="text" inputmode="numeric" autocomplete="one-time-code" maxlength="9" aria-describedby="ogc-ra-err ogc-ra-help">' +
      '<p class="ogc-reauth__err" id="ogc-ra-err" role="alert"' + (note ? '' : ' hidden') + '>' + esc(note || '') + '</p>' +
      '<p class="ogc-reauth__help" id="ogc-ra-help"><span style="display:block">Code or link in the email</span> <span style="display:block">From ' + esc(W.mailFrom || 'conference@ogbbc.org') + ' · <span style="white-space:nowrap">Check spam</span></span></p>' +
      '<p class="ogc-reauth__btns"><button type="button" class="wk-btn" data-ra-go>Confirm</button></p>' +
      '<p class="ogc-reauth__links"><button type="button" data-ra-again>Resend</button></p>');
    const c = dlg.querySelector('#ogc-ra-code'), err = dlg.querySelector('#ogc-ra-err'), go = dlg.querySelector('[data-ra-go]');
    dlg.querySelector('[data-ra-again]').addEventListener('click', send);
    let busy = false;
    const submit = async () => {
      const d = c.value.replace(/\D/g, '');
      if (d.length !== 6 || busy) { if (!busy) { err.textContent = d ? 'Code not valid' : 'Enter the code'; err.hidden = false; c.focus(); } return; }
      busy = true; go.disabled = true; go.textContent = 'Confirming';
      try {
        const r = await W.api('POST', 'auth/code', { code: d });
        if (r.nonce) W.nonce = r.nonce;
        confirmed();
      } catch (x) {
        busy = false; go.disabled = false; go.textContent = 'Confirm';
        err.textContent = (x.data && x.data.message) || 'Code not valid'; err.hidden = false;
        c.setAttribute('aria-invalid', 'true');
        c.focus(); c.select();
        if (x.data && /ogc_code_(gone|tries)/.test(x.data.code || '')) drawAsk(err.textContent);
      }
    };
    c.addEventListener('input', () => { err.hidden = true; c.removeAttribute('aria-invalid'); if (c.value.replace(/\D/g, '').length === 6) submit(); });
    c.addEventListener('keydown', ev => { if (ev.key === 'Enter') { ev.preventDefault(); submit(); } });
    go.addEventListener('click', submit);
    c.focus();
  }
  // Confirmed (a code here, or a link opened in another tab): the dialog goes and the page carries on.
  function confirmed() {
    // The server's "Signed in" note is for a new page; this one carries on.
    document.cookie = 'ogc_flash=; Max-Age=0; path=/; SameSite=Lax';
    if (dlg) { if (dlg.open) dlg.close(); dlg.remove(); dlg = null; }
    if (pill) { pill.remove(); pill = null; }
    const done = sheetDone; waiting = null; sheetDone = null;
    toast('Confirmed');
    if (done) done();
  }
  // The dialog says "Or open the link in the email": a link opened in another tab (or the email's
  // button on this browser) signs this browser in again. The waiting dialog asks the server when that
  // tab says so, and whenever this one comes back into view; its saved-up changes then go through.
  let checking = false;
  async function recheck() {
    if (!waiting || checking) return;
    checking = true;
    try {
      const r = await fetch((W.signin || base + 'signin/') + '?session=1', { credentials: 'same-origin', headers: { Accept: 'application/json' } });
      const j = await r.json();
      if (j && j.fresh && W.me && j.email === W.me.email) { if (j.nonce) W.nonce = j.nonce; confirmed(); }
    } catch (x) { /* still waiting */ }
    checking = false;
  }
  window.addEventListener('storage', e => { if (e.key === 'ogc-signed-in' && e.newValue) recheck(); });
  window.addEventListener('focus', recheck);
  document.addEventListener('visibilitychange', () => { if (!document.hidden) recheck(); });

  // Every call through OGC_WP.api: a 401 ogc_reauth waits for the code, then goes once more.
  if (W.api && !W.api.__reauth) {
    const call = W.api;
    W.api = async function (method, path, body) {
      try { return await call(method, path, body); }
      catch (e) {
        if (e.status !== 401 || !e.data || e.data.code !== 'ogc_reauth' || /^auth\//.test(String(path))) throw e;
        await reauth();
        return call(method, path, body);
      }
    };
    W.api.__reauth = true;
  }
  // A members' page opened after 30 days: its own frame, the dialog over it, then the page itself.
  const reauthPage = () => { if (document.querySelector('[data-ogc-reauth]')) reauth().then(() => location.reload()); };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', reauthPage); else reauthPage();

  /* ------------------------------------------------------------ a small question over the page */

  // "Sign out other devices?" in the page's own dialog (never the browser's window.confirm).
  function ask(q, yes) {
    return new Promise(resolve => {
      const d = document.createElement('dialog');
      d.className = 'ogc ogc-reauth ogc-ask';
      d.setAttribute('aria-labelledby', 'ogc-ask-h');
      d.innerHTML = '<div class="ogc-reauth__in"><div class="ogc-reauth__top"><h2 id="ogc-ask-h">' + esc(q) + '</h2><button type="button" class="ogc-reauth__x" data-no aria-label="Close">×</button></div>' +
        '<p class="ogc-reauth__btns"><button type="button" class="wk-btn" data-yes>' + esc(yes) + '</button></p><p class="ogc-reauth__links"><button type="button" data-no>Cancel</button></p></div>';
      document.body.appendChild(d);
      const done = v => { if (d.open) d.close(); d.remove(); resolve(v); };
      d.addEventListener('cancel', e => { e.preventDefault(); done(false); });
      d.addEventListener('click', e => { if (e.target === d || e.target.closest('[data-no]')) done(false); else if (e.target.closest('[data-yes]')) done(true); });
      d.showModal();
      d.querySelector('[data-yes]').focus();
    });
  }

  /* ------------------------------------------------------------ the mark */

  if (!W.me || !W.me.email) return;
  const name = String(W.me.name || '').trim();
  const words = name.split(/\s+/).filter(Boolean);
  // A full name reads "Ruth K."; without one (a household that only typed its email, or a one-word
  // name), the address is the label and "Sign out" is written beside the mark, never a lone letter.
  const fullName = words.length > 1;
  const short = fullName ? words[0] + ' ' + words[words.length - 1].charAt(0) + '.' : W.me.email;
  const initials = (words.length ? (words[0].charAt(0) + (words.length > 1 ? words[words.length - 1].charAt(0) : '')) : W.me.email.charAt(0)).toUpperCase();
  const years = (W.member || []).map(Number);
  const q = new URLSearchParams(location.search);
  const yearHere = +q.get('year') || 0;
  // Someone in two years (2027's Lodging and 2028's COA): the other year, one tap away. Nobody else
  // sees a year choice.
  const others = !W.webmaster && years.length > 1 ? years.filter(y => y !== yearHere) : [];
  const sheetMq = window.matchMedia('(max-width: 600px)');

  function menuHtml() {
    const items = [];
    items.push('<a role="menuitem" href="' + esc(W.mine || base + 'register/?view=mine') + '">Your sign-ups</a>');
    if (W.webmaster) items.push('<a role="menuitem" href="' + esc(base + 'admin/?role=web') + '">All years</a>');
    others.forEach(y => items.push('<a role="menuitem" href="' + esc(base + 'year/?year=' + y) + '">Open ' + esc(y) + '</a>'));
    return '<div class="ogc-acct__head"><b>' + esc(name || W.me.email) + '</b>' + (name ? '<span>' + esc(W.me.email) + '</span>' : '') + (W.webmaster ? '<span class="ogc-acct__role">Webmaster</span>' : '') + '</div>' +
      items.join('') +
      '<hr><a role="menuitem" href="' + esc(W.logout || '#') + '" data-acct-out>Sign out</a>' +
      (W.signoutAll ? '<a role="menuitem" class="ogc-acct__quiet" href="' + esc(W.signoutAll) + '" data-acct-others>Sign out other devices</a>' : '') +
      // Not this person's own device (the desk's laptop): a switch, its meaning written under it (a phone
      // has no hover), and off again restores the year-long sign-in.
      (W.sharedUrl ? '<a role="menuitemcheckbox" aria-checked="' + (W.sharedDevice ? 'true' : 'false') + '" class="ogc-acct__switch" href="' + esc(W.sharedDevice ? W.sharedUrl.replace(/([?&])shared=1/, '$1shared=0') : W.sharedUrl) + '">' +
        '<span class="ogc-acct__sw" aria-hidden="true"></span><span><b>Shared device</b><small>Signs out when the browser closes</small></span></a>' : '') +
      '<button type="button" role="menuitem" class="ogc-acct__close" data-acct-close>Close</button>';
  }

  // Signing out from any page: what this browser kept for the person goes too (a pending email, and the
  // registration form's draft in this tab), as the form's own Sign out does.
  function forget() {
    try { localStorage.removeItem('ogc-me-pending'); } catch (x) { /* nothing kept */ }
    try { Object.keys(sessionStorage).filter(k => k.indexOf('ogc-register-draft-') === 0).forEach(k => sessionStorage.removeItem(k)); } catch (x) { /* nothing kept */ }
  }

  let seq = 0;
  function mount(bar) {
    if (bar.querySelector('.ogc-acct')) return;
    // Your sign-ups' line under its heading ("a@example.com · Sign out") becomes the same control as
    // every other page's: the mark, the name (or the address), the menu.
    const line = bar.classList.contains('rf-who');
    if (line) { bar.textContent = ''; bar.classList.add('ogc-acct-line'); }
    const id = 'ogc-acct-menu-' + (++seq);
    const el = document.createElement('div');
    el.className = 'ogc-acct' + (line ? ' ogc-acct--line' : '') + (fullName ? '' : ' ogc-acct--noname');
    el.innerHTML = (others.length === 1 ? '<a class="ogc-acct__year" href="' + esc(base + 'year/?year=' + others[0]) + '">Open ' + esc(others[0]) + '</a>' : '') +
      '<button type="button" class="ogc-acct__btn" aria-haspopup="true" aria-expanded="false" aria-controls="' + id + '" title="' + esc(W.me.email) + '">' +
      '<span class="ogc-acct__mark" aria-hidden="true">' + esc(initials) + '</span><span class="ogc-acct__name">' + esc(short) + '</span><span class="ogc-sr">Account</span></button>' +
      // No name yet (a household that only typed its email): "Sign out" in words beside the mark, never
      // a lone letter.
      (fullName ? '' : '<a class="ogc-acct__out" href="' + esc(W.logout || '#') + '" data-acct-out>Sign out</a>') +
      '<div class="ogc-acct__menu" id="' + id + '" role="menu" hidden>' + menuHtml() + '</div>';
    bar.appendChild(el);
    el.addEventListener('click', e => { if (e.target.closest('.ogc-acct__out')) forget(); });
    const btn = el.querySelector('.ogc-acct__btn'), menu = el.querySelector('.ogc-acct__menu');
    // The phone's sheet: its dim backdrop and the sheet itself both go to the end of the page while
    // open. The bar is sticky with a z-index, so anything inside it is layered with the bar: a backdrop
    // on the page would sit over the sheet. Put side by side at the page's end, the sheet is on top.
    let shade = null;
    const set = (open, back) => {
      menu.hidden = !open;
      btn.setAttribute('aria-expanded', String(open));
      el.classList.toggle('is-open', open);
      const sheet = open && sheetMq.matches;
      document.documentElement.classList.toggle('ogc-acct-sheet', sheet);
      if (sheet && !shade) {
        shade = document.createElement('div');
        shade.className = 'ogc-acct-shade';
        shade.addEventListener('click', () => set(false, true));
        document.body.appendChild(shade);
        menu.classList.add('ogc', 'is-sheet');
        document.body.appendChild(menu);
      }
      if (!sheet && shade) { shade.remove(); shade = null; menu.classList.remove('ogc', 'is-sheet'); el.appendChild(menu); }
      if (open) { const f = menu.querySelector('a'); if (f) f.focus(); }
      else if (back) btn.focus();
    };
    btn.addEventListener('click', e => { e.stopPropagation(); set(menu.hidden, true); });
    menu.addEventListener('click', e => {
      if (e.target.closest('[data-acct-close]')) { set(false, true); return; }
      const a = e.target.closest('a');
      if (a && a.hasAttribute('data-acct-others')) {
        e.preventDefault();
        set(false);
        ask('Sign out other devices?', 'Sign out').then(y => { if (y) location.href = a.href; else btn.focus(); });
        return;
      }
      if (a && a.hasAttribute('data-acct-out')) forget();
    });
    menu.addEventListener('keydown', e => {
      const links = Array.from(menu.querySelectorAll('a, button')).filter(x => x.offsetParent !== null), i = links.indexOf(document.activeElement);
      if (e.key === 'ArrowDown') { e.preventDefault(); links[(i + 1) % links.length].focus(); }
      if (e.key === 'ArrowUp') { e.preventDefault(); links[(i - 1 + links.length) % links.length].focus(); }
      if (e.key === 'Escape') { e.preventDefault(); set(false, true); }
      if (e.key === 'Tab' && !e.shiftKey && i === links.length - 1) set(false);
    });
    document.addEventListener('click', e => { if (!menu.hidden && !el.contains(e.target) && !menu.contains(e.target)) set(false); });
    // Turned to a laptop's width with the sheet open: back into the bar.
    sheetMq.addEventListener('change', () => { if (!menu.hidden) set(false); });
  }

  // The pages draw their bars after their data arrives, and again when they change: mount each time.
  let queued = false;
  const scan = () => { queued = false; document.querySelectorAll('.ws-bar__in, .rf-who:not(.rf-who--form)').forEach(mount); };
  const watch = new MutationObserver(() => { if (!queued) { queued = true; requestAnimationFrame(scan); } });
  const start = () => { scan(); watch.observe(document.body, { childList: true, subtree: true }); };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start); else start();
})();
