/*
 * ogc-members.js — Members: who can sign in for a year, and on which committee (signin area). One
 * component with two layouts, on the COA's year page, the Members page (/annual-conference/members/
 * ?year=) and the webmasters' page, from the server's list (/years/{y}/members).
 *
 * Where it goes: any element with data-ogc-members="2027" (data-om-full: the whole list, as on the
 * Members page and the webmasters' page); until the year area draws that slot, it fills the year
 * page's Members section (.yr-people).
 *
 *   Invite first (for the COA and webmasters): addresses become chips as they're typed or pasted
 *   ("Ruth Kinsey <ruth@example.com>", Outlook's "Kinsey, Ruth <…>", a spreadsheet column); a likely
 *   typo asks "Did you mean gmail.com?" (one tap fixes it; Invite asks once more before sending it as
 *   typed). Then the committee, as pills of the year's list (committees.csv) plus New committee, and
 *   Head; where they'll start ("Starts on · Lodging"). Webmasters also choose COA or Helper and how
 *   long.
 *   The list (a phone, or the year page's side column): COA, then each committee, each group with its
 *   own end date under its label ("Until Jun 1, 2028"); a person's own date only when it differs. One
 *   line a person: the name, then one status ("Invited today", "Signed in Oct 10", "Invite expired").
 *   An address never signed in that looks mistyped says "Check email · gmail.com?" with Fix. Tapping a
 *   row opens its address, committee and actions (Edit, Resend, Renew, Remove); while Edit is open only
 *   Save and Cancel show. Remove leaves "Removed · Undo" for 10 seconds.
 *   When the card is 860 px wide or more (a laptop's Members page) and the viewer may invite, the whole
 *   list is a table (Name · Email · Committee · Status · Invited by · Until; a column with nothing in it
 *   isn't drawn). Its actions live in the chosen row's panel, which opens beside the table only once a
 *   row is chosen; until then the table has the card's whole width. No cell is ever cut off.
 *   A viewer who may not invite (a helper) gets the list as a directory at every width: their own
 *   committee first, then the COA and the others (docs/23); no empty columns, no panel.
 *   On the year page and the webmasters' page, a long list (more than 8) is a summary: "14 members · 8
 *   not signed in" and Manage, which opens the Members page.
 *   History (who did what, in words) is for those who may invite.
 *
 * The screen offers only what the server allows this person (each row's "can"); the server checks
 * again. A helper sees each other member's name, committee and one coarse status. Nothing here is kept
 * in the browser.
 */
(function () {
  'use strict';
  const W = window.OGC_WP || {};
  if (!W.api || !W.me) return;
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
  // An address that breaks after its @ (never mid-word; a very long name before the @ still wraps).
  const wbr = e => esc(e).replace('@', '@<wbr>');
  const suggest = e => (window.OGC_AUTH && OGC_AUTH.suggest ? OGC_AUTH.suggest(e) : '');
  const cache = {};
  const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  // The table needs room: the card's own width, not the window's (the webmasters' page puts it in a
  // column). 1024 px of window leaves about 900 for the card.
  const WIDE_AT = 860;
  const COMPACT_AT = 8;

  /* ------------------------------------------------------------ reading addresses */

  const EMAIL = /^[^\s@<>()",;]+@[^\s@<>()",;.]+(\.[^\s@<>()",;.]+)+$/;
  // "Daniel Miller <dan@x.com>", "dan@x.com", "Daniel Miller	dan@x.com" (a spreadsheet's columns).
  function readOne(piece) {
    piece = piece.trim().replace(/^["']|["']$/g, '');
    if (!piece) return null;
    let name = '', email = '';
    const m = piece.match(/^(.*?)<\s*([^>]+?)\s*>\s*$/);
    if (m) { name = m[1].trim().replace(/^["']|["']$/g, ''); email = m[2]; }
    else {
      const words = piece.split(/\s+/), i = words.findIndex(w => w.indexOf('@') > 0);
      if (i >= 0) { email = words.splice(i, 1)[0]; name = words.join(' '); } else email = piece;
    }
    email = email.replace(/^mailto:/i, '').replace(/[()[\]<>"']/g, '').replace(/\.+$/, '').trim().toLowerCase();
    return { name: name.trim(), email, ok: EMAIL.test(email), raw: piece };
  }
  function readMany(text) {
    // People are separated by line breaks, commas and semicolons (not inside <…>). A tab is a
    // spreadsheet's next column (the name beside the address), so it's only a space.
    const out = [];
    let cur = '', depth = 0;
    for (const ch of String(text).replace(/\t/g, ' ')) {
      if (ch === '<') depth++;
      if (ch === '>') depth = Math.max(0, depth - 1);
      if (!depth && /[\n\r;,]/.test(ch)) { out.push(cur); cur = ''; } else cur += ch;
    }
    out.push(cur);
    // Outlook's "Wenger, Ezra <ezra@x.com>": a piece with no @ before a "First <address>" piece is the
    // surname, so the two are one person, "Ezra Wenger".
    for (let i = 0; i < out.length - 1; i++) {
      const a = out[i].trim(), nx = out[i + 1].trim(), m = nx.match(/^([^@<]*?)\s*<[^>]+@[^>]+>$/);
      if (a && a.indexOf('@') < 0 && m && m[1]) { out[i + 1] = m[1] + ' ' + a.replace(/^["']|["']$/g, '') + ' ' + nx.slice(nx.indexOf('<')); out[i] = ''; }
    }
    return out.map(readOne).filter(Boolean);
  }
  const key = n => String(n || '').toLowerCase().replace(/\s+/g, ' ').trim().replace(/^the\s+|\s+committee$/g, '').trim();

  /* ------------------------------------------------------------ words */

  // One status a row: the full one for those who invite, a coarse one (from the server's `state`)
  // for everyone else, and nothing for an active member they can't manage (active is the usual).
  function status(m) {
    if (m.state === 'expired' || m.expired) return 'Expired';
    if (!('invited' in m)) return m.state === 'invited' ? 'Invited' : '';
    if (m.signed_in) return 'Signed in ' + m.signed_in;
    if (m.invite_expired) return 'Invite expired';
    if (m.invited) return 'Invited ' + m.invited;
    return 'Not invited';
  }
  const fixDomain = m => m.suspect ? m.suspect.slice(m.suspect.indexOf('@') + 1) : '';
  const untilOf = (d, coa) => (d.until && typeof d.until === 'object' ? d.until[coa ? 'coa' : 'helper'] : d.until) || '';
  const untilWords = u => /after the Conference/.test(u) ? 'Ends ' + u : 'Until ' + u;
  const committeeWords = m => m.role === 'coa' ? 'COA' : [m.committee || m.helps || 'Helper'].concat(m.head ? ['Head'] : []).join(' · ');
  const named = m => m.name || m.email;

  /* ------------------------------------------------------------ the list (a phone; the year page) */

  function groups(d) {
    const coa = d.members.filter(m => m.role === 'coa'), help = d.members.filter(m => m.role !== 'coa');
    // A helper's own committee comes first (a directory: theirs, then the others).
    const me = !d.viewer.invite ? d.members.find(m => m.you && m.role !== 'coa') : null;
    const mine = me ? key(me.committee || String(me.helps || '').split(',')[0]) : '';
    const by = new Map();
    help.forEach(m => { const label = m.committee || String(m.helps || '').split(',')[0].trim(), k = key(label); if (!by.has(k)) by.set(k, { label, list: [] }); by.get(k).list.push(m); });
    const order = (d.committees || []).map(c => c.key);
    const ranked = Array.from(by.entries()).filter(e => e[0]).sort((a, b) => {
      const ia = order.indexOf(a[0]), ib = order.indexOf(b[0]);
      return (ia < 0 ? 999 : ia) - (ib < 0 ? 999 : ib) || a[1].label.localeCompare(b[1].label);
    });
    const none = by.get('');
    const out = [];
    const own = mine ? ranked.filter(e => e[0] === mine) : [];
    own.forEach(e => out.push({ label: e[1].label, key: e[0], list: e[1].list }));
    if (coa.length) out.push({ label: 'COA', key: '', coa: true, list: coa });
    ranked.filter(e => own.indexOf(e) < 0).forEach(e => out.push({ label: e[1].label, key: e[0], list: e[1].list }));
    if (none) out.push({ label: ranked.length ? 'Other helpers' : 'Helpers', key: '', list: none.list });
    // Each group's own end date: the one most of it shares (said once, under its label); a person's
    // own date shows on their line only when it differs.
    out.forEach(g => {
      const n = {};
      g.list.filter(m => !m.expired && m.until).forEach(m => { n[m.until] = (n[m.until] || 0) + 1; });
      g.until = Object.keys(n).sort((a, b) => n[b] - n[a])[0] || '';
      g.list.forEach(m => { m._gu = g.until; });
    });
    return out;
  }
  function row(m, d, g) {
    const full = 'invited' in m || m.you;
    const own = m.until && m.until !== (m._gu || untilOf(d, m.role === 'coa')) && !m.expired ? untilWords(m.until) : '';
    const st = status(m);
    const meta = [m.head ? 'Head' : ''].concat(own ? [own] : []).concat(st ? [st] : []).filter(Boolean);
    const opens = full && (m.email || actions(m).length);
    const id = 'om-r' + m.id;
    const line = '<span class="om-row__name">' + (m.name ? esc(m.name) : wbr(m.email || m.name)) + '</span>' + (m.you ? '<span class="om-you">You</span>' : '') +
      (meta.length ? '<span class="om-row__meta' + (m.invite_expired || m.state === 'expired' ? ' is-due' : '') + '">' + meta.map(esc).join(' · ') + '</span>' : '');
    const open = d.open === m.id;
    return '<li class="om-row' + (open ? ' is-open' : '') + (d.fresh && d.fresh.indexOf(m.id) >= 0 ? ' is-new' : '') + '" data-id="' + m.id + '">' +
      '<div class="om-row__line">' + (opens ? '<button type="button" class="om-row__btn" data-om="toggle" aria-expanded="' + open + '" aria-controls="' + id + '">' + line + '</button>' : '<div class="om-row__btn om-row__btn--plain">' + line + '</div>') + quick(m) + '</div>' +
      warn(m) +
      (opens ? '<div class="om-more" id="' + id + '"' + (open ? '' : ' hidden') + '>' + detail(m, d) + '</div>' : '') +
      '</li>';
  }
  // An invite past its 7 days: Resend right on the line.
  const quick = m => m.invite_expired && m.can && m.can.resend ? '<button type="button" class="om-act om-row__quick" data-om="resend">Resend</button>' : '';
  // A never-used address that looks mistyped: said on its line, fixed in one tap.
  function warn(m) {
    if (!m.suspect) return '';
    return '<p class="om-warn">Check email · ' + esc(fixDomain(m)) + '?' + (m.can && m.can.email ? ' <button type="button" class="om-act om-warn__fix" data-om="fixmail">Fix</button>' : '') + '</p>';
  }
  function actions(m) {
    const c = m.can || {}, a = [];
    if (c.label || c.name || c.role || c.email) a.push('<button type="button" class="om-act" data-om="edit">Edit</button>');
    if (c.resend && !m.signed_in && !m.expired && !m.invite_expired) a.push('<button type="button" class="om-act" data-om="resend">Resend</button>');
    if (c.renew && (m.expired || m.ending)) a.push('<button type="button" class="om-act" data-om="renew" title="One more year">Renew</button>');
    if (c.remove) a.push('<span class="om-gap"></span><button type="button" class="om-act om-act--remove" data-om="remove">Remove</button>');
    return a;
  }
  // A row opened: its address (unless that's already its name), committee, who invited them, its own
  // end date, then its actions; while it's being edited, only the form (Save, Cancel).
  function detail(m, d) {
    const facts = [];
    if (m.role !== 'coa' && (m.committee || m.helps)) facts.push(committeeWords(m));
    if (m.helps && m.committee && key(m.helps) !== key(m.committee)) facts.push(m.helps);
    if (m.by) facts.push('Invited by ' + m.by);
    if (m.expired) facts.push('Ended ' + m.until);
    else if (m.until && m.until !== (m._gu || untilOf(d, m.role === 'coa'))) facts.push(untilWords(m.until));
    const editing = d.editing === m.id;
    return '<div class="om-detail" data-id="' + m.id + '">' +
      (m.email && m.name ? '<p class="om-more__mail">' + wbr(m.email) + '</p>' : '') +
      (facts.length ? '<p class="om-more__facts">' + facts.map(esc).join(' · ') + '</p>' : '') +
      (editing ? editor(m, d) : (actions(m).length ? '<div class="om-row__acts">' + actions(m).join('') + '</div>' : '')) +
      '</div>';
  }

  /* ------------------------------------------------------------ committee pills (Invite and Edit) */

  function committeePills(d, chosen, head, uid) {
    // A–Z, so a committee is found where it's looked for.
    const list = (d.committees || []).slice().sort((a, b) => String(a.name).localeCompare(String(b.name), 'en', { sensitivity: 'base' }));
    return '<div class="om-field om-coms" role="group" aria-labelledby="' + uid + '-cl" aria-describedby="' + uid + '-ch"><span id="' + uid + '-cl">Committee</span><span class="om-pills">' +
      list.map(c => '<label class="om-pill"><input type="checkbox" name="committee" value="' + esc(c.key) + '"' + (chosen.indexOf(c.key) >= 0 ? ' checked' : '') + '><span>' + esc(c.name) + '</span></label>').join('') +
      '<label class="om-pill om-pill--new"><input type="checkbox" name="newc" value="1"><span>New committee</span></label></span>' +
      '<small class="om-field__help" id="' + uid + '-ch">One or more</small>' +
      '<input class="om-newc" name="new_committee" maxlength="60" autocomplete="off" placeholder="Name" aria-label="New committee" hidden>' +
      // Head of the committee: its own switch, shown once a committee is picked (never one of the pills).
      '<label class="om-head"' + (chosen.length ? '' : ' hidden') + '><input type="checkbox" name="head" value="1" role="switch"' + (head ? ' checked' : '') + '><span class="om-head__sw" aria-hidden="true"></span><span>Head of committee</span></label></div>';
  }
  // Head shows once a committee (or a new one) is picked.
  const headShow = f => { const h = f && f.querySelector('.om-head'); if (!h) return; const any = chosenOf(f).length || !!f.querySelector('input[name="newc"]:checked'); h.hidden = !any; if (!any) h.querySelector('input').checked = false; };
  const chosenOf = f => Array.from(f.querySelectorAll('input[name="committee"]:checked')).map(i => i.value);

  function editor(m, d) {
    const uid = 'om-e' + m.id, c = m.can || {};
    return '<form class="om-edit" data-om-edit="' + m.id + '">' +
      (c.name ? '<label class="om-field"><span>Name</span><input name="name" value="' + esc(m.name) + '" maxlength="60" autocomplete="off"></label>' : '') +
      (c.email ? '<label class="om-field"><span>Email</span><input name="email" type="email" value="' + esc(m.email) + '" maxlength="190" autocomplete="off" autocapitalize="none" spellcheck="false"><small class="om-field__help">A new address gets its own invite</small></label>' : '') +
      (c.role ? '<div class="om-field" role="radiogroup" aria-label="Role"><span>Role</span><span class="om-pills">' + [['coa', 'COA'], ['helper', 'Helper']].map(r => '<label class="om-pill"><input type="radio" name="role" value="' + r[0] + '"' + (m.role === r[0] ? ' checked' : '') + '><span>' + r[1] + '</span></label>').join('') + '</span></div>' : '') +
      (c.label && m.role !== 'coa' ? committeePills(d, m.committees || [], m.head, uid) : '') +
      '<p class="om-edit__btns"><button type="submit" class="wk-btn wk-btn--small">Save</button><button type="button" class="om-act" data-om="cancel">Cancel</button></p></form>';
  }

  function inviteForm(d) {
    const y = d.year, v = d.viewer, inv = d.inv || {};
    const pills = (name, opts, cur, label) => '<div class="om-field" role="radiogroup" aria-label="' + label + '"><span>' + label + '</span><span class="om-pills">' +
      opts.map(o => '<label class="om-pill"><input type="radio" name="' + name + '" value="' + o[0] + '"' + (String(o[0]) === String(cur) ? ' checked' : '') + '><span>' + o[1] + '</span></label>').join('') + '</span></div>';
    const role = inv.role || 'helper';
    const years = inv.years || (d.years && d.years[role]) || 1;
    return '<form class="om-invite" data-om-invite novalidate>' +
      '<label class="om-label" for="om-in-' + y + '">Invite</label>' +
      '<div class="om-chips" data-om-chips><input id="om-in-' + y + '" class="om-chipin" type="email" multiple autocomplete="off" autocapitalize="none" spellcheck="false" placeholder="Emails" aria-describedby="om-in-help-' + y + '"></div>' +
      '<p class="om-hint" id="om-in-help-' + y + '">Paste a list, or names like Ruth Kinsey &lt;ruth@example.com&gt;</p>' +
      '<div class="om-invite__more" hidden>' +
      (v.roles ? pills('role', [['coa', 'COA'], ['helper', 'Helper']], role, 'Role') + pills('years', [[1, '1 year'], [2, '2 years'], [3, '3 years']], years, 'Access') : '') +
      '<div class="om-invite__com"' + (role === 'coa' ? ' hidden' : '') + '>' + committeePills(d, inv.committees || [], inv.head, 'om-i' + y) + '</div>' +
      '<p class="om-hint" data-om-land hidden></p>' +
      '<p class="om-invite__btns"><button type="submit" class="wk-btn wk-btn--small" data-om-go disabled>Invite</button><button type="button" class="om-act" data-om="preview">Preview email</button></p>' +
      '</div></form>';
  }

  /* ------------------------------------------------------------ the table (1024 px and wider) */

  function table(d) {
    const rows = groups(d).reduce((a, g) => a.concat(g.list), []);
    // A column is drawn only when some row has something in it (Email, Status, Invited by, Until).
    const until = m => m.expired ? 'Ended ' + m.until : (m.until || '');
    const has = f => rows.some(m => !!f(m));
    // With a member's panel open, Invited by and Until give way (the panel says both), so nothing scrolls.
    const open = d.members.some(m => m.id === d.open);
    const cols = { mail: has(m => (m.email && m.name) || m.suspect), st: has(status), by: !open && has(m => m.by), until: !open && has(until) };
    const tr = m => {
      const c = m.can || {}, on = d.open === m.id, st = status(m);
      return '<tr class="om-tr' + (on ? ' is-on' : '') + (d.fresh && d.fresh.indexOf(m.id) >= 0 ? ' is-new' : '') + '" data-id="' + m.id + '"' + (on ? ' aria-selected="true"' : '') + '>' +
        '<th scope="row"><button type="button" class="om-tr__name" data-om="pick" aria-expanded="' + on + '">' + esc(m.name || m.email) + '</button>' + (m.you ? ' <span class="om-you">You</span>' : '') + '</th>' +
        (cols.mail ? '<td class="om-td--mail">' + (m.email && m.name ? esc(m.email) : '') + (m.suspect ? '<span class="om-warn om-warn--cell">Check email · ' + esc(fixDomain(m)) + '?' + (c.email ? ' <button type="button" class="om-act" data-om="fixmail">Fix</button>' : '') + '</span>' : '') + '</td>' : '') +
        '<td>' + esc(committeeWords(m)) + '</td>' +
        (cols.st ? '<td class="om-td--nw' + (m.invite_expired || m.expired ? ' is-due' : '') + '">' + esc(st) + '</td>' : '') +
        (cols.by ? '<td class="om-td--nw">' + esc(m.by || '') + '</td>' : '') +
        (cols.until ? '<td class="om-td--nw">' + esc(until(m)) + '</td>' : '') + '</tr>';
    };
    const sel = d.members.find(m => m.id === d.open);
    return '<div class="om-wide' + (sel ? ' has-side' : '') + '"><div class="om-tablewrap"><table class="om-table"><thead><tr><th scope="col">Name</th>' + (cols.mail ? '<th scope="col">Email</th>' : '') + '<th scope="col">Committee</th>' +
      (cols.st ? '<th scope="col">Status</th>' : '') + (cols.by ? '<th scope="col">Invited by</th>' : '') + (cols.until ? '<th scope="col">Until</th>' : '') + '</tr></thead><tbody>' +
      rows.map(tr).join('') + '</tbody></table></div>' +
      '<aside class="om-side" aria-live="polite"' + (sel ? '' : ' hidden') + '>' + side(sel, d) + '</aside></div>';
  }
  // The chosen member, beside the table: their address, committee, who invited them, and the actions
  // (Edit, Resend, Renew, Remove). Close puts the table back to the card's whole width.
  function side(m, d) {
    if (!m) return '';
    // The table's Invited by and Until give way while the panel is open, so the panel says the date.
    const own = m.until && !m.expired ? '<p class="om-more__facts">' + esc(untilWords(m.until)) + '</p>' : '';
    return '<div class="om-side__in" data-id="' + m.id + '"><div class="om-side__top"><h3 class="om-side__h">' + (m.name ? esc(m.name) : wbr(m.email)) + '</h3><button type="button" class="ogc-reauth__x om-side__x" data-om="pick" aria-label="Close">×</button></div>' + warn(m) + detail(Object.assign({}, m, { _gu: m.until }), d).replace('<div class="om-row__acts">', own + '<div class="om-row__acts">') + '</div>';
  }

  /* ------------------------------------------------------------ drawing */

  function draw(sec, d) {
    const y = d.year, v = d.viewer;
    // The whole list on the Members page (and any slot that asks for it, but the webmasters' page, which
    // shows the year page's summary and Manage, so Activity stays in reach).
    const full = W.page === 'members' || (sec.hasAttribute('data-om-full') && W.page !== 'admin');
    const compact = !full && d.members.length > COMPACT_AT;
    // The table is for those who manage the list; a helper reads it as a directory at every width.
    const wide = full && v.invite && sec.clientWidth >= WIDE_AT && d.members.length > 0;
    sec.classList.toggle('is-wide', wide);
    // The Members page has its own Members heading; everywhere else the card draws one.
    const head = W.page === 'members' ? '' : '<div class="om-top"><h2 class="om-h" id="om-h-' + y + '">Members</h2></div>';
    const what = 'Every member sees and changes every ' + y + ' page' + (v.invite ? '' : ' · The Committee of Arrangements adds and removes members');
    let html = head + '<p class="om-help">' + esc(what) + '</p>' + (v.invite ? inviteForm(d) : '') + '<p class="om-status" role="status" aria-live="polite"></p>';
    if (!d.members.length) html += '<p class="om-blank">No members yet</p>';
    else if (compact) {
      const n = d.members.length, out = d.members.filter(m => m.state === 'invited').length, ex = d.members.filter(m => m.invite_expired).length;
      const words = [n + ' members'];
      if (out) words.push(out + ' not signed in');
      if (ex) words.push(ex + ' invite' + (ex === 1 ? '' : 's') + ' expired');
      html += '<div class="om-sum"><p class="om-sum__n">' + esc(words.join(' · ')) + '</p><a class="om-act om-sum__go" href="' + esc(d.page || '#') + '">Manage</a></div>';
    } else if (wide) {
      html += table(d);
    } else {
      html += groups(d).map(g => {
        const u = g.until;
        return '<h3 class="om-k">' + esc(g.label) + '</h3>' + (u ? '<p class="om-until">' + esc(untilWords(u)) + '</p>' : '') + '<ul class="om-list">' + g.list.map(m => row(m, d, g)).join('') + '</ul>';
      }).join('');
    }
    if (!compact && (v.invite || v.webmaster)) {
      html += '<p class="om-foot">' + (v.invite ? '<button type="button" class="om-act" data-om="history" aria-expanded="false">History</button>' : '<span></span>') +
        (v.webmaster ? '<span class="om-addr"><span>' + wbr(d.signin) + '</span><button type="button" class="om-act" data-om="copy" title="The sign-in page, for a lost link">Copy</button></span>' : '') + '</p><div class="om-hist" hidden></div>';
    }
    sec.innerHTML = html;
    if (head) sec.setAttribute('aria-labelledby', 'om-h-' + y);
    if (d.fresh && d.fresh.length && !reduce) setTimeout(() => sec.querySelectorAll('.om-row.is-new, .om-tr.is-new').forEach(li => li.classList.remove('is-new')), 1200);
    d.fresh = [];
  }
  function skeleton(sec) {
    sec.innerHTML = (W.page === 'members' ? '' : '<div class="om-top"><h2 class="om-h">Members</h2></div>') +
      '<span class="om-sk om-sk--line"></span><span class="om-sk om-sk--box"></span><span class="om-sk om-sk--row"></span><span class="om-sk om-sk--row"></span><p class="ogc-sr" role="status">Loading</p>';
  }

  /* ------------------------------------------------------------ one section */

  function setup(sec, year) {
    if (sec.__om) return;
    sec.__om = true;
    sec.classList.add('ogc-members');
    sec.setAttribute('data-ogc-members', year);
    let d = cache[year], chips = [], asked = {}, editTypo = {};
    const say = (t) => { const s = sec.querySelector('.om-status'); if (s) { s.textContent = ''; s.textContent = t; } };
    const firstOpen = +new URLSearchParams(location.search).get('open') || 0;
    const load = async () => {
      try { d = cache[year] = Object.assign(await W.api('GET', 'years/' + year + '/members'), { fresh: (d && d.fresh) || [], open: d ? d.open : firstOpen, inv: d && d.inv, editing: 0 }); }
      catch (e) { sec.innerHTML = (W.page === 'members' ? '' : '<div class="om-top"><h2 class="om-h">Members</h2></div>') + '<p class="om-blank">' + (e.status === 403 || e.status === 401 ? 'Members only' : 'Couldn’t load · <button type="button" class="om-act" data-om="reload">Retry</button>') + '</p>'; return; }
      paint();
      if (firstOpen && d.open === firstOpen) { const el = sec.querySelector('[data-id="' + firstOpen + '"]'); if (el) el.scrollIntoView({ block: 'center' }); }
    };
    // What's chosen in Invite survives a redraw (a Resend or Remove elsewhere on the card).
    const keepInvite = () => {
      const f = sec.querySelector('[data-om-invite]');
      if (!f || !d) return;
      const r = f.querySelector('input[name="role"]:checked'), y = f.querySelector('input[name="years"]:checked'), h = f.querySelector('input[name="head"]');
      d.inv = { role: r ? r.value : '', years: y ? y.value : '', committees: chosenOf(f), head: h && h.checked };
    };
    const paint = () => { keepInvite(); draw(sec, d); drawChips(); landing(); };
    const member = id => d.members.find(m => m.id === +id);
    const wide = () => sec.classList.contains('is-wide');

    // Where a helper on the chosen committee starts: the first the server knows a page for.
    const landing = () => {
      const f = sec.querySelector('[data-om-invite]'), p = f && f.querySelector('[data-om-land]');
      if (!p) return;
      const role = f.querySelector('input[name="role"]:checked');
      const nc = f.querySelector('input[name="newc"]:checked') ? key(f.elements.new_committee.value) : '';
      const l = role && role.value === 'coa' ? '' : chosenOf(f).concat(nc ? [nc] : []).map(k => (d.landings || {})[k]).find(Boolean);
      p.hidden = !l; p.textContent = l ? 'Starts on · ' + l : '';
    };
    // Chips: what's typed or pasted, each checked against the list and for a likely typo.
    const drawChips = () => {
      const box = sec.querySelector('[data-om-chips]');
      if (!box) return;
      box.querySelectorAll('.om-chip').forEach(c => c.remove());
      const inp = box.querySelector('.om-chipin');
      chips.forEach((c, i) => {
        const m = d.members.find(x => x.email === c.email);
        c.member = m ? m.id : 0;
        c.fix = c.ok && !m ? suggest(c.email) : '';
        const el = document.createElement('span');
        el.className = 'om-chip' + (!c.ok ? ' is-bad' : m ? ' is-member' : c.fix ? ' is-suspect' : '');
        const dom = c.fix ? c.fix.slice(c.fix.indexOf('@') + 1) : '';
        el.innerHTML = '<span class="om-chip__who">' + (c.ok ? (c.name ? esc(c.name) + ' · ' : '') + wbr(c.email) : esc(c.raw)) + '</span>' +
          (!c.ok ? '<small>Not an email</small>'
            : m ? '<small>' + (m.you ? 'You' : 'Member') + (m.can && m.can.resend && !m.removed && !m.you && !m.signed_in ? ' · <button type="button" class="om-chip__do" data-om-chipresend="' + i + '">Resend</button>' : '') + '</small>'
            : c.fix ? '<small>Did you mean <button type="button" class="om-chip__do" data-om-chipfix="' + i + '">' + esc(dom) + '</button>?</small>' : '') +
          '<button type="button" class="om-chip__x" data-om-chipx="' + i + '" aria-label="Remove ' + esc(c.email || c.raw) + '">×</button>';
        box.insertBefore(el, inp);
      });
      const go = sec.querySelector('[data-om-go]'), n = chips.filter(c => c.ok && !c.member).length;
      if (go) { go.disabled = !n; go.textContent = n ? 'Invite ' + n : 'Invite'; }
      showMore();
    };
    const showMore = () => {
      const more = sec.querySelector('.om-invite__more'), inp = sec.querySelector('.om-chipin');
      if (more) more.hidden = !(chips.length || (inp && inp.value.trim()));
    };
    const commit = (text, keepTail) => {
      let t = String(text);
      let tail = '';
      if (keepTail) { const m = t.match(/[^\n\r;,\t ]*$/); tail = m ? m[0] : ''; t = t.slice(0, t.length - tail.length); }
      const got = readMany(t).filter(p => !chips.some(c => c.email === p.email && p.ok));
      chips = chips.concat(got);
      drawChips();
      return tail;
    };
    // Open a member: beside the table on a laptop, under its line on a phone. One at a time.
    const openRow = (id, keep) => {
      const was = d.open === id && !keep;
      d.open = was ? 0 : id;
      d.editing = 0;
      if (wide()) {
        sec.querySelectorAll('.om-tr').forEach(r => { const on = +r.dataset.id === d.open; r.classList.toggle('is-on', on); if (on) r.setAttribute('aria-selected', 'true'); else r.removeAttribute('aria-selected'); const b = r.querySelector('[data-om="pick"]'); if (b) b.setAttribute('aria-expanded', String(on)); });
        // The table gains or loses its last columns with the panel: drawn again, focus kept on the row.
        paint();
        const b = d.open ? sec.querySelector('.om-side [data-om="pick"]') : sec.querySelector('.om-tr[data-id="' + id + '"] [data-om="pick"]');
        if (b) b.focus();
        return;
      }
      sec.querySelectorAll('.om-row.is-open').forEach(r => { r.classList.remove('is-open'); const x = r.querySelector('.om-more'); if (x) x.hidden = true; const t = r.querySelector('[data-om="toggle"]'); if (t) t.setAttribute('aria-expanded', 'false'); });
      const li = d.open && sec.querySelector('.om-row[data-id="' + d.open + '"]');
      if (li) { li.classList.add('is-open'); const x = li.querySelector('.om-more'); if (x) { x.hidden = false; x.innerHTML = detail(member(d.open), d); } const t = li.querySelector('[data-om="toggle"]'); if (t) t.setAttribute('aria-expanded', 'true'); }
    };
    // Edit on or off: the opened member's detail drawn again (its actions give way to the form).
    const editRow = (id, on) => {
      d.editing = on ? id : 0;
      const host = wide() ? sec.querySelector('.om-side .om-detail') : sec.querySelector('.om-row[data-id="' + id + '"] .om-detail');
      if (host) host.outerHTML = detail(member(id), d);
      const f = on && sec.querySelector('[data-om-edit="' + id + '"]');
      if (f) { const first = f.querySelector('input'); if (first) first.focus(); }
      else { const b = sec.querySelector('[data-id="' + id + '"] [data-om="edit"]'); if (b) b.focus(); }
    };

    sec.addEventListener('input', e => {
      const f = e.target.closest('[data-om-invite]');
      if (f && e.target.name === 'new_committee') { landing(); return; }
      if (!e.target.classList.contains('om-chipin')) return;
      const v = e.target.value;
      // A separator after an address makes it a chip; the rest stays to type.
      if (/[;\n]/.test(v) || (/,/.test(v) && /@/.test(v)) || (/\s$/.test(v) && /@/.test(v) && !/</.test(v))) e.target.value = commit(v, true);
      showMore();
    });
    sec.addEventListener('change', e => {
      const t = e.target, f = t.closest('form');
      if (!f) return;
      if (t.name === 'newc') { const n = f.querySelector('.om-newc'); if (n) { n.hidden = !t.checked; if (t.checked) n.focus(); } }
      if (t.name === 'committee' || t.name === 'newc') headShow(f);
      if (f.matches('[data-om-invite]')) {
        if (t.name === 'role') {
          // Access follows the role's default until a webmaster picks it; the COA has no committee.
          if (!d.yearsPicked && d.years) { const r = f.querySelector('input[name="years"][value="' + d.years[t.value] + '"]'); if (r) r.checked = true; }
          const c = f.querySelector('.om-invite__com'); if (c) c.hidden = t.value === 'coa';
        }
        if (t.name === 'years') d.yearsPicked = true;
        landing();
      }
    });
    sec.addEventListener('paste', e => {
      if (!e.target.classList.contains('om-chipin')) return;
      const t = (e.clipboardData || window.clipboardData).getData('text');
      if (!t) return;
      e.preventDefault();
      commit(e.target.value + '\n' + t);
      e.target.value = '';
      const n = chips.length;
      say(n + (n === 1 ? ' address' : ' addresses'));
    });
    sec.addEventListener('keydown', e => {
      const t = e.target;
      if (!t.classList || !t.classList.contains('om-chipin')) return;
      if (e.key === 'Enter') { e.preventDefault(); if (t.value.trim()) { commit(t.value); t.value = ''; } else { const f = t.closest('form'); if (f && !f.querySelector('[data-om-go]').disabled) f.requestSubmit(); } }
      if (e.key === 'Backspace' && !t.value && chips.length) { chips.pop(); drawChips(); }
    });
    sec.addEventListener('focusout', e => { if (e.target.classList && e.target.classList.contains('om-chipin') && e.target.value.trim()) { commit(e.target.value); e.target.value = ''; } });

    sec.addEventListener('submit', async e => {
      e.preventDefault();
      const f = e.target;
      if (f.matches('[data-om-invite]')) {
        const inp = f.querySelector('.om-chipin');
        if (inp.value.trim()) { commit(inp.value); inp.value = ''; }
        const go = chips.filter(c => c.ok && !c.member);
        if (!go.length) { say(chips.some(c => !c.ok) ? 'Not an email · Check the red ones' : 'Add an email'); inp.focus(); return; }
        // A likely typo goes to whoever owns that domain: ask once before sending it as typed.
        const sus = go.filter(c => c.fix && !asked[c.email]);
        if (sus.length) {
          sus.forEach(c => { asked[c.email] = true; });
          say('Check ' + sus.map(c => c.email).join(', ') + ' · Invite again to send as typed');
          const b = sec.querySelector('[data-om-chipfix]'); if (b) b.focus();
          return;
        }
        const nc = f.querySelector('input[name="newc"]:checked') ? f.elements.new_committee.value.trim() : '';
        if (f.querySelector('input[name="newc"]:checked') && !nc) { say('Name the new committee'); f.elements.new_committee.focus(); return; }
        const btn = f.querySelector('[data-om-go]');
        btn.disabled = true; btn.textContent = 'Sending';
        const role = f.querySelector('input[name="role"]:checked'), years = f.querySelector('input[name="years"]:checked'), coa = role && role.value === 'coa';
        keepInvite();
        try {
          const r = await W.api('POST', 'years/' + year + '/members', { emails: go.map(c => (c.name ? c.name + ' <' + c.email + '>' : c.email)).join('\n'), role: coa ? 'coa' : 'helper', years: years ? +years.value : 0, committees: coa ? [] : chosenOf(f), new_committee: coa ? '' : nc, head: !coa && !!(f.elements.head && f.elements.head.checked), typos_ok: true });
          const bad = chips.filter(c => !c.ok);
          d = cache[year] = Object.assign(r.list, { fresh: r.added, inv: d.inv, open: d.open, editing: 0 });
          chips = bad; asked = {};
          draw(sec, d); drawChips(); landing();
          const words = [];
          if (r.added.length) words.push(r.added.length + ' invited');
          if (r.already.length) words.push(r.already.length + ' already ' + (r.already.length === 1 ? 'a member' : 'members'));
          if (bad.length) words.push(bad.length + ' not ' + (bad.length === 1 ? 'an email' : 'emails'));
          say(words.join(' · '));
        } catch (err) {
          btn.disabled = false; drawChips();
          say(err.status === 429 || err.status === 409 ? err.message : 'Couldn’t invite · Retry');
        }
        return;
      }
      if (f.matches('[data-om-edit]')) {
        const id = +f.dataset.omEdit, m = member(id), body = {};
        if (f.elements.name) body.name = f.elements.name.value;
        if (f.elements.email && f.elements.email.value.trim().toLowerCase() !== m.email) { body.email = f.elements.email.value.trim(); if (editTypo[body.email]) body.typos_ok = true; }
        if (f.querySelector('.om-coms')) {
          body.committees = chosenOf(f);
          if (f.querySelector('input[name="newc"]:checked')) body.new_committee = f.elements.new_committee.value.trim();
          body.head = !!(f.elements.head && f.elements.head.checked);
        }
        const r = f.querySelector('input[name="role"]:checked');
        if (r && r.value !== m.role) body.role = r.value;
        try {
          const res = await W.api('PATCH', 'members/' + id, body);
          d = cache[year] = Object.assign(res.list, { fresh: [id], open: id, inv: d.inv, editing: 0 });
          paint();
          say(body.email ? 'Saved · Invite sent to ' + body.email : 'Saved');
        } catch (err) {
          // A likely typo in the new address: asked once, sent as typed on the next Save.
          if (err.status === 409 && body.email) editTypo[body.email] = true;
          say(err.message || 'Not saved · Retry');
        }
      }
    });

    sec.addEventListener('click', async e => {
      const b = e.target.closest('[data-om], [data-om-chipx], [data-om-chipresend], [data-om-chipfix], [data-om-undo]');
      if (!b || !sec.contains(b)) return;
      e.stopPropagation();
      if (b.hasAttribute('data-om-chipx')) { chips.splice(+b.dataset.omChipx, 1); drawChips(); const i = sec.querySelector('.om-chipin'); if (i) i.focus(); return; }
      if (b.hasAttribute('data-om-chipfix')) {
        const c = chips[+b.dataset.omChipfix];
        if (c && c.fix) { const was = c.email; c.email = c.fix; c.fix = ''; chips = chips.filter((x, i) => i === +b.dataset.omChipfix || x.email !== c.email); say('Changed to ' + c.email); delete asked[was]; }
        drawChips();
        const i = sec.querySelector('.om-chipin'); if (i) i.focus();
        return;
      }
      if (b.hasAttribute('data-om-chipresend')) {
        const c = chips[+b.dataset.omChipresend];
        try { await W.api('POST', 'members/' + c.member + '/resend'); say('Sent · ' + c.email); chips.splice(+b.dataset.omChipresend, 1); drawChips(); }
        catch (err) { say(err.status === 429 ? 'Sent · Just now' : 'Couldn’t send · Retry'); }
        return;
      }
      if (b.hasAttribute('data-om-undo')) {
        const id = +b.dataset.omUndo;
        try { const r = await W.api('PATCH', 'members/' + id, { restore: true }); d = cache[year] = Object.assign(r.list, { fresh: [id], open: id, inv: d.inv, editing: 0 }); paint(); say('Restored'); }
        catch (err) { say('Couldn’t undo'); }
        return;
      }
      const what = b.dataset.om, host = b.closest('[data-id]'), id = host ? +host.dataset.id : 0, m = id ? member(id) : null;
      if (what === 'reload') { load(); return; }
      if ((what === 'toggle' || what === 'pick') && m) { openRow(id); return; }
      if (what === 'fixmail' && m && m.suspect) {
        try {
          const r = await W.api('PATCH', 'members/' + id, { email: m.suspect, typos_ok: true });
          d = cache[year] = Object.assign(r.list, { fresh: [id], open: id, inv: d.inv, editing: 0 });
          paint(); say('Changed to ' + r.member.email + ' · Invite sent');
        } catch (err) { say(err.message || 'Couldn’t change · Retry'); }
        return;
      }
      if (what === 'resend' && m) {
        b.disabled = true;
        try { await W.api('POST', 'members/' + id + '/resend'); }
        catch (err) { if (err.status !== 429) { b.disabled = false; say('Couldn’t send · Retry'); return; } }
        Object.assign(m, { invited: 'today', invite_expired: false });
        d.fresh = [id];
        paint();
        say('Sent · ' + m.email);
        return;
      }
      if (what === 'renew' && m) {
        try { const r = await W.api('PATCH', 'members/' + id, { renew: true }); d = cache[year] = Object.assign(r.list, { fresh: [id], open: id, inv: d.inv, editing: 0 }); paint(); say('Renewed · Until ' + r.member.until); }
        catch (err) { say('Couldn’t renew · Retry'); }
        return;
      }
      if (what === 'edit' && m) { editRow(id, true); return; }
      if (what === 'cancel') { const f = b.closest('[data-om-edit]'); if (f) editRow(+f.dataset.omEdit, false); return; }
      if (what === 'remove' && m) {
        try {
          const r = await W.api('DELETE', 'members/' + id);
          keepInvite();
          d = cache[year] = Object.assign(r.list || d, { fresh: [], open: 0, inv: d.inv, editing: 0 });
          // The row stays as "Removed · Undo" for ten seconds; access has already ended.
          const undo = '<span class="om-row__name">' + esc(named(m)) + '</span><span class="om-row__meta">Removed</span>';
          const tr = sec.querySelector('.om-tr[data-id="' + id + '"]'), li = sec.querySelector('.om-row[data-id="' + id + '"]');
          if (tr) { tr.className = 'om-tr is-removed'; tr.innerHTML = '<td colspan="' + tr.children.length + '"><span class="om-row__btn om-row__btn--plain">' + undo + '</span> <button type="button" class="om-act" data-om-undo="' + id + '">Undo</button></td>'; const s = sec.querySelector('.om-side'), w = sec.querySelector('.om-wide'); if (s) { s.innerHTML = ''; s.hidden = true; } if (w) w.classList.remove('has-side'); }
          else if (li) { li.className = 'om-row is-removed'; li.innerHTML = '<div class="om-row__line"><p class="om-row__btn om-row__btn--plain">' + undo + '</p><button type="button" class="om-act om-row__quick" data-om-undo="' + id + '">Undo</button></div>'; }
          say('Removed · ' + named(m));
          const u = sec.querySelector('[data-om-undo="' + id + '"]'); if (u) u.focus();
          setTimeout(() => { const x = sec.querySelector('[data-om-undo="' + id + '"]'); if (x) paint(); }, 10000);
        } catch (err) { say(err.message && err.status === 400 ? err.message : 'Couldn’t remove · Retry'); }
        return;
      }
      if (what === 'copy') {
        try { await navigator.clipboard.writeText('https://' + d.signin.replace(/^https?:\/\//, '')); } catch (x) { /* shown anyway */ }
        b.textContent = 'Copied'; say('Copied'); setTimeout(() => { b.textContent = 'Copy'; }, 2000);
        return;
      }
      if (what === 'history') {
        const box = sec.querySelector('.om-hist'), open = box.hidden;
        b.setAttribute('aria-expanded', String(open));
        if (!open) { box.hidden = true; return; }
        box.hidden = false; box.innerHTML = '<span class="om-sk om-sk--row"></span><span class="om-sk om-sk--row"></span>';
        try {
          const h = await W.api('GET', 'years/' + year + '/members/history');
          box.innerHTML = h.length ? '<ul class="om-histlist">' + h.map(x => '<li>' + esc(x.words) + (x.n > 1 ? ' <b>× ' + esc(x.n) + '</b>' : '') + ' <small>· ' + esc(x.at) + '</small></li>').join('') + '</ul>' : '<p class="om-hint">Nothing yet</p>';
        } catch (err) { box.innerHTML = '<p class="om-hint">Couldn’t load</p>'; }
        return;
      }
      if (what === 'preview') { preview(sec, year, d); return; }
    });
    // Made wider or narrower past the table's width: the other layout.
    if (window.ResizeObserver) new ResizeObserver(() => { if (d && sec.isConnected && d.viewer && d.viewer.invite && (sec.clientWidth >= WIDE_AT) !== wide() && (W.page === 'members' || (sec.hasAttribute('data-om-full') && W.page !== 'admin'))) paint(); }).observe(sec);

    if (d) paint(); else skeleton(sec);
    load();
  }

  /* ------------------------------------------------------------ the invite, as it's sent */

  async function preview(sec, year, d) {
    const f = sec.querySelector('[data-om-invite]');
    const role = f && f.querySelector('input[name="role"]:checked'), yrs = f && f.querySelector('input[name="years"]:checked');
    const nc = f && f.querySelector('input[name="newc"]:checked') ? f.elements.new_committee.value.trim() : '';
    // The server applies the invite's own rule (a webmaster's years, else the role's default).
    const q = '?role=' + (role ? role.value : 'helper') + (yrs ? '&years=' + yrs.value : '') + (f ? chosenOf(f).map(k => '&committees[]=' + encodeURIComponent(k)).join('') : '') +
      (nc ? '&new_committee=' + encodeURIComponent(nc) : '') + (f && f.elements.head && f.elements.head.checked ? '&head=1' : '');
    let p;
    try { p = await W.api('GET', 'years/' + year + '/members/preview' + q); } catch (e) { return; }
    let dlg = document.getElementById('om-preview');
    if (!dlg) {
      dlg = document.createElement('dialog');
      dlg.id = 'om-preview';
      dlg.className = 'ogc om-dlg';
      document.body.appendChild(dlg);
      dlg.addEventListener('click', e => { if (e.target === dlg || e.target.closest('[data-om-close]')) dlg.close(); const t = e.target.closest('[data-om-tab]'); if (t) tab(t.dataset.omTab); });
    }
    const tab = which => {
      dlg.querySelectorAll('[data-om-tab]').forEach(b => b.setAttribute('aria-selected', String(b.dataset.omTab === which)));
      dlg.querySelector('.om-dlg__html').hidden = which !== 'html';
      dlg.querySelector('.om-dlg__text').hidden = which !== 'text';
    };
    // The plain-text twin is a webmaster's check; the COA sees the email as it arrives.
    const web = d && d.viewer && d.viewer.webmaster;
    dlg.setAttribute('aria-labelledby', 'om-dlg-h');
    dlg.innerHTML = '<div class="om-dlg__top"><h2 id="om-dlg-h">Preview</h2><button type="button" class="ogc-reauth__x" data-om-close aria-label="Close">×</button></div>' +
      '<dl class="om-dlg__meta"><dt>From</dt><dd>' + esc(p.from) + '</dd><dt>Subject</dt><dd>' + esc(p.subject) + '</dd></dl>' +
      (web ? '<div class="om-tabs" role="tablist"><button type="button" role="tab" data-om-tab="html" aria-selected="true">Email</button><button type="button" role="tab" data-om-tab="text" aria-selected="false">Text</button></div>' : '') +
      '<iframe class="om-dlg__html" title="The email" sandbox="allow-popups allow-popups-to-escape-sandbox"></iframe><pre class="om-dlg__text" hidden></pre>';
    dlg.querySelector('iframe').srcdoc = String(p.html).replace('<head>', '<head><base target="_blank">');
    dlg.querySelector('pre').textContent = p.text;
    dlg.showModal();
    dlg.querySelector('[data-om-close]').focus();
  }

  /* ------------------------------------------------------------ where it goes */

  function yearOf(el) {
    const a = el.getAttribute('data-ogc-members');
    if (a && /^\d{4}$/.test(a)) return a;
    const q = new URLSearchParams(location.search).get('year');
    if (q && /^\d{4}$/.test(q)) return q;
    const t = document.querySelector('[data-year][aria-pressed="true"]');
    return t ? t.dataset.year : '';
  }
  function scan() {
    const slots = Array.from(document.querySelectorAll('[data-ogc-members]'));
    // Until the year area draws a slot: its own Members section.
    document.querySelectorAll('.yr-people').forEach(s => { if (slots.indexOf(s) < 0) slots.push(s); });
    // The COA's year page with no Members section at all: one at the end of the page.
    if (W.page === 'year' && !slots.length && !new URLSearchParams(location.search).get('part')) {
      const home = document.querySelector('.yr-home');
      if (home && !home.querySelector('.ogc-members')) { const s = document.createElement('section'); s.className = 'yr-people'; home.appendChild(s); slots.push(s); }
    }
    slots.forEach(s => { const y = yearOf(s); if (y && (!s.__om || s.getAttribute('data-ogc-members') !== y)) { s.__om = false; setup(s, y); } });
  }
  let queued = false;
  const watch = new MutationObserver(() => { if (!queued) { queued = true; requestAnimationFrame(() => { queued = false; scan(); }); } });
  const start = () => { scan(); watch.observe(document.body, { childList: true, subtree: true }); };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start); else start();
  window.OGC_MEMBERS = { mount: (el, year) => setup(el, String(year)) };
})();
