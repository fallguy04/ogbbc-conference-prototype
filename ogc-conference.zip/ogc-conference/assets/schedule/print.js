/*
 * print.js — the printed schedule, drawn as the paper itself: Letter pages of a fixed size, filled by
 * measuring, so what's on screen is exactly what prints. The schedule page shows and prints it; the
 * packet prints it after its cover.
 *
 * One sheet, both sides (A/V's rule): the type steps down (8.6 → 7 pt) until the week fits two
 * pages, and the page break falls where the days fill page 1, so nothing is left to a setting no
 * committee can find. If it still doesn't fit, it says so ("3 pages · Over one sheet").
 *
 * Other printouts from the same rows: Large print (a day a page), Preteens or Youngfolks only (their
 * rows with the meals and services), and Today during the week.
 *
 * Every row is written by one line builder (title, time, printed note, call-in mark, place code at
 * the end), so the columns and the list say the same thing. Data comes from the page
 * (OGC_WP.print, module-print.php); nothing is fetched.
 */
(function () {
  'use strict';
  const O = window.OGC, esc = O.esc, slug = O.slug;
  const OPEN_END = /^(\?|tbd|tba)$/i;
  const SHARED = { meal: 1, worship: 1, council: 1, communion: 1 };
  const AUD = { conference: 'Conference', preteens: 'Preteens', youngfolks: 'Youngfolks' };
  const PHONE = '<svg class="pr-ph" viewBox="0 0 24 24" aria-label="On the call-in line" role="img"><path d="M6.6 3.5h2.6l1.5 4-2 1.3a11 11 0 0 0 6.5 6.5l1.3-2 4 1.5v2.6a2 2 0 0 1-2.2 2A16.5 16.5 0 0 1 4.6 5.7a2 2 0 0 1 2-2.2Z"/></svg>';

  /* ------------------------------------------------------------- words for times */

  // "7 AM", "9:45", "noon", "midnight": words for 12 o'clock, so "12" is never a guess.
  const T = (m, o) => m == null ? '' : O.formatTime(m, Object.assign({ compact: true, words: true }, o));
  const cap = t => t ? t.charAt(0).toUpperCase() + t.slice(1) : t;
  // A range keeps together on its line; lines break only between ranges.
  const nw = t => t ? '<span class="pr-nw">' + esc(t) + '</span>' : '';
  // The separator in running text: a line may break before "·", never after it (the dot is glued to
  // what follows by a no-break space), so no printed line ends with "·".
  const SEP = ' ·\u00a0';
  function range(a, b) {
    if (a == null) return '';
    if (b == null) return cap(T(a));
    const half = x => Math.floor((((x % 1440) + 1440) % 1440) / 720);
    const words = x => { const k = ((x % 1440) + 1440) % 1440; return k === 0 || k === 720; };
    const same = half(a) === half(b) && !words(a) && !words(b);
    return cap((same ? T(a, { noSuffix: true }) : T(a)) + '–' + T(b));
  }
  function whole(it) {
    if (it.start == null) return it.startText + (it.end != null ? '–' + T(it.end) : it.endText && !OPEN_END.test(it.endText) ? '–' + it.endText : '');
    if (it.end == null) return OPEN_END.test(it.endText) ? cap(T(it.start)) + ' until finished' : it.endText ? cap(T(it.start)) + '–' + it.endText : cap(T(it.start));
    return range(it.start, it.end);
  }
  function till(it) {
    if (it.end != null) return 'till ' + T(it.end, { noSuffix: true });
    if (OPEN_END.test(it.endText)) return 'until finished';
    return it.endText ? 'till ' + it.endText : '';
  }
  const startLabel = it => it.start != null ? cap(T(it.start)) : it.startText;

  /* ------------------------------------------------------------- the model */

  const keyOf = (day, title, start) => day + '|' + slug(title) + '|' + (start == null ? '' : start);
  const itemKey = it => keyOf(it.day, it.title, it.start != null ? it.start : slug(it.startText));

  // The keys a schedule row makes, one per day it covers (as buildSchedule spreads it).
  function rowKeys(r, days) {
    const find = v => days.find(d => d.key === slug(v) || d.date === String(v || '').trim() || slug(d.name).slice(0, 3) === slug(v).slice(0, 3));
    const a = find(r.day), b = r.last_day ? find(r.last_day) : a;
    if (!a || !b) return [];
    const t = O.parseTime(r.start), out = [];
    for (let i = days.indexOf(a); i <= days.indexOf(b); i++) out.push(keyOf(days[i].key, r.title, t != null ? t : slug(r.start)));
    return out;
  }

  // Rows changed since the schedule was published, and rows taken out (kept, struck through).
  const CMP = ['day', 'last_day', 'start', 'end', 'title', 'place', 'audience', 'display', 'print_note', 'sort_time'];
  function compare(base, rows, days) {
    const marks = new Map(), gone = [], list = [];
    if (!base) return { marks, gone, list };
    const comp = list => { const n = {}; return list.map(r => { const k = [slug(r.day), slug(r.title), slug(r.audience)].join('|'); n[k] = (n[k] || 0) + 1; return k + '|' + n[k]; }); };
    const bc = comp(base), byId = {}, byComp = {};
    base.forEach((r, i) => { if (r._id) byId[r._id] = i; byComp[bc[i]] = i; });
    const used = new Set();
    comp(rows).forEach((k, i) => {
      const r = rows[i];
      if (!r.title) return;
      const j = r._id && byId[r._id] != null ? byId[r._id] : byComp[k];
      if (j == null) { rowKeys(r, days).forEach(x => marks.set(x, 'new')); list.push({ kind: 'new', r }); return; }
      used.add(j);
      if (CMP.some(c => String(r[c] || '').trim() !== String(base[j][c] || '').trim())) { rowKeys(r, days).forEach(x => marks.set(x, 'changed')); list.push({ kind: 'changed', r, b: base[j] }); }
    });
    base.forEach((r, i) => { if (!used.has(i) && r.title && !/^(desk|nightly)$/.test(slug(r.display))) { gone.push(r); list.push({ kind: 'gone', r }); } });
    return { marks, gone, list };
  }

  // For someone holding an older copy: what changed since Publish, in a line under the header
  // ("Singing · Sat 7 → 7:30 PM; Volleyball · MPF → Y/IAC; Snack · Cancelled"). The rest are marked ●.
  function changesLine(c) {
    const L = c.changes || [];
    if (!L.length) return '';
    const day = v => String(v || '').trim().slice(0, 3);
    const when = r => { const a = O.parseTime(r.start), b = O.parseTime(r.end); return a == null ? String(r.start || '') : b == null ? cap(T(a)) : range(a, b); };
    const one = x => {
      const r = x.r, t = '<b>' + esc(r.title) + '</b>', at = esc(day(r.day) + ' ' + when(r));
      if (x.kind === 'new') return t + SEP + nw(day(r.day) + ' ' + when(r)) + SEP + 'New';
      if (x.kind === 'gone') return t + SEP + '<span class="pr-nw">' + at + '</span>' + SEP + 'Cancelled';
      const b = x.b, bits = [];
      if (b.title !== r.title) bits.push('was “' + esc(b.title) + '”');
      const sameDay = day(b.day) === day(r.day);
      if (!sameDay || when(b) !== when(r)) bits.push(esc((sameDay ? '' : day(b.day) + ' ') + when(b)) + ' → ' + esc((sameDay ? '' : day(r.day) + ' ') + when(r)));
      if (String(b.place || '') !== String(r.place || '')) bits.push(esc(b.place || '–') + ' → ' + esc(r.place || '–'));
      // A printed note added or changed is given ("Snack · “Bring a cup”"); one taken off just changed it.
      if (String(b.print_note || '').trim() !== String(r.print_note || '').trim() && String(r.print_note || '').trim()) bits.push('“' + esc(tidy(r.print_note)) + '”');
      return bits.length ? t + SEP + bits.join(SEP) : t + SEP + 'Changed';
    };
    const shown = L.slice(0, 5).map(one), more = L.length - shown.length;
    // On the back, with the other reference blocks: it fills the back's spare space instead of costing
    // the whole sheet a type size in the header.
    return '<section class="pr-ref pr-changes"><h3>Changed since ' + esc(O.fmtDate(c.posted, 'md')) + '</h3><p>' + shown.join('; ') + (more > 0 ? '; and ' + more + ' more, marked ●' : '') + '</p></section>';
  }

  function prepare(P, opts) {
    opts = opts || {};
    const F = P.files || {};
    const src = { settings: F.settings, schedule: F.schedule, places: F.places, contacts: [], guide: F.guide, menus: F.menus, help: F.help, nearby: F.nearby, notices: F.notices };
    const m = O.buildSchedule(src);
    const s = m.settings, yr = P.yr || {};
    const cmp = compare(P.base, F.schedule || [], m.days);
    // Taken out since Publish: drawn in their place, struck through.
    if (cmp.gone.length) {
      const g = O.buildSchedule({ settings: F.settings, schedule: cmp.gone, places: F.places });
      g.days.forEach((d, i) => {
        d.items.concat(d.allDay).forEach(it => { it.cancelled = true; (d.allDay.indexOf(it) > -1 ? m.days[i].allDay : m.days[i].items).push(it); });
        m.days[i].items.sort((a, b) => a.sort - b.sort);
      });
    }
    const look = new Set();
    if (P.draft) (F.schedule || []).forEach(r => { if (r._look && r._look !== '0') rowKeys(r, m.days).forEach(k => look.add(k)); });
    const today = opts.today || P.today || '';
    const conf = { start: yr.start || m.days[0].date, end: yr.end || '' };
    const tzName = (s.timezone_label || '').replace(/\s*time$/i, '') || O.zoneAbbr(m.tz, m.days[0].date);
    // No phone marks on paper (Michael, Oct 14: they made the printout busy). Which services go out on
    // the call-in line is the website's to show; the paper keeps the number and PIN.
    m.days.forEach(d => d.items.concat(d.allDay).forEach(it => { it.callIn = false; }));
    // What the public's paper leaves out, for a member's draft marks (◆ Not confirmed).
    const held = {};
    (P.held || []).forEach(h => { held[h.key] = h; });
    // The Preteens box is the packet's own Preteens part (one copy, edited where it reads).
    const pre = m.guides.preteens;
    return {
      held,
      P, m, s, yr, tz: m.tz, year: P.year, draft: !!P.draft, member: !!P.member, marks: cmp.marks, changes: cmp.list, look, today, conf, tzName,
      span: O.fmtDateSpan(conf.start, conf.end || m.days[m.days.length - 1].date),
      posted: P.posted && P.posted.schedule || '',
      updated: updatedLabel(P.updated && P.updated.schedule, s.revised, P.posted && P.posted.schedule),
      preteens: pre && (pre.summary || pre.paras.length) ? { title: pre.title, text: pre.summary || pre.paras[0], paras: pre.paras } : (s.preteen_note ? { title: 'Preteens', text: s.preteen_note, paras: [] } : null),
      help: m.help.filter(h => h.phone && h.kind !== 'emergency'),
      notices: m.notices.filter(n => (!n.from || n.from <= today) && (!n.to || today <= n.to)),
      edit: P.member && P.urls && P.urls.edit || ''
    };
  }

  // "Updated June 5, 2:10 PM" from the last change after Publish; the typed date only for a year
  // from before the site kept them.
  function updatedLabel(stamp, typed, posted) {
    if (stamp) {
      const [d, t] = stamp.split(' '), p = t ? t.split(':') : null;
      return 'Updated ' + O.fmtDate(d, 'md') + (p ? ', ' + cap(T(+p[0] * 60 + +p[1])) : '');
    }
    if (typed && O.parseISODate(typed) && (!posted || typed >= posted)) return 'Updated ' + O.fmtDate(typed, 'md');
    return '';
  }

  /* ------------------------------------------------------------- one line per row */

  const code = p => p ? '<b class="pr-code">' + esc(p.code) + '</b>' : '';
  // "3:00 PM" in a typed note reads as the house writes it: "3 PM".
  const tidy = t => String(t || '').replace(/\b(\d{1,2}):00(\s?[AP]\.?M\.?)/gi, '$1$2');
  // Large print and Today name the place instead of its code: its building, then the room, as one
  // name ("Barnes, Piazza Terrace", "Barnes, Henry West Room 143", "Chapel Auditorium"). A room named
  // "Piazza Terrace (Barnes)" or "Barnes Rooms 133 A–D" gives its building first.
  function placeParts(p) {
    if (!p) return { b: '', r: '', whole: '' };
    const name = p.name || p.code, w = ((p.building || '').split(/\s+/)[0] || '').toLowerCase().slice(0, 3);
    if (!w || name === p.building) return { b: '', r: name, whole: name };
    const m = /^(.*\S)\s*\(([^)]*)\)\s*$/.exec(name);
    if (m && m[2].toLowerCase().indexOf(w) === 0) {
      // "Piazza Terrace (Barnes)": Barnes, Piazza Terrace. "Intramural Gym (Rec Center)": Rec Center,
      // Intramural Gym. "First Aid Room (Barnes Room 131)": Barnes, First Aid Room (Room 131).
      const inner = m[2].split(/\s+/);
      if (/\d/.test(m[2])) { const b = inner.shift(); return { b, r: m[1] + ' (' + inner.join(' ') + ')', whole: '' }; }
      return { b: m[2], r: m[1], whole: '' };
    }
    // "Barnes Rooms 133 A–D" is a name already; its building is split off only to group two rooms.
    const lead = /^(\S+)\s+(.+)$/.exec(name);
    if (lead && lead[1].toLowerCase().indexOf(w) === 0) return { b: lead[1], r: lead[2], whole: name };
    return { b: '', r: name, whole: name };
  }
  function placeName(p) {
    if (!p) return '';
    const x = placeParts(p);
    return x.whole || (x.b ? x.b + ', ' + x.r : x.r);
  }
  // Two rooms in one building say the building once: "Barnes: Piazza Terrace and Rooms 133 A–D".
  // A name never breaks inside itself.
  function placeNames(ps) {
    const xs = ps.map(placeParts);
    if (xs.length > 1 && xs[0].b && xs.every(x => x.b === xs[0].b)) return nw(xs[0].b + ':') + ' ' + xs.map(x => nw(x.r)).join(' and ');
    return ps.map(p => nw(placeName(p))).join(SEP);
  }
  const named = c => !!(c.ed && c.ed.names);
  const where = (c, p) => !p ? '' : named(c) && !p.unknown ? '<span class="pr-pname">' + nw(placeName(p)) + '</span>' : code(p);
  // A printed note of "also B/JLB" is a second place: printed as a place, after the first.
  function alsoPlaces(c, it) {
    const m = /^also\s+(.+)$/i.exec(String(it.print_note || '').trim());
    if (!m) return null;
    const ps = m[1].split(/[\s,]+(?:and\s+)?/).filter(Boolean).map(x => c.m.places[x.replace(/\.$/, '').toUpperCase()]);
    return ps.length && ps.every(Boolean) ? ps : null;
  }
  // A member's link to the row in the schedule editor, named for a screen reader.
  function editHref(c, it) {
    let u = c.edit.replace('edit=schedule', 'edit=' + encodeURIComponent('schedule:' + dayName(c, it.day)));
    if (it.row) u += '&row=' + encodeURIComponent(it.row);
    return u;
  }
  function line(c, it, o) {
    o = o || {};
    if (it.cancelled) {
      // Struck through, with the same separators as every other row: "Hymn practice · Cancelled · Chapel Auditorium".
      const at = !it.place ? '' : named(c) && !it.place.unknown ? SEP + '<span class="pr-pname">' + placeNames([it.place]) + '</span>' : '\u00a0' + code(it.place);
      return '<span class="pr-it is-gone"><s>' + esc(it.title) + '</s>' + SEP + '<em>Cancelled</em>' + at + '</span>';
    }
    const k = itemKey(it), mk = c.marks.get(k), look = c.look.has(k);
    let when = '';
    if (o.when === 'whole') when = whole(it);
    else if (o.when === 'till') when = till(it);
    else if (o.when === 'at') when = it.start != null ? range(it.start, it.end) : whole(it);
    // The audience leads, in regular weight, unless the title already names it.
    const aud = o.aud && (it.audience === 'preteens' || it.audience === 'youngfolks') ? AUD[it.audience] : '';
    const tag = aud && slug(it.title).indexOf(slug(aud).slice(0, 6)) < 0 ? '<span class="pr-aud">' + aud + ' · </span>' : '';
    const also = alsoPlaces(c, it);
    // Codes end the line in bold, kept on the line with the word before them; names (Large print,
    // Today) are set off as a part of their own.
    const ps = it.place ? [it.place].concat(also || []) : [];
    const places = !ps.length ? '' : named(c) && ps.every(p => !p.unknown) ? SEP + '<span class="pr-pname">' + placeNames(ps) + '</span>' : (named(c) ? SEP : '\u00a0') + ps.map(p => where(c, p)).join(named(c) ? SEP : '\u00a0·\u00a0');
    let h = (mk ? '<i class="pr-mk" title="Changed since posted">●</i>' : '') + (look ? '<i class="pr-look" title="To check">◆</i>' : '') +
      tag + (it.emphasis || mk ? '<b>' + esc(it.title) + '</b>' : esc(it.title)) + (when ? SEP + (mk ? '<b>' + nw(when) + '</b>' : nw(when)) : '') +
      (it.print_note && !also ? '<span class="pr-pn">' + SEP + esc(tidy(it.print_note)) + '</span>' : '') +
      (it.callIn ? '\u00a0' + PHONE : '') + places;
    if (c.edit && c.rowLinks !== false) {
      const label = 'Edit · ' + dayName(c, it.day) + ' ' + (startLabel(it) || '') + ' · ' + it.title;
      // Pointer only: keyboard users have Check rows and Edit schedule, not 90 stops in the paper.
      h = '<a class="pr-edit" href="' + esc(editHref(c, it)) + '" tabindex="-1" aria-label="' + esc(label) + '">' + h + '</a>';
    }
    return '<span class="pr-it' + (mk ? ' is-mk' : '') + '">' + h + '</span>';
  }
  const dayName = (c, key) => (c.m.days.find(d => d.key === key) || {}).name || key;

  // The desk's hours for a day: in the table, each range on a line of its own; in running text
  // "8–10 AM · noon–2:30 PM", the separator kept with what follows. "Noon" only starts a cell.
  function deskSummary(day, kind, lines) {
    const bits = day.desk.filter(d => d.kind === kind).map((d, i) =>
      '<span class="pr-nw">' + (d.title && !/^(open|on call)$/i.test(d.title) ? esc(d.title) + ' ' : '') + esc(i ? lowNoon(whole(d)) : whole(d)) + '</span>');
    return bits.join(lines ? '<br>' : SEP);
  }
  const lowNoon = t => String(t).replace(/\bNoon\b/g, 'noon').replace(/\bMidnight\b/g, 'midnight');

  /* ------------------------------------------------------------- days, as the grid and as the list */

  const BUCKET = 30;
  const colOf = it => it.audience === 'all' ? 'conference' : it.audience;
  // Only the audiences that have rows somewhere in the printout get a column (never an empty one).
  const WIDTH = { conference: 36, preteens: 28, youngfolks: 36 };
  function colsFor(c, days) {
    const used = new Set();
    days.forEach(d => d.items.concat(d.allDay).forEach(it => used.add(colOf(it))));
    const cols = ['conference', 'preteens', 'youngfolks'].filter(k => used.has(k));
    return cols.length ? cols : ['conference'];
  }
  function dayTable(c, day) {
    const COLS = c.cols || ['conference', 'preteens', 'youngfolks'];
    const sum = COLS.reduce((a, k) => a + WIDTH[k], 0);
    const slots = [];
    day.items.forEach(it => {
      // A row timed in words ("After Communion") has a slot of its own, labelled with its words and
      // placed by its sort time, as the list gives it: never a clock time it doesn't have.
      const words = it.start == null && it.startText;
      const b = words ? it.sort / BUCKET + 0.5 : Math.floor(it.sort / BUCKET);
      let s = slots.find(x => x.b === b && (words ? x.words === it.startText : !x.words));
      if (!s) { s = { b, label: null, words: words || '', cells: {} }; slots.push(s); }
      if (it.start != null && (s.label == null || it.start < s.label)) s.label = it.start;
      (s.cells[colOf(it)] = s.cells[colOf(it)] || []).push(it);
    });
    slots.forEach(s => { if (s.label == null && !s.words) s.label = Math.floor(s.b) * BUCKET; });
    slots.sort((a, b) => a.b - b.b);
    const cell = (it, s) => line(c, it, { when: s.words ? 'till' : it.start == null ? 'whole' : it.start !== s.label ? 'at' : 'till' });
    const ad = { conference: [], preteens: [], youngfolks: [] };
    day.allDay.forEach(it => ad[colOf(it)].push(it));
    // One audience alone needs no heading over its column; two or three do.
    const heads = COLS.length > 1 || COLS[0] !== 'conference';
    let h = '<table class="pr-table' + (heads ? '' : ' pr-table--one') + '"><colgroup><col class="pr-c-t">' + COLS.map(k => '<col style="width:' + (WIDTH[k] / sum * 100).toFixed(1) + '%">').join('') + '</colgroup>' +
      (heads ? '<thead><tr><th scope="col"><span class="pr-sr">Time</span></th>' + COLS.map(k => '<th scope="col">' + AUD[k] + '</th>').join('') + '</tr></thead>' : '') + '<tbody>';
    if (day.allDay.length) h += '<tr class="pr-allday"><th scope="row">All day</th>' + COLS.map(k => '<td>' + ad[k].map(it => line(c, it, { when: 'whole' })).join('') + '</td>').join('') + '</tr>';
    slots.forEach(s => {
      h += '<tr><th scope="row"' + (s.words ? ' class="is-words"' : '') + '>' + (s.words ? esc(cap(s.words)) : nw(cap(T(s.label)))) + '</th>' + COLS.map(k => '<td>' + (s.cells[k] || []).map(it => cell(it, s)).join('') + '</td>').join('') + '</tr>';
    });
    return h + '</tbody></table>';
  }

  // Check-out morning (a day after the Conference's last day): one line of its own rows, nothing added.
  const isCheckout = (c, day) => c.conf.end && day.date > c.conf.end;
  function dayHead(day, cont) {
    return '<h2 class="pr-dh">' + esc(day.name) + ' <span>' + esc(O.fmtDate(day.date, 'md')) + '</span>' + (cont ? ' <small>continued</small>' : '') + '</h2>';
  }
  // The Lodging Desk's hours on check-out morning, the same words in the grid and the list.
  // In the list the time stands in its own column, so one stretch says only when it ends.
  function checkoutDesk(c, day, list) {
    const open = day.desk.filter(d => d.kind === 'open');
    const desk = list && open.length === 1 && open[0].start != null && till(open[0]) ? nw(till(open[0])) : deskSummary(day, 'open');
    return desk ? '<span class="pr-it">Lodging Desk' + SEP + desk + (c.ed && c.ed.names ? SEP : '\u00a0') + where(c, day.desk[0].place) + '</span>' : '';
  }
  // A day in one line: check-out morning, or a day with nothing for this printout's audience.
  function dayLine(day, bits) {
    return '<section class="pr-day pr-day--line">' + dayHead(day) + '<p>' + bits.join('<span class="pr-sep">' + SEP + '</span>') + '</p></section>';
  }
  function dayBlock(c, day) {
    if (isCheckout(c, day)) return dayLine(day, day.items.map(it => line(c, it, { when: 'at' })).concat(checkoutDesk(c, day) || []));
    return '<section class="pr-day">' + dayHead(day) + dayTable(c, day) + '</section>';
  }

  function listRows(c, day, keep) {
    const rows = [], aud = c.ed.aud == null;
    // "All day" once, as a repeated time is.
    day.allDay.filter(keep).forEach((it, i) => rows.push('<div class="pr-li pr-li--allday' + (i ? ' is-same' : '') + '"><span class="pr-li__t">' + (i ? '' : 'All day') + '</span><span class="pr-li__x">' + line(c, it, { when: 'whole', aud }) + '</span></div>'));
    let last = null;
    day.items.filter(keep).forEach(it => {
      // A row timed in words ("After Communion") has its own time cell, placed by its sort time.
      const words = it.start == null, t = startLabel(it), show = t !== last;
      last = t;
      rows.push('<div class="pr-li' + (show ? '' : ' is-same') + (it.emphasis ? ' is-em' : '') + '"><span class="pr-li__t' + (words ? ' is-words' : '') + '">' + (show ? (words ? esc(cap(t)) : nw(t)) : '') + '</span><span class="pr-li__x">' +
        line(c, it, { when: 'till', aud }) + '</span></div>');
    });
    // Check-out morning: the desk's hours, as the grid gives them.
    const desk = isCheckout(c, day) && checkoutDesk(c, day, true);
    if (desk) {
      const first = day.desk.find(d => d.kind === 'open'), at = first && first.start;
      const row = '<div class="pr-li"><span class="pr-li__t">' + (at != null ? nw(cap(T(at))) : '') + '</span><span class="pr-li__x">' + desk + '</span></div>';
      const later = day.items.filter(keep).findIndex(it => at != null && it.start != null && it.start > at);
      if (later > -1) rows.splice(rows.length - day.items.filter(keep).length + later, 0, row); else rows.push(row);
    }
    return rows;
  }

  /* ------------------------------------------------------------- the back: places, desk, help, the line */

  // The codes this printout uses: every one on the whole sheet (and Help's rooms); on the others, only
  // the codes printed on that sheet (c.used, gathered as its rows are written).
  function placesBlock(c, only) {
    const m = c.m, used = {};
    if (only) only.forEach(k => { if (m.places[k]) used[k] = m.places[k]; });
    else {
      m.days.forEach(d => ['items', 'allDay', 'desk', 'nightly'].forEach(b => d[b].forEach(it => { if (it.place && !it.place.unknown) used[it.place.code.toUpperCase()] = it.place; })));
      // The places people look for even when no row names them: Help's (First Aid's room).
      (c.P.files.help || []).forEach(h => { const p = h.place && m.places[String(h.place).toUpperCase()]; if (p) used[p.code.toUpperCase()] = p; });
    }
    // Grouped by building, under the building's own code (B, J, W) when the campus has one, and
    // named as that place is (the packet names it the same way). A place that is the building under a
    // shorter name ("Jeremiah Chapel" in "Jeremiah Chapel, Dixon Ministry Center") leads it too.
    const groups = new Map(), all = Object.keys(m.places).map(k => m.places[k]);
    const solo = p => p.code.indexOf('/') < 0;
    const lower = t => String(t || '').toLowerCase();
    const topOf = b => all.find(p => solo(p) && p.name === b) ||
      all.find(p => solo(p) && p.building === b && all.some(x => x.code.indexOf(p.code + '/') === 0)) ||
      all.find(p => solo(p) && p.building === b && lower(b).indexOf(lower(p.name)) === 0) || null;
    all.filter(p => used[p.code.toUpperCase()]).forEach(p => {
      const b = p.building || p.name;
      if (!groups.has(b)) { const t = topOf(b); groups.set(b, { top: t ? t.code : '', name: t && lower(b).indexOf(lower(t.name)) !== 0 ? t.name : b, items: [] }); }
      if (p.name !== b && p.code !== groups.get(b).top) groups.get(b).items.push(p);
    });
    if (!groups.size) return '';
    // Under its building a room says only the rest of its name: "Piazza Terrace (Barnes)" under Barnes is
    // "Piazza Terrace", "Stevens Student Center Room 241" is "Room 241".
    const word = b => (b.split(/\s+/)[0] || '').toLowerCase().slice(0, 3);
    const short = (p, b) => {
      const n = p.name.replace(/\s*\(([^)]*)\)\s*$/, (whole, inner) => inner.toLowerCase().indexOf(word(b)) > -1 ? '' : whole);
      return lower(n).indexOf(lower(b) + ' ') === 0 ? n.slice(b.length + 1) : n;
    };
    // One place a line, the code first: no separators to strand at a line's end.
    const html = Array.from(groups.entries()).map(([b, g]) => '<p><span class="pr-pl__b">' + (g.top ? '<b class="pr-code">' + esc(g.top) + '</b> ' : '') + '<b>' + esc(g.name) + '</b></span>' +
      g.items.map(p => '<span class="pr-pl__r"><b class="pr-code">' + esc(p.code) + '</b> ' + esc(short(p, b)) + '</span>').join('') + '</p>').join('');
    return '<section class="pr-ref pr-places"><h3>Places</h3><div class="pr-pl">' + html + '</div></section>';
  }

  function deskBlock(c) {
    const days = c.m.days.filter(d => d.desk.length);
    if (!days.length) return '';
    // On call says which number: the Help card that gives the desk's hours.
    const line = (c.m.help || []).find(h => h.hours === 'desk' && h.phone);
    const onCall = days.some(d => d.desk.some(x => x.kind === 'on_call'));
    return '<section class="pr-ref pr-desk"><h3>Lodging Desk ' + code(days[0].desk[0].place) + '</h3><table><thead><tr><th></th><th>Open</th>' + (onCall ? '<th>On call' + (line ? ' <span class="pr-nw">' + esc(line.phone) + '</span>' : '') + '</th>' : '') + '</tr></thead><tbody>' +
      days.map(d => '<tr><th>' + esc(O.fmtDate(d.date, 'weekdayShort')) + ' ' + esc(O.fmtDate(d.date, 'day')) + '</th><td>' + deskSummary(d, 'open', true) + '</td>' + (onCall ? '<td>' + deskSummary(d, 'on_call', true) + '</td>' : '') + '</tr>').join('') +
      '</tbody></table></section>';
  }

  // Help's numbers: the same list as the guide and the packet. Without numbers, only the 911 line.
  function helpBlock(c) {
    const nums = c.help.map(h => '<div class="pr-num"><span>' + esc(h.need) + '</span><b>' + esc(h.phone) + '</b></div>').join('');
    // A member's draft says what the public's paper leaves out (cards still to confirm), never the numbers.
    const held = c.draft && c.held.help ? '<p class="pr-small"><i class="pr-look">◆</i> ' + esc(c.held.help.what) + ' · Not confirmed</p>' : '';
    const box = nums || held;
    return '<section class="pr-ref pr-help' + (box ? '' : ' is-bare') + '">' + (box ? '<h3>Help</h3>' : '') + '<p class="pr-911">Emergency: call <b>911</b> first.</p>' + nums + held + '</section>';
  }
  // When the reference blocks don't fit a one-page printout: 911 and Help's numbers in one line.
  function helpStrip(c) {
    return '<b>Emergency: call 911 first</b>' + c.help.slice(0, 4).map(h => SEP + esc(h.need) + ' <b class="pr-nw">' + esc(h.phone) + '</b>').join('');
  }
  // For the Preteens printout: who checks children in and picks them up, and First Aid.
  function preteensRef(c) {
    const aid = c.help.find(h => /first aid/i.test(h.need));
    return '<section class="pr-ref pr-help"><p class="pr-911">Emergency: call <b>911</b> first.</p>' +
      (aid ? '<div class="pr-num"><span>' + esc(aid.need) + '</span><b>' + esc(aid.phone) + '</b></div>' : '') + '</section>';
  }

  function zones(c) {
    const iso = c.m.days[0].date, ref = O.wallToInstant(iso, 720, c.tz);
    const off = z => { try { const w = O.wallNow(z, ref); return w.minutes + (w.date < iso ? -1440 : w.date > iso ? 1440 : 0); } catch (e) { return null; } };
    const v = off(c.tz), out = [];
    [['Eastern', 'America/New_York'], ['Central', 'America/Chicago'], ['Mountain', 'America/Denver'], ['Pacific', 'America/Los_Angeles']].forEach(([n, z]) => {
      const o = off(z);
      if (o == null || v == null || o === v) return;
      const d = (o - v) / 60;
      out.push(n + ' ' + (d > 0 ? '+' : '−') + Math.abs(d));
    });
    return out.join(' · ');
  }

  function lineBlock(c) {
    const s = c.s;
    if (!s.call_in_number) return '';
    const z = zones(c);
    // The number first, then the PIN, as you dial them (and as the header and the packet give them).
    return '<section class="pr-ref pr-line"><h3>Listen by phone</h3><p class="pr-num"><span>Call-in line</span><span class="pr-nw"><b>' + esc(s.call_in_number) + '</b>' + (s.call_in_pin ? ' · PIN ' + esc(s.call_in_pin) : '') + '</span></p>' +
      (z ? '<p class="pr-small">Times are ' + esc(c.tzName) + ': ' + esc(z) + ' hours.</p>' : '') + '</section>';
  }

  function preteensBlock(c, own) {
    if (!c.preteens) return '';
    // On the Preteens printout the days already say which days there's a program: the box gives what
    // the grid can't (who checks children in and picks them up), the part's own paragraphs.
    const paras = own ? (c.preteens.paras || []).filter(t => t && t !== c.preteens.text) : [c.preteens.text];
    if (!paras.length) return '';
    return '<section class="pr-ref"><h3>' + esc(c.preteens.title) + '</h3>' + paras.map(t => '<p>' + esc(t) + '</p>').join('') + '</section>';
  }

  // The QR opens the schedule on screen (the Conference page's full schedule), as its label says.
  function qrBlock(c) {
    // (In the prototype, at its ogbbc.org address: urls.qr, core-dev.php.)
    const u = c.P.urls || {}, svg = qr((u.qr && u.qr.full) || u.full || u.conference);
    if (!svg) return '';
    // The address under it is the Conference page's, which keeps no year, so the label names the year.
    return '<section class="pr-ref pr-qr"><div class="pr-qr__code">' + svg + '</div><p>Latest ' + esc(c.year) + ' schedule<br>Conference page<br><b class="pr-nw">' + esc(u.short) + '</b></p></section>';
  }

  // Large print ends with what someone needs most, in the same large type.
  function largeEnd(c) {
    const aid = c.help.find(h => /first aid/i.test(h.need));
    return '<section class="pr-ref pr-help pr-help--large"><p class="pr-911">Emergency: call <b>911</b> first.</p>' +
      (aid ? '<div class="pr-num"><span>' + esc(aid.need) + (aid.place ? ' · ' + esc(placeName(c.m.places[String(aid.place).toUpperCase()] || null) || aid.place) : '') + '</span><b>' + esc(aid.phone) + '</b></div>' : '') + '</section>';
  }

  // A QR code for the year's Conference page, drawn here (the library is in the plugin). With a
  // quiet zone of four modules, as scanners need. Nothing at all if it can't be made.
  let qrN = 0;
  function qr(url) {
    if (!url || typeof window.qrcode !== 'function') return '';
    try {
      const q = window.qrcode(0, 'M');
      q.addData(url);
      q.make();
      return q.createSvgTag({ cellSize: 2, margin: 8, scalable: true, alt: { text: 'QR code: ' + url, id: 'ogc-qr-' + (++qrN) } });
    } catch (e) { return ''; }
  }

  // Every printout explains the codes it prints (Places, only those on it); Large print names the
  // places instead, so it needs no key.
  function refBlocks(c, kind) {
    if (kind === 'none') return [];
    if (kind === 'large') return [changesLine(c), largeEnd(c)].filter(Boolean);
    // Today names its places (as Large print does): no codes, so no Places key to give up.
    if (kind === 'today') return [helpBlock(c), lineBlock(c), qrBlock(c)].filter(Boolean);
    if (kind === 'short') return [placesBlock(c, c.used), helpBlock(c), lineBlock(c), qrBlock(c)].filter(Boolean);
    if (kind === 'preteens') return [preteensBlock(c, true), preteensRef(c), placesBlock(c, c.used), qrBlock(c)].filter(Boolean);
    if (c.ed.layout === 'columns') {
      // The back row: only the cells with something in them. Help with no numbers is just the 911
      // line, which then heads the last cell instead of standing alone.
      const bare = !c.help.length && !(c.draft && c.held.help);
      const cells = [deskBlock(c), bare ? '' : helpBlock(c), (bare ? helpBlock(c) : '') + preteensBlock(c) + lineBlock(c) + qrBlock(c)].filter(Boolean);
      return [changesLine(c), placesBlock(c), cells.length ? '<div class="pr-refrow pr-refrow--' + cells.length + '">' + cells.map(x => '<div>' + x + '</div>').join('') + '</div>' : ''].filter(Boolean);
    }
    return [changesLine(c), placesBlock(c), deskBlock(c), helpBlock(c), preteensBlock(c), lineBlock(c), qrBlock(c)].filter(Boolean);
  }

  /* ------------------------------------------------------------- the printouts */

  function editions(c, opts) {
    const s = c.s, inWeek = c.today && c.m.dayByDate(c.today);
    const layout = (opts && opts.layout) || (/^list$/i.test(s.print_layout || '') ? 'list' : 'columns');
    // The ladders start large, so a sparse year fills the paper in larger type rather than leaving
    // half of it empty; the fit (draw) picks the largest size that meets the target.
    const E = [
      { id: 'sheet', label: 'One sheet', tip: 'The whole week on one sheet, both sides', layout, cols: layout === 'list' ? 2 : 1, target: 2, ref: 'full', unit: 'sheet',
        sizes: layout === 'list' ? [12, 11.5, 11, 10.5, 10, 9.6, 9.2, 8.8, 8.4, 8, 7.6, 7.2, 7] : [11, 10.5, 10, 9.6, 9.2, 8.8, 8.6, 8.4, 8.2, 8, 7.8, 7.6, 7.4, 7.2, 7] },
      // Large print (the usual standard is 16 pt and up, in a regular-width face): the Conference's
      // own rows only, the places by name. The days run on; a page breaks only before a day that
      // won't fit whole.
      { id: 'large', label: 'Large print', tip: '16 pt, the Conference’s own times, places by name', layout: 'list', cols: 1, sizes: [16], keepDays: true, ref: 'large', aud: 'conference', names: true }
    ];
    const has = a => c.m.days.some(d => d.items.some(it => it.audience === a && !noProgram(it)));
    if (has('preteens')) E.push({ id: 'preteens', label: 'Preteens', tip: 'Preteen times, with the meals and services', layout: 'list', cols: 2, aud: 'preteens', target: 1, ref: 'preteens', sizes: [12, 11, 10, 9.5, 9, 8.5, 8] });
    if (has('youngfolks')) E.push({ id: 'youngfolks', label: 'Youngfolks', tip: 'Youngfolks times, with the meals and services', layout: 'list', cols: 2, aud: 'youngfolks', target: 1, ref: 'short', sizes: [12, 11, 10, 9.5, 9, 8.5, 8] });
    if (inWeek) E.push({ id: 'today', label: 'Today', tip: 'Today alone, in large type, to post', layout: 'list', cols: 1, days: [inWeek.key], target: 1, ref: 'today', names: true, full: 13, sizes: [18, 17, 16, 15, 14, 13, 12, 11, 10] });
    return E;
  }
  // "No preteen program today": a row that says there's nothing for that audience.
  const noProgram = it => /^no\b.*\bprogram\b/i.test(it.title || '');

  function nightlyLine(c, days) {
    if (c.ed.aud === 'preteens') return '';
    const by = new Map();
    c.m.days.forEach(d => d.nightly.forEach(it => {
      if (c.ed.aud === 'conference' && it.audience !== 'conference' && it.audience !== 'all') return; if (!by.has(it.title)) by.set(it.title, { it, days: [] }); by.get(it.title).days.push(d); }));
    if (!by.size) return '';
    const all = Array.from(by.values());
    if (!all.some(x => x.days.some(d => days.indexOf(d) > -1))) return '';
    const span = ds => { const a = O.fmtDate(ds[0].date, 'weekdayShort'), b = O.fmtDate(ds[ds.length - 1].date, 'weekdayShort'); return a === b ? a + ' night' : a + '–' + b + ' nights'; };
    const nights = span(all[0].days);
    const aud = all[0].it.audience === 'youngfolks' ? 'Youngfolks, ' : '';
    // A short entry ("Quiet time 11 PM") keeps whole on its line; a long one breaks only before its time.
    return '<b>' + esc(aud + nights) + '</b>' + SEP + all.map(x => {
      const t = esc(x.it.title) + ' ' + nw(x.it.end != null ? range(x.it.start, x.it.end) : cap(T(x.it.start))) + (x.it.place ? '\u00a0' + where(c, x.it.place) : '') +
        (span(x.days) !== nights ? ' (' + esc(span(x.days)) + ')' : '');
      return x.it.title.length <= 20 ? '<span class="pr-nw">' + t + '</span>' : t;
    }).join(SEP);
  }

  // The header gives the Conference's own dates (years.csv), the same as every other page; a Friday
  // evening before them carries its date in its own day heading.
  const spanFor = c => c.span;
  function headHtml(c, first, days) {
    const s = c.s, ed = c.ed, one = ed.days && ed.days.length === 1;
    // A single day's printout is titled by its date in full ("Sunday, June 7, 2026"), with no day heading under it.
    const title = ed.id === 'preteens' ? 'Preteens schedule' : ed.id === 'youngfolks' ? 'Youngfolks schedule' : one ? O.fmtDate(c.m.days.find(d => d.key === ed.days[0]).date, 'full') : 'Conference schedule';
    const yearTag = one ? '' : ' <span>' + esc(c.year) + '</span>';
    const draft = c.draft ? '<p class="pr-draft">Draft · Not posted</p>' : '';
    if (!first) {
      const which = days.length ? esc(days[0].name) + (days.length > 1 ? '–' + esc(days[days.length - 1].name) : '') : '';
      return '<header class="pr-head pr-head--cont"><p class="pr-h1">' + esc(title) + yearTag + '</p><p>' + which + '</p></header>' + draft;
    }
    // The call-in number at the rows' own size (a large-print reader's most-needed line). In a member's
    // draft, a line the public's paper leaves out is marked, never printed.
    const callIn = s.call_in_number ? '<span class="pr-callin">Call-in ' + esc(s.call_in_number) + (s.call_in_pin ? ' · PIN ' + esc(s.call_in_pin) : '') + '</span>'
      : c.draft && c.held.callin ? '<i class="pr-look">◆</i> Call-in · Not confirmed' : '';
    return '<header class="pr-head"><div><p class="pr-church">Old German Baptist Brethren Church, New Conference</p>' +
      '<p class="pr-h1">' + esc(title) + yearTag + '</p></div>' +
      '<div class="pr-head__r"><p>' + (one ? '' : '<b>' + esc(spanFor(c)) + '</b>') + (s.venue ? (one ? '' : ' · ') + esc(s.venue) : '') + '</p>' +
      (s.hosts ? '<p>Hosted by the ' + esc(s.hosts) + '</p>' : '') +
      '<p>All times ' + esc(c.tzName) + (callIn ? '<span class="pr-callsep"> · </span>' + callIn : '') + '</p></div></header>' + draft +
      c.notices.map(n => '<p class="pr-notice">' + esc(n.text) + '</p>').join('');
  }

  function footHtml(c, page, n, of) {
    const has = sel => !!page.querySelector(sel);
    const keys = [];
    if (has('.pr-ph') && !has('.pr-line')) keys.push('<span class="pr-nw">' + PHONE + ' On the call-in line</span>');
    // The marks' keys at the rows' own size, so they're read, not missed.
    if (has('.pr-mk')) keys.push('<span class="pr-key"><i class="pr-mk">●</i> <b>Changed since ' + esc(O.fmtDate(c.posted, 'md')) + '</b></span>');
    if (has('.pr-look')) keys.push('<span class="pr-key"><i class="pr-look">◆</i> <b>To check</b></span>');
    // The nights' line, then the marks' keys on a line of their own (a key never trails the nights).
    const nights = nightlyLine(c, page._days || []);
    const left = nights && keys.length ? nights + '<br>' + keys.join('<span class="pr-sep">' + SEP + '</span>') : [nights].concat(keys).filter(Boolean).join('<span class="pr-sep">' + SEP + '</span>');
    // "Page 1 of 1" says nothing: the page count only when there's more than one.
    const right = [of > 1 ? 'Page ' + n + ' of ' + of : '', c.updated].filter(Boolean).join(' · ');
    const empty = !left && !right && !c.lite && !c.s.print_required;
    return '<footer class="pr-foot' + (empty ? ' is-empty' : '') + '">' + (c.lite ? '<p class="pr-foot__help">' + helpStrip(c) + '</p>' : '') + '<p class="pr-foot__l">' + left + '</p><p class="pr-foot__r">' + esc(right) + '</p>' +
      (c.s.print_required ? '<p class="pr-req">' + esc(c.s.print_required) + '</p>' : '') + '</footer>';
  }

  /* ------------------------------------------------------------- filling the pages */

  const el = html => { const t = document.createElement('template'); t.innerHTML = html.trim(); return t.content.firstElementChild; };
  const over = f => f.scrollHeight > f.clientHeight + 1 || f.scrollWidth > f.clientWidth + 1;

  function book(c, host, size) {
    const pages = [];
    let page = null, fi = 0;
    function newPage() {
      const first = !pages.length;
      page = el('<section class="pr-page pr-ed-' + c.ed.id + ' pr-lay-' + c.ed.layout + (c.draft ? ' is-draft' : '') + '" style="--pr-fs:' + size + 'pt"><div class="pr-in">' +
        headHtml(c, first, [{ name: 'Monday' }]) + '<div class="pr-body pr-body--' + c.ed.cols + '">' + '<div class="pr-frame"></div>'.repeat(c.ed.cols) + '</div>' +
        '<footer class="pr-foot">' + (c.lite ? '<p class="pr-foot__help">&nbsp;</p>' : '') + '<p class="pr-foot__l"><span class="pr-key">&nbsp;<br>&nbsp;</span></p><p class="pr-foot__r">&nbsp;</p>' + (c.s.print_required ? '<p class="pr-req">&nbsp;</p>' : '') + '</footer></div></section>');
      page._first = first;
      page._days = [];
      host.appendChild(page);
      pages.push(page);
      fi = 0;
      return page.querySelectorAll('.pr-frame')[0];
    }
    function nextFrame() {
      const fr = page && page.querySelectorAll('.pr-frame')[fi + 1];
      if (fr) { fi++; return fr; }
      return newPage();
    }
    return { pages, nextFrame, newPage, page: () => page };
  }

  function flow(c, b, items) {
    let fr = b.newPage(), head = null;
    const add = (f, h) => { const e = el(h); f.appendChild(e); return e; };
    for (let i = 0; i < items.length; i++) {
      const it = items[i];
      if (it.kind === 'head' && it.pageBreak && fr.childElementCount) fr = b.newPage();
      // A day that doesn't fit what's left of the page starts the next one (if it fits a page).
      // (Check-out morning is a line or two: it follows the last day on its page.)
      if (it.kind === 'head' && c.ed.keepDays && fr.childElementCount && !isCheckout(c, it.day)) {
        const trial = [it];
        for (let j = i + 1; j < items.length && items[j].kind === 'row' && items[j].day === it.day; j++) trial.push(items[j]);
        const els = trial.map(g => add(fr, g.html)), short = over(fr);
        els.forEach(e => e.remove());
        if (short) fr = b.nextFrame();
      }
      const grp = [it];
      if (it.kind === 'head') { head = it; if (items[i + 1] && items[i + 1].kind === 'row') grp.push(items[++i]); }
      const els = grp.map(g => add(fr, g.html));
      if (over(fr) && fr.childElementCount > els.length) {
        els.forEach(e => e.remove());
        const was = fr, moved = [];
        // A day's last row never goes over alone: the row before it comes too.
        const lastOfDay = grp[0].kind === 'row' && !(items[i + 1] && items[i + 1].kind === 'row' && items[i + 1].day === it.day);
        if (lastOfDay && was.lastElementChild && was.lastElementChild.classList.contains('pr-li') && was.childElementCount > 1) {
          moved.push(was.lastElementChild);
          was.lastElementChild.remove();
        }
        fr = b.nextFrame();
        // A day heading left with no rows under it goes over with them (and needs no "continued").
        let cont = grp[0].kind === 'row' && head;
        if (cont && was.lastElementChild && was.lastElementChild.matches('.pr-dh') && was.childElementCount > 1) { fr.appendChild(was.lastElementChild); cont = false; }
        if (cont) add(fr, dayHead(head.day, true));
        moved.concat(els).forEach(e => fr.appendChild(e));
      }
      if (it.day) { const pg = b.page(); if (pg._days.indexOf(it.day) < 0) pg._days.push(it.day); }
    }
  }

  // What a list printout keeps of each day: the audience's own rows with the meals and services
  // (Preteens, Youngfolks), the Conference's own (Large print), or everything.
  function keeper(ed) {
    if (!ed.aud) return () => true;
    if (ed.aud === 'conference') return it => it.audience === 'conference' || it.audience === 'all';
    return it => it.audience === ed.aud || (SHARED[it.kind] && (it.audience === 'conference' || it.audience === 'all'));
  }

  function itemsFor(c) {
    const ed = c.ed;
    const days = c.m.days.filter(d => !ed.days || ed.days.indexOf(d.key) > -1);
    const one = days.length === 1;
    const out = [];
    if (ed.layout === 'columns') {
      c.cols = colsFor(c, days);
      days.forEach(d => out.push({ kind: 'block', html: dayBlock(c, d), day: d }));
    } else {
      const keep = keeper(ed);
      days.forEach(d => {
        // Check-out morning concerns families with preteens and Youngfolks too (keys, the desk): the
        // same one line the sheet has, from everyone's rows and this audience's.
        if (ed.aud && ed.aud !== 'conference' && isCheckout(c, d)) {
          const bits = d.items.filter(it => it.audience === 'all' || it.audience === 'conference' || it.audience === ed.aud).map(it => line(c, it, { when: 'at' })).concat(checkoutDesk(c, d) || []);
          if (bits.length) out.push({ kind: 'block', html: dayLine(d, bits), day: d });
          return;
        }
        // A day with nothing for this audience is one line, not a full day of the adults' rows.
        if (ed.aud && ed.aud !== 'conference' && !d.items.concat(d.allDay).some(it => it.audience === ed.aud && !noProgram(it))) {
          const none = d.items.concat(d.allDay).find(it => it.audience === ed.aud && noProgram(it));
          out.push({ kind: 'block', html: dayLine(d, ['<span class="pr-it">' + esc(none ? none.title.replace(/\s+today$/i, '') : 'No ' + AUD[ed.aud].toLowerCase().replace(/s$/, '') + ' program') + '</span>']), day: d });
          return;
        }
        const rows = listRows(c, d, it => keep(it) && !(ed.aud && noProgram(it)));
        if (!rows.length) return;
        if (!one) out.push({ kind: 'head', html: dayHead(d), day: d, pageBreak: !!ed.dayBreak });
        rows.forEach(r => out.push({ kind: 'row', html: r, day: d }));
      });
    }
    // The codes printed on this sheet (rows, check-out, the footer's nights), for its Places.
    c.used = new Set();
    const html = out.map(x => x.html).join('') + nightlyLine(c, days);
    html.replace(/<b class="pr-code">([^<]+)<\/b>/g, (w, k) => { c.used.add(k.replace(/&amp;/g, '&').toUpperCase()); return w; });
    refBlocks(c, c.lite ? 'none' : ed.ref).forEach(h => out.push({ kind: 'block', html: h }));
    return out;
  }

  // Draw one printout into host at one type size; then its headers and footers. → {pages, over}
  function drawAt(c, host, size) {
    host.textContent = '';
    const b = book(c, host, size);
    flow(c, b, itemsFor(c));
    b.pages.forEach((pg, i) => {
      const h = pg.querySelector('.pr-head'), extra = pg.querySelectorAll('.pr-head ~ .pr-draft, .pr-head ~ .pr-notice');
      extra.forEach(e => e.remove());
      h.outerHTML = headHtml(c, pg._first, pg._days);
      pg.querySelector('.pr-foot').outerHTML = footHtml(c, pg, i + 1, b.pages.length);
    });
    // Over: a frame's rows don't fit, or the page's header and footer push past its foot.
    const bad = b.pages.some(pg => Array.from(pg.querySelectorAll('.pr-frame')).some(over) || over(pg.querySelector('.pr-in')));
    return { pages: b.pages.length, over: bad };
  }

  // The printout at the largest type that fits its target (two pages for the sheet, one for the
  // others that have one). Bigger type never takes fewer pages, so the ladder is searched by halves.
  // A one-page printout that won't fit gives up its reference blocks (a line of Help's numbers in
  // the footer instead) before it goes to a second page.
  function draw(c, host, ed) {
    c.ed = ed;
    c.lite = false;
    const tried = new Map();
    const at = (size, lite) => {
      const k = size + (lite ? 'L' : '');
      if (!tried.has(k)) { c.lite = lite; tried.set(k, Object.assign({ size, lite }, drawAt(c, host, size))); }
      return tried.get(k);
    };
    const ok = r => !r.over && (!ed.target || r.pages <= ed.target);
    const search = lite => {
      let lo = 0, hi = ed.sizes.length - 1, best = null;
      if (!ok(at(ed.sizes[hi], lite))) return null;
      while (lo <= hi) {
        const mid = (lo + hi) >> 1, r = at(ed.sizes[mid], lite);
        if (ok(r)) { best = r; hi = mid - 1; } else lo = mid + 1;
      }
      return best;
    };
    // Type that reads from across a room matters more than the reference blocks on a sheet to post:
    // below ed.full pt, the blocks give way first.
    const full = ed.full ? ed.sizes.filter(x => x >= ed.full) : ed.sizes;
    const sizes0 = ed.sizes;
    ed.sizes = full;
    let pick = full.length ? search(false) : null;
    ed.sizes = sizes0;
    if (!pick && ed.target === 1 && ed.ref !== 'none') pick = search(true);
    if (!pick && full.length < ed.sizes.length) pick = search(false);
    if (!pick) {
      // Nothing fits: the fewest pages, at the largest type that gives them.
      const all = Array.from(tried.values()).filter(t => !t.lite);
      const good = all.filter(t => !t.over);
      const pool = good.length ? good : all;
      const min = Math.min.apply(null, pool.map(t => t.pages));
      pick = pool.filter(t => t.pages === min).sort((a, b) => b.size - a.size)[0];
    }
    c.lite = pick.lite;
    drawAt(c, host, pick.size);
    if (ed.id === 'sheet' && !pick.over) grow(host);
    host.querySelectorAll('.pr-page').forEach(pg => pg.querySelectorAll('svg.pr-ph').forEach(svg => svg.setAttribute('focusable', 'false')));
    return { tried: Array.from(tried.values()).map(t => t.size + (t.lite ? 'L' : '') + ':' + t.pages + (t.over ? '!' : '')), pages: pick.pages, size: pick.size, over: pick.over, lite: pick.lite,
      fits: ok(pick), target: ed.target || 0, layout: ed.layout, edition: ed.id };
  }

  // The sheet's type is set by its fullest page (in Columns a day can't break). When the last page
  // has room to spare, its reference blocks (Places, the desk, Help, the line) grow into it, a step at a
  // time, so the back isn't a third empty while the week is small.
  function grow(host) {
    const pages = host.querySelectorAll('.pr-page'), pg = pages[pages.length - 1];
    if (!pg || pages.length < 2) return;
    const fr = pg.querySelector('.pr-frame'), refs = fr ? Array.from(fr.children).filter(e => e.matches('.pr-ref, .pr-refrow')) : [];
    if (!refs.length) return;
    const set = k => refs.forEach(e => { e.style.fontSize = k === 1 ? '' : k + 'em'; });
    for (const k of [1.4, 1.32, 1.25, 1.18, 1.12, 1.06]) {
      set(k);
      // Nothing may spill out of its own cell either (a table wider than its column).
      if (!over(fr) && !over(pg.querySelector('.pr-in')) && !Array.from(fr.querySelectorAll('.pr-refrow > div')).some(over)) return;
    }
    set(1);
  }

  // Fonts first: a sheet measured in a stand-in font would print longer than it measured.
  function fontsReady() {
    const f = document.fonts;
    if (!f) return Promise.resolve();
    // Locally and in the prototype the fonts' stylesheet doesn't hold the page up (data-ogc-fonts, turned
    // on when it arrives): until it has, the faces below aren't known yet, so it's waited for first.
    const css = Array.from(document.querySelectorAll('link[data-ogc-fonts]')).filter(l => l.media === 'print' && !l.sheet);
    const sheets = Promise.all(css.map(l => new Promise(r => { l.addEventListener('load', () => setTimeout(r, 0), { once: true }); l.addEventListener('error', r, { once: true }); })));
    // The sheet's face, and the serif the packet's paper is set in.
    const want = () => Promise.all(['400 10pt "Roboto Condensed"', '700 10pt "Roboto Condensed"', '400 10pt "Noto Serif"', '700 10pt "Noto Serif"'].map(x => f.load(x).catch(() => null))).then(() => f.ready);
    return Promise.race([sheets.then(want), new Promise(r => setTimeout(r, 2500))]);
  }

  /* ------------------------------------------------------------- a page at full size */

  // One page of the paper at full size, over the page (both print pages): pan with a finger, pinch to
  // zoom, double-tap to fit; Previous and Next (or a swipe, or the arrow keys) to the other pages;
  // Close or Escape goes back to the thumbnail it came from. pages() gives the current .pr-page /
  // .pkp-page elements; the copy shown is a clone, so the paper itself is never moved.
  const PAGE_W = 816, PAGE_H = 1054;
  const vsvg = d => '<svg class="wk-i" viewBox="0 0 24 24" aria-hidden="true"><path d="' + d + '" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  function viewer(pages, start, opener) {
    if (typeof HTMLDialogElement !== 'function' || !pages().length) return;
    const d = document.createElement('dialog');
    d.className = 'pp-view';
    d.innerHTML = '<div class="pp-view__bar"><button type="button" class="pp-view__nav" data-go="-1" aria-label="Previous page">' + vsvg('M15 6l-6 6 6 6') + '</button>' +
      '<h2 aria-live="polite"></h2><button type="button" class="pp-view__nav" data-go="1" aria-label="Next page">' + vsvg('M9 6l6 6-6 6') + '</button>' +
      '<button type="button" class="pp-view__x" data-close aria-label="Close">' + vsvg('M6 6l12 12M18 6 6 18') + '</button></div>' +
      '<div class="pp-view__scroll" tabindex="0"><div class="pp-view__pad"><div class="pp-view__box"></div></div></div>';
    const box = d.querySelector('.pp-view__box'), scroller = d.querySelector('.pp-view__scroll'), head = d.querySelector('h2');
    const PAD = 12;
    let i = start, page = null, s = 1, fit = 1;
    const apply = v => {
      s = Math.min(3, Math.max(fit, v));
      box.style.width = Math.round(PAGE_W * s) + 'px';
      box.style.height = Math.round(PAGE_H * s) + 'px';
      if (page) page.style.transform = 'scale(' + s + ')';
    };
    function show(k) {
      const all = pages();
      // Opens fitted to the width (the whole page in view); a page turned at its fitted size stays fitted.
      const wasFit = !page || s <= fit * 1.05;
      i = Math.max(0, Math.min(all.length - 1, k));
      page = all[i].cloneNode(true);
      page.inert = false; page.removeAttribute('aria-hidden');   // a thumbnail's copy, readable at full size
      page.style.transform = '';
      // The copy's ids (a QR code's title) are made its own.
      page.querySelectorAll('[id]').forEach(e => { e.id += '-v'; });
      page.querySelectorAll('[aria-labelledby]').forEach(e => e.setAttribute('aria-labelledby', e.getAttribute('aria-labelledby').split(/\s+/).map(x => x + '-v').join(' ')));
      page.querySelectorAll('a').forEach(a => a.setAttribute('tabindex', '-1'));
      box.textContent = '';
      box.appendChild(page);
      head.textContent = 'Page ' + (i + 1) + ' of ' + all.length;
      d.setAttribute('aria-label', head.textContent);
      d.querySelector('[data-go="-1"]').disabled = i === 0;
      d.querySelector('[data-go="1"]').disabled = i === all.length - 1;
      fit = Math.max(.2, (scroller.clientWidth - PAD * 2) / PAGE_W);
      apply(wasFit ? fit : s);
      scroller.scrollTop = 0;
      scroller.scrollLeft = 0;
    }
    // Keep the point under (x, y) on screen while the scale changes.
    const zoomAt = (v, x, y) => {
      const r = scroller.getBoundingClientRect(), px = (scroller.scrollLeft + x - r.left - PAD) / s, py = (scroller.scrollTop + y - r.top - PAD) / s;
      apply(v);
      scroller.scrollLeft = px * s + PAD - (x - r.left);
      scroller.scrollTop = py * s + PAD - (y - r.top);
    };
    document.body.appendChild(d);
    document.documentElement.classList.add('pp-noscroll');
    d.showModal();
    show(i);
    // Focus starts on Close, in the dialog (Escape works too).
    d.querySelector('[data-close]').focus();
    let pinch = null, tap = 0, moved = false, t0 = null;
    const dist = t => Math.hypot(t[0].clientX - t[1].clientX, t[0].clientY - t[1].clientY);
    scroller.addEventListener('touchstart', e => {
      moved = false;
      t0 = e.touches.length === 1 ? { x: e.touches[0].clientX, y: e.touches[0].clientY } : null;
      if (e.touches.length === 2) pinch = { d: dist(e.touches), s };
    }, { passive: true });
    scroller.addEventListener('touchmove', e => {
      moved = true;
      if (!pinch || e.touches.length !== 2) return;
      e.preventDefault();
      const t = e.touches;
      zoomAt(pinch.s * dist(t) / pinch.d, (t[0].clientX + t[1].clientX) / 2, (t[0].clientY + t[1].clientY) / 2);
    }, { passive: false });
    scroller.addEventListener('touchend', e => {
      if (e.touches.length < 2) pinch = null;
      if (e.changedTouches.length !== 1 || e.touches.length) return;
      const t = e.changedTouches[0];
      // A swipe across a page at its fitted size turns to the next or previous one.
      if (moved && t0 && s <= fit * 1.05) {
        const dx = t.clientX - t0.x, dy = t.clientY - t0.y;
        if (Math.abs(dx) > 60 && Math.abs(dx) > Math.abs(dy) * 1.5) show(i + (dx < 0 ? 1 : -1));
        return;
      }
      if (moved) return;
      // A double tap fits the page, or goes back to full size where it was tapped.
      const now = Date.now();
      if (now - tap < 320) { zoomAt(s > fit * 1.05 ? fit : 1, t.clientX, t.clientY); tap = 0; } else tap = now;
    });
    d.addEventListener('keydown', e => {
      if (e.key === 'ArrowRight' || e.key === 'PageDown') { e.preventDefault(); show(i + 1); }
      else if (e.key === 'ArrowLeft' || e.key === 'PageUp') { e.preventDefault(); show(i - 1); }
    });
    d.addEventListener('close', () => {
      d.remove();
      document.documentElement.classList.remove('pp-noscroll');
      // Focus goes back to the thumbnail of the page last shown.
      const back = typeof opener === 'function' ? opener(i) : opener;
      if (back && back.isConnected) back.focus();
    });
    d.addEventListener('click', e => {
      const b = e.target.closest('button');
      if (!b) return;
      if (b.hasAttribute('data-close')) d.close();
      else if (b.dataset.go) show(i + +b.dataset.go);
    });
  }

  // Each page wrapped as a thumbnail at the size that fits the host's width (cols across), a tap
  // opening it at full size. Used by both pages on a phone, and by the packet everywhere. A tappable
  // thumbnail says so: an expand mark on it and a caption under it ("Page 1 · Fri–Sun").
  const EXPAND = '<svg class="wk-i" viewBox="0 0 24 24" aria-hidden="true"><path d="M14 4h6v6M10 20H4v-6M20 4l-7 7M4 20l7-7" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  function wrapPages(host, sel, opts) {
    opts = opts || {};
    host.querySelectorAll(':scope > ' + sel).forEach((pg, i, all) => {
      const w = document.createElement('section');
      w.className = 'pp-pw';
      const cap = opts.tap && opts.caption ? opts.caption(pg, i) : '';
      const name = 'Page ' + (i + 1) + (cap ? ' · ' + cap : '');
      w.setAttribute('aria-label', 'Page ' + (i + 1) + ' of ' + all.length);
      if (opts.tap) {
        // The frame and its caption together, so the caption sits under its own page.
        const t = document.createElement('div');
        t.className = 'pp-tw';
        pg.replaceWith(t);
        t.appendChild(w);
        t.insertAdjacentHTML('beforeend', '<p class="pp-cap" aria-hidden="true">' + esc(name) + '</p>');
      } else pg.replaceWith(w);
      w.appendChild(pg);
      if (opts.tap) w.insertAdjacentHTML('beforeend', '<button type="button" class="pp-open" data-open="' + i + '" aria-label="' + esc('Open ' + name + ', of ' + all.length) + '"><span class="pp-open__i">' + EXPAND + '</span></button>');
    });
  }
  function scalePages(host, cols) {
    const cs = getComputedStyle(host);
    const gap = parseFloat(cs.columnGap) || 0;
    const avail = host.clientWidth - (parseFloat(cs.paddingLeft) || 0) - (parseFloat(cs.paddingRight) || 0);
    const sc = Math.min(1, Math.max(.1, (avail - gap * ((cols || 1) - 1)) / (cols || 1) / PAGE_W));
    host.querySelectorAll('.pp-pw').forEach(w => {
      w.style.width = Math.floor(PAGE_W * sc) + 'px';
      w.style.height = Math.floor(PAGE_H * sc) + 'px';
      w.firstElementChild.style.transform = sc < 1 ? 'scale(' + sc + ')' : '';
    });
    return sc;
  }

  // A member's check: what, where, and its fix on a muted line of its own (never only in a tooltip),
  // a link to where it's fixed when there is one.
  const checkList = list => list.length ? '<ul class="pp-checks__list">' + list.map(k => {
    const body = '<b>' + esc(k.what) + '</b>' + (k.where ? '<span>' + esc(k.where) + '</span>' : '') + (k.tip ? '<small>' + esc(k.tip) + '</small>' : '');
    return '<li>' + (k.href ? '<a href="' + esc(k.href) + '">' + body + '</a>' : '<span class="pp-checks__row">' + body + '</span>') + '</li>';
  }).join('') + '</ul>' : '';

  window.OGC_PRINT = { viewer, checkList, wrapPages, scalePages, PAGE_W, PAGE_H, prepare, editions, draw, fontsReady, placeName, qr, range, whole, cap, T, nw, code, zones, updatedLabel, itemKey, line };
})();
