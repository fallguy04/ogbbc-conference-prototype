/*
 * schedule.js — the printable schedule (/schedule/): the paper itself on screen, at the size that
 * fits, with one Print button. Which printout (One sheet · Large print · Preteens · Young Folks ·
 * Today during the week) is a row of pills. The year's members also get the sheet's layout for
 * everyone (Columns · List) and what to look at before Publish.
 *
 * On a phone the two pages are thumbnails side by side (what will print, not a third schedule to read),
 * under "2 pages · Print both sides", Print and "Full schedule" (the Conference page's, to read on
 * screen), so the first screen holds it all; a tap opens a page at full size, with Previous and Next.
 * The page's data is in OGC_WP.print (module-print.php), so it draws at once and Print never catches
 * a half-drawn page.
 */
(function () {
  'use strict';
  const O = window.OGC, PR = window.OGC_PRINT, esc = O.esc;
  const W = window.OGC_WP || {}, P = W.print || {};
  const bar = document.getElementById('pp-tools'), host = document.getElementById('pp-sheets');
  if (!bar || !host || P.state !== 'ok' || !PR) return;
  const q = new URLSearchParams(location.search);
  const asOf = O.parseAsOf(q.get('as-of'));
  const phone = window.matchMedia('(max-width: 767px)');
  const svg = d => '<svg class="wk-i" viewBox="0 0 24 24" aria-hidden="true"><path d="' + d + '" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  const icon = svg('M7 9V4h10v5M7 17H5a1.5 1.5 0 0 1-1.5-1.5v-5A1.5 1.5 0 0 1 5 9h14a1.5 1.5 0 0 1 1.5 1.5v5A1.5 1.5 0 0 1 19 17h-2M7 14h10v6H7z');
  const tick = '<svg class="wk-i" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>';

  const chev = '<svg class="wk-i pp-chev" viewBox="0 0 24 24" aria-hidden="true"><path d="M6 9l6 6 6-6" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  const checkList = PR.checkList;

  let c;
  try {
    c = PR.prepare(P, { today: asOf ? asOf.date : '' });
  } catch (e) {
    host.removeAttribute('aria-busy');
    host.innerHTML = '<p class="pp-wait__h">Couldn’t draw the schedule</p>';
    console.error(e);
    return;
  }
  // A row's link to the editor brings the member back here (the editor's Back reads `return`).
  const here = () => location.pathname + location.search;
  const withReturn = u => u + '&return=' + encodeURIComponent(here());
  if (c.edit) c.edit = withReturn(c.edit);
  const savedLayout = () => /^list$/i.test(c.s.print_layout || '') ? 'list' : 'columns';
  const state = { ed: q.get('print') || 'sheet', layout: null, result: null, drawn: null, sizes: null, undo: null, msg: '' };

  /* ------------------------------------------------------------- the bar */

  // Back to where the person came from on this site; otherwise the year's Conference page.
  function backLink() {
    let ref = null;
    try { ref = document.referrer ? new URL(document.referrer) : null; } catch (e) { ref = null; }
    if (ref && ref.origin === location.origin && ref.pathname !== location.pathname) return '<a class="pp-link" href="' + esc(ref.href) + '">Back</a>';
    return '<a class="pp-link" href="' + esc(P.urls.conference) + '">Conference page</a>';
  }

  // The type size each layout gives the sheet, measured off screen once (said in the pills' tooltips).
  function layoutSizes() {
    if (state.sizes) return state.sizes;
    const tmp = document.createElement('div');
    tmp.className = 'pp-measure';
    document.body.appendChild(tmp);
    const out = {};
    const links = c.rowLinks;
    c.rowLinks = false;
    ['columns', 'list'].forEach(l => { out[l] = PR.draw(c, tmp, PR.editions(c, { layout: l })[0]); });
    c.rowLinks = links;
    tmp.remove();
    return (state.sizes = out);
  }
  const pt = n => (Math.round(n * 10) / 10) + ' pt';
  const pill = (attr, id, label, on, tip) => '<button type="button" class="pp-pill" ' + attr + '="' + esc(id) + '" aria-pressed="' + on + '"' + (tip ? ' title="' + esc(tip) + '"' : '') + '>' + tick + '<span>' + esc(label) + '</span></button>';

  // The pills: which printout (this viewer's choice). Print and its status follow them, drawn once,
  // apart (renderAct), so they stay put while the pills are redrawn.
  function renderBar() {
    const eds = PR.editions(c, { layout: state.layout });
    if (!eds.some(e => e.id === state.ed)) state.ed = 'sheet';
    const keep = bar.querySelector('.pp-act');
    bar.innerHTML = '<div class="pp-pick" role="group" aria-label="Printout">' + eds.map(e => pill('data-ed', e.id, e.label, e.id === state.ed, e.tip)).join('') + '</div>';
    if (keep) bar.appendChild(keep);
  }

  // A member's setting for everyone's sheet, apart from the print flow (under To check): the
  // layout, with the type size each gives on the pill itself (the deciding fact for older readers,
  // never only in a tooltip a phone can't show), saved for the year, with Undo.
  function layoutCard() {
    if (!P.member || state.ed !== 'sheet') return '';
    const lay = state.layout || savedLayout();
    const sz = state.fonts ? layoutSizes() : null;
    const lab = l => (l === 'list' ? 'List' : 'Columns') + (sz ? ' · ' + (sz[l].fits ? pt(sz[l].size) : 'Over') : '');
    return '<div class="pp-checks__card pp-lay"><h2 class="pp-checks__h" id="pp-lay-k">Printed layout</h2>' +
      '<div class="pp-pick pp-pick--lay" role="group" aria-labelledby="pp-lay-k" aria-describedby="pp-lay-h">' +
        pill('data-lay', 'columns', lab('columns'), lay === 'columns', 'Time, then Conference · Preteens · Young Folks side by side') +
        pill('data-lay', 'list', lab('list'), lay === 'list', 'One list a day, in two columns') + '</div>' +
      '<p class="pp-help" id="pp-lay-h">For everyone’s printout' + (state.msg ? ' · <b>' + esc(state.msg) + '</b>' + (state.undo ? ' · <button type="button" class="pp-undo" data-undo>Undo</button>' : '') : '') + '</p></div>';
  }

  // Print, the page count, and at most two quiet links, under the pills (on a phone too, so the first
  // screen holds the whole page).
  let act = null;
  function renderAct() {
    if (!act) {
      const links = [];
      if (!P.member) links.push(backLink());
      // "Full schedule": the Conference page's own name for the schedule to read on screen.
      if (P.urls.full) links.push('<a class="pp-link" href="' + esc(P.urls.full) + '">Full schedule</a>');
      if (P.member && P.urls.edit) links.push('<a class="pp-link" href="' + esc(phone.matches && P.urls.part ? P.urls.part : withReturn(P.urls.edit)) + '">Edit schedule</a>');
      act = document.createElement('div');
      act.className = 'pp-act';
      act.innerHTML = '<button type="button" class="wk-btn" data-print title="Print, or save as a PDF">' + icon + 'Print</button>' +
        '<p class="pp-status" id="pp-status" role="status" aria-live="polite"></p>' +
        (links.length ? '<p class="pp-links">' + links.join('') + '</p>' : '');
      act.addEventListener('click', e => { if (e.target.closest('[data-print]')) printNow(); });
    }
    if (act.parentElement !== bar) bar.appendChild(act);
  }

  function status(t, over) {
    const el = document.getElementById('pp-status');
    if (el) { el.textContent = t; el.classList.toggle('is-over', !!over); }
  }

  // What a member looks at before Publish: the fit, the rows marked ◆ (one line, "Check rows" opens
  // the editor at the first; the list folds under it), then the server's checks (personal numbers,
  // unknown places, rows twice, dates). Nothing is drawn when there's nothing to look at.
  function renderChecks() {
    const box = document.getElementById('pp-checks');
    if (!box || !P.member) return;
    const r = state.result;
    const fit = r && !r.fits ? [{ what: r.pages + ' pages · Over ' + (r.target === 2 ? 'one sheet' : 'one page'), where: 'Printout', tip: 'Shorten a title or a printed note, or take out a row', href: P.urls.edit ? withReturn(P.urls.edit) : '' }] : [];
    const look = [];
    if (c.look.size) {
      // A day's all-day rows first, as the sheet prints them, then its rows by time.
      c.m.days.forEach(d => d.allDay.concat(d.items).forEach(it => {
        if (!c.look.has(PR.itemKey(it))) return;
        look.push({ what: it.title, where: d.name + ' ' + (it.start != null ? PR.T(it.start) : it.startText || ''), href: c.edit ? editAt(it, d) : '' });
      }));
    }
    const list = fit.concat((P.checks || []).filter(k => k.part === 'schedule'));
    const lay = layoutCard();
    box.hidden = !look.length && !list.length && !lay;
    if (box.hidden) { box.innerHTML = ''; return; }
    const open = box.querySelector('.pp-checks__more[open]');
    // On a phone, "Check rows" is the year page's own check tool (the editor is for a laptop).
    const first = look.length && (phone.matches && P.urls.checkPhone ? P.urls.checkPhone : look[0].href);
    const rows = look.length ? '<p class="pp-checks__rows"><b>' + look.length + (look.length === 1 ? ' row' : ' rows') + ' to check</b>' +
        (first ? ' · <a href="' + esc(first) + '">Check rows</a>' : '') + '</p>' +
      '<details class="pp-checks__more"' + (open ? ' open' : '') + '><summary><span>' + (open ? 'Hide rows' : 'Show rows') + '</span>' + chev + '</summary><ul>' + look.map(k =>
        '<li>' + (k.href && !phone.matches ? '<a href="' + esc(k.href) + '"><b>◆ ' + esc(k.what) + '</b><span>' + esc(k.where) + '</span></a>' : '<span class="pp-checks__row"><b>◆ ' + esc(k.what) + '</b><span>' + esc(k.where) + '</span></span>') + '</li>').join('') + '</ul></details>' : '';
    box.innerHTML = (look.length || list.length ? '<div class="pp-checks__card"><h2 class="pp-checks__h">To check</h2>' + rows + checkList(list) + '</div>' : '') + lay;
    // The fold says what it does next: Show rows, then Hide rows.
    const more = box.querySelector('.pp-checks__more');
    if (more) more.addEventListener('toggle', () => { more.querySelector('summary span').textContent = more.open ? 'Hide rows' : 'Show rows'; });
  }
  // The editor, at this row, with "Looks right" to press.
  function editAt(it, d) {
    return c.edit.replace('edit=schedule', 'edit=' + encodeURIComponent('schedule:' + d.name)) + (it.row ? '&row=' + encodeURIComponent(it.row) : '') + '&check=1';
  }

  /* ------------------------------------------------------------- the paper */

  // On a phone the two pages sit side by side (about 170 px each: what prints, not to read).
  const scale = () => PR.scalePages(host, phone.matches ? 2 : 1);

  function statusText(ed, r) {
    const pages = r.pages + (r.pages === 1 ? ' page' : ' pages');
    if (!r.fits) return [pages + ' · Over ' + (r.target === 2 ? 'one sheet' : 'one page'), true];
    if (r.pages === 2 && ed.target === 2) return ['2 pages · Print both sides', false];
    if (r.pages > 1) return [pages + ' · Print both sides', false];
    return [pages, false];
  }

  function draw() {
    host.setAttribute('aria-busy', 'true');
    const eds = PR.editions(c, { layout: state.layout });
    const ed = eds.find(e => e.id === state.ed) || eds[0];
    // On a phone the thumbnails carry no links (a tap opens the page; Edit schedule is enough).
    c.rowLinks = !phone.matches;
    const r = PR.draw(c, host, ed);
    state.result = r;
    // Each page is a region named for its place in the printout; its tables stay tables.
    // On a phone each thumbnail says which days it holds ("Page 1 · Fri–Sun").
    PR.wrapPages(host, '.pr-page', { tap: phone.matches, caption: pg => {
      const ds = (pg._days || []).filter(d => d && d.date), a = ds[0], b = ds[ds.length - 1];
      return a ? O.fmtDate(a.date, 'weekdayShort') + (b !== a ? '–' + O.fmtDate(b.date, 'weekdayShort') : '') : '';
    } });
    host.classList.toggle('is-thumbs', phone.matches);
    scale();
    host.removeAttribute('aria-busy');
    const st = statusText(ed, r);
    status(st[0], st[1]);
    renderChecks();
    if (ed.id === 'sheet') report(r);
    state.drawn = ed.id;
  }

  // The fit, for the year page's card ("Printout · 2 pages · Fits"). Members only; only when it changed.
  function report(r) {
    if (!P.member || !W.api) return;
    const v = { pages: r.pages, fits: r.fits, size: r.size, layout: r.layout };
    const was = P.status || {};
    if (was.pages === v.pages && was.fits === v.fits && was.size === v.size && was.layout === v.layout) return;
    P.status = Object.assign({ at: new Date().toISOString() }, v);
    W.api('PUT', 'years/' + P.year + '/state/print_status', { value: P.status }).catch(e => console.warn('Fit not saved', e));
  }

  host.addEventListener('click', e => {
    const b = e.target.closest('[data-open]');
    if (b) PR.viewer(() => Array.from(host.querySelectorAll('.pp-pw > .pr-page')), +b.dataset.open, k => host.querySelectorAll('.pp-open')[k]);
  });

  /* ------------------------------------------------------------- choices */

  function setParam() {
    const u = new URL(location.href);
    if (state.ed === 'sheet') u.searchParams.delete('print'); else u.searchParams.set('print', state.ed);
    history.replaceState(null, '', u);
  }

  // The sheet's layout is the year's (settings print_layout), for everyone's printout.
  function saveLayout(v, undoTo) {
    state.layout = v;
    state.msg = 'Saving';
    state.undo = null;
    draw();
    const again = document.querySelector('[data-lay="' + v + '"]');
    if (again) again.focus();
    if (!W.api) return;
    W.api('PATCH', 'years/' + P.year + '/files/settings', { op: 'key', key: 'print_layout', value: v })
      .then(() => { c.s.print_layout = v; state.msg = 'Saved'; state.undo = undoTo || null; })
      .catch(() => { state.msg = 'Not saved'; state.layout = null; })
      .then(() => {
        const f = document.activeElement && document.activeElement.dataset ? document.activeElement.dataset.lay : null;
        if (state.layout === null) draw(); else renderChecks();
        const b = f && document.querySelector('[data-lay="' + f + '"]');
        if (b) b.focus();
      });
  }

  const onChoice = e => {
    const b = e.target.closest('button');
    if (!b) return;
    if (b.dataset.ed) {
      state.ed = b.dataset.ed;
      setParam();
      renderBar();
      draw();
      const again = bar.querySelector('[data-ed="' + state.ed + '"]');
      if (again) again.focus();
    } else if (b.dataset.lay) {
      const was = state.layout || savedLayout();
      if (b.dataset.lay !== was) saveLayout(b.dataset.lay, was);
    } else if (b.hasAttribute('data-undo')) {
      saveLayout(state.undo, null);
    }
  };
  bar.addEventListener('click', onChoice);
  const checksBox = document.getElementById('pp-checks');
  if (checksBox) checksBox.addEventListener('click', onChoice);

  // The saved PDF's name: "2026 Conference schedule" (sentence case, as every title on the site).
  let title0 = document.title;
  const pdfName = () => P.year + ' ' + (state.ed === 'preteens' ? 'Preteens schedule' : state.ed === 'youngfolks' ? 'Young Folks schedule' : state.ed === 'large' ? 'Conference schedule, large print' : state.ed === 'today' ? 'Schedule today' : 'Conference schedule');
  addEventListener('beforeprint', () => { title0 = document.title; document.title = pdfName(); if (!state.drawn) draw(); });
  addEventListener('afterprint', () => { document.title = title0; });
  function printNow() { ready.then(() => window.print()); }

  // The theme around the page doesn't print: only the path down to the paper is kept.
  document.body.classList.add('ogc-print-doc');
  host.classList.add('pp-print-root');
  for (let n = host.parentElement; n && n !== document.body; n = n.parentElement) n.classList.add('pp-path');

  c.rowLinks = !phone.matches;
  renderBar();
  renderAct();
  const ready = PR.fontsReady().then(() => { state.fonts = true; state.sizes = null; draw(); });
  let t = 0;
  addEventListener('resize', () => { if (printing.matches) return; clearTimeout(t); t = setTimeout(scale, 80); });
  // Phone ↔ laptop: Print moves, and the thumbnails get (or lose) their taps.
  // (Printing changes the width the media queries see: the paper is never redrawn while it prints.)
  const printing = window.matchMedia('print');
  const onPhone = () => { if (printing.matches) return; renderBar(); renderAct(); if (state.drawn) draw(); };
  if (phone.addEventListener) phone.addEventListener('change', onPhone);
  // A font that arrives late changes the measure: draw again.
  if (document.fonts) document.fonts.addEventListener('loadingdone', () => { if (state.drawn && !printing.matches) { clearTimeout(t); t = setTimeout(() => { state.sizes = null; draw(); }, 120); } });
})();
