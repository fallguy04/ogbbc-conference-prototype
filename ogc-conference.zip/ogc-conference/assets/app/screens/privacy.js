/*
 * privacy.js — Privacy: who sees people's details in the year (access area, Oct 13–14; docs/26
 * decision 25). Each row is a kind of detail (children's, households, rooms, each payment…) and who may
 * see it, worked out by the server from the same rule its routes ask (module-guard.php ogc_access_for),
 * never typed here. The COA sees the names; the webmasters see how many (they see structure, not
 * people). At the side: every See as in the last 30 days, and every privacy request, with who ran it.
 * Who is on which committee, and Handles money, are changed on Members.
 */
(function () {
  'use strict';
  const A = window.OGC_APP;
  if (!A) return;
  const h = A.h;

  A.screen({
    id: 'privacy', title: 'Privacy', icon: 'eye', section: 'own', who: ['coa', 'webmaster'],
    render(ctx) {
      let alive = true;
      ctx.head('Privacy', '', []);
      ctx.body.appendChild(h('div', { class: 'ap-quiet', role: 'status', text: 'Loading' }));
      ctx.api('GET', 'privacy').then(d => { if (alive) page(ctx, d); }, () => {
        if (!alive) return;
        A.clear(ctx.body).appendChild(A.empty({ title: 'Not loaded', line: 'Reload the page', inset: true }));
      });
      return () => { alive = false; };
    }
  });

  function page(ctx, d) {
    const v = d.viewer || {};
    const money = d.money || { n: 0, names: [] };
    const members = { s: 'members', id: '', c: '', v: '' };
    // A name opens that person beside Members, with "← Privacy" back here (Round 6b; P1 for the COA).
    const personLink = pp => {
      if (!v.coa || !pp.id) return h('span', { text: pp.name });
      const go = { s: 'members', id: String(pp.id), c: '', v: '' };
      return h('a', { class: 'pv-name', href: A.href(Object.assign({ from: 'privacy' }, go)), 'data-person': String(pp.id), text: pp.name,
        on: { click: e => { if (e.metaKey || e.ctrlKey || e.shiftKey || e.button !== 0) return; e.preventDefault(); A.follow(go, 'privacy', 'Privacy'); } } });
    };
    // The fact is the one choice this screen hangs on: who handles money (a name opens them).
    const fact = money.n ? h('span', null, 'Handles money · ', (money.people || []).length ? (money.people || []).map((pp, i) => [i ? ', ' : '', personLink(pp)]) : (money.names.length ? money.names.join(', ') : A.fmt.plural(money.n, 'person', 'people'))) : h('span', { class: 'pp-tan', text: 'No one handles money' });
    const acts = [];
    if (v.coa && !money.n) acts.push(A.btn('Choose', { primary: true, href: A.href({ s: 'members', id: '', c: '', v: '', at: 'money' }), title: 'Who handles money · On Members' }));
    else if (v.coa) acts.push(A.btn('Members', { ghost: true, icon: 'members', href: A.href(members) }));
    ctx.head('Privacy', fact, acts);
    A.clear(ctx.body);

    const main = h('div', { class: 'pv-main' });
    const side = h('div', { class: 'pv-side' });
    ctx.body.appendChild(h('div', { class: 'ap-cols' }, main, side));

    // One row a kind of detail: what it is, then who sees it, by the place that gives it.
    const list = h('ul', { class: 'ap-list pv-rules', 'aria-label': 'Who sees what' });
    // Each group names the place that gives it (a door to that committee's page) and its people (doors).
    const place = g => g.key === 'money' ? (v.coa ? A.link({ s: 'members', id: '', c: '', v: '', at: 'money' }, g.label, 'pv-group__label pv-door') : h('span', { class: 'pv-group__label', text: g.label }))
      : g.key && (A.committee(g.key) || g.key === 'coa') ? A.link({ s: 'committees', c: g.key, id: '', v: '' }, g.label, 'pv-group__label pv-door') : h('span', { class: 'pv-group__label', text: g.label });
    const names = g => (g.people || []).length ? h('span', { class: 'pv-group__names' }, g.people.map((pp, i) => [i ? ', ' : '', personLink(pp)])) : h('span', { class: 'pv-group__names', text: g.names.length ? g.names.join(', ') : A.fmt.plural(g.n, 'person', 'people') });
    (d.rules || []).forEach(r => list.appendChild(row(r.what, r.detail, r.groups.length ? r.groups.map(g => h('div', { class: 'pv-group', 'data-group': g.key || '' }, place(g), names(g))) : [group('', 'No one', true)], r.key)));
    const wm = d.webmasters || { n: 0, names: [] };
    const onYear = d.on_year || [];
    const yr = ctx.boot.year;
    list.appendChild(row('Webmasters', 'Years, access, publishing',
      [group('People', onYear.length ? 'By See as · Logged · Or on ' + yr : 'Only by See as · Logged'),
        onYear.length ? group('On ' + yr, onYear.map(x => x.who + ' · ' + x.as).join(', ')) : null,
        wm.names.length ? group(A.fmt.plural(wm.n, 'webmaster'), wm.names.join(', ')) : null], 'webmasters'));
    main.appendChild(list);
    main.appendChild(v.coa ? h('p', { class: 'ap-help pv-foot' }, 'Committees and ', A.link({ s: 'members', id: '', c: '', v: '', at: 'money' }, 'Handles money'), ' change on ', A.link(members, 'Members'))
      : h('p', { class: 'ap-help pv-foot', text: 'Names show to the COA · Webmasters see how many' }));

    // Webmasters on the year, See as and privacy requests: never a zero (an empty section isn't drawn).
    // A webmaster can't add themselves; the COA can remove one on Members.
    if (onYear.length) side.appendChild(section('Webmasters on ' + yr, onYear.length, 'They see what that place sees · ' + (v.coa ? 'Remove on Members' : 'Added by another webmaster or the COA'),
      onYear.map(x => v.coa ? h('li', null, h('a', { class: 'ap-item', href: A.href({ s: 'members', id: x.id, c: '', v: '' }) }, h('span', { class: 'ap-item__main' },
        h('span', { class: 'ap-item__title', text: x.who + ' · ' + x.as }), h('span', { class: 'ap-item__why', text: ['Added by ' + (x.by || 'a webmaster'), x.when].filter(Boolean).join(' · ') }))))
        : item(x.who + ' · ' + x.as, ['Added by ' + (x.by || 'a webmaster'), x.when].filter(Boolean).join(' · ')))));
    // See as, folded by person and day ("Webmaster · 14 committees · Oct 14"); each committee a door.
    const folds = d.seen_folds || [];
    if (folds.length) side.appendChild(section('See as', folds.length, 'Last 30 days · Read only · Logged', folds.map(x => h('li', { class: 'pv-seen' }, h('details', { class: 'ap-item pv-fold' },
      h('summary', null, h('span', { class: 'ap-item__main' }, h('span', { class: 'ap-item__title', text: x.who + ' · ' + (x.as.length === 1 ? x.as[0].name : x.as.length + ' committees') }), h('span', { class: 'ap-item__why', text: x.when }))),
      h('div', { class: 'pv-fold__as' }, x.as.map((c, i) => [i ? ' · ' : '', c.key === 'coa' ? A.link({ s: 'committees', c: 'coa', id: '', v: '' }, 'COA', 'pv-door') : A.link({ s: 'committees', c: c.key, id: '', v: '' }, c.name, 'pv-door')])))))));
    const asks = d.requests || [];
    if (asks.length) side.appendChild(section('Privacy requests', asks.length, 'Export or erase one person’s records', asks.map(x => item(x.what + ' · ' + x.who, x.when))));
  }

  function row(what, detail, groups, key) {
    return h('li', { class: 'pv-rule', 'data-key': key },
      h('div', { class: 'pv-rule__what' }, h('span', { class: 'ap-item__title', text: what }), h('span', { class: 'ap-item__why', text: detail })),
      h('div', { class: 'pv-rule__who' }, groups));
  }

  function group(label, text, quiet) {
    return h('div', { class: 'pv-group' }, label ? h('span', { class: 'pv-group__label', text: label }) : null,
      h('span', { class: 'pv-group__names' + (quiet ? ' ap-quiet' : ''), text }));
  }

  function section(title, n, help, items) {
    return h('section', { class: 'ap-section' },
      h('h2', { class: 'ap-h2' }, title, h('span', { class: 'ap-h2__n', text: String(n) })),
      h('p', { class: 'ap-help pv-help', text: help }),
      h('ul', { class: 'ap-list' }, items));
  }

  function item(title, why) {
    return h('li', null, h('div', { class: 'ap-item' }, h('span', { class: 'ap-item__main' },
      h('span', { class: 'ap-item__title', text: title }), h('span', { class: 'ap-item__why', text: why }))));
  }
})();
