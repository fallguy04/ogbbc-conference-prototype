/*
 * coa-callin.js — Call-in: the phone line for the services, its own screen (handable on its own:
 * docs/scope/05 Q17; docs/24 A/V, Oct 12). Routes: module-schedule.php (app/{y}/callin…).
 *
 *   - The line: the provider (a fixed list), the number, the PIN (blank when there's none), # after the
 *     PIN, who holds the account (a role address), the trouble line, and Not used this year. A line
 *     carried from last year waits for Looks right before any public page shows it.
 *   - The rows: which of the week's rows go out on the line, and which are recorded for playback, two
 *     ticks each (the Schedule screen shows the same two). They go public when saved.
 *   - Playback: the provider decides the numbers. FreeConferenceCall numbers recordings 1, 2, 3 in the
 *     order they're made; Midwest Conference Online by date. Each recorded row shows the number to
 *     expect by that rule, and whoever runs the line types the number the provider gave: Numbered.
 *   - Download: the rows on the line with their times in five zones, for The Testimony and Listening by
 *     phone (the same columns every year), as Excel or CSV.
 * No streaming anywhere, and nothing on the site runs the line: A/V runs it on the provider's account.
 */
(function () {
  'use strict';
  const A = window.OGC_APP, K = window.OGC_COA, W = window.OGC_WP || {};
  if (!A || !K) return;
  const h = A.h;
  const lc = s => String(s == null ? '' : s).trim().toLowerCase();
  if (A.addIcons) A.addIcons({ phone: 'M5.2 2.5h-1.7A1 1 0 0 0 2.5 3.6C2.9 9 7 13.1 12.4 13.5a1 1 0 0 0 1.1-1v-1.7l-2.6-1-1.3 1.3A7.5 7.5 0 0 1 5.9 6.9l1.3-1.3z' });

  A.screen({
    id: 'callin', title: 'Call-in', icon: 'phone', section: 'own', who: ['coa'],
    render(ctx) {
      let alive = true;
      ctx.head('Call-in', '', []);
      K.loading(ctx.body);
      const st = { view: ctx.params.v || '', sel: ctx.params.id || '' };
      const load = () => A.api('GET', 'callin').then(data => { if (alive) draw(ctx, data, st, load); }, err => { if (alive) K.failed(ctx.body, err); });
      load();
      return () => { alive = false; };
    }
  });

  function fetchFile(path, name) {
    const q = new URLSearchParams(location.search);
    const as = q.get('as') ? '&as=' + encodeURIComponent(q.get('as')) : '';
    return fetch((W.rest || '/wp-json/ogc/v1/') + path + as, { credentials: 'same-origin', headers: { 'X-WP-Nonce': W.nonce || '' } })
      .then(r => { if (!r.ok) throw Object.assign(new Error('Not downloaded'), { status: r.status }); return r.blob(); })
      .then(b => { const a = h('a', { href: URL.createObjectURL(b) }); a.download = name; document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 4000); });
  }

  function draw(ctx, data, st, reload) {
    const y = ctx.params.year;
    const L = data.line, can = data.can.edit && !A.readonly;
    const prov = (data.providers || {})[L.provider] || null;
    const rows = data.rows || [];
    const onLine = rows.filter(r => r.call_in && !r.private);
    const recorded = onLine.filter(r => r.recorded);
    const exp = data.expected || {}, pb = data.playback || {};
    const today = data.today || '';
    // During the week (and after), the numbers are the work; before it, which rows go out.
    const pastRecorded = recorded.filter(r => r.date && r.date <= today);
    if (!st.view) st.view = pastRecorded.some(r => !(pb[r.id] || {}).st) ? 'playback' : 'line';
    const stateOf = r => { const e = pb[r.id] || {}; return !r.recorded ? '' : e.st === 'not' ? 'not' : e.n ? 'numbered' : 'expected'; };

    /* ---------------------------------------------------------- the title row */
    const fact = L.status === 'off' ? 'Not used this year'
      : !L.number ? 'No number yet'
      : [prov ? prov.name : 'Provider not set', L.number, L.pin ? 'PIN ' + L.pin : 'No PIN', K.plural(onLine.length, 'row') + ' on the line'].join(' · ') + (data.handed ? ' · With ' + data.handed : '');
    const dl = A.btn('Download', { ghost: true, icon: 'down', title: 'The rows on the line, with their times in five zones · Or the whole schedule', onClick: e => A.menu(e.currentTarget, [
      { label: 'Call-in line · Excel', run: () => fetchFile('app/' + y + '/callin?format=xlsx', y + ' Call-in line.xlsx').then(() => A.toast('Downloaded · Call-in line'), () => A.toast('Not downloaded')) },
      { label: 'Call-in line · CSV', run: () => fetchFile('app/' + y + '/callin?format=csv', y + ' Call-in line.csv').then(() => A.toast('Downloaded · Call-in line'), () => A.toast('Not downloaded')) },
      // The whole schedule, for layout work (A/V's printed schedule), without holding Schedule.
      { label: 'Whole schedule · Excel', run: () => fetchFile('app/' + y + '/schedule/export?format=xlsx', y + ' Conference schedule.xlsx').then(() => A.toast('Exported · Schedule'), () => A.toast('Not exported')) },
      { label: 'Whole schedule · CSV', run: () => fetchFile('app/' + y + '/schedule/export?format=csv', y + ' Conference schedule.csv').then(() => A.toast('Exported · Schedule'), () => A.toast('Not exported')) }
    ]) });
    ctx.head('Call-in', fact, [dl]);

    A.clear(ctx.body);
    const sp = ctx.split();
    sp.el.classList.add('cx-split', 'cl-split');

    /* ---------------------------------------------------------- the line */
    const patch = (fields, label, field) => {
      return A.api('PATCH', 'callin', { fields }).then(d => {
        A.toast('Saved · ' + label);
        K.drop(y);
        Object.assign(data, d);
        return '';
      }, err => {
        const m = err && err.data && err.data.message ? err.data.message : (err && err.message) || 'Not saved';
        if (!field) A.fail(err);
        return m;
      });
    };
    // A text field that saves when left, with the server's reason at the field.
    const text = (key, label, o) => {
      const el = K.textIn({ value: L[key] || '', label, placeholder: o.placeholder || '', inputmode: o.inputmode || null, width: o.width || null, live: false, disabled: !can });
      const fld = K.field(label, el, { help: o.help || '', tip: o.tip || '' });
      const save = () => {
        const v = el.value.trim();
        if (v === (L[key] || '')) { fld.setError(''); return; }
        patch({ [key]: v }, label, true).then(m => { fld.setError(m); if (!m) { L[key] = v; if (o.redraw) draw(ctx, data, st, reload); } });
      };
      el.addEventListener('change', save);
      el.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); save(); } });
      return fld;
    };
    const pills = (key, label, opts, o) => K.field(label, K.pills(opts, L[key] || '', v => { patch({ [key]: v }, label).then(m => { if (!m) { L[key] = v; draw(ctx, data, st, reload); } }); }, { label, disabled: !can }), { tag: 'div', help: (o && o.help) || '' });

    const lineEl = h('section', { class: 'cl-line', 'aria-label': 'The line' });
    // Carried from last year: not public until someone checks it with the provider.
    if (L.status === 'check') {
      lineEl.appendChild(h('div', { class: 'cx-from', role: 'note' },
        h('span', { class: 'cx-from__t', text: 'From ' + (L.from || 'last year') }), h('span', { class: 'ap-quiet', text: 'Not public until checked with the provider' }),
        A.btn('Looks right', { primary: true, write: true, disabled: !can, onClick: () => confirm(true) })));
    } else if (L.status === 'off') {
      lineEl.appendChild(h('div', { class: 'cx-from cl-off', role: 'note' }, h('span', { class: 'cx-from__t', text: 'Not used this year' }), h('span', { class: 'ap-quiet', text: 'Not on any public page' }),
        can ? K.link('Use it', () => patch({ off: '' }, 'In use').then(m => { if (!m) reload(); })) : null));
    } else if (L.confirmed) {
      lineEl.appendChild(h('p', { class: 'ap-help cl-conf' }, 'Checked · ' + K.md(L.confirmed.at) + (L.confirmed.by ? ' · ' + L.confirmed.by : ''), can ? [' · ', K.link('Undo', () => confirm(false))] : null));
    }
    const provOpts = Object.keys(data.providers || {}).map(k => [k, data.providers[k].name, data.providers[k].words]);
    lineEl.append(h('div', { class: 'cl-grid' },
      h('div', null,
        pills('provider', 'Provider', provOpts, { help: prov ? prov.words : 'How playback numbers are given follows it' }),
        text('number', 'Number', { placeholder: '717-908-1961', inputmode: 'tel', width: '220px', help: 'On the Conference page, the guide and paper', redraw: true }),
        h('div', { class: 'cx-two' },
          text('pin', 'PIN', { placeholder: 'None', inputmode: 'numeric', width: '160px', help: 'Blank when there’s none', redraw: true }),
          L.pin ? pills('hash', '# after the PIN', [['', 'No'], ['yes', 'Yes']]) : null)),
      h('div', null,
        prov && prov.playback === 'order' ? text('first', 'First playback number', { inputmode: 'numeric', width: '120px', help: 'Blank is 1 · Higher when the account already has recordings', redraw: true }) : null,
        text('account', 'Account held by', { placeholder: 'av@…', width: '280px', help: 'A role address the next committee can reach · Never a person’s own' }),
        h('div', { class: 'cx-two' },
          text('trouble_role', 'Trouble line', { placeholder: 'A/V', width: '160px', help: 'Who a listener calls' }),
          text('trouble_phone', 'Its number', { placeholder: 'Phone', inputmode: 'tel', width: '180px' })))));
    if (can && L.status !== 'off') {
      const sw = h('input', { type: 'checkbox', class: 'ap-check' });
      sw.addEventListener('change', () => { if (sw.checked) patch({ off: 'yes' }, 'Not used this year').then(m => { if (!m) reload(); }); });
      lineEl.appendChild(h('label', { class: 'ap-switch cl-offsw' }, sw, h('span', { text: 'Not used this year' })));
    }
    function confirm(done) {
      A.api('POST', 'callin/confirm', { done }).then(d => { Object.assign(data, d); K.drop(y); A.toast(done ? 'Checked · Call-in line' : 'Undone · Call-in line', done ? { undo: () => confirm(false) } : null); draw(ctx, data, st, reload); }, A.fail);
    }

    /* ---------------------------------------------------------- the rows */
    const views = [
      { id: 'line', label: 'On the line', n: onLine.length },
      { id: 'playback', label: 'Playback', n: recorded.length },
      { id: 'all', label: 'All rows', n: rows.length }
    ];
    const list = st.view === 'all' ? rows : st.view === 'playback' ? recorded : onLine;
    const bar = A.views(views, st.view, id => { st.view = id; A.setParams({ v: id }); draw(ctx, data, st, reload); });
    const tick = (r, field) => {
      const on = field === 'call_in' ? r.call_in : r.recorded;
      const cb = h('input', { type: 'checkbox', class: 'ap-check', checked: on, disabled: !can || (field === 'recorded' && !r.call_in), 'aria-label': (field === 'call_in' ? 'On the line · ' : 'Recorded · ') + r.title });
      cb.addEventListener('change', () => {
        cb.disabled = true;
        A.api('POST', 'callin/rows', { ids: [r.id], [field]: cb.checked }).then(() => {
          A.toast((field === 'call_in' ? (cb.checked ? 'On the line' : 'Off the line') : (cb.checked ? 'Recorded' : 'Not recorded')) + ' · ' + r.title + (data.public ? ' · Public now' : ''));
          reload();
        }, err => { cb.checked = !cb.checked; cb.disabled = false; A.fail(err); });
      });
      return cb;
    };
    const numberIn = r => {
      const e = pb[r.id] || {}, s = stateOf(r);
      if (!r.recorded) return null;
      const inp = h('input', { class: 'ap-input cl-num', value: e.n || '', 'aria-label': 'Playback number · ' + r.title, disabled: !can || s === 'not', inputmode: prov && prov.playback === 'order' ? 'numeric' : null, title: exp[r.id] ? 'Expected ' + exp[r.id] + ' · Type the number the provider gave' : 'Type the number the provider gave' });
      const save = () => {
        const v = inp.value.trim();
        if (v === (e.n || '')) return;
        A.api('POST', 'callin/playback', { id: r.id, number: v }).then(d => { data.playback = d.playback; if (d.expected) data.expected = d.expected; A.toast(v ? 'Numbered · ' + r.title + ' · ' + v : 'Cleared · ' + r.title); draw(ctx, data, st, reload); }, A.fail);
      };
      inp.addEventListener('change', save);
      inp.addEventListener('keydown', ev => { if (ev.key === 'Enter') { ev.preventDefault(); save(); } });
      return inp;
    };
    const stateTag = r => {
      const s = stateOf(r);
      return s === 'numbered' ? A.tag('Numbered', 'ok') : s === 'not' ? A.tag('Not recorded') : s === 'expected' ? h('span', { class: 'ap-quiet cl-exp', text: exp[r.id] ? 'Expected ' + exp[r.id] : 'Expected' }) : null;
    };
    const dayOf = r => r.date ? K.wd(r.date) : r.day;
    const table = A.table({
      label: 'Rows on the call-in line',
      rows: list,
      key: r => r.id,
      selected: st.sel,
      group: r => dayOf(r),
      onOpen: r => openRow(r),
      empty: A.empty({ inset: true, title: st.view === 'playback' ? 'Nothing recorded yet' : st.view === 'all' ? 'No rows yet' : 'Nothing on the line yet', line: st.view === 'all' ? 'The Schedule screen adds rows' : 'Tick rows under All rows' }),
      cols: [
        { label: 'When', cls: 'ap-td--nowrap cx-td--when cl-td--when', render: r => r.exact ? r.when : h('span', { class: 'cx-warn', text: r.when || 'No time' }) },
        // On a phone the time sits under the title, so the ticks and the number fit beside it.
        { label: 'What', cls: 'cx-td--what', render: r => [h('span', { class: 'ap-cell-title', text: r.title }), r.private ? h('span', { class: 'cx-marks' }, A.tag('Committees only')) : null, h('span', { class: 'ap-cell-sub cl-when-sub' + (r.exact ? '' : ' cx-warn'), text: r.when || 'No time' })] },
        { label: 'Where', cls: 'cx-td--where', wide: true, render: r => r.where },
        { label: 'On the line', cls: 'cl-td--tick', render: r => tick(r, 'call_in') },
        { label: 'Recorded', cls: 'cl-td--tick', render: r => r.call_in ? tick(r, 'recorded') : null },
        { label: 'Playback', cls: 'cl-td--num', render: r => r.recorded ? h('span', { class: 'cl-numcell' }, numberIn(r), stateTag(r)) : null }
      ]
    });
    const rowsEl = h('section', { class: 'cl-rows', 'aria-label': 'Rows' },
      h('div', { class: 'ap-views cx-views' }, bar),
      table,
      h('p', { class: 'ap-help cl-foot', text: (prov && prov.playback !== 'none' ? 'Expected numbers follow ' + prov.name + '’s rule · The typed number is the one that counts · ' : '') + 'Download gives each start in Eastern, Central, Mountain, Pacific and Arizona time' }));
    // On a phone during the week the numbers are the work: they come first, the line's form after.
    if (st.view === 'playback' && !K.wide() && L.status !== 'check') sp.main.append(rowsEl, lineEl);
    else sp.main.append(lineEl, rowsEl);

    /* ---------------------------------------------------------- one row, beside the list */
    function openRow(r) {
      st.sel = r.id;
      A.setParams({ id: r.id });
      sp.el.querySelectorAll('tr[data-key]').forEach(x => x.setAttribute('aria-selected', String(x.dataset.key === r.id)));
      const e = pb[r.id] || {};
      const s = stateOf(r);
      const ticks = (field, v) => A.api('POST', 'callin/rows', { ids: [r.id], [field]: v }).then(() => { A.toast('Saved · ' + r.title + (data.public ? ' · Public now' : '')); reload(); }, A.fail);
      const note = K.textIn({ value: e.note || '', label: 'Note', multiline: true, rows: 2, placeholder: 'Recording started late', disabled: !can || !r.call_in, onSave: v => { A.api('POST', 'callin/playback', { id: r.id, note: v }).then(d => { data.playback = d.playback; }, A.fail); } });
      const body = h('div', { class: 'cx-rec' },
        K.facts([
          ['Day', dayOf(r)],
          ['When', r.exact ? r.when : h('span', { class: 'cx-warn', text: (r.when || 'No time') + ' · Set exact time' })],
          ['Where', r.where],
          ['For', r.audience === 'All' ? 'Everyone' : r.audience]
        ]),
        K.field('On the call-in line', K.pills([['', 'No'], ['yes', 'Yes']], r.call_in ? 'yes' : '', v => ticks('call_in', v === 'yes'), { label: 'On the call-in line', disabled: !can }), { tag: 'div', help: data.public ? 'Goes public when saved' : 'Live on the phone line' }),
        r.call_in ? K.field('Recorded', K.pills([['yes', 'Yes'], ['', 'No']], r.recorded ? 'yes' : '', v => ticks('recorded', v === 'yes'), { label: 'Recorded', disabled: !can }), { tag: 'div', help: 'For playback by phone' }) : null,
        r.recorded ? K.field('Playback number', h('div', { class: 'cl-numrow' }, numberIn(r), exp[r.id] ? h('span', { class: 'ap-quiet', text: 'Expected ' + exp[r.id] }) : null), { tag: 'div', help: 'The number the provider gave' }) : null,
        r.recorded ? K.field('Status', K.pills([['', 'Expected'], ['numbered', 'Numbered'], ['not', 'Not recorded']], s === 'not' ? 'not' : s === 'numbered' ? 'numbered' : '', v => {
          A.api('POST', 'callin/playback', { id: r.id, status: v }).then(d => { data.playback = d.playback; if (d.expected) data.expected = d.expected; draw(ctx, data, st, reload); openRow(r); }, A.fail);
        }, { label: 'Status', disabled: !can }), { tag: 'div', help: 'Numbered once a number is typed · Not recorded when it didn’t happen' }) : null,
        r.call_in ? K.field('Note', note, { help: 'For people' }) : null);
      const foot = data.can.schedule ? [A.btn('Open in Schedule', { ghost: true, onClick: () => A.go({ s: 'schedule', v: lc(r.day), id: r.id, at: '' }) })] : null;
      sp.open({ title: r.title, body, foot, onClose: () => { st.sel = ''; A.setParams({ id: '' }); sp.el.querySelectorAll('tr[data-key]').forEach(x => x.setAttribute('aria-selected', 'false')); } });
      if (!K.wide()) window.scrollTo(0, 0);
    }
    if (st.sel) { const r = rows.find(x => x.id === st.sel); if (r) openRow(r); }
  }
})();
