/*
 * Preteens › Children and Communion › Communing (app-committees, Oct 11), moved into the app from the
 * lists area and reworked from its critique. Each list is worked out on the server for its committee
 * and the COA only (module-app-committees.php); children's details go to the Preteens committee and the
 * COA (docs/23), never to the rest of the year.
 *
 *   Children    each preteen: age, the days they're here (when not every day), who may pick them up,
 *               a parent's phone; medical notes and emergency contacts only when there are any. Print
 *               sheet: one line a child with In and Out boxes for each day, the header on every page.
 *               Print medical: notes and contacts, apart. Download: the check-in sheet (never medical).
 *   Communing   how many, on what day, and the households (printed whole: the fold never hides them).
 * "Changed" means the list's own fields changed since it was printed, not any save to a registration.
 */
(function () {
  'use strict';
  const A = window.OGC_APP, h = A.h, K = window.OGC_CK;
  const listsApi = (method, path, body) => A.api(method, '/lists/' + A.params().year + '/' + path, body);
  const asOf = () => (new URLSearchParams(location.search).get('as-of') || '');
  const tag = (t, tone) => h('span', { class: 'cm-chip' + (tone ? ' cm-chip--' + tone : ''), text: t });

  function listScreen(view, title) {
    return function (ctx) {
      const p = ctx.params;
      let D = null, H = null, find = '', alive = true;
      const load = () => listsApi('GET', view + (asOf() ? '?as_of=' + asOf() : '')).then(r => { H = r.head; D = r.list || null; if (alive) draw(); }).catch(err => { if (alive) K.failed(ctx, err); });
      function draw() {
        A.clear(ctx.body);
        ctx.body.classList.add('ap-body--flush');
        if (!D) { ctx.head(title, H && H.cleared ? 'Counts only · Cleared ' + K.md(H.cleared) : '', []); ctx.body.appendChild(A.empty({ title: 'Counts only', line: H && H.cleared ? 'Names cleared ' + K.md(H.cleared) : '', inset: true })); return; }
        // No household registered yet: one empty state, the same on every list (never a zero).
        if (H && !H.held && !H.regs) return K.noRegs(ctx, title, H);
        if (view === 'preteens') children(); else communing();
      }

      function children() {
        if (!D.count) { ctx.head(title, '', []); ctx.body.appendChild(A.empty({ title: 'No preteens registered', inset: true })); return; }
        if (!D.viewer) { ctx.head(title, K.plural(D.count, 'preteen'), []); ctx.body.appendChild(A.empty({ title: K.plural(D.count, 'preteen'), line: 'Children’s details · The Preteens committee and the COA', inset: true })); return; }
        const withDays = D.rows.some(r => r.days), withMed = !D.paper && D.rows.some(r => r.medical), withCon = !D.paper && D.rows.some(r => r.contacts.length);
        const days = (D.days.length ? D.days : ['Friday', 'Saturday', 'Sunday']).map(d => String(d).slice(0, 3));
        ctx.head(title, K.facts([K.plural(D.count, 'preteen'), D.paper ? 'Medical notes and contacts on paper' : '', D.printed && D.changed ? K.plural(D.changed, 'change') + ' since printed' : '']),
          [A.btn('Print sheet', { primary: true, icon: 'file', title: 'One line a child, In and Out for each day', onClick: () => printSheet(days, withDays) }),
            K.more('More', [withMed || withCon ? { label: 'Print medical', run: printMedical } : null, { label: 'Download', run: () => K.fetchFile('ogc/v1/lists/' + p.year + '/preteens?format=csv' + (p.as ? '&as=' + encodeURIComponent(p.as) : ''), 'preteens-checkin-' + p.year + '.csv').catch(() => A.toast('Not downloaded')) }], { ghost: true })]);
        const tbody = h('tbody');
        const render = () => {
          const f = find.trim().toLowerCase();
          const rows = D.rows.filter(r => !f || (r.name + ' ' + r.household + ' ' + r.pickup).toLowerCase().indexOf(f) > -1);
          A.clear(tbody).append(...(rows.length ? rows.map(r => h('tr', null,
            h('td', null, h('span', { class: 'cm-title', text: r.name }), r.age ? h('span', { class: 'cm-sub2', text: 'Age ' + r.age }) : null, r.new ? tag('New', 'tan') : r.changed ? tag('Changed', 'blue') : null),
            withDays ? h('td', { text: r.days || 'All' }) : null,
            h('td', { text: r.pickup || '' }),
            h('td', null, K.phone(r.phone)),
            withMed ? h('td', { text: r.medical || '' }) : null,
            withCon ? h('td', null, r.contacts.map(c => h('div', null, c.name, c.rel ? ' · ' + c.rel : '', ' ', K.phone(c.phone)))) : null,
            h('td', { class: 'is-wide is-muted', text: r.household }))) : [h('tr', null, h('td', { colspan: '7', class: 'is-muted', text: 'No matches' }))]));
        };
        // Search only for a list long enough to need it (polish: a full-width box above one child).
        if (D.rows.length > 10) ctx.body.appendChild(h('div', { class: 'cm-toolbar' }, K.find({ placeholder: 'Search', onInput: v => { find = v; render(); } })));
        if (D.before) ctx.body.appendChild(h('p', { class: 'ap-quiet cm-pad', style: { marginTop: '12px' }, text: K.plural(D.before, 'household') + ' registered before the details were asked' }));
        ctx.body.appendChild(h('div', { class: 'cm-scroll' }, h('table', { class: 'cm-table' }, h('thead', null, h('tr', null, h('th', { text: 'Preteen' }), withDays ? h('th', { text: 'Days' }) : null, h('th', { text: 'May pick up' }), h('th', { text: 'Parent phone' }), withMed ? h('th', { text: 'Medical notes' }) : null, withCon ? h('th', { text: 'Emergency contacts' }) : null, h('th', { class: 'is-wide', text: 'Household' }))), tbody)));
        render();
      }
      function printSheet(days, withDays) {
        listsApi('POST', 'printed', { view: 'preteens' }).then(load).catch(() => {});
        K.print({ title: 'Preteens · Check-in', sub: K.plural(D.count, 'preteen'), who: 'Preteens only', landscape: true, build: () => h('table', null,
          h('thead', null, h('tr', null, h('th', { text: 'Preteen' }), h('th', { text: 'Age' }), withDays ? h('th', { text: 'Days' }) : null, h('th', { text: 'May pick up' }), h('th', { text: 'Parent phone' }), days.map(d => [h('th', { text: d + ' in' }), h('th', { text: d + ' out' })]))),
          h('tbody', null, D.rows.map(r => h('tr', { class: 'cm-tall' }, h('td', { text: r.name }), h('td', { text: r.age }), withDays ? h('td', { text: r.days || 'All' }) : null, h('td', { text: r.pickup }), h('td', { text: r.phone }), days.map(() => [h('td', { class: 'cm-tick' }), h('td', { class: 'cm-tick' })]))))) });
      }
      function printMedical() {
        listsApi('POST', 'printed', { view: 'medical' }).catch(() => {});
        K.print({ title: 'Preteens · Medical notes and contacts', who: 'Preteens only · Keep private', build: () => h('table', null,
          h('thead', null, h('tr', null, ['Preteen', 'Age', 'Medical notes', 'Emergency contacts', 'Parent phone'].map(c => h('th', { text: c })))),
          h('tbody', null, D.rows.filter(r => r.medical || r.contacts.length).map(r => h('tr', null, h('td', { text: r.name }), h('td', { text: r.age }), h('td', { text: r.medical }), h('td', null, r.contacts.map(c => h('div', { text: c.name + (c.rel ? ' · ' + c.rel : '') + (c.phone ? ' · ' + c.phone : '') }))), h('td', { text: r.phone }))))) });
      }

      function communing() {
        if (!D.total) { ctx.head(title, '', []); ctx.body.appendChild(A.empty({ title: 'No one communing yet', line: H.regs ? 'From ' + K.plural(H.regs, 'household') : '', inset: true })); return; }
        ctx.head(title, K.facts([D.total + ' communing', K.plural(D.households.length, 'household'), D.date ? K.day(D.date) : '', D.away ? D.away + ' not here that day' : '', D.printed && D.changed ? K.plural(D.changed, 'change') + ' since printed' : '']),
          [A.btn('Print', { icon: 'file', onClick: printCommunion }), A.btn('Download', { icon: 'download', onClick: () => K.fetchFile('ogc/v1/lists/' + p.year + '/communion?format=csv' + (p.as ? '&as=' + encodeURIComponent(p.as) : ''), 'communion-' + p.year + '.csv').catch(() => A.toast('Not downloaded')) })]);
        ctx.body.appendChild(h('div', { class: 'cm-section' }, h('div', { class: 'cm-stats' }, h('div', { class: 'cm-stat' }, h('b', { text: String(D.total) }), h('span', { text: 'Communing' + (D.date ? ' · ' + K.day(D.date) : '') })))));
        const tbody = h('tbody');
        const render = () => {
          const f = find.trim().toLowerCase(), rows = D.households.filter(r => !f || (r.label + ' ' + r.rid).toLowerCase().indexOf(f) > -1);
          A.clear(tbody).append(...rows.map(r => h('tr', null, h('td', null, h('span', { class: 'cm-title', text: r.label }), r.new ? tag('New', 'tan') : r.changed ? tag('Changed', 'blue') : null), h('td', { class: 'is-muted', text: r.rid }), h('td', { class: 'is-num', text: String(r.n) }))));
        };
        if (D.households.length > 10) ctx.body.appendChild(h('div', { class: 'cm-toolbar' }, K.find({ placeholder: 'Search', onInput: v => { find = v; render(); } })));
        ctx.body.appendChild(h('div', { class: 'cm-scroll' }, h('table', { class: 'cm-table' }, h('thead', null, h('tr', null, h('th', { text: 'Household' }), h('th', { text: 'Registration' }), h('th', { class: 'is-num', text: 'Communing' }))), tbody)));
        render();
      }
      function printCommunion() {
        listsApi('POST', 'printed', { view: 'communion' }).then(load).catch(() => {});
        K.print({ title: 'Communion', sub: D.total + ' communing' + (D.date ? ' · ' + K.day(D.date) : ''), who: 'Communion', build: () => h('table', null,
          h('thead', null, h('tr', null, h('th', { text: 'Household' }), h('th', { text: 'Registration' }), h('th', { class: 'is-num', text: 'Communing' }))),
          h('tbody', null, D.households.map(r => h('tr', null, h('td', { text: r.label }), h('td', { text: r.rid }), h('td', { class: 'is-num', text: String(r.n) }))))) });
      }

      K.loading(ctx);
      load();
      return () => { alive = false; ctx.body.classList.remove('ap-body--flush'); };
    };
  }

  A.screen({ id: 'preteens-list', title: 'Children', icon: 'members', section: 'own', who: ['preteens'], render: listScreen('preteens', 'Children') });
  A.screen({ id: 'communion-list', title: 'Communing', icon: 'report', section: 'own', who: ['communion'], render: listScreen('communion', 'Communing') });
})();
