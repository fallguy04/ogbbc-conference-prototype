/*
 * The committees' lists (lists area; app-committees Oct 11, filled out Oct 13 night; Round 6, Oct 17:
 * "the committees' own lists", docs/27-back-end-map/area-committee-lists §4–6, §8, §9). Each list is
 * worked out on the server for its committee and the COA only (module-lists*.php): the browser gets that
 * list and nothing else. Every list made from records (README rule 5): "As of", Print, Excel (the same
 * columns every year), a Since printed view, rows that open a read-only panel beside the list, and a
 * title fact from the same function as its committee's Work row (module-lists-facts.php: one count).
 *
 *   Children        Preteens: each preteen, by day (?v=<date>), who may pick them up, a parent's phone;
 *                   medical notes and emergency contacts only when there are any, and only to Preteens
 *                   and the COA (withheld on the server for anyone else). A child opens its panel.
 *   Communing       Communion: the one number, on what day, and who; a household opens its panel.
 *   Counts by day   Nursery: under 3 and 3 to 5 each day there's a service, households with one under 3,
 *                   the day's services. Counts only: a day opens its counts and services, never names.
 *   Halls           Young Folks: the Young Folks in the halls, by hall (?v=men|women|none); a Young Folk
 *                   opens their panel (nights, room once Lodging has published, approval, rooming note).
 *   Services        Ushers: the week's services (Worship, Council, Communion; for Everyone or Conference)
 *                   as the public schedule has them, by day. Read only.
 * Since printed: a row not on any kept print is New; one whose newest print says otherwise is Changed.
 * Only a Print moves it (never an Excel download, never a preview, never while seeing as).
 */
(function () {
  'use strict';
  const A = window.OGC_APP, h = A.h, K = window.OGC_CK, W = window.OGC_WP || {};
  const listsApi = (method, path, body) => A.api(method, '/lists/' + A.params().year + '/' + path, body);
  const asOf = () => (new URLSearchParams(location.search).get('as-of') || '');
  const tag = (t, tone, title) => h('span', { class: 'cm-chip' + (tone ? ' cm-chip--' + tone : ''), title: title || null, text: t });
  const short = d => String(d || '').slice(0, 3);
  const WD = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  const weekday = iso => WD[new Date(String(iso).slice(0, 10) + 'T12:00:00Z').getUTCDay()] || '';
  // The Excel file of a list (?format=xlsx), named the same every year but the year.
  const excel = (p, view, name) => K.excel('lists/' + p.year + '/' + view, p.year + ' ' + name, p.as);
  /*
   * A print is kept as the list going out ("since printed"): which rows went on it and what sheet. Not
   * while previewing a date (a look), except on the shared prototype, whose walk-through saves; never
   * while seeing as (the button is greyed, and the server refuses).
   */
  const markPrinted = (view, label, keys, days) => {
    if (A.readonly || (asOf() && !W.prototype)) return Promise.resolve();
    return listsApi('POST', 'printed' + (asOf() ? '?as_of=' + encodeURIComponent(asOf()) : ''), { view, label, keys, days: days || [] });
  };
  const NOT_ASKED = 'From the Lodging Form, which doesn’t ask who may pick up · Confirm with the parent at check-in';
  const sinceTag = (s, short2) => s === 'new' ? tag(short2 ? 'New' : 'New since printed', 'tan') : s === 'changed' ? tag(short2 ? 'Changed' : 'Changed since printed', 'blue') : null;
  // The title row's fact, from the server's head; its "N since printed" part a door to the view that holds
  // exactly those rows (README rule 10).
  function factNode(fact, re, to) {
    if (!fact || !fact.head) return '';
    const parts = fact.head.split(' · ');
    const out = [];
    parts.forEach((t, i) => {
      if (i) out.push(' · ');
      if (re.test(t) && fact.n) { const a = A.link(to, t, 'ap-head__factlink'); a.setAttribute('data-n', String(fact.n)); out.push(a); }
      else out.push(t);
    });
    return h('span', null, out);
  }
  // A fact line in a panel.
  const fl = (dt, dd) => dd == null || dd === '' || (Array.isArray(dd) && !dd.length) ? null : [h('dt', { text: dt }), h('dd', null, dd)];
  const withheld = who => h('span', { class: 'ap-quiet', title: 'Only ' + who + ' see this', text: 'Withheld · ' + who });
  // Previous · Next through the rows as drawn.
  const navOf = (list, i, open) => ({ prev: i > 0 ? () => open(list[i - 1]) : null, next: i < list.length - 1 ? () => open(list[i + 1]) : null });
  if (A.addIcons) A.addIcons({ pram: 'M3 8a5 5 0 0 1 5-5v5M3 8h9l-1.5 3h-6ZM12 8l1.2-3h1.3M6.2 13a1.2 1.2 0 1 1-2.4 0 1.2 1.2 0 0 1 2.4 0ZM11.7 13a1.2 1.2 0 1 1-2.4 0 1.2 1.2 0 0 1 2.4 0Z' });

  function listScreen(view, title) {
    return function (ctx) {
      const p = ctx.params;
      let D = null, H = null, find = '', alive = true, sp = null;
      const load = () => listsApi('GET', view + (asOf() ? '?as_of=' + asOf() : '')).then(r => { H = r.head; D = r.list || null; if (alive) draw(); }).catch(err => { if (alive) K.failed(ctx, err); });
      const reload = () => load();
      function base() {
        if (!sp) { A.clear(ctx.body); sp = ctx.split(); }
        A.clear(sp.main);
        return sp.main;
      }
      function draw() {
        const main = base();
        if (!D) { ctx.head(title, H && H.cleared ? 'Counts only · Cleared ' + K.md(H.cleared) : '', []); main.appendChild(A.empty({ title: 'Counts only', line: H && H.cleared ? 'Names cleared ' + K.md(H.cleared) : '', inset: true })); sp.close(true); return; }
        // No household registered yet: one empty state, the same on every list (never a zero).
        if (H && !H.held && !H.regs) { const opens = H.opens && H.today && H.opens > H.today ? 'Opens ' + K.md(H.opens) : 'The lists come from the registrations'; ctx.head(title, '', []); main.appendChild(A.empty({ title: 'No registrations yet', line: opens, inset: true })); sp.close(true); return; }
        ({ preteens: children, communion: communing, nursery: nursery, halls: halls })[view](main);
      }
      // A row that opens its panel: the whole row, and its name as a button for the keyboard.
      function rowOpen(tr, key, open) {
        tr.classList.add('cm-tap');
        if (p.id === key) tr.classList.add('is-open');
        tr.addEventListener('click', e => { if (e.target.closest('a, input')) return; open(); });
      }
      const nameBtn = (text, open) => h('button', { type: 'button', class: 'cm-rowbtn', on: { click: e => { e.stopPropagation(); open(); } } }, h('span', { class: 'cm-title', text }));
      const setOpen = key => { p.id = key; A.setParams({ id: key }); sp.main.querySelectorAll('tr.cm-tap').forEach(t => t.classList.toggle('is-open', t.dataset.key === key)); };
      const closed = () => { p.id = ''; A.setParams({ id: '' }); sp.main.querySelectorAll('tr.is-open').forEach(t => t.classList.remove('is-open')); };
      const sinceEmpty = (printed, back) => A.empty({ title: 'Nothing since printed', line: printed ? 'Printed ' + K.md(printed.at) + (printed.by ? ' · ' + printed.by : '') : '', inset: true, action: A.link(back, 'All', 'ap-btn') });

      /* ------------------------------------------------------------ Children (Preteens) */

      function children(main) {
        if (!D.count) { ctx.head(title, '', []); main.appendChild(A.empty({ title: 'No preteens registered', line: 'From ' + K.plural(H.regs, 'household'), inset: true })); sp.close(true); return; }
        const prog = D.program || [];
        const since = p.v === 'since';
        const day = prog.find(x => x.date === p.v) || null;
        let rows = since ? D.rows.filter(r => r.since) : day ? D.rows.filter(r => (r.on || []).indexOf(day.date) > -1) : D.rows;
        const withDays = !day && D.rows.some(r => r.days), withMed = !D.paper && D.viewer && rows.some(r => r.medical), withCon = !D.paper && D.viewer && rows.some(r => r.contacts.length);
        const label = day ? K.day(day.date) + ' sheet' : 'the full sheet';
        const ro = A.readonly ? 'Read only while seeing as' : '';
        const more = [day ? { label: 'Print every day', disabled: !!ro, hint: ro, run: () => printSheet(prog) } : null, D.medical ? { label: 'Print medical', disabled: !!ro, hint: ro, run: printMedical } : null].filter(Boolean);
        ctx.head(title, factNode(D.fact, /since printed$/, { v: 'since' }), [
          K.more('Export', [{ label: 'Excel', hint: ro, disabled: !!ro, run: () => excel(p, 'preteens', 'Preteens check-in') }], { ghost: true }),
          more.length ? K.more('More', more, { ghost: true }) : null,
          A.btn(day ? 'Print ' + short(day.name) : 'Print sheet', { primary: true, write: true, icon: 'file', title: day ? 'One line a child, In and Out' : 'One line a child, In and Out for each day', onClick: () => day ? printDay(day, rows, label) : printSheet(prog) })
        ].filter(Boolean));
        // The program's days, each with how many are here (?v=<date>); "All" is every child; Since printed
        // after a first print, while it holds any.
        const chips = [{ id: '', label: 'All', n: D.count }].concat(prog.length > 1 ? prog.map(x => ({ id: x.date, label: K.day(x.date), n: x.n })) : []);
        if (D.since || since) chips.push({ id: 'since', label: 'Since printed', n: D.since });
        const tools = h('div', { class: 'cm-toolbar' });
        if (chips.length > 1) tools.appendChild(A.views(chips, since ? 'since' : day ? day.date : '', id => A.go({ v: id })));
        if (D.rows.length > 10) tools.appendChild(K.find({ placeholder: 'Search', value: find, onInput: v => { find = v; render(); } }));
        if (tools.childNodes.length) main.appendChild(tools);
        if (D.rows[0] && D.rows[0].withheld) main.appendChild(h('p', { class: 'ap-quiet cm-pad', style: { marginTop: '12px' }, text: 'Pick-up, phones, medical notes and contacts · Withheld · Preteens and the COA' }));
        if (D.before) main.appendChild(h('p', { class: 'ap-quiet cm-pad', style: { marginTop: '12px' }, text: K.plural(D.before, 'household') + ' registered before the details were asked' }));
        if (since && !rows.length) { main.appendChild(sinceEmpty(D.print, { v: '' })); sp.close(true); return; }
        const tbody = h('tbody');
        let shown = rows;
        const open = r => {
          setOpen(r.key);
          const i = shown.indexOf(r);
          const rec = (dt, v) => r.withheld ? fl(dt, withheld(r.withheld)) : fl(dt, v);
          sp.open({
            title: r.name, line: K.facts([r.age ? 'Age ' + r.age : '', r.household, r.rid]),
            tags: [sinceTag(r.since), r.unasked && !r.withheld ? tag('Not asked', 'warn', NOT_ASKED) : null].filter(Boolean),
            nav: navOf(shown, i, open),
            body: [
              h('dl', { class: 'ap-facts' },
                fl('Days here', prog.length ? h('span', { class: 'cm-daypills' }, prog.map(x => h('span', { class: 'cm-daypill' + ((r.on || []).indexOf(x.date) > -1 ? ' is-on' : ''), text: short(x.name) }))) : r.daysAll),
                rec('May pick up', r.unasked ? 'Not asked' : r.pickup || (D.paper ? 'On paper at check-in' : '')),
                r.unasked && !r.withheld ? fl('Adults registered', h('span', { title: 'Not permission to pick up: the form didn’t ask', text: r.adults })) : null,
                rec('Parent phone', K.phone(r.phone)),
                D.paper ? fl('Medical', 'On paper at check-in') : rec('Medical notes', r.medical),
                D.paper ? null : rec('Emergency contacts', r.contacts && r.contacts.length ? r.contacts.map(c => h('div', null, c.name, c.rel ? ' · ' + c.rel : '', ' ', K.phone(c.phone))) : '')),
              (r.also || []).length ? h('section', { class: 'ap-linked' }, h('h3', { class: 'ap-rec__h', text: 'Also from this household' }), h('ul', null, r.also.map(x => {
                const o = D.rows.find(y => y.key === x.key);
                return h('li', null, h('a', { class: 'ap-linked__a', href: A.href({ id: x.key }), on: { click: e => { if (e.metaKey || e.ctrlKey) return; e.preventDefault(); if (o) open(o); } } }, h('span', { text: x.name }), A.icon('chev', 14)));
              }))) : null,
              A.linked(r.linked, { from: 'preteens-list:' + r.key, name: r.name }),
              A.history(r.hist)
            ],
            onClose: closed, focus: 'head'
          });
        };
        const render = () => {
          const f = find.trim().toLowerCase();
          shown = rows.filter(r => !f || (r.name + ' ' + r.household + ' ' + r.pickup).toLowerCase().indexOf(f) > -1);
          A.clear(tbody).append(...(shown.length ? shown.map(r => {
            const tr = h('tr', { 'data-key': r.key },
              h('td', null, nameBtn(r.name, () => open(r)), r.age ? h('span', { class: 'cm-sub2', text: 'Age ' + r.age }) : null, sinceTag(r.since, true)),
              withDays ? h('td', { text: r.days || 'All' }) : null,
              h('td', null, r.withheld ? withheld(r.withheld) : r.unasked ? tag('Not asked', 'warn', NOT_ASKED) : (r.pickup || '')),
              h('td', null, r.withheld ? null : K.phone(r.phone)),
              withMed ? h('td', { text: r.medical || '' }) : null,
              withCon ? h('td', null, r.contacts.map(c => h('div', null, c.name, c.rel ? ' · ' + c.rel : '', ' ', K.phone(c.phone)))) : null,
              h('td', { class: 'is-wide is-muted', text: r.household }));
            rowOpen(tr, r.key, () => open(r));
            return tr;
          }) : [h('tr', null, h('td', { colspan: '7', class: 'is-muted', text: 'No matches' }))]));
        };
        main.appendChild(h('div', { class: 'cm-scroll' }, h('table', { class: 'cm-table' }, h('thead', null, h('tr', null, h('th', { text: 'Preteen' }), withDays ? h('th', { text: 'Days' }) : null, h('th', { text: 'May pick up' }), h('th', { text: 'Parent phone' }), withMed ? h('th', { text: 'Medical notes' }) : null, withCon ? h('th', { text: 'Emergency contacts' }) : null, h('th', { class: 'is-wide', text: 'Household' }))), tbody)));
        main.appendChild(h('p', { class: 'ap-help cm-pad cm-foot', text: K.facts([K.plural(D.count, 'preteen') + ' from ' + K.plural(H.regs, 'household'), 'Ages as registered', D.print ? 'Printed ' + K.md(D.print.at) + (D.print.by ? ' · ' + D.print.by : '') : '', 'Medical notes · Preteens and the COA only']) }));
        if (D.rows.some(r => r.unasked)) main.appendChild(h('p', { class: 'ap-help cm-pad cm-foot cm-foot--2', text: 'Not asked · ' + NOT_ASKED }));
        render();
        const cur = p.id && D.rows.find(r => r.key === p.id);
        if (cur) { if (shown.indexOf(cur) < 0) shown = D.rows; open(cur); } else sp.close(true);
      }
      // One day's sheet: a line a child, In and Out (portrait; the header on every page).
      function printDay(day, rows, label) {
        markPrinted('preteens', label, rows.map(r => r.key), [day.date]).then(reload).catch(() => {});
        K.print({ tz: H && H.tz, title: 'Preteens · ' + K.day(day.date), sub: K.facts([K.plural(rows.length, 'preteen'), H.as_of ? 'As of ' + H.as_of : '']), who: 'Preteens only', build: () => h('div', null, h('table', { class: 'cm-ptable' },
          h('thead', null, h('tr', null, ['Preteen', 'Age', 'May pick up', 'Parent phone', 'In', 'Out'].map((c, i) => h('th', { class: i > 3 ? 'cm-tickh' : '', text: c })))),
          h('tbody', null, rows.map(r => h('tr', { class: 'cm-mid' }, h('td', { text: r.name }), h('td', { text: r.age }), h('td', null, r.unasked ? h('b', { text: 'Not asked' }) : r.pickup), h('td', { text: r.phone }), h('td', { class: 'cm-tick' }), h('td', { class: 'cm-tick' }))))),
          notAskedKey(rows)) });
      }
      function printSheet(prog) {
        const days = prog.length ? prog : (D.days || []).map(n => ({ name: n }));
        const withDays = D.rows.some(r => r.days);
        markPrinted('preteens', 'the full sheet', D.rows.map(r => r.key), prog.map(x => x.date)).then(reload).catch(() => {});
        K.print({ tz: H && H.tz, title: 'Preteens · Check-in', sub: K.facts([K.plural(D.count, 'preteen'), H.as_of ? 'As of ' + H.as_of : '']), who: 'Preteens only', landscape: true, build: () => h('div', null, h('table', null,
          h('thead', null, h('tr', null, h('th', { text: 'Preteen' }), h('th', { text: 'Age' }), withDays ? h('th', { text: 'Days' }) : null, h('th', { text: 'May pick up' }), h('th', { text: 'Parent phone' }), days.map(d => [h('th', { text: short(d.name) + ' in' }), h('th', { text: short(d.name) + ' out' })]))),
          h('tbody', null, D.rows.map(r => h('tr', { class: 'cm-tall' }, h('td', { text: r.name }), h('td', { text: r.age }), withDays ? h('td', { text: r.days || 'All' }) : null, h('td', null, r.unasked ? h('b', { text: 'Not asked' }) : r.pickup), h('td', { text: r.phone }),
            days.map(d => d.date && (r.on || []).indexOf(d.date) < 0 ? [h('td', { class: 'cm-off', text: '–' }), h('td', { class: 'cm-off', text: '–' })] : [h('td', { class: 'cm-tick' }), h('td', { class: 'cm-tick' })]))))), notAskedKey(D.rows)) });
      }
      const notAskedKey = list => list.some(r => r.unasked) ? h('p', { class: 'cm-key', text: 'Not asked · ' + NOT_ASKED }) : null;
      function printMedical() {
        markPrinted('medical', 'Medical notes', []).catch(() => {});
        const list = D.rows.filter(r => r.medical || r.contacts.length);
        K.print({ tz: H && H.tz, title: 'Preteens · Medical notes and contacts', sub: K.facts([K.plural(list.length, 'preteen'), H.as_of ? 'As of ' + H.as_of : '']), who: 'Preteens only · Keep private', build: () => list.length ? h('table', null,
          h('thead', null, h('tr', null, ['Preteen', 'Age', 'Medical notes', 'Emergency contacts', 'Parent phone'].map(c => h('th', { text: c })))),
          h('tbody', null, list.map(r => h('tr', null, h('td', { text: r.name }), h('td', { text: r.age }), h('td', { text: r.medical }), h('td', null, r.contacts.map(c => h('div', { text: c.name + (c.rel ? ' · ' + c.rel : '') + (c.phone ? ' · ' + c.phone : '') }))), h('td', { text: r.phone })))))
          : h('p', { text: 'No medical notes or emergency contacts registered' }) });
      }

      /* ------------------------------------------------------------ Communing (Communion) */

      function communing(main) {
        if (!D.total) { ctx.head(title, '', []); main.appendChild(A.empty({ title: 'No one communing yet', line: K.facts([H.regs ? 'From ' + K.plural(H.regs, 'household') : '', H.from_form ? H.from_form + ' from the Lodging Form, which doesn’t ask' : '']), inset: true })); sp.close(true); return; }
        const since = p.v === 'since';
        const rows = since ? D.households.filter(r => r.since) : D.households;
        ctx.head(title, factNode(D.fact, /since printed$/, { v: 'since' }), [
          K.more('Export', [{ label: 'Excel', hint: A.readonly ? 'Read only while seeing as' : '', disabled: A.readonly, run: () => excel(p, 'communion', 'Communing') }], { ghost: true }),
          A.btn('Print', { primary: true, write: true, icon: 'file', onClick: printCommunion })]);
        main.appendChild(h('div', { class: 'cm-section' }, h('div', { class: 'cm-stats' },
          h('div', { class: 'cm-stat' }, h('b', { text: String(D.total) }), h('span', { text: 'Communing' + (D.date ? ' · ' + K.day(D.date) : '') })),
          h('div', { class: 'cm-stat' }, h('b', { text: String(D.households.length) }), h('span', { text: 'Households' })),
          D.away ? h('div', { class: 'cm-stat', title: 'Registered as communing, but not here that day: not counted' }, h('b', { text: String(D.away) }), h('span', { text: 'Not here that day' })) : null,
          // Households the Lodging Form never asked: beside the number, so it isn't read as the whole count.
          H.from_form ? h('div', { class: 'cm-stat cm-stat--warn', title: 'From the Lodging Form, which doesn’t ask about communion · Not in the number' }, h('b', { text: String(H.from_form) }), h('span', { text: 'Households not asked' })) : null)));
        const tools = h('div', { class: 'cm-toolbar' });
        if (D.since || since) tools.appendChild(A.views([{ id: '', label: 'All', n: D.households.length }, { id: 'since', label: 'Since printed', n: D.since }], since ? 'since' : '', id => A.go({ v: id })));
        if (D.households.length > 10) tools.appendChild(K.find({ placeholder: 'Search', value: find, onInput: v => { find = v; render(); } }));
        if (tools.childNodes.length) main.appendChild(tools);
        if (since && !rows.length) { main.appendChild(sinceEmpty(D.print, { v: '' })); sp.close(true); return; }
        const tbody = h('tbody');
        let shown = rows;
        const open = r => {
          setOpen(r.key);
          sp.open({
            title: r.label, line: r.rid, tags: [sinceTag(r.since)].filter(Boolean), nav: navOf(shown, shown.indexOf(r), open),
            body: [h('dl', { class: 'ap-facts' }, fl('Communing', String(r.n)), fl('Names', r.names.join(', ')), fl('Not here that day', (r.away || []).join(', ')), fl('Communion', D.date ? K.day(D.date) : '')),
              A.linked(r.linked, { from: 'communion-list:' + r.key, name: r.label }), A.history(r.hist)],
            onClose: closed, focus: 'head'
          });
        };
        const render = () => {
          const f = find.trim().toLowerCase();
          shown = rows.filter(r => !f || (r.label + ' ' + r.rid + ' ' + (r.names || []).join(' ')).toLowerCase().indexOf(f) > -1);
          A.clear(tbody).append(...(shown.length ? shown.map(r => {
            const tr = h('tr', { 'data-key': r.key }, h('td', null, nameBtn(r.label, () => open(r)), sinceTag(r.since, true)), h('td', { text: (r.names || []).join(', ') }), h('td', { class: 'is-wide is-muted', text: r.rid }), h('td', { class: 'is-num', text: String(r.n) }));
            rowOpen(tr, r.key, () => open(r));
            return tr;
          }) : [h('tr', null, h('td', { colspan: '4', class: 'is-muted', text: 'No matches' }))]));
        };
        main.appendChild(h('div', { class: 'cm-scroll' }, h('table', { class: 'cm-table' }, h('thead', null, h('tr', null, h('th', { text: 'Household' }), h('th', { text: 'Names' }), h('th', { class: 'is-wide', text: 'Registration' }), h('th', { class: 'is-num', text: 'Communing' }))), tbody)));
        main.appendChild(h('p', { class: 'ap-help cm-pad cm-foot', text: K.facts(['From ' + K.plural(H.regs, 'household'), 'Only those here on communion day', D.print ? 'Printed ' + K.md(D.print.at) + (D.print.by ? ' · ' + D.print.by : '') : '', H.from_form ? H.from_form + ' from the Lodging Form, which doesn’t ask' : '']) }));
        render();
        const cur = p.id && D.households.find(r => r.key === p.id);
        if (cur) { if (shown.indexOf(cur) < 0) shown = D.households; open(cur); } else sp.close(true);
      }
      function printCommunion() {
        markPrinted('communion', 'the communing list', D.households.map(r => r.key)).then(reload).catch(() => {});
        K.print({ tz: H && H.tz, title: 'Communion', sub: K.facts([D.total + ' communing', D.date ? K.day(D.date) : '', K.plural(D.households.length, 'household'), H.from_form ? K.plural(H.from_form, 'household') + ' not asked (Lodging Form)' : '', H.as_of ? 'As of ' + H.as_of : '']), who: 'Communion', build: () => h('table', null,
          h('thead', null, h('tr', null, h('th', { text: 'Household' }), h('th', { text: 'Names' }), h('th', { text: 'Registration' }), h('th', { class: 'is-num', text: 'Communing' }))),
          h('tbody', null, D.households.map(r => h('tr', null, h('td', { text: r.label }), h('td', { text: (r.names || []).join(', ') }), h('td', { text: r.rid }), h('td', { class: 'is-num', text: String(r.n) })))),
          h('tfoot', null, h('tr', null, h('td', { colspan: '3', text: 'Total' }), h('td', { class: 'is-num', text: String(D.total) })))) });
      }

      /* ------------------------------------------------------------ Counts by day (Nursery) */

      function nursery(main) {
        if (!D.under3 && !D.small) { ctx.head(title, '', []); main.appendChild(A.empty({ title: 'No children under 6 registered', line: 'From ' + K.plural(H.regs, 'household'), inset: true })); sp.close(true); return; }
        const since = p.v === 'since';
        const days = since ? D.days.filter(d => d.since) : D.days;
        ctx.head(title, factNode(D.fact, /changed since printed$/, { v: 'since' }), [
          K.more('Export', [{ label: 'Excel', run: () => excel(p, 'nursery', 'Nursery counts by day') }], { ghost: true }),
          A.btn('Print', { primary: true, icon: 'file', onClick: printNursery })]);
        main.appendChild(h('div', { class: 'cm-section' }, h('div', { class: 'cm-stats' },
          D.under3 ? h('div', { class: 'cm-stat' }, h('b', { text: String(D.under3) }), h('span', { text: 'Under 3' })) : null,
          D.small ? h('div', { class: 'cm-stat' }, h('b', { text: String(D.small) }), h('span', { text: 'Ages 3–5' })) : null,
          D.households ? h('div', { class: 'cm-stat' }, h('b', { text: String(D.households) }), h('span', { text: D.households === 1 ? 'Household with one under 3' : 'Households with one under 3' })) : null)));
        if (D.since || since) main.appendChild(h('div', { class: 'cm-toolbar' }, A.views([{ id: '', label: 'All', n: D.days.length }, { id: 'since', label: 'Changed since printed', n: D.since }], since ? 'since' : '', id => A.go({ v: id }))));
        if (since && !days.length) { main.appendChild(sinceEmpty(D.print, { v: '' })); sp.close(true); return; }
        const n = v => v ? String(v) : '–';
        const open = d => {
          setOpen(d.key);
          sp.open({
            title: K.day(d.date), line: d.services.length ? K.plural(d.services.length, 'service') + ' · ' + d.span : 'No services on the schedule', tags: [d.since ? tag('Changed since printed', 'blue', d.was) : null].filter(Boolean),
            nav: navOf(days, days.indexOf(d), open),
            body: [h('dl', { class: 'ap-facts' }, fl('Under 3', n(d.under3)), fl('3–5', n(d.small)), fl('Households', d.households ? K.plural(d.households, 'household') + ' with one under 3' : '–'), d.was ? fl('Printed', d.was) : null),
              d.services.length ? h('section', null, h('h3', { class: 'ap-rec__h', text: 'Services' }), h('ul', { class: 'cm-plain cm-svc' }, d.services.map(s => h('li', null, h('b', { text: s.when || 'No time' }), ' · ' + s.title, s.place ? h('small', { class: 'cm-sub2', text: s.place }) : null)))) : null,
              h('p', { class: 'ap-help', text: 'Counts only · No names' })],
            onClose: closed, focus: 'head'
          });
        };
        const tbody = h('tbody', null, days.map(d => {
          const tr = h('tr', { 'data-key': d.key }, h('td', null, nameBtn(K.day(d.date), () => open(d)), d.since ? [' ', tag('Changed', 'blue', d.was)] : null),
            h('td', { class: 'is-num is-total', text: n(d.under3) }), h('td', { class: 'is-num', text: n(d.small) }), h('td', { class: 'is-num', text: n(d.households) }),
            h('td', { class: 'cm-nowrap', text: d.services.length ? d.services.length + ' · ' + d.span : '–' }));
          rowOpen(tr, d.key, () => open(d));
          return tr;
        }));
        main.appendChild(h('div', { class: 'cm-scroll' }, h('table', { class: 'cm-table cm-nursery', 'aria-label': 'Counts by day' },
          h('thead', null, h('tr', null, h('th', { text: 'Day' }), h('th', { class: 'is-num', text: 'Under 3' }), h('th', { class: 'is-num', text: '3–5' }), h('th', { class: 'is-num', text: 'Households' }), h('th', { text: 'Services' }))), tbody)));
        main.appendChild(h('p', { class: 'ap-help cm-pad cm-foot', text: K.facts(['From ' + K.plural(H.regs, 'household'), D.service_days ? 'Days with a service on the schedule' : 'Every day · No services on the schedule yet', 'Under 3 by the registration’s age group', '3–5 by the age typed', D.print ? 'Printed ' + K.md(D.print.at) : '', 'Counts only']) }));
        const cur = p.id && D.days.find(d => d.key === p.id);
        if (cur) open(cur); else sp.close(true);
      }
      function printNursery() {
        markPrinted('nursery', 'Counts by day', D.days.map(d => d.key)).then(reload).catch(() => {});
        const n = v => v ? String(v) : '–';
        K.print({ tz: H && H.tz, title: 'Nursery · Counts by day', sub: K.facts([D.fact ? D.fact.line : '', H.as_of ? 'As of ' + H.as_of : '']), who: 'Nursery', build: () => h('div', null, h('table', null,
          h('thead', null, h('tr', null, ['Day', 'Under 3', '3–5', 'Households', 'Services'].map((c, i) => h('th', { class: i && i < 4 ? 'is-num' : '', text: c })))),
          h('tbody', null, D.days.map(d => h('tr', null, h('td', { text: K.day(d.date) }), h('td', { class: 'is-num', text: n(d.under3) }), h('td', { class: 'is-num', text: n(d.small) }), h('td', { class: 'is-num', text: n(d.households) }), h('td', { text: d.services.length ? d.services.length + ' · ' + d.span : '–' }))))),
          h('p', { class: 'cm-key', text: K.facts(['From ' + K.plural(H.regs, 'household'), D.service_days ? 'Days with a service on the schedule' : '', 'Under 3 by the registration’s age group', '3–5 by the age typed']) })) });
      }

      /* ------------------------------------------------------------ Halls (Young Folks) */

      function halls(main) {
        if (!D.total) { ctx.head(title, '', []); main.appendChild(A.empty({ title: 'No Young Folks in the halls', line: D.family ? D.family + ' with their family' : 'From ' + K.plural(H.regs, 'household'), inset: true })); sp.close(true); return; }
        const since = p.v === 'since';
        const hall = since ? null : D.halls.find(x => x.key === p.v) || null;
        const shownHalls = (hall ? [hall] : D.halls).map(g => since ? Object.assign({}, g, { rows: g.rows.filter(r => r.since) }) : g).filter(g => g.rows.length);
        const all = [].concat(...D.halls.map(g => g.rows));
        const withRoom = D.rooms;
        const printLabel = hall ? 'the ' + hall.label.toLowerCase() + ' list' : 'the halls list';
        ctx.head(title, factNode(D.fact, /since printed$/, { v: 'since' }), [
          K.more('Export', [{ label: 'Excel', hint: A.readonly ? 'Read only while seeing as' : '', disabled: A.readonly, run: () => excel(p, 'halls', 'Young Folks halls') }], { ghost: true }),
          A.btn(hall ? 'Print ' + (hall.key === 'men' ? 'young men' : hall.key === 'women' ? 'young women' : 'list') : 'Print', { primary: true, write: true, icon: 'file', title: 'Each hall on its own page', onClick: () => printHalls(hall ? [hall] : D.halls, printLabel) })]);
        const tools = h('div', { class: 'cm-toolbar' });
        const chips = D.halls.length > 1 ? [{ id: '', label: 'Both', n: D.total }].concat(D.halls.map(x => ({ id: x.key, label: x.label, n: x.n }))) : [{ id: '', label: 'All', n: D.total }];
        if (D.since || since) chips.push({ id: 'since', label: 'Since printed', n: D.since });
        if (chips.length > 1) tools.appendChild(A.views(chips, since ? 'since' : hall ? hall.key : '', id => A.go({ v: id })));
        if (D.total > 10) tools.appendChild(K.find({ placeholder: 'Search', value: find, onInput: v => { find = v; render(); } }));
        if (tools.childNodes.length) main.appendChild(tools);
        // Rooms are Lodging's: shown once Lodging has published them, never before.
        main.appendChild(h('p', { class: 'ap-quiet cm-pad cm-roomsline', text: !D.published ? 'Rooms · After Lodging publishes' : withRoom ? 'Rooms · As Lodging published them ' + K.md(D.published) : 'Rooms · Not given in the halls yet' }));
        if (since && !shownHalls.length) { main.appendChild(sinceEmpty(D.print, { v: '' })); sp.close(true); return; }
        const box = h('div');
        let shown = [];
        const open = r => {
          setOpen(r.key);
          const order = r.order || [];
          sp.open({
            title: r.name, line: K.facts([r.age ? 'Age ' + r.age : '', r.minor ? 'Under 18' : '']),
            tags: [sinceTag(r.since), r.approval === 'Waiting' ? tag('Waiting', 'warn', 'Parent approval waiting · Lodging') : null, !r.hall ? tag('Hall not set', 'warn') : null].filter(Boolean),
            nav: navOf(shown, shown.indexOf(r), open),
            body: [h('dl', { class: 'ap-facts' },
              fl('Hall', r.hall === 'men' ? 'Young men’s hall' : r.hall === 'women' ? 'Young women’s hall' : 'Not set'),
              fl('Nights', order.length ? h('span', { class: 'cm-daypills' }, order.map(x => h('span', { class: 'cm-daypill' + ((r.nightsAll || []).indexOf(x) > -1 ? ' is-on' : ''), text: /^Early /.test(x) ? 'Early ' + x.slice(6, 9) : x.slice(0, 3) }))) : r.nights),
              D.published ? fl('Room', r.room || 'Not given') : fl('Room', 'After Lodging publishes'),
              fl('Approval', r.approval),
              fl('Rooming note', r.rooming ? h('span', { title: 'As typed · Lodging pairs and gives rooms', text: r.rooming }) : ''),
              fl('Household', K.facts([r.household, r.rid]))),
              A.linked(r.linked, { from: 'yf-halls:' + r.key, name: r.name }), A.history(r.hist)],
            onClose: closed, focus: 'head'
          });
        };
        const render = () => {
          const f = find.trim().toLowerCase();
          A.clear(box);
          shown = [];
          shownHalls.forEach(g => {
            const rows = g.rows.filter(r => !f || (r.name + ' ' + r.household + ' ' + r.rooming + ' ' + r.room).toLowerCase().indexOf(f) > -1);
            shown = shown.concat(rows);
            box.appendChild(h('section', { class: 'cm-section cm-hall' }, h('h2', { class: 'ap-h2' }, g.label, h('span', { class: 'ap-h2__n', text: K.facts([K.plural(g.n, 'Young Folk'), g.minors ? g.minors + ' under 18' : '']) })),
              rows.length ? h('div', { class: 'cm-scroll' }, h('table', { class: 'cm-table' },
                h('thead', null, h('tr', null, withRoom ? h('th', { text: 'Room' }) : null, h('th', { text: 'Young Folk' }), h('th', { text: 'Nights' }), h('th', { text: 'Rooming note' }), h('th', { class: 'is-wide', text: 'Household' }))),
                h('tbody', null, rows.map(r => {
                  const tr = h('tr', { 'data-key': r.key },
                    withRoom ? h('td', { class: 'cm-nowrap', text: r.room || '' }) : null,
                    h('td', null, nameBtn(r.name, () => open(r)), h('span', { class: 'cm-sub2' }, K.facts([r.age ? 'Age ' + r.age : '']), r.minor ? tag('Under 18', '', 'Registered as under 18') : null, r.approval === 'Waiting' ? tag('Waiting', 'warn', 'Parent approval waiting') : null), sinceTag(r.since, true)),
                    h('td', { class: 'cm-nowrap', text: r.nights }),
                    h('td', { class: r.rooming ? '' : 'is-muted', text: r.rooming || '' }),
                    h('td', { class: 'is-wide is-muted', text: r.household }));
                  rowOpen(tr, r.key, () => open(r));
                  return tr;
                })))) : h('p', { class: 'ap-quiet', text: 'No matches' })));
          });
        };
        main.appendChild(box);
        render();
        main.appendChild(h('p', { class: 'ap-help cm-pad cm-foot', text: K.facts(['Rooming notes as typed · Lodging pairs and gives rooms', D.family ? D.family + ' with their family, not listed' : '', D.print ? 'Printed ' + K.md(D.print.at) + (D.print.by ? ' · ' + D.print.by : '') : '']) }));
        const cur = p.id && all.find(r => r.key === p.id);
        if (cur) { if (shown.indexOf(cur) < 0) shown = all; open(cur); } else sp.close(true);
      }
      // Each hall on its own page: room, name, age, under 18, nights, rooming note, and a box to tick at check-in.
      function printHalls(list, label) {
        markPrinted('halls', label, [].concat(...list.map(g => g.rows.map(r => r.key)))).then(reload).catch(() => {});
        K.print({ tz: H && H.tz, title: 'Young Folks halls', sub: H.as_of ? 'As of ' + H.as_of : '', who: 'Young Folks committee', landscape: true, build: () => h('div', null, list.map((g, i) => h('section', { class: i ? 'cm-pbreak' : '' },
          h('h2', { text: g.label + ' · ' + K.plural(g.n, 'Young Folk') + (g.minors ? ' · ' + g.minors + ' under 18' : '') }),
          h('table', null, h('thead', null, h('tr', null, (D.rooms ? ['Room'] : []).concat(['Young Folk', 'Age', 'Under 18', 'Nights', 'Rooming note', 'Here']).map(c => h('th', { class: c === 'Here' ? 'cm-tickh' : '', text: c })))),
            h('tbody', null, g.rows.map(r => h('tr', { class: 'cm-mid' }, D.rooms ? h('td', { text: r.room }) : null, h('td', { text: r.name }), h('td', { text: r.age }), h('td', { text: r.minor ? 'Yes' : '' }), h('td', { text: r.nights }), h('td', { text: r.rooming }), h('td', { class: 'cm-tick' })))))))) });
      }

      K.loading(ctx);
      load();
      return () => { alive = false; ctx.body.classList.remove('ap-body--flush'); };
    };
  }

  /* ------------------------------------------------------------ Services (Ushers) */

  // The week's services as the public schedule has them (area-committee-lists 9): by day, each a row that
  // opens read only. Before the COA publishes the schedule: one card saying so.
  function servicesScreen(ctx) {
    const p = ctx.params;
    let alive = true, sp = null;
    K.loading(ctx);
    A.api('GET', 'services').then(D => {
      if (!alive) return;
      A.clear(ctx.body);
      sp = ctx.split();
      if (!D.public) {
        ctx.head('Services', D.fact.line, []);
        sp.main.appendChild(A.empty({ title: 'Schedule not public', line: D.posted ? 'Public ' + K.md(D.posted) : 'The COA publishes it', inset: true }));
        return;
      }
      const day = D.days.find(d => d.date === p.v) || null;
      const days = day ? [day] : D.days;
      const printOut = () => K.print({ title: 'Services', sub: D.fact.line, who: 'Ushers', build: () => h('div', null, days.map(d => h('section', null,
        h('h2', { text: K.day(d.date) + ' · ' + K.plural(d.n, 'service') }),
        h('table', null,
          h('thead', null, h('tr', null, ['When', 'Service', 'Where'].map(c => h('th', { text: c })))),
          h('tbody', null, d.rows.map(s => h('tr', null, h('td', { text: s.when }), h('td', { text: s.title }), h('td', { text: s.place }))))))))
      });
      ctx.head('Services', D.fact.head, [A.btn('Print', { primary: true, icon: 'file', onClick: printOut })]);
      if (D.days.length > 1) sp.main.appendChild(h('div', { class: 'cm-toolbar' }, A.views([{ id: '', label: 'All', n: D.n }].concat(D.days.map(d => ({ id: d.date, label: K.day(d.date), n: d.n }))), day ? day.date : '', id => A.go({ v: id }))));
      const flat = [].concat(...days.map(d => d.rows));
      const open = s => {
        p.id = s.id; A.setParams({ id: s.id });
        sp.main.querySelectorAll('tr.cm-tap').forEach(t => t.classList.toggle('is-open', t.dataset.key === s.id));
        sp.open({ title: s.title, line: K.day(s.date) + ' · ' + (s.when || 'No time'), nav: navOf(flat, flat.indexOf(s), open),
          body: [h('dl', { class: 'ap-facts' }, fl('When', s.when || 'No time'), fl('Where', s.place), fl('Kind', s.kind), fl('For', s.for), fl('Call-in', s.call_in ? 'On the call-in line' : '')), h('p', { class: 'ap-help', text: 'From the published schedule · The COA changes it' })],
          onClose: () => { p.id = ''; A.setParams({ id: '' }); sp.main.querySelectorAll('tr.is-open').forEach(t => t.classList.remove('is-open')); }, focus: 'head' });
      };
      const rows = [];
      days.forEach(d => {
        rows.push(h('tr', { class: 'cm-group' }, h('td', { colspan: '3', text: K.day(d.date) + ' · ' + K.plural(d.n, 'service') + (d.span ? ' · ' + d.span : '') })));
        d.rows.forEach(s => {
          const tr = h('tr', { 'data-key': s.id, class: 'cm-tap' + (p.id === s.id ? ' is-open' : '') }, h('td', { class: 'cm-nowrap', text: s.when || 'No time' }),
            h('td', null, h('button', { type: 'button', class: 'cm-rowbtn', on: { click: e => { e.stopPropagation(); open(s); } } }, h('span', { class: 'cm-title', text: s.title }))), h('td', { class: 'is-muted', text: s.place }));
          tr.addEventListener('click', () => open(s));
          rows.push(tr);
        });
      });
      sp.main.appendChild(h('div', { class: 'cm-scroll' }, h('table', { class: 'cm-table cm-services' }, h('thead', null, h('tr', null, h('th', { text: 'When' }), h('th', { text: 'Service' }), h('th', { text: 'Where' }))), h('tbody', null, rows))));
      sp.main.appendChild(h('p', { class: 'ap-help cm-pad cm-foot', text: 'Worship, Council and Communion for Everyone or Conference · From the published schedule' }));
      const cur = p.id && flat.find(s => s.id === p.id);
      if (cur) open(cur);
    }).catch(err => { if (alive) K.failed(ctx, err); });
    return () => { alive = false; };
  }

  A.screen({ id: 'preteens-list', title: 'Children', icon: 'members', section: 'own', who: ['preteens'], render: listScreen('preteens', 'Children') });
  A.screen({ id: 'communion-list', title: 'Communing', icon: 'report', section: 'own', who: ['communion'], render: listScreen('communion', 'Communing') });
  A.screen({ id: 'nursery-list', title: 'Counts by day', icon: 'pram', section: 'own', who: ['nursery'], render: listScreen('nursery', 'Counts by day') });
  A.screen({ id: 'yf-halls', title: 'Halls', icon: 'bunk', section: 'own', who: ['young folks'], render: listScreen('halls', 'Halls') });
  A.screen({ id: 'services', title: 'Services', icon: 'clock', section: 'own', who: ['ushers'], render: servicesScreen });
})();
