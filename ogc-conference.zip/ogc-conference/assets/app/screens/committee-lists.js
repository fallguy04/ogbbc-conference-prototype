/*
 * The committees' lists (lists area; app-committees Oct 11, filled out Oct 13 night). Each list is
 * worked out on the server for its committee and the COA only (module-lists*.php): the browser gets
 * that list and nothing else. Every list: Print (drawn for paper, one page where it fits) and Download
 * for Excel (the same columns every year, and a Columns sheet saying what each holds). Each says when
 * it was made ("As of Oct 13, 9:40 PM") and how many, and nothing that isn't so.
 *
 *   Children        Preteens: each preteen, by day (?v=<date>), who may pick them up, a parent's phone;
 *                   medical notes and emergency contacts only when there are any. Print a day's sheet
 *                   (In and Out boxes), or every day at once; Print medical apart. Download: the
 *                   check-in sheet (never medical).
 *   Communing       Communion: the one number, on what day, and who (households, the names).
 *   Counts by day   Nursery: children under 3 and 3 to 5 each day, households with one under 3. Counts only.
 *   Halls           Young Folks: the Young Folks in the halls, by hall (?v=men|women): age, under 18,
 *                   nights, the room once Lodging has published rooms, their rooming note as typed.
 * "Changed" means the list's own fields changed since it was printed, not any save to a registration.
 */
(function () {
  'use strict';
  const A = window.OGC_APP, h = A.h, K = window.OGC_CK;
  const listsApi = (method, path, body) => A.api(method, '/lists/' + A.params().year + '/' + path, body);
  const asOf = () => (new URLSearchParams(location.search).get('as-of') || '');
  const tag = (t, tone, title) => h('span', { class: 'cm-chip' + (tone ? ' cm-chip--' + tone : ''), title: title || null, text: t });
  const short = d => String(d || '').slice(0, 3);
  const at = H => H && H.as_of ? 'As of ' + H.as_of : '';
  // The Excel file of a list (?format=xlsx), named the same every year but the year.
  const excel = (p, view, name) => K.excel('lists/' + p.year + '/' + view, p.year + ' ' + name, p.as);
  // A print is kept as the list going out ("changed since printed"), but not while previewing a date:
  // that's a look (critique: a demo's print marked the real Children list). Returns a promise.
  const markPrinted = view => asOf() ? Promise.resolve() : listsApi('POST', 'printed', { view });
  // Pick-up the household didn't choose (the Lodging Form doesn't ask): said on screen and on paper.
  const NOT_ASKED = 'From the Lodging Form, which doesn’t ask who may pick up · Their adults are listed · Confirm before a child leaves';
  // The Nursery's mark in the sidebar (a pram); the halls use Lodging's bunk.
  if (A.addIcons) A.addIcons({ pram: 'M3 8a5 5 0 0 1 5-5v5M3 8h9l-1.5 3h-6ZM12 8l1.2-3h1.3M6.2 13a1.2 1.2 0 1 1-2.4 0 1.2 1.2 0 0 1 2.4 0ZM11.7 13a1.2 1.2 0 1 1-2.4 0 1.2 1.2 0 0 1 2.4 0Z' });

  function listScreen(view, title) {
    return function (ctx) {
      const p = ctx.params;
      let D = null, H = null, find = '', alive = true;
      const load = () => listsApi('GET', view + (asOf() ? '?as_of=' + asOf() : '')).then(r => { H = r.head; D = r.list || null; if (alive) draw(); }).catch(err => { if (alive) K.failed(ctx, err); });
      function draw() {
        A.clear(ctx.body);
        ctx.body.classList.add('ap-body--flush');
        if (!D) { ctx.head(title, H && H.cleared ? 'Counts only · Cleared ' + K.md(H.cleared) : '', []); ctx.body.appendChild(A.empty({ title: 'Counts only', line: H && H.cleared ? 'Names cleared ' + K.md(H.cleared) : '', inset: true })); return; }
        // No household registered yet: one empty state, the same on every list (never a zero).
        if (H && !H.held && !H.regs) return K.noRegs(ctx, title, H);
        ({ preteens: children, communion: communing, nursery: nursery, halls: halls })[view]();
      }

      /* ------------------------------------------------------------ Children (Preteens) */

      function children() {
        if (!D.count) { ctx.head(title, at(H), []); ctx.body.appendChild(A.empty({ title: 'No preteens registered', line: K.plural(H.regs, 'household') + ' registered', inset: true })); return; }
        if (!D.viewer) { ctx.head(title, K.plural(D.count, 'preteen'), []); ctx.body.appendChild(A.empty({ title: K.plural(D.count, 'preteen'), line: 'Children’s details · The Preteens committee and the COA', inset: true })); return; }
        const prog = D.program || [];
        const day = prog.find(x => x.date === p.v) || null;
        const rows = day ? D.rows.filter(r => (r.on || []).indexOf(day.date) > -1) : D.rows;
        const withDays = !day && D.rows.some(r => r.days), withMed = !D.paper && rows.some(r => r.medical), withCon = !D.paper && rows.some(r => r.contacts.length);
        ctx.head(title, K.facts([day ? K.plural(rows.length, 'preteen') + ' · ' + K.day(day.date) : K.plural(D.count, 'preteen'), D.paper ? 'Medical notes and contacts on paper' : '', D.printed && D.changed ? K.plural(D.changed, 'change') + ' since printed' : '', at(H)]),
          [A.btn(day ? 'Print ' + short(day.name) : 'Print sheet', { primary: true, icon: 'file', title: day ? 'One line a child, In and Out' : 'One line a child, In and Out for each day', onClick: () => day ? printDay(day, rows) : printSheet(prog) }),
            K.more('More', [day ? { label: 'Print every day', run: () => printSheet(prog) } : null, withMed || withCon || D.rows.some(r => r.medical || r.contacts.length) ? { label: 'Print medical', run: printMedical } : null, { label: 'Download for Excel', run: () => excel(p, 'preteens', 'Preteens check-in') }], { ghost: true })]);
        // The program's days, each with how many are here (?v=<date>); "All" is every child.
        if (prog.length > 1) ctx.body.appendChild(h('div', { class: 'cm-toolbar' }, A.views([{ id: '', label: 'All', n: D.count }].concat(prog.map(x => ({ id: x.date, label: K.day(x.date), n: x.n }))), day ? day.date : '', id => A.go({ v: id }, { replace: true })),
          D.rows.length > 10 ? K.find({ placeholder: 'Search', value: find, onInput: v => { find = v; render(); } }) : null));
        const tbody = h('tbody');
        const render = () => {
          const f = find.trim().toLowerCase();
          const list = rows.filter(r => !f || (r.name + ' ' + r.household + ' ' + r.pickup).toLowerCase().indexOf(f) > -1);
          A.clear(tbody).append(...(list.length ? list.map(r => h('tr', null,
            h('td', null, h('span', { class: 'cm-title', text: r.name }), r.age ? h('span', { class: 'cm-sub2', text: 'Age ' + r.age }) : null, r.new ? tag('New', 'tan') : r.changed ? tag('Changed', 'blue') : null),
            withDays ? h('td', { text: r.days || 'All' }) : null,
            h('td', null, r.unasked ? [tag('Not asked', 'warn', NOT_ASKED), ' '] : null, r.unasked && r.pickup ? 'Adults: ' + r.pickup : (r.pickup || '')),
            h('td', null, K.phone(r.phone)),
            withMed ? h('td', { text: r.medical || '' }) : null,
            withCon ? h('td', null, r.contacts.map(c => h('div', null, c.name, c.rel ? ' · ' + c.rel : '', ' ', K.phone(c.phone)))) : null,
            h('td', { class: 'is-wide is-muted', text: r.household }))) : [h('tr', null, h('td', { colspan: '7', class: 'is-muted', text: 'No matches' }))]));
        };
        if (prog.length <= 1 && D.rows.length > 10) ctx.body.appendChild(h('div', { class: 'cm-toolbar' }, K.find({ placeholder: 'Search', value: find, onInput: v => { find = v; render(); } })));
        if (D.before) ctx.body.appendChild(h('p', { class: 'ap-quiet cm-pad', style: { marginTop: '12px' }, text: K.plural(D.before, 'household') + ' registered before the details were asked' }));
        ctx.body.appendChild(h('div', { class: 'cm-scroll' }, h('table', { class: 'cm-table' }, h('thead', null, h('tr', null, h('th', { text: 'Preteen' }), withDays ? h('th', { text: 'Days' }) : null, h('th', { text: 'May pick up' }), h('th', { text: 'Parent phone' }), withMed ? h('th', { text: 'Medical notes' }) : null, withCon ? h('th', { text: 'Emergency contacts' }) : null, h('th', { class: 'is-wide', text: 'Household' }))), tbody)));
        ctx.body.appendChild(h('p', { class: 'ap-help cm-pad cm-foot', text: K.facts([K.plural(D.count, 'preteen') + ' from ' + K.plural(H.regs, 'household'), 'Ages as registered', 'Medical notes · Preteens and the COA only']) }));
        if (H.from_form) ctx.body.appendChild(h('p', { class: 'ap-help cm-pad cm-foot cm-foot--2', text: 'Not asked · ' + K.plural(H.from_form, 'household') + ' from the Lodging Form, which doesn’t ask who may pick up · Their adults are listed · Confirm before a child leaves' }));
        render();
      }
      // One day's sheet: a line a child, In and Out (portrait; the header on every page).
      function printDay(day, rows) {
        markPrinted('preteens').then(load).catch(() => {});
        K.print({ tz: H && H.tz, title: 'Preteens · ' + K.day(day.date), sub: K.facts([K.plural(rows.length, 'preteen'), at(H)]), who: 'Preteens only', build: () => h('div', null, h('table', { class: 'cm-ptable' },
          h('thead', null, h('tr', null, ['Preteen', 'Age', 'May pick up', 'Parent phone', 'In', 'Out'].map((c, i) => h('th', { class: i > 3 ? 'cm-tickh' : '', text: c })))),
          h('tbody', null, rows.map(r => h('tr', { class: 'cm-mid' }, h('td', { text: r.name }), h('td', { text: r.age }), h('td', null, r.unasked ? [h('b', { text: 'Not asked · ' }), 'Adults: ' + r.pickup] : r.pickup), h('td', { text: r.phone }), h('td', { class: 'cm-tick' }), h('td', { class: 'cm-tick' }))))),
          notAskedKey(rows)) });
      }
      function printSheet(prog) {
        const days = prog.length ? prog : (D.days || []).map(n => ({ name: n }));
        const withDays = D.rows.some(r => r.days);
        markPrinted('preteens').then(load).catch(() => {});
        K.print({ tz: H && H.tz, title: 'Preteens · Check-in', sub: K.facts([K.plural(D.count, 'preteen'), at(H)]), who: 'Preteens only', landscape: true, build: () => h('div', null, h('table', null,
          h('thead', null, h('tr', null, h('th', { text: 'Preteen' }), h('th', { text: 'Age' }), withDays ? h('th', { text: 'Days' }) : null, h('th', { text: 'May pick up' }), h('th', { text: 'Parent phone' }), days.map(d => [h('th', { text: short(d.name) + ' in' }), h('th', { text: short(d.name) + ' out' })]))),
          h('tbody', null, D.rows.map(r => h('tr', { class: 'cm-tall' }, h('td', { text: r.name }), h('td', { text: r.age }), withDays ? h('td', { text: r.days || 'All' }) : null, h('td', null, r.unasked ? [h('b', { text: 'Not asked · ' }), 'Adults: ' + r.pickup] : r.pickup), h('td', { text: r.phone }),
            days.map(d => d.date && (r.on || []).indexOf(d.date) < 0 ? [h('td', { class: 'cm-off', text: '–' }), h('td', { class: 'cm-off', text: '–' })] : [h('td', { class: 'cm-tick' }), h('td', { class: 'cm-tick' })]))))), notAskedKey(D.rows)) });
      }
      const notAskedKey = list => list.some(r => r.unasked) ? h('p', { class: 'cm-key', text: 'Not asked · ' + NOT_ASKED.replace(/^From/, 'from') }) : null;
      function printMedical() {
        markPrinted('medical').catch(() => {});
        const list = D.rows.filter(r => r.medical || r.contacts.length);
        K.print({ tz: H && H.tz, title: 'Preteens · Medical notes and contacts', sub: K.facts([K.plural(list.length, 'preteen'), at(H)]), who: 'Preteens only · Keep private', build: () => list.length ? h('table', null,
          h('thead', null, h('tr', null, ['Preteen', 'Age', 'Medical notes', 'Emergency contacts', 'Parent phone'].map(c => h('th', { text: c })))),
          h('tbody', null, list.map(r => h('tr', null, h('td', { text: r.name }), h('td', { text: r.age }), h('td', { text: r.medical }), h('td', null, r.contacts.map(c => h('div', { text: c.name + (c.rel ? ' · ' + c.rel : '') + (c.phone ? ' · ' + c.phone : '') }))), h('td', { text: r.phone })))))
          : h('p', { text: 'No medical notes or emergency contacts registered' }) });
      }

      /* ------------------------------------------------------------ Communing (Communion) */

      function communing() {
        if (!D.total) { ctx.head(title, at(H), []); ctx.body.appendChild(A.empty({ title: 'No one communing yet', line: K.facts([H.regs ? 'From ' + K.plural(H.regs, 'household') : '', H.from_form ? H.from_form + ' from the Lodging Form, which doesn’t ask' : '']), inset: true })); return; }
        ctx.head(title, K.facts([D.total + ' communing', K.plural(D.households.length, 'household'), H.from_form ? H.from_form + ' not asked' : '', D.date ? K.day(D.date) : '', D.printed && D.changed ? K.plural(D.changed, 'change') + ' since printed' : '', at(H)]),
          [A.btn('Print', { icon: 'file', onClick: printCommunion }), A.btn('Download', { icon: 'download', title: 'For Excel · Household, Registration, Communing, Names', onClick: () => excel(p, 'communion', 'Communing') })]);
        ctx.body.appendChild(h('div', { class: 'cm-section' }, h('div', { class: 'cm-stats' },
          h('div', { class: 'cm-stat' }, h('b', { text: String(D.total) }), h('span', { text: 'Communing' + (D.date ? ' · ' + K.day(D.date) : '') })),
          h('div', { class: 'cm-stat' }, h('b', { text: String(D.households.length) }), h('span', { text: 'Households' })),
          D.away ? h('div', { class: 'cm-stat', title: 'Registered as communing, but not here that day: not counted' }, h('b', { text: String(D.away) }), h('span', { text: 'Not here that day' })) : null,
          // Households the Lodging Form never asked: beside the number, so it isn't read as the whole count.
          H.from_form ? h('div', { class: 'cm-stat cm-stat--warn', title: 'From the Lodging Form, which doesn’t ask about communion · Not in the number' }, h('b', { text: String(H.from_form) }), h('span', { text: 'Households not asked' })) : null)));
        const tbody = h('tbody');
        const render = () => {
          const f = find.trim().toLowerCase(), rows = D.households.filter(r => !f || (r.label + ' ' + r.rid + ' ' + (r.names || []).join(' ')).toLowerCase().indexOf(f) > -1);
          A.clear(tbody).append(...(rows.length ? rows.map(r => h('tr', null, h('td', null, h('span', { class: 'cm-title', text: r.label }), r.new ? tag('New', 'tan') : r.changed ? tag('Changed', 'blue') : null), h('td', { text: (r.names || []).join(', ') }), h('td', { class: 'is-wide is-muted', text: r.rid }), h('td', { class: 'is-num', text: String(r.n) })))
            : [h('tr', null, h('td', { colspan: '4', class: 'is-muted', text: 'No matches' }))]));
        };
        if (D.households.length > 10) ctx.body.appendChild(h('div', { class: 'cm-toolbar' }, K.find({ placeholder: 'Search', value: find, onInput: v => { find = v; render(); } })));
        ctx.body.appendChild(h('div', { class: 'cm-scroll' }, h('table', { class: 'cm-table' }, h('thead', null, h('tr', null, h('th', { text: 'Household' }), h('th', { text: 'Names' }), h('th', { class: 'is-wide', text: 'Registration' }), h('th', { class: 'is-num', text: 'Communing' }))), tbody)));
        ctx.body.appendChild(h('p', { class: 'ap-help cm-pad cm-foot', text: K.facts(['From ' + K.plural(H.regs, 'household'), 'Only those here on communion day', H.from_form ? H.from_form + ' from the Lodging Form, which doesn’t ask' : '']) }));
        render();
      }
      function printCommunion() {
        markPrinted('communion').then(load).catch(() => {});
        K.print({ tz: H && H.tz, title: 'Communion', sub: K.facts([D.total + ' communing', D.date ? K.day(D.date) : '', K.plural(D.households.length, 'household'), H.from_form ? K.plural(H.from_form, 'household') + ' not asked (Lodging Form)' : '', at(H)]), who: 'Communion', build: () => h('table', null,
          h('thead', null, h('tr', null, h('th', { text: 'Household' }), h('th', { text: 'Names' }), h('th', { text: 'Registration' }), h('th', { class: 'is-num', text: 'Communing' }))),
          h('tbody', null, D.households.map(r => h('tr', null, h('td', { text: r.label }), h('td', { text: (r.names || []).join(', ') }), h('td', { text: r.rid }), h('td', { class: 'is-num', text: String(r.n) })))),
          h('tfoot', null, h('tr', null, h('td', { colspan: '3', text: 'Total' }), h('td', { class: 'is-num', text: String(D.total) })))) });
      }

      /* ------------------------------------------------------------ Counts by day (Nursery) */

      function nursery() {
        if (!D.under3 && !D.small) { ctx.head(title, at(H), []); ctx.body.appendChild(A.empty({ title: 'No children under 6 registered', line: 'From ' + K.plural(H.regs, 'household'), inset: true })); return; }
        ctx.head(title, K.facts([K.plural(D.under3, 'child', 'children') + ' under 3', K.plural(D.households, 'household'), at(H)]),
          [A.btn('Print', { primary: true, icon: 'file', onClick: printNursery }), A.btn('Download', { icon: 'download', title: 'For Excel · Date, Day, Under 3, 3–5, Households', onClick: () => excel(p, 'nursery', 'Nursery counts by day') })]);
        ctx.body.appendChild(h('div', { class: 'cm-section' }, h('div', { class: 'cm-stats' },
          h('div', { class: 'cm-stat' }, h('b', { text: String(D.under3) }), h('span', { text: 'Under 3' })),
          h('div', { class: 'cm-stat' }, h('b', { text: String(D.small) }), h('span', { text: 'Ages 3–5' })),
          h('div', { class: 'cm-stat' }, h('b', { text: String(D.households) }), h('span', { text: 'Households with one under 3' })))));
        ctx.body.appendChild(h('div', { class: 'cm-scroll' }, nurseryTable(false)));
        ctx.body.appendChild(h('p', { class: 'ap-help cm-pad cm-foot', text: K.facts(['From ' + K.plural(H.regs, 'household'), D.service_days ? 'Days with a service on the schedule' : '', 'Under 3 by the registration’s age group', '3–5 by the age typed', 'Counts only']) }));
      }
      function nurseryTable(paper) {
        const n = v => v ? String(v) : '–';
        return h('table', { class: paper ? '' : 'cm-table cm-nursery', 'aria-label': 'Counts by day' },
          h('thead', null, h('tr', null, h('th', { text: 'Day' }), h('th', { class: 'is-num', text: 'Under 3' }), h('th', { class: 'is-num', text: '3–5' }), h('th', { class: 'is-num', text: 'Households' }))),
          h('tbody', null, D.days.map(d => h('tr', null, h('td', null, h('span', { class: 'cm-title', text: K.day(d.date) })), h('td', { class: 'is-num is-total', text: n(d.under3) }), h('td', { class: 'is-num', text: n(d.small) }), h('td', { class: 'is-num', text: n(d.households) })))));
      }
      function printNursery() {
        markPrinted('nursery').catch(() => {});
        K.print({ tz: H && H.tz, title: 'Nursery · Counts by day', sub: K.facts([K.plural(D.under3, 'child', 'children') + ' under 3', at(H)]), who: 'Nursery', build: () => h('div', null, nurseryTable(true),
          h('p', { class: 'cm-key', text: K.facts(['From ' + K.plural(H.regs, 'household'), D.service_days ? 'Days with a service on the schedule' : '', 'Under 3 by the registration’s age group', '3–5 by the age typed']) })) });
      }

      /* ------------------------------------------------------------ Halls (Young Folks) */

      function halls() {
        if (!D.total) { ctx.head(title, at(H), []); ctx.body.appendChild(A.empty({ title: 'No Young Folks in the halls', line: D.family ? D.family + ' with their family' : 'From ' + K.plural(H.regs, 'household'), inset: true })); return; }
        const hall = D.halls.find(x => x.key === p.v) || null;
        const shown = hall ? [hall] : D.halls;
        const withRoom = D.rooms;
        ctx.head(title, K.facts([D.total + ' in the halls'].concat(D.halls.map(x => x.n + ' ' + (x.key === 'men' ? 'young men' : x.key === 'women' ? 'young women' : 'hall not set'))).concat([at(H)])),
          [A.btn(hall ? 'Print ' + (hall.key === 'men' ? 'young men' : hall.key === 'women' ? 'young women' : 'list') : 'Print', { primary: true, icon: 'file', title: 'Each hall on its own page', onClick: () => printHalls(shown) }),
            A.btn('Download', { icon: 'download', title: 'For Excel · Hall, Room, Young Folk, Age, Under 18, Nights, Rooming note, Household', onClick: () => excel(p, 'halls', 'Young Folks halls') })]);
        const tools = h('div', { class: 'cm-toolbar' });
        if (D.halls.length > 1) tools.appendChild(A.views([{ id: '', label: 'Both', n: D.total }].concat(D.halls.map(x => ({ id: x.key, label: x.label, n: x.n }))), hall ? hall.key : '', id => A.go({ v: id }, { replace: true })));
        if (D.total > 10) tools.appendChild(K.find({ placeholder: 'Search', value: find, onInput: v => { find = v; render(); } }));
        if (tools.childNodes.length) ctx.body.appendChild(tools);
        // Rooms are Lodging's: shown once Lodging has published them, never before.
        ctx.body.appendChild(h('p', { class: 'ap-quiet cm-pad cm-roomsline', text: !D.published ? 'Rooms · After Lodging publishes' : withRoom ? 'Rooms · As Lodging published them ' + K.md(D.published) : 'Rooms · Not given in the halls yet' }));
        const box = h('div');
        const render = () => {
          const f = find.trim().toLowerCase();
          A.clear(box);
          shown.forEach(g => {
            const rows = g.rows.filter(r => !f || (r.name + ' ' + r.household + ' ' + r.rooming + ' ' + r.room).toLowerCase().indexOf(f) > -1);
            box.appendChild(h('section', { class: 'cm-section cm-hall' }, h('h2', { class: 'ap-h2' }, g.label, h('span', { class: 'ap-h2__n', text: K.facts([K.plural(g.n, 'Young Folk'), g.minors ? g.minors + ' under 18' : '']) })),
              rows.length ? h('div', { class: 'cm-scroll' }, h('table', { class: 'cm-table' },
                h('thead', null, h('tr', null, withRoom ? h('th', { text: 'Room' }) : null, h('th', { text: 'Young Folk' }), h('th', { text: 'Nights' }), h('th', { text: 'Rooming note' }), h('th', { class: 'is-wide', text: 'Household' }))),
                h('tbody', null, rows.map(r => h('tr', null,
                  withRoom ? h('td', { class: 'cm-nowrap', text: r.room || '' }) : null,
                  h('td', null, h('span', { class: 'cm-title', text: r.name }), h('span', { class: 'cm-sub2' }, K.facts([r.age ? 'Age ' + r.age : '']), r.minor ? tag('Under 18', '', 'Registered as under 18') : null)),
                  h('td', { class: 'cm-nowrap', text: r.nights }),
                  h('td', { class: r.rooming ? '' : 'is-muted', text: r.rooming || '' }),
                  h('td', { class: 'is-wide is-muted', text: r.household })))))) : h('p', { class: 'ap-quiet', text: 'No matches' })));
          });
        };
        ctx.body.appendChild(box);
        render();
        ctx.body.appendChild(h('p', { class: 'ap-help cm-pad cm-foot', text: K.facts(['Rooming notes as typed · Lodging pairs and gives rooms', D.family ? D.family + ' with their family, not listed' : '']) }));
      }
      // Each hall on its own page: room, name, age, under 18, nights, rooming note, and a box to tick at check-in.
      function printHalls(list) {
        markPrinted('halls').catch(() => {});
        K.print({ tz: H && H.tz, title: 'Young Folks halls', sub: at(H), who: 'Young Folks committee', landscape: true, build: () => h('div', null, list.map((g, i) => h('section', { class: i ? 'cm-pbreak' : '' },
          h('h2', { text: g.label + ' · ' + K.plural(g.n, 'Young Folk') + (g.minors ? ' · ' + g.minors + ' under 18' : '') }),
          h('table', null, h('thead', null, h('tr', null, (D.rooms ? ['Room'] : []).concat(['Young Folk', 'Age', 'Under 18', 'Nights', 'Rooming note', 'Here']).map(c => h('th', { class: c === 'Here' ? 'cm-tickh' : '', text: c })))),
            h('tbody', null, g.rows.map(r => h('tr', { class: 'cm-mid' }, D.rooms ? h('td', { text: r.room }) : null, h('td', { text: r.name }), h('td', { text: r.age }), h('td', { text: r.minor ? 'Yes' : '' }), h('td', { text: r.nights }), h('td', { text: r.rooming }), h('td', { class: 'cm-tick' })))))))) });
      }

      K.loading(ctx);
      load();
      return () => { alive = false; ctx.body.classList.remove('ap-body--flush'); };
    };
  }

  A.screen({ id: 'preteens-list', title: 'Children', icon: 'members', section: 'own', who: ['preteens'], render: listScreen('preteens', 'Children') });
  A.screen({ id: 'communion-list', title: 'Communing', icon: 'report', section: 'own', who: ['communion'], render: listScreen('communion', 'Communing') });
  A.screen({ id: 'nursery-list', title: 'Counts by day', icon: 'pram', section: 'own', who: ['nursery'], render: listScreen('nursery', 'Counts by day') });
  A.screen({ id: 'yf-halls', title: 'Halls', icon: 'bunk', section: 'own', who: ['young folks'], render: listScreen('halls', 'Halls') });
})();
