/*
 * coa-intake.js — Intake: the year's request round, for whoever runs it (the COA, or the committee the
 * COA hands it to; A/V in 2027 if the COA agrees). includes/module-requests.php is the server's half.
 *
 *   - The round: Run by, the send and due dates (counted from the Conference's first day), the one
 *     automatic reminder, what's asked, which committees. Change opens them in the panel.
 *   - Send emails each committee's head its own link (never by itself; asked first, with the email).
 *   - The board: each committee's status (Not sent · Not opened · Opened · Started · Returned, Late),
 *     what's left, Not sure. A committee opens beside the list; Open list goes to its Requests.
 *   - Remind: those not returned, once a day each (asked first).
 *   - To settle: rows marked Not sure, removals asked of the packet, requests whose committee isn't on
 *     the list, and packet parts and Help cards nobody answers for (Assign).
 *   - Export for campus (the venue's shape), Mark sent, Template and Upload for every committee.
 */
(function () {
  'use strict';
  const A = window.OGC_APP, K = window.OGC_COA, R = window.OGC_REQ, O = window.OGC;
  if (!A || !K || !R) return;
  const h = A.h;
  const plural = A.fmt.plural, md = K.md;
  const ASKS = [['requests', 'Requests to the campus', 'Requests'], ['packet', 'Packet and Help', 'Packet'], ['contact', 'Contact', 'Contact']];
  const WHY = { notsure: 'Not sure', remove: 'Remove asked', nocommittee: 'No committee', noowner: 'No one answers' };
  const KIND = { request: 'Request', packet: 'Packet', help: 'Help card', contact: 'Contact' };
  const weeks = off => { const w = Math.round(-off / 7); return -off % 7 === 0 ? plural(w, 'week') + ' before' : plural(-off, 'day') + ' before'; };

  A.screen({
    id: 'intake', title: 'Intake', icon: 'mail', section: 'own', who: ['coa'],
    render(ctx) {
      let alive = true;
      const y = ctx.params.year;
      ctx.head('Intake', '', []);
      K.loading(ctx.body);
      Promise.all([K.load(y), A.api('GET', 'round')]).then(([d, b]) => { if (alive) page(ctx, d, b); }, err => { if (alive) K.failed(ctx.body, err); });
      return () => { alive = false; };
    }
  });

  function page(ctx, d, b) {
    const y = d.year, boot = ctx.boot;
    const ro = () => !!A.readonly || !b.can.write;
    let rows = d.rowsOf('needs').map(r => Object.assign({}, r));
    const listed = boot.committees.filter(c => c.key !== 'coa').map(c => c.name);
    let view = ['waiting', 'notopened', 'returned', 'settle'].indexOf(ctx.params.v) > -1 ? ctx.params.v : '';
    let openKey = ctx.params.id && ctx.params.id !== 'remind' && ctx.params.id !== 'send' ? ctx.params.id : '';

    A.clear(ctx.body);
    const sp = ctx.split();
    sp.el.classList.add('cx-split');
    const views = h('div', { class: 'ap-views' });
    const main = h('div', { class: 'cx-page rq-intake' });
    sp.main.append(views, main);

    const inRound = () => b.committees.filter(c => !c.skipped);
    const isWait = c => ['sent', 'opened', 'started'].indexOf(c.status) > -1;
    const waiting = () => inRound().filter(isWait);
    const notSent = () => inRound().filter(c => c.status === 'notsent');
    const returned = () => inRound().filter(c => c.status === 'returned');
    const sent = () => !!b.sent;
    // Remind only from a few days after a committee's first email (remind_from), and once a day.
    const canRemind = c => isWait(c) && c.people && c.remind_from && d.today >= c.remind_from && c.reminded !== d.today;
    const remindable = () => waiting().filter(canRemind);
    const remindNext = () => waiting().filter(c => c.people && c.remind_from && d.today < c.remind_from).map(c => c.remind_from).sort()[0] || '';
    const remindWhy = c => c.reminded === d.today ? 'Reminded today' : c.remind_from && d.today < c.remind_from ? 'Remind from ' + md(c.remind_from) : '';
    const sentStamp = () => d.coa && d.coa.sent && d.coa.sent.needs;
    const reload = said => A.api('GET', 'round').then(nb => { b = nb; draw(); if (said) A.toast(said); }, A.fail);

    /* ------------------------------------------------------------ the title row */
    function head() {
      const acts = [];
      const w = waiting().length, ns = notSent().filter(c => c.people).length;
      const answered = rows.some(r => ['keep', 'change', 'new'].indexOf(r.answer) > -1);
      // The one primary: Send before it's out; Remind while committees answer; Export once they all have.
      if (!ro()) {
        // Never a disabled button with its reason hidden: with no one to send to, or no dates yet, the
        // board and the round's facts say why, and Send isn't drawn.
        if (!sent() && ns && b.dates.due) acts.push(A.btn('Send · ' + ns, { primary: true, write: true, icon: 'mail', title: 'Emails each committee’s head its own link', onClick: () => doSend('') }));
        else if (remindable().length) acts.push(A.btn('Remind · ' + remindable().length, { primary: true, write: true, icon: 'mail', title: 'Emails the heads of committees not returned', onClick: () => doRemind('') }));
      }
      if (answered && b.settings.asks.indexOf('requests') > -1) acts.push(A.btn('Export for campus', { primary: sent() && !w && !ro(), ghost: !(sent() && !w), icon: 'file', title: 'The list for the campus · By day and place, totals by day', onClick: () => exportCampus('') }));
      acts.push(A.btn('More', { ghost: true, iconOnly: true, icon: 'more', onClick: e => A.menu(e.currentTarget, [
        { label: 'Template · Every committee', run: () => R.template(rows, comNames(), y, d.today) },
        { label: 'Upload', disabled: ro(), hint: ro() ? 'Read only while seeing as' : '', run: () => R.upload({ rows, listed, mine: null, sp, send: sendNeeds }) },
        sent() && ns && !ro() ? { label: 'Send to ' + plural(ns, 'committee') + ' not sent', run: () => doSend('') } : null,
        !sentStamp() && answered && !ro() ? { label: 'Mark as sent to campus', run: () => markSent(true) } : null,
        sentStamp() && !ro() ? { label: 'Not sent to campus', run: () => markSent(false) } : null,
        !ro() ? { label: 'Change the round', run: setup } : null
      ].filter(Boolean)) }));
      const fact = !sent()
        ? ['Not sent', b.dates.send ? 'Send date ' + md(b.dates.send) : 'Dates to come'].join(' · ')
        : ['Sent ' + md(b.sent), 'Due ' + md(b.dates.due) + (d.today > b.dates.due && waiting().length ? ' · Late' : ''), returned().length + ' of ' + inRound().length + ' returned', w && !remindable().length && remindNext() ? 'Remind from ' + md(remindNext()) : ''].filter(Boolean).join(' · ');
      ctx.head('Intake', fact, acts);
    }
    const comNames = () => inRound().map(c => c.name);

    /* ------------------------------------------------------------ views */
    function drawViews() {
      A.clear(views);
      const st = b.settle.length;
      const chips = [{ id: '', label: 'All', n: inRound().length }];
      if (sent()) {
        chips.push({ id: 'waiting', label: 'Waiting', n: waiting().length || null });
        chips.push({ id: 'notopened', label: 'Not opened', n: inRound().filter(c => c.status === 'sent').length || null });
        chips.push({ id: 'returned', label: 'Returned', n: returned().length || null });
      }
      chips.push({ id: 'settle', label: 'To settle', n: st || null });
      views.appendChild(A.views(chips, view, id => { view = id; A.setParams({ v: view, id: '' }); sp.close(true); draw(); }));
    }

    /* ------------------------------------------------------------ the round's facts */
    function roundFacts() {
      const s = b.settings;
      const asks = ASKS.filter(([k]) => s.asks.indexOf(k) > -1).map(x => x[2]).join(', ');
      const reminder = s.remind ? md(b.dates.remind) : 'Off';
      const remSub = !s.remind ? '' : b.auto === 'skip' ? 'Not sent · The round went out after it' : b.auto ? 'Sent ' + md(b.auto) : plural(s.remind, 'day') + ' before' + (b.dates.remind_moved ? ' · Moved off the holidays' : '') + ' · By itself';
      const box = h('section', { class: 'rq-round', 'aria-label': 'The round' },
        h('dl', { class: 'rq-round__facts' },
          fact('Run by', b.run_by.name, b.run_by.key === 'coa' ? '' : 'Handed by the COA'),
          fact(sent() ? 'Sent' : 'Send', b.dates.send ? (sent() ? md(b.sent) : md(b.dates.send)) : 'Dates to come', sent() ? b.sent_by : b.dates.send ? weeks(s.send_off) : ''),
          fact('Due', b.dates.due ? md(b.dates.due) : 'Dates to come', b.dates.due ? weeks(s.due_off) : ''),
          fact('Reminder', reminder, remSub),
          fact('Asks', asks),
          fact('Committees', String(inRound().length), b.committees.length > inRound().length ? (b.committees.length - inRound().length) + ' left out' : '')),
        h('div', { class: 'rq-round__act' }, K.link('Change', setup, { title: 'Dates, reminder, what’s asked, which committees' + (b.can.hand ? ', who runs it' : '') })));
      return box;
    }
    function fact(label, value, sub) {
      return h('div', { class: 'rq-round__f' }, h('dt', { text: label }), h('dd', null, h('span', { text: value || '' }), sub ? h('span', { class: 'rq-round__sub', text: sub }) : null));
    }

    /* ------------------------------------------------------------ the board */
    function draw() {
      head(); drawViews();
      A.clear(main);
      if (view === 'settle') { main.appendChild(settleView()); return; }
      main.appendChild(roundFacts());
      if (!b.dates.due) main.appendChild(h('p', { class: 'cx-issue cx-issue--soft', text: 'The Conference has no dates yet · Dates and place first' }));
      if (sentStamp()) {
        // Only what went as confirmed counts as sent: rows confirmed since are changes; rows still not
        // confirmed are said until they're settled.
        const ch = R.since(rows, sentStamp());
        // One span for the words, so they wrap as a line of text beside the mark (at 390 too).
        main.appendChild(h('p', { class: 'cx-sentline' }, A.icon('check', 14), h('span', null, 'Sent to campus ' + K.mdY(sentStamp().at, y) + (sentStamp().by ? ' · ' + sentStamp().by : ''),
          ch && ch.pending.length ? ' · ' + plural(ch.pending.length, 'request') + ' not confirmed' : null,
          ch && ch.n ? [' · ', h('b', { text: plural(ch.n, 'change') + ' since' }), ' ', K.link('Export changes', () => exportCampus('changes')), [' · ', K.link('Mark as sent', () => markSent(true), { title: 'Once the changes have gone to the campus · Counted from then' })]] : null)));
      } else if (b.exported && rows.some(r => ['keep', 'change', 'new'].indexOf(r.answer) > -1)) {
        // Downloaded, not marked sent: the button stays here, not only in a toast.
        main.appendChild(h('p', { class: 'cx-sentline cx-sentline--todo' }, A.icon('file', 14), h('span', null, 'Downloaded for campus ' + md(b.exported) + (b.exported_by ? ' · ' + b.exported_by : '') + ' · Not marked sent',
          ro() ? null : [' · ', K.link('Mark as sent', () => markSent(true), { title: 'Once the list has gone to the campus · Later changes are counted from then' })])));
      }
      let list = inRound();
      if (view === 'waiting') list = waiting();
      if (view === 'notopened') list = inRound().filter(c => c.status === 'sent');
      if (view === 'returned') list = returned();
      const skipped = b.committees.filter(c => c.skipped);
      main.appendChild(A.table({
        label: 'Committees in the round',
        rows: list, key: c => c.key, selected: openKey,
        onOpen: c => openLine(c.key),
        empty: A.empty({ title: view === 'returned' ? 'None returned yet' : view === 'notopened' ? 'Every committee has opened it' : 'None waiting', inset: true }),
        cols: [
          { label: 'Committee', render: c => h('span', { class: 'ap-cell-title', text: c.name }) },
          { label: 'Head', wide: true, cls: 'ap-td--muted', render: c => c.heads.length ? c.heads.join(', ') : h('span', { class: 'ap-quiet', text: c.people ? 'No head' : 'No one on it' }) },
          { label: 'Status', cls: 'ap-td--nowrap', render: c => [statusTag(c), c.late ? A.tag('Late', 'late') : null] },
          { label: 'To answer', cls: 'ap-td--num', render: c => c.status === 'returned' ? h('span', { class: 'ap-quiet', text: '—' }) : String(c.left.total) },
          { label: 'Not sure', cls: 'ap-td--num', wide: true, render: c => c.left.notsure ? h('span', { class: 'rq-unsure', text: String(c.left.notsure) }) : '' },
          { label: 'Last', wide: true, cls: 'ap-td--nowrap ap-td--muted', render: c => lastWords(c) },
          // On a phone the row opens its panel, which has Remind and Send.
          { label: '', cls: 'ap-td--num', wide: true, render: c => rowAct(c) }
        ]
      }));
      if (skipped.length && !view) main.appendChild(h('p', { class: 'ap-help rq-skipped', text: 'Not in the round · ' + skipped.map(c => c.name).join(', ') }));
      const fold = R.stockFold(rows, d);
      if (fold && !view) main.appendChild(fold);
      if (openKey) openLine(openKey, true);
    }
    function statusTag(c) {
      const tone = { returned: 'ok', started: 'tan', opened: 'tan' }[c.status] || '';
      return A.tag(c.words, tone);
    }
    function lastWords(c) {
      if (c.returned) return 'Returned ' + md(c.returned);
      if (c.started) return 'Started ' + md(c.started);
      if (c.opened) return 'Opened ' + md(c.opened);
      if (c.reminded) return 'Reminded ' + md(c.reminded);
      if (c.sent) return 'Sent ' + md(c.sent);
      return '';
    }
    function rowAct(c) {
      if (ro()) return null;
      if (c.status === 'notsent' && sent() && c.people) return A.btn('Send', { ghost: true, write: true, onClick: e => { e.stopPropagation(); doSend(c.key); } });
      if (canRemind(c)) return A.btn('Remind', { ghost: true, write: true, title: 'Emails ' + (c.heads[0] || 'the committee') + ' again', onClick: e => { e.stopPropagation(); doRemind(c.key); } });
      if (isWait(c) && c.people && remindWhy(c)) return h('span', { class: 'ap-quiet rq-when', text: remindWhy(c) });
      return null;
    }

    /* ------------------------------------------------------------ one committee, beside the list */
    function openLine(key, quiet) {
      const c = b.committees.find(x => x.key === key);
      if (!c) return;
      openKey = key;
      if (!quiet) A.setParams({ id: key });
      main.querySelectorAll('tr[data-key]').forEach(tr => tr.setAttribute('aria-selected', String(tr.dataset.key === key)));
      const unsure = b.settle.filter(x => x.ckey === key);
      const body = h('div', { class: 'rq-line' },
        h('p', null, statusTag(c), c.late ? [' ', A.tag('Late', 'late')] : null),
        K.facts([
          ['Head', c.heads.length ? c.heads.join(', ') : (c.people ? 'No head' : 'No one on it')],
          c.sent ? ['Sent', md(c.sent) + ' · ' + plural(c.sent_n, 'email')] : ['Sent', c.people ? 'Not yet' : 'No one to send to'],
          c.opened ? ['Opened', md(c.opened)] : null,
          c.started ? ['Started', md(c.started)] : null,
          c.returned ? ['Returned', md(c.returned) + (c.returned_by ? ' · ' + c.returned_by : '')] : null,
          c.reminded ? ['Reminded', md(c.reminded) + (c.reminds > 1 ? ' · ' + c.reminds + ' times' : '')] : null,
          isWait(c) && c.people && c.remind_from && d.today < c.remind_from ? ['Remind', 'From ' + md(c.remind_from)] : null
        ]),
        h('p', { class: 'ap-label', text: 'Answers' }),
        h('ul', { class: 'rq-counts' },
          b.settings.asks.indexOf('requests') > -1 ? count('Requests to the campus', c.left.requests) : null,
          b.settings.asks.indexOf('packet') > -1 && (c.packet || c.help) ? count('Packet and Help · ' + (c.packet + c.help), c.left.packet + c.left.help) : null,
          b.settings.asks.indexOf('contact') > -1 ? count('Contact', c.left.contact) : null),
        unsure.length ? [h('p', { class: 'ap-label', text: 'Not sure' }), h('ul', { class: 'rq-unsurelist' }, unsure.map(x => h('li', null, h('b', { text: x.title }), x.note ? h('span', { class: 'ap-quiet', text: ' · “' + x.note + '”' }) : null)))] : null,
        !c.people && b.can.hand ? h('p', { class: 'ap-help' }, 'No one to send to · ', A.link({ s: 'members', id: '', c: '', v: '' }, 'Add people on Members')) : null);
      const foot = [A.btn('Open list', { primary: true, onClick: () => A.go({ s: 'requests', c: key, id: '', v: '' }) })];
      if (!ro()) {
        if (canRemind(c)) foot.push(A.btn('Remind', { write: true, onClick: () => doRemind(key) }));
        if (c.status === 'notsent' && c.people && b.dates.due) foot.push(A.btn('Send', { write: true, onClick: () => doSend(key) }));
        if (c.status === 'returned') foot.push(A.btn('Reopen', { ghost: true, write: true, title: 'Back to Started · ' + c.name + ' can change its answers', onClick: () => A.api('POST', 'round/reopen', { c: key }).then(() => reload('Reopened · ' + c.name), A.fail) }));
      }
      sp.open({ title: c.name, body, foot, onClose: () => { openKey = ''; A.setParams({ id: '' }); main.querySelectorAll('tr[data-key]').forEach(tr => tr.setAttribute('aria-selected', 'false')); } });
    }
    function count(label, n) {
      return h('li', null, h('span', { text: label }), h('span', { class: n ? 'rq-jump__n' : 'rq-jump__n is-done' }, n ? n + ' left' : A.icon('check', 13)));
    }

    /* ------------------------------------------------------------ send and remind (asked first) */
    function doSend(only) {
      const list = (only ? inRound().filter(c => c.key === only) : notSent());
      const to = list.filter(c => c.people), nobody = list.filter(c => !c.people);
      if (!to.length) { A.toast('No one to send to · Add people on Members'); return; }
      const early = b.dates.send && d.today < b.dates.send;
      const pre = h('pre', { class: 'rq-email', text: 'Loading' });
      A.api('GET', 'round/email?c=' + encodeURIComponent(to[0].key)).then(e => { pre.textContent = 'Subject: ' + e.subject + '\n\n' + e.text.replace(/\n{3,}/g, '\n\n').trim(); }, () => { pre.textContent = ''; });
      K.confirm(sp, {
        title: only ? 'Send · ' + to[0].name : 'Send · ' + plural(to.length, 'committee'),
        lines: [
          'Each head gets one email with their own link · Due ' + md(b.dates.due),
          to.map(c => c.name + (c.heads.length ? ' (' + c.heads.join(', ') + ')' : ' (everyone on it)')).join(', '),
          early ? h('span', { class: 'rq-warn', text: 'Send date is ' + md(b.dates.send) + ' · This sends now' }) : null,
          nobody.length ? 'No one to send to · ' + nobody.map(c => c.name).join(', ') : null
        ].filter(Boolean),
        field: K.field('The email · ' + to[0].name, pre, { tag: 'div' }),
        actLabel: 'Send ' + to.length,
        act: () => A.api('POST', 'round/send', only ? { c: only } : {}),
        onDone: r => reload(['Sent to ' + plural(r.sent.length, 'committee'), r.nobody.length ? r.nobody.length + ' with no one to send to' : ''].filter(Boolean).join(' · '))
      });
    }
    function doRemind(only) {
      const list = only ? waiting().filter(c => c.key === only) : waiting();
      const to = list.filter(canRemind);
      if (!to.length) { A.toast(list.length ? remindWhy(list[0]) || 'Reminded today already' : 'No one to remind'); return; }
      K.confirm(sp, {
        title: only ? 'Remind · ' + to[0].name : 'Remind · ' + plural(to.length, 'committee'),
        lines: ['Each head gets their link again, with what’s left · Once a day each', to.map(c => c.name + ' · ' + (c.left.total ? c.left.total + ' left' : 'not returned')).join(', ')],
        actLabel: 'Remind ' + to.length,
        act: () => A.api('POST', 'round/remind', only ? { c: only } : {}),
        onDone: r => reload(['Reminded ' + plural(r.sent.length, 'committee'), r.already.length ? r.already.length + ' already today' : '', r.early && r.early.length ? r.early.length + ' sent too recently' : ''].filter(Boolean).join(' · '))
      });
    }

    /* ------------------------------------------------------------ to settle */
    function settleView() {
      const box = h('div', null);
      // Asked by committees first, then what no one answers for (each group once).
      const asked = x => x.why === 'notsure' || x.why === 'remove';
      const list = b.settle.filter(asked).concat(b.settle.filter(x => !asked(x)));
      if (!list.length) box.appendChild(A.empty({ title: 'Nothing to settle', line: 'Not sure rows and anything without a committee come here', inset: true }));
      else {
        box.appendChild(h('p', { class: 'ap-help rq-help', text: 'Settle with the committee, then mark it here' }));
        box.appendChild(A.table({
          label: 'To settle', rows: list, key: x => x.item,
          onOpen: x => settleOpen(x),
          group: x => asked(x) ? 'Asked by committees' : 'No one answers for these',
          cols: [
            { label: 'What', render: x => [h('span', { class: 'ap-cell-title', text: x.title }), h('span', { class: 'rq-kind', text: ' · ' + KIND[x.kind] })] },
            { label: 'Committee', cls: 'ap-td--muted', render: x => x.ckey ? x.committee : h('span', { class: 'ap-quiet', text: x.committee ? x.committee + ' · Not on the list' : '—' }) },
            { label: 'Why', cls: 'ap-td--nowrap', render: x => A.tag(WHY[x.why], x.why === 'notsure' || x.why === 'remove' ? 'tan' : '') },
            { label: 'Note', wide: true, cls: 'ap-td--muted', render: x => x.note ? '“' + x.note + '”' + (x.by ? ' · ' + x.by : '') : '' },
            { label: '', cls: 'ap-td--num', render: x => A.btn(x.why === 'nocommittee' || x.why === 'noowner' ? 'Assign' : 'Settle', { ghost: true, write: true, onClick: e => { e.stopPropagation(); settleOpen(x); } }) }
          ]
        }));
      }
      // Who answers for each packet part and Help card: chosen by a person, carried to next year.
      const parts = b.parts || [];
      if (parts.length && b.settings.asks.indexOf('packet') > -1) {
        const name = k => k === 'coa' ? 'COA' : ((boot.committees.find(c => c.key === k) || {}).name || '');
        box.appendChild(h('details', { class: 'cx-more rq-owners' }, h('summary', null, h('span', { text: 'Packet and Help · Who answers' }), h('span', { class: 'ap-quiet', text: plural(parts.length, 'part') })),
          h('ul', { class: 'rq-ownerlist' }, parts.map(p => h('li', null, h('span', { class: 'rq-ownerlist__t' }, h('span', { text: p.title }), h('span', { class: 'ap-quiet', text: ' · ' + KIND[p.kind] })),
            h('span', { class: p.owner ? 'ap-muted' : 'ap-quiet', text: p.owner ? name(p.owner) : 'No one' }),
            K.link('Change', () => assign({ item: p.item, kind: p.kind, title: p.title, why: 'noowner' }, p.owner)))))));
      }
      return box;
    }
    function settleOpen(x) {
      if (x.why === 'nocommittee' || x.why === 'noowner') { assign(x, ''); return; }
      const actions = [];
      const note = x.note ? h('blockquote', { class: 'rq-quote', text: x.note }) : null;
      const go = () => A.go({ s: 'requests', c: x.ckey, id: '', v: '' });
      if (x.kind === 'request') {
        actions.push(A.btn('Keep', { primary: true, write: true, onClick: () => { sp.close(true); sendNeeds({ ops: [{ id: x.id, answer: 'keep' }] }, 'Kept · ' + x.title).then(() => reload()); } }));
        actions.push(A.btn('Remove', { write: true, onClick: () => { sp.close(true); sendNeeds({ ops: [{ id: x.id, answer: 'remove' }] }, 'Removed · ' + x.title).then(() => reload()); } }));
      } else {
        actions.push(A.btn(x.kind === 'contact' ? 'Settled' : 'Keep', { primary: true, write: true, title: x.kind === 'contact' ? 'Marks the contact answered, as it now stands' : x.why === 'remove' ? 'Stays in the packet' : 'As it is', onClick: () => { sp.close(true); A.api('POST', 'round/answer', { c: x.ckey, item: x.item, answer: 'keep', note: x.note }).then(() => reload((x.kind === 'contact' ? 'Settled · ' : 'Kept · ') + x.title), A.fail); } }));
        if (x.why === 'remove' && A.allowed(x.kind === 'help' ? 'help' : 'packet')) actions.push(A.btn(x.kind === 'help' ? 'Open Help' : 'Open Packet', { onClick: () => A.go({ s: x.kind === 'help' ? 'help' : 'packet', c: '', id: '', v: '' }) }));
        // Who heads a committee is changed on Members (the COA's): there, or said where it isn't yours.
        if (x.kind === 'contact' && A.allowed('members')) actions.push(A.btn('Open Members', { onClick: () => A.go({ s: 'members', c: '', id: '', v: '' }) }));
      }
      actions.push(A.btn('Open ' + x.committee, { ghost: true, onClick: go, title: 'Change it on ' + x.committee + '’s list' }));
      sp.open({ title: x.title, body: h('div', { class: 'rq-line' },
        K.facts([['What', KIND[x.kind]], ['Committee', x.committee], ['Why', WHY[x.why]], x.by ? ['Asked by', x.by] : null]), note,
        h('p', { class: 'ap-help', text: x.why === 'remove' ? 'Removing a packet part is the COA’s, on Packet · Keep leaves it in' : x.kind === 'contact' ? (A.allowed('members') ? 'Change who heads ' + x.committee + ' on Members, then Settled' : 'The COA changes who heads ' + x.committee + ', on Members · Settled once it’s done') : 'Keep as it was, or open the list to change it' })), foot: actions });
    }
    function assign(x, cur) {
      let pick = cur || '';
      const opts = (x.kind === 'request' ? [] : [['coa', 'COA', 'The COA answers for it']]).concat(boot.committees.filter(c => c.key !== 'coa').map(c => [c.key, c.name]));
      sp.open({ title: 'Assign · ' + x.title, body: h('div', { class: 'cx-rec' },
        h('p', { class: 'ap-help', text: x.kind === 'request' ? 'This request names “' + (x.committee || 'no committee') + '”, which isn’t on this year’s list · Its committee answers it' : 'The committee that answers for this ' + KIND[x.kind].toLowerCase() + ' in the intake · Carried to next year' }),
        K.field('Committee', K.pills(opts, pick, v => { pick = v; }), { tag: 'div' })),
        foot: [A.btn('Save', { primary: true, write: true, onClick: () => { if (!pick) { A.toast('A committee'); return; } sp.close(true); A.api('POST', 'round/assign', { item: x.item, c: pick }).then(nb => { b = nb; if (x.kind === 'request') { K.drop(y); K.load(y, { force: true }).then(nd => { d = nd; rows = d.rowsOf('needs').map(r => Object.assign({}, r)); draw(); }); } else draw(); A.toast('Assigned · ' + x.title); }, A.fail); } }),
          cur ? A.btn('No one', { ghost: true, write: true, onClick: () => { sp.close(true); A.api('POST', 'round/assign', { item: x.item, c: '' }).then(nb => { b = nb; draw(); A.toast('No one · ' + x.title); }, A.fail); } }) : null,
          A.btn('Cancel', { ghost: true, onClick: () => sp.close() })].filter(Boolean) });
    }
    function sendNeeds(body, said) {
      return R.needs(y, body).then(res => {
        if (Array.isArray(res.rows)) rows = res.rows.map(r => Object.assign({}, r));
        K.drop(y);
        return reload(said);
      }, err => { A.fail(err); throw err; });
    }

    /* ------------------------------------------------------------ the round's settings */
    function setup() {
      const s = b.settings;
      let sendIso = b.dates.send, dueIso = b.dates.due, remind = String(s.remind), asks = s.asks.slice(), skip = s.skip.slice(), runBy = b.run_by.key;
      const send = K.dateIn({ value: sendIso, label: 'Send date', near: b.friday, onSave: v => { sendIso = v; } });
      const due = K.dateIn({ value: dueIso, label: 'Due date', near: b.friday, onSave: v => { dueIso = v; } });
      const sf = K.field('Send date', send, { tag: 'div', help: 'Counted from the Conference’s first day · Never sends by itself' });
      const df = K.field('Due date', due, { tag: 'div', help: 'Moves with the Conference’s dates' });
      const box = h('div', { class: 'cx-rec rq-setup' },
        b.can.hand ? K.field('Run by', K.pills([['coa', 'COA']].concat(boot.committees.filter(c => c.key !== 'coa').map(c => [c.key, c.name])), runBy, v => { runBy = v; }), { tag: 'div', help: 'The committee that sends, reminds and settles · It sees every committee’s requests' }) : null,
        sent() ? null : sf, df,
        K.field('Reminder', K.pills([['0', 'Off'], ['3', '3 days before'], ['7', '7 days before'], ['14', '14 days before']], remind, v => { remind = v; }), { tag: 'div', help: 'One email to every head not returned · Goes by itself' }),
        K.field('Asks', h('div', { class: 'rq-checks' }, ASKS.map(([k, l]) => h('label', { class: 'ap-switch' }, h('input', { type: 'checkbox', class: 'ap-check', checked: asks.indexOf(k) > -1, on: { change: e => { asks = asks.filter(x => x !== k); if (e.target.checked) asks.push(k); } } }), h('span', { text: l })))), { tag: 'div' }),
        K.field('Committees', h('div', { class: 'rq-checks' }, b.committees.map(c => h('label', { class: 'ap-switch' }, h('input', { type: 'checkbox', class: 'ap-check', checked: skip.indexOf(c.key) < 0, on: { change: e => { skip = skip.filter(x => x !== c.key); if (!e.target.checked) skip.push(c.key); } } }), h('span', { text: c.name })))), { tag: 'div', help: 'Unticked: not asked this year' }));
      sp.open({ title: 'The round', body: box, foot: [A.btn('Save', { primary: true, write: true, onClick: () => {
        // A typed date is read when the box is left; read it now too.
        [send, due].forEach(w => w.input && w.input.dispatchEvent(new Event('change')));
        sendIso = sendIso || b.dates.send; dueIso = dueIso || b.dates.due;
        if (!asks.length) { A.toast('Asks · One or more'); return; }
        const body = { remind: +remind, asks, skip };
        if (!sent() && sendIso) body.send = sendIso;
        if (dueIso) body.due = dueIso;
        const handed = b.can.hand && runBy !== b.run_by.key ? A.api('POST', 'hand', { screen: 'intake', c: runBy === 'coa' ? '' : runBy }) : Promise.resolve(null);
        A.api('PATCH', 'round', body).then(nb => handed.then(hd => {
          b = nb; sp.close(true);
          if (hd) { A.toast('Run by ' + (runBy === 'coa' ? 'the COA' : (boot.committees.find(c => c.key === runBy) || {}).name)); if (A.refreshBoot) A.refreshBoot().then(() => (A.reload ? A.reload() : A.go({}, { replace: true }))); else location.reload(); return; }
          draw(); A.toast('Saved · The round');
        }), err => { if (err && err.data && err.data.field === 'due') df.setError(err.data.message); else if (err && err.data && err.data.field === 'send') sf.setError(err.data.message); else A.fail(err); });
      } }), A.btn('Cancel', { ghost: true, onClick: () => sp.close() })] });
    }

    /* ------------------------------------------------------------ export for campus, mark sent */
    function exportCampus(only) {
      const l = rows.filter(r => !r.answer).length, ns = rows.filter(r => r.answer === 'notsure').length;
      const go = () => {
        R.exportCampus(rows, d, { only, sent: sentStamp() });
        // Downloading isn't sending: it's marked sent once it's gone to the campus. The download is
        // kept, so "Mark as sent" stays on the board (the toast's button is only a shortcut).
        const shortcut = () => {
          A.toast('Downloaded');
          const t = document.querySelector('.ap-toast');
          if (t && !ro()) t.appendChild(h('button', { type: 'button', text: 'Mark as sent', on: { click: () => { t.remove(); markSent(true); } } }));
        };
        if (ro() || only) { shortcut(); return; }
        A.api('PATCH', 'round', { exported: true }).then(nb => { b = nb; draw(); shortcut(); }, () => shortcut());
      };
      if (!only && (l || ns)) {
        K.confirm(sp, { title: 'Export for campus', lines: [[l && l + ' to answer', ns && ns + ' not sure'].filter(Boolean).join(' · ') + ' · In their own sheet, Not confirmed', 'Sheets · By day and place · Totals by day · All requests'], actLabel: 'Export', act: () => Promise.resolve(go()), onDone: () => {} });
        return;
      }
      go();
    }
    function markSent(done) {
      K.coa(y, 'sent', { what: 'needs', done }).then(() => K.load(y, { force: true })).then(nd => { d = nd; draw(); A.toast(done ? 'Marked sent · ' + (d.row.venue || 'Campus') : 'Not marked sent'); }, A.fail);
    }

    draw();
    if (ctx.params.id === 'remind') { A.setParams({ id: '' }); if (!ro() && waiting().length) setTimeout(() => doRemind(''), 0); }
    if (ctx.params.id === 'send') { A.setParams({ id: '' }); if (!ro() && !sent()) setTimeout(() => doSend(''), 0); }
  }
})();
