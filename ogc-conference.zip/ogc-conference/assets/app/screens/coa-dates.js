/*
 * coa-dates.js — Dates and place: the Conference's days, its campus, its hosts, the call-in line and
 * the volunteering phone, and Announce (the Conference page opens on this year).
 *
 *   - Changing the dates says first what moves with them (registration's dates, dates written in the
 *     packet, tournaments), then Move does it (coa/{y}/dates, one transaction on the server);
 *   - changing the campus shows what it brings from the last Conference there and what it replaces,
 *     then Change (coa/{y}/campus);
 *   - the call-in line carried from last year is "From 2026 · Looks right" until someone checks it
 *     (it isn't public before that);
 *   - Announce says when it shows and what happens to last year's page.
 */
(function () {
  'use strict';
  const A = window.OGC_APP, K = window.OGC_COA, O = window.OGC, W = window.OGC_WP || {};
  if (!A || !K) return;
  const h = A.h;
  const WEEK = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  const weekday = iso => WEEK[new Date(iso + 'T12:00:00Z').getUTCDay()];

  A.screen({
    id: 'dates', title: 'Dates and place', icon: 'years', section: 'own', who: ['coa'],
    render(ctx) {
      let alive = true;
      ctx.head('Dates and place', '', []);
      K.loading(ctx.body);
      const draw = force => K.load(ctx.params.year, { force }).then(d => { if (alive) page(ctx, d, () => draw(true)); }, err => { if (alive) K.failed(ctx.body, err); });
      draw(false);
      return () => { alive = false; };
    }
  });

  function page(ctx, d, again) {
    const y = d.year, row = d.row, S = d.S;
    const ro = !!A.readonly || d.held;
    const ann = row.coa_announced || '';
    const announced = !!ann && ann <= d.today, later = !!ann && ann > d.today;
    const dated = !!row.start;
    const venue = row.venue || S.venue || '';

    /* -------------------------------------------------------- the title row */
    const acts = [K.see('?year=' + y, 'Preview')];
    if (!ro) {
      if (announced || later) {
        acts.push(h('span', { class: 'ap-tag ap-tag--ok', text: (announced ? 'Announced ' : 'Shows ') + K.mdY(ann, y) }));
        acts.push(A.btn('More', { ghost: true, iconOnly: true, icon: 'more', onClick: e => A.menu(e.currentTarget, [{ label: 'Unannounce', run: unannounce }]) }));
      } else {
        // A greyed Announce says why, in words beside it (never only in a tooltip).
        if (!dated || !venue) acts.push(h('span', { class: 'ap-quiet', text: !dated && !venue ? 'Set the dates and campus first' : !dated ? 'Set the dates first' : 'Choose the campus first' }));
        acts.push(A.btn('Announce', { primary: true, write: true, disabled: !dated || !venue, title: !dated || !venue ? 'Dates and campus first' : 'The Conference page turns to ' + y, onClick: announce }));
      }
    }
    // One month style everywhere ("May 28 – Jun 1"), as the rest of the app says dates.
    const fact = d.held ? 'Ended ' + K.md(row.end) : dated ? K.md(row.start) + ' – ' + K.md(row.end) + ', ' + String(row.end || row.start).slice(0, 4) + ' · Check-out ' + K.md(O.isoAddDays(row.end, 1)) + (venue ? ' · ' + venue : '') : 'No dates yet';
    ctx.head('Dates and place', fact, acts);

    A.clear(ctx.body);
    const sp = ctx.split();
    const doc = h('div', { class: 'cx-page cx-doc' });
    sp.main.appendChild(doc);
    // Dates and place carried from last year: "From 2026 · Looks right" until the COA has read them.
    // It ticks Home's first step, Check dates (Round 2, area-home-tasks 1.4), and nothing else.
    const look = !ro && dated ? K.looks(d, 'conf:dates', { always: true, what: 'Dates and place', line: 'Dates, campus and hosts', done: again }) : null;
    if (look) doc.appendChild(look);

    /* -------------------------------------------------------- dates */
    const start = K.dateIn({ value: row.start, label: 'Arrival (Friday)', near: row.start || (y + '-05-28'), placeholder: 'Date', onSave: v => { if (v) plan(v, row.end && row.start ? '' : ''); } });
    // One date model, shown the same everywhere: Arrival (the Friday), Last night, Check-out (the
    // morning after the last night). The schedule's days run from arrival to check-out.
    const end = K.dateIn({ value: row.end, label: 'Last night', near: row.start || (y + '-06-01'), placeholder: 'Date', onSave: v => { if (v && row.start) plan(row.start, v); else if (v) return 'Arrival first'; } });
    const out = dated && row.end ? O.isoAddDays(row.end, 1) : '';
    const nights = dated && row.end ? Math.round((Date.parse(row.end) - Date.parse(row.start)) / 864e5) + 1 : 0;
    const fs = K.field('Arrival', start, { tag: 'div', help: 'The Friday · Tasks and dates count from it' });
    const fe = K.field('Last night', end, { tag: 'div', help: out ? 'Check-out ' + weekday(out) + ' morning, ' + K.md(out) : 'Check-out is the morning after' });
    const same = !dated || !d.days.length || d.days.length === nights + 1;
    doc.appendChild(K.section('Dates', { help: dated ? weekday(row.start) + ' to ' + weekday(out) + ' morning · ' + K.plural(nights, 'night') + ' · ' + K.plural(d.days.length, 'day') + ' on the schedule' : (d.picked.from ? 'Last year’s dates move with them, once' : '') },
      h('div', { class: 'cx-two' }, fs, fe),
      same ? null : h('p', { class: 'cx-issue', text: 'The schedule has ' + K.plural(d.days.length, 'day') + ' · Arrival to check-out is ' + K.plural(nights + 1, 'day') })));
    if (ro) [start.input, end.input].forEach(i => { i.disabled = true; });

    // What moves with the dates, said first; Move does it.
    function plan(s, e) {
      if (weekday(s) !== 'Friday') {
        const back = (5 - new Date(s + 'T12:00:00Z').getUTCDay() + 7) % 7, fri = O.isoAddDays(s, back > 3 ? back - 7 : back);
        fs.setError('Not a Friday · ' + K.wd(fri) + '?');
        fs.querySelector('.ap-err').appendChild(h('span', null, ' ', K.link('Use ' + K.md(fri), () => { start.input.value = K.md(fri); start.input.dispatchEvent(new Event('change')); })));
        return;
      }
      fs.setError('');
      K.api('POST', 'coa/' + y + '/dates', { start: s, end: e || '' }).then(p => {
        const list = [p.registration && K.plural(p.registration, 'registration date'), p.packet && K.plural(p.packet, 'date') + ' in the packet', p.tournaments && K.plural(p.tournaments, 'tournament')].filter(Boolean);
        const by = p.d ? Math.abs(p.d) + (Math.abs(p.d) === 1 ? ' day ' : ' days ') + (p.d < 0 ? 'earlier' : 'later') : '';
        const lines = [K.wd(p.start) + ' – ' + K.wd(p.end) + ', ' + p.end.slice(0, 4)];
        lines.push(list.length ? 'Moves ' + list.join(', ').replace(/, ([^,]*)$/, ' and $1') + (by && row.start ? ' · ' + by : '') : 'Nothing else moves');
        Object.keys(p.reg || {}).forEach(k => lines.push({ opens: 'Registration opens', closes: 'Registration closes', refunds_by: 'Credit asked by', cancel_by: 'Cancel by' }[k] + ' · ' + K.md(p.reg[k].from) + ' → ' + K.md(p.reg[k].to) + (p.reg[k].suggest ? ' (suggested)' : '')));
        if (p.empty_days && p.empty_days.length) lines.push(p.empty_days.join(', ') + ' · No rows on the schedule');
        if (p.dropped_days && p.dropped_days.length) lines.push(p.dropped_days.join(', ') + ' · Not in the new dates · Its rows stay, to move');
        const vol = d.ov && d.ov.counts ? d.ov.counts.signups : 0;
        if (vol) lines.push(K.plural(vol, 'volunteer') + ' signed up · Their shifts move too');
        K.confirm(sp, {
          title: 'Move the Conference', lines, actLabel: list.length ? 'Move' : 'Save',
          act: () => K.api('POST', 'coa/' + y + '/dates', { start: s, end: p.end, apply: true }),
          onDone: () => { K.drop(y); A.toast('Moved · ' + O.fmtDateSpan(p.start, p.end)); A.refreshBoot && A.refreshBoot(); again(); }
        });
      }, err => fs.setError(err && err.data && err.data.message || 'Not saved'));
    }

    /* -------------------------------------------------------- campus */
    const campusFacts = K.facts([
      ['Campus', venue, ro ? null : K.link(venue ? 'Change' : 'Choose', () => chooseCampus())],
      // Each value has its act: "Add" while it's empty, "Change" once it's set.
      ['Town', row.city || S.city || '', ro ? null : K.link(row.city || S.city ? 'Change' : 'Add', editTown)],
      ['Address', S.address || '', ro ? null : K.link(S.address ? 'Change' : 'Add', () => editKey('address', 'Address', S.address || ''))],
      ['Hosts', row.hosts || S.hosts || '', ro ? null : K.link(row.hosts || S.hosts ? 'Change' : 'Add', editHosts)]
    ]);
    doc.appendChild(K.section('Place and hosts', { help: venue ? 'Buildings, halls, pins and care nearby are on Campus' : '' }, campusFacts));
    // The town: on the year (years.csv) and in its settings, the same words.
    function editTown() {
      const t = K.textIn({ value: row.city || S.city || '', label: 'Town', placeholder: 'Town, State', live: false });
      const save = A.btn('Save', { primary: true, write: true, onClick: () => {
        const v = t.value.trim();
        Promise.all([K.api('PATCH', 'years/' + y, { fields: { city: v } }), K.api('PATCH', 'years/' + y + '/files/settings', { op: 'key', key: 'city', value: v })])
          .then(() => { K.drop(y); sp.close(true); A.toast('Saved · Town'); again(); }, A.fail);
      } });
      sp.open({ title: 'Town', body: K.field('Town', t), foot: [save, A.btn('Cancel', { ghost: true, onClick: () => sp.close() })] });
      t.focus();
    }
    // The hosts: on the year (years.csv) and in its settings, the same words.
    function editHosts() {
      const t = K.textIn({ value: row.hosts || S.hosts || '', label: 'Hosts', placeholder: 'California districts', live: false });
      const save = A.btn('Save', { primary: true, write: true, onClick: () => {
        const v = t.value.trim();
        Promise.all([K.api('PATCH', 'years/' + y, { fields: { hosts: v } }), K.api('PATCH', 'years/' + y + '/files/settings', { op: 'key', key: 'hosts', value: v })])
          .then(() => { K.drop(y); sp.close(true); A.toast('Saved · Hosts'); again(); }, A.fail);
      } });
      sp.open({ title: 'Hosts', body: K.field('Hosts', t, { help: 'On the Conference page under the dates' }), foot: [save, A.btn('Cancel', { ghost: true, onClick: () => sp.close() })] });
      t.focus();
    }

    function chooseCampus() {
      K.api('GET', 'years').then(years => {
        const seen = {};
        const used = years.filter(r => r.venue && r.year !== String(y) && !seen[r.venue.toLowerCase()] && (seen[r.venue.toLowerCase()] = 1));
        let pick = '', fresh = null;
        const cards = h('div', { class: 'cx-cards', role: 'group', 'aria-label': 'Campuses' });
        const form = h('div', { class: 'cx-newcampus', hidden: true });
        const nName = K.textIn({ label: 'Name', placeholder: 'Name', live: false });
        const nCity = K.textIn({ label: 'Town', placeholder: 'Town, State', live: false });
        const nAddr = K.textIn({ label: 'Address', placeholder: 'Street, town, ZIP', live: false });
        form.append(K.field('Name', nName), K.field('Town', nCity), K.field('Address', nAddr));
        const say = h('div', { class: 'cx-decide__plan', 'aria-live': 'polite' });
        const goBtn = A.btn('Change', { primary: true, write: true, disabled: true, onClick: () => apply() });
        const mark = el => cards.querySelectorAll('.cx-card').forEach(c => c.setAttribute('aria-pressed', String(c === el)));
        used.forEach(r => cards.appendChild(h('button', { type: 'button', class: 'cx-card', 'aria-pressed': 'false', on: { click: e => { pick = r.venue; fresh = null; form.hidden = true; mark(e.currentTarget); preview(); } } },
          h('span', { class: 'cx-card__t', text: r.venue }), h('span', { class: 'cx-card__s', text: (r.city || '') + ' · Last ' + r.year }))));
        cards.appendChild(h('button', { type: 'button', class: 'cx-card', 'aria-pressed': 'false', on: { click: e => { pick = ''; fresh = {}; form.hidden = false; mark(e.currentTarget); A.clear(say); goBtn.disabled = false; nName.focus(); } } },
          h('span', { class: 'cx-card__t', text: 'New campus' }), h('span', { class: 'cx-card__s', text: 'Its buildings and halls start blank' })));
        const body = h('div', null, cards, form, say);
        const preview = () => {
          A.clear(say);
          goBtn.disabled = true;
          K.api('POST', 'coa/' + y + '/campus', pick ? { venue: pick } : { new: { name: nName.value, city: nCity.value, address: nAddr.value } }).then(pl => {
            const b = pl.brings || {}, rp = pl.replaces || {};
            const brings = [b.places && K.plural(b.places, 'place'), b.halls && K.plural(b.halls, 'hall'), b.help && K.plural(b.help, 'Help card'), b.nearby && b.nearby + ' care nearby', b.map && 'the map', b.prices && b.prices.length && 'prices', b.needs && K.plural(b.needs, 'request')].filter(Boolean);
            const goes = [rp.places && K.plural(rp.places, 'place'), rp.halls && K.plural(rp.halls, 'hall'), rp.pins && K.plural(rp.pins, 'pin'), rp.needs && K.plural(rp.needs, 'request')].filter(Boolean);
            say.append(...[
              h('p', { class: 'cx-decide__line' }, pl.from ? 'From ' + pl.from + ', the last Conference there · ' + (brings.length ? brings.join(', ') : 'Nothing kept') : 'Blank · Buildings, halls and the map start empty'),
              goes.length ? h('p', { class: 'cx-decide__line' }, 'Replaces ' + (rp.venue || 'this campus') + '’s ' + goes.join(', ') + ' · Kept, to restore') : null,
              pl.unmatched && (pl.unmatched.schedule || pl.unmatched.shifts) ? h('p', { class: 'cx-decide__line' }, K.plural(pl.unmatched.schedule, 'schedule row') + ' and ' + K.plural(pl.unmatched.shifts, 'shift') + ' name places to choose again') : null].filter(Boolean));
            goBtn.disabled = false;
          }, err => { say.appendChild(h('p', { class: 'ap-err', text: err && err.data && err.data.message || 'Not read' })); });
        };
        const apply = () => {
          goBtn.disabled = true;
          K.api('POST', 'coa/' + y + '/campus', Object.assign(pick ? { venue: pick } : { new: { name: nName.value.trim(), city: nCity.value.trim(), address: nAddr.value.trim() } }, { apply: true })).then(() => {
            sp.close(true); K.drop(y); A.toast('Changed · ' + (pick || nName.value.trim())); A.refreshBoot && A.refreshBoot(); again();
          }, err => { goBtn.disabled = false; A.fail(err); });
        };
        sp.open({ title: 'Campus', body, foot: [goBtn, A.btn('Cancel', { ghost: true, onClick: () => sp.close() })] });
      }, A.fail);
    }

    /* -------------------------------------------------------- the call-in line */
    // Its own screen since Oct 13 (night-schedule: the provider, the PIN, the rows on the line, the
    // playback numbers; handable to A/V on its own). Here, only what it is and where it's kept.
    doc.appendChild(K.section('Call-in line', { help: 'The phone line for the services · On the Conference page and the guide' },
      K.facts([['Number', S.call_in_off === 'yes' ? 'Not used this year' : S.call_in_number ? S.call_in_number + (S.call_in_pin ? ' · PIN ' + S.call_in_pin : ' · No PIN') : '', A.allowed && A.allowed('callin') ? A.link({ s: 'callin', v: '', id: '' }, 'Call-in', 'cx-link') : null]])));

    /* -------------------------------------------------------- the volunteering phone */
    // One number for all volunteering, a role's (canonical, Oct 14; docs/scope/04 "The year's
    // volunteering phone"). The volunteer page says "Volunteering · 765-555-0100" under Your week;
    // blank, it says nothing.
    doc.appendChild(K.section('Volunteering phone', { help: 'On the volunteer page · A role’s phone, never a person’s own' },
      K.facts([['Number', S.volunteer_phone || '', ro ? null : K.link(S.volunteer_phone ? 'Change' : 'Add', editVolPhone)]])));
    function editVolPhone() {
      const t = K.textIn({ value: S.volunteer_phone || '', label: 'Volunteering phone', placeholder: '765-555-0100', live: false, inputmode: 'tel' });
      t.type = 'tel';
      const f = K.field('Number', t, { help: 'Blank: none shown' });
      const save = A.btn('Save', { primary: true, write: true, onClick: () => {
        const raw = t.value.trim(), dg = raw.replace(/\D/g, '').replace(/^1(?=\d{10}$)/, '');
        if (raw && dg.length !== 10) { f.setError('Ten digits · 765-555-0100'); t.focus(); return; }
        f.setError('');
        setKey('volunteer_phone', raw ? dg.slice(0, 3) + '-' + dg.slice(3, 6) + '-' + dg.slice(6) : '', 'Volunteering phone').then(r => { if (typeof r === 'string') { f.setError(r); return; } sp.close(true); again(); });
      } });
      sp.open({ title: 'Volunteering phone', body: f, foot: [save, A.btn('Cancel', { ghost: true, onClick: () => sp.close() })] });
      t.focus();
    }

    /* -------------------------------------------------------- the side: what this screen decides */
    function setKey(key, value, label) {
      return K.api('PATCH', 'years/' + y + '/files/settings', { op: 'key', key, value }).then(() => { K.drop(y); A.toast('Saved · ' + label); }, err => { A.fail(err); return 'Not saved'; });
    }
    function editKey(key, label, value) {
      const t = K.textIn({ value, label, live: false });
      const save = A.btn('Save', { primary: true, write: true, onClick: () => setKey(key, t.value.trim(), label).then(() => { sp.close(true); again(); }) });
      sp.open({ title: label, body: K.field(label, t), foot: [save, A.btn('Cancel', { ghost: true, onClick: () => sp.close() })] });
      t.focus();
    }

    function announce() {
      const prev = d.ov && d.ov.prev;
      const ahead = prev && prev.end && prev.end >= d.today;
      K.confirm(sp, {
        title: 'Announce ' + y,
        lines: [(ahead ? 'On ' + K.md(O.isoAddDays(prev.end, 1)) + ', after the ' + prev.year + ' Conference' : 'Now') + ' · The Conference page shows ' + y + (prev ? ' · ' + prev.year + ' moves to past years' : ''),
          'Its dates, campus and hosts · Nothing else until it’s published'],
        actLabel: 'Announce',
        act: () => K.coa(y, 'publish', { part: 'conference', act: 'announce' }),
        onDone: r => { A.toast((r && r.stamp && r.stamp.shows && r.stamp.shows > d.today ? 'Shows ' + K.md(r.stamp.shows) : 'Announced') + ' · ' + y); again(); }
      });
    }
    function unannounce() {
      K.confirm(sp, {
        title: 'Unannounce ' + y, danger: true, reason: true,
        lines: ['The Conference page goes back to the year before'],
        actLabel: 'Unannounce',
        act: reason => K.coa(y, 'publish', { part: 'conference', act: 'unannounce', reason }),
        onDone: () => { A.toast('Unannounced · ' + y); again(); }
      });
    }
  }
})();
