/*
 * committee-kit.js — what the committees' screens share (app-committees area, Oct 11):
 *
 *   K.bundle(year)          the year's files, read once (GET years/{y}/bundle): { name: rows }
 *   K.kv(rows)              key/value files (settings, registration) as an object
 *   K.days(start, end)      the Conference's days: [{ date, name: 'Friday' }]
 *   K.md, K.day, K.time…    dates and times in the campus's words ("May 28", "Fri May 28", "3:42 PM")
 *   K.download(rows, name)  a spreadsheet file (UTF-8 with a byte-order mark: Excel reads it right)
 *   K.excel(path, name, as) a list's workbook from its route (?format=xlsx): the list, then Columns
 *   K.print(o)              a printout drawn for paper (its own head, dated, "Committee only"), then
 *                           the print dialog; the screen itself never prints
 *   K.find(o)               a search box that filters without drawing the page again (focus stays)
 *   K.steps(list, onPick)   "What to do": the steps in order, the next one marked, done ones ticked
 *   A.committeeWork         a committee's own screens on its page, each with where it stands
 *
 * Nothing anyone typed goes into innerHTML: every node is built with OGC_APP.h().
 */
(function () {
  'use strict';
  const A = window.OGC_APP, h = A.h, O = window.OGC || {}, W = window.OGC_WP || {};
  const K = window.OGC_CK = {};

  /* ------------------------------------------------------------ the year's files */

  const bundles = {};
  K.bundle = function (year, fresh) {
    if (!fresh && bundles[year]) return bundles[year];
    bundles[year] = W.api('GET', 'years/' + year + '/bundle').then(b => {
      const out = {};
      Object.keys(b || {}).forEach(k => { out[k] = (b[k] && b[k].rows) || []; });
      return out;
    }).catch(err => { delete bundles[year]; throw err; });
    return bundles[year];
  };
  K.kv = rows => {
    const o = {};
    (rows || []).forEach(r => { if (r.key && !/^#/.test(r.key)) o[String(r.key).trim()] = String(r.value == null ? '' : r.value).trim(); });
    return o;
  };

  /* ------------------------------------------------------------ dates and words */

  const WEEK = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  K.days = (start, end) => {
    const out = [];
    if (!start || !end || !O.isoAddDays) return out;
    for (let d = start, n = 0; d <= end && n < 14; d = O.isoAddDays(d, 1), n++) out.push({ date: d, name: WEEK[new Date(d + 'T12:00:00Z').getUTCDay()] });
    return out;
  };
  K.md = iso => iso && O.fmtDate ? O.fmtDate(String(iso).slice(0, 10), 'mdShort') : '';
  K.day = iso => iso && O.fmtDate ? O.fmtDate(String(iso).slice(0, 10), 'short').replace(',', '') : '';
  // A server time ("2026-10-10 19:53:02", UTC) at the campus: "Fri 7:53 PM".
  K.at = (utc, tz, withDay) => {
    if (!utc) return '';
    const d = new Date(String(utc).replace(' ', 'T') + (/Z|[+-]\d\d:?\d\d$/.test(utc) ? '' : 'Z'));
    if (isNaN(d)) return '';
    const o = { hour: 'numeric', minute: '2-digit', timeZone: tz || 'America/Indiana/Indianapolis' };
    if (withDay !== false) o.weekday = 'short';
    return d.toLocaleString('en-US', o).replace(',', '');
  };
  K.plural = (n, one, many) => n + ' ' + (n === 1 ? one : (many || one + 's'));
  K.signed = n => (n > 0 ? '+' : n < 0 ? '−' : '') + Math.abs(n);
  K.tel = p => String(p || '').replace(/[^\d+]/g, '');
  // A phone number as a link (the desk calls from a phone; a laptop shows it plainly).
  K.phone = p => { if (!p) return null; const a = h('a', { class: 'cm-tel', text: p }); a.setAttribute('href', 'tel:' + K.tel(p)); return a; };

  // A few marks the app's own set doesn't have (16 px strokes, as A.icon).
  const PATHS = {
    check: 'M3.5 8.5 6.5 11.5 12.5 4.5',
    print: 'M4.5 6V2.5h7V6M4.5 11.5h-2v-5h11v5h-2M4.5 9.5h7v4h-7z',
    download: 'M8 2.5v8M5 7.5l3 3 3-3M3 13h10',
    key: 'M9.5 6.5a3 3 0 1 1-.9-2.1M8.6 4.4 13.5 9.3l-1.2 1.2-1-1-1 1-1-1',
    phone: 'M4 2.5h2.5l1 3-1.5 1a7.5 7.5 0 0 0 3.5 3.5l1-1.5 3 1V12a1.5 1.5 0 0 1-1.5 1.5A10 10 0 0 1 2.5 4 1.5 1.5 0 0 1 4 2.5Z',
    grip: 'M6 4h.01M10 4h.01M6 8h.01M10 8h.01M6 12h.01M10 12h.01',
    undo: 'M5.5 4 2.5 7l3 3M3 7h6.5a3.5 3.5 0 0 1 0 7H8',
    send: 'M2.5 8 13.5 2.5 10 13.5 7.5 9 2.5 8ZM7.5 9l6-6.5',
    star: 'M8 2.5l1.6 3.4 3.7.4-2.8 2.5.8 3.7L8 10.7l-3.3 1.8.8-3.7L2.7 6.3l3.7-.4z',
    minus: 'M3 8h10'
  };
  // A button with only a mark (its name for screen readers and the tooltip).
  K.iconBtn = (label, name, onClick, o) => {
    const b = A.btn(label, Object.assign({ iconOnly: true, icon: 'plus', onClick }, o || {}));
    const svg = b.querySelector('svg');
    if (svg) svg.replaceWith(K.icon(name));
    b.title = label;
    return b;
  };
  // The app's own buttons may use these marks too (Download, Print).
  if (A.addIcons) A.addIcons({ download: PATHS.download, print: PATHS.print });
  K.icon = (name, size) => {
    if (!PATHS[name]) return A.icon(name, size);
    const svg = A.icon('overview', size);
    svg.querySelector('path').setAttribute('d', PATHS[name]);
    return svg;
  };

  /* ------------------------------------------------------------ files */

  K.download = (rows, name) => {
    const SU = O.signups;
    const text = '﻿' + (SU && SU.csv ? SU.csv(rows) : rows.map(r => r.join(',')).join('\n'));
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([text], { type: 'text/csv;charset=utf-8' }));
    a.download = String(name).replace(/[\\/:*?"<>|]+/g, ' ');
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 2000);
  };
  // A file a route makes (a list for Excel): fetched with the nonce, saved under its own name. W.rest
  // already ends in "ogc/v1/", so a path given as "ogc/v1/lists/…" (every caller's) or "/lists/…" is
  // trimmed to the route (critique: the doubled prefix made every Download a 404).
  K.restUrl = path => {
    const base = W.rest || '/wp-json/ogc/v1/';
    let rel = String(path || '').replace(/^\/+/, '').replace(/^ogc\/v1\//, '');
    if (base.includes('?')) rel = rel.replace('?', '&'); // plain addresses: ?rest_route=/ogc/v1/…
    const url = base + rel;
    return url + (url.includes('?') ? '&' : '?') + '_wpnonce=' + encodeURIComponent(W.nonce || '');
  };
  K.fetchFile = (path, name) => fetch(K.restUrl(path), { credentials: 'same-origin', headers: { 'X-WP-Nonce': W.nonce || '' } })
    .then(r => { if (!r.ok) throw Object.assign(new Error('Not downloaded'), { status: r.status }); return r.blob(); })
    .then(b => { const a = document.createElement('a'); a.href = URL.createObjectURL(b); a.download = name; document.body.appendChild(a); a.click(); a.remove(); });
  // A list for Excel (lists area): the route's ?format=xlsx, a workbook with the list and a Columns
  // sheet (what each column holds). name: "2027 Meal counts" (the year, then the same words every year).
  // A date previewed in the address (?as-of=) gives the same list the screen shows.
  K.excel = (path, name, as) => K.fetchFile(path + (path.includes('?') ? '&' : '?') + 'format=xlsx' + (as ? '&as=' + encodeURIComponent(as) : '') + (new URLSearchParams(location.search).get('as-of') ? '&as_of=' + encodeURIComponent(new URLSearchParams(location.search).get('as-of')) : ''), String(name).replace(/[\\/:*?"<>|]+/g, ' ') + '.xlsx')
    .then(() => A.toast('Downloaded · ' + String(name).replace(/^\d{4} /, ''))).catch(() => A.toast('Not downloaded'));

  /*
   * A printout: o = { title, sub, who ('Lodging only'), landscape, build: () => node }. Drawn into its
   * own block for paper (the screen's table never prints: polish, the phone layout printed 10 pages).
   */
  K.print = function (o) {
    document.querySelectorAll('.cm-print, #cm-page-style').forEach(x => x.remove());
    const b = A.boot && A.boot();
    const conf = b ? b.year + ' Annual Conference' : '';
    // o.tz: the campus's clock (the lists pass it), so "Printed" and "As of" agree on one sheet.
    let now;
    try { now = new Date().toLocaleString('en-US', Object.assign({ month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' }, o.tz ? { timeZone: o.tz } : {})); }
    catch (e) { now = new Date().toLocaleString('en-US', { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' }); }
    const block = h('div', { class: 'cm-print' + (o.landscape ? ' cm-print--wide' : '') },
      h('header', { class: 'cm-print__head' }, h('strong', { text: [conf, o.title].filter(Boolean).join(' · ') }),
        h('span', { text: ['Printed ' + now, o.sub, o.who].filter(Boolean).join(' · ') })),
      o.build());
    const st = h('style', { id: 'cm-page-style' });
    st.textContent = '@page { size: ' + (o.landscape ? 'letter landscape' : 'letter portrait') + '; margin: 0.45in; }';
    document.head.appendChild(st);
    document.body.appendChild(block);
    document.documentElement.classList.add('cm-printing');
    const done = () => { document.documentElement.classList.remove('cm-printing'); block.remove(); st.remove(); window.removeEventListener('afterprint', done); };
    window.addEventListener('afterprint', done);
    setTimeout(() => window.print(), 30);
  };

  /* ------------------------------------------------------------ small parts */

  // A search box that filters as you type without drawing the page again (focus and caret stay).
  K.find = o => {
    const input = h('input', { class: 'ap-input cm-find__in', type: 'search', placeholder: o.placeholder || 'Search', 'aria-label': o.label || 'Search', value: o.value || '', autocomplete: 'off', title: o.title || null });
    input.addEventListener('input', () => o.onInput(input.value));
    input.addEventListener('keydown', e => { if (e.key === 'Escape' && input.value) { e.stopPropagation(); input.value = ''; o.onInput(''); } });
    return h('label', { class: 'cm-find' }, A.icon('search', 15), input);
  };

  // "What to do": [{ id, t, done, note, tip, run }]. The next step is marked; a tap does it.
  K.steps = list => {
    // An optional step is never the one marked next (the filled button's step is).
    const next = list.find(s => !s.done && !s.optional);
    return h('ol', { class: 'cm-steps', 'aria-label': 'What to do' }, list.map((s, i) => h('li', { class: s.done ? 'is-done' : s === next ? 'is-next' : '' },
      h('button', { type: 'button', title: s.tip || null, on: { click: () => s.run && s.run() } },
        h('span', { class: 'cm-steps__n', 'aria-hidden': 'true' }, s.done ? K.icon('check', 12) : String(i + 1)),
        h('span', { class: 'cm-steps__t' }, h('b', { text: s.t }), s.note ? h('small', { text: s.note }) : null),
        h('span', { class: 'ap-sr', text: s.done ? ' · Done' : s === next ? ' · Next' : '' })))));
  };

  // A row of facts ("85 of 89 assigned · Rooms 115 of 144"): parts joined by " · ".
  K.facts = parts => parts.filter(Boolean).join(' · ');
  // One empty state for every list the registrations feed (Meal counts, Communing, Children,
  // Households): said once, no table, no Export or Send until there's a row. head: the lists' head.
  K.noRegs = function (ctx, title, head) {
    const opens = head && head.opens && head.today && head.opens > head.today ? 'Opens ' + K.md(head.opens) : '';
    ctx.head(title, '', []);
    A.clear(ctx.body).appendChild(A.empty({ title: 'No registrations yet', line: opens || 'The lists come from the registrations', inset: true }));
  };

  // A labelled number for the top of a list ("54  To place").
  K.stats = list => h('div', { class: 'cm-stats' }, list.filter(Boolean).map(s => h('button', {
    type: 'button', class: 'cm-stat' + (s.on ? ' is-on' : '') + (s.tone ? ' cm-stat--' + s.tone : ''), 'aria-pressed': s.on != null ? String(!!s.on) : null, disabled: !s.run, title: s.tip || null,
    on: { click: () => s.run && s.run() }
  }, h('b', { text: String(s.n) }), h('span', { text: s.label }))));

  // A menu button ("Export ▾"): items [{ label, run }].
  K.more = (label, items, o) => {
    const b = A.btn(label, Object.assign({ icon: o && o.icon, ghost: !!(o && o.ghost) }, {}));
    b.setAttribute('aria-haspopup', 'menu');
    b.appendChild(A.icon('down', 14));
    b.addEventListener('click', () => A.menu(b, items.filter(Boolean)));
    return b;
  };

  // Tabs for a screen's parts (Desk · Room setup · Counts): its own look, apart from the filter chips.
  K.seg = (opts, cur, onPick, label) => h('div', { class: 'cm-seg', role: 'tablist', 'aria-label': label || null }, opts.map(o => h('button', {
    type: 'button', role: 'tab', 'aria-selected': String(o[0] === cur), on: { click: () => onPick(o[0]) }
  }, o[1])));

  // A pill row (choices, never a dropdown). opts: [[value, label]]
  K.pills = (opts, cur, onPick, label) => h('div', { class: 'ap-pills', role: 'group', 'aria-label': label || null }, opts.map(o => h('button', {
    type: 'button', class: 'ap-pill', 'aria-pressed': String(o[0] === cur), on: { click: () => onPick(o[0]) }
  }, o[1])));

  // Something every screen says when the data didn't come: one card, with Retry.
  K.failed = (ctx, err) => {
    A.clear(ctx.body).appendChild(A.empty({
      title: err && err.status === 403 ? (err.data && err.data.message) || 'Not your committee’s' : 'Not loaded',
      line: err && err.status === 403 ? '' : 'Check the connection',
      action: err && err.status === 403 ? null : A.btn('Retry', { onClick: () => (A.reload ? A.reload() : location.reload()) }), inset: true
    }));
  };
  K.loading = ctx => { A.clear(ctx.body).appendChild(h('div', { class: 'ap-quiet cm-loading', role: 'status', text: 'Loading' })); };

  /* ------------------------------------------------------------ a committee's page: its screens */

  A.committeeWork = function (ctx, c, key) {
    const sec = h('section', { class: 'ap-section cm-work', 'aria-labelledby': 'cm-h-work' });
    ctx.api('GET', 'work?c=' + encodeURIComponent(key)).then(r => {
      if (!r.screens.length) { sec.remove(); return; }
      sec.append(h('h2', { class: 'ap-h2', id: 'cm-h-work', text: 'Work' }),
        // Import is an act on Households ("Import from the Form"), not work of its own.
        h('ul', { class: 'cm-work__list' }, r.screens.filter(s => s.id !== 'lod-import').map(s => h('li', null, A.link({ s: s.id, c: s.id === 'helpers' ? key : '', id: '', v: '', past: '', team: ctx.boot.viewer.coa ? '' : key }, [
          A.icon(A.iconFor ? A.iconFor(s.id) : ((A.screens()[s.id] || {}).icon || 'overview')), h('span', { class: 'cm-work__t', text: s.title }), h('span', { class: 'cm-work__l', text: s.line || '' }), A.icon('chev', 14)
        ], 'cm-work__a')))));
    }).catch(() => sec.remove());
    return sec;
  };
})();
