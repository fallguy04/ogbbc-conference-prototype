/*
 * Lodging › Import (app-committees, Oct 11): the Google Form's responses onto the board (docs/20's
 * middle path), in three steps: File › Columns › Check. Moved into the app from the lodging area's
 * Import, with its critique's fixes:
 *   - Lodging's choice for several responses from one email (Combine · Keep newest · Keep both) is
 *     remembered by the server and offered again on the next upload;
 *   - To check lists only new and changed responses, and each household keeps what didn't read (Rooms ›
 *     Review: "From the Form");
 *   - an unchanged file says Up to date, not a disabled "Import · 0";
 *   - Undo import is the server's (fixed: it marked a stray row, so it could be undone twice).
 * The file is read on the server and never kept; only the mapped answers become households.
 */
(function () {
  'use strict';
  const A = window.OGC_APP, h = A.h, K = window.OGC_CK, O = window.OGC, L = O.lodging, S = L.S, SU = L.SU, W = window.OGC_WP || {};
  const plural = SU.plural;
  const M = { step: 'file', text: '', name: '', cols: [], fields: [], mapping: {}, state: {}, check: null, choices: {}, remove: {}, busy: '', err: '' };
  const STATES = { matched: ['Matched', 'ok'], check: ['Check', 'warn'], unused: ['Not used', ''] };
  let C = null;
  const redraw = () => { if (C) draw(C); };

  function stepper() {
    const steps = [['file', 'File'], ['columns', 'Columns'], ['check', 'Check']], at = steps.findIndex(x => x[0] === M.step);
    return h('ol', { class: 'cm-steps cm-steps--small', 'aria-label': 'Steps' }, steps.map((s, i) => h('li', { class: i < at ? 'is-done' : i === at ? 'is-next' : '' },
      h('button', { type: 'button', disabled: i > at, 'aria-current': i === at ? 'step' : null, on: { click: () => { if (i < at) { if (s[0] === 'columns') M.folded = false; M.step = s[0]; redraw(); } } } },
        h('span', { class: 'cm-steps__n', 'aria-hidden': 'true' }, i < at ? K.icon('check', 12) : String(i + 1)), h('span', { class: 'cm-steps__t' }, h('b', { text: s[1] }))))));
  }

  function fileStep() {
    const last = S.imported, input = h('input', { type: 'file', accept: '.csv,text/csv,.tsv,.txt,.xlsx,.xls', hidden: true });
    input.addEventListener('change', () => readFile(input.files && input.files[0]));
    const drop = h('div', { class: 'ap-drop cm-impdrop' }, h('strong', { text: window.matchMedia('(pointer: coarse)').matches ? 'Choose the responses file' : 'Drop the responses file' }),
      h('span', { class: 'ap-help', text: 'CSV · Google Sheets › File › Download › Comma-separated values' }),
      h('div', { class: 'ap-row', style: { justifyContent: 'center', marginTop: '10px' } }, A.btn('Choose file', { primary: true, icon: 'upload', write: true, onClick: () => input.click() }),
        W.dev ? h('button', { type: 'button', class: 'ogc-mock', title: 'Local only: a made-up 2026-style export', text: 'Mockup: sample file', on: { click: () => L.api('GET', '/sample').then(r => { M.text = r.text; M.name = r.name; readColumns(); }, e => { M.err = (e.data && e.data.message) || 'No sample'; redraw(); }) } }) : null),
      input);
    ['dragenter', 'dragover'].forEach(ev => drop.addEventListener(ev, e => { e.preventDefault(); drop.classList.add('ap-drop--over'); }));
    ['dragleave', 'drop'].forEach(ev => drop.addEventListener(ev, () => drop.classList.remove('ap-drop--over')));
    drop.addEventListener('drop', e => { e.preventDefault(); readFile(e.dataTransfer.files[0]); });
    return h('div', null, drop, M.err ? h('p', { class: 'ap-err', role: 'alert', text: M.err }) : null,
      last ? h('p', { class: 'ap-quiet', text: K.facts(['Last import ' + L.when(last.at), last.by, plural((last.summary || {}).rows || 0, 'row'), (last.summary || {}).created ? last.summary.created + ' added' : '', last.undone ? 'Undone' : '']) }) : null,
      last && !last.undone ? h('p', null, A.btn('Undo import', { ghost: true, write: true, onClick: () => undoImport(last.id) })) : null);
  }

  function columnsStep() {
    const byId = {};
    M.fields.forEach(f => { byId[f.id] = f; });
    const dl = h('datalist', { id: 'cm-fields' }, M.fields.map(f => h('option', { value: f.label })), h('option', { value: 'Not used' }));
    const used = M.cols.filter(c => M.mapping[c.i]), unused = M.cols.filter(c => !M.mapping[c.i]);
    return h('div', null, dl,
      h('p', { class: 'cm-detail__m' }, h('b', { text: M.name }), ' · ' + K.facts([plural(M.rows, 'response'), plural(M.cols.length, 'column'), M.saved ? 'Columns as last time' : ''])),
      h('div', { class: 'cm-scroll' }, h('table', { class: 'cm-table cm-map' }, h('thead', null, h('tr', null, h('th', { text: 'Column in the file' }), h('th', { text: 'Fills' }), h('th', null, h('span', { class: 'ap-sr', text: 'Match' })))),
        h('tbody', null, M.cols.map(c => {
          const f = byId[M.mapping[c.i]], st = M.state[c.i] || (f ? 'matched' : 'unused');
          const input = h('input', { class: 'ap-input', list: 'cm-fields', value: f ? f.label : '', placeholder: 'Not used', autocomplete: 'off', 'aria-label': 'What “' + (c.h || '') + '” fills', title: f ? f.help : null });
          input.addEventListener('change', () => {
            const v = input.value.trim().toLowerCase(), ff = M.fields.find(y => y.label.toLowerCase() === v);
            if (!v || v === 'not used') { M.mapping[c.i] = ''; M.state[c.i] = 'unused'; }
            else if (ff) {
              if (!ff.multi) Object.keys(M.mapping).forEach(k => { if (+k !== c.i && M.mapping[k] === ff.id) { M.mapping[k] = ''; M.state[k] = 'unused'; } });
              M.mapping[c.i] = ff.id; M.state[c.i] = 'matched';
            }
            redraw();
          });
          return h('tr', null, h('td', null, h('b', { text: c.h || '(no heading)' }), h('span', { class: 'cm-sub2 cm-ex', text: c.ex.length ? c.ex.join(' · ') : 'Blank in every response' })),
            h('td', null, input), h('td', null, h('span', { class: 'cm-chip cm-chip--' + STATES[st][1], text: STATES[st][0] })));
        })))),
      unused.length ? h('p', { class: 'ap-help', title: 'These answers aren’t saved', text: 'Not imported · ' + unused.map(c => c.h).filter(Boolean).join(' · ') }) : null,
      h('div', { class: 'ap-row cm-panel__btns' }, A.btn('Next', { primary: true, disabled: !used.length, onClick: readCheck }), A.btn('Back', { ghost: true, onClick: () => { M.step = 'file'; redraw(); } })));
  }

  function checkStep() {
    const C2 = M.check, s = C2.summary, again = s.changed + s.same + s.missing > 0;
    // Each problem once per household (polish: "Blank · imported as all nights" three times for one family).
    const seenP = {};
    C2.problems = C2.problems.filter(x => { const k = (x.label || '') + '|' + x.col + '|' + x.reason; if (seenP[k]) return false; seenP[k] = 1; return true; });
    const n = s.new + s.changed + Object.keys(M.remove).filter(k => M.remove[k]).length;
    const used = M.cols.filter(c => M.mapping[c.i]).length;
    const rowLine = (r, first) => h('li', null, h('span', { class: 'ap-quiet', text: 'Line ' + r.line + ' · ' }),
      [['when', r.when || r.at], ['names', r.names], ['stay', r.type === 'dorm' ? plural(r.rooms || 1, 'room') : r.type === 'camper' ? 'Camper lot' : 'Off campus'], ['nights', r.nights || 'Nights blank']].filter(x => x[1]).map((x, i) => [i ? ' · ' : '', h('span', { class: first && x[0] !== 'when' && first[x[0]] !== r[x[0]] ? 'cm-diff' : '', text: x[1] })]));
    return h('div', null,
      h('p', { class: 'cm-detail__m' }, h('b', { text: M.name }), ' · ' + K.facts([plural(s.rows, 'row'), plural(s.households, 'household'), s.merged ? s.merged + ' merged' : '', s.check ? s.check + ' to check' : ''])),
      again ? h('p', { class: 'ap-quiet', text: K.facts([s.new + ' new', s.changed + ' changed', s.same + ' unchanged', s.missing ? s.missing + ' not in this file' : '']) }) : null,
      M.folded ? h('p', { class: 'ap-quiet' }, 'Columns · ' + used + ' matched · ' + (M.cols.length - used) + ' not used · ', h('button', { type: 'button', class: 'ap-link', text: 'Change', on: { click: () => { M.folded = false; M.step = 'columns'; redraw(); } } })) : null,
      C2.groups.length ? h('section', { class: 'cm-impsec' }, h('h2', { class: 'ap-h2' }, 'Several responses', h('span', { class: 'ap-h2__n', text: String(C2.groups.length) })),
        h('ul', { class: 'cm-plain' }, C2.groups.map(g => h('li', { class: 'cm-impgroup' },
          h('p', null, h('b', { text: g.label }), h('span', { class: 'ap-quiet', text: ' · ' + plural(g.n, 'response') + (g.suggest !== 'one' ? ' · ' + (g.suggest === 'newest' ? 'Same people · likely a change' : 'Different people · likely more rooms') : '') })),
          h('ul', { class: 'cm-plain cm-small' }, g.rows.map((r, i) => rowLine(r, i ? g.rows[0] : null))),
          K.pills([['combine', 'Combine'], ['newest', 'Keep newest'], ['both', 'Keep both']], g.choice, v => { M.choices[g.gid] = v; readCheck(); }, g.label))))) : null,
      C2.problems.length ? h('section', { class: 'cm-impsec' }, h('h2', { class: 'ap-h2' }, 'To check', h('span', { class: 'ap-h2__n', text: String(C2.problems.length) })),
        h('p', { class: 'ap-help', text: 'Imported as each line says · Shown again in Rooms › Review' }),
        h('ul', { class: 'cm-plain' }, C2.problems.map(p => h('li', { class: 'cm-impprob' }, h('span', { class: 'ap-quiet', text: 'Line ' + p.line }), h('span', null, h('b', { text: p.label || '' }), h('small', { class: 'cm-sub2', text: p.col + (p.cell ? ' · “' + p.cell + '”' : '') }), h('small', { class: 'cm-sub2', text: p.reason })))))) : null,
      C2.changes.length ? h('section', { class: 'cm-impsec' }, h('h2', { class: 'ap-h2' }, 'Changed', h('span', { class: 'ap-h2__n', text: String(C2.changes.length) })),
        h('ul', { class: 'cm-plain' }, C2.changes.map(c => h('li', null, h('b', { text: c.label }), h('small', { class: 'cm-sub2', text: c.what.join(' · ') }))))) : null,
      C2.missing.length ? h('section', { class: 'cm-impsec' }, h('h2', { class: 'ap-h2' }, 'Not in this file', h('span', { class: 'ap-h2__n', text: String(C2.missing.length) })),
        h('p', { class: 'ap-help', text: 'Kept unless Remove is ticked' }),
        h('ul', { class: 'cm-plain' }, C2.missing.map(m => h('li', { class: 'ap-row' }, h('span', { style: { flex: '1' } }, h('b', { text: m.label }), ' · ' + m.rid),
          h('label', { class: 'ap-switch' }, h('input', { type: 'checkbox', checked: !!M.remove[m.rid], on: { change: e => { M.remove[m.rid] = e.target.checked; redraw(); } } }), 'Remove'))))) : null,
      C2.new.length ? h('details', { class: 'cm-fold' }, h('summary', { text: 'New · ' + C2.new.length }), h('ul', { class: 'cm-plain cm-small' }, C2.new.map(x => h('li', { text: 'Line ' + x.line + ' · ' + x.label })))) : null,
      h('div', { class: 'ap-row cm-panel__btns' },
        n ? A.btn(again ? 'Import · ' + n : 'Import ' + plural(s.new, 'household'), { primary: true, write: true, onClick: apply }) : h('span', { class: 'cm-chip cm-chip--ok', text: 'Up to date' }),
        A.btn('Back', { ghost: true, onClick: () => { M.step = M.folded ? 'file' : 'columns'; redraw(); } })));
  }

  /* ================================================================ the server */

  function call(step, extra) {
    M.busy = step === 'apply' ? 'Importing' : 'Reading'; M.err = ''; redraw();
    return L.api('POST', '/import', Object.assign({ step, text: M.text, name: M.name }, extra || {})).then(res => { M.busy = ''; return res; }, err => { M.busy = ''; M.err = (err.data && err.data.message) || 'Couldn’t read'; redraw(); throw err; });
  }
  function readColumns() {
    return call('columns').then(res => {
      Object.assign(M, { step: 'columns', rows: res.rows, cols: res.cols, fields: res.fields, saved: res.saved, mapping: {}, state: {}, check: null, choices: {}, remove: {} });
      res.cols.forEach(c => { M.mapping[c.i] = c.field; M.state[c.i] = c.state; });
      M.folded = !!res.saved && !res.cols.some(c => c.state === 'check');
      if (M.folded) return readCheck();
      redraw();
    }, () => { M.step = 'file'; redraw(); });
  }
  function readCheck() {
    return call('check', { mapping: M.mapping, choices: M.choices }).then(res => { M.step = 'check'; M.check = res; redraw(); }, () => { M.step = 'columns'; M.folded = false; redraw(); });
  }
  function apply() {
    const remove = Object.keys(M.remove).filter(k => M.remove[k]);
    return call('apply', { mapping: M.mapping, choices: M.choices, remove }).then(res => {
      const s = res.summary;
      Object.assign(M, { step: 'file', text: '', check: null });
      L.reloadHouseholds().then(() => {
        A.toast(['Imported', s.created ? s.created + ' new' : '', s.updated ? s.updated + ' changed' : '', s.removed ? s.removed + ' removed' : ''].filter(Boolean).join(' · '), { undo: () => undoImport(res.id) });
        A.go({ s: 'lod-rooms', id: '' });
      });
    }, () => { M.step = 'check'; redraw(); });
  }
  function undoImport(id) {
    L.api('POST', '/import/undo', { id }).then(() => L.reloadHouseholds().then(() => { A.toast('Import undone'); redraw(); }), err => A.toast((err.data && err.data.message) || 'Can’t undo'));
  }
  function readFile(file) {
    if (!file) return;
    M.err = '';
    if (L.blocked()) { A.toast(L.blocked()); return; }
    if (file.size > 3 * 1024 * 1024) { M.err = 'File too large'; redraw(); return; }
    file.arrayBuffer().then(buf => {
      const b = new Uint8Array(buf);
      if (b[0] === 0x50 && b[1] === 0x4b) { M.err = 'Excel file · Save as CSV (File › Save As › CSV) and choose it again'; M.step = 'file'; redraw(); return; }
      let text;
      try { text = new TextDecoder('utf-8', { fatal: true }).decode(b); } catch (e) { text = new TextDecoder('windows-1252').decode(b); }
      M.text = text; M.name = file.name || 'responses.csv';
      readColumns();
    });
  }

  function draw(ctx) {
    A.clear(ctx.body);
    const forms = S.hh.filter(x => x.source === 'form').length;
    ctx.head('Import', forms ? plural(forms, 'household') + ' from the Form' : 'From the Google Form', []);
    if (L.ro) { ctx.body.appendChild(A.empty({ title: 'Conference over', line: 'No imports', inset: true })); return; }
    if (A.readonly) { ctx.body.appendChild(A.empty({ title: 'Read only while seeing as', inset: true })); return; }
    ctx.body.appendChild(h('div', { class: 'cm-imp' }, stepper(),
      M.busy ? h('p', { class: 'ap-quiet', role: 'status', text: M.busy }) : M.step === 'columns' ? columnsStep() : M.step === 'check' && M.check ? checkStep() : fileStep()));
  }

  A.screen({
    id: 'lod-import', title: 'Import', icon: 'upload', section: 'own', who: ['lodging'],
    render(ctx) { C = ctx; const off = L.screen(ctx, (c, why) => { if (why !== 'local' && why !== 'remote') draw(ctx); else if (!C.body.querySelector('input:focus')) draw(ctx); }); return () => { C = null; off(); }; }
  });
})();
