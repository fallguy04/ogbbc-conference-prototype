/*
 * coa-schedule.js — Schedule: the year's rows, a day at a time, with the chosen row beside the list.
 *
 * Mechanical (docs/25 rule 4, night-schedule Oct 13): every row has a day, an exact start and end in
 * 5-minute steps, a title, a kind from a fixed list, who it's for, a place from the campus's list, and
 * whether it's on the call-in line. Rows always sort by their start.
 *   - The add line takes one strict format ("7–9:45 PM Hymn sing, Chapel Auditorium, Singing") and says
 *     back every field it filled before Enter adds it; a time without AM or PM is read by one fixed rule,
 *     said "Read as", with the other half one tap away (coa-schedule-read.js).
 *   - Rows carried with words for a time ("After Communion") or no end are flagged "Set exact time";
 *     only noon and midnight count as times by themselves. Nothing else is guessed: the old words stay
 *     until a person types a time (and can keep them in the note with one tap).
 *   - The kind is chosen, never read from the title; how a row is listed follows its kind.
 *   - Tick rows for one change to all of them (Kind, For, Where, Day, Call-in, Looks right, Remove).
 *   - File: Paste rows and Import read the same strict way and show everything before it changes; an
 *     import with the Export's ID column is matched by ID only. Export gives Excel or CSV with the same
 *     columns every year (A/V's layout file's columns first).
 *   - Once public, changes wait for Publish ("3 unpublished · Publish"), except the call-in ticks, which
 *     go public when saved (they're the Call-in screen's too: coa-callin.js).
 */
(function () {
  'use strict';
  const A = window.OGC_APP, K = window.OGC_COA, ED = window.ED, S = window.OGC_SCHED, W = window.OGC_WP || {};
  if (!A || !K || !ED || !S) return;
  const h = A.h;
  const lc = s => String(s == null ? '' : s).trim().toLowerCase();
  const AUD = [['All', 'Everyone'], ['Conference', 'Conference'], ['Preteens', 'Preteens'], ['Youngfolks', 'Youngfolks']];
  const audOf = a => (AUD.find(x => lc(x[0]) === lc(a) || (lc(a) === 'everyone' && x[0] === 'All')) || AUD[1])[0];
  const audLabel = a => (AUD.find(x => x[0] === audOf(a)) || AUD[1])[1];
  // Kinds that share a room with anything (a desk, open hours, a meal line): never a room clash.
  const SHARES = /^(open|desk|meal|prayer|quiet|checkin)$/;
  const LONG = 210; // 3½ hours and more: a row that runs (a bar in Day view; never a room clash)
  if (A.addIcons) A.addIcons({ phone: 'M5.2 2.5h-1.7A1 1 0 0 0 2.5 3.6C2.9 9 7 13.1 12.4 13.5a1 1 0 0 0 1.1-1v-1.7l-2.6-1-1.3 1.3A7.5 7.5 0 0 1 5.9 6.9l1.3-1.3z', square: 'M3 3h10v10H3z' });

  /* ------------------------------------------------------------ reading a row */

  const mins = v => S.minutes(v);
  const exact = r => S.exact(r);
  const lenOf = r => { const a = mins(r.start), b = mins(r.end); return a == null || b == null ? 0 : (b > a ? b - a : b + 1440 - a); };
  // Rows without an exact start come first in their day, where they're seen.
  const sortKey = r => { const a = mins(r.start); return a == null ? -1 : a; };
  const timeText = r => S.when(r);
  const kindOf = r => S.kindKey(r.kind);
  const isDay = (days, v) => days.some(x => lc(x.name) === v);

  /* ------------------------------------------------------------ the screen */

  A.screen({
    id: 'schedule', title: 'Schedule', icon: 'clock', section: 'own', who: ['coa'],
    render(ctx) {
      const y = ctx.params.year, offs = [];
      let alive = true;
      ctx.head('Schedule', '', []);
      K.loading(ctx.body);
      K.load(y).then(d => {
        const f = K.rows(y, 'schedule', d);
        const prevY = d.ov && d.ov.prev ? d.ov.prev.year : '';
        return Promise.all([f.ready, prevY ? K.bundle(prevY) : null, liveOf()]).then(([, pd, lv]) => ({ d, f, pd, lv }));
      }).then(st => { if (alive) draw(ctx, st, offs); }, err => { if (alive) K.failed(ctx.body, err); });
      return () => { alive = false; offs.forEach(fn => fn()); };
    }
  });
  const liveOf = () => A.api('GET', 'live?f=schedule').then(r => r.schedule).catch(() => null);

  // Every member of the year may take the whole schedule to Excel (the same rows they can already
  // read), whoever holds the Schedule screen: here (⌘K), on Call-in's Download, and in File below.
  const exportAll = fmt => { const y = A.params().year; return fetchFile('app/' + y + '/schedule/export?format=' + fmt, y + ' Conference schedule.' + fmt).then(() => A.toast('Exported · Schedule'), () => A.toast('Not exported')); };
  A.exportSchedule = exportAll;
  A.action({ id: 'export-schedule', title: 'Export schedule · Excel', when: b => !!(b && b.viewer), run: () => exportAll('xlsx') });

  // A file from the app's own routes, saved by the browser ("2027 Conference schedule.xlsx").
  function fetchFile(path, name) {
    const q = new URLSearchParams(location.search);
    const as = q.get('as') ? '&as=' + encodeURIComponent(q.get('as')) : '';
    return fetch((W.rest || '/wp-json/ogc/v1/') + path + as, { credentials: 'same-origin', headers: { 'X-WP-Nonce': W.nonce || '' } })
      .then(r => { if (!r.ok) throw Object.assign(new Error('Not downloaded'), { status: r.status }); return r.blob(); })
      .then(b => { const a = h('a', { href: URL.createObjectURL(b) }); a.download = name; document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 4000); });
  }

  function draw(ctx, st, offs) {
    const { d, f } = st;
    const y = d.year, p = ctx.params;
    const ro = !!(A.readonly || f.opts.readOnly);
    const days = d.days.length ? d.days : Array.from(new Set(f.rows.map(r => r.day).filter(Boolean))).map(name => ({ name, date: '' }));
    const prevRows = st.pd ? ((st.pd.schedule || {}).rows || []) : [];
    let lv = st.lv;
    const VIEWS = ['time', 'kind', 'check', 'live', 'all'];
    let view = lc(p.v) || '';
    if (!view || !(isDay(days, view) || VIEWS.indexOf(view) > -1)) view = days[0] ? lc(days[0].name) : 'all';
    let layout = p.at === 'grid' ? 'grid' : 'table';
    let sel = p.id || '';
    let find = '';
    let only = { aud: '', kind: '' };
    const ticked = new Set();
    const places = () => d.rowsOf('places').filter(x => x.code).map(x => ({ code: x.code, name: x.name || x.code, building: x.building || '' }));
    const placeOf = code => { const c = lc(code); return c ? places().find(x => lc(x.code) === c) || null : null; };
    const dayName = v => (days.find(x => lc(x.name) === lc(v)) || {}).name || '';
    const dayShort = v => { const x = days.find(z => lc(z.name) === lc(v)); return x ? (x.date ? K.wd(x.date) : x.name) : v || 'No day'; };
    const rctx = day => ({ days, places: places(), day: day || dayName(view) || (days[0] || {}).name });
    A.clear(ctx.body);
    const sp = ctx.split();
    sp.el.classList.add('cx-split');
    const status = K.status([f], offs);

    /* ---------------------------------------------------------- what doesn't add up */

    function clashable(x) {
      if (!exact(x) || /^(all day|desk|nightly|private)$/.test(x.display || '')) return false;
      return !SHARES.test(kindOf(x)) && lenOf(x) < LONG;
    }
    function clashWith(r) {
      if (!r.place || !clashable(r)) return null;
      const a = mins(r.start), b = a + lenOf(r);
      return f.rows.find(x => x !== r && x._id !== r._id && x.day === r.day && lc(x.place) === lc(r.place) && clashable(x) && mins(x.start) < b && mins(x.start) + lenOf(x) > a) || null;
    }
    // [{ text, k (the field), tone: 'bad' | 'soft', tag }]: fixed checks on fields only (never on words).
    function issues(r) {
      const out = [], a = mins(r.start), b = mins(r.end), kind = kindOf(r);
      if (!exact(r)) {
        const was = a == null && r.start ? r.start : a == null ? '' : !r.end ? 'No end' : mins(r.end) == null ? r.end : '';
        out.push({ text: 'Set exact time' + (was ? ' · ' + (a == null && r.start ? 'Was “' + was + '”' : was) : ' · No time'), k: 'start', tone: 'bad', tag: 'Set exact time' });
      }
      if (r.day && days.length && !isDay(days, lc(r.day))) out.push({ text: 'Not a day of this Conference', k: 'day', tone: 'bad' });
      if (a != null && a % 5) out.push({ text: 'Use 5-minute steps', k: 'start', tone: 'bad' });
      if (a != null && b != null && b < a && b > 300) out.push({ text: 'Ends next day · Check', k: 'start', tone: 'soft' });
      if (!kind) out.push({ text: r.kind ? 'Choose kind · “' + r.kind + '” isn’t on the list' : 'Choose kind', k: 'kind', tone: 'soft', tag: 'Choose kind' });
      if (r.place && !placeOf(r.place)) out.push({ text: 'Not a place at this campus · ' + r.place, k: 'place', tone: 'bad' });
      if (!r.place && kind && !/^(quiet|checkin)$/.test(kind) && r.display !== 'private') out.push({ text: 'No place', k: 'place', tone: 'soft' });
      const c = clashWith(r);
      if (c) out.push({ text: 'Same room · ' + c.title + ' ' + timeText(c), k: 'place', tone: 'bad', go: c._id });
      return out;
    }

    /* ---------------------------------------------------------- live or not */

    const posted = d.S.schedule_posted || '';
    const isPublic = () => !!(lv && lv.public);
    const notLive = () => isPublic() ? new Set([].concat(lv.added, lv.changed)) : new Set();
    const nNotLive = () => isPublic() ? lv.added.length + lv.changed.length + lv.removed.length : 0;
    let liveT = 0;
    const refreshLive = () => { clearTimeout(liveT); liveT = setTimeout(() => liveOf().then(x => { if (x) { lv = x; head(); drawViews(); markRows(); } }), 900); };

    /* ---------------------------------------------------------- the title row */

    function head() {
      const n = f.rows.length, look = f.rows.filter(r => r._look).length, nl = nNotLive();
      const noTime = f.rows.filter(r => !exact(r)).length;
      const fact = d.held ? 'Ended ' + K.md(d.row.end) + ' · Read only'
        : !days.length ? 'No dates yet'
        : isPublic() ? 'Public since ' + K.mdY(posted, y) + ' · ' + K.plural(n, 'row')
        : posted && posted !== K.NOT_YET && posted > d.today ? 'Public ' + K.mdY(posted, y) : 'Not public · ' + K.plural(n, 'row');
      const acts = [status];
      acts.push(K.see('?year=' + y + '&view=full', 'Preview'));
      acts.push(A.btn('File', { ghost: true, icon: 'down', onClick: e => fileMenu(e.currentTarget) }));
      if (!d.held && days.length && !ro) {
        if (isPublic() && nl) acts.push(h('span', { class: 'ap-tag ap-tag--tan cx-notlive', title: 'Changed since ' + K.md((lv.at || '').slice(0, 10)) + ' · Visitors see the schedule as it was', text: nl + ' unpublished' }));
        // One filled button, by the season: rows carried from last year are checked first, then given
        // exact times, then Publish.
        if (look) acts.push(A.btn('Check ' + look, { primary: true, write: true, title: 'Carried from last year · One at a time, with last year’s beside it', onClick: () => { go('check'); const first = rowsInView()[0]; if (first) openRow(first._id); } }));
        else if (noTime) acts.push(A.btn('Set times ' + noTime, { primary: true, write: true, title: 'Rows with words for a time, or no end · A start and an end for each', onClick: () => { go('time'); const first = rowsInView()[0]; if (first) openRow(first._id); } }));
        if (!isPublic() || nl) acts.push(A.btn('Publish', { primary: !look && !noTime, write: true, onClick: publish }));
      }
      ctx.head('Schedule', fact, acts);
    }

    function leftOver() {
      const look = f.rows.filter(r => r._look), noTime = f.rows.filter(r => !exact(r)), noKind = f.rows.filter(r => !kindOf(r));
      const clashes = f.rows.filter(r => clashWith(r));
      const left = [];
      if (look.length) left.push({ t: look.length + ' to check', go: () => go('check') });
      if (noTime.length) left.push({ t: K.plural(noTime.length, 'row') + ' without an exact time', go: () => { go('time'); openRow(noTime[0]._id); } });
      if (noKind.length) left.push({ t: K.plural(noKind.length, 'row') + ' without a kind', go: () => go('kind') });
      if (clashes.length) left.push({ t: K.plural(clashes.length, 'room clash', 'room clashes'), go: () => { go(lc(clashes[0].day)); openRow(clashes[0]._id); } });
      return left;
    }

    function publish() {
      const left = leftOver();
      if (isPublic()) {
        const titles = [].concat(lv.added, lv.changed).map(id => (f.get(id) || {}).title).filter(Boolean).slice(0, 6);
        const gone = lv.removed.map(x => x.title).filter(Boolean).slice(0, 4);
        K.confirm(sp, {
          title: 'Publish ' + K.plural(nNotLive(), 'change'),
          lines: ['On the Conference page, the Conference app and the printout, for everyone · “Schedule updated” shows ' + K.md(d.today)].concat(titles.length ? ['Changed · ' + titles.join(' · ')] : [], gone.length ? ['Removed · ' + gone.join(' · ')] : []),
          left, actLabel: left.length ? 'Publish anyway' : 'Publish',
          act: () => f.flush().then(() => K.coa(y, 'publish', { part: 'schedule', act: 'update' })),
          onDone: () => { A.toast('Published · ' + K.plural(nNotLive(), 'change')); liveOf().then(x => { lv = x; head(); drawMain(); }); }
        });
        return;
      }
      K.confirm(sp, {
        title: 'Publish the schedule',
        lines: ['Now · On the Conference page, the Conference app and the printout, for everyone', 'Later changes wait for Publish · The call-in ticks go public when saved'],
        left, actLabel: left.length ? 'Publish anyway' : 'Publish',
        act: () => f.flush().then(() => K.coa(y, 'publish', { part: 'schedule', act: 'publish' })),
        onDone: r => { d.S.schedule_posted = (r && r.settings && r.settings.schedule_posted) || d.today; A.toast('Published · The schedule is public'); liveOf().then(x => { lv = x; head(); drawMain(); }); }
      });
    }

    function unpublish() {
      K.confirm(sp, {
        title: 'Unpublish the schedule', danger: true, reason: true,
        lines: ['It comes off the Conference page, the Conference app and the printout'],
        actLabel: 'Unpublish',
        act: reason => K.coa(y, 'publish', { part: 'schedule', act: 'unpublish', reason }),
        onDone: () => { d.S.schedule_posted = K.NOT_YET; A.toast('Unpublished · Not public'); liveOf().then(x => { lv = x; head(); drawMain(); }); }
      });
    }

    function fileMenu(btn) {
      const items = [];
      const can = !ro && !d.held && days.length;
      if (can) items.push({ label: 'Paste rows', run: pasteRows });
      if (can) items.push({ label: 'Import', run: importFile });
      items.push({ label: 'Export · Excel', run: () => exportFile('xlsx') });
      items.push({ label: 'Export · CSV', run: () => exportFile('csv') });
      items.push({ label: 'Printable', run: () => window.open((W.base || '/annual-conference/') + 'schedule/?year=' + y, '_blank', 'noopener') });
      if (A.allowed && A.allowed('callin')) items.push({ label: 'Call-in line', run: () => A.go({ s: 'callin', v: '', id: '', at: '' }) });
      if (isPublic() && !ro && !d.held) items.push({ label: 'Unpublish', run: unpublish });
      A.menu(btn, items);
    }

    /* ---------------------------------------------------------- views */

    const views = h('div', { class: 'ap-views cx-views' });
    const addBox = h('div', { class: 'cx-add' });
    const listEl = h('div', { class: 'cx-list' });
    const bulk = h('div', { class: 'cs-bulk', hidden: true, role: 'toolbar', 'aria-label': 'Ticked rows' });
    sp.main.append(views, addBox, listEl, bulk);

    let checkFrom = 0;
    function go(v) { view = v; A.setParams({ v: view, id: sel, at: layout === 'grid' ? 'grid' : '' }); drawMain(); }

    function rowsInView() {
      const nl = notLive();
      let rows = f.rows.slice();
      if (find) { const w = lc(find); rows = rows.filter(r => lc([r.title, r.note, r.place, (placeOf(r.place) || {}).name, S.kindLabel(r.kind)].join(' ')).indexOf(w) > -1); }
      else if (view === 'check') rows = rows.filter(r => r._look);
      else if (view === 'time') rows = rows.filter(r => !exact(r));
      else if (view === 'kind') rows = rows.filter(r => !kindOf(r));
      else if (view === 'live') rows = rows.filter(r => nl.has(r._id));
      else if (view !== 'all') rows = rows.filter(r => lc(r.day) === view);
      if (only.aud) rows = rows.filter(r => audOf(r.audience) === only.aud);
      if (only.kind) rows = rows.filter(r => kindOf(r) === only.kind);
      const di = n => { const i = days.findIndex(x => lc(x.name) === lc(n)); return i < 0 ? 99 : i; };
      return rows.sort((a, b) => di(a.day) - di(b.day) || sortKey(a) - sortKey(b) || f.rows.indexOf(a) - f.rows.indexOf(b));
    }

    function drawViews() {
      A.clear(views);
      const chips = days.map(x => ({ id: lc(x.name), label: x.name.slice(0, 3), n: f.rows.filter(r => lc(r.day) === lc(x.name)).length, title: x.date ? K.wd(x.date) : x.name }));
      const noTime = f.rows.filter(r => !exact(r)).length, noKind = f.rows.filter(r => !kindOf(r)).length;
      const look = f.rows.filter(r => r._look).length, nl = nNotLive();
      if (noTime) chips.push({ id: 'time', label: 'Set exact time', n: noTime, title: 'Words for a time, or no end' });
      if (noKind) chips.push({ id: 'kind', label: 'Choose kind', n: noKind, title: 'No kind from the list' });
      if (look) chips.push({ id: 'check', label: 'To check', n: look, title: 'Carried from last year' });
      if (nl) chips.push({ id: 'live', label: 'Unpublished', n: nl, title: 'Changed since Publish' });
      chips.push({ id: 'all', label: 'All', n: f.rows.length });
      const bar = A.views(chips, find ? '' : view, id => { find = ''; findIn.value = ''; go(id); });
      bar.querySelectorAll('.ap-chip').forEach((b, i) => { if (chips[i].title) b.title = chips[i].title; });
      const findIn = h('input', { class: 'ap-input cx-find', type: 'search', placeholder: 'Find', 'aria-label': 'Find in every day', value: find });
      findIn.addEventListener('input', () => { find = findIn.value.trim(); drawAdd(); drawList(); bar.querySelectorAll('.ap-chip').forEach((b, i) => b.setAttribute('aria-pressed', String(!find && chips[i].id === view))); });
      findIn.addEventListener('keydown', e => { if (e.key === 'Escape') { findIn.value = ''; find = ''; drawAdd(); drawList(); findIn.blur(); } });
      const filt = h('button', { type: 'button', class: 'ap-btn ap-btn--ghost cs-filter' + (only.aud || only.kind ? ' is-on' : ''), title: 'Show only one group or one kind', on: { click: e => filterMenu(e.currentTarget) } },
        A.icon('down', 14), only.aud || only.kind ? [audLabel(only.aud) && only.aud ? audLabel(only.aud) : '', only.kind ? S.kindLabel(only.kind) : ''].filter(Boolean).join(' · ') : 'Filter');
      const tools = h('div', { class: 'cx-views__tools' }, findIn, filt);
      if (only.aud || only.kind) tools.appendChild(h('button', { type: 'button', class: 'cx-link', title: 'Every group and kind', on: { click: () => { only = { aud: '', kind: '' }; drawViews(); drawList(); } } }, 'Clear'));
      if (isDay(days, view) && K.wide()) {
        tools.appendChild(h('div', { class: 'cx-seg', role: 'group', 'aria-label': 'Layout' },
          h('button', { type: 'button', 'aria-pressed': String(layout === 'table'), title: 'Table', on: { click: () => { layout = 'table'; go(view); } } }, A.icon('list', 15), h('span', { class: 'ap-sr', text: 'Table' })),
          h('button', { type: 'button', 'aria-pressed': String(layout === 'grid'), title: 'Day view', on: { click: () => { layout = 'grid'; go(view); } } }, A.icon('grid', 15), h('span', { class: 'ap-sr', text: 'Day view' }))));
      }
      views.append(bar, tools);
    }
    function filterMenu(btn) {
      const items = [{ label: 'Every group and kind', current: !only.aud && !only.kind, run: () => { only = { aud: '', kind: '' }; drawViews(); drawList(); } }];
      AUD.forEach(a => items.push({ label: 'For · ' + a[1], current: only.aud === a[0], run: () => { only.aud = only.aud === a[0] ? '' : a[0]; drawViews(); drawList(); } }));
      S.KINDS.forEach(k => items.push({ label: 'Kind · ' + k.label, current: only.kind === k.key, run: () => { only.kind = only.kind === k.key ? '' : k.key; drawViews(); drawList(); } }));
      A.menu(btn, items);
    }

    /* ---------------------------------------------------------- the line that adds a row */

    function drawAdd() {
      A.clear(addBox);
      const day = dayName(view);
      addBox.hidden = ro || d.held || !day || !!find;
      if (addBox.hidden) return;
      const input = h('input', { class: 'ap-input cx-add__in', placeholder: 'Add to ' + day + ' · 7–9:45 PM Hymn sing, Chapel Auditorium, Singing', 'aria-label': 'Add a row to ' + day, autocomplete: 'off', 'aria-describedby': 'cx-add-echo', title: 'Start–end, the title, then after commas a place, a kind and who it’s for, in any order' });
      const echo = h('div', { class: 'cx-add__echo cs-echo', id: 'cx-add-echo', 'aria-live': 'polite' });
      const hint = h('p', { class: 'ap-help cs-add__hint', text: 'Start–end, then the title · Place, kind and group after commas, from their lists · Enter adds it' });
      // keptTitle: the title whose comma the person kept; it stays kept while the title is the same.
      let read = null, flipped = false, keptTitle = '';
      const rowOf = () => read && read.row ? (flipped ? S.flip(read.row) : read.row) : null;
      const say = () => {
        A.clear(echo);
        const t = input.value.trim();
        hint.hidden = !!t;
        if (!t) { read = null; return; }
        const kept = S.line(t, Object.assign(rctx(day), { keepCommas: true }));
        const keep = !!keptTitle && !!kept.row && kept.row.title === keptTitle;
        read = keep ? kept : S.line(t, rctx(day));
        const r = rowOf();
        read.said.forEach(([label, value, tone]) => {
          if (label === 'When' && r && read.ok !== undefined && mins(r.start) != null) value = S.spanText(mins(r.start), mins(r.end)) + (read.readAs ? ' · Read as' : '');
          echo.appendChild(h('span', { class: 'cs-said' + (tone ? ' cs-said--' + tone : '') }, label ? h('span', { class: 'cs-said__k', text: label }) : null, h('span', { class: 'cs-said__v', text: value })));
        });
        if (read.readAs && r) echo.appendChild(h('button', { type: 'button', class: 'cx-link', on: { click: () => { flipped = !flipped; say(); input.focus(); } } }, (mins(r.start) < 720 ? 'PM' : 'AM') + ' instead'));
        // A comma in the title: the place is fixed in the line, or the comma kept with one tap.
        if (read.commaTitle && !keep) echo.appendChild(h('button', { type: 'button', class: 'cx-link', title: 'The title is “' + read.row.title + '” · Or type a place from the campus list', on: { click: () => { keptTitle = read.row.title; say(); input.focus(); } } }, 'Keep in the title'));
        if (read.ok) echo.appendChild(h('span', { class: 'ap-quiet cx-add__enter', text: '↵ Add' }));
      };
      input.addEventListener('input', () => { flipped = false; say(); });
      input.addEventListener('keydown', e => {
        if (e.key === 'Escape') { input.value = ''; say(); input.blur(); return; }
        if (e.key !== 'Enter') return;
        e.preventDefault();
        if (!read || !read.ok) { echo.classList.remove('is-shake'); void echo.offsetWidth; echo.classList.add('is-shake'); return; }
        const r = Object.assign({}, rowOf());
        if (!r.place) delete r.place;
        if (r.kind) r.display = S.listedOf(r.kind);
        const id = f.add(r, { label: 'Add ' + r.title });
        A.toast('Added · ' + r.title + ' · ' + r.day.slice(0, 3) + ' ' + timeText(r), { undo: () => { K.replay(f, 'undo'); drawMain(); } });
        input.value = ''; flipped = false; keptTitle = ''; say();
        sel = id; drawViews(); drawList(); head();
        const tr = listEl.querySelector('[data-key="' + id + '"]');
        if (tr) tr.scrollIntoView({ block: 'nearest' });
        setTimeout(() => { const i = addBox.querySelector('.cx-add__in'); if (i) i.focus(); }, 0);
      });
      addBox.append(input, echo, hint);
    }

    /* ---------------------------------------------------------- the list */

    function drawMain() { drawViews(); drawAdd(); drawList(); }

    function drawList() {
      A.clear(listEl);
      const rows = rowsInView();
      // Ticks stay only on rows that still exist.
      [...ticked].forEach(id => { if (!f.get(id)) ticked.delete(id); });
      drawBulk();
      if (layout === 'grid' && isDay(days, view) && !find && K.wide()) { listEl.appendChild(grid(rows)); return; }
      if (!rows.length) {
        listEl.appendChild(A.empty({
          inset: true,
          title: find ? 'No rows with “' + find + '”' : view === 'check' ? 'Nothing to check' : view === 'time' ? 'Every row has an exact time' : view === 'kind' ? 'Every row has a kind' : view === 'live' ? 'Everything is published' : !days.length ? 'No dates yet' : (only.aud || only.kind) ? 'Nothing that fits the filter' : 'Nothing on ' + (dayName(view) || 'this day'),
          line: !days.length ? 'Set the dates first' : !find && isDay(days, view) && !ro && !only.aud && !only.kind ? 'Type a line above, or File › Paste rows' : '',
          action: !days.length ? A.link({ s: 'dates', v: '', id: '' }, 'Dates and place', 'ap-btn') : null
        }));
        return;
      }
      const nl = notLive();
      const groups = !isDay(days, view) || find;
      const tb = h('tbody');
      let lastDay = null;
      const can = !ro && !d.held;
      rows.forEach(r => {
        if (groups && r.day !== lastDay) { lastDay = r.day; tb.appendChild(h('tr', { class: 'ap-tr--group' }, h('td', { colspan: '6', text: dayShort(r.day) }))); }
        const iss = issues(r), bad = iss.find(x => x.tone === 'bad');
        const t = exact(r) ? timeText(r) : '';
        const tick = can ? h('input', { type: 'checkbox', class: 'ap-check cs-tick', 'aria-label': 'Tick ' + (r.title || 'row'), checked: ticked.has(r._id) }) : null;
        if (tick) tick.addEventListener('change', () => { if (tick.checked) ticked.add(r._id); else ticked.delete(r._id); tick.closest('tr').classList.toggle('is-ticked', tick.checked); drawBulk(); });
        const tr = h('tr', { 'data-key': r._id, 'aria-selected': String(r._id === sel), tabindex: '-1', class: (r.display === 'private' ? 'cx-tr--private ' : '') + (nl.has(r._id) ? 'cx-tr--notlive ' : '') + (ticked.has(r._id) ? 'is-ticked' : '') },
          can ? h('td', { class: 'cs-td--tick' }, tick) : null,
          h('td', { class: 'ap-td--nowrap cx-td--when' }, t ? t : h('span', { class: 'cx-warn', text: r.start && mins(r.start) == null ? String(r.start) : mins(r.start) != null ? S.fmt(mins(r.start)) + ' · No end' : 'No time' })),
          h('td', { class: 'cx-td--what' },
            h('span', { class: 'ap-cell-title', text: r.title || 'Untitled' }),
            marks(r, nl, iss),
            view === 'check' && r._look ? h('span', { class: 'ap-cell-sub', text: whyCheck(r) }) : r.note ? h('span', { class: 'ap-cell-sub', text: r.note }) : null),
          h('td', { class: 'ap-td--wide ap-td--muted cs-td--kind', text: S.kindLabel(r.kind) || '' }),
          h('td', { class: 'cx-td--where' }, r.place ? h('span', { class: placeOf(r.place) ? '' : 'cx-warn', text: (placeOf(r.place) || {}).name || r.place }) : null),
          h('td', { class: 'ap-td--wide ap-td--muted cx-td--for', text: audLabel(r.audience) }));
        if (bad) tr.title = bad.text;
        tb.appendChild(tr);
      });
      const allTick = can ? h('input', { type: 'checkbox', class: 'ap-check cs-tick', 'aria-label': 'Tick every row shown', checked: rows.length && rows.every(r => ticked.has(r._id)) }) : null;
      if (allTick) allTick.addEventListener('change', () => { rows.forEach(r => { if (allTick.checked) ticked.add(r._id); else ticked.delete(r._id); }); drawList(); });
      const heads = [['When', 'cx-td--when'], ['What', 'cx-td--what'], ['Kind', 'ap-td--wide cs-td--kind'], ['Where', 'cx-td--where'], ['For', 'ap-td--wide cx-td--for']];
      const table = h('table', { class: 'ap-table cx-table cs-table', 'aria-label': 'Rows' },
        h('thead', null, h('tr', null, can ? h('th', { scope: 'col', class: 'cs-td--tick' }, allTick) : null, heads.map(c => h('th', { scope: 'col', class: c[1], text: c[0] })))), tb);
      const wrap = h('div', { class: 'ap-tablewrap', tabindex: '0', role: 'group', 'aria-label': 'Rows · Arrow keys move · Enter opens · X ticks' }, table);
      tb.addEventListener('click', e => { if (e.target.closest('input, label, .cs-td--tick')) return; const tr = e.target.closest('tr[data-key]'); if (tr) openRow(tr.dataset.key); });
      wrap.addEventListener('keydown', e => {
        const trs = [...tb.querySelectorAll('tr[data-key]')];
        let i = trs.findIndex(x => x.dataset.key === sel);
        if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
          e.preventDefault();
          i = e.key === 'ArrowDown' ? Math.min(trs.length - 1, i + 1) : Math.max(0, i - 1);
          if (trs[i]) { openRow(trs[i].dataset.key, { keep: true }); trs[i].scrollIntoView({ block: 'nearest' }); }
        } else if (e.key === 'Enter' && trs[i]) { e.preventDefault(); const t = sp.panel.querySelector('input, textarea'); if (t) t.focus(); }
        else if ((e.key === 'x' || e.key === 'X') && trs[i] && can && !e.target.matches('input')) { e.preventDefault(); const c = trs[i].querySelector('.cs-tick'); if (c) { c.checked = !c.checked; c.dispatchEvent(new Event('change')); } }
      });
      listEl.appendChild(wrap);
    }
    // Last year's row for this one: the same row carried (the pickup keeps its ID), else the one with the
    // same title on the same day, else the only one with that title. Several "Breakfast" rows and none
    // on this day: none (never the first one found).
    function wasOf(r) {
      const t = lc(r.title);
      const byId = r._id ? prevRows.find(x => x._id === r._id) : null;
      if (byId && (lc(byId.title) === t || r._look)) return byId;
      const same = prevRows.filter(x => lc(x.title) === t);
      return same.find(x => lc(x.day) === lc(r.day)) || (same.length === 1 ? same[0] : null);
    }
    // Why a carried row needs a look, in a few words: what it is and whether it moved since last year.
    function whyCheck(r) {
      const was = wasOf(r);
      const line = x => [x.day ? x.day.slice(0, 3) : '', timeText(x), (placeOf(x.place) || {}).name || x.place].filter(Boolean).join(' · ');
      const pk = (d.picked && d.picked.from) || (d.ov && d.ov.prev ? d.ov.prev.year : 'last year');
      return [r._look === 'unsure' ? 'Not sure' : '', S.kindLabel(r.kind), was ? (line(was) === line(r) ? 'Same as ' + pk : 'Moved since ' + pk) : 'New since ' + pk].filter(Boolean).join(' · ');
    }
    function marks(r, nl, iss) {
      const m = [];
      const t = iss.find(x => x.tag === 'Set exact time');
      if (t && view !== 'time') m.push(A.tag('Set exact time', 'late'));
      if (iss.some(x => x.tag === 'Choose kind') && view !== 'kind') m.push(A.tag('Choose kind', 'tan'));
      // In the To check view every row is one: the tag would say it 19 times.
      if (r._look && view !== 'check') m.push(A.tag(r._look === 'unsure' ? 'Not sure' : 'To check', 'tan'));
      if (nl.has(r._id)) m.push(h('span', { class: 'cx-dot-tan', title: 'Unpublished · Changed since Publish', 'aria-label': 'Unpublished' }));
      if (r.display === 'private') m.push(A.tag('Committees only'));
      if (r.call_in === 'yes') m.push(A.tag(lc(r.recorded) === 'no' ? 'Call-in · Not recorded' : 'Call-in'));
      const bad = iss.filter(x => x.tone === 'bad' && !x.tag);
      if (bad.length) m.push(A.tag(bad.length > 1 ? bad.length + ' problems' : bad[0].text.split(' · ')[0], 'late'));
      return m.length ? h('span', { class: 'cx-marks' }, m) : null;
    }
    function markRows() {
      listEl.querySelectorAll('tr[data-key]').forEach(tr => tr.setAttribute('aria-selected', String(tr.dataset.key === sel)));
    }

    /* ---------------------------------------------------------- ticked rows, one change to all */

    function drawBulk() {
      A.clear(bulk);
      const ids = [...ticked].filter(id => f.get(id));
      bulk.hidden = !ids.length || ro || d.held;
      if (bulk.hidden) return;
      const rows = ids.map(id => f.get(id));
      const one = (label, fields) => {
        f.batch(label, () => ids.forEach(id => {
          const r = f.get(id);
          const o = Object.assign({}, fields);
          if (o.kind != null && r.display !== 'private') o.display = S.listedOf(o.kind);
          f.set(id, o);
        }));
        A.toast(label + ' · ' + K.plural(ids.length, 'row'), { undo: () => { K.replay(f, 'undo'); drawMain(); } });
        drawMain(); head();
      };
      const btn = (label, run, o) => h('button', Object.assign({ type: 'button', class: 'ap-btn ap-btn--ghost cs-bulk__b', on: { click: e => run(e.currentTarget) } }, o || {}), label, o && o.menu ? A.icon('down', 13) : null);
      // append() writes a null as the word "null": only what's drawn goes in.
      bulk.append(...[
        h('span', { class: 'cs-bulk__n', text: K.plural(ids.length, 'row') + ' ticked' }),
        btn('Kind', b => A.menu(b, S.KINDS.map(k => ({ label: k.label, run: () => one('Kind ' + k.label, { kind: k.key }) }))), { menu: true }),
        btn('For', b => A.menu(b, AUD.map(a => ({ label: a[1], run: () => one('For ' + a[1], { audience: a[0] }) }))), { menu: true }),
        btn('Day', b => A.menu(b, days.map(x => ({ label: x.date ? K.wd(x.date) : x.name, run: () => one('Day ' + x.name.slice(0, 3), { day: x.name }) }))), { menu: true }),
        btn('Where', () => bulkPlace(ids, one)),
        btn('Call-in', b => A.menu(b, [
          { label: 'On the line', run: () => ticks(ids, { call_in: true }) },
          { label: 'Off the line', run: () => ticks(ids, { call_in: false }) },
          { label: 'Recorded', run: () => ticks(ids.filter(id => f.get(id).call_in === 'yes'), { recorded: true }) },
          { label: 'Not recorded', run: () => ticks(ids.filter(id => f.get(id).call_in === 'yes'), { recorded: false }) }
        ]), { menu: true }),
        rows.some(r => r._look) ? btn('Looks right', () => { const n = rows.filter(r => r._look).length; f.batch('Looks right', () => rows.filter(r => r._look).forEach(r => f.set(r._id, { _look: '' }))); A.toast('Checked · ' + K.plural(n, 'row'), { undo: () => { K.replay(f, 'undo'); drawMain(); } }); drawMain(); head(); }) : null,
        btn('Remove', () => { f.batch('Remove ' + ids.length, () => ids.forEach(id => f.remove(id))); ticked.clear(); if (ids.indexOf(sel) > -1) { sp.close(true); sel = ''; } A.toast('Removed · ' + K.plural(ids.length, 'row'), { undo: () => { K.replay(f, 'undo'); drawMain(); } }); drawMain(); head(); }, { class: 'ap-btn ap-btn--ghost ap-btn--danger cs-bulk__b' }),
        h('button', { type: 'button', class: 'cx-link cs-bulk__clear', on: { click: () => { ticked.clear(); drawList(); } } }, 'Clear')].filter(Boolean));
    }
    function bulkPlace(ids, one) {
      const listId = 'cs-bulk-places';
      const inp = h('input', { class: 'ap-input', list: listId, placeholder: 'Chapel Auditorium, B/HW…', 'aria-label': 'Where', autocomplete: 'off' });
      const said = h('span', { class: 'ap-help' });
      const fld = K.field('Where', h('div', null, inp, h('datalist', { id: listId }, places().map(x => h('option', { value: x.name }))), said));
      const read = () => { const q = S.place(inp.value, places()); said.textContent = q.place ? q.place.name + ' · ' + q.place.code : q.many ? q.many.length + ' places · ' + q.many.slice(0, 3).map(x => x.name).join(', ') : inp.value.trim() ? 'Not a place at this campus · Add it on Campus' : ''; return q; };
      inp.addEventListener('input', read);
      const goBtn = A.btn('Set place', { primary: true, write: true, onClick: () => { const q = read(); if (!q.place) { fld.setError(said.textContent || 'A place from the list'); return; } sp.close(true); one('Where ' + q.place.name, { place: q.place.code }); } });
      sp.open({ title: 'Where · ' + K.plural(ids.length, 'row'), body: fld, foot: [goBtn, A.btn('Cancel', { ghost: true, onClick: () => sp.close() })] });
      inp.focus();
    }

    // The call-in ticks: the Call-in screen's route (public at once once the schedule is).
    function ticks(ids, fields, done) {
      if (!ids.length) { A.toast('Only rows on the line are recorded'); return; }
      // Undo puts each row back as it was (on or off, recorded or not), in two calls at most.
      const k = fields.call_in != null ? 'call_in' : 'recorded';
      const was = id => k === 'call_in' ? f.get(id).call_in === 'yes' : lc(f.get(id).recorded) !== 'no';
      const on = ids.filter(was), off = ids.filter(id => !was(id));
      A.api('POST', 'callin/rows', Object.assign({ ids }, fields)).then(() => f.sync()).then(() => {
        const words = fields.call_in === true ? 'On the line' : fields.call_in === false ? 'Off the line' : fields.recorded ? 'Recorded' : 'Not recorded';
        A.toast(words + ' · ' + K.plural(ids.length, 'row') + (isPublic() ? ' · Public now' : ''), { undo: () => {
          Promise.all([on.length ? A.api('POST', 'callin/rows', { ids: on, [k]: true }) : null, off.length ? A.api('POST', 'callin/rows', { ids: off, [k]: false }) : null])
            .then(() => f.sync()).then(() => { drawMain(); if (sel && f.get(sel)) openRow(sel, { keep: true }); }, A.fail);
        } });
        drawMain(); if (done) done();
      }, A.fail);
    }

    /* ---------------------------------------------------------- Day view */

    // One column for each audience the day has; blocks by their real times, each at least tall enough for
    // its words (measured after drawing, and again whenever the grid's width changes); rows that run
    // 3½ hours or more are a bar at the column's edge, named in the Running line, with rows that have no
    // exact time yet.
    function grid(rows) {
      const timed = rows.filter(r => exact(r) && !/^(all day|desk|nightly)$/.test(r.display || ''));
      const other = rows.filter(r => timed.indexOf(r) < 0);
      const cols = AUD.filter(a => timed.some(r => audOf(r.audience) === a[0]));
      if (!timed.length) return A.empty({ inset: true, title: 'Nothing timed on ' + dayName(view) });
      const lo = Math.floor(Math.min(...timed.map(r => mins(r.start))) / 60) * 60;
      const hi = Math.ceil(Math.max(...timed.map(r => mins(r.start) + Math.max(30, lenOf(r)))) / 60) * 60;
      const PX = 1.4; // per minute
      const wrap = h('div', { class: 'cx-grid' });
      wrap.style.setProperty('--cols', String(cols.length));
      const run = timed.filter(r => lenOf(r) >= LONG);
      if (run.length || other.length) wrap.appendChild(h('div', { class: 'cx-grid__run' }, h('span', { class: 'ap-label', text: 'Running' }),
        run.concat(other).map(r => h('button', { type: 'button', class: 'cx-chiprow' + (r._id === sel ? ' is-sel' : '') + (exact(r) ? '' : ' is-bad'), 'data-key': r._id, on: { click: () => openRow(r._id) } }, h('b', { text: r.title }), ' ', exact(r) ? timeText(r) : 'Set exact time'))));
      const headRow = h('div', { class: 'cx-grid__heads' }, h('span'), cols.map(c => h('span', { class: 'cx-grid__head', text: c[1] })));
      const body = h('div', { class: 'cx-grid__body', style: { height: ((hi - lo) * PX) + 'px' } });
      const hours = h('div', { class: 'cx-grid__hours' });
      for (let m = lo; m <= hi; m += 60) {
        hours.appendChild(h('span', { class: 'cx-grid__hour', style: { top: ((m - lo) * PX) + 'px' }, text: S.fmt(m % 1440).replace(':00', '') }));
        body.appendChild(h('i', { class: 'cx-grid__line', style: { top: ((m - lo) * PX) + 'px' } }));
      }
      const colEls = cols.map(() => h('div', { class: 'cx-grid__col' }));
      body.append(hours, h('div', { class: 'cx-grid__cols' }, colEls));
      const nl = notLive();
      cols.forEach((c, ci) => {
        const mine = timed.filter(r => audOf(r.audience) === c[0] && lenOf(r) < LONG).sort((a, b) => sortKey(a) - sortKey(b));
        mine.forEach(r => {
          const a = mins(r.start), len = Math.max(15, lenOf(r) || 30);
          const iss = issues(r).filter(x => x.tone === 'bad');
          const blk = h('button', {
            type: 'button', class: 'cx-blk' + (r._id === sel ? ' is-sel' : '') + (r._look ? ' is-look' : '') + (iss.length ? ' is-bad' : '') + (nl.has(r._id) ? ' is-notlive' : ''), 'data-key': r._id,
            style: { top: ((a - lo) * PX) + 'px', minHeight: Math.max(26, len * PX - 2) + 'px', left: '2px', width: 'calc(100% - 4px)' },
            title: (r.title || '') + ' · ' + timeText(r) + (iss.length ? ' · ' + iss[0].text : ''),
            on: { click: () => openRow(r._id) }
          }, h('span', { class: 'cx-blk__t', text: timeText(r) }), h('span', { class: 'cx-blk__n', text: r.title || 'Untitled' }), r.place ? h('span', { class: 'cx-blk__p', text: (placeOf(r.place) || {}).name || r.place }) : null);
          colEls[ci].appendChild(blk);
        });
      });
      wrap.append(headRow, body);
      // Every block tall enough for its words, and never on top of another: each is measured, then
      // blocks that would overlap as drawn (a short one grown for its words) sit side by side. Measured
      // again whenever the grid's width changes (the record panel opening narrows it).
      const lanesIn = [];
      const fitCols = () => colEls.forEach((col, ci) => {
        const blks = [...col.querySelectorAll('.cx-blk')];
        for (let pass = 0; pass < 2; pass++) {
          blks.forEach(b => { b.style.height = ''; if (b.scrollHeight > b.clientHeight + 1) b.style.height = b.scrollHeight + 'px'; });
          const lanes = [], laneOf = new Map();
          blks.map(b => ({ b, top: b.offsetTop, bot: b.offsetTop + b.offsetHeight + 2 })).sort((x, z) => x.top - z.top).forEach(x => {
            let li = lanes.findIndex(end => end <= x.top);
            if (li < 0) { li = lanes.length; lanes.push(x.bot); } else lanes[li] = x.bot;
            laneOf.set(x.b, li);
          });
          const sorted = blks.slice().sort((x, z) => x.offsetTop - z.offsetTop);
          let group = [], bottom = -1;
          lanesIn[ci] = Math.max(1, lanes.length);
          const place = g => { const n = Math.max(...g.map(b => laneOf.get(b))) + 1; g.forEach(b => { b.style.left = 'calc(' + (laneOf.get(b) * 100 / n) + '% + 2px)'; b.style.width = 'calc(' + (100 / n) + '% - 4px)'; }); };
          sorted.forEach(b => {
            if (group.length && b.offsetTop >= bottom) { place(group); group = []; bottom = -1; }
            group.push(b); bottom = Math.max(bottom, b.offsetTop + b.offsetHeight + 2);
          });
          if (group.length) place(group);
        }
      });
      const fit = () => {
        fitCols();
        const tpl = colEls.map((c, i) => 'minmax(0, ' + (lanesIn[i] || 1) + 'fr)').join(' ');
        body.querySelector('.cx-grid__cols').style.gridTemplateColumns = tpl;
        headRow.style.gridTemplateColumns = '52px ' + tpl;
        fitCols();
      };
      requestAnimationFrame(fit);
      if (window.ResizeObserver) { let w0 = 0; const ro2 = new ResizeObserver(en => { const w = en[0].contentRect.width; if (Math.abs(w - w0) > 1) { w0 = w; fit(); } }); ro2.observe(wrap); offs.push(() => ro2.disconnect()); }
      return wrap;
    }

    /* ---------------------------------------------------------- one row, beside the list */

    function openRow(id, o) {
      o = o || {};
      const r = f.get(id);
      if (!r) { sp.close(true); return; }
      const was = sel;
      sel = id;
      A.setParams({ v: view, id, at: layout === 'grid' ? 'grid' : '' });
      listEl.querySelectorAll('[data-key]').forEach(x => { x.setAttribute('aria-selected', String(x.dataset.key === id)); x.classList.toggle('is-sel', x.dataset.key === id); });
      if (was && was !== id && f.isHeld && f.isHeld(was)) f.discard(was);
      const set = (fields, label, key) => { f.set(id, fields, { label, key: id + ':' + key }); };
      const body = h('div', { class: 'cx-rec' });
      const issBox = h('div', { class: 'cx-issues', 'aria-live': 'polite' });
      const drawIssues = () => {
        A.clear(issBox);
        const rr = f.get(id); if (!rr) return;
        issues(rr).filter(x => x.tag !== 'Set exact time').forEach(x => issBox.appendChild(h('p', { class: 'cx-issue cx-issue--' + x.tone }, x.text, x.go ? [' · ', K.link('Open', () => openRow(x.go))] : null)));
      };
      if (r._look) body.appendChild(checkBox(r));
      if (!exact(r)) body.appendChild(timeBox(r, set));
      // What
      const title = K.textIn({ value: r.title, label: 'What', onSave: v => { if (!v.trim()) return 'A row needs a name'; set({ title: v.trim() }, 'What', 'title'); const t = sp.panel.querySelector('.ap-panel__title'); if (t) t.textContent = v.trim(); } });
      // Opened by a click, the name takes the focus; moved to with the arrow keys, the list keeps it.
      if (!o.keep) title.setAttribute('data-autofocus', '');
      body.appendChild(held(K.field('What', title), r, 'title'));
      // Day
      body.appendChild(K.field('Day', K.pills(days.map(x => [x.name, x.name.slice(0, 3), x.date ? K.wd(x.date) : x.name]), r.day, v => { set({ day: v }, 'Day', 'day'); A.toast('Moved · ' + r.title + ' · ' + v, { undo: () => K.replay(f, 'undo') }); if (isDay(days, view) && lc(v) !== view) { drawList(); } }, { label: 'Day' }), { tag: 'div' }));
      // Start and End: each a clock time, read as typed and said back.
      body.appendChild(timeFields(r, set));
      // Kind: one of the fixed list; how the row is listed follows it.
      body.appendChild(kindField(r, set));
      // Where: a place this campus has.
      const listId = 'cx-places-' + Math.random().toString(36).slice(2, 7);
      const where = K.textIn({ value: r.place ? ((placeOf(r.place) || {}).name || r.place) : '', label: 'Where', placeholder: 'Chapel Auditorium, B/HW…', onSave: v => {
        if (!v.trim()) { set({ place: '' }, 'Where', 'place'); return; }
        const q = S.place(v, places());
        if (q.many) return q.many.length + ' places · ' + q.many.slice(0, 3).map(x => x.name).join(', ');
        if (!q.place) return 'Not a place at this campus · Add it on Campus';
        set({ place: q.place.code }, 'Where', 'place');
        where.set(q.place.name);
      } });
      where.setAttribute('list', listId);
      body.appendChild(held(K.field('Where', h('div', null, where, h('datalist', { id: listId }, places().map(x => h('option', { value: x.name })))), { help: 'A place from the campus list · Its name or its code' }), r, 'place'));
      // For
      body.appendChild(K.field('For', K.pills(AUD, audOf(r.audience), v => set({ audience: v }, 'For', 'audience'), { label: 'For' }), { tag: 'div' }));
      // The call-in line: two ticks (the Call-in screen's too).
      body.appendChild(callinFields(r));
      // Note
      body.appendChild(held(K.field('Note', K.textIn({ value: r.note, label: 'Note', multiline: true, rows: 2, placeholder: 'Shown under the title', onSave: v => set({ note: v }, 'Note', 'note') }), { help: 'For people · “Begins after Communion” goes here' }), r, 'note'));
      drawIssues();
      body.appendChild(issBox);
      body.appendChild(more(r, set));
      body.appendChild(historyFold(id));
      const foot = ro || d.held ? null : [
        // A new row has an exact start and end (the server holds to it): a row still to set is set first.
        A.btn('Duplicate', { ghost: true, write: true, onClick: () => { const c = Object.assign({}, f.get(id)); delete c._id; delete c._look; if (!exact(c)) { A.toast('Set exact time first · A start and an end'); return; } delete c.sort_time; const nid = f.add(c, { label: 'Duplicate ' + c.title, before: (f.rows[f.rows.indexOf(f.get(id)) + 1] || {})._id }); A.toast('Duplicated · ' + c.title, { undo: () => K.replay(f, 'undo') }); drawList(); openRow(nid); } }),
        A.btn('Remove', { ghost: true, danger: true, write: true, onClick: () => { const t = r.title; f.remove(id, { label: 'Remove ' + t }); sp.close(true); sel = ''; A.setParams({ id: '' }); drawMain(); A.toast('Removed · ' + t, { undo: () => { K.replay(f, 'undo'); drawMain(); } }); } })
      ];
      // Previous · Next through the rows as listed (the record kit, Round 3).
      const keys = listEl ? [...listEl.querySelectorAll('[data-key]')].map(x => x.dataset.key).filter((k, i, a) => k && a.indexOf(k) === i) : [];
      const i = keys.indexOf(String(id));
      sp.open({ title: r.title || 'New row', body, foot, onClose: () => { if (f.isHeld && f.isHeld(id)) f.discard(id); sel = ''; A.setParams({ id: '', v: view }); markRows(); listEl.querySelectorAll('.is-sel').forEach(x => x.classList.remove('is-sel')); },
        nav: i < 0 ? null : { prev: i > 0 ? () => openRow(keys[i - 1], { keep: true }) : null, next: i < keys.length - 1 ? () => openRow(keys[i + 1], { keep: true }) : null } });
      if (!K.wide()) window.scrollTo(0, 0);
      if (ro || d.held) sp.panel.querySelectorAll('input, textarea, button.ap-pill, .cs-callin button').forEach(x => { x.disabled = true; });
      panelIssues = drawIssues;
    }
    let panelIssues = null;

    // Start and End, side by side. A time without AM or PM is read by the one fixed rule (an end: the
    // first such time after the start) and said back: "Read as 7–9:45 PM · 2 hr 45 min".
    function timeFields(r, set) {
      const a0 = mins(r.start), b0 = mins(r.end);
      const sIn = K.textIn({ value: a0 != null ? S.store(a0) : '', label: 'Start', live: false });
      const eIn = K.textIn({ value: b0 != null ? S.store(b0) : '', label: 'End', live: false });
      const said = h('p', { class: 'ap-help cs-time__said' });
      const sF = K.field('Start', sIn), eF = K.field('End', eIn);
      const sayNow = () => {
        const rr = f.get(r._id) || r, a = mins(rr.start), b = mins(rr.end);
        A.clear(said);
        if (a != null && b != null) said.append(S.spanText(a, b) + ' · ' + S.length(a, b) + (b < a ? ' · Ends next day' : ''));
        else if (a != null) said.append('Starts ' + S.fmt(a) + ' · No end yet');
      };
      const save = () => {
        const st = sIn.value.trim(), en = eIn.value.trim();
        sF.setError(''); eF.setError('');
        if (!st && !en) return;
        if (st && !en) {
          // A start alone: read by the same one rule as the add line, and said so, with the other half
          // one tap away (never saved as the morning without saying it).
          const c = S.clock(st);
          if (c.err) { sF.setError(c.err); return; }
          const m = c.half ? c.m : ((c.h % 12) + (c.h >= 7 && c.h <= 11 ? 0 : 12)) * 60 + c.mi;
          set({ start: S.store(m), sort_time: '' }, 'Start', 'start');
          sIn.set(S.store(m));
          sayNow();
          if (!c.half) {
            said.append(' · Read as ', K.link((m < 720 ? 'PM' : 'AM') + ' instead', () => {
              const m2 = (m + 720) % 1440;
              set({ start: S.store(m2), sort_time: '' }, 'Start', 'start');
              sIn.set(S.store(m2)); sayNow();
            }));
          }
          return;
        }
        const sp2 = S.span((st || '') + '–' + en);
        if (sp2.err) {
          const cs = S.clock(st), ce = S.clock(en);
          if (st && cs.err) sF.setError(cs.err); else if (ce.err) eF.setError(ce.err); else sF.setError(sp2.err);
          return;
        }
        set({ start: S.store(sp2.a), end: S.store(sp2.b), sort_time: '' }, 'When', 'when');
        sIn.set(S.store(sp2.a)); eIn.set(S.store(sp2.b));
        sayNow();
        if (sp2.readAs) {
          said.append(' · Read as ', K.link((sp2.a < 720 ? 'PM' : 'AM') + ' instead', () => {
            const by = sp2.a < 720 ? 720 : -720;
            set({ start: S.store(sp2.a + by), end: S.store(sp2.b + by), sort_time: '' }, 'When', 'when');
            sIn.set(S.store(sp2.a + by)); eIn.set(S.store(sp2.b + by)); sayNow();
          }));
        }
      };
      [sIn, eIn].forEach(i => { i.addEventListener('change', save); i.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); save(); } }); });
      sayNow();
      const box = h('div', { class: 'cs-time' }, h('div', { class: 'cx-two' }, held(sF, r, 'start'), held(eF, r, 'end')), said);
      return box;
    }

    // A row with words for a time, or no end: what it had, and a place to keep the words.
    function timeBox(r, set) {
      const words = r.start && mins(r.start) == null ? String(r.start) : '';
      const endWords = r.end && mins(r.end) == null ? String(r.end) : '';
      const kept = [words, endWords && endWords !== '?' ? endWords : ''].filter(Boolean).join(' · ');
      const inNote = kept && lc(r.note).indexOf(lc(words || endWords)) > -1;
      return h('div', { class: 'cs-fix', role: 'note' },
        h('p', { class: 'cs-fix__h' }, A.tag('Set exact time', 'late'), ' ', words ? 'Was “' + words + '”' : endWords ? 'Ends “' + endWords + '”' : r.start ? 'No end' : 'No time'),
        h('p', { class: 'ap-help', text: 'Type the planned start and end below · What it waits on goes in the note' }),
        kept && !inNote && !ro && !d.held ? h('div', { class: 'ap-row' }, K.link('Keep “' + kept + '” in the note', () => {
          const rr = f.get(r._id);
          set({ note: (rr.note ? rr.note.replace(/\s+$/, '') + ' ' : '') + kept.replace(/^\w/, c => c.toUpperCase()) + (/[.!?]$/.test(kept) ? '' : '.') }, 'Note', 'note');
          openRow(r._id, { keep: true });
        }, { title: 'Adds the words to the note, for people' })) : null);
    }

    function kindField(r, set) {
      const k = kindOf(r);
      const opts = S.KINDS.map(x => [x.key, x.label, x.display ? 'Listed as ' + S.LISTED[x.display] : 'Listed in the day']);
      const help = [r.display === 'private' ? 'Committees only' : 'Listed as ' + (S.LISTED[lc(r.display)] || 'In the day'), r.kind && !S.KINDS.some(x => x.key === lc(r.kind)) ? 'Saved as “' + r.kind + '”' + (k ? ' · Read as ' + S.kindLabel(k) : '') : ''].filter(Boolean).join(' · ');
      return K.field('Kind', K.pills(opts, k, v => {
        const rr = f.get(r._id);
        set(Object.assign({ kind: v }, rr.display === 'private' ? {} : { display: S.listedOf(v) }), 'Kind', 'kind');
        openRow(r._id, { keep: true });
      }, { label: 'Kind' }), { tag: 'div', help, cls: 'cs-kind' });
    }

    function callinFields(r) {
      const on = r.call_in === 'yes', rec = on && lc(r.recorded) !== 'no';
      const can = !ro && !d.held;
      const pick = (field, v) => ticks([r._id], { [field]: v === 'yes' }, () => openRow(r._id, { keep: true }));
      const box = h('div', { class: 'cs-callin' },
        K.field('On the call-in line', K.pills([['', 'No'], ['yes', 'Yes']], on ? 'yes' : '', v => pick('call_in', v), { label: 'On the call-in line', disabled: !can }), { tag: 'div', help: isPublic() ? 'Goes public when saved' : 'Live on the phone line' }),
        on ? K.field('Recorded', K.pills([['yes', 'Yes'], ['', 'No']], rec ? 'yes' : '', v => pick('recorded', v), { label: 'Recorded', disabled: !can }), { tag: 'div', help: 'For playback by phone' }) : null);
      return box;
    }

    // Someone else changed the same field first: their text and mine, at the field.
    function held(fieldEl, r, field) {
      const hd = f.held[r._id] && f.held[r._id][field];
      if (!hd) return fieldEl;
      fieldEl.appendChild(h('div', { class: 'cx-clash', role: 'alert' },
        h('p', null, 'Changed by ' + (hd.by || 'someone else') + ' just now: ', h('q', { text: hd.theirs || '(blank)' })),
        h('div', { class: 'ap-row' },
          A.btn('Keep mine', { primary: true, write: true, onClick: () => { f.resolve(r._id, field, true); openRow(r._id); } }),
          A.btn('Use theirs', { write: true, onClick: () => { f.resolve(r._id, field, false); openRow(r._id); } }))));
      return fieldEl;
    }

    // To check: last year's line beside this year's, said plainly; Looks right clears it.
    function checkBox(r) {
      const was = wasOf(r);
      const line = x => [x.day ? x.day.slice(0, 3) : '', timeText(x), (placeOf(x.place) || {}).name || x.place].filter(Boolean).join(' · ');
      const same = was && line(was) === line(r);
      const pk = (d.picked && d.picked.from) || (d.ov && d.ov.prev ? d.ov.prev.year : '');
      const left = f.rows.filter(x => x._look).length;
      if (!checkFrom || left > checkFrom) checkFrom = left;
      const at = checkFrom - left + 1;
      const order = () => (view === 'check' ? rowsInView() : f.rows);
      return h('div', { class: 'cx-check', role: 'note' },
        h('p', { class: 'cx-check__h' }, A.tag(r._look === 'unsure' ? 'Not sure' : 'To check', 'tan'), was ? (same ? ' Same as ' + pk : ' Changed from ' + pk) : ' New since ' + pk, h('span', { class: 'ap-quiet', text: '  ·  ' + at + ' of ' + checkFrom })),
        was ? h('p', { class: 'cx-check__was' }, h('span', { class: 'ap-label', text: pk }), ' ', line(was)) : null,
        h('p', { class: 'ap-help', text: 'Changes most years · Check the time and place' }),
        h('div', { class: 'ap-row' },
          A.btn('Looks right', { primary: true, write: true, icon: 'check', onClick: () => {
            const list = order(), rest = list.filter(x => x._look && x._id !== r._id);
            const after = rest.find(x => list.indexOf(x) > list.indexOf(r)) || rest[0];
            f.set(r._id, { _look: '' }, { label: 'Looks right' });
            A.toast('Checked · ' + r.title + (rest.length ? ' · ' + rest.length + ' left' : ' · All checked'), { undo: () => K.replay(f, 'undo') });
            drawMain(); head();
            if (after) openRow(after._id); else openRow(r._id);
          } }),
          r._look !== 'unsure' ? A.btn('Not sure', { ghost: true, write: true, onClick: () => { f.set(r._id, { _look: 'unsure' }, { label: 'Not sure' }); drawList(); openRow(r._id); } }) : null,
          left > 1 ? A.btn('All ' + left + ' look right', { ghost: true, write: true, title: 'Every row still to check · Undo in the toast', onClick: () => {
            f.batch('All look right', () => f.rows.filter(x => x._look).forEach(x => f.set(x._id, { _look: '' })));
            A.toast('Checked · ' + K.plural(left, 'row'), { undo: () => { K.replay(f, 'undo'); drawMain(); } });
            drawMain(); head(); openRow(r._id);
          } }) : null));
    }

    // More: what's set only now and then, summarised on its line.
    function more(r, set) {
      const kind = kindOf(r);
      const sum = [r.display === 'private' ? 'Committees only' : '', r.last_day ? 'Through ' + r.last_day.slice(0, 3) : '', r.closed_during === 'yes' ? 'Closed during services' : '', r.print_note ? 'Printout note' : ''].filter(Boolean).join(' · ');
      const det = h('details', { class: 'cx-more' }, h('summary', null, h('span', { text: 'More' }), sum ? h('span', { class: 'ap-quiet', text: sum }) : null));
      const after = days.slice(days.findIndex(x => x.name === r.day) + 1);
      det.append(...[
        K.field('Shown to', K.pills([['', 'Everyone'], ['private', 'Committees only']], r.display === 'private' ? 'private' : '', v => { set({ display: v === 'private' ? 'private' : S.listedOf(kind) }, 'Shown to', 'display'); openRow(r._id, { keep: true }); }, { label: 'Shown to' }), { tag: 'div', help: 'Committees only · Never on a public page or paper' }),
        after.length ? K.field('Through', K.pills([['', 'One day']].concat(after.map(x => [x.name, x.name.slice(0, 3)])), r.last_day || '', v => set({ last_day: v }, 'Through', 'last_day'), { label: 'Through' }), { tag: 'div', help: 'The same row each day through then' }) : null,
        kind === 'open' ? K.field('Closed during services', K.pills([['', 'No'], ['yes', 'Yes']], r.closed_during === 'yes' ? 'yes' : '', v => set({ closed_during: v }, 'Closed during services', 'closed_during'), { label: 'Closed during services' }), { tag: 'div', help: '“Closed · reopens 4 PM” while a service is on' }) : null,
        K.field('Printout note', K.textIn({ value: r.print_note, label: 'Printout note', onSave: v => set({ print_note: v }, 'Printout note', 'print_note') }), { help: 'Only on the printed schedule' })
      ].filter(Boolean));
      return det;
    }

    function historyFold(id) {
      const det = h('details', { class: 'cx-more cx-hist' }, h('summary', null, h('span', { text: 'History' })));
      const list = h('ul', { class: 'ap-feed' });
      det.appendChild(list);
      det.addEventListener('toggle', () => {
        if (!det.open || list.dataset.done) return;
        list.dataset.done = '1';
        list.appendChild(h('li', { class: 'ap-quiet', text: 'Loading' }));
        f.history(id).then(rows => {
          A.clear(list);
          if (!rows.length) { list.appendChild(h('li', { class: 'ap-quiet', text: 'No changes yet' })); return; }
          rows.slice(0, 20).forEach(x => list.appendChild(h('li', null, h('span', null, h('b', { text: x.who || 'Someone' }), ' · ', words(x)), h('span', { class: 'ap-feed__at', text: K.ago(x.at) }))));
        }, () => { A.clear(list).appendChild(h('li', { class: 'ap-quiet', text: 'Not loaded' })); });
      });
      return det;
    }
    const FW = { day: 'Day', start: 'Starts', end: 'Ends', title: 'What', place: 'Where', audience: 'For', note: 'Note', call_in: 'Call-in', recorded: 'Recorded', display: 'Listed as', kind: 'Kind', last_day: 'Through', _look: 'Checked', print_note: 'Printout note', closed_during: 'Closed during services', sort_time: 'Sort time' };
    function words(x) {
      if (x.action === 'add') return 'Added';
      if (x.action === 'remove') return 'Removed';
      const b = x.before || {}, a = x.after || {};
      const v = (k, s) => k === 'kind' ? S.kindLabel(s) || s : k === 'display' ? S.LISTED[lc(s)] || s : k === 'recorded' ? (lc(s) === 'no' ? 'No' : 'Yes') : s;
      return Object.keys(a).filter(k => FW[k]).map(k => k === '_look' ? (a[k] ? 'To check' : 'Checked') : FW[k] + ' ' + (v(k, b[k]) || '—') + ' → ' + (v(k, a[k]) || '—')).join(' · ') || 'Changed';
    }

    /* ---------------------------------------------------------- File: paste, import, export */

    // Identical in every field the format can say: already there, never added twice.
    const sameRow = (a, b) => lc(a.day) === lc(b.day) && mins(a.start) === mins(b.start) && mins(a.end) === mins(b.end) && lc(a.title) === lc(b.title) && lc(a.place) === lc(b.place);
    const clean = r => { const o = Object.assign({}, r); Object.keys(o).forEach(k => { if (k[0] === '_' && k !== '_id') delete o[k]; }); return o; };
    // A row read from paste or a file, as it's added: no ID, nothing blank that has a default, and how
    // it's listed from its kind.
    const newRow = r => {
      const o = clean(r);
      delete o._id;
      ['place', 'kind', 'audience', 'last_day', 'note', 'print_note', 'call_in', 'recorded'].forEach(k => { if (o[k] === '') delete o[k]; });
      if (o.kind && o.display == null) o.display = S.listedOf(o.kind);
      return o;
    };

    // Rows read from paste or a file (no ID column) → the preview and the two acts.
    function previewAdd(got, title, after) {
      const okRow = x => !(x.row._errs && x.row._errs.length) && !x.row._timeErr && x.row.start && x.row.end;
      const rows = got.rows.filter(okRow);
      const unread = got.unread.concat(got.rows.filter(x => !okRow(x)).map(x => ({ text: x.line, why: S.errWords(x.row) || x.row._timeErr || 'Set exact time' })));
      const exists = x => f.rows.some(c => sameRow(c, x.row));
      const fresh = rows.filter(x => !exists(x));
      const dset = Array.from(new Set(rows.map(x => x.row.day)));
      const gone = f.rows.filter(x => dset.indexOf(x.day) > -1).length;
      const pre = h('div', { class: 'cx-preview' });
      pre.appendChild(h('p', { class: 'ap-quiet', text: K.plural(rows.length, 'row') + ' read' + (rows.length - fresh.length ? ' · ' + (rows.length - fresh.length) + ' already there' : '') + (unread.length ? ' · ' + K.plural(unread.length, 'line') + ' not read' : '') }));
      const ul = h('ul', { class: 'cx-prevlist' });
      rows.slice(0, 80).forEach(x => ul.appendChild(h('li', { class: exists(x) ? 'is-same' : '' },
        h('span', { class: 'cx-prev__d', text: (x.row.day || '').slice(0, 3) }), h('span', { class: 'cx-prev__t', text: timeText(x.row) + (x.row._readAs ? ' · Read as' : '') }), h('span', { text: x.row.title }),
        x.row.place ? h('span', { class: 'ap-quiet', text: (placeOf(x.row.place) || {}).name || x.row.place }) : null,
        h('span', { class: 'ap-quiet', text: x.row.kind ? S.kindLabel(x.row.kind) : 'Kind to choose' }),
        exists(x) ? h('span', { class: 'ap-quiet', text: 'Already there' }) : null)));
      unread.slice(0, 30).forEach(x => ul.appendChild(h('li', { class: 'is-bad' }, h('span', { class: 'cx-prev__t', text: 'Not read' }), h('span', { text: x.text }), h('span', { text: '· ' + x.why }))));
      pre.appendChild(ul);
      const apply = replace => {
        const add = (replace ? rows : fresh).map(x => { const o = newRow(x.row); return o; });
        f.batch(replace ? 'Replace ' + dset.join(', ') : title, () => {
          if (replace) f.rows.filter(x => dset.indexOf(x.day) > -1).map(x => x._id).forEach(id => f.remove(id));
          add.forEach(o => f.add(o));
        });
        sp.close(true);
        drawMain(); head();
        A.toast((replace ? 'Replaced · ' : 'Added · ') + K.plural(add.length, 'row'), { undo: () => { K.replay(f, 'undo'); drawMain(); } });
        if (after) after();
      };
      const addBtn = A.btn(fresh.length ? 'Add ' + K.plural(fresh.length, 'row') : 'Add rows', { primary: true, write: true, disabled: !fresh.length, onClick: () => apply(false) });
      const repBtn = A.btn(rows.length ? 'Replace ' + dset.map(x => x.slice(0, 3)).join(', ') + ' · removes ' + gone : 'Replace', { danger: true, ghost: true, write: true, disabled: !rows.length, title: 'Every row of those days goes, and these take their place', onClick: () => apply(true) });
      return { pre, addBtn, repBtn };
    }

    function pasteRows() {
      const day = dayName(view) || (days[0] || {}).name;
      const ta = h('textarea', { class: 'ap-textarea cx-paste', rows: '8', placeholder: day + '\n7–9:45 PM Hymn sing, Chapel Auditorium, Singing\n9:30–10 PM Prayer meeting, Chapel Auditorium, Prayer', 'aria-label': 'Rows to paste' });
      const box = h('div', { 'aria-live': 'polite' });
      const foot = h('div', { class: 'ap-row' });
      // Lines whose title has a comma wait, like the add line; one tap keeps every such comma.
      let keepCommas = false;
      const show = () => {
        A.clear(box); A.clear(foot);
        const got = ta.value.trim() ? S.paste(ta.value, Object.assign(rctx(day), { keepCommas })) : null;
        if (!got) { foot.append(A.btn('Add rows', { primary: true, disabled: true }), A.btn('Cancel', { ghost: true, onClick: () => sp.close() })); return; }
        const pv = previewAdd(got, 'Paste');
        const commas = got.unread.filter(u => u.comma).length;
        if (commas) box.appendChild(h('p', { class: 'ap-help cs-commas' }, K.plural(commas, 'line') + ' with a comma in the title · ', K.link('Keep commas in titles', () => { keepCommas = true; show(); }, { title: 'Read the words before the list pieces as the title, commas and all' })));
        box.appendChild(pv.pre);
        foot.append(pv.addBtn, pv.repBtn, A.btn('Cancel', { ghost: true, onClick: () => sp.close() }));
      };
      ta.addEventListener('input', show);
      sp.open({ title: 'Paste rows', body: h('div', null, K.field('Rows', ta, { help: 'A line a row, in the add line’s format · A day’s name starts its rows · Or a spreadsheet’s rows with their header' }), box), foot: [foot] });
      show();
      ta.focus();
    }

    // An import: with the Export's ID column, matched by ID only (docs/scope/05 Q11); without one, like
    // Paste rows. Everything it would do is shown first; Apply is one step of Undo.
    function importFile() {
      K.pick('.csv,.tsv,.txt,.xlsx').then(file => file && ED.files.read(file).then(got => Object.assign(got, { name: file.name }))).then(got => {
        if (!got) return;
        const cells = got.grid.filter(r => r.some(c => String(c).trim()));
        const g = S.grid(cells, rctx());
        if (g.header.indexOf('title') < 0) { A.toast('No What column · Export first, then fill it in'); return; }
        if (!g.hasId) {
          const pv = previewAdd(g, 'Import');
          sp.open({ title: 'Import · ' + file0(got), body: pv.pre, foot: [pv.addBtn, pv.repBtn, A.btn('Cancel', { ghost: true, onClick: () => sp.close() })] });
          return;
        }
        const FIELDS = ['day', 'start', 'end', 'title', 'place', 'audience', 'kind', 'note', 'call_in', 'recorded', 'display', 'last_day', 'print_note'];
        // A problem the file has with a value the site already keeps the same way (words for a time,
        // a place the campus list lacks) isn't a change: that field is left as it is. Any other problem
        // leaves the whole row as it is, said in the preview, never half applied.
        const OF = { time: ['start', 'end'], place: ['place'], day: ['day'], audience: ['audience'], last_day: ['last_day'] };
        const unchanged = (e, cur) => {
          if (e.raw === undefined || !cur) return false;
          if (e.k === 'time') return ['start', 'end'].every(k => { const w = (e.raw || {})[k] || ''; return lc(w) === lc(cur[k]) || (mins(w) != null && mins(w) === mins(cur[k])); });
          return lc(e.raw) === lc(cur[e.k === 'last_day' ? 'last_day' : e.k]);
        };
        const changed = [], added = [], unread = g.unread.slice(), left = [];
        const seen = new Set();
        const rowWords = r => dayShort(r.day) + ' · ' + (r.title || 'Untitled');
        g.rows.forEach(x => {
          const n = x.row, cur = n._id ? f.get(n._id) : null;
          if (cur && seen.has(cur._id)) { unread.push({ text: rowWords(cur), why: 'Twice in the file · The first kept' }); return; }
          if (cur) seen.add(cur._id);
          const errs = (n._errs || []).filter(e => !unchanged(e, cur));
          if (errs.length) { unread.push({ text: cur ? rowWords(cur) : x.line, why: errs.map(e => e.why).join(' · ') }); return; }
          if (!cur) {
            if (!n.start || !n.end) { unread.push({ text: x.line, why: 'Set exact time' }); return; }
            added.push(n); return;
          }
          const skip = new Set();
          (n._errs || []).forEach(e => (OF[e.k] || []).forEach(k => skip.add(k)));
          const out = {};
          FIELDS.forEach(k => {
            if (skip.has(k) || n[k] === undefined) return;
            if (k === 'start' || k === 'end') { if (mins(n[k]) !== mins(cur[k])) out[k] = n[k]; return; }
            if (k === 'kind') { if (S.kindKey(n.kind) !== S.kindKey(cur.kind)) out.kind = n.kind; return; }
            if (k === 'audience') { if (audOf(n.audience) !== audOf(cur.audience)) out.audience = audOf(n.audience); return; }
            if (k === 'call_in') { if ((n.call_in === 'yes') !== (cur.call_in === 'yes')) out.call_in = n.call_in; return; }
            if (k === 'recorded') { if ((lc(n.recorded) === 'no') !== (lc(cur.recorded) === 'no')) out.recorded = n.recorded; return; }
            if (k === 'display') { if (lc(n.display) !== lc(cur.display) && !(lc(n.display) === '' && lc(cur.display) === 'timeline')) out.display = n.display; return; }
            if (k === 'place') { if (lc(n.place) !== lc(cur.place)) out.place = n.place; return; }
            if (String(n[k] == null ? '' : n[k]).trim() !== String(cur[k] == null ? '' : cur[k]).trim()) out[k] = n[k];
          });
          // A new kind lists the row its way (as on the screen), unless the file says how, or it's
          // Committees only.
          if (out.kind !== undefined && out.display === undefined && lc(cur.display) !== 'private' && S.listedOf(out.kind) !== lc(cur.display)) out.display = S.listedOf(out.kind);
          if (n._kindRaw && lc(n._kindRaw) !== lc(cur.kind)) left.push({ text: rowWords(cur), why: 'Kind not on the list · ' + n._kindRaw });
          if (n._displayRaw) left.push({ text: rowWords(cur), why: 'Shown as · ' + n._displayRaw + ' · Follows the kind' });
          const pl = placeOf(out.place !== undefined ? out.place : cur.place);
          if (n._building && lc(n._building) !== lc((pl || {}).building)) left.push({ text: rowWords(cur), why: 'Building follows Where · ' + n._building });
          if (out.start || out.end) out.sort_time = '';
          if (Object.keys(out).filter(k => k !== 'sort_time').length) changed.push({ id: cur._id, title: cur.title, day: cur.day, fields: out, was: cur });
        });
        const fileDays = new Set(g.rows.map(x => lc(x.row.day)));
        const removed = f.rows.filter(c => fileDays.has(lc(c.day)) && !seen.has(c._id));
        const take = new Set();
        const lines = [K.plural(changed.length, 'changed', 'changed') + ' · ' + K.plural(added.length, 'new', 'new') + ' · ' + K.plural(removed.length, 'not in the file', 'not in the file') + (unread.length ? ' · ' + K.plural(unread.length, 'line') + ' not read' : '') + (left.length ? ' · ' + left.length + ' left as is' : '')];
        // Each change said with what it was and what it becomes, so a dropped edit can't hide.
        const val = (k, v) => {
          v = v == null ? '' : String(v);
          if (k === 'start' || k === 'end') return mins(v) != null ? S.fmt(mins(v)) : v || '—';
          if (k === 'place') return v ? ((placeOf(v) || {}).name || v) : '—';
          if (k === 'kind') return v ? (S.kindLabel(v) || v) : '—';
          if (k === 'audience') return audLabel(v);
          if (k === 'call_in') return v === 'yes' ? 'Yes' : 'No';
          if (k === 'recorded') return lc(v) === 'no' ? 'No' : 'Yes';
          if (k === 'display') return S.LISTED[lc(v)] || v || 'In the day';
          if (k === 'day') return v ? v.slice(0, 3) : '—';
          if (k === 'last_day') return v ? v.slice(0, 3) : 'One day';
          return v ? '“' + (v.length > 28 ? v.slice(0, 27) + '…' : v) + '”' : '—';
        };
        const ul = h('ul', { class: 'cx-prevlist' });
        changed.forEach(c => ul.appendChild(h('li', null, h('span', { class: 'cx-prev__t', text: 'Changed' }), h('span', { text: dayShort(c.day) + ' · ' + c.title }),
          h('span', { class: 'ap-quiet cs-prev__what', text: Object.keys(c.fields).filter(k => k !== 'sort_time').map(k => (FW[k] || k) + ' ' + val(k, c.was[k]) + ' → ' + val(k, c.fields[k])).join(' · ') }))));
        added.forEach(r => ul.appendChild(h('li', null, h('span', { class: 'cx-prev__t', text: 'New' }), h('span', { text: (r.day || '').slice(0, 3) + ' ' + timeText(r) + ' ' + r.title }))));
        removed.forEach(x => { const cb = h('input', { type: 'checkbox', class: 'ap-check' }); cb.addEventListener('change', () => { if (cb.checked) take.add(x._id); else take.delete(x._id); }); ul.appendChild(h('li', null, h('label', { class: 'ap-switch' }, cb, h('span', { text: 'Remove · ' + (x.day || '').slice(0, 3) + ' ' + (timeText(x) || '') + ' ' + x.title })))); });
        unread.slice(0, 30).forEach(x => ul.appendChild(h('li', { class: 'is-bad' }, h('span', { class: 'cx-prev__t', text: 'Not read' }), h('span', { text: x.text }), h('span', { text: '· ' + x.why }))));
        left.slice(0, 30).forEach(x => ul.appendChild(h('li', null, h('span', { class: 'cx-prev__t', text: 'Left as is' }), h('span', { text: x.text }), h('span', { class: 'ap-quiet', text: '· ' + x.why }))));
        if (unread.length) lines.push('Rows not read stay as they are · Fix them in the file, then import again');
        K.confirm(sp, {
          title: 'Import · ' + file0(got), lines, field: ul, actLabel: 'Apply',
          act: () => {
            f.batch('Import', () => {
              changed.forEach(c => f.set(c.id, c.fields));
              added.forEach(r => f.add(newRow(r)));
              take.forEach(id => f.remove(id));
            });
            return Promise.resolve();
          },
          onDone: () => { drawMain(); head(); A.toast('Imported · ' + (changed.length + added.length + take.size) + ' changes', { undo: () => { K.replay(f, 'undo'); drawMain(); } }); }
        });
      }).catch(err => A.toast(err && err.message ? err.message : 'Not read'));
    }
    const file0 = got => String(got.name || 'File').replace(/\.(csv|tsv|txt|xlsx)$/i, '').slice(0, 40);

    function exportFile(fmt) {
      fetchFile('app/' + y + '/schedule/export?format=' + fmt, y + ' Conference schedule.' + fmt)
        .then(() => A.toast('Exported · ' + K.plural(f.rows.length, 'row')), () => A.toast('Not exported'));
    }

    /* ---------------------------------------------------------- keeping up */

    offs.push(K.on(f, 'change', e => {
      head(); drawViews();
      drawList();
      if (panelIssues) panelIssues();
      if (e && e.server) refreshLive();
    }));
    offs.push(K.on(f, 'remote', e => {
      drawMain();
      if (sel && e.changed.indexOf(sel) > -1 && !(sp.panel.contains(document.activeElement) && document.activeElement.matches('input, textarea'))) openRow(sel, { keep: true });
      if (sel && e.gone.indexOf(sel) > -1) { sp.close(true); sel = ''; A.toast('Removed by someone else'); }
      refreshLive();
    }));
    offs.push(K.on(f, 'conflict', cf => { if (sel && cf.some(c => c.id === sel)) openRow(sel, { keep: true }); A.toast('Changed by ' + (cf[0].by || 'someone else') + ' first · Choose at the field'); }));
    offs.push(K.on(f, 'ids', e => { if (sel === e.from) { sel = e.to; A.setParams({ id: sel }); } if (ticked.has(e.from)) { ticked.delete(e.from); ticked.add(e.to); } }));
    offs.push(K.undoKeys(dir => { K.replay(f, dir); drawMain(); if (sel && f.get(sel)) openRow(sel, { keep: true }); else if (sel) sp.close(true); }));
    const keys = e => {
      if (e.target.closest && e.target.closest('input, textarea, [contenteditable]')) return;
      if (e.metaKey || e.ctrlKey || e.altKey || document.querySelector('.ap-palette')) return;
      if (e.key === 'n' || e.key === 'N') { const i = addBox.querySelector('.cx-add__in'); if (i) { e.preventDefault(); i.focus(); } }
      if (e.key === '/') { const i = views.querySelector('.cx-find'); if (i) { e.preventDefault(); i.focus(); } }
    };
    document.addEventListener('keydown', keys);
    offs.push(() => document.removeEventListener('keydown', keys));

    head();
    drawMain();
    if (sel && f.get(sel)) openRow(sel, { keep: true });
    else if (p.at !== 'grid') { const i = addBox.querySelector('.cx-add__in'); if (i && K.wide()) i.focus({ preventScroll: true }); }
  }
})();
