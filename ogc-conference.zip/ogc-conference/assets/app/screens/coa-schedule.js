/*
 * coa-schedule.js — Schedule: the year's rows, a day at a time, with the chosen row beside the list.
 *
 * Built for someone who does this once a year, on a laptop:
 *   - a line is read as it's written ("7–9 Hymn sing, Barnes"), and what was understood is said under it
 *     before Enter adds it (a guessed AM or PM can be switched with one tap; a line with no time says so);
 *   - the list is the day's rows; a row opens beside it with What, When, Day, Where, For and Note, the
 *     rest under More; every change saves row by row (ED.Rows), so two people never overwrite each other;
 *   - warnings sit on the row and at the field: two things in one room at once, ends before it starts,
 *     a place this campus doesn't have, a time guessed;
 *   - rows carried from last year that change most years are "To check", with last year's line beside;
 *   - once the schedule is public, changes wait for Publish: the title row says "3 not live · Publish",
 *     and those rows are marked (module-coa-app.php keeps the copy visitors read);
 *   - Paste rows, Import and Export under File; Day view on a laptop, every block tall enough for its words.
 */
(function () {
  'use strict';
  const A = window.OGC_APP, K = window.OGC_COA, O = window.OGC, ED = window.ED, W = window.OGC_WP || {};
  if (!A || !K || !ED || !ED.read) return;
  const h = A.h, R = ED.read;
  const lc = s => String(s == null ? '' : s).trim().toLowerCase();
  const AUD = [['All', 'Everyone'], ['Conference', 'Conference'], ['Preteens', 'Preteens'], ['Young Folks', 'Young Folks']];
  const audOf = a => (AUD.find(x => lc(x[0]) === lc(a)) || AUD[1])[0];
  const audLabel = a => (AUD.find(x => lc(x[0]) === lc(a)) || AUD[1])[1];
  const DISPLAY = [['', 'In the day', 'Listed at its time in the day'], ['all day', 'Open now', 'Under Open now on the page, not in the day'], ['desk', 'Desk hours', 'With the desks’ hours, not in the day'], ['nightly', 'Every night', 'Once, with the nightly rows']];
  const KINDS = [['worship', 'Worship'], ['meal', 'Meal'], ['meeting', 'Meeting'], ['teaching', 'Teaching'], ['singing', 'Singing'], ['activity', 'Activity'], ['devotion', 'Devotion'], ['registration', 'Registration'], ['council', 'Council'], ['communion', 'Communion'], ['snack', 'Snack'], ['prayer', 'Prayer'], ['pickup', 'Pick-up'], ['display', 'Display'], ['social', 'Social'], ['quiet', 'Quiet time'], ['lodging', 'Lodging desk'], ['open', 'Open hours'], ['on_call', 'On call']];
  const SHARES = /^(open|display|on_call|lodging|meal|snack|prayer)$/;
  const SIT = /^(worship|council|communion|teaching|meeting|singing|devotion|prayer|meal)$/;
  const LONG = 210; // 3½ hours and more: a row that runs (a bar in Day view; never a room clash)

  /* ------------------------------------------------------------ reading a row */

  const mins = v => R.minutes(v);
  const lenOf = r => { const a = mins(r.start), b = mins(r.end); return a == null || b == null ? 0 : (b > a ? b - a : b + 1440 - a); };
  const sortKey = r => { const a = mins(r.start); return a != null ? a : mins(r.sort_time) != null ? mins(r.sort_time) : r.start ? 1439 : -1; };
  // "2–8 PM", "Noon–11 PM", "After Communion", "7 PM until finished"; '' when it has no time.
  function timeText(r) {
    const a = mins(r.start), b = mins(r.end);
    if (a == null) return r.start ? String(r.start) : '';
    if (/^(\?|until finished|until done)$/i.test(String(r.end || '').trim())) return R.fmt(a) + ' until finished';
    return R.span(a, b == null ? null : (b <= a ? b + 1440 : b));
  }
  const kindOf = r => r.kind || R.guessKind(r.title) || '';
  const isDay = (days, v) => days.some(x => lc(x.name) === v);

  /* ------------------------------------------------------------ the screen */

  A.screen({
    id: 'schedule', title: 'Schedule', icon: 'clock', section: 'own', who: ['coa'],
    render(ctx) {
      const y = ctx.params.year, offs = [];
      let alive = true;
      ctx.head('Schedule', '', []);
      K.loading(ctx.body);
      K.load(y).then(d => {
        const f = K.rows(y, 'schedule', d);
        const prevY = d.ov && d.ov.prev ? d.ov.prev.year : '';
        return Promise.all([f.ready, prevY ? K.bundle(prevY) : null, liveOf()]).then(([, pd, lv]) => ({ d, f, pd, lv }));
      }).then(st => { if (alive) draw(ctx, st, offs); }, err => { if (alive) K.failed(ctx.body, err); });
      return () => { alive = false; offs.forEach(fn => fn()); };
    }
  });
  const liveOf = () => A.api('GET', 'live?f=schedule').then(r => r.schedule).catch(() => null);

  function draw(ctx, st, offs) {
    const { d, f } = st;
    const y = d.year, p = ctx.params;
    const ro = !!(A.readonly || f.opts.readOnly);
    const days = d.days.length ? d.days : Array.from(new Set(f.rows.map(r => r.day).filter(Boolean))).map(name => ({ name, date: '' }));
    const prevRows = st.pd ? ((st.pd.schedule || {}).rows || []) : [];
    let lv = st.lv;
    let view = lc(p.v) || '';
    if (!view || !(isDay(days, view) || ['check', 'live', 'all', 'find'].indexOf(view) > -1)) view = days[0] ? lc(days[0].name) : 'all';
    let layout = p.at === 'grid' ? 'grid' : 'table';
    let sel = p.id || '';
    let find = '';
    const places = () => d.rowsOf('places').filter(x => x.code).map(x => ({ code: x.code, name: x.name || x.code, building: x.building || '' }));
    const placeOf = code => { const c = lc(code); return c ? places().find(x => lc(x.code) === c) || null : null; };
    const dayName = v => (days.find(x => lc(x.name) === lc(v)) || {}).name || '';
    A.clear(ctx.body);
    const sp = ctx.split();
    sp.el.classList.add('cx-split');
    const status = K.status([f], offs);

    /* ---------------------------------------------------------- the reader's context */

    const last = {};
    prevRows.forEach(r => { const m = mins(r.start); if (m != null) (last[lc(r.title)] = last[lc(r.title)] || []).push(m); });
    const rctx = (day, extra) => Object.assign({ days, places: places(), day: day || dayName(view) || (days[0] || {}).name, titles: Array.from(new Set(f.rows.map(r => r.title).filter(Boolean))), last, dayRows: f.rows.filter(r => r.day === (day || dayName(view))) }, extra || {});

    /* ---------------------------------------------------------- what doesn't add up */

    function clashable(x) {
      const a = mins(x.start), b = mins(x.end);
      if (a == null || b == null || /^(all day|desk|nightly|private)$/.test(x.display || '')) return false;
      return !SHARES.test(kindOf(x)) && lenOf(x) < LONG;
    }
    function clashWith(r) {
      if (!r.place || !clashable(r)) return null;
      const a = mins(r.start), b = a + lenOf(r);
      return f.rows.find(x => x !== r && x._id !== r._id && x.day === r.day && lc(x.place) === lc(r.place) && clashable(x) && mins(x.start) < b && mins(x.start) + lenOf(x) > a) || null;
    }
    // [{ text, k (the field), tone: 'bad' | 'soft' }]
    function issues(r) {
      const out = [], a = mins(r.start), b = mins(r.end), kind = kindOf(r);
      if (r.day && days.length && !isDay(days, lc(r.day))) out.push({ text: 'Not a day of this Conference', k: 'day', tone: 'bad' });
      if (a != null && b != null && b <= a && b > 300) out.push({ text: 'Ends before it starts', k: 'start', tone: 'bad' });
      if (r._guess && a != null) out.push({ text: 'Time guessed · ' + (a < 720 ? 'AM' : 'PM') + '?', k: 'start', tone: 'soft' });
      if (!r.start && !r.sort_time && !/^(all day|desk|nightly)$/.test(r.display || '')) out.push({ text: 'No time', k: 'start', tone: 'soft' });
      if (r.place && !placeOf(r.place)) out.push({ text: 'Not a place at this campus · ' + r.place, k: 'place', tone: 'bad' });
      if (!r.place && SIT.test(kind) && r.display !== 'private') out.push({ text: 'No place', k: 'place', tone: 'soft' });
      const c = clashWith(r);
      if (c) out.push({ text: 'Same room · ' + c.title + ' ' + timeText(c), k: 'place', tone: 'bad', go: c._id });
      if (/!/.test((r.title || '') + (r.note || ''))) out.push({ text: 'Exclamation mark', k: 'note', tone: 'soft' });
      if (/sermonaudio|youtube|youtu\.be|facebook/i.test(r.note || '')) out.push({ text: 'Outside sermon link', k: 'note', tone: 'bad' });
      return out;
    }

    /* ---------------------------------------------------------- live or not */

    const posted = d.S.schedule_posted || '';
    const isPublic = () => !!(lv && lv.public);
    const notLive = () => isPublic() ? new Set([].concat(lv.added, lv.changed)) : new Set();
    const nNotLive = () => isPublic() ? lv.added.length + lv.changed.length + lv.removed.length : 0;
    let liveT = 0;
    const refreshLive = () => { clearTimeout(liveT); liveT = setTimeout(() => liveOf().then(x => { if (x) { lv = x; head(); drawViews(); markRows(); } }), 900); };

    /* ---------------------------------------------------------- the title row */

    function head() {
      const n = f.rows.length, look = f.rows.filter(r => r._look).length, nl = nNotLive();
      const fact = d.held ? 'Ended ' + K.md(d.row.end) + ' · Read only'
        : !days.length ? 'No dates yet'
        : isPublic() ? 'Public since ' + K.mdY(posted, y) + ' · ' + K.plural(n, 'row')
        : posted && posted !== K.NOT_YET && posted > d.today ? 'Public ' + K.mdY(posted, y) : 'Not public · ' + K.plural(n, 'row');
      const acts = [status];
      acts.push(K.see('?year=' + y + '&view=full', 'Preview'));
      acts.push(A.btn('File', { ghost: true, icon: 'down', onClick: e => fileMenu(e.currentTarget) }));
      if (!d.held && days.length && !ro) {
        if (isPublic() && nl) acts.push(h('span', { class: 'ap-tag ap-tag--tan cx-notlive', title: 'Changed since ' + K.md((lv.at || '').slice(0, 10)) + ' · Visitors see the schedule as it was', text: nl + ' not live' }));
        // The season decides the one filled button: rows carried from last year are checked first, then
        // Publish (due in January, not October).
        // Check opens the first row to check; Looks right moves on to the next ("3 of 19").
        if (look) acts.push(A.btn('Check ' + look, { primary: true, write: true, title: 'Carried from last year · One at a time, with last year’s beside it', onClick: () => { go('check'); const first = rowsInView()[0]; if (first) openRow(first._id); } }));
        if (!isPublic() || nl) acts.push(A.btn('Publish', { primary: !look, write: true, onClick: publish }));
      }
      ctx.head('Schedule', fact, acts);
    }

    function publish() {
      const look = f.rows.filter(r => r._look), noTime = f.rows.filter(r => !r.start && !r.sort_time && !r.display);
      const clashes = f.rows.filter(r => clashWith(r));
      const left = [];
      if (look.length) left.push({ t: look.length + ' to check', go: () => go('check') });
      if (clashes.length) left.push({ t: K.plural(clashes.length, 'room clash', 'room clashes'), go: () => { go(lc(clashes[0].day)); openRow(clashes[0]._id); } });
      if (noTime.length) left.push({ t: K.plural(noTime.length, 'row') + ' with no time', go: () => { go(lc(noTime[0].day)); openRow(noTime[0]._id); } });
      if (isPublic()) {
        const titles = [].concat(lv.added, lv.changed).map(id => (f.get(id) || {}).title).filter(Boolean).slice(0, 6);
        const gone = lv.removed.map(x => x.title).filter(Boolean).slice(0, 4);
        K.confirm(sp, {
          title: 'Publish ' + K.plural(nNotLive(), 'change'),
          lines: ['On the Conference page, the guide and the printout, for everyone · “Schedule updated” shows ' + K.md(d.today)].concat(titles.length ? ['Changed · ' + titles.join(' · ')] : [], gone.length ? ['Removed · ' + gone.join(' · ')] : []),
          left, actLabel: left.length ? 'Publish anyway' : 'Publish',
          act: () => f.flush().then(() => K.coa(y, 'publish', { part: 'schedule', act: 'update' })),
          onDone: () => { A.toast('Published · ' + K.plural(nNotLive(), 'change')); liveOf().then(x => { lv = x; head(); drawMain(); }); }
        });
        return;
      }
      K.confirm(sp, {
        title: 'Publish the schedule',
        lines: ['Now · On the Conference page, the guide and the printout, for everyone', 'Later changes wait for Publish'],
        left, actLabel: left.length ? 'Publish anyway' : 'Publish',
        act: () => f.flush().then(() => K.coa(y, 'publish', { part: 'schedule', act: 'publish' })),
        onDone: r => { d.S.schedule_posted = (r && r.settings && r.settings.schedule_posted) || d.today; A.toast('Published · The schedule is public'); liveOf().then(x => { lv = x; head(); drawMain(); }); }
      });
    }

    function unpublish() {
      K.confirm(sp, {
        title: 'Unpublish the schedule', danger: true, reason: true,
        lines: ['It comes off the Conference page, the guide and the printout'],
        actLabel: 'Unpublish',
        act: reason => K.coa(y, 'publish', { part: 'schedule', act: 'unpublish', reason }),
        onDone: () => { d.S.schedule_posted = K.NOT_YET; A.toast('Unpublished · Not public'); liveOf().then(x => { lv = x; head(); drawMain(); }); }
      });
    }

    function fileMenu(btn) {
      const items = [];
      if (!ro && !d.held && days.length) items.push({ label: 'Paste rows', run: pasteRows });
      if (!ro && !d.held && days.length) items.push({ label: 'Import', run: importFile });
      items.push({ label: 'Export', run: exportFile });
      items.push({ label: 'Printable', run: () => window.open((W.base || '/annual-conference/') + 'schedule/?year=' + y, '_blank', 'noopener') });
      // The call-in list (each service's playback number) is read from the schedule: its own page.
      items.push({ label: 'Call-in list', run: () => { location.href = (W.base || '/annual-conference/') + 'lists/?year=' + y + '&view=callin&from=' + encodeURIComponent((W.base || '/annual-conference/') + 'app/?year=' + y + '&s=schedule'); } });
      if (isPublic() && !ro && !d.held) items.push({ label: 'Unpublish', run: unpublish });
      A.menu(btn, items);
    }

    /* ---------------------------------------------------------- views */

    const views = h('div', { class: 'ap-views cx-views' });
    const addBox = h('div', { class: 'cx-add' });
    const listEl = h('div', { class: 'cx-list' });
    sp.main.append(views, addBox, listEl);

    let checkFrom = 0;
    function go(v) { view = v; A.setParams({ v: view, id: sel, at: layout === 'grid' ? 'grid' : '' }); drawMain(); }

    function rowsInView() {
      const nl = notLive();
      let rows = f.rows.slice();
      if (find) { const w = lc(find); rows = rows.filter(r => lc([r.title, r.note, r.place, (placeOf(r.place) || {}).name].join(' ')).indexOf(w) > -1); }
      else if (view === 'check') rows = rows.filter(r => r._look);
      else if (view === 'live') rows = rows.filter(r => nl.has(r._id));
      else if (view !== 'all') rows = rows.filter(r => lc(r.day) === view);
      const di = n => { const i = days.findIndex(x => lc(x.name) === lc(n)); return i < 0 ? 99 : i; };
      return rows.sort((a, b) => di(a.day) - di(b.day) || sortKey(a) - sortKey(b));
    }

    function drawViews() {
      A.clear(views);
      const chips = days.map(x => ({ id: lc(x.name), label: x.name.slice(0, 3), n: f.rows.filter(r => lc(r.day) === lc(x.name)).length, title: x.date ? K.wd(x.date) : x.name }));
      const look = f.rows.filter(r => r._look).length, nl = nNotLive();
      if (look) chips.push({ id: 'check', label: 'To check', n: look });
      if (nl) chips.push({ id: 'live', label: 'Not live', n: nl });
      chips.push({ id: 'all', label: 'All', n: f.rows.length });
      const bar = A.views(chips, find ? '' : view, id => { find = ''; findIn.value = ''; go(id); });
      bar.querySelectorAll('.ap-chip').forEach((b, i) => { if (chips[i].title) b.title = chips[i].title; });
      const findIn = h('input', { class: 'ap-input cx-find', type: 'search', placeholder: 'Find', 'aria-label': 'Find in every day', value: find });
      findIn.addEventListener('input', () => { find = findIn.value.trim(); drawList(); bar.querySelectorAll('.ap-chip').forEach(b => b.setAttribute('aria-pressed', String(!find && b === bar.querySelectorAll('.ap-chip')[chips.findIndex(c => c.id === view)]))); });
      findIn.addEventListener('keydown', e => { if (e.key === 'Escape') { findIn.value = ''; find = ''; drawList(); findIn.blur(); } });
      const tools = h('div', { class: 'cx-views__tools' }, findIn);
      if (isDay(days, view) && K.wide()) {
        tools.appendChild(h('div', { class: 'cx-seg', role: 'group', 'aria-label': 'Layout' },
          h('button', { type: 'button', 'aria-pressed': String(layout === 'table'), title: 'Table', on: { click: () => { layout = 'table'; go(view); } } }, A.icon('list', 15), h('span', { class: 'ap-sr', text: 'Table' })),
          h('button', { type: 'button', 'aria-pressed': String(layout === 'grid'), title: 'Day view', on: { click: () => { layout = 'grid'; go(view); } } }, A.icon('grid', 15), h('span', { class: 'ap-sr', text: 'Day view' }))));
      }
      views.append(bar, tools);
    }

    /* ---------------------------------------------------------- the line that adds a row */

    function drawAdd() {
      A.clear(addBox);
      const day = dayName(view);
      addBox.hidden = ro || d.held || !day || !!find;
      if (addBox.hidden) return;
      const input = h('input', { class: 'ap-input cx-add__in', placeholder: 'Add to ' + day + ' · 7–9 Hymn sing, Barnes', 'aria-label': 'Add a row to ' + day, autocomplete: 'off', 'aria-describedby': 'cx-add-echo' });
      const echo = h('div', { class: 'cx-add__echo', id: 'cx-add-echo', 'aria-live': 'polite' });
      let read = null, flip = false;
      const say = () => {
        A.clear(echo);
        const t = input.value.trim();
        if (!t) { read = null; return; }
        read = R.line(t, rctx(day));
        const r = read.row;
        if (flip && mins(r.start) != null) shift(r);
        const a = mins(r.start);
        const bits = [];
        if (read.moved) bits.push(h('span', { class: 'ap-tag ap-tag--tan', text: r.day }));
        bits.push(a != null || r.start ? h('span', { class: 'ap-tag', text: timeText(r) || r.start }) : h('span', { class: 'ap-tag ap-tag--tan', text: 'No time' }));
        if (r.title) bits.push(h('span', { class: 'cx-add__title', text: r.title }));
        if (r.place) bits.push(h('span', { class: 'ap-tag', text: (placeOf(r.place) || {}).name || r.place }));
        if (read.unknown) bits.push(h('span', { class: 'ap-tag ap-tag--late', title: 'Kept in the note', text: 'Not a place · ' + read.unknown }));
        if (lc(r.audience) !== 'conference') bits.push(h('span', { class: 'ap-tag', text: audLabel(r.audience) }));
        if (read.guess && a != null) bits.push(h('button', { type: 'button', class: 'cx-link', on: { click: () => { flip = !flip; say(); input.focus(); } } }, (a < 720 ? 'PM' : 'AM') + ' instead'));
        bits.push(h('span', { class: 'ap-quiet cx-add__enter', text: '↵ Add' }));
        echo.append(...bits);
      };
      input.addEventListener('input', () => { flip = false; say(); });
      input.addEventListener('keydown', e => {
        if (e.key === 'Escape') { input.value = ''; say(); input.blur(); return; }
        if (e.key !== 'Enter' || !read || !read.row.title) return;
        e.preventDefault();
        const r = Object.assign({}, read.row);
        if (flip && mins(r.start) != null) shift(r);
        if (read.guess && mins(r.start) != null && !flip) r._guess = '1';
        if (read.unknown && !r.note) r.note = read.unknown;
        delete r.by;
        const id = f.add(r, { label: 'Add ' + r.title });
        A.toast('Added · ' + r.title + ' · ' + (r.day || day).slice(0, 3) + (timeText(r) ? ' ' + timeText(r) : ''), { undo: () => K.replay(f, 'undo') });
        input.value = ''; flip = false; say();
        if (lc(r.day) !== view) go(lc(r.day));
        sel = id; drawList(); openRow(id);
        setTimeout(() => { const i = addBox.querySelector('.cx-add__in'); if (i) i.focus(); }, 0);
      });
      addBox.append(input, echo);
    }
    // A guessed half of the day, switched.
    function shift(r) {
      const a = mins(r.start), b = mins(r.end), by = a < 720 ? 720 : -720;
      r.start = R.fmt((a + by + 1440) % 1440);
      if (b != null) r.end = R.fmt((b + by + 1440) % 1440);
    }

    /* ---------------------------------------------------------- the list */

    function drawMain() { drawViews(); drawAdd(); drawList(); }

    function drawList() {
      A.clear(listEl);
      const rows = rowsInView();
      if (layout === 'grid' && isDay(days, view) && !find && K.wide()) { listEl.appendChild(grid(rows)); return; }
      if (!rows.length) {
        listEl.appendChild(A.empty({
          inset: true,
          title: find ? 'No rows with “' + find + '”' : view === 'check' ? 'Nothing to check' : view === 'live' ? 'Everything is live' : !days.length ? 'No dates yet' : 'Nothing on ' + (dayName(view) || 'this day'),
          line: !days.length ? 'Set the dates first' : !find && isDay(days, view) && !ro ? 'Type a line above, or File › Paste rows' : '',
          action: !days.length ? A.link({ s: 'dates', v: '', id: '' }, 'Dates and place', 'ap-btn') : null
        }));
        return;
      }
      const nl = notLive();
      const groups = !isDay(days, view) || find;
      const tb = h('tbody');
      let lastDay = null;
      rows.forEach(r => {
        if (groups && r.day !== lastDay) { lastDay = r.day; tb.appendChild(h('tr', { class: 'ap-tr--group' }, h('td', { colspan: '4', text: r.day || 'No day' }))); }
        const iss = issues(r), bad = iss.find(x => x.tone === 'bad');
        const t = timeText(r);
        const tr = h('tr', { 'data-key': r._id, 'aria-selected': String(r._id === sel), tabindex: '-1', class: (r.display === 'private' ? 'cx-tr--private ' : '') + (nl.has(r._id) ? 'cx-tr--notlive' : '') },
          h('td', { class: 'ap-td--nowrap cx-td--when' }, t ? t : h('span', { class: r.display ? 'ap-quiet' : 'cx-warn-soft', text: r.display === 'all day' ? 'Open now' : r.display === 'desk' ? 'Desk hours' : r.display === 'nightly' ? 'Every night' : 'No time' })),
          h('td', { class: 'cx-td--what' },
            h('span', { class: 'ap-cell-title', text: r.title || 'Untitled' }),
            marks(r, nl, iss),
            view === 'check' && r._look ? h('span', { class: 'ap-cell-sub', text: whyCheck(r) }) : r.note ? h('span', { class: 'ap-cell-sub', text: r.note }) : null),
          h('td', { class: 'cx-td--where' }, r.place ? h('span', { class: placeOf(r.place) ? '' : 'cx-warn', text: (placeOf(r.place) || {}).name || r.place }) : null),
          h('td', { class: 'ap-td--wide ap-td--muted cx-td--for', text: audLabel(r.audience) }));
        if (bad) tr.title = bad.text;
        tb.appendChild(tr);
      });
      const table = h('table', { class: 'ap-table cx-table', 'aria-label': 'Rows' },
        h('thead', null, h('tr', null, ['When', 'What', 'Where', 'For'].map((c, i) => h('th', { scope: 'col', class: i === 3 ? 'ap-td--wide cx-td--for' : i === 2 ? 'cx-td--where' : null, text: c })))), tb);
      const wrap = h('div', { class: 'ap-tablewrap', tabindex: '0', role: 'group', 'aria-label': 'Rows · Arrow keys move · Enter opens' }, table);
      tb.addEventListener('click', e => { const tr = e.target.closest('tr[data-key]'); if (tr) openRow(tr.dataset.key); });
      wrap.addEventListener('keydown', e => {
        const trs = [...tb.querySelectorAll('tr[data-key]')];
        let i = trs.findIndex(x => x.dataset.key === sel);
        if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
          e.preventDefault();
          i = e.key === 'ArrowDown' ? Math.min(trs.length - 1, i + 1) : Math.max(0, i - 1);
          if (trs[i]) { openRow(trs[i].dataset.key, { keep: true }); trs[i].scrollIntoView({ block: 'nearest' }); }
        } else if (e.key === 'Enter' && trs[i]) { e.preventDefault(); const t = sp.panel.querySelector('input, textarea'); if (t) t.focus(); }
      });
      listEl.appendChild(wrap);
    }
    // Why a carried row needs a look, in a few words: what it is and whether it moved since last year.
    function whyCheck(r) {
      const was = prevRows.find(x => lc(x.title) === lc(r.title));
      const line = x => [x.day ? x.day.slice(0, 3) : '', timeText(x), (placeOf(x.place) || {}).name || x.place].filter(Boolean).join(' · ');
      const pk = (d.picked && d.picked.from) || (d.ov && d.ov.prev ? d.ov.prev.year : 'last year');
      const k = (kindOf(r) || '').replace(/^\w/, c => c.toUpperCase());
      return [r._look === 'unsure' ? 'Not sure' : '', k, was ? (line(was) === line(r) ? 'Same as ' + pk : 'Moved since ' + pk) : 'New since ' + pk].filter(Boolean).join(' · ');
    }
    function marks(r, nl, iss) {
      const m = [];
      // In the To check view every row is one: the tag would say it 19 times.
      if (r._look && view !== 'check') m.push(A.tag(r._look === 'unsure' ? 'Not sure' : 'To check', 'tan'));
      if (nl.has(r._id)) m.push(h('span', { class: 'cx-dot-tan', title: 'Not live · Changed since Publish', 'aria-label': 'Not live' }));
      if (r.display === 'private') m.push(A.tag('Committees only'));
      if (r.call_in === 'yes') m.push(A.tag('Call-in'));
      const bad = iss.filter(x => x.tone === 'bad');
      if (bad.length) m.push(A.tag(bad.length > 1 ? bad.length + ' problems' : bad[0].text.split(' · ')[0], 'late'));
      else if (iss.some(x => x.k === 'start' && x.tone === 'soft' && /guessed/.test(x.text))) m.push(A.tag('Time guessed'));
      return m.length ? h('span', { class: 'cx-marks' }, m) : null;
    }
    function markRows() {
      listEl.querySelectorAll('tr[data-key]').forEach(tr => tr.setAttribute('aria-selected', String(tr.dataset.key === sel)));
    }

    /* ---------------------------------------------------------- Day view */

    // One column for each audience the day has; blocks by their real times, each at least tall enough for
    // its words (measured after drawing, and again whenever the grid's width changes); rows that run
    // 3½ hours or more are a bar at the column's edge, named in the Running line.
    function grid(rows) {
      const timed = rows.filter(r => mins(r.start) != null && !/^(all day|desk|nightly)$/.test(r.display || ''));
      const other = rows.filter(r => timed.indexOf(r) < 0);
      const cols = AUD.filter(a => timed.some(r => audOf(r.audience) === a[0]));
      if (!timed.length) return A.empty({ inset: true, title: 'Nothing timed on ' + dayName(view) });
      const lo = Math.floor(Math.min(...timed.map(r => mins(r.start))) / 60) * 60;
      const hi = Math.ceil(Math.max(...timed.map(r => mins(r.start) + Math.max(30, lenOf(r)))) / 60) * 60;
      const PX = 1.4; // per minute
      const wrap = h('div', { class: 'cx-grid' });
      wrap.style.setProperty('--cols', String(cols.length));
      const run = timed.filter(r => lenOf(r) >= LONG);
      if (run.length || other.length) wrap.appendChild(h('div', { class: 'cx-grid__run' }, h('span', { class: 'ap-label', text: 'Running' }),
        run.concat(other).map(r => h('button', { type: 'button', class: 'cx-chiprow' + (r._id === sel ? ' is-sel' : ''), 'data-key': r._id, on: { click: () => openRow(r._id) } }, h('b', { text: r.title }), ' ', timeText(r) || (r.display === 'all day' ? 'Open now' : '')))));
      const headRow = h('div', { class: 'cx-grid__heads' }, h('span'), cols.map(c => h('span', { class: 'cx-grid__head', text: c[1] })));
      const body = h('div', { class: 'cx-grid__body', style: { height: ((hi - lo) * PX) + 'px' } });
      const hours = h('div', { class: 'cx-grid__hours' });
      for (let m = lo; m <= hi; m += 60) {
        hours.appendChild(h('span', { class: 'cx-grid__hour', style: { top: ((m - lo) * PX) + 'px' }, text: R.fmt(m % 1440).replace(':00', '') }));
        body.appendChild(h('i', { class: 'cx-grid__line', style: { top: ((m - lo) * PX) + 'px' } }));
      }
      const colEls = cols.map(() => h('div', { class: 'cx-grid__col' }));
      body.append(hours, h('div', { class: 'cx-grid__cols' }, colEls));
      const nl = notLive();
      cols.forEach((c, ci) => {
        const mine = timed.filter(r => audOf(r.audience) === c[0] && lenOf(r) < LONG).sort((a, b) => sortKey(a) - sortKey(b));
        mine.forEach(r => {
          const a = mins(r.start), len = Math.max(15, lenOf(r) || 30);
          const iss = issues(r).filter(x => x.tone === 'bad');
          const blk = h('button', {
            type: 'button', class: 'cx-blk' + (r._id === sel ? ' is-sel' : '') + (r._look ? ' is-look' : '') + (iss.length ? ' is-bad' : '') + (nl.has(r._id) ? ' is-notlive' : ''), 'data-key': r._id,
            style: { top: ((a - lo) * PX) + 'px', minHeight: Math.max(26, len * PX - 2) + 'px', left: '2px', width: 'calc(100% - 4px)' },
            title: (r.title || '') + ' · ' + timeText(r) + (iss.length ? ' · ' + iss[0].text : ''),
            on: { click: () => openRow(r._id) }
          }, h('span', { class: 'cx-blk__t', text: timeText(r) }), h('span', { class: 'cx-blk__n', text: r.title || 'Untitled' }), r.place ? h('span', { class: 'cx-blk__p', text: (placeOf(r.place) || {}).name || r.place }) : null);
          colEls[ci].appendChild(blk);
        });
      });
      wrap.append(headRow, body);
      // Every block tall enough for its words, and never on top of another: each is measured, then
      // blocks that would overlap as drawn (a short one grown for its words) sit side by side. Measured
      // again whenever the grid's width changes (the record panel opening narrows it).
      const lanesIn = [];
      const fitCols = () => colEls.forEach((col, ci) => {
        const blks = [...col.querySelectorAll('.cx-blk')];
        for (let pass = 0; pass < 2; pass++) {
          blks.forEach(b => { b.style.height = ''; if (b.scrollHeight > b.clientHeight + 1) b.style.height = b.scrollHeight + 'px'; });
          const lanes = [], laneOf = new Map();
          blks.map(b => ({ b, top: b.offsetTop, bot: b.offsetTop + b.offsetHeight + 2 })).sort((x, y) => x.top - y.top).forEach(x => {
            let li = lanes.findIndex(end => end <= x.top);
            if (li < 0) { li = lanes.length; lanes.push(x.bot); } else lanes[li] = x.bot;
            laneOf.set(x.b, li);
          });
          // Blocks that touch one another, however indirectly, share the width by the lanes they use.
          const sorted = blks.slice().sort((x, y) => x.offsetTop - y.offsetTop);
          let group = [], bottom = -1;
          lanesIn[ci] = Math.max(1, lanes.length);
          const place = g => { const n = Math.max(...g.map(b => laneOf.get(b))) + 1; g.forEach(b => { b.style.left = 'calc(' + (laneOf.get(b) * 100 / n) + '% + 2px)'; b.style.width = 'calc(' + (100 / n) + '% - 4px)'; }); };
          sorted.forEach(b => {
            if (group.length && b.offsetTop >= bottom) { place(group); group = []; bottom = -1; }
            group.push(b); bottom = Math.max(bottom, b.offsetTop + b.offsetHeight + 2);
          });
          if (group.length) place(group);
        }
      });
      // A column with more side-by-side blocks gets more of the width.
      const fit = () => {
        fitCols();
        const tpl = colEls.map((c, i) => 'minmax(0, ' + (lanesIn[i] || 1) + 'fr)').join(' ');
        body.querySelector('.cx-grid__cols').style.gridTemplateColumns = tpl;
        headRow.style.gridTemplateColumns = '52px ' + tpl;
        fitCols();
      };
      requestAnimationFrame(fit);
      if (window.ResizeObserver) { let w0 = 0; const ro2 = new ResizeObserver(en => { const w = en[0].contentRect.width; if (Math.abs(w - w0) > 1) { w0 = w; fit(); } }); ro2.observe(wrap); offs.push(() => ro2.disconnect()); }
      return wrap;
    }

    /* ---------------------------------------------------------- one row, beside the list */

    function openRow(id, o) {
      o = o || {};
      const r = f.get(id);
      if (!r) { sp.close(true); return; }
      const was = sel;
      sel = id;
      A.setParams({ v: view, id, at: layout === 'grid' ? 'grid' : '' });
      listEl.querySelectorAll('[data-key]').forEach(x => { x.setAttribute('aria-selected', String(x.dataset.key === id)); x.classList.toggle('is-sel', x.dataset.key === id); });
      if (was && was !== id && f.isHeld && f.isHeld(was)) f.discard(was);
      const set = (fields, label, key) => { f.set(id, Object.assign({ _guess: '' }, fields), { label, key: id + ':' + key }); };
      const body = h('div', { class: 'cx-rec' });
      const issBox = h('div', { class: 'cx-issues', 'aria-live': 'polite' });
      const drawIssues = () => {
        A.clear(issBox);
        const rr = f.get(id); if (!rr) return;
        issues(rr).forEach(x => issBox.appendChild(h('p', { class: 'cx-issue cx-issue--' + x.tone }, x.text, x.go ? [' · ', K.link('Open', () => openRow(x.go))] : null)));
      };
      if (r._look) body.appendChild(checkBox(r));
      // What
      const title = K.textIn({ value: r.title, label: 'What', onSave: v => { if (!v.trim()) return 'A row needs a name'; set({ title: v.trim() }, 'What', 'title'); const t = sp.panel.querySelector('.ap-panel__title'); if (t) t.textContent = v.trim(); } });
      // Opened by a click, the name takes the focus; moved to with the arrow keys, the list keeps it.
      if (!o.keep) title.setAttribute('data-autofocus', '');
      body.appendChild(held(K.field('What', title), r, 'title'));
      // When: one field, read as written.
      const whenSaid = h('span', { class: 'ap-help' });
      const when = K.textIn({ value: timeText(r) || (r.start || ''), label: 'When', placeholder: '7–9 PM · or After Communion', onSave: v => {
        const w = R.when(v, rctx(r.day, { title: r.title }));
        if (!w.ok) return 'Not a time · Try “7–9 PM”';
        set({ start: w.start, end: w.end, sort_time: w.sort_time || '' }, 'When', 'when');
        sayWhen(w);
      } });
      const sayWhen = w => { const g = (w.parts || []).find(x => x[2]); whenSaid.textContent = g ? 'Read as ' + w.parts.map(x => x[1]).join(' · ') + (w.guess ? ' · guessed' : '') : ''; };
      body.appendChild(held(K.field('When', h('div', null, when, whenSaid)), r, 'start'));
      // Day
      body.appendChild(K.field('Day', K.pills(days.map(x => [x.name, x.name.slice(0, 3), x.date ? K.wd(x.date) : x.name]), r.day, v => { set({ day: v }, 'Day', 'day'); A.toast('Moved · ' + r.title + ' · ' + v, { undo: () => K.replay(f, 'undo') }); if (isDay(days, view) && lc(v) !== view) { drawList(); } }, { label: 'Day' }), { tag: 'div' }));
      // Where: a place this campus has (type-ahead from its places).
      const listId = 'cx-places-' + Math.random().toString(36).slice(2, 7);
      const where = K.textIn({ value: r.place ? ((placeOf(r.place) || {}).name || r.place) : '', label: 'Where', placeholder: 'Chapel, Barnes 133…', onSave: v => {
        if (!v.trim()) { set({ place: '' }, 'Where', 'place'); return; }
        const pl = R.findPlace(v, places());
        if (!pl) return 'Not a place at this campus · Add it on Campus';
        set({ place: pl.code }, 'Where', 'place');
        where.set(pl.name);
      } });
      where.setAttribute('list', listId);
      const dl = h('datalist', { id: listId }, places().map(x => h('option', { value: x.name })));
      body.appendChild(held(K.field('Where', h('div', null, where, dl)), r, 'place'));
      // For
      body.appendChild(K.field('For', K.pills(AUD, audOf(r.audience), v => set({ audience: v }, 'For', 'audience'), { label: 'For' }), { tag: 'div' }));
      // Note
      body.appendChild(held(K.field('Note', K.textIn({ value: r.note, label: 'Note', multiline: true, rows: 2, placeholder: 'Shown under the title', onSave: v => set({ note: v }, 'Note', 'note') })), r, 'note'));
      drawIssues();
      body.appendChild(issBox);
      body.appendChild(more(r, set));
      body.appendChild(historyFold(id));
      const foot = ro || d.held ? null : [
        A.btn('Duplicate', { ghost: true, write: true, onClick: () => { const c = Object.assign({}, f.get(id)); delete c._id; delete c._look; const nid = f.add(c, { label: 'Duplicate ' + c.title, before: (f.rows[f.rows.indexOf(f.get(id)) + 1] || {})._id }); A.toast('Duplicated · ' + c.title, { undo: () => K.replay(f, 'undo') }); drawList(); openRow(nid); } }),
        A.btn('Remove', { ghost: true, danger: true, write: true, onClick: () => { const t = r.title; f.remove(id, { label: 'Remove ' + t }); sp.close(true); sel = ''; A.setParams({ id: '' }); drawMain(); A.toast('Removed · ' + t, { undo: () => { K.replay(f, 'undo'); } }); } })
      ];
      sp.open({ title: r.title || 'New row', body, foot, onClose: () => { if (f.isHeld && f.isHeld(id)) f.discard(id); sel = ''; A.setParams({ id: '', v: view }); markRows(); listEl.querySelectorAll('.is-sel').forEach(x => x.classList.remove('is-sel')); } });
      if (!K.wide()) window.scrollTo(0, 0);
      if (ro || d.held) sp.panel.querySelectorAll('input, textarea, button.ap-pill').forEach(x => { x.disabled = true; });
      if (!o.keep && o.focus !== false && document.activeElement && document.activeElement.closest && !document.activeElement.closest('.cx-add')) { /* the panel's own autofocus */ }
      panelIssues = drawIssues;
    }
    let panelIssues = null;

    // Someone else changed the same field first: their text and mine, at the field.
    function held(fieldEl, r, field) {
      const hd = f.held[r._id] && f.held[r._id][field];
      if (!hd) return fieldEl;
      fieldEl.appendChild(h('div', { class: 'cx-clash', role: 'alert' },
        h('p', null, 'Changed by ' + (hd.by || 'someone else') + ' just now: ', h('q', { text: hd.theirs || '(blank)' })),
        h('div', { class: 'ap-row' },
          A.btn('Keep mine', { primary: true, write: true, onClick: () => { f.resolve(r._id, field, true); openRow(r._id); } }),
          A.btn('Use theirs', { write: true, onClick: () => { f.resolve(r._id, field, false); openRow(r._id); } }))));
      return fieldEl;
    }

    // To check: last year's line beside this year's, said plainly; Looks right clears it.
    function checkBox(r) {
      const was = prevRows.find(x => lc(x.title) === lc(r.title));
      const line = x => [x.day ? x.day.slice(0, 3) : '', timeText(x), (placeOf(x.place) || {}).name || x.place].filter(Boolean).join(' · ');
      const same = was && line(was) === line(r);
      const pk = (d.picked && d.picked.from) || (d.ov && d.ov.prev ? d.ov.prev.year : '');
      const left = f.rows.filter(x => x._look).length;
      if (!checkFrom || left > checkFrom) checkFrom = left;
      const at = checkFrom - left + 1;
      const box = h('div', { class: 'cx-check', role: 'note' },
        h('p', { class: 'cx-check__h' }, A.tag(r._look === 'unsure' ? 'Not sure' : 'To check', 'tan'), was ? (same ? ' Same as ' + pk : ' Changed from ' + pk) : ' New since ' + pk, h('span', { class: 'ap-quiet', text: '  ·  ' + at + ' of ' + checkFrom })),
        was ? h('p', { class: 'cx-check__was' }, h('span', { class: 'ap-label', text: pk }), ' ', line(was)) : null,
        h('p', { class: 'ap-help', text: 'Changes most years · Check the time and place' }),
        h('div', { class: 'ap-row' },
          A.btn('Looks right', { primary: true, write: true, icon: 'check', onClick: () => {
            // The next row to check, in the list's order, opens at once.
            const order = (view === 'check' ? rowsInView() : f.rows).filter(x => x._look && x._id !== r._id);
            const after = order.find(x => (view === 'check' ? rowsInView() : f.rows).indexOf(x) > (view === 'check' ? rowsInView() : f.rows).indexOf(r)) || order[0];
            f.set(r._id, { _look: '' }, { label: 'Looks right' });
            A.toast('Checked · ' + r.title + (order.length ? ' · ' + order.length + ' left' : ' · All checked'), { undo: () => K.replay(f, 'undo') });
            drawMain();
            if (after) openRow(after._id); else { head(); openRow(r._id); }
          } }),
          r._look !== 'unsure' ? A.btn('Not sure', { ghost: true, write: true, onClick: () => { f.set(r._id, { _look: 'unsure' }, { label: 'Not sure' }); drawList(); openRow(r._id); } }) : null,
          left > 1 ? A.btn('All ' + left + ' look right', { ghost: true, write: true, title: 'Every row still to check · Undo in the toast', onClick: () => {
            f.rows.filter(x => x._look).forEach(x => f.set(x._id, { _look: '' }, { label: 'All look right' }));
            A.toast('Checked · ' + K.plural(left, 'row'), { undo: () => { for (let i = 0; i < left; i++) K.replay(f, 'undo'); drawMain(); } });
            drawMain(); head(); openRow(r._id);
          } }) : null));
      return box;
    }

    // More: what's set only now and then, summarised on its line.
    function more(r, set) {
      const kind = kindOf(r);
      const sum = [kind ? (KINDS.find(k => k[0] === kind) || [0, kind])[1] : '', r.display === 'private' ? 'Committees only' : r.display ? (DISPLAY.find(x => x[0] === r.display) || [0, r.display])[1] : '', r.call_in === 'yes' ? 'Call-in' : '', r.last_day ? 'Through ' + r.last_day.slice(0, 3) : '', r.print_note ? 'Printout note' : ''].filter(Boolean).join(' · ');
      const det = h('details', { class: 'cx-more' }, h('summary', null, h('span', { text: 'More' }), sum ? h('span', { class: 'ap-quiet', text: sum }) : null));
      const after = days.slice(days.findIndex(x => x.name === r.day) + 1);
      det.append(...[
        K.field('Kind', K.pills(KINDS.slice(0, 8).concat(kind && !KINDS.slice(0, 8).some(k => k[0] === kind) ? [KINDS.find(k => k[0] === kind) || [kind, kind]] : []), kind, v => set({ kind: v }, 'Kind', 'kind'), { label: 'Kind' }), { tag: 'div', help: 'Guessed from the title until chosen' }),
        K.field('Who sees it', K.pills([['', 'Everyone'], ['private', 'Committees only']], r.display === 'private' ? 'private' : '', v => set({ display: v }, 'Who sees it', 'display'), { label: 'Who sees it' }), { tag: 'div', help: 'Committees only · Never on a public page' }),
        r.display === 'private' ? null : K.field('Shown as', K.pills(DISPLAY, r.display || '', v => set({ display: v }, 'Shown as', 'display'), { label: 'Shown as' }), { tag: 'div', help: (DISPLAY.find(x => x[0] === (r.display || '')) || DISPLAY[0])[2] }),
        K.field('Call-in', K.pills([['', 'No'], ['yes', 'Yes']], r.call_in === 'yes' ? 'yes' : '', v => set({ call_in: v }, 'Call-in', 'call_in'), { label: 'Call-in' }), { tag: 'div', help: 'On the phone line' }),
        after.length ? K.field('Through', K.pills([['', 'One day']].concat(after.map(x => [x.name, x.name.slice(0, 3)])), r.last_day || '', v => set({ last_day: v }, 'Through', 'last_day'), { label: 'Through' }), { tag: 'div', help: 'The same row each day through then' }) : null,
        K.field('Printout note', K.textIn({ value: r.print_note, label: 'Printout note', onSave: v => set({ print_note: v }, 'Printout note', 'print_note') }), { help: 'Only on the printed schedule' })
      ].filter(Boolean));
      return det;
    }

    function historyFold(id) {
      const det = h('details', { class: 'cx-more cx-hist' }, h('summary', null, h('span', { text: 'History' })));
      const list = h('ul', { class: 'ap-feed' });
      det.appendChild(list);
      det.addEventListener('toggle', () => {
        if (!det.open || list.dataset.done) return;
        list.dataset.done = '1';
        list.appendChild(h('li', { class: 'ap-quiet', text: 'Loading' }));
        f.history(id).then(rows => {
          A.clear(list);
          if (!rows.length) { list.appendChild(h('li', { class: 'ap-quiet', text: 'No changes yet' })); return; }
          rows.slice(0, 20).forEach(x => list.appendChild(h('li', null, h('span', null, h('b', { text: x.who || 'Someone' }), ' · ', words(x)), h('span', { class: 'ap-feed__at', text: K.ago(x.at) }))));
        }, () => { A.clear(list).appendChild(h('li', { class: 'ap-quiet', text: 'Not loaded' })); });
      });
      return det;
    }
    const FW = { day: 'Day', start: 'Starts', end: 'Ends', title: 'What', place: 'Where', audience: 'For', note: 'Note', call_in: 'Call-in', display: 'Shown as', kind: 'Kind', last_day: 'Through', _look: 'Checked', print_note: 'Printout note' };
    function words(x) {
      if (x.action === 'add') return 'Added';
      if (x.action === 'remove') return 'Removed';
      const b = x.before || {}, a = x.after || {};
      return Object.keys(a).filter(k => FW[k]).map(k => k === '_look' ? (a[k] ? 'To check' : 'Checked') : FW[k] + ' ' + (b[k] || '—') + ' → ' + (a[k] || '—')).join(' · ') || 'Changed';
    }

    /* ---------------------------------------------------------- File: paste, import, export */

    function pasteRows() {
      const day = dayName(view) || (days[0] || {}).name;
      const ta = h('textarea', { class: 'ap-textarea cx-paste', rows: '8', placeholder: day + '\n7–9 Hymn sing, Barnes\n9:30 Prayer meeting, Chapel', 'aria-label': 'Rows to paste' });
      const pre = h('div', { class: 'cx-preview', 'aria-live': 'polite' });
      let got = null;
      const addBtn = A.btn('Add rows', { primary: true, write: true, disabled: true, onClick: () => apply(false) });
      const repBtn = A.btn('Replace', { danger: true, ghost: true, write: true, disabled: true, onClick: () => apply(true) });
      const show = () => {
        A.clear(pre);
        got = ta.value.trim() ? R.paste(ta.value, rctx(day)) : null;
        const rows = got ? got.rows : [];
        const exists = r => f.rows.some(x => lc(x.day) === lc(r.row.day) && lc(x.title) === lc(r.row.title) && mins(x.start) === mins(r.row.start));
        const fresh = rows.filter(r => !exists(r));
        addBtn.disabled = !fresh.length; addBtn.lastChild.textContent = fresh.length ? 'Add ' + K.plural(fresh.length, 'row') : 'Add rows';
        const dset = Array.from(new Set(rows.map(r => r.row.day)));
        const gone = f.rows.filter(x => dset.indexOf(x.day) > -1).length;
        repBtn.disabled = !rows.length; repBtn.lastChild.textContent = rows.length ? 'Replace ' + dset.map(x => x.slice(0, 3)).join(', ') + ' · removes ' + gone : 'Replace';
        if (!got) return;
        pre.appendChild(h('p', { class: 'ap-quiet', text: K.plural(rows.length, 'row') + ' read' + (rows.length - fresh.length ? ' · ' + (rows.length - fresh.length) + ' already there' : '') + (got.unread.length ? ' · ' + K.plural(got.unread.length, 'line') + ' not read' : '') }));
        const ul = h('ul', { class: 'cx-prevlist' });
        rows.slice(0, 60).forEach(r => ul.appendChild(h('li', { class: exists(r) ? 'is-same' : '' }, h('span', { class: 'cx-prev__d', text: (r.row.day || '').slice(0, 3) }), h('span', { class: 'cx-prev__t', text: timeText(r.row) || 'No time' }), h('span', { text: r.row.title }), r.row.place ? h('span', { class: 'ap-quiet', text: (placeOf(r.row.place) || {}).name || r.row.place }) : null, exists(r) ? h('span', { class: 'ap-quiet', text: 'Already there' }) : null)));
        got.unread.slice(0, 20).forEach(l => ul.appendChild(h('li', { class: 'is-bad' }, h('span', { class: 'cx-prev__t', text: 'Not read' }), h('span', { text: l }))));
        pre.appendChild(ul);
      };
      ta.addEventListener('input', show);
      const apply = replace => {
        if (!got) return;
        const rows = got.rows.map(r => Object.assign({}, r.row, r.guess ? { _guess: '1' } : {}));
        const dset = Array.from(new Set(rows.map(r => r.day)));
        f.batch(replace ? 'Replace ' + dset.join(', ') : 'Paste', () => {
          if (replace) f.rows.filter(x => dset.indexOf(x.day) > -1).map(x => x._id).forEach(id => f.remove(id));
          rows.filter(r => replace || !f.rows.some(x => lc(x.day) === lc(r.day) && lc(x.title) === lc(r.title) && mins(x.start) === mins(r.start))).forEach(r => { delete r.by; f.add(r); });
        });
        sp.close(true);
        drawMain();
        A.toast((replace ? 'Replaced · ' : 'Added · ') + K.plural(rows.length, 'row'), { undo: () => { K.replay(f, 'undo'); drawMain(); } });
      };
      sp.open({ title: 'Paste rows', body: h('div', null, K.field('Rows', ta, { help: 'A line a row · A day’s name starts its rows · Or a spreadsheet’s rows' }), pre), foot: [addBtn, repBtn, A.btn('Cancel', { ghost: true, onClick: () => sp.close() })] });
      ta.focus();
    }

    const EXP = [['Day', 'day'], ['Time', r => timeText(r)], ['What', 'title'], ['Where', r => (placeOf(r.place) || {}).name || r.place || ''], ['For', r => audOf(r.audience) === 'Conference' ? '' : audLabel(r.audience)], ['Call-in', r => r.call_in === 'yes' ? 'Yes' : ''], ['Note', 'note'], ['ID', '_id']];
    function exportFile() {
      const rows = f.rows.slice().sort((a, b) => days.findIndex(x => x.name === a.day) - days.findIndex(x => x.name === b.day) || sortKey(a) - sortKey(b));
      K.download('schedule-' + y + '.csv', EXP.map(x => x[0]), rows.map(r => EXP.map(x => typeof x[1] === 'function' ? x[1](r) : (r[x[1]] || ''))));
      A.toast('Exported · ' + K.plural(rows.length, 'row'));
    }

    function importFile() {
      K.pick('.csv,.tsv,.txt,.xlsx').then(file => file && ED.files.read(file)).then(got => {
        if (!got) return;
        const grid = got.grid.filter(r => r.some(c => String(c).trim()));
        const head0 = (grid[0] || []).map(c => lc(c));
        const ix = n => head0.indexOf(n);
        let incoming;
        if (ix('what') > -1 && ix('day') > -1) {
          incoming = grid.slice(1).map(c => {
            const w = R.when(c[ix('time')] || '', rctx(c[ix('day')], { title: c[ix('what')] }));
            const pl = c[ix('where')] ? R.findPlace(c[ix('where')], places()) : null;
            const o = { day: dayName(c[ix('day')]) || c[ix('day')], title: c[ix('what')], start: w.start, end: w.end, place: pl ? pl.code : (c[ix('where')] || ''), note: ix('note') > -1 ? c[ix('note')] : undefined };
            if (ix('for') > -1) o.audience = audOf(c[ix('for')] || 'Conference');
            if (ix('call-in') > -1) o.call_in = /^y/i.test(c[ix('call-in')] || '') ? 'yes' : '';
            if (ix('id') > -1 && c[ix('id')]) o._id = c[ix('id')];
            return o;
          }).filter(r => r.title);
        } else {
          incoming = R.paste(got.text || grid.map(r => r.join('\t')).join('\n'), rctx()).rows.map(r => r.row);
        }
        const cmp = ED.files.compare(incoming, f.rows, { key: r => lc(r.day) + '|' + mins(r.start) + '|' + lc(r.title), name: r => lc(r.title), scope: r => lc(r.day), fields: ['day', 'start', 'end', 'title', 'place', 'audience', 'note', 'call_in'] });
        const take = { removed: new Set() };
        const lines = [K.plural(cmp.changed.length, 'changed') + ' · ' + K.plural(cmp.added.length, 'new', 'new') + ' · ' + K.plural(cmp.removed.length, 'removed', 'removed') + ' · ' + cmp.same.length + ' the same'];
        const ul = h('ul', { class: 'cx-prevlist' });
        cmp.changed.forEach(c => ul.appendChild(h('li', null, h('span', { class: 'cx-prev__t', text: 'Changed' }), h('span', { text: c.now.title }), h('span', { class: 'ap-quiet', text: c.fields.map(k => FW[k] || k).join(', ') }))));
        cmp.added.forEach(r => ul.appendChild(h('li', null, h('span', { class: 'cx-prev__t', text: 'New' }), h('span', { text: (r.day || '').slice(0, 3) + ' ' + timeText(r) + ' ' + r.title }))));
        cmp.removed.forEach(x => { const cb = h('input', { type: 'checkbox', class: 'ap-check', on: { change: e => { if (e.target.checked) take.removed.add(x.row._id); else take.removed.delete(x.row._id); } } }); ul.appendChild(h('li', null, h('label', { class: 'ap-switch' }, cb, h('span', { text: 'Remove · ' + (x.row.day || '').slice(0, 3) + ' ' + x.row.title })))); });
        if (cmp.dupes.length) lines.push(K.plural(cmp.dupes.length, 'row') + ' twice in the file · The first kept: ' + cmp.dupes.slice(0, 3).map(r => r.title).join(', '));
        K.confirm(sp, {
          title: 'Import', lines, field: ul, actLabel: 'Apply',
          act: () => {
            f.batch('Import', () => {
              cmp.changed.forEach(c => { const o = {}; c.fields.forEach(k => { o[k] = c.now[k]; }); f.set(c.row._id, o); });
              cmp.added.forEach(r => { const o = Object.assign({}, r); delete o._id; f.add(o); });
              take.removed.forEach(id => f.remove(id));
            });
            return Promise.resolve();
          },
          onDone: () => { drawMain(); A.toast('Imported · ' + (cmp.changed.length + cmp.added.length + take.removed.size) + ' changes', { undo: () => { K.replay(f, 'undo'); drawMain(); } }); }
        });
      }).catch(err => A.toast(err && err.message ? err.message : 'Not read'));
    }

    /* ---------------------------------------------------------- keeping up */

    offs.push(K.on(f, 'change', e => {
      head(); drawViews();
      drawList();
      if (panelIssues) panelIssues();
      if (e && e.server) refreshLive();
    }));
    offs.push(K.on(f, 'remote', e => {
      drawMain();
      if (sel && e.changed.indexOf(sel) > -1 && !(sp.panel.contains(document.activeElement) && document.activeElement.matches('input, textarea'))) openRow(sel, { keep: true });
      if (sel && e.gone.indexOf(sel) > -1) { sp.close(true); sel = ''; A.toast('Removed by someone else'); }
      refreshLive();
    }));
    offs.push(K.on(f, 'conflict', cf => { if (sel && cf.some(c => c.id === sel)) openRow(sel, { keep: true }); A.toast('Changed by ' + (cf[0].by || 'someone else') + ' first · Choose at the field'); }));
    offs.push(K.on(f, 'ids', e => { if (sel === e.from) { sel = e.to; A.setParams({ id: sel }); } }));
    offs.push(K.undoKeys(dir => { K.replay(f, dir); drawMain(); if (sel && f.get(sel)) openRow(sel, { keep: true }); else if (sel) sp.close(true); }));
    const keys = e => {
      if (e.target.closest && e.target.closest('input, textarea, [contenteditable]')) return;
      if (e.metaKey || e.ctrlKey || e.altKey || document.querySelector('.ap-palette')) return;
      if (e.key === 'n' || e.key === 'N') { const i = addBox.querySelector('.cx-add__in'); if (i) { e.preventDefault(); i.focus(); } }
      if (e.key === '/') { const i = views.querySelector('.cx-find'); if (i) { e.preventDefault(); i.focus(); } }
    };
    document.addEventListener('keydown', keys);
    offs.push(() => document.removeEventListener('keydown', keys));

    head();
    drawMain();
    if (sel && f.get(sel)) openRow(sel, { keep: true });
    else if (p.at !== 'grid') { const i = addBox.querySelector('.cx-add__in'); if (i && K.wide()) i.focus({ preventScroll: true }); }
  }
})();
