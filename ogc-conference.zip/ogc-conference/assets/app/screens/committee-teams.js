/*
 * Young Folks › Teams (app-committees, Oct 11): the tournament teams, moved into the app from the
 * tournaments page's committee list and reworked from its critique. Or "their own way": the committee
 * makes its teams without the site, and the public page shows only times and places (no-assumed-owners).
 *
 *   Each tournament: when, where, how many, when sign-ups close; its teams (active numbered, withdrawn
 *   folded apart), each with its players, the captain's phone, No-show, Remove (Undo).
 *   Add team (taken in person), Message teams (one tournament or all; replies go to you), Print (a
 *   title, page numbers, active teams only, ruled lines for walk-ups), Download.
 */
(function () {
  'use strict';
  const A = window.OGC_APP, h = A.h, K = window.OGC_CK;
  const tag = (t, tone) => h('span', { class: 'cm-chip' + (tone ? ' cm-chip--' + tone : ''), text: t });
  const hm = m => { if (m == null) return ''; const hh = Math.floor(m / 60) % 24, mm = m % 60; return (hh % 12 || 12) + (mm ? ':' + String(mm).padStart(2, '0') : '') + ' ' + (hh >= 12 ? 'PM' : 'AM'); };

  function screen(ctx) {
    const p = ctx.params;
    let T = null, sp = null, panel = '', alive = true;
    const only = () => p.v || '';
    const tn = (method, path, body) => A.api(method, '/tn/' + path, body);
    const asOf = () => (new URLSearchParams(location.search).get('as-of') || '');
    const load = () => tn('GET', p.year + '/teams' + (asOf() ? '?as_of=' + asOf() : '')).then(r => { T = r; if (alive) draw(); }).catch(err => { if (alive) K.failed(ctx, err); });
    const ro = () => !!A.readonly || !!(T && T.cleared);
    const label = x => x.mode === 'solo' ? x.players[0] : x.team || x.players.join(', ');
    const closes = c => c && c.date ? K.day(c.date) + (c.min != null ? ', ' + hm(c.min) : '') : '';
    const when = t => t.items.map(i => K.day(i.date) + (i.when ? ' · ' + i.when : '')).join(' · ');

    function draw() {
      if (!sp) { A.clear(ctx.body); sp = ctx.split(); }
      A.clear(sp.main);
      const active = T.teams.filter(x => x.status === 'active');
      const acts = [];
      if (!ro() && T.online) acts.push(A.btn('Add team', { primary: !panel, icon: 'plus', write: true, onClick: () => openPanel('add') }));
      if (!ro() && active.length) acts.push(A.btn('Message', { icon: 'mail', write: true, onClick: () => openPanel('msg') }));
      const editT = () => { location.href = (OGC_WP.base || '/annual-conference/') + 'admin/?year=' + p.year + '&edit=tournaments&return=' + encodeURIComponent(location.pathname + location.search); };
      acts.push(K.more('More', [ro() ? null : { label: 'Edit tournaments', run: editT }, { label: 'Print', run: printTeams }, { label: 'Download for Excel', run: () => K.excel('tn/' + p.year + '/teams' + (only() ? '?tid=' + encodeURIComponent(only()) : ''), p.year + ' Young Folks teams' + (only() ? ' ' + ((T.list.find(t => t.id === only()) || {}).name || '') : ''), p.as) }], { ghost: true }));
      ctx.head('Teams', T.cleared ? 'Counts only · Cleared ' + K.md(T.cleared) : K.facts([active.length ? K.plural(active.length, 'team') : 'No teams yet', T.online ? '' : 'Their own way', T.posted ? '' : 'Not public']), acts);
      // On the site, or their own way: the committee's choice, said plainly (the public page follows it).
      if (!ro()) sp.main.appendChild(h('div', { class: 'cm-toolbar' },
        K.pills([['yes', 'On the site'], ['no', 'Their own way']], T.online ? 'yes' : 'no', v => setOnline(v), 'Sign-ups'),
        !T.online ? howLine() : null));
      if (T.online && T.list.length > 1) sp.main.appendChild(h('div', { class: 'cm-toolbar' }, A.views([{ id: '', label: 'All' }].concat(T.list.map(t => ({ id: t.id, label: t.name, n: t.counts && (t.counts.teams + t.counts.alone) ? t.counts.teams + t.counts.alone : null }))), only(), id => A.go({ v: id, id: '' }, { replace: true }))));
      const shown = T.list.filter(t => (!only() || t.id === only()) && (T.online || T.teams.some(x => x.tid === t.id)));
      if (!shown.length) sp.main.appendChild(A.empty({ title: T.online ? 'No tournaments' : 'No teams on the site', line: T.online ? '' : 'Times and places show on the public page', inset: true }));
      shown.forEach(t => {
        const list = T.teams.filter(x => x.tid === t.id), live = list.filter(x => x.status === 'active'), gone = list.filter(x => x.status !== 'active');
        const sec = h('section', { class: 'cm-section' }, h('h2', { class: 'ap-h2' }, t.name, h('span', { class: 'ap-h2__n', text: K.facts([live.length ? K.plural(live.length, 'team') : '', t.max === 1 ? 'On their own' : t.min === t.max ? 'Teams of ' + t.max : 'Teams of ' + t.team_min + '–' + t.max, T.online ? (t.state === 'closed' ? 'Closed' : t.closes ? 'Closes ' + closes(t.closes) : '') : '', t.max_teams ? 'Most ' + t.max_teams : '']) })),
          t.items.length ? h('p', { class: 'ap-quiet', text: when(t) + (t.items[0].place ? ' · ' + t.items[0].place : '') }) : null);
        // One column layout for every tournament, so the captains and actions line up down the page.
        if (live.length) sec.appendChild(h('table', { class: 'cm-table cm-teamtab' }, h('tbody', null, live.map((x, i) => teamRow(x, i + 1)))));
        // "No teams yet" is said once, in the title row; a tournament with none draws only its line.
        else if (T.teams.length) sec.appendChild(h('p', { class: 'ap-quiet', text: 'No teams yet' }));
        if (gone.length) sec.appendChild(h('details', { class: 'cm-fold' }, h('summary', { text: 'Withdrawn · ' + gone.length }), h('table', { class: 'cm-table cm-teamtab' }, h('tbody', null, gone.map(x => teamRow(x, 0))))));
        sp.main.appendChild(sec);
      });
      if (panel === 'add') addPanel(); else if (panel === 'msg') msgPanel(); else sp.close(true);
    }
    function teamRow(x, n) {
      const gone = x.status !== 'active';
      return h('tr', { class: gone ? 'is-dim' : '' },
        h('td', { class: 'is-num is-muted', text: n ? n + '.' : '' }),
        h('td', null, h('span', { class: 'cm-title', text: label(x) }), x.late ? tag('Late') : null, x.no_show ? tag('No-show', 'warn') : null, gone ? tag(x.status === 'removed' ? 'Removed' : 'Withdrawn') : null,
          x.mode !== 'solo' && x.team ? h('span', { class: 'cm-sub2', text: x.players.join(', ') }) : null),
        h('td', null, h('span', { class: 'cm-sub2' }, 'Captain ' + (x.players[0] || ''), x.phone ? [' · ', K.phone(x.phone)] : null)),
        h('td', { class: 'is-num' }, ro() ? null : gone ? A.btn('Restore', { ghost: true, write: true, onClick: () => tn('POST', 'r/' + x.id + '/restore', {}).then(() => { A.toast('Restored · ' + label(x)); load(); }).catch(A.fail) })
          : h('span', { class: 'ap-row' }, A.btn(x.no_show ? 'Showed' : 'No-show', { ghost: true, write: true, onClick: () => tn('PATCH', 'r/' + x.id + '/flag', { no_show: !x.no_show }).then(() => { A.toast(label(x) + (x.no_show ? ' · Showed' : ' · No-show')); load(); }).catch(A.fail) }),
            A.btn('Remove', { ghost: true, danger: true, write: true, onClick: () => tn('DELETE', 'r/' + x.id).then(() => { A.toast('Removed · ' + label(x), { undo: () => tn('POST', 'r/' + x.id + '/restore', {}).then(load).catch(A.fail) }); load(); }).catch(A.fail) }))));
    }
    function howLine() {
      const input = h('input', { class: 'ap-input', maxlength: '160', value: T.how || '', placeholder: 'At the Young Folks welcome, Friday 6:30', 'aria-label': 'Sign-up line', title: 'Shown above the tournaments on the public page', style: { minWidth: '320px' } });
      input.addEventListener('change', () => A.api('PATCH', '/years/' + p.year + '/files/settings', { op: 'key', key: 'tournaments_how', value: input.value.trim() }).then(() => { T.how = input.value.trim(); A.toast('Saved · Sign-up line'); }).catch(A.fail));
      return input;
    }
    function setOnline(v) {
      A.api('PATCH', '/years/' + p.year + '/files/settings', { op: 'key', key: 'tournaments_online', value: v }).then(() => { A.toast(v === 'no' ? 'Their own way · Times and places only on the site' : 'On the site · Sign-ups open as set'); load(); }).catch(A.fail);
    }
    function openPanel(k) { panel = k; draw(); }
    function addPanel() {
      let tid = only() || (T.list[0] || {}).id, mode = 'team';
      const players = h('input', { class: 'ap-input', autocomplete: 'off', placeholder: 'Names, with commas', 'data-autofocus': '' }), team = h('input', { class: 'ap-input', autocomplete: 'off', placeholder: 'Optional' });
      const phone = h('input', { class: 'ap-input', type: 'tel', autocomplete: 'off', placeholder: 'Optional' }), email = h('input', { class: 'ap-input', type: 'email', autocomplete: 'off', placeholder: 'Optional' });
      const err = h('p', { class: 'ap-err', role: 'alert' });
      const tp = h('div'), mp = h('div');
      const drawP = () => { A.clear(tp).appendChild(K.pills(T.list.map(t => [t.id, t.name]), tid, v => { tid = v; drawP(); }, 'Tournament')); A.clear(mp).appendChild(K.pills([['team', 'Team'], ['solo', 'On their own']], mode, v => { mode = v; drawP(); }, 'Kind')); };
      drawP();
      sp.open({ title: 'Add team', body: [h('div', { class: 'ap-field' }, h('span', { text: 'Tournament' }), tp), h('div', { class: 'ap-field' }, h('span', { text: 'Kind' }), mp),
        h('label', { class: 'ap-field' }, h('span', { text: 'Players' }), players), h('label', { class: 'ap-field' }, h('span', { text: 'Team name' }), team),
        h('label', { class: 'ap-field' }, h('span', { text: 'Captain’s phone' }), phone), h('label', { class: 'ap-field' }, h('span', { text: 'Email' }), email), err],
      foot: [A.btn('Add', { primary: true, write: true, onClick: () => tn('POST', p.year + '/add', { tid, mode, players: players.value.split(/\s*,\s*/).filter(Boolean), team: team.value, phone: phone.value, email: email.value }).then(() => { panel = ''; A.toast('Added · ' + (team.value || players.value)); load(); }).catch(e => { err.textContent = (e.data && e.data.message) || 'Not added'; }) }),
        A.btn('Cancel', { ghost: true, onClick: () => { panel = ''; draw(); } })], onClose: () => { panel = ''; draw(); } });
    }
    function msgPanel() {
      const t = only() ? T.list.find(x => x.id === only()) : null;
      const n = T.teams.filter(x => x.status === 'active' && (!t || x.tid === t.id) && x.email).length;
      const subject = h('input', { class: 'ap-input', maxlength: '120', 'data-autofocus': '' }), body = h('textarea', { class: 'ap-textarea', rows: '6' });
      const err = h('p', { class: 'ap-err', role: 'alert' });
      sp.open({ title: t ? 'Message ' + t.name + ' teams' : 'Message all teams', body: [h('p', { class: 'ap-quiet', text: K.facts([K.plural(n, 'team'), 'Replies to you']) }), h('label', { class: 'ap-field' }, h('span', { text: 'Subject' }), subject), h('label', { class: 'ap-field' }, h('span', { text: 'Message' }), body), err],
        foot: [A.btn('Send', { primary: true, icon: 'mail', write: true, onClick: () => tn('POST', p.year + '/message', { tid: t ? t.id : '', subject: subject.value, body: body.value }).then(r => { panel = ''; A.toast('Sent · ' + K.plural((r && r.sent) || n, 'team')); draw(); }).catch(e => { err.textContent = (e.data && e.data.message) || 'Not sent'; }) }),
          A.btn('Cancel', { ghost: true, onClick: () => { panel = ''; draw(); } })], onClose: () => { panel = ''; draw(); } });
    }
    // Each tournament on its own page: its active teams numbered, then ruled lines for walk-ups.
    function printTeams() {
      const shown = T.list.filter(t => !only() || t.id === only());
      K.print({ title: 'Tournament teams', who: 'Young Folks committee', build: () => h('div', null, shown.map((t, i) => {
        const live = T.teams.filter(x => x.tid === t.id && x.status === 'active');
        return h('section', { class: i ? 'cm-pbreak' : '' }, h('h2', { text: t.name + (t.items.length ? ' · ' + when(t) : '') }),
          h('table', null, h('thead', null, h('tr', null, ['', 'Team', 'Players', 'Captain’s phone', 'Here'].map(c => h('th', { text: c })))),
            h('tbody', null, live.map((x, k) => h('tr', { class: 'cm-tall' }, h('td', { text: (k + 1) + '.' }), h('td', { text: x.team || '' }), h('td', { text: x.players.join(', ') }), h('td', { text: x.phone }), h('td', { class: 'cm-tick' }))),
              Array.from({ length: 6 }, () => h('tr', { class: 'cm-tall' }, h('td'), h('td'), h('td'), h('td'), h('td', { class: 'cm-tick' }))))));
      })) });
    }
    K.loading(ctx);
    load();
    return () => { alive = false; };
  }

  A.screen({ id: 'yf-teams', title: 'Teams', icon: 'committees', section: 'own', who: ['young folks'], render: screen });
})();
