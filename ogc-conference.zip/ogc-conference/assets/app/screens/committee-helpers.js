/*
 * Shifts (Round 4, Oct 17; CHANGES/round4-shifts.md; docs/27-back-end-map/area-round-shifts.md §6–9): one
 * screen for every committee's volunteer shifts, s=shifts (s=helpers, the heads' list it grew from, is its
 * old address).
 *
 *   The COA, and the committee the COA hands Shifts to (A/V in the sample), open it on By committee: every
 *   committee with its counts; a row opens that committee's shifts (&c=food), and the pill
 *   "Committee · Food ×" widens it again. A committee opens its own, By day.
 *   Views      By committee · By day · Short · Waiting · To call · Not public (a view with nothing in it
 *              isn't drawn).
 *   A shift    its panel beside the list: the people on it (phones where allowed; Add person, Move,
 *              Remove, Offer, Here in the week), its fields (Job, Day, Start, End, Place, Needed, Rule),
 *              Linked (Committee · Place · Schedule at this time). A name opens the volunteer's panel:
 *              their shifts, each a link.
 *   The year   Add shift; Publish sign-ups, then Publish changes (at=publish, at=changes), the filled
 *              button by season; "From 2026 · Looks right" on a committee's carried shifts.
 *   A committee's own list keeps every tool the heads had on Helpers: names and phones inline, who left
 *   and when, Print and its clean sheet, Message a shift or a day, the instruction and reminders, night
 *   shifts under the night before, Download.
 * The server decides who sees and does what (module-shifts.php, the handing rule): this screen draws only
 * what it was given and what each shift's `can` says.
 */
(function () {
  'use strict';
  const A = window.OGC_APP, h = A.h, K = window.OGC_CK;
  // "Food’s", "Ushers’": a committee's name as its owner.
  const poss = n => String(n || '') + (/s$/i.test(String(n || '')) ? '’' : '’s');
  const key = n => String(n || '').toLowerCase().trim().replace(/\s+/g, ' ').replace(/^the\s+|\s+committee$/g, '').trim();
  const hm = m => { m = ((m % 1440) + 1440) % 1440; const hh = Math.floor(m / 60), mm = m % 60; return (hh % 12 || 12) + (mm ? ':' + String(mm).padStart(2, '0') : '') + ' ' + (hh >= 12 ? 'PM' : 'AM'); };
  const span = s => s.allweek ? 'All week' : hm(s.start).replace(/ (AM|PM)$/, hm(s.start).slice(-2) === hm(s.end).slice(-2) ? '' : ' $1') + '–' + hm(s.end);
  // An All week post (a dorm host) is listed before the days, as the volunteer page lists it.
  // A night shift is listed under its night, by the volunteers' one rule (the server's ogc_vol_eve_date:
  // a shift from midnight to 5 AM is the evening before's; after the eighth critic, Oct 16, Helpers, its
  // printout, Move and Message filed Friday night's 12–3 AM under Saturday): `eve`, the evening's date.
  const dayKey = s => s.allweek ? '0000-week' : s.eve || s.date;
  // A shift's time in the heads' words: "Fri night · 12–3 AM" for a night shift, else "6–9 AM".
  const when = s => (s.night ? s.night + ' · ' : '') + span(s);
  // With its day, wherever the day isn't the heading above it: "Fri night · 12–3 AM", "Sat May 29 · 6–9 AM".
  const dayWhen = s => s.allweek ? 'All week' : s.night ? when(s) : K.day(s.date) + ' · ' + span(s);
  const dayHead = (d, list) => d === '0000-week' ? 'All week · ' + K.day(list[0].date) + ' – ' + K.day(list[0].last_date || list[0].date) : K.day(d);
  // What every one of a list's shifts shares: a value when all agree (null when they differ), and the
  // line that says them once ("Golf cart driver · Barnes Student Center · 21 or older").
  function sharedOf(list, many) {
    const one = f => { const v = list.map(x => String(f(x) || '')); return v.length && v.every(x => x === v[0]) ? v[0] : null; };
    const o = many ? { role: null, place: null, rule: null } : { role: one(x => x.role), place: one(x => x.place), rule: one(x => x.rule) };
    o.line = K.facts([o.role, o.place, o.rule]);
    return o;
  }
  // A row's line under its title: only what isn't said above the list. Drawn a fact at a time: the time
  // whole on its line ("10:45 PM–12:15 AM" never splits), a place's or a rule's words free to wrap (after
  // the eighth critic, Oct 16). Every committee's list says the committee first.
  const rowSubEl = (s, sh, withC) => {
    const fs = [withC ? [s.committee] : null, sh.role != null ? null : [when(s), true], sh.place != null || !s.place ? null : [s.place], sh.rule != null || !s.rule ? null : [s.rule]].filter(Boolean);
    return fs.length ? h('span', { class: 'cm-sub2' }, ...fs.reduce((a, f, i) => a.concat(i ? [' · '] : [], [f[1] ? h('span', { class: 'cm-nw', text: f[0] }) : f[0]]), [])) : null;
  };
  // What happened to a place, after the person's name (the head sees full names here).
  const LEFT_ACT = { left: ' left', removed: ' removed', notme: ' removed · Not them', unconfirmed: ' · Not confirmed', moved_out: ' moved', swap: ' swapped' };
  // With the shift after it ("Mark Kline left Sat 3–7 PM · Oct 14"): the verb, and what's true besides.
  const LEFT_SAY = { left: ['left', ''], removed: ['removed from', ''], notme: ['removed from', 'Not them'], unconfirmed: ['off', 'Not confirmed'], moved_out: ['moved from', ''], swap: ['swapped out of', ''] };
  // When someone left, venue time: "Oct 16 · 3:12 PM" (the server's on_at; the date alone from an older one).
  const leftAt = l => l.on_at || l.on || '';
  // The committee's reminders, said plainly.
  const remindWords = su => [su.week ? 'A week before' : '', su.day ? 'The day before' : ''].filter(Boolean).join(' · ') || 'None';
  // The fixed rules (docs/25; round-shifts R3), and how a person was signed up and is reached.
  const RULES = [['none', 'None'], ['18', '18 or older'], ['21', '21 or older'], ['certified', 'Certified']];
  const BY = { self: 'Self', household: 'Household', helper: 'Helper', head: 'Head', replacement: 'Replacement' };
  const REACH = { email: 'Email', helper: 'Helper', phone: 'Phone only' };
  const STATE = { not_open: 'Not public', closed: 'Closed', started: 'Started', ended: 'Ended', committee: 'Committee only' };

  // The year's shifts, kept between screens of this one (a row → a volunteer → a shift each redraw the
  // screen; the address stays the truth). Any change forgets them.
  let cacheX = null, cacheD = null;
  const forget = () => { cacheX = null; cacheD = null; };

  function screen(ctx) {
    const p = ctx.params, y = p.year;
    let X = null, D = null, sp = null, panel = '', alive = true, ckey = '', msgTo = '', msgC = '', sent = null, headRO = null;
    const F = A.fParse(p.f);
    const hf = (F.household || [])[0] || '';
    const asOf = (new URLSearchParams(location.search).get('as-of') || '').slice(0, 10);
    const xKey = [y, p.as || '', hf, asOf].join('|');
    const vol = (method, path, body) => A.api(method, '/vol/' + y + '/lead' + path, body);
    const ro = () => !!A.readonly || !!(X && X.gone);
    const all = () => X && (X.role === 'coa' || X.role === 'holder');
    const com = k => (X.committees || []).find(c => c.key === k) || null;
    const cName = () => (com(ckey) || {}).name || '';
    const ownC = k => (X.own || []).includes(k);

    /* ---------------------------------------------------------------- loading */

    function getX(fresh) {
      if (!fresh && cacheX && cacheX.k === xKey && Date.now() - cacheX.t < 60000) return Promise.resolve(cacheX.d);
      return A.api('GET', 'shifts' + (hf ? '?household=' + encodeURIComponent(hf) : '')).then(d => { cacheX = { k: xKey, t: Date.now(), d }; return d; });
    }
    function getD(name, fresh) {
      const k = xKey + '|' + name;
      if (!fresh && cacheD && cacheD.k === k && Date.now() - cacheD.t < 60000) return Promise.resolve(cacheD.d);
      return vol('GET', '?committee=' + encodeURIComponent(name)).then(d => { cacheD = { k, t: Date.now(), d }; return d; });
    }
    function load(fresh) {
      return getX(fresh).then(x => {
        X = x;
        // Which committee: the address (?c=); else, for a committee, its own (the switcher's); the COA and
        // the committee holding Shifts open every committee's.
        ckey = p.c || (all() || hf ? '' : A.team());
        if (ckey && !com(ckey)) {
          // Not a committee this viewer may see (another's list): No access, never another list instead.
          if (p.c && !all()) return A.noAccess(ctx, { title: 'Shifts', line: poss((A.committee(p.c) || {}).name || p.c) + ' shifts' });
        }
        if (!p.c && ckey && !all()) A.setParams({ c: ckey });
        const c = com(ckey);
        // A committee's list keeps its heads' tools (who left, the instruction, Message, Print).
        if (c && c.counts.shifts && !hf) return getD(c.name, fresh).then(d => { D = d; if (alive) draw(); });
        D = null;
        if (alive) draw();
      }).catch(err => { if (alive) K.failed(ctx, err); });
    }
    const refresh = () => { forget(); return load(true); };
    const findX = id => (X.shifts || []).find(s => s.id === id);

    /* ---------------------------------------------------------------- what's drawn */

    function inF(s) {
      if (ckey && s.c !== ckey) return false;
      if (hf && !(s.hh > 0)) return false;
      if (F.day && !F.day.includes(s.date)) return false;
      if (F.place && !F.place.some(v => v === 'none' ? !s.place_ok : s.place_code.toUpperCase() === v.toUpperCase())) return false;
      return true;
    }
    const rowsIn = () => (X.shifts || []).filter(inF);
    const waitsIn = () => rowsIn().flatMap(s => s.waiting.map(w => Object.assign({ s }, w)));
    const callIn = () => (X.tocall || []).filter(t => !ckey || t.c === ckey);
    function viewsOf() {
      const rows = rowsIn();
      const vs = [];
      if (all() && !ckey && !hf) vs.push({ id: 'committee', label: 'By committee' });
      vs.push({ id: 'day', label: 'By day' });
      const short = rows.filter(s => s.open > 0).length, waiting = waitsIn().length, call = callIn().length, draft = rows.filter(s => s.draft).length;
      if (short && X.posted) vs.push({ id: 'short', label: 'Short', n: short });
      if (waiting) vs.push({ id: 'waiting', label: 'Waiting', n: waiting });
      if (call) vs.push({ id: 'tocall', label: 'To call', n: call });
      if (draft) vs.push({ id: 'draft', label: 'Not public', n: draft });
      return vs;
    }
    // The counts the title row says: the server's (ogc_shift_counts), the same Home and the Work rows say.
    const countsOf = () => ckey ? (com(ckey) || { counts: {} }).counts : X.counts || {};
    function factOf() {
      if (X.gone) return 'Names cleared · Counts only';
      if (hf) return K.plural(rowsIn().length, 'shift');
      const c = countsOf();
      if (!c.shifts) return '';
      if (!X.posted) return K.facts(['Not public', K.plural(c.shifts, 'shift'), c.places ? K.plural(c.places, 'place') : '', X.opens ? 'Opens ' + K.md(X.opens) : '']);
      return K.facts([c.places ? (c.filled || 'None') + ' of ' + c.places + ' filled' : '', c.open ? c.open + ' open' : c.places ? 'All filled' : '', c.draft ? c.draft + ' not public' : '', X.shut ? 'Closed' : '']);
    }

    function draw() {
      if (!sp) { A.clear(ctx.body); sp = ctx.split(); }
      A.clear(sp.main);
      const c = com(ckey);
      const views = viewsOf();
      const v = views.some(x => x.id === p.v) ? p.v : views[0].id;
      const rows = rowsIn();
      // The title row: the crumb names the list's parent (round-shifts R1): the committee's page, or for the
      // committee holding Shifts on another committee's list, the whole list.
      const holderOn = c && X.role === 'holder' && !ownC(ckey);
      const crumb = c && c.on_year ? (holderOn ? { label: 'Shifts', to: { s: 'shifts', c: '' } } : { label: c.name, to: { s: 'committees', c: ckey, id: '', v: '' } }) : null;
      // Who runs what is hidden in simple mode: the holder is said, not a door.
      const runBy = X.role === 'coa' && X.holder ? (A.simple && A.simple() ? h('span', { class: 'cm-runby', text: 'Run by ' + X.holder.name }) : A.link({ s: 'committees', c: 'coa', at: 'who' }, 'Run by ' + X.holder.name, 'cm-runby')) : null;
      const fact = factOf();
      ctx.head(holderOn ? c.name : 'Shifts', runBy ? h('span', null, fact ? fact + ' · ' : '', runBy) : fact, actions(c, rows), crumb ? { crumb } : {});
      stickUnder();
      // The band: the filters as pills (the committee among them, for whoever sees every committee), then
      // the views.
      const pills = [];
      if (ckey && all()) pills.push({ field: 'c', label: 'Committee', values: [{ v: ckey, words: cName() || ckey }] });
      if (hf) pills.push({ field: 'household', label: 'Household', values: [{ v: hf, words: (X.household && X.household.words) || hf }] });
      if (F.day) pills.push({ field: 'day', label: 'Day', values: F.day.map(d => ({ v: d, words: K.day(d) })) });
      if (F.place) pills.push({ field: 'place', label: 'Place', values: F.place.map(x => ({ v: x, words: x === 'none' ? 'To choose' : ((X.choices.places.find(pl => pl.code.toUpperCase() === x.toUpperCase()) || {}).name || x) })) });
      const fp = A.pills(pills, { onClear: field => field === 'c' ? A.go({ c: '' }) : clearF(field), onClearAll: () => A.go(all() ? { c: '' } : { v: p.v || '', f: '' }) });
      if (fp || views.length > 1) sp.main.appendChild(h('div', { class: 'cm-toolbar' }, views.length > 1 ? A.views(views, v, id => A.go({ v: id === views[0].id ? '' : id, f: p.f || '' })) : null, fp));
      if (!rows.length && v !== 'committee') {
        if (ckey && !X.shifts.some(s => s.c === ckey)) {
          sp.main.appendChild(A.empty({ title: 'No shifts', line: c && c.can.shifts ? '' : 'The COA adds them', inset: true, action: c && c.can.shifts && !ro() ? A.btn('Add shift', { write: true, onClick: () => openPanel('add') }) : null }));
        } else sp.main.appendChild(A.empty({ title: 'No shifts match', inset: true, action: A.link({ f: '' }, 'Clear', 'ap-btn') }));
        return panels();
      }
      if (v === 'committee') byCommittee();
      else if (v === 'waiting') waitList();
      else if (v === 'tocall') callList();
      else {
        if (c && D && v === 'day') headTools(c);
        if (c && v === 'day') looksRight(c);
        if (!c && all() && v === 'day') notChecked();
        dayList(v === 'short' ? rows.filter(s => s.open > 0) : v === 'draft' ? rows.filter(s => s.draft) : rows, !ckey);
      }
      panels();
    }
    const clearF = field => { const n = Object.assign({}, F); delete n[field]; A.go({ v: p.v || '', f: A.fString(n) }); };

    // The one filled button by season (round-shifts 6.3), then the quiet ones.
    function actions(c, rows) {
      const acts = [];
      const drafts = (X.shifts || []).filter(s => s.draft && (!ckey || s.c === ckey));
      const canAdd = ckey ? !!(c && c.can.shifts) : (X.committees || []).some(x => x.can.shifts && x.on_year);
      const canMsg = !!(c && c.can.head && D && (X.shifts || []).some(s => s.c === ckey && s.people.length));
      let primary = '';
      if (X.can.publish && !X.gone) primary = !X.posted ? 'publish' : drafts.length ? 'changes' : '';
      else if (c && ownC(ckey) && !X.gone) primary = !X.posted ? 'add' : canMsg ? 'msg' : '';
      if (primary === 'publish') acts.push(A.btn('Publish sign-ups', { primary: !panel && !p.id, write: true, onClick: () => openPanel('publish') }));
      if (primary === 'changes') acts.push(A.btn('Publish changes · ' + drafts.length, { primary: !panel && !p.id, write: true, onClick: () => openPanel('changes') }));
      if (primary === 'add' && canAdd) acts.push(A.btn('Add shift', { primary: !panel && !p.id, icon: 'plus', write: true, onClick: () => openPanel('add') }));
      if (canMsg) acts.push(A.btn('Message', { primary: primary === 'msg' && !panel, icon: 'mail', write: true, onClick: () => openPanel('msg') }));
      const more = [];
      if (canAdd && primary !== 'add' && !ro()) more.push({ label: 'Add shift', run: () => openPanel('add') });
      if (c && D && c.counts.shifts) more.push({ label: 'Print', run: printList });
      if (c && D && c.can.head && c.counts.shifts) more.push({ label: 'Download', run: () => K.fetchFile('ogc/v1/vol/' + y + '/lead/export?committee=' + encodeURIComponent(c.name) + (p.as ? '&as=' + encodeURIComponent(p.as) : ''), key(c.name).replace(/[^a-z0-9]+/g, '-') + '-volunteers-' + y + '.csv').then(() => vol('POST', '/printed', { committee: c.name, what: 'seen' }).then(() => refresh()).catch(() => {})).catch(() => A.toast('Not downloaded')) });
      // Import (and the shifts' own spreadsheet) stay in the shift sheet editor, a committee at a time.
      if (c && c.can.shifts && c.on_year && !ro()) more.push({ label: 'Import', run: () => editIn('shifts:' + c.name) });
      more.push({ label: 'Preview', run: () => window.open((window.OGC_WP && OGC_WP.base || '/annual-conference/') + 'volunteer/?year=' + y + '&preview=1' + (c ? '&committee=' + encodeURIComponent(c.name) : ''), '_blank', 'noopener') });
      if (X.can.publish && X.posted && !X.gone) more.push({ label: 'Publish sign-ups', run: () => openPanel('publish') });
      acts.push(K.more('More', more, { ghost: true }));
      return acts;
    }
    const editIn = what => { location.href = (window.OGC_WP && OGC_WP.base || '/annual-conference/') + 'admin/?year=' + y + '&edit=' + encodeURIComponent(what) + '&return=' + encodeURIComponent(location.pathname + location.search); };

    // A day's heading stays at the top while its shifts scroll, just under the app's title row (after the
    // ninth critic, Oct 16: on a phone's long list the day went out of sight). The row's height is measured,
    // as it's drawn again and when it wraps (on a phone it's the title, the counts and the buttons).
    function stickUnder() {
      const hd = document.querySelector('.ap-head');
      if (!hd || !sp) return;
      const set = el => { if (sp && el && el.isConnected) sp.el.style.setProperty('--cm-stick', Math.round(el.getBoundingClientRect().height) + 'px'); };
      set(hd);
      if (!window.ResizeObserver) return;
      if (!headRO) headRO = new ResizeObserver(es => es.forEach(e => set(e.target)));
      headRO.disconnect();
      headRO.observe(hd);
    }

    /* ---------------------------------------------------------------- By committee */

    function byCommittee() {
      const coms = X.committees || [];
      const chk = c => c.checked ? K.md(c.checked.on) + ' · ' + c.checked.by : X.from && c.counts.shifts && c.on_year ? 'Not checked' : '';
      sp.main.appendChild(A.table({
        label: 'Every committee’s shifts', key: c => c.key, rows: coms,
        onOpen: c => A.go({ c: c.key }),
        cols: [
          { label: 'Committee', render: c => h('span', { class: 'cm-title' }, c.name, c.on_year ? null : h('span', { class: 'ap-tag', text: 'No committee' })) },
          { label: 'Head', wide: true, render: c => c.on_year ? (c.heads.length ? c.heads.join(', ') : h('span', { class: 'ap-quiet', text: 'No head' })) : '' },
          { label: 'Shifts', cls: 'is-num', render: c => c.counts.shifts ? String(c.counts.shifts) : h('span', { class: 'ap-quiet', text: 'No shifts' }) },
          { label: 'Filled', cls: 'is-num', render: c => c.counts.places ? (c.counts.filled || 'None') + ' of ' + c.counts.places : c.counts.nolimit ? 'No limit' : '' },
          { label: 'Open', cls: 'is-num', render: c => c.counts.open ? h('span', { class: 'cm-chip cm-chip--tan', text: c.counts.open + ' open' }) : '' },
          { label: 'Waiting', cls: 'is-num', wide: true, render: c => c.counts.waiting ? String(c.counts.waiting) : '' },
          X.from ? { label: 'Checked', wide: true, render: c => { const t = chk(c); return t === 'Not checked' ? h('span', { class: 'cm-sub2 cm-tan', text: t }) : t; } } : null,
          coms.some(c => c.counts.draft) ? { label: 'Not public', cls: 'is-num', render: c => c.counts.draft ? String(c.counts.draft) : '' } : null,
          { label: '', cls: 'cm-endcell', render: () => h('span', { class: 'cm-chev', 'aria-hidden': 'true' }, A.icon('chev', 16)) }
        ].filter(Boolean)
      }));
      // Every committee's totals, each count a door to its view (never a zero).
      const t = X.counts || {};
      const views = viewsOf();
      const link = (id, words) => views.some(x => x.id === id) ? A.link({ v: id }, words) : h('span', { text: words });
      const parts = [t.places ? t.places + ' places' : '', t.places && t.filled ? t.filled + ' filled' : '', t.open ? t.open + ' open' : '', t.short && X.posted ? link('short', t.short + ' short') : '', t.waiting ? link('waiting', t.waiting + ' waiting') : ''].filter(Boolean);
      if (parts.length) sp.main.appendChild(h('p', { class: 'cm-pad cm-totals' }, ...parts.reduce((a, x, i) => a.concat(i ? [' · '] : [], [x]), [])));
      notChecked();
    }
    // "3 committees not checked" for the COA and the holder (R28), a door to By committee's Checked column.
    function notChecked() {
      if (!X.from || ro()) return;
      const n = (X.committees || []).filter(c => c.on_year && c.counts.shifts && !c.checked).length;
      if (!n) return;
      const wrap = h('p', { class: 'cm-pad cm-from' }, h('span', { class: 'cm-from__t', text: 'From ' + X.from }), h('span', { text: K.plural(n, 'committee') + ' not checked' }));
      if ((p.v || '') !== '' && (p.v || '') !== 'committee') wrap.appendChild(A.link({ v: '' }, 'By committee', 'ap-link'));
      sp.main.appendChild(wrap);
    }

    /* ---------------------------------------------------------------- a committee's own tools */

    function headTools(c) {
      // Who left lately, printed or not, each with the shift's day and time ("Mark Kline left · Sat, May
      // 29 · 3–7 PM"; the job too when the committee has several): since this person last printed or
      // downloaded, else the last seven days (after the third critic, Oct 15). Newest first. Each person
      // and shift once (the newest), and not someone who is back on that shift now.
      const shifts = X.shifts.filter(s => s.c === ckey);
      const seen = new Set(), xs = (D.left || []).slice().reverse().filter(l => {
        const k = l.act + '|' + l.shift + '|' + String(l.name).toLowerCase(), s = findX(l.shift);
        if (seen.has(k) || (s && s.people.some(pp => String(pp.name).toLowerCase() === String(l.name).toLowerCase()))) return false;
        seen.add(k); return true;
      });
      // A print or a download moves what's above the fold to "Earlier", never out of sight (after the
      // fourth critic, Oct 15: a cancelled print dialog emptied the list for good).
      if (xs.length) {
        const roles = new Set(shifts.map(s => s.role));
        const said = l => {
          const w = LEFT_SAY[l.act] || LEFT_SAY.left;
          if (!l.shift_short) return K.facts([l.name + (LEFT_ACT[l.act] || ' left'), l.when, leftAt(l)]);
          return K.facts([l.name + ' ' + w[0] + ' ' + (roles.size > 1 && l.role ? l.role + ' · ' : '') + l.shift_short, w[1], leftAt(l)]);
        };
        const fresh = xs.filter(l => l.group !== 'earlier'), older = xs.filter(l => l.group === 'earlier');
        const list = ls => h('ul', { class: 'cm-left__l' }, ls.map(l => h('li', { text: said(l) })));
        const fold = (label, ls) => h('details', { class: 'cm-left__more' }, h('summary', { text: label }), list(ls));
        sp.main.appendChild(h('div', { class: 'cm-pad cm-since cm-left' },
          fresh.length ? h('span', { class: 'ap-label', text: D.since ? 'Since you printed' : 'Last 7 days' }) : h('span', { class: 'ap-label', text: 'Who left' }),
          fresh.length ? list(fresh.slice(0, 6)) : null,
          fresh.length > 6 ? fold((fresh.length - 6) + ' more', fresh.slice(6)) : null,
          older.length ? fold('Earlier · ' + older.length, older) : null));
      }
      // For every shift: the committee's one instruction (the volunteer page says it once, the emails
      // too) and which reminders go. Its head or the COA changes them.
      const su = D.setup;
      const setupLink = su && su.can && !ro() ? h('button', { type: 'button', class: 'ap-link cm-setup__go', on: { click: () => openPanel('setup') } }, su.instruction ? 'Change' : 'Add instruction') : null;
      if (su && c.can.head) sp.main.appendChild(h('div', { class: 'cm-pad cm-setup' },
        su.instruction ? h('p', { class: 'cm-setup__l' }, h('span', { class: 'ap-label', text: 'For every shift' }), h('span', { class: 'cm-setup__t', text: su.instruction })) : null,
        h('p', { class: 'cm-setup__l' }, h('span', { class: 'ap-label', text: 'Reminders' }), h('span', { class: 'cm-setup__t', text: remindWords(su) }), setupLink)));
    }
    // "From 2026 · Check Food's shifts · Looks right" (R28): a committee's carried shifts, not yet checked.
    function looksRight(c) {
      if (!X.from || !c.counts.shifts || !c.on_year) return;
      if (c.checked) return;
      if (!c.can.shifts) return;
      const btn = A.btn('Looks right', { write: true, title: 'Carried from ' + X.from + ' · Checked by you', onClick: () => {
        btn.disabled = true;
        A.api('POST', 'shifts/check', { c: ckey }).then(() => {
          A.toast('Checked · ' + poss(c.name) + ' shifts', { undo: () => A.api('POST', 'shifts/check', { c: ckey, undo: true }).then(refresh).catch(A.fail) });
          refresh();
        }).catch(e => { btn.disabled = false; A.fail(e); });
      } });
      sp.main.appendChild(h('div', { class: 'cm-pad cm-from', role: 'note' }, h('span', { class: 'cm-from__t', text: 'From ' + X.from }), h('span', { text: 'Check ' + poss(c.name) + ' shifts' }), btn));
    }

    /* ---------------------------------------------------------------- By day (and Short, Not public) */

    function dayList(shifts, withC) {
      const sh = sharedOf(shifts, withC || shifts.length < 2);
      if (sh.line) sp.main.appendChild(h('p', { class: 'cm-pad cm-shared', text: sh.line }));
      const byDay = {};
      shifts.forEach(s => { (byDay[dayKey(s)] = byDay[dayKey(s)] || []).push(s); });
      const rows = [];
      Object.keys(byDay).sort().forEach(d => {
        rows.push(h('tr', { class: 'cm-group' }, h('td', { colspan: '4', text: dayHead(d, byDay[d]) + ' · ' + K.plural(byDay[d].length, 'shift') })));
        byDay[d].forEach(s => {
          const full = s.unlimited ? null : s.n / Math.max(1, s.needed);
          // The whole row opens the shift (its time or job is the button, for the keyboard), with a chevron
          // on a phone; a phone number in it still calls (after the fourth critic, Oct 15).
          const openIt = () => openShift(s.id);
          const rowTap = e => { if (e.target.closest('a, button, input, label, summary')) return; openIt(); };
          // On a phone (no Who column) the names are a full-width line under the row, each with its phone.
          const whoM = X.gone || !s.people.length ? null : h('tr', { class: 'cm-who-tr cm-tap' + (p.id === s.id ? ' is-open' : ''), on: { click: rowTap } }, h('td', { colspan: '4' }, h('ul', { class: 'cm-who-m', 'aria-label': 'Who' }, s.people.map(pp => h('li', { class: 'cm-who-m__p' }, h('span', { class: 'cm-who-m__n', text: pp.name + (pp.minor ? ' · Under 18' : '') + (pp.confirmed === false ? ' · Unconfirmed' : '') }), K.phone(pp.phone), pp.via ? h('span', { class: 'cm-sub2', text: 'via ' + pp.via }) : null)))));
          const tag = s.draft ? 'Not public' : '';
          rows.push(h('tr', { class: 'cm-tap' + (p.id === s.id ? ' is-open' : '') + (whoM ? ' has-who' : ''), 'data-sid': s.id, on: { click: rowTap } },
            h('td', null, h('button', { type: 'button', class: 'cm-rowbtn', 'aria-label': (sh.role != null ? '' : s.role + ', ') + (s.night ? s.day_words : K.day(s.date)) + ' ' + span(s), on: { click: openIt } }, h('span', { class: 'cm-title' + (sh.role != null ? '' : ' cm-title--job'), text: sh.role != null ? when(s) : s.role })), rowSubEl(s, sh, withC),
              tag || !s.place_ok ? h('span', { class: 'cm-rowtags' }, tag ? h('span', { class: 'ap-tag ap-tag--tan', text: tag }) : null, !s.place_ok ? h('span', { class: 'cm-sub2 cm-tan', text: 'Place to choose' }) : null) : null),
            h('td', { class: 'is-num cm-filled' }, h('span', { class: 'ap-bar', 'aria-hidden': 'true' }, h('i', { style: { width: Math.round(100 * Math.min(1, full == null ? 1 : full)) + '%' } })), h('span', { class: 'cm-filled__n', text: s.unlimited ? (s.n ? String(s.n) : 'None yet') : s.n ? s.n + ' of ' + s.needed : 'None yet' })),
            // On a laptop each person with their phone in the row, as on a phone (after the sixth critic).
            h('td', { class: 'is-wide' }, X.gone ? '' : h('ul', { class: 'cm-who-l', 'aria-label': 'Who' }, s.people.map(pp => h('li', { class: 'cm-who-l__p' }, h('span', { class: 'cm-who-l__n', text: pp.name + (pp.minor ? ' (under 18)' : '') + (pp.confirmed === false ? ' · Unconfirmed' : '') }), pp.phone ? K.phone(pp.phone) : null, pp.via ? h('span', { class: 'cm-sub2', text: 'via ' + pp.via }) : null))), s.waiting.length ? h('span', { class: 'cm-sub2', text: s.waiting.length + ' waiting' }) : null),
            h('td', { class: 'is-num cm-endcell' }, !s.unlimited && s.n < s.needed ? h('span', { class: 'cm-chip cm-chip--tan', text: (s.needed - s.n) + ' open' }) : s.over ? h('span', { class: 'cm-chip', text: s.over + ' over' }) : !s.unlimited ? h('span', { class: 'cm-chip', text: 'Full' }) : null, h('span', { class: 'cm-chev', 'aria-hidden': 'true' }, A.icon('chev', 16)))));
          if (whoM) rows.push(whoM);
        });
      });
      sp.main.appendChild(h('div', { class: 'cm-scroll' }, h('table', { class: 'cm-table cm-helpers' }, h('thead', null, h('tr', null, h('th', { text: 'Shift' }), h('th', { class: 'is-num', text: 'Filled' }), h('th', { class: 'is-wide', text: 'Who' }), h('th', null, h('span', { class: 'ap-sr', text: 'Open' })))), h('tbody', null, rows))));
    }

    /* ---------------------------------------------------------------- Waiting, To call */

    function waitList() {
      const ws = waitsIn();
      sp.main.appendChild(A.table({
        label: 'Waiting', key: w => w.rid, rows: ws, onOpen: w => openShift(w.s.id),
        cols: [
          { label: 'Name', render: w => h('b', { text: w.name }) },
          ckey ? null : { label: 'Committee', wide: true, render: w => w.s.committee },
          { label: 'Shift', render: w => w.s.role + ' · ' + dayWhen(w.s) },
          { label: 'Since', wide: true, render: w => K.md(w.at) },
          { label: '', render: w => w.s.can.head && !ro() ? A.btn('Offer', { write: true, title: 'Emails them a one-tap Join', onClick: () => vol('POST', '/offer', { committee: w.s.committee, id: w.rid }).then(() => A.toast('Offered · ' + w.name)).catch(A.fail) }) : '' }
        ].filter(Boolean)
      }));
    }
    function callList() {
      const ls = callIn();
      if (!ls.length) { sp.main.appendChild(A.empty({ title: 'All called', inset: true, action: A.link({ s: 'home' }, 'Home', 'ap-btn') })); return; }
      sp.main.appendChild(A.table({
        label: 'To call', key: t => t.rid, rows: ls, onOpen: t => openVol(t.rid),
        cols: [
          { label: 'Name', render: t => h('b', { text: t.name }) },
          { label: 'Phone', render: t => K.phone(t.phone) || '' },
          { label: 'Helper', wide: true, render: t => t.helper || '' },
          { label: 'Why', render: t => { const s = findX(t.shift); return K.facts([t.why, s ? s.role : '', s ? dayWhen(s) : '']); } },
          { label: '', render: t => ro() ? '' : A.btn('Called', { write: true, onClick: () => A.api('POST', 'shifts/called', { rid: t.rid }).then(() => { A.toast('Called · ' + t.name, { undo: () => A.api('POST', 'shifts/called', { rid: t.rid, undo: true }).then(refresh).catch(A.fail) }); refresh(); }).catch(A.fail) }) }
        ]
      }));
    }

    /* ---------------------------------------------------------------- panels */

    function panels() {
      if (panel === 'msg') return msgPanel();
      if (panel === 'sent') return sentPanel();
      if (panel === 'setup') return setupPanel();
      if (panel === 'publish') return publishPanel();
      if (panel === 'changes') return changesPanel();
      if (panel === 'add' || p.id === 'new') return addPanel();
      if (/^vol-\d+$/.test(p.id || '')) { const r = personOf(+p.id.slice(4)); if (r) return volPanel(r); }
      const s = p.id && findX(p.id);
      if (s) shiftPanel(s); else sp.close(true);
    }
    function openPanel(k, to) { panel = k; msgTo = to || ''; p.id = ''; A.setParams({ id: '' }); draw(); }
    // A shift or a person opens beside the list as its own history entry (Back closes it first).
    function openShift(id) { panel = ''; p.id = id; A.openRecord({ id }); draw(); }
    function openVol(rid) { panel = ''; p.id = 'vol-' + rid; A.openRecord({ id: p.id }); draw(); }
    const closeRec = () => { p.id = ''; A.closeRecord(); draw(); };
    // Previous · Next through the list as drawn.
    function navOf(id) {
      const ids = [...sp.main.querySelectorAll('tr[data-sid]')].map(tr => tr.dataset.sid);
      const list = ids.length ? ids : rowsIn().map(s => s.id);
      const i = list.indexOf(id);
      return { prev: i > 0 ? () => openShift(list[i - 1]) : null, next: i > -1 && i < list.length - 1 ? () => openShift(list[i + 1]) : null };
    }

    // Every leave the year's log keeps for one shift, newest first, each line once.
    function shiftLeft(s) {
      const seen = new Set();
      return ((D && D.left) || []).filter(l => l.shift === s.id).slice().reverse().filter(l => { const k = l.act + '|' + String(l.name).toLowerCase() + '|' + leftAt(l); if (seen.has(k)) return false; seen.add(k); return true; });
    }
    // Save one field of a shift, and say what it did (round-shifts 7.6): the server's reason at the field.
    function saveField(s, field, value, err) {
      if (err) err.textContent = '';
      return A.api('POST', 'shifts/save', { id: s.id, field, value }).then(r => {
        if (r && r.same) return;
        A.toast(K.facts(['Saved', r && r.told ? K.plural(r.told, 'person', 'people') + ' told' : '']));
        refresh();
      }).catch(e => { const d = e.data || {}; if (err) err.textContent = d.message || 'Not saved'; else A.fail(e); });
    }
    // The shift's fields (round-shifts 7.1): each edited in place and saved when it's left.
    function fieldsOf(s, can) {
      const off = !can || ro();
      const err = () => h('p', { class: 'ap-err', role: 'alert' });
      const fld = (label, ...kids) => h('div', { class: 'ap-field cm-sf' }, h('span', { text: label }), ...kids);
      const text = (field, val, o) => {
        const e = err(), i = h('input', Object.assign({ class: 'ap-input', value: val || '', disabled: off, autocomplete: 'off', 'aria-label': o.label }, o.attrs || {}));
        i.addEventListener('change', () => saveField(s, field, i.value, e));
        return [i, e];
      };
      const pills = (field, opts, curV, label) => {
        const e = err();
        const el = K.pills(opts, curV, x => { if (x !== curV) saveField(s, field, x, e); }, label);
        el.querySelectorAll('button').forEach(b => { b.disabled = off; });
        return [el, e];
      };
      const out = [];
      if (all() && !s.allweek) {
        const id = 'cm-sf-c-' + Math.random().toString(36).slice(2, 7);
        const [i, e] = text('committee', s.on_year ? s.committee : '', { label: 'Committee', attrs: { list: id, placeholder: 'Choose' } });
        out.push(fld('Committee', i, h('datalist', { id }, (X.committees || []).filter(c => c.on_year && c.can.shifts).map(c => h('option', { value: c.name }))), e));
      }
      out.push(fld('Job', ...text('role', s.role, { label: 'Job', attrs: { maxlength: '60' } })));
      if (!s.allweek) {
        out.push(fld('Day', ...pills('date', X.choices.days.map(d => [d.date, K.day(d.date)]), s.date, 'Day')));
        const [si, se] = text('start', hm(s.start), { label: 'Start', attrs: { placeholder: '11:45 AM', inputmode: 'text' } });
        const [ei, ee] = text('end', hm(s.end), { label: 'End', attrs: { placeholder: '2:15 PM' } });
        out.push(h('div', { class: 'cm-sf2' }, fld('Start', si, se), fld('End', ei, ee)));
      }
      const pid = 'cm-sf-p-' + Math.random().toString(36).slice(2, 7);
      const [pi, pe] = text('place', s.place_ok ? s.place : '', { label: 'Place', attrs: { list: pid, placeholder: 'Place to choose' } });
      out.push(fld('Place', pi, h('datalist', { id: pid }, X.choices.places.map(pl => h('option', { value: pl.name }))), s.place_code && !s.place_ok ? h('span', { class: 'ap-help', text: 'Was ' + s.place_code + ' · Not at this campus' }) : null, pe));
      const ne = err(), ni = h('input', { class: 'ap-input cm-sf__n', type: 'number', min: '1', max: '99', value: s.unlimited ? '' : String(s.needed), disabled: off, 'aria-label': 'Needed' });
      ni.addEventListener('change', () => saveField(s, 'needed', ni.value, ne));
      const nl = h('button', { type: 'button', class: 'ap-pill', 'aria-pressed': String(!!s.unlimited), disabled: off, on: { click: () => { if (!s.unlimited) saveField(s, 'needed', 'nolimit', ne); } } }, 'No limit');
      out.push(fld('Needed', h('div', { class: 'ap-row cm-sf__row' }, ni, nl), ne));
      out.push(fld('Rule', ...pills('rule', RULES, s.rule_key, 'Rule'), s.rule_key === 'other' ? h('span', { class: 'ap-help', text: 'Now: ' + s.rule_words }) : null));
      return out;
    }
    function shiftPanel(s) {
      const others = X.shifts.filter(x => x.id !== s.id && x.c === s.c);
      const during = X.begun;
      const canP = s.can.people && !ro(), canH = s.can.head && !ro();
      const withheld = 'Withheld · ' + s.committee + ' and the COA';
      const person = pp => {
        const here = h('input', { type: 'checkbox', class: 'ap-check', checked: pp.here, disabled: ro() || !s.can.head, 'aria-label': 'Here: ' + pp.name });
        here.addEventListener('change', () => vol('POST', '/here', { committee: s.committee, id: pp.rid, here: here.checked }).then(() => { pp.here = here.checked; A.toast(pp.name + (here.checked ? ' · Here' : ' · Not here')); forget(); }).catch(e => { here.checked = !here.checked; A.fail(e); }));
        const ask = h('p', { class: 'cm-sub2 cm-move__ask', hidden: true });
        const moveTo = h('div', { hidden: true }, ask, h('p', { class: 'ap-label cm-sub', text: 'Move to' }), h('div', { class: 'ap-pills' }, others.slice(0, 30).map(o => h('button', { type: 'button', class: 'ap-pill', on: { click: () => vol('POST', '/move', { committee: s.committee, id: pp.rid, to: o.id }).then(() => { A.toast('Moved · ' + pp.name + ' · ' + o.role + ' · ' + dayWhen(o)); refresh(); }).catch(e => A.toast((e.data && e.data.message) || 'Not moved')) } }, o.role + ' · ' + dayWhen(o)))));
        // The holder moving another committee's volunteer sees that one person's phone first (the handing
        // rule's "a phone only on the person being moved"), and the server logs it.
        const move = () => {
          if (!moveTo.hidden) { moveTo.hidden = true; return; }
          if (pp.withheld) A.api('GET', 'shifts/phone?rid=' + pp.rid).then(r => { ask.hidden = false; A.clear(ask).append('Moving ' + r.name + ' · ', K.phone(r.phone) || 'No phone'); moveTo.hidden = false; }).catch(A.fail);
          else moveTo.hidden = false;
        };
        const nameBtn = h('button', { type: 'button', class: 'ap-link cm-person__n', title: 'Their shifts', on: { click: () => openVol(pp.rid) } }, h('b', { text: pp.name }));
        return h('li', { class: 'cm-person' },
          h('div', { class: 'cm-person__main' }, nameBtn, h('span', { class: 'cm-sub2 cm-person__line' }, pp.withheld ? withheld : K.phone(pp.phone), pp.via ? ' · via ' + pp.via : '', pp.phone && pp.email ? ' · ' : '', pp.email ? h('span', { class: 'cm-email', text: pp.email }) : '', pp.minor ? ' · Under 18' : '', pp.by === 'head' ? ' · Added by a head' : '', pp.over ? ' · Past the count' : '', pp.by === 'helper' && pp.helper && !pp.via ? ' · Signed up by ' + pp.helper : '', pp.confirmed === false ? ' · Unconfirmed' : '', pp.hidden ? ' · Name hidden' : '', pp.reach && pp.reach !== 'email' ? ' · ' + REACH[pp.reach] : ''), pp.note ? h('span', { class: 'cm-sub2', text: pp.note }) : null),
          ro() ? null : h('div', { class: 'ap-row' }, during && s.can.head ? h('label', { class: 'ap-switch' }, here, 'Here') : null,
            canP && others.length ? A.btn('Move', { ghost: true, onClick: move }) : null,
            canP ? A.btn('Remove', { ghost: true, danger: true, write: true, onClick: () => vol('POST', '/remove', { committee: s.committee, id: pp.rid }).then(() => {
              A.toast('Removed · ' + pp.name, { undo: () => vol('POST', '/restore', { committee: s.committee, id: pp.rid }).then(() => { A.toast('Restored · ' + pp.name); refresh(); }).catch(e => A.toast((e.data && e.data.message) || 'Can’t undo')) });
              refresh();
            }).catch(A.fail) }) : null), moveTo);
      };
      const name = h('input', { class: 'ap-input', autocomplete: 'off', maxlength: '80' }), phone = h('input', { class: 'ap-input', type: 'tel', autocomplete: 'off' }), email = h('input', { class: 'ap-input', type: 'email', autocomplete: 'off' });
      const err = h('p', { class: 'ap-err', role: 'alert' });
      const add = () => vol('POST', '/add', { committee: s.committee, shift: s.id, name: name.value, phone: phone.value, email: email.value }).then(() => { A.toast('Added · ' + name.value.trim() + ' · ' + s.role + ' · ' + dayWhen(s)); refresh(); })
        .catch(e => { const d = e.data || {}; err.textContent = d.code === 'busy' || (d.data && d.data.busy) ? 'Busy · On ' + ((d.data && d.data.busy && d.data.busy.role) || 'another shift') + ' then' : d.data && d.data.fields ? Object.values(d.data.fields).filter(Boolean).join(' · ') : d.message || 'Not added'; });
      // Linked (README 2.7): by stored ids only. The place opens its Campus record for whoever may open
      // Campus; the schedule rows at this time, the day's Schedule for whoever may open it.
      const linked = [
        s.on_year ? { kind: 'committee', label: 'Committee · ' + s.committee, go: { s: 'committees', c: s.c } } : null,
        s.place_ok && s.place_id && A.allowed('campus') ? { kind: 'place', label: 'Place · ' + s.place, go: { s: 'campus', id: s.place_id } } : null,
        s.sched && A.allowed('schedule') ? { kind: 'schedule', label: 'Schedule at this time', n: s.sched, go: { s: 'schedule', v: String(s.day || '').toLowerCase() } } : null
      ].filter(Boolean);
      const tags = [s.draft ? A.tag('Not public', 'tan') : !s.draft && STATE[s.state] && s.state !== 'not_open' ? A.tag(STATE[s.state]) : null, s.state === 'full' ? A.tag('Full') : null, s.rule ? A.tag(s.rule) : null].filter(Boolean);
      sp.open({
        title: s.role, tags, nav: navOf(s.id),
        body: [
          // Each fact whole on its line ("1 of 4" never splits; after the sixth critic, Oct 15). A night
          // shift by its night: "Fri night, May 28 · 12–3 AM" (after the eighth critic, Oct 16).
          h('p', { class: 'cm-detail__m' }, ...[ckey ? '' : s.committee, s.allweek ? 'All week' : s.night ? s.day_words : K.day(s.date), span(s), s.place || 'Place to choose', s.unlimited ? K.plural(s.n, 'person', 'people') : s.n + ' of ' + s.needed].filter(Boolean).reduce((a, t, i) => a.concat(i ? [' · '] : [], [h('span', { class: 'cm-nw', text: t })]), [])),
          s.rule ? h('p', { class: 'ap-quiet', text: s.rule_words || s.rule }) : null,
          // The shift's fields first (round-shifts 7.1), open until the Conference begins; in the week the
          // people come first, so the fold starts closed.
          h('details', { class: 'cm-fold cm-sfs', open: !X.begun || p.at === 'fields' }, h('summary', { text: 'Shift' }), fieldsOf(s, s.can.shifts)),
          // Message only this shift's people (Transportation sent one a shift on May 28, 2026).
          canH && s.people.length ? h('p', null, A.btn('Message this shift', { icon: 'mail', ghost: true, write: true, onClick: () => { msgC = s.c; openPanel('msg', 'shift:' + s.id); } })) : null,
          h('h3', { class: 'ap-rec__h', text: s.unlimited ? 'People · ' + s.n : 'People · ' + s.n + ' of ' + s.needed }),
          s.people.length ? h('ul', { class: 'cm-plain cm-people2' }, s.people.map(person)) : h('p', { class: 'ap-quiet', text: X.gone ? 'Names cleared' : 'No one yet' }),
          // This shift's own history of who left (after the seventh and ninth critics, Oct 15–16).
          (() => {
            const ls = shiftLeft(s), li = l => h('li', { text: K.facts([l.name + (LEFT_ACT[l.act] || ' left'), leftAt(l)]) });
            return ls.length ? [h('h3', { class: 'ap-label cm-sub', text: 'Left · ' + ls.length }), h('ul', { class: 'cm-plain cm-left__l cm-left--shift' }, ls.slice(0, 6).map(li)),
              ls.length > 6 ? h('details', { class: 'cm-left__more' }, h('summary', { text: (ls.length - 6) + ' more' }), h('ul', { class: 'cm-plain cm-left__l cm-left--shift' }, ls.slice(6).map(li))) : null] : null;
          })(),
          s.waiting.length ? [h('h3', { class: 'ap-label cm-sub', text: 'Waiting · ' + s.waiting.length }), h('ul', { class: 'cm-plain' }, s.waiting.map(w => h('li', { class: 'ap-row' }, h('span', { style: { flex: '1' } }, h('b', { text: w.name }), ' ', w.withheld ? h('span', { class: 'cm-sub2', text: withheld }) : K.phone(w.phone)), canH ? A.btn('Offer', { write: true, title: 'Emails them a one-tap Join', onClick: () => vol('POST', '/offer', { committee: s.committee, id: w.rid }).then(() => A.toast('Offered · ' + w.name)).catch(A.fail) }) : null)))] : null,
          canP && !X.gone ? h('details', { class: 'cm-fold', open: !s.people.length }, h('summary', { text: 'Add person' }),
            h('label', { class: 'ap-field' }, h('span', { text: 'Name' }), name),
            h('label', { class: 'ap-field' }, h('span', { text: 'Phone' }), phone),
            h('label', { class: 'ap-field' }, h('span', { text: 'Email' }), email, h('span', { class: 'ap-help', text: 'Optional · They get a confirmation' })),
            err, A.btn('Add', { primary: true, write: true, onClick: add })) : null,
          A.linked(linked, { from: 'shifts:' + s.id, name: s.role })
        ],
        foot: s.can.shifts && !ro() ? [A.btn('Remove shift', { ghost: true, danger: true, write: true, onClick: () => removeShift(s) })] : null,
        onClose: closeRec
      });
    }
    // Remove a shift: asks first, then the people on it are told (round-shifts 7.4).
    function removeShift(s) {
      sp.open({ title: 'Remove shift', body: [h('p', { class: 'cx-decide__line', text: s.role + ' · ' + dayWhen(s) }), s.n ? h('p', { class: 'cx-decide__line', text: K.plural(s.n, 'person', 'people') + ' on it · They’re told' }) : null],
        foot: [A.btn('Remove', { danger: true, write: true, onClick: () => A.api('POST', 'shifts/remove', { id: s.id }).then(r => { A.toast(K.facts(['Removed · ' + s.role, r && r.people ? K.plural(r.people, 'person', 'people') + ' told' : ''])); p.id = ''; A.setParams({ id: '' }); refresh(); }).catch(A.fail) }),
          A.btn('Cancel', { ghost: true, onClick: () => shiftPanel(s) })], onClose: closeRec });
    }

    /* ---------------------------------------------------------------- the volunteer */

    // A volunteer is every place with one person key (the server's, never a name compared to a name: R8).
    function personOf(rid) {
      for (const s of X.shifts || []) { const pp = s.people.find(x => x.rid === rid); if (pp) return { s, pp }; }
      return null;
    }
    function volPanel(r) {
      const pk = r.pp.pk;
      const seats = (X.shifts || []).flatMap(s => s.people.filter(x => x.pk === pk).map(pp => ({ s, pp })));
      const pp = r.pp, w = pp.withheld ? 'Withheld · ' + r.s.committee + ' and the COA' : '';
      const fact = (k, v) => v ? [h('dt', { text: k }), h('dd', null, v)] : null;
      const lines = seats.map(x => ({ kind: 'shift', label: x.s.role + ' · ' + dayWhen(x.s) + (x.s.place ? ' · ' + x.s.place : '') + (x.pp.confirmed === false ? ' · Unconfirmed' : ''), go: { s: 'shifts', c: ckey ? x.s.c : '', id: x.s.id } }));
      const hh = pp.reg && A.allowed('households') ? A.linked([{ kind: 'household', label: 'Household · ' + pp.reg, go: { s: 'households', id: pp.reg } }], { from: 'shifts:vol-' + pp.rid, name: pp.name }) : null;
      // Their shifts are the panel's Linked part, said as what they are ("Shifts · 2").
      const sh = A.linked(lines, { from: 'shifts:vol-' + pp.rid, name: pp.name });
      if (sh) sh.querySelector('.ap-rec__h').textContent = 'Shifts · ' + seats.length;
      sp.open({
        title: pp.name, tags: [pp.confirmed === false ? A.tag('Unconfirmed', 'tan') : null].filter(Boolean),
        body: [
          h('dl', { class: 'ap-facts' },
            fact('Phone', w ? h('span', { class: 'cm-sub2', text: w }) : K.phone(pp.phone)),
            fact('Email', w ? h('span', { class: 'cm-sub2', text: w }) : pp.email ? h('span', { class: 'cm-email', text: pp.email }) : ''),
            fact('Signed up by', (BY[pp.by] || 'Self') + (pp.helper ? ' · ' + pp.helper : '')),
            fact('Reached by', REACH[pp.reach] || ''),
            fact('On the page', pp.hidden ? 'Name hidden' : 'Name shown')),
          sh, hh,
          pp.note ? [h('h3', { class: 'ap-rec__h', text: 'Note' }), h('p', { class: 'cm-sub2', text: pp.note })] : null
        ],
        onClose: closeRec
      });
    }

    /* ---------------------------------------------------------------- Add shift */

    function addPanel() {
      const days = X.choices.days;
      const fixed = ckey && com(ckey) && com(ckey).on_year ? com(ckey) : null;
      const st = { committee: fixed ? fixed.name : '', role: '', date: (F.day || [])[0] || (days[0] || {}).date || '', start: '', end: '', place: '', needed: '', rule: 'none' };
      const errs = {};
      const e = k => (errs[k] = h('p', { class: 'ap-err', role: 'alert' }));
      const inp = (k, o) => { const i = h('input', Object.assign({ class: 'ap-input', autocomplete: 'off', 'aria-label': o.label }, o.attrs || {})); i.addEventListener('input', () => { st[k] = i.value; }); return i; };
      const fld = (label, ...kids) => h('div', { class: 'ap-field cm-sf' }, h('span', { text: label }), ...kids);
      const cid = 'cm-add-c', pid = 'cm-add-p';
      const dayPills = h('div');
      const drawDays = () => A.clear(dayPills).appendChild(K.pills(days.map(d => [d.date, K.day(d.date)]), st.date, x => { st.date = x; drawDays(); }, 'Day'));
      drawDays();
      const rulePills = h('div');
      const drawRule = () => A.clear(rulePills).appendChild(K.pills(RULES, st.rule, x => { st.rule = x; drawRule(); }, 'Rule'));
      drawRule();
      const go = A.btn('Add', { primary: true, write: true, onClick: () => {
        Object.values(errs).forEach(x => { x.textContent = ''; });
        go.disabled = true;
        const com0 = (X.committees || []).find(c => c.name === st.committee || c.key === key(st.committee));
        A.api('POST', 'shifts/save', { id: 'new', fields: Object.assign({}, st, { committee: com0 ? com0.key : st.committee }) }).then(r => {
          A.toast(K.facts(['Added · ' + st.role, K.day(st.date), r.draft ? 'Not public' : '']));
          panel = '';
          forget();
          A.go({ c: ckey && p.c ? ckey : '', id: r.id });
        }).catch(x => {
          go.disabled = false;
          const d = (x.data && x.data.data) || {};
          const fs = d.fields || (d.field ? { [d.field]: x.data.message } : null);
          if (fs) Object.keys(fs).forEach(k => { if (errs[k]) errs[k].textContent = fs[k]; });
          else A.fail(x);
        });
      } });
      sp.open({
        title: 'Add shift',
        body: [
          fixed ? h('p', { class: 'cm-detail__m', text: fixed.name }) : fld('Committee', inp('committee', { label: 'Committee', attrs: { list: cid, placeholder: 'Choose', 'data-autofocus': '' } }), h('datalist', { id: cid }, (X.committees || []).filter(c => c.on_year && c.can.shifts).map(c => h('option', { value: c.name }))), e('committee')),
          fld('Job', inp('role', { label: 'Job', attrs: Object.assign({ maxlength: '60', placeholder: 'Like Golf cart driver' }, fixed ? { 'data-autofocus': '' } : {}) }), e('role')),
          fld('Day', dayPills, e('date')),
          h('div', { class: 'cm-sf2' }, fld('Start', inp('start', { label: 'Start', attrs: { placeholder: '11:45 AM' } }), e('start')), fld('End', inp('end', { label: 'End', attrs: { placeholder: '2:15 PM' } }), e('end'))),
          fld('Place', inp('place', { label: 'Place', attrs: { list: pid, placeholder: 'Place to choose' } }), h('datalist', { id: pid }, X.choices.places.map(pl => h('option', { value: pl.name }))), e('place')),
          fld('Needed', inp('needed', { label: 'Needed', attrs: { type: 'number', min: '1', max: '99' } }), e('needed')),
          fld('Rule', rulePills, e('rule')),
          X.posted && !X.begun ? h('p', { class: 'ap-help', text: 'Not public until Publish changes' }) : null
        ],
        foot: [go, A.btn('Cancel', { ghost: true, onClick: () => { panel = ''; p.id = ''; A.setParams({ id: '' }); sp.close(true); draw(); } })],
        onClose: () => { panel = ''; p.id = ''; A.setParams({ id: '' }); draw(); }
      });
    }

    /* ---------------------------------------------------------------- Publish */

    function publish(act) {
      return A.api('POST', 'shifts/publish', { act }).then(r => {
        A.toast({ publish: 'Published · ' + K.plural((X.counts || {}).places || 0, 'place'), changes: 'Published · ' + K.plural((r && r.n) || 0, 'shift'), close: 'Closed · Join stops on the page', reopen: 'Reopened' }[act]);
        panel = '';
        refresh();
      }).catch(A.fail);
    }
    // What's left before Publish (round-shifts 9.1): each a link the viewer can open; none blocks (R7).
    function leftLines() {
      const all0 = X.shifts || [];
      const out = [];
      const noPlace = all0.filter(s => !s.place_ok).length, noCom = all0.filter(s => !s.on_year);
      const unchecked = X.from ? (X.committees || []).filter(c => c.on_year && c.counts.shifts && !c.checked).length : 0;
      if (noPlace) out.push(A.link({ c: '', v: 'day', f: 'place:none' }, K.plural(noPlace, 'shift') + ' without a place'));
      if (noCom.length) out.push(A.link({ c: noCom[0].c, v: '' }, K.plural(noCom.length, 'shift') + ' with no committee'));
      if (unchecked) out.push(A.link({ c: '', v: '' }, K.plural(unchecked, 'committee') + ' not checked'));
      if (!X.phone) out.push(A.allowed('dates') ? A.link({ s: 'dates' }, 'Volunteering phone · Not set') : h('span', { text: 'Volunteering phone · Not set · Ask the COA' }));
      return out;
    }
    function publishPanel() {
      // Already public (the task's "Volunteer sign-ups open", or Home's line after the day): what's true, and
      // the same What's left; Publish changes takes over when shifts were added since.
      if (X.posted && (X.shifts || []).some(s => s.draft)) { panel = 'changes'; return changesPanel(); }
      const t = X.counts || {};
      const left = leftLines();
      const coms = (X.committees || []).filter(c => c.counts.shifts && c.on_year).length;
      const preview = h('a', { class: 'ap-btn ap-btn--ghost', href: (window.OGC_WP && OGC_WP.base || '/annual-conference/') + 'volunteer/?year=' + y + '&preview=1', target: '_blank', rel: 'noopener' }, 'Preview');
      sp.open({
        title: 'Publish sign-ups',
        tags: X.posted ? [A.tag(X.shut ? 'Closed' : 'Public', X.shut ? '' : 'ok')] : [A.tag('Not public', 'tan')],
        body: [
          h('p', { class: 'cm-detail__m', text: K.facts([X.posted && X.posted_on ? 'Public since ' + K.md(X.posted_on) : '', t.places ? K.plural(t.places, 'place') : '', K.plural(t.shifts || 0, 'shift'), K.plural(coms, 'committee')]) }),
          left.length ? [h('h3', { class: 'ap-rec__h', text: 'What’s left' }), h('ul', { class: 'cm-plain cm-left__l cm-publeft' }, left.map(x => h('li', null, x)))] : null,
          X.posted ? null : h('p', { class: 'ap-help', text: 'The volunteer page opens today · Nothing here holds it back' })
        ],
        foot: X.posted ? [preview, A.btn(X.shut ? 'Reopen sign-ups' : 'Close sign-ups', { ghost: true, write: true, onClick: () => publish(X.shut ? 'reopen' : 'close') })].filter(Boolean)
          : [A.btn(left.length ? 'Publish anyway' : 'Publish', { primary: true, write: true, onClick: () => publish('publish') }), preview,
            A.btn('Cancel', { ghost: true, onClick: () => { panel = ''; sp.close(true); draw(); } })],
        onClose: () => { panel = ''; draw(); }
      });
    }
    function changesPanel() {
      const drafts = (X.shifts || []).filter(s => s.draft && (!ckey || s.c === ckey));
      const left = leftLines().slice(0, 2);
      sp.open({
        title: 'Publish changes',
        body: [
          h('h3', { class: 'ap-rec__h', text: 'Not public · ' + drafts.length }),
          h('ul', { class: 'cm-plain cm-left__l cm-publeft' }, drafts.map(s => h('li', null, h('button', { type: 'button', class: 'ap-link', on: { click: () => openShift(s.id) } }, K.facts([s.committee, s.role, dayWhen(s)]))))),
          left.length ? [h('h3', { class: 'ap-rec__h', text: 'What’s left' }), h('ul', { class: 'cm-plain cm-left__l cm-publeft' }, left.map(x => h('li', null, x)))] : null
        ],
        foot: [A.btn('Publish · ' + drafts.length, { primary: true, write: true, disabled: !drafts.length, onClick: () => publish('changes') }), A.btn('Cancel', { ghost: true, onClick: () => { panel = ''; sp.close(true); draw(); } })],
        onClose: () => { panel = ''; draw(); }
      });
    }

    /* ---------------------------------------------------------------- Message (a committee's own) */

    // A message goes to one committee's volunteers: the list's, or (on every committee's list) the shift's.
    const comShifts = k => (X.shifts || []).filter(s => s.c === (k || ckey));
    function msgPanel() {
      const mk = msgC || ckey;
      const c = com(mk);
      if (!c) { panel = ''; return; }
      const shifts = comShifts(mk);
      // A day is the day and its night (Message › Fri reaches Friday's 12–3 AM too; the server's own rule).
      const days = Array.from(new Set(shifts.map(s => s.eve || s.date))).sort();
      let to = msgTo || 'all';
      const one = msgTo ? findX(msgTo.slice(6)) : null;
      const subject = h('input', { class: 'ap-input', maxlength: '140', 'data-autofocus': '' }), body = h('textarea', { class: 'ap-textarea', rows: '6' });
      const err = h('p', { class: 'ap-err', role: 'alert' }), count = h('p', { class: 'ap-quiet cm-msg__n' });
      // Who it reaches, as the server counts (after the ninth critic, Oct 16: a couple under one email was
      // one): each person with an email once by their name under it, and each without one to call.
      const who = () => {
        const people = new Set(), calls = new Set();
        shifts.filter(s => to === 'all' || 'day:' + (s.eve || s.date) === to || 'shift:' + s.id === to).forEach(s => s.people.forEach(pp => {
          const nm = String(pp.name || '').trim().replace(/\s+/g, ' ').toLowerCase();
          if (pp.email) people.add(String(pp.email).toLowerCase() + '|' + nm); else calls.add(nm + '|' + String(pp.phone || '').replace(/\D+/g, ''));
        }));
        return { people: people.size, call: calls.size };
      };
      const pills = h('div');
      let send = null;
      const drawPills = () => {
        A.clear(pills).appendChild(K.pills([['all', 'Everyone']].concat(days.map(d => ['day:' + d, K.day(d)])).concat(one ? [['shift:' + one.id, one.role + ' · ' + dayWhen(one)]] : []), to, x => { to = x; drawPills(); }, 'To'));
        const w = who();
        count.textContent = K.facts([w.people ? K.plural(w.people, 'person', 'people') : w.call ? 'Nobody by email' : 'No one yet', w.call ? w.call + ' to call' : '', D && (D.me_name || D.me) ? 'Replies to ' + (D.me_name || D.me) : '', D && D.msgs_left != null ? (D.msgs_left ? D.msgs_left + ' left today' : 'None left today') : '']);
        // Nobody on what's chosen, or the day's messages used: nothing to send (never "0 left").
        if (send) send.disabled = (!w.people && !w.call) || (D && D.msgs_left === 0);
      };
      send = A.btn('Send', { primary: true, icon: 'mail', write: true, onClick: () => {
        send.disabled = true;
        vol('POST', '/message', { committee: c.name, to: to === 'all' ? '' : to, subject: subject.value, body: body.value }).then(r => {
          r = r || {};
          const call = (r.call || []).map(callOf);
          // Who to call stays on screen, beside the list, until it's closed (after the ninth critic, Oct 16).
          sent = { said: sentWords(r), any: (r.people != null ? r.people : r.queued) > 0, skipped: r.skipped || 0, call };
          panel = call.length ? 'sent' : '';
          draw();
          A.toast(K.facts([sent.said, sent.skipped ? sent.skipped + ' skipped · Already ' + ((D && D.msgs_per_person) || 4) + ' today' : '', call.length ? (call.length > 2 ? 'Call ' + call.length + ' people' : 'Call ' + call.map(x => x.name).join(' and ')) : '']));
          forget();
          getD(c.name, true).then(d => { D = d; }).catch(() => {});
        }).catch(e => { send.disabled = false; const d = e.data || {}; err.textContent = d.data && d.data.fields ? Object.values(d.data.fields).filter(Boolean).join(' · ') : d.message || 'Not sent'; });
      } });
      drawPills();
      sp.open({ title: 'Message', body: [h('div', { class: 'ap-field' }, h('span', { text: 'To' }), pills, count), h('label', { class: 'ap-field' }, h('span', { text: 'Subject' }), subject), h('label', { class: 'ap-field' }, h('span', { text: 'Message' }), body), err],
        foot: [send, A.btn('Cancel', { ghost: true, onClick: () => { panel = ''; msgC = ''; draw(); } })], onClose: () => { panel = ''; msgC = ''; draw(); } });
    }
    // A message's answer in the heads' words (after the ninth critic, Oct 16): the people reached by email,
    // each once, and the addresses only when they differ ("Sent · 4 people · 3 emails"); never "Sent · 0".
    function sentWords(r) {
      const n = r.people != null ? r.people : (r.queued || 0), e = r.emails != null ? r.emails : (r.queued || 0);
      if (n) return 'Sent · ' + K.plural(n, 'person', 'people') + (e && e !== n ? ' · ' + K.plural(e, 'email') : '');
      return r.skipped ? 'Not sent' : 'Nobody by email';
    }
    // "Lois B. · 555-0190" → its name and its phone (the server's call line; no phone, the name alone).
    const callOf = t => { t = String(t || ''); const i = t.indexOf(' · '); return i < 0 ? { name: t, phone: '' } : { name: t.slice(0, i), phone: t.slice(i + 3) }; };
    // Who has no email, after a message: named with their phones to tap, beside the list until it's closed.
    function sentPanel() {
      const x = sent || { said: '', skipped: 0, call: [] };
      sp.open({ title: 'Message', focus: 'head', body: [
        h('p', { class: 'cm-sent' }, x.any ? K.icon('check', 14) : null, h('span', { text: K.facts([x.said, x.skipped ? x.skipped + ' skipped · Already ' + ((D && D.msgs_per_person) || 4) + ' today' : '']) })),
        h('h3', { class: 'ap-label cm-sub', text: 'Call · ' + x.call.length }),
        h('ul', { class: 'cm-plain cm-call', 'aria-label': 'Call' }, x.call.map(c => h('li', { class: 'cm-call__p' }, h('span', { class: 'cm-call__n', text: c.name }), c.phone ? K.phone(c.phone) : null)))
      ], foot: [A.btn('Done', { ghost: true, onClick: () => sp.close() })], onClose: () => { panel = ''; sent = null; draw(); } });
    }

    // The committee's one instruction for every shift, and its reminders (its head or the COA).
    function setupPanel() {
      const c = com(ckey);
      const su = (D && D.setup) || {};
      const ins = h('textarea', { class: 'ap-textarea', rows: '3', maxlength: '200', 'data-autofocus': '', 'aria-describedby': 'cm-ins-n' });
      ins.value = su.instruction || '';
      // A live count toward the 200 (after the third critic, Oct 15).
      const n = h('span', { class: 'ap-help cm-count', id: 'cm-ins-n', 'aria-live': 'polite' });
      const count = () => { n.textContent = ins.value.length + ' of 200'; n.classList.toggle('is-near', ins.value.length >= 180); };
      ins.addEventListener('input', count);
      count();
      const wk = h('input', { type: 'checkbox', class: 'ap-check', checked: su.week !== false }), dy = h('input', { type: 'checkbox', class: 'ap-check', checked: su.day !== false });
      const err = h('p', { class: 'ap-err', role: 'alert' });
      const save = A.btn('Save', { primary: true, write: true, onClick: () => {
        save.disabled = true;
        vol('POST', '/setup', { committee: c.name, instruction: ins.value, week: wk.checked, day: dy.checked }).then(r => {
          D.setup = r; panel = ''; A.toast('Saved · ' + c.name); forget(); draw();
        }).catch(e => { save.disabled = false; const d = e.data || {}; err.textContent = d.data && d.data.fields ? Object.values(d.data.fields).filter(Boolean).join(' · ') : d.message || 'Not saved'; });
      } });
      sp.open({ title: 'For every shift', body: [
        // A neutral example, not another committee's (after the third critic, Oct 15).
        h('label', { class: 'ap-field' }, h('span', { text: 'Instruction' }), ins, h('span', { class: 'ap-help', text: 'Like: Come 10 minutes early to check in · On the volunteer page once, and in every email' }), n),
        h('div', { class: 'ap-field' }, h('span', { text: 'Reminders' }),
          h('label', { class: 'ap-switch' }, wk, h('span', { text: 'A week before the Conference' })),
          h('label', { class: 'ap-switch' }, dy, h('span', { text: 'The day before each shift' })),
          h('span', { class: 'ap-help', text: 'By email, with the shift’s calendar file' })),
        err],
      foot: [save, A.btn('Cancel', { ghost: true, onClick: () => { panel = ''; draw(); } })], onClose: () => { panel = ''; draw(); } });
    }

    /* ---------------------------------------------------------------- Print (a committee's clean sheet) */

    // The browser's own Print (⌘P, or its menu) prints the same clean sheet as More › Print, never the
    // screen (after the seventh critic, Oct 15).
    const ownPrint = () => { if (alive && ckey && D && X && comShifts().length && !document.documentElement.classList.contains('cm-printing')) printList(false); };
    window.addEventListener('beforeprint', ownPrint);
    function printList(dialog) {
      const c = com(ckey);
      const shifts = comShifts();
      // "Since you printed" moves on once the print dialog closes (a cancel can't be told from a print),
      // and what was before it stays under Earlier (after the fourth critic, Oct 15).
      const seen = () => { window.removeEventListener('afterprint', seen); vol('POST', '/printed', { committee: c.name, what: 'seen' }).then(() => { if (alive && !panel && !p.id) refresh(); }).catch(() => {}); };
      window.addEventListener('afterprint', seen);
      const byDay = {};
      shifts.forEach(s => { (byDay[dayKey(s)] = byDay[dayKey(s)] || []).push(s); });
      // Compact: what every shift shares said once at the top; a column only for what differs.
      const sh = sharedOf(shifts);
      const cols = [sh.role == null ? ['Shift', s => s.role] : null, ['When', s => when(s)], sh.place == null ? ['Place', s => s.place] : null].filter(Boolean);
      // Every day's table has the same columns at the same widths; "Fri night · 12–3 AM" needs a wider When.
      const W = { Shift: 22, When: shifts.some(s => s.night) ? 21 : 17, Place: 19 }, fixed = cols.reduce((k, x) => k + W[x[0]], 0);
      // Each name whole on one line (after the ninth critic, Oct 16): Name as wide as the longest name in the
      // print's own type, Phone as its longest number, Here a box; measured against the letter page.
      const PAGE = 7.6 * 96, PAD = 16;
      const meas = h('span', { 'aria-hidden': 'true', style: { position: 'absolute', left: '-9999px', top: '0', visibility: 'hidden', whiteSpace: 'nowrap', font: '10.5pt/1.35 -apple-system, "Segoe UI", Arial, sans-serif' } });
      document.body.appendChild(meas);
      const widest = list => list.reduce((m, t) => { meas.textContent = t; return Math.max(m, meas.getBoundingClientRect().width); }, 0);
      const everyone = shifts.reduce((a, s) => a.concat(s.people), []);
      const pct = (px, lo, hi) => Math.min(hi, Math.max(lo, Math.ceil(1000 * (px + PAD) / PAGE) / 10));
      const wName = pct(widest(everyone.map(pp => pp.name).concat(['No limit', '000 open'])), 14, 32), wPhone = pct(widest(everyone.map(pp => pp.phone || '')), 10, 18), wHere = 7.5;
      const rest = 100 - wName - wPhone - wHere;
      const colgroup = () => h('colgroup', null, cols.map(x => h('col', { style: { width: (Math.floor(10 * rest * W[x[0]] / fixed) / 10) + '%' } })).concat([h('col', { style: { width: wName + '%' } }), h('col', { style: { width: wPhone + '%' } }), h('col', { style: { width: wHere + '%' } })]));
      meas.remove();
      // A shift's rows stay together on one page, and the day's heading repeats on a page it runs onto.
      const heads = cols.map(x => x[0]).concat(['Name', 'Phone', 'Here']);
      // After the people: a line per open place, up to 8; more open than that, "12 open" said once and three
      // lines to write names in; a shift with no limit, "No limit" and the same three lines.
      const OPEN_LINES = 8, WRITE_LINES = 3;
      const linesOf = s => {
        const open = s.unlimited ? 0 : Math.max(0, s.needed - s.people.length);
        const ls = s.people.map(pp => ['p', pp]);
        if (s.unlimited || open > OPEN_LINES) {
          ls.push(['note', s.unlimited ? 'No limit' : open + ' open']);
          for (let i = 0; i < WRITE_LINES; i++) ls.push(['write']);
        } else for (let i = 0; i < open; i++) ls.push(['open']);
        return ls.length ? ls : [['open']];
      };
      K.print({ dialog: dialog !== false, title: c.name + ' · Shifts', who: c.name + ' only', build: () => h('div', null, sh.line ? h('p', { class: 'cm-print__shared', text: sh.line }) : null, Object.keys(byDay).sort().map(d => h('section', { class: 'cm-psec' },
        h('table', { class: 'cm-ptable' }, colgroup(), h('thead', null, h('tr', { class: 'cm-pday' }, h('th', { colspan: String(heads.length) }, h('h2', { text: dayHead(d, byDay[d]) }))), h('tr', null, heads.map(x => h('th', { text: x })))),
          byDay[d].map(s => h('tbody', { class: 'cm-pshift' }, linesOf(s).map((ln, k) => {
            const pp = ln[0] === 'p' ? ln[1] : null;
            return h('tr', { class: ln[0] === 'write' ? 'cm-pwrite' : null }, cols.map(x => h('td', { text: k ? '' : x[1](s) })),
              h('td', { class: 'cm-pname' + (ln[0] === 'note' ? ' cm-pnote' : ''), text: pp ? pp.name : ln[0] === 'open' ? 'Open' : ln[0] === 'note' ? ln[1] : '' }),
              h('td', { text: pp ? (pp.withheld ? '' : (pp.phone || '') + (pp.via ? ' · via ' + pp.via : '')) : '' }),
              h('td', { class: ln[0] === 'note' ? null : 'cm-tick' }));
          }))))))) });
      vol('POST', '/printed', { committee: c.name, what: 'done' }).catch(() => {});
    }

    // An act named in the address (Home's "Publish sign-ups", the task's Where) opens once.
    if (p.at === 'publish') panel = 'publish';
    else if (p.at === 'changes') panel = 'changes';
    else if (p.at === 'add') panel = 'add';
    K.loading(ctx);
    load();
    const t = setInterval(() => { if (!document.hidden && !panel && !p.id && X) refresh(); }, 60000);
    return () => { alive = false; clearInterval(t); window.removeEventListener('beforeprint', ownPrint); if (headRO) headRO.disconnect(); };
  }

  A.screen({ id: 'shifts', title: 'Shifts', icon: 'members', section: 'own', who: ['coa', 'committee'], render: screen });
})();
