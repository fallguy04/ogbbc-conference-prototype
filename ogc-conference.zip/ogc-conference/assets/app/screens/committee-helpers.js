/*
 * Helpers (app-committees, Oct 11): who's signed up for a committee's volunteer shifts, for the
 * committee itself (the volunteer page's old ?view=lead, moved into the app). Every committee with
 * shifts has it in its sidebar; the COA opens any committee's.
 *
 *   The list     the committee's shifts by day: what, when, where, how full, and who (names); a shift
 *                opens beside the list with each person's phone, Move, Remove (Undo), Here during the
 *                week, the waiting list (Offer), and Add person (by phone, on paper, at the desk).
 *   Message      an email through the site to everyone on the committee's shifts, a day's, or one
 *                shift's (replies to you; no address shown to anyone). Counted in people, each once
 *                ("Sent · 4 people · 3 emails"); who has no email stays beside the list to call, by name
 *                with their phones, until it's closed.
 *   Print        a day at a time, one line a person, with a Here box; past 8 open places or no limit,
 *                said once with three lines to write in. Download: the list for Excel.
 * The server decides who sees what (module-app-committees.php): a committee's people see their own
 * committee's shifts only; the COA every committee's.
 */
(function () {
  'use strict';
  const A = window.OGC_APP, h = A.h, K = window.OGC_CK;
  const key = n => String(n || '').toLowerCase().trim().replace(/\s+/g, ' ').replace(/^the\s+|\s+committee$/g, '').trim();
  const hm = m => { m = ((m % 1440) + 1440) % 1440; const hh = Math.floor(m / 60), mm = m % 60; return (hh % 12 || 12) + (mm ? ':' + String(mm).padStart(2, '0') : '') + ' ' + (hh >= 12 ? 'PM' : 'AM'); };
  const span = s => s.allweek ? 'All week' : hm(s.start).replace(/ (AM|PM)$/, hm(s.start).slice(-2) === hm(s.end).slice(-2) ? '' : ' $1') + '–' + hm(s.end);
  // An All week post (a dorm host) is listed before the days, as the volunteer page lists it.
  // A night shift is listed under its night, by the volunteers' one rule (the server's ogc_vol_eve_date:
  // a shift from midnight to 5 AM is the evening before's; after the eighth critic, Oct 16, Helpers, its
  // printout, Move and Message filed Friday night's 12–3 AM under Saturday): `eve`, the evening's date.
  const dayKey = s => s.allweek ? '0000-week' : s.eve || s.date;
  // A shift's time in the heads' words: "Fri night · 12–3 AM" for a night shift, else "6–9 AM".
  const when = s => (s.night ? s.night + ' · ' : '') + span(s);
  // With its day, wherever the day isn't the heading above it: "Fri night · 12–3 AM", "Sat May 29 · 6–9 AM".
  const dayWhen = s => s.allweek ? 'All week' : s.night ? when(s) : K.day(s.date) + ' · ' + span(s);
  const dayHead = (d, list) => d === '0000-week' ? 'All week · ' + K.day(list[0].date) + ' – ' + K.day(list[0].last_date || list[0].date) : K.day(d);
  // What every one of a committee's shifts shares: a value when all agree (null when they differ), and
  // the line that says them once ("Golf cart driver · Barnes Student Center · 21 or older").
  function sharedOf(list) {
    const one = f => { const v = list.map(x => String(f(x) || '')); return v.length && v.every(x => x === v[0]) ? v[0] : null; };
    const o = { role: one(x => x.role), place: one(x => x.place), rule: one(x => x.rule) };
    o.line = K.facts([o.role, o.place, o.rule]);
    return o;
  }
  // A row's line under its title: only what isn't said above the list.
  // Drawn a fact at a time: the time whole on its line ("10:45 PM–12:15 AM" never splits), a place's or a
  // rule's words free to wrap (after the eighth critic, Oct 16: 2026's long names pushed the phone's list
  // wider than the screen).
  const rowSubEl = (s, sh) => {
    const fs = [sh.role != null ? null : [when(s), true], sh.place != null || !s.place ? null : [s.place], sh.rule != null || !s.rule ? null : [s.rule]].filter(Boolean);
    return fs.length ? h('span', { class: 'cm-sub2' }, ...fs.reduce((a, f, i) => a.concat(i ? [' · '] : [], [f[1] ? h('span', { class: 'cm-nw', text: f[0] }) : f[0]]), [])) : null;
  };
  // What happened to a place, after the person's name (the head sees full names here).
  const LEFT_ACT = { left: ' left', removed: ' removed', notme: ' removed · Not them', unconfirmed: ' · Not confirmed', moved_out: ' moved', swap: ' swapped' };
  // With the shift after it ("Mark Kline left Sat 3–7 PM · Oct 14"): the verb, and what's true besides.
  const LEFT_SAY = { left: ['left', ''], removed: ['removed from', ''], notme: ['removed from', 'Not them'], unconfirmed: ['off', 'Not confirmed'], moved_out: ['moved from', ''], swap: ['swapped out of', ''] };
  // When someone left, venue time: "Oct 16 · 3:12 PM" (the server's on_at; the date alone from an older one).
  const leftAt = l => l.on_at || l.on || '';
  // The committee's reminders, said plainly.
  const remindWords = su => [su.week ? 'A week before' : '', su.day ? 'The day before' : ''].filter(Boolean).join(' · ') || 'None';

  function screen(ctx) {
    const p = ctx.params, v = ctx.boot.viewer;
    let D = null, sp = null, panel = '', alive = true, committee = '', msgTo = '', sent = null, headRO = null;
    const vol = (method, path, body) => A.api(method, '/vol/' + p.year + '/lead' + path, body);
    const ro = () => !!A.readonly || (D && D.gone);
    // One household's places only (its Linked "Shifts · 3", Round 3: f=household:<R>): the server keeps
    // the shifts inside the committees this viewer may lead that hold a place with its registration number.
    const hf = (A.fParse(p.f).household || [])[0] || '';
    const hq = hf ? 'household=' + encodeURIComponent(hf) : '';
    const getOf = c => vol('GET', '?' + [c ? 'committee=' + encodeURIComponent(c) : '', hq].filter(Boolean).join('&'));

    // Which committee: the address (?c=), else the viewer's own (the switcher's), else the first.
    function pickCommittee(list) {
      const want = p.c || (v.coa ? '' : A.team());
      // A household's places: a committee that holds some of them (the one asked for, else the first).
      if (hf) { const mine = list.filter(c => c.hh > 0); return ((mine.find(c => key(c.name) === want) || mine[0]) || {}).name || ''; }
      const hit = list.find(c => key(c.name) === want);
      // A committee named in the address that has no shifts says so (Round 2: every committee has Shifts);
      // never another committee's shifts in its place.
      return hit ? hit.name : p.c ? '' : (list[0] || {}).name || '';
    }
    function load() {
      return getOf('').then(first => {
        // Only committees that have shifts (committees.csv also lists those without).
        const list = (first.committees || []).filter(c => c.shifts > 0);
        first.committees = list;
        committee = pickCommittee(list);
        // The address names the committee shown, so Reload, a copied link and the crumb agree.
        if (committee && key(committee) !== p.c) A.setParams({ c: key(committee) });
        else if (!committee) A.setParams({});
        if (!committee) { D = Object.assign(first, { shifts: [] }); return draw(); }
        return getOf(committee).then(d => { D = d; if (alive) draw(); });
      }).catch(err => {
        if (!alive) return;
        // A committee with no shifts may lead none: that's "No shifts", not a refusal.
        if (err && err.status === 403 && !v.coa) { D = { committees: [], shifts: [] }; committee = ''; return draw(); }
        K.failed(ctx, err);
      });
    }
    const refresh = () => getOf(committee).then(d => { D = d; if (alive) draw(); }).catch(A.fail);
    const find = id => D.shifts.find(s => s.id === id);

    function draw() {
      if (!sp) { A.clear(ctx.body); sp = ctx.split(); }
      A.clear(sp.main);
      const coms = D.committees || [];
      // The household filter's pill ("Household · Hoovers ×"): × shows the committee's every shift again.
      const hpill = hf ? A.pills([{ field: 'household', label: 'Household', values: [{ v: hf, words: (D.household && D.household.words) || hf }] }]) : null;
      if (!committee) {
        ctx.head('Shifts', '', []);
        if (hpill) sp.main.appendChild(h('div', { class: 'cm-toolbar' }, hpill));
        sp.main.appendChild(A.empty({ title: 'No shifts', line: hf ? 'None of this household’s' : 'The year’s shifts are set by the COA', inset: true, action: hf ? A.link({ f: '' }, 'Every shift', 'ap-btn') : null }));
        return;
      }
      const shifts = D.shifts || [];
      const needed = shifts.reduce((k, s) => k + (s.unlimited ? 0 : s.needed), 0), filled = shifts.reduce((k, s) => k + Math.min(s.n, s.unlimited ? s.n : s.needed), 0);
      const open = shifts.filter(s => !s.unlimited && s.n < s.needed).length;
      // With a household's filter, only the committees holding its places, each with how many.
      const chips = hf ? coms.filter(c => c.hh > 0) : coms;
      const many = chips.length > 1 || (!hf && coms.length > 1);
      // The shifts themselves (times, places, how many) are kept in the shift editor until it moves in.
      const editIn = what => { location.href = (OGC_WP.base || '/annual-conference/') + 'admin/?year=' + p.year + '&edit=' + encodeURIComponent(what) + '&return=' + encodeURIComponent(location.pathname + location.search); };
      // The committee is said once: by the crumb ("Lodging / Shifts") when there is one, else in the title.
      ctx.head(many && !A.foreignOf('helpers') ? 'Shifts · ' + committee : 'Shifts', D.gone ? 'Names cleared · Counts only' : hf ? K.plural(shifts.length, 'shift') : K.facts([needed ? (filled ? filled + ' of ' + needed + ' places filled' : K.plural(needed, 'place') + ' to fill') : filled ? K.plural(filled, 'person', 'people') : '', open ? K.plural(open, 'shift') + ' open' : needed ? 'All filled' : '', D.posted ? '' : 'Not public']),
        [ro() ? null : A.btn('Message', { primary: !panel, icon: 'mail', write: true, disabled: !shifts.some(s => s.people.length), onClick: () => openPanel('msg') }),
          K.more('More', [ro() ? null : { label: 'Edit shifts', run: () => editIn('shifts:' + committee) }, { label: 'Print', run: printList }, { label: 'Download', run: () => K.fetchFile('ogc/v1/vol/' + p.year + '/lead/export?committee=' + encodeURIComponent(committee) + (p.as ? '&as=' + encodeURIComponent(p.as) : ''), key(committee).replace(/[^a-z0-9]+/g, '-') + '-volunteers-' + p.year + '.csv').then(() => vol('POST', '/printed', { committee, what: 'seen' }).then(() => refresh()).catch(() => {})).catch(() => A.toast('Not downloaded')) }], { ghost: true })].filter(Boolean));
      stickUnder();
      if (many || hpill) sp.main.appendChild(h('div', { class: 'cm-toolbar' }, many ? A.views(chips.map(c => ({ id: c.name, label: c.name, n: hf ? c.hh : null })), committee, name => { A.go({ c: key(name), id: '', f: p.f || '' }, { replace: true }); }) : null, hpill));
      // Who left lately, printed or not, each with the shift's day and time ("Mark Kline left · Sat, May
      // 29 · 3–7 PM"; the job too when the committee has several): since this person last printed or
      // downloaded, else the last seven days (after the third critic, Oct 15). Newest first.
      // Each person and shift once (the newest), and not someone who is back on that shift now.
      const seen = new Set(), xs = (D.left || []).slice().reverse().filter(l => {
        const k = l.act + '|' + l.shift + '|' + String(l.name).toLowerCase(), s = find(l.shift);
        if (seen.has(k) || (s && s.people.some(pp => String(pp.name).toLowerCase() === String(l.name).toLowerCase()))) return false;
        seen.add(k); return true;
      });
      // Who, which shift, and when they left ("Mark Kline left Sat 3–7 PM · Oct 14"; the job too when the
      // committee has several). A print or a download moves what's above the fold to "Earlier", never out
      // of sight (after the fourth critic, Oct 15: a cancelled print dialog emptied the list for good).
      if (xs.length) {
        const roles = new Set(shifts.map(s => s.role));
        const said = l => {
          const v = LEFT_SAY[l.act] || LEFT_SAY.left;
          if (!l.shift_short) return K.facts([l.name + (LEFT_ACT[l.act] || ' left'), l.when, leftAt(l)]);
          return K.facts([l.name + ' ' + v[0] + ' ' + (roles.size > 1 && l.role ? l.role + ' · ' : '') + l.shift_short, v[1], leftAt(l)]);
        };
        const fresh = xs.filter(l => l.group !== 'earlier'), older = xs.filter(l => l.group === 'earlier');
        const list = ls => h('ul', { class: 'cm-left__l' }, ls.map(l => h('li', { text: said(l) })));
        const fold = (label, ls) => h('details', { class: 'cm-left__more' }, h('summary', { text: label }), list(ls));
        sp.main.appendChild(h('div', { class: 'cm-pad cm-since cm-left' },
          fresh.length ? h('span', { class: 'ap-label', text: D.since ? 'Since you printed' : 'Last 7 days' }) : h('span', { class: 'ap-label', text: 'Who left' }),
          fresh.length ? list(fresh.slice(0, 6)) : null,
          fresh.length > 6 ? fold((fresh.length - 6) + ' more', fresh.slice(6)) : null,
          older.length ? fold('Earlier · ' + older.length, older) : null));
      }
      // For every shift: the committee's one instruction (the volunteer page says it once, the emails
      // too) and which reminders go. Its head or the COA changes them.
      const su = D.setup;
      // Change (or Add instruction) is a plain link at the end of its line, never a borderless button
      // floating mid-line (after the second critic, Oct 15).
      const setupLink = su && su.can && !ro() ? h('button', { type: 'button', class: 'ap-link cm-setup__go', on: { click: () => openPanel('setup') } }, su.instruction ? 'Change' : 'Add instruction') : null;
      if (su) sp.main.appendChild(h('div', { class: 'cm-pad cm-setup' },
        su.instruction ? h('p', { class: 'cm-setup__l' }, h('span', { class: 'ap-label', text: 'For every shift' }), h('span', { class: 'cm-setup__t', text: su.instruction })) : null,
        h('p', { class: 'cm-setup__l' }, h('span', { class: 'ap-label', text: 'Reminders' }), h('span', { class: 'cm-setup__t', text: remindWords(su) }), setupLink)));
      if (!shifts.length) { sp.main.appendChild(A.empty({ title: 'No shifts for ' + committee, inset: true })); return; }
      // What every shift shares (the job, the place, the rule) is said once above the list, as the
      // public page says it; each row says only what differs (after the critic, Oct 15).
      const sh = sharedOf(shifts);
      if (sh.line) sp.main.appendChild(h('p', { class: 'cm-pad cm-shared', text: sh.line }));
      const byDay = {};
      shifts.forEach(s => { (byDay[dayKey(s)] = byDay[dayKey(s)] || []).push(s); });
      const rows = [];
      Object.keys(byDay).sort().forEach(d => {
        rows.push(h('tr', { class: 'cm-group' }, h('td', { colspan: '4', text: dayHead(d, byDay[d]) + ' · ' + K.plural(byDay[d].length, 'shift') })));
        byDay[d].forEach(s => {
          const full = s.unlimited ? null : s.n / Math.max(1, s.needed);
          // On a phone (no Who column) the names are a full-width line under the row, each with its
          // phone to tap (after the critic, Oct 15).
          // The whole row opens the shift (its time is the button, for the keyboard), with a chevron on a
          // phone; a phone number in it still calls (after the fourth critic, Oct 15: only the time, which
          // looked like plain text, opened it).
          const openIt = () => { panel = ''; p.id = s.id; A.setParams({ id: s.id }); draw(); };
          const rowTap = e => { if (e.target.closest('a, button, input, label, summary')) return; openIt(); };
          const whoM = D.gone || !s.people.length ? null : h('tr', { class: 'cm-who-tr cm-tap' + (p.id === s.id ? ' is-open' : ''), on: { click: rowTap } }, h('td', { colspan: '4' }, h('ul', { class: 'cm-who-m', 'aria-label': 'Who' }, s.people.map(pp => h('li', { class: 'cm-who-m__p' }, h('span', { class: 'cm-who-m__n', text: pp.name + (pp.minor ? ' · Under 18' : '') + (pp.confirmed === false ? ' · Unconfirmed' : '') }), K.phone(pp.phone), pp.via ? h('span', { class: 'cm-sub2', text: 'via ' + pp.via }) : null)))));
          rows.push(h('tr', { class: 'cm-tap' + (p.id === s.id ? ' is-open' : '') + (whoM ? ' has-who' : ''), on: { click: rowTap } },
            h('td', null, h('button', { type: 'button', class: 'cm-rowbtn', 'aria-label': (sh.role != null ? '' : s.role + ', ') + (s.night ? s.day_words : K.day(s.date)) + ' ' + span(s), on: { click: openIt } }, h('span', { class: 'cm-title' + (sh.role != null ? '' : ' cm-title--job'), text: sh.role != null ? when(s) : s.role })), rowSubEl(s, sh)),
            h('td', { class: 'is-num cm-filled' }, h('span', { class: 'ap-bar', 'aria-hidden': 'true' }, h('i', { style: { width: Math.round(100 * Math.min(1, full == null ? 1 : full)) + '%' } })), h('span', { class: 'cm-filled__n', text: s.unlimited ? (s.n ? String(s.n) : 'None yet') : s.n ? s.n + ' of ' + s.needed : 'None yet' })),
            // On a laptop each person with their phone in the row, as on a phone (after the sixth critic,
            // Oct 15: the names only, the phones a click away).
            h('td', { class: 'is-wide' }, D.gone ? '' : h('ul', { class: 'cm-who-l', 'aria-label': 'Who' }, s.people.map(pp => h('li', { class: 'cm-who-l__p' }, h('span', { class: 'cm-who-l__n', text: pp.name + (pp.minor ? ' (under 18)' : '') + (pp.confirmed === false ? ' · Unconfirmed' : '') }), pp.phone ? K.phone(pp.phone) : null, pp.via ? h('span', { class: 'cm-sub2', text: 'via ' + pp.via }) : null))), s.waiting.length ? h('span', { class: 'cm-sub2', text: s.waiting.length + ' waiting' }) : null),
            h('td', { class: 'is-num cm-endcell' }, !s.unlimited && s.n < s.needed ? h('span', { class: 'cm-chip cm-chip--tan', text: (s.needed - s.n) + ' open' }) : s.over ? h('span', { class: 'cm-chip', text: s.over + ' over' }) : !s.unlimited ? h('span', { class: 'cm-chip', text: 'Full' }) : null, h('span', { class: 'cm-chev', 'aria-hidden': 'true' }, A.icon('chev', 16)))));
          if (whoM) rows.push(whoM);
        });
      });
      sp.main.appendChild(h('div', { class: 'cm-scroll' }, h('table', { class: 'cm-table cm-helpers' }, h('thead', null, h('tr', null, h('th', { text: 'Shift' }), h('th', { class: 'is-num', text: 'Filled' }), h('th', { class: 'is-wide', text: 'Who' }), h('th', null, h('span', { class: 'ap-sr', text: 'Open' })))), h('tbody', null, rows))));
      if (panel === 'msg') return msgPanel();
      if (panel === 'sent') return sentPanel();
      if (panel === 'setup') return setupPanel();
      const cur = p.id && find(p.id);
      if (cur) shiftPanel(cur); else sp.close(true);
    }
    // A day's heading stays at the top while its shifts scroll, just under the app's title row (after the
    // ninth critic, Oct 16: on a phone's long list the day went out of sight). The row's height is measured,
    // as it's drawn again and when it wraps (on a phone it's the title, the counts and the buttons).
    function stickUnder() {
      const hd = document.querySelector('.ap-head');
      if (!hd || !sp) return;
      const set = el => { if (sp && el && el.isConnected) sp.el.style.setProperty('--cm-stick', Math.round(el.getBoundingClientRect().height) + 'px'); };
      set(hd);
      if (!window.ResizeObserver) return;
      if (!headRO) headRO = new ResizeObserver(es => es.forEach(e => set(e.target)));
      headRO.disconnect();
      headRO.observe(hd);
    }
    function openPanel(k, to) { panel = k; msgTo = to || ''; p.id = ''; A.setParams({ id: '' }); draw(); }

    // Every leave the year's log keeps for one shift, newest first, each line once.
    function shiftLeft(s) {
      const seen = new Set();
      return (D.left || []).filter(l => l.shift === s.id).slice().reverse().filter(l => { const k = l.act + '|' + String(l.name).toLowerCase() + '|' + leftAt(l); if (seen.has(k)) return false; seen.add(k); return true; });
    }
    function shiftPanel(s) {
      const others = D.shifts.filter(x => x.id !== s.id);
      const during = D.begun;
      const person = pp => {
        const here = h('input', { type: 'checkbox', class: 'ap-check', checked: pp.here, disabled: ro(), 'aria-label': 'Here: ' + pp.name });
        here.addEventListener('change', () => vol('POST', '/here', { committee, id: pp.rid, here: here.checked }).then(() => { pp.here = here.checked; A.toast(pp.name + (here.checked ? ' · Here' : ' · Not here')); }).catch(e => { here.checked = !here.checked; A.fail(e); }));
        const moveTo = h('div', { hidden: true }, h('p', { class: 'ap-label cm-sub', text: 'Move to' }), h('div', { class: 'ap-pills' }, others.slice(0, 30).map(o => h('button', { type: 'button', class: 'ap-pill', on: { click: () => vol('POST', '/move', { committee, id: pp.rid, to: o.id }).then(() => { A.toast('Moved · ' + pp.name + ' · ' + o.role + ' · ' + dayWhen(o)); refresh(); }).catch(e => A.toast((e.data && e.data.message) || 'Not moved')) } }, o.role + ' · ' + dayWhen(o)))));
        return h('li', { class: 'cm-person' },
          h('div', { class: 'cm-person__main' }, h('b', { text: pp.name }), h('span', { class: 'cm-sub2 cm-person__line' }, K.phone(pp.phone), pp.via ? ' · via ' + pp.via : '', pp.phone && pp.email ? ' · ' : '', pp.email ? h('span', { class: 'cm-email', text: pp.email }) : '', pp.minor ? ' · Under 18' : '', pp.by === 'head' ? ' · Added by a head' : '', pp.over ? ' · Past the count' : '', pp.by === 'helper' && pp.helper && !pp.via ? ' · Signed up by ' + pp.helper : '', pp.confirmed === false ? ' · Unconfirmed' : '', pp.hidden ? ' · Name hidden' : '', pp.check ? ' · Also on ' + pp.check : ''), pp.note ? h('span', { class: 'cm-sub2', text: pp.note }) : null),
          ro() ? null : h('div', { class: 'ap-row' }, during ? h('label', { class: 'ap-switch' }, here, 'Here') : null,
            others.length ? A.btn('Move', { ghost: true, onClick: () => { moveTo.hidden = !moveTo.hidden; } }) : null,
            A.btn('Remove', { ghost: true, danger: true, write: true, onClick: () => vol('POST', '/remove', { committee, id: pp.rid }).then(() => {
              A.toast('Removed · ' + pp.name, { undo: () => vol('POST', '/restore', { committee, id: pp.rid }).then(() => { A.toast('Restored · ' + pp.name); refresh(); }).catch(e => A.toast((e.data && e.data.message) || 'Can’t undo')) });
              refresh();
            }).catch(A.fail) })), moveTo);
      };
      const name = h('input', { class: 'ap-input', autocomplete: 'off', maxlength: '80' }), phone = h('input', { class: 'ap-input', type: 'tel', autocomplete: 'off' }), email = h('input', { class: 'ap-input', type: 'email', autocomplete: 'off' });
      const err = h('p', { class: 'ap-err', role: 'alert' });
      const add = () => vol('POST', '/add', { committee, shift: s.id, name: name.value, phone: phone.value, email: email.value }).then(() => { A.toast('Added · ' + name.value.trim() + ' · ' + s.role + ' · ' + dayWhen(s)); refresh(); })
        .catch(e => { const d = e.data || {}; err.textContent = d.code === 'busy' || (d.data && d.data.busy) ? 'Busy · On ' + ((d.data && d.data.busy && d.data.busy.role) || 'another shift') + ' then' : d.data && d.data.fields ? Object.values(d.data.fields).filter(Boolean).join(' · ') : d.message || 'Not added'; });
      sp.open({
        title: s.role,
        body: [
          // Each fact whole on its line ("1 of 4" never splits; after the sixth critic, Oct 15).
          // A night shift by its night: "Fri night, May 28 · 12–3 AM" (after the eighth critic, Oct 16).
          // Each fact whole, the line free to wrap between them (the dot ends a line, never starts one).
          h('p', { class: 'cm-detail__m' }, ...[s.allweek ? 'All week' : s.night ? s.day_words : K.day(s.date), span(s), s.place, s.unlimited ? K.plural(s.n, 'person', 'people') : s.n + ' of ' + s.needed].filter(Boolean).reduce((a, t, i) => a.concat(i ? [' · '] : [], [h('span', { class: 'cm-nw', text: t })]), [])),
          s.rule ? h('p', { class: 'ap-quiet', text: s.rule_words || s.rule }) : null,
          // Message only this shift's people (Transportation sent one a shift on May 28, 2026).
          !ro() && s.people.length ? h('p', null, A.btn('Message this shift', { icon: 'mail', ghost: true, write: true, onClick: () => openPanel('msg', 'shift:' + s.id) })) : null,
          s.people.length ? h('ul', { class: 'cm-plain cm-people2' }, s.people.map(person)) : h('p', { class: 'ap-quiet', text: 'No one yet' }),
          // This shift's own history (after the seventh critic, Oct 15: who left was only in "Last 7 days"):
          // a line each, newest first, "Lena Shirk left · Oct 16" ("removed", "moved" for a head's).
          // With the time too, venue time: "Lena Shirk left · Oct 16 · 3:12 PM" (after the ninth critic, Oct 16);
          // the six newest, the rest behind "N more" (each leave by the minute, so a long history stays one fold).
          (() => {
            const ls = shiftLeft(s), li = l => h('li', { text: K.facts([l.name + (LEFT_ACT[l.act] || ' left'), leftAt(l)]) });
            return ls.length ? [h('h3', { class: 'ap-label cm-sub', text: 'Left · ' + ls.length }), h('ul', { class: 'cm-plain cm-left__l cm-left--shift' }, ls.slice(0, 6).map(li)),
              ls.length > 6 ? h('details', { class: 'cm-left__more' }, h('summary', { text: (ls.length - 6) + ' more' }), h('ul', { class: 'cm-plain cm-left__l cm-left--shift' }, ls.slice(6).map(li))) : null] : null;
          })(),
          s.waiting.length ? [h('h3', { class: 'ap-label cm-sub', text: 'Waiting · ' + s.waiting.length }), h('ul', { class: 'cm-plain' }, s.waiting.map(w => h('li', { class: 'ap-row' }, h('span', { style: { flex: '1' } }, h('b', { text: w.name }), ' ', K.phone(w.phone)), ro() ? null : A.btn('Offer', { write: true, title: 'Emails them a one-tap Join', onClick: () => vol('POST', '/offer', { committee, id: w.rid }).then(() => A.toast('Offered · ' + w.name)).catch(A.fail) }))))] : null,
          ro() ? null : h('details', { class: 'cm-fold', open: !s.people.length }, h('summary', { text: 'Add person' }),
            h('label', { class: 'ap-field' }, h('span', { text: 'Name' }), name),
            h('label', { class: 'ap-field' }, h('span', { text: 'Phone' }), phone),
            h('label', { class: 'ap-field' }, h('span', { text: 'Email' }), email, h('span', { class: 'ap-help', text: 'Optional · They get a confirmation' })),
            err, A.btn('Add', { primary: true, write: true, onClick: add }))
        ],
        onClose: () => { p.id = ''; A.setParams({ id: '' }); draw(); }
      });
    }

    function msgPanel() {
      // A day is the day and its night (Message › Fri reaches Friday's 12–3 AM too; the server's own rule).
      const days = Array.from(new Set(D.shifts.map(s => s.eve || s.date))).sort();
      let to = msgTo || 'all';
      const one = msgTo ? find(msgTo.slice(6)) : null;
      const subject = h('input', { class: 'ap-input', maxlength: '140', 'data-autofocus': '' }), body = h('textarea', { class: 'ap-textarea', rows: '6' });
      const err = h('p', { class: 'ap-err', role: 'alert' }), count = h('p', { class: 'ap-quiet cm-msg__n' });
      // Who it reaches, as the server counts (after the ninth critic, Oct 16: a couple under one email was
      // one): each person with an email once by their name under it, and each without one to call.
      const who = () => {
        const people = new Set(), calls = new Set();
        D.shifts.filter(s => to === 'all' || 'day:' + (s.eve || s.date) === to || 'shift:' + s.id === to).forEach(s => s.people.forEach(pp => {
          const nm = String(pp.name || '').trim().replace(/\s+/g, ' ').toLowerCase();
          if (pp.email) people.add(String(pp.email).toLowerCase() + '|' + nm); else calls.add(nm + '|' + String(pp.phone || '').replace(/\D+/g, ''));
        }));
        return { people: people.size, call: calls.size };
      };
      const pills = h('div');
      let send = null;
      const drawPills = () => {
        A.clear(pills).appendChild(K.pills([['all', 'Everyone']].concat(days.map(d => ['day:' + d, K.day(d)])).concat(one ? [['shift:' + one.id, one.role + ' · ' + dayWhen(one)]] : []), to, x => { to = x; drawPills(); }, 'To'));
        const w = who();
        count.textContent = K.facts([w.people ? K.plural(w.people, 'person', 'people') : w.call ? 'Nobody by email' : 'No one yet', w.call ? w.call + ' to call' : '', D.me_name || D.me ? 'Replies to ' + (D.me_name || D.me) : '', D.msgs_left != null ? (D.msgs_left ? D.msgs_left + ' left today' : 'None left today') : '']);
        // Nobody on what's chosen, or the day's messages used: nothing to send (never "0 left").
        if (send) send.disabled = (!w.people && !w.call) || D.msgs_left === 0;
      };
      send = A.btn('Send', { primary: true, icon: 'mail', write: true, onClick: () => {
        send.disabled = true;
        vol('POST', '/message', { committee, to: to === 'all' ? '' : to, subject: subject.value, body: body.value }).then(r => {
          r = r || {};
          const call = (r.call || []).map(callOf);
          // Who to call stays on screen, beside the list, until it's closed (after the ninth critic, Oct 16).
          sent = { said: sentWords(r), any: (r.people != null ? r.people : r.queued) > 0, skipped: r.skipped || 0, call };
          panel = call.length ? 'sent' : '';
          draw();
          A.toast(K.facts([sent.said, sent.skipped ? sent.skipped + ' skipped · Already ' + (D.msgs_per_person || 4) + ' today' : '', call.length ? (call.length > 2 ? 'Call ' + call.length + ' people' : 'Call ' + call.map(c => c.name).join(' and ')) : '']));
          refresh();
        }).catch(e => { send.disabled = false; const d = e.data || {}; err.textContent = d.data && d.data.fields ? Object.values(d.data.fields).filter(Boolean).join(' · ') : d.message || 'Not sent'; });
      } });
      drawPills();
      sp.open({ title: 'Message', body: [h('div', { class: 'ap-field' }, h('span', { text: 'To' }), pills, count), h('label', { class: 'ap-field' }, h('span', { text: 'Subject' }), subject), h('label', { class: 'ap-field' }, h('span', { text: 'Message' }), body), err],
        foot: [send, A.btn('Cancel', { ghost: true, onClick: () => { panel = ''; draw(); } })], onClose: () => { panel = ''; draw(); } });
    }

    // A message's answer in the heads' words (after the ninth critic, Oct 16): the people reached by email,
    // each once, and the addresses only when they differ ("Sent · 4 people · 3 emails"); never "Sent · 0".
    function sentWords(r) {
      const p = r.people != null ? r.people : (r.queued || 0), e = r.emails != null ? r.emails : (r.queued || 0);
      if (p) return 'Sent · ' + K.plural(p, 'person', 'people') + (e && e !== p ? ' · ' + K.plural(e, 'email') : '');
      return r.skipped ? 'Not sent' : 'Nobody by email';
    }
    // "Lois B. · 555-0190" → its name and its phone (the server's call line; no phone, the name alone).
    const callOf = t => { t = String(t || ''); const i = t.indexOf(' · '); return i < 0 ? { name: t, phone: '' } : { name: t.slice(0, i), phone: t.slice(i + 3) }; };
    // Who has no email, after a message: named with their phones to tap, beside the list until it's closed.
    function sentPanel() {
      const x = sent || { said: '', skipped: 0, call: [] };
      sp.open({ title: 'Message', focus: 'head', body: [
        h('p', { class: 'cm-sent' }, x.any ? K.icon('check', 14) : null, h('span', { text: K.facts([x.said, x.skipped ? x.skipped + ' skipped · Already ' + (D.msgs_per_person || 4) + ' today' : '']) })),
        h('h3', { class: 'ap-label cm-sub', text: 'Call · ' + x.call.length }),
        h('ul', { class: 'cm-plain cm-call', 'aria-label': 'Call' }, x.call.map(c => h('li', { class: 'cm-call__p' }, h('span', { class: 'cm-call__n', text: c.name }), c.phone ? K.phone(c.phone) : null)))
      ], foot: [A.btn('Done', { ghost: true, onClick: () => sp.close() })], onClose: () => { panel = ''; sent = null; draw(); } });
    }

    // The committee's one instruction for every shift, and its reminders (its head or the COA).
    function setupPanel() {
      const su = D.setup || {};
      const ins = h('textarea', { class: 'ap-textarea', rows: '3', maxlength: '200', 'data-autofocus': '', 'aria-describedby': 'cm-ins-n' });
      ins.value = su.instruction || '';
      // A live count toward the 200 (after the third critic, Oct 15).
      const n = h('span', { class: 'ap-help cm-count', id: 'cm-ins-n', 'aria-live': 'polite' });
      const count = () => { n.textContent = ins.value.length + ' of 200'; n.classList.toggle('is-near', ins.value.length >= 180); };
      ins.addEventListener('input', count);
      count();
      const wk = h('input', { type: 'checkbox', class: 'ap-check', checked: su.week !== false }), dy = h('input', { type: 'checkbox', class: 'ap-check', checked: su.day !== false });
      const err = h('p', { class: 'ap-err', role: 'alert' });
      const save = A.btn('Save', { primary: true, write: true, onClick: () => {
        save.disabled = true;
        vol('POST', '/setup', { committee, instruction: ins.value, week: wk.checked, day: dy.checked }).then(r => {
          D.setup = r; panel = ''; A.toast('Saved · ' + committee); draw();
        }).catch(e => { save.disabled = false; const d = e.data || {}; err.textContent = d.data && d.data.fields ? Object.values(d.data.fields).filter(Boolean).join(' · ') : d.message || 'Not saved'; });
      } });
      sp.open({ title: 'For every shift', body: [
        // A neutral example, not another committee's (after the third critic, Oct 15: Transportation saw
        // the Ushers').
        h('label', { class: 'ap-field' }, h('span', { text: 'Instruction' }), ins, h('span', { class: 'ap-help', text: 'Like: Come 10 minutes early to check in · On the volunteer page once, and in every email' }), n),
        h('div', { class: 'ap-field' }, h('span', { text: 'Reminders' }),
          h('label', { class: 'ap-switch' }, wk, h('span', { text: 'A week before the Conference' })),
          h('label', { class: 'ap-switch' }, dy, h('span', { text: 'The day before each shift' })),
          h('span', { class: 'ap-help', text: 'By email, with the shift’s calendar file' })),
        err],
      foot: [save, A.btn('Cancel', { ghost: true, onClick: () => { panel = ''; draw(); } })], onClose: () => { panel = ''; draw(); } });
    }

    // The browser's own Print (⌘P, or its menu) prints the same clean sheet as More › Print, never the
    // screen (after the seventh critic, Oct 15: ⌘P printed the app's chrome, the ≡ icon and "Add
    // instruction", with no title).
    const ownPrint = () => { if (alive && committee && D && D.shifts && !document.documentElement.classList.contains('cm-printing')) printList(false); };
    window.addEventListener('beforeprint', ownPrint);
    function printList(dialog) {
      // "Since you printed" moves on once the print dialog closes (a cancel can't be told from a print),
      // and what was before it stays under Earlier (after the fourth critic, Oct 15).
      const seen = () => { window.removeEventListener('afterprint', seen); vol('POST', '/printed', { committee, what: 'seen' }).then(() => { if (alive && !panel && !p.id) refresh(); }).catch(() => {}); };
      window.addEventListener('afterprint', seen);
      const byDay = {};
      D.shifts.forEach(s => { (byDay[dayKey(s)] = byDay[dayKey(s)] || []).push(s); });
      // Compact: what every shift shares said once at the top; a column only for what differs.
      const sh = sharedOf(D.shifts);
      const cols = [sh.role == null ? ['Shift', s => s.role] : null, ['When', s => when(s)], sh.place == null ? ['Place', s => s.place] : null].filter(Boolean);
      // Every day's table has the same columns at the same widths (after the second critic, Oct 15: each
      // day sized its own, so the days didn't line up).
      // "Fri night · 12–3 AM" needs a wider When (after the eighth critic, Oct 16).
      const W = { Shift: 22, When: D.shifts.some(s => s.night) ? 21 : 17, Place: 19 }, fixed = cols.reduce((k, c) => k + W[c[0]], 0);
      // Each name whole on one line (after the ninth critic, Oct 16: the Name column was what was left, 11%,
      // so "Deborah / Stone" wrapped): Name as wide as the longest name in the print's own type, Phone as its
      // longest number, Here a box; the shift's own columns share the rest as before, their words free to
      // wrap. Measured in the sheet's type (10.5 pt) against the letter page less its margins (7.6 in).
      const PAGE = 7.6 * 96, PAD = 16;
      const meas = h('span', { 'aria-hidden': 'true', style: { position: 'absolute', left: '-9999px', top: '0', visibility: 'hidden', whiteSpace: 'nowrap', font: '10.5pt/1.35 -apple-system, "Segoe UI", Arial, sans-serif' } });
      document.body.appendChild(meas);
      const widest = list => list.reduce((m, t) => { meas.textContent = t; return Math.max(m, meas.getBoundingClientRect().width); }, 0);
      const everyone = D.shifts.reduce((a, s) => a.concat(s.people), []);
      const pct = (px, lo, hi) => Math.min(hi, Math.max(lo, Math.ceil(1000 * (px + PAD) / PAGE) / 10));
      const wName = pct(widest(everyone.map(pp => pp.name).concat(['No limit', '000 open'])), 14, 32), wPhone = pct(widest(everyone.map(pp => pp.phone || '')), 10, 18), wHere = 7.5;
      const rest = 100 - wName - wPhone - wHere;
      const colgroup = () => h('colgroup', null, cols.map(c => h('col', { style: { width: (Math.floor(10 * rest * W[c[0]] / fixed) / 10) + '%' } })).concat([h('col', { style: { width: wName + '%' } }), h('col', { style: { width: wPhone + '%' } }), h('col', { style: { width: wHere + '%' } })]));
      meas.remove();
      // A shift's rows stay together on one page (its own tbody), and the day's heading is the table's
      // first header row, so a day that runs onto the next page says its day again (after the third
      // critic, Oct 15: the continuation had no heading, and a shift was split across pages).
      const heads = cols.map(c => c[0]).concat(['Name', 'Phone', 'Here']);
      // After the people: a line per open place, up to 8; more open than that, "12 open" said once and
      // three lines to write names in; a shift with no limit, "No limit" and the same three lines (after the
      // ninth critic, Oct 16: Young Folks printed 17 pages, a line for each of kit packing's places).
      const OPEN_LINES = 8, WRITE_LINES = 3;
      const linesOf = s => {
        const open = s.unlimited ? 0 : Math.max(0, s.needed - s.people.length);
        const ls = s.people.map(pp => ['p', pp]);
        if (s.unlimited || open > OPEN_LINES) {
          ls.push(['note', s.unlimited ? 'No limit' : open + ' open']);
          for (let i = 0; i < WRITE_LINES; i++) ls.push(['write']);
        } else for (let i = 0; i < open; i++) ls.push(['open']);
        return ls.length ? ls : [['open']];
      };
      K.print({ dialog: dialog !== false, title: committee + ' · Helpers', who: committee + ' only', build: () => h('div', null, sh.line ? h('p', { class: 'cm-print__shared', text: sh.line }) : null, Object.keys(byDay).sort().map(d => h('section', { class: 'cm-psec' },
        h('table', { class: 'cm-ptable' }, colgroup(), h('thead', null, h('tr', { class: 'cm-pday' }, h('th', { colspan: String(heads.length) }, h('h2', { text: dayHead(d, byDay[d]) }))), h('tr', null, heads.map(c => h('th', { text: c })))),
          byDay[d].map(s => h('tbody', { class: 'cm-pshift' }, linesOf(s).map((ln, k) => {
            const pp = ln[0] === 'p' ? ln[1] : null;
            return h('tr', { class: ln[0] === 'write' ? 'cm-pwrite' : null }, cols.map(c => h('td', { text: k ? '' : c[1](s) })),
              h('td', { class: 'cm-pname' + (ln[0] === 'note' ? ' cm-pnote' : ''), text: pp ? pp.name : ln[0] === 'open' ? 'Open' : ln[0] === 'note' ? ln[1] : '' }),
              h('td', { text: pp ? (pp.phone || '') + (pp.via ? ' · via ' + pp.via : '') : '' }),
              h('td', { class: ln[0] === 'note' ? null : 'cm-tick' }));
          }))))))) });
      vol('POST', '/printed', { committee, what: 'done' }).catch(() => {});
    }

    K.loading(ctx);
    load();
    const t = setInterval(() => { if (!document.hidden && !panel && !p.id && committee) refresh(); }, 60000);
    return () => { alive = false; clearInterval(t); window.removeEventListener('beforeprint', ownPrint); if (headRO) headRO.disconnect(); };
  }

  A.screen({ id: 'helpers', title: 'Shifts', icon: 'members', section: 'own', who: ['committee'], render: screen });
})();
