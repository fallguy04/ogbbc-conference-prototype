/*
 * Helpers (app-committees, Oct 11): who's signed up for a committee's volunteer shifts, for the
 * committee itself (the volunteer page's old ?view=lead, moved into the app). Every committee with
 * shifts has it in its sidebar; the COA opens any committee's.
 *
 *   The list     the committee's shifts by day: what, when, where, how full, and who (names); a shift
 *                opens beside the list with each person's phone, Move, Remove (Undo), Here during the
 *                week, the waiting list (Offer), and Add person (by phone, on paper, at the desk).
 *   Message      an email through the site to everyone on the committee's shifts, a day's, or one
 *                shift's (replies to you; no address shown to anyone).
 *   Print        a day at a time, one line a person, with a Here box. Download: the list for Excel.
 * The server decides who sees what (module-app-committees.php): a committee's people see their own
 * committee's shifts only; the COA every committee's.
 */
(function () {
  'use strict';
  const A = window.OGC_APP, h = A.h, K = window.OGC_CK;
  const key = n => String(n || '').toLowerCase().trim().replace(/\s+/g, ' ').replace(/^the\s+|\s+committee$/g, '').trim();
  const hm = m => { m = ((m % 1440) + 1440) % 1440; const hh = Math.floor(m / 60), mm = m % 60; return (hh % 12 || 12) + (mm ? ':' + String(mm).padStart(2, '0') : '') + ' ' + (hh >= 12 ? 'PM' : 'AM'); };
  const span = s => hm(s.start).replace(/ (AM|PM)$/, hm(s.start).slice(-2) === hm(s.end).slice(-2) ? '' : ' $1') + '–' + hm(s.end);

  function screen(ctx) {
    const p = ctx.params, v = ctx.boot.viewer;
    let D = null, sp = null, panel = '', alive = true, committee = '';
    const vol = (method, path, body) => A.api(method, '/vol/' + p.year + '/lead' + path, body);
    const ro = () => !!A.readonly || (D && D.gone);

    // Which committee: the address (?c=), else the viewer's own (the switcher's), else the first.
    function pickCommittee(list) {
      const want = p.c || (v.coa ? '' : A.team());
      const hit = list.find(c => key(c.name) === want);
      return hit ? hit.name : (list[0] || {}).name || '';
    }
    function load() {
      return vol('GET', '').then(first => {
        // Only committees that have shifts (committees.csv also lists those without).
        const list = (first.committees || []).filter(c => c.shifts > 0);
        first.committees = list;
        committee = pickCommittee(list);
        // The address names the committee shown, so Reload, a copied link and the crumb agree.
        if (committee && key(committee) !== p.c) A.setParams({ c: key(committee) });
        if (!committee) { D = Object.assign(first, { shifts: [] }); return draw(); }
        return vol('GET', '?committee=' + encodeURIComponent(committee)).then(d => { D = d; if (alive) draw(); });
      }).catch(err => { if (alive) K.failed(ctx, err); });
    }
    const refresh = () => vol('GET', '?committee=' + encodeURIComponent(committee)).then(d => { D = d; if (alive) draw(); }).catch(A.fail);
    const find = id => D.shifts.find(s => s.id === id);

    function draw() {
      if (!sp) { A.clear(ctx.body); sp = ctx.split(); }
      A.clear(sp.main);
      const coms = D.committees || [];
      if (!committee) { ctx.head('Helpers', '', []); sp.main.appendChild(A.empty({ title: 'No shifts', line: 'The year’s shifts are set by the COA', inset: true })); return; }
      const shifts = D.shifts || [];
      const needed = shifts.reduce((k, s) => k + (s.unlimited ? 0 : s.needed), 0), filled = shifts.reduce((k, s) => k + Math.min(s.n, s.unlimited ? s.n : s.needed), 0);
      const open = shifts.filter(s => !s.unlimited && s.n < s.needed).length;
      const many = coms.length > 1;
      // The shifts themselves (times, places, how many) are kept in the shift editor until it moves in.
      const editIn = what => { location.href = (OGC_WP.base || '/annual-conference/') + 'admin/?year=' + p.year + '&edit=' + encodeURIComponent(what) + '&return=' + encodeURIComponent(location.pathname + location.search); };
      ctx.head(many ? 'Helpers · ' + committee : 'Helpers', D.gone ? 'Names cleared · Counts only' : K.facts([needed ? (filled ? filled + ' of ' + needed + ' places filled' : K.plural(needed, 'place') + ' to fill') : filled ? K.plural(filled, 'person', 'people') : '', open ? K.plural(open, 'shift') + ' open' : needed ? 'All filled' : '', D.posted ? '' : 'Not public']),
        [ro() ? null : A.btn('Message', { primary: !panel, icon: 'mail', write: true, disabled: !shifts.some(s => s.people.length), onClick: () => openPanel('msg') }),
          K.more('More', [ro() ? null : { label: 'Edit shifts', run: () => editIn('shifts:' + committee) }, { label: 'Print', run: printList }, { label: 'Download', run: () => K.fetchFile('ogc/v1/vol/' + p.year + '/lead/export?committee=' + encodeURIComponent(committee) + (p.as ? '&as=' + encodeURIComponent(p.as) : ''), key(committee).replace(/[^a-z0-9]+/g, '-') + '-volunteers-' + p.year + '.csv').then(() => vol('POST', '/printed', { committee, what: 'seen' }).catch(() => {})).catch(() => A.toast('Not downloaded')) }], { ghost: true })].filter(Boolean));
      if (many) sp.main.appendChild(h('div', { class: 'cm-toolbar' }, A.views(coms.map(c => ({ id: c.name, label: c.name })), committee, name => { A.go({ c: key(name), id: '' }, { replace: true }); })));
      if (D.left && D.left.length) sp.main.appendChild(h('p', { class: 'cm-pad cm-since' }, 'Since you printed · ', D.left.map(l => l.name + ' left ' + (find(l.shift) || {}).role).join(' · ')));
      if (!shifts.length) { sp.main.appendChild(A.empty({ title: 'No shifts for ' + committee, inset: true })); return; }
      const byDay = {};
      shifts.forEach(s => { (byDay[s.date] = byDay[s.date] || []).push(s); });
      const rows = [];
      Object.keys(byDay).sort().forEach(d => {
        rows.push(h('tr', { class: 'cm-group' }, h('td', { colspan: '4', text: K.day(d) + ' · ' + K.plural(byDay[d].length, 'shift') })));
        byDay[d].forEach(s => {
          const full = s.unlimited ? null : s.n / Math.max(1, s.needed);
          rows.push(h('tr', { class: p.id === s.id ? 'is-open' : '' },
            h('td', null, h('button', { type: 'button', class: 'cm-rowbtn', on: { click: () => { panel = ''; p.id = s.id; A.setParams({ id: s.id }); draw(); } } }, h('span', { class: 'cm-title', text: s.role })), h('span', { class: 'cm-sub2', text: K.facts([span(s), s.place, s.rule]) })),
            h('td', { class: 'is-num' }, h('span', { class: 'ap-bar', 'aria-hidden': 'true' }, h('i', { style: { width: Math.round(100 * Math.min(1, full == null ? 1 : full)) + '%' } })), s.unlimited ? (s.n ? String(s.n) : 'None yet') : s.n ? s.n + ' of ' + s.needed : 'None yet'),
            h('td', { class: 'is-wide' }, D.gone ? '' : s.people.map(pp => pp.name).join(', '), s.waiting.length ? h('span', { class: 'cm-sub2', text: s.waiting.length + ' waiting' }) : null),
            h('td', { class: 'is-num' }, !s.unlimited && s.n < s.needed ? h('span', { class: 'cm-chip cm-chip--tan', text: (s.needed - s.n) + ' open' }) : s.over ? h('span', { class: 'cm-chip', text: s.over + ' over' }) : !s.unlimited ? h('span', { class: 'cm-chip', text: 'Full' }) : null)));
        });
      });
      sp.main.appendChild(h('div', { class: 'cm-scroll' }, h('table', { class: 'cm-table' }, h('thead', null, h('tr', null, h('th', { text: 'Shift' }), h('th', { class: 'is-num', text: 'Filled' }), h('th', { class: 'is-wide', text: 'Who' }), h('th', null, h('span', { class: 'ap-sr', text: 'Open' })))), h('tbody', null, rows))));
      if (panel === 'msg') return msgPanel();
      const cur = p.id && find(p.id);
      if (cur) shiftPanel(cur); else sp.close(true);
    }
    function openPanel(k) { panel = k; p.id = ''; A.setParams({ id: '' }); draw(); }

    function shiftPanel(s) {
      const others = D.shifts.filter(x => x.id !== s.id);
      const during = D.begun;
      const person = pp => {
        const here = h('input', { type: 'checkbox', class: 'ap-check', checked: pp.here, disabled: ro(), 'aria-label': 'Here: ' + pp.name });
        here.addEventListener('change', () => vol('POST', '/here', { committee, id: pp.rid, here: here.checked }).then(() => { pp.here = here.checked; A.toast(pp.name + (here.checked ? ' · Here' : ' · Not here')); }).catch(e => { here.checked = !here.checked; A.fail(e); }));
        const moveTo = h('div', { hidden: true }, h('p', { class: 'ap-label cm-sub', text: 'Move to' }), h('div', { class: 'ap-pills' }, others.slice(0, 30).map(o => h('button', { type: 'button', class: 'ap-pill', on: { click: () => vol('POST', '/move', { committee, id: pp.rid, to: o.id }).then(() => { A.toast('Moved · ' + pp.name + ' · ' + o.role + ', ' + K.day(o.date)); refresh(); }).catch(e => A.toast((e.data && e.data.message) || 'Not moved')) } }, o.role + ' · ' + K.day(o.date) + ' ' + hm(o.start)))));
        return h('li', { class: 'cm-person' },
          h('div', { class: 'cm-person__main' }, h('b', { text: pp.name }), h('span', { class: 'cm-sub2' }, K.phone(pp.phone), pp.phone && pp.email ? ' · ' : '', pp.email || '', pp.by === 'head' ? ' · Added by a head' : '', pp.hidden ? ' · Name hidden' : '', pp.check ? ' · Also on ' + pp.check : ''), pp.note ? h('span', { class: 'cm-sub2', text: pp.note }) : null),
          ro() ? null : h('div', { class: 'ap-row' }, during ? h('label', { class: 'ap-switch' }, here, 'Here') : null,
            others.length ? A.btn('Move', { ghost: true, onClick: () => { moveTo.hidden = !moveTo.hidden; } }) : null,
            A.btn('Remove', { ghost: true, danger: true, write: true, onClick: () => vol('POST', '/remove', { committee, id: pp.rid }).then(() => {
              A.toast('Removed · ' + pp.name, { undo: () => vol('POST', '/restore', { committee, id: pp.rid }).then(() => { A.toast('Restored · ' + pp.name); refresh(); }).catch(e => A.toast((e.data && e.data.message) || 'Can’t undo')) });
              refresh();
            }).catch(A.fail) })), moveTo);
      };
      const name = h('input', { class: 'ap-input', autocomplete: 'off', maxlength: '80' }), phone = h('input', { class: 'ap-input', type: 'tel', autocomplete: 'off' }), email = h('input', { class: 'ap-input', type: 'email', autocomplete: 'off' });
      const err = h('p', { class: 'ap-err', role: 'alert' });
      const add = () => vol('POST', '/add', { committee, shift: s.id, name: name.value, phone: phone.value, email: email.value }).then(() => { A.toast('Added · ' + name.value.trim() + ' · ' + s.role); refresh(); })
        .catch(e => { const d = e.data || {}; err.textContent = d.code === 'busy' || (d.data && d.data.busy) ? 'Busy · On ' + ((d.data && d.data.busy && d.data.busy.role) || 'another shift') + ' then' : d.data && d.data.fields ? Object.values(d.data.fields).filter(Boolean).join(' · ') : d.message || 'Not added'; });
      sp.open({
        title: s.role,
        body: [
          h('p', { class: 'cm-detail__m', text: K.facts([K.day(s.date), span(s), s.place, s.unlimited ? K.plural(s.n, 'person', 'people') : s.n + ' of ' + s.needed]) }),
          s.rule ? h('p', { class: 'ap-quiet', text: 'Asks · ' + s.rule }) : null,
          s.people.length ? h('ul', { class: 'cm-plain cm-people2' }, s.people.map(person)) : h('p', { class: 'ap-quiet', text: 'No one yet' }),
          s.waiting.length ? [h('h3', { class: 'ap-label cm-sub', text: 'Waiting · ' + s.waiting.length }), h('ul', { class: 'cm-plain' }, s.waiting.map(w => h('li', { class: 'ap-row' }, h('span', { style: { flex: '1' } }, h('b', { text: w.name }), ' ', K.phone(w.phone)), ro() ? null : A.btn('Offer', { write: true, title: 'Emails them a one-tap Join', onClick: () => vol('POST', '/offer', { committee, id: w.rid }).then(() => A.toast('Offered · ' + w.name)).catch(A.fail) }))))] : null,
          ro() ? null : h('details', { class: 'cm-fold', open: !s.people.length }, h('summary', { text: 'Add person' }),
            h('label', { class: 'ap-field' }, h('span', { text: 'Name' }), name),
            h('label', { class: 'ap-field' }, h('span', { text: 'Phone' }), phone),
            h('label', { class: 'ap-field' }, h('span', { text: 'Email' }), email, h('span', { class: 'ap-help', text: 'Optional · They get a confirmation' })),
            err, A.btn('Add', { primary: true, write: true, onClick: add }))
        ],
        onClose: () => { p.id = ''; A.setParams({ id: '' }); draw(); }
      });
    }

    function msgPanel() {
      const days = Array.from(new Set(D.shifts.map(s => s.date))).sort();
      let to = 'all';
      const subject = h('input', { class: 'ap-input', maxlength: '140', 'data-autofocus': '' }), body = h('textarea', { class: 'ap-textarea', rows: '6' });
      const err = h('p', { class: 'ap-err', role: 'alert' }), count = h('p', { class: 'ap-quiet' });
      const who = () => { const n = new Set(); D.shifts.filter(s => to === 'all' || 'day:' + s.date === to).forEach(s => s.people.forEach(pp => n.add(pp.email || pp.name))); return n.size; };
      const pills = h('div');
      const drawPills = () => { A.clear(pills).appendChild(K.pills([['all', 'Everyone']].concat(days.map(d => ['day:' + d, K.day(d)])), to, x => { to = x; drawPills(); }, 'To')); count.textContent = K.plural(who(), 'person', 'people') + ' · Replies to you · ' + (D.msgs_left != null ? D.msgs_left + ' left today' : ''); };
      drawPills();
      const send = A.btn('Send', { primary: true, icon: 'mail', write: true, onClick: () => {
        send.disabled = true;
        vol('POST', '/message', { committee, to: to === 'all' ? '' : to, subject: subject.value, body: body.value }).then(r => {
          panel = ''; A.toast('Sent · ' + K.plural((r && (r.sent || r.n)) || who(), 'person', 'people') + (r && r.call && r.call.length ? ' · ' + r.call.length + ' to call' : '')); refresh();
        }).catch(e => { send.disabled = false; const d = e.data || {}; err.textContent = d.data && d.data.fields ? Object.values(d.data.fields).filter(Boolean).join(' · ') : d.message || 'Not sent'; });
      } });
      sp.open({ title: 'Message', body: [h('div', { class: 'ap-field' }, h('span', { text: 'To' }), pills, count), h('label', { class: 'ap-field' }, h('span', { text: 'Subject' }), subject), h('label', { class: 'ap-field' }, h('span', { text: 'Message' }), body), err],
        foot: [send, A.btn('Cancel', { ghost: true, onClick: () => { panel = ''; draw(); } })], onClose: () => { panel = ''; draw(); } });
    }

    function printList() {
      vol('POST', '/printed', { committee, what: 'seen' }).catch(() => {});
      const byDay = {};
      D.shifts.forEach(s => { (byDay[s.date] = byDay[s.date] || []).push(s); });
      K.print({ title: committee + ' · Helpers', who: committee + ' only', build: () => h('div', null, Object.keys(byDay).sort().map((d, i) => h('section', { class: i ? 'cm-pbreak' : '' }, h('h2', { text: K.day(d) }),
        h('table', null, h('thead', null, h('tr', null, ['Shift', 'When', 'Place', 'Name', 'Phone', 'Here'].map(c => h('th', { text: c })))),
          h('tbody', null, byDay[d].map(s => {
            const list = s.people.length ? s.people : [null];
            const open = s.unlimited ? 0 : Math.max(0, s.needed - s.people.length);
            return list.map((pp, k) => h('tr', null, h('td', { text: k ? '' : s.role }), h('td', { text: k ? '' : span(s) }), h('td', { text: k ? '' : s.place }), h('td', { text: pp ? pp.name : 'Open' }), h('td', { text: pp ? pp.phone : '' }), h('td', { class: 'cm-tick' })))
              .concat(Array.from({ length: s.people.length ? open : Math.max(0, open - 1) }, () => h('tr', null, h('td'), h('td'), h('td'), h('td', { text: 'Open' }), h('td'), h('td', { class: 'cm-tick' }))));
          })))))) });
      vol('POST', '/printed', { committee, what: 'done' }).catch(() => {});
    }

    K.loading(ctx);
    load();
    const t = setInterval(() => { if (!document.hidden && !panel && !p.id && committee) refresh(); }, 60000);
    return () => { alive = false; clearInterval(t); };
  }

  A.screen({ id: 'helpers', title: 'Helpers', icon: 'members', section: 'own', who: ['committee'], render: screen });
})();
