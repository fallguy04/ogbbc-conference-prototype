/*
 * coa-kit.js — what the COA's screens share (window.OGC_COA), on top of the app's kit (OGC_APP):
 *
 *   K.load(year, { force })    the year's files (one /bundle) and the COA's overview (GET coa/{y}),
 *                              cached for the session; K.drop(year) forgets them after a change
 *   K.rows(year, name)         one file kept row by row (ED.Rows, admin-rows.js), one per file per visit,
 *                              so Undo and unsent changes survive moving between screens
 *   K.statusOf(rowsList)       one word for the title row from every file a screen saves
 *   K.dateIn / K.textIn / K.pills / K.field   inputs that say back what they read, errors at the field
 *   K.confirm(sp, …)           a decision in the record panel (never a pop-up): what happens, what isn't
 *                              done, the act, Cancel; the heading takes the focus, never the act
 *   K.looks(…)                 "From 2026 · Looks right" on a thing carried from last year
 *   K.md / K.mdY / K.ago       dates and times in status words
 *
 * Nothing a person typed goes into innerHTML: everything is built with OGC_APP.h.
 */
(function () {
  'use strict';
  const A = window.OGC_APP, O = window.OGC, ED = window.ED, W = window.OGC_WP || {};
  if (!A || !O || !ED) return;
  const h = A.h;
  const K = window.OGC_COA = {};
  const NOT_YET = '9999-12-31';
  if (A.addIcons) A.addIcons({
    pin: 'M8 14s-4.5-3.8-4.5-7.5a4.5 4.5 0 0 1 9 0C12.5 10.2 8 14 8 14Zm0-6a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3Z',
    clock: 'M8 14A6 6 0 1 0 8 2a6 6 0 0 0 0 12ZM8 5v3.2l2 1.3',
    box: 'M2.5 5 8 2.5 13.5 5v6L8 13.5 2.5 11zM2.5 5 8 7.5 13.5 5M8 7.5v6',
    form: 'M5.5 2.5h5v2h-5zM5 3.5H3.5v10h9v-10H11M5.5 8h5M5.5 10.5h3.5',
    money: 'M2 4.5h12v7H2zM8 9.5a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3ZM4.5 6.5v3M11.5 6.5v3',
    book: 'M2.5 3h4a1.5 1.5 0 0 1 1.5 1.5v9a1.2 1.2 0 0 0-1.2-1.2H2.5zM13.5 3h-4A1.5 1.5 0 0 0 8 4.5v9a1.2 1.2 0 0 1 1.2-1.2h4.3z',
    help: 'M8 14A6 6 0 1 0 8 2a6 6 0 0 0 0 12ZM6.3 6.2a1.8 1.8 0 0 1 3.5.6c0 1.2-1.8 1.5-1.8 2.6M8 11.3v.2',
    grid: 'M2.5 2.5h11v11h-11zM2.5 6h11M6.5 6v7.5M10 6v7.5',
    list: 'M5.5 4h8M5.5 8h8M5.5 12h8M2.5 4h.01M2.5 8h.01M2.5 12h.01',
    more: 'M3.5 8h.01M8 8h.01M12.5 8h.01',
    check: 'M3 8.5l3 3 7-7'
  });
  // A listener on a file, with the way to take it off (screens come and go; the file stays).
  K.on = function (f, ev, fn) { f.on(ev, fn); return () => { f.fns[ev] = (f.fns[ev] || []).filter(x => x !== fn); }; };
  K.NOT_YET = NOT_YET;

  /* ------------------------------------------------------------ the year's data */

  const cache = {};
  // The bundle and the overview, together. A screen draws from these; a change sends K.drop.
  K.load = function (year, o) {
    const y = String(year);
    if (cache[y] && !(o && o.force) && Date.now() - cache[y].at < 60000) return cache[y].p;
    const p = Promise.all([
      W.api('GET', 'years/' + y + '/bundle').catch(() => ({})),
      W.api('GET', 'coa/' + y).catch(err => { if (err.status === 403) return null; throw err; })
    ]).then(([b, ov]) => {
      const d = { year: y, b: b || {}, ov, S: kv(b, 'settings'), R: kv(b, 'registration') };
      d.rowsOf = n => ((d.b[n] || {}).rows || []);
      d.today = (ov && ov.today) || O.wallNow(d.S.timezone || 'America/Indiana/Indianapolis').date;
      d.row = (ov && ov.year) || {};
      d.held = !!(d.row.end && d.today > d.row.end);
      d.coa = (ov && ov.coa) || { steps: {}, checks: {}, notes_done: {}, pub: {}, sent: {}, due: {} };
      ['steps', 'checks', 'notes_done', 'pub', 'sent', 'due'].forEach(k => { if (!d.coa[k] || Array.isArray(d.coa[k])) d.coa[k] = {}; });
      d.picked = (ov && ov.picked) || { parts: {} };
      d.days = (d.S.days || '').split('|').filter(Boolean).map((name, i) => ({ name, date: d.S.first_day ? O.isoAddDays(d.S.first_day, i) : '' }));
      return d;
    });
    cache[y] = { at: Date.now(), p };
    p.catch(() => { delete cache[y]; });
    return p;
  };
  K.drop = year => { delete cache[String(year)]; };
  // Another year's files as anyone may read them (last year's, to compare): no COA overview.
  const bundles = {};
  K.bundle = year => bundles[year] || (bundles[year] = W.api('GET', 'years/' + year + '/bundle').catch(() => ({})));
  function kv(b, n) { const o = {}; (((b || {})[n] || {}).rows || []).forEach(r => { if (r.key) o[r.key] = r.value == null ? '' : String(r.value); }); return o; }

  // A file kept row by row: one per file per visit (its Undo and unsent changes are kept).
  const files = {};
  K.rows = function (year, name, d) {
    const k = year + '/' + name;
    if (!files[k]) {
      const f = new ED.Rows(year, name, { readOnly: !!A.readonly || !!(d && d.held && !(A.boot() || {}).viewer.webmaster) });
      f.ready = f.load(d && d.b[name] ? d.b[name] : null).then(() => f, err => { delete files[k]; throw err; });
      f.on('change', e => { if (e && e.server) K.drop(year); });
      files[k] = f;
      // Every 30 seconds and when the window comes back: others' changes come in.
      f.timer = setInterval(() => { if (!document.hidden) f.sync(); }, 30000);
    }
    return files[k];
  };
  K.unsaved = () => Object.values(files).reduce((n, f) => n + (f.unsaved ? f.unsaved() : 0), 0);
  window.addEventListener('beforeunload', e => { if (K.unsaved()) { e.preventDefault(); e.returnValue = ''; } });
  window.addEventListener('focus', () => Object.values(files).forEach(f => f.loaded && f.sync()));

  // The COA's own routes (/coa/{y}/…) and any ogc/v1 path.
  K.api = (m, p, b) => W.api(m, p, b);
  K.coa = (year, act, body) => W.api('POST', 'coa/' + year + '/' + act, body || {}).then(r => { K.drop(year); return r; });

  /* ------------------------------------------------------------ words */

  const SHORT = new Intl.DateTimeFormat('en-US', { month: 'short', day: 'numeric', timeZone: 'UTC' });
  const SHORTY = new Intl.DateTimeFormat('en-US', { month: 'short', day: 'numeric', year: 'numeric', timeZone: 'UTC' });
  const WEEKDAY = new Intl.DateTimeFormat('en-US', { weekday: 'short', month: 'short', day: 'numeric', timeZone: 'UTC' });
  const ok = iso => !!O.parseISODate(iso) && iso !== NOT_YET;
  const WEEKNAME = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  K.md = iso => ok(iso) ? SHORT.format(new Date(iso + 'T12:00:00Z')) : '';
  // With its year when it isn't this one ("Feb 25, 2027" seen in 2026).
  K.mdY = (iso, year) => !ok(iso) ? '' : (String(year || '') === iso.slice(0, 4) ? K.md(iso) : SHORTY.format(new Date(iso + 'T12:00:00Z')));
  K.wd = iso => ok(iso) ? WEEKDAY.format(new Date(iso + 'T12:00:00Z')) : '';
  K.plural = A.fmt.plural;
  K.money = c => '$' + (c / 100).toLocaleString('en-US', { minimumFractionDigits: c % 100 ? 2 : 0, maximumFractionDigits: 2 });
  // "just now", "5 min ago", "2 h ago", "Oct 9".
  K.ago = function (at) {
    const t = Date.parse(String(at || '').replace(' ', 'T') + (/[zZ+]/.test(at || '') ? '' : 'Z'));
    if (!t) return '';
    const s = (Date.now() - t) / 1000;
    if (s < 60) return 'just now';
    if (s < 3600) return Math.round(s / 60) + ' min ago';
    if (s < 86400) return Math.round(s / 3600) + ' h ago';
    return K.md(new Date(t).toISOString().slice(0, 10));
  };
  // A typed date: "Feb 25", "2/25", "February 25, 2027", "2027-02-25", "Fri". → ISO or ''.
  const MON = ['jan', 'feb', 'mar', 'apr', 'may', 'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec'];
  K.readDate = function (text, near) {
    const t = String(text || '').trim().toLowerCase().replace(/(\d)(st|nd|rd|th)\b/g, '$1').replace(/,/g, ' ');
    if (!t) return '';
    let m = t.match(/^(\d{4})-(\d{1,2})-(\d{1,2})$/);
    const iso = (y, mo, d) => { const dt = new Date(Date.UTC(y, mo - 1, d)); return dt.getUTCMonth() === mo - 1 ? dt.toISOString().slice(0, 10) : ''; };
    const yearFor = (mo, d) => {
      // The nearest such date to `near` (the Conference's year, or today): a date in the past year
      // reads as next year's when it's far behind.
      const base = near && O.parseISODate(near) ? O.parseISODate(near).y : new Date().getUTCFullYear();
      const c = [base - 1, base, base + 1].map(y => iso(y, mo, d)).filter(Boolean);
      if (!near) return c[1] || c[0];
      return c.sort((a, b) => Math.abs(O.daysBetween(near, a)) - Math.abs(O.daysBetween(near, b)))[0];
    };
    if (m) return iso(+m[1], +m[2], +m[3]);
    m = t.match(/^(\d{1,2})\/(\d{1,2})(?:\/(\d{2,4}))?$/);
    if (m) return m[3] ? iso(m[3].length === 2 ? 2000 + +m[3] : +m[3], +m[1], +m[2]) : yearFor(+m[1], +m[2]);
    m = t.match(/^(?:[a-z]+\s+)?([a-z]{3})[a-z]*\.?\s+(\d{1,2})(?:\s+(\d{4}))?$/);
    if (m && MON.indexOf(m[1]) > -1) return m[3] ? iso(+m[3], MON.indexOf(m[1]) + 1, +m[2]) : yearFor(MON.indexOf(m[1]) + 1, +m[2]);
    return '';
  };

  /* ------------------------------------------------------------ the title row's status */

  const WORDS = { saving: 'Saving', saved: 'Saved', offline: 'Offline · Saves when back', error: 'Not saved', signedout: 'Signed out · Sign in', held: 'Read only', conflict: 'Not saved · Choose' };
  // One status for every file a screen saves: the worst of them.
  K.status = function (list, offs) {
    const el = h('span', { class: 'cx-status', role: 'status', 'aria-live': 'polite' });
    const order = ['signedout', 'error', 'conflict', 'offline', 'saving', 'held', 'saved'];
    let first = true;
    const draw = () => {
      const st = list.map(f => f.state || 'saved').sort((a, b) => order.indexOf(a) - order.indexOf(b))[0] || 'saved';
      const f = list.find(x => x.state === st);
      const n = list.reduce((s, x) => s + (x.conflicts ? x.conflicts() : 0), 0);
      el.textContent = st === 'conflict' ? 'Not saved · ' + K.plural(n, 'clash', 'clashes') : st === 'error' && f && f.problem ? 'Not saved · ' + f.problem : first && st === 'saved' ? '' : WORDS[st] || '';
      el.dataset.state = st;
      if (st === 'signedout') { el.textContent = ''; el.appendChild(h('a', { href: (W.signin || '/annual-conference/signin/') + '?return=' + encodeURIComponent(location.pathname + location.search), text: 'Signed out · Sign in' })); }
      first = false;
    };
    list.forEach(f => { const off = K.on(f, 'status', draw); if (offs) offs.push(off); });
    draw();
    return el;
  };

  /* ------------------------------------------------------------ fields */

  // A labelled field: the label, the input, then help or an error under it.
  K.field = function (label, input, o) {
    o = o || {};
    const err = h('span', { class: 'ap-err', role: 'alert', hidden: true });
    const wrap = h(o.tag || 'label', { class: 'ap-field cx-field' + (o.cls ? ' ' + o.cls : '') },
      h('span', { class: 'cx-field__label' }, label, o.tip ? h('span', { class: 'cx-tip', title: o.tip, 'aria-label': o.tip, text: 'i' }) : null),
      input, o.help ? h('span', { class: 'ap-help', text: o.help }) : null, err, o.after || null);
    wrap.setError = m => { err.textContent = m || ''; err.hidden = !m; wrap.classList.toggle('is-bad', !!m); };
    return wrap;
  };

  // A text box that saves as typed (onSave after a pause, and on leaving it). o: { value, placeholder,
  // multiline, rows, onSave(v) → error string or nothing, width, mono, label }
  K.textIn = function (o) {
    const el = h(o.multiline ? 'textarea' : 'input', {
      class: o.multiline ? 'ap-textarea cx-in' : 'ap-input cx-in', value: o.value || '', placeholder: o.placeholder || null,
      rows: o.rows || null, 'aria-label': o.label || null, autocomplete: 'off', spellcheck: o.multiline ? 'true' : null,
      disabled: A.readonly || o.disabled, inputmode: o.inputmode || null
    });
    if (o.width) el.style.maxWidth = o.width;
    if (o.multiline) { el.value = o.value || ''; grow(el); el.addEventListener('input', () => grow(el)); }
    // One line of words that wraps (a title on a phone is never cut off): Enter finishes, no new lines.
    if (o.multiline && o.oneLine) {
      el.classList.add('cx-in--oneline');
      el.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); el.blur(); } });
      el.addEventListener('input', () => { if (/[\r\n]/.test(el.value)) { el.value = el.value.replace(/\s*[\r\n]+\s*/g, ' '); grow(el); } });
    }
    let t = 0, last = o.value || '';
    const save = () => { clearTimeout(t); if (el.value === last) return; last = el.value; const r = o.onSave && o.onSave(el.value, el); if (el.closest('.cx-field') && el.closest('.cx-field').setError) el.closest('.cx-field').setError(typeof r === 'string' ? r : ''); };
    el.addEventListener('input', () => { clearTimeout(t); if (o.live !== false) t = setTimeout(save, o.delay || 600); });
    el.addEventListener('change', save);
    el.addEventListener('blur', save);
    el.set = v => { last = v; el.value = v; if (o.multiline) grow(el); };
    return el;
  };
  // A text box as tall as its words (measured once it's on the page).
  function grow(t) { if (!t.isConnected) { requestAnimationFrame(() => { if (t.isConnected) grow(t); }); return; } t.style.height = 'auto'; t.style.height = Math.min(900, t.scrollHeight + 2) + 'px'; }
  K.grow = grow;

  // A date typed as people say it ("Feb 25"), said back under it ("Thu, Feb 25, 2027"). onSave(iso).
  K.dateIn = function (o) {
    const shown = v => ok(v) ? K.mdY(v, '') : '';
    const back = h('span', { class: 'cx-said' });
    const el = h('input', { class: 'ap-input cx-in cx-in--date', value: shown(o.value), placeholder: o.placeholder || 'Date', 'aria-label': o.label || null, autocomplete: 'off', disabled: A.readonly || o.disabled });
    // Said back only what the box doesn't show: the weekday.
    const say = () => { const v = K.readDate(el.value, o.near); back.textContent = el.value.trim() && v ? WEEKNAME[new Date(v + 'T12:00:00Z').getUTCDay()] : ''; };
    say();
    let last = ok(o.value) ? o.value : '';
    const commit = () => {
      const t = el.value.trim();
      const v = t ? K.readDate(t, o.near) : '';
      const f = el.closest('.cx-field');
      if (t && !v) { if (f && f.setError) f.setError('Not a date · Try "Feb 25"'); return; }
      if (f && f.setError) f.setError('');
      if (v === last) return;
      const was = last; last = v;
      Promise.resolve(o.onSave && o.onSave(v)).then(r => { if (typeof r === 'string' && f && f.setError) { f.setError(r); last = was; } });
    };
    el.addEventListener('input', say);
    el.addEventListener('change', commit);
    el.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); commit(); } });
    const wrap = h('span', { class: 'cx-date' }, el, back);
    wrap.input = el;
    return wrap;
  };

  // Pills for a few choices (never a dropdown). opts: [[value, label, title?]]; onPick(value).
  K.pills = function (opts, value, onPick, o) {
    o = o || {};
    const g = h('div', { class: 'ap-pills', role: 'group', 'aria-label': o.label || null });
    opts.forEach(([v, label, tip]) => g.appendChild(h('button', {
      type: 'button', class: 'ap-pill', 'aria-pressed': String(String(value) === String(v)), title: tip || null, disabled: A.readonly || o.disabled,
      on: { click: e => { const me = e.currentTarget; g.querySelectorAll('.ap-pill').forEach(b => b.setAttribute('aria-pressed', String(b === me))); onPick(v); } }
    }, label)));
    return g;
  };

  // A section of a document screen: a heading with its count and one quiet action at the right.
  K.section = function (title, o, ...kids) {
    o = o || {};
    return h('section', { class: 'ap-section cx-sec', id: o.id || null, 'aria-label': typeof title === 'string' ? title : null },
      h('h2', { class: 'ap-h2' }, title, o.n != null ? h('span', { class: 'ap-h2__n', text: String(o.n) }) : null, o.act ? h('span', { class: 'ap-h2__act' }, o.act) : null),
      o.help ? h('p', { class: 'ap-help cx-sec__help', text: o.help }) : null, kids);
  };

  // A quiet text button ("+ Add card", "Change").
  K.link = (label, onClick, o) => h('button', { type: 'button', class: 'cx-link' + (o && o.danger ? ' cx-link--danger' : ''), title: o && o.title || null, disabled: A.readonly || (o && o.disabled), on: { click: onClick } }, o && o.icon ? A.icon(o.icon, 14) : null, label);

  // The facts table: label, value, action (the same layout on every screen).
  K.facts = function (rows) {
    return h('dl', { class: 'cx-facts' }, rows.filter(Boolean).map(([label, value, act]) => [
      h('dt', { text: label }), h('dd', null, h('span', { class: 'cx-facts__v' }, value == null || value === '' ? h('span', { class: 'ap-quiet', text: 'Not set' }) : value), act || null)
    ]));
  };

  /* ------------------------------------------------------------ carried from last year */

  // "From 2026 · Looks right" on a thing carried over and not checked yet. done() after it's pressed.
  K.looks = function (d, id, o) {
    o = o || {};
    if (!d.ov || d.coa.checks[id]) return null;
    const picked = d.picked || {};
    if (Array.isArray(picked.confirm) && picked.confirm.indexOf(id) < 0 && !o.always) return null;
    if (!picked.from) return null;
    const btn = A.btn('Looks right', { write: true, title: o.tip || 'Carried from ' + picked.from + ' · Checked by you', onClick: () => {
      btn.disabled = true;
      K.coa(d.year, 'check', { id, done: true }).then(() => { A.toast('Checked · ' + (o.what || 'Looks right'), { undo: () => K.coa(d.year, 'check', { id, done: false }).then(() => o.done && o.done()) }); if (o.done) o.done(); }, err => { btn.disabled = false; A.fail(err); });
    } });
    return h('div', { class: 'cx-from', role: 'note' }, h('span', { class: 'cx-from__t', text: 'From ' + picked.from }), o.line ? h('span', { class: 'ap-quiet', text: o.line }) : null, btn);
  };

  /* ------------------------------------------------------------ deciding, in the panel */

  // A decision in the record panel (or the body on a phone): the heading, what happens, what isn't done
  // (each a link when it can be), the act (one filled button), Cancel. o: { title, lines[], left[{t, go}],
  // act, actLabel, danger, reason, onDone, field }
  K.confirm = function (sp, o) {
    const reason = o.reason ? h('input', { class: 'ap-input', placeholder: 'Reason · Optional', 'aria-label': 'Reason', maxlength: '140' }) : null;
    const go = A.btn(o.actLabel, { primary: !o.danger, danger: o.danger, write: true, onClick: () => {
      go.disabled = true;
      Promise.resolve(o.act(reason ? reason.value.trim() : '')).then(r => { sp.close(true); if (o.onDone) o.onDone(r); }, err => { go.disabled = false; A.fail(err); });
    } });
    const body = h('div', { class: 'cx-decide' },
      (o.lines || []).map(l => h('p', { class: 'cx-decide__line' }, l)),
      o.field || null,
      o.left && o.left.length ? h('div', { class: 'cx-decide__left' }, h('span', { class: 'ap-label', text: 'Not done' }),
        h('ul', { class: 'cx-bullets' }, o.left.map(x => h('li', null, x.go ? K.link(x.t, () => { sp.close(true); x.go(); }) : x.t)))) : null,
      reason ? K.field('Reason', reason, { help: 'Kept in History' }) : null);
    sp.open({ title: o.title, body, foot: [go, A.btn('Cancel', { ghost: true, onClick: () => sp.close() })] });
    if (!K.wide()) window.scrollTo(0, 0);
    const t = sp.panel.querySelector('.ap-panel__title');
    if (t) { t.setAttribute('tabindex', '-1'); t.focus(); }
    sp.panel.setAttribute('role', 'dialog');
    sp.panel.setAttribute('aria-label', o.title);
  };

  /* ------------------------------------------------------------ files out */

  // A CSV that opens in Excel (admin-files.js: a BOM, formulas made harmless).
  K.download = (name, header, rows) => ED.files.download(name, header, rows);

  // A hidden file chooser: pick(accept) → Promise of the File.
  K.pick = function (accept) {
    return new Promise(res => {
      const i = h('input', { type: 'file', accept: accept || '.csv,.tsv,.txt,.xlsx', hidden: true });
      i.addEventListener('change', () => { res(i.files[0] || null); i.remove(); });
      document.body.appendChild(i); i.click();
    });
  };

  /* ------------------------------------------------------------ the keyboard, per screen */

  // ⌘Z / ⇧⌘Z for a screen's files, outside a text box (a text box keeps its own undo).
  K.undoKeys = function (fn) {
    const key = e => {
      if (!(e.metaKey || e.ctrlKey) || (e.key !== 'z' && e.key !== 'Z')) return;
      if (e.target.closest && e.target.closest('input, textarea, [contenteditable]')) return;
      if (document.querySelector('.ap-palette')) return;
      e.preventDefault();
      fn(e.shiftKey ? 'redo' : 'undo');
    };
    document.addEventListener('keydown', key);
    return () => document.removeEventListener('keydown', key);
  };
  // Undo or redo on a file, said in a toast; asks when someone else has changed the same field since.
  K.replay = function (f, dir) {
    const r = dir === 'redo' ? f.redo() : f.undo();
    if (!r) { A.toast(dir === 'redo' ? 'Nothing to redo' : 'Nothing to undo'); return; }
    if (r.blocked) {
      A.toast('Changed since by ' + (r.blocked[0].by || 'someone') + ' · ' + (dir === 'redo' ? 'Redo' : 'Undo') + ' anyway?', { undo: null });
      const t = document.querySelector('.ap-toast');
      if (t) t.appendChild(h('button', { type: 'button', text: dir === 'redo' ? 'Redo' : 'Undo', on: { click: () => { t.remove(); dir === 'redo' ? f.redo(true) : f.undo(true); } } }));
      return;
    }
    A.toast((dir === 'redo' ? 'Redone · ' : 'Undone · ') + r.label);
  };

  /* ------------------------------------------------------------ small pieces */

  // A place's name from its code ("Barnes Student Center", "Piazza Terrace (Barnes)").
  K.placeName = function (places, code) {
    const c = String(code || '').trim().toLowerCase();
    if (!c) return '';
    const p = places.find(x => String(x.code || '').toLowerCase() === c);
    return p ? (p.name || p.code) : '';
  };
  K.wide = () => matchMedia('(min-width: 1024px)').matches;
  // The public page for this screen, in a new tab (the real page, as visitors see it, plus what's
  // waiting: ?preview=1 shows members the working copy).
  K.see = (path, label) => h('a', { class: 'ap-btn ap-btn--ghost', href: (W.base || '/annual-conference/') + path, target: '_blank', rel: 'noopener', title: 'Opens the public page in a new tab' }, A.icon('eye'), label || 'Preview');
  K.loading = body => body.appendChild(h('div', { class: 'ap-quiet cx-loading', role: 'status', text: 'Loading' }));
  K.failed = (body, err) => { A.clear(body).appendChild(A.empty({ title: err && err.status === 403 ? 'No access' : 'Not loaded', line: err && err.status === 403 ? 'The COA’s · Ask the COA to hand it to your committee' : 'Reload the page', inset: true })); };
})();
