/*
 * committee-lodging.js — Lodging's year, shared by its screens in the app (Households, Rooms, Check-in,
 * Young Folks, Campers, Import). No drawing here: the data, the words and the saving.
 *
 * One load for the year (two requests side by side: the year's files, and Lodging's board with its
 * households: GET years/{y}/lodging?hh=1, which sends only what Lodging needs, never an email, a
 * medical note or a money total). Lodging's own rows live on the server, each with a version
 * (module-lodging.php): a change shows at once, is saved in order, and a refusal puts the board back
 * as the server has it and says why. Undo is the toast's; ⌘Z undoes this sitting's own last change;
 * Recent changes (any member's, with Undo) are on Rooms. Every 25 seconds the board catches up with
 * other members' changes (the board's rows only: the households come with the first load).
 *
 * window.OGC.lodging (L) keeps the API lodging-plan.js (the planner and the checks) reads.
 */
(function () {
  'use strict';
  const O = window.OGC, SU = O.signups, A = window.OGC_APP, K = window.OGC_CK, W = window.OGC_WP || {};

  const S = {
    year: 0, loaded: false, cfg: {}, settings: {}, rooms: [], floors: [], plans: {}, campus: null, roomBy: {},
    hh: [], byRid: {}, rows: {}, ver: {}, undo: [], phase: {}, me: '', seen: '', prev: null, prevYear: '', carry: null,
    numbers: null, imported: null, days: [], tz: 'America/Indiana/Indianapolis', ui: {}, pending: 0, asOf: '', row: null
  };
  const L = { S, SU, O, esc: O.esc, views: {}, plural: SU.plural };
  O.lodging = L;

  /* ================================================================ words */

  L.first = n => String(n || '').trim().split(/\s+/)[0];
  L.money = cents => SU.money((+cents || 0) / 100);
  L.md = iso => K.md(iso);
  L.when = at => K.at(at, S.tz);
  L.time = at => K.at(at, S.tz, false);
  L.since = at => {
    if (!at) return '';
    const d = String(at).slice(0, 10), days = O.daysBetween(d, S.phase.today || d);
    return days <= 6 && days >= 1 ? O.fmtDate(d, 'weekday') : L.md(d);
  };
  L.floorName = n => O.map ? O.map.floorName(n) : (+n === 1 ? 'Ground floor' : 'Floor ' + n);
  L.hallShort = x => String(x || '').replace(/\s+Hall$/i, '');
  L.roomWords = id => { const r = L.room(id); return r ? L.hallShort(r.hall) + ' ' + r.num : String(id).replace('|', ' '); };
  // "Carmin 209 and 210", "Reed 101–103", "Carmin 209 · Reed 101".
  L.roomsWords = ids => {
    const by = [];
    (ids || []).map(L.room).filter(Boolean).forEach(r => { let g = by.find(x => x.hall === r.hall); if (!g) by.push(g = { hall: r.hall, nums: [] }); g.nums.push(r.num); });
    return by.map(g => {
      const n = g.nums.slice().sort((a, b) => a - b), run = n.length > 2 && n.every((v, i) => !i || v === n[i - 1] + 1);
      return L.hallShort(g.hall) + ' ' + (run ? n[0] + '–' + n[n.length - 1] : n.length === 2 ? n.join(' and ') : n.join(', '));
    }).join(' · ');
  };
  L.nightSpan = ns => SU.nightSpan(ns || [], SU.nightsOf(S.cfg));
  // Nights only when they aren't the regular ones.
  L.someNights = ns => { const main = SU.mainNights(S.cfg); return ns && ns.length && ns.join('|') !== main.join('|') ? L.nightSpan(ns) : ''; };
  // Payment as the Form says it, or as the site's own ledger has it.
  L.payWords = x => {
    if (x.source === 'form') return x.formPay === 'paid' ? 'Paid · on the Form' : x.formPay === 'pending' ? 'Pending · on the Form' : x.formPay ? (x.formPayText || 'See the Form') + ' · on the Form' : '';
    const m = x.money;
    return m && m.due > 0 ? L.money(m.due) + (m.check >= m.due ? ' · check to come' : ' due') : m ? 'Paid' : '';
  };
  // What the desk should collect or ask about; '' when settled.
  L.owes = x => x.source === 'form' ? (x.formPay === 'pending' ? 'Pending · on the Form' : '') : (x.money && x.money.due > 0 ? L.payWords(x) : '');
  L.conf = () => S.year + ' Annual Conference';
  // Change (Round 5): the household's own form "for a household", in this tab, back to this address with
  // the household open (the form keeps only an app address: area-households-money H9).
  L.changeHref = x => {
    const a = new URLSearchParams(location.search).get('as-of');
    return new URL('../register/?year=' + S.year + '&view=edit&id=' + x.id + '&how=phone&return=' + encodeURIComponent(location.pathname + location.search) + (a ? '&as-of=' + encodeURIComponent(a) : ''), location.href).href;
  };

  /* ================================================================ households */

  const MOBILITY = /\b(walker|wheel\s?chair|scooter|cane|crutches|can'?t (do |climb |manage )?stairs|no stairs|knee|hip replacement)\b/i;
  const NOT = /\b(no|not|without|doesn'?t (need|use)) (a )?(walker|wheel\s?chair|scooter|cane)\b/i;
  function norm(d) {
    const s = d.stay || {}, people = (d.people || []).filter(p => p.name);
    const kind = p => p.kind || (p.yf ? 'yf' : p.band === 'adult' && !p.preteen ? 'adult' : 'child');
    const inHall = p => !!p.yf && (s.type === 'yf' || p.sleeps !== 'family');
    const adults = people.filter(p => kind(p) === 'adult');
    const sur = String((d.household && d.household.name) || '').replace(/^the\s+/i, '').replace(/\s+(family|household)$/i, '').trim() || String(d.household && d.household.contact || '').split(/\s+/).pop() || 'Household';
    const firsts = adults.map(p => L.first(p.name));
    const fl = firsts.length ? (firsts.length === 1 ? firsts[0] : firsts.slice(0, -1).join(', ') + ' and ' + firsts[firsts.length - 1]) : '';
    const note = String(s.needs || '').trim();
    // docs/25: needs are the household's own boxes; the note is for people and never read here.
    const mob = false && MOBILITY.test(note) && !NOT.test(note);
    return {
      rid: String(d.rid || ''), id: +d.id || 0, d, sur, firsts: fl,
      label: sur + (fl ? ' · ' + fl : ''),
      short: (firsts[0] ? firsts[0].charAt(0) + '. ' : '') + sur,
      type: s.type || 'dorm', status: d.status || 'registered',
      active: (s.type || 'dorm') === 'dorm' && d.status !== 'cancelled',
      gone: d.status === 'cancelled',
      people, adults, kind, inHall,
      inRooms: people.filter(p => !inHall(p)), yfs: people.filter(inHall),
      sleepers: people.filter(p => !inHall(p) && p.band !== 'baby'),
      nights: s.nights || [], asked: s.type === 'dorm' ? Math.max(1, +s.rooms || 1) : 0,
      ground: !!s.ground, walker: !!s.walker || mob, walkerFromNote: !s.walker && mob,
      nearW: !!s.nearW, nearM: !!s.nearM, restroom: !!s.restroom, cribs: people.filter(p => p.crib).length, nearText: String(s.near || '').trim(), note,
      linens: +s.linens || 0, mattresses: +s.mattresses || 0,
      source: d.source || 'online', at: d.created || '', updated: d.updated || '', sample: !!d.sample,
      money: d.money || null, phone: (d.household && d.household.phone) || '', email: d.ek || '',
      formPay: d.source === 'form' ? String((d.form && d.form.pay) || '') : '', formPayText: String((d.form && d.form.payText) || ''),
      formProblems: (d.form && d.form.problems) || [], oldest: +(d.form && d.form.oldest) || 0
    };
  }
  L.norm = norm;
  function buildHouseholds(list) {
    S.hh = (list || []).map(norm).filter(x => x.rid).sort((a, b) => a.sur.localeCompare(b.sur) || a.firsts.localeCompare(b.firsts));
    S.byRid = {};
    S.hh.forEach(x => { S.byRid[x.rid] = x; });
    const n = {};
    S.hh.forEach(x => { n[x.sur] = (n[x.sur] || 0) + 1; });
    S.hh.forEach(x => { x.common = n[x.sur] > 1; });
  }
  L.byRid = rid => S.byRid[rid] || null;
  L.dorm = () => S.hh.filter(x => x.active);

  /* ================================================================ Lodging's rows */

  L.data = key => (S.rows[key] && S.rows[key].data) || null;
  L.hrow = x => L.data('hh:' + (x && x.rid || x)) || {};
  // A household's rooms: Lodging's; else, when the COA lets households choose, the rooms they chose
  // (polish: the board never read them, so Assign all could give a chosen room to someone else).
  L.given = x => {
    const r = L.hrow(x);
    if (r.rooms && r.rooms.length) return r.rooms.filter(id => L.room(id));
    const hx = typeof x === 'string' ? L.byRid(x) : x;
    if (S.cfg.room_choice === 'households' && hx && hx.active && hx.d.stay && (hx.d.stay.chosen || []).length) return hx.d.stay.chosen.filter(id => L.room(id));
    return [];
  };
  L.chosenByHousehold = x => !(L.hrow(x).rooms || []).length && L.given(x).length > 0;
  L.older = x => !!L.hrow(x).older;
  L.firstGroup = x => x.walker || x.ground || L.older(x);
  L.fact = id => Object.assign({}, (S.carry && S.carry.rooms && S.carry.rooms[id]) || {}, L.data('room:' + id) || {});
  L.room = id => S.roomBy[id] || null;
  L.beds = id => +(L.fact(id).beds) || (L.room(id) || {}).beds || 2;
  L.assign = () => { const a = {}; L.dorm().forEach(x => { const g = L.given(x); if (g.length) a[x.rid] = g; }); return a; };
  L.taken = except => {
    const t = {};
    L.dorm().forEach(x => { if (x.rid !== except) L.given(x).forEach(id => { t[id] = x.rid; }); });
    Object.keys(S.rows).forEach(k => { if (/^yf:/.test(k) && S.rows[k].data && S.rows[k].data.room) t[S.rows[k].data.room] = 'yf'; });
    return t;
  };

  /* ================================================================ when things happen */

  L.nightDate = n => {
    if (SU.isEarly(n)) return SU.earlyDate(n, S.days[0] && S.days[0].date);
    const d = S.days.find(x => x.name.slice(0, 3).toLowerCase() === String(n).slice(0, 3).toLowerCase());
    return d ? d.date : '';
  };
  L.arrive = ns => ns && ns.length ? L.nightDate(ns[0]) : '';
  L.depart = ns => { const d = ns && ns.length ? L.nightDate(ns[ns.length - 1]) : ''; return d ? O.isoAddDays(d, 1) : ''; };
  L.today = () => S.phase.today || '';
  L.stamp = () => O.wallNow(S.tz).date;

  /* ================================================================ listeners */

  const subs = new Set();
  L.on = fn => { subs.add(fn); return () => subs.delete(fn); };
  const changed = why => subs.forEach(fn => { try { fn(why); } catch (e) { console.error(e); } });
  L.notify = changed;

  /* ================================================================ the server */

  const asOfQ = () => S.asOf ? 'as_of=' + S.asOf : '';
  // The shared prototype is each visitor's own copy, so its dated scenes may save.
  const protoSaves = !!(window.OGC_WP && window.OGC_WP.prototype);
  L.api = (method, path, body) => {
    let p = '/years/' + S.year + '/lodging' + path;
    if ((method === 'GET' || protoSaves) && asOfQ()) p += (p.includes('?') ? '&' : '?') + asOfQ();
    return A.api(method, p, body);
  };
  // Who may change things here and now: never while seeing as, previewing a date, or after the names are cleared.
  L.blocked = late => A.readonly ? 'Read only while seeing as' : (S.asOf && !protoSaves) ? 'Preview · Not saved' : S.phase.cleared ? 'Names cleared · No changes' : (L.ro && !late) ? 'Conference over · Desk only' : '';

  let chain = Promise.resolve();
  const pend = {};
  const take = rows => Object.keys(rows || {}).forEach(k => {
    const r = rows[k];
    S.ver[k] = r ? r.v : 0;
    if (pend[k]) return;
    if (r) S.rows[k] = r; else delete S.rows[k];
  });
  L.take = take;
  // Change rows together: shown at once, saved in order. ops: [{ key, data }] (data null removes).
  // o: { label (the toast and the change's name), toast, silent, late (desk or notes after the
  // Conference), done(res) }.
  L.save = function (ops, o) {
    o = o || {};
    const no = L.blocked(o.late);
    if (no) { A.toast(no); return Promise.resolve(false); }
    const before = {};
    ops.forEach(op => {
      before[op.key] = S.rows[op.key] || null;
      pend[op.key] = (pend[op.key] || 0) + 1;
      if (op.data == null) delete S.rows[op.key];
      else S.rows[op.key] = { data: op.data, v: S.ver[op.key] || 0, by: S.me, at: '' };
    });
    S.pending++;
    changed('local');
    const run = () => {
      const body = ops.map(op => ({ key: op.key, data: op.data == null ? null : op.data, v: S.ver[op.key] || 0 }));
      return L.api('POST', '/ops', { ops: body, label: o.label || '' }).then(res => {
        ops.forEach(op => { pend[op.key]--; });
        take(res.rows);
        if (res.undo) { res.undo.at = new Date().toISOString(); res.undo.sitting = true; S.undo.unshift(res.undo); S.undo = S.undo.slice(0, 20); }
        S.pending--;
        if (o.label && !o.silent) A.toast(o.toast || o.label, res.undo ? { undo: () => L.undoLast(res.undo.id) } : null);
        if (o.done) o.done(res);
        changed('saved');
        return true;
      }, err => {
        ops.forEach(op => { pend[op.key]--; });
        S.pending--;
        const rows = err.data && err.data.data && err.data.data.rows;
        Object.keys(before).forEach(k => { if (!pend[k]) { if (before[k]) S.rows[k] = before[k]; else delete S.rows[k]; } });
        if (rows) take(rows);
        const m = (err.data && err.data.message) || err.message || '';
        A.toast(err.status === 409 ? (m || 'Changed by another member · Reload') : err.status === 403 ? (m || 'Not allowed') : err.status ? 'Not saved · ' + (m || 'Retry') : 'Offline · Not saved');
        changed('error');
        if (err.status === 409) refresh(true);
        return false;
      });
    };
    chain = chain.then(run, run);
    return chain;
  };
  L.hhSave = (x, change, o) => {
    const cur = Object.assign({}, L.hrow(x));
    Object.keys(change).forEach(k => { if (change[k] == null || change[k] === false) delete cur[k]; else cur[k] = change[k]; });
    if (cur.rooms && !cur.rooms.length) delete cur.rooms;
    return L.save([{ key: 'hh:' + x.rid, data: Object.keys(cur).length ? cur : null }], o);
  };
  L.undoLast = function (id) {
    const u = id ? S.undo.find(x => x.id === id) || { id, label: '' } : S.undo.find(x => x.mine && x.sitting);
    if (!u) { A.toast('Nothing to undo'); return; }
    const no = L.blocked(true);
    if (no) { A.toast(no); return; }
    S.pending++;
    L.api('POST', '/undo', { id: u.id }).then(res => {
      S.pending--;
      S.undo = S.undo.filter(x => x.id !== u.id);
      take(res.rows);
      const m = /^(Check-in|Keys back|Keys out) · (.+)$/.exec(res.label || u.label || '');
      A.toast(m ? m[1] + ' undone · ' + m[2] : 'Undone · ' + (res.label || u.label || ''));
      changed('saved');
    }, err => { S.pending--; A.toast((err.data && err.data.message) || 'Can’t undo'); refresh(true); });
  };

  // Other members' changes: every 25 seconds while a Lodging screen is open and the tab in view.
  let lastPoll = 0, timer = 0, users = 0;
  function refresh(force) {
    if (!S.loaded || (S.pending && !force) || (document.hidden && !force)) return Promise.resolve();
    lastPoll = Date.now();
    return L.api('GET', '').then(B => {
      const news = [];
      Object.keys(B.rows || {}).forEach(k => {
        const r = B.rows[k], old = S.rows[k];
        if ((!old || old.v !== r.v) && r.by && r.by !== S.me && /^hh:/.test(k)) { const x = L.byRid(k.slice(3)); if (x) news.push([r.by, x]); }
      });
      S.rows = Array.isArray(B.rows) ? {} : (B.rows || {});
      S.ver = {};
      Object.keys(S.rows).forEach(k => { S.ver[k] = S.rows[k].v; });
      const sat = new Set(S.undo.filter(x => x.sitting).map(x => x.id));
      S.undo = (B.undo || []).map(x => sat.has(x.id) ? Object.assign(x, { sitting: true }) : x);
      S.imported = B.import;
      S.phase = B.phase || S.phase;
      if (B.sent) S.sent = B.sent;
      // Another member's change says what it was: its own label from Recent changes ("Sarah C. · Crane · Older").
      if (news.length && !force) {
        const u = S.undo.find(x => !x.mine);
        A.toast(news.length === 1 ? news[0][0] + ' · ' + (u && u.label ? u.label : news[0][1].sur) : news[0][0] + ' · ' + SU.plural(news.length, 'change'));
      }
      changed('remote');
    }).catch(() => { /* next time */ });
  }
  L.refresh = refresh;
  // Households again (an import, a new registration): the board with them.
  L.reloadHouseholds = () => L.api('GET', '?hh=1').then(B => { buildHouseholds(B.households); S.rows = Array.isArray(B.rows) ? {} : (B.rows || {}); S.ver = {}; Object.keys(S.rows).forEach(k => { S.ver[k] = S.rows[k].v; }); S.imported = B.import; changed('remote'); });
  // A screen in use keeps the board fresh; the last to close stops it.
  L.use = () => {
    users++;
    if (!timer) timer = setInterval(() => { if (Date.now() - lastPoll > 24000) refresh(); }, 5000);
    return () => { users = Math.max(0, users - 1); if (!users) { clearInterval(timer); timer = 0; } };
  };
  document.addEventListener('visibilitychange', () => { if (users && !document.hidden && Date.now() - lastPoll > 10000) refresh(); });
  document.addEventListener('keydown', e => {
    if (!users || !(e.metaKey || e.ctrlKey) || e.shiftKey || e.key.toLowerCase() !== 'z') return;
    if (e.target.matches && e.target.matches('input, textarea')) return;
    e.preventDefault(); L.undoLast();
  });
  window.addEventListener('beforeunload', e => { if (S.pending) { e.preventDefault(); e.returnValue = ''; } });

  /* ================================================================ the year */

  let loading = null;
  // The year, loaded once for every Lodging screen (again only for another year or when asked).
  L.load = function (year, fresh) {
    year = +year;
    const asOf = (new URLSearchParams(location.search).get('as-of') || '').slice(0, 10);
    if (!fresh && loading && S.year === year && S.asOf === asOf) return loading;
    S.year = year; S.asOf = /^\d{4}-\d\d-\d\d$/.test(asOf) ? asOf : ''; S.loaded = false;
    loading = Promise.all([K.bundle(year, fresh), L.api('GET', '?hh=1')]).then(([F, B]) => {
      S.settings = K.kv(F.settings);
      S.cfg = SU.settings(F.registration || []);
      S.tz = S.settings.timezone || 'America/Indiana/Indianapolis';
      if (O.map) {
        const c = O.map.campus(F.campus || []);
        S.campus = c.items.length ? c : null;
        S.plans = O.map.plans(F.plans || []);
      }
      const R = SU.readRooms(F.rooms || []);
      S.rooms = R.rooms; S.floors = R.floors;
      if (O.map) O.map.orderFloors(S.floors, S.plans);
      S.roomBy = {};
      S.rooms.forEach(r => { S.roomBy[r.id] = r; });
      Object.assign(S, { rows: Array.isArray(B.rows) ? {} : (B.rows || {}), undo: B.undo || [], phase: B.phase || {}, me: B.me || '', seen: B.seen || '', prev: B.prev, prevYear: String(B.prev_year || year - 1), carry: B.carry, numbers: B.numbers, imported: B.import,
        // Counts' sends, each with its kept copy; who they may go to; when they're due (Round 5).
        sent: B.sent || [], sendTo: B.send_to || [], countsDue: B.counts_due || '' });
      S.ver = {};
      Object.keys(S.rows).forEach(k => { S.ver[k] = S.rows[k].v; });
      S.days = K.days(S.phase.start, S.phase.end);
      L.ro = !!S.phase.held;
      buildHouseholds(B.households || []);
      S.loaded = true;
      lastPoll = Date.now();
      return L;
    });
    loading.catch(() => { loading = null; });
    return loading;
  };

  /* ================================================================ things every screen says */

  // A household's requests as tags: "Step-free", "Near Dale and Ann Miller".
  L.tagsOf = x => {
    const c = L.nearCands ? L.nearCands(x) : [];
    return [x.walker ? (x.walkerFromNote ? 'Step-free (from their note)' : 'Step-free') : '', x.ground ? 'Ground floor' : '', x.nearW ? 'Near women’s restroom' : '', x.nearM ? 'Near men’s restroom' : '', x.restroom && !x.nearW && !x.nearM ? 'Near a restroom' : '', x.cribs ? SU.plural(x.cribs, 'crib') : '',
      x.nearText ? 'Near ' + (c.length === 1 ? c[0].sur + (c[0].firsts ? ' · ' + c[0].firsts : '') : x.nearText.replace(/^near\s+/i, '')) : ''].filter(Boolean);
  };
  L.metaList = x => {
    const yf = x.yfs.length, n = x.inRooms.length;
    // One phrasing: "3 people" (Young Folks said apart).
    return [SU.plural(x.active && yf ? n : (n || x.people.length), 'person', 'people'), yf ? SU.plural(yf, 'Young Folk') : '', x.active ? SU.plural(x.asked, 'room') : '', L.someNights(x.nights), x.source === 'form' ? 'Form' : x.source === 'desk' ? 'Desk' : ''];
  };
  L.metaOf = x => L.metaList(x).filter(Boolean).join(' · ');
  L.where = x => {
    if (!x.active) return x.gone ? 'Cancelled' : x.type === 'camper' ? 'Camper lot' : x.type === 'yf' ? 'Young Folks halls' : 'Off campus';
    const g = L.given(x);
    return g.length ? L.roomsWords(g) : 'Unassigned';
  };
  // One search over every household and every person in it, a registration number, a phone's last digits, a room.
  L.search = f => {
    f = String(f || '').trim().toLowerCase();
    if (!f) return S.hh.slice();
    const digits = f.replace(/\D/g, '');
    return S.hh.filter(x => (x.label + ' ' + x.rid).toLowerCase().indexOf(f) > -1 ||
      x.people.some(p => p.name.toLowerCase().indexOf(f) > -1) ||
      (digits.length >= 3 && x.phone.replace(/\D/g, '').slice(-digits.length) === digits) ||
      L.given(x).some(id => L.roomWords(id).toLowerCase().indexOf(f) > -1));
  };
  // Every Young Folk staying in a hall: { p, h, pid, key: 'men'|'women'|'' }.
  L.everyYf = () => {
    const out = [];
    S.hh.filter(x => !x.gone).forEach(x => x.yfs.forEach(p => out.push({ p, h: x, pid: p.pid || (x.rid + ':' + p.name), key: p.yfHall || '' })));
    return out;
  };

  // The screens that need the year draw "Loading" first, then themselves, and again on every change.
  L.screen = function (ctx, draw) {
    const off = [];
    K.loading(ctx);
    let alive = true;
    L.load(ctx.params.year).then(() => {
      if (!alive) return;
      off.push(L.use());
      if (S.phase.cleared && draw.held !== false) { L.held(ctx); return; }
      draw(ctx);
      off.push(L.on(why => { if (alive) draw(ctx, why); }));
    }).catch(err => { if (alive) K.failed(ctx, err); });
    return () => { alive = false; off.forEach(f => f()); };
  };

  // A year whose names are cleared: its counts, to print and keep.
  L.held = function (ctx) {
    const N = S.numbers || {}, P = S.phase, halls = Object.keys(N.by_hall || {}), h = A.h;
    ctx.head(A.screens()[ctx.params.s] ? (A.screens()[ctx.params.s].title || 'Lodging') : 'Lodging', 'Names cleared ' + K.md(P.clear), halls.length ? [A.btn('Print', { icon: 'file', onClick: () => K.print({ title: 'Lodging · The year in counts', who: 'Lodging only', build: () => countsTable(N, halls) }) })] : []);
    const totals = [[N.households, 'households in dorm rooms'], [N.rooms, 'rooms given'], [(N.linens || 0) + (N.yf_linens || 0), 'linen packets'], [N.mattresses, 'air mattresses'], [N.yf_rooms, 'Young Folks rooms']].filter(x => x[0]);
    A.clear(ctx.body).append(...[
      h('p', { class: 'ap-quiet', text: O.fmtDateSpan(N.start || P.start, N.end || P.end) }),
      totals.length ? h('div', { class: 'cm-stats' }, totals.map(x => h('div', { class: 'cm-stat' }, h('b', { text: String(x[0]) }), h('span', { text: x[1] })))) : A.empty({ title: 'Counts only', line: 'Nothing was kept for this year' }),
      halls.length ? countsTable(N, halls) : null].filter(Boolean));
  };
  function countsTable(N, halls) {
    const h = A.h;
    return h('table', { class: 'cm-table' }, h('thead', null, h('tr', null, h('th', { text: 'Night' }), halls.map(x => h('th', { class: 'is-num', text: L.hallShort(x) + ' · rooms' })), h('th', { class: 'is-num', text: 'Campers' }))),
      h('tbody', null, (N.nights || []).map(n => h('tr', null, h('td', { text: n }), halls.map(x => h('td', { class: 'is-num', text: String(((N.per_night || {})[n] || {})[x] || '') })), h('td', { class: 'is-num', text: String((N.campers || {})[n] || '') })))));
  }
})();
