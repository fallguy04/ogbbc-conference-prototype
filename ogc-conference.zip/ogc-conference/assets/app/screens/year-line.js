/*
 * year-line.js — the year as a line (Round 2, Oct 16; docs/27 README 12): the kit a committee's page and
 * Home draw with. window.OGC_APP.yl:
 *
 *   YL.stages(items, today)      group a committee's rows into stages by their own days (mechanical: a
 *                                screen's season, the round's span, a task's due date), each above or
 *                                below Today
 *   YL.stage(o), YL.today(day)   one stage of the line (its gutter date, its dot, its rows); the Today mark
 *   YL.row(o)                    a Work row: icon · name · fact · act · ›
 *   YL.task(ctx, t, o)           a task on the line: Done box · title (opens it) · its date
 *   YL.fill(label, to), YL.at(label, to | fn)   the one filled button; a quiet act in tan words
 *   YL.lab(title, n, right)      a section's label
 *
 * Every row's words come from the server (module-app-line.php), which counts with the same functions the
 * screens it opens use; nothing here works a number out. Nothing anyone typed goes into innerHTML.
 */
(function () {
  'use strict';
  const A = window.OGC_APP, h = A.h;
  const YL = A.yl = {};
  const MON = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'];
  const month = iso => iso ? iso.slice(0, 7) : '';
  const monName = iso => MON[+iso.slice(5, 7) - 1] || '';
  const dayName = iso => monName(iso) + ' ' + (+iso.slice(8, 10));
  YL.md = iso => iso ? A.fmt.md(iso) : '';
  YL.dayName = dayName;
  YL.monName = monName;

  const TICK = () => { const s = A.icon('overview', 10); s.querySelector('path').setAttribute('d', 'M3.5 8.5 6.5 11.5 12.5 4.5'); s.setAttribute('stroke-width', '2.4'); return s; };
  YL.tick = TICK;

  /* ------------------------------------------------------------ small parts */

  YL.lab = (title, n, right, tag) => h('div', { class: 'yl-lab' }, h(tag || 'h2', { text: title }), n !== undefined && n !== '' && n !== null ? h('span', { class: 'yl-n', text: String(n) }) : null, right || null);
  // The one filled button of a view: a door (to) or an act (fn).
  YL.fill = (label, to, o) => {
    o = o || {};
    if (typeof to === 'function') {
      const b = h('button', { type: 'button', class: 'yl-fill' + (o.sm ? ' sm' : ''), disabled: o.write && A.readonly, title: o.write && A.readonly ? 'Read only while seeing as' : o.title || null, on: { click: to } }, o.icon ? A.icon(o.icon) : null, label);
      return b;
    }
    return A.link(to, [o.icon ? A.icon(o.icon) : null, label], 'yl-fill' + (o.sm ? ' sm' : ''));
  };
  // A quiet act in tan words: a door, or an act done here (greyed while seeing as when it writes).
  YL.at = (label, to, o) => {
    o = o || {};
    if (typeof to === 'function') return h('button', { type: 'button', class: 'yl-at' + (o.sm ? ' sm' : ''), disabled: o.write && A.readonly, title: o.write && A.readonly ? 'Read only while seeing as' : o.title || null, on: { click: to } }, label);
    const a = A.link(to, label, 'yl-at' + (o.sm ? ' sm' : ''));
    if (o.title) a.title = o.title;
    return a;
  };
  const chev = () => h('span', { class: 'yl-chev', 'aria-hidden': 'true' }, A.icon('chev', 14));

  /* ------------------------------------------------------------ the line */

  // o: { when (text or node), state: done|open|later|end|home, dated, last, rows: [nodes], label }
  YL.stage = o => {
    const dot = h('span', { class: 'yl-dot', 'aria-hidden': 'true' }, o.state === 'done' ? TICK() : null);
    return h('div', { class: 'yl-stage is-' + (o.state || 'later') + (o.dated ? ' is-dated' : '') + (o.last ? ' is-last' : ''), 'data-stage': o.key || '', 'data-start': o.start || '', 'aria-label': o.label || null, role: o.label ? 'group' : null },
      h('div', { class: 'yl-when' }, o.when), h('div', { class: 'yl-track' }, dot, o.rows || []));
  };
  YL.today = day => h('div', { class: 'yl-today', 'data-today': day || '', role: 'separator', 'aria-label': 'Today, ' + YL.md(day) },
    h('div', { class: 'yl-when' }, 'Today', h('b', { text: YL.md(day) })),
    h('div', { class: 'yl-track' }, h('i', { class: 'yl-tline', 'aria-hidden': 'true' }), h('span', { class: 'yl-dot', 'aria-hidden': 'true' })));

  // A Work row. o: { id, icon, title, to, fact (text), factNeed (bool: tan), tag, act (node), done, big }
  YL.row = o => {
    const name = A.link(o.to, o.title, 'yl-nm');
    if (o.tag) name.appendChild(h('span', { class: 'yl-tagsq', text: o.tag }));
    const row = h('div', { class: 'yl-row' + (o.done ? ' is-done' : '') + (o.big ? ' is-big' : ''), 'data-row': o.id || '', 'data-go': A.href(o.to) },
      A.icon(o.icon || 'overview'), name,
      h('span', { class: 'yl-fact' + (o.factNeed ? ' yl-need' : '') }, o.fact || ''),
      h('span', { class: 'yl-act' }, o.act || null), chev());
    // The whole row opens its screen; the act inside does its own thing.
    row.addEventListener('click', e => { if (!e.target.closest('a,button,input')) name.click(); });
    return row;
  };

  // For next year's rows: no chevron, the act opens a fold under the row.
  YL.nextRow = o => h('div', { class: 'yl-row is-next', 'data-row': o.id || '' }, A.icon(o.icon || 'note'), h('span', { class: 'yl-nm', text: o.title }),
    h('span', { class: 'yl-fact', text: o.fact || '' }), h('span', { class: 'yl-act' }, o.act || null));

  // Folded: screens not open yet that open the same day ("Households · Rooms · Youngfolks · Campers").
  YL.listRow = (rows, fact) => h('div', { class: 'yl-lrow', 'data-row': rows.map(r => r.id).join(' ') },
    rows.map((r, i) => [i ? h('span', { class: 'yl-sep', 'aria-hidden': 'true', text: '·' }) : null, A.link(r.to, r.title)]), h('span', { class: 'yl-meta', text: fact }));

  // A task on the line: the Done box (a tied task ticks itself on its screen), its title opening it on
  // Tasks, Late in red, its date.
  YL.task = (ctx, t, o) => {
    o = o || {};
    const box = h('input', { type: 'checkbox', 'aria-label': 'Done: ' + t.title, disabled: !o.canWrite || !!t.auto, title: t.auto ? 'Ticks itself on its screen' : null });
    box.addEventListener('change', () => A.toggleTask(ctx, Object.assign({ done: false }, t), box));
    return h('div', { class: 'yl-trow', 'data-task': String(t.id) }, box,
      h('span', { class: 'yl-tt' }, A.link({ s: 'tasks', id: t.id, c: '', v: '' }, t.title), t.auto ? h('span', { class: 'yl-meta', text: 'Ticks itself' }) : null, t.late ? A.tag('Late', 'late') : null),
      h('span', { class: 'yl-meta', text: t.when || '' }));
  };

  /* ------------------------------------------------------------ grouping a committee's year */

  /*
   * items: [{ kind: 'screen' | 'task' | 'next', on, until, due, done, ... }]. A stage gathers the screens
   * that come into season in one month ("all" for those open all year), then each task joins the stage
   * whose months hold its due date (else a stage of its own month). For next year is always the last.
   * A stage is above Today once its first day has come. Returns [{ key, start, end, items, open, done }].
   */
  YL.stages = (items, today) => {
    const by = {};
    const get = key => by[key] || (by[key] = { key, items: [], days: [] });
    items.filter(x => x.kind !== 'task').forEach(x => {
      const st = get(x.kind === 'next' ? 'next' : x.on ? month(x.on) : 'all');
      st.items.push(x);
      if (x.on) st.days.push(x.on);
      if (x.until) st.days.push(x.until);
    });
    const span = st => {
      const d = st.days.slice().sort();
      return d.length ? [month(d[0]), month(d[d.length - 1])] : null;
    };
    items.filter(x => x.kind === 'task').forEach(t => {
      if (!t.due) { get('all').items.push(t); return; }
      const m = month(t.due);
      const hit = Object.values(by).filter(st => st.key !== 'all' && span(st) && span(st)[0] <= m && m <= span(st)[1])
        .sort((a, b) => (span(b)[0] > span(a)[0] ? 1 : -1))[0];
      const st = hit || get(m);
      st.items.push(t);
      st.days.push(t.due);
    });
    const list = Object.values(by).map(st => {
      const d = st.days.slice().sort();
      return Object.assign(st, { start: st.key === 'all' ? '' : d[0] || '', end: d[d.length - 1] || '' });
    });
    list.sort((a, b) => a.key === 'all' ? -1 : b.key === 'all' ? 1 : a.key === 'next' ? 1 : b.key === 'next' ? -1 : (a.start < b.start ? -1 : a.start > b.start ? 1 : 0));
    list.forEach(st => {
      st.open = st.key === 'all' || (!!st.start && st.start <= today);
      st.done = st.items.length > 0 && st.items.every(x => x.done);
      // The gutter's words: one day ("FEB 25"), one month ("MAY"), or the months it runs ("OCT – NOV").
      const one = st.days.length && st.days.every(d => d === st.days[0]);
      st.when = st.key === 'all' ? 'All year' : one ? dayName(st.start) : month(st.start) === month(st.end) ? monName(st.start) : monName(st.start) + ' – ' + monName(st.end);
    });
    return list;
  };
})();
