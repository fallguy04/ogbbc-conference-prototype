/*
 * coa-years.js — Years, for the webmasters: every Conference on the site, what's public of each, and
 * the jobs that carry the site from year to year while each COA turns over:
 *   - Start the next year (one ahead only; it picks itself up from the last one once that's over), and
 *     Remove it again while nothing's been done in it;
 *   - Export a year's files as one zip (its spreadsheets, never anyone's record) for the Scheduling
 *     Committee to hand on;
 *   - the webmasters themselves: adding or removing one is asked by one and confirmed by a second;
 *   - the year's Activity.
 * Who signs in for a year is Access (the frame's Members screen). This replaces the frame's plain list.
 */
(function () {
  'use strict';
  const A = window.OGC_APP, K = window.OGC_COA, O = window.OGC, W = window.OGC_WP || {};
  if (!A || !K) return;
  const h = A.h;

  A.screen({
    id: 'years', title: 'Years', icon: 'years', section: 'own', who: ['webmaster'],
    render(ctx) {
      let alive = true;
      ctx.head('Years', '', []);
      K.loading(ctx.body);
      const draw = () => Promise.all([K.api('GET', 'years'), K.api('GET', 'webmasters').catch(() => null), K.api('GET', 'years/' + ctx.params.year + '/webinfo').catch(() => null)])
        .then(([years, web, info]) => { if (alive) page(ctx, years, web, info, draw); }, err => { if (alive) K.failed(ctx.body, err); });
      draw();
      return () => { alive = false; };
    }
  });

  function page(ctx, years, web, info, again) {
    const boot = ctx.boot, today = new Date().toISOString().slice(0, 10);
    const ro = !!A.readonly;
    const withData = years.filter(y => y.data).sort((a, b) => b.year - a.year);
    const upcoming = withData.slice().reverse().find(y => !y.end || y.end >= today) || null;
    const newest = withData[0];
    const next = newest && (+newest.year + 1) <= (upcoming ? +upcoming.year + 1 : +newest.year + 1) ? String(+newest.year + 1) : '';
    const nextRow = years.find(y => y.year === next);
    const acts = [];
    if (next && !ro) acts.push(A.btn('Start ' + next, { primary: true, write: true, icon: 'plus', title: 'Picks up from ' + newest.year + ' once it’s over', onClick: () => start(next) }));
    // Every row counted, newest first (a year only announced is a row too).
    const rows = withData.concat(nextRow && !nextRow.data ? [nextRow] : []).sort((a, b) => b.year - a.year);
    ctx.head('Years', K.plural(rows.length, 'year') + (upcoming ? ' · Next: ' + upcoming.year : ''), acts);
    A.clear(ctx.body);
    const sp = ctx.split();
    sp.el.classList.add('cx-split');
    const doc = h('div', { class: 'cx-list' });
    sp.main.appendChild(doc);

    // One word, one meaning: "Hosts named" is years.csv's announcement of the hosts; "Announced" is the
    // COA's announcement that opens the Conference page.
    const pubOf = y => [y.coa_announced && y.coa_announced <= today ? 'Announced' : '', y.status_word === 'Registration open' ? 'Registration open' : '', y.recordings ? 'Recordings' : ''].filter(Boolean);
    const nowWord = y => y.status_word === 'Announced' || !y.status_word ? (y.data ? 'Started' : 'Hosts named') : y.status_word;
    const tb = h('tbody', null, rows.map(y => h('tr', { 'data-key': y.year, 'aria-selected': String(String(y.year) === String(ctx.params.id)), tabindex: '-1', on: { click: () => openYear(y) } },
      h('td', null, h('span', { class: 'ap-cell-title', text: y.year }), h('span', { class: 'ap-cell-sub', text: y.hosts || '' })),
      h('td', { class: 'ap-td--nowrap' }, y.start ? O.fmtDateSpan(y.start, y.end) : h('span', { class: 'ap-quiet', text: 'Dates not set' })),
      h('td', { class: 'ap-td--wide' }, y.venue || ''),
      h('td', { class: 'ap-td--wide' }, h('span', { class: 'cx-marks' }, [h('span', { class: 'ap-tag' + (y.status_word === 'Past' ? '' : ' ap-tag--tan'), text: nowWord(y) })].concat(pubOf(y).filter(x => x !== y.status_word).map(x => A.tag(x))))),
      // The year you're in is marked; any other opens by name ("Open 2028").
      h('td', { class: 'ap-td--num ap-td--nowrap' }, !y.data ? '' : String(y.year) === String(boot.year) ? h('span', { class: 'ap-quiet', text: 'Current' }) : A.link({ year: y.year, s: 'home', id: '' }, 'Open ' + y.year, 'ap-link')))));
    doc.appendChild(h('div', { class: 'ap-tablewrap' }, h('table', { class: 'ap-table', 'aria-label': 'Years' },
      h('thead', null, h('tr', null, ['Year', 'Dates', 'Campus', 'Now', ''].map((t, i) => h('th', { scope: 'col', class: i === 2 || i === 3 ? 'ap-td--wide' : i === 4 ? 'ap-td--num' : null, text: t })))), tb)));

    /* -------------------------------------------------------- webmasters */
    if (web) {
      const list = h('ul', { class: 'ap-list' }, web.list.map(w => h('li', null, h('div', { class: 'ap-item' }, A.face(w.name || String(w.email || '').split('@')[0], w.me),
        h('span', { class: 'ap-item__main' }, h('span', { class: 'ap-item__title', text: (w.name || w.email) + (w.me ? ' (you)' : '') }), h('span', { class: 'ap-item__why', text: w.admin ? 'Site admin' : w.last ? 'Signed in ' + K.md(w.last.slice(0, 10)) : 'Not signed in yet' })),
        !ro && !w.admin && !w.me ? K.link('Remove', () => ask(w.email, 'remove', w.name || w.email), { danger: true }) : null))));
      const asks = (web.asks || []).map(a => h('div', { class: 'cx-from' }, h('span', { class: 'cx-from__t', text: (a.act === 'remove' ? 'Remove ' : 'Add ') + (a.name || a.email) }), h('span', { class: 'ap-quiet', text: 'Asked by ' + (a.by || 'a webmaster') }),
        ro || a.mine ? (a.mine ? K.link('Cancel', () => K.api('POST', 'webmasters', { email: a.email, cancel: 1 }).then(() => { A.toast('Cancelled'); again(); }, A.fail)) : null) : A.btn('Confirm', { write: true, onClick: () => K.api('POST', 'webmasters/confirm', { email: a.email }).then(() => { A.toast('Confirmed · ' + (a.name || a.email)); again(); }, A.fail) })));
      doc.appendChild(h('div', { class: 'cx-page' }, K.section('Webmasters', { n: web.list.length, help: web.alone ? 'One webmaster · Adding someone goes ahead at once' : 'Adding or removing one needs a second webmaster', act: ro ? null : K.link('Add webmaster', addWebmaster, { icon: 'plus' }) }, asks, list)));
    }

    /* -------------------------------------------------------- a year, beside the list */
    function openYear(y) {
      A.setParams({ id: y.year });
      doc.querySelectorAll('tr[data-key]').forEach(x => x.setAttribute('aria-selected', String(x.dataset.key === String(y.year))));
      const isThis = String(y.year) === String(boot.year);
      // What's done in that year (untouched: it can be removed), asked of that year, not the one open.
      if (!isThis && y.data && !y._info) { K.api('GET', 'years/' + y.year + '/webinfo').then(i => { y._info = i || {}; openYear(y); }).catch(() => { y._info = {}; }); }
      const inf = isThis ? info : y._info;
      const body = h('div', { class: 'cx-rec' },
        K.facts([
          ['Dates', y.start ? O.fmtDateSpan(y.start, y.end) : 'Not set'],
          y.venue ? ['Campus', y.venue] : null,
          y.hosts ? ['Hosts', y.hosts] : null,
          y.announced ? ['Hosts named', K.md(y.announced) + ', ' + String(y.announced).slice(0, 4)] : null,
          y.coa_announced ? ['Announced', K.md(y.coa_announced) + ', ' + y.coa_announced.slice(0, 4)] : null,
          ['Now', nowWord(y)]
        ]),
        inf && inf.exported ? h('p', { class: 'ap-quiet', text: 'Exported ' + K.md(String(inf.exported.at || '').slice(0, 10)) }) : null,
        inf && inf.untouched ? h('p', { class: 'cx-issue cx-issue--soft', text: 'Started · Nothing in it yet' }) : null);
      const foot = y.data ? [A.link({ year: y.year, s: 'home', id: '' }, 'Open ' + y.year, 'ap-btn')] : [];
      if (y.data) foot.push(A.btn('Export', { ghost: true, icon: 'file', title: 'Its spreadsheets in one zip · Never anyone’s record', onClick: () => exportYear(y.year) }));
      if (inf && inf.untouched && !ro) foot.push(A.btn('Remove ' + y.year, { ghost: true, danger: true, write: true, onClick: () => unstart(y.year) }));
      sp.open({ title: y.year + ' Annual Conference', body, foot, onClose: () => A.setParams({ id: '' }) });
      if (!K.wide()) window.scrollTo(0, 0);
    }
    const sel = rows.find(y => String(y.year) === String(ctx.params.id));
    if (sel) openYear(sel);
    // From the webmasters' Home: "Start 2028" opens its panel.
    else if (ctx.params.id === 'start' && next && !ro) start(next);

    /* -------------------------------------------------------- the acts */
    function start(y) {
      const known = years.find(r => r.year === y) || {};
      const hosts = K.textIn({ value: known.hosts || '', label: 'Hosts', placeholder: 'Ohio and Tennessee districts', live: false });
      K.confirm(sp, {
        title: 'Start ' + y,
        lines: [newest ? 'Now: committees, their responsibilities and their yearly tasks from ' + newest.year : 'Starts from the usual committees', newest && upcoming && upcoming.year === newest.year ? 'After ' + newest.year + ' is over: its notes, its files and the tasks it added' : '', 'Only its hosts are public until its COA announces it'].filter(Boolean),
        field: K.field('Hosts', hosts, { help: 'From the Scheduling Committee’s report' }),
        actLabel: 'Start ' + y,
        act: () => K.api('POST', 'coa/' + y + '/start', { hosts: hosts.value.trim() }).then(() => K.api('POST', 'years/' + y + '/started', {})),
        onDone: () => { A.flash('Started · ' + y + ' · Invite its COA on Access'); location.href = A.href({ year: y, s: 'members', id: '' }); }
      });
    }
    // What Remove does to people is said: the year's COA keeps its access (and can be removed on Access).
    function unstart(y) {
      K.api('GET', 'years/' + y + '/members').catch(() => ({ members: [] })).then(m => {
        const coa = (m.members || []).filter(x => !x.removed && x.role === 'coa' && x.state !== 'expired');
        const others = (m.members || []).filter(x => !x.removed && x.role !== 'coa' && x.state !== 'expired');
        const people = coa.length || others.length
          ? [coa.length ? K.plural(coa.length, 'COA member') + (coa.length === 1 ? ' keeps' : ' keep') + ' their access · ' + coa.map(x => x.name ? x.name.replace(/^(\S+).*\s(\S)\S*$/, '$1 $2.') : x.email).join(', ') : '', others.length ? K.plural(others.length, 'helper') + ' keep their access' : '', 'Remove them on Access']
          : ['No one has access to it'];
        K.confirm(sp, { title: 'Remove ' + y, danger: true, lines: ['Nothing has been done in it · Its files, committees and tasks go', people.filter(Boolean).join(' · ')], actLabel: 'Remove ' + y,
          act: () => K.api('DELETE', 'years/' + y + '/started'), onDone: () => { A.flash('Removed · ' + y); location.href = A.href({ year: withData.find(r => r.year !== y).year, s: 'years', id: '' }); } });
      });
    }
    function exportYear(y) {
      fetch((W.rest || '/wp-json/ogc/v1/') + 'years/' + y + '/export', { credentials: 'same-origin', headers: { 'X-WP-Nonce': W.nonce } })
        .then(r => { if (!r.ok) throw new Error('Not exported'); return r.blob(); })
        .then(b => { const a = h('a', { href: '#', download: y + ' Annual Conference.zip' }); a.href = URL.createObjectURL(b); document.body.appendChild(a); a.click(); a.remove(); A.toast('Exported · ' + y); })
        .catch(() => A.toast('Not exported'));
    }
    function addWebmaster() {
      const email = K.textIn({ label: 'Email', placeholder: 'name@example.org', inputmode: 'email', live: false });
      const name = K.textIn({ label: 'Name', placeholder: 'First and last name', live: false });
      K.confirm(sp, { title: 'Add webmaster', lines: [web && web.alone ? 'Goes ahead at once' : 'A second webmaster confirms'], field: h('div', null, K.field('Email', email), K.field('Name', name)), actLabel: web && web.alone ? 'Add' : 'Request',
        act: () => { const e = email.value.trim(); if (!/^[^\s@]+@[^\s@]+\.[a-z]{2,}$/i.test(e)) return Promise.reject({ message: 'An email address' }); return K.api('POST', 'webmasters', { email: e, act: 'add', name: name.value.trim() }); },
        onDone: () => { A.toast(web && web.alone ? 'Added · Sign-in link sent' : 'Requested · A second webmaster confirms'); again(); } });
    }
    function ask(email, act, label) {
      K.confirm(sp, { title: 'Remove ' + label, danger: true, lines: [web && web.alone ? 'Goes ahead at once' : 'A second webmaster confirms'], actLabel: web && web.alone ? 'Remove' : 'Request',
        act: () => K.api('POST', 'webmasters', { email, act }), onDone: () => { A.toast('Requested · Remove ' + label); again(); } });
    }
  }
})();
