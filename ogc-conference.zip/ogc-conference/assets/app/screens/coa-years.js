/*
 * coa-years.js — Years, for the webmasters (Round 6b, Oct 17; docs/27-back-end-map/area-people-access.md §8):
 * every Conference on the site with its state, and the jobs that carry the site from year to year:
 *   - Start the next year: the only thing that sets a year up (README 2.4 rule 6, P17). It lands on Access
 *     in the new year with Add COA member open;
 *   - each year's COA (→ Access), its Names cleared day (shown, not set, until the Advisors decide: P16);
 *   - Export a year's files as one zip, and Remove a year started by mistake while no one is on it.
 * The webmasters themselves moved to Access (P5). s=years&id=<year>|start&at=clear.
 */
(function () {
  'use strict';
  const A = window.OGC_APP, K = window.OGC_COA, O = window.OGC, W = window.OGC_WP || {};
  if (!A || !K) return;
  const h = A.h;

  A.screen({
    id: 'years', title: 'Years', icon: 'years', section: 'own', who: ['webmaster'],
    render(ctx) {
      let alive = true;
      ctx.head('Years', '', []);
      K.loading(ctx.body);
      const draw = () => Promise.all([K.api('GET', 'years'), A.api('GET', 'years').catch(() => ({ years: [] })), K.api('GET', 'years/' + ctx.params.year + '/webinfo').catch(() => null)])
        .then(([years, facts, info]) => { if (alive) page(ctx, years, facts.years || [], info, draw); }, err => { if (alive) K.failed(ctx.body, err); });
      draw();
      return () => { alive = false; };
    }
  });

  function page(ctx, years, facts, info, again) {
    const boot = ctx.boot, today = new Date().toISOString().slice(0, 10);
    const fact = y => facts.find(f => String(f.year) === String(y.year)) || {};
    const started = y => fact(y).started != null ? !!fact(y).started : !!y.data;
    const withData = years.filter(started).sort((a, b) => b.year - a.year);
    const upcoming = withData.slice().reverse().find(y => !y.end || y.end >= today) || null;
    const newest = withData[0];
    // Start is offered for the one year after the newest started year (8.4).
    const next = newest ? String(+newest.year + 1) : '';
    const nextRow = years.find(y => String(y.year) === next) || (next ? { year: next } : null);
    const acts = [];
    if (next) acts.push(A.btn('Start ' + next, { primary: true, icon: 'plus', title: 'Picks up from ' + newest.year + ' · The only way a year is set up', onClick: () => start(next) }));
    const rows = withData.concat(nextRow && !started(nextRow) ? [nextRow] : []).sort((a, b) => b.year - a.year);
    ctx.head('Years', K.plural(withData.length, 'year') + (upcoming ? ' · Next: ' + upcoming.year : ''), acts);
    A.clear(ctx.body);
    const sp = ctx.split();
    sp.el.classList.add('cx-split');
    const doc = h('div', { class: 'cx-list' });
    sp.main.appendChild(doc);

    // One word, one meaning (P10): Hosts named · Announced · The week · Held · Cleared.
    const status = y => {
      const f = fact(y);
      if (!started(y)) return 'Hosts named';
      if (f.clears && f.clears.cleared) return 'Cleared';
      if (y.end && y.end < today) return 'Held';
      if (y.start && y.start <= today && (!y.end || y.end >= today)) return 'The week';
      if (y.coa_announced && y.coa_announced <= today) return 'Announced';
      return 'Hosts named';
    };
    const pub = y => [y.status_word === 'Registration open' ? 'Registration open' : '', y.recordings ? 'Recordings' : ''].filter(Boolean);
    const coaWords = y => { const c = fact(y).coa; return !started(y) ? '' : !c || c.state === 'none' ? 'Not invited' : c.state === 'invited' ? c.invited + ' invited' : c.words; };
    const clearWords = y => { const c = fact(y).clears; return !c ? '' : c.cleared ? 'Cleared ' + K.md(c.cleared) : c.on ? K.md(c.on) + ', ' + c.on.slice(0, 4) : ''; };
    const tb = h('tbody', null, rows.map(y => {
      const c = fact(y).coa;
      const tr = h('tr', { 'data-key': y.year, 'aria-selected': String(String(y.year) === String(ctx.params.id)), tabindex: '-1', on: { click: e => { if (!e.target.closest('a, button')) openYear(y); } } },
        h('td', null, h('span', { class: 'ap-cell-title', text: y.year }), h('span', { class: 'ap-cell-sub', text: y.hosts || '' })),
        h('td', { class: 'ap-td--nowrap ap-td--wide' }, y.start ? O.fmtDateSpan(y.start, y.end) : h('span', { class: 'ap-quiet', text: 'Dates not set' })),
        h('td', { class: 'ap-td--wide' }, y.venue || ''),
        h('td', null, h('span', { class: 'cx-marks' }, [h('span', { class: 'ap-tag' + (status(y) === 'Held' || status(y) === 'Cleared' ? '' : ' ap-tag--tan'), text: status(y) })].concat(pub(y).map(x => A.tag(x))))),
        h('td', { class: 'ap-td--nowrap ap-td--wide' }, started(y) ? A.link({ year: y.year, s: 'members', id: c && c.state === 'none' ? 'new' : '', v: '', c: '' }, coaWords(y), c && c.state === 'none' ? 'pp-tan' : 'ap-link') : ''),
        h('td', { class: 'ap-td--nowrap ap-td--wide' }, clearWords(y)),
        // The year you're in is marked; another opens by name ("Open 2028"); the next can be started.
        h('td', { class: 'ap-td--num ap-td--nowrap' }, !started(y) ? h('button', { type: 'button', class: 'ap-link', text: 'Start', on: { click: () => start(String(y.year)) } })
          : String(y.year) === String(boot.year) ? h('span', { class: 'ap-quiet', text: 'Current' }) : A.link({ year: y.year, s: 'home', id: '' }, 'Open ' + y.year, 'ap-link'),
          h('span', { class: 'pp-chev', 'aria-hidden': 'true' }, A.icon('chev', 14))));
      return tr;
    }));
    doc.appendChild(h('div', { class: 'ap-tablewrap pp-years' }, h('table', { class: 'ap-table', 'aria-label': 'Years' },
      h('thead', null, h('tr', null, [['Year'], ['Dates', 1], ['Campus', 1], ['Status'], ['COA', 1], ['Names cleared', 1], ['', 0, 1]].map(([t, w, n]) => h('th', { scope: 'col', class: (w ? 'ap-td--wide' : '') + (n ? ' ap-td--num' : ''), text: t })))), tb)));

    /* -------------------------------------------------------- a year, beside the list */
    function openYear(y, at) {
      A.setParams({ id: y.year });
      doc.querySelectorAll('tr[data-key]').forEach(x => x.setAttribute('aria-selected', String(x.dataset.key === String(y.year))));
      if (!started(y)) { start(String(y.year)); return; }
      const isThis = String(y.year) === String(boot.year);
      if (!isThis && !y._info) { K.api('GET', 'years/' + y.year + '/webinfo').then(i => { y._info = i || {}; openYear(y, at); }).catch(() => { y._info = {}; }); }
      const inf = isThis ? info : y._info;
      const f = fact(y), c = f.coa, cl = f.clears;
      const coaPart = h('section', { class: 'pp-part', 'data-part': 'coa' }, h('h3', { class: 'ap-rec__h', text: 'COA' }),
        h('p', null, !c || c.state === 'none'
          ? [h('span', { class: c && c.late ? 'pp-late' : 'pp-tan', text: 'Not invited' + (c && c.late ? ' · Late' : '') }), ' · ', A.link({ year: y.year, s: 'members', id: 'new', v: '', c: '' }, 'Add COA', 'ap-link')]
          : [c.words, ' · ', A.link({ year: y.year, s: 'members', id: '', v: c.active < c.invited ? 'invited' : '', c: '' }, 'Open Access', 'ap-link')]));
      const clearPart = cl ? h('section', { class: 'pp-part', 'data-part': 'clear', id: 'pp-clear' }, h('h3', { class: 'ap-rec__h', text: 'Names cleared' }),
        h('p', { text: cl.cleared ? 'Cleared ' + K.md(cl.cleared) + ', ' + cl.cleared.slice(0, 4) + ' · Counts stay' : cl.on ? cl.days + ' days after · ' + K.md(cl.on) + ', ' + cl.on.slice(0, 4) : 'After its dates are set' }),
        h('p', { class: 'ap-help', text: 'Set by the webmasters’ policy · Waits for the Advisors' })) : null;
      const people = f.people || 0;
      const body = h('div', { class: 'cx-rec' },
        K.facts([
          ['Dates', y.start ? O.fmtDateSpan(y.start, y.end) : 'Not set'],
          y.venue ? ['Campus', y.venue] : null,
          y.hosts ? ['Hosts', y.hosts] : null,
          y.announced ? ['Hosts named', K.md(y.announced) + ', ' + String(y.announced).slice(0, 4)] : null,
          y.coa_announced ? ['Announced', K.md(y.coa_announced) + ', ' + y.coa_announced.slice(0, 4)] : null,
          ['Status', status(y)]
        ]),
        coaPart, clearPart,
        inf && inf.exported ? h('p', { class: 'ap-quiet', text: 'Exported ' + K.md(String(inf.exported.at || '').slice(0, 10)) }) : null,
        inf && inf.untouched && !people ? h('p', { class: 'cx-issue cx-issue--soft', text: 'Started · Nothing in it yet' }) : null,
        // Remove only with no one on it (P17); else where to remove them.
        inf && inf.untouched && people ? h('p', { class: 'ap-help' }, K.plural(people, 'person', 'people') + ' on it · ', A.link({ year: y.year, s: 'members', id: '', v: '', c: '' }, 'Remove them on Access', 'ap-link'), ' first') : null);
      const foot = isThis ? [] : [A.link({ year: y.year, s: 'home', id: '' }, 'Open ' + y.year, 'ap-btn')];
      foot.push(A.btn('Export', { ghost: true, icon: 'file', title: 'Its spreadsheets in one zip · Never anyone’s record', onClick: () => exportYear(y.year) }));
      if (inf && inf.untouched && !people) foot.push(A.btn('Remove ' + y.year, { ghost: true, danger: true, onClick: () => unstart(y.year) }));
      sp.open({ title: y.year + ' Annual Conference', tags: [A.tag(status(y), 'tan')], body, foot, onClose: () => A.setParams({ id: '' }) });
      if (at === 'clear') setTimeout(() => { const el = sp.panel.querySelector('#pp-clear'); if (el) el.scrollIntoView({ block: 'start' }); }, 0);
      if (!K.wide()) window.scrollTo(0, 0);
    }
    const sel = rows.find(y => String(y.year) === String(ctx.params.id));
    if (sel) openYear(sel, ctx.params.at);
    // From the webmasters' Home: "Start 2028" opens its panel.
    else if (ctx.params.id === 'start' && next) start(next);

    /* -------------------------------------------------------- the acts */
    function start(y) {
      const known = years.find(r => String(r.year) === String(y)) || {};
      const hosts = K.textIn({ value: known.hosts || '', label: 'Hosts', placeholder: 'Ohio and Tennessee districts', live: false });
      K.confirm(sp, {
        title: 'Start ' + y,
        lines: [newest ? 'Now: committees, their responsibilities and their yearly tasks from ' + newest.year : 'Starts from the usual committees', newest && upcoming && upcoming.year === newest.year ? 'After ' + newest.year + ' is over: its notes, its files and the tasks it added' : '', 'Only its hosts are public until its COA announces it'].filter(Boolean),
        field: K.field('Hosts', hosts, { help: 'From the Scheduling Committee’s report' }),
        actLabel: 'Start ' + y,
        act: () => K.api('POST', 'coa/' + y + '/start', { hosts: hosts.value.trim() }).then(() => K.api('POST', 'years/' + y + '/started', {})),
        // Then Access in the new year, with Add COA member open (8.4).
        onDone: () => { A.flash('Started · ' + y); location.href = A.href({ year: y, s: 'members', id: 'new', v: '', c: '' }); }
      });
    }
    function unstart(y) {
      K.confirm(sp, { title: 'Remove ' + y, danger: true, lines: ['Its committees and tasks go · Its hosts stay public'], actLabel: 'Remove ' + y,
        act: () => K.api('DELETE', 'years/' + y + '/started'), onDone: () => { A.flash('Removed · ' + y); location.href = A.href({ year: withData.find(r => String(r.year) !== String(y)).year, s: 'years', id: '' }); } });
    }
    function exportYear(y) {
      fetch((W.rest || '/wp-json/ogc/v1/') + 'years/' + y + '/export', { credentials: 'same-origin', headers: { 'X-WP-Nonce': W.nonce } })
        .then(r => { if (!r.ok) throw new Error('Not exported'); return r.blob(); })
        .then(b => { const a = h('a', { href: '#', download: y + ' Annual Conference.zip' }); a.href = URL.createObjectURL(b); document.body.appendChild(a); a.click(); a.remove(); A.toast('Exported · ' + y); })
        .catch(() => A.toast('Not exported'));
    }
  }
})();
