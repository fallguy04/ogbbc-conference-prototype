/*
 * people-kit.js — the people screens' shared pieces (Round 6b, Oct 17; docs/27-back-end-map/
 * area-people-access.md §2). One component each, hosted wherever a person is shown or added:
 *
 *   A.people.list(year)          the year's members as this viewer may see them (See as goes with it)
 *   A.people.open(sp, id, o)     the person panel (§5) in the host's split: o = { c, from, nav, onChange, onClose }
 *   A.people.card(sp, id, o)     the short card (anyone not on the COA, P1): name, Head · Lodging, each
 *                                committee a door, Message. Not kept in the address.
 *   A.people.add(sp, o)          Add people (§6): o = { c, head, wm, rows: [{ name, email }], ask, onDone }
 *   A.people.ask(sp, o)          Ask the COA to add someone (P20): o = { c, onDone }
 *   A.people.money(sp, data, o)  who handles money (3.8, at=money)
 *   A.people.nameBtn(person, open)  a name drawn as a door (a button that opens the panel or the card)
 *
 * Writes are greyed while seeing as, never hidden (README 2.6); the server refuses them anyway.
 */
(function () {
  'use strict';
  const A = window.OGC_APP;
  if (!A) return;
  const h = A.h;
  const P = A.people = {};
  const year = () => A.boot().year;
  const RO = 'Read only while seeing as';
  const cname = k => k === 'coa' ? 'COA' : ((A.committee(k) || {}).name || k);
  P.cname = cname;

  P.list = y => A.api('GET', '/years/' + (y || year()) + '/members');

  // One status, from one fixed list (§5.3), with its date.
  P.status = m => {
    if (m.removed) return { word: 'Removed', tone: '' };
    if (m.expired || m.state === 'expired') return { word: 'Ended', tone: '', date: m.until };
    if (m.state === 'invited') return m.invite_expired ? { word: 'Link expired', tone: '', date: m.invited, pre: 'Invited' } : { word: 'Invited', tone: '', date: m.invited };
    if (m.ending_soon) return { word: 'Ending soon', tone: 'late', date: m.until };
    return { word: 'Signed in', tone: '', date: m.signed_in };
  };
  P.statusWords = m => { const s = P.status(m); return s.pre ? s.word + ' · ' + s.pre + ' ' + (s.date || '') : [s.word, s.date].filter(Boolean).join(' '); };
  const roleWords = m => m.role === 'coa' ? 'COA' : [m.head ? 'Head' : '', (m.committees || []).map(cname).join(', ')].filter(Boolean).join(' · ');

  // A name as a door: a real button, 44 px on a phone (people.css).
  P.nameBtn = (name, onOpen, o) => h('button', { type: 'button', class: 'pp-name' + (o && o.cls ? ' ' + o.cls : ''), 'data-person': o && o.id != null ? String(o.id) : null, title: o && o.title || null, on: { click: e => { e.stopPropagation(); onOpen(); } } }, name);

  // A field that saves when left; greyed while seeing as.
  function textField(label, value, o) {
    const i = h('input', { class: 'ap-input', value: value || '', maxlength: o.max || null, inputmode: o.inputmode || null, type: o.type || null, placeholder: o.placeholder || null, disabled: !!o.disabled, title: o.disabled && A.readonly ? RO : o.title || null, 'aria-label': label, autocomplete: 'off' });
    if (o.onSave) i.addEventListener('change', () => o.onSave(i.value.trim(), i));
    return h('label', { class: 'ap-field' }, h('span', { text: label }), i, o.help ? h('span', { class: 'ap-help', text: o.help }) : null);
  }

  function pills(keys, sel, o) {
    const box = h('div', { class: 'ap-pills', role: 'group', 'aria-label': o.label || 'Committees' });
    const draw = () => {
      A.clear(box);
      keys.forEach(k => box.appendChild(h('button', {
        type: 'button', class: 'ap-pill', 'aria-pressed': String(sel.includes(k)), disabled: !!o.disabled, title: o.disabled && A.readonly ? RO : null,
        on: { click: () => { const i = sel.indexOf(k); if (i >= 0) sel.splice(i, 1); else sel.push(k); draw(); if (o.onChange) o.onChange(); } }
      }, o.word ? o.word(k) : cname(k))));
    };
    draw();
    return box;
  }
  const committeeKeys = () => A.boot().committees.filter(c => c.key !== 'coa').map(c => c.key);

  /* ------------------------------------------------------------ the person panel (§5) */

  P.open = function (sp, id, o) {
    o = o || {};
    sp.open({ title: 'Loading', body: [h('p', { class: 'ap-quiet', role: 'status', text: 'Loading' })], onClose: o.onClose });
    return A.api('GET', 'person?id=' + encodeURIComponent(id)).then(d => draw(sp, d, o)).catch(e => {
      sp.open({ title: e && e.status === 404 ? 'Not found' : 'Not loaded', body: [A.empty({ title: e && e.status === 404 ? 'Not on this year' : 'Not loaded', line: 'Close and try again', inset: true })], onClose: o.onClose });
    });
  };

  function draw(sp, d, o) {
    const boot = A.boot(), v = boot.viewer, m = d.member, can = m.can || {};
    const ro = !!A.readonly;
    const wm = v.webmaster && !v.coa;
    const coaRow = m.role === 'coa';
    const who = m.name || m.email;
    const may = k => !!can[k] || (ro && !coaRow);
    const off = k => ro || !can[k];
    const changed = () => { if (o.onChange) o.onChange(); };
    const patch = (body, words) => A.api('PATCH', '/members/' + m.id, body).then(r => { A.toast(words); Object.assign(m, (r && r.member) || {}); changed(); return r; });
    const body = [];

    // Fields
    if (may('name')) body.push(textField('Name', m.name, { max: 60, disabled: off('name'), onSave: x => patch({ name: x }, 'Saved · Name').catch(A.fail) }));
    if (can.email || (ro && !coaRow && m.state === 'invited')) {
      body.push(textField('Email', m.email, { type: 'email', inputmode: 'email', disabled: off('email'), help: 'Not signed in yet · A new address gets a new link',
        onSave: (x, i) => { if (!x || x === m.email) return; patch({ email: x }, 'New link sent · ' + x).catch(e => { if (e.status === 409 && e.data && e.data.code === 'ogc_typo') { A.toast(e.data.message); } else A.fail(e); i.value = m.email; }); } }));
    }
    // The phone: the COA's own record of them, never anyone else's (the server sends it to the COA only).
    if (v.coa && !coaRow) {
      if (d.withheld) body.push(h('div', { class: 'ap-field' }, h('span', { text: 'Phone' }), h('span', { class: 'pp-withheld', text: 'Withheld' }), h('span', { class: 'ap-help', text: 'Only the COA sees it' })));
      else body.push(h('div', { class: 'pp-phone' }, textField('Phone', d.phone, { inputmode: 'tel', placeholder: '555-0100', help: 'Only the COA sees it',
        onSave: x => A.api('PUT', 'phones', { id: m.id, phone: x }).then(() => { A.toast(x ? 'Phone saved · ' + who : 'Phone removed'); changed(); }).catch(A.fail) }),
        d.phone ? h('a', { class: 'ap-link pp-tel', href: 'tel:' + d.phone.replace(/[^\d+]/g, ''), text: 'Call' }) : null));
    }
    // Committees and Head: the COA's, on a committee member (Save, drawn only when changed).
    const sel = (m.committees || []).slice();
    const head = h('input', { type: 'checkbox', checked: !!m.head, disabled: off('label'), title: ro ? RO : null });
    let saveBtn = null;
    const dirty = () => sel.slice().sort().join() !== (m.committees || []).slice().sort().join() || head.checked !== !!m.head;
    const guard = h('span', { class: 'ap-help pp-guard', hidden: true, text: 'Head of one committee · Until Head per committee' });
    const syncHead = () => {
      // One Head flag heads every committee someone is on (until Head per committee, P3): greyed for two.
      const two = sel.length > 1;
      head.disabled = off('label') || (two && !m.head);
      guard.hidden = !two || !!m.head;
      if (saveBtn) saveBtn.hidden = !dirty();
    };
    if (!wm && !coaRow && may('label')) {
      body.push(h('div', { class: 'ap-field' }, h('span', { text: 'Committees' }), pills(committeeKeys(), sel, { disabled: off('label'), onChange: syncHead })),
        h('label', { class: 'ap-switch' }, head, 'Head of committee'), guard);
      head.addEventListener('change', syncHead);
      body.push(textField('Helps with', m.helps, { max: 40, disabled: off('label'), help: 'A few words · Shown under their name', onSave: x => patch({ helps: x }, 'Saved · Helps with').catch(A.fail) }));
    }
    // Handles money (decision 4): the COA ticks it, never on their own row.
    if (v.coa && (can.money || ro)) body.push(moneyField(m, { disabled: ro, onDone: changed }));
    else if (m.money) body.push(h('p', { class: 'ap-help', text: 'Handles money' }));

    // Facts
    const st = P.status(m);
    const renewable = (m.ending_soon || m.expired) && (can.renew || ro);
    let years = (d.years || {})[m.role === 'coa' ? 'coa' : 'helper'] || 1;
    const facts = h('dl', { class: 'ap-facts' },
      h('dt', { text: 'Status' }), h('dd', null, st.tone ? A.tag(P.statusWords(m), st.tone) : P.statusWords(m)),
      m.email && !may('email') ? [h('dt', { text: 'Email' }), h('dd', { title: m.signed_in ? 'Signed in · Remove and add again to change' : null, text: m.email })] : null,
      [h('dt', { text: 'Added by' }), h('dd', { text: m.by || 'A webmaster' })],
      h('dt', { text: 'Access until' }), h('dd', { text: m.until || '' }),
      m.webmaster ? [h('dt', { text: 'Also' }), h('dd', { text: 'Webmaster' })] : null);
    body.push(h('section', { class: 'pp-facts', 'aria-label': 'Facts' }, facts));
    // Access lasts (the webmasters', on Renew): how long the next renewal gives.
    if (wm && renewable) {
      const yp = h('div', { class: 'ap-pills', role: 'group', 'aria-label': 'Access lasts' }, [1, 2, 3].map(n => h('button', { type: 'button', class: 'ap-pill', 'aria-pressed': String(n === years), on: { click: e => { years = n; yp.querySelectorAll('.ap-pill').forEach(b => b.setAttribute('aria-pressed', String(b === e.currentTarget))); } } }, n + (n === 1 ? ' year' : ' years'))));
      body.push(h('div', { class: 'ap-field' }, h('span', { text: 'Access lasts' }), yp));
    }
    if (coaRow && v.coa) body.push(h('p', { class: 'ap-help', text: 'Added by the webmasters · Role and email are theirs' }));

    // Linked: each committee its page, tasks given, the screens their committee runs.
    const L = d.linked || {};
    const lines = [];
    (L.committees || []).forEach(c => lines.push(h('li', null, A.link({ s: 'committees', c: c.key, id: '', v: '', at: '', f: '' }, [h('span', { text: c.name + (c.head ? ' · Head' : '') }), A.icon('chev', 14)], 'ap-linked__a pp-door'))));
    if (L.tasks && A.allowed('tasks')) lines.push(h('li', null, A.link({ s: 'tasks', c: '', v: 'all', f: 'who:' + m.id, id: '' }, [h('span', { text: 'Tasks given · ' + L.tasks }), A.icon('chev', 14)], 'ap-linked__a pp-door')));
    (L.runs || []).forEach(r => { if (A.allowed(r.id)) lines.push(h('li', { title: 'Through ' + r.through }, A.link({ s: r.id, c: '', id: '', v: '' }, [h('span', { text: 'Runs · ' + r.title }), A.icon('chev', 14)], 'ap-linked__a pp-door'))); });
    if (L.webmaster && A.allowed('privacy')) lines.push(h('li', null, A.link({ s: 'privacy', c: '', id: '', v: '' }, [h('span', { text: 'Privacy · Webmaster on ' + boot.year }), A.icon('chev', 14)], 'ap-linked__a pp-door')));
    if (lines.length) body.push(h('section', { class: 'ap-linked', 'aria-label': 'Linked' }, h('h3', { class: 'ap-rec__h', text: 'Linked' }), h('ul', null, lines)));
    const hist = A.history(d.history || []);
    if (hist) body.push(hist);

    // Acts: at most one filled (Save, only when changed).
    const foot = [];
    if (!wm && !coaRow && may('label')) {
      saveBtn = A.btn('Save', { primary: true, write: true, onClick: () => patch({ committees: sel, head: head.checked }, 'Saved · ' + who + ' · ' + (sel.map(cname).join(', ') || 'No committee')).then(() => { if (o.onSaved) o.onSaved(); }).catch(A.fail) });
      saveBtn.hidden = true;
      foot.push(saveBtn);
    }
    if (!m.you && (v.coa || (wm && coaRow))) foot.push(A.btn('Message', { icon: 'mail', write: true, onClick: () => A.message({ sp, api: A.api, body: sp.main }, { to: 'member:' + m.id, label: who }) }));
    if (m.state === 'invited' && (can.resend || ro)) foot.push(A.btn('Resend', { write: true, title: 'A new sign-in link', onClick: () => A.api('POST', '/members/' + m.id + '/resend').then(() => { A.toast('Sent a new link · ' + who); changed(); }).catch(A.fail) }));
    if (renewable) foot.push(A.btn('Renew', { write: true, title: wm ? 'Access lasts the years chosen above' : 'One more year', onClick: () => patch(wm ? { renew: true, years } : { renew: true }, 'Renewed · ' + who).catch(A.fail) }));
    if (can.remove || (ro && !coaRow)) foot.push(A.btn('Remove from ' + boot.year, { danger: true, ghost: true, write: true, onClick: () => remove(sp, m, o) }));
    syncHead();
    sp.open({
      title: who, line: roleWords(m) || null, focus: 'head',
      tags: [st.tone ? A.tag(st.word, st.tone) : null, m.head && !coaRow ? A.tag('Head', 'tan') : null, coaRow ? A.tag('COA') : null, m.money ? A.tag('Handles money') : null, m.webmaster ? A.tag('Webmaster') : null],
      body, foot, nav: o.nav || null, onClose: o.onClose
    });
  }

  // Remove from the year: asks in the foot first, then Undo for the hour (as built).
  function remove(sp, m, o) {
    const who = m.name || m.email, y = A.boot().year;
    const box = h('div', { class: 'pv-ask', role: 'alert' },
      h('p', { class: 'pv-ask__q', text: 'Remove ' + who + ' from ' + y + ' · Access ends now · Every committee' }),
      h('div', { class: 'ap-row' },
        A.btn('Remove', { danger: true, write: true, onClick: () => A.api('DELETE', '/members/' + m.id).then(() => {
          A.toast('Removed · ' + who, { undo: () => A.api('PATCH', '/members/' + m.id, { restore: true }).then(() => { A.toast('Restored · ' + who); if (o.onChange) o.onChange(); }).catch(A.fail) });
          sp.close();
          if (o.onChange) o.onChange();
        }).catch(A.fail) }),
        A.btn('Cancel', { ghost: true, onClick: () => box.remove() })));
    const foot = sp.panel.querySelector('.ap-panel__foot');
    if (foot && !foot.querySelector('.pv-ask')) foot.prepend(box);
  }

  // Handles money (decision 4): saved at once. The first tick asks whether the address is theirs alone.
  function moneyField(m, o) {
    const box = h('input', { type: 'checkbox', checked: !!m.money, disabled: !!o.disabled || (m.you && !m.money), title: o.disabled ? RO : m.you && !m.money ? 'Another COA member ticks it' : null });
    const ask = h('div', { class: 'pv-ask', hidden: true });
    const who = m.name || m.email;
    const send = (on, own) => A.api('PATCH', '/members/' + m.id, own ? { money: on, own_email: true } : { money: on }).then(() => {
      A.toast(on ? 'Handles money · ' + who : 'Removed · Handles money · ' + who);
      m.money = on;
      if (o.onDone) o.onDone();
    }).catch(e => { box.checked = !!m.money; if (e.status === 409 && e.data && e.data.code === 'ogc_own_email') { ask.hidden = false; return; } A.fail(e); });
    A.clear(ask).append(h('p', { class: 'pv-ask__q', text: 'Only ' + who + ' reads ' + (m.email || 'this email') + '?' }),
      h('p', { class: 'ap-help', text: 'Each payment shows to whoever reads it' }),
      h('div', { class: 'ap-row' },
        A.btn('Yes', { write: true, onClick: () => { ask.hidden = true; box.checked = true; send(true, true); } }),
        A.btn('No', { ghost: true, onClick: () => { ask.hidden = true; box.checked = false; A.toast('Needs an email only ' + who + ' reads'); } })));
    box.addEventListener('change', () => {
      if (box.checked && !m.money) { box.checked = false; ask.hidden = false; return; }
      ask.hidden = true;
      send(box.checked, false);
    });
    return h('div', { class: 'ap-field' }, h('label', { class: 'ap-switch' }, box, 'Handles money'), h('span', { class: 'ap-help', text: 'Sees each payment · Checks and refunds' }), ask);
  }
  P.moneyField = moneyField;

  /* ------------------------------------------------------------ the short card (P1) */

  P.card = function (sp, id, o) {
    o = o || {};
    const pp = (A.boot().people || []).find(x => String(x.id) === String(id)) || o.person;
    if (!pp) return;
    const keys = (pp.committees || []).filter(k => k !== 'coa');
    const coa = (pp.committees || []).includes('coa');
    const v = A.boot().viewer;
    const body = [];
    if (keys.length) body.push(h('section', { class: 'ap-linked', 'aria-label': 'Committees' }, h('h3', { class: 'ap-rec__h', text: 'Committees' }),
      h('ul', null, keys.map(k => h('li', null, A.link({ s: 'committees', c: k, id: '', v: '', at: '' }, [h('span', { text: cname(k) }), A.icon('chev', 14)], 'ap-linked__a pp-door'))))));
    if (coa) body.push(h('p', { class: 'ap-help', text: 'On the COA' }));
    const mine = v.member_id && String(v.member_id) === String(pp.id);
    sp.open({
      title: pp.name, line: coa ? 'COA' : [pp.head ? 'Head' : '', keys.map(cname).join(', ')].filter(Boolean).join(' · '), focus: 'head',
      body, foot: mine ? [] : [A.btn('Message', { icon: 'mail', write: true, onClick: () => A.message({ sp, api: A.api, body: sp.main }, { to: 'member:' + pp.id, label: pp.name }) })],
      onClose: o.onClose
    });
  };

  /* ------------------------------------------------------------ Add people (§6) */

  const parse = t => String(t || '').split(/\r?\n|;/).map(line => {
    const m = line.match(/[^\s<>,;"']+@[^\s<>,;"']+\.[a-z]{2,}/i);
    if (!m) return null;
    return { name: line.replace(m[0], ' ').replace(/[<>"'\t,]+/g, ' ').replace(/\s+/g, ' ').trim(), email: m[0] };
  }).filter(Boolean);

  P.add = function (sp, o) {
    o = o || {};
    const boot = A.boot(), wm = !!o.wm, y = boot.year;
    const rowsBox = h('div', { class: 'ap-people-rows' });
    const rows = [];
    const addRow = (name, email) => {
      const n = h('input', { class: 'ap-input', value: name || '', placeholder: 'Name', 'aria-label': 'Name', autocomplete: 'off' });
      const e = h('input', { class: 'ap-input', value: email || '', placeholder: 'Email', type: 'email', inputmode: 'email', 'aria-label': 'Email', autocomplete: 'off' });
      const r = { n, e };
      const x = A.btn('Remove row', { ghost: true, iconOnly: true, icon: 'x', onClick: () => { if (rows.length > 1) { rows.splice(rows.indexOf(r), 1); el.remove(); } else { n.value = ''; e.value = ''; } } });
      const el = h('div', { class: 'ap-people-row' }, n, e, x);
      r.el = el;
      e.addEventListener('paste', ev => { const t = (ev.clipboardData || window.clipboardData).getData('text'); if (/\n|,|;|\t/.test(t.trim())) { ev.preventDefault(); takeList(t); } });
      rows.push(r);
      rowsBox.appendChild(el);
      return r;
    };
    const takeList = t => {
      const list = parse(t);
      if (!list.length) return;
      for (let i = rows.length - 1; i >= 0; i--) if (!rows[i].n.value.trim() && !rows[i].e.value.trim() && rows.length > 1) { rows[i].el.remove(); rows.splice(i, 1); }
      list.forEach((x, i) => { const r = i === 0 && rows.length === 1 && !rows[0].n.value.trim() && !rows[0].e.value.trim() ? rows[0] : addRow(); r.n.value = x.name; r.e.value = x.email; });
      A.toast(A.fmt.plural(list.length, 'person', 'people') + ' from the list · Check the names');
    };
    (o.rows && o.rows.length ? o.rows : [{}]).forEach(x => addRow(x.name, x.email));
    rows[0].n.setAttribute('data-autofocus', '');
    const more = h('button', { type: 'button', class: 'ap-link', text: 'Add another', on: { click: () => addRow().n.focus() } });
    const paste = h('textarea', { class: 'ap-textarea', rows: '3', placeholder: 'Ruth Kinsey   ruth@example.com', 'aria-label': 'Paste a list' });
    paste.addEventListener('change', () => { if (paste.value.trim()) { takeList(paste.value); paste.value = ''; } });
    const pasteBox = h('details', { class: 'ap-more' }, h('summary', { text: 'Paste a list' }), paste, h('span', { class: 'ap-help', text: 'A name and an email on each line · From a spreadsheet works' }));
    const sel = (o.cs || (o.c && o.c !== 'coa' && A.committee(o.c) ? [o.c] : [])).slice();
    const head = h('input', { type: 'checkbox', checked: !!o.head && sel.length <= 1 });
    const headLabel = h('span', { text: sel.length === 1 ? 'Head of ' + cname(sel[0]) : 'Head of committee' });
    const guard = h('span', { class: 'ap-help pp-guard', hidden: true, text: 'Head of one committee · Until Head per committee' });
    const headBox = h('div', { class: 'pp-head' }, h('label', { class: 'ap-switch' }, head, headLabel), guard);
    const syncHead = () => {
      const two = sel.length > 1;
      head.disabled = two || !sel.length || A.readonly;
      if (two) head.checked = false;
      guard.hidden = !two;
      headBox.hidden = !sel.length;
      headLabel.textContent = sel.length === 1 ? 'Head of ' + cname(sel[0]) : 'Head of committee';
    };
    let years = (o.years || 2);
    const yearsBox = wm ? h('div', { class: 'ap-pills', role: 'group', 'aria-label': 'Access lasts' }, [1, 2, 3].map(n => h('button', { type: 'button', class: 'ap-pill', 'aria-pressed': String(n === years), on: { click: e => { years = n; e.currentTarget.parentNode.querySelectorAll('.ap-pill').forEach(b => b.setAttribute('aria-pressed', String(b === e.currentTarget))); untilWords(); } } }, n + (n === 1 ? ' year' : ' years')))) : null;
    const until = h('span', { class: 'ap-help' });
    const untilWords = () => { const end = (boot.conference.end || (y + '-06-01')).slice(5); until.textContent = 'Until ' + A.fmt.md((y + years) + '-' + end) + ', ' + (y + years); };
    if (wm) untilWords();
    const err = h('div', { class: 'ap-err', role: 'alert' });
    let typosOk = false;
    const people = () => rows.map(r => ({ name: r.n.value.trim(), email: r.e.value.trim(), r })).filter(x => x.name || x.email);
    const add = btn => {
      const list = people();
      if (!list.length) { err.textContent = 'Name and email needed'; rows[0].n.focus(); return; }
      const noName = list.find(x => !x.name), noMail = list.find(x => !/^[^\s@]+@[^\s@]+\.[a-z]{2,}$/i.test(x.email));
      if (noName) { err.textContent = 'Name needed · ' + (noName.email || 'a row'); noName.r.n.focus(); return; }
      if (noMail) { err.textContent = 'Email needed · ' + noMail.name; noMail.r.e.focus(); return; }
      if (list.length > 40) { err.textContent = 'Up to 40 at once'; return; }
      if (!wm && !sel.length) { err.textContent = 'Choose a committee'; return; }
      btn.disabled = true;
      const emails = list.map(x => x.name.replace(/[<>"]/g, '') + ' <' + x.email + '>').join('\n');
      const body = wm ? { emails, role: 'coa', years, typos_ok: typosOk } : { emails, role: 'helper', committees: sel, head: head.checked, typos_ok: typosOk, ask: o.ask || '' };
      A.api('POST', '/years/' + y + '/members', body).then(r => {
        const n = r.added.length, merged = (r.merged || []).length, already = r.already.length;
        const to = wm ? 'the COA' : sel.map(cname).join(' and ');
        const name1 = id => { const x = (r.list && r.list.members || []).find(z => z.id === id); return x ? (x.name || x.email) : ''; };
        A.toast(n ? 'Added ' + A.fmt.plural(n, 'person', 'people') + ' to ' + to + ' · Sign-in link' + (n > 1 ? 's' : '') + ' sent' + (merged ? ' · ' + merged + ' now on it too' : '') + (already ? ' · ' + already + ' already on' : '')
          : merged === 1 ? name1(r.merged[0]) + ' · Now on ' + ((r.list.members.find(z => z.id === r.merged[0]) || {}).committees || []).map(cname).join(', ')
          : merged ? merged + ' people · Now on ' + to
          : already ? 'Already on ' + y + (already === 1 ? ' · ' + name1(r.already[0]) : '') : 'No one added');
        if (r.bad && r.bad.length) { err.textContent = 'Not an email: ' + r.bad.join(', '); btn.disabled = false; return; }
        if (o.onDone) o.onDone(r);
      }).catch(e => {
        btn.disabled = false;
        if (e.status === 409 && e.data && e.data.code === 'ogc_typo') {
          typosOk = true;
          const sus = (e.data.data && e.data.data.suspect) || [];
          A.clear(err).append(h('span', { text: e.data.message }), sus.length ? h('span', { class: 'ap-row', style: { marginTop: '6px' } },
            A.btn('Use ' + String(sus[0].fix).split('@')[1], { ghost: true, onClick: () => { sus.forEach(sx => rows.forEach(r => { if (r.e.value.trim().toLowerCase() === String(sx.email).toLowerCase()) r.e.value = sx.fix; })); typosOk = false; err.textContent = ''; } }),
            A.btn('Add as typed', { ghost: true, onClick: () => add(btn) })) : null);
          return;
        }
        err.textContent = (e.data && e.data.message) || 'Not added';
      });
    };
    const addBtn = A.btn('Add', { primary: true, write: true, onClick: () => add(addBtn) });
    // The invite exactly as it goes (members/preview), in the panel, with Back.
    const preview = () => {
      const q = wm ? 'role=coa&years=' + years : 'role=helper' + sel.map(k => '&committees[]=' + encodeURIComponent(k)).join('') + (head.checked ? '&head=1' : '');
      A.api('GET', '/years/' + y + '/members/preview?' + q).then(t => {
        const f = h('iframe', { title: 'Invite preview', sandbox: '', class: 'ap-mailframe' });
        f.srcdoc = t.html;
        sp.open({ title: t.subject, line: 'From ' + t.from, body: [h('p', { class: 'ap-help', text: 'Each gets their own link' }), f], foot: [A.btn('Back', { icon: 'back', onClick: () => P.add(sp, Object.assign({}, o, { rows: people().map(x => ({ name: x.name, email: x.email })), cs: sel.slice(), head: head.checked, years })) })], onClose: o.onClose });
      }).catch(A.fail);
    };
    const prevBtn = h('button', { type: 'button', class: 'ap-link', text: 'Preview email', on: { click: preview } });
    const cBox = wm ? null : h('div', { class: 'ap-field' }, h('span', { text: 'Committee' }), pills(committeeKeys(), sel, { onChange: syncHead }));
    sp.open({
      title: wm ? 'Add COA member' : sel.length === 1 && o.head ? 'Add head · ' + cname(sel[0]) : 'Add people', focus: '',
      body: [
        h('div', { class: 'ap-field' }, h('span', { text: 'People' }), rowsBox, h('div', { class: 'ap-row', style: { marginTop: '6px' } }, more)),
        pasteBox,
        cBox, wm ? null : headBox,
        wm ? h('div', { class: 'ap-field' }, h('span', { text: 'Access lasts' }), yearsBox, until) : null,
        h('p', { class: 'ap-help', text: wm ? 'Each gets a sign-in link · The COA sees the whole year' : 'Each gets a sign-in link · They see their committee’s screens' }),
        h('div', { class: 'ap-row' }, prevBtn),
        err
      ],
      foot: [addBtn], onClose: o.onClose
    });
    syncHead();
  };

  /* ------------------------------------------------------------ Ask the COA (P20) */

  P.ask = function (sp, o) {
    o = o || {};
    const y = A.boot().year;
    const name = h('input', { class: 'ap-input', 'data-autofocus': '', maxlength: '60', autocomplete: 'off', 'aria-label': 'Name' });
    const email = h('input', { class: 'ap-input', type: 'email', inputmode: 'email', autocomplete: 'off', 'aria-label': 'Email' });
    const err = h('div', { class: 'ap-err', role: 'alert' });
    const send = btn => {
      if (!name.value.trim()) { err.textContent = 'Name needed'; name.focus(); return; }
      if (!/^[^\s@]+@[^\s@]+\.[a-z]{2,}$/i.test(email.value.trim())) { err.textContent = 'Email needed'; email.focus(); return; }
      btn.disabled = true;
      A.api('POST', '/years/' + y + '/members/asks', { c: o.c, name: name.value.trim(), email: email.value.trim() }).then(r => {
        A.toast('Asked the COA · ' + name.value.trim());
        sp.close();
        if (o.onDone) o.onDone(r);
      }).catch(e => { btn.disabled = false; err.textContent = (e.data && e.data.message) || 'Not sent'; });
    };
    const b = A.btn('Ask', { primary: true, write: true, onClick: () => send(b) });
    sp.open({
      title: 'Ask to add', line: cname(o.c),
      body: [
        h('label', { class: 'ap-field' }, h('span', { text: 'Name' }), name),
        h('label', { class: 'ap-field' }, h('span', { text: 'Email' }), email, h('span', { class: 'ap-help', text: 'The COA adds them · Kept until answered' })),
        h('dl', { class: 'ap-facts' }, h('dt', { text: 'Committee' }), h('dd', { text: cname(o.c) })),
        err
      ],
      foot: [b], onClose: o.onClose
    });
  };

  /* ------------------------------------------------------------ Handles money (3.8, at=money) */

  P.money = function (sp, data, o) {
    o = o || {};
    const rows = (data.members || []).filter(m => !m.removed && !m.expired && m.role === 'coa');
    const has = rows.filter(m => m.money);
    const body = [h('p', { class: 'ap-help', text: 'Sees each payment · Checks and refunds' })];
    body.push(has.length ? h('ul', { class: 'ap-list' }, has.map(m => h('li', null, h('div', { class: 'ap-item' },
      h('span', { class: 'ap-item__main' }, P.nameBtn(m.name || m.email, () => o.onOpen && o.onOpen(m), { id: m.id }), h('span', { class: 'ap-item__why', text: 'COA' })))))) : h('p', { class: 'pp-none', text: 'No one yet' }));
    rows.forEach(m => body.push(h('div', { class: 'pp-money-row' }, h('span', { class: 'ap-item__title', text: m.name || m.email }), (m.can || {}).money || A.readonly ? moneyField(m, { disabled: A.readonly, onDone: o.onChange }) : h('span', { class: 'ap-help', text: m.you ? 'Another COA member ticks it' : '' }))));
    sp.open({ title: 'Handles money', body, onClose: o.onClose });
  };
})();
