/*
 * Food (app-committees, Oct 11): Meal counts and Menus, moved into the app from the lists area's Meals
 * and reworked from its critique.
 *
 *   Meal counts  each meal by age group, worked out on the server from the registrations (the browser
 *                never gets the households). Send to caterer emails the counts with the changes since
 *                the last ones sent, and keeps what was sent; the Change column shows only while a meal
 *                still ahead has changed; during the week the meals already served fold away; a past
 *                year keeps its final count. A meal opens beside the table with the households behind
 *                its change.
 *   Menus        the caterer's whole menu pasted once, split by day and meal, then read as a document
 *                with Change on each meal (a station a line: "Savory: Pot roast · Biscuits"),
 *                as the caterer sends them; the packet and the guide show them. Saved as typed.
 */
(function () {
  'use strict';
  const A = window.OGC_APP, h = A.h, K = window.OGC_CK, O = window.OGC || {}, W = window.OGC_WP || {};

  const listsApi = (method, view, body) => A.api(method, '/lists/' + A.params().year + '/' + view, body);

  /* ================================================================ Meal counts */

  function mealsScreen(ctx) {
    let sp = null, D = null, head = null, panel = '', alive = true;
    const p = ctx.params;
    const tz = () => (head && head.tz) || 'America/Indiana/Indianapolis';
    const load = () => listsApi('GET', 'meals' + (asOf() ? '?as_of=' + asOf() : '')).then(r => { head = r.head; D = r.list || null; if (alive) draw(); }).catch(err => { if (alive) K.failed(ctx, err); });
    const asOf = () => (new URLSearchParams(location.search).get('as-of') || '');
    const ro = () => !!A.readonly || (head && head.held);

    function draw() {
      if (!sp) { A.clear(ctx.body); sp = ctx.split(); }
      A.clear(sp.main);
      if (!D) { ctx.head('Meal counts', head && head.cleared ? 'Counts only · Cleared ' + K.md(head.cleared) : '', []); sp.main.appendChild(A.empty({ title: head && head.cleared ? 'Counts only' : 'Nothing yet', inset: true })); return; }
      if (!head.set_up) { ctx.head('Meal counts', '', []); sp.main.appendChild(A.empty({ title: 'Registration not set up', line: 'The counts come from the registrations', inset: true })); return; }
      if (!D.meals.length) { ctx.head('Meal counts', '', []); sp.main.appendChild(A.empty({ title: 'No meals in the schedule', inset: true })); return; }
      // No household registered yet: no table of zeros, no Send or Export (never a zero).
      if (!head.held && !head.regs && !D.sent) { ctx.head('Meal counts', '', []); const opens = head.opens && head.today && head.opens > head.today ? 'Opens ' + K.md(head.opens) : 'The counts come from the registrations'; sp.main.appendChild(A.empty({ title: 'No registrations yet', line: opens, inset: true })); return; }
      const set = D.settings, sent = D.sent, due = set.counts_due || set.suggest_due;
      const live = D.meals.filter(m => !m.served && m.status !== 'removed');
      const changed = sent && !head.held ? D.meals.filter(m => !m.served && (m.change || m.status === 'new' || m.status === 'removed')).length : 0;
      const left = due && head.today ? O.daysBetween(head.today, due) : null;
      const fact = head.held
        ? (D.final ? 'Final sent ' + K.md(D.final.day) + ' by ' + D.final.by : sent ? 'Last sent ' + K.md(sent.day) + ' by ' + sent.by : 'Never sent')
        : K.facts([D.busiest ? D.busiest.total + ' at the busiest meal' : '', sent ? (sent.final ? 'Final sent ' : 'Sent ') + K.md(sent.day) + (sent.by ? ' by ' + sent.by : '') : 'Not sent', sent ? (changed ? K.plural(changed, 'meal') + ' changed' : 'No changes') : '',
          due && !(sent && sent.final) ? (left > 0 ? 'Due ' + K.md(due) + (left <= 30 ? ' · ' + K.plural(left, 'day') : '') : left === 0 ? 'Due today' : 'Was due ' + K.md(due)) : '']);
      const acts = [];
      // Until there's a caterer's email the one act is adding it; then sending. Mark as sent stays for
      // counts that went another way.
      if (!ro()) {
        if (set.caterer_email) acts.push(A.btn(sent && !changed ? 'Send again' : 'Send to caterer', { primary: !panel, write: true, icon: 'mail', onClick: () => openPanel('send') }));
        else acts.push(A.btn('Add caterer', { primary: !panel, write: true, onClick: () => openPanel('caterer') }), A.btn('Mark as sent', { ghost: true, write: true, title: 'Counts that went another way', onClick: () => openPanel('send') }));
      }
      acts.push(K.more('Export', [{ label: 'Download', run: () => K.fetchFile('ogc/v1/lists/' + p.year + '/meals?format=csv' + (p.as ? '&as=' + encodeURIComponent(p.as) : ''), 'meal-counts-' + p.year + '.csv').catch(() => A.toast('Not downloaded')) }, { label: 'Print', run: printMeals }], { ghost: true }));
      if (sent && sent.undo && !ro()) acts.push(A.btn('Undo', { ghost: true, write: true, title: 'Takes back the last Mark as sent', onClick: () => listsApi('POST', 'meals/undo', {}).then(() => { A.toast('Undone · Mark as sent'); load(); }).catch(A.fail) }));
      ctx.head('Meal counts', fact, acts);
      // The caterer, said once where it's used (polish: a fourth quiet link in the tool row).
      if (!head.held) sp.main.appendChild(h('div', { class: 'cm-toolbar cm-toolbar--line' },
        h('span', { class: 'ap-quiet' }, set.caterer_email ? 'To ' + set.caterer_email : 'No caterer email yet', set.counts_due ? ' · Counts due ' + K.md(set.counts_due) : ''),
        ro() || !set.caterer_email ? null : h('button', { type: 'button', class: 'ap-link', text: 'Change', on: { click: () => openPanel('caterer') } })));
      const showChange = !head.held && sent && changed > 0;
      const served = D.meals.filter(m => m.served), rest = D.meals.filter(m => !m.served);
      if (served.length && rest.length) {
        const f = h('details', { class: 'cm-fold cm-pad' }, h('summary', { text: 'Served · ' + K.plural(served.length, 'meal') }), mealTable(served, false));
        sp.main.appendChild(f);
      }
      sp.main.appendChild(h('div', { class: 'cm-scroll' }, mealTable(rest.length ? rest : served, showChange)));
      sp.main.appendChild(help());
      if (D.snacks && D.snacks.length) sp.main.appendChild(snacks());
      if (panel === 'send') sendPanel(); else if (panel === 'caterer') catererPanel(); else if (p.id) { const m = D.meals.find(x => x.key === p.id); if (m) mealPanel(m); else sp.close(true); } else sp.close(true);
    }
    const tag = (t, tone, title) => h('span', { class: 'cm-chip' + (tone ? ' cm-chip--' + tone : ''), title: title || null, text: t });
    function mealTable(list, showChange, paper) {
      const communing = (D.meals.find(m => m.from === 'communion') || {}).total || 0;
      // An age column that's 0 on every row isn't drawn (no one under 3 registered yet).
      const ages = [['adult', '12+', '12 and up · Young Folks included'], ['child', '3–11', '3 to 11'], ['baby', '<3', 'Under 3']].filter(([k]) => list.some(m => m.status !== 'removed' && +m.counts[k] > 0));
      const span = String(2 + ages.length + (showChange ? 1 : 0));
      let prev = '';
      const rows = [];
      list.forEach(m => {
        if (m.date !== prev) { rows.push(h('tr', { class: 'cm-group' }, h('td', { colspan: span, text: K.day(m.date) }))); prev = m.date; }
        const gone = m.status === 'removed', chg = m.change != null ? m.change : m.status === 'new' ? m.total : 0;
        const notes = [];
        if (m.status === 'new' && !paper) notes.push(tag('New', 'tan'));
        if (gone) notes.push(tag('Removed · was ' + (m.was.adult + m.was.child + m.was.baby), 'warn'));
        if (m.notime) notes.push(tag('No time', 'warn', 'Give the meal a time on the schedule'));
        if (m.after_final && !paper) notes.push(tag('After final', 'warn'));
        // Said once, on the communion meal: whether those communing are also in Supper's count (the
        // setting Food chooses; NOTES/questions-app.md asks Food which is true at IWU).
        if (m.from === 'communion') notes.push(h('small', { class: 'cm-sub2', text: 'Those communing · ' + (D.settings.communion_supper === 'skip' ? 'Not in Supper’s count' : 'Also in Supper’s count') }));
        const tr = h('tr', { class: (m.served ? 'is-dim' : '') + (p.id === m.key ? ' is-open' : '') },
          h('td', null, paper ? h('b', { text: m.title }) : h('button', { type: 'button', class: 'cm-rowbtn', on: { click: () => { panel = ''; A.setParams({ id: m.key }); p.id = m.key; draw(); } } }, h('span', { class: 'cm-title', text: m.title })),
            h('span', { class: 'cm-sub2', text: m.when }), notes),
          // A count of nobody is a dash, never a 0.
          ages.map(([k]) => h('td', { class: 'is-num', text: gone ? '' : +m.counts[k] ? String(m.counts[k]) : '–' })),
          h('td', { class: 'is-num is-total' }, gone ? '0' : String(m.total), m.est ? h('abbr', { class: 'cm-est', title: 'Includes ' + m.est + ' arriving or leaving that day', text: ' est.' }) : null),
          showChange ? h('td', { class: 'is-num' }, chg && !m.served ? h('b', { class: chg > 0 ? 'cm-up' : 'cm-down', text: K.signed(chg) }) : null) : null);
        rows.push(tr);
      });
      return h('table', { class: paper ? '' : 'cm-table cm-meals', 'aria-label': 'Meal counts' },
        h('thead', null, h('tr', null, h('th', { text: 'Meal' }), ages.map(([, t, tip]) => h('th', { class: 'is-num', title: tip || null, text: t })), h('th', { class: 'is-num', text: 'Total' }), showChange ? h('th', { class: 'is-num', text: 'Change' }) : null)),
        h('tbody', null, rows));
    }
    function help() {
      const any = D.meals.some(m => m.est);
      return h('ul', { class: 'cm-plain ap-help cm-pad cm-keys' },
        h('li', { text: K.facts(['Everyone registered · ' + K.plural(D.households, 'household'), K.plural(D.people, 'person', 'people'), D.elsewhere ? D.elsewhere + ' off campus' : '']) }),
        any ? h('li', { text: 'est. · Includes people arriving or leaving that day' }) : null);
    }
    function snacks() {
      const who = { preteens: 'Preteens', youngfolks: 'Young Folks', all: 'Everyone' };
      return h('div', { class: 'cm-section' }, h('h2', { class: 'ap-h2', text: 'Snacks' }),
        h('table', { class: 'cm-table' }, h('thead', null, h('tr', null, h('th', { text: 'Snack' }), h('th', { text: 'For' }), h('th', { class: 'is-num', text: 'Here that day' }))),
          h('tbody', null, D.snacks.map(x => h('tr', null, h('td', null, h('span', { class: 'cm-title', text: x.title }), h('span', { class: 'cm-sub2', text: K.day(x.date) + (x.when ? ' · ' + x.when : '') })), h('td', { text: who[x.aud] || '' }), h('td', { class: 'is-num is-total', text: String(x.count) }))))));
    }
    function openPanel(k) { panel = k; p.id = ''; A.setParams({ id: '' }); draw(); }
    function closePanel() { panel = ''; p.id = ''; A.setParams({ id: '' }); }

    function mealPanel(m) {
      const why = (m.why || []);
      sp.open({
        title: m.title + ' · ' + K.day(m.date),
        body: [
          h('dl', { class: 'ap-facts' }, h('dt', { text: 'When' }), h('dd', { text: m.when || 'No time' }), h('dt', { text: '12 and up' }), h('dd', { text: String(m.counts.adult) }), h('dt', { text: '3–11' }), h('dd', { text: String(m.counts.child) }), h('dt', { text: 'Under 3' }), h('dd', { text: String(m.counts.baby) }), h('dt', { text: 'Total' }), h('dd', null, h('b', { text: String(m.total) }), m.est ? ' · ' + m.est + ' arriving or leaving' : '')),
          D.sent && why.length ? [h('h3', { class: 'ap-label cm-sub', text: 'Since ' + K.md(D.sent.day) }), h('ul', { class: 'cm-plain' }, why.map(w => h('li', { class: 'ap-row' }, h('span', { style: { flex: '1' } }, h('b', { text: w.label }), ' · ' + w.what), h('b', { class: w.now > w.was ? 'cm-up' : 'cm-down', text: K.signed(w.now - w.was) }))))] : D.sent ? h('p', { class: 'ap-quiet', text: 'No change since ' + K.md(D.sent.day) }) : null
        ],
        onClose: () => { p.id = ''; A.setParams({ id: '' }); draw(); }
      });
    }

    function sendPanel() {
      const set = D.settings, mark = !set.caterer_email;
      const plates = D.meals.filter(m => m.status !== 'removed' && m.from !== 'communion');
      const cm = D.meals.find(m => m.from === 'communion');
      const changed = D.meals.filter(m => !m.served && (m.change || m.status === 'new' || m.status === 'removed')).length;
      const fin = h('input', { type: 'checkbox', class: 'ap-check' });
      const err = h('p', { class: 'ap-err', role: 'alert' });
      const send = A.btn(mark ? 'Mark as sent' : D.sent && !changed ? 'Send again' : 'Send', { primary: true, write: true, icon: mark ? null : 'mail', onClick: () => {
        send.disabled = true;
        listsApi('POST', 'meals/send', { how: mark ? 'mark' : 'email', final: fin.checked }).then(r => { closePanel(); A.toast(r.say || 'Sent'); load(); })
          .catch(e => { send.disabled = false; err.textContent = (e.data && e.data.message) || 'Not sent'; });
      } });
      sp.open({
        title: mark ? 'Mark as sent' : 'Send to caterer',
        body: [
          // Both numbers counted the same way (polish: 14 meals, but the plates left the communion meal out).
          h('dl', { class: 'ap-facts' },
            mark ? null : [h('dt', { text: 'To' }), h('dd', { text: set.caterer_email }), h('dt', { text: 'Copy' }), h('dd', { text: 'You' })],
            h('dt', { text: 'Meals' }), h('dd', { text: K.facts([K.plural(plates.length, 'meal'), K.plural(plates.reduce((k, m) => k + m.total, 0), 'plate'), cm ? 'Communion meal ' + cm.total : '']) }),
            D.sent ? [h('dt', { text: 'Since ' + K.md(D.sent.day) }), h('dd', { text: changed ? K.plural(changed, 'meal') + ' changed' : 'No changes' })] : null),
          h('label', { class: 'ap-switch' }, fin, 'Final count'),
          mark ? h('p', { class: 'ap-help', text: 'Add the caterer’s email to send from here' }) : null, err
        ],
        foot: [send, A.btn('Cancel', { ghost: true, onClick: () => { closePanel(); draw(); } })],
        onClose: () => { closePanel(); draw(); }
      });
    }
    function catererPanel() {
      const set = D.settings;
      const email = h('input', { class: 'ap-input', type: 'email', value: set.caterer_email, placeholder: 'orders@caterer.example', autocomplete: 'off', 'data-autofocus': '' });
      const due = h('input', { class: 'ap-input', type: 'date', value: set.counts_due });
      let supper = set.communion_supper;
      const pills = h('div');
      const drawPills = () => A.clear(pills).appendChild(K.pills([['all', 'Everyone'], ['skip', 'Not those communing']], supper, v => { supper = v; drawPills(); }, 'Supper on communion day'));
      drawPills();
      const err = h('p', { class: 'ap-err', role: 'alert' });
      sp.open({
        title: 'Caterer',
        body: [
          h('label', { class: 'ap-field' }, h('span', { text: 'Email' }), email, h('span', { class: 'ap-help', text: 'Members only · Never shown to households' })),
          h('label', { class: 'ap-field' }, h('span', { text: 'Counts due' }), due, set.suggest_due ? h('span', { class: 'ap-help', text: 'Two weeks before is ' + K.md(set.suggest_due) }) : null),
          D.communion ? h('div', { class: 'ap-field' }, h('span', { text: 'Supper on communion day', title: 'Those communing eat the communion meal instead' }), pills) : null, err
        ],
        foot: [A.btn('Save', { primary: true, write: true, onClick: () => listsApi('PUT', 'settings', { caterer_email: email.value, counts_due: due.value, communion_supper: supper }).then(() => { closePanel(); A.toast('Saved · Caterer'); load(); }).catch(e => { err.textContent = (e.data && e.data.message) || 'Not saved'; }) }),
          A.btn('Cancel', { ghost: true, onClick: () => { closePanel(); draw(); } })],
        onClose: () => { closePanel(); draw(); }
      });
    }
    function printMeals() {
      listsApi('POST', 'printed', { view: 'meals' }).catch(() => {});
      const any = D.meals.some(m => m.est);
      K.print({ title: 'Meal counts', sub: D.sent ? 'Sent ' + K.md(D.sent.day) : '', who: 'Food', build: () => h('div', null, mealTable(D.meals.filter(m => m.status !== 'removed'), false, true),
        h('p', { class: 'cm-key', text: K.facts(['12 and up includes Young Folks', any ? 'est. includes people arriving or leaving that day' : '']) })) });
    }

    load();
    const t = setInterval(() => { if (!document.hidden && !panel) load(); }, 120000);
    return () => { alive = false; clearInterval(t); ctx.body.classList.remove('ap-body--flush'); };
  }

  /* ================================================================ Menus */

  // menus.csv: day, meal, station, items ("Pot roast · Biscuits").
  function menusScreen(ctx) {
    const p = ctx.params;
    let file = null, meals = [], prev = null, alive = true;
    const ro = () => !!A.readonly;
    const keyOf = (day, meal) => (day + '|' + meal).toLowerCase();
    const toText = rows => rows.map(r => (r.station ? r.station + ': ' : '') + (r.items || '')).join('\n');
    const fromText = (day, meal, text) => String(text || '').split(/\n+/).map(l => l.trim()).filter(Boolean).map(l => {
      const m = /^([^:]{1,40}):\s*(.*)$/.exec(l);
      return { day, meal, station: m ? m[1].trim() : '', items: (m ? m[2] : l).split(/\s*[·;,]\s*|\s{2,}/).filter(Boolean).join(' · ') };
    });
    const load = () => Promise.all([
      A.api('GET', '/years/' + p.year + '/files/menus?format=json'),
      A.api('GET', '/lists/' + p.year + '/meals').catch(() => null),
      A.api('GET', '/years/' + (p.year - 1) + '/files/menus?format=json').catch(() => null)
    ]).then(([f, m, pv]) => {
      file = { rows: (f && f.rows) || [], version: f ? f.version : 0, cols: (f && f.cols && f.cols.length) ? f.cols : ['day', 'meal', 'station', 'items'] };
      const days = (m && m.head && m.head.start) ? K.days(m.head.start, m.head.end) : [];
      const name = d => (days.find(x => x.date === d) || {}).name || '';
      meals = m && m.list ? m.list.meals.filter(x => x.status !== 'removed' && x.from !== 'communion').map(x => ({ day: name(x.date), meal: x.title.replace(/\s*\(.*\)\s*$/, ''), date: x.date, when: x.when })) : [];
      // Meals in the file the schedule doesn't have (yet) still show.
      file.rows.forEach(r => { if (r.day && r.meal && !meals.some(x => keyOf(x.day, x.meal) === keyOf(r.day, r.meal))) meals.push({ day: r.day, meal: r.meal, date: '', when: '' }); });
      prev = pv && pv.rows && pv.rows.length ? pv.rows : null;
      if (alive) draw();
    }).catch(err => { if (alive) K.failed(ctx, err); });
    const save = (rows, words) => A.api('PUT', '/years/' + p.year + '/files/menus', { rows, version: file.version, cols: file.cols }).then(r => {
      file.rows = rows; file.version = r && r.version != null ? r.version : file.version + 1;
      A.toast(words); draw();
    }).catch(e => { if (e.status === 409) { A.toast('Changed by another member · Reloaded'); load(); } else A.fail(e); });
    // One way in: the caterer's whole menu, pasted, split by day and meal; then read as a document,
    // each meal with Change. No copying last year's (old menus could pass for this year's).
    const DAYS = ['Friday', 'Saturday', 'Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday'];
    const MEALS = ['Breakfast', 'Lunch', 'Supper', 'Dinner', 'Snack'];
    const meal1 = x => x === 'Dinner' ? 'Supper' : x;
    function readMenu(t) {
      const out = []; let day = '', meal = '';
      String(t).split(/\r?\n/).map(l => l.trim()).filter(Boolean).forEach(l => {
        const dd = DAYS.find(x => new RegExp('^' + x + '\\b', 'i').test(l));
        if (dd) { day = dd; meal = ''; const rest = l.slice(dd.length).replace(/^[,:\s]+/, ''); const mm = MEALS.find(x => new RegExp('^' + x + '\\b', 'i').test(rest)); if (mm) meal = meal1(mm); return; }
        const mm = MEALS.find(x => new RegExp('^' + x + '\\b', 'i').test(l));
        if (mm && l.length < 24) { meal = meal1(mm); return; }
        if (!day || !meal) return;
        out.push(fromText(day, meal, l)[0]);
      });
      return out.filter(Boolean);
    }
    let pasting = false, changing = '';
    function pasteBox() {
      const t = h('textarea', { class: 'ap-textarea cm-paste', rows: '10', 'aria-label': 'The menu, as the caterer sent it', placeholder: 'Friday\nSupper\nStation: dish · dish' });
      const err = h('div', { class: 'ap-err', role: 'alert' });
      const prevBox = h('div');
      let rows = [];
      const read = A.btn('Read it', { primary: true, write: true, onClick: () => {
        rows = readMenu(t.value);
        A.clear(prevBox);
        if (!rows.length) { err.textContent = 'No day and meal found · Start with the day, then the meal'; return; }
        err.textContent = '';
        const n = new Set(rows.map(r => keyOf(r.day, r.meal))).size;
        prevBox.append(h('p', { class: 'ap-quiet', text: K.plural(n, 'meal') + ' · ' + K.plural(rows.length, 'station') + (file.rows.length ? ' · Replaces those meals' : '') }),
          h('div', { class: 'ap-row' }, A.btn('Use this menu', { primary: true, write: true, onClick: () => {
            const keys = new Set(rows.map(r => keyOf(r.day, r.meal)));
            pasting = false;
            save(file.rows.filter(r => !keys.has(keyOf(r.day, r.meal))).concat(rows), 'Menu · ' + K.plural(n, 'meal'));
          } }), A.btn('Cancel', { ghost: true, onClick: () => { pasting = false; draw(); } })));
        read.classList.remove('ap-btn--primary');
      } });
      setTimeout(() => t.focus(), 0);
      return h('section', { class: 'ap-section cm-pastebox' }, h('label', { class: 'ap-field' }, h('span', { text: 'The menu, as the caterer sent it' }), t,
        h('span', { class: 'ap-help', text: 'A day’s name, then each meal, then a station a line: Station: dish · dish' })), err,
        h('div', { class: 'ap-row' }, read, A.btn('Cancel', { ghost: true, onClick: () => { pasting = false; draw(); } })), prevBox);
    }
    function draw() {
      A.clear(ctx.body);
      const withMenu = meals.filter(m => file.rows.some(r => keyOf(r.day, r.meal) === keyOf(m.day, m.meal)));
      const acts = ro() || pasting ? [] : [A.btn(file.rows.length ? 'Paste a newer menu' : 'Paste menu', { primary: !file.rows.length, write: true, onClick: () => { pasting = true; draw(); } })];
      ctx.head('Menus', !meals.length ? '' : withMenu.length ? withMenu.length + ' of ' + K.plural(meals.length, 'meal') + ' with a menu' : 'Waiting for the caterer', acts);
      if (!meals.length) { ctx.body.appendChild(A.empty({ title: 'No meals in the schedule', line: 'Menus follow the schedule’s meals' })); return; }
      if (pasting) ctx.body.appendChild(pasteBox());
      else if (!file.rows.length) { ctx.body.appendChild(A.empty({ title: 'Waiting for the caterer', line: 'Paste the whole menu as sent · Split by day and meal' })); return; }
      const doc = h('div', { class: 'cm-menudoc' });
      let prevDay = '';
      // Meals the caterer hasn't sent a menu for are one line, opened to add one (never ten "No menu yet").
      const has = m => file.rows.some(r => keyOf(r.day, r.meal) === keyOf(m.day, m.meal));
      const without = meals.filter(m => !has(m) && changing !== keyOf(m.day, m.meal));
      const fold = without.length > 1 ? h('details', { class: 'cm-fold cm-nomenu' }, h('summary', null, K.plural(without.length, 'meal') + ' without a menu', h('span', { class: 'ap-quiet', text: ' · Paste the caterer’s menu above, or add one here' }))) : null;
      meals.forEach(m => {
        const into = fold && without.indexOf(m) > -1 ? fold : doc;
        if (into === doc && m.day !== prevDay) { doc.appendChild(h('h2', { class: 'ap-label cm-sub', text: m.date ? K.day(m.date) : m.day })); prevDay = m.day; }
        const k = keyOf(m.day, m.meal);
        const rows = file.rows.filter(r => keyOf(r.day, r.meal) === k);
        const headRow = h('div', { class: 'cm-menurow__h' }, h('b', { text: m.meal }), m.when ? h('span', { class: 'ap-quiet', text: m.when }) : null,
          ro() || changing === k ? null : h('button', { type: 'button', class: 'ap-link', text: rows.length ? 'Change' : 'Add', on: { click: () => { changing = k; draw(); } } }));
        if (changing === k) {
          const ta = h('textarea', { class: 'ap-textarea cm-menu', rows: String(Math.max(3, rows.length + 1)), value: toText(rows), placeholder: 'Station: dish · dish', 'aria-label': m.meal + ', ' + m.day });
          setTimeout(() => ta.focus(), 0);
          doc.appendChild(h('div', { class: 'cm-menurow' }, headRow, h('div', null, ta, h('div', { class: 'ap-row', style: { marginTop: '8px' } },
            A.btn('Save', { primary: true, write: true, onClick: () => {
              const mine = fromText(m.day, m.meal, ta.value);
              changing = '';
              save(file.rows.filter(r => keyOf(r.day, r.meal) !== k).concat(mine), m.meal + ' · ' + m.day + ' · ' + (mine.length ? K.plural(mine.length, 'station') : 'No menu'));
            } }), A.btn('Cancel', { ghost: true, onClick: () => { changing = ''; draw(); } })))));
          return;
        }
        if (into !== doc) { headRow.insertBefore(h('span', { class: 'ap-quiet', text: (m.date ? K.day(m.date) : m.day) + ' · ' }), headRow.firstChild); into.appendChild(h('div', { class: 'cm-menurow cm-menurow--one' }, headRow)); return; }
        doc.appendChild(h('div', { class: 'cm-menurow' }, headRow, rows.length
          ? h('ul', { class: 'cm-menulist' }, rows.map(r => h('li', null, r.station ? h('span', { class: 'cm-menulist__st', text: r.station + ': ' }) : null, r.items)))
          : h('p', { class: 'ap-quiet', text: 'No menu yet' })));
      });
      if (fold) doc.appendChild(fold);
      ctx.body.appendChild(doc);
    }
    K.loading(ctx);
    load();
    return () => { alive = false; };
  }

  A.screen({ id: 'food-meals', title: 'Meal counts', icon: 'report', section: 'own', who: ['food'], render: mealsScreen });
  A.screen({ id: 'food-menus', title: 'Menus', icon: 'note', section: 'own', who: ['food'], render: menusScreen });
  A.action({ id: 'food-send', title: 'Send meal counts', screen: 'food-meals', run: () => A.go({ s: 'food-meals', id: '' }) });
})();
