/*
 * Food (app-committees, Oct 11): Meal counts and Menus, moved into the app from the lists area's Meals
 * and reworked from its critique.
 *
 *   Meal counts  each meal by age group, worked out on the server from the registrations (the browser
 *                never gets the households). Send to caterer emails the counts with the changes since
 *                the last ones sent, and keeps what was sent; the Change column shows only while a meal
 *                still ahead has changed; during the week the meals already served fold away; a past
 *                year keeps its final count. A meal opens beside the table with the households behind
 *                its change. Every send is kept, and listed under the counts (Sent to the caterer),
 *                each downloadable for Excel exactly as it went: the record (lists area, Oct 13).
 *   Menus        the caterer's whole menu pasted once, split by day and meal, then read as a document
 *                with Change on each meal (a station a line: "Savory: Pot roast · Biscuits"),
 *                as the caterer sends them; the packet and the guide show them. Saved as typed.
 */
(function () {
  'use strict';
  const A = window.OGC_APP, h = A.h, K = window.OGC_CK, O = window.OGC || {}, W = window.OGC_WP || {};

  const listsApi = (method, view, body) => A.api(method, '/lists/' + A.params().year + '/' + view, body);

  /* ================================================================ Meal counts */

  function mealsScreen(ctx) {
    let sp = null, D = null, head = null, alive = true;
    const p = ctx.params;
    // A part or an act named in the address (Round 6): at=send (Home's Send counts, the COA's Final
    // counts line), at=caterer (Add caterer), at=sent (the Sent list).
    let panel = ({ send: 'send', caterer: 'caterer', sent: 'sent' })[p.at] || '';
    const tz = () => (head && head.tz) || 'America/Indiana/Indianapolis';
    const load = () => listsApi('GET', 'meals' + (asOf() ? '?as_of=' + asOf() : '')).then(r => { head = r.head; D = r.list || null; if (alive) draw(); }).catch(err => { if (alive) K.failed(ctx, err); });
    const asOf = () => (new URLSearchParams(location.search).get('as-of') || '');
    const ro = () => !!A.readonly || (head && head.held);
    const WD = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
    const dayKey = iso => WD[new Date(String(iso).slice(0, 10) + 'T12:00:00Z').getUTCDay()];

    function draw() {
      if (!sp) { A.clear(ctx.body); sp = ctx.split(); }
      A.clear(sp.main);
      if (!D) { ctx.head('Meal counts', head && head.cleared ? 'Counts only · Cleared ' + K.md(head.cleared) : '', []); sp.main.appendChild(A.empty({ title: head && head.cleared ? 'Counts only' : 'Nothing yet', inset: true })); return; }
      if (!head.set_up) { ctx.head('Meal counts', '', []); sp.main.appendChild(A.empty({ title: 'Registration not set up', line: 'The counts come from the registrations', inset: true })); return; }
      if (!D.meals.length) { ctx.head('Meal counts', '', []); sp.main.appendChild(A.empty({ title: 'No meals on the schedule', line: 'Kind Meal · For Everyone or Conference', inset: true })); return; }
      const set = D.settings, sent = D.sent;
      // No household registered yet: no table of zeros, no Send or Export (never a zero). Add caterer is
      // still the one thing to do.
      if (!head.held && !head.regs && !sent) {
        ctx.head('Meal counts', '', set.caterer_email || ro() ? [] : [A.btn('Add caterer', { primary: true, write: true, onClick: () => openPanel('caterer') })]);
        const opens = head.opens && head.today && head.opens > head.today ? 'Opens ' + K.md(head.opens) : 'The counts come from the registrations';
        sp.main.appendChild(A.empty({ title: 'No registrations yet', line: K.facts([opens, K.plural(D.meals.length, 'meal') + ' on the schedule']), inset: true }));
        if (panel === 'caterer') catererPanel();
        return;
      }
      // The title row's fact is the list's own (module-lists-facts.php: the same words as Food's Work row
      // and the COA's Final counts line); its "N meals changed" is a door to exactly those meals.
      const n = D.changed || 0;
      const fact = h('span', null, (D.fact.head || '').split(' · ').map((t, i) => {
        const bit = /meals? changed$/.test(t) && n ? Object.assign(A.link({ v: 'changed' }, t, 'ap-head__factlink'), {}) : t;
        if (bit !== t) bit.setAttribute('data-n', String(n));
        return [i ? ' · ' : '', bit];
      }));
      const acts = [];
      acts.push(A.btn('Print', { ghost: true, icon: 'file', onClick: printMeals }));
      acts.push(K.more('Export', [{ label: 'Excel', run: () => K.excel('lists/' + p.year + '/meals', p.year + ' Meal counts', p.as) }], { ghost: true }));
      if (D.sends && D.sends.length) acts.push(A.btn('Sent · ' + D.sends.length, { ghost: true, onClick: () => openPanel('sent') }));
      const more = [];
      if (set.caterer_email) {
        more.push({ label: 'Caterer', disabled: ro(), run: () => openPanel('caterer') });
        more.push({ label: 'Mark as sent', disabled: ro(), hint: 'Counts phoned in or handed over', run: () => openPanel('mark') });
        if (sent && !n) more.push({ label: 'Send again', disabled: ro(), run: () => openPanel('send') });
      }
      if (sent && sent.undo && sent.mine) more.push({ label: 'Undo mark as sent', disabled: ro(), run: () => listsApi('POST', 'meals/undo' + (asOf() ? '?as_of=' + asOf() : ''), {}).then(() => { A.toast('Undone · Mark as sent'); load(); }).catch(A.fail) });
      if (more.length) acts.push(K.more('More', more, { ghost: true }));
      // One filled act: Add caterer until there's an email (Mark as sent beside it, quiet); then Send to
      // caterer while nothing is sent or a meal changed since; nothing filled when nothing is due.
      if (!head.held) {
        if (!set.caterer_email) acts.push(A.btn('Mark as sent', { ghost: true, write: true, title: 'Counts that went another way', onClick: () => openPanel('mark') }), A.btn('Add caterer', { primary: !panel, write: true, onClick: () => openPanel('caterer') }));
        else if (!sent || n) acts.push(A.btn('Send to caterer', { primary: !panel, write: true, icon: 'mail', onClick: () => openPanel('send') }));
      }
      ctx.head('Meal counts', fact, acts);
      if (!head.held) sp.main.appendChild(h('div', { class: 'cm-toolbar cm-toolbar--line' },
        h('span', { class: 'ap-quiet' }, set.caterer_email ? 'To ' + set.caterer_email : 'No caterer yet'),
        ro() || !set.caterer_email ? null : h('button', { type: 'button', class: 'ap-link', text: 'Change', on: { click: () => openPanel('caterer') } })));
      // Views: All, and Changed since sent (after a send, while any meal still ahead changed).
      const chg = p.v === 'changed';
      const live = D.meals.filter(m => m.status !== 'removed' && m.from !== 'communion');
      if (sent && (n || chg)) sp.main.appendChild(h('div', { class: 'cm-toolbar' }, A.views([{ id: '', label: 'All', n: live.length }, { id: 'changed', label: 'Changed since sent', n }], chg ? 'changed' : '', id => A.go({ v: id }))));
      const list = chg ? D.meals.filter(m => m.changed) : D.meals;
      if (chg && !list.length) { sp.main.appendChild(A.empty({ title: 'No changes since ' + K.md(sent.day), inset: true, action: A.link({ v: '' }, 'All', 'ap-btn') })); afterDraw(list); return; }
      const showChange = !head.held && sent && n > 0;
      const served = list.filter(m => m.served), rest = list.filter(m => !m.served);
      if (served.length && rest.length) {
        const f = h('details', { class: 'cm-fold cm-pad' }, h('summary', { text: 'Served · ' + K.plural(served.length, 'meal') }), mealTable(served, false));
        sp.main.appendChild(f);
      }
      sp.main.appendChild(h('div', { class: 'cm-scroll' }, mealTable(rest.length ? rest : served, showChange)));
      sp.main.appendChild(help());
      if (D.snacks && D.snacks.length && !chg) sp.main.appendChild(snacks());
      afterDraw(list);
    }
    function afterDraw(list) {
      if (panel === 'send' || panel === 'mark') sendPanel();
      else if (panel === 'caterer') catererPanel();
      else if (panel === 'sent' && D.sends && D.sends.length) sentPanel();
      else if (p.id) { const m = D.meals.find(x => x.key === p.id || (x.row && x.row === p.id && x.date >= (head.today || ''))) || D.meals.find(x => x.row && x.row === p.id); if (m) mealPanel(m, list); else sp.close(true); }
      else sp.close(true);
    }
    const tag = (t, tone, title) => h('span', { class: 'cm-chip' + (tone ? ' cm-chip--' + tone : ''), title: title || null, text: t });
    function mealTable(list, showChange, paper) {
      // An age column that's 0 on every row isn't drawn (no one under 3 registered yet).
      const ages = [['adult', '12+', '12 and up · Young Folks included'], ['child', '3–11', '3 to 11'], ['baby', '<3', 'Under 3']].filter(([k]) => list.some(m => m.status !== 'removed' && +m.counts[k] > 0));
      // Arriving or leaving: its own column, the plain number. Drawn only when some meal has one.
      const arr = list.some(m => m.status !== 'removed' && m.est);
      const span = String(2 + ages.length + (arr ? 1 : 0) + (showChange ? 1 : 0));
      let prev = '';
      const rows = [];
      list.forEach(m => {
        if (m.date !== prev) { rows.push(h('tr', { class: 'cm-group' }, h('td', { colspan: span, text: K.day(m.date) }))); prev = m.date; }
        const gone = m.status === 'removed', chg = m.change != null ? m.change : m.status === 'new' ? m.total : 0;
        const notes = [];
        if (m.status === 'new' && !paper) notes.push(tag('New', 'tan'));
        if (gone) notes.push(tag('Removed · was ' + (m.was.adult + m.was.child + m.was.baby), 'warn'));
        if (m.notime) notes.push(tag('No time', 'warn', 'Give the meal a time on the schedule'));
        if (m.after_final && !paper) notes.push(tag('After final', 'warn'));
        // Said once, on the communion meal: whether those communing are also in Supper's count.
        if (m.from === 'communion') notes.push(h('small', { class: 'cm-sub2', text: 'Those communing · ' + (D.settings.communion_supper === 'skip' ? 'Not in Supper’s count' : 'Also in Supper’s count') }));
        if (m.from === 'communion' && m.not_asked) notes.push(paper ? h('small', { class: 'cm-sub2', text: 'Not asked of ' + m.not_asked + ' households' }) : tag(m.not_asked + ' households not asked', 'warn', 'From the Lodging Form, which doesn’t ask about communion · Not in this number'));
        const tr = h('tr', { 'data-key': m.key, class: (m.served ? 'is-dim' : '') + (paper ? '' : ' cm-tap') + (p.id === m.key ? ' is-open' : '') },
          h('td', null, paper ? [h('b', { text: m.title }), m.when ? ' · ' + m.when : ''] : h('button', { type: 'button', class: 'cm-rowbtn', on: { click: e => { e.stopPropagation(); openMeal(m); } } }, h('span', { class: 'cm-title', text: m.title })),
            paper ? null : h('span', { class: 'cm-sub2', text: m.when }), notes),
          // A count of nobody is a dash, never a 0.
          ages.map(([k]) => h('td', { class: 'is-num', text: gone ? '' : +m.counts[k] ? String(m.counts[k]) : '–' })),
          h('td', { class: 'is-num is-total', text: gone ? '0' : String(m.total) }),
          arr ? h('td', { class: 'is-num', text: !gone && m.est ? String(m.est) : '–' }) : null,
          showChange ? h('td', { class: 'is-num' }, chg && !m.served ? h('b', { class: chg > 0 ? 'cm-up' : 'cm-down', text: K.signed(chg) }) : null) : null);
        if (!paper) tr.addEventListener('click', () => openMeal(m));
        rows.push(tr);
      });
      return h('table', { class: paper ? '' : 'cm-table cm-meals', 'aria-label': 'Meal counts' },
        h('thead', null, h('tr', null, h('th', { text: 'Meal' }), ages.map(([, t, tip]) => h('th', { class: 'is-num', title: tip || null, text: t })), h('th', { class: 'is-num', text: 'Total' }),
          arr ? h('th', { class: 'is-num cm-th-wrap', title: 'In the total · Counted for every meal that day: the form doesn’t ask their first and last meal', text: 'Arriving or leaving' }) : null,
          showChange ? h('th', { class: 'is-num', text: 'Change' }) : null)),
        h('tbody', null, rows));
    }
    function help() {
      const any = D.meals.some(m => m.est);
      return h('ul', { class: 'cm-plain ap-help cm-pad cm-keys' },
        h('li', { text: K.facts([head.as_of ? 'Counts as of ' + head.as_of : '', K.plural(D.households, 'household'), K.plural(D.people, 'person', 'people'), D.elsewhere ? D.elsewhere + ' off campus' : '']) }),
        any ? h('li', { text: 'Arriving or leaving · In the total, counted for every meal that day · The form doesn’t ask their first and last meal' }) : null);
    }
    function snacks() {
      const who = { preteens: 'Preteens', youngfolks: 'Young Folks', all: 'Everyone' };
      return h('div', { class: 'cm-section' }, h('h2', { class: 'ap-h2' }, 'Snacks', h('span', { class: 'ap-h2__n cm-h2-note', title: 'Send to caterer carries the meals only', text: 'Not sent to the caterer' })),
        h('table', { class: 'cm-table' }, h('thead', null, h('tr', null, h('th', { text: 'Snack' }), h('th', { text: 'For' }), h('th', { class: 'is-num', text: 'Here that day' }))),
          h('tbody', null, D.snacks.map(x => h('tr', null, h('td', null, h('span', { class: 'cm-title', text: x.title }), h('span', { class: 'cm-sub2', text: K.day(x.date) + (x.when ? ' · ' + x.when : '') })), h('td', { text: who[x.aud] || '' }), h('td', { class: 'is-num is-total', text: String(x.count) }))))));
    }
    function openPanel(k) { panel = k; p.id = ''; A.setParams({ id: '', at: k === 'sent' ? 'sent' : '' }); draw(); }
    function closePanel() { panel = ''; p.id = ''; A.setParams({ id: '', at: '' }); }
    function openMeal(m) { panel = ''; p.id = m.key; A.setParams({ id: m.key, at: '' }); draw(); }

    /*
     * A meal (area-committee-lists 2.5): read only. Food sees why it moved as counts by reason; the COA
     * sees the households by name, each a door to the household (L5, on the server). Linked: its schedule
     * row (for whoever may open Schedule), and for the communion meal, Communing (the COA). History: its
     * total in every send it was in.
     */
    function mealPanel(m, list) {
      const why = m.why || [];
      const flat = list.filter(x => x.status !== 'removed' || x.key === m.key);
      const i = flat.indexOf(m);
      const state = m.status === 'removed' ? 'Removed' : m.served ? 'Served' : m.after_final ? 'After final' : m.status === 'new' ? 'New' : D.sent ? (m.changed ? 'Changed since ' + K.md(D.sent.day) : 'Same as sent') : '';
      const linked = [];
      if (m.row && A.allowed('schedule')) linked.push({ kind: 'schedule', label: 'Schedule row · ' + m.title + ' ' + K.day(m.date).slice(0, 3) + (m.when ? ' ' + m.when.split('–')[0] : ''), go: { s: 'schedule', v: dayKey(m.date), id: m.row } });
      if (m.from === 'communion' && A.allowed('communion-list')) linked.push({ kind: 'communing', label: 'Communing · ' + m.total, go: { s: 'communion-list' } });
      const reasons = D.sent && !m.served && why.length ? h('section', null, h('h3', { class: 'ap-rec__h', text: 'Since ' + K.md(D.sent.day) }),
        h('ul', { class: 'cm-plain' }, why.map(w => D.names
          ? h('li', { class: 'ap-row' }, h('span', { style: { flex: '1' } }, A.link({ s: 'households', id: w.rid }, w.label), ' · ' + w.what), h('b', { class: w.now > w.was ? 'cm-up' : 'cm-down', text: K.signed(w.now - w.was) }))
          : h('li', { class: 'ap-row' }, h('span', { style: { flex: '1' } }, h('b', { text: w.what }), ' · ' + K.plural(w.households, 'household')), h('b', { class: w.change > 0 ? 'cm-up' : 'cm-down', text: K.signed(w.change) }))))) : D.sent && !m.served ? h('p', { class: 'ap-quiet', text: 'No change since ' + K.md(D.sent.day) }) : null;
      sp.open({
        title: m.title + ' · ' + K.day(m.date),
        line: K.facts([m.when || 'No time', m.place]),
        tags: state ? [h('span', { class: 'ap-tag' + (/Changed|New|After/.test(state) ? ' ap-tag--tan' : ''), text: state })] : null,
        nav: { prev: i > 0 ? () => openMeal(flat[i - 1]) : null, next: i > -1 && i < flat.length - 1 ? () => openMeal(flat[i + 1]) : null },
        body: [
          m.status === 'removed'
            ? h('p', { class: 'ap-quiet', text: 'Was ' + (m.was.adult + m.was.child + m.was.baby) + ' · Removed from the schedule since ' + K.md(D.sent.day) })
            : h('dl', { class: 'ap-facts' }, h('dt', { text: '12 and up' }), h('dd', { text: String(m.counts.adult) }), m.from === 'communion' ? null : [h('dt', { text: '3–11' }), h('dd', { text: String(m.counts.child) }), h('dt', { text: 'Under 3' }), h('dd', { text: String(m.counts.baby) })],
              h('dt', { text: 'Total' }), h('dd', null, h('b', { text: String(m.total) }), m.est ? ' · ' + m.est + ' arriving or leaving' : '')),
          reasons,
          linked.length ? A.linked(linked, { from: 'food-meals:' + m.key, name: m.title + ' ' + K.day(m.date) }) : null,
          A.history(m.hist)
        ],
        onClose: () => { p.id = ''; A.setParams({ id: '' }); draw(); }, focus: 'head'
      });
    }

    function sendPanel() {
      const set = D.settings, mark = panel === 'mark' || !set.caterer_email;
      if (ro()) { panel = ''; sp.close(true); return; }
      const plates = D.meals.filter(m => m.status !== 'removed' && m.from !== 'communion');
      const cm = D.meals.find(m => m.from === 'communion');
      const changed = D.changed || 0;
      const fin = h('input', { type: 'checkbox', class: 'ap-check' });
      const err = h('p', { class: 'ap-err', role: 'alert' });
      // A Final is asked once: ticked, the button becomes "Send final" with a line on what it means.
      const word = mark ? 'Mark as sent' : D.sent && !changed ? 'Send again' : 'Send';
      const finLine = h('p', { class: 'ap-help', hidden: true, text: 'Final count · Later changes show as After final' + (mark ? '' : ' · An email can’t be taken back') });
      let armed = false;
      const label = t => { send.lastChild.nodeValue = t; };
      fin.addEventListener('change', () => { armed = false; finLine.hidden = !fin.checked; label(fin.checked ? (mark ? 'Mark as final' : 'Send final') : word); });
      const send = A.btn(word, { primary: true, write: true, icon: mark ? null : 'mail', onClick: () => {
        if (fin.checked && !armed) { armed = true; finLine.hidden = false; label('Final count · ' + (mark ? 'Mark' : 'Send')); return; }
        send.disabled = true;
        listsApi('POST', 'meals/send' + (asOf() ? '?as_of=' + asOf() : ''), { how: mark ? 'mark' : 'email', final: fin.checked }).then(r => { closePanel(); A.toast(r.say || 'Sent'); load(); })
          .catch(e => { send.disabled = false; err.textContent = (e.data && e.data.message) || 'Not sent'; });
      } });
      sp.open({
        title: mark ? 'Mark as sent' : 'Send to caterer',
        line: mark ? 'Kept as sent · Emails no one' : 'Kept as sent',
        body: [
          h('dl', { class: 'ap-facts' },
            mark ? null : [h('dt', { text: 'To' }), h('dd', { text: set.caterer_email }), h('dt', { text: 'Copy' }), h('dd', { text: 'You' })],
            h('dt', { text: 'Meals' }), h('dd', { text: K.facts([K.plural(plates.length, 'meal'), (x => x.toLocaleString('en-US') + (x === 1 ? ' plate' : ' plates'))(plates.reduce((k, m) => k + m.total, 0)), cm ? 'Communion meal ' + cm.total + (cm.not_asked ? ' (' + cm.not_asked + ' households not asked)' : '') : '']) }),
            D.sent ? [h('dt', { text: 'Since ' + K.md(D.sent.day) }), h('dd', { text: changed ? K.plural(changed, 'meal') + ' changed' : 'No changes' })] : null),
          h('label', { class: 'ap-switch' }, fin, 'Final count'), finLine,
          mark ? h('p', { class: 'ap-help' }, set.caterer_email ? 'Counts phoned in or handed over · Nothing is emailed' : ['No caterer email · ', h('button', { type: 'button', class: 'ap-link', text: 'Add caterer', on: { click: () => openPanel('caterer') } })]) : null, err
        ],
        foot: [send, A.btn('Cancel', { ghost: true, onClick: () => { closePanel(); draw(); } })],
        onClose: () => { closePanel(); draw(); }
      });
    }
    function catererPanel() {
      const set = D.settings;
      if (ro()) { panel = ''; sp.close(true); return; }
      const email = h('input', { class: 'ap-input', type: 'email', value: set.caterer_email, placeholder: 'orders@caterer.example', autocomplete: 'off', 'data-autofocus': '' });
      const due = h('input', { class: 'ap-input', type: 'date', value: set.counts_due || D.due || '' });
      let supper = set.communion_supper;
      const pills = h('div');
      const drawPills = () => A.clear(pills).appendChild(K.pills([['all', 'Everyone'], ['skip', 'Not those communing']], supper, v => { supper = v; drawPills(); }, 'Supper on communion day'));
      drawPills();
      const err = h('p', { class: 'ap-err', role: 'alert' });
      sp.open({
        title: 'Caterer',
        body: [
          h('label', { class: 'ap-field' }, h('span', { text: 'Email' }), email, h('span', { class: 'ap-help', text: 'Members only · Never shown to households' })),
          h('label', { class: 'ap-field' }, h('span', { text: 'Counts due' }), due, h('span', { class: 'ap-help', text: 'Also the task Final meal counts to the caterer' })),
          D.communion ? h('div', { class: 'ap-field' }, h('span', { text: 'Supper on communion day', title: 'Those communing eat the communion meal instead' }), pills) : null, err
        ],
        foot: [A.btn('Save', { primary: true, write: true, onClick: () => listsApi('PUT', 'settings' + (asOf() ? '?as_of=' + asOf() : ''), { caterer_email: email.value, counts_due: due.value, communion_supper: supper }).then(() => { closePanel(); A.toast('Saved · Caterer'); load(); }).catch(e => { err.textContent = (e.data && e.data.message) || 'Not saved'; }) }),
          A.btn('Cancel', { ghost: true, onClick: () => { closePanel(); draw(); } })],
        onClose: () => { closePanel(); draw(); }
      });
    }
    /*
     * Sent to the caterer (Lodging's Counts' shape, Round 5): every send kept, newest first: the day, who,
     * how, Final, the meals and plates, what changed since the one before; each printed or downloaded
     * exactly as it went (lists/{y}/meals/sent?at=).
     */
    function sentPanel() {
      const num = x => Number(x || 0).toLocaleString('en-US');
      sp.open({
        title: 'Sent · ' + D.sends.length, line: 'Every send is kept',
        body: h('ul', { class: 'cm-sent' }, D.sends.map((s, i) => h('li', null,
          h('p', null, h('b', { text: K.md(s.day) }), ' · ' + K.facts([s.by, s.how === 'email' ? 'Emailed to ' + (s.to || 'the caterer') : 'Marked as sent']), s.final ? [' ', tag('Final', 'tan')] : null),
          h('p', { class: 'ap-quiet', text: K.facts([K.plural(s.meals, 'meal'), num(s.plates) + (s.plates === 1 ? ' plate' : ' plates'), s.change ? (s.change > 0 ? '+' : '−') + num(Math.abs(s.change)) + ' since the one before' : '']) }),
          i === 0 ? h('p', { class: D.changed ? 'cm-sent__ch' : 'ap-quiet' }, D.changed ? ['Changed since · ', A.link({ v: 'changed', at: '' }, K.plural(D.changed, 'meal'))] : 'Nothing changed since') : null,
          h('p', { class: 'cm-sent__acts' }, h('button', { type: 'button', class: 'ap-link', text: 'Print as sent', on: { click: () => printSent(s) } }),
            h('button', { type: 'button', class: 'ap-link', text: 'Download as sent', on: { click: () => K.excel('lists/' + p.year + '/meals/sent?at=' + encodeURIComponent(s.at), p.year + ' Meal counts sent ' + s.day, p.as) } }))))),
        onClose: () => { panel = ''; A.setParams({ at: '' }); }
      });
    }
    // The counts as they are now. Not kept as printed while previewing a date.
    function printMeals() {
      if (!asOf()) listsApi('POST', 'printed', { view: 'meals' }).catch(() => {});
      const any = D.meals.some(m => m.est);
      K.print({ tz: tz(), title: 'Meal counts', sub: K.facts([head.as_of ? 'As of ' + head.as_of : '', D.sent ? 'Last sent ' + K.md(D.sent.day) : 'Not sent']), who: 'Food', build: () => h('div', null, mealTable(D.meals.filter(m => m.status !== 'removed'), false, true),
        h('p', { class: 'cm-key', text: K.facts(['12 and up includes Young Folks', any ? 'Arriving or leaving: in the total, counted for every meal that day' : '']) })) });
    }
    // One send, exactly as it went (lists/{y}/meals/sent?at=): the paper record of what the caterer was told.
    function printSent(s) {
      A.api('GET', '/lists/' + p.year + '/meals/sent?at=' + encodeURIComponent(s.at)).then(r => {
        const cols = r.cols || [], rows = r.rows || [];
        const ix = n => cols.indexOf(n);
        const arr = rows.some(x => x[ix('Arriving or leaving')] !== '' && +x[ix('Arriving or leaving')] > 0);
        const chg = !!r.before;
        let prev = '';
        const body = [];
        rows.forEach(x => {
          if (x[0] !== prev) { body.push(h('tr', { class: 'cm-group' }, h('td', { colspan: String(5 + (arr ? 1 : 0) + (chg ? 1 : 0)), text: K.day(x[0]) }))); prev = x[0]; }
          const note = x[ix('Note')];
          body.push(h('tr', null, h('td', null, h('b', { text: x[ix('Meal')] }), x[ix('Time')] ? ' · ' + x[ix('Time')] : '', note ? h('small', { class: 'cm-sub2', text: note }) : null),
            ['12 and up', '3–11', 'Under 3'].map(c => h('td', { class: 'is-num', text: +x[ix(c)] ? String(x[ix(c)]) : '–' })),
            h('td', { class: 'is-num', text: String(x[ix('Total')]) }),
            arr ? h('td', { class: 'is-num', text: +x[ix('Arriving or leaving')] ? String(x[ix('Arriving or leaving')]) : '–' }) : null,
            chg ? h('td', { class: 'is-num', text: +x[ix('Change')] ? K.signed(+x[ix('Change')]) : '' }) : null));
        });
        K.print({ tz: tz(), title: 'Meal counts as sent', sub: K.facts(['Sent ' + K.md(s.day) + (s.by ? ' by ' + s.by : ''), s.final ? 'Final' : '', s.how === 'email' ? 'Emailed to ' + (s.to || 'the caterer') : 'Marked as sent']), who: 'Food', build: () => h('div', null,
          h('table', null, h('thead', null, h('tr', null, h('th', { text: 'Meal' }), h('th', { class: 'is-num', text: '12+' }), h('th', { class: 'is-num', text: '3–11' }), h('th', { class: 'is-num', text: '<3' }), h('th', { class: 'is-num', text: 'Total' }),
            arr ? h('th', { class: 'is-num', text: 'Arriving or leaving' }) : null, chg ? h('th', { class: 'is-num', text: 'Since ' + K.md(r.before) }) : null)), h('tbody', null, body)),
          h('p', { class: 'cm-key', text: K.facts(['12 and up includes Young Folks', arr ? 'Arriving or leaving: in the total, counted for every meal that day' : '']) })) });
      }).catch(A.fail);
    }

    load();
    const t = setInterval(() => { if (!document.hidden && !panel) load(); }, 120000);
    return () => { alive = false; clearInterval(t); ctx.body.classList.remove('ap-body--flush'); };
  }

  /* ================================================================ Menus */

  // menus.csv: day, meal, station, items ("Pot roast · Biscuits").
  function menusScreen(ctx) {
    const p = ctx.params;
    let file = null, meals = [], prev = null, alive = true;
    const ro = () => !!A.readonly;
    const keyOf = (day, meal) => (day + '|' + meal).toLowerCase();
    const toText = rows => rows.map(r => (r.station ? r.station + ': ' : '') + (r.items || '')).join('\n');
    const fromText = (day, meal, text) => String(text || '').split(/\n+/).map(l => l.trim()).filter(Boolean).map(l => {
      const m = /^([^:]{1,40}):\s*(.*)$/.exec(l);
      return { day, meal, station: m ? m[1].trim() : '', items: (m ? m[2] : l).split(/\s*[·;,]\s*|\s{2,}/).filter(Boolean).join(' · ') };
    });
    const load = () => Promise.all([
      A.api('GET', '/years/' + p.year + '/files/menus?format=json'),
      A.api('GET', '/lists/' + p.year + '/meals').catch(() => null),
      A.api('GET', '/years/' + (p.year - 1) + '/files/menus?format=json').catch(() => null)
    ]).then(([f, m, pv]) => {
      file = { rows: (f && f.rows) || [], version: f ? f.version : 0, cols: (f && f.cols && f.cols.length) ? f.cols : ['day', 'meal', 'station', 'items'] };
      const days = (m && m.head && m.head.start) ? K.days(m.head.start, m.head.end) : [];
      const name = d => (days.find(x => x.date === d) || {}).name || '';
      meals = m && m.list ? m.list.meals.filter(x => x.status !== 'removed' && x.from !== 'communion').map(x => ({ day: name(x.date), meal: x.title.replace(/\s*\(.*\)\s*$/, ''), date: x.date, when: x.when })) : [];
      // Meals in the file the schedule doesn't have (yet) still show.
      file.rows.forEach(r => { if (r.day && r.meal && !meals.some(x => keyOf(x.day, x.meal) === keyOf(r.day, r.meal))) meals.push({ day: r.day, meal: r.meal, date: '', when: '' }); });
      prev = pv && pv.rows && pv.rows.length ? pv.rows : null;
      if (alive) draw();
    }).catch(err => { if (alive) K.failed(ctx, err); });
    const save = (rows, words) => A.api('PUT', '/years/' + p.year + '/files/menus', { rows, version: file.version, cols: file.cols }).then(r => {
      file.rows = rows; file.version = r && r.version != null ? r.version : file.version + 1;
      A.toast(words); draw();
    }).catch(e => { if (e.status === 409) { A.toast('Changed by another member · Reloaded'); load(); } else A.fail(e); });
    // One way in: the caterer's whole menu, pasted, split by day and meal; then read as a document,
    // each meal with Change. No copying last year's (old menus could pass for this year's).
    const DAYS = ['Friday', 'Saturday', 'Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday'];
    const MEALS = ['Breakfast', 'Lunch', 'Supper', 'Dinner', 'Snack'];
    const meal1 = x => x === 'Dinner' ? 'Supper' : x;
    function readMenu(t) {
      const out = []; let day = '', meal = '';
      String(t).split(/\r?\n/).map(l => l.trim()).filter(Boolean).forEach(l => {
        const dd = DAYS.find(x => new RegExp('^' + x + '\\b', 'i').test(l));
        if (dd) { day = dd; meal = ''; const rest = l.slice(dd.length).replace(/^[,:\s]+/, ''); const mm = MEALS.find(x => new RegExp('^' + x + '\\b', 'i').test(rest)); if (mm) meal = meal1(mm); return; }
        const mm = MEALS.find(x => new RegExp('^' + x + '\\b', 'i').test(l));
        if (mm && l.length < 24) { meal = meal1(mm); return; }
        if (!day || !meal) return;
        out.push(fromText(day, meal, l)[0]);
      });
      return out.filter(Boolean);
    }
    let pasting = false, changing = '';
    function pasteBox() {
      const t = h('textarea', { class: 'ap-textarea cm-paste', rows: '10', 'aria-label': 'The menu, as the caterer sent it', placeholder: 'Friday\nSupper\nStation: dish · dish' });
      const err = h('div', { class: 'ap-err', role: 'alert' });
      const prevBox = h('div');
      let rows = [];
      const read = A.btn('Read it', { primary: true, write: true, onClick: () => {
        rows = readMenu(t.value);
        A.clear(prevBox);
        if (!rows.length) { err.textContent = 'No day and meal found · Start with the day, then the meal'; return; }
        err.textContent = '';
        const n = new Set(rows.map(r => keyOf(r.day, r.meal))).size;
        prevBox.append(h('p', { class: 'ap-quiet', text: K.plural(n, 'meal') + ' · ' + K.plural(rows.length, 'station') + (file.rows.length ? ' · Replaces those meals' : '') }),
          h('div', { class: 'ap-row' }, A.btn('Use this menu', { primary: true, write: true, onClick: () => {
            const keys = new Set(rows.map(r => keyOf(r.day, r.meal)));
            pasting = false;
            save(file.rows.filter(r => !keys.has(keyOf(r.day, r.meal))).concat(rows), 'Menu · ' + K.plural(n, 'meal'));
          } }), A.btn('Cancel', { ghost: true, onClick: () => { pasting = false; draw(); } })));
        read.classList.remove('ap-btn--primary');
      } });
      setTimeout(() => t.focus(), 0);
      return h('section', { class: 'ap-section cm-pastebox' }, h('label', { class: 'ap-field' }, h('span', { text: 'The menu, as the caterer sent it' }), t,
        h('span', { class: 'ap-help', text: 'A day’s name, then each meal, then a station a line: Station: dish · dish' })), err,
        h('div', { class: 'ap-row' }, read, A.btn('Cancel', { ghost: true, onClick: () => { pasting = false; draw(); } })), prevBox);
    }
    function draw() {
      A.clear(ctx.body);
      const withMenu = meals.filter(m => file.rows.some(r => keyOf(r.day, r.meal) === keyOf(m.day, m.meal)));
      const acts = ro() || pasting ? [] : [A.btn(file.rows.length ? 'Paste a newer menu' : 'Paste menu', { primary: !file.rows.length, write: true, onClick: () => { pasting = true; draw(); } })];
      ctx.head('Menus', !meals.length ? '' : withMenu.length ? withMenu.length + ' of ' + K.plural(meals.length, 'meal') + ' with a menu' : 'Waiting for the caterer', acts);
      if (!meals.length) { ctx.body.appendChild(A.empty({ title: 'No meals in the schedule', line: 'Menus follow the schedule’s meals' })); return; }
      if (pasting) ctx.body.appendChild(pasteBox());
      else if (!file.rows.length) { ctx.body.appendChild(A.empty({ title: 'Waiting for the caterer', line: 'Paste the whole menu as sent · Split by day and meal' })); return; }
      const doc = h('div', { class: 'cm-menudoc' });
      let prevDay = '';
      // Meals the caterer hasn't sent a menu for are one line, opened to add one (never ten "No menu yet").
      const has = m => file.rows.some(r => keyOf(r.day, r.meal) === keyOf(m.day, m.meal));
      const without = meals.filter(m => !has(m) && changing !== keyOf(m.day, m.meal));
      const fold = without.length > 1 ? h('details', { class: 'cm-fold cm-nomenu' }, h('summary', null, K.plural(without.length, 'meal') + ' without a menu', h('span', { class: 'ap-quiet', text: ' · Paste the caterer’s menu above, or add one here' }))) : null;
      meals.forEach(m => {
        const into = fold && without.indexOf(m) > -1 ? fold : doc;
        if (into === doc && m.day !== prevDay) { doc.appendChild(h('h2', { class: 'ap-label cm-sub', text: m.date ? K.day(m.date) : m.day })); prevDay = m.day; }
        const k = keyOf(m.day, m.meal);
        const rows = file.rows.filter(r => keyOf(r.day, r.meal) === k);
        const headRow = h('div', { class: 'cm-menurow__h' }, h('b', { text: m.meal }), m.when ? h('span', { class: 'ap-quiet', text: m.when }) : null,
          ro() || changing === k ? null : h('button', { type: 'button', class: 'ap-link', text: rows.length ? 'Change' : 'Add', on: { click: () => { changing = k; draw(); } } }));
        if (changing === k) {
          const ta = h('textarea', { class: 'ap-textarea cm-menu', rows: String(Math.max(3, rows.length + 1)), value: toText(rows), placeholder: 'Station: dish · dish', 'aria-label': m.meal + ', ' + m.day });
          setTimeout(() => ta.focus(), 0);
          doc.appendChild(h('div', { class: 'cm-menurow' }, headRow, h('div', null, ta, h('div', { class: 'ap-row', style: { marginTop: '8px' } },
            A.btn('Save', { primary: true, write: true, onClick: () => {
              const mine = fromText(m.day, m.meal, ta.value);
              changing = '';
              save(file.rows.filter(r => keyOf(r.day, r.meal) !== k).concat(mine), m.meal + ' · ' + m.day + ' · ' + (mine.length ? K.plural(mine.length, 'station') : 'No menu'));
            } }), A.btn('Cancel', { ghost: true, onClick: () => { changing = ''; draw(); } })))));
          return;
        }
        if (into !== doc) { headRow.insertBefore(h('span', { class: 'ap-quiet', text: (m.date ? K.day(m.date) : m.day) + ' · ' }), headRow.firstChild); into.appendChild(h('div', { class: 'cm-menurow cm-menurow--one' }, headRow)); return; }
        doc.appendChild(h('div', { class: 'cm-menurow' }, headRow, rows.length
          ? h('ul', { class: 'cm-menulist' }, rows.map(r => h('li', null, r.station ? h('span', { class: 'cm-menulist__st', text: r.station + ': ' }) : null, r.items)))
          : h('p', { class: 'ap-quiet', text: 'No menu yet' })));
      });
      if (fold) doc.appendChild(fold);
      ctx.body.appendChild(doc);
    }
    K.loading(ctx);
    load();
    return () => { alive = false; };
  }

  A.screen({ id: 'food-meals', title: 'Meal counts', icon: 'report', section: 'own', who: ['food'], render: mealsScreen });
  A.screen({ id: 'food-menus', title: 'Menus', icon: 'note', section: 'own', who: ['food'], render: menusScreen });
  A.action({ id: 'food-send', title: 'Send meal counts', screen: 'food-meals', run: () => A.go({ s: 'food-meals', id: '' }) });
})();
