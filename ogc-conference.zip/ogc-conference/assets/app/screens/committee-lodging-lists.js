/*
 * Lodging's other screens in the app (app-committees, Oct 11), from the lodging area's tabs and their
 * critique:
 *
 *   Households   every household as a table, with saved views (All · Needs a room · Asks · Changed
 *                this week) and one search; a household opens beside the list with what Lodging needs.
 *   Check-in     Desk (search, Not checked in · Checked in, by arrival day; Check in asks who took each
 *                room's keys; Keys back for anyone checked in, and before the last night it records
 *                the night they left, for the credit), Room setup (linens and mattresses per room) and
 *                Counts (the final count for the campus). Each prints for paper: the desk landscape,
 *                one line a household, with tick boxes.
 *   Youngfolks  each hall: pairs, only the exceptions said; Suggest pairs, Pair, Unpair; Assign rooms;
 *                printed hall by hall in room order with Key out and Key back.
 *   Campers      a table, those arriving together grouped; prints on one page.
 */
(function () {
  'use strict';
  const A = window.OGC_APP, h = A.h, K = window.OGC_CK, O = window.OGC, L = O.lodging, S = L.S, SU = L.SU;
  const plural = SU.plural;
  const chip = (text, tone, title) => h('span', { class: 'cm-chip' + (tone ? ' cm-chip--' + tone : ''), title: title || null, text });
  const nameCell = x => h('span', null, h('span', { class: 'cm-title', text: x.sur }), x.firsts ? ' · ' + x.firsts : '');
  const listName = x => x.sur + (x.firsts ? ', ' + x.firsts : '');
  const ro = () => L.ro || !!A.readonly;
  const STAY = { dorm: 'Dorm', camper: 'Camper lot', elsewhere: 'Off campus', yf: 'Youngfolks halls' };

  /* ================================================================ Households */

  const weekAgo = () => S.phase.today ? O.isoAddDays(S.phase.today, -7) : '';
  const asks = x => x.walker || x.ground || x.nearW || x.nearM || x.restroom || x.cribs || x.nearText || x.note;
  const changedWeek = x => { const w = weekAgo(); return !!w && (String(x.at).slice(0, 10) >= w || (x.d.history || []).some(y => String(y.at).slice(0, 10) >= w) || L.changes(x).length > 0); };
  // New since this person last opened Households (the server keeps when: POST app/{y}/seen).
  const iso = t => String(t || '').replace(' ', 'T').slice(0, 19);
  const isNew = x => !!L.hhSince && !x.gone && iso(x.at) > L.hhSince;
  const VIEWS = [
    { id: '', label: 'All', f: () => true },
    { id: 'new', label: 'New', f: isNew },
    { id: 'room', label: 'Needs a room', f: x => x.active && !L.given(x).length },
    { id: 'asks', label: 'Asks', f: x => !x.gone && asks(x) },
    { id: 'week', label: 'Changed this week', f: x => changedWeek(x) }
  ];

  // "since your last look" (today), "since Monday" (this week), "since Oct 5".
  function sinceWords(at) {
    if (!at) return '';
    const day = String(at).slice(0, 10), today = S.phase.today || new Date().toISOString().slice(0, 10);
    const d = Math.round((Date.parse(today) - Date.parse(day)) / 864e5);
    if (d <= 0) return 'since your last look';
    return d < 7 ? 'since ' + new Date(day + 'T12:00:00Z').toLocaleDateString('en-US', { weekday: 'long', timeZone: 'UTC' }) : 'since ' + K.md(day);
  }

  function householdsScreen(ctx) {
    const p = ctx.params, U = L.hhUI = L.hhUI || { find: '', sort: '' };
    let sp = null, tbl = null;
    // Once a visit: when they last looked (kept for this visit), then now. Never while seeing as or previewing.
    if (!L.hhSeenAsked && !A.readonly && !S.asOf) {
      L.hhSeenAsked = true;
      A.api('POST', 'seen', { screen: 'lod-households' }).then(r => {
        // The server keeps UTC ("2027-02-13 15:00:00"); households' times are ISO: compare as ISO.
        L.hhSince = r.was ? iso(r.was) : '';
        if (sp) draw();
      }).catch(() => {});
    }
    const draw = () => {
      const v = VIEWS.find(x => x.id === p.v) || VIEWS[0];
      const all = S.hh.filter(x => !x.gone || v.id === '');
      const rows = () => L.search(U.find).filter(v.f).filter(x => !x.gone || v.id === '');
      const dorm = L.dorm(), waiting = dorm.filter(x => !L.given(x).length).length;
      const fresh = S.hh.filter(isNew).length;
      // The chips carry the counts and the button the rooms to give: the fact is only what's new.
      const fk = ctx.foreign ? ((A.committee(ctx.foreign) || {}).name || 'Lodging') : '';
      ctx.head('Households', fresh ? fresh + ' new ' + sinceWords(L.hhSince) : '',
        // The title row carries the act (Assign all), not a link styled as the main button. The COA
        // doing it says whose it is.
        // "Assign all · 8" (whose it is in the tooltip when the COA does it); Export once there's a row.
        [waiting && !ro() ? A.btn('Place · ' + waiting, { primary: true, write: true, title: 'On Rooms' + (fk ? ' · For ' + fk : '') + ' · Each household by hand', onClick: () => A.go({ s: 'lod-rooms', id: '', v: '', at: 'assign' }) }) : null,
          S.hh.length ? A.btn('Export', { icon: 'download', onClick: exportHouseholds }) : null].filter(Boolean));
      if (!sp) { A.clear(ctx.body); sp = ctx.split(); }
      A.clear(sp.main);
      if (!S.hh.length) {
        sp.main.appendChild(A.empty({ title: 'No registrations yet', line: S.cfg.opens ? 'Opens ' + O.fmtDate(S.cfg.opens, 'md') : '', inset: true, action: ro() ? null : A.btn('Import from the Form', { icon: 'upload', onClick: () => A.go({ s: 'lod-import' }) }) }));
        return;
      }
      const wrap = h('div');
      const renderTable = () => {
        const list = rows().slice();
        if (U.sort === 'new') list.sort((a, b) => String(b.at).localeCompare(String(a.at)));
        const cols = [
          { label: 'Household', cls: 'cm-col-name', render: x => h('span', null, nameCell(x), h('span', { class: 'ap-cell-sub', text: L.metaOf(x) })) },
          { label: 'Staying', cls: 'ap-td--nowrap', wide: true, render: x => x.gone ? chip('Cancelled', 'warn') : STAY[x.type] || x.type },
          { label: 'Rooms', cls: 'ap-td--nowrap', render: x => !x.active ? '' : L.given(x).length ? L.roomsWords(L.given(x)) : chip('Unassigned', 'tan') },
          list.some(asks) ? { label: 'Asks', wide: true, render: x => h('span', { class: 'cm-tags' }, L.tagsOf(x).map(t => chip(t)), x.note ? chip('Note', '', x.note) : null) } : null,
          list.some(x => L.owes(x)) ? { label: 'Owes', cls: 'ap-td--nowrap', wide: true, render: x => L.owes(x) } : null,
          list.some(x => x.source !== 'online') ? { label: 'From', cls: 'ap-td--nowrap ap-td--muted', wide: true, render: x => x.source === 'form' ? 'Form' : x.source === 'desk' ? 'Desk' : 'Online' } : null,
          list.some(L.older) ? { label: 'Older', cls: 'ap-td--nowrap', wide: true, render: x => L.older(x) ? 'Older' : '' } : null,
          { label: 'Registered', cls: 'ap-td--nowrap ap-td--muted', wide: true, render: x => h('span', null, K.md(x.at), isNew(x) ? [' ', chip('New', 'tan')] : null) }
        ].filter(Boolean);
        const t = A.table({ label: 'Households', rows: list, key: x => x.rid, selected: p.id, cols, onOpen: x => { p.id = x.rid; A.setParams({ id: x.rid }); open(x); renderTable(); },
          empty: A.empty({ title: U.find ? 'No matches' : v.id === 'room' ? 'Everyone has a room' : v.id === 'week' ? 'No changes this week' : v.id === 'new' ? 'Nothing new since you last looked' : 'None', inset: true }) });
        if (tbl) tbl.replaceWith(t); else wrap.appendChild(t);
        tbl = t;
      };
      // Never a zero: a view with nothing in it isn't offered (unless it's the one open).
      // "Changed this week" only when it says something (not every row).
      const total = S.hh.length;
      const counts = VIEWS.map(x => ({ id: x.id, label: x.label, n: S.hh.filter(y => (!y.gone || x.id === '') && x.f(y)).length })).filter(x => !x.id || (x.n && !(x.id === 'week' && x.n >= total)) || x.id === v.id);
      // The sort is a control of its own beside the search, not one of the filter chips.
      const sortBtn = A.btn(U.sort === 'new' ? 'Newest first' : 'By name', { ghost: true, icon: 'down', title: 'Sort · By name or by when they registered', onClick: () => { U.sort = U.sort === 'new' ? '' : 'new'; sortBtn.lastChild.textContent = U.sort === 'new' ? 'Newest first' : 'By name'; renderTable(); } });
      sortBtn.classList.add('cm-sort');
      const imp = ro() ? null : h('button', { type: 'button', class: 'ap-link cm-import', text: 'Import from the Form', title: 'The Google Form’s responses, for households who didn’t register here', on: { click: () => A.go({ s: 'lod-import', id: '', v: '' }) } });
      sp.main.appendChild(h('div', { class: 'cm-toolbar' }, counts.length > 1 ? A.views(counts, v.id, id => A.go({ v: id, id: '' }, { replace: true })) : null,
        K.find({ value: U.find, placeholder: 'Search', title: 'A name, a room, R-number or a phone’s last digits', onInput: val => { U.find = val; renderTable(); } }), sortBtn, imp));
      tbl = null;
      sp.main.appendChild(wrap);
      renderTable();
      const cur = p.id && L.byRid(p.id);
      if (cur) open(cur); else sp.close(true);
    };
    function open(x) {
      const g = L.given(x), row = L.hrow(x), rv = x.active ? L.toReview(x) : [], ch = L.changes(x);
      const note = h('textarea', { class: 'ap-textarea', rows: '2', maxlength: '500', value: row.note || '', disabled: ro(), placeholder: 'Add note', title: 'For Lodging only; cleared with the names' });
      note.addEventListener('change', () => { const val = note.value.trim(); if ((row.note || '') !== val) L.hhSave(x, { note: val || null }, { label: x.sur + ' · Note saved' }); });
      const older = h('input', { type: 'checkbox', class: 'ap-check', checked: L.older(x), disabled: ro() || !x.active });
      older.addEventListener('change', () => L.hhSave(x, { older: older.checked }, { label: x.sur + (older.checked ? ' · Older' : ' · Not older') }));
      const keys = x.active ? L.keysOf(x).map((n, i) => (g.length > 1 ? (g[i] ? L.roomWords(g[i]) : 'Room ' + (i + 1)) + ' · ' : '') + n).join(' · ') : '';
      sp.open({
        title: x.label,
        body: [
          h('p', { class: 'cm-detail__m', text: K.facts([x.gone ? 'Cancelled' : L.where(x)].concat(L.metaList(x))) }),
          L.tagsOf(x).length ? h('p', { class: 'cm-tags' }, L.tagsOf(x).map(t => chip(t))) : null,
          x.note ? h('blockquote', { class: 'cm-quote' }, h('span', { class: 'ap-label', text: 'Note for Lodging' }), h('span', { text: x.note })) : null,
          rv.length ? h('ul', { class: 'cm-issues' }, rv.map(i => h('li', null, h('b', { text: i.text }), i.title ? h('span', { text: i.title }) : null))) : null,
          ch.length ? h('ul', { class: 'cm-issues cm-issues--change' }, ch.map(c => h('li', null, h('b', { text: c.text })))) : null,
          h('dl', { class: 'ap-facts' },
            h('dt', { text: 'Coming' }), h('dd', null, h('ul', { class: 'cm-people' }, x.people.map(pp => h('li', null, h('span', { text: pp.name }), h('small', { text: K.facts([x.kind(pp) === 'child' && pp.age ? 'Age ' + pp.age : '', x.kind(pp) === 'yf' ? 'Youngfolk' + (x.inHall(pp) ? ' · ' + (pp.yfHall === 'women' ? 'young women’s hall' : pp.yfHall === 'men' ? 'young men’s hall' : 'hall not set') : '') : '', L.someNights(pp.nights)]) }))))),
            keys ? [h('dt', { text: 'Keys' }), h('dd', { text: keys })] : null,
            x.linens || x.mattresses ? [h('dt', { text: 'Bedding' }), h('dd', { text: K.facts([x.linens ? plural(x.linens, 'linen packet') : '', x.mattresses ? plural(x.mattresses, 'air mattress', 'air mattresses') : '']) })] : null,
            h('dt', { text: 'Contact' }), h('dd', null, (x.d.household && x.d.household.contact) || '', x.phone ? [' · ', K.phone(x.phone)] : null),
            h('dt', { text: 'Registered' }), h('dd', { text: K.facts([L.md(x.at), x.source === 'form' ? 'Form' : x.source === 'desk' ? 'Desk' : 'Online', x.rid]) }),
            L.payWords(x) ? [h('dt', { text: 'Payment' }), h('dd', { text: L.payWords(x) })] : null),
          x.active ? h('label', { class: 'ap-switch', title: 'Lodging’s own mark: placed first, on a ground floor near the dining hall' }, older, 'Older', x.oldest >= 65 && !L.older(x) ? h('span', { class: 'ap-quiet', text: ' · Suggested · ' + x.oldest }) : null) : null,
          h('label', { class: 'ap-field', style: { marginTop: '14px' } }, h('span', { text: 'Note' }), note)
        ],
        // Change (Round 5): the household's own form, for a household, back here with it open.
        foot: [x.active ? A.btn(g.length ? 'Open in Rooms' : 'Assign in Rooms', { primary: !g.length && !ro(), onClick: () => L.show(x.rid) }) : null,
          !x.gone && x.id ? A.btn('Change', { ghost: true, write: true, href: L.changeHref(x), title: 'Their registration form · Save comes back here' }) : null].filter(Boolean),
        onClose: () => { p.id = ''; A.setParams({ id: '' }); draw(); }
      });
    }
    function exportHouseholds() {
      const rows = [['Household', 'Registration', 'People', 'Staying', 'Nights', 'Rooms asked', 'Rooms', 'Asks', 'Note', 'Phone', 'From', 'Older']];
      S.hh.forEach(x => rows.push([listName(x), x.rid, x.people.length, x.gone ? 'Cancelled' : STAY[x.type] || x.type, L.nightSpan(x.nights).replace('–', '-'), x.asked || '', L.given(x).map(L.roomWords).join('; '), L.tagsOf(x).join('; '), x.note, x.phone, x.source, L.older(x) ? 'Yes' : '']));
      K.download(rows, 'Households ' + S.year + ' ' + L.stamp() + '.csv');
      L.api('POST', '/log', { what: 'export', list: 'households', rows: rows.length - 1 }).catch(() => {});
    }
    return L.screen(ctx, (c, why) => { if (why === 'local') return; draw(); });
  }

  /* ================================================================ Check-in */

  const firstNight = () => { const ns = SU.nightsOf(S.cfg).filter(n => L.dorm().some(x => x.nights.indexOf(n) > -1)); return ns[0] ? L.nightDate(ns[0]) : S.phase.start; };
  L.deskOn = () => !S.phase.cleared && L.today() >= (firstNight() || S.phase.start || '9999') && (!S.phase.checkout || L.today() <= S.phase.checkout);
  const deskLate = () => !S.phase.cleared && L.today() >= (firstNight() || S.phase.start || '9999');
  const checkedIn = x => L.hrow(x).checkin || null;
  const keysPer = (x, i) => S.cfg.keys_per === 'person' ? Math.max(1, L.inRoom(x, i).filter(p => p.band !== 'baby').length) : 1;
  const keysOut = (x, id, i) => { const k = L.hrow(x).keysout || {}; return k[id] != null ? +k[id] : keysPer(x, i); };

  function setupRows() {
    const rows = [];
    L.dorm().forEach(x => {
      const ids = L.given(x), n = ids.length, set = L.hrow(x).setup || {};
      ids.forEach((id, i) => {
        const share = t => Math.floor(t / n) + (i < t % n ? 1 : 0), s = set[id];
        const l = s ? s.l : share(x.linens), m = s ? s.m : share(x.mattresses);
        if (l || m || s) rows.push({ r: L.room(id), x, l, m, ask: { l: share(x.linens), m: share(x.mattresses) }, set: !!s, arrives: x.nights[0] || '' });
      });
    });
    return rows.sort((a, b) => S.rooms.indexOf(a.r) - S.rooms.indexOf(b.r));
  }
  function linens() {
    const rooms = setupRows().reduce((k, y) => k + y.l, 0);
    const yf = S.hh.filter(x => !x.gone && x.type === 'yf').reduce((k, x) => k + x.linens, 0);
    const waiting = L.dorm().filter(x => !L.given(x).length).reduce((k, x) => k + x.linens, 0);
    return { rooms, yf, waiting, all: rooms + yf + waiting };
  }
  L.linens = linens;
  // Counts (Round 5, committee-lodging-counts.js) draws these same lists.
  L.setupRows = () => setupRows();
  L.countsRows = () => countsRows();
  const yfHalls = () => {
    const out = [];
    S.floors.filter(f => /^young/.test(f.for)).forEach(f => {
      const key = /women/.test(f.for) ? 'women' : 'men';
      let g = out.find(y => y.hall === f.hall);
      if (!g) out.push(g = { hall: f.hall, key, floors: [] });
      g.floors.push(f);
    });
    return out;
  };
  const yfNights = i => i.p.nights && i.p.nights.length ? i.p.nights : i.h.nights.length ? i.h.nights : SU.mainNights(S.cfg);
  function countsRows() {
    const ns = SU.nightsOf(S.cfg), halls = Array.from(new Set(L.familyFloors().map(f => f.hall)));
    const yh = yfHalls(), yf = L.everyYf(), camp = S.hh.filter(x => x.type === 'camper' && !x.gone);
    const nC = x => +(x.d.stay && x.d.stay.campers) || 1;
    const head = ['Night', 'Date'].concat(halls.map(x => L.hallShort(x) + ' · rooms'), yh.map(g => L.hallShort(g.hall) + ' · Youngfolks'), camp.length ? ['Campers'] : []);
    const rows = ns.filter(n => !SU.isEarly(n) || L.dorm().some(x => x.nights.indexOf(n) > -1)).map(n => [n, K.md(L.nightDate(n))]
      .concat(halls.map(hall => L.dorm().reduce((k, x) => k + (x.nights.indexOf(n) > -1 ? L.given(x).filter(id => L.room(id).hall === hall).length : 0), 0)),
        yh.map(g => yf.filter(i => i.key === g.key && yfNights(i).indexOf(n) > -1).length),
        camp.length ? [camp.reduce((k, x) => k + (x.nights.indexOf(n) > -1 ? nC(x) : 0), 0)] : []));
    const d = L.dorm(), ln = linens();
    const keys = d.reduce((k, x) => k + L.given(x).reduce((j, id, i) => j + keysPer(x, i), 0), 0) + yf.length;
    const totals = [['Rooms given', d.reduce((k, x) => k + L.given(x).length, 0)], ['Linen packets', ln.all]].concat([['Air mattresses', d.reduce((k, x) => k + x.mattresses, 0)], ['Keys', keys]]);
    return { head, rows, totals, ln };
  }

  function checkinScreen(ctx) {
    const p = ctx.params, U = L.ciUI = L.ciUI || { find: '', show: 'out' };
    let sp = null;
    // Room setup and Counts moved to their own screen, Counts (Round 5; area-lodging §8): the old
    // addresses land there.
    if (p.v === 'setup' || p.v === 'counts') { setTimeout(() => A.go({ s: 'lod-counts', v: p.v, id: '' }, { replace: true }), 0); return () => {}; }
    const draw = (c, why) => {
      if (why === 'local' && document.activeElement && document.activeElement.matches('input')) return;
      if (!sp) { A.clear(ctx.body); sp = ctx.split(); }
      A.clear(sp.main);
      if (!L.dorm().length) { ctx.head('Check-in', '', []); sp.main.appendChild(A.empty({ title: 'No households in dorm rooms', inset: true })); return; }
      desk(null);
    };

    function desk(seg) {
      const list = L.dorm(), given = list.filter(x => L.given(x).length);
      const ins = given.filter(checkedIn).length, on = L.deskOn();
      const owes = list.some(x => L.owes(x));
      ctx.head('Check-in', K.facts([S.asOf && !(window.OGC_WP && OGC_WP.prototype) ? 'Preview ' + K.md(S.asOf) + ' · Not saved' : '', on ? ins + ' of ' + given.length + ' checked in' : K.facts([plural(list.length, 'household'), 'Desk opens ' + K.md(firstNight())])]),
        [A.btn('Print', { icon: 'file', title: 'The desk’s list: one line a household, with tick boxes', onClick: printDesk }), A.btn('Export', { icon: 'download', onClick: exportDesk })]);
      // Before the desk opens and before anyone has a room: its date, and nothing to work.
      if (!on && !given.length) {
        sp.main.appendChild(A.empty({ title: 'No rooms given yet', line: 'Desk opens ' + K.md(firstNight()) + ' · The list fills as Rooms are assigned', inset: true, action: ro() ? null : A.link({ s: 'lod-rooms', v: '', id: '' }, 'Open Rooms', 'ap-btn') }));
        return;
      }
      const vlist = [{ id: 'out', label: 'Not checked in', n: given.length - ins }, { id: 'in', label: 'Checked in', n: ins }, { id: 'all', label: 'All', n: list.length }].filter(x => x.n || x.id === 'all' || x.id === U.show);
      const views = A.views(vlist, U.show, id => { U.show = id; renderRows(); syncChips(); });
      const syncChips = () => views.querySelectorAll('.ap-chip').forEach((b, i) => b.setAttribute('aria-pressed', String(vlist[i].id === U.show)));
      const find = K.find({ value: U.find, placeholder: 'Search', title: 'Anyone’s name, a room or R-number', onInput: v => { U.find = v; renderRows(); } });
      sp.main.appendChild(h('div', { class: 'cm-toolbar' }, views, find));
      if (given.length < list.length) sp.main.appendChild(h('p', { class: 'ap-quiet cm-pad', style: { margin: '10px 0 0' } }, (list.length - given.length) + ' without rooms · ', A.link({ s: 'lod-rooms', v: '', id: '' }, 'Rooms', 'ap-link')));
      const answer = h('div');
      const tbody = h('tbody');
      const table = h('div', { class: 'cm-scroll' }, h('table', { class: 'cm-table cm-desk' },
        h('thead', null, h('tr', null, h('th', { text: 'Household' }), h('th', { text: 'Rooms · keys' }), h('th', { class: 'is-wide', text: 'Nights' }), owes ? h('th', { text: 'Owes' }) : null, h('th', null, h('span', { class: 'ap-sr', text: 'Check in' })))), tbody));
      sp.main.append(answer, table);
      function renderRows() {
        const f = U.find.trim().toLowerCase();
        const hit = x => !f || (x.label + ' ' + x.rid).toLowerCase().indexOf(f) > -1 || x.people.some(pp => pp.name.toLowerCase().indexOf(f) > -1) || L.given(x).some(id => L.roomWords(id).toLowerCase().indexOf(f) > -1);
        const show = x => U.show === 'all' || f || (U.show === 'in' ? !!checkedIn(x) : !checkedIn(x) && L.given(x).length);
        // A Youngfolk asked for at the desk: where they check in.
        A.clear(answer);
        if (f) {
          const hits = L.everyYf().filter(i => i.p.name.toLowerCase().indexOf(f) > -1).slice(0, 4);
          if (hits.length) answer.appendChild(h('ul', { class: 'cm-plain cm-pad', style: { margin: '10px 0' } }, hits.map(i => h('li', null, h('b', { text: i.p.name }), ' · ' + K.facts([i.key === 'women' ? 'Young women’s hall' : i.key === 'men' ? 'Young men’s hall' : 'Youngfolks halls', 'Checks in at its lobby', (L.data('yf:' + i.pid) || {}).room ? L.roomWords(L.data('yf:' + i.pid).room) : ''])))));
        }
        const groups = {};
        list.filter(hit).filter(show).forEach(x => { const d = L.arrive(x.nights) || ''; (groups[d] = groups[d] || []).push(x); });
        A.clear(tbody);
        const dates = Object.keys(groups).sort();
        if (!dates.length) { tbody.appendChild(h('tr', null, h('td', { colspan: '5', class: 'is-muted', text: f ? 'No matches' : U.show === 'out' ? (given.length ? (on ? 'Everyone with a room is checked in' : 'Desk opens ' + K.md(firstNight())) : 'No rooms given yet') : 'None' }))); return; }
        dates.forEach(d => {
          tbody.appendChild(h('tr', { class: 'cm-group' }, h('td', { colspan: '5', text: (d ? K.day(d) : 'No nights') + ' · ' + groups[d].length })));
          groups[d].sort((a, b) => a.sur.localeCompare(b.sur)).forEach(x => tbody.appendChild(deskRow(x, owes)));
        });
      }
      renderRows();
      const cur = p.id && L.byRid(p.id);
      if (cur) openCheckin(cur); else sp.close(true);
    }
    function deskRow(x, owes) {
      const ci = checkedIn(x), g = L.given(x), row = L.hrow(x), back = row.back || {}, allBack = g.length && g.every(id => back[id]);
      const k = L.keysOf(x);
      let act = null;
      if (g.length && !ro()) {
        if (!ci && L.deskOn()) act = A.btn('Check in', { write: true, onClick: () => { p.id = x.rid; A.setParams({ id: x.rid }); openCheckin(x); } });
        // Keys back for anyone checked in (polish: it waited for the last morning, hiding the early leavers).
        else if (ci && !allBack && deskLate()) act = A.btn('Keys back', { write: true, title: 'Credit for nights not used needs the keys back', onClick: () => keysBack(x) });
      }
      const n = ci ? g.reduce((j, id, i) => j + keysOut(x, id, i), 0) : 0;
      return h('tr', { class: ci ? 'is-dim' : '' },
        h('td', null, nameCell(x), ci ? h('span', { class: 'cm-sub2', text: K.facts(['Checked in ' + L.when(ci.at), plural(n, 'key'), allBack ? 'Keys back' : '', row.left ? 'Left early · ' + SU.nightShort(row.left.night) : '']) }) : null),
        h('td', null, g.length ? g.map((id, i) => h('div', null, h('b', { text: L.roomWords(id) }), ' · Keys to ' + L.first((ci && ci.keys && ci.keys[id]) || k[i] || k[0]), back[id] ? ' · back' : '')) : h('span', { class: 'is-muted', text: 'No room' })),
        h('td', { class: 'is-wide ap-td--nowrap' }, L.someNights(x.nights) || L.nightSpan(x.nights)),
        owes ? h('td', null, L.owes(x) ? chip(L.owes(x), 'warn') : null) : null,
        h('td', { class: 'is-num' }, act));
    }
    // Check in: who took each room's keys (any grown-up there), how many keys.
    function openCheckin(x) {
      const g = L.given(x), k = L.keysOf(x), holders = x.people.filter(pp => x.kind(pp) === 'adult' || (x.kind(pp) === 'yf' && !pp.minor)).map(pp => pp.name);
      const ci = checkedIn(x);
      const pickK = {}, nK = {};
      g.forEach((id, i) => { pickK[id] = (ci && ci.keys && ci.keys[id]) || k[i] || k[0]; nK[id] = keysOut(x, id, i); });
      const body = h('div');
      const drawBody = () => {
        A.clear(body).append(
          h('p', { class: 'cm-detail__m', text: K.facts([L.metaOf(x), L.owes(x) ? 'Owes ' + L.owes(x) : '']) }),
          ...g.map(id => h('div', { class: 'ap-field' }, h('span', { text: L.roomWords(id) + ' · Keys to' }),
            K.pills(holders.map(n => [n, L.first(n)]), pickK[id], v => { pickK[id] = v; drawBody(); }, 'Keys to'),
            h('div', { class: 'ap-row' }, h('span', { class: 'ap-quiet', text: 'Keys' }), K.iconBtn('Fewer keys', 'minus', () => { nK[id] = Math.max(0, nK[id] - 1); drawBody(); }), h('b', { text: String(nK[id]) }), K.iconBtn('More keys', 'plus', () => { nK[id] = Math.min(12, nK[id] + 1); drawBody(); })))),
          h('ul', { class: 'cm-people' }, x.people.map(pp => h('li', null, h('span', { text: pp.name }), x.inHall(pp) ? h('small', { text: pp.yfHall === 'women' ? 'Young women’s hall' : 'Young men’s hall' }) : null))));
      };
      drawBody();
      sp.open({
        title: x.label, body,
        foot: ci ? [A.btn('Save keys', { write: true, onClick: () => L.hhSave(x, { keysout: nK }, { label: 'Keys out · ' + x.sur, late: true }) })]
          : [A.btn('Check in', { primary: true, write: true, onClick: () => {
            const who = Array.from(new Set(Object.values(pickK))).map(L.first).join(' and ');
            L.hhSave(x, { checkin: { keys: pickK }, keysout: nK }, { label: 'Check-in · ' + x.sur, toast: x.sur + ' · Checked in · Keys to ' + who, late: true }).then(ok => { if (ok) { p.id = ''; A.setParams({ id: '' }); sp.close(true); } });
          } })],
        onClose: () => { p.id = ''; A.setParams({ id: '' }); }
      });
    }
    // Keys back. Before the household's last night: they're leaving early, and the first night not
    // used is kept for the credit.
    function keysBack(x) {
      const b = {};
      L.given(x).forEach(id => { b[id] = true; });
      const last = x.nights[x.nights.length - 1], lastDate = L.nightDate(last), today = L.today();
      const notUsed = x.nights.find(n => L.nightDate(n) >= today);
      const early = lastDate && today <= lastDate && notUsed;
      const change = { back: Object.assign({}, L.hrow(x).back || {}, b) };
      if (early) change.left = { night: notUsed };
      L.hhSave(x, change, { label: 'Keys back · ' + x.sur, toast: early ? x.sur + ' · Keys back · Leaving early · ' + SU.nightShort(notUsed) + ' not used' : 'Keys back · ' + x.sur, late: true });
    }
    function printDesk() {
      L.api('POST', '/log', { what: 'print', list: 'checkin' }).catch(() => {});
      const st = Object.assign({}, L.data('meta:steps') || {});
      const list = L.dorm().filter(x => L.given(x).length), groups = {};
      list.forEach(x => { const d = L.arrive(x.nights) || ''; (groups[d] = groups[d] || []).push(x); });
      const line = x => {
        const k = L.keysOf(x), g = L.given(x);
        return h('tr', { class: 'cm-tall' },
          h('td', null, h('b', { text: x.sur }), x.firsts ? ' · ' + x.firsts : '', h('small', { text: x.rid })),
          h('td', { text: L.roomsWords(g) }),
          h('td', { text: Array.from(new Set(g.map((id, i) => L.first(k[i] || k[0])))).join(', ') }),
          h('td', { text: L.nightSpan(x.nights) }), h('td', { text: L.owes(x) }),
          h('td', { class: 'cm-tick' }), h('td', { class: 'cm-tick' }), h('td', { class: 'cm-tick' }));
      };
      const day = d => h('section', null, h('h2', { text: (d ? K.day(d) : 'No nights') + ' · ' + groups[d].length }),
        h('table', null, h('thead', null, h('tr', null, ['Household', 'Rooms', 'Keys to', 'Nights', 'Owes', 'In', 'Keys out', 'Keys back'].map(c => h('th', { text: c })))),
          h('tbody', null, groups[d].sort((a, b) => a.sur.localeCompare(b.sur)).map(line))));
      K.print({ title: 'Lodging Desk', sub: plural(list.length, 'household'), who: 'Lodging only', landscape: true, build: () => h('div', null, Object.keys(groups).sort().map(day)) });
      if (!st.print) L.refresh(true);
    }
    function exportDesk() {
      const rows = [['Household', 'Registration', 'Rooms', 'Keys to', 'Arrive', 'Depart', 'Owes', 'Checked in', 'Keys out', 'Keys back', 'Left early']];
      L.dorm().sort((a, b) => a.sur.localeCompare(b.sur)).forEach(x => { const g = L.given(x), k = L.keysOf(x), ci = checkedIn(x), r = L.hrow(x); rows.push([listName(x), x.rid, g.map(L.roomWords).join('; '), g.map((id, i) => k[i] || k[0]).join('; '), L.arrive(x.nights), L.depart(x.nights), L.owes(x), ci ? L.when(ci.at) : '', ci ? g.reduce((j, id, i) => j + keysOut(x, id, i), 0) : '', g.length && g.every(id => (r.back || {})[id]) ? 'Yes' : '', r.left ? r.left.night : '']); });
      K.download(rows, 'Check-in ' + S.year + ' ' + L.stamp() + '.csv');
      L.api('POST', '/log', { what: 'export', list: 'checkin', rows: rows.length - 1 }).catch(() => {});
    }

    function setup(seg) {
      const rows = setupRows(), l = rows.reduce((k, y) => k + y.l, 0), m = rows.reduce((k, y) => k + y.m, 0), ln = linens();
      const stock = +S.cfg.linen_stock || 0, over = stock && ln.all > stock;
      ctx.head('Check-in', K.facts([plural(rows.length, 'room') + ' to set up', plural(l, 'linen packet'), m ? plural(m, 'air mattress', 'air mattresses') : '', over ? 'Over stock · ' + ln.all + ' of ' + stock : '']),
        [A.btn('Print', { icon: 'file', onClick: () => K.print({ title: 'Room setup', sub: plural(rows.length, 'room'), who: 'Lodging only', build: () => setupTable(rows, true) }) }),
          A.btn('Export', { icon: 'download', onClick: () => K.download([['Hall', 'Floor', 'Room', 'Arrives', 'Linen packets', 'Air mattresses']].concat(rows.map(y => [y.r.hall, y.r.floor, y.r.num, y.arrives ? K.md(L.nightDate(y.arrives)) : '', y.l || '', y.m || ''])), 'Room setup ' + S.year + ' ' + L.stamp() + '.csv') })]);
      sp.main.appendChild(h('div', { class: 'cm-segbar' }, seg));
      if (!rows.length) { sp.main.appendChild(A.empty({ title: 'Rooms not assigned', line: '', action: A.link({ s: 'lod-rooms', v: '' }, 'Rooms', 'ap-btn'), inset: true })); return; }
      sp.main.appendChild(h('div', { class: 'cm-scroll' }, setupTable(rows, false)));
      sp.close(true);
    }
    function setupTable(rows, paper) {
      let last = '';
      const cell = (y, k) => {
        const v = y[k];
        if (paper || ro()) return h('td', { class: 'is-num', text: v ? String(v) : '' });
        const input = h('input', { class: 'ap-input cm-num', type: 'number', min: '0', max: '24', inputmode: 'numeric', value: String(v || 0), 'aria-label': (k === 'l' ? 'Linen packets' : 'Air mattresses') + ', room ' + y.r.num });
        input.addEventListener('change', () => {
          const val = Math.max(0, Math.min(24, +input.value || 0)), set = Object.assign({}, L.hrow(y.x).setup || {});
          set[y.r.id] = { l: k === 'l' ? val : y.l, m: k === 'm' ? val : y.m };
          L.hhSave(y.x, { setup: set }, { label: L.roomWords(y.r.id) + ' · ' + (k === 'l' ? plural(val, 'linen packet') : plural(val, 'air mattress', 'air mattresses')) });
        });
        // An override far above what was asked says so (polish: 24 packets for a household that asked for 1).
        return h('td', { class: 'is-num' }, input, y.set && y[k] !== y.ask[k] ? h('small', { class: 'ap-quiet', text: ' asked ' + y.ask[k] }) : null);
      };
      return h('table', { class: 'cm-table' }, h('thead', null, h('tr', null, h('th', { text: 'Room' }), h('th', { text: 'Arrives' }), h('th', { class: 'is-num', text: 'Linen packets' }), h('th', { class: 'is-num', text: 'Air mattresses' }))),
        h('tbody', null, rows.map(y => {
          const fl = y.r.hall + '|' + y.r.floor, out = [];
          if (fl !== last) { out.push(h('tr', { class: 'cm-group' }, h('td', { colspan: '4', text: y.r.hall + ' · ' + L.floorName(y.r.floor) }))); last = fl; }
          out.push(h('tr', null, h('td', null, h('b', { text: String(y.r.num) })), h('td', { text: y.arrives ? SU.nightShort(y.arrives) : '' }), cell(y, 'l'), cell(y, 'm')));
          return out;
        })));
    }

    function counts(seg) {
      const C = countsRows(), st = L.data('meta:steps') || {}, ln = C.ln, stock = +S.cfg.linen_stock || 0;
      ctx.head('Check-in', st.counts ? 'Sent ' + L.md(st.counts.at) + ' · ' + st.counts.by : S.phase.start ? 'To the campus by ' + K.md(O.isoAddDays(S.phase.start, -14)) : '',
        [!st.counts ? A.btn('Mark sent', { primary: true, write: true, title: 'Ticks Final counts in What to do', onClick: () => { const s2 = Object.assign({}, L.data('meta:steps') || {}); s2.counts = true; L.save([{ key: 'meta:steps', data: s2 }], { label: 'Counts sent', late: true }); } }) : null,
          A.btn('Print', { icon: 'file', onClick: () => K.print({ title: 'Counts for the campus', who: 'Lodging only', build: () => h('div', null, totalsList(C, true), countsTable(C)) }) }),
          A.btn('Export', { icon: 'download', onClick: () => K.download([C.head].concat(C.rows, [[]], C.totals), 'Counts ' + S.year + ' ' + L.stamp() + '.csv') })].filter(Boolean));
      sp.main.appendChild(h('div', { class: 'cm-segbar' }, seg));
      // One number for linen packets everywhere: in rooms, the Youngfolks halls, and those still without rooms.
      sp.main.appendChild(h('div', { class: 'cm-section' }, totalsList(C), ln.waiting || ln.yf ? h('p', { class: 'ap-quiet', text: K.facts(['Linen packets: ' + ln.rooms + ' in rooms', ln.yf ? ln.yf + ' Youngfolks halls' : '', ln.waiting ? ln.waiting + ' households without rooms yet' : '']) }) : null,
        stock && ln.all > stock ? h('p', { class: 'cm-warn', text: 'Linen packets over stock · ' + ln.all + ' of ' + stock }) : null));
      sp.main.appendChild(h('div', { class: 'cm-scroll' }, countsTable(C)));
      sp.close(true);
    }
    const totalsList = (C, paper) => h('div', { class: paper ? '' : 'cm-stats' }, C.totals.map(t => paper ? h('p', null, h('b', { text: String(t[1]) }), ' ' + t[0].toLowerCase()) : h('div', { class: 'cm-stat' }, h('b', { text: String(t[1]) }), h('span', { text: t[0] }))));
    const countsTable = C => h('table', { class: 'cm-table' }, h('thead', null, h('tr', null, C.head.map((x, i) => h('th', { class: i > 1 ? 'is-num' : '', text: x })))),
      h('tbody', null, C.rows.map(r => h('tr', null, r.map((v, i) => h('td', { class: i > 1 ? 'is-num' : '', text: i === 0 ? String(v) : String(v || '') }))))));

    return L.screen(ctx, draw);
  }

  /* ================================================================ Youngfolks */

  // Names only: never a phone number or an email typed into the box.
  const words = t => String(t || '').toLowerCase().replace(/\S+@\S+/g, '').replace(/\+?\d[\d\s().-]{5,}\d/g, '').split(/\s*(?:,|;|&|\/|\band\b)\s*/).map(x => x.replace(/\(.*?\)/g, '').replace(/[^a-z .'’-]/g, '').trim()).filter(Boolean);
  function findMate(t, i, all) {
    const tw = t.split(/\s+/), last = (tw[tw.length - 1] || '').replace(/\./g, '');
    const same = all.filter(x => x !== i && x.key === i.key), n = x => x.p.name.toLowerCase();
    let hit = same.find(x => n(x) === t);
    if (!hit && tw.length > 1 && last.length === 1) hit = same.find(x => n(x).split(' ')[0] === tw[0] && n(x).split(' ').pop().charAt(0) === last);
    if (!hit && tw.length === 1) { const f = same.filter(x => n(x).split(' ')[0] === tw[0]); if (f.length === 1) hit = f[0]; }
    return hit || null;
  }
  function pairsOf(all) {
    const byPid = {}, used = new Set(), pairs = [];
    all.forEach(i => { byPid[i.pid] = i; i.asks = words(i.p.rooming).map(t => ({ t, m: findMate(t, i, all) })); i.row = L.data('yf:' + i.pid) || {}; });
    const add = (a, b, how) => { used.add(a); used.add(b); pairs.push({ a, b, how }); };
    all.forEach(i => { const m = i.row.mate && byPid[i.row.mate]; if (m && !used.has(i) && !used.has(m)) add(i, m, 'lodging'); });
    const free = i => !used.has(i) && i.row.mate !== 'none';
    all.forEach(i => { if (!free(i)) return; const m = i.asks.map(x => x.m).find(z => z && free(z) && z.asks.some(y => y.m === i)); if (m) add(i, m, 'both'); });
    all.forEach(i => { if (!free(i)) return; const m = i.asks.map(x => x.m).find(z => z && free(z)); if (m) add(i, m, 'one'); });
    return { pairs, single: all.filter(i => !used.has(i)) };
  }
  const ageOf = i => +i.p.age || (i.p.minor ? 17 : 19);
  const mixed = list => S.cfg.yf_age_split === 'yes' && list.length > 1 && list.some(i => i.p.minor) && list.some(i => !i.p.minor);
  function approval(i) {
    if (!(i.p.minor && !i.h.adults.length)) return null;
    const a = i.h.d.approval;
    if (a && a.state === 'approved') return { t: 'Approved ' + L.md(a.at) };
    if (a && a.state === 'waiting') return { t: 'Approval pending · sent ' + L.md(a.sent_at) };
    if (a && a.state === 'declined') return { t: 'Declined', warn: true };
    return i.h.d.stay && i.h.d.stay.parentEmail ? { t: 'Approval pending' } : { t: 'No parent email', warn: true };
  }
  function flags(list) {
    const out = [];
    if (mixed(list)) out.push(chip('Ages mixed', 'warn', (S.cfg.yf_age_rule || 'Ohio') + ': all 17 and under, or all 18 and over, in a room'));
    list.forEach(i => {
      const ns = L.someNights(yfNights(i));
      if (ns) out.push(chip(list.length > 1 ? L.first(i.p.name) + ' ' + ns : ns));
      const ap = approval(i);
      if (ap) out.push(chip((list.length > 1 ? L.first(i.p.name) + ' · ' : '') + ap.t, ap.warn ? 'warn' : ''));
    });
    return out;
  }
  function suggestPairs(single, skip) {
    const out = [], left = single.filter(i => !i.row.room && skip.indexOf(i.pid) < 0);
    const score = (a, b) => (yfNights(a).join('|') === yfNights(b).join('|') ? 0 : 10) + Math.abs(ageOf(a) - ageOf(b)) + (mixed([a, b]) ? 100 : 0);
    while (left.length > 1) {
      let best = null;
      for (let x = 0; x < left.length; x++) for (let y = x + 1; y < left.length; y++) { const s = score(left[x], left[y]); if (!best || s < best.s) best = { s, x, y }; }
      if (best.s >= 100) break;
      out.push([left[best.x], left[best.y]]);
      left.splice(best.y, 1); left.splice(best.x, 1);
    }
    return out;
  }

  function yfScreen(ctx) {
    const U = L.yfUI = L.yfUI || { suggest: false, skip: [], pick: '', move: '' };
    let sp = null;
    const draw = () => {
      if (!sp) { A.clear(ctx.body); sp = ctx.split(); }
      A.clear(sp.main);
      const halls = yfHalls(), all = L.everyYf();
      if (!all.length) { ctx.head('Youngfolks', '', []); sp.main.appendChild(A.empty({ title: 'No Youngfolks yet', inset: true })); return; }
      const st = pairsOf(all), sugg = {};
      halls.forEach(g => { sugg[g.key] = suggestPairs(st.single.filter(i => i.key === g.key), U.skip); });
      const suggN = Object.keys(sugg).reduce((k, x) => k + sugg[x].length, 0);
      const assignN = st.pairs.filter(x => !x.a.row.room && !x.b.row.room).length;
      const acts = [];
      if (!ro()) {
        if (U.suggest) acts.push(A.btn('Pair these · ' + suggN, { primary: true, write: true, onClick: pairAll }), A.btn('Cancel', { ghost: true, onClick: () => { U.suggest = false; draw(); } }));
        // docs/25: Lodging pairs Youngfolks and gives their rooms by hand, from the rooming notes;
        // nothing suggests pairs or places them.
      }
      acts.push(A.btn('Print', { icon: 'file', onClick: () => printYf(st) }));
      ctx.head('Youngfolks', K.facts([all.length + ' staying', st.pairs.length ? plural(st.pairs.length, 'pair') : '', st.single.length ? st.single.length + ' unpaired' : '']), acts);
      halls.forEach(g => {
        const mine = all.filter(i => i.key === g.key), pairs = st.pairs.filter(x => x.a.key === g.key), single = st.single.filter(i => i.key === g.key);
        const rooms = g.floors.reduce((k, f) => k + f.rooms.length, 0), used = new Set(mine.map(i => i.row.room).filter(Boolean)).size;
        const sg = U.suggest ? sugg[g.key] : [], inSug = new Set([].concat.apply([], sg));
        const sec = h('section', { class: 'cm-section' }, h('h2', { class: 'ap-h2' }, g.hall, h('span', { class: 'ap-h2__n', text: K.facts([g.key === 'women' ? 'Young women' : 'Young men', mine.length + ' staying', used ? used + ' of ' + rooms + ' rooms' : rooms + ' rooms']) })));
        if (sg.length) sec.appendChild(table('Suggested · ' + sg.length, sg.map(x => [h('span', null, h('b', { text: x[0].p.name }), ' and ', h('b', { text: x[1].p.name })), h('span', { class: 'cm-tags' }, flags(x), chip(ageOf(x[0]) === ageOf(x[1]) ? 'Both ' + ageOf(x[0]) : ageOf(x[0]) + ' and ' + ageOf(x[1]))), '', A.btn('Skip', { ghost: true, onClick: () => { U.skip.push(x[0].pid); draw(); } })])));
        if (pairs.length) sec.appendChild(table('', pairs.map(x => {
          const room = x.a.row.room || x.b.row.room, f = flags([x.a, x.b]);
          if (x.how === 'one') f.unshift(chip('Only ' + L.first(x.a.p.name) + ' asked'));
          return [h('span', null, h('b', { text: x.a.p.name }), ' and ', h('b', { text: x.b.p.name })), h('span', { class: 'cm-tags' }, f), room ? h('b', { text: L.roomWords(room) }) : '',
            ro() ? '' : h('span', { class: 'ap-row' }, A.btn(room ? 'Change room' : 'Room', { onClick: () => openRoom(g, [x.a, x.b], room) }), A.btn('Unpair', { ghost: true, write: true, onClick: () => unpair(x.a.pid, x.b.pid) }))];
        })));
        const singles = single.filter(i => !inSug.has(i));
        if (singles.length) sec.appendChild(table('Unpaired · ' + singles.length, singles.map(i => {
          const missing = i.asks.filter(a => !a.m).map(a => a.t.replace(/\b\w/g, c => c.toUpperCase()));
          const on = U.pick === i.pid, chosen = U.pick && all.find(y => y.pid === U.pick);
          const label = on ? 'Choose another' : chosen && chosen.key === i.key ? 'Pair with ' + L.first(chosen.p.name) : 'Pair';
          return [h('b', { text: i.p.name }), h('span', { class: 'cm-tags' }, flags([i]), missing.map(m => chip(m + ' · Not registered', 'warn'))), i.row.room ? L.roomWords(i.row.room) : '',
            ro() ? '' : A.btn(label, { primary: on, write: true, onClick: () => pairTap(i, all) })];
        })));
        sp.main.appendChild(sec);
      });
      const unset = all.filter(i => !i.key);
      if (unset.length) sp.main.appendChild(h('section', { class: 'cm-section' }, h('h2', { class: 'ap-h2' }, 'Hall not set', h('span', { class: 'ap-h2__n', text: String(unset.length) })),
        h('p', { class: 'ap-help', text: 'The household’s answer · Change it on their registration' }), table('', unset.map(i => [h('b', { text: i.p.name }), i.h.label, '', '']))));
    };
    const table = (title, rows) => h('div', null, title ? h('h3', { class: 'ap-label cm-sub', text: title }) : null,
      h('table', { class: 'cm-table cm-yf' }, h('tbody', null, rows.map(r => h('tr', null, r.map((c, i) => h('td', { class: i === 3 ? 'is-num' : i === 1 ? '' : '' }, c)))))));
    function openRoom(g, who, cur) {
      const t = L.taken();
      sp.open({
        title: who.map(i => L.first(i.p.name)).join(' and '),
        body: g.floors.map(f => h('div', { class: 'ap-field' }, h('span', { text: L.floorName(f.floor) }),
          h('div', { class: 'ap-pills' }, f.rooms.filter(r => (!t[r.id] || r.id === cur) && L.usable(r.id)).slice(0, 60).map(r => h('button', { type: 'button', class: 'ap-pill', 'aria-pressed': String(r.id === cur), on: { click: () => {
            sp.close(true);
            L.save(who.map((i, k) => ({ key: 'yf:' + i.pid, data: Object.assign({}, L.data('yf:' + i.pid) || {}, { room: r.id, mate: (who[1 - k] || {}).pid || '' }) })), { label: L.roomWords(r.id) + ' · ' + who.map(i => L.first(i.p.name)).join(' and ') });
          } } }, String(r.num)))))),
        onClose: () => {}
      });
    }
    function unpair(a, b) {
      const strip = k => { const d = Object.assign({}, L.data('yf:' + k) || {}); delete d.room; d.mate = 'none'; return d; };
      L.save([{ key: 'yf:' + a, data: strip(a) }, { key: 'yf:' + b, data: strip(b) }], { label: 'Unpaired · Room freed' });
    }
    function pairTap(i, all) {
      const a = U.pick && all.find(y => y.pid === U.pick);
      if (!a || a === i || a.key !== i.key) { U.pick = a === i ? '' : i.pid; draw(); return; }
      U.pick = '';
      L.save([{ key: 'yf:' + a.pid, data: Object.assign({}, L.data('yf:' + a.pid) || {}, { mate: i.pid }) }, { key: 'yf:' + i.pid, data: Object.assign({}, L.data('yf:' + i.pid) || {}, { mate: a.pid }) }], { label: L.first(a.p.name) + ' and ' + L.first(i.p.name) + ' · Paired' });
    }
    function pairAll() {
      const all = L.everyYf(), st = pairsOf(all), ops = [];
      yfHalls().forEach(g => suggestPairs(st.single.filter(i => i.key === g.key), U.skip).forEach(x => x.forEach((i, k) => ops.push({ key: 'yf:' + i.pid, data: Object.assign({}, i.row, { mate: x[1 - k].pid }) }))));
      U.suggest = false;
      if (ops.length) L.save(ops, { label: plural(ops.length / 2, 'pair') + ' · Paired' }); else draw();
    }
    function assignYf() {
      const st = pairsOf(L.everyYf()), t = L.taken(), ops = [];
      yfHalls().forEach(g => {
        const free = [].concat.apply([], g.floors.map(f => f.rooms)).filter(r => !t[r.id] && L.usable(r.id));
        st.pairs.filter(x => x.a.key === g.key && !x.a.row.room && !x.b.row.room).forEach(x => {
          const r = free.shift();
          if (r) [x.a, x.b].forEach(i => ops.push({ key: 'yf:' + i.pid, data: Object.assign({}, i.row, { room: r.id, mate: (i === x.a ? x.b : x.a).pid }) }));
        });
      });
      if (!ops.length) { A.toast('No rooms free'); return; }
      L.save(ops, { label: plural(ops.length / 2, 'pair') + ' · Rooms given' });
    }
    // Hall by hall, in room order, with Key out and Key back to tick (the hall host's sheet).
    function printYf(st) {
      L.api('POST', '/log', { what: 'print', list: 'yf' }).catch(() => {});
      const order = id => id ? S.rooms.indexOf(L.room(id)) : 1e6;
      K.print({ title: 'Youngfolks halls', who: 'Lodging only', build: () => h('div', null, yfHalls().map((g, gi) => {
        const rows = [];
        st.pairs.filter(x => x.a.key === g.key).forEach(x => [x.a, x.b].forEach(i => rows.push({ i, mate: (i === x.a ? x.b : x.a).p.name, room: x.a.row.room || x.b.row.room })));
        st.single.filter(i => i.key === g.key).forEach(i => rows.push({ i, mate: '', room: i.row.room }));
        rows.sort((a, b) => order(a.room) - order(b.room) || a.i.p.name.localeCompare(b.i.p.name));
        return h('section', { class: gi ? 'cm-pbreak' : '' }, h('h2', { text: g.hall + ' · ' + (g.key === 'women' ? 'Young women' : 'Young men') + ' · ' + rows.length }),
          h('table', null, h('thead', null, h('tr', null, ['Room', 'Name', 'Rooming with', 'Nights', 'Under 18', 'Key out', 'Key back'].map(c => h('th', { text: c })))),
            h('tbody', null, rows.map(r => h('tr', { class: 'cm-tall' }, h('td', { text: r.room ? String(L.room(r.room).num) : '' }), h('td', { text: r.i.p.name }), h('td', { text: r.mate }), h('td', { text: L.nightSpan(yfNights(r.i)) }), h('td', { text: r.i.p.minor ? 'Yes' : '' }), h('td', { class: 'cm-tick' }), h('td', { class: 'cm-tick' }))))));
      })) });
    }
    return L.screen(ctx, draw);
  }

  /* ================================================================ Campers */

  const LEN = { short: 'Short', mid: 'Medium', long: 'Long' }, ARR = { afternoon: 'Afternoon', evening: 'Evening', late: 'Late' };
  function together(list) {
    const groups = [], seen = new Set();
    list.forEach(x => {
      if (seen.has(x)) return;
      const g = [x];
      seen.add(x);
      for (let k = 0; k < g.length; k++) {
        const y = g[k], w = y.nearText.toLowerCase();
        list.forEach(z => { if (!seen.has(z) && ((w && (w.indexOf(z.sur.toLowerCase()) > -1 || w === z.nearText.toLowerCase())) || (z.nearText && z.nearText.toLowerCase().indexOf(y.sur.toLowerCase()) > -1))) { seen.add(z); g.push(z); } });
      }
      groups.push(g);
    });
    return groups;
  }
  function campersScreen(ctx) {
    const draw = () => {
      const list = S.hh.filter(x => x.type === 'camper' && !x.gone).sort((a, b) => a.sur.localeCompare(b.sur));
      const nC = x => +(x.d.stay && x.d.stay.campers) || 1;
      ctx.body.classList.add('ap-body--flush');
      A.clear(ctx.body);
      if (!list.length) { ctx.head('Campers', '', []); ctx.body.appendChild(A.empty({ title: 'No campers', inset: true })); return; }
      const ns = SU.nightsOf(S.cfg).filter(n => !SU.isEarly(n) || list.some(x => x.nights.indexOf(n) > -1));
      const per = ns.map(n => list.reduce((k, x) => k + (x.nights.indexOf(n) > -1 ? nC(x) : 0), 0)), max = Math.max.apply(null, per);
      const total = list.reduce((k, x) => k + nC(x), 0), groups = together(list);
      const cols = [['Household', x => nameCell(x)], ['People', x => String(x.people.length)], ['Campers', x => String(nC(x))], ['Length', x => LEN[x.d.stay.camperLen] || x.d.stay.camperLen || ''], ['Arrives', x => ARR[x.d.stay.arrive] || x.d.stay.arrive || ''], ['Nights', x => L.nightSpan(x.nights)], ['Phone', x => K.phone(x.phone)]];
      const used = cols.filter(c => list.some(x => { const v = c[1](x); return v && v !== ''; }));
      const tableOf = paper => h('table', { class: paper ? '' : 'cm-table' }, h('thead', null, h('tr', null, used.map(c => h('th', { text: c[0] })))),
        h('tbody', null, groups.filter(g => g.length > 1).map(g => [h('tr', { class: 'cm-group' }, h('td', { colspan: String(used.length), text: 'Arriving together · ' + g.map(x => x.sur).join(', ') })), g.map(x => h('tr', null, used.map(c => h('td', null, paper && c[0] === 'Phone' ? x.phone : c[1](x)))))]),
          groups.filter(g => g.length === 1).length && groups.some(g => g.length > 1) ? h('tr', { class: 'cm-group' }, h('td', { colspan: String(used.length), text: 'On their own' })) : null,
          groups.filter(g => g.length === 1).map(g => h('tr', null, used.map(c => h('td', null, paper && c[0] === 'Phone' ? g[0].phone : c[1](g[0])))))));
      ctx.head('Campers', K.facts([plural(total, 'camper'), per.every(k => k === per[0]) ? max + ' every night' : 'Most ' + max + ' a night']),
        [A.btn('Print', { icon: 'file', onClick: () => K.print({ title: 'Camper lot', sub: plural(total, 'camper'), who: 'Lodging only', build: () => tableOf(true) }) }),
          A.btn('Export', { icon: 'download', onClick: () => K.download([['Household', 'People', 'Campers', 'Length', 'Arrive', 'Nights', 'Phone', 'Together with']].concat([].concat.apply([], groups.map(g => g.map(x => [listName(x), x.people.length, nC(x), LEN[x.d.stay.camperLen] || '', ARR[x.d.stay.arrive] || '', L.nightSpan(x.nights).replace('–', '-'), x.phone, g.filter(y => y !== x).map(y => y.sur).join('; ')])))), 'Camper lot ' + S.year + ' ' + L.stamp() + '.csv') })]);
      if (!per.every(k => k === per[0])) ctx.body.appendChild(h('div', { class: 'cm-section' }, h('div', { class: 'cm-stats' }, ns.map((n, i) => h('div', { class: 'cm-stat' }, h('b', { text: String(per[i]) }), h('span', { text: SU.nightShort(n) }))))));
      ctx.body.appendChild(h('div', { class: 'cm-scroll' }, tableOf(false)));
    };
    const off = L.screen(ctx, draw);
    return () => { off(); ctx.body.classList.remove('ap-body--flush'); };
  }

  /* ================================================================ register */

  A.screen({ id: 'lod-households', title: 'Households', icon: 'members', section: 'own', who: ['lodging'], render: householdsScreen });
  A.screen({ id: 'lod-checkin', title: 'Check-in', icon: 'tasks', section: 'own', who: ['lodging'], render: checkinScreen });
  A.screen({ id: 'lod-yf', title: 'Youngfolks', icon: 'committees', section: 'own', who: ['lodging'], render: yfScreen });
  A.screen({ id: 'lod-campers', title: 'Campers', icon: 'file', section: 'own', who: ['lodging'], render: campersScreen });
  A.action({ id: 'lod-desk', title: 'Check in a household', screen: 'lod-checkin', run: () => A.go({ s: 'lod-checkin', v: 'desk', id: '' }) });
})();
