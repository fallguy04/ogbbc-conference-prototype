/*
 * coa-packet.js — Packet: the information packet written like a document (its parts, each a heading,
 * one line under it, then paragraphs), and the caterer's menus. The same parts are the folds on the
 * Conference page and the printed packet.
 *
 *   - A part is typed as text: a blank line starts a paragraph. It saves as typed, a paragraph a row
 *     (ED.Rows on guide.csv), so two people writing different parts never clash.
 *   - A part carried from last year is "From 2026 · Looks right" until checked; dates moved with the
 *     Conference are said under it; a price that disagrees with Registration is flagged with "Use $27".
 *   - Menus wait for the caterer: paste them as sent ("FRIDAY / Supper / Main: …") or choose a file.
 *   - Once the packet is public, changes wait for Publish ("2 not live · Publish").
 */
(function () {
  'use strict';
  const A = window.OGC_APP, K = window.OGC_COA, ED = window.ED, W = window.OGC_WP || {};
  if (!A || !K || !ED) return;
  const h = A.h;
  const DAYS = ['Friday', 'Saturday', 'Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday'];
  const MEALS = ['Breakfast', 'Lunch', 'Supper', 'Dinner', 'Snack'];
  const FACTS = [['linen_price', /linen/i, 'Linen packets'], ['room_price', /\b(dorm|room)s?\b/i, 'Dorm rooms'], ['camper_price', /\b(camper|RV)/i, 'Camper lot'], ['mattress_price', /mattress/i, 'Air mattresses']];

  A.screen({
    id: 'packet', title: 'Packet', icon: 'book', section: 'own', who: ['coa'],
    render(ctx) {
      const y = ctx.params.year, offs = [];
      let alive = true;
      ctx.head('Packet', '', []);
      K.loading(ctx.body);
      K.load(y).then(d => {
        const g = K.rows(y, 'guide', d), m = K.rows(y, 'menus', d);
        return Promise.all([g.ready, m.ready, live()]).then(([, , lv]) => ({ d, g, m, lv }));
      }).then(st => { if (alive) page(ctx, st, offs); }, err => { if (alive) K.failed(ctx.body, err); });
      return () => { alive = false; offs.forEach(fn => fn()); };
    }
  });
  const live = () => A.api('GET', 'live?f=guide,menus').catch(() => null);

  function page(ctx, st, offs) {
    const { d, g, m } = st;
    const y = d.year, S = d.S, R = d.R;
    let lv = st.lv;
    const ro = !!(A.readonly || g.opts.readOnly);
    const posted = S.packet_posted || '';
    const isPublic = () => !!(lv && lv.guide && lv.guide.public);
    const nl = () => isPublic() ? ['guide', 'menus'].reduce((n, k) => n + (lv[k] ? lv[k].added.length + lv[k].changed.length + lv[k].removed.length : 0), 0) : 0;
    const notLive = () => isPublic() ? new Set([].concat(lv.guide.added, lv.guide.changed)) : new Set();
    const status = K.status([g, m], offs);
    const ids = () => Array.from(new Set(g.rows.map(r => r.id).filter(Boolean)));
    const partRows = id => g.rows.filter(r => r.id === id);
    const titleOf = id => (partRows(id).find(r => r.title) || {}).title || id;

    // Parts carried from last year nobody has read for this year.
    const unchecked = () => d.ov && d.picked.from ? ids().filter(id => !d.coa.checks['packet:' + id]) : [];
    function checkAll() {
      const list = unchecked();
      const one = i => i >= list.length ? Promise.resolve() : K.coa(y, 'check', { id: 'packet:' + list[i], done: true }).then(() => { d.coa.checks['packet:' + list[i]] = { by: 'you' }; return one(i + 1); });
      one(0).then(() => { A.toast('Checked · ' + K.plural(list.length, 'part'), { undo: () => Promise.all(list.map(id => K.coa(y, 'check', { id: 'packet:' + id, done: false }).then(() => { delete d.coa.checks['packet:' + id]; }))).then(() => { head(); drawParts(); }) }); head(); drawParts(); }, A.fail);
    }

    function head() {
      const n = nl();
      const acts = [status, K.see('packet/?year=' + y, 'Preview')];
      if (!ro && !d.held) {
        if (isPublic() && n) acts.push(h('span', { class: 'ap-tag ap-tag--tan cx-notlive', title: 'Visitors see the packet as it was', text: n + ' not live' }));
        // Read last year's parts first; Publish once they're this year's.
        const u = unchecked().length;
        if (u) acts.push(A.btn('All look right · ' + u, { primary: true, write: true, title: 'You’ve read every part for ' + y, onClick: checkAll }));
        if (!isPublic() || n) acts.push(A.btn('Publish', { primary: !u, write: true, onClick: publish }));
        if (isPublic()) acts.push(A.btn('More', { ghost: true, iconOnly: true, icon: 'more', onClick: e => A.menu(e.currentTarget, [{ label: 'Unpublish', run: unpublish }]) }));
      }
      // The parts' count is on the button while they're unchecked; the fact says what isn't on screen.
      const fact = d.held ? 'Ended ' + K.md(d.row.end) : (isPublic() ? 'Public since ' + K.mdY(posted, y) : 'Not public') + (unchecked().length ? '' : ' · ' + K.plural(ids().length, 'part'));
      ctx.head('Packet', fact, acts);
    }

    A.clear(ctx.body);
    const sp = ctx.split();
    const wrap = h('div', { class: 'cx-page cx-packet' });
    const outline = h('nav', { class: 'cx-outline', 'aria-label': 'Parts' });
    const doc = h('div', { class: 'cx-doc' });
    wrap.append(outline, doc);
    sp.main.appendChild(wrap);

    /* -------------------------------------------------------- the parts */

    function drawOutline() {
      A.clear(outline);
      outline.append(h('span', { class: 'ap-label', text: 'Parts' }), h('ol', null, ids().map(id => h('li', null, h('a', { href: '#pk-' + id, class: notLive().has((partRows(id)[0] || {})._id) ? 'is-notlive' : '', text: titleOf(id) })))),
        h('a', { href: '#pk-menus', class: 'cx-outline__menus', text: 'Menus' }));
    }

    function drawParts() {
      A.clear(doc);
      const checks = factsCheck();
      if (!ro && !d.held) doc.appendChild(h('p', { class: 'ap-help cx-pk__help', text: 'Click any text to change it · Saved as you type' }));
      ids().forEach((id, i) => doc.appendChild(part(id, i, checks.filter(c => c.id === id))));
      if (!ro && !d.held) doc.appendChild(h('p', { class: 'cx-addpart' }, K.link('Add part', addPart, { icon: 'plus' })));
      doc.appendChild(menus());
    }

    function part(id, i, checks) {
      const rows = partRows(id), first = rows[0] || {};
      const moved = (((d.picked.parts || {}).packet || {}).moved || []).filter(x => x.id === id);
      const nlive = rows.some(r => notLive().has(r._id));
      const title = K.textIn({ value: first.title || '', label: 'Part title', placeholder: 'Title', multiline: true, oneLine: true, rows: 1, onSave: v => { if (!v.trim()) return 'A part needs a title'; g.set(first._id, { title: v.trim() }, { label: 'Title', key: first._id + ':title' }); } });
      title.classList.add('cx-pk__title');
      const sum = K.textIn({ value: first.summary || '', label: 'One line', placeholder: 'One line under the title', multiline: true, oneLine: true, rows: 1, onSave: v => g.set(first._id, { summary: v.trim() }, { label: 'One line', key: first._id + ':summary' }) });
      sum.classList.add('cx-pk__sum');
      // As tall as its words (no empty band under a short part); trailing blank lines are trimmed.
      const text = K.textIn({ value: rows.map(r => String(r.text || '').trim()).filter(Boolean).join('\n\n'), label: titleOf(id), multiline: true, rows: 1, placeholder: 'Paragraphs · A blank line starts a new one', onSave: v => saveText(id, v), delay: 900 });
      text.classList.add('cx-pk__text');
      // Move and Remove are rare: one ⋯ on the part's row, opened with a click (never a hover).
      const more = A.btn('More · ' + titleOf(id), { ghost: true, iconOnly: true, icon: 'more', title: 'Move or remove', onClick: e => A.menu(e.currentTarget, [
        i > 0 ? { label: 'Move up', run: () => movePart(id, -1) } : null,
        i < ids().length - 1 ? { label: 'Move down', run: () => movePart(id, 1) } : null,
        { label: 'Remove', run: () => removePart(id) }].filter(Boolean)) });
      const tools = ro || d.held ? null : h('span', { class: 'cx-pk__tools' }, more);
      const sec = h('section', { class: 'cx-pk' + (nlive ? ' is-notlive' : ''), id: 'pk-' + id, 'aria-label': titleOf(id) },
        h('div', { class: 'cx-pk__head' }, title, nlive ? h('span', { class: 'cx-dot-tan', title: 'Not live', 'aria-label': 'Not live' }) : null, carried(id), tools),
        sum,
        text,
        moved.length ? h('p', { class: 'ap-help', text: 'Moved with the Conference · ' + moved.map(x => x.from + ' → ' + x.to).join(' · ') }) : null,
        checks.map(c => h('p', { class: 'cx-issue cx-issue--soft' }, c.label + ' ' + c.was + ' here · Registration says ' + c.to + ' ', ro ? null : K.link('Use ' + c.to, () => usePrice(c)))));
      if (ro || d.held) sec.querySelectorAll('input, textarea').forEach(x => { x.disabled = true; });
      return sec;
    }

    // Carried from last year and not checked: a small mark by the title, with Looks right beside it.
    function carried(id) {
      if (ro || d.held || !d.ov || !d.picked.from || d.coa.checks['packet:' + id]) return null;
      return h('span', { class: 'cx-pk__from' }, A.tag('From ' + d.picked.from, 'tan'), K.link('Looks right', e => {
        e.currentTarget.disabled = true;
        K.coa(y, 'check', { id: 'packet:' + id, done: true }).then(() => { d.coa.checks['packet:' + id] = { by: 'you' }; A.toast('Checked · ' + titleOf(id), { undo: () => K.coa(y, 'check', { id: 'packet:' + id, done: false }).then(() => { delete d.coa.checks['packet:' + id]; drawParts(); }) }); drawParts(); }, A.fail);
      }, { title: 'You’ve read it for this year' }));
    }

    // Paragraphs ↔ rows, in order: changed rows set, new ones added after the part's last, extra removed.
    function saveText(id, v) {
      const paras = String(v).split(/\n\s*\n/).map(s => s.replace(/\s*\n\s*/g, ' ').trim()).filter(Boolean);
      const rows = partRows(id);
      if (!rows.length) return;
      const lastIx = g.rows.indexOf(g.get(rows[rows.length - 1]._id));
      const nextId = (g.rows[lastIx + 1] || {})._id || '';
      g.batch('Text · ' + titleOf(id), () => {
        paras.forEach((t, i) => {
          if (rows[i]) { if ((rows[i].text || '') !== t) g.set(rows[i]._id, { text: t }); }
          else g.add({ id, title: '', summary: '', text: t }, { before: nextId });
        });
        if (!paras.length) g.set(rows[0]._id, { text: '' });
        rows.slice(Math.max(1, paras.length)).forEach(r => g.remove(r._id));
      });
    }
    function movePart(id, dir) {
      const list = ids(), i = list.indexOf(id), j = i + dir;
      if (j < 0 || j >= list.length) return;
      const rows = partRows(id);
      g.batch('Move ' + titleOf(id), () => {
        if (dir < 0) { const before = partRows(list[j])[0]._id; rows.forEach(r => g.move(r._id, before)); }
        else { const after = partRows(list[j]), nxt = g.rows[g.rows.indexOf(g.get(after[after.length - 1]._id)) + 1]; rows.forEach(r => g.move(r._id, nxt ? nxt._id : '')); }
      });
      drawAll();
      A.toast('Moved · ' + titleOf(id), { undo: () => { K.replay(g, 'undo'); drawAll(); } });
    }
    function removePart(id) {
      const t = titleOf(id);
      g.batch('Remove ' + t, () => partRows(id).forEach(r => g.remove(r._id)));
      drawAll();
      A.toast('Removed · ' + t, { undo: () => { K.replay(g, 'undo'); drawAll(); } });
    }
    function addPart() {
      const t = K.textIn({ label: 'Title', placeholder: 'Parking', live: false });
      const go = A.btn('Add', { primary: true, write: true, onClick: () => {
        const title = t.value.trim();
        if (!title) { t.closest('.cx-field').setError('A title'); return; }
        let id = title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 30) || 'part';
        while (ids().indexOf(id) > -1) id += '-2';
        g.add({ id, title, summary: '', text: '' }, { label: 'Add ' + title });
        sp.close(true); drawAll();
        setTimeout(() => { const s = document.getElementById('pk-' + id); if (s) { s.scrollIntoView({ block: 'start' }); const ta = s.querySelector('.cx-pk__sum'); if (ta) ta.focus(); } }, 50);
        A.toast('Added · ' + title, { undo: () => { K.replay(g, 'undo'); drawAll(); } });
      } });
      sp.open({ title: 'Add part', body: K.field('Title', t), foot: [go, A.btn('Cancel', { ghost: true, onClick: () => sp.close() })] });
      t.focus();
    }

    // A price written in the packet that disagrees with Registration (Registration's is what the form charges).
    function factsCheck() {
      const out = [];
      g.rows.forEach(r => ['summary', 'text'].forEach(fld => {
        const t = String(r[fld] || ''), re = /\$\s?\d+(?:\.\d{2})?/g;
        let mm;
        while ((mm = re.exec(t))) {
          const before = t.slice(Math.max(0, mm.index - 60), mm.index);
          let best = null, at = -1;
          FACTS.forEach(fc => { const gg = new RegExp(fc[1].source, 'gi'); let x; while ((x = gg.exec(before))) { if (x.index > at) { at = x.index; best = fc; } } });
          if (!best || !R[best[0]]) continue;
          const v = mm[0].replace(/[$\s]/g, '').replace(/\.00$/, '');
          if (v !== String(R[best[0]]).replace(/\.00$/, '')) out.push({ id: r.id, row: r._id, fld, label: best[2], was: mm[0], to: '$' + R[best[0]] });
        }
      }));
      return out;
    }
    function usePrice(c) {
      const r = g.get(c.row);
      if (!r) return;
      g.set(c.row, { [c.fld]: String(r[c.fld]).replace(c.was, c.to) }, { label: 'Use ' + c.to });
      drawAll();
      A.toast('Changed · ' + c.label + ' ' + c.to, { undo: () => { K.replay(g, 'undo'); drawAll(); } });
    }

    /* -------------------------------------------------------- menus */

    function menus() {
      // Menus have one owner: Food's own screen (or whoever the COA hands it to). Here they're read only.
      const food = A.allowed('food-menus') || !!A.committee('food');
      const ok = A.foreignOf ? A.foreignOf('food-menus') : '', owner = ok ? ((A.committee(ok) || {}).name || '') : '';
      if (food) {
        const meals = new Set(m.rows.map(r => r.day + '|' + r.meal)).size;
        return K.section('Menus', { id: 'pk-menus', act: A.allowed('food-menus') ? A.link({ s: 'food-menus' }, 'Open Menus', 'cx-link') : null },
          // The committee whose screen Menus is this year (never named by rule: no-assumed-owners).
          h('p', { class: 'ap-muted', text: meals ? K.plural(meals, 'meal') + ' with a menu' + (owner ? ' · From ' + owner : '') : 'Waiting for the caterer' }));
      }
      const byDay = {};
      m.rows.forEach(r => { ((byDay[r.day] = byDay[r.day] || {})[r.meal] = byDay[r.day][r.meal] || []).push(r); });
      const days = Object.keys(byDay).sort((a, b) => DAYS.indexOf(a) - DAYS.indexOf(b));
      const act = ro || d.held ? null : h('span', { class: 'ap-row' }, K.link(m.rows.length ? 'Paste a newer menu' : 'Paste', pasteMenu), K.link('Choose a file', fileMenu));
      const sec = K.section('Menus', { id: 'pk-menus', act: m.rows.length ? act : null },
        !m.rows.length ? A.empty({ title: 'Waiting for the caterer', line: 'Paste the menu as sent, or choose a file', action: act }) :
          h('div', { class: 'cx-menus' }, days.map(day => h('div', { class: 'cx-menu' }, h('h3', { class: 'ap-label', text: day }),
            Object.keys(byDay[day]).map(meal => h('p', null, h('b', { text: meal }), ' ', byDay[day][meal].map((r, i) => [i ? ' · ' : '', r.station ? h('i', { text: r.station + ': ' }) : null, r.items])))))));
      return sec;
    }
    function readMenu(t) {
      const out = []; let day = '', meal = '';
      String(t).split(/\r?\n/).map(l => l.trim()).filter(Boolean).forEach(l => {
        const dd = DAYS.find(x => new RegExp('^' + x + '\\b', 'i').test(l));
        if (dd) { day = dd; meal = ''; const rest = l.slice(dd.length).replace(/^[,\s]+/, ''); const mm = MEALS.find(x => new RegExp('^' + x + '\\b', 'i').test(rest)); if (mm) meal = mm === 'Dinner' ? 'Supper' : mm; return; }
        const mm = MEALS.find(x => new RegExp('^' + x + '\\b', 'i').test(l));
        if (mm && l.length < 24) { meal = mm === 'Dinner' ? 'Supper' : mm; return; }
        if (!day || !meal) return;
        const s = l.match(/^([^:]{2,30}):\s*(.+)$/);
        out.push({ day, meal, station: s ? s[1].trim() : '', items: (s ? s[2] : l).trim() });
      });
      return out;
    }
    function useMenu(rows, from) {
      const ta = h('div', { class: 'cx-preview' }, h('p', { class: 'ap-quiet', text: K.plural(rows.length, 'line') + ' · ' + K.plural(new Set(rows.map(r => r.day)).size, 'day') }),
        h('ul', { class: 'cx-prevlist' }, rows.slice(0, 40).map(r => h('li', null, h('span', { class: 'cx-prev__d', text: r.day.slice(0, 3) }), h('span', { class: 'cx-prev__t', text: r.meal }), h('span', { text: (r.station ? r.station + ': ' : '') + r.items })))));
      K.confirm(sp, {
        title: 'Use this menu', lines: [from + (m.rows.length ? ' · Replaces the menu there now' : '')], field: ta, actLabel: 'Use this menu',
        act: () => { m.batch('Menu', () => { m.rows.map(r => r._id).forEach(id => m.remove(id)); rows.forEach(r => m.add(r)); }); return Promise.resolve(); },
        onDone: () => { drawAll(); A.toast('Menu · ' + K.plural(rows.length, 'line'), { undo: () => { K.replay(m, 'undo'); drawAll(); } }); }
      });
    }
    function pasteMenu() {
      const t = h('textarea', { class: 'ap-textarea cx-paste', rows: '10', placeholder: 'FRIDAY\nSupper\nMain: Baked chicken, green beans', 'aria-label': 'The menu' });
      const go = A.btn('Read it', { primary: true, write: true, onClick: () => { const rows = readMenu(t.value); if (!rows.length) { t.closest('.cx-field').setError('No day and meal found · Start with the day, then the meal'); return; } useMenu(rows, 'Pasted'); } });
      sp.open({ title: 'Paste the menu', body: K.field('The menu, as the caterer sent it', t, { help: 'A day’s name, then each meal, then its dishes' }), foot: [go, A.btn('Cancel', { ghost: true, onClick: () => sp.close() })] });
      t.focus();
    }
    function fileMenu() {
      K.pick('.csv,.tsv,.txt,.xlsx').then(f => f && ED.files.read(f).then(got => {
        const head = (got.grid[0] || []).map(c => String(c).trim().toLowerCase());
        let rows;
        if (head.indexOf('day') > -1 && head.indexOf('meal') > -1) rows = got.grid.slice(1).map(c => ({ day: c[head.indexOf('day')] || '', meal: c[head.indexOf('meal')] || '', station: head.indexOf('station') > -1 ? c[head.indexOf('station')] || '' : '', items: c[head.indexOf('items')] || c[head.indexOf('dishes')] || '' })).filter(r => r.day && r.items);
        else rows = readMenu(got.text || got.grid.map(r => r.join(' ')).join('\n'));
        if (!rows.length) { A.toast('No menu found in ' + f.name); return; }
        useMenu(rows, f.name);
      })).catch(err => A.toast(err && err.message ? err.message : 'Not read'));
    }

    /* -------------------------------------------------------- publish */

    function publish() {
      const unchecked = ids().filter(id => d.ov && d.picked.from && !d.coa.checks['packet:' + id]);
      const left = unchecked.map(id => ({ t: titleOf(id) + ' to check', go: () => { const s = document.getElementById('pk-' + id); if (s) s.scrollIntoView({ block: 'start' }); } }));
      if (!m.rows.length) left.push({ t: 'No menus yet' });
      if (factsCheck().length) left.push({ t: K.plural(factsCheck().length, 'price') + ' that disagree with Registration' });
      if (isPublic()) {
        K.confirm(sp, { title: 'Publish ' + K.plural(nl(), 'change'), lines: ['On the Conference page and the printed packet, for everyone'], left, actLabel: 'Publish',
          act: () => Promise.all([g.flush(), m.flush()]).then(() => K.coa(y, 'publish', { part: 'packet', act: 'update' })),
          onDone: () => { A.toast('Published · ' + K.plural(nl(), 'change')); live().then(x => { lv = x; head(); drawAll(); }); } });
        return;
      }
      K.confirm(sp, { title: 'Publish the packet', lines: ['Now · On the Conference page and the printed packet, for everyone', 'Later changes wait for Publish'], left, actLabel: left.length ? 'Publish anyway' : 'Publish',
        act: () => Promise.all([g.flush(), m.flush()]).then(() => K.coa(y, 'publish', { part: 'packet', act: 'publish' })),
        onDone: () => { A.toast('Published · The packet is public'); live().then(x => { lv = x; head(); drawAll(); }); } });
    }
    function unpublish() {
      K.confirm(sp, { title: 'Unpublish the packet', danger: true, reason: true, lines: ['It comes off the Conference page and the printed packet'], actLabel: 'Unpublish',
        act: reason => K.coa(y, 'publish', { part: 'packet', act: 'unpublish', reason }),
        onDone: () => { A.toast('Unpublished · Not public'); live().then(x => { lv = x; head(); drawAll(); }); } });
    }

    /* -------------------------------------------------------- keeping up */

    function drawAll() { drawOutline(); drawParts(); head(); }
    let lt = 0;
    const typing = () => document.activeElement && doc.contains(document.activeElement) && document.activeElement.matches('input, textarea');
    [g, m].forEach(f => {
      offs.push(K.on(f, 'change', e => { if (e && e.server) { clearTimeout(lt); lt = setTimeout(() => live().then(x => { if (x) { lv = x; head(); drawOutline(); } }), 900); } }));
      offs.push(K.on(f, 'remote', () => { if (!typing()) drawAll(); else A.toast('Changed by someone else · Shows when you leave the box'); }));
    });
    offs.push(K.undoKeys(dir => { K.replay(g, dir); drawAll(); }));
    drawAll();
    if (ctx.params.v === 'menus') setTimeout(() => { const s = document.getElementById('pk-menus'); if (s) s.scrollIntoView({ block: 'start' }); }, 50);
  }
})();
