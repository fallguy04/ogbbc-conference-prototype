/*
 * coa-campus.js — Campus: what belongs to the campus rather than the year, carried to the next
 * Conference there. Views: Buildings and rooms (the places the schedule names), Dorm halls, Care nearby
 * and Pins (the walk-through: each room pinned at its door on the map, the map area's tool).
 *
 *   - A place's code changed is renamed everywhere it's used, at once, with Undo (years/{y}/recode).
 *   - Halls whose floor plans are samples say so ("Sample") until Lodging has the campus's real plans.
 *   - Care nearby carried from last year is "From 2026 · Looks right" until checked.
 * Lists save row by row (ED.Rows); a new row stays here until its name is typed.
 */
(function () {
  'use strict';
  const A = window.OGC_APP, K = window.OGC_COA, ED = window.ED, O = window.OGC;
  if (!A || !K || !ED) return;
  const h = A.h;
  const lc = s => String(s == null ? '' : s).trim().toLowerCase();
  const VIEWS = [['', 'Buildings and rooms', 'places'], ['halls', 'Dorm halls', 'rooms'], ['nearby', 'Care nearby', 'nearby'], ['pins', 'Pins', 'places']];

  A.screen({
    id: 'campus', title: 'Campus', icon: 'pin', section: 'own', who: ['coa'],
    render(ctx) {
      const y = ctx.params.year, offs = [];
      let alive = true;
      ctx.head('Campus', '', []);
      K.loading(ctx.body);
      const v = VIEWS.find(x => x[0] === (ctx.params.v || '')) || VIEWS[0];
      K.load(y).then(d => {
        const f = K.rows(y, v[2], d);
        return f.ready.then(() => ({ d, f, v }));
      }).then(st => { if (alive) page(ctx, st, offs); }, err => { if (alive) K.failed(ctx.body, err); });
      return () => { alive = false; offs.forEach(fn => fn()); };
    }
  });

  function page(ctx, st, offs) {
    const { d, f, v } = st;
    const y = d.year, view = v[0];
    const ro = !!(A.readonly || f.opts.readOnly);
    let sel = ctx.params.id || '';
    const status = K.status([f], offs);
    const venue = d.row.venue || d.S.venue || '';
    const head = () => {
      const acts = [status];
      if (!d.held && view !== 'pins') acts.push(A.btn(view === 'halls' ? 'Add floor' : view === 'nearby' ? 'Add place' : 'Add room', { write: true, icon: 'plus', onClick: add }));
      ctx.head('Campus', venue ? venue + (d.picked.campus && d.picked.campus !== y && !d.coa.checks['campus:places'] ? ' · From ' + d.picked.campus : '') : 'No campus yet', acts);
    };
    head();
    A.clear(ctx.body);
    const sp = ctx.split();
    sp.el.classList.add('cx-split');
    const counts = { '': d.rowsOf('places').length, halls: new Set(d.rowsOf('rooms').map(r => r.hall)).size, nearby: d.rowsOf('nearby').length };
    sp.main.appendChild(h('div', { class: 'ap-views' }, A.views(VIEWS.map(x => ({ id: x[0], label: x[1], n: x[0] === 'pins' ? null : counts[x[0]] })), view, id => A.go({ v: id, id: '' }))));
    const list = h('div', { class: 'cx-list' });
    sp.main.appendChild(list);
    if (!venue) { list.appendChild(A.empty({ inset: true, title: 'No campus yet', line: 'Choose it on Dates and place', action: A.link({ s: 'dates', v: '', id: '' }, 'Dates and place', 'ap-btn') })); return; }

    /* -------------------------------------------------------- Pins: the map area's walk-through */
    if (view === 'pins') {
      const slot = h('div', { class: 'cx-page cx-pins', id: 'yr-pinmap' });
      list.appendChild(slot);
      if (O.map && O.map.pins) {
        const tool = O.map.pins({ year: y, places: f.rows, onSaved: () => K.drop(y) });
        tool.mount(slot);
      } else slot.appendChild(A.empty({ title: 'No map for this campus yet', line: 'The campus map comes with its buildings' }));
      return;
    }

    /* -------------------------------------------------------- the lists */
    const plans = d.rowsOf('plans');
    const sampleHall = hall => plans.some(p => p.hall === hall && p.status === 'sample');
    const SPEC = {
      '': {
        one: 'room', name: r => r.name || r.code || 'New room', key: 'name',
        sort: (a, b) => lc(a.building).localeCompare(lc(b.building)) || lc(a.code).localeCompare(lc(b.code)),
        group: r => r.building || 'No building',
        // The code is a small tag right after the name (not a column a screen away); inside its
        // building's group a room doesn't repeat the building ("Globe Theater", not "… (Barnes)").
        cols: [['Name', r => h('span', null, h('span', { class: 'ap-cell-title', text: inGroup(r) }), r.code ? h('span', { class: 'cx-code', text: r.code }) : null, r.inside ? h('span', { class: 'ap-cell-sub', text: r.inside }) : null)], ['Floor', r => r.floor || '', rs => rs.some(r => r.floor)], ['Pin', r => r.x !== '' && r.x != null ? A.tag('Pinned', 'ok') : h('span', { class: 'ap-quiet', text: 'Not pinned' }), rs => rs.some(r => r.x !== '' && r.x != null)]],
        fields: r => [
          tf('Name', 'name', r, { placeholder: 'Barnes Rooms 133 A–D', need: 'A room needs a name' }),
          K.field('Code', codeIn(r), { help: 'On the schedule and the printout · Changing it renames it everywhere' }),
          tf('Building', 'building', r, { list: Array.from(new Set(f.rows.map(x => x.building).filter(Boolean))), placeholder: 'Barnes Student Center' }),
          K.field('Floor', K.pills([['', 'Not said'], ['Lower', 'Lower'], ['Ground', 'Ground'], ['2', '2nd'], ['3', '3rd']], r.floor || '', val => set(r._id, { floor: val }, 'Floor')), { tag: 'div' }),
          tf('Inside', 'inside', r, { placeholder: 'Past the cafeteria, on the left', help: 'Said with the directions' })
        ],
        blank: { code: '', name: '', building: '' }
      },
      halls: {
        one: 'floor', name: r => (r.hall || 'New hall') + (r.floor ? ' · Floor ' + r.floor : ''), key: 'hall',
        sort: (a, b) => lc(a.hall).localeCompare(lc(b.hall)) || String(a.floor).localeCompare(String(b.floor)),
        group: r => r.hall || 'No hall',
        groupMark: hall => [sampleHall(hall) ? A.tag('Sample', 'tan') : null, beds(hall)],
        cols: [['Floor', r => r.floor || ''], ['Rooms', r => h('span', { class: 'cx-nowrap', text: r.first ? r.first + (r.last && r.last !== r.first ? '–' + r.last : '') : '' })], ['Beds', r => r.beds || ''], ['For', r => r.for || ''], ['Bathrooms', r => ({ private: 'Private', pairs: 'Shared by pairs', hall: 'Down the hall' })[r.share] || '']],
        fields: r => [
          tf('Hall', 'hall', r, { list: Array.from(new Set(f.rows.map(x => x.hall).filter(Boolean))), placeholder: 'Hodson Hall', need: 'A hall' }),
          h('div', { class: 'cx-two' }, tf('Floor', 'floor', r, { placeholder: '1' }), tf('Beds a room', 'beds', r, { placeholder: '2', inputmode: 'numeric', check: x => !x || /^\d{1,2}$/.test(x) ? '' : 'A number' })),
          h('div', { class: 'cx-two' }, tf('First room', 'first', r, { placeholder: '101' }), tf('Last room', 'last', r, { placeholder: '132' })),
          K.field('For', K.pills([['', 'Anyone'], ['families', 'Families'], ['young men', 'Young men'], ['young women', 'Young women']], lc(r.for), val => set(r._id, { for: val }, 'For')), { tag: 'div' }),
          K.field('Bathrooms', K.pills([['private', 'Private'], ['pairs', 'Shared by pairs'], ['hall', 'Down the hall']], r.share || '', val => set(r._id, { share: val }, 'Bathrooms')), { tag: 'div', help: 'Older guests are placed by this' }),
          tf('Note', 'note', r, { placeholder: 'Optional' }),
          sampleHall(r.hall) ? h('p', { class: 'cx-issue cx-issue--soft', text: 'Sample floor plan · Lodging replaces it with the campus’s plans' }) : null
        ],
        blank: { hall: '', floor: '', first: '', last: '', beds: '2' }
      },
      nearby: {
        one: 'place', name: r => r.name || 'New place', key: 'name',
        sort: (a, b) => lc(a.kind).localeCompare(lc(b.kind)) || lc(a.name).localeCompare(lc(b.name)),
        group: r => r.kind || 'Other',
        cols: [['Name', r => h('span', null, h('span', { class: 'ap-cell-title', text: r.name || 'Untitled' }), r.address ? h('span', { class: 'ap-cell-sub', text: r.address }) : null)], ['Phone', r => h('span', { class: 'cx-nowrap', text: r.phone || '' })], ['Hours', r => r.hours || ''], ['How far', r => r.distance || '']],
        fields: r => [
          K.looks(d, 'nearby:' + r.name, { what: r.name, line: 'Not public until checked', done: () => K.load(y, { force: true }).then(nd => { d.coa = nd.coa; }) }),
          K.field('Kind', K.pills([['Urgent care', 'Urgent care'], ['Hospital', 'Hospital'], ['Pharmacy', 'Pharmacy']], r.kind || '', val => set(r._id, { kind: val }, 'Kind')), { tag: 'div' }),
          tf('Name', 'name', r, { placeholder: 'Marion Health urgent care', need: 'A name' }),
          tf('Address', 'address', r, { placeholder: 'Street, town' }),
          h('div', { class: 'cx-two' }, tf('Phone', 'phone', r, { inputmode: 'tel', placeholder: '765-660-7892' }), tf('How far', 'distance', r, { placeholder: 'About 1 mile' })),
          tf('Hours', 'hours', r, { placeholder: 'Open 24 hours' })
        ],
        blank: { kind: 'Urgent care', name: '', address: '', phone: '', hours: '', distance: '' }
      }
    };
    const S = SPEC[view];
    const set = (id, fields, label) => { f.set(id, fields, { label, key: id + ':' + Object.keys(fields)[0] }); if (f.isHeld(id) && Object.values(fields).some(Boolean)) f.release(id); };
    function tf(label, key, r, o) {
      o = o || {};
      const i = K.textIn({ value: r[key] || '', label, placeholder: o.placeholder, inputmode: o.inputmode, onSave: val => {
        const t = val.trim();
        if (o.need && !t) return o.need;
        if (o.check) { const e = o.check(t); if (e) return e; }
        set(r._id, { [key]: t }, label);
        if (key === S.key) { const tt = sp.panel.querySelector('.ap-panel__title'); if (tt) tt.textContent = S.name(f.get(r._id)); }
        draw();
      } });
      if (o.list) { const id = 'cx-l-' + key + Math.random().toString(36).slice(2, 6); i.setAttribute('list', id); return K.field(label, h('div', null, i, h('datalist', { id }, o.list.map(x => h('option', { value: x })))), { help: o.help }); }
      return K.field(label, i, { help: o.help });
    }
    function beds(hall) {
      const n = f.rows.filter(r => r.hall === hall).reduce((s, r) => { const a = parseInt(r.first, 10), b = parseInt(r.last || r.first, 10); return s + (a && b && b >= a ? (b - a + 1) * (+r.beds || 0) : 0); }, 0);
      return n ? h('span', { class: 'ap-quiet', text: ' · ' + K.plural(n, 'bed') }) : null;
    }
    // A code renamed everywhere it's used (schedule, shifts), with Undo.
    function codeIn(r) {
      const i = K.textIn({ value: r.code || '', label: 'Code', placeholder: 'B/JLB', width: '160px', live: false, onSave: val => {
        const t = val.trim().toUpperCase(), was = String(r.code || '').toUpperCase();
        if (!t) return 'A code';
        if (!/^[A-Z0-9][A-Z0-9/ .&-]{0,23}$/.test(t)) return 'Letters, numbers and / only';
        if (t !== was && f.rows.some(x => x._id !== r._id && String(x.code).toUpperCase() === t)) return 'Already used by ' + (f.rows.find(x => String(x.code).toUpperCase() === t) || {}).name;
        if (!was || f.isHeld(r._id)) { set(r._id, { code: t }, 'Code'); draw(); return; }
        if (t === was) return;
        K.api('POST', 'years/' + y + '/recode', { map: { [was]: t } }).then(res => {
          K.drop(y); f.sync();
          A.toast('Renamed · ' + was + ' → ' + t + (res && res.counts ? ' · ' + Object.keys(res.counts).map(k => res.counts[k] + ' ' + k).join(', ') : ''), { undo: () => K.api('POST', 'years/' + y + '/recode', { map: { [t]: was } }).then(() => { f.sync(); A.toast('Undone · ' + was); }, A.fail) });
        }, err => { A.fail(err); i.set(was); });
      } });
      return i;
    }

    // "Recreation and Wellness Center" and "Recreation & Wellness Center" are one building.
    function norm(t) { return lc(t).replace(/&/g, 'and').replace(/[^a-z0-9]+/g, ' ').trim(); }
    function inGroup(r) {
      const n = r.name || 'Untitled';
      if (!norm(r.building)) return n;
      return n.replace(/\s*\(([^)]+)\)$/, (m, inner) => norm(r.building).indexOf(norm(inner)) === 0 || norm(inner).indexOf(norm(r.building).split(' ')[0]) === 0 ? '' : m);
    }
    function draw() {
      A.clear(list);
      // Carried from the last Conference at this campus: one Looks right for the whole list.
      if (view === '' && !d.held && d.picked.campus) list.appendChild(h('div', { class: 'cx-page cx-page--strip' }, K.looks(d, 'campus:places', { always: true, what: 'Campus', line: 'Rooms and codes from ' + d.picked.campus, done: () => K.load(y, { force: true }).then(nd => { d.coa = nd.coa; head(); draw(); }) })));
      const rows = f.rows.slice().sort((a, b) => view === '' ? (norm(a.building).localeCompare(norm(b.building)) || lc(a.code).localeCompare(lc(b.code))) : S.sort(a, b));
      if (!rows.length) { list.appendChild(A.empty({ inset: true, title: 'No ' + v[1].toLowerCase() + ' yet', line: view === 'halls' ? 'Each hall’s floors, with their rooms and beds' : view === 'nearby' ? 'Urgent care, hospitals and pharmacies, for Places' : 'The rooms the schedule names' })); return; }
      // A column with nothing in it isn't drawn.
      const cols = S.cols.filter(c => c[2] ? c[2](rows) : rows.some(r => { const x = c[1](r); return x && (typeof x === 'string' ? x : x.textContent); }));
      // A building's own row is its group's heading (with its code), not a repeat under it. A building
      // with nothing else under it is one plain row, never an empty heading.
      const key = r => view === '' ? norm(S.group(r)) : S.group(r);
      const own = gg => view === '' ? rows.find(r => norm(r.name) === gg) : null;
      const size = {};
      rows.forEach(r => { size[key(r)] = (size[key(r)] || 0) + 1; });
      const tb = h('tbody');
      let g = null;
      // Buildings with nothing in them come last, under one heading.
      const lone = r => view === '' && size[key(r)] === 1 && own(key(r)) === r;
      rows.sort((a, b) => lone(a) - lone(b));
      let otherDone = false;
      rows.forEach(r => {
        const kk = key(r), gg = S.group(r);
        if (lone(r)) {
          if (!otherDone) { otherDone = true; tb.appendChild(h('tr', { class: 'ap-tr--group' }, h('td', { colspan: String(cols.length), text: 'Other buildings' }))); }
          tb.appendChild(h('tr', { 'data-key': r._id, 'aria-selected': String(r._id === sel), tabindex: '-1', on: { click: () => open(r._id) } }, cols.map(c => h('td', null, c[1](r)))));
          g = kk;
          return;
        }
        if (kk !== g) {
          g = kk;
          const b = own(kk);
          tb.appendChild(h('tr', { class: 'ap-tr--group' + (b ? ' cx-grouprow' : ''), 'data-key': b ? b._id : null, 'aria-selected': b ? String(b._id === sel) : null, on: b ? { click: () => open(b._id) } : null },
            h('td', { colspan: String(cols.length) }, b ? b.name : gg, b && b.code ? h('span', { class: 'cx-groupcode', text: ' · ' + b.code }) : null, S.groupMark ? S.groupMark(gg) : null)));
        }
        if (own(kk) === r) return;
        tb.appendChild(h('tr', { 'data-key': r._id, 'aria-selected': String(r._id === sel), tabindex: '-1', on: { click: () => open(r._id) } }, cols.map(c => h('td', null, c[1](r)))));
      });
      list.appendChild(h('div', { class: 'ap-tablewrap' }, h('table', { class: 'ap-table', 'aria-label': v[1] }, h('thead', null, h('tr', null, cols.map(c => h('th', { scope: 'col', text: c[0] })))), tb)));
    }
    function open(id) {
      const r = f.get(id);
      if (!r) return;
      if (sel && sel !== id && f.isHeld(sel)) f.discard(sel);
      sel = id;
      A.setParams({ v: view, id });
      list.querySelectorAll('tr[data-key]').forEach(x => x.setAttribute('aria-selected', String(x.dataset.key === id)));
      const body = h('div', { class: 'cx-rec' }, S.fields(r));
      const foot = ro || d.held ? null : [A.btn('Remove', { ghost: true, danger: true, write: true, onClick: () => { const t = S.name(r); f.remove(id, { label: 'Remove' }); sp.close(true); sel = ''; draw(); A.toast('Removed · ' + t, { undo: () => { K.replay(f, 'undo'); draw(); } }); } })];
      // Previous · Next through the rows as listed (the record kit, Round 3).
      const keys = [...list.querySelectorAll('[data-key]')].map(x => x.dataset.key).filter((k, i, a) => k && a.indexOf(k) === i);
      const i = keys.indexOf(id);
      sp.open({ title: S.name(r), body, foot, onClose: () => { if (f.isHeld(id)) f.discard(id); sel = ''; A.setParams({ id: '' }); draw(); },
        tags: r.code ? [A.tag(r.code)] : null,
        nav: i < 0 ? null : { prev: i > 0 ? () => open(keys[i - 1]) : null, next: i < keys.length - 1 ? () => open(keys[i + 1]) : null } });
      if (!K.wide()) window.scrollTo(0, 0);
      if (ro || d.held) sp.panel.querySelectorAll('input, textarea, button.ap-pill').forEach(x => { x.disabled = true; });
    }
    function add() {
      const id = f.add(Object.assign({}, S.blank), { hold: true, label: 'Add ' + S.one });
      draw(); open(id);
    }
    offs.push(K.on(f, 'remote', draw));
    offs.push(K.undoKeys(dir => { K.replay(f, dir); draw(); if (sel && f.get(sel)) open(sel); }));
    draw();
    if (sel && f.get(sel)) open(sel);
  }
})();
