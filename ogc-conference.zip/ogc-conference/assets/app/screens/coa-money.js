/*
 * coa-money.js — Money (night-records, Oct 13): the treasurer's ledger, as a CRM (docs/25 rule 5;
 * docs/scope/02 flow E and Q). And the pieces Households shares (window.OGC_REC, window.OGC_MONEY).
 *
 * Who sees what (docs/26 #4, #25, as recommended): the COA sees the year's totals and who handles money;
 * people the COA ticked "Handles money" on Members also see each payment line and work them:
 *   Checks to come   tick twenty and Mark received, or one at a time with its amount and number
 *   Check received   one check for one or several households: an amount against each until it adds up
 *   Owed             households with something to pay (each opens beside the list)
 *   Refunds          Approve (one or many), then Sent with the payment company's or the check's number,
 *                    or Decline. The site never sends money.
 *   Received         money in, newest first; tick checks taken to the bank and press New deposit
 *   Deposits         each with its lines added up and the bank's figure: "Off by $20" when they differ
 *   Everything       every line, for Excel (Export: the same columns every year)
 * Every act has Undo in its toast (POST app/{y}/ledger/undo). Routes: module-payments-ledger.php.
 */
(function () {
  'use strict';
  const A = window.OGC_APP, K = window.OGC_COA, W = window.OGC_WP || {};
  if (!A || !K) return;
  const h = A.h;
  const money = c => K.money(c || 0);
  const errOf = e => (e && e.data && e.data.message) || (e && e.message) || 'Not saved';

  /* ================================================================ the kit (OGC_REC) */

  const R = window.OGC_REC = {};
  // Money as its word with a dot: red for owed, tan for coming or to give back. Paid is the ordinary
  // case: its word alone, the plain dot (docs/30 settle 11, no green).
  R.TONE = { due: 'late', balance: 'late', checkin: 'look', check: 'look', refund: 'look', paid: '', refunded: '', none: '', form_due: 'late', form_paid: '', form: '' };
  R.money = (key, words) => h('span', { class: 'rx-money' }, h('span', { class: 'rx-dot' + (R.TONE[key] ? ' rx-dot--' + R.TONE[key] : ''), 'aria-hidden': 'true' }), words);
  R.status = (key, words) => A.tag(words, key === 'placed' ? 'tan' : key === 'checked_in' ? 'ok' : '');
  // A dollar amount typed: "$455", "455.50". el.cents() → whole cents or 0.
  R.amount = function (cents, label) {
    const i = h('input', { class: 'ap-input', inputmode: 'decimal', autocomplete: 'off', value: cents ? (cents / 100).toFixed(cents % 100 ? 2 : 0) : '', 'aria-label': label || 'Amount', placeholder: '0' });
    const el = h('span', { class: 'rx-amount' }, h('span', { text: '$', 'aria-hidden': 'true' }), i);
    el.input = i;
    el.cents = () => { const v = parseFloat(String(i.value).replace(/[$,\s]/g, '')); return isFinite(v) && v > 0 ? Math.round(v * 100) : 0; };
    return el;
  };
  R.text = (o) => h('input', Object.assign({ class: 'ap-input', autocomplete: 'off' }, o || {}));
  // Words the search matches: a household's name and its R-number (never its note).
  R.matches = (find, ...fields) => {
    const words = String(find || '').toLowerCase().split(/\s+/).filter(Boolean);
    const hay = fields.join(' ').toLowerCase();
    return words.every(w => hay.indexOf(w) > -1);
  };
  R.find = function (value, onInput, placeholder) {
    const i = h('input', { class: 'ap-input', type: 'search', value: value || '', placeholder: placeholder || 'Search', 'aria-label': placeholder || 'Search', autocomplete: 'off' });
    let t = 0;
    i.addEventListener('input', () => { clearTimeout(t); t = setTimeout(() => onInput(i.value), 120); });
    return h('label', { class: 'rx-find' }, A.icon('search', 14), i);
  };
  // A filter on one fixed field: a small menu of its values with their counts. opts [{ v, label, n }]
  R.filter = function (label, cur, opts, onPick) {
    const now = opts.find(x => x.v === cur);
    const b = h('button', { type: 'button', class: 'rx-filter', 'aria-pressed': String(!!now), 'aria-haspopup': 'menu', title: 'Filter by ' + label },
      now ? label + ' · ' + now.label : label, A.icon('down', 12));
    b.addEventListener('click', () => A.menu(b, [{ label: 'Any ' + label.toLowerCase(), current: !now, run: () => onPick('') }]
      .concat(opts.map(x => ({ label: [x.label, h('span', { class: 'rx-menu__n', text: String(x.n) })], current: now && now.v === x.v, run: () => onPick(x.v) })))));
    return b;
  };
  // The bulk bar over a list with ticked rows: "3 selected · Export · Mark received · Clear". Ticks stay
  // through a search: hidden says how many of them the list isn't showing now ("2 not shown").
  R.bulk = (n, acts, clear, hidden) => n ? h('div', { class: 'rx-bulk', role: 'region', 'aria-label': 'Selected rows' },
    h('span', { class: 'rx-bulk__n', text: n + ' selected' }),
    hidden ? h('span', { class: 'rx-bulk__hid', text: hidden + ' not shown', title: 'Ticked before the search or filter changed · Still included' }) : null,
    acts.filter(Boolean), h('button', { type: 'button', class: 'rx-clear', text: 'Clear', on: { click: clear } })) : null;

  /*
   * A list on fixed fields: sortable headings, a tick on each row (and one for all), the record beside it.
   * o: { label, rows, key, name(row), cols: [{ id, label, cls, num, wide, side, sort, render }],
   *      sort: { id, dir }, onSort(id), ticks: Set|null, onTick(), selected, onOpen(row), gone(row), empty }
   * wide: hidden on a phone; side: hidden while a record is open beside the list.
   */
  R.table = function (o) {
    if (!o.rows.length) return o.empty || A.empty({ title: 'None', inset: true });
    const ticks = o.ticks;
    const keys = o.rows.map(r => String(o.key(r)));
    // rx-wide, not the kit's ap-td--wide: committee.css hides those whenever a panel is open.
    const cellCls = c => (c.cls || '') + (c.num ? ' ap-td--num' : '') + (c.wide ? ' rx-wide' : '') + (c.side ? ' rx-side' : '');
    const head = h('tr');
    let all = null;
    const tb = h('tbody');
    const sync = () => {
      if (!all) return;
      const on = keys.filter(k => ticks.has(k)).length;
      all.checked = on > 0 && on === keys.length;
      all.indeterminate = on > 0 && on < keys.length;
    };
    if (ticks) {
      all = h('input', { type: 'checkbox', class: 'ap-check', 'aria-label': 'Select all ' + keys.length, title: 'Select all' });
      all.addEventListener('change', () => {
        keys.forEach(k => { if (all.checked) ticks.add(k); else ticks.delete(k); });
        tb.querySelectorAll('tr[data-key]').forEach(tr => { const on = ticks.has(tr.dataset.key); tr.classList.toggle('is-ticked', on); const cb = tr.querySelector('.rx-tick input'); if (cb) cb.checked = on; });
        if (o.onTick) o.onTick();
      });
      head.appendChild(h('th', { class: 'rx-tick', scope: 'col' }, all));
    }
    o.cols.forEach(c => {
      const sorted = o.sort && o.sort.id === c.id;
      head.appendChild(h('th', { scope: 'col', class: cellCls(c), 'aria-sort': sorted ? (o.sort.dir < 0 ? 'descending' : 'ascending') : null },
        c.sort && o.onSort ? h('button', { type: 'button', class: 'rx-sort', title: 'Sort by ' + c.label.toLowerCase(), on: { click: () => o.onSort(c.id) } }, c.label, sorted ? A.icon('down', 12) : null) : c.label));
    });
    o.rows.forEach(row => {
      const k = String(o.key(row));
      const tr = h('tr', { 'data-key': k, 'aria-selected': String(String(o.selected) === k), tabindex: '-1', class: ((ticks && ticks.has(k)) ? 'is-ticked' : '') + (o.gone && o.gone(row) ? ' is-gone' : '') });
      if (ticks) {
        const cb = h('input', { type: 'checkbox', class: 'ap-check', checked: ticks.has(k), 'aria-label': 'Select ' + (o.name ? o.name(row) : k) });
        cb.addEventListener('change', () => { if (cb.checked) ticks.add(k); else ticks.delete(k); tr.classList.toggle('is-ticked', cb.checked); sync(); if (o.onTick) o.onTick(); });
        tr.appendChild(h('td', { class: 'rx-tick' }, cb));
      }
      o.cols.forEach(c => tr.appendChild(h('td', { class: cellCls(c) }, c.render(row))));
      tr.addEventListener('click', e => { if (e.target.closest('button, a, input, label')) return; if (o.onOpen) o.onOpen(row); });
      tb.appendChild(tr);
    });
    sync();
    const t = h('table', { class: 'ap-table rx-table', 'aria-label': o.label }, h('thead', null, head), tb);
    const wrap = h('div', { class: 'ap-tablewrap', tabindex: '0', role: 'group', 'aria-label': o.label + ' · Arrow keys move · Enter opens' + (ticks ? ' · Space selects' : '') }, t);
    wrap.addEventListener('keydown', e => {
      if (e.target !== wrap && e.target.closest('input, button, a')) return;
      const trs = [...tb.querySelectorAll('tr[data-key]')];
      if (!trs.length) return;
      let i = trs.findIndex(r => r.getAttribute('aria-selected') === 'true');
      if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
        e.preventDefault();
        i = e.key === 'ArrowDown' ? Math.min(trs.length - 1, i + 1) : Math.max(0, i < 0 ? 0 : i - 1);
        trs.forEach(r => r.setAttribute('aria-selected', 'false'));
        trs[i].setAttribute('aria-selected', 'true');
        trs[i].scrollIntoView({ block: 'nearest' });
      } else if (e.key === 'Enter' && i >= 0) {
        e.preventDefault();
        const row = o.rows[keys.indexOf(trs[i].dataset.key)];
        if (row && o.onOpen) o.onOpen(row);
      } else if (e.key === ' ' && i >= 0 && ticks) {
        e.preventDefault();
        const cb = trs[i].querySelector('.rx-tick input');
        if (cb) { cb.checked = !cb.checked; cb.dispatchEvent(new Event('change')); }
      }
    });
    return wrap;
  };

  // A file from a route (CSV), saved: "Payments 2027 2027-04-15.csv".
  R.download = function (path, name, say) {
    const asOf = (new URLSearchParams(location.search).get('as-of') || '').slice(0, 10);
    const as = A.params().as;
    let url = (W.rest || '/wp-json/ogc/v1/') + path;
    if (as) url += (url.includes('?') ? '&' : '?') + 'as=' + encodeURIComponent(as);
    if (/^\d{4}-\d\d-\d\d$/.test(asOf)) url += (url.includes('?') ? '&' : '?') + 'as_of=' + asOf;
    return fetch(url, { credentials: 'same-origin', headers: { 'X-WP-Nonce': W.nonce } })
      .then(r => { if (!r.ok) throw new Error('Not exported'); return r.blob(); })
      .then(b => { const a = h('a', { href: '#', download: name }); a.href = URL.createObjectURL(b); document.body.appendChild(a); a.click(); setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 1000); A.toast(say || 'Exported'); })
      .catch(() => A.toast('Not exported'));
  };

  /* ================================================================ the money acts (OGC_MONEY) */

  const M = window.OGC_MONEY = {};
  // What just happened, with Undo (24 hours on the server; the toast's own 7 seconds here).
  // keep: the record stays open (a household's panel after Record payment); else the panel closes.
  M.done = function (res, again, keep) {
    A.toast(res.say || 'Done', res.undo ? { undo: () => A.api('POST', 'ledger/undo', { token: res.undo }).then(r => { A.toast(r.say || 'Undone'); if (again) again(); }, A.fail) } : null);
    if (!keep) A.setParams({ id: '' });
    M.back = !keep;
    if (again) again();
  };
  // After an act, the search box has the focus again with its words selected: the next surname is
  // typed straight over it (twenty envelopes, one after another).
  M.refocus = function (bar) {
    if (!M.back) return;
    M.back = false;
    const i = bar && bar.querySelector('.rx-find input');
    if (i && K.wide()) { i.focus(); i.select(); }
  };
  // Minutes a receipt waits after money is marked in (Undo's time); the server says.
  M.wait = 10;
  const receiptLine = () => h('p', { class: 'ap-help', text: 'Receipt emailed in ' + M.wait + ' min · Undo stops it' });
  const today = () => (new URLSearchParams(location.search).get('as-of') || '').slice(0, 10);
  const dayField = (label, set) => K.field(label, K.dateIn({ value: '', placeholder: 'Today', label, near: today() || undefined, onSave: v => { set(v); } }), { tag: 'div' });
  // The panel's foot: the act and Cancel. The act reports an error at the panel's own line.
  function form(sp, o) {
    const err = h('p', { class: 'ap-err', role: 'alert' });
    let again = false;
    const go = A.btn(o.act, { primary: true, write: true, onClick: () => {
      const body = o.body();
      if (typeof body === 'string') { err.textContent = body; return; }
      go.disabled = true;
      err.textContent = '';
      if (again) body.again = true;
      // The same number and amount received already: said once; pressing again saves it anyway.
      A.api('POST', o.path, body).then(res => { sp.close(true); M.done(res, o.again, o.keep); }, e => { go.disabled = false; again = !!(e && e.data && e.data.dup); err.textContent = errOf(e); });
    } });
    sp.open({ title: o.title, nav: o.nav, tags: o.tags, body: h('div', null, o.fields, err, o.linked || null), foot: [go, A.btn('Cancel', { ghost: true, onClick: () => (o.back ? o.back() : sp.close()) })], onClose: o.onClose });
    const first = sp.panel.querySelector('input');
    if (first && K.wide()) first.focus();
    return go;
  }

  // One check to come, received: its amount (less leaves the rest to come), number, day.
  M.received = function (sp, l, o) {
    o = o || {};
    const amt = R.amount(l.cents, 'Amount');
    const ref = R.text({ placeholder: 'Number', 'aria-label': 'Check number', inputmode: 'numeric', style: { maxWidth: '180px' } });
    let day = '';
    form(sp, {
      title: 'Mark received', act: 'Mark received', path: 'ledger/received', again: o.again, keep: o.keep, back: o.back, onClose: o.onClose, nav: o.nav, tags: o.tags, linked: o.linked,
      fields: [
        h('p', { class: 'rx-panel__line' }, h('b', { text: l.label }), ' · ' + l.rid),
        K.field('Amount', amt, { help: 'Expected ' + money(l.cents) + ' · Less leaves the rest as a check to come' }),
        K.field('Check number', ref),
        dayField('Received', v => { day = v; }),
        receiptLine(),
        o.several ? h('p', { class: 'rx-quiet-line' }, K.link('One check for several households', () => o.several())) : null
      ],
      body: () => amt.cents() ? { lines: [l.id], cents: amt.cents(), ref: ref.value.trim(), day } : 'Enter an amount'
    });
  };

  /*
   * Ticked checks to come, received: each with its number and its amount (filled in with what was
   * expected), one under another; Enter moves down the Number column as in a spreadsheet, and on the
   * last one saves. The day is for all of them.
   */
  M.receivedMany = function (sp, lines, o) {
    o = o || {};
    let day = '';
    lines = lines.slice(0, 60);
    const rows = lines.map(l => ({ l, amt: R.amount(l.cents, 'Amount for ' + l.label), ref: R.text({ placeholder: 'Number', 'aria-label': 'Check number for ' + l.label, inputmode: 'numeric', maxlength: '40' }) }));
    const total = h('b');
    const sumUp = () => { total.textContent = money(rows.reduce((n, r) => n + r.amt.cents(), 0)); };
    rows.forEach(r => r.amt.input.addEventListener('input', sumUp));
    sumUp();
    const table = h('table', { class: 'rx-many', 'aria-label': 'Checks to mark received' },
      h('thead', null, h('tr', null, h('th', { scope: 'col', text: 'Household' }), h('th', { scope: 'col', text: 'Number' }), h('th', { scope: 'col', class: 'ap-td--num', text: 'Amount' }))),
      h('tbody', null, rows.map(r => h('tr', null,
        h('td', null, h('span', { class: 'rx-name', text: r.l.label }), h('span', { class: 'rx-sub', text: r.l.rid + ' · Expected ' + money(r.l.cents) })),
        h('td', null, r.ref), h('td', { class: 'ap-td--num' }, r.amt)))));
    const go = form(sp, {
      title: 'Mark received · ' + lines.length, act: 'Mark received · ' + lines.length, path: 'ledger/received', again: o.again, onClose: o.onClose,
      fields: [
        h('p', { class: 'rx-panel__line' }, K.plural(lines.length, 'check') + ' · ', total),
        table,
        dayField('Received', v => { day = v; }),
        h('p', { class: 'ap-help', text: 'Enter moves to the next number · Less than expected leaves the rest as a check to come' }),
        receiptLine()
      ],
      body: () => {
        const bad = rows.find(r => !r.amt.cents());
        if (bad) { bad.amt.input.focus(); return 'Enter an amount · ' + bad.l.label; }
        return { items: rows.map(r => ({ line: r.l.id, cents: r.amt.cents(), ref: r.ref.value.trim() })), day };
      }
    });
    // The first Number has the focus: type, Tab, type.
    if (rows[0] && K.wide()) rows[0].ref.focus();
    // Enter in a Number moves to the next one; on the last, it saves.
    rows.forEach((r, i) => r.ref.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); if (rows[i + 1]) rows[i + 1].ref.focus(); else go.click(); } }));
  };

  /*
   * One check for one or several households (a district's, a family's): its number, amount, the name on
   * it, then an amount against each household it covers until "Adds up". hh: the households to pick from
   * ({ id, rid, label, money_w, balance, check }); preset: households to start with.
   */
  M.check = function (sp, hh, preset, o) {
    o = o || {};
    const parts = [];
    const total = R.amount(0, 'Check amount');
    const ref = R.text({ placeholder: 'Number', 'aria-label': 'Check number', inputmode: 'numeric' });
    const by = R.text({ placeholder: 'Name on the check', 'aria-label': 'Paid by', maxlength: '80' });
    let day = '';
    const list = h('ul', { class: 'rx-parts', 'aria-label': 'Households on this check' });
    const left = h('div', { class: 'rx-left', role: 'status', 'aria-live': 'polite' });
    const pick = h('ul', { class: 'rx-pick', 'aria-label': 'Matches' });
    const find = h('input', { class: 'ap-input', type: 'search', placeholder: 'Surname or R-number', 'aria-label': 'Add a household', autocomplete: 'off' });
    const owed = x => x.check > 0 ? x.check : x.balance;
    let go = null;
    const sum = () => {
      const t = total.cents(), s = parts.reduce((n, p) => n + p.a.cents(), 0), d = t - s;
      A.clear(left);
      left.className = 'rx-left' + (t && parts.length ? (d === 0 ? ' is-even' : ' is-off') : '');
      left.appendChild(h('span', { text: !t ? 'Enter the check’s amount' : !parts.length ? 'Add the households it pays for' : d > 0 ? 'Not yet assigned' : d < 0 ? 'Over by' : 'Adds up' }));
      if (t && parts.length) left.appendChild(h('b', { text: d === 0 ? money(s) : money(Math.abs(d)) }));
      if (go) go.disabled = !(t && parts.length && d === 0) || !!A.readonly;
    };
    // A part over what its household owes is said beside it (it would leave a refund to give back).
    const overOf = p => { const c = p.a.cents(), w = owed(p.x); return c > w ? c - w : 0; };
    const sayOver = p => { const v = overOf(p); p.over.textContent = v ? 'Over by ' + money(v) : ''; };
    const draw = () => {
      A.clear(list);
      parts.forEach((p, i) => list.appendChild(h('li', null,
        h('span', null, h('span', { class: 'rx-name', text: p.x.label }), h('span', { class: 'rx-sub', text: p.x.rid + ' · ' + p.x.money_w + (owed(p.x) ? ' ' + money(owed(p.x)) : '') }), p.over),
        p.a,
        A.btn('Remove ' + p.x.label, { ghost: true, iconOnly: true, icon: 'x', onClick: () => { parts.splice(i, 1); draw(); sum(); } }))));
      parts.forEach(sayOver);
    };
    const add = x => {
      if (!x || parts.some(p => p.x.id === x.id)) return;
      const a = R.amount(owed(x), 'Amount for ' + x.label);
      const part = { x, a, over: h('span', { class: 'rx-over', role: 'status' }) };
      a.input.addEventListener('input', () => { sayOver(part); sum(); });
      parts.push(part);
      // One household and no amount typed yet: the check is what it owed.
      if (!total.cents() && parts.length === 1 && owed(x)) total.input.value = (owed(x) / 100).toFixed(owed(x) % 100 ? 2 : 0);
      draw(); sum();
    };
    const suggest = () => {
      A.clear(pick);
      const q = find.value.trim();
      if (!q) return;
      hh.filter(x => !parts.some(p => p.x.id === x.id) && R.matches(q, x.label, x.rid)).slice(0, 8).forEach(x => pick.appendChild(h('li', null,
        h('button', { type: 'button', on: { click: () => { add(x); find.value = ''; A.clear(pick); find.focus(); } } }, h('span', { text: x.label + ' · ' + x.rid }), h('small', { text: x.money_w + (owed(x) ? ' ' + money(owed(x)) : '') })))));
    };
    find.addEventListener('input', suggest);
    find.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); const b = pick.querySelector('button'); if (b) b.click(); } });
    total.input.addEventListener('input', sum);
    (preset || []).forEach(add);
    go = form(sp, {
      title: 'Record check', act: 'Save', path: 'ledger/check', again: o.again, keep: o.keep, back: o.back, onClose: o.onClose,
      fields: [
        h('div', { class: 'rx-grid2' }, K.field('Check number', ref), K.field('Amount', total)),
        K.field('Paid by', by, { help: 'The name on the check, when it isn’t the household’s' }),
        dayField('Received', v => { day = v; }),
        h('div', { class: 'ap-field' }, h('span', { text: 'Households' }), list, find, pick),
        left,
        h('p', { class: 'ap-help', text: 'A part less than a household’s check to come leaves the rest to come' }),
        receiptLine()
      ],
      body: () => ({ ref: ref.value.trim(), cents: total.cents(), paid_by: by.value.trim(), day, parts: parts.map(p => ({ record: p.x.id, cents: p.a.cents() })) })
    });
    sum();
  };

  // Money taken with no line waiting for it: a check that came unannounced, cash or a card at the desk.
  M.record = function (sp, x, o) {
    o = o || {};
    let how = 'check';
    const amt = R.amount(x.balance || 0, 'Amount');
    const ref = R.text({ placeholder: 'Number', 'aria-label': 'Check number', inputmode: 'numeric', style: { maxWidth: '180px' } });
    const refF = K.field('Check number', ref);
    let day = '';
    form(sp, {
      title: 'Record payment', act: 'Save', path: 'ledger/add', again: o.again, keep: o.keep, back: o.back, onClose: o.onClose,
      fields: [
        h('p', { class: 'rx-panel__line' }, h('b', { text: x.label }), ' · ' + x.rid + (x.balance ? ' · Owes ' + money(x.balance) : '')),
        K.field('How', K.pills([['check', 'Check'], ['cash', 'Cash'], ['card', 'Card at the desk']], how, v => { how = v; refF.hidden = v !== 'check'; }), { tag: 'div' }),
        K.field('Amount', amt), refF, dayField('Received', v => { day = v; }), receiptLine()
      ],
      body: () => amt.cents() ? { record: x.id, how, cents: amt.cents(), ref: how === 'check' ? ref.value.trim() : '', day } : 'Enter an amount'
    });
  };

  // A refund of what was paid over the total: the amount and a few words; approved later.
  M.askRefund = function (sp, x, o) {
    o = o || {};
    const amt = R.amount(x.refund || 0, 'Amount');
    const note = R.text({ placeholder: 'Check was $20 over', 'aria-label': 'Note', maxlength: '120' });
    form(sp, {
      title: 'Ask refund', act: 'Ask', path: 'ledger/refund/ask', again: o.again, keep: o.keep, back: o.back, onClose: o.onClose,
      fields: [
        h('p', { class: 'rx-panel__line' }, h('b', { text: x.label }), ' · ' + x.rid + ' · Paid ' + money(x.refund || 0) + ' over'),
        K.field('Amount', amt), K.field('Note', note, { help: 'A few words · Kept on the line' })
      ],
      body: () => amt.cents() ? { record: x.id, cents: amt.cents(), note: note.value.trim() } : 'Enter an amount'
    });
  };

  // A refund line: Approve, or Sent (with the payment company's or the check's number), or Decline.
  M.refund = function (sp, l, o) {
    o = o || {};
    const card = l.method === 'card';
    const ref = R.text({ placeholder: card ? 'Refund number' : 'Check number', 'aria-label': 'Reference', style: { maxWidth: '220px' } });
    let day = '';
    const act = (action, extra) => A.api('POST', 'ledger/refund', Object.assign({ lines: [l.id], action }, extra || {})).then(res => { sp.close(true); M.done(res, o.again, o.keep); }, A.fail);
    const facts = h('dl', { class: 'ap-facts' },
      h('dt', { text: 'Household' }), h('dd', null, l.label, ' · ', l.rid),
      h('dt', { text: 'Amount' }), h('dd', { text: money(l.cents) }),
      h('dt', { text: 'Status' }), h('dd', { text: l.status_w }),
      h('dt', { text: 'Asked' }), h('dd', { text: K.md(l.created) }),
      l.note ? [h('dt', { text: 'Note' }), h('dd', { text: l.note })] : null,
      h('dt', { text: 'To' }), h('dd', { text: card ? 'The card it was paid with' : 'A check by mail' }));
    const foot = [];
    if (l.status === 'requested') foot.push(A.btn('Approve', { primary: true, write: true, onClick: () => act('approve') }));
    if (l.status === 'requested' || l.status === 'approved') {
      foot.push(A.btn('Sent', { primary: l.status === 'approved', write: true, title: card ? 'Refunded in the payment company’s dashboard' : 'The refund check is in the mail', onClick: () => act('send', { ref: ref.value.trim(), day }) }));
      foot.push(A.btn('Decline', { ghost: true, write: true, onClick: () => act('decline') }));
    }
    sp.open({
      title: 'Refund · ' + l.label, onClose: o.onClose, nav: o.nav, tags: [A.tag(l.status_w, l.status === 'approved' ? 'tan' : '')],
      body: h('div', null, facts,
        l.status === 'requested' || l.status === 'approved' ? [K.field(card ? 'Refund number' : 'Check number', ref, { help: card ? 'From the payment company, once refunded there' : 'The refund check’s number' }), dayField('Sent', v => { day = v; })] : null,
        o.linked || (o.open ? h('p', { class: 'rx-quiet-line' }, K.link('Open household', o.open)) : null)),
      foot
    });
  };

  /* ================================================================ the screen */

  A.screen({
    id: 'money', title: 'Money', icon: 'money', section: 'own', who: ['coa'],
    render(ctx) {
      let alive = true;
      const st = { ticks: new Set(), find: '', sort: null, view: ctx.params.v || '' };
      ctx.head('Money', '', []);
      K.loading(ctx.body);
      let sp = null;
      // One household's lines (f=rid:<R>, from its Linked "Payments"): applied by the server, inside what
      // this viewer sees.
      const q = () => { const f = A.params().f; return f ? '?f=' + encodeURIComponent(f) : ''; };
      const load = () => A.api('GET', 'ledger' + q()).then(d => { if (alive) page(ctx, d, st, () => sp, s => { sp = s; }, load); }, err => { if (alive) K.failed(ctx.body, err); });
      load();
      return () => { alive = false; };
    }
  });

  // Which lines each view holds is the server's (each line's `in`, ogc_ledger_in), and so are the counts
  // (line_views): the same function Home's lines count with ("3 refunds", "11 checks late").
  const has = id => x => (x.in || []).includes(id);
  const VIEWS = [
    { id: 'checks', label: 'Checks to come', f: has('checks') },
    { id: 'late', label: 'Late checks', f: has('late') },
    { id: 'owed', label: 'Owed', hh: true, f: has('owes') },
    { id: 'refunds', label: 'Refunds', f: has('refunds') },
    { id: 'received', label: 'Received', f: has('received') },
    { id: 'deposits', label: 'Deposits', dep: true },
    { id: 'all', label: 'Everything', f: () => true }
  ];

  function page(ctx, d, st, getSp, setSp, again) {
    const y = ctx.params.year, t = d.totals, ro = !!A.readonly;
    // The address as it is now (an act's reload clears ?id=).
    const p = Object.assign(ctx.params, { id: A.params().id, v: A.params().v });
    A.clear(ctx.body);
    const sp = ctx.split();
    setSp(sp);
    const main = sp.main;
    if (d.wait != null) M.wait = d.wait;
    const owedSum = ['due', 'balance', 'checkin'].reduce((n, k) => n + t.by[k].cents, 0);
    const formDue = (t.by.form_due || {}).n || 0;
    const owedN = ['due', 'balance', 'checkin'].reduce((n, k) => n + t.by[k].n, 0) + formDue;
    const received = t.card + t.checks_in + t.desk - t.refunded;

    /* -------- the head */
    const acts = [];
    if (d.handler) {
      acts.push(A.btn('Export', { ghost: true, icon: 'file', title: 'Every payment line · The same columns every year', onClick: () => R.download('app/' + y + '/ledger?format=csv', 'Payments ' + y + '.csv', 'Exported · Payments') }));
      if (!ro) acts.push(A.btn('Record check', { primary: true, write: true, title: 'One check, one or several households', onClick: () => { A.setParams({ id: 'check' }); M.check(sp, d.households, [], { again, onClose: () => A.setParams({ id: '' }) }); } }));
    }
    const fact = d.check_by ? (d.closed ? 'Checks were due ' : 'Checks by ') + K.md(d.check_by) : '';
    ctx.head('Money', fact, acts);

    /* -------- the totals (no names: everyone on the COA) */
    // A card's line breaks only between its parts ("27 households · 19 on the Form"), never inside one.
    const keep = t => String(t).split(' · ').map(x => x.replace(/ /g, '\u00a0').replace(/−\$/g, '−\u2060$')).join(' · ');
    const cell = (b, label, sub, title) => h('div', { title: title || null }, h('span', { class: 'rx-sum__l', text: label }), h('b', { text: b }), sub ? h('span', { text: keep(sub) }) : null);
    // The headline is money in less refunds sent, and its line adds up to it (refunds as their own part).
    const ways = [t.card && 'Card ' + money(t.card), t.checks_in && 'Checks ' + money(t.checks_in), t.desk && 'Desk ' + money(t.desk), t.refunded && 'Refunded −' + money(t.refunded)].filter(Boolean);
    // The COA's tiles (H6): each counts households with Households' own views (the server's one count,
    // ogc_rec_views) and opens that view, so the number on the tile is the number on the list it opens.
    const V = d.views || {};
    const vn = k => (V[k] || {}).n || 0, vc = k => (V[k] || {}).cents || 0;
    const can = A.allowed('households');
    const door = (b, label, sub, to, n, title) => {
      const kids = [h('span', { class: 'rx-sum__l', text: label }), h('b', { text: b }), sub ? h('span', { text: keep(sub) }) : null];
      if (!to || !can) return h('div', { title: title || null }, kids);
      const a = A.link(to, kids, 'rx-sum__go');
      a.dataset.n = String(n);
      if (title) a.title = title;
      return a;
    };
    if (!d.handler && (t.households || t.paid)) {
      const fd = vn('money:form_due'), ci = vn('money:checkin'), un = vn('flag:unasked');
      main.appendChild(h('div', { class: 'rx-sum' },
        door(money(received), 'Received', ways.concat(vn('paid') ? [K.plural(vn('paid'), 'household') + ' paid'] : []).join(' · '), vn('paid') ? { s: 'households', v: 'paid' } : null, vn('paid'), 'The households paid in full · Households › Paid'),
        // Past the check date a check that hasn't come is owed at check-in: its households are in Owed
        // too, and the Late checks tile opens them by their flag.
        !d.closed && vn('checks') ? door(money(vc('checks')), 'Checks to come', K.plural(vn('checks'), 'household'), { s: 'households', v: 'checks' }, vn('checks')) : null,
        d.closed && vn('flag:late') ? door(money(vc('flag:late')), 'Late checks', K.plural(vn('flag:late'), 'household') + ' · In Owed', { s: 'households', f: 'flag:late' }, vn('flag:late'), 'Not received by ' + K.md(d.check_by) + ' · Now due at check-in') : null,
        vn('owes') ? door(money(vc('owes')), 'Owed', [K.plural(vn('owes'), 'household'), fd ? fd + ' on the Form' : '', ci ? ci + ' at check-in' : ''].filter(Boolean).join(' · '), { s: 'households', v: 'owes' }, vn('owes'), fd ? 'The Form’s unpaid households are counted here · Their amounts are on the Form' : null) : null,
        t.form ? door(String(t.form), 'On the Form', fd ? fd + ' unpaid' : 'Payments kept there', fd ? { s: 'households', f: 'money:form_due' } : null, fd, 'Households imported from the Google Form · Their payments stay there') : null,
        vn('refunds') ? door(money(vc('refunds')), 'Refunds', K.plural(vn('refunds'), 'household') + (un ? ' · ' + un + ' not asked yet' : ''), { s: 'households', v: 'refunds' }, vn('refunds')) : null));
    } else if (t.households || t.paid) {
      main.appendChild(h('div', { class: 'rx-sum' },
        cell(money(received), 'Received', ways.join(' · ') || K.plural(t.by.paid.n, 'household') + ' paid', ways.length ? ways.join(' · ') : null),
        // Past the check date a check that hasn't come is owed at check-in: counted in Owed, so its money
        // isn't in two cards (here only how many).
        t.checks_n && !d.closed ? cell(money(t.checks), 'Checks to come', K.plural(t.checks_n, 'check')) : null,
        t.checks_n && d.closed ? cell(String(t.checks_n), 'Late checks', 'In Owed · Due at check-in', 'Not received by ' + K.md(d.check_by) + ' · Counted in Owed') : null,
        owedN ? cell(money(owedSum), 'Owed', K.plural(owedN, 'household') + (formDue ? ' · ' + formDue + ' on the Form' : '') + (t.by.checkin.n ? ' · ' + t.by.checkin.n + ' at check-in' : ''), formDue ? 'The Form’s unpaid households are counted here · Their amounts are on the Form' : null) : null,
        t.form ? cell(String(t.form), 'On the Form', formDue ? formDue + ' unpaid' : 'Payments kept there', 'Households imported from the Google Form · Their payments stay there') : null,
        t.refunds_n ? cell(money(t.refunds), 'Refunds to send', K.plural(t.refunds_n, 'refund')) : null));
    }

    /* -------- who handles money */
    const toMembers = () => A.go({ s: 'members', id: '', v: '', c: '' });
    const who = h('div', { class: 'rx-who' },
      h('span', { class: 'rx-who__i', title: 'Only they see each household’s payments · The COA ticks it on Members' },
        h('span', { class: 'ap-label', text: 'Handles money' }),
        d.handlers.length ? h('span', { text: d.handlers.join(' · ') }) : h('span', { class: 'ap-quiet', text: 'No one yet' }),
        d.can_tick && A.allowed('members') ? K.link('Change on Members', toMembers) : null),
      t.gifts_n ? h('span', { class: 'rx-who__i' }, h('span', { class: 'ap-label', text: 'Gifts' }), h('span', { text: money(t.gifts) + ' · ' + K.plural(t.gifts_n, 'household') + (d.gift_for ? ' · For ' + d.gift_for : '') })) : null);

    if (!d.handler) {
      if (!d.handlers.length && d.can_tick) {
        main.insertBefore(h('div', { class: 'rx-hero' }, h('h2', { text: 'No one handles money' }), h('p', { text: 'Tick Handles money on Members for the treasurer' }), A.btn('Open Members', { primary: true, onClick: toMembers })), main.firstChild);
      } else {
        main.appendChild(who);
      }
      if (!t.households) { main.appendChild(h('div', { class: 'cx-page' }, A.empty({ title: 'No registrations yet', line: 'Totals show here as households register' }))); return; }
      // Where every household stands, by its Money word: counts and sums, no names, from the same views
      // as Households. Every row opens Households filtered to that word (Paid, Refunded and Nothing due
      // included): the row is the link, and the number on it is the number of rows it opens.
      const WORDS = { due: 'Payment due', balance: 'Balance due', checkin: 'Due at check-in', form_due: 'Unpaid on the Form', check: 'Check to come', refund: 'Refund due', paid: 'Paid', form_paid: 'Paid on the Form', refunded: 'Refunded', form: 'On the Form', none: 'Nothing due' };
      const rowsM = Object.keys(WORDS).filter(k => vn('money:' + k)).map(k => ({ k, n: vn('money:' + k), cents: vc('money:' + k) }));
      const toOf = x => ({ s: 'households', f: 'money:' + x.k });
      main.appendChild(h('section', { class: 'rx-sec rx-sec--page', 'aria-label': 'Households by money' }, h('h3', { text: 'Households by money' }),
        R.table({
          label: 'Households by money', rows: rowsM, key: x => x.k,
          cols: [
            { id: 'w', label: 'Money', render: x => can ? (() => { const a = A.link(toOf(x), R.money(x.k, WORDS[x.k]), 'rx-rowlink'); a.dataset.n = String(x.n); return a; })() : R.money(x.k, WORDS[x.k]) },
            { id: 'n', label: 'Households', num: true, render: x => String(x.n) },
            { id: 'c', label: 'Amount', num: true, render: x => x.cents ? money(x.cents) : '' }
          ],
          onOpen: x => { if (can) A.go(toOf(x)); }
        }),
        h('p', { class: 'rx-quiet-line', title: 'Only whoever the COA ticks Handles money on Members' }, 'Each payment · ', h('span', { class: 'ap-quiet', text: 'Withheld' }), ' · Handles money')));
      return;
    }
    if (!d.lines.length && !t.households) {
      main.appendChild(h('div', { class: 'cx-page' }, A.empty({ title: 'No registrations yet', line: 'Payments show here as households register' })));
      return;
    }

    /* -------- the treasurer's lists */
    const lines = d.lines;
    const hh = d.households;
    const byRid = {};
    hh.forEach(x => { byRid[x.rid] = x; });
    const deps = {};
    d.deposits.forEach(x => { deps[x.id] = x; });
    // Each chip's count is the server's (line_views: one count, one place).
    const LV = d.line_views || {};
    const countOf = v => LV[v.id] && LV[v.id].n != null ? LV[v.id].n : v.dep ? d.deposits.length : v.hh ? hh.filter(v.f).length : lines.filter(v.f).length;
    const views = VIEWS.map(v => Object.assign({ n: countOf(v) }, v)).filter(v => v.n || v.id === 'all');
    // A line asked for by the address that this view doesn't hold: the first view that does (area-shell 1.3).
    const lineOf = id => /^L\d+$/.test(id) ? lines.find(x => x.id === +id.slice(1)) : null;
    if (p.id && lineOf(String(p.id))) {
      const got = A.pickView({ views: views.map(v => v.id), current: st.view, id: String(p.id), has: (vid, id) => { const v = VIEWS.find(z => z.id === vid), l = lineOf(id); return !!(v && l && !v.dep && !v.hh && v.f(l)); } });
      if (got !== st.view) { st.view = got; st.sort = null; A.setParams({ v: got }); }
    }
    let view = views.find(v => v.id === st.view) || views.find(v => ['checks', 'refunds', 'owed'].includes(v.id)) || views[views.length - 1];
    st.view = view.id;
    // Each list's own first order: the longest waiting first, the oldest refund first, the newest money in.
    if (!st.sort) st.sort = { checks: { id: 'waiting', dir: -1 }, late: { id: 'waiting', dir: -1 }, refunds: { id: 'created', dir: 1 }, owed: { id: 'owes', dir: -1 }, received: { id: 'day', dir: -1 }, deposits: { id: 'day', dir: -1 }, all: { id: 'day', dir: -1 } }[view.id] || null;

    const bar = h('div', { class: 'rx-bar' });
    const bulkSlot = h('div');
    const listSlot = h('div');
    main.append(bar, bulkSlot, listSlot);
    // The panel opened by the address (?id=L12 a line, R-2027-… a household, D3 a deposit, check).
    const openFromAddress = () => {
      const id = String(p.id || '');
      if (id === 'check') return M.check(sp, hh, [], { again, onClose: closeId });
      if (/^L\d+$/.test(id)) { const l = lines.find(x => x.id === +id.slice(1)); if (l) return openLine(l); }
      if (/^D\d+$/.test(id)) { const x = deps[+id.slice(1)]; if (x) return openDeposit(x); }
      if (/^R-\d{4}-\d+$/.test(id) && window.OGC_HH) return openHousehold(id);
      sp.close(true);
    };
    const closeId = () => { p.id = ''; A.setParams({ id: '' }); drawList(); };

    const drawBar = () => {
      A.clear(bar);
      bar.appendChild(h('div', { class: 'rx-bar__row rx-bar__views' },
        A.views(views.map(v => ({ id: v.id, label: v.label, n: v.n })), view.id, id => { st.view = id; st.ticks.clear(); st.sort = null; A.setParams({ v: id, id: '' }); p.id = ''; sp.close(true); page(ctx, d, st, getSp, setSp, again); })));
      if (view.id !== 'deposits') bar.appendChild(h('div', { class: 'rx-bar__row' }, R.find(st.find, v => { st.find = v; drawList(); }, 'Surname or R-number'), h('span', { class: 'rx-count', role: 'status' })));
      // One household's lines (its Linked "Payments"): "Household · Hoovers ×".
      const pills = A.pills(d.filters);
      if (pills) bar.appendChild(h('div', { class: 'rx-bar__row' }, pills));
    };

    const sortBy = (rows, cols) => {
      const s = st.sort;
      const c = s && cols.find(x => x.id === s.id);
      if (!c || !c.sort) return rows;
      return rows.slice().sort((a, b) => { const x = c.sort(a), z = c.sort(b); return (x < z ? -1 : x > z ? 1 : 0) * s.dir; });
    };
    const onSort = id => { st.sort = st.sort && st.sort.id === id ? { id, dir: -st.sort.dir } : { id, dir: 1 }; drawList(); };
    const hhName = x => h('span', null, h('span', { class: 'rx-name', text: x.label }), h('span', { class: 'rx-sub', text: x.rid }));
    // A check's number ("No. 1042"), a card's payment company reference ("Ref. pi_…"), the name on a check.
    const refOf = l => [l.ref && l.ref !== 'sample' ? (l.kind === 'charge' ? 'Ref. ' : 'No. ') + l.ref : '', l.paid_by].filter(Boolean).join(' · ');

    function colsFor() {
      const amount = { id: 'amount', label: 'Amount', num: true, sort: l => l.cents, render: l => (l.kind === 'refund' ? '−' : '') + money(l.cents) };
      const name = { id: 'name', label: 'Household', sort: l => l.label.toLowerCase(), render: l => hhName(l) };
      const dayC = { id: 'day', label: 'Date', cls: 'ap-td--nowrap ap-td--muted', sort: l => l.day, render: l => K.md(l.day) };
      if (view.id === 'checks' || view.id === 'late') return [name, amount,
        { id: 'created', label: 'Registered', cls: 'ap-td--nowrap ap-td--muted', wide: true, side: true, sort: l => l.created, render: l => K.md(l.created) },
        { id: 'waiting', label: 'Waiting', cls: 'ap-td--nowrap', wide: true, sort: l => l.waiting, render: l => l.late ? A.tag('Late · Due at check-in', 'late') : h('span', { class: 'ap-muted', text: l.waiting ? K.plural(l.waiting, 'day') : 'Today' }) },
        { id: 'act', label: '', cls: 'ap-td--nowrap', render: l => ro ? '' : A.btn('Mark received', { write: true, onClick: () => openLine(l) }) }];
      if (view.id === 'owed') return [
        { id: 'name', label: 'Household', sort: x => x.label.toLowerCase(), render: x => hhName(x) },
        { id: 'money', label: 'Money', cls: 'ap-td--nowrap', sort: x => x.money_w, render: x => R.money(x.money, x.money_w) },
        { id: 'owes', label: 'Owes', num: true, sort: x => x.balance, render: x => x.form ? h('span', { class: 'ap-quiet', text: 'On the Form', title: 'Unpaid on the Google Form · Its amount is there' }) : h('span', { class: 'rx-owe', text: money(x.balance) }) },
        { id: 'paid', label: 'Paid', num: true, wide: true, side: true, sort: x => x.paid, render: x => x.paid ? money(x.paid) : '' },
        { id: 'phone', label: 'Phone', cls: 'ap-td--nowrap ap-td--muted', wide: true, render: x => x.phone || '' }];
      if (view.id === 'refunds') return [name, amount,
        { id: 'status', label: 'Status', cls: 'ap-td--nowrap', sort: l => l.status, render: l => A.tag(l.status_w, l.status === 'approved' ? 'tan' : '') },
        { id: 'created', label: 'Asked', cls: 'ap-td--nowrap ap-td--muted', wide: true, sort: l => l.created, render: l => K.md(l.created) },
        { id: 'note', label: 'Note', cls: 'ap-td--muted', wide: true, side: true, render: l => l.note || '' }];
      if (view.id === 'received') return [dayC, name,
        { id: 'kind', label: 'Kind', cls: 'ap-td--nowrap', wide: true, sort: l => l.kind_w, render: l => l.status === 'paid' ? l.kind_w : h('span', null, l.kind_w + ' · ', A.tag(l.status_w, 'late')) },
        amount,
        { id: 'ref', label: 'Number', cls: 'ap-td--muted', wide: true, side: true, render: refOf },
        { id: 'dep', label: 'Deposit', cls: 'ap-td--nowrap', wide: true, sort: l => l.deposit ? (deps[l.deposit] || {}).day || '' : '', render: l => l.deposit && deps[l.deposit] ? K.md(deps[l.deposit].day) : l.kind === 'charge' ? '' : h('span', { class: 'ap-quiet', text: 'Not deposited' }) }];
      if (view.id === 'deposits') return [
        { id: 'day', label: 'Date', cls: 'ap-td--nowrap', sort: x => x.day, render: x => K.md(x.day) },
        { id: 'kind', label: 'Kind', sort: x => x.kind_w, render: x => x.kind_w },
        { id: 'n', label: 'Items', num: true, wide: true, render: x => h('span', { title: x.lines !== x.n ? K.plural(x.lines, 'household line') : null, text: K.plural(x.n, x.kind === 'checks' ? 'check' : 'payment') }) },
        { id: 'total', label: 'Total', num: true, sort: x => x.total, render: x => money(x.total) },
        { id: 'bank', label: 'Bank', num: true, wide: true, render: x => x.bank == null ? h('span', { class: 'ap-quiet', text: 'Not typed' }) : money(x.bank) },
        { id: 'off', label: '', cls: 'ap-td--nowrap', render: x => x.bank != null && x.off ? A.tag('Off by ' + (x.off < 0 ? '−' : '') + money(Math.abs(x.off)), 'late') : x.bank != null ? A.tag('Matches', 'ok') : '' }];
      return [dayC, name,
        { id: 'kind', label: 'Kind', cls: 'ap-td--nowrap', wide: true, sort: l => l.kind_w, render: l => l.kind_w },
        { id: 'status', label: 'Status', cls: 'ap-td--nowrap', sort: l => l.status_w, render: l => l.status_w },
        amount,
        { id: 'ref', label: 'Number', cls: 'ap-td--muted', wide: true, side: true, render: refOf }];
    }

    function rowsFor() {
      if (view.dep) return d.deposits.slice();
      if (view.hh) return hh.filter(view.f).filter(x => R.matches(st.find, x.label, x.rid));
      return lines.filter(view.f).filter(l => R.matches(st.find, l.label, l.rid, l.ref, l.paid_by));
    }
    const tickable = () => !ro && ['checks', 'late', 'refunds', 'received'].includes(view.id);
    // A row's key, the same in the address (?id=), the selection and the ticks.
    const keyOf = x => view.hh ? x.rid : view.dep ? 'D' + x.id : 'L' + x.id;

    // Ticks stay through a search (working through a pile of envelopes by surname): the act takes every
    // ticked row of this list, shown or not, and the bar says how many aren't shown.
    function drawBulk(rows) {
      A.clear(bulkSlot);
      const on = (view.dep ? d.deposits : view.hh ? hh.filter(view.f) : lines.filter(view.f)).filter(r => st.ticks.has(keyOf(r)));
      if (!on.length) return;
      const hidden = on.filter(r => !rows.includes(r)).length;
      const actsB = [];
      if (view.id === 'checks' || view.id === 'late') actsB.push(A.btn('Mark received · ' + on.length, { primary: true, write: true, onClick: () => M.receivedMany(sp, on, { again: () => { st.ticks.clear(); again(); } }) }));
      if (view.id === 'refunds') {
        const ask = on.filter(l => l.status === 'requested');
        if (ask.length) actsB.push(A.btn('Approve · ' + ask.length, { primary: true, write: true, onClick: () => A.api('POST', 'ledger/refund', { lines: ask.map(l => l.id), action: 'approve' }).then(res => { st.ticks.clear(); M.done(res, again); }, A.fail) }));
      }
      if (view.id === 'received') {
        const free = on.filter(l => !l.deposit && l.status === 'paid');
        if (free.length) actsB.push(A.btn('New deposit · ' + free.length, { primary: true, write: true, onClick: () => newDeposit(free) }));
      }
      bulkSlot.appendChild(R.bulk(on.length, actsB, () => { st.ticks.clear(); drawList(); }, hidden));
    }

    // Previous · Next through the rows as drawn.
    let drawnRows = [];
    const openRow = x => view.hh ? openHousehold(x.rid) : view.dep ? openDeposit(x) : openLine(x);
    const navFor = key => { const i = drawnRows.findIndex(r => keyOf(r) === key); return i < 0 ? null : { prev: i > 0 ? () => openRow(drawnRows[i - 1]) : null, next: i < drawnRows.length - 1 ? () => openRow(drawnRows[i + 1]) : null }; };
    // A line's household, as a Linked line: its panel here, with the chip back to this line.
    const houseOf = l => A.linked([{ kind: 'household', label: 'Household · ' + l.label, go: { s: 'money', id: l.rid } }], { from: 'money:L' + l.id, name: l.kind_w + ' · ' + l.label.split(',')[0] });
    function drawList() {
      const cols = colsFor();
      const rows = sortBy(rowsFor(), cols);
      drawnRows = rows;
      const cnt = bar.querySelector('.rx-count');
      if (cnt) cnt.textContent = st.find && rows.length ? K.plural(rows.length, 'match', 'matches') : '';
      A.clear(listSlot).appendChild(R.table({
        label: view.label, rows, key: keyOf, name: x => x.label || x.kind_w, cols,
        sort: st.sort, onSort, ticks: tickable() ? st.ticks : null, onTick: () => drawBulk(rows),
        selected: String(p.id || ''),
        onOpen: x => view.hh ? openHousehold(x.rid) : view.dep ? openDeposit(x) : openLine(x),
        empty: A.empty({ title: st.find ? 'No matches' : view.id === 'checks' ? 'No checks to come' : view.id === 'refunds' ? 'No refunds to send' : 'None', inset: true })
      }));
      drawBulk(rows);
      main.appendChild(who);
    }

    /* -------- a record opened beside the list */
    function openLine(l) {
      p.id = 'L' + l.id;
      A.setParams({ id: p.id });
      const back = () => openLine(l);
      const nav = navFor('L' + l.id);
      if (l.kind === 'refund') return M.refund(sp, l, { again, onClose: closeId, nav, linked: houseOf(l) });
      if (l.kind === 'check' && l.status === 'pending') {
        return M.received(sp, l, { again, back: closeId, onClose: closeId, nav, tags: [A.tag(l.late ? 'Late' : l.status_w, l.late ? 'late' : '')], linked: houseOf(l), several: () => M.check(sp, hh, byRid[l.rid] ? [byRid[l.rid]] : [], { again, back, onClose: closeId }) });
      }
      const ref = R.text({ value: l.ref, placeholder: 'Number', 'aria-label': 'Number', style: { maxWidth: '200px' }, disabled: ro });
      ref.addEventListener('change', () => A.api('POST', 'ledger/edit', { line: l.id, ref: ref.value.trim() }).then(() => { l.ref = ref.value.trim(); A.toast('Saved · Number'); }, A.fail));
      const grp = l.grp ? lines.filter(x => x.grp === l.grp && x.id !== l.id) : [];
      const foot = [];
      if (l.status === 'paid' && (l.kind === 'check' || (l.kind === 'desk' && l.method === 'check'))) foot.push(A.btn('Returned', { write: true, title: 'The bank returned it · It stops counting as paid', onClick: () => markLine(l, 'returned') }));
      if (l.status === 'paid' && l.kind === 'charge') foot.push(A.btn('Disputed', { write: true, title: 'The cardholder disputed it · It stops counting as paid', onClick: () => markLine(l, 'disputed') }));
      sp.open({
        title: l.kind_w + ' · ' + l.label, onClose: closeId, nav, tags: [A.tag(l.status_w, l.status === 'paid' ? '' : 'late')],
        body: h('div', null,
          h('dl', { class: 'ap-facts' },
            h('dt', { text: 'Household' }), h('dd', null, l.label, ' · ', l.rid),
            h('dt', { text: 'Amount' }), h('dd', { text: money(l.cents) + (l.fee ? ' · Fee ' + money(l.fee) : '') }),
            h('dt', { text: 'Status' }), h('dd', { text: l.status_w }),
            h('dt', { text: 'Date' }), h('dd', { text: K.md(l.day) }),
            l.paid_by ? [h('dt', { text: 'Paid by' }), h('dd', { text: l.paid_by })] : null,
            grp.length ? [h('dt', { text: 'Same check' }), h('dd', { text: grp.map(x => x.label + ' ' + money(x.cents)).join(' · ') })] : null,
            l.deposit && deps[l.deposit] ? [h('dt', { text: 'Deposit' }), h('dd', { text: K.md(deps[l.deposit].day) + ' · ' + deps[l.deposit].kind_w })] : null,
            l.note ? [h('dt', { text: 'Note' }), h('dd', { text: l.note })] : null,
            l.by ? [h('dt', { text: 'By' }), h('dd', { text: l.by })] : null),
          l.kind !== 'charge' ? K.field('Number', ref, { help: l.kind === 'check' ? 'The check’s number' : 'A receipt or check number' }) : null,
          houseOf(l)),
        foot: foot.length ? foot : null
      });
    }
    function markLine(l, action) {
      A.api('POST', 'ledger/mark', { line: l.id, action }).then(res => { sp.close(true); p.id = ''; A.setParams({ id: '' }); M.done(res, again); }, A.fail);
    }
    function openHousehold(rid) {
      p.id = rid;
      A.setParams({ id: rid });
      if (window.OGC_HH) window.OGC_HH.open(sp, rid, { again, onClose: closeId, households: hh, host: 'money', nav: view.hh ? navFor(rid) : null, head: byRid[rid] });
    }
    function openDeposit(x) {
      p.id = 'D' + x.id;
      A.setParams({ id: p.id });
      const bank = R.amount(x.bank == null ? 0 : x.bank, 'Bank amount');
      bank.input.disabled = ro;
      const off = h('p', { class: 'rx-quiet-line', role: 'status' });
      const sayOff = () => { off.textContent = x.bank == null ? '' : x.off ? 'Off by ' + (x.off < 0 ? '−' : '') + money(Math.abs(x.off)) : 'Matches'; };
      sayOff();
      bank.input.addEventListener('change', () => {
        const c = bank.input.value.trim() === '' ? '' : bank.cents();
        A.api('PATCH', 'ledger/deposits/' + x.id, { bank: c === '' ? '' : String(c) }).then(r => { if (r.deposit) Object.assign(x, r.deposit); sayOff(); A.toast('Saved · Bank amount'); }, A.fail);
      });
      const its = lines.filter(l => l.deposit === x.id);
      sp.open({
        title: 'Deposit · ' + K.md(x.day), onClose: closeId, nav: navFor('D' + x.id),
        body: h('div', null,
          h('dl', { class: 'ap-facts' },
            h('dt', { text: 'Kind' }), h('dd', { text: x.kind_w }),
            h('dt', { text: 'Total' }), h('dd', { text: money(x.total) + ' · ' + K.plural(x.n, x.kind === 'checks' ? 'check' : 'payment') }),
            x.by ? [h('dt', { text: 'By' }), h('dd', { text: x.by })] : null),
          K.field('Bank amount', bank, { help: 'From the bank statement' }), off,
          itemList(its, 'In this deposit')),
        foot: [A.btn('Remove deposit', { ghost: true, write: true, title: 'Its lines are free to deposit again', onClick: () => A.api('DELETE', 'ledger/deposits/' + x.id).then(res => { sp.close(true); p.id = ''; A.setParams({ id: '' }); M.done(res, again); }, A.fail) })]
      });
    }
    /*
     * Money in as the bank sees it: one check that paid for several households is one item ("Pine Grove
     * district · No. 2290 · $1,326.50"), its households under it; every other line is its own item.
     */
    function itemsOf(ls) {
      const out = [], by = {};
      ls.forEach(l => {
        if (!l.grp) { out.push({ lines: [l], cents: l.cents }); return; }
        if (!by[l.grp]) { by[l.grp] = { lines: [], cents: 0 }; out.push(by[l.grp]); }
        by[l.grp].lines.push(l);
        by[l.grp].cents += l.cents;
      });
      return out;
    }
    function itemList(ls, label) {
      return h('ul', { class: 'rx-lines', 'aria-label': label }, itemsOf(ls).map(it => {
        const l = it.lines[0];
        const many = it.lines.length > 1;
        return h('li', null, h('span', { class: 'rx-lines__d', text: K.md(l.day) }),
          h('span', { class: 'rx-lines__w' }, many ? (l.paid_by || 'Check') + (l.ref ? ' · No. ' + l.ref : '') : l.label,
            h('small', { text: many ? it.lines.map(z => z.label + ' ' + money(z.cents)).join(' · ') : [l.kind_w, refOf(l)].filter(Boolean).join(' · ') })),
          h('span', { class: 'rx-lines__a', text: money(it.cents) }));
      }));
    }
    function newDeposit(free) {
      let day = '';
      const kinds = Array.from(new Set(free.map(l => l.kind === 'charge' ? 'card' : l.kind === 'desk' && l.method === 'cash' ? 'cash' : 'checks')));
      let kind = kinds.length === 1 ? kinds[0] : 'checks';
      const sum = free.reduce((n, l) => n + l.cents, 0);
      const bank = R.amount(0, 'Bank amount');
      const n = itemsOf(free).length;
      form(sp, {
        title: 'New deposit', act: 'Save', path: 'ledger/deposits', again: () => { st.ticks.clear(); again(); },
        fields: [
          h('p', { class: 'rx-panel__line', text: K.plural(n, kind === 'checks' ? 'check' : 'payment') + ' · ' + money(sum) }),
          itemList(free, 'In this deposit'),
          K.field('Kind', K.pills(Object.keys(d.kinds).map(k => [k, d.kinds[k]]), kind, v => { kind = v; }), { tag: 'div' }),
          dayField('Date', v => { day = v; }),
          K.field('Bank amount', bank, { help: 'Optional · From the bank statement, to check it matches' })
        ],
        body: () => ({ lines: free.map(l => l.id), day, kind, bank: bank.cents() ? String(bank.cents()) : '' })
      });
    }

    drawBar();
    drawList();
    openFromAddress();
    M.refocus(bar);
  }
})();
