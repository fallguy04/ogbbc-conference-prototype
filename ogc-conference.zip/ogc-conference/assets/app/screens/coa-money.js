/*
 * coa-money.js — Money, for the treasurer: what's been paid, checks to come, refunds asked, balances.
 *
 * The COA sees totals (GET app/{y}/money: no names). The people the COA names as treasurer (the lists
 * area's payment viewers) also see each household's payment, and mark a check received, a refund sent
 * or declined, or a payment taken at the desk (the lists area's routes: lists/{y}/payments, /pay…),
 * each with Undo. Remind sends a household the check reminder, once a week at most.
 */
(function () {
  'use strict';
  const A = window.OGC_APP, K = window.OGC_COA, W = window.OGC_WP || {};
  if (!A || !K) return;
  const h = A.h;

  A.screen({
    id: 'money', title: 'Money', icon: 'money', section: 'own', who: ['coa'],
    render(ctx) {
      let alive = true;
      ctx.head('Money', '', []);
      K.loading(ctx.body);
      const y = ctx.params.year;
      const draw = () => A.api('GET', 'money').then(m => (m.viewer ? K.api('GET', 'lists/' + y + '/payments').catch(() => null) : Promise.resolve(null)).then(p => ({ m, p })))
        .then(st => { if (alive) page(ctx, st, draw); }, err => { if (alive) K.failed(ctx.body, err); });
      draw();
      return () => { alive = false; };
    }
  });

  function page(ctx, st, again) {
    const y = ctx.params.year, m = st.m, t = m.totals, p = st.p;
    const ro = !!A.readonly;
    const acts = [];
    if (m.viewer && p) acts.push(A.btn('Export', { ghost: true, icon: 'file', title: 'Every payment, for Excel', onClick: exportCsv }));
    // The one decision this screen needs, while it's open: who the treasurer is.
    const noTreasurer = m.choose && !m.treasurers.length && !ro;
    if (noTreasurer) acts.push(A.btn('Choose treasurer', { primary: true, write: true, onClick: () => choose() }));
    // The fact is what isn't on screen (the totals are the tiles below).
    // An empty year says so once, in the card below.
    ctx.head('Money', t.households && m.check_by ? 'Checks by ' + K.md(m.check_by) : '', acts);
    A.clear(ctx.body);
    const sp = ctx.split();
    const doc = h('div', { class: 'cx-page' });
    sp.main.appendChild(doc);
    if (noTreasurer) doc.appendChild(h('div', { class: 'ap-hero' }, h('div', null, h('h2', { class: 'ap-headline', text: 'No treasurer named' }), h('p', { class: 'ap-lede', text: 'The treasurer sees each household’s payment and marks checks received' }))));

    if (!t.households) {
      doc.appendChild(A.empty({ title: 'No registrations yet', line: 'Payments show here as households register' }));
      if (m.choose && !noTreasurer) doc.appendChild(treasurers());
      return;
    }

    // Every household counted once: paid in full, a check to come, not paid (or nothing to pay); then
    // credit asked. Each tile's amount under it; a tile with nothing in it isn't drawn.
    const by = t.by || {};
    const stat = (n, label, sub, title) => h('div', { title: title || null }, h('b', { text: String(n) }), h('span', { text: label }), sub ? h('span', { class: 'ap-quiet', text: sub }) : null);
    const ways = [t.card && 'Card ' + K.money(t.card), t.checks_in && 'Checks ' + K.money(t.checks_in), t.desk && 'Desk ' + K.money(t.desk)].filter(Boolean);
    doc.appendChild(h('div', { class: 'cx-stat' },
      by.full ? stat(by.full, 'Paid in full', K.money(t.paid) + ' paid' + (ways.length > 1 ? ' · ' + ways.join(' · ') : ''), K.plural(t.households, 'household') + ' registered') : null,
      by.check ? stat(by.check, 'Check to come', K.money(t.checks) + (t.checks_late ? ' · ' + t.checks_late + ' late' : ''), m.check_by ? 'Due by ' + K.md(m.check_by) : '') : null,
      by.owes ? stat(by.owes, 'Not paid', K.money(t.due) + ' owed') : null,
      by.none ? stat(by.none, 'Nothing to pay') : null,
      t.credits_n || t.refunds_n ? stat(t.credits_n || t.refunds_n, 'Credit asked', t.refunds ? K.money(t.refunds) : '') : null));
    if (t.gifts_n) doc.appendChild(h('p', { class: 'ap-quiet', text: K.plural(t.gifts_n, 'gift') + ' · ' + K.money(t.gifts) }));

    if (!m.viewer || !p || !p.viewer) {
      // One line: who sees each household's payment (not said twice while the headline asks for one).
      if (!noTreasurer) doc.appendChild(treasurers());
      return;
    }

    /* -------------------------------------------------------- the treasurer's lists */
    const money = c => K.money(c);
    const table = (label, cols, rows, onOpen) => {
      const tb = h('tbody');
      rows.forEach(r => {
        const tr = h('tr', { tabindex: '-1' }, cols.map(c => h('td', { class: c.cls || null }, c.v(r))));
        if (onOpen) tr.addEventListener('click', e => { if (!e.target.closest('button')) onOpen(r); });
        tb.appendChild(tr);
      });
      return h('div', { class: 'ap-tablewrap cx-flushtable' }, h('table', { class: 'ap-table', 'aria-label': label },
        h('thead', null, h('tr', null, cols.map(c => h('th', { scope: 'col', class: c.cls || null, text: c.l })))), tb));
    };
    const who = r => h('span', null, h('span', { class: 'ap-cell-title', text: r.label }), r.rid ? h('span', { class: 'ap-cell-sub', text: r.rid }) : null);

    if (p.checks.length) doc.appendChild(K.section('Checks to come', { n: p.checks.length, help: m.check_by ? 'Due by ' + K.md(m.check_by) + ' · ' + (m.payee ? 'Payable to ' + m.payee : '') : '' },
      table('Checks to come', [
        { l: 'Household', v: who },
        { l: 'Amount', cls: 'ap-td--num', v: r => money(r.cents) },
        { l: 'Waiting', cls: 'ap-td--nowrap ap-td--wide', v: r => h('span', { class: r.late ? 'cx-warn' : '', text: r.waiting ? K.plural(r.waiting, 'day') + (r.late ? ' · Late' : '') : 'Today' }) },
        { l: '', cls: 'ap-td--nowrap', v: r => ro || !p.can.checks ? '' : h('span', { class: 'ap-row' }, A.btn('Received', { write: true, onClick: () => received(r) }), r.email && p.can.remind ? A.btn('Remind', { ghost: true, write: true, onClick: () => remind(r) }) : null) }
      ], p.checks)));

    if (p.refunds.length) doc.appendChild(K.section('Refunds asked', { n: p.refunds.length, help: m.refunds_by ? 'Asked by ' + K.md(m.refunds_by) : '' },
      table('Refunds asked', [
        { l: 'Household', v: who },
        { l: 'Amount', cls: 'ap-td--num', v: r => money(r.cents) },
        { l: 'Asked', cls: 'ap-td--nowrap ap-td--wide', v: r => K.md(r.asked) + (r.late ? ' · After the date' : '') },
        { l: '', cls: 'ap-td--nowrap', v: r => ro || !p.can.refund ? '' : h('span', { class: 'ap-row' }, A.btn('Refunded', { write: true, onClick: () => mark(r, 'refunded', 'Refunded') }), A.btn('Decline', { ghost: true, danger: true, write: true, onClick: () => mark(r, 'declined', 'Declined') })) }
      ], p.refunds)));

    if (p.due.length) doc.appendChild(K.section('Balance due', { n: p.due.length, help: 'At check-in, or by check' },
      table('Balance due', [
        { l: 'Household', v: who },
        { l: 'Owes', cls: 'ap-td--num', v: r => money(r.cents) },
        { l: 'Total', cls: 'ap-td--num ap-td--wide', v: r => money(r.total) },
        { l: '', cls: 'ap-td--nowrap', v: r => ro || !p.can.checks ? '' : A.btn('Paid at desk', { ghost: true, write: true, onClick: () => desk(r) }) }
      ], p.due)));

    if (p.done.length) {
      const det = h('details', { class: 'cx-more' }, h('summary', null, h('span', { text: 'Received' }), h('span', { class: 'ap-quiet', text: String(p.done.length) })));
      det.appendChild(table('Received', [
        { l: 'Day', cls: 'ap-td--nowrap', v: r => K.md(r.day) },
        { l: 'Household', v: who },
        { l: 'What', v: r => r.kind === 'refund' ? (r.status === 'sent' ? 'Refunded' : 'Declined') : r.kind === 'desk' ? 'At the desk · ' + (r.method || '') : 'Check' + (r.ref ? ' · ' + r.ref : '') },
        { l: 'Amount', cls: 'ap-td--num', v: r => (r.kind === 'refund' ? '−' : '') + money(r.cents) },
        { l: 'By', cls: 'ap-td--wide ap-td--muted', v: r => r.by || '' }
      ], p.done));
      doc.appendChild(K.section('History', {}, det));
    }
    if (m.choose) doc.appendChild(treasurers());

    /* -------------------------------------------------------- acts */
    const undoable = (res, after) => { A.toast(res.say || 'Done', res.mark ? { undo: () => K.api('POST', 'lists/' + y + '/pay/undo', { mark: res.mark }).then(r => { A.toast(r.say || 'Undone'); again(); }, A.fail) } : null); after && after(); again(); };
    function received(r) {
      const amt = K.textIn({ value: (r.cents / 100).toFixed(r.cents % 100 ? 2 : 0), label: 'Amount', inputmode: 'decimal', width: '120px', live: false });
      const ref = K.textIn({ label: 'Check number', placeholder: 'Number', width: '160px', live: false });
      let day = '';
      const date = K.dateIn({ value: '', label: 'Received', placeholder: 'Today', onSave: v => { day = v; } });
      K.confirm(sp, {
        title: 'Check received · ' + r.label, lines: ['Expected ' + money(r.cents) + ' · Less is kept as the rest to come'],
        field: h('div', null, K.field('Amount', h('span', { class: 'cx-money' }, h('span', { class: 'cx-money__pre', text: '$' }), amt)), K.field('Check number', ref), K.field('Received', date, { tag: 'div' })),
        actLabel: 'Received',
        act: () => {
          const c = Math.round(parseFloat(String(amt.value).replace(/[$,]/g, '')) * 100);
          if (!(c > 0)) return Promise.reject({ message: 'Enter an amount' });
          return K.api('POST', 'lists/' + y + '/pay', { payment: r.payment, action: 'received', cents: c, ref: ref.value.trim(), date: day });
        },
        onDone: res => undoable(res)
      });
    }
    function mark(r, action) {
      K.api('POST', 'lists/' + y + '/pay', { payment: r.payment, action }).then(res => undoable(res), A.fail);
    }
    function remind(r) {
      K.api('POST', 'lists/' + y + '/pay/remind', { payment: r.payment, preview: 1 }).then(pv => {
        K.confirm(sp, {
          title: 'Remind · ' + r.label,
          lines: ['To ' + pv.to, h('b', { text: pv.subject })],
          field: h('p', { class: 'ap-pre cx-mailbody', text: pv.body }),
          actLabel: 'Send',
          act: () => K.api('POST', 'lists/' + y + '/pay/remind', { payment: r.payment }),
          onDone: res => { A.toast(res.say || 'Reminder sent'); }
        });
      }, A.fail);
    }
    function desk(r) {
      const amt = K.textIn({ value: (r.cents / 100).toFixed(r.cents % 100 ? 2 : 0), label: 'Amount', inputmode: 'decimal', width: '120px', live: false });
      let method = 'cash';
      const ref = K.textIn({ label: 'Check number', placeholder: 'Number', width: '160px', live: false });
      K.confirm(sp, {
        title: 'Paid at the desk · ' + r.label, lines: ['Owes ' + money(r.cents)],
        field: h('div', null, K.field('Amount', h('span', { class: 'cx-money' }, h('span', { class: 'cx-money__pre', text: '$' }), amt)), K.field('How', K.pills([['cash', 'Cash'], ['check', 'Check']], 'cash', v => { method = v; }), { tag: 'div' }), K.field('Check number', ref, { help: 'For a check' })),
        actLabel: 'Paid',
        act: () => {
          const c = Math.round(parseFloat(String(amt.value).replace(/[$,]/g, '')) * 100);
          if (!(c > 0)) return Promise.reject({ message: 'Enter an amount' });
          return K.api('POST', 'lists/' + y + '/pay/add', { record: r.record, cents: c, method, ref: ref.value.trim() });
        },
        onDone: res => undoable(res)
      });
    }
    function exportCsv() {
      fetch((W.rest || '/wp-json/ogc/v1/') + 'lists/' + y + '/payments?format=csv', { credentials: 'same-origin', headers: { 'X-WP-Nonce': W.nonce } })
        .then(r => { if (!r.ok) throw new Error('Not exported'); return r.blob(); })
        .then(b => { const a = h('a', { href: '#', download: 'payments-' + y + '.csv' }); a.href = URL.createObjectURL(b); document.body.appendChild(a); a.click(); a.remove(); A.toast('Exported · Payments'); })
        .catch(() => A.toast('Not exported'));
    }

    /* -------------------------------------------------------- who is treasurer (the COA names them) */
    function treasurers() {
      // "Treasurer · Not named · Choose": one line, its explanation in the tooltip.
      return h('p', { class: 'cx-treasurer', title: 'The treasurer sees each household’s payment · The COA names them' },
        h('span', { class: 'ap-label', text: 'Treasurer' }), ' ',
        m.treasurers.length ? h('span', { class: 'cx-names', text: m.treasurers.join(' · ') }) : h('span', { class: 'ap-quiet', text: 'Not named' }),
        ro || !m.choose ? null : [' · ', K.link(m.treasurers.length ? 'Change' : 'Choose', choose)]);
    }
    function choose() {
      K.api('GET', 'lists/' + y + '/access').then(acc => {
        const on = new Set((acc.lists.payments || []).map(x => x.email));
        const list = h('ul', { class: 'ap-list' }, (acc.members || []).map(mm => h('li', null, h('label', { class: 'ap-item' },
          h('input', { type: 'checkbox', class: 'ap-check', checked: on.has(mm.email), on: { change: e => { if (e.target.checked) on.add(mm.email); else on.delete(mm.email); } } }),
          h('span', { class: 'ap-item__main' }, h('span', { class: 'ap-item__title', text: mm.name || mm.email }), h('span', { class: 'ap-item__why', text: mm.role === 'coa' ? 'COA' : (mm.helps || 'Helper') }))))));
        const go = A.btn('Save', { primary: true, write: true, onClick: () => K.api('PUT', 'lists/' + y + '/access', { list: 'payments', emails: Array.from(on) }).then(() => { sp.close(true); A.toast('Saved · Treasurer'); again(); }, A.fail) });
        sp.open({ title: 'Treasurer', body: h('div', null, h('p', { class: 'ap-help', text: 'Only members of ' + y + ' · Up to 20' }), list), foot: [go, A.btn('Cancel', { ghost: true, onClick: () => sp.close() })] });
      }, A.fail);
    }
  }
})();
