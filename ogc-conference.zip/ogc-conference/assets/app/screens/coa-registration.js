/*
 * coa-registration.js — Registration: when the form opens and closes, the nights, the prices, and what
 * the form asks. Every value saves as typed through coa/{y}/reg, which checks it (prices, counts, dates
 * in order) and logs it; an error shows at its field. Prices carried from last year are one "From 2026 ·
 * Looks right" on the whole block (not public before that, or before Schedule).
 *
 * The title row's one action follows the state: Schedule (choose Opens and Closes) → "Opens Feb 25" →
 * "Open" (Close in its menu) → "Closed" (Reopen). Another tool: the Register button's link, nothing else.
 */
(function () {
  'use strict';
  const A = window.OGC_APP, K = window.OGC_COA, O = window.OGC, W = window.OGC_WP || {};
  if (!A || !K) return;
  const h = A.h;
  const DAYS = ['Friday', 'Saturday', 'Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday'];

  A.screen({
    id: 'registration', title: 'Registration', icon: 'form', section: 'own', who: ['coa'],
    render(ctx) {
      let alive = true;
      ctx.head('Registration', '', []);
      K.loading(ctx.body);
      const draw = force => K.load(ctx.params.year, { force }).then(d => { if (alive) page(ctx, d, () => draw(true)); }, err => { if (alive) K.failed(ctx.body, err); });
      draw(false);
      return () => { alive = false; };
    }
  });

  function page(ctx, d, again) {
    const y = d.year, R = d.R, S = d.S, row = d.row;
    const ro = !!A.readonly || d.held;
    const posted = v => !!v && v !== K.NOT_YET && v <= d.today;
    // A date the pickup moved forward from last year isn't scheduled until someone chooses it (the
    // public reads it as not scheduled: module-public's ogc_pub_reg); it's a suggestion here too.
    const movedOpens = ((d.picked.parts.registration || {}).moved || []).find(x => x.k === 'opens' && R.opens === x.to);
    const pubAct = ((d.coa.pub || {}).registration || {}).act;
    const carried = !!movedOpens && !['schedule', 'close', 'reopen'].includes(pubAct) && !d.coa.checks['reg:dates'];
    const opens = R.opens && R.opens !== K.NOT_YET && !carried ? R.opens : '';
    const closed = posted(S.registration_closed) ? S.registration_closed : (R.closes && d.today > R.closes ? R.closes : '');
    const pub = { scheduled: !!opens, on: posted(opens) && !closed, when: opens, closed };
    const other = S.registration_mode === 'link';
    const n = d.ov && d.ov.counts ? d.ov.counts.registrations : 0;
    const sug = (d.picked.suggest || {}).opens;
    const suggested = carried ? R.opens : sug && sug.to ? sug.to : (row.start ? O.isoAddDays(row.start, -91) : '');
    const sugWords = carried ? K.mdY(R.opens, y) + ' · From ' + (d.picked.from || 'last year') : suggested ? K.mdY(suggested, y) + ' suggested' : '';
    const pricesLeft = d.ov && !d.coa.checks['reg:prices'] && d.picked.from && Array.isArray(d.picked.confirm) && d.picked.confirm.indexOf('reg:prices') > -1;

    /* -------------------------------------------------------- the title row */
    const acts = [K.see('register/?year=' + y, 'Preview')];
    let fact = '';
    if (d.held) fact = 'Ended ' + K.md(row.end);
    else if (other) fact = 'Another tool';
    else if (pub.closed) fact = 'Closed ' + K.mdY(pub.closed, y) + (n ? ' · ' + K.plural(n, 'household') : '');
    else if (pub.on) fact = 'Open since ' + K.mdY(opens, y) + ' · ' + K.plural(n, 'household');
    else if (pub.scheduled) fact = 'Opens ' + K.mdY(opens, y) + (R.opens_time ? ' · ' + R.opens_time : '');
    else fact = 'Not scheduled' + (sugWords ? ' · ' + sugWords : '');
    if (!ro && !other && row.start) {
      if (!pub.scheduled) acts.push(A.btn('Schedule', { primary: true, write: true, onClick: schedule }));
      else {
        // Said as buttons in the title row, not behind an icon-only menu.
        if (!pub.on && !pub.closed) acts.push(A.btn('Change dates', { write: true, onClick: schedule }), A.btn('Unschedule', { ghost: true, write: true, onClick: () => act('unschedule', 'Unscheduled · Not open', true) }));
        if (pub.on) acts.push(A.btn('Close registration', { write: true, onClick: () => act('close', 'Closed · Households keep their rooms', true) }));
        if (pub.closed && S.registration_closed) acts.push(A.btn('Reopen', { write: true, onClick: () => act('reopen', 'Reopened') }));
      }
    }
    ctx.head('Registration', fact, acts);

    A.clear(ctx.body);
    const sp = ctx.split();
    const doc = h('div', { class: 'cx-page cx-doc' });
    sp.main.appendChild(doc);

    // One value, checked and saved on the server; the error at its field.
    const save = (k, v, label) => K.coa(y, 'reg', { key: k, value: v }).then(() => { R[k] = v; A.toast('Saved · ' + label); }, err => { A.fail(err); return (err && err.data && err.data.message) || 'Not saved'; });
    const saveS = (k, v, label) => K.api('PATCH', 'years/' + y + '/files/settings', { op: 'key', key: k, value: v }).then(() => { K.drop(y); S[k] = v; A.toast('Saved · ' + label); }, A.fail);
    const money = (k, label) => {
      const i = K.textIn({ value: R[k] || '', label, inputmode: 'decimal', width: '110px', placeholder: '0', onSave: v => {
        const t = v.trim().replace(/^\$/, '');
        if (t && !/^\d{1,5}(\.\d{1,2})?$/.test(t)) return 'A price · Like 65 or 27.50';
        return save(k, t, label).then(r => { const f = i.closest('.cx-field'); if (f) f.setError(typeof r === 'string' ? r : ''); });
      } });
      return h('span', { class: 'cx-money' }, h('span', { class: 'cx-money__pre', 'aria-hidden': 'true', text: '$' }), i);
    };
    const count = (k, label, ph) => {
      const i = K.textIn({ value: R[k] || '', label, inputmode: 'numeric', width: '96px', placeholder: ph || 'Number', onSave: v => {
        const t = v.trim();
        if (t && !/^\d{1,5}$/.test(t)) return 'A number';
        return save(k, t, label).then(r => { const f = i.closest('.cx-field'); if (f) f.setError(typeof r === 'string' ? r : ''); });
      } });
      return i;
    };
    const date = (k, label, help) => {
      const moved = ((d.picked.parts.registration || {}).moved || []).find(x => x.k === k && R[k] === x.to);
      const el = K.dateIn({ value: R[k] === K.NOT_YET ? '' : R[k], label, near: row.start || (y + '-05-01'), onSave: v => save(k, v, label) });
      return K.field(label, el, { tag: 'div', help: [help, moved && moved.from ? moved.from.slice(0, 4) + ': ' + K.md(moved.from) : ''].filter(Boolean).join(' · ') });
    };
    const pills = (k, opts, label, help, onPick) => K.field(label, K.pills(opts, R[k] || opts[0][0], v => (onPick || (x => save(k, x, label)))(v), { label }), { tag: 'div', help });

    /* -------------------------------------------------------- tool */
    doc.appendChild(K.section('Registration on', { help: other ? 'The Register button goes to the link' : 'One form for each household · Lodging, meals, preteens' },
      K.pills([['site', 'This site'], ['link', 'Another tool']], other ? 'link' : 'site', v => saveS('registration_mode', v, 'Registration on').then(again), { label: 'Registration on' }),
      other ? K.field('Link', K.textIn({ value: S.registration_url || '', label: 'Link', placeholder: 'https://', onSave: v => { const t = v.trim(); if (t && !/^https:\/\//.test(t)) return 'A link starting https://'; saveS('registration_url', t, 'Link'); } })) : null));
    if (other) { lock(); return; }

    /* -------------------------------------------------------- when */
    const nights = String(R.nights || '').split('|').filter(Boolean), early = String(R.early_nights || '').split('|').filter(Boolean);
    const dayList = (S.days || DAYS.slice(0, 5).join('|')).split('|').filter(x => x !== 'Wednesday' || nights.indexOf(x) > -1);
    const nightDate = x => row.start ? ' ' + K.md(O.isoAddDays(row.start, DAYS.indexOf(x))).replace(/^\w+ /, '') : '';
    const toggle = (list, x) => list.indexOf(x) > -1 ? list.filter(z => z !== x) : list.concat(x);
    const multi = (k, opts, on, label, help) => {
      const g = h('div', { class: 'ap-pills', role: 'group', 'aria-label': label });
      opts.forEach(([v, t]) => g.appendChild(h('button', { type: 'button', class: 'ap-pill', 'aria-pressed': String(on.indexOf(v) > -1), disabled: ro, on: { click: e => {
        const now = toggle(String(R[k] || '').split('|').filter(Boolean), v);
        const order = DAYS;
        save(k, now.sort((a, b) => order.indexOf(a) - order.indexOf(b)).join('|'), label);
        e.currentTarget.setAttribute('aria-pressed', String(now.indexOf(v) > -1));
      } } }, t)));
      return K.field(label, g, { tag: 'div', help });
    };
    // Opens and Closes read the same way, each with Change; choosing them is Schedule (it publishes).
    const closes = R.closes && R.closes !== K.NOT_YET ? R.closes : '';
    const when = K.section('When', { help: pub.scheduled ? '' : row.start ? 'Schedule chooses the days · The form opens to everyone then' : 'Set the dates first' },
      K.facts([
        ['Opens', pub.scheduled ? K.wd(opens) + ', ' + opens.slice(0, 4) + (R.opens_time ? ' · ' + R.opens_time + ' ' + (S.timezone_label || '') : '') : h('span', { class: 'ap-quiet', text: 'Not scheduled' + (sugWords ? ' · ' + sugWords : '') }), ro || !row.start ? null : K.link(pub.scheduled ? 'Change' : 'Schedule', schedule)],
        ['Closes', closes ? K.wd(closes) + (pub.scheduled ? '' : ' · From ' + (d.picked.from || 'last year')) + ' · After that, at check-in' : h('span', { class: 'ap-quiet', text: 'Not set' }), ro || !row.start ? null : K.link('Change', schedule)]
      ]),
      K.field('Opens at', K.textIn({ value: R.opens_time || '', label: 'Opens at', placeholder: 'Midnight', width: '140px', onSave: v => save('opens_time', v.trim(), 'Opens at') }), { help: (R.opens_time ? '' : 'Midnight if left blank · ') + (S.timezone_label || 'Campus time') }),
      multi('nights', dayList.map(x => [x, x.slice(0, 3) + nightDate(x)]), nights, 'Nights', 'Dorm rooms and the camper lot'),
      multi('early_nights', [['Wednesday', 'Wed'], ['Thursday', 'Thu']], early, 'Early nights', 'For committees and helpers who come early · Priced as nights'));
    doc.appendChild(when);

    /* -------------------------------------------------------- prices */
    const mattress = !!R.mattress_price || R.mattress_offered === 'yes';
    // Each group read as one sentence, with Change: the fields only when someone changes them.
    const $ = v => v ? '$' + v : '';
    const priceLine = [R.room_price ? $(R.room_price) + ' a night ' + (R.price_basis === 'person' ? 'a person' : 'a room') : 'No room price', R.room_beds ? K.plural(+R.room_beds, 'bed') : '', R.rooms_held ? R.rooms_held + ' rooms held' : '',
      R.linen_price ? 'Linen ' + $(R.linen_price) + (R.linen_stock ? ' · ' + R.linen_stock + ' on hand' : '') : '', mattress && R.mattress_price ? 'Air mattress ' + $(R.mattress_price) : '', R.camper_price ? 'Camper ' + $(R.camper_price) + (R.camper_per === 'stay' ? ' for the stay' : ' a night') : ''].filter(Boolean).join(' · ');
    const prices = group('Prices', priceLine, !R.room_price, () => [
      h('div', { class: 'cx-two' }, K.field('Dorm room', money('room_price', 'Dorm room'), { help: 'A night' }), K.field('Beds to a room', count('room_beds', 'Beds to a room'))),
      pills('price_basis', [['room', 'Per room'], ['person', 'Per person']], 'The campus charges'),
      K.field('Rooms held', count('rooms_held', 'Rooms held'), { help: 'Rooms the campus holds · The form stops there' }),
      h('div', { class: 'cx-two' }, K.field('Linen packet', money('linen_price', 'Linen packet')), K.field('Linen on hand', count('linen_stock', 'Linen on hand'))),
      pills('mattress_offered', [['yes', 'Offered'], ['no', 'Not offered']], 'Air mattresses', '', v => save('mattress_offered', v, 'Air mattresses').then(() => again())),
      mattress ? h('div', { class: 'cx-two' }, K.field('Air mattress', money('mattress_price', 'Air mattress')), K.field('On hand', count('mattress_stock', 'Air mattresses on hand'))) : null,
      h('div', { class: 'cx-two' }, K.field('Camper lot', money('camper_price', 'Camper lot')), pills('camper_per', [['night', 'A night'], ['stay', 'For the stay']], 'Camper price is')),
      R.key_fee ? K.field('Lost key', money('key_fee', 'Lost key'), { help: 'Each key or fob' }) : null,
      R.bed_fee ? K.field('Beds moved', money('bed_fee', 'Beds moved'), { help: 'If not put back' }) : null,
      'yf_age_split' in R ? pills('yf_age_split', [['yes', 'All under 18, or all 18 and over'], ['no', 'Any ages']], 'Young Folks rooms') : null,
      ((d.picked.parts.registration || {}).campus) ? h('p', { class: 'ap-quiet', text: 'Prices and the campus’s rules from ' + d.picked.parts.registration.campus + ', the last Conference at ' + (S.venue || row.venue || 'this campus') }) : null],
      { help: n ? K.plural(n, 'household') + ' registered · A changed price applies to new registrations' : '', looks: ro ? null : K.looks(d, 'reg:prices', { what: 'Prices', line: 'Not public until checked or scheduled', tip: 'Prices, and the linens and mattresses on hand', done: again }) });
    doc.appendChild(prices);

    /* -------------------------------------------------------- on the form */
    const addr = K.textIn({ value: String(R.check_address || '').split('|').join('\n'), label: 'Mail checks to', multiline: true, rows: 3, placeholder: 'Annual Conference Treasurer\nPO Box\nTown, State ZIP', onSave: v => save('check_address', v.split(/\r?\n/).map(s => s.trim()).filter(Boolean).join('|'), 'Mail checks to') });
    const gift = String(R.gift_for || '').toLowerCase() !== 'none';
    const formLine = [R.meals_free === 'no' ? 'Meals paid on the form' : 'Meals provided', R.preteen_details === 'paper' ? 'Preteens’ notes on paper' : 'Preteens’ notes on the form', R.room_choice === 'households' ? 'Households choose rooms' : 'Lodging gives rooms',
      R.refunds_by && R.refunds_by !== K.NOT_YET ? 'Credit asked by ' + K.md(R.refunds_by) : '', R.check_payee ? 'Checks to ' + R.check_payee + (R.check_by ? ' by ' + K.md(R.check_by) : '') : '', R.paper_forms === 'yes' ? 'Paper forms' : '', gift ? (R.gift_for ? 'Gift for ' + R.gift_for : 'A gift asked') : 'No gift'].filter(Boolean).join(' · ');
    doc.appendChild(group('On the form', formLine, false, () => [
      pills('meals_free', [['yes', 'Provided'], ['no', 'Paid on the form']], 'Meals'),
      pills('preteen_details', [['online', 'On the form'], ['paper', 'On paper at check-in']], 'Preteens’ medical notes'),
      pills('room_choice', [['lodging', 'Lodging'], ['households', 'Each household']], 'Rooms given by', R.room_choice === 'households' ? 'Households choose on the map' : 'Lodging places everyone'),
      h('div', { class: 'cx-two' }, date('refunds_by', 'Credit asked by', 'For nights not used'), date('cancel_by', 'Cancel by', 'Full refund before then')),
      K.field('Checks payable to', K.textIn({ value: R.check_payee || '', label: 'Checks payable to', placeholder: 'Annual Conference Treasurer', onSave: v => save('check_payee', v.trim(), 'Checks payable to') }), { help: 'By role, never a name' }),
      K.field('Mail checks to', addr, { help: 'One line each' }),
      date('check_by', 'Checks by', 'After that, at check-in'),
      pills('paper_forms', [['no', 'None'], ['yes', 'Lodging enters them']], 'Paper forms', 'For households without email'),
      // A gift is a switch, not the word "none" typed into a box.
      K.field('A gift', K.pills([['yes', 'Asked'], ['no', 'Not asked']], gift ? 'yes' : 'no', v => save('gift_for', v === 'no' ? 'none' : '', 'A gift').then(again), { label: 'A gift' }), { tag: 'div', help: 'Optional on the form' }),
      gift ? K.field('A gift for', K.textIn({ value: R.gift_for || '', label: 'A gift for', placeholder: 'What it’s for', onSave: v => save('gift_for', v.trim(), 'A gift for') })) : null,
      K.field('Names cleared', (A.boot() || { viewer: {} }).viewer.webmaster ? count('clear_after_days', 'Names cleared', '60') : h('span', { text: (R.clear_after_days || 60) + ' days after' + (row.end ? ' · ' + K.mdY(O.isoAddDays(row.end, +R.clear_after_days || 60), y) : '') }), { tag: 'div', help: 'Set by the webmasters · Counts stay' })]));
    lock();

    // A group read as a sentence; Change shows its fields (open from the start when it's empty).
    function group(title, line, start, fields, o) {
      o = o || {};
      let openG = start;
      const sec = h('section', { class: 'ap-section cx-sec', 'aria-label': title });
      const drawG = () => {
        A.clear(sec);
        sec.append(...[h('h2', { class: 'ap-h2' }, title, ro ? null : h('span', { class: 'ap-h2__act' }, K.link(openG ? 'Done' : 'Change', () => { openG = !openG; if (!openG) again(); else drawG(); }))),
          o.help ? h('p', { class: 'ap-help cx-sec__help', text: o.help }) : null, o.looks || null].filter(Boolean));
        if (openG) sec.append(h('div', { class: 'cx-groupfields' }, fields()));
        else sec.append(h('p', { class: 'cx-groupline', text: line }));
        lock();
      };
      drawG();
      return sec;
    }

    function lock() { if (ro) doc.querySelectorAll('input, textarea, button.ap-pill, button.cx-link').forEach(x => { x.disabled = true; }); }

    /* -------------------------------------------------------- the acts */
    function schedule() {
      let o = opens || suggested, c = R.closes && R.closes !== K.NOT_YET ? R.closes : '';
      const fo = K.field('Opens', K.dateIn({ value: o, label: 'Opens', near: row.start, onSave: v => { o = v; } }), { tag: 'div', help: carried ? 'From ' + (d.picked.from || 'last year') + ' · Moved with the Conference' : suggested && !opens ? 'Suggested from last year' : '' });
      const fc = K.field('Closes', K.dateIn({ value: c, label: 'Closes', near: row.start, onSave: v => { c = v; } }), { tag: 'div', help: 'By the first day' });
      const left = [];
      // Scheduling publishes the prices then: last year's, unchecked, are said plainly first.
      if (pricesLeft) left.push({ t: 'Prices are ' + d.picked.from + '’s · Check before ' + K.md(o || suggested), go: () => { const b = doc.querySelector('[aria-label="Prices"] .cx-from .ap-btn'); if (b) b.scrollIntoView({ block: 'center' }); } });
      if (!R.room_price) left.push({ t: 'No room price' });
      K.confirm(sp, {
        title: pub.scheduled ? 'Change the dates' : 'Schedule registration',
        lines: ['The form opens to everyone on that day' + (R.opens_time ? ', at ' + R.opens_time : '') + ' · Its prices go public then'],
        field: h('div', null, fo, fc), left,
        actLabel: pub.scheduled ? 'Save' : left.length ? 'Schedule anyway' : 'Schedule',
        act: () => {
          fo.querySelectorAll('input').forEach(i => i.dispatchEvent(new Event('change')));
          fc.querySelectorAll('input').forEach(i => i.dispatchEvent(new Event('change')));
          if (!o) return Promise.reject({ message: 'Choose when it opens' });
          return K.coa(y, 'publish', { part: 'registration', act: 'schedule', opens: o, closes: c });
        },
        onDone: () => { A.toast('Scheduled · Opens ' + K.md(o)); again(); }
      });
    }
    function act(a, said, danger) {
      if (!danger) { K.coa(y, 'publish', { part: 'registration', act: a }).then(() => { A.toast(said); again(); }, A.fail); return; }
      K.confirm(sp, {
        title: { close: 'Close registration', unschedule: 'Unschedule registration' }[a], danger: true, reason: true,
        lines: [a === 'close' ? 'Nobody new can register · Households registered keep their rooms' : 'The form doesn’t open until scheduled again'],
        actLabel: { close: 'Close', unschedule: 'Unschedule' }[a],
        act: reason => K.coa(y, 'publish', { part: 'registration', act: a, reason }),
        onDone: () => { A.toast(said); again(); }
      });
    }
  }
})();
