/*
 * webmaster-email.js — Email, for the webmasters (Round 6b, Oct 17; docs/27-back-end-map/
 * area-people-access.md §9): what the site sends, by kind and day, and what didn't go; never anyone's
 * address (a domain at most), subject or words. Each kind has a preview, drawn from made-up people.
 *
 *   s=email&v=problems|queued|all|kinds&f=kind:<kind>&id=<day>:<kind> | kind:<kind>
 *   (v=failed and v=refused are other names for problems.)
 * The Mail log (every email in full) is local and staging only: Open Mail log, when it exists.
 */
(function () {
  'use strict';
  const A = window.OGC_APP;
  if (!A) return;
  const h = A.h;
  const num = n => n ? Number(n).toLocaleString('en-US') : '';

  A.screen({
    id: 'email', title: 'Email', icon: 'mail', section: 'own', who: ['webmaster'],
    render(ctx) {
      let alive = true;
      const p = ctx.params;
      const sp = ctx.split();
      ctx.head('Email', '', []);
      sp.main.appendChild(h('p', { class: 'ap-quiet', style: { padding: '20px' }, role: 'status', text: 'Loading' }));
      A.api('GET', 'email?days=14').then(d => { if (alive) page(d); }).catch(() => { if (alive) A.clear(sp.main).appendChild(A.empty({ title: 'Not loaded', line: 'Reload the page', inset: true })); });

      function page(d) {
        const prob = d.problems.failed + d.problems.refused;
        const kindF = (A.fParse(p.f).kind || [])[0] || '';
        let view = { failed: 'problems', refused: 'problems' }[p.v] || p.v || (prob ? 'problems' : 'all');
        const rowsAll = d.rows.filter(r => !kindF || r.kind === kindF);
        const probRows = rowsAll.filter(r => r.failed || r.refused);
        const qRows = rowsAll.filter(r => r.queued);
        const chips = [];
        if (probRows.length) chips.push({ id: 'problems', label: 'Problems', n: probRows.reduce((k, r) => k + r.failed + r.refused, 0) });
        if (qRows.length) chips.push({ id: 'queued', label: 'Queued', n: d.queue.n });
        chips.push({ id: 'all', label: 'All' });
        chips.push({ id: 'kinds', label: 'Every kind' });
        if (!chips.some(c => c.id === view)) view = 'all';
        // The fact: 14 days, how many went, what didn't; the queue when anything waits.
        const fact = h('span', null, d.days + ' days · ' + (d.totals.sent ? num(d.totals.sent) + ' sent' : 'No email'),
          prob ? h('span', { class: 'pp-late' }, ' · ' + (d.problems.failed ? d.problems.failed + ' failed' : '') + (d.problems.failed && d.problems.refused ? ' · ' : '') + (d.problems.refused ? d.problems.refused + ' refused' : '')) : (d.totals.sent ? ' · All sent' : ''),
          d.queue.n ? h('span', { class: d.queue.mins > 30 ? 'pp-late' : '' }, ' · ' + d.queue.n + ' waiting · Oldest ' + (d.queue.mins >= 60 ? Math.round(d.queue.mins / 60) + ' h' : d.queue.mins + ' min')) : null);
        ctx.head('Email', fact, d.log ? [h('a', { class: 'ap-btn ap-btn--ghost', href: d.log, title: 'Every email in full · Local and staging only' }, A.icon('mail'), 'Open Mail log')] : []);
        A.clear(sp.main);
        const bar = h('div', { class: 'ap-views' }, A.views(chips, view, id => { A.go({ v: id === (prob ? 'problems' : 'all') ? '' : id, id: '' }, { replace: true }); }));
        if (kindF) {
          const lab = (d.kinds.find(k => k.kind === kindF) || {}).label || kindF;
          const x = A.link({ f: '', id: '' }, h('span', { class: 'ap-sr', text: 'Every kind' }), 'ap-chip__x');
          x.appendChild(A.icon('x', 13));
          bar.appendChild(h('span', { class: 'ap-chip ap-chip--filter' }, lab, x));
        }
        sp.main.appendChild(bar);
        if (view === 'kinds') {
          // What the site sends: every kind in the set, with how many went in 14 days; each has a preview.
          const sent = {};
          d.rows.forEach(r => { sent[r.kind] = (sent[r.kind] || 0) + r.sent; });
          sp.main.appendChild(A.table({
            label: 'Every kind', rows: d.kinds, key: k => 'kind:' + k.kind, selected: p.id,
            onOpen: k => openKind(k.kind),
            cols: [
              { label: 'Kind', render: k => h('span', { class: 'ap-cell-title', text: k.label }) },
              { label: 'Sent · 14 days', cls: 'ap-td--num', render: k => num(sent[k.kind]) }
            ]
          }));
        } else {
          const rows = view === 'problems' ? probRows : view === 'queued' ? qRows : rowsAll;
          const has = k => rows.some(r => r[k]);
          sp.main.appendChild(rows.length ? A.table({
            label: 'Email by day', rows, key: r => r.id, selected: p.id,
            onOpen: r => openDay(r),
            cols: [
              { label: 'Day', cls: 'ap-td--nowrap', render: r => A.fmt.md(r.day) },
              { label: 'Kind', render: r => h('span', null, h('span', { class: 'ap-cell-title', text: r.label }), h('span', { class: 'ap-only-narrow ap-cell-sub', text: [r.failed ? r.failed + ' failed' : '', r.refused ? r.refused + ' refused' : '', r.queued ? r.queued + ' queued' : ''].filter(Boolean).join(' · ') })) },
              // A zero cell is blank; a column with nothing in it isn't drawn.
              has('sent') ? { label: 'Sent', cls: 'ap-td--num', wide: true, render: r => num(r.sent) } : null,
              has('failed') ? { label: 'Failed', cls: 'ap-td--num', wide: true, render: r => r.failed ? h('span', { class: 'pp-late', text: num(r.failed) }) : '' } : null,
              has('refused') ? { label: 'Refused', cls: 'ap-td--num', wide: true, render: r => r.refused ? h('span', { class: 'pp-late', text: num(r.refused) }) : '' } : null,
              has('queued') ? { label: 'Queued', cls: 'ap-td--num', wide: true, render: r => num(r.queued) } : null
            ].filter(Boolean)
          }) : A.empty({ title: d.rows.length ? 'Nothing here' : 'No email in ' + d.days + ' days', inset: true }));
        }
        // A record named in the address opens beside the list.
        if (p.id && /^kind:/.test(p.id)) openKind(p.id.slice(5));
        else if (p.id) { const r = d.rows.find(x => x.id === p.id); if (r) openDay(r); else { const [day, kind] = p.id.split(':'); if (day && kind) openDay({ id: p.id, day, kind, label: kind }); } }

        function mark(id) { sp.main.querySelectorAll('tr[data-key]').forEach(tr => tr.setAttribute('aria-selected', String(tr.dataset.key === id))); }

        // A day's kind: counts, then each message that didn't go (time · domain · why). No acts: the words
        // aren't kept once a message fails, so there's nothing to resend.
        function openDay(r) {
          A.setParams({ id: r.id });
          mark(r.id);
          sp.open({ title: A.fmt.md(r.day) + ' · ' + r.label, body: [h('p', { class: 'ap-quiet', role: 'status', text: 'Loading' })], onClose: () => { A.setParams({ id: '' }); mark(''); } });
          A.api('GET', 'email/day?d=' + encodeURIComponent(r.day) + '&kind=' + encodeURIComponent(r.kind)).then(x => {
            const c = x.counts;
            const body = [h('dl', { class: 'ap-facts' }, ['sent', 'failed', 'refused', 'queued'].filter(k => c[k]).map(k => [h('dt', { text: k[0].toUpperCase() + k.slice(1) }), h('dd', { text: num(c[k]) })]))];
            if (x.rows.length) body.push(h('ul', { class: 'ap-list pp-mail' }, x.rows.map(m => h('li', null, h('div', { class: 'ap-item' }, h('span', { class: 'ap-item__main' },
              h('span', { class: 'ap-item__title', text: m.at + ' · To ' + (m.domain || 'an address') }), h('span', { class: 'ap-item__why' + (m.status === 'queued' ? '' : ' pp-late'), text: m.why })))))));
            body.push(h('p', { class: 'ap-help', text: r.kind === 'invite' ? 'Shows on Members and Access as not signed in' : x.rows.length ? 'Ask them to try again · Or the Conference phone' : 'All went' }));
            if (r.kind === 'invite' && x.rows.length) body.push(h('p', null, A.link({ s: 'members', v: 'invited', id: '', f: '' }, 'Open Access', 'ap-link')));
            sp.open({ title: A.fmt.md(r.day) + ' · ' + (x.label || r.label), body, foot: [previewBtn(r.kind), d.log ? h('a', { class: 'ap-btn ap-btn--ghost', href: d.log + (d.log.includes('?') ? '&' : '?') + 'kind=' + encodeURIComponent(r.kind) + '&day=' + r.day, text: 'Open Mail log' }) : null].filter(Boolean), onClose: () => { A.setParams({ id: '' }); mark(''); } });
          }).catch(() => sp.open({ title: r.label, body: [A.empty({ title: 'Not loaded', inset: true })] }));
        }
        function previewBtn(kind) { return A.btn('Preview', { ghost: true, icon: 'eye', onClick: () => openKind(kind) }); }
        // The kind as the set draws it, from made-up people (never anyone's email).
        function openKind(kind) {
          A.setParams({ id: 'kind:' + kind });
          mark('kind:' + kind);
          const lab = (d.kinds.find(k => k.kind === kind) || {}).label || kind;
          sp.open({ title: lab, body: [h('p', { class: 'ap-quiet', role: 'status', text: 'Loading' })], onClose: () => { A.setParams({ id: '' }); mark(''); } });
          A.api('GET', 'email/preview?kind=' + encodeURIComponent(kind)).then(t => {
            const f = h('iframe', { title: lab + ' · Preview', sandbox: '', class: 'ap-mailframe' });
            f.srcdoc = t.html;
            sp.open({ title: lab, line: t.subject, body: [h('p', { class: 'ap-help', text: 'A preview · Made-up people' }), f], onClose: () => { A.setParams({ id: '' }); mark(''); },
              foot: [A.link({ s: 'email', v: 'all', f: 'kind:' + kind, id: '' }, 'Every day of it', 'ap-btn ap-btn--ghost')] });
          }).catch(() => sp.open({ title: lab, body: [A.empty({ title: 'No preview', line: 'Its words come from the screen that sends it', inset: true })], onClose: () => { A.setParams({ id: '' }); mark(''); } }));
        }
      }
      return () => { alive = false; };
    }
  });
})();
