/*
 * Lodging › Rooms (app-committees, Oct 11): from the whole list of households to everyone in a room.
 * Moved into the app from the lodging area's board (lodging-board.js) and reworked from its critique.
 *
 *   Title row   "Rooms", where it stands, and one filled button chosen by where the work is:
 *               Assign all · N, then Review · N, then Publish, then Send update · N. Export (the
 *               rooming list for the campus) and More (Mark older, Recent changes, Unpublish).
 *   What to do  the steps in order, ticking themselves from the data.
 *   The list    Unassigned · Review · Assigned, and one search over every household and person.
 *   Beside it   the chosen household (the decision first: what they asked, what's wrong and why,
 *               Assign; the rest folded under More), then its floor. With nobody chosen: the plan,
 *               and "On this floor" (room · household) under it, so a floor reads at a glance.
 *   The plan    tap or drop a household on a room: it takes its whole run of rooms there, or moves
 *               there (polish: a tap gave one room and left a family of six short). A swap only
 *               between households with the same number of rooms. Names in the rooms where they fit.
 * Every change saves at once and says what it did, with Undo. On a phone the list is the page and a
 * household opens on its own, its floor below.
 */
(function () {
  'use strict';
  const A = window.OGC_APP, h = A.h, K = window.OGC_CK, O = window.OGC, L = O.lodging, S = L.S, SU = L.SU;
  const U = { sel: '', list: '', find: '', hall: '', floor: 0, room: '', older: false, followed: '', zoom: 0, band: false, side: '', focusRoom: '' };
  L.roomsUI = U;
  const plural = SU.plural;
  const narrow = () => window.matchMedia('(max-width: 899px)').matches;
  const touch = () => window.matchMedia('(pointer: coarse)').matches;

  /* ================================================================ where the work stands */

  const familyRooms = () => L.familyFloors().reduce((k, f) => k + f.rooms.length, 0);
  const isNew = x => !!S.seen && String(x.at) > S.seen && !L.given(x).length;
  function tally() {
    const d = L.dorm(), waiting = [], given = [];
    d.forEach(x => { if (L.given(x).length) given.push(x); else waiting.push(x); });
    const changes = L.changed();
    const review = given.filter(x => L.toReview(x).length || changes.indexOf(x) > -1).concat(changes.filter(x => !x.active));
    const pub = L.data('meta:published');
    return { d, waiting, review, given, changes, pub: pub && pub.date ? pub : null, pubChanged: L.pubChanged(), rooms: familyRooms() };
  }
  L.tally = tally;

  // The next household waiting, opened beside the rooms (by hand: docs/25).
  function placeNext() {
    U.list = 'todo'; U.older = false;
    const f = listOf(tally(), 'todo')[0];
    if (f) pick(f.rid, true); else redraw();
  }

  function primary(t) {
    if (L.ro) return null;
    // The COA doing Lodging's big act: whose it is goes in the tooltip; the label stays 1–3 words.
    const fk = A.foreignOf ? A.foreignOf(A.params().s) : '';
    // By hand (docs/25): the button opens the next household waiting, with its needs, its note and the
    // free rooms that fit. Nothing is placed by the software.
    if (t.waiting.length) return { t: 'Place · ' + t.waiting.length, run: placeNext, tip: (fk ? 'For ' + ((A.committee(fk) || {}).name || 'Lodging') + ' · ' : '') + 'The next household waiting: its needs, its note and the free rooms that fit' };
    if (t.review.length) return { t: 'Review · ' + t.review.length, run: () => { U.list = 'review'; U.older = false; const f = listOf(t, 'review')[0]; if (f) pick(f.rid, true); else redraw(); } };
    if (!t.pub && t.given.length) return { t: 'Publish', run: () => openPublish('publish'), tip: 'Households see their rooms in Your sign-ups' };
    if (t.pub && t.pubChanged.length) return { t: 'Send update · ' + t.pubChanged.length, run: () => openPublish('update'), tip: 'The households whose rooms changed since ' + L.md(t.pub.date) };
    return null;
  }

  function steps(t) {
    const st = L.data('meta:steps') || {}, start = S.phase.start;
    const forms = S.hh.some(x => x.source === 'form') || (S.imported && !S.imported.undone);
    const marked = t.d.filter(L.older).length;
    const before = !t.waiting.length && !t.review.length;
    const list = [];
    if (forms) list.push({ t: 'Import', done: !!S.hh.some(x => x.source === 'form'), note: S.imported ? L.md(S.imported.at) : '', tip: 'The Google Form’s responses', run: () => A.go({ s: 'lod-import', id: '' }) });
    // The step the title row's filled button does is the one marked; its count is on the button.
    list.push({ t: 'Place', done: t.d.length > 0 && !t.waiting.length, note: '', tip: 'Each household by hand, reading its note', run: placeNext });
    list.push({ t: 'Review', done: t.given.length > 0 && before, note: t.review.length ? String(t.review.length) : '', tip: 'Requests the rooms don’t meet, and changes since rooms were given', run: () => { U.list = 'review'; U.older = false; redraw(); } });
    list.push({ t: 'Publish', done: !!t.pub && !t.pubChanged.length, note: t.pub ? L.md(t.pub.date) + (t.pubChanged.length ? ' · ' + t.pubChanged.length + ' changed' : '') : '', tip: 'Households see their rooms in Your sign-ups', run: () => { if (t.given.length) openPublish(t.pub ? 'update' : 'publish'); } });
    // Counts' own Mark sent (Round 5): the newest send.
    const sent = (S.sent || [])[0];
    list.push({ t: 'Final counts', done: !!sent, note: sent ? L.md(sent.day) : S.countsDue ? 'By ' + L.md(S.countsDue) : start ? 'By ' + L.md(O.isoAddDays(start, -14)) : '', tip: 'Rooms per night, linens, mattresses and keys, to the campus two weeks before', run: () => A.go({ s: 'lod-counts', v: '', id: '' }) });
    list.push({ t: 'Print desk list', done: !!st.print, note: st.print ? L.md(st.print.at) : '', tip: 'The Lodging Desk’s list, the week before', run: () => A.go({ s: 'lod-checkin', v: 'desk', id: '' }) });
    return K.steps(list);
  }

  /* ================================================================ the list */

  const LISTS = [['todo', 'Unassigned'], ['review', 'Review'], ['done', 'Assigned']];
  function listOf(t, k) {
    if (k === 'todo') return t.waiting.slice().sort((a, b) => (isNew(b) - isNew(a)) || (L.firstGroup(b) - L.firstGroup(a)) || (String(a.at) < String(b.at) ? -1 : 1));
    if (k === 'review') return t.review;
    return t.given.slice().sort((a, b) => a.sur.localeCompare(b.sur) || a.firsts.localeCompare(b.firsts));
  }

  function chip(text, tone, title) { return h('span', { class: 'cm-chip' + (tone ? ' cm-chip--' + tone : ''), title: title || null, text }); }

  function olderBox(x, label) {
    const on = L.older(x);
    return h('button', { type: 'button', class: 'cm-older', 'aria-pressed': String(on), 'data-k': 'older:' + x.rid, title: 'Lodging’s own mark: placed first, on a ground floor near the dining hall. Never shown to anyone else.',
      on: { click: e => { e.stopPropagation(); L.hhSave(x, { older: !on }, { label: x.sur + (on ? ' · Not older' : ' · Older') }); } } },
    h('span', { class: 'cm-box', 'aria-hidden': 'true' }, on ? K.icon('check', 12) : null), label || 'Older');
  }

  function item(x, t, plan, status) {
    const on = U.sel === x.rid, mine = L.given(x), rv = L.toReview(x), ch = L.changes(x);
    const review = U.list === 'review' && !U.find && !L.ro && (rv.length || ch.length);
    // "Near the Millers" said once: the Review chip asks which, so the tag steps aside.
    const tags = L.tagsOf(x).filter(g => !(rv.some(i => i.k === 'nearpick') && /^Near /.test(g) && !/restroom/.test(g))), drag = !L.ro && !narrow() && x.active && !touch() && !A.readonly;
    const sug = null; // docs/25: no room is suggested; Lodging chooses
    const roomLine = status ? h('span', { text: status }) : mine.length ? h('b', { text: L.roomsWords(mine) + (L.chosenByHousehold(x) ? ' · Chosen' : '') }) : null; // not placed yet: nothing to say (docs/25: no suggestion, no guess why)
    const li = h('li', { class: 'cm-hh' + (on ? ' is-sel' : '') + (review ? ' is-review' : ''), draggable: drag ? 'true' : null, 'data-drag': drag ? x.rid : null },
      h('button', { type: 'button', class: 'cm-hh__main', 'aria-pressed': String(on), 'data-k': 'sel:' + x.rid, on: { click: () => pick(x.rid) } },
        h('span', { class: 'cm-hh__name' }, h('b', { text: x.sur }), x.firsts ? h('span', { text: ' · ' + x.firsts }) : null, isNew(x) && !t.waiting.every(isNew) ? chip('New', 'tan') : null),
        h('span', { class: 'cm-hh__meta', text: L.metaOf(x) }),
        rv.length || ch.length || tags.length ? h('span', { class: 'cm-hh__tags' }, rv.map(i => chip(i.text, 'warn', i.title)), ch.map(c => chip(c.text, 'blue')), tags.map(g => chip(g))) : null,
        roomLine ? h('span', { class: 'cm-hh__room' }, roomLine) : null),
      review ? h('div', { class: 'cm-hh__acts' }, fixButtons(x, rv, true), ch.some(c => c.free) ? A.btn('Free ' + L.roomsWords(mine), { write: true, onClick: () => setRooms(x, null, x.sur + ' · ' + L.roomsWords(mine) + ' freed') }) : null,
        A.btn('Looks right', { write: true, onClick: () => looksRight(x) }))
        : null);
    return li;
  }

  function listBody(t) {
    const plan = U.list === 'todo' && !U.find ? L.plan(t.waiting) : {};
    if (U.find.trim()) {
      const hits = L.search(U.find);
      return hits.length ? hits.map(x => item(x, t, null, L.where(x))) : [h('li', { class: 'cm-none', text: 'No matches' })];
    }
    const l = listOf(t, U.list);
    return l.length ? l.map(x => item(x, t, plan)) : [h('li', { class: 'cm-none', text: U.list === 'review' ? 'Nothing to review' : 'None' })];
  }

  function listCol(t) {
    if (U.older) return olderPass(t);
    const n = { todo: t.waiting.length, review: t.review.length, done: t.given.length };
    const ul = h('ul', { class: 'cm-hhlist', 'aria-label': 'Households' }, listBody(t));
    // A lone chip is no choice: the lists' chips only when there are two or more.
    const chipList = LISTS.filter(c => n[c[0]] || U.list === c[0]);
    const views = chipList.length > 1 ? A.views(chipList.map(c => ({ id: c[0], label: c[1], n: n[c[0]] })), U.find ? '' : U.list, id => { U.list = id; U.find = ''; redraw(); }) : h('span', { class: 'cm-listname', text: (LISTS.find(c => c[0] === U.list) || ['', ''])[1] });
    const find = K.find({ value: U.find, placeholder: 'Search', title: 'Anyone’s name, a room, R-number or a phone’s last digits · /', onInput: v => {
      U.find = v;
      A.clear(ul).append(...listBody(t));
      views.querySelectorAll('.ap-chip').forEach(b => b.setAttribute('aria-pressed', String(!v.trim() && b.textContent.indexOf(LISTS.find(c => c[0] === U.list)[1]) === 0)));
    } });
    find.querySelector('input').setAttribute('data-k', 'find');
    return h('div', { class: 'cm-board__list' }, h('div', { class: 'cm-listhead' }, views, find),
      touch() && !narrow() && !L.ro && U.list === 'todo' ? h('p', { class: 'ap-quiet cm-hint', text: 'Tap a household, then a room' }) : null,
      ul);
  }

  // Mark older, in one pass. Households whose Form named an adult 65 or over are suggested.
  function olderPass(t) {
    const l = t.d.slice().sort((a, b) => (b.oldest >= 65) - (a.oldest >= 65) || a.sur.localeCompare(b.sur)), n = l.filter(L.older).length;
    return h('div', { class: 'cm-board__list' },
      h('div', { class: 'cm-listhead cm-olderhead' }, h('div', null, h('strong', { text: 'Mark older' }), h('span', { class: 'ap-quiet', text: n ? ' · ' + n + ' marked' : ' · None marked' })),
        A.btn('Done', { primary: true, write: true, onClick: () => { U.older = false; const st = Object.assign({}, L.data('meta:steps') || {}); st.older = true; L.save([{ key: 'meta:steps', data: st }], { label: 'Mark older · Done' }); } })),
      h('p', { class: 'ap-help cm-pad', text: 'Placed first, on ground floors near the dining hall · Lodging’s own mark' }),
      h('ul', { class: 'cm-hhlist cm-olderlist' }, l.map(x => h('li', { class: 'cm-hh' },
        h('div', { class: 'cm-hh__main' }, h('span', { class: 'cm-hh__name' }, h('b', { text: x.sur }), x.firsts ? h('span', { text: ' · ' + x.firsts }) : null),
          h('span', { class: 'cm-hh__meta', text: K.facts([x.oldest >= 65 ? 'Suggested · ' + x.oldest : '', x.walker ? (x.walkerFromNote ? 'Step-free (from their note)' : 'Step-free') : '', x.ground ? 'Ground floor' : '', L.given(x).length ? L.roomsWords(L.given(x)) : '']) })),
        A.readonly ? null : olderBox(x)))));
  }

  /* ================================================================ fixes */

  function fixFor(x, i) {
    const g = L.given(x);
    if (i.k === 'group') { const s = groupMove(x); return s ? { t: 'Move · ' + L.roomsWords(s), run: () => setRooms(x, s) } : null; }
    if (['ground', 'older', 'restroom', 'apart', 'near', 'bath', 'kept', 'outroom'].indexOf(i.k) > -1) {
      const s = moveSuggestion(x);
      return s ? { t: 'Move · ' + L.roomsWords(s), run: () => setRooms(x, s) } : null;
    }
    if (i.k === 'short' || i.k === 'over') { const s = addRoom(x); return s ? { t: 'Add ' + L.roomWords(s), run: () => setRooms(x, g.concat(s), x.sur + ' · ' + L.roomWords(s) + ' added') } : { none: g.length ? 'No room free beside ' + L.roomWords(g[g.length - 1]) : '' }; }
    if (i.k === 'extra') return { t: 'Free ' + L.roomWords(g[g.length - 1]), run: () => setRooms(x, g.slice(0, -1), x.sur + ' · ' + L.roomWords(g[g.length - 1]) + ' freed') };
    if (i.k === 'keys') { const o = x.adults.find(p => !p.nights || !p.nights.length || p.nights.indexOf(x.nights[0]) > -1); return o ? { t: 'Keys to ' + L.first(o.name), run: () => { const k = Object.assign({}, L.hrow(x).keys || {}); k[i.room] = o.name; L.hhSave(x, { keys: k }, { label: x.sur + ' · Keys to ' + L.first(o.name) }); } } : null; }
    return null;
  }
  // The buttons that fix what's wrong, when there's an obvious fix. compact: on a list card.
  function fixButtons(x, rv, compact) {
    const out = [], seen = {};
    rv.forEach(i => {
      if (i.k === 'nearpick') return;
      const f = fixFor(x, i);
      if (f && f.t && !seen[f.t]) { seen[f.t] = 1; out.push(A.btn(f.t, { write: true, onClick: f.run })); }
      else if (f && f.none && !compact && !seen[f.none]) { seen[f.none] = 1; out.push(h('span', { class: 'ap-quiet', text: f.none })); }
    });
    return out;
  }
  // Where it would go if planned again on its own (its rooms freed for the planning).
  function moveSuggestion(x) {
    const keep = L.hrow(x).rooms, row = S.rows['hh:' + x.rid];
    if (row) row.data = Object.assign({}, row.data, { rooms: [] });
    const p = L.plan([x])[x.rid];
    if (row) row.data = Object.assign({}, row.data, { rooms: keep });
    return p && p.join('|') !== (keep || []).join('|') ? p : null;
  }
  function groupMove(x) {
    const floor = L.groupFloor(x);
    if (!floor || (L.firstGroup(x) && +floor.split('|')[1] !== 1)) return null;
    const t = L.taken(x.rid), need = Math.max(1, L.given(x).length || x.asked), f = S.floors.find(y => y.hall + '|' + y.floor === floor);
    if (!f) return null;
    for (let i = 0; i + need <= f.rooms.length; i++) {
      const run = f.rooms.slice(i, i + need);
      if (run.every((r, k) => !t[r.id] && L.usable(r.id) && (k === 0 || !r.gap))) return run.map(r => r.id);
    }
    return null;
  }
  // A free room beside the household's own, on the same floor; never a ground-floor room kept for
  // those who asked, unless they're on the ground floor already. No far room offered (polish).
  function addRoom(x) {
    const g = L.given(x).map(L.room).filter(Boolean), t = L.taken();
    const onGround = g.some(r => r.floor === 1);
    for (const r of g) {
      const f = S.floors.find(y => y.rooms.indexOf(r) > -1), i = f.rooms.indexOf(r);
      for (const j of [i + 1, i - 1]) {
        const o = f.rooms[j];
        if (o && !t[o.id] && L.usable(o.id) && !(j > i ? o.gap : r.gap) && (o.floor !== 1 || onGround || L.firstGroup(x))) return o.id;
      }
    }
    return null;
  }
  function looksRight(x) {
    const rv = L.toReview(x), ch = L.changes(x), patch = {};
    if (rv.length) patch.ok = { sig: L.sig(L.issues(x)) };
    if (ch.length) patch.snap = true;
    L.hhSave(x, patch, { label: x.sur + ' · Looks right' });
  }

  /* ================================================================ doing things */

  function pick(rid, keepList) {
    U.sel = U.sel === rid && !keepList ? '' : rid; U.room = ''; U.followed = ''; U.focusRoom = ''; U.side = '';
    A.setParams({ id: U.sel || '' });
    redraw();
    const side = document.querySelector('.cm-board__side');
    if (side && !narrow()) side.scrollTop = 0;
    if (narrow()) window.scrollTo(0, 0);
  }
  L.show = rid => { U.sel = rid; U.room = ''; U.find = ''; U.followed = ''; const x = L.byRid(rid); if (x) U.list = L.given(x).length ? (tally().review.indexOf(x) > -1 ? 'review' : 'done') : 'todo'; A.go({ s: 'lod-rooms', id: rid, v: '' }); };
  function setRooms(x, ids, label) {
    return L.hhSave(x, { rooms: ids && ids.length ? ids : null }, { label: label || (ids && ids.length ? x.sur + ' · ' + L.roomsWords(ids) : x.sur + ' · Unassigned') });
  }
  function suggestionOf(x) {
    if (!x.active || L.given(x).length) return null;
    return L.plan(L.dorm().filter(y => !L.given(y).length))[x.rid] || null;
  }
  function assignOne(x) {
    const sug = suggestionOf(x);
    if (!sug) { A.toast(L.whyNot(x)); return; }
    const t = tally(), nx = listOf(t, 'todo').filter(y => y.rid !== x.rid)[0];
    setRooms(x, sug, x.sur + ' · ' + L.roomsWords(sug) + (nx ? ' · Next · ' + nx.sur : ''));
    U.sel = nx ? nx.rid : ''; U.followed = '';
    A.setParams({ id: U.sel });
  }
  function assignAll() {
    const t = tally(), plan = L.plan(t.waiting);
    const ops = Object.keys(plan).map(rid => ({ key: 'hh:' + rid, data: Object.assign({}, L.hrow(rid), { rooms: plan[rid] }) }));
    if (!ops.length) { A.toast('No rooms free'); return; }
    const notPlaced = t.waiting.length - ops.length;
    U.older = false; U.sel = '';
    L.save(ops, { label: plural(ops.length, 'household') + ' assigned', silent: true, done: res => {
      const after = tally();
      const fk = A.foreignOf ? A.foreignOf(A.params().s) : '';
      A.toast([ops.length + ' assigned', notPlaced ? notPlaced + ' not placed' : '', after.review.length ? after.review.length + ' to review' : '', fk ? ((A.committee(fk) || {}).name || 'Lodging') + ' sees it in Recent changes' : ''].filter(Boolean).join(' · '), res.undo ? { undo: () => L.undoLast(res.undo.id) } : null);
      U.list = after.review.length ? 'review' : after.waiting.length ? 'todo' : 'done';
      redraw();
    } });
  }
  // The rooms a household takes starting at a room: it and the free ones beside it (need: how many).
  function runAt(x, id, need) {
    const r = L.room(id), t = L.taken(x.rid);
    if (!r || t[id] || !L.usable(id)) return null;
    const f = S.floors.find(y => y.rooms.indexOf(r) > -1), run = [r];
    need = Math.max(1, need || x.asked || 1);
    if (f && need > 1) {
      const i = f.rooms.indexOf(r);
      for (let k = i + 1; k < f.rooms.length && run.length < need && !f.rooms[k].gap && !t[f.rooms[k].id] && L.usable(f.rooms[k].id); k++) run.push(f.rooms[k]);
      for (let k = i - 1; k >= 0 && run.length < need && !f.rooms[k + 1].gap && !t[f.rooms[k].id] && L.usable(f.rooms[k].id); k--) run.unshift(f.rooms[k]);
    }
    return run.map(y => y.id);
  }
  // A household onto a room (a tap with it chosen, or a drop): placed there, or moved there whole.
  function placeAt(x, id) {
    if (!x || !x.active || !L.room(id)) return;
    const t = L.taken(x.rid), owner = t[id];
    if (owner === 'yf') { A.toast(L.roomWords(id) + ' · Young Folks'); return; }
    if (L.fact(id).out) { A.toast(L.roomWords(id) + ' · Out of service'); return; }
    if (owner) {
      const o = L.byRid(owner), mine = L.given(x), theirs = L.given(o);
      if (!mine.length) { A.toast(L.roomWords(id) + ' is taken · ' + o.label); return; }
      // A swap only when both hold the same number of rooms (polish: a family of nine ended in one room).
      if (mine.length !== theirs.length) { A.toast(o.sur + ' has ' + plural(theirs.length, 'room') + ' · Move instead'); return; }
      L.save([{ key: 'hh:' + x.rid, data: Object.assign({}, L.hrow(x), { rooms: theirs }) }, { key: 'hh:' + o.rid, data: Object.assign({}, L.hrow(o), { rooms: mine }) }],
        { label: 'Swapped · ' + x.sur + ' ' + L.roomsWords(theirs) + ' · ' + o.sur + ' ' + L.roomsWords(mine) });
      return;
    }
    const g = L.given(x);
    const run = runAt(x, id, g.length || x.asked);
    if (!run) return;
    const short = run.length < (g.length || x.asked);
    setRooms(x, run, x.sur + ' · ' + L.roomsWords(run) + (short ? ' · Short ' + plural((g.length || x.asked) - run.length, 'room') : ''));
  }
  // A room tapped on the plan.
  function tapRoom(id) {
    const r = L.room(id);
    if (!r) return;
    U.focusRoom = id;
    const x = U.sel && L.byRid(U.sel), owner = L.taken()[id];
    if (owner === 'yf') { A.toast(L.roomWords(id) + ' · Young Folks'); return; }
    if (x && x.active && !L.ro && !A.readonly) {
      const g = L.given(x);
      if (g.indexOf(id) > -1) { setRooms(x, g.filter(y => y !== id), x.sur + ' · ' + L.roomWords(id) + ' freed'); return; }
      if (owner && owner !== x.rid && !g.length) { pick(owner); return; }
      placeAt(x, id);
      return;
    }
    if (owner) { pick(owner); return; }
    U.room = U.room === id ? '' : id; U.sel = ''; U.side = '';
    A.setParams({ id: '' });
    redraw();
  }

  /* ================================================================ publish */

  function openPublish(mode) { U.side = 'pub:' + mode; U.room = ''; redraw(); }
  function publishPanel(mode, t) {
    const names = t.pubChanged.map(L.byRid).filter(Boolean);
    const left = [t.waiting.length ? t.waiting.length + ' unassigned' : '', t.review.length ? t.review.length + ' to review' : ''].filter(Boolean);
    const n = Object.keys(L.assign()).length, shown = t.pub ? Object.keys(t.pub.snap || {}).length : 0;
    const forms = Object.keys(L.assign()).map(L.byRid).filter(x => x && x.source === 'form').length;
    const title = mode === 'update' ? 'Send update' : mode === 'unpublish' ? 'Unpublish' : 'Publish rooms';
    const email = h('input', { type: 'checkbox', class: 'ap-check', checked: mode !== 'unpublish' });
    const was = rid => { const s = t.pub && t.pub.snap && t.pub.snap[rid]; return s && s.length ? L.roomsWords(s) : 'No rooms'; };
    const go = A.btn(mode === 'unpublish' ? 'Unpublish' : left.length ? (mode === 'update' ? 'Send anyway' : 'Publish anyway') : title, { primary: mode !== 'unpublish', danger: mode === 'unpublish', write: true, onClick: () => {
      go.disabled = true;
      L.api('POST', '/publish', { mode, email: mode !== 'unpublish' && email.checked }).then(res => {
        S.rows['meta:published'] = { data: res.published, v: 0, by: S.me, at: '' };
        U.side = '';
        A.toast(mode === 'unpublish' ? 'Unpublished · Households no longer see rooms' : (mode === 'update' ? 'Update sent · ' : 'Published · ') + plural(res.changed || 0, 'household') + (res.notified ? ' · ' + res.notified + ' emailed' : ''));
        L.refresh(true);
      }, err => { go.disabled = false; A.toast((err.data && err.data.message) || 'Not published'); });
    } });
    return h('section', { class: 'cm-panel', 'aria-labelledby': 'cm-pub-h' },
      h('h2', { class: 'cm-panel__h', id: 'cm-pub-h', text: title }),
      mode === 'unpublish' ? h('p', { text: plural(shown, 'household') + ' stop seeing their rooms' })
        : mode === 'update' ? [h('p', { text: plural(names.length, 'household') + ' · changed since ' + L.md(t.pub.date) }),
          h('ul', { class: 'cm-plain' }, names.slice(0, 12).map(x => h('li', null, h('b', { text: x.sur }), ' · ' + was(x.rid) + ' → ' + (L.given(x).length && x.active ? L.roomsWords(L.given(x)) : x.gone ? 'Cancelled' : 'No rooms'))), names.length > 12 ? h('li', { class: 'ap-quiet', text: (names.length - 12) + ' more' }) : null)]
          : [h('p', { text: plural(n, 'household') + ' · Rooms in Your sign-ups' }), forms ? h('p', { class: 'ap-help', text: plural(forms, 'household') + ' from the Form see theirs when they sign in with the email they used, or at the desk' }) : null],
      mode !== 'unpublish' && left.length ? h('p', { class: 'cm-warn', text: left.join(' · ') }) : null,
      mode !== 'unpublish' ? h('label', { class: 'ap-switch' }, email, mode === 'update' ? 'Email them · Your rooms changed' : 'Email them · Your rooms are posted') : null,
      h('div', { class: 'ap-row cm-panel__btns' }, go, A.btn('Cancel', { ghost: true, onClick: () => { U.side = ''; redraw(); } })));
  }

  /* ================================================================ the chosen household */

  function detail(x, t) {
    const g = L.given(x), rv = L.issues(x), ch = L.changes(x), sug = null /* docs/25: no suggested room */, row = L.hrow(x);
    const tags = L.tagsOf(x), okd = row.ok && row.ok.sig === L.sig(rv), quiet = L.quiet(x);
    const ro = L.ro || A.readonly;
    const acts = [];
    if (x.active && !L.ro && g.length) acts.push(A.btn('Unassign', { ghost: true, write: true, onClick: () => setRooms(x, null) }));
    // Change (Round 5): the household's own form, for a household, back here with it open.
    if (!x.gone && x.id) acts.push(A.btn('Change', { ghost: true, write: true, href: L.changeHref(x), title: 'Their registration form · Save comes back here' }));
    // "Near the Millers" fits several households: which one, once, as pills.
    const cands = []; // docs/25: "near" requests stay in the note; nothing matches names
    const people = h('ul', { class: 'cm-people' }, x.people.map(p => {
      const k = x.kind(p), bits = [];
      if (k === 'child' && p.age) bits.push('Age ' + p.age);
      if (k === 'yf') bits.push('Young Folk' + (x.inHall(p) ? ' · ' + (p.yfHall === 'women' ? 'young women’s hall' : p.yfHall === 'men' ? 'young men’s hall' : 'hall not set') : ''));
      if (p.band === 'baby') bits.push('Baby');
      const ns = L.someNights(p.nights && p.nights.length ? p.nights : null);
      if (ns) bits.push(ns);
      if (g.length > 1 && p.room != null && !x.inHall(p) && p.band !== 'baby') bits.push(L.roomWords(g[Math.min(p.room, g.length - 1)]));
      return h('li', null, h('span', { text: p.name }), bits.length ? h('small', { text: bits.join(' · ') }) : null);
    }));
    const keys = x.active ? L.keysOf(x).map((n, i) => (g.length > 1 || x.asked > 1 ? (g[i] ? L.roomWords(g[i]) : 'Room ' + (i + 1)) + ' · ' : '') + n).join(' · ') : '';
    const bal = L.payWords(x);
    const note = h('textarea', { class: 'ap-textarea', rows: '2', maxlength: '500', placeholder: 'Add note', value: row.note || '', disabled: ro, 'aria-label': 'Lodging’s note', title: 'For Lodging only; cleared with the names', 'data-k': 'note:' + x.rid });
    note.addEventListener('change', () => { const v = note.value.trim(); if ((row.note || '') !== v) L.hhSave(x, { note: v || null }, { label: x.sur + ' · Note saved' }); });
    const hist = (x.d.history || []).slice().reverse().map(y => L.md(y.at) + ' · ' + y.what).concat(row.given ? [L.md(row.given.at) + ' · Rooms given · ' + row.given.by] : []);
    const more = h('details', { class: 'cm-fold', open: !!U.moreOpen }, h('summary', { text: 'More' }),
      h('dl', { class: 'ap-facts' },
        h('dt', { text: 'Coming' }), h('dd', null, people),
        keys ? [h('dt', { text: 'Keys' }), h('dd', { text: keys })] : null,
        x.linens || x.mattresses ? [h('dt', { text: 'Bedding' }), h('dd', { text: K.facts([x.linens ? plural(x.linens, 'linen packet') : '', x.mattresses ? plural(x.mattresses, 'air mattress', 'air mattresses') : '']) })] : null,
        h('dt', { text: 'Contact' }), h('dd', null, (x.d.household && x.d.household.contact) || '', x.phone ? [' · ', K.phone(x.phone)] : null),
        h('dt', { text: 'Registered' }), h('dd', { text: K.facts([L.md(x.at), x.source === 'form' ? 'Form' : x.source === 'desk' ? 'Desk' : 'Online', x.rid]) }),
        bal ? [h('dt', { text: 'Payment' }), h('dd', { text: bal })] : null,
        h('dt', { text: 'Note' }), h('dd', null, note),
        hist.length ? [h('dt', { text: 'History' }), h('dd', null, h('ul', { class: 'cm-plain cm-small' }, hist.slice(0, 8).map(y => h('li', { text: y }))))] : null));
    more.addEventListener('toggle', () => { U.moreOpen = more.open; });
    return h('section', { class: 'cm-panel cm-detail', 'aria-labelledby': 'cm-dh' },
      h('div', { class: 'cm-panel__top' },
        h('h2', { class: 'cm-panel__h', id: 'cm-dh' }, h('b', { text: x.sur }), x.firsts ? ' · ' + x.firsts : ''),
        A.btn('Close', { ghost: true, iconOnly: true, icon: 'x', onClick: () => pick(x.rid) })),
      h('p', { class: 'cm-detail__m', text: K.facts([L.where(x)].concat(L.metaList(x))) }),
      tags.length ? h('p', { class: 'cm-tags' }, tags.map(g2 => chip(g2))) : null,
      x.note ? h('blockquote', { class: 'cm-quote' }, h('span', { class: 'ap-label', text: 'Note for Lodging' }), h('span', { text: x.note })) : null,
      // What's wrong, each with its reason in words (polish: reasons sat only in hover titles).
      rv.length && !L.ro ? h('ul', { class: 'cm-issues' + (okd ? ' is-ok' : '') }, rv.map(i => h('li', null, h('b', { text: i.text }), i.title ? h('span', { text: i.title }) : null))) : null,
      rv.length && !L.ro ? (okd ? h('p', { class: 'ap-quiet', text: 'Looks right · ' + row.ok.by }) : h('div', { class: 'ap-row cm-fixes' }, fixButtons(x, rv), A.btn('Looks right', { write: true, onClick: () => looksRight(x) }))) : null,
      cands.length && !ro ? h('div', { class: 'ap-field cm-which' }, h('span', { text: 'Which ' + (cands[0].sur + (/s$/.test(cands[0].sur) ? 'es' : 's')) + '?' }),
        h('div', { class: 'ap-pills' }, cands.slice(0, 5).map(c => h('button', { type: 'button', class: 'ap-pill', on: { click: () => L.hhSave(x, { near: c.rid }, { label: x.sur + ' · Near ' + c.sur + (c.firsts ? ' · ' + c.firsts : '') }) } }, c.firsts ? c.firsts + ' ' + c.sur : c.sur, h('small', { class: 'ap-quiet', text: ' · ' + L.where(c) }))))) : null,
      ch.length && !L.ro ? [h('ul', { class: 'cm-issues cm-issues--change' }, ch.map(c => h('li', null, h('b', { text: c.text })))), h('div', { class: 'ap-row cm-fixes' }, ch.some(c => c.free) ? A.btn('Free ' + L.roomsWords(g), { write: true, onClick: () => setRooms(x, null, x.sur + ' · ' + L.roomsWords(g) + ' freed') }) : null, A.btn('Looks right', { write: true, onClick: () => looksRight(x) }))] : null,
      quiet.length ? h('p', { class: 'ap-quiet', text: quiet.join(' · ') }) : null,
      x.active && !L.ro ? fitsPart(x) : null,
      acts.length ? h('div', { class: 'ap-row cm-acts' }, acts) : null,
      sug ? h('p', { class: 'ap-quiet', text: sugWords(sug, x) }) : null,
      more);
  }
  /* ================================================================ free rooms that fit (Round 5) */

  /*
   * Free rooms that fit (area-lodging 1.4, 5.4): for the household's next room, the rooms on the plain
   * room list (rooms.csv, Lodging's facts) that hold it, from fields only: for families; not held, out of
   * service or taken; beds + 1 at least the people sleeping in that room (under 3 not counted); on the
   * ground floor when its Ground floor box is ticked; step-free when No stairs is. Never its note
   * (docs/25). Ordered, never ranked: the room sharing a bath with the one just placed, then that floor,
   * then hall, floor and number. No floor plan needed.
   */
  function fitsOf(x) {
    const g = L.given(x), n = Math.max(1, x.asked || 1), i = g.length;
    if (i >= n) return null;
    const sleep = x.inRooms.filter(p => p.band !== 'baby' && (p.room == null ? 0 : Math.min(+p.room, n - 1)) === i).length;
    const st = (x.d && x.d.stay) || {}, ground = !!st.ground, stairs = !!st.walker;
    const t = L.taken(x.rid);
    const free = S.rooms.filter(r => r.for === 'families' && !t[r.id] && g.indexOf(r.id) < 0 && L.usable(r.id));
    const why = r => [L.beds(r.id) + 1 < sleep ? plural(sleep - L.beds(r.id) - 1, 'bed') + ' short' : '', ground && r.floor !== 1 ? 'Floor ' + r.floor : '', stairs && !ground && !L.stepFree(r) ? 'Stairs' : ''].filter(Boolean).join(' · ');
    const last = g.length ? L.room(g[g.length - 1]) : null;
    const near = r => !last ? 2 : L.bathMate(last.id) === r.id ? 0 : r.hall === last.hall && r.floor === last.floor ? 1 : 2;
    const order = (a, b) => near(a) - near(b) || a.hall.localeCompare(b.hall) || a.floor - b.floor || a.num - b.num;
    return { i, n, sleep, ground, stairs, last, near, why, fit: free.filter(r => !why(r)).sort(order), all: free.slice().sort(order) };
  }
  const fitWords = (r, F) => [L.roomWords(r.id), r.floor === 1 ? 'Ground' : 'Floor ' + r.floor, plural(L.beds(r.id), 'bed'), r.floor !== 1 && L.fact(r.id).access ? 'Step-free' : '', F.last && F.near(r) === 0 ? 'Shares bath with ' + F.last.num : ''].filter(Boolean).join(' · ');
  function fitsPart(x) {
    const F = fitsOf(x);
    if (!F) return null;
    const waiting = x.status === 'waitlist', showAll = U.fitsAll === x.rid;
    const list = showAll ? F.all : F.fit, max = U.fitsMore === x.rid ? list.length : 6;
    const ro = L.ro || A.readonly;
    const room = F.n > 1 ? 'Room ' + (F.i + 1) + ' of ' + F.n + ' · ' : '';
    const asks = [F.ground ? 'Ground floor' : '', F.stairs ? 'No stairs' : ''].filter(Boolean).join(' · ');
    const rows = list.slice(0, max).map((r, k) => {
      const w = showAll ? F.why(r) : '';
      return h('li', { class: 'cm-fit' }, h('span', { class: 'cm-fit__w' }, h('b', { text: fitWords(r, F) }), w ? h('small', { class: 'cm-fit__no', text: w }) : null),
        waiting ? null : A.btn('Place', { primary: k === 0 && !w && !ro, ghost: k > 0 || !!w, write: true, title: 'Gives ' + L.roomWords(r.id) + ' to the ' + x.sur + 's', onClick: () => placeIn(x, r, F) }));
    });
    return h('section', { class: 'cm-fits', 'aria-labelledby': 'cm-fits-h' },
      h('h3', { class: 'ap-label cm-sub', id: 'cm-fits-h', text: (waiting ? 'Waiting · ' : '') + (showAll ? 'Free rooms · ' + F.all.length : 'Free rooms that fit · ' + F.fit.length) }),
      h('p', { class: 'ap-quiet cm-fits__for', text: room + plural(F.sleep, 'sleeping', 'sleeping') + (asks ? ' · ' + asks : '') }),
      waiting ? h('p', { class: 'ap-help', text: 'On the waiting list · Offer the place first' }) : null,
      rows.length ? h('ul', { class: 'cm-fits__list' }, rows) : h('p', { class: 'cm-fits__none', text: 'No free room fits' }),
      h('p', { class: 'cm-fits__more' },
        list.length > max ? h('button', { type: 'button', class: 'ap-link', text: 'Show ' + (list.length - max) + ' more', on: { click: () => { U.fitsMore = x.rid; redraw(); } } }) : null,
        list.length > max && F.all.length > F.fit.length ? ' · ' : null,
        F.all.length > F.fit.length || showAll ? h('button', { type: 'button', class: 'ap-link', text: showAll ? 'Only rooms that fit' : 'Show all free rooms', on: { click: () => { U.fitsAll = showAll ? '' : x.rid; U.fitsMore = ''; redraw(); } } }) : null));
  }
  // Place: this room for the household's next room; once every room it asked for is placed, the next
  // household to place opens (area-lodging 2.2).
  function placeIn(x, r, F) {
    const ids = L.given(x).concat(r.id), whole = ids.length >= F.n;
    const todo = whole && U.list === 'todo' ? listOf(tally(), 'todo') : [], at = todo.findIndex(y => y.rid === x.rid);
    const nx = todo[at + 1] || todo.find(y => y.rid !== x.rid) || null;
    L.hhSave(x, { rooms: ids }, {
      label: x.sur + ' · ' + (F.n > 1 ? 'Room ' + ids.length + ' → ' : '') + L.roomWords(r.id) + (nx ? ' · Next · ' + nx.sur : ''),
      done: () => { U.fitsAll = ''; U.fitsMore = ''; if (nx) { U.sel = nx.rid; U.followed = ''; A.setParams({ id: nx.rid }); } }
    });
  }

  function sugWords(ids, x) {
    const rs = ids.map(L.room).filter(Boolean), out = [];
    if (rs.every(L.stepFree)) out.push('Ground floor');
    if (rs.length === 1) { const m = L.bathMate(rs[0].id), w = m && L.taken(x.rid)[m]; if (w && L.byRid(w)) out.push('Shares a bath with ' + L.byRid(w).sur); }
    else if (rs.length === 2 && L.bathMate(rs[0].id) === rs[1].id) out.push('Their own bath');
    return out.join(' · ');
  }

  /* ================================================================ a free room, no one chosen */

  function roomPanel(id, t) {
    const r = L.room(id);
    if (!r || L.taken()[id]) return null;
    const f = L.fact(id), ro = L.ro || A.readonly;
    const fl = S.plans[r.hall] && S.plans[r.hall].floors[r.floor], sh = fl && fl.rooms.find(s => s.label === String(r.num));
    const near = sh && O.map ? O.map.near(fl, sh) : [];
    const mate = L.bathMate(id), mateFree = mate && !L.taken()[mate] && L.usable(mate);
    const fits = t.waiting.map(x => {
      let sc = 0;
      if (L.stepFree(r)) sc += L.firstGroup(x) ? 50 : -20; else sc += L.firstGroup(x) ? -60 : 0;
      if (x.asked === 1) sc += 10; else if (x.asked === 2 && mateFree) sc += 12; else sc -= 30;
      return { x, sc };
    }).sort((a, b) => b.sc - a.sc);
    const giveList = h('ul', { class: 'cm-give' });
    const drawGive = q => {
      q = (q || '').trim().toLowerCase();
      const list = q ? fits.filter(y => y.x.label.toLowerCase().indexOf(q) > -1 || y.x.people.some(p => p.name.toLowerCase().indexOf(q) > -1)) : fits.slice(0, 5);
      A.clear(giveList).append(...(list.length ? list.map(y => {
        const both = y.x.asked === 2 && mateFree;
        return h('li', null, h('button', { type: 'button', on: { click: () => { U.room = ''; setRooms(y.x, both ? [id, mate] : [id]); } } },
          h('span', null, h('b', { text: y.x.sur }), y.x.firsts ? ' · ' + y.x.firsts : ''), h('small', { text: K.facts([L.metaOf(y.x), both ? 'Gets ' + r.num + ' and ' + L.room(mate).num : '', L.firstGroup(y.x) ? 'Ground floor asked' : '']) })));
      }) : [h('li', { class: 'cm-none', text: t.waiting.length ? 'No matches' : 'Everyone has rooms' })]));
    };
    drawGive('');
    const hold = h('input', { class: 'ap-input', maxlength: '30', value: f.hold || '', placeholder: 'COA, speakers, walk-ins', disabled: ro, 'aria-label': 'Hold for', title: 'Kept back: Assign all leaves it free' });
    hold.addEventListener('change', () => { const d = Object.assign({}, L.data('room:' + id) || {}), v = hold.value.trim(); if ((d.hold || '') === v) return; if (v) d.hold = v; else delete d.hold; L.save([{ key: 'room:' + id, data: Object.keys(d).length ? d : null }], { label: L.roomWords(id) + (v ? ' · Kept · ' + v : ' · Not kept') }); });
    const tog = (k, label) => h('label', { class: 'ap-switch' }, h('input', { type: 'checkbox', checked: !!f[k], disabled: ro, on: { change: e => { const d = Object.assign({}, L.data('room:' + id) || {}); if (e.target.checked) d[k] = true; else delete d[k]; L.save([{ key: 'room:' + id, data: Object.keys(d).length ? d : null }], { label: L.roomWords(id) + (e.target.checked ? ' · ' : ' · Not ') + label.toLowerCase() }); } } }), label);
    const beds = n => { const d = Object.assign({}, L.data('room:' + id) || {}), b = Math.max(1, Math.min(8, L.beds(id) + n)); d.beds = b; L.save([{ key: 'room:' + id, data: d }], { label: L.roomWords(id) + ' · ' + plural(b, 'bed') }); };
    return h('section', { class: 'cm-panel', 'aria-labelledby': 'cm-rh' },
      h('div', { class: 'cm-panel__top' }, h('h2', { class: 'cm-panel__h', id: 'cm-rh' }, 'Room ' + r.num, ' ', chip(f.out ? 'Out of service' : f.hold ? 'Kept · ' + f.hold : 'Free', f.out ? 'warn' : 'tan')),
        A.btn('Close', { ghost: true, iconOnly: true, icon: 'x', onClick: () => { U.room = ''; redraw(); } })),
      h('p', { class: 'cm-detail__m', text: K.facts([r.hall, L.floorName(r.floor)].concat(near)) }),
      !f.out && !ro ? [h('h3', { class: 'ap-label cm-sub', text: 'Give to' }), t.waiting.length > 5 ? K.find({ placeholder: 'Search households', onInput: drawGive }) : null, giveList] : null,
      h('details', { class: 'cm-fold', open: !!U.factsOpen, on: { toggle: e => { U.factsOpen = e.target.open; } } }, h('summary', { text: 'This room' }),
        h('label', { class: 'ap-field' }, h('span', { text: 'Hold for' }), hold),
        h('div', { class: 'ap-row' }, tog('out', 'Out of service'), tog('access', 'Accessible')),
        h('div', { class: 'ap-row cm-beds' }, h('span', { text: 'Beds' }), K.iconBtn('Fewer beds', 'minus', () => beds(-1), { write: true }), h('b', { text: String(L.beds(id)) }), K.iconBtn('More beds', 'plus', () => beds(1), { write: true }))));
  }

  /* ================================================================ the plan */

  const planHalls = () => Array.from(new Set(L.familyFloors().map(f => f.hall))).filter(x => S.plans[x] && S.plans[x].list.length);
  const MIN_K = 2;   // px a foot: a 16 ft room's number stays at 11 px or more
  function plan(x) {
    const halls = planHalls();
    if (!halls.length || !O.map) return null;
    const g = x ? L.given(x) : [], sug = []; // no suggested rooms on the plan (docs/25)
    const at = L.room(g[0] || sug[0]);
    if (at && U.followed !== (x && x.rid)) { U.hall = at.hall; U.floor = at.floor; U.followed = x && x.rid; }
    const hall = halls.indexOf(U.hall) > -1 ? U.hall : halls[0], P = S.plans[hall];
    const fl = P.list.find(y => y.floor === U.floor) || P.list[0];
    U.hall = hall; U.floor = fl.floor;
    const t = L.taken(x ? x.rid : null), partner = x && L.nearOf(x), pr = partner ? L.given(partner) : [];
    const freeIn = rooms => rooms.filter(r => L.room(r.id) && !t[r.id] && g.indexOf(r.id) < 0 && L.usable(r.id)).length;
    const freeWords = n => n ? n + ' free' : 'Full';
    const st = r => {
      if (g.indexOf(r.id) > -1) return 'sel';
      if (!L.room(r.id)) return 'off';
      const f = L.fact(r.id);
      if (f.out) return 'off';
      if (t[r.id]) return pr.indexOf(r.id) > -1 ? 'other' : 'taken';
      if (sug.indexOf(r.id) > -1) return 'sug';
      if (f.hold) return 'held';
      if (U.room === r.id) return 'sug';
      return 'free';
    };
    const label = (r, s) => {
      const w = t[r.id], y = w && L.byRid(w);
      return 'Room ' + r.label + ', ' + ({ sel: 'given to ' + (x ? x.label : ''), off: L.fact(r.id).out ? 'out of service' : 'not ours', taken: y ? y.label + (y.walker ? ' · step-free' : L.older(y) ? ' · older' : '') : 'Young Folks', other: (y ? y.label : '') + ', near request', sug: 'suggested', held: 'kept · ' + L.fact(r.id).hold, free: 'free' })[s];
    };
    // Names in the rooms where they fit at 11.5 px (fitText steps down to the surname, then nothing).
    const tag = r => { const w = t[r.id], y = w && w !== 'yf' && L.byRid(w); return y ? y.short : w === 'yf' ? 'Young Folks' : ''; };
    const minutes = y => { const m = L.hallRank(y); return m < 99 ? ' · ' + m + ' min to dining' : ''; };
    const box = h('div', { class: 'cm-plan' + (narrow() || U.band ? ' is-band' : ''), 'data-hallplan': hall });
    // The map module draws the floor (its own escaping: ogc-map.js esc on every label and title).
    box.innerHTML = O.map.floorSvg(fl, { state: st, label, tag, pick: !L.ro && !A.readonly, pickAll: true, turn: O.map.turnFor(fl, narrow() || U.band), narrow: narrow() || U.band, beds: r => L.beds(r.id), title: hall + ', ' + L.floorName(fl.floor), sampleHref: '' });
    const states = {};
    fl.rooms.forEach(r => { states[st(r)] = 1; });
    const legend = Object.keys(states).length < 2 ? null : h('ul', { class: 'pl-legend cm-legend', 'aria-hidden': 'true' }, [['free', 'Free'], ['taken', 'Taken'], ['sel', x ? x.sur : 'Chosen'], ['sug', U.room && !x ? 'Chosen' : 'Suggested'], ['other', 'Near request'], ['held', 'Kept'], ['off', 'Out of service']].filter(y => states[y[0]]).map(y => h('li', null, h('i', { class: 'is-' + y[0] }), y[1])));
    // On this floor: room · household, a tap chooses the household (no hover needed to read the floor).
    const onFloor = fl.rooms.map(r => ({ r, w: t[r.id] })).filter(y => y.w && y.w !== 'yf' && L.byRid(y.w));
    const byHh = [];
    onFloor.forEach(y => { const last = byHh[byHh.length - 1]; if (last && last.w === y.w) last.rooms.push(y.r); else byHh.push({ w: y.w, rooms: [y.r] }); });
    const list = byHh.length ? h('details', { class: 'cm-fold cm-onfloor', open: U.floorOpen !== false, on: { toggle: e => { U.floorOpen = e.target.open; } } },
      h('summary', { text: 'On this floor · ' + byHh.length }),
      h('ul', { class: 'cm-onfloor__list' }, byHh.map(y => { const z = L.byRid(y.w); return h('li', null, h('button', { type: 'button', on: { click: () => pick(z.rid) } }, h('b', { text: y.rooms.map(r => r.label).join(', ') }), h('span', { text: z.label }))); }))) : null;
    return h('section', { class: 'cm-planbox', 'aria-label': 'Floor plan' },
      halls.length > 1 ? h('div', { class: 'cm-tabs', role: 'group', 'aria-label': 'Hall' }, halls.map(y => h('button', { type: 'button', 'aria-pressed': String(y === hall), on: { click: () => { U.hall = y; U.floor = 0; U.followed = U.sel; U.focusRoom = ''; redraw(); } } },
        L.hallShort(y), h('small', { text: freeWords(freeIn([].concat.apply([], S.plans[y].list.map(f => f.rooms)))) + minutes(y) })))) : null,
      h('div', { class: 'cm-planhead' },
        h('div', { class: 'cm-tabs cm-tabs--floors', role: 'group', 'aria-label': 'Floor' }, P.list.map(f => {
          const here = x && g.concat(sug).some(id => L.room(id) && L.room(id).hall === hall && L.room(id).floor === f.floor);
          return h('button', { type: 'button', 'aria-pressed': String(f.floor === fl.floor), on: { click: () => { U.floor = f.floor; U.followed = U.sel; U.focusRoom = ''; redraw(); } } }, f.floor === 1 ? 'Ground' : L.floorName(f.floor).replace(' floor', ''), h('small', { text: freeWords(freeIn(f.rooms)) + (here ? ' · ' + x.sur : '') }));
        })),
        narrow() ? null : h('div', { class: 'cm-zoom', role: 'group', 'aria-label': 'Zoom' }, K.iconBtn('Zoom out', 'minus', () => { U.zoom = Math.max(-2, U.zoom - 1); sizePlan(); }), K.iconBtn('Zoom in', 'plus', () => { U.zoom = Math.min(4, U.zoom + 1); sizePlan(); }))),
      box, legend, list);
  }
  function sizePlan() {
    const box = document.querySelector('.cm-plan');
    if (!box) return;
    const P = S.plans[box.dataset.hallplan];
    if (!P) return;
    const avail = box.clientWidth - 20, zoom = Math.pow(1.25, U.zoom || 0);
    if (!narrow()) {
      const widest = Math.max.apply(null, P.list.map(f => (O.map.turnFor(f, false) ? f.bounds.h : f.bounds.w))) + 12;
      const fits = avail / widest >= MIN_K;
      if (fits === !!U.band) { U.band = !fits; redraw(); return; }
    }
    box.querySelectorAll('svg.pl-floor').forEach(s => {
      const vb = s.viewBox.baseVal;
      const k = Math.max(narrow() ? 3.2 : MIN_K, Math.min(7, avail / vb.width)) * zoom;
      s.style.width = Math.round(vb.width * k) + 'px'; s.style.maxWidth = 'none';
    });
    const rooms = Array.from(box.querySelectorAll('[data-room][role="button"]'));
    const x = U.sel && L.byRid(U.sel), first = x && L.given(x)[0];
    rooms.forEach(g => g.setAttribute('tabindex', '-1'));
    const on = rooms.find(g => g.dataset.room === (U.focusRoom || first)) || rooms[0];
    if (on) on.setAttribute('tabindex', '0');
    if (first || U.focusRoom) O.map.reveal(box, U.focusRoom || first);
  }

  /* ================================================================ recent changes */

  function recent() {
    const list = (S.undo || []).slice(0, 12);
    if (!list.length || L.ro) return null;
    return h('details', { class: 'cm-fold cm-recent', open: !!U.recentOpen, on: { toggle: e => { U.recentOpen = e.target.open; } } },
      h('summary', { text: 'Recent changes · ' + list.length }),
      h('ul', { class: 'cm-plain cm-recent__list' }, list.map(u => h('li', null, h('span', null, h('b', { text: u.by || 'Someone' }), ' · ' + (u.label || 'Change')), h('small', { class: 'ap-quiet', text: L.when(u.at) }),
        h('button', { type: 'button', class: 'ap-link', disabled: A.readonly, title: A.readonly ? 'Read only while seeing as' : null, text: 'Undo', on: { click: () => L.undoLast(u.id) } })))));
  }

  /* ================================================================ export */

  // The rooming list for the campus: the same list as Counts' (Round 5; key holders only).
  function roomingCsv() {
    const R = L.roomingRows(), rows = [R.head].concat(R.rows);
    K.download(rows, (S.settings.venue || 'Campus') + ' rooming list ' + S.year + ' ' + L.stamp() + '.csv');
    L.api('POST', '/log', { what: 'export', list: 'rooming', rows: rows.length - 1 }).catch(() => {});
    A.toast('Rooming list · ' + plural(rows.length - 1, 'room'));
  }

  /* ================================================================ the screen */

  let C = null;   // the screen's ctx while it's open
  function redraw() { if (C) draw(C); }

  function draw(ctx) {
    const sx = window.scrollY, act = document.activeElement, k = act && act.getAttribute && act.getAttribute('data-k');
    const side0 = document.querySelector('.cm-board__side'), list0 = document.querySelector('.cm-board__list');
    const sTop = side0 ? side0.scrollTop : 0, lTop = list0 ? list0.scrollTop : 0;
    const typing = act && act.matches && act.matches('input[type="search"], textarea, input[type="text"]') ? { v: act.value, s: act.selectionStart } : null;
    ctx.body.classList.add('ap-body--flush');
    A.clear(ctx.body);
    if (!L.familyFloors().length) {
      ctx.head('Rooms', '', []);
      ctx.body.appendChild(A.empty({ title: 'No dorm halls', line: 'The year’s halls are set on The Conference', inset: true }));
      return;
    }
    const t = tally();
    const asked = t.d.reduce((n, x) => n + x.asked, 0);
    if (!t.d.length) {
      const opens = S.cfg.opens && S.cfg.opens > (S.phase.today || '') ? 'Opens ' + O.fmtDate(S.cfg.opens, 'md') : '';
      const halls = Array.from(new Set(L.familyFloors().map(f => L.hallShort(f.hall))));
      ctx.head('Rooms', plural(t.rooms, 'family room') + ' in ' + halls.join(' and '), []);
      ctx.body.appendChild(A.empty({ title: S.hh.length ? 'No households in dorm rooms' : 'No registrations yet', line: S.hh.length ? '' : opens, inset: true,
        action: !L.ro && !A.readonly ? A.btn('Import from the Form', { icon: 'upload', onClick: () => A.go({ s: 'lod-import' }) }) : null }));
      return;
    }
    if (!U.list) U.list = t.waiting.length ? 'todo' : t.review.length ? 'review' : 'done';
    if (U.list === 'todo' && !t.waiting.length) U.list = t.review.length ? 'review' : 'done';
    if (ctx.params.id && !U.sel && L.byRid(ctx.params.id) && U.lastId !== ctx.params.id) { U.sel = ctx.params.id; }
    U.lastId = ctx.params.id;
    const p = primary(t), busy = U.sel || U.older || U.room || U.side;
    const pub = t.pub;
    // Never "0 of 8 assigned": what's left to place (said by the filled "Place · 48" when it's there), then
    // the rooms needed against the rooms held.
    const fact = K.facts([t.waiting.length ? (p ? '' : t.waiting.length + ' to place') : 'All ' + t.d.length + ' placed', plural(asked, 'room') + ' needed · ' + t.rooms + ' held' + (asked > t.rooms ? ' · Over' : ''),
      pub ? 'Published ' + L.md(pub.date) + (t.pubChanged.length ? ' · ' + t.pubChanged.length + ' changed' : '') : '']);
    const acts = [];
    if (p) acts.push(A.btn(p.t, { primary: !busy, write: true, title: p.tip, onClick: p.run }));
    if (t.given.length) acts.push(A.btn('Export', { icon: 'download', title: 'The rooming list for the campus: one line a room, with dates', onClick: roomingCsv }));
    const more = [];
    if (pub && !L.ro && !A.readonly) more.push({ label: 'Unpublish', run: () => openPublish('unpublish') });
    more.push({ label: 'Households', run: () => A.go({ s: 'lod-households', id: '' }) });
    acts.push(K.more('More', more, { ghost: true }));
    ctx.head('Rooms', fact, acts);
    // From Home's "Assign all · 8": the act itself, once (Undo in the toast).
    if (ctx.params.at === 'assign') {
      A.setParams({ at: '' });
      ctx.params.at = '';
      if (t.waiting.length && !L.ro && !A.readonly) setTimeout(placeNext, 0);
    }

    const top = h('div', { class: 'cm-top' }, L.ro || A.readonly ? null : steps(t), since(t),
      L.ro ? h('p', { class: 'ap-quiet', text: 'Conference over · Rooms no longer move' }) : null,
      A.readonly ? null : null);
    const side = h('div', { class: 'cm-board__side' });
    const x = U.sel && L.byRid(U.sel);
    // Reached from a household's Linked "Rooms · 2" (Round 3): the chip back to it ("← Hoovers").
    const chip = x && !U.side ? A.returnChip() : null;
    if (chip) side.appendChild(h('div', { class: 'cm-retchip' }, chip));
    if (U.side && U.side.indexOf('pub:') === 0) side.appendChild(publishPanel(U.side.slice(4), t));
    else if (x) side.appendChild(detail(x, t));
    else if (U.room) { const rp = roomPanel(U.room, t); if (rp) side.appendChild(rp); else U.room = ''; }
    const pl = plan(x);
    if (pl) side.appendChild(pl);
    const rc = recent();
    if (rc) side.appendChild(rc);
    const board = h('div', { class: 'cm-board' + (x || U.room || U.side ? ' has-sel' : '') }, listCol(t), side);
    ctx.body.append(top, board);
    if (narrow() && x) { const back = h('div', { class: 'cm-back' }, A.btn('Households', { ghost: true, icon: 'back', onClick: () => pick(x.rid) })); side.prepend(back); }
    requestAnimationFrame(sizePlan);
    // Put the place back: the window, the list and the side, the focused control and its caret.
    window.scrollTo(0, sx);
    const side1 = document.querySelector('.cm-board__side'), list1 = document.querySelector('.cm-board__list');
    if (side1) side1.scrollTop = sTop;
    if (list1) list1.scrollTop = lTop;
    if (k) { const b = ctx.body.querySelector('[data-k="' + CSS.escape(k) + '"]'); if (b) { b.focus({ preventScroll: true }); if (typing && b.setSelectionRange) { b.value = typing.v; try { b.setSelectionRange(typing.s, typing.s); } catch (e) { /* not text */ } } } }
  }

  function since(t) {
    if (!S.seen || L.ro) return null;
    const n = t.d.filter(isNew).length, c = t.changes.length;
    if (!n && !c) return null;
    // Every one waiting is new: "Place · 48" and the Unassigned chip already say it.
    if (!c && n === t.waiting.length) return null;
    return h('p', { class: 'cm-since' }, 'Since ' + L.since(S.seen) + ' · ',
      n ? h('button', { type: 'button', class: 'ap-link', text: n + ' new', on: { click: () => { U.list = 'todo'; U.find = ''; redraw(); } } }) : null, n && c ? ' · ' : null,
      c ? h('button', { type: 'button', class: 'ap-link', text: c + ' changed', on: { click: () => { U.list = 'review'; U.find = ''; redraw(); } } }) : null);
  }

  /* ================================================================ hands and keys */

  function bind(ctx) {
    const body = ctx.body;
    const onClick = e => {
      const g = e.target.closest && e.target.closest('.cm-plan [data-room]');
      if (g && !pdrag.moved) tapRoom(g.dataset.room);
    };
    const onKey = e => {
      const g = e.target.closest && e.target.closest('.cm-plan [data-room][role="button"]');
      if (g) {
        if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); tapRoom(g.dataset.room); return; }
        if (/^Arrow/.test(e.key)) {
          e.preventDefault();
          const all = Array.from(body.querySelectorAll('.cm-plan [data-room][role="button"]')), a = g.getBoundingClientRect();
          const dir = { ArrowRight: [1, 0], ArrowLeft: [-1, 0], ArrowDown: [0, 1], ArrowUp: [0, -1] }[e.key];
          let best = null, bd = Infinity;
          all.forEach(o => { if (o === g) return; const b = o.getBoundingClientRect(), dx = (b.left + b.width / 2) - (a.left + a.width / 2), dy = (b.top + b.height / 2) - (a.top + a.height / 2); const along = dx * dir[0] + dy * dir[1]; if (along <= 2) return; const d = along + Math.abs(dx * dir[1] + dy * dir[0]) * 2; if (d < bd) { bd = d; best = o; } });
          if (best) { g.setAttribute('tabindex', '-1'); best.setAttribute('tabindex', '0'); best.focus(); U.focusRoom = best.dataset.room; }
        }
      }
    };
    const onDoc = e => {
      if (!C || document.querySelector('.ap-palette')) return;
      const typing = e.target.matches && e.target.matches('input, textarea');
      if (e.key === 'Escape' && (U.sel || U.room || U.older || U.side)) { e.preventDefault(); const was = U.sel; U.sel = ''; U.room = ''; U.older = false; U.side = ''; A.setParams({ id: '' }); redraw(); const b = was && body.querySelector('[data-k="sel:' + CSS.escape(was) + '"]'); if (b) b.focus({ preventScroll: true }); return; }
      if (typing || e.metaKey || e.ctrlKey) return;
      if (e.key === '/') { const f = body.querySelector('[data-k="find"]'); if (f) { e.preventDefault(); f.focus(); } }
      else if (e.key === 'n' || e.key === 'N') { const l = tally().review; if (l.length) { const i = l.findIndex(y => y.rid === U.sel), n = l[(i + 1) % l.length]; U.list = 'review'; pick(n.rid, true); } }
    };
    // A household dragged from the list onto a room (laptop).
    const onDragStart = e => { const li = e.target.closest && e.target.closest('[data-drag]'); if (!li) return; e.dataTransfer.setData('text/x-lodging', li.dataset.drag); e.dataTransfer.effectAllowed = 'move'; U.drag = li.dataset.drag; body.classList.add('is-dragging'); };
    const clearDrop = () => body.querySelectorAll('.pl-room.is-drop').forEach(g => g.classList.remove('is-drop'));
    const onDragEnd = () => { body.classList.remove('is-dragging'); clearDrop(); U.drag = ''; };
    const onDragOver = e => {
      const g = e.target.closest && e.target.closest('.cm-plan [data-room]');
      if (!g || !U.drag) return;
      e.preventDefault(); e.dataTransfer.dropEffect = 'move';
      clearDrop();
      const x = L.byRid(U.drag), run = x && (L.taken(x.rid)[g.dataset.room] ? [g.dataset.room] : runAt(x, g.dataset.room, L.given(x).length || x.asked));
      (run || []).forEach(id => { const y = body.querySelector('.cm-plan [data-room="' + CSS.escape(id) + '"]'); if (y) y.classList.add('is-drop'); });
    };
    const onDrop = e => {
      const g = e.target.closest && e.target.closest('.cm-plan [data-room]');
      if (!g || !U.drag) return;
      e.preventDefault(); body.classList.remove('is-dragging'); clearDrop();
      const x = L.byRid(U.drag); U.drag = '';
      U.sel = x.rid; U.followed = ''; A.setParams({ id: x.rid });
      placeAt(x, g.dataset.room);
    };
    // A taken room dragged onto another: that household moves there (or swaps, same number of rooms).
    const pdrag = { on: null, moved: false };
    const onDown = e => {
      const g = e.target.closest && e.target.closest('.cm-plan .pl-room.is-taken, .cm-plan .pl-room.is-sel, .cm-plan .pl-room.is-other');
      pdrag.moved = false;
      if (!g || L.ro || A.readonly || narrow() || e.button !== 0 || e.pointerType === 'touch') return;
      const owner = L.taken()[g.dataset.room];
      if (!owner || owner === 'yf') return;
      pdrag.on = { rid: owner, from: g.dataset.room, x: e.clientX, y: e.clientY };
    };
    const onMove = e => {
      const d = pdrag.on;
      if (!d) return;
      if (!pdrag.moved && Math.hypot(e.clientX - d.x, e.clientY - d.y) < 8) return;
      pdrag.moved = true;
      body.classList.add('is-dragging'); clearDrop();
      const el = document.elementFromPoint(e.clientX, e.clientY), g = el && el.closest && el.closest('.cm-plan [data-room]');
      if (g) g.classList.add('is-drop');
    };
    const onUp = e => {
      const d = pdrag.on; pdrag.on = null;
      if (!d || !pdrag.moved) return;
      body.classList.remove('is-dragging'); clearDrop();
      const el = document.elementFromPoint(e.clientX, e.clientY), g = el && el.closest && el.closest('.cm-plan [data-room]');
      setTimeout(() => { pdrag.moved = false; }, 60);
      if (!g || g.dataset.room === d.from) return;
      const x = L.byRid(d.rid);
      U.sel = x.rid; U.followed = ''; A.setParams({ id: x.rid });
      placeAt(x, g.dataset.room);
    };
    let rsT = 0, wasNarrow = narrow();
    const onResize = () => { clearTimeout(rsT); rsT = setTimeout(() => { if (narrow() !== wasNarrow) { wasNarrow = narrow(); redraw(); } else sizePlan(); }, 120); };
    body.addEventListener('click', onClick);
    body.addEventListener('keydown', onKey);
    body.addEventListener('dragstart', onDragStart);
    body.addEventListener('dragend', onDragEnd);
    body.addEventListener('dragover', onDragOver);
    body.addEventListener('drop', onDrop);
    body.addEventListener('pointerdown', onDown);
    window.addEventListener('pointermove', onMove);
    window.addEventListener('pointerup', onUp);
    window.addEventListener('resize', onResize);
    document.addEventListener('keydown', onDoc);
    return () => {
      window.removeEventListener('pointermove', onMove);
      window.removeEventListener('pointerup', onUp);
      window.removeEventListener('resize', onResize);
      document.removeEventListener('keydown', onDoc);
      ctx.body.classList.remove('ap-body--flush');
    };
  }

  A.screen({
    id: 'lod-rooms', title: 'Rooms', icon: 'overview', section: 'own', who: ['lodging'],
    render(ctx) {
      C = ctx;
      U.sel = ctx.params.id && ctx.params.id !== U.sel ? ctx.params.id : U.sel;
      if (!ctx.params.id) U.sel = '';
      const off = L.screen(ctx, draw);
      const unbind = bind(ctx);
      return () => { C = null; off(); unbind(); };
    }
  });

  A.action({ id: 'lod-assign', title: 'Assign rooms', screen: 'lod-rooms', run: () => A.go({ s: 'lod-rooms', id: '' }) });
})();
