/*
 * Lodging › Counts (Round 5, Oct 17; docs/27-back-end-map/area-lodging §8): what the campus needs two
 * weeks before, on one screen, sent once with a kept copy.
 *
 *   Views        Counts (each night's rooms by hall, Youngfolks by hall, campers; the totals, never a
 *                zero) · Rooming list (one line a room, the key holder only) · Room setup (linens and
 *                mattresses a room, in walking order; the numbers change here).
 *   Mark sent    beside the list: to whom (Lodging's Contacts by role, or Other), what (Counts · Rooming
 *                list), the day. It keeps a copy of exactly what's drawn, emails no one, and ticks the task
 *                "Final counts and dorm keys"; Undo the same day.
 *   Sent         every send kept (at=sent): the day, who, to whom, what, what has changed since (a cell
 *                changed since the last send is marked on the screen too), Download as sent.
 * The COA's Final counts line on Home reads the newest send (module-lodging-counts.php ogc_lod_sent).
 */
(function () {
  'use strict';
  const A = window.OGC_APP, h = A.h, K = window.OGC_CK, O = window.OGC, L = O && O.lodging;
  if (!A || !K || !L) return;
  const S = L.S, SU = L.SU, plural = SU.plural;
  const VIEWS = [{ id: 'counts', label: 'Counts' }, { id: 'rooming', label: 'Rooming list' }, { id: 'setup', label: 'Room setup' }];
  const WHAT = { counts: 'Counts', rooming: 'Rooming list' };
  const ro = () => L.ro || !!A.readonly;
  const blank = v => (v === 0 || v === '0' || v == null ? '' : String(v));

  /* ================================================================ the lists, as drawn and as kept */

  // The rooming list (area-lodging 8.4; Q22 a: the key holder only, never everyone's names): one line a
  // room, its dates from the people sleeping in it. Rooms' Export is this same list.
  L.roomingRows = function () {
    const head = ['Hall', 'Floor', 'Room', 'Arrive', 'Depart', 'Guests', 'Key holder', 'Keys', 'Linen packets', 'Air mattresses', 'Ground floor', 'Step-free'];
    const rows = [], perPerson = S.cfg.keys_per === 'person', a = L.assign(), ord = SU.nightsOf(S.cfg);
    S.rooms.forEach(r => {
      const rid = Object.keys(a).find(k => a[k].indexOf(r.id) > -1), x = rid && L.byRid(rid);
      if (!x) return;
      const ids = a[rid], i = ids.indexOf(r.id), n = ids.length, share = v => Math.floor(v / n) + (i < v % n ? 1 : 0);
      const setup = (L.hrow(x).setup || {})[r.id], here = L.inRoom(x, i), sleep = here.filter(p => p.band !== 'baby').length;
      const ns = here.length ? Array.from(new Set([].concat.apply([], here.map(p => p.nights && p.nights.length ? p.nights : x.nights)))) : x.nights;
      const sorted = ns.slice().sort((p, q) => ord.indexOf(p) - ord.indexOf(q));
      rows.push([r.hall, r.floor, r.num, K.md(L.arrive(sorted)), K.md(L.depart(sorted)), here.length, L.keysOf(x)[i] || '', perPerson ? Math.max(1, sleep) : 1,
        setup ? setup.l : share(x.linens), setup ? setup.m : share(x.mattresses), r.floor === 1 ? 'Yes' : '', L.stepFree(r) ? 'Yes' : '']);
    });
    return { head, rows };
  };

  // The counts with the totals this screen says (area-lodging 8.3): rooms, Youngfolks, campers, linen
  // packets, air mattresses, keys.
  function countsNow() {
    const C = L.countsRows();
    const d = L.dorm(), yf = L.everyYf().length;
    const camp = S.hh.filter(x => x.type === 'camper' && !x.gone).reduce((k, x) => k + (+(x.d.stay && x.d.stay.campers) || 1), 0);
    const get = name => ((C.totals || []).find(t => t[0] === name) || [])[1] || 0;
    const totals = [['Rooms placed', get('Rooms given')], ['Youngfolks', yf], ['Campers', camp], ['Linen packets', get('Linen packets')], ['Air mattresses', get('Air mattresses')], ['Keys', get('Keys')]];
    const waitingHh = d.filter(x => !L.given(x).length && x.linens).length;
    return { head: C.head, rows: C.rows, totals, ln: C.ln, waitingHh };
  }
  function setupNow() {
    const rows = L.setupRows();
    return { rows, head: ['Hall', 'Floor', 'Room', 'Arrives', 'Linen packets', 'Air mattresses'], table: rows.map(y => [y.r.hall, y.r.floor, y.r.num, y.arrives ? SU.nightShort(y.arrives) : '', y.l, y.m]) };
  }

  // What has changed since a send: each night's cells (by column name) and each room (Hall · Room).
  function changedSince(send) {
    const out = { nights: 0, rooms: 0, cells: {}, roomKeys: {} };
    if (!send || !send.copy) return out;
    const was = send.copy.counts, now = countsNow();
    if (was && was.rows) {
      const byNight = {};
      was.rows.forEach(r => { const o = {}; was.head.forEach((c, j) => { o[c] = r[j]; }); byNight[r[0]] = o; });
      const seen = {};
      now.rows.forEach(r => {
        seen[r[0]] = 1;
        const w = byNight[r[0]];
        let any = false;
        now.head.forEach((c, j) => {
          if (j < 2) return;
          const a = +(w && w[c]) || 0, b = +r[j] || 0;
          if (a !== b) { out.cells[r[0] + '|' + c] = a; any = true; }
        });
        if (any) out.nights++;
      });
      Object.keys(byNight).forEach(n => { if (!seen[n]) out.nights++; });
    }
    const wr = send.copy.rooming;
    if (wr && wr.rows) {
      const key = r => r[0] + '|' + r[2], then = {};
      wr.rows.forEach(r => { then[key(r)] = JSON.stringify(r.map(String)); });
      const nowR = L.roomingRows().rows, seen = {};
      nowR.forEach(r => { const k = key(r); seen[k] = 1; if (then[k] !== JSON.stringify(r.map(String))) { out.rooms++; out.roomKeys[k] = 1; } });
      Object.keys(then).forEach(k => { if (!seen[k]) out.rooms++; });
    }
    return out;
  }
  const changedWords = c => [c.nights ? plural(c.nights, 'night') : '', c.rooms ? plural(c.rooms, 'room') : ''].filter(Boolean).join(' · ');

  /* ================================================================ the screen */

  function countsScreen(ctx) {
    const p = ctx.params;
    let sp = null, panel = p.at === 'sent' ? 'sent' : '';
    const draw = (c, why) => {
      if (why === 'local' && document.activeElement && document.activeElement.matches('input')) return;
      if (!sp) { A.clear(ctx.body); sp = ctx.split(); }
      const v = VIEWS.some(x => x.id === p.v) ? p.v : 'counts';
      const last = (S.sent || [])[0], ch = changedSince(last), n = ch.nights + ch.rooms;
      const due = S.countsDue ? 'Due ' + K.md(S.countsDue) : '';
      // The fact: "Due May 14 · Not sent", "Sent May 12 · Ada T.", "Sent May 12 · 2 changed since".
      const fact = last ? h('span', null, 'Sent ' + K.md(last.day) + ' · ', n ? A.link({ at: 'sent' }, n + ' changed since', 'ap-head__factlink') : last.by) : K.facts([due, 'Not sent']);
      const acts = [];
      acts.push(A.btn('Print', { ghost: true, icon: 'file', onClick: () => printView(v) }));
      acts.push(A.btn('Download', { ghost: true, icon: 'download', title: 'This list, for Excel', onClick: () => download(v) }));
      if (S.sent && S.sent.length) acts.push(A.btn('Sent · ' + S.sent.length, { ghost: true, onClick: () => { panel = 'sent'; A.setParams({ at: 'sent' }); draw(ctx); } }));
      if (!last || n) acts.push(A.btn('Mark sent', { primary: panel !== 'mark', write: true, title: 'Keeps a copy of what’s here · Emails no one · Ticks Final counts', onClick: () => { panel = 'mark'; draw(ctx); } }));
      ctx.head('Counts', fact, acts);
      A.clear(sp.main);
      sp.main.appendChild(h('div', { class: 'cm-toolbar' }, A.views(VIEWS, v, id => A.go({ v: id === 'counts' ? '' : id }, { replace: true }))));
      if (v === 'rooming') rooming(ch);
      else if (v === 'setup') setup();
      else counts(ch);
      if (panel === 'sent' && S.sent && S.sent.length) openSent();
      else if (panel === 'mark') openMark();
      else sp.close(true);
    };

    function counts(ch) {
      const C = countsNow(), stock = +S.cfg.linen_stock || 0, ln = C.ln;
      if (!C.totals[0][1] && !C.totals[1][1] && !C.totals[2][1]) {
        sp.main.appendChild(A.empty({ title: 'Rooms not placed yet', line: 'Counts follow the rooms', inset: true, action: A.link({ s: 'lod-rooms', v: '', id: '' }, 'Rooms', 'ap-btn') }));
        return;
      }
      // The totals, never a zero; then where the linen packets go, in words that are true.
      sp.main.appendChild(h('div', { class: 'cm-section' },
        h('div', { class: 'cm-stats' }, C.totals.filter(t => t[1]).map(t => h('div', { class: 'cm-stat' }, h('b', { text: String(t[1]) }), h('span', { text: t[0] })))),
        ln.all ? h('p', { class: 'ap-quiet' }, K.facts([plural(ln.all, 'linen packet'), ln.rooms ? ln.rooms + ' in rooms' : '', ln.yf ? ln.yf + ' Youngfolks halls' : '', C.waitingHh ? plural(C.waitingHh, 'household') + ' still to place' : ''])) : null,
        stock && ln.all > stock ? h('p', { class: 'cm-warn', text: 'Linen packets over stock · ' + ln.all + ' of ' + stock }) : null));
      const last = (S.sent || [])[0];
      sp.main.appendChild(h('div', { class: 'cm-scroll' }, h('table', { class: 'cm-table cm-counts' },
        h('thead', null, h('tr', null, C.head.map((x, i) => h('th', { class: i > 1 ? 'is-num' : '', text: x })))),
        h('tbody', null, C.rows.map(r => h('tr', null, r.map((v, i) => {
          const was = i > 1 ? ch.cells[r[0] + '|' + C.head[i]] : undefined;
          return h('td', { class: i > 1 ? 'is-num' : '' }, i === 0 ? String(v) : blank(v), was !== undefined ? h('span', { class: 'cm-was', title: 'Was ' + was + ' · Sent ' + K.md(last.day), 'aria-label': 'Was ' + was + ' · Sent ' + K.md(last.day) }) : null);
        })))))));
    }

    function rooming(ch) {
      const R = L.roomingRows();
      if (!R.rows.length) { sp.main.appendChild(A.empty({ title: 'Rooms not placed yet', line: 'The rooming list follows the rooms', inset: true, action: A.link({ s: 'lod-rooms', v: '', id: '' }, 'Rooms', 'ap-btn') })); return; }
      sp.main.appendChild(h('p', { class: 'ap-quiet cm-pad', text: plural(R.rows.length, 'room') + ' · Key holders only' }));
      sp.main.appendChild(h('div', { class: 'cm-scroll' }, h('table', { class: 'cm-table cm-rooming' },
        h('thead', null, h('tr', null, R.head.map((x, i) => h('th', { class: i === 1 || i === 2 || (i >= 5 && i <= 9) ? 'is-num' : '', text: x })))),
        h('tbody', null, R.rows.map(r => h('tr', { class: ch.roomKeys[r[0] + '|' + r[2]] ? 'is-changed' : '', title: ch.roomKeys[r[0] + '|' + r[2]] ? 'Changed since sent' : null }, r.map((v, i) => h('td', { class: i === 1 || i === 2 || (i >= 5 && i <= 9) ? 'is-num' : '', text: blank(v) }))))))));
    }

    function setup() {
      const T = setupNow(), l = T.rows.reduce((k, y) => k + y.l, 0), m = T.rows.reduce((k, y) => k + y.m, 0);
      if (!T.rows.length) { sp.main.appendChild(A.empty({ title: 'No linens or mattresses asked', inset: true, action: A.link({ v: '' }, 'Counts', 'ap-btn') })); return; }
      sp.main.appendChild(h('p', { class: 'ap-quiet cm-pad', text: K.facts([plural(T.rows.length, 'room'), l ? plural(l, 'linen packet') : '', m ? plural(m, 'air mattress', 'air mattresses') : '']) }));
      let lastFloor = '';
      const cell = (y, k) => {
        const v = y[k];
        if (ro()) return h('td', { class: 'is-num', text: blank(v) });
        const input = h('input', { class: 'ap-input cm-num', type: 'number', min: '0', max: '24', inputmode: 'numeric', value: String(v || 0), 'aria-label': (k === 'l' ? 'Linen packets' : 'Air mattresses') + ', room ' + y.r.num });
        input.addEventListener('change', () => {
          const val = Math.max(0, Math.min(24, +input.value || 0)), set = Object.assign({}, L.hrow(y.x).setup || {});
          set[y.r.id] = { l: k === 'l' ? val : y.l, m: k === 'm' ? val : y.m };
          L.hhSave(y.x, { setup: set }, { label: L.roomWords(y.r.id) + ' · ' + (k === 'l' ? plural(val, 'linen packet') : plural(val, 'air mattress', 'air mattresses')) });
        });
        return h('td', { class: 'is-num' }, input, y.set && y[k] !== y.ask[k] ? h('small', { class: 'ap-quiet', text: ' asked ' + y.ask[k] }) : null);
      };
      sp.main.appendChild(h('div', { class: 'cm-scroll' }, h('table', { class: 'cm-table' },
        h('thead', null, h('tr', null, h('th', { text: 'Room' }), h('th', { text: 'Arrives' }), h('th', { class: 'is-num', text: 'Linen packets' }), h('th', { class: 'is-num', text: 'Air mattresses' }))),
        h('tbody', null, T.rows.map(y => {
          const fl = y.r.hall + '|' + y.r.floor, out = [];
          if (fl !== lastFloor) { out.push(h('tr', { class: 'cm-group' }, h('td', { colspan: '4', text: y.r.hall + ' · ' + L.floorName(y.r.floor) }))); lastFloor = fl; }
          out.push(h('tr', null, h('td', null, h('b', { text: String(y.r.num) })), h('td', { text: y.arrives ? SU.nightShort(y.arrives) : '' }), cell(y, 'l'), cell(y, 'm')));
          return out;
        })))));
    }

    /* ---------------------------------------------------------------- Mark sent, and the Sent list */

    // What a send keeps: the three lists exactly as drawn here.
    function copyNow() {
      const C = countsNow(), T = setupNow();
      return { counts: { head: C.head, rows: C.rows, totals: C.totals.filter(t => t[1]) }, rooming: L.roomingRows(), setup: { head: T.head, rows: T.table } };
    }
    function openMark() {
      const to = S.sendTo || [];
      let who = to[0] || 'other';
      const other = h('input', { class: 'ap-input', maxlength: '80', placeholder: 'Who', 'aria-label': 'Sent to', hidden: who !== 'other' });
      const what = { counts: true, rooming: true };
      const day = h('input', { type: 'date', class: 'ap-input', value: L.today() || '', max: L.today() || null, 'aria-label': 'Date', style: { maxWidth: '200px' } });
      const err = h('p', { class: 'ap-err', role: 'alert' });
      const go = A.btn('Mark sent', { primary: true, write: true, title: 'Keeps a copy of what’s here · Emails no one', onClick: () => {
        const no = L.blocked();
        if (no) { err.textContent = no; return; }
        const whom = who === 'other' ? other.value.trim() : who;
        const list = Object.keys(what).filter(k => what[k]);
        if (!whom) { err.textContent = 'Who it went to'; other.focus(); return; }
        if (!list.length) { err.textContent = 'Tick what was sent'; return; }
        go.disabled = true;
        err.textContent = '';
        L.api('POST', '/sent', { to: whom, what: list.join(','), day: day.value, copy: copyNow() }).then(res => {
          S.sent = res.sent || [];
          panel = '';
          A.toast(res.say || 'Marked sent', { undo: () => L.api('DELETE', '/sent/' + res.send.n).then(r => { S.sent = r.sent || []; A.toast(r.say || 'Undone'); draw(ctx); }, A.fail) });
          draw(ctx);
        }, e => { go.disabled = false; err.textContent = (e && e.data && e.data.message) || e.message || 'Not saved'; });
      } });
      sp.open({
        title: 'Mark sent', line: 'To the campus · Kept as sent',
        body: h('div', { class: 'cm-mark' },
          h('div', { class: 'ap-field' }, h('span', { class: 'ap-label', text: 'Sent to' }),
            K.pills(to.map(t => [t, t]).concat([['other', 'Other']]), who, v => { who = v; other.hidden = v !== 'other'; if (v === 'other') other.focus(); }, 'Sent to'), other),
          h('div', { class: 'ap-field' }, h('span', { class: 'ap-label', text: 'What' }),
            Object.keys(WHAT).map(k => h('label', { class: 'ap-switch' }, h('input', { type: 'checkbox', class: 'ap-check', checked: true, on: { change: e => { what[k] = e.target.checked; } } }), WHAT[k]))),
          h('label', { class: 'ap-field' }, h('span', { class: 'ap-label', text: 'Date' }), day),
          err),
        foot: [go, A.btn('Cancel', { ghost: true, onClick: () => { panel = ''; sp.close(true); draw(ctx); } })],
        onClose: () => { panel = ''; draw(ctx); }
      });
    }
    function openSent() {
      const list = S.sent || [];
      sp.open({
        title: 'Sent · ' + list.length, line: 'Every send is kept',
        body: h('ul', { class: 'cm-sent' }, list.map((s, i) => {
          const c = i === 0 ? changedSince(s) : null;
          return h('li', null,
            h('p', null, h('b', { text: K.md(s.day) }), ' · ' + K.facts([s.by, s.to])),
            h('p', { class: 'ap-quiet', text: s.what.map(k => WHAT[k] || k).join(' · ') }),
            c ? h('p', { class: c.nights || c.rooms ? 'cm-sent__ch' : 'ap-quiet' }, c.nights || c.rooms ? 'Changed since · ' + changedWords(c) : 'Nothing changed since') : null,
            h('p', null, h('button', { type: 'button', class: 'ap-link', text: 'Download as sent', on: { click: () => K.excel('years/' + S.year + '/lodging/sent/' + s.n, S.year + ' Lodging counts · Sent ' + s.day) } })));
        })),
        onClose: () => { panel = ''; A.setParams({ at: '' }); }
      });
    }

    /* ---------------------------------------------------------------- print and download */

    function tableOf(v) {
      if (v === 'rooming') { const R = L.roomingRows(); return [R.head].concat(R.rows); }
      if (v === 'setup') { const T = setupNow(); return [T.head].concat(T.table); }
      const C = countsNow();
      return [C.head].concat(C.rows, [[]], C.totals.filter(t => t[1]));
    }
    function download(v) {
      const name = { counts: 'Counts', rooming: 'Rooming list', setup: 'Room setup' }[v];
      const rows = tableOf(v);
      K.download(rows, S.year + ' Lodging ' + name.toLowerCase() + ' ' + L.stamp() + '.csv');
      L.api('POST', '/log', { what: 'export', list: 'counts-' + v, rows: rows.length - 1 }).catch(() => {});
    }
    function printView(v) {
      const rows = tableOf(v), name = { counts: 'Counts for the campus', rooming: 'Rooming list', setup: 'Room setup' }[v];
      L.api('POST', '/log', { what: 'print', list: 'counts-' + v }).catch(() => {});
      K.print({ title: name, who: 'Lodging only', landscape: v === 'rooming', build: () => h('table', null, h('thead', null, h('tr', null, rows[0].map(c => h('th', { text: c })))), h('tbody', null, rows.slice(1).map(r => h('tr', null, r.map(c => h('td', { text: blank(c) }))))) ) });
    }

    return L.screen(ctx, draw);
  }

  A.screen({ id: 'lod-counts', title: 'Counts', icon: 'report', section: 'own', who: ['lodging'], parts: ['sent'], render: countsScreen });
})();
