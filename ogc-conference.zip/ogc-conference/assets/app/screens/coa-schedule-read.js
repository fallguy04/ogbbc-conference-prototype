/*
 * coa-schedule-read.js — the schedule's one strict format (window.OGC_SCHED; docs/25 rules 4 and 7).
 *
 * Mechanical, not smart: a time is a clock time, a kind or a group is a word from a fixed list, a place
 * is one of the campus's places. What's read is said back, field by field, before anything is added;
 * anything that isn't on a list is said as a problem, never guessed and never moved into a note.
 *
 *   S.clock('7:30 PM') → { m: 1150, half: true } | { err }        one time ("7", "7:30p", "19:30", "noon")
 *   S.span('7–9:45 PM') → { a, b, readAs, err }                    a start and an end, both required
 *   S.line('7–9:45 PM Hymn sing, Chapel, Singing', ctx) → { ok, row, said: [[label, value, tone]], err, readAs }
 *   S.paste(text, ctx) → { rows: [{ row, line }], unread: [{ text, why }] }   lines, or a spreadsheet's rows
 *   S.grid(cells, ctx) → the same, from rows of cells with a header row (Export's own columns, A/V's
 *                        file from tools/export-schedule.py, or a Sheet's), plus hasId; each row's
 *                        problems in row._errs, field by field (S.errWords(row) says them)
 *   S.exact(row), S.minutes(v), S.store(m), S.fmt(m), S.when(row)
 *
 * The one fixed rule for a time written without AM or PM (docs/26 #6 keeps it, "Read as", one tap to
 * switch): an hour from 7 to 11 is the morning; 12 and 1 to 6 are the afternoon or evening. An end
 * without one is the first such time after the start. A start without one, when the end has it, is the
 * last such time before the end ("7–9:45 PM" is 7 PM).
 *
 * ctx = { days: [{ name, date }], day: 'Saturday', places: [{ code, name, building }], keepCommas }. No DOM: Node
 * runs it (tools/check-schedule-read.mjs).
 */
(function (root) {
  'use strict';
  const CFG = (root.OGC_WP && root.OGC_WP.sched) || {};
  // The fixed lists come from the server (module-schedule.php), with the same lists here for Node.
  const KINDS = (CFG.kinds && CFG.kinds.length ? CFG.kinds : [
    ['worship', 'Worship', ''], ['communion', 'Communion', ''], ['council', 'Council', ''], ['meal', 'Meal', ''], ['teaching', 'Teaching', ''],
    ['singing', 'Singing', ''], ['prayer', 'Prayer', ''], ['meeting', 'Meeting', ''], ['activity', 'Activity', ''], ['tournament', 'Tournament', ''],
    ['open', 'Open hours', 'all day'], ['desk', 'Desk', 'desk'], ['quiet', 'Quiet time', 'nightly'], ['checkin', 'Check-in', '']
  ]).map(k => ({ key: k[0], label: k[1], display: k[2] || '' }));
  const OLD = CFG.old || { devotion: 'worship', snack: 'meal', social: 'activity', free: 'activity', display: 'open', lodging: 'desk', on_call: 'desk', registration: 'checkin', pickup: 'checkin' };
  const AUD = [['All', 'Everyone', /^(everyone|all)$/i], ['Conference', 'Conference', /^conference$/i], ['Preteens', 'Preteens', /^pre-?teens?$/i], ['Young Folks', 'Young Folks', /^(young folks?|yf)$/i]];
  const LISTED = { '': 'In the day', 'all day': 'Open hours', desk: 'Desk hours', nightly: 'Every night', private: 'Committees only', timeline: 'In the day' };
  const lc = s => String(s == null ? '' : s).trim().toLowerCase();

  /* ------------------------------------------------------------ one clock time */

  function clock(text) {
    const t = lc(text).replace(/\./g, '').replace(/\s+/g, ' ');
    if (!t) return { err: 'No time' };
    if (/^(12(:00)? ?)?noon$/.test(t)) return { m: 720, half: true };
    if (/^(12(:00)? ?)?midnight$/.test(t)) return { m: 0, half: true, midnight: true };
    let m = t.match(/^(\d{1,2})(?::(\d{2}))? ?(am|pm|a|p)$/);
    if (m) {
      const h = +m[1], mi = m[2] ? +m[2] : 0;
      if (h < 1 || h > 12 || mi > 59) return { err: 'Not a time · ' + text };
      if (mi % 5) return { err: 'Use 5-minute steps' };
      return { m: ((h % 12) + (m[3][0] === 'p' ? 12 : 0)) * 60 + mi, half: true };
    }
    m = t.match(/^(\d{1,2})(?::(\d{2}))?$/);
    if (m) {
      const h = +m[1], mi = m[2] ? +m[2] : 0;
      if (h > 23 || mi > 59) return { err: 'Not a time · ' + text };
      if (mi % 5) return { err: 'Use 5-minute steps' };
      // 0:30, 13:00 and up, or a leading zero ("07:00"): 24-hour, exact.
      if (h === 0 || h > 12 || /^0\d/.test(m[1])) return { m: h * 60 + mi, half: true };
      return { h, mi, half: false };
    }
    return { err: 'Not a time · ' + text };
  }

  // The one fixed rule: 7–11 the morning, 12 and 1–6 the afternoon or evening.
  const ruled = c => ((c.h % 12) + (c.h >= 7 && c.h <= 11 ? 0 : 12)) * 60 + c.mi;
  const cand = c => [(c.h % 12) * 60 + c.mi, (c.h % 12) * 60 + c.mi + 720];

  // "7–9:45 PM", "10–11:30", "noon–1", "19:00–21:45", "11 PM–1 AM". → { a, b, readAs, text } or { err }.
  const SEP = /\s*(?:–|—|-|\bto\b|\buntil\b|\btill\b)\s*/i;
  function span(text) {
    const t = String(text || '').trim();
    const parts = t.split(SEP).filter(x => x !== '');
    if (parts.length !== 2) return { err: parts.length < 2 ? 'Start and end · 7–9:45 PM' : 'Not a time · ' + t };
    const A = clock(parts[0]), B = clock(parts[1]);
    if (A.err) return { err: A.err };
    if (B.err) return { err: B.err };
    let a, b, readAs = false;
    if (A.half) a = A.m;
    if (B.half) b = B.m;
    if (a == null && b != null) {
      // The last such time before the end.
      const c = cand(A).filter(x => x < (b === 0 ? 1440 : b));
      a = c.length ? c[c.length - 1] : cand(A)[0];
    }
    if (a == null) { a = ruled(A); readAs = true; }
    if (b == null) {
      // The first such time after the start.
      const c = cand(B).concat(cand(B).map(x => x + 1440)).filter(x => x > a).sort((x, y) => x - y);
      b = c.length ? c[0] % 1440 : cand(B)[0];
    }
    return { a, b, readAs };
  }

  /* ------------------------------------------------------------ writing times */

  function fmt(m) {
    if (m == null) return '';
    m = ((m % 1440) + 1440) % 1440;
    if (m === 720) return 'Noon';
    if (m === 0) return 'Midnight';
    const h = Math.floor(m / 60), mm = m % 60;
    return (h % 12 || 12) + (mm ? ':' + String(mm).padStart(2, '0') : '') + (h < 12 ? ' AM' : ' PM');
  }
  // "2–8 PM", "10–11:30 AM", "Noon–11 PM", "11 PM–1 AM"
  function spanText(a, b) {
    if (a == null) return '';
    if (b == null) return fmt(a);
    const A = fmt(a), B = fmt(b);
    const same = /[AP]M$/.test(A) && /[AP]M$/.test(B) && A.slice(-2) === B.slice(-2) && b > a;
    return (same ? A.slice(0, -3) : A) + '–' + B;
  }
  // A kept time ("7:00 PM", "noon") → minutes, or null. Words are never a time.
  function minutes(v) {
    const c = clock(v);
    return c.err || !c.half ? null : c.m;
  }
  const store = m => { if (m == null) return ''; m = ((m % 1440) + 1440) % 1440; const h = Math.floor(m / 60); return (h % 12 || 12) + ':' + String(m % 60).padStart(2, '0') + (h < 12 ? ' AM' : ' PM'); };
  const exact = r => minutes(r.start) != null && minutes(r.end) != null;
  // A row's time in words: "7–9:45 PM", or the words it still has ("After Communion").
  function when(r) {
    const a = minutes(r.start), b = minutes(r.end);
    if (a == null) return String(r.start || '').trim();
    return spanText(a, b);
  }
  // How long, said: "2 hr 45 min", "Ends next day".
  function length(a, b) {
    if (a == null || b == null) return '';
    const len = b > a ? b - a : b + 1440 - a, h = Math.floor(len / 60);
    return (h ? h + ' hr' : '') + (h && len % 60 ? ' ' : '') + (len % 60 ? len % 60 + ' min' : '');
  }

  /* ------------------------------------------------------------ the fixed lists */

  const kindKey = k => { k = lc(k); return KINDS.some(x => x.key === k) ? k : OLD[k] || ''; };
  const kindLabel = k => { const x = KINDS.find(y => y.key === kindKey(k)); return x ? x.label : ''; };
  const kindWord = w => { w = lc(w); const x = KINDS.find(y => lc(y.label) === w || y.key === w); return x ? x.key : ''; };
  const listedOf = k => { const x = KINDS.find(y => y.key === kindKey(k)); return x ? x.display : ''; };
  const audWord = w => (AUD.find(a => a[2].test(String(w || '').trim())) || [''])[0];
  const audLabel = a => (AUD.find(x => lc(x[0]) === lc(a)) || AUD[1])[1];
  // A place by its code or its whole name, or the one place whose name starts so (never two).
  function place(text, places) {
    const v = lc(text).replace(/^the\s+/, '');
    if (!v) return { none: true };
    const list = places || [];
    const hit = list.find(p => lc(p.code) === v) || list.find(p => lc(p.name) === v);
    if (hit) return { place: hit };
    const pre = list.filter(p => lc(p.name).indexOf(v) === 0 && v.length >= 3);
    if (pre.length === 1) return { place: pre[0] };
    if (pre.length > 1) return { many: pre };
    return { none: true };
  }
  const WEEK = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
  const MONTHS = ['jan', 'feb', 'mar', 'apr', 'may', 'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec'];
  // A day as written ("Saturday", "Sat", "2027-05-29", "5/29", "29-May", "May 29") → one of the year's.
  function dayOf(s, days) {
    const t = lc(s).replace(/\.(?=\s|$)/g, '').replace(/,/g, ' ').replace(/\s+/g, ' ');
    if (!t) return null;
    days = days || [];
    const md = (m, d) => days.find(x => { const p = String(x.date || '').split('-'); return +p[1] === m && +p[2] === d; }) || null;
    let m = t.match(/^(\d{4})-(\d{1,2})-(\d{1,2})$/);
    if (m) return md(+m[2], +m[3]);
    m = t.match(/^(\d{1,2})\/(\d{1,2})(?:\/\d{2,4})?$/);
    if (m) return md(+m[1], +m[2]);
    m = t.match(/^(?:[a-z]+ )?([a-z]{3})[a-z]* (\d{1,2})(?: \d{4})?$/);
    if (m && MONTHS.indexOf(m[1]) > -1) return md(MONTHS.indexOf(m[1]) + 1, +m[2]);
    m = t.match(/^(\d{1,2})[ -]([a-z]{3})[a-z]*$/);
    if (m && MONTHS.indexOf(m[2]) > -1) return md(MONTHS.indexOf(m[2]) + 1, +m[1]);
    m = t.match(/^([a-z]{3})[a-z]*$/);
    if (m && WEEK.some(w => w.slice(0, 3) === m[1])) return days.find(x => lc(x.name).slice(0, 3) === m[1]) || null;
    return null;
  }

  /* ------------------------------------------------------------ one line */

  // "7–9:45 PM Hymn sing, Chapel, Singing, Young Folks": the time first, then the title, then (after
  // commas, in any order) a place, a kind and who it's for, each from its list. The title is everything
  // up to the first piece that's on a list. A title with a comma in it is never taken quietly: the piece
  // before the list ("Lunch, Dining Hall": "Dining Hall") is said as not on a list, and the row waits
  // until the place is fixed or the person keeps the comma (ctx.keepCommas: "Song, prayer and
  // dismissal, Young Folks"). out.commaTitle says which case it was.
  function line(text, ctx) {
    ctx = ctx || {};
    const t = String(text || '').trim().replace(/\s+/g, ' ');
    const out = { ok: false, row: null, said: [], err: '', readAs: false, commaTitle: false };
    if (!t) return out;
    // "9 PM", "9pm", "9p", "9 p.m.": a lone letter only when it's joined to the number ("7–9 a cappella
    // sing" is 7 to 9, then the title).
    const T = '(?:\\d{1,2}(?::\\d{2})?(?:\\s*[ap]\\.?m\\.?|[ap](?![a-z]))?|noon|midnight)';
    const m = t.match(new RegExp('^(' + T + '\\s*(?:–|—|-|\\bto\\b)\\s*' + T + ')(?=\\s|,|$)', 'i'));
    if (!m) {
      out.err = /^\d/.test(t) ? 'Start and end first · 7–9:45 PM' : 'Start with the time · 7–9:45 PM Hymn sing, Chapel';
      out.said.push(['When', 'Not read', 'bad']);
      return out;
    }
    const sp = span(m[1]);
    if (sp.err) { out.err = sp.err; out.said.push(['When', sp.err, 'bad']); return out; }
    const rest = t.slice(m[0].length).replace(/^[\s,·:]+/, '');
    const pieces = rest.split(/\s*,\s*/).map(x => x.trim()).filter(Boolean);
    const row = { day: ctx.day || '', start: store(sp.a), end: store(sp.b), title: '', audience: 'Conference', kind: '', place: '' };
    // Each piece: a place (exactly), a group, a kind, or a place by the start of its name.
    const read = p => {
      const pl = place(p, ctx.places);
      if (pl.place && (lc(pl.place.code) === lc(p) || lc(pl.place.name) === lc(p).replace(/^the\s+/, ''))) return { k: 'place', v: pl.place };
      if (audWord(p)) return { k: 'aud', v: audWord(p) };
      if (kindWord(p)) return { k: 'kind', v: kindWord(p) };
      if (pl.place) return { k: 'place', v: pl.place };
      if (pl.many) return { k: 'many', v: pl.many };
      return null;
    };
    const marks = pieces.map(read);
    let first = marks.findIndex((x, i) => i > 0 && x);
    if (first < 0) first = pieces.length;
    row.title = pieces.slice(0, first).join(', ');
    const errs = [];
    // A comma in the title: the last piece of it is most likely a place the list doesn't have.
    if (first > 1) {
      out.commaTitle = true;
      if (!ctx.keepCommas) errs.push('Not a place, kind or group · ' + pieces[first - 1]);
    }
    for (let i = first; i < pieces.length; i++) {
      const x = marks[i];
      if (!x) { errs.push('Not a place, kind or group · ' + pieces[i]); continue; }
      if (x.k === 'many') { errs.push(pieces[i] + ' · ' + x.v.length + ' places · ' + x.v.slice(0, 3).map(p => p.name).join(', ')); continue; }
      const f = x.k === 'place' ? 'place' : x.k === 'aud' ? 'audience' : 'kind';
      const val = x.k === 'place' ? x.v.code : x.v;
      if (f === 'audience' ? row._aud : row[f]) { errs.push('Two ' + (f === 'place' ? 'places' : f === 'kind' ? 'kinds' : 'groups') + ' · ' + pieces[i]); continue; }
      row[f] = val;
      if (f === 'audience') row._aud = true;
    }
    delete row._aud;
    out.readAs = sp.readAs;
    out.said.push(['Day', String(row.day || '').slice(0, 3) || '—']);
    out.said.push(['When', spanText(sp.a, sp.b) + (sp.readAs ? ' · Read as' : '') + (sp.b < sp.a && sp.b !== 0 ? ' · Ends next day' : ''), sp.readAs ? 'tan' : '']);
    out.said.push(['What', row.title || 'No title', !row.title ? 'bad' : out.commaTitle ? 'tan' : '']);
    const pl = (ctx.places || []).find(p => p.code === row.place);
    out.said.push(['Where', pl ? pl.name : '—', '']);
    out.said.push(['For', audLabel(row.audience), '']);
    out.said.push(['Kind', row.kind ? kindLabel(row.kind) : 'To choose', row.kind ? '' : 'tan']);
    errs.forEach(e => out.said.push(['', e, 'bad']));
    if (!row.title) errs.unshift('A title after the time');
    out.err = errs[0] || '';
    out.ok = !errs.length;
    out.row = row;
    out.a = sp.a; out.b = sp.b;
    return out;
  }
  // The other half of the day (the "Read as" rule switched): both times 12 hours on.
  function flip(row) {
    const a = minutes(row.start), b = minutes(row.end);
    if (a == null) return row;
    const by = a < 720 ? 720 : -720;
    return Object.assign({}, row, { start: store(a + by), end: b == null ? row.end : store(b + by) });
  }

  /* ------------------------------------------------------------ many lines, a spreadsheet */

  const DAY_HEAD = /^(sun|mon|tue|tues|wed|thu|thur|thurs|fri|sat)[a-z]*\.?,?(\s+([a-z]{3,9}\.?\s+\d{1,2}|\d{1,2}\/\d{1,2}(\/\d{2,4})?))?:?$/i;

  // A spreadsheet's column names → the schedule's fields: the site's Export, A/V's file from
  // tools/export-schedule.py, schedule.csv's own names, and the plain names a Sheet uses.
  const HEAD = [
    [/^(day|days)$/, 'day'], [/^(date)$/, 'date'], [/^(time|times|when)$/, 'time'],
    [/^(start|starts|begin|begins|from|start time|start_time)$/, 'start'], [/^(end|ends|to|until|end time|end_time|finish)$/, 'end'],
    [/^(what|title|event|activity|session)$/, 'title'], [/^(where|place|location|room|venue)$/, 'where'], [/^(place code|code|place_code)$/, 'place'],
    [/^(building)$/, 'building'], [/^(for|audience|group|who)$/, 'audience'], [/^(kind|type)$/, 'kind'], [/^(note|notes)$/, 'note'],
    [/^(call-?in|call_in|call in line|on the line|live)$/, 'call_in'], [/^(recorded|recording)$/, 'recorded'],
    [/^(shown as|display|listed as)$/, 'display'], [/^(shown to)$/, 'shown_to'], [/^(through|last day|last_day)$/, 'last_day'],
    [/^(printout note|print_note|on the printout)$/, 'print_note'], [/^(id|_id|row id)$/, '_id'], [/^(sort_time|sort time)$/, 'sort_time']
  ];
  const headOf = c => { const v = lc(c).replace(/^﻿/, ''); const x = HEAD.find(h => h[0].test(v)); return x ? x[1] : ''; };
  const unsafe = v => String(v == null ? '' : v).replace(/^'(?=[=+\-@\t\r])/, '');
  // Excel's own time (a fraction of a day) → "7:30 PM".
  const cellTime = v => { const s = String(v || '').trim(); return /^0?\.\d+$|^0$/.test(s) ? store(Math.round(parseFloat(s) * 1440)) : s; };
  const YES = /^(y|yes|x|1|true|✓|on)$/i;
  const DISP = { 'in the day': '', 'open hours': 'all day', 'open now': 'all day', 'all day': 'all day', 'desk hours': 'desk', desk: 'desk', 'every night': 'nightly', nightly: 'nightly', 'committees only': 'private', private: 'private' };

  // Columns the Export always fills: a blank cell there means none (no note, not on the line, no
  // place), never "leave it as it is", so clearing a cell in Excel is a change like any other.
  const FILLED = ['call_in', 'recorded', 'note', 'print_note', 'last_day', 'kind', 'audience', 'where', 'place'];
  const NO = /^(n|no|0|false)$/i;

  // Rows of cells with a header row → { rows: [{ row, line }], unread: [{ text, why }], hasId }.
  // Nothing is chosen quietly: when two columns say the same thing (Day and Date, Where and Place code)
  // and disagree, or a cell isn't on its list, the row carries the problem in row._errs
  // ([{ k, why, raw }]); raw is what the file said, so an import matched by ID can tell a value that
  // didn't change (the same words the site keeps) from one that did. A row with only a day in it is a
  // day's heading.
  function grid(cells, ctx) {
    ctx = ctx || {};
    const out = { rows: [], unread: [], hasId: false, header: [] };
    const heads = (cells || []).find(r => r.some(c => String(c).trim()));
    if (!heads) return out;
    const map = heads.map(headOf);
    out.header = map;
    out.hasId = map.indexOf('_id') > -1;
    const list = ctx.places || [];
    let day = ctx.day || '';
    (cells || []).slice(cells.indexOf(heads) + 1).forEach(cs => {
      const o = {};
      map.forEach((k, i) => {
        if (!k) return;
        const v = cs[i] == null ? '' : unsafe(cs[i]).trim();
        if (v !== '') o[k] = v;
        else if (FILLED.indexOf(k) > -1 && !(k in o)) o[k] = '';
      });
      const full = Object.keys(o).filter(k => o[k] !== '');
      if (!full.length) return;
      const text = cs.filter(x => String(x).trim()).join(' · ');
      const row = { _errs: [] };
      const bad = (k, why, raw) => row._errs.push({ k, why, raw });
      // The day: Day and Date must agree when both are there; either one is enough.
      const dd = o.date ? dayOf(o.date, ctx.days) : null, dn = o.day ? dayOf(o.day, ctx.days) : null;
      if (full.every(k => k === 'day' || k === 'date')) { if (dd || dn) day = (dd || dn).name; else out.unread.push({ text, why: 'Not a day of this Conference · ' + (o.date || o.day) }); return; }
      if (o.date && !dd) bad('day', 'Not a day of this Conference · ' + o.date);
      else if (o.day && !dn) bad('day', 'Not a day of this Conference · ' + o.day, o.day);
      else if (dd && dn && dd !== dn) bad('day', 'Day and Date differ · ' + o.day + ', ' + o.date);
      else if (dd || dn) day = (dd || dn).name;
      row.day = day;
      row.title = o.title || '';
      if (!o.title) bad('title', 'No title');
      // The time: Start and End, or one Time cell ("7–9:45 PM"). Exact, or said why not (_timeErr):
      // a new row isn't added without one; a row matched by its ID that still has the same words as
      // the site keeps them (raw = _was).
      let a = null, b = null, terr = '';
      row._was = { start: '', end: '' };
      // A/V's file wrote a repeating row's end as "9:00 PM (Monday)": the day in brackets is Through.
      const endDay = o.end && o.end.match(/^(.*?)\s*\(([A-Za-z]+)\)\s*$/);
      if (endDay) { o.end = endDay[1]; if (!o.last_day) o.last_day = endDay[2]; }
      const said = (o.time || [o.start, o.end].filter(Boolean).join('–')) || '';
      if (o.start != null || o.end != null) {
        row._was = { start: o.start || '', end: o.end || '' };
        const A = clock(cellTime(o.start || '')), B = clock(cellTime(o.end || ''));
        if (o.start && A.err && !/5-minute/.test(A.err)) terr = 'Set exact time · ' + o.start;
        else if (!o.start || !o.end) terr = 'Set exact time · ' + (o.start ? 'No end' : 'No start');
        else if (A.err || B.err) terr = (/5-minute/.test(A.err + B.err) ? 'Use 5-minute steps · ' : 'Set exact time · ') + said;
        else {
          const sp = span(cellTime(o.start) + '–' + cellTime(o.end));
          if (sp.err) terr = 'Set exact time · ' + said; else { a = sp.a; b = sp.b; if (sp.readAs) row._readAs = true; }
        }
      } else if (o.time) {
        row._was = { start: o.time, end: '' };
        const sp = span(o.time);
        if (sp.err) terr = (/5-minute/.test(sp.err) ? 'Use 5-minute steps · ' : 'Set exact time · ') + said; else { a = sp.a; b = sp.b; if (sp.readAs) row._readAs = true; }
      } else terr = 'Set exact time · No time';
      if (terr) { row._timeErr = terr; bad('time', terr, row._was); }
      row.start = a == null ? '' : store(a);
      row.end = b == null ? '' : store(b);
      // Where: the place's name, its code, or both. Both there and saying different places is a problem,
      // never one chosen over the other. The Export writes a code it doesn't know as the Where too.
      if ('where' in o || 'place' in o) {
        const code = o.place || '', name = o.where || '';
        const byCode = code ? list.find(x => lc(x.code) === lc(code)) : null;
        const nm = name && lc(name) !== lc(code) ? place(name, list) : null;
        const many = q => name + ' · ' + q.many.length + ' places · ' + q.many.slice(0, 3).map(p => p.name).join(', ');
        if (code && nm) {
          if (nm.place && byCode) { if (nm.place.code === byCode.code) row.place = byCode.code; else bad('place', 'Where and Place code differ · ' + name + ', ' + code); }
          else if (nm.many) bad('place', many(nm));
          else if (nm.place || byCode) bad('place', 'Where and Place code differ · ' + name + ', ' + code);
          else bad('place', 'Not a place at this campus · ' + name);
        } else if (code) {
          if ('where' in o && !name) bad('place', 'Where is blank · Place code says ' + code);
          else if (byCode) row.place = byCode.code;
          else bad('place', 'Not a place at this campus · ' + code, code);
        } else if (nm) {
          if (nm.place) row.place = nm.place.code;
          else if (nm.many) bad('place', many(nm));
          else bad('place', 'Not a place at this campus · ' + name, name);
        } else row.place = '';
        if (o.building && row.place != null) row._building = o.building;
      }
      if ('audience' in o) {
        if (!o.audience) row.audience = '';
        else { const w = audWord(o.audience); if (w) row.audience = w; else bad('audience', 'Not a group · ' + o.audience, o.audience); }
      }
      // A kind on the list (its word or its key), an older kind read by the fixed table, or kept aside
      // as written (_kindRaw) for a person to choose.
      if ('kind' in o) { const k = o.kind ? kindWord(o.kind) || OLD[lc(o.kind)] || '' : ''; if (k || !o.kind) row.kind = k; else row._kindRaw = o.kind; }
      if ('note' in o) row.note = o.note;
      if ('print_note' in o) row.print_note = o.print_note;
      if ('call_in' in o) { if (o.call_in && !YES.test(o.call_in) && !NO.test(o.call_in)) bad('call_in', 'Call-in is Yes or blank · ' + o.call_in); else row.call_in = YES.test(o.call_in) ? 'yes' : ''; }
      if ('recorded' in o) { if (o.recorded && !YES.test(o.recorded) && !NO.test(o.recorded)) bad('recorded', 'Recorded is Yes, No or blank · ' + o.recorded); else row.recorded = NO.test(o.recorded) ? 'no' : ''; }
      if (o.shown_to != null) row.display = /committee/i.test(o.shown_to) ? 'private' : '';
      if (o.display != null) { if (DISP[lc(o.display)] !== undefined) { if (row.display !== 'private') row.display = DISP[lc(o.display)]; } else row._displayRaw = o.display; }
      if ('last_day' in o) { const ld = o.last_day ? dayOf(o.last_day, ctx.days) : null; if (o.last_day && !ld) bad('last_day', 'Not a day of this Conference · Through ' + o.last_day, o.last_day); else row.last_day = ld ? ld.name : ''; }
      if (o._id) row._id = o._id;
      out.rows.push({ row, line: text });
    });
    return out;
  }
  // A row's problems in words ("Day and Date differ · Monday, 2027-05-29 · Not a group · Adults").
  const errWords = r => (r._errs || []).map(e => e.why).join(' · ');

  // Pasted text: a spreadsheet's rows (with a header row), or lines in the one format, a line that's
  // a day's name starting that day's rows.
  function paste(text, ctx) {
    ctx = ctx || {};
    const raw = String(text || '').replace(/^﻿/, '');
    const lines = raw.split(/\r?\n/);
    const first = lines.find(l => l.trim()) || '';
    const tab = first.indexOf('\t') > -1;
    if (tab || /,/.test(first)) {
      const cells = tab ? lines.map(l => l.split('\t').map(x => x.trim())) : csvCells(raw);
      const h = (cells.find(r => r.some(c => String(c).trim())) || []).map(headOf);
      if (h.filter(Boolean).length >= 2 && h.indexOf('title') > -1) return grid(cells, ctx);
    }
    const out = { rows: [], unread: [], hasId: false };
    let day = ctx.day || '';
    lines.forEach(l0 => {
      const l = (tab ? l0.split('\t').map(x => x.trim()).filter(Boolean).join(', ') : l0).trim();
      if (!l) return;
      if (DAY_HEAD.test(l)) { const d = dayOf(l.replace(/:$/, '').split(/,|\s+(?=\d)/)[0], ctx.days) || dayOf(l, ctx.days); if (d) { day = d.name; return; } }
      const r = line(l, Object.assign({}, ctx, { day }));
      if (!r.ok) { out.unread.push({ text: l, why: r.err || 'Not read', comma: r.commaTitle && !ctx.keepCommas }); return; }
      if (r.readAs) r.row._readAs = true;
      if (!r.row.place) delete r.row.place;
      if (!r.row.kind) delete r.row.kind;
      out.rows.push({ row: r.row, line: l });
    });
    return out;
  }
  // CSV with quotes → rows of cells.
  function csvCells(text) {
    const out = []; let row = [], cur = '', q = false;
    const s = String(text);
    for (let i = 0; i < s.length; i++) {
      const c = s[i];
      if (q) { if (c === '"' && s[i + 1] === '"') { cur += '"'; i++; } else if (c === '"') q = false; else cur += c; }
      else if (c === '"') q = true; else if (c === ',') { row.push(cur.trim()); cur = ''; }
      else if (c === '\n' || c === '\r') { if (c === '\r' && s[i + 1] === '\n') i++; row.push(cur.trim()); out.push(row); row = []; cur = ''; }
      else cur += c;
    }
    if (cur || row.length) { row.push(cur.trim()); out.push(row); }
    return out;
  }

  root.OGC_SCHED = {
    KINDS, OLD, AUD, LISTED, clock, span, line, flip, paste, grid, errWords, csvCells, headOf, dayOf, place,
    minutes, store, fmt, spanText, exact, when, length, kindKey, kindLabel, kindWord, listedOf, audWord, audLabel
  };
})(typeof window !== 'undefined' ? window : globalThis);
