/*
 * committee-handdown.js — the hand-down on a committee's page (night-handdown, Oct 13; docs/23 "The
 * hand-down lives in the system", docs/14 idea 7). screen-committees.js draws the page and asks these
 * for its parts; the routes are includes/module-handdown.php (GET/PUT app/{y}/handdown…).
 *
 *   A.hd.load(ctx, key, from)        the committee's hand-down (from: a past year, read only)
 *   A.hd.lastNotes(ctx, c, hd, key)  last year's notes on top: Done, and Keep for next year
 *   A.hd.lastReport(ctx, c, hd, open) last year's report: the answers and its numbers
 *   A.hd.how(ctx, c, hd, key)        How we work: the committee's own standards, carried
 *   A.hd.contacts(ctx, c, hd, key)   Contacts by role (the side column; each opens in the panel)
 *   A.hd.files(ctx, c, hd, key, up)  Files: what each is for, Next year, Remove with Undo
 *   A.hd.report(ctx, c, hd, key)     this year's report: the COA's questions, Numbers, the contacts
 *   A.hd.exportBtn(ctx, c, hd, key)  Export ▾: Print (Your part), Excel, Excel and files (.zip)
 *   A.hd.board(ctx, sp)              the COA's Hand-down view on Committees
 *
 * Nothing anyone typed goes into innerHTML: every node is built with OGC_APP.h().
 */
(function () {
  'use strict';
  const A = window.OGC_APP, h = A.h;
  const K = () => window.OGC_CK || {};
  const HD = A.hd = {};
  if (A.addIcons) A.addIcons({ up: 'M4 10l4-4 4 4' });
  const enc = encodeURIComponent;
  const asQ = () => (A.params().as ? '&as=' + enc(A.params().as) : '');
  const msg = e => (e && e.data && e.data.message) || 'Not saved';
  const nameOf = c => c.key === 'coa' ? 'COA' : c.name;
  // "Ushers’ page", "Food’s page".
  const poss = n => n + (/s$/i.test(n) ? '’' : '’s');

  HD.load = (ctx, key, from) => ctx.api('GET', 'handdown?c=' + enc(key) + (from ? '&from=' + from : '')).catch(() => null);

  /* ------------------------------------------------------------ last year's notes */

  HD.lastNotes = function (ctx, c, hd, key, o) {
    const list = c.last_notes || [];
    if (!list.length) return null;
    o = o || {};
    const kept = Object.assign({}, (hd && hd.kept) || {});
    const origin = (hd && hd.origin) || {};
    const n = h('span', { class: 'ap-h2__n' });
    const count = () => { const open = list.filter(x => !x.done).length; n.textContent = open ? open + ' open' : 'All done'; };
    const sec = h('section', { class: 'ap-section', 'aria-labelledby': 'hd-h-last' },
      h('h2', { class: 'ap-h2', id: 'hd-h-last', title: c.prev + '’s committee wrote these for this year’s' }, 'Notes from ' + c.prev, n));
    const redraw = {};
    list.forEach(x => sec.appendChild(noteCard(ctx, c, x, key, kept, origin[x.id], count, o, redraw)));
    count();
    // This year's copy removed (Notes for next year): Keep is offered again; put back: Kept again.
    if (o.bind) o.bind((id, on) => { if (on) kept[id] = true; else delete kept[id]; if (redraw[id]) redraw[id](); });
    return sec;
  };

  function noteCard(ctx, c, n, key, kept, from, after, o, redraw) {
    const ro = A.readonly || !c.can.write;
    const next = ctx.boot.year + 1;
    const box = h('input', { type: 'checkbox', class: 'ap-check', checked: n.done, disabled: ro, 'aria-label': 'Done' });
    const keepSlot = h('span', { class: 'hd-note__keep' });
    // A note kept from an earlier year says where it was first written ("Written Jul 1, 2026 · Kept in 2027").
    const when = from && from.year < c.prev ? 'Written ' + (from.on || from.year) + ' · Kept in ' + c.prev : n.on ? 'Written ' + n.on : '';
    const card = h('div', { class: 'ap-note hd-note' + (n.done ? ' is-done' : '') }, h('div', { class: 'ap-pre', text: n.body }),
      h('div', { class: 'ap-note__meta' }, h('label', { class: 'ap-switch' }, box, 'Done'), when ? h('span', { text: when }) : null, keepSlot));
    const setDone = d => { n.done = d; box.checked = d; card.classList.toggle('is-done', d); after(); };
    const drawKeep = () => {
      A.clear(keepSlot);
      if (kept[n.id]) keepSlot.appendChild(A.tag('Kept for ' + next, 'tan'));
      else if (!ro && hdOk(ctx)) keepSlot.appendChild(h('button', { type: 'button', class: 'ap-link', text: 'Keep for ' + next, title: 'Copies it into this year’s notes, so ' + next + '’s committee reads it too · Done stays yours to tick', on: { click: keep } }));
    };
    redraw[n.id] = drawKeep;
    box.addEventListener('change', () => {
      const want = box.checked;
      A.api('PATCH', '/app/notes/' + n.id + '?year=' + ctx.boot.year, { done: want }).then(() => {
        setDone(want);
        A.toast(want ? 'Done · Note from ' + c.prev : 'Reopened · Note from ' + c.prev, { undo: () => A.api('PATCH', '/app/notes/' + n.id + '?year=' + ctx.boot.year, { done: !want }).then(() => setDone(!want)).catch(A.fail) });
      }).catch(e => { box.checked = !want; A.fail(e); });
    });
    // Keep copies the note and nothing else: it stays open here until someone does what it says.
    function keep() {
      ctx.api('POST', 'handdown/keep?c=' + enc(key), { id: n.id }).then(r => {
        kept[n.id] = true;
        drawKeep();
        if (o.onKept) o.onKept({ id: r.copy || 0, src: n.id, body: n.body, by: r.by || '', origin: r.origin || null });
        A.toast('Kept for ' + next + ' · In Notes for ' + next, { undo: () => ctx.api('POST', 'handdown/keep?c=' + enc(key), { id: n.id, undo: true }).then(() => {
          delete kept[n.id];
          drawKeep();
          if (o.onUnkept) o.onUnkept(r.copy || 0);
        }).catch(A.fail) });
      }).catch(A.fail);
    }
    drawKeep();
    return card;
  }
  // The keep route answers only where the hand-down loaded (its table is there).
  const hdOk = ctx => !!ctx.hd;

  /* ------------------------------------------------------------ last year's report */

  HD.lastReport = function (ctx, c, hd, open) {
    const r = c.last_report;
    const nums = (hd && hd.numbers && hd.numbers.last) || [];
    const said = r && r.answers.some(Boolean);
    if (!said && !nums.length) return null;
    // A report never sent says so: next year's committee tells a finished one from a half-typed draft.
    const det = h('details', { class: 'hd-report', open: open || null },
      h('summary', null, h('span', { class: 'hd-report__t', text: c.prev + ' report' }), r && r.sent ? h('span', { class: 'hd-report__s', text: 'Sent ' + r.sent }) : A.tag('Draft · Not sent', 'tan')));
    const inner = h('div', { class: 'hd-report__body' });
    // Under the questions as they were asked that year, not as they read now.
    const qs = lastQs(ctx, hd);
    if (said) r.answers.forEach((a, i) => { if (a) inner.appendChild(h('div', { class: 'ap-q' }, h('span', { class: 'ap-q__ask', text: qs[i] || 'Question ' + (i + 1) }), h('p', { class: 'ap-q__said', text: a }))); });
    if (nums.length) inner.append(h('h3', { class: 'hd-h3', text: 'Numbers' }), numbersRead(nums.filter(x => x.n !== ''), c.prev));
    det.appendChild(inner);
    return h('section', { class: 'ap-section', 'aria-label': c.prev + ' report' }, det);
  };

  const lastQs = (ctx, hd) => (hd && hd.last_questions && hd.last_questions.length ? hd.last_questions : ctx.boot.questions);
  HD.lastQs = lastQs;

  function numbersRead(rows, year, lastBy, prevY) {
    return h('table', { class: 'hd-numtable' },
      h('thead', null, h('tr', null, h('th', { text: 'What' }), h('th', { class: 'hd-num', text: String(year) }), lastBy ? h('th', { class: 'hd-num', text: String(prevY || year - 1) }) : null)),
      h('tbody', null, rows.map(x => h('tr', null, h('td', { text: x.what }), h('td', { class: 'hd-num', text: fmtN(x.n) }), lastBy ? h('td', { class: 'hd-num ap-muted', text: fmtN(lastBy[x.what.toLowerCase()] || '') }) : null))));
  }
  const fmtN = n => n === '' || n == null ? '' : Number(n).toLocaleString('en-US');

  /* ------------------------------------------------------------ How we work */

  HD.how = function (ctx, c, hd, key) {
    const sec = h('section', { class: 'ap-section', id: 'hd-how', 'aria-labelledby': 'hd-h-how' });
    const can = hd.can.how;
    const draw = () => {
      A.clear(sec);
      sec.hidden = false;
      const t = hd.how.text;
      sec.appendChild(h('h2', { class: 'ap-h2', id: 'hd-h-how', title: 'The committee’s own standards and the usual way · Kept for next year' }, 'How we work',
        can && t ? h('span', { class: 'ap-h2__act' }, h('button', { type: 'button', class: 'ap-link', text: 'Edit', on: { click: edit } })) : null));
      if (t) {
        sec.appendChild(h('p', { class: 'ap-pre ap-muted', text: t }));
        const meta = hd.how.from ? 'From ' + hd.how.from : [hd.how.by, hd.how.on].filter(Boolean).join(' · ');
        if (meta) sec.appendChild(h('p', { class: 'ap-quiet hd-meta', text: meta }));
      } else if (can) {
        sec.appendChild(A.empty({ title: 'Not written', line: 'Standards and the usual way, for next year’s ' + nameOf(c), action: A.btn('Write', { write: true, onClick: edit }) }));
      } else {
        sec.hidden = true;
      }
    };
    const edit = () => {
      A.clear(sec);
      const ta = h('textarea', { class: 'ap-textarea', rows: '9', maxlength: '6000', value: hd.how.text || '', 'aria-describedby': 'hd-how-help' });
      const err = h('div', { class: 'ap-err', role: 'alert' });
      const save = btn => {
        btn.disabled = true;
        ctx.api('PUT', 'handdown/how?c=' + enc(key), { text: ta.value }).then(r => {
          hd.how = r.how;
          A.toast('Saved · How we work');
          draw();
        }).catch(e => { btn.disabled = false; err.textContent = msg(e); });
      };
      const saveBtn = A.btn('Save', { primary: true, write: true, onClick: () => save(saveBtn) });
      sec.append(h('h2', { class: 'ap-h2', id: 'hd-h-how', text: 'How we work' }),
        h('label', { class: 'ap-field' }, h('span', { class: 'ap-sr', text: 'How we work' }), ta,
          h('span', { class: 'ap-help', id: 'hd-how-help', text: 'One a line · Kept for next year · About the work, not people' })),
        err, h('div', { class: 'ap-row' }, saveBtn, A.btn('Cancel', { ghost: true, onClick: draw })));
      ta.focus();
    };
    draw();
    return sec;
  };

  /* ------------------------------------------------------------ Contacts by role */

  HD.contacts = function (ctx, c, hd, key) {
    const sec = h('section', { class: 'ap-section', id: 'hd-contacts', 'aria-labelledby': 'hd-h-con' });
    const can = hd.can.write;
    let rows = hd.contacts.rows.slice();
    const save = list => ctx.api('PUT', 'handdown/contacts?c=' + enc(key), { rows: list }).then(r => {
      hd.contacts = r.contacts;
      rows = r.contacts.rows.slice();
      draw();
      return r;
    });
    const draw = () => {
      A.clear(sec);
      sec.hidden = false;
      sec.appendChild(h('h2', { class: 'ap-h2', id: 'hd-h-con', title: 'Offices and roles the committee calls · Kept for next year' }, 'Contacts',
        rows.length ? h('span', { class: 'ap-h2__n', text: String(rows.length) }) : null,
        can && rows.length ? h('span', { class: 'ap-h2__act' }, h('button', { type: 'button', class: 'ap-link', text: 'Add', on: { click: () => open(null) } })) : null));
      if (!rows.length) {
        if (can) sec.appendChild(A.empty({ title: 'None yet', line: 'Offices and roles you call · Never a volunteer’s own phone', action: A.btn('Add contact', { write: true, onClick: () => open(null) }) }));
        else sec.hidden = true;
        return;
      }
      const meta = hd.contacts.from ? 'From ' + hd.contacts.from : [hd.contacts.by, hd.contacts.on].filter(Boolean).join(' · ');
      if (meta) sec.appendChild(h('p', { class: 'ap-help hd-sub', text: meta }));
      sec.appendChild(h('ul', { class: 'hd-contacts' }, rows.map(r => h('li', null, h(can ? 'button' : 'div', {
        type: can ? 'button' : null, class: 'hd-contact', 'aria-label': can ? 'Open ' + r.role : null, on: can ? { click: () => open(r) } : null
      }, h('span', { class: 'hd-contact__role', text: r.role }),
        r.phone || r.email ? h('span', { class: 'hd-contact__how', text: [r.phone, r.email].filter(Boolean).join(' · ') }) : null,
        r.note ? h('span', { class: 'hd-contact__note', text: r.note }) : null)))));
    };
    // A contact opens in the record panel beside the page: its fields save as they're changed.
    function open(r) {
      const isNew = !r;
      const role = h('input', { class: 'ap-input', maxlength: '80', value: r ? r.role : '', 'data-autofocus': '', 'aria-describedby': 'hd-c-role' });
      const phone = h('input', { class: 'ap-input', maxlength: '40', inputmode: 'tel', value: r ? r.phone : '' });
      const email = h('input', { class: 'ap-input', type: 'email', maxlength: '120', value: r ? r.email : '' });
      const note = h('input', { class: 'ap-input', maxlength: '200', value: r ? r.note : '' });
      const err = h('div', { class: 'ap-err', role: 'alert' });
      const status = h('span', { class: 'ap-quiet', role: 'status' });
      const data = () => ({ id: r ? r.id : '', role: role.value, phone: phone.value, email: email.value, note: note.value });
      const check = () => {
        if (!role.value.trim()) { err.textContent = 'Role needed'; role.focus(); return false; }
        err.textContent = '';
        return true;
      };
      const commit = () => {
        if (!check()) return Promise.reject(null);
        const list = isNew ? rows.concat([data()]) : rows.map(x => x.id === r.id ? data() : x);
        status.textContent = 'Saving';
        return save(list).then(res => { status.textContent = 'Saved'; return res; }).catch(e => {
          status.textContent = '';
          err.textContent = msg(e);
          // Said at the field the server refused, and focused (e.g. "Phone · Numbers and ext. only").
          const f = { role, phone, email, note }[e && e.data && e.data.data && e.data.data.field];
          if (f) {
            f.setAttribute('aria-invalid', 'true');
            f.closest('.ap-field').appendChild(err);
            f.focus();
            f.addEventListener('input', () => { f.removeAttribute('aria-invalid'); err.textContent = ''; }, { once: true });
          }
          throw e;
        });
      };
      if (!isNew) [role, phone, email, note].forEach(i => i.addEventListener('change', () => { commit().then(() => { if (r) r.role = role.value; }).catch(() => {}); }));
      const body = [
        h('label', { class: 'ap-field' }, h('span', { text: 'Role' }), role, h('span', { class: 'ap-help', id: 'hd-c-role', text: 'A role or office, not a person' })),
        h('label', { class: 'ap-field' }, h('span', { text: 'Phone' }), phone, h('span', { class: 'ap-help', text: 'With ext. 12 when there is one' })),
        h('label', { class: 'ap-field' }, h('span', { text: 'Email' }), email),
        h('label', { class: 'ap-field' }, h('span', { text: 'Note' }), note, h('span', { class: 'ap-help', text: 'What to call them for' })),
        err
      ];
      const add = A.btn('Add', { primary: true, write: true, onClick: () => commit().then(() => { ctx.sp.close(true); A.toast('Added · ' + role.value.trim()); }).catch(() => {}) });
      const remove = A.btn('Remove', { danger: true, ghost: true, write: true, onClick: () => {
        const before = rows.slice();
        save(rows.filter(x => x.id !== r.id)).then(() => {
          ctx.sp.close(true);
          A.toast('Removed · ' + r.role, { undo: () => save(before).catch(A.fail) });
        }).catch(A.fail);
      } });
      ctx.sp.open({
        title: isNew ? 'Add contact' : r.role,
        body,
        foot: isNew ? [add] : [status, h('span', { style: { flex: '1' } }), remove]
      });
      if (isNew) role.addEventListener('keydown', e => { if (e.key === 'Enter') add.click(); });
    }
    draw();
    return sec;
  };

  /* ------------------------------------------------------------ Files */

  HD.files = function (ctx, c, hd, key, upload) {
    const sec = h('section', { class: 'ap-section', id: 'hd-files', 'aria-labelledby': 'hd-h-files' });
    const can = c.can.write && !A.readonly;
    const input = h('input', { type: 'file', hidden: true, multiple: true, accept: hd.file.accept || null });
    const W = window.OGC_WP || {};
    const base = (W.app || {}).files || '/wp-json/ogc/v1/app/files/';
    const files = c.files.slice();
    const meta = id => (hd.files && hd.files[id]) || {};
    // After an upload the list is read again and drawn here: the page stays where it is.
    const refresh = () => Promise.all([ctx.api('GET', 'committee?c=' + enc(key)), HD.load(ctx, key)]).then(([cc, h2]) => {
      files.splice(0, files.length, ...cc.files);
      c.files = cc.files;
      if (h2) { hd.files = h2.files; hd.next_year = h2.next_year; }
      draw();
    }).catch(() => A.reload());
    const up = list => upload(ctx, key, list, refresh);
    input.addEventListener('change', () => { up([...input.files]); input.value = ''; });
    const year = ctx.boot.year;
    const nextY = () => hd.next_year || year + 1;
    // Where a file stands for next year, said as it is (module-handdown.php, ogc_hd_file_sync).
    const where = (pass, st) => {
      const n = nextY();
      if (!pass) return st === 'theirs' ? { t: 'Kept in ' + n, why: n + '’s committee has made it theirs · Remove it on ' + n + '’s page' } : { t: 'Stays with ' + year, why: 'Not passed on to ' + n };
      if (st === 'in') return { t: 'In ' + n, why: 'In ' + n + '’s files now' };
      if (st === 'gone') return { t: 'Removed in ' + n, why: n + '’s committee removed it there' };
      return { t: 'Goes to ' + n, why: st === 'later' ? 'Once ' + year + ' is over' : 'When ' + n + ' is started' };
    };
    const draw = () => {
      A.clear(sec);
      sec.appendChild(h('h2', { class: 'ap-h2', id: 'hd-h-files', title: 'Kept here for this committee, the COA and next year’s committee · Never a public link' }, 'Files',
        files.length ? h('span', { class: 'ap-h2__n', text: String(files.length) }) : null,
        can ? h('span', { class: 'ap-h2__act' }, A.btn('Upload', { icon: 'upload', write: true, onClick: () => input.click() })) : null));
      sec.appendChild(input);
      if (!files.length && !can) { sec.hidden = true; return; }
      if (files.length) sec.appendChild(h('ul', { class: 'hd-files' }, files.map(f => h('li', null, row(f)))));
      if (can) {
        const drop = h('div', { class: 'ap-drop' }, h('span', { text: 'Drop files here' }), h('span', { class: 'hd-drop__rule', text: hd.file.words + ' · About the work, not people' }));
        ['dragenter', 'dragover'].forEach(ev => drop.addEventListener(ev, e => { e.preventDefault(); drop.classList.add('ap-drop--over'); }));
        ['dragleave', 'drop'].forEach(ev => drop.addEventListener(ev, () => drop.classList.remove('ap-drop--over')));
        drop.addEventListener('drop', e => { e.preventDefault(); up([...e.dataTransfer.files]); });
        sec.appendChild(drop);
      }
    };
    const row = f => {
      const m = meta(f.id);
      const href = base + f.id + '?_wpnonce=' + enc(W.nonce || '') + asQ();
      const noteSlot = h('div', { class: 'hd-file__note' });
      const drawNote = () => {
        A.clear(noteSlot);
        if (m.note) noteSlot.appendChild(can ? h('button', { type: 'button', class: 'hd-file__notebtn', title: 'Change what it’s for', text: m.note, on: { click: editNote } }) : h('span', { text: m.note }));
        else if (can) noteSlot.appendChild(h('button', { type: 'button', class: 'ap-link', text: 'Add note', title: 'What it’s for, for next year’s committee', on: { click: editNote } }));
      };
      function editNote() {
        A.clear(noteSlot);
        const inp = h('input', { class: 'ap-input hd-file__in', maxlength: '160', value: m.note || '', 'aria-label': 'What ' + f.name + ' is for', placeholder: 'What it’s for' });
        let done = false;
        const finish = keepIt => {
          if (done) return;
          done = true;
          if (!keepIt || inp.value.trim() === (m.note || '')) { drawNote(); return; }
          ctx.api('PATCH', 'handdown/file?c=' + enc(key), { id: f.id, note: inp.value }).then(r => { m.note = r.note; hd.files[f.id] = Object.assign(meta(f.id), m); drawNote(); A.toast('Saved · ' + f.name); }).catch(e => { A.fail(e); drawNote(); });
        };
        inp.addEventListener('keydown', e => { if (e.key === 'Enter') finish(true); else if (e.key === 'Escape') { e.stopPropagation(); finish(false); } });
        inp.addEventListener('blur', () => finish(true));
        noteSlot.appendChild(inp);
        inp.focus();
      }
      drawNote();
      const pass = h('input', { type: 'checkbox', checked: m.pass !== false, disabled: !can });
      const state = h('span', { class: 'hd-file__state' });
      const sw = h('label', { class: 'ap-switch hd-file__pass' }, pass, h('span', { text: 'Next year' }), state);
      const drawState = () => { const w = where(m.pass !== false, m.next || ''); state.textContent = w.t; sw.title = w.why; };
      drawState();
      pass.addEventListener('change', () => {
        const want = pass.checked;
        ctx.api('PATCH', 'handdown/file?c=' + enc(key), { id: f.id, pass: want }).then(r => {
          m.pass = r.pass;
          m.next = r.state;
          if (r.next) hd.next_year = r.next;
          hd.files[f.id] = Object.assign(meta(f.id), m);
          drawState();
          A.toast(where(r.pass, r.state).t + ' · ' + f.name);
        }).catch(e => { pass.checked = !want; A.fail(e); });
      });
      const from = m.from || 0;
      return h('div', { class: 'hd-file' }, A.icon('file'),
        h('div', { class: 'hd-file__main' },
          h('a', { class: 'ap-item__title', href, download: f.name, text: f.name }),
          h('span', { class: 'ap-item__why', text: [f.type, A.fmt.size(f.size), from && from !== ctx.boot.year ? 'From ' + from : f.on, from && from !== ctx.boot.year ? '' : f.by].filter(Boolean).join(' · ') }),
          noteSlot),
        sw,
        can ? h('button', { type: 'button', class: 'ap-link ap-link--quiet hd-file__rm', text: 'Remove', 'aria-label': 'Remove ' + f.name, on: { click: () => remove(f) } }) : h('span'));
    };
    function remove(f) {
      ctx.api('DELETE', '/app/files/' + f.id).then(() => {
        const i = files.indexOf(f);
        files.splice(i, 1);
        draw();
        A.toast('Removed · ' + f.name, { undo: () => ctx.api('PATCH', 'handdown/file?c=' + enc(key), { id: f.id, restore: true }).then(r => { if (r.state) meta(f.id).next = r.state; files.splice(Math.max(0, i), 0, f); draw(); }).catch(A.fail) });
      }).catch(A.fail);
    }
    draw();
    return sec;
  };

  /* ------------------------------------------------------------ this year's report */

  HD.report = function (ctx, c, hd, key) {
    const sec = h('section', { class: 'ap-section', id: 'ap-report', 'aria-labelledby': 'ap-h-report' });
    const qs = ctx.boot.questions;
    const r = c.report || { answers: [] };
    const can = c.can.write && !A.readonly;
    const after = c.phase === 'after';
    const year = ctx.boot.year;
    const state = h('span', { class: 'ap-h2__n' });
    // One rule with the COA's board and the workbooks (module-handdown.php, ogc_hd_report_row): Not
    // started · Draft · Sent · Changed since sending. An answer or a number typed is a start.
    let st = (hd.report && hd.report.status) || 'none';
    const setState = () => {
      state.textContent = st === 'sent' ? 'Sent ' + r.sent : st === 'changed' ? 'Changed since sending' : st === 'draft' ? (r.updated ? 'Draft · Saved ' + r.updated : 'Draft') : 'Not started';
      state.title = st === 'changed' ? 'Sent ' + r.sent + ' · Changed after · Send again so the COA has this one' : '';
    };
    setState();
    sec.appendChild(h('h2', { class: 'ap-h2', id: 'ap-h-report', title: 'The same for every committee: the COA’s questions, numbers and contacts · Next year’s committee reads it first' }, 'Report', state));
    if (!can) {
      if (!r.answers.some(Boolean) && !hd.numbers.rows.length) { sec.appendChild(A.empty({ title: 'Not written', line: 'Answered after the Conference' })); return sec; }
      const asked = hd.questions && hd.questions.length ? hd.questions : qs;
      r.answers.forEach((a, i) => a && sec.appendChild(h('div', { class: 'ap-q' }, h('span', { class: 'ap-q__ask', text: asked[i] || 'Question ' + (i + 1) }), h('p', { class: 'ap-q__said', text: a }))));
      const lastBy = {};
      (hd.numbers.last || []).forEach(x => { lastBy[x.what.toLowerCase()] = x.n; });
      if (hd.numbers.rows.length) sec.append(h('h3', { class: 'hd-h3', text: 'Numbers' }), numbersRead(hd.numbers.rows, year, hd.numbers.last.length ? lastBy : null, hd.prev));
      return sec;
    }
    const boxes = qs.map(() => h('textarea', { class: 'ap-textarea', rows: '3', maxlength: '6000' }));
    boxes.forEach((b, i) => { b.value = r.answers[i] || ''; });
    const started = r.answers.some(Boolean) || hd.numbers.rows.some(x => x.n !== '');
    const status = h('span', { class: 'ap-quiet', role: 'status' });
    // What it says now, to tell a change after sending (the server keeps the same fingerprint).
    const nums = numbersEdit(ctx, hd, key, year, status, () => recompute());
    const now = () => JSON.stringify([boxes.map(b => b.value.trim()), nums.values()]);
    let snap = st === 'sent' ? now() : null;
    const sendSlot = h('span', { class: 'hd-send__btn' });
    const drawSend = () => {
      const again = st === 'sent' || st === 'changed';
      A.clear(sendSlot).appendChild(A.btn(again ? 'Send again' : 'Send to the COA', { primary: after && st !== 'sent', write: true, onClick: send }));
    };
    function recompute() {
      if (st === 'sent' || st === 'changed') { if (snap != null) st = now() === snap ? 'sent' : 'changed'; } else st = boxes.some(b => b.value.trim()) || nums.any() ? 'draft' : 'none';
      setState();
      drawSend();
    }
    let t = 0;
    const save = sendIt => ctx.api('PUT', 'committee/report?c=' + enc(key), { answers: boxes.map(b => b.value), send: !!sendIt }).then(res => {
      Object.assign(r, res);
      if (sendIt) { snap = now(); st = 'sent'; }
      status.textContent = sendIt ? 'Sent ' + res.sent : 'Saved';
      recompute();
      // Stays on the report: the task "Report to the COA" ticks itself, and the page's tasks show it.
      if (sendIt) { A.toast('Sent to the COA · ' + c.name + ' report'); if (ctx.refresh) ctx.refresh(); }
    }).catch(e => { status.textContent = ''; A.fail(e); });
    boxes.forEach(b => b.addEventListener('input', () => { status.textContent = 'Saving'; clearTimeout(t); t = setTimeout(() => save(false), 900); }));
    function send() {
      if (!boxes.some(b => b.value.trim())) { boxes[0].focus(); A.toast('Answer at least one'); return; }
      clearTimeout(t);
      // Numbers still being typed are saved first, so what's sent is what's on the page.
      nums.flush().then(() => save(true));
    }
    const wrap = h('div', { hidden: !after && !started });
    qs.forEach((q, i) => wrap.appendChild(h('label', { class: 'ap-field' }, h('span', { text: (i + 1) + '. ' + q }), boxes[i])));
    wrap.appendChild(nums.el);
    // The contacts are kept on the page all year; the report says how many, and where to check them.
    const n = hd.contacts.rows.length;
    wrap.appendChild(h('div', { class: 'hd-repcon' }, h('h3', { class: 'hd-h3', text: 'Contacts by role' }),
      h('p', { class: 'ap-muted' }, n ? (n === 1 ? '1 contact' : n + ' contacts') + (hd.contacts.from ? ' · From ' + hd.contacts.from : '') + ' · ' : 'None yet · ',
        h('button', { type: 'button', class: 'ap-link', text: n ? 'Check them' : 'Add one', on: { click: () => {
          const s = document.getElementById('hd-contacts');
          if (!s) return;
          s.scrollIntoView({ block: 'center' });
          s.classList.add('hd-flash');
          setTimeout(() => s.classList.remove('hd-flash'), 1600);
          const b = s.querySelector('.hd-contact, .ap-empty .ap-btn');
          if (b) b.focus({ preventScroll: true });
        } } }))));
    drawSend();
    wrap.appendChild(h('div', { class: 'ap-row hd-send' }, sendSlot, status));
    if (!after && !started) {
      const show = A.btn('Start the report', { write: true, onClick: () => { wrap.hidden = false; show.remove(); quiet.remove(); boxes[0].focus(); } });
      const quiet = h('p', { class: 'ap-quiet', text: 'Answered after the Conference' });
      sec.append(quiet, show);
    }
    sec.appendChild(wrap);
    return sec;
  };

  // Numbers: last year's labels to fill in (only while this year's list was never saved: a list emptied
  // on purpose stays empty); saved as typed. → { el, flush(), values(), any() }
  function numbersEdit(ctx, hd, key, year, status, onSaved) {
    const box = h('div', { class: 'hd-nums' });
    const last = hd.numbers.last || [];
    const lastBy = {};
    last.forEach(x => { lastBy[x.what.toLowerCase()] = x.n; });
    const prevY = hd.prev || year - 1;
    let rows = hd.numbers.saved || hd.numbers.rows.length ? hd.numbers.rows.map(x => Object.assign({}, x))
      : last.map(x => ({ id: '', what: x.what, n: '', note: '' }));
    const err = h('div', { class: 'ap-err', role: 'alert' });
    let t = 0;
    const send = () => {
      t = 0;
      const sent = rows.filter(x => String(x.what).trim() || String(x.n).trim());
      const bad = sent.find(x => String(x.n).trim() && !/^-?[\d,]*\.?\d+$/.test(String(x.n).trim()));
      if (bad) { err.textContent = 'A number only · ' + (bad.what || 'Number'); return Promise.resolve(); }
      if (sent.find(x => !String(x.what).trim())) { err.textContent = 'Name the number'; return Promise.resolve(); }
      err.textContent = '';
      status.textContent = 'Saving';
      return ctx.api('PUT', 'handdown/numbers?c=' + enc(key), { rows: sent }).then(res => {
        (res.numbers.rows || []).forEach((x, i) => { if (sent[i]) sent[i].id = x.id; });
        hd.numbers.rows = res.numbers.rows;
        hd.numbers.saved = true;
        status.textContent = 'Saved';
        if (onSaved) onSaved();
      }).catch(e => { status.textContent = ''; err.textContent = msg(e); });
    };
    const later = () => { clearTimeout(t); t = setTimeout(send, 800); };
    const list = h('div', { class: 'hd-nums__rows' });
    const draw = focusLast => {
      A.clear(list);
      list.appendChild(h('div', { class: 'hd-nums__row hd-nums__head', 'aria-hidden': 'true' }, h('span', { text: 'What' }), h('span', { class: 'hd-num', text: String(year) }), h('span', { class: 'hd-num', text: last.length ? String(prevY) : '' }), h('span')));
      rows.forEach((x, i) => {
        const what = h('input', { class: 'ap-input', maxlength: '80', value: x.what, 'aria-label': 'What was counted', placeholder: 'What was counted' });
        const n = h('input', { class: 'ap-input hd-num', inputmode: 'decimal', maxlength: '14', value: x.n, 'aria-label': (x.what || 'Number') + ' · ' + year });
        what.addEventListener('input', () => { x.what = what.value; n.setAttribute('aria-label', (x.what || 'Number') + ' · ' + year); later(); });
        n.addEventListener('input', () => { x.n = n.value; later(); });
        const l = lastBy[String(x.what).toLowerCase()];
        list.appendChild(h('div', { class: 'hd-nums__row' }, what, n,
          h('span', { class: 'hd-num ap-muted', title: l != null && l !== '' ? prevY + ': ' + fmtN(l) : null, text: l != null && l !== '' ? fmtN(l) : '' }),
          A.btn('Remove ' + (x.what || 'row'), { ghost: true, iconOnly: true, icon: 'x', write: true, onClick: () => { rows.splice(i, 1); draw(); clearTimeout(t); send(); } })));
        if (focusLast && i === rows.length - 1) setTimeout(() => what.focus(), 0);
      });
    };
    draw();
    // (append() writes a null as the word "null": only nodes go in.)
    box.append(...[h('h3', { class: 'hd-h3', title: 'The same counts each year, so next year’s committee can compare' }, 'Numbers'),
      rows.length ? null : h('p', { class: 'ap-help', text: 'Counts next year’s committee compares · Chairs set, meals served, callers' }),
      list, err,
      h('button', { type: 'button', class: 'ap-link hd-nums__add', text: 'Add number', on: { click: () => { rows.push({ id: '', what: '', n: '', note: '' }); draw(true); } } })].filter(Boolean));
    return {
      el: box,
      flush: () => { if (!t) return Promise.resolve(); clearTimeout(t); return send(); },
      values: () => rows.filter(x => String(x.what).trim() || String(x.n).trim()).map(x => [String(x.what).trim().toLowerCase(), String(x.n).replace(/[,\s]/g, '')]),
      any: () => rows.some(x => String(x.n).trim() !== '')
    };
  }

  /* ------------------------------------------------------------ Export and Print */

  HD.exportBtn = function (ctx, c, hd, key) {
    const KK = K();
    if (!KK.more) return null;
    const year = ctx.boot.year;
    const file = year + ' ' + nameOf(c) + ' hand-down';
    const get = (fmt, name) => KK.fetchFile('app/' + year + '/handdown/export?c=' + enc(key) + '&format=' + fmt + asQ(), name)
      .then(() => A.toast('Downloaded · ' + name))
      .catch(e => A.toast(e && e.status === 413 ? 'Too large to zip · Download the files one by one' : 'Not downloaded'));
    return KK.more('Export', [
      { label: 'Print', run: () => HD.print(ctx, c, hd) },
      { label: 'Excel', run: () => get('xlsx', file + '.xlsx') },
      c.files && c.files.length ? { label: 'Excel and files (.zip)', run: () => get('zip', file + '.zip') } : null
    ], { icon: 'download' });
  };

  // "Your part": one printout made from the records (scope ch. 6 Q47; decisions #10), for a first
  // meeting or someone who reads on paper. Nothing typed for it.
  HD.print = function (ctx, c, hd) {
    const KK = K();
    if (!KK.print) return;
    const lines = t => String(t || '').split('\n').filter(x => x.trim()).map(x => h('p', { class: 'hd-p', text: x }));
    const named = (c.people || []).filter(pp => !/\*|@/.test(pp.name || ''));
    KK.print({
      title: nameOf(c), sub: 'Your part', who: 'Committee only',
      build: () => h('div', { class: 'hd-print' },
        c.duties ? [h('h2', { text: 'Responsibilities' }), lines(c.duties)] : null,
        hd.how.text ? [h('h2', { text: 'How we work' }), lines(hd.how.text)] : null,
        named.length ? [h('h2', { text: 'People' }), h('p', { text: named.map(pp => pp.name + (pp.head ? ' (Head)' : '')).join(' · ') })] : null,
        hd.contacts.rows.length ? [h('h2', { text: 'Contacts' }), h('table', null, h('thead', null, h('tr', null, ['Role', 'Phone', 'Email', 'Note'].map(x => h('th', { text: x })))),
          h('tbody', null, hd.contacts.rows.map(x => h('tr', null, h('td', { text: x.role }), h('td', { text: x.phone }), h('td', { text: x.email }), h('td', { text: x.note })))))] : null,
        c.tasks.length ? [h('h2', { text: 'Tasks' }), h('table', null, h('thead', null, h('tr', null, ['Task', 'Due', 'Done'].map(x => h('th', { text: x })))),
          h('tbody', null, c.tasks.map(t => h('tr', null, h('td', { text: t.title }), h('td', { text: t.due_words || '' }), h('td', { text: t.done ? (t.done_on || 'Done') : '' })))))] : null,
        (c.last_notes || []).length ? [h('h2', { text: 'Notes from ' + c.prev }), h('ul', null, c.last_notes.map(n => h('li', { text: n.body + (n.done ? ' (Done)' : '') })))] : null,
        c.last_report && c.last_report.answers.some(Boolean) ? [h('h2', { text: c.prev + ' report' + (c.last_report.sent ? '' : ' (Draft, not sent)') }), c.last_report.answers.map((a, i) => a ? h('p', null, h('b', { text: (lastQs(ctx, hd)[i] || 'Question ' + (i + 1)) + ' ' }), a) : null)] : null,
        (hd.numbers.last || []).length ? [h('h2', { text: c.prev + ' numbers' }), h('table', null, h('tbody', null, hd.numbers.last.filter(x => x.n !== '').map(x => h('tr', null, h('td', { text: x.what }), h('td', { class: 'hd-n', text: fmtN(x.n) })))))] : null,
        c.files.length ? [h('h2', { text: 'Files' }), h('ul', null, c.files.map(f => h('li', { text: f.name + ((hd.files[f.id] || {}).note ? ' · ' + hd.files[f.id].note : '') })))] : null,
        h('p', { class: 'hd-print__foot', text: 'Kept in the app on ' + poss(nameOf(c)) + ' page · This printout is a copy' }))
    });
  };

  /* ------------------------------------------------------------ the COA's view on Committees */

  HD.board = function (ctx, sp) {
    const year = ctx.boot.year;
    const wait = h('div', { class: 'ap-quiet', style: { padding: '20px' }, role: 'status', text: 'Loading' });
    sp.main.appendChild(wait);
    ctx.api('GET', 'handdown/board').then(d => {
      wait.remove();
      const L = d.committees;
      const any = f => L.some(f);
      const prev = d.prev;
      const reports = d.phase === 'after' || any(x => x.report && x.report !== 'none');
      const num = n => n ? String(n) : '';
      const repTag = x => x.report === 'sent' ? A.tag('Sent ' + x.sent, 'ok') : x.report === 'changed' ? A.tag('Changed since sending', 'tan') : x.report === 'draft' ? A.tag('Draft', 'tan') : h('span', { class: 'ap-muted', text: 'Not started' });
      // A row opens that committee's report beside the list (↑ ↓ go to the next); its page is one link.
      let table = null;
      const open = x => {
        if (table) table.querySelectorAll('tr[data-key]').forEach(tr => tr.setAttribute('aria-selected', String(tr.dataset.key === x.key)));
        A.setParams({ id: x.key });
        const d = x.read;
        const body = [];
        if (d) {
          body.push(h('p', { class: 'hd-panel__state' }, repTag(x)));
          const said = d.answers.some(a => String(a || '').trim());
          if (said) d.answers.forEach((a, i) => { if (String(a || '').trim()) body.push(h('div', { class: 'ap-q' }, h('span', { class: 'ap-q__ask', text: d.questions[i] || 'Question ' + (i + 1) }), h('p', { class: 'ap-q__said', text: a }))); });
          const lastBy = {};
          d.last.forEach(n => { lastBy[n.what.toLowerCase()] = n.n; });
          const rows = d.numbers.filter(n => n.n !== '');
          if (rows.length) body.push(h('h3', { class: 'hd-h3', text: 'Numbers' }), numbersRead(rows, year, d.last.length ? lastBy : null, prev));
          if (!said && !rows.length) body.push(A.empty({ title: 'Not started', line: d.last.length || x.last_report !== 'none' ? 'Answered after the Conference' : 'The COA’s questions and the numbers' }));
        } else {
          body.push(h('p', { class: 'ap-muted', text: 'The COA writes no report to itself' }));
        }
        const i = L.indexOf(x);
        const step = by => { const y2 = L[i + by]; if (y2) open(y2); };
        sp.open({
          title: x.name + (x.key === 'coa' ? '' : ' report'),
          body,
          foot: [A.btn('Previous', { ghost: true, icon: 'up', disabled: i <= 0, title: 'The committee above (↑)', onClick: () => step(-1) }),
            A.btn('Next', { ghost: true, icon: 'down', disabled: i >= L.length - 1, title: 'The committee below (↓)', onClick: () => step(1) }),
            h('span', { style: { flex: '1' } }),
            A.link({ c: x.key, v: '', id: '', at: x.key === 'coa' ? '' : 'report' }, 'Open page', 'ap-btn')],
          onClose: () => { A.setParams({ id: '' }); if (table) table.querySelectorAll('tr[data-key]').forEach(tr => tr.setAttribute('aria-selected', 'false')); }
        });
      };
      table = A.table({
        label: 'Hand-down', rows: L, key: x => x.key, selected: ctx.params.id || '',
        onOpen: open,
        cols: [
          { label: 'Committee', render: x => h('span', { class: 'ap-cell-title', text: x.name }) },
          prev && any(x => x.last_notes) ? { label: 'Notes from ' + prev, cls: 'ap-td--nowrap', render: x => x.last_notes ? (x.last_open ? x.last_open + ' of ' + x.last_notes + ' open' : 'All ' + x.last_notes + ' done') : '' } : null,
          prev && any(x => x.last_report !== 'none') ? { label: prev + ' report', cls: 'ap-td--nowrap', render: x => x.last_report === 'sent' || x.last_report === 'changed' ? 'Sent' : x.last_report === 'draft' ? 'Draft · Not sent' : '' } : null,
          any(x => x.checked || x.unchecked) ? { label: 'Checked', cls: 'ap-td--nowrap', wide: true, render: x => x.checked ? A.tag('Looks right', 'ok') : x.unchecked ? h('span', { class: 'ap-muted', text: 'Not checked' }) : '' } : null,
          any(x => x.how) ? { label: 'How we work', cls: 'ap-td--nowrap', wide: true, render: x => x.how ? 'Written' : '' } : null,
          any(x => x.contacts) ? { label: 'Contacts', cls: 'ap-td--num', wide: true, render: x => num(x.contacts) } : null,
          any(x => x.files) ? { label: 'Files', cls: 'ap-td--num', wide: true, render: x => num(x.files) } : null,
          any(x => x.notes) ? { label: 'Notes for ' + (year + 1), cls: 'ap-td--num', wide: true, render: x => num(x.notes) } : null,
          reports ? { label: 'Report', cls: 'ap-td--nowrap', render: x => x.key === 'coa' ? '' : repTag(x) } : null
        ].filter(Boolean)
      });
      // With a report open, ↑ ↓ on the list open the one above or below.
      table.addEventListener('keydown', e => {
        if ((e.key !== 'ArrowDown' && e.key !== 'ArrowUp') || !sp.isOpen) return;
        const sel = table.querySelector('tr[aria-selected="true"]');
        const x = sel && L.find(r => r.key === sel.dataset.key);
        if (x) open(x);
      });
      sp.main.appendChild(table);
      const pre = ctx.params.id && L.find(x => x.key === ctx.params.id);
      if (pre) open(pre);
    }).catch(() => { wait.remove(); sp.main.appendChild(A.empty({ title: 'Not loaded', line: 'Reload the page', inset: true })); });
  };

  HD.reportsBtn = function (ctx) {
    const KK = K();
    const year = ctx.boot.year;
    return A.btn('Export reports', { icon: 'download', title: 'Every committee’s report, numbers, contacts and notes in one workbook', onClick: () => KK.fetchFile('app/' + year + '/handdown/reports?format=xlsx' + asQ(), year + ' Committee reports.xlsx')
      .then(() => A.toast('Downloaded · Committee reports')).catch(() => A.toast('Not downloaded')) });
  };
})();
