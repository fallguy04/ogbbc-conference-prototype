/*
 * coa-requests.js — Requests: a committee's part of the year's round (night-requests, Oct 13;
 * includes/module-requests.php). Everything the committee tells the others, filled in from last year,
 * answered once: Keep · Change · Remove · Not sure, then Return.
 *
 *   - Requests to the campus (needs.csv, from the last Conference at the campus), folded by event.
 *     Answers go through coa/{y}/needs, stamped on the server.
 *   - Packet: the parts of the information packet the committee answers for, and its Help card(s).
 *     Change writes the new words into the packet itself (guide.csv / help.csv, history kept).
 *   - Contact: who heads it (the COA changes that on Members; Not sure tells them) and its phone.
 *   - Not sure asks what's unclear and goes to the coordinator's To settle (Intake), never the webmasters.
 *   - Return when nothing is left; Change answers reopens it.
 *   - Template (Excel, with an Answer column) and Upload: matched by ID, else by committee and item
 *     exactly; nothing changes until Apply.
 *
 * A committee sees only its own (the server filters and refuses the rest). The coordinator (the COA,
 * or the committee holding Intake) opens any committee's from Intake.
 *
 * window.OGC_REQ: the pieces coa-intake.js shares (stock, export for campus, template, upload).
 */
(function () {
  'use strict';
  const A = window.OGC_APP, K = window.OGC_COA, O = window.OGC, ED = window.ED;
  if (!A || !K || !ED) return;
  const h = A.h;
  const R = window.OGC_REQ = {};
  // Set-up days come before the Friday; the Conference's own days follow it.
  const DAYS = ['Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday', 'Monday', 'Tuesday'];
  const ANSWER = R.ANSWER = { keep: 'Kept', change: 'Changed', remove: 'Removed', notsure: 'Not sure', new: 'New' };
  const ANSWER_IN = { keep: 'keep', kept: 'keep', change: 'change', changed: 'change', remove: 'remove', removed: 'remove', 'not sure': 'notsure', notsure: 'notsure', new: 'new' };
  const ckey = R.ckey = n => String(n || '').replace(/\s+/g, ' ').trim().toLowerCase().replace(/^the\s+|\s+committee$/g, '').trim();
  const norm = x => String(x || '').trim().toLowerCase().replace(/\s+/g, ' ');
  const dayIx = n => { const i = DAYS.indexOf(n); return i < 0 ? 99 : i; };

  /*
   * Exact fields (docs/25): what's typed is read as it is, or refused, never reread. The server checks
   * the same (module-requests.php ogc_round_need_check).
   *   Days: one day name, or two joined by "–", "-", "to" or "through" ("Fri thru Tue" and "Sat, Sun"
   *   are refused). A day is its name or its usual short form (Fri, Tues, Thurs), never a guess from
   *   its first letters.
   *   Qty: a whole number, 1 or more ("6-8" and "2 or 3" are refused).
   *   Times: as the app reads times ("9:00 AM", "9am", "noon"), written "9:00 AM"; both or neither.
   */
  const SHORT_DAY = { wed: 'Wednesday', thu: 'Thursday', thur: 'Thursday', thurs: 'Thursday', fri: 'Friday', sat: 'Saturday', sun: 'Sunday', mon: 'Monday', tue: 'Tuesday', tues: 'Tuesday' };
  const dayExact = v => { const t = norm(v).replace(/\.$/, ''); return DAYS.find(x => x.toLowerCase() === t) || SHORT_DAY[t] || ''; };
  R.readDays = function (text) {
    const t = String(text == null ? '' : text).trim();
    if (!t) return { first_day: '', last_day: '' };
    const parts = t.split(/\s*[–—-]\s*|\s+(?:to|through)\s+/i);
    const a = dayExact(parts[0]), b = parts.length > 1 ? dayExact(parts[1]) : '';
    if (parts.length > 2 || !a || (parts.length > 1 && !b)) return { error: 'Day names · Friday–Tuesday' };
    if (b && DAYS.indexOf(b) < DAYS.indexOf(a)) return { error: 'The last day after the first' };
    return { first_day: a, last_day: b && b !== a ? b : '' };
  };
  R.readQty = v => { const t = String(v == null ? '' : v).trim(); return /^\d{1,4}$/.test(t) && +t >= 1 ? String(+t) : null; };
  // '' for empty, null when it doesn't read as a time.
  R.readTime = v => { const t = String(v == null ? '' : v).trim(); if (!t) return ''; const m = O.parseTime(t); return m == null ? null : O.formatTime(m); };
  // Kept, changed or new with no days or no place: it can't go to the campus like that.
  R.incomplete = r => ['keep', 'change', 'new'].indexOf(r.answer) > -1 && (!String(r.first_day || '').trim() || !String(r.building || '').trim());
  const missing = r => [!String(r.first_day || '').trim() ? 'days' : '', !String(r.building || '').trim() ? 'place' : ''].filter(Boolean);
  // What a row had when it was carried this year, where a change moved it ({} when nothing moved).
  R.wasOf = (r, year) => { try { const w = r.was ? JSON.parse(r.was) : null; if (!w || +w.in !== +year) return {}; delete w.in; return w; } catch (e) { return {}; } };
  const splitWhere = w => { const m = String(w || '').trim().match(/^(.*?)\s+(\d[\w/-]*)$/); return m ? { building: m[1], room: m[2] } : { building: String(w || '').trim(), room: '' }; };
  const whereOf = R.whereOf = r => [r.building, r.room].filter(Boolean).join(' ');
  const daysOf = r => r.last_day && r.last_day !== r.first_day ? r.first_day + '–' + r.last_day : (r.first_day || '');
  const shortDays = r => !r.first_day ? '' : r.last_day && r.last_day !== r.first_day ? r.first_day.slice(0, 3) + '–' + r.last_day.slice(0, 3) : r.first_day.slice(0, 3);
  // An event with no name is headed by its days ("Sunday", "Fri–Tue").
  const eventName = r => r.for || (!r.first_day ? 'Days to set' : r.last_day && r.last_day !== r.first_day ? shortDays(r) : r.first_day);
  const supShort = t => String(t || '').replace(/^IWU |^Cedarville /, '');
  const timeOf = r => { const a = O.parseTime(r.start), b = O.parseTime(r.end); return a != null && b != null ? O.formatRange(a, b <= a ? b + 1440 : b) : a != null ? O.formatTime(a) : 'All day'; };
  const eventKey = r => [r.for, r.first_day, r.last_day, r.start, r.end, r.building, r.room].map(norm).join('|');
  const plural = A.fmt.plural;
  const md = K.md;

  /* ================================================================== shared pieces (OGC_REQ) */

  // The days a list covers, in order, with their dates (from the year's first day, the Friday).
  R.days = function (d) {
    const conf = (d.S.days || 'Friday|Saturday|Sunday|Monday|Tuesday').split('|').filter(Boolean);
    const fri = d.S.first_day || '';
    const list = ['Wednesday', 'Thursday'].concat(conf);
    return list.map(name => ({ name, date: fri ? O.isoAddDays(fri, DAYS.indexOf(name) - 2) : '' }));
  };
  const dayLabel = (d, name) => { const x = R.days(d).find(z => z.name === name); return x && x.date ? K.wd(x.date) : name; };

  // How many of each item at once, each day: what the campus sets out ("Most at once").
  R.stock = function (rows, d) {
    const days = R.days(d).map(x => x.name), out = {}, ours = {};
    let noDay = 0;
    rows.filter(r => r.answer !== 'remove' && r.item).forEach(r => {
      const a = days.indexOf(r.first_day), b = r.last_day ? days.indexOf(r.last_day) : a, q = +r.qty || 1;
      if (a < 0) { noDay++; return; }
      const into = /we bring/i.test(r.supplied_by || '') ? ours : out;
      const s = O.parseTime(r.start), e = O.parseTime(r.end), span = s != null && e != null ? [s, e <= s ? e + 1440 : e] : [0, 1440];
      for (let i = a; i <= Math.max(a, b); i++) ((into[r.item] = into[r.item] || days.map(() => []))[i]).push([span[0], span[1], q]);
    });
    const peak = list => { const ev = []; list.forEach(([s, e, n]) => { ev.push([s, n], [e, -n]); }); ev.sort((x, z) => x[0] - z[0] || x[1] - z[1]); let c = 0, m = 0; ev.forEach(([, n]) => { c += n; m = Math.max(m, c); }); return m; };
    const of = o => Object.keys(o).sort().map(k => { const n = o[k].map(peak); return { item: k, n, most: Math.max.apply(null, n) }; }).filter(x => x.most > 0);
    // Only the days anything is asked for (set-up days drop out when nothing is set up).
    const used = days.map((x, i) => Object.values(out).concat(Object.values(ours)).some(list => list[i] && list[i].length));
    const keep = (arr) => arr.filter((x, i) => used[i]);
    const a = of(out).map(x => Object.assign(x, { n: keep(x.n) })), b = of(ours).map(x => Object.assign(x, { n: keep(x.n) }));
    return { days: keep(days), rows: a, ours: b, noDay };
  };
  R.stockFold = function (rows, d) {
    const s = R.stock(rows, d);
    if (!s.rows.length) return null;
    const table = list => h('div', { class: 'ap-tablewrap' }, h('table', { class: 'ap-table cx-stock' },
      h('thead', null, h('tr', null, h('th', { scope: 'col', text: 'Item' }), s.days.map(x => h('th', { scope: 'col', class: 'ap-td--num', text: x.slice(0, 3) })), h('th', { scope: 'col', class: 'ap-td--num', text: 'Most' }))),
      h('tbody', null, list.map(x => h('tr', null, h('th', { scope: 'row', text: x.item }), x.n.map(k => h('td', { class: 'ap-td--num' + (k ? '' : ' ap-td--muted'), text: k ? String(k) : '·' })), h('td', { class: 'ap-td--num' }, h('b', { text: String(x.most) })))))));
    return h('details', { class: 'cx-more rq-stock' }, h('summary', null, h('span', { text: 'Most at once, by day' }), h('span', { class: 'ap-quiet', text: plural(s.rows.length, 'item') })),
      h('p', { class: 'ap-help', text: 'The most of each item needed at one time, each day · Kept, changed and new rows · What the campus sets out' }),
      s.noDay ? h('p', { class: 'cx-issue cx-issue--soft', text: plural(s.noDay, 'request') + ' · Days to set' }) : null, table(s.rows), s.ours.length ? [h('p', { class: 'ap-label', text: 'We bring' }), table(s.ours)] : null);
  };

  // An Excel file (or a CSV where the writer isn't loaded). A cell Excel would run is made text.
  R.saveXlsx = function (sheets, name) {
    const safe = val => { val = String(val == null ? '' : val); return /^[=+\-@\t\r]/.test(val) && !/^-?\d+(\.\d+)?$/.test(val) ? "'" + val : val; };
    if (!O.xlsx) { K.download(name + '.csv', sheets[0].rows[0], sheets[0].rows.slice(1)); return; }
    const blob = O.xlsx.write(sheets.map(s => Object.assign({}, s, { rows: s.rows.map(r => r.map(safe)) })));
    const a = h('a', { href: '#', download: name + '.xlsx' }); a.href = URL.createObjectURL(blob); document.body.appendChild(a); a.click(); setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 1000);
  };

  // What changed since the list was marked sent to the campus (its fingerprint per row).
  const hash = t => { let x = 5381; String(t).split('').forEach(c => { x = ((x << 5) + x + c.charCodeAt(0)) | 0; }); return (x >>> 0).toString(36); };
  const fp = R.fp = r => hash(['item', 'qty', 'for', 'first_day', 'last_day', 'start', 'end', 'building', 'room', 'notes'].map(k => String(r[k] == null ? '' : r[k]).trim()).join('|'));
  // Only rows that went to the campus as confirmed (kept, changed, new) are in what was sent: one
  // confirmed later is Added; one sent and now Not sure or To answer is Not confirmed; rows not
  // confirmed when sent and still not are `pending` (said on the sent line, never counted as sent).
  const confirmed = r => ['keep', 'change', 'new'].indexOf(r.answer) > -1;
  R.since = function (rows, sent) {
    if (!sent || !sent.rows) return null;
    const out = { added: [], changed: [], removed: [], unconfirmed: [], pending: [] }, seen = {};
    rows.filter(r => r.id).forEach(r => {
      seen[r.id] = 1;
      const was = r.id in sent.rows;
      if (confirmed(r) && !R.incomplete(r)) { if (!was) out.added.push(r); else if (sent.rows[r.id] !== fp(r)) out.changed.push(r); }
      else if (was) (r.answer === 'remove' ? out.removed : out.unconfirmed).push(r);
      else if (r.answer !== 'remove') out.pending.push(r);
    });
    Object.keys(sent.rows).forEach(id => { if (!seen[id]) out.removed.push({ id }); });
    out.n = out.added.length + out.changed.length + out.removed.length + out.unconfirmed.length;
    return out;
  };

  /*
   * Export for campus, in the venue's shape: By day and place (each day a row is needed, then each
   * place, its items and times, who provides them), Totals by day (the most of each item at once),
   * the whole list with its status, and what isn't confirmed yet in its own sheet. Only kept, changed
   * and new rows go to the campus; Not sure and unanswered rows are marked Not confirmed.
   */
  R.exportCampus = function (rows, d, o) {
    o = o || {};
    const venue = d.row.venue || d.S.venue || 'the campus';
    // Confirmed and complete go to the campus; the rest (not answered, Not sure, no days or place) are
    // in their own sheet.
    const ok = rows.filter(r => confirmed(r) && !R.incomplete(r));
    const not = rows.filter(r => r.answer !== 'remove' && ok.indexOf(r) < 0);
    const days = R.days(d);
    const status = r => r.answer === 'notsure' ? 'Not sure' : !r.answer ? 'To answer' : R.incomplete(r) ? 'No ' + missing(r).join(' or ') : ANSWER[r.answer];
    const when = r => { const a = O.parseTime(r.start), b = O.parseTime(r.end); return a != null && b != null ? [O.formatTime(a), O.formatTime(b)] : ['All day', '']; };
    // By day and place: a row for every day it's needed.
    const byDay = [['Day', 'Date', 'Place', 'Room', 'Item', 'Qty', 'Start', 'End', 'Provided by', 'Committee', 'For', 'Notes']];
    const lines = [];
    (o.only === 'changes' ? [] : ok).forEach(r => {
      const a = days.findIndex(x => x.name === r.first_day), b0 = r.last_day ? days.findIndex(x => x.name === r.last_day) : a, b = b0 < a ? a : b0;
      const t = when(r);
      if (a < 0) { lines.push([99, '', r.building || '', r, ['Days to set', '', r.building || '', r.room || '', r.item, r.qty || '1', t[0], t[1], r.supplied_by || '', r.committee, r.for || '', r.notes || '']]); return; }
      for (let i = a; i <= b; i++) lines.push([i, days[i].date, r.building || '', r, [days[i].name, days[i].date ? K.mdY(days[i].date, '') : '', r.building || '', r.room || '', r.item, r.qty || '1', t[0], t[1], r.supplied_by || '', r.committee, r.for || '', r.notes || '']]);
    });
    lines.sort((x, z) => x[0] - z[0] || String(x[2]).localeCompare(String(z[2])) || String(x[3].room || '').localeCompare(String(z[3].room || '')) || (O.parseTime(x[3].start) || 0) - (O.parseTime(z[3].start) || 0) || String(x[3].item).localeCompare(String(z[3].item)));
    lines.forEach(l => byDay.push(l[4]));
    const s = R.stock(ok, d);
    const totals = [['Item'].concat(s.days, ['Most at once'])].concat(s.rows.map(x => [x.item].concat(x.n, [x.most])));
    if (s.ours.length) { totals.push([], ['We bring']); s.ours.forEach(x => totals.push([x.item].concat(x.n, [x.most]))); }
    const head0 = ['Status', 'Committee', 'For', 'Item', 'Qty', 'Detail', 'Provided by', 'First day', 'Last day', 'Start', 'End', 'Building', 'Room', 'Notes', 'ID'];
    const line = (r, st) => [st, r.committee, r.for, r.item, r.qty, r.detail, r.supplied_by, r.first_day, r.last_day || r.first_day, r.start, r.end, r.building, r.room, r.notes, r.id];
    let all;
    if (o.only === 'changes') {
      const ch = R.since(rows, o.sent);
      all = [head0].concat(ch.added.map(r => line(r, 'New')), ch.changed.map(r => line(r, 'Changed')), ch.removed.map(r => line(r, 'Removed')), ch.unconfirmed.map(r => line(r, 'Not confirmed')));
    } else all = [head0].concat(ok.map(r => line(r, status(r))));
    const sheets = o.only === 'changes'
      ? [{ name: 'Changes', rows: all, widths: [10, 16, 22, 26, 5, 22, 16, 11, 11, 10, 10, 14, 7, 30, 7] }]
      : [{ name: 'By day and place', rows: byDay, widths: [11, 11, 22, 9, 26, 5, 10, 10, 16, 16, 22, 30] },
        { name: 'Totals by day', rows: totals, widths: [30].concat(s.days.map(() => 7), [12]) },
        { name: 'All requests', rows: all, widths: [10, 16, 22, 26, 5, 22, 16, 11, 11, 10, 10, 14, 7, 30, 7] }];
    if (o.only !== 'changes' && not.length) sheets.push({ name: 'Not confirmed', rows: [head0].concat(not.map(r => line(r, status(r)))), widths: [10, 16, 22, 26, 5, 22, 16, 11, 11, 10, 10, 14, 7, 30, 7] });
    R.saveXlsx(sheets, d.year + ' requests to ' + venue + (o.only === 'changes' ? ' (changes)' : ''));
  };

  // Template: a committee's rows (or several), with an Answer column and three empty rows for new ones.
  const TPL = ['ID', 'Committee', 'For', 'Item', 'Qty', 'Where', 'Days', 'Start', 'End', 'Provided by', 'Answer', 'Notes'];
  R.template = function (rows, coms, y, today) {
    const out = [TPL];
    coms.forEach(cm => {
      rows.filter(r => r.committee === cm).forEach(r => out.push([r.id || '', cm, r.for || '', r.item || '', r.qty || '', whereOf(r), daysOf(r), r.start || '', r.end || '', r.supplied_by || '', r.answer ? ({ keep: 'Keep', change: 'Change', remove: 'Remove', notsure: 'Not sure', new: 'New' })[r.answer] : '', r.notes || '']));
      for (let i = 0; i < 3; i++) out.push(['', cm, '', '', '', '', '', '', '', '', '', '']);
    });
    const how = [['How to fill it in'], ['Answer each row in the Answer column: Keep · Change (and change the row) · Remove · Not sure'], ['A new request: an empty row with its committee and item'], ['Leave the ID column as it is · It is how each row finds its way back'], ['Then Upload it on Requests'], ['Downloaded ' + today]];
    R.saveXlsx([{ name: 'Requests', rows: out, widths: [7, 16, 22, 26, 5, 18, 18, 10, 10, 16, 10, 30] }, { name: 'How to fill it in', rows: how, widths: [80], bold: true }], 'requests ' + (coms.length === 1 ? coms[0].toLowerCase().replace(/[^a-z0-9]+/g, '-') + ' ' : '') + y);
    A.toast('Downloaded · Fill it in, then Upload');
  };

  /*
   * Upload: a filled-in Template. Each row finds its own by its ID; a row without one, by committee and
   * item exactly (and, where that's still two rows, by For, Days and Start exactly). A row that still
   * matches two is left out and said ("Same item twice · Keep the ID"); nothing is guessed. Nothing
   * changes until Apply, which shows the tally first.
   *   o: { rows, listed (committee names), mine (keys or null for the coordinator), sp, file grid, name, send(body, said) }
   */
  R.plan = function (all, file, o) {
    const rows = o.rows, listed = o.listed, mine = o.mine;
    if (!all || all.length < 2) { A.toast('Nothing in ' + file); return; }
    const hd = all[0].map(x => norm(x)), at = (...hs) => { for (const x of hs) { const i = hd.indexOf(x); if (i > -1) return i; } return -1; };
    if (at('item') < 0 || at('committee') < 0) { A.toast(file + ' · Not a Template · It needs Committee and Item'); return; }
    const col = { id: at('id'), committee: at('committee'), for: at('for', 'used for'), item: at('item'), qty: at('qty'), where: at('where'), days: at('days'), start: at('start'), end: at('end'), from: at('provided by', 'from', 'supplied by'), answer: at('answer'), notes: at('notes') };
    const val = (row, k) => col[k] > -1 ? String(row[col[k]] == null ? '' : row[col[k]]).trim() : null;
    const used = new Set(), u = { ops: [], add: [], changes: [], per: {}, coms: new Set(), unknown: {}, refused: 0, twice: [], bad: [] };
    const bump = (c, k) => { const p = u.per[c] = u.per[c] || {}; p[k] = (p[k] || 0) + 1; };
    // A committee by its own name (or key), never by a near spelling.
    const canon = c => (rows.find(r => ckey(r.committee) === ckey(c)) || {}).committee || listed.find(n => ckey(n) === ckey(c)) || c;
    const time = v => R.readTime(v) || String(v || '').trim();
    const lastOf = x => x.last_day && x.last_day !== x.first_day ? x.last_day : '';
    all.slice(1).forEach(row => {
      let c = val(row, 'committee'); const it = val(row, 'item');
      if (!c || /^#/.test(c) || !it) return;
      c = canon(c);
      if (mine && mine.indexOf(ckey(c)) < 0) { u.refused++; return; }
      u.coms.add(c);
      if (!rows.some(r => r.committee === c) && !listed.some(n => ckey(n) === ckey(c))) u.unknown[c] = '';
      const said = ANSWER_IN[norm(val(row, 'answer'))] || '';
      const id = val(row, 'id'), days = val(row, 'days'), where = val(row, 'where');
      // Exact fields: a cell that doesn't read is left out and said, never reread ("6-8" isn't 68).
      const leaveOut = why => { const x = id ? rows.find(z => z.id === id) : null; if (x) used.add(x); u.bad.push(c + ' · ' + it + ' · ' + why); };
      const next = {};
      ['for', 'notes'].forEach(k => { if (val(row, k) != null) next[k] = val(row, k); });
      if (val(row, 'from') != null) next.supplied_by = val(row, 'from');
      if (val(row, 'qty') != null) { const q = R.readQty(val(row, 'qty')); if (q == null) { leaveOut('Qty not read · ' + (val(row, 'qty') || 'empty')); return; } next.qty = q; }
      if (days != null) { const dd = R.readDays(days); if (dd.error) { leaveOut('Days not read · ' + days); return; } Object.assign(next, dd); }
      if (val(row, 'start') != null || val(row, 'end') != null) {
        const s0 = val(row, 'start') || '', e0 = val(row, 'end') || '', st = R.readTime(s0), en = R.readTime(e0);
        if (st == null || en == null) { leaveOut('Time not read · ' + (st == null ? s0 : e0)); return; }
        if (!st !== !en) { leaveOut('Start and end, or neither · ' + (s0 || e0)); return; }
        next.start = st; next.end = en;
      }
      let r = id ? rows.find(x => x.id === id && !used.has(x)) : null;
      if (!r && !id) {
        let cand = rows.filter(x => !used.has(x) && ckey(x.committee) === ckey(c) && norm(x.item) === norm(it));
        if (cand.length > 1) {
          cand = cand.filter(x => (next.for === undefined || norm(x.for) === norm(next.for)) && (days == null || (norm(x.first_day) === norm(next.first_day) && norm(lastOf(x)) === norm(next.last_day))) && (next.start === undefined || norm(time(x.start)) === norm(next.start)) && (where == null || norm(whereOf(x)) === norm(where)));
          // Still not exactly one: which row it was can't be told, so it's left out (never added as new).
          if (cand.length !== 1) { u.twice.push(c + ' · ' + it); return; }
        }
        r = cand[0] || null;
      }
      if (!r) {
        if (said === 'remove') return;
        // A new request has what every request has: how many, its days and its place.
        const add = Object.assign({ committee: c, item: it }, next, where != null ? splitWhere(where) : {});
        if (!add.qty) { leaveOut('New · Qty missing'); return; }
        if (!add.first_day) { leaveOut('New · Days missing'); return; }
        if (!String(add.building || '').trim()) { leaveOut('New · Place missing'); return; }
        u.add.push(add); bump(c, 'new'); return;
      }
      used.add(r);
      if (where != null && norm(where) !== norm(whereOf(r))) next.where = where;
      const was = k => k === 'where' ? whereOf(r) : k === 'start' || k === 'end' ? time(r[k]) : k === 'last_day' ? lastOf(r) : r[k];
      const LABEL = { where: 'Where', for: 'For', qty: 'Qty', start: 'Start', end: 'End', notes: 'Notes', supplied_by: 'Provided by', first_day: 'Days', last_day: 'Last day' };
      const diffs = Object.keys(next).filter(k => norm(next[k]) !== norm(was(k)));
      const ans = said === 'remove' || said === 'notsure' ? said : diffs.length ? 'change' : said === 'new' ? 'keep' : said;
      if (!diffs.length && (!ans || ans === r.answer)) return;
      const op = { id: r.id };
      if (diffs.length && ans !== 'remove') { op.fields = {}; diffs.forEach(k => { if (k === 'where') Object.assign(op.fields, splitWhere(next.where)); else op.fields[k] = next[k]; }); if (op.fields.first_day !== undefined && op.fields.last_day === undefined) op.fields.last_day = next.last_day; }
      // Kept or changed with no days or no place: left out until the sheet (or the list) has them.
      const after = Object.assign({}, r, op.fields || {}, { answer: ans || r.answer });
      if (R.incomplete(after)) { u.bad.push(c + ' · ' + it + ' · No ' + missing(after).join(' or ')); return; }
      if (op.fields) u.changes.push(c + ' · ' + r.item + ': ' + diffs.map(k => (LABEL[k] || k) + ' ' + (next[k] || '—') + ' (was ' + (was(k) || '—') + ')').join(', '));
      if (ans && ans !== r.answer) op.answer = ans;
      if (ans === 'notsure') op.question = 'From the uploaded sheet' + (val(row, 'notes') ? ' · ' + val(row, 'notes') : '');
      if (op.fields || op.answer) { u.ops.push(op); bump(c, !op.answer || op.answer === 'change' ? 'changed' : op.answer); }
    });
    u.missing = rows.filter(r => u.coms.has(r.committee) && !used.has(r) && r.answer !== 'remove');
    const drop = new Set();
    const per = Object.keys(u.per).map(c => { const x = u.per[c]; return c + ': ' + [x.changed && x.changed + ' changed', x.new && x.new + ' new', x.keep && x.keep + ' kept', x.notsure && x.notsure + ' not sure', x.remove && x.remove + ' removed'].filter(Boolean).join(', '); });
    if (!per.length && !u.missing.length && !u.twice.length && !u.bad.length) { A.toast(file + ' · No changes'); return; }
    const pick = {};
    // Rows of the file's committees that the file doesn't have: left as they are unless ticked (a long
    // list folds, so a partial sheet doesn't bury the tally).
    function missingList() {
      const ul = h('ul', { class: 'cx-prevlist' }, u.missing.map(r => h('li', null, h('label', { class: 'ap-switch' }, h('input', { type: 'checkbox', class: 'ap-check', on: { change: e => { if (e.target.checked) drop.add(r.id); else drop.delete(r.id); } } }), h('span', { text: r.committee + ' · ' + r.item + ' × ' + (r.qty || '1') + (whereOf(r) ? ' · ' + whereOf(r) : '') })))));
      if (u.missing.length <= 8) return [h('p', { class: 'ap-label', text: 'Not in the file · Remove?' }), ul];
      return h('details', { class: 'cx-more' }, h('summary', null, h('span', { text: plural(u.missing.length, 'row') + ' not in the file' }), h('span', { class: 'ap-quiet', text: 'Left as they are · Tick to remove' })), ul);
    }
    const body = h('div', { class: 'cx-preview' },
      per.length ? h('ul', { class: 'cx-prevlist' }, per.map(t => h('li', { text: t }))) : null,
      u.changes.length ? [h('p', { class: 'ap-label', text: 'Changed' }), h('ul', { class: 'cx-prevlist' }, u.changes.slice(0, 30).map(t => h('li', { text: t })))] : null,
      Object.keys(u.unknown).length ? [h('p', { class: 'ap-label', text: 'Which committee?' }), Object.keys(u.unknown).map(n => K.field(n, K.pills(listed.map(x => [x, x]), '', pv => { pick[n] = pv; }), { tag: 'div', help: 'Not on this year’s list · Rows left out unless one is chosen' }))] : null,
      u.twice.length ? [h('p', { class: 'ap-label', text: 'Left out · Item listed more than once' }), h('ul', { class: 'cx-prevlist' }, u.twice.map(t => h('li', { text: t + ' · No ID to match it by' })))] : null,
      u.bad.length ? [h('p', { class: 'ap-label', text: 'Left out · Not read' }), h('p', { class: 'ap-help', text: 'Fix these in the sheet and upload it again, or change them on the list' }), h('ul', { class: 'cx-prevlist' }, u.bad.map(t => h('li', { text: t })))] : null,
      u.missing.length ? missingList() : null,
      u.refused ? h('p', { class: 'ap-quiet', text: plural(u.refused, 'row') + ' for other committees · Left as they are' }) : null);
    K.confirm(o.sp, { title: 'Upload · ' + file, lines: [], field: body, actLabel: 'Apply',
      act: () => {
        const ops = u.ops.slice(); drop.forEach(id => ops.push({ id, answer: 'remove' }));
        const add = u.add.filter(a => !(a.committee in u.unknown) || pick[a.committee]).map(a => Object.assign({}, a, { committee: pick[a.committee] || a.committee }));
        return o.send({ ops, add }, plural(ops.length, 'row') + ' answered · ' + plural(add.length, 'new request'));
      }, onDone: () => {} });
  };
  R.upload = function (o) {
    K.pick('.xlsx,.csv,.tsv,.txt').then(file => file && ED.files.read(file).then(got => R.plan(got.grid, file.name, o))).catch(err => A.toast(err && err.message ? err.message : 'Not read'));
  };

  // Answering requests: through the COA's route, stamped on the server.
  R.needs = (y, body) => K.api('POST', 'coa/' + y + '/needs', body);

  /* ================================================================== the screen */

  A.screen({
    id: 'requests', title: 'Requests', icon: 'box', section: 'own', who: ['committee'],
    render(ctx) {
      let alive = true;
      const y = ctx.params.year, v = ctx.boot.viewer, boot0 = ctx.boot;
      // The coordinator: whoever may open Intake (the COA, or the committee it was handed to).
      const coord = A.allowed('intake');
      const mine = (v.committees || []).map(c => c.key);
      let c = ctx.params.c;
      if (!c && mine.length) c = A.team() || mine[0];
      // Simple mode (screen-simple.js): this screen is a committee's packet and Help text, nothing of the round.
      const simple = !!(A.simple && A.simple());
      // The COA's own packet and Help is Packet; a committee's is reached with its key.
      if (simple && !c && A.allowed('packet')) { A.go({ s: 'packet', c: '', id: '', v: '' }, { replace: true }); return; }
      if (simple && !c) { ctx.head('Packet and Help', '', []); ctx.body.appendChild(A.empty({ title: 'No committee', line: 'Each committee’s own text', action: A.link({ s: 'home' }, 'Home', 'ap-btn'), inset: true })); return; }
      // The coordinator with no committee chosen: the round's board.
      if (!c && coord && !simple) { A.go({ s: 'intake', c: '', id: '', v: '' }, { replace: true }); return; }
      if (!c) { ctx.head('Requests', '', []); ctx.body.appendChild(A.empty({ title: 'No committee', line: 'Requests are by committee', inset: true })); return; }
      // Another committee's requests, for someone who isn't on it and doesn't run the round (the Nursery
      // head at &c=lodging): No access, naming whose, with the way to their own (Round 1, after the critic).
      const whose = ((boot0.committees.find(x => x.key === c) || {}).name || c) + '’s requests';
      const own = mine.length ? (A.team() || mine[0]) : '';
      const noAccess = () => A.noAccess(ctx, { title: 'Requests', line: whose, action: own ? A.link({ c: own }, 'Your requests', 'ap-btn') : null });
      if (!v.coa && !coord && !mine.includes(c)) { noAccess(); return; }
      ctx.head(simple ? 'Packet and Help' : 'Requests', '', []);
      K.loading(ctx.body);
      Promise.all([K.load(y), A.api('GET', 'round/mine?c=' + encodeURIComponent(c))]).then(([d, m]) => { if (alive) page(ctx, d, m, c, !!coord); }, err => { if (!alive) return; if (err && (err.status === 403 || err.status === 404)) noAccess(); else K.failed(ctx.body, err); });
      return () => { alive = false; };
    }
  });

  function page(ctx, d, m, c, coord) {
    const y = d.year, boot = ctx.boot;
    const simple = !!(A.simple && A.simple());
    const cname = m.committee.name;
    const ro = () => !!A.readonly || d.held || !m.can.answer;
    let rows = d.rowsOf('needs').filter(r => ckey(r.committee) === c).map(r => Object.assign({}, r));
    const places = d.rowsOf('places');
    const listed = boot.committees.filter(x => x.key !== 'coa').map(x => x.name);
    const asks = m.asks || [];

    A.clear(ctx.body);
    const sp = ctx.split();
    sp.el.classList.add('cx-split');
    const wrap = h('div', { class: 'cx-page rq-page' });
    sp.main.appendChild(wrap);
    const main = h('div', { class: 'rq-main' }), side = h('aside', { class: 'rq-side', 'aria-label': 'Your round' });
    wrap.appendChild(h('div', { class: 'ap-cols rq-cols' }, main, side));

    /* ------------------------------------------------------------ counts and the title row */
    // To answer, plus any kept with no days or no place (they can't go to the campus like that).
    const reqLeft = () => rows.filter(r => !r.answer || R.incomplete(r)).length;
    const left = () => (asks.indexOf('requests') > -1 ? reqLeft() : 0) + m.left.packet + m.left.help + m.left.contact;
    const total = () => (asks.indexOf('requests') > -1 ? rows.length : 0) + m.packet.length + m.help.length + (m.contact ? 1 : 0);
    function head() {
      if (simple) {
        // Simple mode: what's in it, and the way up to the committee's page.
        const n = [m.packet.length ? K.plural(m.packet.length, 'packet part') : '', m.help.length ? K.plural(m.help.length, 'Help card') : ''].filter(Boolean).join(' · ');
        const up = boot.viewer.coa ? { crumb: { label: cname, to: { s: 'committees', c, id: '', v: '' } } } : (boot.viewer.committees.length > 1 ? { crumb: { label: cname, to: { s: 'overview', c, id: '', v: '' } } } : null);
        ctx.head('Packet and Help', n, [], up);
        return;
      }
      const acts = [];
      if (rows.length && asks.indexOf('requests') > -1) acts.push(A.btn('Template', { ghost: true, icon: 'file', title: 'Your requests as an Excel sheet, with an Answer column · Fill it in, then Upload', onClick: () => R.template(rows, [cname], y, d.today) }));
      if (asks.indexOf('requests') > -1) acts.push(A.btn('Upload', { ghost: true, write: true, icon: 'upload', title: 'A filled-in Template (Excel or CSV)', onClick: () => R.upload({ rows, listed, mine: [c], sp, send }) }));
      const fact = m.returned ? 'Returned ' + md(m.returned) + (m.returned_by ? ' · ' + m.returned_by : '') : [left() ? left() + ' to answer' : 'All answered', m.due ? 'Due ' + md(m.due) + (m.late ? ' · Late' : '') : ''].filter(Boolean).join(' · ');
      // The way up names the committee: "Nursery / Requests" goes to Nursery's page (the COA, from the
      // page's Work row). Only a committee holding Intake, reading another's, has "Intake / Nursery"
      // (docs/27 area-shell D16; Round 1).
      const holder = coord && !boot.viewer.coa && boot.viewer.committees.every(x => x.key !== c);
      ctx.head(holder ? cname : 'Requests', fact, acts, holder ? { crumb: { label: 'Intake', to: { s: 'intake', c: '', id: '', v: '' } } }
        : boot.viewer.coa ? { crumb: { label: cname, to: { s: 'committees', c, id: '', v: '' } } }
        : (boot.viewer.committees.length > 1 ? { crumb: { label: cname, to: { s: 'overview', c, id: '', v: '' } } } : null));
    }

    /* ------------------------------------------------------------ the side card */
    function drawSide() {
      A.clear(side);
      if (simple) { side.hidden = true; return; }
      const n = total(), l = left();
      const status = m.returned ? A.tag('Returned', 'ok') : m.late ? A.tag('Late', 'late') : m.status === 'notsent' ? A.tag('Not sent yet') : A.tag(l ? (n - l ? 'Started' : 'To answer') : 'Answered', l ? 'tan' : 'ok');
      const card = h('div', { class: 'rq-card' },
        h('div', { class: 'rq-card__top' }, h('span', { class: 'rq-card__name', text: cname }), status),
        K.facts([
          m.due ? ['Due', md(m.due) + (m.late ? ' · Late' : '')] : null,
          ['From', m.from],
          m.sent ? ['Sent', md(m.sent)] : null
        ]),
        n ? h('div', { class: 'rq-meter', role: 'img', 'aria-label': (n - l) + ' of ' + n + ' answered' }, h('span', { style: { width: Math.round(100 * (n - l) / n) + '%' } })) : null,
        n ? h('p', { class: 'rq-card__line', text: (n - l) + ' of ' + n + ' answered' }) : null,
        h('ul', { class: 'rq-jump' },
          asks.indexOf('requests') > -1 && rows.length ? jump('rq-req', 'Requests to the campus', reqLeft()) : null,
          m.packet.length || m.help.length ? jump('rq-pk', 'Packet and Help', m.left.packet + m.left.help) : null,
          m.contact ? jump('rq-ct', 'Contact', m.left.contact) : null));
      if (m.returned) {
        card.appendChild(h('p', { class: 'rq-card__done' }, A.icon('check', 14), ' Returned ' + md(m.returned) + (m.returned_by ? ' · ' + m.returned_by : '')));
        if (m.can.reopen) card.appendChild(K.link('Change answers', reopen, { title: 'Opens your answers again · ' + m.from + ' sees it on the board' }));
      } else if (!A.readonly && !d.held) {
        if (m.can.answer && m.sent && !l) card.appendChild(A.btn('Return to ' + m.from, { primary: true, big: true, write: true, title: 'Your answers go to ' + m.from + ' · You can open them again', onClick: doReturn }));
        else if (m.status === 'notsent') card.appendChild(h('p', { class: 'ap-help', text: 'Not sent yet · Answers are kept' }));
        else card.appendChild(h('p', { class: 'ap-help', text: 'Return once every row is answered' }));
      }
      side.appendChild(card);
      if (m.notes && m.notes.length) {
        side.appendChild(h('section', { class: 'rq-notes', 'aria-label': 'Notes from last year' },
          h('p', { class: 'ap-label', text: 'Notes from ' + (y - 1) }),
          m.notes.map(nt => h('div', { class: 'ap-note' }, h('span', { text: nt.body })))));
      }
      if (m.shifts && m.shifts.n) {
        side.appendChild(h('div', { class: 'rq-shifts' }, h('p', { class: 'ap-label', text: 'Volunteer shifts' }),
          h('p', { class: 'rq-shifts__line' }, plural(m.shifts.n, 'shift'), ' · ', m.shifts.screen && A.allowed(m.shifts.screen) ? A.link({ s: m.shifts.screen, c, id: '', v: '' }, 'Open Helpers') : h('span', { class: 'ap-quiet', text: 'Set up with the volunteer sign-ups' }))));
      }
    }
    function jump(id, label, n) {
      return h('li', null, h('a', { href: '#' + id, on: { click: e => { e.preventDefault(); const t = document.getElementById(id); if (t) t.scrollIntoView({ behavior: matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth', block: 'start' }); } } }, h('span', { text: label }), h('span', { class: n ? 'rq-jump__n' : 'rq-jump__n is-done' }, n ? n + ' left' : A.icon('check', 13))));
    }

    /* ------------------------------------------------------------ the main column */
    function draw() {
      A.clear(main);
      if (simple) {
        if (m.packet.length || m.help.length) main.appendChild(packetSection());
        else main.appendChild(A.empty({ title: 'Nothing in the packet for ' + cname, line: 'The COA writes the packet', inset: true }));
        return;
      }
      if (!m.in) main.appendChild(h('div', { class: 'ap-banner', role: 'note' }, h('span', { text: 'Not in this year’s intake · ' + m.from + ' left ' + cname + ' out' })));
      if (m.status === 'notsent' && m.in) main.appendChild(h('div', { class: 'ap-banner', role: 'note' }, h('span', { text: 'Not sent yet · ' + m.from + ' sends it' + (m.due ? ' · Due ' + md(m.due) : '') })));
      if (asks.indexOf('requests') > -1) main.appendChild(requestsSection());
      if (m.packet.length || m.help.length) main.appendChild(packetSection());
      if (m.contact) main.appendChild(contactSection());
      if (!main.children.length) main.appendChild(A.empty({ title: 'Nothing asked of ' + cname, line: m.from + ' chooses what the intake asks', inset: true }));
    }
    const redraw = () => { draw(); drawSide(); head(); };

    /* ------------------------------------------------------------ requests to the campus */
    // Still to answer and complete (Keep the rest keeps these); still to answer or kept, with no days or place.
    const keepable = () => rows.filter(r => !r.answer && missing(r).length === 0);
    const unset = () => rows.filter(r => (!r.answer || R.incomplete(r)) && missing(r).length > 0);
    function requestsSection() {
      const l = reqLeft();
      const sec = h('section', { class: 'ap-section rq-sec', id: 'rq-req', 'aria-label': 'Requests to the campus' });
      const ns = rows.filter(r => r.answer === 'notsure').length;
      sec.appendChild(h('h2', { class: 'ap-h2 rq-h2' }, 'Requests to the campus', h('span', { class: 'ap-h2__n', text: rows.length ? [l ? l + ' to answer' : 'All answered', ns ? ns + ' not sure' : ''].filter(Boolean).join(' · ') : '' }),
        keepable().length && !ro() ? h('span', { class: 'ap-h2__act' }, A.btn(keepable().length === rows.length ? 'Keep all ' + rows.length : 'Keep the rest · ' + keepable().length, { icon: 'check', write: true, title: 'Keeps every request still to answer, as it was last year · ' + cname + ' only' + (unset().length ? ' · Not the ' + plural(unset().length, 'request') + ' with no days or place' : ''), onClick: () => { const n = unset().length; answer(keepable(), 'keep', plural(keepable().length, 'request') + ' kept' + (n ? ' · ' + n + ' need days or a place' : '')); } })) : null));
      if (unset().length && !ro()) sec.appendChild(h('p', { class: 'cx-issue cx-issue--soft', text: plural(unset().length, 'request') + ' with no days or no place · Set them, or mark Not sure' }));
      if (!rows.length) {
        sec.appendChild(A.empty({ title: 'No requests to the campus', line: 'Nothing carried from last time at this campus', action: A.btn('Add request', { write: true, icon: 'plus', onClick: () => addEvent() }) }));
        return sec;
      }
      sec.appendChild(h('p', { class: 'ap-help rq-help', text: 'What ' + cname + ' asked the campus for last time · Keep, Change, Remove or Not sure' }));
      const groups = [];
      rows.forEach(r => { const k = eventKey(r); let g = groups.find(x => x.k === k); if (!g) groups.push(g = { k, rows: [] }); g.rows.push(r); });
      groups.sort((a, b) => dayIx(a.rows[0].first_day) - dayIx(b.rows[0].first_day) || (O.parseTime(a.rows[0].start) || 0) - (O.parseTime(b.rows[0].start) || 0));
      groups.forEach(g => sec.appendChild(event(g)));
      if (!ro()) sec.appendChild(h('p', null, K.link('Add request', () => addEvent(), { icon: 'plus' })));
      return sec;
    }
    function event(g) {
      const r = g.rows[0], when = [r.for ? shortDays(r) : '', timeOf(r)].filter(Boolean).join(' · ');
      const sups = Array.from(new Set(g.rows.map(x => x.supplied_by || ''))), evSup = sups.length === 1 ? sups[0] : '';
      return h('section', { class: 'cx-ev' },
        h('header', { class: 'cx-ev__h' },
          h('div', null, h('p', { class: 'cx-ev__t', text: eventName(r) }),
            h('p', { class: 'cx-ev__m', text: [when, whereOf(r), supShort(evSup)].filter(Boolean).join(' · ') })),
          K.link('Edit event', () => editEvent(g), { title: 'Days, time or place for every item in it' })),
        h('ul', { class: 'cx-ev__items' }, g.rows.map(x => item(x, evSup))),
        h('p', { class: 'cx-ev__add' }, K.link('Add item', () => addItem(r), { icon: 'plus' })));
    }
    function item(r, evSup) {
      const notes = String(r.notes || '').trim();
      // A detail that only says the item again ("Easels" on Easel) isn't shown: letters compared, nothing more.
      const bare = x => norm(x).replace(/[^a-z0-9]+/g, '').replace(/s$/, '');
      const detail = r.detail && bare(r.detail) !== bare(r.item) ? r.detail : '';
      const was = R.wasOf(r, y), gaps = missing(r);
      const added = +r.added_in === +y;
      const fixLabel = 'Set ' + gaps.join(' and ');
      return h('li', { class: 'cx-need' + (r.answer ? ' is-' + r.answer : '') },
        h('div', { class: 'cx-need__main' },
          h('p', { class: 'cx-need__item' }, h('b', { text: r.item }), h('span', { class: 'ap-quiet', text: ' × ' + (r.qty || '1') }), r.supplied_by && r.supplied_by !== evSup ? h('span', { class: 'ap-tag', text: supShort(r.supplied_by) }) : null),
          detail || notes ? h('p', { class: 'cx-need__note', text: [detail, notes].filter(Boolean).join(' · ') }) : null,
          Object.keys(was).length ? h('p', { class: 'cx-need__was', text: 'Was ' + wasWords(r, was) }) : null,
          gaps.length && r.answer !== 'remove' && r.answer !== 'notsure' ? h('p', { class: 'cx-need__gap' }, 'No ' + gaps.join(' or '), ro() || !r.answer ? null : [' · ', K.link(fixLabel, () => editItem(r))]) : null,
          r.answer === 'notsure' && r.question ? h('p', { class: 'cx-need__q', text: '“' + r.question + '”' }) : null),
        h('div', { class: 'cx-need__side' }, answerBox(r.answer, [r.answered_by, md(r.answered_at)].filter(Boolean).join(' · '), r.item, {
          keep: () => answer([r], 'keep', 'Kept · ' + r.item),
          // No days or no place: it can't be kept as it is; the button says what's missing and opens the form.
          fix: gaps.length ? { label: fixLabel, run: () => editItem(r) } : null,
          change: () => editItem(r),
          notsure: () => ask(r.item, q => sendNeeds({ ops: [{ id: r.id, answer: 'notsure', question: q }] }, 'Not sure · ' + r.item)),
          remove: () => answer([r], 'remove', 'Removed · ' + r.item),
          // Undo puts back last year's values (the server keeps them); a request added this year has
          // none, so it's Removed instead, and Undo from there makes it New again.
          undo: r.answer === 'new' ? null : () => undoRow(r, was),
          undoLabel: r.answer === 'change' ? 'Undo change' : null,
          undoTip: r.answer === 'change' ? 'Back to last year’s: ' + wasWords(r, was) : added ? 'Back to New' : 'Back to To answer',
          after: r.answer === 'new' && !ro() ? K.link('Remove', () => answer([r], 'remove', 'Removed · ' + r.item)) : null
        }), r.answer && r.answer !== 'remove' ? K.link('Edit', () => editItem(r)) : null));
    }
    // "× 2 · Friday–Tuesday · 9:00 AM–5:00 PM · Barnes 133": what a changed row had, only where it moved.
    function wasWords(r, was) {
      const w = Object.assign({}, r, was), has = (...ks) => ks.some(k => k in was);
      return [
        has('item') ? w.item : '',
        has('qty') ? '× ' + (w.qty || '1') : '',
        has('for') ? (w.for ? 'For ' + w.for : 'No event') : '',
        has('first_day', 'last_day') ? daysOf(w) || 'No days' : '',
        has('start', 'end') ? timeOf(w) : '',
        has('building', 'room') ? whereOf(w) || 'No place' : '',
        has('supplied_by') ? supShort(w.supplied_by) || 'No one providing it' : '',
        has('detail') ? w.detail || 'No detail' : '',
        has('notes') ? (w.notes ? '“' + w.notes + '”' : 'No note') : ''
      ].filter(Boolean).join(' · ');
    }
    function undoRow(r, was) {
      const back = { id: r.id, answer: r.answer, question: r.answer === 'notsure' ? r.question : undefined };
      // Undo of the undo: the changed values go back on with the answer.
      if (r.answer === 'change' || Object.keys(was).length) { back.fields = {}; Object.keys(was).forEach(k => { back.fields[k] = r[k] || ''; }); }
      const said = r.answer === 'change' ? 'Back to last year’s · ' + r.item : +r.added_in === +y ? 'New again · ' + r.item : 'To answer · ' + r.item;
      sendNeeds({ ops: [{ id: r.id, answer: '' }] }, said, () => sendNeeds({ ops: [back] }, 'Undone'));
    }

    // One answer control, the same for every kind of row: Keep and Change in words, and Not sure ·
    // Remove under More (a click, never a hover). Answered: the word, who and when, and Undo.
    function answerBox(a, by, what, acts) {
      if (a && ANSWER[a]) {
        return h('div', { class: 'cx-ans' }, h('span', { class: 'cx-ans__w cx-ans--' + a }, a === 'remove' ? A.icon('x', 14) : a === 'notsure' ? null : A.icon('check', 14), ANSWER[a]),
          by ? h('span', { class: 'ap-quiet', text: by }) : null, ro() || !acts.undo ? null : K.link(acts.undoLabel || 'Undo', acts.undo, { title: acts.undoTip || 'Back to To answer' }), acts.after || null);
      }
      if (ro()) return h('span', { class: 'ap-quiet', text: 'To answer' });
      const more = [];
      if (acts.notsure) more.push({ label: 'Not sure', run: acts.notsure });
      if (acts.remove) more.push({ label: 'Remove', run: acts.remove });
      return h('div', { class: 'cx-ans cx-ans--btns', role: 'group', 'aria-label': 'Answer ' + what },
        acts.fix ? A.btn(acts.fix.label, { write: true, title: 'Days and place are needed to keep it', onClick: acts.fix.run }) : A.btn('Keep', { write: true, icon: 'check', onClick: acts.keep }),
        acts.change && !acts.fix ? A.btn('Change', { ghost: true, write: true, onClick: acts.change }) : null,
        more.length === 1 ? A.btn(more[0].label, { ghost: true, write: true, onClick: more[0].run }) : more.length ? A.btn('More', { ghost: true, write: true, icon: 'more', title: more.map(x => x.label).join(' · '), onClick: e => A.menu(e.currentTarget, more) }) : null);
    }

    function sendNeeds(body, said, undo) {
      return R.needs(y, body).then(res => {
        if (Array.isArray(res.rows)) rows = res.rows.filter(r => ckey(r.committee) === c).map(r => Object.assign({}, r));
        K.drop(y);
        const done = () => { redraw(); if (said) A.toast(said, undo ? { undo } : null); return res; };
        // A first answer starts the round on the server: its status comes back from there.
        if (m.status === 'sent' || m.status === 'opened') return A.api('GET', 'round/mine?c=' + encodeURIComponent(c)).then(nm => { m = nm; return done(); }, done);
        return done();
      }, err => { A.fail(err); throw err; });
    }
    const send = (body, said) => sendNeeds(body, said);
    function answer(rs, a, said) {
      if (!rs.length) return;
      const was = rs.map(r => ({ id: r.id, answer: r.answer || '', question: r.answer === 'notsure' ? r.question : undefined }));
      sendNeeds({ ops: rs.map(r => ({ id: r.id, answer: a })) }, said, () => sendNeeds({ ops: was }, 'Undone'));
    }
    function ask(what, go) {
      const q = K.textIn({ label: 'What’s unclear?', placeholder: 'Which gym? The schedule may move it', live: false, multiline: true, rows: 2 });
      const f = K.field('What’s unclear?', q, { help: 'Goes to ' + m.from + ' · They settle it with you' });
      K.confirm(sp, { title: 'Not sure · ' + what, lines: [], field: f, actLabel: 'Save',
        act: () => { const t = q.value.trim(); if (!t) { f.setError('Say what’s unclear'); return Promise.reject({ message: 'Say what’s unclear' }); } return go(t); }, onDone: () => {} });
      setTimeout(() => q.focus(), 0);
    }

    /* the request form: what, how many, days, time, where, who provides it, a note for people */
    const SUPPLIED = () => Array.from(new Set(d.rowsOf('needs').map(r => r.supplied_by).filter(Boolean).concat(['We bring'])));
    function form(r, isEvent) {
      const f = {};
      const t = (k, label, val, o) => { f[k] = K.textIn(Object.assign({ value: val || '', label, live: false }, o || {})); return K.field(label, f[k], { help: o && o.help }); };
      let sup = r.supplied_by || '';
      const dl = h('datalist', { id: 'rq-places' }, Array.from(new Set(places.map(p => p.name || p.building).filter(Boolean))).map(n => h('option', { value: n })));
      const body = h('div', { class: 'cx-rec' },
        isEvent ? null : t('item', 'Item', r.item, { placeholder: 'Easel' }),
        isEvent ? null : t('qty', 'Qty', r.qty, { inputmode: 'numeric', width: '96px' }),
        t('for', 'For', r.for, { placeholder: 'Preteen check-in', help: 'The meeting or room it’s for · Optional' }),
        h('div', { class: 'cx-two' }, t('days', 'Days', daysOf(r), { placeholder: 'Friday–Tuesday' }), t('where', 'Where', whereOf(r), { placeholder: 'Barnes 133' })),
        h('div', { class: 'cx-two' }, t('start', 'Start', r.start, { placeholder: 'All day' }), t('end', 'End', r.end, { placeholder: 'All day' })),
        isEvent ? null : K.field('Provided by', K.pills(SUPPLIED().map(s => [s, supShort(s)]), sup, val => { sup = val; }), { tag: 'div' }),
        isEvent ? null : t('notes', 'Note', r.notes, { multiline: true, rows: 2, help: 'For people · Goes to the campus with the request' }), dl);
      if (f.where) f.where.setAttribute('list', 'rq-places');
      // What's typed, as typed: days and times read exactly or refused at the field (never reread).
      const read = () => {
        const out = {};
        ['item', 'qty', 'for', 'start', 'end', 'notes'].forEach(k => { if (f[k]) out[k] = f[k].value.trim(); });
        if (f.where) Object.assign(out, splitWhere(f.where.value));
        if (f.days) { const dd = R.readDays(f.days.value); out.first_day = dd.error ? f.days.value.trim() : dd.first_day; out.last_day = dd.error ? '' : dd.last_day; }
        ['start', 'end'].forEach(k => { if (f[k]) { const tm = R.readTime(out[k]); if (tm) out[k] = tm; } });
        if (f.qty) { const q = R.readQty(out.qty); if (q) out.qty = q; }
        if (!isEvent) out.supplied_by = sup;
        return out;
      };
      // Every request has an item, how many (a whole number), its days and its place; times both or neither.
      const check = () => {
        let ok = true;
        const say = (el, msg) => { if (!el) return; el.closest('.cx-field').setError(msg || ''); if (msg) ok = false; };
        if (f.item) say(f.item, f.item.value.trim() ? '' : 'An item');
        if (f.qty) say(f.qty, R.readQty(f.qty.value) ? '' : 'A whole number · 1 or more');
        if (f.days) { const dd = R.readDays(f.days.value); say(f.days, dd.error || (!dd.first_day ? 'Days · Friday–Tuesday' : '')); }
        if (f.where) say(f.where, f.where.value.trim() ? '' : 'A place · Barnes 133');
        const st = f.start ? R.readTime(f.start.value) : '', en = f.end ? R.readTime(f.end.value) : '';
        say(f.start, st == null ? 'A time · 9:00 AM' : '');
        say(f.end, en == null ? 'A time · 9:00 AM' : st != null && en != null && !st !== !en ? 'Start and end · Or neither for All day' : '');
        return ok;
      };
      return { body, read, check };
    }
    function editItem(r) {
      const fm = form(r, false);
      sp.open({ title: r.item, body: fm.body, foot: [A.btn('Save', { primary: true, write: true, onClick: () => { const fields = fm.read(); if (!fm.check(fields)) return; sp.close(true); sendNeeds({ ops: [{ id: r.id, fields, answer: r.answer === 'new' ? 'new' : 'change' }] }, 'Saved · ' + fields.item); } }), A.btn('Cancel', { ghost: true, onClick: () => sp.close() })] });
    }
    function editEvent(g) {
      const fm = form(g.rows[0], true);
      sp.open({ title: 'Event · ' + eventName(g.rows[0]), body: h('div', null, h('p', { class: 'ap-help', text: 'For every item in it · ' + plural(g.rows.length, 'item') }), fm.body), foot: [A.btn('Save', { primary: true, write: true, onClick: () => { const fields = fm.read(); if (!fm.check(fields)) return; sp.close(true); sendNeeds({ ops: g.rows.map(x => ({ id: x.id, fields })) }, plural(g.rows.length, 'request') + ' changed'); } }), A.btn('Cancel', { ghost: true, onClick: () => sp.close() })] });
    }
    function addItem(ev) {
      const base = { for: ev.for, first_day: ev.first_day, last_day: ev.last_day, start: ev.start, end: ev.end, building: ev.building, room: ev.room };
      const fm = form(Object.assign({ item: '', qty: '1' }, base), false);
      sp.open({ title: 'Add item · ' + cname, body: fm.body, foot: [A.btn('Add', { primary: true, write: true, onClick: () => { const fields = fm.read(); if (!fm.check(fields)) return; sp.close(true); sendNeeds({ add: [Object.assign({ committee: cname }, base, fields)] }, 'Added · ' + fields.item); } }), A.btn('Cancel', { ghost: true, onClick: () => sp.close() })] });
    }
    function addEvent() {
      const fm = form({ item: '', qty: '1', first_day: 'Friday', last_day: 'Tuesday' }, false);
      sp.open({ title: 'Add request · ' + cname, body: fm.body, foot: [A.btn('Add', { primary: true, write: true, onClick: () => { const fields = fm.read(); if (!fm.check(fields)) return; sp.close(true); sendNeeds({ add: [Object.assign({ committee: cname }, fields)] }, 'Added · ' + fields.item); } }), A.btn('Cancel', { ghost: true, onClick: () => sp.close() })] });
    }

    /* ------------------------------------------------------------ packet and Help */
    function roundAnswer(item, answer, extra, said) {
      return A.api('POST', 'round/answer', Object.assign({ c, item, answer }, extra || {})).then(nm => { m = nm; K.drop(y); redraw(); if (said) A.toast(said); return nm; }, err => { A.fail(err); throw err; });
    }
    function byOf(a) { return a ? [a.by, md(a.on)].filter(Boolean).join(' · ') : ''; }
    function packetSection() {
      const l = m.left.packet + m.left.help;
      const ns = m.packet.concat(m.help).filter(x => x.answer && x.answer.answer === 'notsure').length;
      const sec = h('section', { class: 'ap-section rq-sec' + (simple ? ' rq-sec--simple' : ''), id: 'rq-pk', 'aria-label': 'Packet and Help' },
        simple ? null : h('h2', { class: 'ap-h2 rq-h2' }, 'Packet and Help', h('span', { class: 'ap-h2__n', text: [l ? l + ' to answer' : 'All answered', ns ? ns + ' not sure' : ''].filter(Boolean).join(' · ') })),
        h('p', { class: 'ap-help rq-help', text: 'What ' + cname + ' says in the information packet and on its Help card · Changes go into the packet' + (simple ? ', on the website once it’s published' : ' for the COA to publish') }));
      // Simple mode: each part as it reads, with Edit (no round to answer).
      const editOnly = fn => h('div', { class: 'cx-ans' }, ro() ? null : A.btn('Edit', { write: true, onClick: fn }));
      m.packet.forEach(p => sec.appendChild(h('article', { class: 'rq-doc' + (p.answer ? ' is-' + p.answer.answer : '') },
        h('header', { class: 'rq-doc__h' },
          h('div', null, h('p', { class: 'ap-label', text: 'Packet' }), h('h3', { class: 'rq-doc__t', text: p.title || p.id }), p.summary ? h('p', { class: 'rq-doc__s', text: p.summary }) : null),
          simple ? editOnly(() => editPart(p)) : answerBox(p.answer && p.answer.answer, byOf(p.answer), p.title, {
            keep: () => roundAnswer(p.item, 'keep', null, 'Kept · ' + p.title),
            change: () => editPart(p),
            notsure: () => ask(p.title, q => roundAnswer(p.item, 'notsure', { note: q }, 'Not sure · ' + p.title)),
            remove: () => roundAnswer(p.item, 'remove', null, 'Asked to remove · ' + p.title),
            undo: () => roundAnswer(p.item, '', null, 'To answer · ' + p.title)
          })),
        h('div', { class: 'rq-doc__body' }, p.paras.filter(Boolean).map(t => h('p', { text: t }))),
        !simple && p.answer && p.answer.note ? h('p', { class: 'cx-need__q', text: '“' + p.answer.note + '”' }) : null,
        !simple && p.answer && p.answer.answer !== 'remove' ? h('p', { class: 'rq-doc__edit' }, K.link('Edit', () => editPart(p))) : null)));
      m.help.forEach(hc => sec.appendChild(h('article', { class: 'rq-doc rq-doc--help' + (hc.answer ? ' is-' + hc.answer.answer : '') },
        h('header', { class: 'rq-doc__h' },
          h('div', null, h('p', { class: 'ap-label', text: 'Help card' }), h('h3', { class: 'rq-doc__t', text: hc.need })),
          simple ? editOnly(() => editHelp(hc)) : answerBox(hc.answer && hc.answer.answer, byOf(hc.answer), hc.need, {
            keep: () => roundAnswer(hc.item, 'keep', null, 'Kept · ' + hc.need),
            change: () => editHelp(hc),
            notsure: () => ask(hc.need, q => roundAnswer(hc.item, 'notsure', { note: q }, 'Not sure · ' + hc.need)),
            remove: () => roundAnswer(hc.item, 'remove', null, 'Asked to remove · ' + hc.need),
            undo: () => roundAnswer(hc.item, '', null, 'To answer · ' + hc.need)
          })),
        hc.text ? h('div', { class: 'rq-doc__body' }, h('p', { text: hc.text })) : null,
        K.facts([hc.action || hc.phone ? ['Call', [hc.action, hc.phone].filter(Boolean).join(' · ')] : null, hc.hours ? ['Hours', hc.hours] : null, hc.open ? ['Where', hc.open] : null]),
        !simple && hc.answer && hc.answer.note ? h('p', { class: 'cx-need__q', text: '“' + hc.answer.note + '”' }) : null,
        !simple && hc.answer && hc.answer.answer !== 'remove' ? h('p', { class: 'rq-doc__edit' }, K.link('Edit', () => editHelp(hc))) : null)));
      return sec;
    }
    function editPart(p) {
      const title = K.textIn({ value: p.title, label: 'Title', live: false });
      const sum = K.textIn({ value: p.summary, label: 'Summary', live: false, multiline: true, oneLine: true });
      const paras = h('div', { class: 'rq-paras' });
      const addPara = val => { const t = K.textIn({ value: val || '', label: 'Paragraph', live: false, multiline: true, rows: 3 }); paras.appendChild(h('div', { class: 'rq-para' }, t)); return t; };
      (p.paras.length ? p.paras : ['']).forEach(addPara);
      const tf = K.field('Title', title), pf = K.field('Paragraphs', paras, { tag: 'div', help: 'A paragraph left empty is taken out', after: h('p', null, K.link('Add paragraph', () => addPara('').focus(), { icon: 'plus' })) });
      sp.open({ title: 'Packet · ' + p.title, body: h('div', { class: 'cx-rec' }, tf, K.field('Summary', sum, { help: 'One line under the title' }), pf),
        foot: [A.btn('Save', { primary: true, write: true, onClick: () => {
          const fields = { title: title.value.trim(), summary: sum.value.trim(), paras: Array.from(paras.querySelectorAll('textarea')).map(x => x.value.trim()).filter(Boolean) };
          if (!fields.title) { tf.setError('A title'); return; }
          if (!fields.paras.length) { pf.setError('One paragraph or more'); return; }
          sp.close(true); roundAnswer(p.item, 'change', { fields }, 'Changed · ' + fields.title + ' · In the packet');
        } }), A.btn('Cancel', { ghost: true, onClick: () => sp.close() })] });
    }
    function editHelp(hc) {
      const text = K.textIn({ value: hc.text, label: 'Text', live: false, multiline: true, rows: 3 });
      const phone = K.textIn({ value: hc.phone, label: 'Phone', live: false, inputmode: 'tel', width: '220px' });
      const hours = K.textIn({ value: hc.hours, label: 'Hours', live: false, placeholder: 'Fri 5 PM–11 PM; Sat–Tue 8 AM–11 PM' });
      sp.open({ title: 'Help card · ' + hc.need, body: h('div', { class: 'cx-rec' }, K.field('Text', text), K.field('Phone', phone, { help: 'A role’s phone, never a person’s own' }), K.field('Hours', hours)),
        foot: [A.btn('Save', { primary: true, write: true, onClick: () => { sp.close(true); roundAnswer(hc.item, 'change', { fields: { text: text.value.trim(), phone: phone.value.trim(), hours: hours.value.trim() } }, 'Changed · ' + hc.need); } }), A.btn('Cancel', { ghost: true, onClick: () => sp.close() })] });
    }

    /* ------------------------------------------------------------ contact */
    function contactSection() {
      const ct = m.contact;
      return h('section', { class: 'ap-section rq-sec', id: 'rq-ct', 'aria-label': 'Contact' },
        h('h2', { class: 'ap-h2 rq-h2' }, 'Contact', h('span', { class: 'ap-h2__n', text: m.left.contact ? 'To answer' : ct.answer && ct.answer.answer === 'notsure' ? 'Not sure' : 'Answered' })),
        h('article', { class: 'rq-doc' + (ct.answer ? ' is-' + ct.answer.answer : '') },
          h('header', { class: 'rq-doc__h' },
            K.facts([
              ['Head', ct.heads.length ? ct.heads.join(', ') : h('span', { class: 'ap-quiet', text: 'No head' })],
              ['Phone', ct.phone || '']
            ]),
            answerBox(ct.answer && ct.answer.answer, byOf(ct.answer), 'Contact', {
              keep: () => roundAnswer(ct.item, 'keep', null, 'Kept · Contact'),
              change: () => editContact(ct),
              notsure: () => ask('Contact', q => roundAnswer(ct.item, 'notsure', { note: q }, 'Not sure · Contact')),
              undo: () => roundAnswer(ct.item, '', null, 'To answer · Contact')
            })),
          h('p', { class: 'ap-help', text: 'The COA changes who heads ' + cname + ' · Not sure tells them' }),
          ct.answer && ct.answer.note ? h('p', { class: 'cx-need__q', text: '“' + ct.answer.note + '”' }) : null));
    }
    function editContact(ct) {
      const phone = K.textIn({ value: ct.phone, label: 'Phone', live: false, inputmode: 'tel', width: '220px', placeholder: '765-555-0100' });
      const f = K.field('Phone', phone, { help: 'The committee’s phone for volunteers and the desk · A role’s, never a person’s own' });
      sp.open({ title: 'Contact · ' + cname, body: h('div', { class: 'cx-rec' }, K.facts([['Head', ct.heads.join(', ') || 'No head']]), f),
        foot: [A.btn('Save', { primary: true, write: true, onClick: () => { const v = phone.value.trim(); if (v && !/^[0-9+().\-\s]{7,}$/.test(v)) { f.setError('A phone number'); return; } sp.close(true); roundAnswer(ct.item, 'change', { fields: { phone: v } }, 'Changed · Phone'); } }), A.btn('Cancel', { ghost: true, onClick: () => sp.close() })] });
    }

    /* ------------------------------------------------------------ return, reopen */
    function doReturn() {
      K.confirm(sp, { title: 'Return to ' + m.from, lines: [plural(total(), 'row') + ' answered · ' + m.from + ' sees ' + cname + ' as Returned', 'You can open your answers again'], actLabel: 'Return',
        act: () => A.api('POST', 'round/return', { c }), onDone: nm => { m = nm; redraw(); A.toast('Returned · ' + cname, { undo: reopen }); } });
    }
    function reopen() {
      A.api('POST', 'round/reopen', { c }).then(nm => { m = nm; redraw(); A.toast('Open again · ' + cname); }, A.fail);
    }

    redraw();
  }
})();
