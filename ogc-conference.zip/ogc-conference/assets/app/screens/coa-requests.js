/*
 * coa-requests.js — Requests: what each committee asks the campus for (equipment, rooms set up, carts),
 * picked up from the last Conference at the campus with every row unanswered. Each committee answers
 * its own (Keep · Not sure · Remove, or Edit), and the COA sends the venue one list.
 *
 *   - Every committee sees this screen; a committee sees and answers only its own rows (the server
 *     filters and refuses the rest). The COA sees them all, the questions asked, and Export for campus.
 *   - Rows fold by event (what they're for, the days and time, where); "Keep 4" keeps an event's rows,
 *     "Keep the other 12" a committee's. Not sure asks "What's unclear?".
 *   - Template (Excel, an Answer column) and Upload: a filled-in sheet comes back to the same rows by its
 *     ID; nothing changes until Apply. Export for campus only downloads; Mark as sent says it's gone.
 *   - Questions are tan; red is for what's wrong. A detail that only repeats the item isn't shown.
 */
(function () {
  'use strict';
  const A = window.OGC_APP, K = window.OGC_COA, O = window.OGC, ED = window.ED;
  if (!A || !K || !ED) return;
  const h = A.h;
  const DAYS = ['Friday', 'Saturday', 'Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday'];
  const ANSWER = { keep: 'Kept', change: 'Changed', remove: 'Removed', notsure: 'Not sure', new: 'New' };
  const ANSWER_IN = { keep: 'keep', kept: 'keep', yes: 'keep', change: 'change', changed: 'change', remove: 'remove', removed: 'remove', drop: 'remove', no: 'remove', 'not sure': 'notsure', notsure: 'notsure', '?': 'notsure', new: 'new', add: 'new' };
  const ckey = n => String(n || '').replace(/\s+/g, ' ').trim().toLowerCase().replace(/^the\s+|\s+committee$/g, '').trim();
  const norm = x => String(x || '').trim().toLowerCase().replace(/\s+/g, ' ');
  const dayIx = n => { const i = DAYS.indexOf(n); return i < 0 ? 99 : i; };
  const dayName = v => DAYS.find(x => x.toLowerCase() === norm(v) || x.slice(0, 3).toLowerCase() === norm(v).slice(0, 3)) || '';
  const splitWhere = w => { const m = String(w || '').trim().match(/^(.*?)\s+(\d[\w/-]*)$/); return m ? { building: m[1], room: m[2] } : { building: String(w || '').trim(), room: '' }; };
  const whereOf = r => [r.building, r.room].filter(Boolean).join(' ');
  const daysOf = r => r.last_day && r.last_day !== r.first_day ? r.first_day + '–' + r.last_day : (r.first_day || '');
  const shortDays = r => !r.first_day ? '' : r.last_day && r.last_day !== r.first_day ? r.first_day.slice(0, 3) + '–' + r.last_day.slice(0, 3) : r.first_day.slice(0, 3);
  // An event with no name is headed by its days ("Sunday", "Fri–Tue"), never "All week" for one day.
  const eventName = r => r.for || (!r.first_day ? 'All week' : r.last_day && r.last_day !== r.first_day ? shortDays(r) : r.first_day);
  // Who brings it, said in a tooltip on its tag.
  const supTip = t => /facilit/i.test(t) ? 'The campus brings it' : /we bring/i.test(t) ? 'The committee brings it' : /cater|food service/i.test(t) ? 'The caterer brings it' : '';
  const timeOf = r => { const a = O.parseTime(r.start), b = O.parseTime(r.end); return a != null && b != null ? O.formatRange(a, b <= a ? b + 1440 : b) : a != null ? O.formatTime(a) : ''; };
  const eventKey = r => [r.for, r.first_day, r.last_day, r.start, r.end, r.building, r.room].map(norm).join('|');
  const lev = (a, b) => { if (Math.abs(a.length - b.length) > 2) return 9; const d = Array.from({ length: b.length + 1 }, (_, i) => i); for (let i = 1; i <= a.length; i++) { let pr = d[0]; d[0] = i; for (let j = 1; j <= b.length; j++) { const t = d[j]; d[j] = Math.min(d[j] + 1, d[j - 1] + 1, pr + (a[i - 1] === b[j - 1] ? 0 : 1)); pr = t; } } return d[b.length]; };
  const loose = x => String(x || '').toLowerCase().replace(/×/g, ' x ').replace(/(\d+)\s*(?:ft\b|feet\b|foot\b|'|’)/g, '$1 ').replace(/[^a-z0-9]+/g, ' ').trim();
  const sing = w => w.length > 3 ? w.replace(/ies$/, 'y').replace(/(?:es|s)$/, '') : w;
  function restates(detail, item, qty) {
    const toks = x => loose(x).split(' ').filter(w => w && w !== 'x' && w !== 'or' && w !== 'and' && w !== String(qty || '')).map(sing);
    const a = toks(detail), b = toks(item);
    if (!a.length) return true;
    if (a.every(w => b.some(v => w === v || (w.length >= 4 && v.length >= 4 && lev(w, v) <= 1)))) return true;
    const ja = a.join(''), jb = b.join('');
    return ja === jb || jb.indexOf(ja) > -1;
  }

  A.screen({
    id: 'requests', title: 'Requests', icon: 'box', section: 'own', who: ['coa', 'committee'],
    render(ctx) {
      let alive = true;
      ctx.head('Requests', '', []);
      K.loading(ctx.body);
      const y = ctx.params.year;
      const draw = force => K.load(y, { force }).then(d => { if (alive) page(ctx, d); }, err => { if (alive) K.failed(ctx.body, err); });
      draw(false);
      return () => { alive = false; };
    }
  });

  function page(ctx, d) {
    const y = d.year, boot = ctx.boot, v = boot.viewer;
    const coa = !!v.coa;
    const ro = !!A.readonly || d.held;
    let rows = d.rowsOf('needs').map(r => Object.assign({}, r));
    const venue = d.row.venue || d.S.venue || 'the campus';
    const places = d.rowsOf('places');
    const mine = coa ? null : (v.committees || []).map(c => c.key);
    // The committees, in the COA's order; a name the requests use that isn't on the list is marked.
    const listed = boot.committees.filter(c => c.key !== 'coa').map(c => c.name);
    const onList = c => listed.some(n => ckey(n) === ckey(c));
    const coms = () => { const names = Array.from(new Set(rows.map(r => r.committee).filter(Boolean))); const order = listed.map(ckey); return names.sort((a, b) => { const i = order.indexOf(ckey(a)), j = order.indexOf(ckey(b)); return (i < 0 ? 999 : i) - (j < 0 ? 999 : j) || a.localeCompare(b); }); };
    const left = rs => rs.filter(r => !r.answer).length;
    const unsure = rs => rs.filter(r => r.answer === 'notsure').length;
    let open = ctx.params.c || (mine && mine.length ? (coms().find(c => mine.indexOf(ckey(c)) > -1) ? ckey(coms().find(c => mine.indexOf(ckey(c)) > -1)) : '') : '');
    const nameOfKey = k => coms().find(c => ckey(c) === k) || (boot.committees.find(c => c.key === k) || {}).name || '';
    const sent = d.coa.sent && d.coa.sent.needs;
    // The answer date every committee with requests left shares ('' when they differ, or none is set).
    const sameDue = () => {
      const ds = coms().filter(c => left(rows.filter(r => r.committee === c))).map(c => (ansDue[ckey(c)] || {}).due || '');
      return ds.length && ds[0] && ds.every(x => x === ds[0]) ? ds[0] : '';
    };
    // Remind heads: asked first, saying who gets what (it emails each head whose committee isn't done).
    function remindHeads() {
      const todo = coms().filter(c => left(rows.filter(r => r.committee === c)));
      K.confirm(sp, {
        title: 'Remind heads',
        lines: ['Emails ' + K.plural(todo.length, 'committee head') + ' now · Each gets their committee’s weekly email, with the link to their requests', todo.join(', ')],
        actLabel: 'Send ' + todo.length,
        act: () => A.api('POST', 'remind', { what: 'requests' }),
        onDone: r => A.toast([r && r.sent ? 'Sent to ' + K.plural(r.sent, 'head') : 'No one to send to', r && r.nohead ? K.plural(r.nohead, 'committee') + ' with no head' : '', r && r.already ? r.already + ' sent today already' : ''].filter(Boolean).join(' · '))
      });
    }
    // When it's due: the task that stands for it (the committees answer, the COA sends).
    let due = '';
    // Each committee's own date to answer by (the COA's table shows it per committee).
    let ansDue = {};
    A.api('GET', 'tasks' + (coa ? '' : '?view=committee')).then(r => {
      const t = (r.tasks || []).find(x => x.kind === (coa ? 'requests_sent' : 'requests_answer') && (coa || mine.indexOf(x.committee) > -1));
      due = (t && t.due) || '';
      (r.tasks || []).filter(x => x.kind === 'requests_answer').forEach(x => { ansDue[x.committee] = x; });
      head(); if (coa && !open) drawMain();
    }).catch(() => {});

    A.clear(ctx.body);
    const sp = ctx.split();
    sp.el.classList.add('cx-split');
    const views = h('div', { class: 'ap-views' });
    const main = h('div', { class: 'cx-page cx-reqs' });
    sp.main.append(views, main);
    // From Home's "Remind heads": the same question here, before anything is sent.
    if (ctx.params.id === 'remind') { A.setParams({ id: '' }); if (coa && !ro && left(rows) && !sent) setTimeout(remindHeads, 0); }

    /* -------------------------------------------------------- the title row */
    function head() {
      const n = rows.length, l = left(rows);
      const acts = [];
      if (n) acts.push(A.btn('Template', { ghost: true, icon: 'file', title: 'An Excel sheet with an Answer column · Fill it in, then Upload', onClick: () => template(open ? nameOfKey(open) : '') }));
      if (!ro) acts.push(A.btn('Upload', { ghost: true, icon: 'upload', title: 'A filled-in Template (Excel or CSV)', onClick: upload }));
      if (coa && n) {
        const kept = rows.filter(r => ['keep', 'change', 'new'].indexOf(r.answer) > -1).length;
        // Never a disabled button with its reason hidden: the reason, said.
        // Export comes once something is answered (before that it isn't drawn at all).
        if (kept) acts.push(A.btn('Export for campus', { primary: !l || !!sent, title: 'The list for ' + venue, onClick: () => exportCampus('') }));
        // While committees are still answering, the page's one act is reminding their heads (asked
        // first, in the panel: it emails them).
        if (l && !sent && !ro) acts.push(A.btn('Remind heads', { primary: !kept, write: true, icon: 'mail', onClick: remindHeads }));
      }
      if (coa && !ro) acts.push(A.btn('More', { ghost: true, iconOnly: true, icon: 'more', onClick: e => A.menu(e.currentTarget, [{ label: d.S.tool_requests === 'own' ? 'Answer on this site' : 'Answered in another tool', run: () => setTool(d.S.tool_requests === 'own' ? 'site' : 'own') }]) }));
      // The date it's due, from the task (a committee answers by Jan 8; the COA sends by Jan 15).
      const dueWords = due ? (sent ? '' : (due < d.today ? 'Due ' + K.md(due) + ' · Late' : (coa ? 'To campus by ' : 'Due ') + K.md(due))) : '';
      // The count is said once: by the committee's own heading below, or for the COA as committees done.
      // What's left, never a zero ("6 committees to answer", not "0 of 11 done").
      const cs = coms(), doneC = cs.filter(c => !left(rows.filter(r => r.committee === c))).length;
      const ans = coa && !open && !sent ? sameDue() : '';
      const fact = !n ? 'No requests yet' : [coa && !open && cs.length - doneC ? K.plural(cs.length - doneC, 'committee') + ' to answer' : '', !l ? 'All answered' : '', ans ? 'Answers due ' + K.md(ans) : '', sent ? 'Sent to campus ' + K.md(sent.at) : dueWords].filter(Boolean).join(' · ');
      ctx.head('Requests', fact, acts);
    }

    /* -------------------------------------------------------- views: committees */
    // No chips where the table already lists the committees, and never a single chip: the COA gets
    // "All" and the committee it opened (and Not sure); someone on two committees, the two.
    function drawViews() {
      A.clear(views);
      const cs = coms().filter(c => !mine || mine.indexOf(ckey(c)) > -1);
      let chips;
      if (coa) {
        chips = open ? [{ id: '', label: 'All committees' }].concat(open !== '~notsure' ? [{ id: open, label: nameOfKey(open), n: left(rows.filter(r => ckey(r.committee) === open)) || null }] : []) : [];
        if (unsure(rows)) chips.push({ id: '~notsure', label: 'Not sure', n: unsure(rows) });
      } else chips = cs.map(c => ({ id: ckey(c), label: c, n: left(rows.filter(r => r.committee === c)) || null }));
      views.hidden = chips.length < 2;
      if (chips.length > 1) views.appendChild(A.views(chips, open, id => { open = id; A.setParams({ c: open }); drawMain(); drawViews(); head(); }));
    }
    function setTool(val) { K.api('PATCH', 'years/' + y + '/files/settings', { op: 'key', key: 'tool_requests', value: val }).then(() => { d.S.tool_requests = val; K.drop(y); A.toast(val === 'own' ? 'Answered in another tool · Upload its sheet here' : 'Answered on this site'); drawMain(); head(); }, A.fail); }

    /* -------------------------------------------------------- the list */
    function drawMain() {
      A.clear(main);
      if (!rows.length) {
        main.appendChild(A.empty({ title: 'No requests yet', line: coa ? 'A new campus starts blank · Upload a filled-in sheet' : 'Your committee has no requests to ' + venue, action: ro ? null : A.btn(coa ? 'Upload' : 'Add request', { write: true, onClick: coa ? upload : () => addEvent(mine && mine[0] ? (boot.committees.find(c => c.key === mine[0]) || {}).name : '') }) }));
        return;
      }
      if (open === '~notsure') { main.appendChild(unsureList()); return; }
      if (!open && coa) { main.appendChild(overview()); return; }
      const c = nameOfKey(open);
      if (!c) { main.appendChild(A.empty({ title: 'No requests for this committee' })); return; }
      main.appendChild(committee(c));
    }

    function overview() {
      const box = h('div', null);
      if (sent) {
        const ch = since();
        box.appendChild(h('p', { class: 'cx-sentline' }, A.icon('check', 14), ' Sent ' + K.mdY(sent.at, y) + ' · ' + (sent.by || ''), ch && ch.n ? [' · ', h('b', { text: K.plural(ch.n, 'change') + ' since' }), ' ', K.link('Export changes', () => exportCampus('changes'))] : null,
          ro ? null : [' · ', K.link('Not sent', () => markSent(false))]));
      }
      const from = ((d.picked.parts || {}).needs || {}).from;
      // What the list is, in the table's tooltip (not a lede over it).
      const about = from ? 'What each committee asked ' + venue + ' for in ' + from + ' · Each committee answers its own' : null;
      // What the COA needs before the date: each committee's head, how far along it is, when it's due,
      // and Remind on one not started (its head gets the weekly email now, with the link).
      const headOf = c => (boot.people.find(pp => pp.head && pp.committees.indexOf(ckey(c)) > -1) || {}).name || '';
      const tb = h('tbody');
      const dueCol = !sameDue();
      coms().forEach(c => {
        const rs = rows.filter(r => r.committee === c), l = left(rs), ns = unsure(rs), done = rs.length - l;
        const t = ansDue[ckey(c)];
        const late = t && !t.done && t.due && t.due < d.today && l;
        const remind = coa && !ro && l && !done && !sent && headOf(c) ? A.btn('Remind', { ghost: true, write: true, title: headOf(c) + ' gets ' + c + '’s weekly email now', onClick: e => { e.stopPropagation(); const b = e.currentTarget; b.disabled = true; K.api('POST', 'app/' + y + '/remind', { what: 'requests', c: ckey(c) }).then(r => A.toast(r.sent ? 'Sent to ' + headOf(c) : r.already ? 'Sent today already' : 'Not sent'), err => { b.disabled = false; A.fail(err); }); } }) : null;
        tb.appendChild(h('tr', { tabindex: '-1', on: { click: e => { if (e.target.closest('button')) return; open = ckey(c); A.setParams({ c: open }); drawViews(); drawMain(); head(); } } },
          h('td', null, h('span', { class: 'ap-cell-title', text: c }), onList(c) ? null : h('span', { class: 'cx-warn-soft', title: 'Not on the committee list', text: ' ?' })),
          h('td', { class: 'ap-td--wide ap-td--muted' }, headOf(c) || h('span', { class: 'ap-quiet', text: 'No head' })),
          h('td', { class: 'ap-td--nowrap' }, !l ? 'Done' : !done ? 'Not started' : l + ' to answer', ns ? h('span', { class: 'ap-quiet', text: ' · ' + ns + ' not sure' }) : null),
          // The date only where it isn't the one every committee shares (that one is in the title row).
          dueCol ? h('td', { class: 'ap-td--nowrap ap-td--muted' }, t && t.due && l ? (late ? A.tag(K.md(t.due) + ' · Late', 'late') : K.md(t.due)) : '') : null,
          h('td', { class: 'ap-td--nowrap ap-td--num' }, remind)));
      });
      box.appendChild(h('div', { class: 'ap-tablewrap cx-flushtable' }, h('table', { class: 'ap-table', 'aria-label': 'Committees', title: about }, h('thead', null, h('tr', null, ['Committee', 'Head', 'Answered'].concat(dueCol ? ['Due'] : [], ['']).map((x, i, all) => h('th', { scope: 'col', class: i === 1 ? 'ap-td--wide' : i === all.length - 1 ? 'ap-td--num' : null, text: x })))), tb)));
      box.appendChild(stockFold());
      if (d.S.tool_requests === 'own') box.appendChild(h('p', { class: 'ap-help', text: 'Answered in another tool this year · Upload its sheet here when it’s done' }));
      return box;
    }

    function unsureList() {
      const rs = rows.filter(r => r.answer === 'notsure');
      return h('ul', { class: 'ap-list' }, rs.map(r => h('li', null, h('div', { class: 'ap-item' }, h('span', { class: 'ap-item__main' },
        h('span', { class: 'ap-item__title', text: r.committee + ' · ' + r.item }),
        h('span', { class: 'ap-item__why', text: [r.question ? '“' + r.question + '”' : '', r.answered_by].filter(Boolean).join(' · ') })),
        K.link('Open', () => { open = ckey(r.committee); A.setParams({ c: open }); drawViews(); drawMain(); head(); })))));
    }

    function committee(c) {
      const rs = rows.filter(r => r.committee === c), l = left(rs);
      const box = h('div', null);
      const top = h('div', { class: 'cx-reqtop' }, h('h2', { class: 'ap-h2' }, c, h('span', { class: 'ap-h2__n', text: l ? l + ' to answer' : 'All answered' })),
        l && !ro ? A.btn(l === rs.length ? 'Keep all ' + l : 'Keep the other ' + l, { icon: 'check', write: true, onClick: () => answer(rs.filter(r => !r.answer), 'keep', c + ' · ' + K.plural(l, 'request') + ' kept') }) : null);
      box.appendChild(top);
      // Places the campus list doesn't know, gathered into one step (not a warning on every event).
      const unknown = Array.from(new Set(rs.filter(r => r.building && places.length && !placeKnown(r.building)).map(r => r.building)));
      if (unknown.length) box.appendChild(h('p', { class: 'cx-issue cx-issue--soft' }, K.plural(unknown.length, 'place') + ' to match to Campus · ' + unknown.slice(0, 4).join(', ') + ' ', coa && A.allowed('campus') ? K.link('Open Campus', () => A.go({ s: 'campus', c: '', id: '', v: '' })) : h('span', { class: 'ap-quiet', text: '· The COA matches them' })));
      const groups = [];
      rs.forEach(r => { const k = eventKey(r); let g = groups.find(x => x.k === k); if (!g) groups.push(g = { k, rows: [] }); g.rows.push(r); });
      groups.sort((a, b) => dayIx(a.rows[0].first_day) - dayIx(b.rows[0].first_day) || (O.parseTime(a.rows[0].start) || 0) - (O.parseTime(b.rows[0].start) || 0));
      groups.forEach(g => box.appendChild(event(c, g)));
      if (!ro) box.appendChild(h('p', null, K.link('Add event', () => addEvent(c), { icon: 'plus' })));
      return box;
    }

    // Is a building one this campus has ("PPAC", "Chapel", the campus itself)?
    function placeKnown(text) {
      const t = String(text).toLowerCase().trim(), first = t.split(/[\s/-]+/)[0];
      const ini = n => String(n || '').replace(/&|\band\b|\bof\b/gi, ' ').split(/\s+/).filter(Boolean).map(w => w[0]).join('').toLowerCase();
      if (/^(campus|all week|everywhere|all over campus)$/.test(t) || t === venue.toLowerCase() || t === ini(venue)) return true;
      return places.some(p => [p.name, p.building].some(n => { const l = String(n || '').toLowerCase(); return l && (t.indexOf(l) > -1 || l.indexOf(t) > -1 || ini(n) === first || l.split(/\s+/)[0] === first); }) || String(p.code || '').toLowerCase() === first);
    }

    function event(c, g) {
      // Headed by its days when it has no name: the line under it doesn't say them again.
      const r = g.rows[0], l = g.rows.filter(x => !x.answer), when = [r.for ? shortDays(r) : '', timeOf(r)].filter(Boolean).join(' ');
      const sups = Array.from(new Set(g.rows.map(x => x.supplied_by || ''))), evSup = sups.length === 1 ? sups[0] : '';
      const sec = h('section', { class: 'cx-ev' },
        h('header', { class: 'cx-ev__h' },
          h('div', null, h('p', { class: 'cx-ev__t', text: eventName(r) }),
            h('p', { class: 'cx-ev__m' }, when || (r.first_day ? '' : h('span', { class: 'cx-warn-soft', text: 'Which days?' })), whereOf(r) ? (when ? ' · ' : '') + whereOf(r) : '', evSup ? h('span', { title: supTip(evSup) || null, text: ' · ' + evSup.replace(/^IWU |^Cedarville /, '') }) : '')),
          ro ? null : h('div', { class: 'ap-row' },
            K.link('Edit event', () => editEvent(c, g), { title: 'Days, time or place for every item in it' }))),
        h('ul', { class: 'cx-ev__items' }, g.rows.map(x => item(x, evSup))),
        ro ? null : h('p', { class: 'cx-ev__add' }, K.link('Add item', () => addItem(c, r), { icon: 'plus' })));
      return sec;
    }

    function item(r, evSup) {
      const detail = r.detail && !restates(r.detail, r.item, r.qty) ? r.detail : '';
      const notes = forLine(r.notes) || String(r.notes || '').replace(/^[\s,;·]+|[\s,;·]+$/g, '');
      const ans = r.answer && ANSWER[r.answer]
        ? h('div', { class: 'cx-ans' }, h('span', { class: 'cx-ans__w cx-ans--' + r.answer }, r.answer === 'remove' ? A.icon('x', 14) : r.answer === 'notsure' ? null : A.icon('check', 14), ANSWER[r.answer]),
          h('span', { class: 'ap-quiet', text: [r.answered_by, K.md(r.answered_at)].filter(Boolean).join(' · ') }), ro ? null : K.link('Change', () => answer([r], '', 'Not answered')))
        // Keep is the one act on the row; Not sure, Change and Remove wait in its ⋯ (a click, not a hover).
        : ro ? h('span', { class: 'ap-quiet', text: 'Not answered' }) : h('div', { class: 'cx-ans cx-ans--btns', role: 'group', 'aria-label': 'Answer ' + r.item },
          A.btn('Keep', { write: true, icon: 'check', onClick: () => answer([r], 'keep', 'Kept · ' + r.item) }),
          A.btn('More · ' + r.item, { ghost: true, iconOnly: true, icon: 'more', write: true, title: 'Not sure, Change or Remove', onClick: e => A.menu(e.currentTarget, [
            { label: 'Not sure', run: () => ask(r) },
            { label: 'Change', run: () => editItem(r) },
            { label: 'Remove', run: () => answer([r], 'remove', 'Removed · ' + r.item) }]) }));
      return h('li', { class: 'cx-need' + (r.answer ? ' is-' + r.answer : '') },
        h('div', { class: 'cx-need__main' },
          h('p', { class: 'cx-need__item' }, h('b', { text: r.item }), h('span', { class: 'ap-quiet', text: ' × ' + (r.qty || '1') }), r.supplied_by && r.supplied_by !== evSup ? h('span', { class: 'ap-tag', title: supTip(r.supplied_by) || null, text: r.supplied_by.replace(/^IWU |^Cedarville /, '') }) : null),
          detail || notes ? h('p', { class: 'cx-need__note', text: [detail, notes].filter(Boolean).join(' · ') }) : null,
          r.answer === 'notsure' && r.question ? h('p', { class: 'cx-need__q', text: '“' + r.question + '”' }) : null),
        h('div', { class: 'cx-need__side' }, ans, ro || !r.answer || r.answer === 'remove' ? null : K.link('Edit', () => editItem(r))));
    }
    // "1-Nursery, 2-PreTeen · 6-Transportation" → "For Nursery 1 · Preteens 2 · Transportation 6".
    function forLine(t) {
      const bits = String(t || '').split(/[,;·]+/).map(x => x.trim()).filter(Boolean), seen = {}, out = [];
      if (!bits.length) return '';
      for (const x of bits) {
        const m = x.match(/^(\d+)\s*-\s*(.+)$/);
        if (!m) return '';
        const cn = listed.find(n => loose(n) === loose(m[2]) || sing(loose(n)) === sing(loose(m[2])) || ({ yf: 'young folks', pt: 'preteens' })[loose(m[2])] === loose(n)) || m[2].trim();
        if (!seen[cn.toLowerCase()]) { seen[cn.toLowerCase()] = 1; out.push(cn + ' ' + m[1]); }
      }
      return 'For ' + out.join(' · ');
    }

    /* -------------------------------------------------------- answering (stamped on the server) */
    function send(body, said, undo) {
      return K.api('POST', 'coa/' + y + '/needs', body).then(res => {
        if (Array.isArray(res.rows)) rows = res.rows.map(r => Object.assign({}, r));
        K.drop(y); drawViews(); drawMain(); head();
        if (said) A.toast(said, undo ? { undo } : null);
        return res;
      }, err => { A.fail(err); throw err; });
    }
    function answer(rs, a, said) {
      if (!rs.length) return;
      const was = rs.map(r => ({ id: r.id, answer: r.answer || '' }));
      send({ ops: rs.map(r => ({ id: r.id, answer: a })) }, said, () => send({ ops: was }, 'Undone'));
    }
    function ask(r) {
      const q = K.textIn({ label: 'What’s unclear?', placeholder: 'Which gym?', live: false });
      K.confirm(sp, { title: 'Not sure · ' + r.item, lines: [r.committee + ' · Asked once, for the COA'], field: K.field('What’s unclear?', q), actLabel: 'Save',
        act: () => send({ ops: [{ id: r.id, answer: 'notsure', question: q.value.trim() }] }, 'Not sure · ' + r.item), onDone: () => {} });
      q.focus();
    }
    const SUPPLIED = () => Array.from(new Set(rows.map(r => r.supplied_by).filter(Boolean).concat(['We bring'])));
    function form(r, isEvent) {
      const f = {};
      const t = (k, label, val, o) => { f[k] = K.textIn(Object.assign({ value: val || '', label, live: false }, o || {})); return K.field(label, f[k], { help: o && o.help }); };
      let sup = r.supplied_by || '';
      const body = h('div', { class: 'cx-rec' },
        isEvent ? null : t('item', 'Item', r.item, { placeholder: 'Easel' }),
        isEvent ? null : t('qty', 'Qty', r.qty, { inputmode: 'numeric', width: '96px' }),
        t('for', 'Used for', r.for, { placeholder: 'Preteen check-in' }),
        h('div', { class: 'cx-two' }, t('days', 'Days', daysOf(r), { placeholder: 'Friday–Tuesday' }), t('where', 'Where', whereOf(r), { placeholder: 'Barnes 133' })),
        h('div', { class: 'cx-two' }, t('start', 'Start', r.start, { placeholder: '8:00 AM' }), t('end', 'End', r.end, { placeholder: '9:00 PM' })),
        isEvent ? null : K.field('From', K.pills(SUPPLIED().map(s => [s, s.replace(/^IWU |^Cedarville /, '')]), sup, val => { sup = val; }), { tag: 'div' }),
        isEvent ? null : t('notes', 'Notes', r.notes, { multiline: true, rows: 2 }));
      const read = () => {
        const out = {};
        ['item', 'qty', 'for', 'start', 'end', 'notes'].forEach(k => { if (f[k]) out[k] = k === 'qty' ? f[k].value.replace(/[^\d]/g, '') : f[k].value.trim(); });
        if (f.where) Object.assign(out, splitWhere(f.where.value));
        if (f.days) { const [a, b] = f.days.value.split(/\s*(?:–|-|\bto\b|\bthrough\b)\s*/i); out.first_day = dayName(a) || (a || '').trim(); out.last_day = b ? dayName(b) || b.trim() : ''; }
        if (!isEvent) out.supplied_by = sup;
        return out;
      };
      return { body, read };
    }
    function editItem(r) {
      const fm = form(r, false);
      sp.open({ title: r.item, body: fm.body, foot: [A.btn('Save', { primary: true, write: true, onClick: () => { const fields = fm.read(); if (!fields.item) { A.toast('An item'); return; } sp.close(true); send({ ops: [{ id: r.id, fields, answer: r.answer === 'new' ? 'new' : 'change' }] }, 'Changed · ' + fields.item); } }), A.btn('Cancel', { ghost: true, onClick: () => sp.close() })] });
    }
    function editEvent(c, g) {
      const fm = form(g.rows[0], true);
      sp.open({ title: 'Event · ' + eventName(g.rows[0]), body: h('div', null, h('p', { class: 'ap-help', text: 'For every item in it · ' + K.plural(g.rows.length, 'item') }), fm.body), foot: [A.btn('Save', { primary: true, write: true, onClick: () => { const fields = fm.read(); sp.close(true); send({ ops: g.rows.map(x => ({ id: x.id, fields, answer: x.answer === 'new' ? 'new' : 'change' })) }, K.plural(g.rows.length, 'request') + ' changed'); } }), A.btn('Cancel', { ghost: true, onClick: () => sp.close() })] });
    }
    function addItem(c, ev) {
      const base = { for: ev.for, first_day: ev.first_day, last_day: ev.last_day, start: ev.start, end: ev.end, building: ev.building, room: ev.room };
      const fm = form(Object.assign({ item: '', qty: '1' }, base), false);
      sp.open({ title: 'Add item · ' + c, body: fm.body, foot: [A.btn('Add', { primary: true, write: true, onClick: () => { const fields = fm.read(); if (!fields.item) { A.toast('An item'); return; } sp.close(true); send({ add: [Object.assign({ committee: c }, base, fields)] }, 'Added · ' + fields.item); } }), A.btn('Cancel', { ghost: true, onClick: () => sp.close() })] });
    }
    function addEvent(c) {
      if (!c) return;
      const fm = form({ item: '', qty: '1' }, false);
      sp.open({ title: 'Add request · ' + c, body: fm.body, foot: [A.btn('Add', { primary: true, write: true, onClick: () => { const fields = fm.read(); if (!fields.item) { A.toast('An item'); return; } sp.close(true); send({ add: [Object.assign({ committee: c }, fields)] }, 'Added · ' + fields.item); } }), A.btn('Cancel', { ghost: true, onClick: () => sp.close() })] });
    }

    /* -------------------------------------------------------- what the campus needs on hand */
    function stock() {
      const days = (d.S.days || 'Friday|Saturday|Sunday|Monday|Tuesday').split('|'), out = {}, ours = {};
      let noDay = 0;
      rows.filter(r => r.answer !== 'remove' && r.item).forEach(r => {
        const a = days.indexOf(r.first_day), b = r.last_day ? days.indexOf(r.last_day) : a, q = +r.qty || 1;
        if (a < 0) { noDay++; return; }
        const into = /we bring/i.test(r.supplied_by || '') ? ours : out;
        const s = O.parseTime(r.start), e = O.parseTime(r.end), span = s != null && e != null ? [s, e <= s ? e + 1440 : e] : [0, 1440];
        for (let i = a; i <= Math.max(a, b); i++) ((into[r.item] = into[r.item] || days.map(() => []))[i]).push([span[0], span[1], q]);
      });
      const peak = list => { const ev = []; list.forEach(([s, e, n]) => { ev.push([s, n], [e, -n]); }); ev.sort((x, z) => x[0] - z[0] || x[1] - z[1]); let c = 0, m = 0; ev.forEach(([, n]) => { c += n; m = Math.max(m, c); }); return m; };
      const of = o => Object.keys(o).sort().map(k => { const n = o[k].map(peak); return { item: k, n, most: Math.max.apply(null, n) }; }).filter(x => x.most > 0);
      return { days, rows: of(out), ours: of(ours), noDay };
    }
    function stockFold() {
      const s = stock();
      if (!s.rows.length) return h('span');
      const table = list => h('div', { class: 'ap-tablewrap' }, h('table', { class: 'ap-table cx-stock' },
        h('thead', null, h('tr', null, h('th', { scope: 'col', text: 'Item' }), s.days.map(x => h('th', { scope: 'col', class: 'ap-td--num', text: x.slice(0, 3) })), h('th', { scope: 'col', class: 'ap-td--num', text: 'Most' }))),
        h('tbody', null, list.map(x => h('tr', null, h('th', { scope: 'row', text: x.item }), x.n.map(k => h('td', { class: 'ap-td--num' + (k ? '' : ' ap-td--muted'), text: k ? String(k) : '·' })), h('td', { class: 'ap-td--num' }, h('b', { text: String(x.most) })))))));
      return h('details', { class: 'cx-more' }, h('summary', null, h('span', { text: 'Peak per day' }), h('span', { class: 'ap-quiet', text: K.plural(s.rows.length, 'item') })),
        h('p', { class: 'ap-help', text: 'The most of each item needed at one time, each day · What the campus sets out' }),
        s.noDay ? h('p', { class: 'cx-issue cx-issue--soft', text: K.plural(s.noDay, 'request') + ' · Day to set' }) : null, table(s.rows), s.ours.length ? [h('p', { class: 'ap-label', text: 'We bring' }), table(s.ours)] : null);
    }

    /* -------------------------------------------------------- since sent, export, mark sent */
    const hash = t => { let x = 5381; String(t).split('').forEach(c => { x = ((x << 5) + x + c.charCodeAt(0)) | 0; }); return (x >>> 0).toString(36); };
    const fp = r => hash(['item', 'qty', 'for', 'first_day', 'last_day', 'start', 'end', 'building', 'room', 'notes'].map(k => String(r[k] == null ? '' : r[k]).trim()).join('|'));
    function since() {
      if (!sent || !sent.rows) return null;
      const out = { added: [], changed: [], removed: [] }, now = {};
      rows.filter(r => r.answer !== 'remove' && r.id).forEach(r => { now[r.id] = 1; if (!(r.id in sent.rows)) out.added.push(r); else if (sent.rows[r.id] !== fp(r)) out.changed.push(r); });
      Object.keys(sent.rows).forEach(id => { if (!now[id]) out.removed.push(rows.find(r => r.id === id) || { id }); });
      out.n = out.added.length + out.changed.length + out.removed.length;
      return out;
    }
    function saveXlsx(sheets, name) {
      const safe = val => { val = String(val == null ? '' : val); return /^[=+\-@\t\r]/.test(val) && !/^-?\d+(\.\d+)?$/.test(val) ? "'" + val : val; };
      if (!O.xlsx) { K.download(name + '.csv', sheets[0].rows[0], sheets[0].rows.slice(1)); return; }
      const blob = O.xlsx.write(sheets.map(s => Object.assign({}, s, { rows: s.rows.map(r => r.map(safe)) })));
      const a = h('a', { href: '#', download: name + '.xlsx' }); a.href = URL.createObjectURL(blob); document.body.appendChild(a); a.click(); setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 1000);
    }
    function exportCampus(only) {
      const l = left(rows), ns = unsure(rows);
      const go = () => {
        const head0 = ['Status', 'Committee', 'Used for', 'Item', 'Qty', 'Detail', 'From', 'First day', 'Last day', 'Start', 'End', 'Building', 'Room', 'Notes'];
        const line = (r, st) => [st, r.committee, r.for, r.item, r.qty, r.detail, r.supplied_by, r.first_day, r.last_day || r.first_day, r.start, r.end, r.building, r.room, r.notes];
        let out;
        if (only === 'changes') { const ch = since(); out = [head0].concat(ch.added.map(r => line(r, 'New')), ch.changed.map(r => line(r, 'Changed')), ch.removed.map(r => line(r, 'Removed'))); }
        else {
          const ok = rows.filter(r => ['keep', 'change', 'new'].indexOf(r.answer) > -1), not = rows.filter(r => !r.answer || r.answer === 'notsure');
          out = [head0].concat(ok.map(r => line(r, ANSWER[r.answer])));
          if (not.length) out = out.concat([[], ['Not confirmed'], head0], not.map(r => line(r, r.answer === 'notsure' ? 'Not sure' : 'To answer')));
        }
        const s = stock(), most = [['Item'].concat(s.days, ['Most at once'])].concat(s.rows.map(x => [x.item].concat(x.n, [x.most])));
        saveXlsx([{ name: only === 'changes' ? 'Changes' : 'Requests', rows: out, widths: [10, 16, 22, 26, 5, 22, 16, 11, 11, 10, 10, 14, 7, 30] }, { name: 'Most at once', rows: most, widths: [30].concat(s.days.map(() => 6), [12]) }], y + ' requests to ' + venue + (only === 'changes' ? ' (changes)' : ''));
        // Downloading isn't sending: the COA marks it sent once it's gone to the campus.
        A.toast('Downloaded', ro ? null : { undo: null });
        const t = document.querySelector('.ap-toast');
        if (t && !ro) t.appendChild(h('button', { type: 'button', text: 'Mark as sent', on: { click: () => { t.remove(); markSent(true); } } }));
      };
      if (!only && (l || ns)) {
        K.confirm(sp, { title: 'Export for campus', lines: [[l && l + ' to answer', ns && ns + ' not sure'].filter(Boolean).join(' · ') + ' · In their own block, marked Not confirmed'], actLabel: 'Export', act: () => Promise.resolve(go()), onDone: () => {} });
        return;
      }
      go();
    }
    function markSent(done) {
      K.coa(y, 'sent', { what: 'needs', done }).then(c => { if (c && c.sent) d.coa.sent = c.sent; else K.drop(y); A.toast(done ? 'Marked sent · ' + venue : 'Not marked sent'); K.load(y, { force: true }).then(nd => { Object.assign(d, { coa: nd.coa }); drawMain(); head(); }); }, A.fail);
    }

    /* -------------------------------------------------------- Template and Upload */
    const TPL = ['ID', 'Committee', 'Used for', 'Item', 'Qty', 'Where', 'Days', 'Start', 'End', 'From', 'Answer', 'Notes'];
    function template(c) {
      const list = c ? [c] : coms().filter(x => !mine || mine.indexOf(ckey(x)) > -1), out = [TPL];
      list.forEach(cm => {
        rows.filter(r => r.committee === cm).forEach(r => out.push([r.id || '', cm, r.for || '', r.item || '', r.qty || '', whereOf(r), daysOf(r), r.start || '', r.end || '', r.supplied_by || '', r.answer ? ({ keep: 'Keep', change: 'Change', remove: 'Remove', notsure: 'Not sure', new: 'New' })[r.answer] : '', r.notes || '']));
        for (let i = 0; i < 3; i++) out.push(['', cm, '', '', '', '', '', '', '', '', '', '']);
      });
      const how = [['How to fill it in'], ['Answer each row: Keep · Change (and change the row) · Remove · Not sure'], ['A new item: an empty row with its committee, Answer New'], ['Leave the ID as it is · Save, then Upload it on Requests'], ['Downloaded ' + d.today]];
      saveXlsx([{ name: 'Requests', rows: out, widths: [7, 16, 22, 26, 5, 18, 18, 10, 10, 16, 10, 30] }, { name: 'How to fill it in', rows: how, widths: [70], bold: true }], 'requests ' + (c ? c.toLowerCase().replace(/[^a-z0-9]+/g, '-') + ' ' : '') + y);
      A.toast('Downloaded · Upload it back here');
    }
    function upload() {
      K.pick('.xlsx,.csv,.tsv,.txt').then(file => file && ED.files.read(file).then(got => plan(got.grid, file.name))).catch(err => A.toast(err && err.message ? err.message : 'Not read'));
    }
    // A filled-in Template: matched by ID, then by committee, item, used for, day and start; nothing is
    // applied until Apply.
    function plan(all, file) {
      if (!all || all.length < 2) { A.toast('Nothing in ' + file); return; }
      const hd = all[0].map(x => norm(x)), at = (...hs) => { for (const x of hs) { const i = hd.indexOf(x); if (i > -1) return i; } return -1; };
      if (at('item') < 0 || at('committee') < 0) { A.toast(file + ' · Not a Template · It needs Committee and Item'); return; }
      const col = { id: at('id'), committee: at('committee'), for: at('used for', 'for'), item: at('item'), qty: at('qty'), where: at('where'), days: at('days'), start: at('start'), end: at('end'), from: at('from', 'supplied by'), answer: at('answer'), notes: at('notes') };
      const val = (row, k) => col[k] > -1 ? String(row[col[k]] == null ? '' : row[col[k]]).trim() : null;
      const used = new Set(), u = { ops: [], add: [], changes: [], per: {}, coms: new Set(), unknown: {}, refused: 0 };
      const bump = (c, k) => { const p = u.per[c] = u.per[c] || {}; p[k] = (p[k] || 0) + 1; };
      const canon = c => (rows.find(r => norm(r.committee) === norm(c)) || {}).committee || listed.find(n => loose(n) === loose(c) || sing(loose(n)) === sing(loose(c))) || c;
      const nearest = c => { let best = '', d0 = 3; listed.forEach(n => { const dd = lev(loose(n), loose(c)); if (dd < d0) { d0 = dd; best = n; } }); return best; };
      all.slice(1).forEach(row => {
        let c = val(row, 'committee'); const it = val(row, 'item');
        if (!c || /^#/.test(c) || !it) return;
        c = canon(c);
        if (mine && mine.indexOf(ckey(c)) < 0) { u.refused++; return; }
        u.coms.add(c);
        if (!rows.some(r => r.committee === c) && !onList(c)) u.unknown[c] = nearest(c) || c;
        const said = ANSWER_IN[norm(val(row, 'answer'))] || '';
        const id = val(row, 'id'), days = val(row, 'days');
        const first = days != null ? dayName(String(days).split(/\s*(?:–|-|\bto\b|\bthrough\b)\s*/i)[0]) : null;
        let r = id ? rows.find(x => x.id === id && !used.has(x)) : null;
        if (!r) r = rows.find(x => !used.has(x) && x.committee === c && norm(x.item) === norm(it) && norm(x.for) === norm(val(row, 'for')) && (first == null || norm(x.first_day) === norm(first)) && (val(row, 'start') == null || norm(x.start) === norm(val(row, 'start'))));
        if (!r) r = rows.find(x => !used.has(x) && x.committee === c && norm(x.item) === norm(it) && norm(x.for) === norm(val(row, 'for')));
        const next = {};
        ['for', 'start', 'end', 'notes'].forEach(k => { if (val(row, k) != null) next[k] = val(row, k); });
        if (val(row, 'qty') != null) next.qty = val(row, 'qty').replace(/[^\d]/g, '');
        if (val(row, 'from') != null) next.supplied_by = val(row, 'from');
        if (days != null) { const [a, b] = String(days).split(/\s*(?:–|-|\bto\b|\bthrough\b)\s*/i); next.first_day = dayName(a) || (a || '').trim(); next.last_day = b ? dayName(b) || b.trim() : ''; }
        const where = val(row, 'where');
        if (!r) { if (said === 'remove') return; u.add.push(Object.assign({ committee: c, item: it, qty: next.qty || '1' }, next, where != null ? splitWhere(where) : {})); bump(c, 'new'); return; }
        used.add(r);
        if (where != null && norm(where) !== norm(whereOf(r))) next.where = where;
        const was = k => k === 'where' ? whereOf(r) : r[k];
        const LABEL = { where: 'Where', for: 'Used for', qty: 'Qty', start: 'Start', end: 'End', notes: 'Notes', supplied_by: 'From', first_day: 'Days', last_day: 'Last day' };
        const diffs = Object.keys(next).filter(k => norm(next[k]) !== norm(was(k)) && !(k === 'last_day' && norm(next[k]) === norm(r.first_day) && !r.last_day) && !(k === 'last_day' && !next[k] && norm(r.last_day) === norm(r.first_day)));
        const ans = said === 'remove' || said === 'notsure' ? said : diffs.length ? 'change' : said === 'new' ? 'keep' : said;
        if (!diffs.length && (!ans || ans === r.answer)) return;
        const op = { id: r.id };
        if (diffs.length && ans !== 'remove') { op.fields = {}; diffs.forEach(k => { if (k === 'where') Object.assign(op.fields, splitWhere(next.where)); else op.fields[k] = next[k]; }); u.changes.push(c + ' · ' + r.item + ': ' + diffs.map(k => (LABEL[k] || k) + ' ' + (next[k] || '—') + ' (was ' + (was(k) || '—') + ')').join(', ')); }
        if (ans && ans !== r.answer) op.answer = ans;
        if (op.fields || op.answer) { u.ops.push(op); bump(c, !op.answer || op.answer === 'change' ? 'changed' : op.answer); }
      });
      u.missing = rows.filter(r => u.coms.has(r.committee) && !used.has(r) && r.answer !== 'remove');
      const drop = new Set();
      const per = Object.keys(u.per).map(c => { const x = u.per[c]; return c + ': ' + [x.changed && x.changed + ' changed', x.new && x.new + ' new', x.keep && x.keep + ' kept', x.notsure && x.notsure + ' not sure', x.remove && x.remove + ' removed'].filter(Boolean).join(', '); });
      if (!per.length && !u.missing.length) { A.toast(file + ' · No changes'); return; }
      const unknownPick = {};
      const body = h('div', { class: 'cx-preview' },
        h('ul', { class: 'cx-prevlist' }, per.map(t => h('li', { text: t }))),
        u.changes.length ? [h('p', { class: 'ap-label', text: 'Changed' }), h('ul', { class: 'cx-prevlist' }, u.changes.slice(0, 20).map(t => h('li', { text: t })))] : null,
        Object.keys(u.unknown).length ? [h('p', { class: 'ap-label', text: 'Which committee?' }), Object.keys(u.unknown).map(n => { unknownPick[n] = u.unknown[n]; const opts = (u.unknown[n] !== n ? [[u.unknown[n], u.unknown[n]]] : []).concat(listed.filter(x => x !== u.unknown[n]).slice(0, 10).map(x => [x, x])).concat([[n, 'Add ' + n]]); return K.field(n, K.pills(opts, u.unknown[n], pv => { unknownPick[n] = pv; }), { tag: 'div' }); })] : null,
        u.missing.length ? [h('p', { class: 'ap-label', text: 'Not in the file · Remove?' }), h('ul', { class: 'cx-prevlist' }, u.missing.map(r => h('li', null, h('label', { class: 'ap-switch' }, h('input', { type: 'checkbox', class: 'ap-check', on: { change: e => { if (e.target.checked) drop.add(r.id); else drop.delete(r.id); } } }), h('span', { text: r.committee + ' · ' + r.item + (r.for ? ' · ' + r.for : '') })))))] : null,
        u.refused ? h('p', { class: 'ap-quiet', text: K.plural(u.refused, 'row') + ' for other committees · Left as they are' }) : null);
      K.confirm(sp, { title: 'Upload · ' + file, lines: [], field: body, actLabel: 'Apply',
        act: () => {
          const ops = u.ops.slice(); drop.forEach(id => ops.push({ id, answer: 'remove' }));
          const add = u.add.map(a => Object.assign({}, a, { committee: unknownPick[a.committee] || a.committee }));
          return send({ ops, add }, K.plural(ops.length, 'row') + ' answered · ' + K.plural(add.length, 'new request'));
        }, onDone: () => {} });
    }

    head(); drawViews(); drawMain();
  }
})();
