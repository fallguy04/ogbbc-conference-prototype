/*
 * coa-households.js — Households (night-records, Oct 13; Round 3, Oct 17): every registration of the
 * year as one list for the COA, like a CRM (docs/25 rule 5). For the COA member answering a phone call
 * ("Search the surname, open it, everything is there"), and for Lodging asking who still owes.
 *
 *   The list     fixed fields only: Status (one list: Waitlist · Registered · Placed · Checked in ·
 *                Checked out · Didn't come · Cancelled), Money (worked out from the payments, never
 *                typed), what's owed, stay, nights, people, the need boxes, how it came in, when.
 *                Saved views as chips, each counted by the server's one function (ogc_rec_views: the
 *                same number Money's tiles and the COA's Work row say); filters in the address
 *                (f=money:paid;flag:late), applied by the server inside the viewer's scope and drawn as
 *                pills with ×; sort by any heading; search by surname or R-number (never the note).
 *   Ticked rows  Export (the same columns every year); for someone who handles money, Mark received
 *                for the checks to come among them.
 *   A household  opens beside the list on the record kit (README 2.7): its people, stay, needs, the
 *                note to Lodging (read only), contact, money; Linked lines (Rooms · 2, Payments · 2,
 *                Shifts · 3), each opening that list filtered to the household with a chip back
 *                ("← Millers"); History (who, when, how) with Add note; its acts at the foot, one filled;
 *                Previous · Next through the list as drawn.
 * Routes: GET app/{y}/households (?f=&open=; ?format=csv), GET …/households/{rid}, POST …/households/mark,
 * …/note (module-records.php). window.OGC_HH.open(sp, rid, o) draws a household in any screen's panel.
 */
(function () {
  'use strict';
  const A = window.OGC_APP, K = window.OGC_COA, R = window.OGC_REC, M = window.OGC_MONEY;
  if (!A || !K || !R || !M) return;
  const h = A.h;
  const money = c => K.money(c || 0);
  const HH = window.OGC_HH = {};

  const STAY = { dorm: 'Dorm', camper: 'Camper', elsewhere: 'Elsewhere' };
  const SOURCE = { online: 'Online', helper: 'Helper', paper: 'Paper', phone: 'Phone', desk: 'Desk', form: 'Form import' };
  const NEEDS = { ground: 'Ground floor', stairs: 'No stairs', restroom: 'Near a restroom' };
  const STATUS_ORDER = ['waitlist', 'registered', 'placed', 'checked_in', 'checked_out', 'noshow', 'cancelled'];
  const MONEY_ORDER = ['due', 'balance', 'checkin', 'form_due', 'check', 'refund', 'paid', 'form_paid', 'refunded', 'form', 'none'];
  const gone = x => x.status === 'cancelled' || x.status === 'waitlist';
  // Still owes: the same Money words on Households, Money, Lodging and the export (module-records.php
  // ogc_rec_owing_keys). A Form import the Form says is unpaid owes too, its amount on the Form.
  const owes = x => ['due', 'balance', 'checkin', 'form_due'].includes(x.money);

  // Saved views: the questions asked every year, in the spec's order (area-households-money 4.3). Which
  // rows each holds is the server's (each row's `in`); so are their counts. Didn't come from the first day.
  const VIEWS = [
    { id: '', label: 'All' }, { id: 'owes', label: 'Owes' }, { id: 'checks', label: 'Checks to come' },
    { id: 'refunds', label: 'Refunds' }, { id: 'needs', label: 'Needs' }, { id: 'waitlist', label: 'Waitlist' },
    { id: 'cancelled', label: 'Cancelled' }, { id: 'paid', label: 'Paid' }, { id: 'noshow', label: 'Didn’t come', week: true }
  ];
  const inView = (x, id) => !id || (x.in || []).includes(id);
  // The fields a list filters on: each a fixed list of values, offered with how many have it.
  const FILTERS = [
    { id: 'status', label: 'Status', of: x => [x.status], words: (v, d) => d.lists.status[v], order: STATUS_ORDER },
    { id: 'money', label: 'Money', of: x => [x.money], words: (v, d) => d.lists.money[v], order: MONEY_ORDER },
    { id: 'stay', label: 'Stay', of: x => [x.stay], words: v => STAY[v], order: ['dorm', 'camper', 'elsewhere'] },
    { id: 'nights', label: 'Nights', of: x => x.stay === 'elsewhere' ? [] : [String(x.nights)], words: v => K.plural(+v, 'night'), order: null },
    { id: 'size', label: 'People', of: x => [x.size >= 6 ? '6' : String(x.size)], words: v => v === '6' ? '6 or more' : K.plural(+v, 'person', 'people'), order: null },
    { id: 'needs', label: 'Needs', of: x => x.needs, words: v => NEEDS[v], order: ['ground', 'stairs', 'restroom'] },
    { id: 'source', label: 'Source', of: x => [x.source], words: v => SOURCE[v], order: ['online', 'helper', 'paper', 'phone', 'desk', 'form'] },
    { id: 'flag', label: 'Flag', of: x => x.flag_keys || [], words: (v, d) => (d.lists.flag || {})[v] || v, order: ['changed', 'notapproved', 'late', 'unasked', 'offered', 'lapsed'] }
  ];

  const nameCell = x => h('span', null, h('span', { class: 'rx-name', text: x.label }),
    h('span', { class: 'rx-sub', text: x.rid }),
    h('span', { class: 'rx-narrow rx-sub', text: x.status_w + ' · ' + STAY[x.stay] }));
  const owedCell = x => x.form ? (x.money === 'form_due' ? h('span', { class: 'ap-quiet', text: 'On the Form', title: 'Unpaid on the Google Form · Its amount is there' }) : '')
    // Red is for owed or late only: a check to come or what's due at check-in is in ink, and a refund is its
    // amount alone (its Money word already says Refund due).
    : owes(x) || x.money === 'check' ? h('span', { class: x.money === 'check' || x.money === 'checkin' ? '' : 'rx-owe', text: money(x.balance) })
    : x.money === 'refund' ? h('span', { class: 'rx-back', text: money(x.refund), title: 'To give back' }) : '';
  const needsCell = x => h('span', { class: 'rx-needs' }, x.needs.map(k => h('span', { class: 'rx-chip', text: NEEDS[k] })), x.note ? h('span', { class: 'rx-chip rx-chip--note', text: 'Note', title: 'A note to Lodging · Open the household to read it' }) : null);

  /* ================================================================ the screen */

  A.screen({
    id: 'households', title: 'Households', icon: 'house', section: 'own', who: ['coa'],
    render(ctx) {
      let alive = true;
      const st = { ticks: new Set(), find: '', sort: { id: 'name', dir: 1 } };
      ctx.head('Households', '', []);
      K.loading(ctx.body);
      let sp = null;
      // The address's filters go to the server, which applies them inside what this viewer may see; the
      // record named to open comes too, so a filter that would hide it is dropped there (area-shell 1.3).
      const q = () => { const p = A.params(), a = []; if (p.f) a.push('f=' + encodeURIComponent(p.f)); if (p.id) a.push('open=' + encodeURIComponent(p.id)); return a.length ? '?' + a.join('&') : ''; };
      const load = () => A.api('GET', 'households' + q()).then(d => { if (alive) { if (!sp) { A.clear(ctx.body); sp = ctx.split(); } page(ctx, d, st, sp, load); } }, err => { if (alive) K.failed(ctx.body, err); });
      load();
      return () => { alive = false; };
    }
  });

  function page(ctx, d, st, sp, again) {
    const y = ctx.params.year, ro = !!A.readonly;
    const p = Object.assign(ctx.params, { id: A.params().id, v: A.params().v, f: A.params().f });
    // A filter that would have hidden the household asked for was dropped by the server: the address says so.
    if (d.dropped) { A.setParams({ f: '' }); p.f = ''; }
    const all = d.rows;
    const vc = d.views || {};
    const nOf = id => ((vc[id || 'all'] || {}).n) || 0;
    if (d.wait != null) M.wait = d.wait;
    // An act named in the address (Home's "Offer place"): done once, on the household it names.
    let firstAt = ctx.params.at || '';
    const exportRows = rids => R.download('app/' + y + '/households?format=csv' + (rids ? '&rids=' + encodeURIComponent(rids.join(',')) : ''), 'Households ' + y + '.csv', 'Exported · ' + K.plural(rids ? rids.length : all.length, 'household'));
    // The week: from the first day of the Conference through check-out day.
    const dayAfter = iso => { const t = new Date(iso + 'T12:00:00Z'); t.setUTCDate(t.getUTCDate() + 1); return t.toISOString().slice(0, 10); };
    const week = !!(d.start && d.today >= d.start && (!d.end || d.today <= dayAfter(d.end)));
    // The head's fact (ogc_rec_counts, the same counts as the COA's Work row): those coming, then the
    // rest, each that counts rows elsewhere a link to the view that holds them ("2 waiting").
    const c = d.counts || {};
    const part = (n, words, v) => n ? (v ? A.link({ v, id: '', f: '' }, words, 'ap-head__factlink') : words) : null;
    const parts = (week
      ? [part(c.coming, c.coming + ' coming'), part(c.checked_in, c.checked_in + ' checked in'), part(c.noshow, c.noshow + ' didn’t come', 'noshow')]
      : [part(c.coming, c.coming + ' coming'), part(c.people, K.plural(c.people, 'person', 'people')), part(c.waiting, c.waiting + ' waiting', 'waitlist'), part(c.cancelled, c.cancelled + ' cancelled', 'cancelled')]).filter(Boolean);
    const headFact = parts.length ? h('span', { 'data-counts': '1' }, parts.reduce((a, x, i) => a.concat(i ? [' · '] : [], [x]), [])) : '';
    const headActs = [];
    // A household that called or wrote: the desk's form (the register area's), entered for them.
    // Round 5: the desk's form in this tab, How it came first, and back here with the new household open.
    if (d.desk && !ro) headActs.push(A.btn('New household', { ghost: true, icon: 'plus', write: true, href: HH.newHref(d.desk), title: 'For a phone call or a paper form · The desk’s form' }));
    if (all.length) headActs.push(A.btn('Export', { ghost: true, icon: 'file', title: 'This list as a spreadsheet (.csv) · Opens in Excel · The same columns every year', onClick: () => exportRows(rows().map(x => x.rid)) }));
    ctx.head('Households', headFact, headActs);
    const main = A.clear(sp.main);
    if (!nOf('') && !(d.filters || []).length) {
      main.appendChild(h('div', { class: 'cx-page' }, A.empty({ title: 'No registrations yet', line: 'Households show here as they register' })));
      return;
    }
    // The view the address names; a household asked for that it doesn't hold switches to one that does.
    const shown = VIEWS.filter(v => !v.week || week || nOf(v.id));
    const viewIds = shown.map(v => v.id);
    let vid = viewIds.includes(p.v || '') ? (p.v || '') : '';
    const want = p.id && all.find(x => x.rid === p.id);
    if (want) {
      const got = A.pickView({ views: viewIds, current: vid, id: p.id, has: (v, id) => { const x = all.find(z => z.rid === id); return !!x && inView(x, v); } });
      if (got !== vid) { vid = got === 'all' ? '' : got; A.setParams({ v: vid }); p.v = vid; }
    }
    let view = shown.find(v => v.id === vid) || shown[0];
    const counts = shown.map(v => ({ id: v.id, label: v.label, n: nOf(v.id) })).filter(v => !v.id || v.n || v.id === view.id);
    const bar = h('div', { class: 'rx-bar' });
    const bulkSlot = h('div');
    const listSlot = h('div');
    main.append(bar, bulkSlot, listSlot);

    // What the list shows: the view, then the search (surname or R-number). The filters were applied by
    // the server; the rows it sent are already inside them.
    const cur = A.fParse(p.f);
    const base = () => all.filter(x => inView(x, view.id)).filter(x => R.matches(st.find, x.label, x.rid, x.contact));
    const rows = () => base();
    // A filter menu writes the address, and the list comes again from the server.
    const setF = (field, v) => { const n = Object.assign({}, cur); if (v) n[field] = [v]; else delete n[field]; A.go({ f: A.fString(n) }); };

    function drawBar() {
      A.clear(bar);
      bar.appendChild(h('div', { class: 'rx-bar__row rx-bar__views' }, counts.length > 1 ? A.views(counts, view.id, id => { A.setParams({ v: id, id: '' }); p.v = id; p.id = ''; view = shown.find(v => v.id === id) || shown[0]; st.ticks.clear(); sp.close(true); drawBar(); drawList(); }) : null));
      // On a phone the filters fold behind one button (the list comes first); on a laptop they're out.
      const on = Object.keys(cur).length;
      const fbox = h('div', { class: 'rx-fbox' + (st.fOpen ? ' is-open' : '') });
      const toggle = h('button', { type: 'button', class: 'rx-filter rx-ftoggle', 'aria-pressed': String(!!on), 'aria-expanded': String(!!st.fOpen), on: { click: () => { st.fOpen = !st.fOpen; fbox.classList.toggle('is-open', st.fOpen); toggle.setAttribute('aria-expanded', String(st.fOpen)); } } }, on ? 'Filters · ' + on : 'Filters', A.icon('down', 12));
      const fRow = h('div', { class: 'rx-bar__row' }, R.find(st.find, v => { st.find = v; drawList(); }, 'Surname or R-number'), toggle, fbox);
      FILTERS.forEach(f => {
        const seen = {};
        all.filter(x => inView(x, view.id)).forEach(x => f.of(x).forEach(v => { seen[v] = (seen[v] || 0) + 1; }));
        const vals = Object.keys(seen);
        const chosen = (cur[f.id] || [])[0] || '';
        // A field with one value on every row says nothing: no filter for it (unless it's the one chosen).
        if (vals.length < 2 && !chosen) return;
        const order = f.order || vals.slice().sort((a, b) => +a - +b);
        const opts = order.filter(v => seen[v] || chosen === v).map(v => ({ v, label: f.words(v, d), n: seen[v] || 0 }));
        fbox.appendChild(R.filter(f.label, chosen, opts, v => setF(f.id, v)));
      });
      fRow.appendChild(h('span', { class: 'rx-count', role: 'status' }));
      bar.appendChild(fRow);
      // What the address filters, said as pills ("Money · Paid ×"): the server's words for what it applied.
      const pills = A.pills(d.filters);
      if (pills) bar.appendChild(h('div', { class: 'rx-bar__row' }, pills));
    }

    const SORTS = {
      name: x => (x.sur + ' ' + x.label).toLowerCase(),
      status: x => STATUS_ORDER.indexOf(x.status),
      money: x => MONEY_ORDER.indexOf(x.money),
      owed: x => x.money === 'refund' ? -x.refund : x.balance,
      stay: x => x.stay,
      nights: x => x.nights,
      size: x => x.size,
      source: x => x.source,
      registered: x => x.registered
    };
    const cols = [
      { id: 'name', label: 'Household', sort: SORTS.name, render: nameCell },
      { id: 'status', label: 'Status', cls: 'ap-td--nowrap', wide: true, sort: SORTS.status, render: x => x.status === 'registered' ? '' : R.status(x.status, x.status_w) },
      { id: 'money', label: 'Money', cls: 'ap-td--nowrap', sort: SORTS.money, render: x => R.money(x.money, x.money_w) },
      { id: 'owed', label: 'Owed', num: true, sort: SORTS.owed, render: owedCell },
      { id: 'stay', label: 'Stay', cls: 'ap-td--nowrap', wide: true, side: true, sort: SORTS.stay, render: x => h('span', null, STAY[x.stay] + (x.hall ? ' · Hall' : ''), x.span ? h('span', { class: 'rx-sub', text: x.span }) : null) },
      { id: 'nights', label: 'Nights', num: true, wide: true, side: true, sort: SORTS.nights, render: x => x.stay === 'elsewhere' ? '' : String(x.nights) },
      { id: 'size', label: 'People', num: true, wide: true, side: true, sort: SORTS.size, render: x => String(x.size) },
      { id: 'needs', label: 'Needs', wide: true, render: needsCell },
      { id: 'registered', label: 'Registered', cls: 'ap-td--nowrap', wide: true, side: true, sort: SORTS.registered, render: x => h('span', null, K.md(x.registered), h('span', { class: 'rx-sub', text: SOURCE[x.source] || x.source })) }
    ];
    const onSort = id => { st.sort = st.sort && st.sort.id === id ? { id, dir: -st.sort.dir } : { id, dir: id === 'owed' || id === 'registered' ? -1 : 1 }; drawList(); };

    // Ticks stay through a search or a filter (working through a pile of envelopes by surname): the bar
    // counts every ticked household in this view, and says how many the list isn't showing.
    function drawBulk(list) {
      A.clear(bulkSlot);
      const on = all.filter(x => inView(x, view.id)).filter(x => st.ticks.has(x.rid));
      if (!on.length) return;
      const hidden = on.filter(x => !list.includes(x)).length;
      // Every ticked household with a check still to come (a late one too: it can still arrive).
      const checks = on.filter(x => ((d.checks || {})[x.rid] || []).length);
      bulkSlot.appendChild(R.bulk(on.length, [
        A.btn('Export', { icon: 'file', onClick: () => exportRows(on.map(x => x.rid)) }),
        d.money && checks.length && !ro ? A.btn('Mark received · ' + checks.length, { primary: true, write: true, title: 'Their checks to come · Each with its amount and number', onClick: () => markMany(checks) }) : null
      ], () => { st.ticks.clear(); drawList(); }, hidden));
    }
    function markMany(list) {
      // Each household's checks to come, as lines (amount and number each, in one column).
      const lines = [];
      list.forEach(x => ((d.checks || {})[x.rid] || []).forEach(c => lines.push({ id: c.id, cents: c.cents, rid: x.rid, label: x.label })));
      M.receivedMany(sp, lines, { again: () => { st.ticks.clear(); again(); } });
    }

    let drawn = [];
    function drawList() {
      let list = rows();
      const c = cols.find(x => x.id === (st.sort || {}).id);
      if (c && c.sort) list = list.slice().sort((a, b) => { const u = c.sort(a), w = c.sort(b); return ((u < w ? -1 : u > w ? 1 : 0) * st.sort.dir) || SORTS.name(a).localeCompare(SORTS.name(b)); });
      drawn = list;
      const cnt = bar.querySelector('.rx-count');
      // Never a zero: an empty list says "No matches" in its own card. The count line only when narrowed.
      if (cnt) cnt.textContent = list.length && list.length !== nOf(view.id) ? K.plural(list.length, 'household') : '';
      // Columns with nothing in them aren't drawn (Needs, when nobody ticked one; Status, when every row is
      // just Registered, which a row leaves blank: COA rehearsal, Oct 28, an empty column on every row).
      const shownCols = cols.filter(x => x.id !== 'needs' || list.some(r => r.needs.length || r.note)).filter(x => x.id !== 'owed' || list.some(r => owes(r) || r.money === 'check' || r.money === 'refund' || r.form))
        .filter(x => x.id !== 'status' || list.some(r => r.status !== 'registered'));
      A.clear(listSlot).appendChild(R.table({
        label: 'Households', rows: list, key: x => x.rid, name: x => x.label, cols: shownCols, sort: st.sort, onSort,
        ticks: st.ticks, onTick: () => drawBulk(list), selected: p.id, gone,
        onOpen: x => open(x.rid),
        empty: A.empty({ title: st.find ? 'No matches' : (d.filters || []).length ? 'No households match' : 'None', line: st.find ? 'Search is by surname or R-number' : '', inset: true,
          action: !st.find && (d.filters || []).length ? A.link({ f: '' }, 'Clear filters', 'ap-btn') : null })
      }));
      drawBulk(list);
    }
    function open(rid) {
      p.id = rid;
      A.setParams({ id: rid });
      listSlot.querySelectorAll('tr[data-key]').forEach(tr => tr.setAttribute('aria-selected', String(tr.dataset.key === rid)));
      const i = drawn.findIndex(x => x.rid === rid);
      const at = firstAt;
      firstAt = '';
      HH.open(sp, rid, {
        again, host: 'households', at, households: all.map(x => Object.assign({}, x)), money: d.money, head: all.find(x => x.rid === rid),
        // Previous · Next through the list as it's drawn (view, filters, search, sort).
        nav: { prev: i > 0 ? () => open(drawn[i - 1].rid) : null, next: i > -1 && i < drawn.length - 1 ? () => open(drawn[i + 1].rid) : null },
        onClose: () => { p.id = ''; A.setParams({ id: '' }); drawList(); }
      });
      const tr = listSlot.querySelector('tr[data-key="' + CSS.escape(rid) + '"]');
      if (tr) tr.scrollIntoView({ block: 'nearest' });
    }

    drawBar();
    drawList();
    if (p.id && all.some(x => x.rid === p.id)) open(p.id); else sp.close(true);
    M.refocus(bar);
  }

  /* ================================================================ one household, beside any list */

  /*
   * HH.open(sp, rid, o): the household's record in the panel, on the record kit. o: { again (reload the
   * list), onClose, households (for one check across several), host ('households' | 'money': the screen
   * it's opened on, for the Linked lines' way back), nav ({ prev, next }), head (its list row, drawn at
   * once while the rest loads) }.
   */
  HH.open = function (sp, rid, o) {
    o = o || {};
    const x0 = o.head;
    // Drawn on the click: the head from the row the list already holds; the rest loads under it.
    sp.open({ title: x0 ? x0.label : 'Household', line: x0 ? x0.rid + (x0.size != null ? ' · ' + K.plural(x0.size, 'person', 'people') : '') : '', tags: x0 ? headTags(x0) : null, nav: o.nav,
      body: h('p', { class: 'ap-quiet', role: 'status', text: 'Loading' }), onClose: o.onClose });
    A.api('GET', 'households/' + encodeURIComponent(rid)).then(x => draw(sp, x, o), err => {
      sp.open({ title: 'Household', nav: o.nav, body: A.empty({ title: err && err.status === 404 ? 'Not found' : 'Not loaded', inset: true }), onClose: o.onClose });
    });
  };
  const headTags = x => [R.status(x.status, x.status_w), h('span', { class: 'ap-tag' }, R.money(x.money, x.money_w)), (x.flags || []).map(f => A.tag(f, 'tan'))];
  const errWords = e => (e && e.data && e.data.message) || (e && e.message) || 'Not saved';
  const asOfQ = () => { const a = new URLSearchParams(location.search).get('as-of'); return a ? '&as-of=' + encodeURIComponent(a) : ''; };

  /* ================================================================ Round 5: the acts that leave or ask */

  // Change: the household's own form, "for a household", in this tab; Save (or ‹ Households) comes back
  // to this address with the household open (area-households-money 6; the form keeps only an app address).
  HH.changeHref = x => x.edit + '&how=phone&return=' + encodeURIComponent(location.pathname + location.search) + asOfQ();
  // New household: the desk's form, How it came first, back to this list with the new household open.
  HH.newHref = base => {
    const u = new URL(location.href);
    ['id', 'at', 'from'].forEach(k => u.searchParams.delete(k));
    return base + '&how=phone&return=' + encodeURIComponent(u.pathname + u.search) + asOfQ();
  };

  // Cancel: the foot asks (area-households-money 5.9.6): what it frees and refunds, how it came, then
  // Cancel registration (red) or Keep. Undo while its email waits.
  HH.askCancel = function (sp, x, o) {
    const foot = sp.panel.querySelector('.ap-panel__foot');
    if (!foot) return;
    let how = o.how || '';
    const err = h('p', { class: 'ap-err', role: 'alert' });
    const go = A.btn('Cancel registration', { danger: true, write: true, onClick: () => {
      go.disabled = true;
      err.textContent = '';
      A.api('POST', 'households/cancel', { rid: x.rid, how }).then(res => {
        A.toast(res.say, res.undo ? { undo: () => A.api('POST', 'households/cancel', { rid: x.rid, undo: res.undo }).then(r => { A.toast(r.say); o.done(); }, A.fail) } : null);
        o.done();
      }, e => { go.disabled = false; err.textContent = errWords(e); });
    } });
    A.clear(foot).appendChild(h('div', { class: 'rx-ask', role: 'group', 'aria-label': 'Cancel registration' },
      h('p', { class: 'rx-ask__q' }, h('b', { text: 'Cancel registration?' })),
      (x.cancel_says || []).length ? h('ul', { class: 'rx-ask__lines' }, x.cancel_says.map(t => h('li', { text: t }))) : null,
      h('div', { class: 'rx-ask__how' }, h('span', { class: 'ap-label', text: 'How it came' }), K.pills([['phone', 'Phone'], ['paper', 'Paper'], ['desk', 'Desk']], how, v => { how = v; })),
      err,
      h('div', { class: 'rx-acts' }, go, A.btn('Keep', { ghost: true, onClick: () => o.keep() }))));
    go.focus();
  };

  // Offer place (area-households-money 5.9.1): how (Email · Phone), pay by, then Send offer or Offered by
  // phone. The place is held until that day (the server counts it); "Offered · Pay by May 12" on the row.
  function offerPanel(sp, x, o, reopen) {
    const s = x.offer_says || { pay_by: {} };
    let how = s.email ? 'email' : 'phone';
    const date = h('input', { type: 'date', class: 'ap-input', min: (new URLSearchParams(location.search).get('as-of') || '').slice(0, 10) || null, max: s.last || null, value: s.pay_by[how] || '', 'aria-label': 'Pay by', style: { maxWidth: '200px' } });
    const under = h('p', { class: 'ap-help' });
    const err = h('p', { class: 'ap-err', role: 'alert' });
    let go = null;
    const sayHow = () => {
      under.textContent = how === 'email' ? 'Emails the household · Their place stays theirs until ' + K.md(date.value) : 'Call them first · Then Offered by phone';
      if (go) go.lastChild.textContent = how === 'email' ? 'Send offer' : 'Offered by phone';
    };
    date.addEventListener('change', sayHow);
    const pills = K.pills((s.email ? [['email', 'Email']] : []).concat([['phone', 'Phone']]), how, v => { how = v; date.value = s.pay_by[v] || date.value; sayHow(); });
    go = A.btn(how === 'email' ? 'Send offer' : 'Offered by phone', { primary: true, write: true, onClick: () => {
      go.disabled = true;
      err.textContent = '';
      A.api('POST', 'households/offer', { rid: x.rid, how, pay_by: date.value }).then(res => {
        A.toast(res.say, res.undo ? { undo: () => A.api('POST', 'households/offer', { rid: x.rid, undo: res.undo }).then(r => { A.toast(r.say); if (o.again) o.again(); reopen(); }, A.fail) } : null);
        if (o.again) o.again();
        reopen();
      }, e => { go.disabled = false; err.textContent = errWords(e); });
    } });
    sp.open({
      title: 'Offer place', line: x.label + ' · ' + x.rid, nav: o.nav, onClose: o.onClose,
      body: h('div', { class: 'rx-offer' },
        h('p', { class: 'rx-panel__line', text: s.line || '' }),
        s.cost ? h('dl', { class: 'ap-facts' }, h('dt', { text: 'Costs' }), h('dd', { text: s.cost })) : null,
        K.field('How', pills, { tag: 'div' }),
        K.field('Pay by', date),
        under, err),
      foot: [go, A.btn('Back', { ghost: true, onClick: reopen })]
    });
    // A panel inside the panel starts at its top (the household's panel may have been scrolled to its foot).
    sp.panel.scrollTop = 0;
    sayHow();
  }
  function offerAct(x, body, after, reopen) {
    A.api('POST', 'households/offer', Object.assign({ rid: x.rid }, body)).then(res => {
      A.toast(res.say, res.undo ? { undo: () => A.api('POST', 'households/offer', { rid: x.rid, undo: res.undo }).then(r => { A.toast(r.say); after(); reopen(); }, A.fail) } : null);
      after();
      reopen();
    }, A.fail);
  }

  function draw(sp, x, o) {
    const ro = !!A.readonly;
    const reopen = () => HH.open(sp, x.rid, Object.assign({}, o, { head: x, at: '' }));
    const after = () => { if (o.again) o.again(); };
    const sec = (title, ...kids) => h('section', { class: 'rx-sec', 'aria-label': title }, h('h3', { text: title }), kids);
    const sd = x.stay_d;
    const host = o.host || A.params().s || 'households';
    const facts = [];
    const fact = (k, v) => { if (v) facts.push(h('dt', { text: k }), h('dd', null, v)); };
    fact('Where', [STAY[x.stay] + (x.hall ? ' · Young Folks hall' : ''), sd.rooms && x.stay === 'dorm' && !x.hall ? ' · ' + K.plural(sd.rooms, 'room') + ' asked' : '', sd.campers ? ' · ' + K.plural(sd.campers, 'camper') + (sd.camper_len ? ' · ' + sd.camper_len : '') : ''].join(''));
    fact(x.stay === 'elsewhere' ? 'Days' : 'Nights', x.span ? x.span + (x.stay === 'elsewhere' ? '' : ' · ' + K.plural(x.nights, 'night')) + (sd.per_person ? ' · Not everyone every night' : '') : '');
    fact('Rooms', x.rooms_given.length ? x.rooms_given.join(' · ') : x.stay === 'dorm' && !x.hall && !['cancelled', 'waitlist'].includes(x.status) ? h('span', { class: 'ap-quiet', text: 'Not placed yet' }) : '');
    fact('Keys', sd.keys.length && x.stay === 'dorm' && !x.hall ? sd.keys.join(' · ') : '');
    fact('Bedding', [sd.linens ? K.plural(sd.linens, 'linen packet') : '', sd.mattresses ? K.plural(sd.mattresses, 'air mattress', 'air mattresses') : ''].filter(Boolean).join(' · '));
    fact('Arriving', sd.arrive);
    fact('Parent', x.approval);
    const contact = h('dl', { class: 'ap-facts' },
      h('dt', { text: 'Name' }), h('dd', null, x.contact || '', x.phone ? [' · ', h('a', { href: 'tel:' + x.phone.replace(/[^\d+]/g, ''), class: 'ap-link', text: x.phone })] : null),
      x.email ? [h('dt', { text: 'Email' }), h('dd', { text: x.email })] : [h('dt', { text: 'Email' }), h('dd', null, h('span', { class: 'ap-quiet', text: 'None · Call or write' }))],
      x.helper ? [h('dt', { text: 'Helper' }), h('dd', { text: [x.helper.name, x.helper.phone, x.helper.email].filter(Boolean).join(' · ') })] : null,
      h('dt', { text: 'Registered' }), h('dd', { text: K.md(x.registered) + ' · ' + (SOURCE[x.source] || x.source) }));

    /* -------- money */
    // Never a zero (COA rehearsal, Oct 28: "$0 Owes" beside a household paid in full): a cell with nothing
    // to say isn't drawn, and the Money word in the head says Paid. A Form import keeps its dashes (the
    // amounts are on the Form).
    const cell = (v, label, cls) => h('div', null, h('b', { class: cls || '', text: x.form ? '—' : money(v) }), h('span', { text: label }));
    const cells = [
      x.form || x.total ? cell(x.total, 'Total') : null,
      x.form || x.paid ? cell(x.paid, 'Paid') : null,
      x.money === 'refund' ? (x.refund ? cell(x.refund, 'To give back', 'rx-back') : null)
        : x.form || x.balance ? cell(x.balance, x.money === 'check' ? 'Check to come' : 'Owes', x.balance && x.money !== 'check' ? 'rx-owe' : '') : null
    ].filter(Boolean);
    const box = cells.length ? h('div', { class: 'rx-money-box' }, cells) : null;
    const charges = x.price.length ? h('details', { class: 'ap-more' }, h('summary', { text: 'Charges · ' + K.plural(x.price.length, 'line') }),
      h('ul', { class: 'rx-lines' }, x.price.map(l => h('li', null, h('span'), h('span', { text: l.label }), h('span', { class: 'rx-lines__a', text: money(l.cents) }))),
        x.gift ? h('li', null, h('span'), h('span', { text: 'Gift' }), h('span', { class: 'rx-lines__a', text: money(x.gift) })) : null)) : null;
    let pays = null;
    // The acts at the foot (area-households-money 5.8; Round 5): at most one filled, by the first rule
    // that applies to this household and this viewer (Offer place · the money acts · Place · Change); the
    // rest quiet; Withdraw offer, Didn't come and Cancel under More.
    const acts = [];
    const more = [];
    let filled = false;
    const act = (label, o2) => { const primary = !filled && !!o2.primary; if (primary) filled = true; acts.push(A.btn(label, Object.assign({}, o2, { primary }))); };
    const households = o.households || [];
    // 1. On the waiting list, no offer open: Offer place.
    if (x.can.offer) act('Offer place', { primary: true, write: true, title: 'Holds the place until the pay-by day', onClick: () => offerPanel(sp, x, o, reopen) });
    if (x.ledger) {
      const mine = x.ledger.slice().sort((a, b) => String(b.day).localeCompare(String(a.day)) || b.id - a.id);
      pays = mine.length ? h('ul', { class: 'rx-lines', 'aria-label': 'Payments' }, mine.map(l => h('li', null,
        h('span', { class: 'rx-lines__d', text: K.md(l.day) }),
        h('span', { class: 'rx-lines__w' }, l.kind_w + ' · ' + l.status_w, h('small', { text: [l.ref && l.ref !== 'sample' ? (l.kind === 'charge' ? 'Ref. ' : 'No. ') + l.ref : '', l.paid_by, l.note].filter(Boolean).join(' · ') })),
        h('span', { class: 'rx-lines__a', text: (l.kind === 'refund' ? '−' : '') + money(l.cents) })))) : h('p', { class: 'rx-quiet-line', text: 'No payments yet' });
      if (!ro) {
        const keep = { again: () => { after(); reopen(); }, back: reopen, onClose: o.onClose, keep: true };
        const toCome = x.ledger.find(l => l.kind === 'check' && l.status === 'pending');
        const ask = x.ledger.find(l => l.kind === 'refund' && (l.status === 'requested' || l.status === 'approved'));
        if (toCome) act('Mark received', { primary: true, write: true, onClick: () => M.received(sp, Object.assign({ label: x.label }, toCome), Object.assign({}, keep, { several: () => M.check(sp, households, [households.find(z => z.rid === x.rid) || x], keep) })) });
        if (ask) act('Review refund', { primary: true, write: true, title: 'Refund ' + ask.status_w.toLowerCase() + ' · ' + money(ask.cents), onClick: () => M.refund(sp, Object.assign({ label: x.label }, ask), keep) });
        if (x.status !== 'waitlist') act('Record payment', { primary: x.balance > 0, write: true, onClick: () => M.record(sp, x, keep) });
        if (x.unasked > 0) act('Ask refund', { write: true, title: 'Paid ' + money(x.unasked) + ' over the total', onClick: () => M.askRefund(sp, Object.assign({}, x, { refund: x.unasked }), keep) });
      }
    }
    // Place: a door to Lodging's Rooms with the household open and the way back (the COA and Lodging,
    // a dorm household registered and not placed yet). It replaces "Open in Lodging".
    if (A.allowed('lod-rooms') && x.stay === 'dorm' && !x.hall && x.status === 'registered' && !ro) {
      const go = { s: 'lod-rooms', id: x.rid };
      const a = A.btn('Place', { primary: !filled, href: A.href(Object.assign({ from: host + ':' + x.rid }, go)), title: 'Lodging’s Rooms, this household open' });
      filled = true;
      a.addEventListener('click', e => { if (e.metaKey || e.ctrlKey || e.shiftKey || e.button !== 0) return; e.preventDefault(); A.follow(go, host + ':' + x.rid, x.short); });
      acts.push(a);
    }
    // 6. Otherwise Change: the household's own form, filled in, "for a household", in this tab; Save comes
    // back here with the household open (area-households-money 6).
    if (x.can.change && x.edit) act('Change', { primary: true, write: true, href: HH.changeHref(x), title: 'Their registration form · Save comes back here' });
    if (x.can.withdraw) more.push({ label: 'Withdraw offer', hint: x.offer ? x.offer.words : '', run: () => offerAct(x, { withdraw: 1 }, after, reopen) });
    if (x.can.noshow) {
      const mark = x.status === 'noshow' ? '' : 'noshow';
      more.push({ label: mark ? 'Didn’t come' : 'Came after all', run: () => A.api('POST', 'households/mark', { rid: x.rid, mark }).then(res => {
        A.toast(res.say, { undo: () => A.api('POST', 'households/mark', { rid: x.rid, mark: mark ? '' : 'noshow' }).then(() => { after(); reopen(); }, A.fail) });
        after(); reopen();
      }, A.fail) });
    }
    if (x.can.cancel) more.push({ label: 'Cancel registration', run: () => HH.askCancel(sp, x, { how: 'phone', done: () => { after(); reopen(); }, keep: reopen }) });
    if (more.length) {
      const m = A.btn('More', { ghost: true, icon: 'down', write: true, onClick: () => A.menu(m, more) });
      acts.push(m);
    }

    /* -------- a note (a phone call, a letter): people's words, kept as written, never read by the site */
    let noteBox = null;
    if (x.can.note && !ro) {
      const ta = h('textarea', { class: 'ap-textarea rx-notein', rows: '2', maxlength: '400', 'aria-label': 'Note' });
      const err = h('p', { class: 'ap-err', role: 'alert' });
      const add = A.btn('Add note', { write: true, onClick: () => {
        const text = ta.value.trim();
        if (!text) { err.textContent = 'Write the note'; ta.focus(); return; }
        add.disabled = true;
        A.api('POST', 'households/note', { rid: x.rid, text }).then(res => {
          A.toast(res.say, res.undo ? { undo: () => A.api('POST', 'households/note', { rid: x.rid, undo: res.undo }).then(() => reopen(), A.fail) } : null);
          reopen();
        }, e => { add.disabled = false; err.textContent = (e && e.data && e.data.message) || (e && e.message) || 'Not saved'; });
      } });
      noteBox = h('div', { class: 'rx-note-add' }, ta, h('div', { class: 'rx-acts' }, add, h('span', { class: 'ap-help', text: 'Dated and signed' })), err);
    }

    sp.open({
      title: x.label, onClose: o.onClose, nav: o.nav,
      line: x.rid + ' · ' + K.plural(x.size, 'person', 'people'),
      tags: headTags(x),
      body: h('div', { 'data-record': x.rid },
        sec('People', h('ul', { class: 'rx-people' }, x.people.map(pp => h('li', null, h('span', { text: pp.name }),
          h('small', { text: [pp.kind + (pp.age ? ' · ' + pp.age : ''), pp.hall, pp.preteen ? 'Preteen' : '', pp.communing ? 'Communing' : '', pp.nights].filter(Boolean).join(' · ') }))))),
        facts.length ? sec('Stay', h('dl', { class: 'ap-facts' }, facts)) : null,
        x.needs.length ? sec('Needs', h('div', { class: 'rx-needs' }, x.needs.map(k => h('span', { class: 'rx-chip', text: NEEDS[k] })))) : null,
        // The household's own words, as typed: shown, never read by the site (docs/25 rule 2).
        x.note_text ? h('div', { class: 'rx-note', title: 'The household’s own words · Read only' }, h('span', { class: 'ap-label', text: 'Note to Lodging' }), x.note_text) : null,
        sec('Contact', contact),
        box || charges || pays || !x.ledger ? sec('Money', box, charges, pays,
          !x.ledger ? h('p', { class: 'rx-quiet-line', title: 'Only whoever the COA ticks Handles money on Members' }, 'Payments · ', h('span', { class: 'ap-quiet', text: 'Treasurer only' })) : null) : null,
        // Linked: by stored IDs, each a door to that list with this household open and the way back.
        A.linked(x.linked, { from: host + ':' + x.rid, name: x.short }),
        A.history(x.history.map(e => Object.assign({}, e, { by: e.by, how: e.how })), { add: noteBox })),
      foot: acts.length ? acts : null
    });
    // Opened to make an offer (at=offer in the address).
    if (o.at === 'offer' && x.can.offer && !ro) offerPanel(sp, x, Object.assign({}, o, { at: '' }), reopen);
  }

  A.action({ id: 'find-household', title: 'Find a household', screen: 'households', run: () => A.go({ s: 'households', id: '', v: '' }) });
})();
