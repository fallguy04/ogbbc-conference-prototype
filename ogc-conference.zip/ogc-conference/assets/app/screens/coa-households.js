/*
 * coa-households.js — Households (night-records, Oct 13): every registration of the year as one list for
 * the COA, like a CRM (docs/25 rule 5). For the COA member answering a phone call ("Search the surname,
 * open it, everything is there"), and for Lodging asking who still owes.
 *
 *   The list     fixed fields only: Status (one list: Waitlist · Registered · Placed · Checked in ·
 *                Checked out · Didn't come · Cancelled), Money (worked out from the payments, never
 *                typed), what's owed, stay, nights, people, the need boxes, how it came in, when.
 *                Saved views as chips; a filter on each field (its values and how many); sort by any
 *                heading; search by surname or R-number (never the note).
 *   Ticked rows  Export (the same columns every year); for someone who handles money, Mark received
 *                for the checks to come among them.
 *   A household  opens beside the list: people, stay, nights, needs, the note to Lodging (read only),
 *                rooms Lodging gave, contact and helper, the charges, the payments (to whoever handles
 *                money: Mark received, Record payment, Ask refund), History. From the first day of the
 *                Conference: Didn't come.
 * Routes: GET app/{y}/households (?format=csv), GET …/households/{rid}, POST …/households/mark
 * (module-records.php). window.OGC_HH.open(sp, rid, o) draws a household in any screen's panel.
 */
(function () {
  'use strict';
  const A = window.OGC_APP, K = window.OGC_COA, R = window.OGC_REC, M = window.OGC_MONEY;
  if (!A || !K || !R || !M) return;
  const h = A.h;
  const money = c => K.money(c || 0);
  const HH = window.OGC_HH = {};

  const STAY = { dorm: 'Dorm', camper: 'Camper', elsewhere: 'Elsewhere' };
  const SOURCE = { online: 'Online', helper: 'Helper', paper: 'Paper', phone: 'Phone', desk: 'Desk', form: 'Form import' };
  const NEEDS = { ground: 'Ground floor', stairs: 'No stairs', restroom: 'Near a restroom' };
  const STATUS_ORDER = ['waitlist', 'registered', 'placed', 'checked_in', 'checked_out', 'noshow', 'cancelled'];
  const MONEY_ORDER = ['due', 'balance', 'checkin', 'form_due', 'check', 'refund', 'paid', 'form_paid', 'refunded', 'form', 'none'];
  const gone = x => x.status === 'cancelled' || x.status === 'waitlist';
  // Still owes: the same Money words on Households, Money, Lodging and the export (module-records.php
  // ogc_rec_owing_keys). A Form import the Form says is unpaid owes too, its amount on the Form.
  const owes = x => ['due', 'balance', 'checkin', 'form_due'].includes(x.money);

  // Saved views: the questions asked every year. Never a zero: a view with nothing in it isn't drawn.
  const VIEWS = [
    { id: '', label: 'All', f: () => true },
    { id: 'owes', label: 'Owes', f: owes },
    { id: 'checks', label: 'Checks to come', f: x => x.money === 'check' },
    { id: 'refunds', label: 'Refunds', f: x => x.money === 'refund' },
    { id: 'needs', label: 'Needs', f: x => x.needs.length > 0 && !gone(x) },
    { id: 'waitlist', label: 'Waitlist', f: x => x.status === 'waitlist' },
    { id: 'cancelled', label: 'Cancelled', f: x => x.status === 'cancelled' }
  ];
  // The fields a list filters on: each a fixed list of values, offered with how many have it.
  const FILTERS = [
    { id: 'status', label: 'Status', of: x => [x.status], words: (v, d) => d.lists.status[v], order: STATUS_ORDER },
    { id: 'money', label: 'Money', of: x => [x.money], words: (v, d) => d.lists.money[v], order: MONEY_ORDER },
    { id: 'stay', label: 'Stay', of: x => [x.stay], words: v => STAY[v], order: ['dorm', 'camper', 'elsewhere'] },
    { id: 'nights', label: 'Nights', of: x => x.stay === 'elsewhere' ? [] : [String(x.nights)], words: v => K.plural(+v, 'night'), order: null },
    { id: 'size', label: 'People', of: x => [x.size >= 6 ? '6' : String(x.size)], words: v => v === '6' ? '6 or more' : K.plural(+v, 'person', 'people'), order: null },
    { id: 'needs', label: 'Needs', of: x => x.needs, words: v => NEEDS[v], order: ['ground', 'stairs', 'restroom'] },
    { id: 'source', label: 'Source', of: x => [x.source], words: v => SOURCE[v], order: ['online', 'helper', 'paper', 'phone', 'desk', 'form'] }
  ];

  const nameCell = x => h('span', null, h('span', { class: 'rx-name', text: x.label }),
    h('span', { class: 'rx-sub', text: x.rid }),
    h('span', { class: 'rx-narrow rx-sub', text: x.status_w + ' · ' + STAY[x.stay] }));
  const owedCell = x => x.form ? (x.money === 'form_due' ? h('span', { class: 'ap-quiet', text: 'On the Form', title: 'Unpaid on the Google Form · Its amount is there' }) : '')
    : owes(x) || x.money === 'check' ? h('span', { class: x.money === 'check' ? '' : 'rx-owe', text: money(x.balance) })
    : x.money === 'refund' ? h('span', { class: 'rx-back', text: 'Refund ' + money(x.refund), title: 'To give back' }) : '';
  const needsCell = x => h('span', { class: 'rx-needs' }, x.needs.map(k => h('span', { class: 'rx-chip', text: NEEDS[k] })), x.note ? h('span', { class: 'rx-chip rx-chip--note', text: 'Note', title: 'A note to Lodging · Open the household to read it' }) : null);

  /* ================================================================ the screen */

  A.screen({
    id: 'households', title: 'Households', icon: 'house', section: 'own', who: ['coa'],
    render(ctx) {
      let alive = true;
      const st = { ticks: new Set(), find: '', sort: { id: 'name', dir: 1 }, f: {} };
      ctx.head('Households', '', []);
      K.loading(ctx.body);
      let sp = null;
      const load = () => A.api('GET', 'households').then(d => { if (alive) { if (!sp) { A.clear(ctx.body); sp = ctx.split(); } page(ctx, d, st, sp, load); } }, err => { if (alive) K.failed(ctx.body, err); });
      load();
      return () => { alive = false; };
    }
  });

  function page(ctx, d, st, sp, again) {
    const y = ctx.params.year, ro = !!A.readonly;
    const p = Object.assign(ctx.params, { id: A.params().id, v: A.params().v });
    const all = d.rows;
    if (d.wait != null) M.wait = d.wait;
    const live = all.filter(x => !gone(x));
    const people = live.reduce((n, x) => n + x.size, 0);
    const nWait = all.filter(x => x.status === 'waitlist').length, nOff = all.filter(x => x.status === 'cancelled').length;
    const exportRows = rids => R.download('app/' + y + '/households?format=csv' + (rids ? '&rids=' + encodeURIComponent(rids.join(',')) : ''), 'Households ' + y + '.csv', 'Exported · ' + K.plural(rids ? rids.length : all.length, 'household'));
    // What the head counts, said: those coming, then the rest by their status ("146 coming · 2 waitlist").
    const headFact = [live.length ? live.length + ' coming · ' + K.plural(people, 'person', 'people') : '', nWait ? nWait + ' waitlist' : '', nOff ? nOff + ' cancelled' : ''].filter(Boolean).join(' · ');
    const headActs = [];
    // A household that called or wrote: the desk's form (the register area's), entered for them.
    if (d.desk && !ro) headActs.push(A.btn('New household', { ghost: true, icon: 'plus', write: true, href: d.desk, title: 'For a phone call or a paper form · The desk’s form' }));
    if (all.length) headActs.push(A.btn('Export', { ghost: true, icon: 'file', title: 'This list, for Excel · The same columns every year', onClick: () => exportRows(rows().map(x => x.rid)) }));
    ctx.head('Households', headFact, headActs);
    const main = A.clear(sp.main);
    if (!all.length) {
      main.appendChild(h('div', { class: 'cx-page' }, A.empty({ title: 'No registrations yet', line: 'Households show here as they register' })));
      return;
    }
    let view = VIEWS.find(v => v.id === p.v) || VIEWS[0];
    const counts = VIEWS.map(v => ({ id: v.id, label: v.label, n: all.filter(v.f).length })).filter(v => !v.id || v.n || v.id === view.id);
    const bar = h('div', { class: 'rx-bar' });
    const bulkSlot = h('div');
    const listSlot = h('div');
    main.append(bar, bulkSlot, listSlot);

    // What the list shows: the view, the search (surname or R-number), then each filter.
    const base = () => all.filter(view.f).filter(x => R.matches(st.find, x.label, x.rid, x.contact));
    const pass = (x, skip) => FILTERS.every(f => f.id === skip || !st.f[f.id] || f.of(x).includes(st.f[f.id]));
    const rows = () => base().filter(x => pass(x));

    function drawBar() {
      A.clear(bar);
      bar.appendChild(h('div', { class: 'rx-bar__row rx-bar__views' }, counts.length > 1 ? A.views(counts, view.id, id => { A.setParams({ v: id, id: '' }); p.v = id; view = VIEWS.find(v => v.id === id) || VIEWS[0]; st.ticks.clear(); sp.close(true); drawBar(); drawList(); }) : null));
      // On a phone the filters fold behind one button (the list comes first); on a laptop they're out.
      const on = Object.keys(st.f).filter(k => st.f[k]).length;
      const fbox = h('div', { class: 'rx-fbox' + (st.fOpen ? ' is-open' : '') });
      const toggle = h('button', { type: 'button', class: 'rx-filter rx-ftoggle', 'aria-pressed': String(!!on), 'aria-expanded': String(!!st.fOpen), on: { click: () => { st.fOpen = !st.fOpen; fbox.classList.toggle('is-open', st.fOpen); toggle.setAttribute('aria-expanded', String(st.fOpen)); } } }, on ? 'Filters · ' + on : 'Filters', A.icon('down', 12));
      const fRow = h('div', { class: 'rx-bar__row' }, R.find(st.find, v => { st.find = v; drawList(); }, 'Surname or R-number'), toggle, fbox);
      FILTERS.forEach(f => {
        const seen = {};
        base().filter(x => pass(x, f.id)).forEach(x => f.of(x).forEach(v => { seen[v] = (seen[v] || 0) + 1; }));
        const vals = Object.keys(seen);
        // A field with one value on every row says nothing: no filter for it (unless it's the one chosen).
        if (vals.length < 2 && !st.f[f.id]) return;
        const order = f.order || vals.slice().sort((a, b) => +a - +b);
        const opts = order.filter(v => seen[v] || st.f[f.id] === v).map(v => ({ v, label: f.words(v, d), n: seen[v] || 0 }));
        fbox.appendChild(R.filter(f.label, st.f[f.id] || '', opts, v => { st.f[f.id] = v; drawBar(); drawList(); }));
      });
      if (on) fbox.appendChild(h('button', { type: 'button', class: 'rx-clear', text: 'Clear filters', on: { click: () => { st.f = {}; drawBar(); drawList(); } } }));
      fRow.appendChild(h('span', { class: 'rx-count', role: 'status' }));
      bar.appendChild(fRow);
    }

    const SORTS = {
      name: x => (x.sur + ' ' + x.label).toLowerCase(),
      status: x => STATUS_ORDER.indexOf(x.status),
      money: x => MONEY_ORDER.indexOf(x.money),
      owed: x => x.money === 'refund' ? -x.refund : x.balance,
      stay: x => x.stay,
      nights: x => x.nights,
      size: x => x.size,
      source: x => x.source,
      registered: x => x.registered
    };
    const cols = [
      { id: 'name', label: 'Household', sort: SORTS.name, render: nameCell },
      { id: 'status', label: 'Status', cls: 'ap-td--nowrap', wide: true, sort: SORTS.status, render: x => R.status(x.status, x.status_w) },
      { id: 'money', label: 'Money', cls: 'ap-td--nowrap', sort: SORTS.money, render: x => R.money(x.money, x.money_w) },
      { id: 'owed', label: 'Owed', num: true, sort: SORTS.owed, render: owedCell },
      { id: 'stay', label: 'Stay', cls: 'ap-td--nowrap', wide: true, side: true, sort: SORTS.stay, render: x => h('span', null, STAY[x.stay] + (x.hall ? ' · Hall' : ''), x.span ? h('span', { class: 'rx-sub', text: x.span }) : null) },
      { id: 'nights', label: 'Nights', num: true, wide: true, side: true, sort: SORTS.nights, render: x => x.stay === 'elsewhere' ? '' : String(x.nights) },
      { id: 'size', label: 'People', num: true, wide: true, side: true, sort: SORTS.size, render: x => String(x.size) },
      { id: 'needs', label: 'Needs', wide: true, render: needsCell },
      { id: 'registered', label: 'Registered', cls: 'ap-td--nowrap', wide: true, side: true, sort: SORTS.registered, render: x => h('span', null, K.md(x.registered), h('span', { class: 'rx-sub', text: SOURCE[x.source] || x.source })) }
    ];
    const onSort = id => { st.sort = st.sort && st.sort.id === id ? { id, dir: -st.sort.dir } : { id, dir: id === 'owed' || id === 'registered' ? -1 : 1 }; drawList(); };

    // Ticks stay through a search or a filter (working through a pile of envelopes by surname): the bar
    // counts every ticked household in this view, and says how many the list isn't showing.
    function drawBulk(list) {
      A.clear(bulkSlot);
      const on = all.filter(view.f).filter(x => st.ticks.has(x.rid));
      if (!on.length) return;
      const hidden = on.filter(x => !list.includes(x)).length;
      // Every ticked household with a check still to come (a late one too: it can still arrive).
      const checks = on.filter(x => ((d.checks || {})[x.rid] || []).length);
      bulkSlot.appendChild(R.bulk(on.length, [
        A.btn('Export', { icon: 'file', onClick: () => exportRows(on.map(x => x.rid)) }),
        d.money && checks.length && !ro ? A.btn('Mark received · ' + checks.length, { primary: true, write: true, title: 'Their checks to come · Each with its amount and number', onClick: () => markMany(checks) }) : null
      ], () => { st.ticks.clear(); drawList(); }, hidden));
    }
    function markMany(list) {
      // Each household's checks to come, as lines (amount and number each, in one column).
      const lines = [];
      list.forEach(x => ((d.checks || {})[x.rid] || []).forEach(c => lines.push({ id: c.id, cents: c.cents, rid: x.rid, label: x.label })));
      M.receivedMany(sp, lines, { again: () => { st.ticks.clear(); again(); } });
    }

    function drawList() {
      let list = rows();
      const c = cols.find(x => x.id === (st.sort || {}).id);
      if (c && c.sort) list = list.slice().sort((a, b) => { const u = c.sort(a), w = c.sort(b); return ((u < w ? -1 : u > w ? 1 : 0) * st.sort.dir) || SORTS.name(a).localeCompare(SORTS.name(b)); });
      const cnt = bar.querySelector('.rx-count');
      // Never a zero: an empty list says "No matches" in its own card.
      if (cnt) cnt.textContent = list.length && list.length !== all.filter(view.f).length ? K.plural(list.length, 'household') : '';
      // Columns with nothing in them aren't drawn (Needs, when nobody ticked one).
      const shown = cols.filter(x => x.id !== 'needs' || list.some(r => r.needs.length || r.note)).filter(x => x.id !== 'owed' || list.some(r => owes(r) || r.money === 'check' || r.money === 'refund' || r.form));
      A.clear(listSlot).appendChild(R.table({
        label: 'Households', rows: list, key: x => x.rid, name: x => x.label, cols: shown, sort: st.sort, onSort,
        ticks: st.ticks, onTick: () => drawBulk(list), selected: p.id, gone,
        onOpen: x => open(x.rid),
        empty: A.empty({ title: st.find ? 'No matches' : 'None', line: st.find ? 'Search is by surname or R-number' : '', inset: true })
      }));
      drawBulk(list);
    }
    function open(rid) {
      p.id = rid;
      A.setParams({ id: rid });
      listSlot.querySelectorAll('tr[data-key]').forEach(tr => tr.setAttribute('aria-selected', String(tr.dataset.key === rid)));
      HH.open(sp, rid, { again, households: all.map(x => Object.assign({}, x)), money: d.money, onClose: () => { p.id = ''; A.setParams({ id: '' }); drawList(); } });
    }

    drawBar();
    drawList();
    if (p.id && all.some(x => x.rid === p.id)) open(p.id); else sp.close(true);
    M.refocus(bar);
  }

  /* ================================================================ one household, beside any list */

  /*
   * HH.open(sp, rid, o): the household's record in the panel. o: { again (reload the list), onClose,
   * households (for one check across several) }.
   */
  HH.open = function (sp, rid, o) {
    o = o || {};
    sp.open({ title: 'Household', body: h('p', { class: 'ap-quiet', role: 'status', text: 'Loading' }), onClose: o.onClose });
    A.api('GET', 'households/' + encodeURIComponent(rid)).then(x => draw(sp, x, o), err => {
      sp.open({ title: 'Household', body: A.empty({ title: err && err.status === 404 ? 'Not found' : 'Not loaded', inset: true }), onClose: o.onClose });
    });
  };

  function draw(sp, x, o) {
    const ro = !!A.readonly;
    const reopen = () => HH.open(sp, x.rid, o);
    const after = () => { if (o.again) o.again(); };
    const sec = (title, ...kids) => h('section', { class: 'rx-sec', 'aria-label': title }, h('h3', { text: title }), kids);
    const sd = x.stay_d;
    const facts = [];
    const fact = (k, v) => { if (v) facts.push(h('dt', { text: k }), h('dd', null, v)); };
    fact('Stay', [STAY[x.stay] + (x.hall ? ' · Young Folks hall' : ''), sd.rooms && x.stay === 'dorm' && !x.hall ? ' · ' + K.plural(sd.rooms, 'room') + ' asked' : '', sd.campers ? ' · ' + K.plural(sd.campers, 'camper') + (sd.camper_len ? ' · ' + sd.camper_len : '') : ''].join(''));
    fact(x.stay === 'elsewhere' ? 'Days' : 'Nights', x.span ? x.span + (x.stay === 'elsewhere' ? '' : ' · ' + K.plural(x.nights, 'night')) + (sd.per_person ? ' · Not everyone every night' : '') : '');
    fact('Rooms', x.rooms_given.length ? x.rooms_given.join(' · ') : x.stay === 'dorm' && !x.hall && !['cancelled', 'waitlist'].includes(x.status) ? h('span', { class: 'ap-quiet', text: 'Not placed yet' }) : '');
    fact('Keys', sd.keys.length && x.stay === 'dorm' && !x.hall ? sd.keys.join(' · ') : '');
    fact('Bedding', [sd.linens ? K.plural(sd.linens, 'linen packet') : '', sd.mattresses ? K.plural(sd.mattresses, 'air mattress', 'air mattresses') : ''].filter(Boolean).join(' · '));
    fact('Arriving', sd.arrive);
    fact('Parent', x.approval);
    const contact = h('dl', { class: 'ap-facts' },
      h('dt', { text: 'Contact' }), h('dd', null, x.contact || '', x.phone ? [' · ', h('a', { href: 'tel:' + x.phone.replace(/[^\d+]/g, ''), class: 'ap-link', text: x.phone })] : null),
      x.email ? [h('dt', { text: 'Email' }), h('dd', { text: x.email })] : [h('dt', { text: 'Email' }), h('dd', null, h('span', { class: 'ap-quiet', text: 'None · Call or write' }))],
      x.helper ? [h('dt', { text: 'Helper' }), h('dd', { text: [x.helper.name, x.helper.phone, x.helper.email].filter(Boolean).join(' · ') })] : null,
      h('dt', { text: 'Registered' }), h('dd', { text: K.md(x.registered) + ' · ' + (SOURCE[x.source] || x.source) }));

    /* -------- money */
    const box = h('div', { class: 'rx-money-box' },
      h('div', null, h('b', { text: x.form ? '—' : money(x.total) }), h('span', { text: 'Total' })),
      h('div', null, h('b', { text: x.form ? '—' : money(x.paid) }), h('span', { text: 'Paid' })),
      x.money === 'refund' ? h('div', null, h('b', { class: 'rx-back', text: money(x.refund) }), h('span', { text: 'To give back' }))
        : h('div', null, h('b', { class: x.balance && x.money !== 'check' ? 'rx-owe' : '', text: x.form ? '—' : money(x.balance) }), h('span', { text: x.money === 'check' ? 'Check to come' : 'Owes' })));
    const charges = x.price.length ? h('details', { class: 'ap-more' }, h('summary', { text: 'Charges · ' + K.plural(x.price.length, 'line') }),
      h('ul', { class: 'rx-lines' }, x.price.map(l => h('li', null, h('span'), h('span', { text: l.label }), h('span', { class: 'rx-lines__a', text: money(l.cents) }))),
        x.gift ? h('li', null, h('span'), h('span', { text: 'Gift' }), h('span', { class: 'rx-lines__a', text: money(x.gift) })) : null)) : null;
    let pays = null;
    const actions = [];
    const households = o.households || [];
    if (x.ledger) {
      const mine = x.ledger.slice().sort((a, b) => String(b.day).localeCompare(String(a.day)) || b.id - a.id);
      pays = mine.length ? h('ul', { class: 'rx-lines', 'aria-label': 'Payments' }, mine.map(l => h('li', null,
        h('span', { class: 'rx-lines__d', text: K.md(l.day) }),
        h('span', { class: 'rx-lines__w' }, l.kind_w + ' · ' + l.status_w, h('small', { text: [l.ref && l.ref !== 'sample' ? (l.kind === 'charge' ? 'Ref. ' : 'No. ') + l.ref : '', l.paid_by, l.note].filter(Boolean).join(' · ') })),
        h('span', { class: 'rx-lines__a', text: (l.kind === 'refund' ? '−' : '') + money(l.cents) })))) : h('p', { class: 'rx-quiet-line', text: 'No payments yet' });
      if (!ro) {
        const keep = { again: () => { after(); reopen(); }, back: reopen, onClose: o.onClose, keep: true };
        const toCome = x.ledger.find(l => l.kind === 'check' && l.status === 'pending');
        if (toCome) actions.push(A.btn('Mark received', { primary: true, write: true, onClick: () => M.received(sp, Object.assign({ label: x.label }, toCome), Object.assign({}, keep, { several: () => M.check(sp, households, [households.find(z => z.rid === x.rid) || x], keep) })) }));
        if (x.status !== 'waitlist') actions.push(A.btn('Record payment', { primary: !toCome && (x.balance > 0), write: true, onClick: () => M.record(sp, x, keep) }));
        if (x.unasked > 0) actions.push(A.btn('Ask refund', { write: true, title: 'Paid ' + money(x.unasked) + ' over the total', onClick: () => M.askRefund(sp, Object.assign({}, x, { refund: x.unasked }), keep) }));
        const ask = x.ledger.find(l => l.kind === 'refund' && (l.status === 'requested' || l.status === 'approved'));
        if (ask) actions.push(A.btn('Review refund', { write: true, title: 'Refund ' + ask.status_w.toLowerCase() + ' · ' + money(ask.cents), onClick: () => M.refund(sp, Object.assign({ label: x.label }, ask), keep) }));
      }
    }

    const foot = [];
    if (A.allowed('lod-households') && x.stay === 'dorm' && !x.hall) foot.push(A.btn('Open in Lodging', { ghost: true, onClick: () => A.go({ s: 'lod-households', id: x.rid, v: '' }) }));
    if (x.can.noshow && !ro) {
      const mark = x.status === 'noshow' ? '' : 'noshow';
      foot.push(A.btn(mark ? 'Didn’t come' : 'Came after all', { write: true, title: mark ? 'Kept for the treasurer' : 'Back to Registered', onClick: () => A.api('POST', 'households/mark', { rid: x.rid, mark }).then(res => {
        A.toast(res.say, { undo: () => A.api('POST', 'households/mark', { rid: x.rid, mark: mark ? '' : 'noshow' }).then(() => { after(); reopen(); }, A.fail) });
        after(); reopen();
      }, A.fail) }));
    }

    /* -------- a note (a phone call, a letter): people's words, kept as written, never read by the site */
    let noteBox = null;
    if (x.can.note && !ro) {
      const ta = h('textarea', { class: 'ap-textarea rx-notein', rows: '2', maxlength: '400', placeholder: 'Called · Wants Saturday instead of Friday · Told Lodging', 'aria-label': 'Note' });
      const err = h('p', { class: 'ap-err', role: 'alert' });
      const add = A.btn('Add note', { write: true, onClick: () => {
        const text = ta.value.trim();
        if (!text) { err.textContent = 'Write the note'; ta.focus(); return; }
        add.disabled = true;
        A.api('POST', 'households/note', { rid: x.rid, text }).then(res => {
          A.toast(res.say, res.undo ? { undo: () => A.api('POST', 'households/note', { rid: x.rid, undo: res.undo }).then(() => reopen(), A.fail) } : null);
          reopen();
        }, e => { add.disabled = false; err.textContent = (e && e.data && e.data.message) || (e && e.message) || 'Not saved'; });
      } });
      noteBox = h('div', { class: 'rx-note-add' }, ta, h('div', { class: 'rx-acts' }, add, h('span', { class: 'ap-help', text: 'Dated and signed' })), err);
    }
    const histList = x.history.length ? h('ul', { class: 'rx-hist' }, x.history.map(e => h('li', { class: e.note ? 'is-note' : '' }, h('span', { text: K.md(e.at) }), h('span', { text: e.what + (e.by ? ' · ' + e.by : '') })))) : null;

    sp.open({
      title: x.label, onClose: o.onClose,
      body: h('div', null,
        h('p', { class: 'rx-panel__line', text: x.rid + ' · ' + K.plural(x.size, 'person', 'people') }),
        h('div', { class: 'rx-tags' }, R.status(x.status, x.status_w), h('span', { class: 'ap-tag' }, R.money(x.money, x.money_w)), x.flags.map(f => A.tag(f, 'tan'))),
        sec('People', h('ul', { class: 'rx-people' }, x.people.map(pp => h('li', null, h('span', { text: pp.name }),
          h('small', { text: [pp.kind + (pp.age ? ' · ' + pp.age : ''), pp.hall, pp.preteen ? 'Preteen' : '', pp.communing ? 'Communing' : '', pp.nights].filter(Boolean).join(' · ') }))))),
        facts.length ? sec('Stay', h('dl', { class: 'ap-facts' }, facts)) : null,
        x.needs.length ? sec('Needs', h('div', { class: 'rx-needs' }, x.needs.map(k => h('span', { class: 'rx-chip', text: NEEDS[k] })))) : null,
        x.note_text ? h('div', { class: 'rx-note', title: 'The household’s own words · Read only' }, h('span', { class: 'ap-label', text: 'Note to Lodging' }), x.note_text) : null,
        sec('Contact', contact),
        sec('Money', box, charges, pays, actions.length ? h('div', { class: 'rx-acts' }, actions) : null,
          !x.ledger ? h('p', { class: 'rx-quiet-line', text: 'Each payment · Only who handles money' }) : null),
        histList || noteBox ? sec('History', noteBox, histList) : null),
      foot: foot.length ? foot : null
    });
  }

  A.action({ id: 'find-household', title: 'Find a household', screen: 'households', run: () => A.go({ s: 'households', id: '', v: '' }) });
})();
