/*
 * coa-help.js — Help and notices: the week's Help cards (by need, with a phone or a link and hours),
 * the notices under the title on the Conference page, and the year's numbers.
 *
 *   - Help cards look as they will on the guide; one opens beside them to edit. A text-message card is a
 *     Number and a Message (the sms: link is made from them). A phone carried from last year is
 *     "From 2026 · Looks right" until checked, and isn't public before.
 *   - A new notice is a Draft: nothing reaches the Conference page until Post. Until defaults to the end
 *     of today (or the last day, during the week).
 *   - What the title row says about being public is the server's answer (GET app/{y}/public), from the
 *     same rules that decide it.
 */
(function () {
  'use strict';
  const A = window.OGC_APP, K = window.OGC_COA, ED = window.ED, O = window.OGC;
  if (!A || !K || !ED) return;
  const h = A.h;
  const VIEWS = [['', 'Help cards', 'help'], ['notices', 'Notices', 'notices'], ['numbers', 'Phone numbers', 'contacts']];

  A.screen({
    id: 'help', title: 'Help and notices', icon: 'help', section: 'own', who: ['coa'],
    render(ctx) {
      const y = ctx.params.year, offs = [];
      let alive = true;
      ctx.head('Help and notices', '', []);
      K.loading(ctx.body);
      const v = VIEWS.find(x => x[0] === (ctx.params.v || '')) || VIEWS[0];
      K.load(y).then(d => {
        const f = K.rows(y, v[2], d);
        return Promise.all([f.ready, A.api('GET', 'public?f=help,notices,contacts').catch(() => ({}))]).then(([, pub]) => ({ d, f, pub, v }));
      }).then(st => { if (alive) page(ctx, st, offs); }, err => { if (alive) K.failed(ctx.body, err); });
      return () => { alive = false; offs.forEach(fn => fn()); };
    }
  });

  function page(ctx, st, offs) {
    const { d, f, pub, v } = st;
    const y = d.year, view = v[0], file = v[2];
    const ro = !!(A.readonly || f.opts.readOnly);
    let sel = ctx.params.id || '';
    const status = K.status([f], offs);
    const pubWord = () => {
      const p = (pub || {})[file] || {};
      if (p.public) return 'Public · ' + K.plural(p.rows, file === 'help' ? 'card' : file === 'notices' ? 'notice' : 'number');
      if (file === 'help') return 'Public with the schedule';
      if (file === 'notices') return f.rows.some(r => r.draft === 'yes') ? 'Drafts only' : 'None showing';
      return 'Not public';
    };
    const head = () => {
      const acts = [status, K.see(file === 'notices' ? '?year=' + y : 'guide/?year=' + y + '&view=help', 'Preview')];
      if (!d.held) acts.push(A.btn(file === 'help' ? 'Add card' : file === 'notices' ? 'Add notice' : 'Add number', { write: true, icon: 'plus', onClick: add }));
      ctx.head('Help and notices', pubWord(), acts);
    };
    head();
    A.clear(ctx.body);
    const sp = ctx.split();
    sp.el.classList.add('cx-split');
    const views = h('div', { class: 'ap-views' }, A.views(VIEWS.map(x => ({ id: x[0], label: x[1], n: x[0] === view ? f.rows.length : null })), view, id => A.go({ v: id, id: '' })));
    const list = h('div', { class: 'cx-page cx-helplist' });
    sp.main.append(views, list);

    /* -------------------------------------------------------- the list */
    function draw() {
      A.clear(list);
      const chip = views.querySelector('.ap-chip[aria-pressed="true"] .ap-chip__n');
      if (chip) chip.textContent = String(f.rows.filter(r => !f.isHeld(r._id)).length);
      if (!f.rows.length) {
        list.appendChild(A.empty({ title: file === 'help' ? 'No Help cards' : file === 'notices' ? 'No notices' : 'No numbers', line: file === 'notices' ? 'A line under the title on the Conference page, while it’s true' : file === 'contacts' ? 'Numbers people call during the week' : '', action: ro || d.held ? null : A.btn(file === 'help' ? 'Add card' : file === 'notices' ? 'Add notice' : 'Add number', { write: true, onClick: add }) }));
        return;
      }
      if (file === 'help') {
        // A hairline list (no boxes in the card): each card's need, its words, its call and hours, then
        // "From 2026 · Looks right" while it's carried and unchecked, and Edit.
        list.appendChild(h('ul', { class: 'cx-helprows' }, f.rows.map(r => {
          // The number only when the button doesn't already say it ("Call 911"); "desk" is the Lodging Desk's hours.
          const phone = r.phone && String(r.action || '').indexOf(r.phone) < 0 ? r.phone + (r.pin ? ' · PIN ' + r.pin : '') : '';
          const look = d.ov && Array.isArray(d.picked.confirm) && d.picked.confirm.indexOf('help:' + r._id) > -1 && !d.coa.checks['help:' + r._id];
          const bits = [r.action ? h('b', { text: r.action }) : null].concat(phone ? [h('span', { text: phone })] : [],
            // Each "days · hours" pair stays on one line.
            String(r.hours || '').split(/\s*;\s*/).filter(Boolean).map(x => h('span', { class: 'cx-nowrap', text: /^desk$/i.test(x) ? 'Desk hours' : x }))).filter(Boolean);
          return h('li', { class: 'cx-helprow', 'data-key': r._id, 'aria-current': r._id === sel ? 'true' : null },
            h('div', { class: 'cx-helprow__main' },
              h('span', { class: 'cx-card__t' }, r.need || 'Untitled'),
              r.text ? h('span', { class: 'cx-helpcard__text', text: r.text }) : null,
              bits.length ? h('span', { class: 'cx-card__s cx-bits' }, bits) : null),
            h('div', { class: 'cx-helprow__acts' },
              look && !d.held ? h('span', { class: 'cx-from cx-from--inline' }, h('span', { class: 'cx-from__t', text: 'From ' + d.picked.from }), A.btn('Looks right', { write: true, onClick: e => {
                e.currentTarget.disabled = true;
                K.coa(y, 'check', { id: 'help:' + r._id, done: true }).then(() => { d.coa.checks['help:' + r._id] = { by: 'you' }; A.toast('Checked · ' + (r.need || 'Card'), { undo: () => K.coa(y, 'check', { id: 'help:' + r._id, done: false }).then(() => { delete d.coa.checks['help:' + r._id]; draw(); }) }); draw(); }, A.fail);
              } })) : null,
              h('button', { type: 'button', class: 'cx-link', text: ro || d.held ? 'Open' : 'Edit', 'aria-label': (ro || d.held ? 'Open ' : 'Edit ') + (r.need || 'card'), on: { click: () => open(r._id) } })));
        })));
        return;
      }
      const cols = file === 'notices'
        ? [['Notice', r => h('span', null, h('span', { class: 'ap-cell-title', text: r.text || 'Untitled' }), r.url ? h('span', { class: 'ap-cell-sub', text: r.url }) : null)], ['Shows', r => noticeWhen(r)]]
        : [['Number', r => h('span', null, h('span', { class: 'ap-cell-title', text: r.label || 'Untitled' }), r.note ? h('span', { class: 'ap-cell-sub', text: r.note }) : null)], ['Phone', r => h('span', { class: 'cx-nowrap', text: (r.phone || '') + (r.pin ? ' · PIN ' + r.pin : '') })]];
      const tb = h('tbody', null, f.rows.map(r => h('tr', { 'data-key': r._id, 'aria-selected': String(r._id === sel), tabindex: '-1', on: { click: () => open(r._id) } }, cols.map(c => h('td', null, c[1](r))))));
      list.classList.add('cx-flushtable');
      list.appendChild(h('div', { class: 'ap-tablewrap' }, h('table', { class: 'ap-table', 'aria-label': v[1] }, h('thead', null, h('tr', null, cols.map(c => h('th', { scope: 'col', text: c[0] })))), tb)));
    }
    function noticeWhen(r) {
      if (r.draft === 'yes') return A.tag('Draft', 'tan');
      const from = r.from || '', to = r.to || '';
      if (to && to < d.today) return h('span', { class: 'ap-quiet', text: 'Ended ' + K.md(to) });
      if (from && from > d.today) return h('span', { text: 'From ' + K.md(from) });
      return A.tag('Showing' + (to ? ' · Until ' + K.md(to) : ''), 'ok');
    }

    /* -------------------------------------------------------- one, beside the list */
    function open(id) {
      const r = f.get(id);
      if (!r) return;
      if (sel && sel !== id && f.isHeld(sel)) f.discard(sel);
      sel = id;
      A.setParams({ v: view, id });
      list.querySelectorAll('[data-key]').forEach(x => { if (x.tagName === 'TR') x.setAttribute('aria-selected', String(x.dataset.key === id)); else if (x.dataset.key === id) x.setAttribute('aria-current', 'true'); else x.removeAttribute('aria-current'); });
      const set = (fields, label, key) => { f.set(id, fields, { label, key: id + ':' + key }); if (f.isHeld(id) && Object.values(fields).some(Boolean)) f.release(id); };
      const body = h('div', { class: 'cx-rec' });
      const field = (label, key, o) => K.field(label, K.textIn(Object.assign({ value: r[key] || '', label, onSave: val => { if (o && o.check) { const e = o.check(val); if (e) return e; } set({ [key]: o && o.clean ? o.clean(val) : val.trim() }, label, key); if (o && o.after) o.after(); } }, o || {})), { help: o && o.help, tip: o && o.tip });
      if (file === 'help') {
        const look = K.looks(d, 'help:' + id, { what: r.need, line: 'Not public until checked', done: () => K.load(y, { force: true }).then(nd => { d.coa = nd.coa; draw(); }) });
        if (look) body.appendChild(look);
        const sms = /^sms:/i.test(r.link || '');
        const smsNum = sms ? decodeURIComponent((r.link.match(/^sms:([^?&]*)/i) || [])[1] || '') : '';
        const smsBody = sms ? decodeURIComponent((r.link.match(/[?&]body=([^&]*)/i) || [])[1] || '') : '';
        const setSms = (num, text) => set({ link: num ? 'sms:' + num.replace(/[^\d+]/g, '') + (text ? '?&body=' + encodeURIComponent(text) : '') : '' }, 'Text message', 'link');
        body.append(
          field('Need', 'need', { placeholder: 'First aid', check: val => val.trim() ? '' : 'A card needs a name', after: () => { const t = sp.panel.querySelector('.ap-panel__title'); if (t) t.textContent = f.get(id).need; draw(); } }),
          K.field('Text', K.textIn({ value: r.text || '', label: 'Text', multiline: true, rows: 3, onSave: val => { set({ text: val.trim() }, 'Text', 'text'); draw(); } })),
          K.field('Button', K.pills([['phone', 'Call'], ['sms', 'Text'], ['link', 'Link'], ['none', 'None']], r.phone && !sms ? 'phone' : sms ? 'sms' : r.link ? 'link' : 'none', kind => {
            if (kind === 'none') set({ phone: '', link: '', action: '' }, 'Button', 'action');
            if (kind === 'phone') set({ link: '' }, 'Button', 'link');
            if (kind === 'sms') set({ phone: '', link: 'sms:' }, 'Button', 'link');
            if (kind === 'link') set({ phone: '', link: r.link && !sms ? r.link : 'https://' }, 'Button', 'link');
            open(id); draw();
          }, { label: 'Button' }), { tag: 'div' }));
        const k = r.phone && !sms ? 'phone' : sms ? 'sms' : r.link ? 'link' : 'none';
        if (k === 'phone') body.append(h('div', { class: 'cx-two' }, field('Phone', 'phone', { inputmode: 'tel', placeholder: '765-555-0101', after: draw }), field('PIN', 'pin', { inputmode: 'numeric', placeholder: 'None' })));
        if (k === 'sms') {
          const n = K.textIn({ value: smsNum, label: 'Number', inputmode: 'tel', placeholder: '226787', onSave: val => setSms(val, m2.value) });
          const m2 = K.textIn({ value: smsBody, label: 'Message', placeholder: 'ConferenceGuest', onSave: val => setSms(n.value, val) });
          body.append(h('div', { class: 'cx-two' }, K.field('Number', n), K.field('Message', m2)));
        }
        if (k === 'link') body.append(field('Link', 'link', { placeholder: 'https://', check: val => /^https:\/\//.test(val.trim()) || !val.trim() ? (/sermonaudio|youtube|youtu\.be|facebook/i.test(val) ? 'Not an outside sermon platform' : '') : 'A link starting https://' }));
        if (k !== 'none') body.append(field('Button label', 'action', { placeholder: 'Call First Aid', after: draw }));
        body.append(
          h('div', { class: 'cx-two' }, field('Hours', 'hours', { placeholder: '7 AM–10 PM', after: draw }), field('Open now label', 'open', { placeholder: 'First Aid Room', help: 'In Open now on the guide, during its hours' })),
          field('Place', 'place', { placeholder: 'Barnes 131' }),
          field('Before the week', 'before', { placeholder: 'Starts a week before Conference', help: 'Said on the card before the week starts' }));
      } else if (file === 'notices') {
        const dr = r.draft === 'yes';
        const text = K.textIn({ value: r.text || '', label: 'Notice', multiline: true, rows: 2, placeholder: 'Supper moved to the Fieldhouse tonight', onSave: val => {
          const t = val.replace(/\s+/g, ' ').trim();
          if (t.length > 140) return 'At most 140 letters · ' + t.length;
          set({ text: t }, 'Notice', 'text'); draw();
          if (/!/.test(t)) return 'No exclamation marks';
        } });
        const counter = h('span', { class: 'ap-help', text: (r.text || '').length + ' of 140' });
        text.addEventListener('input', () => { counter.textContent = text.value.length + ' of 140'; });
        body.append(...[
          dr ? h('p', { class: 'cx-issue cx-issue--soft', text: 'Draft · Not on the Conference page until Post' }) : null,
          K.field('Notice', h('div', null, text, counter)),
          h('div', { class: 'cx-two' },
            K.field('From', K.dateIn({ value: r.from, label: 'From', near: d.today, placeholder: 'Today', onSave: val => set({ from: val }, 'From', 'from') }), { tag: 'div' }),
            K.field('Until', K.dateIn({ value: r.to, label: 'Until', near: d.today, placeholder: 'Date', onSave: val => set({ to: val }, 'Until', 'to') }), { tag: 'div', after: K.link('Ends tonight', () => { set({ to: d.today }, 'Until', 'to'); open(id); draw(); }) })),
          field('Link', 'url', { placeholder: 'https:// · Optional', check: val => !val.trim() || /^https:\/\//.test(val.trim()) ? '' : 'A link starting https://' })].filter(Boolean));
      } else {
        body.append(field('Role', 'label', { placeholder: 'Lodging desk', check: val => val.trim() ? '' : 'A role', help: 'By role, never a name', after: draw }),
          h('div', { class: 'cx-two' }, field('Phone', 'phone', { inputmode: 'tel', placeholder: '765-555-0104', after: draw }), field('PIN', 'pin', { inputmode: 'numeric', placeholder: 'None' })),
          field('Note', 'note', { placeholder: 'Optional' }));
      }
      const foot = ro || d.held ? null : [
        file === 'notices' && r.draft === 'yes' ? A.btn('Post', { primary: true, write: true, onClick: () => post(id) }) : null,
        A.btn('Remove', { ghost: true, danger: true, write: true, onClick: () => { const t = r.need || r.text || r.label || ''; f.remove(id, { label: 'Remove' }); sp.close(true); sel = ''; draw(); A.toast('Removed · ' + t.slice(0, 40), { undo: () => { K.replay(f, 'undo'); draw(); } }); } })
      ].filter(Boolean);
      sp.open({ title: r.need || (file === 'notices' ? 'Notice' : r.label) || 'New', body, foot, onClose: () => { if (f.isHeld(id)) f.discard(id); sel = ''; A.setParams({ id: '' }); draw(); } });
      if (!K.wide()) window.scrollTo(0, 0);
      if (ro || d.held) sp.panel.querySelectorAll('input, textarea, button.ap-pill, .cx-link').forEach(x => { x.disabled = true; });
    }

    function post(id) {
      const r = f.get(id);
      if (!r || !String(r.text || '').trim()) { A.toast('Write the notice first'); return; }
      f.set(id, { draft: '', from: r.from || d.today }, { label: 'Post' });
      if (f.isHeld(id)) f.release(id);
      f.flush().then(() => { A.toast('Posted · On the Conference page ' + (r.to ? 'until ' + K.md(r.to) : '')); A.api('GET', 'public?f=help,notices,contacts').then(p => { Object.assign(pub, p); head(); }); });
      open(id); draw();
    }

    // A new row stays here until something is typed in it (never a blank row on the server).
    function add() {
      let row;
      if (file === 'help') row = { need: '', text: '', action: '' };
      else if (file === 'notices') {
        const week = d.row.start && d.today >= d.row.start && d.today <= d.row.end;
        row = { text: '', from: d.today, to: week ? d.row.end : d.today, url: '', draft: 'yes' };
      } else row = { label: '', phone: '', pin: '', note: '', kind: '' };
      const id = f.add(row, { hold: true, label: 'Add' });
      draw(); open(id);
    }

    offs.push(K.on(f, 'remote', () => { draw(); }));
    offs.push(K.on(f, 'change', e => { if (e && e.server) { head(); } }));
    offs.push(K.undoKeys(dir => { K.replay(f, dir); draw(); if (sel && f.get(sel)) open(sel); }));
    draw();
    if (sel && f.get(sel)) open(sel);
  }
})();
