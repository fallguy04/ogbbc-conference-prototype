/*
 * Home: what's true now, and the one thing to do. The COA: what needs a decision across the year; a
 * committee: what needs it; a webmaster: years and access. Down the left: Needs you and Coming up (the
 * tasks by date, counted from the Conference's Friday); at the right: last year's notes and Activity.
 *
 * A need either opens the screen where it's done (go) or does its act here (op: "Remind heads"). A
 * past task with no screen behind it (a meeting) is asked about once: Done · Not yet.
 */
(function () {
  'use strict';
  const A = window.OGC_APP, h = A.h;

  // A need opens the screen where it's done (the Mail log is its own page).
  function needLink(go, kids, cls) {
    const mail = ((window.OGC_WP || {}).app || {}).mail;
    if (go && go.s === 'mail') return h('a', { href: mail || '#', class: cls }, kids);
    return A.link(go, kids, cls);
  }

  // An act done right here, said in a toast ("Sent to 10 heads").
  const OPS = {
    'remind:requests': (ctx, btn) => {
      btn.disabled = true;
      return ctx.api('POST', 'remind', { what: 'requests' }).then(r => {
        const bits = [r.sent ? 'Sent to ' + A.fmt.plural(r.sent, 'head') : 'No one to send to'];
        if (r.nohead) bits.push(A.fmt.plural(r.nohead, 'committee') + ' with no head');
        if (r.already) bits.push(r.already + ' sent today already');
        A.toast(bits.join(' · '));
      }).catch(e => { btn.disabled = false; A.fail(e); });
    }
  };
  function opBtn(ctx, n, big) {
    const tip = n.op === 'remind:requests' ? 'Each head gets their committee’s weekly email now, with the link to their requests' : null;
    if (big) { const b = A.btn(n.button || n.label, { primary: true, big: true, write: true, title: tip, onClick: () => OPS[n.op](ctx, b) }); return b; }
    // In the list it reads like every other row's act (tan words), and is a real button.
    const b = h('button', { type: 'button', class: 'ap-item__act ap-actbtn', title: tip, disabled: A.readonly, on: { click: () => OPS[n.op](ctx, b) } }, n.button);
    return b;
  }

  function needRow(ctx, n) {
    // Asked once: "First meeting · Nov 1 · Was it done?" Done · Not yet.
    if (n.ask) {
      const li = h('li', { class: 'ap-ask' }, h('span', { class: 'ap-dot' }),
        h('span', { class: 'ap-item__main' }, A.link(n.go, n.words, 'ap-item__title'), n.why ? h('span', { class: 'ap-item__why', text: n.why }) : null),
        h('span', { class: 'ap-ask__acts' },
          A.btn('Done', { write: true, onClick: () => ctx.api('PATCH', '/app/tasks/' + n.ask, { done: true }).then(() => {
            A.forgetTasks();
            li.remove();
            A.toast('Done · ' + n.words.replace(/ · [^·]+$/, ''), { undo: () => ctx.api('PATCH', '/app/tasks/' + n.ask, { done: false }).then(() => A.go({}, { replace: true })).catch(A.fail) });
          }).catch(A.fail) }),
          A.btn('Not yet', { ghost: true, write: true, title: 'Stays on Tasks, marked Late · Home stops asking', onClick: () => ctx.api('POST', 'later', { id: n.ask }).then(() => { li.remove(); A.toast('Kept on Tasks'); }).catch(A.fail) })));
      return li;
    }
    // An act done here: the row opens its screen, the button does the act.
    if (n.op && OPS[n.op]) {
      return h('li', { class: 'ap-ask' }, h('span', { class: 'ap-dot' + (n.tone ? ' ap-dot--' + n.tone : '') }),
        h('span', { class: 'ap-item__main' }, A.link(n.go, n.words, 'ap-item__title'), n.why ? h('span', { class: 'ap-item__why', text: n.why }) : null),
        h('span', { class: 'ap-ask__acts' }, opBtn(ctx, n, false)));
    }
    return h('li', null, needLink(n.go, [
      h('span', { class: 'ap-dot' + (n.tone ? ' ap-dot--' + n.tone : '') }),
      h('span', { class: 'ap-item__main' }, h('span', { class: 'ap-item__title', text: n.words }), n.why ? h('span', { class: 'ap-item__why', text: n.why }) : null),
      h('span', { class: 'ap-item__side' }, n.button ? h('span', { class: 'ap-item__act', text: n.button }) : null, A.icon('chev'))
    ], 'ap-item'));
  }

  // The one button: the act the headline names ("Assign all · 8", "Add head", "Start 2028").
  function primary(ctx, d) {
    if (!d.button || !d.button.label) return null;
    if (d.button.op && OPS[d.button.op]) return opBtn(ctx, { button: d.button.label, op: d.button.op }, true);
    if (!d.button.go) return null;
    return needLink(d.button.go, d.button.label, 'ap-btn ap-btn--primary ap-btn--big');
  }

  // "8 weeks before" in a narrow column: "8 wk before".
  const shortWhen = w => String(w || '').replace(/(\d+) weeks?/, '$1 wk').replace(/(\d+) days?/, '$1 d').replace(/(\d+) months/, '$1 mo');

  function coming(list) {
    const box = h('div');
    let month = '';
    let cur = null;
    list.forEach(t => {
      const m = t.due ? A.fmt.month(t.due) : (t.when === 'Dates to come' ? 'Dates to come' : 'Counted from the first day');
      if (m !== month) {
        month = m;
        box.appendChild(h('div', { class: 'ap-label ap-month', text: m }));
        cur = h('ul', { class: 'ap-list' });
        box.appendChild(cur);
      }
      // One task: Tasks with it open. One task across committees ("First meeting · 11 committees"): Tasks
      // listing each committee's (the server's go: f=kind:first_meeting), so the line opens what it names.
      const a = A.link(t.go || { s: 'tasks', id: t.id, c: '', v: '' }, [
        h('span', { class: 'ap-when', title: t.when || null, text: t.due ? A.fmt.md(t.due) : t.when === 'Dates to come' ? '' : shortWhen(t.when) }),
        h('span', { class: 'ap-item__main' }, h('span', { class: 'ap-item__title', text: t.title })),
        t.committee ? A.tag(t.committee) : null
      ], 'ap-item');
      if (t.n > 1) a.dataset.n = String(t.n);
      cur.appendChild(h('li', null, a));
    });
    return box;
  }

  // Activity by day ("Today", "Yesterday", "Fri, Oct 9"), each line's time at the right.
  function activity(list) {
    const box = h('div');
    let day = '', ul = null;
    list.forEach(a => {
      if (a.day !== day) {
        day = a.day;
        box.appendChild(h('div', { class: 'ap-label ap-feed__day', text: day }));
        ul = h('ul', { class: 'ap-feed' });
        box.appendChild(ul);
      }
      ul.appendChild(h('li', null, h('span', { text: a.words + (a.n > 1 ? ' · ' + a.n + ' times' : '') }), h('span', { class: 'ap-feed__at', text: a.at })));
    });
    return box;
  }

  // The webmasters' years: what's public now, what goes public next, the COA's sign-in.
  function yearsTable(list) {
    // A column with nothing in it isn't drawn (Next, before anything is scheduled).
    const next = list.some(y => y.next);
    return h('div', { class: 'ap-tablewrap' }, h('table', { class: 'ap-table ap-years', 'aria-label': 'Years' },
      h('thead', null, h('tr', null, ['Year', 'Public now'].concat(next ? ['Next'] : [], ['COA']).map(x => h('th', { scope: 'col', text: x })))),
      h('tbody', null, list.map(y => h('tr', null,
        h('td', { class: 'ap-td--nowrap' }, A.link({ year: y.year, s: 'home' }, y.label, 'ap-link')),
        h('td', { class: 'ap-td--muted', text: y.public }),
        next ? h('td', { class: 'ap-td--muted', text: y.next || '' }) : null,
        h('td', { class: 'ap-td--muted', text: y.coa }))))));
  }

  /* ------------------------------------------------------------ Home on the year's line */

  /*
   * Round 2 (Oct 16; docs/27 README 12, area-home-tasks 1): the headline and its one filled button; then
   * the year as a line. At Today: First steps (the COA's five, each ticking itself) and Needs you, every
   * line a door to the exact place. Below Today: Coming up by month, down to the Conference. Beside it:
   * Committees (the COA: only those late or needing a look), Notes from last year, Activity.
   */
  const TICK = () => A.yl.tick();

  function stepRow(ctx, s) {
    const L = A.yl;
    const acts = [];
    if (!s.done) {
      if (s.key === 'who' && s.act === 'Same') {
        // Same acts here only when nothing it hands needs a warning; else Who runs what asks first (1.4).
        acts.push(L.at('Same', () => ctx.api('POST', 'handing/same', {}).then(r => {
          const ch = r.changed || [];
          A.toast('Handed · ' + ch.map(x => x.title + ' · ' + x.to_name).join(' · '), { undo: () => Promise.all(ch.map(x => ctx.api('POST', 'hand', { screen: x.id, c: x.from, confirm: true }))).then(() => A.refreshBoot()).then(() => A.reload()).catch(A.fail) });
          A.refreshBoot().then(() => A.reload());
        }).catch(e => { if (e && e.status === 409) A.go(s.go); else A.fail(e); }), { write: true }));
        acts.push(L.at('Change', s.go));
      } else if (s.key === 'who') {
        acts.push(L.at('Looks right', () => ctx.api('POST', 'first-steps', { step: 'who' }).then(() => { A.toast('Checked · Who runs what', { undo: () => ctx.api('POST', 'first-steps', { step: 'who', done: false }).then(() => A.reload()).catch(A.fail) }); A.reload(); }).catch(A.fail), { write: true }));
        acts.push(L.at('Change', s.go));
      } else {
        acts.push(L.at(s.act, s.go));
      }
    }
    return h('div', { class: 'yl-steprow' + (s.done ? ' is-ok' : ''), 'data-step': s.key },
      h('span', { class: 'yl-mark' + (s.done ? ' is-ok' : ''), role: 'img', 'aria-label': s.done ? 'Done' : 'Not done' }, s.done ? TICK() : null),
      h('span', { class: 'yl-nm', text: s.words }),
      h('span', { class: 'yl-fact', text: s.line + (s.done && s.on ? ' · ' + s.on : '') }),
      h('span', { class: 'yl-acts' }, acts));
  }

  // A Needs you line: its words (a door), its why, its act in tan words (a door too), or what it waits for.
  function needLine(ctx, n) {
    const L = A.yl;
    if (n.ask || (n.op && OPS[n.op])) {
      const li = needRow(ctx, n);
      return h('div', { class: 'yl-needrow', 'data-need': n.key || '' }, li.querySelector('.ap-item__main') || li, li.querySelector('.ap-ask__acts'));
    }
    const words = needLink(n.go, n.words);
    const parts = (n.parts || []).length ? h('div', { class: 'yl-parts' }, n.parts.map(pt => A.link(pt.go, [h('b', { text: pt.name }), ' ', h('span', { class: pt.tone === 'need' ? 'yl-need' : '', text: pt.state })]))) : null;
    const act = n.wait ? h('span', { class: 'yl-meta', text: n.wait }) : n.button ? needLink(n.go, [n.button, A.icon('chev', 14)], 'yl-at') : null;
    return h('div', { class: 'yl-needrow', 'data-need': n.key || '', 'data-go': A.href(n.go || { s: 'home' }) },
      h('div', { class: 'yl-w' }, words, n.why ? h('div', { class: 'yl-meta' }, n.tone === 'late' ? [h('span', { class: 'yl-late', text: 'Late' }), ' · ' + n.why.replace(/ · Late\b/, '')] : n.why) : null, parts), act);
  }

  // Coming up, by month, down to the Conference (and, for a committee, its notes and report after it).
  function comingStages(d, list) {
    const L = A.yl;
    const out = [];
    const by = {};
    const order = [];
    list.forEach(t => {
      const k = t.due ? t.due.slice(0, 7) : 'tbd';
      if (!by[k]) { by[k] = []; order.push(k); }
      by[k].push(t);
    });
    const conf = d.start ? { conf: true, due: d.start } : null;
    let confAt = -1;
    order.forEach((k, i) => { if (confAt < 0 && conf && k !== 'tbd' && k > d.start.slice(0, 7)) confAt = i; });
    const keys = order.slice();
    const stages = keys.map(k => ({ key: k, when: k === 'tbd' ? 'Dates to come' : L.monName(k + '-01'), rows: by[k] }));
    if (conf) {
      // The Conference itself, at its day: the line's end.
      const st = { key: 'conf', when: L.dayName(d.start), conf: true, rows: [] };
      const sameMonth = stages.findIndex(x => x.key === d.start.slice(0, 7));
      // Rows of the Conference's month after its first day go after it.
      if (sameMonth >= 0) {
        const after = stages[sameMonth].rows.filter(t => t.due > d.start);
        stages[sameMonth].rows = stages[sameMonth].rows.filter(t => t.due <= d.start);
        if (!stages[sameMonth].rows.length) stages.splice(sameMonth, 1);
        const at = stages.findIndex(x => x.key > d.start.slice(0, 7) && x.key !== 'tbd');
        stages.splice(at < 0 ? stages.filter(x => x.key !== 'tbd').length : at, 0, st);
        if (after.length) stages.splice(stages.indexOf(st) + 1, 0, { key: d.start.slice(0, 7) + '-after', when: L.monName(d.start), rows: after });
      } else {
        const at = stages.findIndex(x => x.key > d.start.slice(0, 7) && x.key !== 'tbd');
        stages.splice(at < 0 ? stages.filter(x => x.key !== 'tbd').length : at, 0, st);
      }
    }
    stages.forEach((st, i) => {
      const last = i === stages.length - 1;
      const rows = st.conf ? [h('div', { class: 'yl-conf' }, h('b', { text: 'The Conference' }), h('span', { class: 'yl-meta', text: d.range + (d.venue ? ' · ' + d.venue : '') }))]
        : st.rows.map(t => { const a = A.link(t.go || { s: 'tasks', id: t.id, c: '', v: '' }, [h('span', { class: 'yl-meta', text: t.due ? L.md(t.due) : '' }), h('span', { text: t.title }), t.committee ? h('span', { class: 'yl-tag', text: t.committee }) : h('span')], 'yl-dated'); if (t.n > 1) a.dataset.n = String(t.n); return a; });
      out.push(L.stage({ key: st.key, when: st.when, state: st.conf ? 'end' : 'later', dated: true, last, rows }));
      if (st.conf && !last) out[out.length - 1].classList.remove('is-end'), out[out.length - 1].classList.add('is-later', 'is-conf');
    });
    return out;
  }

  A.screen({
    id: 'home', title: 'Home', icon: 'home', section: 'main', who: ['all'],
    render(ctx) {
      const boot = ctx.boot;
      ctx.head('Home', boot.conference.dates + (boot.conference.when ? ' · ' + boot.conference.when : ''), []);
      const body = ctx.body;
      body.appendChild(h('div', { class: 'ap-quiet', role: 'status', text: 'Loading' }));
      ctx.api('GET', 'home').then(d => {
        A.clear(body);
        body.classList.add('ap-body--flush');
        const L = A.yl;
        const page = h('div', { class: 'yl yl-home' });
        body.appendChild(page);
        // The headline and its one filled button. The Final counts line says its parts under it.
        const why = d.parts ? h('p', { class: 'yl-why' }, d.parts.map(pt => h('span', null, A.link(pt.go, [h('b', { text: pt.name }), ' ', h('span', { class: pt.tone === 'need' ? 'yl-need' : '', text: pt.state })]))))
          : d.lede ? h('p', { class: 'yl-why', text: d.lede }) : null;
        const btn = d.button && d.button.label ? (d.button.op && OPS[d.button.op] ? opBtn(ctx, { button: d.button.label, op: d.button.op }, true) : d.button.go ? needLink(d.button.go, d.button.label, 'yl-fill') : null) : null;
        page.appendChild(h('section', { class: 'yl-hero', 'data-part': 'headline' }, h('h1', { class: 'yl-head', text: d.headline }), why, btn));
        if (d.first) page.appendChild(h('p', { class: 'ap-first' }, d.first + ' · ', A.link({ s: 'committees', c: '', id: '', v: '' }, 'Committees')));

        const main = h('div', { class: 'yl-main' });
        const side = h('div', { class: 'yl-aside' });
        page.appendChild(h('div', { class: 'yl-cols' }, main, side));

        // At Today: First steps, then Needs you (the headline's need isn't said again).
        const today = [];
        if (d.steps) {
          const n = d.steps.filter(s => s.done).length;
          today.push(h('div', { class: 'yl-lab yl-group is-first', 'data-part': 'steps' }, h('h2', { text: 'First steps' }), h('span', { class: 'yl-n', text: n + ' of ' + d.steps.length })),
            h('div', { class: 'yl-list' }, d.steps.map(s => stepRow(ctx, s))));
        }
        const rest = d.needs.filter(n => !n.lead);
        if (rest.length) {
          today.push(h('div', { class: 'yl-lab yl-group' + (today.length ? '' : ' is-first'), 'data-part': 'needs' }, h('h2', { text: d.needs.length > rest.length || d.button ? 'Also needs you' : 'Needs you' }), h('span', { class: 'yl-n', text: String(rest.length) })),
            h('div', { class: 'yl-list' }, rest.map(n => needLine(ctx, n))));
        }
        if (d.years && d.years.length) today.push(h('div', { class: 'yl-lab yl-group' + (today.length ? '' : ' is-first') }, h('h2', { text: 'Years' })), yearsTable(d.years));
        // The reference (Committees, last year's notes): beside the line on a laptop, in Today's place on
        // a phone (area-home-tasks 1.2), moved, never drawn twice.
        const ref = [];
        if ((d.committees || []).length) {
          ref.push(h('section', { 'data-part': 'committees' }, L.lab('Committees', d.committees.length, A.link({ s: 'committees', c: '', v: '' }, 'All committees', 'yl-r')),
            h('div', { class: 'yl-list' }, d.committees.map(cl => h('div', { class: 'yl-needrow', 'data-go': A.href(cl.go) }, h('div', { class: 'yl-w' }, A.link(cl.go, cl.words), cl.why ? h('div', { class: 'yl-meta', text: cl.why }) : null), L.at(cl.act, cl.go))))));
        }
        if (d.last.length) {
          const k = d.last[0].ckey;
          ref.push(h('section', { 'data-part': 'notes' }, L.lab('Notes from ' + d.prev, d.last.length, A.link({ s: 'committees', c: k, at: 'notes', v: '' }, k === 'coa' ? 'COA' : (A.committee(k) || {}).name || 'Page', 'yl-r')),
            d.last.map(n => noteCard(n, ctx))));
        }
        const todayStage = L.stage({ key: 'today', when: [h('span', { text: 'Today' }), h('b', { text: L.md(d.today) })], state: 'home', rows: today, last: !d.coming.length && !d.start });
        todayStage.classList.add('is-open');
        todayStage.setAttribute('data-today', d.today);
        main.appendChild(h('div', { class: 'yl-line' }, todayStage, comingStages(Object.assign({ range: boot.conference.dates }, d), d.coming)));
        const refBox = h('div', { class: 'yl-ref' }, ref);
        const phone = window.matchMedia ? window.matchMedia('(max-width: 759px)') : null;
        const place = () => { if (phone && phone.matches) todayStage.querySelector('.yl-track').appendChild(refBox); else side.prepend(refBox); refBox.style.display = 'contents'; };
        place();
        if (phone && phone.addEventListener) phone.addEventListener('change', place);
        if (d.activity.length) side.appendChild(h('section', { 'data-part': 'activity' }, L.lab('Activity'), activity(d.activity)));
        if (!ref.length && !d.activity.length) side.remove();
        if (d.first && !A.readonly) ctx.api('POST', 'seen', { screen: 'home' }).catch(() => {});
      }).catch(err => { A.clear(body).appendChild(A.empty({ title: 'Not loaded', line: err.status === 403 ? 'No access' : 'Reload the page' })); });
    }
  });

  // A note last year's committee left, with Done (the next committee marks it).
  function noteCard(n, ctx) {
    const done = h('input', { type: 'checkbox', class: 'ap-check', 'aria-label': 'Done', disabled: A.readonly });
    const card = h('div', { class: 'ap-note' }, h('div', { class: 'ap-pre', text: n.body }),
      h('div', { class: 'ap-note__meta' }, h('label', { class: 'ap-switch' }, done, 'Done'), h('span', { text: [n.committee, n.on ? 'Written ' + n.on : ''].filter(Boolean).join(' · ') })));
    done.addEventListener('change', () => {
      A.api('PATCH', '/app/notes/' + n.id + '?year=' + ctx.boot.year, { done: done.checked }).then(() => {
        A.toast(done.checked ? 'Note marked done' : 'Note reopened', { undo: () => { done.checked = !done.checked; done.dispatchEvent(new Event('change')); } });
        card.style.opacity = done.checked ? '.55' : '';
      }).catch(e => { done.checked = !done.checked; A.fail(e); });
    });
    return card;
  }
  A.noteCard = noteCard;
})();
