/*
 * Home: what's true now, and the one thing to do. The COA: what needs a decision across the year; a
 * committee: what needs it; a webmaster: years and access. Down the left: Needs you and Coming up (the
 * tasks by date, counted from the Conference's Friday); at the right: last year's notes and Activity.
 *
 * A need either opens the screen where it's done (go) or does its act here (op: "Remind heads"). A
 * past task with no screen behind it (a meeting) is asked about once: Done · Not yet.
 */
(function () {
  'use strict';
  const A = window.OGC_APP, h = A.h;

  // A need opens the screen where it's done (the Mail log is its own page).
  function needLink(go, kids, cls) {
    const mail = ((window.OGC_WP || {}).app || {}).mail;
    if (go && go.s === 'mail') return h('a', { href: mail || '#', class: cls }, kids);
    return A.link(go, kids, cls);
  }

  // An act done right here, said in a toast ("Sent to 10 heads").
  const OPS = {
    'remind:requests': (ctx, btn) => {
      btn.disabled = true;
      return ctx.api('POST', 'remind', { what: 'requests' }).then(r => {
        const bits = [r.sent ? 'Sent to ' + A.fmt.plural(r.sent, 'head') : 'No one to send to'];
        if (r.nohead) bits.push(A.fmt.plural(r.nohead, 'committee') + ' with no head');
        if (r.already) bits.push(r.already + ' sent today already');
        A.toast(bits.join(' · '));
      }).catch(e => { btn.disabled = false; A.fail(e); });
    }
  };
  function opBtn(ctx, n, big) {
    const tip = n.op === 'remind:requests' ? 'Each head gets their committee’s weekly email now, with the link to their requests' : null;
    if (big) { const b = A.btn(n.button || n.label, { primary: true, big: true, write: true, title: tip, onClick: () => OPS[n.op](ctx, b) }); return b; }
    // In the list it reads like every other row's act (tan words), and is a real button.
    const b = h('button', { type: 'button', class: 'ap-item__act ap-actbtn', title: tip, disabled: A.readonly, on: { click: () => OPS[n.op](ctx, b) } }, n.button);
    return b;
  }

  function needRow(ctx, n) {
    // Asked once: "First meeting · Nov 1 · Was it done?" Done · Not yet.
    if (n.ask) {
      const li = h('li', { class: 'ap-ask' }, h('span', { class: 'ap-dot' }),
        h('span', { class: 'ap-item__main' }, A.link(n.go, n.words, 'ap-item__title'), n.why ? h('span', { class: 'ap-item__why', text: n.why }) : null),
        h('span', { class: 'ap-ask__acts' },
          A.btn('Done', { write: true, onClick: () => ctx.api('PATCH', '/app/tasks/' + n.ask, { done: true }).then(() => {
            A.forgetTasks();
            li.remove();
            A.toast('Done · ' + n.words.replace(/ · [^·]+$/, ''), { undo: () => ctx.api('PATCH', '/app/tasks/' + n.ask, { done: false }).then(() => A.go({}, { replace: true })).catch(A.fail) });
          }).catch(A.fail) }),
          A.btn('Not yet', { ghost: true, write: true, title: 'Stays on Tasks, marked Late · Home stops asking', onClick: () => ctx.api('POST', 'later', { id: n.ask }).then(() => { li.remove(); A.toast('Kept on Tasks'); }).catch(A.fail) })));
      return li;
    }
    // An act done here: the row opens its screen, the button does the act.
    if (n.op && OPS[n.op]) {
      return h('li', { class: 'ap-ask' }, h('span', { class: 'ap-dot' + (n.tone ? ' ap-dot--' + n.tone : '') }),
        h('span', { class: 'ap-item__main' }, A.link(n.go, n.words, 'ap-item__title'), n.why ? h('span', { class: 'ap-item__why', text: n.why }) : null),
        h('span', { class: 'ap-ask__acts' }, opBtn(ctx, n, false)));
    }
    return h('li', null, needLink(n.go, [
      h('span', { class: 'ap-dot' + (n.tone ? ' ap-dot--' + n.tone : '') }),
      h('span', { class: 'ap-item__main' }, h('span', { class: 'ap-item__title', text: n.words }), n.why ? h('span', { class: 'ap-item__why', text: n.why }) : null),
      h('span', { class: 'ap-item__side' }, n.button ? h('span', { class: 'ap-item__act', text: n.button }) : null, A.icon('chev'))
    ], 'ap-item'));
  }

  // The one button: the act the headline names ("Assign all · 8", "Add head", "Start 2028").
  function primary(ctx, d) {
    if (!d.button || !d.button.label) return null;
    if (d.button.op && OPS[d.button.op]) return opBtn(ctx, { button: d.button.label, op: d.button.op }, true);
    if (!d.button.go) return null;
    return needLink(d.button.go, d.button.label, 'ap-btn ap-btn--primary ap-btn--big');
  }

  // "8 weeks before" in a narrow column: "8 wk before".
  const shortWhen = w => String(w || '').replace(/(\d+) weeks?/, '$1 wk').replace(/(\d+) days?/, '$1 d').replace(/(\d+) months/, '$1 mo');

  function coming(list) {
    const box = h('div');
    let month = '';
    let cur = null;
    list.forEach(t => {
      const m = t.due ? A.fmt.month(t.due) : (t.when === 'Dates to come' ? 'Dates to come' : 'Counted from the first day');
      if (m !== month) {
        month = m;
        box.appendChild(h('div', { class: 'ap-label ap-month', text: m }));
        cur = h('ul', { class: 'ap-list' });
        box.appendChild(cur);
      }
      cur.appendChild(h('li', null, A.link({ s: 'tasks', id: t.id, c: '', v: '' }, [
        h('span', { class: 'ap-when', title: t.when || null, text: t.due ? A.fmt.md(t.due) : t.when === 'Dates to come' ? '' : shortWhen(t.when) }),
        h('span', { class: 'ap-item__main' }, h('span', { class: 'ap-item__title', text: t.title })),
        t.committee ? A.tag(t.committee) : null
      ], 'ap-item')));
    });
    return box;
  }

  // Activity by day ("Today", "Yesterday", "Fri, Oct 9"), each line's time at the right.
  function activity(list) {
    const box = h('div');
    let day = '', ul = null;
    list.forEach(a => {
      if (a.day !== day) {
        day = a.day;
        box.appendChild(h('div', { class: 'ap-label ap-feed__day', text: day }));
        ul = h('ul', { class: 'ap-feed' });
        box.appendChild(ul);
      }
      ul.appendChild(h('li', null, h('span', { text: a.words + (a.n > 1 ? ' · ' + a.n + ' times' : '') }), h('span', { class: 'ap-feed__at', text: a.at })));
    });
    return box;
  }

  // The webmasters' years: what's public now, what goes public next, the COA's sign-in.
  function yearsTable(list) {
    // A column with nothing in it isn't drawn (Next, before anything is scheduled).
    const next = list.some(y => y.next);
    return h('div', { class: 'ap-tablewrap' }, h('table', { class: 'ap-table ap-years', 'aria-label': 'Years' },
      h('thead', null, h('tr', null, ['Year', 'Public now'].concat(next ? ['Next'] : [], ['COA']).map(x => h('th', { scope: 'col', text: x })))),
      h('tbody', null, list.map(y => h('tr', null,
        h('td', { class: 'ap-td--nowrap' }, A.link({ year: y.year, s: 'home' }, y.label, 'ap-link')),
        h('td', { class: 'ap-td--muted', text: y.public }),
        next ? h('td', { class: 'ap-td--muted', text: y.next || '' }) : null,
        h('td', { class: 'ap-td--muted', text: y.coa }))))));
  }

  A.screen({
    id: 'home', title: 'Home', icon: 'home', section: 'main', who: ['all'],
    render(ctx) {
      const boot = ctx.boot;
      ctx.head('Home', boot.conference.dates + (boot.conference.when ? ' · ' + boot.conference.when : ''), []);
      const body = ctx.body;
      body.appendChild(h('div', { class: 'ap-quiet', role: 'status', text: 'Loading' }));
      ctx.api('GET', 'home').then(d => {
        A.clear(body);
        const hero = h('div', { class: 'ap-hero' },
          h('div', null, h('h2', { class: 'ap-headline', text: d.headline }), d.lede ? h('p', { class: 'ap-lede', text: d.lede }) : null),
          primary(ctx, d));
        body.appendChild(hero);
        // The COA's first look: who's on the year, one quiet line.
        if (d.first) {
          body.appendChild(h('p', { class: 'ap-first' }, d.first + ' · ', A.link({ s: 'committees', c: '', id: '', v: '' }, 'Committees')));
          if (!A.readonly) ctx.api('POST', 'seen', { screen: 'home' }).catch(() => {});
        }
        const left = h('div');
        const right = h('div', { class: 'ap-home-desk' });
        // Needs you: the headline is the first; the rest here. Never a zero.
        const rest = d.needs.filter(n => !n.lead);
        if (rest.length) {
          left.appendChild(h('section', { class: 'ap-section', 'aria-labelledby': 'ap-h-needs' },
            h('h3', { class: 'ap-h2', id: 'ap-h-needs' }, d.needs.length > rest.length ? 'Also needs you' : 'Needs you', h('span', { class: 'ap-h2__n', text: String(rest.length) })),
            h('ul', { class: 'ap-list' }, rest.map(n => needRow(ctx, n)))));
        }
        if (d.years && d.years.length) {
          left.appendChild(h('section', { class: 'ap-section', 'aria-labelledby': 'ap-h-years' }, h('h3', { class: 'ap-h2', id: 'ap-h-years' }, 'Years'), yearsTable(d.years)));
        }
        if (d.last.length) {
          left.appendChild(h('section', { class: 'ap-section ap-home-desk', 'aria-labelledby': 'ap-h-last' },
            h('h3', { class: 'ap-h2', id: 'ap-h-last' }, 'Notes from ' + d.prev, h('span', { class: 'ap-h2__n', text: String(d.last.length) })),
            d.last.map(n => noteCard(n, ctx))));
        }
        // Coming up beside what needs you (on a laptop the right column; under it on a phone).
        if (d.coming.length) {
          right.appendChild(h('section', { class: 'ap-section ap-home-desk', 'aria-labelledby': 'ap-h-coming' },
            h('h3', { class: 'ap-h2', id: 'ap-h-coming' }, 'Coming up', A.allowed('tasks') ? h('span', { class: 'ap-h2__act' }, A.link({ s: 'tasks', c: '', id: '' }, 'All tasks', 'ap-link')) : null),
            coming(d.coming)));
        }
        // Only what others did, and only once there's some.
        if (d.activity.length) {
          right.appendChild(h('section', { class: 'ap-section', 'aria-labelledby': 'ap-h-act' },
            h('h3', { class: 'ap-h2', id: 'ap-h-act' }, 'Activity'), activity(d.activity)));
        }
        body.appendChild(h('div', { class: 'ap-cols' }, left, right));
      }).catch(err => { A.clear(body).appendChild(A.empty({ title: 'Not loaded', line: err.status === 403 ? 'No access' : 'Reload the page' })); });
    }
  });

  // A note last year's committee left, with Done (the next committee marks it).
  function noteCard(n, ctx) {
    const done = h('input', { type: 'checkbox', class: 'ap-check', 'aria-label': 'Done', disabled: A.readonly });
    const card = h('div', { class: 'ap-note' }, h('div', { class: 'ap-pre', text: n.body }),
      h('div', { class: 'ap-note__meta' }, h('label', { class: 'ap-switch' }, done, 'Done'), h('span', { text: [n.committee, n.on ? 'Written ' + n.on : ''].filter(Boolean).join(' · ') })));
    done.addEventListener('change', () => {
      A.api('PATCH', '/app/notes/' + n.id + '?year=' + ctx.boot.year, { done: done.checked }).then(() => {
        A.toast(done.checked ? 'Note marked done' : 'Note reopened', { undo: () => { done.checked = !done.checked; done.dispatchEvent(new Event('change')); } });
        card.style.opacity = done.checked ? '.55' : '';
      }).catch(e => { done.checked = !done.checked; A.fail(e); });
    });
    return card;
  }
  A.noteCard = noteCard;
})();
