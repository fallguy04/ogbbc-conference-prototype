/*
 * screen-simple.js — simple mode (Oct 22, 2026; includes/module-app-simple.php). For 2027 the app is "here's
 * how you get the information onto the website", and the lists that come out of it; nothing of a project
 * system. With simple mode on (the default) this file draws:
 *
 *   - Home: the year's parts in the order the year uses them, each with where it stands on the website
 *     (Published · Scheduled · Draft · Not started) and one act; one filled button, the next thing to put up;
 *     under it, only the lists that matter now ("Get it out"), each a door with its count.
 *   - A committee's page: Put it on the website · Get it out · Who's on it.
 *   - Packet and Help: one place, the packet and the Help cards a switch apart in the title row.
 *   - Dates and place: the call-in line (its own screen is hidden), checked and changed in place.
 *
 * With it off, every screen draws as it did: each wrapper hands back to the screen's own render.
 * Nothing anyone typed goes into innerHTML.
 */
(function () {
  'use strict';
  const A = window.OGC_APP;
  if (!A) return;
  const h = A.h;
  const S = A.screens();
  const L = () => A.yl;
  if (A.addIcons) A.addIcons({
    book: 'M3 3.5c2-.8 3.6-.6 5 .6 1.4-1.2 3-1.4 5-.6v9c-2-.8-3.6-.6-5 .6-1.4-1.2-3-1.4-5-.6zM8 4.1v9',
    clock: 'M8 14A6 6 0 1 0 8 2a6 6 0 0 0 0 12ZM8 5v3l2 1.5',
    check: 'M3.5 8.5 6.5 11.5 12.5 4.5'
  });

  // A screen's render, drawn by simple mode while it's on (else the screen's own).
  function wrap(id, fn) {
    const d = S[id];
    if (!d || d._simple) return;
    const own = d.render;
    d._simple = true;
    d.render = function (ctx) { return A.simple() ? fn(ctx, own.bind(d)) : own.call(d, ctx); };
  }

  const md = iso => iso ? A.fmt.md(iso) : '';

  // Simple mode's names: the packet and Help are one place; a committee's Requests is its packet text.
  [['packet', 'Packet and Help'], ['help', 'Help'], ['requests', 'Packet and Help']].forEach(([id, name]) => {
    const d = S[id];
    if (!d || typeof d.title === 'function') return;
    const was = d.title;
    d.title = b => b && b.simple ? name : was;
  });
  // A committee's packet text is a book in the sidebar, as the COA's packet is.
  if (S.requests) {
    const box = S.requests.icon;
    Object.defineProperty(S.requests, 'icon', { configurable: true, get: () => A.simple() ? 'book' : box });
  }

  /* ------------------------------------------------------------ a part of the year */

  // The mark at the left of a part: a tick once it's on the website, a clock while it waits for its day,
  // an empty ring before.
  function mark(state) {
    const on = state === 'published', soon = state === 'scheduled';
    return h('span', { class: 'sm-mark is-' + state, 'aria-hidden': 'true' }, on ? A.icon('check', 12) : soon ? A.icon('clock', 14) : null);
  }
  const stateWords = p => p.state === 'scheduled' && p.when ? 'Scheduled · ' + md(p.when) : p.words;

  // One part: its name (a door when this person can open it), what it holds, its state, its one act.
  function partRow(p) {
    const title = p.go ? A.link(p.go, p.title, 'sm-nm') : h('span', { class: 'sm-nm', text: p.title });
    const row = h('div', { class: 'sm-row sm-part is-' + p.state + (p.go ? ' is-door' : ''), 'data-part': p.key || p.id, 'data-go': p.go ? A.href(p.go) : null },
      mark(p.state),
      h('span', { class: 'sm-main' }, title, h('span', { class: 'sm-line', text: p.line || '' })),
      h('span', { class: 'sm-state is-' + p.state, text: stateWords(p) }),
      h('span', { class: 'sm-act' }, p.act && p.go ? L().at(p.act, p.go) : null));
    if (p.go) row.addEventListener('click', e => { if (!e.target.closest('a,button,input')) title.click(); });
    return row;
  }

  // One list or screen to open: icon · name · what's in it · its act (the page's first need filled) · ›.
  function workRow(r, today, filled) {
    const notYet = r.on && r.on > today && !r.done;
    // Before its season: only the day it opens (what it will say isn't true yet).
    const fact = notYet ? 'Opens ' + md(r.on) : r.line || (r.need && r.need.words) || '';
    let act = null;
    if (r.need && r.need.button && !notYet) act = filled ? L().fill(r.need.button, r.need.go, { sm: true }) : L().at(r.need.button, r.need.go);
    const row = L().row({ id: r.id, icon: r.icon, title: r.title, to: r.go, fact, factNeed: !!(r.need && !notYet && r.need.tone === 'late'), act, done: false, big: !!filled });
    row.classList.add('sm-work');
    return row;
  }

  /* ------------------------------------------------------------ Home */

  wrap('home', (ctx, own) => {
    const boot = ctx.boot, v = boot.viewer;
    // The webmasters' Home is the years (what each has on the website, and its COA).
    if (v.webmaster && !v.coa && !(v.committees || []).length) return webHome(ctx);
    ctx.head('Home', boot.conference.dates + (boot.conference.when ? ' · ' + boot.conference.when : ''), []);
    const body = ctx.body;
    body.appendChild(h('div', { class: 'ap-quiet', role: 'status', text: 'Loading' }));
    let alive = true;
    ctx.api('GET', 'simple').then(d => {
      if (!alive) return;
      A.clear(body);
      body.classList.add('ap-body--flush');
      const page = h('div', { class: 'yl sm sm-home' });
      body.appendChild(page);
      // The headline: what's on the website; what goes up next by itself; the one thing to put up.
      const n = d.published, all = d.parts.length;
      const said = [n ? (n === all ? 'All ' + all + ' published' : n + ' of ' + all + ' published') : 'Nothing published yet',
        d.coming ? d.coming.title + ' goes up ' + d.coming.words : ''].filter(Boolean).join(' · ');
      page.appendChild(h('section', { class: 'yl-hero sm-hero', 'data-part': 'headline' },
        h('h1', { class: 'yl-head', text: 'On the website' }),
        h('p', { class: 'yl-why', text: said }),
        d.next ? L().fill(d.next.label, d.next.go) : null));
      page.appendChild(h('section', { class: 'sm-sec', 'data-part': 'parts', 'aria-label': 'The year’s parts' },
        h('div', { class: 'sm-list' }, d.parts.map(partRow))));
      // Get it out: only what matters now (a list with nothing in it isn't drawn, nor is the section).
      if (d.lists.length) {
        page.appendChild(h('section', { class: 'sm-sec', 'data-part': 'lists' }, L().lab('Get it out'),
          h('div', { class: 'sm-list sm-list--work' }, d.lists.map(l => { const r = L().row({ id: l.id, icon: l.icon, title: l.title, to: l.go, fact: l.line }); r.classList.add('sm-work'); return r; }))));
      }
    }).catch(err => { if (alive) A.clear(body).appendChild(A.empty({ title: 'Not loaded', line: err && err.status === 403 ? 'No access' : 'Reload the page', inset: true })); });
    return () => { alive = false; };
  });

  // The webmasters' Home: the one thing to do next (Start 2028), then every year with what's on its
  // website and its COA, each year a door to its own Home.
  function webHome(ctx) {
    const boot = ctx.boot;
    ctx.head('Home', boot.conference.dates + (boot.conference.when ? ' · ' + boot.conference.when : ''), []);
    const body = ctx.body;
    body.appendChild(h('div', { class: 'ap-quiet', role: 'status', text: 'Loading' }));
    let alive = true;
    ctx.api('GET', 'home').then(d => {
      if (!alive) return;
      A.clear(body);
      body.classList.add('ap-body--flush');
      const page = h('div', { class: 'yl sm sm-home' });
      body.appendChild(page);
      const go = d.button && d.button.go && !A.hiddenScreen(d.button.go) ? d.button : null;
      page.appendChild(h('section', { class: 'yl-hero sm-hero', 'data-part': 'headline' },
        h('h1', { class: 'yl-head', text: d.headline || 'Years' }), d.lede ? h('p', { class: 'yl-why', text: d.lede }) : null,
        go ? L().fill(go.label, go.go) : null));
      const years = d.years || [];
      if (years.length) {
        const next = years.some(y => y.next);
        page.appendChild(h('section', { class: 'sm-sec', 'data-part': 'years' }, L().lab('Years'),
          h('div', { class: 'ap-tablewrap' }, h('table', { class: 'ap-table sm-years', 'aria-label': 'Years' },
            h('thead', null, h('tr', null, ['Year', 'On the website'].concat(next ? ['Next'] : [], ['COA']).map(x => h('th', { scope: 'col', text: x })))),
            h('tbody', null, years.map(y => h('tr', null,
              h('td', { class: 'ap-td--nowrap' }, A.link({ year: y.year, s: 'home' }, y.label, 'ap-link')),
              h('td', { class: 'ap-td--muted', text: y.public }),
              next ? h('td', { class: 'ap-td--muted', text: y.next || '' }) : null,
              h('td', { class: 'ap-td--muted' }, A.allowed('members') ? A.link({ year: y.year, s: 'members', id: '', v: '' }, y.coa, 'ap-link') : y.coa))))))));
      }
    }).catch(err => { if (alive) A.clear(body).appendChild(A.empty({ title: 'Not loaded', line: err && err.status === 403 ? 'No access' : 'Reload the page', inset: true })); });
    return () => { alive = false; };
  }

  /* ------------------------------------------------------------ a committee's page */

  wrap('committees', (ctx, own) => {
    const p = ctx.params;
    const v = ctx.boot.viewer;
    // The board is the COA's only (reached from a crumb, Members current): a committee goes to its own
    // page (the webmasters have no Committees in simple mode).
    if (!p.c && !p.past && !v.coa && v.committees.length) { A.go({ s: 'committees', c: A.team(), v: '' }, { replace: true }); return; }
    // A past year and a page the viewer isn't on (another committee's short page) draw as they did.
    if (!p.c || p.past) return own(ctx);
    if (!v.coa && !(v.committees || []).some(x => x.key === p.c)) return own(ctx);
    return committeePage(ctx, p.c);
  });
  wrap('overview', (ctx, own) => {
    const key = ctx.params.c && ctx.boot.viewer.committees.some(c => c.key === ctx.params.c) ? ctx.params.c : A.team();
    return key ? committeePage(ctx, key) : own(ctx);
  });

  function committeePage(ctx, key) {
    const v = ctx.boot.viewer;
    const root = A.ownPage(key) || (key === 'coa' && v.coa);
    // The COA reaches a committee's page from Members (each committee a heading there): the way back.
    const crumb = root ? null : v.coa && A.allowed('members') ? { label: 'Members', to: { s: 'members', c: key === 'coa' ? '' : key, id: '', v: '' } } : null;
    const name0 = key === 'coa' ? 'COA' : (A.committee(key) || {}).name || key;
    ctx.head(name0, '', [], crumb ? { crumb } : null);
    const body = ctx.body;
    body.appendChild(h('div', { class: 'ap-quiet', role: 'status', text: 'Loading' }));
    let alive = true;
    ctx.api('GET', 'simple?c=' + encodeURIComponent(key)).then(c => {
      if (!alive) return;
      A.clear(body);
      body.classList.add('ap-body--flush');
      const rows = [].concat(c.put, c.out);
      // The page's one filled button: its first need (the same need the full page fills).
      const ready = r => r.need && r.need.button && !(r.on && r.on > c.today);
      const top = rows.find(r => ready(r) && r.need.top) || rows.find(ready);
      const acts = [];
      if (c.can.see_as) acts.push(A.btn('See as', { icon: 'eye', title: 'See the app as ' + c.name + ' sees it · Read only', onClick: () => A.go({ as: key, 'as-role': '', s: 'committees', c: key, team: '', id: '', v: '' }) }));
      const fact = top && top.need.words ? h('span', { class: top.need.tone === 'late' ? 'yl-late' : 'yl-need', text: top.need.words }) : '';
      ctx.head(key === 'coa' ? 'COA' : c.name, fact, acts, crumb ? { crumb } : null);
      const page = h('div', { class: 'yl sm sm-page', 'data-c': key });
      body.appendChild(page);
      const half = (part, title, list, draw) => list.length ? h('section', { class: 'sm-sec', 'data-part': part }, L().lab(title), h('div', { class: 'sm-list' + (part === 'out' ? ' sm-list--work' : '') }, list.map(draw))) : null;
      [half('put', 'Put it on the website', c.put, r => r.state ? partRow(r) : workRow(r, c.today, r === top)),
        half('out', 'Get it out', c.out, r => workRow(r, c.today, r === top)), who(c, key, v)].filter(Boolean).forEach(x => page.appendChild(x));
    }).catch(err => {
      if (!alive) return;
      A.clear(body).appendChild(A.empty({ title: err && err.status === 404 ? 'Not found' : 'Not loaded', line: err && err.status === 404 ? '' : 'Reload the page', action: A.link({ s: 'home' }, 'Home', 'ap-btn'), inset: true }));
    });
    return () => { alive = false; };
  }

  // Who's on it: one line of names (the head said), the COA's way to change it.
  function who(c, key, v) {
    const names = c.people.map(pp => pp.name + (pp.head ? ' (head)' : ''));
    if (c.asked) names.push(A.fmt.plural(c.asked, 'invited', 'invited'));
    const none = !c.people.length && !c.asked;
    const act = c.can.members && key !== 'coa'
      ? (none ? A.link({ s: 'members', c: key, id: 'new', at: 'head', v: '' }, 'Add head', 'yl-at') : A.link({ s: 'members', c: key, id: '', v: '' }, 'Members', 'yl-at'))
      : c.can.members && key === 'coa' ? A.link({ s: 'members', c: '', id: '', v: '' }, 'Members', 'yl-at') : null;
    return h('section', { class: 'sm-sec sm-who', 'data-part': 'who' }, L().lab('Who’s on it'),
      h('p', { class: 'sm-who__line' }, h('span', { text: none ? 'No one yet' : names.join(' · ') }), act));
  }

  /* ------------------------------------------------------------ Packet and Help: one place */

  // The title row says "Packet and Help" on both screens, with the switch between them.
  function switcher(cur) {
    const tab = (id, label) => {
      // Two doors to two screens (not tabs of one): the current one marked.
      const a = A.link({ s: id, c: '', id: '', v: '', at: '' }, label, 'sm-tab');
      if (cur === id) a.setAttribute('aria-current', 'page');
      return a;
    };
    return h('nav', { class: 'sm-tabs', 'aria-label': 'Packet and Help' }, tab('packet', 'Packet'), tab('help', 'Help'));
  }
  ['packet', 'help'].forEach(id => wrap(id, (ctx, own) => {
    if (!A.allowed('packet') || !A.allowed('help')) return own(ctx);
    const real = ctx.head;
    ctx.head = (t, f, a, o) => real('Packet and Help', f, [switcher(id)].concat(a || []), o);
    ctx.head('Packet and Help', '', []);
    return own(ctx);
  }));

  /* ------------------------------------------------------------ the call-in line, on Dates and place */

  /*
   * Simple mode hides the Call-in screen (the rows on the line are ticked on the Schedule; playback
   * numbers wait for 2028). What has to be set is here: the number and PIN, Not used this year, and
   * Looks right for a line carried from last year (no public page shows it before).
   */
  A.simpleCallin = function (box, y) {
    const K = window.OGC_COA;
    if (!K) return;
    const draw = data => {
      A.clear(box);
      const Ln = data.line, can = data.can && data.can.edit && !A.readonly;
      const patch = (fields, label) => A.api('PATCH', 'callin', { fields }).then(d => { K.drop(y); A.toast('Saved · ' + label); draw(Object.assign(data, d)); return ''; },
        err => (err && err.data && err.data.message) || 'Not saved');
      const text = (key, label, o) => {
        const el = K.textIn({ value: Ln[key] || '', label, placeholder: o.placeholder || '', inputmode: o.inputmode || null, width: o.width || null, live: false, disabled: !can });
        const f = K.field(label, el, { help: o.help || '' });
        const save = () => { const val = el.value.trim(); if (val === (Ln[key] || '')) { f.setError(''); return; } patch({ [key]: val }, label).then(m => f.setError(m)); };
        el.addEventListener('change', save);
        el.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); save(); } });
        return f;
      };
      const confirm = done => A.api('POST', 'callin/confirm', { done }).then(d => { K.drop(y); A.toast(done ? 'Checked · Call-in line' : 'Undone · Call-in line', done ? { undo: () => confirm(false) } : null); draw(Object.assign(data, d)); }, A.fail);
      if (Ln.status === 'off') {
        box.appendChild(K.facts([['Call-in', 'Not used this year', can ? K.link('Use it', () => patch({ off: '' }, 'In use')) : null]]));
        return;
      }
      if (Ln.status === 'check') {
        box.appendChild(h('div', { class: 'cx-from', role: 'note' },
          h('span', { class: 'cx-from__t', text: 'From ' + (Ln.from || 'last year') }), h('span', { class: 'ap-quiet', text: 'Not public until checked' }),
          A.btn('Looks right', { write: true, disabled: !can, onClick: () => confirm(true) })));
      }
      box.appendChild(h('div', { class: 'cx-two' },
        text('number', 'Number', { placeholder: '717-908-1961', inputmode: 'tel', width: '220px', help: 'On the Conference page and the guide' }),
        text('pin', 'PIN', { placeholder: 'None', inputmode: 'numeric', width: '160px', help: 'Blank when there’s none' })));
      if (can) {
        const sw = h('input', { type: 'checkbox', class: 'ap-check' });
        sw.addEventListener('change', () => { if (sw.checked) patch({ off: 'yes' }, 'Not used this year'); });
        box.appendChild(h('label', { class: 'ap-switch sm-off' }, sw, h('span', { text: 'Not used this year' })));
      }
    };
    A.api('GET', 'callin').then(draw, () => { A.clear(box).appendChild(h('p', { class: 'ap-quiet', text: 'Not loaded' })); });
  };
})();
