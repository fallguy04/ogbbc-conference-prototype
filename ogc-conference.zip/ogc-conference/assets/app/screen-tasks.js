/*
 * Tasks: what each committee does by a date, counted from the Conference's Friday where it counts from
 * it. Views: Mine (tasks someone gave you) · My committee · All (the COA). A task opens beside the
 * list: title, committee (the COA moves it), due (a date, or weeks before or after the first day), who
 * has it, a note, Done. Every change saves as it's made and says so.
 */
(function () {
  'use strict';
  const A = window.OGC_APP, h = A.h;

  // The views, each with its count: Mine 3 · COA 9 · All 61 (and Late, while something is).
  // One committee's tasks (only: ?c=lodging) read for that committee: Lodging 4 · Late · Mine, never the
  // viewer's own scope beside them (area-home-tasks 2.4), so no chip says "none" over a list that has some.
  // A chip whose scope holds no task at all isn't drawn, unless it's the view asked for.
  function viewsFor(boot, all, only, cname, current) {
    const v = boot.viewer;
    const keys = v.coa ? ['coa'] : v.committees.map(c => c.key);
    const open = all.filter(t => !t.done);
    const out = [];
    const mine = open.filter(t => v.member_id && t.owner === v.member_id).length;
    if (only) {
      out.push({ id: v.coa || v.webmaster ? 'all' : 'committee', label: cname(only), n: open.length });
      const late = open.filter(t => t.late).length;
      if (late) out.push({ id: 'late', label: 'Late', n: late });
      if (v.member_id && mine) out.push({ id: 'mine', label: 'Mine', n: mine });
      return out;
    }
    const mineName = v.coa ? 'COA' : v.committees.length === 1 ? v.committees[0].name : 'My committees';
    if (v.member_id && mine) out.push({ id: 'mine', label: 'Mine', n: mine });
    if ((v.coa || v.committees.length) && (all.some(t => keys.includes(t.committee)) || current === 'committee')) out.push({ id: 'committee', label: mineName, n: open.filter(t => keys.includes(t.committee)).length });
    if (v.coa || v.webmaster) out.push({ id: 'all', label: 'All', n: open.length });
    const late = open.filter(t => t.late && (v.webmaster && !v.coa ? true : keys.includes(t.committee))).length;
    if (late) out.push({ id: 'late', label: 'Late', n: late });
    return out;
  }
  function inView(boot, view, t, only) {
    const v = boot.viewer, keys = v.coa ? ['coa'] : v.committees.map(c => c.key);
    if (view === 'mine') return v.member_id && t.owner === v.member_id;
    // With one committee's tasks shown, its chip is all of them (whoever is looking).
    if (view === 'committee') return only ? true : keys.includes(t.committee);
    if (view === 'late') return t.late && (only || (v.webmaster && !v.coa) ? true : keys.includes(t.committee));
    return true;
  }
  // The address's filters (area-shell 1.4): f=kind:first_meeting (a Home line that names a task across
  // committees). Only kind is read here; anything else in f is left alone.
  function kindOf(f) {
    const m = String(f || '').split(';').map(x => x.split(':')).find(x => x[0] === 'kind');
    return m && /^[a-z_]{2,40}$/.test(m[1] || '') ? m[1] : '';
  }

  // A date as the app says it ("Jan 8"), typed as people say it, with the calendar a click away.
  function dateField(iso, near, onSave, label) {
    const K = window.OGC_COA;
    const box = h('span', { class: 'ap-row', style: { flexWrap: 'nowrap', gap: '6px' } });
    const shown = v => v ? A.fmt.md(v) + (near && v.slice(0, 4) !== String(near).slice(0, 4) && !(v.slice(0, 4) === String(+String(near).slice(0, 4) - 1) && v.slice(5) >= '07') ? ', ' + v.slice(0, 4) : '') : '';
    const text = h('input', { class: 'ap-input', value: shown(iso), placeholder: 'Jan 8', 'aria-label': label || 'Due date', style: { maxWidth: '150px' }, autocomplete: 'off' });
    const pick = h('input', { type: 'date', value: iso || '', tabindex: '-1', 'aria-hidden': 'true', style: { position: 'absolute', opacity: '0', width: '1px', height: '1px', pointerEvents: 'none' } });
    const cal = A.btn('Calendar', { ghost: true, iconOnly: true, icon: 'years', onClick: () => { try { pick.showPicker(); } catch (e) { pick.click(); } } });
    let last = iso || '';
    const set = v => { if (v === last) return; last = v; text.value = shown(v); pick.value = v; onSave(v); };
    text.addEventListener('change', () => {
      const t = text.value.trim();
      const v = !t ? '' : K && K.readDate ? K.readDate(t, near) : (/^\d{4}-\d\d-\d\d$/.test(t) ? t : '');
      if (t && !v) { text.setCustomValidity('Not a date'); text.reportValidity(); return; }
      text.setCustomValidity('');
      set(v);
    });
    pick.addEventListener('change', () => set(pick.value));
    box.append(text, cal, pick);
    return box;
  }

  // Due, in the panel: a date, or so many weeks or days before or after the first day.
  // The date shown is the one shown everywhere (t.due): never a stored date the list doesn't use.
  function dueEditor(t, hasFriday, onSave, near) {
    const mode = t.date ? 'date' : (t.offset != null ? 'offset' : 'date');
    const box = h('div');
    const date = dateField(t.due || '', near, v => { if (m === 'date') onSave({ date: v || '' }); }, 'Due date');
    const n = h('input', { class: 'ap-input', type: 'number', min: '0', max: '400', style: { width: '90px' }, 'aria-label': 'How many', value: t.offset != null ? String(Math.abs(t.offset % 7 === 0 ? t.offset / 7 : t.offset)) : '2' });
    let unit = t.offset != null && t.offset % 7 !== 0 ? 'days' : 'weeks';
    let side = t.offset != null && t.offset > 0 ? 'after' : 'before';
    let m = mode;
    const pills = (opts, cur, set) => h('div', { class: 'ap-pills' }, opts.map(o => h('button', { type: 'button', class: 'ap-pill', 'aria-pressed': String(o[0] === cur), on: { click: () => { set(o[0]); draw(); save(); } } }, o[1])));
    const save = () => {
      if (m === 'date') return;
      else {
        const k = Math.max(0, parseInt(n.value || '0', 10)) * (unit === 'weeks' ? 7 : 1) * (side === 'before' ? -1 : 1);
        onSave({ offset: k });
      }
    };
    n.addEventListener('change', save);
    const draw = () => {
      A.clear(box);
      box.appendChild(pills([['date', 'Date'], ['offset', 'Weeks before Conference']], m, x => { m = x; }));
      if (m === 'date') box.appendChild(h('div', { style: { marginTop: '8px' } }, date));
      else {
        box.appendChild(h('div', { class: 'ap-row', style: { marginTop: '8px' } }, n, pills([['weeks', 'Weeks'], ['days', 'Days']], unit, x => { unit = x; }), pills([['before', 'Before'], ['after', 'After']], side, x => { side = x; })));
        if (!hasFriday) box.appendChild(h('span', { class: 'ap-help', text: 'A date once the Conference has dates' }));
      }
    };
    draw();
    return box;
  }

  // What ticks a task tied to its screen, in the committee's words.
  const DONE_WHEN = {
    requests_answer: 'every request is answered', requests_sent: 'the requests go to the campus', meals_sent: 'the final counts are sent',
    reg_open: 'registration opens', announce: 'the Conference is announced', schedule: 'the schedule is published',
    signups_open: 'volunteer sign-ups open', rooms_published: 'the rooms are published'
  };

  // Where a task tied to its screen is done: that screen, and for a list each committee has its own of
  // (Requests, Helpers), the task's committee's (never the COA's own Intake board for Ushers' task).
  const PER_COMMITTEE = ['requests', 'helpers'];
  A.taskWhere = (screen, t) => ({ s: screen, c: PER_COMMITTEE.includes(screen) && t && t.committee !== 'coa' ? t.committee : '', id: '', v: '' });

  // "Done Nov 1 · Ruth K.", or, ticked by the work itself, "Done · from Meal counts · May 12".
  function doneWords(t) {
    if (t.auto) return 'Done · from ' + t.auto + (t.done_on ? ' · ' + t.done_on : '');
    return 'Done ' + (t.done_on || '') + (t.done_by ? ' · ' + t.done_by : '');
  }
  A.taskDoneWords = doneWords;

  A.screen({
    id: 'tasks', title: 'Tasks', icon: 'tasks', section: 'main', who: ['all'],
    render(ctx) {
      const boot = ctx.boot, v = boot.viewer, p = ctx.params;
      // One committee's tasks (?c=lodging: a committee's page's All tasks): its crumb leads back to the
      // page. The server sends only what the viewer may see, so another committee's are simply none.
      let only = p.c && (p.c === 'coa' || A.committee(p.c)) ? p.c : '';
      // One task across committees (?f=kind:first_meeting, Home's "First meeting · 11 committees"): each
      // committee's own row, with a pill that names it and × to see every task again.
      let kind = kindOf(p.f);
      // The COA starts on its own tasks; All is a chip away. One committee's tasks start on all of them.
      const defOf = () => only ? (v.coa || v.webmaster ? 'all' : 'committee') : (v.webmaster && !v.coa ? 'all' : 'committee');
      let views = [], view = p.v || defOf();
      // One committee's chip is that committee's whole list, whatever it was called in the address.
      if (only && view === 'committee' && (v.coa || v.webmaster)) view = 'all';
      const sp = ctx.split();
      let every = [], rows = [], drawnTasks = [];
      let hasFriday = true;
      const canWrite = t => !A.readonly && (v.coa || v.committees.some(c => c.key === t.committee));
      const cname = k => k === 'coa' ? 'COA' : ((A.committee(k) || {}).name || k);
      const many = () => !only && (v.coa || v.webmaster || v.committees.length > 1);
      const scoped = () => every.filter(t => (!only || t.committee === only) && (!kind || t.kind === kind));

      // A task opened by its address (Home's Coming up, a committee's page, ⌘K) opens in the narrowest
      // view that holds it: the one asked for, else the viewer's own, else All; the committee filter
      // goes only if it would hide it (area-shell 1.3, area-home-tasks 2.9). Said by the chip pressed.
      const pickView = () => {
        if (!p.id || p.id === 'new') return;
        const t = every.find(x => String(x.id) === String(p.id));
        if (!t) return;
        if (only && t.committee !== only) only = '';
        if (kind && t.kind !== kind) kind = '';
        const vs = viewsFor(boot, scoped(), only, cname, view);
        const has = id => vs.some(x => x.id === id) && inView(boot, id, t, only);
        const want = has(view) ? view : ['committee', 'all', 'mine', 'late'].find(has);
        if (want && want !== view) view = want;
        A.setParams({ c: only, f: kind ? 'kind:' + kind : '', v: view === defOf() ? '' : view });
      };

      const draw = keepPanel => {
        views = viewsFor(boot, scoped(), only, cname, view);
        if (!views.some(x => x.id === view)) view = views.length ? (views.some(x => x.id === defOf()) ? defOf() : views[0].id) : defOf();
        rows = scoped().filter(t => inView(boot, view, t, only));
        A.clear(sp.main);
        const open = rows.filter(t => !t.done), late = rows.filter(t => t.late).length;
        const crumb = only ? { crumb: { label: cname(only), to: { s: 'committees', c: only } } } : null;
        ctx.head('Tasks', A.fmt.plural(open.length, 'open task') + (late ? ' · ' + late + ' late' : ''),
          v.coa || v.committees.length ? [A.btn('Add task', { primary: true, icon: 'plus', write: true, onClick: () => openNew() })] : [], crumb);
        const chips = views.length > 1 ? A.views(views, view, id => A.go({ v: id, id: '' }, { replace: true })) : null;
        // A filter set by a link, with × to clear it: the committee (the COA, webmasters) and the task
        // ("First meeting ×", from Home's line that names it across committees).
        const filterPill = (label, to, sr) => { const x = A.link(to, h('span', { class: 'ap-sr', text: sr }), 'ap-chip__x'); x.appendChild(A.icon('x', 13)); return h('span', { class: 'ap-chip ap-chip--filter' }, label, x); };
        const pill = only && (v.coa || v.webmaster || v.committees.length > 1) ? filterPill(cname(only), { c: '', v: '', id: '' }, 'Every committee’s tasks') : null;
        const kt = kind ? (every.find(t => t.kind === kind) || {}).title : '';
        const kpill = kind ? filterPill(kt || 'Task', { f: '', id: '' }, 'Every task') : null;
        if (kpill) kpill.dataset.n = String(scoped().length);
        if (chips || pill || kpill) sp.main.appendChild(h('div', { class: 'ap-views' }, chips, pill, kpill));
        const sorted = open.concat(rows.filter(t => t.done));
        drawnTasks = sorted;
        sp.main.appendChild(A.table({
          label: 'Tasks', rows: sorted, key: t => t.id, selected: p.id,
          group: t => t.done ? 'Done' : t.due ? A.fmt.month(t.due) : t.due_words === 'Dates to come' ? 'Dates to come' : (t.due_words ? 'Weeks before Conference' : 'No date'),
          // A task opened here is its own history entry: Back closes it first (A.openRecord).
          onOpen: t => { p.id = String(t.id); A.openRecord({ id: t.id }); draw(); },
          empty: only && !v.coa && !v.webmaster && !v.committees.some(c => c.key === only)
            ? A.empty({ title: 'Not ' + cname(only) + '’s tasks', inset: true, action: A.link({ c: '', v: '', id: '' }, 'Your tasks', 'ap-btn') })
            : A.empty({ title: view === 'mine' ? 'None given to you' : 'No tasks', line: view === 'mine' ? 'Tasks with your name show here' : only ? cname(only) + ' has none for ' + boot.year : '', inset: true }),
          cols: [
            { label: 'Done', cls: 'ap-td--check', render: t => { if (t.screen && !t.done && !t.auto) return ''; const b = h('input', { type: 'checkbox', class: 'ap-check', checked: t.done, disabled: !canWrite(t) || !!t.auto || (!!t.screen && !t.done), title: t.auto ? 'Done · from ' + t.auto : t.screen && !t.done ? 'Done when ' + (DONE_WHEN[t.kind] || 'it’s done on its screen') : null, 'aria-label': 'Done: ' + t.title }); b.addEventListener('change', () => A.toggleTask(ctx, t, b)); return b; } },
            // A task the work ticks says so, with its screen one tap away (no faint box nobody can tick).
            { label: 'Task', cls: '', rowCls: t => t.done ? 'ap-td--done' : '', render: t => h('span', null, h('span', { class: 'ap-cell-title', text: t.title }),
              t.screen && !t.done ? h('span', { class: 'ap-cell-sub' }, 'Done when ' + (DONE_WHEN[t.kind] || 'it’s done there') + ' · ', screenLink(t.screen, t)) : t.note ? h('span', { class: 'ap-cell-sub', text: t.note.split('\n')[0] }) : null) },
            // A column whose value is the same on every row (the COA's view: all COA) isn't drawn.
            many() && new Set(sorted.map(t => t.committee)).size > 1 ? { label: 'Committee', cls: 'ap-td--nowrap', render: t => A.tag(cname(t.committee)) } : null,
            { label: 'Due', cls: 'ap-td--nowrap', render: t => t.done ? h('span', { class: 'ap-quiet', text: doneWords(t) }) : t.late ? A.tag(t.due_words + ' · Late', 'late') : h('span', { text: t.due_words }) },
            // A column with nothing in it isn't drawn.
            open.some(t => t.owner_name) ? { label: 'Who', cls: 'ap-td--nowrap ap-td--muted', wide: true, render: t => t.done ? '' : (t.owner_name || '') } : null
          ].filter(Boolean)
        }));
        const cur = p.id && p.id !== 'new' ? rows.find(t => String(t.id) === String(p.id)) : null;
        if (keepPanel) return;
        if (cur) openTask(cur);
        else if (p.id === 'new') openNew();
        // Removed, or not this viewer's: said in the panel, the list as it was (never a silent nothing).
        else if (p.id) sp.open({ title: 'Not found', body: [A.empty({ title: 'Not found', line: 'Removed, or another committee’s', inset: true })], onClose: () => { p.id = ''; A.closeRecord(); } });
        else sp.close(true);
      };

      // Someone invited who hasn't signed in has no name yet: "Invited", never a piece of their address.
      const people = k => boot.people.filter(pp => pp.committees.includes(k)).map(pp => /[*@]/.test(pp.name || '') ? Object.assign({}, pp, { name: 'Invited' }) : pp);
      // A screen by its name, also for a screen this viewer doesn't open (a webmaster reading Tasks).
      const titleOfScreen = id => (boot.screens.find(x => x.id === id) || {}).title || (typeof (A.screens()[id] || {}).title === 'string' ? A.screens()[id].title : id);
      // A tied task's screen, as a link in its row (the row itself still opens the task). A list every
      // committee has its own of (Requests, Helpers) opens on the task's committee's.
      const screenLink = (id, t) => {
        if (!A.allowed(id)) return h('span', { text: titleOfScreen(id) });
        const a = A.link(A.taskWhere(id, t), titleOfScreen(id), 'ap-link');
        a.addEventListener('click', e => e.stopPropagation());
        return a;
      };

      function openTask(t) {
        const ro = !canWrite(t);
        const status = h('span', { class: 'ap-quiet', role: 'status' });
        // undo: the fields as they were, put back by the toast's Undo (Who has it: one tap saves, so one tap
        // takes it back).
        const patch = (data, words, undo) => ctx.api('PATCH', '/app/tasks/' + t.id, data).then(r => {
          Object.assign(t, r);
          A.forgetTasks();
          status.textContent = 'Saved';
          if (words) A.toast(words, undo ? { undo: () => patch(undo, 'Undone · ' + words) } : null);
          draw(true);
          if (data.owner != null && whoPills) whoPills.querySelectorAll('[data-owner]').forEach(b => b.setAttribute('aria-pressed', String(+b.dataset.owner === (t.owner || 0))));
        }).catch(A.fail);
        let whoPills = null;
        // Opened to read: nothing is focused for typing (the panel's heading has focus).
        const title = h('input', { class: 'ap-input', value: t.title, maxlength: '190', disabled: ro, 'aria-label': 'Task' });
        title.addEventListener('change', () => title.value.trim() && patch({ title: title.value }));
        const note = h('textarea', { class: 'ap-textarea', rows: '3', value: t.note || '', disabled: ro });
        note.addEventListener('change', () => patch({ note: note.value }));
        // A task the work ticks (Schedule published) says so; ticking it by hand is there, but asked for.
        const done = h('input', { type: 'checkbox', checked: t.done, disabled: ro || (!!t.auto && t.done) });
        done.addEventListener('change', () => A.toggleTask(ctx, t, done));
        const tied = t.screen && !t.done;
        const anyway = tied && !ro ? h('details', { class: 'ap-more' }, h('summary', { text: 'Mark done anyway' }), h('label', { class: 'ap-switch', style: { marginTop: '8px' } }, done, 'Done')) : null;
        // Moving a task to another committee is rare: under More (the COA only).
        const move = v.coa && !ro ? h('details', { class: 'ap-more' }, h('summary', { text: 'More · Committee: ' + cname(t.committee) }),
          h('div', { class: 'ap-pills', style: { marginTop: '8px' } }, boot.committees.map(c => h('button', { type: 'button', class: 'ap-pill', 'aria-pressed': String(c.key === t.committee), on: { click: () => c.key !== t.committee && patch({ committee: c.key }, 'Moved to ' + c.name) } }, c.key === 'coa' ? 'COA' : c.name)))) : null;
        // Whose task it is, and a way to its page (the COA reads every committee's from here).
        const whose = t.committee === 'coa' ? 'COA' : cname(t.committee);
        const body = [
          h('label', { class: 'ap-field' }, h('span', { text: 'Task' }), title),
          h('div', { class: 'ap-field' }, h('span', { text: 'Committee' }), A.allowed('committees') && (v.coa || v.webmaster || v.committees.some(c => c.key === t.committee))
            ? A.link({ s: 'committees', c: t.committee }, whose, 'ap-link') : h('span', { class: 'ap-muted', text: whose })),
          // One date, from one source: a task whose date a setting decides (Answer requests: the round's due
          // date) shows that date, said as such, and isn't typed over here.
          h('div', { class: 'ap-field' }, h('span', { text: 'Due' }), ro || t.due_from ? h('span', { class: 'ap-muted', text: (t.due_words || 'No date') + (t.due_from ? ' · ' + t.due_from : '') })
            : [dueEditor(t, hasFriday, d => patch(d), boot.conference.start || boot.conference.today), !t.due && t.date ? h('span', { class: 'ap-help', text: 'Dates to come' }) : null]),
          people(t.committee).length ? h('div', { class: 'ap-field' }, h('span', { text: 'Who has it' }), ro ? h('span', { class: 'ap-muted', text: t.owner_name || 'The committee' })
            : (whoPills = h('div', { class: 'ap-pills' }, [{ id: 0, name: 'The committee' }].concat(people(t.committee)).map(pp => h('button', { type: 'button', class: 'ap-pill', 'data-owner': String(pp.id), 'aria-pressed': String((t.owner || 0) === pp.id), on: { click: () => { const was = t.owner || 0; if (was === pp.id) return; patch({ owner: pp.id }, pp.id ? 'Given to ' + pp.name : 'Given to the committee', { owner: was }); } } }, pp.name))))) : null,
          h('label', { class: 'ap-field' }, h('span', { text: 'Note' }), note),
          t.done ? (t.auto ? null : h('label', { class: 'ap-switch' }, done, 'Done')) : tied ? h('p', { class: 'ap-help', text: 'Done when ' + (DONE_WHEN[t.kind] || ('it’s done on ' + titleOfScreen(t.screen))) }) : h('label', { class: 'ap-switch' }, done, 'Done'),
          t.done ? h('p', { class: 'ap-quiet', text: doneWords(t) }) : null,
          anyway,
          move,
          t.source === 'carried' ? h('p', { class: 'ap-quiet', text: 'From last year' }) : null
        ];
        // A task done on a screen opens it: the one filled button.
        const openIt = t.screen && A.allowed(t.screen) ? A.link(A.taskWhere(t.screen, t), 'Open ' + titleOfScreen(t.screen), 'ap-btn' + (t.done ? '' : ' ap-btn--primary')) : null;
        // Previous · Next through the list as drawn (the record kit, Round 3).
        const i = drawnTasks.findIndex(x => x.id === t.id);
        const stepTo = x => () => { p.id = String(x.id); A.openRecord({ id: x.id }); draw(); };
        sp.open({
          title: t.title, body,
          tags: [t.done ? A.tag('Done', 'ok') : t.late ? A.tag('Late', 'late') : null, t.committee ? A.tag(whose) : null],
          nav: i < 0 ? null : { prev: i > 0 ? stepTo(drawnTasks[i - 1]) : null, next: i < drawnTasks.length - 1 ? stepTo(drawnTasks[i + 1]) : null },
          foot: ro ? (openIt ? [openIt] : null) : [openIt, status, h('span', { style: { flex: '1' } }), A.btn('Remove', { danger: true, ghost: true, write: true, onClick: () => ctx.api('DELETE', '/app/tasks/' + t.id).then(r => {
            A.forgetTasks();
            A.toast('Removed · ' + t.title, { undo: () => ctx.api('POST', 'tasks?c=' + encodeURIComponent(r.task.committee), { title: r.task.title, note: r.task.note, offset: r.task.offset, date: r.task.date }).then(nt => A.go({ id: nt.id }, { replace: true })).catch(A.fail) });
            A.go({ id: '' }, { replace: true });
          }).catch(A.fail) })],
          onClose: () => { p.id = ''; A.closeRecord(); draw(true); },
          focus: 'head'
        });
      }

      function openNew() {
        const mine = v.coa ? boot.committees.map(c => c.key) : v.committees.map(c => c.key);
        let ck = v.coa ? 'coa' : A.team() || mine[0];
        const title = h('input', { class: 'ap-input', maxlength: '190', 'data-autofocus': '' });
        const date = h('input', { class: 'ap-input', type: 'date', 'aria-label': 'Due date' });
        const err = h('div', { class: 'ap-err', role: 'alert' });
        const pills = h('div', { class: 'ap-pills' });
        const drawPills = () => { A.clear(pills); mine.forEach(k => pills.appendChild(h('button', { type: 'button', class: 'ap-pill', 'aria-pressed': String(k === ck), on: { click: () => { ck = k; drawPills(); } } }, cname(k)))); };
        drawPills();
        const add = () => {
          if (!title.value.trim()) { err.textContent = 'Task needed'; title.focus(); return; }
          ctx.api('POST', 'tasks?c=' + encodeURIComponent(ck), { title: title.value, date: date.value }).then(t => {
            A.forgetTasks();
            A.toast('Added · ' + t.title);
            A.go({ id: t.id, v: view === 'mine' ? 'committee' : view }, { replace: true });
          }).catch(e => { err.textContent = (e.data && e.data.message) || 'Not added'; });
        };
        title.addEventListener('keydown', e => { if (e.key === 'Enter') add(); });
        sp.open({
          title: 'Add task',
          body: [
            h('label', { class: 'ap-field' }, h('span', { text: 'Task' }), title),
            mine.length > 1 ? h('div', { class: 'ap-field' }, h('span', { text: 'Committee' }), pills) : null,
            h('label', { class: 'ap-field' }, h('span', { text: 'Due' }), date, h('span', { class: 'ap-help', text: 'Optional · Or weeks before the first day, once added' })),
            err
          ],
          foot: [A.btn('Add', { primary: true, write: true, onClick: add })],
          onClose: () => { p.id = ''; A.setParams({ id: '' }); }
        });
      }

      sp.main.appendChild(h('div', { class: 'ap-quiet', style: { padding: '20px' }, role: 'status', text: 'Loading' }));
      ctx.api('GET', 'tasks').then(r => { every = r.tasks; hasFriday = r.friday; pickView(); draw(); })
        .catch(() => { A.clear(sp.main).appendChild(A.empty({ title: 'Not loaded', line: 'Reload the page', inset: true })); });
    }
  });

  A.action({ id: 'add-task', title: 'Add task', screen: 'tasks', when: b => (b.viewer.coa || b.viewer.committees.length > 0) && !b.viewer.as, run: () => A.go({ s: 'tasks', id: 'new', c: '' }) });
})();
