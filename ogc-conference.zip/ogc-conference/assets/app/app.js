/*
 * OGC_APP: the committees' app (docs/23). The kit, the shell and the screen registry.
 *
 *   OGC_APP.screen({ id, title, icon, section, who, render(ctx), title?(boot) })
 *       A screen. Who may see it is the server's rule (ogc_app_screens in module-app.php, the same id):
 *       the shell draws only the screens /boot lists. render(ctx) draws into ctx.body; ctx has
 *       head(title, fact, actions), params, boot, api, go, readonly, split().
 *   OGC_APP.action({ id, title, screen?, run(), when?(boot) })   a ⌘K action (Add task, Add people…)
 *   OGC_APP.api(method, path, body)   /wp-json/ogc/v1/app/<year>/<path>, with ?as= when seeing as
 *   OGC_APP.go(params, { replace })    to another screen: ?year=&s=&c=&id=&as=&team=&v=
 *   OGC_APP.h(tag, attrs, ...kids)     DOM without innerHTML: text is always text
 *   OGC_APP.btn, tag, empty, toast, menu, table, panel, icon, fmt (DEV.md › App › The kit)
 *
 * Nothing a person typed ever goes into innerHTML: every node is built with h() and textContent.
 */
(function () {
  'use strict';
  const W = window.OGC_WP || {};
  const CFG = W.app || {};
  const A = window.OGC_APP = {};
  const SCREENS = {};
  const ACTIONS = [];
  let boot = null;
  let cleanup = null;

  /* ------------------------------------------------------------ DOM */

  // h('a', { class: 'x', href, on: { click }, text: 'Hi' }, child, [children], null)
  const h = A.h = function (tag, attrs, ...kids) {
    const el = document.createElement(tag);
    const a = attrs || {};
    for (const k in a) {
      const v = a[k];
      if (v == null || v === false) continue;
      if (k === 'class') el.className = v;
      else if (k === 'text') el.textContent = v;
      else if (k === 'on') { for (const ev in v) el.addEventListener(ev, v[ev]); }
      else if (k === 'style' && typeof v === 'object') Object.assign(el.style, v);
      else if (k === 'value') el.value = v;
      else if (k === 'checked' || k === 'disabled' || k === 'hidden' || k === 'selected') el[k] = !!v;
      else if (k === 'href') el.setAttribute('href', safeHref(v));
      else el.setAttribute(k, v === true ? '' : String(v));
    }
    add(el, kids);
    return el;
  };
  function add(el, kids) {
    for (const k of kids) {
      if (k == null || k === false) continue;
      if (Array.isArray(k)) add(el, k);
      else el.appendChild(k instanceof Node ? k : document.createTextNode(String(k)));
    }
  }
  // Only our own addresses (a path, or this site's own origin) and https: links (a committee's
  // folder) are written into an href.
  function safeHref(v) {
    const s = String(v);
    return /^(\/(?!\/)|\?|#|https:\/\/)/i.test(s) || s.indexOf(location.origin + '/') === 0 ? s : '#';
  }
  const clear = el => { while (el.firstChild) el.removeChild(el.firstChild); return el; };
  A.clear = clear;

  /* ------------------------------------------------------------ icons (16 px, strokes) */

  const PATHS = {
    home: 'M3 7.5 8 3l5 4.5V13H9.5V9.5h-3V13H3z',
    committees: 'M5.5 7a2 2 0 1 0 0-4 2 2 0 0 0 0 4Zm5 0a2 2 0 1 0 0-4 2 2 0 0 0 0 4ZM2 13c0-2 1.6-3.5 3.5-3.5S9 11 9 13m-.5-2.6c.6-.6 1.3-.9 2-.9 1.9 0 3.5 1.5 3.5 3.5',
    tasks: 'M3 4.5 4.5 6 7 3.5M3 10.5 4.5 12 7 9.5M9 5h4.5M9 11h4.5',
    members: 'M8 7.5a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5ZM3 13.5c.4-2.3 2.5-4 5-4s4.6 1.7 5 4M12.5 2v3M11 3.5h3',
    overview: 'M2.5 3.5h11v9h-11zM2.5 6.5h11M6 6.5v6',
    years: 'M3 3.5h10v10H3zM3 6.5h10M6 2v3M10 2v3',
    search: 'M7 12A5 5 0 1 0 7 2a5 5 0 0 0 0 10Zm3.5-1.5L14 14',
    plus: 'M8 3v10M3 8h10',
    x: 'M4 4l8 8M12 4l-8 8',
    chev: 'M6 4l4 4-4 4',
    down: 'M4 6l4 4 4-4',
    menu: 'M2.5 4.5h11M2.5 8h11M2.5 11.5h11',
    mail: 'M2.5 4h11v8h-11zM2.5 4.5 8 8.5l5.5-4',
    eye: 'M1.5 8S4 3.5 8 3.5 14.5 8 14.5 8 12 12.5 8 12.5 1.5 8 1.5 8Zm6.5 2a2 2 0 1 0 0-4 2 2 0 0 0 0 4Z',
    file: 'M4 2h5l3 3v9H4zM9 2v3h3',
    out: 'M6 3H3v10h3M10 5l3 3-3 3M13 8H6',
    back: 'M10 4 6 8l4 4',
    note: 'M3 2.5h10v8l-3 3H3zM10 13.5v-3h3',
    report: 'M4 2h8v12H4zM6 5h4M6 8h4M6 11h2',
    link: 'M7 9a3 3 0 0 0 4.2 0l2-2a3 3 0 0 0-4.2-4.2l-.6.6M9 7a3 3 0 0 0-4.2 0l-2 2A3 3 0 0 0 7 13.2l.6-.6',
    upload: 'M8 11V3M5 6l3-3 3 3M3 11v2.5h10V11',
    // Each committee screen its own plain mark, so the sidebar can be read by its icons.
    bed: 'M2 12.5V4M2 9.5h12v3M14 9.5V8a2 2 0 0 0-2-2H7.5v3.5M4.5 8a1 1 0 1 0 0-.01',
    key: 'M9.5 6.5a3 3 0 1 1-.9-2.1M8.6 4.4 13.5 9.3l-1.2 1.2-1-1-1 1-1-1',
    caravan: 'M1.5 11.5h11v-6a1.5 1.5 0 0 0-1.5-1.5H3a1.5 1.5 0 0 0-1.5 1.5zM12.5 9.5h2M4 6.5h3v2.5H4zM5.5 13a1.2 1.2 0 1 0 0-.01',
    house: 'M2.5 7 8 2.5 13.5 7M4 6v7.5h8V6M6.5 13.5V10h3v3.5',
    // Young Folks' halls: a bunk bed (never the two heads of Committees).
    bunk: 'M3 2.5v11M13 2.5v11M3 7h10M3 12h10M5 5.2h3M5 10.2h3',
    pair: 'M5 7a2 2 0 1 0 0-4 2 2 0 0 0 0 4Zm6 0a2 2 0 1 0 0-4 2 2 0 0 0 0 4ZM1.5 13.5c.3-2 1.7-3.5 3.5-3.5s3.2 1.5 3.5 3.5M7.5 13.5c.3-2 1.7-3.5 3.5-3.5s3.2 1.5 3.5 3.5',
    plate: 'M8 13a5 5 0 1 0 0-10 5 5 0 0 0 0 10Zm0-2.5a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5ZM1 3v4M15 3v10',
    hand: 'M5 8V3.5a1 1 0 0 1 2 0V7m0-3.5a1 1 0 0 1 2 0V7m0-2.5a1 1 0 0 1 2 0V9a4.5 4.5 0 0 1-8.3 2.4L2.3 9.2a1 1 0 0 1 1.6-1.2L5 9.3',
    child: 'M8 6a2 2 0 1 0 0-4 2 2 0 0 0 0 4ZM5 14l1-5h4l1 5M4.5 8.5 8 7.5l3.5 1',
    cup: 'M4 2.5h8l-1 6a3 3 0 0 1-6 0zM8 11.5V14M5.5 14h5',
    flag: 'M3.5 14V2.5M3.5 3h8l-1.5 2.5 1.5 2.5h-8',
    pin: 'M8 14s4.5-4.2 4.5-7.5a4.5 4.5 0 0 0-9 0C3.5 9.8 8 14 8 14Zm0-6a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3Z'
  };
  // The sidebar's mark for each screen, by id (a screen's own icon otherwise).
  const ICON_FOR = { 'lod-households': 'house', 'lod-rooms': 'bed', 'lod-checkin': 'key', 'lod-yf': 'bunk', 'lod-campers': 'caravan', 'lod-import': 'upload', 'food-meals': 'plate', 'food-menus': 'note', helpers: 'hand', 'preteens-list': 'child', 'communion-list': 'cup', 'yf-teams': 'flag', overview: 'overview' };
  A.iconFor = id => ICON_FOR[id] || (SCREENS[id] && SCREENS[id].icon) || id;
  // A screen file may add its own 16 px strokes (the COA's screens: clock, pin, book…).
  A.addIcons = o => { Object.keys(o || {}).forEach(k => { if (!PATHS[k]) PATHS[k] = o[k]; }); };
  A.icon = function (name, size) {
    const s = size || 16;
    const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    svg.setAttribute('width', s); svg.setAttribute('height', s); svg.setAttribute('viewBox', '0 0 16 16');
    svg.setAttribute('fill', 'none'); svg.setAttribute('stroke', 'currentColor'); svg.setAttribute('stroke-width', '1.4');
    svg.setAttribute('stroke-linecap', 'round'); svg.setAttribute('stroke-linejoin', 'round'); svg.setAttribute('aria-hidden', 'true');
    const p = document.createElementNS('http://www.w3.org/2000/svg', 'path');
    p.setAttribute('d', PATHS[name] || PATHS.overview);
    svg.appendChild(p);
    return svg;
  };

  /* ------------------------------------------------------------ the kit */

  // A button. o: { primary, ghost, danger, big, icon, title, disabled, onClick, href, write }
  // A write button is disabled while seeing as (read only), with the reason in its tooltip.
  A.btn = function (label, o) {
    o = o || {};
    const ro = o.write && A.readonly;
    const cls = 'ap-btn' + (o.primary ? ' ap-btn--primary' : '') + (o.ghost ? ' ap-btn--ghost' : '') + (o.danger ? ' ap-btn--danger' : '') + (o.big ? ' ap-btn--big' : '') + (o.iconOnly ? ' ap-btn--icon' : '');
    const kids = [o.icon ? A.icon(o.icon) : null, o.iconOnly ? h('span', { class: 'ap-sr', text: label }) : label];
    if (o.href && !ro) return h('a', { class: cls, href: o.href, title: o.title, download: o.download }, kids);
    return h('button', {
      type: 'button', class: cls, title: ro ? 'Read only while seeing as ' + boot.viewer.as_name : o.title,
      disabled: o.disabled || ro, 'aria-label': o.iconOnly ? label : null,
      on: { click: e => { if (o.onClick) o.onClick(e); } }
    }, kids);
  };
  A.tag = (text, tone) => h('span', { class: 'ap-tag' + (tone ? ' ap-tag--' + tone : '') }, text);
  // An empty state: one dashed card, never a bare line. o: { title, line, action: node }
  A.empty = o => h('div', { class: 'ap-empty' + (o.inset ? ' ap-empty--inset' : '') }, h('strong', { text: o.title }), o.line ? h('span', { text: o.line }) : null, o.action || null);
  A.face = (name, you) => h('span', { class: 'ap-face' + (you ? ' ap-face--you' : ''), 'aria-hidden': 'true', text: initials(name) });
  function initials(n) {
    const w = String(n || '?').replace(/[^\p{L}\s]/gu, ' ').trim().split(/\s+/);
    return ((w[0] || '?')[0] + (w.length > 1 ? w[w.length - 1][0] : '')).toUpperCase();
  }

  // The toast: what just happened, with Undo when it can be undone. One at a time.
  let toastEl = null, toastT = 0;
  // Say it after a full page load (an action whose next page is another year's app).
  A.flash = function (msg) { try { sessionStorage.setItem('ogc-app-flash', msg); } catch (e) { /* storage off: the page itself shows the result */ } };
  A.toast = function (msg, o) {
    o = o || {};
    if (toastEl) toastEl.remove();
    clearTimeout(toastT);
    toastEl = h('div', { class: 'ap-toast', role: 'status' }, h('span', { text: msg }),
      o.undo ? h('button', { type: 'button', text: 'Undo', on: { click: () => { const t = toastEl; t.remove(); toastEl = null; o.undo(); } } }) : null);
    (root || document.body).appendChild(toastEl);
    toastT = setTimeout(() => { if (toastEl) { toastEl.remove(); toastEl = null; } }, o.undo ? 7000 : 3500);
  };
  A.fail = function (err) {
    const m = err && err.data && err.data.message ? err.data.message : (err && err.message) || 'Not saved';
    A.toast(/HTTP|fetch|network/i.test(m) ? 'Not saved · Check the connection' : m);
  };

  // A small menu under a button. items: [{ label, current, run }]
  A.menu = function (anchor, items) {
    closeMenu();
    const r = anchor.getBoundingClientRect();
    const m = h('div', { class: 'ap-menu', role: 'menu' }, items.map(it => h('button', {
      type: 'button', role: 'menuitem', 'aria-current': it.current ? 'true' : null,
      on: { click: () => { closeMenu(); it.run(); } }
    }, it.label)));
    m.style.left = Math.max(8, Math.min(r.left, innerWidth - 310)) + 'px';
    m.style.top = (r.bottom + 4) + 'px';
    (root || document.body).appendChild(m);
    const first = m.querySelector('button');
    if (first) first.focus();
    A._menu = m;
    setTimeout(() => document.addEventListener('mousedown', outside), 0);
  };
  function outside(e) { if (A._menu && !A._menu.contains(e.target)) closeMenu(); }
  function closeMenu() { if (A._menu) { A._menu.remove(); A._menu = null; document.removeEventListener('mousedown', outside); } }

  // Saved views: chips over a list. views: [{ id, label, n }]
  A.views = function (views, current, onPick) {
    return h('div', { class: 'ap-chips', role: 'toolbar', 'aria-label': 'Views' }, views.map(v => h('button', {
      type: 'button', class: 'ap-chip', 'aria-pressed': String(v.id === current),
      on: { click: () => onPick(v.id) }
    }, v.label, v.n != null && String(v.n) !== '0' ? h('span', { class: 'ap-chip__n', text: String(v.n) }) : null)));   // never a zero
  };

  /*
   * A table: o = { cols: [{ label, cls, render(row) → node|text, wide }], rows, key(row), selected,
   * onOpen(row), group(row) → heading, empty: node, label }. Arrow keys move, Enter opens; the mouse is
   * always enough. Returns the element.
   */
  A.table = function (o) {
    if (!o.rows.length) return o.empty || A.empty({ title: 'Nothing here', inset: true });
    const tb = h('tbody');
    let last = null;
    o.rows.forEach(row => {
      const g = o.group ? o.group(row) : null;
      if (g != null && g !== last) { tb.appendChild(h('tr', { class: 'ap-tr--group' }, h('td', { colspan: String(o.cols.length), text: g }))); last = g; }
      const k = String(o.key(row));
      const tr = h('tr', { 'data-key': k, 'aria-selected': String(String(o.selected) === k), tabindex: '-1' }, o.cols.map(c => {
        const v = c.render(row);
        return h('td', { class: (c.cls || '') + (c.wide ? ' ap-td--wide' : '') + (typeof c.rowCls === 'function' ? ' ' + c.rowCls(row) : '') }, v);
      }));
      tr.addEventListener('click', e => { if (e.target.closest('button, a, input, label')) return; o.onOpen && o.onOpen(row); });
      tb.appendChild(tr);
    });
    const t = h('table', { class: 'ap-table', 'aria-label': o.label || null },
      h('thead', null, h('tr', null, o.cols.map(c => h('th', { scope: 'col', class: (c.cls || '').replace(/ap-td--done|ap-td--muted/g, '') + (c.wide ? ' ap-td--wide' : '') }, c.label)))), tb);
    const wrap = h('div', { class: 'ap-tablewrap', tabindex: '0', role: 'group', 'aria-label': (o.label || 'List') + ' · Arrow keys move · Enter opens' }, t);
    wrap.addEventListener('keydown', e => {
      const trs = [...tb.querySelectorAll('tr[data-key]')];
      if (!trs.length) return;
      let i = trs.findIndex(r => r.getAttribute('aria-selected') === 'true');
      if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
        e.preventDefault();
        i = e.key === 'ArrowDown' ? Math.min(trs.length - 1, i + 1) : Math.max(0, i < 0 ? 0 : i - 1);
        trs.forEach(r => r.setAttribute('aria-selected', 'false'));
        trs[i].setAttribute('aria-selected', 'true');
        trs[i].scrollIntoView({ block: 'nearest' });
      } else if (e.key === 'Enter' && i >= 0) {
        e.preventDefault();
        const row = o.rows.find(r => String(o.key(r)) === trs[i].dataset.key);
        if (row && o.onOpen) o.onOpen(row);
      }
    });
    return wrap;
  };

  // The split: a list with the record panel beside it (on a phone, the panel takes the screen).
  // const sp = ctx.split(); sp.main.append(...); sp.open({ title, body, foot, onClose }); sp.close();
  function split(body) {
    const main = h('div', { class: 'ap-split__main' });
    const panel = h('aside', { class: 'ap-panel', hidden: true, 'aria-label': 'Details' });
    const el = h('div', { class: 'ap-split' }, main, panel);
    body.classList.add('ap-body--flush');
    body.appendChild(el);
    let onClose = null;
    const api = {
      main, panel, el,
      open(o) {
        clear(panel);
        onClose = o.onClose || null;
        panel.appendChild(h('div', { class: 'ap-panel__head' },
          h('h2', { class: 'ap-panel__title', text: o.title }),
          A.btn('Close', { ghost: true, iconOnly: true, icon: 'x', onClick: () => api.close() })));
        panel.appendChild(h('div', { class: 'ap-panel__body' }, o.body));
        if (o.foot) panel.appendChild(h('div', { class: 'ap-panel__foot' }, o.foot));
        panel.hidden = false;
        el.classList.add('ap-split--open');
        const f = panel.querySelector('[data-autofocus]');
        if (f) f.focus();
      },
      close(silent) {
        if (panel.hidden) return;
        panel.hidden = true;
        el.classList.remove('ap-split--open');
        clear(panel);
        const f = onClose; onClose = null;
        if (f && !silent) f();
      },
      get isOpen() { return !panel.hidden; }
    };
    return api;
  }

  /* ------------------------------------------------------------ words */

  A.fmt = {
    plural: (n, one, many) => n + ' ' + (n === 1 ? one : (many || one + 's')),
    // One short date everywhere: "Jan 15".
    md: d => d ? new Date(String(d).slice(0, 10) + 'T12:00:00Z').toLocaleDateString('en-US', { month: 'short', day: 'numeric', timeZone: 'UTC' }) : '',
    size: b => b < 1024 ? b + ' B' : b < 1048576 ? Math.round(b / 1024) + ' KB' : (b / 1048576).toFixed(1) + ' MB',
    month: d => d ? new Date(d + 'T12:00:00Z').toLocaleDateString('en-US', { month: 'long', year: 'numeric', timeZone: 'UTC' }) : '',
    initials
  };

  /* ------------------------------------------------------------ data and addresses */

  const params = () => {
    const q = new URLSearchParams(location.search);
    return { year: +(q.get('year') || CFG.year), s: q.get('s') || 'home', c: q.get('c') || '', id: q.get('id') || '', as: q.get('as') || '', team: q.get('team') || '', v: q.get('v') || '', past: q.get('past') || '', at: q.get('at') || '' };
  };
  A.params = params;

  A.api = function (method, path, body, o) {
    const p = params();
    const year = (o && o.year) || p.year;
    let url = /^\//.test(path) ? path.slice(1) : 'app/' + year + '/' + path;
    if (p.as) url += (url.includes('?') ? '&' : '?') + 'as=' + encodeURIComponent(p.as);
    // A previewed date (?as-of=2027-02-14) reads the year as it would be then; nothing is saved.
    const asOf = (new URLSearchParams(location.search).get('as-of') || '').slice(0, 10);
    // The shared prototype (each visitor's own copy) saves under its tour's dates too.
    if ((method === 'GET' || (window.OGC_WP && OGC_WP.prototype)) && /^\d{4}-\d\d-\d\d$/.test(asOf) && !/[?&]as_of=/.test(url)) url += (url.includes('?') ? '&' : '?') + 'as_of=' + asOf;
    return W.api(method, url, body).catch(err => {
      // A session older than 30 days: the page itself asks to confirm (members' pages, module-auth).
      if (err.status === 401 || (err.data && err.data.code === 'ogc_reauth')) location.reload();
      throw err;
    });
  };

  // The address of a screen. Keeps year, as and team unless they're given.
  A.href = function (to) {
    const p = params();
    const q = new URLSearchParams();
    const n = Object.assign({ year: p.year, as: p.as, team: p.team }, to);
    ['year', 's', 'c', 'id', 'v', 'past', 'at', 'as', 'team'].forEach(k => { if (n[k] != null && n[k] !== '' && !(k === 's' && n[k] === 'home')) q.set(k, n[k]); });
    const asOf = new URLSearchParams(location.search).get('as-of');
    if (asOf && n['as-of'] !== '') q.set('as-of', asOf);
    return location.pathname + '?' + q.toString();
  };
  // Change the address without drawing again (a record opened beside the list).
  // Everything else in the address stays (the screen, its committee and view), so Reload, Back and a
  // copied link land on the same screen and record; '' clears a key.
  A.setParams = function (to) { history.replaceState(null, '', A.href(Object.assign({}, params(), to))); };
  A.go = function (to, o) {
    const url = A.href(to);
    if (o && o.replace) history.replaceState(null, '', url); else history.pushState(null, '', url);
    route();
  };
  // Draw the screen the address is on again (after a change), on the same screen, committee, view and
  // record. A.go({}) is Home: it keeps only year, as and team.
  A.reload = function () { A.go(params(), { replace: true }); };
  // A link that moves inside the app without a reload (a real link: open in a new tab works).
  A.link = function (to, kids, cls) {
    const a = h('a', { href: A.href(to), class: cls || null }, kids);
    a.addEventListener('click', e => {
      if (e.metaKey || e.ctrlKey || e.shiftKey || e.button !== 0) return;
      e.preventDefault();
      A.go(to);
    });
    return a;
  };

  /* ------------------------------------------------------------ the registry */

  A.screen = function (def) { SCREENS[def.id] = def; };
  A.action = function (def) { ACTIONS.push(def); };
  A.screens = () => SCREENS;
  A.allowed = id => !!(boot && boot.screens.some(s => s.id === id));
  A.committee = key => boot && boot.committees.find(c => c.key === key);
  A.boot = () => boot;
  // The committee the viewer works as in the sidebar (two committees: the switcher picks).
  A.team = function () {
    const mine = boot.viewer.committees;
    if (!mine.length) return '';
    const t = params().team;
    if (t && mine.some(c => c.key === t)) return t;
    try { const s = localStorage.getItem('ogc-app-team'); if (s && mine.some(c => c.key === s)) return s; } catch (e) { /* storage off */ }
    return mine[0].key;
  };

  /* ------------------------------------------------------------ the shell */

  const root = document.getElementById('ogc-app');
  const side = root.querySelector('.ap-side');
  const card = root.querySelector('.ap-card');

  function sectionName() {
    const v = boot.viewer;
    if (v.as) return v.as_name;
    if (v.coa) return 'COA';
    const t = A.team();
    if (t) return (A.committee(t) || {}).name || '';
    return v.webmaster ? 'Webmasters' : '';
  }

  // The screens in the "who you are" section: the COA's own (minus any handed away), a committee's
  // (theirs, handed to them, Overview first), a webmaster's.
  function ownScreens() {
    const v = boot.viewer;
    const team = A.team();
    return boot.screens.filter(s => {
      // Import is an act on Households ("Import from the Form"), not a place of its own.
      if (s.section !== 'own' || !SCREENS[s.id] || s.id === 'lod-import') return false;
      if (v.coa) return s.who.includes('coa') && !s.handed;
      if (team) return s.who.includes('committee') || s.who.includes(team) || s.handed === team;
      return v.webmaster && s.who.includes('webmaster');
    });
  }

  function titleOf(id) {
    // A committee's own page is named for the committee ("Lodging"), the same page as Committees › Lodging.
    if (id === 'overview' && A.team()) return (A.committee(A.team()) || {}).name || 'Overview';
    const d = SCREENS[id];
    const s = boot.screens.find(x => x.id === id);
    return d && typeof d.title === 'function' ? d.title(boot) : (d && d.title) || (s && s.title) || id;
  }

  function drawSide() {
    clear(side);
    const v = boot.viewer, p = params();
    // The year at the head: a menu only for someone in more than one year.
    const many = boot.years.length > 1 && !v.as;
    // One year: the year said plainly (a button that does nothing is a dead end).
    const yearBtn = h(many ? 'button' : 'div', { type: many ? 'button' : null, class: 'ap-year' + (many ? '' : ' ap-year--one'), 'aria-haspopup': many ? 'menu' : null, title: boot.conference.dates },
      h('span', { class: 'ap-year__name', text: boot.conference.label }),
      many ? h('span', { class: 'ap-year__chev' }, A.icon('down', 14)) : null);
    if (many) yearBtn.addEventListener('click', () => A.menu(yearBtn, boot.years.map(y => ({ label: y.label, current: y.year === boot.year, run: () => { location.href = A.href({ year: y.year, s: 'home', as: '', team: '' }); } }))));
    side.appendChild(yearBtn);
    // Two committees: the switcher.
    if (v.committees.length > 1 && !v.as) {
      const team = A.team();
      side.appendChild(h('div', { class: 'ap-team', role: 'group', 'aria-label': 'Committee' }, v.committees.map(c => h('button', {
        type: 'button', class: 'ap-chip', 'aria-pressed': String(c.key === team),
        on: { click: () => { try { localStorage.setItem('ogc-app-team', c.key); } catch (e) { /* storage off */ } A.go({ team: c.key, s: p.s === 'overview' ? 'overview' : p.s, c: '' }); } }
      }, c.name))));
    }
    // See as (the COA and webmasters): the app as any committee sees it, read only, one click to switch.
    // The same as Committees › a committee › See as; webmasters (not on the COA) may see as the COA too.
    if (v.can_see_as) {
      const others = boot.committees.filter(c => c.key !== 'coa');
      const opts = (v.real_coa ? [] : [{ key: 'coa', name: 'COA' }]).concat(others);
      const seeBtn = h('button', { type: 'button', class: 'ap-seeas-btn' + (v.as ? ' is-on' : ''), 'aria-haspopup': 'menu', title: 'See the app as a committee sees it · Read only' },
        A.icon('eye', 15), h('span', { text: v.as ? 'Seeing as ' + v.as_name : 'See as' }), A.icon('down', 14));
      seeBtn.addEventListener('click', () => A.menu(seeBtn, [{ label: 'Yourself', current: !v.as, run: () => A.go({ as: '', s: 'home', c: '', id: '', v: '', team: '' }) }]
        .concat(opts.map(c => ({ label: c.name, current: v.as === c.key, run: () => A.go(c.key === 'coa' ? { as: 'coa', s: 'home', c: '', id: '', v: '', team: '' } : { as: c.key, s: 'overview', c: c.key, id: '', v: '', team: '' }) })))));
      side.appendChild(seeBtn);
    }
    side.appendChild(h('button', { type: 'button', class: 'ap-search', on: { click: openPalette } }, A.icon('search', 15), 'Search', h('kbd', { text: /Mac/.test(navigator.platform) ? '⌘K' : 'Ctrl K' })));
    const item = (id, extra, later) => {
      // Under the committee's own section label, its page is "Overview" (not "Lodging" twice).
      const a = A.link(Object.assign({ s: id, c: '', id: '', v: '', past: '', at: '' }, extra || {}), [A.icon(A.iconFor(id)), h('span', { text: id === 'overview' ? 'Overview' : titleOf(id) }),
        later ? h('span', { class: 'ap-nav__when', text: A.fmt.md(later) }) : null]);
      if (later) { a.classList.add('ap-nav__later'); a.title = 'From ' + A.fmt.md(later); }
      return h('li', null, a);
    };
    const main = h('ul', { class: 'ap-nav' }, ['home', 'committees', 'tasks'].filter(A.allowed).map(id => item(id)));
    side.appendChild(main);
    const own = ownScreens();
    if (own.length) {
      // In season first; the rest after, quietly, with the day they open (Check-in · May 28).
      const today = boot.conference.today || '';
      const later = s => s.opens && s.opens > today ? s.opens : '';
      const now = own.filter(s => !later(s)), soon = own.filter(s => later(s)).sort((a, b) => a.opens < b.opens ? -1 : 1);
      side.appendChild(h('div', { class: 'ap-sect', text: sectionName() }));
      side.appendChild(h('ul', { class: 'ap-nav' }, now.map(s => item(s.id, s.id === 'overview' ? { c: A.team() } : null))));
      if (soon.length) side.appendChild(h('ul', { class: 'ap-nav ap-nav--later', 'aria-label': 'Later in the year' }, soon.map(s => item(s.id, null, s.opens))));
    }
    // The webmasters' Mail log (its own page).
    if (v.webmaster && !v.coa && !v.as && CFG.mail) {
      side.appendChild(h('ul', { class: 'ap-nav' }, h('li', null, h('a', { href: CFG.mail, 'data-page': 'mail', title: 'The Mail log · Every email the site sent' }, A.icon('mail'), h('span', { text: 'Mail' })))));
    }
    // The current screen in the sidebar; a committee's screen the COA opened (Lodging's Households)
    // is under Committees.
    const cur = foreignOf(p.s) ? 'committees' : p.s;
    side.querySelectorAll('.ap-nav a:not([data-page])').forEach(a => {
      const q = new URLSearchParams(a.search);
      const s = q.get('s') || 'home';
      if (s === cur) a.setAttribute('aria-current', 'page');
    });
    const foot = h('div', { class: 'ap-foot' },
      h('div', { class: 'ap-me', title: v.email }, A.face(v.short || v.name, true), h('span', { class: 'ap-me__name', text: v.short || v.name })),
      h('ul', { class: 'ap-nav' }, h('li', null, h('a', { href: boot.logout }, A.icon('out'), h('span', { text: 'Sign out' })))));
    side.appendChild(foot);
  }

  // A screen that isn't in the viewer's sidebar but belongs to a committee (the COA on Lodging's
  // Households): that committee's key, so the title row says "Lodging / Households".
  function foreignOf(id) {
    if (!boot || !id || ['home', 'committees', 'tasks'].includes(id)) return '';
    if (ownScreens().some(s => s.id === id)) return '';
    const s = boot.screens.find(x => x.id === id);
    if (!s) return '';
    if (s.handed) return s.handed;
    // A screen several committees share (Helpers): the one it's showing (?c=), else the first.
    const ks = (s.who || []).filter(w => !['all', 'coa', 'committee', 'webmaster'].includes(w) && A.committee(w));
    const c = params().c;
    return c && ks.includes(c) ? c : ks[0] || '';
  }
  A.foreignOf = foreignOf;

  // The card's title row: ctx.head(title, fact, actions[], { crumb: { label, to } })
  function head(title, fact, actions, o) {
    const old = card.querySelector('.ap-head');
    const row = h('header', { class: 'ap-head' },
      A.btn('Menu', { ghost: true, iconOnly: true, icon: 'menu', onClick: () => root.classList.add('ap--drawer') }),
      h('h1', { class: 'ap-head__title' },
        o && o.crumb ? [A.link(o.crumb.to, o.crumb.label, 'ap-head__crumb'), h('span', { class: 'ap-head__crumb', 'aria-hidden': 'true', text: '  /  ' })] : null,
        title),
      fact ? h('span', { class: 'ap-head__fact', text: fact }) : null,
      h('div', { class: 'ap-head__acts' }, actions || []));
    row.querySelector('.ap-btn--icon').classList.add('ap-head__menu');
    if (old) old.replaceWith(row); else card.prepend(row);
    document.title = (typeof title === 'string' ? title : 'Conference') + ' · ' + boot.year + ' Conference';
  }

  function route() {
    const p = params();
    closeMenu();
    root.classList.remove('ap--drawer');
    if (cleanup) { try { cleanup(); } catch (e) { /* screen gone */ } cleanup = null; }
    if (!boot || p.year !== boot.year || p.as !== (boot.viewer.as || '')) return start();
    let id = p.s;
    if (!A.allowed(id) || !SCREENS[id]) id = 'home';
    drawSide();
    clear(card);
    if (boot.viewer.as) {
      card.appendChild(h('div', { class: 'ap-seeas', role: 'note' }, A.icon('eye'), h('span', { text: 'Seeing as ' + boot.viewer.as_name }),
        A.link({ as: '', s: 'committees', c: boot.viewer.as === 'coa' ? '' : boot.viewer.as, team: '' }, 'Back')));
    }
    const body = h('div', { class: 'ap-body', id: 'ap-body' });
    card.appendChild(body);
    const fk = foreignOf(id);
    const crumb = fk ? { label: (A.committee(fk) || {}).name || fk, to: { s: 'committees', c: fk, id: '', v: '' } } : null;
    head(titleOf(id), '', [], crumb ? { crumb } : null);
    const ctx = {
      body, boot, params: p, api: A.api, go: A.go, readonly: A.readonly, foreign: fk,
      // The crumb as the screen now stands (Helpers names the committee it switched to).
      head: (t, f, a, o) => {
        const k = foreignOf(id), cr = k ? { label: (A.committee(k) || {}).name || k, to: { s: 'committees', c: k, id: '', v: '' } } : null;
        head(t, f, a, o && o.crumb ? o : Object.assign({}, o || {}, cr ? { crumb: cr } : {}));
      },
      split: () => split(body)
    };
    try {
      const r = SCREENS[id].render(ctx);
      if (typeof r === 'function') cleanup = r;
    } catch (e) {
      console.error(e);
      clear(body).appendChild(A.empty({ title: 'Not shown', line: 'Reload the page' }));
    }
  }

  function start() {
    const p = params();
    clear(card).appendChild(h('div', { class: 'ap-loading', role: 'status', text: 'Loading' }));
    A.api('GET', 'boot').then(b => {
      boot = b;
      A.readonly = !!b.viewer.as;
      tasksCache = null;
      root.dataset.state = 'ready';
      // The local site's floating Pages button sits over the card's last row: room for it.
      if (W.dev) root.classList.add('ap--dev');
      if (p.year !== b.year) history.replaceState(null, '', A.href({ year: b.year }));
      route();
      // What an action that moved to another page did (Start 2028, Remove): said once it has loaded.
      let said = '';
      try { said = sessionStorage.getItem('ogc-app-flash') || ''; sessionStorage.removeItem('ogc-app-flash'); } catch (e) { /* storage off */ }
      if (said) A.toast(said);
    }).catch(err => {
      clear(card).appendChild(A.empty({ title: err.status === 403 || err.status === 401 ? 'No access' : 'Not loaded', line: err.status === 403 ? 'Not on the ' + p.year + ' members list' : 'Reload the page', inset: true }));
    });
  }

  window.addEventListener('popstate', route);
  root.addEventListener('click', e => { if (e.target === root && root.classList.contains('ap--drawer')) root.classList.remove('ap--drawer'); });
  document.addEventListener('click', e => {
    if (root.classList.contains('ap--drawer') && !side.contains(e.target) && !e.target.closest('.ap-head__menu')) root.classList.remove('ap--drawer');
  });

  /* ------------------------------------------------------------ ⌘K */

  let tasksCache = null;
  A.forgetTasks = () => { tasksCache = null; };
  function openPalette() {
    if (!boot || document.querySelector('.ap-palette')) return;
    root.classList.remove('ap--drawer');
    const back = document.activeElement;
    const input = h('input', { class: 'ap-palette__input', type: 'search', placeholder: 'Search people, committees, screens, tasks', 'aria-label': 'Search', role: 'combobox', 'aria-expanded': 'true', 'aria-controls': 'ap-pal-list', autocomplete: 'off' });
    const list = h('ul', { class: 'ap-palette__list', id: 'ap-pal-list', role: 'listbox' });
    const scrim = h('div', { class: 'ap-scrim' });
    const xBtn = A.btn('Close', { ghost: true, iconOnly: true, icon: 'x' });
    xBtn.classList.add('ap-palette__x');
    const box = h('div', { class: 'ap-palette', role: 'dialog', 'aria-modal': 'true', 'aria-label': 'Search' }, input, xBtn, list);
    xBtn.addEventListener('click', () => close());
    const close = () => { scrim.remove(); box.remove(); document.removeEventListener('keydown', key, true); if (back && back.focus) back.focus(); };
    scrim.addEventListener('click', close);
    root.append(scrim, box);
    let sel = 0, opts = [];
    const items = () => {
      const out = [];
      // Screens in the sidebar's order (Home, Committees, Tasks, then yours); a committee's screen names it.
      const mine = ownScreens().map(s => s.id), rank = id => ['home', 'committees', 'tasks'].indexOf(id) > -1 ? ['home', 'committees', 'tasks'].indexOf(id) : mine.indexOf(id) > -1 ? 10 + mine.indexOf(id) : 100;
      boot.screens.filter(s => SCREENS[s.id]).slice().sort((a, b) => rank(a.id) - rank(b.id)).forEach(s => {
        const own = (s.who || []).find(w => w !== 'all' && w !== 'coa' && w !== 'committee' && w !== 'webmaster');
        const hint = own && !mine.includes(s.id) ? ((A.committee(own) || {}).name || '') : '';
        out.push({ group: 'Screens', label: titleOf(s.id), hint, run: () => A.go({ s: s.id, c: s.id === 'overview' ? A.team() : '', id: '', v: '', past: '' }) });
      });
      ACTIONS.filter(a => (!a.screen || A.allowed(a.screen)) && (!a.when || a.when(boot))).forEach(a => out.push({ group: 'Actions', label: a.title, run: a.run }));
      boot.committees.forEach(c => out.push({ group: 'Committees', label: c.name, run: () => A.go({ s: 'committees', c: c.key, id: '', v: '', past: '' }) }));
      boot.people.forEach(pp => {
        const c = pp.committees[0];
        const cn = c === 'coa' ? 'COA' : ((A.committee(c) || {}).name || '');
        out.push({ group: 'People', label: pp.name, hint: cn + (pp.head ? ' · Head' : ''), run: () => A.go(boot.viewer.coa && A.allowed('members') ? { s: 'members', id: pp.id, c: '' } : { s: 'committees', c, id: '' }) });
      });
      (tasksCache || []).forEach(t => out.push({ group: 'Tasks', label: t.title, hint: ((A.committee(t.committee) || {}).name || '') + (t.due_words ? ' · ' + t.due_words : ''), run: () => A.go({ s: 'tasks', id: t.id, c: '', v: 'all' }) }));
      return out;
    };
    const draw = () => {
      const qv = input.value.trim().toLowerCase();
      const words = qv.split(/\s+/).filter(Boolean);
      opts = items().filter(o => words.every(w => (o.label + ' ' + (o.hint || '')).toLowerCase().includes(w)));
      if (!qv) opts = opts.filter(o => o.group === 'Screens' || o.group === 'Actions' || o.group === 'Committees');
      opts = opts.slice(0, 40);
      sel = Math.min(sel, Math.max(0, opts.length - 1));
      clear(list);
      if (!opts.length) { list.appendChild(h('li', { class: 'ap-palette__none', text: 'No results' })); return; }
      let g = '';
      opts.forEach((o, i) => {
        if (o.group !== g) { g = o.group; list.appendChild(h('li', { class: 'ap-palette__group', role: 'presentation', text: g })); }
        const li = h('li', { class: 'ap-palette__opt', role: 'option', id: 'ap-opt-' + i, 'aria-selected': String(i === sel) }, h('span', { text: o.label }), o.hint ? h('small', { text: o.hint }) : null);
        li.addEventListener('mousemove', () => { if (sel !== i) { sel = i; mark(); } });
        li.addEventListener('click', () => { close(); o.run(); });
        list.appendChild(li);
      });
      input.setAttribute('aria-activedescendant', 'ap-opt-' + sel);
    };
    const mark = () => {
      list.querySelectorAll('.ap-palette__opt').forEach((li, i) => li.setAttribute('aria-selected', String(i === sel)));
      const cur = list.querySelector('#ap-opt-' + sel);
      if (cur) cur.scrollIntoView({ block: 'nearest' });
      input.setAttribute('aria-activedescendant', 'ap-opt-' + sel);
    };
    const key = e => {
      if (e.key === 'Escape') { e.preventDefault(); close(); }
      else if (e.key === 'ArrowDown') { e.preventDefault(); sel = Math.min(opts.length - 1, sel + 1); mark(); }
      else if (e.key === 'ArrowUp') { e.preventDefault(); sel = Math.max(0, sel - 1); mark(); }
      else if (e.key === 'Enter' && opts[sel]) { e.preventDefault(); const o = opts[sel]; close(); o.run(); }
    };
    document.addEventListener('keydown', key, true);
    input.addEventListener('input', () => { sel = 0; draw(); });
    draw();
    input.focus();
    if (!tasksCache && A.allowed('tasks')) A.api('GET', 'tasks?view=all').then(r => { tasksCache = r.tasks; if (document.body.contains(box)) draw(); }).catch(() => { tasksCache = []; });
  }
  A.openSearch = openPalette;
  document.addEventListener('keydown', e => {
    if ((e.metaKey || e.ctrlKey) && (e.key === 'k' || e.key === 'K')) { e.preventDefault(); openPalette(); }
    if (e.key === 'Escape') closeMenu();
  });

  // Screens register after this file loads; start once the page is parsed.
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start); else setTimeout(start, 0);
})();
