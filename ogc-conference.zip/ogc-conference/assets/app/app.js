/*
 * OGC_APP: the committees' app (docs/23). The kit, the shell and the screen registry.
 *
 *   OGC_APP.screen({ id, title, icon, section, who, render(ctx), title?(boot) })
 *       A screen. Who may see it is the server's rule (ogc_app_screens in module-app.php, the same id):
 *       the shell draws only the screens /boot lists. render(ctx) draws into ctx.body; ctx has
 *       head(title, fact, actions), params, boot, api, go, readonly, split().
 *   OGC_APP.action({ id, title, screen?, run(), when?(boot) })   a ⌘K action (Add task, Add people…)
 *   OGC_APP.api(method, path, body)   /wp-json/ogc/v1/app/<year>/<path>, with ?as= when seeing as
 *   OGC_APP.go(params, { replace })    to another screen: ?year=&s=&c=&id=&as=&team=&v=
 *   OGC_APP.h(tag, attrs, ...kids)     DOM without innerHTML: text is always text
 *   OGC_APP.btn, tag, empty, toast, menu, table, panel, icon, fmt (DEV.md › App › The kit)
 *
 * Nothing a person typed ever goes into innerHTML: every node is built with h() and textContent.
 */
(function () {
  'use strict';
  const W = window.OGC_WP || {};
  const CFG = W.app || {};
  const A = window.OGC_APP = {};
  const SCREENS = {};
  const ACTIONS = [];
  let boot = null;
  let cleanup = null;

  /* ------------------------------------------------------------ DOM */

  // h('a', { class: 'x', href, on: { click }, text: 'Hi' }, child, [children], null)
  const h = A.h = function (tag, attrs, ...kids) {
    const el = document.createElement(tag);
    const a = attrs || {};
    for (const k in a) {
      const v = a[k];
      if (v == null || v === false) continue;
      if (k === 'class') el.className = v;
      else if (k === 'text') el.textContent = v;
      else if (k === 'on') { for (const ev in v) el.addEventListener(ev, v[ev]); }
      else if (k === 'style' && typeof v === 'object') Object.assign(el.style, v);
      else if (k === 'value') el.value = v;
      else if (k === 'checked' || k === 'disabled' || k === 'hidden' || k === 'selected') el[k] = !!v;
      else if (k === 'href') el.setAttribute('href', safeHref(v));
      else el.setAttribute(k, v === true ? '' : String(v));
    }
    add(el, kids);
    return el;
  };
  function add(el, kids) {
    for (const k of kids) {
      if (k == null || k === false) continue;
      if (Array.isArray(k)) add(el, k);
      else el.appendChild(k instanceof Node ? k : document.createTextNode(String(k)));
    }
  }
  // Only our own addresses (a path, or this site's own origin) and https: links (a committee's
  // folder) are written into an href.
  function safeHref(v) {
    const s = String(v);
    return /^(\/(?!\/)|\?|#|https:\/\/)/i.test(s) || s.indexOf(location.origin + '/') === 0 ? s : '#';
  }
  const clear = el => { while (el.firstChild) el.removeChild(el.firstChild); return el; };
  A.clear = clear;

  /* ------------------------------------------------------------ icons (16 px, strokes) */

  const PATHS = {
    home: 'M3 7.5 8 3l5 4.5V13H9.5V9.5h-3V13H3z',
    committees: 'M5.5 7a2 2 0 1 0 0-4 2 2 0 0 0 0 4Zm5 0a2 2 0 1 0 0-4 2 2 0 0 0 0 4ZM2 13c0-2 1.6-3.5 3.5-3.5S9 11 9 13m-.5-2.6c.6-.6 1.3-.9 2-.9 1.9 0 3.5 1.5 3.5 3.5',
    tasks: 'M3 4.5 4.5 6 7 3.5M3 10.5 4.5 12 7 9.5M9 5h4.5M9 11h4.5',
    members: 'M8 7.5a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5ZM3 13.5c.4-2.3 2.5-4 5-4s4.6 1.7 5 4M12.5 2v3M11 3.5h3',
    overview: 'M2.5 3.5h11v9h-11zM2.5 6.5h11M6 6.5v6',
    years: 'M3 3.5h10v10H3zM3 6.5h10M6 2v3M10 2v3',
    search: 'M7 12A5 5 0 1 0 7 2a5 5 0 0 0 0 10Zm3.5-1.5L14 14',
    plus: 'M8 3v10M3 8h10',
    x: 'M4 4l8 8M12 4l-8 8',
    chev: 'M6 4l4 4-4 4',
    down: 'M4 6l4 4 4-4',
    up: 'M8 13V3M4 7l4-4 4 4',
    dn: 'M8 3v10M4 9l4 4 4-4',
    menu: 'M2.5 4.5h11M2.5 8h11M2.5 11.5h11',
    mail: 'M2.5 4h11v8h-11zM2.5 4.5 8 8.5l5.5-4',
    eye: 'M1.5 8S4 3.5 8 3.5 14.5 8 14.5 8 12 12.5 8 12.5 1.5 8 1.5 8Zm6.5 2a2 2 0 1 0 0-4 2 2 0 0 0 0 4Z',
    file: 'M4 2h5l3 3v9H4zM9 2v3h3',
    out: 'M6 3H3v10h3M10 5l3 3-3 3M13 8H6',
    back: 'M10 4 6 8l4 4',
    note: 'M3 2.5h10v8l-3 3H3zM10 13.5v-3h3',
    report: 'M4 2h8v12H4zM6 5h4M6 8h4M6 11h2',
    link: 'M7 9a3 3 0 0 0 4.2 0l2-2a3 3 0 0 0-4.2-4.2l-.6.6M9 7a3 3 0 0 0-4.2 0l-2 2A3 3 0 0 0 7 13.2l.6-.6',
    upload: 'M8 11V3M5 6l3-3 3 3M3 11v2.5h10V11',
    // Each committee screen its own plain mark, so the sidebar can be read by its icons.
    bed: 'M2 12.5V4M2 9.5h12v3M14 9.5V8a2 2 0 0 0-2-2H7.5v3.5M4.5 8a1 1 0 1 0 0-.01',
    key: 'M9.5 6.5a3 3 0 1 1-.9-2.1M8.6 4.4 13.5 9.3l-1.2 1.2-1-1-1 1-1-1',
    caravan: 'M1.5 11.5h11v-6a1.5 1.5 0 0 0-1.5-1.5H3a1.5 1.5 0 0 0-1.5 1.5zM12.5 9.5h2M4 6.5h3v2.5H4zM5.5 13a1.2 1.2 0 1 0 0-.01',
    house: 'M2.5 7 8 2.5 13.5 7M4 6v7.5h8V6M6.5 13.5V10h3v3.5',
    // Young Folks' halls: a bunk bed (never the two heads of Committees).
    bunk: 'M3 2.5v11M13 2.5v11M3 7h10M3 12h10M5 5.2h3M5 10.2h3',
    pair: 'M5 7a2 2 0 1 0 0-4 2 2 0 0 0 0 4Zm6 0a2 2 0 1 0 0-4 2 2 0 0 0 0 4ZM1.5 13.5c.3-2 1.7-3.5 3.5-3.5s3.2 1.5 3.5 3.5M7.5 13.5c.3-2 1.7-3.5 3.5-3.5s3.2 1.5 3.5 3.5',
    plate: 'M8 13a5 5 0 1 0 0-10 5 5 0 0 0 0 10Zm0-2.5a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5ZM1 3v4M15 3v10',
    hand: 'M5 8V3.5a1 1 0 0 1 2 0V7m0-3.5a1 1 0 0 1 2 0V7m0-2.5a1 1 0 0 1 2 0V9a4.5 4.5 0 0 1-8.3 2.4L2.3 9.2a1 1 0 0 1 1.6-1.2L5 9.3',
    child: 'M8 6a2 2 0 1 0 0-4 2 2 0 0 0 0 4ZM5 14l1-5h4l1 5M4.5 8.5 8 7.5l3.5 1',
    cup: 'M4 2.5h8l-1 6a3 3 0 0 1-6 0zM8 11.5V14M5.5 14h5',
    flag: 'M3.5 14V2.5M3.5 3h8l-1.5 2.5 1.5 2.5h-8',
    pin: 'M8 14s4.5-4.2 4.5-7.5a4.5 4.5 0 0 0-9 0C3.5 9.8 8 14 8 14Zm0-6a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3Z'
  };
  // The sidebar's mark for each screen, by id (a screen's own icon otherwise).
  const ICON_FOR = { 'lod-households': 'house', 'lod-rooms': 'bed', 'lod-checkin': 'key', 'lod-yf': 'bunk', 'lod-campers': 'caravan', 'lod-import': 'upload', 'food-meals': 'plate', 'food-menus': 'note', helpers: 'hand', 'preteens-list': 'child', 'communion-list': 'cup', 'yf-teams': 'flag', overview: 'overview' };
  A.iconFor = id => ICON_FOR[id] || (SCREENS[id] && SCREENS[id].icon) || id;
  // A screen file may add its own 16 px strokes (the COA's screens: clock, pin, book…).
  A.addIcons = o => { Object.keys(o || {}).forEach(k => { if (!PATHS[k]) PATHS[k] = o[k]; }); };
  A.icon = function (name, size) {
    const s = size || 16;
    const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    svg.setAttribute('width', s); svg.setAttribute('height', s); svg.setAttribute('viewBox', '0 0 16 16');
    svg.setAttribute('fill', 'none'); svg.setAttribute('stroke', 'currentColor'); svg.setAttribute('stroke-width', '1.4');
    svg.setAttribute('stroke-linecap', 'round'); svg.setAttribute('stroke-linejoin', 'round'); svg.setAttribute('aria-hidden', 'true');
    const p = document.createElementNS('http://www.w3.org/2000/svg', 'path');
    p.setAttribute('d', PATHS[name] || PATHS.overview);
    svg.appendChild(p);
    return svg;
  };

  /* ------------------------------------------------------------ the kit */

  // A button. o: { primary, ghost, danger, big, icon, title, disabled, onClick, href, write }
  // A write button is disabled while seeing as (read only), with the reason in its tooltip.
  A.btn = function (label, o) {
    o = o || {};
    const ro = o.write && A.readonly;
    const cls = 'ap-btn' + (o.primary ? ' ap-btn--primary' : '') + (o.ghost ? ' ap-btn--ghost' : '') + (o.danger ? ' ap-btn--danger' : '') + (o.big ? ' ap-btn--big' : '') + (o.iconOnly ? ' ap-btn--icon' : '');
    const kids = [o.icon ? A.icon(o.icon) : null, o.iconOnly ? h('span', { class: 'ap-sr', text: label }) : label];
    if (o.href && !ro) return h('a', { class: cls, href: o.href, title: o.title, download: o.download }, kids);
    return h('button', {
      type: 'button', class: cls, title: ro ? 'Read only while seeing as ' + boot.viewer.as_name : o.title,
      disabled: o.disabled || ro, 'aria-label': o.iconOnly ? label : null,
      on: { click: e => { if (o.onClick) o.onClick(e); } }
    }, kids);
  };
  A.tag = (text, tone) => h('span', { class: 'ap-tag' + (tone ? ' ap-tag--' + tone : '') }, text);
  // An empty state: one dashed card, never a bare line. o: { title, line, action: node }
  A.empty = o => h('div', { class: 'ap-empty' + (o.inset ? ' ap-empty--inset' : '') }, h('strong', { text: o.title }), o.line ? h('span', { text: o.line }) : null, o.action || null);
  A.face = (name, you) => h('span', { class: 'ap-face' + (you ? ' ap-face--you' : ''), 'aria-hidden': 'true', text: initials(name) });
  function initials(n) {
    const w = String(n || '?').replace(/[^\p{L}\s]/gu, ' ').trim().split(/\s+/);
    return ((w[0] || '?')[0] + (w.length > 1 ? w[w.length - 1][0] : '')).toUpperCase();
  }

  // The toast: what just happened, with Undo when it can be undone. One at a time.
  let toastEl = null, toastT = 0;
  // Say it after a full page load (an action whose next page is another year's app).
  A.flash = function (msg) { try { sessionStorage.setItem('ogc-app-flash', msg); } catch (e) { /* storage off: the page itself shows the result */ } };
  A.toast = function (msg, o) {
    o = o || {};
    if (toastEl) toastEl.remove();
    clearTimeout(toastT);
    toastEl = h('div', { class: 'ap-toast', role: 'status' }, h('span', { text: msg }),
      o.undo ? h('button', { type: 'button', text: 'Undo', on: { click: () => { const t = toastEl; t.remove(); toastEl = null; o.undo(); } } }) : null);
    (root || document.body).appendChild(toastEl);
    toastT = setTimeout(() => { if (toastEl) { toastEl.remove(); toastEl = null; } }, o.undo ? 7000 : 3500);
  };
  A.fail = function (err) {
    const m = err && err.data && err.data.message ? err.data.message : (err && err.message) || 'Not saved';
    A.toast(/HTTP|fetch|network/i.test(m) ? 'Not saved · Check the connection' : m);
  };

  // A small menu under a button. items: [{ label, current, run }]
  // An item that can't be chosen says why in words under its label (hint), never only in a tooltip.
  A.menu = function (anchor, items) {
    closeMenu();
    const r = anchor.getBoundingClientRect();
    const m = h('div', { class: 'ap-menu', role: 'menu' }, items.map(it => h('button', {
      type: 'button', role: 'menuitem', 'aria-current': it.current ? 'true' : null, disabled: !!it.disabled, title: it.title || null,
      on: { click: () => { closeMenu(); it.run(); } }
    }, it.hint ? h('span', { class: 'ap-menu__two' }, h('span', { text: it.label }), h('small', { text: it.hint })) : it.label)));
    m.style.left = Math.max(8, Math.min(r.left, innerWidth - 310)) + 'px';
    m.style.top = (r.bottom + 4) + 'px';
    (root || document.body).appendChild(m);
    const first = m.querySelector('button');
    if (first) first.focus();
    A._menu = m;
    setTimeout(() => document.addEventListener('mousedown', outside), 0);
  };
  function outside(e) { if (A._menu && !A._menu.contains(e.target)) closeMenu(); }
  function closeMenu() { if (A._menu) { A._menu.remove(); A._menu = null; document.removeEventListener('mousedown', outside); } }

  // Saved views: chips over a list. views: [{ id, label, n }]
  A.views = function (views, current, onPick) {
    return h('div', { class: 'ap-chips', role: 'toolbar', 'aria-label': 'Views' }, views.map(v => h('button', {
      type: 'button', class: 'ap-chip', 'aria-pressed': String(v.id === current),
      on: { click: () => onPick(v.id) }
    }, v.label, v.n != null && String(v.n) !== '0' ? h('span', { class: 'ap-chip__n', text: String(v.n) }) : null)));   // never a zero
  };

  /*
   * A table: o = { cols: [{ label, cls, render(row) → node|text, wide }], rows, key(row), selected,
   * onOpen(row), group(row) → heading, empty: node, label }. Arrow keys move, Enter opens; the mouse is
   * always enough. Returns the element.
   */
  A.table = function (o) {
    if (!o.rows.length) return o.empty || A.empty({ title: 'Nothing here', inset: true });
    const tb = h('tbody');
    let last = null;
    o.rows.forEach(row => {
      const g = o.group ? o.group(row) : null;
      if (g != null && g !== last) { tb.appendChild(h('tr', { class: 'ap-tr--group' }, h('td', { colspan: String(o.cols.length), text: g }))); last = g; }
      const k = String(o.key(row));
      const tr = h('tr', { 'data-key': k, 'aria-selected': String(String(o.selected) === k), tabindex: '-1' }, o.cols.map(c => {
        const v = c.render(row);
        return h('td', { class: (c.cls || '') + (c.wide ? ' ap-td--wide' : '') + (typeof c.rowCls === 'function' ? ' ' + c.rowCls(row) : '') }, v);
      }));
      tr.addEventListener('click', e => { if (e.target.closest('button, a, input, label')) return; o.onOpen && o.onOpen(row); });
      tb.appendChild(tr);
    });
    const t = h('table', { class: 'ap-table', 'aria-label': o.label || null },
      h('thead', null, h('tr', null, o.cols.map(c => h('th', { scope: 'col', class: (c.cls || '').replace(/ap-td--done|ap-td--muted/g, '') + (c.wide ? ' ap-td--wide' : '') }, c.label)))), tb);
    const wrap = h('div', { class: 'ap-tablewrap', tabindex: '0', role: 'group', 'aria-label': (o.label || 'List') + ' · Arrow keys move · Enter opens' }, t);
    wrap.addEventListener('keydown', e => {
      const trs = [...tb.querySelectorAll('tr[data-key]')];
      if (!trs.length) return;
      let i = trs.findIndex(r => r.getAttribute('aria-selected') === 'true');
      if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
        e.preventDefault();
        i = e.key === 'ArrowDown' ? Math.min(trs.length - 1, i + 1) : Math.max(0, i < 0 ? 0 : i - 1);
        trs.forEach(r => r.setAttribute('aria-selected', 'false'));
        trs[i].setAttribute('aria-selected', 'true');
        trs[i].scrollIntoView({ block: 'nearest' });
      } else if (e.key === 'Enter' && i >= 0) {
        e.preventDefault();
        const row = o.rows.find(r => String(o.key(r)) === trs[i].dataset.key);
        if (row && o.onOpen) o.onOpen(row);
      }
    });
    return wrap;
  };

  // The split: a list with the record panel beside it (on a phone, the panel takes the screen).
  // const sp = ctx.split(); sp.main.append(...); sp.open({ title, body, foot, onClose }); sp.close();
  function split(body) {
    const main = h('div', { class: 'ap-split__main' });
    const panel = h('aside', { class: 'ap-panel', hidden: true, 'aria-label': 'Details' });
    const el = h('div', { class: 'ap-split' }, main, panel);
    body.classList.add('ap-body--flush');
    body.appendChild(el);
    let onClose = null, lastTitle = '', backY = null;
    // On a phone the panel takes the screen in the list's place, while the page stays scrolled where the
    // list was: a record opened from far down began above the screen, its title and Close under the
    // sticky header (after the fourth critic, Oct 15: Helpers' shift panel). Its top is brought just
    // under the header, measured (the header wraps to two or three lines on a phone), and Close goes back
    // to where the list was.
    const stacked = () => getComputedStyle(main).display === 'none';
    const headBottom = () => { const hd = document.querySelector('.ap-head'); return hd ? Math.max(0, hd.getBoundingClientRect().bottom) : 0; };
    let nav = null;
    // ↑ ↓ move through the list while the cursor is in the panel but not in a field (area-shell 10.2).
    panel.addEventListener('keydown', e => {
      if (!nav || e.metaKey || e.ctrlKey || e.altKey || (e.key !== 'ArrowUp' && e.key !== 'ArrowDown')) return;
      if (e.target.closest && e.target.closest('input, textarea, select, [contenteditable]')) return;
      const f = e.key === 'ArrowUp' ? nav.prev : nav.next;
      if (!f) return;
      e.preventDefault();
      f();
    });
    const api = {
      main, panel, el,
      /*
       * The record panel kit (README 2.7; area-shell 10): o = { title, body, foot, onClose, focus,
       *   line (under the title: "R-2027-2049 · 6 people"), tags (the status, money word, flags),
       *   nav: { prev, next } (Previous · Next through the list as drawn; a missing one is greyed) }.
       * The return chip ("← Hoovers") is drawn on its own when the record was reached by a Linked line
       * (from= in the address). On a phone the panel takes the screen, and Close reads ‹ Back.
       * o.focus 'head': a record opened to read (a task) puts focus on its heading, never in a field.
       */
      open(o) {
        const fresh = panel.hidden || o.title !== lastTitle;
        if (panel.hidden) backY = window.scrollY;
        clear(panel);
        onClose = o.onClose || null;
        lastTitle = o.title;
        nav = o.nav || null;
        const title = h('h2', { class: 'ap-panel__title', tabindex: '-1', text: o.title });
        const close = A.btn('Close', { ghost: true, iconOnly: true, icon: 'x', onClick: () => api.close() });
        close.classList.add('ap-panel__close');
        close.appendChild(h('span', { class: 'ap-panel__back', 'aria-hidden': 'true' }, A.icon('back', 14), 'Back'));
        const step = (lab, icon, f) => { const b = A.btn(lab, { ghost: true, iconOnly: true, icon, disabled: !f, title: lab + ' · ' + (icon === 'up' ? '↑' : '↓'), onClick: () => f && f() }); b.classList.add('ap-panel__step'); return b; };
        const chip = A.returnChip();
        if (chip) panel.appendChild(h('div', { class: 'ap-panel__chip' }, chip));
        panel.appendChild(h('div', { class: 'ap-panel__head' }, h('div', { class: 'ap-panel__titles' }, title,
          o.line ? h('p', { class: 'ap-panel__line', text: o.line }) : null),
          nav ? h('div', { class: 'ap-panel__nav' }, step('Previous', 'up', nav.prev), step('Next', 'dn', nav.next)) : null, close));
        if (o.tags && [].concat(o.tags).filter(Boolean).length) panel.appendChild(h('div', { class: 'ap-panel__tags' }, o.tags));
        panel.appendChild(h('div', { class: 'ap-panel__body' }, o.body));
        if (o.foot) panel.appendChild(h('div', { class: 'ap-panel__foot' }, o.foot));
        panel.hidden = false;
        el.classList.add('ap-split--open');
        if (fresh && stacked()) {
          const d = panel.getBoundingClientRect().top - headBottom();
          if (Math.abs(d) > 1) window.scrollTo(0, Math.max(0, window.scrollY + d));
        }
        const f = o.focus === 'head' ? title : panel.querySelector('[data-autofocus]');
        if (f) f.focus({ preventScroll: o.focus === 'head' || stacked() });
      },
      close(silent) {
        if (panel.hidden) return;
        const wasStacked = stacked(), y = backY;
        panel.hidden = true;
        el.classList.remove('ap-split--open');
        clear(panel);
        lastTitle = ''; backY = null;
        const f = onClose; onClose = null;
        if (f && !silent) f();
        if (wasStacked && y != null) window.scrollTo(0, y);
      },
      get isOpen() { return !panel.hidden; }
    };
    return api;
  }

  /* ------------------------------------------------------------ words */

  A.fmt = {
    plural: (n, one, many) => n + ' ' + (n === 1 ? one : (many || one + 's')),
    // One short date everywhere: "Jan 15".
    md: d => d ? new Date(String(d).slice(0, 10) + 'T12:00:00Z').toLocaleDateString('en-US', { month: 'short', day: 'numeric', timeZone: 'UTC' }) : '',
    size: b => b < 1024 ? b + ' B' : b < 1048576 ? Math.round(b / 1024) + ' KB' : (b / 1048576).toFixed(1) + ' MB',
    month: d => d ? new Date(d + 'T12:00:00Z').toLocaleDateString('en-US', { month: 'long', year: 'numeric', timeZone: 'UTC' }) : '',
    initials
  };

  /* ------------------------------------------------------------ data and addresses */

  /*
   * The address (docs/27-back-end-map/area-shell.md section 1). Every state is in it, so Back, Reload
   * and a copied link land where they were:
   *   ?year=&s=&c=&past=&v=&f=&o=&at=&id=&from=&as=&as-role=&team=&as-of=
   * The address's own keys rank coarsest first: s (the screen) › c (a committee) › past › v (a view) ›
   * f, o (filters, sort) › at (a part of the screen, or an act opened once) › id (the record beside the
   * list). from lives with an id (the return chip). year, as, as-role, team and as-of always stay.
   */
  const RANK = { s: 1, c: 2, past: 3, v: 4, f: 5, o: 5, at: 6, id: 7 };
  const KEEP = ['year', 'as', 'as-role', 'team', 'as-of'];
  const ORDER = ['year', 's', 'c', 'past', 'v', 'f', 'o', 'at', 'id', 'from', 'as', 'as-role', 'team', 'as-of'];
  // A screen's parts: the at words it keeps in the address (a page's Report, the schedule's Day view).
  // Any other at word is an act (Assign, Head): the screen opens it once, then the router takes it out
  // of the address, so Reload and Back never open it again (area-shell 1.2, D22, 1.9). A screen may
  // also say its own: OGC_APP.screen({ parts: [...] }).
  const PAGE_PARTS = ['people', 'contacts', 'report', 'last', 'notes', 'how', 'files', 'folder', 'who'];
  const PARTS = { committees: PAGE_PARTS, overview: PAGE_PARTS, schedule: ['grid'], requests: ['requests', 'shifts', 'packet', 'contact'], registration: ['prices'], campus: ['doors', 'halls', 'rooms'], callin: ['testimony'], 'food-meals': ['sent', 'report', 'last'], 'lod-counts': ['sent'] };
  const isPart = (s, at) => { const d = SCREENS[s || 'home']; return ((d && d.parts) || PARTS[s] || []).includes(at); };
  // The address as it stands, every key a string ('' when not there).
  function raw() {
    const q = new URLSearchParams(location.search);
    const o = {};
    ORDER.forEach(k => { o[k] = q.get(k) || ''; });
    if (!o.year) o.year = String(CFG.year || '');
    return o;
  }
  const params = () => {
    const r = raw();
    return { year: +(r.year || CFG.year), s: r.s || 'home', c: r.c, past: r.past, v: r.v, f: r.f, o: r.o, at: r.at, id: r.id, from: r.from, as: r.as, asRole: r['as-role'], team: r.team };
  };
  A.params = params;
  A.isPart = isPart;

  A.api = function (method, path, body, o) {
    const p = params();
    const year = (o && o.year) || p.year;
    let url = /^\//.test(path) ? path.slice(1) : 'app/' + year + '/' + path;
    if (p.as) url += (url.includes('?') ? '&' : '?') + 'as=' + encodeURIComponent(p.as);
    // A previewed date (?as-of=2027-02-14) reads the year as it would be then; nothing is saved.
    const asOf = (new URLSearchParams(location.search).get('as-of') || '').slice(0, 10);
    // The shared prototype (each visitor's own copy) saves under its tour's dates too.
    if ((method === 'GET' || (window.OGC_WP && OGC_WP.prototype)) && /^\d{4}-\d\d-\d\d$/.test(asOf) && !/[?&]as_of=/.test(url)) url += (url.includes('?') ? '&' : '?') + 'as_of=' + asOf;
    return W.api(method, url, body).catch(err => {
      // A session older than 30 days: the page itself asks to confirm (members' pages, module-auth).
      if (err.status === 401 || (err.data && err.data.code === 'ogc_reauth')) location.reload();
      throw err;
    });
  };

  /*
   * The rule (area-shell 1.2): a click changes the level it names. Find the coarsest key `to` names;
   * keep every coarser key and the others of that rank; clear every finer key it doesn't name; set what
   * it names. So { c: 'lodging' } on the board opens Lodging's page, { v: 'all' } on Tasks is Tasks'
   * All view, { id: 74 } opens a record beside the list, and {} is this screen again. Only a click that
   * says { s: 'home' } (or names nothing, on Home) goes Home. An act in `at` is never carried forward;
   * `from` lives only while a record stays open on the same screen; year, as, as-role, team and as-of
   * stay unless named; and `team` follows `c` into the viewer's own section (D18).
   * Returns every key, as strings.
   */
  A.ladder = function (to) {
    to = to || {};
    const cur = raw();
    const val = k => to[k] == null ? '' : String(to[k]);
    const named = Object.keys(to).filter(k => RANK[k]);
    const top = named.length ? Math.min(...named.map(k => RANK[k])) : 99;
    const n = {};
    Object.keys(RANK).forEach(k => { n[k] = k in to ? val(k) : RANK[k] <= top ? cur[k] : ''; });
    if (n.s === 'home') n.s = '';
    // One address for your own committee's page (Round 1, after the critic): s=overview is the old name
    // of s=committees&c=<yours>, so the sidebar, a crumb and a task's Committee link all write the same.
    if (n.s === 'overview') { n.s = 'committees'; if (!n.c) n.c = ownTeam(); }
    if (!('at' in to) && n.at && !isPart(n.s || 'home', n.at)) n.at = '';
    n.from = 'from' in to ? val('from') : (n.id && n.s === cur.s && n.id !== '' ? cur.from : '');
    if (!n.id) n.from = '';
    KEEP.forEach(k => { n[k] = k in to ? val(k) : cur[k]; });
    if (!('team' in to) && !n.as && n.c && n.c !== cur.c && inOwnSection(n.s || 'home', n.c)) n.team = n.c;
    return n;
  };
  // The viewer's own committee (the switcher's, for someone on two); '' for the COA and webmasters.
  const ownTeam = () => boot && boot.viewer.committees.length ? A.team() : '';
  // Is this committee's page the viewer's own (they're on it; the COA's own page is Round 2's)?
  A.ownPage = c => !!(boot && c && A.allowed('overview') && boot.viewer.committees.some(x => x.key === c));
  // A committee's own screen (its page, its Requests, a screen written or handed for it), for someone on
  // two committees: the sidebar then shows that committee's section.
  function inOwnSection(s, c) {
    if (!boot || (boot.viewer.committees || []).length < 2 || !boot.viewer.committees.some(x => x.key === c)) return false;
    if (s === 'committees' || s === 'overview') return true;
    const sc = boot.screens.find(x => x.id === s);
    return !!(sc && ((sc.who || []).includes(c) || (sc.who || []).includes('committee') || sc.handed === c));
  }
  function build(n) {
    const q = new URLSearchParams();
    ORDER.forEach(k => { if (n[k] != null && n[k] !== '' && !(k === 's' && n[k] === 'home')) q.set(k, n[k]); });
    return location.pathname + '?' + q.toString();
  }
  // The address of a screen, by the rule above.
  A.href = function (to) { return build(A.ladder(to)); };
  // Change the address without drawing again, after the screen has drawn what the keys mean (a record
  // opened beside its list, a view chip on a screen that draws itself). A merge: exactly the keys named
  // change ('' clears one), so Reload, Back and a copied link land on the same screen and record.
  // Closing a record (id '') also drops its return chip (from); an act is never written into at.
  A.setParams = function (to) {
    to = to || {};
    const n = Object.assign(raw(), {});
    Object.keys(to).forEach(k => { const key = k === 'asRole' ? 'as-role' : k; if (ORDER.includes(key)) n[key] = to[k] == null ? '' : String(to[k]); });
    if (n.s === 'home') n.s = '';
    if ('id' in to && !n.id) n.from = '';
    if ('at' in to && n.at && !isPart(n.s || 'home', n.at)) n.at = raw().at;
    history.replaceState(null, '', build(n));
  };
  // To another place in the app (pushed, so Back returns). The same address again only draws again.
  // Another screen, committee or year opens at its top, never where the last page was scrolled to.
  A.go = function (to, o) {
    const url = A.href(to);
    const was = raw();
    if ((o && o.replace) || url === location.pathname + location.search) history.replaceState(null, '', url); else history.pushState(null, '', url);
    route();
    const now = raw();
    if (['year', 's', 'c', 'past'].some(k => was[k] !== now[k])) window.scrollTo(0, 0);
  };
  // A record opened beside its list (a task on Tasks): a new history entry the first time, so the
  // browser's Back closes the panel first; another record in its place replaces that entry.
  // closeRecord: Close or Esc goes back to the list's own entry when it was opened that way (without
  // drawing the list again); else the address just drops the record.
  let quietPop = '';
  A.openRecord = function (to) {
    const r = raw();
    const n = Object.assign({}, r);
    Object.keys(to || {}).forEach(k => { if (ORDER.includes(k)) n[k] = to[k] == null ? '' : String(to[k]); });
    if (r.id && history.state && history.state.ogcRecord) history.replaceState({ ogcRecord: true }, '', build(n));
    else history.pushState({ ogcRecord: true }, '', build(n));
  };
  A.closeRecord = function () {
    const url = build(Object.assign(raw(), { id: '', from: '' }));
    if (history.state && history.state.ogcRecord) { quietPop = url; history.back(); } else history.replaceState(null, '', url);
  };
  // Draw the screen the address is on again (after a change): the same screen, committee, view and
  // record. A.go({}) does the same; Home is A.go({ s: 'home' }).
  A.reload = function () { A.go({}, { replace: true }); };
  // A link that moves inside the app without a reload (a real link: open in a new tab works).
  A.link = function (to, kids, cls) {
    const a = h('a', { href: A.href(to), class: cls || null }, kids);
    a.addEventListener('click', e => {
      if (e.metaKey || e.ctrlKey || e.shiftKey || e.button !== 0) return;
      e.preventDefault();
      A.go(to);
    });
    return a;
  };

  /* ------------------------------------------------------------ records that lead to each other (Round 3) */

  /*
   * Going sideways (README 2.3; area-shell 10.3): a record's Linked line opens another list with that
   * record open, and the address carries from=<screen>:<record>. The tab's session storage keeps the
   * origin's whole address and its name, so the return chip ("← Hoovers") goes back exactly there. A
   * copied link or a new tab has no stored entry: the chip names the screen ("← Households") and opens
   * s=<screen>&id=<record>. The chip lives while a record stays open on this screen (Previous · Next,
   * another row); Close, a view, a filter or another screen clears it (A.ladder, A.setParams).
   */
  const FROM_KEY = k => 'ogc-app-from:' + k;
  A.follow = function (go, fromKey, name) {
    try { sessionStorage.setItem(FROM_KEY(fromKey), JSON.stringify({ href: location.pathname + location.search, name: name || '' })); } catch (e) { /* storage off: the chip names the screen */ }
    A.go(Object.assign({}, go, { from: fromKey }));
  };
  A.returnChip = function () {
    const r = raw();
    if (!r.from || !r.id) return null;
    const i = r.from.indexOf(':'), scr = i < 0 ? r.from : r.from.slice(0, i), rec = i < 0 ? '' : r.from.slice(i + 1);
    let e = null;
    try { e = JSON.parse(sessionStorage.getItem(FROM_KEY(r.from)) || 'null'); } catch (x) { e = null; }
    const href = e && e.href && /^\/[^/]/.test(e.href) ? e.href : '';
    const to = { s: scr, id: rec, from: '' };
    const name = (e && e.name) || titleOf(scr) || 'Back';
    const a = h('a', { class: 'ap-retchip', href: href || A.href(to), title: 'Back to ' + name }, A.icon('back', 14), name);
    a.addEventListener('click', ev => {
      if (ev.metaKey || ev.ctrlKey || ev.shiftKey || ev.button !== 0) return;
      ev.preventDefault();
      if (href) { history.pushState(null, '', href); route(); window.scrollTo(0, 0); } else A.go(to);
    });
    return a;
  };
  // The words of each Linked kind (one fixed list; the server sends the kind and its count).
  const LINKED = { rooms: 'Rooms', payments: 'Payments', refunds: 'Refunds', shifts: 'Shifts', household: 'Household', checkin: 'Check-in', children: 'Children', deposit: 'Deposit', same: 'Same check', committee: 'Committee', place: 'Place' };
  /*
   * The Linked part: one line per related kind, "Rooms · 2", each a real link to that list filtered,
   * its first row open. lines: [{ kind, n, go, label? }]; o: { from: 'households:R-…', name: 'Hoovers' }.
   * A line with nothing isn't drawn; with no lines the part isn't either.
   */
  A.linked = function (lines, o) {
    const ls = (lines || []).filter(l => l && l.go && (l.n == null || +l.n > 0));
    if (!ls.length) return null;
    return h('section', { class: 'ap-linked', 'aria-label': 'Linked' }, h('h3', { class: 'ap-rec__h', text: 'Linked' }),
      h('ul', null, ls.map(l => {
        const go = Object.assign({}, l.go, { from: o.from });
        const a = h('a', { class: 'ap-linked__a', href: A.href(go), 'data-kind': l.kind, 'data-n': l.n == null ? '' : String(l.n) },
          h('span', { text: (l.label || LINKED[l.kind] || l.kind) + (l.n != null ? ' · ' + l.n : '') }), A.icon('chev', 14));
        a.addEventListener('click', e => { if (e.metaKey || e.ctrlKey || e.shiftKey || e.button !== 0) return; e.preventDefault(); A.follow(l.go, o.from, o.name); });
        return h('li', null, a);
      })));
  };
  /*
   * History: who changed what, when and how, newest first (area-shell 10.7). lines: [{ at, what, by,
   * how, note }]; six show, then "Show all · 24". o.add: the Add note box (the record kind's own), first.
   */
  A.history = function (lines, o) {
    o = o || {};
    const ls = lines || [];
    if (!ls.length && !o.add) return null;
    const li = e => h('li', { class: e.note ? 'is-note' : '' }, h('span', { class: 'ap-hist__d', text: A.fmt.md(e.at) }),
      h('span', { class: 'ap-hist__w' }, h('span', { text: e.what }), [e.by, e.how].filter(Boolean).length ? h('small', { text: [e.by, e.how].filter(Boolean).join(' · ') }) : null));
    const list = h('ul', { class: 'ap-hist' }, ls.slice(0, 6).map(li));
    const more = ls.length > 6 ? h('button', { type: 'button', class: 'ap-link ap-hist__all', text: 'Show all · ' + ls.length, on: { click: () => { A.clear(list); ls.forEach(e => list.appendChild(li(e))); more.remove(); } } }) : null;
    return h('section', { class: 'ap-rec__hist', 'aria-label': 'History' }, h('h3', { class: 'ap-rec__h', text: 'History' }), o.add || null, ls.length ? list : null, more);
  };

  /*
   * Filters in the address (area-shell 1.4): f=field:value,value;field:value. A.fParse reads it into
   * { field: [values] }, A.fString writes it back. A.pills draws what the server accepted ([{ field,
   * label, values: [{ v, words }] }]) as pills, "Household · Hoovers ×"; × clears that field, Clear all
   * of them (two or more). The server applies them inside the viewer's own scope; the browser only says.
   */
  A.fParse = function (f) {
    const o = {};
    String(f || '').split(';').forEach(part => {
      const i = part.indexOf(':');
      if (i < 1) return;
      const vals = part.slice(i + 1).split(',').map(v => v.trim()).filter(Boolean);
      if (vals.length) o[part.slice(0, i)] = vals;
    });
    return o;
  };
  A.fString = function (o) {
    return Object.keys(o || {}).filter(k => o[k] && o[k].length).map(k => k + ':' + o[k].join(',')).join(';');
  };
  A.pills = function (filters, o) {
    o = o || {};
    const fs = (filters || []).filter(x => x && x.values && x.values.length);
    if (!fs.length) return null;
    const cur = A.fParse(raw().f);
    const clear = field => { const n = Object.assign({}, cur); delete n[field]; A.go({ f: A.fString(n) }); };
    return h('div', { class: 'ap-fpills', role: 'group', 'aria-label': 'Filters' },
      fs.map(x => h('span', { class: 'ap-fpill', 'data-field': x.field }, h('span', { text: x.label + ' · ' + (x.values.length > 2 ? x.values.length : x.values.map(v => v.words).join(', ')) }),
        h('button', { type: 'button', class: 'ap-fpill__x', title: 'Clear ' + x.label, 'aria-label': 'Clear ' + x.label, on: { click: () => (o.onClear ? o.onClear(x.field) : clear(x.field)) } }, A.icon('x', 12)))),
      fs.length > 1 ? h('button', { type: 'button', class: 'rx-clear', text: 'Clear', on: { click: () => (o.onClearAll ? o.onClearAll() : A.go({ f: '' })) } }) : null);
  };
  /*
   * A record that isn't in the view (area-shell 1.3): the view that holds it. o: { views: [ids, left to
   * right], current, id, has(viewId, id) }. The current one if it holds the record; else the first that
   * does; else 'all' (or the first view).
   */
  A.pickView = function (o) {
    if (!o.id || o.has(o.current, o.id)) return o.current;
    const hit = o.views.find(v => o.has(v, o.id));
    return hit != null ? hit : (o.views.includes('all') ? 'all' : o.views[0]);
  };

  /* ------------------------------------------------------------ the registry */

  A.screen = function (def) { SCREENS[def.id] = def; };
  A.action = function (def) { ACTIONS.push(def); };
  A.screens = () => SCREENS;
  A.allowed = id => !!(boot && boot.screens.some(s => s.id === id));
  A.committee = key => boot && boot.committees.find(c => c.key === key);
  A.boot = () => boot;
  // The committee the viewer works as in the sidebar (two committees: the switcher picks).
  A.team = function () {
    const mine = boot.viewer.committees;
    if (!mine.length) return '';
    const t = params().team;
    if (t && mine.some(c => c.key === t)) return t;
    try { const s = localStorage.getItem('ogc-app-team'); if (s && mine.some(c => c.key === s)) return s; } catch (e) { /* storage off */ }
    return mine[0].key;
  };

  /* ------------------------------------------------------------ the shell */

  const root = document.getElementById('ogc-app');
  const side = root.querySelector('.ap-side');
  const card = root.querySelector('.ap-card');

  function sectionName() {
    const v = boot.viewer;
    if (v.as) return v.as_name;
    if (v.coa) return 'COA';
    const t = A.team();
    if (t) return (A.committee(t) || {}).name || '';
    return v.webmaster ? 'Webmasters' : '';
  }

  // The screens in the "who you are" section: the COA's own (minus any handed away), a committee's
  // (theirs, handed to them, Overview first), a webmaster's.
  function ownScreens() {
    const v = boot.viewer;
    const team = A.team();
    return boot.screens.filter(s => {
      // Import is an act on Households ("Import from the Form"), not a place of its own.
      if (s.section !== 'own' || !SCREENS[s.id] || s.id === 'lod-import') return false;
      // A handed screen stays in the COA's section, marked with its holder (README rule 8).
      if (v.coa) return s.who.includes('coa');
      if (team) return s.who.includes('committee') || s.who.includes(team) || s.handed === team;
      return v.webmaster && s.who.includes('webmaster');
    });
  }

  function titleOf(id) {
    // A committee's own page is named for the committee ("Lodging"), the same page as Committees › Lodging.
    if (id === 'overview' && A.team()) return (A.committee(A.team()) || {}).name || 'Overview';
    const d = SCREENS[id];
    const s = boot.screens.find(x => x.id === id);
    return d && typeof d.title === 'function' ? d.title(boot) : (d && d.title) || (s && s.title) || id;
  }

  // The year at the head of the sidebar: plain text, or a menu for someone in more than one year. A year
  // not started yet (a member's 2028) is listed greyed, with why in words: opening it would only say so.
  function yearHead(label, dates, years, cur) {
    const many = years.length > 1;
    // One year: the year said plainly (a button that does nothing is a dead end).
    const yearBtn = h(many ? 'button' : 'div', { type: many ? 'button' : null, class: 'ap-year' + (many ? '' : ' ap-year--one'), 'aria-haspopup': many ? 'menu' : null, title: dates || null },
      h('span', { class: 'ap-year__name', text: label }),
      many ? h('span', { class: 'ap-year__chev' }, A.icon('down', 14)) : null);
    if (many) yearBtn.addEventListener('click', () => A.menu(yearBtn, years.map(y => ({
      label: y.started === false ? y.label.replace(/ · Not started$/, '') : y.label, current: y.year === cur, disabled: y.started === false,
      hint: y.started === false ? 'Not started · Webmasters start each year' : '',
      run: () => { location.href = A.href({ year: y.year, s: 'home', as: '', team: '' }); }
    }))));
    return yearBtn;
  }
  // The person at the foot, and the way out: always there, whatever the card says.
  function footOf(name, email, logout) {
    return h('div', { class: 'ap-foot' },
      h('div', { class: 'ap-me', title: email || null }, A.face(name, true), h('span', { class: 'ap-me__name', text: name })),
      logout ? h('ul', { class: 'ap-nav' }, h('li', null, h('a', { href: logout }, A.icon('out'), h('span', { text: 'Sign out' })))) : null);
  }

  // The one sidebar item that's current (area-shell 2.7): the item whose screen the address shows (your
  // own committee's page by its c); else, for another committee's page or screen, Committees; else none
  // (No access, Not found).
  function currentItem(p, missing) {
    if (missing) return '';
    const s = p.s || 'home', c = p.c || '';
    const own = ownScreens().map(x => x.id);
    if (s === 'committees' && c === 'coa' && boot.viewer.coa) return 'coa-page';
    if (s === 'committees') return c && A.ownPage(c) && own.includes('overview') ? 'overview' : 'committees';
    if (s === 'home' || s === 'tasks' || own.includes(s)) return s;
    if (c || foreignOf(s)) return 'committees';
    return '';
  }
  A.unmarkSide = () => side.querySelectorAll('[aria-current=page]').forEach(a => a.removeAttribute('aria-current'));

  function drawSide(missing) {
    clear(side);
    const v = boot.viewer, p = params();
    side.appendChild(yearHead(boot.conference.label, boot.conference.dates, v.as ? [] : boot.years, boot.year));
    // Two committees: the switcher.
    if (v.committees.length > 1 && !v.as) {
      const team = A.team();
      side.appendChild(h('div', { class: 'ap-team', role: 'group', 'aria-label': 'Committee' }, v.committees.map(c => h('button', {
        type: 'button', class: 'ap-chip', 'aria-pressed': String(c.key === team),
        on: { click: () => { try { localStorage.setItem('ogc-app-team', c.key); } catch (e) { /* storage off */ } A.go(p.s === 'committees' && A.ownPage(p.c) ? { team: c.key, s: 'committees', c: c.key } : { team: c.key, s: p.s, c: '' }); } }
      }, c.name))));
    }
    // See as (the COA and webmasters): the app as any committee sees it, read only, one click to switch.
    // The same as Committees › a committee › See as; webmasters (not on the COA) may see as the COA too.
    if (v.can_see_as) {
      const others = boot.committees.filter(c => c.key !== 'coa');
      const opts = (v.real_coa ? [] : [{ key: 'coa', name: 'COA' }]).concat(others);
      const seeBtn = h('button', { type: 'button', class: 'ap-seeas-btn' + (v.as ? ' is-on' : ''), 'aria-haspopup': 'menu', title: 'See the app as a committee sees it · Read only' },
        A.icon('eye', 15), h('span', { text: v.as ? 'Seeing as ' + v.as_name : 'See as' }), A.icon('down', 14));
      seeBtn.addEventListener('click', () => A.menu(seeBtn, [{ label: 'Yourself', current: !v.as, run: () => A.go({ as: '', s: 'home', c: '', id: '', v: '', team: '' }) }]
        .concat(opts.map(c => ({ label: c.name, current: v.as === c.key, run: () => A.go(c.key === 'coa' ? { as: 'coa', s: 'home', c: '', id: '', v: '', team: '' } : { as: c.key, s: 'overview', c: c.key, id: '', v: '', team: '' }) })))));
      side.appendChild(seeBtn);
    }
    side.appendChild(h('button', { type: 'button', class: 'ap-search', on: { click: openPalette } }, A.icon('search', 15), 'Search', h('kbd', { text: /Mac/.test(navigator.platform) ? '⌘K' : 'Ctrl K' })));
    const item = (id, extra, later, label) => {
      // A committee's own page is named for the committee, never "Overview" (README 2.1, 12). A screen
      // the COA handed on stays in the COA's section with its holder: "Intake · A/V".
      const sc = boot.screens.find(x => x.id === id) || {};
      const holder = v.coa && sc.handed ? (A.committee(sc.handed) || {}).name || '' : '';
      const a = A.link(Object.assign({ s: id, c: '', id: '', v: '', past: '', at: '' }, extra || {}), [A.icon(A.iconFor(id)), h('span', { text: label || titleOf(id) + (holder ? ' · ' + holder : '') }),
        later ? h('span', { class: 'ap-nav__when', text: A.fmt.md(later) }) : null]);
      a.dataset.id = id;
      if (holder) a.title = 'Run by ' + holder;
      if (later) { a.classList.add('ap-nav__later'); a.title = 'From ' + A.fmt.md(later); }
      return h('li', null, a);
    };
    const main = h('ul', { class: 'ap-nav' }, ['home', 'committees', 'tasks'].filter(A.allowed).map(id => item(id)));
    side.appendChild(main);
    const own = ownScreens();
    if (own.length) {
      // In season first; the rest after, quietly, with the day they open (Check-in · May 28).
      const today = boot.conference.today || '';
      const later = s => s.opens && s.opens > today ? s.opens : '';
      const now = own.filter(s => !later(s)), soon = own.filter(s => later(s)).sort((a, b) => a.opens < b.opens ? -1 : 1);
      side.appendChild(h('div', { class: 'ap-sect', text: sectionName() }));
      // The year's order: the committee's page, Requests, Shifts, then its own screens (the COA: its page
      // first, then its screens in the order the year uses them).
      const ORDER = ['overview', 'requests', 'helpers'];
      const rank = s => { const i = ORDER.indexOf(s.id); return i < 0 ? 9 : i; };
      now.sort((a, b) => rank(a) - rank(b));
      const page = v.coa && !v.webmaster ? [h('li', null, (() => { const a = A.link({ s: 'committees', c: 'coa', id: '', v: '', past: '', at: '' }, [A.icon('overview'), h('span', { text: 'COA' })]); a.dataset.id = 'coa-page'; return a; })())] : [];
      side.appendChild(h('ul', { class: 'ap-nav' }, page, now.map(s => item(s.id, s.id === 'overview' ? { c: A.team() } : null))));
      if (soon.length) side.appendChild(h('ul', { class: 'ap-nav ap-nav--later', 'aria-label': 'Later in the year' }, soon.map(s => item(s.id, null, s.opens))));
    }
    // The webmasters' Mail log (its own page).
    if (v.webmaster && !v.coa && !v.as && CFG.mail) {
      side.appendChild(h('ul', { class: 'ap-nav' }, h('li', null, h('a', { href: CFG.mail, 'data-page': 'mail', title: 'The Mail log · Every email the site sent' }, A.icon('mail'), h('span', { text: 'Mail' })))));
    }
    // The current screen in the sidebar, by one rule (currentItem).
    const cur = currentItem(p, missing);
    side.querySelectorAll('.ap-nav a[data-id]').forEach(a => { if (a.dataset.id === cur) a.setAttribute('aria-current', 'page'); });
    side.appendChild(footOf(v.short || v.name, v.email, boot.logout));
  }

  // When boot didn't answer (a year not started, no access): the sidebar still says which year this is
  // and keeps the person and Sign out, never an empty column or the last year's sidebar.
  function drawBare(year, x) {
    x = x || {};
    clear(side);
    const years = (x.years || []).slice();
    side.appendChild(yearHead(year + (x.code === 'ogc_not_started' ? ' · Not started' : ''), '', years.length > 1 || (years.length && years[0].year !== year) ? years : [], year));
    const me = x.viewer || (W.me ? { short: W.me.name || W.me.email, email: W.me.email } : null);
    if (me) side.appendChild(footOf(me.short || me.name || me.email, me.email, x.logout || W.logout || ''));
  }

  // A screen that isn't in the viewer's sidebar but belongs to a committee (the COA on Lodging's
  // Households): that committee's key, so the title row says "Lodging / Households".
  function foreignOf(id) {
    if (!boot || !id || ['home', 'committees', 'tasks'].includes(id)) return '';
    if (ownScreens().some(s => s.id === id)) return '';
    const s = boot.screens.find(x => x.id === id);
    if (!s) return '';
    if (s.handed) return s.handed;
    // A screen several committees share (Helpers): the one it's showing (?c=), else the first.
    const ks = (s.who || []).filter(w => !['all', 'coa', 'committee', 'webmaster'].includes(w) && A.committee(w));
    const c = params().c;
    return c && ks.includes(c) ? c : ks[0] || '';
  }
  A.foreignOf = foreignOf;

  // The card's title row: ctx.head(title, fact, actions[], { crumb: { label, to } })
  function head(title, fact, actions, o) {
    const old = card.querySelector('.ap-head');
    const row = h('header', { class: 'ap-head' },
      A.btn('Menu', { ghost: true, iconOnly: true, icon: 'menu', onClick: () => root.classList.add('ap--drawer') }),
      h('h1', { class: 'ap-head__title' },
        o && o.crumb ? [A.link(o.crumb.to, o.crumb.label, 'ap-head__crumb'), h('span', { class: 'ap-head__crumb', 'aria-hidden': 'true', text: '  /  ' })] : null,
        title),
      fact ? (typeof fact === 'string' ? h('span', { class: 'ap-head__fact', text: fact }) : h('span', { class: 'ap-head__fact' }, fact)) : null,
      h('div', { class: 'ap-head__acts' }, actions || []));
    row.querySelector('.ap-btn--icon').classList.add('ap-head__menu');
    if (old) old.replaceWith(row); else card.prepend(row);
    document.title = (typeof title === 'string' ? title : 'Conference') + ' · ' + boot.year + ' Conference';
  }

  function route() {
    const p = params();
    closeMenu();
    root.classList.remove('ap--drawer');
    if (cleanup) { try { cleanup(); } catch (e) { /* screen gone */ } cleanup = null; }
    if (!boot || p.year !== boot.year || p.as !== (boot.viewer.as || '')) return start();
    // The old address of your own committee's page (s=overview, from an older email or link) becomes its
    // one address, s=committees&c=<yours>, in place.
    if (p.s === 'overview' && boot.viewer.committees.length) {
      const r0 = raw(), k = boot.viewer.committees.some(x => x.key === r0.c) ? r0.c : A.team();
      history.replaceState(history.state, '', build(Object.assign(r0, { s: 'committees', c: k, team: boot.viewer.committees.length > 1 ? k : r0.team })));
      return route();
    }
    let id = p.s;
    // A screen that doesn't exist, or that this viewer can't open, says so where it was asked for: never
    // Home in its place (area-shell 1.6). The address stays, so Reload shows the same card.
    const missing = !SCREENS[id] ? 'notfound' : !A.allowed(id) ? 'noaccess' : '';
    root.dataset.screen = missing || id;
    root.dataset.c = p.c || '';
    drawSide(missing);
    clear(card);
    if (boot.viewer.as) {
      card.appendChild(h('div', { class: 'ap-seeas', role: 'note' }, A.icon('eye'), h('span', { text: 'Seeing as ' + boot.viewer.as_name }),
        A.link({ as: '', s: 'committees', c: boot.viewer.as === 'coa' ? '' : boot.viewer.as, team: '' }, 'Back')));
    }
    const body = h('div', { class: 'ap-body', id: 'ap-body' });
    card.appendChild(body);
    if (missing) {
      const d = SCREENS[id] || {};
      const t = typeof d.title === 'string' ? d.title : '';
      const whose = (d.who || []).map(k => A.committee(k)).filter(Boolean).map(c => c.name)[0] || '';
      head(missing === 'notfound' ? 'Not found' : t || 'No access', '', []);
      body.appendChild(A.empty({ title: missing === 'notfound' ? 'Not found' : 'No access', line: missing === 'notfound' ? '' : [t, whose].filter(Boolean).join(' · '),
        action: A.link({ s: 'home' }, 'Home', 'ap-btn') }));
      return;
    }
    const fk = foreignOf(id);
    const crumb = fk ? { label: (A.committee(fk) || {}).name || fk, to: { s: 'committees', c: fk, id: '', v: '' } } : null;
    head(titleOf(id), '', [], crumb ? { crumb } : null);
    const ctx = {
      body, boot, params: p, api: A.api, go: A.go, readonly: A.readonly, foreign: fk,
      // The crumb as the screen now stands (Helpers names the committee it switched to).
      head: (t, f, a, o) => {
        const k = foreignOf(id), cr = k ? { label: (A.committee(k) || {}).name || k, to: { s: 'committees', c: k, id: '', v: '' } } : null;
        head(t, f, a, o && o.crumb ? o : Object.assign({}, o || {}, cr ? { crumb: cr } : {}));
      },
      split: () => split(body)
    };
    try {
      const r = SCREENS[id].render(ctx);
      if (typeof r === 'function') cleanup = r;
    } catch (e) {
      console.error(e);
      clear(body).appendChild(A.empty({ title: 'Not shown', line: 'Reload the page' }));
    }
    // An act in at (Assign, Head) has been opened by the screen, from ctx.params: it leaves the address,
    // so Reload and Back show the screen and its record without opening it again.
    if (p.at && !isPart(id, p.at) && raw().at === p.at) history.replaceState(null, '', build(Object.assign(raw(), { at: '' })));
  }

  function start() {
    const p = params();
    clear(card).appendChild(h('div', { class: 'ap-loading', role: 'status', text: 'Loading' }));
    A.api('GET', 'boot').then(b => {
      boot = b;
      A.readonly = !!b.viewer.as;
      tasksCache = null;
      root.dataset.state = 'ready';
      // The local site's floating Pages button sits over the card's last row: room for it.
      if (W.dev) root.classList.add('ap--dev');
      if (p.year !== b.year) history.replaceState(null, '', build(Object.assign(raw(), { year: String(b.year) })));
      // See as the server didn't grant (someone not on the COA, a committee that isn't there): the
      // address says what it did grant, once, so the app never asks boot again for the same address.
      if (p.as !== (b.viewer.as || '')) {
        history.replaceState(null, '', build(Object.assign(raw(), { as: b.viewer.as || '', 'as-role': b.viewer.as ? raw()['as-role'] : '' })));
        if (!b.viewer.as) setTimeout(() => A.toast('See as · Not available'), 0);
      }
      route();
      // What an action that moved to another page did (Start 2028, Remove): said once it has loaded.
      let said = '';
      try { said = sessionStorage.getItem('ogc-app-flash') || ''; sessionStorage.removeItem('ogc-app-flash'); } catch (e) { /* storage off */ }
      if (said) A.toast(said);
    }).catch(err => {
      root.dataset.state = 'failed';
      // Nothing of the last year's stays: its sidebar, its title, its boot.
      boot = null;
      const d = (err && err.data) || {};
      // A year the webmasters haven't started: what's true, and the ways on. Opening it writes nothing.
      // The sidebar says the year too, and keeps the person and Sign out (Round 1, after the critic).
      if (d.code === 'ogc_not_started') {
        const x = d.data || {};
        root.dataset.screen = 'notstarted';
        drawBare(p.year, Object.assign({ code: d.code }, x));
        document.title = p.year + ' · Not started · Conference';
        const acts = [];
        if (x.webmaster && x.years_in) acts.push(A.link({ year: x.years_in, s: 'years', id: String(p.year) }, 'Years', 'ap-btn ap-btn--primary'));
        (x.open || []).slice(0, 2).forEach(y => acts.push(A.link({ year: y, s: 'home' }, 'Open ' + y, 'ap-btn')));
        acts.push(h('a', { class: 'ap-btn ap-btn--ghost', href: W.mine || (W.base || '/annual-conference/') + 'register/?view=mine' }, 'Your sign-ups'));
        clear(card).appendChild(A.empty({ title: p.year + ' · Not started', line: 'Webmasters start each year', action: h('div', { class: 'ap-row' }, acts), inset: true }));
        return;
      }
      const no = err.status === 403 || err.status === 401;
      root.dataset.screen = no ? 'noaccess' : 'notloaded';
      drawBare(p.year, d.data || {});
      document.title = (no ? 'No access' : 'Not loaded') + ' · ' + p.year + ' Conference';
      clear(card).appendChild(A.empty({ title: no ? 'No access' : 'Not loaded', line: err.status === 403 ? 'Not on the ' + p.year + ' members list' : 'Reload the page', inset: true }));
    });
  }

  // Back to a list's own entry after Close (A.closeRecord) is already drawn: nothing to draw again.
  window.addEventListener('popstate', () => {
    const q = quietPop;
    quietPop = '';
    if (q && q === location.pathname + location.search) return;
    route();
  });
  // A screen's own No access (a list for another committee the viewer isn't on): what it is and whose,
  // and nothing in the sidebar marked as if it were open.
  A.noAccess = function (ctx, o) {
    root.dataset.screen = 'noaccess';
    A.unmarkSide();
    ctx.head(o.title || 'No access', '', []);
    clear(ctx.body).appendChild(A.empty({ title: 'No access', line: o.line || '', action: o.action || A.link({ s: 'home' }, 'Home', 'ap-btn'), inset: true }));
  };
  root.addEventListener('click', e => { if (e.target === root && root.classList.contains('ap--drawer')) root.classList.remove('ap--drawer'); });
  document.addEventListener('click', e => {
    if (root.classList.contains('ap--drawer') && !side.contains(e.target) && !e.target.closest('.ap-head__menu')) root.classList.remove('ap--drawer');
  });

  /* ------------------------------------------------------------ ⌘K */

  let tasksCache = null;
  A.forgetTasks = () => { tasksCache = null; };
  function openPalette() {
    if (!boot || document.querySelector('.ap-palette')) return;
    root.classList.remove('ap--drawer');
    const back = document.activeElement;
    const input = h('input', { class: 'ap-palette__input', type: 'search', placeholder: 'Search people, committees, screens, tasks', 'aria-label': 'Search', role: 'combobox', 'aria-expanded': 'true', 'aria-controls': 'ap-pal-list', autocomplete: 'off' });
    const list = h('ul', { class: 'ap-palette__list', id: 'ap-pal-list', role: 'listbox' });
    const scrim = h('div', { class: 'ap-scrim' });
    const xBtn = A.btn('Close', { ghost: true, iconOnly: true, icon: 'x' });
    xBtn.classList.add('ap-palette__x');
    const box = h('div', { class: 'ap-palette', role: 'dialog', 'aria-modal': 'true', 'aria-label': 'Search' }, input, xBtn, list);
    xBtn.addEventListener('click', () => close());
    const close = () => { scrim.remove(); box.remove(); document.removeEventListener('keydown', key, true); if (back && back.focus) back.focus(); };
    scrim.addEventListener('click', close);
    root.append(scrim, box);
    let sel = 0, opts = [];
    const items = () => {
      const out = [];
      // Screens in the sidebar's order (Home, Committees, Tasks, then yours); a committee's screen names it.
      const mine = ownScreens().map(s => s.id), rank = id => ['home', 'committees', 'tasks'].indexOf(id) > -1 ? ['home', 'committees', 'tasks'].indexOf(id) : mine.indexOf(id) > -1 ? 10 + mine.indexOf(id) : 100;
      boot.screens.filter(s => SCREENS[s.id]).slice().sort((a, b) => rank(a.id) - rank(b.id)).forEach(s => {
        const own = (s.who || []).find(w => w !== 'all' && w !== 'coa' && w !== 'committee' && w !== 'webmaster');
        const hint = own && !mine.includes(s.id) ? ((A.committee(own) || {}).name || '') : '';
        out.push({ group: 'Screens', label: titleOf(s.id), hint, run: () => A.go({ s: s.id, c: s.id === 'overview' ? A.team() : '', id: '', v: '', past: '' }) });
      });
      ACTIONS.filter(a => (!a.screen || A.allowed(a.screen)) && (!a.when || a.when(boot))).forEach(a => out.push({ group: 'Actions', label: a.title, run: a.run }));
      boot.committees.forEach(c => out.push({ group: 'Committees', label: c.name, run: () => A.go({ s: 'committees', c: c.key, id: '', v: '', past: '' }) }));
      boot.people.forEach(pp => {
        const c = pp.committees[0];
        const cn = c === 'coa' ? 'COA' : ((A.committee(c) || {}).name || '');
        out.push({ group: 'People', label: pp.name, hint: cn + (pp.head ? ' · Head' : ''), run: () => A.go(boot.viewer.coa && A.allowed('members') ? { s: 'members', id: pp.id, c: '' } : { s: 'committees', c, id: '' }) });
      });
      (tasksCache || []).forEach(t => out.push({ group: 'Tasks', label: t.title, hint: ((A.committee(t.committee) || {}).name || '') + (t.due_words ? ' · ' + t.due_words : ''), run: () => A.go({ s: 'tasks', id: t.id, c: '', v: 'all' }) }));
      return out;
    };
    const draw = () => {
      const qv = input.value.trim().toLowerCase();
      const words = qv.split(/\s+/).filter(Boolean);
      opts = items().filter(o => words.every(w => (o.label + ' ' + (o.hint || '')).toLowerCase().includes(w)));
      if (!qv) opts = opts.filter(o => o.group === 'Screens' || o.group === 'Actions' || o.group === 'Committees');
      opts = opts.slice(0, 40);
      sel = Math.min(sel, Math.max(0, opts.length - 1));
      clear(list);
      if (!opts.length) { list.appendChild(h('li', { class: 'ap-palette__none', text: 'No results' })); return; }
      let g = '';
      opts.forEach((o, i) => {
        if (o.group !== g) { g = o.group; list.appendChild(h('li', { class: 'ap-palette__group', role: 'presentation', text: g })); }
        const li = h('li', { class: 'ap-palette__opt', role: 'option', id: 'ap-opt-' + i, 'aria-selected': String(i === sel) }, h('span', { text: o.label }), o.hint ? h('small', { text: o.hint }) : null);
        li.addEventListener('mousemove', () => { if (sel !== i) { sel = i; mark(); } });
        li.addEventListener('click', () => { close(); o.run(); });
        list.appendChild(li);
      });
      input.setAttribute('aria-activedescendant', 'ap-opt-' + sel);
    };
    const mark = () => {
      list.querySelectorAll('.ap-palette__opt').forEach((li, i) => li.setAttribute('aria-selected', String(i === sel)));
      const cur = list.querySelector('#ap-opt-' + sel);
      if (cur) cur.scrollIntoView({ block: 'nearest' });
      input.setAttribute('aria-activedescendant', 'ap-opt-' + sel);
    };
    const key = e => {
      if (e.key === 'Escape') { e.preventDefault(); close(); }
      else if (e.key === 'ArrowDown') { e.preventDefault(); sel = Math.min(opts.length - 1, sel + 1); mark(); }
      else if (e.key === 'ArrowUp') { e.preventDefault(); sel = Math.max(0, sel - 1); mark(); }
      else if (e.key === 'Enter' && opts[sel]) { e.preventDefault(); const o = opts[sel]; close(); o.run(); }
    };
    document.addEventListener('keydown', key, true);
    input.addEventListener('input', () => { sel = 0; draw(); });
    draw();
    input.focus();
    if (!tasksCache && A.allowed('tasks')) A.api('GET', 'tasks?view=all').then(r => { tasksCache = r.tasks; if (document.body.contains(box)) draw(); }).catch(() => { tasksCache = []; });
  }
  A.openSearch = openPalette;
  document.addEventListener('keydown', e => {
    if ((e.metaKey || e.ctrlKey) && (e.key === 'k' || e.key === 'K')) { e.preventDefault(); openPalette(); }
    if (e.key === 'Escape') closeMenu();
  });

  // Screens register after this file loads; start once the page is parsed.
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start); else setTimeout(start, 0);
})();
