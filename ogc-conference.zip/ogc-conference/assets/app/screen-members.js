/*
 * Members: who is on each committee, managed by the COA (docs/23). Adding someone by email puts them on
 * the committee and sends them a sign-in link (the signin area's invite, through its routes: POST
 * /years/{y}/members, PATCH and DELETE /members/{id}); their screens follow from the committee.
 * Webmasters manage the COA itself here (Access). Years: the webmasters' list of Conferences.
 */
(function () {
  'use strict';
  const A = window.OGC_APP, h = A.h;

  A.screen({
    id: 'members', icon: 'members', section: 'own', who: ['coa', 'webmaster'],
    title: b => b.viewer.coa ? 'Members' : 'Access',
    render(ctx) {
      const boot = ctx.boot, v = boot.viewer, p = ctx.params;
      const wm = !v.coa;
      const year = boot.year;
      const sp = ctx.split();
      let data = null;
      let view = p.v || '';
      const cname = k => k === 'coa' ? 'COA' : ((A.committee(k) || {}).name || k);
      // A day said without its year is this calendar year's: in a Conference two years off (2028,
      // seen in 2026) it says the year, so "Feb 11" doesn't read as the future.
      const yr = w => !w || /\d{4}|today|yesterday/.test(w) || year - new Date().getFullYear() < 2 ? w : w + ', ' + new Date().getFullYear();

      // Phones: optional, on the COA's record of each person, seen by the COA only.
      let phones = {};
      const load = () => Promise.all([W().api('GET', 'years/' + year + '/members'), wm ? Promise.resolve({ phones: {} }) : ctx.api('GET', 'phones').catch(() => ({ phones: {} }))]).then(([d, ph]) => { data = d; phones = ph.phones || {}; draw(); })
        .catch(() => { A.clear(sp.main).appendChild(A.empty({ title: 'Not loaded', line: 'Reload the page', inset: true })); });
      const W = () => window.OGC_WP;

      // The rows this screen manages: the COA's committee people; a webmaster's, the COA.
      const mine = () => data.members.filter(m => !m.removed && (wm ? m.role === 'coa' : m.role !== 'coa'));
      const groupOf = m => m.role === 'coa' ? 'COA' : (m.committees.length ? m.committees.map(cname).join(' · ') : 'No committee');

      // keepPanel: redraw the list only, so a panel's unsaved Committee and Head stay as typed.
      let drawnPeople = [];
      function draw(keepPanel) {
        A.clear(sp.main);
        const all = mine();
        const never = all.filter(m => m.state === 'invited');
        const heads = all.filter(m => m.head);
        const views = [{ id: '', label: 'All', n: all.length }];
        if (!wm) views.push({ id: 'heads', label: 'Heads', n: heads.length });
        if (never.length) views.push({ id: 'invited', label: 'Not signed in', n: never.length });
        if (!views.some(x => x.id === view)) view = '';
        let rows = view === 'heads' ? heads : view === 'invited' ? never : all;
        // By committee, in the COA's order: someone on two committees is listed under each. The COA
        // itself first, read only (the webmasters manage it).
        const order = boot.committees.map(c => c.key);
        if (!wm) {
          const out = [];
          rows.forEach(m => (m.committees.length ? m.committees : ['']).forEach(k => out.push(Object.assign({}, m, { _g: k, _k: m.id + '|' + k }))));
          if (!view) data.members.filter(m => !m.removed && m.role === 'coa').forEach(m => out.push(Object.assign({}, m, { _g: 'coa', _k: m.id + '|coa', _ro: true })));
          rows = out.sort((a, b) => (order.indexOf(a._g) - order.indexOf(b._g)) || ((b._g === a._g ? (b.head - a.head) : 0)) || String(a.name || a.email).localeCompare(String(b.name || b.email)));
        }
        // The chips carry the counts; the fact says what isn't on screen (when access ends).
        const until = (data.until || {})[wm ? 'coa' : 'helper'];
        ctx.head(wm ? 'Access' : 'Members', until ? 'Access until ' + until : '',
          [A.btn(wm ? 'Add COA member' : 'Add people', { primary: true, icon: 'plus', write: true, onClick: () => { A.setParams({ id: 'new' }); openAdd(); } })]);
        // One chip is no choice: drawn only when there are two or more.
        if (views.length > 1) sp.main.appendChild(h('div', { class: 'ap-views' }, A.views(views, view, id => { view = id; A.setParams({ v: id }); draw(); })));
        const statusOf = m => m.state === 'invited' ? h('span', { class: 'ap-row', style: { flexWrap: 'nowrap', gap: '10px' } }, h('span', { class: 'ap-quiet', text: m.invite_expired ? 'Link expired · Invited ' + yr(m.invited || '') : 'Invited ' + yr(m.invited || '') }),
              (m.can || {}).resend && !A.readonly && !m._ro ? h('button', { type: 'button', class: 'ap-link', text: 'Resend', on: { click: () => W().api('POST', 'members/' + m.id + '/resend').then(() => A.toast('Sent a new link · ' + (m.name || m.email))).catch(A.fail) } }) : null)
              : m.state === 'expired' ? A.tag('Ended') : h('span', { class: 'ap-quiet', text: m.signed_in ? 'Signed in ' + yr(m.signed_in) : 'Active' });
        // Previous · Next through the people as listed (each person once, in the list's order).
        drawnPeople = rows.filter((m, i) => rows.findIndex(x => x.id === m.id) === i && !(m._ro && !(data.viewer || {}).money));
        sp.main.appendChild(A.table({
          label: wm ? 'COA members' : 'Members', rows, key: m => m._k || m.id, selected: (rows.find(r => String(r.id) === String(p.id)) || {})._k || p.id,
          group: wm ? null : m => m._g === 'coa' ? 'COA · Managed by the webmasters' : m._g ? cname(m._g) : 'No committee',
          // A COA row opens too (Handles money is the COA's to tick); the rest of it is the webmasters'.
          onOpen: m => { if (m._ro && !(data.viewer || {}).money) { A.toast('The COA is managed by the webmasters'); return; } p.id = String(m.id); A.setParams({ id: m.id }); draw(); },
          empty: A.empty({ title: wm ? 'No COA yet' : 'No one yet', line: wm ? 'Add the COA by email' : 'Add people by email · Each gets a sign-in link', inset: true }),
          cols: [
            // Initials from the name, else the address' own first part (silas.grant → SG).
            // On a phone the Status (and its Resend) is a line under the name: never off to the right.
            { label: 'Name', render: m => h('span', null, h('span', { class: 'ap-row', style: { flexWrap: 'nowrap' } }, A.face(m.name || String(m.email || '').split('@')[0], m.you), h('span', { class: 'ap-cell-title', text: m.name || m.email })), h('span', { class: 'ap-only-narrow ap-cell-sub' }, statusOf(m))) },
            { label: 'Email', cls: 'ap-td--muted', wide: true, render: m => m.name ? m.email : '' },
            // A column whose value is the same on every row (Access: all COA) isn't drawn.
            wm ? null : { label: 'Role', cls: 'ap-td--nowrap', wide: true, render: m => h('span', { class: 'ap-row', style: { flexWrap: 'nowrap', gap: '6px' } }, m.role === 'coa' ? 'COA' : (m.head && (m._g === (m.committees[0] || '') || m.committees.length === 1) ? A.tag('Head', 'tan') : 'Helper'), m.money ? A.tag('Handles money') : null, m.webmaster ? A.tag('Webmaster') : null) },
            !wm && Object.keys(phones).length ? { label: 'Phone', cls: 'ap-td--nowrap ap-td--muted', wide: true, render: m => phones[m.id] || '' } : null,
            { label: 'Status', cls: 'ap-td--nowrap', wide: true, render: statusOf }
          ].filter(Boolean)
        }));
        if (keepPanel) return;
        const cur = p.id && p.id !== 'new' ? data.members.find(m => String(m.id) === String(p.id)) : null;
        if (cur) openRow(cur);
        else if (p.id === 'new') openAdd();
        else sp.close(true);
      }

      function committeePills(sel, max) {
        const box = h('div', { class: 'ap-pills', role: 'group', 'aria-label': 'Committees' });
        const drawP = () => {
          A.clear(box);
          boot.committees.filter(c => c.key !== 'coa').forEach(c => box.appendChild(h('button', {
            type: 'button', class: 'ap-pill', 'aria-pressed': String(sel.includes(c.key)),
            on: { click: () => { const i = sel.indexOf(c.key); if (i >= 0) sel.splice(i, 1); else if (sel.length < (max || 4)) sel.push(c.key); drawP(); } }
          }, c.name)));
        };
        drawP();
        return box;
      }

      // Each person a row: Name and Email (the name is how the app says them: "Ruth K."). A pasted list
      // (a spreadsheet's two columns, "Ruth Kinsey <ruth@example.com>", one a line) becomes rows to see first.
      function openAdd() {
        const rowsBox = h('div', { class: 'ap-people-rows' });
        const rows = [];
        const addRow = (name, email) => {
          const n = h('input', { class: 'ap-input', value: name || '', placeholder: 'Name', 'aria-label': 'Name', autocomplete: 'off' });
          const e = h('input', { class: 'ap-input', value: email || '', placeholder: 'Email', type: 'email', inputmode: 'email', 'aria-label': 'Email', autocomplete: 'off' });
          const r = { n, e };
          const x = A.btn('Remove row', { ghost: true, iconOnly: true, icon: 'x', onClick: () => { if (rows.length > 1) { rows.splice(rows.indexOf(r), 1); el.remove(); } else { n.value = ''; e.value = ''; } } });
          const el = h('div', { class: 'ap-people-row' }, n, e, x);
          e.addEventListener('paste', ev => { const t = (ev.clipboardData || window.clipboardData).getData('text'); if (/\n|,|;|\t/.test(t.trim())) { ev.preventDefault(); takeList(t); } });
          rows.push(r);
          rowsBox.appendChild(el);
          return r;
        };
        const parse = t => String(t || '').split(/\r?\n|;/).map(line => {
          const m = line.match(/[^\s<>,;"']+@[^\s<>,;"']+\.[a-z]{2,}/i);
          if (!m) return null;
          const name = line.replace(m[0], ' ').replace(/[<>"'\t,]+/g, ' ').replace(/\s+/g, ' ').trim();
          return { name, email: m[0] };
        }).filter(Boolean);
        const takeList = t => {
          const list = parse(t);
          if (!list.length) return;
          // The empty rows go; the list's people come in as rows to read before adding.
          for (let i = rows.length - 1; i >= 0; i--) if (!rows[i].n.value.trim() && !rows[i].e.value.trim() && rows.length > 1) { rows[i].n.parentNode.remove(); rows.splice(i, 1); }
          list.forEach((x, i) => { const r = i === 0 && rows.length === 1 && !rows[0].n.value.trim() && !rows[0].e.value.trim() ? rows[0] : addRow(); r.n.value = x.name; r.e.value = x.email; });
          A.toast(A.fmt.plural(list.length, 'person', 'people') + ' from the list · Check the names');
        };
        const first = addRow();
        first.n.setAttribute('data-autofocus', '');
        const more = h('button', { type: 'button', class: 'ap-link', text: 'Add another', on: { click: () => addRow().n.focus() } });
        const paste = h('textarea', { class: 'ap-textarea', rows: '3', placeholder: 'Ruth Kinsey   ruth@example.com', 'aria-label': 'Paste a list' });
        paste.addEventListener('change', () => { if (paste.value.trim()) { takeList(paste.value); paste.value = ''; } });
        const pasteBox = h('details', { class: 'ap-more' }, h('summary', { text: 'Paste a list' }), paste, h('span', { class: 'ap-help', text: 'A name and an email on each line · From a spreadsheet works' }));
        const sel = p.c && !wm && A.committee(p.c) ? [p.c] : [];
        // From Home's "Add head": Head ticked (and the committee chosen when it's one).
        const head = h('input', { type: 'checkbox', checked: p.at === 'head' && !wm });
        const err = h('div', { class: 'ap-err', role: 'alert' });
        let typosOk = false;
        const add = btn => {
          const people = rows.map(r => ({ name: r.n.value.trim(), email: r.e.value.trim(), r })).filter(x => x.name || x.email);
          if (!people.length) { err.textContent = 'Name and email needed'; first.n.focus(); return; }
          const noName = people.find(x => !x.name), noMail = people.find(x => !/^[^\s@]+@[^\s@]+\.[a-z]{2,}$/i.test(x.email));
          if (noName) { err.textContent = 'Name needed · ' + (noName.email || 'a row'); noName.r.n.focus(); return; }
          if (noMail) { err.textContent = 'Email needed · ' + noMail.name; noMail.r.e.focus(); return; }
          if (!wm && !sel.length) { err.textContent = 'Choose a committee'; return; }
          btn.disabled = true;
          const emails = people.map(x => x.name.replace(/[<>"]/g, '') + ' <' + x.email + '>').join('\n');
          const body = wm ? { emails, role: 'coa', typos_ok: typosOk } : { emails, role: 'helper', committees: sel, head: head.checked, typos_ok: typosOk };
          W().api('POST', 'years/' + year + '/members', body).then(r => {
            const n = r.added.length, already = r.already.length;
            const to = wm ? 'the COA' : sel.map(cname).join(' and ');
            A.toast(n ? 'Added ' + A.fmt.plural(n, 'person', 'people') + ' to ' + to + ' · Sign-in link sent' + (already ? ' · ' + already + ' already on' : '') : already ? 'Already on the list' : 'No one added');
            if (r.bad && r.bad.length) { err.textContent = 'Not an email: ' + r.bad.join(', '); btn.disabled = false; }
            A.refreshBoot().then(() => { p.id = ''; A.setParams({ id: '' }); load(); });
          }).catch(e => {
            btn.disabled = false;
            if (e.status === 409 && e.data && e.data.code === 'ogc_typo') { typosOk = true; err.textContent = e.data.message; return; }
            err.textContent = (e.data && e.data.message) || 'Not added';
          });
        };
        const addBtn = A.btn('Add', { primary: true, write: true, onClick: () => add(addBtn) });
        sp.open({
          title: wm ? 'Add COA member' : 'Add people',
          body: [
            h('div', { class: 'ap-field' }, h('span', { text: 'People' }), rowsBox, h('div', { class: 'ap-row', style: { marginTop: '6px' } }, more)),
            pasteBox,
            wm ? null : h('div', { class: 'ap-field' }, h('span', { text: 'Committee' }), committeePills(sel)),
            wm ? null : h('label', { class: 'ap-switch' }, head, 'Head of committee'),
            h('p', { class: 'ap-help', text: wm ? 'Each gets a sign-in link · The COA sees the whole year' : 'Each gets a sign-in link · They see their committee’s screens' }),
            err
          ],
          foot: [addBtn],
          onClose: () => { p.id = ''; A.setParams({ id: '' }); }
        });
      }

      function openRow(m) {
        const sel = m.committees.slice();
        const head = h('input', { type: 'checkbox', checked: m.head });
        const can = m.can || {};
        const facts = h('dl', { class: 'ap-facts' },
          h('dt', { text: 'Email' }), h('dd', { text: m.email || '' }),
          h('dt', { text: 'Status' }), h('dd', { text: m.state === 'invited' ? (m.invite_expired ? 'Link expired · Invited ' + yr(m.invited) : 'Invited ' + yr(m.invited)) : m.signed_in ? 'Signed in ' + yr(m.signed_in) : 'Active' }),
          m.by ? [h('dt', { text: 'Added by' }), h('dd', { text: m.by })] : null,
          m.webmaster ? [h('dt', { text: 'Also' }), h('dd', { text: 'Webmaster' })] : null,
          h('dt', { text: 'Access until' }), h('dd', { text: m.until || '' }));
        const save = () => W().api('PATCH', 'members/' + m.id, { committees: sel, head: head.checked }).then(() => {
          A.toast('Saved · ' + (m.name || m.email) + ' · ' + (sel.map(cname).join(', ') || 'No committee'));
          A.refreshBoot().then(load);
        }).catch(A.fail);
        const body = [facts];
        if (!wm && !m._ro && m.role !== 'coa' && !A.readonly) {
          const ph = h('input', { class: 'ap-input', value: phones[m.id] || '', inputmode: 'tel', placeholder: '555-0100', 'aria-label': 'Phone', style: { maxWidth: '200px' } });
          ph.addEventListener('change', () => ctx.api('PUT', 'phones', { id: m.id, phone: ph.value.trim() }).then(r => { phones = r.phones || phones; A.toast(ph.value.trim() ? 'Phone saved · ' + (m.name || m.email) : 'Phone removed'); }).catch(A.fail));
          body.push(h('label', { class: 'ap-field' }, h('span', { text: 'Phone' }), ph, h('span', { class: 'ap-help', text: 'Optional · Only the COA sees it' })));
        }
        if (!wm && can.label && m.role !== 'coa') {
          body.push(h('div', { class: 'ap-field' }, h('span', { text: 'Committee' }), committeePills(sel)), h('label', { class: 'ap-switch', style: { marginBottom: '12px' } }, head, 'Head of committee'));
        }
        // Handles money (decision 4): the COA ticks it here; whoever has it sees each payment. The first
        // tick asks whether the address is this person's alone (a shared one would show every payment to
        // whoever else reads it).
        if (can.money && !A.readonly) body.push(moneyField(m));
        else if (m.money) body.push(h('p', { class: 'ap-help', text: 'Handles money' }));
        else if (m.you && (data.viewer || {}).money && !A.readonly) body.push(h('p', { class: 'ap-help', text: 'Handles money · Another COA member ticks it' }));
        const foot = [];
        if (!wm && can.label && m.role !== 'coa') foot.push(A.btn('Save', { primary: true, write: true, onClick: save }));
        if (m.state === 'invited' && can.resend) foot.push(A.btn('Resend', { write: true, onClick: () => W().api('POST', 'members/' + m.id + '/resend').then(() => A.toast('Sent a new link · ' + (m.name || m.email))).catch(A.fail) }));
        if (can.remove) foot.push(A.btn('Remove', { danger: true, ghost: true, write: true, onClick: () => W().api('DELETE', 'members/' + m.id).then(() => {
          A.toast('Removed · ' + (m.name || m.email), { undo: () => W().api('PATCH', 'members/' + m.id, { restore: true }).then(() => { A.toast('Restored · ' + (m.name || m.email)); A.refreshBoot().then(load); }).catch(A.fail) });
          p.id = ''; A.setParams({ id: '' });
          A.refreshBoot().then(load);
        }).catch(A.fail) }));
        const i = drawnPeople.findIndex(x => x.id === m.id);
        const stepTo = x => () => { p.id = String(x.id); A.setParams({ id: x.id }); draw(); };
        sp.open({ title: m.name || m.email, body, foot, onClose: () => { p.id = ''; A.setParams({ id: '' }); draw(); },
          tags: [m.role === 'coa' ? A.tag('COA') : m.head ? A.tag('Head', 'tan') : null, m.money ? A.tag('Handles money') : null, m.state === 'invited' ? A.tag('Invited') : null],
          nav: i < 0 ? null : { prev: i > 0 ? stepTo(drawnPeople[i - 1]) : null, next: i < drawnPeople.length - 1 ? stepTo(drawnPeople[i + 1]) : null } });
      }

      function moneyField(m) {
        const box = h('input', { type: 'checkbox', checked: !!m.money });
        const ask = h('div', { class: 'pv-ask', hidden: true });
        const err = h('div', { class: 'ap-err', role: 'alert' });
        const who = m.name || m.email;
        // Saved at once; only the list redraws, so the panel's unsaved Committee and Head stay as they are.
        const send = (on, own) => W().api('PATCH', 'members/' + m.id, own ? { money: on, own_email: true } : { money: on }).then(r => {
          A.toast(on ? 'Handles money · ' + who : 'Removed · Handles money · ' + who);
          m.money = on;
          if (r && r.list) data = r.list;
          draw(true);
        }).catch(e => { box.checked = !!m.money; if (e.status === 409 && e.data && e.data.code === 'ogc_own_email') { ask.hidden = false; return; } A.fail(e); });
        // No: a shared address (a couple's) would show every payment to both. The way on: add the person
        // again with an address only they read, then tick that row. A COA member's address is the webmasters'.
        const next = h('div', { class: 'pv-ask', hidden: true });
        const showNext = () => {
          A.clear(next).append(h('p', { class: 'pv-ask__q', text: 'Needs an email only ' + who + ' reads' }),
            m.role === 'coa' ? h('p', { class: 'ap-help', text: 'The webmasters add a COA member’s own email' })
              : h('div', { class: 'ap-row' }, A.btn('Add their email', { write: true, title: 'Adds ' + who + ' again with their own address · Then tick Handles money on that row', onClick: () => {
                p.id = 'new'; p.c = m.committees[0] || ''; A.setParams({ id: 'new', c: p.c }); openAdd();
              } })));
          next.hidden = false;
        };
        A.clear(ask).append(h('p', { class: 'pv-ask__q', text: 'Only ' + who + ' reads ' + (m.email || 'this email') + '?' }),
          h('p', { class: 'ap-help', style: { margin: '-6px 0 10px' }, text: 'Each payment shows to whoever reads it' }),
          h('div', { class: 'ap-row' },
            A.btn('Yes', { write: true, onClick: () => { ask.hidden = true; box.checked = true; send(true, true); } }),
            A.btn('No', { ghost: true, onClick: () => { ask.hidden = true; box.checked = false; showNext(); } })));
        box.addEventListener('change', () => {
          err.textContent = '';
          next.hidden = true;
          if (box.checked && !m.money) { box.checked = false; ask.hidden = false; return; }
          ask.hidden = true;
          send(box.checked, false);
        });
        return h('div', { class: 'ap-field' }, h('label', { class: 'ap-switch' }, box, 'Handles money'),
          h('span', { class: 'ap-help', text: 'Sees each payment · Checks and refunds' }), ask, next, err);
      }

      sp.main.appendChild(h('div', { class: 'ap-quiet', style: { padding: '20px' }, role: 'status', text: 'Loading' }));
      load();
    }
  });

  A.action({ id: 'add-people', title: 'Add people', screen: 'members', when: b => b.viewer.coa && !b.viewer.as, run: () => A.go({ s: 'members', id: 'new', c: '' }) });

  /* ------------------------------------------------------------ Years (webmasters) */

  A.screen({
    id: 'years', title: 'Years', icon: 'years', section: 'own', who: ['webmaster'],
    render(ctx) {
      const boot = ctx.boot;
      ctx.head('Years', A.fmt.plural(boot.years.length, 'year'), []);
      const sp = ctx.split();
      sp.main.appendChild(A.table({
        label: 'Years', rows: boot.years, key: y => y.year,
        onOpen: y => { location.href = A.href({ year: y.year, s: 'home', as: '', team: '' }); },
        cols: [
          { label: 'Year', render: y => h('span', { class: 'ap-cell-title', text: y.label }) },
          { label: '', cls: 'ap-td--num', render: y => y.year === boot.year ? A.tag('Open', 'tan') : A.link({ year: y.year, s: 'home' }, 'Open', 'ap-link') }
        ]
      }));
    }
  });
})();
