/*
 * Members (the COA) and Access (the webmasters): who is on the year, and the one place to add, change and
 * remove them (Round 6b, Oct 17; docs/27-back-end-map/area-people-access.md §3, §4). The person panel, Add
 * people, Ask and Handles money are the people kit's (screens/people-kit.js), hosted beside the list.
 *
 *   s=members&v=all|heads|nohead|invited|ending|asked|removed|history&c=<committee>&id=<member>|new&at=head|money
 *
 * The search box is never kept in the address (P8). A webmaster seeing as the COA gets the COA's list from
 * the server, read only and logged; every write is greyed here and refused there.
 */
(function () {
  'use strict';
  const A = window.OGC_APP, h = A.h;

  const VIEWS = ['all', 'heads', 'nohead', 'invited', 'ending', 'asked', 'removed', 'history'];
  const ALIAS = { nosignin: 'invited' };

  A.screen({
    id: 'members', icon: 'members', section: 'own', who: ['coa', 'webmaster'],
    title: b => b.viewer.coa ? 'Members' : 'Access',
    render(ctx) {
      const P = A.people;
      const boot = ctx.boot, v = boot.viewer, p = ctx.params;
      const wm = v.webmaster && !v.coa;
      const sp = ctx.split();
      sp.el.classList.add('pp-split');
      let alive = true;
      const st = { find: '', ticks: new Set() };
      let data = null, phones = {}, history = null;
      const load = () => Promise.all([P.list(), !wm && !A.readonly ? ctx.api('GET', 'phones').catch(() => ({ phones: {} })) : Promise.resolve({ phones: {} })])
        .then(([d, ph]) => { if (!alive) return; data = d; phones = ph.phones || {}; draw(); })
        .catch(() => { if (alive) A.clear(sp.main).appendChild(A.empty({ title: 'Not loaded', line: 'Reload the page', inset: true })); });
      const again = () => { history = null; return A.refreshBoot().then(load); };
      sp.main.appendChild(h('div', { class: 'ap-quiet', style: { padding: '20px' }, role: 'status', text: 'Loading' }));
      load();
      // "/" focuses the search (never inside a field).
      const onKey = e => { if (e.key === '/' && !e.target.closest('input, textarea, [contenteditable]')) { const f = sp.main.querySelector('.rx-find input'); if (f) { e.preventDefault(); f.focus(); } } };
      document.addEventListener('keydown', onKey);

      function draw() { return wm ? access() : members(); }

      /* ------------------------------------------------------------ Members (the COA) */

      function members() {
        const order = ['coa'].concat(boot.committees.map(c => c.key).filter(k => k !== 'coa'));
        const c = p.c && order.includes(p.c) ? p.c : '';
        let view = ALIAS[p.v] || p.v || 'all';
        const active = data.members.filter(m => !m.removed);
        // Who is in each committee's group: the COA's rows in the COA group; someone on two under each.
        const keysOf = m => m.role === 'coa' ? ['coa'] : (m.committees.length ? m.committees : ['']);
        const inC = m => !c || keysOf(m).includes(c);
        const people = active.filter(inC);
        const heads = people.filter(m => m.role !== 'coa' && m.head);
        const groupsWithPeople = k => active.some(m => keysOf(m).includes(k));
        const noHead = order.filter(k => k !== 'coa' && (!c || k === c) && !active.some(m => m.role !== 'coa' && m.head && keysOf(m).includes(k)));
        const invited = people.filter(m => m.state === 'invited');
        const ending = people.filter(m => m.ending_soon || m.expired);
        const asks = (data.asks || []).filter(a => !c || a.c === c || (a.cs || []).includes(c));
        const removed = (data.removed_rows || []).filter(m => !c || keysOf(m).includes(c));
        const chips = [{ id: 'all', label: 'All', n: people.length }];
        if (heads.length) chips.push({ id: 'heads', label: 'Heads', n: heads.length });
        if (noHead.length) chips.push({ id: 'nohead', label: 'No head', n: noHead.length });
        if (invited.length) chips.push({ id: 'invited', label: 'Not signed in', n: invited.length });
        if (ending.length) chips.push({ id: 'ending', label: 'Ending soon', n: ending.length });
        if (asks.length) chips.push({ id: 'asked', label: 'Asked', n: asks.length });
        if (removed.length) chips.push({ id: 'removed', label: 'Removed', n: removed.length });
        chips.push({ id: 'history', label: 'History' });
        if (!chips.some(x => x.id === view)) view = 'all';

        // The title row: the crumb when filtered, the fact (each part a door), Export and Add people.
        const money = active.filter(m => m.money);
        const fact = h('span', null,
          A.fmt.plural(people.length, 'person', 'people'),
          invited.length ? [' · ', A.link({ v: 'invited', id: '' }, invited.length + ' not signed in')] : null,
          c ? null : [' · ', money.length ? A.link({ at: 'money', id: '' }, 'Handles money · ' + money.map(m => short(m)).join(' · '))
            : A.link({ at: 'money', id: '' }, 'No one handles money', 'pp-tan')]);
        const exportBtn = A.btn('Export', { ghost: true, icon: 'file', title: 'Has names · Delete after the Conference', onClick: () => exportRows([]) });
        const addBtn = A.btn('Add people', { primary: true, icon: 'plus', write: true, onClick: () => { A.setParams({ id: 'new' }); p.id = 'new'; openAdd(); } });
        ctx.head('Members', fact, [exportBtn, addBtn], c ? { crumb: { label: cname(c), to: { s: 'committees', c, id: '', v: '' } } } : {});

        A.clear(sp.main);
        const bar = h('div', { class: 'ap-views pp-bar' });
        if (c) {
          const x = A.link({ c: '', id: '', v: view === 'all' ? '' : view }, h('span', { class: 'ap-sr', text: 'Every committee' }), 'ap-chip__x');
          x.appendChild(A.icon('x', 13));
          bar.appendChild(h('span', { class: 'ap-chip ap-chip--filter', 'data-filter': c }, cname(c), x));
        }
        bar.appendChild(A.views(chips, view, id => { A.setParams({ v: id === 'all' ? '' : id, id: '' }); p.v = id; p.id = ''; st.ticks.clear(); sp.close(true); draw(); }));
        const R = window.OGC_REC;
        if (R && !['history', 'asked'].includes(view)) bar.appendChild(R.find(st.find, x => { st.find = x; drawList(); }, 'Search'));
        sp.main.appendChild(bar);
        const bulk = h('div');
        const list = h('div');
        sp.main.append(bulk, list);

        function drawList() {
          A.clear(list);
          if (view === 'history') return drawHistory(list);
          if (view === 'asked') return drawAsked(list, asks);
          if (view === 'removed') return drawRemoved(list, removed);
          let rows = view === 'heads' ? heads : view === 'invited' ? invited : view === 'ending' ? ending : people;
          const R2 = window.OGC_REC;
          if (st.find && R2) rows = rows.filter(m => R2.matches(st.find, m.name || '', m.email || ''));
          // Groups in the board's order, the COA first; a committee with no one is drawn with Add head.
          let keys = order.filter(k => !c || k === c);
          if (view === 'nohead') keys = noHead;
          else if (view !== 'all' || st.find) keys = keys.filter(k => rows.some(m => keysOf(m).includes(k)));
          if (view === 'nohead') rows = people;
          if (st.find && !rows.length) {
            list.appendChild(A.empty({ title: 'No one named ' + st.find, inset: true, action: h('button', { type: 'button', class: 'ap-btn', text: 'Clear search', on: { click: () => { st.find = ''; const f = bar.querySelector('.rx-find input'); if (f) f.value = ''; drawList(); } } }) }));
            drawBulk([]);
            return;
          }
          list.appendChild(table(keys, rows, view));
          drawBulk(rows);
        }

        function table(keys, rows, view) {
          const anyPhone = rows.some(m => phones[m.id]);
          const cols = 4 + (anyPhone ? 1 : 0) + 1;
          const tb = h('tbody');
          const drawnIds = [];
          keys.forEach(k => {
            const g = rows.filter(m => keysOf(m).includes(k));
            const ghead = h('tr', { class: 'ap-tr--group pp-group', 'data-group': k },
              h('td', { colspan: String(cols) }, h('span', { class: 'pp-group__row' },
                A.link({ s: 'committees', c: k, id: '', v: '', at: '' }, k === 'coa' ? 'COA · Added by the webmasters' : cname(k) + (g.length ? ' · ' + g.length : ''), 'pp-group__name'),
                k === 'coa' ? null : h('button', { type: 'button', class: 'ap-link pp-group__add', disabled: A.readonly, title: A.readonly ? 'Read only while seeing as' : 'Add people to ' + cname(k), text: 'Add', on: { click: () => goAdd(k, false) } }))));
            tb.appendChild(ghead);
            if (!g.length || (view === 'nohead' && k !== 'coa')) {
              if (!g.length || view === 'nohead') {
                const why = g.length ? 'No head' : 'No one yet';
                tb.appendChild(h('tr', { class: 'pp-empty', 'data-empty': k }, h('td', { colspan: String(cols) }, h('span', { class: 'pp-empty__row' }, h('span', { class: 'ap-quiet', text: why }),
                  h('button', { type: 'button', class: 'ap-link pp-addhead', disabled: A.readonly, title: A.readonly ? 'Read only while seeing as' : null, text: 'Add head', on: { click: () => goAdd(k, true) } })))));
              }
            }
            g.forEach(m => {
              if (!drawnIds.includes(m.id)) drawnIds.push(m.id);
              const key = m.id + '|' + k;
              const tick = h('input', { type: 'checkbox', class: 'ap-check', checked: st.ticks.has(m.id), 'aria-label': 'Select ' + (m.name || m.email) });
              tick.addEventListener('change', () => { if (tick.checked) st.ticks.add(m.id); else st.ticks.delete(m.id); tb.querySelectorAll('tr[data-id="' + m.id + '"] .ap-check').forEach(x => { x.checked = tick.checked; }); drawBulk(rows); });
              const s = P.status(m);
              const tr = h('tr', { 'data-key': key, 'data-id': String(m.id), 'aria-selected': String(String(p.id) === String(m.id)), tabindex: '-1' },
                h('td', { class: 'rx-tick pp-tick' }, tick),
                h('td', null, h('span', { class: 'ap-row', style: { flexWrap: 'nowrap' } }, A.face(m.name || String(m.email || '').split('@')[0], m.you),
                  h('span', null, P.nameBtn(m.name || m.email, () => open(m.id), { id: m.id, cls: 'ap-cell-title' }), m.helps && m.helps !== (m.committees || []).map(cname).join(', ') ? h('span', { class: 'ap-cell-sub', text: m.helps }) : null,
                    h('span', { class: 'ap-only-narrow ap-cell-sub', text: P.statusWords(m) })))),
                h('td', { class: 'ap-td--nowrap ap-td--wide' }, h('span', { class: 'ap-row', style: { flexWrap: 'nowrap', gap: '6px' } }, k === 'coa' ? 'COA' : m.head ? A.tag('Head', 'tan') : 'Helper', m.money ? A.tag('Handles money') : null, m.webmaster ? A.tag('Webmaster') : null)),
                h('td', { class: 'ap-td--muted ap-td--wide' }, m.name ? m.email : ''),
                anyPhone ? h('td', { class: 'ap-td--nowrap ap-td--muted ap-td--wide' }, phones[m.id] || '') : null,
                h('td', { class: 'ap-td--nowrap ap-td--wide' }, statusCell(m, s)));
              tr.addEventListener('click', e => { if (e.target.closest('button, a, input, label')) return; open(m.id); });
              tb.appendChild(tr);
            });
          });
          drawn = drawnIds;
          const t = h('table', { class: 'ap-table pp-table', 'aria-label': 'Members' },
            h('thead', null, h('tr', null, h('th', { class: 'rx-tick pp-tick', scope: 'col' }, h('span', { class: 'ap-sr', text: 'Select' })), h('th', { scope: 'col', text: 'Name' }), h('th', { scope: 'col', class: 'ap-td--wide', text: 'Role' }), h('th', { scope: 'col', class: 'ap-td--wide', text: 'Email' }),
              anyPhone ? h('th', { scope: 'col', class: 'ap-td--wide', text: 'Phone' }) : null, h('th', { scope: 'col', class: 'ap-td--wide', text: 'Status' }))), tb);
          return h('div', { class: 'ap-tablewrap' }, t);
        }

        function statusCell(m, s) {
          const word = s.tone ? A.tag(P.statusWords(m), s.tone) : h('span', { class: m.state === 'invited' ? 'ap-quiet' : '', text: P.statusWords(m) });
          if (m.state !== 'invited') return word;
          return h('span', { class: 'ap-row', style: { flexWrap: 'nowrap', gap: '10px' } }, word,
            h('button', { type: 'button', class: 'ap-link', text: 'Resend', disabled: A.readonly || !(m.can || {}).resend, title: A.readonly ? 'Read only while seeing as' : 'A new sign-in link',
              on: { click: () => A.api('POST', '/members/' + m.id + '/resend').then(() => A.toast('Sent a new link · ' + (m.name || m.email))).catch(A.fail) } }));
        }

        // Ticked rows: "3 selected · Resend · Remove from 2027 · Export · Clear" (desktop; P14's Take off waits).
        function drawBulk(rows) {
          A.clear(bulk);
          const R3 = window.OGC_REC;
          const on = active.filter(m => st.ticks.has(m.id));
          if (!on.length || !R3) return;
          const inv = on.filter(m => m.state === 'invited');
          const rem = on.filter(m => (m.can || {}).remove || (A.readonly && m.role !== 'coa'));
          const hidden = on.filter(m => !rows.includes(m)).length;
          bulk.appendChild(R3.bulk(on.length, [
            inv.length ? A.btn('Resend · ' + inv.length, { write: true, onClick: () => Promise.all(inv.map(m => A.api('POST', '/members/' + m.id + '/resend').catch(() => null))).then(r => A.toast('Sent new links · ' + r.filter(Boolean).length)) }) : null,
            A.btn('Export', { icon: 'file', onClick: () => exportRows(on.map(m => m.id)) }),
            rem.length ? A.btn('Remove from ' + boot.year + ' · ' + rem.length, { danger: true, ghost: true, write: true, onClick: () => removeMany(rem) }) : null
          ], () => { st.ticks.clear(); drawList(); }, hidden));
        }

        function removeMany(list) {
          const box = h('div', { class: 'pv-ask pp-bulkask', role: 'alert' }, h('p', { class: 'pv-ask__q', text: 'Remove ' + A.fmt.plural(list.length, 'person', 'people') + ' from ' + boot.year + ' · Their access ends now · Every committee' }),
            h('div', { class: 'ap-row' }, A.btn('Remove', { danger: true, write: true, onClick: () => Promise.all(list.map(m => A.api('DELETE', '/members/' + m.id).then(() => m).catch(() => null))).then(done => {
              const ok = done.filter(Boolean);
              st.ticks.clear();
              A.toast('Removed ' + A.fmt.plural(ok.length, 'person', 'people'), { undo: () => Promise.all(ok.map(m => A.api('PATCH', '/members/' + m.id, { restore: true }).catch(() => null))).then(() => { A.toast('Restored · ' + ok.length); again(); }) });
              again();
            }) }), A.btn('Cancel', { ghost: true, onClick: () => box.remove() })));
          bulk.appendChild(box);
        }

        drawList();
        openFromAddress();
      }

      /* ------------------------------------------------------------ the views that aren't rows of people */

      function drawHistory(box) {
        const draw = () => {
          A.clear(box);
          if (!history.length) { box.appendChild(A.empty({ title: 'No changes yet', inset: true })); return; }
          box.appendChild(h('ul', { class: 'ap-list pp-hist' }, history.map(x => h('li', null, h('div', { class: 'ap-item' },
            h('span', { class: 'ap-item__main' }, x.id ? h('button', { type: 'button', class: 'pp-name ap-item__title', 'data-person': String(x.id), text: x.words + (x.n > 1 ? ' × ' + x.n : ''), on: { click: () => open(x.id) } }) : h('span', { class: 'ap-item__title', text: x.words + (x.n > 1 ? ' × ' + x.n : '') }),
              h('span', { class: 'ap-item__why', text: x.at })))))));
        };
        if (history) return draw();
        box.appendChild(h('p', { class: 'ap-quiet', style: { padding: '20px' }, role: 'status', text: 'Loading' }));
        A.api('GET', '/years/' + boot.year + '/members/history').then(r => { history = r || []; if (alive) draw(); }).catch(() => { A.clear(box).appendChild(A.empty({ title: 'Not loaded', inset: true })); });
      }

      function drawAsked(box, asks) {
        box.appendChild(h('ul', { class: 'ap-list pp-asks' }, asks.map(a => h('li', { 'data-ask': a.id }, h('div', { class: 'ap-item' },
          h('span', { class: 'ap-item__main' }, h('span', { class: 'ap-item__title', text: (a.name || a.email) + (a.name ? ' · ' + a.email : '') }),
            h('span', { class: 'ap-item__why' }, a.kind === 'head' ? ['Asked by ', a.by_id ? P.nameBtn(a.by, () => open(a.by_id), { id: a.by_id }) : a.by, ' · ', a.c ? A.link({ s: 'committees', c: a.c, id: '', v: '' }, a.cname) : a.cname, ' · ', A.fmt.md(a.at)]
              : ['Asked for access · ', a.was || '', a.cname ? ' · ' + a.cname : '', ' · ', A.fmt.md(a.at)])),
          h('span', { class: 'ap-item__side pp-acts' },
            A.btn('Add', { write: true, onClick: () => { A.setParams({ id: 'new' }); P.add(sp, { c: a.c, cs: a.kind === 'access' ? (a.cs || []) : null, rows: [{ name: a.name, email: a.email }], ask: a.id, onDone: afterAdd, onClose: closed }); } }),
            A.btn('Dismiss', { ghost: true, write: true, onClick: () => A.api('POST', '/years/' + boot.year + '/members/asks/' + a.id + '/dismiss').then(() => { A.toast('Dismissed · ' + (a.name || a.email)); again(); }).catch(A.fail) })))))));
      }

      function drawRemoved(box, list) {
        box.appendChild(h('ul', { class: 'ap-list pp-removed' }, list.map(m => h('li', null, h('div', { class: 'ap-item' },
          h('span', { class: 'ap-item__main' }, h('span', { class: 'ap-item__title', text: m.name || m.email }),
            h('span', { class: 'ap-item__why', text: [(m.committees || []).map(cname).join(', ') || (m.role === 'coa' ? 'COA' : ''), 'Removed ' + A.fmt.md(m.removed_on) + (m.removed_by ? ' · ' + m.removed_by : '')].filter(Boolean).join(' · ') })),
          h('span', { class: 'ap-item__side pp-acts' }, m.restore
            ? A.btn('Restore', { write: true, onClick: () => A.api('PATCH', '/members/' + m.id, { restore: true }).then(() => { A.toast('Restored · ' + (m.name || m.email)); again(); }).catch(A.fail) })
            : A.btn('Add again', { write: true, onClick: () => { A.setParams({ id: 'new' }); P.add(sp, { cs: m.committees || [], rows: [{ name: m.name, email: m.email }], onDone: afterAdd, onClose: closed }); } })))))));
      }

      /* ------------------------------------------------------------ Access (the webmasters) */

      function access() {
        const coa = data.members.filter(m => !m.removed && m.role === 'coa');
        const invited = coa.filter(m => m.state === 'invited'), ending = coa.filter(m => m.ending_soon || m.expired);
        let view = ALIAS[p.v] || p.v || 'all';
        const chips = [{ id: 'all', label: 'All', n: coa.length }];
        if (invited.length) chips.push({ id: 'invited', label: 'Not signed in', n: invited.length });
        if (ending.length) chips.push({ id: 'ending', label: 'Ending soon', n: ending.length });
        if (!chips.some(x => x.id === view)) view = 'all';
        const cs = data.coa_state || {};
        const fact = !coa.length ? 'No COA yet' : cs.late ? h('span', { class: 'pp-tan', text: 'Not invited · Late' }) : 'COA · ' + coa.filter(m => m.signed_in).length + ' of ' + coa.length + ' signed in';
        ctx.head('Access', fact, [
          A.btn('See as COA', { ghost: true, icon: 'eye', title: 'The committees’ members, read only · Logged', onClick: () => A.go({ as: 'coa', s: 'members', id: '', v: '', c: '' }) }),
          coa.length ? A.btn('Export', { ghost: true, icon: 'file', onClick: () => exportRows([]) }) : null,
          A.btn('Add COA member', { primary: true, icon: 'plus', onClick: () => { A.setParams({ id: 'new' }); p.id = 'new'; openAdd(); } })
        ].filter(Boolean));
        A.clear(sp.main);
        if (chips.length > 1) sp.main.appendChild(h('div', { class: 'ap-views' }, A.views(chips, view, id => { A.setParams({ v: id === 'all' ? '' : id, id: '' }); p.v = id; sp.close(true); draw(); })));
        const rows = view === 'invited' ? invited : view === 'ending' ? ending : coa;
        drawn = rows.map(m => m.id);
        sp.main.appendChild(!coa.length ? A.empty({ title: 'No COA yet', line: 'Names come from the Scheduling Committee or the outgoing COA’s secretary', inset: true,
          action: A.btn('Add COA member', { icon: 'plus', onClick: () => { A.setParams({ id: 'new' }); openAdd(); } }) }) : A.table({
          label: 'COA members', rows, key: m => m.id, selected: p.id,
          onOpen: m => open(m.id),
          cols: [
            { label: 'Name', render: m => h('span', { class: 'ap-row', style: { flexWrap: 'nowrap' } }, A.face(m.name || String(m.email || '').split('@')[0], m.you), h('span', null, P.nameBtn(m.name || m.email, () => open(m.id), { id: m.id, cls: 'ap-cell-title' }), m.webmaster ? h('span', { class: 'ap-cell-sub', text: 'Webmaster' }) : null, h('span', { class: 'ap-only-narrow ap-cell-sub', text: P.statusWords(m) }))) },
            { label: 'Email', cls: 'ap-td--muted', wide: true, render: m => m.name ? m.email : '' },
            { label: 'Status', cls: 'ap-td--nowrap', wide: true, render: m => m.state === 'invited' ? h('span', { class: 'ap-row', style: { flexWrap: 'nowrap', gap: '10px' } }, h('span', { class: 'ap-quiet', text: P.statusWords(m) }),
              h('button', { type: 'button', class: 'ap-link', text: 'Resend', on: { click: () => A.api('POST', '/members/' + m.id + '/resend').then(() => A.toast('Sent a new link · ' + (m.name || m.email))).catch(A.fail) } })) : P.statusWords(m) },
            // How long access lasts, always said on Access (the webmasters set it: 1–3 years).
            { label: 'Access until', cls: 'ap-td--nowrap', wide: true, render: m => m.until }
          ].filter(Boolean)
        }));
        webmasters();
        openFromAddress();
      }

      // The webmasters themselves (P5: moved here from Years): one asks to add or remove, a second confirms.
      function webmasters() {
        const K = window.OGC_COA;
        if (!K) return;
        const box = h('div', { class: 'pp-web' });
        sp.main.appendChild(box);
        K.api('GET', 'webmasters').then(web => {
          if (!alive || !web) return;
          const list = h('ul', { class: 'ap-list' }, web.list.map(w => h('li', null, h('div', { class: 'ap-item' }, A.face(w.name || String(w.email || '').split('@')[0], w.me),
            h('span', { class: 'ap-item__main' }, h('span', { class: 'ap-item__title', text: (w.name || w.email) + (w.me ? ' (you)' : '') }), h('span', { class: 'ap-item__why', text: w.admin ? 'Site admin' : w.last ? 'Signed in ' + K.md(w.last.slice(0, 10)) : 'Not signed in yet' })),
            !w.admin && !w.me ? K.link('Remove', () => askWeb(web, w.email, 'remove', w.name || w.email), { danger: true }) : null))));
          const asks = (web.asks || []).map(a => h('div', { class: 'cx-from' }, h('span', { class: 'cx-from__t', text: (a.act === 'remove' ? 'Remove ' : 'Add ') + (a.name || a.email) }), h('span', { class: 'ap-quiet', text: 'Asked by ' + (a.by || 'a webmaster') }),
            a.mine ? K.link('Cancel', () => K.api('POST', 'webmasters', { email: a.email, cancel: 1 }).then(() => { A.toast('Cancelled'); draw(); }, A.fail)) : A.btn('Confirm', { onClick: () => K.api('POST', 'webmasters/confirm', { email: a.email }).then(() => { A.toast('Confirmed · ' + (a.name || a.email)); draw(); }, A.fail) })));
          box.appendChild(h('div', { class: 'cx-page' }, K.section('Webmasters · Every year', { n: web.list.length, help: web.alone ? 'One webmaster · Adding someone goes ahead at once' : 'Adding or removing one needs a second webmaster', act: K.link('Add webmaster', () => addWeb(web), { icon: 'plus' }) }, asks, list)));
        }).catch(() => box.remove());
      }
      function addWeb(web) {
        const K = window.OGC_COA;
        const email = K.textIn({ label: 'Email', placeholder: 'name@example.org', inputmode: 'email', live: false });
        const name = K.textIn({ label: 'Name', placeholder: 'First and last name', live: false });
        K.confirm(sp, { title: 'Add webmaster', lines: [web.alone ? 'Goes ahead at once' : 'A second webmaster confirms'], field: h('div', null, K.field('Email', email), K.field('Name', name)), actLabel: web.alone ? 'Add' : 'Request',
          act: () => { const e = email.value.trim(); if (!/^[^\s@]+@[^\s@]+\.[a-z]{2,}$/i.test(e)) return Promise.reject({ message: 'An email address' }); return K.api('POST', 'webmasters', { email: e, act: 'add', name: name.value.trim() }); },
          onDone: () => { A.toast(web.alone ? 'Added · Sign-in link sent' : 'Requested · A second webmaster confirms'); draw(); } });
      }
      function askWeb(web, email, act, label) {
        const K = window.OGC_COA;
        K.confirm(sp, { title: 'Remove ' + label, danger: true, lines: [web.alone ? 'Goes ahead at once' : 'A second webmaster confirms'], actLabel: web.alone ? 'Remove' : 'Request',
          act: () => K.api('POST', 'webmasters', { email, act }), onDone: () => { A.toast('Requested · Remove ' + label); draw(); } });
      }

      /* ------------------------------------------------------------ the panel beside the list */

      let drawn = [];
      const cname = k => P.cname(k);
      const short = m => { const n = String(m.name || '').trim().split(/\s+/); return n.length > 1 ? n[0] + ' ' + n[n.length - 1][0] + '.' : (m.name || m.email); };
      const closed = () => { p.id = ''; A.setParams({ id: '' }); sp.main.querySelectorAll('tr[aria-selected="true"]').forEach(tr => tr.setAttribute('aria-selected', 'false')); };
      function open(id) {
        p.id = String(id);
        A.setParams({ id });
        sp.main.querySelectorAll('tr[data-id]').forEach(tr => tr.setAttribute('aria-selected', String(tr.dataset.id === String(id))));
        const i = drawn.indexOf(+id);
        const step = x => () => open(x);
        P.open(sp, id, {
          c: p.c, onClose: closed, onChange: () => { again(); },
          nav: i < 0 ? null : { prev: i > 0 ? step(drawn[i - 1]) : null, next: i < drawn.length - 1 ? step(drawn[i + 1]) : null }
        });
      }
      function goAdd(k, head) { A.setParams({ id: 'new' }); p.id = 'new'; P.add(sp, { c: k, head, onDone: afterAdd, onClose: closed }); }
      function openAdd() { P.add(sp, { c: p.c, head: p.at === 'head', wm, years: wm ? 2 : 1, onDone: afterAdd, onClose: closed }); }
      // After Add: one person → their panel; several → the list, the panel closed (6.2).
      function afterAdd(r) {
        const ids = (r.added || []).concat(r.merged || []);
        data = r.list || data;
        A.refreshBoot().then(() => {
          if (!alive) return;
          if (ids.length === 1) { p.id = String(ids[0]); A.setParams({ id: ids[0] }); }
          else { p.id = ''; A.setParams({ id: '' }); sp.close(true); }
          load();
        });
      }
      function openFromAddress() {
        if (p.at === 'money' && !wm) { P.money(sp, data, { onClose: closed, onChange: again, onOpen: m => open(m.id) }); return; }
        if (p.id === 'new') { if (!sp.isOpen) openAdd(); return; }
        if (p.id && /^\d+$/.test(String(p.id))) { open(p.id); return; }
        sp.close(true);
      }

      function exportRows(ids) {
        const K = window.OGC_CK;
        const path = 'ogc/v1/years/' + boot.year + '/members/export' + '?ids=' + ids.join(',') + (p.c && !wm ? '&c=' + encodeURIComponent(p.c) : '') + (p.as ? '&as=' + encodeURIComponent(p.as) : '');
        const name = boot.year + ' ' + (wm ? 'COA' : 'Members') + ' (' + new Date().toISOString().slice(0, 10) + ').xlsx';
        if (K && K.fetchFile) K.fetchFile(path, name).then(() => A.toast('Downloaded · ' + (wm ? 'COA' : 'Members'))).catch(() => A.toast('Not downloaded'));
      }

      return () => { alive = false; document.removeEventListener('keydown', onKey); };
    }
  });

  A.action({ id: 'add-people', title: 'Add people', screen: 'members', when: b => b.viewer.coa && !b.viewer.as, run: () => A.go({ s: 'members', id: 'new', c: '' }) });
  A.action({ id: 'add-coa', title: 'Add COA member', screen: 'members', when: b => b.viewer.webmaster && !b.viewer.coa, run: () => A.go({ s: 'members', id: 'new', c: '' }) });
})();
