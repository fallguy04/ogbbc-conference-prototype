/*
 * Committees. The COA: the status board (every committee on one screen, where it stands in a few words,
 * tasks done, a mark when it needs a look; all written from data). A committee: the directory (their
 * own first, with everyone on it; then who is on each other committee and what it does, with Message).
 * A webmaster: the structure. Each opens to the committee's page (?c=): its people, responsibilities,
 * tasks, files, notes for next year, report, last year's notes and report, See as, and its past years
 * read-only (?past=2026; never past people). The viewer's own committee's page is this same address
 * (?c=<yours>, no crumb); "Overview" (s=overview) is its old name, rewritten by app.js.
 */
(function () {
  'use strict';
  const A = window.OGC_APP, h = A.h;

  /* ------------------------------------------------------------ the list */

  function board(ctx, d) {
    const p = ctx.params;
    const sp = ctx.split();
    // The chips and their rows come from the same marks (area-committees 2.2): a chip never shows 0.
    const has = (c, v) => (c.views || []).includes(v);
    const VIEWS = [['look', 'Needs a look'], ['nohead', 'No head'], ['late', 'Late'], ['from', 'Not checked']];
    const views = [{ id: '', label: 'All', n: d.committees.length }];
    VIEWS.forEach(([id, label]) => { const n = d.committees.filter(c => has(c, id)).length; if (n || p.v === id) views.push({ id, label, n }); });
    // What each committee was handed from last year and is leaving for next (committee-handdown.js).
    if (A.hd && ctx.boot.viewer.coa) views.push({ id: 'handdown', label: 'Hand-down' });
    const v = views.some(x => x.id === p.v) ? p.v : '';
    const rows = v ? d.committees.filter(c => has(c, v)) : d.committees;
    ctx.head('Committees', views.length > 1 ? '' : A.fmt.plural(d.committees.length, 'committee'),
      v === 'handdown' ? [A.hd.reportsBtn(ctx)] : [A.btn('Add committee', { icon: 'plus', write: true, onClick: () => addCommittee(ctx, sp) })]);
    sp.main.appendChild(h('div', { class: 'ap-views' }, A.views(views, v, id => A.go({ v: id }, { replace: true }))));
    if (v === 'handdown') { A.hd.board(ctx, sp); return; }
    const empty = { look: 'None need a look', nohead: 'Every committee has a head', late: 'Nothing late', from: 'All checked' };
    sp.main.appendChild(A.table({
      label: 'Committees',
      rows, key: c => c.key,
      // A row opens the committee's page, keeping the view (Back walks the same list).
      onOpen: c => A.go({ c: c.key, v }),
      empty: A.empty({ title: empty[v] || 'None', line: '', action: A.link({ s: 'committees', c: '', v: '' }, 'All committees', 'ap-btn'), inset: true }),
      cols: [
        { label: 'Committee', render: c => h('span', { class: 'ap-cell-title', text: c.name }) },
        // The committee's one fact (the same words its page and Home say); its marks beside it.
        { label: 'Where it stands', cls: 'ap-td--muted', render: c => h('span', { 'data-fact': c.key },
          h('span', { class: c.fact && c.fact.tone === 'late' ? 'yl-late' : c.fact && (c.fact.source === 'need' || c.fact.source === 'nobody') ? 'yl-need' : '', text: c.line || '' }),
          (c.look || []).length ? h('span', { class: 'ap-chips ap-chips--inline' }, c.look.map(l => A.tag(l, /late|No one|No head/.test(l) ? 'late' : 'tan'))) : null) },
        { label: 'Head', cls: 'ap-td--nowrap', wide: true, render: c => c.key === 'coa' ? '' : c.head },
        { label: 'People', cls: 'ap-td--num', wide: true, render: c => c.people_count ? String(c.people_count) : '' }
      ]
    }));
  }

  function addCommittee(ctx, sp) {
    const name = h('input', { class: 'ap-input', 'data-autofocus': '', maxlength: '60', 'aria-describedby': 'ap-ac-help' });
    const duties = h('textarea', { class: 'ap-textarea', rows: '4' });
    const err = h('div', { class: 'ap-err', role: 'alert' });
    const save = () => {
      ctx.api('POST', 'committees', { name: name.value, duties: duties.value }).then(r => {
        A.toast('Added ' + r.name);
        refreshBoot().then(() => A.go({ c: r.key, v: '' }));
      }).catch(e => { err.textContent = (e.data && e.data.message) || 'Not added'; });
    };
    sp.open({
      title: 'Add committee',
      body: [
        h('label', { class: 'ap-field' }, h('span', { text: 'Name' }), name, h('span', { class: 'ap-help', id: 'ap-ac-help', text: 'Kept for next year' })),
        h('label', { class: 'ap-field' }, h('span', { text: 'Responsibilities' }), duties, h('span', { class: 'ap-help', text: 'One a line' })),
        err
      ],
      foot: [A.btn('Add', { primary: true, write: true, onClick: save })]
    });
  }

  function directory(ctx0, d) {
    ctx0.head('Committees', A.fmt.plural(d.committees.length, 'committee'), []);
    // A split, so a name's short card opens beside the directory (Round 6b, P1).
    const sp = ctx0.split();
    const ctx = Object.assign({}, ctx0, { sp, body: sp.main });
    const body = ctx.body;
    const mine = d.committees.filter(c => c.mine);
    const rest = d.committees.filter(c => !c.mine);
    mine.forEach(c => {
      body.appendChild(h('section', { class: 'ap-mine', 'aria-label': c.name },
        h('h2', { class: 'ap-h2' }, c.name, c.people.length ? h('span', { class: 'ap-h2__n', text: A.fmt.plural(c.people.length, 'person', 'people') }) : null,
          h('span', { class: 'ap-h2__act' }, A.link({ s: 'overview', c: c.key, team: c.key }, 'Open', 'ap-link'))),
        h('p', { class: 'ap-dir__duties', text: c.duties }),
        people(ctx, c.people, c)));
    });
    body.appendChild(h('div', { class: 'ap-dir' }, rest.map(c => h('div', { class: 'ap-dir__c' },
      h('div', null, A.link({ c: c.key }, c.name, 'ap-dir__name')),
      h('div', null, c.duties ? h('div', { class: 'ap-dir__duties', text: c.duties }) : null,
        c.people.length ? h('div', { class: 'ap-dir__people' }, named(c.people).map(pp => h('span', null, nameDoor(ctx, pp, c), pp.head ? h('span', { class: 'ap-quiet', text: ' · Head' }) : null)),
          unnamed(c.people) ? h('span', { class: 'ap-quiet', text: unnamed(c.people) + ' invited' }) : null) : h('div', { class: 'ap-quiet', text: 'No one yet' })),
      h('div', null, c.people.length && !A.readonly ? h('button', { type: 'button', class: 'ap-link', text: 'Message', on: { click: () => message(ctx, { to: 'committee:' + c.key, label: c.name }) } }) : null)))));
  }

  // Someone invited who hasn't given a name shows as "1 invited", never a piece of their address.
  const masked = pp => /\*/.test(pp.name || '') || /@/.test(pp.name || '');
  const named = list => list.filter(pp => !masked(pp));
  const unnamed = list => list.filter(masked).length;

  function structure(ctx, d) {
    ctx.head('Committees', A.fmt.plural(d.committees.length, 'committee'), []);
    const sp = ctx.split();
    sp.main.appendChild(A.table({
      label: 'Committees', rows: d.committees, key: c => c.key, onOpen: c => A.go({ c: c.key }),
      cols: [
        { label: 'Committee', render: c => h('span', { class: 'ap-cell-title', text: c.name }) },
        { label: 'Responsibilities', cls: 'ap-td--muted', wide: true, render: c => (c.duties || '').split('\n').slice(0, 2).join(' · ') },
        { label: 'People', cls: 'ap-td--num', render: c => String(c.people_count) },
        // A column with nothing in it isn't drawn.
        d.committees.some(c => (c.screens || []).length) ? { label: 'Screens', render: c => (c.screens || []).map(id => (ctx.boot.screens.find(x => x.id === id) || { title: id }).title).join(', ') } : null
      ].filter(Boolean)
    }));
  }

  /* ------------------------------------------------------------ people and Message */

  // A name as a door (Round 6b, P1): the COA opens the person panel in place (id=person:<n>); anyone
  // else the short card, in place, never Members (which they can't open).
  function nameDoor(ctx, pp, c) {
    const P = A.people, v = ctx.boot.viewer;
    if (!P || !ctx.sp || masked(pp) && !v.coa) return h('span', { text: pp.name });
    const label = masked(pp) && pp.email ? pp.email : pp.name;
    if (v.coa && A.allowed('members')) return P.nameBtn(label, () => openPerson(ctx, pp.id, c), { id: pp.id });
    return P.nameBtn(label, () => P.card(ctx.sp, pp.id), { id: pp.id });
  }
  function openPerson(ctx, id, c) {
    A.setParams({ id: 'person:' + id });
    A.people.open(ctx.sp, id, { c: c && c.key, onClose: () => A.setParams({ id: '' }), onChange: () => A.reload() });
  }
  A.openPersonHere = openPerson;

  function people(ctx, list, c) {
    if (!list.length) return A.empty({ title: 'No one yet', line: ctx.boot.viewer.coa ? '' : 'The COA adds people', action: ctx.boot.viewer.coa && ctx.addHere ? A.btn('Add people', { write: true, onClick: () => ctx.addHere(false) }) : null });
    const shown = ctx.boot.viewer.coa ? list : named(list);
    const hidden = list.length - shown.length;
    return h('div', null, shown.map(pp => h('div', { class: 'ap-person' },
      A.face(masked(pp) && pp.email ? pp.email.split('@')[0] : pp.name, pp.you),
      h('div', { class: 'ap-person__main' },
        h('span', { class: 'ap-person__name' }, nameDoor(ctx, pp, c), pp.you ? h('span', { class: 'ap-quiet', text: ' · You' }) : null),
        h('span', { class: 'ap-person__sub', text: [pp.head ? 'Head' : '', masked(pp) ? '' : pp.email || '', pp.phone || '', pp.state === 'Invited' ? 'Not signed in' : ''].filter(Boolean).join(' · ') })),
      pp.you ? null : h('button', { type: 'button', class: 'ap-link ap-person__act', disabled: A.readonly, title: A.readonly ? 'Read only while seeing as' : null, text: 'Message', 'aria-label': 'Message ' + pp.name, on: { click: () => message(ctx, { to: 'member:' + pp.id, label: masked(pp) ? 'them' : pp.name }) } }))),
      hidden ? h('p', { class: 'ap-quiet', text: hidden + ' invited' }) : null);
  }

  // Message: the site emails them (no addresses shown); replies come to the sender.
  function message(ctx, o) {
    const sp = ctx.sp || null;
    const subject = h('input', { class: 'ap-input', maxlength: '120', 'data-autofocus': '', value: o.subject || '' });
    const text = h('textarea', { class: 'ap-textarea', rows: '7', maxlength: '4000' });
    const err = h('div', { class: 'ap-err', role: 'alert' });
    const send = btn => {
      if (!text.value.trim()) { err.textContent = 'Message needed'; text.focus(); return; }
      btn.disabled = true;
      ctx.api('POST', 'message', { to: o.to, subject: subject.value, body: text.value }).then(r => {
        A.toast('Sent to ' + (o.to.startsWith('member:') ? o.label : A.fmt.plural(r.sent, 'person', 'people') + ' · ' + o.label));
        close();
      }).catch(e => { btn.disabled = false; err.textContent = (e.data && e.data.message) || 'Not sent'; });
    };
    const body = [
      h('dl', { class: 'ap-facts' }, h('dt', { text: 'To' }), h('dd', { text: o.label })),
      h('label', { class: 'ap-field' }, h('span', { text: 'Subject' }), subject),
      h('label', { class: 'ap-field' }, h('span', { text: 'Message' }), text, h('span', { class: 'ap-help', text: 'Sent by email · Replies come to you' })),
      err
    ];
    let close;
    if (sp) {
      const sendBtn = A.btn('Send', { primary: true, write: true, onClick: () => send(sendBtn) });
      sp.open({ title: 'Message', body, foot: [sendBtn] });
      close = () => sp.close();
    } else {
      // A committee's page has no list beside it: the composer opens in the side column's place.
      const holder = ctx.body.querySelector('[data-compose]') || ctx.body;
      const box = h('section', { class: 'ap-section ap-mine', 'aria-label': 'Message' }, h('h2', { class: 'ap-h2' }, 'Message', h('span', { class: 'ap-h2__act' }, A.btn('Close', { ghost: true, onClick: () => close() }))), body);
      const sendBtn = A.btn('Send', { primary: true, write: true, onClick: () => send(sendBtn) });
      box.appendChild(sendBtn);
      const old = holder.querySelector('.ap-compose');
      if (old) old.remove();
      box.classList.add('ap-compose');
      holder.prepend(box);
      box.scrollIntoView({ block: 'nearest' });
      subject.focus();
      close = () => box.remove();
    }
  }
  A.message = message;

  /* ------------------------------------------------------------ a committee's page: the year as a line */

  /*
   * Round 2 (Oct 16; docs/27 README 3 and 12, area-committees 7–13): "Check this page" and last year's
   * notes, then The year: one line with Today marked. The committee's Work rows, its dated tasks and For
   * next year sit on it by their own days; everything above Today is open now, and the committee's first
   * need is the one filled button, on its row. Screens not open yet fold into one line with their date.
   * The side column holds the reference: People, Contacts, Responsibilities, Works with, Runs, Past
   * years. Four versions: the COA's (‹ › and See as), the committee's own, another committee's (short),
   * and a past year (read only).
   */
  function page(ctx0, key, own) {
    ctx0.body.appendChild(h('div', { class: 'ap-quiet', role: 'status', text: 'Loading' }));
    // The hand-down (committee-handdown.js) only for a committee the viewer is on (or the COA): anyone
    // else's would answer 404.
    const v0 = ctx0.boot.viewer;
    const pastY = +ctx0.params.past || 0;
    const on = v0.coa || (v0.committees || []).some(x => x.key === key);
    // Everything the page draws comes with it, so nothing below jumps when it arrives (Round 1).
    const now = on && !pastY;
    Promise.all([ctx0.api('GET', 'committee?c=' + encodeURIComponent(key)), A.hd && on ? A.hd.load(ctx0, key, pastY) : Promise.resolve(null),
      now && key !== 'coa' && !v0.as ? ctx0.api('GET', 'weekly?c=' + encodeURIComponent(key)).catch(() => null) : Promise.resolve(null),
      now && key === 'coa' && v0.coa ? ctx0.api('GET', 'handing').catch(() => null) : Promise.resolve(null)]).then(([c, hd, weekly, handing]) => {
      A.clear(ctx0.body);
      // The page in a split, so Message, the weekly email's preview and Who runs what's panel open beside it.
      const sp = ctx0.split();
      const inner = h('div', { class: 'cx-page yl', 'data-version': c.version || c.access });
      sp.main.appendChild(inner);
      const ctx = Object.assign({}, ctx0, { body: inner, sp, hd: c.access === 'full' ? hd : null, pre: { weekly, handing } });
      if (ctx.params.past) return past(ctx, c, +ctx.params.past);
      // Add people, in place on the page with this committee ticked (Round 6b; area-people-access 6):
      // s=committees&c=<key>&id=new (&at=head ticks Head). After Add the page's People redraws.
      if (ctx0.boot.viewer.coa && key !== 'coa' && A.people) {
        ctx.addHere = head => {
          A.setParams({ id: 'new' });
          A.people.add(sp, { c: key, head: !!head, onClose: () => A.setParams({ id: '' }), onDone: r => {
            const ids = (r.added || []).concat(r.merged || []);
            A.refreshBoot().then(() => { if (ids.length === 1) A.go({ id: 'person:' + ids[0] }, { replace: true }); else A.go({ id: '' }, { replace: true }); });
          } });
        };
      }
      const v = ctx.boot.viewer;
      // The COA's own page is the COA's root: no crumb, as a committee's own page has none.
      const root = own || (key === 'coa' && v.coa);
      const crumb = root ? null : { label: 'Committees', to: { s: 'committees', c: '', v: '' } };
      const acts = [];
      // ‹ › to the previous and next committee in the board's order, keeping the screen (the COA).
      if (c.version === 'coa' && c.step) {
        const st = c.step;
        acts.push(h('span', { class: 'yl-step' },
          st.prev ? A.link({ s: 'committees', c: st.prev.key, v: ctx.params.v || '' }, [A.icon('back', 14), st.prev.key === 'coa' ? 'COA' : st.prev.name], 'ap-btn') : null,
          st.next ? A.link({ s: 'committees', c: st.next.key, v: ctx.params.v || '' }, [st.next.name, A.icon('chev', 14)], 'ap-btn') : null));
      }
      // See as ▾ Head · Helper (README 2.6): the committee as each sees it, read only and logged.
      if (c.can.see_as) {
        const sb = A.btn('See as', { icon: 'eye', title: 'See the app as ' + c.name + ' sees it · Read only', onClick: () => key === 'coa'
          ? A.go({ as: key, s: 'committees', c: key, team: '' })
          : A.menu(sb, [{ label: 'Head', hint: c.name + '’s head', run: () => A.go({ as: key, 'as-role': '', s: 'committees', c: key, team: '' }) },
            { label: 'Helper', hint: 'On ' + c.name + ', not its head', run: () => A.go({ as: key, 'as-role': 'helper', s: 'committees', c: key, team: '' }) }]) });
        if (key !== 'coa') { sb.appendChild(A.icon('down', 14)); sb.setAttribute('aria-haspopup', 'menu'); }
        acts.push(sb);
      }
      if (c.access === 'full' && ctx.hd && A.hd.exportBtn) { const ex = A.hd.exportBtn(ctx, c, ctx.hd, key); if (ex) acts.push(ex); }
      const msg = c.people && c.people.filter(pp => !pp.you).length && c.can.message;
      if (msg) acts.push(A.btn('Message', { primary: c.access === 'directory', icon: 'mail', write: true, onClick: () => message(ctx, { to: 'committee:' + key, label: c.name }) }));
      else if (c.access === 'directory' && !c.people.length && c.can.message) acts.push(A.btn('Message the COA', { icon: 'mail', write: true, onClick: () => message(ctx, { to: 'committee:coa', label: 'the COA', subject: 'About ' + c.name }) }));
      const fact = () => {
        if (c.access === 'structure') return A.fmt.plural(c.people_count, 'person', 'people');
        if (c.access !== 'full') return A.fmt.plural(c.people.length, 'person', 'people');
        const f = c.fact || {};
        if (!f.words) return '';
        // The fact is a door to the work it counts.
        const cls = f.tone === 'late' ? 'yl-late' : f.source === 'need' || f.source === 'nobody' ? 'yl-need' : '';
        return f.go ? A.link(f.go, f.words, cls) : h('span', { class: cls, text: f.words });
      };
      ctx.head(c.name, fact(), acts, { crumb });
      ctx.redrawHead = () => ctx.head(c.name, fact(), acts, { crumb });
      if (c.access === 'structure') return structurePage(ctx, c);
      if (c.access === 'directory') return shortPage(ctx, c, key);
      yearPage(ctx, c, key, root);
      // A record named in the address opens beside the page: Add people (id=new), a person (id=person:<n>).
      const pid = String(ctx.params.id || '');
      if (pid === 'new' && ctx.addHere) ctx.addHere(ctx.params.at === 'head');
      else if (/^person:\d+$/.test(pid)) {
        const id = pid.slice(7);
        if (ctx.boot.viewer.coa && A.allowed('members')) openPerson(ctx, id, c);
        else A.people && A.people.card(sp, id, { onClose: () => A.setParams({ id: '' }) });
      }
    }).catch(err => { A.clear(ctx0.body).appendChild(A.empty({ title: err.status === 404 ? 'Not found' : 'Not loaded', line: 'Back to Committees', action: A.link({ s: 'committees', c: '' }, 'Committees', 'ap-btn') })); });
  }

  function structurePage(ctx, c) {
    ctx.body.appendChild(h('div', { class: 'yl-cols' },
      h('div', { class: 'yl-main' }, h('section', null, YL().lab('Responsibilities'), dutiesList(c.duties))),
      h('div', { class: 'yl-aside' }, h('section', null, YL().lab('Runs'), h('p', { class: 'yl-meta', text: (c.runs || []).length ? c.runs.join(' · ') : 'None' })))));
  }

  const YL = () => A.yl;
  const dutiesList = d => (d || '').trim() ? h('ul', { class: 'yl-resp' }, d.split('\n').filter(x => x.trim()).map(x => h('li', { text: x }))) : h('p', { class: 'yl-meta', text: 'None written' });

  // Another committee's page, short (area-committees 9): what it does, who's on it (each with Message),
  // the phone it gives out, and what passes between it and yours. No work, tasks or numbers.
  function shortPage(ctx, c, key) {
    const L = YL();
    const main = h('div', { class: 'yl-main' }), side = h('div', { class: 'yl-aside', 'data-compose': '' });
    if ((c.works_with || []).length) main.appendChild(h('section', { 'data-part': 'works' }, L.lab('Works with you'), worksWith(ctx, c.works_with, true)));
    main.appendChild(h('section', { 'data-part': 'duties' }, L.lab('Responsibilities'), dutiesList(c.duties)));
    side.appendChild(h('section', { 'data-part': 'people' }, L.lab('People', c.people.length || ''), c.people.length ? people(ctx, c.people, c) : h('p', { class: 'yl-meta', text: 'No one yet' })));
    if ((c.contacts || []).length) side.appendChild(h('section', { 'data-part': 'contacts' }, L.lab('Contacts', c.contacts.length), c.contacts.map(r => h('div', { class: 'yl-wk' }, h('div', { class: 'yl-wh', text: r.role }), h('div', { class: 'yl-meta' }, K().phone ? K().phone(r.phone) : r.phone)))));
    ctx.body.appendChild(h('div', { class: 'yl-cols' }, main, side));
  }
  const K = () => window.OGC_CK || {};

  // Works with: one line per hand-off (states only, never the other committee's numbers). The other
  // committee's name opens its page; the state opens your own screen for it, when you have one.
  function worksWith(ctx, list, you) {
    return h('div', null, list.map(w => {
      const state = w.state ? (w.go && A.allowed(w.go.s) ? A.link(Object.assign({ c: '', id: '', v: '' }, w.go), w.state) : h('span', { text: w.state })) : null;
      if (you) return h('div', { class: 'yl-wk', 'data-hand': String(w.n) }, h('div', { class: 'yl-wh', text: w.words }), h('div', { class: 'yl-meta' }, [w.what, state].filter(Boolean).reduce((a, x, i) => a.concat(i ? [' · ', x] : [x]), [])));
      const names = w.other.map((o, i) => [i ? (i === w.other.length - 1 ? ' and ' : ', ') : '', o.key && o.key !== ctx.params.c ? A.link({ s: 'committees', c: o.key, v: '', id: '' }, o.name) : o.name]);
      return h('div', { class: 'yl-wk', 'data-hand': String(w.n) }, h('div', { class: 'yl-wh' }, w.dir === 'gives' ? 'Gives to ' : 'Gets from ', names),
        h('div', { class: 'yl-meta' }, [w.what, state].filter(Boolean).reduce((a, x, i) => a.concat(i ? [' · ', x] : [x]), [])));
    }));
  }

  function yearPage(ctx, c, key, root) {
    const L = YL(), body = ctx.body, v = ctx.boot.viewer, hd = ctx.hd, p = ctx.params;
    const coaV = c.version === 'coa' && key !== 'coa';
    const today = c.today;
    // A change on the page (a task ticked, Looks right) reads the committee again; the page stays where it is.
    ctx.refresh = () => ctx.api('GET', 'committee?c=' + encodeURIComponent(key)).then(cc => { Object.assign(c, cc); if (ctx.redrawHead) ctx.redrawHead(); return cc; }).catch(() => null);

    /* ---------------- the check, above The year */
    const check = checkBanner(ctx, c, key, coaV);
    if (check) body.appendChild(check);

    const main = h('div', { class: 'yl-main' });
    const side = h('div', { class: 'yl-aside', 'data-compose': '' });
    body.appendChild(h('div', { class: 'yl-cols' }, main, side));

    // Last year's notes on top, each with Done and Keep for next year; last year's report under them.
    const nextNotes = { add: null, drop: null, setKept: null };
    if (hd) {
      const ln = A.hd.lastNotes(ctx, c, hd, key, { onKept: n => nextNotes.add && nextNotes.add(n), onUnkept: id => nextNotes.drop && nextNotes.drop(id), bind: f => { nextNotes.setKept = f; } });
      if (ln) main.appendChild(ln);
      const lr = A.hd.lastReport(ctx, c, hd, !!c.from);
      if (lr) main.appendChild(lr);
    }

    /* ---------------- The year */
    const sec = h('section', { 'aria-label': (key === 'coa' ? 'COA' : c.name) + '’s year', 'data-part': 'year' },
      L.lab('The year', '', c.tasks.length ? A.link({ s: 'tasks', c: key === 'coa' ? '' : key, id: '', v: '' }, 'All tasks', 'yl-r') : null));
    main.appendChild(sec);
    const canWrite = c.can.write && !A.readonly;
    const items = [].concat(
      (c.work || []).map(r => Object.assign({ kind: 'screen' }, r)),
      (c.line_tasks || []).map(t => Object.assign({ kind: 'task', on: t.due }, t)),
      (c.next || []).map(r => Object.assign({ kind: 'next' }, r)));
    const stages = L.stages(items, today);
    const folds = {};
    const line = h('div', { class: 'yl-line' });
    sec.appendChild(line);
    // No one on it: said first, with the one act that fills it (the COA adds the head).
    const nobody = c.fact && c.fact.source === 'nobody';
    if (nobody) {
      line.appendChild(L.stage({ key: 'now', when: h('span', { class: 'yl-need', text: 'Now' }), state: 'open', rows: [h('div', { class: 'yl-empty' }, A.icon('members'), h('b', { text: 'No one on it' }),
        v.coa ? (ctx.addHere ? L.fill('Add head', () => ctx.addHere(true), { icon: 'plus', write: true }) : L.fill('Add head', { s: 'committees', c: key, id: 'new', at: 'head' }, { icon: 'plus', write: true })) : null)] }));
    }
    const todayAt = (() => { let i = -1; stages.forEach((st, j) => { if (st.open) i = j; }); return i; })();
    if (todayAt < 0) line.appendChild(L.today(today));
    stages.forEach((st, j) => {
      const later = !st.open;
      const rows = [];
      const screens = st.items.filter(x => x.kind === 'screen');
      // Screens not open yet that open the same day fold into one line with their date.
      const waiting = later ? screens.filter(r => !r.need && !r.done && r.on && r.on > today) : [];
      const byDay = {};
      waiting.forEach(r => { (byDay[r.on] = byDay[r.on] || []).push(r); });
      const folded = new Set();
      screens.forEach(r => {
        const group = byDay[r.on];
        if (group && group.length > 1 && waiting.includes(r)) {
          if (group[0] === r) rows.push(L.listRow(group.map(g => ({ id: g.id, title: g.title, to: rowTo(ctx, g, key) })), 'Open ' + L.md(r.on)));
          folded.add(r.id);
          return;
        }
        rows.push(workRow(ctx, r, key, today, nobody));
      });
      st.items.filter(x => x.kind === 'task').sort((a, b) => (a.due || '') < (b.due || '') ? -1 : 1).forEach(t => rows.push(L.task(ctx, t, { canWrite })));
      st.items.filter(x => x.kind === 'next').forEach(r => {
        const fold = h('div', { class: 'yl-fold', 'data-fold': r.id, hidden: true });
        folds[r.id] = { el: fold, r, drawn: false };
        rows.push(L.nextRow({ id: r.id, icon: { notes: 'note', report: 'report', how: 'file', files: 'file', folder: 'link' }[r.id], title: r.title, fact: r.line,
          act: r.act ? L.at(r.act, () => openFold(r.id, true)) : null }), fold);
      });
      line.appendChild(L.stage({ key: st.key, start: st.start, when: st.when, state: st.done ? 'done' : later ? 'later' : 'open', dated: false, last: j === stages.length - 1 && todayAt !== j, rows }));
      if (j === todayAt) line.appendChild(L.today(today));
    });

    // For next year's folds: each part as it's built (the hand-down's), opened in place (at=notes…).
    const build = id => {
      if (id === 'notes') return notesSection(ctx, c, key, nextNotes);
      if (id === 'report') return hd ? A.hd.report(ctx, c, hd, key) : reportSection(ctx, c, key);
      if (id === 'how') return hd ? A.hd.how(ctx, c, hd, key) : h('p', { class: 'yl-meta', text: 'Not written' });
      if (id === 'files') return hd ? A.hd.files(ctx, c, hd, key, upload) : fileSection(ctx, c, key);
      if (id === 'folder') return linkSection(ctx, c, key);
      return null;
    };
    // The notes for next year are drawn at once (hidden), so a note kept from last year joins them.
    if (folds.notes) { folds.notes.el.appendChild(build('notes')); folds.notes.drawn = true; }
    function openFold(id, toggle) {
      const f = folds[id];
      if (!f) return;
      if (!f.drawn) { const n = build(id); if (n) f.el.appendChild(n); f.drawn = true; }
      f.el.hidden = toggle ? !f.el.hidden : false;
      if (!f.el.hidden) {
        const ta = id === 'notes' ? f.el.querySelector('textarea') : null;
        if (ta && toggle) ta.focus();
      }
    }

    /* ---------------- Who runs what (the COA's own page) */
    if (key === 'coa' && v.coa) main.appendChild(whoRunsWhat(ctx, c));

    /* ---------------- the side column */
    side.appendChild(peopleSection(ctx, c, key));
    if (hd) { const ct = A.hd.contacts(ctx, c, hd, key); if (ct) { ct.dataset.part = 'contacts'; side.appendChild(ct); } }
    side.appendChild(dutiesSection(ctx, c, key));
    if ((c.works_with || []).length) side.appendChild(h('section', { 'data-part': 'works' }, L.lab('Works with'), worksWith(ctx, c.works_with, false)));
    if (coaV && (c.runs || []).length) side.appendChild(h('section', { 'data-part': 'runs' }, L.lab('Runs', '', A.link({ s: 'committees', c: 'coa', at: 'who', v: '', id: '' }, 'Change', 'yl-r')), h('p', { class: 'yl-meta', text: c.runs.map(r => r.title).join(' · ') })));
    if (c.past.length) side.appendChild(h('section', { 'data-part': 'past' }, L.lab('Past years'), h('div', null, c.past.map(py => A.link({ past: py }, String(py), 'yl-pill')))));
    if (key !== 'coa' && c.can.write) side.appendChild(weeklySection(ctx, c, key));

    // A part named in the address opens and comes into view (at=notes, report, how, files, folder, who…).
    const at = p.at;
    if (at) setTimeout(() => {
      if (folds[at]) openFold(at, false);
      const el = body.querySelector('[data-fold="' + at + '"]') || body.querySelector('[data-part="' + at + '"]') || (at === 'last' ? body.querySelector('#ap-report, [aria-label$="report"]') : null);
      if (el) { const row = el.previousElementSibling && el.matches('[data-fold]') ? el.previousElementSibling : el; row.scrollIntoView({ block: 'start' }); window.scrollBy(0, -70); }
    }, 0);
  }

  // A shared screen opens filtered to this committee ("Lodging / Requests"); its own screens as they are.
  function rowTo(ctx, r, key) {
    return { s: r.id, c: r.c || '', id: '', v: '', past: '', at: '', team: ctx.boot.viewer.coa || key === 'coa' ? '' : key };
  }

  // A Work row (area-committees 2.3): the screen's line; before its season "Opens Feb 25"; when it needs
  // something, the need in tan with its act, the committee's first need filled.
  function workRow(ctx, r, key, today, nobody) {
    const L = YL();
    const notYet = r.on && r.on > today && !r.done;
    // With no one on it, Add head is the page's one filled button.
    if (nobody && r.need) r.need.top = false;
    const n = r.need && !notYet ? r.need : null;
    const words = r.done ? r.line : notYet ? ['Opens ' + L.md(r.on), r.line].filter(Boolean).join(' · ') : r.line || (n ? n.words : '');
    const fact = n && n.tone === 'late' && !/Late/.test(words) ? [words, ' ', A.tag('Late', 'late')] : words;
    let act = null;
    if (n && n.button) act = n.top ? L.fill(n.button, n.go, { sm: true }) : L.at(n.button, n.go);
    return L.row({ id: r.id, icon: A.iconFor(r.id), title: r.title, to: rowTo(ctx, r, key), fact, factNeed: !!n, tag: r.handed || '', act, done: r.done, big: !!(n && n.top) });
  }

  // The check above The year. The COA's: the responsibilities and tasks (decision 1), worded by where
  // they came from. The committee's own (its head): the page. On the COA's own page, one check is both.
  function checkBanner(ctx, c, key, coaV) {
    const v = ctx.boot.viewer, L = YL();
    let words = '', send = null, undo = null;
    if (coaV && !c.duties_checked) {
      words = [c.source === 'carried' ? 'From ' + c.from_year : 'Written for ' + ctx.boot.year, 'Check responsibilities and tasks'];
      send = { duties_checked: true }; undo = { duties_checked: false };
    } else if (!coaV && !c.head_checked && (key === 'coa' ? v.coa : v.head) && (c.can.write || A.readonly)) {
      words = [c.source === 'carried' ? 'From ' + c.from_year : '', 'Check this page'];
      send = { checked: true };
    }
    if (!send) return null;
    const box = h('div', { class: 'yl-check', role: 'note', 'data-part': 'check' });
    const btn = h('button', { type: 'button', class: 'yl-ob', disabled: A.readonly, title: A.readonly ? 'Read only while seeing as' : null, text: 'Looks right' });
    btn.addEventListener('click', () => {
      btn.disabled = true;
      ctx.api('PATCH', 'committee?c=' + encodeURIComponent(key) + '&v=' + encodeURIComponent(ctx.params.v || ''), send).then(cc => {
        A.toast('Checked · ' + (key === 'coa' ? 'COA' : c.name), undo ? { undo: () => ctx.api('PATCH', 'committee?c=' + encodeURIComponent(key), undo).then(() => A.reload()).catch(A.fail) } : null);
        // From Not checked, the next committee to check is one step on (J2); the last says so.
        if (coaV && ctx.params.v === 'from') {
          const nx = cc && cc.next_unchecked;
          A.clear(box).append(h('span', { text: 'Checked' }), h('span', { class: 'yl-meta', 'aria-hidden': 'true', text: '·' }),
            nx ? A.link({ s: 'committees', c: nx.key, v: 'from' }, 'Next: ' + nx.name + ' ›', 'yl-at') : A.link({ s: 'home' }, 'All checked · Home', 'yl-at'));
        } else box.remove();
        if (cc) { Object.assign(c, cc); if (ctx.redrawHead) ctx.redrawHead(); }
      }).catch(e => { btn.disabled = false; A.fail(e); });
    });
    box.append(...words.filter(Boolean).map((w, i, all) => i < all.length - 1 ? [h('span', { class: 'yl-meta', text: w }), h('span', { class: 'yl-meta', 'aria-hidden': 'true', text: '·' })] : h('b', { text: w })).flat(), btn);
    return box;
  }

  function peopleSection(ctx, c, key) {
    const L = YL(), v = ctx.boot.viewer;
    let right = null;
    if (v.coa && key !== 'coa' && ctx.addHere) right = h('button', { type: 'button', class: 'yl-r', disabled: A.readonly, title: A.readonly ? 'Read only while seeing as' : 'Add people to ' + c.name, text: 'Add people', on: { click: () => ctx.addHere(false) } });
    else if (!v.coa && c.version === 'own') right = h('button', { type: 'button', class: 'yl-r', disabled: A.readonly, title: A.readonly ? 'Read only while seeing as' : 'Ask the COA to add someone', text: 'Ask the COA',
      on: { click: () => A.people ? A.people.ask(ctx.sp, { c: key, onDone: () => drawAsks() }) : message(ctx, { to: 'committee:coa', label: 'the COA', subject: 'Add people · ' + c.name }) } });
    const sec = h('section', { 'data-part': 'people' }, L.lab('People', c.people.length || '', right));
    if (c.people.length) sec.appendChild(people(ctx, c.people, c));
    else sec.appendChild(h('p', { class: 'yl-meta', text: 'No one yet' }));
    // The committee's own asks to add someone: "Ruth K. · Asked Oct 14", then Added or Not added (P20).
    const asks = h('div', { class: 'pp-myasks' });
    sec.appendChild(asks);
    const drawAsks = () => {
      if (v.coa || c.version !== 'own') return;
      ctx.api('GET', '/years/' + ctx.boot.year + '/members/asks?c=' + encodeURIComponent(key)).then(r => {
        A.clear(asks);
        (r.asks || []).forEach(a => asks.appendChild(h('p', { class: 'yl-meta pp-myask', 'data-ask': a.id }, a.name + ' · ' + (a.status === 'added' ? 'Added ' + A.fmt.md(a.done) : a.status === 'dismissed' ? 'Not added' : a.status === 'lapsed' ? 'Not answered' : 'Asked ' + A.fmt.md(a.at)))));
      }).catch(() => {});
    };
    drawAsks();
    return sec;
  }

  // Responsibilities: the COA writes them once; they carry to next year.
  function dutiesSection(ctx, c, key) {
    const L = YL();
    const sec = h('section', { 'data-part': 'duties', 'aria-labelledby': 'ap-h-duties' });
    const draw = () => {
      A.clear(sec);
      sec.appendChild(L.lab('Responsibilities', '', c.can.edit ? h('button', { type: 'button', class: 'yl-r', id: 'ap-h-duties-edit', text: 'Edit', on: { click: edit } }) : null));
      sec.firstChild.firstChild.id = 'ap-h-duties';
      sec.appendChild(dutiesList(c.duties));
    };
    const edit = () => {
      A.clear(sec);
      const ta = h('textarea', { class: 'ap-textarea', rows: '6', value: c.duties || '' });
      // The name waits for lasting committee IDs (area-committees C0): a rename today makes a second committee.
      sec.append(L.lab('Responsibilities'),
        h('label', { class: 'ap-field' }, h('span', { class: 'ap-sr', text: 'Responsibilities' }), ta, h('span', { class: 'ap-help', text: 'One a line · Kept for next year' })),
        h('div', { class: 'ap-row' }, A.btn('Save', { primary: true, write: true, onClick: () => ctx.api('PATCH', 'committee?c=' + encodeURIComponent(key), { duties: ta.value }).then(r => { c.duties = r.duties; A.toast('Saved · ' + (key === 'coa' ? 'COA' : r.name)); draw(); }).catch(A.fail) }),
          A.btn('Cancel', { ghost: true, onClick: draw })));
      ta.focus();
    };
    draw();
    return sec;
  }

  /* ------------------------------------------------------------ Who runs what (the COA's own page) */

  // One row per screen the COA may hand, who runs it now and who ran it last year (a suggestion, never a
  // fact), Same as last year with Undo; a row opens its Run by panel (area-committees 12.2–12.3).
  function whoRunsWhat(ctx, c) {
    const L = YL(), sec = h('section', { 'data-part': 'who', 'aria-label': 'Who runs what' });
    const nameOf = k => !k ? 'COA' : ((A.committee(k) || {}).name || k);
    const again = () => ctx.api('GET', 'handing').then(d => { ctx.pre.handing = d; return A.refreshBoot(); }).then(draw).catch(A.fail);
    const send = (screen, to, confirm) => ctx.api('POST', 'hand', Object.assign({ screen, c: to }, confirm ? { confirm: true } : {}));
    function draw() {
      const d = ctx.pre.handing;
      A.clear(sec);
      if (!d) { sec.appendChild(L.lab('Who runs what')); sec.appendChild(h('p', { class: 'yl-meta', text: 'Not loaded' })); return; }
      const rows = d.rows || [], prev = d.prev;
      const diff = rows.filter(r => r.differs);
      const same = prev && diff.length ? h('button', { type: 'button', class: 'yl-ob', disabled: A.readonly, title: A.readonly ? 'Read only while seeing as' : 'Hands each screen as ' + prev + ' did', text: 'Same as ' + prev + ' · ' + diff.length, on: { click: () => sameAs(false) } }) : null;
      sec.appendChild(L.lab('Who runs what', '', same));
      const t = h('table', { class: 'yl-who' }, h('thead', null, h('tr', null, h('th', { scope: 'col', text: 'Screen' }), h('th', { scope: 'col', text: 'Run by' }), prev ? h('th', { scope: 'col', text: String(prev) }) : null, h('th', { scope: 'col' }, h('span', { class: 'ap-sr', text: 'Open' })))),
        h('tbody', null, rows.map(r => {
          const tr = h('tr', { class: 'is-row', tabindex: '0', 'data-screen': r.id, 'aria-label': r.title + ' · Run by ' + r.to_name },
            h('td', null, A.allowed(r.id) ? A.link({ s: r.id, c: '', id: '', v: '', at: '' }, r.title) : h('b', { text: r.title })),
            h('td', { class: r.to ? '' : 'yl-meta', text: r.to_name }),
            prev ? h('td', { class: r.differs ? 'is-diff' : 'yl-meta', title: r.differs ? 'Not the same as this year' : null, text: r.last ? r.last.name + (r.last.here ? '' : ' · Not in ' + ctx.boot.year) : '' }) : null,
            h('td', null, A.icon('chev', 14)));
          const open = () => runBy(r);
          tr.addEventListener('click', e => { if (!e.target.closest('a')) open(); });
          tr.addEventListener('keydown', e => { if (e.key === 'Enter') open(); });
          return tr;
        })));
      sec.appendChild(t);
    }
    // Same as last year: one act, Undo puts each back. Households asks first, in the panel.
    function sameAs(confirm) {
      ctx.api('POST', 'handing/same', confirm ? { confirm: true } : {}).then(r => {
        const ch = r.changed || [];
        if (ctx.sp) ctx.sp.close(true);
        A.toast(ch.length ? 'Handed · ' + ch.map(x => x.title + ' · ' + x.to_name).join(' · ') : 'Nothing to hand', ch.length ? { undo: () => Promise.all(ch.map(x => send(x.id, x.from, true))).then(again).catch(A.fail) } : null);
        again();
      }).catch(e => {
        if (e && e.data && e.data.code === 'ogc_hand_people' || (e && e.status === 409)) {
          const rows = (e.data && e.data.data && e.data.data.rows) || [];
          ctx.sp.open({ title: 'Same as ' + ctx.pre.handing.prev, body: [h('ul', { class: 'yl-resp' }, rows.map(x => h('li', null, x.title + ' · ' + x.last.name, x.people ? h('div', { class: 'yl-need', text: x.people }) : null)))],
            foot: [A.btn('Hand ' + rows.length, { primary: true, write: true, onClick: () => sameAs(true) })] });
          return;
        }
        A.fail(e);
      });
    }
    // The Run by panel: who runs it (pills), last year's, what handing grants, the tasks that move with it.
    function runBy(r) {
      let pick = r.to;
      const pills = h('div', { class: 'ap-pills', role: 'group', 'aria-label': 'Run by' }, [''].concat(ctx.boot.committees.filter(x => x.key !== 'coa').map(x => x.key)).map(k => h('button', {
        type: 'button', class: 'ap-pill', 'aria-pressed': String(k === pick), on: { click: e => { pick = k; pills.querySelectorAll('.ap-pill').forEach(b => b.setAttribute('aria-pressed', String(b === e.currentTarget))); hand.disabled = A.readonly || pick === r.to; } }
      }, nameOf(k))));
      const hand = A.btn('Hand', { primary: true, write: true, onClick: () => {
        hand.disabled = true;
        send(r.id, pick, !!r.people).then(() => {
          const was = r.to;
          A.toast((pick ? 'Handed · ' + r.title + ' · ' + nameOf(pick) : 'Back with the COA · ' + r.title), { undo: () => send(r.id, was, true).then(again).catch(A.fail) });
          ctx.sp.close(true);
          again();
        }).catch(e => { hand.disabled = false; A.fail(e); });
      } });
      hand.disabled = true;
      ctx.sp.open({
        title: r.title,
        body: [
          h('div', { class: 'ap-field' }, h('span', { text: 'Run by' }), pills),
          r.last ? h('p', { class: 'yl-meta', text: ctx.pre.handing.prev + ' · ' + r.last.name }) : null,
          r.grants.length ? h('div', { class: 'ap-field' }, h('span', { text: 'Handing gives' }), h('ul', { class: 'yl-resp' }, r.grants.map(g => h('li', { text: g })))) : null,
          r.tasks.length ? h('div', { class: 'ap-field' }, h('span', { text: 'Its tasks go with it' }), h('ul', { class: 'yl-resp' }, r.tasks.map(t => h('li', null, A.link({ s: 'tasks', id: t.id, c: '', v: '' }, t.title), ' · ' + t.when)))) : null,
          r.people ? h('p', { class: 'yl-need', text: r.people }) : null
        ],
        foot: [hand, r.to ? A.btn('Take back', { write: true, onClick: () => send(r.id, '', true).then(() => { const was = r.to; A.toast('Back with the COA · ' + r.title, { undo: () => send(r.id, was, true).then(again).catch(A.fail) }); ctx.sp.close(true); again(); }).catch(A.fail) }) : null].filter(Boolean)
      });
    }
    draw();
    if (ctx.params.id && /^screen:/.test(ctx.params.id)) { const r = ((ctx.pre.handing || {}).rows || []).find(x => 'screen:' + x.id === ctx.params.id); if (r) setTimeout(() => runBy(r), 0); }
    return sec;
  }

  // A task done or not, with Undo. The page reads itself again (ctx.refresh), any other screen redraws.
  // A screen by its name (also one this viewer doesn't open), never its id.
  const screenTitle = (ctx, id) => (ctx.boot.screens.find(x => x.id === id) || {}).title || (typeof (A.screens()[id] || {}).title === 'string' ? A.screens()[id].title : id);

  // Done or not, with Undo; says what it did. The screen it's on stays: a committee's page redraws its
  // tasks (ctx.refresh), any other screen draws itself again where it was (A.reload).
  function toggleTask(ctx, t, box) {
    const want = box.checked;
    const again = () => { A.forgetTasks(); if (ctx.refresh) ctx.refresh(); else A.reload(); };
    ctx.api('PATCH', '/app/tasks/' + t.id, { done: want }).then(() => {
      A.toast((want ? 'Done · ' : 'Reopened · ') + t.title, { undo: () => ctx.api('PATCH', '/app/tasks/' + t.id, { done: !want }).then(again).catch(A.fail) });
      again();
    }).catch(e => { box.checked = !want; A.fail(e); });
  }
  A.toggleTask = toggleTask;

  function fileSection(ctx, c, key) {
    const sec = h('section', { class: 'ap-section', 'aria-labelledby': 'ap-h-files' });
    const input = h('input', { type: 'file', hidden: true, multiple: true });
    sec.appendChild(h('h2', { class: 'ap-h2', id: 'ap-h-files' }, 'Files', c.files.length ? h('span', { class: 'ap-h2__n', text: String(c.files.length) }) : null,
      c.can.write ? h('span', { class: 'ap-h2__act' }, A.btn('Upload', { icon: 'upload', write: true, onClick: () => input.click() })) : null));
    sec.appendChild(input);
    const nonce = (window.OGC_WP || {}).nonce || '';
    const base = ((window.OGC_WP || {}).app || {}).files || '/wp-json/ogc/v1/app/files/';
    if (c.files.length) {
      sec.appendChild(h('ul', { class: 'ap-list' }, c.files.map(f => h('li', null, h('div', { class: 'ap-item' }, A.icon('file'),
        h('span', { class: 'ap-item__main' },
          h('a', { class: 'ap-item__title', href: base + f.id + '?_wpnonce=' + encodeURIComponent(nonce) + (ctx.params.as ? '&as=' + encodeURIComponent(ctx.params.as) : ''), download: f.name, text: f.name }),
          h('span', { class: 'ap-item__why', text: [f.type, A.fmt.size(f.size), f.carried ? 'From last year' : f.on, f.by].filter(Boolean).join(' · ') })),
        c.can.write && !A.readonly ? h('button', { type: 'button', class: 'ap-link ap-link--quiet', text: 'Remove', 'aria-label': 'Remove ' + f.name, on: { click: () => ctx.api('DELETE', '/app/files/' + f.id).then(() => { A.toast('Removed ' + f.name); A.reload(); }).catch(A.fail) } }) : null)))));
    }
    if (c.can.write) {
      const drop = h('div', { class: 'ap-drop', text: c.files.length ? 'Drop files here' : 'Drop files here · Kept for this committee and the COA, and for next year’s committee' });
      ['dragenter', 'dragover'].forEach(ev => drop.addEventListener(ev, e => { e.preventDefault(); drop.classList.add('ap-drop--over'); }));
      ['dragleave', 'drop'].forEach(ev => drop.addEventListener(ev, () => drop.classList.remove('ap-drop--over')));
      drop.addEventListener('drop', e => { e.preventDefault(); upload(ctx, key, [...e.dataTransfer.files]); });
      sec.appendChild(drop);
    } else if (!c.files.length) {
      return h('span', { hidden: true });
    }
    input.addEventListener('change', () => upload(ctx, key, [...input.files]));
    return sec;
  }

  // done: what draws the files again (the hand-down's Files section); else the page is drawn again where
  // it is. Files uploaded before one that fails are kept and shown.
  async function upload(ctx, key, files, done) {
    const W = window.OGC_WP || {};
    let n = 0, said = '';
    for (const f of files.slice(0, 10)) {
      const fd = new FormData();
      fd.append('file', f, f.name);
      A.toast('Uploading ' + f.name);
      try {
        const res = await fetch((W.rest || '/wp-json/ogc/v1/') + 'app/' + ctx.boot.year + '/committee/files?c=' + encodeURIComponent(key), { method: 'POST', credentials: 'same-origin', headers: { 'X-WP-Nonce': W.nonce || '' }, body: fd });
        const d = await res.json().catch(() => null);
        if (!res.ok) { said = f.name + ' · ' + ((d && d.message) || 'Not uploaded'); break; }
        n++;
      } catch (e) { said = 'Not uploaded · Check the connection'; break; }
    }
    if (!n) { if (said) A.toast(said); return; }
    A.toast(said || (n === 1 ? 'Uploaded ' + files[0].name : 'Uploaded ' + n + ' files'));
    if (done) done(); else A.reload();
  }

  function notesSection(ctx, c, key, hooks) {
    const sec = h('section', { class: 'ap-section', 'aria-labelledby': 'ap-h-notes' });
    const next = ctx.boot.year + 1;
    // Notes kept from last year's (committee-handdown.js) say where they came from; one kept just now
    // joins the list without drawing the page again.
    const origin = Object.assign({}, (ctx.hd && ctx.hd.origin) || {});
    if (hooks) {
      hooks.add = n => { c.notes.push({ id: n.id, body: n.body, by: n.by, on: 'Today' }); if (n.origin) origin[n.id] = n.origin; draw(); };
      hooks.drop = id => { const i = c.notes.findIndex(x => x.id === id); if (i >= 0) c.notes.splice(i, 1); draw(); };
    }
    const meta = n => {
      const o = origin[n.id];
      return o ? 'From ' + o.year + (n.by ? ' · Kept by ' + n.by : '') : [n.by, n.on].filter(Boolean).join(' · ');
    };
    // Read the notes again (after Add or Undo), then draw only this section.
    const again = () => ctx.api('GET', 'committee?c=' + encodeURIComponent(key)).then(cc => { c.notes = cc.notes; draw(); }).catch(() => A.reload());
    const removeNote = n => ctx.api('DELETE', '/app/notes/' + n.id).then(r => {
      const i = c.notes.indexOf(n);
      if (i >= 0) c.notes.splice(i, 1);
      const o = origin[n.id];
      // A kept copy removed: last year's note offers Keep again.
      if (o && hooks && hooks.setKept) hooks.setKept(o.src, false);
      draw();
      A.toast('Note removed', { undo: () => (o
        ? ctx.api('POST', 'handdown/keep?c=' + encodeURIComponent(key), { id: o.src }).then(k => { if (hooks && hooks.add) hooks.add({ id: k.copy, body: n.body, by: k.by, origin: k.origin }); if (hooks && hooks.setKept) hooks.setKept(o.src, true); })
        : ctx.api('POST', 'committee/notes?c=' + encodeURIComponent(key), { body: r.body }).then(again)).catch(A.fail) });
    }).catch(A.fail);
    const draw = () => {
      A.clear(sec);
      sec.hidden = false;
      sec.appendChild(h('h2', { class: 'ap-h2', id: 'ap-h-notes' }, 'Notes for ' + next, c.notes.length ? h('span', { class: 'ap-h2__n', text: String(c.notes.length) }) : null));
      sec.appendChild(h('p', { class: 'ap-help', style: { margin: '-4px 0 8px' }, text: 'Next year’s committee reads these first' }));
      c.notes.forEach(n => sec.appendChild(h('div', { class: 'ap-note' }, h('div', { class: 'ap-pre', text: n.body }), h('div', { class: 'ap-note__meta' }, h('span', { text: meta(n) }),
        c.can.write && n.id ? h('button', { type: 'button', class: 'ap-link ap-link--quiet', text: 'Remove', on: { click: () => removeNote(n) } }) : null))));
      if (c.can.write) {
        const ta = h('textarea', { class: 'ap-textarea', rows: '3', maxlength: '2000', 'aria-label': 'Add note for ' + next, placeholder: 'Note for next year’s ' + (key === 'coa' ? 'COA' : c.name) });
        const add = A.btn('Add note', { write: true, onClick: () => {
          if (!ta.value.trim()) { ta.focus(); return; }
          ctx.api('POST', 'committee/notes?c=' + encodeURIComponent(key), { body: ta.value }).then(() => { A.toast('Note added for ' + next); again(); }).catch(A.fail);
        } });
        sec.appendChild(h('div', { class: 'ap-field', style: { marginTop: '10px' } }, ta, h('div', { class: 'ap-row' }, add)));
      } else if (!c.notes.length) {
        sec.hidden = true;
      }
    };
    draw();
    return sec;
  }

  function linkSection(ctx, c, key) {
    const sec = h('section', { class: 'ap-section', 'aria-labelledby': 'ap-h-link' });
    const draw = () => {
      A.clear(sec);
      sec.appendChild(h('h2', { class: 'ap-h2', id: 'ap-h-link', title: 'The committee’s own working folder, if it keeps one · Pasted once, kept for next year' }, 'Folder',
        c.can.write ? h('span', { class: 'ap-h2__act' }, h('button', { type: 'button', class: 'ap-link', text: c.link ? 'Change' : 'Add link', on: { click: edit } })) : null));
      if (c.link) sec.appendChild(h('a', { class: 'ap-link', href: c.link, rel: 'noopener noreferrer', target: '_blank' }, A.icon('link'), ' ', c.link.replace(/^https:\/\//, '').slice(0, 48)));
      else sec.appendChild(h('p', { class: 'ap-quiet', text: 'None · Optional' }));
    };
    const edit = () => {
      A.clear(sec);
      const inp = h('input', { class: 'ap-input', type: 'url', value: c.link || '', placeholder: 'https://', 'aria-label': 'Folder link' });
      const err = h('div', { class: 'ap-err', role: 'alert' });
      sec.append(h('h2', { class: 'ap-h2', text: 'Folder' }), h('div', { class: 'ap-field' }, inp, err),
        h('div', { class: 'ap-row' }, A.btn('Save', { primary: true, write: true, onClick: () => ctx.api('PATCH', 'committee?c=' + encodeURIComponent(key), { link: inp.value.trim() }).then(r => { c.link = r.link; A.toast(r.link ? 'Link saved' : 'Link removed'); draw(); }).catch(e => { err.textContent = (e.data && e.data.message) || 'Not saved'; }) }),
          A.btn('Cancel', { ghost: true, onClick: draw })));
      inp.focus();
    };
    draw();
    return sec;
  }

  // The weekly note: Mondays, to everyone on the committee, while something needs them. The COA turns it off.
  // Drawn with the page from what it fetched alongside (ctx.pre.weekly); not drawn when that didn't load.
  function weeklySection(ctx, c, key) {
    const sec = h('section', { class: 'ap-section', 'aria-labelledby': 'ap-h-weekly' });
    const coa = ctx.boot.viewer.coa && !A.readonly;
    const pre = ctx.pre && ctx.pre.weekly;
    if (ctx.pre && !pre) { sec.hidden = true; return sec; }
    (pre ? Promise.resolve(pre) : ctx.api('GET', 'weekly?c=' + encodeURIComponent(key))).then(w => {
      const draw = () => {
        A.clear(sec);
        sec.appendChild(h('h2', { class: 'ap-h2', id: 'ap-h-weekly' }, 'Weekly email', h('span', { class: 'ap-h2__n', text: w.on ? 'On' : 'Off' }),
          h('span', { class: 'ap-h2__act' }, w.items ? h('button', { type: 'button', class: 'ap-link', text: 'Preview', on: { click: () => preview(w) } }) : null)));
        sec.appendChild(h('p', { class: 'ap-help', text: w.on ? (w.items ? 'Mondays · ' + A.fmt.plural(w.items, 'item') : 'Mondays, when something needs ' + c.name) : 'Not sent' }));
        if (coa) sec.appendChild(h('button', { type: 'button', class: 'ap-link', text: w.on ? 'Turn off' : 'Turn on', on: { click: () => ctx.api('PUT', 'weekly?c=' + encodeURIComponent(key), { on: !w.on }).then(r => { w.on = r.on; A.toast('Weekly email ' + (r.on ? 'on' : 'off') + ' · ' + c.name); draw(); }).catch(A.fail) } }));
      };
      draw();
    }).catch(() => sec.remove());
    // The email as it would go this Monday, in a sandboxed frame (no scripts, no links followed).
    function preview(w) {
      const f = h('iframe', { title: 'Weekly email preview', sandbox: '', class: 'ap-mailframe' });
      f.srcdoc = w.html;
      if (ctx.sp) { ctx.sp.open({ title: w.subject, body: [h('p', { class: 'ap-help', text: 'As it goes this Monday, to everyone on ' + c.name }), f] }); return; }
      const box = h('section', { class: 'ap-section ap-mine ap-compose', 'aria-label': 'Weekly email' }, h('h2', { class: 'ap-h2' }, w.subject, h('span', { class: 'ap-h2__act' }, A.btn('Close', { ghost: true, onClick: () => box.remove() }))), f);
      (ctx.body.querySelector('[data-compose]') || ctx.body).prepend(box);
    }
    return sec;
  }

  function reportSection(ctx, c, key) {
    const sec = h('section', { class: 'ap-section', id: 'ap-report', 'aria-labelledby': 'ap-h-report' });
    const qs = ctx.boot.questions;
    const r = c.report || { answers: [] };
    sec.appendChild(h('h2', { class: 'ap-h2', id: 'ap-h-report', title: 'The COA’s questions, answered after the Conference · Next year’s committee sees it at the top' }, 'Report',
      h('span', { class: 'ap-h2__n', text: r.sent ? 'Sent ' + r.sent : r.updated ? 'Draft · Saved ' + r.updated : '' })));
    // Before the Conference the report waits; it's answered after (or written as things happen).
    if (!c.can.write) {
      if (!r.answers.some(Boolean)) sec.appendChild(A.empty({ title: 'Not written', line: 'Answered after the Conference' }));
      else qs.forEach((q, i) => r.answers[i] && sec.appendChild(h('div', { class: 'ap-q' }, h('span', { class: 'ap-q__ask', text: q }), h('p', { class: 'ap-q__said', text: r.answers[i] }))));
      return sec;
    }
    const after = c.phase === 'after';
    const boxes = qs.map((q, i) => h('textarea', { class: 'ap-textarea', rows: '3', maxlength: '6000', value: r.answers[i] || '' }));
    if (!after && !r.answers.some(Boolean)) {
      const show = A.btn('Start the report', { write: true, onClick: () => { wrap.hidden = false; show.remove(); boxes[0].focus(); } });
      sec.appendChild(h('p', { class: 'ap-quiet', text: 'Answered after the Conference' }));
      sec.appendChild(show);
    }
    const status = h('span', { class: 'ap-quiet', role: 'status' });
    let t = 0;
    const save = send => ctx.api('PUT', 'committee/report?c=' + encodeURIComponent(key), { answers: boxes.map(b => b.value), send: !!send }).then(res => {
      status.textContent = res.sent ? 'Sent ' + res.sent : 'Saved';
      if (send) { A.toast('Report sent to the COA'); A.reload(); }
    }).catch(A.fail);
    boxes.forEach(b => b.addEventListener('input', () => { status.textContent = 'Saving'; clearTimeout(t); t = setTimeout(() => save(false), 900); }));
    const wrap = h('div', { hidden: !after && !r.answers.some(Boolean) },
      qs.map((q, i) => h('label', { class: 'ap-field' }, h('span', { text: (i + 1) + '. ' + q }), boxes[i])),
      h('div', { class: 'ap-row' }, r.sent ? A.btn('Send again', { write: true, onClick: () => save(true) }) : A.btn('Send to the COA', { primary: after, write: true, onClick: () => save(true) }), status));
    sec.appendChild(wrap);
    return sec;
  }

  /* ------------------------------------------------------------ a past year, read only, no people */

  function past(ctx, now, py) {
    const key = now.key;
    ctx.api('GET', 'committee/past?c=' + encodeURIComponent(key) + '&from=' + py).then(d => {
      const body = ctx.body;
      // Read only and the way back, said once (the title row); the banner only says who was on it.
      // The way up is the committee's own page (area-shell 3.2), the same for its people and the COA.
      ctx.head(now.name + ' · ' + py, 'Read only', [A.link({ past: '' }, 'Back to ' + ctx.boot.year, 'ap-btn')], { crumb: { label: now.name, to: { s: 'committees', c: key, past: '' } } });
      if (d.people) body.appendChild(h('div', { class: 'ap-banner', role: 'note' }, h('span', { text: A.fmt.plural(d.people, 'person was', 'people were') + ' on it in ' + py })));
      const main = h('div'), sideCol = h('div');
      main.appendChild(h('section', { class: 'ap-section' }, h('h2', { class: 'ap-h2', text: 'Responsibilities' }), h('p', { class: 'ap-pre ap-muted', text: d.duties || '' })));
      // That year's own hand-down (committee-handdown.js), read only and without names.
      const hd = ctx.hd && ctx.hd.year === py ? ctx.hd : null;
      if (hd && hd.how.text) main.appendChild(h('section', { class: 'ap-section' }, h('h2', { class: 'ap-h2', text: 'How we work' }), h('p', { class: 'ap-pre ap-muted', text: hd.how.text })));
      if (d.report || (hd && hd.numbers.rows.length)) {
        main.appendChild(h('section', { class: 'ap-section' }, h('h2', { class: 'ap-h2' }, 'Report', h('span', { class: 'ap-h2__n', text: d.report && d.report.sent ? 'Sent ' + d.report.sent : 'Draft' })),
          // Under the questions as they were asked that year (kept with the report), not as they read now.
          d.report ? d.report.answers.map((a, i) => a ? h('div', { class: 'ap-q' }, h('span', { class: 'ap-q__ask', text: ((hd && hd.questions && hd.questions.length ? hd.questions : ctx.boot.questions)[i]) || 'Question ' + (i + 1) }), h('p', { class: 'ap-q__said', text: a })) : null) : null,
          hd && hd.numbers.rows.length ? [h('h3', { class: 'hd-h3', text: 'Numbers' }), h('table', { class: 'hd-numtable' }, h('tbody', null, hd.numbers.rows.filter(x => x.n !== '').map(x => h('tr', null, h('td', { text: x.what }), h('td', { class: 'hd-num', text: Number(x.n).toLocaleString('en-US') })))))] : null));
      }
      main.appendChild(h('section', { class: 'ap-section' }, h('h2', { class: 'ap-h2' }, 'Tasks', h('span', { class: 'ap-h2__n', text: d.tasks.filter(t => t.done).length + ' of ' + d.tasks.length })),
        d.tasks.length ? h('ul', { class: 'ap-list' }, d.tasks.map(t => h('li', null, h('div', { class: 'ap-item' }, h('span', { class: 'ap-item__main' }, h('span', { class: 'ap-item__title', text: t.title }), t.done ? h('span', { class: 'ap-item__why', text: 'Done ' + t.done_on }) : h('span', { class: 'ap-item__why', text: 'Not done' })), h('span', { class: 'ap-item__side', text: t.when }))))) : A.empty({ title: 'No tasks' })));
      if (hd && hd.contacts.rows.length) sideCol.appendChild(h('section', { class: 'ap-section' }, h('h2', { class: 'ap-h2' }, 'Contacts', h('span', { class: 'ap-h2__n', text: String(hd.contacts.rows.length) })),
        h('ul', { class: 'hd-contacts' }, hd.contacts.rows.map(r => h('li', null, h('div', { class: 'hd-contact' }, h('span', { class: 'hd-contact__role', text: r.role }),
          r.phone || r.email ? h('span', { class: 'hd-contact__how', text: [r.phone, r.email].filter(Boolean).join(' · ') }) : null, r.note ? h('span', { class: 'hd-contact__note', text: r.note }) : null))))));
      sideCol.appendChild(h('section', { class: 'ap-section' }, h('h2', { class: 'ap-h2' }, 'Notes', h('span', { class: 'ap-h2__n', text: String(d.notes.length) })),
        d.notes.length ? d.notes.map(n => h('div', { class: 'ap-note' }, h('div', { class: 'ap-pre', text: n.body }), h('div', { class: 'ap-note__meta', text: n.on }))) : A.empty({ title: 'No notes' })));
      if (d.files.length) sideCol.appendChild(h('section', { class: 'ap-section' }, h('h2', { class: 'ap-h2', text: 'Files' }), h('ul', { class: 'ap-list' }, d.files.map(f => h('li', null, h('div', { class: 'ap-item' }, A.icon('file'), h('span', { class: 'ap-item__main' }, h('span', { class: 'ap-item__title', text: f.name }), h('span', { class: 'ap-item__why', text: [f.type, A.fmt.size(f.size), f.on].filter(Boolean).join(' · ') }))))))));
      body.appendChild(h('div', { class: 'ap-cols' }, main, sideCol));
    }).catch(() => { A.clear(ctx.body).appendChild(A.empty({ title: 'Not found', action: A.link({ past: '' }, 'Back to ' + ctx.boot.year, 'ap-btn') })); });
  }

  /* ------------------------------------------------------------ boot again (names, screens) */

  function refreshBoot() {
    return A.api('GET', 'boot').then(b => { const cur = A.boot(); Object.assign(cur, b); });
  }
  A.refreshBoot = refreshBoot;

  /* ------------------------------------------------------------ the screens */

  A.screen({
    id: 'committees', title: 'Committees', icon: 'committees', section: 'main', who: ['all'],
    render(ctx) {
      const p = ctx.params;
      // Your own committee's page has one address, this one (s=committees&c=<yours>): no crumb, its own
      // sidebar item current (Round 1, after the critic). Anyone else's has the crumb to Committees.
      if (p.c) return page(ctx, p.c, A.ownPage(p.c));
      ctx.body.appendChild(h('div', { class: 'ap-quiet', role: 'status', text: 'Loading' }));
      ctx.api('GET', 'committees').then(d => {
        A.clear(ctx.body);
        ctx.body.classList.remove('ap-body--flush');
        if (d.view === 'board') board(ctx, d);
        else if (d.view === 'directory') directory(ctx, d);
        else structure(ctx, d);
      }).catch(() => { A.clear(ctx.body).appendChild(A.empty({ title: 'Not loaded', line: 'Reload the page' })); });
    }
  });

  A.screen({
    id: 'overview', title: b => ((b.committees || []).find(c => c.key === A.team()) || {}).name || 'Overview', icon: 'overview', section: 'own', who: ['committee'],
    render(ctx) {
      const key = ctx.params.c && ctx.boot.viewer.committees.some(c => c.key === ctx.params.c) ? ctx.params.c : A.team();
      if (!key) { ctx.body.appendChild(A.empty({ title: 'No committee' })); return; }
      page(ctx, key, true);
    }
  });

  A.action({ id: 'add-committee', title: 'Add committee', screen: 'committees', when: b => b.viewer.coa && !b.viewer.as, run: () => A.go({ s: 'committees', c: '', v: '' }) });
  A.action({ id: 'note', title: 'Add note for next year', when: b => b.viewer.committees.length > 0 && !b.viewer.as, run: () => { A.go({ s: 'overview', c: A.team() }); setTimeout(() => { const t = document.querySelector('[aria-label^="Add note"]'); if (t) t.focus(); }, 600); } });
})();
