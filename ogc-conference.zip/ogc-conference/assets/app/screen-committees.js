/*
 * Committees. The COA: the status board (every committee on one screen, where it stands in a few words,
 * tasks done, a mark when it needs a look; all written from data). A committee: the directory (their
 * own first, with everyone on it; then who is on each other committee and what it does, with Message).
 * A webmaster: the structure. Each opens to the committee's page (?c=): its people, responsibilities,
 * tasks, files, notes for next year, report, last year's notes and report, See as, and its past years
 * read-only (?past=2026; never past people). The viewer's own committee's page is this same address
 * (?c=<yours>, no crumb); "Overview" (s=overview) is its old name, rewritten by app.js.
 */
(function () {
  'use strict';
  const A = window.OGC_APP, h = A.h;

  /* ------------------------------------------------------------ the list */

  function board(ctx, d) {
    const p = ctx.params;
    const sp = ctx.split();
    const look = d.committees.filter(c => c.look && c.look.length);
    const fresh = d.committees.filter(c => c.from);
    const views = [{ id: '', label: 'All', n: d.committees.length }];
    if (look.length) views.push({ id: 'look', label: 'Needs a look', n: look.length });
    if (fresh.length) views.push({ id: 'from', label: 'Not checked', n: fresh.length });
    // What each committee was handed from last year and is leaving for next (committee-handdown.js).
    if (A.hd && ctx.boot.viewer.coa) views.push({ id: 'handdown', label: 'Hand-down' });
    const v = views.some(x => x.id === p.v) ? p.v : '';
    const rows = v === 'look' ? look : v === 'from' ? fresh : d.committees;
    // The chips carry the counts; with none to choose, the fact does.
    ctx.head('Committees', views.length > 1 ? '' : A.fmt.plural(d.committees.length, 'committee'),
      v === 'handdown' ? [A.hd.reportsBtn(ctx)] : [A.btn('Add committee', { icon: 'plus', write: true, onClick: () => addCommittee(ctx, sp) })]);
    sp.main.appendChild(h('div', { class: 'ap-views' }, A.views(views, v, id => A.go({ v: id }, { replace: true }))));
    if (v === 'handdown') { A.hd.board(ctx, sp); return; }
    sp.main.appendChild(A.table({
      label: 'Committees',
      rows, key: c => c.key,
      onOpen: c => A.go({ c: c.key, v: '' }),
      empty: A.empty({ title: v === 'look' ? 'None need a look' : 'All checked', inset: true }),
      cols: [
        { label: 'Committee', render: c => h('span', { class: 'ap-cell-title', text: c.name }) },
        // The committee's one most pressing true thing; its marks beside it.
        { label: 'Where it stands', cls: 'ap-td--muted', render: c => h('span', null, c.line || '', (c.look || []).length ? h('span', { class: 'ap-chips ap-chips--inline' }, c.look.map(l => A.tag(l, /late|No one/.test(l) ? 'late' : 'tan'))) : null) },
        { label: 'Head', cls: 'ap-td--nowrap', wide: true, render: c => c.key === 'coa' ? '' : c.head },
        { label: 'People', cls: 'ap-td--num', wide: true, render: c => c.people_count ? String(c.people_count) : '' }
      ]
    }));
  }

  function addCommittee(ctx, sp) {
    const name = h('input', { class: 'ap-input', 'data-autofocus': '', maxlength: '60', 'aria-describedby': 'ap-ac-help' });
    const duties = h('textarea', { class: 'ap-textarea', rows: '4' });
    const err = h('div', { class: 'ap-err', role: 'alert' });
    const save = () => {
      ctx.api('POST', 'committees', { name: name.value, duties: duties.value }).then(r => {
        A.toast('Added ' + r.name);
        refreshBoot().then(() => A.go({ c: r.key, v: '' }));
      }).catch(e => { err.textContent = (e.data && e.data.message) || 'Not added'; });
    };
    sp.open({
      title: 'Add committee',
      body: [
        h('label', { class: 'ap-field' }, h('span', { text: 'Name' }), name, h('span', { class: 'ap-help', id: 'ap-ac-help', text: 'Kept for next year' })),
        h('label', { class: 'ap-field' }, h('span', { text: 'Responsibilities' }), duties, h('span', { class: 'ap-help', text: 'One a line' })),
        err
      ],
      foot: [A.btn('Add', { primary: true, write: true, onClick: save })]
    });
  }

  function directory(ctx, d) {
    ctx.head('Committees', A.fmt.plural(d.committees.length, 'committee'), []);
    const body = ctx.body;
    const mine = d.committees.filter(c => c.mine);
    const rest = d.committees.filter(c => !c.mine);
    mine.forEach(c => {
      body.appendChild(h('section', { class: 'ap-mine', 'aria-label': c.name },
        h('h2', { class: 'ap-h2' }, c.name, c.people.length ? h('span', { class: 'ap-h2__n', text: A.fmt.plural(c.people.length, 'person', 'people') }) : null,
          h('span', { class: 'ap-h2__act' }, A.link({ s: 'overview', c: c.key, team: c.key }, 'Open', 'ap-link'))),
        h('p', { class: 'ap-dir__duties', text: c.duties }),
        people(ctx, c.people, c)));
    });
    body.appendChild(h('div', { class: 'ap-dir' }, rest.map(c => h('div', { class: 'ap-dir__c' },
      h('div', null, A.link({ c: c.key }, c.name, 'ap-dir__name')),
      h('div', null, c.duties ? h('div', { class: 'ap-dir__duties', text: c.duties }) : null,
        c.people.length ? h('div', { class: 'ap-dir__people' }, named(c.people).map(pp => h('span', null, pp.name, pp.head ? h('span', { class: 'ap-quiet', text: ' · Head' }) : null)),
          unnamed(c.people) ? h('span', { class: 'ap-quiet', text: unnamed(c.people) + ' invited' }) : null) : h('div', { class: 'ap-quiet', text: 'No one yet' })),
      h('div', null, c.people.length && !A.readonly ? h('button', { type: 'button', class: 'ap-link', text: 'Message', on: { click: () => message(ctx, { to: 'committee:' + c.key, label: c.name }) } }) : null)))));
  }

  // Someone invited who hasn't given a name shows as "1 invited", never a piece of their address.
  const masked = pp => /\*/.test(pp.name || '') || /@/.test(pp.name || '');
  const named = list => list.filter(pp => !masked(pp));
  const unnamed = list => list.filter(masked).length;

  function structure(ctx, d) {
    ctx.head('Committees', A.fmt.plural(d.committees.length, 'committee'), []);
    const sp = ctx.split();
    sp.main.appendChild(A.table({
      label: 'Committees', rows: d.committees, key: c => c.key, onOpen: c => A.go({ c: c.key }),
      cols: [
        { label: 'Committee', render: c => h('span', { class: 'ap-cell-title', text: c.name }) },
        { label: 'Responsibilities', cls: 'ap-td--muted', wide: true, render: c => (c.duties || '').split('\n').slice(0, 2).join(' · ') },
        { label: 'People', cls: 'ap-td--num', render: c => String(c.people_count) },
        // A column with nothing in it isn't drawn.
        d.committees.some(c => (c.screens || []).length) ? { label: 'Screens', render: c => (c.screens || []).map(id => (ctx.boot.screens.find(x => x.id === id) || { title: id }).title).join(', ') } : null
      ].filter(Boolean)
    }));
  }

  /* ------------------------------------------------------------ people and Message */

  function people(ctx, list, c) {
    if (!list.length) return A.empty({ title: 'No one yet', line: ctx.boot.viewer.coa ? 'Add people on Members' : 'The COA adds people', action: ctx.boot.viewer.coa && A.allowed('members') ? A.link({ s: 'members', c: c.key, id: 'new' }, 'Add people', 'ap-btn') : null });
    const shown = ctx.boot.viewer.coa ? list : named(list);
    const hidden = list.length - shown.length;
    return h('div', null, shown.map(pp => h('div', { class: 'ap-person' },
      A.face(masked(pp) && pp.email ? pp.email.split('@')[0] : pp.name, pp.you),
      h('div', { class: 'ap-person__main' },
        h('span', { class: 'ap-person__name' }, masked(pp) && pp.email ? pp.email : pp.name, pp.you ? h('span', { class: 'ap-quiet', text: ' · You' }) : null),
        h('span', { class: 'ap-person__sub', text: [pp.head ? 'Head' : '', masked(pp) ? '' : pp.email || '', pp.phone || '', pp.state === 'Invited' ? 'Not signed in' : ''].filter(Boolean).join(' · ') })),
      pp.you || A.readonly ? null : h('button', { type: 'button', class: 'ap-link ap-person__act', text: 'Message', 'aria-label': 'Message ' + pp.name, on: { click: () => message(ctx, { to: 'member:' + pp.id, label: masked(pp) ? 'them' : pp.name }) } }))),
      hidden ? h('p', { class: 'ap-quiet', text: hidden + ' invited' }) : null);
  }

  // Message: the site emails them (no addresses shown); replies come to the sender.
  function message(ctx, o) {
    const sp = ctx.sp || null;
    const subject = h('input', { class: 'ap-input', maxlength: '120', 'data-autofocus': '' });
    const text = h('textarea', { class: 'ap-textarea', rows: '7', maxlength: '4000' });
    const err = h('div', { class: 'ap-err', role: 'alert' });
    const send = btn => {
      if (!text.value.trim()) { err.textContent = 'Message needed'; text.focus(); return; }
      btn.disabled = true;
      ctx.api('POST', 'message', { to: o.to, subject: subject.value, body: text.value }).then(r => {
        A.toast('Sent to ' + (o.to.startsWith('member:') ? o.label : A.fmt.plural(r.sent, 'person', 'people') + ' · ' + o.label));
        close();
      }).catch(e => { btn.disabled = false; err.textContent = (e.data && e.data.message) || 'Not sent'; });
    };
    const body = [
      h('dl', { class: 'ap-facts' }, h('dt', { text: 'To' }), h('dd', { text: o.label })),
      h('label', { class: 'ap-field' }, h('span', { text: 'Subject' }), subject),
      h('label', { class: 'ap-field' }, h('span', { text: 'Message' }), text, h('span', { class: 'ap-help', text: 'Sent by email · Replies come to you' })),
      err
    ];
    let close;
    if (sp) {
      const sendBtn = A.btn('Send', { primary: true, write: true, onClick: () => send(sendBtn) });
      sp.open({ title: 'Message', body, foot: [sendBtn] });
      close = () => sp.close();
    } else {
      // A committee's page has no list beside it: the composer opens in the side column's place.
      const holder = ctx.body.querySelector('[data-compose]') || ctx.body;
      const box = h('section', { class: 'ap-section ap-mine', 'aria-label': 'Message' }, h('h2', { class: 'ap-h2' }, 'Message', h('span', { class: 'ap-h2__act' }, A.btn('Close', { ghost: true, onClick: () => close() }))), body);
      const sendBtn = A.btn('Send', { primary: true, write: true, onClick: () => send(sendBtn) });
      box.appendChild(sendBtn);
      const old = holder.querySelector('.ap-compose');
      if (old) old.remove();
      box.classList.add('ap-compose');
      holder.prepend(box);
      box.scrollIntoView({ block: 'nearest' });
      subject.focus();
      close = () => box.remove();
    }
  }
  A.message = message;

  /* ------------------------------------------------------------ a committee's page */

  function page(ctx0, key, own) {
    ctx0.body.appendChild(h('div', { class: 'ap-quiet', role: 'status', text: 'Loading' }));
    // The hand-down (committee-handdown.js) only for a committee the viewer is on (or the COA): anyone
    // else's would answer 404.
    const v0 = ctx0.boot.viewer;
    const pastY = +ctx0.params.past || 0;
    const on = v0.coa || (v0.committees || []).some(x => x.key === key);
    // Work and the weekly email come with the page (Round 1, after the critic: they used to arrive a beat
    // later and push everything down). A part that doesn't load is simply not drawn.
    const now = on && !pastY;
    Promise.all([ctx0.api('GET', 'committee?c=' + encodeURIComponent(key)), A.hd && on ? A.hd.load(ctx0, key, pastY) : Promise.resolve(null),
      now && A.committeeWork ? ctx0.api('GET', 'work?c=' + encodeURIComponent(key)).catch(() => null) : Promise.resolve(null),
      now && key !== 'coa' && !v0.as ? ctx0.api('GET', 'weekly?c=' + encodeURIComponent(key)).catch(() => null) : Promise.resolve(null)]).then(([c, hd, work, weekly]) => {
      A.clear(ctx0.body);
      // The page in a split, so Message and the weekly email's preview open in the record panel beside
      // it, as everywhere else.
      const sp = ctx0.split();
      const inner = h('div', { class: 'cx-page' });
      sp.main.appendChild(inner);
      const ctx = Object.assign({}, ctx0, { body: inner, sp, hd: c.access === 'full' ? hd : null, pre: { work, weekly } });
      const body = inner;
      if (ctx.params.past) return past(ctx, c, +ctx.params.past);
      const v = ctx.boot.viewer;
      const crumb = own ? null : { label: 'Committees', to: { s: 'committees', c: '', v: '' } };
      const acts = [];
      if (c.can.see_as) acts.push(A.btn('See as', { icon: 'eye', title: 'See the app as ' + c.name + ' sees it', onClick: () => A.go({ as: key, s: 'committees', c: key, team: '' }) }));
      if (c.access === 'full' && ctx.hd && A.hd.exportBtn) { const ex = A.hd.exportBtn(ctx, c, ctx.hd, key); if (ex) acts.push(ex); }
      const msg = c.people && c.people.filter(pp => !pp.you).length && c.can.message;
      if (msg && c.access !== 'full') acts.push(A.btn('Message', { primary: true, icon: 'mail', write: true, onClick: () => message(ctx, { to: 'committee:' + key, label: c.name }) }));
      else if (msg) acts.push(A.btn('Message', { icon: 'mail', write: true, onClick: () => message(ctx, { to: 'committee:' + key, label: c.name }) }));
      const fact = () => c.access === 'full' ? c.status.line : c.access === 'structure' ? A.fmt.plural(c.people_count, 'person', 'people') : A.fmt.plural(c.people.length, 'person', 'people');
      ctx.head(c.name, fact(), acts, { crumb });
      // A change on the page (a task ticked, the report sent, Looks right) reads the committee again and
      // redraws only what changed: the page stays where it is.
      ctx.redrawHead = () => ctx.head(c.name, fact(), acts, { crumb });
      if (c.access === 'structure') return structurePage(ctx, c);
      if (c.access === 'directory') {
        body.appendChild(h('div', { class: 'ap-cols' },
          h('div', null, h('section', { class: 'ap-section' }, h('h2', { class: 'ap-h2', text: 'Responsibilities' }), h('p', { class: 'ap-pre ap-muted', text: c.duties || '' }))),
          h('div', { 'data-compose': '' }, h('section', { class: 'ap-section' }, h('h2', { class: 'ap-h2' }, 'People', h('span', { class: 'ap-h2__n', text: String(c.people.length) })), people(ctx, c.people, c)))));
        return;
      }
      fullPage(ctx, c, key, own);
    }).catch(err => { A.clear(ctx0.body).appendChild(A.empty({ title: err.status === 404 ? 'Not found' : 'Not loaded', line: 'Back to Committees', action: A.link({ s: 'committees', c: '' }, 'Committees', 'ap-btn') })); });
  }

  function structurePage(ctx, c) {
    ctx.body.appendChild(h('div', { class: 'ap-cols' },
      h('section', { class: 'ap-section' }, h('h2', { class: 'ap-h2', text: 'Responsibilities' }), h('p', { class: 'ap-pre ap-muted', text: c.duties || '' })),
      h('section', { class: 'ap-section' }, h('h2', { class: 'ap-h2', text: 'Screens' }), h('p', { class: 'ap-muted', text: (c.screens || []).length ? c.screens.join(', ') : 'None handed' }))));
  }

  function fullPage(ctx, c, key, own) {
    const body = ctx.body, v = ctx.boot.viewer;
    const hd = ctx.hd;
    const reload = () => A.reload();
    // What a change elsewhere on the page moves: the title row's fact and the tasks (read again).
    let tasksSec = null;
    ctx.refresh = () => ctx.api('GET', 'committee?c=' + encodeURIComponent(key)).then(cc => {
      c.status = cc.status; c.tasks = cc.tasks; c.from = cc.from;
      if (ctx.redrawHead) ctx.redrawHead();
      if (tasksSec) { const ns = taskSection(ctx, c, key); tasksSec.replaceWith(ns); tasksSec = ns; }
      return cc;
    }).catch(() => null);
    // Carried from last year: a quiet banner until someone on it says it looks right.
    // Only the head (or the COA) says it looks right: the COA writes the responsibilities.
    const unchecked = !!c.from;
    if (c.from && c.can.write && (v.coa || v.head)) {
      const banner = h('div', { class: 'ap-banner', role: 'note' }, h('span', { title: hd ? 'The responsibilities, How we work, contacts, tasks and files came from ' + c.from : null, text: 'From ' + c.from + ' · ' + (hd ? 'Check this page' : 'Check the responsibilities, tasks and files') }),
        A.btn('Looks right', { write: true, onClick: () => ctx.api('PATCH', 'committee?c=' + encodeURIComponent(key), { checked: true }).then(() => {
          A.toast('Checked · ' + c.name);
          banner.remove();
          ctx.refresh();
        }).catch(A.fail) }));
      body.appendChild(banner);
    }
    const main = h('div');
    const sideCol = h('div', { 'data-compose': '' });
    body.appendChild(h('div', { class: 'ap-cols' }, main, sideCol));
    // The notes for next year (the side column) learn of a note kept from last year's.
    const nextNotes = { add: null, drop: null, setKept: null };
    // Last year's notes, at the top, each with Done (and Keep for next year).
    if (hd) {
      const ln = A.hd.lastNotes(ctx, c, hd, key, { onKept: n => nextNotes.add && nextNotes.add(n), onUnkept: id => nextNotes.drop && nextNotes.drop(id), bind: f => { nextNotes.setKept = f; } });
      if (ln) main.appendChild(ln);
      // Last year's report, read first (docs/23): open until the page is checked.
      const lr = A.hd.lastReport(ctx, c, hd, unchecked);
      if (lr) main.appendChild(lr);
    } else {
      const open = c.last_notes.filter(n => !n.done);
      if (c.last_notes.length) {
        main.appendChild(h('section', { class: 'ap-section', 'aria-label': 'Notes from ' + c.prev },
          h('h2', { class: 'ap-h2' }, 'Notes from ' + c.prev, h('span', { class: 'ap-h2__n', text: open.length ? open.length + ' open' : 'All done' })),
          c.last_notes.map(n => {
            const card = A.noteCard({ id: n.id, body: n.body, committee: '', on: n.on }, ctx);
            if (n.done) { card.querySelector('input').checked = true; card.style.opacity = '.55'; }
            return card;
          })));
      }
      if (c.last_report && c.last_report.answers.some(Boolean)) {
        main.appendChild(h('section', { class: 'ap-section', 'aria-label': c.prev + ' report' },
          h('details', { class: 'ap-note' }, h('summary', { text: c.prev + ' report' + (c.last_report.sent ? ' · Sent ' + c.last_report.sent : '') }),
            ctx.boot.questions.map((q, i) => c.last_report.answers[i] ? h('div', { class: 'ap-q', style: { marginTop: '10px' } }, h('span', { class: 'ap-q__ask', text: q }), h('p', { class: 'ap-q__said', text: c.last_report.answers[i] })) : null))));
      }
    }
    // The committee's own screens, each with where it stands (app-committees: committee-kit.js).
    if (A.committeeWork) { const w = A.committeeWork(ctx, c, key, ctx.pre ? ctx.pre.work : undefined); if (w) main.appendChild(w); }

    // Responsibilities: the COA writes them once; they carry to next year.
    const duties = h('section', { class: 'ap-section', 'aria-labelledby': 'ap-h-duties' });
    const drawDuties = () => {
      A.clear(duties);
      duties.appendChild(h('h2', { class: 'ap-h2', id: 'ap-h-duties' }, 'Responsibilities', c.can.edit ? h('span', { class: 'ap-h2__act' }, h('button', { type: 'button', class: 'ap-link', text: 'Edit', on: { click: editDuties } })) : null));
      duties.appendChild(c.duties ? h('p', { class: 'ap-pre ap-muted', text: c.duties }) : A.empty({ title: 'None written', line: 'The COA writes them once' }));
    };
    const editDuties = () => {
      A.clear(duties);
      const name = h('input', { class: 'ap-input', value: c.name, maxlength: '60' });
      const ta = h('textarea', { class: 'ap-textarea', rows: '6', value: c.duties || '' });
      duties.append(h('h2', { class: 'ap-h2', text: 'Responsibilities' }),
        h('label', { class: 'ap-field' }, h('span', { text: 'Name' }), name),
        h('label', { class: 'ap-field' }, h('span', { text: 'Responsibilities' }), ta, h('span', { class: 'ap-help', text: 'One a line · Kept for next year' })),
        h('div', { class: 'ap-row' }, A.btn('Save', { primary: true, write: true, onClick: () => ctx.api('PATCH', 'committee?c=' + encodeURIComponent(key), { name: name.value, duties: ta.value }).then(r => { c.duties = r.duties; c.name = r.name; A.toast('Saved ' + r.name); refreshBoot().then(reload); }).catch(A.fail) }),
          A.btn('Cancel', { ghost: true, onClick: drawDuties })));
      ta.focus();
    };
    drawDuties();
    main.appendChild(duties);
    // How we work: the committee's own standards, under the COA's responsibilities (committee-handdown.js).
    if (hd) main.appendChild(A.hd.how(ctx, c, hd, key));

    // Tasks.
    tasksSec = taskSection(ctx, c, key);
    main.appendChild(tasksSec);
    // Files.
    main.appendChild(hd ? A.hd.files(ctx, c, hd, key, upload) : fileSection(ctx, c, key));
    // Report (not the COA's own): drawn once the Conference is over, or once someone has started it.
    const started = (c.report && c.report.answers.some(Boolean)) || (hd && hd.numbers.rows.some(x => x.n !== ''));
    if (key !== 'coa' && (c.phase === 'after' || started)) main.appendChild(hd ? A.hd.report(ctx, c, hd, key) : reportSection(ctx, c, key));

    // The side column: people, contacts, notes for next year, the folder link, screens, past years.
    sideCol.appendChild(h('section', { class: 'ap-section', 'aria-labelledby': 'ap-h-people' },
      h('h2', { class: 'ap-h2', id: 'ap-h-people' }, 'People', h('span', { class: 'ap-h2__n', text: String(c.people.length) }),
        v.coa && !v.as && A.allowed('members') ? h('span', { class: 'ap-h2__act' }, A.link({ s: 'members', c: key === 'coa' ? '' : key, id: '' }, 'Manage', 'ap-link')) : null),
      people(ctx, c.people, c)));
    if (hd) sideCol.appendChild(A.hd.contacts(ctx, c, hd, key));
    sideCol.appendChild(notesSection(ctx, c, key, nextNotes));
    sideCol.appendChild(linkSection(ctx, c, key));
    if (key !== 'coa' && c.can.write) sideCol.appendChild(weeklySection(ctx, c, key));
    if (c.handable.length || c.screens.length) sideCol.appendChild(screensSection(ctx, c, key));
    if (c.past.length) {
      sideCol.appendChild(h('section', { class: 'ap-section', 'aria-labelledby': 'ap-h-past' },
        h('h2', { class: 'ap-h2', id: 'ap-h-past', text: 'Past years' }),
        h('div', { class: 'ap-row' }, c.past.map(py => A.link({ past: py }, String(py), 'ap-chip')))));
    }
    if (ctx.params.at === 'report') setTimeout(() => { const r = body.querySelector('#ap-report'); if (r) r.scrollIntoView(); }, 0);
  }

  function taskSection(ctx, c, key) {
    const sec = h('section', { class: 'ap-section', 'aria-labelledby': 'ap-h-tasks' });
    const done = c.tasks.filter(t => t.done).length;
    sec.appendChild(h('h2', { class: 'ap-h2', id: 'ap-h-tasks' }, 'Tasks', c.tasks.length ? h('span', { class: 'ap-h2__n', text: done ? done + ' of ' + c.tasks.length + ' done' : String(c.tasks.length) }) : null,
      h('span', { class: 'ap-h2__act' }, A.link({ s: 'tasks', c: key }, 'All tasks', 'ap-link'))));
    if (!c.tasks.length) { sec.appendChild(A.empty({ title: 'No tasks', line: 'Add one on Tasks' })); return sec; }
    sec.appendChild(h('ul', { class: 'ap-list' }, c.tasks.map(t => {
      // A task its screen ticks ("Answer requests") isn't ticked here; its panel on Tasks can, if asked.
      const box = h('input', { type: 'checkbox', class: 'ap-check', checked: t.done, disabled: !c.can.write || !!t.auto || (!!t.screen && !t.done), title: t.screen && !t.done ? 'Ticks itself on its screen' : null, 'aria-label': 'Done: ' + t.title });
      const li = h('li', { class: t.done ? 'ap-item--done' : '' }, h('div', { class: 'ap-item' + (t.done ? ' ap-item--done' : '') }, box,
        // The task itself, open on Tasks in a view that holds it (another committee's, for the COA).
        h('span', { class: 'ap-item__main' }, A.link({ s: 'tasks', id: t.id }, t.title, 'ap-item__title'),
          t.done ? h('span', { class: 'ap-item__why', text: A.taskDoneWords ? A.taskDoneWords(t) : 'Done ' + t.done_on })
            // Ticked by the work itself: where that work is, said and one tap away.
            : t.screen && !t.auto ? h('span', { class: 'ap-item__why' }, 'Ticks itself · ', A.allowed(t.screen) ? A.link(A.taskWhere ? A.taskWhere(t.screen, Object.assign({ committee: key }, t)) : { s: t.screen }, screenTitle(ctx, t.screen), 'ap-link') : h('span', { text: screenTitle(ctx, t.screen) })) : null),
        t.late ? A.tag('Late', 'late') : null,
        h('span', { class: 'ap-item__side', text: t.due_words })));
      box.addEventListener('change', () => toggleTask(ctx, t, box));
      return li;
    })));
    return sec;
  }

  // A screen by its name (also one this viewer doesn't open), never its id.
  const screenTitle = (ctx, id) => (ctx.boot.screens.find(x => x.id === id) || {}).title || (typeof (A.screens()[id] || {}).title === 'string' ? A.screens()[id].title : id);

  // Done or not, with Undo; says what it did. The screen it's on stays: a committee's page redraws its
  // tasks (ctx.refresh), any other screen draws itself again where it was (A.reload).
  function toggleTask(ctx, t, box) {
    const want = box.checked;
    const again = () => { A.forgetTasks(); if (ctx.refresh) ctx.refresh(); else A.reload(); };
    ctx.api('PATCH', '/app/tasks/' + t.id, { done: want }).then(() => {
      A.toast((want ? 'Done · ' : 'Reopened · ') + t.title, { undo: () => ctx.api('PATCH', '/app/tasks/' + t.id, { done: !want }).then(again).catch(A.fail) });
      again();
    }).catch(e => { box.checked = !want; A.fail(e); });
  }
  A.toggleTask = toggleTask;

  function fileSection(ctx, c, key) {
    const sec = h('section', { class: 'ap-section', 'aria-labelledby': 'ap-h-files' });
    const input = h('input', { type: 'file', hidden: true, multiple: true });
    sec.appendChild(h('h2', { class: 'ap-h2', id: 'ap-h-files' }, 'Files', c.files.length ? h('span', { class: 'ap-h2__n', text: String(c.files.length) }) : null,
      c.can.write ? h('span', { class: 'ap-h2__act' }, A.btn('Upload', { icon: 'upload', write: true, onClick: () => input.click() })) : null));
    sec.appendChild(input);
    const nonce = (window.OGC_WP || {}).nonce || '';
    const base = ((window.OGC_WP || {}).app || {}).files || '/wp-json/ogc/v1/app/files/';
    if (c.files.length) {
      sec.appendChild(h('ul', { class: 'ap-list' }, c.files.map(f => h('li', null, h('div', { class: 'ap-item' }, A.icon('file'),
        h('span', { class: 'ap-item__main' },
          h('a', { class: 'ap-item__title', href: base + f.id + '?_wpnonce=' + encodeURIComponent(nonce) + (ctx.params.as ? '&as=' + encodeURIComponent(ctx.params.as) : ''), download: f.name, text: f.name }),
          h('span', { class: 'ap-item__why', text: [f.type, A.fmt.size(f.size), f.carried ? 'From last year' : f.on, f.by].filter(Boolean).join(' · ') })),
        c.can.write && !A.readonly ? h('button', { type: 'button', class: 'ap-link ap-link--quiet', text: 'Remove', 'aria-label': 'Remove ' + f.name, on: { click: () => ctx.api('DELETE', '/app/files/' + f.id).then(() => { A.toast('Removed ' + f.name); A.reload(); }).catch(A.fail) } }) : null)))));
    }
    if (c.can.write) {
      const drop = h('div', { class: 'ap-drop', text: c.files.length ? 'Drop files here' : 'Drop files here · Kept for this committee and the COA, and for next year’s committee' });
      ['dragenter', 'dragover'].forEach(ev => drop.addEventListener(ev, e => { e.preventDefault(); drop.classList.add('ap-drop--over'); }));
      ['dragleave', 'drop'].forEach(ev => drop.addEventListener(ev, () => drop.classList.remove('ap-drop--over')));
      drop.addEventListener('drop', e => { e.preventDefault(); upload(ctx, key, [...e.dataTransfer.files]); });
      sec.appendChild(drop);
    } else if (!c.files.length) {
      return h('span', { hidden: true });
    }
    input.addEventListener('change', () => upload(ctx, key, [...input.files]));
    return sec;
  }

  // done: what draws the files again (the hand-down's Files section); else the page is drawn again where
  // it is. Files uploaded before one that fails are kept and shown.
  async function upload(ctx, key, files, done) {
    const W = window.OGC_WP || {};
    let n = 0, said = '';
    for (const f of files.slice(0, 10)) {
      const fd = new FormData();
      fd.append('file', f, f.name);
      A.toast('Uploading ' + f.name);
      try {
        const res = await fetch((W.rest || '/wp-json/ogc/v1/') + 'app/' + ctx.boot.year + '/committee/files?c=' + encodeURIComponent(key), { method: 'POST', credentials: 'same-origin', headers: { 'X-WP-Nonce': W.nonce || '' }, body: fd });
        const d = await res.json().catch(() => null);
        if (!res.ok) { said = f.name + ' · ' + ((d && d.message) || 'Not uploaded'); break; }
        n++;
      } catch (e) { said = 'Not uploaded · Check the connection'; break; }
    }
    if (!n) { if (said) A.toast(said); return; }
    A.toast(said || (n === 1 ? 'Uploaded ' + files[0].name : 'Uploaded ' + n + ' files'));
    if (done) done(); else A.reload();
  }

  function notesSection(ctx, c, key, hooks) {
    const sec = h('section', { class: 'ap-section', 'aria-labelledby': 'ap-h-notes' });
    const next = ctx.boot.year + 1;
    // Notes kept from last year's (committee-handdown.js) say where they came from; one kept just now
    // joins the list without drawing the page again.
    const origin = Object.assign({}, (ctx.hd && ctx.hd.origin) || {});
    if (hooks) {
      hooks.add = n => { c.notes.push({ id: n.id, body: n.body, by: n.by, on: 'Today' }); if (n.origin) origin[n.id] = n.origin; draw(); };
      hooks.drop = id => { const i = c.notes.findIndex(x => x.id === id); if (i >= 0) c.notes.splice(i, 1); draw(); };
    }
    const meta = n => {
      const o = origin[n.id];
      return o ? 'From ' + o.year + (n.by ? ' · Kept by ' + n.by : '') : [n.by, n.on].filter(Boolean).join(' · ');
    };
    // Read the notes again (after Add or Undo), then draw only this section.
    const again = () => ctx.api('GET', 'committee?c=' + encodeURIComponent(key)).then(cc => { c.notes = cc.notes; draw(); }).catch(() => A.reload());
    const removeNote = n => ctx.api('DELETE', '/app/notes/' + n.id).then(r => {
      const i = c.notes.indexOf(n);
      if (i >= 0) c.notes.splice(i, 1);
      const o = origin[n.id];
      // A kept copy removed: last year's note offers Keep again.
      if (o && hooks && hooks.setKept) hooks.setKept(o.src, false);
      draw();
      A.toast('Note removed', { undo: () => (o
        ? ctx.api('POST', 'handdown/keep?c=' + encodeURIComponent(key), { id: o.src }).then(k => { if (hooks && hooks.add) hooks.add({ id: k.copy, body: n.body, by: k.by, origin: k.origin }); if (hooks && hooks.setKept) hooks.setKept(o.src, true); })
        : ctx.api('POST', 'committee/notes?c=' + encodeURIComponent(key), { body: r.body }).then(again)).catch(A.fail) });
    }).catch(A.fail);
    const draw = () => {
      A.clear(sec);
      sec.hidden = false;
      sec.appendChild(h('h2', { class: 'ap-h2', id: 'ap-h-notes' }, 'Notes for ' + next, c.notes.length ? h('span', { class: 'ap-h2__n', text: String(c.notes.length) }) : null));
      sec.appendChild(h('p', { class: 'ap-help', style: { margin: '-4px 0 8px' }, text: 'Next year’s committee reads these first' }));
      c.notes.forEach(n => sec.appendChild(h('div', { class: 'ap-note' }, h('div', { class: 'ap-pre', text: n.body }), h('div', { class: 'ap-note__meta' }, h('span', { text: meta(n) }),
        c.can.write && n.id ? h('button', { type: 'button', class: 'ap-link ap-link--quiet', text: 'Remove', on: { click: () => removeNote(n) } }) : null))));
      if (c.can.write) {
        const ta = h('textarea', { class: 'ap-textarea', rows: '3', maxlength: '2000', 'aria-label': 'Add note for ' + next, placeholder: 'Note for next year’s ' + (key === 'coa' ? 'COA' : c.name) });
        const add = A.btn('Add note', { write: true, onClick: () => {
          if (!ta.value.trim()) { ta.focus(); return; }
          ctx.api('POST', 'committee/notes?c=' + encodeURIComponent(key), { body: ta.value }).then(() => { A.toast('Note added for ' + next); again(); }).catch(A.fail);
        } });
        sec.appendChild(h('div', { class: 'ap-field', style: { marginTop: '10px' } }, ta, h('div', { class: 'ap-row' }, add)));
      } else if (!c.notes.length) {
        sec.hidden = true;
      }
    };
    draw();
    return sec;
  }

  function linkSection(ctx, c, key) {
    const sec = h('section', { class: 'ap-section', 'aria-labelledby': 'ap-h-link' });
    const draw = () => {
      A.clear(sec);
      sec.appendChild(h('h2', { class: 'ap-h2', id: 'ap-h-link', title: 'The committee’s own working folder, if it keeps one · Pasted once, kept for next year' }, 'Folder',
        c.can.write ? h('span', { class: 'ap-h2__act' }, h('button', { type: 'button', class: 'ap-link', text: c.link ? 'Change' : 'Add link', on: { click: edit } })) : null));
      if (c.link) sec.appendChild(h('a', { class: 'ap-link', href: c.link, rel: 'noopener noreferrer', target: '_blank' }, A.icon('link'), ' ', c.link.replace(/^https:\/\//, '').slice(0, 48)));
      else sec.appendChild(h('p', { class: 'ap-quiet', text: 'None · Optional' }));
    };
    const edit = () => {
      A.clear(sec);
      const inp = h('input', { class: 'ap-input', type: 'url', value: c.link || '', placeholder: 'https://', 'aria-label': 'Folder link' });
      const err = h('div', { class: 'ap-err', role: 'alert' });
      sec.append(h('h2', { class: 'ap-h2', text: 'Folder' }), h('div', { class: 'ap-field' }, inp, err),
        h('div', { class: 'ap-row' }, A.btn('Save', { primary: true, write: true, onClick: () => ctx.api('PATCH', 'committee?c=' + encodeURIComponent(key), { link: inp.value.trim() }).then(r => { c.link = r.link; A.toast(r.link ? 'Link saved' : 'Link removed'); draw(); }).catch(e => { err.textContent = (e.data && e.data.message) || 'Not saved'; }) }),
          A.btn('Cancel', { ghost: true, onClick: draw })));
      inp.focus();
    };
    draw();
    return sec;
  }

  // Screens the COA hands this committee: they move into its sidebar. A tap never hands at once (Round 1,
  // after the critic: the pills look like links): it asks first, saying what moves and to whom, then Undo.
  // Round 2 replaces these pills with Who runs what; this is only the guard until then.
  function screensSection(ctx, c, key) {
    const sec = h('section', { class: 'ap-section', 'aria-labelledby': 'ap-h-screens' });
    sec.appendChild(h('h2', { class: 'ap-h2', id: 'ap-h-screens' }, c.handable.length ? 'Hand a screen' : 'Screens'));
    if (c.handable.length) sec.appendChild(h('p', { class: 'ap-help', style: { margin: '-4px 0 8px' }, text: 'Moves it into ' + c.name + '’s sidebar · Its tasks go with it' }));
    if (!c.handable.length) {
      sec.appendChild(h('p', { class: 'ap-muted', text: c.screens.map(id => (ctx.boot.screens.find(s => s.id === id) || { title: id }).title).join(', ') }));
      return sec;
    }
    const nameOf = k => !k ? 'the COA' : ((A.committee(k) || {}).name || k);
    // Hand a screen to a committee (to: key, '' = back to the COA). A screen that carries people
    // (Households) is sent with Yes once asked (the server answers 409 ogc_hand_people until then).
    const send = (s, to, confirm) => ctx.api('POST', 'hand', Object.assign({ screen: s.id, c: to }, confirm ? { confirm: true } : {}));
    const ask = h('div', { class: 'pv-ask', hidden: true, role: 'group', 'aria-label': 'Hand a screen' });
    const askFor = s => {
      const on = s.to === key;
      const was = s.to || '';
      const to = on ? '' : key;
      const what = on ? 'Give ' + s.title + ' back to the COA?' : 'Hand ' + s.title + ' to ' + c.name + '?';
      const moves = on ? 'It leaves ' + c.name + '’s sidebar · Its tasks go with it'
        : 'It moves into ' + c.name + '’s sidebar' + (was ? ', from ' + nameOf(was) + '’s' : '') + ' · Its tasks go with it' + (s.people ? ' · ' + s.people : '');
      const yes = A.btn(on ? 'Give back' : 'Hand to ' + c.name, { write: true, onClick: () => {
        yes.disabled = true;
        send(s, to, !!s.people).then(() => {
          ask.hidden = true;
          const said = on ? s.title + ' back with the COA' : s.title + ' handed to ' + c.name;
          A.toast(said, { undo: () => send(s, was, true).then(() => { A.toast('Undone · ' + said); return refreshBoot().then(() => A.reload()); }).catch(A.fail) });
          refreshBoot().then(() => A.reload());
        }).catch(e => { yes.disabled = false; A.fail(e); });
      } });
      A.clear(ask).append(h('p', { class: 'pv-ask__q', text: what }), h('p', { class: 'ap-help', text: moves }),
        h('div', { class: 'ap-row' }, yes, A.btn('Cancel', { ghost: true, onClick: () => { ask.hidden = true; } })));
      ask.hidden = false;
      yes.focus();
    };
    sec.appendChild(h('div', { class: 'ap-pills', role: 'group', 'aria-label': 'Hand screens to ' + c.name }, c.handable.map(s => {
      const on = s.to === key;
      return h('button', {
        type: 'button', class: 'ap-pill', 'aria-pressed': String(on), disabled: A.readonly, title: on ? 'With ' + c.name + ' · Asks before giving it back' : 'Asks before handing it to ' + c.name + (s.to ? ' · Now with ' + nameOf(s.to) : ''),
        on: { click: () => askFor(s) }
      }, s.title + (s.to && !on ? ' · ' + nameOf(s.to) : ''));
    })));
    c.handable.filter(s => s.people).forEach(s => sec.appendChild(h('p', { class: 'ap-help', style: { margin: '8px 0 0' }, text: s.title + ' · ' + s.people })));
    sec.appendChild(ask);
    return sec;
  }

  // The weekly note: Mondays, to everyone on the committee, while something needs them. The COA turns it off.
  // Drawn with the page from what it fetched alongside (ctx.pre.weekly); not drawn when that didn't load.
  function weeklySection(ctx, c, key) {
    const sec = h('section', { class: 'ap-section', 'aria-labelledby': 'ap-h-weekly' });
    const coa = ctx.boot.viewer.coa && !A.readonly;
    const pre = ctx.pre && ctx.pre.weekly;
    if (ctx.pre && !pre) { sec.hidden = true; return sec; }
    (pre ? Promise.resolve(pre) : ctx.api('GET', 'weekly?c=' + encodeURIComponent(key))).then(w => {
      const draw = () => {
        A.clear(sec);
        sec.appendChild(h('h2', { class: 'ap-h2', id: 'ap-h-weekly' }, 'Weekly email', h('span', { class: 'ap-h2__n', text: w.on ? 'On' : 'Off' }),
          h('span', { class: 'ap-h2__act' }, w.items ? h('button', { type: 'button', class: 'ap-link', text: 'Preview', on: { click: () => preview(w) } }) : null)));
        sec.appendChild(h('p', { class: 'ap-help', text: w.on ? (w.items ? 'Mondays · ' + A.fmt.plural(w.items, 'item') : 'Mondays, when something needs ' + c.name) : 'Not sent' }));
        if (coa) sec.appendChild(h('button', { type: 'button', class: 'ap-link', text: w.on ? 'Turn off' : 'Turn on', on: { click: () => ctx.api('PUT', 'weekly?c=' + encodeURIComponent(key), { on: !w.on }).then(r => { w.on = r.on; A.toast('Weekly email ' + (r.on ? 'on' : 'off') + ' · ' + c.name); draw(); }).catch(A.fail) } }));
      };
      draw();
    }).catch(() => sec.remove());
    // The email as it would go this Monday, in a sandboxed frame (no scripts, no links followed).
    function preview(w) {
      const f = h('iframe', { title: 'Weekly email preview', sandbox: '', class: 'ap-mailframe' });
      f.srcdoc = w.html;
      if (ctx.sp) { ctx.sp.open({ title: w.subject, body: [h('p', { class: 'ap-help', text: 'As it goes this Monday, to everyone on ' + c.name }), f] }); return; }
      const box = h('section', { class: 'ap-section ap-mine ap-compose', 'aria-label': 'Weekly email' }, h('h2', { class: 'ap-h2' }, w.subject, h('span', { class: 'ap-h2__act' }, A.btn('Close', { ghost: true, onClick: () => box.remove() }))), f);
      (ctx.body.querySelector('[data-compose]') || ctx.body).prepend(box);
    }
    return sec;
  }

  function reportSection(ctx, c, key) {
    const sec = h('section', { class: 'ap-section', id: 'ap-report', 'aria-labelledby': 'ap-h-report' });
    const qs = ctx.boot.questions;
    const r = c.report || { answers: [] };
    sec.appendChild(h('h2', { class: 'ap-h2', id: 'ap-h-report', title: 'The COA’s questions, answered after the Conference · Next year’s committee sees it at the top' }, 'Report',
      h('span', { class: 'ap-h2__n', text: r.sent ? 'Sent ' + r.sent : r.updated ? 'Draft · Saved ' + r.updated : '' })));
    // Before the Conference the report waits; it's answered after (or written as things happen).
    if (!c.can.write) {
      if (!r.answers.some(Boolean)) sec.appendChild(A.empty({ title: 'Not written', line: 'Answered after the Conference' }));
      else qs.forEach((q, i) => r.answers[i] && sec.appendChild(h('div', { class: 'ap-q' }, h('span', { class: 'ap-q__ask', text: q }), h('p', { class: 'ap-q__said', text: r.answers[i] }))));
      return sec;
    }
    const after = c.phase === 'after';
    const boxes = qs.map((q, i) => h('textarea', { class: 'ap-textarea', rows: '3', maxlength: '6000', value: r.answers[i] || '' }));
    if (!after && !r.answers.some(Boolean)) {
      const show = A.btn('Start the report', { write: true, onClick: () => { wrap.hidden = false; show.remove(); boxes[0].focus(); } });
      sec.appendChild(h('p', { class: 'ap-quiet', text: 'Answered after the Conference' }));
      sec.appendChild(show);
    }
    const status = h('span', { class: 'ap-quiet', role: 'status' });
    let t = 0;
    const save = send => ctx.api('PUT', 'committee/report?c=' + encodeURIComponent(key), { answers: boxes.map(b => b.value), send: !!send }).then(res => {
      status.textContent = res.sent ? 'Sent ' + res.sent : 'Saved';
      if (send) { A.toast('Report sent to the COA'); A.reload(); }
    }).catch(A.fail);
    boxes.forEach(b => b.addEventListener('input', () => { status.textContent = 'Saving'; clearTimeout(t); t = setTimeout(() => save(false), 900); }));
    const wrap = h('div', { hidden: !after && !r.answers.some(Boolean) },
      qs.map((q, i) => h('label', { class: 'ap-field' }, h('span', { text: (i + 1) + '. ' + q }), boxes[i])),
      h('div', { class: 'ap-row' }, r.sent ? A.btn('Send again', { write: true, onClick: () => save(true) }) : A.btn('Send to the COA', { primary: after, write: true, onClick: () => save(true) }), status));
    sec.appendChild(wrap);
    return sec;
  }

  /* ------------------------------------------------------------ a past year, read only, no people */

  function past(ctx, now, py) {
    const key = now.key;
    ctx.api('GET', 'committee/past?c=' + encodeURIComponent(key) + '&from=' + py).then(d => {
      const body = ctx.body;
      // Read only and the way back, said once (the title row); the banner only says who was on it.
      // The way up is the committee's own page (area-shell 3.2), the same for its people and the COA.
      ctx.head(now.name + ' · ' + py, 'Read only', [A.link({ past: '' }, 'Back to ' + ctx.boot.year, 'ap-btn')], { crumb: { label: now.name, to: { s: 'committees', c: key, past: '' } } });
      if (d.people) body.appendChild(h('div', { class: 'ap-banner', role: 'note' }, h('span', { text: A.fmt.plural(d.people, 'person was', 'people were') + ' on it in ' + py })));
      const main = h('div'), sideCol = h('div');
      main.appendChild(h('section', { class: 'ap-section' }, h('h2', { class: 'ap-h2', text: 'Responsibilities' }), h('p', { class: 'ap-pre ap-muted', text: d.duties || '' })));
      // That year's own hand-down (committee-handdown.js), read only and without names.
      const hd = ctx.hd && ctx.hd.year === py ? ctx.hd : null;
      if (hd && hd.how.text) main.appendChild(h('section', { class: 'ap-section' }, h('h2', { class: 'ap-h2', text: 'How we work' }), h('p', { class: 'ap-pre ap-muted', text: hd.how.text })));
      if (d.report || (hd && hd.numbers.rows.length)) {
        main.appendChild(h('section', { class: 'ap-section' }, h('h2', { class: 'ap-h2' }, 'Report', h('span', { class: 'ap-h2__n', text: d.report && d.report.sent ? 'Sent ' + d.report.sent : 'Draft' })),
          // Under the questions as they were asked that year (kept with the report), not as they read now.
          d.report ? d.report.answers.map((a, i) => a ? h('div', { class: 'ap-q' }, h('span', { class: 'ap-q__ask', text: ((hd && hd.questions && hd.questions.length ? hd.questions : ctx.boot.questions)[i]) || 'Question ' + (i + 1) }), h('p', { class: 'ap-q__said', text: a })) : null) : null,
          hd && hd.numbers.rows.length ? [h('h3', { class: 'hd-h3', text: 'Numbers' }), h('table', { class: 'hd-numtable' }, h('tbody', null, hd.numbers.rows.filter(x => x.n !== '').map(x => h('tr', null, h('td', { text: x.what }), h('td', { class: 'hd-num', text: Number(x.n).toLocaleString('en-US') })))))] : null));
      }
      main.appendChild(h('section', { class: 'ap-section' }, h('h2', { class: 'ap-h2' }, 'Tasks', h('span', { class: 'ap-h2__n', text: d.tasks.filter(t => t.done).length + ' of ' + d.tasks.length })),
        d.tasks.length ? h('ul', { class: 'ap-list' }, d.tasks.map(t => h('li', null, h('div', { class: 'ap-item' }, h('span', { class: 'ap-item__main' }, h('span', { class: 'ap-item__title', text: t.title }), t.done ? h('span', { class: 'ap-item__why', text: 'Done ' + t.done_on }) : h('span', { class: 'ap-item__why', text: 'Not done' })), h('span', { class: 'ap-item__side', text: t.when }))))) : A.empty({ title: 'No tasks' })));
      if (hd && hd.contacts.rows.length) sideCol.appendChild(h('section', { class: 'ap-section' }, h('h2', { class: 'ap-h2' }, 'Contacts', h('span', { class: 'ap-h2__n', text: String(hd.contacts.rows.length) })),
        h('ul', { class: 'hd-contacts' }, hd.contacts.rows.map(r => h('li', null, h('div', { class: 'hd-contact' }, h('span', { class: 'hd-contact__role', text: r.role }),
          r.phone || r.email ? h('span', { class: 'hd-contact__how', text: [r.phone, r.email].filter(Boolean).join(' · ') }) : null, r.note ? h('span', { class: 'hd-contact__note', text: r.note }) : null))))));
      sideCol.appendChild(h('section', { class: 'ap-section' }, h('h2', { class: 'ap-h2' }, 'Notes', h('span', { class: 'ap-h2__n', text: String(d.notes.length) })),
        d.notes.length ? d.notes.map(n => h('div', { class: 'ap-note' }, h('div', { class: 'ap-pre', text: n.body }), h('div', { class: 'ap-note__meta', text: n.on }))) : A.empty({ title: 'No notes' })));
      if (d.files.length) sideCol.appendChild(h('section', { class: 'ap-section' }, h('h2', { class: 'ap-h2', text: 'Files' }), h('ul', { class: 'ap-list' }, d.files.map(f => h('li', null, h('div', { class: 'ap-item' }, A.icon('file'), h('span', { class: 'ap-item__main' }, h('span', { class: 'ap-item__title', text: f.name }), h('span', { class: 'ap-item__why', text: [f.type, A.fmt.size(f.size), f.on].filter(Boolean).join(' · ') }))))))));
      body.appendChild(h('div', { class: 'ap-cols' }, main, sideCol));
    }).catch(() => { A.clear(ctx.body).appendChild(A.empty({ title: 'Not found', action: A.link({ past: '' }, 'Back to ' + ctx.boot.year, 'ap-btn') })); });
  }

  /* ------------------------------------------------------------ boot again (names, screens) */

  function refreshBoot() {
    return A.api('GET', 'boot').then(b => { const cur = A.boot(); Object.assign(cur, b); });
  }
  A.refreshBoot = refreshBoot;

  /* ------------------------------------------------------------ the screens */

  A.screen({
    id: 'committees', title: 'Committees', icon: 'committees', section: 'main', who: ['all'],
    render(ctx) {
      const p = ctx.params;
      // Your own committee's page has one address, this one (s=committees&c=<yours>): no crumb, its own
      // sidebar item current (Round 1, after the critic). Anyone else's has the crumb to Committees.
      if (p.c) return page(ctx, p.c, A.ownPage(p.c));
      ctx.body.appendChild(h('div', { class: 'ap-quiet', role: 'status', text: 'Loading' }));
      ctx.api('GET', 'committees').then(d => {
        A.clear(ctx.body);
        ctx.body.classList.remove('ap-body--flush');
        if (d.view === 'board') board(ctx, d);
        else if (d.view === 'directory') directory(ctx, d);
        else structure(ctx, d);
      }).catch(() => { A.clear(ctx.body).appendChild(A.empty({ title: 'Not loaded', line: 'Reload the page' })); });
    }
  });

  A.screen({
    id: 'overview', title: b => ((b.committees || []).find(c => c.key === A.team()) || {}).name || 'Overview', icon: 'overview', section: 'own', who: ['committee'],
    render(ctx) {
      const key = ctx.params.c && ctx.boot.viewer.committees.some(c => c.key === ctx.params.c) ? ctx.params.c : A.team();
      if (!key) { ctx.body.appendChild(A.empty({ title: 'No committee' })); return; }
      page(ctx, key, true);
    }
  });

  A.action({ id: 'add-committee', title: 'Add committee', screen: 'committees', when: b => b.viewer.coa && !b.viewer.as, run: () => A.go({ s: 'committees', c: '', v: '' }) });
  A.action({ id: 'note', title: 'Add note for next year', when: b => b.viewer.committees.length > 0 && !b.viewer.as, run: () => { A.go({ s: 'overview', c: A.team() }); setTimeout(() => { const t = document.querySelector('[aria-label^="Add note"]'); if (t) t.focus(); }, 600); } });
})();
