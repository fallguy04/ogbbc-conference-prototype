/*
 * admin-rows.js — one editor file kept on the server, row by row (ED.Rows).
 *
 * Every row has a lasting _id (the server gives one to any row without). A change is sent as the
 * change itself — this row, these fields, and what they were when read — so two people working on
 * different rows (the A/V head on Friday, the COA chair on Sunday) never collide, and two working on the
 * same field get a conflict on that field, said where it is, never a silent overwrite.
 *
 *   const f = new ED.Rows(2027, 'schedule');  await f.load();
 *   f.rows                      the rows as this person sees them (the server's, plus changes not yet sent)
 *   f.set(id, {k: v}, {label, key})   f.add(row, {before, label})   f.remove(id, {label})   f.move(id, beforeId)
 *   f.undo() / f.redo()         the reverse of this person's own last change, row by row
 *   f.on('change'|'status'|'conflict'|'remote'|'here'|'ids', fn)
 *   f.meta[id] = { by, at }     who last changed a row
 *   f.add(row, {hold: true})    a new row kept here until its key field has something in it (f.release),
 *                               or dropped while still blank (f.discard): Add never writes a blank row
 *   f.held[id][field]           a field the server refused because someone else changed it first: the
 *                               person's text stays in the box until they choose (f.resolve)
 *
 * Status words (said in the editor's bar): Saving · Saved · Not saved · Offline · Couldn't save ·
 * Signed out · Held.
 * Changes not yet confirmed are kept in this browser too (localStorage), so a closed tab or a dropped
 * connection loses nothing; they're sent again when the editor opens.
 */
(function () {
  'use strict';
  const ED = window.ED = window.ED || {};
  const W = window.OGC_WP || {};
  const api = (m, p, b) => W.api(m, p, b);
  const copy = r => Object.assign({}, r);
  const tmpId = () => 'n' + Math.random().toString(36).slice(2, 11);
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const KEEP = 'ogc-ed-pending-';

  // A fresh nonce for a page left open past a day (WordPress's own: admin-ajax rest-nonce).
  async function freshNonce() {
    try {
      const r = await fetch((W.ajax || '/wp-admin/admin-ajax.php') + '?action=rest-nonce', { credentials: 'same-origin' });
      const t = (await r.text()).trim();
      if (r.ok && /^[a-f0-9]{6,}$/i.test(t)) { W.nonce = t; return true; }
    } catch (e) { /* offline */ }
    return false;
  }

  class Rows {
    constructor(year, name, opts) {
      this.year = String(year); this.name = name; this.opts = opts || {};
      this.server = []; this.cols = []; this.version = 0; this.meta = {};
      this.pending = [];           // ops not yet confirmed: { op, id, fields, base, row, before, sent }
      this.undoes = []; this.redoes = [];
      this.fns = {}; this.state = 'saved'; this.busy = false; this.wait = 0; this.here = [];
      this.loaded = false; this.problem = '';
      this.held = {};              // conflicts waiting for a choice: { id: { field: { mine, theirs, by } } }
    }
    on(ev, fn) { (this.fns[ev] = this.fns[ev] || []).push(fn); return this; }
    emit(ev, d) { (this.fns[ev] || []).forEach(fn => { try { fn(d); } catch (e) { console.error(e); } }); }
    setState(s, extra) { this.state = s; this.problem = (extra && extra.message) || ''; this.emit('status', Object.assign({ state: s, pending: this.pending.length }, extra || {})); }

    /* ---------------------------------------------------------- reading */

    // initial: the file as a year's bundle already gave it ({ rows, cols, version }), so no request is
    // needed to open it; who changed each row comes with the first sync, a moment later.
    async load(initial) {
      const d = initial && initial.rows ? Object.assign({ here: [] }, initial) : await api('POST', 'years/' + this.year + '/sync/' + this.name, { version: -1, group: this.opts.group || '' });
      if (initial) setTimeout(() => this.sync({ meta: 1 }), 50);
      // Rows with no lasting id get one (one quiet write, the first time a file is opened here).
      const noIds = (d.rows || []).some(r => !r._id);
      this.take(d);
      if (!this.opts.readOnly && noIds) {
        const r = await api('POST', 'years/' + this.year + '/rows/' + this.name, { ops: [{ op: 'ids' }] });
        this.take(r);
      }
      this.here = d.here || [];
      // Changes typed here and never confirmed (a tab closed, the connection lost) are sent again.
      try {
        const kept = JSON.parse(localStorage.getItem(this.keepKey()) || 'null');
        if (kept && kept.length && !this.opts.readOnly) { this.pending = kept.map(o => Object.assign(o, { sent: false })); this.send(); }
      } catch (e) { /* nothing kept */ }
      this.loaded = true;
      this.rebuild();
      return this;
    }
    keepKey() { return KEEP + this.year + '-' + this.name; }
    // A blank row kept here (hold) isn't kept past the tab: nothing was typed in it.
    keep() { try { const p = this.pending.filter(o => !o.hold); if (p.length) localStorage.setItem(this.keepKey(), JSON.stringify(p.map(o => Object.assign({}, o, { sent: false })))); else localStorage.removeItem(this.keepKey()); } catch (e) { /* not kept */ } }
    unsaved() { return this.pending.filter(o => !o.hold).length + this.conflicts(); }
    take(d) {
      if (!d || !d.rows) return;
      // A row with no lasting id yet (a held year, read only) gets one here only, to be pointed at.
      this.server = d.rows.map((r, i) => r._id ? copy(r) : Object.assign(copy(r), { _id: '@' + i }));
      this.cols = d.cols || this.cols; this.version = d.version;
      if (d.meta) this.meta = d.meta;
    }
    // The rows as this person sees them: the server's, with their own changes not yet confirmed.
    rebuild() {
      const rows = this.server.map(copy), at = id => rows.findIndex(r => r._id === id);
      this.pending.forEach(o => {
        if (o.op === 'set') { const i = at(o.id); if (i > -1) Object.assign(rows[i], o.fields); }
        else if (o.op === 'add') { if (at(o.row._id) > -1) return; const b = o.before ? at(o.before) : -1; if (b < 0) rows.push(copy(o.row)); else rows.splice(b, 0, copy(o.row)); }
        else if (o.op === 'remove') { const i = at(o.id); if (i > -1) rows.splice(i, 1); }
        else if (o.op === 'move') { const i = at(o.id); if (i < 0) return; const r = rows.splice(i, 1)[0]; const b = o.before ? at(o.before) : -1; if (b < 0) rows.push(r); else rows.splice(b, 0, r); }
      });
      // A field in conflict keeps the person's own text until they choose.
      Object.keys(this.held).forEach(id => { const i = at(id); if (i > -1) Object.keys(this.held[id]).forEach(k => { rows[i][k] = this.held[id][k].mine; }); });
      this.rows = rows;
      return rows;
    }
    get(id) { return this.rows.find(r => r._id === id) || null; }
    serverRow(id) { return this.server.find(r => r._id === id) || null; }

    /* ---------------------------------------------------------- changing */

    // One change from the person: applied here at once, sent a moment later, and remembered for Undo.
    // opts.key: typing in one field is one step of Undo (the same key within a few seconds).
    set(id, fields, opts) {
      opts = opts || {};
      const r = this.get(id);
      if (!r || this.opts.readOnly) return;
      const before = {}, after = {};
      Object.keys(fields).forEach(k => { const was = r[k] == null ? '' : String(r[k]), now = fields[k] == null ? '' : String(fields[k]); if (was !== now) { before[k] = was; after[k] = now; } });
      if (!Object.keys(after).length) return;
      // Typing again in a field in conflict is the person's choice: theirs is the base, mine is sent.
      if (this.held[id]) { Object.keys(after).forEach(k => { delete this.held[id][k]; }); if (!Object.keys(this.held[id]).length) delete this.held[id]; }
      this.queueSet(id, after);
      this.remember({ label: opts.label || 'Change', key: opts.key, undo: [{ op: 'set', id, fields: before }], redo: [{ op: 'set', id, fields: after }] });
      this.changed([id]);
    }
    queueSet(id, fields) {
      // A new row not sent yet: the change goes into the row itself (one request, never a blank row).
      const addOp = this.pending.find(o => o.op === 'add' && o.row._id === id);
      if (addOp && !addOp.sent) { Object.assign(addOp.row, fields); this.rebuild(); if (!addOp.hold) this.soon(); else this.keep(); return; }
      // A row on its way to the server: what it was sent with is the base, not "nothing".
      const s = this.serverRow(id) || (addOp ? addOp.row : null), base = {};
      Object.keys(fields).forEach(k => { base[k] = s ? (s[k] == null ? '' : String(s[k])) : ''; });
      // Joined to a change of the same row not yet sent: one request, the first base kept.
      const last = this.pending[this.pending.length - 1];
      if (last && !last.sent && last.op === 'set' && last.id === id) {
        Object.keys(fields).forEach(k => { if (!(k in last.base)) last.base[k] = base[k]; last.fields[k] = fields[k]; });
      } else this.pending.push({ op: 'set', id, fields: Object.assign({}, fields), base });
      this.rebuild(); this.soon();
    }
    add(row, opts) {
      opts = opts || {};
      if (this.opts.readOnly) return null;
      const r = copy(row); r._id = r._id || tmpId();
      this.pending.push({ op: 'add', row: copy(r), before: opts.before || '', hold: !!opts.hold });
      this.rebuild(); if (!opts.hold) this.soon();
      if (!opts.quiet) this.remember({ label: opts.label || 'Add', undo: [{ op: 'remove', id: r._id }], redo: [{ op: 'add', row: copy(r), before: opts.before || '' }] });
      this.changed([r._id]);
      return r._id;
    }
    remove(id, opts) {
      opts = opts || {};
      const r = this.get(id);
      if (!r || this.opts.readOnly) return;
      const i = this.rows.indexOf(r), next = this.rows[i + 1];
      if (!this.dropUnsent(id)) this.pending.push({ op: 'remove', id });
      this.rebuild(); this.soon();
      if (!opts.quiet) this.remember({ label: opts.label || 'Remove', undo: [{ op: 'add', row: copy(r), before: next ? next._id : '' }], redo: [{ op: 'remove', id }] });
      this.changed([id]);
    }
    move(id, before, opts) {
      opts = opts || {};
      const r = this.get(id);
      if (!r || this.opts.readOnly) return;
      const i = this.rows.indexOf(r), next = this.rows[i + 1];
      this.pending.push({ op: 'move', id, before: before || '' });
      this.rebuild(); this.soon();
      this.remember({ label: opts.label || 'Move', undo: [{ op: 'move', id, before: next ? next._id : '' }], redo: [{ op: 'move', id, before: before || '' }] });
      this.changed([id]);
    }
    // A new row kept here (Add, before anything is typed): is it, let it go to the server, or drop it.
    isHeld(id) { return this.pending.some(o => o.op === 'add' && o.hold && o.row._id === id); }
    release(id) { const o = this.pending.find(x => x.op === 'add' && x.hold && x.row._id === id); if (o) { o.hold = false; this.soon(); } }
    discard(id) {
      const o = this.pending.find(x => x.op === 'add' && x.hold && x.row._id === id);
      if (!o) return null;
      this.dropUnsent(id);
      this.undoes = this.undoes.filter(s => !s.undo.some(u => u.op === 'remove' && u.id === id));
      this.rebuild(); this.changed([id]);
      return copy(o.row);
    }
    // A row that never reached the server: its add (and changes to it) leave the queue. → true if so.
    dropUnsent(id) {
      const o = this.pending.find(x => x.op === 'add' && !x.sent && x.row._id === id);
      if (!o) return false;
      this.pending = this.pending.filter(x => x !== o && !(x.id === id && !x.sent));
      return true;
    }
    // A field in conflict: keep this person's text (sent again, over theirs) or take theirs.
    resolve(id, field, keepMine) {
      const h = this.held[id] && this.held[id][field];
      if (!h) return;
      delete this.held[id][field]; if (!Object.keys(this.held[id]).length) delete this.held[id];
      if (keepMine) this.queueSet(id, { [field]: h.mine });
      else { this.rebuild(); this.setState(this.pending.length ? 'saving' : this.conflicts() ? 'conflict' : 'saved'); }
      this.emit('change', { ids: [id] });
    }
    conflicts() { return Object.keys(this.held).reduce((n, id) => n + Object.keys(this.held[id]).length, 0); }

    // Several changes as one step of Undo (a paste, an import, a bulk change).
    batch(label, fn) {
      const mark = this.undoes.length;
      this.inBatch = true;
      try { fn(); } finally { this.inBatch = false; }
      const steps = this.undoes.splice(mark);
      if (steps.length) this.undoes.push({ label, undo: [].concat.apply([], steps.map(s => s.undo).reverse()), redo: [].concat.apply([], steps.map(s => s.redo)) });
      this.redoes = [];
    }
    remember(step) {
      const now = Date.now(), top = this.undoes[this.undoes.length - 1];
      if (!this.inBatch && step.key && top && top.key === step.key && now - top.at < 4000) {
        // Typing in one field: the step grows, its undo keeps the oldest values.
        step.redo.forEach(o => { const t = top.redo.find(x => x.op === 'set' && x.id === o.id); if (t) Object.assign(t.fields, o.fields); else top.redo.push(o); });
        step.undo.forEach(o => { const t = top.undo.find(x => x.op === 'set' && x.id === o.id); if (t) Object.keys(o.fields).forEach(k => { if (!(k in t.fields)) t.fields[k] = o.fields[k]; }); else top.undo.push(o); });
        top.at = now;
        return;
      }
      step.at = now;
      this.undoes.push(step); if (this.undoes.length > 200) this.undoes.shift();
      if (!this.inBatch) this.redoes = [];
    }
    // Undo puts back only what this person changed: if someone else has changed the same field since,
    // it asks first (returns { blocked: [{ id, field, by }] } without doing it, unless force).
    undo(force) { return this.replay(this.undoes, this.redoes, 'undo', force); }
    redo(force) { return this.replay(this.redoes, this.undoes, 'redo', force); }
    replay(from, to, dir, force) {
      const step = from[from.length - 1];
      if (!step) return null;
      const ops = dir === 'undo' ? step.undo : step.redo, other = dir === 'undo' ? step.redo : step.undo;
      if (!force) {
        // A field another person changed after this person's change.
        const blocked = [];
        ops.forEach(o => {
          if (o.op !== 'set') return;
          const mine = other.find(x => x.op === 'set' && x.id === o.id), r = this.get(o.id);
          if (!mine || !r) return;
          Object.keys(mine.fields).forEach(k => { if (String(r[k] == null ? '' : r[k]) !== String(mine.fields[k])) blocked.push({ id: o.id, field: k, by: (this.meta[o.id] || {}).by || 'someone' }); });
        });
        if (blocked.length) return { blocked, label: step.label };
      }
      from.pop();
      ops.forEach(o => {
        if (o.op === 'set') { if (this.get(o.id)) this.queueSet(o.id, o.fields); }
        else if (o.op === 'add') { if (!this.get(o.row._id)) { this.pending.push({ op: 'add', row: copy(o.row), before: o.before || '' }); } }
        else if (o.op === 'remove') { if (this.get(o.id) && !this.dropUnsent(o.id)) this.pending.push({ op: 'remove', id: o.id }); }
        else if (o.op === 'move') this.pending.push({ op: 'move', id: o.id, before: o.before || '' });
      });
      to.push(step);
      this.rebuild(); this.soon();
      this.changed(ops.map(o => o.id || (o.row && o.row._id)));
      return { done: true, label: step.label };
    }
    changed(ids) { this.keep(); this.emit('change', { ids: ids || [] }); }

    /* ---------------------------------------------------------- sending */

    soon() { if (this.pending.some(o => !o.sent && !o.hold)) this.setState('saving'); clearTimeout(this.timer); this.timer = setTimeout(() => this.send(), 450); }
    flush() { clearTimeout(this.timer); return this.send(); }
    async send() {
      if (this.busy) { this.again = true; return; }
      // Rows kept here (Add, nothing typed yet) and changes to them wait.
      const holdIds = this.pending.filter(o => o.op === 'add' && o.hold).map(o => o.row._id);
      const ops = this.pending.filter(o => !o.sent && !o.hold && holdIds.indexOf(o.id) < 0 && holdIds.indexOf(o.before) < 0);
      if (!ops.length) { if (this.state !== 'error' && this.state !== 'signedout' && this.state !== 'held') this.setState(this.conflicts() ? 'conflict' : 'saved'); return; }
      this.busy = true;
      ops.forEach(o => { o.sent = true; });
      const body = ops.map(o => o.op === 'set' ? { op: 'set', id: o.id, fields: o.fields, base: o.base } : o.op === 'add' ? { op: 'add', row: o.row, before: o.before } : { op: o.op, id: o.id, before: o.before });
      try {
        const d = await api('POST', 'years/' + this.year + '/rows/' + this.name, { ops: body });
        this.wait = 0;
        // New rows' ids, as the server gave them.
        const ids = d.ids || {};
        Object.keys(ids).forEach(a => { if (a !== ids[a]) this.renameId(a, ids[a]); });
        this.pending = this.pending.filter(o => ops.indexOf(o) < 0);
        this.take(d);
        this.rebuild(); this.keep();
        // Someone else changed the same field first: theirs is kept on the server, and the person's
        // own text stays in the box (held) until they choose. Nothing is counted as saved before that.
        const cf = (d.conflicts || []).map(c => Object.assign({ by: (this.meta[c.id] || {}).by || '' }, c));
        cf.filter(c => c.field).forEach(c => { (this.held[c.id] = this.held[c.id] || {})[c.field] = { mine: c.mine, theirs: c.theirs, by: c.by }; });
        if (cf.length) { this.rebuild(); this.emit('conflict', cf); }
        this.emit('change', { ids: [], server: true });
        try { localStorage.setItem('ogc-saved', String(Date.now())); } catch (e) { /* not framed */ }
        this.busy = false;
        this.setState(this.pending.some(o => !o.hold) ? 'saving' : this.conflicts() ? 'conflict' : 'saved');
      } catch (e) {
        ops.forEach(o => { o.sent = false; });
        this.busy = false;
        if (e.status === 403 && e.data && e.data.code === 'rest_cookie_invalid_nonce' && await freshNonce()) return this.send();
        if (e.status === 401 || (e.status === 403 && e.data && /cookie|not_logged/i.test(e.data.code || ''))) { this.setState('signedout'); return; }
        if (e.status === 423) { this.setState('held'); return; }
        if (e.status && e.status < 500 && e.status !== 408 && e.status !== 429) {
          // Refused (a value the server won't keep): the change is taken back here and the reason said.
          this.pending = this.pending.filter(o => ops.indexOf(o) < 0);
          this.rebuild(); this.keep();
          this.emit('change', { ids: [], server: true });
          this.setState('error', { message: e.message, data: e.data });
          return;
        }
        this.setState('offline');
        this.wait = Math.min(30000, this.wait ? this.wait * 2 : 1500);
        clearTimeout(this.retryT);
        this.retryT = setTimeout(() => this.send(), this.wait);
        return;
      }
      if (this.again || this.pending.some(o => !o.sent && !o.hold)) { this.again = false; this.send(); }
    }
    retry() { this.wait = 0; return this.send(); }
    renameId(a, b) {
      this.pending.forEach(o => { if (o.id === a) o.id = b; if (o.before === a) o.before = b; if (o.row && o.row._id === a) o.row._id = b; });
      [this.undoes, this.redoes].forEach(st => st.forEach(s => s.undo.concat(s.redo).forEach(o => { if (o.id === a) o.id = b; if (o.before === a) o.before = b; if (o.row && o.row._id === a) o.row._id = b; })));
      this.emit('ids', { from: a, to: b });
    }

    /* ---------------------------------------------------------- others working */

    // Every 30 seconds, and when the window comes back: who else is here, and what's changed.
    async sync(where) {
      if (this.syncing) return;
      this.syncing = true;
      try {
        const d = await api('POST', 'years/' + this.year + '/sync/' + this.name, Object.assign({ version: this.version }, where || {}));
        this.here = d.here || [];
        this.emit('here', this.here);
        if (d.meta && !d.rows) { this.meta = d.meta; this.emit('remote', { changed: [], gone: [] }); }
        if (d.rows && d.version !== this.version && !this.busy) {
          const old = {}; this.server.forEach(r => { old[r._id] = JSON.stringify(r); });
          this.take(d); this.rebuild();
          const changed = this.server.filter(r => old[r._id] !== JSON.stringify(r)).map(r => r._id);
          const gone = Object.keys(old).filter(id => !this.server.some(r => r._id === id));
          if (changed.length || gone.length) this.emit('remote', { changed, gone });
        }
        if (this.state === 'offline') this.send();
      } catch (e) {
        if (e.status === 401) this.setState('signedout');
        else if (!e.status) this.setState('offline');
      }
      this.syncing = false;
    }
    async history(row) {
      return api('GET', 'years/' + this.year + '/history/' + this.name + '?limit=60' + (row ? '&row=' + encodeURIComponent(row) : ''));
    }
  }
  ED.Rows = Rows;
  ED.api = api;
})();
