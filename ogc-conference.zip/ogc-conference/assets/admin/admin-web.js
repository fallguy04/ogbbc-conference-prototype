/*
 * admin-web.js — the webmasters' page (?role=web): every year, who can sign in for each, what's public,
 * what changed and who changed it, and the year's files to hand on (ED.web).
 *
 * The webmasters keep the site from year to year while each year's COA turns over: they start the next
 * year (one ahead, never an endless button), invite its COA, see the year's activity, export it for the
 * Scheduling Committee, and link the sermons to their services. Members come from the signin area's list
 * (years/{y}/members); starting a year is the year area's (coa/{y}/start).
 */
(function () {
  'use strict';
  const O = window.OGC, esc = O.esc, ED = window.ED, W = window.OGC_WP || {}, CFG = W.editors || {};
  const root = document.getElementById('ogc-admin');
  let X, I;
  const st = { members: null, web: null, log: null, logWho: '', sermons: [], samples: null, older: false, invited: [], removed: null, years: 2, err: '', bad: '' };
  const plural = (n, w) => O.signups && O.signups.plural ? O.signups.plural(n, w) : n + ' ' + w + (n === 1 ? '' : 's');
  const md = iso => iso ? O.fmtDate(String(iso).slice(0, 10), 'md') : '';
  const NOT_YET = '9999-12-31';

  /* ------------------------------------------------------------ the years */

  const withData = () => X.years.filter(y => y.data);
  // The Conference coming up (or on now): the first whose last day hasn't passed.
  const upcoming = () => withData().slice().reverse().find(y => !y.end || y.end >= X.today) || null;
  // Start is offered for one year ahead only: the year after the newest, when that's no further than
  // the year after the one coming up.
  function startable() {
    const newest = withData()[0], up = upcoming(), next = newest ? +newest.year + 1 : null;
    if (!next) return null;
    const limit = up ? +up.year + 1 : +newest.year + 1;
    return next <= limit ? String(next) : null;
  }

  /* ------------------------------------------------------------ drawing */

  async function draw() {
    X = ED.X; I = ED.I;
    X.title('Webmasters');
    paint();
    await load();
    paint();
  }
  async function load() {
    const y = X.year;
    const tasks = [
      ED.api('GET', 'years/' + y + '/members').then(d => { st.members = d; }).catch(e => { st.members = { error: e.status }; }),
      ED.api('GET', 'webmasters').then(d => { st.web = d; }).catch(() => { st.web = null; }),
      ED.api('GET', 'log?year=' + y + '&limit=80').then(d => { st.log = d; }).catch(() => { st.log = []; }),
      ED.api('GET', 'years/' + y + '/sermons-waiting').then(d => { st.sermons = d || []; }).catch(() => { st.sermons = []; }),
      ED.api('GET', 'years/' + y + '/webinfo').then(d => { st.years = +d.invite_years || 2; st.exported = d.exported; st.untouched = d.untouched; }).catch(() => null),
      fetch(O.dataBase(y) + 'settings.csv', { cache: 'no-store' }).then(r => r.text()).then(t => { const S = {}; O.csvToObjects(t).forEach(r => { if (r.key) S[r.key] = r.value; }); st.settings = S; }).catch(() => { st.settings = {}; })
    ];
    if (!CFG.prod) tasks.push(ED.api('GET', 'years/' + y + '/records?kinds=registrations,signups,teams').then(d => { st.samples = Object.keys(d || {}).reduce((n, k) => n + (d[k] || []).filter(r => r.sample).length, 0); }).catch(() => { st.samples = null; }));
    await Promise.all(tasks.filter(Boolean));
  }
  function paint() {
    const r = X.row, me = W.me || {}, who = CFG.short || me.name || me.email || 'Signed in';
    const ys = withData(), shown = st.older ? ys : ys.slice(0, 3), next = startable(), untouched = (CFG.untouched || []).map(String);
    const toggle = '<div class="ed-years"><div class="wk-aud adm-years" role="group" aria-label="Year">' + shown.map(y => '<button type="button" data-year="' + esc(y.year) + '" aria-pressed="' + (y.year === X.year) + '">' + (y.year === X.year ? I.check : '') + esc(y.year) + '</button>').join('') +
      (ys.length > 3 ? '<button type="button" data-earlier aria-expanded="' + st.older + '">' + (st.older ? 'Fewer' : 'Earlier') + '</button>' : '') + '</div>' +
      (next ? '<button type="button" class="wk-btn wk-btn--line wk-btn--small" data-start="' + esc(next) + '">' + I.plus + 'Start ' + esc(next) + '</button>' : '') + '</div>';
    const bar = '<header class="ws-bar ws-bar--page"><div class="ws-bar__in"><div class="ws-title ws-title--home"><p class="wk-kicker">Webmasters</p><h1 tabindex="-1">Annual Conferences</h1></div>' + toggle +
      '<p class="ws-tools ws-who"><span>' + esc(who) + '</span><a href="' + esc(W.logout || '#') + '">Sign out</a></p></div></header>';
    // The year once (its pill); the card says what's known of it. Members are in the main column.
    const main = [yearCard(next, untouched), membersCard(), sermonsCard(), activityCard(), toolsCard()].join('');
    root.innerHTML = '<div class="wk adm ws adm--web ed-web">' + bar + '<div class="ws-body ws-body--page adm-home"><div class="adm-home__main">' + main + '</div><aside class="adm-home__side">' + webmastersCard() + '</aside></div></div>';
  }

  // The year: open it, and what's public (only the moments that have a date or a state).
  function yearCard(next, untouched) {
    const S = st.settings || {}, r = X.row, y = X.year;
    const state = v => !v || v === NOT_YET ? '' : v <= X.today ? 'Since ' + md(v) : 'Opens ' + md(v);
    const pub = [['Announcement', r.coa_announced], ['Schedule', S.schedule_posted], ['Registration', S.registration_opens], ['Volunteer sign-ups', S.signups_posted], ['Packet', S.packet_posted], ['Conference app', r.start ? O.isoAddDays(r.start, -7) : '']].filter(p => state(p[1]));
    const held = r.end && r.end < X.today;
    const line = held ? ['Held', st.exported && st.exported.at ? 'Exported ' + md(st.exported.at) : ''].filter(Boolean).join(' · ') : '';
    // Only what's known: its dates and place when set, and its hosts.
    const when = r.start ? O.fmtDateSpan(r.start, r.end) : '', where = [r.venue || '', r.hosts || ''].filter(Boolean).join(' · ');
    return '<section class="adm-yearcard"><div class="adm-yearcard__top"><div><h2 class="adm-yearcard__h">' + esc(when || 'Dates not set') + '</h2>' + (where || line ? '<p class="adm-yearcard__p">' + esc([where, line].filter(Boolean).join(' · ')) + '</p>' : '') + '</div>' +
      '<a class="wk-btn" href="' + esc(X.yearHref('')) + '">Open the year</a></div>' +
      (pub.length ? '<ul class="adm-yearcard__pub">' + pub.map(p => '<li class="' + (p[1] <= X.today ? 'is-on' : '') + '"><span>' + esc(p[0]) + '</span><small>' + esc(state(p[1])) + '</small></li>').join('') + '</ul>' : '') +
      (untouched.indexOf(y) > -1 || st.untouched ? '<p class="ed-web__undo">Started, nothing in it yet · <button type="button" class="wk-linklike" data-unstart="' + esc(y) + '">Remove ' + esc(y) + '</button></p>' : '') + '</section>';
  }

  /* ------------------------------------------------------------ members (the signin area's list) */

  // One date style everywhere: "Oct 3" (the list may say "October 10" or "2026-10-10").
  const MON = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  const day = v => { v = String(v || ''); if (/^\d{4}-\d{2}-\d{2}/.test(v)) return O.fmtDate(v.slice(0, 10), 'mdShort') + (v.slice(0, 4) !== X.today.slice(0, 4) ? ', ' + v.slice(0, 4) : ''); return MON.reduce((t, m) => t.replace(new RegExp('\\b' + m + '\\b'), m.slice(0, 3)), v); };
  function membersCard() {
    // One Members component for the COA and the webmasters, with one set of words (the signin area's
    // assets/signin/ogc-members.js: a table with the chosen member beside it on a laptop).
    if (window.OGC_MEMBERS) return '<section class="adm-sec ed-members" data-ogc-members="' + esc(X.year) + '" data-om-full aria-label="Members"></section>';
    const m = st.members;
    const head = '<div class="wk-bar"><h2 class="wk-h" id="ed-members-h">Members</h2>';
    if (!m) return '<section class="adm-sec ed-members" aria-labelledby="ed-members-h">' + head + '</div><p class="ed-dim">Loading</p></section>';
    if (m.error) return '<section class="adm-sec ed-members" aria-labelledby="ed-members-h">' + head + '</div><p class="ed-dim">Couldn’t load · <button type="button" class="wk-linklike" data-reload>Retry</button></p></section>';
    const list = (m.members || []).filter(x => !x.removed || (st.removed && st.removed.id === x.id));
    // Access is said once, for most; a member whose access ends at another time says so on their row.
    const untils = list.map(x => x.until || '').filter(Boolean), common = untils.slice().sort((a, b) => untils.filter(v => v === b).length - untils.filter(v => v === a).length)[0] || '';
    const row = x => {
      const status = x.expired ? 'Access ended' : x.signed_in ? 'Signed in ' + day(x.signed_in) : 'Invited ' + day(x.invited) + ' · Not signed in';
      const fresh = st.invited.indexOf(x.id) > -1, can = x.can || {};
      const acts = (can.resend && !x.signed_in && !x.expired ? '<button type="button" class="wk-linklike" data-resend="' + x.id + '" title="A new sign-in email">Resend</button>' : '') +
        (can.renew && (x.ending || x.expired) ? '<button type="button" class="wk-linklike" data-renew="' + x.id + '" title="One more year">Renew</button>' : '') +
        (can.remove ? '<button type="button" class="wk-linklike ed-danger" data-mremove="' + x.id + '">Remove</button>' : '');
      // An address may break after its @ and dots, never mid-word.
      const addr = e => esc(e).replace(/([@.])/g, '$1<wbr>');
      return '<tr class="ed-member' + (fresh ? ' is-new' : '') + '"><td><b>' + (x.name ? esc(x.name) : addr(x.email)) + (x.you ? ' <small>(you)</small>' : '') + '</b>' + (x.name ? '<small>' + addr(x.email) + '</small>' : '') + '</td>' +
        '<td>' + esc(x.role === 'coa' ? 'COA' : 'Helper') + (x.helps ? '<small>' + esc(x.helps) + '</small>' : '') + '</td>' +
        '<td>' + esc(status) + (x.until && x.until !== common ? '<small>Until ' + esc(day(x.until)) + '</small>' : x.ending ? '<small>Ends soon</small>' : '') + '</td><td class="ed-member__a">' + acts + '</td></tr>';
    };
    const yrs = [1, 2, 3], web = m.viewer && m.viewer.webmaster;
    return '<section class="adm-sec ed-members" aria-labelledby="ed-members-h">' + head + (common ? '<p class="vol-count" title="After the Conference’s last day; each member can be renewed">Access until ' + esc(day(common)) + '</p>' : '') + '</div>' +
      '<p class="adm-side__p">The COA and their helpers · Each sees and changes everything for ' + esc(X.year) + '</p>' +
      (st.msg ? '<p class="ed-ok" role="status">' + I.check + esc(st.msg) + '</p>' : '') +
      (list.length ? '<div class="ed-memberwrap"><table class="ed-table ed-membertable"><thead><tr><th scope="col">Name</th><th scope="col">Role</th><th scope="col">Status</th><th scope="col"><span class="ogc-sr">Actions</span></th></tr></thead><tbody>' + list.map(row).join('') + '</tbody></table></div>' : '<p class="ed-dim">Nobody yet</p>') +
      (m.viewer && m.viewer.invite ? (st.inviting || !list.length || st.err ? '<form class="adm-form ed-invite" data-invite novalidate><h3 class="ed-h3">Invite</h3>' +
        (web ? '<div class="ed-f" role="group" aria-label="As"><span class="ed-f__l">As</span><span class="rf-seg ed-pills">' + [['helper', 'Helper'], ['coa', 'COA']].map(o => '<button type="button" data-role="' + o[0] + '" aria-pressed="' + ((st.role || 'helper') === o[0]) + '">' + ((st.role || 'helper') === o[0] ? I.check : '') + o[1] + '</button>').join('') + '</span></div>' : '') +
        '<label class="ed-f"><span class="ed-f__l">Emails</span><textarea class="ed-in" name="emails" rows="3" placeholder=" " aria-describedby="ed-inv-help ed-inv-err">' + esc(st.bad) + '</textarea>' +
        (st.err ? '<small class="ed-err" id="ed-inv-err" role="alert">' + esc(st.err) + '</small>' : '<small id="ed-inv-err" hidden></small>') + '<small class="ed-help is-on" id="ed-inv-help">One a line, or separated by commas</small></label>' +
        '<label class="ed-f"><span class="ed-f__l">Helps with</span><input class="ed-in" name="helps" list="ed-helps" placeholder=" " autocomplete="off"><small class="ed-help is-on">Optional, like Lodging · Everyone sees everything for the year</small></label><datalist id="ed-helps">' + (m.helps || []).map(h => '<option value="' + esc(h) + '">').join('') + '</datalist>' +
        (web ? '<div class="ed-f" role="group" aria-label="Access lasts"><span class="ed-f__l">Access lasts</span><span class="rf-seg ed-pills">' + yrs.map(n => '<button type="button" data-years="' + n + '" aria-pressed="' + (st.years === n) + '">' + (st.years === n ? I.check : '') + plural(n, 'year') + '</button>').join('') + '</span><small class="ed-help is-on">After the Conference’s last day · ' + (st.yearsSaved ? 'Saved for new invites' : 'For new invites; each member can be renewed') + '</small></div>' : '') +
        '<p class="wk-sheet__btns"><button type="submit" class="wk-btn wk-btn--line wk-btn--small" title="Each gets their own sign-in email">' + I.mail + 'Invite</button><button type="button" class="wk-linklike" data-emailpreview>Preview email</button>' + (list.length ? '<button type="button" class="wk-linklike" data-inviteoff>Cancel</button>' : '') + '</p></form>'
        : '<p class="ed-btns"><button type="button" class="wk-btn wk-btn--line wk-btn--small" data-inviteon>' + I.plus + 'Invite</button></p>') : '') +
      '<p class="adm-side__p"><button type="button" class="wk-linklike" data-copysignin>Copy sign-in address</button> · <button type="button" class="wk-linklike" data-mhistory>History</button></p>' +
      (st.mhist ? '<ul class="ed-actlist">' + st.mhist.slice(0, 15).map(h => '<li><span>' + esc(h.words) + '</span><small>' + esc(day(h.at)) + '</small></li>').join('') + '</ul>' : '') + '</section>';
  }

  /* ------------------------------------------------------------ webmasters */

  function webmastersCard() {
    const w = st.web;
    if (!w) return '';
    return '<section class="adm-side ed-webmasters" aria-labelledby="ed-wm-h"><h2 class="adm-side__h" id="ed-wm-h" title="Every year’s access · Adding or removing one needs a second webmaster">Webmasters</h2><ul class="ed-memberlist">' +
      w.list.map(x => '<li class="ed-member"><div class="ed-member__t"><b>' + esc(x.name || x.email) + (x.me ? ' <small>(you)</small>' : '') + '</b>' + (x.name ? '<small>' + esc(x.email) + '</small>' : '') + '<small class="ed-member__s">' + (x.last ? 'Signed in ' + esc(day(x.last)) : 'Not signed in yet') + (x.admin ? ' · Site admin' : '') + '</small></div><p class="ed-member__a">' + (!x.me && !x.admin ? '<button type="button" class="wk-linklike ed-danger" data-wmremove="' + esc(x.email) + '">Remove</button>' : '') + '</p></li>').join('') + '</ul>' +
      (w.asks.length ? '<ul class="ed-asks">' + w.asks.map(a => '<li><span>' + (a.act === 'add' ? 'Add ' : 'Remove ') + esc(a.email) + ' <small>Requested by ' + esc(a.by) + '</small></span>' + (a.mine ? '<small>Waiting for a second webmaster</small><button type="button" class="wk-linklike" data-wmcancel="' + esc(a.email) + '">Cancel</button>' : '<button type="button" class="wk-btn wk-btn--small" data-wmconfirm="' + esc(a.email) + '">Confirm</button>') + '</li>').join('') + '</ul>' : '') +
      '<form class="ed-wmadd" data-wmadd><label class="ed-f"><span class="ed-f__l">Add a webmaster</span><input class="ed-in" type="email" name="email" placeholder=" " autocomplete="off"><small class="ed-help is-on">A second webmaster confirms</small></label><button type="submit" class="wk-btn wk-btn--line wk-btn--small">Request</button></form></section>';
  }

  /* ------------------------------------------------------------ activity */

  const ACT = {
    rows: 'changed', file_put: 'saved', file_row: 'changed', file_key: 'changed', change: 'changed', year_set: 'changed the dates or place', year_start: 'started the year', year_unstart: 'removed the started year',
    publish: 'published', export: 'exported the year', import: 'imported the seed', dev_import: 'imported the seed', seed: 'imported the seed', recode: 'renamed place codes', samples_clear: 'cleared the samples', state_put: 'changed', record_add: 'added a record', record_set: 'changed a record', record_remove: 'removed a record'
  };
  const NAMES = { schedule: 'the schedule', shifts: 'the shifts', tournaments: 'the tournaments', rooms: 'the dorm halls', places: 'buildings and rooms', nearby: 'care nearby', help: 'the Help cards', notices: 'the notices', contacts: 'the numbers', settings: 'the settings', registration: 'registration', guide: 'the packet', menus: 'the menus', needs: 'the requests', notes: 'the notes', committees: 'the committees', attachments: 'the recordings' };
  function activityCard() {
    const log = st.log;
    if (!log || !log.length) return '';
    const words = e => {
      const M = { member_invite: 'invited a member', member_remove: 'removed a member', member_restore: 'restored a member', member_resend: 'sent a new sign-in link', member_renew: 'renewed a member', member_label: 'changed what a member helps with', member_name: 'changed a member’s name', member_role: 'changed a member’s role', member_email: 'changed a member’s address', committee_add: 'added a committee', member_signin: 'signed in', member_ending: 'was told access ends soon', member: 'changed the members', links_carried: 'moved what was pinned to a row', webmaster_ask: 'asked to change the webmasters', webmaster_add: 'added a webmaster', webmaster_remove: 'removed a webmaster', mail_refused: 'email refused · limit' };
      if (M[e.action]) return M[e.action];
      const a = ACT[e.action] || e.action.replace(/_/g, ' ');
      return a + (NAMES[e.target] && !/seed/.test(a) ? ' ' + NAMES[e.target] : '');
    };
    const who = Array.from(new Set(log.map(e => e.who || 'Someone')));
    // The same change by the same person, one after another, is one line ("× 7").
    const shown = [];
    log.filter(e => !st.logWho || (e.who || 'Someone') === st.logWho).filter(e => !/^(state_put|record_)/.test(e.action)).forEach(e => {
      const last = shown[shown.length - 1], w = words(e);
      if (last && last.who === (e.who || 'Someone') && last.w === w) { last.n++; last.first = e.at; return; }
      shown.push({ who: e.who || 'Someone', w, at: e.at, first: e.at, n: 1 });
    });
    const more = shown.length > 8 && !st.allLog;
    shown.splice(st.allLog ? 40 : 8);
    return '<section class="adm-sec ed-activity" aria-labelledby="ed-act-h"><div class="wk-bar"><h2 class="wk-h" id="ed-act-h">Activity</h2>' + (who.length > 1 ? '<span class="rf-seg ed-pills" role="group" aria-label="Who">' + [''].concat(who).map(w => '<button type="button" data-logwho="' + esc(w) + '" aria-pressed="' + (st.logWho === w) + '">' + (st.logWho === w ? I.check : '') + esc(w || 'Everyone') + '</button>').join('') + '</span>' : '') + '</div>' +
      '<ul class="ed-actlist">' + shown.map(e => '<li><span><b>' + esc(e.who) + '</b> ' + esc(e.w) + (e.n > 1 ? ' <small>× ' + e.n + '</small>' : '') + '</span><small>' + esc(when(e.at)) + '</small></li>').join('') + '</ul>' + (more ? '<p class="ed-btns"><button type="button" class="wk-linklike" data-alllog>Show more</button></p>' : '') + '</section>';
  }
  const when = at => { if (!at) return ''; const d = new Date(String(at).replace(' ', 'T') + 'Z'); return O.fmtDate(d.toISOString().slice(0, 10), 'mdShort') + ', ' + d.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' }); };

  /* ------------------------------------------------------------ sermons to link */

  // Sermons posted on the site that aren't pinned to their service yet (none until the sermon post type
  // and series are there). One filled action: the first waiting sermon's suggestion.
  let model = null;
  function suggestFor(s) {
    if (!model) return null;
    const d = model.days.find(x => x.date === s.date);
    if (!d) return null;
    const svc = d.items.filter(it => /^(worship|council|communion|teaching)$/.test(it.kind) && it.start != null);
    const t = s.time ? O.parseTime(s.time) : null;
    return (t == null ? svc.find(it => it.kind === 'worship') : svc.filter(it => it.start <= t + 20).pop()) || svc[0] || null;
  }
  function sermonsCard() {
    const list = st.sermons || [];
    if (!list.length) return '';
    return '<section class="adm-sec"><div class="wk-bar"><h2 class="wk-h">Sermons to link</h2><p class="vol-count">' + plural(list.length, 'waiting') + '</p></div><div class="adm-sermons">' + list.map((s, i) => {
      const it = suggestFor(s);
      return '<section class="adm-sermon"><p class="adm-mname">' + esc(s.title) + '</p><p class="adm-mwhat">' + esc([s.by, md(s.date)].filter(Boolean).join(' · ')) + '</p>' +
        (it ? '<p class="adm-suggest">' + esc(O.fmtDate(it.date, 'long') + ', ' + O.formatTime(it.start) + ' ' + it.title) + '</p>' : '') +
        '<p class="wk-hcard__btn">' + (it ? '<button type="button" class="' + (i ? 'wk-btn wk-btn--line wk-btn--small' : 'wk-btn wk-btn--small') + '" data-link="' + i + '">Link</button>' : '') + '<button type="button" class="wk-linklike" data-choose="' + i + '">Choose another</button></p></section>';
    }).join('') + '</div></section>';
  }

  /* ------------------------------------------------------------ the year's files, samples, older years */

  function toolsCard() {
    const y = X.year, exp = (W.rest || '/wp-json/ogc/v1/') + 'years/' + y + '/export?_wpnonce=' + encodeURIComponent(W.nonce || '');
    const sample = !CFG.prod && st.samples != null ? '<li class="ogc-mock-row"><span><b>Sample data</b><small>' + (st.samples ? plural(st.samples, 'made-up record') : 'None') + '</small></span>' + (st.samples ? '<button type="button" class="wk-linklike" data-clearsamples>Clear</button>' : '') + (W.dev ? '<button type="button" class="wk-linklike" data-loadseed>Load</button>' : '') + '</li>' : '';
    // Years before the site kept them (no data): facts only, past years only, each a line with Edit.
    const older = X.years.filter(z => !z.data && +z.year < +X.today.slice(0, 4));
    return '<section class="adm-sec ed-tools2"><div class="wk-bar"><h2 class="wk-h">Files</h2></div><ul class="ed-toollist">' +
      '<li><span><b>Export ' + esc(y) + '</b><small>Every part as spreadsheets, in one zip · Never people’s records</small></span><a class="wk-linklike" href="' + esc(exp) + '" data-export>Export</a></li>' + sample + '</ul>' +
      (older.length ? '<details class="ed-older"' + (st.olderOpen ? ' open' : '') + '><summary>Older years · ' + older.length + '</summary><ul class="ed-olderlist">' +
        older.map(z => st.olderEdit === z.year ? '<li class="is-edit"><b>' + esc(z.year) + '</b><div class="ed-olderform">' + [['start', 'First day'], ['end', 'Last day'], ['venue', 'Place'], ['hosts', 'Hosts']].map(k => '<label class="ed-f"><span class="ed-f__l">' + k[1] + '</span><input class="ed-in" ' + (k[0] === 'start' || k[0] === 'end' ? 'type="date"' : '') + ' data-older="' + esc(z.year) + '" data-k="' + k[0] + '" value="' + esc(z[k[0]] || '') + '"></label>').join('') + '</div><button type="button" class="wk-linklike" data-olderdone>Done</button></li>'
          : '<li><b>' + esc(z.year) + '</b><span>' + esc([z.start ? O.fmtDateSpan(z.start, z.end) : '', z.venue || '', z.hosts || ''].filter(Boolean).join(' · ') || 'Nothing kept') + '</span>' + (X.webmaster ? '<button type="button" class="wk-linklike" data-olderedit="' + esc(z.year) + '">Edit</button>' : '') + '</li>').join('') + '</ul></details>' : '') + '</section>';
  }

  /* ------------------------------------------------------------ events */

  async function refreshMembers(msg) { try { st.members = await ED.api('GET', 'years/' + X.year + '/members'); } catch (e) { /* kept */ } st.msg = msg || ''; paint(); }
  root.addEventListener('click', async e => {
    if (X && X.edit) return;
    const b = e.target.closest('button, a[data-export]');
    if (!b || !ED.X || ED.X.edit) return;
    const d = b.dataset;
    if (d.year) { X.year = d.year; X.row = X.years.find(y => y.year === d.year) || { year: d.year }; const u = new URL(location.href); u.searchParams.set('year', d.year); history.replaceState(null, '', u); st.members = null; st.invited = []; st.msg = ''; st.err = ''; paint(); await load(); paint(); const t = root.querySelector('[data-year="' + d.year + '"]'); if (t) t.focus(); return; }
    if (b.hasAttribute('data-earlier')) { st.older = !st.older; paint(); return; }
    if (b.hasAttribute('data-reload')) { await load(); paint(); return; }
    if (d.start) { startSheet(d.start); return; }
    if (d.unstart) { if (!confirmIn(b, 'Remove ' + d.unstart + '?')) return; try { await ED.api('DELETE', 'years/' + d.unstart + '/started'); location.href = location.pathname + '?role=web'; } catch (x) { X.toast('Couldn’t remove · ' + (x.message || '')); } return; }
    if (d.years) { st.years = +d.years; st.yearsSaved = true; if (O.state) O.state.set(X.year, 'invite_years', st.years); paint(); setTimeout(() => { st.yearsSaved = false; }, 2500); const t = root.querySelector('[data-years="' + d.years + '"]'); if (t) t.focus(); return; }
    if (b.hasAttribute('data-inviteon')) { st.inviting = true; paint(); const t = root.querySelector('[data-invite] textarea'); if (t) t.focus(); return; }
    if (b.hasAttribute('data-inviteoff')) { st.inviting = false; st.err = ''; st.bad = ''; paint(); const t = root.querySelector('[data-inviteon]'); if (t) t.focus(); return; }
    if (d.olderedit) { st.olderEdit = d.olderedit; st.olderOpen = true; paint(); const t = root.querySelector('[data-older="' + d.olderedit + '"]'); if (t) t.focus(); return; }
    if (b.hasAttribute('data-olderdone')) { st.olderEdit = ''; paint(); return; }
    if (d.role) { st.role = d.role; paint(); const t = root.querySelector('[data-role="' + d.role + '"]'); if (t) t.focus(); return; }
    if (d.resend) { try { await ED.api('POST', 'members/' + d.resend + '/resend'); X.toast('Sent'); } catch (x) { X.toast(x.message || 'Couldn’t send'); } return; }
    if (d.renew) { try { await ED.api('PATCH', 'members/' + d.renew, { renew: true }); await refreshMembers('Renewed'); } catch (x) { X.toast(x.message || 'Couldn’t renew'); } return; }
    if (d.mremove) {
      const id = +d.mremove, m = (st.members.members || []).find(x => x.id === id);
      try { await ED.api('DELETE', 'members/' + id); await refreshMembers(); X.toast('Removed ' + (m ? m.name || m.email : ''), ['Undo', async () => { await ED.api('PATCH', 'members/' + id, { restore: true }).catch(x => X.toast(x.message || 'Couldn’t undo')); refreshMembers('Restored'); }]); } catch (x) { X.toast(x.message || 'Couldn’t remove'); }
      return;
    }
    if (b.hasAttribute('data-copysignin')) { const a = 'https://' + ((st.members && st.members.signin) || location.host + (W.signin || '/annual-conference/signin/')); try { await navigator.clipboard.writeText(a); X.toast('Copied · ' + a); } catch (x) { X.toast(a); } return; }
    if (b.hasAttribute('data-mhistory')) { st.mhist = st.mhist ? null : await ED.api('GET', 'years/' + X.year + '/members/history').catch(() => []); paint(); return; }
    if (b.hasAttribute('data-emailpreview')) { preview(); return; }
    if (d.wmremove) { st.web = await ED.api('POST', 'webmasters', { email: d.wmremove, act: 'remove' }).catch(x => { X.toast(x.message); return st.web; }); paint(); X.toast('Waiting for a second webmaster'); return; }
    if (d.wmcancel) { st.web = await ED.api('POST', 'webmasters', { email: d.wmcancel, cancel: true }).catch(() => st.web); paint(); return; }
    if (d.wmconfirm) { st.web = await ED.api('POST', 'webmasters/confirm', { email: d.wmconfirm }).catch(x => { X.toast(x.message); return st.web; }); paint(); X.toast('Confirmed'); return; }
    if (d.logwho != null) { st.logWho = d.logwho; paint(); return; }
    if (b.hasAttribute('data-alllog')) { st.allLog = true; paint(); return; }
    if (d.link != null) { await linkSermon(+d.link, null); return; }
    if (d.choose != null) { chooseSheet(+d.choose); return; }
    if (b.hasAttribute('data-clearsamples')) { if (!confirmIn(b, 'Clear ' + plural(st.samples, 'record') + '?')) return; await ED.api('DELETE', 'years/' + X.year + '/samples').catch(x => X.toast(x.message)); await load(); paint(); X.toast('Samples cleared'); return; }
    if (b.hasAttribute('data-loadseed')) { if (!confirmIn(b, 'Load the seed for ' + X.year + '? (local only)')) return; await ED.api('POST', 'dev/import', { force: +X.year }).catch(x => X.toast(x.message)); await load(); paint(); X.toast('Loaded'); return; }
    if (d.export != null) setTimeout(() => { load().then(paint); }, 1500);
  });
  // Two steps for anything that can't be taken back: the button asks once more.
  function confirmIn(b, q) {
    if (b.dataset.sure) return true;
    b.dataset.sure = '1'; const was = b.textContent; b.textContent = q.replace(/\?$/, '') + ' · Yes';
    setTimeout(() => { if (b.isConnected) { delete b.dataset.sure; b.textContent = was; } }, 5000);
    return false;
  }
  root.addEventListener('submit', async e => {
    if (!ED.X || ED.X.edit) return;
    const f = e.target;
    e.preventDefault();
    if (f.hasAttribute('data-invite')) {
      const text = f.elements.emails.value, helps = f.elements.helps.value;
      if (!text.trim()) { st.err = 'Type an email address'; st.bad = ''; paint(); root.querySelector('[data-invite] textarea').focus(); return; }
      try {
        const r = await ED.api('POST', 'years/' + X.year + '/members', { emails: text, helps, years: st.years, role: st.role || 'helper' });
        st.members = r.list; st.invited = r.added || [];
        // Errors at the field: the lines that weren't addresses stay in the box.
        st.bad = (r.bad || []).join('\n');
        st.err = r.bad && r.bad.length ? r.bad.slice(0, 3).join(', ') + (r.bad.length > 1 ? ' aren’t email addresses' : ' isn’t an email address') : '';
        st.msg = r.added && r.added.length ? 'Invited ' + r.added.length + (r.already && r.already.length ? ' · ' + r.already.length + ' already here' : '') : r.already && r.already.length ? r.already.length + ' already here' : '';
        paint();
        setTimeout(() => { st.invited = []; st.msg = ''; const el = root.querySelector('.ed-ok'); if (el) el.remove(); root.querySelectorAll('.ed-member.is-new').forEach(x => x.classList.remove('is-new')); }, 6000);
        if (st.err) root.querySelector('[data-invite] textarea').focus();
      } catch (x) {
        st.err = x.message || 'Couldn’t invite'; st.bad = text; paint(); root.querySelector('[data-invite] textarea').focus();
      }
      return;
    }
    if (f.hasAttribute('data-wmadd')) {
      const email = f.elements.email.value.trim();
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) { X.toast(email ? email + ' isn’t an email address' : 'Type an email address'); return; }
      st.web = await ED.api('POST', 'webmasters', { email, act: 'add' }).catch(x => { X.toast(x.message); return st.web; });
      paint(); X.toast('Waiting for a second webmaster');
    }
  });
  root.addEventListener('change', async e => {
    const t = e.target;
    if (!t.dataset || !t.dataset.older || !X.webmaster) return;
    try { await ED.api('PATCH', 'years/' + t.dataset.older, { fields: { [t.dataset.k]: t.value } }); X.toast('Saved · ' + t.dataset.older); const z = X.years.find(y => y.year === t.dataset.older); if (z) z[t.dataset.k] = t.value; st.olderOpen = true; } catch (x) { X.toast(x.message || 'Couldn’t save'); }
  });

  /* ------------------------------------------------------------ sheets */

  const sheet = () => {
    let dlg = document.querySelector('dialog.ed-websheet');
    if (!dlg) { dlg = document.createElement('dialog'); dlg.className = 'ogc wk-sheet ed-websheet'; dlg.setAttribute('aria-labelledby', 'ed-ws-h'); document.body.appendChild(dlg); dlg.addEventListener('click', ev => { if (ev.target === dlg || ev.target.closest('[data-x]')) dlg.close(); }); }
    return dlg;
  };
  const show = (title, body) => { const dlg = sheet(); dlg.innerHTML = '<div class="wk-sheet__in"><button type="button" class="wk-sheet__x" data-x aria-label="Close">' + I.close + '</button><h2 class="wk-sheet__h" id="ed-ws-h">' + esc(title) + '</h2>' + body + '</div>'; if (!dlg.open) dlg.showModal(); return dlg; };
  function startSheet(ny) {
    const row = X.years.find(y => y.year === ny) || {}, from = withData()[0].year;
    const dlg = show('Start ' + ny, (row.hosts ? '<p class="adm-help">' + esc(row.hosts) + (row.venue ? ' · ' + esc(row.venue) : '') + '</p>' : '<label class="ed-f"><span class="ed-f__l">Hosts</span><input class="ed-in" name="hosts" placeholder=" " autocomplete="off"><small class="ed-help is-on">Like Ohio and Tennessee districts</small></label>') +
      '<div class="adm-copy"><div><h3 class="wk-eyebrow">From ' + esc(from) + ', once it’s held</h3><ul><li>Each part, to check</li><li>Buildings, halls and care nearby, from the last Conference at the campus</li></ul></div><div><h3 class="wk-eyebrow">Starts fresh</h3><ul><li>Dates and place</li><li>Members</li><li>Registrations and sign-ups</li></ul></div></div>' +
      '<p class="wk-sheet__btns"><button type="button" class="wk-btn" data-make="' + esc(ny) + '">Start ' + esc(ny) + '</button></p>');
    dlg.querySelector('[data-make]').onclick = async () => {
      const h = dlg.querySelector('[name=hosts]');
      try {
        await ED.api('POST', 'coa/' + ny + '/start', h && h.value.trim() ? { hosts: h.value.trim() } : {});
        await ED.api('POST', 'years/' + ny + '/started').catch(() => null);
        location.href = location.pathname + '?role=web&year=' + ny;
      } catch (x) { X.toast(x.message || 'Couldn’t start'); }
    };
  }
  async function preview() {
    try {
      const p = await ED.api('GET', 'years/' + X.year + '/members/preview?role=' + (st.role || 'helper') + '&years=' + st.years);
      const dlg = show('The sign-in email', '<p class="adm-help"><b>Subject:</b> ' + esc(p.subject) + '</p><iframe class="ed-mailpv" title="The email" sandbox></iframe>');
      dlg.querySelector('iframe').srcdoc = p.html || '<pre>' + esc(p.text || '') + '</pre>';
    } catch (x) { X.toast(x.message || 'No preview'); }
  }
  async function chooseSheet(i) {
    const s = st.sermons[i];
    if (!model && X.row.data) model = await ED.loadYear(X.row.data);
    const days = (model ? model.days : []).map(d => ({ d, svc: d.items.filter(it => /^(worship|council|communion|teaching)$/.test(it.kind) && it.start != null) })).filter(x => x.svc.length);
    const dlg = show('Choose a service', '<p class="adm-help">' + esc(s.title) + '</p>' + days.map(x => '<h3 class="ed-h3">' + esc(O.fmtDate(x.d.date, 'long')) + '</h3><ul class="ed-choose">' + x.svc.map(it => '<li><button type="button" class="wk-linklike" data-pickday="' + esc(x.d.name) + '" data-picktime="' + esc(O.formatTime(it.start)) + '" data-picktitle="' + esc(it.title) + '"><span>' + esc(O.formatTime(it.start)) + '</span> ' + esc(it.title) + '</button></li>').join('') + '</ul>').join(''));
    dlg.onclick = ev => { const b = ev.target.closest('[data-pickday]'); if (b) { dlg.close(); linkSermon(i, { day: b.dataset.pickday, start: b.dataset.picktime, title: b.dataset.picktitle }); } else if (ev.target === dlg || ev.target.closest('[data-x]')) dlg.close(); };
  }
  async function linkSermon(i, to) {
    const s = st.sermons[i];
    if (!to) { if (!model && X.row.data) model = await ED.loadYear(X.row.data); const it = suggestFor(s); if (!it) return; to = { day: model.days.find(d => d.date === it.date).name, start: O.formatTime(it.start), title: it.title }; }
    try {
      await ED.api('POST', 'years/' + X.year + '/rows/attachments', { ops: [{ op: 'add', row: { day: to.day, start: to.start, match: to.title, kind: 'sermon', title: s.title, by: s.by || '', url: s.url, posted: s.date } }] });
      st.sermons.splice(i, 1); paint(); X.toast('Linked to ' + to.title);
    } catch (x) { X.toast(x.message || 'Couldn’t link'); }
  }

  ED.web = { draw: () => { draw().then(() => { if (X.row.data) ED.loadYear(X.row.data).then(m => { model = m; if (st.sermons.length) paint(); }).catch(() => null); }); } };
})();
