/*
 * admin-read.js — reading a schedule the way the COA writes it (Michael, Oct 8: editing the schedule was
 * "constricting and fiddly and confusing"; take "10–11:30 Worship, Chapel" as written).
 *
 *   ED.read.line(text, ctx)    one typed line → { row, guess, unknown, day }
 *   ED.read.when(text, ctx)    the When field → { start, end, sort_time, words, guess, parts }
 *   ED.read.paste(text, ctx)   pasted lines or a spreadsheet's rows → { rows: [{ row, guess, line }], unread: [lines] }
 *   ED.read.span(a, b)         minutes → "2–8 PM", "Noon–11 PM", "11 PM–Midnight" (as people type them)
 *
 * ctx = { days: [{ name, date }], places: [{ code, name, building }], day: 'Saturday' (the day being
 * edited), titles: ['Communion', …] (the year's rows, for "After Communion"), last: { title → [minutes] }
 * (last year's starts for a title), dayRows (the day's rows, for where "After Communion" falls), audience }.
 * A missing AM or PM is guessed from the title's words, then last year's row of the same name, then the
 * hour; a guess is said as one (guess.ampm), so the page can offer the other half with one tap.
 * No DOM here: tools can run it in Node (NOTES/editors.md).
 */
(function (root) {
  'use strict';
  const ED = root.ED = root.ED || {};

  /* ------------------------------------------------------------ times */

  // A clock time as written: "7", "7:30", "10:00:00 AM", "7:30p", "22:00", "noon", "midnight".
  const TM = '(\\d{1,2}(?::\\d{2}){0,2}|noon|midnight)\\s*(a\\.?\\s?m\\.?|p\\.?\\s?m\\.?|a|p)?(?![a-z])';
  const SEP = '\\s*(?:-|–|—|to|until|till|thru)\\s*';
  const RANGE = new RegExp('^' + TM + '(?:' + SEP + TM + ')?', 'i');
  const OPEN_END = /^(?:\s*(?:-|–|—)\s*\?|\s+(?:until|till)\s+(?:done|finished|it'?s? (?:done|over)|over))(?![a-z])/i;

  function clock(num, ap) {
    num = String(num).toLowerCase();
    if (num === 'noon') return { m: 720, fixed: true };
    if (num === 'midnight') return { m: 1440, fixed: true };
    const p = num.split(':'), h = +p[0], min = p[1] ? +p[1] : 0;
    if (h > 24 || min > 59) return null;
    if (ap) {
      if (h < 1 || h > 12) return null;
      return { m: ((h % 12) + (/^p/i.test(ap) ? 12 : 0)) * 60 + min, fixed: true };
    }
    // 0:30, 13:00 and up, or a leading zero ("07:00") are 24-hour times.
    if (h === 0 || h > 12 || /^0\d/.test(p[0])) return { m: h * 60 + min, fixed: true };
    return { h, min, fixed: false };
  }

  // Words that say which half of the day a row is in: some say it outright ("Evening", "Breakfast"),
  // some only lean ("Hymn sing" is nearly always at night; a sunrise song service says so itself).
  const PM_WORDS = /\b(evening|night|nightly|supper|dinner|bedtime|lights out|curfew)\b/i;
  const AM_WORDS = /\b(sunrise|breakfast|morning|wake|devotions? before breakfast|check-?out)\b/i;
  const PM_LEAN = /\b(snack|dismissal|quiet time|social|pick ?up children|campfire|sing|singing|hymns?|hymn sing|song service)\b/i;

  // Which half of the day an hour written without AM or PM means, and why.
  function half(c, title, ctx, endFixed) {
    const am = (c.h % 12) * 60 + c.min, pm = am + 720;
    if (endFixed != null) return { m: pm <= endFixed ? pm : am, why: '' };
    const t = String(title || '');
    if (c.h === 12) return { m: 720 + c.min, why: '' };
    if (AM_WORDS.test(t) && !PM_WORDS.test(t)) return { m: am, why: 'title' };
    if (PM_WORDS.test(t)) return { m: pm, why: 'title' };
    // Last year's rows of the same name: the half nearest one of them.
    const was = ctx && ctx.last && ctx.last[String(t).trim().toLowerCase()];
    if (was != null && [].concat(was).length) {
      const near = m => Math.min.apply(null, [].concat(was).map(w => Math.abs(w - m)));
      return { m: near(am) <= near(pm) ? am : pm, why: 'last year' };
    }
    if (PM_LEAN.test(t)) return { m: pm, why: 'title' };
    // Youngfolks' evenings run 8 to 11 at night.
    if (/young ?folks/i.test((ctx && ctx.audience) || '') && c.h >= 8 && c.h <= 11) return { m: pm, why: 'audience' };
    // The day's own rows: an hour with rows around it in only one half of the day is that half.
    const day = ((ctx && ctx.dayRows) || []).map(r => minutes(r.start)).filter(m => m != null);
    const nearAm = day.some(m => Math.abs(m - am) <= 45), nearPm = day.some(m => Math.abs(m - pm) <= 45);
    if (nearAm !== nearPm) return { m: nearPm ? pm : am, why: 'the day' };
    return { m: c.h >= 7 && c.h <= 11 ? am : pm, why: 'hour' };
  }

  // The times at the start of some text: { a, b (raw clocks), open, used (characters read) } or null.
  function times(text) {
    const t = String(text || '');
    const mt = t.match(RANGE);
    if (!mt) return null;
    const a = clock(mt[1], mt[2]), b = mt[3] ? clock(mt[3], mt[4]) : null;
    if (!a || (mt[3] && !b)) return null;
    // "7" alone needs something after it that isn't a word run straight on ("7 Habits" is a title).
    let used = mt[0].length;
    // A number alone ("3-on-3 basketball") is a time only when a space, a comma or the end follows.
    if (!b && !mt[2] && !/[:]/.test(mt[1]) && !/^(noon|midnight)$/i.test(mt[1]) && !/^(?:[\s,·:]|$)/.test(t.slice(used))) return null;
    const oe = !b && t.slice(used).match(OPEN_END);
    if (oe) used += oe[0].length;
    return { a, b, open: !!oe, used };
  }

  // Raw clocks → minutes, guessing a missing AM or PM. → { start, end, guess: '' | 'title' | … }
  function settle(tm, title, ctx) {
    let guess = '';
    if (tm.b && !tm.b.fixed && tm.a.fixed) {
      let m = (tm.b.h % 12) * 60 + tm.b.min;
      while (m <= tm.a.m) m += 720;
      tm.b = { m, fixed: true };
    }
    if (!tm.a.fixed) {
      const endM = tm.b && tm.b.fixed ? tm.b.m : null;
      const h = half(tm.a, title, ctx, endM);
      tm.a = { m: h.m, fixed: true };
      guess = endM != null ? '' : h.why;
    }
    if (tm.b && !tm.b.fixed) { let m = (tm.b.h % 12) * 60 + tm.b.min; while (m <= tm.a.m) m += 720; tm.b = { m, fixed: true }; }
    return { start: tm.a.m, end: tm.b ? tm.b.m : null, guess, open: tm.open };
  }

  // A time written alone: "9:15", "10", "7:30 PM", "noon".
  const BARE = '\\d{1,2}(?::\\d{2})?(?:\\s*(?:a\\.?\\s?m\\.?|p\\.?\\s?m\\.?))?|noon|midnight';
  const OPEN_TAIL = "\\s+(?:until|till)\\s+(?:done|finished|it'?s? (?:done|over)|over)";
  // A number after these words is a room, a team or an age, not a time ("Room 2", "Ages 10").
  const NOT_TIME_BEFORE = /\b(room|rm|rooms|hall|floor|no\.?|number|court|field|gym|building|bldg|grade|age|ages|team|teams|table|tables|section|lot|door|gate)$/i;

  /* ------------------------------------------------------------ writing times */

  // "7 AM", "7:30 PM", "Noon", "Midnight"
  function fmt(m) {
    if (m == null) return '';
    m = ((m % 1440) + 1440) % 1440;
    if (m === 720) return 'Noon';
    if (m === 0) return 'Midnight';
    const h = Math.floor(m / 60), mm = m % 60;
    return (h % 12 || 12) + (mm ? ':' + String(mm).padStart(2, '0') : '') + (h < 12 ? ' AM' : ' PM');
  }
  // "2–8 PM", "10–11:30 AM", "Noon–11 PM", "11 PM–Midnight", "7 PM" (no end)
  function span(a, b) {
    if (a == null) return '';
    if (b == null) return fmt(a);
    const A = fmt(a), B = fmt(b);
    const sameHalf = !/Noon|Midnight/.test(A) && !/Noon|Midnight/.test(B) && A.slice(-2) === B.slice(-2);
    return (sameHalf ? A.slice(0, -3) : A) + '–' + B;
  }
  // A saved time ("7:00 PM", "noon") → minutes, or null.
  function minutes(v) {
    if (v == null) return null;
    const s = String(v).trim().toLowerCase().replace(/\./g, '');
    if (!s) return null;
    if (/^(12(:00)?\s*)?noon$/.test(s)) return 720;
    if (/^(12(:00)?\s*)?midnight$/.test(s)) return 1440;
    const m = s.match(/^(\d{1,2})(?::(\d{2}))?(?::\d{2})?\s*(am|pm|a|p)?$/);
    if (!m) return null;
    let h = +m[1];
    const min = m[2] ? +m[2] : 0;
    if (min > 59 || h > 24) return null;
    if (m[3]) { if (h === 0 || h > 12) return null; if (m[3][0] === 'p' && h !== 12) h += 12; if (m[3][0] === 'a' && h === 12) h = 0; }
    return h * 60 + min;
  }
  // Minutes → the saved form the pages read ("7:00 PM", "12:00 AM").
  const store = m => { if (m == null) return ''; m = ((m % 1440) + 1440) % 1440; const h = Math.floor(m / 60); return (h % 12 || 12) + ':' + String(m % 60).padStart(2, '0') + (h < 12 ? ' AM' : ' PM'); };

  /* ------------------------------------------------------------ the When field */

  // Words that place a row by another ("After Communion", "End of services", "30 min after Council").
  const REL = /^((?:\d{1,3}\s*(?:min(?:utes?)?|hours?|hrs?)\s+)?(?:after|before|following)|end of|close of|at the end of)\s+/i;

  // "After Communion Foot washing" → { words: 'After Communion', rest: 'Foot washing' }: the event named
  // is the longest of the year's titles that the text starts with, or else one word.
  function relative(text, ctx) {
    const t = String(text || '').trim(), m = t.match(REL);
    if (!m) return null;
    const after = t.slice(m[0].length);
    const titles = ((ctx && ctx.titles) || []).filter(Boolean).slice().sort((x, y) => y.length - x.length);
    const low = after.toLowerCase();
    let name = titles.find(x => low.indexOf(x.toLowerCase()) === 0 && !/[a-z0-9]/i.test(after.charAt(x.length)));
    if (!name) { const w = after.match(/^([A-Za-z][\w'’]*)/); name = w ? w[1] : ''; }
    else name = after.slice(0, name.length);
    if (!name) return null;
    return { words: (m[0] + name).trim().replace(/\s+/g, ' '), ref: name, rest: after.slice(name.length) };
  }
  // The minute a worded time falls at: the named row's end (or start), else the fallback.
  function placeOf(ref, ctx) {
    const rows = (ctx && ctx.dayRows) || [];
    const r = rows.find(x => String(x.title || '').toLowerCase() === String(ref || '').toLowerCase());
    if (!r) return null;
    const e = minutes(r.end), s = minutes(r.start);
    return e != null ? e : s;
  }

  // The When field, as written: "7–9:45", "noon–1", "2 PM until done", "After Communion–10 PM",
  // "30 min after Council, or 3", "All day". → { start, end, sort_time, guess, parts: [[label, text, guessed]] }
  function when(text, ctx) {
    const t = String(text || '').trim().replace(/\s+/g, ' ');
    const out = { start: '', end: '', sort_time: '', guess: '', parts: [], ok: true };
    if (!t || /^all day$/i.test(t)) { out.parts.push(['When', 'All day']); return out; }
    const rel = relative(t, ctx);
    if (rel) {
      out.start = rel.words;
      let rest = rel.rest.trim();
      const e = rest.match(new RegExp('^(?:-|–|—|to|until)\\s*' + TM, 'i'));
      if (e) { const c = clock(e[1], e[2]); if (c) { out.end = store(c.fixed ? c.m : ((c.h % 12) + 12) * 60 + c.min); rest = rest.slice(e[0].length).trim(); } }
      const f = rest.match(new RegExp('^,?\\s*or\\s+' + TM, 'i'));
      let at = null;
      if (f) { const c = clock(f[1], f[2]); if (c) at = c.fixed ? c.m : half(c, '', ctx).m; rest = rest.slice(f[0].length).trim(); }
      if (at == null) at = placeOf(rel.ref, ctx);
      out.sort_time = at == null ? '' : store(at);
      out.parts.push(['Starts', rel.words]);
      if (out.end) out.parts.push(['Ends', fmt(minutes(out.end))]);
      out.parts.push(['In the list at', at == null ? 'To choose' : fmt(at), at == null]);
      out.ok = !rest;
      return out;
    }
    const tm = times(t);
    if (!tm) { out.ok = false; out.parts.push(['When', 'Not a time yet']); return out; }
    const rest = t.slice(tm.used).trim();
    const s = settle(tm, (ctx && ctx.title) || '', ctx);
    out.start = store(s.start);
    out.end = s.open ? 'until finished' : s.end == null ? '' : store(s.end);
    out.guess = s.guess;
    out.parts.push(['When', s.open ? fmt(s.start) + ' until finished' : span(s.start, s.end), !!s.guess]);
    if (s.end != null && !s.open) {
      const len = s.end - s.start, h = Math.floor(len / 60);
      out.parts.push(['Runs', (h ? h + ' hr' : '') + (h && len % 60 ? ' ' : '') + (len % 60 ? len % 60 + ' min' : '')]);
    }
    out.ok = !rest;
    return out;
  }

  /* ------------------------------------------------------------ places, audiences, days */

  // A place named in passing: its code, its name, or the start of a word in its name; the building
  // itself before a room in it.
  function findPlace(s, places) {
    const v = String(s || '').trim().toLowerCase().replace(/^the\s+/, '');
    if (!v) return null;
    const list = places || [], words = v.split(/\s+/);
    const rank = p => {
      const n = String(p.name || '').toLowerCase(), ws = n.split(/[\s()]+/);
      if (String(p.code).toLowerCase() === v || n === v) return 0;
      if (n.indexOf(v) === 0) return 1;
      if ((' ' + n).indexOf(' ' + v) > -1 || n.indexOf('(' + v) > -1) return 2;
      if (v.length >= 3 && words.every(w => ws.some(x => x.indexOf(w) === 0))) return 3;
      return 9;
    };
    const hits = list.filter(p => rank(p) < 9).sort((a, b) => rank(a) - rank(b) || (String(a.code).indexOf('/') > -1) - (String(b.code).indexOf('/') > -1) || String(a.name).length - String(b.name).length);
    if (!hits.length) return null;
    const best = hits.filter(p => rank(p) === rank(hits[0])), pre = String(best[0].code).split('/')[0];
    if (String(best[0].code).indexOf('/') > -1 && best.length > 1 && best.every(p => String(p.code).split('/')[0] === pre)) {
      const b = list.find(p => String(p.code).toUpperCase() === pre.toUpperCase());
      if (b) return b;
    }
    return hits[0];
  }
  const AUD = [[/^(young ?folks?|yf|youth)$/i, 'Youngfolks'], [/^pre-?teens?$/i, 'Preteens'], [/^(all|everyone)$/i, 'All'], [/^conference$/i, 'Conference']];
  const audOf = s => (AUD.find(a => a[0].test(String(s || '').trim())) || [0, ''])[1];
  const WEEK = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
  const MONTHS = ['jan', 'feb', 'mar', 'apr', 'may', 'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec'];
  // A day as a spreadsheet or a person writes it: "Saturday", "Sat", "Sat 5/29", "5/29",
  // "Saturday, May 29", "2027-05-29", "29-May", "May 29" → one of the year's days, or null.
  function dayOf(s, days) {
    const t = String(s || '').trim().toLowerCase().replace(/\.(?=\s|$)/g, '');
    if (!t) return null;
    days = days || [];
    const md = (m, d) => days.find(x => { const p = String(x.date || '').split('-'); return +p[1] === m && +p[2] === d; });
    let m = t.match(/(\d{4})-(\d{1,2})-(\d{1,2})/);
    if (m) return md(+m[2], +m[3]) || null;
    m = t.match(/(?:^|\s)(\d{1,2})\/(\d{1,2})(?:\/\d{2,4})?(?:\s|$)/);
    if (m) return md(+m[1], +m[2]) || null;
    m = t.match(/(?:^|\s|,)([a-z]{3})[a-z]*\.?\s+(\d{1,2})(?:st|nd|rd|th)?(?:,?\s+\d{4})?$/);
    if (m && MONTHS.indexOf(m[1]) > -1) return md(MONTHS.indexOf(m[1]) + 1, +m[2]) || null;
    m = t.match(/^(\d{1,2})[\s-]([a-z]{3})[a-z]*\.?$/);
    if (m && MONTHS.indexOf(m[2]) > -1) return md(MONTHS.indexOf(m[2]) + 1, +m[1]) || null;
    m = t.match(/^([a-z]{3})[a-z]*\b/);
    if (m && WEEK.some(w => w.slice(0, 3) === m[1])) return days.find(x => x.name.toLowerCase().slice(0, 3) === m[1]) || null;
    return null;
  }
  // A line that's only a day's heading ("Saturday", "Sat 5/29", "Saturday, May 29").
  const DAY_HEAD = /^(sun|mon|tue|tues|wed|thu|thur|thurs|fri|sat)[a-z]*\.?,?(\s+([a-z]{3,9}\.?\s+\d{1,2}|\d{1,2}\/\d{1,2}(\/\d{2,4})?))?:?$/i;

  // A short all-caps word that reads as a room code nobody has ("ZZ", "B/9").
  const CODE_LIKE = /^[A-Z0-9]{1,4}(\/[A-Z0-9]{1,6})?$/;

  /* ------------------------------------------------------------ one line */

  // One line: [day] [time] what, where, who for, anything else (a note). The title keeps its commas
  // ("Song, prayer and dismissal, Youngfolks"): only trailing pieces that are a place or an audience
  // are taken from it; a piece before one of those is part of the title.
  function line(text, ctx) {
    ctx = ctx || {};
    let t = String(text || '').trim().replace(/\s+/g, ' ');
    let day = ctx.day || '';
    const row = { day, audience: 'Conference', start: '', end: '', title: '', place: '', note: '' };
    const out = { row, guess: '', unknown: '', moved: false, rel: '' };
    // A day first: "Sat 10–12 Worship".
    const dm = t.match(/^(sun|mon|tue|wed|thu|fri|sat)[a-z]*\.?,?\s+(?=\d|noon|after|before|end of)/i);
    if (dm) { const d = dayOf(dm[1], ctx.days); if (d) { row.day = d.name; out.moved = d.name !== ctx.day; t = t.slice(dm[0].length); } }
    let tm = null, rel = null;
    if (/^all day\b/i.test(t)) t = t.replace(/^all day[\s,·:]*/i, '');
    else if ((rel = relative(t, ctx))) { t = rel.rest.replace(/^[\s,·:–-]+/, ''); }
    else if ((tm = times(t))) t = t.slice(tm.used).replace(/^[\s,·:]+/, '');
    else {
      // The time after the title: "Supper 5–7, Barnes", "Worship 10–12 Chapel".
      const m = t.match(new RegExp('(^|\\s)(' + TM + SEP + TM + '|\\d{1,2}(?::\\d{2})?\\s*(?:a\\.?m\\.?|p\\.?m\\.?)|noon' + SEP + TM + ')(?=[\\s,]|$)', 'i'));
      if (m) { tm = times(m[2]); if (tm) t = (t.slice(0, m.index).trim() + ', ' + t.slice(m.index + m[0].length).trim()).replace(/(,\s*)+/g, ', ').replace(/^[,\s]+|[,\s]+$/g, ''); }
      // One time at the end of the title ("Ushers meet 9:15, Chapel lobby", "Council 2 till done"),
      // or "by" one ("Check-out by 10": done by then, placed at that time).
      if (!tm) {
        const cut = t.search(/\s*[,·|;]/), first = cut < 0 ? t : t.slice(0, cut), rest = cut < 0 ? '' : t.slice(cut);
        const one = first.match(new RegExp('^(.*?\\S)\\s+(by\\s+|at\\s+|@\\s*)?(' + BARE + ')(' + OPEN_TAIL + ')?\\s*$', 'i'));
        if (one && !NOT_TIME_BEFORE.test(one[1])) {
          const t2 = times(one[3] + (one[4] || ''));
          if (t2 && !t2.b) { tm = t2; if (/^by/i.test(one[2] || '')) out.by = true; t = (one[1] + rest).trim(); }
        }
      }
    }
    // "… at Chapel" / "… in Barnes" at the end: a place.
    let pieces = t.split(/\s*[,·|;]\s*|\s+[–—]\s+|\s+-\s+/).map(x => x.trim()).filter(Boolean);
    if (pieces.length) {
      const lastP = pieces[pieces.length - 1], m = lastP.match(/^(.+?)\s+(?:at|in)\s+(.+)$/i);
      if (m && findPlace(m[2], ctx.places)) pieces.splice(pieces.length - 1, 1, m[1], m[2]);
    }
    const kindOf = x => audOf(x) ? 'aud' : findPlace(x, ctx.places) ? 'place' : CODE_LIKE.test(x) ? 'code' : '';
    const marks = pieces.map(kindOf);
    const title = [pieces[0] || ''];
    for (let i = 1; i < pieces.length; i++) {
      const x = pieces[i], k = marks[i];
      if (k === 'aud') { row.audience = audOf(x); continue; }
      if (k === 'place' && !row.place) { row.place = findPlace(x, ctx.places).code; continue; }
      if (k === 'code' && !row.place && !out.unknown) { out.unknown = x; continue; }
      if (marks.slice(i + 1).some(z => z === 'aud' || z === 'place')) { title.push(x); continue; }
      row.note = row.note ? row.note + ' · ' + x : x;
    }
    row.title = title.join(', ').trim();
    ctx = Object.assign({}, ctx, { audience: row.audience });
    if (rel) {
      const w = when(rel.words + (tm ? '' : ''), ctx);
      row.start = w.start; row.sort_time = w.sort_time; out.rel = rel.words;
    } else if (tm && out.by) {
      // "By 10": a row that has to be done by then is written as words, placed at that time.
      const s = settle(tm, row.title, ctx);
      row.start = 'By ' + fmt(s.start); row.sort_time = store(s.start); out.guess = s.guess;
    } else if (tm) {
      const s = settle(tm, row.title, ctx);
      row.start = store(s.start); row.end = s.open ? 'until finished' : s.end == null ? '' : store(s.end);
      out.guess = s.guess;
    }
    if (out.unknown && !row.place) row.note = row.note ? out.unknown + ' · ' + row.note : out.unknown;
    return out;
  }

  /* ------------------------------------------------------------ pasting */

  // A spreadsheet's column names → the schedule's fields (the site's own Export, schedule.csv, and the
  // names people give them).
  const HEAD = [
    [/^(day|date|days)$/, 'day'], [/^(time|times|when|hours)$/, 'time'], [/^(start|starts|begin|begins|from|start time|start_time)$/, 'start'],
    [/^(end|ends|to|until|end time|end_time|finish)$/, 'end'], [/^(what|title|event|activity|item|session|description of event)$/, 'title'],
    [/^(where|place|location|room|building|venue)$/, 'place'], [/^(for|audience|who|group)$/, 'audience'], [/^(note|notes|details|description|comments?)$/, 'note'],
    [/^(call-?in|call_in|call in line|on the line)$/, 'call_in'], [/^(recorded|recording)$/, 'recorded'], [/^(id|_id|row id)$/, '_id'], [/^(kind|type)$/, 'kind'],
    [/^(display|shown|on the page)$/, 'display'], [/^(last_day|through|repeats|last day)$/, 'last_day'], [/^(sort_time|sort time|in the list at)$/, 'sort_time'],
    [/^(print_note|on the printout)$/, 'print_note'], [/^(guide|packet parts|linked packet parts)$/, 'guide']
  ];
  const headOf = c => { const v = String(c || '').trim().toLowerCase().replace(/^﻿/, ''); const h = HEAD.find(x => x[0].test(v)); return h ? h[1] : ''; };
  // A cell from Excel or a Sheet: "'=x" (made safe by Export) → "=x"; 0.4166… (a time) → minutes.
  const unsafe = v => String(v == null ? '' : v).replace(/^'(?=[=+\-@\t\r])/, '');
  function cellTime(v) {
    const s = String(v || '').trim();
    if (/^0?\.\d+$/.test(s)) { const m = Math.round(parseFloat(s) * 1440); return store(m); }
    return s;
  }
  // Rows of cells from text: tabs (Excel, Sheets), or CSV with quotes.
  function cells(text, tab) {
    if (tab) return String(text).split(/\r?\n/).map(l => l.split('\t').map(x => x.replace(/^"(.*)"$/s, '$1').replace(/""/g, '"').trim()));
    const out = []; let row = [], cur = '', q = false;
    const s = String(text);
    for (let i = 0; i < s.length; i++) {
      const c = s[i];
      if (q) { if (c === '"' && s[i + 1] === '"') { cur += '"'; i++; } else if (c === '"') q = false; else cur += c; }
      else if (c === '"') q = true; else if (c === ',') { row.push(cur.trim()); cur = ''; }
      else if (c === '\n' || c === '\r') { if (c === '\r' && s[i + 1] === '\n') i++; row.push(cur.trim()); out.push(row); row = []; cur = ''; }
      else cur += c;
    }
    if (cur || row.length) { row.push(cur.trim()); out.push(row); }
    return out;
  }

  // Pasted text → rows. A header row (by its names) means a spreadsheet's rows; otherwise each line is
  // read as typed, and a line that's a day's name starts that day's rows.
  function paste(text, ctx) {
    ctx = ctx || {};
    const raw = String(text || '').replace(/^﻿/, '');
    const lines = raw.split(/\r?\n/);
    const first = lines.find(l => l.trim()) || '';
    const tab = first.indexOf('\t') > -1;
    const grid = tab || /,/.test(first) ? cells(raw, tab) : null;
    const heads = grid ? grid.find(r => r.some(c => c.trim())) : null;
    const map = heads ? heads.map(headOf) : [];
    if (heads && map.filter(Boolean).length >= 2 && map.indexOf('title') > -1) return pasteGrid(grid.slice(grid.indexOf(heads) + 1), map, ctx);
    // No header: tab-separated cells read as one line each ("7:00–9:45 AM  Breakfast  Barnes").
    let day = ctx.day || '';
    const out = { rows: [], unread: [], unreadAt: [], days: [] };
    lines.forEach((l0, at) => {
      const l = tab ? l0.split('\t').map(x => x.trim()).filter(Boolean).join(', ') : l0.trim();
      if (!l) return;
      if (DAY_HEAD.test(l)) { const d = dayOf(l, ctx.days); if (d) { day = d.name; return; } }
      if (!ctx.days || !ctx.days.length) {
        const w = l.match(/^(sun|mon|tue|wed|thu|fri|sat)[a-z]*\.?:?$/i);
        if (w) { day = w[0].replace(/[.:]$/, ''); return; }
      }
      const r = line(l, Object.assign({}, ctx, { day }));
      if (!r.row.title || (!r.row.start && !r.rel && !/^all day/i.test(l))) { out.unread.push(l); out.unreadAt.push(at); return; }
      // What a line doesn't say (no note, no place) isn't "blank": a pasted row never clears them.
      if (!r.row.note) delete r.row.note;
      if (!r.row.place) delete r.row.place;
      out.rows.push({ row: r.row, guess: r.guess, line: l, unknown: r.unknown });
    });
    return out;
  }
  function pasteGrid(grid, map, ctx) {
    const out = { rows: [], unread: [], days: [] };
    let day = ctx.day || '';
    grid.forEach(cs => {
      const o = {};
      map.forEach((k, i) => { if (k && cs[i] != null && String(cs[i]).trim() !== '') o[k] = unsafe(cs[i]).trim(); });
      if (!Object.keys(o).length) return;
      const text = cs.filter(Boolean).join(' · ');
      // A row that's only a day ("Sat 5/29" in the Day column, nothing else): the next rows' day.
      if (o.day && Object.keys(o).length === 1) { const d = dayOf(o.day, ctx.days); if (d) { day = d.name; return; } }
      if (o.day) { const d = dayOf(o.day, ctx.days); if (d) day = d.name; else if (!ctx.days || !ctx.days.length) day = o.day; else { out.unread.push(text); return; } }
      if (!o.title) { out.unread.push(text); return; }
      const row = { day, audience: audOf(o.audience) || (o.audience ? o.audience : 'Conference'), start: '', end: '', title: o.title };
      if (o.note) row.note = o.note;
      let guess = '';
      const lc = Object.assign({}, ctx, { day, audience: row.audience, title: o.title });
      if (o.time || o.start) {
        const w = when(cellTime(o.time || o.start) + (o.end && !o.time ? '–' + cellTime(o.end) : ''), lc);
        if (!w.ok && !w.start) { out.unread.push(text); return; }
        row.start = w.start; row.end = w.end; if (w.sort_time) row.sort_time = w.sort_time; guess = w.guess;
      }
      if (o.place) {
        const p = findPlace(o.place, ctx.places) || (ctx.places || []).find(x => String(x.code).toUpperCase() === o.place.toUpperCase());
        if (p) row.place = p.code; else row.place = o.place.toUpperCase().slice(0, 32);
      }
      ['call_in', 'recorded', 'kind', 'display', 'last_day', 'sort_time', 'print_note', 'guide', '_id'].forEach(k => { if (o[k] != null) row[k] = k === 'call_in' || k === 'recorded' ? (/^(y|yes|x|1|true|on the line)$/i.test(o[k]) ? 'yes' : '') : o[k]; });
      out.rows.push({ row, guess, line: text, unknown: row.place && !(ctx.places || []).some(x => String(x.code).toUpperCase() === row.place.toUpperCase()) ? row.place : '' });
    });
    return out;
  }

  /* ------------------------------------------------------------ kinds */

  const KIND_GUESS = [[/communion/i, 'communion'], [/council/i, 'council'], [/worship|preaching|service\b|sermon/i, 'worship'], [/breakfast|lunch|supper|dinner|meal/i, 'meal'], [/snack/i, 'snack'],
    [/singing|song service/i, 'singing'], [/devotion/i, 'devotion'], [/prayer/i, 'prayer'], [/teaching|class|study/i, 'teaching'], [/meeting/i, 'meeting'], [/registration|check-in|check in/i, 'registration'],
    [/tournament|game|volleyball|basketball/i, 'activity'], [/quiet time/i, 'quiet'], [/social/i, 'social'], [/pick ?up/i, 'pickup'], [/display/i, 'display']];
  const guessKind = t => (KIND_GUESS.find(k => k[0].test(t || '')) || [0, ''])[1];

  ED.read = { line, when, paste, span, fmt, minutes, store, findPlace, audOf, dayOf, guessKind, times, settle, relative, unsafe, cells, headOf, DAY_HEAD };
})(typeof window !== 'undefined' ? window : globalThis);
