/*
 * admin-files.js — lists out to Excel and back (ED.files). Docs/14 and Andrew: people live in their
 * spreadsheets, so whatever goes out comes back in through every door, and nothing is lost on the way.
 *
 *   ED.files.download(name, header, rows)   a CSV that opens in Excel: a BOM, and any cell starting
 *                                            =, +, -, @ (a formula) written with an apostrophe first
 *   ED.files.read(file)                      a dropped or chosen file → rows of cells (CSV, tab-separated,
 *                                            Windows-1252 text, or .xlsx read on the server)
 *   ED.files.compare(incoming, current, o)   what an import would do, row by row, before anything changes:
 *                                            { same, changed: [{ row, now, fields }], added, removed, dupes }
 *
 * Rows are matched by the export's ID column; without one, by the key the editor gives (a schedule
 * row's day, time and title), then by name. Rows missing from the file are removed only within the
 * days or committees the file has, and each removal is a box left unticked when the row has people.
 */
(function () {
  'use strict';
  const ED = window.ED = window.ED || {};

  // A cell that Excel would run as a formula gets an apostrophe; times and numbers are left alone.
  const safe = v => { v = v == null ? '' : String(v); return /^[=+\-@\t\r]/.test(v) && !/^[+-]?\d[\d.,:]*$/.test(v) ? "'" + v : v; };
  const cell = v => { v = safe(v); return /[",\r\n]|^\s|\s$/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v; };
  function csv(header, rows) { return '﻿' + [header.map(cell).join(',')].concat(rows.map(r => r.map(cell).join(','))).join('\r\n') + '\r\n'; }
  function download(name, header, rows) {
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([csv(header, rows)], { type: 'text/csv;charset=utf-8' }));
    a.download = name;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 4000);
  }

  // A file → { grid: rows of cells, text (for CSV/TSV) }. Excel's .xlsx is read on the server.
  async function read(file) {
    if (file.size > 3 * 1024 * 1024) throw new Error('Too big · 3 MB at most');
    if (/\.xlsx$/i.test(file.name) || /spreadsheetml/.test(file.type)) {
      const buf = new Uint8Array(await file.arrayBuffer());
      let bin = ''; for (let i = 0; i < buf.length; i += 0x8000) bin += String.fromCharCode.apply(null, buf.subarray(i, i + 0x8000));
      const d = await ED.api('POST', 'xlsx', { data: btoa(bin) });
      return { grid: (d.rows || []).map(r => r.map(x => x == null ? '' : String(x))), text: '' };
    }
    if (/\.(xls|numbers|ods)$/i.test(file.name)) throw new Error('Save it as .xlsx or .csv first');
    const buf = await file.arrayBuffer();
    let text = new TextDecoder('utf-8').decode(buf);
    // Excel on Windows saves CSV as Windows-1252: read it so, if UTF-8 didn't fit.
    if (text.indexOf('�') > -1) text = new TextDecoder('windows-1252').decode(buf);
    text = text.replace(/^﻿/, '');
    const tab = (text.split(/\r?\n/)[0] || '').indexOf('\t') > -1;
    return { grid: ED.read.cells(text, tab), text };
  }

  // What an import would change. incoming / current: rows (objects). o.key(r): a row's match key without
  // an id; o.name(r): a looser match; o.fields: the fields compared; o.scope(r): the day or committee
  // (rows missing from the file are removed only in the scopes the file has); o.people(r): how many
  // people a row has (its removal box starts unticked).
  function compare(incoming, current, o) {
    const out = { same: [], changed: [], added: [], removed: [], dupes: [] };
    const used = new Set(), seen = new Set();
    const norm = v => String(v == null ? '' : v).trim();
    const find = r => {
      if (r._id) { const hit = current.find(c => c._id === r._id && !used.has(c)); if (hit) return hit; }
      const k = o.key(r), byKey = current.find(c => !used.has(c) && o.key(c) === k);
      if (byKey) return byKey;
      return o.name ? current.find(c => !used.has(c) && o.name(c) === o.name(r) && (!o.scope || o.scope(c) === o.scope(r))) : null;
    };
    incoming.forEach(r => {
      const k = o.key(r);
      if (seen.has(k)) { out.dupes.push(r); return; }
      seen.add(k);
      const hit = find(r);
      if (!hit) { out.added.push(r); return; }
      used.add(hit);
      // "noon" and "12:00 PM" are the same time; "All" and "all" the same word.
      const same = (a, b) => { a = norm(a); b = norm(b); if (a.toLowerCase() === b.toLowerCase()) return true; const open = v => /^(\?|until finished|until done)$/i.test(v); if (open(a) && open(b)) return true; const m = ED.read && ED.read.minutes; return !!m && m(a) != null && m(a) === m(b); };
      const fields = o.fields.filter(f => r[f] !== undefined && !same(r[f], hit[f]));
      if (fields.length) out.changed.push({ row: hit, now: r, fields });
      else out.same.push(hit);
    });
    const scopes = new Set(incoming.map(r => o.scope ? o.scope(r) : ''));
    current.forEach(c => { if (!used.has(c) && scopes.has(o.scope ? o.scope(c) : '')) out.removed.push({ row: c, people: o.people ? o.people(c) : 0 }); });
    return out;
  }

  ED.files = { download, read, compare, safe, csv };
})();
