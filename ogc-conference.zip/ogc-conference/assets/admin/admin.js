/*
 * admin.js — the back end's own page: the webmasters' page (?role=web) and the full-screen editors
 * (?edit=schedule, shifts:<committee>, tournaments, halls, places, nearby, help, notices, numbers).
 *
 * This file loads the year and draws the frame every editor shares: Back to the part of the year it
 * came from, the editor's name, whether what's being changed is public, the save status, and See it.
 * The editors themselves are admin-table.js; the webmasters' page is admin-web.js; saving row by row is
 * admin-rows.js; reading typed and pasted lines is admin-read.js; files in and out are admin-files.js.
 *
 * The year's other parts (its dates and place, the call-in line, registration, the packet, the menus)
 * are edited in place on the year's page (year/), so there's one place for each; their old addresses
 * here go there.
 */
(function () {
  'use strict';
  const O = window.OGC, esc = O.esc, ED = window.ED, W = window.OGC_WP || {}, CFG = W.editors || {};
  const root = document.getElementById('ogc-admin');
  const q = new URLSearchParams(location.search);
  const svg = d => '<svg class="wk-i" viewBox="0 0 24 24" aria-hidden="true"><path d="' + d + '" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  const I = ED.I = {
    check: svg('m5.5 12.5 4 4 9-9'), down: svg('m6 9.5 6 6 6-6'), eye: svg('M2.5 12S6 5.5 12 5.5 21.5 12 21.5 12 18 18.5 12 18.5 2.5 12 2.5 12ZM12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6Z'),
    close: svg('m6.5 6.5 11 11M17.5 6.5l-11 11'), copy: svg('M8.5 8.5h11v11h-11zM5 15.5H4.5v-11h11V5'), plus: svg('M12 5v14M5 12h14'), minus: svg('M5 12h14'),
    back: svg('M14.5 5.5 8 12l6.5 6.5'), go: svg('m9.5 5.5 6.5 6.5-6.5 6.5'), grip: svg('M9 6.5h.01M9 12h.01M9 17.5h.01M15 6.5h.01M15 12h.01M15 17.5h.01'),
    warn: svg('M12 4 21 19.5H3zM12 10v4.5M12 17.5h.01'), pin: svg('M12 20.5s-6.5-5.4-6.5-10.8a6.5 6.5 0 0 1 13 0c0 5.4-6.5 10.8-6.5 10.8ZM12 12a2.3 2.3 0 1 0 0-4.6 2.3 2.3 0 0 0 0 4.6Z'),
    mail: svg('M4 6.5h16v11H4zM4.5 7l7.5 6 7.5-6'), info: svg('M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18ZM12 11v5.5M12 7.5h.01'), out: svg('M13.5 5.5h5v5M18.5 5.5 11 13M10 6.5H5.5v12h12V14'),
    search: svg('M10.5 17a6.5 6.5 0 1 0 0-13 6.5 6.5 0 0 0 0 13ZM15.5 15.5 20 20'), up: svg('M12 19V5M6 11l6-6 6 6'), lock: svg('M6.5 10.5h11v9h-11zM8.5 10.5V8a3.5 3.5 0 0 1 7 0v2.5'),
    clock: svg('M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18ZM12 7.5V12l3 2'), undo: svg('M9 14 4.5 9.5 9 5M5 9.5h9a5 5 0 0 1 0 10h-3')
  };

  /* ------------------------------------------------------------ the year */

  const NOT_YET = '9999-12-31';
  const X = ED.X = { year: q.get('year') || '', edit: q.get('edit') || '', role: q.get('role') || '', back: q.get('back') || '', today: CFG.today || O.wallNow('America/Indiana/Indianapolis').date };
  // The year's days, places and settings (as the pages read them), and last year's for comparing.
  async function loadYear(y) {
    const folder = O.dataBase(y);
    const model = await O.loadSchedule(folder).catch(() => undated(folder));
    return model;
  }
  O.dataBase = y => root.dataset.base + y + '/';
  async function undated(folder) {
    const t = await fetch(folder + 'settings.csv', { cache: 'no-store' }).then(r => r.text()).catch(() => '');
    const S = {}; O.csvToObjects(t).forEach(r => { if (r.key) S[O.slug(r.key)] = r.value; });
    return { settings: S, tz: S.timezone || 'America/Indiana/Indianapolis', days: [], places: {}, guides: {}, help: [], nearby: [], notices: [], contacts: [], problems: [], dayByDate: () => null };
  }
  // A year's files at once (one request), as the model the pages draw from.
  const NAMES = ['settings', 'schedule', 'places', 'contacts', 'attachments', 'milestones', 'guide', 'notices', 'help', 'nearby', 'menus'];
  function modelOf(bundle) {
    const src = {}; NAMES.forEach(n => { src[n] = ((bundle || {})[n] || {}).rows || []; });
    try { return O.buildSchedule(src); } catch (e) {
      const S = {}; src.settings.forEach(r => { if (r.key) S[O.slug(r.key)] = r.value; });
      return { settings: S, tz: S.timezone || 'America/Indiana/Indianapolis', days: [], places: {}, guides: {}, help: [], nearby: [], notices: [], contacts: [], problems: [], dayByDate: () => null };
    }
  }
  async function boot() {
    // years.csv comes with the page (no request); a page without it reads it.
    const str = o => { const r = {}; Object.keys(o).forEach(k => { r[k] = o[k] == null ? '' : String(o[k]); }); return r; };
    X.years = CFG.years ? CFG.years.map(str) : O.csvToObjects(await fetch(root.dataset.base + 'years.csv', { cache: 'no-store' }).then(r => r.text()));
    X.years = X.years.filter(y => y.year).sort((a, b) => b.year - a.year);
    X.webmaster = !!W.webmaster;
    const mine = (W.member || []).map(String);
    const withData = X.years.filter(y => y.data);
    if (!X.year || !X.years.some(y => y.year === X.year)) X.year = ((withData.find(y => X.webmaster || mine.indexOf(y.year) > -1) || withData[0]) || {}).year || '';
    X.row = X.years.find(y => y.year === X.year) || { year: X.year };
    X.held = (CFG.held || []).map(String).indexOf(X.year) > -1;
    // The old full-screen editors of the year's own parts go to where they're edited now.
    const IN_PLACE = { details: 'conference', callin: 'conference', registration: 'registration', packet: 'packet', menus: 'packet' };
    const k = X.edit.split(':')[0];
    if (IN_PLACE[k]) { location.replace(yearHref(IN_PLACE[k])); return; }
    // A COA member's home is the year's page; the webmasters' page is the webmasters'.
    if (!X.edit && (X.role !== 'web' || !X.webmaster)) { location.replace(yearHref('')); return; }
    if (!X.edit) { ED.web.draw(); return; }
    X.bundle = await ED.api('GET', 'years/' + X.year + '/bundle').catch(() => ({}));
    X.model = modelOf(X.bundle);
    X.settings = X.model.settings || {};
    X.days = (X.model.days || []).map(d => ({ name: d.name, date: d.date }));
    // Last year (for "From 2026" and comparing a row to check) and the last year at this campus.
    const before = withData.filter(y => +y.year < +X.year);
    X.prevRow = before[0] || null;
    X.campusPrev = before.find(y => y.venue && y.venue === X.row.venue) || null;
    X.campusChanged = !!(X.prevRow && X.row.venue && X.prevRow.venue && X.prevRow.venue !== X.row.venue);
    ED.table.open();
  }
  ED.loadYear = loadYear; ED.modelOf = modelOf;

  /* ------------------------------------------------------------ where things are */

  const yearPage = () => (W.base || '/annual-conference/') + 'year/';
  function yearHref(part, extra) { return yearPage() + '?year=' + encodeURIComponent(X.year) + (part ? '&part=' + encodeURIComponent(part) : '') + (extra || ''); }
  X.yearHref = yearHref;
  X.page = (path, args) => (W.base || '/annual-conference/') + path + (args ? (path.indexOf('?') > -1 ? '&' : '?') + args : '');
  // The parts of the year, by the names the year's page uses.
  const PART = { conference: 'Conference', schedule: 'Schedule', requests: 'Requests', registration: 'Registration', helping: 'Volunteer shifts', youngfolks: 'Young Folks', packet: 'Packet' };
  X.partName = p => PART[p] || '';

  /* ------------------------------------------------------------ the frame */

  // Is what this editor changes public? Two speeds (the year's parts wait for Publish; small things show
  // at once). → { word, tip, href }
  X.publicState = function (part, gateKey) {
    if (X.held) return { word: 'Held · Read only', cls: 'is-held', tip: 'The ' + X.year + ' Conference is over' };
    if (!gateKey) return part === 'private' ? { word: 'Committees only', cls: '', tip: 'Never on a public page' } : { word: 'Public · Changes show at once', cls: 'is-live', tip: 'On the Conference page and the guide' };
    const v = X.settings[gateKey];
    if (v && v !== NOT_YET && v <= X.today) return { word: 'Public · Changes show at once', cls: 'is-live', tip: 'Published ' + O.fmtDate(v, 'md') };
    if (v && v !== NOT_YET) return { word: 'Opens ' + O.fmtDate(v, 'md'), cls: '', tip: 'Not public until then' };
    return { word: 'Not public', cls: '', tip: 'Publish it on the year’s ' + (PART[part] || 'page'), link: ['Publish', yearHref(part)] };
  };

  // Back reads the year (and the part it came from); the title is the thing.
  X.frame = function (o) {
    // `return`, a path on this site (the printable schedule sends it), wins over the year's part.
    const ret = (r => r && /^\/(?!\/)[^\s\\]*$/.test(r) ? r : '')(q.get('return'));
    const back = ret ? (/\/schedule\//.test(ret) ? 'Printable schedule' : 'Back') : X.back && PART[X.back] ? X.year + ' · ' + PART[X.back] : X.year;
    const pub = o.state ? '<p class="ed-pub ' + (o.state.cls || '') + '" title="' + esc(o.state.tip || '') + '">' + esc(o.state.word) + (o.state.link ? ' · <a href="' + esc(o.state.link[1]) + '">' + esc(o.state.link[0]) + '</a>' : '') + (o.unlock ? ' · <button type="button" class="wk-linklike" data-unlock title="Webmasters only · Every change is logged">Unlock</button>' : '') + '</p>' : '';
    return '<header class="ws-bar ed-bar"><div class="ws-bar__in">' +
      '<a class="ws-back" href="' + esc(ret || (X.back ? yearHref(X.back) : yearHref(''))) + '" data-back>' + I.back + '<span>' + esc(back) + '</span></a>' +
      '<div class="ws-title"><h1 tabindex="-1">' + esc(o.title) + '</h1>' + pub + '</div>' +
      '<p class="ws-status ed-status" role="status" aria-live="polite" data-status></p>' + (o.tools || '') + '</div></header>';
  };
  X.title = t => { document.title = t + ' · ' + X.year + ' Conference'; };

  /* ------------------------------------------------------------ See it, beside the editor */

  // On a laptop (1240 px and wider) See it opens the page in a pane at a phone's width, and it follows
  // each save (ogc-wp.js reloads a framed page); narrower, a new tab.
  const WIDE = matchMedia('(min-width: 1240px)');
  let pane = null;
  X.seeAttrs = href => 'href="' + esc(href) + '" target="_blank" rel="noopener" data-see';
  function openSee(href, title) {
    if (!pane) {
      pane = document.createElement('aside');
      pane.className = 'ogc ed-pv';
      pane.setAttribute('aria-label', 'Preview');
      document.body.appendChild(pane);
      pane.addEventListener('click', e => { if (e.target.closest('[data-seeclose]')) closeSee(true); });
    }
    pane.innerHTML = '<header class="ed-pv__bar"><p><b>' + esc(title || 'Preview') + '</b><small>As it will look</small></p>' +
      '<a class="ed-pv__btn" href="' + esc(href) + '" target="_blank" rel="noopener" title="Open in a new tab">' + I.out + '<span class="ogc-sr">Open in a new tab</span></a>' +
      '<button type="button" class="ed-pv__btn" data-seeclose title="Close">' + I.close + '<span class="ogc-sr">Close</span></button></header>' +
      '<div class="ed-pv__page"><iframe src="' + esc(href) + '" title="' + esc(title || 'Preview') + '"></iframe></div>';
    pane.hidden = false; X.see = href;
    document.documentElement.classList.add('ed-has-pv');
    document.dispatchEvent(new CustomEvent('ed:see'));
    root.querySelectorAll('a[data-see]').forEach(a => a.setAttribute('aria-expanded', String(a.getAttribute('href') === href)));
  }
  function closeSee(focus) {
    if (!pane || pane.hidden) return;
    pane.hidden = true; pane.innerHTML = ''; const was = X.see; X.see = '';
    document.documentElement.classList.remove('ed-has-pv');
    document.dispatchEvent(new CustomEvent('ed:see'));
    root.querySelectorAll('a[data-see]').forEach(a => a.setAttribute('aria-expanded', 'false'));
    if (focus) { const a = root.querySelector('a[data-see][href="' + CSS.escape(was) + '"]'); if (a) a.focus(); }
  }
  X.closeSee = closeSee;
  document.addEventListener('click', e => {
    const a = e.target.closest && e.target.closest('a[data-see]');
    if (!a || !WIDE.matches || e.metaKey || e.ctrlKey || e.shiftKey) return;
    e.preventDefault();
    if (X.see === a.getAttribute('href')) closeSee(); else openSee(a.getAttribute('href'), a.dataset.seeTitle || a.textContent.trim());
  });
  WIDE.addEventListener('change', () => { if (!WIDE.matches) closeSee(); });

  /* ------------------------------------------------------------ a small message at the foot */

  // "Removed Check-in · Undo": what just happened, with the way back, for a few seconds.
  let toastT = 0;
  X.toast = function (text, action) {
    let el = document.querySelector('.ed-toast');
    if (!el) { el = document.createElement('div'); el.className = 'ogc ed-toast'; el.setAttribute('role', 'status'); el.setAttribute('aria-live', 'polite'); document.body.appendChild(el); }
    el.innerHTML = '<span>' + esc(text) + '</span>' + (action ? '<button type="button" class="ed-toast__b" data-toast>' + esc(action[0]) + '</button>' : '');
    el.hidden = false; el.classList.add('is-on');
    el.onclick = e => { if (e.target.closest('[data-toast]') && action) { action[1](); hide(); } };
    const hide = () => { el.classList.remove('is-on'); el.hidden = true; };
    clearTimeout(toastT); toastT = setTimeout(hide, action ? 10000 : 4000);
  };

  ED.I = I; ED.esc = esc;
  boot().catch(err => {
    console.error(err);
    root.innerHTML = '<div class="wk adm ws ws--center"><div class="adm-card"><h1 class="adm-card__h">Couldn’t load</h1><p class="adm-help">' + esc(err.message || 'Try again') + '</p><p><button type="button" class="wk-btn" onclick="location.reload()">Retry</button></p></div></div>';
  });
})();
