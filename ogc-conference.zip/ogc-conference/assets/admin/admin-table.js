/*
 * admin-table.js — the full-screen editors (ED.table): the schedule, each committee's shifts, the
 * tournaments, the dorm halls, buildings and rooms, care nearby, the Help cards, the notices and the
 * year's numbers. Each is a list that behaves like a spreadsheet (Michael, Oct 7: "open like a document,
 * connected like a database"): a rail of days or committees, the rows, and the chosen row's details
 * beside them (on a phone, a sheet over the list).
 *
 * Built for a once-a-year volunteer on a laptop: every control is labelled in words, an example shows
 * while a field is empty, a line is read as it's written ("10–11:30 Worship, Chapel"), ⌘Z takes back
 * this person's own last change, Find searches every day, warnings are gentle flags beside the field,
 * and every change is saved row by row on the server (admin-rows.js), so two people can work at once.
 */
(function () {
  'use strict';
  const O = window.OGC, esc = O.esc, ED = window.ED, SU = O.signups, R = ED.read;
  const root = document.getElementById('ogc-admin');
  let X, I, spec, S, F;
  const aux = {};          // other files an editor reads or adds to: places, schedule, shifts, committees, contacts
  const prev = {};         // last year's files (for "From 2026" and comparing a row to check)
  let people = [];         // sign-ups (shifts) or teams (tournaments): members see them
  const NOT_YET = '9999-12-31';
  const WEEKS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  const plural = (n, w) => SU.plural ? SU.plural(n, w) : n + ' ' + w + (n === 1 ? '' : 's');
  const lc = s => String(s == null ? '' : s).trim().toLowerCase();
  const val = (r, k) => r && r[k] != null ? String(r[k]) : '';
  const uniq = xs => Array.from(new Set(xs.filter(Boolean)));
  const isPhone = () => matchMedia('(max-width: 759px)').matches;
  const isNarrow = () => matchMedia('(max-width: 1099px)').matches;

  /* ================================================================ shared reading */

  const placesList = () => (aux.places ? aux.places.rows : spec && spec.file === 'places' ? F.rows : []).filter(p => p.code).map(p => ({ code: p.code, name: p.name || p.code, building: p.building || '', x: p.x, y: p.y, _id: p._id }));
  const placeOf = code => { const c = lc(code); return c ? placesList().find(p => lc(p.code) === c) || null : null; };
  // "Piazza Terrace (Barnes)" first, the code after it, muted: people read names.
  const placeHtml = code => {
    if (!code) return '';
    const p = placeOf(code);
    if (!p) return '<span class="ed-place is-unknown">' + (X.campusChanged ? 'Place to choose' : esc(code)) + '</span><small class="ed-code">' + esc(code) + '</small>';
    return '<span class="ed-place">' + esc(p.name) + '</span><small class="ed-code">' + esc(p.code) + '</small>';
  };
  const dayIx = name => X.days.findIndex(d => lc(d.name) === lc(name) || lc(d.name).slice(0, 3) === lc(name).slice(0, 3));
  // "All week" (volunteer area, Oct 15): a shift's one fixed choice beside an exact start and end: one
  // shift for the Conference's days (or day to last_day), as the server's ogc_vol_allweek_shift.
  const allWeek = r => spec.file === 'shifts' && /^\s*all\s+week\s*$/i.test(r.start || '');
  const weekSpan = r => { const a = r.day ? dayIx(r.day) : 0, e = X.row && X.row.end ? X.days.findIndex(d => d.date === X.row.end) : -1; const b = r.last_day ? dayIx(r.last_day) : (e > -1 ? e : X.days.length - 1); return [a, Math.max(a, b)]; };
  const dayDate = name => (X.days[dayIx(name)] || {}).date || '';
  const short = name => String(name || '').slice(0, 3);
  // A row's time as people write it: "2–8 PM", "Noon–11 PM", "After Communion–10 PM", "All day".
  function timeText(r) {
    const a = R.minutes(r.start), b = R.minutes(r.end);
    if (a == null) return r.start ? r.start + (r.end ? (b != null ? '–' + R.fmt(b) : ' ' + r.end) : '') : 'All day';
    if (/^(\?|until finished|until done)$/i.test(String(r.end || '').trim())) return R.fmt(a) + ' until finished';
    return R.span(a, b == null ? null : (b <= a ? b + 1440 : b));
  }
  const tStart = r => { const a = R.minutes(r.start); return a != null ? a : R.minutes(r.sort_time) != null ? R.minutes(r.sort_time) : r.start ? 1439 : -1; };
  const lenOf = r => { const a = R.minutes(r.start), b = R.minutes(r.end); return a == null || b == null ? 0 : (b > a ? b - a : b + 1440 - a); };
  const AUD = [['Conference', 'Conference'], ['Preteens', 'Preteens'], ['Youngfolks', 'Youngfolks'], ['All', 'Everyone']];
  const audLabel = a => (AUD.find(x => lc(x[0]) === lc(a)) || [0, a])[1];

  // The context the line reader uses: the days, the places, the titles, last year's starts.
  function readCtx(day, extra) {
    const last = {};
    (prev.schedule || []).forEach(r => { const m = R.minutes(r.start); if (m != null) (last[lc(r.title)] = last[lc(r.title)] || []).push(m); });
    const rows = spec.file === 'schedule' ? F.rows : aux.schedule ? aux.schedule.rows : [];
    return Object.assign({ days: X.days, places: placesList(), day: day || S.group, titles: uniq(rows.map(r => r.title)), last, dayRows: rows.filter(r => r.day === (day || S.group)) }, extra || {});
  }

  /* ================================================================ checks */

  const SIT = /^(worship|council|communion|teaching|meeting|singing|devotion|prayer|meal)$/;
  const SERVICE = /^(worship|council|communion|teaching|singing|devotion)$/;
  // House rules, said as flags where the words are (never refused): Advisor policy and the site's ways.
  function wordFlags(text) {
    const t = String(text || ''), out = [];
    if (/!/.test(t)) out.push('Exclamation mark');
    if (/\b(speaker|preacher|by|led by|with)[:\s]+[A-Z][a-z]+\s+[A-Z][a-z]{2,}/.test(t)) out.push('Full name · Speakers as First L.');
    if (/\b\d{3}[-.\s)]\s?\d{3}[-.\s]\d{4}\b/.test(t)) out.push('Personal phone?');
    if (/[^\s@]+@[^\s@]+\.[a-z]{2,}/i.test(t)) out.push('Email address');
    if (/sermonaudio|youtube|youtu\.be|facebook/i.test(t)) out.push('Outside sermon link');
    if (/click here/i.test(t)) out.push('“Click here”');
    return out;
  }
  // What doesn't add up about a row: [{ text, k (the field it's about) }].
  function issues(r) {
    if (!r || !spec.issues) return [];
    return spec.issues(r).filter(Boolean);
  }
  function scheduleIssues(r) {
    const out = [], a = R.minutes(r.start), b = R.minutes(r.end), kind = r.kind || R.guessKind(r.title);
    if (r.day && X.days.length && dayIx(r.day) < 0) out.push({ text: 'Not a day of this Conference', k: 'day' });
    if (r._guess) out.push({ text: 'Time guessed · ' + (R.minutes(r.start) < 720 ? 'AM' : 'PM') + '?', k: 'start', soft: true });
    const len = lenOf(r);
    if (len >= 9 * 60 && !/^(all day|desk|nightly)$/.test(r.display || '') && !/^(prayer|display|open|lodging|on_call)$/.test(kind)) out.push({ text: 'Runs ' + Math.round(len / 60) + ' hours', k: 'start' });
    if (r.place && !placeOf(r.place)) out.push({ text: X.campusChanged ? 'Place to choose · ' + r.place : 'No place ' + r.place + ' at this campus', k: 'place' });
    if (!r.place && SIT.test(kind) && r.display !== 'private') out.push({ text: 'No place', k: 'place', soft: true });
    if (r.call_in === 'yes' && kind && !SERVICE.test(kind)) out.push({ text: 'Call-in on a ' + (kind === 'meal' ? 'meal' : 'row that isn’t a service') + '?', k: 'call_in' });
    // Two things in one room at once, whatever they are: only rows that run all day or stand open
    // (display rooms, desks, open hours, prayer rooms) and meals share a room by design.
    const clash = roomClash(r);
    if (clash) out.push({ text: 'Room conflict · ' + clash.title + ' ' + timeText(clash), k: 'place' });
    if (F.rows.some(x => x !== r && x._id !== r._id && x.day === r.day && lc(x.title) === lc(r.title) && lc(x.start) === lc(r.start))) out.push({ text: 'Duplicate', k: 'title', dup: true });
    wordFlags(r.title + ' ' + (r.note || '')).forEach(t => out.push({ text: t, k: 'note', soft: true }));
    return out;
  }

  const SHARES = /^(open|display|on_call|lodging|meal|snack)$/;
  function clashable(x) {
    const a = R.minutes(x.start), b = R.minutes(x.end);
    if (a == null || b == null || x.display === 'desk' || x.display === 'all day') return false;
    if (SHARES.test(x.kind || R.guessKind(x.title) || '')) return false;
    return lenOf(x) < LONG;
  }
  function roomClash(r) {
    if (!r.place || !clashable(r)) return null;
    const rooms = [r.place].concat(String(r.also || '').split('|')).filter(Boolean).map(lc);
    const on = x => dayIx(x.day) <= dayIx(r.last_day || r.day) && dayIx(x.last_day || x.day) >= dayIx(r.day);
    const a = R.minutes(r.start), end = a + lenOf(r);
    return F.rows.find(x => x !== r && x._id !== r._id && clashable(x) && on(x) && [x.place].concat(String(x.also || '').split('|')).some(c => c && rooms.indexOf(lc(c)) > -1) &&
      R.minutes(x.start) < end && a < R.minutes(x.start) + lenOf(x)) || null;
  }

  /* ================================================================ people on a row */

  // A shift's places, a day at a time (the volunteer area's ids: the row's uid, with the date when it
  // runs several days; older rows by committee, job, day and start).
  function shiftDays(r) {
    if (allWeek(r)) {
      const [a, b] = weekSpan(r), d = X.days[a];
      if (!d) return [];
      const ids = [r.uid || [r.committee, r.role, 'all-week'].join('|').toLowerCase().replace(/[^a-z0-9|]+/g, '-')];
      const ups = people.filter(p => ids.indexOf(String(p.id)) > -1);
      return [{ day: short(d.name) + '–' + short((X.days[b] || d).name), date: d.date, need: +r.needed || 0, have: ups.length, ups }];
    }
    const a = dayIx(r.day), b = r.last_day ? dayIx(r.last_day) : a;
    if (a < 0 || b < 0) return [];
    const out = [];
    for (let i = a; i <= b; i++) {
      const d = X.days[i];
      const v3 = [r.committee, r.role, O.slug(d.name), r.start].join('|').toLowerCase().replace(/[^a-z0-9|]+/g, '-');
      const ids = [v3]; if (r.uid) ids.unshift(a === b ? r.uid : r.uid + '|' + d.date);
      const ups = people.filter(p => ids.indexOf(String(p.id)) > -1);
      out.push({ day: d.name, date: d.date, need: +r.needed || 0, have: ups.length, ups });
    }
    return out;
  }
  // How full a shift is: neutral ("Open · 4") until the last three weeks, when a shift still short is
  // flagged. Never a wall of zeros.
  const lastStretch = () => !!(X.row.start && O.isoAddDays(X.row.start, -21) <= X.today);
  function fillHtml(ds) {
    if (!ds.length) return '';
    const late = lastStretch(), need = ds[0].need;
    if (ds.every(d => !d.have) && ds.every(d => d.need === need)) return '<span class="ed-fill"><span class="ed-fill__d' + (late && need ? ' is-empty' : '') + '">' + (need ? 'Open · ' + need + (ds.length > 1 ? ' a day' : '') : 'Open') + '</span></span>';
    return '<span class="ed-fill">' + ds.map(d => '<span class="ed-fill__d' + (late && d.need && d.have < d.need ? ' is-empty' : d.need && d.have >= d.need ? ' is-full' : '') + '" title="' + esc(d.day + ': ' + d.have + (d.need ? ' of ' + d.need : ' · no limit')) + '">' + esc(short(d.day)) + ' ' + (d.need && d.have >= d.need ? 'full' : !d.have ? (d.need ? d.need + ' open' : 'open') : d.have + (d.need ? '/' + d.need : '')) + '</span>').join('') + '</span>';
  }
  const signedUp = r => spec.file === 'shifts' ? shiftDays(r).reduce((n, d) => n + d.have, 0) : spec.file === 'tournaments' ? people.filter(t => String(t.tournament || t.tid || t.id_tournament || '') === String(r.id)).length : 0;
  const nameOf = p => SU.firstL ? SU.firstL(p.name || '') : p.name || '';

  /* ================================================================ fields */

  // A field's label, its control, and help shown while it's empty or being typed in.
  const help = (h, show) => h ? '<small class="ed-help' + (show ? ' is-on' : '') + '">' + esc(h) + '</small>' : '';
  function pills(k, v, opts, label, o) {
    o = o || {};
    const on = x => o.multi ? String(v || '').split('|').indexOf(x) > -1 : String(v || '') === x;
    return '<div class="ed-f" role="group" aria-label="' + esc(label) + '"><span class="ed-f__l">' + esc(label) + '</span><span class="rf-seg ed-pills">' +
      opts.map(x => '<button type="button" data-pick="' + esc(k) + '" data-v="' + esc(x[0]) + '"' + (o.multi ? ' data-multi' : '') + ' aria-pressed="' + on(x[0]) + '"' + (x[2] ? ' title="' + esc(x[2]) + '"' : '') + '>' + (on(x[0]) ? I.check : '') + esc(x[1]) + '</button>').join('') +
      '</span>' + (o.after || '') + help(o.help, true) + '</div>';
  }
  function input(k, label, v, o) {
    o = o || {};
    const tag = o.area ? '<textarea class="ed-in' + (o.grow ? ' ed-grow' : '') + (o.line ? ' ed-line' : '') + '" rows="' + (o.line ? 1 : 2) + '" data-k="' + esc(k) + '" data-fk="' + esc(k) + '" placeholder=" "' + (o.max ? ' maxlength="' + o.max + '"' : '') + '>' + esc(v) + '</textarea>'
      : '<input class="ed-in" data-k="' + esc(k) + '" data-fk="' + esc(k) + '" type="' + (o.type || 'text') + '" value="' + esc(v) + '" placeholder=" "' + (o.list ? ' list="' + o.list + '"' : '') + (o.mode ? ' inputmode="' + o.mode + '"' : '') + ' autocomplete="off"' + (o.max ? ' maxlength="' + o.max + '"' : '') + '>';
    return '<label class="ed-f' + (o.cls ? ' ' + o.cls : '') + '"><span class="ed-f__l">' + esc(label) + '</span>' + tag + (o.echo != null ? '<small class="ed-echo" data-echo="' + esc(k) + '">' + o.echo + '</small>' : '') + help(o.help, !v) + (o.after || '') + '</label>';
  }
  function stepper(k, label, v, o) {
    o = o || {};
    const n = +v || 0, min = o.min || 0;
    return '<div class="ed-f" role="group" aria-label="' + esc(label) + '"><span class="ed-f__l">' + esc(label) + '</span><span class="reg-stepper ed-step"><button type="button" data-step="' + esc(k) + '" data-by="-1" aria-label="Fewer"' + (n <= min ? ' disabled' : '') + '>' + I.minus + '</button><output>' + (o.zero && !n ? esc(o.zero) : n) + '</output><button type="button" data-step="' + esc(k) + '" data-by="1" aria-label="More">' + I.plus + '</button></span>' + (o.after || '') + help(o.help, true) + '</div>';
  }
  const dayOpts = () => X.days.map(d => [d.name, short(d.name), O.fmtDate(d.date, 'long')]);

  // The When field: one box, read as written, and what was understood said under it, part by part.
  function whenField(r, label) {
    const words = r.start && R.minutes(r.start) == null;
    const text = words ? r.start + (r.end ? (R.minutes(r.end) != null ? '–' + R.fmt(R.minutes(r.end)) : ' ' + r.end) : '') + (r.sort_time && !words ? '' : '') : timeText(r) === 'All day' ? '' : timeText(r);
    return '<label class="ed-f"><span class="ed-f__l">' + esc(label || 'When') + '</span><input class="ed-in" data-when data-fk="when" value="' + esc(text) + '" placeholder=" " autocomplete="off" spellcheck="false">' +
      '<span class="ed-chips" data-whenecho>' + whenChips(r, text) + '</span>' + help(spec.file === 'shifts' ? 'Like 7–11 or 10 PM–2 AM' : 'Like 7–9:45, noon–1, After Communion, or 2 PM until done', !text) + '</label>' +
      (words && !allWeek(r) ? input('sort_time', 'In the list at', r.sort_time ? R.fmt(R.minutes(r.sort_time)) : '', { help: 'Where it falls in the day, like 8:30 PM', cls: 'ed-f--sub', echo: '' }) : '');
  }
  // What the When box was read as, said only where it adds something: a guess, a normalised time
  // ("7-9:45" → "7–9:45 AM"), how long it runs, the night it belongs to.
  function whenChips(r, typed) {
    const a = R.minutes(r.start);
    // A shift: All week is a fixed choice, one tap (never words to read).
    if (allWeek(r)) return '<span class="ed-chip"><b>All week</b> ' + esc(short((X.days[weekSpan(r)[0]] || {}).name) + '–' + short((X.days[weekSpan(r)[1]] || {}).name)) + '</span>';
    const weekBtn = spec.file === 'shifts' ? '<button type="button" class="ed-chip ed-chip--btn" data-allweek title="One shift for the whole Conference, like a dorm host">All week</button>' : '';
    if (!r.start) return '<span class="ed-chip">All day</span>' + weekBtn;
    const norm = v => lc(v).replace(/[\s.]+/g, '').replace(/[-—]/g, '–').replace(/:00/g, '');
    if (a == null) return '<span class="ed-chip"><b>Starts</b> ' + esc(r.start) + '</span>' + (r.end ? '<span class="ed-chip"><b>Ends</b> ' + esc(R.minutes(r.end) != null ? R.fmt(R.minutes(r.end)) : r.end) + '</span>' : '') + '<span class="ed-chip' + (r.sort_time ? '' : ' is-guess') + '"><b>In the list at</b> ' + esc(r.sort_time ? R.fmt(R.minutes(r.sort_time)) : 'To choose') + '</span>';
    const len = lenOf(r), h = Math.floor(len / 60);
    const night = a < 300 && spec.file === 'shifts' && dayIx(r.day) > 0 ? '<span class="ed-chip"><b>Night of</b> ' + esc(X.days[dayIx(r.day) - 1].name) + '</span>' : '';
    const said = typed == null || r._guess || norm(typed) !== norm(timeText(r));
    return (said ? '<span class="ed-chip' + (r._guess ? ' is-guess' : '') + '"><b>When</b> ' + esc(timeText(r)) + '</span>' : '') + (r._guess ? '<button type="button" class="ed-chip ed-chip--btn" data-flip title="Switch the half of the day">' + (a < 720 ? 'PM instead' : 'AM instead') + '</button>' : '') +
      (len ? '<span class="ed-chip"><b>Runs</b> ' + (h ? h + ' hr' : '') + (h && len % 60 ? ' ' : '') + (len % 60 ? len % 60 + ' min' : '') + '</span>' : '') + night + weekBtn;
  }

  // Where: a type-ahead of the campus's places, by name, building or code. Only a place chosen from the
  // list is saved; the last choice adds a new one.
  function placeField(k, r, label, inner) {
    const p = placeOf(r[k]);
    return '<div class="ed-f ed-combo' + (inner ? ' ed-f--flush' : '') + '" data-combo="' + esc(k) + '"><label class="' + (inner ? 'ogc-sr' : 'ed-f__l') + '" for="ed-combo-' + esc(k) + '">' + esc(label || 'Where') + '</label>' +
      '<input class="ed-in" id="ed-combo-' + esc(k) + '" data-placein="' + esc(k) + '" data-fk="place-' + esc(k) + '" value="' + esc(p ? p.name : r[k] || '') + '" placeholder=" " role="combobox" aria-expanded="false" aria-autocomplete="list" aria-controls="ed-list-' + esc(k) + '" autocomplete="off" spellcheck="false">' +
      '<small class="ed-echo">' + (p ? esc(p.code) + (p.building && p.building !== p.name ? ' · ' + esc(p.building) : '') : r[k] ? (X.campusChanged ? 'Place to choose · ' : 'Not a place here · ') + esc(r[k]) : '') + '</small>' +
      '<ul class="ed-list" id="ed-list-' + esc(k) + '" role="listbox" hidden></ul>' + help('Type a name, like Chapel or Barnes 133', !r[k]) + '</div>';
  }
  function placeOptions(text, k) {
    const t = lc(text), list = placesList();
    const hits = !t ? list.filter(p => String(p.code).indexOf('/') < 0).slice(0, 12) : list.filter(p => lc(p.name).indexOf(t) > -1 || lc(p.code).indexOf(t) === 0 || lc(p.building).indexOf(t) > -1).slice(0, 12);
    const opts = hits.map((p, i) => '<li role="option" id="ed-opt-' + k + '-' + i + '" data-opt="' + esc(p.code) + '"><b>' + esc(p.name) + '</b><small>' + esc(p.code) + (p.building && p.building !== p.name ? ' · ' + esc(p.building) : '') + '</small></li>');
    if (text.trim() && !hits.some(p => lc(p.name) === t || lc(p.code) === t)) opts.push('<li role="option" id="ed-opt-' + k + '-new" data-optnew="' + esc(text.trim()) + '"><b>New place: ' + esc(text.trim()) + '</b><small>Adds it to Buildings and rooms</small></li>');
    if (S.row && val(S.row, k)) opts.push('<li role="option" id="ed-opt-' + k + '-none" data-opt=""><b>No place</b></li>');
    return opts.join('');
  }

  // The field for a row, by its type (spec.fields: [type, key, label, options]).
  function field(f, r) {
    const [type, k, label, o0] = f, o = o0 || {}, v = val(r, k);
    if (S.ro) return roField(f, r);
    switch (type) {
      case 'line': return input(k, label, v, { area: true, line: true, grow: true, help: o.help, max: o.max });
      case 'area': return input(k, label, v, { area: true, grow: true, help: o.help, max: o.max });
      case 'text': return input(k, label, v, { help: o.help, list: o.list, max: o.max });
      case 'tel': return input(k, label, v, { type: 'tel', help: o.help, mode: 'tel', echo: o.echo ? o.echo(r) : null });
      case 'date': return input(k, label, v, { type: 'date', help: o.help, echo: o.echo ? o.echo(r) : null });
      case 'pills': return pills(k, v || o.def || '', o.opts, label, { help: o.help, after: o.after ? o.after(r) : '' });
      case 'multi': return pills(k, v, typeof o.opts === 'function' ? o.opts() : o.opts, label, { multi: true, help: o.help });
      case 'day': return pills(k, v, dayOpts(), label, { help: o.help });
      case 'num': return stepper(k, label, v, { min: o.min, zero: o.zero, help: o.help, after: o.after ? o.after(r) : '' });
      case 'when': return whenField(r, label);
      case 'place': return placeField(k, r, label);
      case 'custom': return o.html(r);
    }
    return '';
  }
  // A held year: the details as plain text, nothing to press.
  function roField(f, r) {
    const [type, k, label, o0] = f, o = o0 || {};
    if (type === 'custom') return o.ro ? o.ro(r) : '';
    let v = val(r, k);
    if (type === 'when') v = timeText(r);
    if (type === 'place') { const p = placeOf(v); v = p ? p.name + ' (' + p.code + ')' : v; }
    if ((type === 'pills') && o.opts) { const hit = o.opts.find(x => x[0] === v); v = hit ? hit[1] : v; }
    return v ? '<div class="ed-f ed-f--ro"><span class="ed-f__l">' + esc(label) + '</span><p>' + esc(v) + '</p></div>' : '';
  }

  /* ================================================================ the editors */

  const KINDS = [['worship', 'Worship'], ['meal', 'Meal'], ['meeting', 'Meeting'], ['teaching', 'Teaching'], ['singing', 'Singing'], ['activity', 'Activity'], ['devotion', 'Devotion'], ['registration', 'Registration']];
  const MORE_KINDS = [['council', 'Council'], ['communion', 'Communion'], ['snack', 'Snack'], ['prayer', 'Prayer'], ['pickup', 'Pick-up'], ['signup', 'Sign-up'], ['display', 'Display'], ['free', 'Free time'], ['social', 'Social'], ['quiet', 'Quiet time'], ['lodging', 'Lodging desk'], ['notice', 'Notice'], ['open', 'Open hours'], ['on_call', 'On call']];
  const kindLabel = k => (KINDS.concat(MORE_KINDS).find(x => x[0] === k) || [0, k])[1];
  const DISPLAY = [['', 'In the day', 'Listed at its time in the day'], ['all day', 'Open now', 'Under Open now on the page, not in the day'], ['desk', 'Desk hours', 'With the desks’ hours, not in the day'], ['nightly', 'Every night', 'Once, with the nightly rows'], ['private', 'Committees only', 'Never on a public page: set-up, sound checks, committee meetings']];

  const SPECS = {
    schedule: {
      file: 'schedule', title: 'Schedule', keyField: 'title', part: 'schedule', gate: 'schedule_posted', one: 'row', rail: 'Days', addLine: true,
      needs: ['places'], see: g => X.page('', 'year=' + X.year + '&preview=1&view=full' + (g && dayIx(g) > -1 ? '&day=' + encodeURIComponent(g) : '')), seeTitle: 'Full schedule',
      groups() {
        const rows = F.rows, gs = X.days.map(d => {
          const mine = rows.filter(r => r.day === d.name);
          return { id: d.name, label: d.name, sub: O.fmtDate(d.date, 'md'), n: mine.length, check: mine.filter(r => r._look).length, callin: mine.filter(r => r.call_in === 'yes').length };
        });
        const desk = rows.filter(r => r.display === 'desk').length, look = rows.filter(r => issues(r).some(i => !i.soft)).length;
        const lost = rows.filter(r => !X.days.length || dayIx(r.day) < 0).length;
        if (desk) gs.push({ id: '@desk', label: 'Desk hours', n: desk, extra: true });
        if (look) gs.push({ id: '@look', label: 'To look at', n: look, extra: true, warn: true });
        if (lost) gs.push({ id: '@none', label: X.days.length ? 'Not on any day' : 'Waiting for dates', n: lost, extra: true, warn: !!X.days.length });
        return gs;
      },
      inGroup(r, g) {
        if (g === '@desk') return r.display === 'desk';
        if (g === '@look') return issues(r).some(i => !i.soft);
        if (g === '@none') return !X.days.length || dayIx(r.day) < 0;
        return r.day === g && r.display !== 'desk';
      },
      sort: r => (S.group && S.group[0] === '@' ? dayIx(r.day) * 2000 : 0) + tStart(r),
      cols: [['Time', 'ed-c-time'], ['What', 'ed-c-what'], ['For', 'ed-c-for'], ['Where', 'ed-c-where']],
      cells: r => [esc(timeText(r)) + (S.group && S.group[0] === '@' ? '<small class="ed-sub">' + esc(short(r.day)) + '</small>' : ''),
        '<b class="ed-title">' + esc(r.title || 'New row').replace(/-/g, '‑') + '</b>' + (r._look ? ' <span class="ed-tag ed-tag--check">' + (r._look === 'unsure' ? 'Not sure' : 'To check') + '</span>' : '') + (r.display === 'private' ? ' <span class="ed-tag">Committees only</span>' : '') + (r.call_in === 'yes' ? ' <span class="ed-tag" title="On the call-in line">Call-in</span>' : '') +
          (r.audience && lc(r.audience) !== 'conference' ? ' <span class="ed-tag ed-aud">' + esc(audLabel(r.audience)) + '</span>' : '') + (r.note ? '<span class="ed-note">' + esc(r.note) + '</span>' : ''),
        r.audience && lc(r.audience) !== 'conference' ? '<span class="ws-tag">' + esc(audLabel(r.audience)) + '</span>' : '<span class="ed-dim">Conference</span>', placeHtml(r.place) + (r.also ? '<small class="ed-code">+ ' + esc(r.also.split('|').length) + ' more</small>' : '')],
      label: r => r.title || 'New row',
      sub: r => [short(r.day), timeText(r)].filter(Boolean).join(' · '),
      blank: g => ({ day: g && g[0] !== '@' ? g : (X.days[0] || {}).name || '', audience: 'Conference', title: '', start: '', end: '' }),
      issues: scheduleIssues,
      fields: () => [
        ['line', 'title', 'What', { help: 'Like Worship, Lunch, Youngfolks check-in', max: 200 }],
        ['custom', 'day', 'Days', { html: daysRange, ro: r => roField(['text', 'day', 'Days'], { day: r.day + (r.last_day ? ' through ' + r.last_day : '') }) }],
        ['when', 'start', 'When'],
        ['place', 'place', 'Where'],
        ['pills', 'audience', 'For', { opts: AUD, def: 'Conference' }],
        ['area', 'note', 'Note', { help: 'Shown when the row is opened', max: 1500 }],
        ['custom', 'linked', 'Linked', { html: linkedField, ro: linkedField }]
      ],
      more: () => [
        ['pills', 'call_in', 'Call-in', { opts: [['', 'No'], ['yes', 'Yes']], help: 'On the phone line (the call-in list)' }],
        ['pills', 'recorded', 'Recorded', { opts: [['', 'No'], ['yes', 'Yes']], help: 'A recording or sermon is posted for it' }],
        ['custom', 'display', 'Who sees it', { html: r => pills('who', r.display === 'private' ? 'private' : '', [['', 'Everyone'], ['private', 'Committees only']], 'Who sees it', { help: r.display === 'private' ? 'Never on a public page: set-up, sound checks, committee meetings' : '' }) + (r.display === 'private' ? '' : pills('display', r.display || '', DISPLAY.filter(x => x[0] !== 'private'), 'Shown as', { help: (DISPLAY.find(x => x[0] === (r.display || '')) || DISPLAY[0])[2] })) }],
        ['custom', 'kind', 'Kind', { html: kindField }],
        ['custom', 'also', 'Also at', { html: r => alsoField(r) }],
        ['multi', 'guide', 'Linked packet parts', { opts: () => uniq((aux.guide || []).map(g => g.id)).map(id => [id, ((aux.guide || []).find(g => g.id === id && g.title) || {}).title || id]) }],
        ['text', 'print_note', 'On the printout', { help: 'A few words for the paper schedule' }],
        ['area', 'why', 'Why', { help: 'Why it’s on the schedule; shown to next year’s committee' }]
      ],
      moreSummary: r => [(r.kind || R.guessKind(r.title)) ? 'Kind: ' + kindLabel(r.kind || R.guessKind(r.title)) : '', r.call_in === 'yes' ? 'Call-in' : '', r.recorded === 'yes' ? 'Recorded' : '', r.display ? (DISPLAY.find(x => x[0] === r.display) || [0, r.display])[1] : '', r.also ? 'Also at ' + plural(r.also.split('|').length, 'place') : '', r.guide ? 'Packet' : '', r.print_note ? 'Printout' : '', r.why ? 'Why' : ''].filter(Boolean).join(' · '),
      // Import and export: the site's own columns, by the names people read.
      exp: [['Day', 'day'], ['Time', r => timeText(r) === 'All day' ? '' : timeText(r)], ['What', 'title'], ['Where', r => { const p = placeOf(r.place); return p ? p.name : r.place || ''; }], ['For', r => lc(r.audience) === 'conference' ? '' : audLabel(r.audience)], ['Call-in', r => r.call_in === 'yes' ? 'Yes' : ''], ['Note', 'note'], ['ID', '_id']],
      key: r => lc(r.day) + '|' + (R.minutes(r.start) != null ? R.minutes(r.start) : lc(r.start)) + '|' + lc(r.title),
      name: r => lc(r.title), scope: r => r.day,
      compareFields: ['day', 'start', 'end', 'title', 'place', 'audience', 'note', 'call_in']
    },
    shifts: {
      file: 'shifts', title: 'Shifts', keyField: 'role', part: 'helping', gate: 'signups_posted', one: 'shift', rail: 'Committees',
      needs: ['places', 'committees', 'schedule'], see: g => X.page('volunteer/', 'year=' + X.year + '&preview=1' + (g && g[0] !== '@' ? '&committee=' + encodeURIComponent(g) : '')), seeTitle: 'Volunteer page',
      groups() {
        const names = uniq(F.rows.map(r => r.committee).concat((aux.committees ? aux.committees.rows : []).map(c => c.name)).concat(S.extraGroups || []));
        const gs = names.map(c => { const mine = F.rows.filter(r => r.committee === c); const days = [].concat.apply([], mine.map(shiftDays)); const open = days.filter(d => d.need).reduce((n, d) => n + Math.max(0, d.need - d.have), 0); return { id: c, label: c, n: mine.length, sub: mine.length ? (open ? open + ' open' : 'Full') : 'No shifts', check: mine.filter(r => r._look).length }; });
        // Last year's committees with nothing this year, faint, to start from.
        uniq((prev.shifts || []).map(r => r.committee)).filter(c => names.indexOf(c) < 0).forEach(c => gs.push({ id: '@from:' + c, label: c, sub: 'From ' + X.prevRow.year, faint: true, n: (prev.shifts || []).filter(r => r.committee === c).length }));
        return gs;
      },
      inGroup: (r, g) => r.committee === g,
      sort: r => dayIx(r.day) * 2000 + (R.minutes(r.start) == null ? 0 : R.minutes(r.start)),
      cols: [['Job', 'ed-c-what'], ['Days', 'ed-c-days'], ['Time', 'ed-c-time'], ['Filled', 'ed-c-fill'], ['Where', 'ed-c-where']],
      cells: r => {
        const ds = shiftDays(r), a = R.minutes(r.start);
        const nightOf = a != null && a < 300 && dayIx(r.day) > 0 ? ' <small class="ed-sub">' + esc(short(X.days[dayIx(r.day) - 1].name)) + ' night</small>' : '';
        return ['<b class="ed-title">' + esc(r.role || 'New shift') + '</b>' + (r._look ? ' <span class="ed-tag ed-tag--check">To check</span>' : '') + (r.join === 'invited' ? ' <span class="ed-tag">Invited</span>' : '') + (r.rule ? ' <span class="ed-note">' + esc(r.rule) + '</span>' : ''),
          esc(allWeek(r) ? short((X.days[weekSpan(r)[0]] || {}).name) + '–' + short((X.days[weekSpan(r)[1]] || {}).name) : short(r.day) + (r.last_day && r.last_day !== r.day ? '–' + short(r.last_day) : '')) + nightOf, esc(timeText(r)),
          fillHtml(ds),
          placeHtml(r.place)];
      },
      label: r => r.role || 'New shift', sub: r => [short(r.day) + (r.last_day ? '–' + short(r.last_day) : ''), timeText(r)].join(' · '),
      blank: g => ({ committee: g && g[0] !== '@' ? g : '', role: '', day: (X.days[1] || X.days[0] || {}).name || '', start: '8:00 AM', end: '10:00 AM', needed: '2' }),
      issues: r => {
        const out = [];
        if (r.place && !placeOf(r.place)) out.push({ text: X.campusChanged ? 'Place to choose · ' + r.place : 'No place ' + r.place + ' at this campus', k: 'place' });
        if (!allWeek(r) && (R.minutes(r.start) == null || R.minutes(r.end) == null)) out.push({ text: 'Needs a start and an end, or All week', k: 'start' });
        if (lenOf(r) > 8 * 60) out.push({ text: 'Runs ' + Math.round(lenOf(r) / 60) + ' hours', k: 'start' });
        const ds = shiftDays(r), over = ds.filter(d => d.need && d.have > d.need);
        if (over.length) out.push({ text: 'More signed up than needed · ' + over.map(d => short(d.day)).join(', '), k: 'needed' });
        wordFlags(r.role + ' ' + (r.note || '')).forEach(t => out.push({ text: t, k: 'note', soft: true }));
        return out;
      },
      fields: () => [
        ['line', 'role', 'Job', { help: 'Like Golf cart driver, Server, Usher', max: 160 }],
        ['custom', 'day', 'Days', { html: daysRange, ro: r => roField(['text', 'day', 'Days'], { day: short(r.day) + (r.last_day ? '–' + short(r.last_day) : '') }) }],
        ['when', 'start', 'When'],
        ['num', 'needed', 'People needed', { zero: 'No limit', help: 'Each day', after: r => { const n = signedUp(r); return n ? '<small class="ed-echo">' + plural(n, 'person') + ' signed up</small>' : ''; } }],
        ['place', 'place', 'Where'],
        ['area', 'note', 'Description', { help: 'What they’ll do, where to meet', max: 1500 }],
        ['custom', 'rule', 'Requirement', { html: ruleField }],
        ['pills', 'join', 'Who can join', { opts: [['', 'Anyone'], ['invited', 'Invited']], help: 'Invited: filled from the head’s list; the count still shows' }],
        ['pills', 'couples', 'Couples', { opts: [['', 'One at a time'], ['yes', 'Couples welcome']] }],
        ['custom', 'people', 'Signed up', { html: peopleField, ro: peopleField }]
      ],
      exp: [['Committee', 'committee'], ['Job', 'role'], ['Day', 'day'], ['Last day', 'last_day'], ['Start', 'start'], ['End', 'end'], ['Needed', 'needed'], ['Where', 'place'], ['Description', 'note'], ['Requirement', 'rule'], ['ID', '_id']],
      key: r => lc(r.committee) + '|' + lc(r.role) + '|' + lc(r.day) + '|' + R.minutes(r.start), name: r => lc(r.committee) + '|' + lc(r.role), scope: r => r.committee,
      compareFields: ['committee', 'role', 'day', 'last_day', 'start', 'end', 'needed', 'place', 'note', 'rule']
    },
    tournaments: {
      file: 'tournaments', title: 'Tournaments', keyField: 'name', part: 'youngfolks', one: 'tournament', needs: ['schedule', 'places'], see: () => X.page('tournaments/', 'year=' + X.year + '&preview=1'), seeTitle: 'Tournaments',
      cols: [['Tournament', 'ed-c-what'], ['Team size', 'ed-c-num'], ['Sign-ups', 'ed-c-time'], ['Teams', 'ed-c-num']],
      cells: r => ['<b class="ed-title">' + esc(r.name || 'New tournament') + '</b>' + (eventOf(r) ? ' <span class="ed-note">' + esc(eventLine(eventOf(r))) + '</span>' : ''), esc(r.min && r.max && r.min !== r.max ? r.min + '–' + r.max : r.max || r.min || ''),
        esc([r.opens ? 'Opens ' + O.fmtDate(r.opens, 'mdShort') : '', r.closes_day ? 'closes ' + short(r.closes_day) + ' ' + (r.closes_time ? R.fmt(R.minutes(r.closes_time)) || r.closes_time : '') : ''].filter(Boolean).join(' · ')), String(signedUp(r) || '')],
      label: r => r.name || 'New tournament', sub: r => r.min && r.max ? 'Teams of ' + (r.min === r.max ? r.min : r.min + '–' + r.max) : '',
      blank: () => ({ id: 't' + Date.now().toString(36), name: '', min: '2', max: '4' }),
      issues: r => {
        const out = [];
        if (+r.min > +r.max) out.push({ text: 'Fewest is more than most', k: 'min' });
        if ((r.schedule_id || r.schedule_title) && !eventOf(r)) out.push({ text: 'Its schedule row is gone', k: 'schedule_id' });
        if (!r.schedule_id && !r.schedule_title) out.push({ text: 'No schedule row', k: 'schedule_id', soft: true });
        return out;
      },
      fields: () => [
        ['line', 'name', 'Name', { help: 'Like Volleyball, 3-on-3 basketball', max: 120 }],
        ['custom', 'schedule_id', 'Event', { html: eventField, ro: r => roField(['text', 'x', 'Event'], { x: eventOf(r) ? eventLine(eventOf(r)) : '' }) }],
        ['custom', 'size', 'Team size', { html: r => '<div class="ed-2">' + stepper('min', 'Fewest', r.min, { min: 1 }) + stepper('max', 'Most', r.max, { min: 1 }) + '</div>' + (signedUp(r) ? '<p class="ed-flag">' + I.warn + plural(signedUp(r), 'team') + ' signed up</p>' : ''), ro: r => roField(['text', 'x', 'Team size'], { x: r.min === r.max ? r.min : r.min + '–' + r.max }) }],
        ['pills', 'solo', 'Solo sign-ups', { opts: [['', 'No'], ['yes', 'Yes']], help: 'One person may sign up and be placed on a team' }],
        ['custom', 'opens', 'Sign-ups open', { html: r => typedDate('opens', 'Sign-ups open', r.opens, 'Like Thu May 7') }],
        ['custom', 'closes', 'Sign-ups close', { html: closesField }],
        ['text', 'rule', 'Requirement', { help: 'Like at least one young man and one young woman' }],
        ['area', 'note', 'Note']
      ],
      exp: [['Name', 'name'], ['Fewest', 'min'], ['Most', 'max'], ['Opens', 'opens'], ['Closes day', 'closes_day'], ['Closes at', 'closes_time'], ['Requirement', 'rule'], ['Note', 'note'], ['ID', '_id']],
      key: r => lc(r.name), name: r => lc(r.name), compareFields: ['name', 'min', 'max', 'opens', 'closes_day', 'closes_time', 'rule', 'note']
    },
    halls: {
      file: 'rooms', title: 'Dorm halls', keyField: 'hall', part: 'conference', priv: true, one: 'floor', needs: ['plans'], see: () => X.page('lodging/', 'year=' + X.year), seeTitle: 'Lodging',
      sort: r => lc(r.hall) + '|' + String(r.floor || '').padStart(3, '0'),
      head: r => r.hall || 'New hall',
      cols: [['Floor', 'ed-c-num'], ['Rooms', 'ed-c-time'], ['Beds', 'ed-c-num'], ['For', 'ed-c-for'], ['Bathrooms', 'ed-c-where']],
      cells: r => ['<b class="ed-title">' + esc(floorName(r.floor)) + '</b>' + ((aux.plans || []).length && !planOf(r) ? ' <span class="ed-tag" title="Lodging assigns these rooms without a floor plan">No plan</span>' : '') + (r.closed ? '<span class="ed-note">Not used: ' + esc(r.closed) + '</span>' : ''), esc((r.first || '') + (r.last ? '–' + r.last : '')) + ' <small class="ed-sub">' + plural(roomsOf(r), 'room') + '</small>', String(roomsOf(r) * (+r.beds || 0)), esc(forLabel(r.for)), esc(SHARE_LABEL[r.share || ''] || '')],
      label: r => (r.hall || 'New hall') + ' · ' + floorName(r.floor), sub: r => plural(roomsOf(r), 'room'),
      blank: () => { const s = S.row || F.rows[F.rows.length - 1] || {}; return { hall: s.hall || '', floor: String((+s.floor || 0) + 1), beds: s.beds || '2', for: s.for || 'families', share: s.share || '' }; },
      issues: r => { const out = []; if (!r.hall) out.push({ text: 'No hall', k: 'hall' }); if (!roomsOf(r)) out.push({ text: 'No rooms', k: 'first' }); return out; },
      fields: () => [
        ['text', 'hall', 'Hall', { list: 'ed-halls', help: 'Like Carmin Hall' }],
        ['num', 'floor', 'Floor', { min: 0, help: '1 is the ground floor' }],
        ['custom', 'range', 'Rooms', { html: r => '<div class="ed-2">' + input('first', 'First room', val(r, 'first'), { mode: 'numeric' }) + input('last', 'Last room', val(r, 'last'), { mode: 'numeric' }) + '</div>' + (planOf(r) ? '<p class="ed-hint">' + I.pin + 'Floor plan · ' + plural(planOf(r), 'room') + '</p>' : ''), ro: r => roField(['text', 'x', 'Rooms'], { x: (r.first || '') + '–' + (r.last || '') }) }],
        ['text', 'closed', 'Not used', { help: 'Rooms out of service or kept for staff, like 105, 117' }],
        ['num', 'beds', 'Beds in each room', { min: 0 }],
        ['pills', 'for', 'For', { opts: [['families', 'Families'], ['young men', 'Young men'], ['young women', 'Young women']], def: 'families' }],
        ['pills', 'share', 'Bathrooms', { opts: [['private', 'Private bath'], ['pairs', 'Shared by pairs'], ['hall', 'Down the hall']], help: 'Older guests are placed by this' }],
        ['area', 'note', 'Note']
      ],
      exp: [['Hall', 'hall'], ['Floor', 'floor'], ['First room', 'first'], ['Last room', 'last'], ['Beds', 'beds'], ['For', 'for'], ['Bathrooms', 'share'], ['Not used', 'closed'], ['Note', 'note'], ['ID', '_id']],
      key: r => lc(r.hall) + '|' + lc(r.floor), name: r => lc(r.hall) + '|' + lc(r.floor), compareFields: ['hall', 'floor', 'first', 'last', 'beds', 'for', 'share', 'closed', 'note']
    },
    places: {
      file: 'places', title: 'Buildings and rooms', keyField: 'name', part: 'conference', one: 'place', needs: ['schedule', 'shifts'], see: () => X.page('guide/', 'year=' + X.year + '&preview=1&view=places'), seeTitle: 'Places',
      sort: r => { const c = String(r.code || '').toUpperCase(), b = c.split('/')[0]; return b + (c.indexOf('/') > -1 ? '/1' + c : '/0'); },
      cols: [['Name', 'ed-c-what'], ['Code', 'ed-c-num'], ['Used by', 'ed-c-time'], ['Map', 'ed-c-for']],
      cells: r => { const room = String(r.code || '').indexOf('/') > -1, u = usedBy(r.code); return ['<span class="' + (room ? 'ed-indent' : '') + '"><b class="ed-title">' + esc(r.name || 'New place') + '</b></span>', '<span class="ed-code">' + esc(r.code || '?') + '</span>', esc(u.text), r.x !== '' && r.x != null && !isNaN(+r.x) && r.x !== undefined ? 'Pinned' : '']; },
      rowCls: r => String(r.code || '').indexOf('/') < 0 ? 'is-building' : '',
      label: r => r.name || r.code || 'New place', sub: r => r.code || '',
      blank: () => { const s = S.row; const b = s ? String(s.code || '').split('/')[0] : ''; return { code: b ? b + '/' : '', name: '', building: s ? (s.building || s.name || '') : '' }; },
      issues: r => { const out = []; if (!r.code) out.push({ text: 'No code', k: 'code' }); if (F.rows.some(x => x !== r && x._id !== r._id && lc(x.code) === lc(r.code))) out.push({ text: 'Same code as another place', k: 'code' }); return out; },
      fields: () => [
        ['line', 'name', 'Name', { help: 'Like Barnes Student Center, First Aid Room' }],
        ['custom', 'code', 'Code', { html: codeField, ro: r => roField(['text', 'code', 'Code'], r) }],
        ['custom', 'building', 'Building', { html: r => String(r.code || '').indexOf('/') < 0 ? '' : input('building', 'Building', val(r, 'building'), { list: 'ed-buildings', help: 'The building it’s in, for the map' }) + '<datalist id="ed-buildings">' + F.rows.filter(x => x.code && String(x.code).indexOf('/') < 0).map(x => '<option value="' + esc(x.name || x.code) + '">').join('') + '</datalist>', ro: r => roField(['text', 'building', 'Building'], r) }],
        ['custom', 'pin', 'Map', { html: pinField, ro: pinField }],
        ['custom', 'used', 'Used by', { html: usedField, ro: usedField }]
      ],
      exp: [['Code', 'code'], ['Name', 'name'], ['Building', 'building'], ['ID', '_id']],
      key: r => lc(r.code), name: r => lc(r.name), compareFields: ['code', 'name', 'building']
    },
    nearby: {
      file: 'nearby', title: 'Care nearby', keyField: 'name', part: 'conference', one: 'place', see: () => X.page('guide/', 'year=' + X.year + '&preview=1&view=places'), seeTitle: 'Places',
      sort: r => (NEAR_KINDS.findIndex(k => k[0] === r.kind) + 10) + lc(r.name),
      cols: [['Name', 'ed-c-what'], ['Kind', 'ed-c-for'], ['Phone', 'ed-c-time'], ['Checked', 'ed-c-num']],
      cells: r => ['<b class="ed-title">' + esc(r.name || 'New place') + '</b>' + (r.address ? ' <span class="ed-note">' + esc(r.address) + '</span>' : ''), esc(r.kind || ''), esc(r.phone || ''), r.checked ? esc(O.fmtDate(r.checked, 'mdShort')) : '<span class="ed-dim">Not checked</span>'],
      label: r => r.name || 'New place', sub: r => r.kind || '',
      blank: () => ({ kind: 'Urgent care', name: '' }),
      issues: r => { const out = []; const d = String(r.phone || '').replace(/\D/g, ''); if (r.phone && d.length !== 10 && !(d.length === 11 && d[0] === '1')) out.push({ text: 'Phone needs 10 digits', k: 'phone' }); if (!r.phone) out.push({ text: 'No phone', k: 'phone', soft: true }); return out; },
      fields: () => [
        ['line', 'name', 'Name'],
        ['custom', 'kind', 'Kind', { html: r => { const known = NEAR_KINDS.some(k => k[0] === r.kind); return pills('kind', known ? r.kind : r.kind ? '@other' : '', NEAR_KINDS.concat([['@other', 'Other']]), 'Kind') + (!known && r.kind ? input('kind', 'Kind, in words', r.kind === 'Other' ? '' : r.kind) : ''); } }],
        ['text', 'address', 'Address'],
        ['tel', 'phone', 'Phone', { help: 'The business number, like 765-660-7892' }],
        ['text', 'hours', 'Hours', { help: 'Like Open 24 hours · Blank shows nothing' }],
        ['text', 'distance', 'How far', { help: 'Like About 1 mile' }],
        ['custom', 'checked', 'Checked', { html: r => '<div class="ed-f"><span class="ed-f__l">Checked</span><p class="ed-inline">' + (r.checked ? 'Checked ' + esc(O.fmtDate(r.checked, 'mdy')) : 'Not checked') + (r.checked === X.today ? '' : ' · <button type="button" class="wk-linklike" data-checknow>Mark checked</button>') + '</p>' + help('Numbers and hours change: call or look each year', true) + '</div>', ro: r => roField(['text', 'checked', 'Checked'], r) }]
      ],
      exp: [['Kind', 'kind'], ['Name', 'name'], ['Address', 'address'], ['Phone', 'phone'], ['Hours', 'hours'], ['How far', 'distance'], ['Checked', 'checked'], ['ID', '_id']],
      key: r => lc(r.name), name: r => lc(r.name), compareFields: ['kind', 'name', 'address', 'phone', 'hours', 'distance']
    },
    help: {
      file: 'help', title: 'Help cards', keyField: 'need', part: 'packet', one: 'card', needs: ['contacts'], see: () => X.page('guide/', 'year=' + X.year + '&preview=1&view=help'), seeTitle: 'Help',
      cols: [['Need', 'ed-c-what'], ['Number', 'ed-c-time'], ['Hours', 'ed-c-where'], ['Number is', 'ed-c-for']],
      cells: r => ['<b class="ed-title">' + esc(r.need || 'New card') + '</b>' + (r._look || helpCarried(r) ? ' <span class="ed-tag ed-tag--check">To check</span>' : '') + (r.text ? '<span class="ed-note">' + esc(r.text) + '</span>' : ''), esc(r.phone || (r.link ? linkShort(r.link) : '')) + (r.phone && numberOf(r.phone) ? '<small class="ed-sub">' + esc(numberOf(r.phone).label) + '</small>' : ''), esc(nb(lc(r.hours) === 'desk' ? 'Desk hours' : r.hours || '')), esc(r.line === 'year' ? 'This year’s' : r.line === 'campus' ? 'Campus line' : '')],
      label: r => r.need || 'New card', sub: r => r.phone || '',
      blank: () => ({ need: '', text: '', phone: '', action: '', hours: '', line: 'year' }),
      issues: r => {
        const out = [];
        if (r.hours && lc(r.hours) !== 'desk' && O.parseHours && !O.parseHours(r.hours)) out.push({ text: 'Hours not read · Like Fri 5 PM–11 PM; Sat–Tue 8 AM–11 PM', k: 'hours' });
        if (!r.phone && !r.link) out.push({ text: 'No number or link', k: 'phone', soft: true });
        if (r.phone && aux.contacts && aux.contacts.rows.length && !aux.contacts.rows.some(c => digits(c.phone) === digits(r.phone)) && digits(r.phone).length > 3) out.push({ text: 'Not in the year’s numbers', k: 'phone', soft: true });
        wordFlags(r.text).forEach(t => out.push({ text: t, k: 'text', soft: true }));
        return out;
      },
      fields: () => [
        ['line', 'need', 'Need', { help: 'Like Lost something, I need a ride' }],
        ['area', 'text', 'Text', { help: 'One or two sentences · A role, never a name', max: 600 }],
        ['custom', 'phone', 'Number', { html: helpNumberField, ro: r => roField(['text', 'phone', 'Number'], r) }],
        ['pills', 'line', 'Number is', { opts: [['campus', 'Campus line', 'The venue’s own line: the same every year'], ['year', 'This year’s', 'A volunteer’s line: checked every year, never carried']], help: 'Campus line: the venue’s own, the same every year · This year’s: a volunteer’s, checked every year', after: r => helpCarried(r) ? '<p class="ed-flag">' + I.warn + 'Same number as ' + esc(X.prevRow.year) + ' · <button type="button" class="wk-linklike" data-helpchecked>Checked</button></p>' : '' }],
        ['text', 'action', 'Button', { help: 'Like Call First Aid' }],
        ['text', 'link', 'Link', { help: 'https:// only, for a card with a page instead of a number' }],
        ['custom', 'hours', 'Hours', { html: r => input('hours', 'Hours', val(r, 'hours'), { help: 'Like Fri 5 PM–11 PM; Sat–Tue 8 AM–11 PM · “desk” to follow the desk hours · Blank if any time', echo: esc(hoursEcho(r.hours)) }) }],
        ['text', 'open', 'Open now label', { help: 'Its name under Open now in the guide while it’s open, like First Aid Room' }],
        ['text', 'pin', 'PIN']
      ],
      exp: [['Need', 'need'], ['Text', 'text'], ['Phone', 'phone'], ['PIN', 'pin'], ['Button', 'action'], ['Link', 'link'], ['Hours', 'hours'], ['Open now label', 'open'], ['Number is', 'line'], ['ID', '_id']],
      key: r => lc(r.need), name: r => lc(r.need), compareFields: ['need', 'text', 'phone', 'pin', 'action', 'link', 'hours', 'open', 'line']
    },
    notices: {
      // A new notice is a draft (its From is the "not yet" date, so no page shows it) until Post: nothing
      // half-typed reaches the public. A posted notice's words are saved when the field is left.
      file: 'notices', title: 'Notices', keyField: 'text', part: 'conference', one: 'notice', see: () => X.page('', 'year=' + X.year + '&preview=1'), seeTitle: 'Conference page',
      sort: r => (r.draft ? '0' : '1') + (r.from || '9'),
      cols: [['Notice', 'ed-c-what'], ['From', 'ed-c-num'], ['Until', 'ed-c-num'], ['Showing', 'ed-c-for']],
      cells: r => ['<b class="ed-title ed-title--plain">' + esc(r.text || 'New notice') + '</b>', r.draft ? '<span class="ed-dim">' + esc(r.post_from && r.post_from > X.today ? O.fmtDate(r.post_from, 'mdShort') : 'When posted') + '</span>' : esc(r.from ? O.fmtDate(r.from, 'mdShort') : ''), esc(r.to ? O.fmtDate(r.to, 'mdShort') + (r.until_time && r.until_time !== '11:59 PM' ? ' ' + R.fmt(R.minutes(r.until_time)) : '') : ''), r.draft ? '<span class="ed-tag ed-tag--check">Draft</span>' : esc(noticeState(r))],
      rowCls: r => noticeState(r) === 'Ended' ? 'is-ended' : '',
      label: r => r.text ? r.text.slice(0, 40) : 'New notice', sub: r => noticeState(r),
      blank: () => ({ from: NOT_YET, post_from: X.today, to: X.today, until_time: '11:59 PM', text: '', url: '', draft: 'yes' }),
      issues: r => {
        const out = [];
        if (!r.to) out.push({ text: 'No end date · Shows until removed', k: 'to' });
        const from = r.draft ? r.post_from || X.today : r.from;
        if (from && r.to && r.to < from) out.push({ text: 'Ends before it starts', k: 'to' });
        if (String(r.text || '').length > 140) out.push({ text: 'Long for one line', k: 'text', soft: true });
        // A public banner: the house rules are warnings here, and Post asks once more.
        wordFlags(r.text).forEach(t => out.push({ text: t, k: 'text' }));
        return out;
      },
      fields: () => [
        ['custom', 'text', 'Notice', { html: r => input('text', 'Notice', val(r, 'text'), { max: 200, help: 'One line · No exclamation marks' + (r.draft ? '' : ' · Saved when you leave the field'), echo: '<span data-count>' + String(r.text || '').length + ' of 140</span>' }) }],
        ['custom', 'from', 'From', { html: r => r.draft ? typedDate('post_from', 'From', r.post_from || X.today, 'Like Sun Oct 10 · Today when blank') : typedDate('from', 'From', r.from, 'Like Sun Oct 10'), ro: r => roField(['text', 'x', 'From'], { x: r.from ? O.fmtDate(r.from, 'short') : '' }) }],
        ['custom', 'to', 'Until', { html: r => typedDate('to', 'Until', r.to, 'Like Mon Oct 11') + '<p class="ed-quick"><button type="button" class="wk-linklike" data-ends="tonight">Ends tonight</button><button type="button" class="wk-linklike" data-ends="tomorrow">Ends tomorrow</button>' + (X.row.end && X.row.end >= X.today ? '<button type="button" class="wk-linklike" data-ends="last">Last day</button>' : '') + '</p>' + input('until_time', 'Ends at', r.until_time && r.until_time !== '11:59 PM' ? R.fmt(R.minutes(r.until_time)) : '', { help: 'Blank for the end of the day', cls: 'ed-f--sub', echo: '' }), ro: r => roField(['text', 'x', 'Until'], { x: r.to ? O.fmtDate(r.to, 'short') : '' }) }],
        ['text', 'url', 'Link', { help: 'https:// only · Optional' }],
        ['custom', 'where', 'Shows', { html: r => '<div class="ed-f"><span class="ed-f__l">Shows</span><p class="ed-inline">' + esc(r.draft ? 'Draft · Not public until Post' : noticeState(r)) + '</p>' + help('Under the Conference’s title and in the guide', true) + '</div>', ro: r => '' }]
      ],
      exp: [['From', 'from'], ['Until', 'to'], ['Notice', 'text'], ['Link', 'url'], ['ID', '_id']],
      key: r => lc(r.text), name: r => lc(r.text), compareFields: ['from', 'to', 'text', 'url']
    },
    numbers: {
      file: 'contacts', title: 'Numbers', keyField: 'label', part: 'conference', one: 'number', see: () => X.page('schedule/', 'year=' + X.year + '&preview=1'), seeTitle: 'Printed schedule',
      cols: [['Role', 'ed-c-what'], ['Number', 'ed-c-time'], ['Shows on', 'ed-c-where'], ['Line', 'ed-c-for']],
      cells: r => ['<b class="ed-title">' + esc(r.label || 'New number') + '</b>' + (r.hours ? ' <span class="ed-note">' + esc(r.hours) + '</span>' : ''), esc(r.phone || '') + (r.pin ? ' <small class="ed-sub">PIN ' + esc(r.pin) + '</small>' : ''), esc(String(r.shows || '').split('|').filter(Boolean).map(s => (SHOWS.find(x => x[0] === s) || [0, s])[1]).join(', ')), esc(r.line === 'campus' ? 'Campus line' : r.line === 'year' ? 'This year’s' : '')],
      label: r => r.label || 'New number', sub: r => r.phone || '',
      blank: () => ({ label: '', phone: '', shows: 'help|print', line: 'year' }),
      issues: r => { const out = []; const d = digits(r.phone); if (r.phone && d.length !== 10 && d.length !== 3 && !(d.length === 11 && d[0] === '1')) out.push({ text: 'Phone needs 10 digits', k: 'phone' }); return out; },
      fields: () => [
        ['line', 'label', 'Role', { help: 'A role, never a name: Lodging desk, First Aid, Call-in line' }],
        ['tel', 'phone', 'Number'],
        ['text', 'pin', 'PIN', { help: 'For the call-in line' }],
        ['text', 'hours', 'Hours', { help: 'Like Fri 5 PM–11 PM; Sat–Tue 8 AM–11 PM' }],
        ['multi', 'shows', 'Shows on', { opts: SHOWS }],
        ['pills', 'line', 'Line', { opts: [['campus', 'Campus line', 'The venue’s own line: kept with the campus'], ['year', 'This year’s', 'A volunteer’s line: checked every year']] }],
        ['area', 'note', 'Note']
      ],
      exp: [['Role', 'label'], ['Number', 'phone'], ['PIN', 'pin'], ['Hours', 'hours'], ['Shows on', 'shows'], ['Line', 'line'], ['Note', 'note'], ['ID', '_id']],
      key: r => lc(r.label), name: r => lc(r.label), compareFields: ['label', 'phone', 'pin', 'hours', 'shows', 'line', 'note']
    }
  };
  // A column's name in words, for the import's review.
  const WORDS = { day: 'Day', last_day: 'Repeats', start: 'Starts', end: 'Ends', title: 'What', place: 'Where', audience: 'For', note: 'Note', call_in: 'Call-in', committee: 'Committee', role: 'Job', needed: 'Needed', rule: 'Requirement', name: 'Name', min: 'Fewest', max: 'Most', opens: 'Opens', closes_day: 'Closes', closes_time: 'Closes at', hall: 'Hall', floor: 'Floor', first: 'First room', last: 'Last room', beds: 'Beds', for: 'For', share: 'Bathrooms', closed: 'Not used', code: 'Code', building: 'Building', kind: 'Kind', address: 'Address', phone: 'Phone', hours: 'Hours', distance: 'How far', need: 'Need', text: 'Text', action: 'Button', link: 'Link', open: 'Open now as', line: 'Number is', from: 'From', to: 'Until', url: 'Link', label: 'Role', shows: 'Shows on', pin: 'PIN' };
  const ALIAS = { rooms: 'halls', helpcards: 'help', contacts: 'numbers' };
  const SHARE_LABEL = { '': '', private: 'Private bath', pairs: 'Shared by pairs', hall: 'Down the hall' };
  const NEAR_KINDS = [['Urgent care', 'Urgent care'], ['Hospital ER', 'Hospital ER'], ['Pharmacy', 'Pharmacy']];
  const SHOWS = [['help', 'Help'], ['print', 'Printout'], ['packet', 'Packet']];
  const digits = v => String(v || '').replace(/\D/g, '');
  // Times kept on one line: "9 PM–11 PM" never breaks inside a time or at its dash.
  const nb = v => String(v || '').replace(/(\d) (AM|PM)/g, '$1\u00a0$2').replace(/ ?– ?/g, '\u2060–\u2060');
  // The year's number a Help card's phone is (Numbers), and a volunteer's number carried unchanged.
  const numberOf = ph => (aux.contacts ? aux.contacts.rows : []).find(c => digits(c.phone) && digits(c.phone) === digits(ph)) || null;
  const helpCarried = r => !!(spec && spec.file === 'help' && digits(r.phone).length >= 10 && r.line !== 'campus' && r.checked !== X.today && !(r.checked && r.checked.slice(0, 4) === X.today.slice(0, 4)) &&
    (prev.help || []).some(p => lc(p.need) === lc(r.need) && digits(p.phone) === digits(r.phone)));
  // A Help card's number: one of the year's Numbers (chosen by role), or a new one added there.
  function helpNumberField(r) {
    const list = (aux.contacts ? aux.contacts.rows : []).filter(c => c.phone), cur = numberOf(r.phone);
    return '<div class="ed-f" role="group" aria-label="Number"><span class="ed-f__l">Number</span>' + (list.length ? '<span class="rf-seg ed-pills ed-pills--wrap">' + list.map(c => '<button type="button" data-helpnum="' + esc(c.phone) + '" aria-pressed="' + (cur === c) + '">' + (cur === c ? I.check : '') + esc(c.label || c.phone) + '</button>').join('') + '</span>' : '') +
      '</div>' + input('phone', list.length ? 'Or a number' : 'Number', cur ? '' : val(r, 'phone'), { mode: 'tel', help: list.length ? 'Typed here, it’s added to Numbers when you leave the field' : 'Like 765-660-7892 · Added to Numbers when you leave the field' }) + (cur ? '<p class="ed-inline ed-dim">' + esc(cur.phone) + '</p>' : '');
  }
  const linkShort = u => { try { return new URL(u).hostname.replace(/^www\./, ''); } catch (e) { return u; } };
  const forLabel = f => ({ families: 'Families', 'young men': 'Young men', 'young women': 'Young women' })[f || 'families'] || f;
  const floorName = f => f === '' || f == null ? 'Floor' : +f === 1 ? 'Ground floor' : 'Floor ' + f;
  function roomsOf(r) {
    const a = parseInt(r.first, 10), b = parseInt(r.last, 10);
    if (isNaN(a)) return 0;
    const n = isNaN(b) ? 1 : Math.max(0, b - a + 1);
    return Math.max(0, n - String(r.closed || '').split(/[\s,;]+/).filter(x => /\d/.test(x)).length);
  }
  const planOf = r => { const ps = (aux.plans || []).filter(p => lc(p.hall) === lc(r.hall) && String(p.floor) === String(r.floor) && /room/i.test(p.kind || '')); return ps.length; };
  function noticeState(r) {
    const d = X.today;
    if (r.draft) return 'Draft';
    if (r.to && r.to < d) return 'Ended';
    if (r.from && r.from > d) return 'From ' + O.fmtDate(r.from, 'mdShort');
    return 'Showing';
  }
  // "Sat 9 AM: Open" for the first day of Conference at 9 AM, as the guide will work it out.
  function hoursEcho(h) {
    if (!h) return 'Any time';
    if (lc(h) === 'desk') return 'Follows the desk hours on the schedule';
    const p = O.parseHours ? O.parseHours(h) : null;
    if (!p) return 'Not read yet';
    const d0 = X.days[1] || X.days[0];
    if (!d0) return 'Read';
    const dow = new Date(d0.date + 'T12:00:00Z').getUTCDay(), at = 9 * 60;
    const open = p.some(x => x.days.indexOf(dow) > -1 && x.ranges.some(g => at >= g[0] && at < (g[1] <= g[0] ? g[1] + 1440 : g[1])));
    return short(d0.name) + ' 9 AM: ' + (open ? 'Open' : 'Closed');
  }

  // A tournament's event: a Youngfolks row of the schedule, chosen from a list and kept by its id.
  const eventOf = r => { const rows = aux.schedule ? aux.schedule.rows : []; return rows.find(x => r.schedule_id && x._id === r.schedule_id) || rows.find(x => r.schedule_title && lc(x.title) === lc(r.schedule_title)) || null; };
  const eventLine = e => [short(e.day), timeText(e), (placeOf(e.place) || {}).name || e.place || ''].filter(Boolean).join(' · ');
  // The chosen row with Change; Change is a type-ahead of the schedule, tournaments first.
  function eventRows(q) {
    const t = lc(q), sport = /tournament|volleyball|basketball|spikeball|chess|blitz|soccer|softball|game/i;
    return (aux.schedule ? aux.schedule.rows : []).filter(x => x.title && (!t || lc(x.title).indexOf(t) > -1))
      .sort((a, b) => (sport.test(b.title) - sport.test(a.title)) || (/^young ?folks?$/.test(lc(b.audience)) - /^young ?folks?$/.test(lc(a.audience))) || dayIx(a.day) - dayIx(b.day) || tStart(a) - tStart(b)).slice(0, 8);
  }
  const eventList = (r, q) => { const cur = eventOf(r); return eventRows(q).map(x => '<li><button type="button" data-event="' + esc(x._id) + '" aria-pressed="' + (cur === x) + '">' + (cur === x ? I.check : '') + '<b>' + esc(x.title) + '</b><small>' + esc(eventLine(x)) + '</small></button></li>').join('') || '<li class="ed-dim">No row like that</li>'; };
  function eventField(r) {
    const cur = eventOf(r);
    if (cur && !S.eventOpen) return '<div class="ed-f"><span class="ed-f__l">Event</span><p class="ed-inline"><b>' + esc(cur.title) + '</b> · ' + esc(eventLine(cur)) + ' · <button type="button" class="wk-linklike" data-eventopen>Change</button></p>' + help('Its day, time and place come from the schedule', true) + '</div>';
    return '<div class="ed-f"><label class="ed-f__l" for="ed-eventq">Event</label><input class="ed-in" id="ed-eventq" data-eventq data-fk="eventq" placeholder=" " autocomplete="off" spellcheck="false"><ul class="ed-pick" data-eventlist>' + eventList(r, '') + '</ul>' + help('Type to find its row on the schedule', true) + '</div>';
  }
  // A date typed as people say it ("Thu May 7", "5/7") → its ISO date, said back.
  function typedDate(k, label, v, h) {
    return input(k + '_typed', label, v && v !== NOT_YET ? O.fmtDate(v, 'short') : '', { help: h, echo: '' });
  }
  function closesField(r) {
    const t = [r.closes_day ? short(r.closes_day) : '', r.closes_time ? (R.minutes(r.closes_time) != null ? R.fmt(R.minutes(r.closes_time)) : r.closes_time) : ''].filter(Boolean).join(' ');
    return input('closes_typed', 'Sign-ups close', t, { help: 'Like Fri noon, Sat 10:15 PM', echo: r.closes_day ? esc(r.closes_day + (r.closes_time ? ', ' + R.fmt(R.minutes(r.closes_time)) : '') + (dayDate(r.closes_day) ? ' · ' + O.fmtDate(dayDate(r.closes_day), 'md') : '')) : '' });
  }
  function kindField(r) {
    const g = R.guessKind(r.title), k = r.kind || g, all = KINDS.concat(MORE_KINDS);
    if (!S.kindOpen) return '<div class="ed-f"><span class="ed-f__l">Kind</span><p class="ed-inline">' + esc(kindLabel(k) || 'None') + (!r.kind && g ? ' <small class="ed-dim">(guessed)</small>' : '') + ' · <button type="button" class="wk-linklike" data-kindopen>Change</button></p>' + help('How the page draws it: services stand out, meals open their menus', true) + '</div>';
    return pills('kind', r.kind, KINDS, 'Kind') + input('kind_typed', 'Other kind', '', { list: 'ed-kinds', help: 'Type to find: Council, Communion, Snack…' }) + '<datalist id="ed-kinds">' + all.map(x => '<option value="' + esc(x[1]) + '">').join('') + '</datalist>';
  }
  function alsoField(r) {
    const codes = String(r.also || '').split('|').filter(Boolean);
    return '<div class="ed-f ed-also"><span class="ed-f__l">Also at</span>' + (codes.length ? '<p class="ed-chips">' + codes.map(c => '<span class="ed-chip">' + esc((placeOf(c) || {}).name || c) + ' <button type="button" class="ed-chip__x" data-alsox="' + esc(c) + '" aria-label="Remove ' + esc(c) + '">' + I.close + '</button></span>').join('') + '</p>' : '') +
      placeField('also_add', { also_add: '' }, 'Add a place', true) + '</div>';
  }
  function ruleField(r) {
    const ages = [['', 'None'], ['16 or older', '16+'], ['18 or older', '18+'], ['21 or older', '21+']];
    const known = ages.some(a => a[0] === (r.rule || ''));
    return pills('rule', known ? r.rule || '' : '@other', ages.concat([['@other', 'Other']]), 'Requirement', { help: 'Each volunteer confirms it when they join' }) + (!known || S.ruleOther ? input('rule', 'Requirement, in words', known ? '' : r.rule, { help: 'Like Certified in first aid, Screened for working with children' }) : '');
  }
  // Days: one row of day pills; tap the first day, then the last.
  function daysRange(r) {
    const a = dayIx(r.day), b = r.last_day ? dayIx(r.last_day) : a, n = a > -1 && b >= a ? b - a + 1 : 0;
    const places = n * (+r.needed || 0);
    return '<div class="ed-f" role="group" aria-label="Days"><span class="ed-f__l">Days</span><span class="rf-seg ed-pills">' +
      X.days.map((d, i) => { const on = i >= a && i <= b && a > -1; return '<button type="button" data-range="' + esc(d.name) + '" aria-pressed="' + on + '"' + (S.anchor === d.name ? ' class="is-anchor"' : '') + '>' + (on ? I.check : '') + esc(short(d.name)) + '</button>'; }).join('') +
      '</span><small class="ed-echo">' + (n > 1 || places ? plural(n, 'day') + (places ? ' · ' + plural(places, 'place') : '') : '') + (S.anchor ? (n > 1 || places ? ' · ' : '') + 'Now tap the last day' : '') + '</small>' + help(spec.file === 'schedule' ? 'Tap its day; for a row on several days, then the last' : 'Tap the first day, then the last', true) + '</div>';
  }
  function peopleField(r) {
    const ds = shiftDays(r).filter(d => d.have);
    if (!ds.length) return '';
    return '<div class="ed-f"><span class="ed-f__l">Signed up · ' + ds.reduce((n, d) => n + d.have, 0) + '</span><ul class="ed-people">' + ds.map(d => '<li><b>' + esc(short(d.day)) + '</b> ' + d.ups.map(p => esc(nameOf(p))).join(', ') + '</li>').join('') + '</ul>' +
      '<p class="ed-inline"><a href="' + esc(X.page('volunteer/', 'year=' + X.year + '&view=lead&committee=' + encodeURIComponent(r.committee || ''))) + '">Who’s signed up</a> · Add someone without email there</p></div>';
  }

  /* ---- Buildings and rooms: a code used everywhere, a pin on the map */

  // What hangs on a schedule row (moving it carries them along, on the server).
  function linkedField(r) {
    const a = (aux.attachments || []).filter(x => lc(x.day) === lc(r.day) && R.minutes(x.start) != null && R.minutes(x.start) === R.minutes(r.start) && (!x.match || lc(x.match) === lc(r.title)));
    const t = (aux.tlist || []).filter(x => (x.schedule_id && x.schedule_id === r._id) || (x.schedule_title && lc(x.schedule_title) === lc(r.title)));
    const parts = a.map(x => (x.kind === 'sermon' ? 'Sermon' : x.kind === 'minutes' ? 'Minutes' : 'Recording') + ': ' + x.title).concat(t.map(x => 'Tournament: ' + x.name));
    return parts.length ? '<div class="ed-f"><span class="ed-f__l" title="Moving the row carries them along">Linked</span><p class="ed-inline">' + parts.map(esc).join(' · ') + '</p></div>' : '';
  }
  function usedBy(code) {
    if (!code) return { n: 0, text: '', rows: 0, shifts: 0 };
    const c = lc(code);
    const sr = (aux.schedule ? aux.schedule.rows : []).filter(r => lc(r.place) === c || String(r.also || '').toLowerCase().split('|').indexOf(c) > -1).length;
    const sh = (aux.shifts ? aux.shifts.rows : []).filter(r => lc(r.place) === c).length;
    return { n: sr + sh, rows: sr, shifts: sh, text: [sr ? plural(sr, 'schedule row') : '', sh ? plural(sh, 'shift') : ''].filter(Boolean).join(' · ') };
  }
  function usedField(r) {
    const u = usedBy(r.code);
    if (!u.n) return '<div class="ed-f"><span class="ed-f__l">Used by</span><p class="ed-inline ed-dim">Nothing yet</p></div>';
    return '<div class="ed-f"><span class="ed-f__l">Used by</span><p class="ed-inline">' + (u.rows ? '<a href="' + esc(X.page('admin/', 'year=' + X.year + '&edit=schedule&q=' + encodeURIComponent(r.code))) + '">' + plural(u.rows, 'schedule row') + '</a>' : '') + (u.rows && u.shifts ? ' · ' : '') + (u.shifts ? '<a href="' + esc(X.page('admin/', 'year=' + X.year + '&edit=shifts&q=' + encodeURIComponent(r.code))) + '">' + plural(u.shifts, 'shift') + '</a>' : '') + '</p></div>';
  }
  function codeField(r) {
    return input('code', 'Code', val(r, 'code'), { help: 'As on the signs: B, B/131, J · Renaming it renames it everywhere', max: 32 });
  }
  function pinField(r) {
    const pinned = r.x !== '' && r.x != null && !isNaN(+r.x);
    const href = X.yearHref('conference', '&tool=pins&code=' + encodeURIComponent(r.code || ''));
    return '<div class="ed-f"><span class="ed-f__l">Map</span><p class="ed-inline">' + I.pin + (pinned ? 'Pinned · <a href="' + esc(href) + '">Change</a>' : String(r.code || '').indexOf('/') > -1 ? 'By its building · <a href="' + esc(href) + '">Pin</a>' : 'By its building on the campus map') + '</p>' + help('Directions lead to the door nearest the pin', true) + '</div>';
  }

  /* ================================================================ opening an editor */

  async function open() {
    X = ED.X; I = ED.I;
    const parts = X.edit.split(/:(.*)/), k0 = parts[0], arg = parts[1] || '', k = ALIAS[k0] || k0;
    spec = SPECS[k];
    if (!spec) { location.replace(X.yearHref(X.back || '')); return; }
    spec.id = k;
    S = { group: arg, sel: '', multi: new Set(), q: new URLSearchParams(location.search).get('q') || '', ro: X.held, view: 'table', zoom: 1, conflicts: [], flash: new Set() };
    try { S.view = localStorage.getItem('ogc-ed-view') || 'table'; } catch (e) { /* table */ }
    X.title(spec.title);
    root.innerHTML = X.frame({ title: spec.title }) + '<div class="ed ed--loading"><p class="ws-empty">Loading</p></div>';
    F = new ED.Rows(X.year, spec.file, { readOnly: S.ro });
    // Everything comes from the year's bundle (already read); last year's is one more request.
    const b = X.bundle || {};
    const loads = [F.load(b[spec.file])];
    (spec.needs || []).forEach(n => {
      if (n === 'plans' || n === 'guide') return;
      aux[n] = new ED.Rows(X.year, n, { readOnly: S.ro || n !== 'places' && n !== 'committees' && !(n === 'contacts' && spec.id === 'help') });
      loads.push(aux[n].load(b[n]).catch(() => null));
    });
    aux.plans = (b.plans || {}).rows || []; aux.guide = (b.guide || {}).rows || []; aux.attachments = (b.attachments || {}).rows || []; aux.tlist = (b.tournaments || {}).rows || [];
    // Last year's (for comparing and "From 2026") arrives after the page is drawn.
    if (X.prevRow) fetchJson('years/' + X.prevRow.year + '/bundle').then(d => { Object.keys(d || {}).forEach(n => { prev[n] = d[n].rows || []; }); if (S && root.querySelector('[data-main]')) paint(['rail', 'main', 'insp']); }).catch(() => null);
    // Sign-ups (shifts) and teams (tournaments): the store reads the year's records once, at O.ready.
    if (spec.file === 'shifts' || spec.file === 'tournaments') loads.push((O.ready || Promise.resolve()).then(() => { const k = spec.file === 'shifts' ? 'signups' : 'teams'; people = O.records.list(k, X.year) || []; }).catch(() => null));
    try { await Promise.all(loads); } catch (e) { console.error(e); root.querySelector('.ed').innerHTML = '<p class="ws-empty">Couldn’t load · <button type="button" class="wk-linklike" onclick="location.reload()">Retry</button></p>'; return; }
    wire();
    const gs = spec.groups ? spec.groups() : null;
    if (gs) S.group = (gs.find(g => g.id === arg) || gs.find(g => !g.faint && !g.extra) || gs[0] || {}).id || '';
    // From the year's "Check the rows" step: the first row to check, open.
    if (new URLSearchParams(location.search).get('check')) { const r = visible().find(r0 => r0._look) || F.rows.find(r0 => r0._look); if (r) { S.group = spec.groups ? (spec.file === 'schedule' ? r.day : r.committee) : ''; S.sel = r._id; } }
    draw();
    poll();
    // From the year page's "Add committee": the field, ready to type.
    if (new URLSearchParams(location.search).get('add') === 'committee') { const f = root.querySelector('[data-newgroup]'); if (f) f.focus(); }
  }
  const fetchJson = p => ED.api('GET', p);

  /* ================================================================ drawing */

  // What the public sees of this editor's list right now, worked out on the server by the same rules
  // that decide it (module-editors.php ogc_ed_public_lines): never a promise the pages don't keep.
  function pubState() {
    const P = ((window.OGC_WP || {}).editors || {}).public, p = P && P[spec.file], sched = P ? P._schedule : true;
    if (X.held) return X.publicState(spec.part, spec.gate || 'x');
    const live = { word: 'Public · Changes show at once', cls: 'is-live', tip: 'On the Conference page and the guide' };
    const withSched = { word: 'Shows with the schedule', cls: '', tip: 'Public once the schedule is published', link: ['Publish', X.yearHref('schedule')] };
    if (spec.file === 'schedule' || spec.file === 'shifts') return X.publicState(spec.part, spec.gate);
    if (!P) return spec.priv ? X.publicState('private') : live;
    if (spec.file === 'rooms') return p && p.shown ? { word: 'Households choosing rooms see it', cls: 'is-live', tip: 'Free and taken rooms only, while registration is open' } : { word: 'Committees only', cls: '', tip: P._room_choice === 'households' ? 'Households see free rooms only while registration is open' : 'Never on a public page' };
    if (p && p.private) return { word: 'Committees only', cls: '', tip: 'Never on a public page' };
    if (spec.file === 'tournaments') return p && !p.visible ? { word: 'Not public', cls: '', tip: 'Held on the Youngfolks part', link: ['Youngfolks', X.yearHref('youngfolks')] } : sched ? live : withSched;
    if (spec.file === 'help' || spec.file === 'nearby' || spec.file === 'contacts') {
      if (!sched) return withSched;
      if (p && p.total > p.shown) return { word: 'Public · ' + (p.total - p.shown) + ' wait for Looks right', cls: 'is-live', tip: 'Carried from last year: each shows once it’s checked on the year’s page' };
      return live;
    }
    if (spec.file === 'notices') return { word: 'Public · Each by its dates', cls: 'is-live', tip: 'A posted notice shows from its From date to its Until date' };
    return live;
  }
  // The bar: Find, See it, and the file things (Export, Import, Print, Rooms booked) under one File menu.
  function toolsHtml() {
    const see = spec.see(S.group), empty = !F.rows.length;
    const printHref = (window.OGC_WP && window.OGC_WP.url ? window.OGC_WP.url('../schedule/') : '../schedule/') + '?year=' + encodeURIComponent(ED.X.year);
    const items = [
      empty ? '' : '<li><button type="button" role="menuitem" data-export>Export</button></li>',
      empty || spec.file !== 'schedule' ? '' : '<li><button type="button" role="menuitem" data-rooms title="Every room booked, for the venue">Rooms booked</button></li>',
      S.ro ? '' : '<li class="ed-file__wide"><button type="button" role="menuitem" data-import>Import</button></li>',
      empty ? '' : spec.file === 'schedule' ? '<li class="ed-file__wide"><a role="menuitem" href="' + esc(printHref) + '" title="The printable schedule">Print</a></li>' : spec.file === 'shifts' ? '<li class="ed-file__wide"><button type="button" role="menuitem" data-print title="What’s shown, marked as a draft">Print</button></li>' : ''
    ].filter(Boolean);
    return '<div class="ed-bartools" data-tools>' + (empty ? '' : '<form class="ed-find" role="search" data-findform><label><span class="ogc-sr">Find</span>' + I.search + '<input type="search" data-find value="' + esc(S.q) + '" placeholder="Find" title="/" autocomplete="off" spellcheck="false"></label><button type="button" class="ed-find__x" data-clearfind aria-label="Clear"' + (S.q ? '' : ' hidden') + '>' + I.close + '</button></form>') +
      (items.length ? '<div class="ed-file"><button type="button" class="wk-linklike ed-file__b" data-filemenu aria-haspopup="true" aria-expanded="false">File' + I.down + '</button><ul class="ed-file__m" role="menu" hidden>' + items.join('') + '</ul></div>' : '') +
      '<a class="ws-see" ' + X.seeAttrs(see) + ' data-see-title="' + esc(spec.seeTitle || spec.title) + '">' + I.eye + 'See it</a><input type="file" hidden data-file accept=".csv,.tsv,.txt,.xlsx,text/csv"></div>';
  }
  function draw() {
    const st = pubState();
    const tools = toolsHtml();
    const title = spec.file === 'shifts' && S.group && S.group[0] !== '@' ? S.group + ' shifts' : spec.title;
    // A schedule with no days and no rows has nothing for a rail.
    const rail = !!spec.groups && (spec.file !== 'schedule' || X.days.length || F.rows.length);
    root.innerHTML = X.frame({ title, state: st, unlock: X.held && X.webmaster && S.ro, tools }) +
      '<div class="ed ed--' + spec.id + (rail ? ' has-rail' : '') + (S.ro ? ' is-ro' : '') + (spec.file === 'schedule' && S.view === 'day' ? ' is-day' : '') + '" data-ed>' +
      (rail ? '<nav class="ed-rail" data-rail aria-label="' + esc(spec.rail) + '"></nav>' : '') +
      '<section class="ed-main" data-main aria-label="' + esc(spec.title) + '"></section>' +
      '<aside class="ed-insp" data-insp aria-labelledby="ed-insp-h" hidden></aside></div>';
    X.title(S.group && S.group[0] !== '@' && spec.groups ? (spec.file === 'shifts' ? S.group + ' shifts' : S.group + ' · ' + spec.title) : spec.title);
    paint(['rail', 'main', 'insp']);
    if (dayRO) { dayW = 0; dayRO.disconnect(); dayRO.observe(root.querySelector('[data-main]')); }
    status();
  }
  // Paint parts again, keeping focus (and the caret) where it was.
  function paint(which, focusSel) {
    // A field left while it's being redrawn fires its own change: that nested redraw is skipped.
    if (S.painting) return;
    S.painting = true;
    try { paintNow(which, focusSel); } finally { S.painting = false; }
  }
  function paintNow(which, focusSel) {
    const a = document.activeElement, fk = a && a.dataset ? (a.dataset.fk || '') : '', caret = a && a.selectionStart != null ? [a.selectionStart, a.selectionEnd] : null;
    const inInsp = a && a.closest && a.closest('[data-insp]');
    if (which.indexOf('rail') > -1) { const el = root.querySelector('[data-rail]'); if (el) el.innerHTML = railHtml(); }
    if (which.indexOf('main') > -1) { const el = root.querySelector('[data-main]'); if (el) { el.innerHTML = mainHtml(); if (S.view === 'day') measureDay(); if (S.q.trim()) markFinds(el); } }
    if (which.indexOf('insp') > -1) paintInsp();
    // The first row added to an empty list (or the last removed): Find and File follow.
    const has = !!F.rows.length;
    if (S.hadRows != null && S.hadRows !== has) { const t = root.querySelector('[data-tools]'); if (t) t.outerHTML = toolsHtml(); }
    S.hadRows = has;
    if (focusSel) { const f = root.querySelector(focusSel); if (f) f.focus({ preventScroll: true }); }
    else if (fk && inInsp && which.indexOf('insp') > -1) { const f = root.querySelector('[data-insp] [data-fk="' + CSS.escape(fk) + '"]'); if (f) { f.focus({ preventScroll: true }); if (caret && f.setSelectionRange) try { f.setSelectionRange(caret[0], caret[1]); } catch (e) { /* not a text field */ } } }
    growAll();
  }
  const growAll = () => root.querySelectorAll('textarea.ed-grow').forEach(grow);
  const grow = el => { el.style.height = 'auto'; el.style.height = (el.scrollHeight + 2) + 'px'; };

  /* ---- the rail */

  function railHtml() {
    const gs = spec.groups(), here = F.here || [];
    const who = g => here.filter(h => h.group === g.id).map(h => '<span class="ed-face" title="' + esc(h.name + ' is here') + '">' + esc(initials(h.name)) + '</span>').join('');
    const main = gs.filter(g => !g.faint && !g.extra), extra = gs.filter(g => g.extra), faint = gs.filter(g => g.faint);
    // While finding: how many matches each day (or committee) has; the ones with none are dimmed.
    const q = lc(S.q), found = g => q ? F.rows.filter(r => spec.inGroup(r, g.id) && shownText(r).indexOf(q) > -1).length : 0;
    const one = spec.file === 'schedule' ? 'row' : spec.one;
    const item = g => { const f = found(g); return '<li><button type="button" class="ed-rail__b' + (g.warn ? ' is-warn' : '') + (q && !f ? ' is-none' : '') + '" data-group="' + esc(g.id) + '" aria-current="' + (g.id === S.group && !S.q ? 'true' : 'false') + '"' + (g.faint ? ' data-fromgroup="' + esc(g.label) + '"' : '') + '>' +
      '<span class="ed-rail__t"><b>' + esc(g.label) + '</b><small>' + esc(q ? (f ? f + ' found' : 'None found') : spec.file === 'shifts' ? (g.n ? plural(g.n, 'shift') + (g.sub && g.sub !== 'No shifts' ? ' · ' + g.sub : '') : 'No shifts') : [g.sub, g.n ? plural(g.n, one) : ''].filter(Boolean).join(' · ')) + '</small>' +
      (!q && (g.check || g.callin) ? '<small class="ed-rail__marks">' + [g.check ? g.check + ' to check' : '', g.callin ? g.callin + ' call-in' : ''].filter(Boolean).join(' · ') + '</small>' : '') + '</span>' + who(g) + '</button></li>'; };
    const narrow = isNarrow(), adding = spec.file === 'shifts' && !S.ro && narrow && !S.addingGroup ? '<li><button type="button" class="ed-rail__b ed-rail__add" data-addcommittee>' + I.plus + 'Committee</button></li>' : '';
    let html = '<ul class="ed-rail__list' + (S.q ? ' is-dim' : '') + '">' + main.map(item).join('') + adding + '</ul>';
    if (extra.length) html += '<ul class="ed-rail__list ed-rail__extra">' + extra.map(item).join('') + '</ul>';
    if (spec.file === 'shifts' && !S.ro) html += '<form class="ed-addgroup" data-addgroup' + (narrow && !S.addingGroup ? ' hidden' : '') + '><label class="ed-f"><span class="ed-f__l">Add committee</span><input class="ed-in" data-newgroup list="ed-oldgroups" placeholder=" " autocomplete="off"></label><datalist id="ed-oldgroups">' + uniq((prev.shifts || []).map(r => r.committee).concat(['Transportation', 'Ushers', 'Dining hall', 'Lodging desk', 'First aid', 'Nursery', 'Preteens', 'Youngfolks'])).map(c => '<option value="' + esc(c) + '">').join('') + '</datalist><button type="submit" class="wk-btn wk-btn--line wk-btn--small">' + I.plus + 'Add</button></form>';
    if (faint.length) html += '<p class="ed-rail__k">From ' + esc(X.prevRow.year) + (S.ro || faint.length < 2 ? '' : ' · <button type="button" class="wk-linklike" data-startall>Start all</button>') + '</p><ul class="ed-rail__list ed-rail__faint">' + faint.map(g => '<li><button type="button" class="ed-rail__b is-faint" data-startfrom="' + esc(g.label) + '"' + (S.ro ? ' disabled' : '') + '><span class="ed-rail__t"><b>' + esc(g.label) + '</b><small>' + plural(g.n, 'shift') + ' · Start from ' + esc(X.prevRow.year) + '</small></span></button></li>').join('') + '</ul>';
    if (here.length) html += '<p class="ed-here">Also here · ' + here.map(h => esc(h.name) + (h.group ? ' (' + esc(h.group.replace(/^@(look|none|desk)$/, m => ({ '@look': 'To look at', '@none': 'Not on any day', '@desk': 'Desk hours' })[m]).replace(/^@/, '')) + ')' : '')).join(', ') + '</p>';
    return html;
  }
  const initials = n => String(n || '?').split(/\s+/).map(w => w[0]).join('').slice(0, 2).toUpperCase();

  /* ---- the list */

  function visible() {
    const q = lc(S.q);
    let rows = F.rows.slice();
    if (q) rows = rows.filter(r => shownText(r).indexOf(q) > -1);
    else if (spec.groups) rows = rows.filter(r => spec.inGroup(r, S.group));
    const sort = spec.sort;
    const ix = new Map(F.rows.map((r, i) => [r, i]));
    rows.sort((a, b) => {
      if (q && spec.file === 'schedule') { const d = dayIx(a.day) - dayIx(b.day); if (d) return d; }
      if (q && spec.file === 'shifts') { const d = lc(a.committee) < lc(b.committee) ? -1 : lc(a.committee) > lc(b.committee) ? 1 : 0; if (d) return d; }
      if (sort) { const x = sort(a), y = sort(b); if (x < y) return -1; if (x > y) return 1; }
      return ix.get(a) - ix.get(b);
    });
    return rows;
  }
  // What a row shows (Find matches only what's on the screen).
  function shownText(r) {
    const t = spec.cells(r).join(' ').replace(/<[^>]+>/g, ' ');
    const div = document.createElement('div'); div.innerHTML = t;
    return lc(div.textContent + ' ' + (spec.file === 'schedule' || spec.file === 'shifts' ? r.day || '' : '') + ' ' + (spec.file === 'shifts' ? r.committee || '' : '') + ' ' + (r.place || ''));
  }
  // What Find matched, marked in the rows' words (text only: nobody's words become markup).
  function markFinds(el) {
    const re = findRe();
    el.querySelectorAll('.ed-table .ed-title, .ed-table .ed-note, .ed-table .ed-place, .ed-table .ed-c-time').forEach(box => {
      const walk = document.createTreeWalker(box, NodeFilter.SHOW_TEXT), nodes = [];
      while (walk.nextNode()) nodes.push(walk.currentNode);
      nodes.forEach(n => {
        const t = n.nodeValue; re.lastIndex = 0;
        if (!re.test(t)) return;
        re.lastIndex = 0;
        const frag = document.createDocumentFragment(); let at = 0, m;
        while ((m = re.exec(t)) && m[0]) { frag.appendChild(document.createTextNode(t.slice(at, m.index))); const mk = document.createElement('mark'); mk.className = 'ed-mark'; mk.textContent = m[0]; frag.appendChild(mk); at = m.index + m[0].length; }
        frag.appendChild(document.createTextNode(t.slice(at)));
        n.parentNode.replaceChild(frag, n);
      });
    });
  }
  // Rows repeated into this day from an earlier one.
  const repeats = () => spec.file === 'schedule' && !S.q && S.group && S.group[0] !== '@' ? F.rows.filter(r => r.last_day && dayIx(r.day) < dayIx(S.group) && dayIx(r.last_day) >= dayIx(S.group) && r.display !== 'desk') : [];

  function mainHtml() {
    if (S.importing) return importHtml();
    if (spec.file === 'schedule' && S.paste) return headHtml() + pasteHtml();
    if (spec.file === 'shifts' && (!S.group || S.group[0] === '@')) return shiftsBlank();
    const list = visible(), reps = repeats();
    let html = headHtml();
    if (spec.file === 'schedule' && !X.days.length) html += '<section class="ws-blank"><p class="ws-blank__h">No dates yet</p><p class="ws-blank__btn"><a class="wk-btn wk-btn--small" href="' + esc(X.yearHref('conference')) + '">Set the first day</a> <button type="button" class="wk-linklike" data-paste title="Rows with day names wait here until the first day is set">Paste rows</button></p></section>';
    if (spec.addLine && !S.q && !S.ro && S.group && S.group[0] !== '@') html += quickHtml();
    if (spec.id === 'places') html += campusHtml();
    if (S.lastImport && !S.q) html += '<p class="ed-bar2">' + esc(S.lastImport) + ' · <button type="button" class="wk-linklike" data-undoimport>Undo</button></p>';
    if (spec.file === 'schedule' && S.view === 'day' && !S.q && !isPhone() && S.group && S.group[0] !== '@') return html + dayHtml(list, reps);
    if (spec.file === 'schedule' && S.group === '@desk' && !S.q) return html + deskHtml(list);
    if (S.multi.size) html += bulkHtml();
    if (!list.length && !reps.length) return html + (S.q ? '<p class="ws-empty">No matches</p>' : spec.addLine && !S.ro ? '' : emptyHtml());
    return html + tableHtml(list, reps) + addHtml() + (S.ro ? '' : '<p class="ed-keyhint"><button type="button" class="wk-linklike" data-keys>Shortcuts</button> · Press ?</p>');
  }
  // Shifts with no committee chosen: Add committee first, or every committee from last year at once.
  function shiftsBlank() {
    const real = spec.groups().filter(g => !g.faint), from = (prev.shifts || []).length && X.prevRow ? X.prevRow.year : '';
    const g = S.group && S.group.indexOf('@from:') === 0 ? S.group.slice(6) : '';
    if (g) { const n = (prev.shifts || []).filter(r => r.committee === g).length; return '<section class="ws-blank"><p class="ws-blank__h">' + esc(g) + '</p><p class="ws-blank__p">' + plural(n, 'shift') + ' in ' + esc(from) + '</p>' + (S.ro ? '' : '<p class="ws-blank__btn"><button type="button" class="wk-btn wk-btn--small" data-startfrom="' + esc(g) + '">Start from ' + esc(from) + '</button></p>') + '</section>'; }
    if (real.length || S.ro) return '';
    return '<section class="ws-blank"><p class="ws-blank__h">No committees yet</p><p class="ws-blank__btn"><button type="button" class="wk-btn wk-btn--small" data-addcommittee>' + I.plus + 'Add committee</button>' + (from ? ' <button type="button" class="wk-linklike" data-startall>Start all from ' + esc(from) + '</button>' : '') + '</p></section>';
  }
  function headHtml() {
    const q = S.q.trim();
    if (q) { const list = visible(), gs = spec.file === 'schedule' ? uniq(list.map(r => r.day)) : spec.file === 'shifts' ? uniq(list.map(r => r.committee)) : []; return '<div class="ed-head"><h2 class="ed-h">' + plural(list.length, spec.one) + (gs.length ? ' · ' + plural(gs.length, spec.file === 'schedule' ? 'day' : 'committee') : '') + '</h2><p class="ed-headtools">' + replaceHtml(list) + '<button type="button" class="wk-linklike" data-clearfind>Clear</button></p></div>'; }
    if (spec.id === 'help' && !S.ro && aux.contacts) {
      const loose = uniq(F.rows.filter(r => digits(r.phone).length >= 10 && !numberOf(r.phone)).map(r => digits(r.phone))).length;
      return loose ? '<p class="ed-bar2">' + plural(loose, 'number') + ' only on the cards · <button type="button" class="wk-linklike" data-movenumbers>Move to Numbers</button></p>' : '';
    }
    if (!spec.groups) return spec.id === 'halls' ? hallTotals() : '';
    const g = (spec.groups().find(x => x.id === S.group) || {});
    if (spec.file === 'schedule') {
      if (!g.id) return '';
      const d = X.days[dayIx(S.group)];
      const views = !isPhone() && S.group[0] !== '@' ? '<span class="rf-seg ed-views" role="group" aria-label="View">' + [['table', 'Table'], ['day', 'Day']].map(v => '<button type="button" data-view="' + v[0] + '" aria-pressed="' + (S.view === v[0]) + '">' + (S.view === v[0] ? I.check : '') + v[1] + '</button>').join('') + '</span>' : '';
      const zoom = S.view === 'day' && views ? '<span class="ed-zoom" role="group" aria-label="Zoom"><span class="ed-zoom__l" aria-hidden="true">Zoom</span><button type="button" data-zoom="-1" aria-label="Zoom out">' + I.minus + '</button><button type="button" data-zoom="1" aria-label="Zoom in">' + I.plus + '</button></span>' : '';
      // Day view and See it take the whole width: the days are pills here instead of the rail.
      const dayPills = (S.view === 'day' && views) || X.see ? '<span class="rf-seg ed-pills ed-daypills" role="group" aria-label="Day">' + X.days.map(x => '<button type="button" data-dayview="' + esc(x.name) + '" aria-pressed="' + (x.name === S.group) + '">' + (x.name === S.group ? I.check : '') + esc(short(x.name)) + '</button>').join('') + '</span>' : '';
      // How Day view works, said once under its controls until put away (never only in a hover).
      let hint = '';
      try { hint = S.view === 'day' && views && !localStorage.getItem('ogc-ed-dayhint') ? '<p class="ed-dayhint">Drag a block to move it · Drag its bottom edge for when it ends · Double-click to add <button type="button" class="wk-linklike" data-dayhintx>Got it</button></p>' : ''; } catch (e) { /* none */ }
      return '<div class="ed-head"><h2 class="ed-h">' + esc(g.label || '') + (d ? ' <small>' + esc(O.fmtDate(d.date, 'md')) + '</small>' : '') + '</h2><p class="ed-headtools">' + dayPills + zoom + views + '</p></div>' + hint;
    }
    if (spec.file === 'shifts' && g.id && !g.faint) {
      const c = aux.committees ? aux.committees.rows.find(x => x.name === g.id) : null;
      const notify = c ? (c.heads || c.contact_email || '').split('|').filter(Boolean).join(', ') : '';
      return '<div class="ed-head"><h2 class="ed-h">' + esc(g.label) + '</h2><p class="ed-headtools">' + (S.ro ? '' : '<button type="button" class="wk-linklike" data-renamegroup>Rename</button>' + (g.n ? '' : '<button type="button" class="wk-linklike" data-removegroup>Remove</button>')) + '</p></div>' +
        '<form class="ed-notify" data-notify><label class="ed-f ed-f--inline"><span class="ed-f__l">Notify</span><input class="ed-in" data-notifyin value="' + esc(notify) + '" placeholder=" " autocomplete="off"' + (S.ro ? ' disabled' : '') + '><small class="ed-help is-on">' + (notify ? 'Told when someone leaves a shift · Never shown publicly' : 'To set · The head’s email or a role address, told when someone leaves a shift') + '</small></label></form>' + (S.renaming ? '<form class="ed-rename" data-renameform><label class="ed-f"><span class="ed-f__l">New name</span><input class="ed-in" data-renamein value="' + esc(g.label) + '" autocomplete="off"></label><p class="ed-btns"><button type="submit" class="wk-btn wk-btn--small">Rename</button><button type="button" class="wk-linklike" data-renameoff>Cancel</button></p></form>' : '');
    }
    return g.label ? '<div class="ed-head"><h2 class="ed-h">' + esc(g.label) + '</h2></div>' : '';
  }
  function emptyHtml() {
    return '<section class="ws-blank"><p class="ws-blank__h">No ' + esc(spec.one) + 's</p>' + (S.ro ? '' : '<p class="ws-blank__btn"><button type="button" class="wk-btn wk-btn--small" data-add>' + I.plus + 'Add ' + esc(spec.one) + '</button></p>') + '</section>';
  }
  const addHtml = () => S.ro || spec.addLine && !S.q ? '' : S.q || (spec.file === 'shifts' && (!S.group || S.group[0] === '@')) ? '' : '<p class="ed-add"><button type="button" class="wk-btn wk-btn--small" data-add title="N">' + I.plus + 'Add ' + esc(spec.one) + '</button></p>';

  function tableHtml(list, reps) {
    const all = list.map(r => ({ r, rep: false })).concat(reps.map(r => ({ r, rep: true })));
    if (reps.length) all.sort((a, b) => tStart(a.r) - tStart(b.r));
    // Desk rows of the day fold into one line (their own view is Desk hours).
    let desk = '';
    if (spec.file === 'schedule' && S.group && S.group[0] !== '@' && !S.q) {
      const ds = F.rows.filter(r => r.display === 'desk' && (r.day === S.group || (r.last_day && dayIx(r.day) < dayIx(S.group) && dayIx(r.last_day) >= dayIx(S.group))));
      if (ds.length) desk = '<tr class="ed-row ed-row--fold"><td colspan="' + spec.cols.length + '"><button type="button" class="wk-linklike" data-group="@desk">Desk hours · ' + esc(uniq(ds.map(r => (placeOf(r.place) || {}).name || r.title)).join(', ')) + ' · ' + plural(ds.length, 'row') + '</button></td></tr>';
    }
    const groupCol = S.q && spec.groups;
    // A column with nothing in it on any row isn't drawn (What always is).
    const txt = h => String(h || '').replace(/<[^>]*>/g, '').trim();
    S.mask = spec.cols.map((c, k) => c[1] === 'ed-c-what' || k === 0 || all.some(x => txt(spec.cells(x.r)[k])));
    spec.colsShown = S.mask.filter(Boolean).length + (groupCol ? 1 : 0);
    let body = '', lastHead = null;
    const tabbable = S.sel && all.some(x => x.r._id === S.sel) ? S.sel : (all.find(x => !x.rep) || {}).r ? all.find(x => !x.rep).r._id : '';
    all.forEach(x => {
      if (spec.head && !S.q) { const h = spec.head(x.r); if (h !== lastHead) { lastHead = h; body += hallHeadRow(h); } }
      body += x.rep ? repRow(x.r) : rowHtml(x.r, groupCol, x.r._id === tabbable);
    });
    return '<table class="ed-table" role="grid" aria-label="' + esc(spec.title) + '" aria-multiselectable="true"><thead><tr>' + (groupCol ? '<th scope="col" class="ed-c-grp">' + (spec.file === 'schedule' ? 'Day' : 'Committee') + '</th>' : '') + spec.cols.map((c, k) => S.mask[k] ? '<th scope="col" class="' + c[1] + '">' + esc(c[0]) + '</th>' : '').join('') + '</tr></thead><tbody>' + desk + body + '</tbody></table>';
  }
  function rowHtml(r, groupCol, tab) {
    const warn = issues(r).filter(i => !i.soft), cs = spec.cells(r), sel = S.sel === r._id, here = (F.here || []).find(h => h.row === r._id);
    const meta = F.meta[r._id];
    const cls = 'ed-row' + (sel ? ' is-sel' : '') + (S.multi.has(r._id) ? ' is-multi' : '') + (r._look ? ' is-check' : '') + (S.flash.has(r._id) ? ' is-flash' : '') + (here ? ' is-here' : '') + (spec.rowCls ? ' ' + spec.rowCls(r) : '');
    const name = spec.label(r) + (spec.sub ? ', ' + spec.sub(r) : '');
    return '<tr class="' + cls + '" data-id="' + esc(r._id) + '" tabindex="' + (sel || tab ? '0' : '-1') + '" aria-selected="' + (sel || S.multi.has(r._id)) + '" aria-label="' + esc(name) + '"' + (S.ro ? '' : ' draggable="true"') + (here ? ' title="' + esc(here.name + ' is on this row') + '"' : '') + '>' +
      (groupCol ? '<td class="ed-c-grp">' + esc(spec.file === 'schedule' ? short(r.day) : r.committee || '') + '</td>' : '') +
      cs.map((c, k) => S.mask && !S.mask[k] ? '' : '<td class="' + spec.cols[k][1] + '">' + (k === 0 && !S.ro ? '<span class="ed-grip" aria-hidden="true">' + I.grip + '</span>' : '') + c +
        (k === (spec.cols.findIndex(x => x[1] === 'ed-c-what') > -1 ? spec.cols.findIndex(x => x[1] === 'ed-c-what') : 0) && warn.length ? '<small class="ed-warnline">' + I.warn + '<span class="ogc-sr">Warning: </span>' + esc(warn.map(w => w.text).join(' · ')) + '</small>' : '') + '</td>').join('') + '</tr>';
  }
  function repRow(r) {
    const cs = spec.cells(r);
    return '<tr class="ed-row is-repeat" data-goto="' + esc(r._id) + '" tabindex="-1" aria-label="' + esc(spec.label(r) + ', every day from ' + r.day) + '">' + cs.map((c, k) => S.mask && !S.mask[k] ? '' : '<td class="' + spec.cols[k][1] + '">' + c + (k === 1 ? '<small class="ed-sub">Every day from ' + esc(short(r.day)) + ' · <button type="button" class="wk-linklike" data-split="' + esc(r._id) + '">Change this day only</button></small>' : '') + '</td>').join('') + '</tr>';
  }
  function hallHeadRow(h) {
    const rows = F.rows.filter(r => (r.hall || 'New hall') === h), rooms = rows.reduce((n, r) => n + roomsOf(r), 0), beds = rows.reduce((n, r) => n + roomsOf(r) * (+r.beds || 0), 0);
    const fors = uniq(rows.map(r => forLabel(r.for)));
    // A hall whose plan isn't the university's (or checked) is a sample: said, never shown as real.
    const pl = (aux.plans || []).find(p => lc(p.hall) === lc(h)), sample = !pl || !/^(university|checked)$/.test(pl.status || 'sample');
    return '<tr class="ed-grouprow"><th colspan="' + spec.colsShown + '" scope="rowgroup">' + esc(h) + (sample ? ' <span class="ed-tag ed-tag--sample" title="Sample rooms and floors until Lodging has the university’s plans">Sample</span>' : '') + ' <small>' + [plural(rows.length, 'floor'), plural(rooms, 'room'), plural(beds, 'bed'), fors.join(', ')].join(' · ') + '</small></th></tr>';
  }
  function hallTotals() {
    const by = {};
    F.rows.forEach(r => { const f = forLabel(r.for); by[f] = (by[f] || 0) + roomsOf(r) * (+r.beds || 0); });
    const keys = Object.keys(by);
    return keys.length ? '<p class="ed-totals">' + keys.map(k => '<span><b>' + by[k] + '</b> beds · ' + esc(k) + '</span>').join('') + '<datalist id="ed-halls">' + uniq(F.rows.map(r => r.hall)).map(h => '<option value="' + esc(h) + '">').join('') + '</datalist></p>' : '';
  }

  /* ---- Desk hours: each desk once, its week as a grid (a row for Open, On call…, a column a day) */

  function deskHtml(list) {
    const deskOf = r => (placeOf(r.place) || {}).name || r.place || 'Desk';
    const desks = uniq(list.map(deskOf));
    const on = (r, d) => dayIx(r.day) <= d && dayIx(r.last_day || r.day) >= d;
    if (!desks.length) return emptyHtml();
    return desks.map(name => {
      const rows = list.filter(r => deskOf(r) === name), kinds = uniq(rows.map(r => r.title || 'Open'));
      return '<section class="ed-desk"><h3 class="ed-desk__h">' + esc(name) + '</h3><div class="ed-desk__scroll"><table class="ed-table ed-desk__t"><thead><tr><th scope="col"><span class="ogc-sr">Hours</span></th>' + X.days.map(d => '<th scope="col">' + esc(short(d.name)) + '</th>').join('') + '</tr></thead><tbody>' +
        kinds.map(k => '<tr><th scope="row">' + esc(k) + '</th>' + X.days.map((d, i) => {
          const here = rows.filter(r => (r.title || 'Open') === k && on(r, i));
          return '<td>' + here.map(r => '<button type="button" class="ed-deskcell' + (r._id === S.sel ? ' is-sel' : '') + '" data-id="' + esc(r._id) + '">' + esc(nb(timeText(r))) + (r.last_day ? '<small>' + esc(short(r.day) + '–' + short(r.last_day)) + '</small>' : '') + '</button>').join('') +
            (S.ro || here.length ? '' : '<button type="button" class="ed-deskadd" data-deskadd="' + esc(i) + '" data-desk="' + esc(rows[0].place || '') + '" data-kind="' + esc(k) + '" aria-label="Add ' + esc(k + ' hours on ' + d.name) + '">' + I.plus + '</button>') + '</td>';
        }).join('') + '</tr>').join('') + '</tbody></table></div></section>';
    }).join('');
  }

  /* ---- the Add line (the schedule): a line read as it's written */

  function quickHtml() {
    return '<form class="ed-quick" data-quick autocomplete="off"><label class="ed-f ed-quick__f"><span class="ed-f__l">Add a row to ' + esc(S.group) + '</span>' +
      '<span class="ed-quick__row"><input class="ed-in" data-quickin data-fk="quick" placeholder=" " spellcheck="false" aria-describedby="ed-quick-help"><button type="submit" class="wk-btn wk-btn--small">' + I.plus + 'Add</button></span>' +
      '<small class="ed-help is-on" id="ed-quick-help">Like 10–11:30 Worship, Chapel · Then Enter</small></label>' +
      '<div class="ed-chips ed-quick__echo" data-quickecho aria-live="polite"></div>' +
      '<p class="ed-quick__links"><button type="button" class="wk-linklike" data-paste>Paste rows</button></p></form>';
  }
  // What a typed line was read as, part by part; a guessed half of the day can be switched with a tap,
  // and a place nobody has is said so, with what to do about it.
  function quickEcho(text) {
    if (!text.trim()) return '';
    const res = R.line(text, readCtx(S.group)), r = res.row;
    if (S.flipQuick && r.start && R.minutes(r.start) != null) { r.start = R.store(R.minutes(r.start) + 720); if (R.minutes(r.end) != null) r.end = R.store(R.minutes(r.end) + 720); }
    const chips = [];
    if (res.moved) chips.push(['Day', r.day]);
    const allDay = /\ball day\b/i.test(text);
    if (r.start || allDay) chips.push(['When', r.start ? timeText(r) : 'All day', !!res.guess && !S.flipQuick]);
    else chips.push(['When', 'No time · Add one', false, true]);
    chips.push(['What', r.title || 'What is it?', !r.title]);
    if (r.place) chips.push(['Where', (placeOf(r.place) || {}).name || r.place]);
    if (lc(r.audience) !== 'conference') chips.push(['For', audLabel(r.audience)]);
    if (r.note && r.note !== res.unknown) chips.push(['Note', r.note.replace(res.unknown + ' · ', '')]);
    return chips.map(c => '<span class="ed-chip' + (c[2] ? ' is-guess' : '') + (c[3] ? ' is-warn' : '') + '"><b>' + esc(c[0]) + '</b> ' + esc(c[1]) + '</span>').join('') +
      (res.guess && r.start ? '<button type="button" class="ed-chip ed-chip--btn" data-flipquick>' + (R.minutes(r.start) < 720 ? 'PM instead' : 'AM instead') + '</button>' : '') +
      (res.unknown ? '<span class="ed-chip is-warn"><b>' + esc(res.unknown) + '</b> Not a place</span><button type="button" class="ed-chip ed-chip--btn" data-addplace="' + esc(res.unknown) + '">Add place</button><span class="ed-chip ed-chip--q">Or kept as a note</span>' : '');
  }

  /* ---- Paste rows: what each line was read as, before anything is added */

  function pasteHtml() {
    const res = S.pasteRes || { rows: [], unread: [] };
    const cmp = res.rows.length ? ED.files.compare(res.rows.map(x => x.row), F.rows, { key: SPECS.schedule.key, name: SPECS.schedule.name, scope: SPECS.schedule.scope, fields: SPECS.schedule.compareFields }) : null;
    const days = uniq(res.rows.map(x => x.row.day)), counts = days.map(d => [d, F.rows.filter(r => r.day === d).length]);
    const fresh = cmp ? cmp.added.length + cmp.changed.length : 0;
    // Replace removes the rows on the pasted days that aren't in the paste: said as a number.
    const keepIds = cmp ? new Set(cmp.same.map(r => r._id).concat(cmp.changed.map(c => c.row._id))) : new Set();
    const gone = days.length ? F.rows.filter(r => days.indexOf(r.day) > -1 && !keepIds.has(r._id)).length : 0;
    const preview = res.rows.length ? '<table class="ed-table ed-table--pv"><thead><tr><th>Day</th><th>When</th><th>What</th><th>Where</th><th>For</th><th>Note</th><th></th></tr></thead><tbody>' + res.rows.map((x, i) => {
      const ch = cmp.changed.find(c => c.now === x.row);
      const word = (row, f) => f === 'start' || f === 'end' ? timeText(row) : f === 'place' ? ((placeOf(row.place) || {}).name || row.place || 'blank') : f === 'audience' ? audLabel(row.audience) : val(row, f) || 'blank';
      const r = x.row, st = cmp.same.some(s => SPECS.schedule.key(s) === SPECS.schedule.key(r)) ? 'Same' : ch ? uniq(ch.fields.map(f => f === 'end' ? 'start' : f)).map(f => (WORDS[f] === 'Starts' ? 'When' : WORDS[f] || f) + ': ' + word(ch.row, f) + ' → ' + word(ch.now, f)).join(' · ') : cmp.dupes.indexOf(r) > -1 ? 'Twice · First kept' : 'New';
      return '<tr class="' + (st ? 'is-same' : '') + '"><td>' + esc(short(r.day)) + '</td><td>' + (x.guess ? '<button type="button" class="ed-guess" data-pasteflip="' + i + '" title="Guessed · Tap for the other half of the day">' + esc(timeText(r)) + '</button>' : esc(timeText(r))) + '</td><td>' + esc(r.title) + '</td><td>' + (r.place ? (placeOf(r.place) ? esc(placeOf(r.place).name) : '<span class="ed-guess is-warn" title="Not a place here">' + esc(r.place) + '</span>') : '') + '</td><td>' + esc(lc(r.audience) === 'conference' ? '' : audLabel(r.audience)) + '</td><td>' + esc(r.note || '') + '</td><td class="ed-dim">' + esc(st) + '</td></tr>';
    }).join('') + '</tbody></table>' : '';
    return '<form class="ed-paste" data-pasteform><label class="ed-f"><span class="ed-f__l">Paste rows</span><textarea class="ed-in" data-pastein data-fk="paste" rows="7" placeholder=" " spellcheck="false">' + esc(S.pasteText || '') + '</textarea>' +
      '<small class="ed-help is-on">One a line, like 10–11:30 Worship, Chapel · A day’s name starts its rows · Or a spreadsheet’s rows with their header</small></label>' +
      (res.rows.length ? '<p class="ed-sum">' + plural(res.rows.length, 'row') + ' read' + (cmp && cmp.same.length ? ' · ' + cmp.same.length + ' already there' : '') + (res.rows.some(x => x.guess) ? ' · <span class="ed-guess">Dotted</span> = guessed' : '') + '</p>' + preview : '') +
      // Lines not read: each fixed where it is, read again as it's typed.
      (res.unread.length ? '<div class="ed-unread"><p><b>' + plural(res.unread.length, 'line') + ' not read</b> · Fix them here</p><ul>' + res.unread.slice(0, 20).map((l, i) => '<li><input class="ed-in" data-unread="' + (res.unreadAt ? res.unreadAt[i] : i) + '" value="' + esc(l) + '" spellcheck="false" aria-label="Line not read"><span class="ed-chips">' + unreadEcho(l) + '</span></li>').join('') + '</ul></div>' : '') +
      '<p class="ed-btns"><button type="submit" class="wk-btn wk-btn--small" value="add"' + (fresh ? '' : ' disabled') + '>' + I.plus + (fresh ? 'Add ' + plural(cmp.added.length, 'row') + (cmp.changed.length ? ' · update ' + cmp.changed.length : '') : 'Add rows') + '</button>' +
      (gone ? '<button type="submit" class="wk-linklike ed-danger" value="replace" title="Rows on ' + esc(days.join(', ')) + ' not in what’s pasted are removed">' + (S.replaceArmed ? 'Remove ' + plural(gone, 'row') + ' and replace · Yes' : 'Replace · removes ' + plural(gone, 'row')) + '</button>' : '') +
      '<button type="button" class="wk-linklike" data-pasteoff>Cancel</button></p></form>';
  }

  function unreadEcho(l) {
    const r = R.line(l, readCtx(S.group)).row;
    return (r.start ? '<span class="ed-chip"><b>When</b> ' + esc(timeText(r)) + '</span>' : '<span class="ed-chip is-warn"><b>When</b> No time</span>') + (r.title ? '<span class="ed-chip"><b>What</b> ' + esc(r.title) + '</span>' : '<span class="ed-chip is-warn"><b>What</b> What is it?</span>');
  }

  /* ---- Import: a review of every change before it happens */

  function importHtml() {
    const im = S.importing, c = im.cmp;
    const n = c.changed.length + c.added.length + c.removed.length;
    const line = (r, html, k, checked, cls) => '<li class="' + (cls || '') + '"><label><input type="checkbox" data-imp="' + k + '"' + (checked ? ' checked' : '') + '> <span>' + html + '</span></label></li>';
    const name = r => esc(spec.label(r)) + (spec.sub ? ' <small>' + esc(spec.sub(r)) + '</small>' : '');
    return '<section class="ed-import"><div class="ed-head"><h2 class="ed-h">From ' + esc(im.file) + '</h2></div>' +
      '<p class="ed-sum">' + [c.changed.length ? c.changed.length + ' changed' : '', c.added.length ? c.added.length + ' added' : '', c.removed.length ? c.removed.length + ' removed' : '', c.same.length ? c.same.length + ' the same' : '', c.dupes.length ? c.dupes.length + ' twice in the file' : ''].filter(Boolean).join(' · ') + (im.other ? ' · <b>From ' + esc(im.other) + '</b> · Days match by name' : '') + '</p>' +
      (im.unread && im.unread.length ? '<div class="ed-unread"><p><b>' + plural(im.unread.length, 'line') + ' not read</b></p><ul>' + im.unread.slice(0, 8).map(l => '<li>' + esc(l) + '</li>').join('') + '</ul></div>' : '') +
      (c.changed.length ? '<h3 class="ed-h3">Changed</h3><ul class="ed-implist">' + c.changed.map((x, i) => line(x.row, name(x.row) + '<span class="ed-diff">' + x.fields.map(f => esc(WORDS[f] || f) + ' <s>' + esc(val(x.row, f)) + '</s> <ins>' + esc(val(x.now, f)) + '</ins>').join(' · ') + '</span>', 'c' + i, true)).join('') + '</ul>' : '') +
      (c.dupes.length ? '<h3 class="ed-h3">Twice in the file</h3><p class="ed-hint">The first is kept</p><ul class="ed-implist ed-implist--plain">' + c.dupes.map(r => '<li>' + name(r) + '</li>').join('') + '</ul>' : '') +
      (c.added.length ? '<h3 class="ed-h3">Added</h3><ul class="ed-implist">' + c.added.map((r, i) => line(r, name(r), 'a' + i, true, 'is-added')).join('') + '</ul>' : '') +
      (c.removed.length ? '<h3 class="ed-h3">Removed</h3><p class="ed-hint">Not in the file · ' + (spec.file === 'schedule' ? 'only on the days the file has' : spec.file === 'shifts' ? 'only in the committees the file has' : 'in the whole list') + '</p><ul class="ed-implist">' + c.removed.map((x, i) => line(x.row, '<s>' + name(x.row) + '</s>' + (x.people ? ' <span class="ed-flag">' + I.warn + plural(x.people, 'person') + ' signed up</span>' : ''), 'r' + i, false, 'is-removed')).join('') + '</ul>' : '') +
      '<p class="ed-btns"><button type="button" class="wk-btn wk-btn--small" data-impapply' + (n ? '' : ' disabled') + '>Apply</button><button type="button" class="wk-linklike" data-impcancel>Cancel</button></p></section>';
  }

  /* ---- several rows at once */

  function bulkHtml() {
    const n = S.multi.size;
    const days = spec.file === 'schedule' ? '<span class="ed-bulk__g"><span>Move to</span>' + X.days.map(d => '<button type="button" class="ed-mini" data-bulkmove="' + esc(d.name) + '">' + esc(short(d.name)) + '</button>').join('') + '</span><span class="ed-bulk__g"><span>Copy to</span>' + X.days.map(d => '<button type="button" class="ed-mini" data-bulkcopy="' + esc(d.name) + '">' + esc(short(d.name)) + '</button>').join('') + '</span>' +
      '<span class="ed-bulk__g"><span>For</span>' + AUD.map(a => '<button type="button" class="ed-mini" data-bulkfor="' + esc(a[0]) + '">' + esc(a[1]) + '</button>').join('') + '</span><span class="ed-bulk__g"><span>Call-in</span><button type="button" class="ed-mini" data-bulkcall="yes">On</button><button type="button" class="ed-mini" data-bulkcall="">Off</button></span>' : '';
    return '<div class="ed-bulk" role="toolbar" aria-label="' + plural(n, 'row') + ' chosen"><b>' + plural(n, spec.one) + '</b>' + days + '<button type="button" class="wk-linklike ed-danger" data-bulkremove>Remove</button><button type="button" class="wk-linklike" data-bulkoff>Done</button></div>';
  }

  /* ---- Find and Replace */

  function replaceHtml(list) {
    if (S.ro || !list.length || !(spec.file === 'schedule' || spec.file === 'shifts')) return '';
    if (!S.replacing) return '<button type="button" class="wk-linklike" data-replaceon>Replace</button>';
    return '<span class="ed-replace"><label><span class="ogc-sr">Replace with</span><input class="ed-in" data-replacein value="' + esc(S.replaceWith || '') + '" placeholder="Replace with" autocomplete="off"></label><button type="button" class="wk-linklike" data-replacego>Replace in ' + plural(list.filter(r => replaced(r)).length, spec.one) + '</button></span>';
  }
  const findRe = () => new RegExp(S.q.trim().replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'gi');
  function replaced(r) {
    const out = {};
    ['title', 'role', 'note'].forEach(k => { if (r[k] && findRe().test(r[k])) out[k] = r[k].replace(findRe(), S.replaceWith || ''); });
    return Object.keys(out).length ? out : null;
  }

  /* ---- Buildings and rooms at a new campus: each old code matched to a place here */

  function campusHtml() {
    const used = {};
    (aux.schedule ? aux.schedule.rows : []).concat(aux.shifts ? aux.shifts.rows : []).forEach(r => { [r.place].concat(String(r.also || '').split('|')).filter(Boolean).forEach(c => { if (!placeOf(c)) used[c.toUpperCase()] = (used[c.toUpperCase()] || 0) + 1; }); });
    const codes = Object.keys(used);
    if (!codes.length || S.ro) return '';
    S.map = S.map || {};
    return '<section class="ed-campus"><h2 class="ed-h">Places to choose</h2><p class="ed-hint">' + plural(codes.length, 'code') + ' the schedule and shifts use aren’t here' + (X.campusChanged ? ' · From ' + esc(X.prevRow.venue) : '') + '</p><ul class="ed-maplist">' +
      codes.map(c => '<li><span class="ed-code">' + esc(c) + '</span><small>' + plural(used[c], 'row') + '</small><span>' + I.go + '</span>' + placeField('map_' + c, { ['map_' + c]: S.map[c] || '' }, 'Becomes') + '</li>').join('') +
      '</ul><p class="ed-btns"><button type="button" class="wk-btn wk-btn--small" data-applymap' + (Object.keys(S.map).length ? '' : ' disabled') + '>Apply</button></p></section>';
  }

  /* ---- the schedule's Day view: the day as a timeline, a column for each audience (the editor's only) */

  const LANES = [['All', 'Everyone'], ['Conference', 'Conference'], ['Preteens', 'Preteens'], ['Youngfolks', 'Youngfolks']];
  const laneOf = r => { const k = LANES.findIndex(l => lc(l[0]) === lc(r.audience || 'Conference')); return k < 0 ? 1 : k; };
  // A block's height: its time, or more when its words need more room (measured once drawn, again
  // whenever the day's width changes: no text is ever cut off or split mid-word, Michael's rule). Blocks
  // sit side by side only when their real times overlap; a short block that needs more room than its
  // time borrows it, and the block under it moves down a little (its own time is always written in it).
  const NEED = {}, TIGHT = {};
  const tspan = r => { const a = R.minutes(r.start); if (a == null) return null; let b = R.minutes(r.end); if (b != null && b <= a) b += 1440; const open = b == null; b = open ? a + 60 : Math.max(b, a + 10); return { a, b, open }; };
  function measureDay(again) {
    if (!S.px) return;
    let grew = false;
    root.querySelectorAll('.tl-ev[data-ev], .tl-ev[data-goto]').forEach(el => {
      const id = el.dataset.ev || el.dataset.goto;
      if (el.scrollHeight > el.clientHeight + 1) { NEED[id] = Math.max(NEED[id] || 0, el.scrollHeight + 4); grew = true; }
      // A word wider than its block: the words get a little smaller (never split).
      if (el.scrollWidth > el.clientWidth + 1 && (TIGHT[id] || 0) < 2) { TIGHT[id] = (TIGHT[id] || 0) + 1; grew = true; }
    });
    if (grew && (again || 0) < 4) { const el = root.querySelector('[data-main]'); if (el) { el.innerHTML = mainHtml(); measureDay((again || 0) + 1); } }
  }
  // The day's width changed (the details opened or closed, See it, the window): measure again.
  let dayW = 0;
  const dayRO = typeof ResizeObserver === 'function' ? new ResizeObserver(es => {
    const w = Math.round(es[0].contentRect.width);
    if (!S || S.view !== 'day' || !w || !dayW || Math.abs(w - dayW) < 2) { dayW = w || dayW; return; }
    dayW = w;
    requestAnimationFrame(() => {
      if (!root.querySelector('.tl')) return;
      Object.keys(NEED).forEach(k => { delete NEED[k]; }); Object.keys(TIGHT).forEach(k => { delete TIGHT[k]; });
      const a = document.activeElement, ev = a && a.dataset ? a.dataset.ev : '';
      const el = root.querySelector('[data-main]'); el.innerHTML = mainHtml(); measureDay();
      if (ev) { const b = root.querySelector('.tl-ev[data-ev="' + CSS.escape(ev) + '"]'); if (b) b.focus({ preventScroll: true }); }
    });
  }) : null;
  const LONG = 210;
  const GENERIC = /^(open|on call|closed|desk)$/i;
  function dayHtml(list, reps) {
    const timed = list.filter(r => tspan(r) && r.display !== 'desk'), loose = list.filter(r => !tspan(r));
    const all = timed.map(r => ({ r, rep: false })).concat(reps.filter(r => tspan(r)).map(r => ({ r, rep: true })));
    const lo = all.length ? Math.min(...all.map(e => tspan(e.r).a)) : 7 * 60, hi = Math.max(lo + 4 * 60, ...all.map(e => tspan(e.r).b));
    const h0 = Math.floor(lo / 60);
    let h1 = Math.min(28, Math.ceil(hi / 60));
    // The whole day fits the window, unless that's too small to read (then it scrolls).
    const avail = Math.max(420, window.innerHeight - 260);
    const PX = Math.max(1.1, Math.min(2.4, avail / ((h1 - h0) * 60))) * S.zoom;
    S.px = PX; S.dayStart = h0 * 60;
    const placed = [], runs = LANES.map(() => []);
    LANES.forEach((l, li) => {
      const mine = all.filter(e => laneOf(e.r) === li).map(e => Object.assign({ s: tspan(e.r) }, e));
      mine.filter(e => e.s.b - e.s.a >= LONG).sort((p, q) => p.s.a - q.s.a).forEach((e, k) => { e.lane = li; e.k = k; runs[li].push(e); });
      const evs = mine.filter(e => e.s.b - e.s.a < LONG).sort((p, q) => p.s.a - q.s.a || q.s.b - p.s.b);
      let cluster = [], end = -1;
      const flush = () => {
        const cols = [];
        cluster.forEach(e => { let c = cols.findIndex(t => t <= e.s.a); if (c < 0) { c = cols.length; cols.push(0); } cols[c] = e.s.b; e.col = c; });
        cluster.forEach(e => { let to = cols.length; cluster.forEach(o => { if (o !== e && o.col > e.col && o.s.a < e.s.b && e.s.a < o.s.b) to = Math.min(to, o.col); }); e.cols = cols.length; e.span = to - e.col; e.lane = li; placed.push(e); });
        cluster = [];
      };
      evs.forEach(e => { if (cluster.length && e.s.a >= end) flush(); cluster.push(e); end = Math.max(end, e.s.b); });
      if (cluster.length) flush();
    });
    // Where each block is drawn: at its time, taller when its words need it, below a block above it.
    let bottom = 0;
    LANES.forEach((l, li) => {
      const boxes = [];
      placed.filter(e => e.lane === li).sort((p, q) => p.s.a - q.s.a).forEach(e => {
        e.x0 = e.col / e.cols; e.x1 = (e.col + e.span) / e.cols;
        let top = (e.s.a - S.dayStart) * PX;
        const h = Math.max(30, (e.s.b - e.s.a) * PX - 2, NEED[e.r._id] || 0);
        let moved = true;
        while (moved) { moved = false; boxes.forEach(b => { if (b.x0 < e.x1 - 1e-6 && e.x0 < b.x1 - 1e-6 && b.top <= top + .5 && b.bottom + 2 > top) { top = b.bottom + 2; moved = true; } }); }
        e.top = top; e.h = h; boxes.push({ x0: e.x0, x1: e.x1, top, bottom: top + h });
        bottom = Math.max(bottom, top + h);
      });
    });
    while ((h1 - h0) * 60 * PX < bottom + 4 && h1 < 30) h1++;
    const hours = []; for (let h = h0; h <= h1; h++) hours.push(h);
    const named = r => GENERIC.test(r.title || '') && r.place ? r.title + ' · ' + ((placeOf(r.place) || {}).name || r.place) : r.title || 'New row';
    const block = e => {
      const r = e.r, top = e.top, ht = e.h, inset = runs[e.lane].length * 8;
      const w = 100 / e.cols, warn = !e.rep && issues(r).some(i => !i.soft);
      return '<div class="tl-ev tl-lane' + e.lane + (e.rep ? ' is-repeat' : '') + (r._id === S.sel && !e.rep ? ' is-sel' : '') + (r._look ? ' is-check' : '') + (ht < 44 ? ' is-short' : '') + (TIGHT[r._id] ? ' is-tight' + TIGHT[r._id] : '') + '" style="top:' + top + 'px;height:' + ht + 'px;left:calc(' + inset + 'px + (100% - ' + inset + 'px) * ' + (e.col * w / 100) + ' + 2px);width:calc((100% - ' + inset + 'px) * ' + (e.span * w / 100) + ' - 4px)"' +
        (e.rep ? ' data-goto="' + esc(r._id) + '" title="Every day from ' + esc(r.day) + '"' : ' data-ev="' + esc(r._id) + '" tabindex="0" role="button" aria-label="' + esc(timeText(r) + ', ' + named(r)) + '"') + '>' +
        '<span class="tl-t">' + (warn ? I.warn : '') + esc(timeText(r)) + (r._look ? ' · To check' : '') + '</span><b>' + esc(named(r)) + '</b>' + (e.rep ? '<small>Every day from ' + esc(short(r.day)) + '</small>' : '') + (e.rep || S.ro ? '' : '<span class="tl-resize" aria-hidden="true"></span>') + '</div>';
    };
    const chip = e => '<button type="button" class="tl-runchip tl-lane' + e.lane + (e.r._id === S.sel ? ' is-sel' : '') + '" ' + (e.rep ? 'data-goto' : 'data-ev') + '="' + esc(e.r._id) + '"><b>' + esc(named(e.r)) + '</b><small>' + esc(timeText(e.r)) + '</small></button>';
    const bar = e => '<button type="button" class="tl-run tl-lane' + e.lane + '" ' + (e.rep ? 'data-goto' : 'data-ev') + '="' + esc(e.r._id) + '" style="top:' + ((e.s.a - S.dayStart) * PX) + 'px;height:' + ((e.s.b - e.s.a) * PX - 2) + 'px;left:' + (e.k * 8 + 1) + 'px" aria-label="' + esc(timeText(e.r) + ', ' + named(e.r)) + '"></button>';
    const label = h => R.fmt((h % 24) * 60);
    return (loose.length ? '<div class="tl-loose"><span class="tl-loose__k">No set time</span>' + loose.map(r => '<button type="button" class="tl-chip' + (r._id === S.sel ? ' is-sel' : '') + '" data-ev="' + esc(r._id) + '">' + esc((r.start || 'All day') + ' · ' + (r.title || 'New row')) + '</button>').join('') + '</div>' : '') +
      '<div class="tl"><div class="tl-head"><span></span>' + LANES.map(l => '<span>' + esc(l[1]) + '</span>').join('') + '</div>' +
      (runs.some(x => x.length) ? '<div class="tl-runs"><span class="tl-runs__k">Running</span>' + runs.map(rs => '<div>' + rs.map(chip).join('') + '</div>').join('') + '</div>' : '') +
      '<div class="tl-grid" style="height:' + ((h1 - h0) * 60 * PX) + 'px">' +
        '<div class="tl-hours">' + hours.map(h => '<span style="top:' + ((h - h0) * 60 * PX) + 'px">' + label(h) + '</span>').join('') + '</div>' +
        LANES.map((l, li) => '<div class="tl-col" data-lane="' + li + '">' + runs[li].map(bar).join('') + placed.filter(e => e.lane === li).map(block).join('') + '</div>').join('') +
      '</div></div>';
  }

  /* ---- the chosen row's details */

  function paintInsp() {
    const el = root.querySelector('[data-insp]');
    if (!el) return;
    const r = S.sel ? F.get(S.sel) : null;
    S.row = r;
    el.hidden = !r;
    document.documentElement.classList.toggle('ed-insp-open', !!r && isNarrow());
    if (!r) { el.innerHTML = ''; return; }
    const warn = issues(r);
    const main = spec.fields(), more = spec.more ? spec.more() : [];
    const conf = Object.keys(F.held[r._id] || {}).map(field => Object.assign({ id: r._id, field }, F.held[r._id][field]));
    const meta = F.meta[r._id];
    const look = r._look ? lookHtml(r) : '';
    const scope = S.scopeFor === r._id ? '' : '';
    const foot = meta ? '<p class="ed-meta">' + (meta.me ? 'Changed by you' : 'Changed by ' + esc(meta.by)) + ' · ' + esc(whenAgo(meta.at)) + ' · <button type="button" class="wk-linklike" data-history>History</button></p>' : r._look || (!/^n/.test(r._id) && lastYearOf(r)) ? '<p class="ed-meta">From ' + esc(X.prevRow ? X.prevRow.year : 'last year') + ' · <button type="button" class="wk-linklike" data-history>History</button></p>' : '';
    const fieldsHtml = main.map(f => fieldWrap(f, r, warn, conf)).join('');
    const moreHtml = more.length ? '<div class="ed-more' + (S.more ? ' is-open' : '') + '"><button type="button" class="ed-more__b" data-more aria-expanded="' + !!S.more + '">' + I.down + '<span>More</span><small>' + esc(spec.moreSummary ? spec.moreSummary(r) : '') + '</small></button>' + (S.more ? more.map(f => fieldWrap(f, r, warn, conf)).join('') : '') + '</div>' : '';
    const people = signedUp(r);
    const removeWord = spec.file === 'schedule' && X.publicState(spec.part, spec.gate).cls === 'is-live' ? 'Cancel' : 'Remove';
    const post = spec.file === 'notices' && r.draft && !S.ro ? '<button type="button" class="wk-btn wk-btn--small" data-post' + (r.text && r.text.trim() ? '' : ' disabled') + '>' + (S.postArmed === r._id ? 'Post anyway' : 'Post') + '</button>' : '';
    const btns = S.ro ? '' : post ? '<p class="ed-insp__btns">' + post + '<button type="button" class="ed-remove" data-remove>Remove</button></p>' : '<p class="ed-insp__btns"><button type="button" class="wk-btn wk-btn--line wk-btn--small" data-dup title="⌘D">' + I.copy + 'Duplicate</button><button type="button" class="ed-remove" data-remove title="Delete' + (removeWord === 'Cancel' ? ' · Shows as Cancelled on the page' : '') + '">' + removeWord + (people ? ' · ' + plural(people, spec.file === 'shifts' ? 'person' : 'team') : '') + '</button></p>';
    const general = warn.filter(w => !main.concat(more).some(f => f[1] === w.k || (f[1] === 'start' && w.k === 'start')));
    el.innerHTML = '<div class="ed-insp__in"><header class="ed-insp__top"><button type="button" class="ed-insp__back" data-close aria-label="' + (isNarrow() ? 'Back to ' + esc(backWord()) : 'Close') + '" title="Esc">' + (isNarrow() ? I.back + '<span>' + esc(backWord()) + '</span>' : I.close) + '</button><h2 id="ed-insp-h" tabindex="-1">' + esc(spec.label(r)) + '</h2>' + (spec.sub ? '<p class="ed-insp__sub">' + esc(spec.sub(r)) + '</p>' : '') + '</header>' +
      look + (general.length ? '<ul class="ed-flags">' + general.map(w => '<li class="' + (w.soft ? 'is-soft' : '') + '">' + I.warn + esc(w.text) + (w.dup ? ' · <button type="button" class="wk-linklike" data-merge>Merge</button>' : '') + '</li>').join('') + '</ul>' : '') +
      (S.ro ? '<dl class="ed-ro">' + main.map(f => field(f, r)).join('') + '</dl>' : fieldsHtml + moreHtml) + foot + btns + (S.hist ? histHtml() : '') + '</div>';
    growAll();
  }
  // A field with its own flags and conflicts beside it.
  // Where a phone's details go back to: the day or committee, else the list.
  const backWord = () => S.group && S.group[0] !== '@' ? (spec.file === 'schedule' ? short(S.group) : S.group) : spec.title;
  // A field someone else changed first keeps this person's text, marked, with the choice under it.
  function fieldWrap(f, r, warn, conf) {
    const k = f[1], mine = warn.filter(w => w.k === k || (k === 'start' && w.k === 'start') || (k === 'day' && w.k === 'day')), cf = conf.filter(c => c.field === k || (k === 'start' && /^(start|end|sort_time)$/.test(c.field)) || (k === 'place' && c.field === 'place'));
    const theirs = c => { const sr = F.serverRow(r._id) || {}; if (k === 'start' && f[0] === 'when') return timeText(sr) === 'All day' ? 'blank' : timeText(sr); if (f[0] === 'place') { const p = placeOf(sr[c.field]); return p ? p.name : sr[c.field] || 'blank'; } return val(sr, c.field) || 'blank'; };
    const note = cf.length ? '<p class="ed-conflict" role="alert">' + I.warn + '<span><b>' + esc(cf[0].by || 'Someone') + ' changed this just now:</b> “' + esc(theirs(cf[0])) + '”</span> <span class="ed-conflict__a"><button type="button" class="wk-linklike" data-keeptheirs="' + esc(cf.map(c => c.field).join('|')) + '">Use theirs</button><button type="button" class="wk-linklike" data-keepmine="' + esc(cf.map(c => c.field).join('|')) + '">Keep mine</button></span></p>' : '';
    return '<div class="ed-fw' + (cf.length ? ' is-conflict' : '') + '" data-fw="' + esc(k) + '">' + field(f, r) +
      (mine.length && !S.ro ? '<ul class="ed-flags">' + mine.map(w => '<li class="' + (w.soft ? 'is-soft' : '') + '">' + I.warn + esc(w.text) + (w.dup ? ' · <button type="button" class="wk-linklike" data-merge>Merge</button>' : '') + '</li>').join('') + '</ul>' : '') + note + '</div>';
  }
  // A row carried from last year that varies: what's different from last year, marked; when nothing
  // is, it says so. Why it's asked is said in words (not in a hover). Keep is quiet: the view's one
  // filled action stays Add.
  function lookHtml(r) {
    const was = lastYearOf(r), py = X.prevRow ? X.prevRow.year : 'last year';
    const ws = was ? [short(was.day), timeText(was), (placeOf(was.place) || {}).name || was.place || ''] : null, ns = [short(r.day), timeText(r), (placeOf(r.place) || {}).name || r.place || ''];
    const same = ws && ws.every((x, i) => x === ns[i]);
    const cell = (a, b) => '<span class="' + (a !== b ? 'is-diff' : '') + '">' + esc(b || '·') + '</span>';
    const body = !ws ? '<p class="ed-look__l">New this year</p>' : same ? '<p class="ed-look__l"><b>Same as ' + esc(py) + '</b> · ' + esc(ns.filter(Boolean).join(' · ')) + '</p>'
      : '<p class="ed-look__l"><small>' + esc(py) + '</small>' + ws.map(x => esc(x || '·')).join(' · ') + '</p><p class="ed-look__l"><small>' + esc(X.year) + '</small>' + ns.map((x, i) => cell(ws[i], x)).join(' · ') + '</p>';
    return '<div class="ed-look"><p class="ed-look__h"><b>' + (r._look === 'unsure' ? 'Not sure' : 'To check') + '</b></p>' + body +
      '<p class="ed-look__why">' + (spec.file === 'shifts' ? 'Shifts change most years: check the times and how many are needed' : 'Its time or place changes most years') + '</p>' +
      (S.ro ? '' : '<p class="ed-btns"><button type="button" class="wk-btn wk-btn--line wk-btn--small" data-keep>' + I.check + 'Keep</button><button type="button" class="wk-linklike" data-lookchange>Change</button>' + (r._look === 'unsure' ? '' : '<button type="button" class="wk-linklike" data-notsure>Not sure</button>') + '</p>') + '</div>';
  }
  function lastYearOf(r) {
    const rows = prev[spec.file] || [], key = spec.file === 'shifts' ? 'role' : 'title';
    const same = rows.filter(x => lc(x[key]) === lc(r[key]) && (spec.file !== 'shifts' || lc(x.committee) === lc(r.committee)));
    return same.find(x => lc(x.day) === lc(r.day)) || same[0] || null;
  }
  function whenAgo(at) {
    if (!at) return '';
    const t = new Date(at.replace(' ', 'T') + 'Z'), s = (Date.now() - t) / 1000;
    if (s < 90) return 'just now';
    if (s < 3600) return Math.round(s / 60) + ' min ago';
    if (s < 86400) return Math.round(s / 3600) + ' hr ago';
    return O.fmtDate(t.toISOString().slice(0, 10), 'mdShort');
  }
  function histHtml() {
    const h = S.hist;
    if (h === 'loading') return '<section class="ed-hist"><p class="ed-dim">Loading</p></section>';
    if (!h.length) return '<section class="ed-hist"><h3 class="ed-h3">History</h3><p class="ed-dim">No changes yet</p></section>';
    const words = (o) => Object.keys(o || {}).filter(k => k[0] !== '_').map(k => k + ' ' + (o[k] || 'blank')).join(' · ');
    return '<section class="ed-hist"><h3 class="ed-h3">History</h3><ul>' + h.slice(0, 20).map((e, i) => '<li><b>' + esc(e.who || 'Someone') + '</b> · ' + esc(whenAgo(e.at)) + '<br><small>' + esc(e.action === 'add' ? 'Added' : e.action === 'remove' ? 'Removed' : words(e.after)) + '</small>' + (e.action === 'set' && !S.ro ? ' <button type="button" class="wk-linklike" data-restore="' + i + '">Restore</button>' : '') + '</li>').join('') + '</ul></section>';
  }

  /* ================================================================ changing rows */

  // A new row left blank (its details closed, another row chosen, another day): it goes, with Undo.
  function dropBlank(id) {
    if (!id || !F.isHeld(id) || id === S.keepBlank) return;
    const row = F.discard(id);
    if (!row) return;
    if (S.sel === id) S.sel = '';
    X.toast('Blank ' + spec.one + ' not kept', ['Undo', () => { const nid = F.add(row, { hold: true }); S.sel = nid; paint(['rail', 'main', 'insp'], '[data-insp] [data-fk]'); }]);
  }
  function select(id, o) {
    o = o || {};
    if (S.sel && S.sel !== id) dropBlank(S.sel);
    S.sel = id || ''; S.hist = null; S.kindOpen = false; S.ruleOther = false; S.anchor = '';
    if (!o.keepMulti) S.multi.clear();
    paint(['main', 'insp']);
    if (S.sel && (o.focusInsp || isNarrow())) { const h = root.querySelector('#ed-insp-h'); if (h) h.focus({ preventScroll: !isNarrow() }); if (isNarrow()) window.scrollTo(0, 0); }
    else if (o.focusRow !== false && id) { const tr = root.querySelector('[data-id="' + CSS.escape(id) + '"], [data-ev="' + CSS.escape(id) + '"]'); if (tr) tr.focus({ preventScroll: true }); }
    sync();
  }
  function closeInsp() {
    const id = S.sel;
    dropBlank(id);
    S.sel = ''; paint(['rail', 'main', 'insp']);
    const tr = id && root.querySelector('[data-id="' + CSS.escape(id) + '"], [data-ev="' + CSS.escape(id) + '"]'); if (tr) tr.focus({ preventScroll: true });
  }
  function setRow(id, fields, o) {
    o = o || {};
    if (S.ro) return;
    const r = F.get(id); if (!r) return;
    F.set(id, fields, { label: o.label || spec.label(r), key: o.key });
    // A new row goes to the server once its key field (title, job, name…) has something in it.
    if (F.isHeld(id) && val(F.get(id), spec.keyField).trim()) F.release(id);
    afterChange(id, o);
  }
  function afterChange(id, o) {
    o = o || {};
    const tr = root.querySelector('[data-id="' + CSS.escape(id) + '"]'), r = F.get(id);
    if (o.repaint) paint(o.repaint, o.focus);
    else if (tr && r) { tr.outerHTML = rowHtml(r, S.q && spec.groups); }
    if (!o.repaint || o.repaint.indexOf('rail') < 0) { const el = root.querySelector('[data-rail]'); if (el && spec.groups) el.innerHTML = railHtml(); }
  }
  function addRow(row, o) {
    o = o || {};
    // Placed among rows in the list's order (the server keeps file order; the list sorts). A row with
    // nothing in its key field yet is kept here until something is typed (never a blank public row).
    dropBlank(S.sel);
    const id = F.add(row, { label: 'Add ' + (row[spec.keyField] || spec.one), hold: !val(row, spec.keyField).trim() });
    S.sel = id;
    flash(id);
    paint(['rail', 'main', 'insp'], o.focus || (isNarrow() ? '#ed-insp-h' : '[data-insp] [data-fk]'));
    return id;
  }
  function removeRow(id) {
    const r = F.get(id); if (!r || S.ro) return;
    const n = signedUp(r), name = spec.label(r);
    if (spec.id === 'places' && usedBy(r.code).n && S.confirmRemove !== id) { S.confirmRemove = id; X.toast('Used by ' + usedBy(r.code).text + ' · Rename the code instead, or press Remove again and choose their new place'); return; }
    if (n && S.confirmRemove !== id) { S.confirmRemove = id; X.toast(plural(n, spec.file === 'shifts' ? 'person' : 'team') + ' signed up · They’ll be told · Press again to remove', null); return; }
    S.confirmRemove = '';
    F.remove(id, { label: 'Remove ' + name });
    S.sel = ''; S.multi.delete(id);
    paint(['rail', 'main', 'insp']);
    X.toast((X.publicState(spec.part, spec.gate).cls === 'is-live' && spec.file === 'schedule' ? 'Cancelled ' : 'Removed ') + name, ['Undo', doUndo]);
  }
  function duplicate(id) {
    const r = F.get(id); if (!r) return;
    const c = Object.assign({}, r); delete c._id; delete c.uid; delete c._look; delete c._guess;
    if (spec.file === 'tournaments') c.id = 't' + Date.now().toString(36);
    const nid = F.add(c, { before: (F.rows[F.rows.indexOf(r) + 1] || {})._id || '', label: 'Duplicate ' + spec.label(r) });
    S.sel = nid; flash(nid);
    paint(['rail', 'main', 'insp']);
    X.toast('Duplicated ' + spec.label(r), ['Undo', doUndo]);
  }
  function doUndo(redo) {
    const res = redo ? F.redo() : F.undo();
    if (!res) { X.toast(redo ? 'Nothing to redo' : 'Nothing to undo'); return; }
    if (res.blocked) {
      X.toast('Changed by ' + res.blocked[0].by + ' since · ' + (redo ? 'Redo' : 'Undo') + ' anyway?', [redo ? 'Redo' : 'Undo', () => { (redo ? F.redo(true) : F.undo(true)); paint(['rail', 'main', 'insp']); }]);
      return;
    }
    if (S.sel && !F.get(S.sel)) S.sel = '';
    paint(['rail', 'main', 'insp']);
    X.toast((redo ? 'Redone · ' : 'Undone · ') + pastLabel(res.label));
  }
  // "Remove Snack" → "Snack removed", "Move Snack to Friday" → "Snack moved to Friday"; a change is the title.
  const PAST = { Add: 'added', Remove: 'removed', Move: 'moved', Duplicate: 'duplicated', Keep: 'kept', Paste: 'pasted', Replace: 'replaced', Import: 'imported', Restore: 'restored', Merge: 'merged', Split: 'split', Rename: 'renamed', Start: 'started', Copy: 'copied', Post: 'posted' };
  function pastLabel(l) {
    const m = String(l || '').match(/^(\w+) (.+?)( to .+)?$/);
    return m && PAST[m[1]] ? m[2] + ' ' + PAST[m[1]] + (m[3] || '') : l;
  }
  function flash(id) {
    if (matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    S.flash.add(id);
    setTimeout(() => { S.flash.delete(id); const tr = root.querySelector('[data-id="' + CSS.escape(id) + '"]'); if (tr) tr.classList.remove('is-flash'); }, 1600);
    setTimeout(() => { const tr = root.querySelector('[data-id="' + CSS.escape(id) + '"]'); if (tr) tr.scrollIntoView({ block: 'nearest', behavior: 'smooth' }); }, 30);
  }
  function goGroup(g, o) {
    o = o || {};
    if (!o.keepSel) { dropBlank(S.sel); S.sel = ''; } S.group = g; S.multi.clear(); S.paste = false;
    const u = new URL(location.href); u.searchParams.set('edit', X.edit.split(':')[0] + (g ? ':' + g : '')); history.replaceState(null, '', u);
    X.title(g && g[0] !== '@' ? (spec.file === 'shifts' ? g + ' shifts' : g + ' · ' + spec.title) : spec.title);
    if (spec.file === 'shifts') { const h = root.querySelector('.ws-title h1'); if (h) h.textContent = g && g[0] !== '@' ? g + ' shifts' : 'Shifts'; }
    const see = root.querySelector('a[data-see]'); if (see) see.setAttribute('href', spec.see(g));
    paint(['rail', 'main', 'insp'], o.focus);
    sync();
  }

  // The When field: read as it's typed; what was understood is said under it at once.
  function whenTyped(r, text) {
    const w = R.when(text, readCtx(r.day, { title: r.title || r.role || '', audience: r.audience }));
    if (!text.trim()) return { start: '', end: '', sort_time: '', _guess: '' };
    if (!w.start) return null;
    return { start: w.start, end: w.end, sort_time: w.sort_time || (R.minutes(w.start) != null ? '' : r.sort_time || ''), _guess: w.guess ? '1' : '' };
  }

  /* ================================================================ status, sync */

  function status() {
    const el = root.querySelector('[data-status]');
    if (!el) return;
    const stores = [F].concat(Object.values(aux).filter(a => a && a.state));
    const worst = ['signedout', 'held', 'error', 'conflict', 'offline', 'saving', 'saved'].find(s => stores.some(f => f.state === s)) || 'saved';
    const f = stores.find(x => x.state === worst) || F;
    const W = window.OGC_WP || {};
    const html = {
      saving: 'Saving', saved: F.undoes.length ? I.check + 'Saved' : '',
      offline: 'Offline · Saves when back',
      conflict: 'Not saved · ' + plural(F.conflicts(), 'conflict'),
      error: 'Couldn’t save' + (f.problem ? ' · ' + esc(f.problem) : '') + ' · <button type="button" class="wk-linklike" data-retry>Retry</button>',
      signedout: 'Signed out · <a href="' + esc((W.signin || '/annual-conference/signin/') + '?return=' + encodeURIComponent(location.pathname + location.search)) + '" target="_blank" rel="noopener">Sign in</a>',
      held: 'Held · Read only'
    }[worst];
    el.innerHTML = S.editingText && worst === 'saved' ? 'Not saved yet · Leave the field to save' : html;
    el.className = 'ws-status ed-status is-' + worst;
  }
  // Every 30 seconds and when the window comes back: who's here, and others' changes.
  let pollT = 0;
  function poll() {
    clearInterval(pollT);
    pollT = setInterval(() => { if (!document.hidden) sync(); }, 30000);
  }
  function sync() { F.sync({ group: S.group, row: S.sel || '' }); }
  function wire() {
    const repaint = () => paint(['rail', 'main', 'insp']);
    [F].concat(Object.values(aux).filter(a => a && a.on)).forEach(f => f.on('status', status));
    F.on('conflict', list => {
      const gone = list.filter(c => c.gone);
      const c = list.find(x => x.field);
      if (c && c.id !== S.sel) { const r = F.get(c.id); X.toast('Changed by ' + (c.by || 'someone') + ' · ' + (r ? spec.label(r) : ''), ['Open', () => select(c.id, { focusInsp: true })]); }
      if (gone.length) X.toast('Removed by someone else · Your change wasn’t kept');
      repaint();
    });
    F.on('remote', d => {
      d.changed.forEach(id => flash(id));
      if (S.sel && d.gone.indexOf(S.sel) > -1) { S.sel = ''; X.toast('Removed by someone else'); }
      const a = document.activeElement, typing = a && a.closest && a.closest('[data-insp]') && /INPUT|TEXTAREA/.test(a.tagName);
      paint(typing ? ['rail', 'main'] : ['rail', 'main', 'insp']);
    });
    F.on('here', () => { const el = root.querySelector('[data-rail]'); if (el && spec.groups) el.innerHTML = railHtml(); });
    F.on('ids', d => { if (S.sel === d.from) S.sel = d.to; if (S.multi.has(d.from)) { S.multi.delete(d.from); S.multi.add(d.to); } root.querySelectorAll('[data-id="' + CSS.escape(d.from) + '"]').forEach(el => { el.dataset.id = d.to; }); });
    F.on('status', s => { if (s.state === 'error' && s.data && s.data.data && s.data.data.column) X.toast('Couldn’t save ' + s.data.data.column + ' · ' + s.message); });
    window.addEventListener('focus', sync);
    document.addEventListener('visibilitychange', () => { if (!document.hidden) sync(); });
    window.addEventListener('beforeunload', e => { if ([F].concat(Object.values(aux)).some(f => f && f.unsaved && f.unsaved())) { e.preventDefault(); e.returnValue = ''; } });
    window.addEventListener('resize', () => { document.documentElement.classList.toggle('ed-insp-open', !!S.sel && isNarrow()); });
  }

  /* ================================================================ events */

  root.addEventListener('click', e => {
    if (!spec) return;
    const t = e.target.closest('button, a, [data-id], [data-ev], [data-goto], li[data-opt], li[data-optnew], input[type=checkbox]');
    if (!t) return;
    const d = t.dataset;
    if (t.hasAttribute('data-unlock')) {
      S.ro = false; F.opts.readOnly = false; S.sel = '';
      const more = Object.values(aux).filter(a => a && a.opts && (a.name === 'places' || a.name === 'committees'));
      more.forEach(a => { a.opts.readOnly = false; });
      Promise.all([F.load()].concat(more.map(a => a.load()))).then(() => { draw(); X.toast('Unlocked · Every change is logged'); });
      return;
    }
    if (t.hasAttribute('data-retry')) { F.retry(); Object.values(aux).forEach(a => a && a.retry && a.state === 'error' && a.retry()); return; }
    if (t.hasAttribute('data-export')) { doExport(); return; }
    if (t.hasAttribute('data-import')) { root.querySelector('[data-file]').click(); return; }
    if (t.hasAttribute('data-keys')) { keysSheet(); return; }
    if (t.hasAttribute('data-filemenu')) { const m = t.nextElementSibling, open = m.hidden; m.hidden = !open; t.setAttribute('aria-expanded', String(open)); if (open) { const f = m.querySelector('button, a'); if (f) f.focus(); } return; }
    if (t.closest('.ed-file__m')) { const m = t.closest('.ed-file__m'); m.hidden = true; m.previousElementSibling.setAttribute('aria-expanded', 'false'); }
    if (t.hasAttribute('data-rooms')) { exportRooms(); X.toast('Exported · Rooms booked'); return; }
    if (t.hasAttribute('data-print')) {
      const m = root.querySelector('[data-main]'), pub = X.publicState(spec.part, spec.gate);
      m.dataset.print = X.year + ' ' + spec.title + (S.q ? ' · ' + S.q : '') + (pub.cls === 'is-live' ? '' : ' · Draft · Not for posting') + ' · Printed ' + O.fmtDate(X.today, 'md');
      window.print(); return;
    }
    if (d.group != null && t.classList.contains('ed-rail__b') || (d.group && t.closest('.ed-row--fold'))) { S.q = ''; const f = root.querySelector('[data-find]'); if (f) f.value = ''; goGroup(d.group, { focus: '[data-group="' + CSS.escape(d.group) + '"]' }); return; }
    if (d.startfrom != null) { startFrom(d.startfrom); return; }
    if (t.hasAttribute('data-startall')) { startAll(); return; }
    if (t.hasAttribute('data-addcommittee')) { S.addingGroup = true; if (root.querySelector('[data-rail]')) paint(['rail'], '[data-newgroup]'); return; }
    if (t.hasAttribute('data-clearfind')) { clearFind(); return; }
    if (t.hasAttribute('data-replaceon')) { S.replacing = true; paint(['main'], '[data-replacein]'); return; }
    if (t.hasAttribute('data-replacego')) { const list = visible().filter(r => replaced(r)); F.batch('Replace in ' + list.length, () => list.forEach(r => F.set(r._id, replaced(r), {}))); S.replacing = false; paint(['rail', 'main', 'insp']); X.toast('Replaced in ' + plural(list.length, spec.one), ['Undo', doUndo]); return; }
    if (d.dayview) { goGroup(d.dayview, { focus: '[data-dayview="' + CSS.escape(d.dayview) + '"]' }); return; }
    if (d.view) { S.view = d.view; const ed = root.querySelector('[data-ed]'); if (ed) ed.classList.toggle('is-day', d.view === 'day'); try { localStorage.setItem('ogc-ed-view', d.view); } catch (x) { /* not kept */ } paint(['main'], '[data-view="' + d.view + '"]'); return; }
    if (d.zoom) { S.zoom = Math.max(.6, Math.min(2.4, S.zoom * (+d.zoom > 0 ? 1.25 : .8))); paint(['main'], '[data-zoom="' + d.zoom + '"]'); return; }
    if (t.hasAttribute('data-dayhintx')) { try { localStorage.setItem('ogc-ed-dayhint', '1'); } catch (x) { /* shown again */ } const h = root.querySelector('.ed-dayhint'); if (h) h.remove(); return; }
    if (t.hasAttribute('data-paste')) { S.paste = true; S.view = 'table'; paint(['main'], '[data-pastein]'); return; }
    if (t.hasAttribute('data-pasteoff')) { S.paste = false; S.pasteText = ''; S.pasteRes = null; paint(['main'], '[data-quickin]'); return; }
    if (d.pasteflip != null) { const x = S.pasteRes.rows[+d.pasteflip], r = x.row; r.start = R.store(R.minutes(r.start) + 720); if (R.minutes(r.end) != null) r.end = R.store(R.minutes(r.end) + 720); x.guess = ''; paint(['main']); return; }
    if (t.hasAttribute('data-flipquick')) { S.flipQuick = !S.flipQuick; const e2 = root.querySelector('[data-quickecho]'), inp = root.querySelector('[data-quickin]'); if (e2 && inp) e2.innerHTML = quickEcho(inp.value); inp && inp.focus(); return; }
    if (d.addplace) { addPlace(d.addplace).then(() => { const e2 = root.querySelector('[data-quickecho]'), inp = root.querySelector('[data-quickin]'); if (e2 && inp) e2.innerHTML = quickEcho(inp.value); }); return; }
    if (t.hasAttribute('data-undoimport')) { doUndo(); S.lastImport = ''; paint(['main']); return; }
    if (t.hasAttribute('data-impcancel')) { S.importing = null; paint(['main']); return; }
    if (t.hasAttribute('data-impapply')) { applyImport(); return; }
    if (t.hasAttribute('data-applymap')) { applyMap(); return; }
    if (t.hasAttribute('data-renamegroup')) { S.renaming = true; paint(['main'], '[data-renamein]'); return; }
    if (t.hasAttribute('data-renameoff')) { S.renaming = false; paint(['main']); return; }
    if (t.hasAttribute('data-removegroup')) { removeGroup(); return; }
    if (t.hasAttribute('data-bulkoff')) { S.multi.clear(); paint(['main']); return; }
    if (d.bulkmove || d.bulkcopy || d.bulkfor != null || d.bulkcall != null || t.hasAttribute('data-bulkremove')) { bulk(d, t); return; }
    if (t.hasAttribute('data-add')) { addRow(spec.blank(S.group)); return; }
    if (d.deskadd != null) { const day = X.days[+d.deskadd], like = F.rows.find(x => x.display === 'desk' && x.place === d.desk && (x.title || 'Open') === d.kind) || {}; addRow({ day: day.name, audience: like.audience || 'All', title: d.kind, place: d.desk, start: like.start || '8:00 AM', end: like.end || '5:00 PM', display: 'desk' }, { focus: '[data-insp] [data-fk="when"]' }); return; }
    if (d.goto) { const r = F.get(d.goto); if (r) goGroup(r.day, { keepSel: true }); select(d.goto, { focusInsp: true }); return; }
    if (d.split) { splitRepeat(d.split, 'one'); return; }
    if (t.classList.contains('ed-deskcell')) { select(d.id, { focusInsp: true }); return; }
    if (d.id && !e.target.closest('button, a, input')) {
      if (e.shiftKey || e.metaKey || e.ctrlKey) { toggleMulti(d.id, e.shiftKey); return; }
      select(d.id === S.sel && !isNarrow() ? d.id : d.id); return;
    }
    if (d.ev && !pd) { select(d.ev); return; }
    // The details.
    const r = S.sel && F.get(S.sel);
    if (t.hasAttribute('data-close')) { closeInsp(); return; }
    if (t.hasAttribute('data-more')) { S.more = !S.more; paintInsp(); const b = root.querySelector('[data-more]'); if (b) b.focus(); return; }
    if (!r) return;
    if (t.hasAttribute('data-dup')) { duplicate(r._id); return; }
    if (t.hasAttribute('data-remove')) { removeRow(r._id); return; }
    if (t.hasAttribute('data-keep')) { setRow(r._id, { _look: '' }, { label: 'Keep ' + spec.label(r) }); nextToCheck(r); return; }
    if (t.hasAttribute('data-notsure')) { setRow(r._id, { _look: 'unsure' }, { repaint: ['main', 'insp'] }); X.toast('Not sure · On the COA’s list'); return; }
    if (t.hasAttribute('data-lookchange')) { const f = root.querySelector('[data-insp] [data-fk="when"], [data-insp] [data-fk]'); if (f) f.focus(); return; }
    if (t.hasAttribute('data-merge')) { const dup = F.rows.find(x => x._id !== r._id && x.day === r.day && lc(x.title) === lc(r.title) && lc(x.start) === lc(r.start)); if (dup) { F.remove(dup._id, { label: 'Merge ' + spec.label(r) }); paint(['rail', 'main', 'insp']); X.toast('Merged', ['Undo', doUndo]); } return; }
    if (t.hasAttribute('data-history')) { S.hist = 'loading'; paintInsp(); F.history(r._id).then(h => { S.hist = h || []; paintInsp(); }).catch(() => { S.hist = []; paintInsp(); }); return; }
    if (d.restore != null && Array.isArray(S.hist)) { const h = S.hist[+d.restore]; if (h && h.before) { setRow(r._id, h.before, { label: 'Restore ' + spec.label(r), repaint: ['main', 'insp'] }); X.toast('Restored', ['Undo', doUndo]); } return; }
    if (d.keepmine || d.keeptheirs) { const mine = !!d.keepmine; (d.keepmine || d.keeptheirs).split('|').forEach(k => F.resolve(r._id, k, mine)); paint(['main', 'insp']); X.toast(mine ? 'Kept yours' : 'Theirs kept'); return; }
    if (t.hasAttribute('data-allweek')) { setRow(r._id, { start: 'All week', end: '', sort_time: '', _guess: '' }, { repaint: ['main', 'insp'], focus: '[data-fk="when"]' }); return; }
    if (t.hasAttribute('data-flip')) { const a = R.minutes(r.start), b = R.minutes(r.end); setRow(r._id, { start: R.store(a + 720), end: b == null ? r.end : R.store(b + 720), _guess: '' }, { repaint: ['main', 'insp'], focus: '[data-fk="when"]' }); return; }
    if (t.hasAttribute('data-kindopen')) { S.kindOpen = true; paintInsp(); const b = root.querySelector('[data-pick="kind"]'); if (b) b.focus(); return; }
    if (t.hasAttribute('data-checknow')) { setRow(r._id, { checked: X.today }, { repaint: ['main', 'insp'] }); return; }
    if (d.ends) { const day = d.ends === 'tonight' ? X.today : d.ends === 'last' ? X.row.end : O.isoAddDays(X.today, 1); setRow(r._id, { to: day, until_time: '11:59 PM' }, { repaint: ['main', 'insp'] }); return; }
    if (t.hasAttribute('data-post')) { postNotice(r, t); return; }
    if (d.event) { const ev = (aux.schedule.rows || []).find(x => x._id === d.event); S.eventOpen = false; if (ev) setRow(r._id, { schedule_id: ev._id, schedule_title: ev.title }, { repaint: ['main', 'insp'], focus: '[data-eventopen]' }); return; }
    if (t.hasAttribute('data-eventopen')) { S.eventOpen = true; paintInsp(); const f = root.querySelector('[data-eventq]'); if (f) f.focus(); return; }
    if (d.helpnum) { setRow(r._id, { phone: d.helpnum, checked: X.today }, { repaint: ['main', 'insp'], focus: '[data-helpnum="' + CSS.escape(d.helpnum) + '"]' }); return; }
    if (t.hasAttribute('data-helpchecked')) { setRow(r._id, { checked: X.today }, { repaint: ['main', 'insp'] }); X.toast('Checked'); return; }
    if (t.hasAttribute('data-movenumbers')) { moveNumbers(); return; }
    if (d.alsox) { setRow(r._id, { also: String(r.also || '').split('|').filter(c => c && c !== d.alsox).join('|') }, { repaint: ['main', 'insp'] }); return; }
    if (d.range) { pickRange(r, d.range); return; }
    if (d.step) { const k = d.step, n = Math.max(k === 'min' || k === 'max' ? 1 : 0, (+r[k] || 0) + +d.by); setRow(r._id, { [k]: String(n) }, { key: 'step:' + k, repaint: ['main', 'insp'], focus: '[data-step="' + k + '"][data-by="' + d.by + '"]' }); return; }
    if (d.pick) { pick(r, d.pick, d.v, t.hasAttribute('data-multi')); return; }
    if (t.matches('li[data-opt], li[data-optnew]')) { choosePlace(t); return; }
  });

  function pick(r, k, v, multi) {
    if (k === 'who') { setRow(r._id, { display: v }, { repaint: ['main', 'insp'], focus: '[data-pick="who"][data-v="' + CSS.escape(v) + '"]' }); return; }
    if (k === 'rule' && v === '@other') { S.ruleOther = true; paintInsp(); const f = root.querySelector('[data-insp] [data-k="rule"]'); if (f) f.focus(); return; }
    if (k === 'kind' && v === '@other') { setRow(r._id, { kind: 'Other' }, { repaint: ['main', 'insp'] }); const f = root.querySelector('[data-insp] [data-k="kind"]'); if (f) f.focus(); return; }
    let nv = v;
    if (multi) { const on = String(r[k] || '').split('|').filter(Boolean), i = on.indexOf(v); if (i > -1) on.splice(i, 1); else on.push(v); nv = on.join('|'); }
    else if (k === 'rule') S.ruleOther = false;
    const fields = { [k]: nv };
    // A row moved to another day: it goes there, and the list follows it.
    if (k === 'day' && spec.file === 'schedule') {
      if (r.last_day && dayIx(r.last_day) <= dayIx(nv)) fields.last_day = '';
      setRow(r._id, fields, { label: 'Move ' + spec.label(r) + ' to ' + nv });
      goGroup(nv, { keepSel: true, focus: '[data-pick="day"][data-v="' + CSS.escape(nv) + '"]' });
      X.toast('Moved to ' + nv, ['Undo', () => { doUndo(); goGroup(r.day, { keepSel: true }); }]);
      return;
    }
    setRow(r._id, fields, { repaint: ['main', 'insp'], focus: '[data-pick="' + CSS.escape(k) + '"][data-v="' + CSS.escape(v) + '"]' });
  }
  // A shift's days: the first tap is the first day, the next (later) tap the last.
  // The same for a schedule row (a row that runs several days); moving its first day, the list follows.
  function pickRange(r, day) {
    const i = dayIx(day), f = '[data-range="' + CSS.escape(day) + '"]';
    if (spec.file === 'shifts' && signedUp(r)) setTimeout(() => X.toast(plural(signedUp(r), 'person') + ' signed up · They’ll be told', ['Undo', doUndo]), 0);
    if (S.anchor && dayIx(S.anchor) < i) { setRow(r._id, { day: S.anchor, last_day: day }, { repaint: ['rail', 'main', 'insp'], focus: f }); S.anchor = ''; paintInsp(); const b = root.querySelector(f); if (b) b.focus(); return; }
    S.anchor = day;
    const moved = r.day !== day;
    setRow(r._id, { day, last_day: '' }, { label: moved ? 'Move ' + spec.label(r) + ' to ' + day : '', repaint: ['rail', 'main', 'insp'], focus: f });
    if (moved && spec.file === 'schedule') { goGroup(day, { keepSel: true, focus: f }); X.toast('Moved to ' + day, ['Undo', () => { doUndo(); goGroup(r.day, { keepSel: true }); }]); }
  }
  function toggleMulti(id, range) {
    if (range && (S.sel || S.lastMulti)) {
      const list = visible().map(r => r._id), a = list.indexOf(S.lastMulti || S.sel), b = list.indexOf(id);
      if (a > -1 && b > -1) list.slice(Math.min(a, b), Math.max(a, b) + 1).forEach(x => S.multi.add(x));
    } else if (S.multi.has(id)) S.multi.delete(id); else S.multi.add(id);
    if (S.sel && !S.multi.size) S.multi.add(S.sel);
    S.lastMulti = id; S.sel = '';
    paint(['main', 'insp']);
  }
  function bulk(d, t) {
    const ids = Array.from(S.multi), rows = ids.map(id => F.get(id)).filter(Boolean);
    if (!rows.length) return;
    if (t.hasAttribute('data-bulkremove')) { F.batch('Remove ' + plural(rows.length, spec.one), () => rows.forEach(r => F.remove(r._id, {}))); S.multi.clear(); paint(['rail', 'main', 'insp']); X.toast('Removed ' + plural(rows.length, spec.one), ['Undo', doUndo]); return; }
    if (d.bulkmove) { F.batch('Move to ' + d.bulkmove, () => rows.forEach(r => F.set(r._id, { day: d.bulkmove, last_day: r.last_day && dayIx(r.last_day) > dayIx(d.bulkmove) ? r.last_day : '' }, {}))); S.multi.clear(); goGroup(d.bulkmove); X.toast('Moved ' + plural(rows.length, spec.one) + ' to ' + d.bulkmove, ['Undo', doUndo]); return; }
    if (d.bulkcopy) { F.batch('Copy to ' + d.bulkcopy, () => rows.forEach(r => { const c = Object.assign({}, r, { day: d.bulkcopy, last_day: '' }); delete c._id; delete c._look; F.add(c, { quiet: false }); })); S.multi.clear(); goGroup(d.bulkcopy); X.toast('Copied ' + plural(rows.length, spec.one) + ' to ' + d.bulkcopy, ['Undo', doUndo]); return; }
    if (d.bulkfor != null) { F.batch('For ' + audLabel(d.bulkfor), () => rows.forEach(r => F.set(r._id, { audience: d.bulkfor }, {}))); paint(['main']); X.toast('Changed ' + plural(rows.length, spec.one), ['Undo', doUndo]); return; }
    if (d.bulkcall != null) { F.batch('Call-in', () => rows.forEach(r => F.set(r._id, { call_in: d.bulkcall }, {}))); paint(['main', 'rail']); X.toast('Changed ' + plural(rows.length, spec.one), ['Undo', doUndo]); }
  }
  // A repeated row changed on one day only: split, the way a calendar does.
  function splitRepeat(id, how) {
    const r = F.get(id), g = S.group;
    if (!r || !r.last_day || dayIx(g) <= dayIx(r.day)) return;
    const gi = dayIx(g), last = dayIx(r.last_day);
    let nid;
    F.batch('Split ' + spec.label(r), () => {
      F.set(id, { last_day: gi - 1 > dayIx(r.day) ? X.days[gi - 1].name : '' }, {});
      const one = Object.assign({}, r, { day: g, last_day: how === 'one' ? '' : r.last_day }); delete one._id; delete one._look;
      nid = F.add(one, {});
      if (how === 'one' && gi < last) { const rest = Object.assign({}, r, { day: X.days[gi + 1].name, last_day: gi + 1 < last ? r.last_day : '' }); delete rest._id; delete rest._look; F.add(rest, {}); }
    });
    S.sel = nid; paint(['rail', 'main', 'insp'], '#ed-insp-h');
    X.toast(g + ' only · Split from the repeated row', ['Undo', doUndo]);
  }
  function nextToCheck(r) {
    const left = F.rows.filter(x => x._look && x._look !== 'unsure').sort((a, b) => dayIx(a.day) - dayIx(b.day) || tStart(a) - tStart(b));
    const next = left.find(o => spec.file !== 'schedule' || dayIx(o.day) > dayIx(r.day) || (o.day === r.day && tStart(o) >= tStart(r))) || left[0];
    if (next) { if (spec.groups) { const g = spec.file === 'schedule' ? next.day : next.committee; if (g !== S.group) goGroup(g, { keepSel: true }); } select(next._id, { focusInsp: true }); const b = root.querySelector('[data-keep]'); if (b) b.focus(); }
    else { paint(['rail', 'main', 'insp']); }
    X.toast(left.length ? 'Kept · ' + left.length + ' to check' : 'Kept · All checked', ['Undo', doUndo]);
  }
  function clearFind() { S.q = ''; S.replacing = false; const f = root.querySelector('[data-find]'); if (f) f.value = ''; const x = root.querySelector('.ed-find__x'); if (x) x.hidden = true; paint(['rail', 'main']); const b = root.querySelector('[data-group][aria-current="true"]'); if (b) b.focus(); }

  // Last year's committee, brought in (each shift to check), or a new one.
  function startFrom(c) {
    const rows = (prev.shifts || []).filter(r => r.committee === c);
    F.batch('Start ' + c + ' from ' + X.prevRow.year, () => rows.forEach(r => { const n = Object.assign({}, r, { _look: '1' }); delete n._id; delete n.uid; F.add(n, {}); }));
    goGroup(c);
    X.toast(c + ' · ' + plural(rows.length, 'shift') + ' to check', ['Undo', doUndo]);
  }
  // Every committee from last year at once (each shift to check), as one step of Undo.
  function startAll() {
    const have = new Set(F.rows.map(r => r.committee)), rows = (prev.shifts || []).filter(r => !have.has(r.committee)), cs = uniq(rows.map(r => r.committee));
    if (!rows.length) return;
    F.batch('Start ' + plural(cs.length, 'committee') + ' from ' + X.prevRow.year, () => rows.forEach(r => { const n = Object.assign({}, r, { _look: '1' }); delete n._id; delete n.uid; F.add(n, {}); }));
    goGroup(cs[0]);
    X.toast(plural(cs.length, 'committee') + ' · ' + plural(rows.length, 'shift') + ' to check', ['Undo', doUndo]);
  }
  function removeGroup() {
    const g = S.group;
    if (F.rows.some(r => r.committee === g)) return;
    S.extraGroups = (S.extraGroups || []).filter(x => x !== g);
    const c = aux.committees && aux.committees.rows.find(x => x.name === g);
    if (c) aux.committees.remove(c._id, { label: 'Remove ' + g });
    const gs = spec.groups();
    goGroup((gs.find(x => !x.faint) || {}).id || '');
    X.toast('Removed ' + g, c ? ['Undo', () => { aux.committees.undo(); paint(['rail', 'main']); }] : null);
  }

  // A new place, made in Buildings and rooms from where it was typed.
  async function addPlace(text) {
    const pl = aux.places || (spec.file === 'places' ? F : null);
    if (!pl || S.ro) return null;
    const t = String(text || '').trim(), code = /^[A-Za-z0-9]{1,4}(\/[A-Za-z0-9]{1,6})?$/.test(t) ? t.toUpperCase() : t.replace(/[^A-Za-z0-9]+/g, '').slice(0, 6).toUpperCase() || 'NEW';
    let c = code, n = 2; while (placesList().some(p => lc(p.code) === lc(c))) c = code + n++;
    pl.add({ code: c, name: t, building: '' }, { label: 'Add place ' + t });
    X.toast('Added ' + t + ' to Buildings and rooms');
    return c;
  }
  async function choosePlace(li) {
    const box = li.closest('[data-combo]'), k = box.dataset.combo, r = S.sel && F.get(S.sel);
    let code = li.dataset.opt;
    if (li.dataset.optnew != null) code = await addPlace(li.dataset.optnew);
    if (code == null) return;
    if (k.indexOf('map_') === 0) { S.map[k.slice(4)] = code; paint(['main']); return; }
    if (!r) return;
    if (k === 'also_add') { if (code) setRow(r._id, { also: uniq(String(r.also || '').split('|').concat([code])).join('|') }, { repaint: ['main', 'insp'], focus: '#ed-combo-also_add' }); return; }
    setRow(r._id, { [k]: code }, { repaint: ['main', 'insp'], focus: '#ed-combo-' + CSS.escape(k) });
  }

  /* ---- typing */

  const timers = {};
  root.addEventListener('input', e => {
    if (!spec) return;
    const t = e.target;
    if (t.matches('textarea.ed-grow')) grow(t);
    const help = t.closest('.ed-f') && t.closest('.ed-f').querySelector('.ed-help');
    if (help && !t.hasAttribute('data-pastein')) help.classList.toggle('is-on', !t.value);
    if (t.hasAttribute('data-find')) { const x = root.querySelector('.ed-find__x'); if (x) x.hidden = !t.value; S.q = t.value; S.sel = ''; clearTimeout(timers.find); timers.find = setTimeout(() => paint(['rail', 'main', 'insp']), 120); return; }
    if (t.hasAttribute('data-replacein')) { S.replaceWith = t.value; const b = root.querySelector('[data-replacego]'); if (b) b.textContent = 'Replace in ' + plural(visible().filter(r => replaced(r)).length, spec.one); return; }
    if (t.hasAttribute('data-quickin')) { S.flipQuick = false; const e2 = root.querySelector('[data-quickecho]'); if (e2) e2.innerHTML = quickEcho(t.value); return; }
    if (t.dataset.unread != null) {
      const at = +t.dataset.unread, lines = String(S.pasteText || '').split(/\r?\n/);
      lines[at] = t.value; S.pasteText = lines.join('\n');
      const echo = t.nextElementSibling; if (echo) echo.innerHTML = unreadEcho(t.value);
      clearTimeout(timers.unread);
      // Read again once typing stops: a line now read joins the rows above.
      timers.unread = setTimeout(() => { const caret = t.selectionStart; S.pasteRes = R.paste(S.pasteText, readCtx(S.group)); paint(['main']); const box = root.querySelector('[data-unread="' + at + '"]') || root.querySelector('[data-unread]') || root.querySelector('[data-pastein]'); if (box) { box.focus(); try { box.setSelectionRange(caret, caret); } catch (x) { /* moved */ } } }, 700);
      return;
    }
    if (t.hasAttribute('data-pastein')) { S.pasteText = t.value; clearTimeout(timers.paste); timers.paste = setTimeout(() => { S.pasteRes = R.paste(t.value, readCtx(S.group)); paint(['main']); }, 250); return; }
    if (t.dataset.placein != null) { comboOpen(t); return; }
    if (t.hasAttribute('data-eventq')) { const ul = root.querySelector('[data-eventlist]'); if (ul && S.row) ul.innerHTML = eventList(S.row, t.value); return; }
    const r = S.sel && F.get(S.sel);
    if (!r || S.ro) return;
    if (t.hasAttribute('data-when')) {
      const w = whenTyped(r, t.value);
      const echo = root.querySelector('[data-whenecho]');
      if (!w) { if (echo) echo.innerHTML = '<span class="ed-chip is-warn">Not a time yet</span>'; return; }
      // A shift people are on: the new time is saved when the field is left (they're told once, not
      // at every keystroke).
      if (spec.file === 'shifts' && signedUp(r)) { if (echo) echo.innerHTML = whenChips(Object.assign({}, r, w), t.value) + '<span class="ed-chip">Saved when you leave the field</span>'; S.editingText = true; status(); return; }
      setRow(r._id, w, { key: 'when:' + r._id });
      if (echo) echo.innerHTML = whenChips(F.get(r._id), t.value);
      return;
    }
    const k = t.dataset.k;
    if (!k) return;
    let v = t.value;
    if (k === 'sort_time') { const m = R.when(v, readCtx(r.day)); if (!m.start || R.minutes(m.start) == null) return; v = m.start; }
    if (k === 'until_time') { const m = R.when(v, readCtx(r.day, { title: 'evening' })); v = v.trim() ? (m.start && R.minutes(m.start) != null ? m.start : null) : ''; if (v == null) return; }
    // A date typed as people say it: said back only when it reads differently ("5/7" → "Fri, May 7").
    if (/^(opens|from|to|post_from)_typed$/.test(k)) {
      const base = k.replace(/_typed$/, ''), iso = typedIso(v, spec.file === 'notices' ? X.today : X.row.start || X.today);
      const echo = t.closest('label').querySelector('.ed-echo'), said = iso ? O.fmtDate(iso, 'short') : '';
      if (echo) echo.textContent = iso ? (lc(said) === lc(v.trim()) ? '' : said + (iso.slice(0, 4) !== X.today.slice(0, 4) ? ', ' + iso.slice(0, 4) : '')) : v.trim() ? 'Not a date yet · Like Sun Oct 10' : '';
      if (iso || !v.trim()) setRow(r._id, { [base]: iso || '' }, { key: base + ':' + r._id });
      return;
    }
    if (k === 'closes_typed') { const c = typedClose(v); const echo = t.closest('label').querySelector('.ed-echo'); if (echo) echo.textContent = c ? c.closes_day + (c.closes_time ? ', ' + R.fmt(R.minutes(c.closes_time)) : '') : v.trim() ? 'Not read yet · Like Fri noon' : ''; if (c || !v.trim()) setRow(r._id, c || { closes_day: '', closes_time: '' }, { key: 'closes:' + r._id }); return; }
    if (k === 'kind_typed') { const hit = KINDS.concat(MORE_KINDS).find(x => lc(x[1]) === lc(v)); if (hit) setRow(r._id, { kind: hit[0] }, { repaint: ['main', 'insp'] }); return; }
    if (k === 'text' && spec.file === 'notices') { const c = t.closest('label').querySelector('[data-count]'); if (c) { c.textContent = v.length + ' of 140'; c.classList.toggle('is-over', v.length > 140); } if (!r.draft) { S.editingText = true; status(); return; } }
    if (k === 'code' && spec.file === 'places') return;   // renamed when the field is left (everywhere at once)
    setRow(r._id, { [k]: v }, { key: k + ':' + r._id });
    // The details' own flags follow the typing.
    const fw = t.closest('[data-fw]');
    if (fw) { const warn = issues(F.get(r._id)).filter(w => w.k === k); let ul = fw.querySelector('.ed-flags'); const html = warn.length ? '<ul class="ed-flags">' + warn.map(w => '<li class="' + (w.soft ? 'is-soft' : '') + '">' + I.warn + esc(w.text) + '</li>').join('') + '</ul>' : ''; if (ul) ul.outerHTML = html || ''; else if (html) fw.insertAdjacentHTML('beforeend', html); }
    if (k === 'title' || k === 'role' || k === 'name' || k === 'need' || k === 'label') { const h = root.querySelector('#ed-insp-h'); if (h) h.textContent = spec.label(F.get(r._id)); }
    if (k === 'text' && spec.file === 'notices') { const b = root.querySelector('[data-post]'); if (b) b.disabled = !v.trim(); const h = root.querySelector('#ed-insp-h'); if (h) h.textContent = spec.label(F.get(r._id)); }
  });
  // The year is the one that puts the date nearest `near` (today for a notice, the Conference for sign-ups).
  function typedIso(v, near) {
    const s = String(v || '').trim().replace(/^(sun|mon|tue|wed|thu|fri|sat)[a-z]*\.?,?\s*/i, '');
    if (!s) return '';
    let m = s.match(/^(\d{4})-(\d{2})-(\d{2})$/); if (m) return s;
    const MON = ['jan', 'feb', 'mar', 'apr', 'may', 'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec'];
    let mo, d;
    if ((m = s.match(/^([a-z]{3})[a-z]*\.?\s+(\d{1,2})/i))) { mo = MON.indexOf(m[1].toLowerCase()) + 1; d = +m[2]; }
    else if ((m = s.match(/^(\d{1,2})\/(\d{1,2})/))) { mo = +m[1]; d = +m[2]; }
    if (!mo || !d || d > 31 || mo > 12) return '';
    const md = '-' + String(mo).padStart(2, '0') + '-' + String(d).padStart(2, '0'), ref = near || X.today, y0 = +ref.slice(0, 4);
    return [y0 - 1, y0, y0 + 1].map(y => y + md).sort((a, b) => Math.abs(O.daysBetween ? O.daysBetween(ref, a) : 0) - Math.abs(O.daysBetween ? O.daysBetween(ref, b) : 0))[0];
  }
  function typedClose(v) {
    const s = String(v || '').trim(), m = s.match(/^(sun|mon|tue|wed|thu|fri|sat)[a-z]*\.?,?\s*(.*)$/i);
    if (!m) return null;
    const d = X.days.find(x => lc(x.name).slice(0, 3) === lc(m[1])) || { name: WEEKS.find(w => lc(w).slice(0, 3) === lc(m[1])) };
    const w = m[2] ? R.when(m[2], readCtx(d.name, { title: 'evening' })) : null;
    return { closes_day: d.name, closes_time: w && w.start && R.minutes(w.start) != null ? w.start : '' };
  }
  // Leaving a field: the list sorts again; a renamed code is renamed everywhere.
  root.addEventListener('change', e => {
    if (!spec) return;
    const t = e.target, r = S.sel && F.get(S.sel);
    if (t.matches('[data-imp]')) return;
    if (r && t.hasAttribute('data-when') && spec.file === 'shifts' && signedUp(r)) {
      const w = whenTyped(r, t.value); S.editingText = false;
      if (w && (w.start !== r.start || w.end !== r.end)) { const n = signedUp(r); setRow(r._id, w, { label: 'Change ' + spec.label(r) + ' time', repaint: ['main', 'insp'] }); X.toast(plural(n, 'person') + ' signed up · They’ll be told', ['Undo', doUndo]); }
      else status();
      return;
    }
    if (t.hasAttribute('data-when') || t.dataset.k === 'title' || t.dataset.k === 'role' || t.dataset.k === 'start') {
      // A new row's kind follows its title until one is chosen.
      if (r && spec.file === 'schedule' && t.dataset.k === 'title' && !r.kind && R.guessKind(r.title)) F.set(r._id, { kind: R.guessKind(r.title) }, { key: 'title:' + r._id });
      paint(['main', 'rail']);
      if (r && t.hasAttribute('data-when')) { const ch = root.querySelector('[data-whenecho]'); if (ch) ch.innerHTML = whenChips(F.get(r._id), t.value); }
    }
    if (r && t.dataset.k === 'code' && spec.file === 'places') renameCode(r, t.value.trim());
    // A posted notice's words go public when the field is left, never letter by letter.
    if (r && t.dataset.k === 'text' && spec.file === 'notices' && !r.draft && t.value !== r.text) { S.editingText = false; setRow(r._id, { text: t.value }, { repaint: ['main', 'insp'], focus: '[data-insp] [data-k="text"]' }); }
    if (r && t.dataset.k === 'phone' && (spec.id === 'nearby' || spec.id === 'numbers' || spec.id === 'help')) { const dg = digits(t.value); if (dg.length === 10) setRow(r._id, { phone: dg.slice(0, 3) + '-' + dg.slice(3, 6) + '-' + dg.slice(6) }, { repaint: ['main', 'insp'] }); }
    // A number typed on a Help card is one of the year's Numbers too (one place for each number).
    if (r && t.dataset.k === 'phone' && spec.id === 'help' && aux.contacts && digits(t.value).length >= 10 && !numberOf(t.value)) { const ph = F.get(r._id).phone; aux.contacts.add({ label: String(r.action || '').replace(/^call\s+/i, '') || r.need || 'Help', phone: ph, line: r.line || 'year', shows: 'help' }, { label: 'Add number' }); paint(['main', 'insp']); X.toast('Added to Numbers'); }
    if (r && t.dataset.k === 'label' && spec.id === 'numbers' && /call-?in/i.test(t.value)) syncCallIn(F.get(r._id));
    if (r && (t.dataset.k === 'phone' || t.dataset.k === 'pin') && spec.id === 'numbers' && /call-?in/i.test(r.label || '')) syncCallIn(F.get(r._id));
  });
  // Help cards that carry their own numbers: those numbers, moved into Numbers once (kept on the cards).
  function moveNumbers() {
    const loose = F.rows.filter(r => digits(r.phone).length >= 10 && !numberOf(r.phone));
    const seen = new Set();
    aux.contacts.batch('Move ' + plural(loose.length, 'number'), () => loose.forEach(r => { const d = digits(r.phone); if (seen.has(d)) return; seen.add(d); aux.contacts.add({ label: String(r.action || '').replace(/^call\s+/i, '') || r.need, phone: r.phone, line: r.line || 'year', shows: 'help' }, {}); }));
    paint(['main', 'insp']);
    X.toast('Moved ' + plural(seen.size, 'number') + ' to Numbers', ['Undo', () => { aux.contacts.undo(); paint(['main', 'insp']); }]);
  }
  // Post a draft notice: from its From date (today when blank). A house rule broken asks once more.
  function postNotice(r, b) {
    const flags = wordFlags(r.text);
    if (flags.length && S.postArmed !== r._id) { S.postArmed = r._id; paintInsp(); const p = root.querySelector('[data-post]'); if (p) p.focus(); X.toast(flags.join(' · ') + ' · Post anyway?'); return; }
    S.postArmed = '';
    const from = r.post_from && r.post_from > X.today ? r.post_from : X.today;
    setRow(r._id, { from, post_from: '', draft: '' }, { label: 'Post ' + spec.label(r), repaint: ['rail', 'main', 'insp'] });
    X.toast(from > X.today ? 'Posted · From ' + O.fmtDate(from, 'mdShort') : 'Posted · Showing', ['Undo', doUndo]);
  }
  // The call-in line is one number: its row here is also the year's call-in setting.
  function syncCallIn(r) { if (!r || S.ro) return; O.edits.setKey(X.year, 'settings', 'call_in_number', r.phone || ''); if (r.pin != null) O.edits.setKey(X.year, 'settings', 'call_in_pin', r.pin || ''); X.toast('Also the year’s call-in line'); }
  async function renameCode(r, to) {
    const from = r.code;
    if (!to || lc(to) === lc(from)) return;
    if (placesList().some(p => p._id !== r._id && lc(p.code) === lc(to))) { X.toast('Same code as another place'); paint(['insp']); return; }
    const u = usedBy(from);
    if (!from) { setRow(r._id, { code: to.toUpperCase() }, { repaint: ['main', 'insp'] }); return; }
    try {
      await ED.api('POST', 'years/' + X.year + '/recode', { map: { [from]: to.toUpperCase() }, rename: true });
      await Promise.all([F.load(), aux.schedule && aux.schedule.load(), aux.shifts && aux.shifts.load()]);
      paint(['main', 'insp']);
      X.toast('Renamed ' + from + ' to ' + to.toUpperCase() + (u.n ? ' · ' + plural(u.n, 'row') : ''), ['Undo', async () => { await ED.api('POST', 'years/' + X.year + '/recode', { map: { [to.toUpperCase()]: from }, rename: true }); await Promise.all([F.load(), aux.schedule && aux.schedule.load(), aux.shifts && aux.shifts.load()]); paint(['main', 'insp']); }]);
    } catch (e) { X.toast('Couldn’t rename · ' + (e.message || 'Retry')); }
  }
  async function applyMap() {
    const map = {}; Object.keys(S.map || {}).forEach(c => { if (S.map[c]) map[c] = S.map[c]; });
    if (!Object.keys(map).length) return;
    try {
      await ED.api('POST', 'years/' + X.year + '/recode', { map });
      await Promise.all([aux.schedule && aux.schedule.load(), aux.shifts && aux.shifts.load()]);
      S.map = {}; paint(['main']);
      X.toast('Places chosen · ' + plural(Object.keys(map).length, 'code'));
    } catch (e) { X.toast('Couldn’t apply · ' + (e.message || 'Retry')); }
  }

  /* ---- the Where type-ahead */

  function comboOpen(inp) {
    const box = inp.closest('[data-combo]'), ul = box.querySelector('.ed-list');
    ul.innerHTML = placeOptions(inp.value, box.dataset.combo);
    ul.hidden = !ul.children.length; inp.setAttribute('aria-expanded', String(!ul.hidden));
    S.comboAt = -1;
  }
  root.addEventListener('focusin', e => { if (e.target.dataset && e.target.dataset.placein != null) comboOpen(e.target); });
  root.addEventListener('focusout', e => {
    const inp = e.target;
    if (!inp.dataset || inp.dataset.placein == null) return;
    setTimeout(() => {
      const box = inp.closest('[data-combo]');
      if (!box || box.contains(document.activeElement)) return;
      const ul = box.querySelector('.ed-list'); ul.hidden = true; inp.setAttribute('aria-expanded', 'false');
      // Half-typed text is never saved as a place: it goes back to what's chosen.
      const r = S.sel && F.get(S.sel), k = box.dataset.combo;
      if (r && k !== 'also_add' && k.indexOf('map_') !== 0) { const p = placeOf(r[k]); inp.value = p ? p.name : r[k] || ''; }
    }, 150);
  });

  // The File menu closes on a click outside it, and on Esc.
  document.addEventListener('click', e => { if (!e.target.closest || e.target.closest('.ed-file')) return; root.querySelectorAll('.ed-file__m:not([hidden])').forEach(m => { m.hidden = true; m.previousElementSibling.setAttribute('aria-expanded', 'false'); }); });
  document.addEventListener('ed:see', () => { if (spec && S) { paint(['main']); } });

  /* ---- Enter, Escape, shortcuts */

  root.addEventListener('submit', e => {
    if (!spec) return;
    const f = e.target;
    e.preventDefault();
    if (f.hasAttribute('data-findform')) { const first = visible()[0]; if (first) select(first._id, { focusInsp: true }); return; }
    if (f.hasAttribute('data-quick')) { quickAdd(f); return; }
    if (f.hasAttribute('data-pasteform')) {
      const rep = e.submitter && e.submitter.value === 'replace';
      // Replace removes rows: the button asks once more.
      if (rep && !S.replaceArmed) { S.replaceArmed = true; paint(['main'], 'button[value="replace"]'); clearTimeout(timers.arm); timers.arm = setTimeout(() => { S.replaceArmed = false; if (S.paste) paint(['main']); }, 6000); return; }
      S.replaceArmed = false; pasteApply(rep); return;
    }
    if (f.hasAttribute('data-addgroup')) { const v = f.querySelector('[data-newgroup]').value.trim(); if (!v) return; addGroup(v); return; }
    if (f.hasAttribute('data-renameform')) { renameGroup(f.querySelector('[data-renamein]').value.trim()); return; }
    if (f.hasAttribute('data-notify')) { saveNotify(f.querySelector('[data-notifyin]').value); }
  });
  function quickAdd(f) {
    const inp = f.querySelector('[data-quickin]'), res = R.line(inp.value, readCtx(S.group)), r = res.row;
    if (!r.title) { const e2 = root.querySelector('[data-quickecho]'); if (e2) e2.innerHTML = inp.value.trim() ? '<span class="ed-chip is-warn">What is it? · Like 10–11:30 Worship, Chapel</span>' : ''; inp.focus(); return; }
    // No time read: said where it was typed, never added as "All day" by surprise.
    if (!r.start && !/\ball day\b/i.test(inp.value)) { const e2 = root.querySelector('[data-quickecho]'); if (e2) e2.innerHTML = quickEcho(inp.value); inp.focus(); return; }
    if (S.flipQuick && r.start && R.minutes(r.start) != null) { r.start = R.store(R.minutes(r.start) + 720); if (R.minutes(r.end) != null) r.end = R.store(R.minutes(r.end) + 720); res.guess = ''; }
    if (!r.note) delete r.note;
    if (R.guessKind(r.title)) r.kind = R.guessKind(r.title);
    if (res.guess) r._guess = '1';
    const row = Object.assign(spec.blank(r.day), r);
    const id = F.add(row, { label: 'Add ' + r.title });
    S.sel = id; S.flipQuick = false;
    flash(id);
    if (r.day !== S.group) goGroup(r.day, { keepSel: true });
    inp.value = '';
    paint(['rail', 'main', 'insp'], '[data-quickin]');
    X.toast('Added ' + r.title + (res.guess ? ' · Time guessed' : ''), ['Undo', doUndo]);
  }
  function pasteApply(replace) {
    const res = S.pasteRes || R.paste(S.pasteText || '', readCtx(S.group));
    if (!res.rows.length) return;
    const incoming = res.rows.map(x => Object.assign(x.row, x.guess ? { _guess: '1' } : {}));
    const days = uniq(incoming.map(r => r.day));
    const cmp = ED.files.compare(incoming, F.rows, { key: SPECS.schedule.key, name: SPECS.schedule.name, scope: SPECS.schedule.scope, fields: SPECS.schedule.compareFields });
    F.batch(replace ? 'Replace ' + days.join(', ') : 'Paste ' + plural(incoming.length, 'row'), () => {
      if (replace) {
        // Rows that match keep their id, call-in, kind and pinned sermons; the rest of those days go.
        const keep = new Set(cmp.same.map(r => r._id).concat(cmp.changed.map(c => c.row._id)));
        F.rows.filter(r => days.indexOf(r.day) > -1 && !keep.has(r._id)).forEach(r => F.remove(r._id, {}));
      }
      cmp.changed.forEach(c => { const f = {}; c.fields.forEach(k => { f[k] = c.now[k]; }); F.set(c.row._id, f, {}); });
      cmp.added.forEach(r => { if (!r.kind && R.guessKind(r.title)) r.kind = R.guessKind(r.title); F.add(Object.assign(spec.blank(r.day), r), {}); });
    });
    S.paste = false; S.pasteText = ''; S.pasteRes = null; S.sel = '';
    if (days.indexOf(S.group) < 0 && days[0]) goGroup(days[0]); else paint(['rail', 'main', 'insp'], '[data-quickin]');
    X.toast((replace ? 'Replaced ' + days.join(', ') : 'Added ' + plural(cmp.added.length, 'row')) + (cmp.same.length ? ' · ' + cmp.same.length + ' already there' : ''), ['Undo', doUndo]);
  }
  function addGroup(name) {
    if (spec.groups().some(g => lc(g.id) === lc(name))) { goGroup(spec.groups().find(g => lc(g.id) === lc(name)).id); return; }
    S.extraGroups = (S.extraGroups || []).concat([name]);
    if (aux.committees && !aux.committees.rows.some(c => lc(c.name) === lc(name))) aux.committees.add({ name, heads: '', weekly: 'yes' }, { label: 'Add ' + name });
    goGroup(name);
    addRow(spec.blank(name), { focus: '[data-insp] [data-fk="role"]' });
  }
  function renameGroup(to) {
    const g = S.group;
    if (!to || to === g) { S.renaming = false; paint(['main']); return; }
    F.batch('Rename ' + g, () => F.rows.filter(r => r.committee === g).forEach(r => F.set(r._id, { committee: to }, {})));
    const c = aux.committees && aux.committees.rows.find(x => x.name === g);
    if (c) aux.committees.set(c._id, { name: to }, {});
    S.extraGroups = (S.extraGroups || []).map(x => x === g ? to : x);
    S.renaming = false; goGroup(to);
    X.toast('Renamed to ' + to, ['Undo', () => { doUndo(); if (c) aux.committees.undo(); goGroup(g); }]);
  }
  function saveNotify(v) {
    const g = S.group, list = String(v || '').split(/[\s,;]+/).map(x => x.trim().toLowerCase()).filter(Boolean);
    const bad = list.filter(x => !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(x));
    if (bad.length) { X.toast(bad[0] + ' isn’t an email address'); return; }
    if (!aux.committees) return;
    const c = aux.committees.rows.find(x => x.name === g);
    if (c) aux.committees.set(c._id, { heads: list.join('|') }, { label: 'Notify for ' + g });
    else aux.committees.add({ name: g, heads: list.join('|'), weekly: 'yes' }, { label: 'Notify for ' + g });
    paint(['main']);
    X.toast(list.length ? 'Saved · ' + g + ' heads are told' : 'Cleared');
  }

  // Shortcuts work only from the list (a row, a block, the rail, the page), never from a field or a
  // button in the details: N adds, ⌘D duplicates, Delete removes (with Undo), / finds, Esc lets go.
  document.addEventListener('keydown', e => {
    if (!spec || !S) return;
    const a = document.activeElement || document.body, typing = /^(INPUT|TEXTAREA|SELECT)$/.test(a.tagName) || a.isContentEditable;
    const inInsp = a.closest && a.closest('[data-insp]');
    const onList = a === document.body || (a.closest && (a.closest('tr[data-id]') || a.closest('[data-ev]') || a.closest('.ed-rail__b') || a.matches('[data-main]')));
    const mod = e.metaKey || e.ctrlKey;
    if (document.querySelector('dialog[open]')) return;
    // The Where list: ↑↓ and Enter.
    if (a.dataset && a.dataset.placein != null && /^(ArrowDown|ArrowUp|Enter|Escape)$/.test(e.key)) {
      const ul = a.closest('[data-combo]').querySelector('.ed-list'), items = Array.from(ul.children);
      if (e.key === 'Escape') { ul.hidden = true; return; }
      if (ul.hidden && e.key !== 'Enter') { comboOpen(a); return; }
      e.preventDefault();
      if (e.key === 'Enter') { const it = items[S.comboAt] || items[0]; if (it && a.value.trim()) choosePlace(it); return; }
      S.comboAt = Math.max(0, Math.min(items.length - 1, (S.comboAt == null ? -1 : S.comboAt) + (e.key === 'ArrowDown' ? 1 : -1)));
      items.forEach((it, i) => it.setAttribute('aria-selected', String(i === S.comboAt)));
      if (items[S.comboAt]) { a.setAttribute('aria-activedescendant', items[S.comboAt].id); items[S.comboAt].scrollIntoView({ block: 'nearest' }); }
      return;
    }
    if (e.key === 'Enter' && a.classList && (a.classList.contains('ed-line') || (spec.file === 'notices' && a.dataset.k === 'text'))) { e.preventDefault(); a.dispatchEvent(new Event('change', { bubbles: true })); return; }
    if (mod && e.key.toLowerCase() === 'z' && !typing) { e.preventDefault(); doUndo(e.shiftKey); return; }
    if (mod && e.key.toLowerCase() === 'y' && !typing) { e.preventDefault(); doUndo(true); return; }
    if (e.key === 'Escape') {
      const fm = root.querySelector('.ed-file__m:not([hidden])');
      if (fm) { fm.hidden = true; fm.previousElementSibling.setAttribute('aria-expanded', 'false'); fm.previousElementSibling.focus(); return; }
      if (a.dataset && a.dataset.find != null && a.value) { clearFind(); return; }
      if (S.paste) { S.paste = false; paint(['main'], '[data-quickin]'); return; }
      if (S.multi.size) { S.multi.clear(); paint(['main']); return; }
      if (S.sel) { e.preventDefault(); closeInsp(); return; }
      if (S.q) { clearFind(); return; }
      return;
    }
    if (a.dataset && a.dataset.find != null && (e.key === 'ArrowDown')) { e.preventDefault(); const tr = root.querySelector('tr[data-id]'); if (tr) select(tr.dataset.id); return; }
    if (typing || inInsp) return;
    if (mod && e.key.toLowerCase() === 'a' && onList && spec.groups) { e.preventDefault(); visible().forEach(r => S.multi.add(r._id)); S.sel = ''; paint(['main', 'insp']); return; }
    if (mod && e.key.toLowerCase() === 'd' && S.sel) { e.preventDefault(); duplicate(S.sel); return; }
    if (mod || !onList) return;
    if (e.key === '/') { e.preventDefault(); const f = root.querySelector('[data-find]'); if (f) f.focus(); return; }
    if (e.key === '?') { e.preventDefault(); keysSheet(); return; }
    if ((e.key === 'n' || e.key === 'N') && !S.ro && !e.altKey) { e.preventDefault(); if (spec.addLine && S.group && S.group[0] !== '@') { const q = root.querySelector('[data-quickin]'); if (q) q.focus(); } else addRow(spec.blank(S.group)); return; }
    if (e.key === 'Delete' && S.sel && !S.ro) { e.preventDefault(); removeRow(S.sel); return; }
    const tr = a.closest && a.closest('tr[data-id]');
    if (tr && !e.altKey && (e.key === 'ArrowDown' || e.key === 'ArrowUp')) {
      e.preventDefault();
      const rows = Array.from(root.querySelectorAll('tr[data-id]')), i = rows.indexOf(tr), next = rows[Math.max(0, Math.min(rows.length - 1, i + (e.key === 'ArrowDown' ? 1 : -1)))];
      if (next) { if (e.shiftKey) toggleMulti(next.dataset.id, true); else select(next.dataset.id); }
      return;
    }
    if (tr && (e.key === 'Enter' || e.key === ' ')) { e.preventDefault(); select(tr.dataset.id, { focusInsp: true }); const f = root.querySelector('[data-insp] [data-fk]'); if (f) f.focus(); return; }
    const ev = a.closest && a.closest('[data-ev]');
    if (ev && (e.key === 'Enter' || e.key === ' ')) { e.preventDefault(); select(ev.dataset.ev, { focusInsp: true }); return; }
    // Alt and the arrows: move a row among those at the same time; in Day view, nudge a block 5 minutes
    // (Shift: its end) or move it to the next column.
    if (e.altKey && /^Arrow/.test(e.key) && !S.ro) {
      if (ev) { e.preventDefault(); nudge(ev.dataset.ev, e.key, e.shiftKey); return; }
      if (tr && (e.key === 'ArrowUp' || e.key === 'ArrowDown')) {
        e.preventDefault();
        const rows = Array.from(root.querySelectorAll('tr[data-id]')), i = rows.indexOf(tr), next = rows[i + (e.key === 'ArrowUp' ? -1 : 1)];
        const r = F.get(tr.dataset.id), n = next && F.get(next.dataset.id);
        if (n && (!spec.sort || spec.sort(r) === spec.sort(n))) { F.move(r._id, e.key === 'ArrowUp' ? n._id : (F.rows[F.rows.indexOf(n) + 1] || {})._id || ''); paint(['main'], '[data-id="' + CSS.escape(r._id) + '"]'); }
        else X.toast(spec.sort ? 'Same time only · The list keeps time order' : '');
      }
    }
  });
  function nudge(id, key, end) {
    const r = F.get(id), s = tspan(r);
    if (!s) return;
    if (key === 'ArrowLeft' || key === 'ArrowRight') { const li = Math.max(0, Math.min(LANES.length - 1, laneOf(r) + (key === 'ArrowLeft' ? -1 : 1))); setRow(id, { audience: LANES[li][0] }, { key: 'nudge:' + id, repaint: ['main', 'insp'], focus: '[data-ev="' + CSS.escape(id) + '"]' }); return; }
    const d = key === 'ArrowUp' ? -5 : 5;
    const f = end ? { end: R.store(Math.max(s.a + 5, s.b + d)) } : { start: R.store(s.a + d), end: s.open ? r.end : R.store(s.b + d) };
    setRow(id, Object.assign(f, { _guess: '' }), { key: 'nudge:' + id, repaint: ['main', 'insp'], focus: '[data-ev="' + CSS.escape(id) + '"]' });
  }

  function keysSheet() {
    let dlg = document.querySelector('dialog.ed-keys');
    if (!dlg) { dlg = document.createElement('dialog'); dlg.className = 'ogc wk-sheet ed-keys'; dlg.setAttribute('aria-labelledby', 'ed-keys-h'); document.body.appendChild(dlg); dlg.addEventListener('click', e => { if (e.target === dlg || e.target.closest('[data-x]')) dlg.close(); }); }
    const k = [['N', 'Add'], ['⌘D', 'Duplicate'], ['Delete', 'Remove (with Undo)'], ['⌘Z', 'Undo'], ['⇧⌘Z', 'Redo'], ['/', 'Find'], ['↑ ↓', 'Next row'], ['Enter', 'Open the row'], ['Esc', 'Close'], ['Shift-click', 'Choose several'], ['⌘A', 'Choose every row'], ['Alt ↑ ↓', 'Move a row (same time) · In Day view, 5 minutes'], ['Alt ← →', 'Day view: another column']];
    dlg.innerHTML = '<div class="wk-sheet__in"><button type="button" class="wk-sheet__x" data-x aria-label="Close">' + I.close + '</button><h2 class="wk-sheet__h" id="ed-keys-h">Shortcuts</h2><dl class="ed-keylist">' + k.map(x => '<div><dt><kbd>' + esc(x[0]) + '</kbd></dt><dd>' + esc(x[1]) + '</dd></div>').join('') + '</dl>' +
      (spec.file === 'schedule' ? '<h3 class="ed-h3">Day view</h3><p class="ed-hint">Drag a block to move it · Drag its bottom edge to change when it ends · Double-click an empty place to add</p>' : '') + '</div>';
    dlg.showModal();
  }

  /* ---- Day view: drag a block (5-minute steps), across to another column, or its bottom edge */

  let pd = null;
  root.addEventListener('pointerdown', e => {
    const el = e.target.closest('[data-ev].tl-ev');
    if (!el || e.button !== 0 || S.ro) return;
    const r = F.get(el.dataset.ev), s = r && tspan(r);
    if (!s) return;
    pd = { id: r._id, el, x0: e.clientX, y0: e.clientY, mode: e.target.closest('.tl-resize') ? 'end' : 'move', s, lane: laneOf(r), to: laneOf(r), d: 0, moved: false, cols: Array.from(root.querySelectorAll('.tl-col')) };
    try { el.setPointerCapture(e.pointerId); } catch (x) { /* gone */ }
  });
  root.addEventListener('pointermove', e => {
    if (!pd) return;
    const dx = e.clientX - pd.x0, dy = e.clientY - pd.y0;
    if (!pd.moved && Math.abs(dx) < 4 && Math.abs(dy) < 4) return;
    pd.moved = true; pd.el.classList.add('is-moving');
    pd.d = Math.round(dy / S.px / 5) * 5;
    const t = pd.el.querySelector('.tl-t');
    if (pd.mode === 'end') { const b = Math.max(pd.s.a + 5, pd.s.b + pd.d); pd.el.style.height = Math.max(22, (b - pd.s.a) * S.px - 2) + 'px'; t.textContent = R.span(pd.s.a, b); }
    else {
      const k = pd.cols.findIndex(c => { const b = c.getBoundingClientRect(); return e.clientX >= b.left && e.clientX < b.right; });
      if (k > -1) pd.to = k;
      const shift = pd.cols[pd.to].getBoundingClientRect().left - pd.cols[pd.lane].getBoundingClientRect().left;
      pd.el.style.transform = 'translate(' + shift + 'px,' + pd.d * S.px + 'px)';
      t.textContent = R.span(pd.s.a + pd.d, pd.s.open ? null : pd.s.b + pd.d) + (pd.to !== pd.lane ? ' · ' + LANES[pd.to][1] : '');
    }
  });
  root.addEventListener('pointerup', () => {
    if (!pd) return;
    const p = pd; pd = null;
    if (!p.moved) return;
    const r = F.get(p.id);
    const f = p.mode === 'end' ? { end: R.store(Math.max(p.s.a + 5, p.s.b + p.d)) } : Object.assign(p.d ? { start: R.store(p.s.a + p.d), end: p.s.open ? r.end : R.store(p.s.b + p.d) } : {}, { audience: LANES[p.to][0] });
    S.sel = p.id;
    setRow(p.id, Object.assign(f, { _guess: '' }), { label: 'Move ' + spec.label(r), repaint: ['main', 'insp'], focus: '[data-ev="' + CSS.escape(p.id) + '"]' });
    X.toast('Moved ' + spec.label(r), ['Undo', doUndo]);
  });
  // Double-click an empty place in a column: a new row there, an hour long.
  root.addEventListener('dblclick', e => {
    const col = e.target.closest('.tl-col');
    if (!col || e.target.closest('[data-ev], [data-goto]') || S.ro) return;
    const at = Math.round((S.dayStart + (e.clientY - col.getBoundingClientRect().top) / S.px) / 15) * 15;
    addRow(Object.assign(spec.blank(S.group), { audience: LANES[+col.dataset.lane][0], start: R.store(at), end: R.store(at + 60) }), { focus: '[data-insp] [data-fk="title"]' });
  });

  /* ---- dragging rows: onto a day or a committee in the rail, or among rows at the same time */

  let drag = null;
  root.addEventListener('dragstart', e => {
    const tr = e.target.closest && e.target.closest('tr[data-id]');
    if (!tr || S.ro) return;
    drag = { id: tr.dataset.id };
    e.dataTransfer.effectAllowed = 'move'; e.dataTransfer.setData('text/plain', drag.id);
    setTimeout(() => tr.classList.add('is-dragging'), 0);
  });
  function dropAt(e) {
    if (!drag) return null;
    const rail = e.target.closest('[data-group]');
    if (rail && spec.groups && rail.dataset.group !== S.group && rail.dataset.group[0] !== '@') return { el: rail, group: rail.dataset.group };
    const tr = e.target.closest('tr[data-id]');
    if (!tr || tr.dataset.id === drag.id) return null;
    const a = F.get(drag.id), b = F.get(tr.dataset.id);
    if (!a || !b || (spec.sort && spec.sort(a) !== spec.sort(b))) return null;
    const box = tr.getBoundingClientRect(); return { el: tr, to: b._id, after: e.clientY > box.top + box.height / 2 };
  }
  const clearDrop = () => root.querySelectorAll('.is-drop-before, .is-drop-after, .is-drop, .is-dragging').forEach(el => el.classList.remove('is-drop-before', 'is-drop-after', 'is-drop', 'is-dragging'));
  root.addEventListener('dragover', e => {
    if (e.dataTransfer && Array.from(e.dataTransfer.types || []).indexOf('Files') > -1 && !S.ro) { e.preventDefault(); root.classList.add('is-dropfile'); return; }
    const at = dropAt(e);
    root.querySelectorAll('.is-drop-before, .is-drop-after, .is-drop').forEach(el => { if (!at || el !== at.el) el.classList.remove('is-drop-before', 'is-drop-after', 'is-drop'); });
    if (!at) return;
    e.preventDefault();
    if (at.group) at.el.classList.add('is-drop'); else { at.el.classList.toggle('is-drop-before', !at.after); at.el.classList.toggle('is-drop-after', at.after); }
  });
  root.addEventListener('dragleave', e => { if (!root.contains(e.relatedTarget)) root.classList.remove('is-dropfile'); });
  root.addEventListener('drop', e => {
    root.classList.remove('is-dropfile');
    if (e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files.length && !S.ro) { e.preventDefault(); importFile(e.dataTransfer.files[0]); return; }
    const at = dropAt(e), d = drag;
    clearDrop(); drag = null;
    if (!at || !d) return;
    e.preventDefault();
    const r = F.get(d.id);
    if (at.group) {
      const f = spec.file === 'schedule' ? { day: at.group, last_day: r.last_day && dayIx(r.last_day) > dayIx(at.group) ? r.last_day : '' } : { committee: at.group };
      setRow(d.id, f, { label: 'Move ' + spec.label(r) + ' to ' + at.group, repaint: ['rail', 'main', 'insp'] });
      X.toast('Moved to ' + at.group, ['Undo', doUndo]);
    } else {
      const before = at.after ? (F.rows[F.rows.findIndex(x => x._id === at.to) + 1] || {})._id || '' : at.to;
      F.move(d.id, before, { label: 'Move ' + spec.label(r) });
      paint(['main'], '[data-id="' + CSS.escape(d.id) + '"]');
    }
  });
  root.addEventListener('dragend', () => { clearDrop(); drag = null; });

  /* ================================================================ files */

  function doExport() {
    const all = spec.groups && !S.q ? F.rows : visible();
    const cols = spec.exp;
    const rows = all.slice().sort((a, b) => (spec.file === 'schedule' ? dayIx(a.day) - dayIx(b.day) : 0) || (spec.sort ? (spec.sort(a) < spec.sort(b) ? -1 : spec.sort(a) > spec.sort(b) ? 1 : 0) : 0)).map(r => cols.map(c => typeof c[1] === 'function' ? c[1](r) : val(r, c[1])));
    ED.files.download(X.year + ' ' + spec.title + (S.q ? ' (' + S.q.trim() + ')' : '') + '.csv', cols.map(c => c[0]), rows);
    X.toast('Exported');
  }
  function exportRooms() {
    const out = [];
    F.rows.forEach(r => {
      if (!r.place || R.minutes(r.start) == null) return;
      const a = dayIx(r.day), b = r.last_day ? dayIx(r.last_day) : a;
      for (let i = a; i <= b && i > -1; i++) [r.place].concat(String(r.also || '').split('|')).filter(Boolean).forEach(c => { const p = placeOf(c) || { name: c, building: '' }; out.push([p.building || p.name, p.name, c, X.days[i].name, X.days[i].date, R.fmt(R.minutes(r.start)), r.end && R.minutes(r.end) != null ? R.fmt(R.minutes(r.end)) : '', r.title, audLabel(r.audience), r.display === 'private' ? 'Committees only' : '']); });
    });
    out.sort((x, y) => (x[2] + x[4] + x[5]).localeCompare(y[2] + y[4] + y[5]));
    ED.files.download(X.year + ' Rooms booked.csv', ['Building', 'Room', 'Code', 'Day', 'Date', 'From', 'To', 'What', 'For', 'Shown'], out);
  }
  root.addEventListener('change', e => {
    if (e.target.matches('[data-file]') && e.target.files[0]) { importFile(e.target.files[0]); e.target.value = ''; }
  });
  async function importFile(file) {
    if (S.ro) return;
    let read;
    try { read = await ED.files.read(file); } catch (e) { X.toast(e.message || 'Couldn’t read the file'); return; }
    const other = (file.name.match(/\b(20\d\d)\b/) || [])[1];
    let incoming = [], unread = [];
    if (spec.file === 'schedule') {
      const text = read.text || read.grid.map(r => r.join('\t')).join('\n');
      const res = R.paste(text, readCtx(S.group));
      incoming = res.rows.map(x => Object.assign(x.row, x.guess ? { _guess: '1' } : {})); unread = res.unread;
    } else {
      const grid = read.grid.filter(r => r.some(c => String(c).trim()));
      const head = (grid.shift() || []).map(h => { const n = lc(h).replace(/^﻿/, ''); const hit = spec.exp.find(c => lc(c[0]) === n || (typeof c[1] === 'string' && lc(c[1]) === n)); return hit && typeof hit[1] === 'string' ? hit[1] : (n === 'id' ? '_id' : ''); });
      if (!head.filter(Boolean).length) { X.toast('No columns read · Export first for the layout'); return; }
      incoming = grid.map(c => { const o = {}; head.forEach((k, i) => { if (k && c[i] != null) o[k] = R.unsafe(c[i]).trim(); }); return o; }).filter(o => Object.keys(o).some(k => k !== '_id' && o[k]));
    }
    if (!incoming.length) { X.toast('Nothing read in ' + file.name); return; }
    const cmp = ED.files.compare(incoming, F.rows, { key: spec.key, name: spec.name, scope: spec.scope, fields: spec.compareFields, people: r => signedUp(r) });
    S.importing = { file: file.name, cmp, unread, other: other && other !== X.year ? other : '' };
    S.sel = ''; paint(['main', 'insp']);
    const h = root.querySelector('.ed-import h2'); if (h) { h.setAttribute('tabindex', '-1'); h.focus(); }
  }
  function applyImport() {
    const im = S.importing, c = im.cmp, on = k => { const b = root.querySelector('[data-imp="' + k + '"]'); return b && b.checked; };
    let n = 0;
    F.batch('Import ' + im.file, () => {
      c.changed.forEach((x, i) => { if (!on('c' + i)) return; const f = {}; x.fields.forEach(k => { f[k] = x.now[k]; }); F.set(x.row._id, f, {}); n++; });
      c.added.forEach((r, i) => { if (!on('a' + i)) return; const row = Object.assign(spec.blank(r.day || r.committee || ''), r); delete row._id; F.add(row, {}); n++; });
      c.removed.forEach((x, i) => { if (!on('r' + i)) return; F.remove(x.row._id, {}); n++; });
    });
    S.importing = null; S.lastImport = 'From ' + im.file + ' · ' + plural(n, 'change');
    paint(['rail', 'main', 'insp']);
  }

  ED.table = { open, SPECS, timeText };
})();
