/*
 * tournaments.js — the Young Folks tournaments (lists area).
 *
 *   (default)     the tournaments: when and where (from the published schedule), team sizes, when
 *                 sign-ups open and close, Sign up. Open ones first; closed ones fold to a line.
 *   ?view=mine    My teams: change, withdraw (with Undo), add to a calendar
 *   ?view=teams   the committee's list (members): every team with its captain's phone, flags,
 *                 Add team, Remove, No-show, Message teams, Print, Download
 *
 * Every rule is held on the server (includes/module-tournaments.php); this page only shows them early.
 * Nobody's names reach a visitor: the public answer carries counts only.
 */
(function () {
  'use strict';
  const O = window.OGC, esc = O.esc, W = window.OGC_WP || {}, SU = O.signups;
  const root = document.getElementById('ogc-tn');
  const q = new URLSearchParams(location.search);
  const ASOF = q.get('as-of') || '';
  const DRAFT_KEY = 'ogc-tn-draft';
  const yearOf = () => q.get('year') || String((W.member || []).slice().sort().pop() || new Date().getFullYear());
  const state = { year: yearOf(), view: q.get('view') || '', d: null, teams: null, only: '', panel: '', open: {} };

  const svg = d => '<svg class="wk-i" viewBox="0 0 24 24" aria-hidden="true"><path d="' + d + '" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  const I = {
    cal: svg('M7.5 3.5v3M16.5 3.5v3M4 9.5h16M5.5 5.5h13A1.5 1.5 0 0 1 20 7v11.5a1.5 1.5 0 0 1-1.5 1.5h-13A1.5 1.5 0 0 1 4 18.5V7a1.5 1.5 0 0 1 1.5-1.5Z'),
    pin: svg('M12 20.5s-6.5-5.4-6.5-10.8a6.5 6.5 0 0 1 13 0c0 5.4-6.5 10.8-6.5 10.8ZM12 12a2.3 2.3 0 1 0 0-4.6 2.3 2.3 0 0 0 0 4.6Z'),
    people: svg('M9 11a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7ZM2.5 20c0-3.6 2.9-6 6.5-6s6.5 2.4 6.5 6M16 4.3a3.5 3.5 0 0 1 0 6.4M18 14.4c2.1.7 3.5 2.7 3.5 5.6'),
    check: svg('m5.5 12.5 4 4 9-9'),
    close: svg('m6.5 6.5 11 11M17.5 6.5l-11 11'),
    down: svg('M12 4v10.5M7.5 10 12 14.5 16.5 10M5 19.5h14'),
    print: svg('M7 9V4h10v5M7 17H5a1.5 1.5 0 0 1-1.5-1.5v-5A1.5 1.5 0 0 1 5 9h14a1.5 1.5 0 0 1 1.5 1.5v5A1.5 1.5 0 0 1 19 17h-2M7 14h10v6H7z'),
    back: svg('M14.5 5.5 8 12l6.5 6.5'),
    chev: svg('m6 9 6 6 6-6'),
    mail: svg('M4 6.5h16v11H4zM4.5 7l7.5 6 7.5-6'),
    plus: svg('M12 5v14M5 12h14')
  };

  const api = (m, p, b) => W.api(m, p, b);
  const withAsOf = p => ASOF ? p + (p.indexOf('?') > -1 ? '&' : '?') + 'as_of=' + encodeURIComponent(ASOF) : p;
  const live = document.createElement('p');
  live.className = 'ogc-sr';
  live.setAttribute('aria-live', 'polite');
  root.after(live);
  const say = t => { live.textContent = ''; setTimeout(() => { live.textContent = t; }, 30); };
  const href = (view, extra) => '?' + new URLSearchParams(Object.assign({ year: state.year }, view ? { view } : {}, ASOF ? { 'as-of': ASOF } : {}, extra || {})).toString();
  const plural = (n, one, many) => n + ' ' + (n === 1 ? one : (many || one + 's'));
  const firstL = n => { const w = String(n || '').trim().split(/\s+/); return w.length > 1 ? w[0] + ' ' + w[w.length - 1].charAt(0) + '.' : w[0]; };
  const tag = (t, cls) => '<span class="tn-tag' + (cls ? ' tn-tag--' + cls : '') + '">' + esc(t) + '</span>';
  const blank = (h, more) => '<section class="ws-blank tn-blank"><p class="ws-blank__h">' + esc(h) + '</p>' + (more || '') + '</section>';
  const find = id => state.d.list.find(t => t.id === id);
  const telOf = p => { const d = String(p || '').replace(/[^\d+]/g, ''); return d ? 'tel:' + (d.length === 10 ? '+1' + d : d) : ''; };

  /* ---------------------------------------------------------------- words for times */

  const now = () => state.d.now;
  // Before the week a close is always a date ("Fri, May 28, noon"); during the week "today" or the day.
  function closeWords(c) {
    if (!c) return '';
    const n = now(), t = O.formatTime(c.min, { words: true });
    const time = c.min >= 1439 ? 'end of day' : t;
    if (c.date === n.date) return 'today, ' + time;
    const inWeek = state.d.start && n.date >= state.d.start && n.date <= state.d.end;
    return (inWeek ? O.fmtDate(c.date, 'weekdayShort') : O.fmtDate(c.date, 'short')) + ', ' + time;
  }
  function sizeWords(t) {
    if (t.max === 1) return 'On your own';
    if (t.solo && t.max === 2) return 'On your own or with a partner';
    const team = t.team_min === t.max ? 'Teams of ' + t.max : 'Teams of ' + t.team_min + ' to ' + t.max;
    return t.solo ? team + ', or on your own' : team;
  }
  function countWords(c, max) {
    if (!c || !(c.teams + c.alone)) return '';
    if (max === 1) return plural(c.alone, 'player');
    return [c.teams ? plural(c.teams, 'team') : '', c.alone ? c.alone + ' on their own' : ''].filter(Boolean).join(' · ');
  }
  const whenLine = it => O.fmtDate(it.date, 'short') + ', ' + it.when;
  const places = t => Array.from(new Set(t.items.filter(it => it.place).map(it => it.place)));

  /* ---------------------------------------------------------------- loading */

  async function load() {
    try {
      if (q.get('signin')) {
        // (An emailed link signs in through the sign-in page now; this address only drops the old query.)
        q.delete('signin');
        history.replaceState(null, '', '?' + q.toString());
      }
      const preview = q.get('preview') ? '?preview=1' : '';
      state.d = await api('GET', withAsOf('tn/' + state.year + preview));
      if (state.view === 'teams') state.teams = await api('GET', withAsOf('tn/' + state.year + '/teams'));
      render();
      resume();
    } catch (err) {
      if (err.status === 401 || err.status === 403) {
        const to = (window.OGC_AUTH && OGC_AUTH.signinUrl()) || W.signin || '../signin/';
        // Signed in but not this year's: say so, with no sign-in button (another link wouldn't help).
        const other = err.status === 403 && W.me;
        root.innerHTML = '<div class="wk tn ws">' + bar('Tournament teams') + '<div class="ws-body ws-body--page">' + (other ? blank('Not a member for ' + state.year, '') : blank(err.status === 401 ? 'Signed out' : 'Members only', '<p class="ws-blank__btn"><a class="wk-btn" href="' + esc(to) + '">Email me a link</a></p>')) + '</div></div>';
      } else {
        root.innerHTML = '<div class="wk tn"><section class="wk-main"><div class="wk-wrap">' + blank('Couldn’t load', '<p class="ws-blank__btn"><button type="button" class="wk-btn wk-btn--line" data-retry>Retry</button></p>') + '</div></section></div>';
      }
      console.error(err);
    }
  }

  /* ---------------------------------------------------------------- the public page */

  function render() {
    if (state.view === 'teams') return renderTeams();
    const d = state.d, mine = d.mine.filter(m => m.status === 'active');
    const title = state.view === 'mine' ? 'My teams' : 'Young Folks tournaments';
    const span = d.start ? O.fmtDateSpan(d.start, d.end).replace(/, \d{4}$/, d.over ? ', ' + state.year : '') : '';
    const facts = state.view === 'mine' ? '' : '<p class="tn-facts">' + [span, d.venue, d.over ? 'Over' : 'Young Folks only'].filter(Boolean).map(esc).join('<span aria-hidden="true"> · </span>') + '</p>';
    const links = [state.view ? '<a href="' + esc(href('')) + '">All tournaments</a>' : '', state.view !== 'mine' && mine.length ? '<a href="' + esc(href('mine')) + '">My teams · ' + mine.length + '</a>' : '', d.member ? '<a href="' + esc(href('teams')) + '">Teams</a>' : ''].filter(Boolean).join('');
    const head = '<header class="wk-hero tn-hero"><div class="wk-wrap"><p class="wk-kicker">' + esc(state.year) + ' Annual Conference</p><h1 class="tn-title" tabindex="-1">' + title + '</h1>' + facts + (links ? '<p class="tn-links">' + links + '</p>' : '') + '</div></header>';
    let body;
    if (!d.posted && !d.draft) body = blank('Not posted yet', d.member ? '<p class="ws-blank__btn"><a class="wk-btn wk-btn--line" href="' + esc(href('', { preview: 1 })) + '">Preview</a></p>' : '');
    else if (!d.list.length) body = blank('No tournaments', '');
    else body = state.view === 'mine' ? mineView() : listView();
    root.innerHTML = '<div class="wk tn">' + head + '<section class="wk-main tn-main"><div class="wk-wrap">' + (d.draft ? '<p class="tn-draft">' + tag('Draft · Not posted', 'blue') + ' Members only</p>' : '') + body + '</div></section></div>';
    document.title = title + ' – ' + state.year + ' Annual Conference – Old German Baptist Brethren Church, New Conference';
  }

  function listView() {
    const d = state.d;
    if (d.over) return '<div class="tn-cards">' + d.list.map(t => '<article class="wk-hcard tn-card"><h3>' + esc(t.name) + '</h3>' + whenList(t) + '</article>').join('') + '</div>';
    if (!d.online) {
      return (d.how ? '<p class="tn-how">' + esc(d.how) + '</p>' : '') +
        '<div class="tn-cards">' + d.list.map(t => '<article class="wk-hcard tn-card"><h3>' + esc(t.name) + '</h3>' + whenList(t, true) + (t.note ? '<p class="tn-note">' + esc(t.note) + '</p>' : '') + '</article>').join('') + '</div>';
    }
    const rank = { open: 0, soon: 1, full: 2, closed: 3 };
    const list = d.list.slice().sort((a, b) => rank[a.state] - rank[b.state]);
    const shut = list.filter(t => t.state === 'closed'), on = list.filter(t => t.state !== 'closed');
    return (on.length ? '<div class="tn-cards">' + on.map(card).join('') + '</div>' : '') +
      (shut.length ? '<h2 class="tn-h2">Closed</h2><ul class="tn-shut">' + shut.map(t => '<li><b>' + esc(t.name) + '</b><span>' + esc(t.items[0] ? whenLine(t.items[0]) : '') + '</span><span>' + esc(['Closed', countWords(t.counts, t.max)].filter(Boolean).join(' · ')) + '</span>' + (mineOf(t).length ? '<a href="' + esc(href('mine')) + '">My teams</a>' : '') + '</li>').join('') + '</ul>' : '');
  }
  const mineOf = t => state.d.mine.filter(m => m.tid === t.id && m.status === 'active');

  function whenList(t, withSize) {
    const ps = places(t);
    return '<ul class="tn-when">' + t.items.map(it => '<li>' + I.cal + '<span>' + esc(O.fmtDate(it.date, 'long')) + ', ' + esc(it.when) + (ps.length > 1 && it.place ? ' · ' + esc(it.place) : '') + (it.note ? '<small>' + esc(it.note) + '</small>' : '') + '</span></li>').join('') +
      (ps.length === 1 ? '<li>' + I.pin + '<span>' + esc(ps[0]) + '</span></li>' : '') +
      (withSize ? '<li>' + I.people + '<span>' + esc(sizeWords(t)) + '</span></li>' : '') + '</ul>';
  }

  function card(t) {
    const mine = mineOf(t), c = countWords(t.counts, t.max);
    const line = t.state === 'soon' ? 'Opens ' + O.fmtDate(t.opens, 'mdShort') + (t.closes ? ' · Closes ' + closeWords(t.closes) : '')
      : t.state === 'full' ? 'Full' : t.closes ? 'Closes ' + closeWords(t.closes) : 'Open';
    const action = mine.length ? '<span class="tn-me">' + I.check + 'Signed up</span><a class="tn-quiet" href="' + esc(href('mine')) + '">My teams</a>'
      : t.state === 'open' ? '<button type="button" class="wk-btn wk-btn--line" data-signup="' + esc(t.id) + '">Sign up</button>' : '';
    return '<article class="wk-hcard tn-card"><div class="tn-top"><h3>' + esc(t.name) + '</h3>' + whenList(t, true) +
      (t.clash.length ? '<p class="tn-fact">Same time as ' + esc(t.clash.map(u => u.name).join(' and ')) + '</p>' : '') +
      (t.note ? '<p class="tn-note">' + esc(t.note) + '</p>' : '') + '</div>' +
      '<p class="tn-close' + (t.state === 'full' ? ' is-closed' : '') + '">' + esc(line) + (c ? '<span>' + esc(c) + '</span>' : '') + '</p>' +
      (action ? '<p class="wk-hcard__btn">' + action + '</p>' : '') + '</article>';
  }

  function mineView() {
    const list = state.d.mine.filter(m => m.status === 'active').map(m => ({ m, t: find(m.tid) })).filter(x => x.t);
    if (!list.length) return blank('No teams', '<p class="ws-blank__btn"><a class="wk-btn wk-btn--line" href="' + esc(href('')) + '">See tournaments</a></p>');
    return '<div class="tn-mine">' + list.map(({ m, t }) => {
      const who = m.mode === 'solo' ? '<b>On your own</b><span>' + esc(m.players[0]) + '</span>' : '<b>' + esc(m.team || 'Team') + '</b><span>' + esc(m.players.map(firstL).join(', ')) + '</span>';
      const st = t.state === 'closed' ? 'Closed · Changes at the tournament' : t.closes ? 'Closes ' + closeWords(t.closes) : '';
      return '<section class="wk-hcard tn-mcard"><h3>' + esc(t.name) + '</h3>' + whenList(t) +
        '<p class="tn-team">' + who + '</p>' + (m.own ? '' : '<p class="tn-fine">Captain ' + esc(m.captain) + '</p>') +
        (st ? '<p class="tn-status">' + esc(st) + '</p>' : '') +
        '<p class="tn-acts">' + (m.can ? '<button type="button" class="tn-act" data-change="' + m.id + '">Change</button><button type="button" class="tn-act tn-act--quiet" data-withdraw="' + m.id + '">Withdraw</button>' : '') +
        '<button type="button" class="wk-btn wk-btn--line wk-btn--small" data-ics="' + m.id + '">' + I.cal + 'Add to Calendar</button></p>' +
        (m.own && m.email ? '<p class="tn-fine">Confirmation to ' + esc(m.email) + '</p>' : '') + '</section>';
    }).join('') + '</div>';
  }

  /* ---------------------------------------------------------------- the sign-up sheet */

  const sheet = document.createElement('dialog');
  sheet.className = 'ogc wk-sheet tn-sheet';
  sheet.setAttribute('aria-labelledby', 'tn-sheet-t');
  document.body.appendChild(sheet);

  // f: what's typed so far (a change, a draft kept across signing in, or nothing).
  function openSignup(tid, rec, f) {
    const t = find(tid), d = state.d;
    if (!t) return;
    f = f || {};
    const me = d.me || {}, last = d.mine.filter(m => m.own).slice(-1)[0] || {};
    const mode = f.mode || (rec ? rec.mode : t.max === 1 ? 'solo' : 'team');
    const other = f.for_other != null ? f.for_other : rec ? rec.for_other : false;
    const players = f.players || (rec ? rec.players : [other ? '' : (me.name && me.name.indexOf('@') < 0 ? me.name : '')]);
    const n = mode === 'solo' ? 1 : t.max;
    const label = i => i === 0 ? (other ? 'Player 1' : 'Your name') : t.max === 2 && mode === 'team' ? (other ? 'Partner' : 'Your partner') : 'Player ' + (i + 1);
    const ps = t.items.filter(it => it.code).filter((it, i, a) => a.findIndex(x => x.code === it.code) === i);
    sheet.innerHTML = '<form class="wk-sheet__in tn-form" data-form="' + esc(t.id) + '"' + (rec ? ' data-edit="' + rec.id + '"' : '') + ' novalidate>' +
      '<button type="button" class="wk-sheet__x" data-close aria-label="Close">' + I.close + '</button>' +
      '<p class="wk-kicker">Young Folks tournament</p><h2 class="wk-sheet__h" id="tn-sheet-t">' + esc(t.name) + '</h2>' +
      '<p class="tn-err" role="alert" hidden></p>' +
      '<ul class="tn-when tn-when--sheet">' + t.items.map(it => '<li>' + I.cal + '<span>' + esc(O.fmtDate(it.date, 'long')) + ', ' + esc(it.when) + (it.note ? '<small>' + esc(it.note) + '</small>' : '') + '</span></li>').join('') +
        ps.map(it => '<li>' + I.pin + '<span>' + esc(it.place) + ' <a class="tn-quiet" href="' + esc(W.url('../guide/?year=' + encodeURIComponent(state.year) + '&view=places&to=' + encodeURIComponent(it.code))) + '">Directions</a></span></li>').join('') +
        '<li>' + I.people + '<span>' + esc(sizeWords(t)) + (t.closes ? '<small>Closes ' + esc(closeWords(t.closes)) + '</small>' : '') + '</span></li></ul>' +
      clashMine(t, rec) +
      (t.max > 1 && t.solo ? '<fieldset class="tn-mode"><legend class="ogc-sr">Sign up as</legend>' + [['team', 'Team'], ['solo', 'On my own']].map(o => '<label class="tn-pill"><input type="radio" name="mode" value="' + o[0] + '"' + (mode === o[0] ? ' checked' : '') + '><span>' + o[1] + '</span></label>').join('') + '</fieldset>' : '') +
      '<div class="tn-fields">' +
        '<fieldset class="tn-players"><legend class="ogc-sr">Players</legend>' + Array.from({ length: n }, (_, i) =>
          '<label class="tn-field"><span>' + label(i) + '</span><input name="p" autocomplete="' + (i === 0 && !other ? 'name' : 'off') + '" maxlength="60" value="' + esc(players[i] || '') + '"' + (i < (mode === 'solo' ? 1 : t.team_min) ? ' required' : '') + '></label>').join('') +
          (mode === 'team' && t.team_min < t.max ? '<small>' + esc(t.team_min + ' to ' + t.max + ' players') + '</small>' : '') + '</fieldset>' +
        (mode === 'team' ? '<label class="tn-field"><span>Team name</span><input name="team" maxlength="40" autocomplete="off" placeholder="Optional" value="' + esc(f.team != null ? f.team : rec ? rec.team : '') + '"></label>' : '') +
        (mode === 'team' && t.rule ? '<label class="tn-check"><input type="checkbox" name="rule"' + (f.rule || rec ? ' checked' : '') + '><span>' + esc(t.rule) + '</span></label>' : '') +
        '<label class="tn-field"><span>' + (other ? 'Your phone' : 'Phone') + '</span><input name="phone" type="tel" autocomplete="tel" maxlength="24" required value="' + esc(f.phone || (rec ? rec.phone : last.phone) || '') + '"></label>' +
        (mode === 'team' ? '<label class="tn-field"><span>Teammates’ emails</span><input name="mates" autocomplete="off" placeholder="Optional" value="' + esc((f.mates || (rec ? rec.mates : []) || []).join(', ')) + '"><small>They get the confirmation · Only you can change the team</small></label>' : '') +
        (state.d.me ? '<p class="tn-fact">Confirmation to ' + esc(state.d.me.email) + '</p>' : '<label class="tn-field"><span>Your email</span><input name="email" type="email" autocomplete="email" required value="' + esc(f.email || '') + '"><small>A code comes by email · No password</small></label>') +
        (rec ? '' : '<label class="tn-check tn-check--quiet"><input type="checkbox" name="for_other"' + (other ? ' checked' : '') + '><span>For someone else</span></label>') +
      '</div>' +
      '<p class="tn-foot"><button type="submit" class="wk-btn">' + (rec ? 'Save' : 'Sign up') + '</button></p></form>';
    if (!sheet.open) sheet.showModal();
    const first = sheet.querySelector('input[name=p]');
    if (first && !first.value) first.focus();
  }
  function clashMine(t, rec) {
    const on = t.clash.map(u => find(u.id)).filter(u => u && mineOf(u).some(m => !rec || m.id !== rec.id));
    return on.length ? '<p class="tn-fact tn-fact--warn">On ' + esc(on.map(u => u.name).join(' and ')) + ' · Same time <a class="tn-quiet" href="' + esc(href('mine')) + '">My teams</a></p>' : '';
  }
  function readForm(f) {
    const v = n => (f.elements[n] && f.elements[n].value ? f.elements[n].value : '').trim();
    const mode = (f.querySelector('[name=mode]:checked') || {}).value || (find(f.dataset.form).max === 1 ? 'solo' : 'team');
    return {
      tid: f.dataset.form, mode,
      players: Array.from(f.querySelectorAll('[name=p]')).map(i => i.value.trim()).filter(Boolean),
      team: v('team'), phone: v('phone'), email: v('email'),
      rule: !!(f.elements.rule && f.elements.rule.checked),
      for_other: !!(f.elements.for_other && f.elements.for_other.checked),
      mates: v('mates').split(/[\s,;]+/).filter(Boolean)
    };
  }
  function sheetError(msg, field) {
    const p = sheet.querySelector('.tn-err');
    if (p) { p.hidden = false; p.textContent = msg; p.scrollIntoView({ block: 'nearest' }); }
    const map = { players: '[name=p]', rule: '[name=rule]', phone: '[name=phone]', mates: '[name=mates]', email: '[name=email]' };
    const el = field && sheet.querySelector(map[field] || '[name=' + field + ']');
    if (el) { el.setAttribute('aria-invalid', 'true'); el.focus(); }
  }
  // The browser's own checks first, said in the sheet's words.
  function precheck(t, x) {
    if (!x.players.length) return ['Add ' + (x.for_other ? 'a name' : 'your name'), 'players'];
    if (x.mode === 'team' && (x.players.length < t.team_min || x.players.length > t.max)) return [t.team_min === t.max ? 'A team has ' + t.max : 'A team has ' + t.team_min + ' to ' + t.max, 'players'];
    if (x.mode === 'team' && t.rule && !x.rule) return ['Check the rule', 'rule'];
    if (String(x.phone).replace(/\D/g, '').length < 7) return ['A phone number', 'phone'];
    if (!state.d.me && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(x.email)) return ['An email', 'email'];
    return null;
  }

  async function submit(f) {
    const t = find(f.dataset.form), x = readForm(f), btn = f.querySelector('[type=submit]');
    const bad = precheck(t, x);
    if (bad) { sheetError(bad[0], bad[1]); return; }
    if (!state.d.me) { askCode(t, x); return; }
    btn.disabled = true;
    const was = btn.textContent;
    btn.textContent = f.dataset.edit ? 'Saving…' : 'Signing up…';
    try {
      const out = f.dataset.edit ? await api('PUT', withAsOf('tn/r/' + f.dataset.edit), x) : await api('POST', withAsOf('tn/' + state.year + '/teams'), x);
      const i = state.d.mine.findIndex(m => m.id === out.item.id);
      if (i > -1) state.d.mine[i] = out.item; else state.d.mine.push(out.item);
      done(t, out.item, !!f.dataset.edit, out.warn || []);
      // The counts come from the server again.
      api('GET', withAsOf('tn/' + state.year)).then(r => { state.d = r; render(); }).catch(() => {});
    } catch (err) {
      btn.disabled = false;
      btn.textContent = was;
      sheetError(err.status === 429 ? 'Too many · Try later' : err.message || 'Not saved · Retry', err.data && err.data.data && err.data.data.field);
    }
  }

  // Not signed in: a code by email (no password), then on with the sign-up. The code is the register
  // site's one sign-in (auth/send with for=register, then auth/code; register polish 2), which reaches an
  // address the site doesn't know yet.
  async function askCode(t, x) {
    const ret = location.origin + location.pathname + href(state.view);
    try {
      await api('POST', 'auth/send', { email: x.email, for: 'register', typos_ok: 1, return: ret });
    } catch (err) { sheetError(err.status === 429 ? 'Too many codes · Try later' : err.message, 'email'); return; }
    try { sessionStorage.setItem(DRAFT_KEY, JSON.stringify(Object.assign({ at: Date.now() }, x))); } catch (e) { /* kept in the sheet only */ }
    state.pending = x;
    sheet.innerHTML = '<form class="wk-sheet__in tn-form" data-code novalidate><button type="button" class="wk-sheet__x" data-close aria-label="Close">' + I.close + '</button>' +
      '<p class="wk-kicker">' + esc(t.name) + '</p><h2 class="wk-sheet__h" id="tn-sheet-t">Check your email</h2><p class="tn-err" role="alert" hidden></p>' +
      '<p class="tn-fact">Code sent to ' + esc(x.email) + '</p>' +
      '<label class="tn-field"><span>Code</span><input name="code" inputmode="numeric" autocomplete="one-time-code" pattern="[0-9 ]*" maxlength="9" required></label>' +
      '<p class="tn-foot"><button type="submit" class="wk-btn">Continue</button></p></form>';
    sheet.querySelector('[name=code]').focus();
  }
  async function sendCode(f) {
    const b = f.querySelector('[type=submit]'), x = state.pending;
    b.disabled = true;
    try {
      const out = await api('POST', 'auth/code', { code: f.elements.code.value.trim() });
      signedIn({ nonce: out.nonce, me: { email: x.email, name: x.for_other ? '' : x.players[0] } });
      try { sessionStorage.removeItem(DRAFT_KEY); } catch (e) { /* fine */ }
      openSignup(x.tid, null, x);
      submit(sheet.querySelector('form'));
    } catch (err) { b.disabled = false; sheetError(err.message || 'Wrong code', 'code'); }
  }
  // Signed in on this device: this person's own nonce from here on.
  function signedIn(out) {
    if (out && out.nonce) W.nonce = out.nonce;
    if (out && out.me) { W.me = out.me; state.d.me = out.me; }
  }
  // After signing in: the draft kept for a few minutes reopens and is sent.
  function resume() {
    let x = null;
    try { x = JSON.parse(sessionStorage.getItem(DRAFT_KEY) || 'null'); sessionStorage.removeItem(DRAFT_KEY); } catch (e) { x = null; }
    if (!x || !state.d.me || Date.now() - x.at > 15 * 60e3 || !find(x.tid)) return;
    openSignup(x.tid, null, x);
    submit(sheet.querySelector('form'));
  }

  function done(t, rec, changed, warn) {
    sheet.innerHTML = '<div class="wk-sheet__in tn-done"><button type="button" class="wk-sheet__x" data-close aria-label="Close">' + I.close + '</button>' +
      '<p class="tn-tick">' + I.check + '</p><h2 class="wk-sheet__h" id="tn-sheet-t">' + (changed ? 'Saved' : 'Signed up') + '</h2>' +
      '<p class="wk-sheet__when">' + esc(t.name) + (t.items[0] ? ' · ' + esc(whenLine(t.items[0])) : '') + '</p>' +
      '<p class="tn-team">' + (rec.mode === 'solo' ? '<b>On your own</b>' : '<b>' + esc(rec.team || 'Team') + '</b>') + '<span>' + esc(rec.players.join(', ')) + '</span></p>' +
      (warn.length ? '<p class="tn-fact tn-fact--warn">' + warn.map(esc).join('<br>') + '</p>' : '') +
      '<p class="wk-sheet__btns"><button type="button" class="wk-btn wk-btn--line" data-ics="' + rec.id + '">' + I.cal + 'Add to Calendar</button><a class="tn-quiet" href="' + esc(href('mine')) + '">My teams</a></p>' +
      '<p class="tn-fine">Confirmation to ' + esc(rec.email) + (t.closes ? ' · Changes until ' + esc(closeWords(t.closes)) : '') + '</p>' +
      '<p class="tn-foot"><button type="button" class="wk-btn" data-close>Done</button></p></div>';
    say((changed ? 'Saved: ' : 'Signed up: ') + t.name);
    const b = sheet.querySelector('.tn-foot .wk-btn');
    if (b) b.focus();
  }

  // Withdraw: on your own, at once with Undo; a team asks first, naming who's on it.
  function askWithdraw(m) {
    const t = find(m.tid);
    sheet.innerHTML = '<div class="wk-sheet__in"><button type="button" class="wk-sheet__x" data-close aria-label="Close">' + I.close + '</button>' +
      '<h2 class="wk-sheet__h" id="tn-sheet-t">Withdraw ' + esc(m.team || 'the team') + '?</h2><p class="wk-sheet__when">' + esc(t.name) + ' · ' + esc(m.players.map(firstL).join(', ')) + '</p>' +
      (m.mates && m.mates.length ? '<p class="tn-fine">Teammates with an email are told</p>' : '') +
      '<p class="tn-foot"><button type="button" class="wk-btn wk-btn--alert" data-withdraw-yes="' + m.id + '">Withdraw</button><button type="button" class="tn-act" data-close>Cancel</button></p></div>';
    if (!sheet.open) sheet.showModal();
    sheet.querySelector('[data-close].tn-act').focus();
  }
  async function withdraw(id) {
    try {
      const r = await api('DELETE', withAsOf('tn/r/' + id));
      if (sheet.open) sheet.close();
      state.d = await api('GET', withAsOf('tn/' + state.year));
      if (state.view === 'teams') state.teams = await api('GET', withAsOf('tn/' + state.year + '/teams'));
      render();
      toast(r.say, id);
    } catch (err) { toast(err.message); }
  }
  async function restore(id) {
    try {
      const r = await api('POST', 'tn/r/' + id + '/restore');
      state.d = await api('GET', withAsOf('tn/' + state.year));
      if (state.view === 'teams') state.teams = await api('GET', withAsOf('tn/' + state.year + '/teams'));
      render();
      toast(r.say);
    } catch (err) { toast(err.message); }
  }
  function toast(text, undo) {
    let t = document.getElementById('tn-toast');
    if (t) t.remove();
    t = document.createElement('div');
    t.id = 'tn-toast';
    t.className = 'ogc tn-toast';
    t.setAttribute('role', 'status');
    t.innerHTML = '<span>' + esc(text) + '</span>' + (undo ? '<button type="button" data-restore="' + esc(undo) + '">Undo</button>' : '');
    document.body.appendChild(t);
    requestAnimationFrame(() => t.classList.add('is-on'));
    clearTimeout(toast.timer);
    toast.timer = setTimeout(() => { t.classList.remove('is-on'); setTimeout(() => t.remove(), 300); }, undo ? 8000 : 3500);
    if (undo) t.querySelector('button').focus();
  }

  // The tournament as calendar events, one per schedule row; a row with no clock time has no end.
  function downloadIcs(id) {
    const m = state.d.mine.find(x => String(x.id) === String(id)), t = m && find(m.tid);
    if (!t) return;
    const ev = t.items.filter(it => it.start != null).map(it => ({
      uid: 'yf-' + m.id + '-' + it.date, date: it.date, start: it.start, end: it.end != null ? it.end : it.start + 60,
      summary: t.name + ' tournament' + (m.team ? ': ' + m.team : ''),
      location: [it.place, state.d.venue].filter(Boolean).join(', '),
      description: [it.note, 'Players: ' + m.players.join(', '), state.year + ' Annual Conference · My teams on ogbbc.org'].filter(Boolean).join('\n')
    }));
    SU.save(SU.ics(ev, state.d.tz), 'text/calendar', 'young-folks-' + t.id + '-' + state.year + '.ics');
  }

  /* ---------------------------------------------------------------- the committee's list */

  function bar(title) {
    const b = W.url('../year/?year=' + encodeURIComponent(state.year) + '&part=youngfolks');
    return '<header class="ws-bar ws-bar--page"><div class="ws-bar__in"><a class="ws-back" href="' + esc(b) + '">' + I.back + '<span>Young Folks</span></a>' +
      '<div class="ws-title"><p class="wk-kicker">' + esc(state.year) + ' Annual Conference' + (state.teams && state.teams.owner ? ' · ' + esc(state.teams.owner) : '') + '</p><h1 tabindex="-1">' + esc(title) + '</h1></div></div></header>';
  }
  function renderTeams() {
    document.documentElement.classList.add('adm-full');
    const T = state.teams, d = state.d;
    // Their own way: only tournaments the committee has typed teams into (no empty sign-up lists).
    const shown = T.list.filter(t => (!state.only || t.id === state.only) && (T.online || T.teams.some(x => x.tid === t.id)));
    const active = T.teams.filter(x => x.status === 'active');
    const n = T.now, asOf = 'As of ' + O.fmtDate(n.date, 'mdShort') + ', ' + O.formatTime(n.min);
    let body = '';
    if (T.cleared) body += '<p class="tn-status-line"><b>Counts only</b> · Cleared ' + esc(O.fmtDate(T.cleared, 'mdShort')) + '</p>';
    else body += '<p class="tn-status-line">' + esc(asOf) + (T.posted ? '' : ' · ' + 'Not posted') + '</p>';
    if (!T.online) {
      body += '<section class="tn-own"><p><b>Their own way</b> · Not on the site</p>' +
        '<form class="tn-inline" data-form-how><label class="tn-field"><span>Sign-up line</span><input name="how" maxlength="160" value="' + esc(T.how) + '" placeholder="At the Young Folks welcome, Friday 6:30"><small>Shown above the tournaments</small></label><p class="tn-foot"><button type="submit" class="wk-btn wk-btn--line wk-btn--small">Save</button></p></form></section>';
    }
    const pills = T.online && T.list.length > 1 ? '<div class="tn-filter" role="group" aria-label="Tournament">' + [['', 'All']].concat(T.list.map(t => [t.id, t.name])).map(p => '<button type="button" data-only="' + esc(p[0]) + '" aria-pressed="' + (state.only === p[0]) + '">' + esc(p[1]) + '</button>').join('') + '</div>' : '';
    const tools = '<p class="tn-tools">' + (T.cleared ? '' : '<button type="button" class="wk-btn wk-btn--small" data-panel="add">' + I.plus + 'Add team</button>') +
      '<button type="button" class="tn-act" data-print>' + I.print + 'Print</button><button type="button" class="tn-act" data-csv>' + I.down + 'Download</button>' +
      (active.length && !T.cleared ? '<button type="button" class="tn-act" data-panel="message">' + I.mail + 'Message teams</button>' : '') + '</p>';
    body += pills + tools + panel() + (shown.length ? '' : blank('No teams on the site', '')) +
      '<div class="tn-lists">' + shown.map(t => {
        const list = T.teams.filter(x => x.tid === t.id).sort((a, b) => (a.status === 'active' ? 0 : 1) - (b.status === 'active' ? 0 : 1)), live = list.filter(x => x.status === 'active');
        const cw = countWords(t.counts, t.max);
        return '<section class="tn-lsec"><div class="tn-lhead"><h2 class="tn-lh">' + esc(t.name) + '</h2>' +
          '<p class="tn-lwhen">' + esc(t.items.map(whenLine).join(' · ')) + (places(t).length ? ' · ' + esc(places(t).join(', ')) : '') + '</p>' +
          '<p class="tn-lcount">' + esc([cw || 'No one yet', sizeWords(t), t.state === 'closed' ? 'Closed' : t.closes ? 'Closes ' + closeWords(t.closes) : '', t.max_teams ? 'Most ' + t.max_teams : ''].filter(Boolean).join(' · ')) + '</p>' +
          (t.close_set === false ? '<p class="tn-lcount">' + tag('Close not set', 'alert') + ' Closes when it starts</p>' : '') + '</div>' +
          (T.cleared ? '' : live.length || list.length ? '<ol class="tn-teams">' + list.map(teamRow).join('') + '</ol>' : '') + '</section>';
      }).join('') + '</div>';
    root.innerHTML = '<div class="wk tn ws">' + bar('Tournament teams') + '<div class="ws-body ws-body--page tn-body">' + body +
      '<p class="tn-more"><a href="' + esc(href('')) + '">The sign-up page</a><a href="' + esc(W.url('../lists/?year=' + encodeURIComponent(state.year))) + '">Lists</a></p></div></div>';
    document.title = 'Tournament teams – ' + state.year + ' Annual Conference';
  }
  function teamRow(x) {
    const gone = x.status !== 'active';
    // A team with no name is its players (never a made-up "Ruth T.'s team").
    const label = x.mode === 'solo' ? x.players[0] : x.team || x.players.join(', ');
    const tags = [x.late ? tag('Late') : '', x.no_show ? tag('No-show', 'alert') : '', gone ? tag(x.status === 'removed' ? 'Removed' : 'Withdrawn', 'alert') : '', x.sample ? '' : ''].join(' ');
    return '<li class="' + (gone ? 'is-gone' : '') + '"><div><b>' + esc(label) + '</b> ' + tags +
      '<span>' + (x.mode === 'solo' ? 'On their own' : x.team ? esc(x.players.join(', ')) : 'Team') + (x.rule ? ' · Rule ✓' : '') + '</span>' +
      (x.flags.length ? '<span class="tn-flag">' + x.flags.map(esc).join('<br>') + '</span>' : '') +
      '<span class="tn-cap">Captain ' + esc(firstL(x.players[0])) + (x.phone ? ' · <a href="' + esc(telOf(x.phone)) + '">' + esc(x.phone) + '</a>' : '') + (x.email ? ' · <a href="mailto:' + esc(x.email) + '">Email</a>' : '') + '</span></div>' +
      (gone ? '<p class="tn-racts"><button type="button" class="tn-act" data-restore="' + x.id + '">Restore</button></p>'
        : '<p class="tn-racts"><button type="button" class="tn-act" data-noshow="' + x.id + '" aria-pressed="' + x.no_show + '">No-show</button><button type="button" class="tn-act tn-act--quiet" data-remove="' + x.id + '">Remove</button></p>') + '</li>';
  }
  function panel() {
    const T = state.teams;
    if (state.panel === 'add') {
      const tid = state.only || (T.list[0] || {}).id;
      return '<form class="tn-panel" data-form-add><h2 class="tn-h3">Add team</h2>' +
        '<fieldset class="tn-field"><legend>Tournament</legend><span class="tn-pills">' + T.list.map(t => '<label class="tn-pill"><input type="radio" name="tid" value="' + esc(t.id) + '"' + (t.id === tid ? ' checked' : '') + '><span>' + esc(t.name) + '</span></label>').join('') + '</span></fieldset>' +
        '<fieldset class="tn-field"><legend>Kind</legend><span class="tn-pills"><label class="tn-pill"><input type="radio" name="mode" value="team" checked><span>Team</span></label><label class="tn-pill"><input type="radio" name="mode" value="solo"><span>On their own</span></label></span></fieldset>' +
        '<label class="tn-field"><span>Players</span><input name="players" placeholder="One name, or names with commas" autocomplete="off"></label>' +
        '<label class="tn-field"><span>Team name</span><input name="team" placeholder="Optional" autocomplete="off"></label>' +
        '<label class="tn-field"><span>Phone</span><input name="phone" type="tel" placeholder="Optional" autocomplete="off"></label>' +
        '<label class="tn-field"><span>Email</span><input name="email" type="email" placeholder="Optional" autocomplete="off"></label>' +
        '<p class="tn-err" role="alert" hidden></p><p class="tn-foot"><button type="submit" class="wk-btn wk-btn--small">Add</button><button type="button" class="tn-act" data-panel="">Cancel</button></p></form>';
    }
    if (state.panel === 'message') {
      const t = state.only ? T.list.find(x => x.id === state.only) : null;
      return '<form class="tn-panel" data-form-msg><h2 class="tn-h3">Message ' + esc(t ? t.name : 'every tournament') + '</h2><p class="tn-fine" data-msg-count></p>' +
        '<label class="tn-field"><span>Subject</span><input name="subject" maxlength="120" required></label>' +
        '<label class="tn-field"><span>Message</span><textarea name="body" rows="5" maxlength="3000" required></textarea></label>' +
        '<p class="tn-err" role="alert" hidden></p><p class="tn-foot"><button type="submit" class="wk-btn wk-btn--small">' + I.mail + 'Send</button><button type="button" class="tn-act" data-panel="">Cancel</button></p></form>';
    }
    return '';
  }
  async function downloadCsv() {
    const res = await fetch((W.rest || '/wp-json/ogc/v1/') + withAsOf('tn/' + state.year + '/teams?format=csv' + (state.only ? '&tid=' + encodeURIComponent(state.only) : '')), { credentials: 'same-origin', headers: { 'X-WP-Nonce': W.nonce || '' } });
    if (!res.ok) { toast('Download failed'); return; }
    const m = /filename="([^"]+)"/.exec(res.headers.get('Content-Disposition') || '');
    SU.save(await res.text(), 'text/csv', m ? m[1] : 'teams-' + state.year + '.csv');
  }
  async function reloadTeams() {
    state.teams = await api('GET', withAsOf('tn/' + state.year + '/teams'));
    render();
  }

  /* ---------------------------------------------------------------- events */

  root.addEventListener('click', async e => {
    const b = e.target.closest('button');
    if (!b) return;
    const d = b.dataset;
    if (d.retry != null) { load(); return; }
    if (d.signup) { openSignup(d.signup); return; }
    if (d.ics) { downloadIcs(d.ics); return; }
    if (d.change) { const m = state.d.mine.find(x => String(x.id) === d.change); if (m) openSignup(m.tid, m); return; }
    if (d.withdraw) {
      const m = state.d.mine.find(x => String(x.id) === d.withdraw);
      if (!m) return;
      if (m.mode === 'solo') withdraw(m.id); else askWithdraw(m);
      return;
    }
    if (d.only != null) { state.only = d.only; render(); const a = root.querySelector('[data-only="' + CSS.escape(state.only) + '"]'); if (a) a.focus(); return; }
    if (d.print != null) { window.print(); return; }
    if (d.csv != null) { downloadCsv(); return; }
    if (d.panel != null) {
      state.panel = state.panel === d.panel ? '' : d.panel;
      render();
      const f = root.querySelector('.tn-panel input:not([type=radio]), .tn-panel textarea');
      if (f) f.focus();
      if (state.panel === 'message') api('POST', 'tn/' + state.year + '/message', { tid: state.only, preview: 1 }).then(r => { const c = root.querySelector('[data-msg-count]'); if (c) c.textContent = 'To ' + plural(r.count, 'email'); }).catch(() => {});
      return;
    }
    if (d.noshow) { try { await api('PATCH', 'tn/r/' + d.noshow + '/flag', { no_show: d.noshow && b.getAttribute('aria-pressed') !== 'true' }); await reloadTeams(); const a = root.querySelector('[data-noshow="' + d.noshow + '"]'); if (a) a.focus(); } catch (err) { toast(err.message); } return; }
    if (d.remove) { withdraw(d.remove); return; }
    if (d.restore) { restore(d.restore); }
  });
  document.addEventListener('click', e => { const u = e.target.closest('.tn-toast [data-restore]'); if (u) restore(u.dataset.restore); });
  sheet.addEventListener('click', e => {
    if (e.target === sheet || e.target.closest('[data-close]')) { sheet.close(); return; }
    const c = e.target.closest('[data-ics]');
    if (c) downloadIcs(c.dataset.ics);
    const w = e.target.closest('[data-withdraw-yes]');
    if (w) withdraw(w.dataset.withdrawYes);
  });
  // Team · On my own, and For someone else, redraw the sheet keeping what's typed.
  sheet.addEventListener('change', e => {
    if (e.target.name === 'mode' || e.target.name === 'for_other') {
      const f = e.target.form, x = readForm(f), rec = f.dataset.edit ? state.d.mine.find(m => String(m.id) === f.dataset.edit) : null;
      openSignup(f.dataset.form, rec, x);
      const again = sheet.querySelector('[name=' + e.target.name + ']' + (e.target.name === 'mode' ? '[value=' + e.target.value + ']' : ''));
      if (again) again.focus();
    }
  });
  sheet.addEventListener('input', e => { if (e.target.getAttribute('aria-invalid')) e.target.removeAttribute('aria-invalid'); });
  sheet.addEventListener('submit', e => {
    e.preventDefault();
    if (e.target.hasAttribute('data-code')) sendCode(e.target); else submit(e.target);
  });
  root.addEventListener('submit', async e => {
    e.preventDefault();
    const f = e.target, err = f.querySelector('.tn-err');
    const fail = x => { if (err) { err.hidden = false; err.textContent = x.message; } else toast(x.message); };
    try {
      if (f.hasAttribute('data-form-how')) {
        await api('PATCH', 'years/' + state.year + '/files/settings', { op: 'key', key: 'tournaments_how', value: f.elements.how.value.trim() });
        toast('Saved');
        await reloadTeams();
      } else if (f.hasAttribute('data-form-add')) {
        const r = await api('POST', withAsOf('tn/' + state.year + '/add'), { tid: (f.querySelector('[name=tid]:checked') || {}).value, mode: (f.querySelector('[name=mode]:checked') || {}).value, players: f.elements.players.value.split(',').map(s => s.trim()).filter(Boolean), team: f.elements.team.value, phone: f.elements.phone.value, email: f.elements.email.value });
        state.panel = '';
        await reloadTeams();
        toast(r.say + (r.warn && r.warn.length ? ' · ' + r.warn[0] : ''));
      } else if (f.hasAttribute('data-form-msg')) {
        const r = await api('POST', 'tn/' + state.year + '/message', { tid: state.only, subject: f.elements.subject.value, body: f.elements.body.value });
        state.panel = '';
        render();
        toast(r.say);
      }
    } catch (x) { fail(x); }
  });
  document.addEventListener('keydown', e => { if (e.key === 'Escape' && state.panel) { state.panel = ''; render(); } });

  load();
})();
