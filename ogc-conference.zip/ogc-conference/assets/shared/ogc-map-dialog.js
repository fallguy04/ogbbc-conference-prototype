/*
 * ogc-map-dialog.js — a place, in a dialog that stands alone (docs/34 §5.2, W4; Nov 5).
 *
 * The Conference page never shows the Conference app. A place named on it (a row's room, a service's
 * place, an event sheet's small map before the week) opens this dialog; so does a volunteer shift's small
 * map before the week, so the sign-up is never left. One function for both pages:
 *
 *   O.map.placeDialog(code, { year, opener, room })   code: a places.csv code ("B/HW"), or "care:<slug>"
 *                                                       for care nearby (§4.12); room: { floor, number },
 *                                                       one of the place's rooms by its number (the
 *                                                       Chapel's balcony)
 *   O.map.placeDialog.use(fn)                          the page says what it knows: fn() → ctx or null
 *   O.map.placeDialog.close()
 *
 * ctx: { year, member, places, campus() → Promise({ c, places }) | null, rows() → [{ id, code, title,
 * day ("Sat"), time ("10:00 AM"), at (minutes from the first day, for the order), past }], openRow(id, opener) (the Conference page: the event's sheet)
 * or rowHref(id) (the volunteer page: the Conference page's), dirs(p) → href or '' (only from a week
 * before, as the Conference page's one Conference app pill), care: nearby.csv's rows }.
 *
 * Laptop (960 and up): 880 wide, the picture 520 × 420 on the left, the place on the right. Between 768
 * and 959 one column, the picture 16:9 on top. A phone: a bottom sheet, the picture on top at 16:9.
 * The picture is the campus map to move (⌘-scroll or two fingers: the viewer's cooperative mode) with
 * the year's floor plans on it where the place is in the public build: its floor open, the room in tan,
 * the line from the best door (the same drawing as the small maps), its own floor picker. A place with
 * no plan gets today's campus mini in the same frame; an outdoor place its pin; a care place no map.
 *
 * Mechanical (docs/25): the door, its line and Nearby come from the router's and the build's fixed rules;
 * nothing is guessed or read from notes. Nothing here reads a private file: the build is the public one.
 * Esc, × and a tap outside close it; Back closes it (one history entry, ?place=CODE, so the address opens
 * it again); the page keeps still under it; focus stays inside and goes back where it came from.
 */
(function () {
  'use strict';
  const O = window.OGC, M = O && O.map;
  if (!M) return;
  const esc = O.esc;
  // A name with a dash ("Rooms 133 A–D", "South-west doors") never breaks at the dash.
  const nb = s => esc(s).replace(/[^\s<>]*[A-Za-z0-9][-–][A-Za-z0-9][^\s<>]*/g, m => '<span class="pl-dlg__nw">' + m + '</span>');
  const svg = d => '<svg class="pm-i" viewBox="0 0 24 24" aria-hidden="true"><path d="' + d + '" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  const I = {
    close: svg('M6.5 6.5l11 11M17.5 6.5l-11 11'),
    dirs: '<svg class="wk-i" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3.5 20.5 12 12 20.5 3.5 12ZM9.5 13.5v-2.5h4.5M12.5 9l2 2-2 2" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    next: svg('M9.5 5.5 16 12l-6.5 6.5'),
    door: svg('M6.5 20.5v-16h11v16M4 20.5h16M14.5 12.5v.01'),
    pin: '<svg class="wk-i" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 20.5s-6.5-5.4-6.5-10.8a6.5 6.5 0 0 1 13 0c0 5.4-6.5 10.8-6.5 10.8ZM12 12a2.3 2.3 0 1 0 0-4.6 2.3 2.3 0 0 0 0 4.6Z" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    phone: '<svg class="wk-i" viewBox="0 0 24 24" aria-hidden="true"><path d="M6.6 3.5h3l1.5 4-2 1.3a10.5 10.5 0 0 0 6.1 6.1l1.3-2 4 1.5v3a2 2 0 0 1-2.2 2A16.5 16.5 0 0 1 4.6 5.7a2 2 0 0 1 2-2.2Z" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/></svg>',
    right: svg('M9.5 5.5 16 12l-6.5 6.5')
  };
  const mq = q => window.matchMedia ? matchMedia(q) : { matches: false, addEventListener() {} };
  const phoneQ = mq('(max-width: 767px)'), wideQ = mq('(min-width: 960px)'), reduceQ = mq('(prefers-reduced-motion: reduce)');
  const keyOf = code => String(code || '').split('/')[0].toUpperCase();
  const later = (p, ms) => Promise.race([p, new Promise(r => setTimeout(() => r(undefined), ms))]);

  let use = null;
  // What's open: D. The map to move is made once a campus and year (V) and moved into each new drawing.
  const D = { el: null, ctx: null, year: '', code: '', room: null, care: null, opener: null, gen: 0, pushed: false, popping: false, closing: false, after: null, near: null, door: undefined, info: null };
  let V = null;

  /* ------------------------------------------------ what a place is called */

  const where = p => M.whereIs(D.c, p, D.places);
  const shorts = () => D.shorts || (D.shorts = M.shortsFor(D.c, D.places));
  const bShort = b => b ? shorts()[b.name] || M.shortOf(b) : '';
  // A room named for its building ("Piazza Terrace (Barnes)") drops the building it's in.
  const inBuilding = (p, b) => String(p.name).replace(/\s*\(([^)]+)\)$/, (m, w) => b && String(b.name).toLowerCase().indexOf(w.split(' ')[0].toLowerCase()) > -1 ? '' : m);
  const roomName = p => { const b = D.c ? where(p).b : null; return String(p.code).indexOf('/') > -1 && b ? inBuilding(p, b) : p.name; };
  // A room's name on the map, without its building ("PPAC Room 150" → "Room 150").
  function mapName(code) {
    const p = D.places[code]; if (!p) return code;
    if (!D.c) return p.name;
    const b = where(p).b, n = roomName(p), sh = b ? bShort(b) : '';
    const lead = [sh, b ? b.name : ''].filter(Boolean).find(w => n.toLowerCase().indexOf(w.toLowerCase() + ' ') === 0);
    return lead ? n.slice(lead.length + 1) : n;
  }
  const doorRow = id => (D.c && D.c.doors || []).find(d => d.id === id) || null;
  // A place in the build: its building and its rooms there ([] for a whole building); with a room asked
  // for by its number, that room alone, named as IWU names it (the Chapel's "Balcony").
  function planOf(p, room) {
    const P = D.P;
    if (!P || !p) return null;
    const rooms = P.roomsOf(p.code), B = P.by[keyOf(p.code)];
    if (!rooms || !B || !B.ok) return null;
    const pl = { code: B.code, B, rooms, place: String(p.code).toUpperCase(), name: '' };
    if (!room || room.number == null) return pl;
    const f = P.got(B.code, +room.floor), x = f && f._by[String(room.number)];
    if (B.floors.indexOf(+room.floor) < 0) return pl;
    return Object.assign({}, pl, { rooms: [{ floor: +room.floor, number: String(room.number) }], name: x && x.r.name ? M.floors.titleCase(x.r.name) : '', room: { floor: +room.floor, number: String(room.number) } });
  }
  // A room's name in its floor's drawing ("Balcony"), or ''.
  function roomWord(B, r) { const f = D.P && D.P.got(B.code, +r.floor), x = f && f._by[String(r.number)]; return x && x.r.name ? M.floors.titleCase(x.r.name) : ''; }
  // The floor a place is on: the build's (its first room's), else places.csv's own words.
  function floorOf(p, pl) {
    if (pl && pl.rooms.length) return M.floorName(+pl.rooms[0].floor);
    const f = String(p.floor || '');
    return !f ? '' : /^\d/.test(f) ? M.floorName(parseInt(f, 10)) : f === 'Ground' ? M.floorName(1) : f === 'Lower' ? 'Lower level' : f;
  }

  /* ------------------------------------------------ open, close, Back */

  function dialog() {
    if (D.el) return D.el;
    const el = document.createElement('dialog');
    el.className = 'ogc pl-dlg';
    el.setAttribute('aria-labelledby', 'pl-dlg-t');
    document.body.appendChild(el);
    el.addEventListener('cancel', e => { e.preventDefault(); close(); });
    el.addEventListener('click', onClick);
    // A tap on the scrim (the dialog itself, outside its card) closes it.
    el.addEventListener('pointerdown', e => { D.downOut = e.target === el; });
    grab(el);
    return (D.el = el);
  }
  function placeDialog(code, o) {
    o = o || {};
    const ctx = use ? use() : null;
    if (!ctx) return false;
    const key = String(code || '').trim(), care = /^care:/i.test(key);
    const nearby = care ? (ctx.care || []).find(n => O.slug(n.name) === O.slug(key.slice(5))) : null;
    const p = care ? null : (ctx.places || {})[key.toUpperCase()];
    if (care ? !nearby : !p) return false;
    const gen = ++D.gen, el = dialog(), was = el.open;
    D.ctx = ctx; D.year = String(o.year || ctx.year); D.care = nearby; D.code = care ? key : key.toUpperCase();
    D.room = o.room && o.room.number != null ? { floor: +o.room.floor, number: String(o.room.number) } : null;
    D.near = null; D.door = undefined; D.doorWord = ''; D.info = null; D.pl = null; D.mini = null;
    D.c = null; D.places = ctx.places || {}; D.shorts = null; D.P = null;
    if (!was) D.opener = o.opener || document.activeElement;
    // The campus (read once by the page) and the year's build index (a few KB) before it's drawn, so it
    // opens once with its picture's frame; never longer than a moment (it opens with the campus mini).
    const ready = care ? Promise.resolve(null) : Promise.resolve(ctx.campus ? ctx.campus() : null).then(cp => {
      if (gen !== D.gen) return;
      D.c = cp && cp.c || null; D.places = cp && cp.places || D.places;
      const FL = M.floors;
      if (!D.c || !FL || !FL.hasBuild || !FL.hasBuild(D.year)) { D.P = null; return; }
      return later(FL.load(D.year), 1500).then(P => {
        if (gen !== D.gen) return;
        D.P = P || null;
        const B = P && P.by[keyOf(D.code)];
        // (Its floors too, briefly, so the room's own name and the door line come with the first frame.)
        return B && P.places[D.code] ? later(P.floorsOf(B.code), 800) : null;
      });
    });
    ready.catch(() => {}).then(() => {
      if (gen !== D.gen) return;
      paint();
      if (!was) show(o);
      else { replaceUrl(); focusHead(); }
      mountMap(true);
      after();
    });
    return true;
  }
  // Shown: the page keeps still, one history entry (?place=CODE), the heading gets the focus (§9 K4).
  function show(o) {
    const el = D.el;
    el.classList.remove('is-out');
    el.showModal();
    document.documentElement.classList.add('pl-dlg-on');
    if (!reduceQ.matches) { el.classList.remove('is-in'); void el.offsetWidth; el.classList.add('is-in'); }
    if (o.popped) D.pushed = true;
    else {
      try {
        const u = urlWith(D.code, D.room), st = Object.assign({}, history.state || {}, { plDlg: 1 });
        // A link with its address: the page under it first, then the dialog as its own entry, so Back
        // closes it and stays on the page.
        if (o.link) history.replaceState(Object.assign({}, history.state || {}), '', urlWith('', null));
        history.pushState(st, '', u); D.pushed = true;
      } catch (e) { D.pushed = false; }
    }
    focusHead();
  }
  function focusHead() { const h = D.el.querySelector('#pl-dlg-t'); if (h) h.focus({ preventScroll: true }); }
  function urlWith(code, room) {
    const u = new URL(location.href);
    if (code) u.searchParams.set('place', code); else u.searchParams.delete('place');
    if (code && room) u.searchParams.set('room', room.floor + '-' + room.number); else u.searchParams.delete('room');
    return u.href;
  }
  // Another place in the same dialog (a part, a room on the map): the entry follows it, no new one.
  function replaceUrl() { try { history.replaceState(history.state, '', urlWith(D.code, D.room)); } catch (e) { /* fine */ } }
  // Put away (×, Esc, the scrim, a swipe, a row of the schedule): it leaves, its entry goes; then
  // whatever was asked (the event's sheet), or the focus back where it came from.
  function close(then) {
    const el = D.el;
    if (!el || !el.open || D.closing) return;
    D.closing = true; D.after = then || null;
    const done = () => {
      hide();
      if (D.pushed) {
        D.pushed = false; D.popping = true;
        history.back();
        // (Should the browser keep the entry, the dialog is still put away.)
        setTimeout(() => { if (D.popping) { D.popping = false; finish(); } }, 600);
      } else finish();
    };
    if (reduceQ.matches) done();
    else { el.classList.add('is-out'); setTimeout(done, 140); }
  }
  function hide() {
    D.closing = false; D.gen++;
    const el = D.el;
    el.classList.remove('is-out', 'is-in');
    el.style.transform = '';
    if (el.open) el.close();
    document.documentElement.classList.remove('pl-dlg-on');
    // The map to move stays made, out of the page (the next place moves it back in).
    if (V && V.host.parentNode) V.host.parentNode.removeChild(V.host);
  }
  function finish() {
    const f = D.after, o = D.opener;
    D.after = null; D.opener = null;
    // (A link opened without an entry of its own leaves the address as it found the page.)
    const u = new URL(location.href);
    if (u.searchParams.has('place')) { try { history.replaceState(history.state, '', urlWith('', null)); } catch (e) { /* fine */ } }
    if (f) { f(o); return; }
    refocus(o);
  }
  function refocus(o) {
    if (o && document.contains(o) && o.focus) { o.focus({ preventScroll: true }); return; }
    // (The page drew itself again under it: the same place's link, if it's there.)
    const code = o && o.dataset ? o.dataset.open || o.dataset.pldialog : '';
    const t = code ? document.querySelector('[data-open="' + CSS.escape(code) + '"], [data-pldialog="' + CSS.escape(code) + '"]') : null;
    if (t) t.focus({ preventScroll: true });
  }
  // Back: the dialog's own entry closes it and nothing else; Forward to it opens it again.
  addEventListener('popstate', e => {
    if (D.popping) { D.popping = false; e.stopImmediatePropagation(); finish(); return; }
    if (D.el && D.el.open) {
      e.stopImmediatePropagation();
      D.pushed = false;
      if (D.closing) return;
      hide(); finish();
      return;
    }
    if (e.state && e.state.plDlg) {
      const q = new URLSearchParams(location.search), code = q.get('place');
      if (code && placeDialog(code, { room: roomOf(q.get('room')), popped: true })) e.stopImmediatePropagation();
    }
  });
  const roomOf = v => { const m = /^(-?\d+)-(.+)$/.exec(String(v || '')); return m ? { floor: +m[1], number: m[2] } : null; };

  // A phone: drag the sheet down by its top to put it away.
  function grab(el) {
    let y0 = null, dy = 0, id = null;
    el.addEventListener('pointerdown', e => {
      if (!phoneQ.matches || !e.target.closest('.pl-dlg__grab')) return;
      y0 = e.clientY; dy = 0; id = e.pointerId;
      el.style.transition = 'none';
    });
    el.addEventListener('pointermove', e => {
      if (y0 == null || e.pointerId !== id) return;
      dy = Math.max(0, e.clientY - y0);
      el.style.transform = dy ? 'translateY(' + dy + 'px)' : '';
    });
    const up = e => {
      if (y0 == null || (e && e.pointerId !== id)) return;
      y0 = null; el.style.transition = '';
      if (dy > 80) close(); else el.style.transform = '';
    };
    el.addEventListener('pointerup', up); el.addEventListener('pointercancel', up);
  }

  /* ------------------------------------------------ the drawing */

  function paint() {
    const el = D.el;
    if (D.care) { el.innerHTML = careView(D.care); el.classList.add('is-nomap'); el.classList.remove('is-static'); return; }
    const p = D.places[D.code];
    const pl = planOf(p, D.room), main = String(p.code).indexOf('/') < 0;
    const w = D.c ? where(p) : { kind: 'none' };
    const live = !!(pl && D.c && M.floors && M.floors.layer);
    // The campus mini, in the same frame, for a place the build doesn't hold (and as the picture's stand-in).
    D.mini = !pl && D.c ? M.mini(D.c, p, D.places, { parts: true, member: !!D.ctx.member, aspect: wideQ.matches ? 520 / 420 : 16 / 9 }) : null;
    const hasMap = live || !!(D.mini && D.mini.svg);
    el.classList.toggle('is-nomap', !hasMap);
    el.classList.toggle('is-static', !live && hasMap);
    D.pl = pl;
    // The title, and building · floor · code (§4.3); a room asked for by its number: its own name.
    const b = w.b;
    let title, fact;
    if (pl && pl.room) {
      title = '<h2 class="pl-dlg__h" id="pl-dlg-t" tabindex="-1">' + nb(pl.name || roomName(p)) + '</h2>';
      fact = [b ? bShort(b) : '', M.floorName(pl.room.floor), p.code];
    } else if (main) {
      title = '<h2 class="pl-dlg__h" id="pl-dlg-t" tabindex="-1">' + nb(p.name) + ' <span class="pm-code">' + esc(p.code) + '</span></h2>';
      fact = [floorOf(p, pl)];
    } else {
      title = '<h2 class="pl-dlg__h" id="pl-dlg-t" tabindex="-1" aria-label="' + esc(p.name + ', ' + p.code) + '">' + nb(roomName(p)) + '</h2>';
      fact = [b && w.kind !== 'outdoor' ? bShort(b) : '', floorOf(p, pl), p.code];
    }
    fact = fact.filter(Boolean).join(' · ');
    // How to get in: the door and which side ("South doors · on the right"), from the walk (filled in once
    // it comes; its line is kept so nothing under it moves); with no plan, the campus mini's own line.
    const doorSlot = pl && pl.rooms.length ? '<p class="pl-dlg__door" data-pldoor>' + (D.door ? I.door + '<span>' + nb(D.door) + '</span>' : '<span aria-hidden="true">&nbsp;</span>') + '</p>'
      : D.mini && (D.mini.line || D.mini.note) ? '<p class="pl-dlg__door">' + (D.mini.line ? '<span>' + nb(D.mini.line) + '</span>' : '') + (D.mini.note ? '<small>' + esc(D.mini.note) + '</small>' : '') + '</p>' : '';
    // The place's other rooms in the build ("Balcony · 2nd floor"): each opens here.
    let parts = '';
    if (pl) {
      const all = (D.P.roomsOf(p.code) || []), cur = pl.room ? pl.room : all[0];
      parts = all.length > 1 ? all.filter(r => !cur || +r.floor !== +cur.floor || String(r.number) !== String(cur.number)).map(r =>
        '<button type="button" class="pm-flrow" data-plpart="' + esc(r.floor + '|' + r.number) + '"><span>' + nb([roomWord(pl.B, r), M.floorName(+r.floor)].filter(Boolean).join(' · ')) + '</span>' + I.next + '</button>').join('') : '';
    }
    // (A room asked for by its number goes with it: the balcony's Directions went to the 1st floor's
    // Auditorium and its North-west doors; r2c, last round.)
    const href = D.ctx.dirs ? D.ctx.dirs(p, pl && pl.room ? pl.room : null) : '';
    const dirs = href ? '<p class="pl-dlg__go"><a class="wk-btn wk-btn--big" href="' + esc(href) + '" data-dirs>' + I.dirs + 'Directions</a></p>' : '';
    el.innerHTML = '<div class="pl-dlg__in">' + '<span class="pl-dlg__grab" aria-hidden="true"></span>' +
      (hasMap ? '<div class="pl-dlg__map" data-plmap></div>' : '') +
      '<div class="pl-dlg__body"><div class="pl-dlg__top"><button type="button" class="pl-dlg__x" data-plx aria-label="Close" title="Close">' + I.close + '</button>' + title +
      (fact ? '<p class="pl-dlg__fact">' + nb(fact) + '</p>' : '') + doorSlot + '</div>' + parts + dirs + rowsView(p) +'<div data-plnear>' + nearView() + '</div></div></div>';
  }
  // On the schedule: the year's rows at this place (its own code: a building's rooms have their own), in
  // time order, each with its day and time; tapping one opens it on the Conference page. Never drawn empty.
  // A whole building with no rows of its own (W, Y) lists its rooms' rows, each with its room under it
  // ("Room 150"), so the Rec Center's dialog isn't the map alone (r2c fix). One with rows of its own (the
  // Chapel's services, Barnes's meals) keeps to them; its rooms have their own dialogs.
  function rowsView(p) {
    const ctx = D.ctx, code = String(p.code).toUpperCase(), all = ctx.rows ? ctx.rows() : [];
    const own = all.filter(r => r.code && String(r.code).toUpperCase() === code);
    const list = (own.length || code.indexOf('/') > -1 ? own : all.filter(r => r.code && keyOf(r.code) === code))
      .map((r, i) => ({ r, i })).sort((a, b) => (a.r.at != null && b.r.at != null ? a.r.at - b.r.at : 0) || a.i - b.i).map(x => x.r);
    if (!list.length) return '';
    const row = r => {
      const rc = String(r.code).toUpperCase(), sub = rc !== code && D.places[rc] ? mapName(rc) : '';
      const inner = '<span class="pl-dlg__when">' + esc(r.day) + (r.time ? ' ' + esc(r.time) : '') + '</span><span class="pl-dlg__what">' + nb(r.title) + (sub ? '<small>' + nb(sub) + '</small>' : '') + '</span>';
      const cls = 'pl-dlg__row' + (r.past ? ' is-past' : '');
      return '<li>' + (ctx.openRow ? '<button type="button" class="' + cls + '" data-plrow="' + esc(r.id) + '">' + inner + I.right + '</button>'
        : ctx.rowHref ? '<a class="' + cls + '" href="' + esc(ctx.rowHref(r.id)) + '">' + inner + I.right + '</a>'
          : '<div class="' + cls + ' is-plain">' + inner + '</div>') + '</li>';
    };
    return '<section class="pl-dlg__sec"><h3 class="pm-k">On the schedule</h3><ul class="pl-dlg__rows">' + list.map(row).join('') + '</ul></section>';
  }
  // Nearby: the nearest restroom and elevator along the halls, in feet; "Stairs only" where true (§4.3).
  function nearView() {
    const n = D.near, pl = D.pl;
    if (!n || !pl || !pl.rooms.length) return '';
    const fl = +pl.rooms[0].floor, rows = [];
    const row = (z, word, m) => '<li><button type="button" class="pm-nrow" data-plring="' + esc(z.floor + '|' + z.at[0] + '|' + z.at[1]) + '"><span>' + esc(word + (+z.floor !== fl ? ' · ' + M.floorName(z.floor) : '')) + '</span><span class="pm-nrow__d">' + esc(M.feet(m)) + '</span></button></li>';
    if (n.rest && n.rest.x.at) rows.push(row(n.rest.x, n.rest.word, n.rest.m));
    if (n.lift && n.lift.x.at) rows.push(row(n.lift.x, 'Elevator', n.lift.m));
    else if (n.stairsOnly) rows.push('<li><p class="pm-nrow is-plain"><span>Stairs only</span></p></li>');
    return rows.length ? '<section class="pl-dlg__sec pm-near"><h3 class="pm-k">Nearby</h3><ul>' + rows.join('') + '</ul></section>' : '';
  }
  // Care nearby (§4.12): Emergency first, its kind and hours, the address and Call. No Directions (driving
  // is held for Michael's yes) and no map (nearby.csv has no positions).
  function careView(n) {
    const tel = O.telHref;
    return '<div class="pl-dlg__in"><span class="pl-dlg__grab" aria-hidden="true"></span><div class="pl-dlg__body"><div class="pl-dlg__top"><button type="button" class="pl-dlg__x" data-plx aria-label="Close" title="Close">' + I.close + '</button>' +
      '<h2 class="pl-dlg__h" id="pl-dlg-t" tabindex="-1">' + nb(n.name) + '</h2></div>' +
      '<a class="wk-sosrow" href="' + esc(tel('911')) + '">' + I.phone + '<span>Emergency · Call 911</span>' + I.right.replace('pm-i', 'wk-i') + '</a>' +
      (n.kind || n.hours || n.distance ? '<p class="pl-dlg__fact">' + esc([n.kind, n.hours, n.distance].filter(Boolean).join(' · ')) + '</p>' : '') +
      (n.address ? '<p class="pl-dlg__addr">' + I.pin + '<span>' + esc(n.address) + '</span></p>' : '') +
      (n.phone ? '<p class="pl-dlg__go"><a class="wk-btn wk-btn--line wk-btn--big" href="' + esc(tel(n.phone)) + '">' + I.phone + 'Call<span class="wk-btn__num">' + esc(n.phone) + '</span></a></p>' : '') +
      '</div></div>';
  }

  /* ------------------------------------------------ the picture */

  // The map to move, made once a campus and year: the viewer (cooperative), the floor plans on it, the
  // streets under it.
  function viewerFor() {
    if (V && V.c === D.c && V.year === D.year && V.P === D.P) return V;
    const host = document.createElement('div');
    host.className = 'pl-dlg__view';
    return (V = { c: D.c, year: D.year, P: D.P, host, view: null, L: null });
  }
  function mountMap(first) {
    const slot = D.el && D.el.querySelector('[data-plmap]');
    if (!slot) return;
    if (!D.pl) {
      // A laptop: the campus mini drawn again at the shape its column has once the place's side is laid out
      // (it sat 520 × 420 over 260 px of white; r2c, last round). More of the campus, never a stretched one.
      const p = D.places[D.code], r = wideQ.matches && D.el.open && D.c ? slot.getBoundingClientRect() : null;
      if (r && r.width && r.height > 430 && D.mini) { const m2 = M.mini(D.c, p, D.places, { parts: true, member: !!D.ctx.member, aspect: r.width / r.height }); if (m2 && m2.svg) D.mini.svg = m2.svg; }
      slot.innerHTML = D.mini && D.mini.svg ? D.mini.svg : '';
      const s = slot.querySelector('svg'); if (s) s.classList.add('pl-dlg__mini');
      return;
    }
    const v = viewerFor();
    slot.appendChild(v.host);
    if (!v.view) {
      const used = [], codes = {};
      Object.keys(D.places).forEach(k => { const q = D.places[k], w = where(q); if (w.b && used.indexOf(w.b.name) < 0) used.push(w.b.name); if (w.b && !codes[w.b.name] && String(q.code).indexOf('/') < 0) codes[w.b.name] = q.code; });
      const B = D.pl.B, box = B.box || (B.item ? M.boxOf(D.c, [B.item.name], 30) : null);
      v.view = M.viewer(v.host, D.c, { title: 'Campus map', cooperative: true, expand: false, used, codes, shorts: shorts(), focus: box });
      v.L = v.view.extend(inner => M.floors.layer(inner, D.P, {
        nameOf: mapName,
        shortOf: B2 => B2.item ? bShort(B2.item) : B2.name,
        keyOnly: id => { const d = doorRow(id); return !!(d && d.keyOnly); },
        stepFree: id => { const d = doorRow(id); return !!(d && d.stepFree === 'yes'); },
        labelOf: id => { const d = doorRow(id); return d && d.label ? d.label : ''; },
        // (A laptop's floor caption, outside the building: where the picture is roomy. 'pin': with that corner
        // off the frame, in the frame's lower-left corner instead, so the opened floor always has it; r2c fix.)
        // (And from 768: the one-column dialog said no floor; r2c, last round.)
        get caption() { return !phoneQ.matches ? 'pin' : false; },
        // Another Conference room tapped on the map: that room, here.
        onRoom: code => { if (D.el && D.el.open && D.places[code] && code !== D.code) placeDialog(code, { year: D.year }); },
        onMissing: () => { if (D.el && D.el.open) dest(false); },
        // (Names keep off the credit and the zoom buttons in the frame's corners.)
        covers: () => v.host.isConnected ? [v.host.querySelector('.pv-credit'), v.host.querySelector('.pv-ctl')] : []
      }));
      if (D.P.area) D.P.area().then(a => { if (a && v.view && v.view.area) v.view.area(a); }, () => {});
    }
    // Labels and the fit keep clear of the floor picker (top right) and the credit (along the bottom).
    v.view.inset({ top: 0, bottom: 22, left: 0, right: 64 });
    dest(first);
  }
  // The place's building opened on its floor, the room in tan, the door line drawn; framed once known:
  // the room and its door, at the building's fit, at least 2.2 px a metre, closer for a small room (§4.3).
  function dest(first) {
    const v = V, pl = D.pl, gen = D.gen;
    if (!v || !v.L || !pl) return;
    // Its building tinted, as the Conference app's Places does: hidden while its floor is open, and the place
    // still in tan when a floor doesn't come (§12.7; the check saw a white building; r2c, last round).
    const w = where(D.places[D.code]), sel = w.b && w.kind !== 'outdoor' ? w.b.name : '';
    if (v.view.select) v.view.select(sel);
    if (v.L.picked) v.L.picked(sel);
    // (its door: M.placeDoor's, as the door line's; step-free only with No stairs on, Nov 5, night)
    v.L.dest({ code: pl.code, rooms: pl.rooms, place: pl.place, name: pl.name || '', stepFree: !!(M.floors.stepFreeOf && M.floors.stepFreeOf(D.year)) }).then(info => {
      if (gen !== D.gen || !info || V !== v) return;
      D.info = info;
      frame(info, first);
      // (The map's line wins: should the walk and the drawn line name another door, the drawn one is said.)
      if (D.door && info.door && info.door.name && D.doorWord && D.doorWord !== info.door.name) { D.door = info.door.name; paintDoor(); }
    });
  }
  function frame(info, first) {
    const v = V; if (!v || !v.view) return;
    const L = v.L, bs = info.B.box ? L.scaleFor(info.B.box, 16) : 2.2;
    const s = info.room ? Math.min(L.scaleFor(info.box, 40), Math.max(bs, 2.2), 24) : Math.min(bs, 24);
    const b = info.room ? info.box : info.B.box || info.box;
    if (b) v.view.look(b.x + b.w / 2, b.y + b.h / 2, s, !first && !reduceQ.matches);
  }
  // What comes after the drawing: the door line, then Nearby.
  function after() {
    const gen = D.gen, pl = D.pl;
    if (D.care || !pl || !pl.rooms.length) return;
    const p = D.places[D.code], r0 = pl.rooms[0];
    if (M.floors.doorOf) M.floors.doorOf(D.year, D.c, p, D.places, pl.room || null).then(d => {
      if (gen !== D.gen) return;
      D.doorWord = d ? d.door : '';
      // ("South doors · on the right"; upstairs, "East doors · Elevator".)
      // (With No stairs on and no step-free walk, Directions' reason after it: "East doors · Elevator ·
      // Doors not checked", as Directions says "No step-free route · Doors not checked"; Nov 5, night.)
      D.door = d ? (d.up ? [d.door, d.lift] : [d.door, d.side]).concat(d.why ? [d.why] : []).filter(Boolean).join(' · ') : '';
      if (D.door && D.info && D.info.door && D.info.door.name && D.info.door.name !== D.doorWord) D.door = D.info.door.name;
      paintDoor();
    });
    const v = V;
    if (v && v.L) v.L.nearby(pl.code, +r0.floor, r0.number).then(n => {
      if (gen !== D.gen) return;
      D.near = n || null;
      const box = D.el.querySelector('[data-plnear]');
      if (box) box.innerHTML = nearView();
    });
  }
  function paintDoor() {
    const el = D.el && D.el.querySelector('[data-pldoor]');
    if (!el) return;
    if (D.door) el.innerHTML = I.door + '<span>' + nb(D.door) + '</span>';
    else el.remove();
  }

  /* ------------------------------------------------ taps */

  function onClick(e) {
    const el = D.el;
    if (e.target === el) { if (D.downOut) close(); return; }
    const t = e.target.closest('[data-plx], [data-plpart], [data-plrow], [data-plring]');
    if (!t) return;
    if (t.hasAttribute('data-plx')) { close(); return; }
    if (t.dataset.plpart) {
      const m = /^(-?\d+)\|(.+)$/.exec(t.dataset.plpart), all = D.P ? D.P.roomsOf(D.code) || [] : [];
      const first = all[0], room = m && !(first && +first.floor === +m[1] && String(first.number) === m[2]) ? { floor: +m[1], number: m[2] } : null;
      placeDialog(D.code, { year: D.year, room });
      return;
    }
    if (t.dataset.plrow) { const id = t.dataset.plrow, ctx = D.ctx; close(o => ctx.openRow(id, o)); return; }
    if (t.dataset.plring && V && V.L && D.pl) {
      // A Nearby row: rung on its floor, and framed with the room if it's out of view.
      const [fl, x, y] = t.dataset.plring.split('|').map(Number), at = [x, y], i = D.info;
      V.L.ring(D.pl.code, fl, at);
      if (i && i.room) {
        const r = i.room, x0 = Math.min(r.x, at[0]), y0 = Math.min(r.y, at[1]), bx = { x: x0, y: y0, w: Math.max(r.x + r.w, at[0]) - x0, h: Math.max(r.y + r.h, at[1]) - y0 };
        const rr = V.host.getBoundingClientRect(), cur = rr.width / Math.max(1e-6, V.view.view().w);
        V.view.look(bx.x + bx.w / 2, bx.y + bx.h / 2, Math.min(cur, V.L.scaleFor(bx, 40)), !reduceQ.matches);
      }
    }
  }
  // A phone turned, a window made narrower: drawn again in its new shape (the map moves with it).
  const redraw = () => { if (D.el && D.el.open && !D.closing) { const f = document.activeElement, x = f && f.closest && f.closest('[data-plx]'); paint(); mountMap(true); after(); (x ? D.el.querySelector('[data-plx]') : D.el.querySelector('#pl-dlg-t')).focus({ preventScroll: true }); } };
  [phoneQ, wideQ].forEach(q => { if (q.addEventListener) q.addEventListener('change', redraw); });

  placeDialog.use = fn => { use = typeof fn === 'function' ? fn : null; };
  placeDialog.close = () => close();
  placeDialog.isOpen = () => !!(D.el && D.el.open);
  // The page's address asks for a place (?place=CODE, &room=2-220): opened once the page can say it.
  placeDialog.arrive = () => {
    const q = new URLSearchParams(location.search), code = q.get('place');
    return code ? placeDialog(code, { room: roomOf(q.get('room')), link: true }) : false;
  };
  M.placeDialog = placeDialog;
})();
