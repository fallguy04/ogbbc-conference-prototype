/*!
 * ogc-core.js — shared helpers for the Annual Conference hub and schedule.
 * No dependencies, no build step. Everything hangs off window.OGC.
 *
 * Time model: schedule times are wall-clock times at the venue (the conference
 * time zone). They are displayed as written. The only conversion is the
 * "your time" hint for people calling in from another time zone.
 *
 * In the WordPress plugin, the parsing half of this file moves to PHP (so the
 * page is rendered server-side) and the "now / next" half stays in the browser,
 * because page caching would otherwise freeze it.
 */
(function (global) {
  'use strict';

  /* ---------------------------------------------------------------- CSV */

  // RFC 4180-ish: quoted fields, escaped quotes, commas and newlines in quotes.
  function parseCSV(text) {
    const rows = [];
    let row = [], field = '', inQuotes = false;
    text = String(text || '').replace(/^﻿/, '');
    for (let i = 0; i < text.length; i++) {
      const c = text[i];
      if (inQuotes) {
        if (c === '"') {
          if (text[i + 1] === '"') { field += '"'; i++; } else { inQuotes = false; }
        } else {
          field += c;
        }
      } else if (c === '"') {
        inQuotes = true;
      } else if (c === ',') {
        row.push(field); field = '';
      } else if (c === '\n') {
        row.push(field); rows.push(row); row = []; field = '';
      } else if (c !== '\r') {
        field += c;
      }
    }
    if (field !== '' || row.length) { row.push(field); rows.push(row); }
    return rows.filter(r => r.some(v => v.trim() !== ''));
  }

  function slug(s) {
    return String(s || '').trim().toLowerCase().replace(/[^a-z0-9]+/g, '_').replace(/^_|_$/g, '');
  }

  // First row is the header. Rows whose first cell starts with "#" are notes
  // for the people filling in the sheet, and are skipped.
  function csvToObjects(text) {
    const rows = parseCSV(text);
    if (!rows.length) return [];
    const head = rows[0].map(slug);
    return rows.slice(1)
      .filter(r => !String(r[0] || '').trim().startsWith('#'))
      .map(r => {
        const o = {};
        head.forEach((h, i) => { if (h) o[h] = String(r[i] == null ? '' : r[i]).trim(); });
        return o;
      });
  }

  function yes(s) { return /^(y|yes|true|1|x)$/i.test(String(s || '').trim()); }

  /* --------------------------------------------------------------- time */

  // "7:00 AM", "7 am", "7:30pm", "noon", "12 noon", "midnight", "19:30" → minutes after midnight.
  function parseTime(s) {
    if (s == null) return null;
    const t = String(s).trim().toLowerCase().replace(/\./g, '');
    if (!t) return null;
    if (/^(12(:00)?\s*)?noon$/.test(t)) return 720;
    if (/^(12(:00)?\s*)?midnight$/.test(t)) return 1440;
    const m = t.match(/^(\d{1,2})(?::(\d{2}))?\s*(am|pm|a|p)?$/);
    if (!m) return null;
    let h = +m[1];
    const min = m[2] ? +m[2] : 0, ap = m[3];
    if (min > 59 || h > 24) return null;
    if (ap) {
      if (h === 0 || h > 12) return null;
      if (ap[0] === 'p' && h !== 12) h += 12;
      if (ap[0] === 'a' && h === 12) h = 0;
    }
    return h * 60 + min;
  }

  function formatTime(min, opts) {
    opts = opts || {};
    if (min == null) return '';
    const m = ((min % 1440) + 1440) % 1440;
    if (opts.words && m === 720) return 'noon';
    if (opts.words && m === 0) return 'midnight';
    let h = Math.floor(m / 60);
    const mm = m % 60, ap = h >= 12 ? 'PM' : 'AM';
    h = h % 12 || 12;
    const t = (opts.compact && mm === 0) ? String(h) : h + ':' + String(mm).padStart(2, '0');
    return opts.noSuffix ? t : t + ' ' + ap;
  }

  // "7:00–9:45 AM", "10:00 AM–12:00 PM", or "10:00 AM" when there is no end.
  function formatRange(start, end, opts) {
    opts = opts || {};
    if (start == null) return '';
    if (end == null) return formatTime(start, opts);
    const sameHalf = (Math.floor(((start % 1440) + 1440) % 1440 / 720)) === (Math.floor(((end % 1440) + 1440) % 1440 / 720));
    return (sameHalf ? formatTime(start, Object.assign({}, opts, { noSuffix: true })) : formatTime(start, opts)) +
      '–' + formatTime(end, opts);
  }

  /* --------------------------------------------------------------- dates */

  function parseISODate(s) {
    const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(s || '').trim());
    return m ? { y: +m[1], m: +m[2], d: +m[3] } : null;
  }
  function isoAddDays(iso, n) {
    const p = parseISODate(iso);
    return new Date(Date.UTC(p.y, p.m - 1, p.d + n)).toISOString().slice(0, 10);
  }
  function daysBetween(a, b) {
    const pa = parseISODate(a), pb = parseISODate(b);
    return Math.round((Date.UTC(pb.y, pb.m - 1, pb.d) - Date.UTC(pa.y, pa.m - 1, pa.d)) / 864e5);
  }
  const FMT = {
    long: { weekday: 'long', month: 'long', day: 'numeric' },            // Saturday, June 6
    full: { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' },
    short: { weekday: 'short', month: 'short', day: 'numeric' },         // Sat, Jun 6
    md: { month: 'long', day: 'numeric' },                               // June 6
    mdShort: { month: 'short', day: 'numeric' },                         // Jun 6
    mdy: { month: 'long', day: 'numeric', year: 'numeric' },             // June 6, 2026
    weekday: { weekday: 'long' },
    weekdayShort: { weekday: 'short' },
    day: { day: 'numeric' }
  };
  function fmtDate(iso, style) {
    const p = parseISODate(iso);
    if (!p) return '';
    return new Intl.DateTimeFormat('en-US', Object.assign({ timeZone: 'UTC' }, FMT[style || 'long']))
      .format(new Date(Date.UTC(p.y, p.m - 1, p.d)));
  }
  // "May 28 – June 1, 2027" / "June 5–9, 2026"
  function fmtDateSpan(a, b) {
    const pa = parseISODate(a), pb = parseISODate(b);
    if (!pa) return '';
    if (!pb || a === b) return fmtDate(a, 'mdy');
    if (pa.y === pb.y && pa.m === pb.m) return fmtDate(a, 'md') + '–' + pb.d + ', ' + pb.y;
    if (pa.y === pb.y) return fmtDate(a, 'md') + ' – ' + fmtDate(b, 'md') + ', ' + pb.y;
    return fmtDate(a, 'mdy') + ' – ' + fmtDate(b, 'mdy');
  }

  /* ---------------------------------------------------------- time zones */

  // Wall-clock date and minutes in `tz` at instant `date` (default: now).
  function wallNow(tz, date) {
    const parts = new Intl.DateTimeFormat('en-US', {
      timeZone: tz, year: 'numeric', month: '2-digit', day: '2-digit',
      hour: '2-digit', minute: '2-digit', hourCycle: 'h23'
    }).formatToParts(date || new Date());
    const g = t => (parts.find(p => p.type === t) || {}).value;
    const hh = +g('hour') % 24;
    return { date: g('year') + '-' + g('month') + '-' + g('day'), minutes: hh * 60 + +g('minute') };
  }

  // Venue wall-clock → real instant.
  function wallToInstant(iso, minutes, tz) {
    const p = parseISODate(iso);
    const target = Date.UTC(p.y, p.m - 1, p.d, 0, minutes);
    let guess = target;
    for (let k = 0; k < 3; k++) {
      const w = wallNow(tz, new Date(guess)), wp = parseISODate(w.date);
      const diff = target - Date.UTC(wp.y, wp.m - 1, wp.d, 0, w.minutes);
      if (!diff) break;
      guess += diff;
    }
    return new Date(guess);
  }

  function viewerZone() {
    try { return Intl.DateTimeFormat().resolvedOptions().timeZone || null; } catch (e) { return null; }
  }

  // "7:00 AM PDT" when the viewer's clock differs from the venue's; '' when it is the same.
  function localHint(iso, minutes, tz, viewerTz) {
    const vz = viewerTz || viewerZone();
    if (!vz || minutes == null || !iso) return '';
    const inst = wallToInstant(iso, minutes, tz);
    const a = wallNow(tz, inst), b = wallNow(vz, inst);
    if (a.date === b.date && a.minutes === b.minutes) return '';
    let s = new Intl.DateTimeFormat('en-US', { timeZone: vz, hour: 'numeric', minute: '2-digit', timeZoneName: 'short' }).format(inst);
    if (a.date !== b.date) s += ' (' + fmtDate(b.date, 'weekdayShort') + ')';
    return s;
  }

  // Short zone name for the venue on a given date, e.g. "EDT".
  function zoneAbbr(tz, iso) {
    const inst = wallToInstant(iso || new Date().toISOString().slice(0, 10), 720, tz);
    const p = new Intl.DateTimeFormat('en-US', { timeZone: tz, timeZoneName: 'short' }).formatToParts(inst);
    return (p.find(x => x.type === 'timeZoneName') || {}).value || '';
  }

  // "2026-06-06T14:45" (venue wall clock) → { date, minutes }. Used by the ?as-of= preview.
  function parseAsOf(s) {
    const m = /^(\d{4}-\d{2}-\d{2})(?:[T ](\d{1,2}):(\d{2}))?$/.exec(String(s || '').trim());
    if (!m) return null;
    return { date: m[1], minutes: m[2] != null ? (+m[2]) * 60 + (+m[3]) : 12 * 60 };
  }

  /* ------------------------------------------------------------ schedule */

  const AUDIENCE_LABEL = { all: 'Everyone', conference: 'Conference', preteens: 'Preteens', youngfolks: 'Youngfolks' };
  const AUDIENCE_ORDER = { all: 0, conference: 1, preteens: 2, youngfolks: 3 };
  const EMPHASIS = { worship: 1, council: 1, communion: 1 };

  function normAudience(s) {
    const k = slug(s);
    if (!k || k === 'all' || k === 'everyone') return 'all';
    if (k.indexOf('pre') === 0) return 'preteens';
    if (k.indexOf('young') === 0 || k === 'yf' || k === 'yfs') return 'youngfolks';
    return 'conference';
  }

  // src = { settings: [{key, value}], schedule: [...], places: [...], contacts: [...] }
  function buildSchedule(src) {
    const S = {};
    (src.settings || []).forEach(r => { if (r.key) S[slug(r.key)] = r.value; });
    if (!parseISODate(S.first_day)) throw new Error('settings.csv needs first_day as YYYY-MM-DD (the conference Friday).');

    const tz = S.timezone || 'America/Indiana/Indianapolis';
    const names = (S.days || 'Friday|Saturday|Sunday|Monday|Tuesday|Wednesday').split('|').map(s => s.trim()).filter(Boolean);
    const days = names.map((name, i) => ({
      key: slug(name), name, date: isoAddDays(S.first_day, i),
      items: [], allDay: [], desk: [], nightly: []
    }));
    const dayIndex = {};
    days.forEach(d => { dayIndex[d.key] = d; dayIndex[d.date] = d; dayIndex[slug(d.name).slice(0, 3)] = d; });
    const findDay = v => dayIndex[slug(v)] || dayIndex[String(v || '').trim()] || dayIndex[slug(v).slice(0, 3)];

    const places = {};
    (src.places || []).forEach(p => {
      if (!p.code) return;
      // v3, Oct 8: x, y = where the room is on the campus map (metres; pinned on the walk-through).
      const pin = v => v === '' || v == null || isNaN(+v) ? null : +v;
      places[p.code.toUpperCase()] = { code: p.code, name: p.name || p.code, building: p.building || '', map: p.map || '', x: pin(p.x), y: pin(p.y), signed: p.signed || '',
        // The map area: how to find the room once inside (floor, a short note, its door), and whether it's outdoors.
        floor: p.floor || '', inside: p.inside || '', door: p.door || '', outdoor: p.outdoor || '',
        // Oct 13 (from Andrew's guide): the words people ask for it by, and what's there from one fixed list.
        search: wordList(p.search), features: wordList(p.features).filter(f => FEATURES[f]) };
    });
    const placeInfo = code => {
      if (!code) return null;
      return places[code.toUpperCase()] || { code, name: code, building: '', map: '', unknown: true };
    };

    const problems = [];
    let seq = 0;
    const ids = {};
    (src.schedule || []).forEach((r, rowNo) => {
      if (!r.title) return;
      const first = findDay(r.day);
      if (!first) { problems.push('Row ' + (rowNo + 2) + ': unknown day "' + r.day + '"'); return; }
      const last = r.last_day ? findDay(r.last_day) : first;
      if (!last) { problems.push('Row ' + (rowNo + 2) + ': unknown last_day "' + r.last_day + '"'); return; }
      const start = parseTime(r.start), endRaw = parseTime(r.end);
      let end = endRaw;
      if (start != null && end != null && end <= start) end += 1440;          // "11:00 PM – 12:00 AM"
      const sortTime = start != null ? start : parseTime(r.sort_time);
      if (r.place && !places[r.place.toUpperCase()]) problems.push('Row ' + (rowNo + 2) + ': place code "' + r.place + '" is not in places.csv');
      const display = slug(r.display) || 'timeline';
      for (let i = days.indexOf(first); i <= days.indexOf(last); i++) {
        const day = days[i];
        ++seq;
        // A row's id stays the same from load to load (links, recordings, changes): the row's own _id
        // (with the day when it repeats over several), else one made from its day, time and title.
        let rid = r._id ? String(r._id) + (first !== last ? '-' + day.key : '') : 'x' + slug(day.key + ' ' + (r.start || r.sort_time || '') + ' ' + r.title);
        if (ids[rid]) rid += '-' + seq;
        ids[rid] = 1;
        const item = {
          id: rid, row: r._id || '', day: day.key, date: day.date, closedDuring: slug(r.closed_during),
          start, end, sort: sortTime == null ? 1439 : sortTime,
          startText: start == null ? (r.start || '') : '',
          endText: endRaw == null ? (r.end || '') : '',
          title: r.title, audience: normAudience(r.audience), kind: slug(r.kind) || 'other',
          place: placeInfo(r.place), note: r.note || '', print_note: r.print_note || '', callIn: yes(r.call_in), display,
          noteShort: r.note_short || '',
          emphasis: !!EMPHASIS[slug(r.kind)]
        };
        const bucket = display === 'all_day' ? day.allDay : display === 'desk' ? day.desk : display === 'nightly' ? day.nightly : day.items;
        bucket.push(item);
      }
    });
    const bySort = (a, b) => a.sort - b.sort || AUDIENCE_ORDER[a.audience] - AUDIENCE_ORDER[b.audience];
    days.forEach(d => { d.items.sort(bySort); d.allDay.sort(bySort); d.desk.sort(bySort); d.nightly.sort(bySort); });

    // Rows in schedule.csv can point at short answers in guide.csv ("lodging|campers").
    const guides = {};
    (src.guide || []).forEach(r => {
      const id = slug(r.id);
      if (!id) return;
      const g = guides[id] = guides[id] || { id, title: '', summary: '', paras: [] };
      if (r.title) g.title = r.title;
      if (r.summary) g.summary = r.summary;
      if (r.text) g.paras.push(r.text);
    });
    const rawGuide = {};
    (src.schedule || []).forEach(r => { if (r.guide) rawGuide[r.day + '|' + r.title] = r.guide; });
    days.forEach(d => d.items.forEach(it => {
      const g = rawGuide[d.name + '|' + it.title];
      it.guides = g ? g.split('|').map(slug).filter(id => guides[id]) : [];
    }));

    // Menus (menus.csv): each meal or snack row gets its stations and dishes, matched by day and the
    // row's own title ("Supper", "Snack"); a station with no dishes is left out. Where two rows that day
    // share the title (the Conference's Snack and the Youngfolks' Snack), the menu is the Conference's
    // and the other row has none.
    const menus = {};
    (src.menus || []).forEach(r => {
      if (!r.day || !r.meal || /^#/.test(r.day)) return;
      const items = String(r.items || '').split(/\s+·\s+/).map(x => x.trim()).filter(Boolean);
      if (!items.length) return;
      const k = slug(r.day) + '|' + slug(r.meal);
      (menus[k] = menus[k] || []).push({ station: r.station || '', course: slug(r.course), items });
    });
    days.forEach(d => {
      const eat = d.items.filter(it => it.kind === 'meal' || it.kind === 'snack');
      eat.forEach(it => {
        const shared = eat.some(x => x !== it && slug(x.title) === slug(it.title));
        it.menu = shared && it.audience !== 'conference' && it.audience !== 'all' ? null : menus[d.key + '|' + slug(it.title)] || null;
      });
    });

    // Sermons, recordings and documents pinned to a schedule row by day + start.
    (src.attachments || []).forEach((r, i) => {
      if (!r.title) return;
      const day = findDay(r.day);
      const t = parseTime(r.start);
      const pool = day ? day.items.concat(day.allDay) : [];
      // By the row's own id when the attachment names it (row), else by its day and time.
      const hits = r.row ? days.reduce((l, d) => l.concat(d.items.concat(d.allDay).filter(it => it.row === r.row)), [])
        : pool.filter(it => it.start === t && (!r.match || slug(it.title) === slug(r.match)));
      const target = hits.find(it => it.emphasis) || hits[0];
      if (!target) { problems.push('attachments.csv row ' + (i + 2) + ': nothing on ' + r.day + ' at ' + r.start + (r.match ? ' called "' + r.match + '"' : '')); return; }
      (target.attachments = target.attachments || []).push({
        id: 'a' + i, kind: slug(r.kind) || 'recording', title: r.title, by: r.by || '', url: r.url || '', audio: r.audio || '',
        duration: r.duration || '', refs: (r.refs || '').split(';').map(x => x.trim()).filter(Boolean), note: r.note || '', posted: r.posted || ''
      });
    });

    // The Conference year around the week: announcements, deadlines, minutes.
    const milestones = (src.milestones || []).filter(r => r.title).map(r => ({
      phase: slug(r.phase) === 'after' ? 'after' : 'before', date: parseISODate(r.date) ? r.date : '', when: r.when || '',
      kind: slug(r.kind) || 'notice', title: r.title, url: r.url || '', note: r.note || '', cta: r.cta || '', until: parseISODate(r.until) ? r.until : ''
    }));

    // Notices: one line each, shown from `from` through `to` (a closed entrance, a room change), until
    // `until_time` on its last day when it has one (the admin's "Ends at"; round 3's fix pass).
    const notices = (src.notices || []).filter(r => r.text).map((r, i) => {
      if (!parseISODate(r.from) || !parseISODate(r.to)) problems.push('notices.csv row ' + (i + 2) + ': from and to must be dates (YYYY-MM-DD)');
      return { from: r.from || '', to: r.to || '', text: r.text, url: r.url || '', kind: slug(r.kind), until: parseTime(r.until_time) };
    });

    // Help during the week, by what someone needs: a sentence, its hours, one number or link.
    const help = (src.help || []).filter(r => r.need).map(r => ({
      need: r.need, text: r.text || '', phone: r.phone || '', pin: r.pin || '', action: r.action || '', link: r.link || '',
      hours: r.hours || '', open: r.open || '', kind: slug(r.kind) || '', place: r.place || '', before: r.before || '',
      search: wordList(r.search)
    }));

    // Off campus, for the Places view: urgent care, hospitals, pharmacies.
    const nearby = (src.nearby || []).filter(r => r.name).map(r => ({
      kind: r.kind || '', name: r.name, address: r.address || '', phone: r.phone || '', hours: r.hours || '', distance: r.distance || ''
    }));

    return {
      settings: S, tz, days, places, guides, milestones, notices, help, nearby,
      contacts: (src.contacts || []).filter(c => c.label),
      problems,
      dayByDate: iso => days.find(d => d.date === iso) || null
    };
  }

  // settings, schedule, places and contacts are required; the rest are optional.
  function loadSchedule(baseUrl) {
    const need = ['settings', 'schedule', 'places', 'contacts'];
    const optional = ['attachments', 'milestones', 'guide', 'notices', 'help', 'nearby', 'menus'];
    const get = (n, must) => fetch(baseUrl + n + '.csv', { cache: 'no-store' }).then(r => {
      if (r.ok) return r.text();
      if (must) throw new Error(n + '.csv could not be loaded (' + r.status + ')');
      return '';
    }, err => { if (must) throw err; return ''; });
    const names = need.concat(optional);
    return Promise.all(names.map(n => get(n, need.indexOf(n) > -1))).then(texts => {
      const src = {};
      names.forEach((n, i) => { src[n] = csvToObjects(texts[i]); });
      return buildSchedule(src);
    });
  }

  // Opening hours as people write them: "Fri 5 PM–11 PM; Sat–Tue 8 AM–11 PM", several times in a day
  // separated by commas ("Sat–Tue 6 AM–8 AM, 9 PM–11 PM"). → [{ days: [0–6, Sunday = 0], ranges: [[start, end]] }],
  // or null when a part doesn't read (so a check can say which).
  const WEEK = ['sun', 'mon', 'tue', 'wed', 'thu', 'fri', 'sat'];
  function parseHours(txt) {
    const out = [];
    for (const seg of String(txt || '').split(';').map(x => x.trim()).filter(Boolean)) {
      const m = /^([A-Za-z]{3})[a-z]*\.?(?:\s*[–-]\s*([A-Za-z]{3})[a-z]*\.?)?\s+(.+)$/.exec(seg);
      if (!m) return null;
      const a = WEEK.indexOf(m[1].toLowerCase()), b = m[2] ? WEEK.indexOf(m[2].toLowerCase()) : a;
      if (a < 0 || b < 0) return null;
      const days = [];
      for (let d = a; ; d = (d + 1) % 7) { days.push(d); if (d === b) break; }
      const ranges = [];
      for (const r of m[3].split(',').map(x => x.trim()).filter(Boolean)) {
        const p = r.split(/\s*[–-]\s*/);
        const s = parseTime(p[0]), e = parseTime(p[1]);
        if (p.length !== 2 || s == null || e == null) return null;
        ranges.push([s, e <= s ? e + 1440 : e]);
      }
      out.push({ days, ranges });
    }
    return out;
  }

  // "1:15:20" → "1 hr 15 min", "00:31:30" → "32 min"
  function fmtDuration(s) {
    const p = String(s || '').split(':').map(Number);
    if (!p.length || p.some(isNaN)) return '';
    let sec = p.length === 3 ? p[0] * 3600 + p[1] * 60 + p[2] : p.length === 2 ? p[0] * 60 + p[1] : p[0];
    const min = Math.round(sec / 60), h = Math.floor(min / 60), m = min % 60;
    return h ? h + ' hr' + (m ? ' ' + m + ' min' : '') : m + ' min';
  }
  function durationSeconds(s) {
    const p = String(s || '').split(':').map(Number);
    if (!p.length || p.some(isNaN)) return 0;
    return p.length === 3 ? p[0] * 3600 + p[1] * 60 + p[2] : p.length === 2 ? p[0] * 60 + p[1] : p[0];
  }

  // Item text helpers shared by every view.
  // An end written as "?" or "TBD" means the organizers don't know yet (Council).
  const OPEN_END = /^(\?|tbd|tba)$/i;
  function itemTime(it, opts) {
    const openEnd = OPEN_END.test(it.endText);
    if (it.start == null) {
      if (it.end != null) return it.startText + '–' + formatTime(it.end, opts);
      return it.startText + (it.endText && !openEnd ? '–' + it.endText : '');
    }
    if (it.end == null && openEnd) return formatTime(it.start, opts) + ' until finished';
    if (it.end == null && it.endText) return formatTime(it.start, opts) + '–' + it.endText;
    return formatRange(it.start, it.end, opts);
  }
  function itemTill(it, opts) {           // "till 9:45" style used by the grid and print
    if (it.end != null) return 'till ' + formatTime(it.end, Object.assign({ noSuffix: true }, opts));
    if (OPEN_END.test(it.endText)) return 'until finished';
    if (it.endText) return 'till ' + it.endText;
    return '';
  }
  // Is the item happening at wall-clock `now` ({date, minutes})?
  function itemState(it, now) {
    if (!now || it.date !== now.date || it.start == null) return it.date < (now && now.date) ? 'past' : '';
    const end = it.end != null ? it.end : it.start + 1;
    if (now.minutes < it.start) return 'upcoming';
    if (now.minutes < end) return 'now';
    return 'past';
  }

  function mapUrl(place, settings) {
    if (!place) return '';
    if (/^https?:/.test(place.map)) return place.map;
    const q = [place.map || place.building || place.name, settings.venue, settings.city].filter(Boolean).join(', ');
    return 'https://www.google.com/maps/search/?api=1&query=' + encodeURIComponent(q);
  }

  // tel: link. With a PIN the phone pauses (",,") and then dials it.
  function telHref(number, pin) {
    const digits = String(number || '').replace(/[^\d+]/g, '');
    if (!digits) return '';
    const full = digits.length === 10 ? '+1' + digits : digits;
    return 'tel:' + full + (pin ? ',,' + String(pin).replace(/[^\d#*]/g, '').replace('#', '%23') : '');
  }

  // A place's features, one fixed list (Oct 13, from Andrew's guide), its words as the guide says them.
  // places.csv `features`: these keys, `|` between them. Anything else in the cell is ignored.
  const FEATURES = { nursery: 'Nursery', restroom: 'Restroom', 'family restroom': 'Family restroom', 'accessible entrance': 'Accessible entrance', elevator: 'Elevator', 'quiet room': 'Quiet room' };
  // What each is asked for by, fixed (search matches these whole): "baby" finds a nursery.
  const FEATURE_WORDS = { nursery: ['nursery', 'baby', 'babies', 'infant', 'toddler'], restroom: ['restroom', 'bathroom', 'toilet'], 'family restroom': ['family restroom', 'restroom', 'bathroom', 'changing table'],
    'accessible entrance': ['accessible entrance', 'accessible', 'wheelchair'], elevator: ['elevator', 'lift'], 'quiet room': ['quiet room', 'quiet', 'nursing'] };
  const featureWords = fs => [].concat.apply([], (fs || []).map(f => FEATURE_WORDS[f] || [f]));
  // Words kept as typed, `|` between them, lower case ("bathroom|restroom"); search matches them whole.
  const wordList = v => String(v || '').split('|').map(w => w.trim().toLowerCase().replace(/\s+/g, ' ')).filter(Boolean);

  // One way to say a floor, on every page (Nov 5, docs/34 §10.4): the campus's own numbers, as IWU's signs
  // and its 1xx rooms say them, "1st floor", "2nd floor"; below the first, "Lower level". Kept in this one
  // function, since Michael may change the words (O.map.floorName is this one).
  function floorName(n) {
    n = +n;
    if (!n || n < 1) return 'Lower level';
    const s = n % 10 === 2 && n % 100 !== 12 ? 'nd' : n % 10 === 3 && n % 100 !== 13 ? 'rd' : n % 10 === 1 && n % 100 !== 11 ? 'st' : 'th';
    return n + s + ' floor';
  }

  const ESC = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, c => ESC[c]); }

  global.OGC = {
    parseCSV, csvToObjects, slug, yes,
    parseTime, formatTime, formatRange,
    parseISODate, isoAddDays, daysBetween, fmtDate, fmtDateSpan,
    wallNow, wallToInstant, viewerZone, localHint, zoneAbbr, parseAsOf, parseHours,
    AUDIENCE_LABEL, normAudience, buildSchedule, loadSchedule, fmtDuration, durationSeconds,
    itemTime, itemTill, itemState, mapUrl, telHref, esc, FEATURES, featureWords, floorName
  };
})(window);
