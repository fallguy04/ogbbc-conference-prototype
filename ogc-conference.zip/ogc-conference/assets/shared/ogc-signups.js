/*
 * ogc-signups.js — what the sign-up pages share (volunteer, register, lodging, the committees'
 * Sheets): the year's shifts, the records people make, the prices, and calendar files.
 *
 * Plugin copy (foundation, Oct 10): the records live on the server. SU.load / SU.store / SU.me keep
 * v3's signatures, backed by ogc-store.js's O.records (filled at O.ready with what this viewer may
 * see: a member every record of the year; anyone else their own, and others' public views, marked
 * _pub). v3's in-browser samples are off: sample households and volunteers are rows in the database
 * (seeded by the volunteer and register areas), so sampleHouseholds() and seatSamples() are kept only
 * for making that seed.
 */
(function () {
  'use strict';
  const O = window.OGC;

  /* ------------------------------------------------------------ the store (this browser) */

  // Lists of records (one row each on the server) and values kept whole in the year's state (members).
  const RECORDS = { signups: 1, registrations: 1, credits: 1, waits: 1, teams: 1 };
  const STATE = { rooms: 'rooms' };
  function load(kind, year, fallback) {
    if (RECORDS[kind] && O.records) {
      const l = O.records.list(kind, year);
      if (l) return l;
      O.records.load(year, [kind]);   // not loaded yet: the page hears "ogc:records" when it is
      return fallback;
    }
    if (STATE[kind] && O.state) return O.state.get(year, STATE[kind], fallback);
    return fallback;
  }
  function store(kind, year, value) {
    if (RECORDS[kind] && O.records) return O.records.store(kind, year, value);
    if (STATE[kind] && O.state) return O.state.set(year, STATE[kind], value);
  }

  /* ------------------------------------------------------------ who's signing up */

  // No accounts and no passwords: a person is their email. The real site emails a sign-in link,
  // then remembers the device; here this browser remembers them. Everything signed up for under
  // that email shows on Your sign-ups.
  // Plugin: the signed-in person (OGC_WP.me). Someone who has typed their name and email on a form
  // but isn't signed in yet is remembered in this browser as "pending" (the signin area emails them a
  // link; until then the server refuses their writes).
  const W = window.OGC_WP || {}, PENDING = 'ogc-me-pending';
  function me() {
    if (W.me && W.me.email) return { name: W.me.name || '', email: W.me.email, phone: W.me.phone || '' };
    try { const v = JSON.parse(localStorage.getItem(PENDING)); return v && v.email ? Object.assign(v, { pending: true }) : null; } catch (e) { return null; }
  }
  function setMe(p) {
    if (W.me && W.me.email && sameEmail(W.me.email, p.email)) { if (p.name) W.me.name = W.me.name || p.name; if (p.phone) W.me.phone = p.phone; return; }
    try { localStorage.setItem(PENDING, JSON.stringify({ name: p.name || '', email: String(p.email || '').trim(), phone: p.phone || '' })); } catch (e) { /* not remembered */ }
  }
  function signOut() {
    try { localStorage.removeItem(PENDING); } catch (e) { /* nothing kept */ }
    if (W.me && W.logout) location.href = W.logout;
  }
  const sameEmail = (a, b) => !!a && !!b && String(a).trim().toLowerCase() === String(b).trim().toLowerCase();
  // A name to greet someone by when they sign in with only their email.
  function nameFor(year, email) {
    const reg = load('registrations', year, []).find(r => sameEmail(r.household.email, email) || (r.helper && r.helper.on && sameEmail(r.helper.email, email)));
    if (reg) return reg.helper && reg.helper.on && sameEmail(reg.helper.email, email) ? reg.helper.name : reg.household.contact;
    const up = load('signups', year, []).find(u => sameEmail(u.email, email));
    return up ? up.name : '';
  }

  /* ------------------------------------------------------------ shifts */

  const findDay = (days, s) => days.find(d => d.name.toLowerCase().indexOf(String(s).toLowerCase().slice(0, 3)) === 0 || d.date === s);

  // A steady made-up count of people already signed up, so the pages show open and full shifts.
  function sampleFilled(id, needed) {
    let h = 0;
    for (let i = 0; i < id.length; i++) h = (h * 31 + id.charCodeAt(i)) >>> 0;
    const r = h % 10;
    return r < 3 ? needed : Math.min(needed, Math.floor((r / 10) * needed));
  }
  // Made-up first names for the sample people (Oct 8: the sign-up page shows who's on each shift, so
  // the samples need names a person could recognise, not initials).
  const MEN = ['John', 'Daniel', 'David', 'Samuel', 'Joseph', 'Paul', 'Aaron', 'Jonathan', 'Mark', 'Timothy', 'Stephen', 'Philip', 'James', 'Joel', 'Seth', 'Levi', 'Micah', 'Peter', 'Thomas', 'Matthew', 'Isaac', 'Benjamin', 'Jacob', 'Ethan', 'Josiah', 'Silas', 'Owen', 'Simon', 'Eli', 'Adam'];
  const WOMEN = ['Ruth', 'Esther', 'Mary', 'Anna', 'Sarah', 'Rebecca', 'Lydia', 'Miriam', 'Rachel', 'Hannah', 'Leah', 'Martha', 'Naomi', 'Lois', 'Grace', 'Joy', 'Faith', 'Ellen', 'Abigail', 'Elizabeth', 'Susanna', 'Deborah', 'Priscilla', 'Rosanna', 'Joanna', 'Julia', 'Phoebe', 'Eunice', 'Carol', 'Laura'];
  // A name as the public pages show it: "Ruth K." (the site's convention, as for speakers).
  const firstL = n => { const w = String(n || '').trim().split(/\s+/); return w.length > 1 ? w[0] + ' ' + w[w.length - 1].charAt(0) + '.' : w[0]; };
  // One naming rule for the volunteer page, Your sign-ups and the calendar files, the same as the emails'
  // (the server's ogc_vol_job_said / ogc_vol_job_words / ogc_vol_names_words; after the third critic,
  // Oct 15): a job named as its committee is ("Usher" under Ushers) isn't said twice, and people are
  // "Edith and Harold Garber" (one surname) or "Martha Crittenden and Alex Bowman".
  const lowW = t => String(t || '').trim().toLowerCase().replace(/\s+/g, ' ');
  const jobSaid = (role, c) => { const a = lowW(role).replace(/\s+helpers?$/, ''), b = lowW(c); return !!a && (a === b || a + 's' === b); };
  // A job whose words are its committee's apart from capitals and spaces ("First aid" under First Aid) is
  // said once, in the committee's own spelling ("First Aid"), wherever the job is shown (after the ninth
  // critic, Oct 16: "First aid" on a row, "First Aid" above it). "Usher" under Ushers and "Preteen helper"
  // under Preteens keep the job's own words. The server's emails and calendar files follow the same rule.
  const squash = t => String(t || '').toLowerCase().replace(/\s+/g, '');
  const jobName = (role, c) => squash(role) && squash(role) === squash(c) ? String(c).trim() : String(role || '');
  const jobWords = (role, c) => jobSaid(role, c) || !String(c || '').trim() ? jobName(role, c) : role + ' · ' + c;
  // The night a shift belongs to, one rule for every page (the server's ogc_vol_eve_date; after the eighth
  // critic, Oct 16): a shift starting from midnight to before 5 AM belongs to the evening before ("Fri
  // night"), unless it's on the Conference's first day. sh: a shift with .day (one of days) and .start.
  const eveOf = (sh, days) => { if (!sh || sh.allweek || !(sh.start < 300)) return sh && sh.day; const i = (days || []).indexOf(sh.day); return i > 0 ? days[i - 1] : sh.day; };
  const isNight = (sh, days) => !!sh && !sh.allweek && eveOf(sh, days) !== sh.day;
  // "Fri night, May 28" / "Sat, May 29": a shift's day as the volunteer page and the emails say it.
  const dayShort = (sh, days) => { const e = eveOf(sh, days); return e ? O.fmtDate(e.date, 'weekdayShort') + (isNight(sh, days) ? ' night' : '') + ', ' + O.fmtDate(e.date, 'mdShort') : ''; };
  const namesWords = (names, short) => {
    const ns = Array.from(new Set((names || []).map(n => String(n || '').trim()).filter(Boolean)));
    if (!ns.length) return '';
    const and = a => a.length < 2 ? a.join('') : a.slice(0, -1).join(', ') + ' and ' + a[a.length - 1];
    const firsts = ns.map(n => n.split(/\s+/)[0]), lasts = ns.map(n => { const w = n.split(/\s+/); return w.length > 1 ? w[w.length - 1] : ''; });
    if (short) return and(Array.from(new Set(firsts)));
    if (ns.length === 1) return ns[0];
    return new Set(lasts.map(l => l.toLowerCase())).size === 1 && lasts[0] ? and(firsts) + ' ' + lasts[0] : and(ns);
  };
  const initials = n => String(n || '').trim().split(/\s+/).filter(Boolean).map(w => w.charAt(0)).filter((c, i, a) => i === 0 || i === a.length - 1).join('').toUpperCase();
  // The sample volunteers: eighty couples, each sharing a surname and a phone.
  const POOL = [];
  for (let k = 0; k < 80; k++) {
    const sur = ['Adams', 'Baker', 'Carter', 'Dean', 'Ellis', 'Ford', 'Grant', 'Hayes', 'Irwin', 'Jordan', 'Knight', 'Lane', 'Mason', 'Nash', 'Owens', 'Parker', 'Quinn', 'Rhodes', 'Stone', 'Turner', 'Vaughn', 'Walsh', 'Young', 'Barton', 'Cole', 'Drake', 'Fleming', 'Gates', 'Hart', 'Keller', 'Lowe', 'Marsh', 'Porter', 'Reed', 'Shaw', 'Tate', 'Ward', 'Wells', 'Brooks', 'Fisher', 'Moore', 'Clark', 'Evans', 'Hall'][(k * 17) % 44];
    const phone = '555-01' + String(k).padStart(2, '0');
    [MEN[(k * 7) % MEN.length], WOMEN[(k * 11 + 3) % WOMEN.length]].forEach(f => POOL.push({ name: f + ' ' + sur, phone, email: (f + '.' + sur).toLowerCase() + '@example.com', sample: true }));
  }
  const hashOf = s => { let h = 0; for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) >>> 0; return h; };
  // Who's already on each shift: each committee has its regulars, most people take a shift a day and
  // two or three in the week, and no one is on two shifts at once.
  function seatSamples(shifts) {
    const busy = {}, roster = {}, load = {};
    const free = (p, sh) => !(busy[p.name] || []).some(b => b.date === sh.day.date && b.start < sh.end && sh.start < b.end);
    const room = (p, sh, perDay) => { const l = load[p.name] || {}; return (l[sh.day.date] || 0) < perDay && (l.week || 0) < 3; };
    shifts.forEach((sh, i) => {
      const c = sh.committee;
      if (!roster[c]) {
        const want = shifts.filter(x => x.committee === c).reduce((k, x) => k + x.base, 0);
        const size = Math.min(POOL.length, Math.max(8, Math.ceil(want / 2.2) + 3)), h = hashOf(c), at = h % POOL.length, step = [3, 7, 9, 11, 13][h % 5];
        roster[c] = Array.from({ length: size }, (_, k) => POOL[(at + k * step) % POOL.length]);
      }
      const r = roster[c], out = [];
      [1, 2].forEach(perDay => {
        for (let k = 0; k < r.length && out.length < sh.base; k++) {
          const p = r[(i * 7 + k) % r.length];
          if (out.indexOf(p) < 0 && free(p, sh) && room(p, sh, perDay)) out.push(p);
        }
      });
      out.forEach(p => {
        (busy[p.name] = busy[p.name] || []).push({ date: sh.day.date, start: sh.start, end: sh.end });
        const l = load[p.name] = load[p.name] || {};
        l[sh.day.date] = (l[sh.day.date] || 0) + 1; l.week = (l.week || 0) + 1;
      });
      sh.sample = out;
      sh.base = out.length;
    });
  }
  // The sample people already on a shift, for the committee views.
  const samplePeople = sh => (sh.sample || []).slice();

  // shifts.csv → one shift for each day (a row's last_day repeats it every day through that day).
  function expandShifts(rows, model, opt) {
    const days = model.days, out = [];
    // "All week" (the one fixed choice beside exact times; the volunteer area, Oct 15): one shift for the
    // days it covers, as the server's ogc_vol_allweek_shift. Only a page that draws it asks (opt.allweek);
    // anywhere else the row is left out, as before.
    const allweek = r => /^\s*all\s+week\s*$/i.test(r.start || '');
    if (opt && opt.allweek) rows.forEach((r, row) => {
      if (!r.role || !allweek(r) || /^#/.test(r.committee || '') || !days.length) return;
      const first = r.day ? findDay(days, r.day) : days[0];
      const endIx = days.findIndex(d => d.date === opt.lastDate);
      const last = r.last_day ? findDay(days, r.last_day) : days[endIx > -1 ? endIx : days.length - 1];
      if (!first || !last) return;
      const a = days.indexOf(first), b = Math.max(a, days.indexOf(last));
      const place = r.place ? (model.places[r.place.toUpperCase()] || { code: r.place, name: r.place }) : null;
      out.push({ id: r.uid || [r.committee, r.role, 'all-week'].join('|').toLowerCase().replace(/[^a-z0-9|]+/g, '-'), uid: r.uid || '', row, committee: r.committee, role: jobName(r.role, r.committee), day: first, lastDay: days[b], allweek: true, start: 0, end: (b - a + 1) * 1440,
        needed: Math.max(1, +r.needed || 1), unlimited: /^(any|no limit|unlimited|0)$/i.test(String(r.needed || '').trim()), place, note: r.note || '', rule: r.rule || '', question: r.question || '', min_age: r.min_age || '', screening: r.screening || '', shown: r.shown || '', base: 0, sample: [] });
    });
    rows.filter(r => r.role && r.day && !allweek(r) && !/^#/.test(r.committee || '')).forEach((r, row) => {
      // Volunteer area (Oct 10): a repeating row whose last day isn't in the year is cut at the year's
      // last day, never dropped (as the server, module-volunteer.php).
      const first = findDay(days, r.day), last = r.last_day ? (findDay(days, r.last_day) || days[days.length - 1]) : first;
      if (!first || !last) return;
      const start = O.parseTime(r.start); let end = O.parseTime(r.end);
      if (start == null || end == null) return;
      if (end <= start) end += 1440;
      const a = days.indexOf(first), b = days.indexOf(last);
      for (let i = a; i <= b; i++) {
        // A row's lasting uid (kept by the server through edits) makes the id: the uid for a one-day
        // row, uid|date for each day of a repeating one. An old row without one: v3's id.
        const d = days[i], id = r.uid ? (a === b ? r.uid : r.uid + '|' + d.date) : [r.committee, r.role, d.key, r.start].join('|').toLowerCase().replace(/[^a-z0-9|]+/g, '-');
        const unlimited = /^(any|no limit|unlimited|0)$/i.test(String(r.needed || '').trim());
        const needed = Math.max(1, +r.needed || 1);
        const place = r.place ? (model.places[r.place.toUpperCase()] || { code: r.place, name: r.place }) : null;
        // Plugin: no made-up people already on a shift (base 0); who's on it comes from the records.
        out.push({ id, uid: r.uid || '', row, committee: r.committee, role: jobName(r.role, r.committee), day: d, start, end, needed, unlimited, place, note: r.note || '', rule: r.rule || '', question: r.question || '', min_age: r.min_age || '', screening: r.screening || '', shown: r.shown || '', base: 0, sample: [] });
      }
    });
    out.sort((a, b) => a.day.date < b.day.date ? -1 : a.day.date > b.day.date ? 1 : a.start - b.start);
    return out;
  }
  const span = sh => O.formatTime(sh.start) + ' – ' + O.formatTime(sh.end);

  /* ------------------------------------------------------------ registration */

  // A file's rows with any admin edits kept in this browser (prototype; see ogc-local-edits.js).
  const withEdits = (year, name, rows) => O.edits ? O.edits.merge(year, name, rows) : rows;
  function settings(rows) {
    const cfg = {};
    rows.forEach(r => { if (r.key && !/^#/.test(r.key)) cfg[r.key] = r.value; });
    return cfg;
  }
  // Oct 8 (Michael: "sometimes they include Thursday and Wednesday nights too"): nights before the first
  // day, for committees and helpers who come early (early_nights = Wednesday|Thursday), named "Early
  // Wednesday" so they're never taken for the Wednesday at the end.
  const nightsOf = cfg => String(cfg.early_nights || '').split('|').map(x => x.trim()).filter(Boolean).map(x => 'Early ' + x)
    .concat(String(cfg.nights || '').split('|').map(x => x.trim()).filter(Boolean));
  const isEarly = n => /^Early /.test(n);
  const nightShort = n => String(n).replace(/^Early /, '').slice(0, 3);
  // The regular nights, without the early ones (what a new registration starts with).
  const mainNights = cfg => nightsOf(cfg).filter(n => !isEarly(n));
  // The date of an early night: the last day of that name before the first day.
  const WEEK = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  const earlyDate = (n, firstDate) => {
    const want = WEEK.indexOf(String(n).replace(/^Early /, ''));
    if (want < 0 || !firstDate) return '';
    for (let k = 1; k < 7; k++) { const d = O.isoAddDays(firstDate, -k), p = O.parseISODate(d); if (p && new Date(Date.UTC(p.y, p.m - 1, p.d)).getUTCDay() === want) return d; }
    return '';
  };
  const money = n => '$' + (Math.round(n * 100) / 100).toLocaleString('en-US', { minimumFractionDigits: n % 1 ? 2 : 0, maximumFractionDigits: 2 });
  const plural = (n, one, many) => n + ' ' + (n === 1 ? one : (many || one + 's'));

  // A person's nights: their own when they come or go on different days (Oct 8, Michael: family members
  // come and go, and Young Folks do their own thing), else the household's. A Young Folk whose household
  // stays elsewhere still has the hall's nights.
  function nightsFor(p, d, all) {
    if (p.nights && p.nights.length) return p.nights;
    if (d.stay.nights && d.stay.nights.length) return d.stay.nights;
    return p.yf ? (all || []).filter(n => !isEarly(n)) : [];
  }
  // The days a person is on campus: the first night's day through the morning after the last night;
  // someone here only for the day, any day.
  function personDays(p, d, days) {
    const all = nightsFor(p, d, days.map(x => x.name)), ns = all.filter(n => !isEarly(n)), early = all.length > ns.length;
    if (!ns.length) return early ? days.slice(0, 1) : days.slice();
    const a = early ? 0 : days.indexOf(findDay(days, ns[0])), b = days.indexOf(findDay(days, ns[ns.length - 1]));
    return a < 0 || b < 0 ? days.slice() : days.slice(a, b + 2);
  }

  // What a household pays: lodging only (meals are provided), plus any gift.
  function cost(d, cfg) {
    // A saved registration carries what it was charged (the server prices it, register area): that,
    // never a fresh guess from today's prices.
    if (d.price && Array.isArray(d.price.lines) && d.price.total_cents != null) return { lines: d.price.lines.map(l => [l.label, l.cents / 100]), sum: d.price.total_cents / 100 };
    const s = d.stay, lines = [], C = k => +cfg[k] || 0;
    if (s.type === 'dorm' && s.nights.length) {
      lines.push(['Dorm room' + (s.rooms > 1 ? 's' : '') + ': ' + s.rooms + ' × ' + plural(s.nights.length, 'night') + ' × ' + money(C('room_price')), s.rooms * s.nights.length * C('room_price')]);
      if (s.mattresses) lines.push(['Air mattresses: ' + s.mattresses + ' × ' + money(C('mattress_price')), s.mattresses * C('mattress_price')]);
    }
    // Young Folks share rooms in their own halls, each with their own key (Oct 8): each pays a share of
    // a room for their nights. How the campus charges them (per room in 2025 at Cedarville, per person
    // in 2018 at IWU) is the lodging committee's to confirm; a share of a room is the starting point.
    const share = C('room_price') / Math.max(1, C('room_beds') || 2), yfNights = (d.people || []).filter(p => p.name && p.yf).reduce((k, p) => k + nightsFor(p, d, nightsOf(cfg)).length, 0);
    if (yfNights && share) lines.push(['Young Folks halls: ' + plural(yfNights, 'night') + ' × ' + money(share) + ' (a share of a room)', yfNights * share]);
    if ((s.type === 'dorm' || s.type === 'yf') && s.linens) lines.push(['Linen packets: ' + s.linens + ' × ' + money(C('linen_price')), s.linens * C('linen_price')]);
    // Campers pay by the night (2026) or once for the stay (2022): camper_per in registration.csv.
    if (s.type === 'camper' && s.nights.length) lines.push(cfg.camper_per === 'stay' ? ['Camper lot', C('camper_price')] : ['Camper lot: ' + plural(s.nights.length, 'night') + ' × ' + money(C('camper_price')), s.nights.length * C('camper_price')]);
    if (d.gift > 0) lines.push(['Gift for ' + (cfg.gift_for || 'the Conference fund'), +d.gift]);
    return { lines, sum: lines.reduce((k, l) => k + l[1], 0) };
  }

  // The days a household is on campus: every day any of its people is here (each from their first
  // night's day through the morning after their last). Staying elsewhere, any day.
  function daysHere(d, days) {
    const s = d.stay, ppl = (d.people || []).filter(p => p.name);
    if (!ppl.length) {
      const ns = (s.nights || []).filter(n => !isEarly(n)), early = (s.nights || []).length > ns.length;
      if (s.type === 'elsewhere' || !ns.length) return days.slice();
      const a = early ? 0 : days.indexOf(findDay(days, ns[0])), b = days.indexOf(findDay(days, ns[ns.length - 1]));
      return a < 0 || b < 0 ? days.slice() : days.slice(a, b + 2);
    }
    const set = new Set();
    ppl.forEach(p => personDays(p, d, days).forEach(x => set.add(x)));
    return days.filter(x => set.has(x));
  }
  const label = d => d.household.name ? d.household.name.replace(/^the /i, '') : d.household.contact;
  const householdName = d => /(household|family)$/i.test(label(d)) ? label(d) : label(d) + ' household';
  const surname = d => (d.household.name || d.household.contact || '').replace(/^the /i, '').replace(/ (family|household)$/i, '').split(/\s+/).pop();
  const nightSpan = (nights, all) => !nights.length ? '' : nights.length === 1 ? nightShort(nights[0]) : nightShort(nights[0]) + '–' + nightShort(nights[nights.length - 1]);

  // Steady sample households, so the committee pages show a believable year. Names are made up.
  // Oct 8: 130 households, nearer a real Conference's size, so Lodging's board shows the whole job.
  const SURNAMES = ['Adams', 'Baker', 'Carter', 'Dean', 'Ellis', 'Ford', 'Grant', 'Hayes', 'Irwin', 'Jordan', 'Knight', 'Lane', 'Mason', 'Nash', 'Owens', 'Parker', 'Quinn', 'Rhodes', 'Stone', 'Turner', 'Vaughn', 'Walsh', 'Young', 'Barton', 'Cole', 'Drake', 'Fleming', 'Gates', 'Hart', 'Keller', 'Lowe', 'Marsh', 'Porter', 'Reed', 'Shaw', 'Tate', 'Ward', 'Wells', 'Brooks', 'Fisher', 'Moore', 'Clark', 'Evans', 'Hall',
    'Abbott', 'Archer', 'Bell', 'Bishop', 'Blake', 'Bradley', 'Burke', 'Burton', 'Caldwell', 'Chapman', 'Cooper', 'Craig', 'Cross', 'Curtis', 'Dalton', 'Dawson', 'Dixon', 'Duncan', 'Eaton', 'Elliott', 'Emery', 'Farmer', 'Fields', 'Fletcher', 'Foster', 'Fuller', 'Gardner', 'Garrett', 'Gibson', 'Gilbert', 'Graves', 'Gray', 'Griffin', 'Hale', 'Hammond', 'Hardy', 'Harper', 'Hawkins', 'Hicks', 'Hill', 'Holland', 'Holt', 'Hopkins', 'Horton', 'Howell', 'Hudson', 'Hunt', 'Ingram', 'Jarvis', 'Kemp', 'Kirby', 'Lambert', 'Lawson', 'Lewis', 'Lloyd', 'Long', 'Lucas', 'Lyons', 'Manning', 'Maxwell', 'Meyer', 'Miles', 'Mills', 'Morgan', 'Morris', 'Newton', 'Noble', 'Norris', 'Oliver', 'Page', 'Palmer', 'Payne', 'Pearson', 'Perry', 'Pierce', 'Powell', 'Pratt', 'Preston', 'Price', 'Ramsey', 'Riley', 'Roberts', 'Rogers', 'Ross', 'Rowe', 'Russell'];
  const INITIALS = 'ABCDEGHJKLMNPRSTW';
  function rng(seed) {
    let a = seed >>> 0;
    return () => { a = (a + 0x6D2B79F5) >>> 0; let t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
  }
  function sampleHouseholds(year, cfg) {
    const r = rng((+year || 2026) * 7919), nights = mainNights(cfg), early = nightsOf(cfg).filter(isEarly), out = [];
    SURNAMES.forEach((sur, i) => {
      const who = extra => Object.assign({ name: INITIALS[Math.floor(r() * INITIALS.length)] + '. ' + sur, band: 'adult', preteen: false, yf: false, yfHall: '', minor: false }, extra || {});
      const x = r(), size = x < .12 ? 1 : x < .42 ? 2 : x < .66 ? 3 + Math.floor(r() * 2) : 5 + Math.floor(r() * 3);
      const people = [who()];
      if (size > 1) people.push(who());
      for (let k = 2; k < size; k++) {
        const y = r();
        people.push(y < .32 ? who({ yf: true, yfHall: r() < .5 ? 'men' : 'women', minor: r() < .45 }) : y < .5 ? who({ preteen: true }) : y < .86 ? who({ band: 'child' }) : who({ band: 'baby' }));
      }
      const t = r(), type = t < .7 ? 'dorm' : t < .86 ? 'camper' : 'elsewhere';
      const n = r(), ns = n < .72 ? nights.slice() : n < .86 ? nights.slice(1) : nights.slice(0, -1);
      const sleepers = people.filter(p => !p.yf && p.band !== 'baby').length;
      const rooms = Math.max(1, Math.ceil(sleepers / 3));
      const adults = people.filter(p => p.band === 'adult' && !p.yf && !p.preteen).length;
      out.push({
        id: 'R-' + year + '-' + String(1000 + ((i * 7919) % 9000)), sample: true,
        at: O.isoAddDays(cfg.opens || year + '-03-01', Math.floor(r() * 80)),
        household: { name: sur, contact: people[0].name, phone: '555-' + String(200 + i).padStart(4, '0'), email: people[0].name.replace(/[^A-Za-z]/g, '').toLowerCase() + '@example.com' },
        people,
        stay: { type, nights: type === 'elsewhere' ? [] : ns, rooms: type === 'dorm' ? rooms : 0, linens: type === 'dorm' ? Math.floor(r() * (rooms * 2 + 1)) : 0, mattresses: type === 'dorm' && r() < .2 ? 1 : 0, ground: type === 'dorm' && r() < .14, yfOk: true,
          keys: type === 'dorm' ? Array.from({ length: rooms }, (_, k) => (people[k % 2] && !people[k % 2].yf && people[k % 2].band === 'adult' ? people[k % 2] : people[0]).name) : [], needs: '' },
        meals: { off: {}, custom: {} }, communion: Math.min(adults, Math.floor(r() * (adults + 1)) + (adults ? 1 : 0)), preteens: {}, contacts: [], gift: 0, help: []
      });
      const h = out[out.length - 1];
      if (h.stay.ground) h.stay.needs = 'Uses a walker (sample)';
    });
    nameHouseholds(out, year);
    // Young Folks pair up in their halls, most both asking; a few come a day late (a separate stream of
    // chance, so the households above stay as they were).
    const r2 = rng((+year || 2026) * 31), yf = { men: [], women: [] };
    out.forEach(h => h.people.forEach(p => { if (p.yf && yf[p.yfHall]) yf[p.yfHall].push(p); }));
    Object.keys(yf).forEach(k => { const l = yf[k]; for (let i = 0; i + 1 < l.length; i += 2) { const x = r2(); if (l[i].name === l[i + 1].name) continue; if (x < .75) { l[i].rooming = l[i + 1].name; l[i + 1].rooming = l[i].name; } else if (x < .9) l[i].rooming = l[i + 1].name; } });
    out.forEach(h => h.people.forEach(p => { if (p.yf && h.stay.nights.length > 1 && r2() < .18) p.nights = h.stay.nights.slice(1); }));
    // Paying by check, and credit for nights not used (Oct 8 review: the treasurer's list was always
    // empty): a few checks still to come before a Conference, a few credits asked for after one.
    const r4 = rng((+year || 2026) * 977), over = cfg.refunds_by && O.wallNow('America/Indiana/Indianapolis').date > O.isoAddDays(cfg.refunds_by, -30);
    out.forEach(h => {
      const x = r4(), y = r4();
      if (h.stay.type === 'elsewhere') return;
      if (!over && x < .07) { h.pay = 'check'; h.checkDue = Math.round(cost(h, cfg).sum * 100) / 100; }
      if (over && y < .05 && h.stay.type === 'dorm' && h.stay.nights.length > 2) {
        const last = h.stay.nights[h.stay.nights.length - 1];
        h.creditAsk = { nights: last, amount: (h.stay.rooms || 1) * (+cfg.room_price || 0), at: O.isoAddDays(cfg.refunds_by, -Math.floor(r4() * 10) - 3) };
      }
    });
    // When the COA offers early nights, a few households (committees, helpers) come the night before.
    if (early.length) {
      const r3 = rng((+year || 2026) * 131);
      out.forEach(h => { if (h.stay.type !== 'elsewhere' && h.stay.nights.length === nights.length && r3() < .07) h.stay.nights = early.slice(r3() < .3 ? 0 : -1).concat(h.stay.nights); });
    }
    return out;
  }
  // First names for the sample households (Oct 8), from a stream of chance of their own so the
  // households stay as they were: a couple, the Young Folks by their hall, the children either way.
  function nameHouseholds(out, year) {
    const r3 = rng((+year || 2026) * 97), pick = l => l[Math.floor(r3() * l.length)];
    out.forEach(h => {
      const sur = h.household.name, used = {};
      const first = (list) => { let f = pick(list); for (let k = 0; used[f] && k < 6; k++) f = pick(list); used[f] = true; return f; };
      const man = r3() < .5;
      h.people.forEach((p, i) => {
        const list = p.yf ? (p.yfHall === 'men' ? MEN : WOMEN) : i === 0 ? (man ? MEN : WOMEN) : i === 1 && p.band === 'adult' && !p.preteen ? (man ? WOMEN : MEN) : (r3() < .5 ? MEN : WOMEN);
        p.name = first(list) + ' ' + sur;
      });
      h.household.contact = h.people[0].name;
      h.household.email = h.people[0].name.replace(/[^A-Za-z ]/g, '').toLowerCase().replace(' ', '.') + '@example.com';
      const ppl = h.people;
      h.stay.keys = (h.stay.keys || []).map((_, k) => (ppl[k % 2] && !ppl[k % 2].yf && ppl[k % 2].band === 'adult' ? ppl[k % 2] : ppl[0]).name);
    });
    return out;
  }
  // Who picks up each room's keys: only the person named for that room may (2026 packet). Defaults to
  // the household's contact.
  const keysFor = d => Array.from({ length: d.stay.type === 'dorm' ? Math.max(1, d.stay.rooms) : 0 }, (_, i) => (d.stay.keys || [])[i] || d.household.contact);
  // Linen packets and air mattresses are limited; what's left after everyone else's reservations.
  function stockLeft(year, cfg, exceptEmail) {
    const used = { linens: 0, mattresses: 0 };
    households(year, cfg).filter(h => !exceptEmail || h.household.email !== exceptEmail).forEach(h => { if (h.stay.type === 'dorm') { used.linens += +h.stay.linens || 0; used.mattresses += +h.stay.mattresses || 0; } });
    return { linens: cfg.linen_stock ? Math.max(0, +cfg.linen_stock - used.linens) : null, mattresses: cfg.mattress_stock ? Math.max(0, +cfg.mattress_stock - used.mattresses) : null };
  }

  // Every household this viewer may see (a member: the year's; anyone else: their own), the
  // signed-in person's marked mine. Sample households are records marked sample on the server.
  function households(year, cfg) {
    const who = me();
    return load('registrations', year, []).filter(h => !h._pub && h.household)
      .map(h => Object.assign({}, h, { mine: !!who && (sameEmail(h.household.email, who.email) || !!(h.helper && h.helper.on && sameEmail(h.helper.email, who.email))) }));
  }

  // The year's meals from the schedule (the main schedule's meal rows), and how many of each age
  // group a household eats at each: everyone on the days they're here, unless they said otherwise.
  // A meal's id is its day and its name ("2027-05-30:supper", as the server's ogc_reg_meals), so a
  // household's answers stay on the right meal when the schedule is edited (register area, Oct 10).
  function mealsOf(model) {
    const out = [], seen = {};
    model.days.forEach(d => d.items.filter(it => it.kind === 'meal' && (it.audience === 'conference' || it.audience === 'all') && it.start != null).forEach(it => {
      const m = /^\s*(breakfast|lunch|supper|dinner)/i.exec(it.title), kind = m ? (m[1].toLowerCase() === 'dinner' ? 'supper' : m[1].toLowerCase()) : O.slug(it.title);
      const key = d.date + ':' + kind, n = seen[key] = (seen[key] || 0) + 1;
      out.push({ id: n > 1 ? key + '-' + n : key, day: d, title: it.title, start: it.start });
    }));
    return out;
  }
  // Each person counts on the days they're here (Oct 8: people come and go on different days).
  function eats(h, meal, days) {
    const c = { adult: 0, child: 0, baby: 0 };
    if (h.meals.off[meal.id] || daysHere(h, days).indexOf(meal.day) < 0) return c;
    const cust = h.meals.custom[meal.id];
    ['adult', 'child', 'baby'].forEach(b => { c[b] = cust ? cust[b] : h.people.filter(p => p.name && p.band === b && personDays(p, h, days).indexOf(meal.day) > -1).length; });
    return c;
  }

  /* ------------------------------------------------------------ rooms (the lodging committee's) */

  // rooms.csv → every room in order, and every floor: { id, hall, num, floor, beds, for }
  function readRooms(rows) {
    const rooms = [], floors = [];
    rows.filter(r => r.hall && !/^#/.test(r.hall) && +r.first && +r.last).forEach(r => {
      const f = { hall: r.hall, floor: +r.floor || 1, for: (r.for || 'families').toLowerCase(), share: (r.share || '').toLowerCase(), rooms: [] };
      for (let n = +r.first; n <= +r.last; n++) { const room = { id: r.hall + '|' + n, hall: r.hall, num: n, floor: f.floor, beds: +r.beds || 2, for: f.for }; f.rooms.push(room); rooms.push(room); }
      floors.push(f);
    });
    return { rooms, floors };
  }
  // Which household has each room: { roomId: householdId }, leaving one household out if asked.
  function takenBy(assign, except) {
    const t = {};
    Object.keys(assign).forEach(k => { if (k !== except) (assign[k] || []).forEach(r => { t[r] = k; }); });
    return t;
  }
  // A family's rooms side by side on one floor (family floors only). Ground floors go first to
  // those who ask, last to everyone else, so they're there for those who need them.
  function suggestRooms(h, floors, t) {
    const need = Math.max(1, h.stay.rooms || 1), g = f => (f.floor === 1) === !!h.stay.ground ? 0 : 1;
    const order = floors.slice().sort((a, b) => g(a) - g(b));
    // Where pairs of rooms share a bathroom, a family of two rooms gets a pair: try runs that start a pair first.
    // With a floor plan (ogc-map.js orderFloors), a run never crosses a gap: the rooms share walls or a bathroom.
    const runs = step => { for (const f of order) for (let i = 0; i + need <= f.rooms.length; i += (f.share === 'pairs' ? step : 1)) { const run = f.rooms.slice(i, i + need); if (run.every((r, k) => !t[r.id] && (k === 0 || !r.gap))) return run.map(r => r.id); } return null; };
    const best = (need % 2 === 0 && runs(2)) || runs(1);
    if (best) return best;
    for (const f of order) { const free = f.rooms.filter(r => !t[r.id]); if (free.length >= need) return free.slice(0, need).map(r => r.id); }
    return null;
  }
  // Rooms for every household in the list, planned together so no two get the same room. Returns
  // { householdId: [roomIds] } without changing anything. o (Oct 8, Lodging's board; Michael: Lodging
  // places "some of the older folks where they want"):
  //   o.first(h)  households to place first, on the ground floor (older, a walker, asked for it);
  //   o.rank(hall) how near a hall is to the dining hall (smaller first, for those placed first);
  //   o.near(h)   the household it asked to be near, to share its floor.
  function planRooms(assign, list, floors, o) {
    o = o || {};
    const t = takenBy(assign), plan = {}, first = h => !!(h.stay.ground || (o.first && o.first(h)));
    const rank = f => o.rank ? o.rank(f.hall) : 0;
    const order = list.slice().sort((a, b) => (first(b) - first(a)) || (b.stay.rooms - a.stay.rooms) || (a.at < b.at ? -1 : 1));
    order.forEach(h => {
      const need = Math.max(1, h.stay.rooms || 1), wantGround = first(h);
      // Its partner's floor first, if it asked to be near a household already placed.
      const pid = o.near && o.near(h), proom = pid && (plan[pid] || assign[pid] || [])[0];
      const pf = proom && floors.find(f => f.rooms.some(r => r.id === proom));
      const fl = floors.slice().sort((a, b) => ((b === pf) - (a === pf)) || (wantGround ? ((b.floor === 1) - (a.floor === 1)) || (rank(a) - rank(b)) : ((a.floor === 1) - (b.floor === 1)) || (rank(a) - rank(b))));
      const runs = step => { for (const f of fl) for (let i = 0; i + need <= f.rooms.length; i += (f.share === 'pairs' ? step : 1)) { const run = f.rooms.slice(i, i + need); if (run.every((r, k) => !t[r.id] && (k === 0 || !r.gap))) return run.map(r => r.id); } return null; };
      let s = (need % 2 === 0 && runs(2)) || runs(1);
      if (!s) for (const f of fl) { const free = f.rooms.filter(r => !t[r.id]); if (free.length >= need) { s = free.slice(0, need).map(r => r.id); break; } }
      if (s) { plan[h.id] = s; s.forEach(r => { t[r] = h.id; }); }
    });
    return plan;
  }
  const assignRooms = (assign, list, floors, o) => Object.assign(assign, planRooms(assign, list, floors, o));
  // The rooms given so far: as saved in this browser, or (prototype) most samples already placed and
  // the latest few still waiting.
  function roomsGiven(year, hh, floors) {
    const stored = load('rooms', year, null), assign = {}, ids = {}, real = {};
    hh.forEach(h => { ids[h.id] = true; });
    floors.forEach(f => f.rooms.forEach(r => { real[r.id] = true; }));
    if (stored) Object.keys(stored).forEach(k => { if (ids[k]) assign[k] = stored[k].filter(r => real[r]); });
    // A Conference still ahead (the mockup's 2027 and later) starts with every household unassigned.
    else if (+year > 2026) { /* Lodging's to do */ }
    else {
      const samples = hh.filter(h => h.sample && h.stay.type === 'dorm').sort((a, b) => a.at < b.at ? -1 : 1);
      assignRooms(assign, samples.slice(0, samples.length - 5), floors.filter(f => f.for === 'families'));
    }
    // Oct 8: rooms a household chose on the map are theirs until lodging changes them.
    const t = takenBy(assign);
    hh.forEach(h => { const c = (h.stay && h.stay.chosen || []).filter(r => real[r] && !t[r]); if (!(h.id in assign) && h.stay.type === 'dorm' && c.length) { assign[h.id] = c; c.forEach(r => { t[r] = h.id; }); } });
    return assign;
  }

  /* ------------------------------------------------------------ files */

  const stamp = () => new Date().toISOString().replace(/[-:]/g, '').replace(/\.\d+Z$/, 'Z');
  const icsText = v => String(v).replace(/[\\,;]/g, m => '\\' + m).replace(/\n/g, '\\n');
  // events: { uid, date, endDate (all day), or start and end in minutes; summary, location, description, remind }
  function ics(events, tz) {
    const L = ['BEGIN:VCALENDAR', 'VERSION:2.0', 'PRODID:-//ogbbc.org//Annual Conference//EN'];
    const utc = (date, min) => O.wallToInstant(date, min, tz || 'America/Indiana/Indianapolis').toISOString().replace(/[-:]/g, '').replace(/\.\d+Z$/, 'Z');
    events.forEach(e => {
      L.push('BEGIN:VEVENT', 'UID:' + e.uid + '@ogbbc.org', 'DTSTAMP:' + stamp());
      if (e.start == null) L.push('DTSTART;VALUE=DATE:' + e.date.replace(/-/g, ''), 'DTEND;VALUE=DATE:' + O.isoAddDays(e.endDate || e.date, 1).replace(/-/g, ''));
      else L.push('DTSTART:' + utc(e.date, e.start), 'DTEND:' + utc(e.date, e.end));
      L.push('SUMMARY:' + icsText(e.summary));
      if (e.location) L.push('LOCATION:' + icsText(e.location));
      if (e.description) L.push('DESCRIPTION:' + icsText(e.description));
      if (e.remind) L.push('BEGIN:VALARM', 'TRIGGER:-P1D', 'ACTION:DISPLAY', 'DESCRIPTION:' + icsText(e.remind), 'END:VALARM');
      L.push('END:VEVENT');
    });
    return L.concat('END:VCALENDAR').join('\r\n') + '\r\n';
  }
  function shiftEvent(sh, s, year, who) {
    return {
      uid: sh.id + (who ? '-' + who.toLowerCase().replace(/[^a-z0-9]+/g, '-') : ''), date: sh.day.date, start: sh.start, end: sh.end,
      summary: 'Volunteer: ' + (jobSaid(sh.role, sh.committee) ? jobName(sh.role, sh.committee) : sh.role + ' (' + sh.committee + ')') + (who ? ', ' + who : ''),
      location: [sh.place && sh.place.name, s.venue, s.city].filter(Boolean).join(', '),
      description: (sh.note ? sh.note + '\n' : '') + 'Annual Conference ' + year + '. To change or cancel: My sign-ups on ogbbc.org.',
      remind: 'Tomorrow: ' + sh.role
    };
  }
  function save(text, type, name) {
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([text], { type }));
    a.download = name;
    document.body.appendChild(a); a.click(); a.remove();
  }
  // The committees' pages share the editors' frame: the site's header steps aside, Back returns to the year.
  function wsHead(o) {
    document.documentElement.classList.add('adm-full');
    const back = '<svg class="wk-i" viewBox="0 0 24 24" aria-hidden="true"><path d="M14.5 5.5 8 12l6.5 6.5" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>';
    // v3: back to the part of the year it's made from (Registration, The schedule…), or the year.
    return '<header class="ws-bar ws-bar--page"><div class="ws-bar__in"><a class="ws-back" href="../year/?year=' + O.esc(o.year) + (o.part ? '&part=' + O.esc(o.part[0]) : '') + '">' + back + '<span>' + (o.part ? O.esc(o.part[1]) : O.esc(o.year) + ' Annual Conference') + '</span></a>' +
      '<div class="ws-title"><p class="wk-kicker">' + O.esc(o.kicker) + '</p><h1>' + O.esc(o.title) + '</h1></div>' + (o.stats ? '<p class="ws-stats">' + o.stats + '</p>' : '') + (o.tools ? '<p class="ws-tools">' + o.tools + '</p>' : '') + '</div></header>';
  }
  // A cell someone typed that starts like a formula (= + - @, a tab or a return) is written with an
  // apostrophe first, so Excel shows it as text and never runs it (CSV injection).
  const cellSafe = v => /^[=+\-@\t\r]/.test(v) && !/^-?\d+(\.\d+)?$/.test(v) ? "'" + v : v;
  const csv = rows => rows.map(r => r.map(v => { v = cellSafe(String(v == null ? '' : v)); return /[",\n\r]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v; }).join(',')).join('\n') + '\n';

  // Who does each of the year's parts (Oct 8, Michael: "the schedule is traditionally probably not
  // audiovisual's job… pretty assuming that everything's going to remain the same"): the COA's choice each
  // year (settings owner_<part>), these until they choose.
  const OWNER = { conference: 'Committee of Arrangements', schedule: 'Committee of Arrangements', requests: 'Every committee', registration: 'Lodging committee', helping: 'Every committee', youngfolks: 'Young Folks committee', packet: 'Committee of Arrangements' };
  // Who does a part is the COA's choice each year (settings owner_<part>); none until they choose.
  // OWNER is kept only as v3's old suggestions, never shown as fact (no-assumed-owners).
  const ownerOf = (settings, part) => (settings && settings['owner_' + part]) || '';
  // The year's picture (settings: photo), or the Brotherhood Council Meeting the site already uses.
  // Plugin: the plugin's own copy of the picture, so nothing loads from another site.
  const PHOTO = (W.assets || '../shared/') + (W.assets ? 'shared/' : '') + 'img/conference-auditorium.jpg';
  const photoOf = s => (s && s.photo) || PHOTO;

  // One Leave sheet everywhere a volunteer leaves a shift (after the fourth critic, Oct 15: Your sign-ups had
  // a red button and other pills, the emailed link and the page tan ones, the page's own said "Keep"): the
  // volunteer page's opened row and Your week, the emailed "Can't make it?" link, and Your sign-ups all draw
  // it here. The question, the shift (or a toggle a shift when several), a toggle a person when several (all
  // on at first), the line saying who goes, "The committee head is told", Leave as the one filled button
  // (the site's tan), Find replacement only for one person's one place, Keep shift. Each page wires the
  // controls: [data-lv] (go · swap · keep) and the inputs lvshift / lvwho, inside [data-lv-for].
  //   o: { scope, id, heading, hTag, when, shifts: [{ value, label, sub, on }], people: [{ value, label, on }],
  //        goes, head, swap, go, busy, disabled, keep, err, lead }
  const lvEsc = t => String(t == null ? '' : t).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
  const LV_CHECK = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m5.5 12.5 4 4 9-9" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  const leaveSheet = o => {
    const id = o.id || 'ogc-lv', ht = o.hTag || 'p', shifts = o.shifts || [], people = o.people || [];
    let h = '<section class="ogc-lv" data-lv-for="' + lvEsc(o.scope || '') + '" role="group" aria-labelledby="' + id + '-h">' + (o.lead || '') +
      '<' + ht + ' class="ogc-lv__h" id="' + id + '-h">' + lvEsc(o.heading || 'Leave this shift?') + '</' + ht + '>';
    if (shifts.length > 1) {
      h += '<p class="ogc-lv__l" id="' + id + '-s">Shifts</p><div class="ogc-lv__ss" role="group" aria-labelledby="' + id + '-s">' + shifts.map(x =>
        '<label class="ogc-lv__s"><input type="checkbox" name="lvshift" value="' + lvEsc(x.value) + '"' + (x.on ? ' checked' : '') + '><span><b>' + lvEsc(x.label) + '</b>' + (x.sub ? '<small>' + lvEsc(x.sub) + '</small>' : '') + '</span></label>').join('') + '</div>';
    } else if (o.when) h += '<p class="ogc-lv__when">' + lvEsc(o.when) + '</p>';
    if (people.length > 1) {
      h += '<p class="ogc-lv__l" id="' + id + '-w">Who’s leaving</p><div class="ogc-lv__pp" role="group" aria-labelledby="' + id + '-w">' + people.map(x =>
        '<label class="ogc-lv__tog"><input type="checkbox" name="lvwho" value="' + lvEsc(x.value) + '"' + (x.on ? ' checked' : '') + '><span>' + LV_CHECK + lvEsc(x.label) + '</span></label>').join('') + '</div>';
    }
    h += '<p class="ogc-lv__who" data-lv-goes aria-live="polite">' + lvEsc(o.goes || '') + '</p>' +
      // Said only when a Leave now reaches the head (o.head false: it doesn't; after the eighth critic).
      (o.head === false ? '' : '<p class="ogc-lv__note">' + lvEsc(o.head || 'The committee head is told') + '</p>') +
      '<p class="ogc-lv__btns"><button type="button" class="wk-btn ogc-lv__go" data-lv="go"' + (o.disabled || o.busy ? ' disabled' : '') + '>' + lvEsc(o.busy ? 'Leaving…' : o.go || 'Leave shift') + '</button>' +
      (o.swap ? '<button type="button" class="wk-linklike" data-lv="swap">Find replacement</button>' : '') +
      '<button type="button" class="wk-linklike" data-lv="keep">' + lvEsc(o.keep || 'Keep shift') + '</button></p>' +
      (o.err ? '<p class="ogc-lv__err" role="alert">' + lvEsc(o.err) + '</p>' : '') + '</section>';
    return h;
  };

  O.signups = { leaveSheet, OWNER, ownerOf, photoOf, wsHead, me, setMe, signOut, sameEmail, nameFor, load, store, withEdits, mealsOf, eats, findDay, expandShifts, samplePeople, seatSamples, sampleFilled, POOL, firstL, jobSaid, jobName, jobWords, eveOf, isNight, dayShort, namesWords, initials, span, settings, nightsOf, mainNights, isEarly, nightShort, earlyDate, money, plural, cost, daysHere, nightsFor, personDays, label, householdName, surname, nightSpan, sampleHouseholds, households, keysFor, stockLeft, readRooms, takenBy, suggestRooms, planRooms, assignRooms, roomsGiven, ics, shiftEvent, save, csv };
})();
