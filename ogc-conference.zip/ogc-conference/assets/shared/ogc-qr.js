/*
 * ogc-qr.js — a QR code made on the phone itself, with nothing downloaded, so the Conference app's
 * Share (Nov 5, 2026) works with no signal: someone across the table scans the app's link from the
 * screen.
 *
 * Written from the QR standard (ISO/IEC 18004): byte mode (the text as UTF-8), error correction level
 * M (about 15% of the code may be lost and it still reads), the smallest of versions 1–40 that holds
 * the text, all eight masks scored by the standard's four penalty rules (the lowest is kept), and the
 * format and version information.
 *
 *   OGC.qr.encode(text)     { version, size, mask, dark }   dark[row][col], true for a dark module
 *   OGC.qr.svg(text, o)     '<svg …>': dark ink on white with a 4-module quiet zone, one path.
 *                           o.cell: CSS px a module (whole pixels draw crisp); o.label: its aria-label
 *                           (none: aria-hidden); o.ink: the colour of the dark modules (#000)
 *
 * Plain JavaScript, no build step. A text too long for version 40 (over 2,331 bytes) throws.
 * Loaded on the Conference app's page only (module-public.php), after ogc-core.js.
 */
(function () {
  'use strict';

  // Level M, by version (1–40): error correction codewords in each block, and the number of blocks.
  const EC_PER_BLOCK = [0, 10, 16, 26, 18, 24, 16, 18, 22, 22, 26, 30, 22, 22, 24, 24, 28, 28, 26, 26, 26,
    26, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28];
  const BLOCKS = [0, 1, 1, 1, 2, 2, 4, 4, 4, 5, 5, 5, 8, 9, 9, 10, 10, 11, 13, 14, 16, 17, 17, 18, 20, 21,
    23, 25, 26, 28, 29, 31, 33, 35, 37, 38, 40, 43, 45, 47, 49];
  const LEVEL_M = 0; // the level's two bits in the format information (L 01, M 00, Q 11, H 10)

  // The modules left for data and error correction once the fixed patterns are drawn.
  function rawModules(v) {
    let n = (16 * v + 128) * v + 64;
    if (v >= 2) {
      const a = Math.floor(v / 7) + 2;
      n -= (25 * a - 10) * a - 55;
      if (v >= 7) n -= 36;
    }
    return n;
  }
  const dataCodewords = v => Math.floor(rawModules(v) / 8) - EC_PER_BLOCK[v] * BLOCKS[v];

  // Where the alignment patterns' centres are, along each side.
  function alignAt(v) {
    if (v === 1) return [];
    const n = Math.floor(v / 7) + 2, size = v * 4 + 17;
    const step = Math.floor((v * 8 + n * 3 + 5) / (n * 4 - 4)) * 2;
    const at = [6];
    for (let p = size - 7; at.length < n; p -= step) at.splice(1, 0, p);
    return at;
  }

  /* ------------------------------------------- Reed–Solomon over GF(256), polynomial 0x11D */

  function mul(x, y) {
    let z = 0;
    for (let i = 7; i >= 0; i--) {
      z = (z << 1) ^ ((z >>> 7) * 0x11d);
      z ^= ((y >>> i) & 1) * x;
    }
    return z;
  }
  // The generator polynomial of the given degree, (x − 1)(x − 2)(x − 4)…, its leading 1 left out.
  function divisor(degree) {
    const r = new Array(degree).fill(0);
    r[degree - 1] = 1;
    let root = 1;
    for (let i = 0; i < degree; i++) {
      for (let j = 0; j < degree; j++) {
        r[j] = mul(r[j], root);
        if (j + 1 < degree) r[j] ^= r[j + 1];
      }
      root = mul(root, 2);
    }
    return r;
  }
  function remainder(data, div) {
    const r = new Array(div.length).fill(0);
    data.forEach(b => {
      const f = b ^ r.shift();
      r.push(0);
      div.forEach((c, i) => { r[i] ^= mul(c, f); });
    });
    return r;
  }

  /* ------------------------------------------- the codewords */

  // Byte mode: 0100, the count (8 bits to version 9, 16 after), the bytes, the terminator, then the pad
  // bytes 0xEC 0x11 … to fill the version's data codewords.
  function dataFor(bytes) {
    const need = v => 4 + (v < 10 ? 8 : 16) + 8 * bytes.length;
    let v = 1;
    while (v <= 40 && need(v) > dataCodewords(v) * 8) v++;
    if (v > 40) throw new RangeError('Too long for a QR code');
    const cap = dataCodewords(v) * 8, bits = [];
    const put = (val, n) => { for (let i = n - 1; i >= 0; i--) bits.push((val >>> i) & 1); };
    put(4, 4);
    put(bytes.length, v < 10 ? 8 : 16);
    bytes.forEach(b => put(b, 8));
    put(0, Math.min(4, cap - bits.length));
    put(0, (8 - bits.length % 8) % 8);
    for (let pad = 0xec; bits.length < cap; pad ^= 0xec ^ 0x11) put(pad, 8);
    const data = [];
    for (let i = 0; i < bits.length; i += 8) data.push(bits.slice(i, i + 8).reduce((a, b) => a * 2 + b, 0));
    return { v, data };
  }

  // Split into the version's blocks (the short ones first, one data codeword fewer), each with its own
  // error correction; then interleaved: the blocks' first data codewords, their second…, then the same
  // for the error correction.
  function interleave(v, data) {
    const nb = BLOCKS[v], ec = EC_PER_BLOCK[v], raw = Math.floor(rawModules(v) / 8);
    const short = nb - raw % nb, shortLen = Math.floor(raw / nb) - ec;
    const div = divisor(ec), blocks = [];
    let k = 0;
    for (let i = 0; i < nb; i++) {
      const len = shortLen + (i < short ? 0 : 1), d = data.slice(k, k + len);
      k += len;
      blocks.push({ d, e: remainder(d, div) });
    }
    const out = [];
    for (let i = 0; i <= shortLen; i++) blocks.forEach(b => { if (i < b.d.length) out.push(b.d[i]); });
    for (let i = 0; i < ec; i++) blocks.forEach(b => out.push(b.e[i]));
    return out;
  }

  /* ------------------------------------------- the symbol */

  // The eight masks, by column x and row y: where true, a data module is flipped.
  const MASKS = [
    (x, y) => (x + y) % 2 === 0,
    (x, y) => y % 2 === 0,
    (x, y) => x % 3 === 0,
    (x, y) => (x + y) % 3 === 0,
    (x, y) => (Math.floor(x / 3) + Math.floor(y / 2)) % 2 === 0,
    (x, y) => x * y % 2 + x * y % 3 === 0,
    (x, y) => (x * y % 2 + x * y % 3) % 2 === 0,
    (x, y) => ((x + y) % 2 + x * y % 3) % 2 === 0
  ];

  // The format information (level and mask, BCH(15,5), masked with 0x5412), twice, and the dark module.
  function drawFormat(dark, size, mask) {
    const d = (LEVEL_M << 3) | mask;
    let r = d;
    for (let i = 0; i < 10; i++) r = (r << 1) ^ ((r >>> 9) * 0x537);
    const bits = ((d << 10) | r) ^ 0x5412, bit = i => ((bits >>> i) & 1) === 1;
    const set = (x, y, on) => { dark[y][x] = on; };
    for (let i = 0; i <= 5; i++) set(8, i, bit(i));
    set(8, 7, bit(6)); set(8, 8, bit(7)); set(7, 8, bit(8));
    for (let i = 9; i < 15; i++) set(14 - i, 8, bit(i));
    for (let i = 0; i < 8; i++) set(size - 1 - i, 8, bit(i));
    for (let i = 8; i < 15; i++) set(8, size - 15 + i, bit(i));
    set(8, size - 8, true);
  }

  // The standard's penalty: 1, runs of five or more of one colour in a row or column (3, and 1 more for
  // each past five); 2, each 2 × 2 block of one colour (3); 3, each finder-like 1:1:3:1:1 run with four
  // light modules on one side, the edge counting as light (40); 4, 10 for each whole 5% the dark
  // modules are away from half.
  function penalty(m) {
    const n = m.length;
    let p = 0, darkCount = 0;
    const lines = [];
    for (let i = 0; i < n; i++) { lines.push(m[i]); lines.push(m.map(row => row[i])); }
    lines.forEach(l => {
      let run = 1;
      for (let i = 1; i <= n; i++) {
        if (i < n && l[i] === l[i - 1]) run++;
        else { if (run >= 5) p += run - 2; run = 1; }
      }
      const at = k => k >= 0 && k < n && l[k];
      for (let i = 0; i + 7 <= n; i++) {
        if (!(at(i) && !at(i + 1) && at(i + 2) && at(i + 3) && at(i + 4) && !at(i + 5) && at(i + 6))) continue;
        const before = !at(i - 1) && !at(i - 2) && !at(i - 3) && !at(i - 4);
        const after = !at(i + 7) && !at(i + 8) && !at(i + 9) && !at(i + 10);
        if (before || after) p += 40;
      }
    });
    for (let y = 0; y < n; y++) {
      for (let x = 0; x < n; x++) {
        if (m[y][x]) darkCount++;
        if (x + 1 < n && y + 1 < n && m[y][x] === m[y][x + 1] && m[y][x] === m[y + 1][x] && m[y][x] === m[y + 1][x + 1]) p += 3;
      }
    }
    return p + 10 * Math.floor(Math.abs(darkCount * 100 / (n * n) - 50) / 5);
  }

  function encode(text) {
    const bytes = Array.from(new TextEncoder().encode(String(text)));
    const { v, data } = dataFor(bytes);
    const words = interleave(v, data), size = v * 4 + 17;
    const dark = [], fixed = [];
    for (let y = 0; y < size; y++) { dark.push(new Array(size).fill(false)); fixed.push(new Array(size).fill(false)); }
    const set = (x, y, on) => { dark[y][x] = on; fixed[y][x] = true; };

    // The timing lines, then the three finders with their light borders, then the alignment patterns
    // (none on a finder).
    for (let i = 0; i < size; i++) { set(6, i, i % 2 === 0); set(i, 6, i % 2 === 0); }
    [[3, 3], [size - 4, 3], [3, size - 4]].forEach(([cx, cy]) => {
      for (let dy = -4; dy <= 4; dy++) {
        for (let dx = -4; dx <= 4; dx++) {
          const x = cx + dx, y = cy + dy, d = Math.max(Math.abs(dx), Math.abs(dy));
          if (x >= 0 && x < size && y >= 0 && y < size) set(x, y, d !== 2 && d !== 4);
        }
      }
    });
    const al = alignAt(v), last = al.length - 1;
    al.forEach((ax, i) => al.forEach((ay, j) => {
      if ((i === 0 && j === 0) || (i === 0 && j === last) || (i === last && j === 0)) return;
      for (let dy = -2; dy <= 2; dy++) for (let dx = -2; dx <= 2; dx++) set(ax + dx, ay + dy, Math.max(Math.abs(dx), Math.abs(dy)) !== 1);
    }));
    // The format information's place, kept now and drawn for each mask below.
    drawFormat(dark, size, 0);
    for (let i = 0; i < 9; i++) { fixed[8][i] = fixed[i][8] = true; }
    for (let i = 0; i < 8; i++) { fixed[8][size - 1 - i] = fixed[size - 1 - i][8] = true; }
    // The version information (BCH(18,6)), from version 7: two 6 × 3 blocks.
    if (v >= 7) {
      let r = v;
      for (let i = 0; i < 12; i++) r = (r << 1) ^ ((r >>> 11) * 0x1f25);
      const bits = (v << 12) | r;
      for (let i = 0; i < 18; i++) {
        const on = ((bits >>> i) & 1) === 1, a = size - 11 + i % 3, b = Math.floor(i / 3);
        set(a, b, on); set(b, a, on);
      }
    }

    // The codewords, two columns at a time from the bottom right, up then down, around what's fixed.
    let i = 0;
    for (let right = size - 1; right >= 1; right -= 2) {
      if (right === 6) right = 5;
      const up = ((right + 1) & 2) === 0;
      for (let vert = 0; vert < size; vert++) {
        const y = up ? size - 1 - vert : vert;
        for (let j = 0; j < 2; j++) {
          const x = right - j;
          if (fixed[y][x] || i >= words.length * 8) continue;
          dark[y][x] = ((words[i >>> 3] >>> (7 - (i & 7))) & 1) === 1;
          i++;
        }
      }
    }

    // Each mask in turn; the one the penalty likes best is kept.
    let best = null;
    MASKS.forEach((f, mask) => {
      const m = dark.map((row, y) => row.map((on, x) => fixed[y][x] ? on : on !== f(x, y)));
      drawFormat(m, size, mask);
      const score = penalty(m);
      if (!best || score < best.score) best = { mask, score, m };
    });
    return { version: v, size, mask: best.mask, dark: best.m };
  }

  const attr = s => String(s).replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;');
  function svg(text, o) {
    o = o || {};
    const q = encode(text), b = 4, n = q.size + 2 * b, cell = o.cell || 1;
    // Each row's runs of dark modules, one rectangle a run.
    let d = '';
    q.dark.forEach((row, y) => {
      for (let x = 0; x < q.size; x++) {
        if (!row[x]) continue;
        let e = x;
        while (e + 1 < q.size && row[e + 1]) e++;
        d += 'M' + (x + b) + ' ' + (y + b) + 'h' + (e - x + 1) + 'v1h-' + (e - x + 1) + 'z';
        x = e;
      }
    });
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' + n + ' ' + n + '" width="' + n * cell + '" height="' + n * cell + '" shape-rendering="crispEdges"' +
      (o.label ? ' role="img" aria-label="' + attr(o.label) + '"' : ' aria-hidden="true"') + ' data-modules="' + n + '">' +
      '<rect width="' + n + '" height="' + n + '" fill="#fff"/><path d="' + d + '" fill="' + attr(o.ink || '#000') + '"/></svg>';
  }

  (window.OGC = window.OGC || {}).qr = { encode, svg };
})();
