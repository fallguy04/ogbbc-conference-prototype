/*
 * ogc-map-route.js — Directions on the campus, from the streets to the room (Nov 5, round 2 of the map;
 * Michael, Nov 4: directions are ours end to end, Google Maps is no longer the fallback). docs/34 §4.5–4.10
 * (the planner and what each step shows), §10.2–10.5 (the words, distances and times), §12.2 (the graph).
 *
 * The planner over the one router (ogc-map.js, router(c, build)) and the steps it says. Nothing here draws:
 * the guide's Places draws what plan() returns. Mechanical (docs/25): the route is Dijkstra over lengths,
 * the sentences are §10.2's fixed templates filled from the graph, and nothing is generated or guessed
 * (a building with no door in the campus record gets today's guessed doors, never named).
 *
 *   const R = O.map.routerOf(campus, { walk, area, index });   // the campus record and the public build
 *   const r = O.map.plan(R, from, to, o);
 *
 * from, to: one of
 *   { lat, lng }               My location (the phone's fix)
 *   { x, y }                   a point on the campus map (metres), outdoors; with { floor }, a tap on a
 *                              drawn building's opened floor: the nearest hall point on that floor
 *   { code: 'B/HW' }           a place on the schedule, by its code (o.places: the year's places.csv rows)
 *   { building: 'B' }          a building, by its code or name: its best door
 *   { door: 'f-b-v100se' }     a door, by its id in the campus record (or the build's)
 *   { room: 'B|1|143' }        a public room: building code, floor, number
 *   { hall: 'Hodson Hall' }    a household's hall (My room): its best door, said so (no hall floor is public)
 * o: { stepFree, date: 'YYYY-MM-DD', time: 'HH:MM' (venue time, both for the doors' hours and closures),
 *      places (the year's places by code), keys (key-only doors allowed; never for the public),
 *      unchecked (with stepFree, a door nobody has checked yet is allowed too; never one checked and found
 *      not step-free: the planner asks for it only after "Doors not checked", docs/35 §6 question 5) }
 * →  { ok: true, from, to, metres, sec, min, distance, outdoorMetres, legs, legsText, steps, parts, door,
 *      exit, guessedDoor, notes, stepFree, unmapped }   (the router is made once a campus and build
 *      object: keep it). unmapped: an end is a room the build hasn't got (J/LOFT), so the route goes to
 *      its building's door; the page may try the place's other end (its alt). Its note says so plainly
 *      ("Ends at the Chapel’s door"), as an outdoor place's does.
 *    { ok: false, reason, why?, building? }   reason: 'No step-free route' (why: 'Doors not checked'
 *      while a building it must use has a door not yet checked, else 'No step-free door';
 *      '2nd floor · No elevator'), 'Set start' (My location inside a drawn building: building), 'Not on
 *      campus', 'Not on the map yet' (an outdoor place not pinned with no building beside it: one beside
 *      a building, Nebraska Green, ends at that building's door, "Ends at the Rec Center’s door"), 'Not on
 *      the map', 'Doors closed', 'No route', 'Same place'
 * A step: { kind: 'outside' | 'door' | 'inside' | 'floor' | 'end', building (code, or null outdoors),
 *   floor (0 outdoors), text, detail, metres, distance, at: [x, y] (where the step starts), pts (its
 *   stretch), box: [x0, y0, x1, y1] (the stretch to frame), icon, turn (degrees, + right) }
 * campus/FORMAT.md ("The plugin's router") and DEV.md say the same.
 */
(function () {
  'use strict';
  const O = window.OGC, M = O.map;
  const norm = M.norm;
  const BUILT = { hall: 1, dining: 1, worship: 1, venue: 1, other: 1 };
  const LM = 6;                        // metres: a landmark this near a turn or a stretch (§10.2)
  const FAR = 1500;                    // metres from the campus: Not on campus (§4.11)
  const TOL = { out: 1.5, in: .8 };    // metres: a line's small wiggles aren't turns
  // metres: bends this close together are one turn (the way in to the first against the way out of the
  // last: a jog right and back left is no turn), and a bend this near the start or the end of a stretch is
  // no step (the first step's heading and the end's side say it). About 30 ft outdoors, 20 ft inside (Nov 5,
  // the checks: at 15 ft Barnes's lounges read as a run of 20 ft steps; at 30 ft a hall's real zigzag,
  // left and then right 7 m on, merged into no turn at all).
  const MERGE = { out: 10, in: 6 };
  // metres: a turn's angle is the way walked this far either side of it. Inside it's 10 m (round 2 part 2,
  // the last checks: over 6 m, the half-metre jogs of IWU's centre lines read as 25–35° on a straight hall,
  // and "Left down the hall" was said there 131 times; over 10 m they're under 20°, a real corner still 90°).
  const NET = { out: 10, in: 10 };
  const BRANCH = 4;                    // metres: a branching hall or path this near a bend makes it a step
  const SPUR = 3;                      // metres: inside, a branch shorter than this, ending there, is the line's own stub
  // Outdoors, a step only where a person could go wrong (Nov 5, evening; Michael: "every single little turn
  // on the … sidewalk is probably not necessary"; docs/34 §10.2):
  //   a jog, a turn and its opposite within len metres (50 ft) that ends within head degrees of the way in
  //   (round a crosswalk's kerb ramps, or over to the next path of a grid), is no turn;
  //   a way that leaves a turn is followed WAY metres to take its heading;
  //   a crossing with no street name (a drive, a lot) no longer than XSHORT metres is no step of its own:
  //   its step's detail says "Across the drive".
  // After the review (Nov 5, late), where a stranger went wrong:
  //   a turn of 60° or more is a step unless the route's own way is the one someone told nothing would take
  //   (the path's own bend); one of SLIGHT_MIN–60° only where someone told nothing would go wrong (strayAt,
  //   below): a fork as much as a bend off a straight way. "Keep left" at a Y (the route the outer of the
  //   ways within FORK° as straight as it, none within STRAIGHTER° of straight on), or a dogleg at a fork
  //   (two bends under 60° and under MERGE apart: one step); else "Slight left"; SHARP° or more is "Sharp left";
  //   a jog's bends are of a size (the smaller at least JOG.alike of the larger), and it's no turn only where
  //   someone told nothing keeps on beside the route;
  //   a named street is crossed wherever the walk goes from one side of it to the other: along it no more than
  //   RUN metres, from where it meets it; longer, where it leaves it. Its step runs to the far kerb, unless
  //   the next street's crossing is BLOCK metres or less straight on.
  const JOG = { len: 15, head: 30, alike: .5 };
  const WAY = 8, STRAIGHTER = 15, XSHORT = 20;
  const FORK = 15, SLIGHT_MIN = 10, SHARP = 120, RUN = 25, BLOCK = 200;
  // Someone told nothing at a junction takes the way nearest straight on (and any within tie° as near), for
  // len metres, the way nearest straight on at each junction: beside the route if it ends within off metres
  // of it, or comes back within back metres of it after 15 m; else off it.
  const STRAY = { len: 40, off: 12, back: 2.5, tie: 20 };
  // A street crossed while carrying straight on along another (Nov 5, night; Michael: down Washington
  // Street, a "Cross East 36th Street", "Cross East 37th Street"… step a block) is no step: the walk along
  // the street is one "Continue on {street}", its detail the streets it crosses. Along a street: on its line,
  // or beside it within ALONG.w metres with its way within ALONG.deg°, at each of ALONG.at metres before the
  // crossing and after its far kerb (the same street both sides, not the one crossed); straight on: the way
  // walked ALONG.head metres either side within ALONG.deg°. Where the walk changes way it's "Cross {street}".
  const ALONG = { w: 15, deg: 30, at: [4, 10, 16], head: 15 };
  // A turn left unsaid where the next step's words send someone the wrong way (Nov 5, night; the check
  // walked Barnes → Troyer: at a T where the route goes right, the card said "Turn left · 50 ft", and a path
  // goes left there): a turn of TRAP.deg° or more at a junction, the next step a turn TRAP.len metres or
  // less on, and another way leaving that junction on the side the next step turns (TRAP.way° or more off
  // the way in), is a step of its own. And a "Continue on {street}" ends where the walk turns ALONG.deg° or
  // more off its street (the check: "Continue on West 44th Street" ran on 51 m up South Washington Street).
  const TRAP = { deg: 45, len: 60, way: 20 };
  // A kerb (the router's line from a sidewalk to a road's junction, which OpenStreetMap seldom draws) is no
  // way of its own to anyone told nothing: only the route's own when it takes one.
  const kerbOf = e => e.s.kind === 'kerb';
  // A room whose door carries no number (§4.10: the Piazza, a lobby) by IWU's name for it: its name is the
  // sign. Every other room's sign is its number. (A fixed list; the walk-through checks it.)
  const OPEN = /\b(LOBBY|FOYER|TERRACE|PIAZZA|COMMONS|ATRIUM|CONCOURSE|GYM|GYMNASIUM|ARENA|AUDITORIUM|BALCONY|THEATRE|THEATER|NATATORIUM|FIELDHOUSE)\b/i;

  const dist = (a, b) => Math.hypot(a[0] - b[0], a[1] - b[1]);
  const plen = P => { let k = 0; for (let i = 1; i < P.length; i++) k += dist(P[i - 1], P[i]); return k; };
  const head = (a, b) => Math.atan2(b[1] - a[1], b[0] - a[0]);
  // The signed turn from heading h1 to h2, in degrees: + is right (the campus frame's y runs south).
  const turnOf = (h1, h2) => { let t = (h2 - h1) * 180 / Math.PI; while (t > 180) t -= 360; while (t < -180) t += 360; return t; };
  const segD = (p, a, b) => { const dx = b[0] - a[0], dy = b[1] - a[1], L = dx * dx + dy * dy, t = L ? Math.max(0, Math.min(1, ((p[0] - a[0]) * dx + (p[1] - a[1]) * dy) / L)) : 0; return { d: Math.hypot(a[0] + t * dx - p[0], a[1] + t * dy - p[1]), t, q: [a[0] + t * dx, a[1] + t * dy] }; };
  const polyD = (p, pts) => M.inPoly(p[0], p[1], pts) ? 0 : pts.reduce((m, a, i) => Math.min(m, segD(p, a, pts[(i + 1) % pts.length]).d), Infinity);
  const title = s => String(s || '').toLowerCase().replace(/\b[a-z]/g, ch => ch.toUpperCase());
  const floorWord = n => { const w = O.floorName(n); return /^\d/.test(w) ? w : w.charAt(0).toLowerCase() + w.slice(1); };
  const floorShort = n => O.floorName(n).replace(/ floor$/, '');
  // Headings over a stretch of line, never over its last or first segment alone (the checks, Nov 5: a door's
  // half-metre jog, or a snap's stub, gave "Left down the hall" where the hall goes straight on).
  const cumOf = P => { const c = [0]; for (let i = 1; i < P.length; i++) c.push(c[i - 1] + dist(P[i - 1], P[i])); return c; };
  // the point s metres along P (cum: its running lengths), held to its ends
  const along = (P, cum, s) => {
    const L = cum[cum.length - 1];
    if (s <= 0) return P[0];
    if (s >= L) return P[P.length - 1];
    let i = 1;
    while (i < cum.length - 1 && cum[i] < s) i++;
    const l = cum[i] - cum[i - 1], t = l ? (s - cum[i - 1]) / l : 0;
    return [P[i - 1][0] + (P[i][0] - P[i - 1][0]) * t, P[i - 1][1] + (P[i][1] - P[i - 1][1]) * t];
  };
  // the way walked over a line's last m metres (into its end), or its first m metres (out of its start)
  const headIn = (P, m) => { const c = cumOf(P), L = c[c.length - 1]; return L < .3 ? null : head(along(P, c, Math.max(0, L - m)), P[P.length - 1]); };
  const headOut = (P, m) => { const c = cumOf(P), L = c[c.length - 1]; return L < .3 ? null : head(P[0], along(P, c, Math.min(L, m))); };
  const WIN = { out: 6, in: 3 };   // metres: the heading either side of a bend, taken over this much line
  const BEND = 12;                 // degrees: less, measured so, isn't a bend at all
  const HEAD_IN = 4, FIRST = 30;   // metres: the way in through a door; the first stretch's own way, at most
  const END_W = 6, AHEAD = 30;     // the end: metres of hall its way is taken over; degrees still "ahead"

  /* ================================================================ names */

  // A place's name without its building, as the map labels it ("Henry West Room 143", "Lobby").
  function nameIn(c, p, places, b) {
    const n = String(p.name || p.code).replace(/\s*\(([^)]+)\)$/, (m, w) => b && norm(b.name).indexOf(norm(w.split(' ')[0])) > -1 ? '' : m);
    const sh = b ? (M.shortsFor(c, places)[b.name] || M.shortOf(b)) : '';
    const lead = [sh, b ? b.name : ''].filter(Boolean).find(w => n.toLowerCase().indexOf(w.toLowerCase() + ' ') === 0);
    return lead ? n.slice(lead.length + 1) : n;
  }
  const shortName = (c, b, places) => b ? (M.shortsFor(c, places || {})[b.name] || (b.short && b.short !== '-' ? b.short : b.name)) : '';
  const itemOf = (c, name) => name ? c.items.find(i => BUILT[i.kind] && i.lab && (norm(i.name) === norm(name) || (i.code && i.code.toUpperCase() === String(name).toUpperCase()))) || M.find(c, name) : null;

  // The landmarks outdoors (§10.2): a Conference building or a confirmed hall by its short name, a named lot
  // (a lot called just "Parking", as OpenStreetMap names them all, isn't one: "Toward Parking", the checks).
  function outMarks(R, places) {
    const c = R.campus;
    return c.items.filter(i => i.pts.length > 2 && i.lab && ((BUILT[i.kind] && (i.code || i.stayOk)) || (i.kind === 'parking' && i.name && !/^(parking|parking lot|lot)$/i.test(String(i.name).trim()))))
      .map(i => ({ name: i.kind === 'parking' ? i.name : shortName(c, i, places), pts: i.pts, item: i }));
  }
  // The landmarks inside, by building and floor (walk.json's marks): a Conference room by its name, "the
  // restrooms", "the elevator", "the stairs".
  function inMarks(R, places) {
    const W = R.walk, c = R.campus, out = {};
    if (!W || !W.marks) return out;
    const k = (W.mark_cols || []).reduce((o, n, i) => (o[n] = i, o), {});
    W.marks.forEach(m => {
      const kind = m[k.kind], codes = String(m[k.codes] || '').split('|').filter(Boolean);
      let name = kind === 'restroom' ? 'the restrooms' : kind === 'elevator' ? 'the elevator' : kind === 'stairs' ? 'the stairs' : '';
      if (kind === 'room') {
        const p = codes.map(cd => places && places[cd]).find(Boolean), b = itemOf(c, R.names[m[k.building]]);
        name = p ? nameIn(c, p, places, b) : 'Room ' + m[k.number];
      }
      const key = m[k.building] + '|' + m[k.floor];
      (out[key] = out[key] || []).push({ kind, name, number: m[k.number], iwu: m[k.name], hall: !!m[k.hall], codes, pts: (function (f) { const q = []; for (let i = 0; i + 1 < f.length; i += 2) q.push([f[i], f[i + 1]]); return q; })(m[k.at] || []) });
    });
    return out;
  }
  function nearest(list, p, skip) {
    let best = null;
    (list || []).forEach(m => {
      if (skip && skip(m)) return;
      const d = m.item ? polyD(p, m.pts) : m.pts.reduce((k, q) => Math.min(k, dist(p, q)), Infinity);
      if (d <= LM && (!best || d < best.d)) best = { m, d };
    });
    return best ? best.m : null;
  }

  /* ================================================================ where a route starts and ends */

  // → { list (the router's ends), label, b (the building's campus item), code (its build code), room,
  //     at (the room's doors, for the end), sign, notes, reason, kind }
  function endsOf(R, spec, o, role) {
    const c = R.campus, places = o.places || {}, X = R.index || {};
    const out = { list: [], notes: [], kind: '' };
    if (!spec) return Object.assign(out, { reason: 'Choose start' });
    const codeOf = name => { const b = (X.buildings || []).find(x => norm(x.name) === norm(name)); return b ? b.code : ''; };
    const drawn = name => R.names.some(n => norm(n) === norm(name));
    // A room the build hasn't got ends at its building's door, said so as a field's is (the last checks: the
    // Chapel Loft ended "North-west doors · on the right" with nothing to say the steps stop at the building).
    const doorNote = b => b ? (role === 'to' ? 'Ends at the ' : 'Starts at the ') + shortName(c, b, places) + '’s door' : '';
    // A building's ways in: a drawn building's entrances (doorways inside to arrive at, the paths outside to
    // leave from), else its doors in the campus record, or today's guessed doors. outdoors: a field beside it
    // (Nebraska Green), reached at the path outside its door, never through it, so Step-free asks nothing of
    // the door (the last checks: "No step-free route · Doors not checked" for a field).
    const building = (b, why, outdoors) => {
      out.b = b; out.kind = out.kind || 'building';
      if (!b) return Object.assign(out, { reason: 'Not on the map' });
      out.label = out.label || shortName(c, b, places);
      const od = outdoors ? Object.assign({}, o, { stepFree: false }) : o;
      if (drawn(b.name)) {
        out.code = codeOf(b.name);
        R.entrancesOf(b.name).forEach(s => {
          if (!R.doorOk(s.door, od)) return;
          const outside = s.a.out ? s.a : s.b;
          out.list.push(role === 'to' && !outdoors ? { n: s.door.inside, door: s.door } : { n: outside, door: s.door });
        });
      } else R.doors(b.name, Object.assign({}, od, { strict: true })).forEach(d => out.list.push(d));
      if (why) out.notes.push(why);
      return out;
    };
    const room = (code, floor, number, p, b) => {
      R.roomEnds(code, floor, number).forEach(e => out.list.push({ n: e.n, room: { code, floor: +floor, number } }));
      out.kind = 'room';
      if (b) out.b = b;
      out.code = code;
      return out;
    };
    if (spec.lat != null && spec.lng != null || (spec.x != null && spec.y != null)) {
      const p = spec.lat != null ? M.toMap(c, +spec.lat, +spec.lng) : { x: +spec.x, y: +spec.y };
      if (!p || !isFinite(p.x) || !isFinite(p.y)) return Object.assign(out, { reason: 'Not on the map' });
      const B = c.bounds, dx = Math.max(B.x - p.x, 0, p.x - B.x - B.w), dy = Math.max(B.y - p.y, 0, p.y - B.y - B.h);
      if (Math.hypot(dx, dy) > FAR) return Object.assign(out, { reason: 'Not on campus' });
      const inside = c.items.find(i => BUILT[i.kind] && i.lab && i.pts.length > 2 && M.inPoly(p.x, p.y, i.pts));
      if (inside && drawn(inside.name)) {
        if (spec.floor == null) return Object.assign(out, { reason: 'Set start', building: inside.name, b: inside });
        // a tap on an opened floor: its nearest hall on that floor
        const bi = R.names.findIndex(n => norm(n) === norm(inside.name));
        let best = null;
        R.IN.forEach(n => { if (n.out || n.car || n.b !== bi || n.f !== +spec.floor) return; const d = Math.hypot(n.x - p.x, n.y - p.y); if (!best || d < best.d) best = { n, d }; });
        if (best) out.list.push({ n: best.n });
        return Object.assign(out, { kind: 'point', b: inside, code: codeOf(inside.name), label: shortName(c, inside, places) });
      }
      if (inside) return building(inside);
      out.list.push({ x: p.x, y: p.y });
      // (sign: what the app calls a point it was given, "Dropped pin", for the end's own words; the walk's
      // "Toward the dropped pin" since round 3. None given: as before, "The end".)
      return Object.assign(out, { kind: spec.lat != null ? 'here' : 'point', label: spec.lat != null ? 'My location' : '', sign: spec.lat == null && spec.label ? String(spec.label) : '', at: [[p.x, p.y]] });
    }
    if (spec.room) {
      const [code, floor, number] = String(spec.room).split('|');
      const bn = ((X.buildings || []).find(x => x.code === code) || {}).name;
      const b = itemOf(c, bn);
      room(code, floor, number, null, b);
      out.label = 'Room ' + number;
      if (out.list.length) return out;
      // a room the public build has no way into (not a public room, or none drawn): its building's doors
      // (the end then names the door it reaches; unmapped tells the app, which has a hall point to try)
      if (!b) return Object.assign(out, { reason: 'Not on the map' });
      out.unmapped = true;
      out.kind = 'building';
      return building(b, doorNote(b));
    }
    if (spec.door) {
      // the campus record's id (d4) or the build's entrance id (f-b-v100s)
      const s = R.ents.find(x => x.door && (x.door.id === spec.door || x.door.entrance === spec.door));
      if (s) {
        out.b = itemOf(c, s.door.building); out.code = s.door.code; out.kind = 'door'; out.label = s.door.name;
        out.list.push(role === 'to' ? { n: s.door.inside, door: s.door } : { n: s.a.out ? s.a : s.b, door: s.door });
        return out;
      }
      const d = c.doors.find(x => x.id === spec.door);
      if (!d) return Object.assign(out, { reason: 'Not on the map' });
      out.b = itemOf(c, d.name); out.kind = 'door'; out.label = d.label || shortName(c, out.b, places);
      out.list.push({ x: d.cx, y: d.cy, door: d });
      return out;
    }
    if (spec.hall) {
      out.kind = 'hall';
      return building(itemOf(c, spec.hall), role === 'to' ? 'Ends at the hall’s door' : 'Starts at the hall’s door');
    }
    if (spec.building) return building(itemOf(c, spec.building));
    if (spec.code) {
      const code = String(spec.code), p = places[code] || { code, name: code }, ip = X.places && X.places[code];
      out.place = p;
      if (ip && ip.rooms && ip.rooms.length) {
        const b = itemOf(c, ip.building);
        ip.rooms.forEach(r => room(ip.code, r.floor, r.number, p, b));
        out.label = b ? nameIn(c, p, places, b) : p.name;
        if (out.list.length) return out;
        out.list = [];
        out.unmapped = true;
        out.kind = 'building';
        return building(b, doorNote(b));
      }
      const w = M.whereIs(c, p, places);
      if (w.kind === 'pin' && (w.outdoor || !w.b)) {
        out.list.push({ x: w.x, y: w.y });
        return Object.assign(out, { kind: 'point', label: p.name, at: [[w.x, w.y]] });
      }
      // A field or green not pinned yet, by the building places.csv names (Nebraska Green, the Rec Center):
      // to that building's best door, said so; the map never says where the field itself is (Nov 5, the
      // checks: it was a dead end). With no building, nothing to walk to yet.
      if (w.kind === 'outdoor') {
        if (!w.b) return Object.assign(out, { reason: 'Not on the map yet' });
        out.label = p.name;
        return building(w.b, doorNote(w.b), true);
      }
      if (w.kind === 'pin' || w.kind === 'building') {
        const room = code.indexOf('/') > -1 && drawn(w.b.name) && !(ip && ip.rooms && !ip.rooms.length);
        out.label = nameIn(c, p, places, w.b);
        if (room) out.unmapped = true;
        return building(w.b, room ? doorNote(w.b) : '');
      }
      return Object.assign(out, { reason: 'Not on the map' });
    }
    return Object.assign(out, { reason: 'Choose start' });
  }

  /* ================================================================ the route, as walked */

  // The edges walked, each with its points in walking order (a row's own bends), its length and its kind.
  function walked(r) {
    return r.used.map(u => {
      const s = u.s, fwd = s.a === u.from;
      let P = [[u.from.x, u.from.y]];
      if (s.via && s.via.length) P = P.concat(fwd ? s.via : s.via.slice().reverse());
      P.push([u.to.x, u.to.y]);
      const vert = s.kind === 'stairs' || s.kind === 'elevator' || s.kind === 'board';
      return { s, from: u.from, to: u.to, P, len: s.d, vert, type: vert ? 'vert' : s.inside && s.kind !== 'entrance' ? 'in' : 'out' };
    });
  }
  // Cut the walk where it meets the room (§4.10: the route ends where the room meets the hall): at the door
  // of the room's row walked (the router's s.at, from walk.json's room_doors), the last such row at the end
  // (fromEnd) or the first at the start. room: { number } of the room at that end.
  function clip(E, room, fromEnd) {
    if (!room || !E.length) return null;
    const order = fromEnd ? E.map((e, i) => i).reverse() : E.map((e, i) => i);
    for (const k of order.slice(0, 4)) {
      const e = E[k];
      if (e.type !== 'in') break;
      if (!e.s.at || e.s.num !== String(room.number)) continue;
      const at = e.s.at;
      let best = null;
      for (let i = 0; i + 1 < e.P.length; i++) { const q = segD(at, e.P[i], e.P[i + 1]); if (!best || q.d < best.d) best = Object.assign(q, { i }); }
      if (best && best.d < 1.5) {
        if (fromEnd) { e.P = e.P.slice(0, best.i + 1).concat([best.q]); E.splice(k + 1); }
        else { e.P = [best.q].concat(e.P.slice(best.i + 1)); E.splice(0, k); }
        e.len = plen(e.P);
        e.cut = true;
        return best.q;
      }
    }
    return null;
  }
  // Douglas–Peucker: the indices kept at tolerance tol (and every index in keep).
  function simplify(P, tol, keep) {
    const on = new Uint8Array(P.length);
    on[0] = on[P.length - 1] = 1;
    (keep || []).forEach(i => { if (i >= 0 && i < P.length) on[i] = 1; });
    const st = [[0, P.length - 1]];
    while (st.length) {
      const [a, b] = st.pop();
      let m = -1, md = tol;
      for (let i = a + 1; i < b; i++) { const d = segD(P[i], P[a], P[b]).d; if (d > md) { md = d; m = i; } }
      if (m > -1) { on[m] = 1; st.push([a, m], [m, b]); }
    }
    const kept = [];
    for (let i = 0; i < P.length; i++) if (on[i]) kept.push(i);
    // the kept points between forced ones split again, so a forced point never hides a bend beside it
    return kept;
  }

  /* ================================================================ the plan */

  function plan(R, from, to, o) {
    o = Object.assign({}, o || {});
    const c = R.campus, places = o.places || {};
    const F = endsOf(R, from, o, 'from'), T = endsOf(R, to, o, 'to');
    if (F.reason || T.reason) {
      const x = F.reason ? F : T;
      return { ok: false, reason: x.reason, building: x.building || '', side: F.reason ? 'from' : 'to' };
    }
    const base = { stepFree: !!o.stepFree, lift: !!o.lift, date: o.date || '', time: o.time == null ? '' : o.time, keys: !!o.keys, unchecked: !!o.unchecked, strict: true };
    const go = (q, f, t) => (f || F).list.length && (t || T).list.length ? R.route((f || F).list, (t || T).list, q) : null;
    const r = go(base);
    if (!r) {
      const anyHour = Object.assign({}, base, { date: '', time: '' });
      if (!base.stepFree) return { ok: false, reason: go(anyHour) ? 'Doors closed' : 'No route' };
      // Why there's no step-free route (§4.5, one reason): with any door, is there one? Then the doors
      // (none checked yet, or none step-free); if not, a floor no elevator reaches.
      const anyDoor = Object.assign({}, base, { anyDoor: true }), oa = Object.assign({}, o, { anyDoor: true });
      const Fa = endsOf(R, from, oa, 'from'), Ta = endsOf(R, to, oa, 'to');
      const alt = go(anyDoor, Fa, Ta);
      // The doors decide it by building (Nov 5, the checks: one checked door anywhere said "No step-free
      // door" for a building nobody had looked at): "No step-free door" only when a building the trip must
      // go in or out of has every door checked and none step-free; else "Doors not checked".
      if (alt) {
        const settled = b => { const ds = buildingDoors(R, b); return ds.length > 0 && ds.every(d => d.checked) && !ds.some(d => d.stepFree === 'yes'); };
        const must = [Fa, Ta].filter(x => x.b && x.kind !== 'here').map(x => x.b);
        return { ok: false, reason: 'No step-free route', why: must.some(settled) ? 'No step-free door' : 'Doors not checked', stepFree: true };
      }
      const plain = go(Object.assign({}, base, { stepFree: false, anyDoor: true }), Fa, Ta);
      if (!plain) return { ok: false, reason: go(Object.assign({}, anyHour, { stepFree: false })) ? 'Doors closed' : 'No route', stepFree: true };
      const up = plain.used.filter(u => u.s.kind === 'stairs' || u.s.sf === false);
      const f = Ta.list.concat(Fa.list).map(x => x.room && x.room.floor).find(n => n && n !== 1) || (up[0] ? Math.max(up[0].s.f0, up[0].s.f1) : 1);
      return { ok: false, reason: 'No step-free route', why: O.floorName(f) + ' · No elevator', stepFree: true };
    }
    if (!r.used.length) return { ok: false, reason: 'Same place' };
    const notes = F.notes.concat(T.notes);
    // A nearer door passed over because it's closed at that hour or that day (§4.5): one line.
    if (base.date || base.time) {
      const open = go(Object.assign({}, base, { date: '', time: '' }));
      const mine = doorsOf(r).map(d => d.key);
      const shut = open && doorsOf(open).find(d => mine.indexOf(d.key) < 0 && R.doorShut(d, base));
      if (shut) {
        const why = R.doorShut(shut, base), nm = shut.name || 'Doors';
        notes.unshift(why.why === 'after' ? nm + ' closed after ' + O.formatTime(why.at) : why.why === 'until' ? nm + ' closed until ' + O.formatTime(why.at) : nm + ' closed');
      }
    }
    return describe(R, r, F, T, Object.assign({}, o, base), notes);
  }
  // A building's own doors (its entrances' doors when it's drawn, else its rows in the campus record), each
  // with the COA's checks (checked, stepFree). A building with no doors in the record has none: unchecked.
  function buildingDoors(R, b) {
    if (!b) return [];
    const ents = R.entrancesOf(b.name);
    return ents.length ? ents.map(s => s.door || {}) : R.campus.doors.filter(d => norm(d.name) === norm(b.name));
  }
  // The doors a route goes through: its entrances, and a no-plan building's door at either end, each as
  // { key, name, x, y, open, checked, … } (what R.doorShut reads).
  function doorsOf(r) {
    const out = [];
    const put = d => {
      if (!d) return;
      const x = d.inside ? d : { key: 'rec|' + (d.id || d.cx + ',' + d.cy), name: d.label || '', x: d.cx, y: d.cy, open: d.open, checked: d.checked, keyOnly: d.keyOnly, stepFree: d.stepFree };
      if (d.inside) x.key = x.key || 'ent|' + (d.id || d.x + ',' + d.y);
      if (!out.some(q => q.key === x.key)) out.push(x);
    };
    r.used.forEach(u => { if (u.s.kind === 'entrance') put(u.s.door); });
    put(r.start); put(r.end);
    return out;
  }

  /* ================================================================ the steps */

  function describe(R, r, F, T, o, notes) {
    const c = R.campus, places = o.places || {};
    const codeOfB = bi => { const n = R.names[bi], b = R.index && (R.index.buildings || []).find(x => norm(x.name) === norm(n)); return b ? b.code : ''; };
    const itemB = bi => itemOf(c, R.names[bi]);
    const E = walked(r);
    // the room's door at each end (§4.10)
    const endRoom = r.endAt && r.endAt.room, startRoom = r.startAt && r.startAt.room;
    clip(E, endRoom, true);
    clip(E, startRoom, false);
    const lmOut = R._lmOut || (R._lmOut = outMarks(R, places)), lmIn = inMarks(R, places);
    const ends = new Set([F.b, T.b].filter(Boolean));
    // the end room's own mark (a restroom ends "Women's restroom", and the restrooms aren't passed on the way)
    const lastIn = E.length && E[E.length - 1].type === 'in' ? E[E.length - 1] : null;
    const endMk = endRoom && lastIn ? (lmIn[lastIn.s.bd + '|' + endRoom.floor] || []).find(m => m.number === String(endRoom.number)) || null : null;

    // --- the contexts: outdoors, a floor of a building, a floor change
    const ctx = [];
    E.forEach(e => {
      const key = e.type === 'in' ? 'in|' + e.s.bd + '|' + e.from.f : e.type;
      let cur = ctx[ctx.length - 1];
      if (!cur || cur.key !== key) ctx.push(cur = { key, type: e.type, edges: [], bd: e.type === 'out' ? -1 : e.s.bd, f: e.type === 'in' ? e.from.f : 0 });
      cur.edges.push(e);
    });
    ctx.forEach(x => {
      const P = [], at = [];   // points, and at each the graph node it is (or null for a bend in a row)
      x.edges.forEach(e => e.P.forEach((p, i) => {
        if (P.length && i === 0) return;
        P.push(p); at.push(i === 0 ? e.from : i === e.P.length - 1 && !e.cut ? e.to : null);
      }));
      x.P = P; x.at = at; x.full = P;   // (full: what the map draws; P: what the steps say, from where they start)
      x.len = x.edges.reduce((k, e) => k + e.len, 0);
    });
    const metres = E.reduce((k, e) => k + e.len, 0), pace = o.stepFree ? 50 : 60;
    const vsec = E.reduce((k, e) => k + (e.s.sec || 0), 0), sec = metres * 60 / pace + vsec;
    const outM = ctx.filter(x => x.type === 'out').reduce((k, x) => k + x.len, 0);

    const steps = [];
    const box = pts => { const xs = pts.map(p => p[0]), ys = pts.map(p => p[1]); return [Math.min.apply(null, xs), Math.min.apply(null, ys), Math.max.apply(null, xs), Math.max.apply(null, ys)]; };
    const add = s => { s.distance = s.metres >= .5 ? M.feet(s.metres) : ''; s.metres = Math.round(s.metres * 10) / 10; s.box = box(s.pts.length ? s.pts : [s.at]); s.at = [+s.at[0].toFixed(2), +s.at[1].toFixed(2)]; s.pts = s.pts.map(p => [+p[0].toFixed(2), +p[1].toFixed(2)]); steps.push(s); return s; };
    const degree = n => n ? new Set(n.e.filter(e => !e.s.dead && !(e.n.car) && !kerbOf(e)).map(e => e.n)).size : 0;
    // a stretch outdoors's way in (inward: walked from the paths into a building) or its way out
    const entry = (x, inward) => x.edges.find(e => e.s.kind === 'entrance' && !!e.from.out === !!inward);
    let lastHead = null;   // the heading walked last (for the first stretch after a door or a floor change)

    // turns along a context's line → [{ i, t }] (i: the point; t: degrees, + right). Each bend's angle is
    // the way walked over WIN metres before it against WIN metres after (a hall's half-metre zigzags in
    // IWU's centre lines aren't turns), and bends within MERGE of the first of them are one turn, at the
    // sharpest, its angle the way walked MERGE metres either side of it (Nov 5: summing the bends gave a
    // 170° "Left" for two rights; chaining them from far back, a 144° one for a plain left).
    const turns = (x, kind, forced) => {
      const P = x.P;
      if (P.length < 3) return [];
      const kept = simplify(P, TOL[kind], forced);
      const cum = cumOf(P), L = cum[P.length - 1], w = WIN[kind], mw = MERGE[kind], nw = NET[kind];
      x.cum = cum;
      const hIn = i => head(along(P, cum, cum[i] - w), P[i]), hOut = i => head(P[i], along(P, cum, cum[i] + w));
      const net = i => turnOf(head(along(P, cum, cum[i] - nw), P[i]), head(P[i], along(P, cum, cum[i] + nw)));
      const raw = [];
      for (let j = 1; j + 1 < kept.length; j++) {
        const i = kept[j];
        if (cum[i] < .05 || L - cum[i] < .05) continue;
        // (a bend under BEND° is the line's own wobble: kept out, or a long hall of them chains into one turn)
        const t = turnOf(hIn(i), hOut(i));
        if (Math.abs(t) >= BEND) raw.push({ i, t });
      }
      const out = [];
      raw.forEach(q => {
        const last = out[out.length - 1];
        if (last && cum[q.i] - cum[last.first] <= mw && forced.indexOf(q.i) < 0 && forced.indexOf(last.i) < 0) {
          last.end = q.i;
          if (Math.abs(q.t) > Math.abs(last.top)) { last.top = q.t; last.i = q.i; }
        } else out.push({ i: q.i, t: q.t, top: q.t, first: q.i, end: q.i });
      });
      // (a crossing's forced point keeps its own bend; any other turn is the way walked either side of it)
      out.forEach(q => { if (forced.indexOf(q.i) < 0) q.t = net(q.i); });
      return out;
    };
    // The way a walk outdoors leaves node n (from the point before it, was): each way's heading over its first
    // WAY metres (on along it while it has no other way), and whether it's the route's own (to the point then).
    const waysOut = (n, at, was, then) => {
      const out = [];
      n.e.forEach(e => {
        if (e.s.dead || e.n.car) return;
        const q = [e.n.x, e.n.y];
        if (was && dist(q, was) < .05) return;
        const own = !!then && dist(q, then) < .05;
        if ((e.s.tmp || kerbOf(e)) && !own) return;
        let a = n, b = e.n, len = e.s.d || dist([a.x, a.y], q);
        while (len < WAY) {
          const nx = b.e.filter(f => !f.s.dead && !f.n.car && f.n !== a && !kerbOf(f));
          if (nx.length !== 1) break;
          a = b; b = nx[0].n; len += nx[0].s.d || 0;
        }
        if (dist(at, [b.x, b.y]) > .3) out.push({ e, own, h: head(at, [b.x, b.y]) });
      });
      return out;
    };
    // Where someone told nothing goes at the bend i (Nov 5, late; the review: a jog folded at a junction left a
    // stranger 60 m off): at each junction within BRANCH of it, the way nearest straight on (and any within
    // STRAY.tie of it), followed STRAY.len metres taking the way nearest straight on at each junction. →
    // 'none' (no junction there), 'route' (that way is the route's own), 'beside' (another way that keeps
    // near the route or comes back to it: a sidewalk beside a drive), 'off' (another way that leaves it).
    // (told: where the step before is; a junction within BRANCH of it was that step's, and isn't asked again:
    // "Turn right 10 ft", then "Slight right" 3 m on at the same crossing of paths. j: a turn of bends merged,
    // from its first bend i to its last j, has the junctions of all of them: a left 25° and a left 29° 8 m on,
    // the fork at the second.)
    const within = (x, k, i, j) => { const a = x.cum[i], b = x.cum[j == null ? i : j]; return x.cum[k] >= Math.min(a, b) - BRANCH && x.cum[k] <= Math.max(a, b) + BRANCH; };
    const strayAt = (x, i, told, j) => {
      let res = 'none';
      for (let k = 1; k + 1 < x.P.length && res !== 'off'; k++) {
        const n = x.at[k];
        if (!n || !within(x, k, i, j) || degree(n) < 3) continue;
        if (told != null && Math.abs(x.cum[k] - told) <= BRANCH) continue;
        const hIn = head(along(x.P, x.cum, x.cum[k] - NET.out), x.P[k]);
        const ws = waysOut(n, x.P[k], x.P[k - 1], x.P[k + 1]).map(w => Object.assign(w, { t: Math.abs(turnOf(hIn, w.h)) }));
        if (!ws.length) continue;
        const best = Math.min.apply(null, ws.map(w => w.t));
        const took = ws.filter(w => !w.own && w.t <= best + STRAY.tie && w.t <= 100);
        if (!took.length) { if (res === 'none') res = 'route'; continue; }
        // the route from a little before the junction to well past it, as a line to measure from
        const lo = Math.max(0, k - 2);
        let hi = k; while (hi < x.P.length - 1 && x.cum[hi] - x.cum[k] < STRAY.len * 2.5) hi++;
        const off = q => { let m = Infinity; for (let j = lo; j < hi; j++) m = Math.min(m, segD(q, x.P[j], x.P[j + 1]).d); return m; };
        took.forEach(w => {
          let a = n, b = w.e.n, h = head([a.x, a.y], [b.x, b.y]), len = w.e.s.d || dist([a.x, a.y], [b.x, b.y]), back = false;
          while (len < STRAY.len) {
            if (len > 15 && off([b.x, b.y]) < STRAY.back) { back = true; break; }
            const nx = waysOut(b, [b.x, b.y], [a.x, a.y], null).filter(v => v.e.s.kind !== 'link' && v.e.s.kind !== 'entrance');
            if (!nx.length) break;
            const v = nx.reduce((m, v) => Math.abs(turnOf(h, v.h)) < Math.abs(turnOf(h, m.h)) ? v : m);
            if (Math.abs(turnOf(h, v.h)) > 100) break;   // a dead end: they'd stop and look
            a = b; b = v.e.n; h = head([a.x, a.y], [b.x, b.y]); len += v.e.s.d || dist([a.x, a.y], [b.x, b.y]);
          }
          if (!back && off([b.x, b.y]) > STRAY.off) res = 'off';
          else if (res !== 'off') res = 'beside';
        });
      }
      return res;
    };
    // Outdoors (Nov 5, evening): the same bends, but a turn's angle is the way walked into its first bend
    // against the way out of its last (NET either side), so bends merged into one turn that cancel (a kerb
    // ramp's jog) come to nothing; then a jog (JOG) a little longer than MERGE is no turn either. Each turn
    // keeps hIn, the way walked into it.
    const turnsOut = (x, forced) => {
      const P = x.P;
      if (P.length < 3) return [];
      const kept = simplify(P, TOL.out, forced);
      const cum = cumOf(P), L = cum[P.length - 1], w = WIN.out, nw = NET.out;
      x.cum = cum;
      const back = (i, m) => head(along(P, cum, cum[i] - m), P[i]), on = (i, m) => head(P[i], along(P, cum, cum[i] + m));
      const isF = i => forced.indexOf(i) > -1;
      const raw = [];
      for (let j = 1; j + 1 < kept.length; j++) {
        const i = kept[j];
        if (cum[i] < .05 || L - cum[i] < .05) continue;
        const t = turnOf(back(i, w), on(i, w));
        if (Math.abs(t) >= BEND) raw.push({ i, t });
      }
      // (bends the same way merge; a bend back the other way is the jog test's, which asks how far sideways)
      const out = [];
      raw.forEach(q => {
        const g = out[out.length - 1];
        if (g && cum[q.i] - cum[g.first] <= MERGE.out && !isF(q.i) && !isF(g.i) && g.top * q.t > 0) {
          g.end = q.i; g.sum += q.t;
          if (Math.abs(q.t) > Math.abs(g.top)) { g.top = q.t; g.i = q.i; }
        } else out.push({ i: q.i, t: q.t, top: q.t, first: q.i, end: q.i, sum: q.t });
      });
      // (never measured back past a crossing's start, nor on past one: the way off a street just crossed is
      // the crossing's own, not the street's; the review: "Keep left" for a plain left after crossing it)
      const lim = (i, dir) => forced.reduce((m, f) => { const d = dir < 0 ? cum[i] - cum[f] : cum[f] - cum[i]; return d >= 2 && d < m ? d : m; }, nw);
      const overAt = i => { const K = Object.keys(x.across || {}).map(Number).find(K => Math.abs(cum[K] - cum[i]) <= 3); return K == null ? null : x.across[K]; };
      // (gap: a jog that stays two turns has each measured to the other, 5 m or more off, not past it: a right
      // and a left 6 m on read as one 54° "Slight right", the checks)
      const measure = (g, gap) => {
        // (off a street's far kerb, the way in is the way over it)
        const ov = overAt(g.first), m = (l, d) => d != null && d >= 5 && d < l ? d : l;
        g.hIn = ov != null ? ov : back(g.first, m(lim(g.first, -1), gap && gap[0]));
        if (isF(g.i)) return;
        let t = turnOf(g.hIn, on(g.end, m(lim(g.end, 1), gap && gap[1])));
        // (two rights nearly back the way you came: the bends' own side, never a "Left" for them)
        if (Math.abs(g.sum) > 120 && t * g.sum < 0) t = -t;
        g.t = t;
      };
      out.forEach(g => measure(g));
      for (let j = 0; j + 1 < out.length; j++) {
        const a = out[j], b = out[j + 1];
        if (isF(a.i) || isF(b.i) || a.t * b.t >= 0 || cum[b.first] - cum[a.end] > JOG.len) continue;
        if (Math.abs(turnOf(a.hIn, on(b.end, nw))) > JOG.head) continue;
        // (a real turn and a wobble back isn't a jog: 42° and 8°, the review)
        if (Math.min(Math.abs(a.t), Math.abs(b.t)) < JOG.alike * Math.max(Math.abs(a.t), Math.abs(b.t))) continue;
        // Someone told nothing keeps on at the first bend: beside the route (a sidewalk beside the drive the
        // route walks down the middle of), it's no turn; off it, it's two. On the route, the same at the second.
        const s1 = strayAt(x, a.first, null, a.end), s2 = s1 === 'off' ? null : strayAt(x, b.first, null, b.end);
        if (s1 === 'off' || ((s1 === 'route' || s1 === 'none') && s2 === 'off')) {
          const d = cum[b.first] - cum[a.end];
          // A dogleg at a fork (its bends under MERGE apart and each under 60°: the PPAC to the Chapel, a
          // left 14° and a right 23° 3 m on, where the other way goes off 19° right) is one step at the bend
          // where someone could go wrong, "Keep left"; the other bend another only where someone could go
          // wrong there too. Else each bend is a turn of its own, measured to the other.
          if (d < MERGE.out && Math.max(Math.abs(a.top), Math.abs(b.top)) < 60) {
            const [s, o] = s1 === 'off' ? [a, b] : [b, a];
            s.dogleg = true; s.t = s.top;
            if (s === a ? strayAt(x, b.first, cum[a.i], b.end) !== 'off' : true) o.jog = true;
            j++;
            continue;
          }
          measure(a, [null, d]); measure(b, [d, null]);
          continue;
        }
        a.jog = b.jog = true;
        j++;
      }
      // (the jogs' bends kept aside: a bend folded here can still be a trap, TRAP below)
      x.jogs = out.filter(g => g.jog);
      return out.filter(g => !g.jog);
    };
    // The other ways at a turn outdoors: at each graph node within BRANCH of it where a way leaves that the
    // route doesn't walk, that way's heading over its first WAY metres (on along it while it has no other
    // way), from that node. None: a bend in the path with nowhere else to go.
    // (paths: only paths and roads, never a building's door: TRAP's lures, below; a way that is a door's own
    // path, or a link to nothing but one, is no way anyone told "Turn left" takes)
    const doorWay = (n, e) => e.s.kind === 'entrance' || (e.s.kind === 'link' && e.n.e.every(f => f.n === n || f.s.kind === 'entrance' || f.s.kind === 'link'));
    const waysAt = (x, i, j, paths) => {
      const hs = [];
      for (let k = 0; k < x.P.length; k++) {
        const n = x.at[k];
        if (!n || !within(x, k, i, j) || degree(n) < 3) continue;
        const was = x.P[k - 1], then = x.P[k + 1];
        n.e.forEach(e => {
          if (e.s.dead || e.n.car || kerbOf(e) || (paths && doorWay(n, e))) return;
          const q = [e.n.x, e.n.y];
          if ((was && dist(q, was) < .05) || (then && dist(q, then) < .05)) return;
          let a = n, b = e.n, len = e.s.d || dist([a.x, a.y], q);
          while (len < WAY) {
            const nx = b.e.filter(f => !f.s.dead && !f.n.car && f.n !== a && !kerbOf(f));
            if (nx.length !== 1) break;
            a = b; b = nx[0].n; len += nx[0].s.d || 0;
          }
          if (dist(x.P[k], [b.x, b.y]) > .3) hs.push(head(x.P[k], [b.x, b.y]));
        });
      }
      return hs;
    };
    // Inside, a branch is another hall (round 2 part 2, the last checks): a row into a room or its doorway
    // branches off nearly every point of a hall, so it made every jog a step; nor is a hall's stub that
    // ends within SPUR metres.
    const hallWay = e => !e.s.dead && !e.n.car && (e.s.kind === 'hall' || e.s.kind === 'entrance') && (e.s.d >= SPUR || e.n.e.some(f => f.n !== e.n && f.s !== e.s && f.s.kind === 'hall'));
    const halls = n => n ? new Set(n.e.filter(hallWay).map(e => e.n)).size : 0;
    const branchNear = (x, i, kind) => { for (let k = 0; k < x.P.length; k++) { if (Math.abs(x.cum[k] - x.cum[i]) <= BRANCH && (kind === 'in' ? halls(x.at[k]) : degree(x.at[k])) >= 3) return true; } return false; };
    const side = t => t > 0 ? 'right' : 'left';
    const Side = t => t > 0 ? 'Right' : 'Left';

    // the street a crossing crosses: a road line through the crosswalk, or through the crossing mark
    const streetAt = (a, b) => {
      let best = null;
      const cross = (p, q, r1, r2) => { const o1 = (q[0] - p[0]) * (r1[1] - p[1]) - (q[1] - p[1]) * (r1[0] - p[0]), o2 = (q[0] - p[0]) * (r2[1] - p[1]) - (q[1] - p[1]) * (r2[0] - p[0]), o3 = (r2[0] - r1[0]) * (p[1] - r1[1]) - (r2[1] - r1[1]) * (p[0] - r1[0]), o4 = (r2[0] - r1[0]) * (q[1] - r1[1]) - (r2[1] - r1[1]) * (q[0] - r1[0]); return o1 * o2 < 0 && o3 * o4 < 0; };
      R.live.forEach(sg => { if (sg.dead || !sg.road || !sg.name) return; if (b ? cross(a, b, [sg.a.x, sg.a.y], [sg.b.x, sg.b.y]) : (Math.hypot(sg.a.x - a[0], sg.a.y - a[1]) < .1 || Math.hypot(sg.b.x - a[0], sg.b.y - a[1]) < .1)) best = best || sg.name; });
      return best || 'the drive';
    };
    // The named streets a walk outdoors crosses (the review, Nov 5, late: half a crosswalk that ends on the
    // road's line, or a walk down the road's middle and off its far side, said "Across the drive" or nothing):
    // wherever the walk goes from one side of a named road to the other, over it (a line of the walk through
    // one of the road's) or by its nodes (the walk before them on one side, after them on the other). Along
    // it no more than RUN metres, the step starts where the walk (or its crosswalk) meets it; longer, the walk
    // goes along it on the side it came and crosses where it leaves it. Its far kerb: the crosswalk's end, or
    // the walk's next point when that's near. → [{ i, kerb, name, run }] in walking order.
    const namedIx = () => {
      if (R._named) return R._named;
      const G = new Map(), C = 25;
      R.live.forEach(sg => {
        if (!sg.road || !sg.name) return;
        for (let gx = Math.floor(Math.min(sg.a.x, sg.b.x) / C); gx <= Math.floor(Math.max(sg.a.x, sg.b.x) / C); gx++)
          for (let gy = Math.floor(Math.min(sg.a.y, sg.b.y) / C); gy <= Math.floor(Math.max(sg.a.y, sg.b.y) / C); gy++) { const k = gx + ',' + gy; if (!G.has(k)) G.set(k, []); G.get(k).push(sg); }
      });
      return (R._named = { G, C });
    };
    const segX = (p, q, r1, r2) => { const o = (a, b, c) => (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0]); return o(p, q, r1) * o(p, q, r2) < 0 && o(r1, r2, p) * o(r1, r2, q) < 0; };
    const streetsCrossed = x => {
      const P = x.P, N = P.length, cum = cumOf(P), found = [];
      const segE = [];
      { let k = 0; x.edges.forEach(e => { for (let z = 0; z + 1 < e.P.length; z++) segE[k + z] = e; k += e.P.length - 1; }); }
      const cw = j => !!(segE[j] && segE[j].s.cross);
      const onS = n => n ? n.e.filter(e => !e.s.dead && e.s.road && e.s.name) : [];
      // metres right (+) or left (−) of the line through o along d
      const sideOf = (o, d, q) => { const L = Math.hypot(d[0], d[1]); return L ? (d[0] * (q[1] - o[1]) - d[1] * (q[0] - o[0])) / L : 0; };
      // the walk s metres before (dir −1) or after (+1) index k, the first point of it clear of the street's line
      const clear = (k, dir, o, d) => { for (const s of [6, 12, 20]) { const v = sideOf(o, d, along(P, cum, cum[k] + dir * s)); if (Math.abs(v) >= 1.5) return v; } return 0; };
      // (across: the way a person crossing faces, from one side straight over to the other, whatever the line
      // walks along the road's middle; the turn off the far kerb is said from it)
      const put = (name, i0, k0, run, short, across) => {
        let i = i0, kb = k0;
        if (run <= RUN) while (i > 0 && cw(i - 1)) i--;
        while (kb < N - 1 && cw(kb)) kb++;
        if (kb === k0 && short && kb < N - 1 && cum[kb + 1] - cum[kb] <= 30) kb++;
        found.push({ i, kerb: kb, name, run, across });
      };
      const over = (d, s) => s > 0 ? Math.atan2(d[0], -d[1]) : Math.atan2(-d[0], d[1]);
      // by its nodes: a run of the walk's points on one named road
      const open = new Map();
      for (let k = 0; k <= N; k++) {
        const here = new Set(k < N ? onS(x.at[k]).map(e => e.s.name) : []);
        open.forEach((p, nm) => {
          if (here.has(nm)) return;
          open.delete(nm);
          const q = k - 1;
          if (p === 0 || q === N - 1) return;
          // the street's way where the walk meets it and leaves it: the walk's own along it, else the road's line
          let dp, dq;
          if (q > p) { dp = [P[p + 1][0] - P[p][0], P[p + 1][1] - P[p][1]]; dq = [P[q][0] - P[q - 1][0], P[q][1] - P[q - 1][1]]; }
          else {
            const ns = onS(x.at[p]).filter(e => e.s.name === nm).map(e => e.n);
            if (!ns.length) return;
            const a = ns[0], b = ns[1] || x.at[p];
            dp = dq = [b.x - a.x, b.y - a.y];
          }
          const sb = clear(q, 1, P[q], dq);
          if (clear(p, -1, P[p], dp) * sb >= 0) return;
          const run = cum[q] - cum[p];
          if (run <= RUN) put(nm, p, q, run, p === q, over(dq, sb));
          else put(nm, q, q, run, true, over(dq, sb));
        });
        if (k < N) here.forEach(nm => { if (!open.has(nm)) open.set(nm, k); });
      }
      // over it: a line of the walk (not a road's own) through a named road's
      const { G, C } = namedIx();
      for (let k = 0; k + 1 < N; k++) {
        if (segE[k] && segE[k].s.road) continue;
        const a = P[k], b = P[k + 1], hit = new Set();
        for (let gx = Math.floor(Math.min(a[0], b[0]) / C); gx <= Math.floor(Math.max(a[0], b[0]) / C); gx++)
          for (let gy = Math.floor(Math.min(a[1], b[1]) / C); gy <= Math.floor(Math.max(a[1], b[1]) / C); gy++)
            (G.get(gx + ',' + gy) || []).forEach(sg => { if (!hit.has(sg.name) && segX(a, b, [sg.a.x, sg.a.y], [sg.b.x, sg.b.y])) hit.add(sg.name); });
        hit.forEach(nm => put(nm, k, k + 1, 0, false, head(a, b)));
      }
      // in walking order; one street crossed once within 25 m; where two overlap (a walk down one street and
      // over the next where they meet), the one walked over, not along
      found.sort((a, b) => a.i - b.i || a.run - b.run);
      const out = [];
      found.forEach(w => {
        const last = out[out.length - 1];
        if (out.some(v => v.name === w.name && Math.abs(cum[v.i] - cum[w.i]) < 25)) return;
        if (last && w.i < Math.max(last.kerb, last.i + 1)) {
          // (Nov 5, night: two streets crossed where they meet, neither walked along, from one corner to the
          // one across from it through the junction (a kerb into it, the router's): both said, the second
          // where the first ends, to the walk's next point when that's near)
          if (w.i === last.i && w.run <= RUN && last.run <= RUN && w.name !== last.name) {
            const i = Math.max(last.kerb, last.i + 1);
            if (i >= N - 1) return;
            let kb = Math.max(w.kerb, i);
            if (kb === i && cum[kb + 1] - cum[kb] <= 30) kb++;
            out.push(Object.assign({}, w, { i, kerb: kb }));
            return;
          }
          if (w.run < last.run) out[out.length - 1] = w;
          return;
        }
        out.push(w);
      });
      return out;
    };

    ctx.forEach((x, ci) => {
      const prev = ctx[ci - 1], next = ctx[ci + 1];
      if (x.type === 'vert') {
        const e0 = x.edges[0], eN = x.edges[x.edges.length - 1], f0 = e0.from.f, f1 = eN.to.f, lift = x.edges.some(e => e.s.kind === 'elevator' || e.s.kind === 'board');
        if (f0 === f1) return;
        const at = [e0.from.x, e0.from.y], lm = nearest(lmIn[e0.s.bd + '|' + f0], at, m => m.kind === 'stairs' || m.kind === 'elevator');
        add({ kind: 'floor', building: codeOfB(e0.s.bd), floor: f0, floorTo: f1, text: lift ? 'Elevator to the ' + floorWord(f1) : 'Stairs ' + (f1 > f0 ? 'up' : 'down') + ' to the ' + floorWord(f1),
          detail: lm ? (lift ? 'Elevator by ' : 'Stairs by ') + lm.name : '', metres: 0, at, pts: [], icon: lift ? 'elevator' : f1 > f0 ? 'stairs-up' : 'stairs-down', turn: null });
        // out of a car, facing back the way in; off a flight, facing on
        if (lastHead != null && lift) lastHead += Math.PI;
        return;
      }
      const kind = x.type;
      // Off the stairs or out of the car (Nov 5, the checks): the stairwell's (or the lift lobby's) own rows
      // and its doorway are no step, and the way out of its door is the way you face. (The stairwell's row
      // ran out past the hall and back: "Past the restrooms 20 ft", then "Left at the stairs", a turn of 170°.)
      if (kind === 'in' && prev && prev.type === 'vert') {
        let n = 0, k = 0;
        for (const e of x.edges) { if (e.s.kind !== 'room' && e.s.kind !== 'door') break; n += e.P.length - 1; k++; }
        if (k && k < x.edges.length && n > 0 && n < x.P.length - 1) {
          const h = headIn(x.P.slice(0, n + 1), 3);
          if (h != null) lastHead = h;
          x.P = x.P.slice(n); x.at = x.at.slice(n);
        }
      }
      const P = x.P;
      if (P.length < 2 || plen(P) < .5) { const h = P.length > 1 ? headIn(P, HEAD_IN) : null; if (h != null) lastHead = h; return; }
      // The crossings outdoors: a crosswalk (from its start to the far kerb), or a crossing mark (where a
      // footway crosses a road: not where the walk goes on along the road; its far side the footway's next
      // point, when that's near). One over a named street, or a long one, is a step of its own (forced: "Cross
      // East 45th Street"), and the walk after its far kerb (kerb) another. A short one over a drive or a lot
      // (folded) is no step (Nov 5, evening): its step's detail says "Across the drive".
      const forced = [], crossAt = {}, kerb = {}, folded = [], endOf = {};
      if (kind === 'out') {
        // the named streets first (the review, Nov 5, late), each a step of its own; a crosswalk or a crossing
        // mark of theirs isn't said again
        const named = streetsCrossed(x);
        x.across = {};
        named.forEach(w => { forced.push(w.i); crossAt[w.i] = w.name; endOf[w.i] = Math.max(w.i, w.kerb); if (w.kerb > w.i && w.kerb < P.length - 1) { kerb[w.kerb] = { run: w.run }; x.across[w.kerb] = w.across; } });
        const saidAt = (i, name) => named.some(w => (i >= w.i && i < Math.max(w.kerb, w.i + 1)) || (name && w.name === name && Math.abs(i - w.i) <= 3));
        let k = 0;
        const xs = [];
        x.edges.forEach((e, j) => {
          const i0 = k, before = x.edges[j - 1], after = x.edges[j + 1];
          k += e.P.length - 1;
          if (e.s.cross) {
            if (!(before && before.s.cross)) xs.push({ i: i0, a: e.P[0], m: 0, mid: [] });
            const w = xs[xs.length - 1];
            w.m += e.len; w.b = e.P[e.P.length - 1];
            if (after && after.s.cross) w.mid.push([e.to.x, e.to.y]);
            else if (k < P.length - 1) w.kerb = k;
          }
          if (e.to.xing && k < P.length - 1 && !e.s.road && !(after && after.s.road)) {
            const near = after && !after.s.cross && after.len <= 30 && k + after.P.length - 1 < P.length - 1;
            xs.push({ i: k, mark: [e.to.x, e.to.y], m: near ? after.len : 0, kerb: near ? k + after.P.length - 1 : null });
          }
        });
        xs.forEach(w => {
          if (saidAt(w.i)) return;
          // (a crosswalk's street: a named road through it, end to end, or one it meets in the middle)
          let name = w.mark ? streetAt(w.mark) : streetAt(w.a, w.b);
          if (name === 'the drive' && w.mid) name = w.mid.map(p => streetAt(p)).find(s => s !== 'the drive') || name;
          if (name !== 'the drive' && saidAt(w.i, name)) return;
          if (name === 'the drive' && w.m <= XSHORT) { folded.push(w.i); return; }
          forced.push(w.i); crossAt[w.i] = name; endOf[w.i] = w.kerb != null ? w.kerb : w.i;
          if (w.kerb != null) kerb[w.kerb] = { run: 0 };
        });
      }
      const T_ = kind === 'out' ? turnsOut(x, forced) : turns(x, kind, forced);
      if (!x.cum) x.cum = cumOf(P);
      const breaks = [], L = x.cum[P.length - 1];
      T_.forEach(q => {
        const a = Math.abs(q.t);
        if (crossAt[q.i] != null) breaks.push({ i: q.i, t: q.t, cross: crossAt[q.i] });
        else if (x.cum[q.i] < MERGE[kind] || L - x.cum[q.i] < MERGE[kind]) return;
        else if (kind === 'out') {
          // Outdoors only where another way leaves (a bend with nowhere else to go: you follow the path): 60° or
          // more always; under it (Nov 5, late, after the review: a Y with neither way straight on said nothing)
          // only where someone told nothing would go wrong (strayAt: the way nearest straight on, or one about as
          // near, leaves the route), a fork as much as a bend off a straight way. Under 60° it's "Keep left"
          // where the route is the outer of the ways about as straight as it and none goes straight on (a Y),
          // else "Slight left".
          const ways = waysAt(x, q.first, q.end).map(h => turnOf(q.hIn, h));
          const told = breaks.length ? x.cum[breaks[breaks.length - 1].i] : null;
          if (q.dogleg) { breaks.push({ i: q.i, t: q.t, keep: true, fork: true }); return; }
          if (!ways.length) return;
          // (60° or more where the route's own way is the one nearest straight on, and nothing else near it, is
          // the path's own bend: no step, Michael: "every single little turn on the sidewalk is probably not
          // necessary")
          if (a >= 60) { const s = strayAt(x, q.first, told, q.end); if (s === 'off' || s === 'beside') breaks.push({ i: q.i, t: q.t }); return; }
          if (a < SLIGHT_MIN || strayAt(x, q.first, told, q.end) !== 'off') return;
          const near = ways.filter(o => Math.abs(o) <= a + FORK);
          const keep = near.length > 0 && !ways.some(o => Math.abs(o) < STRAIGHTER) && near.every(o => (o - q.t) * Math.sign(q.t) < 0);
          breaks.push({ i: q.i, t: q.t, keep, fork: true });
        }
        else if (a >= 60 || (a >= 25 && branchNear(x, q.i, kind))) breaks.push({ i: q.i, t: q.t });
      });
      forced.forEach(i => { if (!breaks.some(b => b.i === i) && i > 0) breaks.push({ i, t: 0, cross: crossAt[i] }); else if (i === 0 && crossAt[0] != null) breaks.unshift({ i: 0, t: 0, cross: crossAt[0], first: true }); });
      // A street crossed while carrying straight on along another (ALONG above): no step; its break is the
      // walk along that street (cont), the street crossed in its list (overs).
      // (the one named street the walk is along at each of ALONG.at metres before point k (dir −1) or after
      // it (+1), or null)
      const streetOn = (k, dir) => {
        const { G, C } = namedIx();
        let names = null;
        for (const s of ALONG.at) {
          const m = x.cum[k] + dir * s;
          if (m < 0 || m > L) return null;
          const q = along(P, x.cum, m), h = head(along(P, x.cum, m - 3), along(P, x.cum, m + 3)), here = new Set();
          const gx = Math.floor(q[0] / C), gy = Math.floor(q[1] / C);
          for (let u = -1; u <= 1; u++) for (let v = -1; v <= 1; v++) (G.get((gx + u) + ',' + (gy + v)) || []).forEach(sg => {
            if (here.has(sg.name)) return;
            const t = Math.abs(turnOf(h, head([sg.a.x, sg.a.y], [sg.b.x, sg.b.y])));
            if (Math.min(t, 180 - t) <= ALONG.deg && segD(q, [sg.a.x, sg.a.y], [sg.b.x, sg.b.y]).d <= ALONG.w) here.add(sg.name);
          });
          names = names ? new Set([...names].filter(nm => here.has(nm))) : here;
          if (!names.size) return null;
        }
        return names.size === 1 ? [...names][0] : null;
      };
      if (kind === 'out') {
        breaks.forEach(b => {
          if (b.cross == null || b.i === 0) return;
          const e = endOf[b.i] != null ? endOf[b.i] : b.i, s0 = streetOn(b.i, -1);
          if (!s0 || s0 === b.cross || streetOn(e, 1) !== s0) return;
          if (Math.abs(turnOf(head(along(P, x.cum, x.cum[b.i] - ALONG.head), P[b.i]), head(P[e], along(P, x.cum, x.cum[e] + ALONG.head)))) > ALONG.deg) return;
          b.cont = s0; b.overs = [b.cross]; b.cross = null; b.t = 0;
        });
      }
      // A crossing ends at the far kerb (Nov 5: "Cross East 45th Street · 0.5 mi" took in all the walk after
      // it): the rest is a step of its own, when it's longer than a bend's merge.
      Object.keys(kerb).map(Number).forEach(i => {
        const last = breaks.filter(b => b.i < i).reduce((m, b) => !m || b.i > m.i ? b : m, null);
        // (nor after a crossing of no length: a start on the road's own line, at its far kerb already)
        if (breaks.some(b => b.i === i) || !last || last.cross == null || x.cum[i] - x.cum[last.i] < .5) return;
        const nb = breaks.filter(b => b.i > i).reduce((m, b) => !m || b.i < m.i ? b : m, null), nx = nb ? x.cum[nb.i] : L;
        // (nor when the walk goes straight over and on to the next street's crossing, a block on: "Cross East
        // 38th Street 30 ft", "Continue toward Rec Center 300 ft", "Cross East 39th Street" down Washington
        // Street. Not after a walk along the street: from a lot, along East 39th 12 m and off it down a path,
        // the path's start is a step.)
        if (nb && nb.cross != null && nx - x.cum[i] <= BLOCK && !(kerb[i].run >= 5)) return;
        if (nx - x.cum[i] > MERGE[kind]) breaks.push({ i, t: 0, on: true });
      });
      // A hairpin out of a door or a stairwell (the hall runs back past where you came out: Barnes's stairs by
      // 133, a right and a right again 4 m on): the first step would turn more than 120°, which no Left or
      // Right says (§10.2: "Turn around" is only Rerouting's), so its first sharp bend is a step of its own.
      if (kind === 'in' && lastHead != null) {
        const firstI = breaks.filter(b => b.i > 0).reduce((m, b) => Math.min(m, b.i), P.length - 1);
        const t0 = turnOf(lastHead, head(P[0], along(P, x.cum, Math.min(x.cum[firstI], FIRST))));
        const sharp = Math.abs(t0) > 120 ? T_.find(q => q.i < firstI && x.cum[q.i] > 1 && x.cum[q.i] < MERGE[kind] && Math.abs(q.t) >= 60) : null;
        if (sharp) breaks.push({ i: sharp.i, t: sharp.t });
      }
      breaks.sort((a, b) => a.i - b.i);
      // (the walk along one street is one step: from the street just crossed (its far kerb's "Continue"), or
      // from the first street crossed along it, to the next step that isn't a street crossed along it; from a
      // far kerb only when the walk goes on along that street from it: the check, Nov 5, night, saw "Continue
      // on South Bellamy Boulevard" said 250 m before the walk came to it)
      for (let j = breaks.length - 1; j > 0; j--) {
        const a = breaks[j - 1], b = breaks[j];
        if (!b.cont || !(a.cont === b.cont || (a.on && streetOn(a.i, 1) === b.cont))) continue;
        if (a.on) { a.on = false; a.cont = b.cont; a.overs = []; }
        a.overs = a.overs.concat(b.overs);
        breaks.splice(j, 1);
      }
      // A slight turn outdoors with less than 30 ft before the next step is no step of its own (the last
      // checks: "Bear right 10 ft", then the door): its stretch goes with the step before.
      for (let j = breaks.length - 1; j >= 0; j--) {
        const b = breaks[j], nx = j + 1 < breaks.length ? x.cum[breaks[j + 1].i] : L;
        if (kind === 'out' && b.i > 0 && b.cross == null && !b.on && !b.cont && !b.fork && forced.indexOf(b.i) < 0 && Math.abs(b.t) < 60 && nx - x.cum[b.i] < 9) breaks.splice(j, 1);
      }
      // The two rules of TRAP (above), over the turns no step says (a jog's bends too), never within a merge
      // of either end of the walk outdoors (the first step's heading, the door or the end says those).
      if (kind === 'out') {
        const free = g => !breaks.some(b => b.i === g.i) && x.cum[g.i] >= MERGE.out && L - x.cum[g.i] >= MERGE.out;
        const bent = T_.concat(x.jogs || []).filter(free).sort((u, v) => u.i - v.i);
        const nextOf = i => breaks.filter(b => b.i > i).reduce((m, b) => !m || b.i < m.i ? b : m, null);
        // A walk along one street ends where it turns off it (more than ALONG.w metres from its line at 10, 20
        // or 30 m on: not a kerb over to the sidewalk beside it): that turn is a step, unless the next step is
        // RUN metres or less on (a bend to the kerb just before "Cross University Boulevard" is no step).
        const { G, C } = namedIx();
        const offStreet = (k, name) => [10, 20, 30].some(s => {
          const q = along(P, x.cum, Math.min(x.cum[k] + s, L)), gx = Math.floor(q[0] / C), gy = Math.floor(q[1] / C);
          let d = Infinity;
          for (let u = -1; u <= 1; u++) for (let v = -1; v <= 1; v++) (G.get((gx + u) + ',' + (gy + v)) || []).forEach(sg => { if (sg.name === name) d = Math.min(d, segD(q, [sg.a.x, sg.a.y], [sg.b.x, sg.b.y]).d); });
          return d > ALONG.w;
        });
        breaks.filter(b => b.cont).map(b => {
          const nb = nextOf(b.i), end = nb ? nb.i : P.length - 1;
          return bent.find(g => g.i > b.i && g.i < end && x.cum[end] - x.cum[g.i] > RUN && Math.abs(g.t) >= ALONG.deg && offStreet(g.i, b.cont));
        }).filter(Boolean).forEach(g => { if (free(g)) breaks.push({ i: g.i, t: g.t, leave: true }); });
        // A turn at a junction the next step's words would send someone the wrong way at (from the last, so
        // each one's next step is the one said).
        bent.slice().reverse().forEach(g => {
          if (!free(g) || Math.abs(g.t) < TRAP.deg) return;
          const nb = nextOf(g.i);
          if (!nb || nb.cross != null || nb.cont || nb.on || Math.abs(nb.t || 0) < SLIGHT_MIN || x.cum[nb.i] - x.cum[g.i] > TRAP.len) return;
          const sd = Math.sign(nb.t);
          const lure = waysAt(x, g.first, g.end, true).some(h => { const o = turnOf(g.hIn, h); return Math.sign(o) === sd && Math.abs(o) >= TRAP.way && Math.abs(o) <= 180 - TRAP.way; });
          if (lure) breaks.push({ i: g.i, t: g.t, trap: true });
        });
        breaks.sort((a, b) => a.i - b.i);
      }
      const bounds =[0].concat(breaks.filter(b => b.i > 0 && b.i < P.length - 1).map(b => b.i), [P.length - 1]);
      const byI = {};
      breaks.forEach(b => { byI[b.i] = b; });
      const ent = kind === 'out' ? entry(x, true) : null, ex_ = kind === 'in' && next && next.type === 'out' ? entry(next, false) : null;
      const enteringDoor = ent ? ent.s.door : null;
      const leavingDoor = ex_ ? ex_.s.door : null;
      const destB = kind === 'out' ? (enteringDoor ? itemOf(c, enteringDoor.building) : T.b) : null;
      const destName = kind === 'out' ? (enteringDoor ? shortName(c, destB, places) : T.kind === 'point' || T.kind === 'here' ? T.label : shortName(c, T.b, places) || T.label) : '';
      // (Nor the room the walk starts in: "Past" the Henry West Room, walking out of it.)
      const skipLm = m => (m.item && ends.has(m.item)) || (endRoom && m.number === endRoom.number && m.kind === 'room') || (startRoom && m.number === startRoom.number && m.kind === 'room') || (endMk && endMk.kind === 'restroom' && m.kind === 'restroom');
      // "Toward {building}" only where the walk heads (Nov 5: "Toward Barnes" set off 90° from Barnes): the
      // destination when the first 20 m head within 60° of it, else the Conference building or lot the walk
      // heads for (within 45°, 15–400 m off; never the one it starts at), else the destination.
      const destPt = destB ? [destB.lx != null ? destB.lx : destB.cx, destB.ly != null ? destB.ly : destB.cy] : T.at && T.at[0] ? T.at[0] : null;
      const towardFrom = i0 => {
        const h = head(P[i0], along(P, x.cum, x.cum[i0] + 20)), ang = q => Math.abs(turnOf(h, head(P[i0], q)));
        // (A dropped pin is named as the app names it, "Head toward the dropped pin": round 3, round 2's leftover.)
        const fallback = destName || 'the dropped pin';
        if (destPt && ang(destPt) <= 60) return fallback;
        let best = null;
        lmOut.forEach(m => {
          if (m.item === F.b || (destB && m.item === destB)) return;
          const q = [m.item.lx != null ? m.item.lx : m.item.cx, m.item.ly != null ? m.item.ly : m.item.cy], d = dist(P[i0], q), a = ang(q);
          if (d >= 15 && d <= 400 && a <= 45 && (!best || a < best.a)) best = { m, a };
        });
        return best ? best.m.name : fallback;
      };
      // a landmark the step before named (its own or its Past) isn't named again: "Left at the elevator",
      // then "Right at the elevator" says nothing new; nor are the stairs or the elevator just taken
      const took = prev && prev.type === 'vert' ? prev.edges.some(e => e.s.kind === 'elevator' || e.s.kind === 'board') ? 'the elevator' : 'the stairs' : '';
      let said = took ? [took] : [];
      // (the stairs or the car just left aren't a landmark anywhere near on this floor: "Right at the stairs"
      // 10 ft after coming down them)
      const offAt = took ? [prev.edges[prev.edges.length - 1].to.x, prev.edges[prev.edges.length - 1].to.y] : null;
      const justTook = m => !!took && m.name === took && m.pts.some(q => dist(q, offAt) < 12);
      // Nor are the stairs or the elevator the next step takes "Past" (round 2 part 2, the last checks:
      // "Past the stairs 20 ft", then "Stairs up to the 2nd floor", on every walk to the Chapel's balcony).
      // A turn at them still names them: "Left at the elevator".
      const goes = next && next.type === 'vert' ? next.edges.some(e => e.s.kind === 'elevator' || e.s.kind === 'board') ? 'the elevator' : 'the stairs' : '';
      const onAt = goes ? [next.edges[0].from.x, next.edges[0].from.y] : null;
      const aboutTo = m => !!goes && m.name === goes && m.pts.some(q => dist(q, onAt) < 12);
      // A landmark is passed once a floor (or once outdoors): "Past Rec Center" twice in one walk said nothing.
      const passed = [];
      for (let k = 0; k + 1 < bounds.length; k++) {
        const i0 = bounds[k], i1 = bounds[k + 1], pts = P.slice(i0, i1 + 1), metres = x.cum[i1] - x.cum[i0], b = byI[i0];
        let text, icon, turn = null, lmName = '';
        const lms = kind === 'out' ? lmOut : (lmIn[x.bd + '|' + x.f] || []).filter(m => !justTook(m));
        if (k === 0 && !(b && b.cross != null)) {
          if (kind === 'out') {
            // the walk's first stretch outdoors: toward where it goes; one stretch to a door is "Head to the …"
            text = bounds.length === 2 && enteringDoor ? 'Head to the ' + enteringDoor.name : 'Head toward ' + towardFrom(i0);
            icon = 'straight';
          } else {
            // the way in (through the door, off the stairs) against the first stretch's own way: where the
            // step goes (its end, or FIRST metres on), so a doorway's jog it takes in doesn't decide it
            const t = lastHead == null ? 0 : turnOf(lastHead, head(P[0], along(P, x.cum, Math.min(x.cum[i1], FIRST))));
            turn = Math.round(t);
            text = Math.abs(t) < 25 ? 'Straight down the hall' : Side(t) + ' down the hall';
            icon = Math.abs(t) < 25 ? 'straight' : side(t);
          }
        } else if (b && b.cross != null) {
          text = 'Cross ' + b.cross; icon = 'cross'; turn = Math.round(b.t);
        } else if (b && b.cont) {
          // along one street, over the streets it meets (ALONG)
          text = 'Continue on ' + b.cont; icon = 'straight'; turn = 0;
        } else if (b && b.on) {
          // over the street, on the same way
          text = 'Continue toward ' + towardFrom(i0); icon = 'straight'; turn = 0;
        } else {
          // (Google's and Apple's words for walking, Nov 5, evening: "Slight left", "Turn left at …"; never "Bear")
          const a = Math.abs(b.t), lm = nearest(lms, P[i0], m => skipLm(m) || said.indexOf(m.name) > -1);
          turn = Math.round(b.t);
          if (kind === 'out') {
            // (at a fork "Keep left"; 120° and over "Sharp left": Google's and Apple's words, the review)
            if (a < 60 || b.keep) { const w = b.keep ? 'keep' : 'slight'; text = title(w) + ' ' + side(b.t); icon = w + '-' + side(b.t); }
            else { const w = a >= SHARP ? 'Sharp ' : 'Turn '; text = w + side(b.t) + (lm ? ' at ' + lm.name : ''); icon = (a >= SHARP ? 'sharp-' : '') + side(b.t); lmName = lm ? lm.name : ''; }
          } else {
            text = lm ? 'Turn ' + side(b.t) + ' at ' + lm.name : Side(b.t) + ' down the hall'; icon = side(b.t); lmName = lm ? lm.name : '';
          }
        }
        // Past {landmark}: one in reach of the stretch, beyond its first 3 m (not the step's own landmark)
        let detail = '';
        for (let i = i0 + 1; i <= i1 && !detail && !(b && b.cont); i++) {
          if (x.cum[i] - x.cum[i0] < 3) continue;
          const lm = nearest(lms, P[i], m => skipLm(m) || m.name === lmName || said.indexOf(m.name) > -1 || passed.indexOf(m.name) > -1 || aboutTo(m) || (kind === 'out' && m.name === destName));
          if (lm) detail = 'Past ' + lm.name;
        }
        said = [lmName, detail.replace(/^Past /, '')].filter(Boolean);
        if (detail) passed.push(detail.replace(/^Past /, ''));
        // the streets a walk along one crosses ("Across East 36th Street", "Across 4 streets"), then the short
        // crossings over a drive this step takes in, after any Past ("Past PPAC · Across the drive")
        const overs = b && b.cont ? b.overs : [];
        if (overs.length) detail = overs.length > 1 ? 'Across ' + overs.length + ' streets' : 'Across ' + overs[0];
        const nx = folded.filter(i => i >= i0 && i < i1).length;
        if (nx) detail = [detail, nx > 1 ? 'Across ' + nx + ' drives' : 'Across the drive'].filter(Boolean).join(' · ');
        if (k + 2 === bounds.length && leavingDoor) detail = 'To the ' + leavingDoor.name;
        const st = add({ kind: kind === 'out' ? 'outside' : 'inside', building: kind === 'out' ? null : codeOfB(x.bd), floor: kind === 'out' ? 0 : x.f, text, detail, metres, at: P[i0], pts, icon, turn });
        if (overs.length) st.streets = overs.slice();
      }
      // The way walked last, for the step after a door or a floor change: through the door (the entrance's
      // own line, when it's long enough to say), else the last HEAD_IN metres; never a stub's.
      const entE = x.edges[x.edges.length - 1], hDoor = kind === 'out' && entE && entE.s.kind === 'entrance' && entE.len >= 1.5 ? headIn(entE.P, 3) : null;
      const hLast = hDoor != null ? hDoor : headIn(P, HEAD_IN);
      if (hLast != null) lastHead = hLast;
      // the door (§4.7); a route that ends at the door says it once, as its end
      if (enteringDoor && ci < ctx.length - 1) {
        add({ kind: 'door', building: enteringDoor.code || null, floor: 1, text: 'Go in at the ' + enteringDoor.name, detail: '', metres: 0, at: P[P.length - 1], pts: [], icon: 'door', turn: null });
      }
    });

    // --- the end (§4.10): what's on the door, and its side
    // The side: where the walk leaves its hall or path (H: the start of the room's own rows, of the
    // entrance, or of the last straight stretch to a door), the heading along it there, and the door
    // from H. Ahead within 30° (a door at the hall's end).
    const lastE = E[E.length - 1];
    let k = E.length - 1;
    if (endRoom) { while (k > 0 && E[k - 1].type === 'in' && E[k - 1].s.num === String(endRoom.number) && (E[k - 1].s.kind === 'room' || E[k - 1].s.kind === 'hall')) k--; }
    const H = E[k].P[0], back = [];
    E.slice(0, k).forEach(e => e.P.forEach(p => { if (!back.length || dist(back[back.length - 1], p) > .01) back.push(p); }));
    // The hall's (or the path's) own way there: over its last END_W metres (Nov 5: taken from half a metre
    // back, a door's jog in IWU's centre line said "Room 143 · ahead" for a door on the left).
    let hh = back.length > 1 && plen(back) >= 1 ? headIn(back, END_W) : null;
    if (hh == null) hh = lastHead;
    const endPt = lastE.P[lastE.P.length - 1];
    let v = [endPt[0] - H[0], endPt[1] - H[1]];
    if (Math.hypot(v[0], v[1]) < .5) {
      const target = endRoom ? (lmIn[lastE.s.bd + '|' + lastE.to.f] || []).find(m => m.number === String(endRoom.number)) : null;
      const q = target && target.pts.length ? target.pts[target.pts.length - 1] : T.b ? [T.b.cx, T.b.cy] : endPt;
      v = [q[0] - H[0], q[1] - H[1]];
    }
    // (A walk that reaches the room's own point, its row starting inside the room, walks into it: ahead. The
    // last checks: Barnes's 1920 Gallery, open to the hall, said "Room 131 · on the left" from 16 cm.)
    const ta = hh == null || Math.hypot(v[0], v[1]) < 1 ? 0 : turnOf(hh, Math.atan2(v[1], v[0]));
    const sideWord = Math.abs(ta) <= AHEAD ? 'ahead' : ta > 0 ? 'on the right' : 'on the left';
    const sign = signOf(R, r, T, endRoom, lastE, lmIn, places);
    add({ kind: 'end', building: lastE.type === 'out' ? (T.code || null) : codeOfB(lastE.s.bd), floor: lastE.type === 'out' ? 0 : lastE.to.f, text: sign + ' · ' + sideWord, detail: '', metres: 0, at: endPt, pts: [], icon: 'arrive', turn: Math.round(ta), sign, side: sideWord });

    // --- the legs (§4.5): up to four, "Walk 4 min › South doors › Elevator to 2nd › Room 206"
    const legs = [];
    const vertBefore = (lo, hi) => ctx.slice(lo, hi).filter(x => x.type === 'vert' && x.edges[0].from.f !== x.edges[x.edges.length - 1].to.f);
    const firstOut = ctx.findIndex(x => x.type === 'out'), lastOut = ctx.length - 1 - ctx.slice().reverse().findIndex(x => x.type === 'out');
    const vleg = x => { const f1 = x.edges[x.edges.length - 1].to.f, lift = x.edges.some(e => e.s.kind === 'elevator' || e.s.kind === 'board'); return { kind: 'floor', text: (lift ? 'Elevator to ' : 'Stairs to ') + floorShort(f1), icon: lift ? 'elevator' : 'stairs' }; };
    let exitDoor = null, entryDoor = null;
    if (firstOut > -1) {
      const before = vertBefore(0, firstOut), ex = entry(ctx[firstOut], false);
      if (before.length) legs.push(Object.assign(vleg(before[before.length - 1]), { drop: 1 }));
      if (ex) { exitDoor = ex.s.door; legs.push({ kind: 'door', text: ex.s.door.name, icon: 'door', drop: 2 }); }
      legs.push({ kind: 'walk', text: 'Walk ' + M.minutes(outM, o.stepFree) + ' min', icon: 'walk' });
      const en = entry(ctx[lastOut], true);
      if (en) { entryDoor = en.s.door; if (T.kind !== 'building' && T.kind !== 'door') legs.push({ kind: 'door', text: en.s.door.name, icon: 'door' }); }
      const after = vertBefore(lastOut + 1, ctx.length);
      if (after.length) legs.push(vleg(after[after.length - 1]));
    } else {
      const v_ = vertBefore(0, ctx.length);
      if (v_.length) legs.push(vleg(v_[v_.length - 1]));
    }
    legs.push({ kind: 'end', text: sign, icon: 'arrive' });
    while (legs.length > 4) { const i = legs.findIndex(l => l.drop === 1) > -1 ? legs.findIndex(l => l.drop === 1) : legs.findIndex(l => l.drop === 2); if (i < 0) break; legs.splice(i, 1); }
    legs.forEach(l => { delete l.drop; });

    // --- what the map draws: each stretch outdoors or on a floor
    const parts = ctx.filter(x => x.type !== 'vert' && x.full.length > 1).map(x => ({ floor: x.type === 'out' ? 0 : x.f, building: x.type === 'out' ? null : codeOfB(x.bd), pts: x.full.map(p => [+p[0].toFixed(2), +p[1].toFixed(2)]) }));
    // (number and entrance: the build's own, so the map can name its mark; at: where it is.)
    const doorOut = d => d ? { id: d.id || '', name: d.name || d.label || '', building: d.building || d.name || '', code: d.code || '', number: d.number != null ? String(d.number) : '', entrance: d.entrance || '', at: isFinite(d.x) ? [+(+d.x).toFixed(2), +(+d.y).toFixed(2)] : isFinite(d.cx) ? [+(+d.cx).toFixed(2), +(+d.cy).toFixed(2)] : null } : null;
    return {
      ok: true, stepFree: !!o.stepFree,
      from: { kind: F.kind, label: F.label || '', building: F.b ? F.b.name : '', code: F.code || '' },
      to: { kind: T.kind, label: T.label || '', building: T.b ? T.b.name : '', code: T.code || '' },
      metres: Math.round(metres * 10) / 10, sec: Math.round(sec), min: Math.max(1, Math.round(sec / 60)), distance: M.feet(metres), outdoorMetres: Math.round(outM * 10) / 10,
      legs, legsText: legs.map(l => l.text).join(' › '), steps, parts,
      door: doorOut(entryDoor || (r.end && !r.end.inside ? r.end : null)), exit: doorOut(exitDoor || (r.start && !r.start.inside ? r.start : null)),
      guessedDoor: !!r.guessedEnd, notes,
      // (the To room isn't in the public build: the route ends at its building's door, which the end names)
      unmapped: !!T.unmapped
    };
  }
  // What's on the door (§4.10): a room's number ("Room 143"), or for a room with no number on its door its
  // name ("Piazza Terrace"); a building's door by its name; a place outdoors by its name.
  function signOf(R, r, T, endRoom, lastE, lmIn, places) {
    const c = R.campus;
    if (endRoom) {
      const m = (lmIn[lastE.s.bd + '|' + endRoom.floor] || []).find(x => x.number === String(endRoom.number));
      const iwu = m ? m.iwu : '';
      // A restroom by what it is, as the map names it (§10.1), never IWU's tag ("Room 153W"): the build's
      // rule (tools/campus/build-plugin.py): its name, else the number's W or M.
      if (m && m.kind === 'restroom') {
        const nm = String(iwu || '').toUpperCase(), num = String(endRoom.number).toUpperCase();
        return /\bWOMEN/.test(nm) ? 'Women’s restroom' : /\bMEN/.test(nm) ? 'Men’s restroom' : /FAMILY|UNISEX|ALL[- ]GENDER/.test(nm) ? 'Family restroom'
          : /W$/.test(num) ? 'Women’s restroom' : /M$/.test(num) ? 'Men’s restroom' : 'Restroom';
      }
      if (m && (m.hall || OPEN.test(iwu))) {
        const p = T.place, ip = p && R.index && R.index.places && R.index.places[p.code];
        const first = ip && ip.rooms && ip.rooms[0] && String(ip.rooms[0].number) === String(endRoom.number);
        return p && first ? nameIn(c, p, places, T.b) : title(iwu);
      }
      return 'Room ' + endRoom.number;
    }
    if (T.kind === 'building' || T.kind === 'door' || T.kind === 'hall') {
      const d = r.end;
      if (d && d.inside) return d.name;
      if (d && d.label) return d.label;
      return T.b ? T.b.name : T.label;
    }
    return T.label || T.sign || 'The end';
  }

  M.plan = plan;
  M.planEnds = endsOf;
  // A place's name without its building ("Henry West Room 143"): the small maps' plate says it as the steps do.
  M.nameIn = nameIn;
  // The door a place is walked to when there's no start (Nov 5, night; Michael: one door everywhere): the
  // planner's own default, the shortest whole walk from the building's entrances by its rules (a door
  // closed then or key only left out; no elevator preferred over the stairs). Step-free only when No stairs
  // is on (o.stepFree: the phone's Step-free switch, else the household's No stairs): then a step-free walk,
  // else (no door checked yet) up by the elevator where there's one, else the plain walk. The place
  // dialog's door line and its map, Places' map line and the small maps all take their door from it.
  // With No stairs on and no step-free walk, the walk it falls back to carries the planner's own reason as
  // r.why ("Doors not checked", "No step-free door", "2nd floor · No elevator"), so the dialog's door line and
  // the small maps say what Directions says (the check, Nov 5, night: the dialog said "East doors · Elevator"
  // while Directions said "No step-free route · Doors not checked").
  //   building: its code ("J"); to: as plan's ({ code } or { room: "J|2|220" }); o: { places, stepFree, date, time }
  //   → plan()'s result (r.door, r.steps, r.parts, r.why) or null.
  M.placeDoor = function (R, building, to, o) {
    o = o || {};
    const tries = o.stepFree ? [{ stepFree: true }, { lift: true }, {}] : [{}];
    let why = '';
    for (const t of tries) {
      const r = plan(R, { building }, to, Object.assign({}, o, { stepFree: false, lift: false }, t));
      if (r && r.ok && r.door && !r.unmapped) { if (why) r.why = why; return r; }
      if (t.stepFree && r && !r.ok && r.reason === 'No step-free route') why = r.why || '';
    }
    return null;
  };
})();
