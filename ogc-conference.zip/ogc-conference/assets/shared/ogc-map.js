/*
 * ogc-map.js — the campus and its halls as maps (Oct 8, Michael: "make a virtual map of the campus…
 * the actual layouts of each building accurate by floor… when you go to select a room, you know exactly
 * which floor you're on… so when you actually go, there's no surprises").
 *
 * The map area (Oct 10) reworked it for the plugin: the campus is kept per campus on the server
 * (includes/module-map.php), and the pages read it as before, in three files:
 *   campus.csv  code, name, kind, short, points: each building's outline in metres from a corner of the
 *               campus (x east, y south), from OpenStreetMap (ODbL: every drawn map credits it). kind:
 *               hall · dining · worship · venue · other · parking · green · water · road · path · steps.
 *               lat, lng (Oct 13): a building's entrance, where Directions sends the phone's maps app. A
 *               row of kind geo (Projection) ties the metres to latitude and longitude.
 *               Rows the server adds: kind door (name = its building, short = its name; step_free, open,
 *               key_only, checked), kind spot (spot = camper · parking · carts · desk · accessible) and
 *               kind closed (a closed path or door, from–to).
 *   places.csv  the schedule's places by code (B, B/131…), with their pins: x, y, floor, inside, door, outdoor.
 *   plans.csv   hall, floor, kind, label, x, y, w, h, note, status: each hall's floors in feet, one row a
 *               shape (room · bath · restroom-w · restroom-m · stairs · elevator · corridor · lobby · lounge ·
 *               laundry · entrance · wing · outline). status: sample · university · checked. The public
 *               gets only halls that aren't samples; Lodging sees samples marked "Sample plan".
 *
 * Pages draw these as SVG and handle the clicks: each room is a button (data-room = "hall|number"). Text
 * on a drawn map keeps its size on screen however wide the drawing is (fitText, below).
 */
(function () {
  'use strict';
  const O = window.OGC, esc = O.esc;
  const num = v => +v || 0;
  const reduced = () => window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  const CREDIT = '© OpenStreetMap contributors';
  const CREDIT_URL = 'https://www.openstreetmap.org/copyright';
  // One way to say a floor (the audit: four ways before).
  function floorName(n) {
    n = +n;
    if (!n) return 'Lower level';
    if (n === 1) return 'Ground floor';
    const s = n % 10 === 2 && n % 100 !== 12 ? 'nd' : n % 10 === 3 && n % 100 !== 13 ? 'rd' : n % 10 === 1 && n % 100 !== 11 ? 'st' : 'th';
    return n + s + ' floor';
  }
  // Names compared loosely: "Recreation & Wellness Center" is "Recreation and Wellness Center".
  const norm = s => String(s || '').toLowerCase().replace(/&/g, ' and ').replace(/[^a-z0-9]+/g, ' ').trim();

  /* ================================================================ the halls, by floor */

  function plans(rows) {
    const halls = {};
    (rows || []).filter(r => r.hall && !/^#/.test(r.hall) && r.kind).forEach(r => {
      const h = halls[r.hall] = halls[r.hall] || { name: r.hall, floors: {}, status: '' };
      if (r.status) h.status = r.status;
      const f = h.floors[r.floor] = h.floors[r.floor] || { hall: r.hall, floor: +r.floor || 1, shapes: [] };
      f.shapes.push({ kind: r.kind.trim().toLowerCase(), label: r.label || '', x: num(r.x), y: num(r.y), w: num(r.w), h: num(r.h), note: r.note || '', id: r.kind.trim().toLowerCase() === 'room' ? r.hall + '|' + r.label : '' });
    });
    Object.values(halls).forEach(h => {
      // A plan with no status is a sample: never shown as fact.
      h.status = h.status === 'university' || h.status === 'checked' ? h.status : 'sample';
      h.list = Object.values(h.floors).sort((a, b) => a.floor - b.floor);
      h.list.forEach(f => { f.status = h.status; bounds(f); });
    });
    return halls;
  }
  function bounds(f) {
    const out = f.shapes.find(s => s.kind === 'outline');
    const xs = f.shapes.filter(s => s.kind !== 'entrance');
    f.bounds = out ? { x: out.x, y: out.y, w: out.w, h: out.h } : xs.length ? {
      x: Math.min.apply(null, xs.map(s => s.x)), y: Math.min.apply(null, xs.map(s => s.y)),
      w: Math.max.apply(null, xs.map(s => s.x + s.w)) - Math.min.apply(null, xs.map(s => s.x)), h: Math.max.apply(null, xs.map(s => s.y + s.h)) - Math.min.apply(null, xs.map(s => s.y))
    } : { x: 0, y: 0, w: 10, h: 10 };
    f.rooms = f.shapes.filter(s => s.kind === 'room');
    return f;
  }

  // What's near a room, in words: its bathroom, the restrooms, the stairs and the lift, the entrance.
  // A sample plan's layout isn't fact, so nothing is said from it (polish 1).
  function near(f, room) {
    if (!f || !room || f.status === 'sample' || f.status === 'schematic') return [];
    const cx = s => s.x + s.w / 2, cy = s => s.y + s.h / 2, d = (a, b) => Math.hypot(cx(a) - cx(b), cy(a) - cy(b));
    const touches = (a, b) => a.x <= b.x + b.w + .5 && b.x <= a.x + a.w + .5 && a.y <= b.y + b.h + .5 && b.y <= a.y + a.h + .5;
    const out = [], of = k => f.shapes.filter(s => s.kind === k);
    const bath = of('bath').find(b => touches(b, room));
    if (bath) {
      const other = f.rooms.find(r => r !== room && touches(r, bath));
      out.push(other ? 'Shared bath with ' + other.label : 'Private bath');
    }
    [['restroom-w', 'Near the women’s restroom'], ['restroom-m', 'Near the men’s restroom']].forEach(k => { const s = of(k[0]).sort((a, b) => d(a, room) - d(b, room))[0]; if (s && d(s, room) < 45) out.push(k[1]); });
    const lift = of('elevator').sort((a, b) => d(a, room) - d(b, room))[0];
    if (f.floor > 1) out.push(lift ? (d(lift, room) < 40 ? 'Near the elevator' : Math.round(d(lift, room) / 10) * 10 + ' ft to the elevator') : 'Stairs only');
    const stairs = of('stairs').sort((a, b) => d(a, room) - d(b, room))[0];
    if (stairs && d(stairs, room) < 30) out.push('Near the stairs');
    return out;
  }
  const stairsOnly = f => !!f && f.floor > 1 && !f.shapes.some(s => s.kind === 'elevator');

  // Rooms side by side, as the plan has them (Oct 8): each floor's rooms in order along each side of
  // the corridor, a room marked gap when it doesn't share a wall or a bathroom with the one before. Room
  // suggestions (ogc-signups.js) then keep a family's rooms next to each other, not across the hall.
  // A floor with no drawn plan gets a schematic (Lodging's members only): rooms along a corridor in
  // number order, odd on one side and even on the other, stairs at the ends.
  function orderFloors(floors, halls) {
    const beside = (a, b, baths) => {
      const ox = Math.min(a.x + a.w, b.x + b.w) - Math.max(a.x, b.x), oy = Math.min(a.y + a.h, b.y + b.h) - Math.max(a.y, b.y);
      const gx = Math.max(a.x, b.x) - Math.min(a.x + a.w, b.x + b.w), gy = Math.max(a.y, b.y) - Math.min(a.y + a.h, b.y + b.h);
      const bathIn = (x0, y0, x1, y1) => baths.some(t => t.x < x1 && x0 < t.x + t.w && t.y < y1 && y0 < t.y + t.h);
      if (oy > Math.min(a.h, b.h) * .6) return gx <= .6 || (gx < 7 && bathIn(Math.min(a.x + a.w, b.x + b.w), Math.max(a.y, b.y), Math.max(a.x, b.x), Math.min(a.y + a.h, b.y + b.h)));
      if (ox > Math.min(a.w, b.w) * .6) return gy <= .6 || (gy < 7 && bathIn(Math.max(a.x, b.x), Math.min(a.y + a.h, b.y + b.h), Math.min(a.x + a.w, b.x + b.w), Math.max(a.y, b.y)));
      return false;
    };
    const W = window.OGC_WP || {}, member = !!(W.webmaster || (W.member && W.member.length));
    floors.forEach(f => {
      let h = halls[f.hall], pf = h && h.floors[f.floor];
      if (!pf && member && f.rooms.length) {
        h = halls[f.hall] = h || { name: f.hall, floors: {}, status: 'schematic', list: [] };
        pf = h.floors[f.floor] = schematic(f);
        h.list = Object.values(h.floors).sort((a, b) => a.floor - b.floor);
      }
      if (!pf) return;
      const shape = {}; pf.rooms.forEach(r => { shape[r.label] = r; });
      const baths = pf.shapes.filter(s => s.kind === 'bath');
      const placed = f.rooms.filter(r => shape[r.num]), rest = f.rooms.filter(r => !shape[r.num]);
      const nb = new Map(placed.map(r => [r, placed.filter(o => o !== r && beside(shape[r.num], shape[o.num], baths))]));
      const seen = new Set(), lines = [];
      placed.slice().sort((a, b) => a.num - b.num).sort((a, b) => (nb.get(a).length > 1) - (nb.get(b).length > 1)).forEach(start => {
        if (seen.has(start)) return;
        const line = []; let cur = start, prev = null;
        while (cur && !seen.has(cur)) { seen.add(cur); line.push(cur); const next = nb.get(cur).find(o => o !== prev && !seen.has(o)); prev = cur; cur = next; }
        lines.push(line);
      });
      lines.sort((a, b) => a[0].num - b[0].num);
      lines.forEach(l => l.forEach((r, i) => { r.gap = i === 0; }));
      rest.forEach(r => { r.gap = true; });
      f.rooms.splice(0, f.rooms.length, ...[].concat.apply([], lines).concat(rest));
      f.share = '';
    });
    return floors;
  }
  function schematic(f) {
    const nums = f.rooms.map(r => r.num).sort((a, b) => a - b), odd = nums.filter(n => n % 2), even = nums.filter(n => !(n % 2));
    const RW = 14, RH = 14, C = 7, n = Math.max(odd.length, even.length, 1), S = 12, shapes = [];
    shapes.push({ kind: 'stairs', label: '', x: 0, y: 0, w: S, h: RH * 2 + C }, { kind: 'stairs', label: '', x: S + n * RW, y: 0, w: S, h: RH * 2 + C });
    shapes.push({ kind: 'corridor', label: '', x: S, y: RH, w: n * RW, h: C });
    odd.forEach((k, i) => shapes.push({ kind: 'room', label: String(k), x: S + i * RW, y: 0, w: RW, h: RH, id: f.hall + '|' + k }));
    even.forEach((k, i) => shapes.push({ kind: 'room', label: String(k), x: S + i * RW, y: RH + C, w: RW, h: RH, id: f.hall + '|' + k }));
    return bounds({ hall: f.hall, floor: f.floor, shapes, status: 'schematic' });
  }

  /* ================================================================ text that keeps its size */

  // A drawn map (svg.pl-fit) is scaled to its box, so its words would shrink with it. Each word carries
  // its size in screen pixels (data-px), and at most what its room allows (data-max, in the drawing's
  // units); fitText sets them from the drawing's scale, and hides any word that would sit on another
  // or run off the edge (data-rank: the lower, the more it matters). Re-done when the map is resized.
  const seen = new WeakSet();
  const ro = 'ResizeObserver' in window ? new ResizeObserver(es => es.forEach(e => fitText(e.target))) : null;
  function fitText(svg) {
    const r = svg.getBoundingClientRect(), vb = svg.viewBox && svg.viewBox.baseVal;
    if (!r.width || !vb || !vb.width) return;
    const k = Math.max(vb.width / r.width, vb.height / Math.max(1, r.height));
    svg.style.setProperty('--k', k.toFixed(4));
    svg.querySelectorAll('[data-px]').forEach(t => {
      let s = +t.dataset.px * k;
      if (t.dataset.max) s = Math.min(s, +t.dataset.max);
      t.style.fontSize = s.toFixed(3) + 'px';
      if (t.dataset.halo) t.style.strokeWidth = (+t.dataset.halo * k).toFixed(3) + 'px';
    });
    svg.querySelectorAll('[data-sz]').forEach(g => {
      const [x, y] = g.dataset.at.split(','), s = +g.dataset.sz * k;
      g.setAttribute('transform', 'translate(' + x + ' ' + y + ') scale(' + s.toFixed(4) + ')');
    });
    // Words that must fit a room (polish 1: "L. Garret", "E. Hick" cut by the walls and the marks):
    // data-fitw is the width they have; a name steps down through data-alts ("L. Garrett|Garrett"),
    // then goes (it's in the room's title); a number shrinks to fit.
    svg.querySelectorAll('[data-fitw]').forEach(t => {
      const w = +t.dataset.fitw, alts = t.dataset.alts ? t.dataset.alts.split('|') : null;
      const wide = () => { try { return t.getBBox().width; } catch (e) { return 0; } };
      if (alts) { t.textContent = alts[0]; for (let i = 1; i < alts.length && wide() > w; i++) t.textContent = alts[i]; if (wide() > w) t.textContent = ''; return; }
      // (Never under 11 px on screen, polish 2: a word that small isn't read.)
      const bw = wide(); if (bw > w && bw) t.style.fontSize = Math.max(11 * k, parseFloat(t.style.fontSize) * w / bw * .98).toFixed(3) + 'px';
    });
    // Words that must stay inside the drawing (an entrance's name at the plan's edge), and inside the
    // box that clips it when a page scrolls a wide plan (polish 1: "Entra" at Lodging's card edge).
    let lo = vb.x, hi = vb.x + vb.width;
    if (svg.querySelector('[data-keep]')) {
      for (let el = svg.parentElement, n = 0; el && n < 6; el = el.parentElement, n++) {
        if (getComputedStyle(el).overflowX !== 'visible') { const cr = el.getBoundingClientRect(); hi = Math.min(hi, vb.x + (cr.right - 6 - r.left) * k); lo = Math.max(lo, vb.x + (cr.left + 6 - r.left) * k); break; }
      }
    }
    svg.querySelectorAll('[data-keep]').forEach(t => {
      t.removeAttribute('dx');
      let b; try { b = t.getBBox(); } catch (e) { return; }
      const over = b.x + b.width - (hi - k * 2), under = lo + k * 2 - b.x;
      if (over > 0) t.setAttribute('dx', (-over).toFixed(2)); else if (under > 0) t.setAttribute('dx', under.toFixed(2));
    });
    const labs = Array.from(svg.querySelectorAll('[data-rank]')).sort((a, b) => a.dataset.rank - b.dataset.rank), placed = [];
    // A pin, a spot or an edge arrow is in the way of names too.
    svg.querySelectorAll('.pl-pin, .pl-spot, .pl-far').forEach(g => { g.style.visibility = ''; let b; try { b = g.getBBox(); } catch (e) { return; } const [x, y] = g.dataset.at.split(',').map(Number), sc = +g.dataset.sz * k; placed.push({ x0: x + b.x * sc, y0: y + b.y * sc, x1: x + (b.x + b.width) * sc, y1: y + (b.y + b.height) * sc }); });
    // The licence's credit too (polish 2: "Chapel" ran into it on the small maps).
    svg.querySelectorAll('.pl-credit').forEach(t => { let b; try { b = t.getBBox(); } catch (e) { return; } if (b.width) placed.push({ x0: b.x - 2 * k, y0: b.y - 2 * k, x1: b.x + b.width + 2 * k, y1: b.y + b.height + 2 * k }); });
    const hits = box => placed.reduce((n, p) => n + (box.x0 < p.x1 && box.x1 > p.x0 && box.y0 < p.y1 && box.y1 > p.y0 ? 1 : 0), 0);
    const outside = b => b.x < vb.x || b.y < vb.y || b.x + b.width > vb.x + vb.width || b.y + b.height > vb.y + vb.height;
    // Where a name may go, best first: its own point, the middle of the building's other arms, then
    // just outside its outline (above, below, beside). A Conference building's name (rank 2 or less)
    // tries all of them, then a size smaller, and is never dropped (polish 1: Hodson lost its name to
    // the Chapel's while unused halls kept theirs).
    const spots = t => {
      const fs = parseFloat(t.style.fontSize) || 9, x = +t.dataset.x0, y = +t.dataset.y0, out = [[x, y, t.dataset.a0 || '']];
      (t.dataset.in || '').split(';').filter(Boolean).forEach(s => { const p = s.split(',').map(Number); out.push([p[0], p[1], '']); });
      if (t.dataset.bb) { const [x0, y0, x1, y1] = t.dataset.bb.split(',').map(Number), cx = (x0 + x1) / 2; out.push([cx, y0 - fs * .75, ''], [cx, y1 + fs * .75, ''], [x1 + fs * .4, y, 'start'], [x0 - fs * .4, y, 'end']); }
      return out;
    };
    const put = (t, s) => { t.setAttribute('x', s[0].toFixed(2)); t.setAttribute('y', s[1].toFixed(2)); t.style.textAnchor = s[2] || ''; t.querySelectorAll('tspan[x]').forEach(sp => sp.setAttribute('x', s[0].toFixed(2))); };
    labs.forEach(t => {
      t.style.visibility = ''; t.removeAttribute('dy');
      if (!t.dataset.x0) { t.dataset.x0 = t.getAttribute('x'); t.dataset.y0 = t.getAttribute('y'); }
      put(t, [+t.dataset.x0, +t.dataset.y0, t.dataset.a0 || '']);
      const m = 2 * k, rank = +t.dataset.rank;
      const boxOf = () => { let b; try { b = t.getBBox(); } catch (e) { return null; } return b.width ? { b, box: { x0: b.x - m, y0: b.y - m, x1: b.x + b.width + m, y1: b.y + b.height + m } } : null; };
      let at = boxOf(); if (!at) return;
      if (!outside(at.b) && !hits(at.box)) { placed.push(at.box); return; }
      if (rank > 2 && !t.dataset.bb) { t.style.visibility = 'hidden'; return; }
      const list = spots(t);
      let best = null;
      for (const s of list.slice(1).concat(rank <= 2 ? [null] : [])) {
        if (s === null) { t.style.fontSize = (parseFloat(t.style.fontSize) * 12 / 13).toFixed(3) + 'px'; for (const z of list) { put(t, z); const q = boxOf(); if (q && !outside(q.b) && !hits(q.box)) { best = { s: z, q }; break; } } break; }
        put(t, s); const q = boxOf();
        if (q && !outside(q.b) && !hits(q.box)) { best = { s, q }; break; }
      }
      if (best) { put(t, best.s); placed.push(best.q.box); return; }
      if (rank > 2) { t.style.visibility = 'hidden'; return; }
      // Nothing clear: where it covers least, still shown.
      let least = null;
      list.forEach(s => { put(t, s); const q = boxOf(); if (q && !outside(q.b)) { const n = hits(q.box); if (!least || n < least.n) least = { s, q, n }; } });
      if (least) { put(t, least.s); placed.push(least.q.box); } else { put(t, list[0]); if (rank > 0) t.style.visibility = 'hidden'; }
    });
    // An edge arrow goes with its name.
    svg.querySelectorAll('.pl-far').forEach(g => { const l = svg.querySelector('[data-farlab="' + g.dataset.far + '"]'); if (l && l.style.visibility === 'hidden') g.style.visibility = 'hidden'; });
    svg.classList.add('is-fitted');
  }
  function watch() {
    document.querySelectorAll('svg.pl-fit').forEach(s => { if (!seen.has(s)) { seen.add(s); if (ro) ro.observe(s); fitText(s); } });
  }
  let pending = 0;
  if ('MutationObserver' in window) new MutationObserver(() => { if (!pending) pending = requestAnimationFrame(() => { pending = 0; watch(); }); }).observe(document.documentElement, { childList: true, subtree: true });
  // Printing: the drawing at the page's width.
  addEventListener('beforeprint', () => document.querySelectorAll('svg.pl-fit').forEach(fitText));
  addEventListener('afterprint', () => document.querySelectorAll('svg.pl-fit').forEach(fitText));

  /* ================================================================ a floor, drawn */

  const LABEL = { 'restroom-w': 'Women', 'restroom-m': 'Men', stairs: 'Stairs', elevator: 'Elevator', lobby: 'Lobby', lounge: 'Lounge', laundry: 'Laundry' };
  const glyph = {
    // A small padlock (taken), a walker and an older person's cane (Lodging's marks), a bathtub (a shared bath).
    lock: 'M-2.2 -0.4h4.4v3.4h-4.4zM-1.3 -0.4v-1.2a1.3 1.3 0 0 1 2.6 0v1.2',
    walker: 'M-1.6 2.6v-4.2h3.2v4.2M-1.6 -0.2h3.2M-2 2.6h.8M1.2 2.6h.8',
    older: 'M0.4 -2.6c-1 0-1.4 .8-1.4 1.4M-1 -1.2v3.8',
    tub: 'M-2.4 -0.2h4.8v1.2a1.4 1.4 0 0 1-1.4 1.4h-2a1.4 1.4 0 0 1-1.4-1.4zM-1.6 -0.2v-1.6a.7 .7 0 0 1 1.2-.4'
  };
  // o.state(room) → free · taken · held · off · sel · mine · sug · other; o.tag(room) → a name under the
  // number; o.mark(room) → 'walker' | 'older' (Lodging's); o.label(room, state) → what a screen reader
  // hears; o.pick: rooms are buttons; o.title. On a phone (o.px, or o.narrow) a hall with wings is drawn
  // a wing at a time, stacked, each the screen's width, so a room's number is readable (the audit: the
  // whole L-shaped floor at a phone's width left the rooms a few pixels wide). A sample plan says so.
  function floorSvg(f, o) {
    o = o || {};
    const narrow = !!(o.narrow || o.px);
    const wings = f.shapes.filter(s => s.kind === 'wing');
    // A plan showing someone's own rooms (nothing to pick) draws the other rooms plainly, neither free nor taken.
    const own = !o.pick && o.state && f.rooms.some(r => o.state(r) === 'mine');
    const state = r => { const s = o.state ? o.state(r) : 'free'; return own && s === 'free' ? 'plain' : s; };
    const tag = f.status === 'sample' ? 'Sample plan' : f.status === 'schematic' ? 'Schematic' : '';
    const tagTitle = f.status === 'sample' ? 'Layout and room numbers to be checked against the university’s plans' : 'Rooms in number order; the hall’s plan isn’t drawn yet';
    // Polish 1: a sample says what to do about it, "Check" (the walk-through's Halls tab, for those who
    // can open it), and it isn't drawn like the dark mockup pills.
    const W = window.OGC_WP || {}, member = !!(W.webmaster || (W.member && W.member.length));
    const yr = o.year || new URLSearchParams(location.search).get('year') || '';
    const href = o.sampleHref != null ? o.sampleHref : member && W.url && f.status === 'sample' ? W.url('../year/?' + (yr ? 'year=' + encodeURIComponent(yr) + '&' : '') + 'part=conference&tool=pins&tab=halls') : '';
    const head = tag ? '<p class="pl-sample" title="' + esc(tagTitle) + '"><span>' + esc(tag) + '</span>' + (href ? ' · <a href="' + esc(href) + '">Check</a>' : '') + '</p>' : '';
    // A hall whose wings run in one straight line is one bar, drawn whole (polish 1: Carmin, a straight
    // bar, read as two buildings); only a corridor that turns is split.
    const inLine = wings.length > 1 && (wings.every(w => Math.abs(w.y - wings[0].y) < 2 && Math.abs(w.h - wings[0].h) < 2) || wings.every(w => Math.abs(w.x - wings[0].x) < 2 && Math.abs(w.w - wings[0].w) < 2));
    if (narrow && wings.length > 1 && !inLine) {
      // Each wing with the shapes whose middle is inside it.
      const inside = (s, w) => { const x = s.x + s.w / 2, y = s.y + s.h / 2; return x >= w.x - .5 && x <= w.x + w.w + .5 && y >= w.y - .5 && y <= w.y + w.h + .5; };
      const used = new Set();
      const bands = wings.map(w => {
        const sh = f.shapes.filter(s => s.kind !== 'wing' && s.kind !== 'outline' && !used.has(s) && (s.kind === 'entrance' ? Math.abs(s.x - Math.max(w.x, Math.min(w.x + w.w, s.x))) < 3 && Math.abs(s.y - Math.max(w.y, Math.min(w.y + w.h, s.y))) < 3 : inside(s, w)));
        sh.forEach(s => used.add(s));
        return { hall: f.hall, floor: f.floor, status: f.status, shapes: [Object.assign({}, w)].concat(sh), bounds: { x: w.x, y: w.y, w: w.w, h: w.h }, rooms: sh.filter(s => s.kind === 'room') };
      }).filter(b => b.rooms.length);
      const nums = b => b.rooms.map(r => +r.label).filter(n => !isNaN(n)).sort((a, z) => a - z);
      return '<div class="pl-bands" role="group" aria-label="' + esc(o.title || f.hall + ', ' + floorName(f.floor)) + '">' + head + bands.map(b => {
        const n = nums(b);
        return '<div class="pl-band"><p class="pl-band__h">' + (n.length ? 'Rooms ' + n[0] + '–' + n[n.length - 1] : '') + '</p>' + drawFloor(b, o, state, b.bounds.h > b.bounds.w ? 'ccw' : false) + '</div>';
      }).join('') + '</div>';
    }
    const turn = narrow ? f.bounds.h > f.bounds.w * 1.15 && f.bounds.w < 60 ? false : f.bounds.w > f.bounds.h * 1.15 ? false : !!o.turn : !!o.turn;
    return '<div class="pl-bands" role="group" aria-label="' + esc(o.title || f.hall + ', ' + floorName(f.floor)) + '">' + head + drawFloor(f, o, state, turn) + '</div>';
  }
  function drawFloor(f, o, state, turn) {
    const b = f.bounds, pad = 5;
    // Turned: a quarter turn, so a long wing lies across the screen (a wing anticlockwise, so its rooms read in order left to right).
    const P = (x, y) => turn === 'ccw' ? [y, b.x + b.w - (x - b.x)] : turn ? [b.y + b.h - (y - b.y), x] : [x, y];
    const R = s => { const a = P(s.x, s.y), c = P(s.x + s.w, s.y + s.h); return { x: Math.min(a[0], c[0]), y: Math.min(a[1], c[1]), w: Math.abs(c[0] - a[0]), h: Math.abs(c[1] - a[1]) }; };
    const B = R(b), vb = [B.x - pad, B.y - pad, B.w + pad * 2, B.h + pad * 2];
    const sideOf = p => { const d = { l: p[0] - B.x, r: B.x + B.w - p[0], t: p[1] - B.y, b: B.y + B.h - p[1] }; return Object.keys(d).reduce((m, k) => d[k] < d[m] ? k : m, 'l'); };
    // Room for an entrance's word outside its wall.
    f.shapes.filter(s => s.kind === 'entrance').forEach(s => { const sd = sideOf(P(s.x, s.y)); if (sd === 'r') vb[2] += 18; if (sd === 'l') { vb[0] -= 18; vb[2] += 18; } if (sd === 't') { vb[1] -= 6; vb[3] += 6; } if (sd === 'b') vb[3] += 6; });
    const out = ['<svg class="pl-floor pl-fit" viewBox="' + vb.map(n => n.toFixed(1)).join(' ') + '" role="presentation">',
      '<defs><pattern id="pl-steps" width="2.2" height="2.2" patternUnits="userSpaceOnUse"><line x1="0" y1="0" x2="2.2" y2="0" stroke="#b9b3a6" stroke-width=".5"/></pattern></defs>'];
    const wings = f.shapes.filter(s => s.kind === 'wing');
    (wings.length ? wings : [b]).forEach(s => { const r = R(s); out.push('<rect class="pl-walls" x="' + r.x + '" y="' + r.y + '" width="' + r.w + '" height="' + r.h + '"/>'); });
    (wings.length ? wings : [b]).forEach(s => { const r = R(s); out.push('<rect class="pl-inside" x="' + (r.x + .45) + '" y="' + (r.y + .45) + '" width="' + Math.max(0, r.w - .9) + '" height="' + Math.max(0, r.h - .9) + '"/>'); });
    const baths = [];
    f.shapes.forEach(s => {
      if (s.kind === 'room' || s.kind === 'outline' || s.kind === 'wing') return;
      if (s.kind === 'bath') { baths.push(s); return; }
      const r = R(s);
      if (s.kind === 'entrance') {
        const p = P(s.x, s.y), sd = sideOf(p);
        const lab = sd === 'r' ? { x: p[0] + 2.5, y: p[1], a: 'start' } : sd === 'l' ? { x: p[0] - 2.5, y: p[1], a: 'end' } : sd === 't' ? { x: p[0], y: p[1] - 2.5, a: 'middle' } : { x: p[0], y: p[1] + 4.5, a: 'middle' };
        out.push('<g class="pl-door"><title>' + esc(s.label || 'Entrance') + '</title><circle cx="' + p[0] + '" cy="' + p[1] + '" r="1.6"/><text x="' + lab.x + '" y="' + lab.y + '" dominant-baseline="middle" style="text-anchor:' + lab.a + '" data-a0="' + lab.a + '" data-rank="4" data-px="11" data-keep="1" font-size="3">' + esc(s.label || 'Entrance') + '</text></g>');
        return;
      }
      const cls = 'pl-' + s.kind.replace(/[^a-z-]/g, '');
      out.push('<rect class="' + cls + '" x="' + r.x + '" y="' + r.y + '" width="' + r.w + '" height="' + r.h + '"/>');
      const t = s.label || LABEL[s.kind];
      if (t && s.kind !== 'corridor' && Math.min(r.w, r.h) >= 5) out.push('<text class="pl-t ' + cls + '-t" data-rank="2" x="' + (r.x + r.w / 2) + '" y="' + (r.y + r.h / 2) + '" dominant-baseline="middle" data-px="11" data-max="' + Math.min(r.h * .45, (r.w * 1.7) / Math.max(4, t.length)).toFixed(2) + '" font-size="3">' + esc(t) + '</text>');
    });
    // Polish 1: no word under a bath or a corner mark, or past a wall. Each room's marks take a corner
    // clear of its bath; its number and name are centred in the widest clear stretch of their line and
    // fitted to it (fitText); a name steps down to the surname, then to nothing (it's in the title).
    const bathR = f.shapes.filter(s => s.kind === 'bath').map(R);
    f.rooms.forEach(s => {
      const r = R(s), st = state(s), tag = o.tag ? o.tag(s) : '', mark = o.mark ? o.mark(s) : '';
      const lab = o.label ? o.label(s, st) : 'Room ' + s.label + ', ' + ({ free: 'free', taken: 'taken', held: 'kept', off: 'unavailable', sel: 'selected', mine: 'yours', sug: 'suggested', other: 'requested', plain: '' })[st];
      const live = o.pick && (st === 'free' || st === 'sel' || st === 'sug' || o.pickAll);
      const nb = near(f, s);
      out.push('<g class="pl-room is-' + st + '" data-room="' + esc(s.id) + '"' + (live ? ' role="button" tabindex="0" aria-pressed="' + (st === 'sel') + '"' : ' role="img"') + ' aria-label="' + esc(lab + (tag ? ', ' + tag : '') + (nb.length ? '. ' + nb.join(', ') : '')) + '">' +
        '<title>' + esc([lab].concat(tag ? [tag] : [], nb).join(' · ')) + '</title><rect x="' + r.x + '" y="' + r.y + '" width="' + r.w + '" height="' + r.h + '" rx=".5"/>');
      const room = Math.min(r.w, r.h), pad = room * .06;
      const clip = b => ({ x0: Math.max(b.x, r.x), x1: Math.min(b.x + b.w, r.x + r.w), y0: Math.max(b.y, r.y), y1: Math.min(b.y + b.h, r.y + r.h) });
      const obs = bathR.filter(b => b.x < r.x + r.w && b.x + b.w > r.x && b.y < r.y + r.h && b.y + b.h > r.y).map(clip);
      // Corner marks: the lock (taken) or "Kept" (held) top right if clear, Lodging's mark top left.
      const bs = room * .26, cornerAt = k => ({ tr: [r.x + r.w - bs * .7, r.y + bs * .7], tl: [r.x + bs * .7, r.y + bs * .7], br: [r.x + r.w - bs * .7, r.y + r.h - bs * .7], bl: [r.x + bs * .7, r.y + r.h - bs * .7] })[k];
      const boxAt = p => ({ x0: p[0] - bs / 2, x1: p[0] + bs / 2, y0: p[1] - bs / 2, y1: p[1] + bs / 2 });
      const clear = p => !obs.some(q => { const b = boxAt(p); return b.x0 < q.x1 && b.x1 > q.x0 && b.y0 < q.y1 && b.y1 > q.y0; });
      const taken = [];
      const corner = order => { for (const k of order) { const p = cornerAt(k); if (taken.indexOf(k) < 0 && clear(p)) { taken.push(k); return p; } } const k = order.find(z => taken.indexOf(z) < 0) || order[0]; taken.push(k); return cornerAt(k); };
      const marks = [];
      // Lodging's walker and older marks 12 px or more on screen (polish 2: 6 px blue glyphs); the lock 9 px.
      const glyphAt = (g, cls, p, title) => { marks.push(boxAt(p)); out.push('<g class="pl-mark ' + cls + '" data-at="' + p[0].toFixed(2) + ',' + p[1].toFixed(2) + '" data-sz="' + (g === 'lock' ? 1.8 : 2.1) + '" transform="translate(' + p[0].toFixed(2) + ' ' + p[1].toFixed(2) + ') scale(' + (bs / 5.4).toFixed(3) + ')">' + (title ? '<title>' + title + '</title>' : '') + (g === 'lock' ? '' : '<circle class="pl-markbg" r="3.1"/>') + '<path d="' + glyph[g] + '"/></g>'); };
      if (mark && glyph[mark]) glyphAt(mark, 'is-' + mark, corner(['tl', 'bl', 'tr', 'br']), mark === 'walker' ? 'Walker' : 'Older');
      if (st === 'taken') glyphAt('lock', 'is-lock', corner(['tr', 'br', 'tl', 'bl']));
      // The widest clear stretch of a line (y0–y1) across the room.
      const stretch = (y0, y1) => {
        let segs = [[r.x + pad, r.x + r.w - pad]];
        obs.concat(marks).forEach(q => { if (q.y0 >= y1 || q.y1 <= y0) return; segs = [].concat.apply([], segs.map(g => q.x1 <= g[0] || q.x0 >= g[1] ? [g] : [[g[0], q.x0 - pad * .5], [q.x1 + pad * .5, g[1]]].filter(z => z[1] - z[0] > 0))); });
        return segs.sort((a, z) => (z[1] - z[0]) - (a[1] - a[0]))[0] || [r.x + pad, r.x + r.w - pad];
      };
      const two = tag || st === 'sel' || st === 'mine' || st === 'held';
      const nfs = room * (two ? .36 : .4), ty = two ? r.y + r.h * .38 : r.y + r.h / 2, ns = stretch(ty - nfs / 2, ty + nfs / 2), ncx = (ns[0] + ns[1]) / 2;
      out.push('<text class="pl-num" x="' + ncx.toFixed(2) + '" y="' + ty.toFixed(2) + '" dominant-baseline="middle" data-px="14" data-max="' + nfs.toFixed(2) + '" data-fitw="' + (ns[1] - ns[0]).toFixed(2) + '" font-size="' + (room * .3).toFixed(1) + '">' + esc(s.label) + '</text>');
      const tfs = room * .24, tgy = r.y + r.h * .73, ts = stretch(tgy - tfs / 2, tgy + tfs / 2), tcx = (ts[0] + ts[1]) / 2;
      if (st === 'sel' || st === 'mine') out.push('<path class="pl-check" d="M' + (tcx - room * .13).toFixed(2) + ' ' + (r.y + r.h * .7).toFixed(2) + 'l' + (room * .09).toFixed(2) + ' ' + (room * .09).toFixed(2) + ' ' + (room * .18).toFixed(2) + ' -' + (room * .2).toFixed(2) + '"/>');
      else if (tag) {
        // At 11.5 px or not at all: a name steps down to the surname, then goes (it's in the title).
        const sur = String(tag).replace(/^.*\.\s*/, '');
        const alts = [tag].concat(sur && sur !== tag ? [sur] : []).join('|');
        out.push('<text class="pl-tag" x="' + tcx.toFixed(2) + '" y="' + tgy.toFixed(2) + '" dominant-baseline="middle" data-px="11.5" data-fitw="' + (ts[1] - ts[0]).toFixed(2) + '" data-alts="' + esc(alts) + '" font-size="' + (room * .2).toFixed(1) + '">' + esc(tag) + '</text>');
      } else if (st === 'held') {
        // Kept for those who need it: the word under the number at 11 px (polish 2: a 6 px corner word).
        out.push('<text class="pl-kept" x="' + tcx.toFixed(2) + '" y="' + tgy.toFixed(2) + '" dominant-baseline="middle" data-px="11" data-fitw="' + (ts[1] - ts[0]).toFixed(2) + '" data-alts="Kept" font-size="' + (room * .2).toFixed(1) + '">Kept</text>');
      }
      out.push('</g>');
    });
    // A shared bathroom: a small room of its own between the two it serves, with a tub to say what it is.
    baths.forEach(s => { const r = R(s); out.push('<g class="pl-bathg"><title>Shared bath</title><rect class="pl-bath" x="' + r.x + '" y="' + r.y + '" width="' + r.w + '" height="' + r.h + '" rx=".3"/><g class="pl-mark is-tub" data-at="' + (r.x + r.w / 2) + ',' + (r.y + r.h / 2) + '" data-sz="1.2" transform="translate(' + (r.x + r.w / 2) + ' ' + (r.y + r.h / 2) + ') scale(' + (Math.min(r.w, r.h) * .14).toFixed(3) + ')"><path d="' + glyph.tub + '"/></g></g>'); });
    out.push('</svg>');
    return out.join('');
  }
  // Which way to draw a floor on a laptop: whichever way it's long. (A phone draws a wing at a time.)
  const turnFor = (f, narrow) => { const b = f.bounds; return narrow ? false : b.h > b.w * 1.15; };
  // A legend for the states a floor shows. list: [['free', 'Free'], ['taken', 'Taken']…]
  // (Lodging's walker and older marks are drawn as on the plan: ['walker', 'Walker'].)
  const legendMark = k => glyph[k] ? '<svg class="pl-legend__mark is-' + k + '" viewBox="-3.6 -3.6 7.2 7.2" aria-hidden="true"><circle class="pl-markbg" r="3.1"/><path d="' + glyph[k] + '"/></svg>' : '';
  const legend = list => '<ul class="pl-legend" aria-hidden="true">' + list.map(x => '<li>' + (glyph[x[0]] && x[0] !== 'tub' ? legendMark(x[0]) : '<i class="is-' + x[0] + '"></i>') + esc(x[1]) + '</li>').join('') + '</ul>';

  /* ================================================================ the campus */

  // The best point inside a shape for its name (the audit: an L-shaped hall's centre falls outside it):
  // the inside point farthest from the walls, found on a grid and then refined.
  function inPoly(x, y, pts) {
    let c = false;
    for (let i = 0, j = pts.length - 1; i < pts.length; j = i++) { const a = pts[i], b = pts[j]; if ((a[1] > y) !== (b[1] > y) && x < (b[0] - a[0]) * (y - a[1]) / (b[1] - a[1]) + a[0]) c = !c; }
    return c;
  }
  function edgeDist(x, y, pts) {
    let m = Infinity;
    for (let i = 0, j = pts.length - 1; i < pts.length; j = i++) {
      const a = pts[j], b = pts[i], dx = b[0] - a[0], dy = b[1] - a[1], L = dx * dx + dy * dy, t = L ? Math.max(0, Math.min(1, ((x - a[0]) * dx + (y - a[1]) * dy) / L)) : 0;
      m = Math.min(m, Math.hypot(a[0] + t * dx - x, a[1] + t * dy - y));
    }
    return m;
  }
  function labelPoint(pts, cx, cy) {
    if (pts.length < 3) return [cx, cy];
    if (inPoly(cx, cy, pts) && edgeDist(cx, cy, pts) > 6) return [cx, cy];
    const xs = pts.map(p => p[0]), ys = pts.map(p => p[1]), x0 = Math.min.apply(null, xs), y0 = Math.min.apply(null, ys), w = Math.max.apply(null, xs) - x0, h = Math.max.apply(null, ys) - y0;
    let best = [cx, cy], bd = -1, step = Math.max(w, h) / 16;
    for (let i = 0; i <= 16; i++) for (let j = 0; j <= 16; j++) { const x = x0 + w * i / 16, y = y0 + h * j / 16; if (inPoly(x, y, pts)) { const d = edgeDist(x, y, pts); if (d > bd) { bd = d; best = [x, y]; } } }
    for (let k = 0; k < 3 && bd >= 0; k++) { step /= 3; const [bx, by] = best; for (let i = -2; i <= 2; i++) for (let j = -2; j <= 2; j++) { const x = bx + i * step, y = by + j * step; if (inPoly(x, y, pts)) { const d = edgeDist(x, y, pts); if (d > bd) { bd = d; best = [x, y]; } } } }
    return best;
  }

  const POINTS = { door: 1, spot: 1, closed: 1 };
  function campus(rows) {
    const items = (rows || []).filter(r => (r.name || /^(path|road|steps|highway)$/.test(r.kind || '')) && !/^#/.test(r.code || '') && r.points).map(r => {
      const pts = String(r.points).split(';').map(p => p.trim().split(/[\s,]+/).map(Number)).filter(p => p.length === 2 && !isNaN(p[0]) && !isNaN(p[1]));
      let a = 0, cx = 0, cy = 0;
      for (let i = 0; i < pts.length; i++) { const p = pts[i], q = pts[(i + 1) % pts.length], k = p[0] * q[1] - q[0] * p[1]; a += k; cx += (p[0] + q[0]) * k; cy += (p[1] + q[1]) * k; }
      const c = Math.abs(a) > 1 ? [cx / (3 * a), cy / (3 * a)] : [pts.reduce((k, p) => k + p[0], 0) / pts.length, pts.reduce((k, p) => k + p[1], 0) / pts.length];
      const kind = (r.kind || 'other').toLowerCase();
      const it = { code: r.code || '', name: r.name, kind, short: r.short || '', pts, cx: c[0], cy: c[1], area: Math.abs(a) / 2,
        aliases: String(r.aliases || '').split('|').map(s => s.trim()).filter(Boolean), address: r.address || '',
        // Its entrance for a phone's maps app (Oct 13: Directions opens Google Maps), when the campus says it.
        ll: r.lat !== '' && r.lat != null && r.lng !== '' && r.lng != null && isFinite(+r.lat) && isFinite(+r.lng) && Math.abs(+r.lat) <= 90 && Math.abs(+r.lng) <= 180 ? { lat: +r.lat, lng: +r.lng } : null,
        // A hall with the year's rooms in it (module-map.php: yes once Lodging has confirmed it with the
        // university; sample before that, members only). Which rooms, and whose, stay Lodging's.
        stay: r.stay === 'yes' || r.stay === 'sample', stayOk: r.stay === 'yes' };
      if (kind === 'door') Object.assign(it, { id: r.door || '', label: r.short || '', stepFree: r.step_free || '', open: r.open || '', keyOnly: r.key_only === 'yes', checked: r.checked || '' });
      if (kind === 'spot') Object.assign(it, { id: r.door || '', spot: r.spot || 'other', note: r.note || '' });
      if (kind === 'closed') Object.assign(it, { id: r.door || '', from: r.from || '', to: r.to || '', note: r.name || '' });
      return it;
    }).filter(i => i.pts.length > 1 || (POINTS[i.kind] && i.pts.length === 1));
    // A building drawn in several parts is named once, on its largest part, at its best inside point.
    const biggest = {};
    items.forEach(i => { if (i.name && !POINTS[i.kind] && (!biggest[i.name] || i.area > biggest[i.name].area)) biggest[i.name] = i; });
    items.forEach(i => { i.lab = biggest[i.name] === i; if (i.lab && i.pts.length > 2) { const p = labelPoint(i.pts, i.cx, i.cy); i.lx = p[0]; i.ly = p[1]; } else { i.lx = i.cx; i.ly = i.cy; } });
    // A building's other good spots for its name (the other arm of an L), and its outline's box.
    items.forEach(i => {
      if (!i.lab || i.pts.length < 3 || !BUILT[i.kind]) return;
      const xs = i.pts.map(p => p[0]), ys = i.pts.map(p => p[1]);
      i.bb = [Math.min.apply(null, xs), Math.min.apply(null, ys), Math.max.apply(null, xs), Math.max.apply(null, ys)];
      const w = i.bb[2] - i.bb[0], h = i.bb[3] - i.bb[1], best = edgeDist(i.lx, i.ly, i.pts), cand = [];
      for (let a = 0; a <= 12; a++) for (let b = 0; b <= 12; b++) { const x = i.bb[0] + w * a / 12, y = i.bb[1] + h * b / 12; if (inPoly(x, y, i.pts)) { const d = edgeDist(x, y, i.pts); if (d >= best * .55 && d > 3) cand.push([x, y, d]); } }
      cand.sort((p, q) => q[2] - p[2]);
      i.alts = [];
      cand.forEach(p => { if (i.alts.length < 2 && Math.hypot(p[0] - i.lx, p[1] - i.ly) > 18 && i.alts.every(q => Math.hypot(q[0] - p[0], q[1] - p[1]) > 18)) i.alts.push([p[0], p[1]]); });
    });
    const g = items.find(i => i.kind === 'geo');
    const drawn = items.filter(i => i.kind !== 'geo');
    const shapes = drawn.filter(i => !POINTS[i.kind]);
    const xs = [].concat.apply([], shapes.map(i => i.pts.map(p => p[0]))), ys = [].concat.apply([], shapes.map(i => i.pts.map(p => p[1])));
    return { items: drawn, doors: drawn.filter(i => i.kind === 'door'), spots: drawn.filter(i => i.kind === 'spot'), closed: drawn.filter(i => i.kind === 'closed'),
      geo: g ? { lat: g.pts[0][0], lon: g.pts[0][1], x: g.pts[1][0], y: g.pts[1][1] } : null,
      bounds: xs.length ? { x: Math.min.apply(null, xs), y: Math.min.apply(null, ys), w: Math.max.apply(null, xs) - Math.min.apply(null, xs), h: Math.max.apply(null, ys) - Math.min.apply(null, ys) } : { x: 0, y: 0, w: 100, h: 100 } };
  }
  function toMap(c, lat, lon) {
    const g = c.geo;
    if (!g) return null;
    return { x: (lon - g.lon) * Math.cos(g.lat * Math.PI / 180) * 111320 + g.x, y: (g.lat - lat) * 110574 + g.y };
  }
  // The other way: a point on the map (metres) as latitude and longitude. (Checked Oct 13 against
  // OpenStreetMap's own outlines and entrances for IWU: within 0.1 m.)
  function toLatLng(c, x, y) {
    const g = c && c.geo;
    if (!g || !isFinite(x) || !isFinite(y)) return null;
    return { lat: g.lat - (y - g.y) / 110574, lng: g.lon + (x - g.x) / (Math.cos(g.lat * Math.PI / 180) * 111320) };
  }

  /* ================================================================ directions: the phone's maps app */

  // Michael, Oct 13: "keep the Google Maps stuff and not try to do our own maps… for actual directions,
  // let's rely on GPS and everything from Google Maps." The campus map shows where things are; every
  // Directions opens Google Maps walking directions to the building's entrance (on a phone, the Maps
  // app), with no key and no paid service.
  // A building's entrance: what campus.csv says (lat, lng; a webmaster or the COA can correct it), else
  // its first door that isn't key only, else its middle (its name's spot), from the map's projection.
  function entrance(c, name) {
    const b = find(c, name);
    if (!b) return null;
    if (b.ll) return b.ll;
    const ds = c.doors.filter(d => norm(d.name) === norm(b.name)), d = ds.find(x => !x.keyOnly) || ds[0];
    return d ? toLatLng(c, d.cx, d.cy) : toLatLng(c, b.lx, b.ly);
  }
  // Where Directions goes for a place: a room (pinned or not) is its building's entrance; a field pinned
  // out of doors is its pin. A field not pinned yet, or a place not on the map, gets none (null).
  function placeLatLng(c, p, places) {
    const w = whereIs(c, p, places);
    if (w.kind === 'pin' && (w.outdoor || !w.b)) return toLatLng(c, w.x, w.y);
    // (A field named for the building beside it isn't at that building's door: none until it's pinned.)
    return (w.kind === 'pin' || w.kind === 'building') && w.b ? entrance(c, w.b.name) : null;
  }
  // Google Maps' own directions address: walking, to a point (no key; on a phone it opens the Maps app).
  const mapsUrl = ll => ll ? 'https://www.google.com/maps/dir/?api=1&destination=' + ll.lat.toFixed(6) + ',' + ll.lng.toFixed(6) + '&travelmode=walking' : '';
  // → the address for a place's Directions, or '' when the map can't say where it is. A maps link the
  // year pasted in places.csv's map column (docs/05; https only) wins: the place's own, else (for a room)
  // its building's ("B" for B/131).
  const pasted = q => q && /^https:\/\/\S+$/i.test(String(q.map || '').trim()) ? String(q.map).trim() : '';
  function directionsUrl(c, p, places) {
    if (!c || !p) return '';
    const main = places && places[String(p.code || '').split('/')[0].toUpperCase()];
    return pasted(p) || (main && main !== p && p.outdoor !== 'yes' ? pasted(main) : '') || mapsUrl(placeLatLng(c, p, places));
  }
  // Opened beside the page (a new tab; a phone hands it to the Maps app).
  const OUT = ' target="_blank" rel="noopener"';
  const onCampus = (c, p, margin) => !!p && p.x > c.bounds.x - (margin || 150) && p.x < c.bounds.x + c.bounds.w + (margin || 150) && p.y > c.bounds.y - (margin || 150) && p.y < c.bounds.y + c.bounds.h + (margin || 150);
  const BUILT = { hall: 1, dining: 1, worship: 1, venue: 1, other: 1 };
  // A building by its name, one of its aliases, or its code.
  const find = (c, name) => {
    if (!c || !name) return null;
    const n = norm(name);
    return c.items.find(i => !POINTS[i.kind] && i.lab && (norm(i.name) === n || i.aliases.some(a => norm(a) === n))) || c.items.find(i => i.code && i.code.toUpperCase() === String(name).toUpperCase() && !POINTS[i.kind]) || null;
  };
  // A place's building on the campus map: the building places.csv names for it (the year's own word,
  // matched loosely and by alias), else its main place's, else the code before the slash. (The audit: a
  // code could silently win over the year's own building; at Cedarville codes changed meaning.)
  function buildingFor(c, p, places) {
    if (!c || !p) return null;
    const code = String(p.code || '').split('/')[0].toUpperCase(), main = places && places[code];
    const by = n => n ? c.items.find(i => BUILT[i.kind] && i.lab && (norm(i.name) === norm(n) || i.aliases.some(a => norm(a) === norm(n)))) : null;
    return by(p.building) || (main && (by(main.building) || by(main.name))) || (code && c.items.find(i => BUILT[i.kind] && i.code && i.code.toUpperCase() === code && i.lab)) || by(p.name) || null;
  }
  // Where a place is: a pin (x, y; a field's pin is outdoors), its building, or nowhere yet.
  //   → { kind: 'pin' | 'building' | 'outdoor' (not pinned) | 'none', x, y, b, green }
  function whereIs(c, p, places) {
    if (!c || !p) return { kind: 'none' };
    const pinned = p.x !== '' && p.x != null && !isNaN(+p.x) && p.y !== '' && !isNaN(+p.y);
    const b = buildingFor(c, p, places), out = p.outdoor === 'yes';
    if (pinned) {
      const x = +p.x, y = +p.y, green = out ? c.items.find(i => (i.kind === 'green' || i.kind === 'parking') && i.pts.length > 2 && inPoly(x, y, i.pts)) : null;
      return { kind: 'pin', x, y, b: out ? null : b, green, outdoor: out };
    }
    if (out) return { kind: 'outdoor', b };
    return b ? { kind: 'building', b } : { kind: 'none' };
  }
  // The building a point is in, or nearest (within 40 m): "Near Hodson Hall · South door".
  function whereAmI(c, p) {
    if (!c || !p) return null;
    let best = null, bd = Infinity;
    c.items.forEach(i => {
      if (!BUILT[i.kind] || !i.lab || i.pts.length < 3 || !i.name || i.name === 'Building') return;
      const d = inPoly(p.x, p.y, i.pts) ? 0 : edgeDist(p.x, p.y, i.pts);
      if (d < bd) { bd = d; best = i; }
    });
    if (!best || bd > 40) return null;
    const door = c.doors.filter(d => norm(d.name) === norm(best.name) && d.label).sort((a, z) => Math.hypot(a.cx - p.x, a.cy - p.y) - Math.hypot(z.cx - p.x, z.cy - p.y))[0];
    return { b: best, inside: bd === 0, door: door && Math.hypot(door.cx - p.x, door.cy - p.y) < 30 ? door.label : '', address: best.address };
  }
  // Checks for the COA (gentle flags): halls and places the map can't find, a code meaning two buildings.
  function check(c, places, halls) {
    const out = [];
    if (!c) return out;
    (halls || []).forEach(h => { if (!find(c, h)) out.push({ kind: 'hall', name: h, text: 'Hall not on the map' }); });
    const codes = {};
    Object.values(places || {}).forEach(p => {
      const b = buildingFor(c, p, places);
      if (!b && p.outdoor !== 'yes') out.push({ kind: 'place', code: p.code, name: p.name, text: 'Not on the map' });
      const k = String(p.code || '').split('/')[0].toUpperCase();
      if (b && k) (codes[k] = codes[k] || new Set()).add(b.name);
    });
    Object.keys(codes).forEach(k => { if (codes[k].size > 1) out.push({ kind: 'code', code: k, text: 'Code ' + k + ' means ' + codes[k].size + ' buildings' }); });
    return out;
  }
  function boxOf(c, names, pad) {
    const its = c.items.filter(i => !POINTS[i.kind] && (names.indexOf(i.name) > -1 || (i.code && names.indexOf(i.code) > -1)));
    if (!its.length) return null;
    const xs = [].concat.apply([], its.map(i => i.pts.map(p => p[0]))), ys = [].concat.apply([], its.map(i => i.pts.map(p => p[1])));
    const x0 = Math.min.apply(null, xs), y0 = Math.min.apply(null, ys), x1 = Math.max.apply(null, xs), y1 = Math.max.apply(null, ys), q = pad == null ? 60 : pad;
    return { x: x0 - q, y: y0 - q, w: x1 - x0 + q * 2, h: y1 - y0 + q * 2 };
  }
  const ptBox = (x, y, r) => ({ x: x - r, y: y - r, w: r * 2, h: r * 2 });
  // The short name a building goes by on every map and list (campus.csv short; "-" means none).
  const shortOf = i => i && i.short && i.short !== '-' ? i.short : i ? i.name : '';
  // The name the schedule itself uses for a building, where it uses one (polish 1: the map said
  // "Phillippe" while every row said "PPAC Auditorium", "PPAC Lobby"): the capitals most of its rooms
  // start with. → { buildingName: 'PPAC' }
  function shortsFor(c, places) {
    const by = {}, out = {};
    Object.values(places || {}).forEach(p => { if (String(p.code).indexOf('/') < 0) return; const b = buildingFor(c, p, places); const m = /^([A-Z]{2,6})\b/.exec(String(p.name || '')); if (b) { const k = by[b.name] = by[b.name] || { n: 0, w: {} }; k.n++; if (m) k.w[m[1]] = (k.w[m[1]] || 0) + 1; } });
    Object.keys(by).forEach(n => { const k = by[n], top = Object.keys(k.w).sort((a, z) => k.w[z] - k.w[a])[0]; if (top && k.w[top] * 2 > k.n) out[n] = top; });
    return out;
  }
  // A parking lot's aisles drawn as roads make a lot look striped (the audit): a nameless road whose
  // middle is inside a lot isn't drawn (it's still walked).
  const aisle = (c, i) => i.kind === 'road' && (!i.name || /^(road|service)$/i.test(i.name)) && c.items.some(l => l.kind === 'parking' && l.pts.length > 2 && inPoly(i.pts[Math.floor(i.pts.length / 2)][0], i.pts[Math.floor(i.pts.length / 2)][1], l.pts));
  const SPOT = { camper: 'Camper lot', parking: 'Parking', carts: 'Golf carts', desk: 'Information', accessible: 'Accessible parking', other: '' };
  const SPOT_MARK = { camper: 'RV', parking: 'P', carts: 'C', desk: 'i', accessible: 'P', other: '•' };

  // The campus drawn whole (the packet, a shift's sheet, Your rooms, the room picker). Options:
  //   o.halls: { hallName: { line, mine } } (the halls with rooms this year, as buttons); o.sel: the hall chosen;
  //   o.mark: a building to point out; o.pin: { x, y, label } a spot to pin; o.named: buildings to name;
  //   o.codes: { buildingName: code } badges ("B · Barnes"); o.fit: names to fit around; o.aspect: the
  //   frame's width ÷ height; o.small: a mini map (no north arrow or scale); o.quiet: other buildings grey;
  //   o.far: names left off the fitted view get an arrow at the edge with how far ("Troyer · 0.5 mi").
  function campusSvg(c, o) {
    o = o || {};
    const fit = o.fit && boxOf(c, o.fit, o.pad == null ? 50 : o.pad), b = fit || (o.box ? o.box : c.bounds), pad = fit || o.box ? 0 : 18, vb = [b.x - pad, b.y - pad, b.w + pad * 2, b.h + pad * 2];
    if (o.aspect) { if (vb[2] / vb[3] < o.aspect) { const w = vb[3] * o.aspect; vb[0] -= (w - vb[2]) / 2; vb[2] = w; } else { const h = vb[2] / o.aspect; vb[1] -= (h - vb[3]) / 2; vb[3] = h; } }
    const LINE = { road: 1, path: 1, highway: 1, steps: 1 };
    const path = i => 'M' + i.pts.map(p => p[0].toFixed(1) + ' ' + p[1].toFixed(1)).join('L') + (LINE[i.kind] ? '' : 'Z');
    const out = ['<svg class="pl-campus pl-fit' + (o.small ? ' is-small' : '') + (o.quiet ? ' is-quiet' : '') + '" viewBox="' + vb.map(n => n.toFixed(1)).join(' ') + '" role="img" aria-label="' + esc(o.title || 'Campus map') + '">'];
    const order = ['green', 'water', 'parking', 'camper', 'highway', 'road', 'path', 'steps', 'other', 'venue', 'worship', 'dining', 'hall'];
    const marked = i => o.mark && (o.mark === i.code || o.mark === i.name);
    const used = new Set(Object.keys(o.codes || {}).concat(o.named || []));
    c.items.filter(i => order.indexOf(i.kind) > -1 && !aisle(c, i)).sort((p, q) => order.indexOf(p.kind) - order.indexOf(q.kind)).forEach(i => {
      const h = o.halls && o.halls[i.name];
      if (h) out.push('<g class="pl-bld is-hall is-pick' + (o.sel === i.name ? ' is-sel' : '') + (h.mine ? ' is-mine' : '') + '" data-hall="' + esc(i.name) + '" role="button" tabindex="0" aria-pressed="' + (o.sel === i.name) + '" aria-label="' + esc(i.name + (h.line ? ', ' + h.line : '')) + '"><path d="' + path(i) + '"/></g>');
      else out.push('<path class="pl-bld is-' + i.kind + (marked(i) ? ' is-mark' : '') + (used.has(i.name) ? ' is-used' : '') + '" d="' + path(i) + '"/>');
    });
    // A pinned spot (a room's door, a field's pin), and the lots, the camper lot and the like.
    c.spots.forEach(s => out.push('<g class="pl-spot is-' + esc(s.spot) + '" data-at="' + s.cx.toFixed(1) + ',' + s.cy.toFixed(1) + '" data-sz="1" transform="translate(' + s.cx.toFixed(1) + ' ' + s.cy.toFixed(1) + ')"><title>' + esc(s.name || SPOT[s.spot]) + '</title><circle r="7"/><text dominant-baseline="central">' + esc(SPOT_MARK[s.spot] || '•') + '</text></g>'));
    if (o.pin) out.push('<g class="pl-pin" data-at="' + o.pin.x.toFixed(1) + ',' + o.pin.y.toFixed(1) + '" data-sz="1" transform="translate(' + o.pin.x.toFixed(1) + ' ' + o.pin.y.toFixed(1) + ')"><path d="M0 0c-4-6-9-9.5-9-15a9 9 0 0 1 18 0c0 5.5-5 9-9 15Z"/><circle cy="-15" r="3.4"/></g>');
    // Names on top, most important first (hidden where they'd collide).
    const inView = i => i.lx >= vb[0] && i.lx <= vb[0] + vb[2] && i.ly >= vb[1] && i.ly <= vb[1] + vb[3];
    c.items.forEach(i => {
      if (!i.lab || !inView(i)) return;
      const h = o.halls && o.halls[i.name], go = ['dining', 'worship', 'venue', 'camper'].indexOf(i.kind) > -1 && i.short !== '-';
      const stayH = (o.stayHalls || []).indexOf(i.name) > -1, named = used.has(i.name) || marked(i) || stayH;
      // A small map names only what it's about (polish 1: a shift's map named a nearby dorm).
      if (o.small && !named && !h) return;
      if (!h && !named && i.kind !== 'hall' && !go) return;
      const code = o.codes && o.codes[i.name], nm = (o.shorts && o.shorts[i.name]) || shortOf(i);
      const rank = marked(i) || o.sel === i.name ? 0 : h ? 1 : named ? 2 : i.kind === 'hall' ? 3 : 4;
      const where = i.bb ? ' data-bb="' + i.bb.map(n => n.toFixed(1)).join(',') + '"' + (i.alts && i.alts.length ? ' data-in="' + i.alts.map(p => p[0].toFixed(1) + ',' + p[1].toFixed(1)).join(';') + '"' : '') : '';
      out.push('<text class="pl-lab' + (h || i.kind === 'hall' ? ' is-hall' : '') + (named ? ' is-used' : '') + (stayH ? ' is-stay' : '') + (marked(i) ? ' is-mark' : '') + '" x="' + i.lx.toFixed(1) + '" y="' + i.ly.toFixed(1) + '" dominant-baseline="middle" data-rank="' + rank + '"' + where + ' data-px="' + (rank < 3 ? 13 : 12) + '" data-halo="3" font-size="9">' +
        (code ? '<tspan class="pl-code">' + esc(code) + '</tspan> · ' : '') + esc(nm) + (h && h.line ? '<tspan class="pl-lab__sub" x="' + i.lx.toFixed(1) + '" dy="1.25em">' + esc(h.line) + '</tspan>' : '') + '</text>');
    });
    c.spots.forEach(s => { if (s.name && !o.small && s.cx >= vb[0] && s.cx <= vb[0] + vb[2] && s.cy >= vb[1] && s.cy <= vb[1] + vb[3]) out.push('<text class="pl-lab is-spot" x="' + s.cx.toFixed(1) + '" y="' + (s.cy + 11).toFixed(1) + '" dominant-baseline="hanging" data-rank="3" data-px="11.5" data-halo="3" font-size="8">' + esc(s.name) + '</text>'); });
    if (o.pin && o.pin.label) out.push('<text class="pl-lab is-pinlab" x="' + o.pin.x.toFixed(1) + '" y="' + (o.pin.y + 4).toFixed(1) + '" dominant-baseline="hanging" data-rank="0" data-px="12.5" data-halo="3" font-size="9">' + esc(o.pin.label) + '</text>');
    // Buildings left off a fitted map: a long, narrow arrow at the edge (it can't be read as pointing
    // back), with the name and the walk from the middle of the Conference ("Troyer · 10 min walk").
    // The arrow and its name show or hide together.
    (o.far || []).forEach((n, fi) => {
      const i = find(c, n); if (!i || inView(i)) return;
      const cx = vb[0] + vb[2] / 2, cy = vb[1] + vb[3] / 2, dx = i.lx - cx, dy = i.ly - cy, t = Math.min((vb[2] / 2 - 14) / Math.abs(dx || 1e-6), (vb[3] / 2 - 14) / Math.abs(dy || 1e-6));
      const ex = cx + dx * t, ey = cy + dy * t, ang = Math.atan2(dy, dx) * 180 / Math.PI, r = ang * Math.PI / 180;
      const mins = o.from ? walkMin(c, o.from, i.name) : null;
      const say = shortOf(i) + ' · ' + (mins ? mins + ' min walk' : feet(Math.hypot(i.lx - ex, i.ly - ey)));
      // The name beside the arrow, inward from the edge, in the same group (so they show together and
      // keep their size on screen: the group is scaled to screen pixels).
      const steep = Math.abs(Math.sin(r)) > .7, tx = steep ? 0 : -Math.cos(r) * 16, ty = steep ? (dy > 0 ? -16 : 18) : 0, anchor = steep ? 'middle' : dx > 0 ? 'end' : 'start';
      out.push('<g class="pl-far" data-far="' + fi + '" data-at="' + ex.toFixed(1) + ',' + ey.toFixed(1) + '" data-sz="1" transform="translate(' + ex.toFixed(1) + ' ' + ey.toFixed(1) + ')"><title>' + esc(i.name) + '</title><path transform="rotate(' + ang.toFixed(1) + ') scale(1.4)" d="M9 0L-6 -5.5L-2.5 0L-6 5.5Z"/>' +
        '<text class="pl-lab is-far" x="' + tx.toFixed(1) + '" y="' + ty.toFixed(1) + '" dominant-baseline="middle" style="text-anchor:' + anchor + ';font-size:12.5px;stroke-width:3px">' + esc(say) + '</text></g>');
    });
    if (!o.small) {
      const k = vb[2] / 700, nx = vb[0] + vb[2] - 22 * k, ny = vb[1] + 22 * k;
      out.push('<g class="pl-north" aria-hidden="true" data-at="' + nx.toFixed(1) + ',' + ny.toFixed(1) + '" data-sz="1" transform="translate(' + nx.toFixed(1) + ' ' + ny.toFixed(1) + ')"><path d="M0 -10l6 15 -6 -4 -6 4z"/><text y="16" dominant-baseline="hanging">N</text></g>');
      // A scale bar of 100 m (328 ft), drawn in the map's own metres.
      const sx = vb[0] + 14 * k, sy = vb[1] + vb[3] - 26 * k;
      out.push('<g class="pl-scale" aria-hidden="true"><path d="M' + sx.toFixed(1) + ' ' + (sy - 4 * k).toFixed(1) + 'v' + (4 * k).toFixed(1) + 'h91.4v' + (-4 * k).toFixed(1) + '"/><text x="' + (sx + 45.7).toFixed(1) + '" y="' + (sy - 7 * k).toFixed(1) + '" data-px="11" font-size="8">300 ft</text></g>');
    }
    // The licence's credit, in a corner of every map, on screen and on paper.
    out.push('<text class="pl-credit" x="' + (vb[0] + vb[2] - 3 * vb[2] / 700).toFixed(1) + '" y="' + (vb[1] + vb[3] - 3 * vb[2] / 700).toFixed(1) + '" style="text-anchor:end" data-px="' + (o.small ? 9.5 : 10.5) + '" data-halo="3" font-size="6"><title>Map data: OpenStreetMap, ODbL</title>' + CREDIT + '</text>');
    out.push('</svg>');
    return out.join('');
  }

  // A small map for a sheet (an event, a shift, a place before the week): the place's building in tan
  // among grey ones, a pin where the room or field is, and its line under it ("Barnes · North doors",
  // "Ground floor · Across from the cafeteria"). With o.href the whole map is a link (the guide's map).
  // Polish 1: the target is named, with the one or two nearest Conference buildings to find it by (not a
  // dorm next door); a room with no pin says so; and the sheet's one Directions button is here, filled
  // (o.dirs: { href }, Google Maps' walking directions, opened beside the page; o.dirsAttrs). The map
  // itself is the link to the place on the guide's map (o.href); no separate "Map" or "Building" link.
  function mini(c, p, places, o) {
    o = o || {};
    if (!c || !p) return '';
    const w = whereIs(c, p, places);
    if (w.kind === 'none') return '';
    const b = w.b, door = b && w.kind === 'pin' ? nearestDoor(c, b.name, w) : null;
    let box = w.kind === 'pin' ? (b ? grow(boxOf(c, [b.name], 40), w.x, w.y, 40) : ptBox(w.x, w.y, 90)) : b ? boxOf(c, [b.name], 70) : null;
    if (!box) return '';
    // The nearest Conference buildings (the year's main places), within a short walk, brought into view.
    const at = b ? { x: b.lx, y: b.ly } : { x: w.x, y: w.y }, conf = [];
    Object.values(places || {}).forEach(q => { if (String(q.code).indexOf('/') > -1) return; const x = buildingFor(c, q, places); if (x && (!b || x.name !== b.name) && conf.indexOf(x) < 0) conf.push(x); });
    const near2 = conf.map(x => ({ x, d: Math.hypot(x.lx - at.x, x.ly - at.y) })).filter(z => z.d < 170).sort((a, z) => a.d - z.d).slice(0, 2).map(z => z.x);
    // Each named neighbour's name point well inside the frame (polish 2: "Chapel" half off the bottom).
    near2.forEach(x => { box = grow(box, x.lx, x.ly, 34); });
    const map = campusSvg(c, { box, aspect: o.aspect || 340 / 180, small: true, quiet: true, mark: b ? b.name : '', named: (b ? [b.name] : []).concat(near2.map(x => x.name)), shorts: shortsFor(c, places), pin: w.kind === 'pin' ? { x: w.x, y: w.y } : null, title: (p.name || '') + ' on the campus map' });
    const room = String(p.code || '').indexOf('/') > -1 && w.kind === 'building';
    // What the map is missing is told to members only (o.member); the public gets what's useful or nothing.
    const line = placeLine(c, p, places, door), note = !o.member ? '' : room ? 'Room not on the map yet' : w.kind === 'outdoor' ? 'Not on the map yet' : '';
    const mapEl = o.href ? '<a class="pl-mini__map" href="' + esc(o.href) + '" title="' + esc(o.hrefTitle || 'Open the map') + '"' + (o.attrs || '') + '>' + map + '</a>' : '<span class="pl-mini__map">' + map + '</span>';
    const d = o.dirs;
    const go = d && d.href ? '<p class="pl-mini__go"><a class="wk-btn" href="' + esc(d.href) + '"' + (/^https?:/.test(d.href) ? OUT : '') + (o.dirsAttrs || '') + '>' + DIRS + 'Directions</a></p>' : '';
    return '<div class="pl-mini">' + mapEl + (line || note ? '<span class="pl-mini__line">' + esc(line) + (note ? '<small>' + esc(note) + '</small>' : '') + '</span>' : '') + go + '</div>';
  }
  const DIRS = '<svg class="wk-i" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3.5 20.5 12 12 20.5 3.5 12ZM9.5 13.5v-2.5h4.5M12.5 9l2 2-2 2" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  // A hall on a small map, its outline only (never its plan), for Your rooms: o.href, o.dirs as mini's.
  function hallMini(c, hall, places, o) {
    const b = find(c, hall);
    if (!b) return '';
    return mini(c, { code: '', name: b.name, building: b.name }, places, o);
  }
  function grow(box, x, y, q) {
    if (!box) return ptBox(x, y, q);
    const x0 = Math.min(box.x, x - q), y0 = Math.min(box.y, y - q), x1 = Math.max(box.x + box.w, x + q), y1 = Math.max(box.y + box.h, y + q);
    return { x: x0, y: y0, w: x1 - x0, h: y1 - y0 };
  }
  // How to find a room once you're through the door: "Ground floor · Across from the cafeteria"; for a
  // building or a field with no note, which door ("Barnes · West doors").
  function placeLine(c, p, places, door) {
    const bits = [];
    if (p.floor) bits.push(/^\d/.test(p.floor) ? floorName(parseInt(p.floor, 10)) : p.floor === 'Ground' ? 'Ground floor' : p.floor === 'Lower' ? 'Lower level' : p.floor);
    if (p.inside) bits.push(p.inside);
    if (!bits.length && door && door.label) { const b = buildingFor(c, p, places); bits.push((b ? shortOf(b) + ' · ' : '') + door.label); }
    return bits.join(' · ');
  }
  function nearestDoor(c, name, pt) {
    const ds = c.doors.filter(d => norm(d.name) === norm(name));
    return ds.sort((a, z) => Math.hypot(a.cx - pt.x, a.cy - pt.y) - Math.hypot(z.cx - pt.x, z.cy - pt.y))[0] || null;
  }

  // The packet's campus map: every building the year uses with its code, the halls tinted and named,
  // lots and the camper lot, a key, and the credit; buildings off the fitted view get an edge arrow.
  function packetMap(c, o) {
    o = o || {};
    const codes = {};
    Object.values(o.places || {}).forEach(p => { if (String(p.code).indexOf('/') < 0) { const b = buildingFor(c, p, o.places); if (b && !codes[b.name]) codes[b.name] = String(p.code).toUpperCase(); } });
    // The halls with rooms this year are always in the frame with the Conference buildings, and named
    // once Lodging has confirmed them (polish 2: Reed and Evans were cut off at the edges while the packet
    // sends families to the map for their hall). Only a far building gets an edge arrow (Troyer).
    const halls = Array.from(new Set(c.items.filter(i => i.stay && i.lab).map(i => i.name).concat((o.halls || []).map(n => (find(c, n) || {}).name).filter(Boolean))));
    const sure = c.items.filter(i => i.stayOk && i.lab).map(i => i.name);
    const named = Array.from(new Set((o.named || []).concat(Object.keys(codes), sure)));
    if (o.fit) o.fit = Array.from(new Set(o.fit.concat(halls)));
    const far = named.filter(n => o.fit && o.fit.indexOf(n) < 0);
    // Walks to a far building are said from the dining hall (else the first building fitted).
    const core = (o.fit || []).map(n => find(c, n)).filter(Boolean), from = (core.find(i => i.kind === 'dining') || core[0] || {}).name;
    const svg = campusSvg(c, { named, codes, fit: o.fit, far, from, stayHalls: sure, shorts: shortsFor(c, o.places), title: 'Campus map' });
    const key = [['used', 'Conference buildings'], ['hall', 'Halls']].concat(c.spots.length ? Array.from(new Set(c.spots.map(s => s.spot))).map(k => ['spot-' + k, SPOT[k] || 'Other']) : []).concat(c.items.some(i => i.kind === 'parking') ? [['parking', 'Parking']] : []);
    return '<div class="pl-packet">' + svg + '<ul class="pl-key">' + key.map(k => '<li><i class="is-' + esc(k[0]) + '"></i>' + esc(k[1]) + '</li>').join('') + '</ul></div>';
  }
  // "Buildings and their codes" as a table: code, then name, the rooms under it.
  function codesTable(places, c) {
    const groups = {}, order = [];
    Object.values(places || {}).forEach(p => { const k = String(p.code).split('/')[0].toUpperCase(); if (!groups[k]) { groups[k] = { main: null, rooms: [] }; order.push(k); } if (String(p.code).toUpperCase() === k) groups[k].main = p; else groups[k].rooms.push(p); });
    return '<table class="pl-codes"><tbody>' + order.map(k => {
      const g = groups[k], main = g.main || g.rooms[0];
      return '<tr class="pl-codes__b"><th scope="row"><code>' + esc(k) + '</code></th><td>' + esc(main ? main.name : k) + '</td></tr>' +
        g.rooms.filter(r => r !== main).map(r => '<tr class="pl-codes__r"><th scope="row"><code>' + esc(r.code) + '</code></th><td>' + esc(r.name) + (r.floor || r.inside ? '<small>' + esc(placeLine(c, r, places)) + '</small>' : '') + '</td></tr>').join('');
    }).join('') + '</tbody></table>';
  }

  /* ================================================================ walking times */

  // How far apart two buildings are on foot, door to door along the campus's footpaths and drives (kinds
  // path, road, steps) as a graph: Lodging's "3 min to Barnes", the packet's "Troyer · 20 min walk", and
  // the pins tool's doors. (Oct 13: the guide no longer draws routes or gives steps; Directions opens the
  // phone's maps app instead, above.)
  function router(c) {
    const nodes = new Map(), segs = [];
    const node = (x, y) => { const k = x.toFixed(1) + ',' + y.toFixed(1); let n = nodes.get(k); if (!n) nodes.set(k, n = { x, y, e: [], c: 0 }); return n; };
    c.items.forEach(i => {
      if (i.kind !== 'path' && i.kind !== 'road' && i.kind !== 'steps') return;
      for (let j = 0; j + 1 < i.pts.length; j++) {
        const a = node(i.pts[j][0], i.pts[j][1]), b = node(i.pts[j + 1][0], i.pts[j + 1][1]), d = Math.hypot(a.x - b.x, a.y - b.y);
        if (d < .05) continue;
        const sg = { a, b, d, w: d * (i.kind === 'road' ? 1.15 : 1), steps: i.kind === 'steps', name: i.kind === 'road' && !/^(road|service)$/i.test(i.name || '') ? i.name : '' };
        a.e.push({ n: b, s: sg }); b.e.push({ n: a, s: sg }); segs.push(sg);
      }
    });
    let comp = 0; const sizes = [0];
    nodes.forEach(n => { if (n.c) return; comp++; let k = 0; const st = [n]; n.c = comp; while (st.length) { const x = st.pop(); k++; x.e.forEach(e => { if (!e.n.c) { e.n.c = comp; st.push(e.n); } }); } sizes[comp] = k; });
    const main = sizes.indexOf(Math.max.apply(null, sizes));
    const live = segs.filter(sg => sg.a.c === main);
    const hasSteps = live.some(s => s.steps) || c.doors.some(d => d.stepFree);
    // Closed for a day (the COA's closures): a stretch of path within 6 m of one isn't walked.
    const closedOn = date => c.closed.filter(k => (!k.from || !date || k.from <= date) && (!k.to || !date || k.to >= date));
    const near = (sg, k) => { const dx = sg.b.x - sg.a.x, dy = sg.b.y - sg.a.y, L = dx * dx + dy * dy, t = L ? Math.max(0, Math.min(1, ((k.cx - sg.a.x) * dx + (k.cy - sg.a.y) * dy) / L)) : 0; return Math.hypot(sg.a.x + t * dx - k.cx, sg.a.y + t * dy - k.cy) < 6; };
    function snap(x, y, o) {
      o = o || {};
      let best = null;
      const shut = o.date ? closedOn(o.date) : [];
      live.forEach(sg => {
        if (o.stepFree && sg.steps) return;
        if (shut.length && shut.some(k => near(sg, k))) return;
        const dx = sg.b.x - sg.a.x, dy = sg.b.y - sg.a.y, L = dx * dx + dy * dy, t = L ? Math.max(0, Math.min(1, ((x - sg.a.x) * dx + (y - sg.a.y) * dy) / L)) : 0;
        const px = sg.a.x + t * dx, py = sg.a.y + t * dy, d = Math.hypot(px - x, py - y);
        if (!best || d < best.d) best = { sg, t, x: px, y: py, d };
      });
      return best;
    }
    // Where a building is walked to: its doors, the open ones (not closed that day, not key only unless
    // allowed, step-free when asked, if any are); with no doors drawn, the two outline points nearest the
    // paths, on different sides, marked guessed (drawn hollow and never named).
    function doors(name, o) {
      o = o || {};
      const shut = o.date ? closedOn(o.date) : [];
      let ds = c.doors.filter(d => norm(d.name) === norm(name)).filter(d => !shut.some(k => Math.hypot(k.cx - d.cx, k.cy - d.cy) < 3));
      if (!o.keys) { const open = ds.filter(d => !d.keyOnly); if (open.length) ds = open; }
      if (o.stepFree) { const sf = ds.filter(d => d.stepFree === 'yes'); if (sf.length) ds = sf; }
      if (ds.length) return ds.map(d => ({ x: d.cx, y: d.cy, door: d }));
      const b = find(c, name);
      if (!b) return [];
      if (b.pts.length < 3) return [{ x: b.cx, y: b.cy, guessed: true }];
      const cand = [];
      for (let k = 0; k < b.pts.length; k++) { const p = b.pts[k], q = b.pts[(k + 1) % b.pts.length]; [p, [(p[0] + q[0]) / 2, (p[1] + q[1]) / 2]].forEach(pt => { const sn = snap(pt[0], pt[1]); if (sn) cand.push({ x: pt[0], y: pt[1], d: sn.d }); }); }
      cand.sort((a, z) => a.d - z.d);
      const out = [];
      cand.forEach(p => { if (out.length < 2 && out.every(q => Math.hypot(q.x - p.x, q.y - p.y) > 20)) out.push({ x: p.x, y: p.y, guessed: true }); });
      return out;
    }
    // from, to: lists of points ({ x, y, door? }). → { pts, d, end (the door reached) } or null.
    function route(from, to, o) {
      o = o || {};
      const temp = [];
      const link = (u, v, d, w, base) => { const sg = { a: u, b: v, d, w: w == null ? d : w, steps: base ? base.steps : false, name: base ? base.name : '' }; u.e.push({ n: v, s: sg }); v.e.push({ n: u, s: sg }); temp.push(u, v); };
      const attach = (pts, tag) => pts.map(p => {
        const sn = snap(p.x, p.y, o);
        if (!sn) return null;
        const t = { x: sn.x, y: sn.y, e: [], tmp: true, sg: sn.sg, t: sn.t }, end = { x: p.x, y: p.y, e: [], tmp: true, tag, door: p.door || null, guessed: !!p.guessed };
        const sg = sn.sg, r = sg.w / sg.d;
        link(t, sg.a, sg.d * sn.t, sg.d * sn.t * r, sg); link(t, sg.b, sg.d * (1 - sn.t), sg.d * (1 - sn.t) * r, sg); link(end, t, sn.d, sn.d * 1.3);
        return { end, t };
      }).filter(Boolean);
      const A = attach(from, 'from'), Z = attach(to, 'to');
      A.forEach(a => Z.forEach(b => { if (a.t.sg === b.t.sg) { const d = Math.abs(a.t.t - b.t.t) * a.t.sg.d; link(a.t, b.t, d, d * a.t.sg.w / a.t.sg.d, a.t.sg); } }));
      const shut = o.date ? closedOn(o.date) : [];
      const dist = new Map(), prev = new Map(), heap = [];
      const push = (n, d) => { heap.push([d, n]); let i = heap.length - 1; while (i > 0) { const p = (i - 1) >> 1; if (heap[p][0] <= heap[i][0]) break; [heap[p], heap[i]] = [heap[i], heap[p]]; i = p; } };
      const pop = () => { const top = heap[0], last = heap.pop(); if (heap.length) { heap[0] = last; let i = 0; for (;;) { const l = i * 2 + 1, r = l + 1; let m = i; if (l < heap.length && heap[l][0] < heap[m][0]) m = l; if (r < heap.length && heap[r][0] < heap[m][0]) m = r; if (m === i) break; [heap[m], heap[i]] = [heap[i], heap[m]]; i = m; } } return top; };
      A.forEach(a => { dist.set(a.end, 0); push(a.end, 0); });
      let goal = null;
      while (heap.length) {
        const [d, n] = pop();
        if (d > (dist.get(n) == null ? Infinity : dist.get(n))) continue;
        if (n.tag === 'to') { goal = n; break; }
        n.e.forEach(e => {
          if (o.stepFree && e.s.steps) return;
          if (shut.length && !e.n.tmp && !n.tmp && shut.some(k => near(e.s, k))) return;
          const nd = d + e.s.w;
          if (nd < (dist.get(e.n) == null ? Infinity : dist.get(e.n))) { dist.set(e.n, nd); prev.set(e.n, { n, s: e.s }); push(e.n, nd); }
        });
      }
      temp.forEach(u => { if (!u.tmp) u.e = u.e.filter(e => !e.n.tmp); });
      if (!goal) return null;
      const pts = [], used = [];
      let first = goal;
      for (let n = goal; n; n = prev.get(n) && prev.get(n).n) { first = n; pts.unshift({ x: n.x, y: n.y }); if (prev.get(n)) used.unshift(prev.get(n).s); }
      const d = used.reduce((k, sg) => k + sg.d, 0);
      return { pts, d, end: goal.door, start: first.door || null, guessedEnd: goal.guessed };
    }
    return { route, doors, snap, hasSteps };
  }
  // Walking, at a gentle 60 m a minute (older folks; the audit: 75 was brisk), slower step-free.
  // One way to say a distance everywhere (the packet's edge arrows, the pins tool): feet under 1,000
  // (to the nearest 50; 10 under 100), then tenths of a mile (polish 1: "0.1 mi" for 530 ft).
  const PACE = 60, PACE_SLOW = 50;
  const minutes = (m, slow) => Math.max(1, Math.round(m / (slow ? PACE_SLOW : PACE)));
  const feet = m => { const f = m * 3.28084; return f < 975 ? (f < 100 ? Math.max(10, Math.round(f / 10) * 10) : Math.round(f / 50) * 50) + ' ft' : (f / 5280).toFixed(1) + ' mi'; };
  // Minutes walked from one building to another, door to door along the paths: the one way every page
  // says it (the audit: register and Lodging used a straight line).
  const routers = new WeakMap();
  function routerOf(c) { let r = routers.get(c); if (!r) routers.set(c, r = router(c)); return r; }
  function walkMin(c, a, b, o) {
    if (!c || !a || !b) return null;
    const x = find(c, a), y = find(c, b);
    if (!x || !y) return null;
    const R = routerOf(c), r = R.route(R.doors(x.name, o), R.doors(y.name, o), o);
    return r ? minutes(r.d, o && o.stepFree) : Math.max(1, Math.round(Math.hypot(x.cx - y.cx, x.cy - y.cy) * 1.35 / PACE));
  }

  /* ================================================================ the map to move around */

  // The campus as a map to move around. Gestures, as a maps app has them:
  //   drag (with momentum) · pinch, which also pans · double-tap to zoom in · two-finger tap to zoom out ·
  //   the + and − buttons · arrow keys and + / − once the map has focus.
  // o.cooperative (a map inside a scrolling page): one finger scrolls the page and two move the map
  // ("Use two fingers"), and a mouse wheel zooms only with ⌘ or Ctrl ("⌘ + scroll to zoom"); an Expand
  // button opens it full screen, where one finger moves it. Without it (a full-screen map), one finger.
  // o.start: names to frame first; o.focus: a box to frame instead (a place asked for).
  // o.onTap(pt, buildingName) · o.onPick(name) · o.onLocate() · o.onMove() (the person moved the map).
  function viewer(el, c, o) {
    o = o || {};
    const NS = 'http://www.w3.org/2000/svg';
    const LINE = { road: 1, path: 1, highway: 1, steps: 1 };
    const d = i => 'M' + i.pts.map(p => p[0].toFixed(1) + ' ' + p[1].toFixed(1)).join('L') + (LINE[i.kind] ? '' : 'Z');
    const used = new Set(o.used || []);
    const order = ['green', 'water', 'parking', 'highway', 'road', 'path', 'steps', 'other', 'venue', 'worship', 'dining', 'hall'];
    const codes = o.codes || {};
    const B = c.bounds;
    // The drawn parts.
    const parts = q => ({
      bg: '<rect class="pv-bg" x="' + (q.bounds.x - 2000) + '" y="' + (q.bounds.y - 2000) + '" width="' + (q.bounds.w + 4000) + '" height="' + (q.bounds.h + 4000) + '"/>',
      shapes: q.items.filter(i => order.indexOf(i.kind) > -1 && !aisle(q, i)).sort((p, r) => order.indexOf(p.kind) - order.indexOf(r.kind)).map(i =>
        '<path class="pv-' + i.kind + (used.has(i.name) ? ' is-used' : '') + '" d="' + d(i) + '"' + (BUILT[i.kind] ? ' data-b="' + esc(i.name) + '"' : '') + '/>').join(''),
      // A lot gets a small P badge of a set size on screen, shown once the lot is 30 px across (polish 1:
      // the P was sized in map units, so it was the biggest thing on the map when zoomed in).
      lots: q.items.filter(i => i.kind === 'parking' && i.pts.length > 2).map(i => { const xs = i.pts.map(p => p[0]), ys = i.pts.map(p => p[1]); const mk = q.spots.some(sp => /^(parking|accessible|camper)$/.test(sp.spot) && inPoly(sp.cx, sp.cy, i.pts)); return '<g class="pv-lot"' + (mk ? ' data-mark="1"' : '') + ' data-x="' + i.lx.toFixed(1) + '" data-y="' + i.ly.toFixed(1) + '" data-m="' + Math.min(Math.max.apply(null, xs) - Math.min.apply(null, xs), Math.max.apply(null, ys) - Math.min.apply(null, ys)).toFixed(1) + '"><rect x="-7" y="-7" width="14" height="14" rx="3"/><text>P</text></g>'; }).join(''),
      labels: q.items.filter(i => i.lab && BUILT[i.kind] && i.short !== '-' && i.name !== 'Building')
        .map(i => '<text class="pv-lab pv-lab--' + i.kind + (used.has(i.name) ? ' is-used' : '') + '" data-k="' + i.kind + '" data-a="' + Math.round(i.area || 0) + '" data-n="' + esc(i.name) + '" x="' + i.lx.toFixed(1) + '" y="' + i.ly.toFixed(1) + '">' +
          (codes[i.name] ? '<tspan class="pv-code">' + esc(codes[i.name]) + '</tspan> · ' : '') + esc((o.shorts && o.shorts[i.name]) || shortOf(i)) + '</text>').join(''),
      spots: q.spots.map(s => '<g class="pv-spot is-' + esc(s.spot) + '" data-spot="' + esc(s.id) + '" data-x="' + s.cx.toFixed(1) + '" data-y="' + s.cy.toFixed(1) + '"><circle data-r="11"/><text>' + esc(SPOT_MARK[s.spot] || '•') + '</text>' + (s.name ? '<text class="pv-spot__n">' + esc(s.name) + '</text>' : '') + '</g>').join('')
    });
    const P = parts(c);
    const touch = window.matchMedia && matchMedia('(pointer: coarse)').matches;
    const locate = o.locate && touch && 'geolocation' in navigator;
    // On a touch screen the fingers zoom (as in any maps app); + and − are for a mouse.
    const zoomBtns = touch ? '' : '<button type="button" data-z="in" aria-label="Zoom in" title="Zoom in">+</button><button type="button" data-z="out" aria-label="Zoom out" title="Zoom out">−</button>';
    // (Polish 3: a region, not an application, so a screen reader can still read around it; the keys in hidden help.)
    const hid = 'pv-k' + Math.random().toString(36).slice(2, 8);
    el.innerHTML = '<div class="pv' + (o.cooperative ? ' is-coop' : '') + '" tabindex="0" role="region" aria-roledescription="map" aria-label="' + esc(o.title || 'Campus map') + '" aria-describedby="' + hid + '"><span id="' + hid + '" class="ogc-sr">Arrow keys move the map; plus and minus zoom</span>' +
      '<svg class="pv-svg" xmlns="' + NS + '" preserveAspectRatio="xMidYMid meet" aria-hidden="true">' +
      '<g class="pv-world"><g class="pv-bgs">' + P.bg + '</g>' +
      '<g class="pv-shapes">' + P.shapes + '</g><g class="pv-sel"></g><g class="pv-lots">' + P.lots + '</g><g class="pv-labels">' + P.labels + '</g><g class="pv-spots">' + P.spots + '</g><g class="pv-doors"></g><g class="pv-pins"></g><g class="pv-me"></g></g></svg>' +
      '<div class="pv-ctl">' + (o.expand ? '<button type="button" data-z="full" aria-label="Full screen" title="Full screen"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4.5 9V4.5H9M15 4.5h4.5V9M19.5 15v4.5H15M9 19.5H4.5V15" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg></button>' : '') +
      zoomBtns +
      (locate ? '<button type="button" data-locate aria-label="My location" title="My location"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3v3M12 18v3M3 12h3M18 12h3M12 17a5 5 0 1 0 0-10 5 5 0 0 0 0 10Z" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg></button>' : '') + '</div>' +
      // The credit as plain words (a stray tap at the map's edge never leaves the guide).
      '<span class="pv-credit" title="Map data: OpenStreetMap, ODbL">' + CREDIT + '</span>' +
      '<p class="pv-hint" aria-hidden="true" hidden></p></div>';
    const root = el.querySelector('.pv'), svg = el.querySelector('svg'), G = k => svg.querySelector('.pv-' + k);
    const hint = root.querySelector('.pv-hint');
    const v = { x: B.x, y: B.y, w: B.w, h: B.h };
    let inset = { top: 0, bottom: 0, right: 0 };
    const size = () => { const r = svg.getBoundingClientRect(); return { W: r.width || 360, H: r.height || 260, r }; };
    // Map units per screen pixel (the viewBox fills the box: meet, with the box's own aspect).
    const px = () => { const s = size(); return Math.max(v.w / Math.max(1, s.W), v.h / Math.max(1, s.H)); };
    const RANK = { hall: 1, dining: 1, worship: 1, venue: 2, other: 3 };
    let picked = '';
    let labs = Array.from(svg.querySelectorAll('.pv-lab'));
    const ranked = () => labs.slice().sort((a, b) => (a.dataset.n === picked ? -1 : 0) - (b.dataset.n === picked ? -1 : 0) || (b.classList.contains('is-used') - a.classList.contains('is-used')) || (RANK[a.dataset.k] || 4) - (RANK[b.dataset.k] || 4) || b.dataset.a - a.dataset.a);
    let frame = 0, settle = 0;
    // Drawn once a frame; the names sorted out once the map stops moving.
    function draw() { if (!frame) frame = requestAnimationFrame(paint); }
    function paint() {
      frame = 0;
      const s = size();
      // The viewBox keeps the box's own aspect, so a map unit is the same across and down.
      const k = Math.max(v.w / s.W, v.h / s.H), cx = v.x + v.w / 2, cy = v.y + v.h / 2;
      v.w = s.W * k; v.h = s.H * k; v.x = cx - v.w / 2; v.y = cy - v.h / 2;
      svg.setAttribute('viewBox', [v.x, v.y, v.w, v.h].map(n => n.toFixed(2)).join(' '));
      const wide = v.w > 700;
      labs.forEach(t => {
        const kd = t.dataset.k, big = t.classList.contains('is-used') || t.dataset.n === picked;
        const show = big || kd !== 'other' || (!wide && v.w < 560);
        t.style.display = show ? '' : 'none';
        t.setAttribute('font-size', ((big ? 13.5 : kd === 'hall' ? 13 : 12) * k).toFixed(2));
        t.setAttribute('stroke-width', (3.2 * k).toFixed(2));
      });
      // (Polish 3: thirteen Ps crowded the first view. The lots Transportation marks show from 30 px across, the rest once zoomed in.)
      svg.querySelectorAll('.pv-lot').forEach(g => { const on = +g.dataset.m / k >= (g.dataset.mark ? 30 : 70); g.style.display = on ? '' : 'none'; if (on) g.setAttribute('transform', 'translate(' + g.dataset.x + ' ' + g.dataset.y + ') scale(' + k.toFixed(4) + ')'); });
      svg.querySelectorAll('[data-r]').forEach(n => n.setAttribute('r', (+n.dataset.r * k).toFixed(2)));
      svg.querySelectorAll('.pv-spot').forEach(g => {
        g.setAttribute('transform', 'translate(' + g.dataset.x + ' ' + g.dataset.y + ')');
        const ts = g.querySelectorAll('text'); ts[0].setAttribute('font-size', (10 * k).toFixed(2));
        if (ts[1]) { ts[1].setAttribute('font-size', (12 * k).toFixed(2)); ts[1].setAttribute('y', (20 * k).toFixed(2)); ts[1].setAttribute('stroke-width', (3 * k).toFixed(2)); }
      });
      svg.querySelectorAll('.pv-pin').forEach(g => g.setAttribute('transform', 'translate(' + g.dataset.x + ' ' + g.dataset.y + ') scale(' + k.toFixed(4) + ')'));
      svg.querySelectorAll('.pv-door').forEach(g => g.setAttribute('transform', 'translate(' + g.dataset.x + ' ' + g.dataset.y + ') scale(' + k.toFixed(4) + ')'));
      clearTimeout(settle);
      settle = setTimeout(declutter, moving ? 120 : 0);
    }
    // No name over another or over a pin, and none cut off at the edge (the audit: big
    // buildings running off the edge lost their names, so a name goes where the building is in view).
    function declutter() {
      const s = size();
      if (!s.r.width) return;
      const k = px(), m = 4 * k, cx = v.x + v.w / 2, cy = v.y + v.h / 2, hw = s.W * k / 2, hh = s.H * k / 2;
      const placed = [], wx = sx => cx - hw + (sx - s.r.left) * k, wy = sy => cy - hh + (sy - s.r.top) * k;
      root.querySelectorAll('.pv-ctl button, .pv-credit').forEach(b => { const r = b.getBoundingClientRect(); if (r.width) placed.push({ x0: wx(r.left), y0: wy(r.top), x1: wx(r.right), y1: wy(r.bottom), hard: true }); });
      const top = cy - hh + inset.top * k, bottom = cy + hh - inset.bottom * k;
      // Pins and doors (the pins tool's rings) are in the way too; a pin that names a building stands
      // for that building's own name (polish 1: "Evans" and "Evans Hall" both shown).
      const pinNamed = new Set();
      svg.querySelectorAll('.pv-pin, .pv-door').forEach(g => {
        if (g.dataset.of && g.querySelector('text')) pinNamed.add(g.dataset.of);
        // A pin's name kept inside the map's edges, slid along under its pin (polish 2: "Evans Hall" cut off).
        const tx = g.classList.contains('pv-pin') && g.querySelector('text');
        if (tx) { tx.removeAttribute('x'); let tb = null; try { tb = tx.getBBox(); } catch (e) { /* not drawn */ } if (tb && tb.width && +g.dataset.x > cx - hw && +g.dataset.x < cx + hw) { const X = +g.dataset.x, L = X + tb.x * k, R = X + (tb.x + tb.width) * k, lo = cx - hw + 8 * k, hi = cx + hw - 8 * k; if (L < lo) tx.setAttribute('x', ((lo - L) / k).toFixed(1)); else if (R > hi) tx.setAttribute('x', (-(R - hi) / k).toFixed(1)); } }
        let b; try { b = g.getBBox(); } catch (e) { return; } const x = +g.dataset.x, y = +g.dataset.y; placed.push({ x0: x + b.x * k, y0: y + b.y * k, x1: x + (b.x + b.width) * k, y1: y + (b.y + b.height) * k }); });
      const hits = bx => placed.reduce((n, p) => n + (bx.x0 < p.x1 && bx.x1 > p.x0 && bx.y0 < p.y1 && bx.y1 > p.y0 ? 1 : 0), 0);
      const outOf = b => b.x < cx - hw || b.x + b.width > cx + hw || b.y < top || b.y + b.height > bottom;
      const put = (t, x, y, a) => { t.setAttribute('x', x.toFixed(1)); t.setAttribute('y', y.toFixed(1)); t.style.textAnchor = a || ''; t.querySelectorAll('tspan').forEach(sp => sp.removeAttribute('x')); };
      const measure = t => { let b; try { b = t.getBBox(); } catch (e) { return null; } return { b, box: { x0: b.x - m, y0: b.y - m, x1: b.x + b.width + m, y1: b.y + b.height + m } }; };
      ranked().forEach(t => {
        if (t.style.display === 'none') return;
        t.style.visibility = '';
        const n = t.dataset.n, i = c.items.find(x => x.name === n && x.lab);
        if (pinNamed.has(n) && n !== picked) { t.style.visibility = 'hidden'; return; }
        if (!i) return;
        // A building partly in view: its name in the part that shows, at a point inside its outline.
        let lx = i.lx, ly = i.ly;
        const vis = clipBox(i, cx - hw, top, cx + hw, bottom);
        if (vis && (lx < vis.x0 || lx > vis.x1 || ly < vis.y0 || ly > vis.y1)) {
          const inside = (x, y) => inPoly(x, y, i.pts);
          let best = null;
          for (let a = 1; a < 6 && !best; a++) for (let b2 = 1; b2 < 6; b2++) { const x = vis.x0 + (vis.x1 - vis.x0) * a / 6, y = vis.y0 + (vis.y1 - vis.y0) * b2 / 6; if (inside(x, y) && (!best || edgeDist(x, y, i.pts) > best[2])) best = [x, y, edgeDist(x, y, i.pts)]; }
          if (!best) { t.style.visibility = 'hidden'; return; }
          lx = best[0]; ly = best[1];
        }
        put(t, lx, ly);
        let at = measure(t); if (!at) return;
        if (!outOf(at.b) && !hits(at.box)) { placed.push(at.box); return; }
        const big = t.classList.contains('is-used') || n === picked;
        if (!big) { t.style.visibility = 'hidden'; return; }
        // A Conference building (or the one picked): its name tries the building's other spots, then
        // just below, above and beside it, then a size smaller, rather than going (polish 1: Hodson).
        const fs = +t.getAttribute('font-size') || 12 * k, bb = i.bb || [lx, ly, lx, ly];
        const spots = [[lx, ly + at.b.height * 1.3, ''], [lx, ly - at.b.height * 1.3, '']].concat((i.alts || []).map(p => [p[0], p[1], '']))
          .concat([[(bb[0] + bb[2]) / 2, bb[3] + fs * .8, ''], [(bb[0] + bb[2]) / 2, bb[1] - fs * .8, ''], [bb[2] + fs * .4, ly, 'start'], [bb[0] - fs * .4, ly, 'end']]);
        const tryAll = () => { for (const s of spots) { put(t, s[0], s[1], s[2]); const q = measure(t); if (q && !outOf(q.b) && !hits(q.box)) return q; } return null; };
        let q = tryAll();
        if (!q) { t.setAttribute('font-size', (fs * 12 / 13.5).toFixed(2)); put(t, lx, ly); q = measure(t); if (!q || outOf(q.b) || hits(q.box)) q = tryAll(); }
        if (q) { placed.push(q.box); return; }
        put(t, lx, ly);
        if (n === picked) { const z = measure(t); if (z) placed.push(z.box); } else t.style.visibility = 'hidden';
      });
    }
    // The part of a building inside the view, as a box (for placing its name).
    function clipBox(i, x0, y0, x1, y1) {
      const xs = i.pts.map(p => p[0]), ys = i.pts.map(p => p[1]);
      const a = Math.max(x0, Math.min.apply(null, xs)), b = Math.min(x1, Math.max.apply(null, xs)), c0 = Math.max(y0, Math.min.apply(null, ys)), d0 = Math.min(y1, Math.max.apply(null, ys));
      return a < b && c0 < d0 ? { x0: a, x1: b, y0: c0, y1: d0 } : null;
    }
    // Zoomed out no further than about 1.5 × the Conference's own buildings and halls (o.extent), not the
    // OpenStreetMap extract with its far roads (polish 2: the campus shrank to a postage stamp).
    const EXT = o.extent && o.extent.length ? boxOf(c, o.extent, 40) : null;
    const clamp = () => {
      const maxW = EXT ? Math.max(EXT.w, EXT.h, 300) * 1.5 : Math.max(B.w, B.h) * 1.4, minW = 60;
      if (v.w > maxW) { const f = maxW / v.w; v.x += v.w * (1 - f) / 2; v.y += v.h * (1 - f) / 2; v.w *= f; v.h *= f; }
      if (v.w < minW) { const f = minW / v.w; v.x -= v.w * (f - 1) / 2; v.y -= v.h * (f - 1) / 2; v.w *= f; v.h *= f; }
      v.x = Math.min(Math.max(v.x, B.x - v.w * .6), B.x + B.w - v.w * .4); v.y = Math.min(Math.max(v.y, B.y - v.h * .6), B.y + B.h - v.h * .4);
    };
    // Moving the view: at once while a finger is on it; eased (about 220 ms) for a fit, a zoom button,
    // a double-tap, so the change is followed (off under reduced motion).
    let anim = 0;
    function goTo(t, ease) {
      cancelAnimationFrame(anim);
      if (!ease || reduced()) { Object.assign(v, t); clamp(); draw(); return; }
      const f0 = Object.assign({}, v), t0 = performance.now(), D = 220;
      const step = now => { const p = Math.min(1, (now - t0) / D), e = 1 - Math.pow(1 - p, 3); ['x', 'y', 'w', 'h'].forEach(k => { v[k] = f0[k] + (t[k] - f0[k]) * e; }); clamp(); draw(); if (p < 1) anim = requestAnimationFrame(step); };
      anim = requestAnimationFrame(step);
    }
    function zoom(f, cx, cy, ease) {
      if (cx == null) { cx = v.x + v.w / 2; cy = v.y + v.h / 2 + (inset.top - inset.bottom) * px() / 2; }
      goTo({ x: cx - (cx - v.x) * f, y: cy - (cy - v.y) * f, w: v.w * f, h: v.h * f }, ease);
    }
    // A box (in metres) fitted inside what shows of the map (less the sheet over it and the buttons).
    let lastFit = null, userMoved = false;
    function fit(box, pad, ease, at) {
      if (!box) return;
      lastFit = { box, pad, at }; userMoved = false;
      const s = size(), q = pad == null ? 28 : pad, ctl = 56;
      const aw = Math.max(40, s.W - q * 2 - ctl), ah = Math.max(40, s.H - q * 2 - inset.top - inset.bottom);
      const k = Math.max(box.w / aw, box.h / ah);
      const w = s.W * k, h = s.H * k;
      // Centred in the part that shows: left of the buttons, between the top and the sheet.
      // (at: where the box's middle sits, as a share of the height that shows.)
      const cxs = (s.W - ctl) / 2, cys = inset.top + (s.H - inset.top - inset.bottom) * (at || .5);
      goTo({ x: box.x + box.w / 2 - cxs * k, y: box.y + box.h / 2 - cys * k, w, h }, ease !== false && !!ease);
    }
    // A screen point in campus metres.
    const toFrame = (sx, sy) => { const s = size(), k = px(); const ox = v.x + v.w / 2 - (s.W * k) / 2, oy = v.y + v.h / 2 - (s.H * k) / 2; return { x: ox + (sx - s.r.left) * k, y: oy + (sy - s.r.top) * k }; };
    const toWorld = toFrame;
    // ---- gestures
    const ptrs = new Map(); let moved = 0, pinch = null, moving = false, lastTap = null, vel = { x: 0, y: 0, t: 0 }, glide = 0, two = null, full = false;
    const coop = () => o.cooperative && !full;
    let hintT = 0;
    function say(t) { hint.textContent = t; hint.hidden = false; clearTimeout(hintT); hintT = setTimeout(() => { hint.hidden = true; }, 1600); }
    svg.addEventListener('pointerdown', e => {
      cancelAnimationFrame(glide); cancelAnimationFrame(anim);
      if (e.pointerType === 'touch' && coop() && ptrs.size === 0) { ptrs.set(e.pointerId, { x: e.clientX, y: e.clientY, x0: e.clientX, y0: e.clientY, solo: true }); moved = 0; return; }
      try { svg.setPointerCapture(e.pointerId); } catch (x) { /* fine */ }
      ptrs.set(e.pointerId, { x: e.clientX, y: e.clientY, x0: e.clientX, y0: e.clientY });
      moved = 0;
      if (ptrs.size === 2) {
        const [a, b] = Array.from(ptrs.values());
        a.solo = b.solo = false;
        pinch = { d: Math.hypot(a.x - b.x, a.y - b.y), mx: (a.x + b.x) / 2, my: (a.y + b.y) / 2 };
        two = { t: performance.now(), moved: 0 };
      }
    });
    svg.addEventListener('pointermove', e => {
      const p = ptrs.get(e.pointerId); if (!p) return;
      if (p.solo) { if (Math.abs(e.clientX - p.x0) + Math.abs(e.clientY - p.y0) > 14) say('Use two fingers to move the map'); return; }
      const k = px(), dx = e.clientX - p.x, dy = e.clientY - p.y;
      p.x = e.clientX; p.y = e.clientY;
      if (ptrs.size === 1) {
        moved += Math.abs(dx) + Math.abs(dy);
        if (moved > 4) { moving = true; userMoved = true; v.x -= dx * k; v.y -= dy * k; clamp(); draw(); const now = performance.now(), dt = Math.max(1, now - vel.t); vel = { x: dx / dt * .8 + vel.x * .2, y: dy / dt * .8 + vel.y * .2, t: now }; if (o.onMove) o.onMove(); }
      } else if (ptrs.size === 2 && pinch) {
        const [a, b] = Array.from(ptrs.values()), dd = Math.hypot(a.x - b.x, a.y - b.y), mx = (a.x + b.x) / 2, my = (a.y + b.y) / 2;
        two.moved += Math.abs(dx) + Math.abs(dy);
        moving = true; userMoved = true;
        // The pinch's middle moving pans the map; its spread zooms around that middle.
        v.x -= (mx - pinch.mx) * k; v.y -= (my - pinch.my) * k;
        const m = toFrame(mx, my);
        if (dd > 0) { const f = pinch.d / dd; v.x = m.x - (m.x - v.x) * f; v.y = m.y - (m.y - v.y) * f; v.w *= f; v.h *= f; }
        clamp(); draw();
        pinch = { d: dd, mx, my }; moved = 99;
        if (o.onMove) o.onMove();
      }
    });
    const up = e => {
      const p = ptrs.get(e.pointerId); if (!p) return;
      ptrs.delete(e.pointerId);
      if (p.solo) {
        if (e.type === 'pointerup' && Math.abs(e.clientX - p.x0) + Math.abs(e.clientY - p.y0) < 8) tap(e);
        return;
      }
      if (two && ptrs.size === 1) {
        // Two fingers down and up quickly without moving: zoom out.
        if (performance.now() - two.t < 260 && two.moved < 16) { zoom(1.6, null, null, true); two = null; ptrs.clear(); pinch = null; moving = false; return; }
      }
      if (ptrs.size < 2) pinch = null;
      if (ptrs.size === 0) {
        two = null;
        if (moving && moved > 4 && moved < 99 && e.type === 'pointerup' && !reduced() && performance.now() - vel.t < 80) momentum();
        else moving = false;
        draw();
      }
      if (e.type === 'pointerup' && moved < 6) tap(e);
    };
    function momentum() {
      let vx = vel.x, vy = vel.y, t0 = performance.now();
      const step = now => { const dt = now - t0; t0 = now; const k = px(); v.x -= vx * dt * k; v.y -= vy * dt * k; vx *= Math.pow(.92, dt / 16); vy *= Math.pow(.92, dt / 16); clamp(); draw(); if (Math.hypot(vx, vy) > .02) glide = requestAnimationFrame(step); else { moving = false; draw(); } };
      glide = requestAnimationFrame(step);
    }
    function tap(e) {
      const now = performance.now();
      // A second tap close by: zoom in there.
      if (lastTap && now - lastTap.t < 300 && Math.hypot(e.clientX - lastTap.x, e.clientY - lastTap.y) < 24) {
        clearTimeout(lastTap.timer); lastTap = null;
        const m = toFrame(e.clientX, e.clientY); zoom(.5, m.x, m.y, true); return;
      }
      const t = document.elementFromPoint(e.clientX, e.clientY), b = t && t.closest && t.closest('[data-b]'), sp = t && t.closest && t.closest('[data-spot]'), dr = t && t.closest && t.closest('[data-door]');
      const pt = toWorld(e.clientX, e.clientY);
      // Wait to see if it's a double-tap before acting on a single one.
      lastTap = { t: now, x: e.clientX, y: e.clientY, timer: setTimeout(() => {
        lastTap = null;
        if (o.onTap) o.onTap(pt, b ? b.dataset.b : '', sp ? sp.dataset.spot : '', dr ? dr.dataset.door : '');
        else if (sp && o.onSpot) o.onSpot(sp.dataset.spot);
        else if (b && o.onPick) o.onPick(b.dataset.b);
      }, 260) };
    }
    svg.addEventListener('pointerup', up); svg.addEventListener('pointercancel', up);
    let wheelHinted = false;
    svg.addEventListener('wheel', e => {
      // Inside a page, a plain wheel scrolls the page; ⌘ or Ctrl (a trackpad pinch sends Ctrl) zooms.
      if (coop() && !e.ctrlKey && !e.metaKey) { if (!wheelHinted) { wheelHinted = true; say((/Mac|iPhone|iPad/.test(navigator.platform) ? '⌘' : 'Ctrl') + ' + scroll to zoom'); } return; }
      e.preventDefault(); userMoved = true; const m = toFrame(e.clientX, e.clientY); zoom(Math.pow(1.0022, e.deltaY), m.x, m.y);
    }, { passive: false });
    root.addEventListener('keydown', e => {
      if (e.target !== root) return;
      const k = px(), s = size(), step = Math.min(s.W, s.H) * .18 * k;
      const keys = { ArrowLeft: [-step, 0], ArrowRight: [step, 0], ArrowUp: [0, -step], ArrowDown: [0, step] };
      if (keys[e.key] || /^[-+=_]$/.test(e.key)) userMoved = true;
      if (keys[e.key]) { e.preventDefault(); goTo({ x: v.x + keys[e.key][0], y: v.y + keys[e.key][1], w: v.w, h: v.h }, true); if (o.onMove) o.onMove(); }
      else if (e.key === '+' || e.key === '=') { e.preventDefault(); zoom(.66, null, null, true); }
      else if (e.key === '-' || e.key === '_') { e.preventDefault(); zoom(1.5, null, null, true); }
    });
    root.querySelector('.pv-ctl').addEventListener('click', e => {
      const b = e.target.closest('button'); if (!b) return;
      if (b.dataset.z === 'full') api.full(!full);
      else if (b.dataset.z) { userMoved = true; zoom(b.dataset.z === 'in' ? .6 : 1.6, null, null, true); }
      else if (b.hasAttribute('data-locate') && o.onLocate) o.onLocate();
    });
    // Kept fitted when the box changes size (a phone turned, a window resized, the sheet moved).
    if (ro) {
      let w0 = 0, h0 = 0;
      new ResizeObserver(() => { const s = size(); if (Math.abs(s.W - w0) < 1 && Math.abs(s.H - h0) < 1) return; w0 = s.W; h0 = s.H; if (lastFit && !userMoved && !moving) fit(lastFit.box, lastFit.pad, false, lastFit.at); else draw(); }).observe(svg);
    }
    const api = {
      el, root, fit, draw, zoom, toWorld,
      view: () => Object.assign({}, v),
      // The part of the map covered by a sheet or a bar (screen pixels): fits and names keep clear of it.
      inset(t) { inset = Object.assign({ top: 0, bottom: 0 }, t); draw(); },
      // A building picked out (tinted, with a firm outline), by name; or a field ({ green }).
      select(name, green) {
        const i = name && find(c, name);
        G('sel').innerHTML = (i ? '<path class="pv-picked" d="' + d(i) + '"/>' : '') + (green ? '<path class="pv-picked pv-picked--green" d="' + d(green) + '"/>' : '');
        picked = i ? i.name : '';
        draw();
        return i;
      },
      // Pins: { x, y, label, kind: 'to' (a place: a pin with its name) | 'stay' (my hall: a bed) | 'room' (a small dot) | 'draft' }.
      pins(list) {
        G('pins').innerHTML = (list || []).map(p => '<g class="pv-pin is-' + (p.kind || 'to') + '" data-x="' + p.x.toFixed(2) + '" data-y="' + p.y.toFixed(2) + '"' + (p.of ? ' data-of="' + esc(p.of) + '"' : '') + '>' +
          // A stay: a bed on a white badge (polish 2: my hall, named at every zoom).
          (p.kind === 'stay' ? '<circle r="12"/><path class="pv-pin__bed" d="M-7 5V-5M-7 2h14v3M7 2V0a2 2 0 0 0-2-2h-6v4M-4 -.5a1.4 1.4 0 1 0 0-2.8 1.4 1.4 0 0 0 0 2.8Z"/>'
            : p.kind === 'room' ? '<circle r="6"/><circle class="pv-pin__dot" r="2.4"/>' : '<path d="M0 0c-5-7.5-11-12-11-19a11 11 0 0 1 22 0c0 7-6 11.5-11 19Z"/><circle class="pv-pin__dot" cy="-19" r="4"/>') +
          (p.label ? '<text y="' + (p.kind === 'room' ? 20 : p.kind === 'stay' ? 16 : 14) + '">' + esc(p.label) + '</text>' : '') + '</g>').join('');
        draw();
      },
      // Doors (the pins tool): { x, y, id, n (its number in its building's list), named, guessed, on }.
      doors(list) {
        G('doors').innerHTML = (list || []).map(p => '<g class="pv-door' + (p.named ? ' is-named' : '') + (p.guessed ? ' is-guessed' : '') + (p.on ? ' is-on' : '') + '" data-door="' + esc(p.id || '') + '" data-x="' + p.x.toFixed(2) + '" data-y="' + p.y.toFixed(2) + '"><circle r="9"/>' + (p.n ? '<text class="pv-door__n">' + esc(p.n) + '</text>' : '') + (p.label ? '<text y="20">' + esc(p.label) + '</text>' : '') + '</g>').join('');
        draw();
      },
      // You are here: the blue dot and how sure the phone is (its accuracy circle).
      me(p) {
        const at = p ? 'cx="' + p.x.toFixed(1) + '" cy="' + p.y.toFixed(1) + '"' : '';
        G('me').innerHTML = p ? '<circle class="pv-me__acc" ' + at + ' r="' + Math.max(4, p.acc || 10).toFixed(1) + '"/><circle class="pv-me__ring" data-r="9" ' + at + ' r="1"/><circle class="pv-me__dot" data-r="6" ' + at + ' r="1"/>' : '';
        draw();
      },
      // A point in the middle of what shows (at: lower down, as a share of the height).
      centre(p, ease, at) { const s = size(), k = px(), cys = inset.top + (s.H - inset.top - inset.bottom) * (at || .5); goTo({ x: p.x - v.w / 2, y: p.y - cys * k, w: v.w, h: v.h }, ease); },
      // Full screen (the Expand button): one finger moves it there.
      full(on) {
        full = !!on; root.classList.toggle('is-full', full); document.documentElement.classList.toggle('pv-lock', full);
        const b = root.querySelector('[data-z="full"]'); if (b) { b.setAttribute('aria-label', full ? 'Close full screen' : 'Full screen'); b.title = b.getAttribute('aria-label'); }
        if (o.onFull) o.onFull(full);
        requestAnimationFrame(() => { if (lastFit) fit(lastFit.box, lastFit.pad, false, lastFit.at); else draw(); });
      },
      hint: say,
      used(names) { used.clear(); (names || []).forEach(n => used.add(n)); labs.forEach(t => t.classList.toggle('is-used', used.has(t.dataset.n))); draw(); }
    };
    if (o.cooperative) document.addEventListener('keydown', e => { if (e.key === 'Escape' && full) api.full(false); });
    // First view: the place asked for, else the buildings the Conference uses.
    // (Unless a place was asked for first: the audit found the start's frame overriding it.)
    requestAnimationFrame(() => { if (!lastFit) fit(o.focus || (o.start && o.start.length ? boxOf(c, o.start, 30) : null) || B, 8); });
    return api;
  }

  // Scroll a plan's box (a phone's) to show a room, both ways.
  function reveal(box, id) {
    const g = box && id && box.querySelector('[data-room="' + CSS.escape(id) + '"]');
    if (!g) return;
    const b = g.getBoundingClientRect(), c = box.getBoundingClientRect();
    if (box.scrollWidth > box.clientWidth) box.scrollLeft += (b.left + b.width / 2) - (c.left + c.width / 2);
    if (box.scrollHeight > box.clientHeight) box.scrollTop += (b.top + b.height / 2) - (c.top + c.height / 2);
  }

  /* ================================================================ the campus record (members) */

  // The pins tool's reads and writes (includes/module-map.php): the year's campus, every part with its
  // version; a row changed on the server's copy; a part replaced (409 when someone changed it first).
  const store = {
    load: y => window.OGC_WP ? OGC_WP.api('GET', 'years/' + y + '/campus') : Promise.reject(new Error('No server')),
    row: (y, part, row) => OGC_WP.api('PATCH', 'years/' + y + '/campus/' + part, { row }),
    put: (y, part, rows, version) => OGC_WP.api('PUT', 'years/' + y + '/campus/' + part, { rows, version }),
    // Where this person sleeps (their own registration only). Polish 3: the guide offline lost My room, the
    // trip people most need with no signal. Their own hall, floor and room numbers are kept on this phone
    // (ogc-stay-<year>) after each answer, never on a shared device, and forgotten when they sign out or
    // the server says they're not signed in. Not signed in on this page (the guide's offline copy is the
    // public page): asked once; no answer at all means offline, so what was kept is used.
    stay: y => {
      const W = window.OGC_WP, key = 'ogc-stay-' + y;
      if (!W) return Promise.resolve(null);
      const kept = () => { try { return JSON.parse(localStorage.getItem(key) || 'null'); } catch (e) { return null; } };
      const keep = v => {
        try {
          if (v && v.type && !W.sharedDevice) localStorage.setItem(key, JSON.stringify({ type: v.type, posted: v.posted, rooms: (v.rooms || []).map(r => ({ hall: r.hall, floor: r.floor, num: r.num })), halls: v.halls || [], kept: true }));
          else localStorage.removeItem(key);
        } catch (e) { /* not kept */ }
        return v;
      };
      if (W.me) return W.api('GET', 'years/' + y + '/me/stay').then(keep, e => e && e.status ? keep(null) : kept());
      if (!kept()) return Promise.resolve(null);
      return fetch((W.rest || '/wp-json/ogc/v1/') + 'years/' + y + '/me/stay', { credentials: 'same-origin', cache: 'no-store' }).then(() => keep(null), () => kept());
    },
    taken: y => window.OGC_WP && OGC_WP.me ? OGC_WP.api('GET', 'years/' + y + '/rooms/taken').catch(() => null) : Promise.resolve(null)
  };

  // Signing out forgets the room kept for the guide offline (above).
  document.addEventListener('click', e => {
    if (!e.target.closest || !e.target.closest('[data-acct-out]')) return;
    try { Object.keys(localStorage).filter(k => k.indexOf('ogc-stay-') === 0).forEach(k => localStorage.removeItem(k)); } catch (x) { /* nothing kept */ }
  }, true);

  O.map = { plans, near, stairsOnly, orderFloors, floorSvg, turnFor, legend, reveal, campus, campusSvg, mini, hallMini, packetMap, codesTable, boxOf, buildingFor, whereIs, whereAmI, placeLine, nearestDoor, check, toMap, toLatLng, entrance, placeLatLng, mapsUrl, directionsUrl, OUT, onCampus, router, routerOf, viewer, minutes, feet, walkMin, find, shortOf, shortsFor, floorName, norm, inPoly, fitText, store, CREDIT, CREDIT_URL, SPOT, SPOT_MARK };
})();
