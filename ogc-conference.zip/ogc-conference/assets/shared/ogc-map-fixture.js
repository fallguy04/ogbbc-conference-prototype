/*
 * ogc-map-fixture.js — the map area's floor-plan fixture (local development only; module-map-dev.php).
 * Every hall and floor, every room state, long names, Lodging's marks: drawn as the room picker draws them
 * on a phone (3 px a foot, a wing at a time) and as Lodging's board does on a laptop (2 and 4 px a foot),
 * so tools/map-check.sh can measure every word. The names are made up.
 */
(function () {
  'use strict';
  const O = window.OGC, M = O && O.map, root = document.getElementById('ogc-plans-fixture');
  if (!M || !root) return;
  let rows = [];
  try { rows = JSON.parse(document.getElementById('ogc-plans-data').textContent || '[]'); } catch (e) { rows = []; }
  const halls = M.plans(rows), narrow = innerWidth < 768;
  const STATES = ['free', 'taken', 'held', 'off', 'sel', 'mine', 'sug', 'other', 'plain', 'free', 'taken', 'sug'];
  const NAMES = ['M. Hochstetler', 'R. Kauffman', 'J. Oberholtzer', 'A. Wenger', 'S. Brubaker'];
  const scales = narrow ? [3] : [2, 4];
  const out = [];
  Object.values(halls).forEach(h => h.list.forEach(f => scales.forEach(k => {
    let n = 0;
    const st = r => STATES[(+r.label || n++) % STATES.length];
    const svg = M.floorSvg(f, {
      state: st, pick: true, pickAll: true, narrow, px: narrow ? 3 : 0, turn: M.turnFor(f, narrow),
      tag: r => (+r.label % 5 === 1 ? NAMES[(+r.label / 5 | 0) % NAMES.length] : ''),
      mark: r => (+r.label % 7 === 0 ? 'walker' : +r.label % 7 === 3 ? 'older' : ''),
      title: h.name + ', ' + M.floorName(f.floor), sampleHref: ''
    });
    out.push('<section class="fx-floor" data-k="' + k + '"><h2 style="font:700 15px/1.3 sans-serif;margin:18px 0 6px">' + O.esc(h.name + ' · ' + M.floorName(f.floor) + ' · ' + k + ' px a foot') + '</h2><div class="fx-box" style="overflow:auto">' + svg + '</div></section>');
  })));
  root.innerHTML = (out.join('') || '<p>No plans</p>') + M.legend([['free', 'Free'], ['taken', 'Taken'], ['sel', 'Chosen'], ['sug', 'Suggested'], ['held', 'Kept'], ['other', 'Near request'], ['off', 'Out of service'], ['plain', 'Other rooms'], ['walker', 'Walker'], ['older', 'Older']]);
  // Each drawing at its scale: its width in feet times its pixels a foot.
  root.querySelectorAll('.fx-floor').forEach(sec => {
    const k = +sec.dataset.k;
    sec.querySelectorAll('svg.pl-floor').forEach(s => { const vb = s.viewBox.baseVal; s.style.width = Math.round(vb.width * k) + 'px'; s.style.maxWidth = 'none'; });
  });
  document.documentElement.dataset.fixture = 'ready';
})();
