/*
 * ogc-map-floors.js — the campus's floors on the guide's map (the map area, Nov 5; docs/34 §3–§5, §8–§10).
 *
 * A campus with a public build (tools/campus/build-plugin.py → assets/campus/<slug>/, named for the year
 * in OGC_WP.floors) opens its buildings in place. Zoom in, or choose a place, and the building's roof
 * lifts away: its floor shows as a white card, the Conference's rooms named (or a code plate where a name
 * doesn't fit), the restrooms, stairs and elevators marked, its doors as small triangles, and the floor
 * picker at the side. A chosen room turns tan, with its name plate and the line from the best door along
 * the halls to its own door. A campus with no build has none of this: the map is as it was.
 *
 * Only one building is open at a time, and only its one floor is drawn. Nothing is guessed: the rooms,
 * doors, restrooms and walks are the build's (campus/FORMAT.md, "The public build"); the door line is the
 * quickest walk by its fixed rules (Dijkstra by time, step-free first); "nearest" is measured along those
 * walks, in feet (feet()). The build has no dorm or Lodge in it, and no number or name for a room that
 * isn't the Conference's (docs/34 §11, §12.6).
 *
 * The planner (Nov 5, round 2 part 2; ogc-map-route.js plans, ogc-map-app.js asks): with a route shown
 * (route()), the door line gives way to the route, which the map draws (viewer.route); the layer names
 * the route's doors, puts a floor-change pill where it changes floor (a tap shows that floor), dots the
 * picker's floors it uses, opens a building asked for (focus(): a step on a laptop, Set start) and takes
 * one tap on an opened floor as where you are (pick()).
 *
 * The small maps (Nov 5, round 2 part 3; docs/34 §6.1): picture() draws a place's door-to-room picture for
 * a sheet (an event, a place, a volunteer shift) with the same floor drawing and marks as the map
 * (floorBody(), the mark builders below): the floor cropped round the best door and the room, the room in
 * tan with its plate, the line along the halls, the door named, and the floor's caption. The best door and
 * the line are the one router's (O.map.plan, from the building to the room). ogc-map.js's mini() asks for it.
 */
(function () {
  'use strict';
  const O = window.OGC, M = O && O.map;
  if (!M) return;
  const esc = O.esc;
  const reduced = () => window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  const BUILT = { hall: 1, dining: 1, worship: 1, venue: 1, other: 1 };

  /* ================================================================ the build */

  const loads = {}, loaded = {};
  // The year's build (its index), or null: no build, no server, or it didn't come.
  function load(year) {
    const W = window.OGC_WP || {}, href = W.floors && W.floors[String(year)];
    if (!href || !window.fetch) return Promise.resolve(null);
    const url = new URL(href, location.href).href;
    return loads[url] || (loads[url] = fetch(url, { credentials: 'same-origin' }).then(r => r.ok ? r.json() : null)
      .then(ix => ix && ix.format === 1 ? (loaded[url] = plansOf(ix, url)) : null)
      .catch(() => { delete loads[url]; return null; }));
  }
  // The year's build when it has already come (the small maps choose their box at once), else null;
  // hasBuild(year): the year's campus has one at all (OGC_WP.floors).
  const urlOf = year => { const W = window.OGC_WP || {}, href = W.floors && W.floors[String(year)]; return href ? new URL(href, location.href).href : ''; };
  const ready = year => loaded[urlOf(year)] || null;
  const hasBuild = year => !!urlOf(year) && !!window.fetch;
  // "Floor plans: IWU": the campus's initials from its name in the build (three words or more), else its name.
  function creditOf(slug) {
    const w = String(slug || '').split('-').filter(Boolean);
    if (w.length >= 3) return w.map(x => x.charAt(0).toUpperCase()).join('');
    return w.map(x => x.charAt(0).toUpperCase() + x.slice(1)).join(' ');
  }
  function plansOf(ix, url) {
    const P = { ix, list: [], by: {}, places: ix.places || {}, entrances: ix.entrances || [], credit: 'Floor plans: ' + creditOf(ix.campus) };
    (ix.buildings || []).forEach(b => {
      const B = { name: b.name, code: String(b.code || '').toUpperCase(), middle: b.middle || null, entrance: +b.entrance_floor || 1,
        // A floor placed more than a metre off never opens on the campus (docs/34 §3.5).
        ok: !(b.placement && +b.placement.residual_m > 1), floors: (b.floors || []).map(f => +f.floor).sort((p, q) => p - q), href: {} };
      (b.floors || []).forEach(f => { B.href[+f.floor] = new URL(f.href, url).href; });
      if (B.code && B.floors.length) { P.list.push(B); P.by[B.code] = B; }
    });
    const got = {}, wait = {}, fail = {};
    P.got = (code, n) => got[code + '-' + n] || null;
    // A floor that didn't come (no signal and not kept yet, a dropped line, an error) is asked for again
    // after 30 s or when the phone is back online, never every frame (the check: 60 requests a second).
    P.missing = (code, n) => !!fail[code + '-' + n];
    P.onChange = null;
    const changed = () => { if (P.onChange) P.onChange(); };
    const miss = k => { if (fail[k]) return; fail[k] = setTimeout(() => { delete fail[k]; changed(); }, 30000); changed(); };
    addEventListener('online', () => { const ks = Object.keys(fail); if (!ks.length) return; ks.forEach(k => { clearTimeout(fail[k]); delete fail[k]; }); changed(); });
    P.floor = (code, n) => {
      const k = code + '-' + n, B = P.by[code];
      if (got[k]) return Promise.resolve(got[k]);
      if (!B || !B.href[n] || fail[k]) return Promise.resolve(null);
      return wait[k] || (wait[k] = fetch(B.href[n], { credentials: 'same-origin' }).then(r => r.ok ? r.json() : null)
        .then(f => { delete wait[k]; if (!f) { miss(k); return null; } return (got[k] = prep(f)); })
        .catch(() => { delete wait[k]; miss(k); return null; }));
    };
    P.floorsOf = code => Promise.all((P.by[code] ? P.by[code].floors : []).map(n => P.floor(code, n))).then(l => l.filter(Boolean));
    // The walking graph and the area as the build has them (the planner's router reads them raw: Nov 5,
    // round 2 part 2), and the graph made ready for the door line and Nearby. One fetch each, kept; one that
    // didn't come is asked for again next time.
    let walkP = null, rawP = null, areaP = null;
    const json = (href, done) => fetch(new URL(href, url).href, { credentials: 'same-origin' }).then(r => r.ok ? r.json() : null).then(x => { if (!x) done(); return x; }).catch(() => { done(); return null; });
    P.walkRaw = () => rawP || (rawP = ix.walk && ix.walk.href ? json(ix.walk.href, () => { rawP = null; }) : Promise.resolve(null));
    P.area = () => areaP || (areaP = ix.area && ix.area.href ? json(ix.area.href, () => { areaP = null; }) : Promise.resolve(null));
    P.walk = () => walkP || (walkP = P.walkRaw().then(w => { if (!w) { walkP = null; return null; } return graph(w); }));
    // The build the small maps route over: the walk and the index, no streets (a door to a room never
    // leaves the building), one object for the year so the router is made once (O.map.routerOf).
    let inP = null;
    P.indoor = () => inP || (inP = P.walkRaw().then(w => { if (!w) { inP = null; return null; } return { walk: w, index: ix }; }));
    // A place's rooms in the build: [{ floor, number }] (none: a whole building, or not in the build).
    P.roomsOf = code => { const p = P.places[String(code || '').toUpperCase()]; return p ? p.rooms || [] : null; };
    return P;
  }

  // A shape (rings of flat x, y lists) as an SVG path, and its box.
  const ring = r => { let s = 'M' + r[0].toFixed(2) + ' ' + r[1].toFixed(2); for (let i = 2; i < r.length - 1; i += 2) s += 'L' + r[i].toFixed(2) + ' ' + r[i + 1].toFixed(2); return s + 'Z'; };
  const path = rs => (rs || []).filter(r => r && r.length >= 6).map(ring).join('');
  function boxOfRings(rs) {
    let x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity;
    (rs || []).forEach(r => { for (let i = 0; i < r.length - 1; i += 2) { x0 = Math.min(x0, r[i]); x1 = Math.max(x1, r[i]); y0 = Math.min(y0, r[i + 1]); y1 = Math.max(y1, r[i + 1]); } });
    return x0 < Infinity ? { x: x0, y: y0, w: x1 - x0, h: y1 - y0 } : null;
  }
  const titleCase = s => String(s || '').toLowerCase().replace(/(^|[\s/(-])([a-z])/g, (m, a, b) => a + b.toUpperCase());
  // A floor file made ready to draw once: its paths, and its rooms by number.
  function prep(f) {
    f._out = path(f.outline);
    f._box = boxOfRings(f.outline);
    // Walls and columns are drawn solid at their true thickness, each part one path (they have holes).
    f._walls = (f.walls || []).map(path).join('');
    // IWU's structural columns: drawn only in the Detail band (§3.2 layer 8 has none; at building zoom a
    // hall of them read as a dotted line).
    f._cols = (f.columns || []).map(path).join('');
    f._voids = (f.voids || []).map(path).join('');
    f._rooms = (f.rooms || []).map(r => ({ r, d: path(r.shape), box: boxOfRings(r.shape),
      // Where you walk (halls, lobbies, vestibules), what's shut (stairs, elevators), and the rest as rooms.
      cls: r.hall || r.kind === 'entrance' ? 'is-hall' : r.kind === 'stairs' || r.kind === 'elevator' ? 'is-shut' : 'is-room' }));
    f._by = {};
    f._rooms.forEach(x => { if (x.r.public && x.r.number) f._by[x.r.number] = x; });
    // The elevator's ✕ across its car.
    f._lift = liftPath(f);
    return f;
  }
  // The elevator's ✕ across its car, in metres, or (X: a small map's crop) in its pixels.
  function liftPath(f, X) {
    return f._rooms.filter(x => x.r.kind === 'elevator' && x.r.box && (!X || X.see(x.box))).map(x => {
      const b = x.r.box, a = b[0] - b[2] / 2, c = b[0] + b[2] / 2, t = b[1] - b[3] / 2, u = b[1] + b[3] / 2;
      if (X) return X.line([[a, t], [c, u]]) + X.line([[a, u], [c, t]]);
      return 'M' + a.toFixed(2) + ' ' + t.toFixed(2) + 'L' + c.toFixed(2) + ' ' + u.toFixed(2) + 'M' + a.toFixed(2) + ' ' + u.toFixed(2) + 'L' + c.toFixed(2) + ' ' + t.toFixed(2);
    }).join('');
  }

  /* ================================================================ the floor drawn (the map's and the small maps') */

  // One floor: the base, halls and what's shut, the Conference's rooms, the destination's rooms in tan, the
  // elevator's ✕, the walls and the outline's edge (§3.2 layers 8–9). The map's open floor (layer's
  // floorSvg) and a sheet's small map (picture()) are drawn by this one code. o: mode ('full' | 'simple'),
  // dest (room numbers in tan), whole (the whole building is where you're going: its edge tan-ink), g0 (the
  // entrance floor under an upper floor that covers only part of the building), X (a small map's crop:
  // what's outside it is left out, the rest in its pixels; else the floor's own paths in metres).
  function floorBody(f, o) {
    const X = o.X, dest = o.dest || [], out = X ? X.d(f.outline) : f._out;
    let h = '';
    // (a) the entrance floor's outline under an upper floor that covers only part of the building.
    if (o.g0 && o.g0 !== f) h += '<path class="pv-fl__ground" d="' + (X ? X.d(o.g0.outline) : o.g0._out) + '"/>';
    h += '<path class="pv-fl__base" d="' + out + '"/>';
    const isDest = x => x.r.public && dest.indexOf(String(x.r.number)) > -1;
    if (o.mode === 'full') {
      const voids = X ? (f.voids || []).map(X.d).join('') : f._voids;
      if (voids) h += '<path class="pv-fl__void" d="' + voids + '"/>';
      // (c) halls and what's shut; the Conference's rooms (taps find them); the destination in tan.
      h += f._rooms.map(x => {
        const code = x.r.public && x.r.codes && x.r.codes[0], tan = isDest(x);
        if (!x.d || (!code && !tan && x.cls === 'is-room')) return '';
        // (A small map has no taps: a Conference room, white on the white floor, isn't drawn there.)
        if (X && (!X.see(x.box) || (!tan && x.cls === 'is-room'))) return '';
        return '<path class="pv-fl__r ' + (tan ? 'is-dest' : x.cls) + '" d="' + (X ? X.d(x.r.shape) : x.d) + '"' + (code && !X ? ' data-rm="' + esc(code) + '"' : '') + '/>';
      }).join('');
      // (d) the elevator's ✕, (e) the walls, solid, (f) the outline's edge.
      const lift = X ? liftPath(f, X) : f._lift;
      if (lift) h += '<path class="pv-fl__x" d="' + lift + '"/>';
      h += '<path class="pv-fl__w" d="' + (X ? wallsIn(f, X) : f._walls) + '"/>';
      // (IWU's columns show only in the map's Detail band: a small map never has them.)
      if (f._cols && !X) h += '<path class="pv-fl__w pv-fl__col" d="' + f._cols + '"/>';
    } else {
      h += f._rooms.filter(x => x.d && isDest(x)).map(x => '<path class="pv-fl__r is-dest" d="' + (X ? X.d(x.r.shape) : x.d) + '"/>').join('');
    }
    // A whole building chosen (B, W, Y): its open floor edged in tan-ink, where a room would be tan (layer 9).
    h += '<path class="pv-fl__edge' + (o.whole ? ' is-dest' : '') + '" d="' + out + '"/>';
    return h;
  }
  // The walls in a crop: each part (a wall with its holes) whose box is in it.
  function wallsIn(f, X) {
    const bs = f._wb || (f._wb = (f.walls || []).map(boxOfRings));
    return (f.walls || []).map((part, i) => bs[i] && X.see(bs[i]) ? X.d(part, 1.5) : '').join('');
  }

  // A word's width in screen pixels, in the map's sans (family: the element's own, else the page's).
  let ctx2d = null;
  function measure(t, px, weight, family) {
    if (!ctx2d) ctx2d = document.createElement('canvas').getContext('2d');
    ctx2d.font = (weight || 700) + ' ' + px + 'px ' + (family || 'sans-serif');
    return ctx2d.measureText(t).width;
  }
  // A line icon (I1) in a size × size box round its point.
  const icon = (k, size) => '<g transform="translate(' + (-size / 2) + ' ' + (-size / 2) + ') scale(' + (size / 24).toFixed(4) + ')"><path class="pv-ico" d="' + ICON[k] + '" style="stroke-width:' + (1.6 * 24 / size).toFixed(2) + 'px"/></g>';
  // The marks the map and the small maps share: a door's entry triangle (pointing in at angle a, sc times
  // its size), a name plate with its tail (w: its width), and a floor's caption with its rule (tw: its width).
  const entMark = (a, sc) => '<path class="pv-ent" d="M4 0L-3 4L-3 -4Z" transform="rotate(' + a.toFixed(1) + ') scale(' + sc + ')"/>';
  const plateIn = (name, below, w) => {
    const h = 26, q = below ? -1 : 1;
    return '<path d="M-6 ' + (-7 * q) + 'L0 ' + (-1 * q) + 'L6 ' + (-7 * q) + 'Z"/><rect x="' + (-w / 2).toFixed(1) + '" y="' + (below ? 7 : -7 - h) + '" width="' + w.toFixed(1) + '" height="' + h + '" rx="5"/><text y="' + (below ? 7 + h / 2 + 1 : -7 - h / 2 + 1) + '">' + esc(name) + '</text>';
  };
  const capIn = (word, tw) => '<text>' + esc(word) + '</text><path d="M0 18H' + tw.toFixed(1) + '"/>';

  /* ================================================================ the walks inside */

  function graph(w) {
    const nc = w.node_cols || [], ec = w.edge_cols || [], N = (w.nodes || []).length;
    const ni = k => nc.indexOf(k), ei = k => ec.indexOf(k);
    const X = new Float64Array(N), Y = new Float64Array(N), F = new Int16Array(N), Bd = new Int16Array(N), PASS = new Float32Array(N), OUT = new Uint8Array(N);
    const [ix, iy, ifl, ib, ip, io] = ['x', 'y', 'floor', 'building', 'pass', 'out'].map(ni);
    w.nodes.forEach((n, i) => { X[i] = n[ix]; Y[i] = n[iy]; F[i] = n[ifl]; Bd[i] = n[ib]; PASS[i] = +n[ip] || 0; OUT[i] = n[io] ? 1 : 0; });
    const [ia, ibb, ik, im, isf, isec, inum, ibd, iv] = ['a', 'b', 'kind', 'm', 'step_free', 'seconds', 'number', 'building', 'via'].map(ei);
    const E = (w.edges || []).map(e => ({ a: e[ia], b: e[ibb], kind: e[ik], m: +e[im] || 0, sf: e[isf] !== 0, sec: +e[isec] || 0, num: String(e[inum] == null ? '' : e[inum]), bd: e[ibd], via: e[iv] || [] }));
    const adj = Array.from({ length: N }, () => []);
    E.forEach((e, i) => { adj[e.a].push(i); adj[e.b].push(i); });
    return { N, X, Y, F, Bd, PASS, OUT, E, adj, ends: w.ends || {}, names: w.buildings || [] };
  }
  // Quickest walks from a room's ways in (FORMAT.md): a row's length at 1.3 m/s, plus a stair's or an
  // elevator's seconds, plus a node's pass seconds when walking on past it (never where a walk starts).
  function walkFrom(G, src, ok, stop) {
    const d = new Float64Array(G.N).fill(Infinity), m = new Float64Array(G.N), prev = new Int32Array(G.N).fill(-1), done = new Uint8Array(G.N), start = new Uint8Array(G.N);
    const heap = [];
    const push = (c, n) => { heap.push([c, n]); let i = heap.length - 1; while (i > 0) { const p = (i - 1) >> 1; if (heap[p][0] <= heap[i][0]) break; [heap[p], heap[i]] = [heap[i], heap[p]]; i = p; } };
    const pop = () => { const top = heap[0], last = heap.pop(); if (heap.length) { heap[0] = last; let i = 0; for (;;) { const l = 2 * i + 1, r = l + 1; let s = i; if (l < heap.length && heap[l][0] < heap[s][0]) s = l; if (r < heap.length && heap[r][0] < heap[s][0]) s = r; if (s === i) break; [heap[s], heap[i]] = [heap[i], heap[s]]; i = s; } } return top; };
    src.forEach(n => { if (n >= 0 && n < G.N) { d[n] = 0; start[n] = 1; push(0, n); } });
    while (heap.length) {
      const [du, u] = pop();
      if (done[u]) continue;
      done[u] = 1;
      if (stop && !start[u] && stop(u)) return { d, m, prev, end: u };
      const extra = start[u] ? 0 : G.PASS[u];
      G.adj[u].forEach(i => {
        const e = G.E[i];
        if (ok && !ok(e)) return;
        const v = e.a === u ? e.b : e.a, c = du + extra + e.m / 1.3 + (e.kind === 'stairs' || e.kind === 'elevator' ? e.sec : 0);
        if (c < d[v]) { d[v] = c; m[v] = m[u] + e.m; prev[v] = i; push(c, v); }
      });
    }
    return { d, m, prev, end: -1 };
  }
  const endsOf = (G, code, floor, number) => G.ends[code + '|' + floor + '|' + number] || null;
  // The line from the best door to a room's own door: the quickest way out to a door that's open to
  // visitors (the build's named entrances, not key only), step-free when there is one. Traced back, with
  // the room's own rows at the end left off, so it stops at the room's door, never inside the tan.
  // want (Nov 5, night: one door everywhere): { number, stairs } from M.placeDoor's walk (doorWant): only
  // that door, and by the stairs when that walk takes them.
  function doorLine(G, P, B, floor, number, keyOnly, want) {
    const bi = G.names.indexOf(B.name), src = endsOf(G, B.code, floor, number);
    if (bi < 0 || !src) return null;
    const ents = P.entrances.filter(e => e.code === B.code && !(keyOnly && keyOnly(e.door)) && (!want || String(e.number) === String(want.number)));
    const doorAt = {};
    G.E.forEach(e => {
      if (e.kind !== 'entrance') return;
      const inside = G.OUT[e.a] ? e.b : e.a;
      if (G.Bd[inside] !== bi) return;
      const en = ents.find(x => x.number === e.num);
      if (en) doorAt[inside] = en;
    });
    const ok = sf => e => e.kind !== 'entrance' && G.Bd[e.a] === bi && G.Bd[e.b] === bi && (!sf || e.sf);
    let r = want && want.stairs ? { end: -1 } : walkFrom(G, src, ok(true), u => !!doorAt[u]), stepFree = true;
    if (r.end < 0) { r = walkFrom(G, src, ok(false), u => !!doorAt[u]); stepFree = false; }
    if (r.end < 0) return null;
    const steps = [];
    let u = r.end;
    while (r.prev[u] >= 0) { const e = G.E[r.prev[u]], v = e.a === u ? e.b : e.a; steps.push({ e, from: u, to: v }); u = v; }
    const popped = [];
    while (steps.length && steps[steps.length - 1].e.kind === 'room' && steps[steps.length - 1].e.num === String(number)) popped.push(steps.pop());
    // The room's own rows, from where the line stops on into the room: the line is run on along them to the
    // room's edge or the wall it meets (finish()), so it reaches the room instead of stopping in the hall.
    const tail = [];
    for (let i = popped.length - 1; i >= 0; i--) {
      const st = popped[i], e = st.e, via = [];
      for (let j = 0; j < e.via.length - 1; j += 2) via.push([e.via[j], e.via[j + 1]]);
      if (e.a !== st.from) via.reverse();
      if (!tail.length) tail.push([G.X[st.from], G.Y[st.from]]);
      via.forEach(p => tail.push(p));
      tail.push([G.X[st.to], G.Y[st.to]]);
    }
    const parts = [];
    let cur = null;
    steps.forEach(st => {
      const e = st.e;
      if (e.kind === 'stairs' || e.kind === 'elevator') { cur = null; return; }
      const f = G.F[st.from], via = [];
      for (let i = 0; i < e.via.length - 1; i += 2) via.push([e.via[i], e.via[i + 1]]);
      if (e.a !== st.from) via.reverse();
      if (!cur || cur.floor !== f) { cur = { floor: f, pts: [[G.X[st.from], G.Y[st.from]]] }; parts.push(cur); }
      via.forEach(p => cur.pts.push(p));
      cur.pts.push([G.X[st.to], G.Y[st.to]]);
    });
    const end = steps.length ? steps[steps.length - 1].to : r.end;
    return { door: doorAt[r.end], parts, m: r.m[end], stepFree, at: [G.X[end], G.Y[end]], endFloor: G.F[end], tail, tailFloor: popped.length ? G.F[popped[popped.length - 1].from] : null,
      change: steps.filter(st => st.e.kind === 'stairs' || st.e.kind === 'elevator').map(st => st.e.kind)[0] || '' };
  }
  // The door the one door rule gives a room (M.placeDoor, ogc-map-route.js), for the line drawn from it:
  // → a promise of { number, stairs } or null (no build or no walk: the line's own best door).
  function doorWant(P, c, B, floor, number, stepFree) {
    if (!M.placeDoor || !M.routerOf || !c || !P.indoor) return Promise.resolve(null);
    return P.indoor().then(build => {
      if (!build) return null;
      const r = M.placeDoor(M.routerOf(c, build), B.code, { room: B.code + '|' + floor + '|' + number }, { stepFree });
      return r && r.door ? { number: r.door.number, stairs: (r.steps || []).some(q => q.kind === 'floor' && q.building === B.code && q.icon !== 'elevator') } : null;
    }).catch(() => null);
  }
  // A door line's words, then No stairs' reason when there's no step-free walk (M.placeDoor's r.why), no word
  // said twice: "East doors · Elevator · 2nd floor · Doors not checked", as Directions says it.
  const withWhy = (parts, why) => { const p = parts.filter(Boolean); return p.concat(String(why || '').split(' · ').filter(w => w && p.indexOf(w) < 0)).join(' · '); };
  // doorLine from that door (a door the floors' own walk can't reach from the room: its own best door).
  const lineTo = (G, P, B, floor, number, keyOnly, want) => (want && doorLine(G, P, B, floor, number, keyOnly, want)) || doorLine(G, P, B, floor, number, keyOnly);
  // The floor's walls and columns as segments, once (for the line's last stretch and its straightening).
  function segsOf(f) {
    if (f._segs) return f._segs;
    const out = [];
    [].concat(f.walls || [], f.columns || []).forEach(part => (part || []).forEach(r => { for (let i = 0; i + 1 < r.length; i += 2) { const j = (i + 2) % r.length; out.push(r[i], r[i + 1], r[j], r[j + 1]); } }));
    return (f._segs = new Float64Array(out));
  }
  // Where a→b first crosses one of the segments (t along a→b, 0 < t < 1), or null.
  function cross(a, b, segs, from) {
    let best = null;
    const dx = b[0] - a[0], dy = b[1] - a[1], x0 = Math.min(a[0], b[0]), x1 = Math.max(a[0], b[0]), y0 = Math.min(a[1], b[1]), y1 = Math.max(a[1], b[1]);
    for (let i = 0; i < segs.length; i += 4) {
      const px = segs[i], py = segs[i + 1], qx = segs[i + 2], qy = segs[i + 3];
      if (Math.max(px, qx) < x0 || Math.min(px, qx) > x1 || Math.max(py, qy) < y0 || Math.min(py, qy) > y1) continue;
      const ex = qx - px, ey = qy - py, den = dx * ey - dy * ex;
      if (!den) continue;
      const t = ((px - a[0]) * ey - (py - a[1]) * ex) / den, u = ((px - a[0]) * dy - (py - a[1]) * dx) / den;
      if (t > (from || 1e-6) && t < 1 - 1e-6 && u >= 0 && u <= 1 && (!best || t < best)) best = t;
    }
    return best;
  }
  // a→b clear of the walls and columns, and 15 cm from their corners.
  function clearOf(a, b, f) {
    const segs = segsOf(f);
    if (cross(a, b, segs) != null) return false;
    const dx = b[0] - a[0], dy = b[1] - a[1], l = dx * dx + dy * dy, x0 = Math.min(a[0], b[0]) - .15, x1 = Math.max(a[0], b[0]) + .15, y0 = Math.min(a[1], b[1]) - .15, y1 = Math.max(a[1], b[1]) + .15;
    for (let i = 0; i < segs.length; i += 4) {
      const px = segs[i], py = segs[i + 1];
      if (px < x0 || px > x1 || py < y0 || py > y1) continue;
      const t = l ? Math.max(0, Math.min(1, ((px - a[0]) * dx + (py - a[1]) * dy) / l)) : 0;
      if (t > .02 && t < .98 && Math.hypot(px - a[0] - t * dx, py - a[1] - t * dy) < .15) return false;
    }
    return true;
  }
  // The line drawn as walked, with its small kinks taken out: from each point, straight on to the farthest
  // point within 6 m along it that can be reached in a straight line clear of the walls. The walk is the
  // same; only its drawing is straighter (the check: a fish-hook in Barnes' south lobby).
  function straighten(pts, f) {
    if (pts.length < 3) return pts;
    const cum = [0];
    for (let i = 1; i < pts.length; i++) cum.push(cum[i - 1] + Math.hypot(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1]));
    const out = [pts[0]];
    let i = 0;
    while (i < pts.length - 1) {
      let j = i + 1;
      for (let q = pts.length - 1; q > i + 1; q--) { if (cum[q] - cum[i] <= 6 && clearOf(pts[i], pts[q], f)) { j = q; break; } }
      out.push(pts[j]); i = j;
    }
    return out;
  }
  // The line's last stretch run on into the room (doorLine's tail) until it meets the room's edge or a wall,
  // then every stretch on a floor straightened.
  function finish(line, P, B, number) {
    if (!line) return line;
    const last = line.parts[line.parts.length - 1], tail = line.tail || [];
    const f = line.tailFloor != null ? P.got(B.code, line.tailFloor) : null, x = f && f._by[String(number)];
    const room = [];
    if (x) (x.r.shape || []).forEach(r => { for (let i = 0; i + 1 < r.length; i += 2) { const j = (i + 2) % r.length; room.push(r[i], r[i + 1], r[j], r[j + 1]); } });
    const onIt = f && x && last && +last.floor === +line.tailFloor;
    if (onIt && tail.length > 1) {
      const segs = new Float64Array(Array.from(segsOf(f)).concat(room));
      for (let i = 0; i < tail.length - 1; i++) {
        const t = cross(tail[i], tail[i + 1], segs);
        if (t != null) { last.pts.push([tail[i][0] + (tail[i + 1][0] - tail[i][0]) * t, tail[i][1] + (tail[i + 1][1] - tail[i][1]) * t]); break; }
        last.pts.push(tail[i + 1]);
      }
    }
    line.parts.forEach(p => { const fl = P.got(B.code, +p.floor); if (fl) p.pts = straighten(p.pts, fl); });
    // Then it stops where it first goes into the room, wherever that falls (§3.1: it never enters the tan).
    // The build's room node can sit metres inside (PPAC 150: 6 m in, with a bend in the middle of the room).
    if (onIt && room.length) last.pts = clipAt(last.pts, new Float64Array(room), x.r.shape);
    return line;
  }
  // Inside a room's shape (its rings, even-odd).
  function inShape(px, py, shape) {
    let c = false;
    (shape || []).forEach(r => { for (let i = 0, n = r.length; i + 1 < n; i += 2) { const j = (i + 2) % n, xi = r[i], yi = r[i + 1], xj = r[j], yj = r[j + 1]; if ((yi > py) !== (yj > py) && px < (xj - xi) * (py - yi) / (yj - yi) + xi) c = !c; } });
    return c;
  }
  // A line cut where it first crosses into the shape (a crossing that only clips a corner doesn't count).
  function clipAt(pts, segs, shape) {
    for (let i = 0; i < pts.length - 1; i++) {
      const a = pts[i], b = pts[i + 1], len = Math.hypot(b[0] - a[0], b[1] - a[1]) || 1;
      let t = 0;
      while ((t = cross(a, b, segs, t)) != null) {
        const q = [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t], u = Math.min(1, t + .1 / len);
        if (inShape(a[0] + (b[0] - a[0]) * u, a[1] + (b[1] - a[1]) * u, shape)) return pts.slice(0, i + 1).concat([q]);
      }
    }
    return pts;
  }
  // The nearest restroom and elevator from a room's door, along the halls (docs/34 §4.3). A restroom a
  // visitor can't use (the build marks it walk: false) and a locker room are left out.
  function nearestFrom(G, B, floors, floor, number) {
    const bi = G.names.indexOf(B.name), src = endsOf(G, B.code, floor, number);
    if (bi < 0 || !src) return null;
    const r = walkFrom(G, src, e => e.kind !== 'entrance' && G.Bd[e.a] === bi && G.Bd[e.b] === bi);
    const best = list => {
      let b = null;
      list.forEach(x => (endsOf(G, B.code, x.floor, x.number) || []).forEach(n => { if (r.d[n] < Infinity && (!b || r.d[n] < b.d)) b = { x, d: r.d[n], m: r.m[n] }; }));
      return b;
    };
    const rest = [], lifts = [];
    floors.forEach(f => {
      (f.restrooms || []).forEach(x => { const rm = f._by[x.number]; if (x.walk !== false && !(rm && /LOCKER|SHOWER|TEAM|STAFF/i.test(rm.r.name || ''))) rest.push(Object.assign({ floor: f.floor }, x)); });
      (f.elevators || []).forEach(x => lifts.push(Object.assign({ floor: f.floor }, x)));
    });
    const rr = best(rest), ll = best(lifts);
    // "Restrooms" when the nearest is one of a women's and men's pair (the other within 15 m on its floor).
    if (rr) {
      const w = rr.x.who, pair = (w === 'women' || w === 'men') && rest.some(o => o.floor === rr.x.floor && o.who === (w === 'women' ? 'men' : 'women') && Math.hypot(o.at[0] - rr.x.at[0], o.at[1] - rr.x.at[1]) <= 15);
      rr.word = pair ? 'Restrooms' : WHO[w] || 'Restroom';
    }
    return { rest: rr, lift: ll, stairsOnly: !lifts.length && floor !== B.entrance };
  }
  const WHO = { women: 'Women', men: 'Men', family: 'Family restroom', unknown: 'Restroom' };

  /* ================================================================ icons (24-unit line icons, I1) */

  const ICON = {
    women: 'M12 6.5a1.75 1.75 0 1 0 0-3.5 1.75 1.75 0 0 0 0 3.5ZM10.25 20.5v-5H8l2.4-6.9a1.5 1.5 0 0 1 1.4-1h.4a1.5 1.5 0 0 1 1.4 1L16 15.5h-2.25v5',
    men: 'M12 6.5a1.75 1.75 0 1 0 0-3.5 1.75 1.75 0 0 0 0 3.5ZM9.5 20.5V14l-1-.5V10A1.5 1.5 0 0 1 10 8.5h4a1.5 1.5 0 0 1 1.5 1.5v3.5l-1 .5v6.5M12 14.5v6',
    family: 'M8.5 6.5a1.75 1.75 0 1 0 0-3.5 1.75 1.75 0 0 0 0 3.5ZM5.5 20.5v-6.5l-1-.5V10A1.5 1.5 0 0 1 6 8.5h5A1.5 1.5 0 0 1 12.5 10v3.5l-1 .5v6.5M17 11a1.4 1.4 0 1 0 0-2.8 1.4 1.4 0 0 0 0 2.8ZM15 20.5v-4l-.7-.5v-2.2a1 1 0 0 1 1-1h3.4a1 1 0 0 1 1 1V16l-.7.5v4',
    unknown: 'M7.5 6a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3ZM5.5 20.5V15l-1-.5v-4A1.5 1.5 0 0 1 6 9h3a1.5 1.5 0 0 1 1.5 1.5v4l-1 .5v5.5M16.5 6a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3ZM15 20.5V16h-2.2l2-6.2A1.2 1.2 0 0 1 16 9h1a1.2 1.2 0 0 1 1.2.8l2 6.2H18v4.5',
    stairs: 'M3.5 19.5h4.5v-4h4v-4h4v-4h4.5',
    elevator: 'M5.5 3.5h13v17h-13ZM9.5 9.5 12 7l2.5 2.5M9.5 14.5 12 17l2.5-2.5',
    access: 'M10.5 5.5a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3ZM10.5 7.5V13h5l2.5 5.5M10.5 10h4.5M8 10.6a5.2 5.2 0 1 0 7.6 6.6'
  };
  const ICON_WORD = { women: 'Women', men: 'Men', family: 'Family restroom', unknown: 'Restroom', stairs: 'Stairs', elevator: 'Elevator' };

  /* ================================================================ the layer on the map */

  // inner: the viewer's insides (M.viewer(...).extend). P: the build. o:
  //   nameOf(code) → the place's name without its building ("Henry West Room 143")
  //   shortOf(B) → the building's short name ("Barnes"); keyOnly(doorId), stepFree(doorId), openOf(doorId)
  //   onMark(kind, data) (a door or an icon tapped), onRoom(code) (a Conference room tapped)
  //   onFloor(code, n) (the floor shown changed; null, null when a building closes), onEscape(), caption (a laptop's floor caption)
  //   plates (a phone): a tap on a room's name or plate, grown to 44 × 44, is onRoom(code)
  //   wholePlate: false (a phone): a whole building chosen gets no name plate on its floor (its sheet names it)
  //   covers() → elements floating over the map (labels keep off them); onMissing() (a floor didn't come, or came back)
  function layer(inner, P, o) {
    o = o || {};
    const { svg, root, c, hooks } = inner;
    const G = k => svg.querySelector('.pv-' + k);
    const fls = G('fls'), marks = G('marks');
    root.classList.add('has-floors');
    hooks.motion = true;
    // Zoomed in to 24 px a metre at most, and out to the Conference's buildings fitted, times 0.8 (§3.4).
    hooks.limits = EXT => {
      const s = inner.size(), minW = s.W / 24;
      const maxW = EXT ? s.W * Math.max(EXT.w / s.W, EXT.h / s.H) / .8 : Math.max(c.bounds.w, c.bounds.h) * 1.4;
      return { minW, maxW: Math.max(maxW, minW * 2) };
    };
    // Each building's outline on the campus (its parts: Luckey Arena is drawn beside the Rec Center).
    P.list.forEach(B => {
      B.items = c.items.filter(i => BUILT[i.kind] && i.pts.length > 2 && (M.norm(i.name) === M.norm(B.name) || (i.code && (i.code.toUpperCase() === B.code || i.code.toUpperCase().indexOf(B.code + '/') === 0))));
      B.item = B.items.find(i => i.lab) || B.items[0] || null;
      B.names = Array.from(new Set(B.items.map(i => i.name)));
      const xs = [].concat.apply([], B.items.map(i => i.pts.map(p => p[0]))), ys = [].concat.apply([], B.items.map(i => i.pts.map(p => p[1])));
      B.box = xs.length ? { x: Math.min.apply(null, xs), y: Math.min.apply(null, ys), w: Math.max.apply(null, xs) - Math.min.apply(null, xs), h: Math.max.apply(null, ys) - Math.min.apply(null, ys) } : null;
      B.short = o.shortOf ? o.shortOf(B) : B.name;
    });
    // route: the planner's route (its doors, pills and floors); prefer: a building asked to open (a step,
    // Set start); pick: Set start's one tap on the opened floor.
    const S = { dest: null, line: null, ring: null, shown: {}, key: '#', open: null, band: '', hidden: [], gen: 0, picked: null, home: 0, route: null, prefer: null, pick: null };
    // A floor that didn't come (or came back): drawn again, and the app told (it shows the place as a campus
    // with no plans would, its building tan, until the floor is here).
    P.onChange = () => { S.key = '#'; inner.draw(); if (o.onMissing) o.onMissing(); };
    const sOf = () => 1 / inner.px();

    // ---- which building opens (§3.5)
    // The visible map's middle: not under the search bar, the sheet, the panel or the picker.
    function middle() {
      const s = inner.size(), t = inner.inset(), r = s.r;
      const x = r.left + ((t.left || 0) + s.W - (t.right || 0)) / 2, y = r.top + (t.top + s.H - t.bottom) / 2;
      return inner.toWorld(x, y);
    }
    function focusAt(s) {
      const m = middle();
      let best = null, bd = Infinity;
      P.list.forEach(B => {
        if (!B.ok || !B.items.length) return;
        B.items.forEach(i => { const d = M.inPoly(m.x, m.y, i.pts) ? 0 : edge(m.x, m.y, i.pts) * s; if (d < bd) { bd = d; best = B; } });
      });
      return bd <= 60 ? best : null;
    }
    function edge(x, y, pts) { let d = Infinity; for (let i = 0; i < pts.length; i++) { const a = pts[i], b = pts[(i + 1) % pts.length], dx = b[0] - a[0], dy = b[1] - a[1], l = dx * dx + dy * dy, t = l ? Math.max(0, Math.min(1, ((x - a[0]) * dx + (y - a[1]) * dy) / l)) : 0; d = Math.min(d, Math.hypot(x - a[0] - t * dx, y - a[1] - t * dy)); } return d; }
    // Any of a building in the visible map (not under the search bar, the sheet, the panel or the picker).
    function shows(B) {
      if (!B.box) return false;
      const s = inner.size(), t = inner.inset(), r = s.r;
      const a = inner.toWorld(r.left + (t.left || 0), r.top + t.top), b = inner.toWorld(r.left + s.W - (t.right || 0), r.top + s.H - t.bottom);
      return B.box.x < b.x && B.box.x + B.box.w > a.x && B.box.y < b.y && B.box.y + B.box.h > a.y;
    }
    // Its floor and its entrance floor both came (or are coming): a floor that didn't come never opens,
    // and the app shows the place as a campus with no plans would (its building tan).
    const can = (B, n) => !P.missing(B.code, n) && !P.missing(B.code, B.entrance);
    // Walking (S.walk, the app's walk()): only the building the route goes into next has its whole floor
    // and the picker; the destination's is its simple floor, any other its outline (round 2: the Chapel's
    // J / 2 / 1 showed on the way to Barnes).
    function want(s) {
      const w = wantFree(s);
      if (!S.walk || !w || w.mode !== 'full' || w.B.code === S.walk.full) return w;
      if (S.dest && S.dest.code === w.B.code) return Object.assign({}, w, { mode: 'simple' });
      return can(w.B, w.B.entrance) ? { B: w.B, floor: w.B.entrance, mode: 'hint' } : null;
    }
    function wantFree(s) {
      const f = focusAt(s), cur = S.open && P.by[S.open.code];
      // A building asked for (a step on a laptop, Set start) comes before the destination's.
      const pick = code => code && P.by[code] && P.by[code].ok ? P.by[code] : null;
      const D = pick(S.prefer) || pick(S.dest && S.dest.code);
      // The destination's building stays open while any of it shows (§3.2 layer 9, §4.3): the sheet pulled
      // down to peek, or a small pan, never closes it for the building now in the middle.
      // (Off screen altogether, walking in from the town, the destination isn't open: no picker for a
      // building you can't see; one asked for still opens.)
      let B = null;
      if (D && (shows(D) || (!f && D === pick(S.prefer)))) B = D;
      else if (f && (s >= 2 || (cur === f && S.open.mode === 'full' && s >= 1.6 && !S.home))) B = f;
      if (B) {
        const floor = S.shown[B.code] || B.entrance;
        if (!can(B, floor)) return null;
        // After Home (the campus fitted), the destination's building is its simple floor until you zoom in.
        return { B, floor, mode: s >= 2 || (s >= 1.2 && !S.home) ? 'full' : 'simple' };
      }
      if (f && s >= 1.2 && can(f, f.entrance)) return { B: f, floor: f.entrance, mode: 'hint' };
      return null;
    }

    // ---- drawing the floor (layer 8, 9, 10)
    const wholeDest = B => !!(S.dest && S.dest.code === B.code && !(S.dest.rooms || []).length);
    const destRooms = (B, n) => S.dest && S.dest.code === B.code ? (S.dest.rooms || []).filter(r => +r.floor === +n).map(r => String(r.number)) : [];
    function floorSvg(w, f, g0) {
      const B = w.B, n = w.floor;
      if (w.mode === 'hint') return '<path class="pv-fl__hint" d="' + f._walls + '"/>';
      return floorBody(f, { mode: w.mode, dest: destRooms(B, n), whole: wholeDest(B), g0 }) + lineSvg(B, n);
    }
    // The door-to-room line: on the floor shown, a 3 px tan-ink line on a white casing; on another floor,
    // tan-ink dots (§3.2 layer 10).
    function lineSvg(B, n) {
      const L = S.line;
      // With a route shown, the map draws the route itself (viewer.route), not the door line.
      if (!L || S.route || !S.dest || S.dest.code !== B.code) return '';
      const d = pts => 'M' + pts.map(p => p[0].toFixed(2) + ' ' + p[1].toFixed(2)).join('L');
      return L.parts.map(p => p.pts.length < 2 ? '' : +p.floor === +n
        ? '<path class="pv-fl__case" d="' + d(p.pts) + '"/><path class="pv-fl__line" d="' + d(p.pts) + '"/>'
        : '<path class="pv-fl__dots" d="' + d(p.pts) + '"/>').join('');
    }

    // ---- marks (layer 11–12): screen-sized, scaled by the viewer each frame
    const mk = (cls, x, y, p, inside, extra) => '<g class="pv-mark ' + cls + '" data-x="' + x.toFixed(2) + '" data-y="' + y.toFixed(2) + '" data-p="' + p + '"' + (extra || '') + '>' + inside + '</g>';
    const textW = (t, px, weight) => measure(t, px, weight, getComputedStyle(root).fontFamily);
    // A door: the architect's entry mark, a solid triangle on the wall pointing in; a checked step-free door,
    // the accessible icon in a white chip; the line's door, bigger, with its name (§3.6).
    function doorMark(B, e, route) {
      const mid = B.middle || (B.box ? [B.box.x + B.box.w / 2, B.box.y + B.box.h / 2] : e.at), a = Math.atan2(mid[1] - e.at[1], mid[0] - e.at[0]) * 180 / Math.PI;
      const sf = o.stepFree && o.stepFree(e.door);
      const sc = route ? 11 / 7 : 1;
      let inner_ = '<circle class="pv-hit" r="22"/>' + (sf ? '<circle class="pv-chip__bg" r="10"/>' + icon('access', 14) : entMark(a, sc));
      if (route && e.name) {
        // Its name on the outside, away from the building; when the line comes in from that side, along
        // the wall on the side the line isn't (the name never sits over the line).
        let ox = -Math.cos(a * Math.PI / 180), oy = -Math.sin(a * Math.PI / 180);
        const vs = S.route && S.route.appr && S.route.appr[e.code + ':' + e.number];
        const anchor = dx => Math.abs(dx) > .35 ? (dx > 0 ? 'start' : 'end') : 'middle';
        if (vs) {
          // The eight ways out of the wall, nearest the outward one first: the first whose name (13 px
          // text, measured) stays 8 px clear of the line's first 80 px each way from the door (outside
          // and in), else the clearest.
          const w = textW(doorWord(e), 13), out = [];
          for (let k = 0; k < 8; k++) { const t = k * Math.PI / 4, dx = Math.cos(t), dy = Math.sin(t); if (dx * ox + dy * oy >= -.1) out.push([dx, dy]); }
          out.sort((p, q) => (q[0] * ox + q[1] * oy) - (p[0] * ox + p[1] * oy));
          const clear = ([dx, dy]) => {
            const ax = dx * 15, ay = dy * 15, an = anchor(dx), x0 = an === 'start' ? ax : an === 'end' ? ax - w : ax - w / 2, b = [x0, ay - 9, x0 + w, ay + 9];
            let m = Infinity;
            vs.forEach(v => { for (let t = 6; t <= 80; t += 6) { const px = v[0] * t, py = v[1] * t; m = Math.min(m, Math.hypot(Math.max(b[0] - px, 0, px - b[2]), Math.max(b[1] - py, 0, py - b[3]))); } });
            return m;
          };
          const pick = out.find(c => clear(c) >= 8) || out.slice().sort((p, q) => clear(q) - clear(p))[0];
          if (pick) { ox = pick[0]; oy = pick[1]; }
        }
        const side = anchor(ox);
        inner_ += '<text class="pv-door__t" x="' + (ox * 15).toFixed(1) + '" y="' + (oy * 15).toFixed(1) + '" style="text-anchor:' + side + '"' + (vs ? ' data-v="' + vs.map(v => v[0].toFixed(3) + ',' + v[1].toFixed(3)).join(';') + '"' : '') + '>' + esc(doorWord(e)) + '</text>';
      }
      return mk('pv-door2' + (route ? ' is-route' : '') + (sf ? ' is-sf' : ''), e.at[0], e.at[1], route ? 3 : 6, inner_, ' data-mk="ent:' + esc(B.code) + ':' + esc(e.number) + '"');
    }
    // "North doors, east" is the build's name; a name the COA gave the door (campus.csv's label) wins.
    const doorWord = e => (o.labelOf && o.labelOf(e.door)) || e.name || 'Entrance';
    // The floor-change pill (§3.6): a white pill, 26 px, a 1.5 px tan-ink ring, the stairs or elevator icon
    // and the other floor's numeral ("▲ 2"); its 44 px tap shows that floor. Placed before the route's doors
    // (2, not 3), so a door's name moves to a clear side of it, never under it (round 2: "No▲2doors").
    // rung (round 3's fix pass): the walk's floor change rung here: the tan-ink ring round the pill itself.
    function pillMark(B, q, n, rung) {
      const to = +q.from === +n ? +q.to : +q.from, word = (to > +n ? '▲ ' : '▼ ') + (to < 1 ? 'L' : String(to));
      const tw = textW(word, 12), w = 8 + 14 + 5 + tw + 10;
      return mk('pv-pill' + (rung ? ' is-rung' : ''), q.at[0], q.at[1], 2, '<circle class="pv-hit" r="22"/>' +
        (rung ? '<rect class="pv-pill__ring" x="' + (-w / 2 - 6).toFixed(1) + '" y="-19" width="' + (w + 12).toFixed(1) + '" height="38" rx="19"/>' : '') +
        '<rect x="' + (-w / 2).toFixed(1) + '" y="-13" width="' + w.toFixed(1) + '" height="26" rx="13"/>' +
        '<g transform="translate(' + (-w / 2 + 8 + 7).toFixed(1) + ' 0)">' + icon(q.lift ? 'elevator' : 'stairs', 14) + '</g><text x="' + (-w / 2 + 8 + 14 + 5).toFixed(1) + '" y="1">' + esc(word) + '</text>',
        ' data-mk="pill:' + esc(B.code) + ':' + to + '" aria-label="' + esc(M.floorName(to)) + '"');
    }
    function chip(B, n, kind, x, num, word) {
      return mk('pv-chip', x.at[0], x.at[1], 6, '<circle class="pv-hit" r="22"/><circle class="pv-chip__bg" r="11"/>' + icon(kind, 16) + '<text class="pv-chip__w" x="16" y="4">' + esc(word) + '</text>',
        ' data-mk="feat:' + esc(B.code) + ':' + n + ':' + kind + ':' + esc(num) + '"');
    }
    // A Conference room's name (up to two lines, inside it) or, when the name doesn't fit, its code plate.
    function roomMark(B, n, x, code) {
      const r = x.r, at = r.box ? [r.box[0], r.box[1]] : r.at;
      if (!at) return '';
      const first = (P.places[code] || { rooms: [] }).rooms[0];
      const name = first && +first.floor === +n && String(first.number) === String(r.number) ? (o.nameOf ? o.nameOf(code) : code) : titleCase(r.name);
      // The code after the slash ("HW"); a place that is a whole room under its building's code (the Chapel's
      // auditorium and balcony, J) shows that code, never IWU's number (120 and 220 meant nothing to anyone).
      const tag = code.indexOf('/') > -1 ? code.split('/')[1] : code;
      // Two lines at the space nearest the middle.
      const words = name.split(' ');
      let lines = [name];
      if (words.length > 1) { let best = null; for (let i = 1; i < words.length; i++) { const a = words.slice(0, i).join(' '), b = words.slice(i).join(' '), m = Math.max(textW(a, 14), textW(b, 14)); if (!best || m < best[2]) best = [a, b, m]; } lines = [name, best[0], best[1]]; }
      // Its number under its name in the Detail band, unless the name already says it.
      const numT = y => new RegExp('(^|\\D)' + String(r.number).replace(/[^\w]/g, '') + '(\\D|$)').test(name) ? '' : '<text class="pv-room__n" y="' + y + '">' + esc(r.number) + '</text>';
      const w1 = textW(name, 14), w2 = lines.length > 1 ? Math.max(textW(lines[1], 14), textW(lines[2], 14)) : w1, tw = textW(tag, 12), pw = Math.max(20, tw + 12);
      return mk('pv-room', at[0], at[1], 5,
        '<g class="pv-room__one"><text y="1">' + esc(name) + '</text>' + numT(17) + '</g>' +
        (lines.length > 1 ? '<g class="pv-room__two"><text y="-7">' + esc(lines[1]) + '</text><text y="10">' + esc(lines[2]) + '</text>' + numT(26) + '</g>' : '') +
        '<g class="pv-room__plate"><rect x="' + (-pw / 2).toFixed(1) + '" y="-10" width="' + pw.toFixed(1) + '" height="20" rx="5"/><text y="1">' + esc(tag) + '</text></g>',
        ' data-rmk="' + esc(code) + '" data-w1="' + w1.toFixed(1) + '" data-w2="' + w2.toFixed(1) + '" data-bw="' + (r.box ? r.box[2] : 0) + '" data-bh="' + (r.box ? r.box[3] : 0) + '" data-nw="' + textW(String(r.number), 12, 400).toFixed(1) + '"' +
        ' data-a="' + (r.box ? r.box[2] * r.box[3] : 0).toFixed(0) + '" data-tw="' + pw.toFixed(1) + '" data-ox="' + at[0].toFixed(2) + '" data-oy="' + at[1].toFixed(2) + '"');
    }
    // The destination's name plate, above the tan shape, with its tail (§3.3); below it when the line's door
    // comes in from above, so the plate never covers the door.
    // The top of a floor's outline straight above or below x (where a whole building's plate points).
    function topAt(f, x) {
      let y = Infinity;
      (f.outline || []).forEach(r => { for (let i = 0; i + 1 < r.length; i += 2) { const j = (i + 2) % r.length, x0 = r[i], x1 = r[j]; if ((x0 <= x) !== (x1 <= x)) y = Math.min(y, r[i + 1] + (r[j + 1] - r[i + 1]) * (x - x0) / (x1 - x0)); } });
      return y < Infinity ? y : f._box.y;
    }
    function plateMark(x, y, name, below, box) {
      const w = textW(name, 15) + 16;
      const room = box ? ' data-room="' + [box.x, box.y, box.x + box.w, box.y + box.h].map(n => n.toFixed(2)).join(',') + '" data-o="' + x.toFixed(2) + ',' + y.toFixed(2) + '" data-pw="' + w.toFixed(1) + '"' + (below ? ' data-below="1"' : '') : '';
      return mk('pv-plate', x, y, 1, plateIn(name, below, w), room);
    }
    function marksSvg(w, f) {
      const B = w.B, n = w.floor;
      let h = '';
      const full = w.mode === 'full';
      // Doors: on every planned building from the Building band, on the floor that has them. The route's
      // doors (or, with no route, the door line's) are the big ones, named.
      const big = S.route ? S.route.doors : S.line && S.line.door && S.dest ? [S.line.door] : [];
      P.list.forEach(b => {
        const open = S.open && S.open.code === b.code && w.mode !== 'hint' ? S.open.floor : b.entrance;
        P.entrances.filter(e => e.code === b.code && +e.floor === +open).forEach(e => { if (big.indexOf(e) < 0) h += doorMark(b, e, false); });
      });
      // (Only on its own floor: with the balcony's 2nd floor open, the 1st floor's East doors were drawn over
      // the 2nd floor's walls; r2c, last round.)
      big.forEach(e => { const b = P.by[e.code]; if (b && !(w.mode !== 'hint' && b.code === B.code && +e.floor !== +n)) h += doorMark(b, e, true); });
      // Where the route changes floor, on the floor shown at either end of it: a pill to the other floor.
      // (The walk's floor change rung on this floor, round 3's fix pass; the check: the ring, the pill and
      // the stairs' own mark were one clump, the ▲ under the mark. The ring goes round the pill, and the
      // stairs or elevator mark it stands on is left off, so one mark says "stairs, to the 2nd floor".)
      const pills = S.route && f && w.mode !== 'hint' ? S.route.pills.filter(q => q.code === B.code && (+q.from === +n || +q.to === +n)) : [];
      const sr = S.ring && S.ring.pill && S.ring.code === B.code && +S.ring.floor === +n ? S.ring : null;
      const dist = (a, b) => Math.hypot(a[0] - b[0], a[1] - b[1]);
      const rungQ = sr ? pills.filter(q => dist(q.at, sr.at) <= 12).sort((a, b) => dist(a.at, sr.at) - dist(b.at, sr.at))[0] || null : null;
      const underPill = x => !!(rungQ && x.at && (dist(x.at, rungQ.at) <= 5 || dist(x.at, sr.at) <= 5));
      pills.forEach(q => { h += pillMark(B, q, n, q === rungQ); });
      // The door line (no route) the same way: where it leaves the door's floor and where it arrives on the
      // room's, the elevator or stairs pill to the other floor, so a floor without the door says where you
      // come up (the balcony: "Elevator ▼ 1", not the 1st floor's door; r2c, last round).
      if (!S.route && S.line && S.dest && S.dest.code === B.code && f && w.mode !== 'hint') {
        const ps = S.line.parts.filter(p => p.pts.length);
        for (let i = 0; i + 1 < ps.length; i++) {
          if (+ps[i].floor === +ps[i + 1].floor) continue;
          const q = { from: +ps[i].floor, to: +ps[i + 1].floor, lift: S.line.change !== 'stairs' };
          if (+ps[i].floor === +n) h += pillMark(B, Object.assign({ at: ps[i].pts[ps[i].pts.length - 1] }, q), n);
          if (+ps[i + 1].floor === +n) h += pillMark(B, Object.assign({ at: ps[i + 1].pts[0] }, q), n);
        }
      }
      if (f && full) {
        (f.restrooms || []).forEach(x => { if (x.at) h += chip(B, n, x.who && ICON[x.who] ? x.who : 'unknown', x, x.number, WHO[x.who] || 'Restroom'); });
        (f.stairs || []).forEach(x => { if (x.at && !underPill(x)) h += chip(B, n, 'stairs', x, x.number, 'Stairs'); });
        (f.elevators || []).forEach(x => { if (x.at && !underPill(x)) h += chip(B, n, 'elevator', x, x.number, 'Elevator'); });
        const dest = destRooms(B, n);
        f._rooms.forEach(x => { const code = x.r.public && x.r.codes && x.r.codes[0]; if (code && dest.indexOf(String(x.r.number)) < 0) h += roomMark(B, n, x, code); });
        // The laptop's caption: BARNES · 1ST FLOOR, outside the building's south-west corner.
        if (o.caption && f._box) { const cw = (B.short + ' · ' + M.floorName(n)).toUpperCase(), tw = textW(cw, 12) + 1.2 * cw.length; h += mk('pv-cap', f._box.x, f._box.y + f._box.h + 6, 4, (o.caption === 'pin' ? '<rect class="pv-cap__tab" x="-8" y="-6" width="' + (tw + 16).toFixed(1) + '" height="32" rx="4"/>' : '') + capIn(cw, tw)); }
      }
      // The destination: the room's name plate; a whole building's, its short name over its top.
      if (S.dest && S.dest.code === B.code && w.mode !== 'hint') {
        const dr = destRooms(B, n);
        const x = f && dr.length ? f._by[dr[0]] : null;
        if (x) {
          const rd = S.route && S.route.doors.find(e => e.code === B.code);
          const door = rd ? rd.at : S.line && S.line.door ? S.line.door.at : null;
          const below = !!(x.box && door && door[1] < x.box.y + x.box.h / 2);
          const top = x.box ? [x.box.x + x.box.w / 2, below ? x.box.y + x.box.h : x.box.y] : x.r.at;
          const first = (S.dest.rooms || [])[0];
          // (A room asked for by IWU's name, the Chapel's Balcony, is that name: d.name.)
          const name = first && String(first.number) === String(x.r.number) && +first.floor === +n ? (S.dest.name || (o.nameOf ? o.nameOf(S.dest.place || S.dest.code) : S.dest.code)) : titleCase(x.r.name);
          if (top) h += plateMark(top[0], top[1], name, below, x.box);
          if (!x.box && x.r.at) h += mk('pv-dot', x.r.at[0], x.r.at[1], 2, '<circle r="6"/>');
        }
        // A whole building: its name plate over the top of its floor (it slides along inside it, as a room's does).
        // (Not on a phone's Places, docs/35 §2.4: its sheet already names it; o.wholePlate false.)
        if (wholeDest(B) && f && f._box && o.wholePlate !== false) { const cx = f._box.x + f._box.w / 2; h += plateMark(cx, topAt(f, cx), B.short, false, f._box); }
      }
      if (S.ring && S.ring.code === B.code && +S.ring.floor === +n && !rungQ) h += mk('pv-ring', S.ring.at[0], S.ring.at[1], 2, '<circle r="17"/>');
      return h;
    }

    // ---- drawing, when what's wanted changes
    function hideRoofs(B) {
      S.hidden.forEach(e => { e.style.display = ''; });
      S.hidden = [];
      if (!B) return;
      B.names.forEach(n => svg.querySelectorAll('.pv-shapes [data-b="' + CSS.escape(n) + '"]').forEach(e => { e.style.display = 'none'; S.hidden.push(e); }));
      const sel = G('sel'); if (S.picked && B.names.indexOf(S.picked) > -1) { sel.style.display = 'none'; S.hidden.push(sel); }
    }
    let roofT = 0;
    function render(w, force) {
      const key = w ? w.mode + '|' + w.B.code + '|' + w.floor + '|' + (S.dest ? S.dest.code + (S.dest.rooms || []).map(r => r.floor + ':' + r.number).join(',') : '') + '|' + (S.line ? 1 : 0) + '|' + (S.ring ? S.ring.at.join(',') : '') + '|' + (S.route ? S.route.key : '') : (S.route ? 'r|' + S.route.key : '');
      if (key === S.key && !force) return;
      const f = w ? P.got(w.B.code, w.floor) : null, g0 = w ? P.got(w.B.code, w.B.entrance) : null;
      // Not here yet: what's drawn stays until it comes (one fetch, kept for the guide offline).
      // Asked once; when it doesn't come, want() stops asking for it (P.missing) until it may again.
      if (w && (!f || !g0)) {
        if (S.key === key + '|wait') return;
        S.key = key + '|wait';
        Promise.all([P.floor(w.B.code, w.floor), P.floor(w.B.code, w.B.entrance)]).then(() => { if (S.key === key + '|wait') { S.key = '#'; inner.draw(); } });
        return;
      }
      const was = S.open, isOpen = !!(w && f && w.mode !== 'hint');
      const changed = !was !== !isOpen || (was && isOpen && (was.code !== w.B.code || was.floor !== w.floor));
      const up = was && isOpen && was.code === w.B.code ? Math.sign(w.floor - was.floor) : 0;
      S.key = key;
      const gen = ++S.gen;
      // Out: the old floor fades as the roof comes back (200 ms); in: the new one fades in. Changing floor
      // (§4.9): going up, the old floor drops 8 px as it fades and the new one comes down from 8 px above;
      // going down, the other way. (Its own way in stops first, so it can fade: it held it before.)
      Array.from(fls.children).forEach(old => {
        if (!changed || reduced()) { old.remove(); return; }
        old.classList.remove('is-in');
        if (up) old.style.setProperty('--pv-out', (8 * up * inner.px()).toFixed(3) + 'px');
        old.classList.add('is-out'); old.removeAttribute('data-b'); setTimeout(() => old.remove(), 220);
      });
      if (w && f) {
        const g = document.createElementNS('http://www.w3.org/2000/svg', 'g');
        g.setAttribute('class', 'pv-fl is-' + w.mode + (changed && !reduced() ? ' is-in' : ''));
        if (w.mode !== 'hint') g.setAttribute('data-b', w.B.item ? w.B.item.name : w.B.name);
        if (up) g.style.setProperty('--pv-up', (-8 * up * inner.px()).toFixed(3) + 'px');
        g.innerHTML = floorSvg(w, f, g0);
        fls.appendChild(g);
      }
      S.open = isOpen ? { code: w.B.code, floor: w.floor, mode: w.mode } : null;
      // The roof lifts away once the floor is over it; closing, it's back at once.
      clearTimeout(roofT);
      if (isOpen) { if (changed && was && was.code === w.B.code) hideRoofs(w.B); else if (changed && !reduced()) roofT = setTimeout(() => { if (S.gen === gen) hideRoofs(w.B); }, 200); else hideRoofs(w.B); }
      else hideRoofs(null);
      const hb = (S.dest && P.by[S.dest.code]) || P.list[0];
      marks.innerHTML = w ? marksSvg(w, f) : ((S.line && S.dest) || (S.route && hb)) ? marksSvg({ B: hb, floor: S.shown[hb.code] || hb.entrance, mode: 'hint' }, null) : allDoors();
      // The picker with the whole floor only (a simple floor at campus zoom is an outline and the tan room).
      picker(isOpen && w.mode === 'full' ? w : null);
      const lab = isOpen ? 'Campus map · ' + w.B.short + ' ' + M.floorName(w.floor) : 'Campus map';
      if (root.getAttribute('aria-label') !== lab) root.setAttribute('aria-label', lab);
      const cr = root.querySelector('.pv-credit');
      if (cr) cr.textContent = M.CREDIT + (isOpen ? ' · ' + P.credit : '');
      // (Closing a building says so too: null, null.)
      if (changed && o.onFloor) o.onFloor(isOpen ? w.B.code : null, isOpen ? w.floor : null);
      inner.draw();
    }
    const allDoors = () => P.list.map(b => P.entrances.filter(e => e.code === b.code && +e.floor === +b.entrance).map(e => doorMark(b, e, false)).join('')).join('');

    // ---- the floor picker (§4.4)
    let pk = null;
    function picker(w) {
      if (!w) { if (pk) { pk.remove(); pk = null; } root.classList.remove('has-picker'); return; }
      const B = w.B, list = B.floors.slice().reverse();
      if (!pk || pk.dataset.code !== B.code) {
        if (pk) pk.remove();
        pk = document.createElement('div');
        pk.className = 'pv-floors'; pk.dataset.code = B.code;
        pk.setAttribute('role', 'radiogroup'); pk.setAttribute('aria-label', B.short + ' floors');
        pk.innerHTML = '<p class="pv-floors__h" aria-hidden="true">' + esc(B.code) + '</p><div class="pv-floors__l"><span class="pv-floors__w" aria-hidden="true"></span>' +
          list.map(n => '<button type="button" role="radio" data-fl="' + n + '" aria-label="' + esc(M.floorName(n)) + '" title="' + esc(M.floorName(n)) + '">' + (n < 1 ? 'L' : n) + '<i aria-hidden="true"></i></button>').join('') + '</div>';
        pk.addEventListener('click', e => { const b = e.target.closest('[data-fl]'); if (b) show(+b.dataset.fl, true); });
        pk.addEventListener('keydown', e => {
          const i = list.indexOf(S.open ? S.open.floor : -1);
          const j = e.key === 'ArrowUp' || e.key === 'ArrowLeft' ? i - 1 : e.key === 'ArrowDown' || e.key === 'ArrowRight' ? i + 1 : -2;
          if (j === -2 || j < 0 || j >= list.length) return;
          e.preventDefault(); show(list[j], true); const nb = pk.querySelector('[data-fl="' + list[j] + '"]'); if (nb) nb.focus();
        });
        root.appendChild(pk);
        root.classList.add('has-picker');
        pk.querySelector('.pv-floors__w').style.transition = 'none';
      }
      // A dot on each other floor the destination or the route (or, with no route, the door line) uses.
      const dest = (S.dest && S.dest.code === B.code ? (S.dest.rooms || []).map(r => +r.floor).concat(S.line && !S.route ? S.line.parts.map(p => +p.floor) : []) : [])
        .concat(S.route && S.route.floors[B.code] ? S.route.floors[B.code] : []);
      pk.querySelectorAll('[data-fl]').forEach((b, i) => {
        const n = +b.dataset.fl, on = n === w.floor;
        b.setAttribute('aria-checked', String(on)); b.tabIndex = on ? 0 : -1;
        b.classList.toggle('is-on', on);
        b.querySelector('i').hidden = on || dest.indexOf(n) < 0;
        if (on) { const wsh = pk.querySelector('.pv-floors__w'); wsh.style.transform = 'translateY(' + (i * 44) + 'px)'; requestAnimationFrame(() => { wsh.style.transition = ''; }); }
      });
    }
    // A floor shown (the picker, PageUp and PageDown, a Nearby row on another floor).
    function show(n, say) {
      const code = S.open ? S.open.code : S.dest ? S.dest.code : null, B = code && P.by[code];
      if (!B || B.floors.indexOf(+n) < 0) return;
      S.shown[code] = +n;
      render(want(sOf()));
      if (say) liveSay(M.floorName(n));
    }
    function liveSay(t) { const l = root.querySelector('[data-live]'); if (l) { l.textContent = ''; requestAnimationFrame(() => { l.textContent = t; }); } }

    // ---- each frame: what's wanted, and the bands
    let bandSet = '';
    hooks.paint.push(k => {
      const s = 1 / k;
      // (A shadow on the map is in map units: kept at 2 px on screen.)
      fls.style.setProperty('--pv-k', k.toFixed(4));
      render(want(s));
      // The open building's own name gives way to its rooms' (its code is on the picker); a simple floor
      // keeps it, as a closed building would.
      if (S.open && S.open.mode === 'full') { const B = P.by[S.open.code]; inner.labs().forEach(t => { if (B.names.indexOf(t.dataset.n) > -1) t.style.display = 'none'; }); }
      // Home's campus view lasts until you zoom in again (past its own move).
      if (S.home && s >= 2 && performance.now() > S.home) S.home = 0;
      fls.classList.toggle('z-d', s >= 8);
      const band = (s >= 1.2 ? 'b' : '') + (s >= 1.6 ? 'r' : '') + (s >= 2 ? 'f' : '') + (s >= 3 ? 'c' : '') + (s >= 8 ? 'd' : '');
      if (band !== bandSet) { bandSet = band; marks.setAttribute('class', 'pv-marks z-' + (band.split('').join(' z-') || 'campus')); }
    });
    // Before the buildings' names: the destination's plate, the ring and the line's door (they always show).
    const place = (g, k) => g.setAttribute('transform', 'translate(' + g.dataset.x + ' ' + g.dataset.y + ') scale(' + k.toFixed(4) + ')');
    const boxOfMark = (g, k) => { let b; try { b = g.getBBox(); } catch (e) { return null; } if (!b.width) return null; const x = +g.dataset.x, y = +g.dataset.y; return { x0: x + b.x * k, y0: y + b.y * k, x1: x + (b.x + b.width) * k, y1: y + (b.y + b.height) * k }; };
    const inView = (b, v, k) => b.x0 >= v.x0 + 8 * k && b.x1 <= v.x1 - 8 * k && b.y0 >= v.y0 + 8 * k && b.y1 <= v.y1 - 8 * k;
    const hitsAny = (b, placed, pad) => placed.some(p => !p.floor && b.x0 - pad < p.x1 && b.x1 + pad > p.x0 && b.y0 - pad < p.y1 && b.y1 + pad > p.y0);
    // Marks crowd by what's drawn, not by their 44 px tap circles (hidden while measuring, pre to post).
    hooks.pre.push((placed, v) => {
      const k = v.k, pad = 4 * k;
      // What floats over the map from outside it (a laptop's panel) is in every label's way (§3.3): a name
      // that would cross it is dropped, never left half under it.
      (o.covers ? o.covers() : []).forEach(el => { const r = el && el.getBoundingClientRect(); if (!r || !r.width) return; const a = inner.toWorld(r.left, r.top), b = inner.toWorld(r.right, r.bottom); placed.push({ x0: a.x, y0: a.y, x1: b.x, y1: b.y, hard: true }); });
      marks.classList.add('is-measure');
      Array.from(marks.querySelectorAll('.pv-mark')).filter(g => +g.dataset.p <= 4).sort((a, b) => a.dataset.p - b.dataset.p).forEach(g => {
        g.style.visibility = '';
        // Zoomed in past a room's edge, its plate slides along inside the room to stay on screen.
        if (g.dataset.room) {
          const r = g.dataset.room.split(',').map(Number), o0 = g.dataset.o.split(',').map(Number), hw = (+g.dataset.pw / 2 + 8) * k, ph = 41 * k, m = 8 * k;
          let x = Math.min(Math.max(o0[0], Math.max(r[0], v.x0 + m + hw)), Math.min(r[2], v.x1 - m - hw));
          // (2 px further in than the edge it must clear: placed exactly on it, a rounding of 0.005 hid the
          // plate of Barnes 133, the Intramural Gym and PPAC; the check, round 2.)
          let y = o0[1];
          if (g.dataset.below) { if (y + ph > v.y1 - 2 * k) y = Math.max(r[1], v.y1 - ph - 2 * k); }
          else if (y - ph < v.y0 + 2 * k) y = Math.min(r[3], v.y0 + ph + 2 * k);
          if (!(x >= r[0] && x <= r[2])) x = o0[0];
          g.dataset.x = x.toFixed(2); g.dataset.y = y.toFixed(2);
          g.setAttribute('transform', 'translate(' + g.dataset.x + ' ' + g.dataset.y + ') scale(' + k.toFixed(4) + ')');
        }
        // (o.caption 'pin', the place dialog's: framed on the room, a big floor's own corner is off the frame,
        // so its caption sits in the frame's lower-left corner over the credit, on a cream tab, and the opened
        // floor always says which it is, §3.3; r2c fix.)
        if (o.caption === 'pin' && g.classList.contains('pv-cap')) {
          if (!g.dataset.o) g.dataset.o = g.dataset.x + ',' + g.dataset.y;
          const o0 = g.dataset.o.split(',');
          g.dataset.x = o0[0]; g.dataset.y = o0[1]; g.classList.remove('is-pin'); place(g, k);
          const b0 = boxOfMark(g, k);
          if (b0 && (!inView(b0, v, k) || hitsAny(b0, placed, pad))) { g.classList.add('is-pin'); g.dataset.x = (v.x0 + 18 * k).toFixed(2); g.dataset.y = (v.y1 - 58 * k).toFixed(2); place(g, k); }
        }
        // The line's door names itself beside its mark, on whichever side is clear (never under the plate);
        // with no side clear, the mark stays and its name waits.
        const t = g.querySelector('.pv-door__t');
        const put = q => { t.setAttribute('x', q[0]); t.setAttribute('y', q[1]); t.style.textAnchor = q[2]; };
        if (t) { if (!t.dataset.o) t.dataset.o = [t.getAttribute('x'), t.getAttribute('y'), t.style.textAnchor].join('|'); put(t.dataset.o.split('|')); t.style.display = ''; }
        let b = boxOfMark(g, k);
        // (Nor over the route's own line where it meets the door: data-v, the way back along it, Nov 5.)
        const lvs = t && t.dataset.v ? t.dataset.v.split(';').map(s => s.split(',').map(Number)) : null;
        const offLine = () => {
          if (!lvs) return true;
          let tb; try { tb = t.getBBox(); } catch (e) { return true; }
          return lvs.every(lv => { for (let s = 6; s <= 80; s += 6) { const px = lv[0] * s, py = lv[1] * s; if (px > tb.x - 6 && px < tb.x + tb.width + 6 && py > tb.y - 6 && py < tb.y + tb.height + 6) return false; } return true; });
        };
        if (t && b && (hitsAny(b, placed, pad) || !inView(b, v, k))) {
          const tries = [[0, -18, 'middle'], [0, 20, 'middle'], [16, 1, 'start'], [-16, 1, 'end'], [12, -14, 'start'], [-12, -14, 'end'], [12, 16, 'start'], [-12, 16, 'end']];
          let ok = false;
          for (const q of tries) { put(q); b = boxOfMark(g, k); if (b && !hitsAny(b, placed, pad) && inView(b, v, k) && offLine()) { ok = true; break; } }
          if (!ok) { put(t.dataset.o.split('|')); t.style.display = 'none'; b = boxOfMark(g, k); }
        }
        // The laptop's caption is only drawn whole: off the screen or under the panel, it waits. So does the
        // destination's plate when its room is panned off (never half a plate at the edge).
        if (b && g.classList.contains('pv-cap') && (!inView(b, v, k) || hitsAny(b, placed, pad))) { g.style.visibility = 'hidden'; return; }
        if (b && g.dataset.room && !inView(b, v, k)) { g.style.visibility = 'hidden'; return; }
        // The ring keeps every other mark off it, but not the icon it rings (round 2: it circled bare walls).
        if (b && g.classList.contains('pv-ring')) b.ring = [+g.dataset.x, +g.dataset.y];
        if (b) placed.push(b);
      });
      // An open floor is a card the other buildings' names keep off (its own rooms' names are inside it).
      const fl = S.open && S.open.mode === 'full' && P.got(S.open.code, S.open.floor);
      if (fl && fl._box) placed.push({ x0: fl._box.x, y0: fl._box.y, x1: fl._box.x + fl._box.w, y1: fl._box.y + fl._box.h, floor: true });
    });
    // After them: rooms' names or plates, then doors and icons; one that would cross another is left out.
    hooks.post.push((placed, v) => {
      const k = v.k, s = 1 / k, pad = 4 * k, z = bandSet;
      const open = S.open, isDest = open && S.dest && S.dest.code === open.code;
      // The bigger rooms first among the Conference's (where the services and meetings are), so a crowded
      // floor keeps the Globe Theater's plate and slides a small room's along inside it.
      const ms = Array.from(marks.querySelectorAll('.pv-mark')).filter(g => +g.dataset.p > 4).sort((a, b) => a.dataset.p - b.dataset.p || (+b.dataset.a || 0) - (+a.dataset.a || 0));
      ms.forEach(g => {
        let on = true;
        if (g.classList.contains('pv-room')) {
          // A building chosen shows its rooms' names or plates from the Building band (the fit a phone gives
          // Barnes is about 1.4 px a metre); otherwise from the Floor band.
          on = z.indexOf('f') > -1 || (isDest && z.indexOf('b') > -1);
          if (g.dataset.ox) { g.dataset.x = g.dataset.ox; g.dataset.y = g.dataset.oy; place(g, k); }
          if (on) {
            // Its name when it fits inside at 90 %, on one line or two; else its code plate (§3.3).
            const bw = +g.dataset.bw * s * .9, bh = +g.dataset.bh * s, detail = z.indexOf('d') > -1;
            const one = +g.dataset.w1 <= bw && 18 <= bh, two = !one && g.querySelector('.pv-room__two') && +g.dataset.w2 <= bw && 36 <= bh;
            const num = detail && +g.dataset.nw <= bw && (one ? 36 : 52) <= bh;
            g.classList.toggle('is-one', !!one); g.classList.toggle('is-two', !!two); g.classList.toggle('is-plate', !one && !two); g.classList.toggle('has-num', !!num && (one || two));
          }
        } else if (g.classList.contains('pv-chip')) {
          on = z.indexOf('c') > -1;
          g.classList.toggle('has-word', z.indexOf('d') > -1);
        } else if (g.classList.contains('pv-door2')) on = z.indexOf('b') > -1;
        g.style.display = on ? '' : 'none';
        if (!on) return;
        g.style.visibility = '';
        let b = boxOfMark(g, k);
        if (!b) return;
        // The icon a ring is drawn round crowds nothing in it (its word still keeps off the ring).
        const rung = g.classList.contains('pv-chip') ? placed.find(p => p.ring && Math.abs(p.ring[0] - +g.dataset.x) < .05 && Math.abs(p.ring[1] - +g.dataset.y) < .05) : null;
        if (rung) { g.classList.remove('has-word'); b = boxOfMark(g, k); g.style.visibility = ''; placed.push(b); return; }
        // An icon's word goes first if it's what crowds (the icon stays).
        if (g.classList.contains('has-word') && (!inView(b, v, k) || hitsAny(b, placed, pad))) { g.classList.remove('has-word'); b = boxOfMark(g, k); }
        if (g.classList.contains('has-num') && (!inView(b, v, k) || hitsAny(b, placed, pad))) { g.classList.remove('has-num'); b = boxOfMark(g, k); }
        // A code plate that crowds tries the other places inside its own room (its edges, its corners).
        const clear = q => q && inView(q, v, k) && !hitsAny(q, placed, pad);
        if (!clear(b) && g.classList.contains('is-plate') && g.dataset.ox) {
          const ox = +g.dataset.ox, oy = +g.dataset.oy, mx = Math.max(0, +g.dataset.bw / 2 - (+g.dataset.tw / 2 + 3) * k), my = Math.max(0, +g.dataset.bh / 2 - 13 * k);
          const tries = [[0, -my], [0, my], [-mx, 0], [mx, 0], [-mx, -my], [mx, -my], [-mx, my], [mx, my]].filter(q => q[0] || q[1]);
          for (const q of tries) { g.dataset.x = (ox + q[0]).toFixed(2); g.dataset.y = (oy + q[1]).toFixed(2); place(g, k); b = boxOfMark(g, k); if (clear(b)) break; }
          if (!clear(b)) { g.dataset.x = g.dataset.ox; g.dataset.y = g.dataset.oy; place(g, k); b = boxOfMark(g, k); }
        }
        if (!clear(b)) { g.style.visibility = 'hidden'; return; }
        placed.push(b);
      });
      marks.classList.remove('is-measure');
    });

    // ---- taps (§9): a mark, then a Conference room 24 px or more, else zoom in twice around the tap
    hooks.tap = (t, pt, e) => {
      if (!t || !t.closest) return false;
      // Set start (§4.5): one tap inside the opened floor is where you are (only as good as the tap).
      if (S.pick && S.open && S.open.mode === 'full' && pt) {
        const f = P.got(S.open.code, S.open.floor);
        if (f && inShape(pt.x, pt.y, f.outline)) { S.pick({ x: pt.x, y: pt.y, floor: S.open.floor, code: S.open.code }); return true; }
      }
      const m = t.closest('[data-mk]');
      if (m && m.closest('.pv-marks')) {
        const a = m.dataset.mk.split(':');
        // A floor-change pill shows its floor.
        if (a[0] === 'pill') { S.shown[a[1]] = +a[2]; render(want(sOf())); liveSay(M.floorName(+a[2])); return true; }
        if (o.onMark) o.onMark(a[0], a.slice(1)); return true;
      }
      // A room's name or plate on the map opens the room (o.plates, a phone: docs/35 §2.4): each one as
      // drawn, grown to 44 × 44 around its middle; the nearest middle wins.
      if (o.plates && o.onRoom && e && e.clientX != null) {
        let best = null;
        marks.querySelectorAll('.pv-room[data-rmk]').forEach(g => {
          const r = g.getBoundingClientRect();
          if (!r.width || !r.height) return;
          const cx = r.left + r.width / 2, cy = r.top + r.height / 2, hw = Math.max(22, r.width / 2), hh = Math.max(22, r.height / 2);
          if (Math.abs(e.clientX - cx) > hw || Math.abs(e.clientY - cy) > hh) return;
          const d = Math.hypot(e.clientX - cx, e.clientY - cy);
          if (!best || d < best.d) best = { d, code: g.dataset.rmk };
        });
        if (best) { o.onRoom(best.code); return true; }
      }
      const rm = t.closest('[data-rm]');
      if (rm) {
        const r = rm.getBoundingClientRect();
        if (Math.min(r.width, r.height) >= 24) { if (o.onRoom) o.onRoom(rm.dataset.rm); return true; }
        const v = inner.v; inner.goTo({ x: pt.x - (pt.x - v.x) * .5, y: pt.y - (pt.y - v.y) * .5, w: v.w * .5, h: v.h * .5 }, true);
        return true;
      }
      return false;
    };
    // ---- keys (§9): PageUp and PageDown change floor, Home fits the campus, Esc closes the place
    hooks.key = e => {
      if ((e.key === 'PageUp' || e.key === 'PageDown') && S.open) {
        const B = P.by[S.open.code], i = B.floors.indexOf(S.open.floor), j = i + (e.key === 'PageUp' ? 1 : -1);
        if (j >= 0 && j < B.floors.length) show(B.floors[j], true);
        return true;
      }
      // Home: the campus, every building closed (the destination's a simple floor) until you zoom in.
      if (e.key === 'Home') { S.home = performance.now() + 450; S.key = '#'; inner.fit(inner.start(), 8, true); return true; }
      if (e.key === 'Escape' && o.onEscape) { o.onEscape(); return true; }
      return false;
    };

    // ---- what the app asks
    const api = {
      P,
      // A place chosen: its building opens on the room's floor, the room in tan with its plate, and the line
      // from the best door. → { B, room (box), door, line, box (room and door together) } once known.
      dest(d) {
        // (Home's campus view ends when a place is opened, not when one is closed: the check, round 2, saw
        // Barnes come back as a tangle at campus scale after Home, then Esc.)
        S.dest = d && P.by[d.code] ? d : null; S.line = null; S.ring = null; if (S.dest) S.home = 0;
        if (!S.dest) { render(want(sOf()), true); return Promise.resolve(null); }
        const B = P.by[d.code], r0 = (d.rooms || [])[0];
        S.shown[B.code] = r0 ? +r0.floor : B.entrance;
        render(want(sOf()), true);
        // (the door: M.placeDoor's, the one door everywhere; d.stepFree: the asker's No stairs)
        // (wish, never want: want() is the viewer's own, called just below; the night's check saw every
        // place with a room throw "want is not a function" when the door's data hid it)
        return Promise.all([P.floorsOf(B.code), r0 ? P.walk() : null, r0 ? doorWant(P, c, B, +r0.floor, r0.number, !!d.stepFree) : null]).then(([floors, Gr, wish]) => {
          if (S.dest !== d) return null;
          const line = r0 && Gr ? finish(lineTo(Gr, P, B, +r0.floor, r0.number, o.keyOnly, wish), P, B, r0.number) : null;
          S.line = line;
          render(want(sOf()), true);
          const f = P.got(B.code, r0 ? +r0.floor : B.entrance), x = r0 && f ? f._by[String(r0.number)] : null;
          const room = x ? (x.box || (x.r.at ? { x: x.r.at[0] - 3, y: x.r.at[1] - 3, w: 6, h: 6 } : null)) : null;
          let box = room ? Object.assign({}, room) : null;
          // Framed with where the line comes onto the room's floor: the door on its own floor, else where
          // the elevator or stairs arrive (the balcony was framed with the 1st floor's door, its own short
          // line from the elevator barely in view; r2c, last round).
          const on = line ? line.parts.filter(p => +p.floor === +r0.floor && p.pts.length) : [];
          if (box && on.length) box = grow(box, line.door && +line.door.floor === +r0.floor ? line.door.at : on[0].pts[0]);
          return { B, room, door: line ? line.door : null, line, box: box || B.box };
        });
      },
      // Show a floor ("Balcony · 2nd floor").
      show(n) { show(n, true); },
      // The planner's route (a plan from ogc-map-route.js), or null: its doors named, its floor changes as
      // pills, its floors dotted on the picker. The line itself is the map's (viewer.route).
      route(r) {
        if (!r || !r.ok) { if (S.route) { S.route = null; render(want(sOf()), true); } return; }
        const ent = d => d && d.code ? P.entrances.find(e => e.code === d.code && String(e.number) === String(d.number)) || null : null;
        const doors = [ent(r.door), ent(r.exit)].filter((e, i, a) => e && a.indexOf(e) === i);
        const floors = {}, pills = [];
        (r.parts || []).forEach(p => { if (p.building && p.floor) (floors[p.building] = floors[p.building] || []).push(+p.floor); });
        (r.steps || []).forEach(s => { if (s.kind === 'floor' && s.building) { pills.push({ code: s.building, from: +s.floor, to: +s.floorTo, at: s.at, lift: s.icon === 'elevator' }); (floors[s.building] = floors[s.building] || []).push(+s.floorTo); } });
        // Where the line meets each door, outside and in: unit vectors from the door along it (doorMark).
        const appr = {};
        doors.forEach(e => {
          const best = { out: null, in: null };
          (r.parts || []).forEach(p => {
            if (!p.pts || p.pts.length < 2 || (p.building && p.building !== e.code)) return;
            const side = p.building ? 'in' : 'out';
            [[0, 1], [p.pts.length - 1, -1]].forEach(([i, s]) => {
              const q = p.pts[i], d = Math.hypot(q[0] - e.at[0], q[1] - e.at[1]);
              if (d > 4 || (best[side] && d >= best[side].d)) return;
              let j = i + s;
              while (j > 0 && j < p.pts.length - 1 && Math.hypot(p.pts[j][0] - q[0], p.pts[j][1] - q[1]) < 3) j += s;
              const n = p.pts[j], L = Math.hypot(n[0] - e.at[0], n[1] - e.at[1]);
              if (L) best[side] = { d, v: [(n[0] - e.at[0]) / L, (n[1] - e.at[1]) / L] };
            });
          });
          const vs = [best.out, best.in].filter(Boolean).map(b => b.v);
          if (vs.length) appr[e.code + ':' + e.number] = vs;
        });
        S.route = { doors, floors, pills, appr, key: doors.map(e => e.code + e.number).join(',') + '|' + pills.map(q => q.code + q.from + q.to + q.at.join(',')).join(',') + '|' + (r.parts || []).length };
        render(want(sOf()), true);
      },
      // The floor shown of a building (open, whole or simple), or null.
      shown: code => S.open && S.open.code === code ? S.open.floor : null,
      // A building asked to open on a floor (a step framed, Set start), or null to let the map choose again.
      focus(code, n) {
        const B = code && P.by[String(code).toUpperCase()];
        S.prefer = B ? B.code : null;
        if (B && n != null && B.floors.indexOf(+n) > -1) S.shown[B.code] = +n;
        render(want(sOf()), true);
      },
      // Set start: fn({ x, y, floor, code }) on the next tap inside the opened floor, or null to stop.
      pick(fn) { S.pick = fn || null; root.classList.toggle('is-picking', !!fn); },
      // Walking (docs/35 §2.6, round 2): g = { full } is the one building whose whole floor (and so the
      // picker) may show, the one the route goes into next once you're within 60 m of it (the app says
      // which); every other building is its simple floor (the destination) or its outline. null: as ever.
      walk(g) {
        const k = g ? String(g.full || '') : null;
        if ((S.walk ? S.walk.full : null) === k) return;
        S.walk = g ? { full: k } : null;
        render(want(sOf()), true);
      },
      // The stairs or elevator a floor change takes (§2.6): the nearest stairwell or car to at on that
      // floor, within 10 m, as a box in metres; null when the floor hasn't one there.
      // (A stairwell IWU's drawing gives no outline is its point, 2 m across, as a room with no outline is
      // everywhere else (the small map's picture()): round 3. Without it Barnes's T200S, Young's T100W and T100S and others were
      // skipped, and the ring went to the elevator 6.5 m off or to nothing.)
      shaft(code, n, at) {
        const f = at && P.got(String(code || '').toUpperCase(), +n); if (!f) return null;
        let best = null;
        f._rooms.forEach(x => {
          if (x.r.kind !== 'stairs' && x.r.kind !== 'elevator') return;
          const b = x.box || (x.r.at ? { x: x.r.at[0] - 1, y: x.r.at[1] - 1, w: 2, h: 2 } : null);
          if (!b) return;
          const dx = Math.max(b.x - at[0], 0, at[0] - b.x - b.w), dy = Math.max(b.y - at[1], 0, at[1] - b.y - b.h), d = Math.hypot(dx, dy);
          if (d <= 10 && (!best || d < best.d)) best = { d, box: b };
        });
        return best ? Object.assign({}, best.box) : null;
      },
      // A place rung on its floor (a Nearby row, a restroom from the list): its floor shown. ring(null)
      // takes the ring away.
      // (how.pill: the walk's floor change; the ring goes round the route's pill there, pillRung.)
      ring(code, n, at, how) {
        if (code == null) { if (S.ring) { S.ring = null; render(want(sOf()), true); } return; }
        const B = P.by[code]; if (!B || !at) return;
        S.ring = { code, floor: +n, at, pill: !!(how && how.pill) };
        if (S.open && S.open.code === code && S.open.floor !== +n) liveSay(M.floorName(n));
        S.shown[code] = +n;
        render(want(sOf()), true);
      },
      // The nearest restroom and elevator from a room → rows for the sheet, or null.
      nearby(code, n, number) {
        const B = P.by[code];
        if (!B) return Promise.resolve(null);
        // Only with every floor of the building here: measured on the floors that came, "nearest" could be
        // a floor away from the one that's nearer.
        return Promise.all([P.floorsOf(code), P.walk()]).then(([floors, Gr]) => Gr && floors.length === B.floors.length ? nearestFrom(Gr, B, floors, +n, number) : null);
      },
      // Distances along the halls from a room, to any end in its building → fn(code, floor, number) → metres or null.
      from(code, n, number) {
        const B = P.by[code];
        return P.walk().then(Gr => {
          const bi = Gr && B ? Gr.names.indexOf(B.name) : -1, src = bi > -1 ? endsOf(Gr, code, n, number) : null;
          if (!src) return () => null;
          const r = walkFrom(Gr, src, e => e.kind !== 'entrance' && Gr.Bd[e.a] === bi && Gr.Bd[e.b] === bi);
          return (c2, n2, num2) => { if (c2 !== code) return null; let best = null; (endsOf(Gr, c2, n2, num2) || []).forEach(k => { if (r.d[k] < Infinity && (!best || r.d[k] < best.d)) best = { d: r.d[k], m: r.m[k] }; }); return best ? best.m : null; };
        });
      },
      // Every restroom or elevator in the build's buildings (the Restrooms list; Search's Nearest).
      all(kind) {
        return Promise.all(P.list.map(B => P.floorsOf(B.code).then(fs => ({ B, fs })))).then(bs => {
          const out = [];
          bs.forEach(({ B, fs }) => fs.forEach(f => {
            if (kind === 'restroom') (f.restrooms || []).forEach(x => { const rm = f._by[x.number]; if (x.at && x.walk !== false && !(rm && /LOCKER|SHOWER|TEAM|STAFF/i.test(rm.r.name || ''))) out.push({ B, floor: f.floor, number: x.number, who: x.who || 'unknown', at: x.at, word: WHO[x.who] || 'Restroom' }); });
            else (f.elevators || []).forEach(x => { if (x.at && !out.some(y => y.B === B && Math.hypot(y.at[0] - x.at[0], y.at[1] - x.at[1]) < 3)) out.push({ B, floor: f.floor, number: x.number, floors: x.floors || [f.floor], at: x.at, word: 'Elevator' }); });
          }));
          return out;
        });
      },
      // A feature by its number on a floor (an icon tapped) → { at, who, kind } or null.
      feature(code, n, kind, number) {
        const f = P.got(code, +n); if (!f) return null;
        const list = kind === 'stairs' ? f.stairs : kind === 'elevator' ? f.elevators : f.restrooms;
        return (list || []).find(x => String(x.number) === String(number)) || null;
      },
      // A building whose floor (the one it would open on) didn't come.
      missing(code) { const B = P.by[code]; return !!B && !can(B, S.shown[code] || B.entrance); },
      entrance: (code, number) => P.entrances.find(e => e.code === code && e.number === number) || null,
      open: () => S.open ? Object.assign({}, S.open) : null,
      building: code => P.by[String(code || '').toUpperCase()] || null,
      // The building tinted as a place with no plan (its roof is hidden while it's open).
      picked(name) { S.picked = name || null; S.key = ''; inner.draw(); },
      // The scale that fits a box in what shows of the map, with pad px round it.
      scaleFor(box, pad) {
        const s = inner.size(), t = inner.inset(), q = pad == null ? 24 : pad;
        const aw = Math.max(40, s.W - (t.left || 0) - (t.right || 0) - q * 2), ah = Math.max(40, s.H - t.top - t.bottom - q * 2);
        return Math.min(aw / Math.max(box.w, 1), ah / Math.max(box.h, 1));
      },
      redraw() { S.key = ''; inner.draw(); }
    };
    const grow = (b, p) => { const x0 = Math.min(b.x, p[0]), y0 = Math.min(b.y, p[1]), x1 = Math.max(b.x + b.w, p[0]), y1 = Math.max(b.y + b.h, p[1]); return { x: x0, y: y0, w: x1 - x0, h: y1 - y0 }; };
    inner.draw();
    return api;
  }

  /* ================================================================ the small maps: door to room (§6.1) */

  // px round the door and the room; px the words keep from the frame's edge; px a metre, most and least.
  const PIC = { pad: 24, edge: 6, maxK: 8, minK: 1 };
  const fontOf = () => (getComputedStyle(document.documentElement).getPropertyValue('--ogc-sans') || '').trim() || 'sans-serif';
  // A crop: the floor's metres scaled k px a metre and moved by ox, oy, in a W × H frame. Paths are written
  // in its pixels to a tenth, relative after the first point (a small map is aimed at under 20 KB).
  // (A point less than SIMPLE px off the line between its neighbours is left out, Douglas–Peucker: the
  // Chapel's curved walls were half its picture's bytes.)
  const SIMPLE = .5;
  function simplify(q, tol) {
    if (q.length < 3) return q;
    const T = tol || SIMPLE;
    const keep = new Uint8Array(q.length), st = [[0, q.length - 1]];
    keep[0] = keep[q.length - 1] = 1;
    while (st.length) {
      const [a, b] = st.pop(), ax = q[a][0], ay = q[a][1], dx = q[b][0] - ax, dy = q[b][1] - ay, L = Math.hypot(dx, dy);
      let far = -1, fd = T;
      for (let i = a + 1; i < b; i++) { const d = L ? Math.abs((q[i][0] - ax) * dy - (q[i][1] - ay) * dx) / L : Math.hypot(q[i][0] - ax, q[i][1] - ay); if (d > fd) { fd = d; far = i; } }
      if (far > -1) { keep[far] = 1; st.push([a, far], [far, b]); }
    }
    return q.filter((p, i) => keep[i]);
  }
  function cropOf(k, ox, oy, W, H, tol) {
    // (To half a pixel: on a phone's screen that's one dot, and a third fewer characters than tenths; a
    // sheet wider than a phone's, tol over 0.55, to the pixel.)
    const Q = tol > .55 ? 1 : 2;
    const n = v => String(v / Q).replace(/^(-?)0\./, '$1.');
    const pair = (a, b) => n(a) + (b < 0 ? '' : ' ') + n(b);
    const run = (pts, close) => {
      let s = '', px = 0, py = 0;
      simplify(pts.map(p => [p[0] * k + ox, p[1] * k + oy]), tol).forEach(p => { const qx = Math.round(p[0] * Q), qy = Math.round(p[1] * Q); if (!s) s = 'M' + pair(qx, qy); else if (qx !== px || qy !== py) s += 'l' + pair(qx - px, qy - py); else return; px = qx; py = qy; });
      return s && close ? s + 'z' : s;
    };
    const flat = r => { const out = []; for (let i = 0; i + 1 < r.length; i += 2) out.push([r[i], r[i + 1]]); return out; };
    return {
      k, ox, oy, W, H,
      pt: p => [p[0] * k + ox, p[1] * k + oy],
      // (min: a ring smaller than this many px across is left out: a wall's specks at a small map's scale.)
      d: (rs, min) => (rs || []).filter(r => r && r.length >= 6 && (!min || (b => b.w * k >= min || b.h * k >= min)(boxOfRings([r])))).map(r => run(flat(r), true)).join(''),
      line: pts => run(pts, false),
      see: b => !!b && b.x * k + ox < W + 4 && (b.x + b.w) * k + ox > -4 && b.y * k + oy < H + 4 && (b.y + b.h) * k + oy > -4
    };
  }
  // A place's room in the build: { B, floor, number, asked } or null (not in the build, a whole building,
  // a building not placed): room asks for one by its number (the Chapel's balcony), else the place's first.
  function specOf(P, code, room) {
    const pl = P.places[String(code || '').toUpperCase()], B = pl && P.by[pl.code];
    if (!B || !B.ok) return null;
    const r = room && room.number != null ? room : (pl.rooms || [])[0];
    if (!r || B.floors.indexOf(+r.floor) < 0) return null;
    return { B, floor: +r.floor, number: String(r.number), asked: !!(room && room.number != null) };
  }
  // The router's walk from the building's door to the room (§6.1): the one door everywhere (Nov 5, night),
  // M.placeDoor's: the planner's own shortest walk from the building's entrances, step-free only for a
  // household with No stairs on (ogc-map-route.js says the rules).
  function walkIn(R, s, p, places, stepFree) {
    const to = s.asked ? { room: s.B.code + '|' + s.floor + '|' + s.number } : { code: String(p.code).toUpperCase() };
    return M.placeDoor(R, s.B.code, to, { places, stepFree: !!stepFree });
  }

  // The picture (§6.1), W px wide and 16:9: the room's floor cropped round the best door and the room (a
  // room upstairs: round the elevator, or the stairs, it comes up by), north up; the door's mark and name,
  // the room in tan with its plate, the 3 px line along the halls, the floor's caption on the cream; the
  // Conference's other rooms named where there's room. Every floor it draws is here already (P.got).
  //   → { svg, line, label, kind: 'room' | 'up', door, floor, W } or null (the campus mini stays).
  function picture(P, r, s, c, p, places, W) {
    const B = s.B, F = s.floor, f = P.got(B.code, F), x0 = f && f._by[s.number];
    // (A room with no shape, PPAC's lobby, is its point: a tan dot, as on the map, in a 2 m box.)
    const x = x0 && (x0.box ? x0 : x0.r.at ? Object.assign({}, x0, { box: { x: x0.r.at[0] - 1, y: x0.r.at[1] - 1, w: 2, h: 2 }, dot: x0.r.at }) : null);
    if (!f || !x) return null;
    const e = P.entrances.find(q => q.code === r.door.code && String(q.number) === String(r.door.number));
    if (!e || !e.at) return null;
    const H = Math.round(W * 9 / 16), fam = fontOf(), tw = (t, px, wt) => measure(t, px, wt, fam);
    const up = +e.floor !== F;
    // The line as the map's own door line is drawn (finish()): its kinks taken out along the walls, and
    // stopped where it first goes into the room (it never enters the tan).
    const room = [];
    (x.r.shape || []).forEach(rg => { for (let i = 0; i + 1 < rg.length; i += 2) { const j = (i + 2) % rg.length; room.push(rg[i], rg[i + 1], rg[j], rg[j + 1]); } });
    const lines = (r.parts || []).filter(q => q.building === B.code && +q.floor === F && q.pts && q.pts.length > 1)
      .map(q => { const st = straighten(q.pts.map(p => [p[0], p[1]]), f); return room.length ? clipAt(st, new Float64Array(room), x.r.shape) : st; })
      .filter(l => l.length > 1);
    if (!lines.length) return null;
    const vstep = up ? (r.steps || []).filter(q => q.kind === 'floor' && q.building === B.code && +q.floorTo === F).pop() : null;
    const liftWord = vstep ? (vstep.icon === 'elevator' ? 'Elevator' : 'Stairs') : '';
    const start = up ? lines[0][0] : e.at;
    const end = (r.steps || []).find(q => q.kind === 'end');
    const item = M.buildingFor(c, p, places), short = item ? (M.shortsFor(c, places)[item.name] || M.shortOf(item)) : B.name;
    const name = s.asked ? titleCase(x.r.name) : (M.nameIn ? M.nameIn(c, p, places, item) : p.name) || titleCase(x.r.name);
    const floorW = O.floorName(F);
    const line = withWhy(up ? [r.door.name, liftWord, floorW] : [r.door.name, floorW, end && end.side], r.why);
    const label = name + ', ' + short + ' ' + floorW + ', from the ' + r.door.name;

    // What must show, in metres: the door (or the way up), the line, the room.
    const G = { x0: Infinity, y0: Infinity, x1: -Infinity, y1: -Infinity };
    const take = q => { G.x0 = Math.min(G.x0, q[0]); G.y0 = Math.min(G.y0, q[1]); G.x1 = Math.max(G.x1, q[0]); G.y1 = Math.max(G.y1, q[1]); };
    take(start); lines.forEach(l => l.forEach(take)); take([x.box.x, x.box.y]); take([x.box.x + x.box.w, x.box.y + x.box.h]);
    const gw = Math.max(G.x1 - G.x0, 1), gh = Math.max(G.y1 - G.y0, 1);
    const mid = B.middle || [f._box.x + f._box.w / 2, f._box.y + f._box.h / 2];

    // The words, placed in pixels at a scale k (relative to G's corner), each kept off the line, the marks
    // and the words before it; the frame then takes them all in, or the scale steps down and they're placed
    // again (a word is never cut off at the edge).
    const hit = (a, b, m) => a.x0 - m < b.x1 && a.x1 + m > b.x0 && a.y0 - m < b.y1 && a.y1 + m > b.y0;
    // Does a box (px at scale k, from G's corner) cross one of the floor's walls? (Each wall ring's edges
    // against the box, Liang–Barsky; a ring inside the box counts too.)
    const wb = f._wb || (f._wb = (f.walls || []).map(boxOfRings));
    // (bx in px at scale k; o: the metres at px 0, 0, G's corner unless given.)
    function onWall(bx, k, o) {
      const ox = o ? o[0] : G.x0, oy = o ? o[1] : G.y0;
      const x0 = bx.x0 / k + ox, y0 = bx.y0 / k + oy, x1 = bx.x1 / k + ox, y1 = bx.y1 / k + oy;
      const cut = (ax, ay, bx2, by) => {
        let t0 = 0, t1 = 1;
        const dx = bx2 - ax, dy = by - ay, p = [-dx, dx, -dy, dy], q = [ax - x0, x1 - ax, ay - y0, y1 - ay];
        for (let i = 0; i < 4; i++) {
          if (p[i] === 0) { if (q[i] < 0) return false; continue; }
          const t = q[i] / p[i];
          if (p[i] < 0) { if (t > t1) return false; if (t > t0) t0 = t; } else { if (t < t0) return false; if (t < t1) t1 = t; }
        }
        return true;
      };
      // (How many edges cross it: the floor's own edge counts as a wall, since a word half on the cream and
      // half on the floor, through the doorway's jambs, is no easier to read.)
      let n = 0;
      const ringCut = r => { for (let j = 0; j + 1 < r.length; j += 2) { const e = (j + 2) % r.length; if (cut(r[j], r[j + 1], r[e], r[e + 1])) n++; } };
      (f.outline || []).forEach(ringCut);
      (f.walls || []).forEach((part, i) => {
        const b = wb[i];
        if (!b || b.x > x1 || b.x + b.w < x0 || b.y > y1 || b.y + b.h < y0) return;
        part.forEach(ringCut);
      });
      return n;
    }
    function lay(k) {
      const at = q => [(q[0] - G.x0) * k, (q[1] - G.y0) * k];
      const samples = [];
      lines.forEach(l => { for (let i = 1; i < l.length; i++) { const a = at(l[i - 1]), b = at(l[i]), L = Math.hypot(b[0] - a[0], b[1] - a[1]), n = Math.max(1, Math.ceil(L / 4)); for (let j = 0; j <= n; j++) samples.push([a[0] + (b[0] - a[0]) * j / n, a[1] + (b[1] - a[1]) * j / n]); } });
      const onLine = (bx, m) => samples.some(q => q[0] > bx.x0 - m && q[0] < bx.x1 + m && q[1] > bx.y0 - m && q[1] < bx.y1 + m);
      const placed = [], S = at(start);
      // (The door's mark, or the way up's chip, a little bigger than it is.)
      const D = up ? 12 : 8;
      placed.push({ x0: S[0] - D, y0: S[1] - D, x1: S[0] + D, y1: S[1] + D });
      const free = (bx, m) => !onLine(bx, m) && !placed.some(q => hit(bx, q, m));
      // The plate: above the room's top (below it when the line comes in from above), else slid along it,
      // else over the room itself.
      const pw = tw(name, 15) + 16, rb = { x0: (x.box.x - G.x0) * k, y0: (x.box.y - G.y0) * k }, rw = x.box.w * k, rh = x.box.h * k;
      rb.x1 = rb.x0 + rw; rb.y1 = rb.y0 + rh;
      const below0 = S[1] < (rb.y0 + rb.y1) / 2;
      const plateBox = (px, py, below) => below ? { x0: px - pw / 2, y0: py + 1, x1: px + pw / 2, y1: py + 33 } : { x0: px - pw / 2, y0: py - 33, x1: px + pw / 2, y1: py - 1 };
      const cx = (rb.x0 + rb.x1) / 2, slide = Math.max(0, rw / 2 - 10);
      const pc = [];
      [below0, !below0].forEach(bl => [0, -.5, .5, -1, 1].forEach(t => pc.push([cx + t * slide, bl ? rb.y1 : rb.y0, bl])));
      pc.push([cx, (rb.y0 + rb.y1) / 2 + 16, false]);
      // Of the clear places, the first, unless a later one lets the picture be a good deal bigger (a word
      // that sticks out the short way makes the whole floor smaller: Barnes 133's door name under the door).
      let U = { x0: -PIC.pad, y0: -PIC.pad, x1: gw * k + PIC.pad, y1: gh * k + PIC.pad };
      const grown = b => ({ x0: Math.min(U.x0, b.x0 - PIC.edge), y0: Math.min(U.y0, b.y0 - PIC.edge), x1: Math.max(U.x1, b.x1 + PIC.edge), y1: Math.max(U.y1, b.y1 + PIC.edge) });
      const need = b => { const u = grown(b); return Math.max((u.x1 - u.x0) / W, (u.y1 - u.y0) / H); };
      const choose = (list, m) => { let pick = null, pn = Infinity; list.forEach(b => { if (!free(b, m)) return; const n = need(b); if (n < pn - .05) { pick = b; pn = n; } }); return pick; };
      const pbs = pc.map(q => Object.assign(plateBox(q[0], q[1], q[2]), { px: q[0], py: q[1], below: q[2] }));
      // (Over the room itself only when nowhere beside it is clear: it hides the tan.)
      const inRoom = pbs.pop(), pb = choose(pbs, 4) || (free(inRoom, 4) ? inRoom : pbs[0]);
      const plate = { x: pb.px, y: pb.py, below: pb.below, bx: pb };
      placed.push(plate.bx); U = grown(plate.bx);
      // The door's name (or the way up's word) beside its mark, outward from the building first.
      const word = up ? liftWord : r.door.name, ww = tw(word, 13), anchor = dx => Math.abs(dx) > .35 ? (dx > 0 ? 'start' : 'end') : 'middle';
      const ax = S[0] - (mid[0] - G.x0) * k, ay = S[1] - (mid[1] - G.y0) * k, al = Math.hypot(ax, ay) || 1, ox = ax / al, oy = ay / al;
      const dirs = [];
      for (let i = 0; i < 8; i++) { const t = i * Math.PI / 4; dirs.push([Math.cos(t), Math.sin(t)]); }
      dirs.sort((a, b) => (b[0] * ox + b[1] * oy) - (a[0] * ox + a[1] * oy));
      // (Beside the mark 5 px clear of it; above or below it 5 px clear; at a corner, beside and a line down or up.)
      const nameBox = d => {
        const an = anchor(d[0]), sy = Math.abs(d[1]) > .35 ? Math.sign(d[1]) : 0;
        const tx = S[0] + (an === 'start' ? D + 5 : an === 'end' ? -D - 5 : 0), ty = S[1] + sy * (an === 'middle' ? D + 14 : 11);
        const x0 = an === 'start' ? tx : an === 'end' ? tx - ww : tx - ww / 2;
        return { x0, y0: ty - 9, x1: x0 + ww, y1: ty + 9, tx, ty, an };
      };
      // (Of the clear spots, those the fewest walls cross: on the cream or a hall's white it reads at a glance.)
      const nbs = dirs.map(nameBox), ok = nbs.filter(b => free(b, 3));
      ok.forEach(b => { b.wn = onWall(b, k); });
      const least = ok.length ? Math.min.apply(null, ok.map(b => b.wn)) : 0;
      const nm = choose(ok.filter(b => b.wn === least), 3) || nbs[0];
      placed.push(nm);
      // The frame takes in what must show (with PIC.pad round it) and the words (PIC.edge from the edge).
      U = grown(nm);
      return { k, at, plate, nm, U, placed, onLine, samples };
    }
    // (A wider sheet, a laptop's, shows the same stretch of floor bigger, not more of the building round
    // it, and keeps a little less of a curve's detail: a picture stays under 20 KB at any width.)
    const big = Math.max(1, W / 346);
    let k = Math.min(Math.max(Math.min((W - 2 * PIC.pad) / gw, (H - 2 * PIC.pad) / gh), PIC.minK), PIC.maxK * big), L = null;
    for (let i = 0; i < 16; i++) {
      L = lay(k);
      if ((L.U.x1 - L.U.x0 <= W && L.U.y1 - L.U.y0 <= H) || k <= PIC.minK) break;
      k = Math.max(PIC.minK, k * .9);
    }
    // The frame: the words and what must show in the middle of it.
    const dx = (W - (L.U.x1 - L.U.x0)) / 2 - L.U.x0, dy = (H - (L.U.y1 - L.U.y0)) / 2 - L.U.y0;
    const X = cropOf(k, dx - G.x0 * k, dy - G.y0 * k, W, H, SIMPLE * big), mv =b => ({ x0: b.x0 + dx, y0: b.y0 + dy, x1: b.x1 + dx, y1: b.y1 + dy });
    const placed = L.placed.map(mv), onLine = (b, m) => L.onLine({ x0: b.x0 - dx, y0: b.y0 - dy, x1: b.x1 - dx, y1: b.y1 - dy }, m);
    const inFrame = b => b.x0 >= PIC.edge && b.y0 >= PIC.edge && b.x1 <= W - PIC.edge && b.y1 <= H - PIC.edge;
    const g = (cls, q, inner) => '<g class="pv-mark ' + cls + '" transform="translate(' + q[0].toFixed(1) + ' ' + q[1].toFixed(1) + ')">' + inner + '</g>';

    let h = '<rect class="pl-pic__bg" width="' + W + '" height="' + H + '"/>';
    // The campus round it (ground, lawns, lots, the streets and paths, the other buildings), only what's in the frame.
    const KIND = { green: 'pl-pic__green', parking: 'pl-pic__lot', camper: 'pl-pic__lot', highway: 'pl-pic__road', road: 'pl-pic__road', path: 'pl-pic__path', steps: 'pl-pic__path' };
    const OPEN = { road: 1, path: 1, highway: 1, steps: 1 };
    const bb = i => i._bb || (i._bb = (() => { let x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity; i.pts.forEach(q => { x0 = Math.min(x0, q[0]); y0 = Math.min(y0, q[1]); x1 = Math.max(x1, q[0]); y1 = Math.max(y1, q[1]); }); return { x: x0, y: y0, w: x1 - x0, h: y1 - y0 }; })());
    const ground = {};
    c.items.forEach(i => {
      if (!i.pts || i.pts.length < 2 || !X.see(bb(i))) return;
      const cls = KIND[i.kind] || (BUILT[i.kind] ? 'pl-pic__b' : '');
      if (!cls) return;
      // (A street or path only where it crosses the frame: a long road was drawn end to end.)
      if (OPEN[i.kind]) {
        const runs = [];
        let cur = null;
        for (let j = 1; j < i.pts.length; j++) {
          const a = i.pts[j - 1], b2 = i.pts[j], seg = { x: Math.min(a[0], b2[0]) - 6 / k, y: Math.min(a[1], b2[1]) - 6 / k, w: Math.abs(b2[0] - a[0]) + 12 / k, h: Math.abs(b2[1] - a[1]) + 12 / k };
          if (X.see(seg)) { if (!cur) runs.push(cur = [a]); cur.push(b2); } else cur = null;
        }
        (ground[cls] = ground[cls] || []).push(runs.map(X.line).join(''));
      } else (ground[cls] = ground[cls] || []).push(i.pts.length > 2 ? X.line(i.pts) + 'z' : '');
    });
    ['pl-pic__green', 'pl-pic__lot', 'pl-pic__road', 'pl-pic__path', 'pl-pic__b'].forEach(cls => {
      if (!ground[cls]) return;
      const sw = cls === 'pl-pic__road' ? ' style="stroke-width:' + Math.min(5 * k, 30).toFixed(1) + 'px"' : cls === 'pl-pic__path' ? ' style="stroke-width:' + Math.max(1.6 * k, 2).toFixed(1) + 'px"' : '';
      h += '<path class="' + cls + '" d="' + ground[cls].join('') + '"' + sw + '/>';
    });
    // The floor (the map's own drawing), then the line on its white casing.
    h += '<g class="pv-fl is-full">' + floorBody(f, { mode: 'full', dest: [s.number], X });
    lines.forEach(l => { const d = X.line(l); h += '<path class="pv-fl__case" d="' + d + '"/><path class="pv-fl__line" d="' + d + '"/>'; });
    h += '</g>';
    // The Conference's other rooms on the floor: a name inside its room where it fits, else its code plate,
    // where neither crowds the line or a word already placed.
    let marks = '';
    f._rooms.forEach(y => {
      const code = y.r.public && y.r.codes && y.r.codes[0];
      if (!code || String(y.r.number) === s.number || !y.box || !X.see(y.box)) return;
      const q = y.r.box ? X.pt([y.r.box[0], y.r.box[1]]) : X.pt([y.box.x + y.box.w / 2, y.box.y + y.box.h / 2]), bw = y.box.w * k, bh = y.box.h * k;
      const pl = places[code] || places[String(code).toUpperCase()], nm = pl ? (M.nameIn ? M.nameIn(c, pl, places, item) : pl.name) : titleCase(y.r.name), w1 = tw(nm, 14);
      const tag = code.indexOf('/') > -1 ? code.split('/')[1] : code, pw = Math.max(20, tw(tag, 12) + 12);
      const one = w1 <= bw * .9 && bh >= 18;
      const bx = one ? { x0: q[0] - w1 / 2, y0: q[1] - 9, x1: q[0] + w1 / 2, y1: q[1] + 9 } : { x0: q[0] - pw / 2, y0: q[1] - 10, x1: q[0] + pw / 2, y1: q[1] + 10 };
      if (!one && (bw < pw + 4 || bh < 22)) return;
      if (!inFrame(bx) || onLine(bx, 3) || placed.some(b => hit(bx, b, 3))) return;
      placed.push(bx);
      marks += g('pv-room ' + (one ? 'is-one' : 'is-plate'), q, one ? '<g class="pv-room__one"><text y="1">' + esc(nm) + '</text></g>'
        : '<g class="pv-room__plate"><rect x="' + (-pw / 2).toFixed(1) + '" y="-10" width="' + pw.toFixed(1) + '" height="20" rx="5"/><text y="1">' + esc(tag) + '</text></g>');
    });
    // The door (the map's entry triangle, bigger, as the route's door is) or the way up (its icon in a
    // chip), with its name; the room's plate.
    const S = X.pt(start), nmb = Object.assign(mv(L.nm), { tx: L.nm.tx + dx, ty: L.nm.ty + dy, an: L.nm.an });
    if (up) marks += g('pv-chip', S, '<circle class="pv-chip__bg" r="11"/>' + icon(vstep && vstep.icon === 'elevator' ? 'elevator' : 'stairs', 16));
    else marks += g('pv-door2 is-route', S, entMark(Math.atan2(mid[1] - e.at[1], mid[0] - e.at[0]) * 180 / Math.PI, 11 / 7));
    marks += '<text class="pv-door__t" x="' + nmb.tx.toFixed(1) + '" y="' + nmb.ty.toFixed(1) + '" style="text-anchor:' + nmb.an + '">' + esc(up ? liftWord : r.door.name) + '</text>';
    if (x.dot) marks += g('pv-dot', X.pt(x.dot), '<circle r="6"/>');
    const pq = [L.plate.x + dx, L.plate.y + dy];
    marks += g('pv-plate', pq, plateIn(name, L.plate.below, tw(name, 15) + 16));
    // The credit (ODbL), as every drawn map has it, where the campus's streets or buildings are drawn round
    // the floor: in a bottom corner clear of the words and the line, on the Places map's light chip (IWU's
    // floor itself is not OpenStreetMap's).
    // (A bottom corner first, then a top one.)
    let crAt = '';
    if (Object.keys(ground).length) {
      const cr = M.CREDIT || '© OpenStreetMap contributors', crw = tw(cr, 9.5, 400) + 8;
      const spots = ['br', 'bl', 'tr', 'tl'].map(at => { const x0 = at[1] === 'r' ? W - 1 - crw : 1, y0 = at[0] === 'b' ? H - 15 : 1; return { at, x0, y0, b: { x0, y0, x1: x0 + crw, y1: y0 + 14 } }; });
      // (With none clear, the one that covers the least of the words.)
      const over = b => placed.reduce((s, z) => s + Math.max(0, Math.min(b.x1, z.x1) - Math.max(b.x0, z.x0)) * Math.max(0, Math.min(b.y1, z.y1) - Math.max(b.y0, z.y0)), 0);
      const sp = spots.find(q => !onLine(q.b, 2) && !placed.some(z => hit(q.b, z, 2))) || spots.slice().sort((a, b) => over(a.b) - over(b.b))[0];
      placed.push(sp.b);
      crAt = sp.at;
      marks += '<g class="pl-pic__credit" transform="translate(' + sp.x0.toFixed(1) + ' ' + sp.y0 + ')"><title>Map data: OpenStreetMap, ODbL</title><rect width="' + crw.toFixed(1) + '" height="14" rx="3"/><text x="4" y="10.5">' + esc(cr) + '</text></g>';
    }
    // The floor's caption (1ST FLOOR, the label with its rule) in a corner on the cream, where it crowds
    // nothing; with no corner clear of the floor, on a cream tab of its own. (Inside the credit on its corner.)
    const cap = floorW.toUpperCase(), cw = tw(cap, 12) + 1.2 * cap.length, m0 = 10;
    const by = at => crAt === at ? 14 : 0;
    const corners = [[m0, H - m0 - 20 - by('bl')], [m0, m0 + by('tl')], [W - m0 - cw, H - m0 - 20 - by('br')], [W - m0 - cw, m0 + by('tr')]];
    const capBox = q => ({ x0: q[0] - 4, y0: q[1] - 4, x1: q[0] + cw + 4, y1: q[1] + 24 });
    const onFloor = b => [[b.x0, b.y0], [b.x1, b.y0], [b.x0, b.y1], [b.x1, b.y1], [(b.x0 + b.x1) / 2, (b.y0 + b.y1) / 2]].some(q => inShape((q[0] - X.ox) / k, (q[1] - X.oy) / k, f.outline));
    const clear = corners.filter(q => { const b = capBox(q); return !onLine(b, 2) && !placed.some(z => hit(b, z, 2)); });
    const cream = clear.find(q => !onFloor(capBox(q)) && !onWall(capBox(q), k, [-X.ox / k, -X.oy / k]));
    const cq = cream || clear[0] || corners[0];
    marks += '<g class="pv-mark pv-cap" transform="translate(' + cq[0].toFixed(1) + ' ' + cq[1].toFixed(1) + ')">' + (cream ? '' : '<rect class="pl-pic__tab" x="-6" y="-5" width="' + (cw + 12).toFixed(1) + '" height="30" rx="4"/>') + capIn(cap, cw) + '</g>';
    h += marks;
    const svg = '<svg class="pl-pic" viewBox="0 0 ' + W + ' ' + H + '" role="img" aria-label="' + esc(label) + '">' + h + '</svg>';
    return { svg, line, label, kind: up ? 'up' : 'room', door: r.door.name, floor: F, W };
  }

  // ---- on a page: mini() leaves a slot (slot()), the page's watcher upgrades it (upgrade()) once the
  // floor and the walk are here. The campus mini shows at once in the same 16:9 box; the picture fades in
  // over it (at once under reduced motion); if the floor never comes, the campus mini stays.
  const SLOTS = {}, made = {}, boxes = new WeakMap();
  let slotN = 0;
  // The household's No stairs, as the Conference app keeps it (its own Step-free switch first; then the
  // stay kept on this phone for a signed-in household). Nothing is asked of the server for it here.
  function stepFreeOf(year) {
    try {
      const v = JSON.parse(localStorage.getItem('ogc-map-stepfree') || 'null');
      if (v != null) return !!v;
      const s = JSON.parse(localStorage.getItem('ogc-stay-' + year) || 'null');
      return !!(s && s.stairs);
    } catch (e) { return false; }
  }
  // What mini() draws for a place on a campus with a build: null (no picture for it: the campus mini, as
  // today), else { attrs (the slot), svg and line (a picture drawn before for the place, at once), wait }.
  function slot(year, c, p, places, o) {
    const P = ready(year), code = String(p && p.code || '').toUpperCase();
    if (!code || (P && !specOf(P, code, o.room))) return null;
    const key = [year, code, o.room ? o.room.floor + '|' + o.room.number : '', stepFreeOf(year) ? 1 : 0].join('|');
    const id = 'p' + (++slotN);
    SLOTS[id] = { id, year, c, p, places, room: o.room || null, key, t: Date.now() };
    const m = made[key];
    return { attrs: ' data-pic="' + id + '"', svg: m ? m.svg : '', line: m ? m.line : null, wait: !m };
  }
  // The build, the walk, the router and the floor for a slot, then the picture at width W.
  function draw(d, W) {
    return load(d.year).then(P => {
      const s = P && specOf(P, d.p.code, d.room);
      if (!s) return null;
      return Promise.all([P.indoor(), P.floor(s.B.code, s.floor)]).then(([build, f]) => {
        if (!build || !f) return null;
        const R = M.routerOf(d.c, build), r = walkIn(R, s, d.p, d.places, stepFreeOf(d.year));
        return r ? picture(P, r, s, d.c, d.p, d.places, W) : null;
      });
    }).catch(() => null);
  }
  // (A picture taken off the page stops being watched; a slot never put on the page goes after a minute:
  // 56 dialogs opened and closed grew the heap by 130 KB; r2c fix.)
  const ro = 'ResizeObserver' in window ? new ResizeObserver(es => es.forEach(en => {
    const el = en.target, b = boxes.get(el);
    if (!el.isConnected) { ro.unobserve(el); boxes.delete(el); if (b) clearTimeout(b.t); return; }
    if (!b) return; clearTimeout(b.t); b.t = setTimeout(() => run(el, b), 150);
  })) : null;
  function sweep() {
    const old = Date.now() - 60000;
    Object.keys(SLOTS).forEach(id => { if (SLOTS[id].t < old) delete SLOTS[id]; });
  }
  function upgrade(el) {
    const d = SLOTS[el.dataset.pic];
    el.removeAttribute('data-pic');
    sweep();
    if (!d) return;
    delete SLOTS[d.id];
    boxes.set(el, d);
    if (ro) ro.observe(el);
    run(el, d);
  }
  function run(el, d) {
    const W = Math.round(el.clientWidth);
    if (!W || !el.isConnected) return;
    const m = made[d.key], has = el.querySelector('svg.pl-pic');
    if (m && has && Math.abs(m.W - W) <= 4) return;
    if (d.busy === W) return;
    d.busy = W;
    draw(d, W).then(res => {
      d.busy = 0;
      if (!el.isConnected) return;
      if (!res) { if (!has) settle(el, null); return; }
      made[d.key] = res;
      swap(el, res);
    });
  }
  // The picture in, over the campus mini (a crossfade, at once under reduced motion), and its line.
  function swap(el, res) {
    const old = el.querySelector('svg'), tmp = document.createElement('div');
    tmp.innerHTML = res.svg;
    const svg = tmp.firstChild;
    if (old && old.classList.contains('pl-campus') && !reduced()) {
      svg.classList.add('is-in'); el.appendChild(svg);
      requestAnimationFrame(() => requestAnimationFrame(() => svg.classList.add('is-on')));
      setTimeout(() => { old.remove(); svg.classList.remove('is-in', 'is-on'); }, 260);
    } else if (old) old.replaceWith(svg); else el.appendChild(svg);
    settle(el, res.line);
  }
  // The line under it: the picture's ("South doors · 1st floor · on the right"); with no picture, today's
  // line, or none (a line kept waiting for the picture goes).
  function settle(el, text) {
    const ln = el.parentElement && el.parentElement.querySelector('.pl-mini__line');
    if (!ln) return;
    if (text) { ln.textContent = text; ln.removeAttribute('aria-hidden'); ln.classList.remove('is-wait'); return; }
    if (ln.classList.contains('is-wait')) { if (ln.dataset.was) { ln.textContent = ln.dataset.was; ln.classList.remove('is-wait'); ln.removeAttribute('aria-hidden'); } else ln.remove(); }
  }

  // Every place of a year drawn (tools/campus/small-maps-check.mjs): its kind, size, door and line; sf: as
  // a household with No stairs on sees them (the check runs both, Nov 5, night).
  function pictureAll(year, c, places, W, extra, sf) {
    return load(year).then(P => {
      if (!P) return [];
      const list = Object.keys(places).map(code => ({ code, p: places[code], room: null })).concat(extra || []);
      return Promise.all([P.indoor(), P.walk()].concat(list.map(q => { const s = specOf(P, q.code, q.room); return s ? P.floorsOf(s.B.code) : null; }))).then(([build, Gr]) => {
        const R = build && M.routerOf(c, build);
        return list.map(q => {
          const s = specOf(P, q.code, q.room), w = M.whereIs(c, q.p, places);
          if (!s) return { code: q.code, room: q.room, kind: w.kind === 'outdoor' || w.kind === 'pin' ? (q.p.outdoor === 'yes' ? 'campus, outdoor' : 'campus, pin') : (P.places[q.code] ? 'campus, whole building' : 'campus, no plan'), bytes: 0, door: '', line: M.placeLine(c, q.p, places, null) };
          const r = R && walkIn(R, s, q.p, places, !!sf), res = r ? picture(P, r, s, c, q.p, places, W) : null;
          // (The door the Places map draws its line from, for the same room, as dest() finds it: they should agree.)
          const pd = R && M.placeDoor(R, s.B.code, { room: s.B.code + '|' + s.floor + '|' + s.number }, { stepFree: !!sf });
          const want = pd && pd.door ? { number: pd.door.number, stairs: (pd.steps || []).some(st => st.kind === 'floor' && st.building === s.B.code && st.icon !== 'elevator') } : null;
          const dl = Gr ? lineTo(Gr, P, s.B, s.floor, s.number, null, want) : null;
          return res ? { code: q.code, room: q.room, kind: res.kind, bytes: new Blob([res.svg]).size, door: res.door, placesDoor: dl && dl.door ? dl.door.name : '', line: res.line, label: res.label, svg: res.svg } : { code: q.code, room: q.room, kind: 'campus, no route', bytes: 0, door: '', line: '' };
        });
      });
    });
  }

  // The place dialog's door line (docs/34 §5.2): the same walk as the small map's picture (walkIn: the
  // router from the building's best door, step-free first for a household that ticked No stairs, up by the
  // elevator where there is one), said without the floor, which the dialog's fact line has.
  //   → { door ("South doors"), side, floor, up, lift ("Elevator"), why (No stairs with no step-free walk:
  //       Directions' reason, "Doors not checked"), line ("South doors · on the right", "East doors · Elevator ·
  //       on the left") } or null (no build, no room in it, no walk).
  function doorOf(year, c, p, places, room) {
    return load(year).then(P => {
      const s = P && p && specOf(P, p.code, room);
      if (!s) return null;
      return P.indoor().then(build => {
        if (!build) return null;
        const r = walkIn(M.routerOf(c, build), s, p, places, stepFreeOf(year));
        if (!r || !r.door) return null;
        const e = P.entrances.find(q => q.code === r.door.code && String(q.number) === String(r.door.number));
        const up = !!e && +e.floor !== s.floor;
        const vstep = up ? (r.steps || []).filter(q => q.kind === 'floor' && q.building === s.B.code && +q.floorTo === s.floor).pop() : null;
        const lift = vstep ? (vstep.icon === 'elevator' ? 'Elevator' : 'Stairs') : '';
        const end = (r.steps || []).find(q => q.kind === 'end'), side = end && end.side ? end.side : '';
        return { door: r.door.name, side, floor: s.floor, up, lift, why: r.why || '', line: withWhy([r.door.name, lift, side], r.why) };
      });
    }).catch(() => null);
  }

  /* ================================================================ the packet's floors (feedback 264bfe637ee3) */

  // The printed packet's floor plans (Caleb, Nov 5: "There might be multiple maps to add to the info
  // packet"), after its campus map: each floor of a building in the public build that the year's printout
  // names a room on, the whole floor at paper size (1 px = 1/96 in; no word under 7.5 pt), north up, drawn
  // by floorBody() as the map's and the small maps' floors are: the Conference's rooms in tan with their
  // code and name, the doors open to visitors named, the restrooms, stairs and elevators marked, a scale
  // and north. A building's floors share one frame and scale, so they line up. Mechanical: the rooms are
  // the build's for the codes given, the doors its entrances (the campus record's name first; a key-only
  // door left out), every mark where the build has it; words are placed by fixed tries, nothing by hand.
  // Never a hall people sleep in or a Lodge: the build has none, and one the campus calls a hall is refused.
  const SHEET = { W: 680, H: 414, edge: 6, foot: 18, line: 12 };
  const KINDS = ['women', 'men', 'family', 'unknown', 'elevator', 'stairs'];
  const itemOfB = (c, B, places) => (places && places[B.code] && M.buildingFor(c, places[B.code], places)) || (M.find ? M.find(c, B.name) : null);
  const staysIn = (c, B, places) => { const i = itemOfB(c, B, places); return /\blodge\b/i.test(B.name) || !!(i && (i.kind === 'hall' || i.stay)); };

  // Which floors the codes name rooms on: [{ B, floor, rooms: [{ number, code }] }], in the build's order of
  // buildings, lowest floor first. (A whole building, a room the build hasn't got: no floor.)
  function sheetFloors(P, c, codes, places) {
    const by = {};
    (codes || []).forEach(code => {
      const k = String(code || '').toUpperCase(), pl = P.places[k], B = pl && P.by[pl.code];
      if (!B || !B.ok || staysIn(c, B, places)) return;
      (pl.rooms || []).forEach(r => {
        const n = +r.floor;
        if (B.floors.indexOf(n) < 0) return;
        const e = by[B.code + '|' + n] || (by[B.code + '|' + n] = { B, floor: n, rooms: [] });
        if (!e.rooms.some(x => x.number === String(r.number))) e.rooms.push({ number: String(r.number), code: k });
      });
    });
    return Object.keys(by).map(k => by[k]).sort((a, b) => P.list.indexOf(a.B) - P.list.indexOf(b.B) || a.floor - b.floor);
  }
  // The year's build with those floors here, and each building's entrance floor (drawn under an upper one).
  //   → Promise(P), or null: no build, or none of the codes has a room in it.
  function sheetLoad(year, c, codes, places) {
    return load(year).then(P => {
      const list = P ? sheetFloors(P, c, codes, places) : [];
      if (!list.length) return null;
      return Promise.all(list.map(x => Promise.all([P.floor(x.B.code, x.floor), P.floor(x.B.code, x.B.entrance)]))).then(() => P);
    }).catch(() => null);
  }

  // The floors drawn: [{ code (the building's), floor, caption ("Barnes · 1st floor"), svg, label, kinds (the
  // marks on it, for its key), bytes }]; a floor that didn't come is left out. o: places (the year's),
  // nameOf(code) (the room's name as the printout writes it), labelOf / keyOnly / stepFree (a door's id: the
  // campus record), W (px wide), H (px tall at most).
  function sheet(P, c, codes, o) {
    o = o || {};
    if (!P) return [];
    const W = o.W || SHEET.W, HM = o.H || SHEET.H, E = SHEET.edge, FOOT = SHEET.foot, LH = SHEET.line, fam = fontOf();
    const tw = (t, px, wt) => measure(t, px, wt == null ? 700 : wt, fam);
    const hit = (a, b, m) => a.x0 - m < b.x1 && a.x1 + m > b.x0 && a.y0 - m < b.y1 && a.y1 + m > b.y0;
    const places = o.places || {}, shorts = M.shortsFor ? M.shortsFor(c, places) : {};
    const list = sheetFloors(P, c, codes, places).filter(x => P.got(x.B.code, x.floor));

    // One floor laid out at k px a metre, in px from the building's frame (M0, metres): the doors, the marks,
    // the rooms' words, the doors' names, each kept off what's placed before it; U is all of it.
    function lay(x, f, g0, M0, k) {
      const B = x.B, at = q => [(q[0] - M0.x0) * k, (q[1] - M0.y0) * k];
      const U = { x0: Infinity, y0: Infinity, x1: -Infinity, y1: -Infinity };
      const grow = b => { U.x0 = Math.min(U.x0, b.x0); U.y0 = Math.min(U.y0, b.y0); U.x1 = Math.max(U.x1, b.x1); U.y1 = Math.max(U.y1, b.y1); };
      const boxPx = bb => ({ x0: (bb.x - M0.x0) * k, y0: (bb.y - M0.y0) * k, x1: (bb.x + bb.w - M0.x0) * k, y1: (bb.y + bb.h - M0.y0) * k });
      grow(boxPx(f._box));
      if (g0) grow(boxPx(g0._box));
      const placed = [], put = b => { placed.push(b); grow(b); return b; };
      const free = (b, m) => !placed.some(q => hit(b, q, m));
      const corners = b => [[b.x0, b.y0], [b.x1, b.y0], [b.x0, b.y1], [b.x1, b.y1], [(b.x0 + b.x1) / 2, (b.y0 + b.y1) / 2]].map(q => [q[0] / k + M0.x0, q[1] / k + M0.y0]);
      const onFloor = b => corners(b).some(q => inShape(q[0], q[1], f.outline) || (g0 && inShape(q[0], q[1], g0.outline)));
      const mid = at(B.middle || [f._box.x + f._box.w / 2, f._box.y + f._box.h / 2]);

      // The doors open to visitors on this floor: the entry triangle pointing in (a checked step-free door,
      // the accessible icon), its name outside.
      const doors = P.entrances.filter(e => e.code === B.code && +e.floor === x.floor && e.at && !(o.keyOnly && o.keyOnly(e.door))).map(e => {
        const S = at(e.at);
        put({ x0: S[0] - 6, y0: S[1] - 6, x1: S[0] + 6, y1: S[1] + 6 });
        return { S, sf: !!(o.stepFree && o.stepFree(e.door)), a: Math.atan2(mid[1] - S[1], mid[0] - S[0]) * 180 / Math.PI, word: (o.labelOf && o.labelOf(e.door)) || e.name || 'Doors' };
      });

      // The restrooms a visitor may use (not a locker room), the elevators and the stairs, each an icon in a
      // white chip; marks nearer than a chip's width share one chip, their icons side by side.
      const feats = [];
      (f.restrooms || []).forEach(r => { const rm = f._by[r.number]; if (r.at && r.walk !== false && !(rm && /LOCKER|SHOWER|TEAM|STAFF/i.test(rm.r.name || ''))) feats.push({ kind: KINDS.indexOf(r.who) > -1 && KINDS.indexOf(r.who) < 4 ? r.who : 'unknown', p: at(r.at) }); });
      (f.elevators || []).forEach(r => { if (r.at) feats.push({ kind: 'elevator', p: at(r.at) }); });
      (f.stairs || []).forEach(r => { if (r.at) feats.push({ kind: 'stairs', p: at(r.at) }); });
      const groups = [];
      feats.forEach(q => {
        const g = groups.find(z => Math.hypot(z.p[0] - q.p[0], z.p[1] - q.p[1]) < 16);
        if (!g) { groups.push({ p: q.p.slice(), n: 1, kinds: [q.kind] }); return; }
        g.p = [(g.p[0] * g.n + q.p[0]) / (g.n + 1), (g.p[1] * g.n + q.p[1]) / (g.n + 1)];
        g.n++;
        if (g.kinds.indexOf(q.kind) < 0) g.kinds.push(q.kind);
      });
      const chips = groups.map(g => {
        g.kinds.sort((a, b) => KINDS.indexOf(a) - KINDS.indexOf(b));
        const w = 4 + 13 * g.kinds.length, box = q => ({ x0: q[0] - w / 2, y0: q[1] - 8, x1: q[0] + w / 2, y1: q[1] + 8 });
        let p = g.p;
        if (!free(box(p), 1)) {
          const tries = [];
          [7, 11, 15].forEach(d => { for (let i = 0; i < 8; i++) { const t = i * Math.PI / 4; tries.push([g.p[0] + Math.cos(t) * d, g.p[1] + Math.sin(t) * d]); } });
          p = tries.find(q => free(box(q), 1)) || g.p;
        }
        put(box(p));
        return { p, w, kinds: g.kinds };
      });

      // How many walls (and the floor's edge) a box of words crosses (Liang–Barsky on each edge, as picture()
      // counts them): words on the white or the cream read at a glance.
      const wb = f._wb || (f._wb = (f.walls || []).map(boxOfRings));
      function cross(b) {
        const x0 = b.x0 / k + M0.x0, y0 = b.y0 / k + M0.y0, x1 = b.x1 / k + M0.x0, y1 = b.y1 / k + M0.y0;
        const cut = (ax, ay, bx, by) => {
          let t0 = 0, t1 = 1;
          const ex = bx - ax, ey = by - ay, p = [-ex, ex, -ey, ey], q = [ax - x0, x1 - ax, ay - y0, y1 - ay];
          for (let i = 0; i < 4; i++) {
            if (p[i] === 0) { if (q[i] < 0) return false; continue; }
            const t = q[i] / p[i];
            if (p[i] < 0) { if (t > t1) return false; if (t > t0) t0 = t; } else { if (t < t0) return false; if (t < t1) t1 = t; }
          }
          return true;
        };
        let n = 0;
        const ring = r => { for (let j = 0; j + 1 < r.length; j += 2) { const e = (j + 2) % r.length; if (cut(r[j], r[j + 1], r[e], r[e + 1])) n++; } };
        (f.outline || []).forEach(ring);
        (f.walls || []).forEach((part, i) => { const q = wb[i]; if (!q || q.x > x1 || q.x + q.w < x0 || q.y > y1 || q.y + q.h < y0) return; part.forEach(ring); });
        return n;
      }
      // Eight ways round a point, east first, clockwise.
      const DIRS = [];
      for (let i = 0; i < 8; i++) { const t = i * Math.PI / 4; DIRS.push([Math.cos(t), Math.sin(t)]); }

      // The Conference's rooms: tan (floorBody), and their code with their name: inside the room where all of
      // it is on the tan and crosses no wall (code over name, then on one line, then the name in two), at the
      // room's own point or a step round it; else beside the room, nearest its point, clear of the tan and of
      // what's placed, the fewest walls crossed, with a leader line into the room.
      const tan = x.rooms.map(rr => f._by[rr.number]).filter(Boolean);
      // (Over the tan: any of fifteen points across the box, five along by three down.)
      const grid = b => { const q = []; for (let i = 0; i <= 4; i++) for (let j = 0; j <= 2; j++) q.push([(b.x0 + (b.x1 - b.x0) * i / 4) / k + M0.x0, (b.y0 + (b.y1 - b.y0) * j / 2) / k + M0.y0]); return q; };
      const onTan = (b, own) => grid(b).some(q => tan.some(y => y !== own && y.d && inShape(q[0], q[1], y.r.shape)));
      const inOwn = (b, y) => [b.x0, (b.x0 + b.x1) / 2, b.x1].every(px => [b.y0, (b.y0 + b.y1) / 2, b.y1].every(py => inShape(px / k + M0.x0, py / k + M0.y0, y.r.shape)));
      const rooms = [];
      x.rooms.forEach(rr => {
        const y = f._by[rr.number];
        if (!y) return;
        const first = ((P.places[rr.code] || {}).rooms || [])[0];
        const isFirst = !!first && +first.floor === x.floor && String(first.number) === rr.number;
        const name = (isFirst && o.nameOf && o.nameOf(rr.code)) || titleCase(y.r.name);
        const pt = y.r.at || (y.box ? [y.box.x + y.box.w / 2, y.box.y + y.box.h / 2] : null);
        const anchor = y.r.box ? at([y.r.box[0], y.r.box[1]]) : pt ? at(pt) : null;
        if (!anchor) return;
        const code = { t: rr.code, cls: 'code', px: 10.5, wt: 700 }, nm = name && name.toUpperCase() !== rr.code ? { t: name, cls: 'name', px: 10, wt: 400 } : null;
        const cfgs = [nm ? [code, nm] : [code]];
        if (nm) {
          cfgs.push([Object.assign({}, code, { then: nm })]);
          const ws = name.split(' ');
          let best = null;
          for (let i = 1; i < ws.length; i++) { const a = ws.slice(0, i).join(' '), b = ws.slice(i).join(' '), m = Math.max(tw(a, 10, 400), tw(b, 10, 400)); if (!best || m < best.m) best = { a, b, m }; }
          if (best) cfgs.push([code, { t: best.a, cls: 'name', px: 10, wt: 400 }, { t: best.b, cls: 'name', px: 10, wt: 400 }]);
        }
        const wOf = l => tw(l.t, l.px, l.wt) + (l.then ? 4 + tw(l.then.t, l.then.px, l.then.wt) : 0);
        const sized = cfgs.map(ls => ({ ls, w: Math.max.apply(null, ls.map(wOf)) + 3, h: ls.length * LH }));
        const boxAt = (s, cx, cy) => ({ x0: cx - s.w / 2, y0: cy - s.h / 2, x1: cx + s.w / 2, y1: cy + s.h / 2, s });
        let lab = null, out = false;
        if (y.d) {
          const offs = [[0, 0]];
          [8, 16, 26].forEach(r => DIRS.forEach(u => offs.push([u[0] * r, u[1] * r])));
          for (const s of sized) {
            lab = offs.map(q => boxAt(s, anchor[0] + q[0], anchor[1] + q[1])).find(b => free(b, 0) && inOwn(b, y) && !cross(b)) || null;
            if (lab) break;
          }
        }
        if (!lab) {
          out = true;
          let best = null;
          [10, 18, 28, 40, 56, 76, 100, 130].forEach(r => sized.forEach((s, si) => DIRS.forEach(u => {
            const b = boxAt(s, anchor[0] + u[0] * (r + Math.abs(u[0]) * s.w / 2), anchor[1] + u[1] * (r + Math.abs(u[1]) * s.h / 2));
            if (!free(b, 2) || onTan(b, null) || (anchor[0] > b.x0 - 4 && anchor[0] < b.x1 + 4 && anchor[1] > b.y0 - 4 && anchor[1] < b.y1 + 4)) return;
            const score = r + 25 * cross(b) + 6 * si;
            if (!best || score < best.score) best = { b, score };
          })));
          lab = best && best.b;
          if (!lab) {
            let least = null;
            sized.forEach(s => DIRS.forEach(u => { const b = boxAt(s, anchor[0] + u[0] * (10 + s.w / 2), anchor[1] + u[1] * (10 + s.h / 2)), n = placed.filter(q => hit(b, q, 1)).length; if (!least || n < least.n) least = { b, n }; }));
            lab = least.b;
          }
        }
        put(lab);
        // (The leader: from the words' nearest edge toward the room's own point, stopping 3 px inside the tan,
        // where its dot is; to a room with no shape, its dot.)
        let lead = null, tip = anchor;
        if (out) {
          lead = [Math.max(lab.x0, Math.min(anchor[0], lab.x1)), Math.max(lab.y0, Math.min(anchor[1], lab.y1))];
          const ex = anchor[0] - lead[0], ey = anchor[1] - lead[1], len = Math.hypot(ex, ey);
          if (y.d && len > 1) for (let t = 0; t <= len; t++) { if (inShape((lead[0] + ex * t / len) / k + M0.x0, (lead[1] + ey * t / len) / k + M0.y0, y.r.shape)) { const t2 = Math.min(len, t + 3); tip = [lead[0] + ex * t2 / len, lead[1] + ey * t2 / len]; break; } }
        }
        rooms.push({ y, code: rr.code, name, anchor: tip, dot: !y.d && pt ? at(pt) : null, lab, lead });
      });

      // The doors' names: beside the door, outward from the building first, off the floor and clear of the
      // walls where they can be.
      const names = doors.map(d => {
        const ww = tw(d.word, 10, 700), ox = d.S[0] - mid[0], oy = d.S[1] - mid[1];
        const dirs = DIRS.slice().sort((a, b) => (b[0] * ox + b[1] * oy) - (a[0] * ox + a[1] * oy));
        const boxAt = (dir, r) => {
          const an = Math.abs(dir[0]) > .35 ? (dir[0] > 0 ? 'start' : 'end') : 'middle', sy = Math.abs(dir[1]) > .35 ? Math.sign(dir[1]) : 0;
          const tx = d.S[0] + (an === 'start' ? r : an === 'end' ? -r : 0), ty = d.S[1] + sy * (an === 'middle' ? r + 5 : r * .8);
          const x0 = an === 'start' ? tx : an === 'end' ? tx - ww : tx - ww / 2;
          return { x0, y0: ty - 6.5, x1: x0 + ww, y1: ty + 6.5, tx, ty, an };
        };
        let best = null;
        [9, 15, 24, 36].forEach(r => dirs.forEach((dir, di) => {
          const b = boxAt(dir, r);
          if (!free(b, 2) || onTan(b, null)) return;
          const score = r + 3 * di + 25 * cross(b) + (onFloor(b) ? 30 : 0);
          if (!best || score < best.score) best = { b, score };
        }));
        const pick = best ? best.b : boxAt(dirs[0], 9);
        put(pick);
        return { word: d.word, b: pick };
      });
      return { x, f, g0, M0, k, U, doors, chips, rooms, names };
    }

    // A floor as SVG in a W × H frame, moved by dx, dy: the floor (floorBody), the dots and leaders, the
    // chips, the doors, the words, then the foot (the scale, north). Icons are symbols, each drawn once.
    function draw(L, short, dx, dy, H) {
      const B = L.x.B, n = L.x.floor, k = L.k, id = 'pkf-' + B.code.replace(/[^A-Za-z0-9]/g, '') + '-' + n;
      // (Whole pixels, a point under .8 px off its line left out: on paper the same, and a third lighter.)
      const X = cropOf(k, dx - L.M0.x0 * k, dy - L.M0.y0 * k, W, H, .8);
      const f1 = v => String(Math.round(v * 10) / 10);
      const at = q => f1(q[0] + dx) + ' ' + f1(q[1] + dy);
      const used = new Set();
      let h = '<g class="pv-fl">' + floorBody(L.f, { mode: 'full', dest: L.x.rooms.map(r => r.number), g0: L.g0, X }) + '</g>';
      L.rooms.forEach(r => { if (r.dot) h += '<circle class="pk-fm__dot" transform="translate(' + at(r.dot) + ')" r="5"/>'; });
      L.rooms.forEach(r => { if (r.lead) h += '<path class="pk-fm__ld" d="M' + at(r.lead) + 'L' + at(r.anchor) + '"/><circle class="pk-fm__ldot" transform="translate(' + at(r.anchor) + ')" r="1.8"/>'; });
      L.chips.forEach(ch => {
        h += '<g transform="translate(' + at(ch.p) + ')"><rect class="pk-fm__chip" x="' + f1(-ch.w / 2) + '" y="-8" width="' + ch.w + '" height="16" rx="8"/>' +
          ch.kinds.map((kd, i) => { used.add(kd); return '<use href="#' + id + '-' + kd + '" x="' + f1(-ch.w / 2 + 2.5 + i * 13) + '" y="-6" width="12" height="12"/>'; }).join('') + '</g>';
      });
      let sf = false;
      L.doors.forEach(d => {
        if (d.sf) { sf = true; used.add('access'); h += '<g transform="translate(' + at(d.S) + ')"><circle class="pk-fm__chip" r="8"/><use href="#' + id + '-access" x="-6" y="-6" width="12" height="12"/></g>'; }
        else h += '<g transform="translate(' + at(d.S) + ')">' + entMark(d.a, 1.3) + '</g>';
      });
      const txt = (cls, x, y, t, an) => '<text class="pk-fm__' + cls + '" x="' + f1(x + dx) + '" y="' + f1(y + dy) + '"' + (an && an !== 'middle' ? ' text-anchor="' + an + '"' : '') + '>' + esc(t) + '</text>';
      L.names.forEach(q => { h += txt('door', q.b.tx, q.b.ty, q.word, q.b.an); });
      L.rooms.forEach(r => {
        const s = r.lab.s, cx = (r.lab.x0 + r.lab.x1) / 2;
        s.ls.forEach((l, i) => {
          const y = r.lab.y0 + LH * i + LH / 2;
          // (Code and name on one line: one text, the name a tspan after a gap, centred together.)
          if (l.then) h += '<text class="pk-fm__' + l.cls + '" x="' + f1(cx + dx) + '" y="' + f1(y + dy) + '">' + esc(l.t) + '<tspan class="pk-fm__' + l.then.cls + '" dx="4">' + esc(l.then.t) + '</tspan></text>';
          else h += txt(l.cls, cx, y, l.t, 'middle');
        });
      });
      // The foot: a scale bar in feet (the longest round length up to 110 px) and north.
      const ft = [200, 100, 50, 25, 10].find(v => v * .3048 * k <= 110) || 10, len = ft * .3048 * k, fy = H - FOOT / 2;
      h += '<path class="pk-fm__sb" d="M' + E + ' ' + f1(fy - 3) + 'v4h' + f1(len) + 'v-4"/>' + '<text class="pk-fm__sc" x="' + f1(E + len + 6) + '" y="' + f1(fy) + '" text-anchor="start">' + ft + ' ft</text>';
      h += '<g transform="translate(' + (W - E - 6) + ' ' + f1(fy) + ')"><path class="pk-fm__n" d="M0 -7L4.5 5L0 2.5L-4.5 5Z"/><text class="pk-fm__sc" x="-9" y="0" text-anchor="end">N</text></g>';
      const ink = ' fill="none" stroke="#76623f" stroke-width="3.2" stroke-linecap="round" stroke-linejoin="round"';
      const defs = used.size ? '<defs>' + Array.from(used).map(kd => '<symbol id="' + id + '-' + kd + '" viewBox="0 0 24 24"><path d="' + ICON[kd] + '"' + ink + '/></symbol>').join('') + '</defs>' : '';
      const label = short + ', ' + O.floorName(n) + ': ' + L.rooms.map(r => r.code + ' ' + r.name).join('; ');
      // (Words centre on their point unless they say otherwise: text-anchor on the root, inherited.)
      const svg = '<svg class="pk-fm" viewBox="0 0 ' + W + ' ' + H + '" width="' + W + '" height="' + H + '" text-anchor="middle" role="img" aria-label="' + esc(label) + '">' + defs + h + '</svg>';
      const kinds = ['dest'].concat(KINDS.filter(kd => used.has(kd))).concat(L.doors.some(d => !d.sf) ? ['door'] : []).concat(sf ? ['sf'] : []);
      return { code: B.code, floor: n, caption: short + ' · ' + O.floorName(n), svg, label, kinds, bytes: svg.length };
    }

    const out = [];
    P.list.forEach(B => {
      const xs = list.filter(x => x.B === B);
      if (!xs.length) return;
      const g0 = P.got(B.code, B.entrance), fs = xs.map(x => P.got(B.code, x.floor)).concat(g0 && xs.some(x => x.floor !== B.entrance) ? [g0] : []);
      const M0 = { x0: Math.min.apply(null, fs.map(f => f._box.x)), y0: Math.min.apply(null, fs.map(f => f._box.y)), x1: Math.max.apply(null, fs.map(f => f._box.x + f._box.w)), y1: Math.max.apply(null, fs.map(f => f._box.y + f._box.h)) };
      // The scale: the building's floors and every word of them inside W × H, a step smaller until they fit.
      let k = Math.min((W - 150) / (M0.x1 - M0.x0), (HM - FOOT - 2 * E - 40) / (M0.y1 - M0.y0)), Ls = null, U = null;
      for (let i = 0; i < 16; i++) {
        Ls = xs.map(x => lay(x, P.got(B.code, x.floor), x.floor !== B.entrance ? g0 : null, M0, k));
        U = Ls.reduce((u, L) => ({ x0: Math.min(u.x0, L.U.x0), y0: Math.min(u.y0, L.U.y0), x1: Math.max(u.x1, L.U.x1), y1: Math.max(u.y1, L.U.y1) }), { x0: Infinity, y0: Infinity, x1: -Infinity, y1: -Infinity });
        if (U.x1 - U.x0 <= W - 2 * E && U.y1 - U.y0 <= HM - FOOT - 2 * E) break;
        k *= .94;
      }
      const H = Math.ceil(U.y1 - U.y0 + 2 * E + FOOT), dx = (W - (U.x1 - U.x0)) / 2 - U.x0, dy = E - U.y0;
      const item = itemOfB(c, B, places), short = (item && (shorts[item.name] || M.shortOf(item))) || B.name;
      Ls.forEach(L => out.push(draw(L, short, dx, dy, H)));
    });
    return out;
  }

  M.floors = { load, ready, hasBuild, layer, titleCase, ICON, WHO, ICON_WORD, slot, upgrade, picture, pictureAll, doorOf, stepFreeOf, sheetFloors, sheetLoad, sheet };
})();
