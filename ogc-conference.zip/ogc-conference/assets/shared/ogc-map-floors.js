/*
 * ogc-map-floors.js — the campus's floors on the guide's map (the map area, Nov 5; docs/34 §3–§5, §8–§10).
 *
 * A campus with a public build (tools/campus/build-plugin.py → assets/campus/<slug>/, named for the year
 * in OGC_WP.floors) opens its buildings in place. Zoom in, or choose a place, and the building's roof
 * lifts away: its floor shows as a white card, the Conference's rooms named (or a code plate where a name
 * doesn't fit), the restrooms, stairs and elevators marked, its doors as small triangles, and the floor
 * picker at the side. A chosen room turns tan, with its name plate and the line from the best door along
 * the halls to its own door. A campus with no build has none of this: the map is as it was.
 *
 * Only one building is open at a time, and only its one floor is drawn. Nothing is guessed: the rooms,
 * doors, restrooms and walks are the build's (campus/FORMAT.md, "The public build"); the door line is the
 * quickest walk by its fixed rules (Dijkstra by time, step-free first); "nearest" is measured along those
 * walks, in feet (feet()). The build has no dorm or Lodge in it, and no number or name for a room that
 * isn't the Conference's (docs/34 §11, §12.6).
 *
 * The planner (Nov 5, round 2 part 2; ogc-map-route.js plans, ogc-map-app.js asks): with a route shown
 * (route()), the door line gives way to the route, which the map draws (viewer.route); the layer names
 * the route's doors, puts a floor-change pill where it changes floor (a tap shows that floor), dots the
 * picker's floors it uses, opens a building asked for (focus(): a step on a laptop, Set start) and takes
 * one tap on an opened floor as where you are (pick()).
 */
(function () {
  'use strict';
  const O = window.OGC, M = O && O.map;
  if (!M) return;
  const esc = O.esc;
  const reduced = () => window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  const BUILT = { hall: 1, dining: 1, worship: 1, venue: 1, other: 1 };

  /* ================================================================ the build */

  const loads = {};
  // The year's build (its index), or null: no build, no server, or it didn't come.
  function load(year) {
    const W = window.OGC_WP || {}, href = W.floors && W.floors[String(year)];
    if (!href || !window.fetch) return Promise.resolve(null);
    const url = new URL(href, location.href).href;
    return loads[url] || (loads[url] = fetch(url, { credentials: 'same-origin' }).then(r => r.ok ? r.json() : null)
      .then(ix => ix && ix.format === 1 ? plansOf(ix, url) : null)
      .catch(() => { delete loads[url]; return null; }));
  }
  // "Floor plans: IWU": the campus's initials from its name in the build (three words or more), else its name.
  function creditOf(slug) {
    const w = String(slug || '').split('-').filter(Boolean);
    if (w.length >= 3) return w.map(x => x.charAt(0).toUpperCase()).join('');
    return w.map(x => x.charAt(0).toUpperCase() + x.slice(1)).join(' ');
  }
  function plansOf(ix, url) {
    const P = { ix, list: [], by: {}, places: ix.places || {}, entrances: ix.entrances || [], credit: 'Floor plans: ' + creditOf(ix.campus) };
    (ix.buildings || []).forEach(b => {
      const B = { name: b.name, code: String(b.code || '').toUpperCase(), middle: b.middle || null, entrance: +b.entrance_floor || 1,
        // A floor placed more than a metre off never opens on the campus (docs/34 §3.5).
        ok: !(b.placement && +b.placement.residual_m > 1), floors: (b.floors || []).map(f => +f.floor).sort((p, q) => p - q), href: {} };
      (b.floors || []).forEach(f => { B.href[+f.floor] = new URL(f.href, url).href; });
      if (B.code && B.floors.length) { P.list.push(B); P.by[B.code] = B; }
    });
    const got = {}, wait = {}, fail = {};
    P.got = (code, n) => got[code + '-' + n] || null;
    // A floor that didn't come (no signal and not kept yet, a dropped line, an error) is asked for again
    // after 30 s or when the phone is back online, never every frame (the check: 60 requests a second).
    P.missing = (code, n) => !!fail[code + '-' + n];
    P.onChange = null;
    const changed = () => { if (P.onChange) P.onChange(); };
    const miss = k => { if (fail[k]) return; fail[k] = setTimeout(() => { delete fail[k]; changed(); }, 30000); changed(); };
    addEventListener('online', () => { const ks = Object.keys(fail); if (!ks.length) return; ks.forEach(k => { clearTimeout(fail[k]); delete fail[k]; }); changed(); });
    P.floor = (code, n) => {
      const k = code + '-' + n, B = P.by[code];
      if (got[k]) return Promise.resolve(got[k]);
      if (!B || !B.href[n] || fail[k]) return Promise.resolve(null);
      return wait[k] || (wait[k] = fetch(B.href[n], { credentials: 'same-origin' }).then(r => r.ok ? r.json() : null)
        .then(f => { delete wait[k]; if (!f) { miss(k); return null; } return (got[k] = prep(f)); })
        .catch(() => { delete wait[k]; miss(k); return null; }));
    };
    P.floorsOf = code => Promise.all((P.by[code] ? P.by[code].floors : []).map(n => P.floor(code, n))).then(l => l.filter(Boolean));
    // The walking graph and the area as the build has them (the planner's router reads them raw: Nov 5,
    // round 2 part 2), and the graph made ready for the door line and Nearby. One fetch each, kept; one that
    // didn't come is asked for again next time.
    let walkP = null, rawP = null, areaP = null;
    const json = (href, done) => fetch(new URL(href, url).href, { credentials: 'same-origin' }).then(r => r.ok ? r.json() : null).then(x => { if (!x) done(); return x; }).catch(() => { done(); return null; });
    P.walkRaw = () => rawP || (rawP = ix.walk && ix.walk.href ? json(ix.walk.href, () => { rawP = null; }) : Promise.resolve(null));
    P.area = () => areaP || (areaP = ix.area && ix.area.href ? json(ix.area.href, () => { areaP = null; }) : Promise.resolve(null));
    P.walk = () => walkP || (walkP = P.walkRaw().then(w => { if (!w) { walkP = null; return null; } return graph(w); }));
    // A place's rooms in the build: [{ floor, number }] (none: a whole building, or not in the build).
    P.roomsOf = code => { const p = P.places[String(code || '').toUpperCase()]; return p ? p.rooms || [] : null; };
    return P;
  }

  // A shape (rings of flat x, y lists) as an SVG path, and its box.
  const ring = r => { let s = 'M' + r[0].toFixed(2) + ' ' + r[1].toFixed(2); for (let i = 2; i < r.length - 1; i += 2) s += 'L' + r[i].toFixed(2) + ' ' + r[i + 1].toFixed(2); return s + 'Z'; };
  const path = rs => (rs || []).filter(r => r && r.length >= 6).map(ring).join('');
  function boxOfRings(rs) {
    let x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity;
    (rs || []).forEach(r => { for (let i = 0; i < r.length - 1; i += 2) { x0 = Math.min(x0, r[i]); x1 = Math.max(x1, r[i]); y0 = Math.min(y0, r[i + 1]); y1 = Math.max(y1, r[i + 1]); } });
    return x0 < Infinity ? { x: x0, y: y0, w: x1 - x0, h: y1 - y0 } : null;
  }
  const titleCase = s => String(s || '').toLowerCase().replace(/(^|[\s/(-])([a-z])/g, (m, a, b) => a + b.toUpperCase());
  // A floor file made ready to draw once: its paths, and its rooms by number.
  function prep(f) {
    f._out = path(f.outline);
    f._box = boxOfRings(f.outline);
    // Walls and columns are drawn solid at their true thickness, each part one path (they have holes).
    f._walls = (f.walls || []).map(path).join('');
    // IWU's structural columns: drawn only in the Detail band (§3.2 layer 8 has none; at building zoom a
    // hall of them read as a dotted line).
    f._cols = (f.columns || []).map(path).join('');
    f._voids = (f.voids || []).map(path).join('');
    f._rooms = (f.rooms || []).map(r => ({ r, d: path(r.shape), box: boxOfRings(r.shape),
      // Where you walk (halls, lobbies, vestibules), what's shut (stairs, elevators), and the rest as rooms.
      cls: r.hall || r.kind === 'entrance' ? 'is-hall' : r.kind === 'stairs' || r.kind === 'elevator' ? 'is-shut' : 'is-room' }));
    f._by = {};
    f._rooms.forEach(x => { if (x.r.public && x.r.number) f._by[x.r.number] = x; });
    // The elevator's ✕ across its car.
    f._lift = f._rooms.filter(x => x.r.kind === 'elevator' && x.r.box).map(x => { const b = x.r.box, a = b[0] - b[2] / 2, c = b[0] + b[2] / 2, t = b[1] - b[3] / 2, u = b[1] + b[3] / 2; return 'M' + a.toFixed(2) + ' ' + t.toFixed(2) + 'L' + c.toFixed(2) + ' ' + u.toFixed(2) + 'M' + a.toFixed(2) + ' ' + u.toFixed(2) + 'L' + c.toFixed(2) + ' ' + t.toFixed(2); }).join('');
    return f;
  }

  /* ================================================================ the walks inside */

  function graph(w) {
    const nc = w.node_cols || [], ec = w.edge_cols || [], N = (w.nodes || []).length;
    const ni = k => nc.indexOf(k), ei = k => ec.indexOf(k);
    const X = new Float64Array(N), Y = new Float64Array(N), F = new Int16Array(N), Bd = new Int16Array(N), PASS = new Float32Array(N), OUT = new Uint8Array(N);
    const [ix, iy, ifl, ib, ip, io] = ['x', 'y', 'floor', 'building', 'pass', 'out'].map(ni);
    w.nodes.forEach((n, i) => { X[i] = n[ix]; Y[i] = n[iy]; F[i] = n[ifl]; Bd[i] = n[ib]; PASS[i] = +n[ip] || 0; OUT[i] = n[io] ? 1 : 0; });
    const [ia, ibb, ik, im, isf, isec, inum, ibd, iv] = ['a', 'b', 'kind', 'm', 'step_free', 'seconds', 'number', 'building', 'via'].map(ei);
    const E = (w.edges || []).map(e => ({ a: e[ia], b: e[ibb], kind: e[ik], m: +e[im] || 0, sf: e[isf] !== 0, sec: +e[isec] || 0, num: String(e[inum] == null ? '' : e[inum]), bd: e[ibd], via: e[iv] || [] }));
    const adj = Array.from({ length: N }, () => []);
    E.forEach((e, i) => { adj[e.a].push(i); adj[e.b].push(i); });
    return { N, X, Y, F, Bd, PASS, OUT, E, adj, ends: w.ends || {}, names: w.buildings || [] };
  }
  // Quickest walks from a room's ways in (FORMAT.md): a row's length at 1.3 m/s, plus a stair's or an
  // elevator's seconds, plus a node's pass seconds when walking on past it (never where a walk starts).
  function walkFrom(G, src, ok, stop) {
    const d = new Float64Array(G.N).fill(Infinity), m = new Float64Array(G.N), prev = new Int32Array(G.N).fill(-1), done = new Uint8Array(G.N), start = new Uint8Array(G.N);
    const heap = [];
    const push = (c, n) => { heap.push([c, n]); let i = heap.length - 1; while (i > 0) { const p = (i - 1) >> 1; if (heap[p][0] <= heap[i][0]) break; [heap[p], heap[i]] = [heap[i], heap[p]]; i = p; } };
    const pop = () => { const top = heap[0], last = heap.pop(); if (heap.length) { heap[0] = last; let i = 0; for (;;) { const l = 2 * i + 1, r = l + 1; let s = i; if (l < heap.length && heap[l][0] < heap[s][0]) s = l; if (r < heap.length && heap[r][0] < heap[s][0]) s = r; if (s === i) break; [heap[s], heap[i]] = [heap[i], heap[s]]; i = s; } } return top; };
    src.forEach(n => { if (n >= 0 && n < G.N) { d[n] = 0; start[n] = 1; push(0, n); } });
    while (heap.length) {
      const [du, u] = pop();
      if (done[u]) continue;
      done[u] = 1;
      if (stop && !start[u] && stop(u)) return { d, m, prev, end: u };
      const extra = start[u] ? 0 : G.PASS[u];
      G.adj[u].forEach(i => {
        const e = G.E[i];
        if (ok && !ok(e)) return;
        const v = e.a === u ? e.b : e.a, c = du + extra + e.m / 1.3 + (e.kind === 'stairs' || e.kind === 'elevator' ? e.sec : 0);
        if (c < d[v]) { d[v] = c; m[v] = m[u] + e.m; prev[v] = i; push(c, v); }
      });
    }
    return { d, m, prev, end: -1 };
  }
  const endsOf = (G, code, floor, number) => G.ends[code + '|' + floor + '|' + number] || null;
  // The line from the best door to a room's own door: the quickest way out to a door that's open to
  // visitors (the build's named entrances, not key only), step-free when there is one. Traced back, with
  // the room's own rows at the end left off, so it stops at the room's door, never inside the tan.
  function doorLine(G, P, B, floor, number, keyOnly) {
    const bi = G.names.indexOf(B.name), src = endsOf(G, B.code, floor, number);
    if (bi < 0 || !src) return null;
    const ents = P.entrances.filter(e => e.code === B.code && !(keyOnly && keyOnly(e.door)));
    const doorAt = {};
    G.E.forEach(e => {
      if (e.kind !== 'entrance') return;
      const inside = G.OUT[e.a] ? e.b : e.a;
      if (G.Bd[inside] !== bi) return;
      const en = ents.find(x => x.number === e.num);
      if (en) doorAt[inside] = en;
    });
    const ok = sf => e => e.kind !== 'entrance' && G.Bd[e.a] === bi && G.Bd[e.b] === bi && (!sf || e.sf);
    let r = walkFrom(G, src, ok(true), u => !!doorAt[u]), stepFree = true;
    if (r.end < 0) { r = walkFrom(G, src, ok(false), u => !!doorAt[u]); stepFree = false; }
    if (r.end < 0) return null;
    const steps = [];
    let u = r.end;
    while (r.prev[u] >= 0) { const e = G.E[r.prev[u]], v = e.a === u ? e.b : e.a; steps.push({ e, from: u, to: v }); u = v; }
    const popped = [];
    while (steps.length && steps[steps.length - 1].e.kind === 'room' && steps[steps.length - 1].e.num === String(number)) popped.push(steps.pop());
    // The room's own rows, from where the line stops on into the room: the line is run on along them to the
    // room's edge or the wall it meets (finish()), so it reaches the room instead of stopping in the hall.
    const tail = [];
    for (let i = popped.length - 1; i >= 0; i--) {
      const st = popped[i], e = st.e, via = [];
      for (let j = 0; j < e.via.length - 1; j += 2) via.push([e.via[j], e.via[j + 1]]);
      if (e.a !== st.from) via.reverse();
      if (!tail.length) tail.push([G.X[st.from], G.Y[st.from]]);
      via.forEach(p => tail.push(p));
      tail.push([G.X[st.to], G.Y[st.to]]);
    }
    const parts = [];
    let cur = null;
    steps.forEach(st => {
      const e = st.e;
      if (e.kind === 'stairs' || e.kind === 'elevator') { cur = null; return; }
      const f = G.F[st.from], via = [];
      for (let i = 0; i < e.via.length - 1; i += 2) via.push([e.via[i], e.via[i + 1]]);
      if (e.a !== st.from) via.reverse();
      if (!cur || cur.floor !== f) { cur = { floor: f, pts: [[G.X[st.from], G.Y[st.from]]] }; parts.push(cur); }
      via.forEach(p => cur.pts.push(p));
      cur.pts.push([G.X[st.to], G.Y[st.to]]);
    });
    const end = steps.length ? steps[steps.length - 1].to : r.end;
    return { door: doorAt[r.end], parts, m: r.m[end], stepFree, at: [G.X[end], G.Y[end]], endFloor: G.F[end], tail, tailFloor: popped.length ? G.F[popped[popped.length - 1].from] : null,
      change: steps.filter(st => st.e.kind === 'stairs' || st.e.kind === 'elevator').map(st => st.e.kind)[0] || '' };
  }
  // The floor's walls and columns as segments, once (for the line's last stretch and its straightening).
  function segsOf(f) {
    if (f._segs) return f._segs;
    const out = [];
    [].concat(f.walls || [], f.columns || []).forEach(part => (part || []).forEach(r => { for (let i = 0; i + 1 < r.length; i += 2) { const j = (i + 2) % r.length; out.push(r[i], r[i + 1], r[j], r[j + 1]); } }));
    return (f._segs = new Float64Array(out));
  }
  // Where a→b first crosses one of the segments (t along a→b, 0 < t < 1), or null.
  function cross(a, b, segs, from) {
    let best = null;
    const dx = b[0] - a[0], dy = b[1] - a[1], x0 = Math.min(a[0], b[0]), x1 = Math.max(a[0], b[0]), y0 = Math.min(a[1], b[1]), y1 = Math.max(a[1], b[1]);
    for (let i = 0; i < segs.length; i += 4) {
      const px = segs[i], py = segs[i + 1], qx = segs[i + 2], qy = segs[i + 3];
      if (Math.max(px, qx) < x0 || Math.min(px, qx) > x1 || Math.max(py, qy) < y0 || Math.min(py, qy) > y1) continue;
      const ex = qx - px, ey = qy - py, den = dx * ey - dy * ex;
      if (!den) continue;
      const t = ((px - a[0]) * ey - (py - a[1]) * ex) / den, u = ((px - a[0]) * dy - (py - a[1]) * dx) / den;
      if (t > (from || 1e-6) && t < 1 - 1e-6 && u >= 0 && u <= 1 && (!best || t < best)) best = t;
    }
    return best;
  }
  // a→b clear of the walls and columns, and 15 cm from their corners.
  function clearOf(a, b, f) {
    const segs = segsOf(f);
    if (cross(a, b, segs) != null) return false;
    const dx = b[0] - a[0], dy = b[1] - a[1], l = dx * dx + dy * dy, x0 = Math.min(a[0], b[0]) - .15, x1 = Math.max(a[0], b[0]) + .15, y0 = Math.min(a[1], b[1]) - .15, y1 = Math.max(a[1], b[1]) + .15;
    for (let i = 0; i < segs.length; i += 4) {
      const px = segs[i], py = segs[i + 1];
      if (px < x0 || px > x1 || py < y0 || py > y1) continue;
      const t = l ? Math.max(0, Math.min(1, ((px - a[0]) * dx + (py - a[1]) * dy) / l)) : 0;
      if (t > .02 && t < .98 && Math.hypot(px - a[0] - t * dx, py - a[1] - t * dy) < .15) return false;
    }
    return true;
  }
  // The line drawn as walked, with its small kinks taken out: from each point, straight on to the farthest
  // point within 6 m along it that can be reached in a straight line clear of the walls. The walk is the
  // same; only its drawing is straighter (the check: a fish-hook in Barnes' south lobby).
  function straighten(pts, f) {
    if (pts.length < 3) return pts;
    const cum = [0];
    for (let i = 1; i < pts.length; i++) cum.push(cum[i - 1] + Math.hypot(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1]));
    const out = [pts[0]];
    let i = 0;
    while (i < pts.length - 1) {
      let j = i + 1;
      for (let q = pts.length - 1; q > i + 1; q--) { if (cum[q] - cum[i] <= 6 && clearOf(pts[i], pts[q], f)) { j = q; break; } }
      out.push(pts[j]); i = j;
    }
    return out;
  }
  // The line's last stretch run on into the room (doorLine's tail) until it meets the room's edge or a wall,
  // then every stretch on a floor straightened.
  function finish(line, P, B, number) {
    if (!line) return line;
    const last = line.parts[line.parts.length - 1], tail = line.tail || [];
    const f = line.tailFloor != null ? P.got(B.code, line.tailFloor) : null, x = f && f._by[String(number)];
    const room = [];
    if (x) (x.r.shape || []).forEach(r => { for (let i = 0; i + 1 < r.length; i += 2) { const j = (i + 2) % r.length; room.push(r[i], r[i + 1], r[j], r[j + 1]); } });
    const onIt = f && x && last && +last.floor === +line.tailFloor;
    if (onIt && tail.length > 1) {
      const segs = new Float64Array(Array.from(segsOf(f)).concat(room));
      for (let i = 0; i < tail.length - 1; i++) {
        const t = cross(tail[i], tail[i + 1], segs);
        if (t != null) { last.pts.push([tail[i][0] + (tail[i + 1][0] - tail[i][0]) * t, tail[i][1] + (tail[i + 1][1] - tail[i][1]) * t]); break; }
        last.pts.push(tail[i + 1]);
      }
    }
    line.parts.forEach(p => { const fl = P.got(B.code, +p.floor); if (fl) p.pts = straighten(p.pts, fl); });
    // Then it stops where it first goes into the room, wherever that falls (§3.1: it never enters the tan).
    // The build's room node can sit metres inside (PPAC 150: 6 m in, with a bend in the middle of the room).
    if (onIt && room.length) last.pts = clipAt(last.pts, new Float64Array(room), x.r.shape);
    return line;
  }
  // Inside a room's shape (its rings, even-odd).
  function inShape(px, py, shape) {
    let c = false;
    (shape || []).forEach(r => { for (let i = 0, n = r.length; i + 1 < n; i += 2) { const j = (i + 2) % n, xi = r[i], yi = r[i + 1], xj = r[j], yj = r[j + 1]; if ((yi > py) !== (yj > py) && px < (xj - xi) * (py - yi) / (yj - yi) + xi) c = !c; } });
    return c;
  }
  // A line cut where it first crosses into the shape (a crossing that only clips a corner doesn't count).
  function clipAt(pts, segs, shape) {
    for (let i = 0; i < pts.length - 1; i++) {
      const a = pts[i], b = pts[i + 1], len = Math.hypot(b[0] - a[0], b[1] - a[1]) || 1;
      let t = 0;
      while ((t = cross(a, b, segs, t)) != null) {
        const q = [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t], u = Math.min(1, t + .1 / len);
        if (inShape(a[0] + (b[0] - a[0]) * u, a[1] + (b[1] - a[1]) * u, shape)) return pts.slice(0, i + 1).concat([q]);
      }
    }
    return pts;
  }
  // The nearest restroom and elevator from a room's door, along the halls (docs/34 §4.3). A restroom a
  // visitor can't use (the build marks it walk: false) and a locker room are left out.
  function nearestFrom(G, B, floors, floor, number) {
    const bi = G.names.indexOf(B.name), src = endsOf(G, B.code, floor, number);
    if (bi < 0 || !src) return null;
    const r = walkFrom(G, src, e => e.kind !== 'entrance' && G.Bd[e.a] === bi && G.Bd[e.b] === bi);
    const best = list => {
      let b = null;
      list.forEach(x => (endsOf(G, B.code, x.floor, x.number) || []).forEach(n => { if (r.d[n] < Infinity && (!b || r.d[n] < b.d)) b = { x, d: r.d[n], m: r.m[n] }; }));
      return b;
    };
    const rest = [], lifts = [];
    floors.forEach(f => {
      (f.restrooms || []).forEach(x => { const rm = f._by[x.number]; if (x.walk !== false && !(rm && /LOCKER|SHOWER|TEAM|STAFF/i.test(rm.r.name || ''))) rest.push(Object.assign({ floor: f.floor }, x)); });
      (f.elevators || []).forEach(x => lifts.push(Object.assign({ floor: f.floor }, x)));
    });
    const rr = best(rest), ll = best(lifts);
    // "Restrooms" when the nearest is one of a women's and men's pair (the other within 15 m on its floor).
    if (rr) {
      const w = rr.x.who, pair = (w === 'women' || w === 'men') && rest.some(o => o.floor === rr.x.floor && o.who === (w === 'women' ? 'men' : 'women') && Math.hypot(o.at[0] - rr.x.at[0], o.at[1] - rr.x.at[1]) <= 15);
      rr.word = pair ? 'Restrooms' : WHO[w] || 'Restroom';
    }
    return { rest: rr, lift: ll, stairsOnly: !lifts.length && floor !== B.entrance };
  }
  const WHO = { women: 'Women', men: 'Men', family: 'Family restroom', unknown: 'Restroom' };

  /* ================================================================ icons (24-unit line icons, I1) */

  const ICON = {
    women: 'M12 6.5a1.75 1.75 0 1 0 0-3.5 1.75 1.75 0 0 0 0 3.5ZM10.25 20.5v-5H8l2.4-6.9a1.5 1.5 0 0 1 1.4-1h.4a1.5 1.5 0 0 1 1.4 1L16 15.5h-2.25v5',
    men: 'M12 6.5a1.75 1.75 0 1 0 0-3.5 1.75 1.75 0 0 0 0 3.5ZM9.5 20.5V14l-1-.5V10A1.5 1.5 0 0 1 10 8.5h4a1.5 1.5 0 0 1 1.5 1.5v3.5l-1 .5v6.5M12 14.5v6',
    family: 'M8.5 6.5a1.75 1.75 0 1 0 0-3.5 1.75 1.75 0 0 0 0 3.5ZM5.5 20.5v-6.5l-1-.5V10A1.5 1.5 0 0 1 6 8.5h5A1.5 1.5 0 0 1 12.5 10v3.5l-1 .5v6.5M17 11a1.4 1.4 0 1 0 0-2.8 1.4 1.4 0 0 0 0 2.8ZM15 20.5v-4l-.7-.5v-2.2a1 1 0 0 1 1-1h3.4a1 1 0 0 1 1 1V16l-.7.5v4',
    unknown: 'M7.5 6a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3ZM5.5 20.5V15l-1-.5v-4A1.5 1.5 0 0 1 6 9h3a1.5 1.5 0 0 1 1.5 1.5v4l-1 .5v5.5M16.5 6a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3ZM15 20.5V16h-2.2l2-6.2A1.2 1.2 0 0 1 16 9h1a1.2 1.2 0 0 1 1.2.8l2 6.2H18v4.5',
    stairs: 'M3.5 19.5h4.5v-4h4v-4h4v-4h4.5',
    elevator: 'M5.5 3.5h13v17h-13ZM9.5 9.5 12 7l2.5 2.5M9.5 14.5 12 17l2.5-2.5',
    access: 'M10.5 5.5a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3ZM10.5 7.5V13h5l2.5 5.5M10.5 10h4.5M8 10.6a5.2 5.2 0 1 0 7.6 6.6'
  };
  const ICON_WORD = { women: 'Women', men: 'Men', family: 'Family restroom', unknown: 'Restroom', stairs: 'Stairs', elevator: 'Elevator' };

  /* ================================================================ the layer on the map */

  // inner: the viewer's insides (M.viewer(...).extend). P: the build. o:
  //   nameOf(code) → the place's name without its building ("Henry West Room 143")
  //   shortOf(B) → the building's short name ("Barnes"); keyOnly(doorId), stepFree(doorId), openOf(doorId)
  //   onMark(kind, data) (a door or an icon tapped), onRoom(code) (a Conference room tapped)
  //   onFloor(code, n) (the floor shown changed), onEscape(), caption (a laptop's floor caption)
  //   covers() → elements floating over the map (labels keep off them); onMissing() (a floor didn't come, or came back)
  function layer(inner, P, o) {
    o = o || {};
    const { svg, root, c, hooks } = inner;
    const G = k => svg.querySelector('.pv-' + k);
    const fls = G('fls'), marks = G('marks');
    root.classList.add('has-floors');
    hooks.motion = true;
    // Zoomed in to 24 px a metre at most, and out to the Conference's buildings fitted, times 0.8 (§3.4).
    hooks.limits = EXT => {
      const s = inner.size(), minW = s.W / 24;
      const maxW = EXT ? s.W * Math.max(EXT.w / s.W, EXT.h / s.H) / .8 : Math.max(c.bounds.w, c.bounds.h) * 1.4;
      return { minW, maxW: Math.max(maxW, minW * 2) };
    };
    // Each building's outline on the campus (its parts: Luckey Arena is drawn beside the Rec Center).
    P.list.forEach(B => {
      B.items = c.items.filter(i => BUILT[i.kind] && i.pts.length > 2 && (M.norm(i.name) === M.norm(B.name) || (i.code && (i.code.toUpperCase() === B.code || i.code.toUpperCase().indexOf(B.code + '/') === 0))));
      B.item = B.items.find(i => i.lab) || B.items[0] || null;
      B.names = Array.from(new Set(B.items.map(i => i.name)));
      const xs = [].concat.apply([], B.items.map(i => i.pts.map(p => p[0]))), ys = [].concat.apply([], B.items.map(i => i.pts.map(p => p[1])));
      B.box = xs.length ? { x: Math.min.apply(null, xs), y: Math.min.apply(null, ys), w: Math.max.apply(null, xs) - Math.min.apply(null, xs), h: Math.max.apply(null, ys) - Math.min.apply(null, ys) } : null;
      B.short = o.shortOf ? o.shortOf(B) : B.name;
    });
    // route: the planner's route (its doors, pills and floors); prefer: a building asked to open (a step,
    // Set start); pick: Set start's one tap on the opened floor.
    const S = { dest: null, line: null, ring: null, shown: {}, key: '#', open: null, band: '', hidden: [], gen: 0, picked: null, home: 0, route: null, prefer: null, pick: null };
    // A floor that didn't come (or came back): drawn again, and the app told (it shows the place as a campus
    // with no plans would, its building tan, until the floor is here).
    P.onChange = () => { S.key = '#'; inner.draw(); if (o.onMissing) o.onMissing(); };
    const sOf = () => 1 / inner.px();

    // ---- which building opens (§3.5)
    // The visible map's middle: not under the search bar, the sheet, the panel or the picker.
    function middle() {
      const s = inner.size(), t = inner.inset(), r = s.r;
      const x = r.left + ((t.left || 0) + s.W - (t.right || 0)) / 2, y = r.top + (t.top + s.H - t.bottom) / 2;
      return inner.toWorld(x, y);
    }
    function focusAt(s) {
      const m = middle();
      let best = null, bd = Infinity;
      P.list.forEach(B => {
        if (!B.ok || !B.items.length) return;
        B.items.forEach(i => { const d = M.inPoly(m.x, m.y, i.pts) ? 0 : edge(m.x, m.y, i.pts) * s; if (d < bd) { bd = d; best = B; } });
      });
      return bd <= 60 ? best : null;
    }
    function edge(x, y, pts) { let d = Infinity; for (let i = 0; i < pts.length; i++) { const a = pts[i], b = pts[(i + 1) % pts.length], dx = b[0] - a[0], dy = b[1] - a[1], l = dx * dx + dy * dy, t = l ? Math.max(0, Math.min(1, ((x - a[0]) * dx + (y - a[1]) * dy) / l)) : 0; d = Math.min(d, Math.hypot(x - a[0] - t * dx, y - a[1] - t * dy)); } return d; }
    // Any of a building in the visible map (not under the search bar, the sheet, the panel or the picker).
    function shows(B) {
      if (!B.box) return false;
      const s = inner.size(), t = inner.inset(), r = s.r;
      const a = inner.toWorld(r.left + (t.left || 0), r.top + t.top), b = inner.toWorld(r.left + s.W - (t.right || 0), r.top + s.H - t.bottom);
      return B.box.x < b.x && B.box.x + B.box.w > a.x && B.box.y < b.y && B.box.y + B.box.h > a.y;
    }
    // Its floor and its entrance floor both came (or are coming): a floor that didn't come never opens,
    // and the app shows the place as a campus with no plans would (its building tan).
    const can = (B, n) => !P.missing(B.code, n) && !P.missing(B.code, B.entrance);
    function want(s) {
      const f = focusAt(s), cur = S.open && P.by[S.open.code];
      // A building asked for (a step on a laptop, Set start) comes before the destination's.
      const pick = code => code && P.by[code] && P.by[code].ok ? P.by[code] : null;
      const D = pick(S.prefer) || pick(S.dest && S.dest.code);
      // The destination's building stays open while any of it shows (§3.2 layer 9, §4.3): the sheet pulled
      // down to peek, or a small pan, never closes it for the building now in the middle.
      // (Off screen altogether, walking in from the town, the destination isn't open: no picker for a
      // building you can't see; one asked for still opens.)
      let B = null;
      if (D && (shows(D) || (!f && D === pick(S.prefer)))) B = D;
      else if (f && (s >= 2 || (cur === f && S.open.mode === 'full' && s >= 1.6 && !S.home))) B = f;
      if (B) {
        const floor = S.shown[B.code] || B.entrance;
        if (!can(B, floor)) return null;
        // After Home (the campus fitted), the destination's building is its simple floor until you zoom in.
        return { B, floor, mode: s >= 2 || (s >= 1.2 && !S.home) ? 'full' : 'simple' };
      }
      if (f && s >= 1.2 && can(f, f.entrance)) return { B: f, floor: f.entrance, mode: 'hint' };
      return null;
    }

    // ---- drawing the floor (layer 8, 9, 10)
    const wholeDest = B => !!(S.dest && S.dest.code === B.code && !(S.dest.rooms || []).length);
    const destRooms = (B, n) => S.dest && S.dest.code === B.code ? (S.dest.rooms || []).filter(r => +r.floor === +n).map(r => String(r.number)) : [];
    function floorSvg(w, f, g0) {
      const B = w.B, n = w.floor, dest = destRooms(B, n);
      if (w.mode === 'hint') return '<path class="pv-fl__hint" d="' + f._walls + '"/>';
      let h = '';
      // (a) the entrance floor's outline under an upper floor that covers only part of the building.
      if (g0 && g0 !== f) h += '<path class="pv-fl__ground" d="' + g0._out + '"/>';
      h += '<path class="pv-fl__base" d="' + f._out + '"/>';
      if (w.mode === 'full') {
        if (f._voids) h += '<path class="pv-fl__void" d="' + f._voids + '"/>';
        // (c) halls and what's shut; the Conference's rooms (taps find them); the destination in tan.
        h += f._rooms.map(x => {
          const code = x.r.public && x.r.codes && x.r.codes[0], isDest = x.r.public && dest.indexOf(String(x.r.number)) > -1;
          if (!x.d || (!code && !isDest && x.cls === 'is-room')) return '';
          return '<path class="pv-fl__r ' + (isDest ? 'is-dest' : x.cls) + '" d="' + x.d + '"' + (code ? ' data-rm="' + esc(code) + '"' : '') + '/>';
        }).join('');
        // (d) the elevator's ✕, (e) the walls, solid, (f) the outline's edge.
        if (f._lift) h += '<path class="pv-fl__x" d="' + f._lift + '"/>';
        h += '<path class="pv-fl__w" d="' + f._walls + '"/>';
        if (f._cols) h += '<path class="pv-fl__w pv-fl__col" d="' + f._cols + '"/>';
      } else {
        h += f._rooms.filter(x => x.r.public && x.d && dest.indexOf(String(x.r.number)) > -1).map(x => '<path class="pv-fl__r is-dest" d="' + x.d + '"/>').join('');
      }
      // A whole building chosen (B, W, Y): its open floor edged in tan-ink, where a room would be tan (layer 9).
      h += '<path class="pv-fl__edge' + (wholeDest(B) ? ' is-dest' : '') + '" d="' + f._out + '"/>';
      h += lineSvg(B, n);
      return h;
    }
    // The door-to-room line: on the floor shown, a 3 px tan-ink line on a white casing; on another floor,
    // tan-ink dots (§3.2 layer 10).
    function lineSvg(B, n) {
      const L = S.line;
      // With a route shown, the map draws the route itself (viewer.route), not the door line.
      if (!L || S.route || !S.dest || S.dest.code !== B.code) return '';
      const d = pts => 'M' + pts.map(p => p[0].toFixed(2) + ' ' + p[1].toFixed(2)).join('L');
      return L.parts.map(p => p.pts.length < 2 ? '' : +p.floor === +n
        ? '<path class="pv-fl__case" d="' + d(p.pts) + '"/><path class="pv-fl__line" d="' + d(p.pts) + '"/>'
        : '<path class="pv-fl__dots" d="' + d(p.pts) + '"/>').join('');
    }

    // ---- marks (layer 11–12): screen-sized, scaled by the viewer each frame
    const mk = (cls, x, y, p, inside, extra) => '<g class="pv-mark ' + cls + '" data-x="' + x.toFixed(2) + '" data-y="' + y.toFixed(2) + '" data-p="' + p + '"' + (extra || '') + '>' + inside + '</g>';
    const icon = (k, size) => '<g transform="translate(' + (-size / 2) + ' ' + (-size / 2) + ') scale(' + (size / 24).toFixed(4) + ')"><path class="pv-ico" d="' + ICON[k] + '" style="stroke-width:' + (1.6 * 24 / size).toFixed(2) + 'px"/></g>';
    let ctx2d = null;
    function textW(t, px, weight) {
      if (!ctx2d) ctx2d = document.createElement('canvas').getContext('2d');
      ctx2d.font = (weight || 700) + ' ' + px + 'px ' + (getComputedStyle(root).fontFamily || 'sans-serif');
      return ctx2d.measureText(t).width;
    }
    // A door: the architect's entry mark, a solid triangle on the wall pointing in; a checked step-free door,
    // the accessible icon in a white chip; the line's door, bigger, with its name (§3.6).
    function doorMark(B, e, route) {
      const mid = B.middle || (B.box ? [B.box.x + B.box.w / 2, B.box.y + B.box.h / 2] : e.at), a = Math.atan2(mid[1] - e.at[1], mid[0] - e.at[0]) * 180 / Math.PI;
      const sf = o.stepFree && o.stepFree(e.door);
      const sc = route ? 11 / 7 : 1;
      let inner_ = '<circle class="pv-hit" r="22"/>' + (sf ? '<circle class="pv-chip__bg" r="10"/>' + icon('access', 14) : '<path class="pv-ent" d="M4 0L-3 4L-3 -4Z" transform="rotate(' + a.toFixed(1) + ') scale(' + sc + ')"/>');
      if (route && e.name) {
        // Its name on the outside, away from the building; when the line comes in from that side, along
        // the wall on the side the line isn't (the name never sits over the line).
        let ox = -Math.cos(a * Math.PI / 180), oy = -Math.sin(a * Math.PI / 180);
        const vs = S.route && S.route.appr && S.route.appr[e.code + ':' + e.number];
        const anchor = dx => Math.abs(dx) > .35 ? (dx > 0 ? 'start' : 'end') : 'middle';
        if (vs) {
          // The eight ways out of the wall, nearest the outward one first: the first whose name (13 px
          // text, measured) stays 8 px clear of the line's first 80 px each way from the door (outside
          // and in), else the clearest.
          const w = textW(doorWord(e), 13), out = [];
          for (let k = 0; k < 8; k++) { const t = k * Math.PI / 4, dx = Math.cos(t), dy = Math.sin(t); if (dx * ox + dy * oy >= -.1) out.push([dx, dy]); }
          out.sort((p, q) => (q[0] * ox + q[1] * oy) - (p[0] * ox + p[1] * oy));
          const clear = ([dx, dy]) => {
            const ax = dx * 15, ay = dy * 15, an = anchor(dx), x0 = an === 'start' ? ax : an === 'end' ? ax - w : ax - w / 2, b = [x0, ay - 9, x0 + w, ay + 9];
            let m = Infinity;
            vs.forEach(v => { for (let t = 6; t <= 80; t += 6) { const px = v[0] * t, py = v[1] * t; m = Math.min(m, Math.hypot(Math.max(b[0] - px, 0, px - b[2]), Math.max(b[1] - py, 0, py - b[3]))); } });
            return m;
          };
          const pick = out.find(c => clear(c) >= 8) || out.slice().sort((p, q) => clear(q) - clear(p))[0];
          if (pick) { ox = pick[0]; oy = pick[1]; }
        }
        const side = anchor(ox);
        inner_ += '<text class="pv-door__t" x="' + (ox * 15).toFixed(1) + '" y="' + (oy * 15).toFixed(1) + '" style="text-anchor:' + side + '"' + (vs ? ' data-v="' + vs.map(v => v[0].toFixed(3) + ',' + v[1].toFixed(3)).join(';') + '"' : '') + '>' + esc(doorWord(e)) + '</text>';
      }
      return mk('pv-door2' + (route ? ' is-route' : '') + (sf ? ' is-sf' : ''), e.at[0], e.at[1], route ? 3 : 6, inner_, ' data-mk="ent:' + esc(B.code) + ':' + esc(e.number) + '"');
    }
    // "North doors, east" is the build's name; a name the COA gave the door (campus.csv's label) wins.
    const doorWord = e => (o.labelOf && o.labelOf(e.door)) || e.name || 'Entrance';
    // The floor-change pill (§3.6): a white pill, 26 px, a 1.5 px tan-ink ring, the stairs or elevator icon
    // and the other floor's numeral ("▲ 2"); its 44 px tap shows that floor. Placed before the route's doors
    // (2, not 3), so a door's name moves to a clear side of it, never under it (round 2: "No▲2doors").
    function pillMark(B, q, n) {
      const to = +q.from === +n ? +q.to : +q.from, word = (to > +n ? '▲ ' : '▼ ') + (to < 1 ? 'L' : String(to));
      const tw = textW(word, 12), w = 8 + 14 + 5 + tw + 10;
      return mk('pv-pill', q.at[0], q.at[1], 2, '<circle class="pv-hit" r="22"/><rect x="' + (-w / 2).toFixed(1) + '" y="-13" width="' + w.toFixed(1) + '" height="26" rx="13"/>' +
        '<g transform="translate(' + (-w / 2 + 8 + 7).toFixed(1) + ' 0)">' + icon(q.lift ? 'elevator' : 'stairs', 14) + '</g><text x="' + (-w / 2 + 8 + 14 + 5).toFixed(1) + '" y="1">' + esc(word) + '</text>',
        ' data-mk="pill:' + esc(B.code) + ':' + to + '" aria-label="' + esc(M.floorName(to)) + '"');
    }
    function chip(B, n, kind, x, num, word) {
      return mk('pv-chip', x.at[0], x.at[1], 6, '<circle class="pv-hit" r="22"/><circle class="pv-chip__bg" r="11"/>' + icon(kind, 16) + '<text class="pv-chip__w" x="16" y="4">' + esc(word) + '</text>',
        ' data-mk="feat:' + esc(B.code) + ':' + n + ':' + kind + ':' + esc(num) + '"');
    }
    // A Conference room's name (up to two lines, inside it) or, when the name doesn't fit, its code plate.
    function roomMark(B, n, x, code) {
      const r = x.r, at = r.box ? [r.box[0], r.box[1]] : r.at;
      if (!at) return '';
      const first = (P.places[code] || { rooms: [] }).rooms[0];
      const name = first && +first.floor === +n && String(first.number) === String(r.number) ? (o.nameOf ? o.nameOf(code) : code) : titleCase(r.name);
      // The code after the slash ("HW"); a place that is a whole room under its building's code (the Chapel's
      // auditorium and balcony, J) shows that code, never IWU's number (120 and 220 meant nothing to anyone).
      const tag = code.indexOf('/') > -1 ? code.split('/')[1] : code;
      // Two lines at the space nearest the middle.
      const words = name.split(' ');
      let lines = [name];
      if (words.length > 1) { let best = null; for (let i = 1; i < words.length; i++) { const a = words.slice(0, i).join(' '), b = words.slice(i).join(' '), m = Math.max(textW(a, 14), textW(b, 14)); if (!best || m < best[2]) best = [a, b, m]; } lines = [name, best[0], best[1]]; }
      // Its number under its name in the Detail band, unless the name already says it.
      const numT = y => new RegExp('(^|\\D)' + String(r.number).replace(/[^\w]/g, '') + '(\\D|$)').test(name) ? '' : '<text class="pv-room__n" y="' + y + '">' + esc(r.number) + '</text>';
      const w1 = textW(name, 14), w2 = lines.length > 1 ? Math.max(textW(lines[1], 14), textW(lines[2], 14)) : w1, tw = textW(tag, 12), pw = Math.max(20, tw + 12);
      return mk('pv-room', at[0], at[1], 5,
        '<g class="pv-room__one"><text y="1">' + esc(name) + '</text>' + numT(17) + '</g>' +
        (lines.length > 1 ? '<g class="pv-room__two"><text y="-7">' + esc(lines[1]) + '</text><text y="10">' + esc(lines[2]) + '</text>' + numT(26) + '</g>' : '') +
        '<g class="pv-room__plate"><rect x="' + (-pw / 2).toFixed(1) + '" y="-10" width="' + pw.toFixed(1) + '" height="20" rx="5"/><text y="1">' + esc(tag) + '</text></g>',
        ' data-rmk="' + esc(code) + '" data-w1="' + w1.toFixed(1) + '" data-w2="' + w2.toFixed(1) + '" data-bw="' + (r.box ? r.box[2] : 0) + '" data-bh="' + (r.box ? r.box[3] : 0) + '" data-nw="' + textW(String(r.number), 12, 400).toFixed(1) + '"' +
        ' data-a="' + (r.box ? r.box[2] * r.box[3] : 0).toFixed(0) + '" data-tw="' + pw.toFixed(1) + '" data-ox="' + at[0].toFixed(2) + '" data-oy="' + at[1].toFixed(2) + '"');
    }
    // The destination's name plate, above the tan shape, with its tail (§3.3); below it when the line's door
    // comes in from above, so the plate never covers the door.
    // The top of a floor's outline straight above or below x (where a whole building's plate points).
    function topAt(f, x) {
      let y = Infinity;
      (f.outline || []).forEach(r => { for (let i = 0; i + 1 < r.length; i += 2) { const j = (i + 2) % r.length, x0 = r[i], x1 = r[j]; if ((x0 <= x) !== (x1 <= x)) y = Math.min(y, r[i + 1] + (r[j + 1] - r[i + 1]) * (x - x0) / (x1 - x0)); } });
      return y < Infinity ? y : f._box.y;
    }
    function plateMark(x, y, name, below, box) {
      const w = textW(name, 15) + 16, h = 26, q = below ? -1 : 1;
      const room = box ? ' data-room="' + [box.x, box.y, box.x + box.w, box.y + box.h].map(n => n.toFixed(2)).join(',') + '" data-o="' + x.toFixed(2) + ',' + y.toFixed(2) + '" data-pw="' + w.toFixed(1) + '"' + (below ? ' data-below="1"' : '') : '';
      return mk('pv-plate', x, y, 1, '<path d="M-6 ' + (-7 * q) + 'L0 ' + (-1 * q) + 'L6 ' + (-7 * q) + 'Z"/><rect x="' + (-w / 2).toFixed(1) + '" y="' + (below ? 7 : -7 - h) + '" width="' + w.toFixed(1) + '" height="' + h + '" rx="5"/><text y="' + (below ? 7 + h / 2 + 1 : -7 - h / 2 + 1) + '">' + esc(name) + '</text>', room);
    }
    function marksSvg(w, f) {
      const B = w.B, n = w.floor;
      let h = '';
      const full = w.mode === 'full';
      // Doors: on every planned building from the Building band, on the floor that has them. The route's
      // doors (or, with no route, the door line's) are the big ones, named.
      const big = S.route ? S.route.doors : S.line && S.line.door && S.dest ? [S.line.door] : [];
      P.list.forEach(b => {
        const open = S.open && S.open.code === b.code && w.mode !== 'hint' ? S.open.floor : b.entrance;
        P.entrances.filter(e => e.code === b.code && +e.floor === +open).forEach(e => { if (big.indexOf(e) < 0) h += doorMark(b, e, false); });
      });
      big.forEach(e => { const b = P.by[e.code]; if (b) h += doorMark(b, e, true); });
      // Where the route changes floor, on the floor shown at either end of it: a pill to the other floor.
      if (S.route && f && w.mode !== 'hint') S.route.pills.forEach(q => { if (q.code === B.code && (+q.from === +n || +q.to === +n)) h += pillMark(B, q, n); });
      if (f && full) {
        (f.restrooms || []).forEach(x => { if (x.at) h += chip(B, n, x.who && ICON[x.who] ? x.who : 'unknown', x, x.number, WHO[x.who] || 'Restroom'); });
        (f.stairs || []).forEach(x => { if (x.at) h += chip(B, n, 'stairs', x, x.number, 'Stairs'); });
        (f.elevators || []).forEach(x => { if (x.at) h += chip(B, n, 'elevator', x, x.number, 'Elevator'); });
        const dest = destRooms(B, n);
        f._rooms.forEach(x => { const code = x.r.public && x.r.codes && x.r.codes[0]; if (code && dest.indexOf(String(x.r.number)) < 0) h += roomMark(B, n, x, code); });
        // The laptop's caption: BARNES · 1ST FLOOR, outside the building's south-west corner.
        if (o.caption && f._box) h += mk('pv-cap', f._box.x, f._box.y + f._box.h + 6, 4, '<text>' + esc((B.short + ' · ' + M.floorName(n)).toUpperCase()) + '</text><path d="M0 18H' + textW((B.short + ' · ' + M.floorName(n)).toUpperCase(), 12).toFixed(1) + '"/>');
      }
      // The destination: the room's name plate; a whole building's, its short name over its top.
      if (S.dest && S.dest.code === B.code && w.mode !== 'hint') {
        const dr = destRooms(B, n);
        const x = f && dr.length ? f._by[dr[0]] : null;
        if (x) {
          const rd = S.route && S.route.doors.find(e => e.code === B.code);
          const door = rd ? rd.at : S.line && S.line.door ? S.line.door.at : null;
          const below = !!(x.box && door && door[1] < x.box.y + x.box.h / 2);
          const top = x.box ? [x.box.x + x.box.w / 2, below ? x.box.y + x.box.h : x.box.y] : x.r.at;
          const first = (S.dest.rooms || [])[0];
          // (A room asked for by IWU's name, the Chapel's Balcony, is that name: d.name.)
          const name = first && String(first.number) === String(x.r.number) && +first.floor === +n ? (S.dest.name || (o.nameOf ? o.nameOf(S.dest.place || S.dest.code) : S.dest.code)) : titleCase(x.r.name);
          if (top) h += plateMark(top[0], top[1], name, below, x.box);
          if (!x.box && x.r.at) h += mk('pv-dot', x.r.at[0], x.r.at[1], 2, '<circle r="6"/>');
        }
        // A whole building: its name plate over the top of its floor (it slides along inside it, as a room's does).
        if (wholeDest(B) && f && f._box) { const cx = f._box.x + f._box.w / 2; h += plateMark(cx, topAt(f, cx), B.short, false, f._box); }
      }
      if (S.ring && S.ring.code === B.code && +S.ring.floor === +n) h += mk('pv-ring', S.ring.at[0], S.ring.at[1], 2, '<circle r="17"/>');
      return h;
    }

    // ---- drawing, when what's wanted changes
    function hideRoofs(B) {
      S.hidden.forEach(e => { e.style.display = ''; });
      S.hidden = [];
      if (!B) return;
      B.names.forEach(n => svg.querySelectorAll('.pv-shapes [data-b="' + CSS.escape(n) + '"]').forEach(e => { e.style.display = 'none'; S.hidden.push(e); }));
      const sel = G('sel'); if (S.picked && B.names.indexOf(S.picked) > -1) { sel.style.display = 'none'; S.hidden.push(sel); }
    }
    let roofT = 0;
    function render(w, force) {
      const key = w ? w.mode + '|' + w.B.code + '|' + w.floor + '|' + (S.dest ? S.dest.code + (S.dest.rooms || []).map(r => r.floor + ':' + r.number).join(',') : '') + '|' + (S.line ? 1 : 0) + '|' + (S.ring ? S.ring.at.join(',') : '') + '|' + (S.route ? S.route.key : '') : (S.route ? 'r|' + S.route.key : '');
      if (key === S.key && !force) return;
      const f = w ? P.got(w.B.code, w.floor) : null, g0 = w ? P.got(w.B.code, w.B.entrance) : null;
      // Not here yet: what's drawn stays until it comes (one fetch, kept for the guide offline).
      // Asked once; when it doesn't come, want() stops asking for it (P.missing) until it may again.
      if (w && (!f || !g0)) {
        if (S.key === key + '|wait') return;
        S.key = key + '|wait';
        Promise.all([P.floor(w.B.code, w.floor), P.floor(w.B.code, w.B.entrance)]).then(() => { if (S.key === key + '|wait') { S.key = '#'; inner.draw(); } });
        return;
      }
      const was = S.open, isOpen = !!(w && f && w.mode !== 'hint');
      const changed = !was !== !isOpen || (was && isOpen && (was.code !== w.B.code || was.floor !== w.floor));
      const up = was && isOpen && was.code === w.B.code ? Math.sign(w.floor - was.floor) : 0;
      S.key = key;
      const gen = ++S.gen;
      // Out: the old floor fades as the roof comes back (200 ms); in: the new one fades in. Changing floor
      // (§4.9): going up, the old floor drops 8 px as it fades and the new one comes down from 8 px above;
      // going down, the other way. (Its own way in stops first, so it can fade: it held it before.)
      Array.from(fls.children).forEach(old => {
        if (!changed || reduced()) { old.remove(); return; }
        old.classList.remove('is-in');
        if (up) old.style.setProperty('--pv-out', (8 * up * inner.px()).toFixed(3) + 'px');
        old.classList.add('is-out'); old.removeAttribute('data-b'); setTimeout(() => old.remove(), 220);
      });
      if (w && f) {
        const g = document.createElementNS('http://www.w3.org/2000/svg', 'g');
        g.setAttribute('class', 'pv-fl is-' + w.mode + (changed && !reduced() ? ' is-in' : ''));
        if (w.mode !== 'hint') g.setAttribute('data-b', w.B.item ? w.B.item.name : w.B.name);
        if (up) g.style.setProperty('--pv-up', (-8 * up * inner.px()).toFixed(3) + 'px');
        g.innerHTML = floorSvg(w, f, g0);
        fls.appendChild(g);
      }
      S.open = isOpen ? { code: w.B.code, floor: w.floor, mode: w.mode } : null;
      // The roof lifts away once the floor is over it; closing, it's back at once.
      clearTimeout(roofT);
      if (isOpen) { if (changed && was && was.code === w.B.code) hideRoofs(w.B); else if (changed && !reduced()) roofT = setTimeout(() => { if (S.gen === gen) hideRoofs(w.B); }, 200); else hideRoofs(w.B); }
      else hideRoofs(null);
      const hb = (S.dest && P.by[S.dest.code]) || P.list[0];
      marks.innerHTML = w ? marksSvg(w, f) : ((S.line && S.dest) || (S.route && hb)) ? marksSvg({ B: hb, floor: S.shown[hb.code] || hb.entrance, mode: 'hint' }, null) : allDoors();
      // The picker with the whole floor only (a simple floor at campus zoom is an outline and the tan room).
      picker(isOpen && w.mode === 'full' ? w : null);
      const lab = isOpen ? 'Campus map · ' + w.B.short + ' ' + M.floorName(w.floor) : 'Campus map';
      if (root.getAttribute('aria-label') !== lab) root.setAttribute('aria-label', lab);
      const cr = root.querySelector('.pv-credit');
      if (cr) cr.textContent = M.CREDIT + (isOpen ? ' · ' + P.credit : '');
      if (changed && isOpen && o.onFloor) o.onFloor(w.B.code, w.floor);
      inner.draw();
    }
    const allDoors = () => P.list.map(b => P.entrances.filter(e => e.code === b.code && +e.floor === +b.entrance).map(e => doorMark(b, e, false)).join('')).join('');

    // ---- the floor picker (§4.4)
    let pk = null;
    function picker(w) {
      if (!w) { if (pk) { pk.remove(); pk = null; } root.classList.remove('has-picker'); return; }
      const B = w.B, list = B.floors.slice().reverse();
      if (!pk || pk.dataset.code !== B.code) {
        if (pk) pk.remove();
        pk = document.createElement('div');
        pk.className = 'pv-floors'; pk.dataset.code = B.code;
        pk.setAttribute('role', 'radiogroup'); pk.setAttribute('aria-label', B.short + ' floors');
        pk.innerHTML = '<p class="pv-floors__h" aria-hidden="true">' + esc(B.code) + '</p><div class="pv-floors__l"><span class="pv-floors__w" aria-hidden="true"></span>' +
          list.map(n => '<button type="button" role="radio" data-fl="' + n + '" aria-label="' + esc(M.floorName(n)) + '" title="' + esc(M.floorName(n)) + '">' + (n < 1 ? 'L' : n) + '<i aria-hidden="true"></i></button>').join('') + '</div>';
        pk.addEventListener('click', e => { const b = e.target.closest('[data-fl]'); if (b) show(+b.dataset.fl, true); });
        pk.addEventListener('keydown', e => {
          const i = list.indexOf(S.open ? S.open.floor : -1);
          const j = e.key === 'ArrowUp' || e.key === 'ArrowLeft' ? i - 1 : e.key === 'ArrowDown' || e.key === 'ArrowRight' ? i + 1 : -2;
          if (j === -2 || j < 0 || j >= list.length) return;
          e.preventDefault(); show(list[j], true); const nb = pk.querySelector('[data-fl="' + list[j] + '"]'); if (nb) nb.focus();
        });
        root.appendChild(pk);
        root.classList.add('has-picker');
        pk.querySelector('.pv-floors__w').style.transition = 'none';
      }
      // A dot on each other floor the destination or the route (or, with no route, the door line) uses.
      const dest = (S.dest && S.dest.code === B.code ? (S.dest.rooms || []).map(r => +r.floor).concat(S.line && !S.route ? S.line.parts.map(p => +p.floor) : []) : [])
        .concat(S.route && S.route.floors[B.code] ? S.route.floors[B.code] : []);
      pk.querySelectorAll('[data-fl]').forEach((b, i) => {
        const n = +b.dataset.fl, on = n === w.floor;
        b.setAttribute('aria-checked', String(on)); b.tabIndex = on ? 0 : -1;
        b.classList.toggle('is-on', on);
        b.querySelector('i').hidden = on || dest.indexOf(n) < 0;
        if (on) { const wsh = pk.querySelector('.pv-floors__w'); wsh.style.transform = 'translateY(' + (i * 44) + 'px)'; requestAnimationFrame(() => { wsh.style.transition = ''; }); }
      });
    }
    // A floor shown (the picker, PageUp and PageDown, a Nearby row on another floor).
    function show(n, say) {
      const code = S.open ? S.open.code : S.dest ? S.dest.code : null, B = code && P.by[code];
      if (!B || B.floors.indexOf(+n) < 0) return;
      S.shown[code] = +n;
      render(want(sOf()));
      if (say) liveSay(M.floorName(n));
    }
    function liveSay(t) { const l = root.querySelector('[data-live]'); if (l) { l.textContent = ''; requestAnimationFrame(() => { l.textContent = t; }); } }

    // ---- each frame: what's wanted, and the bands
    let bandSet = '';
    hooks.paint.push(k => {
      const s = 1 / k;
      // (A shadow on the map is in map units: kept at 2 px on screen.)
      fls.style.setProperty('--pv-k', k.toFixed(4));
      render(want(s));
      // The open building's own name gives way to its rooms' (its code is on the picker); a simple floor
      // keeps it, as a closed building would.
      if (S.open && S.open.mode === 'full') { const B = P.by[S.open.code]; inner.labs().forEach(t => { if (B.names.indexOf(t.dataset.n) > -1) t.style.display = 'none'; }); }
      // Home's campus view lasts until you zoom in again (past its own move).
      if (S.home && s >= 2 && performance.now() > S.home) S.home = 0;
      fls.classList.toggle('z-d', s >= 8);
      const band = (s >= 1.2 ? 'b' : '') + (s >= 1.6 ? 'r' : '') + (s >= 2 ? 'f' : '') + (s >= 3 ? 'c' : '') + (s >= 8 ? 'd' : '');
      if (band !== bandSet) { bandSet = band; marks.setAttribute('class', 'pv-marks z-' + (band.split('').join(' z-') || 'campus')); }
    });
    // Before the buildings' names: the destination's plate, the ring and the line's door (they always show).
    const place = (g, k) => g.setAttribute('transform', 'translate(' + g.dataset.x + ' ' + g.dataset.y + ') scale(' + k.toFixed(4) + ')');
    const boxOfMark = (g, k) => { let b; try { b = g.getBBox(); } catch (e) { return null; } if (!b.width) return null; const x = +g.dataset.x, y = +g.dataset.y; return { x0: x + b.x * k, y0: y + b.y * k, x1: x + (b.x + b.width) * k, y1: y + (b.y + b.height) * k }; };
    const inView = (b, v, k) => b.x0 >= v.x0 + 8 * k && b.x1 <= v.x1 - 8 * k && b.y0 >= v.y0 + 8 * k && b.y1 <= v.y1 - 8 * k;
    const hitsAny = (b, placed, pad) => placed.some(p => !p.floor && b.x0 - pad < p.x1 && b.x1 + pad > p.x0 && b.y0 - pad < p.y1 && b.y1 + pad > p.y0);
    // Marks crowd by what's drawn, not by their 44 px tap circles (hidden while measuring, pre to post).
    hooks.pre.push((placed, v) => {
      const k = v.k, pad = 4 * k;
      // What floats over the map from outside it (a laptop's panel) is in every label's way (§3.3): a name
      // that would cross it is dropped, never left half under it.
      (o.covers ? o.covers() : []).forEach(el => { const r = el && el.getBoundingClientRect(); if (!r || !r.width) return; const a = inner.toWorld(r.left, r.top), b = inner.toWorld(r.right, r.bottom); placed.push({ x0: a.x, y0: a.y, x1: b.x, y1: b.y, hard: true }); });
      marks.classList.add('is-measure');
      Array.from(marks.querySelectorAll('.pv-mark')).filter(g => +g.dataset.p <= 4).sort((a, b) => a.dataset.p - b.dataset.p).forEach(g => {
        g.style.visibility = '';
        // Zoomed in past a room's edge, its plate slides along inside the room to stay on screen.
        if (g.dataset.room) {
          const r = g.dataset.room.split(',').map(Number), o0 = g.dataset.o.split(',').map(Number), hw = (+g.dataset.pw / 2 + 8) * k, ph = 41 * k, m = 8 * k;
          let x = Math.min(Math.max(o0[0], Math.max(r[0], v.x0 + m + hw)), Math.min(r[2], v.x1 - m - hw));
          // (2 px further in than the edge it must clear: placed exactly on it, a rounding of 0.005 hid the
          // plate of Barnes 133, the Intramural Gym and PPAC; the check, round 2.)
          let y = o0[1];
          if (g.dataset.below) { if (y + ph > v.y1 - 2 * k) y = Math.max(r[1], v.y1 - ph - 2 * k); }
          else if (y - ph < v.y0 + 2 * k) y = Math.min(r[3], v.y0 + ph + 2 * k);
          if (!(x >= r[0] && x <= r[2])) x = o0[0];
          g.dataset.x = x.toFixed(2); g.dataset.y = y.toFixed(2);
          g.setAttribute('transform', 'translate(' + g.dataset.x + ' ' + g.dataset.y + ') scale(' + k.toFixed(4) + ')');
        }
        // The line's door names itself beside its mark, on whichever side is clear (never under the plate);
        // with no side clear, the mark stays and its name waits.
        const t = g.querySelector('.pv-door__t');
        const put = q => { t.setAttribute('x', q[0]); t.setAttribute('y', q[1]); t.style.textAnchor = q[2]; };
        if (t) { if (!t.dataset.o) t.dataset.o = [t.getAttribute('x'), t.getAttribute('y'), t.style.textAnchor].join('|'); put(t.dataset.o.split('|')); t.style.display = ''; }
        let b = boxOfMark(g, k);
        // (Nor over the route's own line where it meets the door: data-v, the way back along it, Nov 5.)
        const lvs = t && t.dataset.v ? t.dataset.v.split(';').map(s => s.split(',').map(Number)) : null;
        const offLine = () => {
          if (!lvs) return true;
          let tb; try { tb = t.getBBox(); } catch (e) { return true; }
          return lvs.every(lv => { for (let s = 6; s <= 80; s += 6) { const px = lv[0] * s, py = lv[1] * s; if (px > tb.x - 6 && px < tb.x + tb.width + 6 && py > tb.y - 6 && py < tb.y + tb.height + 6) return false; } return true; });
        };
        if (t && b && (hitsAny(b, placed, pad) || !inView(b, v, k))) {
          const tries = [[0, -18, 'middle'], [0, 20, 'middle'], [16, 1, 'start'], [-16, 1, 'end'], [12, -14, 'start'], [-12, -14, 'end'], [12, 16, 'start'], [-12, 16, 'end']];
          let ok = false;
          for (const q of tries) { put(q); b = boxOfMark(g, k); if (b && !hitsAny(b, placed, pad) && inView(b, v, k) && offLine()) { ok = true; break; } }
          if (!ok) { put(t.dataset.o.split('|')); t.style.display = 'none'; b = boxOfMark(g, k); }
        }
        // The laptop's caption is only drawn whole: off the screen or under the panel, it waits. So does the
        // destination's plate when its room is panned off (never half a plate at the edge).
        if (b && g.classList.contains('pv-cap') && (!inView(b, v, k) || hitsAny(b, placed, pad))) { g.style.visibility = 'hidden'; return; }
        if (b && g.dataset.room && !inView(b, v, k)) { g.style.visibility = 'hidden'; return; }
        // The ring keeps every other mark off it, but not the icon it rings (round 2: it circled bare walls).
        if (b && g.classList.contains('pv-ring')) b.ring = [+g.dataset.x, +g.dataset.y];
        if (b) placed.push(b);
      });
      // An open floor is a card the other buildings' names keep off (its own rooms' names are inside it).
      const fl = S.open && S.open.mode === 'full' && P.got(S.open.code, S.open.floor);
      if (fl && fl._box) placed.push({ x0: fl._box.x, y0: fl._box.y, x1: fl._box.x + fl._box.w, y1: fl._box.y + fl._box.h, floor: true });
    });
    // After them: rooms' names or plates, then doors and icons; one that would cross another is left out.
    hooks.post.push((placed, v) => {
      const k = v.k, s = 1 / k, pad = 4 * k, z = bandSet;
      const open = S.open, isDest = open && S.dest && S.dest.code === open.code;
      // The bigger rooms first among the Conference's (where the services and meetings are), so a crowded
      // floor keeps the Globe Theater's plate and slides a small room's along inside it.
      const ms = Array.from(marks.querySelectorAll('.pv-mark')).filter(g => +g.dataset.p > 4).sort((a, b) => a.dataset.p - b.dataset.p || (+b.dataset.a || 0) - (+a.dataset.a || 0));
      ms.forEach(g => {
        let on = true;
        if (g.classList.contains('pv-room')) {
          // A building chosen shows its rooms' names or plates from the Building band (the fit a phone gives
          // Barnes is about 1.4 px a metre); otherwise from the Floor band.
          on = z.indexOf('f') > -1 || (isDest && z.indexOf('b') > -1);
          if (g.dataset.ox) { g.dataset.x = g.dataset.ox; g.dataset.y = g.dataset.oy; place(g, k); }
          if (on) {
            // Its name when it fits inside at 90 %, on one line or two; else its code plate (§3.3).
            const bw = +g.dataset.bw * s * .9, bh = +g.dataset.bh * s, detail = z.indexOf('d') > -1;
            const one = +g.dataset.w1 <= bw && 18 <= bh, two = !one && g.querySelector('.pv-room__two') && +g.dataset.w2 <= bw && 36 <= bh;
            const num = detail && +g.dataset.nw <= bw && (one ? 36 : 52) <= bh;
            g.classList.toggle('is-one', !!one); g.classList.toggle('is-two', !!two); g.classList.toggle('is-plate', !one && !two); g.classList.toggle('has-num', !!num && (one || two));
          }
        } else if (g.classList.contains('pv-chip')) {
          on = z.indexOf('c') > -1;
          g.classList.toggle('has-word', z.indexOf('d') > -1);
        } else if (g.classList.contains('pv-door2')) on = z.indexOf('b') > -1;
        g.style.display = on ? '' : 'none';
        if (!on) return;
        g.style.visibility = '';
        let b = boxOfMark(g, k);
        if (!b) return;
        // The icon a ring is drawn round crowds nothing in it (its word still keeps off the ring).
        const rung = g.classList.contains('pv-chip') ? placed.find(p => p.ring && Math.abs(p.ring[0] - +g.dataset.x) < .05 && Math.abs(p.ring[1] - +g.dataset.y) < .05) : null;
        if (rung) { g.classList.remove('has-word'); b = boxOfMark(g, k); g.style.visibility = ''; placed.push(b); return; }
        // An icon's word goes first if it's what crowds (the icon stays).
        if (g.classList.contains('has-word') && (!inView(b, v, k) || hitsAny(b, placed, pad))) { g.classList.remove('has-word'); b = boxOfMark(g, k); }
        if (g.classList.contains('has-num') && (!inView(b, v, k) || hitsAny(b, placed, pad))) { g.classList.remove('has-num'); b = boxOfMark(g, k); }
        // A code plate that crowds tries the other places inside its own room (its edges, its corners).
        const clear = q => q && inView(q, v, k) && !hitsAny(q, placed, pad);
        if (!clear(b) && g.classList.contains('is-plate') && g.dataset.ox) {
          const ox = +g.dataset.ox, oy = +g.dataset.oy, mx = Math.max(0, +g.dataset.bw / 2 - (+g.dataset.tw / 2 + 3) * k), my = Math.max(0, +g.dataset.bh / 2 - 13 * k);
          const tries = [[0, -my], [0, my], [-mx, 0], [mx, 0], [-mx, -my], [mx, -my], [-mx, my], [mx, my]].filter(q => q[0] || q[1]);
          for (const q of tries) { g.dataset.x = (ox + q[0]).toFixed(2); g.dataset.y = (oy + q[1]).toFixed(2); place(g, k); b = boxOfMark(g, k); if (clear(b)) break; }
          if (!clear(b)) { g.dataset.x = g.dataset.ox; g.dataset.y = g.dataset.oy; place(g, k); b = boxOfMark(g, k); }
        }
        if (!clear(b)) { g.style.visibility = 'hidden'; return; }
        placed.push(b);
      });
      marks.classList.remove('is-measure');
    });

    // ---- taps (§9): a mark, then a Conference room 24 px or more, else zoom in twice around the tap
    hooks.tap = (t, pt) => {
      if (!t || !t.closest) return false;
      // Set start (§4.5): one tap inside the opened floor is where you are (only as good as the tap).
      if (S.pick && S.open && S.open.mode === 'full' && pt) {
        const f = P.got(S.open.code, S.open.floor);
        if (f && inShape(pt.x, pt.y, f.outline)) { S.pick({ x: pt.x, y: pt.y, floor: S.open.floor, code: S.open.code }); return true; }
      }
      const m = t.closest('[data-mk]');
      if (m && m.closest('.pv-marks')) {
        const a = m.dataset.mk.split(':');
        // A floor-change pill shows its floor.
        if (a[0] === 'pill') { S.shown[a[1]] = +a[2]; render(want(sOf())); liveSay(M.floorName(+a[2])); return true; }
        if (o.onMark) o.onMark(a[0], a.slice(1)); return true;
      }
      const rm = t.closest('[data-rm]');
      if (rm) {
        const r = rm.getBoundingClientRect();
        if (Math.min(r.width, r.height) >= 24) { if (o.onRoom) o.onRoom(rm.dataset.rm); return true; }
        const v = inner.v; inner.goTo({ x: pt.x - (pt.x - v.x) * .5, y: pt.y - (pt.y - v.y) * .5, w: v.w * .5, h: v.h * .5 }, true);
        return true;
      }
      return false;
    };
    // ---- keys (§9): PageUp and PageDown change floor, Home fits the campus, Esc closes the place
    hooks.key = e => {
      if ((e.key === 'PageUp' || e.key === 'PageDown') && S.open) {
        const B = P.by[S.open.code], i = B.floors.indexOf(S.open.floor), j = i + (e.key === 'PageUp' ? 1 : -1);
        if (j >= 0 && j < B.floors.length) show(B.floors[j], true);
        return true;
      }
      // Home: the campus, every building closed (the destination's a simple floor) until you zoom in.
      if (e.key === 'Home') { S.home = performance.now() + 450; S.key = '#'; inner.fit(inner.start(), 8, true); return true; }
      if (e.key === 'Escape' && o.onEscape) { o.onEscape(); return true; }
      return false;
    };

    // ---- what the app asks
    const api = {
      P,
      // A place chosen: its building opens on the room's floor, the room in tan with its plate, and the line
      // from the best door. → { B, room (box), door, line, box (room and door together) } once known.
      dest(d) {
        // (Home's campus view ends when a place is opened, not when one is closed: the check, round 2, saw
        // Barnes come back as a tangle at campus scale after Home, then Esc.)
        S.dest = d && P.by[d.code] ? d : null; S.line = null; S.ring = null; if (S.dest) S.home = 0;
        if (!S.dest) { render(want(sOf()), true); return Promise.resolve(null); }
        const B = P.by[d.code], r0 = (d.rooms || [])[0];
        S.shown[B.code] = r0 ? +r0.floor : B.entrance;
        render(want(sOf()), true);
        return Promise.all([P.floorsOf(B.code), r0 ? P.walk() : null]).then(([floors, Gr]) => {
          if (S.dest !== d) return null;
          const line = r0 && Gr ? finish(doorLine(Gr, P, B, +r0.floor, r0.number, o.keyOnly), P, B, r0.number) : null;
          S.line = line;
          render(want(sOf()), true);
          const f = P.got(B.code, r0 ? +r0.floor : B.entrance), x = r0 && f ? f._by[String(r0.number)] : null;
          const room = x ? (x.box || (x.r.at ? { x: x.r.at[0] - 3, y: x.r.at[1] - 3, w: 6, h: 6 } : null)) : null;
          let box = room ? Object.assign({}, room) : null;
          if (box && line && line.door && line.parts.some(p => +p.floor === +r0.floor)) box = grow(box, line.door.at);
          return { B, room, door: line ? line.door : null, line, box: box || B.box };
        });
      },
      // Show a floor ("Balcony · 2nd floor").
      show(n) { show(n, true); },
      // The planner's route (a plan from ogc-map-route.js), or null: its doors named, its floor changes as
      // pills, its floors dotted on the picker. The line itself is the map's (viewer.route).
      route(r) {
        if (!r || !r.ok) { if (S.route) { S.route = null; render(want(sOf()), true); } return; }
        const ent = d => d && d.code ? P.entrances.find(e => e.code === d.code && String(e.number) === String(d.number)) || null : null;
        const doors = [ent(r.door), ent(r.exit)].filter((e, i, a) => e && a.indexOf(e) === i);
        const floors = {}, pills = [];
        (r.parts || []).forEach(p => { if (p.building && p.floor) (floors[p.building] = floors[p.building] || []).push(+p.floor); });
        (r.steps || []).forEach(s => { if (s.kind === 'floor' && s.building) { pills.push({ code: s.building, from: +s.floor, to: +s.floorTo, at: s.at, lift: s.icon === 'elevator' }); (floors[s.building] = floors[s.building] || []).push(+s.floorTo); } });
        // Where the line meets each door, outside and in: unit vectors from the door along it (doorMark).
        const appr = {};
        doors.forEach(e => {
          const best = { out: null, in: null };
          (r.parts || []).forEach(p => {
            if (!p.pts || p.pts.length < 2 || (p.building && p.building !== e.code)) return;
            const side = p.building ? 'in' : 'out';
            [[0, 1], [p.pts.length - 1, -1]].forEach(([i, s]) => {
              const q = p.pts[i], d = Math.hypot(q[0] - e.at[0], q[1] - e.at[1]);
              if (d > 4 || (best[side] && d >= best[side].d)) return;
              let j = i + s;
              while (j > 0 && j < p.pts.length - 1 && Math.hypot(p.pts[j][0] - q[0], p.pts[j][1] - q[1]) < 3) j += s;
              const n = p.pts[j], L = Math.hypot(n[0] - e.at[0], n[1] - e.at[1]);
              if (L) best[side] = { d, v: [(n[0] - e.at[0]) / L, (n[1] - e.at[1]) / L] };
            });
          });
          const vs = [best.out, best.in].filter(Boolean).map(b => b.v);
          if (vs.length) appr[e.code + ':' + e.number] = vs;
        });
        S.route = { doors, floors, pills, appr, key: doors.map(e => e.code + e.number).join(',') + '|' + pills.map(q => q.code + q.from + q.to + q.at.join(',')).join(',') + '|' + (r.parts || []).length };
        render(want(sOf()), true);
      },
      // The floor shown of a building (open, whole or simple), or null.
      shown: code => S.open && S.open.code === code ? S.open.floor : null,
      // A building asked to open on a floor (a step framed, Set start), or null to let the map choose again.
      focus(code, n) {
        const B = code && P.by[String(code).toUpperCase()];
        S.prefer = B ? B.code : null;
        if (B && n != null && B.floors.indexOf(+n) > -1) S.shown[B.code] = +n;
        render(want(sOf()), true);
      },
      // Set start: fn({ x, y, floor, code }) on the next tap inside the opened floor, or null to stop.
      pick(fn) { S.pick = fn || null; root.classList.toggle('is-picking', !!fn); },
      // A place rung on its floor (a Nearby row, a restroom from the list): its floor shown.
      ring(code, n, at) {
        const B = P.by[code]; if (!B || !at) return;
        S.ring = { code, floor: +n, at };
        if (S.open && S.open.code === code && S.open.floor !== +n) liveSay(M.floorName(n));
        S.shown[code] = +n;
        render(want(sOf()), true);
      },
      // The nearest restroom and elevator from a room → rows for the sheet, or null.
      nearby(code, n, number) {
        const B = P.by[code];
        if (!B) return Promise.resolve(null);
        // Only with every floor of the building here: measured on the floors that came, "nearest" could be
        // a floor away from the one that's nearer.
        return Promise.all([P.floorsOf(code), P.walk()]).then(([floors, Gr]) => Gr && floors.length === B.floors.length ? nearestFrom(Gr, B, floors, +n, number) : null);
      },
      // Distances along the halls from a room, to any end in its building → fn(code, floor, number) → metres or null.
      from(code, n, number) {
        const B = P.by[code];
        return P.walk().then(Gr => {
          const bi = Gr && B ? Gr.names.indexOf(B.name) : -1, src = bi > -1 ? endsOf(Gr, code, n, number) : null;
          if (!src) return () => null;
          const r = walkFrom(Gr, src, e => e.kind !== 'entrance' && Gr.Bd[e.a] === bi && Gr.Bd[e.b] === bi);
          return (c2, n2, num2) => { if (c2 !== code) return null; let best = null; (endsOf(Gr, c2, n2, num2) || []).forEach(k => { if (r.d[k] < Infinity && (!best || r.d[k] < best.d)) best = { d: r.d[k], m: r.m[k] }; }); return best ? best.m : null; };
        });
      },
      // Every restroom or elevator in the build's buildings (the Restrooms list; Search's Nearest).
      all(kind) {
        return Promise.all(P.list.map(B => P.floorsOf(B.code).then(fs => ({ B, fs })))).then(bs => {
          const out = [];
          bs.forEach(({ B, fs }) => fs.forEach(f => {
            if (kind === 'restroom') (f.restrooms || []).forEach(x => { const rm = f._by[x.number]; if (x.at && x.walk !== false && !(rm && /LOCKER|SHOWER|TEAM|STAFF/i.test(rm.r.name || ''))) out.push({ B, floor: f.floor, number: x.number, who: x.who || 'unknown', at: x.at, word: WHO[x.who] || 'Restroom' }); });
            else (f.elevators || []).forEach(x => { if (x.at && !out.some(y => y.B === B && Math.hypot(y.at[0] - x.at[0], y.at[1] - x.at[1]) < 3)) out.push({ B, floor: f.floor, number: x.number, floors: x.floors || [f.floor], at: x.at, word: 'Elevator' }); });
          }));
          return out;
        });
      },
      // A feature by its number on a floor (an icon tapped) → { at, who, kind } or null.
      feature(code, n, kind, number) {
        const f = P.got(code, +n); if (!f) return null;
        const list = kind === 'stairs' ? f.stairs : kind === 'elevator' ? f.elevators : f.restrooms;
        return (list || []).find(x => String(x.number) === String(number)) || null;
      },
      // A building whose floor (the one it would open on) didn't come.
      missing(code) { const B = P.by[code]; return !!B && !can(B, S.shown[code] || B.entrance); },
      entrance: (code, number) => P.entrances.find(e => e.code === code && e.number === number) || null,
      open: () => S.open ? Object.assign({}, S.open) : null,
      building: code => P.by[String(code || '').toUpperCase()] || null,
      // The building tinted as a place with no plan (its roof is hidden while it's open).
      picked(name) { S.picked = name || null; S.key = ''; inner.draw(); },
      // The scale that fits a box in what shows of the map, with pad px round it.
      scaleFor(box, pad) {
        const s = inner.size(), t = inner.inset(), q = pad == null ? 24 : pad;
        const aw = Math.max(40, s.W - (t.left || 0) - (t.right || 0) - q * 2), ah = Math.max(40, s.H - t.top - t.bottom - q * 2);
        return Math.min(aw / Math.max(box.w, 1), ah / Math.max(box.h, 1));
      },
      redraw() { S.key = ''; inner.draw(); }
    };
    const grow = (b, p) => { const x0 = Math.min(b.x, p[0]), y0 = Math.min(b.y, p[1]), x1 = Math.max(b.x + b.w, p[0]), y1 = Math.max(b.y + b.h, p[1]); return { x: x0, y: y0, w: x1 - x0, h: y1 - y0 }; };
    inner.draw();
    return api;
  }

  M.floors = { load, layer, titleCase, ICON, WHO, ICON_WORD };
})();
