/*
 * ogc-pickup.js — a new year starts as the last one, picked up (docs/14, docs/15).
 *
 * The year area moved the pickup to the server (includes/module-coa-pickup.php): one action by a
 * person, in one transaction, logged, and never twice. Nothing here runs on a page load.
 *
 *   O.pickup.start(year)        webmasters: POST coa/{y}/start (the year exists; its parts come from
 *                               the last Conference once that one has ended)
 *   O.pickup.pickUp(year, force) members: POST coa/{y}/pickup (with force: before last year ends)
 *   O.pickup.run()              v3's call after the webmasters' "Start 2028" (admin.js): starts every
 *                               year this webmaster can see that has its folder but isn't started yet
 *   O.pickup.moveText, standard, NOT_YET, VENUE_KEYS   as v3, for pages that still use them
 */
(function () {
  'use strict';
  const O = window.OGC, W = window.OGC_WP || {};
  if (!O) return;
  const NOT_YET = '9999-12-31';
  const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  // What a campus sets on the registration form: kept with the campus, like its buildings and halls.
  const VENUE_KEYS = ['room_price', 'room_beds', 'linen_price', 'mattress_price', 'camper_price', 'camper_per', 'key_fee', 'bed_fee', 'yf_age_split', 'price_basis', 'rooms_held'];

  // "Friday, June 5" → "Friday, May 28"; "June 2–7" → "May 25–30". (The server does the same.)
  function moveText(t, fromYear, d) {
    const moved = [];
    const out = String(t || '').replace(/\b(January|February|March|April|May|June|July|August|September|October|November|December)\s+(\d{1,2})(?:st|nd|rd|th)?(?:\s*[–-]\s*(\d{1,2})\b)?/g, (m, mon, d1, d2) => {
      const iso = n => fromYear + '-' + String(MONTHS.indexOf(mon) + 1).padStart(2, '0') + '-' + String(n).padStart(2, '0');
      if (+d1 > 31 || !O.parseISODate(iso(d1))) return m;
      const a = O.isoAddDays(iso(d1), d);
      let rep = O.fmtDate(a, 'md');
      if (d2) { const b = O.isoAddDays(iso(d2), d); rep += '–' + (b.slice(0, 7) === a.slice(0, 7) ? String(+b.slice(8)) : O.fmtDate(b, 'md')); }
      if (rep !== m) moved.push({ from: m, to: rep });
      return rep;
    });
    return { text: out, moved };
  }
  // The rows of the week that are the same every year (docs/14). The rest varies.
  function standard(r) {
    const k = (r.kind || '').toLowerCase(), t = (r.title || '').toLowerCase(), a = r.audience || '';
    if (/^all$/i.test(a)) return /prayer|display/.test(k);
    if (/preteen/i.test(a)) return /registration|devotion|pickup|snack|notice/.test(k);
    if (/young/i.test(a)) return /quiet|devotion|snack|lodging|singing/.test(k) || /teaching for young|^speaker$|sunrise/.test(t);
    return /worship|council|communion|meal|snack|singing|open|on_call|lodging/.test(k) || /check-?(in|out)/.test(t);
  }

  const api = (m, p, b) => W.api(m, p, b);
  const start = y => api('POST', 'coa/' + y + '/start', {});
  const pickUp = (y, force) => api('POST', 'coa/' + y + '/pickup', { force: !!force });
  // After the webmasters' Start: the years with a folder and no pickup log yet are started on the
  // server (only a webmaster may; for anyone else this does nothing).
  async function run() {
    if (!W.api || !W.webmaster) return;
    if (O.store && O.store.flush) await O.store.flush();
    const years = await api('GET', 'years').catch(() => []);
    for (const row of (years || []).filter(z => z.data).sort((a, b) => a.year - b.year)) {
      const has = await api('GET', 'years/' + row.year + '/state/picked').then(() => true, () => false);
      if (!has) await start(row.year).catch(e => console.error('Not started', row.year, e.status));
    }
  }
  O.pickup = { moveText, standard, NOT_YET, VENUE_KEYS, start, pickUp, run: () => run().catch(err => { console.error(err); }) };
})();
