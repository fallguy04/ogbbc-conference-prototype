/*
 * ogc-search.js — the Conference app's one Search (round 3, part C; docs/35 §3.2 "One Search", §3.9).
 *
 * O.search.open(o): a full-screen layer (one O.layers entry; from 768 px the centred dialog). Its field
 * is its head, with ‹ to close and × to clear; no title. One ranked list under it, in groups: Places
 * (the places, rooms by IWU's number, a place's rooms by IWU's name, My room, the restrooms and
 * elevators in the plans), Schedule (one result a row's title and place, the next time said once),
 * Help (the needs), Packet (the information packet's parts) and Care nearby. Before anything is typed:
 * Recent (codes only, this phone), then a few chips. A number ("143") shows Places alone, the schedule
 * rows there in a Schedule fold.
 *   o.which   'search' (the default), or 'from' / 'to' (the planner's ends: My location, My room, Recent,
 *             Choose on map, then what's typed; only what the route can reach)
 *   o.opener  what the focus goes back to (a tap: quietly, no ring; a key: with it)
 *   o.pick    the planner: fn(item), the end chosen
 *   o.endOk   the planner: fn(v), whether a result can be an end
 *   o.onClose fn(how), after it has closed ('go' a choice, 'x' ‹ or a tap outside, 'esc', 'back')
 *   o.refind  fn(opener), when the opener has been drawn again meanwhile (week.js's minute)
 *
 * What it finds comes from the providers, O.search.use(name, p):
 *   p.items(which) → [item] (null while it isn't ready), p.start(which) → [{ ord, label, rows }],
 *   p.chips(which) → [{ ord, label, sub, icon, run(o) }], p.warm(which) (reads what it needs in the
 *   background, then O.search.refresh()), p.tidy(el) (the page's non-breaking spaces).
 * An item: { group, key, title, line, code, v (a place for the planner), go(o), names, keys (the words
 * it is the answer to), words (its own search words, matched whole), nums (IWU's room numbers), bw (its
 * building's words, "Barnes 143"), pw (its place's words), text (its note, menu, paragraphs: whole words
 * only), ord, past, tie (one score for a kind: the restrooms nearest first), slip (a one-letter slip is
 * forgiven: places only), fallback (dropped when another provider has its key) }.
 * ogc-map-app.js gives the places ('map'); week.js the schedule, Help, the packet and care nearby
 * ('week'), and the places from places.csv for a campus with no map. It reads what's already on the
 * phone, so it works without signal.
 *
 * The ranking: a whole title (or code), IWU's number, what it's the answer to, a title starting with
 * the words, then the words at the start of a word inside it; then its own search words, its code, its
 * line, its place, and last its text, by whole words. Never a word inside another ("call" doesn't find
 * Supper's "Scalloped potatoes"; "hen" doesn't find "when"). A few words people use for what the app
 * calls otherwise (SYN) count a little less than the word itself, and less again found only in a card's
 * text; one of several words ("wi fi") is found only as written together, and a typed word of one or two
 * letters only as a whole word. The schedule's results go by how they matched, then the sooner first.
 */
(function () {
  'use strict';
  const O = window.OGC = window.OGC || {};
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const svg = d => '<svg class="ogc-search__i" viewBox="0 0 24 24" aria-hidden="true"><path d="' + d + '" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  const I = { back: svg('M15 5.5 8.5 12l6.5 6.5'), clear: svg('m6.5 6.5 11 11M17.5 6.5l-11 11'), down: svg('m6 9.5 6 6 6-6') };

  // The words people use for what the app calls otherwise. (A next meal is the answer to "menu", "food"
  // and "eat" by its own keys, week.js; a restroom to "bathroom" and "toilet", the map's.)
  const SYN = {
    bathroom: ['restroom'], toilet: ['restroom'], washroom: ['restroom'], lavatory: ['restroom'],
    nurse: ['first aid'], doctor: ['first aid', 'urgent care'], medical: ['first aid', 'urgent care'], sick: ['first aid', 'urgent care'], hurt: ['first aid'], injury: ['first aid'],
    // The information point, once help.csv has one (or the campus a desk): none in 2027, so nothing.
    info: ['information'], desk: ['information'],
    dinner: ['supper'], key: ['lodging'], checkin: ['check in', 'lodging'], checkout: ['check out', 'lodging'], dorm: ['hall', 'lodging'],
    // (A ride is a Ride, not First aid's golf cart: the check, round 3.)
    wifi: ['wi fi', 'internet'], internet: ['wi fi', 'wifi'], car: ['parking', 'rides'], ride: ['rides'], cart: ['golf cart', 'rides'], lost: ['lost and found'],
    church: ['worship'], service: ['worship'], services: ['worship'], sermon: ['worship'], preaching: ['worship'],
    gym: ['recreation', 'arena'], cafeteria: ['dining'], 'love feast': ['communion'], feetwashing: ['communion'], 'feet washing': ['communion'], pickup: ['pick up']
  };
  const GROUPS = ['Places', 'Schedule', 'Help', 'Packet', 'Care nearby'];
  const CAP = { Places: 10, Schedule: 8, Help: 6, Packet: 4, 'Care nearby': 4 };
  const TIE_CAP = { restroom: 4, elevator: 2 };

  /* ------------------------------------------------ matching */

  // Words as typed and as written, compared alike: lower case, no accents, no apostrophes, every other
  // mark a space ("Women’s" is "womens", "3-on-3" is "3 on 3"); a code's slash stays ("b/hw").
  const norm = s => String(s == null ? '' : s).toLowerCase().normalize('NFKD').replace(/[̀-ͯ]/g, '').replace(/['’‘]/g, '').replace(/[^a-z0-9/]+/g, ' ').trim();
  const sing = q => q.length > 3 && /s$/.test(q) ? q.slice(0, -1) : q;
  // q at the start of a word of s ("hen" in "henry west room 143"); never inside one.
  const at = (s, q) => !!s && (' ' + s).indexOf(' ' + q) > -1;
  // q as a whole word of s, or its plural ("call" in "call this number", never in "scalloped").
  const whole = (s, q) => {
    if (!s) return false;
    const x = ' ' + s + ' ';
    return x.indexOf(' ' + q + ' ') > -1 || x.indexOf(' ' + q + 's ') > -1 || (sing(q) !== q && x.indexOf(' ' + sing(q) + ' ') > -1);
  };
  // A one-letter slip in a word of five letters or more ("barns"; places only: "parking" isn't "Kit packing").
  function slip(w, q) {
    if (q.length < 5 || Math.abs(w.length - q.length) > 1) return false;
    let i = 0, j = 0, e = 0;
    while (i < w.length && j < q.length) {
      if (w[i] === q[j]) { i++; j++; continue; }
      if (++e > 1) return false;
      if (w.length > q.length) i++; else if (q.length > w.length) j++; else { i++; j++; }
    }
    return e + (w.length - i) + (q.length - j) <= 1;
  }
  function prep(it) {
    if (it._p) return it._p;
    const N = (it.names && it.names.length ? it.names : [it.title]).map(norm).filter(Boolean);
    it._p = { N, K: (it.keys || []).map(norm).filter(Boolean), W: (it.words || []).map(norm).filter(Boolean), L: norm(it.line), PW: norm((it.pw || []).join(' ')),
      T: norm((it.text || []).join(' ')), B: norm(it.bw), C: String(it.code || '').toUpperCase(), nums: (it.nums || []).map(x => String(x).toLowerCase()) };
    return it._p;
  }
  // A word of several typed apart ("wi fi"): one of one or two letters is a whole word, never the start of
  // one ("wi" isn't "with", "fi" isn't "Fieldhouse": the check, round 3).
  const atw = (s, w) => w.length < 3 ? whole(s, w) : at(s, w);
  // Lower is better; Infinity is no match.
  // phrase: a synonym of several words is found only as they're written together, never word by word.
  function score(it, q, raw, phrase) {
    const p = prep(it), Q = String(raw || q).replace(/\s+/g, '').toUpperCase();
    if (p.N.some(n => n === q) || (p.C && p.C === Q)) return 0;
    if (p.nums.length) {
      if (p.nums.indexOf(q) > -1) return 0.5;
      const m = /^(.+?) (\w+)$/.exec(q);
      if (m && p.nums.indexOf(m[2]) > -1 && at(p.B, m[1])) return 0.5;
    }
    if (p.K.length && (p.K.indexOf(q) > -1 || p.K.indexOf(sing(q)) > -1)) return 0.8;
    if (p.N.some(n => n.indexOf(q) === 0)) return 1;
    if (p.N.some(n => at(n, q))) return 2;
    const ws = !phrase && q.indexOf(' ') > -1 ? q.split(' ') : null;
    if (ws && ws.every(w => p.N.some(n => atw(n, w)))) return 2.2;
    if (p.W.some(w => w === q || w === sing(q) || w === q + 's')) return 3;
    if (p.C && Q.length > 1 && p.C.indexOf(Q) === 0) return 3.5;
    if (p.W.some(w => at(w, q))) return 3.8;
    if (at(p.L, q)) return 4;
    if (at(p.PW, q)) return 4.5;
    if (whole(p.T, q)) return 5;
    if (ws && ws.every(w => p.N.some(n => atw(n, w)) || p.W.some(x => atw(x, w)) || atw(p.L, w) || atw(p.PW, w) || whole(p.T, w))) return 5.5;
    if (it.slip && !ws && q.length >= 5 && p.N.some(n => n.split(' ').some(w => slip(w, q)))) return 6;
    return Infinity;
  }
  // A synonym counts a little less than the word itself, and found only in a card's body text, less again.
  function best(it, q, raw) {
    let s = score(it, q, raw);
    (SYN[q] || SYN[sing(q)] || []).forEach(a => { const y = score(it, a, a, a.indexOf(' ') > -1), x = y + (y >= 5 ? 1.5 : 0.5); if (x < s) s = x; });
    return s;
  }
  // How a result matched, for the schedule's order (round 3's check: "council" put Tuesday's 2:00 PM
  // "Council continues" over its 9:00 AM "Brotherhood Council Meeting"): its whole title; its title; its
  // words, line or place; its text. Within one, the sooner row first.
  const tier = s => s === 0 ? 0 : s < 3 ? 1 : s < 5 ? 2 : 3;
  // A room's number, or a building's name and one ("barnes 143").
  const isNum = t => /^\d{2,4}[a-z]?$/.test(t) || /^[a-z][a-z ]* \d{2,4}[a-z]?$/.test(t);

  /* ------------------------------------------------ the providers */

  const providers = {}, ORDER = ['map', 'week'];
  const names = () => ORDER.concat(Object.keys(providers).filter(n => ORDER.indexOf(n) < 0)).filter(n => providers[n]);
  const each = (fn, arg) => [].concat.apply([], names().map(n => { const p = providers[n]; try { return p[fn] ? p[fn](arg) || [] : []; } catch (e) { if (window.console) console.error(e); return []; } }));

  /* ------------------------------------------------ the layer */

  const S = { which: 'search', o: {}, opener: null, layer: null, items: null, at: 0, rows: [], chips: [], keyed: false };
  let dlg = null;
  const $ = k => dlg.querySelector('[data-s="' + k + '"]');
  function make() {
    dlg = document.createElement('dialog');
    dlg.className = 'ogc ogc-search';
    dlg.setAttribute('aria-label', 'Search');
    dlg.innerHTML = '<div class="ogc-search__head"><button type="button" class="ogc-search__back" data-s="back" aria-label="Back" title="Back">' + I.back + '</button>' +
      '<label class="ogc-search__q"><span class="ogc-sr" data-s="lab">Search</span><input type="search" data-s="q" autocomplete="off" autocapitalize="off" autocorrect="off" spellcheck="false" enterkeyhint="search">' +
      '<button type="button" class="ogc-search__x" data-s="x" aria-label="Clear" title="Clear" hidden>' + I.clear + '</button></label></div>' +
      '<div class="ogc-search__body" data-s="body"></div><p class="ogc-sr" role="status" data-s="say"></p>';
    document.body.appendChild(dlg);
    dlg.addEventListener('cancel', e => { e.preventDefault(); close('esc'); });
    dlg.addEventListener('input', e => { if (e.target === $('q')) draw(); });
    // A key (Esc, Enter, the arrows, Tab) gives the focus back with its ring; a tap, without.
    dlg.addEventListener('pointerdown', () => { S.keyed = false; });
    dlg.addEventListener('keydown', e => {
      if (/^(Escape|Enter|Tab|ArrowUp|ArrowDown)$/.test(e.key)) S.keyed = true;
      const q = $('q');
      if (e.key === 'Enter' && e.target === q) { e.preventDefault(); const b = $('body').querySelector('[data-r]'); if (b && q.value.trim()) b.click(); return; }
      if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
        const all = Array.from(dlg.querySelectorAll('[data-r], [data-c]')), i = all.indexOf(e.target);
        if (e.target === q && e.key === 'ArrowDown' && all[0]) { e.preventDefault(); all[0].focus(); }
        else if (i > -1) { e.preventDefault(); const n = all[i + (e.key === 'ArrowDown' ? 1 : -1)]; (n || (e.key === 'ArrowUp' ? q : null) || e.target).focus(); }
      }
    });
    dlg.addEventListener('click', e => {
      if (e.target === dlg) { close('x'); return; }
      if (e.target.closest('[data-s="back"]')) { close('x'); return; }
      if (e.target.closest('[data-s="x"]')) { const q = $('q'); q.value = ''; draw(); q.focus(); return; }
      const r = e.target.closest('[data-r]'), c = e.target.closest('[data-c]');
      if (r) choose(S.rows[+r.dataset.r]);
      else if (c) chip(S.chips[+c.dataset.c]);
    });
  }
  function open(o) {
    o = o || {};
    if (!dlg) make();
    const which = o.which === 'from' || o.which === 'to' ? o.which : 'search';
    S.which = which; S.o = o; S.items = null; S.keyed = !!o.keyed;
    S.opener = o.opener || document.activeElement;
    const q = $('q'), word = which === 'from' ? 'Choose start' : which === 'to' ? 'Choose destination' : 'Search';
    q.value = ''; q.placeholder = word; $('lab').textContent = word;
    dlg.setAttribute('aria-label', which === 'from' ? 'From' : which === 'to' ? 'To' : 'Search');
    each('warm', which);
    draw();
    if (!dlg.open) {
      dlg.showModal();
      dlg.classList.remove('is-in'); void dlg.offsetWidth; dlg.classList.add('is-in');
      // A layer (docs/35 §2.7): Back closes Search alone, on any tab.
      if (O.layers) S.layer = O.layers.push('search', { close: () => close('back'), el: dlg });
    }
    $('body').scrollTop = 0;
    q.focus();
  }
  // how: 'go' (a choice: what it opens takes the focus), 'x', 'esc' or 'back' (its entry is gone already).
  function close(how) {
    if (!dlg || !dlg.open) return;
    const l = S.layer, o = S.o, keyed = S.keyed || how === 'esc';
    let op = S.opener;
    S.layer = null;
    if (l && how !== 'back' && O.layers && O.layers.top() === l) O.layers.pop(1);
    // (The field loses the focus first: what the dialog gives it back to then draws no ring after a tap,
    // round 3's check: the map's Search pill kept a tan ring once Search had closed.)
    const q = $('q'); if (document.activeElement === q) q.blur();
    if (op && !keyed) quiet(op);
    dlg.close();
    dlg.classList.remove('is-in');
    if (how !== 'go') {
      if (op && !document.contains(op) && o.refind) { o.refind(op); op = null; if (!keyed && document.activeElement !== document.body) quiet(document.activeElement); }
      if (op && document.contains(op)) op.focus({ preventScroll: true });
    }
    if (o.onClose) { try { o.onClose(how); } catch (e) { if (window.console) console.error(e); } }
  }
  // A focus given back after a tap shows no ring, until a key is pressed.
  function quiet(el) { if (el && el.classList) el.classList.add('ogc-quiet'); }
  document.addEventListener('keydown', e => { if (/^(Tab|ArrowUp|ArrowDown|ArrowLeft|ArrowRight|Enter| )$/.test(e.key)) document.querySelectorAll('.ogc-quiet').forEach(x => x.classList.remove('ogc-quiet')); }, true);

  function run(f) { if (O.layers && O.layers.after) O.layers.after(f); else f(); }
  function choose(it) {
    if (!it) return;
    const o = S.o, which = S.which, keyed = S.keyed, opener = S.opener;
    close('go');
    run(() => {
      if (which !== 'search') { if (o.pick) o.pick(it); }
      else if (it.go) it.go({ opener, keyed });
    });
  }
  function chip(c) {
    if (!c) return;
    const opener = S.opener, keyed = S.keyed;
    close('go');
    run(() => c.run({ opener, keyed }));
  }

  /* ------------------------------------------------ what's drawn */

  // Every provider's items, a few seconds at a time (what's on now moves with the minute).
  function items() {
    const now = Date.now();
    if (S.items && now - S.at < 15000) return S.items;
    let all = each('items', S.which);
    const real = new Set(all.filter(x => !x.fallback).map(x => x.key));
    all = all.filter(x => x && x.title && (!x.fallback || !real.has(x.key)));
    if (S.which !== 'search') all = all.filter(x => x.v && (!S.o.endOk || S.o.endOk(x.v)));
    S.items = all; S.at = now;
    return all;
  }
  function rowHtml(it) {
    const i = S.rows.push(it) - 1;
    return '<li' + (it.past ? ' class="is-past"' : '') + '><button type="button" class="ogc-search__row" data-r="' + i + '"><span class="ogc-search__t"><b>' + esc(it.title) + '</b>' +
      (it.line ? '<small>' + esc(it.line) + '</small>' : '') + '</span>' + (it.code ? '<code>' + esc(it.code) + '</code>' : '') + '</button></li>';
  }
  const list = rows => '<ul class="ogc-search__list">' + rows.map(rowHtml).join('') + '</ul>';
  const group = (k, rows) => '<section class="ogc-search__g" aria-label="' + esc(k) + '"><h3 class="ogc-search__k">' + esc(k) + '</h3>' + list(rows) + '</section>';
  function chipsHtml() {
    if (S.which !== 'search') return '';
    const cs = each('chips', S.which).filter(c => c && c.label && c.run).sort((a, b) => (a.ord || 0) - (b.ord || 0));
    if (!cs.length) return '';
    return '<div class="ogc-search__chips" role="group" aria-label="Suggestions">' + cs.map(c => {
      const i = S.chips.push(c) - 1;
      return '<button type="button" class="ogc-search__chip" data-c="' + i + '"' + (c.aria ? ' aria-label="' + esc(c.aria) + '"' : '') + '>' + (c.icon || '') + '<span>' + esc(c.label) + '</span>' + (c.sub ? '<small>' + esc(c.sub) + '</small>' : '') + '</button>';
    }).join('') + '</div>';
  }
  // Before anything is typed: the providers' sections (Recent; the planner's My location, My room and
  // Choose on map), then the chips.
  function startHtml() {
    const secs = each('start', S.which).filter(s => s && s.rows && s.rows.length).sort((a, b) => (a.ord || 0) - (b.ord || 0));
    return secs.map(s => s.label ? group(s.label, s.rows) : '<section class="ogc-search__g">' + list(s.rows) + '</section>').join('') + chipsHtml();
  }
  function rank(t, raw) {
    const hits = [];
    items().forEach(it => { const s = best(it, t, raw); if (s < Infinity) hits.push({ it, s }); });
    // The restrooms (and the elevators) keep their own order, the nearest first: one score for them all.
    const tie = {};
    hits.forEach(h => { const k = h.it.tie; if (k) tie[k] = Math.min(tie[k] == null ? Infinity : tie[k], h.s); });
    hits.forEach(h => { if (h.it.tie) h.s = tie[h.it.tie]; });
    const by = {};
    hits.forEach(h => { const g = h.it.group || 'Places'; (by[g] = by[g] || []).push(h); });
    Object.keys(by).forEach(g => {
      // (The schedule by how it matched, then by time: its ord is today's first, then the days ahead.)
      const sc = g === 'Schedule' ? h => tier(h.s) : h => h.s;
      by[g].sort((a, b) => (!!a.it.past - !!b.it.past) || sc(a) - sc(b) || (a.it.ord || 0) - (b.it.ord || 0) || a.s - b.s || a.it.title.length - b.it.title.length);
      const n = {};
      by[g] = by[g].filter(h => { const k = h.it.tie; if (!k) return true; n[k] = (n[k] || 0) + 1; return n[k] <= (TIE_CAP[k] || 4); }).slice(0, CAP[g] || 6);
    });
    const top = g => Math.min.apply(null, by[g].map(h => h.s));
    const order = Object.keys(by).sort((a, b) => top(a) - top(b) || (GROUPS.indexOf(a) + 1 || 99) - (GROUPS.indexOf(b) + 1 || 99));
    return { by, order };
  }
  function resultsHtml(t, raw) {
    const { by, order } = rank(t, raw);
    const say = n => { $('say').textContent = n ? n + (n === 1 ? ' result' : ' results') : 'No results'; };
    if (!order.length) { say(0); return '<p class="ogc-search__none">No results</p>' + chipsHtml(); }
    // A number: Places alone, the schedule's rows there folded under them.
    if (isNum(t) && by.Places) {
      say(by.Places.length);
      return group('Places', by.Places.map(h => h.it)) + (by.Schedule ? '<details class="ogc-search__fold"><summary>Schedule<span class="ogc-search__n">' + by.Schedule.length + '</span>' + I.down + '</summary>' + list(by.Schedule.map(h => h.it)) + '</details>' : '');
    }
    say(order.reduce((n, g) => n + by[g].length, 0));
    return order.map(g => group(g, by[g].map(h => h.it))).join('');
  }
  function draw() {
    if (!dlg) return;
    const q = $('q'), raw = q.value.trim(), t = norm(raw), body = $('body');
    $('x').hidden = !q.value;
    S.rows = []; S.chips = [];
    body.innerHTML = t ? resultsHtml(t, raw) : startHtml();
    if (!t) $('say').textContent = '';
    names().forEach(n => { const p = providers[n]; if (p.tidy) { try { p.tidy(body); } catch (e) { /* as drawn */ } } });
  }
  // What a provider read in the background has come (the restrooms, the rooms by name, My room).
  function refresh() {
    S.items = null;
    if (!dlg || !dlg.open) return;
    const body = $('body'), y = body.scrollTop, ae = document.activeElement, was = ae && ae.dataset ? ae.dataset.r || ae.dataset.c : null;
    draw();
    body.scrollTop = y;
    if (was != null && ae !== $('q')) { const b = body.querySelector('[data-r="' + was + '"], [data-c="' + was + '"]'); if (b) b.focus({ preventScroll: true }); }
  }

  O.search = {
    open, refresh,
    close: () => close('x'),
    isOpen: () => !!(dlg && dlg.open),
    use(name, p) { if (p) providers[name] = p; else delete providers[name]; S.items = null; },
    provider: name => providers[name] || null,
    // For a check (and a provider's own tests): the ranked groups for a query, as titles.
    rank: (q, which) => { const w = S.which; S.which = which || 'search'; S.items = null; const r = rank(norm(q), q); S.which = w; S.items = null; return r.order.map(g => ({ group: g, rows: r.by[g].map(h => h.it.title + (h.it.line ? ' · ' + h.it.line : '')) })); },
    norm
  };
})();
