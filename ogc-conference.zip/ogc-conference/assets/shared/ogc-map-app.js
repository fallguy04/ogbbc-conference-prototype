/*
 * ogc-map-app.js — the guide's Places: the campus map, to see where things are (the map area, Oct 10).
 *
 * On a phone (the guide), Places is the map, full height, with a sheet over it (peek: the usual places,
 * one tap each; half: a place; full: every building). On a laptop the map has its panel beside it when
 * the column is wide (a container query, not the window), else above it.
 *
 * Directions are ours, end to end (Michael, Nov 4, replacing Oct 13's "rely on Google Maps"; docs/34
 * §4.5, §5.1): a place's Directions opens the planner here, in the sheet (a phone) or the floating panel
 * (a laptop). From and To (each a row that opens its own Search), Swap, the Step-free switch (kept on this
 * device; on when the signed-in household ticked No stairs), then the time, the distance and arrival, the
 * legs, Start (a phone) and Steps. The route is ogc-map-route.js's plan over the campus's one router
 * (Dijkstra; the steps are its fixed sentences); the map draws it (viewer.route), names its door, puts a
 * pill where it changes floor and opens the destination's building on the room's floor. From is My
 * location on a phone on campus to 40 m, else My room, else Choose start; inside a drawn building it's
 * "Barnes · Set start", and one tap on the opened floor sets it. On a laptop the steps are listed in full
 * and a step hovered or focused is framed on its floor. A campus with no floor plans gets the same planner
 * outdoors to the building's door, from campus.csv's paths. Nothing goes to Google Maps.
 *
 * week.js hands it what the page knows (ctx): the year, the campus (O.map.campus), the places, today's
 * rows with their state, every row (for search), the Help cards, the time, and how to open an event.
 * It keeps its own state between drawings of the page (the map keeps its place).
 *
 * Nov 5 (docs/34 §4, §5.1; the map area): where the year's campus has a public build of its floor plans
 * (ogc-map-floors.js), the map opens buildings in place. A place's sheet opens its building on the room's
 * floor, the room in tan with the line from the best door; its sheet says the building, floor and code,
 * what's on there today, and the nearest restroom and elevator along the halls. The peek is Next and My
 * room over one strip (Restrooms · First Aid · Information · Dining · For families); Search finds IWU's
 * own numbers ("143", "Barnes 143"); on a laptop the map is the whole canvas with a floating panel.
 * A campus with no build is as before.
 *
 * Start, on a phone (docs/34 §4.6–4.10): the head and tabs slide away and the map takes the screen. Outdoors,
 * a step card at the top (‹ ›) and a bar at the foot (Arrive, what's left, End); the map follows the dot,
 * north up, until it's panned (Recenter brings it back); a step moves on 12 m before its end; 25 m off the
 * route for 10 s replans from here with no motion ("Rerouting"); "Approximate location" over 40 m; the dot
 * greys after 30 s with no fix. At the door (15 m, or ‹ › to it), Next on the card opens the building on
 * the door's floor; inside, the steps are a sheet at the foot (Back, Next, a swipe), the step's stretch
 * framed with a ring where it starts and no dot; a floor change plays §4.9's drop and rise. Arrived:
 * the sign and its side, then Done to the place's sheet. Wake Lock where allowed; the compass asked once
 * (an iPhone asks from Start's tap) and its wedge only while following. The location stops when the page
 * is hidden. Where the demo's pills show (local and the shared link), "Mockup: walk it" moves the dot
 * along the route at three times walking speed.
 *
 * Nothing about where someone is leaves the phone: the location is used while Places is open and
 * stopped when it closes or the page is hidden; "My room" comes from the server for the signed-in
 * person alone (/me/stay). Recent places (codes only) stay on this device.
 */
(function () {
  'use strict';
  const O = window.OGC, esc = O.esc, M = O.map;
  if (!M) return;
  // A name with a dash in it ("South-west doors", "Rooms A–D") never breaks at the dash (round 2 checks).
  const nb = s => esc(s).replace(/[^\s<>]*[A-Za-z0-9][-–][A-Za-z0-9][^\s<>]*/g, m => '<span class="pm-nw">' + m + '</span>');
  const svg = d => '<svg class="pm-i" viewBox="0 0 24 24" aria-hidden="true"><path d="' + d + '" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  const I = {
    search: svg('M10.5 17a6.5 6.5 0 1 0 0-13 6.5 6.5 0 0 0 0 13ZM15.3 15.3l4.7 4.7'),
    dirs: svg('M12 3.5 20.5 12 12 20.5 3.5 12ZM9.5 13.5v-2.5h4.5M12.5 9l2 2-2 2'),
    pin: svg('M12 20.5s-6.5-5.4-6.5-10.8a6.5 6.5 0 0 1 13 0c0 5.4-6.5 10.8-6.5 10.8ZM12 12a2.3 2.3 0 1 0 0-4.6 2.3 2.3 0 0 0 0 4.6Z'),
    close: svg('M6.5 6.5l11 11M17.5 6.5l-11 11'),
    locate: svg('M12 3v3M12 18v3M3 12h3M18 12h3M12 17a5 5 0 1 0 0-10 5 5 0 0 0 0 10Z'),
    bed: svg('M3.5 18.5v-11M3.5 14.5h17v4M20.5 14.5v-2.5a2.5 2.5 0 0 0-2.5-2.5h-7v5M7 12.2a1.6 1.6 0 1 0 0-3.2 1.6 1.6 0 0 0 0 3.2Z'),
    clock: svg('M12 20.5a8.5 8.5 0 1 0 0-17 8.5 8.5 0 0 0 0 17ZM12 7.5V12l3 2'),
    cross: svg('M9.5 4.5h5v5h5v5h-5v5h-5v-5h-5v-5h5Z'),
    desk: svg('M4.5 9.5h15v10h-15ZM9.5 9.5v-4h5v4'),
    dining: svg('M7 3.5v7a2 2 0 0 0 2 2v8M5 3.5v5.5M9 3.5v5.5M17 20.5V3.5c-2.2 1.2-3.5 4-3.5 7.5H17'),
    next: svg('M9.5 5.5 16 12l-6.5 6.5'),
    swap: svg('M8 4.5v15M4.5 8 8 4.5 11.5 8M16 19.5v-15M12.5 16l3.5 3.5 3.5-3.5'),
    // The steps' and the legs' icons (ogc-map-route.js's icon names), one plain line icon each.
    'r-straight': svg('M12 20.5V4.5M6.5 10 12 4.5 17.5 10'),
    'r-left': svg('M17 20.5V13a4 4 0 0 0-4-4H5.5M9.5 5 5.5 9l4 4'),
    'r-right': svg('M7 20.5V13a4 4 0 0 1 4-4h7.5M14.5 5l4 4-4 4'),
    'r-bear-left': svg('M14.5 20.5V14L7 6.5M7 12.5v-6h6'),
    'r-bear-right': svg('M9.5 20.5V14L17 6.5M17 12.5v-6h-6'),
    'r-cross': svg('M3.5 5.5h17M3.5 18.5h17M7 9v6M12 9v6M17 9v6'),
    'r-door': svg('M6.5 20.5v-16h11v16M4 20.5h16M14.5 12.5v.01'),
    'r-stairs': svg('M3.5 19.5h4.5v-4h4v-4h4v-4h4.5'),
    'r-stairs-up': svg('M3.5 20h4v-3.5h4V13h4V9.5h5M5 9.5l5-5M6.5 4.5H10V8'),
    'r-stairs-down': svg('M3.5 20h4v-3.5h4V13h4V9.5h5M10 4.5l-5 5M5 6v3.5h3.5'),
    'r-elevator': svg('M5.5 3.5h13v17h-13ZM9.5 9.5 12 7l2.5 2.5M9.5 14.5 12 17l2.5-2.5'),
    'r-arrive': svg('M12 20.5s-6.5-5.4-6.5-10.8a6.5 6.5 0 0 1 13 0c0 5.4-6.5 10.8-6.5 10.8ZM9.3 9.8l1.9 1.9 3.6-3.6'),
    'r-walk': svg('M13.5 5.5a1.6 1.6 0 1 0 0-3.2 1.6 1.6 0 0 0 0 3.2ZM10 21l2.2-6 2.8 2.6V21M8 12l2.3-3.6h3.2l2 3.1 2.5 1M12.7 8.4l-1.4 6'),
    // A place's features (places.csv `features`; Oct 13, from Andrew's guide), one plain line icon each.
    'f-nursery': svg('M10.5 3.5h3l.5 2.5h-4ZM9 6h6v2.5H9ZM10 8.5h4a1.5 1.5 0 0 1 1.5 1.5v9a1.5 1.5 0 0 1-1.5 1.5h-4A1.5 1.5 0 0 1 8.5 19v-9A1.5 1.5 0 0 1 10 8.5ZM8.5 12.5h3M8.5 15.5h3'),
    'f-restroom': svg('M12 6.5a1.75 1.75 0 1 0 0-3.5 1.75 1.75 0 0 0 0 3.5ZM9 20.5v-6.5l-1-.5V10a1.5 1.5 0 0 1 1.5-1.5h5A1.5 1.5 0 0 1 16 10v3.5l-1 .5v6.5M12 14.5v6'),
    'f-family restroom': svg('M8.5 6.5a1.75 1.75 0 1 0 0-3.5 1.75 1.75 0 0 0 0 3.5ZM5.5 20.5v-6.5l-1-.5V10A1.5 1.5 0 0 1 6 8.5h5A1.5 1.5 0 0 1 12.5 10v3.5l-1 .5v6.5M17 11a1.4 1.4 0 1 0 0-2.8 1.4 1.4 0 0 0 0 2.8ZM15 20.5v-4l-.7-.5v-2.2a1 1 0 0 1 1-1h3.4a1 1 0 0 1 1 1V16l-.7.5v4'),
    'f-accessible entrance': svg('M10.5 5.5a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3ZM10.5 7.5V13h5l2.5 5.5M10.5 10h4.5M8 10.6a5.2 5.2 0 1 0 7.6 6.6'),
    'f-elevator': svg('M5.5 3.5h13v17h-13ZM9.5 9.5 12 7l2.5 2.5M9.5 14.5 12 17l2.5-2.5'),
    'f-quiet room': svg('M19 14.5A7.5 7.5 0 0 1 9.5 5a7.5 7.5 0 1 0 9.5 9.5Z')
  };
  // The words a place goes by, beyond its name (search).
  const KIND_WORDS = { dining: ['dining', 'cafeteria', 'food', 'meals', 'lunch', 'dinner', 'breakfast'], worship: ['chapel', 'worship', 'services', 'auditorium'], venue: ['theater', 'hall'], hall: ['hall', 'dorm', 'residence'] };
  const SPOT_WORDS = { parking: 'parking lot cars', accessible: 'parking accessible handicap', camper: 'campers rv lot', carts: 'golf carts cart ride', desk: 'information info desk help' };
  const SYN = { bathroom: ['restroom'], bathrooms: ['restroom'], toilet: ['restroom'], washroom: ['restroom'], food: ['dining'], eat: ['dining'], meals: ['dining'], cafeteria: ['dining'], info: ['information'], doctor: ['first aid'], nurse: ['first aid'], medical: ['first aid'], gym: ['recreation', 'arena'], dorm: ['hall'] };
  const LS = { get: (k, d) => { try { const v = localStorage.getItem(k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } }, set: (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { /* fine */ } } };
  const coarse = () => !!(window.matchMedia && matchMedia('(pointer: coarse)').matches);
  // Members (the pins tool's people) are told what the map is missing; the public only what's useful.
  const W = () => window.OGC_WP || {};
  const member = y => !!(W().webmaster || (W().member || []).map(String).indexOf(String(y)) > -1);
  const touch = () => coarse() && 'geolocation' in navigator;

  function app() {
    const A = { el: null, ctx: null, c: null, map: null, mapEl: null, mode: '', place: null, nav: { me: null, status: '' }, sheetH: 0, snap: 'peek', stay: null, stayAsked: false, watch: null, perm: '', hidden: true,
      // The floor plans (Nov 5): plans is known at once (OGC_WP.floors names the year's build); P and L come after.
      plans: false, P: null, L: null, destKey: '', destInfo: null, fitKey: '', near: {}, feats: {}, origin: null,
      // The planner (Nov 5): dir is what's open ({ to, from, plan, … }); build, the router's build (once a year).
      dir: null, build: null, plansWait: [] };
    const dlg = document.createElement('dialog');
    dlg.className = 'ogc wk-sheet pm-pick';
    dlg.setAttribute('aria-labelledby', 'pm-pick-t');
    document.body.appendChild(dlg);

    /* ------------------------------------------------ what the page knows */

    const places = () => A.ctx.places || {};
    const P = code => code ? places()[String(code).toUpperCase()] || null : null;
    const keyOf = code => String(code).split('/')[0].toUpperCase();
    // A room named for its building ("Piazza Terrace (Barnes)") drops the building in its own card.
    const inBuilding = (room, b) => String(room.name).replace(/\s*\(([^)]+)\)$/, (m, w) => String(b).toLowerCase().indexOf(w.split(' ')[0].toLowerCase()) > -1 ? '' : m);
    // The buildings people go to, in places.csv's order, each with its rooms. A building listed only by
    // its rooms (Cedarville's "Stevens Student Center Room 241") is named for the building, not a room.
    function groups() {
      const out = [], by = {};
      Object.keys(places()).forEach(k => {
        const p = places()[k], key = keyOf(p.code);
        if (!by[key]) out.push(by[key] = { key, main: null, rooms: [] });
        if (String(p.code).toUpperCase() === key) by[key].main = p; else by[key].rooms.push(p);
      });
      return out.filter(g => g.main || g.rooms.length).map(g => {
        if (g.main) return Object.assign(g, { name: g.main.name, all: g.rooms });
        const r = g.rooms[0], name = r.building || String(r.name).replace(/\s*(room|rm\.?|#)\s*[\w–-]+$/i, '') || r.name;
        return Object.assign(g, { main: r, name, all: g.rooms, derived: true });
      });
    }
    const where = p => M.whereIs(A.c, p, places());
    // The halls with rooms this year: rooms.csv for those who may read it, else the campus's own mark.
    const stayHalls = () => Array.from(new Set((A.ctx.halls || []).concat(A.c.items.filter(i => i.stay && i.lab).map(i => i.name))));
    // Directions can take you there: a pin, or a building (a field not pinned yet can't; members are told so).
    // (A field not pinned yet, beside a building, is walked to that building's door: Nebraska Green and the
    // Multi-Purpose Field to the Rec Center's, the route saying so. Round 2 part 2: they were dead ends.)
    const routable = p => { const w = p && where(p); return !!(w && (w.kind === 'pin' || w.kind === 'building' || (w.kind === 'outdoor' && w.b))); };
    // Directions (Nov 5): the planner, here, to what's open (endOfPlace). The one filled button on its card;
    // none for a place the map can't find (a field not pinned yet).
    const dirsBtn = ok => ok ? '<p class="pm-btns"><button type="button" class="pm-btn" data-pm="dirs">' + I.dirs + 'Directions</button></p>' : '';
    const dirsTo = p => dirsBtn(routable(p));
    const today = () => (A.ctx.today ? A.ctx.today() : []);
    // The next thing on today (the Conference's own rows), for "Next".
    function nextEvent() {
      return today().filter(it => it.code && P(it.code) && !it.allDay && (it.state === 'upcoming' || it.state === 'now') && (!it.audience || it.audience === 'conference' || it.audience === 'all'))
        .sort((a, b) => (a.state === 'now') - (b.state === 'now') || (a.start == null ? 1e9 : a.start) - (b.start == null ? 1e9 : b.start))[0] || null;
    }
    // The guide's own way to say a time ("11:00 PM ET" to a reader in another zone), as Today says it.
    const clock = m => { const t = ((m % 1440) + 1440) % 1440; return A.ctx && A.ctx.clock ? A.ctx.clock(t) : O.formatTime(t); };
    // The schedule's own short names for buildings ("PPAC", not "Phillippe").
    let shorts = {};
    // A building as the schedule names it ("PPAC", not campus.csv's "Phillippe"), everywhere a building is said.
    const bShort = b => b ? shorts[b.name] || M.shortOf(b) : '';
    // A building's own schedule code ("N" for Hodson Hall), as its name on the map has it; '' when it has none.
    const bCode = b => { if (!b) return ''; const g = groups().find(z => !z.derived && String(z.main.code).indexOf('/') < 0 && (where(z.main).b || {}).name === b.name); return g ? g.key : ''; };
    // What tells a room apart, beyond its own name: "First Aid Room (Barnes Room 131)" → "Room 131".
    const roomRest = (room, b) => { const m = /\(([^)]+)\)$/.exec(String(room.name)); if (!m || String(b).toLowerCase().indexOf(m[1].split(' ')[0].toLowerCase()) < 0) return ''; const r = /\b(rooms?|rm\.?)\s+\S.*$/i.exec(m[1]); return r ? r[0].charAt(0).toUpperCase() + r[0].slice(1) : ''; };
    // A room by its own name ("First Aid Room"); the building and number go on the line under it.
    const roomName = p => { const b = where(p).b; return String(p.code).indexOf('/') > -1 && b ? inBuilding(p, b.name) : p.name; };

    /* ------------------------------------------------ the floor plans (Nov 5) */

    // A place in the build: its building's code and its rooms there ([] for a whole building); null with
    // no build, or for a place the build has no room for (the Chapel Loft, a field).
    function planOf(p) {
      if (!A.P || !p) return null;
      const rooms = A.P.roomsOf(p.code), B = A.P.by[keyOf(p.code)];
      return rooms && B && B.ok ? { code: B.code, B, rooms, place: String(p.code).toUpperCase() } : null;
    }
    const planFloor = p => { const pl = planOf(p); return pl && pl.rooms.length ? +pl.rooms[0].floor : null; };
    // What's open, as the map marks it: a place, or one of its rooms by IWU's name (the Chapel's Balcony:
    // that room alone, on its floor, named so; the last checks: going to the balcony tinted the 1st floor's
    // Auditorium as where you were going, and its sheet said "1st floor").
    function planFor(t) {
      const pl = t && t.code ? planOf(P(t.code)) : null, rm = t && t.room;
      if (!pl || !rm) return pl;
      return Object.assign({}, pl, { rooms: [{ floor: +rm.floor, number: String(rm.number) }], place: pl.place + '|' + rm.floor + '|' + rm.number, name: rm.name, room: rm });
    }
    // "Barnes · 1st floor · B/HW" (§4.3): the building, the floor, the code; the room's number is in its name.
    function factLine(p, isMain) {
      const w = where(p), fl = planFloor(p);
      return [isMain ? '' : (w.b ? bShort(w.b) : ''), fl != null ? M.floorName(fl) : '', isMain ? '' : p.code].filter(Boolean).join(' · ');
    }
    // A room's name on the map, without its building: "PPAC Room 150" → "Room 150", "Chapel Auditorium" → "Auditorium".
    function mapName(code) {
      const p = P(code); if (!p) return code;
      const b = where(p).b, n = roomName(p), sh = b ? bShort(b) : '';
      const lead = [sh, b ? b.name : ''].filter(Boolean).find(w => n.toLowerCase().indexOf(w.toLowerCase() + ' ') === 0);
      return lead ? n.slice(lead.length + 1) : n;
    }
    const doorRow = id => A.c.doors.find(d => d.id === id) || null;

    // Features (places.csv `features`, one fixed list; Oct 13, from Andrew's guide): a building's own,
    // and its rooms' with the room they're in ("Nursery · Room 114"). Only what a row says is shown.
    const FAMILY = ['nursery', 'family restroom', 'quiet room'];
    const featWord = f => (O.FEATURES && O.FEATURES[f]) || f;
    function featuresIn(g) {
      return (g.derived ? [] : (g.main.features || []).map(f => ({ f, room: null }))).concat([].concat.apply([], (g.derived ? g.all : g.rooms).map(r => (r.features || []).map(f => ({ f, room: r })))));
    }
    // A feature's row: its icon and word, and the room (a room's row opens that room on the map).
    // withB: the building too ("Room 114 · Chapel"), in the campus-wide list.
    function featRow(x, g, withB) {
      const r = x.room ? (roomRest(x.room, g.name) || inBuilding(x.room, g.name)) : '', b = withB ? (where(g.main).b ? bShort(where(g.main).b) : g.name) : '';
      const where_ = [r && r.toLowerCase() !== featWord(x.f).toLowerCase() ? r : '', b].filter(Boolean).join(' · ');
      const inner = (I['f-' + x.f] || '') + '<span><b>' + esc(featWord(x.f)) + '</b>' + (where_ ? '<small>' + esc(where_) + '</small>' : '') + '</span>';
      return '<li>' + (x.room ? '<button type="button" class="pm-feat" data-pm="room" data-code="' + esc(x.room.code) + '">' + inner + (x.room.code ? '<code>' + esc(x.room.code) + '</code>' : '') + '</button>' : '<div class="pm-feat">' + inner + '</div>') + '</li>';
    }
    // Every place with a family feature, campus-wide ("For families").
    const familyPlaces = () => [].concat.apply([], groups().map(g => featuresIn(g).filter(x => FAMILY.indexOf(x.f) > -1).map(x => Object.assign({ g }, x))));

    /* ------------------------------------------------ where I sleep, and what a place is called */

    // My hall: a dorm stay's, or a Youngfolk's one hall (from /me/stay).
    function stayHall() { const s = A.stay; if (!s) return ''; if (s.type === 'dorm' && s.rooms && s.rooms.length) return s.rooms[0].hall; if (s.type === 'yf' && s.halls && s.halls.length === 1) return s.halls[0]; return ''; }
    const camper = () => A.c.spots.find(s => s.spot === 'camper');
    // Where I sleep, as one of the usual places (a chip that shows it on the map).
    function stayEnd() {
      const s = A.stay; if (!s) return null;
      if (s.type === 'camper' && camper()) return { kind: 'stay' };
      return stayHall() ? { kind: 'stay' } : null;
    }
    const stayName = () => A.stay && A.stay.type === 'camper' ? 'Camper lot' : A.stay && A.stay.type === 'yf' ? 'My hall' : 'My room';
    // "Reed Hall · 2nd floor · 211, 212" (the floor of the first room; polish 2).
    // short: without the room numbers ("Hodson Hall · 2nd floor", the peek's row).
    // noHall: without the hall's name, under a title that says it (the floor, then the household's rooms).
    function staySub(short, noHall) { const s = A.stay; if (s && s.type === 'dorm' && s.rooms && s.rooms.length) { const fl = Array.from(new Set(s.rooms.map(r => +r.floor || 0).filter(Boolean))); return [noHall ? '' : s.rooms[0].hall, fl.length === 1 ? M.floorName(fl[0]) : '', short ? '' : s.rooms.map(r => r.num).join(', ')].filter(Boolean).join(' · '); } return noHall ? '' : stayHall(); }
    const spotName = id => { const s = A.c.spots.find(x => x.id === id); return s ? s.name || M.SPOT[s.spot] : 'Spot'; };
    // A pinned place's name on its pin, as the map says it: "Piazza Terrace", "First Aid Room", "PPAC".
    function pinName(p) {
      const b = where(p).b;
      if (String(p.code).indexOf('/') > -1) return b ? inBuilding(p, b.name) : p.name;
      return b ? shorts[b.name] || M.shortOf(b) : p.name;
    }

    /* ------------------------------------------------ location (the phone only) */

    // Near enough to walk from (§4.11): within 1.5 km of the campus (Washington St, the town around it).
    const near = p => M.onCampus(A.c, p, 1500);
    function locate() {
      const n = A.nav;
      if (!touch()) return;
      if (A.watch != null) { if (n.me && near(n.me)) A.map.centre(n.me, true); return; }
      n.status = 'Locating';
      if (!A.walk) paint();
      A.watch = navigator.geolocation.watchPosition(pos => {
        const p = M.toMap(A.c, pos.coords.latitude, pos.coords.longitude);
        if (!p) return;
        p.acc = pos.coords.accuracy;
        // (The fix itself too, for the planner's From: ogc-map-route.js takes { lat, lng }.)
        p.lat = pos.coords.latitude; p.lng = pos.coords.longitude;
        const first = !n.me;
        n.me = p; A.perm = 'granted';
        n.status = !near(p) ? 'Not on campus' : p.acc > 40 ? 'Approximate location' : '';
        // Walking (Start): the walk follows the fix, and nothing else is drawn again.
        if (A.walk) { walkFix(); return; }
        paint();
        // With the planner open, it plans from here (or again, as you move); it frames the route, not you.
        if (A.dir) onFix(); else if (first && near(p)) A.map.centre(p, true);
      }, err => {
        n.status = err && err.code === 1 ? 'Location off' : 'Location unavailable';
        if (err && err.code === 1) A.perm = 'denied';
        // (Walking, a fix that's late isn't the end: the watch keeps on, and 30 s without one greys the dot.)
        if (A.walk) { if (err && err.code === 1) stopWatch(); walkPaint(); return; }
        stopWatch(); paint();
        if (A.dir) onFix();
      }, { enableHighAccuracy: true, maximumAge: 5000, timeout: 15000 });
    }
    function stopWatch() { if (A.watch != null && navigator.geolocation) navigator.geolocation.clearWatch(A.watch); A.watch = null; }
    // Hidden page: the GPS stops (battery); back again, it starts again if it was on.
    let wasWatching = false;
    document.addEventListener('visibilitychange', () => {
      if (document.hidden) { wasWatching = A.watch != null; stopWatch(); if (A.walk) walkHidden(true); }
      else { if (wasWatching && !A.hidden) locate(); if (A.walk) walkHidden(false); }
    });
    if (navigator.permissions && navigator.permissions.query) navigator.permissions.query({ name: 'geolocation' }).then(s => { A.perm = s.state; s.onchange = () => { A.perm = s.state; }; }).catch(() => {});

    /* ------------------------------------------------ drawing */

    function mount(slot, ctx) {
      const yearChanged = !A.ctx || A.ctx.year !== ctx.year || A.ctx.campus !== ctx.campus;
      A.ctx = ctx; A.hidden = false;
      if (yearChanged) { A.c = ctx.campus; A.place = null; A.nav = { me: A.nav.me, status: '' }; A.stay = null; A.stayAsked = false; A.stayIn = false; if (A.map) { A.mapEl.remove(); A.map = null; } shorts = M.shortsFor ? M.shortsFor(A.c, places()) : {}; }
      const mode = ctx.full ? 'full' : 'embed';
      if (yearChanged) { const fl = W().floors; A.plans = !!(fl && fl[String(ctx.year)]); A.P = null; A.L = null; A.destKey = ''; A.destInfo = null; A.near = {}; A.feats = {}; A.origin = null; A.dir = null; A.build = null; A.plansWait = []; A.plansFailed = false; }
      if (!A.el) { A.el = document.createElement('div'); A.el.className = 'pm'; }
      if (A.mode !== mode || yearChanged) { if (A.walk) endWalk(true); A.mode = mode; A.el.className = 'pm pm--' + mode + (ctx.guide ? ' pm--guide' : '') + (A.plans ? ' pm--plans' : ''); build(); }
      slot.appendChild(A.el);
      if (!A.map) makeMap();
      document.documentElement.classList.toggle('pm-on', mode === 'full');
      document.documentElement.classList.add('pm-places');
      if (mode === 'full') { scrollTo(0, 0); place(); }
      else { A.el.style.removeProperty('--pm-top'); A.el.style.removeProperty('--pm-bottom'); if (A.plans) tall(); }
      const host = A.el.querySelector('.pm-map'); if (A.mapEl.parentNode !== host) host.appendChild(A.mapEl);
      if (!A.stayAsked) { A.stayAsked = true; M.store.stay(ctx.year).then(s => {
        A.stay = s && s.type ? s : null; A.stayIn = true;
        // Directions to My room asked before the stay came (Your sign-ups' link): now.
        if (A.wantStay) { A.wantStay = false; if (A.stay) { api.directions('stay'); return; } }
        // The planner open already: My room may be its start now, and No stairs its Step-free.
        if (A.dir) { if (A.dir.auto && (!A.dir.from || A.dir.from.kind === 'stay')) A.dir.from = fromDefault(); A.dir.key = ''; replan(true); }
        paint();
        // My hall in the first frame too (it comes after the map is drawn), unless something's been asked for.
        const h = stayHall();
        if (h && A.map && !A.place && A.firstFrame && A.firstFrame.indexOf(h) < 0) { A.firstFrame = A.firstFrame.concat([h]); A.map.fit(M.boxOf(A.c, A.firstFrame, 30), 8, true); }
      }); }
      paint();
    }
    function hide() {
      if (A.hidden) return;
      if (A.walk) endWalk(true);
      A.hidden = true; stopWatch(); document.documentElement.classList.remove('pm-on', 'pm-places');
    }
    function build() {
      const search = '<button type="button" class="pm-search" data-pm="search">' + I.search + 'Search</button>';
      A.el.innerHTML = A.mode === 'full'
        ? '<div class="pm-map">' + search + '</div><section class="pm-sheet is-peek" aria-label="Places"><button type="button" class="pm-grab" data-pm="grab" aria-label="More"></button><div class="pm-body"></div></section>'
        // A laptop with floor plans (§5.1): the map is the whole canvas; Search and the list float over it.
        : A.plans ? '<div class="pm-grid"><div class="pm-map"></div><section class="pm-panel" aria-label="Places">' + search + '<div class="pm-pbody"></div></section></div><div class="pm-extra"></div>'
        : '<div class="pm-grid"><div class="pm-map">' + search + '</div><div class="pm-panel" aria-live="off"></div></div><div class="pm-cards" aria-label="Buildings"></div><div class="pm-extra"></div>';
      if (A.mode === 'full') sheetDrag();
    }
    // The fixed map sits between the guide's header and its tabs.
    // Walking (Start, §4.6) the head and the tabs slide away and the map takes the screen from where the head
    // starts (under the demo's banner, where there is one). Measured as laid out, not where a slide has it.
    function place() {
      const head = document.querySelector('.wk-apphead'), tabs = document.querySelector('.wk-tabbar');
      let hb = null;
      if (head) { const r = head.getBoundingClientRect(), t = getComputedStyle(head).transform, dy = t && t !== 'none' ? new DOMMatrixReadOnly(t).m42 : 0; hb = { top: r.top - dy, bottom: r.bottom - dy }; }
      const top = hb ? Math.max(0, A.walk ? hb.top : hb.bottom) : 0, bottom = A.walk ? 0 : tabs ? tabs.getBoundingClientRect().height : 0;
      A.el.style.setProperty('--pm-top', top + 'px'); A.el.style.setProperty('--pm-bottom', bottom + 'px');
    }
    // A laptop's canvas (§5.1): the window less the guide's head, its tabs and 24 px, at least 560.
    function tall() {
      const host = A.el.querySelector('.pm-map'), tabs = document.querySelector('.wk-tabbar');
      if (!host) return;
      const top = host.getBoundingClientRect().top + scrollY, bar = tabs ? tabs.getBoundingClientRect().height : 0;
      A.el.style.setProperty('--pm-h', Math.max(560, innerHeight - top - bar - 24) + 'px');
    }
    addEventListener('resize', () => { if (A.hidden) return; if (A.mode === 'full') { place(); setSheet(A.snap, false); if (A.walk) walkPaint(); } else if (A.plans) tall(); });
    // The first frame: the halls with rooms this year and the buildings the schedule uses, together.
    // Polish 2: the outlier rule (a fieldhouse across the fields) dropped Reed and Evans too; it now
    // applies to the Conference's buildings only, and the halls always stay.
    function core(names, halls) {
      const its = names.map(x => M.find(A.c, x)).filter(Boolean), keep = new Set((halls || []).map(x => (M.find(A.c, x) || {}).name).filter(Boolean));
      const med = xs => xs.slice().sort((p, q) => p - q)[Math.floor(xs.length / 2)] || 0;
      const mx = med(its.map(i => i.lx)), my = med(its.map(i => i.ly)), d = i => Math.hypot(i.lx - mx, i.ly - my), md = med(its.map(d));
      return Array.from(new Set(its.filter(i => keep.has(i.name) || d(i) <= Math.max(md * 2.5, 180)).map(i => i.name).concat(Array.from(keep))));
    }
    function makeMap() {
      A.mapEl = document.createElement('div'); A.mapEl.className = 'pm-mapbox'; A.mapEl.style.cssText = 'position:absolute;inset:0';
      const used = new Set(), codes = {};
      groups().forEach(g => { const w = where(g.main); if (w.b) { used.add(w.b.name); if (!codes[w.b.name] && !g.derived && String(g.main.code).indexOf('/') < 0) codes[w.b.name] = g.key; } });
      const hall = stayHall(); if (hall) used.add(hall);
      // First view: the buildings this year's schedule uses, and the halls with rooms (never names written in code).
      const halls = stayHalls().concat(hall ? [hall] : []), start = core(Array.from(used).concat(halls), halls);
      A.firstFrame = start;
      const focus = A.pendingFocus ? A.pendingFocus : null; A.pendingFocus = null;
      const wide = A.mode !== 'full' && A.plans;
      A.map = M.viewer(A.mapEl, A.c, { title: 'Campus map', locate: true, start, focus, extent: Array.from(used).concat(halls), used: Array.from(used), codes, shorts, cooperative: A.mode !== 'full', expand: A.mode !== 'full' && !wide, scale: wide,
        onTap: (pt, b, spot) => { if (!A.walk) { if (spot) openSpot(spot); else if (b) openBuilding(b); } },
        // Walking, a pan stops following you (Recenter brings it back).
        onMove: () => { if (A.walk) walkMoved(); },
        onLocate: () => locate() });
      A.el.querySelector('.pm-map').appendChild(A.mapEl);
      if (A.plans) attachPlans(A.map);
      // The first time on this device: how the map moves (gone at the first touch).
      if (!LS.get('ogc-map-hinted', false)) { LS.set('ogc-map-hinted', true); setTimeout(() => A.map && A.map.hint(A.mode === 'full' ? 'Drag to move · Tap a building' : 'Tap a building'), 600); }
    }

    // The year's floor plans on the map (ogc-map-floors.js), once they've come.
    function attachPlans(map) {
      if (!M.floors) return;
      const year = A.ctx.year;
      // (What waits for the plans, the planner's router, is told either way: with none, it routes outdoors.)
      const flush = () => { const w = A.plansWait; A.plansWait = []; w.forEach(f => f()); };
      M.floors.load(year).then(Pl => {
        if (A.map !== map || A.ctx.year !== year) return;
        if (!Pl) { A.plansFailed = true; flush(); return; }
        A.P = Pl;
        // The streets around the campus, drawn under it (the same file the router walks; kept offline).
        if (Pl.area) Pl.area().then(a => { if (a && A.map === map && map.area) map.area(a); }, () => {});
        A.L = map.extend(inner => M.floors.layer(inner, Pl, {
          nameOf: mapName,
          shortOf: B => B.item ? bShort(B.item) : B.name,
          keyOnly: id => { const d = doorRow(id); return !!(d && d.keyOnly); },
          stepFree: id => { const d = doorRow(id); return !!(d && d.stepFree === 'yes'); },
          labelOf: id => { const d = doorRow(id); return d && d.label ? d.label : ''; },
          caption: A.mode !== 'full',
          // (Walking, a tap on the map opens nothing: the walk's card stays what's open.)
          onMark: (kind, a) => { if (A.walk) return; if (kind === 'ent') openDoor(a[0], a[1]); else if (kind === 'feat') openFeat(a[0], +a[1], a[2], a[3]); },
          onRoom: code => { if (!A.walk) focus(code); },
          onEscape: () => { if (A.walk) endWalk(); else if (A.place && A.place.kind === 'dirs') closeDirs(); else if (A.place) { A.place = null; settle('peek'); paint(); } },
          // A laptop's floating panel, and the guide's tabs where a short window puts them over the map: labels keep off them.
          covers: () => A.mode !== 'full' ? [A.el.querySelector('.pm-panel'), document.querySelector('.wk-tabbar')] : [],
          // A floor that didn't come (or came back): the place is shown as with no plans, then again with them.
          onMissing: () => { A.destKey = ''; A.near = {}; paint(); }
        }));
        paint(!!A.place && A.place.kind !== 'dirs');
        if (A.afterPlans) { const f = A.afterPlans; A.afterPlans = null; f(); }
        flush();
      });
    }

    // The panel (laptop) or sheet (phone): what's open now.
    function paint(fit) {
      if (!A.el || A.hidden) return;
      // Keyboard focus in the panel or sheet survives its redraw (§9 K4; round 2: Enter on a row, or on ×,
      // left focus on the page): a place opened gets its heading, a place closed its row back, else Search.
      const ae = document.activeElement, kept = !!(ae && ae !== document.body && A.el.contains(ae) && ae.closest('.pm-body, .pm-pbody, .pm-panel'));
      const same = kept && ae.dataset && ae.dataset.pm ? '[data-pm="' + CSS.escape(ae.dataset.pm) + '"]' + ['code', 'v', 'id', 'fl', 'i', 'which'].filter(k => ae.dataset[k] != null).map(k => '[data-' + k + '="' + CSS.escape(ae.dataset[k]) + '"]').join('') : '', was = A.lastView;
      const body = A.place ? placeView(A.place) : browseView();
      A.el.classList.toggle('is-dirs', dirsOpen());
      if (A.mode === 'full') {
        // The same view keeps its scroll; another (a building tapped in the list) starts at its top (Oct 13).
        const b = A.el.querySelector('.pm-body'), view = A.place ? A.place.kind + ':' + (A.place.code || A.place.name || A.place.id || '') : 'browse', keepScroll = view === A.lastView ? b.scrollTop : 0;
        A.lastView = view;
        b.innerHTML = body + (A.place ? '' : cardsView() + (A.ctx.extra || ''));
        b.scrollTop = keepScroll;
        setSheet(A.snap, false);
      } else if (A.plans) {
        // The floating panel: Search, then the list or a place (it keeps its scroll for the same view).
        const b = A.el.querySelector('.pm-pbody'), view = A.place ? A.place.kind + ':' + (A.place.code || A.place.name || A.place.id || '') : 'browse', keep = view === A.lastView ? A.el.querySelector('.pm-panel').scrollTop : 0;
        A.lastView = view;
        b.innerHTML = body + (A.place ? '' : listView());
        A.el.querySelector('.pm-panel').scrollTop = keep;
        A.el.querySelector('.pm-extra').innerHTML = A.ctx.extra || '';
      } else {
        A.el.querySelector('.pm-panel').innerHTML = body;
        A.el.querySelector('.pm-cards').innerHTML = cardsView();
        A.el.querySelector('.pm-extra').innerHTML = A.ctx.extra || '';
      }
      if (kept && !A.el.contains(document.activeElement)) { const again = same && A.lastView === was ? A.el.querySelector(same) : null; if (again) again.focus({ preventScroll: true }); else refocus(); }
      if (A.place && A.place.code) A.lastCode = A.place.code;
      drawMap(fit);
    }
    function refocus() {
      let t = null;
      if (A.place) { t = A.el.querySelector('.pm-placecard .pm-h, .pm-body .pm-h, .pm-pbody .pm-h'); if (t) t.setAttribute('tabindex', '-1'); }
      else if (A.lastCode) t = A.el.querySelector('[data-code="' + CSS.escape(A.lastCode) + '"]');
      if (!t) t = A.el.querySelector('.pm-search');
      if (t) t.focus({ preventScroll: true });
    }
    // The demo's dock (ogc-dev-nav.js: the local site and the shared link only, never the real site) rests
    // over the map above a phone's sheet (so it never covers Start): fits and names keep clear of it too.
    const dockH = () => { if (A.mode !== 'full' || A.snap === 'full') return 0; const d = document.querySelector('.ogc-pill'); const r = d && !d.hidden ? d.getBoundingClientRect() : null; return r && r.height ? Math.round(r.height) + 8 : 0; };
    // (A phone's planner hides Search: its From and To rows are the search; the map gets the top back.)
    const dirsOpen = () => !!(A.place && A.place.kind === 'dirs');
    const topInset = () => { if (A.mode !== 'full' && A.plans) return 0; if (A.mode === 'full' && dirsOpen()) return 12; const sb = A.el && A.el.querySelector('.pm-search'); return sb && sb.offsetHeight ? sb.offsetTop + sb.offsetHeight + 8 : 64; };
    // What else covers the map (§4, §5.1): the picker's column on a phone; the panel and the picker on a laptop.
    const sideInset = () => A.mode === 'full' ? { left: 0, right: A.plans ? 60 : 0 } : A.plans ? { left: (A.el.querySelector('.pm-panel') || {}).offsetWidth ? A.el.querySelector('.pm-panel').offsetWidth + 48 : 0, right: 80 } : { left: 0, right: 0 };
    // A building framed with its neighbours: it fills at most about a third of the map's width (polish 1:
    // on a laptop a tapped building filled 70% and the context was lost).
    const roomy = (box, f) => box ? { x: box.x + box.w / 2 - box.w / f / 2, y: box.y + box.h / 2 - box.h / f / 2, w: box.w / f, h: box.h / f } : null;
    function drawMap(fit) {
      const m = A.map, n = A.nav;
      if (!m) return;
      const lb = A.plans && A.mapEl.querySelector('[data-locate]');
      if (lb) { lb.classList.toggle('is-on', A.watch != null && !!n.me); lb.setAttribute('aria-busy', String(n.status === 'Locating')); lb.setAttribute('aria-pressed', String(A.watch != null)); }
      m.me(A.walk ? walkMe() : n.me && near(n.me) ? n.me : null);
      const pins = [];
      let sel = '', green = null, box = null;
      let t = A.place;
      // The planner: where it's going is marked as its own place is (the route is the viewer's own layer,
      // and frames itself), so nothing here moves the map.
      if (t && t.kind === 'dirs') { t = A.dir && A.dir.to ? A.dir.to.place : null; fit = false; }
      if (t && t.kind === 'hall') {
        const b = M.find(A.c, t.name);
        // (Its own name stays on the map under the pin; my hall's pin says "My room" instead.)
        const mine = M.norm(b && b.name) === M.norm(stayHall());
        if (b) { sel = b.name; pins.push({ x: b.lx, y: b.ly, kind: 'to', of: mine ? b.name : '', label: mine ? stayName() : '' }); box = M.boxOf(A.c, [b.name], 10); }
      } else if (t && t.kind === 'spot') {
        const s = A.c.spots.find(z => z.id === t.id);
        if (s) { pins.push({ x: s.cx, y: s.cy, kind: 'to', label: spotName(s.id) }); box = { x: s.cx - 60, y: s.cy - 60, w: 120, h: 120 }; }
      } else if (t && t.kind === 'door' && A.L) {
        const e = A.L.entrance(t.code, t.number), B = A.L.building(t.code);
        if (e) box = { x: e.at[0] - 25, y: e.at[1] - 25, w: 50, h: 50 };
        if (B && B.item) sel = '';
      } else if (t && t.kind === 'feat' && A.L) {
        if (t.at) box = { x: t.at[0] - 12, y: t.at[1] - 12, w: 24, h: 24 };
      } else if (t && (t.kind === 'restrooms' || t.kind === 'elevators')) {
        // (The list's first is rung on its floor, below.)
      } else if (planned(t)) {
        // A place in the build: no pin and no tinted roof; its building opens with the room in tan (§4.3).
      } else if (t) {
        const p = P(t.code), w = p ? where(p) : { kind: 'none' };
        // (A field not pinned yet isn't its building: the building isn't tinted as the place, round 2 part 2.)
        if (w.b && w.kind !== 'outdoor') sel = w.b.name;
        green = w.green || null;
        if (w.kind === 'pin') pins.push({ x: w.x, y: w.y, kind: 'to', label: pinName(p) });
        // A building: a pin on it. A room with no pin: its building tinted, never a pin that reads as the room.
        else if (w.b && w.kind !== 'outdoor' && String(p.code).indexOf('/') < 0) pins.push({ x: w.b.lx, y: w.b.ly, kind: 'to', label: '' });
        box = w.kind === 'pin' ? M.boxOf(A.c, w.b ? [w.b.name] : [], 30) : w.b ? M.boxOf(A.c, [w.b.name], 10) : null;
        if (w.kind === 'pin' && !box) box = { x: w.x - 60, y: w.y - 60, w: 120, h: 120 };
      }
      // Where I sleep: a bed on my hall, its name always shown (polish 2: Reed drawn like every other hall).
      const sh = stayHall() && M.find(A.c, stayHall());
      // It keeps its schedule code ("N · Hodson"), so the household can match it to the schedule (round 2).
      if (sh && !(t && t.kind === 'hall' && M.norm(t.name) === M.norm(sh.name))) pins.push({ x: sh.lx, y: sh.ly, kind: 'stay', of: sh.name, label: shorts[sh.name] || M.shortOf(sh), code: bCode(sh) });
      m.pins(pins);
      m.select(sel, green);
      // What covers the map: the search bar (both layouts) and the sheet (a phone); fits and names keep clear.
      // (A laptop's map keeps its foot, the scale and the credit, clear too: round 2 part 2, a route's start
      // sat under the credit line.)
      const foot = A.mode !== 'full' && A.mapEl && (A.mapEl.querySelector('.pv-foot') || A.mapEl.querySelector('.pv-credit'));
      const footH = foot && foot.offsetHeight ? Math.max(0, Math.round(A.mapEl.getBoundingClientRect().bottom - foot.getBoundingClientRect().top)) + 8 : 0;
      m.inset(A.walk ? walkInset() : Object.assign({ top: topInset(), bottom: A.mode === 'full' ? A.sheetH + 12 + dockH() : footH }, sideInset()));
      if (A.L) {
        A.L.picked(sel);
        destFor(t, fit);
        if (fit && t && (t.kind === 'door' || t.kind === 'feat') && box) { m.look(box.x + box.w / 2, box.y + box.h / 2, Math.max(3, 1 / Math.max(1e-6, m.view().w / Math.max(1, A.mapEl.getBoundingClientRect().width))), true); return; }
        if (planned(t)) return;
      }
      if (fit && box) m.fit(roomy(box, A.mode === 'full' ? .45 : .35), 20, true);
    }
    // A place drawn on its floor: in the build, and its floor here (one that didn't come is shown as a campus
    // with no plans shows it: its building tan, a pin on a whole building).
    const planned = t => { const pl = t && t.code && !t.kind && A.L ? planOf(P(t.code)) : null; return !!pl && !A.L.missing(pl.code); };
    // The place's building opened on its floor, the room in tan, the door line drawn; framed once known
    // (§4.3): the room and its door centred, at the building's fit, at least 2.2 px a metre, closer for a
    // small room near its door.
    function destFor(t, fit) {
      const pl = t && t.code && !t.kind ? planFor(t) : null;
      const key = pl ? pl.place : '';
      if (fit && pl) A.fitKey = key;
      if (key === A.destKey) { if (fit && pl && A.destInfo) frame(A.destInfo); return; }
      A.destKey = key; A.destInfo = null;
      A.L.dest(pl ? { code: pl.code, rooms: pl.rooms, place: pl.room ? String(t.code).toUpperCase() : pl.place, name: pl.name || '' } : null).then(info => {
        if (!info || A.destKey !== key) return;
        A.destInfo = info;
        if (A.fitKey === key) frame(info);
        if (pl.rooms.length && !A.near[key]) nearFor(pl);
      });
    }
    function frame(info) {
      A.fitKey = '';
      if (!A.map || !A.L) return;
      const bs = info.B.box ? A.L.scaleFor(info.B.box, 16) : 2.2;
      const s = info.room ? Math.min(A.L.scaleFor(info.box, 40), Math.max(bs, 2.2), 24) : Math.min(bs, 24);
      const b = info.room ? info.box : info.B.box || info.box;
      if (b) A.map.look(b.x + b.w / 2, b.y + b.h / 2, s, true);
    }

    /* ------------------------------------------------ the views in the sheet or panel */

    const x = '<button type="button" class="pm-x" data-pm="close" aria-label="Close">' + I.close + '</button>';
    // Nothing chosen: the usual places, one tap each (my room, what's next, Help's places). On a laptop the
    // building cards below carry each building's Still today, so the panel neither repeats them nor names
    // the next thing as a chip; its own Still today keeps only what no card shows (conference-1, Oct 28).
    function browseView() {
      if (A.plans) return peekView();
      // Last in the row, quietly: For families, when the campus marks a nursery, family restroom or quiet room.
      const fam = familyPlaces().length ? '<button type="button" class="pm-chip" data-pm="families">' + I['f-family restroom'] + '<span><b>For families</b></span></button>' : '';
      // First, on a phone: Show where I am (Andrew's guide, Oct 13), the phone's location as the blue dot,
      // asked for only when it's tapped; once on, it says so, and a tap centres the map on it again.
      const on = A.watch != null;
      const me = touch() ? '<button type="button" class="pm-chip pm-chip--me" data-pm="locate" aria-pressed="' + on + '">' + I.locate + '<span><b>' + (on ? 'Showing where you are' : 'Show where I am') + '</b></span></button>' : '';
      const embed = A.mode === 'embed';
      const chips = me + quickChips(embed) + fam;
      const status = A.nav.status && A.nav.status !== 'Locating' ? '<p class="pm-status" data-peek>' + I.locate + esc(A.nav.status) + '</p>' : '';
      const still = embed ? stillToday(null, null, true, new Set(groups().map(g => g.key))) : '';
      return (chips ? '<div class="pm-quick" data-peek>' + chips + '</div>' : '') + status + (still ? '<div class="pm-card">' + still + '</div>' : '');
    }
    // With floor plans (§4.1): at most two rows, each drawn only while true (Next, My room), then one strip
    // of chips (Restrooms · First Aid · Information · Dining · For families), each only when the campus has one.
    function peekView() {
      const rows = [], nx = nextEvent();
      const row = (attrs, label, title, right) => '<button type="button" class="pm-prow" ' + attrs + '><span class="pm-prow__m"><span class="pm-k">' + esc(label) + '</span><b>' + esc(title) + '</b></span>' + (right ? '<small>' + esc(right) + '</small>' : '') + I.next + '</button>';
      if (nx) { const b = where(P(nx.code)).b; rows.push(row('data-pm="room" data-code="' + esc(nx.code) + '"', 'Next' + (nx.start != null ? ' · ' + clock(nx.start) : ''), nx.title, b ? bShort(b) : '')); }
      if (stayEnd()) { const h = stayHall() && M.find(A.c, stayHall()); rows.push(row('data-pm="set" data-v="stay"', stayName(), staySub(true) || stayName(), h ? shorts[h.name] || M.shortOf(h) : '')); }
      const chips = stripChips(false);
      const status = A.nav.status && A.nav.status !== 'Locating' ? '<p class="pm-status" data-peek>' + I.locate + esc(A.nav.status) + '</p>' : '';
      return (rows.length ? '<div class="pm-prows" data-peek>' + rows.join('') + '</div>' : '') + status + (chips ? '<div class="pm-quick pm-strip" data-peek>' + chips + '</div>' : '');
    }
    // The strip's chips; in Search, Elevators in place of Dining and For families (§4.2).
    function stripChips(search) {
      const out = [], chip = (attrs, icon, title) => '<button type="button" class="pm-chip" ' + attrs + '>' + icon + '<span><b>' + esc(title) + '</b></span></button>';
      const help = (A.ctx.help || []).filter(h => h.place && P(h.place) && routable(P(h.place)));
      if (A.plans) out.push(chip('data-pm="list" data-v="restroom"', I['f-restroom'], 'Restrooms'));
      const aid = help.find(h => /aid|medic|nurse/i.test(h.need));
      if (aid) out.push(chip('data-pm="room" data-code="' + esc(P(aid.place).code) + '"', I.cross, 'First Aid'));
      const desk = A.c.spots.find(z => z.spot === 'desk'), info = help.find(h => /^info/i.test(h.need));
      if (desk) out.push(chip('data-pm="spot" data-id="' + esc(desk.id) + '"', I.desk, 'Information'));
      else if (info) out.push(chip('data-pm="room" data-code="' + esc(P(info.place).code) + '"', I.desk, 'Information'));
      if (search) { if (A.plans) out.push(chip('data-pm="list" data-v="elevator"', I['f-elevator'], 'Elevators')); return out.join(''); }
      const dg = groups().find(g => !g.derived && where(g.main).b && where(g.main).b.kind === 'dining');
      if (dg) out.push(chip('data-pm="room" data-code="' + esc(dg.main.code) + '"', I.dining, 'Dining'));
      if (familyPlaces().length) out.push(chip('data-pm="families"', I['f-family restroom'], 'For families'));
      return out.join('');
    }
    // A laptop's list (§5.1): each Conference building with its rooms under floor labels, then the lots.
    function listView() {
      const gs = groups().filter(g => where(g.main).kind !== 'none');
      return '<div class="pm-blist">' + gs.map(g => '<section class="pm-blist__g" aria-label="' + esc(g.name) + '">' +
        (g.derived ? '<p class="pm-blist__h"><b>' + esc(g.name) + '</b></p>' : '<button type="button" class="pm-blist__h" data-pm="room" data-code="' + esc(g.main.code) + '"><b>' + esc(g.name) + '</b><code>' + esc(g.main.code) + '</code></button>') +
        roomsByFloor(g) + '</section>').join('') +
        (A.c.spots.length ? '<section class="pm-blist__g"><p class="pm-k pm-flk">Parking and services</p><ul class="pm-rooms">' + A.c.spots.map(z => '<li><button type="button" class="pm-row" data-pm="spot" data-id="' + esc(z.id) + '"><span>' + esc(z.name || M.SPOT[z.spot]) + '</span></button></li>').join('') + '</ul></section>' : '') + '</div>';
    }
    // A building's rooms under their floors ("1ST FLOOR"); a room the plans don't hold goes first, unlabelled.
    function roomsByFloor(g) {
      const rooms = g.derived ? g.all : g.rooms;
      if (!rooms.length) return '';
      const by = {}, none = [];
      rooms.forEach(r => { const f = planFloor(r); if (f == null) none.push(r); else (by[f] = by[f] || []).push(r); });
      const fl = Object.keys(by).map(Number).sort((a, b) => a - b);
      return (none.length ? '<ul class="pm-rooms">' + none.map(r => roomRow(r, g.name)).join('') + '</ul>' : '') +
        fl.map(f => '<p class="pm-k pm-flk">' + esc(M.floorName(f)) + '</p><ul class="pm-rooms">' + by[f].map(r => roomRow(r, g.name)).join('') + '</ul>').join('');
    }
    // A place in the build (§4.3): its name, building · floor · code, another floor's part, Directions
    // (the planner), what's on there today, and the nearest restroom and elevator.
    // A building: its name with its code, Directions, its rooms by floor, then today.
    function planView(p, g, isMain, plan) {
      // One of the place's rooms by IWU's name (the Chapel's Balcony): that room, its building and floor.
      if (plan.room) {
        const b = where(p).b, sub = [b ? bShort(b) : g.name, M.floorName(plan.room.floor), p.code].filter(Boolean).join(' · ');
        return '<div class="pm-card pm-placecard"><div data-peek>' + x + '<h2 class="pm-h pm-h--place">' + esc(plan.name) + '</h2><p class="pm-sub">' + esc(sub) + '</p>' + dirsTo(p) + '</div>' +
          stillToday(null, p.code, false, null, 'Today here') + nearbyView(plan) + '</div>';
      }
      const title = isMain
        ? '<h2 class="pm-h pm-h--place">' + esc(g.name) + ' <span class="pm-code">' + esc(p.code) + '</span></h2>'
        : '<h2 class="pm-h pm-h--place" aria-label="' + esc(p.name + ', ' + p.code) + '">' + esc(roomName(p)) + '</h2>';
      const fact = factLine(p, isMain);
      const more = plan.rooms.slice(1).map(r => {
        const f = A.P.got(plan.code, +r.floor), x_ = f && f._by[String(r.number)], nm = x_ && x_.r.name ? M.floors.titleCase(x_.r.name) : '';
        return '<button type="button" class="pm-flrow" data-pm="floor" data-fl="' + esc(r.floor) + '"><span>' + esc([nm, M.floorName(r.floor)].filter(Boolean).join(' · ')) + '</span>' + I.next + '</button>';
      }).join('');
      const feats = isMain ? featuresIn(g) : (p.features || []).filter(f => String(p.name).toLowerCase().indexOf(featWord(f).toLowerCase()) < 0).map(f => ({ f, room: null }));
      const featList = feats.length ? '<ul class="pm-feats" aria-label="For families and access">' + feats.map(f => featRow(f, g)).join('') + '</ul>' : '';
      const today = stillToday(isMain ? g.key : null, p.code, false, null, 'Today here');
      const rooms = isMain ? roomsByFloor(g) : '';
      return '<div class="pm-card pm-placecard"><div data-peek>' + x + title + (fact ? '<p class="pm-sub">' + esc(fact) + '</p>' : '') + more + dirsTo(p) + '</div>' +
        featList + (rooms ? '<div class="pm-brooms"><p class="pm-k">Rooms</p>' + rooms + '</div>' : '') + today + (plan.rooms.length ? nearbyView(plan) : '') + '</div>';
    }
    // Nearby: the nearest restroom and elevator, along the halls, in feet; "Stairs only" where true.
    function nearbyView(plan) {
      const n = A.near[plan.place];
      if (!n || n === 'wait') return '';
      const fl = +plan.rooms[0].floor, rows = [];
      const row = (z, word, m) => '<li><button type="button" class="pm-nrow" data-pm="ring" data-b="' + esc(plan.code) + '" data-fl="' + z.floor + '" data-x="' + z.at[0] + '" data-y="' + z.at[1] + '"><span>' + esc(word + (+z.floor !== fl ? ' · ' + M.floorName(z.floor) : '')) + '</span><span class="pm-nrow__d">' + esc(M.feet(m)) + '</span></button></li>';
      if (n.rest && n.rest.x.at) rows.push(row(n.rest.x, n.rest.word, n.rest.m));
      if (n.lift && n.lift.x.at) rows.push(row(n.lift.x, 'Elevator', n.lift.m));
      else if (n.stairsOnly) rows.push('<li><p class="pm-nrow is-plain"><span>Stairs only</span></p></li>');
      return rows.length ? '<div class="pm-near"><p class="pm-k">Nearby</p><ul>' + rows.join('') + '</ul></div>' : '';
    }
    function nearFor(pl) {
      const r0 = pl.rooms[0], key = pl.place;
      A.near[key] = 'wait';
      A.origin = { code: pl.code, floor: +r0.floor, number: r0.number };
      A.L.nearby(pl.code, +r0.floor, r0.number).then(n => { A.near[key] = n || null; if (A.place && A.place.code && String(A.place.code).toUpperCase() === key.split('|')[0]) paint(); });
    }
    // A door (a tap on its mark): "South doors · Open 7:00 AM–10:00 PM · Step-free", only what's known (§3.6).
    function doorView(pl) {
      const e = A.L && A.L.entrance(pl.code, pl.number), B = A.L && A.L.building(pl.code);
      if (!e) return '';
      const d = doorRow(e.door), word = (d && d.label) || e.name || 'Entrance';
      const bits = [B ? B.short : '', d && d.open ? 'Open ' + d.open : '', d && d.stepFree === 'yes' ? 'Step-free' : ''].filter(Boolean).join(' · ');
      return '<div class="pm-card pm-placecard"><div data-peek>' + x + '<p class="pm-k">Entrance</p><h2 class="pm-h pm-h--place">' + esc(word) + '</h2>' + (bits ? '<p class="pm-sub">' + esc(bits) + '</p>' : '') +
        dirsBtn(true) + '</div></div>';
    }
    // A restroom, the stairs or an elevator (a tap on its icon, a row in a list).
    const FEAT = { women: ['Restroom', 'Women'], men: ['Restroom', 'Men'], family: ['', 'Family restroom'], unknown: ['', 'Restroom'], stairs: ['', 'Stairs'], elevator: ['', 'Elevator'] };
    const FEAT_END = { women: 'Women’s restroom', men: 'Men’s restroom' };
    function featView(pl) {
      const B = A.L && A.L.building(pl.code), w = FEAT[pl.sub] || FEAT.unknown;
      const sub = [B ? B.short : '', M.floorName(pl.floor)].filter(Boolean).join(' · ');
      return '<div class="pm-card pm-placecard"><div data-peek>' + x + (w[0] ? '<p class="pm-k">' + esc(w[0]) + '</p>' : '') + '<h2 class="pm-h pm-h--place">' + esc(w[1]) + '</h2><p class="pm-sub">' + esc(sub) + '</p>' +
        dirsBtn(!!(B && pl.at)) + '</div></div>';
    }
    // Restrooms (or Elevators): every one in the plans, the nearest first (§4.1, §4.2). Measured along the
    // halls from the room last opened, in its building; the rest by how far they are, with no distance said.
    function listFeatView(pl) {
      const kind = pl.kind === 'restrooms' ? 'restroom' : 'elevator', list = A.feats[kind];
      const head = '<div data-peek>' + x + '<h2 class="pm-h pm-h--place">' + (kind === 'restroom' ? 'Restrooms' : 'Elevators') + '</h2></div>';
      if (!Array.isArray(list)) return '<div class="pm-card pm-placecard">' + head + '</div>';
      return '<div class="pm-card pm-placecard">' + head + '<ul class="pm-rooms">' + uniqFeats(list).slice(0, 24).map(f => '<li><button type="button" class="pm-row" data-pm="feat" data-v="' + esc(featV(f)) + '"><span>' + esc(f.word) + '<small>' + esc(f.B.short + ' · ' + M.floorName(f.floor)) + '</small></span>' + (f.m != null ? '<span class="pm-nrow__d">' + esc(M.feet(f.m)) + '</span>' : '') + '</button></li>').join('') + '</ul></div>';
    }
    // Two the same to read (a floor's pair of "Restroom"s) are one row: the nearer.
    const uniqFeats = list => { const seen = {}; return list.filter(f => { const k = f.word + '|' + f.B.code + '|' + f.floor; if (seen[k]) return false; seen[k] = 1; return true; }); };
    const featV = f => 'feat:' + f.B.code + ':' + f.floor + ':' + (f.word === 'Elevator' ? 'elevator' : f.who || 'unknown') + ':' + f.number;
    // The list in order; the first opened on its floor.
    function loadFeats(kind, open) {
      if (!A.L) return Promise.resolve(null);
      const o = A.origin, at = A.nav.me && M.onCampus(A.c, A.nav.me) ? A.nav.me : (() => { const v = A.map.view(); return { x: v.x + v.w / 2, y: v.y + v.h / 2 }; })();
      const here = !!(A.nav.me && M.onCampus(A.c, A.nav.me));
      // With no room opened and no location, nothing is nearer than another: a building's entrance floor
      // first, women's and men's before a restroom IWU doesn't mark, then by how far from the map's middle.
      const rank = f => (+f.floor === +f.B.entrance ? 0 : 2) + (f.who === 'unknown' ? 1 : 0);
      return Promise.all([A.L.all(kind), o ? A.L.from(o.code, o.floor, o.number) : null]).then(([list, fn]) => {
        list.forEach(f => { f.m = fn ? fn(f.B.code, f.floor, f.number) : null; f.d = Math.hypot(f.at[0] - at.x, f.at[1] - at.y); });
        list.sort((a, b) => (a.m == null) - (b.m == null) || (a.m != null ? a.m - b.m : here ? a.d - b.d : rank(a) - rank(b) || a.d - b.d));
        A.measured = !!fn || here;
        list.at = featKey();
        A.feats[kind] = list;
        return list;
      });
    }
    // What the nearest were measured from: the room last opened, or where the phone is (to 10 m). Search
    // measures again when it's changed (round 2 part 2: the restrooms kept the order of the first look).
    const featKey = () => { const o = A.origin, me = A.nav.me && M.onCampus(A.c, A.nav.me) ? A.nav.me : null; return (o ? o.code + '|' + o.floor + '|' + o.number : '') + (me ? '@' + Math.round(me.x / 10) + ',' + Math.round(me.y / 10) : ''); };
    const featsStale = k => !Array.isArray(A.feats[k]) || A.feats[k].at !== featKey();
    function openList(kind) {
      A.place = { kind: kind === 'restroom' ? 'restrooms' : 'elevators' }; settle('half'); paint(); say(kind === 'restroom' ? 'Restrooms' : 'Elevators');
      const go = () => loadFeats(kind).then(list => {
        if (!list || !A.place || A.place.kind !== (kind === 'restroom' ? 'restrooms' : 'elevators')) return;
        paint();
        const f = list[0];
        if (f) { A.L.ring(f.B.code, f.floor, f.at); A.map.look(f.at[0], f.at[1], Math.max(3, curScale()), true); }
      });
      if (A.L) go(); else A.afterPlans = go;
    }
    const curScale = () => { const r = A.mapEl.getBoundingClientRect(); return r.width / Math.max(1e-6, A.map.view().w); };
    function openDoor(code, number) { A.place = { kind: 'door', code, number }; settle('half'); paint(true); const e = A.L && A.L.entrance(code, number); if (e) say((doorRow(e.door) || {}).label || e.name || 'Entrance'); }
    function openFeat(code, n, sub, number) {
      if (!A.L) return;
      const k = sub === 'stairs' || sub === 'elevator' ? sub : 'restroom';
      const go = () => {
        const ft = A.L.feature(code, n, k, number); if (!ft) return;
        A.place = { kind: 'feat', code, floor: n, sub: k === 'restroom' ? ft.who || 'unknown' : k, number, at: ft.at };
        settle('half'); paint(true);
        A.L.ring(code, n, ft.at);
        say((FEAT[A.place.sub] || FEAT.unknown)[1]);
      };
      if (A.L.feature(code, n, k, number)) go(); else A.L.P.floor(code, n).then(go);
    }

    // A place: its name and code, how to find it, what's inside, what's still on, and Directions.
    // For families (Andrew's guide, Oct 13): every nursery, family restroom and quiet room on the campus,
    // each opening its room. Reached from its chip, which is there only when places.csv marks one.
    function familiesView() {
      const list = familyPlaces();
      return '<div class="pm-card pm-placecard"><div data-peek>' + x + '<h2 class="pm-h">For families</h2></div>' +
        (list.length ? '<ul class="pm-feats">' + list.map(z => featRow(z, z.g, true)).join('') + '</ul>' : '') + '</div>';
    }
    function placeView(pl) {
      if (pl.kind === 'dirs') return dirsView();
      if (pl.kind === 'families') return familiesView();
      if (pl.kind === 'door') return doorView(pl);
      if (pl.kind === 'feat') return featView(pl);
      if (pl.kind === 'restrooms' || pl.kind === 'elevators') return listFeatView(pl);
      if (pl.kind === 'spot') {
        const s = A.c.spots.find(z => z.id === pl.id);
        if (!s) return '';
        return '<div class="pm-card pm-placecard"><div data-peek>' + x + '<p class="pm-k">' + esc(M.SPOT[s.spot] || 'Place') + '</p><h2 class="pm-h">' + esc(s.name || M.SPOT[s.spot]) + '</h2>' + (s.note ? '<p class="pm-line">' + I.pin + '<span>' + esc(s.note) + '</span></p>' : '') +
          dirsBtn(true) + '</div></div>';
      }
      if (pl.kind === 'hall') {
        // My own hall (§4.3 My room): "My room", the hall, then the floor and the rooms (the household's alone).
        const mine = !!stayHall() && M.norm(stayHall()) === M.norm(pl.name), sub = mine ? staySub(false, true) : '';
        const hc = mine ? bCode(M.find(A.c, pl.name)) : '';
        return '<div class="pm-card pm-placecard"><div data-peek>' + x + '<p class="pm-k">' + (mine ? esc(stayName()) : (M.find(A.c, pl.name) || {}).kind === 'hall' ? 'Hall' : 'Building') + '</p><h2 class="pm-h">' + esc(pl.name) + (hc ? ' <span class="pm-code">' + esc(hc) + '</span>' : '') + '</h2>' + (sub ? '<p class="pm-sub">' + esc(sub) + '</p>' : '') +
          dirsBtn(!!M.find(A.c, pl.name)) + '</div></div>';
      }
      const p = P(pl.code); if (!p) return '';
      const g = groups().find(z => z.key === keyOf(p.code)), main = g && g.main, isMain = main && main.code === p.code && !g.derived;
      const plan = planFor(pl);
      if (plan && g) return planView(p, g, isMain, plan);
      const w = where(p), line = M.placeLine(A.c, p, places(), w.kind === 'pin' && w.b ? M.nearestDoor(A.c, w.b.name, w) : null);
      const sub = w.kind === 'outdoor' && w.b ? 'Near ' + bShort(w.b) : [isMain ? '' : (w.b ? bShort(w.b) : g ? g.name : ''), isMain || !w.b ? '' : roomRest(p, w.b.name), line].filter(Boolean).join(' · ');
      const room = String(p.code).indexOf('/') > -1 && w.kind === 'building';
      // What the map is missing is said to members (the pins tool's people), never to the public (polish 2).
      const not = !member(A.ctx.year) ? '' : w.kind === 'outdoor' ? 'Outdoor · Not on the map yet' : w.kind === 'none' ? 'Not on the map yet' : room ? 'Room not on the map yet' : '';
      // Its features (a building's: its own and its rooms'; a room's: any its name doesn't already say),
      // each once: a room with one is listed there, not again among the rooms.
      const feats = isMain ? featuresIn(g) : (p.features || []).filter(f => String(p.name).toLowerCase().indexOf(featWord(f).toLowerCase()) < 0).map(f => ({ f, room: null }));
      const featured = feats.filter(f => f.room).map(f => f.room.code), plain = isMain ? g.rooms.filter(r => featured.indexOf(r.code) < 0) : [];
      const featList = feats.length ? '<ul class="pm-feats" aria-label="For families and access">' + feats.map(f => featRow(f, g)).join('') + '</ul>' : '';
      const rooms = plain.length ? '<ul class="pm-rooms">' + plain.map(r => roomRow(r, main.name, true)).join('') + '</ul>' : '';
      return '<div class="pm-card pm-placecard"><div data-peek>' + x + '<h2 class="pm-h" aria-label="' + esc(p.name + ', ' + p.code) + '">' + esc(roomName(p)) + ' <span class="pm-code" aria-hidden="true">' + esc(p.code) + '</span></h2>' +
        (sub ? '<p class="pm-sub">' + esc(sub) + '</p>' : '') + (not ? '<p class="pm-line">' + I.pin + '<span>' + esc(not) + '</span></p>' : '') +
        dirsTo(p) + '</div>' +
        // With floor plans, a place's own rows are "Today here" as on a room's sheet (§10.1); the campus
        // without plans keeps its words.
        featList + stillToday(isMain ? g.key : null, p.code, false, null, A.plans ? 'Today here' : '') + rooms + '</div>';
    }
    // One row style for a room everywhere (the place card, the cards, the picker).
    const roomRow = (r, bname, small) => { const fl = small && planFloor(r); return '<li><button type="button" class="pm-row" data-pm="room" data-code="' + esc(r.code) + '"><span>' + esc(inBuilding(r, bname)) + (fl != null && fl !== false ? '<small>' + esc(M.floorName(fl)) + '</small>' : small && (r.floor || r.inside) ? '<small>' + esc(M.placeLine(A.c, r, places())) + '</small>' : '') + '</span><code>' + esc(r.code) + '</code></button></li>'; };
    // What's still on today in a building (or at one room, or everywhere: all), as Today says it:
    // the timed rows first ("Now", then by time), then the places open all day, "Open · until 11 PM"
    // or "Closed · reopens 12:00 PM" (polish 1: Places said open while Today said closed during
    // services). One grid, so every title lines up; each row one 44 px button. skip: the buildings (keys)
    // whose cards already list theirs.
    function stillToday(key, code, all, skip, label) {
      const rows = today().filter(it => it.code && (all || (key ? keyOf(it.code) === key : String(it.code).toUpperCase() === String(code).toUpperCase())) && it.state !== 'past' && !(skip && skip.has(keyOf(it.code))));
      if (!rows.length) return '';
      const timed = rows.filter(it => !it.allDay).sort((a, b) => (b.state === 'now') - (a.state === 'now') || (a.start == null ? 1e9 : a.start) - (b.start == null ? 1e9 : b.start));
      const open = rows.filter(it => it.allDay && (it.state === 'now' || it.closed));
      const cap = all && A.allToday ? Infinity : all ? 6 : 5, list = timed.slice(0, cap).concat(open.slice(0, Math.max(0, cap - timed.length)));
      const more = rows.length - list.length;
      const at = it => all && P(it.code) ? ' · ' + (shorts[(where(P(it.code)).b || {}).name] || M.shortOf(where(P(it.code)).b) || P(it.code).name) : '';
      const row = it => {
        const k = it.allDay ? (it.closed ? 'Closed' : 'Open') : it.state === 'now' ? 'Now' : it.start != null ? clock(it.start) : it.startText || '';
        const tail = it.allDay ? (it.closed ? 'reopens ' + clock(it.closed.end) : it.end != null ? 'until ' + clock(it.end) : '') : it.state === 'now' && it.end != null ? 'until ' + clock(it.end) : '';
        const inner = '<span class="pm-ev__k">' + esc(k) + '</span><span class="pm-ev__t">' + esc(it.title) + (tail || at(it) ? '<small>' + esc((tail ? ' · ' + tail : '') + at(it)) + '</small>' : '') + '</span>';
        return '<li class="' + (it.state === 'now' && !it.closed ? 'is-now' : it.closed ? 'is-closed' : '') + '">' + (it.id ? '<button type="button" class="pm-ev" data-pm="event" data-id="' + esc(it.id) + '">' + inner + '</button>' : '<div class="pm-ev">' + inner + '</div>') + '</li>';
      };
      return '<div class="pm-today"><p class="pm-k">' + (label || 'Still today') + '</p><ul>' + list.map(row).join('') + (more > 0 ? '<li class="pm-today__more">' + (all ? '<button type="button" class="pm-link" data-pm="more-today">' + more + ' more</button>' : more + ' more') + '</li>' : '') + '</ul></div>';
    }
    // Every building, what's in it and what's still on: the chosen one first, then what's on now, then next.
    function cardsView() {
      const gs = groups(), sel = A.place && A.place.code ? keyOf(A.place.code) : '';
      const first = g => { const rows = today().filter(it => it.code && keyOf(it.code) === g.key && it.state !== 'past' && !it.allDay); const nowOn = rows.some(it => it.state === 'now'); const nx = rows.filter(it => it.start != null).map(it => it.start).sort((a, b) => a - b)[0]; return [g.key === sel ? 0 : 1, nowOn ? 0 : 1, nx == null ? 1e9 : nx]; };
      const order = gs.map((g, i) => ({ g, i, k: first(g) })).sort((a, b) => a.k[0] - b.k[0] || a.k[1] - b.k[1] || a.k[2] - b.k[2] || a.i - b.i).map(z => z.g);
      // Polish 2: the whole head is one 44 px row that opens the place (its sheet has Directions, filled);
      // the cards carry no Directions of their own (six or more on the full sheet before).
      const head = (attrs, name, code) => '<button type="button" class="pm-cardhead" ' + attrs + '><h3 class="pm-h">' + esc(name) + '</h3>' + (code ? '<span class="pm-code">' + esc(code) + '</span>' : '') + I.next + '</button>';
      const card = g => {
        const w = where(g.main), not = !member(A.ctx.year) ? '' : w.kind === 'outdoor' ? 'Outdoor · Not on the map yet' : w.kind === 'none' ? 'Not on the map yet' : '';
        const rooms = (g.derived ? g.all : g.rooms);
        const list = rooms.length ? '<ul class="pm-rooms">' + rooms.map(r => roomRow(r, g.name)).join('') + '</ul>' : '';
        return '<section class="pm-card' + (g.key === sel ? ' is-sel' : '') + '" aria-label="' + esc(g.name) + '">' + (g.derived ? '<div class="pm-cardhead"><h3 class="pm-h">' + esc(g.name) + '</h3><span class="pm-code">' + esc(g.key) + '</span></div>' : head('data-pm="room" data-code="' + esc(g.main.code) + '"', g.name, g.main.code)) +
          (not ? '<p class="pm-quiet">' + esc(not) + '</p>' : '') + stillToday(g.key) + list + '</section>';
      };
      const spots = A.c.spots.map(s => '<section class="pm-card">' + head('data-pm="spot" data-id="' + esc(s.id) + '"', s.name || M.SPOT[s.spot], '') + (s.note ? '<p class="pm-quiet">' + esc(s.note) + '</p>' : '') + '</section>').join('');
      return (A.mode === 'full' ? '<p class="pm-k">Buildings</p>' : '') + order.map(card).join('') + spots;
    }
    // The usual places, one tap each, each shown on the map with its card: my room, the next thing on
    // today, and the places Help points to (First Aid, the Lodging Desk…). noNext: leave out the next thing
    // (a laptop's Places, where its building's card already lists it).
    function quickChips(noNext) {
      const out = [], se = stayEnd();
      const chip = (attrs, icon, title, sub) => '<button type="button" class="pm-chip" ' + attrs + '>' + icon + '<span><b>' + esc(title) + '</b>' + (sub ? '<small>' + esc(sub) + '</small>' : '') + '</span></button>';
      if (se) out.push(chip('data-pm="set" data-v="stay"', I.bed, stayName(), staySub()));
      const nx = noNext ? null : nextEvent();
      if (nx) out.push(chip('data-pm="room" data-code="' + esc(nx.code) + '" aria-label="Next: ' + esc(nx.title) + '"', I.clock, nx.title, 'Next' + (nx.start != null ? ' · ' + clock(nx.start) : '')));
      out.push(helpChips(3));
      return out.join('');
    }
    // The places Help names (First Aid, the Lodging Desk…), in Help's order, one tap each.
    function helpChips(max) {
      const chip = (attrs, icon, title) => '<button type="button" class="pm-chip" ' + attrs + '>' + icon + '<span><b>' + esc(title) + '</b></span></button>';
      return (A.ctx.help || []).filter(h => h.place && P(h.place) && routable(P(h.place))).slice(0, max || 99).map(h => chip('data-pm="room" data-code="' + esc(h.place) + '"', /aid|medic|nurse/i.test(h.need) ? I.cross : /lodg|room|key/i.test(h.need) ? I.bed : /lost|found/i.test(h.need) ? I.search : '<span class="pm-i" aria-hidden="true"></span>', h.need)).join('');
    }

    /* ------------------------------------------------ Directions: the planner (Nov 5; docs/34 §4.5, §5.1) */

    // An end of the route: what its row says (label, sub), what ogc-map-route.js's plan takes (spec), and
    // the place it came from (place: what the map marks as where you're going while there's no route).
    // kind: here (My location) · stay (My room) · place · point (Set start's tap) · hall · spot · door · feat.
    const endHere = () => { const me = A.nav.me; return { kind: 'here', label: 'My location', spec: me && me.lat != null ? { lat: me.lat, lng: me.lng } : null, place: null }; };
    function endStay() {
      const s = A.stay; if (!s) return null;
      if (s.type === 'camper' && camper()) { const k = camper(); return { kind: 'stay', label: stayName(), sub: k.name || M.SPOT[k.spot] || '', spec: { x: k.cx, y: k.cy }, place: { kind: 'spot', id: k.id } }; }
      const h = stayHall() && M.find(A.c, stayHall());
      // (Its hall's door: no hall floor is public, so the route ends there and says so.)
      return h ? { kind: 'stay', label: stayName(), sub: staySub(true) || h.name, spec: { hall: h.name }, place: { kind: 'hall', name: h.name } } : null;
    }
    function endPlace(code) {
      const p = P(code); if (!p || !routable(p)) return null;
      const main = String(p.code).indexOf('/') < 0, w = where(p), b = w.b;
      const sub = (A.plans && planOf(p) ? factLine(p, main) : '') || (w.kind === 'outdoor' && b ? 'Near ' + bShort(b) : main ? p.code : [b ? bShort(b) : '', p.code].filter(Boolean).join(' · '));
      return { kind: 'place', code: p.code, label: roomName(p), sub, spec: { code: p.code }, place: { code: p.code } };
    }
    function endHall(name) {
      const b = M.find(A.c, name); if (!b) return null;
      if (stayHall() && M.norm(stayHall()) === M.norm(b.name)) return endStay();
      return { kind: 'hall', label: b.name, sub: '', spec: { building: b.name }, place: { kind: 'hall', name: b.name } };
    }
    function endSpot(id) {
      const s = A.c.spots.find(z => z.id === id);
      return s ? { kind: 'spot', label: spotName(id), sub: s.name ? M.SPOT[s.spot] || '' : '', spec: { x: s.cx, y: s.cy }, place: { kind: 'spot', id } } : null;
    }
    function endDoor(code, number) {
      const e = A.L && A.L.entrance(code, number), B = A.L && A.L.building(code); if (!e) return null;
      const d = doorRow(e.door);
      return { kind: 'door', label: (d && d.label) || e.name || 'Entrance', sub: B ? B.short : '', spec: { door: e.door }, place: { kind: 'door', code, number } };
    }
    // A restroom, the stairs or an elevator: its room in the public build, else the hall point by it.
    function endFeat(pl) {
      if (!pl.at) return null;
      const B = A.L && A.L.building(pl.code), w = FEAT[pl.sub] || FEAT.unknown;
      const at = { x: pl.at[0], y: pl.at[1], floor: +pl.floor };
      // Named as the arrival names it (ogc-map-route.js): "Women’s restroom", never "Restroom · Women".
      return { kind: 'feat', label: FEAT_END[pl.sub] || w[1], sub: [B ? B.short : '', M.floorName(pl.floor)].filter(Boolean).join(' · '),
        spec: pl.number ? { room: pl.code + '|' + pl.floor + '|' + pl.number } : at, alt: pl.number ? at : null, place: pl };
    }
    // What's open in the sheet, as the route's To.
    function endOfPlace(pl) {
      if (!pl) return null;
      if (pl.kind === 'hall') return endHall(pl.name);
      if (pl.kind === 'spot') return endSpot(pl.id);
      if (pl.kind === 'door') return endDoor(pl.code, pl.number);
      if (pl.kind === 'feat') return endFeat(pl);
      return pl.code && !pl.kind ? (pl.room ? endRoom(pl.room) : endPlace(pl.code)) : null;
    }
    // A Conference place's own room by IWU's name (the Chapel's Balcony): the place, ending at that room.
    function endRoom(r) {
      const e = r && endPlace(r.code); if (!e) return null;
      const b = where(P(r.code)).b;
      return Object.assign(e, { label: r.name, sub: [b ? bShort(b) : '', M.floorName(r.floor)].filter(Boolean).join(' · '), spec: { room: r.b + '|' + r.floor + '|' + r.number }, place: { code: e.code, room: r } });
    }
    // The rooms of a Conference place that has more than one in the build, by IWU's name, where the place's
    // own name doesn't already say it (the Chapel's and PPAC's Balcony beside their Auditorium; round 2
    // part 2: "balcony" found nothing). From the walking graph's marks, once it's read.
    function namedRooms() {
      const w = A.build && A.build.walk, ix = A.P && A.P.places; if (!w || !ix || !w.marks) return [];
      const col = {}; (w.mark_cols || []).forEach((k, i) => { col[k] = i; });
      const per = {};
      w.marks.forEach(m => { if (m[col.kind] === 'room' && m[col.codes]) String(m[col.codes]).split('|').forEach(c => { (per[c] = per[c] || []).push(m); }); });
      const tc = s => String(s || '').toLowerCase().replace(/(^|[\s/(-])([a-z])/g, (z, a, b) => a + b.toUpperCase());
      const out = [];
      Object.keys(per).forEach(c => {
        const p = P(c), x = ix[String(c).toUpperCase()]; if (!p || !x || per[c].length < 2) return;
        per[c].forEach(m => { const name = tc(m[col.name]); if (name && String(p.name).toLowerCase().indexOf(name.toLowerCase()) < 0) out.push({ code: p.code, b: x.code, floor: +m[col.floor], number: String(m[col.number]), name }); });
      });
      return out;
    }
    const roomV = r => 'room:' + r.code + '|' + r.floor + '|' + r.number;
    const roomOfV = v => namedRooms().find(r => roomV(r) === v) || null;
    // A choice in From's or To's Search (its data-v), as an end.
    function routeEnd(v) {
      v = String(v || '');
      if (v === 'here') return endHere();
      if (v === 'stay') return endStay();
      if (v.indexOf('hall:') === 0) return endHall(v.slice(5));
      if (v.indexOf('spot:') === 0) return endSpot(v.slice(5));
      if (v.indexOf('room:') === 0) return endRoom(roomOfV(v));
      if (v.indexOf('feat:') === 0) {
        const e = endFrom(v), f = e && A.L && A.L.feature(e.code, e.floor, e.sub === 'stairs' || e.sub === 'elevator' ? e.sub : 'restroom', e.number);
        return f ? endFeat(Object.assign(e, { at: f.at })) : null;
      }
      return endPlace(v);
    }
    // Step-free (P8): kept on this device; until it's set, on when the signed-in household ticked No stairs.
    const SF_KEY = 'ogc-map-stepfree';
    const stepFree = () => { const v = LS.get(SF_KEY, null); return v == null ? !!(A.stay && A.stay.stairs) : !!v; };
    // The router waits for the year's plans (or their failing): a campus with none routes outdoors.
    const whenPlans = fn => { if (!A.plans || A.L || A.plansFailed || !M.floors) fn(); else A.plansWait.push(fn); };
    function routerNow() {
      const out = () => M.routerOf(A.c);
      if (!A.P) return Promise.resolve(out());
      if (A.build) return Promise.resolve(M.routerOf(A.c, A.build));
      return Promise.all([A.P.walkRaw(), A.P.area()]).then(([walk, area]) => {
        if (!walk) return out();
        if (!A.build) A.build = { walk, area, index: A.P.ix };
        return M.routerOf(A.c, A.build);
      }, out);
    }
    // The venue's date and time now (the doors' hours and closures are the venue's), and its minutes.
    function venueNow() {
      const n = A.ctx.now ? A.ctx.now() : null;
      if (!n) return { date: '', time: '', minutes: null };
      const m = Math.max(0, Math.floor(n.minutes)) % 1440;
      return { date: n.date, time: String(Math.floor(m / 60)).padStart(2, '0') + ':' + String(m % 60).padStart(2, '0'), minutes: n.minutes };
    }
    // From, before anyone chooses (§4.5): My location on a phone on campus to 40 m, else My room, else none.
    // (Going to My room, From never starts there: Choose start instead.)
    function fromDefault(to) {
      const me = A.nav.me;
      to = to || (A.dir && A.dir.to);
      if (touch() && A.mode === 'full' && me && me.lat != null && near(me) && me.acc <= 40 && A.watch != null) return endHere();
      return to && to.kind === 'stay' ? null : endStay();
    }
    // Directions to an end: the planner in the sheet (half) or the panel. Closing it goes back to the place.
    function openDirs(to) {
      if (!to) return;
      const back = A.place && A.place.kind !== 'dirs' ? A.place : A.dir ? A.dir.back : null;
      A.dir = { to, from: fromDefault(to), auto: true, plan: null, gen: 0, list: false, focus: -1, back, at: null };
      A.place = { kind: 'dirs' };
      // (The place's own framing, still on its way, gives way to the route's.)
      A.fitKey = '';
      settle('half');
      // On a phone it asks where you are (once; never when it's been refused): My location, if it's good enough.
      if (touch() && A.mode === 'full' && A.perm !== 'denied' && A.watch == null) locate();
      paint();
      say('Directions · ' + to.label);
      replan(true);
    }
    // (back: what opens after it; Arrived's Done opens where it went.)
    function closeDirs(back) {
      const d = A.dir;
      if (A.walk) endWalk(true);
      A.dir = null;
      if (A.map) { A.map.route(null); A.map.reach(null); }
      if (A.L) { A.L.pick(null); A.L.route(null); A.L.focus(null); }
      A.place = back !== undefined ? back : d && d.back ? d.back : null;
      settle(A.place ? 'half' : 'peek');
      paint(!!A.place);
    }
    // The route again (an end changed, Step-free, a fix): planned over the one router, drawn, framed.
    // animate: the line draws in (a new trip); a reroute appears with no motion (§8).
    // The plan for what's open (its ends, Step-free, the venue's time), over the one router.
    function planWith(d, R) {
      const now = venueNow(), o = { places: places(), stepFree: stepFree(), date: now.date, time: now.time };
      let r;
      if (!d.from) r = { ok: false, reason: 'Choose start', side: 'from' };
      else if (!d.from.spec) r = { ok: false, reason: d.from.kind === 'here' ? (A.nav.status && A.nav.status !== 'Approximate location' ? A.nav.status : 'Locating') : 'Choose start', side: 'from' };
      else if (!d.to || !d.to.spec) r = { ok: false, reason: 'Choose place', side: 'to' };
      else {
        r = M.plan(R, d.from.spec, d.to.spec, o);
        // A restroom the public build has no room for: to the hall point beside it instead.
        if (d.to.alt && (!r.ok || r.unmapped)) { const r2 = M.plan(R, d.from.spec, d.to.alt, o); if (r2.ok) r = r2; }
      }
      return r;
    }
    // The route's own box (with room round it): the map may go that far while it shows (viewer.reach).
    function routeBox(r) {
      if (!r || !r.ok) return null;
      let x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity;
      r.parts.forEach(p => p.pts.forEach(q => { x0 = Math.min(x0, q[0]); y0 = Math.min(y0, q[1]); x1 = Math.max(x1, q[0]); y1 = Math.max(y1, q[1]); }));
      return isFinite(x0) ? { x: x0 - 60, y: y0 - 60, w: x1 - x0 + 120, h: y1 - y0 + 120 } : null;
    }
    function replan(animate) {
      // (Walking keeps its own route: a reroute replans from where you are, walkReroute.)
      const d = A.dir; if (!d || A.walk) return;
      const gen = d.gen = d.gen + 1;
      whenPlans(() => routerNow().then(R => {
        if (A.dir !== d || d.gen !== gen) return;
        const r = planWith(d, R);
        const was = d.plan, same = !!(was && was.ok && r.ok && was.legsText === r.legsText);
        d.plan = r; d.focus = -1;
        if (A.map) A.map.reach(routeBox(r));
        if (r.ok) {
          if (A.L) {
            A.L.pick(null);
            A.L.route(r);
            // The destination's building opens on the room's floor (§4.5): the end's floor.
            const end = r.steps[r.steps.length - 1];
            if (end && end.building && +end.floor) A.L.focus(end.building, +end.floor); else A.L.focus(null);
          }
        } else {
          if (A.L) A.L.route(null);
          if (A.map) A.map.route(null);
        }
        paint();
        A.fitKey = '';
        if (r.ok) { showRoute(animate && !same, null); fitRoute(r); }
        else if (r.reason === 'Set start') startPick(r.building);
        else {
          // No route to draw: where it's going, framed as its own sheet frames it.
          const tp = d.to && d.to.place, p = tp && tp.code && !tp.kind ? P(tp.code) : null, w = p ? where(p) : null;
          const b = w && w.b ? M.boxOf(A.c, [w.b.name], 10) : tp && tp.kind === 'hall' ? M.boxOf(A.c, [tp.name], 10) : null;
          if (b && A.map) A.map.fit(roomy(b, .45), 20, true);
        }
      }));
    }
    function showRoute(animate, s) {
      const d = A.dir, r = d && d.plan;
      if (!A.map) return;
      if (!r || !r.ok) { A.map.route(null); return; }
      A.map.route({ parts: r.parts, floorOf: code => A.L ? A.L.shown(code) : null, start: r.steps[0] ? r.steps[0].at : null,
        stretch: s && s.pts && s.pts.length > 1 ? { id: String(d.focus), pts: s.pts, floor: s.floor, building: s.building } : null, animate: !!animate });
    }
    // The whole route in view (§4.5), with the destination's building, clear of the sheet or the panel.
    function fitRoute(r) {
      if (!A.map || !r || !r.ok) return;
      let x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity;
      const add = (x, y) => { x0 = Math.min(x0, x); y0 = Math.min(y0, y); x1 = Math.max(x1, x); y1 = Math.max(y1, y); };
      r.parts.forEach(p => p.pts.forEach(q => add(q[0], q[1])));
      const end = r.steps[r.steps.length - 1], B = end && end.building && A.L ? A.L.building(end.building) : null;
      if (B && B.box) { add(B.box.x, B.box.y); add(B.box.x + B.box.w, B.box.y + B.box.h); }
      // (A start at a hall's door, on a laptop: the hall's name and pin in view too, not under the map's
      // scale. A phone's strip of map keeps the route as big as it can.)
      const fh = A.mode !== 'full' && A.dir && A.dir.from && A.dir.from.place && A.dir.from.place.kind === 'hall' ? M.find(A.c, A.dir.from.place.name) : null;
      if (fh && fh.lx != null) add(fh.lx, fh.ly);
      if (!isFinite(x0)) return;
      const w = Math.max(40, x1 - x0), h = Math.max(40, y1 - y0), cx = (x0 + x1) / 2, cy = (y0 + y1) / 2;
      A.map.fit({ x: cx - w / 2, y: cy - h / 2, w, h }, A.mode === 'full' ? 24 : 48, true);
    }
    // Inside a drawn building (§4.5): its entrance floor opens, and one tap on it sets the start.
    function startPick(name) {
      if (!A.L || !A.P || !name) return;
      const B = A.P.list.find(b => b.item && M.norm(b.item.name) === M.norm(name)) || A.P.list.find(b => M.norm(b.name) === M.norm(name));
      if (!B) return;
      A.L.focus(B.code, B.entrance);
      A.L.pick(pt => {
        const d = A.dir; if (!d) return;
        A.L.pick(null);
        d.from = { kind: 'point', label: (B.short || B.name) + ' · ' + M.floorName(pt.floor), sub: '', spec: { x: pt.x, y: pt.y, floor: pt.floor }, place: null };
        d.auto = false;
        replan(true);
      });
      if (B.box) A.map.fit(B.box, 24, true);
    }
    // A location fix (or its failing) with the planner open: My location as From when it's good enough,
    // the route again as you move (8 m or more), and My room or Choose start when there's no location.
    function onFix() {
      const d = A.dir; if (!d) return;
      const me = A.nav.me, bad = A.nav.status === 'Location off' || A.nav.status === 'Location unavailable';
      const moved = () => !d.at || !me || Math.hypot(me.x - d.at[0], me.y - d.at[1]) >= 8;
      if (d.from && d.from.kind === 'here') {
        if (bad) { if (d.auto) d.from = endStay(); d.at = null; replan(true); return; }
        if (me && me.lat != null && moved()) { const first = !d.from.spec; d.at = [me.x, me.y]; d.from = endHere(); replan(first); return; }
        paint(); return;
      }
      if (d.auto && !bad) { const f = fromDefault(); if (f && f.kind === 'here') { d.at = [me.x, me.y]; d.from = f; replan(true); return; } }
      paint();
    }
    function setEnd(which, e) {
      const d = A.dir; if (!d || !e) return;
      if (A.L) A.L.pick(null);
      d[which] = e;
      if (which === 'from') d.auto = false;
      d.list = false;
      if (e.kind === 'here' && touch() && A.watch == null) locate();
      paint();
      replan(true);
    }

    // The planner's view (§4.5): From and To, Swap, Step-free, the summary, Start (a phone) and Steps
    // (a phone; a laptop lists them in full). Every state is its status word (§4.11).
    const endIcon = e => !e ? I.pin : e.kind === 'here' ? '<span class="pm-medot" aria-hidden="true"></span>' : e.kind === 'stay' ? I.bed : I.pin;
    function endRow(which, e, main, sub) {
      const k = which === 'from' ? 'From' : 'To';
      return '<button type="button" class="pm-end' + (e ? '' : ' is-empty') + '" data-pm="end" data-which="' + which + '" aria-label="' + esc(k + ': ' + main + (sub ? ', ' + sub : '')) + '">' +
        '<span class="pm-end__k" aria-hidden="true">' + k + '</span>' + endIcon(e) + '<span class="pm-end__m"><b>' + nb(main) + '</b>' + (sub ? '<small>' + nb(sub) + '</small>' : '') + '</span></button>';
    }
    // The steps by where they are (§4.5: OUTSIDE · BARNES · 1ST FLOOR); a door goes with the stretch before it.
    const stepHead = s => {
      if (!s.building || !+s.floor) return 'Outside';
      const B = A.L && A.L.building(s.building);
      return [B ? B.short || B.name : s.building, M.floorName(s.floor)].join(' · ');
    };
    function stepGroups(r) {
      const gs = [];
      r.steps.forEach((s, i) => {
        const g = gs[gs.length - 1], head = s.kind === 'door' && g ? g.head : stepHead(s);
        if (g && g.head === head) g.rows.push(i); else gs.push({ head, rows: [i] });
      });
      return gs;
    }
    function stepRow(r, i) {
      const s = r.steps[i], n = r.steps.length;
      return '<li><button type="button" class="pm-step' + (A.dir.focus === i ? ' is-on' : '') + '" data-pm="step" data-i="' + i + '" aria-label="' + esc('Step ' + (i + 1) + ' of ' + n + ' · ' + s.text + (s.detail ? ' · ' + s.detail : '') + (s.distance ? ' · ' + s.distance : '')) + '">' +
        (I['r-' + s.icon] || I['r-straight']) + '<span class="pm-step__t">' + nb(s.text) + (s.detail ? '<small>' + nb(s.detail) + '</small>' : '') + '</span>' +
        (s.distance ? '<span class="pm-step__d" aria-hidden="true">' + esc(s.distance) + '</span>' : '') + '</button></li>';
    }
    const stepsList = r => '<div class="pm-steps">' + stepGroups(r).map(g => '<p class="pm-k pm-steps__h">' + esc(g.head) + '</p><ol class="pm-steps__l">' + g.rows.map(i => stepRow(r, i)).join('') + '</ol>').join('') + '</div>';
    function dirsView() {
      const d = A.dir; if (!d) return '';
      const r = d.plan, phone = A.mode === 'full', ok = !!(r && r.ok);
      // The phone's Steps (full height): the list, with the time over it; × goes back to the planner.
      if (phone && d.list && ok) {
        return '<div class="pm-card pm-placecard pm-dirs"><div data-peek><button type="button" class="pm-x" data-pm="steps-close" aria-label="Back">' + I.close + '</button>' +
          '<h2 class="pm-h">Steps</h2><p class="pm-sub">' + esc(r.min + ' min · ' + r.distance) + '</p></div>' + stepsList(r) + '</div>';
      }
      const st = A.nav.status && A.nav.status !== 'Locating' ? A.nav.status : '';
      // From: what it is, or its state (Locating, Not on campus, "Barnes · Set start"), else Choose start.
      let fMain = d.from ? d.from.label : 'Choose start', fSub = d.from ? d.from.sub || '' : '';
      if (d.from && d.from.kind === 'here') fSub = !d.from.spec ? (st || 'Locating') : st;
      else if (!d.from && st && touch() && phone) fSub = st;
      if (r && !r.ok && r.reason === 'Set start') { const it = M.find(A.c, r.building); fMain = (it ? bShort(it) : r.building) + ' · Set start'; fSub = ''; }
      if (r && !r.ok && r.side === 'from' && r.reason === 'Not on campus') fSub = 'Not on campus';
      const rows = '<div class="pm-ends">' + endRow('from', d.from, fMain, fSub) + endRow('to', d.to, d.to ? d.to.label : 'Choose place', d.to ? d.to.sub || '' : '') +
        '<button type="button" class="pm-swap" data-pm="swap" aria-label="Swap" title="Swap From and To"' + (d.from && d.to ? '' : ' disabled') + '>' + I.swap + '</button></div>';
      const sf = stepFree();
      const sfRow = '<div class="pm-sfrow"><span class="pm-sfrow__t" id="pm-sf-l">Step-free<small id="pm-sf-d">No stairs or steps</small></span>' +
        '<button type="button" class="pm-switch" role="switch" aria-checked="' + sf + '" aria-labelledby="pm-sf-l" data-pm="sf"><span class="pm-switch__k"></span></button></div>';
      // The summary (§4.5), or the one state that stands in its place (§4.11).
      let sum = '', why = '';
      if (ok) {
        const n = venueNow(), arrive = n.minutes != null ? 'Arrive ' + clock(Math.floor(n.minutes) + r.min) : '';
        // (Each '›' kept with the leg before it, so a wrapped line never starts with one.)
        const legs = '<p class="pm-legs">' + r.legs.map((l, i, a) => '<span class="pm-leg">' + (I['r-' + l.icon] || '') + '<span>' + nb(l.text) + '</span>' + (i < a.length - 1 ? '<span class="pm-legs__sep" aria-hidden="true">›</span>' : '') + '</span>').join('') + '</p>';
        const notes = (r.notes || []).map(t => '<p class="pm-dnote">' + esc(t) + '</p>').join('');
        sum = '<div class="pm-dsum"><p class="pm-dsum__t">' + r.min + ' min</p><p class="pm-dsum__l">' + esc([r.distance, arrive].filter(Boolean).join(' · ')) + '</p>' + legs + notes + '</div>';
      } else if (r) {
        const word = r.reason === 'Set start' ? 'Set start' : r.reason;
        why = word;
        // (A state the From row already says isn't said twice: the reason sits under Start alone.)
        const inFrom = r.side === 'from' && (r.reason === 'Choose start' || r.reason === 'Set start' || r.reason === 'Not on campus' || r.reason === 'Locating' || r.reason === st);
        if (!inFrom) sum = '<div class="pm-dsum is-none"><p class="pm-dsum__t pm-dsum__t--state" id="pm-why">' + esc(word) + '</p>' + (r.why ? '<p class="pm-dsum__l">' + esc(r.why) + '</p>' : '') + '</div>';
        else if (r.reason === 'Set start') sum = '<div class="pm-dsum is-none"><p class="pm-dsum__l" id="pm-why">Tap where you are on the floor</p></div>';
      }
      const reasonUnder = r && !r.ok && !/id="pm-why"/.test(sum);
      const go = phone ? '<p class="pm-btns pm-go"><button type="button" class="pm-btn pm-btn--go" data-pm="start"' + (ok ? '' : ' disabled aria-describedby="pm-why"') + '>Start</button></p>' + (reasonUnder ? '<p class="pm-why" id="pm-why">' + esc(why) + '</p>' : '') : '';
      // (On a laptop there's no Start to explain, so a reason the From row says isn't repeated.)
      const steps = ok ? (phone ? '<p class="pm-stepslink"><button type="button" class="pm-link" data-pm="steps">Steps</button></p>' : stepsList(r)) : '';
      return '<div class="pm-card pm-placecard pm-dirs"><div data-peek><h2 class="pm-h ogc-sr" tabindex="-1">Directions</h2>' + x.replace('data-pm="close"', 'data-pm="dirs-close"') + rows + sfRow + sum + go + steps + '</div></div>';
    }
    // A step framed (§4.5, §5.1): its building on its floor, its stretch at full strength, flown to (280 ms).
    function frameStep(i, quiet) {
      const d = A.dir, r = d && d.plan; if (!r || !r.ok || !r.steps[i]) return;
      const s = r.steps[i];
      d.focus = i;
      if (A.L && s.building) { const B = A.L.building(s.building); if (s.kind === 'door') A.L.focus(s.building, B ? B.entrance : null); else if (+s.floor) A.L.focus(s.building, +s.floor); }
      showRoute(false, s);
      const b = s.box;
      if (b && A.map) { const w = Math.max(30, b[2] - b[0]), h = Math.max(30, b[3] - b[1]), cx = (b[0] + b[2]) / 2, cy = (b[1] + b[3]) / 2; A.map.fit({ x: cx - w / 2, y: cy - h / 2, w, h }, 48, true); }
      A.el.querySelectorAll('.pm-step').forEach(e => e.classList.toggle('is-on', +e.dataset.i === i));
      if (!quiet && A.map.live) A.map.live('Step ' + (i + 1) + ' of ' + r.steps.length + ' · ' + s.text);
    }
    /* ------------------------------------------------ Start: walking it (a phone; docs/34 §4.6–4.11) */

    // A.walk while Start is on:
    //   i: the step you're on (the location moves it on outdoors; Next and Back inside and at a door);
    //   view: a step looked at by hand outdoors (‹ ›) while the location goes on, or -1;
    //   follow: the camera keeps you in the middle; run, m: the stretch outdoors you're on, and how far
    //   along it you've come (never back); off: metres before each step; fixAt: the last fix (30 s without
    //   one greys the dot); offAt: off the route since (10 s reroutes); sim: the demo's walk (Mockup: walk it).
    // The steps are the planner's (§10.2's fixed sentences); nothing here makes a sentence up.
    const WALK_S = 1.8;   // px a metre while following: about 200 m across a phone, the destination's floor open
    const still = () => !!(window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches);
    I.prev = svg('M14.5 5.5 8 12l6.5 6.5');
    I.check = svg('M6.5 12.5l3.8 3.8 7.2-8.3');
    const walkOffsets = r => { const o = [0]; r.steps.forEach((s, k) => { o[k + 1] = o[k] + (s.metres || 0); }); return o; };
    // The stretch outdoors a step is in (the steps outdoors either side of it) as one line, with the
    // metres along it at each point and at each step's end.
    function walkRun(r, i) {
      if (!r.steps[i] || r.steps[i].kind !== 'outside') return null;
      let a = i, b = i;
      while (a > 0 && r.steps[a - 1].kind === 'outside') a--;
      while (b + 1 < r.steps.length && r.steps[b + 1].kind === 'outside') b++;
      const pts = [], cum = [], ends = [];
      let m = 0;
      for (let k = a; k <= b; k++) {
        (r.steps[k].pts.length ? r.steps[k].pts : [r.steps[k].at]).forEach((p, j) => {
          if (pts.length && j === 0) return;
          if (pts.length) m += Math.hypot(p[0] - pts[pts.length - 1][0], p[1] - pts[pts.length - 1][1]);
          pts.push(p); cum.push(m);
        });
        ends.push(m);
      }
      return { a, b, pts, cum, ends, L: m };
    }
    // The nearest point of the stretch to (x, y), looking only between lo and hi metres along it.
    function walkProject(run, x, y, lo, hi) {
      let best = null;
      for (let k = 1; k < run.pts.length; k++) {
        if (run.cum[k] < lo || run.cum[k - 1] > hi) continue;
        const a = run.pts[k - 1], b = run.pts[k], dx = b[0] - a[0], dy = b[1] - a[1], L = dx * dx + dy * dy;
        const t = L ? Math.max(0, Math.min(1, ((x - a[0]) * dx + (y - a[1]) * dy) / L)) : 0, d = Math.hypot(a[0] + t * dx - x, a[1] + t * dy - y);
        if (!best || d < best.d) best = { d, m: run.cum[k - 1] + t * Math.sqrt(L) };
      }
      return best;
    }
    const walkAt = (run, m) => { for (let k = 1; k < run.pts.length; k++) if (run.cum[k] >= m) { const a = run.pts[k - 1], b = run.pts[k], l = run.cum[k] - run.cum[k - 1], t = l ? (m - run.cum[k - 1]) / l : 0; return [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t]; } return run.pts[run.pts.length - 1]; };
    const walkShown = () => A.walk.view > -1 ? A.walk.view : A.walk.i;
    // The step the card says outdoors, while the location leads (round 2 part 2, the last checks: the card
    // said the step under way, so just after a turn "Turn left · 80 ft" read as a turn 80 ft on): the turn
    // ahead, with the feet until it. The first stretch keeps its own words ("Toward Barnes") for its first
    // 10 m; a turn its own for 3 m past it. Looking by hand (‹ ›) shows the step looked at.
    function walkCard(hand) {
      const wk = A.walk, r = A.dir && A.dir.plan, i = wk.i, run = wk.run;
      if ((hand && wk.view > -1) || wk.rerouting || !walkLive() || !r || !run || i < run.a || i > run.b) return hand ? walkShown() : i;
      const s0 = i > run.a ? run.ends[i - run.a - 1] : 0;
      return wk.m - s0 < (i === run.a ? 10 : 3) || !r.steps[i + 1] ? i : i + 1;
    }
    // What the screen is: out (the card and the bar), door (the card with Next), in (the step sheet), end (Arrived).
    function walkPhase() {
      const wk = A.walk, r = A.dir && A.dir.plan; if (!wk || !r || !r.ok) return '';
      if (wk.arrived) return 'end';
      const s = r.steps[walkShown()];
      return !s ? '' : s.kind === 'door' ? 'door' : s.kind === 'outside' || s.kind === 'end' ? 'out' : 'in';
    }
    // The location is coming in (the phone's, or the demo's walk).
    const walkLive = () => !!A.walk && (!!A.walk.sim || A.watch != null);
    const doorFloor = s => { const e = A.P && (A.P.entrances || []).find(x => x.code === s.building && x.at && Math.hypot(x.at[0] - s.at[0], x.at[1] - s.at[1]) < 4); const B = A.L && A.L.building(s.building); return e ? +e.floor : B ? B.entrance : 1; };

    function start() {
      const d = A.dir; if (!d || !d.plan || !d.plan.ok || A.mode !== 'full' || A.walk) return;
      const r = d.plan, head = document.querySelector('.wk-apphead'), tabs = document.querySelector('.wk-tabbar');
      // An iPhone asks for the compass from the tap itself.
      compassAsk();
      A.walk = { i: 0, view: -1, follow: true, m: 0, run: null, off: walkOffsets(r), fixAt: Date.now(), offAt: 0, stale: false, rerouting: false, arrived: false, sim: null, heading: null, gen: 0, minute: -2, drawn: null, snap: true, tick: 0, realWatch: false };
      [head, tabs].forEach(e => { if (e) e.inert = true; });
      document.documentElement.classList.add('pm-walking');
      A.el.classList.add('is-walk');
      A.walkEl = document.createElement('div'); A.walkEl.className = 'pm-walk';
      A.el.appendChild(A.walkEl);
      walkSwipes(A.walkEl);
      place();
      A.walk.tick = setInterval(walkTick, 1000);
      wake(true);
      if (A.watch == null && A.perm !== 'denied' && touch()) locate();
      if (A.nav.me && near(A.nav.me)) walkFix(); else walkPaint();
      // (The demo's dock, where there is one, rises above the bar once the tabs have gone.)
      setTimeout(() => { if (window.OGC_DOCK && OGC_DOCK.lift) OGC_DOCK.lift(); }, 240);
    }
    // End: back to the planner (or, silent, just the walk taken away: Done, the planner closed).
    function endWalk(silent) {
      const wk = A.walk; if (!wk) return;
      stopSim(); clearInterval(wk.tick); wake(false); compassOff();
      A.walk = null;
      if (A.walkEl) { A.walkEl.remove(); A.walkEl = null; }
      document.documentElement.classList.remove('pm-walking');
      A.el.classList.remove('is-walk'); ['--pm-wtop', '--pm-wbot', '--pm-wdock'].forEach(k => A.el.style.removeProperty(k));
      [document.querySelector('.wk-apphead'), document.querySelector('.wk-tabbar')].forEach(e => { if (e) e.inert = false; });
      place();
      if (wk.realWatch && A.watch == null && A.perm !== 'denied') locate();
      setTimeout(() => { if (window.OGC_DOCK && OGC_DOCK.lift) OGC_DOCK.lift(); }, 180);
      if (silent) return;
      const d = A.dir; if (!d) return;
      const r = d.plan, end = r && r.ok ? r.steps[r.steps.length - 1] : null;
      d.list = false; d.focus = -1;
      if (A.L) { if (end && end.building && +end.floor) A.L.focus(end.building, +end.floor); else A.L.focus(null); }
      settle('half'); paint(); showRoute(false, null); fitRoute(r);
      const b = A.el.querySelector('[data-pm="start"]'); if (b) b.focus({ preventScroll: true });
    }
    // A fix while walking: along the stretch outdoors, the step moves on; at the door, the door; an outdoor
    // place, Arrived within 15 m.
    function walkFix() {
      const wk = A.walk, r = A.dir && A.dir.plan, me = A.nav.me;
      if (!wk || !r || !r.ok) return;
      if (!me || !near(me)) { walkPaint(); return; }
      wk.fixAt = Date.now(); wk.stale = false;
      const s = r.steps[wk.i];
      if (!wk.arrived && !wk.rerouting && s) {
        if (s.kind === 'outside') { if (walkAlong(wk, r, me) === 'arrived') return; }
        else if (s.kind === 'end' && !+s.floor && Math.hypot(me.x - s.at[0], me.y - s.at[1]) <= 15) { walkArrive(); return; }
      }
      walkPaint(1);
    }
    function walkAlong(wk, r, me) {
      if (!wk.run || wk.i < wk.run.a || wk.i > wk.run.b) { wk.run = walkRun(r, wk.i); wk.m = wk.run && wk.i > wk.run.a ? wk.run.ends[wk.i - wk.run.a - 1] : 0; }
      const run = wk.run; if (!run || run.pts.length < 2) return '';
      // Off the route (§4.6): more than 25 m from it, with a fix good to 40 m, for 10 s (walkTick reroutes).
      const all = walkProject(run, me.x, me.y, -Infinity, Infinity);
      if (all && all.d > 25 && !(me.acc > 40)) { if (!wk.offAt) wk.offAt = Date.now(); } else wk.offAt = 0;
      // How far along: the nearest point from a little behind to well ahead of where you were, never back.
      const q = walkProject(run, me.x, me.y, wk.m - 25, wk.m + 150) || all;
      if (q && q.d <= 25) wk.m = Math.max(wk.m, q.m);
      // A step moves on within 12 m of its end; the last one outdoors at its door (or the place), 15 m.
      let k = wk.i;
      while (k < run.b && run.ends[k - run.a] - wk.m <= 12) k++;
      const nx = r.steps[run.b + 1];
      if (nx && Math.hypot(me.x - nx.at[0], me.y - nx.at[1]) <= 15 && run.L - wk.m <= 40) {
        if (nx.kind === 'end') { wk.i = run.b + 1; walkArrive(); return 'arrived'; }
        k = run.b + 1;
      }
      if (k > wk.i) {
        wk.i = k;
        // A step looked at by hand that you've now reached (or one behind you) gives way to where you are.
        if (wk.view > -1 && wk.view <= wk.i) { wk.view = -1; wk.follow = true; }
      }
      return '';
    }
    // ‹ › and Back and Next (and a swipe on the card). Outdoors, with the location on, ‹ › only look;
    // at a door, Next goes in; inside, they're where you are; the last Next to a room is Arrived.
    function walkGo(dir) {
      const wk = A.walk, r = A.dir && A.dir.plan; if (!wk || !r || wk.arrived || wk.rerouting) return;
      // (Outdoors ‹ › go on from the step the card says, and back to the live card where they meet it.)
      const ph = walkPhase(), j = (ph === 'out' ? walkCard(true) : walkShown()) + dir, s = r.steps[j];
      if (!s) return;
      const look = walkLive() && ph !== 'in' && !(ph === 'door' && dir > 0) && (s.kind === 'outside' || s.kind === 'door' || (s.kind === 'end' && !+s.floor));
      if (look) { wk.view = j === walkCard(false) ? -1 : j; wk.follow = wk.view === -1; wk.snap = true; walkPaint(dir); return; }
      if (s.kind === 'end' && (+s.floor || !walkLive())) { wk.i = j; wk.view = -1; walkArrive(); return; }
      wk.i = j; wk.view = -1; wk.follow = true; wk.snap = true;
      if (s.kind === 'outside') wk.run = null;
      walkPaint(dir);
    }
    function walkArrive() {
      const wk = A.walk, r = A.dir.plan;
      wk.arrived = true; wk.i = r.steps.length - 1; wk.view = -1; wk.snap = true;
      stopSim();
      walkPaint(1);
    }
    function walkMoved() { const wk = A.walk; if (wk && wk.follow && walkPhase() === 'out') { wk.follow = false; walkPaint(); } }
    function walkRecenter() { const wk = A.walk; if (!wk) return; wk.follow = true; wk.view = -1; wk.snap = true; walkPaint(-1); }
    // Arrived's Done: the place's own sheet, the head and the tabs back.
    function walkFinish() { const d = A.dir, to = d && d.to ? d.to.place : null; closeDirs(to || undefined); }
    // The dot while walking: none inside (§4.8); greyed after 30 s without a fix; the compass's wedge while following.
    function walkMe() {
      const wk = A.walk, me = A.nav.me, r = A.dir && A.dir.plan, ph = walkPhase();
      if (!wk || !me || !near(me) || ph === 'in' || (ph === 'end' && r && +r.steps[r.steps.length - 1].floor)) return null;
      return Object.assign({}, me, { stale: wk.stale, heading: wk.follow && ph === 'out' && !wk.stale && wk.heading != null ? wk.heading : null });
    }
    // Metres walked along the route (the route-done part of the line).
    function walkMetres() {
      const wk = A.walk, r = A.dir.plan;
      if (wk.arrived) return r.metres;
      if (r.steps[wk.i] && r.steps[wk.i].kind === 'outside' && wk.run && wk.i >= wk.run.a && wk.i <= wk.run.b) return wk.off[wk.run.a] + wk.m;
      return wk.off[wk.i] || 0;
    }
    // What covers the map: the card at the top and the bar at the foot (outdoors), the sheet (inside).
    // The demo's dock (local and the shared link only), which rests 8 px above the bar or the steps: what
    // the map, Recenter and the credit keep clear of. 0 on the real site.
    const walkDock = () => { const dk = document.querySelector('.ogc-pill'), h = dk && !dk.hidden ? dk.offsetHeight : 0; return h ? h + 8 : 0; };
    function walkInset() {
      const el = A.walkEl, ph = A.walk ? walkPhase() : '';
      const card = el && el.querySelector('.pm-wcard'), foot = el && el.querySelector('.pm-wbar, .pm-wsheet');
      // (The floor picker's column on the right, as the planner keeps it: names and plates keep off it too;
      // at the foot, the credit's line, which sits just above the bar or the steps.)
      // under: just under the card, where the picker and the demo's pill sit; the demo's pill, when it
      // shows, is in the way too (a destination's name would go under it).
      const cr = A.mapEl && (A.mapEl.querySelector('.pv-foot') || A.mapEl.querySelector('.pv-credit')), ch = cr ? cr.offsetHeight : 0;
      const under = card ? card.offsetTop + card.offsetHeight + 8 : 12, mk = el && el.querySelector('[data-wmock]:not([hidden])');
      return { top: mk && mk.offsetHeight ? under + 4 + mk.offsetHeight + 8 : under, under, bottom: foot ? foot.offsetHeight + walkDock() + ch + 8 : 0, left: 0, right: A.plans && ph ? 72 : 0, foot: foot ? foot.offsetHeight : 0 };
    }
    function walkHtml(ph) {
      const mock = W().dev || W().prototype ? '<p class="pm-wmock" data-wmock hidden><button type="button" class="ogc-mock" data-pm="w-mock" aria-pressed="false" title="Moves the dot along the route at three times walking speed · Demo only">Mockup: walk it</button></p>' : '';
      if (ph === 'out' || ph === 'door') {
        return '<div class="pm-wcard" data-wswipe><div class="pm-wcard__s" data-wtext tabindex="-1"></div>' +
          '<div class="pm-wcard__nav"><button type="button" class="pm-wnav" data-pm="w-prev" aria-label="Previous step" title="Previous step">' + I.prev + '</button><button type="button" class="pm-wnav" data-pm="w-next" aria-label="Next step" title="Next step">' + I.next + '</button></div>' +
          (ph === 'door' ? '<p class="pm-wcard__go"><button type="button" class="pm-btn" data-pm="w-in">Next</button></p>' : '') + '</div>' +
          '<button type="button" class="pm-btn pm-btn--line pm-recenter" data-pm="w-recenter" hidden>' + I.locate + 'Recenter</button>' + mock +
          '<div class="pm-wbar"><div class="pm-wbar__m"><p class="pm-wbar__t" data-warr></p><p class="pm-wbar__l" data-wrem></p></div><button type="button" class="pm-btn pm-btn--line" data-pm="w-end">End</button></div>';
      }
      if (ph === 'in') {
        return '<section class="pm-wsheet" data-wswipe aria-label="Steps"><div class="pm-wsheet__h"><p class="pm-k" data-wlab></p><button type="button" class="pm-wsheet__end" data-pm="w-end">End</button></div>' +
          '<div class="pm-wsheet__s" data-wtext tabindex="-1"></div>' +
          '<p class="pm-wsheet__b"><button type="button" class="pm-btn pm-btn--line" data-pm="w-back">' + I.prev + 'Back</button><button type="button" class="pm-btn" data-pm="w-fwd">Next</button></p></section>';
      }
      return '<section class="pm-wsheet pm-wsheet--done" aria-label="Arrived"><div class="pm-wsheet__s" data-wtext tabindex="-1"></div><p class="pm-wsheet__b"><button type="button" class="pm-btn" data-pm="w-done">Done</button></p></section>';
    }
    function walkText(ph, s) {
      const wk = A.walk, ico = big => '<span class="pm-wico' + (big ? ' pm-wico--big' : '') + '" aria-hidden="true">' + (I['r-' + s.icon] || I['r-straight']) + '</span>';
      if (ph === 'end') {
        const d = A.dir, sub = d && d.to && d.to.label && d.to.label !== s.sign ? d.to.label : '';
        return '<p class="pm-arr"><span class="pm-arr__c" aria-hidden="true">' + I.check + '</span><span class="pm-k">Arrived</span></p><h2 class="pm-arr__t">' + esc(s.text) + '</h2>' + (sub ? '<p class="pm-arr__s">' + esc(sub) + '</p>' : '');
      }
      if (ph === 'in') return (s.kind === 'floor' ? ico(true) : '') + '<p class="pm-wsheet__t">' + nb(s.text) + '</p><p class="pm-wsheet__d">' + nb([s.detail, s.distance].filter(Boolean).join(' · ')) + '</p>';
      if (wk.rerouting) return '<span class="pm-wico" aria-hidden="true"></span><p class="pm-wcard__m"><span class="pm-wcard__t">Rerouting</span><span class="pm-wcard__d" data-wline></span></p>';
      return ico(false) + '<p class="pm-wcard__m"><span class="pm-wcard__t">' + nb(s.text) + '</span><span class="pm-wcard__d" data-wline></span></p>';
    }
    // The card's second line: the state, else how far. As you walk: the first stretch, what's left of it;
    // a turn ahead, the feet until it (none once you're at it). Looked at by hand: the step's own length.
    function walkLine(s, si) {
      const wk = A.walk, me = A.nav.me, run = wk.run;
      if (wk.rerouting) return '';
      if (wk.stale) return 'Location unavailable';
      if (walkLive() && me && near(me) && me.acc > 40) return 'Approximate location';
      if (wk.view === -1 && walkLive() && me && near(me) && run && wk.i >= run.a && wk.i <= run.b && si >= run.a && si <= run.b + 1) {
        if (si === run.a) return M.feet(Math.max(0, run.ends[0] - wk.m));
        const d = run.ends[si - run.a - 1] - wk.m;
        return d >= 3 ? M.feet(d) : '';
      }
      return s.distance || '';
    }
    // The text of a step changing: the old leaves 12 px and the new comes in from 12 px (200 ms; §8).
    function walkSwap(box, html, dir) {
      if (!dir || still() || !box.animate || !box.firstChild) { box.innerHTML = html; return; }
      const old = box.cloneNode(true);
      old.removeAttribute('data-wtext'); old.removeAttribute('tabindex'); old.setAttribute('aria-hidden', 'true');
      old.style.cssText = 'position:absolute;margin:0;left:' + box.offsetLeft + 'px;top:' + box.offsetTop + 'px;width:' + box.offsetWidth + 'px;pointer-events:none';
      box.parentNode.insertBefore(old, box);
      box.innerHTML = html;
      const e = 'cubic-bezier(.2,.8,.2,1)';
      old.animate([{ opacity: 1, transform: 'none' }, { opacity: 0, transform: 'translateX(' + (-12 * dir) + 'px)' }], { duration: 200, easing: e, fill: 'forwards' }).onfinish = () => old.remove();
      box.animate([{ opacity: 0, transform: 'translateX(' + (12 * dir) + 'px)' }, { opacity: 1, transform: 'none' }], { duration: 200, easing: e });
    }
    const walkFrame = (b, pad, min) => { if (!b || !A.map) return; const w = Math.max(min || 30, b[2] - b[0]), h = Math.max(min || 30, b[3] - b[1]), cx = (b[0] + b[2]) / 2, cy = (b[1] + b[3]) / 2; A.map.fit({ x: cx - w / 2, y: cy - h / 2, w, h }, pad, true); };
    // Everything on the screen while walking, from A.walk: drawn again where it changed.
    function walkPaint(dir) {
      const wk = A.walk, d = A.dir, r = d && d.plan, el = A.walkEl;
      if (!wk || !r || !r.ok || !el || !A.map) return;
      const ph = walkPhase(), si = walkShown(), s = r.steps[si], n = r.steps.length, was = wk.drawn || {};
      // (Outdoors the card says the turn ahead: ci, cs.)
      const ci = ph === 'out' ? walkCard(true) : si, cs = r.steps[ci] || s;
      const newPhase = was.ph !== ph || was.plan !== r, newStep = newPhase || was.si !== si || was.ci !== ci || was.rr !== wk.rerouting;
      const kept = el.contains(document.activeElement) ? document.activeElement.dataset.pm || 'text' : (newPhase && !was.ph ? 'text' : '');
      if (newPhase) el.innerHTML = walkHtml(ph);
      const box = el.querySelector('[data-wtext]');
      if (newStep && box) walkSwap(box, walkText(ph, ph === 'out' ? cs : s), newPhase ? 0 : dir || 1);
      const line = el.querySelector('[data-wline]'); if (line) line.textContent = walkLine(cs, ci);
      const lab = el.querySelector('[data-wlab]'); if (lab) lab.textContent = (si + 1) + ' of ' + n + ' · ' + M.floorName(s.floor);
      el.querySelectorAll('[data-pm="w-prev"], [data-pm="w-back"]').forEach(b => { b.disabled = ci <= 0 || !!wk.rerouting; });
      el.querySelectorAll('[data-pm="w-next"]').forEach(b => { b.disabled = ci >= n - 1 || !!wk.rerouting; });
      // The bar: when you'll arrive, and what's left (§4.6), from the plan's own time for its length.
      const done = walkMetres(), rem = Math.max(0, r.metres - done), left = r.metres ? r.sec * rem / r.metres : 0, min = Math.max(1, Math.round(left / 60)), now = venueNow();
      const arr = el.querySelector('[data-warr]'), rest = el.querySelector('[data-wrem]');
      // (A previewed day, ?as-of, has a clock that stands still: the time walked moves it on, so Arrive
      // doesn't run backwards as the demo walks. The real clock moves by itself.)
      const held = /[?&]as-of=/.test(location.search) ? Math.max(0, r.sec - left) / 60 : 0;
      if (arr) arr.textContent = now.minutes != null ? 'Arrive ' + clock(Math.floor(now.minutes + held) + min) : min + ' min';
      if (rest) rest.textContent = (now.minutes != null ? min + ' min · ' : '') + M.feet(rem);
      const me = A.nav.me, fix = !!(me && near(me));
      const rc = el.querySelector('.pm-recenter'); if (rc) rc.hidden = !(ph === 'out' && !wk.follow && fix);
      const mk = el.querySelector('[data-wmock]');
      if (mk) { mk.hidden = !(ph === 'out' && r.steps[wk.i] && r.steps[wk.i].kind === 'outside'); mk.querySelector('button').setAttribute('aria-pressed', String(!!wk.sim)); }
      // (Recenter and the credit keep clear of the demo's dock where it has risen above the bar.)
      A.el.style.setProperty('--pm-wdock', walkDock() + 'px');
      wk.drawn = { ph, si, ci, rr: wk.rerouting, plan: r };
      // What the map keeps clear of, and where the floor picker sits (under the card outdoors).
      const ins = walkInset();
      A.el.style.setProperty('--pm-wtop', (ph === 'out' || ph === 'door' ? ins.under : 12) + 'px');
      A.el.style.setProperty('--pm-wbot', ins.foot + 'px');
      A.map.inset(ins);
      // The building open: the destination's outdoors; the step's floor inside; the door's floor at a door.
      // (Off the campus, walking in from the town, no floor picker: the building opens on the campus.)
      const offc = ph === 'out' && fix && !M.onCampus(A.c, me, 30), offTurn = wk.offc !== offc; wk.offc = offc;
      if ((newStep || offTurn) && A.L) {
        const end = r.steps[n - 1];
        if (ph === 'in') A.L.focus(s.building, +s.floor);
        else if (ph === 'door') A.L.focus(s.building, doorFloor(s));
        else if (end.building && +end.floor && !offc) A.L.focus(end.building, +end.floor);
        else A.L.focus(null);
      }
      A.map.route({ parts: r.parts, floorOf: code => A.L ? A.L.shown(code) : null, start: r.steps[0] ? r.steps[0].at : null,
        stretch: ph === 'in' && s.pts.length > 1 ? { id: 'w' + si, pts: s.pts, floor: s.floor, building: s.building } : null,
        done, ring: ph === 'in' ? s.at : null, animate: false });
      A.map.me(walkMe());
      // The camera (north up): following you outdoors, eased to each fix; else framed on the step.
      const snap = wk.snap || newStep; wk.snap = false;
      if (ph === 'out') {
        if (wk.follow && fix && wk.view === -1) A.map.look(me.x, me.y, snap ? WALK_S : curScale(), true);
        // (No fix, or looking at a step by hand: the step with the ground round it, never less than about
        // 110 m across, so where it goes is in view; round 2 part 2: "Toward Barnes" filled the phone.)
        else if (snap) walkFrame(s.kind === 'end' ? [s.at[0] - 15, s.at[1] - 15, s.at[0] + 15, s.at[1] + 15] : s.box, 48, s.kind === 'end' ? 30 : 110);
      } else if (snap && ph === 'door') {
        const B = A.L && A.L.building(s.building), bb = B && B.box;
        const fb = bb ? [Math.min(bb.x, s.at[0]), Math.min(bb.y, s.at[1]), Math.max(bb.x + bb.w, s.at[0]), Math.max(bb.y + bb.h, s.at[1])] : [s.at[0] - 20, s.at[1] - 20, s.at[0] + 20, s.at[1] + 20];
        // (You, near the door, in the frame too: round 2 part 2, the dot sat under the floor picker.)
        if (fix && Math.hypot(me.x - s.at[0], me.y - s.at[1]) < 80) { fb[0] = Math.min(fb[0], me.x - 8); fb[1] = Math.min(fb[1], me.y - 8); fb[2] = Math.max(fb[2], me.x + 8); fb[3] = Math.max(fb[3], me.y + 8); }
        walkFrame(fb, 24);
      } else if (snap && ph === 'in') walkFrame(s.pts.length > 1 ? s.box : [s.at[0] - 8, s.at[1] - 8, s.at[0] + 8, s.at[1] + 8], 48);
      else if (snap && ph === 'end') walkFrame([s.at[0] - 12, s.at[1] - 12, s.at[0] + 12, s.at[1] + 12], 48);
      if (newStep) A.map.live(wk.rerouting ? 'Rerouting' : ph === 'end' ? 'Arrived · ' + s.text : 'Step ' + (ci + 1) + ' of ' + n + ' · ' + cs.text);
      // Keyboard focus stays on the walk: the same button, else the step's text.
      if (kept && newPhase) { const b = kept !== 'text' && el.querySelector('[data-pm="' + CSS.escape(kept) + '"]:not([disabled])'); (b || el.querySelector('[data-wtext]') || el).focus({ preventScroll: true }); }
    }
    // Once a second: 30 s without a fix greys the dot; 10 s off the route reroutes; the clock moves on.
    function walkTick() {
      const wk = A.walk, r = A.dir && A.dir.plan; if (!wk || !r) return;
      const stale = A.watch != null && Date.now() - wk.fixAt > 30000;
      let ch = stale !== wk.stale; wk.stale = stale;
      if (wk.offAt && Date.now() - wk.offAt >= 10000 && !wk.rerouting && !stale && r.steps[wk.i] && r.steps[wk.i].kind === 'outside') { walkReroute(); return; }
      const now = venueNow(), mm = now.minutes == null ? -1 : Math.floor(now.minutes);
      if (mm !== wk.minute) { wk.minute = mm; ch = true; }
      if (ch) walkPaint();
    }
    // Off the route: "Rerouting", then the route from here, with no motion (the campus's graph is on the phone).
    function walkReroute() {
      const wk = A.walk, d = A.dir, me = A.nav.me; if (!wk || !d || !me || me.lat == null) return;
      wk.rerouting = true; wk.offAt = 0;
      const gen = ++wk.gen;
      walkPaint();
      routerNow().then(R => {
        if (A.walk !== wk || wk.gen !== gen) return;
        const from = endHere(), r = planWith(Object.assign({}, d, { from }), R);
        setTimeout(() => {
          if (A.walk !== wk || wk.gen !== gen) return;
          wk.rerouting = false;
          if (r.ok) {
            d.from = from; d.auto = false; d.at = [me.x, me.y]; d.plan = r;
            if (A.L) A.L.route(r);
            A.map.reach(routeBox(r));
            Object.assign(wk, { i: 0, view: -1, m: 0, run: null, off: walkOffsets(r), follow: true, snap: true });
          }
          walkPaint(1);
        }, 700);
      });
    }
    // The demo's walk (Mockup: walk it; the local site and the shared link only): the dot along the
    // stretch outdoors at three times walking pace (1 m/s), a fix every 400 ms, to its door or its end.
    function walkSim(on) {
      const wk = A.walk, r = A.dir && A.dir.plan; if (!wk || !r) return;
      if (!on) { stopSim(); walkPaint(); return; }
      if (wk.sim) return;
      if (!wk.run || wk.i < wk.run.a || wk.i > wk.run.b) { wk.run = walkRun(r, wk.i); wk.m = wk.run && wk.i > wk.run.a ? wk.run.ends[wk.i - wk.run.a - 1] : 0; }
      const run = wk.run; if (!run || run.pts.length < 2) return;
      if (A.watch != null) { stopWatch(); wk.realWatch = true; }
      let m = Math.max(wk.m, wk.i > run.a ? run.ends[wk.i - run.a - 1] : 0);
      const tick = () => {
        if (A.walk !== wk) return;
        m = Math.min(run.L, m + 1.2);
        const p = walkAt(run, m), ll = M.toLatLng(A.c, p[0], p[1]);
        A.nav.me = { x: p[0], y: p[1], acc: 5, lat: ll.lat, lng: ll.lng }; A.nav.status = '';
        if (m >= run.L) stopSim();
        walkFix();
        if (A.walk && (A.walk.arrived || A.walk.i > run.b)) stopSim();
      };
      wk.sim = setInterval(tick, 400);
      wk.follow = true; wk.view = -1; wk.snap = true;
      tick();
    }
    function stopSim() { const wk = A.walk; if (wk && wk.sim) { clearInterval(wk.sim); wk.sim = null; } }
    // The page hidden: the location stops (as ever), and the demo's walk with it; back, both go on.
    function walkHidden(h) {
      const wk = A.walk; if (!wk) return;
      if (h) { if (wk.sim) { stopSim(); wk.paused = true; } return; }
      wake(true);
      if (wk.paused) { wk.paused = false; walkSim(true); }
    }
    // Next and Back as a swipe left or right on the card (§4.8).
    function walkSwipes(el) {
      let x0 = null, y0 = 0;
      el.addEventListener('pointerdown', e => { x0 = e.pointerType !== 'mouse' && e.target.closest('[data-wswipe]') ? e.clientX : null; y0 = e.clientY; });
      el.addEventListener('pointerup', e => {
        if (x0 == null) return;
        const dx = e.clientX - x0, dy = e.clientY - y0; x0 = null;
        if (Math.abs(dx) < 48 || Math.abs(dx) < Math.abs(dy) * 2) return;
        A.swiped = Date.now();
        walkGo(dx < 0 ? 1 : -1);
      });
      el.addEventListener('pointercancel', () => { x0 = null; });
    }
    // The screen stays awake while walking (Wake Lock, where the phone allows it).
    function wake(on) {
      if (!on) { if (A.lock) { try { A.lock.release(); } catch (e) { /* gone */ } A.lock = null; } return; }
      if (!A.walk || A.lock || !navigator.wakeLock || document.visibilityState !== 'visible') return;
      navigator.wakeLock.request('screen').then(l => { if (!A.walk) { l.release(); return; } A.lock = l; l.addEventListener('release', () => { if (A.lock === l) A.lock = null; }); }).catch(() => { /* not allowed: fine */ });
    }
    // The compass (§4.6): an iPhone asks once, from Start's tap; refused, there's no wedge and nothing else
    // changes. Elsewhere it's there or it isn't.
    const COMPASS = 'ogc-map-compass';
    let compassFn = null;
    function compassAsk() {
      const D = window.DeviceOrientationEvent;
      if (!D || !touch()) return;
      if (typeof D.requestPermission === 'function') {
        if (LS.get(COMPASS, '') === 'denied') return;
        D.requestPermission().then(s => { LS.set(COMPASS, s); if (s === 'granted') compassOn(); }).catch(() => LS.set(COMPASS, 'denied'));
        return;
      }
      compassOn();
    }
    function compassOn() {
      if (compassFn) return;
      const abs = 'ondeviceorientationabsolute' in window, type = abs ? 'deviceorientationabsolute' : 'deviceorientation';
      let last = 0;
      compassFn = e => {
        const wk = A.walk; if (!wk) return;
        let h = e.webkitCompassHeading != null ? e.webkitCompassHeading : (abs || e.absolute) && e.alpha != null ? 360 - e.alpha : null;
        if (h == null || !isFinite(h)) return;
        const turn = screen.orientation && screen.orientation.angle != null ? screen.orientation.angle : +(window.orientation || 0);
        h = ((h + turn) % 360 + 360) % 360;
        const first = wk.heading == null, t = performance.now();
        if (!first && t - last < 100) return;
        last = t; wk.heading = h;
        if (first) A.map.me(walkMe()); else A.map.heading(h);
      };
      compassFn.type = type;
      addEventListener(type, compassFn);
    }
    function compassOff() { if (compassFn) { removeEventListener(compassFn.type, compassFn); compassFn = null; } }

    /* ------------------------------------------------ the sheet's heights (phone) */

    // Peek: just what's marked data-peek (the usual places, or a place's name and Directions), so the
    // map keeps well over half the screen; half: 60% (a place's card); full: nearly all.
    function heights() {
      const box = A.el.getBoundingClientRect().height || innerHeight * .7;
      const body = A.el.querySelector('.pm-body');
      const els = body ? Array.from(body.querySelectorAll('[data-peek]')) : [];
      let peek = 170;
      if (els.length) { peek = 44 + 14; els.forEach(e => { peek += e.getBoundingClientRect().height + 12; }); }
      peek = Math.round(Math.max(120, Math.min(peek, 250, box * .45)));
      const full = Math.round(box - 8);
      // The planner (§4.5): half is the whole planner, Start and Steps included, never cut (up to full),
      // and no taller, so the map above keeps the rest of the screen.
      // The Steps list: as tall as it is, up to 60%, so the route stays in sight above it (it scrolls).
      const dc = A.dir && A.place && A.place.kind === 'dirs' && body ? body.querySelector('.pm-dirs') : null;
      const dh = dc ? Math.round(dc.getBoundingClientRect().height) + 44 + 16 : 0;
      const half = !dc ? Math.max(peek + 80, Math.round(box * .6)) : Math.max(peek + 80, Math.min(A.dir.list ? Math.round(box * .6) : full, dh));
      return { peek, half, full };
    }
    function setSheet(snap, ease) {
      if (A.mode !== 'full') return;
      A.snap = snap;
      const s = A.el.querySelector('.pm-sheet');
      s.classList.toggle('is-peek', snap === 'peek');
      // (The demo dock rests above the sheet, unless it fills the screen: ogc-dev-nav.js reads is-full.)
      s.classList.toggle('is-full', snap === 'full');
      const H = heights(), h = Math.max(H.peek, H[snap] || H.peek);
      s.classList.toggle('is-settling', !!ease);
      A.sheetH = h; A.el.style.setProperty('--pm-sheet', h + 'px');
      s.querySelector('.pm-grab').setAttribute('aria-label', snap === 'full' ? 'Less' : 'More');
      if (A.map && !A.walk) A.map.inset({ top: topInset(), bottom: h + dockH() });
    }
    function sheetDrag() {
      const s = A.el.querySelector('.pm-sheet'), g = s.querySelector('.pm-grab');
      let y0 = null, h0 = 0, moved = 0;
      g.addEventListener('pointerdown', e => { y0 = e.clientY; h0 = A.sheetH; moved = 0; g.setPointerCapture(e.pointerId); s.classList.remove('is-settling'); });
      g.addEventListener('pointermove', e => { if (y0 == null) return; const d = y0 - e.clientY; moved = Math.max(moved, Math.abs(d)); const H = heights(); const h = Math.max(H.peek, Math.min(H.full, h0 + d)); A.sheetH = h; A.el.style.setProperty('--pm-sheet', h + 'px'); s.classList.toggle('is-peek', h < (H.peek + H.half) / 2); });
      const end = () => {
        if (y0 == null) return; y0 = null;
        const H = heights(), order = ['peek', 'half', 'full'];
        if (moved < 6) { setSheet(order[(order.indexOf(A.snap) + 1) % 3], true); return; }
        const near = order.reduce((m, k) => Math.abs(H[k] - A.sheetH) < Math.abs(H[m] - A.sheetH) ? k : m, 'peek');
        setSheet(near, true);
      };
      g.addEventListener('pointerup', end); g.addEventListener('pointercancel', end);
    }

    /* ------------------------------------------------ acting */

    function openBuilding(name) {
      const g = groups().find(z => { const w = where(z.main); return w.b && w.b.name === name; });
      if (g) return focus(g.main.code);
      // Any other building on the map (polish 3: a hall not confirmed is a building like the rest for the public).
      if (A.c.items.some(i => i.lab && i.name === name && i.name !== 'Building' && i.short !== '-')) { A.place = { kind: 'hall', name }; settle('half'); paint(true); say(name); }
    }
    function openSpot(id) { A.place = { kind: 'spot', id }; settle('half'); paint(true); say(spotName(id)); }
    // Where I sleep: my hall's card (its line says my rooms), or the camper lot.
    // Its own sheet even when the hall is also a place on the schedule (Hodson Hall is N): the place's sheet
    // has no floor or rooms, and My room is the household's floor and rooms (§4.3; the check).
    function openStay() {
      const s = A.stay, b = stayHall() && M.find(A.c, stayHall());
      if (s && s.type === 'camper' && camper()) openSpot(camper().id);
      else if (b) { A.place = { kind: 'hall', name: b.name }; settle('half'); paint(true); say(stayName()); }
    }
    // A place on the map, its sheet open: what a schedule row's place, a card's name or a tap leads to.
    function focus(code, room) {
      const p = P(code); if (!p) return;
      A.place = room ? { code: p.code, room } : { code: p.code };
      settle('half');
      if (!A.map) { const w = where(p); A.pendingFocus = w.b ? roomy(M.boxOf(A.c, [w.b.name], 10), A.mode === 'full' ? .45 : .35) : w.kind === 'pin' ? { x: w.x - 60, y: w.y - 60, w: 120, h: 120 } : null; }
      paint(true);
      say(room ? room.name : p.name);
      remember(p.code);
    }
    function settle(snap) { A.snap = snap; }
    const say = t => { if (A.ctx && A.ctx.say) A.ctx.say(t); };
    // The places opened lately (codes only), first in Search.
    function remember(code) {
      const r = LS.get('ogc-map-recent', []).filter(c => c !== code); r.unshift(code); LS.set('ogc-map-recent', r.slice(0, 4));
    }
    function endFrom(v) {
      if (v === 'stay') return { kind: 'stay' };
      if (v.indexOf('room:') === 0) { const r = roomOfV(v); return r ? { kind: 'place', code: r.code, name: r.name, room: r } : null; }
      if (v.indexOf('near:') === 0) return { kind: 'near', i: +v.slice(5) };
      if (v.indexOf('feat:') === 0) { const a = v.split(':'); return { kind: 'feat', code: a[1], floor: +a[2], sub: a[3], number: a.slice(4).join(':') }; }
      if (v.indexOf('list:') === 0) return { kind: 'list', v: v.slice(5) };
      if (v.indexOf('hall:') === 0) return { kind: 'hall', name: v.slice(5) };
      if (v.indexOf('spot:') === 0) return { kind: 'spot', id: v.slice(5) };
      const p = P(v); return p ? { kind: 'place', code: p.code, name: p.name } : null;
    }
    // A choice (a chip, a search result, a ?to= link): shown on the map with its card.
    function openEnd(e) {
      if (!e) return;
      if (e.kind === 'place') focus(e.code, e.room || null);
      else if (e.kind === 'hall') { const b = M.find(A.c, e.name); if (b) openBuilding(b.name); }
      else if (e.kind === 'spot') openSpot(e.id);
      else if (e.kind === 'stay') openStay();
      else if (e.kind === 'feat') openFeat(e.code, e.floor, e.sub, e.number);
      else if (e.kind === 'list') openList(e.v);
      else if (e.kind === 'near' && A.ctx.openNear) A.ctx.openNear(e.i);
    }

    /* ------------------------------------------------ searching */

    // Everything Search finds: buildings, rooms, halls, lots and the like, Help's
    // places, and every row of the schedule ("Volleyball" finds its field, mapped or not).
    function candidates(which) {
      const out = [];
      groups().forEach(g => {
        const b = where(g.main).b, words = b ? [b.name, b.short].concat(b.aliases, KIND_WORDS[b.kind] || []).join(' ') : '';
        // terms: its own search words and its features' (places.csv; Oct 13), matched whole in ranked().
        const terms = p => (p.search || []).concat(O.featureWords ? O.featureWords(p.features) : []);
        // With floor plans: IWU's own numbers ("143", "Barnes 143"), only for the Conference's rooms (§4.2),
        // and the room's building and floor under it ("Barnes · 1st floor").
        const nums = p => A.P ? (A.P.roomsOf(p.code) || []).map(r => String(r.number).toLowerCase()) : [];
        const bw = b ? [b.name, b.short, shorts[b.name] || '', g.key].join(' ') : g.name;
        if (!g.derived) out.push({ v: g.main.code, main: g.name, sub: A.plans ? factLine(g.main, true) : '', code: g.main.code, ok: routable(g.main), kind: 0, words, terms: terms(g.main), nums: nums(g.main), bw });
        (g.derived ? g.all : g.rooms).forEach(r => out.push({ v: r.code, main: inBuilding(r, g.name), sub: A.plans && planOf(r) ? [b ? bShort(b) : g.name, planFloor(r) != null ? M.floorName(planFloor(r)) : ''].filter(Boolean).join(' · ') : g.name, code: r.code, ok: routable(r), kind: 1, terms: terms(r), nums: nums(r), bw }));
      });
      // A place's own rooms by IWU's name ("Balcony · Chapel · 2nd floor").
      namedRooms().forEach(r => { const p = P(r.code), b = where(p).b; out.push({ v: roomV(r), main: r.name, sub: [b ? bShort(b) : p.name, M.floorName(r.floor)].join(' · '), code: p.code, ok: routable(p), kind: 1, words: p.name }); });
      // My room, to its own household alone (their own /me/stay, kept on this phone): "my room", "room",
      // the hall's name or their own number. Nobody else's number is anywhere here (§4.2).
      if (stayEnd()) out.push({ v: 'stay', main: stayName(), sub: staySub(), code: '', ok: true, kind: -1, grp: 'My room', words: 'my room ' + (stayHall() || '') + ' hall', nums: A.stay && A.stay.rooms ? A.stay.rooms.map(r => String(r.num).toLowerCase()) : [] });
      // The restrooms and elevators in the plans (Nearest), once they've been read.
      // "Nearest" only when measured (from the room last opened, or where the phone is); else they're just
      // the Restrooms and the Elevators (the check: "Nearest" claimed more than was known).
      const near = k => A.measured ? 'Nearest' : k === 'restroom' ? 'Restrooms' : 'Elevators';
      ['restroom', 'elevator'].forEach(k => uniqFeats(Array.isArray(A.feats[k]) ? A.feats[k] : []).forEach((f, fi) => out.push({ fi, v: featV(f), main: f.word, sub: f.B.short + ' · ' + M.floorName(f.floor) + (f.m != null ? ' · ' + M.feet(f.m) : ''), code: '', ok: true, kind: 2.5, grp: near(k), words: k === 'restroom' ? 'restroom restrooms bathroom toilet ' + f.word : 'elevator elevators lift' })));
      A.c.items.filter(i => i.kind === 'hall' && i.lab && i.name !== 'Building').forEach(h => out.push({ v: 'hall:' + h.name, main: h.name, sub: /\bhall\b/i.test(h.name) ? '' : 'Hall', code: '', ok: true, kind: 2, words: h.aliases.join(' ') + ' hall dorm residence' }));
      // Every other named building, for typing ("Reed" finds Reed Hall whether or not it's a hall here).
      const listed = new Set(out.map(c => c.main));
      A.c.items.filter(i => i.kind !== 'hall' && i.lab && i.name && i.name !== 'Building' && i.short !== '-' && i.pts.length > 2 && /^(other|dining|worship|venue)$/.test(i.kind) && !groups().some(g => where(g.main).b === i) && !listed.has(i.name)).forEach(b => out.push({ v: 'hall:' + b.name, main: b.name, sub: '', code: '', ok: true, kind: 2, words: (b.short || '') + ' ' + b.aliases.join(' ') }));
      A.c.spots.forEach(s => out.push({ v: 'spot:' + s.id, main: s.name || M.SPOT[s.spot], sub: s.name ? M.SPOT[s.spot] : '', code: '', ok: true, kind: 2, words: (M.SPOT[s.spot] || '') + ' ' + (SPOT_WORDS[s.spot] || '') + ' ' + (s.note || '') }));
      (A.ctx.help || []).filter(h => h.place && P(h.place)).forEach(h => out.push({ v: P(h.place).code, main: h.need, sub: P(h.place).name, code: P(h.place).code, ok: routable(P(h.place)), kind: 1, grp: 'Help', words: h.text || '', terms: h.search || [] }));
      // Care nearby, off campus (Search only: it has no Directions, driving is held, §13.2). Its sheet
      // has Emergency first.
      if (which === 'search' && A.ctx.openNear) (A.ctx.nearby || []).forEach((n, i) => { if (n.name) out.push({ v: 'near:' + i, main: n.name, sub: [n.kind, n.distance].filter(Boolean).join(' · '), code: '', ok: true, kind: 2, grp: 'Help', words: (n.kind || '') + ' care' }); });
      // Each row's place in time: today's to come (0), later days (1), past (2); then its day and time.
      const nw = A.ctx.now ? A.ctx.now() : null, gone = new Set(today().filter(it => it.state === 'past' && it.id).map(it => it.id));
      const when = e => { const day = e.date || '', t = e.start == null ? 1e4 : e.start; if (!nw || !day) return [1, day, t]; return [day < nw.date || (day === nw.date && ((e.id && gone.has(e.id)) || (e.end != null && e.end <= nw.minutes))) ? 2 : day === nw.date ? 0 : 1, day, t]; };
      (A.ctx.events ? A.ctx.events() : []).filter(e => e.code).forEach(e => { const p = P(e.code); out.push({ v: p ? p.code : '', main: e.title, sub: [e.when, p ? p.name : ''].filter(Boolean).join(' · '), code: p ? p.code : '', ok: !!p && routable(p), kind: 3, et: e.title, es: e.start == null ? '' : e.start, ord: when(e) }); });
      return out;
    }
    // Best first: the name itself, then names starting with it, then a word starting with it, then
    // anywhere in the name, then the code, then the line under it (polish 1: "first aid" put Barnes
    // above the First Aid Room).
    // Polish 2: also the words a place goes by ("dining", "cafeteria", "food" find Barnes; "parking",
    // "info" find the lots and the desk), what people say for what the campus calls it ("bathroom" is a
    // restroom), and a one-letter slip in a word of five letters or more ("barns"; places only: "parking"
    // isn't "Kit packing").
    function ranked(list, t) {
      const T = t.toUpperCase(), alts = [t].concat(SYN[t] || []);
      const words = s => String(s || '').toLowerCase().split(/[\s(/·,&-]+/).filter(Boolean);
      const slip = (w, q) => { if (q.length < 5 || Math.abs(w.length - q.length) > 1) return false; let i = 0, j = 0, e = 0; while (i < w.length && j < q.length) { if (w[i] === q[j]) { i++; j++; continue; } if (++e > 1) return false; if (w.length > q.length) i++; else if (q.length > w.length) j++; else { i++; j++; } } return e + (w.length - i) + (q.length - j) <= 1; };
      const one = (c, t) => { const n = c.main.toLowerCase(); if (n === t || c.code === T) return 0;
        if (c.nums && c.nums.length) { if (c.nums.indexOf(t) > -1) return .5; const mm = /^(.+?)\s+(\w+)$/.exec(t); if (mm && c.nums.indexOf(mm[2]) > -1 && words(c.bw || '').some(w => w.indexOf(mm[1]) === 0)) return .5; } if (n.indexOf(t) === 0) return 1; if (words(n).some(w => w.indexOf(t) === 0)) return 2; if (n.indexOf(t) > -1) return 3; if (c.code && c.code.indexOf(T) === 0) return 3.5; if (c.terms && (c.terms.indexOf(t) > -1 || (t.length > 3 && /s$/.test(t) && c.terms.indexOf(t.slice(0, -1)) > -1))) return 3.8; if (words(c.words).some(w => w.indexOf(t) === 0)) return 4; if (c.sub.toLowerCase().indexOf(t) > -1) return 5; if (c.kind !== 3 && words(n + ' ' + (c.words || '')).some(w => slip(w, t))) return 6; return Infinity; };
      const score = c => Math.min.apply(null, alts.map((a, i) => one(c, a) + (i ? .5 : 0)));
      const seen = new Set();
      // The restrooms and elevators keep their own order, the nearest first (round 2 part 2: "Restroom"
      // came before a nearer "Women’s restroom" for matching the word whole): one score for them all.
      const scored = list.map(c => Object.assign({ s: score(c) }, c)).filter(c => c.s < Infinity);
      const fs = Math.min.apply(null, scored.filter(c => c.fi != null).map(c => c.s).concat(Infinity));
      scored.forEach(c => { if (c.fi != null) c.s = fs; });
      return scored.sort((a, b) => a.s - b.s || a.kind - b.kind || (a.fi != null && b.fi != null ? a.fi - b.fi : 0) || a.main.length - b.main.length)
        // With floor plans a schedule row is its own day and time, sorted by time in filter() (round 2: "supper"
        // kept only Friday's, past, of five). A campus with no plans keeps one row a title, as before.
        .filter(c => { const k = c.v + '|' + c.main + (c.kind === 3 && A.plans ? '|' + c.ord[1] + '|' + c.ord[2] : ''); if (seen.has(k)) return false; seen.add(k); return true; }).slice(0, A.plans ? 60 : 40);
    }
    const resultRow = (which, c) => { const miss = !c.ok && member(A.ctx.year) ? 'Not on the map yet' : ''; return '<li><button type="button" data-pm="set" data-which="' + which + '" data-v="' + esc(c.v) + '"' + (c.et ? ' data-et="' + esc(c.et) + '" data-es="' + esc(c.es) + '"' : '') + (c.ok || (which === 'search' && c.v) ? '' : ' disabled') + '><span><b>' + esc(c.main) + '</b>' + (c.sub || miss ? '<small>' + esc([c.sub, miss].filter(Boolean).join(' · ')) + '</small>' : '') + '</span>' + (c.code ? '<code>' + esc(c.code) + '</code>' : '') + '</button></li>'; };
    // Search's body: the usual places; with nothing typed, Recent, every building with its rooms, the
    // halls, and parking and services; as you type, the ranked results.
    function pickBody(which) {
      const recent = LS.get('ogc-map-recent', []).map(P).filter(Boolean).filter(p => routable(p));
      const gs = groups().filter(g => where(g.main).kind !== 'none');
      const halls = A.c.items.filter(i => i.kind === 'hall' && i.lab && i.name !== 'Building' && !gs.some(g => where(g.main).b === i));
      const li = (v, main, sub, code) => '<li><button type="button" data-pm="set" data-which="' + which + '" data-v="' + esc(v) + '"><span><b>' + esc(main) + '</b>' + (sub ? '<small>' + esc(sub) + '</small>' : '') + '</span>' + (code ? '<code>' + esc(code) + '</code>' : '') + '</button></li>';
      // From's or To's Search (the planner, §4.5): My location (a phone), My room, then the same Search,
      // without the chips (they open places, not ends).
      const end = which === 'from' || which === 'to';
      const chips = end ? '' : A.plans ? stripChips(true) : quickChips(), help = end ? '' : A.plans ? stripChips(true) : helpChips();
      // With floor plans: My room first (its own household only), then Recent, then the chips (§4.2).
      const mine = end ? (touch() && A.mode === 'full' ? li('here', 'My location', A.nav.status && A.nav.status !== 'Locating' ? A.nav.status : '', '') : '') + (stayEnd() ? li('stay', stayName(), staySub(), '') : '')
        : A.plans && stayEnd() ? '<li data-sec><p class="pm-k">' + esc(stayName()) + '</p></li>' + li('stay', stayName(), staySub(), '') : '';
      const sub = r => A.plans && planFloor(r) != null ? M.floorName(planFloor(r)) : '';
      return '<label class="pm-q"><span class="ogc-sr">Search</span><input type="search" data-pmq data-which="' + which + '" placeholder="Building, room or code" autocomplete="off" enterkeyhint="search"><button type="button" class="pm-qx" data-pm="qx" aria-label="Clear" title="Clear" hidden>' + I.close + '</button></label><div class="pm-pickbody">' +
        (mine ? '<ul class="pm-list" data-quick>' + mine + '</ul>' : '') +
        (A.plans ? '' : chips ? '<div class="pm-quick" data-quick>' + chips + '</div>' : '') +
        '<ul class="pm-list" data-results hidden></ul><div data-none hidden><p class="pm-none">No results</p>' + (help ? '<div class="pm-quick">' + help + '</div>' : '') + '</div>' +
        '<ul class="pm-list" data-list>' +
        (recent.length ? '<li data-sec><p class="pm-k">Recent</p></li>' + recent.map(p => li(p.code, roomName(p), A.plans ? factLine(p, String(p.code).indexOf('/') < 0).replace(/ · [A-Z0-9]+\/[A-Z0-9]+$/, '') : String(p.code).indexOf('/') > -1 ? bShort(where(p).b) : '', p.code)).join('') : '') +
        (A.plans && chips ? '<li data-sec class="pm-list__chips"><div class="pm-quick">' + chips + '</div></li>' : '') +
        '<li data-sec><p class="pm-k">Buildings</p></li>' +
        gs.map(g => {
          const head = g.derived ? '<p class="pm-list__h">' + esc(g.name) + '</p>' : li(g.main.code, g.name, '', g.main.code);
          return '<li class="pm-list__g"><ul>' + head + (g.derived ? g.all : g.rooms).map(r => '<li class="pm-list__r">' + li(r.code, inBuilding(r, g.name), sub(r), r.code).slice(4)).join('') + '</ul></li>';
        }).join('') +
        (halls.length ? '<li data-sec><p class="pm-k">Halls</p></li>' + halls.map(h => li('hall:' + h.name, h.name, '', '')).join('') : '') +
        (A.c.spots.length ? '<li data-sec><p class="pm-k">Parking and services</p></li>' + A.c.spots.map(s => li('spot:' + s.id, s.name || M.SPOT[s.spot], s.name ? M.SPOT[s.spot] : '', '')).join('') : '') +
        '</ul></div>';
    }
    // Search opens full height with the field at the top, focused even on a phone (polish 1: a short
    // sheet with its field under the keyboard, a second tap to type).
    function picker(which) {
      which = which === 'from' || which === 'to' ? which : 'search';
      dlg.classList.add('is-search', 'is-full');
      dlg.classList.toggle('pm-pick--plans', !!A.plans);
      // Nearest needs the plans' restrooms and elevators: read once, in the background.
      if (A.L) ['restroom', 'elevator'].forEach(k => { if (featsStale(k)) loadFeats(k).then(() => { const q = dlg.open && dlg.querySelector('[data-pmq]'); if (q && q.value.trim()) filter(q); }); });
      // The rooms by IWU's name need the walking graph: read once, in the background.
      if (A.P && !A.build) routerNow().then(() => { const q = dlg.open && dlg.querySelector('[data-pmq]'); if (q && q.value.trim()) filter(q); });
      dlg.innerHTML = '<div class="wk-sheet__in pm-pickin"><button type="button" class="wk-sheet__x" data-close aria-label="Close">' + I.close + '</button>' +
        '<h2 class="ogc-sr" id="pm-pick-t">' + (which === 'from' ? 'From' : which === 'to' ? 'To' : 'Search') + '</h2>' + pickBody(which) + '</div>';
      dlg.showModal();
      const q = dlg.querySelector('[data-pmq]'); if (q) q.focus();
    }
    // Typing: the list becomes the ranked results; "No results" when nothing matches.
    function filter(input) {
      const box = input.closest('.pm-pickin'); if (!box) return;
      const t = input.value.trim().toLowerCase(), which = input.dataset.which;
      box.querySelectorAll('[data-quick]').forEach(e => { e.hidden = !!t; });
      const qx = box.querySelector('.pm-qx'); if (qx) qx.hidden = !input.value;
      box.querySelector('[data-list]').hidden = !!t;
      const res = box.querySelector('[data-results]'), none = box.querySelector('[data-none]');
      const hits = t ? ranked(candidates(which), t) : [];
      // With floor plans, in groups (§4.2): My room · Places · Nearest · Schedule · Help; Nearest at most four.
      if (A.plans) {
        const ORDER = ['My room', 'Places', 'Nearest', 'Restrooms', 'Elevators', 'Schedule', 'Help'], by = {};
        hits.forEach(c => { const g = c.grp || (c.kind === 3 ? 'Schedule' : 'Places'); (by[g] = by[g] || []).push(c); });
        // Restrooms and elevators in the list's own order (nearest first, or the marked ones on entrance
        // floors), not by how well "Restroom" matches the words typed.
        ['Nearest', 'Restrooms', 'Elevators'].forEach(g => { if (by[g]) by[g] = by[g].sort((a, b) => a.fi - b.fi).slice(0, 4); });
        // The schedule in time order: today's still to come first, then the days after, then what's past.
        // At most eight, so the soonest are what shows.
        if (by.Schedule) by.Schedule = by.Schedule.sort((a, b) => a.ord[0] - b.ord[0] || (a.ord[1] < b.ord[1] ? -1 : a.ord[1] > b.ord[1] ? 1 : 0) || a.ord[2] - b.ord[2]).slice(0, 8);
        res.innerHTML = ORDER.filter(g => by[g]).map(g => '<li data-sec><p class="pm-k">' + g + '</p></li>' + by[g].map(c => resultRow(which, c)).join('')).join('');
      } else res.innerHTML = hits.map(c => resultRow(which, c)).join('');
      res.hidden = !t || !hits.length; none.hidden = !t || !!hits.length;
    }
    function clearQ(lab) { const q = lab && lab.querySelector('[data-pmq]'); if (!q) return; q.value = ''; filter(q); q.focus(); }
    function onInput(e) { if (e.target.matches('[data-pmq]')) filter(e.target); }
    function onKey(e) {
      if (!e.target.matches('[data-pmq]')) return;
      if (e.key === 'Enter') { e.preventDefault(); const box = e.target.closest('.pm-pickin'), b = box && box.querySelector('[data-results]:not([hidden]) button:not([disabled])'); if (b) b.click(); }
    }
    dlg.addEventListener('input', onInput);
    dlg.addEventListener('keydown', onKey);
    // A choice: shown on the map with its card.
    function choose(b) { openEnd(endFrom(b.dataset.v)); }
    dlg.addEventListener('click', e => {
      if (e.target === dlg || e.target.closest('[data-close]')) { dlg.close(); return; }
      if (e.target.closest('[data-pm="qx"]')) { clearQ(e.target.closest('.pm-q')); return; }
      const b = e.target.closest('[data-pm="set"], [data-pm="room"], [data-pm="list"], [data-pm="spot"]'); if (!b || b.disabled) return;
      dlg.close();
      // From's or To's Search: the choice is that end of the route.
      if (b.dataset.pm === 'set' && (b.dataset.which === 'from' || b.dataset.which === 'to')) { setEnd(b.dataset.which, routeEnd(b.dataset.v)); return; }
      if (b.dataset.pm === 'room') { focus(b.dataset.code); return; }
      if (b.dataset.pm === 'list') { openList(b.dataset.v); return; }
      if (b.dataset.pm === 'spot') { openSpot(b.dataset.id); return; }
      choose(b);
    });

    function onClick(e) {
      const b = e.target.closest('[data-pm]'); if (!b || !A.el.contains(b) || b.disabled) return;
      const k = b.dataset.pm;
      // Walking (Start): the card, the sheet and the bar. (A swipe that ended on a button isn't a tap.)
      if (k.indexOf('w-') === 0) {
        if (A.swiped && Date.now() - A.swiped < 400) return;
        if (k === 'w-prev' || k === 'w-back') walkGo(-1);
        else if (k === 'w-next' || k === 'w-fwd' || k === 'w-in') walkGo(1);
        else if (k === 'w-recenter') walkRecenter();
        else if (k === 'w-end') endWalk();
        else if (k === 'w-done') walkFinish();
        else if (k === 'w-mock' && A.walk) walkSim(!A.walk.sim);
        return;
      }
      if (k === 'search') picker();
      else if (k === 'close') { A.place = null; settle('peek'); paint(); }
      // The planner (§4.5).
      else if (k === 'dirs') { const to = endOfPlace(A.place); if (to) openDirs(to); }
      else if (k === 'dirs-close') closeDirs();
      else if (k === 'end') picker(b.dataset.which);
      else if (k === 'swap' && A.dir && A.dir.from && A.dir.to) { const d = A.dir, f = d.from; d.from = d.to; d.to = f; d.auto = false; paint(); replan(true); }
      else if (k === 'sf') { LS.set(SF_KEY, !stepFree()); paint(); replan(false); }
      else if (k === 'start') start();
      else if (k === 'steps' && A.dir) { A.dir.list = true; settle('half'); paint(); fitRoute(A.dir.plan); const h = A.el.querySelector('.pm-dirs .pm-h'); if (h) { h.setAttribute('tabindex', '-1'); h.focus({ preventScroll: true }); } }
      else if (k === 'steps-close' && A.dir) { A.dir.list = false; A.dir.focus = -1; showRoute(false, null); settle('half'); paint(); fitRoute(A.dir.plan); const s = A.el.querySelector('[data-pm="steps"]'); if (s) s.focus({ preventScroll: true }); }
      // A step tapped: framed on the map without starting (on a phone the sheet steps down to show it).
      else if (k === 'step' && A.dir) { const i = +b.dataset.i; if (A.mode === 'full') { if (A.snap === 'full') setSheet('half', true); frameStep(i); } else if (A.dir.focus !== i) frameStep(i); }
      else if (k === 'room') focus(b.dataset.code);
      else if (k === 'spot') openSpot(b.dataset.id);
      else if (k === 'more-today') { A.allToday = true; paint(); }
      else if (k === 'event') { if (A.ctx.openEvent) A.ctx.openEvent(b.dataset.id); }
      else if (k === 'families') { A.place = { kind: 'families' }; settle('half'); paint(); say('For families'); }
      else if (k === 'locate') locate();
      else if (k === 'set') choose(b);
      else if (k === 'list') openList(b.dataset.v);
      else if (k === 'feat') openEnd(endFrom(b.dataset.v));
      else if (k === 'floor') { if (A.L) A.L.show(+b.dataset.fl); }
      else if (k === 'ring' && A.L) {
        // A Nearby row: rung on its floor, and framed with the room if it's out of view.
        const at = [+b.dataset.x, +b.dataset.y], i = A.destInfo;
        A.L.ring(b.dataset.b, +b.dataset.fl, at);
        if (i && i.room) { const r = i.room, x0 = Math.min(r.x, at[0]), y0 = Math.min(r.y, at[1]), bx = { x: x0, y: y0, w: Math.max(r.x + r.w, at[0]) - x0, h: Math.max(r.y + r.h, at[1]) - y0 }; A.map.look(bx.x + bx.w / 2, bx.y + bx.h / 2, Math.min(curScale(), A.L.scaleFor(bx, 40)), true); }
      }
    }
    document.addEventListener('click', e => { if (A.el && !A.hidden && A.el.contains(e.target)) onClick(e); });
    // A laptop with floor plans (§5.1): / opens Search; Esc closes the place open in the panel. The planner,
    // anywhere: Esc closes the phone's Steps, then the planner; the arrows move between steps (§9).
    document.addEventListener('keydown', e => {
      if (!A.el || A.hidden || dlg.open || e.defaultPrevented) return;
      // Walking: Esc is End; ← and → are Back and Next (the map keeps its own arrows when it has focus).
      if (A.walk) {
        if (e.key === 'Escape') { e.preventDefault(); endWalk(); }
        else if ((e.key === 'ArrowRight' || e.key === 'ArrowLeft') && !(e.target.closest && e.target.closest('.pv, input, textarea'))) { e.preventDefault(); walkGo(e.key === 'ArrowRight' ? 1 : -1); }
        return;
      }
      const dirs = A.place && A.place.kind === 'dirs' && A.dir;
      if (!A.plans && !dirs) return;
      const typing = e.target && e.target.closest && e.target.closest('input, textarea, select, [contenteditable]');
      const inside = A.el.contains(e.target === document.body ? A.el : e.target);
      if (dirs && (e.key === 'ArrowDown' || e.key === 'ArrowUp') && e.target.closest && e.target.closest('.pm-step')) {
        const all = Array.from(A.el.querySelectorAll('.pm-step')), i = all.indexOf(e.target.closest('.pm-step')), n = all[i + (e.key === 'ArrowDown' ? 1 : -1)];
        e.preventDefault(); if (n) { n.focus(); if (A.mode === 'full') frameStep(+n.dataset.i); }
      } else if (e.key === '/' && A.plans && !typing && !e.metaKey && !e.ctrlKey && A.mode !== 'full') { e.preventDefault(); picker(); }
      else if (e.key === 'Escape' && dirs && !typing && inside) { e.preventDefault(); const sc = A.dir.list && A.mode === 'full' && A.el.querySelector('[data-pm="steps-close"]'); if (sc) sc.click(); else closeDirs(); }
      else if (e.key === 'Escape' && A.place && A.plans && !typing && inside) { A.place = null; settle('peek'); paint(); }
    });
    // A laptop's steps (§5.1, W3): hovering (after 120 ms, so a pass over the list doesn't fly the map)
    // or focusing a step frames its stretch on its floor; leaving the list draws the whole route again.
    let hoverT = 0;
    document.addEventListener('pointerover', e => {
      if (!A.dir || A.hidden || A.mode === 'full' || !A.el || !A.el.contains(e.target) || e.pointerType === 'touch') return;
      const b = e.target.closest('.pm-step'); clearTimeout(hoverT);
      if (b && +b.dataset.i !== A.dir.focus) hoverT = setTimeout(() => frameStep(+b.dataset.i, true), 120);
    });
    document.addEventListener('pointerout', e => {
      if (!A.dir || A.mode === 'full' || !A.el || !e.target.closest || !e.target.closest('.pm-steps')) return;
      if (e.relatedTarget && e.relatedTarget.closest && e.relatedTarget.closest('.pm-steps')) return;
      clearTimeout(hoverT);
      if (A.dir.focus > -1 && !(document.activeElement && document.activeElement.closest && document.activeElement.closest('.pm-step'))) { A.dir.focus = -1; showRoute(false, null); A.el.querySelectorAll('.pm-step.is-on').forEach(x => x.classList.remove('is-on')); }
    });
    document.addEventListener('focusin', e => {
      if (!A.dir || A.hidden || A.mode === 'full' || !A.el || !A.el.contains(e.target)) return;
      const b = e.target.closest('.pm-step'); if (b && +b.dataset.i !== A.dir.focus) { clearTimeout(hoverT); frameStep(+b.dataset.i); }
    });

    const api = {
      mount, hide, focus,
      // A place by its code, a hall ("hall:Reed Hall") or a spot ("spot:<id>"): shown with its card.
      open: v => openEnd(endFrom(String(v))),
      search: () => picker(),
      // Directions to a place (a code, "hall:…", "spot:…", "stay"): its sheet, then the planner over it
      // (week.js's ?to=CODE&dirs=1, and every Directions in the guide's own sheets).
      directions(v) {
        if (!A.ctx) return;
        if (String(v) === 'stay' && !A.stay && !A.stayIn) { A.wantStay = true; return; }
        openEnd(endFrom(String(v)));
        const to = A.place && A.place.kind !== 'dirs' ? endOfPlace(A.place) : null;
        if (to) openDirs(to);
      },
      // The planner again after what it reads changed (the stay, Step-free; the dev pages' made-up stay).
      redraw() { if (A.dir) { if (A.dir.auto) A.dir.from = fromDefault(); replan(false); } paint(); },
      destroy() { hide(); if (A.el) A.el.remove(); dlg.remove(); },
      get state() { return A; }
    };
    if (window.OGC_WP && OGC_WP.dev) M.devApp = api;
    return api;
  }

  M.app = app;
  // A feature's line icon, for the guide's own sheets (Oct 13).
  M.featureIcon = f => I['f-' + f] || '';
})();
