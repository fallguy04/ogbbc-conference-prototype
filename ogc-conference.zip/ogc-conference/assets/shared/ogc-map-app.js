/*
 * ogc-map-app.js — the guide's Places, as a maps app (the map area, Oct 10).
 *
 * The audit at 390: the map was a box inside a scrolling page that caught every drag, the answer to
 * "how far" sat below the fold, Start scrolled the map away, and Directions with no start did nothing.
 * Now, on a phone (the guide), Places is the map, full height, with a sheet over it (peek: the usual
 * trips, or the route on one line with its answer; half: From and To and the steps, or a place; full:
 * every building). On a laptop the map has its panel beside it when the column is wide (a container
 * query, not the window), else above it; Choose start drops down under its field. Walking is its own
 * full screen: the next turn on top, time left and End at the bottom.
 *
 * week.js hands it what the page knows (ctx): the year, the campus (O.map.campus), the places, today's
 * rows with their state, every row (for search), the Help cards, the time, and how to open an event.
 * It keeps its own state between drawings of the page (the map keeps its place).
 *
 * Nothing about where someone is leaves the phone: the location is used while Places is open and
 * stopped when it closes or the page is hidden; "My room" comes from the server for the signed-in
 * person alone (/me/stay, never kept). Recent destinations (codes only) stay on this device.
 */
(function () {
  'use strict';
  const O = window.OGC, esc = O.esc, M = O.map;
  if (!M) return;
  const svg = d => '<svg class="pm-i" viewBox="0 0 24 24" aria-hidden="true"><path d="' + d + '" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  const I = {
    search: svg('M10.5 17a6.5 6.5 0 1 0 0-13 6.5 6.5 0 0 0 0 13ZM15.3 15.3l4.7 4.7'),
    dirs: svg('M12 3.5 20.5 12 12 20.5 3.5 12ZM9.5 13.5v-2.5h4.5M12.5 9l2 2-2 2'),
    pin: svg('M12 20.5s-6.5-5.4-6.5-10.8a6.5 6.5 0 0 1 13 0c0 5.4-6.5 10.8-6.5 10.8ZM12 12a2.3 2.3 0 1 0 0-4.6 2.3 2.3 0 0 0 0 4.6Z'),
    close: svg('M6.5 6.5l11 11M17.5 6.5l-11 11'),
    swap: svg('M7.5 4.5v14M4.5 7.5l3-3 3 3M16.5 19.5v-14M13.5 16.5l3 3 3-3'),
    locate: svg('M12 3v3M12 18v3M3 12h3M18 12h3M12 17a5 5 0 1 0 0-10 5 5 0 0 0 0 10Z'),
    bed: svg('M3.5 18.5v-11M3.5 14.5h17v4M20.5 14.5v-2.5a2.5 2.5 0 0 0-2.5-2.5h-7v5M7 12.2a1.6 1.6 0 1 0 0-3.2 1.6 1.6 0 0 0 0 3.2Z'),
    clock: svg('M12 20.5a8.5 8.5 0 1 0 0-17 8.5 8.5 0 0 0 0 17ZM12 7.5V12l3 2'),
    cross: svg('M9.5 4.5h5v5h5v5h-5v5h-5v-5h-5v-5h5Z'),
    desk: svg('M4.5 9.5h15v10h-15ZM9.5 9.5v-4h5v4'),
    tap: svg('M9 11.5V5.5a1.5 1.5 0 0 1 3 0v5M12 10.5v-1a1.5 1.5 0 0 1 3 0v1.5M15 11v-.5a1.5 1.5 0 0 1 3 0v4.5a6 6 0 0 1-6 6h-.5a6 6 0 0 1-5.2-3l-2-3.6a1.5 1.5 0 0 1 2.6-1.5L9 15'),
    phone: svg('M6.5 3.5h3l1.5 4-2 1.5a10 10 0 0 0 6 6l1.5-2 4 1.5v3a2 2 0 0 1-2 2A15.5 15.5 0 0 1 4.5 5.5a2 2 0 0 1 2-2Z'),
    straight: svg('M12 20V5M7 10l5-5 5 5'),
    left: svg('M16 20v-7.5a3 3 0 0 0-3-3H6M10 5.5 6 9.5l4 4'),
    right: svg('M8 20v-7.5a3 3 0 0 1 3-3h7M14 5.5l4 4-4 4'),
    'slight-left': svg('M14 20v-6L8.5 8.5M8 13.5V8h5.5'),
    'slight-right': svg('M10 20v-6l5.5-5.5M16 13.5V8h-5.5'),
    uturn: svg('M9 20V9.5a4 4 0 0 1 8 0V14M14 11l3 3 3-3'),
    around: svg('M8 20.5c-3-3.5-3.5-9 .5-12.5s10-2.5 12 1.5M20.5 4.5v5h-5'),
    arrive: svg('M6.5 20.5v-16M6.5 5h10l-2 3.5 2 3.5h-10'),
    prev: svg('M14.5 5.5 8 12l6.5 6.5'),
    next: svg('M9.5 5.5 16 12l-6.5 6.5'),
    list: svg('M8.5 6.5h11M8.5 12h11M8.5 17.5h11M4.5 6.5h.01M4.5 12h.01M4.5 17.5h.01')
  };
  // The words a place goes by, beyond its name (search).
  const KIND_WORDS = { dining: ['dining', 'cafeteria', 'food', 'meals', 'lunch', 'dinner', 'breakfast'], worship: ['chapel', 'worship', 'services', 'auditorium'], venue: ['auditorium', 'theater', 'hall'], hall: ['hall', 'dorm', 'residence'] };
  const SPOT_WORDS = { parking: 'parking lot cars', accessible: 'parking accessible handicap', camper: 'campers rv lot', carts: 'golf carts cart ride', desk: 'information info desk help' };
  const SYN = { bathroom: ['restroom'], bathrooms: ['restroom'], toilet: ['restroom'], washroom: ['restroom'], food: ['dining'], eat: ['dining'], meals: ['dining'], cafeteria: ['dining'], info: ['information'], doctor: ['first aid'], nurse: ['first aid'], medical: ['first aid'], gym: ['recreation', 'arena'], dorm: ['hall'] };
  const LS = { get: (k, d) => { try { const v = localStorage.getItem(k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } }, set: (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { /* fine */ } } };
  const coarse = () => !!(window.matchMedia && matchMedia('(pointer: coarse)').matches);
  // Members (the pins tool's people) are told what the map is missing; the public only what's useful.
  const W = () => window.OGC_WP || {};
  const member = y => !!(W().webmaster || (W().member || []).map(String).indexOf(String(y)) > -1);
  const touch = () => coarse() && 'geolocation' in navigator;

  function app() {
    const A = { el: null, ctx: null, c: null, R: null, map: null, mapEl: null, mode: '', place: null, nav: { from: null, to: null, me: null, status: '', route: null }, sheetH: 0, snap: 'peek', stay: null, stayAsked: false, watch: null, perm: '', go: null, hidden: true, drop: null, pointing: null };
    A.stepFree = !!LS.get('ogc-map-stepfree', false);
    const dlg = document.createElement('dialog');
    dlg.className = 'ogc wk-sheet pm-pick';
    dlg.setAttribute('aria-labelledby', 'pm-pick-t');
    document.body.appendChild(dlg);

    /* ------------------------------------------------ what the page knows */

    const places = () => A.ctx.places || {};
    const P = code => code ? places()[String(code).toUpperCase()] || null : null;
    const keyOf = code => String(code).split('/')[0].toUpperCase();
    // A room named for its building ("Piazza Terrace (Barnes)") drops the building in its own card.
    const inBuilding = (room, b) => String(room.name).replace(/\s*\(([^)]+)\)$/, (m, w) => String(b).toLowerCase().indexOf(w.split(' ')[0].toLowerCase()) > -1 ? '' : m);
    // The buildings people go to, in places.csv's order, each with its rooms. A building listed only by
    // its rooms (Cedarville's "Stevens Student Center Room 241") is named for the building, not a room.
    function groups() {
      const out = [], by = {};
      Object.keys(places()).forEach(k => {
        const p = places()[k], key = keyOf(p.code);
        if (!by[key]) out.push(by[key] = { key, main: null, rooms: [] });
        if (String(p.code).toUpperCase() === key) by[key].main = p; else by[key].rooms.push(p);
      });
      return out.filter(g => g.main || g.rooms.length).map(g => {
        if (g.main) return Object.assign(g, { name: g.main.name, all: g.rooms });
        const r = g.rooms[0], name = r.building || String(r.name).replace(/\s*(room|rm\.?|#)\s*[\w–-]+$/i, '') || r.name;
        return Object.assign(g, { main: r, name, all: g.rooms, derived: true });
      });
    }
    const where = p => M.whereIs(A.c, p, places());
    // The halls with rooms this year: rooms.csv for those who may read it, else the campus's own mark.
    const stayHalls = () => Array.from(new Set((A.ctx.halls || []).concat(A.c.items.filter(i => i.stay && i.lab).map(i => i.name))));
    const routable = p => { const w = p && where(p); return !!(A.R && w && (w.kind === 'pin' || w.kind === 'building')); };
    const today = () => (A.ctx.today ? A.ctx.today() : []);
    const now = () => A.ctx.now ? A.ctx.now() : { minutes: 0 };
    // The next thing on today (the Conference's own rows), for "Next".
    function nextEvent() {
      return today().filter(it => it.code && P(it.code) && !it.allDay && (it.state === 'upcoming' || it.state === 'now') && (!it.audience || it.audience === 'conference' || it.audience === 'all'))
        .sort((a, b) => (a.state === 'now') - (b.state === 'now') || (a.start == null ? 1e9 : a.start) - (b.start == null ? 1e9 : b.start))[0] || null;
    }
    // The guide's own way to say a time ("11:00 PM ET" to a reader in another zone), as Today says it.
    const clock = m => { const t = ((m % 1440) + 1440) % 1440; return A.ctx && A.ctx.clock ? A.ctx.clock(t) : O.formatTime(t); };
    // The schedule's own short names for buildings ("PPAC", not "Phillippe").
    let shorts = {};
    // A building as the schedule names it ("PPAC", not campus.csv's "Phillippe"), everywhere a building is said.
    const bShort = b => b ? shorts[b.name] || M.shortOf(b) : '';
    // What tells a room apart, beyond its own name: "First Aid Room (Barnes Room 131)" → "Room 131".
    const roomRest = (room, b) => { const m = /\(([^)]+)\)$/.exec(String(room.name)); if (!m || String(b).toLowerCase().indexOf(m[1].split(' ')[0].toLowerCase()) < 0) return ''; const r = /\b(rooms?|rm\.?)\s+\S.*$/i.exec(m[1]); return r ? r[0].charAt(0).toUpperCase() + r[0].slice(1) : ''; };
    // A room by its own name ("First Aid Room"); the building and number go on the line under it.
    const roomName = p => { const b = where(p).b; return String(p.code).indexOf('/') > -1 && b ? inBuilding(p, b.name) : p.name; };

    /* ------------------------------------------------ the ends of a route */

    // An end: { kind: 'me' | 'stay' | 'place' | 'hall' | 'spot' | 'pt', code, name, id, x, y, ev }
    function stayHall() { const s = A.stay; if (!s) return ''; if (s.type === 'dorm' && s.rooms && s.rooms.length) return s.rooms[0].hall; if (s.type === 'yf' && s.halls && s.halls.length === 1) return s.halls[0]; return ''; }
    const camper = () => A.c.spots.find(s => s.spot === 'camper');
    function stayEnd() {
      const s = A.stay; if (!s) return null;
      if (s.type === 'camper' && camper()) return { kind: 'stay' };
      return stayHall() ? { kind: 'stay' } : null;
    }
    // Two ends that are the same place (polish 1: From My room, To My room, "1 min · 10 ft").
    function endKey(e) {
      if (!e) return '';
      if (e.kind === 'place') return 'p:' + String(e.code).toUpperCase();
      if (e.kind === 'stay') return stayHall() ? 'h:' + M.norm(stayHall()) : camper() ? 's:' + camper().id : 'stay';
      if (e.kind === 'hall') return 'h:' + M.norm(e.name);
      if (e.kind === 'spot') return 's:' + e.id;
      if (e.kind === 'pt') return 'pt:' + e.x.toFixed(0) + ',' + e.y.toFixed(0);
      return e.kind;
    }
    // Polish 2: two ends in one building are the same place too (Piazza Terrace to Barnes was "1 min ·
    // 10 ft" with a pin on the doorstep): never offered as a start, never routed. My location (or a point)
    // inside the building isn't "the same": it gets the room's line instead of a route (routeNow).
    const live = e => e && (e.kind === 'me' || e.kind === 'pt');
    const same = (a, b) => !!a && !!b && (endKey(a) === endKey(b) || (!live(a) && !live(b) && !!endBuilding(a) && M.norm(endBuilding(a)) === M.norm(endBuilding(b))));
    // The building an end is inside ('' when it isn't in one): a live end by where it is.
    function endIn(e) {
      if (!live(e)) return endBuilding(e);
      const p = e.kind === 'me' ? A.nav.me : e, w = p && M.whereAmI(A.c, p);
      return w && w.inside ? w.b.name : '';
    }
    function points(e) {
      if (!e || !A.R) return [];
      const o = { date: now().date, stepFree: A.stepFree };
      if (e.kind === 'me') return A.nav.me ? [A.nav.me] : [];
      if (e.kind === 'pt') return [{ x: e.x, y: e.y }];
      if (e.kind === 'stay') { if (A.stay && A.stay.type === 'camper') { const s = camper(); return s ? [{ x: s.cx, y: s.cy }] : []; } const h = stayHall(); return h ? A.R.doors(h, Object.assign({ keys: true }, o)) : []; }
      if (e.kind === 'hall') return A.R.doors(e.name, Object.assign({ keys: true }, o));
      if (e.kind === 'spot') { const s = A.c.spots.find(x => x.id === e.id); return s ? [{ x: s.cx, y: s.cy }] : []; }
      const p = P(e.code); if (!p) return [];
      const w = where(p);
      if (w.kind === 'pin' && w.outdoor) return [{ x: w.x, y: w.y }];
      if (w.kind === 'pin' && w.b) {
        const ds = A.R.doors(w.b.name, o);
        // The door the walk-through named for this room, else the one nearest its pin.
        const named = p.door && ds.find(d => d.door && d.door.id === p.door);
        return named ? [named] : ds.slice().sort((a, b) => Math.hypot(a.x - w.x, a.y - w.y) - Math.hypot(b.x - w.x, b.y - w.y)).slice(0, 1);
      }
      if (w.kind === 'pin') return [{ x: w.x, y: w.y }];
      return w.kind === 'building' ? A.R.doors(w.b.name, o) : [];
    }
    function endName(e) {
      if (!e) return '';
      if (e.kind === 'me') return 'My location';
      if (e.kind === 'pt') return 'Point on map';
      if (e.kind === 'stay') return A.stay && A.stay.type === 'camper' ? 'Camper lot' : A.stay && A.stay.type === 'yf' ? 'My hall' : 'My room';
      if (e.kind === 'spot') { const s = A.c.spots.find(x => x.id === e.id); return s ? s.name || M.SPOT[s.spot] : 'Spot'; }
      // A destination chosen from the schedule keeps its event (polish 1): "Lunch · 12:05 PM".
      if (e.kind === 'place' && e.ev) return e.ev.title + (e.ev.start != null && e.ev.start !== '' ? ' · ' + clock(+e.ev.start) : '');
      // A room by its own name (polish 3: "First Aid Room" in the list, "First Aid Room (B…" in the field).
      if (e.kind === 'place' && P(e.code)) return roomName(P(e.code));
      return e.name || e.code;
    }
    // The second line: what tells rooms apart ("Barnes · Ground floor"), or where I am. The code goes in its own chip.
    function endSub(e) {
      if (!e) return '';
      if (e.kind === 'me') { if (!A.nav.me) return A.nav.status || ''; const w = M.whereAmI(A.c, A.nav.me); return w ? (w.inside ? 'In ' : 'Near ') + bShort(w.b) + (w.door ? ' · ' + w.door : '') : ''; }
      if (e.kind === 'pt') { const w = M.whereAmI(A.c, e); return w ? (w.inside ? 'In ' : 'Near ') + bShort(w.b) : ''; }
      // "Reed Hall · 2nd floor · 211, 212" (the floor of the first room; polish 2).
      if (e.kind === 'stay') { const s = A.stay; if (s && s.type === 'dorm' && s.rooms && s.rooms.length) { const fl = Array.from(new Set(s.rooms.map(r => +r.floor || 0).filter(Boolean))); return [s.rooms[0].hall, fl.length === 1 ? M.floorName(fl[0]) : '', s.rooms.map(r => r.num).join(', ')].filter(Boolean).join(' · '); } return stayHall(); }
      if (e.kind !== 'place') return '';
      const p = P(e.code); if (!p) return '';
      if (e.ev) return p.name;
      const w = where(p), b = w.b;
      const bits = [];
      if (b && M.norm(b.name) !== M.norm(p.name)) bits.push(bShort(b));
      if (b) bits.push(roomRest(p, b.name));
      if (p.floor) bits.push(M.placeLine(A.c, { floor: p.floor }, places()));
      return bits.filter(Boolean).join(' · ');
    }
    const endCode = e => e && e.kind === 'place' ? (P(e.code) || {}).code || '' : '';
    // The short way to say an end, as the map and the steps do: "Piazza Terrace", "Barnes", "Reed"
    // (polish 2: the peek's line cut "Piazza Terrace (Bar… → Barnes Student Ce…").
    function endShort(e) {
      if (!e) return '';
      if (e.kind === 'hall') { const b = M.find(A.c, e.name); return b ? shorts[b.name] || M.shortOf(b) : e.name; }
      if (e.kind !== 'place' || e.ev) return endName(e);
      const p = P(e.code); if (!p) return endName(e);
      const b = where(p).b;
      if (String(p.code).indexOf('/') > -1) return b ? inBuilding(p, b.name) : p.name;
      return b ? shorts[b.name] || M.shortOf(b) : p.name;
    }
    // The building an end is at (for its pin to stand in for the building's own name on the map).
    function endBuilding(e) {
      if (!e) return '';
      if (e.kind === 'stay') return stayHall();
      if (e.kind === 'hall') return e.name;
      // (A field named for the building beside it is out of doors, not in it.)
      if (e.kind === 'place') { const p = P(e.code), w = p ? where(p) : null; return w && w.b && p.outdoor !== 'yes' ? w.b.name : ''; }
      return '';
    }
    // Where to start, never the destination itself: my location on campus, else my room.
    function defaultFrom() {
      if (A.nav.me && M.onCampus(A.c, A.nav.me) && A.nav.status !== 'Approximate location') return { kind: 'me' };
      const s = stayEnd();
      return s && !same(s, A.nav.to) ? s : null;
    }
    function routeNow() {
      const n = A.nav;
      // The same place at both ends: no route; the start is asked for instead.
      if (same(n.from, n.to)) n.from = null;
      // Already inside the building: no walk, only how to find the room.
      n.inside = n.from && n.to && endIn(n.from) && M.norm(endIn(n.from)) === M.norm(endIn(n.to)) ? endIn(n.to) : '';
      if (n.inside) { n.route = null; return null; }
      // A room with no pin is walked to its building and arrived at as the building (polish 3: "Arrive ·
      // First Aid Room" at a guessed door read as the room's own door); the room goes on the line under it.
      const tp = n.to && n.to.kind === 'place' ? P(n.to.code) : null, tw = tp ? where(tp) : null, room = !!tp && String(tp.code).indexOf('/') > -1;
      const toName = !tp ? endName(n.to) : tw.b && (tw.kind === 'building' || !room) ? tw.b.name : roomName(tp);
      n.route = n.from && n.to ? A.R.route(points(n.from), points(n.to), { stepFree: A.stepFree, date: now().date, shorts, toName, used: A.used || [], fromName: endBuilding(n.from) }) : null;
      if (n.route && tp) {
        const z = n.route.legs[n.route.legs.length - 1], line = M.placeLine(A.c, { floor: tp.floor, inside: tp.inside }, places());
        z.sub = [room && tw.kind === 'building' ? roomName(tp) : '', room && tw.b ? roomRest(tp, tw.b.name) : '', line].filter(Boolean).join(' · ');
        n.route.unpinned = room && tw.kind === 'building';
      }
      return n.route;
    }

    /* ------------------------------------------------ location (the phone only) */

    function locate(then) {
      const n = A.nav;
      if (!touch()) return;
      if (A.watch != null) { if (n.me && M.onCampus(A.c, n.me)) A.map.centre(n.me, true); return; }
      n.status = 'Locating';
      paint();
      A.watch = navigator.geolocation.watchPosition(pos => {
        const p = M.toMap(A.c, pos.coords.latitude, pos.coords.longitude);
        if (!p) return;
        p.acc = pos.coords.accuracy;
        const first = !n.me || n.mock;
        n.mock = false; n.me = p; A.perm = 'granted';
        n.status = !M.onCampus(A.c, p) ? 'Not on campus' : p.acc > 40 ? 'Approximate location' : '';
        if (!n.status && (!n.from || n.from.kind === 'me')) { n.from = { kind: 'me' }; routeNow(); }
        if (A.go) follow();
        else { paint(first); if (first && !n.status && !n.route) A.map.centre(p, true); }
        if (then) { const t = then; then = null; t(); }
      }, err => {
        n.status = err && err.code === 1 ? 'Location off' : 'Location unavailable';
        if (err && err.code === 1) A.perm = 'denied';
        stopWatch(); paint();
      }, { enableHighAccuracy: true, maximumAge: 5000, timeout: 15000 });
    }
    function stopWatch() { if (A.watch != null && navigator.geolocation) navigator.geolocation.clearWatch(A.watch); A.watch = null; }
    // Hidden page: the GPS stops (battery); back again, it starts again if it was on.
    let wasWatching = false;
    document.addEventListener('visibilitychange', () => {
      if (document.hidden) { wasWatching = A.watch != null; stopWatch(); releaseWake(); }
      else { if (wasWatching && !A.hidden) locate(); if (A.go) wake(); }
    });
    if (navigator.permissions && navigator.permissions.query) navigator.permissions.query({ name: 'geolocation' }).then(s => { A.perm = s.state; s.onchange = () => { A.perm = s.state; }; }).catch(() => {});

    /* ------------------------------------------------ drawing */

    function mount(slot, ctx) {
      const yearChanged = !A.ctx || A.ctx.year !== ctx.year || A.ctx.campus !== ctx.campus;
      A.ctx = ctx; A.hidden = false;
      if (yearChanged) { A.c = ctx.campus; A.R = M.routerOf(A.c); A.place = null; A.drop = null; A.pointing = null; A.nav = { from: null, to: null, me: A.nav.me, status: '', route: null, mock: A.nav.mock }; A.stay = null; A.stayAsked = false; if (A.map) { A.mapEl.remove(); A.map = null; } shorts = M.shortsFor ? M.shortsFor(A.c, places()) : {}; }
      const mode = ctx.full ? 'full' : 'embed';
      if (!A.el) { A.el = document.createElement('div'); A.el.className = 'pm'; }
      if (A.mode !== mode) { A.mode = mode; A.el.className = 'pm pm--' + mode + (ctx.guide ? ' pm--guide' : ''); A.drop = null; build(); }
      slot.appendChild(A.el);
      if (!A.map) makeMap();
      document.documentElement.classList.toggle('pm-on', mode === 'full');
      document.documentElement.classList.add('pm-places');
      if (mode === 'full') { scrollTo(0, 0); place(); }
      else { A.el.style.removeProperty('--pm-top'); A.el.style.removeProperty('--pm-bottom'); }
      const host = A.el.querySelector('.pm-map'); if (A.mapEl.parentNode !== host) host.appendChild(A.mapEl);
      if (!A.stayAsked) { A.stayAsked = true; M.store.stay(ctx.year).then(s => {
        A.stay = s && s.type ? s : null;
        if (A.stay && !A.nav.from && A.nav.to) { A.nav.from = defaultFrom(); routeNow(); }
        paint();
        // My hall in the first frame too (it comes after the map is drawn), unless something's been asked for.
        const h = stayHall();
        if (h && A.map && !A.place && !A.nav.to && !A.go && A.firstFrame && A.firstFrame.indexOf(h) < 0) { A.firstFrame = A.firstFrame.concat([h]); A.map.fit(M.boxOf(A.c, A.firstFrame, 30), 8, true); }
      }); }
      paint();
    }
    function hide() {
      if (A.hidden) return;
      A.hidden = true; stopWatch(); endWalk(); document.documentElement.classList.remove('pm-on', 'pm-places');
    }
    function build() {
      const search = '<button type="button" class="pm-search" data-pm="search">' + I.search + 'Search</button>';
      A.el.innerHTML = A.mode === 'full'
        ? '<div class="pm-map">' + search + '</div><section class="pm-sheet is-peek" aria-label="Places"><button type="button" class="pm-grab" data-pm="grab" aria-label="More"></button><div class="pm-body"></div></section>'
        : '<div class="pm-grid"><div class="pm-map">' + search + '</div><div class="pm-panel" aria-live="off"></div></div><div class="pm-cards" aria-label="Buildings"></div><div class="pm-extra"></div>';
      if (A.mode === 'full') sheetDrag();
    }
    // The fixed map sits between the guide's header and its tabs.
    function place() {
      const head = document.querySelector('.wk-apphead'), tabs = document.querySelector('.wk-tabbar');
      const top = head ? Math.max(0, head.getBoundingClientRect().bottom) : 0, bottom = tabs ? tabs.getBoundingClientRect().height : 0;
      A.el.style.setProperty('--pm-top', top + 'px'); A.el.style.setProperty('--pm-bottom', bottom + 'px');
    }
    addEventListener('resize', () => { if (A.mode === 'full' && !A.hidden) { place(); setSheet(A.snap, false); } });
    // The first frame: the halls with rooms this year and the buildings the schedule uses, together.
    // Polish 2: the outlier rule (a fieldhouse across the fields) dropped Reed and Evans too; it now
    // applies to the Conference's buildings only, and the halls always stay.
    function core(names, halls) {
      const its = names.map(x => M.find(A.c, x)).filter(Boolean), keep = new Set((halls || []).map(x => (M.find(A.c, x) || {}).name).filter(Boolean));
      const med = xs => xs.slice().sort((p, q) => p - q)[Math.floor(xs.length / 2)] || 0;
      const mx = med(its.map(i => i.lx)), my = med(its.map(i => i.ly)), d = i => Math.hypot(i.lx - mx, i.ly - my), md = med(its.map(d));
      return Array.from(new Set(its.filter(i => keep.has(i.name) || d(i) <= Math.max(md * 2.5, 180)).map(i => i.name).concat(Array.from(keep))));
    }
    function makeMap() {
      A.mapEl = document.createElement('div'); A.mapEl.className = 'pm-mapbox'; A.mapEl.style.cssText = 'position:absolute;inset:0';
      const used = new Set(), codes = {};
      groups().forEach(g => { const w = where(g.main); if (w.b) { used.add(w.b.name); if (!codes[w.b.name] && !g.derived && String(g.main.code).indexOf('/') < 0) codes[w.b.name] = g.key; } });
      const hall = stayHall(); if (hall) used.add(hall);
      // First view: the buildings this year's schedule uses, and the halls with rooms (never names written in code).
      const halls = stayHalls().concat(hall ? [hall] : []), start = core(Array.from(used).concat(halls), halls);
      A.firstFrame = start; A.used = Array.from(used);
      const focus = A.pendingFocus ? A.pendingFocus : null; A.pendingFocus = null;
      A.map = M.viewer(A.mapEl, A.c, { title: 'Campus map', locate: true, start, focus, extent: Array.from(used).concat(halls), used: Array.from(used), codes, shorts, cooperative: A.mode !== 'full', expand: A.mode !== 'full',
        onTap: (pt, b, spot) => { if (A.pointing) return setPoint(pt); if (spot) openSpot(spot); else if (b) openBuilding(b); },
        onLocate: () => locate(), onMove: () => { if (A.go) A.go.free = true; showRecentre(); },
        // North: the map north up again; while walking, Recentre turns it back.
        onNorth: () => { A.map.turn(null); if (A.go) { A.go.north = true; A.go.free = true; walkPaint(false); } } });
      A.el.querySelector('.pm-map').appendChild(A.mapEl);
      // The first time on this device: how the map moves (gone at the first touch).
      if (!LS.get('ogc-map-hinted', false)) { LS.set('ogc-map-hinted', true); setTimeout(() => A.map && A.map.hint(A.mode === 'full' ? 'Drag to move · Tap a building' : 'Tap a building'), 600); }
    }

    // The panel (laptop) or sheet (phone): what's open now.
    function paint(fit) {
      if (!A.el || A.hidden) return;
      const n = A.nav;
      let body;
      if (A.dir || A.pointing) body = dirView();
      else if (A.place) body = placeView(A.place);
      else body = browseView();
      if (A.mode === 'full') {
        const b = A.el.querySelector('.pm-body'), keepScroll = b.scrollTop;
        b.innerHTML = body + (A.dir || A.place || A.pointing ? '' : cardsView() + (A.ctx.extra || ''));
        b.scrollTop = keepScroll;
        setSheet(A.snap, false);
      } else {
        const panel = A.el.querySelector('.pm-panel'), q = panel.querySelector('[data-pmq]'), qv = q ? q.value : '', had = q && document.activeElement === q;
        panel.innerHTML = body;
        // A drop-down's typing survives a redraw (the location coming in, say).
        const q2 = panel.querySelector('[data-pmq]'); if (q2 && qv) { q2.value = qv; filter(q2); } if (q2 && had) q2.focus();
        A.el.querySelector('.pm-cards').innerHTML = cardsView();
        A.el.querySelector('.pm-extra').innerHTML = A.ctx.extra || '';
      }
      drawMap(fit);
    }
    const topInset = () => { const sb = A.el && A.el.querySelector('.pm-search'); return sb && sb.offsetHeight ? sb.offsetTop + sb.offsetHeight + 8 : 64; };
    // A building framed with its neighbours: it fills at most about a third of the map's width (polish 1:
    // on a laptop a tapped building filled 70% and the context was lost).
    const roomy = (box, f) => box ? { x: box.x + box.w / 2 - box.w / f / 2, y: box.y + box.h / 2 - box.h / f / 2, w: box.w / f, h: box.h / f } : null;
    function drawMap(fit) {
      const m = A.map, n = A.nav;
      if (!m) return;
      m.route(n.route, A.go ? A.go.at : 0);
      m.me(n.me && M.onCampus(A.c, n.me) ? n.me : null);
      const pins = [];
      let sel = '', green = null, box = null;
      const target = n.to || (A.place ? A.place : null);
      if (target) {
        const t = target.kind ? target : { kind: 'place', code: target.code };
        if (t.kind === 'place') {
          const p = P(t.code), w = p ? where(p) : { kind: 'none' };
          if (w.b) sel = w.b.name;
          green = w.green || null;
          if (w.kind === 'pin') pins.push({ x: w.x, y: w.y, kind: 'to', label: endShort(t) });
          // A room with no pin: its building tinted, and (on a route) a dot at the door reached, never a
          // pin that reads as the room itself (polish 3).
          else if (w.b && String(p.code).indexOf('/') > -1) { if (n.route) { const z = n.route.pts[n.route.pts.length - 1]; pins.push({ x: z.x, y: z.y, kind: 'room', label: '' }); } }
          // At a building's door: the pin names the door (the building's own name is on it already).
          else if (w.b && n.route) { const z = n.route.pts[n.route.pts.length - 1]; pins.push({ x: z.x, y: z.y, kind: 'to', label: n.route.end && n.route.end.label ? n.route.end.label : '' }); }
          else if (w.b) pins.push({ x: w.b.lx, y: w.b.ly, kind: 'to', label: '' });
          box = w.kind === 'pin' ? M.boxOf(A.c, w.b ? [w.b.name] : [], 30) : w.b ? M.boxOf(A.c, [w.b.name], 10) : null;
          if (w.kind === 'pin' && !box) box = { x: w.x - 60, y: w.y - 60, w: 120, h: 120 };
        } else if (t.kind === 'hall' || t.kind === 'stay') {
          const h = t.kind === 'hall' ? t.name : stayHall();
          if (h) { sel = h; const z = n.route ? n.route.pts[n.route.pts.length - 1] : null, b = M.find(A.c, h); pins.push({ x: z ? z.x : b.lx, y: z ? z.y : b.ly, kind: 'to', of: t.kind === 'hall' ? b.name : '', label: t.kind === 'stay' ? endName(t) : bShort(b) }); box = M.boxOf(A.c, [h], 10); }
          else if (A.stay && A.stay.type === 'camper' && camper()) { const s = camper(); pins.push({ x: s.cx, y: s.cy, kind: 'to', label: 'Camper lot' }); box = { x: s.cx - 60, y: s.cy - 60, w: 120, h: 120 }; }
        } else if (t.kind === 'spot') {
          const s = A.c.spots.find(x => x.id === t.id); if (s) { pins.push({ x: s.cx, y: s.cy, kind: 'to', label: endName(t) }); box = { x: s.cx - 60, y: s.cy - 60, w: 120, h: 120 }; }
        }
      }
      // Where I sleep: a bed on my hall, its name always shown (polish 2: Reed drawn like every other hall).
      const sh = stayHall() && M.find(A.c, stayHall());
      if (sh && !(target && (target.kind === 'stay' || (target.kind === 'hall' && M.norm(target.name) === M.norm(sh.name)))) && !(n.from && n.from.kind === 'stay' && n.route)) pins.push({ x: sh.lx, y: sh.ly, kind: 'stay', of: sh.name, label: shorts[sh.name] || M.shortOf(sh) });
      if (n.route && n.from && n.from.kind !== 'me') { const a = n.route.pts[0]; pins.push({ x: a.x, y: a.y, kind: 'from', of: n.from.kind === 'place' || n.from.kind === 'hall' ? endBuilding(n.from) : '', label: endShort(n.from) }); }
      else if (n.from && n.from.kind === 'pt') pins.push({ x: n.from.x, y: n.from.y, kind: 'from', label: 'Start' });
      m.pins(pins);
      m.select(sel, green);
      // What covers the map: the search bar (both layouts) and the sheet (a phone); fits and names keep clear.
      if (!A.go) m.inset({ top: topInset(), bottom: A.mode === 'full' ? A.sheetH : 0 });
      if (!fit || A.go) return;
      // The whole walk in view with where it starts and ends named, and never under about 220 m across
      // (polish 3: a 100 ft walk zoomed in until Barnes filled the map and nothing around was named).
      if (n.route) {
        const ends = [endBuilding(n.from), endBuilding(n.to)].map(b => b && M.find(A.c, b)).filter(Boolean);
        const xs = n.route.pts.map(p => p.x).concat(ends.map(b => b.lx)), ys = n.route.pts.map(p => p.y).concat(ends.map(b => b.ly));
        const x0 = Math.min.apply(null, xs), y0 = Math.min.apply(null, ys), x1 = Math.max.apply(null, xs), y1 = Math.max.apply(null, ys), mx = (x0 + x1) / 2, my = (y0 + y1) / 2;
        const w = Math.max(220, x1 - x0 + 40), h = Math.max(160, y1 - y0 + 40);
        m.fit({ x: mx - w / 2, y: my - h / 2, w, h }, 24, true);
      } else if (box) m.fit(roomy(box, A.mode === 'full' ? .45 : .35), 20, true);
    }

    /* ------------------------------------------------ the views in the sheet or panel */

    const x = '<button type="button" class="pm-x" data-pm="close" aria-label="Close">' + I.close + '</button>';
    // Nothing chosen: the usual trips, one tap each; on a laptop, what's still on today beside the map
    // (polish 1: the panel was one chip over blank space).
    function browseView() {
      const chips = quickChips('to', true);
      const status = A.nav.status && A.nav.status !== 'Locating' ? '<p class="pm-status" data-peek>' + I.locate + esc(A.nav.status) + (A.nav.status === 'Not on campus' || A.nav.status === 'Approximate location' ? ' · <button type="button" class="pm-link" data-pm="pick" data-which="from">Choose start</button>' : '') + '</p>' : '';
      const still = A.mode === 'embed' ? stillToday(null, null, true) : '';
      return (chips ? '<div class="pm-quick" data-peek>' + chips + '</div>' : '') + status + (still ? '<div class="pm-card">' + still + '</div>' : '') + mockPill();
    }
    // A place: its name and code, how to find it, what's inside, what's still on, and Directions.
    function placeView(pl) {
      if (pl.kind === 'spot') {
        const s = A.c.spots.find(z => z.id === pl.id);
        if (!s) return '';
        return '<div class="pm-card pm-placecard"><div data-peek>' + x + '<p class="pm-k">' + esc(M.SPOT[s.spot] || 'Place') + '</p><h2 class="pm-h">' + esc(s.name || M.SPOT[s.spot]) + '</h2>' + (s.note ? '<p class="pm-line">' + I.pin + '<span>' + esc(s.note) + '</span></p>' : '') +
          '<p class="pm-btns"><button type="button" class="pm-btn" data-pm="go" data-spot="' + esc(s.id) + '">' + I.dirs + 'Directions</button></p></div></div>';
      }
      if (pl.kind === 'hall') {
        return '<div class="pm-card pm-placecard"><div data-peek>' + x + '<p class="pm-k">' + ((M.find(A.c, pl.name) || {}).kind === 'hall' ? 'Hall' : 'Building') + '</p><h2 class="pm-h">' + esc(pl.name) + '</h2>' + (stayHall() === pl.name ? '<p class="pm-sub">' + esc(endSub({ kind: 'stay' })) + '</p>' : '') +
          '<p class="pm-btns"><button type="button" class="pm-btn" data-pm="go" data-hall="' + esc(pl.name) + '">' + I.dirs + 'Directions</button></p></div></div>';
      }
      const p = P(pl.code); if (!p) return '';
      const g = groups().find(z => z.key === keyOf(p.code)), main = g && g.main, isMain = main && main.code === p.code && !g.derived;
      const w = where(p), line = M.placeLine(A.c, p, places(), w.kind === 'pin' && w.b ? M.nearestDoor(A.c, w.b.name, w) : null);
      const sub = [isMain ? '' : (w.b ? bShort(w.b) : g ? g.name : ''), isMain || !w.b ? '' : roomRest(p, w.b.name), line].filter(Boolean).join(' · ');
      const room = String(p.code).indexOf('/') > -1 && w.kind === 'building';
      // What the map is missing is said to members (the pins tool's people), never to the public (polish 2).
      const not = !member(A.ctx.year) ? '' : w.kind === 'outdoor' ? 'Outdoor · Not on the map yet' : w.kind === 'none' ? 'Not on the map yet' : room ? 'Room not on the map yet' : '';
      const rooms = isMain && g.rooms.length ? '<ul class="pm-rooms">' + g.rooms.map(r => roomRow(r, main.name, true)).join('') + '</ul>' : '';
      return '<div class="pm-card pm-placecard"><div data-peek>' + x + '<h2 class="pm-h" aria-label="' + esc(p.name + ', ' + p.code) + '">' + esc(roomName(p)) + ' <span class="pm-code" aria-hidden="true">' + esc(p.code) + '</span></h2>' +
        (sub ? '<p class="pm-sub">' + esc(sub) + '</p>' : '') + (not ? '<p class="pm-line">' + I.pin + '<span>' + esc(not) + '</span></p>' : '') +
        (routable(p) ? '<p class="pm-btns"><button type="button" class="pm-btn" data-pm="go" data-code="' + esc(p.code) + '">' + I.dirs + 'Directions</button></p>' : '') + '</div>' +
        stillToday(isMain ? g.key : null, p.code) + rooms + '</div>';
    }
    // One row style for a room everywhere (the place card, the cards, the picker).
    const roomRow = (r, bname, small) => '<li><button type="button" class="pm-row" data-pm="room" data-code="' + esc(r.code) + '"><span>' + esc(inBuilding(r, bname)) + (small && (r.floor || r.inside) ? '<small>' + esc(M.placeLine(A.c, r, places())) + '</small>' : '') + '</span><code>' + esc(r.code) + '</code></button></li>';
    // What's still on today in a building (or at one room, or everywhere: all), as Today says it:
    // the timed rows first ("Now", then by time), then the places open all day, "Open · until 11 PM"
    // or "Closed · reopens 12:00 PM" (polish 1: Places said open while Today said closed during
    // services). One grid, so every title lines up; each row one 44 px button.
    function stillToday(key, code, all) {
      const rows = today().filter(it => it.code && (all || (key ? keyOf(it.code) === key : String(it.code).toUpperCase() === String(code).toUpperCase())) && it.state !== 'past');
      if (!rows.length) return '';
      const timed = rows.filter(it => !it.allDay).sort((a, b) => (b.state === 'now') - (a.state === 'now') || (a.start == null ? 1e9 : a.start) - (b.start == null ? 1e9 : b.start));
      const open = rows.filter(it => it.allDay && (it.state === 'now' || it.closed));
      const cap = all && A.allToday ? Infinity : all ? 6 : 5, list = timed.slice(0, cap).concat(open.slice(0, Math.max(0, cap - timed.length)));
      const more = rows.length - list.length;
      const at = it => all && P(it.code) ? ' · ' + (shorts[(where(P(it.code)).b || {}).name] || M.shortOf(where(P(it.code)).b) || P(it.code).name) : '';
      const row = it => {
        const k = it.allDay ? (it.closed ? 'Closed' : 'Open') : it.state === 'now' ? 'Now' : it.start != null ? clock(it.start) : it.startText || '';
        const tail = it.allDay ? (it.closed ? 'reopens ' + clock(it.closed.end) : it.end != null ? 'until ' + clock(it.end) : '') : it.state === 'now' && it.end != null ? 'until ' + clock(it.end) : '';
        const inner = '<span class="pm-ev__k">' + esc(k) + '</span><span class="pm-ev__t">' + esc(it.title) + (tail || at(it) ? '<small>' + esc((tail ? ' · ' + tail : '') + at(it)) + '</small>' : '') + '</span>';
        return '<li class="' + (it.state === 'now' && !it.closed ? 'is-now' : it.closed ? 'is-closed' : '') + '">' + (it.id ? '<button type="button" class="pm-ev" data-pm="event" data-id="' + esc(it.id) + '">' + inner + '</button>' : '<div class="pm-ev">' + inner + '</div>') + '</li>';
      };
      return '<div class="pm-today"><p class="pm-k">Still today</p><ul>' + list.map(row).join('') + (more > 0 ? '<li class="pm-today__more">' + (all ? '<button type="button" class="pm-link" data-pm="more-today">' + more + ' more</button>' : more + ' more') + '</li>' : '') + '</ul></div>';
    }
    // From and To, the answer, Start, the steps. On a phone at peek, the route is one line with its
    // answer (polish 1: From/To and the answer filled the peek); From and To show from half up.
    function dirView() {
      const n = A.nav, r = n.route;
      const field = (k, empty) => {
        const e = n[k], sub = endSub(e), code = endCode(e);
        return '<div class="pm-fw' + (A.drop === k ? ' is-open' : '') + '"><button type="button" class="pm-f" data-pm="pick" data-which="' + k + '" aria-expanded="' + (A.drop === k) + '"><span>' + (k === 'from' ? 'From' : 'To') + '</span><span><span class="pm-f__n"><b' + (e ? '' : ' class="is-empty"') + '>' + esc(e ? endName(e) : empty) + '</b>' + (code ? '<code>' + esc(code) + '</code>' : '') + '</span>' + (sub ? '<small>' + esc(sub) + '</small>' : '') + '</span>' +
          (k === 'to' && e ? '<span class="pm-clear" data-pm="clear" role="button" aria-label="Clear destination" title="Clear destination">' + I.close + '</span>' : '<span></span>') + '</button>' +
          (A.drop === k ? '<div class="pm-drop">' + pickBody(k) + '</div>' : '') + '</div>';
      };
      const dir = '<div class="pm-dir"' + (r ? '' : ' data-peek') + '>' + field('from', 'Choose start') + field('to', 'Choose destination') + '<button type="button" class="pm-swap" data-pm="swap" aria-label="Swap" title="Swap">' + I.swap + '</button></div>';
      const pointing = A.pointing ? '<p class="pm-status" data-peek>' + I.tap + 'Tap your start on the map · <button type="button" class="pm-link" data-pm="unpoint">Cancel</button></p>' : '';
      let ans = '';
      if (r) {
        const mins = M.minutes(r.d, A.stepFree), at = now().minutes + mins, ev = arrivingFor();
        // Start is for walking with a phone; a laptop has the steps (polish 1).
        const start = coarse() ? '<button type="button" class="pm-btn" data-pm="start">' + I.dirs + 'Start</button>' : '';
        ans = '<div class="pm-card pm-answer" data-peek><button type="button" class="pm-ends" data-pm="more" aria-label="' + esc(endName(n.from) + ' to ' + endName(n.to)) + '"><span>' + esc(endShort(n.from)) + '</span><span aria-hidden="true">→</span><span>' + esc(endShort(n.to)) + '</span></button>' +
          '<div class="pm-sum"><p><b>' + mins + ' min</b> · ' + esc(M.feet(r.d)) + '<br>Arrive ' + esc(clock(at)) + (ev ? ' · ' + esc(ev.title) + ' ' + esc(clock(ev.start)) : '') + '</p>' + start + '</div>' + options(mins) + '</div>' +
          '<div class="pm-card"><p class="pm-k">Steps</p><ol class="pm-steps">' + r.legs.map((l, i) => '<li><button type="button" class="pm-step" data-pm="leg" data-i="' + i + '">' + (I[l.icon] || I.straight) + '<span>' + esc(l.text) + (l.sub ? '<small>' + esc(l.sub) + '</small>' : '') + '</span><span>' + (l.d ? esc(M.feet(l.d)) : '') + '</span></button></li>').join('') + '</ol></div>';
      } else if (n.inside) {
        const p = n.to.kind === 'place' ? P(n.to.code) : null, line = p ? M.placeLine(A.c, { floor: p.floor, inside: p.inside }, places()) : '';
        ans = '<div class="pm-card pm-answer" data-peek><p class="pm-here"><b>Same building</b>' + (line ? ' · ' + esc(line) : '') + '</p></div>';
      } else if (n.from && n.to) ans = '<p class="pm-status" data-peek>No route</p>';
      const status = n.status && n.status !== 'Locating' && (!n.from || n.from.kind === 'me') ? '<p class="pm-status">' + I.locate + esc(n.status) + (n.status === 'Not on campus' || n.status === 'Approximate location' ? ' · <button type="button" class="pm-link" data-pm="pick" data-which="from">Choose start</button>' : '') + '</p>' : '';
      return pointing + dir + status + ans + mockPill();
    }
    // Arriving for the next thing at that place, within the hour: "Arrive 2:27 · Worship 2:30".
    function arrivingFor() {
      const t = A.nav.to; if (!t || t.kind !== 'place') return null;
      const m = now().minutes;
      return today().filter(it => it.code && !it.allDay && keyOf(it.code) === keyOf(t.code) && it.state === 'upcoming' && it.start != null && it.start >= m && it.start - m <= 60).sort((a, b) => a.start - b.start)[0] || null;
    }
    // Step-free, once the campus says where steps and step-free doors are (never a switch that does nothing);
    // a ride, when Help has a ride line and the walk is long or step-free is on, in Help's own words with
    // its number ("Call for a ride · 937-…"). Polish 3: the ride line is found by its need (or kind ride),
    // never in a card's text: First Aid's says "by golf cart", and its number was offered for a ride.
    const rideLine = () => { const hs = (A.ctx.help || []).filter(h => h.phone && h.kind !== 'emergency' && !/aid|medic|nurse|emergenc|doctor/i.test(h.need)); return hs.find(h => h.kind === 'ride') || hs.find(h => /\b(rides?|carts?)\b/i.test(h.need)) || null; };
    function options(mins) {
      const ride = rideLine();
      const sf = A.R.hasSteps ? '<label class="pm-tog" title="Avoids steps and uses step-free doors; times at a slower pace"><input type="checkbox" data-pm="stepfree"' + (A.stepFree ? ' checked' : '') + '>Step-free</label>' : '';
      const cart = ride && (mins > 5 || A.stepFree) ? '<a class="pm-link pm-call" href="' + esc(O.telHref ? O.telHref(ride.phone) : 'tel:' + ride.phone) + '" title="' + esc(ride.need) + '">' + I.phone + esc((ride.action || 'Call for a ride') + ' · ' + ride.phone) + '</a>' : '';
      return sf || cart ? '<div class="pm-opts">' + sf + cart + '</div>' : '';
    }
    // Every building, what's in it and what's still on: the chosen one first, then what's on now, then next.
    function cardsView() {
      const gs = groups(), sel = A.place && A.place.code ? keyOf(A.place.code) : '';
      const first = g => { const rows = today().filter(it => it.code && keyOf(it.code) === g.key && it.state !== 'past' && !it.allDay); const nowOn = rows.some(it => it.state === 'now'); const nx = rows.filter(it => it.start != null).map(it => it.start).sort((a, b) => a - b)[0]; return [g.key === sel ? 0 : 1, nowOn ? 0 : 1, nx == null ? 1e9 : nx]; };
      const order = gs.map((g, i) => ({ g, i, k: first(g) })).sort((a, b) => a.k[0] - b.k[0] || a.k[1] - b.k[1] || a.k[2] - b.k[2] || a.i - b.i).map(z => z.g);
      // Polish 2: the whole head is one 44 px row that opens the place (its sheet has Directions, filled);
      // the cards carry no Directions of their own (six or more on the full sheet before).
      const head = (attrs, name, code) => '<button type="button" class="pm-cardhead" ' + attrs + '><h3 class="pm-h">' + esc(name) + '</h3>' + (code ? '<span class="pm-code">' + esc(code) + '</span>' : '') + I.next + '</button>';
      const card = g => {
        const w = where(g.main), not = !member(A.ctx.year) ? '' : w.kind === 'outdoor' ? 'Outdoor · Not on the map yet' : w.kind === 'none' ? 'Not on the map yet' : '';
        const rooms = (g.derived ? g.all : g.rooms);
        const list = rooms.length ? '<ul class="pm-rooms">' + rooms.map(r => roomRow(r, g.name)).join('') + '</ul>' : '';
        return '<section class="pm-card' + (g.key === sel ? ' is-sel' : '') + '" aria-label="' + esc(g.name) + '">' + (g.derived ? '<div class="pm-cardhead"><h3 class="pm-h">' + esc(g.name) + '</h3><span class="pm-code">' + esc(g.key) + '</span></div>' : head('data-pm="room" data-code="' + esc(g.main.code) + '"', g.name, g.main.code)) +
          (not ? '<p class="pm-quiet">' + esc(not) + '</p>' : '') + stillToday(g.key) + list + '</section>';
      };
      const spots = A.c.spots.map(s => '<section class="pm-card">' + head('data-pm="spot" data-id="' + esc(s.id) + '"', s.name || M.SPOT[s.spot], '') + (s.note ? '<p class="pm-quiet">' + esc(s.note) + '</p>' : '') + '</section>').join('');
      return (A.mode === 'full' ? '<p class="pm-k">Buildings</p>' : '') + order.map(card).join('') + spots;
    }
    // The usual trips, one tap each. A start: My location, My room, a point on the map (never Next,
    // never the destination itself). A destination: My room, Next, the places Help points to.
    function quickChips(which, browse) {
      const out = [], se = stayEnd(), to = A.nav.to;
      const chip = (attrs, icon, title, sub, dis) => '<button type="button" class="pm-chip" ' + attrs + (dis ? ' disabled' : '') + '>' + icon + '<span><b>' + esc(title) + '</b>' + (sub ? '<small>' + esc(sub) + '</small>' : '') + '</span></button>';
      if (which === 'from' && touch()) {
        const off = A.perm === 'denied' || A.nav.status === 'Not on campus';
        out.push(chip('data-pm="set" data-which="from" data-v="me"', I.locate, 'My location', A.perm === 'denied' ? 'Location off' : A.nav.status === 'Not on campus' ? 'Not on campus' : '', off));
      }
      if (se && !(which === 'from' && same(se, to))) out.push(chip('data-pm="set" data-which="' + which + '" data-v="stay"', I.bed, endName(se), endSub(se)));
      if (which === 'from') out.push(chip('data-pm="point"', I.tap, 'Point on map', ''));
      const nx = which === 'from' ? null : nextEvent();
      if (nx) out.push(chip('data-pm="set" data-which="' + which + '" data-v="' + esc(nx.code) + '" data-et="' + esc(nx.title) + '" data-es="' + esc(nx.start == null ? '' : nx.start) + '" aria-label="Next: ' + esc(nx.title) + '"', I.clock, nx.title, 'Next' + (nx.start != null ? ' · ' + clock(nx.start) : '')));
      if (which !== 'from') out.push(helpChips(which, browse, 3));
      return out.join('');
    }
    // The places Help names (First Aid, the Lodging Desk…), in Help's order, one tap each.
    function helpChips(which, browse, max) {
      const chip = (attrs, icon, title) => '<button type="button" class="pm-chip" ' + attrs + '>' + icon + '<span><b>' + esc(title) + '</b></span></button>';
      return (A.ctx.help || []).filter(h => h.place && P(h.place) && routable(P(h.place))).slice(0, max || 99).map(h => chip('data-pm="' + (browse ? 'room' : 'set') + '" data-which="' + which + '" data-v="' + esc(h.place) + '" data-code="' + esc(h.place) + '"', /aid|medic|nurse/i.test(h.need) ? I.cross : /lodg|room|key/i.test(h.need) ? I.bed : /lost|found/i.test(h.need) ? I.search : '<span class="pm-i" aria-hidden="true"></span>', h.need)).join('');
    }
    function mockPill() {
      if (!(window.OGC_WP && OGC_WP.dev)) return '';
      return A.nav.me && !A.nav.mock ? '' : '<p class="pm-mock"><button type="button" class="ogc-mock" data-pm="mock">Mockup: on campus</button></p>';
    }

    /* ------------------------------------------------ the sheet's heights (phone) */

    // Peek: just what's marked data-peek (the usual trips, or the route's one line and answer), so the
    // map keeps well over half the screen; half: 60% (From, To and the steps); full: nearly all.
    function heights() {
      const box = A.el.getBoundingClientRect().height || innerHeight * .7;
      const body = A.el.querySelector('.pm-body');
      const els = body ? Array.from(body.querySelectorAll('[data-peek]')) : [];
      let peek = 170;
      if (els.length) { peek = 44 + 14; els.forEach(e => { peek += e.getBoundingClientRect().height + 12; }); }
      peek = Math.round(Math.max(120, Math.min(peek, 250, box * .45)));
      return { peek, half: Math.max(peek + 80, Math.round(box * .6)), full: Math.round(box - 8) };
    }
    function setSheet(snap, ease) {
      if (A.mode !== 'full') return;
      A.snap = snap;
      const s = A.el.querySelector('.pm-sheet');
      s.classList.toggle('is-peek', snap === 'peek');
      const H = heights(), h = Math.max(H.peek, H[snap] || H.peek);
      s.classList.toggle('is-settling', !!ease);
      A.sheetH = h; A.el.style.setProperty('--pm-sheet', h + 'px');
      s.querySelector('.pm-grab').setAttribute('aria-label', snap === 'full' ? 'Less' : 'More');
      if (A.map && !A.go) A.map.inset({ top: topInset(), bottom: h });
    }
    function sheetDrag() {
      const s = A.el.querySelector('.pm-sheet'), g = s.querySelector('.pm-grab');
      let y0 = null, h0 = 0, moved = 0;
      g.addEventListener('pointerdown', e => { y0 = e.clientY; h0 = A.sheetH; moved = 0; g.setPointerCapture(e.pointerId); s.classList.remove('is-settling'); });
      g.addEventListener('pointermove', e => { if (y0 == null) return; const d = y0 - e.clientY; moved = Math.max(moved, Math.abs(d)); const H = heights(); const h = Math.max(H.peek, Math.min(H.full, h0 + d)); A.sheetH = h; A.el.style.setProperty('--pm-sheet', h + 'px'); s.classList.toggle('is-peek', h < (H.peek + H.half) / 2); });
      const end = () => {
        if (y0 == null) return; y0 = null;
        const H = heights(), order = ['peek', 'half', 'full'];
        if (moved < 6) { setSheet(order[(order.indexOf(A.snap) + 1) % 3], true); return; }
        const near = order.reduce((m, k) => Math.abs(H[k] - A.sheetH) < Math.abs(H[m] - A.sheetH) ? k : m, 'peek');
        setSheet(near, true);
      };
      g.addEventListener('pointerup', end); g.addEventListener('pointercancel', end);
    }

    /* ------------------------------------------------ acting */

    function openBuilding(name) {
      const g = groups().find(z => { const w = where(z.main); return w.b && w.b.name === name; });
      if (g) return focus(g.derived ? g.main.code : g.main.code);
      // Any other building on the map (polish 3: a hall not confirmed is a building like the rest for the public).
      if (A.c.items.some(i => i.lab && i.name === name && i.name !== 'Building' && i.short !== '-')) { A.place = { kind: 'hall', name }; A.nav.to = null; settle('half'); paint(true); say(name); }
    }
    function openSpot(id) { A.place = { kind: 'spot', id }; A.nav.to = null; settle('half'); paint(true); say(endName({ kind: 'spot', id })); }
    // A place on the map, its sheet open: what a schedule row's place, a card's name or a tap leads to.
    function focus(code) {
      const p = P(code); if (!p) return;
      A.place = { code: p.code }; A.nav.to = null; A.nav.route = null; A.drop = null; A.dir = false;
      settle('half');
      if (!A.map) { const w = where(p); A.pendingFocus = w.b ? roomy(M.boxOf(A.c, [w.b.name], 10), A.mode === 'full' ? .45 : .35) : w.kind === 'pin' ? { x: w.x - 60, y: w.y - 60, w: 120, h: 120 } : null; }
      paint(true);
      say(p.name);
    }
    // Directions to a place. With no start known (or the start would be the place itself), the start's
    // chooser opens at once, while the map frames where it's going.
    function directions(to) {
      const n = A.nav;
      n.to = to; A.place = null; A.drop = null; A.dir = true;
      if (!n.from || (n.from.kind === 'me' && !n.me) || same(n.from, to)) n.from = defaultFrom();
      routeNow();
      settle(n.route ? 'peek' : 'half');
      paint(true);
      if (n.route) announce(); else if (!n.from) setTimeout(() => picker('from'), 60);
      remember(to);
    }
    function announce() { const r = A.nav.route; if (r) say(M.minutes(r.d, A.stepFree) + ' min, ' + M.feet(r.d) + ', to ' + endName(A.nav.to)); }
    function settle(snap) { A.snap = snap; }
    const say = t => { if (A.ctx && A.ctx.say) A.ctx.say(t); };
    function remember(e) {
      if (!e || e.kind !== 'place') return;
      const r = LS.get('ogc-map-recent', []).filter(c => c !== e.code); r.unshift(e.code); LS.set('ogc-map-recent', r.slice(0, 4));
    }
    function endFrom(v) {
      if (v === 'me') return { kind: 'me' };
      if (v === 'stay') return { kind: 'stay' };
      if (v.indexOf('hall:') === 0) return { kind: 'hall', name: v.slice(5) };
      if (v.indexOf('spot:') === 0) return { kind: 'spot', id: v.slice(5) };
      const p = P(v); return p ? { kind: 'place', code: p.code, name: p.name } : null;
    }
    // Point on map: the next tap on the map is the start.
    function setPoint(pt) {
      A.pointing = null;
      A.nav.from = { kind: 'pt', x: pt.x, y: pt.y };
      routeNow(); settle(A.nav.route ? 'peek' : 'half'); paint(true);
      if (A.nav.route) announce(); else say('From ' + (endSub(A.nav.from) || 'Point on map'));
    }

    /* ------------------------------------------------ choosing a start, a destination, or searching */

    // Everything that can be chosen, for typing: buildings, rooms, halls, lots and the like, Help's
    // places, and every row of the schedule ("Volleyball" finds its field, mapped or not).
    function candidates(which) {
      const out = [], to = A.nav.to, skip = e => which === 'from' && same(e, to);
      groups().forEach(g => {
        const b = where(g.main).b, words = b ? [b.name, b.short].concat(b.aliases, KIND_WORDS[b.kind] || []).join(' ') : '';
        if (!g.derived) { const e = { kind: 'place', code: g.main.code }; if (!skip(e)) out.push({ v: g.main.code, main: g.name, sub: '', code: g.main.code, ok: routable(g.main), kind: 0, words }); }
        (g.derived ? g.all : g.rooms).forEach(r => { if (!skip({ kind: 'place', code: r.code })) out.push({ v: r.code, main: inBuilding(r, g.name), sub: g.name, code: r.code, ok: routable(r), kind: 1 }); });
      });
      A.c.items.filter(i => i.kind === 'hall' && i.lab && i.name !== 'Building').forEach(h => { if (!skip({ kind: 'hall', name: h.name })) out.push({ v: 'hall:' + h.name, main: h.name, sub: /\bhall\b/i.test(h.name) ? '' : 'Hall', code: '', ok: true, kind: 2, words: h.aliases.join(' ') + ' hall dorm residence' }); });
      // Every other named building, for typing ("Reed" finds Reed Hall whether or not it's a hall here).
      const listed = new Set(out.map(c => c.main));
      A.c.items.filter(i => i.kind !== 'hall' && i.lab && i.name && i.name !== 'Building' && i.short !== '-' && i.pts.length > 2 && /^(other|dining|worship|venue)$/.test(i.kind) && !groups().some(g => where(g.main).b === i) && !listed.has(i.name)).forEach(b => { if (!skip({ kind: 'hall', name: b.name })) out.push({ v: 'hall:' + b.name, main: b.name, sub: '', code: '', ok: true, kind: 2, words: (b.short || '') + ' ' + b.aliases.join(' ') }); });
      A.c.spots.forEach(s => { if (!skip({ kind: 'spot', id: s.id })) out.push({ v: 'spot:' + s.id, main: s.name || M.SPOT[s.spot], sub: s.name ? M.SPOT[s.spot] : '', code: '', ok: true, kind: 2, words: (M.SPOT[s.spot] || '') + ' ' + (SPOT_WORDS[s.spot] || '') + ' ' + (s.note || '') }); });
      (A.ctx.help || []).filter(h => h.place && P(h.place)).forEach(h => out.push({ v: P(h.place).code, main: h.need, sub: P(h.place).name, code: P(h.place).code, ok: routable(P(h.place)), kind: 1, words: h.text || '' }));
      (A.ctx.events ? A.ctx.events() : []).filter(e => e.code).forEach(e => { const p = P(e.code); out.push({ v: p ? p.code : '', main: e.title, sub: [e.when, p ? p.name : ''].filter(Boolean).join(' · '), code: p ? p.code : '', ok: !!p && routable(p), kind: 3, et: e.title, es: e.start == null ? '' : e.start }); });
      // (Help's places and the schedule's rows too: never a start in the destination's building.)
      return out.filter(c => !(which === 'from' && c.v && skip(endFrom(c.v))));
    }
    // Best first: the name itself, then names starting with it, then a word starting with it, then
    // anywhere in the name, then the code, then the line under it (polish 1: "first aid" put Barnes
    // above the First Aid Room).
    // Polish 2: also the words a place goes by ("dining", "cafeteria", "food" find Barnes; "parking",
    // "info" find the lots and the desk), what people say for what the campus calls it ("bathroom" is a
    // restroom), and a one-letter slip in a word of five letters or more ("barns"; places only: "parking"
    // isn't "Kit packing").
    function ranked(list, t) {
      const T = t.toUpperCase(), alts = [t].concat(SYN[t] || []);
      const words = s => String(s || '').toLowerCase().split(/[\s(/·,&-]+/).filter(Boolean);
      const slip = (w, q) => { if (q.length < 5 || Math.abs(w.length - q.length) > 1) return false; let i = 0, j = 0, e = 0; while (i < w.length && j < q.length) { if (w[i] === q[j]) { i++; j++; continue; } if (++e > 1) return false; if (w.length > q.length) i++; else if (q.length > w.length) j++; else { i++; j++; } } return e + (w.length - i) + (q.length - j) <= 1; };
      const one = (c, t) => { const n = c.main.toLowerCase(); if (n === t || c.code === T) return 0; if (n.indexOf(t) === 0) return 1; if (words(n).some(w => w.indexOf(t) === 0)) return 2; if (n.indexOf(t) > -1) return 3; if (c.code && c.code.indexOf(T) === 0) return 3.5; if (words(c.words).some(w => w.indexOf(t) === 0)) return 4; if (c.sub.toLowerCase().indexOf(t) > -1) return 5; if (c.kind !== 3 && words(n + ' ' + (c.words || '')).some(w => slip(w, t))) return 6; return Infinity; };
      const score = c => Math.min.apply(null, alts.map((a, i) => one(c, a) + (i ? .5 : 0)));
      const seen = new Set();
      return list.map(c => Object.assign({ s: score(c) }, c)).filter(c => c.s < Infinity).sort((a, b) => a.s - b.s || a.kind - b.kind || a.main.length - b.main.length)
        .filter(c => { const k = c.v + '|' + c.main; if (seen.has(k)) return false; seen.add(k); return true; }).slice(0, 40);
    }
    const resultRow = (which, c) => { const miss = !c.ok && member(A.ctx.year) ? 'Not on the map yet' : ''; return '<li><button type="button" data-pm="set" data-which="' + which + '" data-v="' + esc(c.v) + '"' + (c.et ? ' data-et="' + esc(c.et) + '" data-es="' + esc(c.es) + '"' : '') + (c.ok || (which === 'search' && c.v) ? '' : ' disabled') + '><span><b>' + esc(c.main) + '</b>' + (c.sub || miss ? '<small>' + esc([c.sub, miss].filter(Boolean).join(' · ')) + '</small>' : '') + '</span>' + (c.code ? '<code>' + esc(c.code) + '</code>' : '') + '</button></li>'; };
    // The chooser's body (the dialog's on a phone; a drop-down under the field on a laptop).
    function pickBody(which) {
      const to = A.nav.to;
      const recent = LS.get('ogc-map-recent', []).map(P).filter(Boolean).filter(p => routable(p) && !(which === 'from' && same({ kind: 'place', code: p.code }, to)));
      const gs = groups().filter(g => where(g.main).kind !== 'none');
      const halls = A.c.items.filter(i => i.kind === 'hall' && i.lab && i.name !== 'Building' && !gs.some(g => where(g.main).b === i) && !(which === 'from' && same({ kind: 'hall', name: i.name }, to)));
      const li = (v, main, sub, code) => '<li><button type="button" data-pm="set" data-which="' + which + '" data-v="' + esc(v) + '"><span><b>' + esc(main) + '</b>' + (sub ? '<small>' + esc(sub) + '</small>' : '') + '</span>' + (code ? '<code>' + esc(code) + '</code>' : '') + '</button></li>';
      const locNote = which === 'from' && touch() && A.perm !== 'granted' && A.perm !== 'denied' && !LS.get('ogc-map-locnote', false);
      if (locNote) LS.set('ogc-map-locnote', true);
      const chips = which === 'search' ? quickChips('search') : quickChips(which);
      const ph = which === 'search' || A.mode === 'embed' ? 'Building, room, code or event' : which === 'from' ? 'Choose start' : 'Choose destination';
      // Polish 3: one Clear inside the field (WebKit's own blue × sat beside the sheet's ×), and Choose start
      // says where it's for ("To · My room"); halls first for someone not signed in (where most start).
      const forTo = which === 'from' && to && A.mode !== 'embed' ? '<p class="pm-pickto"><span>To</span> <b>' + esc(endName(to)) + '</b></p>' : '';
      const hallsFirst = which === 'from' && !(window.OGC_WP && OGC_WP.me);
      const hallList = halls.length ? '<li data-sec><p class="pm-k">Halls</p></li>' + halls.map(h => li('hall:' + h.name, h.name, '', '')).join('') : '';
      return forTo + '<label class="pm-q"><span class="ogc-sr">' + (which === 'search' ? 'Search' : which === 'from' ? 'Search for a start' : 'Search for a destination') + '</span><input type="search" data-pmq data-which="' + which + '" placeholder="' + ph + '" autocomplete="off" enterkeyhint="search"><button type="button" class="pm-qx" data-pm="qx" aria-label="Clear" title="Clear" hidden>' + I.close + '</button></label><div class="pm-pickbody">' +
        (chips ? '<div class="pm-quick" data-quick>' + chips + '</div>' : '') +
        (locNote ? '<p class="pm-help" data-quick>Location stays on this device</p>' : '') +
        '<ul class="pm-list" data-results hidden></ul><div data-none hidden><p class="pm-none">No results</p>' + (which !== 'from' && helpChips(which, which === 'search') ? '<div class="pm-quick">' + helpChips(which, which === 'search') + '</div>' : '') + '</div>' +
        '<ul class="pm-list" data-list>' +
        (recent.length ? '<li data-sec><p class="pm-k">Recent</p></li>' + recent.map(p => li(p.code, roomName(p), String(p.code).indexOf('/') > -1 ? bShort(where(p).b) : '', p.code)).join('') : '') + (hallsFirst ? hallList : '') +
        '<li data-sec><p class="pm-k">Buildings</p></li>' +
        gs.map(g => {
          const self = !g.derived && !(which === 'from' && same({ kind: 'place', code: g.main.code }, to));
          // A place the map can't walk to isn't offered as an end to the public (a grey row with no reason).
          const head = g.derived ? '<p class="pm-list__h">' + esc(g.name) + '</p>' : self ? (routable(g.main) || which === 'search' ? li(g.main.code, g.name, '', g.main.code) : !member(A.ctx.year) ? '' : '<li><button type="button" disabled><span><b>' + esc(g.name) + '</b>' + (member(A.ctx.year) ? '<small>' + (where(g.main).kind === 'outdoor' ? 'Outdoor · Not on the map yet' : 'Not on the map yet') + '</small>' : '') + '</span><code>' + esc(g.main.code) + '</code></button></li>') : '';
          const rooms = (g.derived ? g.all : g.rooms).filter(r => (routable(r) || which === 'search') && !(which === 'from' && same({ kind: 'place', code: r.code }, to)));
          // The destination's own building (and its rooms) isn't a start (polish 2).
          if (!rooms.length && (g.derived || !head)) return '';
          return '<li class="pm-list__g"><ul>' + head + rooms.map(r => '<li class="pm-list__r">' + li(r.code, inBuilding(r, g.name), '', r.code).slice(4)).join('') + '</ul></li>';
        }).join('') +
        (hallsFirst ? '' : hallList) +
        (A.c.spots.length ? '<li data-sec><p class="pm-k">Parking and services</p></li>' + A.c.spots.filter(s => !(which === 'from' && same({ kind: 'spot', id: s.id }, to))).map(s => li('spot:' + s.id, s.name || M.SPOT[s.spot], s.name ? M.SPOT[s.spot] : '', '')).join('') : '') +
        '</ul></div>';
    }
    // Search opens full height with the field at the top, focused even on a phone (polish 1: a short
    // sheet with its field under the keyboard, a second tap to type). Choose start and Choose
    // destination keep the phone's keyboard down until it's wanted (the usual ones are a tap away).
    function picker(which) {
      if (A.mode === 'embed' && which !== 'search') {
        A.drop = A.drop === which ? null : which;
        if (A.drop) { A.dir = true; A.place = null; }
        paint();
        const q = A.el.querySelector('.pm-drop [data-pmq]'); if (q) q.focus();
        return;
      }
      // Polish 2: Choose start and Choose destination are laid out as Search is (full height, the field at
      // the top), so typing never moves the field down to where the keyboard is.
      dlg.classList.toggle('is-search', which === 'search');
      dlg.classList.add('is-full');
      dlg.innerHTML = '<div class="wk-sheet__in pm-pickin"><button type="button" class="wk-sheet__x" data-close aria-label="Close">' + I.close + '</button>' +
        '<h2 class="ogc-sr" id="pm-pick-t">' + (which === 'from' ? 'Choose start' : which === 'search' ? 'Search' : 'Choose destination') + '</h2>' + pickBody(which) + '</div>';
      dlg.showModal();
      const q = dlg.querySelector('[data-pmq]'); if (q && (which === 'search' || !coarse())) q.focus();
    }
    // Typing: the list becomes the ranked results; "No results" when nothing matches.
    function filter(input) {
      const box = input.closest('.pm-pickin, .pm-drop'); if (!box) return;
      const t = input.value.trim().toLowerCase(), which = input.dataset.which;
      box.querySelectorAll('[data-quick]').forEach(e => { e.hidden = !!t; });
      const qx = box.querySelector('.pm-qx'); if (qx) qx.hidden = !input.value;
      box.querySelector('[data-list]').hidden = !!t;
      const res = box.querySelector('[data-results]'), none = box.querySelector('[data-none]');
      const hits = t ? ranked(candidates(which), t) : [];
      res.innerHTML = hits.map(c => resultRow(which, c)).join('');
      res.hidden = !t || !hits.length; none.hidden = !t || !!hits.length;
    }
    function clearQ(lab) { const q = lab && lab.querySelector('[data-pmq]'); if (!q) return; q.value = ''; filter(q); q.focus(); }
    function onInput(e) { if (e.target.matches('[data-pmq]')) filter(e.target); }
    function onKey(e) {
      if (!e.target.matches('[data-pmq]')) return;
      if (e.key === 'Enter') { e.preventDefault(); const box = e.target.closest('.pm-pickin, .pm-drop'), b = box && box.querySelector('[data-results]:not([hidden]) button:not([disabled])'); if (b) b.click(); }
      else if (e.key === 'Escape' && A.drop) { e.preventDefault(); A.drop = null; paint(); }
    }
    dlg.addEventListener('input', onInput);
    dlg.addEventListener('keydown', onKey);
    // A choice: the place on the map (search), or an end of the route.
    function choose(which, b) {
      const end = endFrom(b.dataset.v);
      if (!end) return;
      if (b.dataset.et && end.kind === 'place') end.ev = { title: b.dataset.et, start: b.dataset.es };
      A.drop = null;
      if (which === 'search') { if (end.kind === 'place') focus(end.code); else if (end.kind === 'hall') { A.place = end; A.nav.to = null; settle('half'); paint(true); } else if (end.kind === 'spot') openSpot(end.id); else directions(end); return; }
      if (end.kind === 'me' && !A.nav.me) locate(() => { routeNow(); paint(true); announce(); });
      A.nav[which] = end; A.dir = true;
      if (which === 'to') { remember(end); if (same(A.nav.from, end)) A.nav.from = defaultFrom(); }
      A.place = null;
      routeNow(); settle(A.nav.route ? 'peek' : A.snap === 'peek' ? 'half' : A.snap); paint(true);
      if (A.nav.route) announce(); else if (which === 'to' && !A.nav.from) setTimeout(() => picker('from'), 60);
      else say((which === 'from' ? 'From ' : 'To ') + endName(end));
    }
    dlg.addEventListener('click', e => {
      if (e.target === dlg || e.target.closest('[data-close]')) { dlg.close(); return; }
      if (e.target.closest('[data-pm="qx"]')) { clearQ(e.target.closest('.pm-q')); return; }
      const pt = e.target.closest('[data-pm="point"]'); if (pt) { dlg.close(); startPoint(); return; }
      const b = e.target.closest('[data-pm="set"], [data-pm="room"]'); if (!b || b.disabled) return;
      dlg.close();
      if (b.dataset.pm === 'room') { focus(b.dataset.code); return; }
      choose(b.dataset.which, b);
    });
    function startPoint() {
      A.pointing = 'from'; A.drop = null; A.place = null; A.dir = true;
      settle('peek'); paint();
      if (A.map) A.map.hint('Tap your start');
    }

    function onClick(e) {
      const b = e.target.closest('[data-pm]'); if (!b || !A.el.contains(b) || b.disabled) return;
      const k = b.dataset.pm, n = A.nav;
      if (k === 'search') picker('search');
      else if (k === 'pick') picker(b.dataset.which);
      else if (k === 'qx') clearQ(b.closest('.pm-q'));
      else if (k === 'close') { A.place = null; settle('peek'); paint(); }
      else if (k === 'clear') { e.stopPropagation(); n.to = null; n.route = null; A.drop = null; A.dir = false; endWalk(); settle('peek'); paint(); say('Destination cleared'); }
      else if (k === 'swap' && (n.from || n.to)) { const f = n.from; n.from = n.to; n.to = f; routeNow(); paint(true); announce(); }
      else if (k === 'room') focus(b.dataset.code);
      else if (k === 'spot') openSpot(b.dataset.id);
      else if (k === 'more-today') { A.allToday = true; paint(); }
      else if (k === 'event') { if (A.ctx.openEvent) A.ctx.openEvent(b.dataset.id); }
      else if (k === 'set') { if (b.dataset.which && (A.drop || b.closest('.pm-drop'))) choose(b.dataset.which, b); else { const end = endFrom(b.dataset.v); if (end) { if (b.dataset.et && end.kind === 'place') end.ev = { title: b.dataset.et, start: b.dataset.es }; directions(end); } } }
      else if (k === 'go') { const end = b.dataset.spot ? { kind: 'spot', id: b.dataset.spot } : b.dataset.hall ? { kind: 'hall', name: b.dataset.hall } : endFrom(b.dataset.code); if (end) directions(end); }
      else if (k === 'point') startPoint();
      else if (k === 'unpoint') { A.pointing = null; paint(); }
      else if (k === 'more') setSheet(A.snap === 'peek' ? 'half' : A.snap, true);
      else if (k === 'start') startWalk();
      else if (k === 'leg') showLeg(+b.dataset.i);
      else if (k === 'mock') mockHere();
    }
    function onChange(e) {
      if (e.target.matches('[data-pm="stepfree"]')) { A.stepFree = e.target.checked; LS.set('ogc-map-stepfree', A.stepFree); routeNow(); paint(true); announce(); }
    }
    // A step tapped: its stretch of the walk, framed with the building it names (the sheet drops so the map shows).
    function showLeg(i) {
      const r = A.nav.route; if (!r || !r.legs[i]) return;
      if (A.mode === 'full') setSheet('peek', true);
      A.map.fit(legBox(r, r.legs[i], i === r.legs.length - 1), 30, true);
      say(r.legs[i].text);
    }
    // A stretch of the walk with the landmark it names, and (at the end) the building arrived at.
    function legBox(r, l, last) {
      const pts = r.pts.slice(l.i0, Math.max(l.i0 + 1, l.i1) + 1);
      let xs = pts.map(p => p.x), ys = pts.map(p => p.y);
      const lm = l.lmName && M.boxOf(A.c, [l.lmName], 4);
      if (lm) { xs = xs.concat([lm.x, lm.x + lm.w]); ys = ys.concat([lm.y, lm.y + lm.h]); }
      const z = last && endBuilding(A.nav.to) && M.boxOf(A.c, [endBuilding(A.nav.to)], 4);
      if (z) { xs = xs.concat([z.x, z.x + z.w]); ys = ys.concat([z.y, z.y + z.h]); }
      const x0 = Math.min.apply(null, xs), y0 = Math.min.apply(null, ys);
      // (Its points too, so a turned map fits the stretch itself, not its north-up box.)
      return { x: x0 - 10, y: y0 - 10, w: Math.max(60, Math.max.apply(null, xs) - x0 + 20), h: Math.max(60, Math.max.apply(null, ys) - y0 + 20), pts: xs.map((x, i) => [x, ys[i]]).concat([[x0 - 10, y0 - 10], [Math.max.apply(null, xs) + 10, Math.max.apply(null, ys) + 10]]) };
    }
    // A stretch's box grown to take in more points, and at least about 110 m across, so a short stretch
    // still shows what's around it (polish 2: a 60 m stretch filled the screen with lawn).
    function around(b, more) {
      const cx = b.x + b.w / 2, cy = b.y + b.h / 2;
      const pts = b.pts.concat(more, [[cx - 55, cy - 55], [cx + 55, cy + 55]]), xs = pts.map(q => q[0]), ys = pts.map(q => q[1]);
      const x0 = Math.min.apply(null, xs), y0 = Math.min.apply(null, ys);
      return { x: x0, y: y0, w: Math.max.apply(null, xs) - x0, h: Math.max.apply(null, ys) - y0, pts };
    }
    // The way a stretch goes, from its start to about 80 m along (its end if shorter): that way is up while
    // walking. The last step (Arrive) keeps the way before it.
    function legHeading(r, l) {
      if (!l || l.turn === 'Arrive') { const k = r.legs.indexOf(l); return k > 0 ? legHeading(r, r.legs[k - 1]) : null; }
      let acc = 0, k = l.i0; const end = Math.max(l.i0 + 1, l.i1);
      while (k < end && acc < 80) { acc += Math.hypot(r.pts[k + 1].x - r.pts[k].x, r.pts[k + 1].y - r.pts[k].y); k++; }
      const a = r.pts[l.i0], b = r.pts[Math.min(k, r.pts.length - 1)];
      return Math.hypot(b.x - a.x, b.y - a.y) < 5 ? null : Math.atan2(b.y - a.y, b.x - a.x);
    }
    // Mockup only: the phone at the door of the first hall.
    function mockHere() {
      const h = A.c.items.find(i => i.kind === 'hall' && i.lab) || M.find(A.c, stayHall()) || M.find(A.c, (A.used || [])[0]), d = h && A.R.doors(h.name, { keys: true })[0];
      if (!d) return;
      A.nav.me = { x: d.x + 3, y: d.y + 3, acc: 8 }; A.nav.mock = true; A.nav.status = '';
      if (!A.nav.from || A.nav.from.kind !== 'place') A.nav.from = { kind: 'me' };
      routeNow(); paint(true); if (!A.nav.route) A.map.centre(A.nav.me, true); say('My location');
    }

    /* ------------------------------------------------ walking */

    // Start: the walk on its own screen. Located on campus, it follows the phone; otherwise (at home, a
    // start chosen) it steps through the walk, a turn at a time. The map turns so the way you walk is up
    // (polish 2: a north-up map under an up arrow sent people the wrong way), with you low on the screen
    // and the stretch's end and the building its step names ahead. North (top right, only while turned)
    // puts north up; Recentre turns it back. A "Head" arrow still points the way the line goes on screen.
    let walkEl = null, walker = null, lock = null, offSince = 0;
    function startWalk() {
      const n = A.nav; if (!n.route) return;
      const follow_ = n.from && n.from.kind === 'me' && n.me && M.onCampus(A.c, n.me);
      A.go = { i: 0, at: 0, follow: follow_, free: false, north: false, left: n.route.d, fitI: -1, listI: -1 };
      walkEl = document.createElement('div');
      walkEl.className = 'pw'; walkEl.setAttribute('role', 'dialog'); walkEl.setAttribute('aria-label', 'Walking to ' + endName(n.to));
      walkEl.innerHTML = '<header class="pw-top' + (follow_ ? '' : ' has-step') + '" aria-live="polite"></header><div class="pw-map"></div><footer class="pw-bar"></footer>';
      document.body.appendChild(walkEl);
      document.documentElement.classList.add('pm-on');
      walkEl.querySelector('.pw-map').appendChild(A.mapEl);
      A.map.inset({ top: 0, bottom: 0 });
      walkEl.addEventListener('click', walkClick);
      wake();
      if (follow_ && n.mock && window.OGC_WP && OGC_WP.dev) mockWalk();
      walkPaint(true);
    }
    const stepsList = (r, cur) => r.legs.map((l, i) => '<li><span class="pm-step' + (i === cur ? ' is-cur' : '') + '"' + (i === cur ? ' aria-current="step"' : '') + '>' + (I[l.icon] || I.straight) + '<span>' + esc(l.text) + (l.sub ? '<small>' + esc(l.sub) + '</small>' : '') + '</span><span>' + (l.d ? esc(M.feet(l.d)) : '') + '</span></span></li>').join('');
    function walkClick(e) {
      const b = e.target.closest('[data-w]'); if (!b) return;
      const k = b.dataset.w, g = A.go, r = A.nav.route;
      if (k === 'end') endWalk();
      else if (k === 'prev' || k === 'next') { g.i = Math.max(0, Math.min(r.legs.length - 1, g.i + (k === 'next' ? 1 : -1))); g.at = r.legs.slice(0, g.i).reduce((s, l) => s + l.d, 0); g.free = false; walkPaint(true); }
      else if (k === 'recentre') { g.free = false; g.north = false; g.fitI = -1; walkPaint(true); }
      else if (k === 'steps') {
        const s = walkEl.querySelector('.pw-steps');
        if (s) { s.remove(); b.setAttribute('aria-expanded', 'false'); }
        else { walkEl.querySelector('.pw-map').insertAdjacentHTML('beforeend', '<div class="pw-steps"><div class="pw-steps__h"><p class="pm-k">Steps</p><button type="button" class="pm-x" data-w="steps" aria-label="Close">' + I.close + '</button></div><ol class="pm-steps">' + stepsList(r, g.shownI == null ? g.i : g.shownI) + '</ol></div>'); g.listI = g.shownI == null ? g.i : g.shownI; scrollCur(); walkEl.querySelectorAll('[data-w="steps"]').forEach(x => x.setAttribute('aria-expanded', 'true')); }
      }
    }
    function scrollCur() { const c = walkEl && walkEl.querySelector('.pw-steps .is-cur'); if (c) c.scrollIntoView({ block: 'nearest' }); }
    // Each update changes only the words, the numbers and the dot, never the whole screen.
    const lower = t => t.charAt(0).toLowerCase() + t.slice(1);
    function walkPaint(frame) {
      if (!walkEl) return;
      const g = A.go, r = A.nav.route, l = r.legs[g.i] || r.legs[r.legs.length - 1];
      const legEnd = r.legs.slice(0, g.i + 1).reduce((s, x) => s + x.d, 0), toTurn = Math.max(0, legEnd - g.at);
      const next = g.follow && toTurn < 25 && r.legs[g.i + 1] ? r.legs[g.i + 1] : null, shown = next || l;
      const left = Math.max(0, r.d - g.at), mins = M.minutes(left, A.stepFree), arrived = g.arrived;
      // A straight-on step's arrow turned to the way the line goes on the (north-up) map.
      // The map turned for this stretch first, so the arrow below can follow it.
      if (frame && !g.free && !g.north) { const h = legHeading(r, l); if (h != null) A.map.turn(h); }
      const icon = arrived ? I.arrive : shown.icon === 'straight' && shown.h0 != null ? '<span class="pw-arrow" style="transform:rotate(' + ((shown.h0 + A.map.heading()) * 180 / Math.PI + 90).toFixed(0) + 'deg)">' + I.straight + '</span>' : (I[shown.icon] || I.straight);
      walkEl.querySelector('.pw-top').innerHTML = icon + '<div><b>' + esc(arrived ? 'Arrived' + r.legs[r.legs.length - 1].text.replace(/^Arrive/, '') : shown.text) + '</b><span>' +
        esc(arrived ? r.legs[r.legs.length - 1].sub || endName(A.nav.to) : g.follow ? (next ? (r.legs[g.i + 2] ? 'Then ' + lower(r.legs[g.i + 2].text) : '') : M.feet(toTurn)) : (l.d ? M.feet(l.d) : l.sub || '')) + '</span></div>' +
        (g.follow ? '' : '<div class="pw-step"><button type="button" data-w="prev" aria-label="Previous step"' + (g.i ? '' : ' disabled') + '>' + I.prev + '</button><button type="button" data-w="next" aria-label="Next step"' + (g.i < r.legs.length - 1 ? '' : ' disabled') + '>' + I.next + '</button></div>');
      const open = !!walkEl.querySelector('.pw-steps');
      // Stepping through (not walking it): "Step 3 of 6" over the whole walk, which stays as it is, and
      // no arrival time (polish 2: it counted down at home as Next was tapped).
      const total = M.minutes(r.d, A.stepFree) + ' min · ' + M.feet(r.d);
      walkEl.querySelector('.pw-bar').innerHTML = (g.follow ? '<p><b>' + (arrived ? 'Arrived' : mins + ' min') + '</b>' + (arrived ? '' : ' · ' + esc(M.feet(left)) + '<br>Arrive ' + esc(clock(now().minutes + mins))) + '</p>' : '<p><b>Step ' + (g.i + 1) + ' of ' + r.legs.length + '</b><br>' + esc(total) + '</p>') + '<p class="pm-btns"><button type="button" class="pm-btn pm-btn--line" data-w="steps" aria-expanded="' + open + '">' + I.list + 'Steps</button><button type="button" class="pm-btn" data-w="end">End</button></p>';
      // The open list follows the walk, marking the step the header says (polish 1: it kept the step it opened on).
      g.shownI = next ? g.i + 1 : g.i;
      if (open && g.listI !== g.shownI) { walkEl.querySelector('.pw-steps .pm-steps').innerHTML = stepsList(r, g.shownI); g.listI = g.shownI; scrollCur(); }
      const rc = walkEl.querySelector('.pw-recentre');
      if (g.free && !rc) walkEl.querySelector('.pw-map').insertAdjacentHTML('beforeend', '<button type="button" class="pm-btn pm-btn--line pw-recentre" data-w="recentre">' + I.locate + 'Recenter</button>');
      if (!g.free && rc) rc.remove();
      A.map.route(r, g.follow ? g.at : 0, g.follow ? null : l);
      A.map.me(A.nav.me && g.follow ? A.nav.me : null);
      if (frame && !g.free) {
        if (g.follow && A.nav.me) {
          // A new stretch: framed with me, where it turns and the building the next step names; then the map follows the dot.
          if (g.fitI !== g.i) { g.fitI = g.i; const p = A.nav.me; A.map.fit(around(legBox(r, l, g.i === r.legs.length - 1), [[p.x - 20, p.y - 20], [p.x + 20, p.y + 20]]), 24, true); }
          else A.map.centre(A.nav.me, true, A.map.heading() ? .7 : .5);
        } else A.map.fit(around(legBox(r, l, g.i === r.legs.length - 1), []), 30, true);
      }
    }
    // A position while walking: how far along, which step, and off the route for a while → a new route.
    function follow() {
      const n = A.nav, r = n.route, g = A.go; if (!r || !g || !n.me) return;
      const me = n.me;
      let bd = Infinity, at = 0, k = 0;
      for (let i = 0; i + 1 < r.pts.length; i++) {
        const a = r.pts[i], b = r.pts[i + 1], dx = b.x - a.x, dy = b.y - a.y, L = dx * dx + dy * dy, t = L ? Math.max(0, Math.min(1, ((me.x - a.x) * dx + (me.y - a.y) * dy) / L)) : 0;
        const dd = Math.hypot(a.x + t * dx - me.x, a.y + t * dy - me.y), len = Math.sqrt(L);
        if (dd < bd) { bd = dd; at = k + t * len; }
        k += len;
      }
      if (!n.mock && bd > 30) {
        if (!offSince) offSince = Date.now();
        else if (Date.now() - offSince > 10000) { offSince = 0; n.from = { kind: 'me' }; routeNow(); if (n.route) { g.i = 0; g.at = 0; g.fitI = -1; const t = walkEl && walkEl.querySelector('.pw-top b'); if (t) t.textContent = 'Rerouting'; say('Rerouting'); setTimeout(() => walkPaint(true), 700); } return; }
      } else offSince = 0;
      g.at = Math.max(g.at, at);
      let acc = 0; g.i = r.legs.length - 1;
      for (let i = 0; i < r.legs.length; i++) { if (acc + r.legs[i].d >= g.at && r.legs[i].d) { g.i = i; break; } acc += r.legs[i].d; }
      const before = g.arrived;
      if (r.d - g.at < 8) { g.arrived = true; g.i = r.legs.length - 1; }
      if (g.arrived && !before) say('Arrived'); else if (g.lastI !== g.i) say(r.legs[g.i].text);
      g.lastI = g.i;
      walkPaint(true);
    }
    // Mockup only: a walk along the route, three times life.
    function mockWalk() {
      const pts = A.nav.route.pts; let i = 0, f = 0;
      A.nav.me = { x: pts[0].x, y: pts[0].y, acc: 6 };
      clearInterval(walker);
      walker = setInterval(() => {
        const a = pts[i], b = pts[i + 1];
        if (!b || !A.go) { clearInterval(walker); return; }
        const L = Math.hypot(b.x - a.x, b.y - a.y) || 1; f += 1.6 / L;
        if (f >= 1) { i++; f = 0; A.nav.me = { x: b.x, y: b.y, acc: 6 }; } else A.nav.me = { x: a.x + (b.x - a.x) * f, y: a.y + (b.y - a.y) * f, acc: 6 };
        follow();
      }, 120);
    }
    function endWalk() {
      clearInterval(walker); walker = null; releaseWake();
      if (!walkEl) { A.go = null; return; }
      walkEl.remove(); walkEl = null; A.go = null;
      A.map.turn(null);
      stopWatch();
      // From here now: the route from where the walk ended.
      if (A.nav.from && A.nav.from.kind === 'me') routeNow();
      const body = A.el && A.el.querySelector('.pm-body'); if (body) body.scrollTop = 0;
      if (A.mode !== 'full') document.documentElement.classList.remove('pm-on');
      const host = A.el && A.el.querySelector('.pm-map'); if (host) host.appendChild(A.mapEl);
      if (!A.hidden) paint(true);
    }
    function showRecentre() { if (walkEl && A.go && !walkEl.querySelector('.pw-recentre')) walkPaint(false); }
    // The screen stays on while walking.
    function wake() { if (navigator.wakeLock && !lock) navigator.wakeLock.request('screen').then(l => { lock = l; l.addEventListener('release', () => { lock = null; }); }).catch(() => {}); }
    function releaseWake() { if (lock) { lock.release().catch(() => {}); lock = null; } }
    document.addEventListener('keydown', e => { if (e.key === 'Escape' && walkEl) endWalk(); });

    document.addEventListener('click', e => { if (A.el && !A.hidden && A.el.contains(e.target)) onClick(e); });
    document.addEventListener('change', e => { if (A.el && !A.hidden && A.el.contains(e.target)) onChange(e); });
    document.addEventListener('input', e => { if (A.el && !A.hidden && A.el.contains(e.target)) onInput(e); });
    document.addEventListener('keydown', e => { if (A.el && !A.hidden && A.el.contains(e.target)) onKey(e); });

    // Local development only: every place against every place in its own building (polish 2) — never
    // offered as each other's start, never routed. → the pairs that fail.
    function sameCheck() {
      const bad = [], ps = Object.values(places()), saved = Object.assign({}, A.nav);
      ps.forEach(a => ps.forEach(b => {
        const ea = { kind: 'place', code: a.code }, eb = { kind: 'place', code: b.code }, ba = endBuilding(ea);
        if (!ba || M.norm(ba) !== M.norm(endBuilding(eb))) return;
        A.nav.to = eb;
        if (candidates('from').some(c => c.v === a.code)) bad.push(a.code + ' offered as start for ' + b.code);
        const html = document.createElement('div'); html.innerHTML = pickBody('from');
        if (html.querySelector('[data-list] [data-v="' + CSS.escape(a.code) + '"]')) bad.push(a.code + ' listed as start for ' + b.code);
        A.nav.from = ea; routeNow();
        if (A.nav.route) bad.push(a.code + ' → ' + b.code + ' routed');
      }));
      Object.assign(A.nav, saved); routeNow();
      return bad;
    }
    const api = {
      mount, hide, focus, directions: code => { const e = endFrom(String(code)); if (e) directions(e); },
      search: () => picker('search'),
      destroy() { hide(); if (A.el) A.el.remove(); dlg.remove(); },
      get state() { return A; }
    };
    if (window.OGC_WP && OGC_WP.dev) { api.sameCheck = sameCheck; M.devApp = api; }
    return api;
  }

  M.app = app;
})();
