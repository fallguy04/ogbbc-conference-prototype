/*
 * ogc-map-app.js — the guide's Places: the campus map, to see where things are (the map area, Oct 10).
 *
 * On a phone (the guide), Places is the map, full height, with a sheet over it (peek: the usual places,
 * one tap each; half: a place; full: every building). On a laptop the map has its panel beside it when
 * the column is wide (a container query, not the window), else above it.
 *
 * Oct 13, Michael: "keep the Google Maps stuff and not try to do our own maps… for actual directions,
 * let's rely on GPS and everything from Google Maps." So the map shows the buildings with their codes
 * and names, the rooms' pins, Search and the blue dot; a place's Directions opens Google Maps' walking
 * directions to its building's entrance (O.map.directionsUrl) in a new tab, which a phone hands to its
 * Maps app. The guide no longer draws routes, gives steps or walks anyone there.
 *
 * week.js hands it what the page knows (ctx): the year, the campus (O.map.campus), the places, today's
 * rows with their state, every row (for search), the Help cards, the time, and how to open an event.
 * It keeps its own state between drawings of the page (the map keeps its place).
 *
 * Nothing about where someone is leaves the phone: the location is used while Places is open and
 * stopped when it closes or the page is hidden; "My room" comes from the server for the signed-in
 * person alone (/me/stay). Recent places (codes only) stay on this device.
 */
(function () {
  'use strict';
  const O = window.OGC, esc = O.esc, M = O.map;
  if (!M) return;
  const svg = d => '<svg class="pm-i" viewBox="0 0 24 24" aria-hidden="true"><path d="' + d + '" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  const I = {
    search: svg('M10.5 17a6.5 6.5 0 1 0 0-13 6.5 6.5 0 0 0 0 13ZM15.3 15.3l4.7 4.7'),
    dirs: svg('M12 3.5 20.5 12 12 20.5 3.5 12ZM9.5 13.5v-2.5h4.5M12.5 9l2 2-2 2'),
    pin: svg('M12 20.5s-6.5-5.4-6.5-10.8a6.5 6.5 0 0 1 13 0c0 5.4-6.5 10.8-6.5 10.8ZM12 12a2.3 2.3 0 1 0 0-4.6 2.3 2.3 0 0 0 0 4.6Z'),
    close: svg('M6.5 6.5l11 11M17.5 6.5l-11 11'),
    locate: svg('M12 3v3M12 18v3M3 12h3M18 12h3M12 17a5 5 0 1 0 0-10 5 5 0 0 0 0 10Z'),
    bed: svg('M3.5 18.5v-11M3.5 14.5h17v4M20.5 14.5v-2.5a2.5 2.5 0 0 0-2.5-2.5h-7v5M7 12.2a1.6 1.6 0 1 0 0-3.2 1.6 1.6 0 0 0 0 3.2Z'),
    clock: svg('M12 20.5a8.5 8.5 0 1 0 0-17 8.5 8.5 0 0 0 0 17ZM12 7.5V12l3 2'),
    cross: svg('M9.5 4.5h5v5h5v5h-5v5h-5v-5h-5v-5h5Z'),
    desk: svg('M4.5 9.5h15v10h-15ZM9.5 9.5v-4h5v4'),
    next: svg('M9.5 5.5 16 12l-6.5 6.5'),
    // A place's features (places.csv `features`; Oct 13, from Andrew's guide), one plain line icon each.
    'f-nursery': svg('M10.5 3.5h3l.5 2.5h-4ZM9 6h6v2.5H9ZM10 8.5h4a1.5 1.5 0 0 1 1.5 1.5v9a1.5 1.5 0 0 1-1.5 1.5h-4A1.5 1.5 0 0 1 8.5 19v-9A1.5 1.5 0 0 1 10 8.5ZM8.5 12.5h3M8.5 15.5h3'),
    'f-restroom': svg('M12 6.5a1.75 1.75 0 1 0 0-3.5 1.75 1.75 0 0 0 0 3.5ZM9 20.5v-6.5l-1-.5V10a1.5 1.5 0 0 1 1.5-1.5h5A1.5 1.5 0 0 1 16 10v3.5l-1 .5v6.5M12 14.5v6'),
    'f-family restroom': svg('M8.5 6.5a1.75 1.75 0 1 0 0-3.5 1.75 1.75 0 0 0 0 3.5ZM5.5 20.5v-6.5l-1-.5V10A1.5 1.5 0 0 1 6 8.5h5A1.5 1.5 0 0 1 12.5 10v3.5l-1 .5v6.5M17 11a1.4 1.4 0 1 0 0-2.8 1.4 1.4 0 0 0 0 2.8ZM15 20.5v-4l-.7-.5v-2.2a1 1 0 0 1 1-1h3.4a1 1 0 0 1 1 1V16l-.7.5v4'),
    'f-accessible entrance': svg('M10.5 5.5a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3ZM10.5 7.5V13h5l2.5 5.5M10.5 10h4.5M8 10.6a5.2 5.2 0 1 0 7.6 6.6'),
    'f-elevator': svg('M5.5 3.5h13v17h-13ZM9.5 9.5 12 7l2.5 2.5M9.5 14.5 12 17l2.5-2.5'),
    'f-quiet room': svg('M19 14.5A7.5 7.5 0 0 1 9.5 5a7.5 7.5 0 1 0 9.5 9.5Z')
  };
  // The words a place goes by, beyond its name (search).
  const KIND_WORDS = { dining: ['dining', 'cafeteria', 'food', 'meals', 'lunch', 'dinner', 'breakfast'], worship: ['chapel', 'worship', 'services', 'auditorium'], venue: ['auditorium', 'theater', 'hall'], hall: ['hall', 'dorm', 'residence'] };
  const SPOT_WORDS = { parking: 'parking lot cars', accessible: 'parking accessible handicap', camper: 'campers rv lot', carts: 'golf carts cart ride', desk: 'information info desk help' };
  const SYN = { bathroom: ['restroom'], bathrooms: ['restroom'], toilet: ['restroom'], washroom: ['restroom'], food: ['dining'], eat: ['dining'], meals: ['dining'], cafeteria: ['dining'], info: ['information'], doctor: ['first aid'], nurse: ['first aid'], medical: ['first aid'], gym: ['recreation', 'arena'], dorm: ['hall'] };
  const LS = { get: (k, d) => { try { const v = localStorage.getItem(k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } }, set: (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { /* fine */ } } };
  const coarse = () => !!(window.matchMedia && matchMedia('(pointer: coarse)').matches);
  // Members (the pins tool's people) are told what the map is missing; the public only what's useful.
  const W = () => window.OGC_WP || {};
  const member = y => !!(W().webmaster || (W().member || []).map(String).indexOf(String(y)) > -1);
  const touch = () => coarse() && 'geolocation' in navigator;

  function app() {
    const A = { el: null, ctx: null, c: null, map: null, mapEl: null, mode: '', place: null, nav: { me: null, status: '' }, sheetH: 0, snap: 'peek', stay: null, stayAsked: false, watch: null, perm: '', hidden: true };
    const dlg = document.createElement('dialog');
    dlg.className = 'ogc wk-sheet pm-pick';
    dlg.setAttribute('aria-labelledby', 'pm-pick-t');
    document.body.appendChild(dlg);

    /* ------------------------------------------------ what the page knows */

    const places = () => A.ctx.places || {};
    const P = code => code ? places()[String(code).toUpperCase()] || null : null;
    const keyOf = code => String(code).split('/')[0].toUpperCase();
    // A room named for its building ("Piazza Terrace (Barnes)") drops the building in its own card.
    const inBuilding = (room, b) => String(room.name).replace(/\s*\(([^)]+)\)$/, (m, w) => String(b).toLowerCase().indexOf(w.split(' ')[0].toLowerCase()) > -1 ? '' : m);
    // The buildings people go to, in places.csv's order, each with its rooms. A building listed only by
    // its rooms (Cedarville's "Stevens Student Center Room 241") is named for the building, not a room.
    function groups() {
      const out = [], by = {};
      Object.keys(places()).forEach(k => {
        const p = places()[k], key = keyOf(p.code);
        if (!by[key]) out.push(by[key] = { key, main: null, rooms: [] });
        if (String(p.code).toUpperCase() === key) by[key].main = p; else by[key].rooms.push(p);
      });
      return out.filter(g => g.main || g.rooms.length).map(g => {
        if (g.main) return Object.assign(g, { name: g.main.name, all: g.rooms });
        const r = g.rooms[0], name = r.building || String(r.name).replace(/\s*(room|rm\.?|#)\s*[\w–-]+$/i, '') || r.name;
        return Object.assign(g, { main: r, name, all: g.rooms, derived: true });
      });
    }
    const where = p => M.whereIs(A.c, p, places());
    // The halls with rooms this year: rooms.csv for those who may read it, else the campus's own mark.
    const stayHalls = () => Array.from(new Set((A.ctx.halls || []).concat(A.c.items.filter(i => i.stay && i.lab).map(i => i.name))));
    // Directions can take you there: a pin, or a building (a field not pinned yet can't; members are told so).
    const routable = p => { const w = p && where(p); return !!(w && (w.kind === 'pin' || w.kind === 'building')); };
    // Directions (Oct 13): Google Maps' walking directions to the building's entrance, or a field's pin,
    // opened beside the guide (a phone hands it to its Maps app). The one filled button on a place's card.
    const dirsLink = href => href ? '<p class="pm-btns"><a class="pm-btn" href="' + esc(href) + '"' + M.OUT + ' title="Walking directions in Google Maps">' + I.dirs + 'Directions</a></p>' : '';
    const dirsTo = p => dirsLink(M.directionsUrl(A.c, p, places()));
    const today = () => (A.ctx.today ? A.ctx.today() : []);
    // The next thing on today (the Conference's own rows), for "Next".
    function nextEvent() {
      return today().filter(it => it.code && P(it.code) && !it.allDay && (it.state === 'upcoming' || it.state === 'now') && (!it.audience || it.audience === 'conference' || it.audience === 'all'))
        .sort((a, b) => (a.state === 'now') - (b.state === 'now') || (a.start == null ? 1e9 : a.start) - (b.start == null ? 1e9 : b.start))[0] || null;
    }
    // The guide's own way to say a time ("11:00 PM ET" to a reader in another zone), as Today says it.
    const clock = m => { const t = ((m % 1440) + 1440) % 1440; return A.ctx && A.ctx.clock ? A.ctx.clock(t) : O.formatTime(t); };
    // The schedule's own short names for buildings ("PPAC", not "Phillippe").
    let shorts = {};
    // A building as the schedule names it ("PPAC", not campus.csv's "Phillippe"), everywhere a building is said.
    const bShort = b => b ? shorts[b.name] || M.shortOf(b) : '';
    // What tells a room apart, beyond its own name: "First Aid Room (Barnes Room 131)" → "Room 131".
    const roomRest = (room, b) => { const m = /\(([^)]+)\)$/.exec(String(room.name)); if (!m || String(b).toLowerCase().indexOf(m[1].split(' ')[0].toLowerCase()) < 0) return ''; const r = /\b(rooms?|rm\.?)\s+\S.*$/i.exec(m[1]); return r ? r[0].charAt(0).toUpperCase() + r[0].slice(1) : ''; };
    // A room by its own name ("First Aid Room"); the building and number go on the line under it.
    const roomName = p => { const b = where(p).b; return String(p.code).indexOf('/') > -1 && b ? inBuilding(p, b.name) : p.name; };

    // Features (places.csv `features`, one fixed list; Oct 13, from Andrew's guide): a building's own,
    // and its rooms' with the room they're in ("Nursery · Room 114"). Only what a row says is shown.
    const FAMILY = ['nursery', 'family restroom', 'quiet room'];
    const featWord = f => (O.FEATURES && O.FEATURES[f]) || f;
    function featuresIn(g) {
      return (g.derived ? [] : (g.main.features || []).map(f => ({ f, room: null }))).concat([].concat.apply([], (g.derived ? g.all : g.rooms).map(r => (r.features || []).map(f => ({ f, room: r })))));
    }
    // A feature's row: its icon and word, and the room (a room's row opens that room on the map).
    // withB: the building too ("Room 114 · Chapel"), in the campus-wide list.
    function featRow(x, g, withB) {
      const r = x.room ? (roomRest(x.room, g.name) || inBuilding(x.room, g.name)) : '', b = withB ? (where(g.main).b ? bShort(where(g.main).b) : g.name) : '';
      const where_ = [r && r.toLowerCase() !== featWord(x.f).toLowerCase() ? r : '', b].filter(Boolean).join(' · ');
      const inner = (I['f-' + x.f] || '') + '<span><b>' + esc(featWord(x.f)) + '</b>' + (where_ ? '<small>' + esc(where_) + '</small>' : '') + '</span>';
      return '<li>' + (x.room ? '<button type="button" class="pm-feat" data-pm="room" data-code="' + esc(x.room.code) + '">' + inner + (x.room.code ? '<code>' + esc(x.room.code) + '</code>' : '') + '</button>' : '<div class="pm-feat">' + inner + '</div>') + '</li>';
    }
    // Every place with a family feature, campus-wide ("For families").
    const familyPlaces = () => [].concat.apply([], groups().map(g => featuresIn(g).filter(x => FAMILY.indexOf(x.f) > -1).map(x => Object.assign({ g }, x))));

    /* ------------------------------------------------ where I sleep, and what a place is called */

    // My hall: a dorm stay's, or a Young Folk's one hall (from /me/stay).
    function stayHall() { const s = A.stay; if (!s) return ''; if (s.type === 'dorm' && s.rooms && s.rooms.length) return s.rooms[0].hall; if (s.type === 'yf' && s.halls && s.halls.length === 1) return s.halls[0]; return ''; }
    const camper = () => A.c.spots.find(s => s.spot === 'camper');
    // Where I sleep, as one of the usual places (a chip that shows it on the map).
    function stayEnd() {
      const s = A.stay; if (!s) return null;
      if (s.type === 'camper' && camper()) return { kind: 'stay' };
      return stayHall() ? { kind: 'stay' } : null;
    }
    const stayName = () => A.stay && A.stay.type === 'camper' ? 'Camper lot' : A.stay && A.stay.type === 'yf' ? 'My hall' : 'My room';
    // "Reed Hall · 2nd floor · 211, 212" (the floor of the first room; polish 2).
    function staySub() { const s = A.stay; if (s && s.type === 'dorm' && s.rooms && s.rooms.length) { const fl = Array.from(new Set(s.rooms.map(r => +r.floor || 0).filter(Boolean))); return [s.rooms[0].hall, fl.length === 1 ? M.floorName(fl[0]) : '', s.rooms.map(r => r.num).join(', ')].filter(Boolean).join(' · '); } return stayHall(); }
    const spotName = id => { const s = A.c.spots.find(x => x.id === id); return s ? s.name || M.SPOT[s.spot] : 'Spot'; };
    // A pinned place's name on its pin, as the map says it: "Piazza Terrace", "First Aid Room", "PPAC".
    function pinName(p) {
      const b = where(p).b;
      if (String(p.code).indexOf('/') > -1) return b ? inBuilding(p, b.name) : p.name;
      return b ? shorts[b.name] || M.shortOf(b) : p.name;
    }

    /* ------------------------------------------------ location (the phone only) */

    function locate() {
      const n = A.nav;
      if (!touch()) return;
      if (A.watch != null) { if (n.me && M.onCampus(A.c, n.me)) A.map.centre(n.me, true); return; }
      n.status = 'Locating';
      paint();
      A.watch = navigator.geolocation.watchPosition(pos => {
        const p = M.toMap(A.c, pos.coords.latitude, pos.coords.longitude);
        if (!p) return;
        p.acc = pos.coords.accuracy;
        const first = !n.me;
        n.me = p; A.perm = 'granted';
        n.status = !M.onCampus(A.c, p) ? 'Not on campus' : p.acc > 40 ? 'Approximate location' : '';
        paint();
        if (first && M.onCampus(A.c, p)) A.map.centre(p, true);
      }, err => {
        n.status = err && err.code === 1 ? 'Location off' : 'Location unavailable';
        if (err && err.code === 1) A.perm = 'denied';
        stopWatch(); paint();
      }, { enableHighAccuracy: true, maximumAge: 5000, timeout: 15000 });
    }
    function stopWatch() { if (A.watch != null && navigator.geolocation) navigator.geolocation.clearWatch(A.watch); A.watch = null; }
    // Hidden page: the GPS stops (battery); back again, it starts again if it was on.
    let wasWatching = false;
    document.addEventListener('visibilitychange', () => {
      if (document.hidden) { wasWatching = A.watch != null; stopWatch(); }
      else if (wasWatching && !A.hidden) locate();
    });
    if (navigator.permissions && navigator.permissions.query) navigator.permissions.query({ name: 'geolocation' }).then(s => { A.perm = s.state; s.onchange = () => { A.perm = s.state; }; }).catch(() => {});

    /* ------------------------------------------------ drawing */

    function mount(slot, ctx) {
      const yearChanged = !A.ctx || A.ctx.year !== ctx.year || A.ctx.campus !== ctx.campus;
      A.ctx = ctx; A.hidden = false;
      if (yearChanged) { A.c = ctx.campus; A.place = null; A.nav = { me: A.nav.me, status: '' }; A.stay = null; A.stayAsked = false; if (A.map) { A.mapEl.remove(); A.map = null; } shorts = M.shortsFor ? M.shortsFor(A.c, places()) : {}; }
      const mode = ctx.full ? 'full' : 'embed';
      if (!A.el) { A.el = document.createElement('div'); A.el.className = 'pm'; }
      if (A.mode !== mode) { A.mode = mode; A.el.className = 'pm pm--' + mode + (ctx.guide ? ' pm--guide' : ''); build(); }
      slot.appendChild(A.el);
      if (!A.map) makeMap();
      document.documentElement.classList.toggle('pm-on', mode === 'full');
      document.documentElement.classList.add('pm-places');
      if (mode === 'full') { scrollTo(0, 0); place(); }
      else { A.el.style.removeProperty('--pm-top'); A.el.style.removeProperty('--pm-bottom'); }
      const host = A.el.querySelector('.pm-map'); if (A.mapEl.parentNode !== host) host.appendChild(A.mapEl);
      if (!A.stayAsked) { A.stayAsked = true; M.store.stay(ctx.year).then(s => {
        A.stay = s && s.type ? s : null;
        paint();
        // My hall in the first frame too (it comes after the map is drawn), unless something's been asked for.
        const h = stayHall();
        if (h && A.map && !A.place && A.firstFrame && A.firstFrame.indexOf(h) < 0) { A.firstFrame = A.firstFrame.concat([h]); A.map.fit(M.boxOf(A.c, A.firstFrame, 30), 8, true); }
      }); }
      paint();
    }
    function hide() {
      if (A.hidden) return;
      A.hidden = true; stopWatch(); document.documentElement.classList.remove('pm-on', 'pm-places');
    }
    function build() {
      const search = '<button type="button" class="pm-search" data-pm="search">' + I.search + 'Search</button>';
      A.el.innerHTML = A.mode === 'full'
        ? '<div class="pm-map">' + search + '</div><section class="pm-sheet is-peek" aria-label="Places"><button type="button" class="pm-grab" data-pm="grab" aria-label="More"></button><div class="pm-body"></div></section>'
        : '<div class="pm-grid"><div class="pm-map">' + search + '</div><div class="pm-panel" aria-live="off"></div></div><div class="pm-cards" aria-label="Buildings"></div><div class="pm-extra"></div>';
      if (A.mode === 'full') sheetDrag();
    }
    // The fixed map sits between the guide's header and its tabs.
    function place() {
      const head = document.querySelector('.wk-apphead'), tabs = document.querySelector('.wk-tabbar');
      const top = head ? Math.max(0, head.getBoundingClientRect().bottom) : 0, bottom = tabs ? tabs.getBoundingClientRect().height : 0;
      A.el.style.setProperty('--pm-top', top + 'px'); A.el.style.setProperty('--pm-bottom', bottom + 'px');
    }
    addEventListener('resize', () => { if (A.mode === 'full' && !A.hidden) { place(); setSheet(A.snap, false); } });
    // The first frame: the halls with rooms this year and the buildings the schedule uses, together.
    // Polish 2: the outlier rule (a fieldhouse across the fields) dropped Reed and Evans too; it now
    // applies to the Conference's buildings only, and the halls always stay.
    function core(names, halls) {
      const its = names.map(x => M.find(A.c, x)).filter(Boolean), keep = new Set((halls || []).map(x => (M.find(A.c, x) || {}).name).filter(Boolean));
      const med = xs => xs.slice().sort((p, q) => p - q)[Math.floor(xs.length / 2)] || 0;
      const mx = med(its.map(i => i.lx)), my = med(its.map(i => i.ly)), d = i => Math.hypot(i.lx - mx, i.ly - my), md = med(its.map(d));
      return Array.from(new Set(its.filter(i => keep.has(i.name) || d(i) <= Math.max(md * 2.5, 180)).map(i => i.name).concat(Array.from(keep))));
    }
    function makeMap() {
      A.mapEl = document.createElement('div'); A.mapEl.className = 'pm-mapbox'; A.mapEl.style.cssText = 'position:absolute;inset:0';
      const used = new Set(), codes = {};
      groups().forEach(g => { const w = where(g.main); if (w.b) { used.add(w.b.name); if (!codes[w.b.name] && !g.derived && String(g.main.code).indexOf('/') < 0) codes[w.b.name] = g.key; } });
      const hall = stayHall(); if (hall) used.add(hall);
      // First view: the buildings this year's schedule uses, and the halls with rooms (never names written in code).
      const halls = stayHalls().concat(hall ? [hall] : []), start = core(Array.from(used).concat(halls), halls);
      A.firstFrame = start;
      const focus = A.pendingFocus ? A.pendingFocus : null; A.pendingFocus = null;
      A.map = M.viewer(A.mapEl, A.c, { title: 'Campus map', locate: true, start, focus, extent: Array.from(used).concat(halls), used: Array.from(used), codes, shorts, cooperative: A.mode !== 'full', expand: A.mode !== 'full',
        onTap: (pt, b, spot) => { if (spot) openSpot(spot); else if (b) openBuilding(b); },
        onLocate: () => locate() });
      A.el.querySelector('.pm-map').appendChild(A.mapEl);
      // The first time on this device: how the map moves (gone at the first touch).
      if (!LS.get('ogc-map-hinted', false)) { LS.set('ogc-map-hinted', true); setTimeout(() => A.map && A.map.hint(A.mode === 'full' ? 'Drag to move · Tap a building' : 'Tap a building'), 600); }
    }

    // The panel (laptop) or sheet (phone): what's open now.
    function paint(fit) {
      if (!A.el || A.hidden) return;
      const body = A.place ? placeView(A.place) : browseView();
      if (A.mode === 'full') {
        // The same view keeps its scroll; another (a building tapped in the list) starts at its top (Oct 13).
        const b = A.el.querySelector('.pm-body'), view = A.place ? A.place.kind + ':' + (A.place.code || A.place.name || A.place.id || '') : 'browse', keepScroll = view === A.lastView ? b.scrollTop : 0;
        A.lastView = view;
        b.innerHTML = body + (A.place ? '' : cardsView() + (A.ctx.extra || ''));
        b.scrollTop = keepScroll;
        setSheet(A.snap, false);
      } else {
        A.el.querySelector('.pm-panel').innerHTML = body;
        A.el.querySelector('.pm-cards').innerHTML = cardsView();
        A.el.querySelector('.pm-extra').innerHTML = A.ctx.extra || '';
      }
      drawMap(fit);
    }
    const topInset = () => { const sb = A.el && A.el.querySelector('.pm-search'); return sb && sb.offsetHeight ? sb.offsetTop + sb.offsetHeight + 8 : 64; };
    // A building framed with its neighbours: it fills at most about a third of the map's width (polish 1:
    // on a laptop a tapped building filled 70% and the context was lost).
    const roomy = (box, f) => box ? { x: box.x + box.w / 2 - box.w / f / 2, y: box.y + box.h / 2 - box.h / f / 2, w: box.w / f, h: box.h / f } : null;
    function drawMap(fit) {
      const m = A.map, n = A.nav;
      if (!m) return;
      m.me(n.me && M.onCampus(A.c, n.me) ? n.me : null);
      const pins = [];
      let sel = '', green = null, box = null;
      const t = A.place;
      if (t && t.kind === 'hall') {
        const b = M.find(A.c, t.name);
        // (Its own name stays on the map under the pin; my hall's pin says "My room" instead.)
        const mine = M.norm(b && b.name) === M.norm(stayHall());
        if (b) { sel = b.name; pins.push({ x: b.lx, y: b.ly, kind: 'to', of: mine ? b.name : '', label: mine ? stayName() : '' }); box = M.boxOf(A.c, [b.name], 10); }
      } else if (t && t.kind === 'spot') {
        const s = A.c.spots.find(z => z.id === t.id);
        if (s) { pins.push({ x: s.cx, y: s.cy, kind: 'to', label: spotName(s.id) }); box = { x: s.cx - 60, y: s.cy - 60, w: 120, h: 120 }; }
      } else if (t) {
        const p = P(t.code), w = p ? where(p) : { kind: 'none' };
        if (w.b) sel = w.b.name;
        green = w.green || null;
        if (w.kind === 'pin') pins.push({ x: w.x, y: w.y, kind: 'to', label: pinName(p) });
        // A building: a pin on it. A room with no pin: its building tinted, never a pin that reads as the room.
        else if (w.b && String(p.code).indexOf('/') < 0) pins.push({ x: w.b.lx, y: w.b.ly, kind: 'to', label: '' });
        box = w.kind === 'pin' ? M.boxOf(A.c, w.b ? [w.b.name] : [], 30) : w.b ? M.boxOf(A.c, [w.b.name], 10) : null;
        if (w.kind === 'pin' && !box) box = { x: w.x - 60, y: w.y - 60, w: 120, h: 120 };
      }
      // Where I sleep: a bed on my hall, its name always shown (polish 2: Reed drawn like every other hall).
      const sh = stayHall() && M.find(A.c, stayHall());
      if (sh && !(t && t.kind === 'hall' && M.norm(t.name) === M.norm(sh.name))) pins.push({ x: sh.lx, y: sh.ly, kind: 'stay', of: sh.name, label: shorts[sh.name] || M.shortOf(sh) });
      m.pins(pins);
      m.select(sel, green);
      // What covers the map: the search bar (both layouts) and the sheet (a phone); fits and names keep clear.
      m.inset({ top: topInset(), bottom: A.mode === 'full' ? A.sheetH : 0 });
      if (fit && box) m.fit(roomy(box, A.mode === 'full' ? .45 : .35), 20, true);
    }

    /* ------------------------------------------------ the views in the sheet or panel */

    const x = '<button type="button" class="pm-x" data-pm="close" aria-label="Close">' + I.close + '</button>';
    // Nothing chosen: the usual places, one tap each (my room, what's next, Help's places); on a laptop,
    // what's still on today beside the map (polish 1: the panel was one chip over blank space).
    function browseView() {
      // Last in the row, quietly: For families, when the campus marks a nursery, family restroom or quiet room.
      const fam = familyPlaces().length ? '<button type="button" class="pm-chip" data-pm="families">' + I['f-family restroom'] + '<span><b>For families</b></span></button>' : '';
      // First, on a phone: Show where I am (Andrew's guide, Oct 13), the phone's location as the blue dot,
      // asked for only when it's tapped; once on, it says so, and a tap centres the map on it again.
      const on = A.watch != null;
      const me = touch() ? '<button type="button" class="pm-chip pm-chip--me" data-pm="locate" aria-pressed="' + on + '">' + I.locate + '<span><b>' + (on ? 'Showing where you are' : 'Show where I am') + '</b></span></button>' : '';
      const chips = me + quickChips() + fam;
      const status = A.nav.status && A.nav.status !== 'Locating' ? '<p class="pm-status" data-peek>' + I.locate + esc(A.nav.status) + '</p>' : '';
      const still = A.mode === 'embed' ? stillToday(null, null, true) : '';
      return (chips ? '<div class="pm-quick" data-peek>' + chips + '</div>' : '') + status + (still ? '<div class="pm-card">' + still + '</div>' : '');
    }
    // A place: its name and code, how to find it, what's inside, what's still on, and Directions.
    // For families (Andrew's guide, Oct 13): every nursery, family restroom and quiet room on the campus,
    // each opening its room. Reached from its chip, which is there only when places.csv marks one.
    function familiesView() {
      const list = familyPlaces();
      return '<div class="pm-card pm-placecard"><div data-peek>' + x + '<h2 class="pm-h">For families</h2></div>' +
        (list.length ? '<ul class="pm-feats">' + list.map(z => featRow(z, z.g, true)).join('') + '</ul>' : '') + '</div>';
    }
    function placeView(pl) {
      if (pl.kind === 'families') return familiesView();
      if (pl.kind === 'spot') {
        const s = A.c.spots.find(z => z.id === pl.id);
        if (!s) return '';
        return '<div class="pm-card pm-placecard"><div data-peek>' + x + '<p class="pm-k">' + esc(M.SPOT[s.spot] || 'Place') + '</p><h2 class="pm-h">' + esc(s.name || M.SPOT[s.spot]) + '</h2>' + (s.note ? '<p class="pm-line">' + I.pin + '<span>' + esc(s.note) + '</span></p>' : '') +
          dirsLink(M.mapsUrl(M.toLatLng(A.c, s.cx, s.cy))) + '</div></div>';
      }
      if (pl.kind === 'hall') {
        return '<div class="pm-card pm-placecard"><div data-peek>' + x + '<p class="pm-k">' + ((M.find(A.c, pl.name) || {}).kind === 'hall' ? 'Hall' : 'Building') + '</p><h2 class="pm-h">' + esc(pl.name) + '</h2>' + (stayHall() === pl.name ? '<p class="pm-sub">' + esc(staySub()) + '</p>' : '') +
          dirsLink(M.mapsUrl(M.entrance(A.c, pl.name))) + '</div></div>';
      }
      const p = P(pl.code); if (!p) return '';
      const g = groups().find(z => z.key === keyOf(p.code)), main = g && g.main, isMain = main && main.code === p.code && !g.derived;
      const w = where(p), line = M.placeLine(A.c, p, places(), w.kind === 'pin' && w.b ? M.nearestDoor(A.c, w.b.name, w) : null);
      const sub = [isMain ? '' : (w.b ? bShort(w.b) : g ? g.name : ''), isMain || !w.b ? '' : roomRest(p, w.b.name), line].filter(Boolean).join(' · ');
      const room = String(p.code).indexOf('/') > -1 && w.kind === 'building';
      // What the map is missing is said to members (the pins tool's people), never to the public (polish 2).
      const not = !member(A.ctx.year) ? '' : w.kind === 'outdoor' ? 'Outdoor · Not on the map yet' : w.kind === 'none' ? 'Not on the map yet' : room ? 'Room not on the map yet' : '';
      // Its features (a building's: its own and its rooms'; a room's: any its name doesn't already say),
      // each once: a room with one is listed there, not again among the rooms.
      const feats = isMain ? featuresIn(g) : (p.features || []).filter(f => String(p.name).toLowerCase().indexOf(featWord(f).toLowerCase()) < 0).map(f => ({ f, room: null }));
      const featured = feats.filter(f => f.room).map(f => f.room.code), plain = isMain ? g.rooms.filter(r => featured.indexOf(r.code) < 0) : [];
      const featList = feats.length ? '<ul class="pm-feats" aria-label="For families and access">' + feats.map(f => featRow(f, g)).join('') + '</ul>' : '';
      const rooms = plain.length ? '<ul class="pm-rooms">' + plain.map(r => roomRow(r, main.name, true)).join('') + '</ul>' : '';
      return '<div class="pm-card pm-placecard"><div data-peek>' + x + '<h2 class="pm-h" aria-label="' + esc(p.name + ', ' + p.code) + '">' + esc(roomName(p)) + ' <span class="pm-code" aria-hidden="true">' + esc(p.code) + '</span></h2>' +
        (sub ? '<p class="pm-sub">' + esc(sub) + '</p>' : '') + (not ? '<p class="pm-line">' + I.pin + '<span>' + esc(not) + '</span></p>' : '') +
        dirsTo(p) + '</div>' +
        featList + stillToday(isMain ? g.key : null, p.code) + rooms + '</div>';
    }
    // One row style for a room everywhere (the place card, the cards, the picker).
    const roomRow = (r, bname, small) => '<li><button type="button" class="pm-row" data-pm="room" data-code="' + esc(r.code) + '"><span>' + esc(inBuilding(r, bname)) + (small && (r.floor || r.inside) ? '<small>' + esc(M.placeLine(A.c, r, places())) + '</small>' : '') + '</span><code>' + esc(r.code) + '</code></button></li>';
    // What's still on today in a building (or at one room, or everywhere: all), as Today says it:
    // the timed rows first ("Now", then by time), then the places open all day, "Open · until 11 PM"
    // or "Closed · reopens 12:00 PM" (polish 1: Places said open while Today said closed during
    // services). One grid, so every title lines up; each row one 44 px button.
    function stillToday(key, code, all) {
      const rows = today().filter(it => it.code && (all || (key ? keyOf(it.code) === key : String(it.code).toUpperCase() === String(code).toUpperCase())) && it.state !== 'past');
      if (!rows.length) return '';
      const timed = rows.filter(it => !it.allDay).sort((a, b) => (b.state === 'now') - (a.state === 'now') || (a.start == null ? 1e9 : a.start) - (b.start == null ? 1e9 : b.start));
      const open = rows.filter(it => it.allDay && (it.state === 'now' || it.closed));
      const cap = all && A.allToday ? Infinity : all ? 6 : 5, list = timed.slice(0, cap).concat(open.slice(0, Math.max(0, cap - timed.length)));
      const more = rows.length - list.length;
      const at = it => all && P(it.code) ? ' · ' + (shorts[(where(P(it.code)).b || {}).name] || M.shortOf(where(P(it.code)).b) || P(it.code).name) : '';
      const row = it => {
        const k = it.allDay ? (it.closed ? 'Closed' : 'Open') : it.state === 'now' ? 'Now' : it.start != null ? clock(it.start) : it.startText || '';
        const tail = it.allDay ? (it.closed ? 'reopens ' + clock(it.closed.end) : it.end != null ? 'until ' + clock(it.end) : '') : it.state === 'now' && it.end != null ? 'until ' + clock(it.end) : '';
        const inner = '<span class="pm-ev__k">' + esc(k) + '</span><span class="pm-ev__t">' + esc(it.title) + (tail || at(it) ? '<small>' + esc((tail ? ' · ' + tail : '') + at(it)) + '</small>' : '') + '</span>';
        return '<li class="' + (it.state === 'now' && !it.closed ? 'is-now' : it.closed ? 'is-closed' : '') + '">' + (it.id ? '<button type="button" class="pm-ev" data-pm="event" data-id="' + esc(it.id) + '">' + inner + '</button>' : '<div class="pm-ev">' + inner + '</div>') + '</li>';
      };
      return '<div class="pm-today"><p class="pm-k">Still today</p><ul>' + list.map(row).join('') + (more > 0 ? '<li class="pm-today__more">' + (all ? '<button type="button" class="pm-link" data-pm="more-today">' + more + ' more</button>' : more + ' more') + '</li>' : '') + '</ul></div>';
    }
    // Every building, what's in it and what's still on: the chosen one first, then what's on now, then next.
    function cardsView() {
      const gs = groups(), sel = A.place && A.place.code ? keyOf(A.place.code) : '';
      const first = g => { const rows = today().filter(it => it.code && keyOf(it.code) === g.key && it.state !== 'past' && !it.allDay); const nowOn = rows.some(it => it.state === 'now'); const nx = rows.filter(it => it.start != null).map(it => it.start).sort((a, b) => a - b)[0]; return [g.key === sel ? 0 : 1, nowOn ? 0 : 1, nx == null ? 1e9 : nx]; };
      const order = gs.map((g, i) => ({ g, i, k: first(g) })).sort((a, b) => a.k[0] - b.k[0] || a.k[1] - b.k[1] || a.k[2] - b.k[2] || a.i - b.i).map(z => z.g);
      // Polish 2: the whole head is one 44 px row that opens the place (its sheet has Directions, filled);
      // the cards carry no Directions of their own (six or more on the full sheet before).
      const head = (attrs, name, code) => '<button type="button" class="pm-cardhead" ' + attrs + '><h3 class="pm-h">' + esc(name) + '</h3>' + (code ? '<span class="pm-code">' + esc(code) + '</span>' : '') + I.next + '</button>';
      const card = g => {
        const w = where(g.main), not = !member(A.ctx.year) ? '' : w.kind === 'outdoor' ? 'Outdoor · Not on the map yet' : w.kind === 'none' ? 'Not on the map yet' : '';
        const rooms = (g.derived ? g.all : g.rooms);
        const list = rooms.length ? '<ul class="pm-rooms">' + rooms.map(r => roomRow(r, g.name)).join('') + '</ul>' : '';
        return '<section class="pm-card' + (g.key === sel ? ' is-sel' : '') + '" aria-label="' + esc(g.name) + '">' + (g.derived ? '<div class="pm-cardhead"><h3 class="pm-h">' + esc(g.name) + '</h3><span class="pm-code">' + esc(g.key) + '</span></div>' : head('data-pm="room" data-code="' + esc(g.main.code) + '"', g.name, g.main.code)) +
          (not ? '<p class="pm-quiet">' + esc(not) + '</p>' : '') + stillToday(g.key) + list + '</section>';
      };
      const spots = A.c.spots.map(s => '<section class="pm-card">' + head('data-pm="spot" data-id="' + esc(s.id) + '"', s.name || M.SPOT[s.spot], '') + (s.note ? '<p class="pm-quiet">' + esc(s.note) + '</p>' : '') + '</section>').join('');
      return (A.mode === 'full' ? '<p class="pm-k">Buildings</p>' : '') + order.map(card).join('') + spots;
    }
    // The usual places, one tap each, each shown on the map with its card: my room, the next thing on
    // today, and the places Help points to (First Aid, the Lodging Desk…).
    function quickChips() {
      const out = [], se = stayEnd();
      const chip = (attrs, icon, title, sub) => '<button type="button" class="pm-chip" ' + attrs + '>' + icon + '<span><b>' + esc(title) + '</b>' + (sub ? '<small>' + esc(sub) + '</small>' : '') + '</span></button>';
      if (se) out.push(chip('data-pm="set" data-v="stay"', I.bed, stayName(), staySub()));
      const nx = nextEvent();
      if (nx) out.push(chip('data-pm="room" data-code="' + esc(nx.code) + '" aria-label="Next: ' + esc(nx.title) + '"', I.clock, nx.title, 'Next' + (nx.start != null ? ' · ' + clock(nx.start) : '')));
      out.push(helpChips(3));
      return out.join('');
    }
    // The places Help names (First Aid, the Lodging Desk…), in Help's order, one tap each.
    function helpChips(max) {
      const chip = (attrs, icon, title) => '<button type="button" class="pm-chip" ' + attrs + '>' + icon + '<span><b>' + esc(title) + '</b></span></button>';
      return (A.ctx.help || []).filter(h => h.place && P(h.place) && routable(P(h.place))).slice(0, max || 99).map(h => chip('data-pm="room" data-code="' + esc(h.place) + '"', /aid|medic|nurse/i.test(h.need) ? I.cross : /lodg|room|key/i.test(h.need) ? I.bed : /lost|found/i.test(h.need) ? I.search : '<span class="pm-i" aria-hidden="true"></span>', h.need)).join('');
    }

    /* ------------------------------------------------ the sheet's heights (phone) */

    // Peek: just what's marked data-peek (the usual places, or a place's name and Directions), so the
    // map keeps well over half the screen; half: 60% (a place's card); full: nearly all.
    function heights() {
      const box = A.el.getBoundingClientRect().height || innerHeight * .7;
      const body = A.el.querySelector('.pm-body');
      const els = body ? Array.from(body.querySelectorAll('[data-peek]')) : [];
      let peek = 170;
      if (els.length) { peek = 44 + 14; els.forEach(e => { peek += e.getBoundingClientRect().height + 12; }); }
      peek = Math.round(Math.max(120, Math.min(peek, 250, box * .45)));
      return { peek, half: Math.max(peek + 80, Math.round(box * .6)), full: Math.round(box - 8) };
    }
    function setSheet(snap, ease) {
      if (A.mode !== 'full') return;
      A.snap = snap;
      const s = A.el.querySelector('.pm-sheet');
      s.classList.toggle('is-peek', snap === 'peek');
      const H = heights(), h = Math.max(H.peek, H[snap] || H.peek);
      s.classList.toggle('is-settling', !!ease);
      A.sheetH = h; A.el.style.setProperty('--pm-sheet', h + 'px');
      s.querySelector('.pm-grab').setAttribute('aria-label', snap === 'full' ? 'Less' : 'More');
      if (A.map) A.map.inset({ top: topInset(), bottom: h });
    }
    function sheetDrag() {
      const s = A.el.querySelector('.pm-sheet'), g = s.querySelector('.pm-grab');
      let y0 = null, h0 = 0, moved = 0;
      g.addEventListener('pointerdown', e => { y0 = e.clientY; h0 = A.sheetH; moved = 0; g.setPointerCapture(e.pointerId); s.classList.remove('is-settling'); });
      g.addEventListener('pointermove', e => { if (y0 == null) return; const d = y0 - e.clientY; moved = Math.max(moved, Math.abs(d)); const H = heights(); const h = Math.max(H.peek, Math.min(H.full, h0 + d)); A.sheetH = h; A.el.style.setProperty('--pm-sheet', h + 'px'); s.classList.toggle('is-peek', h < (H.peek + H.half) / 2); });
      const end = () => {
        if (y0 == null) return; y0 = null;
        const H = heights(), order = ['peek', 'half', 'full'];
        if (moved < 6) { setSheet(order[(order.indexOf(A.snap) + 1) % 3], true); return; }
        const near = order.reduce((m, k) => Math.abs(H[k] - A.sheetH) < Math.abs(H[m] - A.sheetH) ? k : m, 'peek');
        setSheet(near, true);
      };
      g.addEventListener('pointerup', end); g.addEventListener('pointercancel', end);
    }

    /* ------------------------------------------------ acting */

    function openBuilding(name) {
      const g = groups().find(z => { const w = where(z.main); return w.b && w.b.name === name; });
      if (g) return focus(g.main.code);
      // Any other building on the map (polish 3: a hall not confirmed is a building like the rest for the public).
      if (A.c.items.some(i => i.lab && i.name === name && i.name !== 'Building' && i.short !== '-')) { A.place = { kind: 'hall', name }; settle('half'); paint(true); say(name); }
    }
    function openSpot(id) { A.place = { kind: 'spot', id }; settle('half'); paint(true); say(spotName(id)); }
    // Where I sleep: my hall's card (its line says my rooms), or the camper lot.
    function openStay() {
      const s = A.stay, b = stayHall() && M.find(A.c, stayHall());
      if (s && s.type === 'camper' && camper()) openSpot(camper().id);
      else if (b) openBuilding(b.name);
    }
    // A place on the map, its sheet open: what a schedule row's place, a card's name or a tap leads to.
    function focus(code) {
      const p = P(code); if (!p) return;
      A.place = { code: p.code };
      settle('half');
      if (!A.map) { const w = where(p); A.pendingFocus = w.b ? roomy(M.boxOf(A.c, [w.b.name], 10), A.mode === 'full' ? .45 : .35) : w.kind === 'pin' ? { x: w.x - 60, y: w.y - 60, w: 120, h: 120 } : null; }
      paint(true);
      say(p.name);
      remember(p.code);
    }
    function settle(snap) { A.snap = snap; }
    const say = t => { if (A.ctx && A.ctx.say) A.ctx.say(t); };
    // The places opened lately (codes only), first in Search.
    function remember(code) {
      const r = LS.get('ogc-map-recent', []).filter(c => c !== code); r.unshift(code); LS.set('ogc-map-recent', r.slice(0, 4));
    }
    function endFrom(v) {
      if (v === 'stay') return { kind: 'stay' };
      if (v.indexOf('hall:') === 0) return { kind: 'hall', name: v.slice(5) };
      if (v.indexOf('spot:') === 0) return { kind: 'spot', id: v.slice(5) };
      const p = P(v); return p ? { kind: 'place', code: p.code, name: p.name } : null;
    }
    // A choice (a chip, a search result, a ?to= link): shown on the map with its card.
    function openEnd(e) {
      if (!e) return;
      if (e.kind === 'place') focus(e.code);
      else if (e.kind === 'hall') { const b = M.find(A.c, e.name); if (b) openBuilding(b.name); }
      else if (e.kind === 'spot') openSpot(e.id);
      else if (e.kind === 'stay') openStay();
    }

    /* ------------------------------------------------ searching */

    // Everything Search finds: buildings, rooms, halls, lots and the like, Help's
    // places, and every row of the schedule ("Volleyball" finds its field, mapped or not).
    function candidates(which) {
      const out = [];
      groups().forEach(g => {
        const b = where(g.main).b, words = b ? [b.name, b.short].concat(b.aliases, KIND_WORDS[b.kind] || []).join(' ') : '';
        // terms: its own search words and its features' (places.csv; Oct 13), matched whole in ranked().
        const terms = p => (p.search || []).concat(O.featureWords ? O.featureWords(p.features) : []);
        if (!g.derived) out.push({ v: g.main.code, main: g.name, sub: '', code: g.main.code, ok: routable(g.main), kind: 0, words, terms: terms(g.main) });
        (g.derived ? g.all : g.rooms).forEach(r => out.push({ v: r.code, main: inBuilding(r, g.name), sub: g.name, code: r.code, ok: routable(r), kind: 1, terms: terms(r) }));
      });
      A.c.items.filter(i => i.kind === 'hall' && i.lab && i.name !== 'Building').forEach(h => out.push({ v: 'hall:' + h.name, main: h.name, sub: /\bhall\b/i.test(h.name) ? '' : 'Hall', code: '', ok: true, kind: 2, words: h.aliases.join(' ') + ' hall dorm residence' }));
      // Every other named building, for typing ("Reed" finds Reed Hall whether or not it's a hall here).
      const listed = new Set(out.map(c => c.main));
      A.c.items.filter(i => i.kind !== 'hall' && i.lab && i.name && i.name !== 'Building' && i.short !== '-' && i.pts.length > 2 && /^(other|dining|worship|venue)$/.test(i.kind) && !groups().some(g => where(g.main).b === i) && !listed.has(i.name)).forEach(b => out.push({ v: 'hall:' + b.name, main: b.name, sub: '', code: '', ok: true, kind: 2, words: (b.short || '') + ' ' + b.aliases.join(' ') }));
      A.c.spots.forEach(s => out.push({ v: 'spot:' + s.id, main: s.name || M.SPOT[s.spot], sub: s.name ? M.SPOT[s.spot] : '', code: '', ok: true, kind: 2, words: (M.SPOT[s.spot] || '') + ' ' + (SPOT_WORDS[s.spot] || '') + ' ' + (s.note || '') }));
      (A.ctx.help || []).filter(h => h.place && P(h.place)).forEach(h => out.push({ v: P(h.place).code, main: h.need, sub: P(h.place).name, code: P(h.place).code, ok: routable(P(h.place)), kind: 1, words: h.text || '', terms: h.search || [] }));
      (A.ctx.events ? A.ctx.events() : []).filter(e => e.code).forEach(e => { const p = P(e.code); out.push({ v: p ? p.code : '', main: e.title, sub: [e.when, p ? p.name : ''].filter(Boolean).join(' · '), code: p ? p.code : '', ok: !!p && routable(p), kind: 3, et: e.title, es: e.start == null ? '' : e.start }); });
      return out;
    }
    // Best first: the name itself, then names starting with it, then a word starting with it, then
    // anywhere in the name, then the code, then the line under it (polish 1: "first aid" put Barnes
    // above the First Aid Room).
    // Polish 2: also the words a place goes by ("dining", "cafeteria", "food" find Barnes; "parking",
    // "info" find the lots and the desk), what people say for what the campus calls it ("bathroom" is a
    // restroom), and a one-letter slip in a word of five letters or more ("barns"; places only: "parking"
    // isn't "Kit packing").
    function ranked(list, t) {
      const T = t.toUpperCase(), alts = [t].concat(SYN[t] || []);
      const words = s => String(s || '').toLowerCase().split(/[\s(/·,&-]+/).filter(Boolean);
      const slip = (w, q) => { if (q.length < 5 || Math.abs(w.length - q.length) > 1) return false; let i = 0, j = 0, e = 0; while (i < w.length && j < q.length) { if (w[i] === q[j]) { i++; j++; continue; } if (++e > 1) return false; if (w.length > q.length) i++; else if (q.length > w.length) j++; else { i++; j++; } } return e + (w.length - i) + (q.length - j) <= 1; };
      const one = (c, t) => { const n = c.main.toLowerCase(); if (n === t || c.code === T) return 0; if (n.indexOf(t) === 0) return 1; if (words(n).some(w => w.indexOf(t) === 0)) return 2; if (n.indexOf(t) > -1) return 3; if (c.code && c.code.indexOf(T) === 0) return 3.5; if (c.terms && (c.terms.indexOf(t) > -1 || (t.length > 3 && /s$/.test(t) && c.terms.indexOf(t.slice(0, -1)) > -1))) return 3.8; if (words(c.words).some(w => w.indexOf(t) === 0)) return 4; if (c.sub.toLowerCase().indexOf(t) > -1) return 5; if (c.kind !== 3 && words(n + ' ' + (c.words || '')).some(w => slip(w, t))) return 6; return Infinity; };
      const score = c => Math.min.apply(null, alts.map((a, i) => one(c, a) + (i ? .5 : 0)));
      const seen = new Set();
      return list.map(c => Object.assign({ s: score(c) }, c)).filter(c => c.s < Infinity).sort((a, b) => a.s - b.s || a.kind - b.kind || a.main.length - b.main.length)
        .filter(c => { const k = c.v + '|' + c.main; if (seen.has(k)) return false; seen.add(k); return true; }).slice(0, 40);
    }
    const resultRow = (which, c) => { const miss = !c.ok && member(A.ctx.year) ? 'Not on the map yet' : ''; return '<li><button type="button" data-pm="set" data-which="' + which + '" data-v="' + esc(c.v) + '"' + (c.et ? ' data-et="' + esc(c.et) + '" data-es="' + esc(c.es) + '"' : '') + (c.ok || (which === 'search' && c.v) ? '' : ' disabled') + '><span><b>' + esc(c.main) + '</b>' + (c.sub || miss ? '<small>' + esc([c.sub, miss].filter(Boolean).join(' · ')) + '</small>' : '') + '</span>' + (c.code ? '<code>' + esc(c.code) + '</code>' : '') + '</button></li>'; };
    // Search's body: the usual places; with nothing typed, Recent, every building with its rooms, the
    // halls, and parking and services; as you type, the ranked results.
    function pickBody(which) {
      const recent = LS.get('ogc-map-recent', []).map(P).filter(Boolean).filter(p => routable(p));
      const gs = groups().filter(g => where(g.main).kind !== 'none');
      const halls = A.c.items.filter(i => i.kind === 'hall' && i.lab && i.name !== 'Building' && !gs.some(g => where(g.main).b === i));
      const li = (v, main, sub, code) => '<li><button type="button" data-pm="set" data-which="' + which + '" data-v="' + esc(v) + '"><span><b>' + esc(main) + '</b>' + (sub ? '<small>' + esc(sub) + '</small>' : '') + '</span>' + (code ? '<code>' + esc(code) + '</code>' : '') + '</button></li>';
      const chips = quickChips(), help = helpChips();
      return '<label class="pm-q"><span class="ogc-sr">Search</span><input type="search" data-pmq data-which="' + which + '" placeholder="Building, room or code" autocomplete="off" enterkeyhint="search"><button type="button" class="pm-qx" data-pm="qx" aria-label="Clear" title="Clear" hidden>' + I.close + '</button></label><div class="pm-pickbody">' +
        (chips ? '<div class="pm-quick" data-quick>' + chips + '</div>' : '') +
        '<ul class="pm-list" data-results hidden></ul><div data-none hidden><p class="pm-none">No results</p>' + (help ? '<div class="pm-quick">' + help + '</div>' : '') + '</div>' +
        '<ul class="pm-list" data-list>' +
        (recent.length ? '<li data-sec><p class="pm-k">Recent</p></li>' + recent.map(p => li(p.code, roomName(p), String(p.code).indexOf('/') > -1 ? bShort(where(p).b) : '', p.code)).join('') : '') +
        '<li data-sec><p class="pm-k">Buildings</p></li>' +
        gs.map(g => {
          const head = g.derived ? '<p class="pm-list__h">' + esc(g.name) + '</p>' : li(g.main.code, g.name, '', g.main.code);
          return '<li class="pm-list__g"><ul>' + head + (g.derived ? g.all : g.rooms).map(r => '<li class="pm-list__r">' + li(r.code, inBuilding(r, g.name), '', r.code).slice(4)).join('') + '</ul></li>';
        }).join('') +
        (halls.length ? '<li data-sec><p class="pm-k">Halls</p></li>' + halls.map(h => li('hall:' + h.name, h.name, '', '')).join('') : '') +
        (A.c.spots.length ? '<li data-sec><p class="pm-k">Parking and services</p></li>' + A.c.spots.map(s => li('spot:' + s.id, s.name || M.SPOT[s.spot], s.name ? M.SPOT[s.spot] : '', '')).join('') : '') +
        '</ul></div>';
    }
    // Search opens full height with the field at the top, focused even on a phone (polish 1: a short
    // sheet with its field under the keyboard, a second tap to type).
    function picker() {
      dlg.classList.add('is-search', 'is-full');
      dlg.innerHTML = '<div class="wk-sheet__in pm-pickin"><button type="button" class="wk-sheet__x" data-close aria-label="Close">' + I.close + '</button>' +
        '<h2 class="ogc-sr" id="pm-pick-t">Search</h2>' + pickBody('search') + '</div>';
      dlg.showModal();
      const q = dlg.querySelector('[data-pmq]'); if (q) q.focus();
    }
    // Typing: the list becomes the ranked results; "No results" when nothing matches.
    function filter(input) {
      const box = input.closest('.pm-pickin'); if (!box) return;
      const t = input.value.trim().toLowerCase(), which = input.dataset.which;
      box.querySelectorAll('[data-quick]').forEach(e => { e.hidden = !!t; });
      const qx = box.querySelector('.pm-qx'); if (qx) qx.hidden = !input.value;
      box.querySelector('[data-list]').hidden = !!t;
      const res = box.querySelector('[data-results]'), none = box.querySelector('[data-none]');
      const hits = t ? ranked(candidates(which), t) : [];
      res.innerHTML = hits.map(c => resultRow(which, c)).join('');
      res.hidden = !t || !hits.length; none.hidden = !t || !!hits.length;
    }
    function clearQ(lab) { const q = lab && lab.querySelector('[data-pmq]'); if (!q) return; q.value = ''; filter(q); q.focus(); }
    function onInput(e) { if (e.target.matches('[data-pmq]')) filter(e.target); }
    function onKey(e) {
      if (!e.target.matches('[data-pmq]')) return;
      if (e.key === 'Enter') { e.preventDefault(); const box = e.target.closest('.pm-pickin'), b = box && box.querySelector('[data-results]:not([hidden]) button:not([disabled])'); if (b) b.click(); }
    }
    dlg.addEventListener('input', onInput);
    dlg.addEventListener('keydown', onKey);
    // A choice: shown on the map with its card.
    function choose(b) { openEnd(endFrom(b.dataset.v)); }
    dlg.addEventListener('click', e => {
      if (e.target === dlg || e.target.closest('[data-close]')) { dlg.close(); return; }
      if (e.target.closest('[data-pm="qx"]')) { clearQ(e.target.closest('.pm-q')); return; }
      const b = e.target.closest('[data-pm="set"], [data-pm="room"]'); if (!b || b.disabled) return;
      dlg.close();
      if (b.dataset.pm === 'room') { focus(b.dataset.code); return; }
      choose(b);
    });

    function onClick(e) {
      const b = e.target.closest('[data-pm]'); if (!b || !A.el.contains(b) || b.disabled) return;
      const k = b.dataset.pm;
      if (k === 'search') picker();
      else if (k === 'close') { A.place = null; settle('peek'); paint(); }
      else if (k === 'room') focus(b.dataset.code);
      else if (k === 'spot') openSpot(b.dataset.id);
      else if (k === 'more-today') { A.allToday = true; paint(); }
      else if (k === 'event') { if (A.ctx.openEvent) A.ctx.openEvent(b.dataset.id); }
      else if (k === 'families') { A.place = { kind: 'families' }; settle('half'); paint(); say('For families'); }
      else if (k === 'locate') locate();
      else if (k === 'set') choose(b);
    }
    document.addEventListener('click', e => { if (A.el && !A.hidden && A.el.contains(e.target)) onClick(e); });

    const api = {
      mount, hide, focus,
      // A place by its code, a hall ("hall:Reed Hall") or a spot ("spot:<id>"): shown with its card.
      open: v => openEnd(endFrom(String(v))),
      search: () => picker(),
      destroy() { hide(); if (A.el) A.el.remove(); dlg.remove(); },
      get state() { return A; }
    };
    if (window.OGC_WP && OGC_WP.dev) M.devApp = api;
    return api;
  }

  M.app = app;
  // A feature's line icon, for the guide's own sheets (Oct 13).
  M.featureIcon = f => I['f-' + f] || '';
})();
