/*
 * ogc-map-app.js — the guide's Places: the campus map, to see where things are (the map area, Oct 10).
 *
 * On a phone (the guide), Places is the map, full height, with a sheet over it (peek: the usual places,
 * one tap each; half: a place; full: every building). On a laptop the map has its panel beside it when
 * the column is wide (a container query, not the window), else above it.
 *
 * Directions are ours, end to end (Michael, Nov 4, replacing Oct 13's "rely on Google Maps"; docs/34
 * §4.5, §5.1): a place's Directions opens the planner here, in the sheet (a phone) or the floating panel
 * (a laptop). From and To (each a row that opens its own Search), Swap, the Step-free switch (kept on this
 * device; on when the signed-in household ticked No stairs), then the time, the distance and arrival, the
 * legs, Start (a phone) and Steps. The route is ogc-map-route.js's plan over the campus's one router
 * (Dijkstra; the steps are its fixed sentences); the map draws it (viewer.route), names its door, puts a
 * pill where it changes floor and opens the destination's building on the room's floor. From is My
 * location on a phone on campus to 40 m, else My room, else Choose start; inside a drawn building it's
 * "Barnes · Set start", and one tap on the opened floor sets it. On a laptop the steps are listed in full
 * and a step hovered or focused is framed on its floor. A campus with no floor plans gets the same planner
 * outdoors to the building's door, from campus.csv's paths. Nothing goes to Google Maps.
 *
 * week.js hands it what the page knows (ctx): the year, the campus (O.map.campus), the places, today's
 * rows with their state, every row (for search), the Help cards, the time, and how to open an event.
 * It keeps its own state between drawings of the page (the map keeps its place).
 *
 * Nov 5 (docs/34 §4, §5.1; the map area): where the year's campus has a public build of its floor plans
 * (ogc-map-floors.js), the map opens buildings in place. A place's sheet opens its building on the room's
 * floor, the room in tan with the line from the best door; its sheet says the building, floor and code,
 * what's on there today, and the nearest restroom and elevator along the halls. The peek is Next and My
 * room over one strip (Restrooms · First Aid · Information · Dining · For families); Search finds IWU's
 * own numbers ("143", "Barnes 143"); on a laptop the map is the whole canvas with a floating panel.
 * A campus with no build is as before.
 *
 * Start, on a phone (docs/34 §4.6–4.10): the head and tabs slide away and the map takes the screen. Outdoors,
 * a step card at the top (‹ ›) and a bar at the foot (Arrive, what's left, End); the map follows the dot,
 * north up, until it's panned (Recenter brings it back); a step moves on 12 m before its end; 25 m off the
 * route for 10 s replans from here with no motion ("Rerouting"); "Approximate location" over 40 m; the dot
 * greys after 30 s with no fix. At the door (15 m, or ‹ › to it), Next on the card opens the building on
 * the door's floor; inside, the steps are a sheet at the foot (Back, Next, a swipe), the step's stretch
 * framed with a ring where it starts and no dot; a floor change plays §4.9's drop and rise. Arrived:
 * the sign and its side, then Done to the place's sheet. Wake Lock where allowed; the compass asked once
 * (an iPhone asks from Start's tap) and its wedge only while following. The location stops when the page
 * is hidden. Where the demo's pills show (local and the shared link), "Mockup: walk it" moves the dot
 * along the route at three times walking speed.
 *
 * Nothing about where someone is leaves the phone: the location is used while Places is open and
 * stopped when it closes or the page is hidden; "My room" comes from the server for the signed-in
 * person alone (/me/stay). Recent places (codes only) stay on this device.
 */
(function () {
  'use strict';
  const O = window.OGC, esc = O.esc, M = O.map;
  if (!M) return;
  // A name with a dash in it ("South-west doors", "Rooms A–D") never breaks at the dash (round 2 checks).
  const nb = s => esc(s).replace(/[^\s<>]*[A-Za-z0-9][-–][A-Za-z0-9][^\s<>]*/g, m => '<span class="pm-nw">' + m + '</span>');
  const svg = d => '<svg class="pm-i" viewBox="0 0 24 24" aria-hidden="true"><path d="' + d + '" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  const I = {
    search: svg('M10.5 17a6.5 6.5 0 1 0 0-13 6.5 6.5 0 0 0 0 13ZM15.3 15.3l4.7 4.7'),
    dirs: svg('M12 3.5 20.5 12 12 20.5 3.5 12ZM9.5 13.5v-2.5h4.5M12.5 9l2 2-2 2'),
    pin: svg('M12 20.5s-6.5-5.4-6.5-10.8a6.5 6.5 0 0 1 13 0c0 5.4-6.5 10.8-6.5 10.8ZM12 12a2.3 2.3 0 1 0 0-4.6 2.3 2.3 0 0 0 0 4.6Z'),
    close: svg('M6.5 6.5l11 11M17.5 6.5l-11 11'),
    locate: svg('M12 3v3M12 18v3M3 12h3M18 12h3M12 17a5 5 0 1 0 0-10 5 5 0 0 0 0 10Z'),
    bed: svg('M3.5 18.5v-11M3.5 14.5h17v4M20.5 14.5v-2.5a2.5 2.5 0 0 0-2.5-2.5h-7v5M7 12.2a1.6 1.6 0 1 0 0-3.2 1.6 1.6 0 0 0 0 3.2Z'),
    clock: svg('M12 20.5a8.5 8.5 0 1 0 0-17 8.5 8.5 0 0 0 0 17ZM12 7.5V12l3 2'),
    cross: svg('M9.5 4.5h5v5h5v5h-5v5h-5v-5h-5v-5h5Z'),
    desk: svg('M4.5 9.5h15v10h-15ZM9.5 9.5v-4h5v4'),
    dining: svg('M7 3.5v7a2 2 0 0 0 2 2v8M5 3.5v5.5M9 3.5v5.5M17 20.5V3.5c-2.2 1.2-3.5 4-3.5 7.5H17'),
    next: svg('M9.5 5.5 16 12l-6.5 6.5'),
    swap: svg('M8 4.5v15M4.5 8 8 4.5 11.5 8M16 19.5v-15M12.5 16l3.5 3.5 3.5-3.5'),
    // The menu mark signed out (⋯), and the building chip's building (docs/35 §2.2).
    more: '<svg class="pm-i" viewBox="0 0 24 24" aria-hidden="true"><circle cx="5.5" cy="12" r="1.7" fill="currentColor"/><circle cx="12" cy="12" r="1.7" fill="currentColor"/><circle cx="18.5" cy="12" r="1.7" fill="currentColor"/></svg>',
    building: svg('M4.5 20.5h15M6.5 20.5v-15h7v15M13.5 9.5h4v11M9 8.5h2M9 11.5h2M9 14.5h2'),
    // The steps' and the legs' icons (ogc-map-route.js's icon names), one plain line icon each.
    'r-straight': svg('M12 20.5V4.5M6.5 10 12 4.5 17.5 10'),
    'r-left': svg('M17 20.5V13a4 4 0 0 0-4-4H5.5M9.5 5 5.5 9l4 4'),
    'r-right': svg('M7 20.5V13a4 4 0 0 1 4-4h7.5M14.5 5l4 4-4 4'),
    'r-slight-left': svg('M14.5 20.5V14L7 6.5M7 12.5v-6h6'),
    'r-slight-right': svg('M9.5 20.5V14L17 6.5M17 12.5v-6h-6'),
    // (a fork, the arrow on the way to take; a turn back on itself)
    'r-keep-left': svg('M12 20.5V13L7 6.5M7 12V6.5h5.5M12 13l5-6.5'),
    'r-keep-right': svg('M12 20.5V13l5-6.5M17 12V6.5h-5.5M12 13 7 6.5'),
    'r-sharp-left': svg('M16 20.5V9.5a3.5 3.5 0 0 0-6.5-1.8L6 16M6 11.5V16h4.5'),
    'r-sharp-right': svg('M8 20.5V9.5a3.5 3.5 0 0 1 6.5-1.8L18 16M18 11.5V16h-4.5'),
    'r-cross': svg('M3.5 5.5h17M3.5 18.5h17M7 9v6M12 9v6M17 9v6'),
    'r-door': svg('M6.5 20.5v-16h11v16M4 20.5h16M14.5 12.5v.01'),
    'r-stairs': svg('M3.5 19.5h4.5v-4h4v-4h4v-4h4.5'),
    'r-stairs-up': svg('M3.5 20h4v-3.5h4V13h4V9.5h5M5 9.5l5-5M6.5 4.5H10V8'),
    'r-stairs-down': svg('M3.5 20h4v-3.5h4V13h4V9.5h5M10 4.5l-5 5M5 6v3.5h3.5'),
    'r-elevator': svg('M5.5 3.5h13v17h-13ZM9.5 9.5 12 7l2.5 2.5M9.5 14.5 12 17l2.5-2.5'),
    'r-arrive': svg('M12 20.5s-6.5-5.4-6.5-10.8a6.5 6.5 0 0 1 13 0c0 5.4-6.5 10.8-6.5 10.8ZM9.3 9.8l1.9 1.9 3.6-3.6'),
    'r-walk': svg('M13.5 5.5a1.6 1.6 0 1 0 0-3.2 1.6 1.6 0 0 0 0 3.2ZM10 21l2.2-6 2.8 2.6V21M8 12l2.3-3.6h3.2l2 3.1 2.5 1M12.7 8.4l-1.4 6'),
    // A place's features (places.csv `features`; Oct 13, from Andrew's guide), one plain line icon each.
    'f-nursery': svg('M10.5 3.5h3l.5 2.5h-4ZM9 6h6v2.5H9ZM10 8.5h4a1.5 1.5 0 0 1 1.5 1.5v9a1.5 1.5 0 0 1-1.5 1.5h-4A1.5 1.5 0 0 1 8.5 19v-9A1.5 1.5 0 0 1 10 8.5ZM8.5 12.5h3M8.5 15.5h3'),
    'f-restroom': svg('M12 6.5a1.75 1.75 0 1 0 0-3.5 1.75 1.75 0 0 0 0 3.5ZM9 20.5v-6.5l-1-.5V10a1.5 1.5 0 0 1 1.5-1.5h5A1.5 1.5 0 0 1 16 10v3.5l-1 .5v6.5M12 14.5v6'),
    'f-family restroom': svg('M8.5 6.5a1.75 1.75 0 1 0 0-3.5 1.75 1.75 0 0 0 0 3.5ZM5.5 20.5v-6.5l-1-.5V10A1.5 1.5 0 0 1 6 8.5h5A1.5 1.5 0 0 1 12.5 10v3.5l-1 .5v6.5M17 11a1.4 1.4 0 1 0 0-2.8 1.4 1.4 0 0 0 0 2.8ZM15 20.5v-4l-.7-.5v-2.2a1 1 0 0 1 1-1h3.4a1 1 0 0 1 1 1V16l-.7.5v4'),
    'f-accessible entrance': svg('M10.5 5.5a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3ZM10.5 7.5V13h5l2.5 5.5M10.5 10h4.5M8 10.6a5.2 5.2 0 1 0 7.6 6.6'),
    'f-elevator': svg('M5.5 3.5h13v17h-13ZM9.5 9.5 12 7l2.5 2.5M9.5 14.5 12 17l2.5-2.5'),
    'f-quiet room': svg('M19 14.5A7.5 7.5 0 0 1 9.5 5a7.5 7.5 0 1 0 9.5 9.5Z')
  };
  // The words a place goes by, beyond its name (search).
  const KIND_WORDS = { dining: ['dining', 'cafeteria', 'food', 'meals', 'lunch', 'dinner', 'breakfast'], worship: ['chapel', 'worship', 'services', 'auditorium'], venue: ['theater', 'hall'], hall: ['hall', 'dorm', 'residence'] };
  const SPOT_WORDS = { parking: 'parking lot cars', accessible: 'parking accessible handicap', camper: 'campers rv lot', carts: 'golf carts cart ride', desk: 'information info desk help' };
  const SYN = { bathroom: ['restroom'], bathrooms: ['restroom'], toilet: ['restroom'], washroom: ['restroom'], food: ['dining'], eat: ['dining'], meals: ['dining'], cafeteria: ['dining'], info: ['information'], doctor: ['first aid'], nurse: ['first aid'], medical: ['first aid'], gym: ['recreation', 'arena'], dorm: ['hall'] };
  const LS = { get: (k, d) => { try { const v = localStorage.getItem(k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } }, set: (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { /* fine */ } } };
  const coarse = () => !!(window.matchMedia && matchMedia('(pointer: coarse)').matches);
  // Members (the pins tool's people) are told what the map is missing; the public only what's useful.
  const W = () => window.OGC_WP || {};
  const member = y => !!(W().webmaster || (W().member || []).map(String).indexOf(String(y)) > -1);
  const touch = () => coarse() && 'geolocation' in navigator;

  function app() {
    const A = { el: null, ctx: null, c: null, map: null, mapEl: null, mode: '', place: null, nav: { me: null, status: '' }, sheetH: 0, snap: 'peek', scrolled: {}, stay: null, stayAsked: false, watch: null, perm: '', hidden: true,
      // The floor plans (Nov 5): plans is known at once (OGC_WP.floors names the year's build); P and L come after.
      plans: false, P: null, L: null, destKey: '', destInfo: null, fitKey: '', near: {}, feats: {}, origin: null,
      // The planner (Nov 5): dir is what's open ({ to, from, plan, … }); build, the router's build (once a year).
      dir: null, build: null, plansWait: [] };
    // The phone's sheet (O.sheet.docked, ogc-sheet.js; docs/35 §2.3), made with the phone's frame.
    let SH = null;
    const dlg = document.createElement('dialog');
    dlg.className = 'ogc wk-sheet pm-pick';
    dlg.setAttribute('aria-labelledby', 'pm-pick-t');
    document.body.appendChild(dlg);

    /* ------------------------------------------------ what the page knows */

    const places = () => A.ctx.places || {};
    const P = code => code ? places()[String(code).toUpperCase()] || null : null;
    const keyOf = code => String(code).split('/')[0].toUpperCase();
    // A room named for its building ("Piazza Terrace (Barnes)") drops the building in its own card.
    const inBuilding = (room, b) => String(room.name).replace(/\s*\(([^)]+)\)$/, (m, w) => String(b).toLowerCase().indexOf(w.split(' ')[0].toLowerCase()) > -1 ? '' : m);
    // The buildings people go to, in places.csv's order, each with its rooms. A building listed only by
    // its rooms (Cedarville's "Stevens Student Center Room 241") is named for the building, not a room.
    function groups() {
      const out = [], by = {};
      Object.keys(places()).forEach(k => {
        const p = places()[k], key = keyOf(p.code);
        if (!by[key]) out.push(by[key] = { key, main: null, rooms: [] });
        if (String(p.code).toUpperCase() === key) by[key].main = p; else by[key].rooms.push(p);
      });
      return out.filter(g => g.main || g.rooms.length).map(g => {
        if (g.main) return Object.assign(g, { name: g.main.name, all: g.rooms });
        const r = g.rooms[0], name = r.building || String(r.name).replace(/\s*(room|rm\.?|#)\s*[\w–-]+$/i, '') || r.name;
        return Object.assign(g, { main: r, name, all: g.rooms, derived: true });
      });
    }
    const where = p => M.whereIs(A.c, p, places());
    // The halls with rooms this year: rooms.csv for those who may read it, else the campus's own mark.
    const stayHalls = () => Array.from(new Set((A.ctx.halls || []).concat(A.c.items.filter(i => i.stay && i.lab).map(i => i.name))));
    // Directions can take you there: a pin, or a building (a field not pinned yet can't; members are told so).
    // (A field not pinned yet, beside a building, is walked to that building's door: Nebraska Green and the
    // Multi-Purpose Field to the Rec Center's, the route saying so. Round 2 part 2: they were dead ends.)
    const routable = p => { const w = p && where(p); return !!(w && (w.kind === 'pin' || w.kind === 'building' || (w.kind === 'outdoor' && w.b))); };
    // Directions (Nov 5): the planner, here, to what's open (endOfPlace). The one filled button on its card;
    // none for a place the map can't find (a field not pinned yet).
    const dirsBtn = ok => ok ? '<p class="pm-btns"><button type="button" class="pm-btn" data-pm="dirs">' + I.dirs + 'Directions</button></p>' : '';
    const dirsTo = p => dirsBtn(routable(p));
    const today = () => (A.ctx.today ? A.ctx.today() : []);
    // The next thing on today (the Conference's own rows), for "Next".
    function nextEvent() {
      return today().filter(it => it.code && P(it.code) && !it.allDay && (it.state === 'upcoming' || it.state === 'now') && (!it.audience || it.audience === 'conference' || it.audience === 'all'))
        .sort((a, b) => (a.state === 'now') - (b.state === 'now') || (a.start == null ? 1e9 : a.start) - (b.start == null ? 1e9 : b.start))[0] || null;
    }
    // The guide's own way to say a time ("11:00 PM ET" to a reader in another zone), as Today says it.
    const clock = m => { const t = ((m % 1440) + 1440) % 1440; return A.ctx && A.ctx.clock ? A.ctx.clock(t) : O.formatTime(t); };
    // Arrive: now plus the seconds left, rounded once (the summary and the walk's bar both). Rounding the
    // minutes left on their own and adding them to the minute made it tick back a minute as the walk went.
    const arriveAt = (mins, secLeft) => 'Arrive ' + clock(Math.round(mins + secLeft / 60));
    // The schedule's own short names for buildings ("PPAC", not "Phillippe").
    let shorts = {};
    // A building as the schedule names it ("PPAC", not campus.csv's "Phillippe"), everywhere a building is said.
    const bShort = b => b ? shorts[b.name] || M.shortOf(b) : '';
    // A building's own schedule code ("N" for Hodson Hall), as its name on the map has it; '' when it has none.
    const bCode = b => { if (!b) return ''; const g = groups().find(z => !z.derived && String(z.main.code).indexOf('/') < 0 && (where(z.main).b || {}).name === b.name); return g ? g.key : ''; };
    // What tells a room apart, beyond its own name: "First Aid Room (Barnes Room 131)" → "Room 131".
    const roomRest = (room, b) => { const m = /\(([^)]+)\)$/.exec(String(room.name)); if (!m || String(b).toLowerCase().indexOf(m[1].split(' ')[0].toLowerCase()) < 0) return ''; const r = /\b(rooms?|rm\.?)\s+\S.*$/i.exec(m[1]); return r ? r[0].charAt(0).toUpperCase() + r[0].slice(1) : ''; };
    // A room by its own name ("First Aid Room"); the building and number go on the line under it.
    const roomName = p => { const b = where(p).b; return String(p.code).indexOf('/') > -1 && b ? inBuilding(p, b.name) : p.name; };

    /* ------------------------------------------------ the floor plans (Nov 5) */

    // A place in the build: its building's code and its rooms there ([] for a whole building); null with
    // no build, or for a place the build has no room for (the Chapel Loft, a field).
    function planOf(p) {
      if (!A.P || !p) return null;
      const rooms = A.P.roomsOf(p.code), B = A.P.by[keyOf(p.code)];
      return rooms && B && B.ok ? { code: B.code, B, rooms, place: String(p.code).toUpperCase() } : null;
    }
    const planFloor = p => { const pl = planOf(p); return pl && pl.rooms.length ? +pl.rooms[0].floor : null; };
    // What's open, as the map marks it: a place, or one of its rooms by IWU's name (the Chapel's Balcony:
    // that room alone, on its floor, named so; the last checks: going to the balcony tinted the 1st floor's
    // Auditorium as where you were going, and its sheet said "1st floor").
    function planFor(t) {
      const pl = t && t.code ? planOf(P(t.code)) : null, rm = t && t.room;
      if (!pl || !rm) return pl;
      return Object.assign({}, pl, { rooms: [{ floor: +rm.floor, number: String(rm.number) }], place: pl.place + '|' + rm.floor + '|' + rm.number, name: rm.name, room: rm });
    }
    // "Barnes · 1st floor · B/HW" (§4.3): the building, the floor, the code; the room's number is in its name.
    function factLine(p, isMain) {
      const w = where(p), fl = planFloor(p);
      return [isMain ? '' : (w.b ? bShort(w.b) : ''), fl != null ? M.floorName(fl) : '', isMain ? '' : p.code].filter(Boolean).join(' · ');
    }
    // A room's name on the map, without its building: "PPAC Room 150" → "Room 150", "Chapel Auditorium" → "Auditorium".
    function mapName(code) {
      const p = P(code); if (!p) return code;
      const b = where(p).b, n = roomName(p), sh = b ? bShort(b) : '';
      const lead = [sh, b ? b.name : ''].filter(Boolean).find(w => n.toLowerCase().indexOf(w.toLowerCase() + ' ') === 0);
      return lead ? n.slice(lead.length + 1) : n;
    }
    const doorRow = id => A.c.doors.find(d => d.id === id) || null;

    // Features (places.csv `features`, one fixed list; Oct 13, from Andrew's guide): a building's own,
    // and its rooms' with the room they're in ("Nursery · Room 114"). Only what a row says is shown.
    const FAMILY = ['nursery', 'family restroom', 'quiet room'];
    const featWord = f => (O.FEATURES && O.FEATURES[f]) || f;
    function featuresIn(g) {
      return (g.derived ? [] : (g.main.features || []).map(f => ({ f, room: null }))).concat([].concat.apply([], (g.derived ? g.all : g.rooms).map(r => (r.features || []).map(f => ({ f, room: r })))));
    }
    // A feature's row: its icon and word, and the room (a room's row opens that room on the map).
    // withB: the building too ("Room 114 · Chapel"), in the campus-wide list.
    function featRow(x, g, withB) {
      const r = x.room ? (roomRest(x.room, g.name) || inBuilding(x.room, g.name)) : '', b = withB ? (where(g.main).b ? bShort(where(g.main).b) : g.name) : '';
      const where_ = [r && r.toLowerCase() !== featWord(x.f).toLowerCase() ? r : '', b].filter(Boolean).join(' · ');
      const inner = (I['f-' + x.f] || '') + '<span><b>' + esc(featWord(x.f)) + '</b>' + (where_ ? '<small>' + esc(where_) + '</small>' : '') + '</span>';
      return '<li>' + (x.room ? '<button type="button" class="pm-feat" data-pm="room" data-code="' + esc(x.room.code) + '">' + inner + (x.room.code ? '<code>' + esc(x.room.code) + '</code>' : '') + '</button>' : '<div class="pm-feat">' + inner + '</div>') + '</li>';
    }
    // Every place with a family feature, campus-wide ("For families").
    const familyPlaces = () => [].concat.apply([], groups().map(g => featuresIn(g).filter(x => FAMILY.indexOf(x.f) > -1).map(x => Object.assign({ g }, x))));

    /* ------------------------------------------------ where I sleep, and what a place is called */

    // My hall: a dorm stay's, or a Youngfolk's one hall (from /me/stay).
    function stayHall() { const s = A.stay; if (!s) return ''; if (s.type === 'dorm' && s.rooms && s.rooms.length) return s.rooms[0].hall; if (s.type === 'yf' && s.halls && s.halls.length === 1) return s.halls[0]; return ''; }
    const camper = () => A.c.spots.find(s => s.spot === 'camper');
    // Where I sleep, as one of the usual places (a chip that shows it on the map).
    function stayEnd() {
      const s = A.stay; if (!s) return null;
      if (s.type === 'camper' && camper()) return { kind: 'stay' };
      return stayHall() ? { kind: 'stay' } : null;
    }
    const stayName = () => A.stay && A.stay.type === 'camper' ? 'Camper lot' : A.stay && A.stay.type === 'yf' ? 'My hall' : 'My room';
    // "Reed Hall · 2nd floor · 211, 212" (the floor of the first room; polish 2).
    // short: without the room numbers ("Hodson Hall · 2nd floor", the peek's row).
    // noHall: without the hall's name, under a title that says it (the floor, then the household's rooms).
    function staySub(short, noHall) { const s = A.stay; if (s && s.type === 'dorm' && s.rooms && s.rooms.length) { const fl = Array.from(new Set(s.rooms.map(r => +r.floor || 0).filter(Boolean))); return [noHall ? '' : s.rooms[0].hall, fl.length === 1 ? M.floorName(fl[0]) : '', short ? '' : s.rooms.map(r => r.num).join(', ')].filter(Boolean).join(' · '); } return noHall ? '' : stayHall(); }
    const spotName = id => { const s = A.c.spots.find(x => x.id === id); return s ? s.name || M.SPOT[s.spot] : 'Spot'; };
    // A pinned place's name on its pin, as the map says it: "Piazza Terrace", "First Aid Room", "PPAC".
    function pinName(p) {
      const b = where(p).b;
      if (String(p.code).indexOf('/') > -1) return b ? inBuilding(p, b.name) : p.name;
      return b ? shorts[b.name] || M.shortOf(b) : p.name;
    }

    /* ------------------------------------------------ location (the phone only) */

    // Near enough to walk from (§4.11): within 1.5 km of the campus (Washington St, the town around it).
    const near = p => M.onCampus(A.c, p, 1500);
    function locate() {
      const n = A.nav;
      if (!touch()) return;
      if (A.watch != null) { if (n.me && near(n.me)) A.map.centre(n.me, true); return; }
      n.status = 'Locating';
      if (!A.walk) paint();
      A.watch = navigator.geolocation.watchPosition(pos => {
        const p = M.toMap(A.c, pos.coords.latitude, pos.coords.longitude);
        if (!p) return;
        p.acc = pos.coords.accuracy;
        // (The fix itself too, for the planner's From: ogc-map-route.js takes { lat, lng }.)
        p.lat = pos.coords.latitude; p.lng = pos.coords.longitude;
        const first = !n.me;
        n.me = p; A.perm = 'granted';
        n.status = !near(p) ? 'Not on campus' : p.acc > 40 ? 'Approximate location' : '';
        // Walking (Start): the walk follows the fix, and nothing else is drawn again.
        if (A.walk) { walkFix(); return; }
        paint();
        // (A Restrooms or First Aid chip waiting for this: its list, nearest from here, round 2.)
        if (A.wantNearest) { nearestDue(); return; }
        // With the planner open, it plans from here (or again, as you move); it frames the route, not you.
        if (A.dir) onFix(); else if (first && near(p)) A.map.centre(p, true);
      }, err => {
        n.status = err && err.code === 1 ? 'Location off' : 'Location unavailable';
        if (err && err.code === 1) A.perm = 'denied';
        // (Walking, a fix that's late isn't the end: the watch keeps on, and 30 s without one greys the dot.)
        if (A.walk) { if (err && err.code === 1) stopWatch(); walkPaint(); return; }
        stopWatch(); paint();
        nearestDue();
        if (A.dir) onFix();
      }, { enableHighAccuracy: true, maximumAge: 5000, timeout: 15000 });
    }
    function stopWatch() { if (A.watch != null && navigator.geolocation) navigator.geolocation.clearWatch(A.watch); A.watch = null; }
    // Hidden page: the GPS stops (battery); back again, it starts again if it was on.
    let wasWatching = false;
    document.addEventListener('visibilitychange', () => {
      if (document.hidden) { wasWatching = A.watch != null; stopWatch(); if (A.walk) walkHidden(true); }
      else { if (wasWatching && !A.hidden) locate(); if (A.walk) walkHidden(false); }
    });
    if (navigator.permissions && navigator.permissions.query) navigator.permissions.query({ name: 'geolocation' }).then(s => { A.perm = s.state; s.onchange = () => { A.perm = s.state; }; }).catch(() => {});

    /* ------------------------------------------------ drawing */

    function mount(slot, ctx) {
      const yearChanged = !A.ctx || A.ctx.year !== ctx.year || A.ctx.campus !== ctx.campus;
      A.ctx = ctx; A.hidden = false;
      if (yearChanged) { A.c = ctx.campus; A.place = null; A.nav = { me: A.nav.me, status: '' }; A.stay = null; A.stayAsked = false; A.stayIn = false; if (A.map) { A.mapEl.remove(); A.map = null; } shorts = M.shortsFor ? M.shortsFor(A.c, places()) : {}; }
      const mode = ctx.full ? 'full' : 'embed';
      if (yearChanged) { const fl = W().floors; A.plans = !!(fl && fl[String(ctx.year)]); A.P = null; A.L = null; A.destKey = ''; A.destInfo = null; A.near = {}; A.feats = {}; A.origin = null; A.dir = null; A.build = null; A.plansWait = []; A.plansFailed = false; }
      if (!A.el) {
        A.el = document.createElement('div'); A.el.className = 'pm';
        // What the sheet's list and the laptop's panel are scrolled to, kept as it changes: moved into the
        // page's new slot (the minute's redraw, offline and online), an element starts again at its top, and
        // by then it can't be read (round 2, leftover 1).
        A.el.addEventListener('scroll', e => { const t = e.target; if (t.classList && (t.classList.contains('pm-body') || t.classList.contains('pm-panel'))) A.scrolled[t.classList.contains('pm-body') ? 'body' : 'panel'] = t.scrollTop; }, true);
      }
      if (A.mode !== mode || yearChanged) { if (A.walk) endWalk(true); A.mode = mode; A.el.className = 'pm pm--' + mode + (ctx.guide ? ' pm--guide' : '') + (A.plans ? ' pm--plans' : ''); build(); }
      if (A.el.parentNode !== slot) {
        slot.appendChild(A.el);
        [['body', '.pm-body'], ['panel', '.pm-panel']].forEach(([k, s]) => { const e = A.el.querySelector(s); if (e && A.scrolled[k]) e.scrollTop = A.scrolled[k]; });
      }
      if (!A.map) makeMap();
      document.documentElement.classList.toggle('pm-on', mode === 'full');
      document.documentElement.classList.add('pm-places');
      // (Wider than a phone: the tab bar is never away or inert, docs/35 §2.8.)
      if (mode !== 'full') { document.documentElement.classList.remove('pm-layer'); const tb = document.querySelector('.wk-tabbar'); if (tb && !A.walk) tb.inert = false; A.layerOn = false; }
      if (mode === 'full') { scrollTo(0, 0); place(); }
      else { A.el.style.removeProperty('--pm-top'); A.el.style.removeProperty('--pm-bottom'); if (A.plans) tall(); }
      const host = A.el.querySelector('.pm-map'); if (A.mapEl.parentNode !== host) host.appendChild(A.mapEl);
      if (!A.stayAsked) { A.stayAsked = true; M.store.stay(ctx.year).then(s => {
        A.stay = s && s.type ? s : null; A.stayIn = true;
        // Directions to My room asked before the stay came (Your sign-ups' link): now.
        if (A.wantStay) { A.wantStay = false; if (A.stay) { api.directions('stay'); return; } }
        // The planner open already: My room may be its start now, and No stairs its Step-free.
        if (A.dir) { if (A.dir.auto && (!A.dir.from || A.dir.from.kind === 'stay')) A.dir.from = fromDefault(); A.dir.key = ''; replan(true); }
        paint();
        // My hall in the first frame too (it comes after the map is drawn), unless something's been asked for.
        const h = stayHall();
        if (h && A.map && !A.place && A.firstFrame && A.firstFrame.indexOf(h) < 0) { A.firstFrame = A.firstFrame.concat([h]); A.map.fit(M.boxOf(A.c, A.firstFrame, 30), 8, true); }
      }); }
      paint();
    }
    function hide() {
      if (A.hidden) return;
      if (A.walk) endWalk(true);
      A.hidden = true; stopWatch(); document.documentElement.classList.remove('pm-on', 'pm-places', 'pm-layer');
      // (A Restrooms or First Aid tap still waiting for a location goes too: it never opens on another tab.)
      clearTimeout(A.wantT); A.wantNearest = null;
      // (The tab bar is back for the other tabs; a place left open is there again on coming back.)
      const tb = document.querySelector('.wk-tabbar'); if (tb && !A.walk) tb.inert = false;
      A.layerOn = false;
    }
    function build() {
      const search = '<button type="button" class="pm-search" data-pm="search">' + I.search + 'Search</button>';
      // A phone (docs/35 §2.1–2.2): no head; Search floats over the map with the menu mark at its right end
      // (the account's initials when signed in, else ⋯), the usual places as chips under it, the sheet
      // (O.sheet.docked) over the foot. The lip is the tucked sheet's one line.
      A.el.innerHTML = A.mode === 'full'
        // (The planner's card, From and To, takes Search's place at the top: docs/35 §2.5, round 2.)
        // (In the page Search, the chips and the card come before the map, so Tab goes Search, chips, map,
        // Locate, sheet, as §2.8 orders it; they float over it by their z-index, so nothing moves.)
        ? '<div class="pm-float"><div class="pm-sbar">' + search + '<span class="pm-mark">' + markHtml() + '</span></div><div class="pm-chips" role="group" aria-label="Usual places" hidden></div><div class="pm-notes"></div></div><div class="pm-dtop" hidden></div><div class="pm-map"></div>' +
          '<section class="pm-sheet" role="region" aria-label="Places"><button type="button" class="pm-grab ogc-sheet__grab" aria-label="More" title="More"></button><button type="button" class="ogc-sheet__lip" data-pm="untuck"></button><div class="pm-body ogc-sheet__body"></div></section>'
        // A laptop with floor plans (§5.1): the map is the whole canvas; Search and the list float over it.
        : A.plans ? '<div class="pm-grid"><div class="pm-map"></div><section class="pm-panel" aria-label="Places">' + search + '<div class="pm-pbody"></div></section></div><div class="pm-extra"></div>'
        : '<div class="pm-grid"><div class="pm-map">' + search + '</div><div class="pm-panel" aria-live="off"></div></div><div class="pm-cards" aria-label="Buildings"></div><div class="pm-extra"></div>';
      SH = null; A.scrolled = {};
      if (A.mode === 'full') sheetMake();
    }
    // The menu mark (docs/35 §2.2, §6 question 2): signed in, the account's own control (ogc-account.js
    // mounts it in a .ws-bar__in; data-acct-extra gives its menu Share the app and Conference page);
    // signed out, ⋯ with the same few rows and Sign in. Round 3's menu replaces both.
    function markHtml() {
      const me = W().me;
      return me && me.email ? '<span class="ws-bar__in pm-acct" data-acct-extra></span>'
        : '<button type="button" class="pm-menu" data-pm="menu" aria-label="Menu" aria-haspopup="dialog" title="Menu">' + I.more + '</button>';
    }
    // The fixed map starts where the guide's head would (under the demo's banner or the offline line,
    // where there is one), and runs to the foot of the screen: the tab bar floats over it (§2.1). The head
    // itself is for screen readers only on a phone's Places (§6 question 1). Measured as laid out, not where
    // a slide has it.
    function place() {
      const head = document.querySelector('.wk-apphead');
      let hb = null;
      if (head) { const r = head.getBoundingClientRect(), t = getComputedStyle(head).transform, dy = t && t !== 'none' ? new DOMMatrixReadOnly(t).m42 : 0; hb = { top: r.top - dy, bottom: r.bottom - dy }; }
      const top = hb ? Math.max(0, hb.top) : 0;
      A.el.style.setProperty('--pm-top', top + 'px'); A.el.style.setProperty('--pm-bottom', '0px');
    }
    // A laptop's canvas (§5.1): the window less the guide's head, its tabs and 24 px, at least 560.
    function tall() {
      const host = A.el.querySelector('.pm-map'), tabs = document.querySelector('.wk-tabbar');
      if (!host) return;
      const top = host.getBoundingClientRect().top + scrollY, bar = tabs ? tabs.getBoundingClientRect().height : 0;
      A.el.style.setProperty('--pm-h', Math.max(560, innerHeight - top - bar - 24) + 'px');
    }
    addEventListener('resize', () => { if (A.hidden) return; if (A.mode === 'full') { place(); if (SH) SH.set(A.snap, 'jump'); if (A.walk) walkPaint(); } else if (A.plans) tall(); });
    // The first frame: the halls with rooms this year and the buildings the schedule uses, together.
    // Polish 2: the outlier rule (a fieldhouse across the fields) dropped Reed and Evans too; it now
    // applies to the Conference's buildings only, and the halls always stay.
    function core(names, halls) {
      const its = names.map(x => M.find(A.c, x)).filter(Boolean), keep = new Set((halls || []).map(x => (M.find(A.c, x) || {}).name).filter(Boolean));
      const med = xs => xs.slice().sort((p, q) => p - q)[Math.floor(xs.length / 2)] || 0;
      const mx = med(its.map(i => i.lx)), my = med(its.map(i => i.ly)), d = i => Math.hypot(i.lx - mx, i.ly - my), md = med(its.map(d));
      return Array.from(new Set(its.filter(i => keep.has(i.name) || d(i) <= Math.max(md * 2.5, 180)).map(i => i.name).concat(Array.from(keep))));
    }
    function makeMap() {
      A.mapEl = document.createElement('div'); A.mapEl.className = 'pm-mapbox'; A.mapEl.style.cssText = 'position:absolute;inset:0';
      const used = new Set(), codes = {};
      groups().forEach(g => { const w = where(g.main); if (w.b) { used.add(w.b.name); if (!codes[w.b.name] && !g.derived && String(g.main.code).indexOf('/') < 0) codes[w.b.name] = g.key; } });
      const hall = stayHall(); if (hall) used.add(hall);
      // First view: the buildings this year's schedule uses, and the halls with rooms (never names written in code).
      const halls = stayHalls().concat(hall ? [hall] : []), start = core(Array.from(used).concat(halls), halls);
      A.firstFrame = start;
      const focus = A.pendingFocus ? A.pendingFocus : null; A.pendingFocus = null;
      const wide = A.mode !== 'full' && A.plans;
      A.map = M.viewer(A.mapEl, A.c, { title: 'Campus map', locate: true, start, focus, extent: Array.from(used).concat(halls), used: Array.from(used), codes, shorts, cooperative: A.mode !== 'full', expand: A.mode !== 'full' && !wide, scale: wide,
        // (A tap on the empty map lowers the sheet, then tucks everything, then brings it back: §2.3.)
        onTap: (pt, b, spot) => { if (A.walk || mapChoose(pt, b)) return; if (spot) openSpot(spot); else if (!(b && openBuilding(b))) mapTap(); },
        // Walking, a pan stops following you (Recenter brings it back).
        onMove: () => { if (A.walk) walkMoved(); },
        onLocate: () => locate() });
      A.el.querySelector('.pm-map').appendChild(A.mapEl);
      if (A.plans) attachPlans(A.map);
      // The first time on this device: how the map moves (gone at the first touch).
      if (!LS.get('ogc-map-hinted', false)) { LS.set('ogc-map-hinted', true); setTimeout(() => A.map && A.map.hint(A.mode === 'full' ? 'Drag to move · Tap a building' : 'Tap a building'), 600); }
    }

    // The year's floor plans on the map (ogc-map-floors.js), once they've come.
    function attachPlans(map) {
      if (!M.floors) return;
      const year = A.ctx.year;
      // (What waits for the plans, the planner's router, is told either way: with none, it routes outdoors.)
      const flush = () => { const w = A.plansWait; A.plansWait = []; w.forEach(f => f()); };
      M.floors.load(year).then(Pl => {
        if (A.map !== map || A.ctx.year !== year) return;
        if (!Pl) { A.plansFailed = true; flush(); return; }
        A.P = Pl;
        // The streets around the campus, drawn under it (the same file the router walks; kept offline).
        if (Pl.area) Pl.area().then(a => { if (a && A.map === map && map.area) map.area(a); }, () => {});
        A.L = map.extend(inner => M.floors.layer(inner, Pl, {
          nameOf: mapName,
          shortOf: B => B.item ? bShort(B.item) : B.name,
          keyOnly: id => { const d = doorRow(id); return !!(d && d.keyOnly); },
          stepFree: id => { const d = doorRow(id); return !!(d && d.stepFree === 'yes'); },
          labelOf: id => { const d = doorRow(id); return d && d.label ? d.label : ''; },
          caption: A.mode !== 'full',
          // (Walking, a tap on the map opens nothing: the walk's card stays what's open.)
          onMark: (kind, a) => { if (A.walk) return; if (kind === 'ent') openDoor(a[0], a[1]); else if (kind === 'feat') openFeat(a[0], +a[1], a[2], a[3]); },
          onRoom: code => { if (!A.walk) focus(code, null, parentFor(code)); },
          // A phone (docs/35 §2.4): a room's name or code plate opens that room, with a 44 px hit area.
          plates: A.mode === 'full',
          // ... and a building chosen has no name tag on its floor while its sheet is open (§2.4).
          wholePlate: A.mode !== 'full',
          // The floor shown changed (or closed): the building chip says it, a building's Rooms follow it.
          onFloor: () => floorShown(),
          onEscape: () => { if (A.walk) endWalk(); else if (A.place) closeLayer(); },
          // A laptop's floating panel, and the guide's tabs where a short window puts them over the map: labels keep off them.
          covers: () => A.mode !== 'full' ? [A.el.querySelector('.pm-panel'), document.querySelector('.wk-tabbar')] : [],
          // A floor that didn't come (or came back): the place is shown as with no plans, then again with them.
          onMissing: () => { A.destKey = ''; A.near = {}; paint(); }
        }));
        paint(!!A.place && A.place.kind !== 'dirs');
        if (A.afterPlans) { const f = A.afterPlans; A.afterPlans = null; f(); }
        flush();
      });
    }

    // The panel (laptop) or sheet (phone): what's open now.
    function paint(fit) {
      if (!A.el || A.hidden) return;
      // A finger on the phone's sheet: what came meanwhile (Nearby, the stay) is drawn once it lets go, so
      // the drag never loses what it holds.
      if (A.mode === 'full' && SH && SH.busy()) {
        A.paintFit = A.paintFit || !!fit; clearTimeout(A.paintT);
        A.paintT = setTimeout(() => { const f = A.paintFit; A.paintFit = false; paint(f); }, 120);
        return;
      }
      // Keyboard focus in the panel or sheet survives its redraw (§9 K4; round 2: Enter on a row, or on ×,
      // left focus on the page): a place opened gets its heading, a place closed its row back, else Search.
      const ae = document.activeElement, kept = !!(ae && ae !== document.body && A.el.contains(ae) && ae.closest('.pm-body, .pm-pbody, .pm-panel, .pm-dtop'));
      const same = kept && ae.dataset && ae.dataset.pm ? '[data-pm="' + CSS.escape(ae.dataset.pm) + '"]' + ['code', 'v', 'id', 'fl', 'i', 'which'].filter(k => ae.dataset[k] != null).map(k => '[data-' + k + '="' + CSS.escape(ae.dataset[k]) + '"]').join('') : '', was = A.lastView;
      const body = A.place ? placeView(A.place) : browseView();
      A.el.classList.toggle('is-dirs', dirsOpen());
      if (A.mode === 'full') {
        // The same view keeps its scroll; another (a building tapped in the list) starts at its top (Oct 13).
        const b = A.el.querySelector('.pm-body'), view = A.place ? A.place.kind + ':' + (A.place.code || A.place.name || A.place.id || '') + (A.place.room ? ':' + A.place.room.number : '') : 'browse', keepScroll = view === A.lastView ? b.scrollTop : 0;
        const fresh = view !== A.lastView, layer = !!A.place && !A.place.arrived, wasLayer = !!A.layerOn;
        // A layer opening rises from below as the tab bar slides away; closing, it leaves downwards (§2.8).
        if (wasLayer && !layer) ghost();
        A.layerOn = layer;
        A.lastView = view;
        b.innerHTML = body + (A.place ? '' : cardsView() + (A.ctx.extra || ''));
        b.scrollTop = keepScroll;
        chrome();
        // Something new opened brings back what a tuck put away.
        if (SH && SH.tucked && fresh) { A.el.classList.remove('is-tucked'); SH.tuck(false, 'jump'); }
        if (SH) SH.set(A.snap, layer !== wasLayer ? 'rise' : fresh ? 'ease' : 'jump');
      } else if (A.plans) {
        // The floating panel: Search, then the list or a place (it keeps its scroll for the same view).
        const b = A.el.querySelector('.pm-pbody'), view = A.place ? A.place.kind + ':' + (A.place.code || A.place.name || A.place.id || '') : 'browse', keep = view === A.lastView ? A.el.querySelector('.pm-panel').scrollTop : 0;
        A.lastView = view;
        b.innerHTML = body + (A.place ? '' : listView());
        A.el.querySelector('.pm-panel').scrollTop = keep;
        A.el.querySelector('.pm-extra').innerHTML = A.ctx.extra || '';
      } else {
        A.el.querySelector('.pm-panel').innerHTML = body;
        A.el.querySelector('.pm-cards').innerHTML = cardsView();
        A.el.querySelector('.pm-extra').innerHTML = A.ctx.extra || '';
      }
      if (kept && !A.el.contains(document.activeElement)) { const again = same && A.lastView === was ? A.el.querySelector(same) : null; if (again) again.focus({ preventScroll: true }); else refocus(); }
      // (What opened the place, Search, is given the focus back once; then it's forgotten.)
      if (!A.place) A.opener = null;
      if (A.place && A.place.code) A.lastCode = A.place.code;
      drawMap(fit);
      syncLayers();
    }
    function refocus() {
      let t = null;
      if (A.place) { t = A.el.querySelector('.pm-placecard .pm-h, .pm-body .pm-h, .pm-pbody .pm-h'); if (t) t.setAttribute('tabindex', '-1'); }
      else if (A.opener && document.contains(A.opener)) t = A.opener;
      else if (A.lastCode) {
        t = A.el.querySelector('[data-code="' + CSS.escape(A.lastCode) + '"]');
        // (Not a row the sheet's stop leaves hidden: a keyboard's focus there raises the sheet over the map.
        // A place opened by its address, closed with Esc, threw the plain map's sheet to full; the fix pass.)
        if (t && SH && A.mode === 'full' && SH.el.contains(t) && t.getBoundingClientRect().bottom - SH.el.getBoundingClientRect().top > (SH.heights()[SH.stop] || 0) + 1) t = null;
      }
      if (!t) t = A.el.querySelector('.pm-search');
      if (t) t.focus({ preventScroll: true });
    }
    // The demo's dock (ogc-dev-nav.js: the local site and the shared link only, never the real site) rests
    // over the map above a phone's sheet (so it never covers Start): fits and names keep clear of it too.
    // Folded to its circle it's no obstacle, and the map stops keeping room for it (docs/35 §2.8).
    // (Open across Locate's column, it rests above Locate, which ogc-dev-nav.js counts as in its way: §2.8.)
    const dockH = () => {
      if (A.mode !== 'full' || A.snap === 'full') return 0;
      const r = dockBox();
      if (!r) return 0;
      const lc = A.mapEl && !A.el.classList.contains('is-high') && A.mapEl.querySelector('.pv-ctl'), lr = lc ? lc.getBoundingClientRect() : null;
      return r.h + 8 + (lr && lr.height && r.right > lr.left ? Math.round(lr.height) + 8 : 0);
    };
    // The dock's height and right edge (none when it's away; folded to its circle, only with folded). It
    // rides in the newest open dialog (ogc-dev-nav.js), so as Search's dialog closes it measures nothing
    // for a moment: its last size then (round 2: the planner's route was fitted in that moment, and the
    // dock sat over its start).
    const dockBox = folded => {
      const d = document.querySelector('.ogc-pill');
      if (!d || d.hidden || (!folded && d.classList.contains('is-min'))) return null;
      const r = d.getBoundingClientRect(), min = d.classList.contains('is-min') ? 'min' : 'open';
      if (r.height) A.dockLast = Object.assign(A.dockLast || {}, { [min]: { h: Math.round(r.height), right: r.right } });
      return (A.dockLast && A.dockLast[min]) || null;
    };
    // (A phone's planner hides Search: its From and To rows are the search; the map gets the top back.)
    const dirsOpen = () => !!(A.place && A.place.kind === 'dirs');
    // A phone: under what floats (Search, the chips) plus 12; tucked, 12 (docs/35 §2.3 Framing).
    // (The planner, round 2: under its card, the route's own 24 px of padding inside that.)
    const topInset = () => { if (A.mode !== 'full' && A.plans) return 0; if (A.mode === 'full') return SH && SH.tucked ? 12 : dirsOpen() && !A.walk ? dcardFoot() : dirsOpen() ? 12 : floatFoot() + 12; const sb = A.el && A.el.querySelector('.pm-search'); return sb && sb.offsetHeight ? sb.offsetTop + sb.offsetHeight + 8 : 64; };
    // The planner's card's foot, from the map's top (as laid out; 12 with none).
    const dcardFoot = () => { const c = A.el && A.el.querySelector('.pm-dtop:not([hidden]) .pm-dcard'); return c && c.offsetHeight ? Math.round(c.getBoundingClientRect().bottom - A.el.getBoundingClientRect().top) : 12; };
    // What else covers the map (§4, §5.1): the picker's column on a phone; the panel and the picker on a laptop.
    const sideInset = () => A.mode === 'full' ? { left: 0, right: A.plans ? 60 : 0 } : A.plans ? { left: (A.el.querySelector('.pm-panel') || {}).offsetWidth ? A.el.querySelector('.pm-panel').offsetWidth + 48 : 0, right: 80 } : { left: 0, right: 0 };
    // A building framed with its neighbours: it fills at most about a third of the map's width (polish 1:
    // on a laptop a tapped building filled 70% and the context was lost).
    const roomy = (box, f) => box ? { x: box.x + box.w / 2 - box.w / f / 2, y: box.y + box.h / 2 - box.h / f / 2, w: box.w / f, h: box.h / f } : null;
    function drawMap(fit) {
      const m = A.map, n = A.nav;
      if (!m) return;
      const lb = A.plans && A.mapEl.querySelector('[data-locate]');
      if (lb) { lb.classList.toggle('is-on', A.watch != null && !!n.me); lb.setAttribute('aria-busy', String(n.status === 'Locating')); lb.setAttribute('aria-pressed', String(A.watch != null)); }
      m.me(A.walk ? walkMe() : n.me && near(n.me) ? n.me : null);
      const pins = [];
      let sel = '', green = null, box = null;
      let t = A.place;
      // The planner: where it's going is marked as its own place is (the route is the viewer's own layer,
      // and frames itself), so nothing here moves the map.
      if (t && t.kind === 'dirs') {
        // (A To chosen on the map has no place: its pin where it was tapped, as the card's To row draws it.
        // The From's ring is the route's own start dot.)
        const te = A.dir && A.dir.to, sp = te && te.kind === 'point' && te.spec;
        if (sp && isFinite(sp.x)) pins.push({ x: +sp.x, y: +sp.y, kind: 'to', label: '' });
        t = te ? te.place : null; fit = false;
      }
      if (t && t.kind === 'hall') {
        const b = M.find(A.c, t.name);
        // (Its own name stays on the map under the pin; my hall's pin says "My room" instead.)
        const mine = M.norm(b && b.name) === M.norm(stayHall());
        if (b) { sel = b.name; pins.push({ x: b.lx, y: b.ly, kind: 'to', of: mine ? b.name : '', label: mine ? stayName() : '' }); box = M.boxOf(A.c, [b.name], 10); }
      } else if (t && t.kind === 'spot') {
        const s = A.c.spots.find(z => z.id === t.id);
        if (s) { pins.push({ x: s.cx, y: s.cy, kind: 'to', label: spotName(s.id) }); box = { x: s.cx - 60, y: s.cy - 60, w: 120, h: 120 }; }
      } else if (t && t.kind === 'door' && A.L) {
        const e = A.L.entrance(t.code, t.number), B = A.L.building(t.code);
        if (e) box = { x: e.at[0] - 25, y: e.at[1] - 25, w: 50, h: 50 };
        if (B && B.item) sel = '';
      } else if (t && t.kind === 'feat' && A.L) {
        if (t.at) box = { x: t.at[0] - 12, y: t.at[1] - 12, w: 24, h: 24 };
      } else if (t && (t.kind === 'restrooms' || t.kind === 'elevators')) {
        // (The list's first is rung on its floor, below.)
      } else if (t && t.kind === 'nearest') {
        // The Restrooms or First Aid chip's rows (§2.4): each marked with a room's small ring where its floor
        // isn't drawn (at the campus's zoom there are no icon chips to ring; the check saw nothing marked).
        // Where its floor shows, its icon chip is there instead, and the first one is rung on it.
        (t.rows || []).forEach(c => {
          const q = c.at || (c.b && c.b.lx != null ? [c.b.lx, c.b.ly] : null);
          const onFloor = c.kind === 'feat' && A.L && A.L.shown(c.code) === +c.floor;
          if (q && !onFloor) pins.push({ x: q[0], y: q[1], kind: 'room', label: '' });
        });
      } else if (planned(t)) {
        // A place in the build: no pin and no tinted roof; its building opens with the room in tan (§4.3).
      } else if (t) {
        const p = P(t.code), w = p ? where(p) : { kind: 'none' };
        // (A field not pinned yet isn't its building: the building isn't tinted as the place, round 2 part 2.)
        if (w.b && w.kind !== 'outdoor') sel = w.b.name;
        green = w.green || null;
        if (w.kind === 'pin') pins.push({ x: w.x, y: w.y, kind: 'to', label: pinName(p) });
        // A building: a pin on it. A room with no pin: its building tinted, never a pin that reads as the room.
        else if (w.b && w.kind !== 'outdoor' && String(p.code).indexOf('/') < 0) pins.push({ x: w.b.lx, y: w.b.ly, kind: 'to', label: '' });
        box = w.kind === 'pin' ? M.boxOf(A.c, w.b ? [w.b.name] : [], 30) : w.b ? M.boxOf(A.c, [w.b.name], 10) : null;
        if (w.kind === 'pin' && !box) box = { x: w.x - 60, y: w.y - 60, w: 120, h: 120 };
      }
      // Where I sleep: a bed on my hall, its name always shown (polish 2: Reed drawn like every other hall).
      const sh = stayHall() && M.find(A.c, stayHall());
      // It keeps its schedule code ("N · Hodson"), so the household can match it to the schedule (round 2).
      if (sh && !(t && t.kind === 'hall' && M.norm(t.name) === M.norm(sh.name))) pins.push({ x: sh.lx, y: sh.ly, kind: 'stay', of: sh.name, label: shorts[sh.name] || M.shortOf(sh), code: bCode(sh) });
      m.pins(pins);
      m.select(sel, green);
      // What covers the map: the search bar (both layouts) and the sheet (a phone); fits and names keep clear.
      // (A laptop's map keeps its foot, the scale and the credit, clear too: round 2 part 2, a route's start
      // sat under the credit line.)
      const foot = A.mode !== 'full' && A.mapEl && (A.mapEl.querySelector('.pv-foot') || A.mapEl.querySelector('.pv-credit'));
      const footH = foot && foot.offsetHeight ? Math.max(0, Math.round(A.mapEl.getBoundingClientRect().bottom - foot.getBoundingClientRect().top)) + 8 : 0;
      m.inset(A.walk ? walkInset() : Object.assign({ top: topInset(), bottom: A.mode === 'full' ? sheetInset() : footH }, sideInset()));
      if (A.L) {
        A.L.picked(sel);
        destFor(t, fit);
        if (fit && t && (t.kind === 'door' || t.kind === 'feat') && box) { m.look(box.x + box.w / 2, box.y + box.h / 2, Math.max(3, 1 / Math.max(1e-6, m.view().w / Math.max(1, A.mapEl.getBoundingClientRect().width))), true); return; }
        if (planned(t)) return;
      }
      if (fit && box) m.fit(roomy(box, A.mode === 'full' ? .45 : .35), 20, true);
    }
    // A place drawn on its floor: in the build, and its floor here (one that didn't come is shown as a campus
    // with no plans shows it: its building tan, a pin on a whole building).
    const planned = t => { const pl = t && t.code && !t.kind && A.L ? planOf(P(t.code)) : null; return !!pl && !A.L.missing(pl.code); };
    // The place's building opened on its floor, the room in tan, the door line drawn; framed once known
    // (§4.3): the room and its door centred, at the building's fit, at least 2.2 px a metre, closer for a
    // small room near its door.
    function destFor(t, fit) {
      const pl = t && t.code && !t.kind ? planFor(t) : null;
      const key = pl ? pl.place : '';
      if (fit && pl) A.fitKey = key;
      if (key === A.destKey) { if (fit && pl && A.destInfo) frame(A.destInfo); return; }
      A.destKey = key; A.destInfo = null;
      // (its door: M.placeDoor's, the dialog's and the small maps' too; step-free only with Step-free on)
      A.L.dest(pl ? { code: pl.code, rooms: pl.rooms, place: pl.room ? String(t.code).toUpperCase() : pl.place, name: pl.name || '', stepFree: stepFree() } : null).then(info => {
        if (!info || A.destKey !== key) return;
        A.destInfo = info;
        if (A.fitKey === key) frame(info);
        if (pl.rooms.length && !A.near[key]) nearFor(pl);
      });
    }
    function frame(info) {
      A.fitKey = '';
      if (!A.map || !A.L) return;
      const bs = info.B.box ? A.L.scaleFor(info.B.box, 16) : 2.2;
      let s = info.room ? Math.min(A.L.scaleFor(info.box, 40), Math.max(bs, 2.2), 24) : Math.min(bs, 24);
      // A phone (docs/35 §2.4): the room is at least a third of the clear map's width, its door still in view.
      if (info.room && A.mode === 'full' && info.room.w) {
        const si = sideInset(), cw = Math.max(1, A.mapEl.getBoundingClientRect().width - si.left - si.right);
        s = Math.min(A.L.scaleFor(info.box, 40), Math.max(s, cw / 3 / info.room.w), 24);
      }
      const b = info.room ? info.box : info.B.box || info.box;
      if (b) A.map.look(b.x + b.w / 2, b.y + b.h / 2, s, true);
    }

    /* ------------------------------------------------ the views in the sheet or panel */

    const x = '<button type="button" class="pm-x" data-pm="close" aria-label="Close">' + I.close + '</button>';
    // Nothing chosen: the usual places, one tap each (my room, what's next, Help's places). On a laptop the
    // building cards below carry each building's Still today, so the panel neither repeats them nor names
    // the next thing as a chip; its own Still today keeps only what no card shows (conference-1, Oct 28).
    function browseView() {
      if (A.plans) return peekView();
      // Last in the row, quietly: For families, when the campus marks a nursery, family restroom or quiet room.
      const fam = familyPlaces().length ? '<button type="button" class="pm-chip" data-pm="families">' + I['f-family restroom'] + '<span><b>For families</b></span></button>' : '';
      // First, on a phone: Show where I am (Andrew's guide, Oct 13), the phone's location as the blue dot,
      // asked for only when it's tapped; once on, it says so, and a tap centres the map on it again.
      const on = A.watch != null;
      const me = touch() ? '<button type="button" class="pm-chip pm-chip--me" data-pm="locate" aria-pressed="' + on + '">' + I.locate + '<span><b>' + (on ? 'Showing where you are' : 'Show where I am') + '</b></span></button>' : '';
      const embed = A.mode === 'embed';
      const chips = me + quickChips(embed) + fam;
      const status = A.nav.status && A.nav.status !== 'Locating' ? '<p class="pm-status" data-peek>' + I.locate + esc(A.nav.status) + '</p>' : '';
      const still = embed ? stillToday(null, null, true, new Set(groups().map(g => g.key))) : '';
      return (chips ? '<div class="pm-quick" data-peek>' + chips + '</div>' : '') + status + (still ? '<div class="pm-card">' + still + '</div>' : '');
    }
    // With floor plans (§4.1): at most two rows, each drawn only while true (Next, My room), then one strip
    // of chips (Restrooms · First Aid · Information · Dining · For families), each only when the campus has one.
    function peekView() {
      const rows = [], nx = nextEvent();
      const row = (attrs, label, title, right) => '<button type="button" class="pm-prow" ' + attrs + '><span class="pm-prow__m"><span class="pm-k">' + esc(label) + '</span><b>' + esc(title) + '</b></span>' + (right ? '<small>' + esc(right) + '</small>' : '') + I.next + '</button>';
      if (nx) { const b = where(P(nx.code)).b; rows.push(row('data-pm="room" data-code="' + esc(nx.code) + '"', 'Next' + (nx.start != null ? ' · ' + clock(nx.start) : ''), nx.title, b ? bShort(b) : '')); }
      if (stayEnd()) { const h = stayHall() && M.find(A.c, stayHall()); rows.push(row('data-pm="set" data-v="stay"', stayName(), staySub(true) || stayName(), h ? shorts[h.name] || M.shortOf(h) : '')); }
      // (On a phone the chips float over the map under Search instead: docs/35 §2.2.)
      const chips = A.mode === 'full' ? '' : stripChips(false);
      const status = A.nav.status && A.nav.status !== 'Locating' ? '<p class="pm-status" data-peek>' + I.locate + esc(A.nav.status) + '</p>' : '';
      return (rows.length ? '<div class="pm-prows" data-peek>' + rows.join('') + '</div>' : '') + status + (chips ? '<div class="pm-quick pm-strip" data-peek>' + chips + '</div>' : '');
    }
    // The strip's chips; in Search, Elevators in place of Dining and For families (§4.2).
    function stripChips(search) {
      const out = [], chip = (attrs, icon, title) => '<button type="button" class="pm-chip" ' + attrs + '>' + icon + '<span><b>' + esc(title) + '</b></span></button>';
      const help = (A.ctx.help || []).filter(h => h.place && P(h.place) && routable(P(h.place)));
      // (A phone's floating chips open the nearest by walking time, saying Locating while the phone finds
      // where it is: docs/35 §2.4. Search's chips, and a laptop's, open the place or the whole list.)
      const near_ = !search && A.mode === 'full', busy = k => near_ && A.wantNearest === k ? ' aria-busy="true"' : '';
      if (A.plans) out.push(chip((near_ ? 'data-pm="nearest" data-v="restroom"' : 'data-pm="list" data-v="restroom"') + busy('restroom'), I['f-restroom'], near_ && A.wantNearest === 'restroom' ? 'Locating' : 'Restrooms'));
      const aid = help.find(h => /aid|medic|nurse/i.test(h.need));
      if (aid) out.push(chip((near_ ? 'data-pm="nearest" data-v="aid"' : 'data-pm="room" data-code="' + esc(P(aid.place).code) + '"') + busy('aid'), I.cross, near_ && A.wantNearest === 'aid' ? 'Locating' : 'First Aid'));
      const desk = A.c.spots.find(z => z.spot === 'desk'), info = help.find(h => /^info/i.test(h.need));
      if (desk) out.push(chip('data-pm="spot" data-id="' + esc(desk.id) + '"', I.desk, 'Information'));
      else if (info) out.push(chip('data-pm="room" data-code="' + esc(P(info.place).code) + '"', I.desk, 'Information'));
      if (search) { if (A.plans) out.push(chip('data-pm="list" data-v="elevator"', I['f-elevator'], 'Elevators')); return out.join(''); }
      const dg = groups().find(g => !g.derived && where(g.main).b && where(g.main).b.kind === 'dining');
      if (dg) out.push(chip('data-pm="room" data-code="' + esc(dg.main.code) + '"', I.dining, 'Dining'));
      if (familyPlaces().length) out.push(chip('data-pm="families"', I['f-family restroom'], 'For families'));
      return out.join('');
    }
    // A laptop's list (§5.1): each Conference building with its rooms under floor labels, then the lots.
    function listView() {
      const gs = groups().filter(g => where(g.main).kind !== 'none');
      return '<div class="pm-blist">' + gs.map(g => '<section class="pm-blist__g" aria-label="' + esc(g.name) + '">' +
        (g.derived ? '<p class="pm-blist__h"><b>' + esc(g.name) + '</b></p>' : '<button type="button" class="pm-blist__h" data-pm="room" data-code="' + esc(g.main.code) + '"><b>' + esc(g.name) + '</b><code>' + esc(g.main.code) + '</code></button>') +
        roomsByFloor(g) + '</section>').join('') +
        (A.c.spots.length ? '<section class="pm-blist__g"><p class="pm-k pm-flk">Parking and services</p><ul class="pm-rooms">' + A.c.spots.map(z => '<li><button type="button" class="pm-row" data-pm="spot" data-id="' + esc(z.id) + '"><span>' + esc(z.name || M.SPOT[z.spot]) + '</span></button></li>').join('') + '</ul></section>' : '') + '</div>';
    }
    // A building's rooms under their floors ("1ST FLOOR"); a room the plans don't hold goes first, unlabelled.
    function roomsByFloor(g) {
      const rooms = g.derived ? g.all : g.rooms;
      if (!rooms.length) return '';
      const by = {}, none = [];
      rooms.forEach(r => { const f = planFloor(r); if (f == null) none.push(r); else (by[f] = by[f] || []).push(r); });
      const fl = Object.keys(by).map(Number).sort((a, b) => a - b);
      return (none.length ? '<ul class="pm-rooms">' + none.map(r => roomRow(r, g.name)).join('') + '</ul>' : '') +
        fl.map(f => '<p class="pm-k pm-flk">' + esc(M.floorName(f)) + '</p><ul class="pm-rooms">' + by[f].map(r => roomRow(r, g.name)).join('') + '</ul>').join('');
    }
    // A place in the build (§4.3): its name, building · floor · code, another floor's part, Directions
    // (the planner), what's on there today, and the nearest restroom and elevator.
    // A building: its name with its code, Directions, its rooms by floor, then today.
    function planView(p, g, isMain, plan) {
      // One of the place's rooms by IWU's name (the Chapel's Balcony): that room, its building and floor.
      if (plan.room) {
        const b = where(p).b, sub = [b ? bShort(b) : g.name, M.floorName(plan.room.floor), p.code].filter(Boolean).join(' · ');
        return '<div class="pm-card pm-placecard"><div data-peek>' + x + '<h2 class="pm-h pm-h--place">' + esc(plan.name) + '</h2><p class="pm-sub">' + esc(sub) + '</p>' + dirsTo(p) + '</div>' +
          stillToday(null, p.code, false, null, 'Today here') + nearbyView(plan) + '</div>';
      }
      const title = isMain
        ? '<h2 class="pm-h pm-h--place">' + esc(g.name) + ' <span class="pm-code">' + esc(p.code) + '</span></h2>'
        : '<h2 class="pm-h pm-h--place" aria-label="' + esc(p.name + ', ' + p.code) + '">' + esc(roomName(p)) + '</h2>';
      const fact = factLine(p, isMain);
      const more = plan.rooms.slice(1).map(r => {
        const f = A.P.got(plan.code, +r.floor), x_ = f && f._by[String(r.number)], nm = x_ && x_.r.name ? M.floors.titleCase(x_.r.name) : '';
        return '<button type="button" class="pm-flrow" data-pm="floor" data-fl="' + esc(r.floor) + '"><span>' + esc([nm, M.floorName(r.floor)].filter(Boolean).join(' · ')) + '</span>' + I.next + '</button>';
      }).join('');
      const feats = isMain ? featuresIn(g) : (p.features || []).filter(f => String(p.name).toLowerCase().indexOf(featWord(f).toLowerCase()) < 0).map(f => ({ f, room: null }));
      const featList = feats.length ? '<ul class="pm-feats" aria-label="For families and access">' + feats.map(f => featRow(f, g)).join('') + '</ul>' : '';
      const today = stillToday(isMain ? g.key : null, p.code, false, null, 'Today here');
      // (A phone's building lists the floor shown, under the floor's name: docs/35 §2.4.)
      const phone = A.mode === 'full', rooms = isMain ? (phone ? floorRooms(g, plan) : roomsByFloor(g)) : '';
      return '<div class="pm-card pm-placecard"><div data-peek>' + x + title + (fact ? '<p class="pm-sub">' + esc(fact) + '</p>' : '') + more + dirsTo(p) + '</div>' +
        featList + (rooms ? '<div class="pm-brooms">' + (phone ? '' : '<p class="pm-k">Rooms</p>') + rooms + '</div>' : '') + today + (plan.rooms.length ? nearbyView(plan) : '') + '</div>';
    }
    // A building's Rooms on a phone (docs/35 §2.4): the floor shown's Conference rooms under its name; a
    // floor with none lists its restrooms, elevator and stairs, never nothing. Rooms the plans don't hold
    // come first, unlabelled, as on every floor.
    function floorRooms(g, plan) {
      const B = A.L && A.L.building(plan.code);
      if (!B) return roomsByFloor(g);
      const shown = A.L.shown(plan.code), fl = +(shown != null ? shown : B.entrance);
      const all = g.derived ? g.all : g.rooms, none = all.filter(r => planFloor(r) == null);
      const rows = all.filter(r => planFloor(r) === fl).map(r => roomRow(r, g.name));
      const f = !rows.length && A.P ? A.P.got(plan.code, fl) : null;
      if (f) {
        const seen = {};
        const add = (sub, z, word) => { if (!z || !z.at || seen[word]) return; seen[word] = 1; rows.push('<li><button type="button" class="pm-row" data-pm="feat" data-v="' + esc('feat:' + plan.code + ':' + fl + ':' + sub + ':' + z.number) + '"><span>' + esc(word) + '</span></button></li>'); };
        (f.restrooms || []).filter(z => z.walk !== false && !(f._by[z.number] && /LOCKER|SHOWER|TEAM|STAFF/i.test(f._by[z.number].r.name || ''))).forEach(z => add(z.who || 'unknown', z, FEAT_END[z.who] || (FEAT[z.who] || FEAT.unknown)[1]));
        (f.elevators || []).forEach(z => add('elevator', z, 'Elevator'));
        (f.stairs || []).forEach(z => add('stairs', z, 'Stairs'));
      }
      return (none.length ? '<ul class="pm-rooms">' + none.map(r => roomRow(r, g.name)).join('') + '</ul>' : '') +
        (rows.length ? '<p class="pm-k pm-flk">' + esc(M.floorName(fl)) + '</p><ul class="pm-rooms">' + rows.join('') + '</ul>' : '');
    }
    // Nearby: the nearest restroom and elevator, along the halls, in feet; "Stairs only" where true.
    function nearbyView(plan) {
      const n = A.near[plan.place];
      if (!n || n === 'wait') return '';
      const fl = +plan.rooms[0].floor, rows = [];
      const row = (z, word, m) => '<li><button type="button" class="pm-nrow" data-pm="ring" data-b="' + esc(plan.code) + '" data-fl="' + z.floor + '" data-x="' + z.at[0] + '" data-y="' + z.at[1] + '"><span>' + esc(word + (+z.floor !== fl ? ' · ' + M.floorName(z.floor) : '')) + '</span><span class="pm-nrow__d">' + esc(M.feet(m)) + '</span></button></li>';
      if (n.rest && n.rest.x.at) rows.push(row(n.rest.x, n.rest.word, n.rest.m));
      if (n.lift && n.lift.x.at) rows.push(row(n.lift.x, 'Elevator', n.lift.m));
      else if (n.stairsOnly) rows.push('<li><p class="pm-nrow is-plain"><span>Stairs only</span></p></li>');
      return rows.length ? '<div class="pm-near"><p class="pm-k">Nearby</p><ul>' + rows.join('') + '</ul></div>' : '';
    }
    function nearFor(pl) {
      const r0 = pl.rooms[0], key = pl.place;
      A.near[key] = 'wait';
      A.origin = { code: pl.code, floor: +r0.floor, number: r0.number };
      A.L.nearby(pl.code, +r0.floor, r0.number).then(n => { A.near[key] = n || null; if (A.place && A.place.code && String(A.place.code).toUpperCase() === key.split('|')[0]) paint(); });
    }
    // A door (a tap on its mark): "South doors · Open 7:00 AM–10:00 PM · Step-free", only what's known (§3.6).
    function doorView(pl) {
      const e = A.L && A.L.entrance(pl.code, pl.number), B = A.L && A.L.building(pl.code);
      if (!e) return '';
      const d = doorRow(e.door), word = (d && d.label) || e.name || 'Entrance';
      const bits = [B ? B.short : '', d && d.open ? 'Open ' + d.open : '', d && d.stepFree === 'yes' ? 'Step-free' : ''].filter(Boolean).join(' · ');
      return '<div class="pm-card pm-placecard"><div data-peek>' + x + '<p class="pm-k">Entrance</p><h2 class="pm-h pm-h--place">' + esc(word) + '</h2>' + (bits ? '<p class="pm-sub">' + esc(bits) + '</p>' : '') +
        dirsBtn(true) + '</div></div>';
    }
    // A restroom, the stairs or an elevator (a tap on its icon, a row in a list).
    const FEAT = { women: ['Restroom', 'Women'], men: ['Restroom', 'Men'], family: ['', 'Family restroom'], unknown: ['', 'Restroom'], stairs: ['', 'Stairs'], elevator: ['', 'Elevator'] };
    const FEAT_END = { women: 'Women’s restroom', men: 'Men’s restroom' };
    function featView(pl) {
      const B = A.L && A.L.building(pl.code), w = FEAT[pl.sub] || FEAT.unknown;
      const sub = [B ? B.short : '', M.floorName(pl.floor)].filter(Boolean).join(' · ');
      return '<div class="pm-card pm-placecard"><div data-peek>' + x + (w[0] ? '<p class="pm-k">' + esc(w[0]) + '</p>' : '') + '<h2 class="pm-h pm-h--place">' + esc(w[1]) + '</h2><p class="pm-sub">' + esc(sub) + '</p>' +
        dirsBtn(!!(B && pl.at)) + '</div></div>';
    }
    // Restrooms (or Elevators): every one in the plans, the nearest first (§4.1, §4.2). Measured along the
    // halls from the room last opened, in its building; the rest by how far they are, with no distance said.
    function listFeatView(pl) {
      const kind = pl.kind === 'restrooms' ? 'restroom' : 'elevator', list = A.feats[kind];
      const head = '<div data-peek>' + x + '<h2 class="pm-h pm-h--place">' + (kind === 'restroom' ? 'Restrooms' : 'Elevators') + '</h2></div>';
      if (!Array.isArray(list)) return '<div class="pm-card pm-placecard">' + head + '</div>';
      return '<div class="pm-card pm-placecard">' + head + '<ul class="pm-rooms">' + uniqFeats(list).slice(0, 24).map(f => '<li><button type="button" class="pm-row" data-pm="feat" data-v="' + esc(featV(f)) + '"><span>' + esc(f.word) + '<small>' + esc(f.B.short + ' · ' + M.floorName(f.floor)) + '</small></span>' + (f.m != null ? '<span class="pm-nrow__d">' + esc(M.feet(f.m)) + '</span>' : '') + '</button></li>').join('') + '</ul></div>';
    }
    // Two the same to read (a floor's pair of "Restroom"s) are one row: the nearer.
    const uniqFeats = list => { const seen = {}; return list.filter(f => { const k = f.word + '|' + f.B.code + '|' + f.floor; if (seen[k]) return false; seen[k] = 1; return true; }); };
    const featV = f => 'feat:' + f.B.code + ':' + f.floor + ':' + (f.word === 'Elevator' ? 'elevator' : f.who || 'unknown') + ':' + f.number;
    // The list in order; the first opened on its floor.
    function loadFeats(kind, open) {
      if (!A.L) return Promise.resolve(null);
      const o = A.origin, at = A.nav.me && M.onCampus(A.c, A.nav.me) ? A.nav.me : (() => { const v = A.map.view(); return { x: v.x + v.w / 2, y: v.y + v.h / 2 }; })();
      const here = !!(A.nav.me && M.onCampus(A.c, A.nav.me));
      // With no room opened and no location, nothing is nearer than another: a building's entrance floor
      // first, women's and men's before a restroom IWU doesn't mark, then by how far from the map's middle.
      const rank = f => (+f.floor === +f.B.entrance ? 0 : 2) + (f.who === 'unknown' ? 1 : 0);
      return Promise.all([A.L.all(kind), o ? A.L.from(o.code, o.floor, o.number) : null]).then(([list, fn]) => {
        list.forEach(f => { f.m = fn ? fn(f.B.code, f.floor, f.number) : null; f.d = Math.hypot(f.at[0] - at.x, f.at[1] - at.y); });
        list.sort((a, b) => (a.m == null) - (b.m == null) || (a.m != null ? a.m - b.m : here ? a.d - b.d : rank(a) - rank(b) || a.d - b.d));
        A.measured = !!fn || here;
        list.at = featKey();
        A.feats[kind] = list;
        return list;
      });
    }
    // What the nearest were measured from: the room last opened, or where the phone is (to 10 m). Search
    // measures again when it's changed (round 2 part 2: the restrooms kept the order of the first look).
    const featKey = () => { const o = A.origin, me = A.nav.me && M.onCampus(A.c, A.nav.me) ? A.nav.me : null; return (o ? o.code + '|' + o.floor + '|' + o.number : '') + (me ? '@' + Math.round(me.x / 10) + ',' + Math.round(me.y / 10) : ''); };
    const featsStale = k => !Array.isArray(A.feats[k]) || A.feats[k].at !== featKey();
    function openList(kind) {
      A.place = { kind: kind === 'restroom' ? 'restrooms' : 'elevators' }; settle('half'); paint(); say(kind === 'restroom' ? 'Restrooms' : 'Elevators');
      const go = () => loadFeats(kind).then(list => {
        if (!list || !A.place || A.place.kind !== (kind === 'restroom' ? 'restrooms' : 'elevators')) return;
        paint();
        const f = list[0];
        if (f) { A.L.ring(f.B.code, f.floor, f.at); A.map.look(f.at[0], f.at[1], Math.max(3, curScale()), true); }
      });
      if (A.L) go(); else A.afterPlans = go;
    }
    /* ------------------------------------------------ the nearest restroom, First Aid (docs/35 §2.4, round 2) */

    // A phone's Restrooms and First Aid chips. The chip asks for the phone's location once (a touch phone,
    // from this tap only) and says Locating while it finds it. Then the nearest of each kind (Women, Men,
    // Family, and a plain Restroom only when it's nearer than the nearest marked one), each by walking time
    // along the paths and halls from you, each row with its own Directions: Start is two taps from the chip.
    // With no location, the order is from the place open at the tap, else the map's middle, and the rows say only
    // where (no minutes or feet from nowhere true). First Aid is the same, with one row.
    const WHO_ROW = { women: 'Women', men: 'Men', family: 'Family', unknown: 'Restroom' };
    const meHere = () => { const me = A.nav.me; return me && me.lat != null && near(me) && M.onCampus(A.c, me) ? me : null; };
    function nearestChip(kind) {
      if (touch() && A.mode === 'full' && A.perm !== 'denied' && A.watch == null) {
        A.wantNearest = kind; locate(); chrome();
        clearTimeout(A.wantT);
        A.wantT = setTimeout(() => { if (A.wantNearest === kind) { A.wantNearest = null; openNearest(kind); } }, 8000);
        return;
      }
      openNearest(kind);
    }
    // (The location came, or didn't: the list the chip asked for opens.)
    function nearestDue() { const k = A.wantNearest; if (!k) return; A.wantNearest = null; clearTimeout(A.wantT); openNearest(k); }
    function openNearest(kind) {
      const pl = { kind: 'nearest', v: kind, rows: null }, ref = refPoint();
      A.place = pl; settle('peek'); paint(); say(kind === 'aid' ? 'First Aid' : 'Restrooms');
      const go = () => nearestRows(kind, ref).then(rows => { if (A.place !== pl) return; pl.rows = rows; paint(); frameNearest(rows); });
      if (A.L || kind === 'aid' || !A.plans || A.plansFailed) go(); else A.afterPlans = go;
    }
    // The candidates: a restroom of each kind (with you, the three nearest of each as the crow flies, the
    // walk then decides), or First Aid's place.
    // With no location, where the order is from (campus metres): the place open when the chip was tapped,
    // else the middle of the map as it shows.
    function refPoint() {
      const t = A.place;
      if (t && t.kind === 'feat' && t.at) return t.at;
      if (t && t.kind === 'door' && A.L) { const e = A.L.entrance(t.code, t.number); if (e) return e.at; }
      if (t && t.kind === 'hall') { const b = M.find(A.c, t.name); if (b) return [b.lx, b.ly]; }
      if (t && t.kind === 'spot') { const s = A.c.spots.find(z => z.id === t.id); if (s) return [s.cx, s.cy]; }
      if (t && t.code && !t.kind) { const p = P(t.code), w = p ? where(p) : null; if (w && w.kind === 'pin') return [w.x, w.y]; if (w && w.b) return [w.b.lx, w.b.ly]; }
      if (!A.map) return null;
      const v = A.map.view();
      return [v.x + v.w / 2, v.y + v.h / 2];
    }
    function nearestCands(kind, me, ref) {
      if (kind === 'aid') {
        const h = (A.ctx.help || []).find(z => /aid|medic|nurse/i.test(z.need) && z.place && P(z.place) && routable(P(z.place)));
        const p = h && P(h.place), b = p && where(p).b, fl = p ? planFloor(p) : null;
        return Promise.resolve(p ? [{ kind: 'place', who: 'aid', code: p.code, label: 'First Aid', where: [b ? bShort(b) : '', fl != null ? M.floorName(fl) : ''].filter(Boolean).join(' '), end: endPlace(p.code), ord: 0, b }] : []);
      }
      if (!A.L) return Promise.resolve([]);
      return loadFeats('restroom').then(list => {
        const by = {};
        // (As the crow flies, a floor up or down counted as 20 m of stairs: the Chapel's restroom on the
        // 1st floor before the one above it.)
        const o = me ? [me.x, me.y] : ref, up = f => isFinite(+f.floor) ? Math.abs(+f.floor - 1) * 20 : 0;
        (list || []).forEach((f, i) => { (by[f.who || 'unknown'] = by[f.who || 'unknown'] || []).push({ f, ord: o ? Math.hypot(f.at[0] - o[0], f.at[1] - o[1]) + up(f) : i }); });
        return Object.keys(by).map(w => by[w].sort((a, b) => a.ord - b.ord).slice(0, me ? 3 : 1)).reduce((a, b) => a.concat(b), []).map(({ f, ord }) => ({
          kind: 'feat', who: f.who || 'unknown', label: WHO_ROW[f.who] || 'Restroom', where: f.B.short + ' ' + M.floorName(f.floor), v: featV(f), at: f.at, code: f.B.code, floor: f.floor, ord,
          end: endFeat({ kind: 'feat', code: f.B.code, floor: f.floor, sub: f.who || 'unknown', number: f.number, at: f.at })
        }));
      });
    }
    function nearestRows(kind, ref) {
      const me = meHere();
      return nearestCands(kind, me, ref).then(list => {
        const timed = !me || !list.length ? Promise.resolve(list) : routerNow().then(R => {
          const now = venueNow(), o = { places: places(), stepFree: stepFree(), date: now.date, time: now.time }, from = { lat: me.lat, lng: me.lng };
          list.forEach(c => {
            if (!c.end) return;
            let r = planStepFree(R, from, c.end.spec, o);
            if (c.end.alt && (!r.ok || r.unmapped)) { const r2 = planStepFree(R, from, c.end.alt, o); if (r2.ok) r = r2; }
            if (r.ok) { c.sec = r.sec; c.min = r.min; c.dist = r.distance; }
          });
          return list;
        }, () => list);
        return timed.then(all => {
          const key = c => me && c.sec != null ? c.sec : me ? Infinity : c.ord, best = {};
          all.forEach(c => { if (!best[c.who] || key(c) < key(best[c.who]) || (key(c) === key(best[c.who]) && c.ord < best[c.who].ord)) best[c.who] = c; });
          let rows = Object.keys(best).map(k => best[k]);
          const marked = rows.filter(c => c.who !== 'unknown' && c.who !== 'aid'), plain = rows.find(c => c.who === 'unknown');
          if (plain && marked.length && key(plain) >= Math.min.apply(null, marked.map(key))) rows = rows.filter(c => c !== plain);
          return rows.sort((a, b) => key(a) - key(b) || a.ord - b.ord);
        });
      });
    }
    // The rows' restrooms ringed (the nearest), framed together with you.
    function frameNearest(rows) {
      if (!A.map || !rows || !rows.length) return;
      const me = meHere(), pts = [];
      rows.forEach(c => { if (c.at) pts.push(c.at); else if (c.b) { const bx = M.boxOf(A.c, [c.b.name], 0); if (bx) pts.push([bx.x + bx.w / 2, bx.y + bx.h / 2]); } });
      if (me) pts.push([me.x, me.y]);
      const f = rows[0];
      if (A.L && f.kind === 'feat') A.L.ring(f.code, f.floor, f.at);
      if (!pts.length) return;
      const xs = pts.map(p => p[0]), ys = pts.map(p => p[1]), x0 = Math.min.apply(null, xs), y0 = Math.min.apply(null, ys);
      const w = Math.max(30, Math.max.apply(null, xs) - x0), h = Math.max(30, Math.max.apply(null, ys) - y0);
      A.map.fit({ x: x0 + (Math.max.apply(null, xs) - x0) / 2 - w / 2, y: y0 + (Math.max.apply(null, ys) - y0) / 2 - h / 2, w, h }, 40, true);
    }
    function nearestView(pl) {
      const t = pl.v === 'aid' ? 'First Aid' : 'Restrooms';
      const head = '<h2 class="pm-h pm-h--place">' + t + '</h2>';
      if (!pl.rows) return '<div class="pm-card pm-placecard"><div data-peek>' + x + head + '</div></div>';
      if (!pl.rows.length) return '<div class="pm-card pm-placecard"><div data-peek>' + x + head + '<p class="pm-sub">Not on the map yet</p></div></div>';
      const rows = pl.rows.map((c, i) => '<li class="pm-nst"><button type="button" class="pm-row" ' + (c.kind === 'feat' ? 'data-pm="feat" data-v="' + esc(c.v) + '"' : 'data-pm="room" data-code="' + esc(c.code) + '"') + '>' +
        '<span>' + esc(c.label + (c.where ? ' · ' + c.where : '')) + (c.min != null ? '<small>' + esc(c.min + ' min · ' + c.dist) + '</small>' : '') + '</span></button>' +
        '<button type="button" class="pm-dbtn" data-pm="ndirs" data-i="' + i + '" aria-label="' + esc('Directions, ' + c.label + (c.where ? ', ' + c.where : '')) + '" title="Directions">' + I.dirs + '</button></li>').join('');
      const all = pl.v === 'aid' ? '' : '<ul class="pm-rooms"><li><button type="button" class="pm-row pm-row--more" data-pm="list" data-v="restroom"><span>All restrooms</span>' + I.next + '</button></li></ul>';
      return '<div class="pm-card pm-placecard"><div data-peek>' + x + head + '<ul class="pm-rooms pm-nlist">' + rows + '</ul></div>' + all + '</div>';
    }
    const curScale = () => { const r = A.mapEl.getBoundingClientRect(); return r.width / Math.max(1e-6, A.map.view().w); };
    function openDoor(code, number) { A.place = { kind: 'door', code, number }; settle('half'); paint(true); const e = A.L && A.L.entrance(code, number); if (e) say((doorRow(e.door) || {}).label || e.name || 'Entrance'); }
    function openFeat(code, n, sub, number) {
      if (!A.L) return;
      const k = sub === 'stairs' || sub === 'elevator' ? sub : 'restroom';
      const go = () => {
        const ft = A.L.feature(code, n, k, number); if (!ft) return;
        A.place = { kind: 'feat', code, floor: n, sub: k === 'restroom' ? ft.who || 'unknown' : k, number, at: ft.at };
        settle('half'); paint(true);
        A.L.ring(code, n, ft.at);
        say((FEAT[A.place.sub] || FEAT.unknown)[1]);
      };
      if (A.L.feature(code, n, k, number)) go(); else A.L.P.floor(code, n).then(go);
    }

    // A place: its name and code, how to find it, what's inside, what's still on, and Directions.
    // For families (Andrew's guide, Oct 13): every nursery, family restroom and quiet room on the campus,
    // each opening its room. Reached from its chip, which is there only when places.csv marks one.
    function familiesView() {
      const list = familyPlaces();
      return '<div class="pm-card pm-placecard"><div data-peek>' + x + '<h2 class="pm-h">For families</h2></div>' +
        (list.length ? '<ul class="pm-feats">' + list.map(z => featRow(z, z.g, true)).join('') + '</ul>' : '') + '</div>';
    }
    function placeView(pl) {
      if (pl.kind === 'dirs') return dirsView();
      if (pl.kind === 'families') return familiesView();
      if (pl.kind === 'door') return doorView(pl);
      if (pl.kind === 'feat') return featView(pl);
      if (pl.kind === 'restrooms' || pl.kind === 'elevators') return listFeatView(pl);
      if (pl.kind === 'nearest') return nearestView(pl);
      if (pl.kind === 'spot') {
        const s = A.c.spots.find(z => z.id === pl.id);
        if (!s) return '';
        return '<div class="pm-card pm-placecard"><div data-peek>' + x + '<p class="pm-k">' + esc(M.SPOT[s.spot] || 'Place') + '</p><h2 class="pm-h">' + esc(s.name || M.SPOT[s.spot]) + '</h2>' + (s.note ? '<p class="pm-line">' + I.pin + '<span>' + esc(s.note) + '</span></p>' : '') +
          dirsBtn(true) + '</div></div>';
      }
      if (pl.kind === 'hall') {
        // My own hall (§4.3 My room): "My room", the hall, then the floor and the rooms (the household's alone).
        const mine = !!stayHall() && M.norm(stayHall()) === M.norm(pl.name), sub = mine ? staySub(false, true) : '';
        const hc = mine ? bCode(M.find(A.c, pl.name)) : '';
        return '<div class="pm-card pm-placecard"><div data-peek>' + x + '<p class="pm-k">' + (mine ? esc(stayName()) : (M.find(A.c, pl.name) || {}).kind === 'hall' ? 'Hall' : 'Building') + '</p><h2 class="pm-h">' + esc(pl.name) + (hc ? ' <span class="pm-code">' + esc(hc) + '</span>' : '') + '</h2>' + (sub ? '<p class="pm-sub">' + esc(sub) + '</p>' : '') +
          dirsBtn(!!M.find(A.c, pl.name)) + '</div></div>';
      }
      const p = P(pl.code); if (!p) return '';
      const g = groups().find(z => z.key === keyOf(p.code)), main = g && g.main, isMain = main && main.code === p.code && !g.derived;
      const plan = planFor(pl);
      if (plan && g) return planView(p, g, isMain, plan);
      const w = where(p), line = M.placeLine(A.c, p, places(), w.kind === 'pin' && w.b ? M.nearestDoor(A.c, w.b.name, w) : null);
      const sub = w.kind === 'outdoor' && w.b ? 'Near ' + bShort(w.b) : [isMain ? '' : (w.b ? bShort(w.b) : g ? g.name : ''), isMain || !w.b ? '' : roomRest(p, w.b.name), line].filter(Boolean).join(' · ');
      const room = String(p.code).indexOf('/') > -1 && w.kind === 'building';
      // What the map is missing is said to members (the pins tool's people), never to the public (polish 2).
      const not = !member(A.ctx.year) ? '' : w.kind === 'outdoor' ? 'Outdoor · Not on the map yet' : w.kind === 'none' ? 'Not on the map yet' : room ? 'Room not on the map yet' : '';
      // Its features (a building's: its own and its rooms'; a room's: any its name doesn't already say),
      // each once: a room with one is listed there, not again among the rooms.
      const feats = isMain ? featuresIn(g) : (p.features || []).filter(f => String(p.name).toLowerCase().indexOf(featWord(f).toLowerCase()) < 0).map(f => ({ f, room: null }));
      const featured = feats.filter(f => f.room).map(f => f.room.code), plain = isMain ? g.rooms.filter(r => featured.indexOf(r.code) < 0) : [];
      const featList = feats.length ? '<ul class="pm-feats" aria-label="For families and access">' + feats.map(f => featRow(f, g)).join('') + '</ul>' : '';
      const rooms = plain.length ? '<ul class="pm-rooms">' + plain.map(r => roomRow(r, main.name, true)).join('') + '</ul>' : '';
      return '<div class="pm-card pm-placecard"><div data-peek>' + x + '<h2 class="pm-h" aria-label="' + esc(p.name + ', ' + p.code) + '">' + esc(roomName(p)) + ' <span class="pm-code" aria-hidden="true">' + esc(p.code) + '</span></h2>' +
        (sub ? '<p class="pm-sub">' + esc(sub) + '</p>' : '') + (not ? '<p class="pm-line">' + I.pin + '<span>' + esc(not) + '</span></p>' : '') +
        dirsTo(p) + '</div>' +
        // With floor plans, a place's own rows are "Today here" as on a room's sheet (§10.1); the campus
        // without plans keeps its words.
        featList + stillToday(isMain ? g.key : null, p.code, false, null, A.plans ? 'Today here' : '') + rooms + '</div>';
    }
    // One row style for a room everywhere (the place card, the cards, the picker).
    const roomRow = (r, bname, small) => { const fl = small && planFloor(r); return '<li><button type="button" class="pm-row" data-pm="room" data-code="' + esc(r.code) + '"><span>' + esc(inBuilding(r, bname)) + (fl != null && fl !== false ? '<small>' + esc(M.floorName(fl)) + '</small>' : small && (r.floor || r.inside) ? '<small>' + esc(M.placeLine(A.c, r, places())) + '</small>' : '') + '</span><code>' + esc(r.code) + '</code></button></li>'; };
    // What's still on today in a building (or at one room, or everywhere: all), as Today says it:
    // the timed rows first ("Now", then by time), then the places open all day, "Open · until 11 PM"
    // or "Closed · reopens 12:00 PM" (polish 1: Places said open while Today said closed during
    // services). One grid, so every title lines up; each row one 44 px button. skip: the buildings (keys)
    // whose cards already list theirs.
    function stillToday(key, code, all, skip, label) {
      const rows = today().filter(it => it.code && (all || (key ? keyOf(it.code) === key : String(it.code).toUpperCase() === String(code).toUpperCase())) && it.state !== 'past' && !(skip && skip.has(keyOf(it.code))));
      if (!rows.length) return '';
      const timed = rows.filter(it => !it.allDay).sort((a, b) => (b.state === 'now') - (a.state === 'now') || (a.start == null ? 1e9 : a.start) - (b.start == null ? 1e9 : b.start));
      const open = rows.filter(it => it.allDay && (it.state === 'now' || it.closed));
      const cap = all && A.allToday ? Infinity : all ? 6 : 5, list = timed.slice(0, cap).concat(open.slice(0, Math.max(0, cap - timed.length)));
      const more = rows.length - list.length;
      const at = it => all && P(it.code) ? ' · ' + (shorts[(where(P(it.code)).b || {}).name] || M.shortOf(where(P(it.code)).b) || P(it.code).name) : '';
      const row = it => {
        const k = it.allDay ? (it.closed ? 'Closed' : 'Open') : it.state === 'now' ? 'Now' : it.start != null ? clock(it.start) : it.startText || '';
        const tail = it.allDay ? (it.closed ? 'reopens ' + clock(it.closed.end) : it.end != null ? 'until ' + clock(it.end) : '') : it.state === 'now' && it.end != null ? 'until ' + clock(it.end) : '';
        const inner = '<span class="pm-ev__k">' + esc(k) + '</span><span class="pm-ev__t">' + esc(it.title) + (tail || at(it) ? '<small>' + esc((tail ? ' · ' + tail : '') + at(it)) + '</small>' : '') + '</span>';
        return '<li class="' + (it.state === 'now' && !it.closed ? 'is-now' : it.closed ? 'is-closed' : '') + '">' + (it.id ? '<button type="button" class="pm-ev" data-pm="event" data-id="' + esc(it.id) + '">' + inner + '</button>' : '<div class="pm-ev">' + inner + '</div>') + '</li>';
      };
      return '<div class="pm-today"><p class="pm-k">' + (label || 'Still today') + '</p><ul>' + list.map(row).join('') + (more > 0 ? '<li class="pm-today__more">' + (all ? '<button type="button" class="pm-link" data-pm="more-today">' + more + ' more</button>' : more + ' more') + '</li>' : '') + '</ul></div>';
    }
    // Every building, what's in it and what's still on: the chosen one first, then what's on now, then next.
    function cardsView() {
      const gs = groups(), sel = A.place && A.place.code ? keyOf(A.place.code) : '';
      const first = g => { const rows = today().filter(it => it.code && keyOf(it.code) === g.key && it.state !== 'past' && !it.allDay); const nowOn = rows.some(it => it.state === 'now'); const nx = rows.filter(it => it.start != null).map(it => it.start).sort((a, b) => a - b)[0]; return [g.key === sel ? 0 : 1, nowOn ? 0 : 1, nx == null ? 1e9 : nx]; };
      const order = gs.map((g, i) => ({ g, i, k: first(g) })).sort((a, b) => a.k[0] - b.k[0] || a.k[1] - b.k[1] || a.k[2] - b.k[2] || a.i - b.i).map(z => z.g);
      // Polish 2: the whole head is one 44 px row that opens the place (its sheet has Directions, filled);
      // the cards carry no Directions of their own (six or more on the full sheet before).
      const head = (attrs, name, code) => '<button type="button" class="pm-cardhead" ' + attrs + '><h3 class="pm-h">' + esc(name) + '</h3>' + (code ? '<span class="pm-code">' + esc(code) + '</span>' : '') + I.next + '</button>';
      const card = g => {
        const w = where(g.main), not = !member(A.ctx.year) ? '' : w.kind === 'outdoor' ? 'Outdoor · Not on the map yet' : w.kind === 'none' ? 'Not on the map yet' : '';
        const rooms = (g.derived ? g.all : g.rooms);
        const list = rooms.length ? '<ul class="pm-rooms">' + rooms.map(r => roomRow(r, g.name)).join('') + '</ul>' : '';
        return '<section class="pm-card' + (g.key === sel ? ' is-sel' : '') + '" aria-label="' + esc(g.name) + '">' + (g.derived ? '<div class="pm-cardhead"><h3 class="pm-h">' + esc(g.name) + '</h3><span class="pm-code">' + esc(g.key) + '</span></div>' : head('data-pm="room" data-code="' + esc(g.main.code) + '"', g.name, g.main.code)) +
          (not ? '<p class="pm-quiet">' + esc(not) + '</p>' : '') + stillToday(g.key) + list + '</section>';
      };
      const spots = A.c.spots.map(s => '<section class="pm-card">' + head('data-pm="spot" data-id="' + esc(s.id) + '"', s.name || M.SPOT[s.spot], '') + (s.note ? '<p class="pm-quiet">' + esc(s.note) + '</p>' : '') + '</section>').join('');
      return (A.mode === 'full' ? '<p class="pm-k">Buildings</p>' : '') + order.map(card).join('') + spots;
    }
    // The usual places, one tap each, each shown on the map with its card: my room, the next thing on
    // today, and the places Help points to (First Aid, the Lodging Desk…). noNext: leave out the next thing
    // (a laptop's Places, where its building's card already lists it).
    function quickChips(noNext) {
      const out = [], se = stayEnd();
      const chip = (attrs, icon, title, sub) => '<button type="button" class="pm-chip" ' + attrs + '>' + icon + '<span><b>' + esc(title) + '</b>' + (sub ? '<small>' + esc(sub) + '</small>' : '') + '</span></button>';
      if (se) out.push(chip('data-pm="set" data-v="stay"', I.bed, stayName(), staySub()));
      const nx = noNext ? null : nextEvent();
      if (nx) out.push(chip('data-pm="room" data-code="' + esc(nx.code) + '" aria-label="Next: ' + esc(nx.title) + '"', I.clock, nx.title, 'Next' + (nx.start != null ? ' · ' + clock(nx.start) : '')));
      out.push(helpChips(3));
      return out.join('');
    }
    // The places Help names (First Aid, the Lodging Desk…), in Help's order, one tap each.
    function helpChips(max) {
      const chip = (attrs, icon, title) => '<button type="button" class="pm-chip" ' + attrs + '>' + icon + '<span><b>' + esc(title) + '</b></span></button>';
      return (A.ctx.help || []).filter(h => h.place && P(h.place) && routable(P(h.place))).slice(0, max || 99).map(h => chip('data-pm="room" data-code="' + esc(h.place) + '"', /aid|medic|nurse/i.test(h.need) ? I.cross : /lodg|room|key/i.test(h.need) ? I.bed : /lost|found/i.test(h.need) ? I.search : '<span class="pm-i" aria-hidden="true"></span>', h.need)).join('');
    }

    /* ------------------------------------------------ Directions: the planner (Nov 5; docs/34 §4.5, §5.1) */

    // An end of the route: what its row says (label, sub), what ogc-map-route.js's plan takes (spec), and
    // the place it came from (place: what the map marks as where you're going while there's no route).
    // kind: here (My location) · stay (My room) · place · point (Set start's tap) · hall · spot · door · feat.
    const endHere = () => { const me = A.nav.me; return { kind: 'here', label: 'My location', spec: me && me.lat != null ? { lat: me.lat, lng: me.lng } : null, place: null }; };
    function endStay() {
      const s = A.stay; if (!s) return null;
      if (s.type === 'camper' && camper()) { const k = camper(); return { kind: 'stay', label: stayName(), sub: k.name || M.SPOT[k.spot] || '', spec: { x: k.cx, y: k.cy }, place: { kind: 'spot', id: k.id } }; }
      const h = stayHall() && M.find(A.c, stayHall());
      // (Its hall's door: no hall floor is public, so the route ends there and says so.)
      return h ? { kind: 'stay', label: stayName(), sub: staySub(true) || h.name, spec: { hall: h.name }, place: { kind: 'hall', name: h.name } } : null;
    }
    function endPlace(code) {
      const p = P(code); if (!p || !routable(p)) return null;
      const main = String(p.code).indexOf('/') < 0, w = where(p), b = w.b;
      const sub = (A.plans && planOf(p) ? factLine(p, main) : '') || (w.kind === 'outdoor' && b ? 'Near ' + bShort(b) : main ? p.code : [b ? bShort(b) : '', p.code].filter(Boolean).join(' · '));
      return { kind: 'place', code: p.code, label: roomName(p), sub, spec: { code: p.code }, place: { code: p.code } };
    }
    function endHall(name) {
      const b = M.find(A.c, name); if (!b) return null;
      if (stayHall() && M.norm(stayHall()) === M.norm(b.name)) return endStay();
      return { kind: 'hall', label: b.name, sub: '', spec: { building: b.name }, place: { kind: 'hall', name: b.name } };
    }
    function endSpot(id) {
      const s = A.c.spots.find(z => z.id === id);
      return s ? { kind: 'spot', label: spotName(id), sub: s.name ? M.SPOT[s.spot] || '' : '', spec: { x: s.cx, y: s.cy }, place: { kind: 'spot', id } } : null;
    }
    function endDoor(code, number) {
      const e = A.L && A.L.entrance(code, number), B = A.L && A.L.building(code); if (!e) return null;
      const d = doorRow(e.door);
      return { kind: 'door', label: (d && d.label) || e.name || 'Entrance', sub: B ? B.short : '', spec: { door: e.door }, place: { kind: 'door', code, number } };
    }
    // A restroom, the stairs or an elevator: its room in the public build, else the hall point by it.
    function endFeat(pl) {
      if (!pl.at) return null;
      const B = A.L && A.L.building(pl.code), w = FEAT[pl.sub] || FEAT.unknown;
      const at = { x: pl.at[0], y: pl.at[1], floor: +pl.floor };
      // Named as the arrival names it (ogc-map-route.js): "Women’s restroom", never "Restroom · Women".
      return { kind: 'feat', label: FEAT_END[pl.sub] || w[1], sub: [B ? B.short : '', M.floorName(pl.floor)].filter(Boolean).join(' · '),
        spec: pl.number ? { room: pl.code + '|' + pl.floor + '|' + pl.number } : at, alt: pl.number ? at : null, place: pl };
    }
    // What's open in the sheet, as the route's To.
    function endOfPlace(pl) {
      if (!pl) return null;
      if (pl.kind === 'hall') return endHall(pl.name);
      if (pl.kind === 'spot') return endSpot(pl.id);
      if (pl.kind === 'door') return endDoor(pl.code, pl.number);
      if (pl.kind === 'feat') return endFeat(pl);
      return pl.code && !pl.kind ? (pl.room ? endRoom(pl.room) : endPlace(pl.code)) : null;
    }
    // A Conference place's own room by IWU's name (the Chapel's Balcony): the place, ending at that room.
    function endRoom(r) {
      const e = r && endPlace(r.code); if (!e) return null;
      const b = where(P(r.code)).b;
      return Object.assign(e, { label: r.name, sub: [b ? bShort(b) : '', M.floorName(r.floor)].filter(Boolean).join(' · '), spec: { room: r.b + '|' + r.floor + '|' + r.number }, place: { code: e.code, room: r } });
    }
    // The rooms of a Conference place that has more than one in the build, by IWU's name, where the place's
    // own name doesn't already say it (the Chapel's and PPAC's Balcony beside their Auditorium; round 2
    // part 2: "balcony" found nothing). From the walking graph's marks, once it's read.
    function namedRooms() {
      const w = A.build && A.build.walk, ix = A.P && A.P.places; if (!w || !ix || !w.marks) return [];
      const col = {}; (w.mark_cols || []).forEach((k, i) => { col[k] = i; });
      const per = {};
      w.marks.forEach(m => { if (m[col.kind] === 'room' && m[col.codes]) String(m[col.codes]).split('|').forEach(c => { (per[c] = per[c] || []).push(m); }); });
      const tc = s => String(s || '').toLowerCase().replace(/(^|[\s/(-])([a-z])/g, (z, a, b) => a + b.toUpperCase());
      const out = [];
      Object.keys(per).forEach(c => {
        const p = P(c), x = ix[String(c).toUpperCase()]; if (!p || !x || per[c].length < 2) return;
        per[c].forEach(m => { const name = tc(m[col.name]); if (name && String(p.name).toLowerCase().indexOf(name.toLowerCase()) < 0) out.push({ code: p.code, b: x.code, floor: +m[col.floor], number: String(m[col.number]), name }); });
      });
      return out;
    }
    // A place's room by its number (?to=J&room=2-220), as namedRooms has it ({ code, b, floor, number, name }),
    // only when the build says it's one of that place's rooms, named as IWU names it → Promise(room | null).
    function roomAt(code, room) {
      const p = P(code), B = p && A.P ? A.P.by[keyOf(p.code)] : null;
      const its = p && A.P ? (A.P.roomsOf(p.code) || []).some(r => +r.floor === +room.floor && String(r.number) === String(room.number)) : false;
      if (!B || !B.ok || !its) return Promise.resolve(null);
      return A.P.floor(B.code, +room.floor).then(f => {
        const x = f && f._by[String(room.number)], name = x && x.r.name ? M.floors.titleCase(x.r.name) : '';
        return name ? { code: p.code, b: B.code, floor: +room.floor, number: String(room.number), name } : null;
      }, () => null);
    }
    const roomV = r => 'room:' + r.code + '|' + r.floor + '|' + r.number;
    const roomOfV = v => namedRooms().find(r => roomV(r) === v) || null;
    // A choice in From's or To's Search (its data-v), as an end.
    function routeEnd(v) {
      v = String(v || '');
      if (v === 'here') return endHere();
      if (v === 'stay') return endStay();
      if (v.indexOf('hall:') === 0) return endHall(v.slice(5));
      if (v.indexOf('spot:') === 0) return endSpot(v.slice(5));
      if (v.indexOf('room:') === 0) return endRoom(roomOfV(v));
      if (v.indexOf('feat:') === 0) {
        const e = endFrom(v), f = e && A.L && A.L.feature(e.code, e.floor, e.sub === 'stairs' || e.sub === 'elevator' ? e.sub : 'restroom', e.number);
        return f ? endFeat(Object.assign(e, { at: f.at })) : null;
      }
      return endPlace(v);
    }
    // Step-free (P8): kept on this device; until it's set, on when the signed-in household ticked No stairs.
    const SF_KEY = 'ogc-map-stepfree';
    const stepFree = () => { const v = LS.get(SF_KEY, null); return v == null ? !!(A.stay && A.stay.stairs) : !!v; };
    // The router waits for the year's plans (or their failing): a campus with none routes outdoors.
    const whenPlans = fn => { if (!A.plans || A.L || A.plansFailed || !M.floors) fn(); else A.plansWait.push(fn); };
    function routerNow() {
      const out = () => M.routerOf(A.c);
      if (!A.P) return Promise.resolve(out());
      if (A.build) return Promise.resolve(M.routerOf(A.c, A.build));
      return Promise.all([A.P.walkRaw(), A.P.area()]).then(([walk, area]) => {
        if (!walk) return out();
        if (!A.build) A.build = { walk, area, index: A.P.ix };
        return M.routerOf(A.c, A.build);
      }, out);
    }
    // The venue's date and time now (the doors' hours and closures are the venue's), and its minutes.
    function venueNow() {
      const n = A.ctx.now ? A.ctx.now() : null;
      if (!n) return { date: '', time: '', minutes: null };
      const m = Math.max(0, Math.floor(n.minutes)) % 1440;
      return { date: n.date, time: String(Math.floor(m / 60)).padStart(2, '0') + ':' + String(m % 60).padStart(2, '0'), minutes: n.minutes };
    }
    // From, before anyone chooses (§4.5): My location on a phone on campus to 40 m, else My room, else none.
    // (Going to My room, From never starts there: Choose start instead.)
    function fromDefault(to) {
      const me = A.nav.me;
      to = to || (A.dir && A.dir.to);
      if (touch() && A.mode === 'full' && me && me.lat != null && near(me) && me.acc <= 40 && A.watch != null) return endHere();
      return to && to.kind === 'stay' ? null : endStay();
    }
    // Directions to an end: the planner in the sheet (half) or the panel. Closing it goes back to the place.
    function openDirs(to) {
      if (!to) return;
      let back = A.place && A.place.kind !== 'dirs' ? A.place : A.dir ? A.dir.back : null;
      // (A room reached and opened by Done is a layer again under the planner.)
      if (back && back.arrived) { back = Object.assign({}, back); delete back.arrived; }
      // (choosing: From or To waiting for a tap on the map, Choose on map.)
      A.dir = { to, from: fromDefault(to), auto: true, plan: null, gen: 0, focus: -1, back, at: null, choosing: '' };
      A.place = { kind: 'dirs' };
      // (The place's own framing, still on its way, gives way to the route's.)
      A.fitKey = '';
      settle('half');
      // On a phone it asks where you are (once; never when it's been refused): My location, if it's good enough.
      if (touch() && A.mode === 'full' && A.perm !== 'denied' && A.watch == null) locate();
      paint();
      say('Directions · ' + to.label);
      replan(true);
    }
    // (back: what opens after it; Arrived's Done opens where it went.)
    function closeDirs(back) {
      const d = A.dir;
      if (A.walk) endWalk(true);
      A.dir = null;
      // (The planner's own ask for the phone's location: its "Location off" goes with it, so the plain map's
      // peek is Next only again, §2.3. A Locate tap still says it.)
      if (A.watch == null && /^Location (off|unavailable)$/.test(A.nav.status)) A.nav.status = '';
      if (A.map) { A.map.route(null); A.map.reach(null); }
      if (A.L) { A.L.pick(null); A.L.route(null); A.L.focus(null); }
      A.place = back !== undefined ? back : d && d.back ? d.back : null;
      settle(A.place ? 'half' : 'peek');
      paint(!!A.place);
    }
    // The route again (an end changed, Step-free, a fix): planned over the one router, drawn, framed.
    // animate: the line draws in (a new trip); a reroute appears with no motion (§8).
    // The plan for what's open (its ends, Step-free, the venue's time), over the one router.
    function planWith(d, R) {
      const now = venueNow(), o = { places: places(), stepFree: stepFree(), date: now.date, time: now.time };
      let r;
      if (!d.from) r = { ok: false, reason: 'Choose start', side: 'from' };
      else if (!d.from.spec) r = { ok: false, reason: d.from.kind === 'here' ? (A.nav.status && A.nav.status !== 'Approximate location' ? A.nav.status : 'Locating') : 'Choose start', side: 'from' };
      else if (!d.to || !d.to.spec) r = { ok: false, reason: 'Choose place', side: 'to' };
      else {
        r = planStepFree(R, d.from.spec, d.to.spec, o);
        // A restroom the public build has no room for: to the hall point beside it instead.
        if (d.to.alt && (!r.ok || r.unmapped)) { const r2 = planStepFree(R, d.from.spec, d.to.alt, o); if (r2.ok) r = r2; }
      }
      return r;
    }
    // Step-free where a door on the way hasn't been checked (docs/35 §6 question 5, decided Nov 6): the
    // best route with no stairs and no outdoor steps through doors nobody has checked yet (never one checked
    // and found not step-free), each named "· Not checked" in the legs; Start stays on. Stairs as the only
    // way up stays "No step-free route" (the router's own answer).
    function planStepFree(R, from, to, o) {
      const r = M.plan(R, from, to, o);
      if (r.ok || r.reason !== 'No step-free route' || r.why !== 'Doors not checked') return r;
      const r2 = M.plan(R, from, to, Object.assign({}, o, { unchecked: true }));
      if (!r2.ok) return r;
      const open = x => { if (!x || !x.name) return false; const row = x.id ? doorRow(x.id) : null; return !row || (!row.checked && row.stepFree !== 'yes'); };
      r2.notChecked = [r2.exit, r2.door].filter(open).map(x => x.name).filter((n, i, a) => a.indexOf(n) === i);
      return r2;
    }
    // The route's own box (with room round it): the map may go that far while it shows (viewer.reach).
    function routeBox(r) {
      if (!r || !r.ok) return null;
      let x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity;
      r.parts.forEach(p => p.pts.forEach(q => { x0 = Math.min(x0, q[0]); y0 = Math.min(y0, q[1]); x1 = Math.max(x1, q[0]); y1 = Math.max(y1, q[1]); }));
      return isFinite(x0) ? { x: x0 - 60, y: y0 - 60, w: x1 - x0 + 120, h: y1 - y0 + 120 } : null;
    }
    function replan(animate) {
      // (Walking keeps its own route: a reroute replans from where you are, walkReroute.)
      const d = A.dir; if (!d || A.walk) return;
      const gen = d.gen = d.gen + 1;
      whenPlans(() => routerNow().then(R => {
        if (A.dir !== d || d.gen !== gen) return;
        const r = planWith(d, R);
        const was = d.plan, same = !!(was && was.ok && r.ok && was.legsText === r.legsText);
        d.plan = r; d.focus = -1;
        if (A.map) A.map.reach(routeBox(r));
        if (r.ok) {
          if (A.L) {
            A.L.pick(null);
            A.L.route(r);
            // The destination's building opens on the room's floor (§4.5): the end's floor.
            const end = r.steps[r.steps.length - 1];
            if (end && end.building && +end.floor) A.L.focus(end.building, +end.floor); else A.L.focus(null);
          }
        } else {
          if (A.L) A.L.route(null);
          if (A.map) A.map.route(null);
        }
        paint();
        A.fitKey = '';
        if (r.ok) { showRoute(animate && !same, null); fitRoute(r); }
        else if (r.reason === 'Set start') startPick(r.building);
        else {
          // No route to draw: where it's going, framed as its own sheet frames it.
          const tp = d.to && d.to.place, p = tp && tp.code && !tp.kind ? P(tp.code) : null, w = p ? where(p) : null;
          const b = w && w.b ? M.boxOf(A.c, [w.b.name], 10) : tp && tp.kind === 'hall' ? M.boxOf(A.c, [tp.name], 10) : null;
          if (b && A.map) A.map.fit(roomy(b, .45), 20, true);
        }
      }));
    }
    function showRoute(animate, s) {
      const d = A.dir, r = d && d.plan;
      if (!A.map) return;
      if (!r || !r.ok) { A.map.route(null); return; }
      A.map.route({ parts: r.parts, floorOf: code => A.L ? A.L.shown(code) : null, start: r.steps[0] ? r.steps[0].at : null,
        stretch: s && s.pts && s.pts.length > 1 ? { id: String(d.focus), pts: s.pts, floor: s.floor, building: s.building } : null, animate: !!animate, keep: stepNames(r) });
    }
    // The buildings the steps name ("Head toward Barnes"), by the campus's names: they keep their names on
    // the map while the route shows, with those it passes within 30 m of (ogc-map.js; docs/35 §2.5).
    function stepNames(r) {
      const text = r.steps.map(s => s.text + ' ' + (s.detail || '')).join(' | ');
      return A.c.items.filter(i => i.lab && [i.name, shorts[i.name], bShort(i)].filter(w => w && String(w).length > 2).some(w => text.indexOf(w) > -1)).map(i => i.name);
    }
    // The whole route in view (§4.5), clear of the card and the sheet, or the panel: the line itself, from
    // the start dot to the room's door, with 24 px round it on a phone (docs/35 §2.5, round 2: with the
    // destination's whole building, a 350 ft walk filled 40 px of a phone's width).
    function fitRoute(r) {
      if (!A.map || !r || !r.ok) return;
      let x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity;
      const add = (x, y) => { x0 = Math.min(x0, x); y0 = Math.min(y0, y); x1 = Math.max(x1, x); y1 = Math.max(y1, y); };
      r.parts.forEach(p => p.pts.forEach(q => add(q[0], q[1])));
      // (A start at a hall's door, on a laptop: the hall's name and pin in view too, not under the map's
      // scale. A phone's strip of map keeps the route as big as it can.)
      const fh = A.mode !== 'full' && A.dir && A.dir.from && A.dir.from.place && A.dir.from.place.kind === 'hall' ? M.find(A.c, A.dir.from.place.name) : null;
      if (fh && fh.lx != null) add(fh.lx, fh.ly);
      if (!isFinite(x0)) return;
      const w = Math.max(40, x1 - x0), h = Math.max(40, y1 - y0), cx = (x0 + x1) / 2, cy = (y0 + y1) / 2;
      A.map.fit({ x: cx - w / 2, y: cy - h / 2, w, h }, A.mode === 'full' ? 24 : 48, true);
    }
    // Inside a drawn building (§4.5): its entrance floor opens, and one tap on it sets the start.
    function startPick(name) {
      if (!A.L || !A.P || !name) return;
      const B = A.P.list.find(b => b.item && M.norm(b.item.name) === M.norm(name)) || A.P.list.find(b => M.norm(b.name) === M.norm(name));
      if (!B) return;
      A.L.focus(B.code, B.entrance);
      A.L.pick(pt => {
        const d = A.dir; if (!d) return;
        A.L.pick(null);
        d.from = { kind: 'point', label: (B.short || B.name) + ' · ' + M.floorName(pt.floor), sub: '', spec: { x: pt.x, y: pt.y, floor: pt.floor }, place: null };
        d.auto = false;
        replan(true);
      });
      if (B.box) A.map.fit(B.box, 24, true);
    }
    // A location fix (or its failing) with the planner open: My location as From when it's good enough,
    // the route again as you move (8 m or more), and My room or Choose start when there's no location.
    function onFix() {
      const d = A.dir; if (!d) return;
      const me = A.nav.me, bad = A.nav.status === 'Location off' || A.nav.status === 'Location unavailable';
      const moved = () => !d.at || !me || Math.hypot(me.x - d.at[0], me.y - d.at[1]) >= 8;
      if (d.from && d.from.kind === 'here') {
        if (bad) { if (d.auto) d.from = endStay(); d.at = null; replan(true); return; }
        if (me && me.lat != null && moved()) { const first = !d.from.spec; d.at = [me.x, me.y]; d.from = endHere(); replan(first); return; }
        paint(); return;
      }
      if (d.auto && !bad) { const f = fromDefault(); if (f && f.kind === 'here') { d.at = [me.x, me.y]; d.from = f; replan(true); return; } }
      paint();
    }
    function setEnd(which, e) {
      const d = A.dir; if (!d || !e) return;
      if (A.L) A.L.pick(null);
      d[which] = e;
      if (which === 'from') d.auto = false;
      d.choosing = '';
      if (e.kind === 'here' && touch() && A.watch == null) locate();
      paint();
      replan(true);
    }
    // Choose on map (docs/35 §2.5): that end waits for one tap on the map; outdoors it's a dropped pin
    // there, on a drawn building's open floor the nearest hall point on that floor (today's Set start).
    function chooseOnMap(which) {
      const d = A.dir; if (!d) return;
      d.choosing = which; d[which] = null;
      if (which === 'from') d.auto = false;
      if (SH && SH.stop !== 'peek') SH.set('peek', 'ease');
      pickEnd();
      paint();
      replan(false);
      say('Tap the map');
    }
    function pickEnd() {
      const d = A.dir; if (!A.L) return;
      if (!d || !d.choosing) { A.L.pick(null); return; }
      A.L.pick(pt => {
        const B = A.L.building(pt.code);
        setEnd(d.choosing, { kind: 'point', label: (B ? B.short || B.name : 'Dropped pin') + ' · ' + M.floorName(pt.floor), sub: '', spec: { x: pt.x, y: pt.y, floor: pt.floor }, place: null });
      });
    }
    // A tap on the map while an end waits for it, outdoors. (On a drawn building whose floor shows, however
    // far it's zoomed, that floor at once, as Set start's tap is: the check saw a first tap on Barnes's
    // floor become a pin with no floor, then "Barnes · Set start" and a second tap.)
    function mapChoose(pt, bn) {
      const d = A.dir; if (!d || !d.choosing || !pt) return false;
      const B = A.P && A.L ? A.P.list.find(x => x.item && M.inPoly(pt.x, pt.y, x.item.pts || []) && (!bn || M.norm(x.item.name) === M.norm(bn))) : null;
      const f = B ? A.L.shown(B.code) : null;
      if (B && f != null) {
        setEnd(d.choosing, { kind: 'point', label: (B.short || B.name) + ' · ' + M.floorName(f), sub: '', spec: { x: pt.x, y: pt.y, floor: f }, place: null });
        return true;
      }
      setEnd(d.choosing, { kind: 'point', label: 'Dropped pin', sub: '', spec: { x: pt.x, y: pt.y, label: 'Dropped pin' }, place: null });
      return true;
    }

    // The planner's view (§4.5): From and To, Swap, Step-free, the summary, Start (a phone) and Steps
    // (a phone; a laptop lists them in full). Every state is its status word (§4.11).
    const endIcon = e => !e ? I.pin : e.kind === 'here' ? '<span class="pm-medot" aria-hidden="true"></span>' : e.kind === 'stay' ? I.bed : I.pin;
    // (The phone's card, round 2: a start that isn't you or your room is a ring, as Google draws it; the
    // end is the pin. No From and To words: the order and the dotted line say it, the row's name says it.)
    I.ring = '<svg class="pm-i" viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="5.5" fill="none" stroke="currentColor" stroke-width="2.4"/></svg>';
    I.info = svg('M12 20.5a8.5 8.5 0 1 0 0-17 8.5 8.5 0 0 0 0 17ZM12 11v5.5M12 7.8v.01');
    const cardIcon = (which, e) => e && e.kind === 'here' ? '<span class="pm-medot" aria-hidden="true"></span>' : e && e.kind === 'stay' ? I.bed : which === 'from' ? I.ring : I.pin;
    function endRow(which, e, main, sub, card) {
      const k = which === 'from' ? 'From' : 'To';
      return '<button type="button" class="pm-end' + (e ? '' : ' is-empty') + '" data-pm="end" data-which="' + which + '" aria-label="' + esc(k + ': ' + main + (sub ? ', ' + sub : '')) + '">' +
        (card ? cardIcon(which, e) : '<span class="pm-end__k" aria-hidden="true">' + k + '</span>' + endIcon(e)) + '<span class="pm-end__m"><b>' + nb(main) + '</b>' + (sub ? '<small>' + nb(sub) + '</small>' : '') + '</span></button>';
    }
    // What the From and To rows say: an end, or its state (Locating, Not on campus, "Barnes · Set start",
    // Tap the map), else Choose start / Choose place.
    function endWords(d) {
      const r = d.plan, phone = A.mode === 'full', st = A.nav.status && A.nav.status !== 'Locating' ? A.nav.status : '';
      let fMain = d.from ? d.from.label : 'Choose start', fSub = d.from ? d.from.sub || '' : '';
      if (d.from && d.from.kind === 'here') fSub = !d.from.spec ? (st || 'Locating') : st;
      else if (!d.from && st && touch() && phone) fSub = st;
      if (r && !r.ok && r.reason === 'Set start') { const it = M.find(A.c, r.building); fMain = (it ? bShort(it) : r.building) + ' · Set start'; fSub = ''; }
      if (r && !r.ok && r.side === 'from' && r.reason === 'Not on campus') fSub = 'Not on campus';
      let tMain = d.to ? d.to.label : 'Choose place', tSub = d.to ? d.to.sub || '' : '';
      if (d.choosing === 'from') { fMain = 'Tap the map'; fSub = ''; }
      if (d.choosing === 'to') { tMain = 'Tap the map'; tSub = ''; }
      return { st, fMain, fSub, tMain, tSub };
    }
    // The phone's card at the top (docs/35 §2.5): ‹ closes the planner (one layer), From over To joined by
    // a dotted line, each a 44 px row opening Search for that end, ⇅ swaps them.
    function dcardView() {
      const d = A.dir; if (!d) return '';
      const w = endWords(d);
      return '<div class="pm-dcard" role="group" aria-label="Directions"><button type="button" class="pm-dback" data-pm="dirs-close" aria-label="Back" title="Back">' + I.prev + '</button>' +
        '<div class="pm-dends">' + endRow('from', d.choosing === 'from' ? null : d.from, w.fMain, w.fSub, true) + endRow('to', d.choosing === 'to' ? null : d.to, w.tMain, w.tSub, true) + '</div>' +
        '<button type="button" class="pm-swap" data-pm="swap" aria-label="Swap" title="Swap From and To"' + (d.from && d.to ? '' : ' disabled') + '>' + I.swap + '</button></div>';
    }
    // The steps by where they are (§4.5: OUTSIDE · BARNES · 1ST FLOOR); a door goes with the stretch before it.
    const stepHead = s => {
      if (!s.building || !+s.floor) return 'Outside';
      const B = A.L && A.L.building(s.building);
      return [B ? B.short || B.name : s.building, M.floorName(s.floor)].join(' · ');
    };
    function stepGroups(r) {
      const gs = [];
      r.steps.forEach((s, i) => {
        const g = gs[gs.length - 1], head = s.kind === 'door' && g ? g.head : stepHead(s);
        if (g && g.head === head) g.rows.push(i); else gs.push({ head, rows: [i] });
      });
      return gs;
    }
    function stepRow(r, i) {
      const s = r.steps[i], n = r.steps.length;
      return '<li><button type="button" class="pm-step' + (A.dir.focus === i ? ' is-on' : '') + '" data-pm="step" data-i="' + i + '" aria-label="' + esc('Step ' + (i + 1) + ' of ' + n + ' · ' + s.text + (s.detail ? ' · ' + s.detail : '') + (s.distance ? ' · ' + s.distance : '')) + '">' +
        (I['r-' + s.icon] || I['r-straight']) + '<span class="pm-step__t">' + nb(s.text) + (s.detail ? '<small>' + nb(s.detail) + '</small>' : '') + '</span>' +
        (s.distance ? '<span class="pm-step__d" aria-hidden="true">' + esc(s.distance) + '</span>' : '') + '</button></li>';
    }
    const stepsList = r => '<div class="pm-steps">' + stepGroups(r).map(g => '<p class="pm-k pm-steps__h">' + esc(g.head) + '</p><ol class="pm-steps__l">' + g.rows.map(i => stepRow(r, i)).join('') + '</ol>').join('') + '</div>';
    // The legs (§4.5), each '›' kept with the leg before it, so a wrapped line never starts with one; a door
    // nobody has checked, on a Step-free route, says so (question 5).
    function legsHtml(r) {
      const nc = r.notChecked || [];
      return '<p class="pm-legs">' + r.legs.map((l, i, a) => '<span class="pm-leg">' + (I['r-' + l.icon] || '') + '<span>' + nb(l.text + (l.icon === 'door' && nc.indexOf(l.text) > -1 ? ' · Not checked' : '')) + '</span>' + (i < a.length - 1 ? '<span class="pm-legs__sep" aria-hidden="true">›</span>' : '') + '</span>').join('') + '</p>' +
        // (One the legs left out, the way out of the building it starts in: a line of its own.)
        nc.filter(n => !r.legs.some(l => l.icon === 'door' && l.text === n)).map(n => '<p class="pm-dnote">' + esc(n + ' · Not checked') + '</p>').join('');
    }
    // A phone's planner (docs/35 §2.5, round 2): From and To are the card at the top (dcardView); the sheet
    // at its peek is the time with the Step-free chip, the distance and arrival, the legs and Start; pulled
    // up, the steps follow Start (no Steps link). With no route, the one state in the time's place.
    function dirsSheet(d, r, ok) {
      const sf = stepFree(), w = endWords(d);
      const chip = '<span class="pm-sfc"><button type="button" class="pm-chip pm-chip--sf" data-pm="sf" aria-pressed="' + sf + '" aria-describedby="pm-sf-d">' + I['f-accessible entrance'] + '<span><b>Step-free</b></span></button>' +
        '<button type="button" class="pm-info" data-pm="sf-info" aria-label="About Step-free" aria-expanded="' + !!A.sfInfo + '" aria-controls="pm-sf-d" title="No stairs or steps">' + I.info + '</button></span>';
      const info = '<p class="pm-sfinfo" id="pm-sf-d"' + (A.sfInfo ? '' : ' hidden') + '>No stairs or steps</p>';
      let head = '', rest = '', why = '';
      if (ok) {
        const n = venueNow(), arrive = n.minutes != null ? arriveAt(n.minutes, r.sec) : '';
        head = '<p class="pm-dsum__t">' + r.min + ' min</p>' + chip + '<p class="pm-dsum__l">' + esc([r.distance, arrive].filter(Boolean).join(' · ')) + '</p>';
        rest = legsHtml(r) + (r.notes || []).map(t => '<p class="pm-dnote">' + esc(t) + '</p>').join('');
      } else if (r) {
        why = r.reason;
        // (A state the From row already says isn't said twice: the reason sits under Start alone.)
        const inFrom = r.side === 'from' && (r.reason === 'Choose start' || r.reason === 'Set start' || r.reason === 'Not on campus' || r.reason === 'Locating' || r.reason === w.st);
        const word = inFrom ? (r.reason === 'Set start' ? 'Tap where you are on the floor' : '') : r.reason;
        head = (word ? '<p class="pm-dsum__t pm-dsum__t--state" id="pm-why">' + esc(word) + '</p>' : '') + chip + (!inFrom && r.why ? '<p class="pm-dsum__l">' + esc(r.why) + '</p>' : '');
      } else head = chip;
      const reasonUnder = r && !r.ok && !/id="pm-why"/.test(head);
      const go = '<p class="pm-btns pm-go"><button type="button" class="pm-btn pm-btn--go" data-pm="start"' + (ok ? '' : ' disabled aria-describedby="pm-why"') + '>Start</button></p>' + (reasonUnder ? '<p class="pm-why" id="pm-why">' + esc(why) + '</p>' : '');
      return '<div class="pm-card pm-placecard pm-dirs pm-dirs--sheet"><div data-peek><h2 class="pm-h ogc-sr" tabindex="-1">Directions</h2><div class="pm-dsum pm-dsum--head' + (ok ? '' : ' is-none') + '">' + head + '</div>' + info + rest + go + '</div>' +
        (ok ? '<h3 class="ogc-sr">Steps</h3>' + stepsList(r) : '') + '</div>';
    }
    function dirsView() {
      const d = A.dir; if (!d) return '';
      const r = d.plan, phone = A.mode === 'full', ok = !!(r && r.ok);
      if (phone) return dirsSheet(d, r, ok);
      // A laptop's panel keeps its planner as it was (docs/35 §2.8): From, To and Step-free over the summary
      // and the steps in full.
      const w = endWords(d), st = w.st, fMain = w.fMain, fSub = w.fSub;
      const rows = '<div class="pm-ends">' + endRow('from', d.choosing === 'from' ? null : d.from, fMain, fSub) + endRow('to', d.choosing === 'to' ? null : d.to, w.tMain, w.tSub) +
        '<button type="button" class="pm-swap" data-pm="swap" aria-label="Swap" title="Swap From and To"' + (d.from && d.to ? '' : ' disabled') + '>' + I.swap + '</button></div>';
      const sf = stepFree();
      const sfRow = '<div class="pm-sfrow"><span class="pm-sfrow__t" id="pm-sf-l">Step-free<small id="pm-sf-d">No stairs or steps</small></span>' +
        '<button type="button" class="pm-switch" role="switch" aria-checked="' + sf + '" aria-labelledby="pm-sf-l" data-pm="sf"><span class="pm-switch__k"></span></button></div>';
      // The summary (§4.5), or the one state that stands in its place (§4.11).
      let sum = '';
      if (ok) {
        const n = venueNow(), arrive = n.minutes != null ? arriveAt(n.minutes, r.sec) : '';
        const notes = (r.notes || []).map(t => '<p class="pm-dnote">' + esc(t) + '</p>').join('');
        sum = '<div class="pm-dsum"><p class="pm-dsum__t">' + r.min + ' min</p><p class="pm-dsum__l">' + esc([r.distance, arrive].filter(Boolean).join(' · ')) + '</p>' + legsHtml(r) + notes + '</div>';
      } else if (r) {
        const word = r.reason === 'Set start' ? 'Set start' : r.reason;
        // (A state the From row already says isn't said twice.)
        const inFrom = r.side === 'from' && (r.reason === 'Choose start' || r.reason === 'Set start' || r.reason === 'Not on campus' || r.reason === 'Locating' || r.reason === st);
        if (!inFrom) sum = '<div class="pm-dsum is-none"><p class="pm-dsum__t pm-dsum__t--state" id="pm-why">' + esc(word) + '</p>' + (r.why ? '<p class="pm-dsum__l">' + esc(r.why) + '</p>' : '') + '</div>';
        else if (r.reason === 'Set start') sum = '<div class="pm-dsum is-none"><p class="pm-dsum__l" id="pm-why">Tap where you are on the floor</p></div>';
      }
      const steps = ok ? stepsList(r) : '';
      return '<div class="pm-card pm-placecard pm-dirs"><div data-peek><h2 class="pm-h ogc-sr" tabindex="-1">Directions</h2>' + x.replace('data-pm="close"', 'data-pm="dirs-close"') + rows + sfRow + sum + steps + '</div></div>';
    }
    // A step framed (§4.5, §5.1): its building on its floor, its stretch at full strength, flown to (280 ms).
    function frameStep(i, quiet) {
      const d = A.dir, r = d && d.plan; if (!r || !r.ok || !r.steps[i]) return;
      const s = r.steps[i];
      d.focus = i;
      if (A.L && s.building) { const B = A.L.building(s.building); if (s.kind === 'door') A.L.focus(s.building, B ? B.entrance : null); else if (+s.floor) A.L.focus(s.building, +s.floor); }
      showRoute(false, s);
      const b = s.box;
      if (b && A.map) { const w = Math.max(30, b[2] - b[0]), h = Math.max(30, b[3] - b[1]), cx = (b[0] + b[2]) / 2, cy = (b[1] + b[3]) / 2; A.map.fit({ x: cx - w / 2, y: cy - h / 2, w, h }, 48, true); }
      A.el.querySelectorAll('.pm-step').forEach(e => e.classList.toggle('is-on', +e.dataset.i === i));
      if (!quiet && A.map.live) A.map.live('Step ' + (i + 1) + ' of ' + r.steps.length + ' · ' + s.text);
    }
    /* ------------------------------------------------ Start: walking it (a phone; docs/34 §4.6–4.11) */

    // A.walk while Start is on:
    //   i: the step you're on (the location moves it on outdoors; Next and Back inside and at a door);
    //   view: a step looked at by hand outdoors (‹ ›) while the location goes on, or -1;
    //   follow: the camera keeps you in the middle; run, m: the stretch outdoors you're on, and how far
    //   along it you've come (never back); off: metres before each step; fixAt: the last fix (30 s without
    //   one greys the dot); offAt: off the route since (10 s reroutes); sim: the demo's walk (Mockup: walk it).
    // The steps are the planner's (§10.2's fixed sentences); nothing here makes a sentence up.
    const WALK_S = 1.8;   // px a metre while following: about 200 m across a phone, the destination's floor open
    const still = () => !!(window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches);
    I.prev = svg('M14.5 5.5 8 12l6.5 6.5');
    I.check = svg('M6.5 12.5l3.8 3.8 7.2-8.3');
    const walkOffsets = r => { const o = [0]; r.steps.forEach((s, k) => { o[k + 1] = o[k] + (s.metres || 0); }); return o; };
    // The stretch outdoors a step is in (the steps outdoors either side of it) as one line, with the
    // metres along it at each point and at each step's end.
    function walkRun(r, i) {
      if (!r.steps[i] || r.steps[i].kind !== 'outside') return null;
      let a = i, b = i;
      while (a > 0 && r.steps[a - 1].kind === 'outside') a--;
      while (b + 1 < r.steps.length && r.steps[b + 1].kind === 'outside') b++;
      const pts = [], cum = [], ends = [];
      let m = 0;
      for (let k = a; k <= b; k++) {
        (r.steps[k].pts.length ? r.steps[k].pts : [r.steps[k].at]).forEach((p, j) => {
          if (pts.length && j === 0) return;
          if (pts.length) m += Math.hypot(p[0] - pts[pts.length - 1][0], p[1] - pts[pts.length - 1][1]);
          pts.push(p); cum.push(m);
        });
        ends.push(m);
      }
      return { a, b, pts, cum, ends, L: m };
    }
    // The nearest point of the stretch to (x, y), looking only between lo and hi metres along it.
    function walkProject(run, x, y, lo, hi) {
      let best = null;
      for (let k = 1; k < run.pts.length; k++) {
        if (run.cum[k] < lo || run.cum[k - 1] > hi) continue;
        const a = run.pts[k - 1], b = run.pts[k], dx = b[0] - a[0], dy = b[1] - a[1], L = dx * dx + dy * dy;
        const t = L ? Math.max(0, Math.min(1, ((x - a[0]) * dx + (y - a[1]) * dy) / L)) : 0, d = Math.hypot(a[0] + t * dx - x, a[1] + t * dy - y);
        if (!best || d < best.d) best = { d, m: run.cum[k - 1] + t * Math.sqrt(L) };
      }
      return best;
    }
    const walkAt = (run, m) => { for (let k = 1; k < run.pts.length; k++) if (run.cum[k] >= m) { const a = run.pts[k - 1], b = run.pts[k], l = run.cum[k] - run.cum[k - 1], t = l ? (m - run.cum[k - 1]) / l : 0; return [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t]; } return run.pts[run.pts.length - 1]; };
    const walkShown = () => A.walk.view > -1 ? A.walk.view : A.walk.i;
    // The step the card says outdoors, while the location leads (round 2 part 2, the last checks: the card
    // said the step under way, so just after a turn "Turn left · 80 ft" read as a turn 80 ft on): the turn
    // ahead, with the feet until it. The first stretch keeps its own words ("Toward Barnes") for its first
    // 10 m; a turn its own for 3 m past it. Looking by hand (‹ ›) shows the step looked at.
    function walkCard(hand) {
      const wk = A.walk, r = A.dir && A.dir.plan, i = wk.i, run = wk.run;
      if ((hand && wk.view > -1) || wk.rerouting || !walkLive() || !r || !run || i < run.a || i > run.b) return hand ? walkShown() : i;
      const s0 = i > run.a ? run.ends[i - run.a - 1] : 0;
      return wk.m - s0 < (i === run.a ? 10 : 3) || !r.steps[i + 1] ? i : i + 1;
    }
    // What the screen is: out (the card and the bar), door (the card with Next), in (the step sheet), end (Arrived).
    function walkPhase() {
      const wk = A.walk, r = A.dir && A.dir.plan; if (!wk || !r || !r.ok) return '';
      if (wk.arrived) return 'end';
      const s = r.steps[walkShown()];
      return !s ? '' : s.kind === 'door' ? 'door' : s.kind === 'outside' || s.kind === 'end' ? 'out' : 'in';
    }
    // The location is coming in (the phone's, or the demo's walk).
    const walkLive = () => !!A.walk && (!!A.walk.sim || A.watch != null);
    const doorFloor = s => { const e = A.P && (A.P.entrances || []).find(x => x.code === s.building && x.at && Math.hypot(x.at[0] - s.at[0], x.at[1] - s.at[1]) < 4); const B = A.L && A.L.building(s.building); return e ? +e.floor : B ? B.entrance : 1; };

    function start() {
      const d = A.dir; if (!d || !d.plan || !d.plan.ok || A.mode !== 'full' || A.walk) return;
      const r = d.plan, head = document.querySelector('.wk-apphead'), tabs = document.querySelector('.wk-tabbar');
      // An iPhone asks for the compass from the tap itself.
      compassAsk();
      // (round 2, §2.6: small, the card made small; overview, the bar raised; low, the step sheet lowered;
      // bar and sheet, their O.sheet.docked; gate, the building the floor picker may show.)
      A.walk = { i: 0, view: -1, follow: true, m: 0, run: null, off: walkOffsets(r), fixAt: Date.now(), offAt: 0, stale: false, rerouting: false, arrived: false, sim: null, heading: null, gen: 0, minute: -2, drawn: null, snap: true, tick: 0, realWatch: false,
        small: false, overview: false, ovFit: false, peek: -1, low: false, bar: null, sheet: null, gate: undefined, rung: '' };
      [head, tabs].forEach(e => { if (e) e.inert = true; });
      document.documentElement.classList.add('pm-walking');
      A.el.classList.add('is-walk');
      A.walkEl = document.createElement('div'); A.walkEl.className = 'pm-walk';
      A.el.appendChild(A.walkEl);
      walkSwipes(A.walkEl);
      place();
      A.walk.tick = setInterval(walkTick, 1000);
      wake(true);
      if (A.watch == null && A.perm !== 'denied' && touch()) locate();
      if (A.nav.me && near(A.nav.me)) walkFix(); else walkPaint();
      // The walk is a layer of its own (§2.7): Back is End. Its entry keeps the planner's address, so a
      // reload never starts a walk.
      syncLayers();
      // (The demo's dock, where there is one, rises above the bar once the tabs have gone.)
      setTimeout(() => { if (window.OGC_DOCK && OGC_DOCK.lift) OGC_DOCK.lift(); }, 240);
    }
    // End: back to the planner (or, silent, just the walk taken away: Done, the planner closed).
    function endWalk(silent) {
      const wk = A.walk; if (!wk) return;
      stopSim(); clearInterval(wk.tick); wake(false); compassOff();
      A.walk = null;
      if (A.walkEl) { A.walkEl.remove(); A.walkEl = null; }
      document.documentElement.classList.remove('pm-walking');
      A.el.classList.remove('is-walk', 'is-recenter'); ['--pm-wtop', '--pm-wbot', '--pm-wdock', '--pm-wride'].forEach(k => A.el.style.removeProperty(k));
      if (A.L) { A.L.walk(null); if (wk.rung) A.L.ring(null); }
      [document.querySelector('.wk-apphead'), document.querySelector('.wk-tabbar')].forEach(e => { if (e) e.inert = false; });
      place();
      // (The demo's walk put the dot where it walked: it goes with the walk, unless the phone's own location
      // has moved it since; the fix pass, round 2.)
      if (wk.simmed && A.watch == null) { A.nav.me = null; A.nav.status = ''; if (A.map) A.map.me(null); }
      if (wk.realWatch && A.watch == null && A.perm !== 'denied') locate();
      setTimeout(() => { if (window.OGC_DOCK && OGC_DOCK.lift) OGC_DOCK.lift(); }, 180);
      if (silent) return;
      const d = A.dir; if (!d) return;
      const r = d.plan, end = r && r.ok ? r.steps[r.steps.length - 1] : null;
      d.focus = -1;
      if (A.L) { if (end && end.building && +end.floor) A.L.focus(end.building, +end.floor); else A.L.focus(null); }
      settle('half'); paint(); showRoute(false, null); fitRoute(r);
      const b = A.el.querySelector('[data-pm="start"]'); if (b) b.focus({ preventScroll: true });
    }
    // A fix while walking: along the stretch outdoors, the step moves on; at the door, the door; an outdoor
    // place, Arrived within 15 m.
    function walkFix() {
      const wk = A.walk, r = A.dir && A.dir.plan, me = A.nav.me;
      if (!wk || !r || !r.ok) return;
      if (!me || !near(me)) { walkPaint(); return; }
      wk.fixAt = Date.now(); wk.stale = false;
      const s = r.steps[wk.i];
      if (!wk.arrived && !wk.rerouting && s) {
        if (s.kind === 'outside') { if (walkAlong(wk, r, me) === 'arrived') return; }
        else if (s.kind === 'end' && !+s.floor && Math.hypot(me.x - s.at[0], me.y - s.at[1]) <= 15) { walkArrive(); return; }
      }
      walkPaint(1);
    }
    function walkAlong(wk, r, me) {
      if (!wk.run || wk.i < wk.run.a || wk.i > wk.run.b) { wk.run = walkRun(r, wk.i); wk.m = wk.run && wk.i > wk.run.a ? wk.run.ends[wk.i - wk.run.a - 1] : 0; }
      const run = wk.run; if (!run || run.pts.length < 2) return '';
      // Off the route (§4.6): more than 25 m from it, with a fix good to 40 m, for 10 s (walkTick reroutes).
      const all = walkProject(run, me.x, me.y, -Infinity, Infinity);
      if (all && all.d > 25 && !(me.acc > 40)) { if (!wk.offAt) wk.offAt = Date.now(); } else wk.offAt = 0;
      // How far along: the nearest point from a little behind to well ahead of where you were, never back.
      const q = walkProject(run, me.x, me.y, wk.m - 25, wk.m + 150) || all;
      if (q && q.d <= 25) wk.m = Math.max(wk.m, q.m);
      // A step moves on within 12 m of its end; the last one outdoors at its door (or the place), 15 m.
      let k = wk.i;
      while (k < run.b && run.ends[k - run.a] - wk.m <= 12) k++;
      // (Only once the last step outdoors is the card's and 15 m or less of the path is left, or 5 m from it:
      // the check, Nov 5, night, saw Arrived 15 m from Hodson's door, as the crow flies, with "Keep right ·
      // 20 ft" and two bends still to walk.)
      const nx = r.steps[run.b + 1], toNx = nx ? Math.hypot(me.x - nx.at[0], me.y - nx.at[1]) : Infinity, left = run.L - wk.m;
      if (nx && ((toNx <= 15 && k >= run.b && left <= 15) || (toNx <= 5 && left <= 40))) {
        if (nx.kind === 'end') { wk.i = run.b + 1; walkArrive(); return 'arrived'; }
        k = run.b + 1;
      }
      if (k > wk.i) {
        wk.i = k;
        // A step looked at by hand that you've now reached (or one behind you) gives way to where you are.
        if (wk.view > -1 && wk.view <= wk.i) { wk.view = -1; wk.follow = true; }
      }
      return '';
    }
    // ‹ › and Back and Next (and a swipe on the card). Outdoors, with the location on, ‹ › only look;
    // at a door, Next goes in; inside, they're where you are; the last Next to a room is Arrived.
    function walkGo(dir) {
      const wk = A.walk, r = A.dir && A.dir.plan; if (!wk || !r || wk.arrived || wk.rerouting) return;
      // (Outdoors ‹ › go on from the step the card says, and back to the live card where they meet it.)
      const ph = walkPhase(), j = (ph === 'out' ? walkCard(true) : walkShown()) + dir, s = r.steps[j];
      if (!s) return;
      const look = walkLive() && ph !== 'in' && !(ph === 'door' && dir > 0) && (s.kind === 'outside' || s.kind === 'door' || (s.kind === 'end' && !+s.floor));
      if (look) { wk.view = j === walkCard(false) ? -1 : j; wk.follow = wk.view === -1; wk.snap = true; walkPaint(dir); return; }
      if (s.kind === 'end' && (+s.floor || !walkLive())) { wk.i = j; wk.view = -1; walkArrive(); return; }
      wk.i = j; wk.view = -1; wk.follow = true; wk.snap = true;
      if (s.kind === 'outside') wk.run = null;
      walkPaint(dir);
    }
    function walkArrive() {
      const wk = A.walk, r = A.dir.plan;
      wk.arrived = true; wk.i = r.steps.length - 1; wk.view = -1; wk.snap = true;
      stopSim();
      walkPaint(1);
      // (The demo's dock rises above the Arrived sheet at once, not a moment after, over its title.)
      if (window.OGC_DOCK && OGC_DOCK.lift) OGC_DOCK.lift();
    }
    function walkMoved() { const wk = A.walk; if (wk && wk.follow && walkPhase() === 'out') { wk.follow = false; walkPaint(); } }
    function walkRecenter() { const wk = A.walk; if (!wk) return; wk.follow = true; wk.view = -1; wk.snap = true; walkPaint(-1); }
    // Arrived's Done (§2.6): the walk and the planner close (two layers); the map with the room open at its
    // peek, the head and the tab bar back (arrived: the room's sheet sits on the tab bar, as the plain map's
    // does, until something else opens).
    // (Focus on the room's heading, K4: Done's button went with the walk and left it on the page's body.)
    function walkFinish() {
      const d = A.dir, to = d && d.to ? d.to.place : null; closeDirs(to ? Object.assign({}, to, { arrived: true }) : undefined);
      if (!A.el || !A.el.contains(document.activeElement)) refocus();
    }
    // The dot while walking: none inside (§4.8); greyed after 30 s without a fix; the compass's wedge while following.
    function walkMe() {
      const wk = A.walk, me = A.nav.me, r = A.dir && A.dir.plan, ph = walkPhase();
      if (!wk || !me || !near(me) || ph === 'in' || (ph === 'end' && r && +r.steps[r.steps.length - 1].floor)) return null;
      return Object.assign({}, me, { stale: wk.stale, heading: wk.follow && ph === 'out' && !wk.stale && wk.heading != null ? wk.heading : null });
    }
    // Metres walked along the route (the route-done part of the line).
    function walkMetres() {
      const wk = A.walk, r = A.dir.plan;
      if (wk.arrived) return r.metres;
      if (r.steps[wk.i] && r.steps[wk.i].kind === 'outside' && wk.run && wk.i >= wk.run.a && wk.i <= wk.run.b) return wk.off[wk.run.a] + wk.m;
      return wk.off[wk.i] || 0;
    }
    // What covers the map: the card at the top and the bar at the foot (outdoors), the sheet (inside).
    // The demo's dock (local and the shared link only), which rests 8 px above the bar or the steps: what
    // the map, Recenter and the credit keep clear of. 0 on the real site.
    // (Its fold tab stands 16 px above it: the credit keeps clear of that too, round 2.)
    const walkDock = () => {
      const dk = document.querySelector('.ogc-pill'), h = dk && !dk.hidden && !dk.classList.contains('is-min') ? dk.offsetHeight : 0;
      if (!h) return 0;
      const tab = dk.querySelector('.ogc-pill__min'), tr = tab ? tab.getBoundingClientRect() : null, top = dk.getBoundingClientRect().top;
      // (Over the bar it rests above the bar's grabber too, whose target stands 22 px over the map.)
      return h + 8 + (A.walk && A.walk.bar ? 22 : 0) + (tr && tr.height && tr.top < top ? Math.round(top - tr.top) : 0);
    };
    function walkInset() {
      const el = A.walkEl, ph = A.walk ? walkPhase() : '';
      const card = el && el.querySelector('.pm-wcard'), fixed = el && el.querySelector('.pm-wsheet--done'), sh = A.walk && (A.walk.bar || A.walk.sheet);
      // (The bar and the step sheet are sheets: what shows of them at their stop, not their box.)
      const foot = sh ? { offsetHeight: Math.round(sh.heights()[sh.stop] || sh.h || 0) } : fixed;
      // (The floor picker's column on the right, as the planner keeps it: names and plates keep off it too;
      // at the foot, the credit's line, which sits just above the bar or the steps.)
      // under: just under the card, where the picker and the demo's pill sit; the demo's pill, when it
      // shows, is in the way too (a destination's name would go under it).
      const cr = A.mapEl && (A.mapEl.querySelector('.pv-foot') || A.mapEl.querySelector('.pv-credit')), ch = cr ? cr.offsetHeight : 0;
      const under = card ? card.offsetTop + card.offsetHeight + 8 : 12, mk = el && el.querySelector('[data-wmock]:not([hidden])');
      return { top: mk && mk.offsetHeight ? under + 4 + mk.offsetHeight + 8 : under, under, bottom: foot ? foot.offsetHeight + walkDock() + ch + 8 : 0, left: 0, right: A.plans && ph ? 72 : 0, foot: foot ? foot.offsetHeight : 0 };
    }
    // The screen while walking, by phase (§2.6, round 2). Outdoors and at a door: the step card at the top
    // (made small, a 52 px strip: the turn's icon and the distance) and the bar at the foot, a sheet of its
    // own: raised, the whole route above it and the steps under it; at the door, Go in in the bar. Inside:
    // the step sheet, lowered to a 120 px bar (the sentence, Back and Next). Arrived: §4.10's sheet.
    const walkGroup = ph => ph === 'door' ? 'out' : ph;
    function walkHtml(ph, r) {
      const mock = W().dev || W().prototype ? '<p class="pm-wmock" data-wmock hidden><button type="button" class="ogc-mock" data-pm="w-mock" aria-pressed="false" title="Moves the dot along the route at three times walking speed · Demo only">Mockup: walk it</button></p>' : '';
      const grab = '<button type="button" class="ogc-sheet__grab" aria-label="More" title="More"></button>';
      if (ph === 'out' || ph === 'door') {
        return '<div class="pm-wcard" data-wswipe><div class="pm-wcard__s" data-wtext tabindex="-1"></div>' +
          '<div class="pm-wcard__nav"><button type="button" class="pm-wnav" data-pm="w-prev" aria-label="Previous step" title="Previous step">' + I.prev + '</button><button type="button" class="pm-wnav" data-pm="w-next" aria-label="Next step" title="Next step">' + I.next + '</button></div>' +
          '<button type="button" class="pm-wcard__grab" data-pm="w-small" aria-label="Smaller" title="Smaller"></button>' +
          '<button type="button" class="pm-wcard__mini" data-pm="w-open" hidden><span class="pm-wico" data-wmini-i aria-hidden="true"></span><span class="pm-wcard__md" data-wmini-d></span></button></div>' +
          '<button type="button" class="pm-recenter" data-pm="w-recenter" hidden>' + I.locate + '<span>Recenter</span></button>' + mock +
          '<section class="pm-wbar" aria-label="Route">' + grab + '<div class="ogc-sheet__body"><div class="pm-wbar__row" data-wrow><div class="pm-wbar__m"><p class="pm-wbar__t" data-warr></p><p class="pm-wbar__l" data-wrem></p></div>' +
          '<button type="button" class="pm-btn pm-btn--line" data-pm="w-end">End</button><button type="button" class="pm-btn pm-wbar__go" data-pm="w-in" hidden>Go in</button></div>' +
          '<div class="pm-wbar__list"><h3 class="ogc-sr">Steps</h3>' + stepsList(r).replace(/data-pm="step"/g, 'data-pm="w-step"').replace(/ is-on"/g, '"') + '</div></div></section>';
      }
      if (ph === 'in') {
        return '<section class="pm-wsheet pm-wsheet--step" data-wswipe aria-label="Steps">' + grab + '<div class="ogc-sheet__body"><div class="pm-wsheet__h"><p class="pm-k" data-wlab></p><button type="button" class="pm-wsheet__end" data-pm="w-end">End</button></div>' +
          '<div class="pm-wsheet__s" data-wtext tabindex="-1"></div>' +
          '<p class="pm-wsheet__b"><button type="button" class="pm-btn pm-btn--line" data-pm="w-back">' + I.prev + 'Back</button><button type="button" class="pm-btn" data-pm="w-fwd">Next</button></p></div></section>';
      }
      return '<section class="pm-wsheet pm-wsheet--done" aria-label="Arrived"><div class="pm-wsheet__s" data-wtext tabindex="-1"></div><p class="pm-wsheet__b"><button type="button" class="pm-btn" data-pm="w-done">Done</button></p></section>';
    }
    // The bar as a sheet (§2.6): its peek the row (64 and the safe area); raised, the row and the steps,
    // up to 55% of the screen (they scroll there). Raised is the overview: the whole route fitted above it;
    // lowered, following again. (No other way out of it: no below.)
    function walkBar(el) {
      const sec = el.querySelector('.pm-wbar'); if (!sec) return null;
      const row = sec.querySelector('[data-wrow]'), list = sec.querySelector('.pm-wbar__list');
      const sh = O.sheet.docked(sec, {
        stops: () => {
          const C = canvasH(), safe = Math.max(0, sec.offsetHeight ? parseFloat(getComputedStyle(sec).paddingBottom) || 0 : 0);
          const peek = Math.round(row.offsetTop + row.offsetHeight + 6 + safe);
          const half = Math.round(Math.min(C * 0.55, list.offsetTop + list.scrollHeight + 16 + safe));
          return { peek, half, full: half };
        },
        floor: () => 0,
        moved: (h, ms) => walkRide(h, ms),
        settled: stop => walkOverview(stop !== 'peek')
      });
      return sh;
    }
    // The step sheet (inside) as a sheet: open (its content) and lowered to a 120 px bar, the sentence and
    // Back and Next (§2.6): lowered, the label and End and the detail fade, the sentence moves up under the
    // grabber and Back and Next stay at the foot.
    function walkStepSheet(el) {
      const sec = el.querySelector('.pm-wsheet--step'); if (!sec) return null;
      const sh = O.sheet.docked(sec, {
        stops: () => { const m = walkLow(sec); return { peek: m.lo, half: m.hi, full: m.hi }; },
        floor: () => 0,
        moved: (h, ms) => { walkLowAt(sec, h, ms); walkRide(h, ms); },
        // (Lowered or raised, the step is framed again in what shows of the map.)
        settled: stop => { const wk = A.walk; if (!wk) return; const low = stop === 'peek'; if (low !== wk.low) wk.snap = true; wk.low = low; walkPaint(); }
      });
      return sh;
    }
    // The step sheet's two heights: hi, as laid out; lo, the grabber's 20, the sentence, 12, Back and Next and
    // the foot's padding (120 for a one-line step).
    // (Tops from the sheet's own top, as laid out: offsetTop up the chain, which no transform moves.)
    const offIn = (e, anc) => { let y = 0; for (let x = e; x && x !== anc; x = x.offsetParent) y += x.offsetTop; return y; };
    function walkLow(sec) {
      // (The text in [data-wtext]: never the old step's copy walkSwap is fading out beside it.)
      const body = sec.querySelector('.ogc-sheet__body'), s = sec.querySelector('[data-wtext] .pm-wsheet__t'), b = sec.querySelector('.pm-wsheet__b');
      const pad = parseFloat(getComputedStyle(body).paddingBottom) || 0;
      // (The sentence's own lines, not the two it keeps room for when open.)
      let sH = 25; if (s) { const rg = document.createRange(); rg.selectNodeContents(s); sH = Math.ceil(rg.getBoundingClientRect().height) || s.offsetHeight; }
      const hi = Math.ceil(offIn(b, sec) + b.offsetHeight + pad);
      const lo = Math.min(hi, Math.max(120, Math.ceil(20 + sH + 12 + b.offsetHeight + pad)));
      return { hi, lo, sT: s ? offIn(s, sec) : 0, sH };
    }
    function walkLowAt(sec, h, ms) {
      const m = walkLow(sec), p = m.hi > m.lo ? Math.max(0, Math.min(1, (h - m.lo) / (m.hi - m.lo))) : 1;
      const tr = ms ? 'transform ' + ms + 'ms cubic-bezier(.2,.8,.2,1), opacity ' + ms + 'ms cubic-bezier(.2,.8,.2,1)' : 'none';
      const put = (e, y, o) => { if (!e) return; e.style.transition = tr; e.style.transform = y ? 'translate3d(0,' + Math.round(y) + 'px,0)' : ''; if (o != null) { e.style.opacity = String(o); e.style.pointerEvents = o < .5 ? 'none' : ''; } };
      // (Back and Next at the screen's foot however far down it is; the sentence from where it is to just
      // under the grabber.)
      const b = sec.querySelector('.pm-wsheet__b'), tx = sec.querySelector('[data-wtext]');
      put(b, -(m.hi - Math.max(m.lo, Math.min(m.hi, h))));
      put(tx && tx.querySelector('.pm-wsheet__t'), -(m.sT - 20) * (1 - p));
      put(sec.querySelector('.pm-wsheet__h'), 0, p);
      put(tx && tx.querySelector('.pm-wsheet__d'), -(m.sT - 20) * (1 - p), p);
      put(tx && tx.querySelector('.pm-wico--big'), 0, p);
      sec.classList.toggle('is-low', p < .5);
    }
    // What rides on the bar or the sheet as it moves (the credit, Recenter): their foot.
    function walkRide(h, ms) {
      if (!A.el) return;
      A.el.style.setProperty('--pm-wbot', Math.round(h) + 'px');
      A.el.style.setProperty('--pm-wride', (ms || 0) + 'ms');
    }
    // The bar raised (the overview) or lowered (following again).
    function walkOverview(on) {
      const wk = A.walk; if (!wk) return;
      if (on === wk.overview) { walkPaint(); return; }
      wk.overview = on; wk.peek = -1; walkPeekMark(-1);
      if (on) { wk.follow = false; wk.ovFit = true; }
      else { wk.follow = true; wk.view = -1; wk.snap = true; }
      walkPaint();
    }
    // A step tapped in the raised bar's list: framed on the map (its floor open, the ring at its start),
    // nothing else changed; lowering the bar follows you again.
    function walkPeekStep(j) {
      const wk = A.walk, r = A.dir && A.dir.plan, s = r && r.steps[j]; if (!wk || !s || !wk.overview) return;
      wk.peek = j;
      if (A.L) { if (s.building && (+s.floor || s.kind === 'door')) A.L.focus(s.building, s.kind === 'door' ? doorFloor(s) : +s.floor); }
      walkPaint();
      walkFrame(s.pts.length > 1 ? s.box : [s.at[0] - 12, s.at[1] - 12, s.at[0] + 12, s.at[1] + 12], 32, s.kind === 'outside' ? 60 : 24);
      walkPeekMark(j);
    }
    const walkPeekMark = j => { if (A.walkEl) A.walkEl.querySelectorAll('.pm-wbar .pm-step').forEach(e => e.classList.toggle('is-peek', +e.dataset.i === j)); };
    // The card made small (a swipe up, or its grabber) or opened again (a tap, or a swipe down): 200 ms,
    // none under reduced motion.
    function walkFold(small) {
      const wk = A.walk, c = A.walkEl && A.walkEl.querySelector('.pm-wcard'); if (!wk || !c || wk.small === small) return;
      const inCard = c.contains(document.activeElement), h0 = c.offsetHeight;
      wk.small = small; walkFoldApply(c);
      const h1 = c.offsetHeight;
      if (!still() && h0 && h1 && h0 !== h1 && c.animate) { c.style.overflow = 'hidden'; c.animate([{ height: h0 + 'px' }, { height: h1 + 'px' }], { duration: 200, easing: 'cubic-bezier(.2,.8,.2,1)' }).onfinish = () => { c.style.overflow = ''; }; }
      walkPaint();
      if (inCard) { const f = c.querySelector(small ? '[data-pm="w-open"]' : '[data-pm="w-small"]'); if (f) f.focus({ preventScroll: true }); }
    }
    function walkFoldApply(c) {
      const wk = A.walk; if (!wk || !c) return;
      c.classList.toggle('is-small', !!wk.small);
      const mini = c.querySelector('[data-pm="w-open"]'); if (mini) mini.hidden = !wk.small;
    }
    function walkText(ph, s) {
      const wk = A.walk, ico = big => '<span class="pm-wico' + (big ? ' pm-wico--big' : '') + '" aria-hidden="true">' + (I['r-' + s.icon] || I['r-straight']) + '</span>';
      if (ph === 'end') {
        const d = A.dir, sub = d && d.to && d.to.label && d.to.label !== s.sign ? d.to.label : '';
        return '<p class="pm-arr"><span class="pm-arr__c" aria-hidden="true">' + I.check + '</span><span class="pm-k">Arrived</span></p><h2 class="pm-arr__t">' + esc(s.text) + '</h2>' + (sub ? '<p class="pm-arr__s">' + esc(sub) + '</p>' : '');
      }
      if (ph === 'in') return (s.kind === 'floor' ? ico(true) : '') + '<p class="pm-wsheet__t">' + nb(s.text) + '</p><p class="pm-wsheet__d">' + nb([s.detail, s.distance].filter(Boolean).join(' · ')) + '</p>';
      if (wk.rerouting) return '<span class="pm-wico" aria-hidden="true"></span><p class="pm-wcard__m"><span class="pm-wcard__t">Rerouting</span><span class="pm-wcard__d" data-wline></span></p>';
      // (A door has no distance of its own: no empty line under its words, §2.6. The bar says what's left.)
      return ico(false) + '<p class="pm-wcard__m"><span class="pm-wcard__t">' + nb(s.text) + '</span>' + (s.kind === 'door' ? '' : '<span class="pm-wcard__d" data-wline></span>') + '</p>';
    }
    // The card's second line: the state, else how far. As you walk: the first stretch, what's left of it;
    // a turn ahead, the feet until it (none once you're at it). Looked at by hand: the step's own length.
    function walkLine(s, si) {
      const wk = A.walk, me = A.nav.me, run = wk.run;
      if (wk.rerouting) return '';
      if (wk.stale) return 'Location unavailable';
      if (walkLive() && me && near(me) && me.acc > 40) return 'Approximate location';
      // (The demo's walk paused keeps the feet to the turn from where its dot stopped, not the step's length.)
      if (wk.view === -1 && (walkLive() || wk.simmed) && me && near(me) && run && wk.i >= run.a && wk.i <= run.b && si >= run.a && si <= run.b + 1) {
        if (si === run.a) return M.feet(Math.max(0, run.ends[0] - wk.m));
        const d = run.ends[si - run.a - 1] - wk.m;
        return d >= 3 ? M.feet(d) : '';
      }
      return s.distance || '';
    }
    // The text of a step changing: the old leaves 12 px and the new comes in from 12 px (200 ms; §8).
    function walkSwap(box, html, dir) {
      if (!dir || still() || !box.animate || !box.firstChild) { box.innerHTML = html; return; }
      const old = box.cloneNode(true);
      old.removeAttribute('data-wtext'); old.removeAttribute('tabindex'); old.setAttribute('aria-hidden', 'true');
      old.style.cssText = 'position:absolute;margin:0;left:' + box.offsetLeft + 'px;top:' + box.offsetTop + 'px;width:' + box.offsetWidth + 'px;pointer-events:none';
      box.parentNode.insertBefore(old, box);
      box.innerHTML = html;
      const e = 'cubic-bezier(.2,.8,.2,1)';
      old.animate([{ opacity: 1, transform: 'none' }, { opacity: 0, transform: 'translateX(' + (-12 * dir) + 'px)' }], { duration: 200, easing: e, fill: 'forwards' }).onfinish = () => old.remove();
      box.animate([{ opacity: 0, transform: 'translateX(' + (12 * dir) + 'px)' }, { opacity: 1, transform: 'none' }], { duration: 200, easing: e });
    }
    const walkFrame = (b, pad, min) => { if (!b || !A.map) return; const w = Math.max(min || 30, b[2] - b[0]), h = Math.max(min || 30, b[3] - b[1]), cx = (b[0] + b[2]) / 2, cy = (b[1] + b[3]) / 2; A.map.fit({ x: cx - w / 2, y: cy - h / 2, w, h }, pad, true); };
    // The building the route goes into next, from step i on: its door step (Go in at …), or a step inside
    // or the end in a building with no door step before it; null when it stays outdoors.
    function walkNextDoor(r, i) {
      for (let k = Math.max(0, i); k < r.steps.length; k++) {
        const s = r.steps[k];
        if (s.kind !== 'outside') return s.building ? s : null;
      }
      return null;
    }
    // Within 60 m of it (§2.6): you, or with no fix the step the card says.
    const walkNear = (nx, s, me) => { const p = me ? [me.x, me.y] : s && s.at; return !!(p && nx && nx.at && Math.hypot(p[0] - nx.at[0], p[1] - nx.at[1]) <= 60); };
    // The point the camera follows (§2.6): ahead of you on the route by a quarter of the clear height, or the
    // next turn (or the door) when that's nearer; you, off the line, moved by the same.
    function walkAhead(me, sc, ins) {
      const wk = A.walk, run = wk.run;
      if (!run || run.pts.length < 2 || wk.i < run.a || wk.i > run.b) return [me.x, me.y];
      const clear = Math.max(80, canvasH() - ins.top - ins.bottom);
      let ahead = clear / 4 / Math.max(.1, sc);
      for (let k = 0; k < run.ends.length; k++) if (run.ends[k] > wk.m + 1) { ahead = Math.min(ahead, run.ends[k] - wk.m); break; }
      ahead = Math.max(0, Math.min(ahead, run.L - wk.m));
      const on = walkAt(run, wk.m), p = walkAt(run, wk.m + ahead);
      return [me.x + p[0] - on[0], me.y + p[1] - on[1]];
    }
    // Everything on the screen while walking, from A.walk: drawn again where it changed.
    function walkPaint(dir) {
      const wk = A.walk, d = A.dir, r = d && d.plan, el = A.walkEl;
      if (!wk || !r || !r.ok || !el || !A.map) return;
      const ph = walkPhase(), si = walkShown(), s = r.steps[si], n = r.steps.length, was = wk.drawn || {};
      // (Outdoors the card says the turn ahead: ci, cs.)
      const ci = ph === 'out' ? walkCard(true) : si, cs = r.steps[ci] || s;
      const grp = walkGroup(ph), newDom = was.g !== grp || was.plan !== r;
      const newPhase = newDom || was.ph !== ph, newStep = newPhase || was.si !== si || was.ci !== ci || was.rr !== wk.rerouting;
      const kept = el.contains(document.activeElement) ? document.activeElement.dataset.pm || 'text' : (newPhase && !was.ph ? 'text' : '');
      if (newDom) {
        el.innerHTML = walkHtml(ph, r);
        // (The bar and the step sheet are sheets: made once for their DOM, at the stop they were left at.)
        wk.bar = grp === 'out' ? walkBar(el) : null;
        wk.sheet = grp === 'in' ? walkStepSheet(el) : null;
        if (grp !== 'out') wk.overview = false;
        walkFoldApply(el.querySelector('.pm-wcard'));
      }
      const box = el.querySelector('[data-wtext]');
      if (newStep && box) walkSwap(box, walkText(ph, ph === 'out' ? cs : s), newPhase ? 0 : dir || 1);
      // (the line in the card now, never the old one walkSwap is fading out: it comes first in the card, so a
      // new turn's distance stayed blank until the next fix; Nov 5, evening, with the longer stretches)
      const line = box && box.querySelector('[data-wline]'), lineT = walkLine(cs, ci); if (line) line.textContent = lineT;
      // The card made small: the turn's icon and the distance (or, with none, the step's own words).
      const mI = el.querySelector('[data-wmini-i]'), mD = el.querySelector('[data-wmini-d]'), mini = el.querySelector('[data-pm="w-open"]');
      if (mini && (grp === 'out')) {
        const ic = I['r-' + (wk.rerouting ? '' : cs.icon)] || I['r-straight'], t = wk.rerouting ? 'Rerouting' : lineT || cs.distance || cs.text;
        if (newStep || mI.innerHTML === '') mI.innerHTML = ic;
        mD.textContent = t;
        mini.setAttribute('aria-label', (wk.rerouting ? 'Rerouting' : cs.text + (lineT ? ' · ' + lineT : '')) + ' · Show step');
      }
      const lab = el.querySelector('[data-wlab]'); if (lab) lab.textContent = (si + 1) + ' of ' + n + ' · ' + M.floorName(s.floor);
      el.querySelectorAll('[data-pm="w-prev"], [data-pm="w-back"]').forEach(b => { b.disabled = ci <= 0 || !!wk.rerouting; });
      el.querySelectorAll('[data-pm="w-next"]').forEach(b => { b.disabled = ci >= n - 1 || !!wk.rerouting; });
      // The bar: when you'll arrive, and what's left (§4.6), from the plan's own time for its length. At the
      // door the clock goes and Go in takes its room, under the thumb (§2.6).
      const done = walkMetres(), rem = Math.max(0, r.metres - done), left = r.metres ? r.sec * rem / r.metres : 0, min = Math.max(1, Math.round(left / 60)), now = venueNow();
      const arr = el.querySelector('[data-warr]'), rest = el.querySelector('[data-wrem]'), goIn = el.querySelector('[data-pm="w-in"]');
      // (A previewed day, ?as-of, has a clock that stands still: the time walked moves it on, so Arrive
      // doesn't run backwards as the demo walks. The real clock moves by itself.)
      const held = /[?&]as-of=/.test(location.search) ? Math.max(0, r.sec - left) / 60 : 0;
      if (arr) { arr.textContent = now.minutes != null ? arriveAt(now.minutes + held, left) : min + ' min'; arr.hidden = ph === 'door'; }
      if (rest) rest.textContent = (now.minutes != null ? min + ' min · ' : '') + M.feet(rem);
      if (goIn) goIn.hidden = ph !== 'door';
      // (quiet: no settled, which would draw all this again from inside itself)
      if (newPhase && wk.bar) wk.bar.set(wk.overview ? 'half' : 'peek', newDom ? 'jump' : 'ease', true);
      // The steps under the bar: the one the card says marked.
      if (wk.bar && newStep) el.querySelectorAll('.pm-wbar .pm-step').forEach(e => { const on = +e.dataset.i === ci; e.classList.toggle('is-on', on); if (on) e.setAttribute('aria-current', 'step'); else e.removeAttribute('aria-current'); });
      if (wk.sheet && newStep) wk.sheet.set(wk.low ? 'peek' : 'half', 'jump', true);
      const me = A.nav.me, fix = !!(me && near(me));
      const rc = el.querySelector('.pm-recenter'); if (rc) rc.hidden = !(ph === 'out' && !wk.follow && fix && !wk.overview);
      A.el.classList.toggle('is-recenter', !!rc && !rc.hidden);
      const mk = el.querySelector('[data-wmock]');
      if (mk) { mk.hidden = !(ph === 'out' && r.steps[wk.i] && r.steps[wk.i].kind === 'outside'); mk.querySelector('button').setAttribute('aria-pressed', String(!!wk.sim)); }
      // (Recenter and the credit keep clear of the demo's dock where it has risen above the bar.)
      A.el.style.setProperty('--pm-wdock', walkDock() + 'px');
      wk.drawn = { ph, g: grp, si, ci, rr: wk.rerouting, plan: r };
      // What the map keeps clear of, and where the floor picker sits (under the card outdoors).
      const ins = walkInset();
      A.el.style.setProperty('--pm-wtop', (ph === 'out' || ph === 'door' ? ins.under : 12) + 'px');
      if (!(wk.bar || wk.sheet) || !(wk.bar || wk.sheet).busy()) A.el.style.setProperty('--pm-wbot', ins.foot + 'px');
      A.map.inset(ins);
      // The building open: the destination's outdoors; the step's floor inside; the door's floor at a door.
      // (Off the campus, walking in from the town, no floor picker: the building opens on the campus.)
      const offc = ph === 'out' && fix && !M.onCampus(A.c, me, 30), offTurn = wk.offc !== offc; wk.offc = offc;
      if ((newStep || offTurn) && A.L) {
        const end = r.steps[n - 1], nx = walkNextDoor(r, ph === 'out' ? ci : si);
        if (ph === 'in') A.L.focus(s.building, +s.floor);
        else if (ph === 'door') A.L.focus(s.building, doorFloor(s));
        // (Outdoors, the building you go into next once you're near it; else the destination's.)
        else if (nx && !offc && walkNear(nx, ph === 'out' ? cs : s, fix ? me : null)) A.L.focus(nx.building, nx.kind === 'door' ? doorFloor(nx) : +nx.floor);
        else if (end.building && +end.floor && !offc) A.L.focus(end.building, +end.floor);
        else A.L.focus(null);
      }
      // The floor picker while walking (§2.6): only for the building the route goes into next, once you're
      // within 60 m of it; inside and at its door, that building; Arrived, the room's.
      if (A.L) {
        const nx = walkNextDoor(r, ph === 'out' ? ci : si);
        const pk = wk.overview && wk.peek > -1 ? r.steps[wk.peek] : null;
        const g = pk && pk.building ? pk.building : offc ? '' : ph === 'in' || ph === 'door' ? s.building || '' : ph === 'end' ? r.steps[n - 1].building || '' : nx && walkNear(nx, cs, fix ? me : null) ? nx.building || '' : '';
        if (g !== wk.gate) { wk.gate = g; A.L.walk({ full: g }); }
      }
      // A floor change frames its stairs or elevator and rings it (§2.6); a step looked at by hand outdoors
      // has the tan-ink ring at its turn.
      const shaft = ph === 'in' && s.kind === 'floor' && A.L ? A.L.shaft(s.building, +s.floor, s.at) : null;
      const rung = shaft ? s.building + '|' + s.floor + '|' + s.at.join(',') : '';
      if (A.L && rung !== wk.rung) { wk.rung = rung; if (shaft) A.L.ring(s.building, +s.floor, [shaft.x + shaft.w / 2, shaft.y + shaft.h / 2]); else A.L.ring(null); }
      A.map.route({ parts: r.parts, floorOf: code => A.L ? A.L.shown(code) : null, start: r.steps[0] ? r.steps[0].at : null,
        stretch: ph === 'in' && s.pts.length > 1 ? { id: 'w' + si, pts: s.pts, floor: s.floor, building: s.building } : null,
        done, ring: ph === 'in' && !shaft ? s.at : grp !== 'out' ? null : wk.overview && wk.peek > -1 && r.steps[wk.peek] ? r.steps[wk.peek].at : wk.view > -1 ? s.at : null, animate: false,
        // (Raised, the whole route small: the planner's rule for names, those the steps name and those the
        // line passes; the check saw Carmin and Kem named and not Barnes, where it ends. Following, as before.)
        keep: wk.overview ? (wk.keep || (wk.keep = stepNames(r))) : undefined });
      A.map.me(walkMe());
      // The camera (north up): outdoors it follows a point ahead of you on the route, eased to each fix;
      // raised, the bar has the whole route above it; else framed on the step.
      const asked = wk.snap, snap = asked || newStep; wk.snap = false;
      // (Panned by the person: following stopped, no step looked at, a fix. Only Recenter, ‹ ›, or the bar
      // lowered bring the camera back; a new step as you walk doesn't. The check saw the map jump back to the
      // next step on its own after a pan; the fix pass, round 2.)
      const panned = !wk.follow && wk.view === -1 && fix;
      if (wk.overview && (ph === 'out' || ph === 'door')) { if (wk.ovFit) { wk.ovFit = false; fitRoute(r); } }
      else if (ph === 'out') {
        if (wk.follow && fix && wk.view === -1) { const sc = snap ? WALK_S : curScale(), at = walkAhead(me, sc, ins); A.map.look(at[0], at[1], sc, true); }
        // (No fix, or looking at a step by hand: the step with the ground round it, never less than about
        // 110 m across, so where it goes is in view; round 2 part 2: "Toward Barnes" filled the phone.)
        else if (snap && !(panned && !asked)) walkFrame(s.kind === 'end' ? [s.at[0] - 15, s.at[1] - 15, s.at[0] + 15, s.at[1] + 15] : s.box, 48, s.kind === 'end' ? 30 : 110);
      } else if (snap && ph === 'door') {
        const B = A.L && A.L.building(s.building), bb = B && B.box;
        const fb = bb ? [Math.min(bb.x, s.at[0]), Math.min(bb.y, s.at[1]), Math.max(bb.x + bb.w, s.at[0]), Math.max(bb.y + bb.h, s.at[1])] : [s.at[0] - 20, s.at[1] - 20, s.at[0] + 20, s.at[1] + 20];
        // (You, near the door, in the frame too: round 2 part 2, the dot sat under the floor picker.)
        if (fix && Math.hypot(me.x - s.at[0], me.y - s.at[1]) < 80) { fb[0] = Math.min(fb[0], me.x - 8); fb[1] = Math.min(fb[1], me.y - 8); fb[2] = Math.max(fb[2], me.x + 8); fb[3] = Math.max(fb[3], me.y + 8); }
        walkFrame(fb, 24);
      } else if (snap && ph === 'in' && shaft) walkFrame([shaft.x - 4, shaft.y - 4, shaft.x + shaft.w + 4, shaft.y + shaft.h + 4], 40, 18);
      else if (snap && ph === 'in') walkFrame(s.pts.length > 1 ? s.box : [s.at[0] - 8, s.at[1] - 8, s.at[0] + 8, s.at[1] + 8], 48);
      else if (snap && ph === 'end') walkFrame([s.at[0] - 12, s.at[1] - 12, s.at[0] + 12, s.at[1] + 12], 48);
      if (newStep) A.map.live(wk.rerouting ? 'Rerouting' : ph === 'end' ? 'Arrived · ' + s.text : 'Step ' + (ci + 1) + ' of ' + n + ' · ' + cs.text);
      // Keyboard focus stays on the walk: the same button, else the step's text.
      if (kept && newPhase) { const b = kept !== 'text' && el.querySelector('[data-pm="' + CSS.escape(kept) + '"]:not([disabled])'); (b || el.querySelector('[data-wtext]') || el).focus({ preventScroll: true }); }
    }
    // Once a second: 30 s without a fix greys the dot; 10 s off the route reroutes; the clock moves on.
    function walkTick() {
      const wk = A.walk, r = A.dir && A.dir.plan; if (!wk || !r) return;
      const stale = A.watch != null && Date.now() - wk.fixAt > 30000;
      let ch = stale !== wk.stale; wk.stale = stale;
      if (wk.offAt && Date.now() - wk.offAt >= 10000 && !wk.rerouting && !stale && r.steps[wk.i] && r.steps[wk.i].kind === 'outside') { walkReroute(); return; }
      const now = venueNow(), mm = now.minutes == null ? -1 : Math.floor(now.minutes);
      if (mm !== wk.minute) { wk.minute = mm; ch = true; }
      if (ch) walkPaint();
    }
    // Off the route: "Rerouting", then the route from here, with no motion (the campus's graph is on the phone).
    function walkReroute() {
      const wk = A.walk, d = A.dir, me = A.nav.me; if (!wk || !d || !me || me.lat == null) return;
      wk.rerouting = true; wk.offAt = 0;
      const gen = ++wk.gen;
      walkPaint();
      routerNow().then(R => {
        if (A.walk !== wk || wk.gen !== gen) return;
        const from = endHere(), r = planWith(Object.assign({}, d, { from }), R);
        setTimeout(() => {
          if (A.walk !== wk || wk.gen !== gen) return;
          wk.rerouting = false;
          if (r.ok) {
            d.from = from; d.auto = false; d.at = [me.x, me.y]; d.plan = r;
            if (A.L) A.L.route(r);
            A.map.reach(routeBox(r));
            Object.assign(wk, { i: 0, view: -1, m: 0, run: null, off: walkOffsets(r), follow: true, snap: true, keep: null });
          }
          walkPaint(1);
        }, 700);
      });
    }
    // The demo's walk (Mockup: walk it; the local site and the shared link only): the dot along the
    // stretch outdoors at three times walking pace (1 m/s), a fix every 400 ms, to its door or its end.
    function walkSim(on) {
      const wk = A.walk, r = A.dir && A.dir.plan; if (!wk || !r) return;
      // (Turned off: the phone's own location again at once, where it was on before, not only at End.)
      if (!on) { stopSim(); if (wk.realWatch && A.watch == null && A.perm !== 'denied') { wk.realWatch = false; locate(); } walkPaint(); return; }
      if (wk.sim) return;
      wk.simmed = true;
      if (!wk.run || wk.i < wk.run.a || wk.i > wk.run.b) { wk.run = walkRun(r, wk.i); wk.m = wk.run && wk.i > wk.run.a ? wk.run.ends[wk.i - wk.run.a - 1] : 0; }
      const run = wk.run; if (!run || run.pts.length < 2) return;
      if (A.watch != null) { stopWatch(); wk.realWatch = true; }
      let m = Math.max(wk.m, wk.i > run.a ? run.ends[wk.i - run.a - 1] : 0);
      const tick = () => {
        if (A.walk !== wk) return;
        m = Math.min(run.L, m + 1.2);
        const p = walkAt(run, m), ll = M.toLatLng(A.c, p[0], p[1]);
        A.nav.me = { x: p[0], y: p[1], acc: 5, lat: ll.lat, lng: ll.lng }; A.nav.status = '';
        if (m >= run.L) stopSim();
        walkFix();
        if (A.walk && (A.walk.arrived || A.walk.i > run.b)) stopSim();
      };
      wk.sim = setInterval(tick, 400);
      wk.follow = true; wk.view = -1; wk.snap = true;
      tick();
    }
    function stopSim() { const wk = A.walk; if (wk && wk.sim) { clearInterval(wk.sim); wk.sim = null; } }
    // The page hidden: the location stops (as ever), and the demo's walk with it; back, both go on.
    function walkHidden(h) {
      const wk = A.walk; if (!wk) return;
      if (h) { if (wk.sim) { stopSim(); wk.paused = true; } return; }
      wake(true);
      if (wk.paused) { wk.paused = false; walkSim(true); }
    }
    // Next and Back as a swipe left or right on the card or the step sheet (§4.8); on the card, a swipe up
    // makes it small and a swipe down opens it again (§2.6).
    function walkSwipes(el) {
      let g = null;
      el.addEventListener('pointerdown', e => { const t = e.pointerType !== 'mouse' && e.target.closest('[data-wswipe]'); g = t ? { x: e.clientX, y: e.clientY, card: t.classList.contains('pm-wcard') } : null; });
      el.addEventListener('pointerup', e => {
        if (!g) return;
        const G = g, dx = e.clientX - G.x, dy = e.clientY - G.y; g = null;
        if (G.card && Math.abs(dy) >= 32 && Math.abs(dy) > Math.abs(dx) * 1.5) { A.swiped = Date.now(); walkFold(dy < 0); return; }
        if (Math.abs(dx) < 48 || Math.abs(dx) < Math.abs(dy) * 2) return;
        A.swiped = Date.now();
        walkGo(dx < 0 ? 1 : -1);
      });
      el.addEventListener('pointercancel', () => { g = null; });
    }
    // The screen stays awake while walking (Wake Lock, where the phone allows it).
    function wake(on) {
      if (!on) { if (A.lock) { try { A.lock.release(); } catch (e) { /* gone */ } A.lock = null; } return; }
      if (!A.walk || A.lock || !navigator.wakeLock || document.visibilityState !== 'visible') return;
      navigator.wakeLock.request('screen').then(l => { if (!A.walk) { l.release(); return; } A.lock = l; l.addEventListener('release', () => { if (A.lock === l) A.lock = null; }); }).catch(() => { /* not allowed: fine */ });
    }
    // The compass (§4.6): an iPhone asks once, from Start's tap; refused, there's no wedge and nothing else
    // changes. Elsewhere it's there or it isn't.
    const COMPASS = 'ogc-map-compass';
    let compassFn = null;
    function compassAsk() {
      const D = window.DeviceOrientationEvent;
      if (!D || !touch()) return;
      if (typeof D.requestPermission === 'function') {
        if (LS.get(COMPASS, '') === 'denied') return;
        D.requestPermission().then(s => { LS.set(COMPASS, s); if (s === 'granted') compassOn(); }).catch(() => LS.set(COMPASS, 'denied'));
        return;
      }
      compassOn();
    }
    function compassOn() {
      if (compassFn) return;
      const abs = 'ondeviceorientationabsolute' in window, type = abs ? 'deviceorientationabsolute' : 'deviceorientation';
      let last = 0;
      compassFn = e => {
        const wk = A.walk; if (!wk) return;
        let h = e.webkitCompassHeading != null ? e.webkitCompassHeading : (abs || e.absolute) && e.alpha != null ? 360 - e.alpha : null;
        if (h == null || !isFinite(h)) return;
        const turn = screen.orientation && screen.orientation.angle != null ? screen.orientation.angle : +(window.orientation || 0);
        h = ((h + turn) % 360 + 360) % 360;
        const first = wk.heading == null, t = performance.now();
        if (!first && t - last < 100) return;
        last = t; wk.heading = h;
        if (first) A.map.me(walkMe()); else A.map.heading(h);
      };
      compassFn.type = type;
      addEventListener(type, compassFn);
    }
    function compassOff() { if (compassFn) { removeEventListener(compassFn.type, compassFn); compassFn = null; } }

    /* ------------------------------------------------ the phone's sheet, its chrome and its layers (docs/35 round 1) */

    // The canvas (the fixed map's box) and what stands under the sheet: the tab bar on the plain map, nothing
    // under a layer (it has slid away, §2.1).
    const canvasH = () => (A.el && A.el.getBoundingClientRect().height) || innerHeight;
    const tabsH = () => { const tb = document.querySelector('.wk-tabbar'); return tb ? tb.offsetHeight : 0; };
    const floorH = () => A.layerOn ? 0 : tabsH();
    // What floats over the map's top (Search, the chips, a notice), as laid out (a tuck's slide aside).
    const floatFoot = () => { const fl = A.el && A.el.querySelector('.pm-float'); return fl && fl.offsetHeight ? fl.offsetTop + fl.offsetHeight : 64; };
    const sbarFoot = () => { const sb = A.el && A.el.querySelector('.pm-sbar'); return sb && sb.offsetHeight ? sb.offsetTop + sb.offsetHeight : 56; };
    // How much of the map's foot the sheet (and the demo's dock above it) covers, at its stop.
    const sheetInset = () => SH ? Math.max(0, Math.round(canvasH() - SH.top())) + 12 + dockH() : 0;

    // The stops (§2.3), measured: peek is the sheet's data-peek parts plus 16 (92–240; the planner's peek,
    // time to Start, plus 12, however tall); half the content up to 50% of the screen; full the content up
    // to 8 px under Search (or the planner's card).
    function sheetStops() {
      // (top: where the content's top would be unscrolled. A drag up on First Aid's one row ran on into a
      // 16 px scroll of the body, which measured the peek 16 px shorter, and the sheet dropped 16 px; the fix pass.)
      const s = SH.el, body = SH.body, top = s.getBoundingClientRect().top - (body.scrollTop || 0);
      const kids = Array.from(body.children);
      const pad = parseFloat(getComputedStyle(body).paddingBottom) || 0;
      const content = Math.ceil(kids.reduce((m, k) => Math.max(m, k.offsetTop + k.offsetHeight), body.offsetTop) + pad);
      // (Under the planner's card, 8 px under it: the card takes Search's place.)
      const full = Math.max(92, Math.round(canvasH() - floorH() - ((dirsOpen() && !A.walk ? dcardFoot() : sbarFoot()) + 8)));
      const els = Array.from(body.querySelectorAll('[data-peek]')).filter(e => e.offsetHeight);
      let peek = els.length ? Math.ceil(Math.max.apply(null, els.map(e => e.getBoundingClientRect().bottom)) - top) + (dirsOpen() ? 12 : 16) : 92;
      // The peek ends where what follows begins, when that's nearer than 16 px: no sliver of the next
      // heading ("TODAY HERE") shows at the screen's foot under Directions (round 1's check).
      if (els.length) {
        const last = els.reduce((m, e) => e.getBoundingClientRect().bottom > m.getBoundingClientRect().bottom ? e : m, els[0]);
        let nx = null;
        // (A heading only a screen reader hears isn't what follows: round 2, the planner's hidden "Steps"
        // cut the 12 px under Start.)
        for (let e = last; e && e !== body && !nx; e = e.parentElement) { let s = e.nextElementSibling; while (s && (!s.offsetHeight || s.classList.contains('ogc-sr'))) s = s.nextElementSibling; nx = s; }
        const at = nx ? Math.floor(nx.getBoundingClientRect().top - top) : Infinity;
        if (at < peek && at > peek - 24) peek = at;
      }
      peek = dirsOpen() ? Math.min(Math.max(peek, 92), full) : Math.max(92, Math.min(peek, 240));
      peek = Math.min(peek, Math.max(92, content));
      const half = Math.min(content, Math.round(innerHeight * .5), full);
      // At its tallest stop the demo's dock rests at the screen's foot over the sheet (ogc-dev-nav.js): room
      // for it under the last row, when there is a tallest stop above half anyway (round 2, leftover 4).
      const room = dockRoom(), top3 = Math.min(content, full) > Math.max(peek, half) + 8;
      A.el.style.setProperty('--pm-dockroom', (top3 ? room : 0) + 'px');
      return { peek, half, full: Math.min(content + (top3 ? room : 0), full) };
    }
    // (The demo's dock, where there is one: its height and 16 px.)
    const dockRoom = () => { const r = dockBox(true); return r ? r.h + 16 : 0; };
    function sheetMake() {
      const s = A.el.querySelector('.pm-sheet');
      if (!s || !O.sheet) return;
      SH = O.sheet.docked(s, {
        stops: sheetStops,
        floor: floorH,
        // Down past its peek: a place (or the planner) closes, one layer; the plain map's sheet tucks.
        below: () => { if (A.place) closeLayer(); else tuckSet(true); },
        raised: () => tuckSet(false),
        settled: stop => { if (stop !== 'lip') A.snap = stop; sheetSettled(); },
        // Locate and the credit ride on its top; Locate fades once it's above half (§2.2).
        moved: (ride, ms) => {
          A.rideMs = ms;
          A.el.style.setProperty('--pm-ride', ride + 'px');
          A.el.style.setProperty('--pm-ride-ms', ms + 'ms');
          A.el.classList.toggle('is-high', ride - floorH() > innerHeight * .5 + 8);
          // Pulled up past the chips (its tallest stop is 8 px under Search): the chips and a notice step
          // aside, so nothing floats over the sheet's rows; Search stays.
          if (A.chipsFoot == null) A.chipsFoot = floatFoot();
          A.el.classList.toggle('is-over', canvasH() - ride < A.chipsFoot);
        }
      });
    }
    // A stop reached: the map keeps clear of what covers it (once, never during a drag), the picker fits.
    function sheetSettled() {
      if (!SH) return;
      // (The demo dock rests above the sheet, and at its foot over the sheet's tallest stop: ogc-dev-nav.js
      // reads is-full.)
      SH.el.classList.toggle('is-full', SH.stop === 'full' && !SH.tucked);
      if (A.map && !A.walk) A.map.inset(Object.assign({ top: topInset(), bottom: sheetInset() }, sideInset()));
      pickerFit();
      // (As soon as the sheet's ease is done, not later: untucked, it never sits over Locate for long.)
      if (window.OGC_DOCK && OGC_DOCK.lift) setTimeout(() => OGC_DOCK.lift(), (A.rideMs || 0) + 20);
    }
    // The floor picker shrinks to one 44 × 76 button ("B" over "1") when the room between the chips and
    // the sheet is shorter than it and 60 px; a tap opens it full (§2.2). (Under the planner's card when
    // it's open: round 2, the picker's top sat under the card.)
    function pickerFit() {
      if (A.mode !== 'full' || !SH) return;
      const pk = A.mapEl && A.mapEl.querySelector('.pv-floors');
      const n = pk ? pk.querySelectorAll('[data-fl]').length : 0, top = (dirsOpen() && !A.walk ? dcardFoot() : floatFoot()) + 16;
      // (Walking, the planner's sheet is away: the picker under the card has the map's height.)
      const mini = !!pk && !A.pkOpen && !A.walk && SH.top() - top < 32 + 44 * n + 60;
      A.el.classList.toggle('is-pkmini', mini);
      A.el.style.setProperty('--pm-pk', top + 'px');
    }
    // A tap on the empty map (§2.3): the sheet down to its peek; at its peek, everything tucks; tucked, back.
    function mapTap() {
      if (A.mode !== 'full' || !SH || A.walk) return;
      if (SH.tucked) { tuckSet(false); return; }
      if (SH.stop !== 'peek') { SH.set('peek', 'ease'); return; }
      tuckSet(true);
    }
    // Tucked (§6 question 4): Search and the chips slide up out of sight; the sheet drops to its 44 px lip.
    // Locate, the picker and the credit stay; the tab bar stays on the plain map. Any tap brings it back.
    function tuckSet(on) {
      if (!SH || A.mode !== 'full' || on === SH.tucked) return;
      // (The demo's dock steps out of sight while the sheet and Locate move, then comes back where they
      // settled: lifted afterwards, it lagged Locate by 0.3 s.)
      if (window.OGC_DOCK && OGC_DOCK.hold) OGC_DOCK.hold(still() ? 40 : 320);
      A.el.classList.toggle('is-tucked', on);
      lipLine();
      SH.tuck(on, 'ease');
      say(on ? 'Map only' : 'Search shown');
    }
    // The lip's one line: the place's name, or what's next.
    function lipLine() {
      const lip = A.el && A.el.querySelector('.ogc-sheet__lip'); if (!lip) return;
      const h = A.place && SH && SH.body.querySelector('.pm-h'), nx = !A.place ? nextEvent() : null;
      // (The heading's words without its code chip: "Barnes Student Center", never "… Center B".)
      const name = h ? Array.from(h.childNodes).filter(n => !(n.classList && n.classList.contains('pm-code'))).map(n => n.textContent).join('').replace(/\s+/g, ' ').trim() : '';
      const t = name || (nx ? 'Next · ' + nx.title : 'Places');
      lip.innerHTML = '<b>' + esc(t) + '</b>';
      lip.setAttribute('aria-label', t + ', show all');
      // The sheet's region is named for what it shows (§2.8): "Henry West Room 143", else Places.
      if (SH) SH.el.setAttribute('aria-label', name || 'Places');
    }
    // What floats over a phone's map (§2.2), drawn with the sheet: the building chip, then the usual places
    // (hidden while a place is open), a notice; the tab bar away under a layer (§2.1, §6 question 3).
    function chrome() {
      if (A.mode !== 'full') return;
      const ch = A.el.querySelector('.pm-chips');
      if (ch) {
        const html = A.plans && !A.place ? bChip() + stripChips(false) : '';
        if (ch.innerHTML !== html) { const sl = ch.scrollLeft; ch.innerHTML = html; ch.scrollLeft = sl; }
        ch.hidden = !html;
        A.el.classList.toggle('has-chips', !!html);
      }
      const nt = A.el.querySelector('.pm-notes');
      if (nt) { const html = !A.place ? A.ctx.notes || '' : ''; if (nt.innerHTML !== html) nt.innerHTML = html; nt.hidden = !html; }
      const dt = A.el.querySelector('.pm-dtop');
      if (dt) {
        const html = dirsOpen() && !A.walk ? dcardView() : '';
        if (dt._card !== html) { dt.innerHTML = html; dt._card = html; }
        dt.hidden = !html;
        // A row's building and floor (or code) show whole or not at all once the name has taken the room:
        // a short code can't take an ellipsis, and was cut through its letter ("Recreation & Wellness
        // Center Y"; the fix pass, round 2). Longer words keep their ellipsis when 40 px or more of them show.
        if (html) dt.querySelectorAll('.pm-end__m small').forEach(s => { s.classList.remove('is-off'); const full = s.scrollWidth, shown = s.clientWidth; if (full > shown + 1 && (full < 48 || shown < 40)) s.classList.add('is-off'); });
      }
      A.chipsFoot = null;
      const de = document.documentElement, tb = document.querySelector('.wk-tabbar'), layer = !!A.place && !A.place.arrived && !A.hidden;
      de.classList.toggle('pm-layer', layer);
      if (tb && !A.walk) tb.inert = layer;
      lipLine();
    }
    // The building chip (§2.2): "Barnes · 1st floor", while a building's floor is open and nothing is chosen.
    function bChip() {
      const o = A.L && A.L.open(), B = o && A.L.building(o.code);
      if (!B) return '';
      const name = B.item ? bShort(B.item) : B.short || B.name;
      return '<button type="button" class="pm-chip pm-chip--b" data-pm="bchip">' + I.building + '<span><b>' + esc(name + ' · ' + M.floorName(o.floor)) + '</b></span></button>';
    }
    // The floor shown changed (the picker, a zoom, a place opening): the chip and a building's Rooms follow.
    let floorT = 0;
    function floorShown() {
      clearTimeout(floorT);
      floorT = setTimeout(() => {
        if (A.hidden || !A.el) return;
        A.pkOpen = false;
        if (A.mode === 'full') { chrome(); pickerFit(); }
        const p = A.place && A.place.code && !A.place.kind ? P(A.place.code) : null, g = p && groups().find(z => z.key === keyOf(p.code));
        if (p && g && !g.derived && g.main.code === p.code) paint();
        // (The nearest restrooms' rings give way to their icon chips where a floor now shows.)
        else if (A.place && A.place.kind === 'nearest' && A.place.rows) drawMap(false);
      }, 0);
    }
    // A layer closing: the sheet leaves downwards, a copy of it so the plain sheet can come up at once.
    function ghost() {
      if (!SH || still()) return;
      const g = SH.el.cloneNode(true);
      g.classList.add('pm-ghost'); g.removeAttribute('role'); g.removeAttribute('aria-label'); g.setAttribute('aria-hidden', 'true'); g.inert = true;
      g.querySelectorAll('[id]').forEach(e => e.removeAttribute('id'));
      g.style.pointerEvents = 'none';
      A.el.appendChild(g);
      void g.offsetHeight;
      g.style.transition = 'transform 140ms cubic-bezier(.2, .8, .2, 1)';
      g.style.transform = 'translate3d(0,' + Math.round(canvasH() + 8) + 'px,0)';
      setTimeout(() => g.remove(), 170);
    }

    // Back, one layer at a time (§2.7): a place is one history entry (?to=CODE), the planner one more
    // (&dirs=1). The app's own state says which are open; O.layers keeps the history in step.
    // A room opened from inside a building (its plate, a row of its Rooms) is a layer over the building
    // (round 2, leftover 7): Back and × come back to the building at its peek. chain() is the place and
    // the building under it, or the place alone; under the planner, the place it was opened from.
    const chain = () => { const t = A.place && A.place.kind === 'dirs' ? A.dir && A.dir.back : A.place; return !t ? [] : t.parent ? [t.parent, t] : [t]; };
    function layersWanted() {
      if (!A.place) return [];
      const c = ['place', 'sub'].slice(0, chain().length);
      // (The walk over the planner: §2.7.)
      return A.place.kind === 'dirs' ? c.concat(A.walk ? ['dirs', 'walk'] : ['dirs']) : c;
    }
    function layerUrl(name) {
      // (The walk keeps the planner's address: a reload is the planner, never a walk.)
      if (name === 'walk') name = 'dirs';
      const u = new URL(location.href);
      ['to', 'dirs', 'room'].forEach(k => u.searchParams.delete(k));
      const c = chain(), t = name === 'dirs' ? (A.dir && A.dir.to ? A.dir.to.place : null) : name === 'sub' ? c[1] : c[0];
      if (t && t.code && !t.kind) {
        u.searchParams.set('to', t.code);
        if (t.room && t.room.number != null) u.searchParams.set('room', t.room.floor + '-' + t.room.number);
      }
      if (name === 'dirs') u.searchParams.set('dirs', '1');
      return u.href;
    }
    // Back closed a layer: what was open under it shows again, on Places.
    function layerClosed(name) {
      // Back while walking is End: the planner again (§2.7).
      if (name === 'walk') { if (A.walk) endWalk(); return; }
      if (name === 'dirs') { if (A.dir || (A.place && A.place.kind === 'dirs')) closeDirs(); return; }
      const under = name === 'sub' ? chain()[0] : null;
      if (A.walk) endWalk(true);
      if (A.dir) { A.dir = null; if (A.watch == null && /^Location (off|unavailable)$/.test(A.nav.status)) A.nav.status = ''; if (A.map) { A.map.route(null); A.map.reach(null); } if (A.L) { A.L.pick(null); A.L.route(null); A.L.focus(null); } }
      A.place = under && P(under.code) ? { code: under.code } : null; settle('peek'); paint();
    }
    // Only Places' own layers (a place, a room over its building, the planner): Search, the menu or a sheet
    // over them is theirs to close, and ours wait under it (a redraw while the menu is open never takes the
    // menu's Back away).
    const ownLayer = n => n === 'place' || n === 'sub' || n === 'dirs' || n === 'walk';
    function syncLayers() {
      const L = O.layers; if (!L || A.hidden) return;
      const all = L.names();
      if (all.length && !ownLayer(all[all.length - 1])) return;
      let from = all.length; while (from > 0 && ownLayer(all[from - 1])) from--;
      const want = layersWanted(), have = all.slice(from);
      let i = 0; while (i < want.length && i < have.length && want[i] === have[i]) i++;
      if (have.length > i) L.pop(have.length - i);
      for (let j = i; j < want.length; j++) L.push(want[j], { close: () => layerClosed(want[j]), url: layerUrl(want[j]) });
      if (i && i === want.length) L.swap(want[i - 1], { url: layerUrl(want[i - 1]) });
    }
    // × on a place, or a drag down past its peek: the top layer closes (the planner back to its place).
    function closeLayer() {
      if (A.place && A.place.kind === 'dirs') { closeDirs(); return; }
      const par = A.place && A.place.parent;
      A.place = par && P(par.code) ? { code: par.code } : null; settle('peek'); paint();
    }
    // The building a room is opened over (leftover 7): the open place when it is that room's building (its
    // own row), or the building a room open over it is already over; else none.
    function parentFor(code) {
      const cur = A.place, p = P(code);
      if (!cur || cur.kind || !p) return null;
      if (cur.parent) return keyOf(cur.parent.code) === keyOf(p.code) ? cur.parent : null;
      const g = !cur.room && groups().find(z => z.key === keyOf(cur.code));
      return g && !g.derived && g.main.code === cur.code && p.code !== cur.code && keyOf(p.code) === g.key ? { code: cur.code } : null;
    }

    // The menu signed out (§3.4, until round 3's): Share the app, Conference page, Sign in. Signed in, the
    // account's own menu has the same rows (ogc-account.js, from OGC_ACCT_EXTRA).
    function openMenu() {
      if (!O.sheet || !O.sheet.modal) return;
      const ix = menuRows(), rows = ix.map((r, i) => '<li>' + (r.href ? '<a href="' + esc(r.href) + '"' + (r.blank ? ' target="_blank" rel="noopener"' : '') + '>' + esc(r.label) + I.next + '</a>' : '<button type="button" data-row="' + i + '">' + esc(r.label) + I.next + '</button>') + '</li>').join('');
      const m = O.sheet.modal('<h2 class="ogc-sheet__h">Menu</h2><ul class="ogc-sheet__rows">' + rows + '</ul>', { label: 'Menu', className: 'pm-menusheet' });
      m.el.addEventListener('click', e => { const b = e.target.closest('[data-row]'); if (!b) return; const r = ix[+b.dataset.row]; m.close('row'); if (r && r.run) setTimeout(r.run, 160); });
    }
    function menuRows() {
      const c = A.ctx || {}, rows = [];
      if (c.share) rows.push({ label: 'Share the app', run: c.share });
      if (c.page && !c.offline) rows.push({ label: 'Conference page', href: c.page, blank: !!c.installed });
      if (!(W().me && W().me.email) && W().signin && !c.offline) rows.push({ label: 'Sign in', href: W().signin + (W().signin.indexOf('?') > -1 ? '&' : '?') + 'return=' + encodeURIComponent(location.pathname + location.search) });
      return rows;
    }
    // The account's menu on a phone's Places (signed in): its extra rows, the same as the menu's.
    window.OGC_ACCT_EXTRA = () => A.mode === 'full' && !A.hidden ? menuRows().filter(r => r.label !== 'Sign in') : [];

    /* ------------------------------------------------ acting */

    function openBuilding(name) {
      const g = groups().find(z => { const w = where(z.main); return w.b && w.b.name === name; });
      if (g) { focus(g.main.code); return true; }
      // Any other building on the map (polish 3: a hall not confirmed is a building like the rest for the public).
      if (A.c.items.some(i => i.lab && i.name === name && i.name !== 'Building' && i.short !== '-')) { A.place = { kind: 'hall', name }; settle('half'); paint(true); say(name); return true; }
      return false;
    }
    function openSpot(id) { A.place = { kind: 'spot', id }; settle('half'); paint(true); say(spotName(id)); }
    // Where I sleep: my hall's card (its line says my rooms), or the camper lot.
    // Its own sheet even when the hall is also a place on the schedule (Hodson Hall is N): the place's sheet
    // has no floor or rooms, and My room is the household's floor and rooms (§4.3; the check).
    function openStay() {
      const s = A.stay, b = stayHall() && M.find(A.c, stayHall());
      if (s && s.type === 'camper' && camper()) openSpot(camper().id);
      else if (b) { A.place = { kind: 'hall', name: b.name }; settle('half'); paint(true); say(stayName()); }
    }
    // A place on the map, its sheet open: what a schedule row's place, a card's name or a tap leads to.
    // under: the building it opens over (parentFor), from inside that building only.
    function focus(code, room, under) {
      const p = P(code); if (!p) return;
      A.place = room ? { code: p.code, room } : { code: p.code };
      if (under) A.place.parent = under;
      settle('half');
      if (!A.map) { const w = where(p); A.pendingFocus = w.b ? roomy(M.boxOf(A.c, [w.b.name], 10), A.mode === 'full' ? .45 : .35) : w.kind === 'pin' ? { x: w.x - 60, y: w.y - 60, w: 120, h: 120 } : null; }
      paint(true);
      say(room ? room.name : p.name);
      remember(p.code);
    }
    // A place opens at its peek (name, fact line, Directions; docs/35 §2.4), the planner too (the time, the
    // legs and Start); the person pulls it up, or a step tapped brings it to half (round 2).
    function settle(snap) { A.snap = snap === 'half' ? 'peek' : snap; }
    const say = t => { if (A.ctx && A.ctx.say) A.ctx.say(t); };
    // The places opened lately (codes only), first in Search.
    function remember(code) {
      const r = LS.get('ogc-map-recent', []).filter(c => c !== code); r.unshift(code); LS.set('ogc-map-recent', r.slice(0, 4));
    }
    function endFrom(v) {
      if (v === 'stay') return { kind: 'stay' };
      if (v.indexOf('room:') === 0) { const r = roomOfV(v); return r ? { kind: 'place', code: r.code, name: r.name, room: r } : null; }
      if (v.indexOf('near:') === 0) return { kind: 'near', i: +v.slice(5) };
      if (v.indexOf('feat:') === 0) { const a = v.split(':'); return { kind: 'feat', code: a[1], floor: +a[2], sub: a[3], number: a.slice(4).join(':') }; }
      if (v.indexOf('list:') === 0) return { kind: 'list', v: v.slice(5) };
      if (v.indexOf('hall:') === 0) return { kind: 'hall', name: v.slice(5) };
      if (v.indexOf('spot:') === 0) return { kind: 'spot', id: v.slice(5) };
      const p = P(v); return p ? { kind: 'place', code: p.code, name: p.name } : null;
    }
    // A choice (a chip, a search result, a ?to= link): shown on the map with its card.
    function openEnd(e) {
      if (!e) return;
      if (e.kind === 'place') focus(e.code, e.room || null);
      else if (e.kind === 'hall') { const b = M.find(A.c, e.name); if (b) openBuilding(b.name); }
      else if (e.kind === 'spot') openSpot(e.id);
      else if (e.kind === 'stay') openStay();
      else if (e.kind === 'feat') openFeat(e.code, e.floor, e.sub, e.number);
      else if (e.kind === 'list') openList(e.v);
      else if (e.kind === 'near' && A.ctx.openNear) A.ctx.openNear(e.i);
    }

    /* ------------------------------------------------ searching */

    // Everything Search finds: buildings, rooms, halls, lots and the like, Help's
    // places, and every row of the schedule ("Volleyball" finds its field, mapped or not).
    function candidates(which) {
      const out = [];
      groups().forEach(g => {
        const b = where(g.main).b, words = b ? [b.name, b.short].concat(b.aliases, KIND_WORDS[b.kind] || []).join(' ') : '';
        // terms: its own search words and its features' (places.csv; Oct 13), matched whole in ranked().
        const terms = p => (p.search || []).concat(O.featureWords ? O.featureWords(p.features) : []);
        // With floor plans: IWU's own numbers ("143", "Barnes 143"), only for the Conference's rooms (§4.2),
        // and the room's building and floor under it ("Barnes · 1st floor").
        const nums = p => A.P ? (A.P.roomsOf(p.code) || []).map(r => String(r.number).toLowerCase()) : [];
        const bw = b ? [b.name, b.short, shorts[b.name] || '', g.key].join(' ') : g.name;
        if (!g.derived) out.push({ v: g.main.code, main: g.name, sub: A.plans ? factLine(g.main, true) : '', code: g.main.code, ok: routable(g.main), kind: 0, words, terms: terms(g.main), nums: nums(g.main), bw });
        (g.derived ? g.all : g.rooms).forEach(r => out.push({ v: r.code, main: inBuilding(r, g.name), sub: A.plans && planOf(r) ? [b ? bShort(b) : g.name, planFloor(r) != null ? M.floorName(planFloor(r)) : ''].filter(Boolean).join(' · ') : g.name, code: r.code, ok: routable(r), kind: 1, terms: terms(r), nums: nums(r), bw }));
      });
      // A place's own rooms by IWU's name ("Balcony · Chapel · 2nd floor").
      namedRooms().forEach(r => { const p = P(r.code), b = where(p).b; out.push({ v: roomV(r), main: r.name, sub: [b ? bShort(b) : p.name, M.floorName(r.floor)].join(' · '), code: p.code, ok: routable(p), kind: 1, words: p.name }); });
      // My room, to its own household alone (their own /me/stay, kept on this phone): "my room", "room",
      // the hall's name or their own number. Nobody else's number is anywhere here (§4.2).
      if (stayEnd()) out.push({ v: 'stay', main: stayName(), sub: staySub(), code: '', ok: true, kind: -1, grp: 'My room', words: 'my room ' + (stayHall() || '') + ' hall', nums: A.stay && A.stay.rooms ? A.stay.rooms.map(r => String(r.num).toLowerCase()) : [] });
      // The restrooms and elevators in the plans (Nearest), once they've been read.
      // "Nearest" only when measured (from the room last opened, or where the phone is); else they're just
      // the Restrooms and the Elevators (the check: "Nearest" claimed more than was known).
      const near = k => A.measured ? 'Nearest' : k === 'restroom' ? 'Restrooms' : 'Elevators';
      ['restroom', 'elevator'].forEach(k => uniqFeats(Array.isArray(A.feats[k]) ? A.feats[k] : []).forEach((f, fi) => out.push({ fi, v: featV(f), main: f.word, sub: f.B.short + ' · ' + M.floorName(f.floor) + (f.m != null ? ' · ' + M.feet(f.m) : ''), code: '', ok: true, kind: 2.5, grp: near(k), words: k === 'restroom' ? 'restroom restrooms bathroom toilet ' + f.word : 'elevator elevators lift' })));
      A.c.items.filter(i => i.kind === 'hall' && i.lab && i.name !== 'Building').forEach(h => out.push({ v: 'hall:' + h.name, main: h.name, sub: /\bhall\b/i.test(h.name) ? '' : 'Hall', code: '', ok: true, kind: 2, words: h.aliases.join(' ') + ' hall dorm residence' }));
      // Every other named building, for typing ("Reed" finds Reed Hall whether or not it's a hall here).
      const listed = new Set(out.map(c => c.main));
      A.c.items.filter(i => i.kind !== 'hall' && i.lab && i.name && i.name !== 'Building' && i.short !== '-' && i.pts.length > 2 && /^(other|dining|worship|venue)$/.test(i.kind) && !groups().some(g => where(g.main).b === i) && !listed.has(i.name)).forEach(b => out.push({ v: 'hall:' + b.name, main: b.name, sub: '', code: '', ok: true, kind: 2, words: (b.short || '') + ' ' + b.aliases.join(' ') }));
      A.c.spots.forEach(s => out.push({ v: 'spot:' + s.id, main: s.name || M.SPOT[s.spot], sub: s.name ? M.SPOT[s.spot] : '', code: '', ok: true, kind: 2, words: (M.SPOT[s.spot] || '') + ' ' + (SPOT_WORDS[s.spot] || '') + ' ' + (s.note || '') }));
      (A.ctx.help || []).filter(h => h.place && P(h.place)).forEach(h => out.push({ v: P(h.place).code, main: h.need, sub: P(h.place).name, code: P(h.place).code, ok: routable(P(h.place)), kind: 1, grp: 'Help', words: h.text || '', terms: h.search || [] }));
      // Care nearby, off campus (Search only: it has no Directions, driving is held, §13.2). Its sheet
      // has Emergency first.
      if (which === 'search' && A.ctx.openNear) (A.ctx.nearby || []).forEach((n, i) => { if (n.name) out.push({ v: 'near:' + i, main: n.name, sub: [n.kind, n.distance].filter(Boolean).join(' · '), code: '', ok: true, kind: 2, grp: 'Help', words: (n.kind || '') + ' care' }); });
      // Each row's place in time: today's to come (0), later days (1), past (2); then its day and time.
      const nw = A.ctx.now ? A.ctx.now() : null, gone = new Set(today().filter(it => it.state === 'past' && it.id).map(it => it.id));
      const when = e => { const day = e.date || '', t = e.start == null ? 1e4 : e.start; if (!nw || !day) return [1, day, t]; return [day < nw.date || (day === nw.date && ((e.id && gone.has(e.id)) || (e.end != null && e.end <= nw.minutes))) ? 2 : day === nw.date ? 0 : 1, day, t]; };
      (A.ctx.events ? A.ctx.events() : []).filter(e => e.code).forEach(e => { const p = P(e.code); out.push({ v: p ? p.code : '', main: e.title, sub: [e.when, p ? p.name : ''].filter(Boolean).join(' · '), code: p ? p.code : '', ok: !!p && routable(p), kind: 3, et: e.title, es: e.start == null ? '' : e.start, ord: when(e) }); });
      return out;
    }
    // Best first: the name itself, then names starting with it, then a word starting with it, then
    // anywhere in the name, then the code, then the line under it (polish 1: "first aid" put Barnes
    // above the First Aid Room).
    // Polish 2: also the words a place goes by ("dining", "cafeteria", "food" find Barnes; "parking",
    // "info" find the lots and the desk), what people say for what the campus calls it ("bathroom" is a
    // restroom), and a one-letter slip in a word of five letters or more ("barns"; places only: "parking"
    // isn't "Kit packing").
    function ranked(list, t) {
      const T = t.toUpperCase(), alts = [t].concat(SYN[t] || []);
      const words = s => String(s || '').toLowerCase().split(/[\s(/·,&-]+/).filter(Boolean);
      const slip = (w, q) => { if (q.length < 5 || Math.abs(w.length - q.length) > 1) return false; let i = 0, j = 0, e = 0; while (i < w.length && j < q.length) { if (w[i] === q[j]) { i++; j++; continue; } if (++e > 1) return false; if (w.length > q.length) i++; else if (q.length > w.length) j++; else { i++; j++; } } return e + (w.length - i) + (q.length - j) <= 1; };
      const one = (c, t) => { const n = c.main.toLowerCase(); if (n === t || c.code === T) return 0;
        if (c.nums && c.nums.length) { if (c.nums.indexOf(t) > -1) return .5; const mm = /^(.+?)\s+(\w+)$/.exec(t); if (mm && c.nums.indexOf(mm[2]) > -1 && words(c.bw || '').some(w => w.indexOf(mm[1]) === 0)) return .5; } if (n.indexOf(t) === 0) return 1; if (words(n).some(w => w.indexOf(t) === 0)) return 2; if (n.indexOf(t) > -1) return 3; if (c.code && c.code.indexOf(T) === 0) return 3.5; if (c.terms && (c.terms.indexOf(t) > -1 || (t.length > 3 && /s$/.test(t) && c.terms.indexOf(t.slice(0, -1)) > -1))) return 3.8; if (words(c.words).some(w => w.indexOf(t) === 0)) return 4; if (c.sub.toLowerCase().indexOf(t) > -1) return 5; if (c.kind !== 3 && words(n + ' ' + (c.words || '')).some(w => slip(w, t))) return 6; return Infinity; };
      const score = c => Math.min.apply(null, alts.map((a, i) => one(c, a) + (i ? .5 : 0)));
      const seen = new Set();
      // The restrooms and elevators keep their own order, the nearest first (round 2 part 2: "Restroom"
      // came before a nearer "Women’s restroom" for matching the word whole): one score for them all.
      const scored = list.map(c => Object.assign({ s: score(c) }, c)).filter(c => c.s < Infinity);
      const fs = Math.min.apply(null, scored.filter(c => c.fi != null).map(c => c.s).concat(Infinity));
      scored.forEach(c => { if (c.fi != null) c.s = fs; });
      return scored.sort((a, b) => a.s - b.s || a.kind - b.kind || (a.fi != null && b.fi != null ? a.fi - b.fi : 0) || a.main.length - b.main.length)
        // With floor plans a schedule row is its own day and time, sorted by time in filter() (round 2: "supper"
        // kept only Friday's, past, of five). A campus with no plans keeps one row a title, as before.
        .filter(c => { const k = c.v + '|' + c.main + (c.kind === 3 && A.plans ? '|' + c.ord[1] + '|' + c.ord[2] : ''); if (seen.has(k)) return false; seen.add(k); return true; }).slice(0, A.plans ? 60 : 40);
    }
    const resultRow = (which, c) => { const miss = !c.ok && member(A.ctx.year) ? 'Not on the map yet' : ''; return '<li><button type="button" data-pm="set" data-which="' + which + '" data-v="' + esc(c.v) + '"' + (c.et ? ' data-et="' + esc(c.et) + '" data-es="' + esc(c.es) + '"' : '') + (c.ok || (which === 'search' && c.v) ? '' : ' disabled') + '><span><b>' + esc(c.main) + '</b>' + (c.sub || miss ? '<small>' + esc([c.sub, miss].filter(Boolean).join(' · ')) + '</small>' : '') + '</span>' + (c.code ? '<code>' + esc(c.code) + '</code>' : '') + '</button></li>'; };
    // Search's body: the usual places; with nothing typed, Recent, every building with its rooms, the
    // halls, and parking and services; as you type, the ranked results.
    function pickBody(which) {
      const recent = LS.get('ogc-map-recent', []).map(P).filter(Boolean).filter(p => routable(p));
      const gs = groups().filter(g => where(g.main).kind !== 'none');
      const halls = A.c.items.filter(i => i.kind === 'hall' && i.lab && i.name !== 'Building' && !gs.some(g => where(g.main).b === i));
      const li = (v, main, sub, code) => '<li><button type="button" data-pm="set" data-which="' + which + '" data-v="' + esc(v) + '"><span><b>' + esc(main) + '</b>' + (sub ? '<small>' + esc(sub) + '</small>' : '') + '</span>' + (code ? '<code>' + esc(code) + '</code>' : '') + '</button></li>';
      // From's or To's Search (the planner, §4.5): My location (a phone), My room, then the same Search,
      // without the chips (they open places, not ends).
      const end = which === 'from' || which === 'to';
      const chips = end ? '' : A.plans ? stripChips(true) : quickChips(), help = end ? '' : A.plans ? stripChips(true) : helpChips();
      // With floor plans: My room first (its own household only), then Recent, then the chips (§4.2).
      // (Then Choose on map: a dropped pin where the next tap is, docs/35 §2.5.)
      const mine = end ? (touch() && A.mode === 'full' ? li('here', 'My location', A.nav.status && A.nav.status !== 'Locating' ? A.nav.status : '', '') : '') + (stayEnd() ? li('stay', stayName(), staySub(), '') : '') + li('map', 'Choose on map', '', '')
        : A.plans && stayEnd() ? '<li data-sec><p class="pm-k">' + esc(stayName()) + '</p></li>' + li('stay', stayName(), staySub(), '') : '';
      const sub = r => A.plans && planFloor(r) != null ? M.floorName(planFloor(r)) : '';
      return '<label class="pm-q"><span class="ogc-sr">Search</span><input type="search" data-pmq data-which="' + which + '" placeholder="Building, room or code" autocomplete="off" enterkeyhint="search"><button type="button" class="pm-qx" data-pm="qx" aria-label="Clear" title="Clear" hidden>' + I.close + '</button></label><div class="pm-pickbody">' +
        (mine ? '<ul class="pm-list" data-quick>' + mine + '</ul>' : '') +
        (A.plans ? '' : chips ? '<div class="pm-quick" data-quick>' + chips + '</div>' : '') +
        '<ul class="pm-list" data-results hidden></ul><div data-none hidden><p class="pm-none">No results</p>' + (help ? '<div class="pm-quick">' + help + '</div>' : '') + '</div>' +
        '<ul class="pm-list" data-list>' +
        (recent.length ? '<li data-sec><p class="pm-k">Recent</p></li>' + recent.map(p => li(p.code, roomName(p), A.plans ? factLine(p, String(p.code).indexOf('/') < 0).replace(/ · [A-Z0-9]+\/[A-Z0-9]+$/, '') : String(p.code).indexOf('/') > -1 ? bShort(where(p).b) : '', p.code)).join('') : '') +
        (A.plans && chips ? '<li data-sec class="pm-list__chips"><div class="pm-quick">' + chips + '</div></li>' : '') +
        '<li data-sec><p class="pm-k">Buildings</p></li>' +
        gs.map(g => {
          const head = g.derived ? '<p class="pm-list__h">' + esc(g.name) + '</p>' : li(g.main.code, g.name, '', g.main.code);
          return '<li class="pm-list__g"><ul>' + head + (g.derived ? g.all : g.rooms).map(r => '<li class="pm-list__r">' + li(r.code, inBuilding(r, g.name), sub(r), r.code).slice(4)).join('') + '</ul></li>';
        }).join('') +
        (halls.length ? '<li data-sec><p class="pm-k">Halls</p></li>' + halls.map(h => li('hall:' + h.name, h.name, '', '')).join('') : '') +
        (A.c.spots.length ? '<li data-sec><p class="pm-k">Parking and services</p></li>' + A.c.spots.map(s => li('spot:' + s.id, s.name || M.SPOT[s.spot], s.name ? M.SPOT[s.spot] : '', '')).join('') : '') +
        '</ul></div>';
    }
    // Search opens full height with the field at the top, focused even on a phone (polish 1: a short
    // sheet with its field under the keyboard, a second tap to type).
    function picker(which) {
      which = which === 'from' || which === 'to' ? which : 'search';
      dlg.classList.add('is-search', 'is-full');
      dlg.classList.toggle('pm-pick--plans', !!A.plans);
      // Nearest needs the plans' restrooms and elevators: read once, in the background.
      if (A.L) ['restroom', 'elevator'].forEach(k => { if (featsStale(k)) loadFeats(k).then(() => { const q = dlg.open && dlg.querySelector('[data-pmq]'); if (q && q.value.trim()) filter(q); }); });
      // The rooms by IWU's name need the walking graph: read once, in the background.
      if (A.P && !A.build) routerNow().then(() => { const q = dlg.open && dlg.querySelector('[data-pmq]'); if (q && q.value.trim()) filter(q); });
      dlg.innerHTML = '<div class="wk-sheet__in pm-pickin"><button type="button" class="wk-sheet__x" data-close aria-label="Close">' + I.close + '</button>' +
        '<h2 class="ogc-sr" id="pm-pick-t">' + (which === 'from' ? 'From' : which === 'to' ? 'To' : 'Search') + '</h2>' + pickBody(which) + '</div>';
      dlg.showModal();
      // A layer (docs/35 §2.7): Back closes Search and stays on Places.
      if (O.layers && !A.pickL) A.pickL = O.layers.push('search', { close: () => { A.pickL = null; if (dlg.open) dlg.close(); } });
      const q = dlg.querySelector('[data-pmq]'); if (q) q.focus();
    }
    // Search closed by the app or the person (a choice, ×, Esc): its history entry goes; Places' own layers
    // catch up with what was chosen.
    function pickDone() {
      const l = A.pickL; A.pickL = null;
      if (l && O.layers && O.layers.top() === l) O.layers.pop(1);
      syncLayers();
    }
    dlg.addEventListener('close', pickDone);
    // Typing: the list becomes the ranked results; "No results" when nothing matches.
    function filter(input) {
      const box = input.closest('.pm-pickin'); if (!box) return;
      const t = input.value.trim().toLowerCase(), which = input.dataset.which;
      box.querySelectorAll('[data-quick]').forEach(e => { e.hidden = !!t; });
      const qx = box.querySelector('.pm-qx'); if (qx) qx.hidden = !input.value;
      box.querySelector('[data-list]').hidden = !!t;
      const res = box.querySelector('[data-results]'), none = box.querySelector('[data-none]');
      const hits = t ? ranked(candidates(which), t) : [];
      // With floor plans, in groups (§4.2): My room · Places · Nearest · Schedule · Help; Nearest at most four.
      if (A.plans) {
        const ORDER = ['My room', 'Places', 'Nearest', 'Restrooms', 'Elevators', 'Schedule', 'Help'], by = {};
        hits.forEach(c => { const g = c.grp || (c.kind === 3 ? 'Schedule' : 'Places'); (by[g] = by[g] || []).push(c); });
        // Restrooms and elevators in the list's own order (nearest first, or the marked ones on entrance
        // floors), not by how well "Restroom" matches the words typed.
        ['Nearest', 'Restrooms', 'Elevators'].forEach(g => { if (by[g]) by[g] = by[g].sort((a, b) => a.fi - b.fi).slice(0, 4); });
        // The schedule in time order: today's still to come first, then the days after, then what's past.
        // At most eight, so the soonest are what shows.
        if (by.Schedule) by.Schedule = by.Schedule.sort((a, b) => a.ord[0] - b.ord[0] || (a.ord[1] < b.ord[1] ? -1 : a.ord[1] > b.ord[1] ? 1 : 0) || a.ord[2] - b.ord[2]).slice(0, 8);
        res.innerHTML = ORDER.filter(g => by[g]).map(g => '<li data-sec><p class="pm-k">' + g + '</p></li>' + by[g].map(c => resultRow(which, c)).join('')).join('');
      } else res.innerHTML = hits.map(c => resultRow(which, c)).join('');
      res.hidden = !t || !hits.length; none.hidden = !t || !!hits.length;
    }
    function clearQ(lab) { const q = lab && lab.querySelector('[data-pmq]'); if (!q) return; q.value = ''; filter(q); q.focus(); }
    function onInput(e) { if (e.target.matches('[data-pmq]')) filter(e.target); }
    function onKey(e) {
      if (!e.target.matches('[data-pmq]')) return;
      if (e.key === 'Enter') { e.preventDefault(); const box = e.target.closest('.pm-pickin'), b = box && box.querySelector('[data-results]:not([hidden]) button:not([disabled])'); if (b) b.click(); }
    }
    dlg.addEventListener('input', onInput);
    dlg.addEventListener('keydown', onKey);
    // A choice: shown on the map with its card.
    function choose(b) { openEnd(endFrom(b.dataset.v)); }
    dlg.addEventListener('click', e => {
      if (e.target === dlg || e.target.closest('[data-close]')) { dlg.close(); pickDone(); return; }
      if (e.target.closest('[data-pm="qx"]')) { clearQ(e.target.closest('.pm-q')); return; }
      const b = e.target.closest('[data-pm="set"], [data-pm="room"], [data-pm="list"], [data-pm="spot"]'); if (!b || b.disabled) return;
      dlg.close(); pickDone();
      // From's or To's Search: the choice is that end of the route.
      if (b.dataset.pm === 'set' && (b.dataset.which === 'from' || b.dataset.which === 'to')) { if (b.dataset.v === 'map') chooseOnMap(b.dataset.which); else setEnd(b.dataset.which, routeEnd(b.dataset.v)); return; }
      // A place from Search (§2.8, K4): its heading gets the focus, and closing it gives the focus back to Search.
      const was = A.place;
      if (b.dataset.pm === 'room') focus(b.dataset.code);
      else if (b.dataset.pm === 'list') openList(b.dataset.v);
      else if (b.dataset.pm === 'spot') openSpot(b.dataset.id);
      else choose(b);
      if (A.place && A.place !== was && A.place.kind !== 'dirs') {
        A.opener = A.el.querySelector('.pm-search');
        const h = A.el.querySelector('.pm-body .pm-h, .pm-pbody .pm-h');
        if (h) { h.setAttribute('tabindex', '-1'); h.focus({ preventScroll: true }); }
      }
    });

    function onClick(e) {
      const b = e.target.closest('[data-pm]'); if (!b || !A.el.contains(b) || b.disabled) return;
      const k = b.dataset.pm;
      // Walking (Start): the card, the sheet and the bar. (A swipe that ended on a button isn't a tap.)
      if (k.indexOf('w-') === 0) {
        if (A.swiped && Date.now() - A.swiped < 400) return;
        if (k === 'w-prev' || k === 'w-back') walkGo(-1);
        else if (k === 'w-next' || k === 'w-fwd' || k === 'w-in') walkGo(1);
        else if (k === 'w-recenter') walkRecenter();
        else if (k === 'w-small' || k === 'w-open') walkFold(k === 'w-small');
        else if (k === 'w-step') walkPeekStep(+b.dataset.i);
        else if (k === 'w-end') endWalk();
        else if (k === 'w-done') walkFinish();
        else if (k === 'w-mock' && A.walk) walkSim(!A.walk.sim);
        return;
      }
      if (k === 'search') picker();
      else if (k === 'close') closeLayer();
      // A phone (docs/35 round 1): the lip untucks; ⋯ opens the menu; the building chip opens its building.
      else if (k === 'untuck') tuckSet(false);
      else if (k === 'menu') openMenu();
      else if (k === 'bchip') {
        const o = A.L && A.L.open(), B = o && A.L.building(o.code), p = o && P(o.code);
        if (p) focus(p.code); else if (B && B.item) openBuilding(B.item.name);
      }
      // The planner (§4.5).
      else if (k === 'dirs') { const to = endOfPlace(A.place); if (to) openDirs(to); }
      else if (k === 'dirs-close') closeDirs();
      else if (k === 'end') picker(b.dataset.which);
      else if (k === 'swap' && A.dir && A.dir.from && A.dir.to) { const d = A.dir, f = d.from; d.from = d.to; d.to = f; d.auto = false; paint(); replan(true); }
      // (The open place's door line is drawn again for the new choice: a step-free door, or the nearest.)
      else if (k === 'sf') { LS.set(SF_KEY, !stepFree()); A.destKey = ''; A.destInfo = null; paint(); replan(false); }
      // (i) beside Step-free: what it means, under it, and away again.
      else if (k === 'sf-info') { A.sfInfo = !A.sfInfo; paint(); }
      else if (k === 'start') start();
      // A step tapped: framed on the map without starting; on a phone the sheet comes to half, the step's
      // stretch framed above it (docs/35 §2.5).
      else if (k === 'step' && A.dir) { const i = +b.dataset.i; if (A.mode === 'full') { if (SH && SH.stop !== 'half') SH.set('half', 'ease'); frameStep(i); } else if (A.dir.focus !== i) frameStep(i); }
      // (A row in a building's own list opens over the building; a chip, Search or the plain map's list replaces.)
      else if (k === 'room') focus(b.dataset.code, null, b.closest('.pm-body, .pm-pbody, .pm-panel') ? parentFor(b.dataset.code) : null);
      else if (k === 'spot') openSpot(b.dataset.id);
      else if (k === 'more-today') { A.allToday = true; paint(); }
      else if (k === 'event') { if (A.ctx.openEvent) A.ctx.openEvent(b.dataset.id); }
      else if (k === 'families') { A.place = { kind: 'families' }; settle('half'); paint(); say('For families'); }
      else if (k === 'locate') locate();
      else if (k === 'set') choose(b);
      else if (k === 'list') openList(b.dataset.v);
      else if (k === 'nearest') nearestChip(b.dataset.v);
      // A nearest row's own Directions: the planner straight away (back to the list at its peek).
      else if (k === 'ndirs') { const c = A.place && A.place.kind === 'nearest' && A.place.rows ? A.place.rows[+b.dataset.i] : null; if (c && c.end) openDirs(c.end); }
      else if (k === 'feat') openEnd(endFrom(b.dataset.v));
      else if (k === 'floor') { if (A.L) A.L.show(+b.dataset.fl); }
      else if (k === 'ring' && A.L) {
        // A Nearby row: rung on its floor, and framed with the room if it's out of view.
        const at = [+b.dataset.x, +b.dataset.y], i = A.destInfo;
        A.L.ring(b.dataset.b, +b.dataset.fl, at);
        if (i && i.room) { const r = i.room, x0 = Math.min(r.x, at[0]), y0 = Math.min(r.y, at[1]), bx = { x: x0, y: y0, w: Math.max(r.x + r.w, at[0]) - x0, h: Math.max(r.y + r.h, at[1]) - y0 }; A.map.look(bx.x + bx.w / 2, bx.y + bx.h / 2, Math.min(curScale(), A.L.scaleFor(bx, 40)), true); }
      }
    }
    document.addEventListener('click', e => { if (A.el && !A.hidden && A.el.contains(e.target)) onClick(e); });
    // The floor picker made small (docs/35 §2.2): a tap opens it full, the sheet down to its peek to make room.
    document.addEventListener('click', e => {
      if (!A.el || A.hidden || A.mode !== 'full' || !A.el.classList.contains('is-pkmini') || !e.target.closest || !e.target.closest('.pv-floors')) return;
      e.stopPropagation(); e.preventDefault();
      A.pkOpen = true; A.el.classList.remove('is-pkmini');
      if (SH && SH.stop !== 'peek' && !SH.tucked) SH.set('peek', 'ease');
      const on = A.el.querySelector('.pv-floors button.is-on'); if (on) on.focus({ preventScroll: true });
    }, true);
    // A laptop with floor plans (§5.1): / opens Search; Esc closes the place open in the panel. The planner,
    // anywhere: Esc closes the phone's Steps, then the planner; the arrows move between steps (§9).
    document.addEventListener('keydown', e => {
      if (!A.el || A.hidden || dlg.open || e.defaultPrevented) return;
      // Walking: Esc is End; ← and → are Back and Next (the map keeps its own arrows when it has focus).
      if (A.walk) {
        if (e.key === 'Escape') { e.preventDefault(); endWalk(); }
        else if ((e.key === 'ArrowRight' || e.key === 'ArrowLeft') && !(e.target.closest && e.target.closest('.pv, input, textarea'))) { e.preventDefault(); walkGo(e.key === 'ArrowRight' ? 1 : -1); }
        return;
      }
      const dirs = A.place && A.place.kind === 'dirs' && A.dir;
      if (!A.plans && !dirs) return;
      const typing = e.target && e.target.closest && e.target.closest('input, textarea, select, [contenteditable]');
      // (Focus on the page's main or body counts as inside: a mouse click on the laptop panel's heading
      // leaves focus on main, and Esc then did nothing; the fix pass, round 2.)
      const inside = A.el.contains(e.target === document.body || (e.target && e.target.tagName === 'MAIN' && e.target.contains(A.el)) ? A.el : e.target);
      if (dirs && (e.key === 'ArrowDown' || e.key === 'ArrowUp') && e.target.closest && e.target.closest('.pm-step')) {
        const all = Array.from(A.el.querySelectorAll('.pm-step')), i = all.indexOf(e.target.closest('.pm-step')), n = all[i + (e.key === 'ArrowDown' ? 1 : -1)];
        e.preventDefault(); if (n) { n.focus(); if (A.mode === 'full') frameStep(+n.dataset.i); }
      } else if (e.key === '/' && A.plans && !typing && !e.metaKey && !e.ctrlKey && A.mode !== 'full') { e.preventDefault(); picker(); }
      else if (e.key === 'Escape' && dirs && !typing && inside) { e.preventDefault(); if (A.dir.choosing) { A.dir.choosing = ''; pickEnd(); paint(); } else closeDirs(); }
      else if (e.key === 'Escape' && A.place && A.plans && !typing && inside) closeLayer();
    });
    // A laptop's steps (§5.1, W3): hovering (after 120 ms, so a pass over the list doesn't fly the map)
    // or focusing a step frames its stretch on its floor; leaving the list draws the whole route again.
    let hoverT = 0;
    document.addEventListener('pointerover', e => {
      if (!A.dir || A.hidden || A.mode === 'full' || !A.el || !A.el.contains(e.target) || e.pointerType === 'touch') return;
      const b = e.target.closest('.pm-step'); clearTimeout(hoverT);
      if (b && +b.dataset.i !== A.dir.focus) hoverT = setTimeout(() => frameStep(+b.dataset.i, true), 120);
    });
    document.addEventListener('pointerout', e => {
      if (!A.dir || A.mode === 'full' || !A.el || !e.target.closest || !e.target.closest('.pm-steps')) return;
      if (e.relatedTarget && e.relatedTarget.closest && e.relatedTarget.closest('.pm-steps')) return;
      clearTimeout(hoverT);
      if (A.dir.focus > -1 && !(document.activeElement && document.activeElement.closest && document.activeElement.closest('.pm-step'))) { A.dir.focus = -1; showRoute(false, null); A.el.querySelectorAll('.pm-step.is-on').forEach(x => x.classList.remove('is-on')); }
    });
    document.addEventListener('focusin', e => {
      if (!A.dir || A.hidden || A.mode === 'full' || !A.el || !A.el.contains(e.target)) return;
      const b = e.target.closest('.pm-step'); if (b && +b.dataset.i !== A.dir.focus) { clearTimeout(hoverT); frameStep(+b.dataset.i); }
    });

    const api = {
      mount, hide, focus,
      // A place by its code, a hall ("hall:Reed Hall") or a spot ("spot:<id>"): shown with its card.
      open: v => openEnd(endFrom(String(v))),
      search: () => picker(),
      // Directions to a place (a code, "hall:…", "spot:…", "stay"): its sheet, then the planner over it
      // (week.js's ?to=CODE&dirs=1, and every Directions in the guide's own sheets).
      // room ({ floor, number }; r2c, last round): one of the place's rooms in the build, the place dialog's
      // balcony (?to=J&room=2-220&dirs=1): its card, the route ending there; once the year's plans are read
      // (a room the build doesn't hold for that place: the place itself, as before). card: its card only.
      directions(v, room, card) {
        if (!A.ctx) return;
        if (room && room.number != null && String(v) !== 'stay') {
          whenPlans(() => roomAt(String(v), room).then(r => {
            if (!A.ctx) return;
            if (!r) { if (card) focus(String(v)); else api.directions(v); return; }
            focus(r.code, r);
            const to = card ? null : endOfPlace(A.place);
            if (to) openDirs(to);
          }));
          return;
        }
        if (String(v) === 'stay' && !A.stay && !A.stayIn) { A.wantStay = true; return; }
        openEnd(endFrom(String(v)));
        const to = A.place && A.place.kind !== 'dirs' ? endOfPlace(A.place) : null;
        if (to) openDirs(to);
      },
      // The planner again after what it reads changed (the stay, Step-free; the dev pages' made-up stay).
      redraw() { if (A.dir) { if (A.dir.auto) A.dir.from = fromDefault(); replan(false); } paint(); },
      destroy() { hide(); if (A.el) A.el.remove(); dlg.remove(); },
      get state() { return A; }
    };
    if (window.OGC_WP && OGC_WP.dev) M.devApp = api;
    return api;
  }

  M.app = app;
  // A feature's line icon, for the guide's own sheets (Oct 13).
  M.featureIcon = f => I['f-' + f] || '';
})();
