/*
 * ogc-wp.js — the seam between v3's pages and WordPress. Loaded first on every plugin page, after
 * window.OGC_WP (written by the page: see ogc_client_config() in includes/core-pages.php):
 *
 *   OGC_WP = { rest, nonce, base, page, folder, assets, me: { email, name } | null, member: [years],
 *              webmaster, dev, signin, logout, version }
 *
 * It does three things, so v3's code runs unchanged at the plugin's addresses:
 *   1. Reads of …/schedule/data/years.csv and …/schedule/data/<year>/<name>.csv (how every v3 page
 *      loads a year) are answered from the REST routes. ogc-store.js, once loaded, answers them from
 *      its cache and keeps the rows it was given (OGC_WP.data).
 *   2. Links between pages: v3 links folders relatively ("../register/?year=2027"), which works from
 *      /annual-conference/register/ but not from the Conference page at /annual-conference/ (v3's
 *      schedule-hub/). Every relative link is resolved as v3 would have from the page's v3 folder, and
 *      schedule-hub/ becomes the Conference page (OGC_WP.url()).
 *   3. OGC_WP.api(method, path, body): a REST call with the nonce, the JSON parsed, errors thrown
 *      with .status and .data.
 */
(function () {
  'use strict';
  const W = window.OGC_WP = window.OGC_WP || {};
  const base = W.base || '/annual-conference/';
  const DATA = '/schedule/data/';
  // The address this page had in v3's folders, for resolving its relative links.
  const virtual = location.origin + base + (W.folder || 'schedule-hub') + '/';

  /* ------------------------------------------------------------ REST */

  const open = window.fetch.bind(window);
  // A visitor's read carries no nonce: WordPress refuses a stale one (a cached page, the guide's
  // offline copy, a tab open past a day) even for a public answer. Signed in, or a change: it does.
  const nonceFor = method => (W.me || String(method).toUpperCase() !== 'GET') && W.nonce ? { 'X-WP-Nonce': W.nonce } : {};
  const stale = (res, data) => res.status === 403 && data && data.code === 'rest_cookie_invalid_nonce';
  // A fresh nonce: signed in, from the sign-in page's session check; a visitor, none (reads need none).
  async function freshNonce() {
    if (!W.me) { W.nonce = ''; return; }
    try {
      const r = await open((W.signin || (base + 'signin/')) + '?session=1', { credentials: 'same-origin', cache: 'no-store' });
      const d = await r.json();
      W.nonce = d && d.nonce ? d.nonce : '';
    } catch (e) { /* offline: the retry fails as the first did */ }
  }
  W.freshNonce = freshNonce;
  W.api = async function (method, path, body, again) {
    const init = { method, credentials: 'same-origin', headers: nonceFor(method) };
    if (body !== undefined) { init.headers['Content-Type'] = 'application/json'; init.body = JSON.stringify(body); }
    const res = await open((W.rest || '/wp-json/ogc/v1/') + String(path).replace(/^\//, ''), init);
    if (!again && res.status === 403) {
      const peek = await res.clone().json().catch(() => null);
      if (stale(res, peek)) { await freshNonce(); return W.api(method, path, body, true); }
    }
    // WordPress sends a fresh nonce with a signed-in answer; keep it (a page left open past a day).
    const fresh = res.headers.get('X-WP-Nonce');
    if (fresh) W.nonce = fresh;
    const type = res.headers.get('Content-Type') || '';
    const data = /json/.test(type) ? await res.json().catch(() => null) : await res.text();
    if (!res.ok) {
      const err = new Error((data && data.message) || ('HTTP ' + res.status));
      err.status = res.status; err.data = data;
      throw err;
    }
    return data;
  };

  /* ------------------------------------------------------------ the year's files */

  // The fallback before ogc-store.js is loaded (or on a page without it): the CSV straight from REST.
  W.data = W.data || function (path) {
    const m = /^(\d{4})\/([a-z][a-z0-9_-]*)\.csv$/.exec(path);
    const url = path === 'years.csv' ? 'years?format=csv' : m ? 'years/' + m[1] + '/files/' + m[2] : null;
    if (!url) return Promise.resolve(new Response('', { status: 404 }));
    const get = () => open((W.rest || '/wp-json/ogc/v1/') + url, { credentials: 'same-origin', headers: nonceFor('GET') });
    return get().then(async res => {
      if (res.status !== 403) return res;
      const peek = await res.clone().json().catch(() => null);
      if (!stale(res, peek)) return res;
      await freshNonce();
      return get();
    });
  };
  window.fetch = function (input, init) {
    let u;
    try { u = new URL(String(input && input.url || input), location.href); } catch (e) { return open(input, init); }
    const i = u.pathname.indexOf(DATA), method = String((init && init.method) || (input && input.method) || 'GET').toUpperCase();
    if (u.origin !== location.origin || i < 0 || method !== 'GET') return open(input, init);
    return W.data(decodeURIComponent(u.pathname.slice(i + DATA.length)));
  };

  /* ------------------------------------------------------------ links */

  // "../register/?year=2027" → "/annual-conference/register/?year=2027"; "../schedule-hub/" → the
  // Conference page; "…/index.html" → its folder. Absolute links, "#…" and "?…" are left alone.
  W.url = function (href) {
    href = String(href == null ? '' : href);
    if (!href || /^([a-z][a-z0-9+.-]*:|[/#?])/i.test(href)) return href;
    let u;
    try { u = new URL(href, virtual); } catch (e) { return href; }
    if (u.origin !== location.origin) return href;
    let path = u.pathname.replace(/index\.html$/, '');
    if (path.indexOf(base + 'schedule-hub/') === 0) path = base + path.slice((base + 'schedule-hub/').length);
    return path + u.search + u.hash;
  };
  const fix = a => {
    const h = a.getAttribute('href');
    if (!h || /^([a-z][a-z0-9+.-]*:|[/#?])/i.test(h)) return;
    const to = W.url(h);
    if (to !== h) a.setAttribute('href', to);
  };
  const fixIn = n => { if (n.nodeType !== 1) return; if (n.tagName === 'A') fix(n); n.querySelectorAll('a[href]').forEach(fix); };
  fixIn(document.documentElement);
  new MutationObserver(ms => ms.forEach(m => m.type === 'attributes' ? m.target.tagName === 'A' && fix(m.target) : m.addedNodes.forEach(fixIn)))
    .observe(document.documentElement, { subtree: true, childList: true, attributes: true, attributeFilter: ['href'] });
  // A click on a link drawn and followed at once (before the observer ran) still goes the right way.
  document.addEventListener('click', e => { const a = e.target.closest && e.target.closest('a[href]'); if (a) fix(a); }, true);

  /* ------------------------------------------------------------ "See it", beside the year page */

  // A page framed beside the year page (v3's See it) follows the typing: when a change is saved in
  // this browser (ogc-store.js sets "ogc-saved"), it reloads where it was; pv-at scrolls it to a part
  // the first time. (From v3's proto-nav.js, which doesn't ship.)
  const framed = (() => { try { return window.top !== window; } catch (e) { return true; } })();
  if (framed) {
    document.documentElement.classList.add('ogc-framed');
    const KEY = 'ogc-pv-y:' + location.pathname + location.search;
    const when = (test, then) => { let n = 0; const t = setInterval(() => { const v = test(); if (v || ++n > 40) { clearInterval(t); then(v); } }, 50); };
    try {
      const y = +sessionStorage.getItem(KEY), at = new URLSearchParams(location.search).get('pv-at');
      sessionStorage.removeItem(KEY);
      if (y) when(() => document.documentElement.scrollHeight >= y + innerHeight / 2, () => scrollTo(0, y));
      else if (at) when(() => document.querySelector(at), el => { if (el) el.scrollIntoView({ block: 'start' }); });
    } catch (e) { /* opens at the top */ }
    let timer = 0;
    addEventListener('storage', e => {
      if (e.key !== 'ogc-saved') return;
      clearTimeout(timer);
      timer = setTimeout(() => { try { sessionStorage.setItem(KEY, String(Math.round(scrollY))); } catch (x) { /* opens at the top */ } location.reload(); }, 250);
    });
  }
})();
