/*
 * ogc-feedback-api.js — the feedback board's one seam to its store (Oct 31, 2026). The local site and
 * the shared prototype only (loaded with ogc-dev-nav.js; never on ogbbc.org). Everything the board does
 * with the store goes through window.OGC_FEEDBACK below; if the store moves, only this file changes.
 *
 * Where it goes:
 *   - OGC_WP.feedback set (the OGC_FEEDBACK_URL constant: https://<project>.vercel.app/api/feedback):
 *     every call is a POST of JSON as text/plain (no CORS preflight), and the reply is JSON.
 *   - None set, on the local site: the same calls answered from this browser's localStorage, so the
 *     board can be tried and tested. The local admin key is "local".
 *   - None set, on the shared prototype: OGC_FEEDBACK.mode is '' and the board isn't drawn.
 *
 * The contract (request {action, client, key?, …} → reply {ok: true, …} or {ok: false, error}):
 *   counts                                   → {counts: {screen: open ideas}}
 *   list     {screen: key | '*'}             → {admin, items: [item]}   (open and resolved, newest first)
 *   add      {name, text, screen, title, page, at, moment, as, size, pin: {x, y, label} | null,
 *             image: data URL | ''}         → {item}
 *   comment  {item, name, text}              → {comment}
 *   vote     {item}                          → {votes, voted}           (a toggle, one per browser)
 *   delete   {item} | {comment}              → {}                       (its owner, or an admin)
 *   resolve  {item}, reopen {item}           → {status}                 (an admin)
 *   item:    {id, created (ISO), screen, title, page, at, moment, as, name, text, image, thumb, pin, size,
 *             status: 'open' | 'resolved', mine, votes, voted, comments: [{id, created, name, text, mine}]}
 *            (image and thumb: https addresses; `picture` is taken for either)
 *   errors:  name, text, screen, image, client, not_found, forbidden, slow, busy, bad_request, server;
 *            and here: network (no answer), offline.
 * client is this browser's random id (localStorage ogc-fb-client); the store keeps only a hash of it,
 * and matches a browser's own ideas, replies and votes by it. key is the admin key, typed once on the
 * board (localStorage ogc-fb-admin).
 */
(function () {
  'use strict';
  const W = window.OGC_WP || {};
  if (!W.dev && !W.prototype) return;
  const URL_ = typeof W.feedback === 'string' && /^https:\/\//.test(W.feedback) ? W.feedback : '';
  const mode = URL_ ? 'remote' : (W.dev && !W.prototype ? 'local' : '');

  const LS = {
    get(k, d) { try { const v = localStorage.getItem(k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } },
    set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); return true; } catch (e) { return false; } },
    del(k) { try { localStorage.removeItem(k); } catch (e) { /* nothing kept */ } }
  };

  // This browser's id: 16 random bytes, base64url. Without storage, one for this page only.
  let memId = '';
  function client() {
    let id = LS.get('ogc-fb-client', '');
    if (typeof id === 'string' && /^[A-Za-z0-9_-]{16,64}$/.test(id)) return id;
    const b = new Uint8Array(16);
    try { crypto.getRandomValues(b); } catch (e) { for (let i = 0; i < 16; i++) b[i] = Math.floor(Math.random() * 256); }
    id = btoa(String.fromCharCode.apply(null, b)).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
    if (!LS.set('ogc-fb-client', id)) { memId = memId || id; return memId; }
    return id;
  }
  // The name people leave ideas under, remembered in this browser (the first Feedback button's key too).
  function name() {
    const n = LS.get('ogc-fb-name', null);
    return typeof n === 'string' ? n : String(LS.get('ogc-feedback-name', '') || '');
  }
  const setName = n => { LS.set('ogc-fb-name', String(n || '').trim().slice(0, 60)); };
  const adminKey = () => { const k = LS.get('ogc-fb-admin', ''); return typeof k === 'string' ? k : ''; };
  const setAdminKey = k => { if (k) LS.set('ogc-fb-admin', String(k)); else LS.del('ogc-fb-admin'); };

  const oops = code => Object.assign(new Error(code), { code });

  /* -------------------------------------------------------------- the API, over the network */

  async function remote(action, body) {
    const req = Object.assign({ action, client: client() }, body || {});
    const k = adminKey();
    if (k) req.key = k;
    if (typeof navigator !== 'undefined' && navigator.onLine === false) throw oops('offline');
    const ctl = typeof AbortController === 'function' ? new AbortController() : null;
    const timer = ctl ? setTimeout(() => ctl.abort(), action === 'add' ? 45000 : 20000) : 0;
    let res;
    try {
      res = await fetch(URL_, { method: 'POST', mode: 'cors', credentials: 'omit', cache: 'no-store', redirect: 'follow',
        headers: { 'Content-Type': 'text/plain;charset=utf-8' }, body: JSON.stringify(req), signal: ctl ? ctl.signal : undefined });
    } catch (e) {
      throw oops('network');
    } finally {
      clearTimeout(timer);
    }
    let j = null;
    try { j = await res.json(); } catch (e) { throw oops(res.ok ? 'server' : 'network'); }
    if (!j || j.ok !== true) throw oops((j && typeof j.error === 'string' && j.error) || 'server');
    return j;
  }

  /* -------------------------------------------------------------- the same API, in this browser */

  const DB = 'ogc-fb-local';
  const LOCAL_KEY = 'local';
  const load = () => { const d = LS.get(DB, null); return d && Array.isArray(d.items) ? d : { items: [], comments: [], votes: [] }; };
  const save = d => { if (!LS.set(DB, d)) throw oops('server'); };
  const line = (v, n) => String(v == null ? '' : v).replace(/[\u0000-\u001f\u007f]+/g, ' ').replace(/\s+/g, ' ').trim().slice(0, n).trim();
  const para = (v, n) => String(v == null ? '' : v).replace(/\r\n?/g, '\n').replace(/[\u0000-\u0009\u000b-\u001f\u007f]/g, ' ').replace(/[ \t]+\n/g, '\n').replace(/\n{3,}/g, '\n\n').trim().slice(0, n).trim();
  const keyOk = s => typeof s === 'string' && s.length <= 300 && /^[\w\-./?=&%:+,~]+$/.test(s);
  const newId = () => { const b = new Uint8Array(6); try { crypto.getRandomValues(b); } catch (e) { for (let i = 0; i < 6; i++) b[i] = Math.floor(Math.random() * 256); } return [...b].map(x => x.toString(16).padStart(2, '0')).join(''); };
  const pinOf = p => {
    if (!p || typeof p !== 'object') return null;
    const x = Number(p.x), y = Number(p.y);
    return isFinite(x) && isFinite(y) && x >= 0 && x <= 100 && y >= 0 && y <= 100 ? { x: Math.round(x * 10) / 10, y: Math.round(y * 10) / 10, label: line(p.label, 80) } : null;
  };
  function view(d, r, me) {
    const img = r.image ? LS.get('ogc-fb-local-img-' + r.id, '') : '';
    return {
      id: r.id, created: r.created, screen: r.screen, title: r.title, page: r.page, at: r.at, moment: r.moment, as: r.as,
      name: r.name, text: r.text, image: img || '', thumb: img || '', pin: r.pin, size: r.size, status: r.status, mine: r.owner === me,
      votes: d.votes.filter(v => v.item === r.id).length, voted: d.votes.some(v => v.item === r.id && v.voter === me),
      comments: d.comments.filter(c => c.item === r.id && !c.deleted).sort((a, b) => a.created < b.created ? -1 : 1)
        .map(c => ({ id: c.id, created: c.created, name: c.name, text: c.text, mine: c.owner === me }))
    };
  }
  const found = (d, id) => d.items.find(r => r.id === id && !r.deleted) || null;

  async function local(action, body) {
    body = body || {};
    const me = client(), admin = adminKey() === LOCAL_KEY, d = load();
    switch (action) {
      case 'counts': {
        const counts = {};
        d.items.forEach(r => { if (!r.deleted && r.status !== 'resolved') counts[r.screen] = (counts[r.screen] || 0) + 1; });
        return { ok: true, counts };
      }
      case 'list': {
        const scope = body.screen === '*' ? '*' : (keyOk(body.screen) ? body.screen : '');
        if (!scope) throw oops('screen');
        const items = d.items.filter(r => !r.deleted && (scope === '*' || r.screen === scope)).map(r => view(d, r, me)).sort((a, b) => a.created < b.created ? 1 : -1);
        return { ok: true, admin, items };
      }
      case 'add': {
        const nm = line(body.name, 60), tx = para(body.text, 4000);
        if (!nm) throw oops('name');
        if (!tx) throw oops('text');
        if (!keyOk(body.screen)) throw oops('screen');
        if (body.image && !/^data:image\/(jpeg|png|webp);base64,[A-Za-z0-9+/]+={0,2}$/.test(String(body.image))) throw oops('image');
        const r = {
          id: newId(), created: new Date().toISOString(), screen: body.screen, title: line(body.title, 120),
          page: /^\/\S*$/.test(String(body.page || '')) ? String(body.page).slice(0, 600) : '',
          at: /^\d{4}-\d\d-\d\dT\d\d:\d\d$/.test(String(body.at || '')) ? String(body.at) : '',
          moment: line(body.moment, 80), as: line(body.as, 80), name: nm, text: tx, pin: pinOf(body.pin),
          size: /^\d{2,5}×\d{2,5}$/.test(String(body.size || '')) ? String(body.size) : '', status: 'open', deleted: false, owner: me, image: false
        };
        // A picture in this browser's storage (about 5 MB in all): when it won't fit, the idea goes without it.
        if (body.image) r.image = LS.set('ogc-fb-local-img-' + r.id, String(body.image));
        d.items.push(r);
        save(d);
        return { ok: true, item: view(d, r, me) };
      }
      case 'comment': {
        const r = found(d, body.item);
        if (!r) throw oops('not_found');
        const nm = line(body.name, 60), tx = para(body.text, 2000);
        if (!nm) throw oops('name');
        if (!tx) throw oops('text');
        const c = { id: newId(), created: new Date().toISOString(), item: r.id, name: nm, text: tx, owner: me, deleted: false };
        d.comments.push(c);
        save(d);
        return { ok: true, comment: { id: c.id, created: c.created, name: c.name, text: c.text, mine: true } };
      }
      case 'vote': {
        const r = found(d, body.item);
        if (!r) throw oops('not_found');
        const had = d.votes.some(v => v.item === r.id && v.voter === me);
        d.votes = had ? d.votes.filter(v => !(v.item === r.id && v.voter === me)) : d.votes.concat([{ item: r.id, voter: me }]);
        save(d);
        return { ok: true, votes: d.votes.filter(v => v.item === r.id).length, voted: !had };
      }
      case 'delete': {
        const r = body.item ? found(d, body.item) : body.comment ? d.comments.find(c => c.id === body.comment && !c.deleted) : null;
        if (!r) throw oops(body.item || body.comment ? 'not_found' : 'bad_request');
        if (!admin && r.owner !== me) throw oops('forbidden');
        r.deleted = true;
        if (body.item) LS.del('ogc-fb-local-img-' + r.id);
        save(d);
        return { ok: true };
      }
      case 'resolve':
      case 'reopen': {
        if (!admin) throw oops('forbidden');
        const r = found(d, body.item);
        if (!r) throw oops('not_found');
        r.status = action === 'resolve' ? 'resolved' : 'open';
        save(d);
        return { ok: true, status: r.status };
      }
      default: throw oops('bad_request');
    }
  }

  /* -------------------------------------------------------------- the seam */

  const call = (action, body) => mode === 'remote' ? remote(action, body) : mode === 'local' ? local(action, body) : Promise.reject(oops('offline'));

  // Only addresses that are pictures: https, or a picture kept in this browser.
  const safeImg = u => typeof u === 'string' && (/^https:\/\/[^\s"'<>]+$/.test(u) || /^data:image\/(jpeg|png|webp);base64,/.test(u)) ? u : '';
  const str = v => (v == null ? '' : String(v));
  function item(x) {
    x = x || {};
    const image = safeImg(x.image) || safeImg(x.picture);
    return {
      id: str(x.id), created: str(x.created), screen: str(x.screen), title: str(x.title), page: str(x.page), at: str(x.at),
      moment: str(x.moment), as: str(x.as), name: str(x.name), text: str(x.text), image, thumb: safeImg(x.thumb) || image,
      pin: x.pin && typeof x.pin === 'object' && isFinite(x.pin.x) && isFinite(x.pin.y) ? { x: +x.pin.x, y: +x.pin.y, label: str(x.pin.label) } : null,
      size: str(x.size), status: x.status === 'resolved' ? 'resolved' : 'open', mine: !!x.mine, votes: Math.max(0, +x.votes || 0), voted: !!x.voted,
      comments: (Array.isArray(x.comments) ? x.comments : []).map(comment)
    };
  }
  function comment(c) {
    c = c || {};
    return { id: str(c.id), created: str(c.created), name: str(c.name), text: str(c.text), mine: !!c.mine };
  }

  window.OGC_FEEDBACK = {
    mode,
    client, name, setName, adminKey, setAdminKey,
    counts: () => call('counts').then(j => { const o = {}; Object.keys(j.counts || {}).forEach(k => { const n = +j.counts[k]; if (n > 0) o[k] = n; }); return o; }),
    list: screen => call('list', { screen }).then(j => ({ admin: !!j.admin, items: (j.items || []).map(item) })),
    add: f => call('add', f).then(j => item(j.item)),
    comment: (id, nm, text) => call('comment', { item: id, name: nm, text }).then(j => comment(j.comment)),
    vote: id => call('vote', { item: id }).then(j => ({ votes: Math.max(0, +j.votes || 0), voted: !!j.voted })),
    removeItem: id => call('delete', { item: id }).then(() => true),
    removeComment: id => call('delete', { comment: id }).then(() => true),
    resolve: id => call('resolve', { item: id }).then(j => j.status),
    reopen: id => call('reopen', { item: id }).then(j => j.status),
    // Is this the admin key? Asked with a list; kept only when it is.
    checkAdmin: k => {
      const was = adminKey();
      setAdminKey(k);
      return call('list', { screen: '*' }).then(j => { if (!j.admin) setAdminKey(was); return !!j.admin; }, e => { setAdminKey(was); throw e; });
    }
  };
})();
