/*
 * ogc-dev-nav.js — the local site and the shared prototype only (loaded when OGC_DEV or OGC_PROTOTYPE is
 * true; never on ogbbc.org). Two things, both presentation:
 *
 *   - A thin banner on every page: "Early prototype · made-up people · details still being decided".
 *   - The Tour (Oct 13; it replaces the old "Pages" button): nine scenes in order, each one signing in
 *     the right made-up person and previewing the date that fills its screen. Scene N of 9, a one-line
 *     caption, Back · Next and the list. On the Conference page it also offers "Through the year": the
 *     same page previewed on six days of the coming Conference's year, 2027 (Michael, Oct 13: a
 *     self-guided look, in place of "See as", which the scenes already do; Oct 16: "it should all be 2027
 *     stuff"). It opens itself on the first visit and can be closed.
 *
 * Every address follows OGC_WP.base and OGC_WP.home, because WordPress Playground serves the site under
 * /scope:…/. The dev sign-in and sign-out (core-dev.php) take a return path relative to the site's home.
 *
 * It also styles v3's mockup-only pills (.ogc-mock), which some pages still draw.
 */
(function () {
  'use strict';
  const W = window.OGC_WP || {};
  if (!W.dev && !W.prototype) return;
  // Framed by one of our own pages (the app's "See it" pane): draw nothing there. WordPress Playground also
  // runs the whole site in a frame, but its parent isn't ours, so the Tour and banner still draw.
  const framed = (() => { try { return window.top !== window && !!(window.parent && window.parent.OGC_WP); } catch (e) { return false; } })();
  const base = W.base || '/annual-conference/';
  const home = W.home || '/';
  // The page's path from the site's home ("annual-conference/"), for the dev sign-in's return=.
  const baseRel = base.indexOf(home) === 0 ? base.slice(home.length) : base.replace(/^\//, '');
  const rel = path => '/' + baseRel + path;
  const hereRel = () => { const p = location.pathname; return '/' + (p.indexOf(home) === 0 ? p.slice(home.length) : p.replace(/^\//, '')) + location.search; };
  const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
  const CHEV = d => '<svg viewBox="0 0 24 24" width="22" height="22" aria-hidden="true"><path d="' + d + '" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  const LS = {
    get(k, d) { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch (e) { return d; } },
    set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { /* nothing kept */ } }
  };

  // Made-up people (seed/members.json, the sample households). extra: the dev sign-in's own flags.
  const P = {
    hoover: { email: 'daniel.hoover@example.com', name: 'Daniel H.' },
    adams: { email: 'naomi.adams@example.com', name: 'Naomi A.' },
    coa: { email: 'nathan.keller@example.com', name: 'Nathan K.' },
    lodging: { email: 'joel.marsh@example.com', name: 'Joel M.' },
    web: { email: 'webmaster@example.com', name: 'Webmaster', extra: '&webmaster=1&name=Webmaster' }
  };
  const IN = '&tz=America/Indiana/Indianapolis';
  // The nine scenes. path is relative to the Conference page; who is a key of P, or '' for signed out;
  // when is what the scene previews, said once on the card; after runs once the scene has drawn.
  const SCENES = [
    { title: 'The Conference page', path: '?year=2027&as-of=2027-05-21T09:00' + IN, who: '', when: 'May 21, 2027',
      cap: 'A week before Conference: the schedule, Register and the packet.' },
    { title: 'Registering', path: 'register/?year=2027&as-of=2027-03-02', who: 'hoover', when: 'Mar 2, 2027',
      cap: 'The Hoovers came in 2026 and saved it for next year. Their 2027 form starts filled in.' },
    { title: 'Your sign-ups', path: 'register/?year=2027&view=mine&as-of=2027-04-01', who: 'adams', when: 'Apr 1, 2027',
      cap: 'Everything one household signed up for, in one place.' },
    { title: 'Volunteering', path: 'volunteer/?year=2027&as-of=2027-04-01', who: 'hoover', when: 'Apr 1, 2027',
      cap: 'Committees first, then their shifts. Sign up several people at once.' },
    { title: 'The guide', path: 'guide/?year=2027&as-of=2027-05-29T14:30' + IN + '&to=J', who: '', when: 'Sat, May 29, 2027 · 2:30 PM',
      cap: 'Saturday afternoon on a phone: today, the map, and Directions.' },
    { title: 'Printed schedule', path: 'schedule/?year=2027&as-of=2027-05-21', who: '', when: 'May 21, 2027',
      cap: 'Two pages, printed from the same rows as the Conference page.' },
    { title: 'The COA', path: 'app/?year=2027', who: 'coa', when: '',
      cap: 'Home is what needs the COA next. See as, at the top left, shows the app as any committee sees it.' },
    { title: 'Lodging', path: 'app/?year=2027&s=lod-rooms&as-of=2027-04-15', who: 'lodging', when: 'Apr 15, 2027',
      cap: 'Lodging places each household by hand, hall by hall.' },
    { title: 'Webmasters', path: 'app/?year=2027&s=years', who: 'web', when: '',
      cap: 'Every year, and who can sign in.' }
  ];
  // Through the year: the Conference page signed out, on six days of 2027's year, each just after its
  // part went up in the sample (announced Nov 1, 2026; registration open Feb 25 – May 21; the schedule
  // public Mar 15 and the packet May 11: module-app-seed.php). A year that's over is never previewed.
  const MOMENTS = [['Announced', '2026-11-10T09:00', 'Nov 10, 2026'], ['Registration', '2027-03-02T09:00', 'Mar 2, 2027'],
    ['Schedule out', '2027-03-18T09:00', 'Mar 18, 2027'], ['Week before', '2027-05-21T09:00', 'May 21, 2027'],
    ['During', '2027-05-29T14:30', 'Sat, May 29, 2027 · 2:30 PM'], ['After', '2027-06-10T09:00', 'June 10, 2027']];
  // The local site keeps the old list's other stops (Oct 12: one place to look); the prototype doesn't.
  const MORE = [
    ['The packet', 'packet/?year=2027&as-of=2027-05-21', ''],
    ['Tournaments', 'tournaments/?year=2027', ''],
    ['Food', 'app/?year=2027', 'food'],
    ['Transportation head', 'app/?year=2027', 'transport'],
    ['Mail log', 'mail/', 'web']
  ];
  P.food = { email: 'silas.grant@example.com', name: 'Food' };
  P.transport = { email: 'phoebe.lane@example.com', name: 'Transportation' };

  const meEmail = W.me ? String(W.me.email || '').toLowerCase() : '';
  // The address that lands on a page as that person: straight there when they're already signed in.
  function as(who, path) {
    const p = who ? P[who] : null;
    if (!p && !meEmail) return base + path;
    if (p && meEmail === p.email && (!p.extra || W.webmaster)) return base + path;
    return p ? base + 'dev-signin/?email=' + encodeURIComponent(p.email) + (p.extra || '') + '&return=' + encodeURIComponent(rel(path))
      : base + 'dev-signout/?return=' + encodeURIComponent(rel(path));
  }
  const sceneUrl = i => as(SCENES[i].who, SCENES[i].path);

  // Which scene this page is: same path, and every one of the scene's own parameters (but ?to=, which
  // the guide takes off once it has used it).
  function matchScene() {
    let best = -1, score = -1;
    SCENES.forEach((s, i) => {
      const u = new URL(base + s.path, location.href);
      if (u.pathname.replace(/\/$/, '') !== location.pathname.replace(/\/$/, '')) return;
      const cur = new URLSearchParams(location.search);
      let n = 0, ok = true;
      u.searchParams.forEach((v, k) => { if (k === 'to') return; if (cur.get(k) === v) n++; else ok = false; });
      if (ok && n > score) { best = i; score = n; }
    });
    return best;
  }

  const css =
    // The banner
    '.ogc-pbar{position:relative;z-index:62;margin:0;padding:6px 16px;background:#333;color:#F3F2EB;text-align:center;font:400 12.5px/1.35 var(--ogb-sans,Arial,sans-serif);letter-spacing:.2px}' +
    // The tour
    '.ogc-tour{position:fixed;right:16px;bottom:16px;z-index:61;font-family:var(--ogb-sans,Arial,sans-serif);color:#333}' +
    '.ogc-app .ogc-tour{bottom:calc(62px + 12px + env(safe-area-inset-bottom))}body.has-player .ogc-tour{bottom:96px}body.has-regbar .ogc-tour{bottom:calc(84px + env(safe-area-inset-bottom))}' +
    '.ogc-tour__card{width:340px;max-height:calc(100vh - 96px);overflow:auto;padding:14px 16px 12px;background:#fff;border:1px solid #e6e1d6;border-radius:12px;box-shadow:0 10px 30px rgba(0,0,0,.18)}' +
    '.ogc-tour__top{display:flex;align-items:center;gap:4px;margin:-6px -6px 2px 0}.ogc-tour__top .ogc-tour__k{margin-right:auto}' +
    '.ogc-tour__k{margin:0;color:#76623F;font-size:12px;font-weight:700;letter-spacing:1.2px;text-transform:uppercase}' +
    '.ogc-tour__x{display:inline-flex;align-items:center;justify-content:center;width:44px;height:44px;margin:-8px -8px -8px 0;border:0;border-radius:8px;background:none;color:#555;font-size:22px;line-height:1;cursor:pointer}.ogc-tour__x:hover{background:#F3F2EB}' +
    '.ogc-tour__h{margin:0 0 4px;font:700 20px/1.25 var(--ogb-serif,"Noto Serif","Droid Serif",Georgia,serif);color:#333}' +
    '.ogc-tour__cap{margin:0 0 6px;font-size:14.5px;line-height:1.45;color:#444}' +
    '.ogc-tour__who{margin:0 0 12px;font-size:12.5px;color:#76623F}' +
    // Every tap 44 px (after the eighth critic, Oct 16: "Back to this scene" was 15 px tall).
    '.ogc-tour__off{margin:0 0 10px;font-size:13px;color:#555}.ogc-tour__off a{display:inline-flex;align-items:center;min-height:44px;color:#333}' +
    // No filled button of its own (after the ninth critic, Oct 16: the tan Next was a second filled button on
    // pages that have their primary): Next is outlined, Back plain; it's a mockup control, not the design.
    '.ogc-tour__nav{display:flex;gap:8px}' +
    '.ogc-tour__b{flex:1;box-sizing:border-box;display:inline-flex;align-items:center;justify-content:center;gap:4px;min-height:44px;padding:8px 14px;border:1px solid transparent;border-radius:4px;background:none;color:#333;font:700 12px/1.2 var(--ogb-sans,Arial,sans-serif);letter-spacing:1.2px;text-transform:uppercase;text-decoration:none;cursor:pointer}' +
    '.ogc-tour__b svg{flex:none;width:16px;height:16px;color:#76623F}.ogc-tour__b--next{border-color:#C0AB85;background:#fff}' +
    '.ogc-tour__b:hover{background:#F3F2EB}.ogc-tour__b[aria-disabled=true]{opacity:.4;pointer-events:none}' +
    '.ogc-tour__more{display:inline-flex;align-items:center;gap:4px;min-height:44px;padding:0 8px;border:0;border-radius:8px;background:none;color:#333;font:inherit;font-size:13px;cursor:pointer}.ogc-tour__more:hover{background:#F3F2EB}' +
    '.ogc-tour__more span{font-size:12px;color:#76623F;transition:transform .15s}.ogc-tour__more[aria-expanded=true] span{transform:rotate(180deg)}' +
    '.ogc-tour__list{display:none;margin-top:10px;padding-top:8px;border-top:1px solid #eee}.ogc-tour.is-more .ogc-tour__list{display:block}' +
    '.ogc-tour__list ol,.ogc-tour__list ul{list-style:none;margin:0;padding:0}' +
    '.ogc-tour__list li a{display:flex;align-items:center;gap:10px;min-height:44px;padding:6px 8px;border-radius:6px;color:#333;text-decoration:none;font-size:14px}' +
    '.ogc-tour__list li a:hover{background:#F3F2EB}.ogc-tour__list li a[aria-current]{background:#F3F2EB;font-weight:700}' +
    '.ogc-tour__n{flex:none;width:20px;color:#76623F;font-size:12px;font-weight:700;text-align:right}' +
    '.ogc-tour__lab{margin:12px 0 6px;color:#76623F;font-size:12px;font-weight:700;letter-spacing:1.2px;text-transform:uppercase}' +
    '.ogc-tour__see{display:flex;flex-wrap:wrap;gap:6px}' +
    '.ogc-tour__see a{display:inline-flex;align-items:center;min-height:44px;padding:4px 12px;border:1px solid #d9d2c3;border-radius:999px;color:#333;text-decoration:none;font-size:13px}' +
    '.ogc-tour__see a:hover{border-color:#C0AB85}.ogc-tour__see a[aria-current]{background:#F3F2EB;border-color:#76623F;font-weight:700}' +
    '.ogc-tour__see--year{margin-bottom:12px}' +
    // "Back to this scene" and "Through the year" sit in the card beside the page (a laptop's margin), and
    // under Scenes where the card is compact (a phone, the strip): one copy drawn at a time.
    '.ogc-tour__inlist{display:none}.ogc-tour.is-dock .ogc-tour__inlist{display:block}.ogc-tour.is-dock .ogc-tour__oncard{display:none}' +
    '.ogc-tour__list .ogc-tour__off{margin:0}.ogc-tour__back .ogc-tour__n{font-size:16px;font-weight:400}' +
    '.ogc-tour__list .ogc-tour__lab:first-child{margin-top:4px}.ogc-tour__inlist{margin:0 0 4px;padding-bottom:4px;border-bottom:1px solid #eee}' +
    '.ogc-tour__end{margin:12px 0 0;padding-top:8px;border-top:1px solid #eee}' +
    '.ogc-tour__end button{min-height:44px;padding:0;border:0;background:none;color:#555;font:inherit;font-size:13px;text-decoration:underline;cursor:pointer}' +
    '.ogc-tour__pill{display:none;min-height:44px;padding:8px 16px;border:1px solid #C0AB85;border-radius:999px;background:#fff;color:#333;font:700 12px/1.2 var(--ogb-sans,Arial,sans-serif);letter-spacing:1.2px;text-transform:uppercase;cursor:pointer;box-shadow:0 4px 14px rgba(0,0,0,.15)}' +
    '.ogc-tour.is-closed .ogc-tour__card{display:none}.ogc-tour.is-closed .ogc-tour__pill{display:inline-flex;align-items:center;gap:8px}' +
    '.ogc-tour a:focus-visible,.ogc-tour button:focus-visible{outline:2px solid #76623F;outline-offset:2px}' +
    // On a phone the card is two lines (after the ninth critic, Oct 16: four, 179 px of a 390 screen): the
    // scene's number and title with ‹ › Scenes and × (the fold to the pill), then its caption on one line,
    // whole under Scenes. The title wraps inside the first line's 44 px, never cut (after the seventh critic).
    '@media (max-width:600px){.ogc-tour{left:8px;right:8px;bottom:8px}.ogc-app .ogc-tour{bottom:calc(62px + 8px + env(safe-area-inset-bottom))}.ogc-tour.is-closed{left:auto}' +
    '.ogc-tour__card{width:auto;max-height:calc(100vh - 120px);padding:2px 4px 8px 10px}.ogc-tour__inlist{display:block}.ogc-tour__oncard{display:none}' +
    '.ogc-tour__row{display:flex;align-items:center;gap:0 2px}.ogc-tour__row .ogc-tour__k{flex:none;margin:0 6px 0 0;letter-spacing:.6px}' +
    '.ogc-tour__row .ogc-tour__h{flex:1 1 auto;min-width:0;margin:0;font-size:15px;line-height:1.2}' +
    '.ogc-tour__card > .ogc-tour__top,.ogc-tour__card > .ogc-tour__h,.ogc-tour__card > .ogc-tour__nav,.ogc-tour__who{display:none}' +
    '.ogc-tour__card > .ogc-tour__cap{margin:0;padding-right:8px;font-size:13.5px;line-height:1.4;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.ogc-tour.is-more .ogc-tour__card > .ogc-tour__cap{margin-bottom:6px;white-space:normal}' +
    '.ogc-tour__ic{flex:none;box-sizing:border-box;display:inline-flex;align-items:center;justify-content:center;width:44px;height:44px;border:1px solid transparent;border-radius:8px;background:none;color:#333;font-size:20px;line-height:1;text-decoration:none;cursor:pointer}.ogc-tour__ic:hover{background:#F3F2EB}' +
    '.ogc-tour__ic--next{border-color:#C0AB85;background:#fff}.ogc-tour__ic[aria-disabled=true]{opacity:.35;pointer-events:none}' +
    '.ogc-tour__row .ogc-tour__more{flex:none;padding:0 6px}.ogc-tour__row .ogc-tour__x{flex:none;margin:0;width:44px}' +
    // In the strip the strip is the card (no box inside it), as on a laptop.
    '.ogc-tour.is-dock:not(.is-closed){padding:2px 8px calc(6px + env(safe-area-inset-bottom))}.ogc-tour.is-dock .ogc-tour__card{border:0;border-radius:0;background:none;padding:0 0 0 4px}}' +
    // A narrow phone: Scenes without its arrow, then (under 340) the title on a line of its own, never cut.
    '@media (max-width:374px){.ogc-tour__row{gap:0}.ogc-tour__row .ogc-tour__k{margin-right:4px}.ogc-tour__row .ogc-tour__more span{display:none}}' +
    '@media (max-width:339px){.ogc-tour__row{flex-wrap:wrap}.ogc-tour__row .ogc-tour__k{margin-right:auto}.ogc-tour__row .ogc-tour__h{order:9;flex:0 0 100%;margin:0 0 2px}}' +
    '@media (min-width:601px){.ogc-tour__row{display:none}}' +
    // At rest the pill moves up off whatever it would cover (a Sign up, a count, a phone number).
    '.ogc-tour.is-closed{transform:translateY(calc(-1 * var(--ogc-tour-lift, 0px)))}@media (prefers-reduced-motion:no-preference){.ogc-tour.is-closed{transition:transform .18s ease-out}}' +
    '@media (prefers-reduced-motion:reduce){.ogc-tour__more span{transition:none}}' +
    // While the pill is shown, what the page or the keyboard brings into view stops above it (after the
    // fourth critic, Oct 15: it sat over a row's open count and Sign up at 390).
    'html:has(.ogc-tour.is-closed){scroll-padding-bottom:76px}' +
    // The dock (after the seventh critic, Oct 15: the pill sat over a phone number, a count and a card's
    // corner; the open card over a grid cell's count): a strip the page reserves at the foot of the screen,
    // the pill or the card in it, never over the page. A spacer at the end of the page keeps its last line
    // above the strip, and the page's own toasts rise over it.
    '.ogc-tour.is-dock,.ogc-tour.is-dock.is-closed{left:0;right:0;bottom:var(--ogc-tour-above,0px)!important;padding:6px 12px calc(6px + env(safe-area-inset-bottom));background:#F3F2EB;border-top:1px solid #e6e1d6;transform:none!important;transition:none!important}' +
    '.ogc-tour.is-dock.is-above:not(.is-closed){padding-bottom:6px}.ogc-tour.is-dock.is-closed{display:flex;justify-content:flex-end;align-items:center}.ogc-tour.is-dock .ogc-tour__pill{box-shadow:none}.ogc-tour.is-dock .ogc-tour__card{box-shadow:none}' +
    '.ogc-tour-spacer{height:var(--ogc-tour-dock,0px)}html.ogc-tour-docked{scroll-padding-bottom:calc(var(--ogc-tour-dock,0px) + var(--ogc-tour-above,0px) + 8px)}' +
    'html.ogc-tour-docked :is(.vol-toast,.rf-toast,.ap-toast,.lst-toast,.tn-toast,.yr-toast,.lod-toast,.ed-toast,.pp-toast){margin-bottom:var(--ogc-tour-dock,0px)}' +
    // The app's columns a screen tall (its sidebar, a record's panel) end above the strip too (after the
    // eighth critic, Oct 16: docked on Helpers at 1440, the strip sat over the sidebar's Sign out).
    '@media (min-width:1024px){html.ogc-tour-docked .ap-side{height:calc(100dvh - var(--ogc-tour-dock,0px))}html.ogc-tour-docked body:has(> .ogc-pbar) .ap-side{height:calc(100dvh - 30px - var(--ogc-tour-dock,0px))}}' +
    'html.ogc-tour-docked .ap-panel{max-height:calc(100dvh - var(--ap-head) - 16px - var(--ogc-tour-dock,0px))}' +
    // A laptop's open card as a strip, where the page's margin can't hold it: two lines (after the ninth
    // critic, Oct 16: four, 131 px over the grid): "Tour · 1 of 9" and the title, then the caption on one
    // line (whole in its tooltip); Back · Next, Scenes (opening above) and × on the right.
    '@media (min-width:601px){.ogc-tour.is-dock:not(.is-closed){padding:6px 16px}.ogc-tour.is-dock:not(.is-closed) .ogc-tour__card{width:auto;max-width:1120px;margin:0 auto;max-height:none;overflow:visible;padding:0 0 0 4px;display:grid;grid-template-columns:auto minmax(0,1fr) auto auto auto;column-gap:12px;row-gap:0;align-items:center;border:0;border-radius:0;background:none}' +
    '.ogc-tour.is-dock .ogc-tour__top{display:contents}.ogc-tour.is-dock .ogc-tour__top .ogc-tour__k{grid-column:1;grid-row:1;align-self:baseline;margin:0}' +
    '.ogc-tour.is-dock .ogc-tour__card > .ogc-tour__h{grid-column:2;grid-row:1;align-self:baseline;min-width:0;margin:0;font-size:17px;line-height:1.3;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}' +
    '.ogc-tour.is-dock .ogc-tour__card > .ogc-tour__cap{grid-column:1/3;grid-row:2;min-width:0;margin:0;font-size:14px;line-height:1.4;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.ogc-tour.is-dock .ogc-tour__who{display:none}' +
    '.ogc-tour.is-dock .ogc-tour__nav{grid-column:3;grid-row:1/3}.ogc-tour.is-dock .ogc-tour__b{flex:none;min-width:96px}' +
    '.ogc-tour.is-dock .ogc-tour__top .ogc-tour__more{grid-column:4;grid-row:1/3}.ogc-tour.is-dock .ogc-tour__top .ogc-tour__x{grid-column:5;grid-row:1/3;margin:0}' +
    '.ogc-tour.is-dock .ogc-tour__list{position:absolute;right:16px;bottom:calc(100% + 8px);width:340px;max-height:60vh;overflow:auto;margin:0;padding:8px 12px;background:#fff;border:1px solid #e6e1d6;border-radius:12px;box-shadow:0 10px 30px rgba(0,0,0,.18)}' +
    '.ogc-tour.is-dock .ogc-tour__lab{margin:4px 0 6px}.ogc-tour.is-dock .ogc-tour__see--year{margin-bottom:8px}.ogc-tour__capfull{margin:2px 0 0;padding:0 0 4px;font-size:14px;line-height:1.45;color:#444}}' +
    '.ogc-tour:not(.is-dock.is-cut) .ogc-tour__capfull{display:none}' +
    // A narrow laptop or a tablet: Back and Next as their arrows, so the title keeps its room.
    '@media (min-width:601px) and (max-width:899px){.ogc-tour.is-dock .ogc-tour__b{min-width:44px;padding:8px 10px}.ogc-tour.is-dock .ogc-tour__b span{display:none}}' +
    // At rest beside the page, it may move left as well as up to a clear spot.
    '.ogc-tour.is-closed:not(.is-dock){transform:translate(calc(-1 * var(--ogc-tour-shift, 0px)),calc(-1 * var(--ogc-tour-lift, 0px)))}' +
    // v3's mockup-only pills
    '.ogc-mock{display:inline-flex;align-items:center;min-height:44px;padding:6px 14px;border:0;border-radius:999px;background:#1f1f1f;color:#e8c98f;font:700 12px/1.2 var(--ogb-sans,Arial,sans-serif);letter-spacing:.4px;cursor:pointer;text-decoration:none}' +
    '.ogc-mock:hover{background:#333}.ogc-mock:focus-visible{outline:2px solid #76623F;outline-offset:2px}' +
    '.ogc-mock--tag{min-height:0;padding:3px 10px;font-size:11px;cursor:default}.ogc-mock--tag:hover{background:#1f1f1f}' +
    '@media print{.ogc-pbar,.ogc-tour,.ogc-tour-spacer,.ogc-mock{display:none!important}}';

  function banner() {
    if (document.querySelector('.ogc-pbar')) return;
    const b = document.createElement('p');
    b.className = 'ogc-pbar';
    b.setAttribute('role', 'note');
    b.textContent = 'Early prototype · made-up people · details still being decided';
    document.body.insertBefore(b, document.body.firstChild);
  }

  function tour() {
    if (!W.dev) return; // the scenes sign people in, which only the dev sign-in can do
    // It opens itself on the first visit to the shared prototype; on the local site it starts as the pill
    // (as the old Pages button did), and ?pages=1 opens it.
    const st = LS.get('ogc-tour', null) || { i: 0, open: !!W.prototype };
    const m = matchScene();
    if (m > -1) st.i = m;
    // The card folds back to the pill when the page changes by anything but the tour itself (after the
    // sixth critic, Oct 15: opened once, it stayed open on every page, over a row's Sign up at 390 and the
    // week's Tuesday at 1440). The tour's own Back, Next and Scenes keep it open on the scene they open.
    const here = location.pathname + location.search;
    const byTour = st.go && Date.now() - st.go.at < 30000;
    if (st.open && st.page && st.page !== here && !byTour) st.open = false;
    if (new URLSearchParams(location.search).get('pages') === '1') st.open = true;
    if (st.open) st.page = here;
    st.i = Math.max(0, Math.min(SCENES.length - 1, +st.i || 0));
    LS.set('ogc-tour', st);
    const el = document.createElement('div');
    el.className = 'ogc-tour' + (st.open ? '' : ' is-closed');
    document.body.appendChild(el);

    const go = i => { const s = LS.get('ogc-tour', st); s.i = i; s.go = { i, at: Date.now() }; LS.set('ogc-tour', s); location.href = sceneUrl(i); };
    // On the Conference page itself (not the guide, the forms or the app).
    const onConf = location.pathname.replace(/\/$/, '') === new URL(base, location.href).pathname.replace(/\/$/, '');
    const asOfNow = (new URLSearchParams(location.search).get('as-of') || '').slice(0, 16);
    const momentUrl = x => as('', '?year=2027&as-of=' + x[1] + IN);
    function draw() {
      const s = SCENES[st.i], n = SCENES.length, more = el.classList.contains('is-more');
      const who = s.who ? P[s.who].name : 'Signed out';
      const back = st.i > 0 ? esc(sceneUrl(st.i - 1)) : '#', last = st.i === n - 1, next = last ? 0 : st.i + 1;
      const dis = st.i > 0 ? '' : ' aria-disabled="true" tabindex="-1"';
      // Drawn twice, one at a time: in the card beside the page, or under Scenes where the card is compact.
      const off = m !== st.i ? '<p class="ogc-tour__off"><a href="' + esc(sceneUrl(st.i)) + '" data-go="' + st.i + '">Back to this scene</a></p>' : '';
      const offRow = m !== st.i ? '<ul class="ogc-tour__off"><li><a href="' + esc(sceneUrl(st.i)) + '" data-go="' + st.i + '" class="ogc-tour__back"><span class="ogc-tour__n" aria-hidden="true">‹</span>Back to this scene</a></li></ul>' : '';
      const year = onConf ? '<p class="ogc-tour__lab">Through the year</p><div class="ogc-tour__see ogc-tour__see--year">' + MOMENTS.map(x =>
        '<a href="' + esc(momentUrl(x)) + '" title="' + esc(x[2]) + '"' + (asOfNow === x[1] ? ' aria-current="true"' : '') + '>' + esc(x[0]) + '</a>').join('') + '</div>' : '';
      const both = (cls, h) => h ? '<div class="' + cls + '">' + h + '</div>' : '';
      el.innerHTML =
        '<section class="ogc-tour__card" aria-label="Tour">' +
        // The phone's first line: the scene, its arrows, Scenes, the fold.
        '<div class="ogc-tour__row"><p class="ogc-tour__k">' + (st.i + 1) + '/' + n + '</p><h2 class="ogc-tour__h">' + esc(s.title) + '</h2>' +
        '<a class="ogc-tour__ic" href="' + back + '" data-go="' + (st.i - 1) + '" aria-label="Back"' + dis + '>' + CHEV('M14.5 5.5 8 12l6.5 6.5') + '</a>' +
        '<a class="ogc-tour__ic ogc-tour__ic--next" href="' + esc(sceneUrl(next)) + '" data-go="' + next + '" aria-label="' + (last ? 'Start again' : 'Next') + '">' + CHEV('M9.5 5.5 16 12l-6.5 6.5') + '</a>' +
        '<button type="button" class="ogc-tour__more" data-t="more" aria-expanded="' + more + '" title="Every scene">Scenes<span aria-hidden="true">▾</span></button>' +
        '<button type="button" class="ogc-tour__x" data-t="close" aria-label="Fold the tour" title="Fold">×</button></div>' +
        '<div class="ogc-tour__top"><p class="ogc-tour__k">Tour · ' + (st.i + 1) + ' of ' + n + '</p>' +
        '<button type="button" class="ogc-tour__more" data-t="more" aria-expanded="' + more + '" title="Every scene">Scenes<span aria-hidden="true">▾</span></button>' +
        '<button type="button" class="ogc-tour__x" data-t="close" aria-label="Close the tour" title="Close">×</button></div>' +
        '<h2 class="ogc-tour__h">' + esc(s.title) + '</h2>' +
        '<p class="ogc-tour__cap" title="' + esc(s.cap) + '">' + esc(s.cap) + '</p>' +
        '<p class="ogc-tour__who">' + esc(who + (s.when ? ' · ' + s.when : '')) + '</p>' +
        both('ogc-tour__oncard', year) + both('ogc-tour__oncard', off) +
        '<div class="ogc-tour__nav">' +
        '<a class="ogc-tour__b" href="' + back + '" data-go="' + (st.i - 1) + '" aria-label="Back"' + dis + '>' + CHEV('M14.5 5.5 8 12l6.5 6.5') + '<span>Back</span></a>' +
        '<a class="ogc-tour__b ogc-tour__b--next" href="' + esc(sceneUrl(next)) + '" data-go="' + next + '" aria-label="' + (last ? 'Start again' : 'Next') + '"><span>' + (last ? 'Start again' : 'Next') + '</span>' + CHEV('M9.5 5.5 16 12l-6.5 6.5') + '</a>' +
        '</div>' +
        '<div class="ogc-tour__list">' + '<p class="ogc-tour__capfull ogc-tour__inlist">' + esc(s.cap) + '</p>' + both('ogc-tour__inlist', offRow) + both('ogc-tour__inlist', year) +
        '<ol>' + SCENES.map((x, i) => '<li><a href="' + esc(sceneUrl(i)) + '" data-go="' + i + '"' + (i === m ? ' aria-current="page"' : '') + '><span class="ogc-tour__n">' + (i + 1) + '</span>' + esc(x.title) + '</a></li>').join('') + '</ol>' +
        (W.prototype ? '' : '<p class="ogc-tour__lab">More pages</p><ul>' + MORE.map(x => '<li><a href="' + esc(as(x[2], x[1])) + '">' + esc(x[0]) + '</a></li>').join('') + '</ul>') +
        '<p class="ogc-tour__end"><button type="button" data-t="over">Start over</button></p></div>' +
        '</section>' +
        '<button type="button" class="ogc-tour__pill" data-t="open" aria-label="Open the tour">Tour · ' + (st.i + 1) + '/' + n + '</button>';
    }
    draw();
    // At rest, the pill never sits over a Sign up, a count or a phone number (after the fifth critic, Oct
    // 15): when scrolling stops (or the page redraws), it rises to the first free band above its place,
    // up to 45% of the screen. Beside a fixed bar of the page's own (Your week), it stays in the bar.
    const AVOID = 'button, a[href], input, select, textarea, [role="button"], [role="switch"], .vo-open, .vo-names, .cm-filled__n, .cm-chip, .rf-on';
    // And never over words (after the sixth critic, Oct 15: at 390 it sat on "Signed up before? Sign
    // in"): the lines of text themselves, measured, not the blocks they're in.
    const SKIP = '.ogc-pbar, dialog, .vol-toast, .vo-pbar, [hidden], [aria-hidden="true"], script, style, noscript';
    function wordRects(win) {
      const out = [], rg = document.createRange();
      const tw = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, { acceptNode: n => n.nodeValue.trim() && !el.contains(n) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT });
      let n;
      while ((n = tw.nextNode())) {
        const p = n.parentElement;
        if (!p || p.closest(SKIP)) continue;
        const pr = p.getBoundingClientRect();
        if (!pr.width || pr.bottom < win.top || pr.top > win.bottom || pr.right < win.left || pr.left > win.right) continue;
        if (getComputedStyle(p).visibility === 'hidden') continue;
        rg.selectNodeContents(n);
        for (const b of rg.getClientRects()) if (b.width && b.height && b.right > win.left && b.left < win.right && b.bottom > win.top && b.top < win.bottom) out.push(b);
      }
      return out;
    }
    // stuck: on a laptop, once the pill found no clear spot it stays in the strip until the window changes
    // size (a strip coming and going as the page scrolls would be motion that explains nothing).
    let placing = 0, spacer = null, rightEdge = null, stuck = false;
    const PHONE = matchMedia('(max-width:600px)');
    // A bar of the page's own at the foot of the screen (Your week's, the form's, the guide's tabs): the tour
    // keeps to it (in it or above it, as before) and doesn't dock. Toasts and dialogs aren't bars.
    function pageBar() {
      const de = document.documentElement, b = document.body;
      if (de.classList.contains('ogc-app') || b.classList.contains('has-vo-pbar') || b.classList.contains('has-regbar') || b.classList.contains('has-player')) return true;
      return [0.3, 0.7].some(fx => (document.elementsFromPoint ? document.elementsFromPoint(innerWidth * fx, innerHeight - 3) : []).some(e => {
        if (el.contains(e) || (spacer && spacer === e) || e === document.body || e === de) return false;
        for (let x = e; x && x !== b; x = x.parentElement) { const cs = getComputedStyle(x); if (cs.position === 'fixed') return !/toast/.test(String(x.className)) && x.tagName !== 'DIALOG' && x.getBoundingClientRect().width >= innerWidth * 0.8; }
        return false;
      }));
    }
    // The top of that bar (the guide's tabs, Your week's), measured; the screen's foot when there's none.
    function barTop() {
      let top = innerHeight;
      [0.3, 0.7].forEach(fx => (document.elementsFromPoint ? document.elementsFromPoint(innerWidth * fx, innerHeight - 3) : []).forEach(e => {
        if (el.contains(e) || (spacer && spacer === e) || e === document.body || e === document.documentElement) return;
        for (let x = e; x && x !== document.body; x = x.parentElement) {
          const cs = getComputedStyle(x);
          if (cs.position !== 'fixed') continue;
          const b = x.getBoundingClientRect();
          if (!/toast/.test(String(x.className)) && x.tagName !== 'DIALOG' && b.width >= innerWidth * 0.4 && b.bottom >= innerHeight - 4 && b.top > innerHeight * 0.5) top = Math.min(top, b.top);
          break;
        }
      }));
      return top;
    }
    // above: the strip sits on the page's own bar, the page reserving the strip as well as its bar (Oct 16,
    // with the ninth critic's item: the open card still floated over the guide's list at 390 and 1100).
    function setDock(on, above) {
      const de = document.documentElement, up = on && above > 0 ? Math.round(above) + 'px' : '';
      el.classList.toggle('is-dock', on);
      de.classList.toggle('ogc-tour-docked', on);
      el.classList.toggle('is-above', !!up);
      if (up) { el.style.setProperty('--ogc-tour-above', up); de.style.setProperty('--ogc-tour-above', up); } else { el.style.removeProperty('--ogc-tour-above'); de.style.removeProperty('--ogc-tour-above'); }
      if (on) {
        if (!spacer) { spacer = document.createElement('div'); spacer.className = 'ogc-tour-spacer'; spacer.setAttribute('aria-hidden', 'true'); }
        if (spacer.parentNode !== document.body) document.body.appendChild(spacer);
        const hgt = Math.ceil(el.getBoundingClientRect().height);
        if (de.style.getPropertyValue('--ogc-tour-dock') !== hgt + 'px') de.style.setProperty('--ogc-tour-dock', hgt + 'px');
        el.style.removeProperty('--ogc-tour-lift'); el.style.removeProperty('--ogc-tour-shift');
      } else {
        if (spacer && spacer.parentNode) spacer.remove();
        de.style.removeProperty('--ogc-tour-dock');
      }
    }
    // How far right the page's own content reaches (measured once a size: the page's column): its words
    // and controls, and its boxes too (a card, a panel, a list's rows: anything drawn with a background, an
    // edge or a shadow; after the eighth critic, Oct 16: the pill rested over a grid card's empty corner at
    // 1100 and over Helpers' panel at 1440). Bands the screen's width (a header, the footer) aren't a column.
    function contentRight() {
      if (rightEdge != null) return rightEdge;
      let r = 0;
      const skip = x => el.contains(x) || (spacer && x === spacer) || !!x.closest('.ogc-pbar, dialog, .vol-toast, .vo-pbar, [hidden]');
      document.querySelectorAll(AVOID).forEach(x => { if (skip(x)) return; const b = x.getClientRects().length ? x.getBoundingClientRect() : null; if (b && b.width && b.height && b.width < innerWidth * 0.98) r = Math.max(r, b.right); });
      wordRects({ left: 0, right: innerWidth, top: -1e6, bottom: 1e6 }).forEach(b => { r = Math.max(r, b.right); });
      document.querySelectorAll('body *').forEach(x => {
        const b = x.getBoundingClientRect();
        if (!b.width || !b.height || b.right <= r || b.width >= innerWidth * 0.98 || skip(x)) return;
        const cs = getComputedStyle(x);
        if (cs.position === 'fixed' || cs.visibility === 'hidden') return;
        const bg = cs.backgroundColor, drawn = (bg && bg !== 'transparent' && !/rgba\([^)]*,\s*0\)$/.test(bg)) || parseFloat(cs.borderRightWidth) > 0 || parseFloat(cs.borderTopWidth) > 0 || cs.boxShadow !== 'none' || /^(IMG|svg|VIDEO|CANVAS|IFRAME)$/i.test(x.tagName);
        if (drawn) r = Math.max(r, b.right);
      });
      return (rightEdge = r);
    }
    // The strip's caption cut short (one line): its whole text shows under Scenes too.
    const markCut = () => { const c = el.querySelector('.ogc-tour__card > .ogc-tour__cap'); el.classList.toggle('is-cut', !!c && el.classList.contains('is-dock') && !PHONE.matches && c.scrollWidth > c.clientWidth + 1); };
    function place() { placeAt(); markCut(); }
    function placeAt() {
      placing = 0;
      const open = !el.classList.contains('is-closed'), bar = pageBar();
      // The open card is the strip the page reserves (on a page with a bar of its own, just above that bar),
      // but on a laptop whose margin holds the whole card beside the column. On a phone the pill sits in the
      // strip too, but where the page has a bar: it keeps to that bar, as before. On a laptop the pill finds
      // a clear spot, else it docks.
      if (open) { setDock(PHONE.matches || innerWidth - contentRight() < 372, bar ? innerHeight - barTop() : 0); return; }
      if (PHONE.matches) { setDock(!bar); return; }
      if (document.body.classList.contains('has-vo-pbar')) { setDock(false); el.style.removeProperty('--ogc-tour-lift'); el.style.removeProperty('--ogc-tour-shift'); return; }
      if (stuck) { setDock(true); return; }
      // On a laptop the pill is in the page's margin, beside the column, or in the strip: never over the
      // page's content (after the eighth critic, Oct 16: a clear spot by words alone still put it over a
      // grid card at 1100 and over Helpers' list and panel at 1440). Where the page has a bar of its own
      // (the guide's tabs) it keeps to it, as before.
      if (!bar) {
        el.classList.remove('is-dock');
        const pr = el.querySelector('.ogc-tour__pill').getBoundingClientRect();
        el.style.removeProperty('--ogc-tour-lift'); el.style.removeProperty('--ogc-tour-shift');
        const fits = pr.width && innerWidth - 16 - pr.width - 12 >= contentRight();
        if (!fits) stuck = true;
        setDock(!fits);
        return;
      }
      // Measured where it would rest beside the page (the strip, if it's in it, stays until decided).
      el.classList.remove('is-dock');
      const pill = el.querySelector('.ogc-tour__pill');
      const lift0 = parseFloat(getComputedStyle(el).getPropertyValue('--ogc-tour-lift')) || 0, shift0 = parseFloat(getComputedStyle(el).getPropertyValue('--ogc-tour-shift')) || 0;
      const r = pill.getBoundingClientRect();
      if (!r.width) { setDock(false); return; }
      // Where it rests unmoved, and how far it may go: up 45% of the screen, left to the screen's edge.
      const top0 = r.top + lift0, bot0 = r.bottom + lift0, left0 = r.left + shift0, right0 = r.right + shift0, room = innerHeight * 0.45, wide = left0 - 8;
      const win = { left: 0, right: right0, top: top0 - room - 8, bottom: bot0 };
      const hits = Array.from(document.querySelectorAll(AVOID)).filter(x => !el.contains(x) && !x.closest('.ogc-pbar, dialog, .vol-toast, .vo-pbar') && x.getClientRects().length).map(x => x.getBoundingClientRect())
        .filter(b => b.width && b.height && b.right > win.left && b.left < win.right && b.bottom > win.top && b.top < win.bottom)
        .concat(wordRects(win));
      const cover = (l, rt, t, bt) => hits.reduce((k, b) => k + Math.max(0, Math.min(b.bottom, bt) - Math.max(b.top, t)) * Math.max(0, Math.min(b.right, rt) - Math.max(b.left, l)), 0);
      // The nearest clear spot (a small move first: up counts as much as left).
      let best = null;
      for (let lift = 0; lift <= room; lift += 4) {
        for (let sh = 0; sh <= wide; sh += 8) {
          if (best && lift + sh >= best.d) break;
          if (!cover(left0 - sh - 4, right0 - sh + 4, top0 - lift - 4, bot0 - lift + 4)) { best = { lift, sh, d: lift + sh }; break; }
        }
      }
      // None near: the strip at the foot of the screen.
      if (!best) { stuck = true; setDock(true); return; }
      setDock(false);
      if (best.lift) el.style.setProperty('--ogc-tour-lift', best.lift + 'px'); else el.style.removeProperty('--ogc-tour-lift');
      if (best.sh) el.style.setProperty('--ogc-tour-shift', best.sh + 'px'); else el.style.removeProperty('--ogc-tour-shift');
    }
    // At rest: when scrolling stops (a debounce). A page drawing itself places it within 160 ms, however
    // long the drawing goes on (after the seventh critic, Oct 15: it sat over a phone number for 2.5 s
    // while the head's list loaded).
    const placeSoon = () => { clearTimeout(placing); placing = setTimeout(place, 160); };
    const placeAtMost = () => { if (!placing) placing = setTimeout(place, 160); };
    addEventListener('scroll', placeSoon, { passive: true });
    addEventListener('resize', () => { rightEdge = null; stuck = false; placeSoon(); });
    const ours = x => el.contains(x.target) || (x.type === 'childList' && [...x.addedNodes, ...x.removedNodes].length > 0 && [...x.addedNodes, ...x.removedNodes].every(n => n === spacer));
    try { new MutationObserver(m => { if (m.some(x => !ours(x))) { rightEdge = null; placeAtMost(); } }).observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ['class', 'hidden'] }); } catch (e) { /* the pill stays where it is */ }
    place();
    placeSoon();
    el.addEventListener('click', e => {
      const a = e.target.closest('[data-go]');
      if (a) { const i = +a.dataset.go; if (i >= 0 && i < SCENES.length) { e.preventDefault(); go(i); } return; }
      const t = e.target.closest('[data-t]');
      if (!t) return;
      const k = t.dataset.t;
      if (k === 'close' || k === 'open') {
        st.open = k === 'open'; const s = LS.get('ogc-tour', st); s.open = st.open; s.page = location.pathname + location.search; LS.set('ogc-tour', s);
        el.classList.toggle('is-closed', !st.open);
        placeSoon();
        const f = el.querySelector(st.open ? (PHONE.matches ? '.ogc-tour__row .ogc-tour__x' : '.ogc-tour__top .ogc-tour__x') : '.ogc-tour__pill'); if (f) f.focus();
      } else if (k === 'more') {
        el.classList.toggle('is-more'); draw(); placeSoon();
        const b = el.querySelector(PHONE.matches ? '.ogc-tour__row [data-t=more]' : '.ogc-tour__top [data-t=more]'); if (b) b.focus();
      } else if (k === 'over') {
        try { Object.keys(localStorage).filter(x => /^ogc/.test(x)).forEach(x => localStorage.removeItem(x)); } catch (x) { /* nothing kept */ }
        const done = () => { location.href = sceneUrl(0); };
        if (!W.prototype && W.webmaster && W.api) W.api('POST', 'dev/import', { force: true }).then(done, done); else done();
      }
    });
    // Using the page (a button, a link, a field) folds the card too: what it opens is never under it.
    document.addEventListener('click', e => {
      if (!st.open || el.contains(e.target) || !e.target.closest || !e.target.closest(AVOID)) return;
      st.open = false; const s = LS.get('ogc-tour', st); s.open = false; LS.set('ogc-tour', s);
      el.classList.remove('is-more'); el.classList.add('is-closed'); placeSoon();
    }, true);
    document.addEventListener('keydown', e => {
      if (e.key === 'Escape' && el.classList.contains('is-more')) { el.classList.remove('is-more'); draw(); placeSoon(); const b = el.querySelector(PHONE.matches ? '.ogc-tour__row [data-t=more]' : '.ogc-tour__top [data-t=more]'); if (b) b.focus(); }
    });

    // Arrived from the tour: the scene's one extra step (the guide's walk needs a start on campus).
    // (The guide may reload itself once as its offline copy starts, so the step is kept until it's done.)
    const arrived = st.go && st.go.i === m && Date.now() - st.go.at < 30000;
    const done = () => { const s = LS.get('ogc-tour', st); delete s.go; LS.set('ogc-tour', s); };
    if (st.go && !arrived) done();
    if (arrived) {
      const from = /^from:(.+)$/.exec(SCENES[m].after || '');
      if (!from) done();
      if (from) {
        // The guide opens the route with its start to choose: choose the hall, as a visitor would.
        // The map draws in steps, so the choice is made again until the walk shows (at most 20 s).
        const t0 = Date.now();
        let last = 0;
        const t = setInterval(() => {
          const set = document.querySelector('.pm-f[data-which="from"] code');
          if ((set && set.textContent === from[1] && document.querySelector('.pm-answer')) || Date.now() - t0 > 20000) { clearInterval(t); done(); return; }
          const b = document.querySelector('[data-pm="set"][data-which="from"][data-v="' + from[1] + '"]');
          if (b && Date.now() - last > 1200) { last = Date.now(); b.click(); }
        }, 300);
      }
    }
  }

  function build() {
    const style = document.createElement('style');
    style.textContent = css;
    document.head.appendChild(style);
    if (framed) return;
    banner();
    tour();
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', build); else build();
})();
