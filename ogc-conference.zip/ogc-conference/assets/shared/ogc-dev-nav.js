/*
 * ogc-dev-nav.js — the local site and the shared prototype only (loaded when OGC_DEV or OGC_PROTOTYPE is
 * true; never on ogbbc.org). Two things, both presentation:
 *
 *   - A thin banner on every page: "Early prototype · made-up people · details still being decided".
 *   - The Tour (Oct 13; it replaces the old "Pages" button): nine scenes in order, each one signing in
 *     the right made-up person and previewing the date that fills its screen. Scene N of 9, a one-line
 *     caption, Back · Next and the list. On the Conference page it also offers "Through the year": the
 *     same page previewed on six days of 2026 (Michael, Oct 13: a self-guided look, in place of "See as",
 *     which the scenes already do). It opens itself on the first visit and can be closed.
 *
 * Every address follows OGC_WP.base and OGC_WP.home, because WordPress Playground serves the site under
 * /scope:…/. The dev sign-in and sign-out (core-dev.php) take a return path relative to the site's home.
 *
 * It also styles v3's mockup-only pills (.ogc-mock), which some pages still draw.
 */
(function () {
  'use strict';
  const W = window.OGC_WP || {};
  if (!W.dev && !W.prototype) return;
  // Framed by one of our own pages (the app's "See it" pane): draw nothing there. WordPress Playground also
  // runs the whole site in a frame, but its parent isn't ours, so the Tour and banner still draw.
  const framed = (() => { try { return window.top !== window && !!(window.parent && window.parent.OGC_WP); } catch (e) { return false; } })();
  const base = W.base || '/annual-conference/';
  const home = W.home || '/';
  // The page's path from the site's home ("annual-conference/"), for the dev sign-in's return=.
  const baseRel = base.indexOf(home) === 0 ? base.slice(home.length) : base.replace(/^\//, '');
  const rel = path => '/' + baseRel + path;
  const hereRel = () => { const p = location.pathname; return '/' + (p.indexOf(home) === 0 ? p.slice(home.length) : p.replace(/^\//, '')) + location.search; };
  const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
  const LS = {
    get(k, d) { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch (e) { return d; } },
    set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { /* nothing kept */ } }
  };

  // Made-up people (seed/members.json, the sample households). extra: the dev sign-in's own flags.
  const P = {
    hoover: { email: 'daniel.hoover@example.com', name: 'Daniel H.' },
    adams: { email: 'naomi.adams@example.com', name: 'Naomi A.' },
    coa: { email: 'nathan.keller@example.com', name: 'Nathan K.' },
    lodging: { email: 'joel.marsh@example.com', name: 'Joel M.' },
    web: { email: 'webmaster@example.com', name: 'Webmaster', extra: '&webmaster=1&name=Webmaster' }
  };
  const IN = '&tz=America/Indiana/Indianapolis';
  // The nine scenes. path is relative to the Conference page; who is a key of P, or '' for signed out;
  // when is what the scene previews, said once on the card; after runs once the scene has drawn.
  const SCENES = [
    { title: 'The Conference page', path: '?year=2026&as-of=2026-05-29T09:00' + IN, who: '', when: 'May 29, 2026',
      cap: 'A week before Conference: the schedule, Register and the packet.' },
    { title: 'Registering', path: 'register/?year=2027&as-of=2027-03-02', who: 'hoover', when: 'Mar 2, 2027',
      cap: 'The Hoovers came in 2026 and saved it for next year. Their 2027 form starts filled in.' },
    { title: 'Your sign-ups', path: 'register/?year=2027&view=mine&as-of=2027-04-01', who: 'adams', when: 'Apr 1, 2027',
      cap: 'Everything one household signed up for, in one place.' },
    { title: 'Volunteering', path: 'volunteer/?year=2027&as-of=2027-04-01', who: 'hoover', when: 'Apr 1, 2027',
      cap: 'Committees first, then their shifts. Sign up several people at once.' },
    { title: 'The guide', path: 'guide/?year=2026&as-of=2026-06-06T14:30' + IN + '&to=J', who: '', when: 'Sat, June 6, 2026 · 2:30 PM',
      cap: 'Saturday afternoon on a phone: today, the map, and Directions.' },
    { title: 'Printed schedule', path: 'schedule/?year=2026', who: '', when: '',
      cap: 'Two pages, printed from the same rows as the Conference page.' },
    { title: 'The COA', path: 'app/?year=2027', who: 'coa', when: '',
      cap: 'Home is what needs the COA next. Committees is every committee’s board.' },
    { title: 'Lodging', path: 'app/?year=2027&s=lod-rooms&as-of=2027-04-15', who: 'lodging', when: 'Apr 15, 2027',
      cap: 'Lodging places each household by hand, hall by hall.' },
    { title: 'Webmasters', path: 'app/?year=2027&s=years', who: 'web', when: '',
      cap: 'Every year, and who can sign in.' }
  ];
  // Through the year: the Conference page signed out, on six days of 2026 (the last year with everything
  // posted: the announcement, registration, the schedule and packet, the week, the recordings).
  const MOMENTS = [['Announced', '2025-11-10T09:00', 'Nov 10, 2025'], ['Registration', '2026-03-10T09:00', 'Mar 10, 2026'],
    ['Schedule out', '2026-05-20T09:00', 'May 20, 2026'], ['Week before', '2026-05-29T09:00', 'May 29, 2026'],
    ['During', '2026-06-06T14:30', 'Sat, June 6, 2026 · 2:30 PM'], ['After', '2026-06-20T09:00', 'June 20, 2026']];
  // The local site keeps the old list's other stops (Oct 12: one place to look); the prototype doesn't.
  const MORE = [
    ['The packet', 'packet/?year=2026', ''],
    ['Tournaments', 'tournaments/?year=2027', ''],
    ['Food', 'app/?year=2027', 'food'],
    ['Transportation head', 'app/?year=2027', 'transport'],
    ['Mail log', 'mail/', 'web']
  ];
  P.food = { email: 'silas.grant@example.com', name: 'Food' };
  P.transport = { email: 'phoebe.lane@example.com', name: 'Transportation' };

  const meEmail = W.me ? String(W.me.email || '').toLowerCase() : '';
  // The address that lands on a page as that person: straight there when they're already signed in.
  function as(who, path) {
    const p = who ? P[who] : null;
    if (!p && !meEmail) return base + path;
    if (p && meEmail === p.email && (!p.extra || W.webmaster)) return base + path;
    return p ? base + 'dev-signin/?email=' + encodeURIComponent(p.email) + (p.extra || '') + '&return=' + encodeURIComponent(rel(path))
      : base + 'dev-signout/?return=' + encodeURIComponent(rel(path));
  }
  const sceneUrl = i => as(SCENES[i].who, SCENES[i].path);

  // Which scene this page is: same path, and every one of the scene's own parameters (but ?to=, which
  // the guide takes off once it has used it).
  function matchScene() {
    let best = -1, score = -1;
    SCENES.forEach((s, i) => {
      const u = new URL(base + s.path, location.href);
      if (u.pathname.replace(/\/$/, '') !== location.pathname.replace(/\/$/, '')) return;
      const cur = new URLSearchParams(location.search);
      let n = 0, ok = true;
      u.searchParams.forEach((v, k) => { if (k === 'to') return; if (cur.get(k) === v) n++; else ok = false; });
      if (ok && n > score) { best = i; score = n; }
    });
    return best;
  }

  const css =
    // The banner
    '.ogc-pbar{position:relative;z-index:62;margin:0;padding:6px 16px;background:#333;color:#F3F2EB;text-align:center;font:400 12.5px/1.35 var(--ogb-sans,Arial,sans-serif);letter-spacing:.2px}' +
    // The tour
    '.ogc-tour{position:fixed;right:16px;bottom:16px;z-index:61;font-family:var(--ogb-sans,Arial,sans-serif);color:#333}' +
    '.ogc-app .ogc-tour{bottom:calc(62px + 12px + env(safe-area-inset-bottom))}body.has-player .ogc-tour{bottom:96px}body.has-regbar .ogc-tour{bottom:calc(84px + env(safe-area-inset-bottom))}' +
    '.ogc-tour__card{width:340px;max-height:calc(100vh - 96px);overflow:auto;padding:14px 16px 12px;background:#fff;border:1px solid #e6e1d6;border-radius:12px;box-shadow:0 10px 30px rgba(0,0,0,.18)}' +
    '.ogc-tour__top{display:flex;align-items:center;gap:4px;margin:-6px -6px 2px 0}.ogc-tour__top .ogc-tour__k{margin-right:auto}' +
    '.ogc-tour__k{margin:0;color:#76623F;font-size:12px;font-weight:700;letter-spacing:1.2px;text-transform:uppercase}' +
    '.ogc-tour__x{display:inline-flex;align-items:center;justify-content:center;width:44px;height:44px;margin:-8px -8px -8px 0;border:0;border-radius:8px;background:none;color:#555;font-size:22px;line-height:1;cursor:pointer}.ogc-tour__x:hover{background:#F3F2EB}' +
    '.ogc-tour__h{margin:0 0 4px;font:700 20px/1.25 var(--ogb-serif,"Noto Serif","Droid Serif",Georgia,serif);color:#333}' +
    '.ogc-tour__cap{margin:0 0 6px;font-size:14.5px;line-height:1.45;color:#444}' +
    '.ogc-tour__who{margin:0 0 12px;font-size:12.5px;color:#76623F}' +
    '.ogc-tour__off{margin:0 0 10px;font-size:13px;color:#555}.ogc-tour__off a{color:#333}' +
    '.ogc-tour__nav{display:flex;gap:8px}' +
    '.ogc-tour__b{flex:1;display:inline-flex;align-items:center;justify-content:center;min-height:44px;padding:8px 14px;border:1px solid #C0AB85;border-radius:4px;background:#fff;color:#333;font:700 12px/1.2 var(--ogb-sans,Arial,sans-serif);letter-spacing:1.2px;text-transform:uppercase;text-decoration:none;cursor:pointer}' +
    '.ogc-tour__b--fill{background:#C0AB85;border-color:#C0AB85}.ogc-tour__b:hover{filter:brightness(.97)}.ogc-tour__b[aria-disabled=true]{opacity:.4;pointer-events:none}' +
    '.ogc-tour__more{display:inline-flex;align-items:center;gap:4px;min-height:44px;padding:0 8px;border:0;border-radius:8px;background:none;color:#333;font:inherit;font-size:13px;cursor:pointer}.ogc-tour__more:hover{background:#F3F2EB}' +
    '.ogc-tour__more span{font-size:11px;color:#76623F;transition:transform .15s}.ogc-tour__more[aria-expanded=true] span{transform:rotate(180deg)}' +
    '.ogc-tour__list{display:none;margin-top:10px;padding-top:8px;border-top:1px solid #eee}.ogc-tour.is-more .ogc-tour__list{display:block}' +
    '.ogc-tour__list ol,.ogc-tour__list ul{list-style:none;margin:0;padding:0}' +
    '.ogc-tour__list li a{display:flex;align-items:center;gap:10px;min-height:40px;padding:6px 8px;border-radius:6px;color:#333;text-decoration:none;font-size:14px}' +
    '.ogc-tour__list li a:hover{background:#F3F2EB}.ogc-tour__list li a[aria-current]{background:#F3F2EB;font-weight:700}' +
    '.ogc-tour__n{flex:none;width:20px;color:#76623F;font-size:12px;font-weight:700;text-align:right}' +
    '.ogc-tour__lab{margin:12px 0 6px;color:#76623F;font-size:12px;font-weight:700;letter-spacing:1.2px;text-transform:uppercase}' +
    '.ogc-tour__see{display:flex;flex-wrap:wrap;gap:6px}' +
    '.ogc-tour__see a{display:inline-flex;align-items:center;min-height:36px;padding:4px 12px;border:1px solid #d9d2c3;border-radius:999px;color:#333;text-decoration:none;font-size:13px}' +
    '.ogc-tour__see a:hover{border-color:#C0AB85}.ogc-tour__see a[aria-current]{background:#333;border-color:#333;color:#fff}' +
    '.ogc-tour__see--year{margin-bottom:12px}' +
    '.ogc-tour__end{margin:12px 0 0;padding-top:8px;border-top:1px solid #eee}' +
    '.ogc-tour__end button{min-height:40px;padding:0;border:0;background:none;color:#555;font:inherit;font-size:13px;text-decoration:underline;cursor:pointer}' +
    '.ogc-tour__pill{display:none;min-height:44px;padding:8px 16px;border:1px solid #C0AB85;border-radius:999px;background:#fff;color:#333;font:700 12px/1.2 var(--ogb-sans,Arial,sans-serif);letter-spacing:1.2px;text-transform:uppercase;cursor:pointer;box-shadow:0 4px 14px rgba(0,0,0,.15)}' +
    '.ogc-tour.is-closed .ogc-tour__card{display:none}.ogc-tour.is-closed .ogc-tour__pill{display:inline-flex;align-items:center;gap:8px}' +
    '.ogc-tour a:focus-visible,.ogc-tour button:focus-visible{outline:2px solid #76623F;outline-offset:2px}' +
    '@media (max-width:600px){.ogc-tour{left:8px;right:8px;bottom:8px}.ogc-app .ogc-tour{bottom:calc(62px + 8px + env(safe-area-inset-bottom))}.ogc-tour__card{width:auto;max-height:calc(100vh - 140px);padding:10px 14px 12px}.ogc-tour.is-closed{left:auto}.ogc-tour__h{font-size:17px;margin-bottom:2px}.ogc-tour__cap{margin-bottom:10px;font-size:14px}.ogc-tour__who{display:none}}' +
    '@media (prefers-reduced-motion:reduce){.ogc-tour__more span{transition:none}}' +
    // v3's mockup-only pills
    '.ogc-mock{display:inline-flex;align-items:center;min-height:44px;padding:6px 14px;border:0;border-radius:999px;background:#1f1f1f;color:#e8c98f;font:700 12px/1.2 var(--ogb-sans,Arial,sans-serif);letter-spacing:.4px;cursor:pointer;text-decoration:none}' +
    '.ogc-mock:hover{background:#333}.ogc-mock:focus-visible{outline:2px solid #76623F;outline-offset:2px}' +
    '.ogc-mock--tag{min-height:0;padding:3px 10px;font-size:11px;cursor:default}.ogc-mock--tag:hover{background:#1f1f1f}' +
    '@media print{.ogc-pbar,.ogc-tour,.ogc-mock{display:none!important}}';

  function banner() {
    if (document.querySelector('.ogc-pbar')) return;
    const b = document.createElement('p');
    b.className = 'ogc-pbar';
    b.setAttribute('role', 'note');
    b.textContent = 'Early prototype · made-up people · details still being decided';
    document.body.insertBefore(b, document.body.firstChild);
  }

  function tour() {
    if (!W.dev) return; // the scenes sign people in, which only the dev sign-in can do
    // It opens itself on the first visit to the shared prototype; on the local site it starts as the pill
    // (as the old Pages button did), and ?pages=1 opens it.
    const st = LS.get('ogc-tour', null) || { i: 0, open: !!W.prototype };
    const m = matchScene();
    if (m > -1) st.i = m;
    if (new URLSearchParams(location.search).get('pages') === '1') st.open = true;
    st.i = Math.max(0, Math.min(SCENES.length - 1, +st.i || 0));
    LS.set('ogc-tour', st);
    const el = document.createElement('div');
    el.className = 'ogc-tour' + (st.open ? '' : ' is-closed');
    document.body.appendChild(el);

    const go = i => { const s = LS.get('ogc-tour', st); s.i = i; s.go = { i, at: Date.now() }; LS.set('ogc-tour', s); location.href = sceneUrl(i); };
    // On the Conference page itself (not the guide, the forms or the app).
    const onConf = location.pathname.replace(/\/$/, '') === new URL(base, location.href).pathname.replace(/\/$/, '');
    const asOfNow = (new URLSearchParams(location.search).get('as-of') || '').slice(0, 16);
    const momentUrl = x => as('', '?year=2026&as-of=' + x[1] + IN);
    function draw() {
      const s = SCENES[st.i], n = SCENES.length, more = el.classList.contains('is-more');
      const who = s.who ? P[s.who].name : 'Signed out';
      el.innerHTML =
        '<section class="ogc-tour__card" aria-label="Tour">' +
        '<div class="ogc-tour__top"><p class="ogc-tour__k">Tour · ' + (st.i + 1) + ' of ' + n + '</p>' +
        '<button type="button" class="ogc-tour__more" data-t="more" aria-expanded="' + more + '" title="Every scene">Scenes<span aria-hidden="true">▾</span></button>' +
        '<button type="button" class="ogc-tour__x" data-t="close" aria-label="Close the tour" title="Close">×</button></div>' +
        '<h2 class="ogc-tour__h">' + esc(s.title) + '</h2>' +
        '<p class="ogc-tour__cap">' + esc(s.cap) + '</p>' +
        '<p class="ogc-tour__who">' + esc(who + (s.when ? ' · ' + s.when : '')) + '</p>' +
        (onConf ? '<p class="ogc-tour__lab">Through the year</p><div class="ogc-tour__see ogc-tour__see--year">' + MOMENTS.map(x =>
          '<a href="' + esc(momentUrl(x)) + '" title="' + esc(x[2]) + '"' + (asOfNow === x[1] ? ' aria-current="true"' : '') + '>' + esc(x[0]) + '</a>').join('') + '</div>' : '') +
        (m !== st.i ? '<p class="ogc-tour__off"><a href="' + esc(sceneUrl(st.i)) + '" data-go="' + st.i + '">Back to this scene</a></p>' : '') +
        '<div class="ogc-tour__nav">' +
        '<a class="ogc-tour__b" href="' + (st.i > 0 ? esc(sceneUrl(st.i - 1)) : '#') + '" data-go="' + (st.i - 1) + '"' + (st.i > 0 ? '' : ' aria-disabled="true" tabindex="-1"') + '>Back</a>' +
        (st.i < n - 1 ? '<a class="ogc-tour__b ogc-tour__b--fill" href="' + esc(sceneUrl(st.i + 1)) + '" data-go="' + (st.i + 1) + '">Next</a>'
          : '<a class="ogc-tour__b ogc-tour__b--fill" href="' + esc(sceneUrl(0)) + '" data-go="0">Start again</a>') +
        '</div>' +
        '<div class="ogc-tour__list"><ol>' + SCENES.map((x, i) => '<li><a href="' + esc(sceneUrl(i)) + '" data-go="' + i + '"' + (i === m ? ' aria-current="page"' : '') + '><span class="ogc-tour__n">' + (i + 1) + '</span>' + esc(x.title) + '</a></li>').join('') + '</ol>' +
        (W.prototype ? '' : '<p class="ogc-tour__lab">More pages</p><ul>' + MORE.map(x => '<li><a href="' + esc(as(x[2], x[1])) + '">' + esc(x[0]) + '</a></li>').join('') + '</ul>') +
        '<p class="ogc-tour__end"><button type="button" data-t="over">Start over</button></p></div>' +
        '</section>' +
        '<button type="button" class="ogc-tour__pill" data-t="open" aria-label="Open the tour">Tour · ' + (st.i + 1) + '/' + n + '</button>';
    }
    draw();
    el.addEventListener('click', e => {
      const a = e.target.closest('[data-go]');
      if (a) { const i = +a.dataset.go; if (i >= 0 && i < SCENES.length) { e.preventDefault(); go(i); } return; }
      const t = e.target.closest('[data-t]');
      if (!t) return;
      const k = t.dataset.t;
      if (k === 'close' || k === 'open') {
        st.open = k === 'open'; const s = LS.get('ogc-tour', st); s.open = st.open; LS.set('ogc-tour', s);
        el.classList.toggle('is-closed', !st.open);
        const f = el.querySelector(st.open ? '.ogc-tour__x' : '.ogc-tour__pill'); if (f) f.focus();
      } else if (k === 'more') {
        el.classList.toggle('is-more'); draw();
        const b = el.querySelector('[data-t=more]'); if (b) b.focus();
      } else if (k === 'over') {
        try { Object.keys(localStorage).filter(x => /^ogc/.test(x)).forEach(x => localStorage.removeItem(x)); } catch (x) { /* nothing kept */ }
        const done = () => { location.href = sceneUrl(0); };
        if (!W.prototype && W.webmaster && W.api) W.api('POST', 'dev/import', { force: true }).then(done, done); else done();
      }
    });
    document.addEventListener('keydown', e => {
      if (e.key === 'Escape' && el.classList.contains('is-more')) { el.classList.remove('is-more'); draw(); const b = el.querySelector('[data-t=more]'); if (b) b.focus(); }
    });

    // Arrived from the tour: the scene's one extra step (the guide's walk needs a start on campus).
    // (The guide may reload itself once as its offline copy starts, so the step is kept until it's done.)
    const arrived = st.go && st.go.i === m && Date.now() - st.go.at < 30000;
    const done = () => { const s = LS.get('ogc-tour', st); delete s.go; LS.set('ogc-tour', s); };
    if (st.go && !arrived) done();
    if (arrived) {
      const from = /^from:(.+)$/.exec(SCENES[m].after || '');
      if (!from) done();
      if (from) {
        // The guide opens the route with its start to choose: choose the hall, as a visitor would.
        // The map draws in steps, so the choice is made again until the walk shows (at most 20 s).
        const t0 = Date.now();
        let last = 0;
        const t = setInterval(() => {
          const set = document.querySelector('.pm-f[data-which="from"] code');
          if ((set && set.textContent === from[1] && document.querySelector('.pm-answer')) || Date.now() - t0 > 20000) { clearInterval(t); done(); return; }
          const b = document.querySelector('[data-pm="set"][data-which="from"][data-v="' + from[1] + '"]');
          if (b && Date.now() - last > 1200) { last = Date.now(); b.click(); }
        }, 300);
      }
    }
  }

  function build() {
    const style = document.createElement('style');
    style.textContent = css;
    document.head.appendChild(style);
    if (framed) return;
    banner();
    tour();
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', build); else build();
})();
