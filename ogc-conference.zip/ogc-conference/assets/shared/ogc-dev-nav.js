/*
 * ogc-dev-nav.js — the local site and the shared prototype only (loaded when OGC_DEV or OGC_PROTOTYPE is
 * true; never on ogbbc.org). All presentation:
 *
 *   - A thin banner on every page: "Demo · made-up people" (Oct 28, for the COA: Caleb, "don't call it
 *     just an early version").
 *   - The dock (Oct 31; it holds the demo pill of Oct 29 and the feedback board's buttons as one unit). A
 *     small near-black capsule in the bottom right corner, in the demo's own look (the system font, one
 *     white for the one action), never the church site's tan, cream or serif, so no one takes it for part of the site
 *     (Michael: "make it clear that it's not part of the interface… we don't want it to just blend in").
 *       Its left part is the demo pill (Oct 29, in place of the Tour; Michael: "a selector that toggles
 *     between the different time periods… and a way to toggle to the back end", "just a little hover pill
 *     that then expands into each different option"). Since Nov 4 (Michael: three things, each only where it
 *     applies) it says where you are, with the day where the day changes the page ("Conference page · Mar 2")
 *     or who on the committees' side ("Committees' side · COA"). Hovered (it closes a moment after the
 *     pointer leaves), tapped or focused, it opens short groups above it, each choice one click: Go to
 *     (Conference page, Register, Volunteer, Tournaments, Conference app, Committees' side), on every page; Day (six
 *     days of the coming Conference's year, 2027) only on the Conference page, its packet and printed
 *     schedule, and the guide; Signed in as (COA, Lodging, Webmaster) only on the committees' side. Every
 *     other page shows May 10, 2027, when every sign-up is open (core-dev.php). The local site adds Today to
 *     Day, and a third group, More.
 *       When keeps the day for the whole site, every page and its reads, as people click around
 *     (/dev-moment/ and ogc_dev_moment in core-dev.php); nothing chosen, the prototype shows Registration.
 *     As signs that made-up person in, or signs out, always through the dev sign-in (whoever was signed
 *     in before, by a code or otherwise, is signed out first), keeps the day, and lands on their page.
 *       Its right part (.ogc-pill__fb) is ogc-feedback.js's: Leave feedback, and this screen's count.
 *       Minimize (Nov 5, Michael): a small four-dot tab on the dock's top edge folds it into a 44 px circle
 *     in the same corner, and the circle opens it again; kept in this browser (minimize()).
 *     The dock rises above a bar the page keeps at the foot of the screen (the form's, Your week's, the
 *     guide's tabs, the player, a toast) and above a control in a panel that stays put (the app's record
 *     panel's Save), so it never covers one.
 *   - In the shared prototype only, links that would leave the laptop (a phone number, a text, an email,
 *     Google Maps) show a small dark note instead (Oct 28 rehearsal: on a Mac paired with an iPhone, Help's
 *     "Call 911" places a real call), as the old mockups did.
 *
 * window.OGC_DOCK (for ogc-feedback.js): { el, slot, root, host(), modals(), scope(css), busy, moment: {name,
 * at, text}, who, travel(page, at, as), lift() }, and the event "ogc-dock" on document once it's drawn.
 * Every element of ours carries data-ogc-tool, which the feedback screenshot leaves out.
 *
 * Over a pop-up (Oct 31, a bug Caleb found: Leave feedback closed the sheet it was about). The site's
 * sheets are <dialog>s opened with showModal(): while one is open, everything outside it is inert and
 * under it, so a press on the dock landed on the sheet's backdrop and closed it. So everything of ours
 * lives in one root (#ogc-tools: the dock, and the board's composer, board, toast, picture and Point to
 * it layer). With no pop-up open it sits at the end of <body> and draws no box of its own. When a modal
 * dialog opens, it moves into the topmost one (the newest open), as a manual popover in the top layer
 * (above the dialog, and placed against the screen even while the dialog has a transform: its slide-in, a
 * phone's half snap), and goes back when that closes; a page that redraws its dialog's insides takes it
 * out, and it goes straight back. Watched (the dialogs' `open`), never polled. The root also keeps our
 * presses, keys and typing from the page's own listeners (a sheet's `e.target === sheet`, a menu that
 * closes on a press outside it, a page's shortcut keys), and an Escape that closes something of ours
 * never closes the sheet under it. Our CSS is scoped to #ogc-tools, so a sheet's own rules (`.ogc
 * :is(a, button):focus-visible`, `.lod-dlg p`) never restyle it.
 *
 * Every address follows OGC_WP.base and OGC_WP.home, because WordPress Playground serves the site under
 * /scope:…/. The dev sign-in, sign-out and moment (core-dev.php) take a return path relative to the
 * site's home.
 *
 * It also styles v3's mockup-only pills (.ogc-mock), which some pages still draw.
 */
(function () {
  'use strict';
  const W = window.OGC_WP || {};
  if (!W.dev && !W.prototype) return;
  // Framed by one of our own pages (the app's "See it" pane): draw nothing there. WordPress Playground also
  // runs the whole site in a frame, but its parent isn't ours, so the pill and banner still draw.
  const framed = (() => { try { return window.top !== window && !!(window.parent && window.parent.OGC_WP); } catch (e) { return false; } })();
  const base = W.base || '/annual-conference/';
  const home = W.home || '/';
  // The page's path from the site's home ("annual-conference/"), for the dev routes' return=.
  const baseRel = base.indexOf(home) === 0 ? base.slice(home.length) : base.replace(/^\//, '');
  const rel = path => '/' + baseRel + path;
  const enc = encodeURIComponent;
  const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
  const LS = {
    get(k, d) { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch (e) { return d; } },
    set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { /* nothing kept */ } }
  };
  const TZ = (W.moment && W.moment.tz) || 'America/Indiana/Indianapolis';

  // Made-up people (seed/members.json). extra: the dev sign-in's own flags.
  const P = {
    coa: { email: 'nathan.keller@example.com', name: 'Nathan K.' },
    lodging: { email: 'joel.marsh@example.com', name: 'Joel M.' },
    web: { email: 'webmaster@example.com', name: 'Webmaster', extra: '&webmaster=1&name=Webmaster' },
    food: { email: 'silas.grant@example.com', name: 'Food' },
    transport: { email: 'phoebe.lane@example.com', name: 'Transportation' }
  };
  // When: six days of 2027's year, each just after its part went up in the sample (announced Nov 1, 2026;
  // registration open Feb 25 – May 21; the schedule public Mar 15 and the packet May 11: module-app-seed.php),
  // and During at 2:30 PM on the Saturday, at the venue. [name, at, the pill's short date, the date in full]
  const MOMENTS = [['Announced', '2026-11-10T09:00', 'Nov 10', 'Nov 10, 2026'], ['Registration', '2027-03-02T09:00', 'Mar 2', 'Mar 2, 2027'],
    ['Schedule out', '2027-03-18T09:00', 'Mar 18', 'Mar 18, 2027'], ['Week before', '2027-05-21T09:00', 'May 21', 'May 21, 2027'],
    ['During', '2027-05-29T14:30', 'May 29', 'May 29, 2:30 PM'], ['After', '2027-06-10T09:00', 'June 10', 'June 10, 2027']];
  // As: who, and the page they land on. [name, key of P ('' signs out), path from the Conference page, the person]
  // Roles only, never the made-up person's name (Oct 31, Michael: "Joel M." reads too close to a real Joel
  // Miller).
  const AS = [['Visitor', '', '?year=2027', ''], ['COA', 'coa', 'app/?year=2027', ''],
    ['Lodging', 'lodging', 'app/?year=2027&s=lod-rooms', ''], ['Webmaster', 'web', 'app/?year=2027&s=years', '']];
  // The local site keeps the old list's other stops (Oct 12: one place to look); the prototype doesn't.
  // null: as whoever is signed in now.
  const MORE = [
    ['The packet', 'packet/?year=2027&as-of=2027-05-21', null],
    ['Tournaments', 'tournaments/?year=2027', null],
    ['Food', 'app/?year=2027', 'food'],
    ['Transportation head', 'app/?year=2027', 'transport'],
    ['Mail log', 'mail/', 'web']
  ];
  const local = !!W.dev && !W.prototype;
  // Where (Nov 4, Michael: three things, each where it applies: where you are, on every page; the day,
  // only where the day changes what you see; who, only on the committees' side). [key, name, its page, the
  // first parts of the addresses that are this section]. The packet and the printed schedule are the
  // Conference page's own.
  const SECTIONS = [
    ['conference', 'Conference page', '?year=2027', ['', 'packet', 'schedule']],
    ['register', 'Register', 'register/?year=2027', ['register', 'signin']],
    ['volunteer', 'Volunteer', 'volunteer/?year=2027', ['volunteer']],
    ['tournaments', 'Tournaments', 'tournaments/?year=2027', ['tournaments']],
    ['guide', 'Conference app', 'guide/?year=2027', ['guide']],
    ['committees', 'Committees’ side', 'app/?year=2027', ['app', 'year', 'admin', 'lists', 'lodging', 'members', 'mail']]
  ];
  // The pages the day changes (the same list as OGC_DEV_DAY_PAGES in core-dev.php); every other page
  // shows May 10, 2027, when every sign-up is open.
  const DAY_PAGES = ['', 'packet', 'schedule', 'guide'];
  // The Conference app works from a week before to the morning people leave (Nov 5, Michael: going to it
  // should switch the day to During). Its Day lists only these days, and a day outside them becomes During
  // when the app opens (core-dev.php, OGC_DEV_APP_FROM/TO, does it on the server too).
  const APP_DAYS = ['2027-05-21', '2027-06-01'];
  const APP_AT = '2027-05-29T14:30';
  const appOk = at => !!at && at.slice(0, 10) >= APP_DAYS[0] && at.slice(0, 10) <= APP_DAYS[1];
  const PAGE_NAMES = { packet: 'Information packet', schedule: 'Printed schedule' };
  const first = (() => { const p = location.pathname; return (p.indexOf(base) === 0 ? p.slice(base.length) : '').split('/')[0]; })();
  const section = SECTIONS.find(x => x[3].indexOf(first) > -1) || SECTIONS[0];
  const dayHere = DAY_PAGES.indexOf(first) > -1;
  const backEnd = section[0] === 'committees';

  // Always through the dev sign-in or sign-out (Oct 29: a code sign-in made in the page, after it drew,
  // left OGC_WP.me empty, so "already signed out" was taken on trust and Visitor kept the session).
  const as = (who, path) => who ? base + 'dev-signin/?email=' + enc(P[who].email) + (P[who].extra || '') + '&return=' + enc(rel(path))
    : base + 'dev-signout/?return=' + enc(rel(path));
  // This page again on another day: its address without the day (the server writes the new one in).
  function hereClean() {
    const u = new URL(location.href);
    u.searchParams.delete('as-of');
    u.searchParams.delete('pages');
    if (u.searchParams.get('tz') === TZ) u.searchParams.delete('tz');
    const p = u.pathname;
    return '/' + (p.indexOf(home) === 0 ? p.slice(home.length) : p.replace(/^\//, '')) + u.search;
  }
  const whenUrl = at => base + 'dev-moment/?' + (at ? 'at=' + enc(at) + '&' : '') + 'return=' + enc(hereClean());

  // Where the page is now: the day in its address (the server put the chosen one there), and who.
  const MON = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'June', 'July', 'Aug', 'Sept', 'Oct', 'Nov', 'Dec'];
  const shortDate = iso => { const m = /^(\d{4})-(\d\d)-(\d\d)/.exec(iso || ''); return m ? MON[+m[2] - 1] + ' ' + (+m[3]) : ''; };
  const curAt = (new URLSearchParams(location.search).get('as-of') || '').slice(0, 16);
  const mi = MOMENTS.findIndex(m => curAt && curAt.slice(0, 10) === m[1].slice(0, 10));
  const me = W.me ? String(W.me.email || '').toLowerCase() : '';
  const ai = AS.findIndex(a => a[1] ? P[a[1]].email === me && (a[1] !== 'web' || W.webmaster) : !me);
  const shortName = n => { const w = String(n || '').trim().split(/\s+/).filter(Boolean); return w.length > 1 && !/\.$/.test(w[w.length - 1]) ? w[0] + ' ' + w[w.length - 1].charAt(0) + '.' : w.join(' '); };
  const whenShort = mi > -1 ? MOMENTS[mi][2] : curAt ? shortDate(curAt) : 'Today';
  // Never an email: it goes with feedback onto a board everyone with the link reads (Oct 31, Caleb's own showed).
  const whoShort = ai > -1 ? AS[ai][0] : (W.me && shortName(W.me.name)) || (me ? 'Signed in' : 'Visitor');
  // For the feedback board (ogc-feedback.js): the moment an idea is about.
  const momentText = mi > -1 ? MOMENTS[mi][0] + ' · ' + MOMENTS[mi][3] : curAt || 'Today';
  // The pill: where you are, then the day where it matters, or who on the committees' side.
  const pillWords = (PAGE_NAMES[first] || section[1]) + (dayHere ? ' · ' + whenShort : backEnd ? ' · ' + whoShort : '');

  // Another page on a day, as someone (the board's Go to screen). page: a path from the site's home
  // ("/annual-conference/register/?year=2027"); at: the day ("2027-03-02T09:00"); asName: one of As's names.
  // Through dev-signin or dev-signout when that's not who's here now, then dev-moment, then the page.
  function travel(page, at, asName) {
    let target = '/' + String(page || '').replace(/^\/+/, '');
    try {
      const u = new URL(target, location.origin);
      ['as-of', 'pages'].forEach(k => u.searchParams.delete(k));
      if (u.searchParams.get('tz') === TZ) u.searchParams.delete('tz');
      target = u.pathname + u.search;
    } catch (e) { /* as it was */ }
    let url = target;
    if (W.dev && /^\d{4}-\d\d-\d\dT\d\d:\d\d$/.test(at || '')) url = '/' + baseRel + 'dev-moment/?at=' + enc(at) + '&return=' + enc(url);
    const k = AS.findIndex(x => x[0] === asName);
    if (W.dev && k > -1 && k !== ai) {
      const who = AS[k][1];
      url = '/' + baseRel + (who ? 'dev-signin/?email=' + enc(P[who].email) + (P[who].extra || '') + '&' : 'dev-signout/?') + 'return=' + enc(url);
      forget();
    }
    location.href = home.replace(/\/$/, '') + url;
  }

  const CARET = '<svg viewBox="0 0 12 12" aria-hidden="true"><path d="M2.5 7.5 6 4l3.5 3.5" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  // The demo's own look (Oct 31): tool chrome over the page, never the site's tan, cream or serif.
  const SANS = 'system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,sans-serif';

  /* ------------------------------------------------------------------ our root, and where it lives */

  const ROOT_ID = 'ogc-tools';
  // Our CSS outweighs the page's: every selector starts at our root's id (a selector that starts at html
  // keeps html first). @media and @supports are scoped inside; @keyframes stay as they are.
  function scope(css) {
    const pre = '#' + ROOT_ID;
    const split = s => { const out = []; let d = 0, from = 0; for (let i = 0; i < s.length; i++) { const c = s[i]; if (c === '(' || c === '[') d++; else if (c === ')' || c === ']') d--; else if (c === ',' && !d) { out.push(s.slice(from, i)); from = i + 1; } } out.push(s.slice(from)); return out; };
    const one = s => { s = s.trim(); const m = /^(html|:root)(\S*)\s+(.*)$/.exec(s); return m ? m[1] + m[2] + ' ' + pre + ' ' + m[3] : pre + ' ' + s; };
    let out = '', i = 0;
    while (i < css.length) {
      const open = css.indexOf('{', i);
      if (open < 0) { out += css.slice(i); break; }
      const head = css.slice(i, open).trim();
      let d = 1, j = open + 1;
      for (; j < css.length && d; j++) { if (css[j] === '{') d++; else if (css[j] === '}') d--; }
      const body = css.slice(open + 1, j - 1);
      if (/^@(media|supports|container|layer)\b/.test(head)) out += head + '{' + scope(body) + '}';
      else if (head.charAt(0) === '@') out += head + '{' + body + '}';
      else out += split(head).map(one).join(',') + '{' + body + '}';
      i = j;
    }
    return out;
  }
  const isModal = d => { try { return d.matches(':modal'); } catch (e) { return !!d.open; } };
  const popOpen = el => { try { return el.matches(':popover-open'); } catch (e) { return false; } };
  // The root: at the end of <body> (no box of its own), or in the topmost open modal dialog, in the top
  // layer. Built at once, so ogc-feedback.js and the prototype's link note can draw into it.
  function makeRoot() {
    const root = document.createElement('div');
    root.id = ROOT_ID;
    root.className = 'ogc-tools';
    root.setAttribute('data-ogc-tool', '');
    document.body.appendChild(root);
    // The page never hears our presses, keys or typing (a sheet's backdrop handler, a menu's press-outside,
    // a page's shortcuts). Our own listeners are inside the root, or on document in the capture phase.
    ['pointerdown', 'pointerup', 'mousedown', 'mouseup', 'click', 'dblclick', 'auxclick', 'contextmenu', 'touchstart', 'touchend', 'touchmove', 'wheel',
      'keydown', 'keyup', 'keypress', 'beforeinput', 'input', 'change', 'submit', 'focusin', 'focusout', 'paste', 'copy', 'cut']
      .forEach(t => root.addEventListener(t, e => e.stopPropagation(), { passive: t === 'touchstart' || t === 'touchmove' || t === 'wheel' }));
    const order = []; // the modal dialogs open now, oldest first
    let host = null, shownOn = null, queued = false;
    const busyFns = [];
    function modals() {
      for (let i = order.length - 1; i >= 0; i--) if (!order[i].isConnected || !isModal(order[i])) order.splice(i, 1);
      document.querySelectorAll('dialog[open]').forEach(d => { if (order.indexOf(d) < 0 && isModal(d)) order.push(d); });
      return order.slice();
    }
    // Was something of ours open when Escape was pressed? Then the dialog under it stays (its cancel).
    let escAt = -1e9, escOurs = false;
    const busy = () => busyFns.some(f => { try { return f(); } catch (e) { return false; } });
    addEventListener('keydown', e => { if (e.key === 'Escape' || e.key === 'Esc') { escAt = performance.now(); escOurs = busy(); } }, true);
    const guarded = new WeakSet();
    function guard(d) {
      if (guarded.has(d)) return;
      guarded.add(d);
      d.addEventListener('cancel', e => { if (escOurs && performance.now() - escAt < 600) { e.preventDefault(); e.stopImmediatePropagation(); } }, true);
    }
    function rehome() {
      queued = false;
      const list = modals(), want = list[list.length - 1] || null, parent = want || document.body;
      if (!parent) return;
      if (root.parentNode === parent && shownOn === want && (!want || popOpen(root))) return;
      // What moving takes away: the focus (and a field's caret) and our panels' scroll.
      const f = root.contains(document.activeElement) ? document.activeElement : null;
      const caret = f && typeof f.selectionStart === 'number' ? [f.selectionStart, f.selectionEnd, f.selectionDirection] : null;
      const scrolled = [...root.querySelectorAll('*')].filter(x => x.scrollTop || x.scrollLeft).map(x => [x, x.scrollTop, x.scrollLeft]);
      if (popOpen(root)) { try { root.hidePopover(); } catch (e) { /* closed with it */ } }
      if (want && typeof root.showPopover === 'function') root.setAttribute('popover', 'manual'); else root.removeAttribute('popover');
      if (root.parentNode !== parent) {
        if (typeof parent.moveBefore === 'function' && root.isConnected) { try { parent.moveBefore(root, null); } catch (e) { parent.appendChild(root); } }
        else parent.appendChild(root);
      }
      if (want && root.hasAttribute('popover')) { try { root.showPopover(); } catch (e) { /* drawn in the dialog instead */ } }
      if (want) guard(want);
      shownOn = want;
      host = want;
      scrolled.forEach(([x, t, l]) => { x.scrollTop = t; x.scrollLeft = l; });
      if (f && root.contains(f) && document.activeElement !== f) {
        try { f.focus({ preventScroll: true }); if (caret) f.setSelectionRange(caret[0], caret[1], caret[2] || 'none'); } catch (e) { /* as it is */ }
      }
      root.dispatchEvent(new Event('ogc-rehome'));
    }
    const soon = () => { if (!queued) { queued = true; queueMicrotask(rehome); } };
    try {
      new MutationObserver(recs => {
        if (recs.some(r => r.type === 'attributes') || root.parentNode !== (host || document.body) || (host && (!host.isConnected || !isModal(host)))) soon();
      }).observe(document.documentElement, { subtree: true, childList: true, attributes: true, attributeFilter: ['open'] });
    } catch (e) { /* stays in <body> */ }
    rehome();
    return { root, host: () => host, modals, busy, onBusy: f => busyFns.push(f), rehome };
  }
  let R = null;

  // The demo's own surfaces that sit on the page itself (the banner, v3's pills): never scoped.
  const pageCss =
    // The banner: the demo's label, in the demo's look.
    '.ogc-pbar{position:relative;z-index:62;margin:0;padding:6px 16px;background:#161616;color:#d4d4d4;text-align:center;font:400 12.5px/1.35 ' + SANS + ';letter-spacing:0}' +
    '.ogc-pbar b{color:#d4d4d4;font-weight:600}' +
    // v3's mockup-only pills
    '.ogc-mock{display:inline-flex;align-items:center;min-height:44px;padding:6px 14px;border:0;border-radius:999px;background:#161616;color:#e6e6e6;font:600 12px/1.2 ' + SANS + ';letter-spacing:0;cursor:pointer;text-decoration:none}' +
    '.ogc-mock:hover{background:#2a2a2a}.ogc-mock:focus-visible{outline:2px solid #f2f2f2;outline-offset:2px}' +
    '.ogc-mock--tag{min-height:0;padding:3px 10px;font-size:12px;cursor:default}.ogc-mock--tag:hover{background:#161616}' +
    // Our root: no box of its own in <body>; over a pop-up, the whole screen in the top layer, letting
    // presses through to the sheet except on our own things.
    '#' + ROOT_ID + '{display:contents;font:400 14px/1.45 ' + SANS + ';color:#f2f2f2;letter-spacing:0;word-spacing:0;text-transform:none;text-align:left;text-indent:0;white-space:normal;font-style:normal;font-variant:normal;cursor:auto;visibility:visible;direction:ltr}' +
    '#' + ROOT_ID + '[popover]{display:none;position:fixed;inset:0;width:auto;height:auto;max-width:none;max-height:none;margin:0;padding:0;border:0;background:transparent;overflow:visible;pointer-events:none}' +
    '#' + ROOT_ID + '[popover]:popover-open{display:block}#' + ROOT_ID + '[popover]>*{pointer-events:auto}#' + ROOT_ID + '::backdrop{display:none}' +
    '@media print{.ogc-pbar,.ogc-mock,#' + ROOT_ID + '{display:none!important}}';

  // Ours, inside the root (scoped).
  const css =
    // The dock: one near-black capsule in the corner. --ogc-pill-lift is the page's own bar or control at
    // the foot of the screen, measured (lift()).
    '.ogc-pill{position:fixed;right:16px;bottom:calc(16px + var(--ogc-pill-lift,0px) + env(safe-area-inset-bottom));z-index:61;box-sizing:border-box;display:flex;align-items:center;max-width:calc(100vw - 32px);height:44px;border-radius:22px;background:#161616;color:#f2f2f2;box-shadow:inset 0 0 0 1px rgba(255,255,255,.09),0 8px 24px rgba(0,0,0,.26),0 1px 3px rgba(0,0,0,.2);font:500 13px/1.2 ' + SANS + ';letter-spacing:0;-webkit-font-smoothing:antialiased;text-transform:none}' +
    '.ogc-pill[hidden]{display:none}.ogc-pill *{box-sizing:border-box}' +
    // The card is placed against the whole dock (its right edge), not the pill's part: the pill sits at the
    // dock's left, and a card from there would run off the screen's right edge.
    '.ogc-pill__pick{position:static;display:flex;flex:none;height:44px}' +
    '.ogc-pill__btn{display:inline-flex;align-items:center;gap:7px;height:44px;min-height:44px;margin:0;padding:0 12px 0 16px;border:0;border-radius:22px;background:transparent;color:#f2f2f2;font:500 13px/1.2 ' + SANS + ';white-space:nowrap;cursor:pointer}' +
    '.ogc-pill__btn:hover,.ogc-pill.is-open .ogc-pill__btn{background:rgba(255,255,255,.08)}' +
    '.ogc-pill__btn svg{flex:none;width:12px;height:12px;color:#a3a3a3}.ogc-pill.is-open .ogc-pill__btn svg{transform:rotate(180deg)}' +
    // The feedback board's part (ogc-feedback.js fills it), after a hairline.
    '.ogc-pill__fb{display:flex;align-items:center;flex:none;height:44px}.ogc-pill__fb[hidden]{display:none}' +
    '.ogc-pill__pick+.ogc-pill__fb::before{content:"";flex:none;width:1px;height:20px;margin:0 2px;background:rgba(255,255,255,.16)}' +
    // Open: the card above the pill. The menu's own foot (8 px, clear) joins the two, so the pointer moving
    // from the pill into the card never leaves it.
    '.ogc-pill__menu{position:absolute;right:0;bottom:100%;padding-bottom:8px;visibility:hidden;opacity:0;pointer-events:none}' +
    '.ogc-pill.is-open .ogc-pill__menu{visibility:visible;opacity:1;pointer-events:auto}' +
    '.ogc-pill__card{box-sizing:border-box;width:min(312px,calc(100vw - 32px));max-height:calc(100vh - 112px - var(--ogc-pill-lift,0px));overflow:auto;padding:8px 10px 10px;border-radius:16px;background:#161616;color:#f2f2f2;box-shadow:inset 0 0 0 1px rgba(255,255,255,.09),0 16px 40px rgba(0,0,0,.34)}' +
    '.ogc-pill__lab{margin:6px 6px 4px;color:#a3a3a3;font-size:12px;font-weight:600;letter-spacing:0}' +
    '.ogc-pill__lab:not(:first-child){margin-top:12px}' +
    '.ogc-pill__grid{display:grid;grid-template-columns:1fr 1fr;gap:4px;list-style:none;margin:0;padding:0}' +
    '.ogc-pill__card a{box-sizing:border-box;display:flex;flex-direction:column;justify-content:center;min-height:44px;padding:5px 10px;border-radius:10px;color:#f2f2f2;text-decoration:none;font-size:13.5px;line-height:1.25}' +
    '.ogc-pill__card a b{font-weight:600}.ogc-pill__card a span{color:#a3a3a3;font-size:12px}' +
    '.ogc-pill__card a:hover{background:rgba(255,255,255,.07)}' +
    // The current day and person: the accent, and an edge (not by colour alone).
    '.ogc-pill__card a[aria-current]{background:rgba(255,255,255,.12);color:#fff;box-shadow:inset 0 0 0 1px rgba(255,255,255,.3)}.ogc-pill__card a[aria-current] span{color:#e6e6e6}' +
    // One focus ring, the demo's accent, drawn inside each control so it's always on the dark surface.
    '.ogc-pill :focus-visible{outline:2px solid #f2f2f2;outline-offset:-2px}.ogc-pill__card :focus-visible{outline-offset:0}' +
    '.ogc-pill :focus:not(:focus-visible){outline:none}' +
    // Minimize (Nov 5): a small tab on the dock's top edge, four dots, its press area 44 × 32 px; folded,
    // the dock is a 44 px circle with the same dots. The tab hides while the card is open above it.
    '.ogc-pill__min{position:absolute;left:50%;bottom:calc(100% - 1px);transform:translateX(-50%);display:flex;align-items:center;justify-content:center;width:40px;height:17px;margin:0;padding:0 0 1px;border:0;border-radius:9px 9px 0 0;background:#161616;color:#8f8f8f;box-shadow:inset 0 1px 0 rgba(255,255,255,.1);cursor:pointer}' +
    '.ogc-pill__min::after{content:"";position:absolute;left:-2px;right:-2px;top:-15px;bottom:0}' +
    '.ogc-pill__min:hover{color:#f2f2f2}.ogc-pill.is-open .ogc-pill__min{visibility:hidden}' +
    '.ogc-pill__max{display:none}' +
    '.ogc-pill.is-min{width:44px}.ogc-pill.is-min>:not(.ogc-pill__max){display:none!important}' +
    '.ogc-pill.is-min .ogc-pill__max{display:flex;align-items:center;justify-content:center;width:44px;height:44px;margin:0;padding:0;border:0;border-radius:22px;background:transparent;color:#d4d4d4;cursor:pointer}' +
    '.ogc-pill.is-min .ogc-pill__max:hover{color:#fff;background:rgba(255,255,255,.08)}' +
    '.ogc-pill__dots{display:grid;grid-template-columns:3px 3px;gap:3px}.ogc-pill__dots i{display:block;width:3px;height:3px;border-radius:50%;background:currentColor}' +
    '.ogc-pill.is-min .ogc-pill__dots{grid-template-columns:4px 4px;gap:4px}.ogc-pill.is-min .ogc-pill__dots i{width:4px;height:4px}' +
    '.ogc-pill__sr{position:absolute;width:1px;height:1px;margin:-1px;padding:0;overflow:hidden;clip:rect(0 0 0 0);white-space:nowrap;border:0}' +
    // Motion only to show the card come from the pill, and the dock rising over a bar; none when reduced.
    '@media (prefers-reduced-motion:no-preference){.ogc-pill{transition:bottom .16s ease-out}.ogc-pill__menu{transform:translateY(4px);transition:opacity .12s ease-out,transform .12s ease-out,visibility 0s linear .12s}.ogc-pill.is-open .ogc-pill__menu{transform:none;transition:opacity .12s ease-out,transform .12s ease-out,visibility 0s}}' +
    // The prototype's note for a link that would leave the laptop: in the demo's look, just above the
    // dock (and so above the page's own bar at its foot when there is one).
    '.ogc-pnote{position:fixed;left:50%;bottom:calc(72px + var(--ogc-pill-lift,0px) + env(safe-area-inset-bottom));z-index:70;transform:translateX(-50%);box-sizing:border-box;width:max-content;max-width:min(440px,calc(100vw - 32px));margin:0;padding:10px 16px;border-radius:12px;background:#161616;color:#e6e6e6;box-shadow:inset 0 0 0 1px rgba(255,255,255,.09),0 8px 24px rgba(0,0,0,.26);font:400 14px/1.4 ' + SANS + ';text-align:center}' +
    '.ogc-pnote b{color:#d4d4d4;font-weight:600}.ogc-pnote[hidden]{display:none}' +
    '@media print{.ogc-pill,.ogc-pnote{display:none!important}}';

  function banner() {
    if (document.querySelector('.ogc-pbar')) return;
    const b = document.createElement('p');
    b.className = 'ogc-pbar';
    b.setAttribute('role', 'note');
    b.innerHTML = '<b>Demo</b> · made-up people';
    document.body.insertBefore(b, document.body.firstChild);
  }

  // The shared prototype runs on a laptop, often on a projector: a link that would leave it (a phone
  // number, a text, an email, Google Maps) says what it does on a phone instead (Oct 28 rehearsal: Help's
  // "Call 911" is a real tel: link, and a Mac paired with an iPhone places the call). Never on ogbbc.org:
  // this script isn't there, and this runs only with OGC_PROTOTYPE.
  const MAPS = /^https?:\/\/((www\.)?google\.[a-z.]+\/maps|maps\.google\.[a-z.]+\/|goo\.gl\/maps|maps\.app\.goo\.gl\/|maps\.apple\.com\/)/i;
  function outside(a) {
    const h = (a.getAttribute('href') || '').trim();
    if (/^tel:/i.test(h)) {
      let n = '';
      try { n = decodeURIComponent(h.slice(4)); } catch (e) { n = h.slice(4); }
      n = n.split(/[,;#]/)[0].replace(/[^\d+]/g, '').replace(/^\+?1(?=\d{10}$)/, '').replace(/^(\d{3})(\d{3})(\d{4})$/, '$1-$2-$3');
      return 'On a phone, this calls ' + (n || 'the number');
    }
    if (/^sms:/i.test(h)) return 'On a phone, this starts a text';
    if (/^mailto:/i.test(h)) return 'This starts an email';
    if (/^geo:/i.test(h)) return 'On a phone, this opens the map';
    if (MAPS.test(a.href || h)) return /travelmode=walking/i.test(a.href) ? 'This opens Google Maps walking directions' : /\/dir\//i.test(a.href) ? 'This opens Google Maps directions' : 'This opens Google Maps';
    return '';
  }
  function guard() {
    if (!W.prototype) return;
    let note = null, timer = 0;
    document.addEventListener('click', e => {
      const a = e.target.closest && e.target.closest('a[href]');
      if (!a || e.defaultPrevented) return;
      const what = outside(a);
      if (!what) return;
      e.preventDefault();
      e.stopPropagation();
      if (!note) {
        note = document.createElement('p');
        note.className = 'ogc-pnote';
        note.setAttribute('role', 'status');
        note.setAttribute('data-ogc-tool', '');
        (R ? R.root : document.body).appendChild(note);
      }
      note.innerHTML = '<b>Demo</b> · ' + esc(what);
      note.hidden = false;
      clearTimeout(timer);
      timer = setTimeout(() => { note.hidden = true; }, 3500);
    }, true);
  }

  // Signing in as someone else: what this browser kept for the last person goes too (a pending email, the
  // registration form's draft in this tab), as the account menu's Sign out does (ogc-account.js forget).
  function forget() {
    try { localStorage.removeItem('ogc-me-pending'); } catch (x) { /* nothing kept */ }
    try { Object.keys(sessionStorage).filter(k => k.indexOf('ogc-register-draft-') === 0).forEach(k => sessionStorage.removeItem(k)); } catch (x) { /* nothing kept */ }
  }

  // The dock: the demo pill (when the dev sign-in is here) and the feedback board's slot.
  function dock() {
    const el = document.createElement('div');
    el.className = 'ogc-pill';
    el.setAttribute('data-ogc-tool', '');
    el.setAttribute('data-ogc-moment', momentText);
    el.innerHTML = '<div class="ogc-pill__fb" hidden></div>';
    R.root.appendChild(el);
    const slot = el.querySelector('.ogc-pill__fb');
    if (W.dev) pill(el); // As signs people in, which only the dev sign-in can do
    minimize(el);
    // Nothing in it yet (the prototype without the pill, the board not here): not drawn.
    const empty = () => !el.querySelector('.ogc-pill__pick') && slot.hidden;
    el.hidden = empty();
    try { new MutationObserver(() => { el.hidden = empty(); }).observe(slot, { attributes: true, attributeFilter: ['hidden'] }); } catch (e) { /* drawn as it was */ }
    lifter(el);
    // Moved into a pop-up or back: measured again where it is now (and once the sheet has slid in).
    R.root.addEventListener('ogc-rehome', () => { if (el._lift) { el._lift(); setTimeout(el._lift, 350); } });
    window.OGC_DOCK = {
      el, slot, travel, lift: () => el._lift && el._lift(),
      root: R.root, host: R.host, modals: R.modals, scope, onBusy: R.onBusy, rehome: R.rehome,
      moment: { name: mi > -1 ? MOMENTS[mi][0] : '', at: curAt, text: momentText },
      who: whoShort
    };
    try { document.dispatchEvent(new Event('ogc-dock')); } catch (e) { /* ogc-feedback.js looks for OGC_DOCK too */ }
  }

  // Minimize (Nov 5, Michael: on a phone the dock "stretches across half the width of your screen", so give
  // it "a little handle… on top of the pill" that "collapses it down into a small little circular state").
  // The handle (four dots) sits on the dock's top edge; it folds the dock into a 44 px circle in the same
  // corner, and the circle opens it again. Kept in this browser (ogc-dock-min); a card that's open closes.
  function minimize(el) {
    const KEY = 'ogc-dock-min', DOTS = '<span class="ogc-pill__dots" aria-hidden="true"><i></i><i></i><i></i><i></i></span>';
    const grip = document.createElement('button'), max = document.createElement('button');
    grip.type = max.type = 'button';
    grip.className = 'ogc-pill__min';
    grip.title = 'Minimize';
    grip.setAttribute('aria-label', 'Minimize the demo controls');
    max.className = 'ogc-pill__max';
    max.title = 'Show the demo controls';
    max.setAttribute('aria-label', 'Show the demo controls');
    grip.innerHTML = max.innerHTML = DOTS;
    el.appendChild(grip);
    el.appendChild(max);
    const fold = (m, focus) => {
      if (m && el._close) el._close();
      el.classList.toggle('is-min', m);
      LS.set(KEY, m ? 1 : 0);
      if (el._lift) el._lift();
      if (focus) (m ? max : grip).focus();
    };
    grip.addEventListener('click', e => fold(true, e.detail === 0));
    max.addEventListener('click', e => fold(false, e.detail === 0));
    if (LS.get(KEY, 0)) el.classList.add('is-min');
  }

  function pill(el) {
    const opt = (href, name, sub, cur, kind, extra) => '<li><a href="' + esc(href) + '" data-k="' + kind + '"' + (extra || '') + (cur ? ' aria-current="true"' : '') + '><b>' + esc(name) + '</b>' + (sub ? '<span>' + esc(sub) + '</span>' : '') + '</a></li>';
    const group = (name, items) => { const id = 'ogc-pill-' + name.toLowerCase().replace(/[^a-z]+/g, '-'); return '<p class="ogc-pill__lab" id="' + id + '">' + name + '</p>' +
      '<ul class="ogc-pill__grid" aria-labelledby="' + id + '">' + items.join('') + '</ul>'; };
    // The local site's Today: the real time again (the prototype always shows one of the six days).
    const now = new Date(), todayLong = MON[now.getMonth()] + ' ' + now.getDate() + ', ' + now.getFullYear();
    // On the Conference app, only the days it works on (no Today, no Registration).
    const onApp = section[0] === 'guide';
    const when = (local && !onApp ? [opt(whenUrl(''), 'Today', todayLong, !curAt, 'when', ' data-at=""')] : [])
      .concat(MOMENTS.map((m, i) => !onApp || appOk(m[1]) ? opt(whenUrl(m[1]), m[0], m[3], i === mi, 'when', ' data-at="' + m[1] + '"') : '').filter(Boolean));
    // Go to: the public sections as whoever is here, unless that's one of the committees' made-up people
    // (then signed out first); the committees' side as the COA, unless one of them is here already.
    // The Conference app with no day chosen (the local site's Today): through dev-moment, to During. A
    // chosen day it can't show, the server moves to During as the app opens.
    const role = ai > 0;
    const toApp = local && !(W.moment && W.moment.chosen);
    const go = SECTIONS.map(x => {
      const pub = x[0] !== 'committees';
      const path = x[0] === 'guide' && toApp ? 'dev-moment/?at=' + enc(APP_AT) + '&return=' + enc(rel(x[2])) : x[2];
      const href = pub ? (role ? as('', path) : base + path) : (role ? base + path : as('coa', path));
      return opt(href, x[1], '', x === section, 'go', ((pub && role) || (!pub && !role) ? ' data-who="' + (pub ? '' : esc(P.coa.email)) + '"' : '') +
        (path !== x[2] ? ' data-day="' + APP_AT + '"' : ''));
    });
    const who = AS.slice(1).map((a, i) => opt(as(a[1], a[2]), a[0], '', i + 1 === ai, 'as', ' data-who="' + esc(P[a[1]].email) + '"'));
    const more = local ? MORE.map(x => opt(x[2] === null ? base + x[1] : as(x[2], x[1]), x[0], '', false, 'more', x[2] ? ' data-who="' + esc(P[x[2]].email) + '"' : '')) : null;

    const pick = document.createElement('div');
    pick.className = 'ogc-pill__pick';
    // The pill first, then its card (drawn above it), so Tab goes from the pill into the choices.
    pick.innerHTML =
      '<button type="button" class="ogc-pill__btn" aria-expanded="false" aria-controls="ogc-pill-menu" title="Where you are' + (dayHere ? ', and the day' : backEnd ? ', and who' : '') + '"><span class="ogc-pill__sr">Demo: </span>' +
      esc(pillWords) + CARET + '</button>' +
      '<div class="ogc-pill__menu" id="ogc-pill-menu"><div class="ogc-pill__card" role="group" aria-label="Demo">' +
      group('Go to', go) + (dayHere ? group('Day', when) : '') + (backEnd ? group('Signed in as', who) : '') + (more ? group('More', more) : '') +
      '</div></div>';
    el.insertBefore(pick, el.firstChild);
    const btn = pick.querySelector('.ogc-pill__btn');
    const links = () => [...pick.querySelectorAll('.ogc-pill__card a')];

    // Open: by hover (a mouse), by a click or tap (it stays until a tap outside, Escape or another click),
    // or by the keyboard (focus, or Enter). how: 'hover' | 'click' | 'key'. Only the pill's own part
    // opens it: Leave feedback beside it never does.
    let open = false, how = '', shut = 0, soon = 0, hush = false, quiet = false;
    function set(o, by) {
      clearTimeout(shut); clearTimeout(soon);
      if (o && open) { if (by && by !== 'hover') how = by; return; }
      if (!o && !open) return;
      open = o; how = o ? by : '';
      el.classList.toggle('is-open', o);
      btn.setAttribute('aria-expanded', String(o));
      if (o && el._lift) el._lift();
    }
    el._close = () => set(false); // the dock's Minimize closes the card first
    const mouse = e => e.pointerType === 'mouse' || e.pointerType === 'pen';
    pick.addEventListener('pointerenter', e => {
      if (!mouse(e)) return;
      clearTimeout(shut);
      if (!open && !hush) soon = setTimeout(() => set(true, 'hover'), 60);
    });
    // A short wait before it closes, so a pointer crossing the gap or the card's edge doesn't shut it.
    pick.addEventListener('pointerleave', e => {
      if (!mouse(e)) return;
      clearTimeout(soon);
      hush = false;
      if (open && how === 'hover') shut = setTimeout(() => set(false), 320);
    });
    let lastPointer = '';
    btn.addEventListener('pointerdown', e => { lastPointer = e.pointerType; });
    btn.addEventListener('click', e => {
      const key = e.detail === 0; // Enter or Space
      if (!open) { set(true, key ? 'key' : 'click'); if (key) (pick.querySelector('.ogc-pill__card a[aria-current]') || links()[0]).focus(); return; }
      // Opened by hover or by focus: a click keeps it (Enter goes into it); opened by a click: it closes.
      if (how === 'hover' && !key) { how = 'click'; return; }
      if (how === 'key' && key && !pick.querySelector('.ogc-pill__card :focus')) { (pick.querySelector('.ogc-pill__card a[aria-current]') || links()[0]).focus(); return; }
      set(false);
      hush = mouse({ pointerType: lastPointer });
    });
    // The keyboard: focus on the pill opens it (Tab then moves through the choices).
    btn.addEventListener('focus', () => { if (!quiet && !open && btn.matches(':focus-visible')) set(true, 'key'); });
    pick.addEventListener('focusout', e => { if (open && how !== 'hover' && !(e.relatedTarget && pick.contains(e.relatedTarget)) && e.relatedTarget) set(false); });
    document.addEventListener('pointerdown', e => { if (open && !pick.contains(e.target)) set(false); }, true);
    // Something of ours is open (Escape closes it, never a sheet under it: ogc-dev-nav's root).
    if (R) R.onBusy(() => open);
    // On document, capturing: our root keeps keys from the page's own listeners, and the page's from ours.
    document.addEventListener('keydown', e => {
      if (!open) return;
      const inside = pick.contains(document.activeElement);
      if (e.key === 'Escape') {
        set(false);
        if (inside) { e.preventDefault(); quiet = true; btn.focus(); quiet = false; }
      } else if (inside && (e.key === 'ArrowDown' || e.key === 'ArrowUp')) {
        const all = links(), i = all.indexOf(document.activeElement);
        const next = e.key === 'ArrowDown' ? (i < 0 ? 0 : (i + 1) % all.length) : (i <= 0 ? all.length - 1 : i - 1);
        all[next].focus();
        e.preventDefault();
      }
    }, true);

    // A choice: its day or person is noted here too, so a page the browser brings back from its cache
    // (Back) with another day or person is drawn again (pageshow below).
    pick.addEventListener('click', e => {
      const a = e.target.closest && e.target.closest('.ogc-pill__card a');
      if (!a) return;
      const kept = LS.get('ogc-pill', {}) || {};
      // This page as it is now (the app changes its address as people move about in it).
      if (a.hasAttribute('data-at')) { kept.at = a.getAttribute('data-at'); a.href = whenUrl(kept.at); }
      if (a.hasAttribute('data-day')) kept.at = a.getAttribute('data-day');
      if (a.hasAttribute('data-who')) { kept.who = a.getAttribute('data-who'); forget(); }
      LS.set('ogc-pill', kept);
    });
    addEventListener('pageshow', e => {
      if (!e.persisted) return;
      const kept = LS.get('ogc-pill', null);
      if (kept && ((kept.at != null && kept.at.slice(0, 10) !== curAt.slice(0, 10)) || (kept.who != null && kept.who !== me))) location.reload();
    });
    // ?pages=1 opens it (as it did the old list): for a screenshot, or a link that should show it.
    if (new URLSearchParams(location.search).get('pages') === '1') setTimeout(() => set(true, 'click'), 0);
  }

  // Never over the page's own bar at the foot of the screen (the form's total and Next, Your week's bar,
  // the guide's tabs, the player, a toast and its Undo): measured where the dock rests, it rises above
  // whatever fixed bar is there, and above the next if bars are stacked. In a tall panel that stays put
  // (the app's record panel, sticky beside its list), it rises above a control under it (its Save) only
  // when no scrolling, the panel's or the page's, would bring that out from under the dock: so it doesn't
  // bob up and down as a panel's links pass under it. Over a pop-up (the dock in it, ogc-dev-nav's root),
  // only the pop-up counts: a short sheet at the foot is a bar (the dock rises above it), a tall one a
  // panel; the page under the backdrop never does. Another dialog never counts.
  // foot: how far above the screen's foot the dock rests unlifted (16 px and the phone's safe area),
  // measured before it has moved, so a lift measured mid-motion still starts from its resting place.
  const CONTROL = 'a[href],button,input,select,textarea,summary,[role=button],[role=tab],[role=switch],[role=checkbox]';
  function lifter(el) {
    let cur = 0, tick = 0, foot = -1;
    const de = document.documentElement;
    // The top of what the dock must stay above, for one thing under it, or Infinity.
    function topOf(e) {
      let control = null;
      const host = R && R.host();
      for (let x = e; x && x !== document.body && x !== de; x = x.parentElement) {
        if (el.contains(x) || (x.tagName === 'DIALOG' && x !== host) || x.hasAttribute('data-ogc-tool') || /(^|\s)ogc-(pnote|pbar|fb)/.test(String(x.className))) return Infinity;
        if (!control && x.matches && x.matches(CONTROL)) control = x;
        // The guide's Places sheet (the map area, Nov 5): the dock rests above it unless it fills the
        // screen, so it never covers the planner's Start (or a place's Directions).
        if (x.classList && x.classList.contains('pm-sheet') && !x.classList.contains('is-full')) { const sb = x.getBoundingClientRect(); return sb.height ? sb.top : Infinity; }
        const p = getComputedStyle(x).position;
        if (p !== 'fixed' && p !== 'sticky') continue;
        const b = x.getBoundingClientRect();
        if (!b.height) return Infinity;
        if (b.height <= innerHeight * 0.45 && b.top >= innerHeight * 0.4) return p === 'fixed' || b.bottom >= innerHeight - 4 ? b.top : Infinity;
        if (control) { const c = control.getBoundingClientRect(); return c.height && c.top >= innerHeight * 0.4 && !more(control, x, p === 'sticky') ? c.top : Infinity; }
        return Infinity;
      }
      return Infinity;
    }
    // Can scrolling still move this control: a scrolled box it's in (up to its panel), or, for a sticky
    // panel, the page?
    function more(c, panel, sticky) {
      for (let x = c.parentElement; x && x !== document.body && x !== de; x = x.parentElement) {
        const o = getComputedStyle(x).overflowY;
        if ((o === 'auto' || o === 'scroll') && x.scrollHeight - x.scrollTop - x.clientHeight > 1) return true;
        if (x === panel) break;
      }
      const se = document.scrollingElement || de;
      return sticky && se.scrollHeight - se.scrollTop - innerHeight > 1;
    }
    function lift() {
      tick = 0;
      if (el.hidden) return;
      const r = el.getBoundingClientRect();
      if (!r.width || !document.elementsFromPoint) return;
      if (foot < 0) foot = innerHeight - r.bottom - cur;
      const rest = innerHeight - foot, h = r.height, xs = [r.left + 8, r.left + r.width * 0.25, (r.left + r.right) / 2, r.left + r.width * 0.75, r.right - 8];
      let bottom = rest;
      for (let n = 0; n < 4; n++) {
        let top = Infinity;
        const host = R && R.host(), hb = host && host.getBoundingClientRect();
        // Over a pop-up: only what's in it, and the pop-up itself only where it is (not its backdrop).
        const counts = (t, x, y) => !host || (host.contains(t) && (t !== host || (x >= hb.left && x <= hb.right && y >= hb.top && y <= hb.bottom)));
        [bottom - 2, bottom - h / 2, bottom - h + 2].forEach(y => { if (y > 0) xs.forEach(x => document.elementsFromPoint(x, y).forEach(t => { if (counts(t, x, y)) top = Math.min(top, topOf(t)); })); });
        if (top === Infinity || top >= bottom) break;
        bottom = top - 8;
      }
      const up = Math.max(0, Math.round(rest - bottom));
      if (up === cur) return;
      cur = up;
      [el, de].forEach(x => { if (up) x.style.setProperty('--ogc-pill-lift', up + 'px'); else x.style.removeProperty('--ogc-pill-lift'); });
    }
    el._lift = lift;
    const soonLift = () => { if (!tick) tick = setTimeout(lift, 150); };
    addEventListener('resize', () => { if (!cur) foot = -1; soonLift(); });
    // Capturing, so a panel's own scroll counts too.
    document.addEventListener('scroll', soonLift, { passive: true, capture: true });
    try { new MutationObserver(m => { if (m.some(x => !el.contains(x.target))) soonLift(); }).observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ['class', 'hidden'] }); } catch (e) { /* it stays where it is */ }
    lift();
    setTimeout(lift, 400);
    setTimeout(lift, 1500);
  }

  function build() {
    const style = document.createElement('style');
    style.textContent = pageCss + (framed ? '' : scope(css));
    document.head.appendChild(style);
    if (!framed) R = makeRoot();
    guard();
    if (framed) return;
    banner();
    dock();
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', build); else build();
})();
