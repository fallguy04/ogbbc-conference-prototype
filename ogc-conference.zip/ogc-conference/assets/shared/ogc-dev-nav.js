/*
 * ogc-dev-nav.js — the local site and the shared prototype only (loaded when OGC_DEV or OGC_PROTOTYPE is
 * true; never on ogbbc.org). All presentation:
 *
 *   - A thin banner on every page: "Demo · made-up people" (Oct 28, for the COA: Caleb, "don't call it
 *     just an early version").
 *   - The dock (Oct 31; it holds the demo pill of Oct 29 and the feedback board's buttons as one unit). A
 *     small near-black capsule in the bottom right corner, in the demo's own look (the system font, one
 *     white for the one action), never the church site's tan, cream or serif, so no one takes it for part of the site
 *     (Michael: "make it clear that it's not part of the interface… we don't want it to just blend in").
 *       Its left part is the demo pill (Oct 29, in place of the Tour; Michael: "a selector that toggles
 *     between the different time periods… and a way to toggle to the back end", "just a little hover pill
 *     that then expands into each different option"): it says the day and who, "Mar 2 · Visitor".
 *     Hovered (it closes a moment after the pointer leaves), tapped or focused, it opens two short groups
 *     above it, each choice one click: When (six days of the coming Conference's year, 2027) and As
 *     (Visitor, COA, Lodging, Webmaster). The local site adds Today to When, and a third group, More.
 *       When keeps the day for the whole site, every page and its reads, as people click around
 *     (/dev-moment/ and ogc_dev_moment in core-dev.php); nothing chosen, the prototype shows Registration.
 *     As signs that made-up person in, or signs out, always through the dev sign-in (whoever was signed
 *     in before, by a code or otherwise, is signed out first), keeps the day, and lands on their page.
 *       Its right part (.ogc-pill__fb) is ogc-feedback.js's: Leave feedback, and this screen's count.
 *     The dock rises above a bar the page keeps at the foot of the screen (the form's, Your week's, the
 *     guide's tabs, the player, a toast) and above a control in a panel that stays put (the app's record
 *     panel's Save), so it never covers one.
 *   - In the shared prototype only, links that would leave the laptop (a phone number, a text, an email,
 *     Google Maps) show a small dark note instead (Oct 28 rehearsal: on a Mac paired with an iPhone, Help's
 *     "Call 911" places a real call), as the old mockups did.
 *
 * window.OGC_DOCK (for ogc-feedback.js): { el, slot, moment: {name, at, text}, who, travel(page, at, as),
 * lift() }, and the event "ogc-dock" on document once it's drawn. Every element of ours carries
 * data-ogc-tool, which the feedback screenshot leaves out.
 *
 * Every address follows OGC_WP.base and OGC_WP.home, because WordPress Playground serves the site under
 * /scope:…/. The dev sign-in, sign-out and moment (core-dev.php) take a return path relative to the
 * site's home.
 *
 * It also styles v3's mockup-only pills (.ogc-mock), which some pages still draw.
 */
(function () {
  'use strict';
  const W = window.OGC_WP || {};
  if (!W.dev && !W.prototype) return;
  // Framed by one of our own pages (the app's "See it" pane): draw nothing there. WordPress Playground also
  // runs the whole site in a frame, but its parent isn't ours, so the pill and banner still draw.
  const framed = (() => { try { return window.top !== window && !!(window.parent && window.parent.OGC_WP); } catch (e) { return false; } })();
  const base = W.base || '/annual-conference/';
  const home = W.home || '/';
  // The page's path from the site's home ("annual-conference/"), for the dev routes' return=.
  const baseRel = base.indexOf(home) === 0 ? base.slice(home.length) : base.replace(/^\//, '');
  const rel = path => '/' + baseRel + path;
  const enc = encodeURIComponent;
  const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
  const LS = {
    get(k, d) { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch (e) { return d; } },
    set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { /* nothing kept */ } }
  };
  const TZ = (W.moment && W.moment.tz) || 'America/Indiana/Indianapolis';

  // Made-up people (seed/members.json). extra: the dev sign-in's own flags.
  const P = {
    coa: { email: 'nathan.keller@example.com', name: 'Nathan K.' },
    lodging: { email: 'joel.marsh@example.com', name: 'Joel M.' },
    web: { email: 'webmaster@example.com', name: 'Webmaster', extra: '&webmaster=1&name=Webmaster' },
    food: { email: 'silas.grant@example.com', name: 'Food' },
    transport: { email: 'phoebe.lane@example.com', name: 'Transportation' }
  };
  // When: six days of 2027's year, each just after its part went up in the sample (announced Nov 1, 2026;
  // registration open Feb 25 – May 21; the schedule public Mar 15 and the packet May 11: module-app-seed.php),
  // and During at 2:30 PM on the Saturday, at the venue. [name, at, the pill's short date, the date in full]
  const MOMENTS = [['Announced', '2026-11-10T09:00', 'Nov 10', 'Nov 10, 2026'], ['Registration', '2027-03-02T09:00', 'Mar 2', 'Mar 2, 2027'],
    ['Schedule out', '2027-03-18T09:00', 'Mar 18', 'Mar 18, 2027'], ['Week before', '2027-05-21T09:00', 'May 21', 'May 21, 2027'],
    ['During', '2027-05-29T14:30', 'May 29', 'May 29, 2:30 PM'], ['After', '2027-06-10T09:00', 'June 10', 'June 10, 2027']];
  // As: who, and the page they land on. [name, key of P ('' signs out), path from the Conference page, the person]
  const AS = [['Visitor', '', '?year=2027', ''], ['COA', 'coa', 'app/?year=2027', 'Nathan K.'],
    ['Lodging', 'lodging', 'app/?year=2027&s=lod-rooms', 'Joel M.'], ['Webmaster', 'web', 'app/?year=2027&s=years', '']];
  // The local site keeps the old list's other stops (Oct 12: one place to look); the prototype doesn't.
  // null: as whoever is signed in now.
  const MORE = [
    ['The packet', 'packet/?year=2027&as-of=2027-05-21', null],
    ['Tournaments', 'tournaments/?year=2027', null],
    ['Food', 'app/?year=2027', 'food'],
    ['Transportation head', 'app/?year=2027', 'transport'],
    ['Mail log', 'mail/', 'web']
  ];
  const local = !!W.dev && !W.prototype;

  // Always through the dev sign-in or sign-out (Oct 29: a code sign-in made in the page, after it drew,
  // left OGC_WP.me empty, so "already signed out" was taken on trust and Visitor kept the session).
  const as = (who, path) => who ? base + 'dev-signin/?email=' + enc(P[who].email) + (P[who].extra || '') + '&return=' + enc(rel(path))
    : base + 'dev-signout/?return=' + enc(rel(path));
  // This page again on another day: its address without the day (the server writes the new one in).
  function hereClean() {
    const u = new URL(location.href);
    u.searchParams.delete('as-of');
    u.searchParams.delete('pages');
    if (u.searchParams.get('tz') === TZ) u.searchParams.delete('tz');
    const p = u.pathname;
    return '/' + (p.indexOf(home) === 0 ? p.slice(home.length) : p.replace(/^\//, '')) + u.search;
  }
  const whenUrl = at => base + 'dev-moment/?' + (at ? 'at=' + enc(at) + '&' : '') + 'return=' + enc(hereClean());

  // Where the page is now: the day in its address (the server put the chosen one there), and who.
  const MON = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'June', 'July', 'Aug', 'Sept', 'Oct', 'Nov', 'Dec'];
  const shortDate = iso => { const m = /^(\d{4})-(\d\d)-(\d\d)/.exec(iso || ''); return m ? MON[+m[2] - 1] + ' ' + (+m[3]) : ''; };
  const curAt = (new URLSearchParams(location.search).get('as-of') || '').slice(0, 16);
  const mi = MOMENTS.findIndex(m => curAt && curAt.slice(0, 10) === m[1].slice(0, 10));
  const me = W.me ? String(W.me.email || '').toLowerCase() : '';
  const ai = AS.findIndex(a => a[1] ? P[a[1]].email === me && (a[1] !== 'web' || W.webmaster) : !me);
  const shortName = n => { const w = String(n || '').trim().split(/\s+/).filter(Boolean); return w.length > 1 && !/\.$/.test(w[w.length - 1]) ? w[0] + ' ' + w[w.length - 1].charAt(0) + '.' : w.join(' '); };
  const whenShort = mi > -1 ? MOMENTS[mi][2] : curAt ? shortDate(curAt) : 'Today';
  const whoShort = ai > -1 ? AS[ai][0] : (W.me && shortName(W.me.name)) || me || 'Visitor';
  // For the feedback board (ogc-feedback.js): the moment an idea is about.
  const momentText = mi > -1 ? MOMENTS[mi][0] + ' · ' + MOMENTS[mi][3] : curAt || 'Today';

  // Another page on a day, as someone (the board's Go to screen). page: a path from the site's home
  // ("/annual-conference/register/?year=2027"); at: the day ("2027-03-02T09:00"); asName: one of As's names.
  // Through dev-signin or dev-signout when that's not who's here now, then dev-moment, then the page.
  function travel(page, at, asName) {
    let target = '/' + String(page || '').replace(/^\/+/, '');
    try {
      const u = new URL(target, location.origin);
      ['as-of', 'pages'].forEach(k => u.searchParams.delete(k));
      if (u.searchParams.get('tz') === TZ) u.searchParams.delete('tz');
      target = u.pathname + u.search;
    } catch (e) { /* as it was */ }
    let url = target;
    if (W.dev && /^\d{4}-\d\d-\d\dT\d\d:\d\d$/.test(at || '')) url = '/' + baseRel + 'dev-moment/?at=' + enc(at) + '&return=' + enc(url);
    const k = AS.findIndex(x => x[0] === asName);
    if (W.dev && k > -1 && k !== ai) {
      const who = AS[k][1];
      url = '/' + baseRel + (who ? 'dev-signin/?email=' + enc(P[who].email) + (P[who].extra || '') + '&' : 'dev-signout/?') + 'return=' + enc(url);
      forget();
    }
    location.href = home.replace(/\/$/, '') + url;
  }

  const CARET = '<svg viewBox="0 0 12 12" aria-hidden="true"><path d="M2.5 7.5 6 4l3.5 3.5" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  // The demo's own look (Oct 31): tool chrome over the page, never the site's tan, cream or serif.
  const SANS = 'system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,sans-serif';

  const css =
    // The banner: the demo's label, in the demo's look.
    '.ogc-pbar{position:relative;z-index:62;margin:0;padding:6px 16px;background:#161616;color:#d4d4d4;text-align:center;font:400 12.5px/1.35 ' + SANS + ';letter-spacing:0}' +
    '.ogc-pbar b{color:#d4d4d4;font-weight:600}' +
    // The dock: one near-black capsule in the corner. --ogc-pill-lift is the page's own bar or control at
    // the foot of the screen, measured (lift()).
    '.ogc-pill{position:fixed;right:16px;bottom:calc(16px + var(--ogc-pill-lift,0px) + env(safe-area-inset-bottom));z-index:61;box-sizing:border-box;display:flex;align-items:center;max-width:calc(100vw - 32px);height:44px;border-radius:22px;background:#161616;color:#f2f2f2;box-shadow:inset 0 0 0 1px rgba(255,255,255,.09),0 8px 24px rgba(0,0,0,.26),0 1px 3px rgba(0,0,0,.2);font:500 13px/1.2 ' + SANS + ';letter-spacing:0;-webkit-font-smoothing:antialiased;text-transform:none}' +
    '.ogc-pill[hidden]{display:none}.ogc-pill *{box-sizing:border-box}' +
    // The card is placed against the whole dock (its right edge), not the pill's part: the pill sits at the
    // dock's left, and a card from there would run off the screen's right edge.
    '.ogc-pill__pick{position:static;display:flex;flex:none;height:44px}' +
    '.ogc-pill__btn{display:inline-flex;align-items:center;gap:7px;height:44px;min-height:44px;margin:0;padding:0 12px 0 16px;border:0;border-radius:22px;background:transparent;color:#f2f2f2;font:500 13px/1.2 ' + SANS + ';white-space:nowrap;cursor:pointer}' +
    '.ogc-pill__btn:hover,.ogc-pill.is-open .ogc-pill__btn{background:rgba(255,255,255,.08)}' +
    '.ogc-pill__btn svg{flex:none;width:12px;height:12px;color:#a3a3a3}.ogc-pill.is-open .ogc-pill__btn svg{transform:rotate(180deg)}' +
    // The feedback board's part (ogc-feedback.js fills it), after a hairline.
    '.ogc-pill__fb{display:flex;align-items:center;flex:none;height:44px}.ogc-pill__fb[hidden]{display:none}' +
    '.ogc-pill__pick+.ogc-pill__fb::before{content:"";flex:none;width:1px;height:20px;margin:0 2px;background:rgba(255,255,255,.16)}' +
    // Open: the card above the pill. The menu's own foot (8 px, clear) joins the two, so the pointer moving
    // from the pill into the card never leaves it.
    '.ogc-pill__menu{position:absolute;right:0;bottom:100%;padding-bottom:8px;visibility:hidden;opacity:0;pointer-events:none}' +
    '.ogc-pill.is-open .ogc-pill__menu{visibility:visible;opacity:1;pointer-events:auto}' +
    '.ogc-pill__card{box-sizing:border-box;width:min(312px,calc(100vw - 32px));max-height:calc(100vh - 112px - var(--ogc-pill-lift,0px));overflow:auto;padding:8px 10px 10px;border-radius:16px;background:#161616;color:#f2f2f2;box-shadow:inset 0 0 0 1px rgba(255,255,255,.09),0 16px 40px rgba(0,0,0,.34)}' +
    '.ogc-pill__lab{margin:6px 6px 4px;color:#a3a3a3;font-size:12px;font-weight:600;letter-spacing:0}' +
    '.ogc-pill__lab:not(:first-child){margin-top:12px}' +
    '.ogc-pill__grid{display:grid;grid-template-columns:1fr 1fr;gap:4px;list-style:none;margin:0;padding:0}' +
    '.ogc-pill__card a{box-sizing:border-box;display:flex;flex-direction:column;justify-content:center;min-height:44px;padding:5px 10px;border-radius:10px;color:#f2f2f2;text-decoration:none;font-size:13.5px;line-height:1.25}' +
    '.ogc-pill__card a b{font-weight:600}.ogc-pill__card a span{color:#a3a3a3;font-size:12px}' +
    '.ogc-pill__card a:hover{background:rgba(255,255,255,.07)}' +
    // The current day and person: the accent, and an edge (not by colour alone).
    '.ogc-pill__card a[aria-current]{background:rgba(255,255,255,.12);color:#fff;box-shadow:inset 0 0 0 1px rgba(255,255,255,.3)}.ogc-pill__card a[aria-current] span{color:#e6e6e6}' +
    // One focus ring, the demo's accent, drawn inside each control so it's always on the dark surface.
    '.ogc-pill :focus-visible{outline:2px solid #f2f2f2;outline-offset:-2px}.ogc-pill__card :focus-visible{outline-offset:0}' +
    '.ogc-pill :focus:not(:focus-visible){outline:none}' +
    '.ogc-pill__sr{position:absolute;width:1px;height:1px;margin:-1px;padding:0;overflow:hidden;clip:rect(0 0 0 0);white-space:nowrap;border:0}' +
    // Motion only to show the card come from the pill, and the dock rising over a bar; none when reduced.
    '@media (prefers-reduced-motion:no-preference){.ogc-pill{transition:bottom .16s ease-out}.ogc-pill__menu{transform:translateY(4px);transition:opacity .12s ease-out,transform .12s ease-out,visibility 0s linear .12s}.ogc-pill.is-open .ogc-pill__menu{transform:none;transition:opacity .12s ease-out,transform .12s ease-out,visibility 0s}}' +
    // v3's mockup-only pills
    '.ogc-mock{display:inline-flex;align-items:center;min-height:44px;padding:6px 14px;border:0;border-radius:999px;background:#161616;color:#e6e6e6;font:600 12px/1.2 ' + SANS + ';letter-spacing:0;cursor:pointer;text-decoration:none}' +
    '.ogc-mock:hover{background:#2a2a2a}.ogc-mock:focus-visible{outline:2px solid #f2f2f2;outline-offset:2px}' +
    '.ogc-mock--tag{min-height:0;padding:3px 10px;font-size:12px;cursor:default}.ogc-mock--tag:hover{background:#161616}' +
    // The prototype's note for a link that would leave the laptop: in the demo's look, just above the
    // dock (and so above the page's own bar at its foot when there is one).
    '.ogc-pnote{position:fixed;left:50%;bottom:calc(72px + var(--ogc-pill-lift,0px) + env(safe-area-inset-bottom));z-index:70;transform:translateX(-50%);box-sizing:border-box;width:max-content;max-width:min(440px,calc(100vw - 32px));margin:0;padding:10px 16px;border-radius:12px;background:#161616;color:#e6e6e6;box-shadow:inset 0 0 0 1px rgba(255,255,255,.09),0 8px 24px rgba(0,0,0,.26);font:400 14px/1.4 ' + SANS + ';text-align:center}' +
    '.ogc-pnote b{color:#d4d4d4;font-weight:600}.ogc-pnote[hidden]{display:none}' +
    '@media print{.ogc-pbar,.ogc-pill,.ogc-mock,.ogc-pnote{display:none!important}}';

  function banner() {
    if (document.querySelector('.ogc-pbar')) return;
    const b = document.createElement('p');
    b.className = 'ogc-pbar';
    b.setAttribute('role', 'note');
    b.innerHTML = '<b>Demo</b> · made-up people';
    document.body.insertBefore(b, document.body.firstChild);
  }

  // The shared prototype runs on a laptop, often on a projector: a link that would leave it (a phone
  // number, a text, an email, Google Maps) says what it does on a phone instead (Oct 28 rehearsal: Help's
  // "Call 911" is a real tel: link, and a Mac paired with an iPhone places the call). Never on ogbbc.org:
  // this script isn't there, and this runs only with OGC_PROTOTYPE.
  const MAPS = /^https?:\/\/((www\.)?google\.[a-z.]+\/maps|maps\.google\.[a-z.]+\/|goo\.gl\/maps|maps\.app\.goo\.gl\/|maps\.apple\.com\/)/i;
  function outside(a) {
    const h = (a.getAttribute('href') || '').trim();
    if (/^tel:/i.test(h)) {
      let n = '';
      try { n = decodeURIComponent(h.slice(4)); } catch (e) { n = h.slice(4); }
      n = n.split(/[,;#]/)[0].replace(/[^\d+]/g, '').replace(/^\+?1(?=\d{10}$)/, '').replace(/^(\d{3})(\d{3})(\d{4})$/, '$1-$2-$3');
      return 'On a phone, this calls ' + (n || 'the number');
    }
    if (/^sms:/i.test(h)) return 'On a phone, this starts a text';
    if (/^mailto:/i.test(h)) return 'This starts an email';
    if (/^geo:/i.test(h)) return 'On a phone, this opens the map';
    if (MAPS.test(a.href || h)) return /travelmode=walking/i.test(a.href) ? 'This opens Google Maps walking directions' : /\/dir\//i.test(a.href) ? 'This opens Google Maps directions' : 'This opens Google Maps';
    return '';
  }
  function guard() {
    if (!W.prototype) return;
    let note = null, timer = 0;
    document.addEventListener('click', e => {
      const a = e.target.closest && e.target.closest('a[href]');
      if (!a || e.defaultPrevented) return;
      const what = outside(a);
      if (!what) return;
      e.preventDefault();
      e.stopPropagation();
      if (!note) {
        note = document.createElement('p');
        note.className = 'ogc-pnote';
        note.setAttribute('role', 'status');
        note.setAttribute('data-ogc-tool', '');
        document.body.appendChild(note);
      }
      note.innerHTML = '<b>Demo</b> · ' + esc(what);
      note.hidden = false;
      clearTimeout(timer);
      timer = setTimeout(() => { note.hidden = true; }, 3500);
    }, true);
  }

  // Signing in as someone else: what this browser kept for the last person goes too (a pending email, the
  // registration form's draft in this tab), as the account menu's Sign out does (ogc-account.js forget).
  function forget() {
    try { localStorage.removeItem('ogc-me-pending'); } catch (x) { /* nothing kept */ }
    try { Object.keys(sessionStorage).filter(k => k.indexOf('ogc-register-draft-') === 0).forEach(k => sessionStorage.removeItem(k)); } catch (x) { /* nothing kept */ }
  }

  // The dock: the demo pill (when the dev sign-in is here) and the feedback board's slot.
  function dock() {
    const el = document.createElement('div');
    el.className = 'ogc-pill';
    el.setAttribute('data-ogc-tool', '');
    el.setAttribute('data-ogc-moment', momentText);
    el.innerHTML = '<div class="ogc-pill__fb" hidden></div>';
    document.body.appendChild(el);
    const slot = el.querySelector('.ogc-pill__fb');
    if (W.dev) pill(el); // As signs people in, which only the dev sign-in can do
    // Nothing in it yet (the prototype without the pill, the board not here): not drawn.
    const empty = () => !el.querySelector('.ogc-pill__pick') && slot.hidden;
    el.hidden = empty();
    try { new MutationObserver(() => { el.hidden = empty(); }).observe(slot, { attributes: true, attributeFilter: ['hidden'] }); } catch (e) { /* drawn as it was */ }
    lifter(el);
    window.OGC_DOCK = {
      el, slot, travel, lift: () => el._lift && el._lift(),
      moment: { name: mi > -1 ? MOMENTS[mi][0] : '', at: curAt, text: momentText },
      who: whoShort
    };
    try { document.dispatchEvent(new Event('ogc-dock')); } catch (e) { /* ogc-feedback.js looks for OGC_DOCK too */ }
  }

  function pill(el) {
    const opt = (href, name, sub, cur, kind, extra) => '<li><a href="' + esc(href) + '" data-k="' + kind + '"' + (extra || '') + (cur ? ' aria-current="true"' : '') + '><b>' + esc(name) + '</b>' + (sub ? '<span>' + esc(sub) + '</span>' : '') + '</a></li>';
    const group = (name, items) => '<p class="ogc-pill__lab" id="ogc-pill-' + name.toLowerCase() + '">' + name + '</p>' +
      '<ul class="ogc-pill__grid" aria-labelledby="ogc-pill-' + name.toLowerCase() + '">' + items.join('') + '</ul>';
    // The local site's Today: the real time again (the prototype always shows one of the six days).
    const now = new Date(), todayLong = MON[now.getMonth()] + ' ' + now.getDate() + ', ' + now.getFullYear();
    const when = (local ? [opt(whenUrl(''), 'Today', todayLong, !curAt, 'when', ' data-at=""')] : [])
      .concat(MOMENTS.map((m, i) => opt(whenUrl(m[1]), m[0], m[3], i === mi, 'when', ' data-at="' + m[1] + '"')));
    const who = AS.map((a, i) => opt(as(a[1], a[2]), a[0], a[3], i === ai, 'as', ' data-who="' + (a[1] ? esc(P[a[1]].email) : '') + '"'));
    const more = local ? MORE.map(x => opt(x[2] === null ? base + x[1] : as(x[2], x[1]), x[0], '', false, 'more', x[2] ? ' data-who="' + esc(P[x[2]].email) + '"' : '')) : null;

    const pick = document.createElement('div');
    pick.className = 'ogc-pill__pick';
    // The pill first, then its card (drawn above it), so Tab goes from the pill into the choices.
    pick.innerHTML =
      '<button type="button" class="ogc-pill__btn" aria-expanded="false" aria-controls="ogc-pill-menu" title="Day and person"><span class="ogc-pill__sr">Demo: </span>' +
      esc(whenShort + ' · ' + whoShort) + CARET + '</button>' +
      '<div class="ogc-pill__menu" id="ogc-pill-menu"><div class="ogc-pill__card" role="group" aria-label="Demo">' +
      group('When', when) + group('As', who) + (more ? group('More', more) : '') +
      '</div></div>';
    el.insertBefore(pick, el.firstChild);
    const btn = pick.querySelector('.ogc-pill__btn');
    const links = () => [...pick.querySelectorAll('.ogc-pill__card a')];

    // Open: by hover (a mouse), by a click or tap (it stays until a tap outside, Escape or another click),
    // or by the keyboard (focus, or Enter). how: 'hover' | 'click' | 'key'. Only the pill's own part
    // opens it: Leave feedback beside it never does.
    let open = false, how = '', shut = 0, soon = 0, hush = false, quiet = false;
    function set(o, by) {
      clearTimeout(shut); clearTimeout(soon);
      if (o && open) { if (by && by !== 'hover') how = by; return; }
      if (!o && !open) return;
      open = o; how = o ? by : '';
      el.classList.toggle('is-open', o);
      btn.setAttribute('aria-expanded', String(o));
      if (o && el._lift) el._lift();
    }
    const mouse = e => e.pointerType === 'mouse' || e.pointerType === 'pen';
    pick.addEventListener('pointerenter', e => {
      if (!mouse(e)) return;
      clearTimeout(shut);
      if (!open && !hush) soon = setTimeout(() => set(true, 'hover'), 60);
    });
    // A short wait before it closes, so a pointer crossing the gap or the card's edge doesn't shut it.
    pick.addEventListener('pointerleave', e => {
      if (!mouse(e)) return;
      clearTimeout(soon);
      hush = false;
      if (open && how === 'hover') shut = setTimeout(() => set(false), 320);
    });
    let lastPointer = '';
    btn.addEventListener('pointerdown', e => { lastPointer = e.pointerType; });
    btn.addEventListener('click', e => {
      const key = e.detail === 0; // Enter or Space
      if (!open) { set(true, key ? 'key' : 'click'); if (key) (pick.querySelector('.ogc-pill__card a[aria-current]') || links()[0]).focus(); return; }
      // Opened by hover or by focus: a click keeps it (Enter goes into it); opened by a click: it closes.
      if (how === 'hover' && !key) { how = 'click'; return; }
      if (how === 'key' && key && !pick.querySelector('.ogc-pill__card :focus')) { (pick.querySelector('.ogc-pill__card a[aria-current]') || links()[0]).focus(); return; }
      set(false);
      hush = mouse({ pointerType: lastPointer });
    });
    // The keyboard: focus on the pill opens it (Tab then moves through the choices).
    btn.addEventListener('focus', () => { if (!quiet && !open && btn.matches(':focus-visible')) set(true, 'key'); });
    pick.addEventListener('focusout', e => { if (open && how !== 'hover' && !(e.relatedTarget && pick.contains(e.relatedTarget)) && e.relatedTarget) set(false); });
    document.addEventListener('pointerdown', e => { if (open && !pick.contains(e.target)) set(false); }, true);
    document.addEventListener('keydown', e => {
      if (!open) return;
      const inside = pick.contains(document.activeElement);
      if (e.key === 'Escape') {
        set(false);
        if (inside) { quiet = true; btn.focus(); quiet = false; }
      } else if (inside && (e.key === 'ArrowDown' || e.key === 'ArrowUp')) {
        const all = links(), i = all.indexOf(document.activeElement);
        const next = e.key === 'ArrowDown' ? (i < 0 ? 0 : (i + 1) % all.length) : (i <= 0 ? all.length - 1 : i - 1);
        all[next].focus();
        e.preventDefault();
      }
    });

    // A choice: its day or person is noted here too, so a page the browser brings back from its cache
    // (Back) with another day or person is drawn again (pageshow below).
    pick.addEventListener('click', e => {
      const a = e.target.closest && e.target.closest('.ogc-pill__card a');
      if (!a) return;
      const kept = LS.get('ogc-pill', {}) || {};
      // This page as it is now (the app changes its address as people move about in it).
      if (a.hasAttribute('data-at')) { kept.at = a.getAttribute('data-at'); a.href = whenUrl(kept.at); }
      if (a.hasAttribute('data-who')) { kept.who = a.getAttribute('data-who'); forget(); }
      LS.set('ogc-pill', kept);
    });
    addEventListener('pageshow', e => {
      if (!e.persisted) return;
      const kept = LS.get('ogc-pill', null);
      if (kept && ((kept.at != null && kept.at.slice(0, 10) !== curAt.slice(0, 10)) || (kept.who != null && kept.who !== me))) location.reload();
    });
    // ?pages=1 opens it (as it did the old list): for a screenshot, or a link that should show it.
    if (new URLSearchParams(location.search).get('pages') === '1') setTimeout(() => set(true, 'click'), 0);
  }

  // Never over the page's own bar at the foot of the screen (the form's total and Next, Your week's bar,
  // the guide's tabs, the player, a toast and its Undo): measured where the dock rests, it rises above
  // whatever fixed bar is there, and above the next if bars are stacked. In a tall panel that stays put
  // (the app's record panel, sticky beside its list), it rises above a control under it (its Save) only
  // when no scrolling, the panel's or the page's, would bring that out from under the dock: so it doesn't
  // bob up and down as a panel's links pass under it. Not over a sheet or a dialog (those are above it).
  // foot: how far above the screen's foot the dock rests unlifted (16 px and the phone's safe area),
  // measured before it has moved, so a lift measured mid-motion still starts from its resting place.
  const CONTROL = 'a[href],button,input,select,textarea,summary,[role=button],[role=tab],[role=switch],[role=checkbox]';
  function lifter(el) {
    let cur = 0, tick = 0, foot = -1;
    const de = document.documentElement;
    // The top of what the dock must stay above, for one thing under it, or Infinity.
    function topOf(e) {
      let control = null;
      for (let x = e; x && x !== document.body && x !== de; x = x.parentElement) {
        if (el.contains(x) || x.tagName === 'DIALOG' || x.hasAttribute('data-ogc-tool') || /(^|\s)ogc-(pnote|pbar|fb)/.test(String(x.className))) return Infinity;
        if (!control && x.matches && x.matches(CONTROL)) control = x;
        const p = getComputedStyle(x).position;
        if (p !== 'fixed' && p !== 'sticky') continue;
        const b = x.getBoundingClientRect();
        if (!b.height) return Infinity;
        if (b.height <= innerHeight * 0.45 && b.top >= innerHeight * 0.4) return p === 'fixed' || b.bottom >= innerHeight - 4 ? b.top : Infinity;
        if (control) { const c = control.getBoundingClientRect(); return c.height && c.top >= innerHeight * 0.4 && !more(control, x, p === 'sticky') ? c.top : Infinity; }
        return Infinity;
      }
      return Infinity;
    }
    // Can scrolling still move this control: a scrolled box it's in (up to its panel), or, for a sticky
    // panel, the page?
    function more(c, panel, sticky) {
      for (let x = c.parentElement; x && x !== document.body && x !== de; x = x.parentElement) {
        const o = getComputedStyle(x).overflowY;
        if ((o === 'auto' || o === 'scroll') && x.scrollHeight - x.scrollTop - x.clientHeight > 1) return true;
        if (x === panel) break;
      }
      const se = document.scrollingElement || de;
      return sticky && se.scrollHeight - se.scrollTop - innerHeight > 1;
    }
    function lift() {
      tick = 0;
      if (el.hidden) return;
      const r = el.getBoundingClientRect();
      if (!r.width || !document.elementsFromPoint) return;
      if (foot < 0) foot = innerHeight - r.bottom - cur;
      const rest = innerHeight - foot, h = r.height, xs = [r.left + 8, r.left + r.width * 0.25, (r.left + r.right) / 2, r.left + r.width * 0.75, r.right - 8];
      let bottom = rest;
      for (let n = 0; n < 4; n++) {
        let top = Infinity;
        [bottom - 2, bottom - h / 2, bottom - h + 2].forEach(y => { if (y > 0) xs.forEach(x => document.elementsFromPoint(x, y).forEach(t => { top = Math.min(top, topOf(t)); })); });
        if (top === Infinity || top >= bottom) break;
        bottom = top - 8;
      }
      const up = Math.max(0, Math.round(rest - bottom));
      if (up === cur) return;
      cur = up;
      [el, de].forEach(x => { if (up) x.style.setProperty('--ogc-pill-lift', up + 'px'); else x.style.removeProperty('--ogc-pill-lift'); });
    }
    el._lift = lift;
    const soonLift = () => { if (!tick) tick = setTimeout(lift, 150); };
    addEventListener('resize', () => { if (!cur) foot = -1; soonLift(); });
    // Capturing, so a panel's own scroll counts too.
    document.addEventListener('scroll', soonLift, { passive: true, capture: true });
    try { new MutationObserver(m => { if (m.some(x => !el.contains(x.target))) soonLift(); }).observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ['class', 'hidden'] }); } catch (e) { /* it stays where it is */ }
    lift();
    setTimeout(lift, 400);
    setTimeout(lift, 1500);
  }

  function build() {
    const style = document.createElement('style');
    style.textContent = css;
    document.head.appendChild(style);
    guard();
    if (framed) return;
    banner();
    dock();
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', build); else build();
})();
