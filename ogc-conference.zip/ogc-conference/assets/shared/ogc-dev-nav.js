/*
 * ogc-dev-nav.js — LOCAL SITE ONLY (loaded only when OGC_DEV is true; never on ogbbc.org). v3's
 * floating "Pages" button (proto-nav.js) at the plugin's addresses: the walk-through's stops in order,
 * then who to be (the dev sign-in), then Start over. Unlike v3's, links aren't stopped: the local site
 * is the real thing.
 *
 * It also styles v3's mockup-only pills (.ogc-mock), which some pages still draw until their areas
 * take them out.
 */
(function () {
  'use strict';
  const W = window.OGC_WP || {};
  if (!W.dev) return;
  const base = W.base || '/annual-conference/';
  const here = location.pathname + location.search;
  const back = encodeURIComponent(here);
  const signin = (email, extra) => base + 'dev-signin/?email=' + encodeURIComponent(email) + (extra || '') + '&return=' + back;
  const app = (email, extra) => base + 'dev-signin/?email=' + encodeURIComponent(email) + (extra || '') + '&return=' + encodeURIComponent(base + 'app/?year=2027');
  // The one list of what to look at on the local site (Oct 12, Michael: one canonical place, not a file per
  // meeting). "Open the Conference site.html" at the top of the repo opens it with ?pages=1.
  const PAGES = [
    ['The Conference page', [
      ['Now', base, 'After 2026: recordings, minutes, next year'],
      ['Before Conference', base + '?year=2026&as-of=2026-05-25T09:00&view=full', 'The schedule, registration, the packet'],
      ['During Conference', base + '?year=2026&as-of=2026-06-06T14:45&tz=America/Indiana/Indianapolis', 'The week, seen from Indiana'],
      ['The guide', base + 'guide/?year=2026&as-of=2026-06-06T13:00', 'Phones at Conference · works offline'],
      ['Printed schedule', base + 'schedule/?year=2026', 'Printed from the same rows'],
      ['The packet', base + 'packet/?year=2026', 'The whole packet, to print']
    ]],
    ['Signing up', [
      ['Register', base + 'register/?year=2027', 'One form for the household'],
      ['Volunteer', base + 'volunteer/?year=2027', 'Shifts by committee'],
      ['Tournaments', base + 'tournaments/?year=2027', 'Young Folks teams'],
      ['Your sign-ups', base + 'register/?year=2027&view=mine', 'Everything one person signed up for']
    ]],
    ["The committees' app · signed in as", [
      ['COA', app('nathan.keller@example.com'), 'The whole year · the Committees board'],
      ['Lodging', app('joel.marsh@example.com'), 'Only Lodging’s screens'],
      ['Food', app('silas.grant@example.com'), 'Meal counts, menus, helpers'],
      ['Transportation head', app('phoebe.lane@example.com'), 'Its helpers and requests'],
      ['Webmaster', app('webmaster@example.com', '&webmaster=1&name=Webmaster'), 'Years and access']
    ]],
    ['Behind the scenes', [
      ['Mail log', signin('webmaster@example.com', '&webmaster=1&name=Webmaster').replace(/&return=.*$/, '&return=' + encodeURIComponent(base + 'mail/')), 'Every email the site would have sent'],
      ['Visitor', base + 'dev-signout/?return=' + back, 'Signed out']
    ]]
  ];
  const isHere = href => { const u = new URL(href, location.href); return u.pathname + u.search === here; };
  const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);

  const css = '.ogc-proto{position:fixed;right:12px;bottom:12px;z-index:61;font-family:var(--ogb-sans,Arial,sans-serif)}' +
    '.ogc-app .ogc-proto{bottom:calc(62px + 10px + env(safe-area-inset-bottom))}body.has-player .ogc-proto{bottom:96px}' +
    '.ogc-proto__btn{min-height:44px;border:0;border-radius:999px;padding:8px 16px;background:#1f1f1f;color:#e8c98f;cursor:pointer;font-size:12.5px;font-weight:700;letter-spacing:.5px;box-shadow:0 4px 14px rgba(0,0,0,.25)}' +
    '.ogc-proto__btn:focus-visible,.ogc-proto__menu a:focus-visible,.ogc-proto__menu button:focus-visible{outline:2px solid #e8c98f;outline-offset:2px}' +
    '.ogc-proto__menu{display:none;position:absolute;right:0;bottom:calc(100% + 8px);width:min(300px,calc(100vw - 24px));max-height:calc(100vh - 90px);overflow:auto;padding:6px;background:#1f1f1f;border-radius:12px;box-shadow:0 8px 24px rgba(0,0,0,.3)}' +
    '.ogc-proto.is-open .ogc-proto__menu{display:block}' +
    '.ogc-proto__v{margin-left:6px;padding:1px 6px;border-radius:999px;background:#e8c98f;color:#1f1f1f;font-size:10.5px}' +
    '.ogc-proto__k{margin:10px 10px 4px;color:#aaa;font-size:10.5px;font-weight:700;letter-spacing:1px;text-transform:uppercase}' +
    '.ogc-proto__menu ul{list-style:none;margin:0;padding:0}' +
    '.ogc-proto__menu a,.ogc-proto__menu button.ogc-proto__item{display:block;width:100%;min-height:40px;padding:7px 10px;border:0;border-radius:8px;background:none;color:#eee;text-align:left;text-decoration:none;cursor:pointer;font:inherit;font-size:13.5px}' +
    '.ogc-proto__menu a span,.ogc-proto__menu button span{display:block;color:#aaa;font-size:11.5px}' +
    '.ogc-proto__menu a[aria-current],.ogc-proto__menu a:hover,.ogc-proto__menu button:hover{background:#333}' +
    '.ogc-proto__end{margin-top:6px!important;padding-top:6px!important;border-top:1px solid #333!important}' +
    'body.has-regbar .ogc-proto{bottom:calc(84px + env(safe-area-inset-bottom))}' +
    '.ogc-mock{display:inline-flex;align-items:center;min-height:44px;padding:6px 14px;border:0;border-radius:999px;background:#1f1f1f;color:#e8c98f;font:700 12px/1.2 var(--ogb-sans,Arial,sans-serif);letter-spacing:.4px;cursor:pointer;text-decoration:none}' +
    '.ogc-mock:hover{background:#333}.ogc-mock:focus-visible{outline:2px solid #76623F;outline-offset:2px}' +
    '.ogc-mock--tag{min-height:0;padding:3px 10px;font-size:11px;cursor:default}.ogc-mock--tag:hover{background:#1f1f1f}' +
    '@media print{.ogc-proto,.ogc-mock{display:none!important}}';

  function build() {
    const style = document.createElement('style');
    style.textContent = css;
    document.head.appendChild(style);
    if ((() => { try { return window.top !== window; } catch (e) { return true; } })()) return;
    const who = W.me ? W.me.email : 'Visitor';
    const el = document.createElement('div');
    el.className = 'ogc-proto';
    el.innerHTML = '<button type="button" class="ogc-proto__btn" data-proto-toggle aria-expanded="false" aria-label="Local site: pages and who to be">Pages <span class="ogc-proto__v">local</span></button>' +
      '<div class="ogc-proto__menu">' +
      PAGES.map(g => '<p class="ogc-proto__k">' + esc(g[0]) + '</p><ul>' + g[1].map(p => '<li><a href="' + esc(p[1]) + '"' + (isHere(p[1]) ? ' aria-current="page"' : '') + '>' + esc(p[0]) + '<span>' + esc(p[2]) + '</span></a></li>').join('') + '</ul>').join('') +
      '<ul class="ogc-proto__end"><li><button type="button" class="ogc-proto__item" data-proto-clear>Start over<span>' + esc(who) + ' · Clears this browser’s keys' + (W.webmaster ? ' and reloads the seed' : '') + '</span></button></li></ul></div>';
    document.body.appendChild(el);
    const btn = el.querySelector('[data-proto-toggle]');
    const set = open => { el.classList.toggle('is-open', open); btn.setAttribute('aria-expanded', String(open)); };
    if (new URLSearchParams(location.search).get('pages') === '1') set(true);
    el.addEventListener('click', e => {
      if (e.target.closest('[data-proto-toggle]')) { set(!el.classList.contains('is-open')); return; }
      if (e.target.closest('[data-proto-clear]')) {
        try { Object.keys(localStorage).filter(k => /^ogc/.test(k)).forEach(k => localStorage.removeItem(k)); } catch (x) { /* nothing kept */ }
        const done = () => location.reload();
        if (W.webmaster && W.api) W.api('POST', 'dev/import', { force: true }).then(done, done); else done();
      }
    });
    document.addEventListener('keydown', e => { if (e.key === 'Escape' && el.classList.contains('is-open')) { set(false); btn.focus(); } });
    document.addEventListener('click', e => { if (!el.contains(e.target)) set(false); });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', build); else build();
})();
