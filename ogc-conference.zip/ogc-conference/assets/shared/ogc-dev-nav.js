/*
 * ogc-dev-nav.js — the local site and the shared prototype only (loaded when OGC_DEV or OGC_PROTOTYPE is
 * true; never on ogbbc.org). Three things, all presentation:
 *
 *   - A thin banner on every page: "Demo · made-up people" (Oct 28, for the COA: Caleb, "don't call it
 *     just an early version").
 *   - The demo pill (Oct 29; it replaces the Tour, now that every COA member clicks around on their own;
 *     Michael: "a selector that toggles between the different time periods… and a way to toggle to the
 *     back end", "just a little hover pill that then expands into each different option"). Closed, a
 *     small dark pill in the bottom right corner says the day and who: "Mar 2 · Visitor". Hovered (it
 *     closes a moment after the pointer leaves), tapped or focused, it opens two short groups, each choice
 *     one click: When (six days of the coming Conference's year, 2027) and As (Visitor, COA, Lodging,
 *     Webmaster). The local site adds Today to When, and a third group, More (the old list's other stops).
 *       When keeps the day for the whole site, every page and its reads, as people click around
 *     (/dev-moment/ and ogc_dev_moment in core-dev.php); nothing chosen, the prototype shows Registration.
 *     As signs that made-up person in, or signs out, always through the dev sign-in (whoever was signed
 *     in before, by a code or otherwise, is signed out first), keeps the day, and lands on their page.
 *     The pill rises above a bar the page keeps at the foot of the screen (the form's, Your week's, the
 *     guide's tabs, the player, a toast), so it never covers one.
 *   - In the shared prototype only, links that would leave the laptop (a phone number, a text, an email,
 *     Google Maps) show a small dark note instead (Oct 28 rehearsal: on a Mac paired with an iPhone, Help's
 *     "Call 911" places a real call), as the old mockups did.
 *
 * Every address follows OGC_WP.base and OGC_WP.home, because WordPress Playground serves the site under
 * /scope:…/. The dev sign-in, sign-out and moment (core-dev.php) take a return path relative to the
 * site's home.
 *
 * It also styles v3's mockup-only pills (.ogc-mock), which some pages still draw.
 */
(function () {
  'use strict';
  const W = window.OGC_WP || {};
  if (!W.dev && !W.prototype) return;
  // Framed by one of our own pages (the app's "See it" pane): draw nothing there. WordPress Playground also
  // runs the whole site in a frame, but its parent isn't ours, so the pill and banner still draw.
  const framed = (() => { try { return window.top !== window && !!(window.parent && window.parent.OGC_WP); } catch (e) { return false; } })();
  const base = W.base || '/annual-conference/';
  const home = W.home || '/';
  // The page's path from the site's home ("annual-conference/"), for the dev routes' return=.
  const baseRel = base.indexOf(home) === 0 ? base.slice(home.length) : base.replace(/^\//, '');
  const rel = path => '/' + baseRel + path;
  const enc = encodeURIComponent;
  const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
  const LS = {
    get(k, d) { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch (e) { return d; } },
    set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { /* nothing kept */ } }
  };
  const TZ = (W.moment && W.moment.tz) || 'America/Indiana/Indianapolis';

  // Made-up people (seed/members.json). extra: the dev sign-in's own flags.
  const P = {
    coa: { email: 'nathan.keller@example.com', name: 'Nathan K.' },
    lodging: { email: 'joel.marsh@example.com', name: 'Joel M.' },
    web: { email: 'webmaster@example.com', name: 'Webmaster', extra: '&webmaster=1&name=Webmaster' },
    food: { email: 'silas.grant@example.com', name: 'Food' },
    transport: { email: 'phoebe.lane@example.com', name: 'Transportation' }
  };
  // When: six days of 2027's year, each just after its part went up in the sample (announced Nov 1, 2026;
  // registration open Feb 25 – May 21; the schedule public Mar 15 and the packet May 11: module-app-seed.php),
  // and During at 2:30 PM on the Saturday, at the venue. [name, at, the pill's short date, the date in full]
  const MOMENTS = [['Announced', '2026-11-10T09:00', 'Nov 10', 'Nov 10, 2026'], ['Registration', '2027-03-02T09:00', 'Mar 2', 'Mar 2, 2027'],
    ['Schedule out', '2027-03-18T09:00', 'Mar 18', 'Mar 18, 2027'], ['Week before', '2027-05-21T09:00', 'May 21', 'May 21, 2027'],
    ['During', '2027-05-29T14:30', 'May 29', 'May 29, 2:30 PM'], ['After', '2027-06-10T09:00', 'June 10', 'June 10, 2027']];
  // As: who, and the page they land on. [name, key of P ('' signs out), path from the Conference page, the person]
  const AS = [['Visitor', '', '?year=2027', ''], ['COA', 'coa', 'app/?year=2027', 'Nathan K.'],
    ['Lodging', 'lodging', 'app/?year=2027&s=lod-rooms', 'Joel M.'], ['Webmaster', 'web', 'app/?year=2027&s=years', '']];
  // The local site keeps the old list's other stops (Oct 12: one place to look); the prototype doesn't.
  // null: as whoever is signed in now.
  const MORE = [
    ['The packet', 'packet/?year=2027&as-of=2027-05-21', null],
    ['Tournaments', 'tournaments/?year=2027', null],
    ['Food', 'app/?year=2027', 'food'],
    ['Transportation head', 'app/?year=2027', 'transport'],
    ['Mail log', 'mail/', 'web']
  ];
  const local = !!W.dev && !W.prototype;

  // Always through the dev sign-in or sign-out (Oct 29: a code sign-in made in the page, after it drew,
  // left OGC_WP.me empty, so "already signed out" was taken on trust and Visitor kept the session).
  const as = (who, path) => who ? base + 'dev-signin/?email=' + enc(P[who].email) + (P[who].extra || '') + '&return=' + enc(rel(path))
    : base + 'dev-signout/?return=' + enc(rel(path));
  // This page again on another day: its address without the day (the server writes the new one in).
  function hereClean() {
    const u = new URL(location.href);
    u.searchParams.delete('as-of');
    u.searchParams.delete('pages');
    if (u.searchParams.get('tz') === TZ) u.searchParams.delete('tz');
    const p = u.pathname;
    return '/' + (p.indexOf(home) === 0 ? p.slice(home.length) : p.replace(/^\//, '')) + u.search;
  }
  const whenUrl = at => base + 'dev-moment/?' + (at ? 'at=' + enc(at) + '&' : '') + 'return=' + enc(hereClean());

  // Where the page is now: the day in its address (the server put the chosen one there), and who.
  const MON = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'June', 'July', 'Aug', 'Sept', 'Oct', 'Nov', 'Dec'];
  const shortDate = iso => { const m = /^(\d{4})-(\d\d)-(\d\d)/.exec(iso || ''); return m ? MON[+m[2] - 1] + ' ' + (+m[3]) : ''; };
  const curAt = (new URLSearchParams(location.search).get('as-of') || '').slice(0, 16);
  const mi = MOMENTS.findIndex(m => curAt && curAt.slice(0, 10) === m[1].slice(0, 10));
  const me = W.me ? String(W.me.email || '').toLowerCase() : '';
  const ai = AS.findIndex(a => a[1] ? P[a[1]].email === me && (a[1] !== 'web' || W.webmaster) : !me);
  const shortName = n => { const w = String(n || '').trim().split(/\s+/).filter(Boolean); return w.length > 1 && !/\.$/.test(w[w.length - 1]) ? w[0] + ' ' + w[w.length - 1].charAt(0) + '.' : w.join(' '); };
  const whenShort = mi > -1 ? MOMENTS[mi][2] : curAt ? shortDate(curAt) : 'Today';
  const whoShort = ai > -1 ? AS[ai][0] : (W.me && shortName(W.me.name)) || me || 'Visitor';
  // For the Feedback button (ogc-feedback.js): the moment a note is about.
  const momentText = mi > -1 ? MOMENTS[mi][0] + ' · ' + MOMENTS[mi][3] : curAt || 'Today';

  const CARET = '<svg viewBox="0 0 12 12" aria-hidden="true"><path d="M2.5 7.5 6 4l3.5 3.5" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>';

  const css =
    // The banner
    '.ogc-pbar{position:relative;z-index:62;margin:0;padding:6px 16px;background:#333;color:#F3F2EB;text-align:center;font:400 12.5px/1.35 var(--ogb-sans,Arial,sans-serif);letter-spacing:.2px}' +
    // The pill: mockup chrome, dark like the .ogc-mock pills. --ogc-pill-lift is the page's own bar at the
    // foot of the screen, measured (lift()).
    '.ogc-pill{position:fixed;right:16px;bottom:calc(16px + var(--ogc-pill-lift,0px) + env(safe-area-inset-bottom));z-index:61;font-family:var(--ogb-sans,Arial,sans-serif)}' +
    '.ogc-pill__btn{box-sizing:border-box;display:inline-flex;align-items:center;gap:8px;min-height:44px;margin:0;padding:0 14px 0 16px;border:0;border-radius:999px;background:#1f1f1f;color:#e8c98f;font:700 12px/1.2 var(--ogb-sans,Arial,sans-serif);letter-spacing:.4px;white-space:nowrap;cursor:pointer;box-shadow:0 4px 14px rgba(0,0,0,.2)}' +
    '.ogc-pill__btn:hover,.ogc-pill.is-open .ogc-pill__btn{background:#141414}' +
    '.ogc-pill__btn svg{flex:none;width:12px;height:12px}.ogc-pill.is-open .ogc-pill__btn svg{transform:rotate(180deg)}' +
    // Open: the card above the pill. The menu's own foot (8 px, clear) joins the two, so the pointer moving
    // from the pill into the card never leaves it.
    '.ogc-pill__menu{position:absolute;right:0;bottom:100%;padding-bottom:8px;visibility:hidden;opacity:0;pointer-events:none}' +
    '.ogc-pill.is-open .ogc-pill__menu{visibility:visible;opacity:1;pointer-events:auto}' +
    '.ogc-pill__card{box-sizing:border-box;width:min(304px,calc(100vw - 32px));max-height:calc(100vh - 112px - var(--ogc-pill-lift,0px));overflow:auto;padding:8px 10px 10px;border-radius:14px;background:#141414;color:#eee;box-shadow:0 10px 30px rgba(0,0,0,.3)}' +
    '.ogc-pill__lab{margin:6px 6px 4px;color:#b8ae9b;font-size:12px;font-weight:700;letter-spacing:1.2px;text-transform:uppercase}' +
    '.ogc-pill__lab:not(:first-child){margin-top:12px}' +
    '.ogc-pill__grid{display:grid;grid-template-columns:1fr 1fr;gap:4px;list-style:none;margin:0;padding:0}' +
    '.ogc-pill__card a{box-sizing:border-box;display:flex;flex-direction:column;justify-content:center;min-height:44px;padding:5px 10px;border-radius:8px;color:#eee;text-decoration:none;font-size:13.5px;line-height:1.25}' +
    '.ogc-pill__card a b{font-weight:700}.ogc-pill__card a span{color:#b8ae9b;font-size:12px}' +
    '.ogc-pill__card a:hover{background:#262626}' +
    // The current day and person: the accent, and an edge (not by colour alone).
    '.ogc-pill__card a[aria-current]{background:#2a251c;color:#e8c98f;box-shadow:inset 0 0 0 1px #8a7650}.ogc-pill__card a[aria-current] span{color:#d9c7a2}' +
    // One focus ring, the site's tan text colour (on the card's near-black it keeps 3:1).
    '.ogc-pill :focus-visible{outline:2px solid #76623F;outline-offset:2px}' +
    '.ogc-pill__sr{position:absolute;width:1px;height:1px;margin:-1px;padding:0;overflow:hidden;clip:rect(0 0 0 0);white-space:nowrap;border:0}' +
    // Motion only to show the card come from the pill, and the pill rising over a bar; none when reduced.
    '@media (prefers-reduced-motion:no-preference){.ogc-pill{transition:bottom .16s ease-out}.ogc-pill__menu{transform:translateY(4px);transition:opacity .12s ease-out,transform .12s ease-out,visibility 0s linear .12s}.ogc-pill.is-open .ogc-pill__menu{transform:none;transition:opacity .12s ease-out,transform .12s ease-out,visibility 0s}}' +
    // v3's mockup-only pills
    '.ogc-mock{display:inline-flex;align-items:center;min-height:44px;padding:6px 14px;border:0;border-radius:999px;background:#1f1f1f;color:#e8c98f;font:700 12px/1.2 var(--ogb-sans,Arial,sans-serif);letter-spacing:.4px;cursor:pointer;text-decoration:none}' +
    '.ogc-mock:hover{background:#333}.ogc-mock:focus-visible{outline:2px solid #76623F;outline-offset:2px}' +
    '.ogc-mock--tag{min-height:0;padding:3px 10px;font-size:11px;cursor:default}.ogc-mock--tag:hover{background:#1f1f1f}' +
    // The prototype's note for a link that would leave the laptop: dark like the pill, just above it (and
    // so above the page's own bar at its foot when there is one).
    '.ogc-pnote{position:fixed;left:50%;bottom:calc(72px + var(--ogc-pill-lift,0px) + env(safe-area-inset-bottom));z-index:70;transform:translateX(-50%);box-sizing:border-box;width:max-content;max-width:min(440px,calc(100vw - 32px));margin:0;padding:10px 16px;border-radius:12px;background:#1f1f1f;color:#eee;box-shadow:0 4px 14px rgba(0,0,0,.25);font:400 14px/1.4 var(--ogb-sans,Arial,sans-serif);text-align:center}' +
    '.ogc-pnote b{color:#e8c98f}.ogc-pnote[hidden]{display:none}' +
    '@media print{.ogc-pbar,.ogc-pill,.ogc-mock,.ogc-pnote{display:none!important}}';

  function banner() {
    if (document.querySelector('.ogc-pbar')) return;
    const b = document.createElement('p');
    b.className = 'ogc-pbar';
    b.setAttribute('role', 'note');
    b.textContent = 'Demo · made-up people';
    document.body.insertBefore(b, document.body.firstChild);
  }

  // The shared prototype runs on a laptop, often on a projector: a link that would leave it (a phone
  // number, a text, an email, Google Maps) says what it does on a phone instead (Oct 28 rehearsal: Help's
  // "Call 911" is a real tel: link, and a Mac paired with an iPhone places the call). Never on ogbbc.org:
  // this script isn't there, and this runs only with OGC_PROTOTYPE.
  const MAPS = /^https?:\/\/((www\.)?google\.[a-z.]+\/maps|maps\.google\.[a-z.]+\/|goo\.gl\/maps|maps\.app\.goo\.gl\/|maps\.apple\.com\/)/i;
  function outside(a) {
    const h = (a.getAttribute('href') || '').trim();
    if (/^tel:/i.test(h)) {
      let n = '';
      try { n = decodeURIComponent(h.slice(4)); } catch (e) { n = h.slice(4); }
      n = n.split(/[,;#]/)[0].replace(/[^\d+]/g, '').replace(/^\+?1(?=\d{10}$)/, '').replace(/^(\d{3})(\d{3})(\d{4})$/, '$1-$2-$3');
      return 'On a phone, this calls ' + (n || 'the number');
    }
    if (/^sms:/i.test(h)) return 'On a phone, this starts a text';
    if (/^mailto:/i.test(h)) return 'This starts an email';
    if (/^geo:/i.test(h)) return 'On a phone, this opens the map';
    if (MAPS.test(a.href || h)) return /travelmode=walking/i.test(a.href) ? 'This opens Google Maps walking directions' : /\/dir\//i.test(a.href) ? 'This opens Google Maps directions' : 'This opens Google Maps';
    return '';
  }
  function guard() {
    if (!W.prototype) return;
    let note = null, timer = 0;
    document.addEventListener('click', e => {
      const a = e.target.closest && e.target.closest('a[href]');
      if (!a || e.defaultPrevented) return;
      const what = outside(a);
      if (!what) return;
      e.preventDefault();
      e.stopPropagation();
      if (!note) {
        note = document.createElement('p');
        note.className = 'ogc-pnote';
        note.setAttribute('role', 'status');
        document.body.appendChild(note);
      }
      note.innerHTML = '<b>Demo</b> · ' + esc(what);
      note.hidden = false;
      clearTimeout(timer);
      timer = setTimeout(() => { note.hidden = true; }, 3500);
    }, true);
  }

  // Signing in as someone else: what this browser kept for the last person goes too (a pending email, the
  // registration form's draft in this tab), as the account menu's Sign out does (ogc-account.js forget).
  function forget() {
    try { localStorage.removeItem('ogc-me-pending'); } catch (x) { /* nothing kept */ }
    try { Object.keys(sessionStorage).filter(k => k.indexOf('ogc-register-draft-') === 0).forEach(k => sessionStorage.removeItem(k)); } catch (x) { /* nothing kept */ }
  }

  function pill() {
    if (!W.dev) return; // As signs people in, which only the dev sign-in can do
    const opt = (href, name, sub, cur, kind, extra) => '<li><a href="' + esc(href) + '" data-k="' + kind + '"' + (extra || '') + (cur ? ' aria-current="true"' : '') + '><b>' + esc(name) + '</b>' + (sub ? '<span>' + esc(sub) + '</span>' : '') + '</a></li>';
    const group = (name, items) => '<p class="ogc-pill__lab" id="ogc-pill-' + name.toLowerCase() + '">' + name + '</p>' +
      '<ul class="ogc-pill__grid" aria-labelledby="ogc-pill-' + name.toLowerCase() + '">' + items.join('') + '</ul>';
    // The local site's Today: the real time again (the prototype always shows one of the six days).
    const now = new Date(), todayLong = MON[now.getMonth()] + ' ' + now.getDate() + ', ' + now.getFullYear();
    const when = (local ? [opt(whenUrl(''), 'Today', todayLong, !curAt, 'when', ' data-at=""')] : [])
      .concat(MOMENTS.map((m, i) => opt(whenUrl(m[1]), m[0], m[3], i === mi, 'when', ' data-at="' + m[1] + '"')));
    const who = AS.map((a, i) => opt(as(a[1], a[2]), a[0], a[3], i === ai, 'as', ' data-who="' + (a[1] ? esc(P[a[1]].email) : '') + '"'));
    const more = local ? MORE.map(x => opt(x[2] === null ? base + x[1] : as(x[2], x[1]), x[0], '', false, 'more', x[2] ? ' data-who="' + esc(P[x[2]].email) + '"' : '')) : null;

    const el = document.createElement('div');
    el.className = 'ogc-pill';
    el.setAttribute('data-ogc-moment', momentText);
    // The pill first, then its card (drawn above it), so Tab goes from the pill into the choices.
    el.innerHTML =
      '<button type="button" class="ogc-pill__btn" aria-expanded="false" aria-controls="ogc-pill-menu"><span class="ogc-pill__sr">Demo: </span>' +
      esc(whenShort + ' · ' + whoShort) + CARET + '</button>' +
      '<div class="ogc-pill__menu" id="ogc-pill-menu"><div class="ogc-pill__card" role="group" aria-label="Demo">' +
      group('When', when) + group('As', who) + (more ? group('More', more) : '') +
      '</div></div>';
    document.body.appendChild(el);
    const btn = el.querySelector('.ogc-pill__btn');
    const links = () => [...el.querySelectorAll('.ogc-pill__card a')];

    // Open: by hover (a mouse), by a click or tap (it stays until a tap outside, Escape or another click),
    // or by the keyboard (focus, or Enter). how: 'hover' | 'click' | 'key'.
    let open = false, how = '', shut = 0, soon = 0, hush = false, quiet = false;
    function set(o, by) {
      clearTimeout(shut); clearTimeout(soon);
      if (o && open) { if (by && by !== 'hover') how = by; return; }
      if (!o && !open) return;
      open = o; how = o ? by : '';
      el.classList.toggle('is-open', o);
      btn.setAttribute('aria-expanded', String(o));
      if (o) lift();
    }
    const mouse = e => e.pointerType === 'mouse' || e.pointerType === 'pen';
    el.addEventListener('pointerenter', e => {
      if (!mouse(e)) return;
      clearTimeout(shut);
      if (!open && !hush) soon = setTimeout(() => set(true, 'hover'), 60);
    });
    // A short wait before it closes, so a pointer crossing the gap or the card's edge doesn't shut it.
    el.addEventListener('pointerleave', e => {
      if (!mouse(e)) return;
      clearTimeout(soon);
      hush = false;
      if (open && how === 'hover') shut = setTimeout(() => set(false), 320);
    });
    let lastPointer = '';
    btn.addEventListener('pointerdown', e => { lastPointer = e.pointerType; });
    btn.addEventListener('click', e => {
      const key = e.detail === 0; // Enter or Space
      if (!open) { set(true, key ? 'key' : 'click'); if (key) (el.querySelector('.ogc-pill__card a[aria-current]') || links()[0]).focus(); return; }
      // Opened by hover or by focus: a click keeps it (Enter goes into it); opened by a click: it closes.
      if (how === 'hover' && !key) { how = 'click'; return; }
      if (how === 'key' && key && !el.querySelector('.ogc-pill__card :focus')) { (el.querySelector('.ogc-pill__card a[aria-current]') || links()[0]).focus(); return; }
      set(false);
      hush = mouse({ pointerType: lastPointer });
    });
    // The keyboard: focus on the pill opens it (Tab then moves through the choices).
    btn.addEventListener('focus', () => { if (!quiet && !open && btn.matches(':focus-visible')) set(true, 'key'); });
    el.addEventListener('focusout', e => { if (open && how !== 'hover' && !(e.relatedTarget && el.contains(e.relatedTarget)) && e.relatedTarget) set(false); });
    document.addEventListener('pointerdown', e => { if (open && !el.contains(e.target)) set(false); }, true);
    document.addEventListener('keydown', e => {
      if (!open) return;
      const inside = el.contains(document.activeElement);
      if (e.key === 'Escape') {
        set(false);
        if (inside) { quiet = true; btn.focus(); quiet = false; }
      } else if (inside && (e.key === 'ArrowDown' || e.key === 'ArrowUp')) {
        const all = links(), i = all.indexOf(document.activeElement);
        const next = e.key === 'ArrowDown' ? (i < 0 ? 0 : (i + 1) % all.length) : (i <= 0 ? all.length - 1 : i - 1);
        all[next].focus();
        e.preventDefault();
      }
    });

    // A choice: its day or person is noted here too, so a page the browser brings back from its cache
    // (Back) with another day or person is drawn again (pageshow below).
    el.addEventListener('click', e => {
      const a = e.target.closest && e.target.closest('.ogc-pill__card a');
      if (!a) return;
      const kept = LS.get('ogc-pill', {}) || {};
      // This page as it is now (the app changes its address as people move about in it).
      if (a.hasAttribute('data-at')) { kept.at = a.getAttribute('data-at'); a.href = whenUrl(kept.at); }
      if (a.hasAttribute('data-who')) { kept.who = a.getAttribute('data-who'); forget(); }
      LS.set('ogc-pill', kept);
    });
    addEventListener('pageshow', e => {
      if (!e.persisted) return;
      const kept = LS.get('ogc-pill', null);
      if (kept && ((kept.at != null && kept.at.slice(0, 10) !== curAt.slice(0, 10)) || (kept.who != null && kept.who !== me))) location.reload();
    });

    // Never over the page's own bar at the foot of the screen (the form's total and Next, Your week's bar,
    // the guide's tabs, the player, a toast and its Undo): measured where the pill rests, it rises above
    // whatever fixed bar is there, and above the next if bars are stacked. Not over a sheet, a dialog or a
    // side panel (those are taller, or above the pill anyway).
    // foot: how far above the screen's foot the pill rests unlifted (16 px and the phone's safe area),
    // measured before it has moved, so a lift measured mid-motion still starts from its resting place.
    let cur = 0, tick = 0, foot = -1;
    const de = document.documentElement;
    function fixedOf(e) {
      for (let x = e; x && x !== document.body && x !== de; x = x.parentElement) {
        if (el.contains(x) || x.tagName === 'DIALOG' || /(^|\s)ogc-(pnote|pbar|fb)/.test(String(x.className))) return null;
        const p = getComputedStyle(x).position;
        if (p !== 'fixed' && p !== 'sticky') continue;
        const b = x.getBoundingClientRect();
        if (!b.height || b.height > innerHeight * 0.45 || b.top < innerHeight * 0.4) return null;
        return p === 'fixed' || b.bottom >= innerHeight - 4 ? b : null;
      }
      return null;
    }
    function lift() {
      tick = 0;
      const r = btn.getBoundingClientRect();
      if (!r.width || !document.elementsFromPoint) return;
      if (foot < 0) foot = innerHeight - r.bottom - cur;
      const rest = innerHeight - foot, h = r.height, xs = [r.left + 6, (r.left + r.right) / 2, r.right - 6];
      let bottom = rest;
      for (let n = 0; n < 4; n++) {
        let top = Infinity;
        [bottom - 2, bottom - h / 2, bottom - h + 2].forEach(y => { if (y > 0) xs.forEach(x => document.elementsFromPoint(x, y).forEach(t => { const b = fixedOf(t); if (b) top = Math.min(top, b.top); })); });
        if (top === Infinity) break;
        bottom = top - 8;
      }
      const up = Math.max(0, Math.round(rest - bottom));
      if (up === cur) return;
      cur = up;
      [el, de].forEach(x => { if (up) x.style.setProperty('--ogc-pill-lift', up + 'px'); else x.style.removeProperty('--ogc-pill-lift'); });
    }
    const soonLift = () => { if (!tick) tick = setTimeout(lift, 150); };
    addEventListener('resize', () => { if (!cur) foot = -1; soonLift(); });
    addEventListener('scroll', soonLift, { passive: true });
    try { new MutationObserver(m => { if (m.some(x => !el.contains(x.target))) soonLift(); }).observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ['class', 'hidden'] }); } catch (e) { /* it stays where it is */ }
    lift();
    setTimeout(lift, 400);
    setTimeout(lift, 1500);
    // ?pages=1 opens it (as it did the old list): for a screenshot, or a link that should show it.
    if (new URLSearchParams(location.search).get('pages') === '1') set(true, 'click');
  }

  function build() {
    const style = document.createElement('style');
    style.textContent = css;
    document.head.appendChild(style);
    guard();
    if (framed) return;
    banner();
    pill();
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', build); else build();
})();
