/*
 * ogc-store.js — the year's data on the server, behind the same functions v3's pages already call.
 * It replaces v3's ogc-local-edits.js (which kept the COA's changes in one browser). Load it after
 * ogc-core.js and before any page script.
 *
 *   O.edits  { get, merge, saveRow, saveFile, setKey, setYear, mergeYears, clear }  as v3, but:
 *            - the server holds every file already merged, so merge()/mergeYears() hand back the
 *              server's rows (exactly, "_id"/"_look" and all) for a file the page has read;
 *            - a change shows at once in this browser, and is sent in order (the wp_rest nonce,
 *              retried while offline); "ogc:save" events say Saving · Saved · Offline · Not saved.
 *   O.records { load, list, store, kinds }  people's records (what this viewer may see), for the
 *            copy of ogc-signups.js (SU.load / SU.store).
 *   O.state  { load, get, has, set }  a year's small values kept on the server (members only).
 *   O.store  { ready, status, flush }  O.ready is store.ready: the years and this page's records.
 *
 * Writes:
 *   saveFile  → PUT   /years/{y}/files/{name} {rows, version}. If someone else saved in between
 *               (409), an "ogc:conflict" event is sent; unless a listener calls preventDefault(),
 *               this browser's rows are saved over theirs (v3's editors have no merge yet).
 *   saveRow   → PATCH /years/{y}/files/{name} {op:'row', row}   (merged on the server)
 *   setKey    → PATCH /years/{y}/files/{name} {op:'key', key, value}
 *   setYear   → PATCH /years/{y} {fields}
 */
(function () {
  'use strict';
  const O = window.OGC, W = window.OGC_WP || {};
  if (!O || !W.api) return;
  const api = W.api;
  const copy = r => Object.assign({}, r);
  const ev = (name, detail, cancelable) => { const e = new CustomEvent(name, { detail, cancelable: !!cancelable }); window.dispatchEvent(e); return e; };

  /* ------------------------------------------------------------ the cache */

  const files = {};        // 'year/name' → { rows, cols, version, pending }
  let years = null;        // years.csv's rows, as the server has them
  const fkey = (y, n) => String(y) + '/' + n;
  const colsOf = (rows, cols) => { const c = (cols || []).slice(); rows.forEach(r => Object.keys(r).forEach(k => { if (c.indexOf(k) < 0) c.push(k); })); return c; };
  const csvCell = v => { v = v == null ? '' : String(v); return /[",\r\n]/.test(v) || /^\s|\s$/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v; };
  const csvText = (rows, cols) => { const c = colsOf(rows, cols); if (!c.length) return ''; return [c.map(csvCell).join(',')].concat(rows.map(r => c.map(k => csvCell(r[k])).join(','))).join('\n') + '\n'; };
  const csvResponse = (rows, cols) => new Response(csvText(rows, cols), { status: 200, headers: { 'Content-Type': 'text/csv; charset=utf-8' } });
  const YEAR_COLS = ['year', 'start', 'end', 'venue', 'city', 'hosts', 'data', 'page', 'coa_announced', 'announced'];

  // One request shared by everything that asks within a moment of it (O.ready and the page's own
  // years.csv read asked twice on every visit; conference area, polish 1).
  let yearsReq = null, yearsAt = 0;
  // A page may arrive with its first answers inlined (OGC_WP.preload: years, bundle[y], records[y]),
  // used once and only while fresh, so the first draw waits for no request (register area, polish 1).
  const P = W.preload && Date.now() / 1000 - (W.preload.at || 0) < 600 ? W.preload : null;
  const pre = (k, y) => { if (!P) return null; const v = y == null ? P[k] : (P[k] || {})[y]; if (y == null) delete P[k]; else if (P[k]) delete P[k][y]; return v || null; };
  function loadYears() {
    if (!yearsReq || Date.now() - yearsAt > 2000) { yearsAt = Date.now(); yearsReq = loadYearsNow().catch(e => { yearsReq = null; throw e; }); }
    return yearsReq;
  }
  async function loadYearsNow() {
    const rows = pre('years') || await api('GET', 'years');
    // A year changed here and not yet saved keeps this browser's fields.
    if (years && queue.some(op => op.type === 'year')) return years;
    years = (rows || []).map(r => { const o = {}; Object.keys(r).forEach(k => { o[k] = r[k] == null ? '' : String(r[k]); }); return o; });
    return years;
  }

  // A year's files are read all at once (each request is a whole WordPress start): GET
  // /years/{y}/bundle, shared by every read within a moment of it. On the local site and the shared
  // prototype a page previewing a day (?as-of=) reads them as the public would have them that day
  // (core-dev.php ogc_dev_preview_at: never for a Conference already over).
  const bundles = {};
  const asOf = W.dev ? (new URLSearchParams(location.search).get('as-of') || '').slice(0, 16) : '';
  const asOfQ = /^\d{4}-\d{2}-\d{2}/.test(asOf) ? '?as_of=' + encodeURIComponent(asOf) : '';
  function yearBundle(y) {
    const b = bundles[y];
    if (b && (b.loading || Date.now() - b.at < 2000)) return b.promise;
    const nb = bundles[y] = { loading: true, at: 0 };
    const pb = pre('bundle', y);
    nb.promise = (pb ? Promise.resolve(pb) : api('GET', 'years/' + y + '/bundle' + asOfQ)).then(d => {
      Object.keys(d || {}).forEach(n => {
        const k = fkey(y, n), f = files[k];
        if (f && f.pending) return;  // changed here, not yet saved: this browser's rows stand
        files[k] = { rows: d[n].rows || [], cols: d[n].cols || [], version: d[n].version || 0, pending: 0 };
      });
      // A file the server no longer has (or this person may no longer read) is empty.
      Object.keys(files).forEach(k => { const [fy, n] = k.split('/'); if (fy === String(y) && !(d || {})[n] && !files[k].pending) files[k] = { rows: [], cols: [], version: 0, pending: 0, unread: true }; });
      nb.loading = false; nb.at = Date.now();
    }, e => { delete bundles[y]; throw e; });
    return nb.promise;
  }

  // ogc-wp.js hands every read of …/schedule/data/… here: the server's rows (kept), or this
  // browser's while a change to that file is still being sent. A file that isn't there reads empty.
  W.data = async function (path) {
    try {
      if (path === 'years.csv') return csvResponse(await loadYears(), YEAR_COLS);
      const m = /^(\d{4})\/([a-z][a-z0-9_-]*)\.csv$/.exec(path);
      if (!m) return new Response('', { status: 404 });
      const k = fkey(m[1], m[2]), f = files[k];
      if (f && f.pending) {
        // A file only patched here (never read) is read once the patches are on the server.
        if (f.unread) await flush(); else return csvResponse(f.rows, f.cols);
      }
      await yearBundle(m[1]);
      const now = files[k];
      return now && !now.unread ? csvResponse(now.rows, now.cols) : new Response('', { status: 200, headers: { 'Content-Type': 'text/csv; charset=utf-8' } });
    } catch (e) {
      return new Response('', { status: e.status || 503 });
    }
  };

  /* ------------------------------------------------------------ O.edits */

  // Rows saved one at a time are found by this column (an area adds its own: OGC_WP.rowKeys).
  const KEY = Object.assign({ help: 'need', places: 'code', nearby: 'name' }, W.rowKeys || {});

  // The rows this page read, as the server keeps them (or as just changed here).
  function merge(year, name, rows) {
    const f = files[fkey(year, name)];
    return f && !f.unread ? f.rows.map(copy) : rows;
  }
  function mergeYears(rows) {
    if (!years) return rows;
    return years.map(copy);
  }
  // v3's shape: { _file: { name: rows } } for the files this page has read of the year.
  function get(year) {
    const out = { _file: {} };
    Object.keys(files).forEach(k => { const [y, n] = k.split('/'); if (y === String(year) && !files[k].unread) out._file[n] = files[k].rows.map(copy); });
    return out;
  }
  function touch(year, name) {
    const k = fkey(year, name);
    return files[k] || (files[k] = { rows: [], cols: [], version: 0, pending: 0, unread: true });
  }
  function saveFile(year, name, rows) {
    const f = touch(year, name);
    f.unread = false;
    f.rows = (rows || []).map(copy);
    f.cols = colsOf(f.rows, f.cols);
    f.pending++;
    // A later save of the same file replaces one not yet sent.
    if (!queue.some((op, i) => (i > 0 || !busy) && op.type === 'put' && op.year == year && op.name === name)) enqueue({ type: 'put', year: String(year), name });
    else { f.pending--; }
  }
  function saveRow(year, name, row) {
    const k = fkey(year, name), f = files[k];
    if (f && !f.unread) {
      const key = KEY[name], i = key ? f.rows.findIndex(x => x[key] === row[key]) : -1;
      if (i > -1) { if (row._gone) f.rows.splice(i, 1); else f.rows[i] = Object.assign({}, f.rows[i], row); }
      else if (!row._gone) f.rows.push(copy(row));
      f.cols = colsOf(f.rows, f.cols);
    }
    touch(year, name).pending++;
    enqueue({ type: 'row', year: String(year), name, row: copy(row) });
  }
  function setKey(year, name, k, v) {
    const f = files[fkey(year, name)];
    if (f && !f.unread) {
      const r = f.rows.find(x => x.key === k);
      if (r) r.value = v; else f.rows.push({ key: k, value: v, help: '' });
    }
    touch(year, name).pending++;
    enqueue({ type: 'key', year: String(year), name, key: k, value: v == null ? '' : String(v) });
  }
  function setYear(year, field, v) {
    if (years) {
      let r = years.find(x => x.year === String(year));
      if (!r) { r = { year: String(year) }; years.push(r); years.sort((a, b) => b.year - a.year); }
      r[field] = v == null ? '' : String(v);
    }
    enqueue({ type: 'year', year: String(year), fields: { [field]: v == null ? '' : String(v) } });
  }
  // v3's "Clear my changes": nothing is kept in the browser now. (Locally, the dev import route
  // reloads the seed: tools/wp-local.sh, DEV.md.)
  function clear() { /* the server keeps the year */ }

  // The pages' loader, as ogc-core.js's, with each file as the server keeps it.
  const yearOf = url => (String(url).match(/(\d{4})\/?$/) || [])[1] || '';
  const need = ['settings', 'schedule', 'places', 'contacts'];
  const names = need.concat(['attachments', 'milestones', 'guide', 'notices', 'help', 'nearby', 'menus']);
  O.loadSchedule = function (baseUrl) {
    const y = yearOf(baseUrl);
    const getText = n => fetch(baseUrl + n + '.csv', { cache: 'no-store' }).then(r => {
      if (r.ok) return r.text();
      if (need.indexOf(n) > -1) throw new Error(n + '.csv could not be loaded (' + r.status + ')');
      return '';
    }, err => { if (need.indexOf(n) > -1) throw err; return ''; });
    return Promise.all(names.map(getText)).then(texts => {
      const src = {};
      names.forEach((n, i) => { src[n] = merge(y, n, O.csvToObjects(texts[i])); });
      return O.buildSchedule(src);
    });
  };

  O.edits = { get, merge, saveRow, saveFile, setKey, setYear, mergeYears, clear };

  /* ------------------------------------------------------------ sending, in order */

  const queue = [];
  let busy = false, wait = 0, state = 'saved';
  const status = (s, extra) => { state = s; ev('ogc:save', Object.assign({ state: s, pending: queue.length }, extra || {})); };
  function enqueue(op) { queue.push(op); status('saving'); pump(); }
  const sleep = ms => new Promise(r => setTimeout(r, ms));

  async function send(op) {
    if (op.type === 'put') {
      const f = files[fkey(op.year, op.name)];
      const r = await api('PUT', 'years/' + op.year + '/files/' + op.name, { rows: f.rows, cols: f.cols, version: f.version });
      f.version = r.version; f.unread = false;
    } else if (op.type === 'row' || op.type === 'key') {
      const body = op.type === 'row' ? { op: 'row', row: op.row } : { op: 'key', key: op.key, value: op.value };
      const r = await api('PATCH', 'years/' + op.year + '/files/' + op.name, body);
      const f = files[fkey(op.year, op.name)];
      if (f) f.version = r.version;
    } else if (op.type === 'year') {
      await api('PATCH', 'years/' + op.year, { fields: op.fields });
    } else if (op.type === 'state') {
      const s = st[skey(op.year, op.key)];
      const r = await api('PUT', 'years/' + op.year + '/state/' + encodeURIComponent(op.key), { value: s.value });
      s.version = r.version;
    } else if (op.type === 'rec') {
      await sendRecord(op);
    }
  }
  function settled(op) {
    if (op.type === 'put' || op.type === 'row' || op.type === 'key') { const f = files[fkey(op.year, op.name)]; if (f) f.pending = Math.max(0, f.pending - 1); }
    if (op.type === 'state') { const s = st[skey(op.year, op.key)]; if (s) s.pending = Math.max(0, s.pending - 1); }
  }
  async function pump() {
    if (busy) return;
    busy = true;
    while (queue.length) {
      const op = queue[0];
      try {
        await send(op);
        queue.shift(); settled(op); wait = 0;
        // Tells a page framed beside this one (See it) to show the change (ogc-wp.js).
        try { localStorage.setItem('ogc-saved', String(Date.now())); } catch (x) { /* not framed */ }
      } catch (e) {
        if (e.status === 409 && op.type === 'put') {
          // Someone else saved this file since it was read.
          const d = await api('GET', 'years/' + op.year + '/files/' + op.name + '?format=json').catch(() => null);
          const f = files[fkey(op.year, op.name)];
          const c = ev('ogc:conflict', { year: op.year, name: op.name, theirs: d && d.rows, mine: f && f.rows }, true);
          if (d && f) {
            f.version = d.version;
            if (c.defaultPrevented) { f.rows = d.rows; f.cols = d.cols; queue.shift(); settled(op); }
          }
          continue;
        }
        if (e.status && e.status < 500 && e.status !== 408 && e.status !== 429) {
          // Refused (not signed in, not a member, not valid): not sent again.
          queue.shift(); settled(op);
          console.error('Not saved', op.type, op.name || op.kind || op.key || '', e.status, e.message);
          status('error', { status: e.status, op });
          continue;
        }
        // Offline or the server busy: try again, a little later each time.
        status('offline');
        wait = Math.min(30000, wait ? wait * 2 : 1000);
        await sleep(wait);
      }
    }
    busy = false;
    if (state !== 'error') status('saved'); else ev('ogc:save', { state: 'saved', pending: 0 });
  }
  window.addEventListener('beforeunload', e => { if (queue.length) { e.preventDefault(); e.returnValue = ''; } });
  // Wait until everything changed so far has been sent (or refused).
  const flush = () => new Promise(res => { if (!queue.length && !busy) return res(); const on = () => { if (!queue.length) { window.removeEventListener('ogc:save', on); res(); } }; window.addEventListener('ogc:save', on); });

  /* ------------------------------------------------------------ O.state */

  const st = {};
  const skey = (y, k) => String(y) + '|' + k;
  const State = {
    load(year, key) {
      const k = skey(year, key);
      if (st[k] && st[k].pending) return Promise.resolve(st[k].value);
      return api('GET', 'years/' + year + '/state/' + encodeURIComponent(key))
        .then(d => { st[k] = { value: d.value, version: d.version, pending: 0, loaded: true }; return d.value; },
          e => { if (e.status === 404) st[k] = { value: null, version: 0, pending: 0, loaded: true }; return null; });
    },
    get(year, key, fallback) { const s = st[skey(year, key)]; return s && s.value != null ? s.value : fallback; },
    has(year, key) { const s = st[skey(year, key)]; return !!(s && s.value != null); },
    loaded(year, key) { const s = st[skey(year, key)]; return !!(s && s.loaded); },
    set(year, key, value) {
      const k = skey(year, key), s = st[k] || (st[k] = { value: null, version: 0, pending: 0, loaded: true });
      s.value = value; s.pending++;
      if (!queue.some((op, i) => (i > 0 || !busy) && op.type === 'state' && op.year == year && op.key === key)) enqueue({ type: 'state', year: String(year), key });
      else s.pending--;
    }
  };
  O.state = State;

  /* ------------------------------------------------------------ O.records */

  // kind|year → { list: [data objects, each with _rid (its id); others' public views also _pub], snap: {rid: json}, loaded }
  const recs = {};
  const KINDS = ['signups', 'registrations', 'credits', 'waits', 'teams'];
  const rkey = (kind, year) => kind + '|' + year;
  const strip = o => { const c = Object.assign({}, o); delete c._rid; delete c._pub; delete c.mine; return c; };
  const sameItem = (a, b) => a.id != null && String(a.id) === String(b.id) && String(a.email || '').toLowerCase() === String(b.email || '').toLowerCase() && String(a.name || '') === String(b.name || '');
  const loading = {};
  // Records being created: the object → { dropped } (taken out of the list before the server answered).
  const posting = new Map();

  function take(kind, year, list) {
    const r = recs[rkey(kind, year)] = { list: [], snap: {}, loaded: true };
    (list || []).forEach(x => {
      const o = Object.assign({}, x.data || {}, { _rid: x.id });
      if (x.public) o._pub = true;
      r.list.push(o);
      if (!x.public) r.snap[x.id] = JSON.stringify(strip(o));
    });
  }
  const Records = {
    kinds: KINDS,
    // Everything this person may see of a year's records (members: all; others: their own and the
    // public views). Loaded once per year; again with force.
    load(year, kinds, force) {
      kinds = kinds || KINDS;
      const want = kinds.filter(k => force || !(recs[rkey(k, year)] && recs[rkey(k, year)].loaded));
      if (!want.length || !/^\d{4}$/.test(String(year))) return Promise.resolve();
      const id = year + ':' + want.join(',');
      if (loading[id]) return loading[id];
      const pr = pre('records', year);
      return (loading[id] = (pr && want.every(k => k in pr) ? Promise.resolve(pr) : api('GET', 'years/' + year + '/records?kinds=' + want.join(',') + (W.recordScope ? '&scope=' + encodeURIComponent(W.recordScope) : '')))
        .then(d => { want.forEach(k => take(k, year, d && d[k])); ev('ogc:records', { year: String(year), kinds: want }); },
          e => { console.error('Records not loaded', year, e.status); want.forEach(k => { if (!recs[rkey(k, year)]) recs[rkey(k, year)] = { list: [], snap: {}, loaded: false }; }); })
        .then(() => { delete loading[id]; }));
    },
    loaded(kind, year) { const r = recs[rkey(kind, year)]; return !!(r && r.loaded); },
    // A copy of the list (the objects themselves are shared, so a change made to one is seen by store()).
    list(kind, year) { const r = recs[rkey(kind, year)]; return r ? r.list.slice() : null; },
    // The list as it now stands: what was added is created, what changed is saved, what's gone is
    // removed. Others' public views (_pub) are never written.
    store(kind, year, list) {
      const k = rkey(kind, year), r = recs[k] || (recs[k] = { list: [], snap: {}, loaded: true });
      const old = r.list, seen = {}, fresh = [];
      (list || []).forEach(o => {
        if (!o || typeof o !== 'object') return;
        if (o._pub) { if (o._rid) seen[o._rid] = 1; return; }
        if (posting.has(o)) { posting.get(o).dropped = false; seen.posting = (seen.posting || []).concat([o]); return; }
        if (o._rid && r.snap[o._rid] != null) {
          seen[o._rid] = 1;
          const j = JSON.stringify(strip(o));
          if (j !== r.snap[o._rid]) { r.snap[o._rid] = j; enqueue({ type: 'rec', act: 'put', kind, year: String(year), obj: o }); }
        } else fresh.push(o);
      });
      const gone = old.filter(o => o._rid && !o._pub && !seen[o._rid] && r.snap[o._rid] != null);
      // One still being created and no longer in the list: removed once the server has it.
      posting.forEach((p, o) => { if (p.kind === k && (seen.posting || []).indexOf(o) < 0) p.dropped = true; });

      fresh.forEach(o => {
        // The same item written anew (v3 often rebuilds a record): saved over the one it replaces.
        const i = gone.findIndex(g => sameItem(g, o));
        if (i > -1) {
          o._rid = gone[i]._rid; gone.splice(i, 1);
          r.snap[o._rid] = JSON.stringify(strip(o));
          enqueue({ type: 'rec', act: 'put', kind, year: String(year), obj: o });
        } else {
          delete o._rid;
          posting.set(o, { kind: k, dropped: false });
          enqueue({ type: 'rec', act: 'post', kind, year: String(year), obj: o });
        }
      });
      gone.forEach(o => { delete r.snap[o._rid]; enqueue({ type: 'rec', act: 'delete', kind, year: String(year), obj: o }); });
      r.list = (list || []).slice();
    }
  };
  async function sendRecord(op) {
    const r = recs[rkey(op.kind, op.year)];
    if (op.act === 'post') {
      const sent = JSON.stringify(strip(op.obj));
      const d = await api('POST', 'years/' + op.year + '/records/' + op.kind, { data: JSON.parse(sent) });
      const p = posting.get(op.obj);
      posting.delete(op.obj);
      op.obj._rid = d.id;
      if (r) r.snap[d.id] = sent;
      // Changed or taken out while it was being created: sent again, or removed.
      if (p && p.dropped) { if (r) delete r.snap[d.id]; queue.splice(1, 0, { type: 'rec', act: 'delete', kind: op.kind, year: op.year, obj: op.obj }); }
      else if (JSON.stringify(strip(op.obj)) !== sent) { if (r) r.snap[d.id] = JSON.stringify(strip(op.obj)); queue.splice(1, 0, { type: 'rec', act: 'put', kind: op.kind, year: op.year, obj: op.obj }); }
    } else if (op.act === 'put') {
      if (!op.obj._rid) return;
      await api('PUT', 'records/' + op.obj._rid, { data: strip(op.obj) });
    } else if (op.act === 'delete') {
      await api('DELETE', 'records/' + op.obj._rid).catch(e => { if (e.status !== 404) throw e; });
    }
  }
  O.records = Records;

  /* ------------------------------------------------------------ ready */

  // The years, and the records of the page's year and the one before (forms start from last year's).
  const q = new URLSearchParams(location.search);
  const ready = loadYears().catch(() => null).then(rows => {
    const want = [];
    const y = q.get('year') || q.get('data');
    if (/^\d{4}$/.test(y || '')) want.push(y, String(+y - 1));
    else (rows || []).filter(r => r.data).slice(0, 2).forEach(r => want.push(r.year));
    // A page may ask for fewer (OGC_WP.recordKinds, and recordYears: 1 for its own year only).
    if (W.recordYears === 1) want.splice(1);
    return Promise.all(want.map(z => Records.load(z, W.recordKinds || undefined)));
  }).catch(err => { console.error(err); });
  O.store = { ready, status: () => state, flush, csvText };
  O.ready = ready;
})();
