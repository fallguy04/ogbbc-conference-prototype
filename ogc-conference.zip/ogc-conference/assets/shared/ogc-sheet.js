/* The Conference app's sheet and its layers (docs/35 §2.3, §2.7, §3.2; Nov 6, round 1).
 *
 * O.sheet.docked(el, o): a sheet over a canvas (Places): no scrim, the canvas stays live. Its stops are
 *   lip (44, only while tucked), peek, half and full; one that adds nothing over the one below is dropped.
 *   el holds .ogc-sheet__grab (the grabber, a button) and .ogc-sheet__body (what it shows).
 *   o.stops()   → { peek, half, full }: how tall each is, in px (the app measures its own content)
 *   o.floor()   → px under it (the tab bar on the plain map; 0 under a layer)
 *   o.below()   → it was dragged or flicked down past its peek: the app closes the place, or tucks
 *   o.raised()  → dragged up from its lip: the app untucks
 *   o.settled(stop) → a stop reached (the map's inset is set here, never during a drag)
 *   o.moved(top, ms) → its top moved (what rides on it, Locate and the credit, follows), ms the ease
 *   → { el, body, set(stop, how), measure(), stop, h, top(), tucked, tuck(on, how), leave(fn) }
 *   how: 'ease' (200–280 ms by distance), 'jump', or 'rise' (from below the screen, 280 ms).
 *
 * O.sheet.modal(html, o): the app's one sheet over a list (round 3: the event, a Help need, a place, care
 *   nearby, Share, the menus), with the scrim (U10) and e3. Two stops: open (its content, at most 62% of
 *   the screen; o.fit: all of it) and full (24 px under the status bar); a drag or flick down from open
 *   closes it. Its top row (the grabber, o.head at the left, o.tools and × at the right) always moves the
 *   sheet; the body hands off to its own scroll at full (§2.3). From 768 px it's the centred dialog (W4).
 *   A layer: Back and Esc close the top one only; a sheet over a sheet dims the one under it.
 *   o: { head, tools, label, className, fit, url (the layer's address), opener, refocus(), onClose(how),
 *        node (an element moved in), prep(el) (before it's measured), here ('own': on its own entry, opened
 *        again by Back) }
 *   → { el, body (the content), scroller, head, close(how), leave() (put away, its entry kept),
 *       set(stop, how), html(body, head), isOpen(), stop }
 *   how 'go' (closed to go somewhere: no focus back).
 *
 * O.layers: one history entry for each layer open (a place, the planner, a modal sheet); Back closes the
 *   top one. push(name, { close, url, here }) (here: on the entry it's on, 'tab' or 'own'; round 3's fix
 *   pass) · swap(name, { close, url }) (another of the same kind over it: the address changes, no entry
 *   added) · pop(n) (closed by the app: its entries go, nothing closes twice) · drop(l) (off the stack,
 *   its entry kept) · names() · state() (for a tab's own entry, so coming back to it doesn't close a layer) ·
 *   after(fn) (fn once a layer's Back has landed: what a closing sheet opens next waits for it) ·
 *   sameView(a, b) (two addresses differing only in a layer's own keys: to, dirs, room, event, need,
 *   care, at, share).
 *
 * The same drag for both kinds: the whole sheet drags; the body moves the sheet until it's at its tallest
 * stop and only then scrolls (and back, in one gesture); a flick faster than 0.5 px/ms (the last 80 ms)
 * goes on to the next stop; a move under 6 px is a tap; past the ends it follows at a third. Under reduced
 * motion the finger still moves it; stops and the rest jump. Tucked, a drag or flick up on the lip untucks.
 * Only a keyboard's focus raises a docked sheet.
 */
(function () {
  'use strict';
  const O = window.OGC = window.OGC || {};
  const still = () => !!(window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches);
  const LIP = 44, TAP = 6, FLICK = 0.5, SPAN = 80;
  const EASE = 'cubic-bezier(.2, .8, .2, 1)';
  // The last input was a key (Tab, an arrow, Enter), not a finger or a mouse.
  let keyed = false;
  addEventListener('keydown', e => { if (!e.metaKey && !e.ctrlKey) keyed = true; }, true);
  addEventListener('pointerdown', () => { keyed = false; }, true);
  const X = '<svg viewBox="0 0 24 24" aria-hidden="true" width="20" height="20"><path d="M6 6l12 12M18 6 6 18" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>';

  /* ------------------------------------------------------------ the drag (both kinds) */

  // k: { stops() → [{ name, h }] lowest first, h() the height shown, put(h) (no ease), settle(stop),
  //      below() (true: past the lowest it follows 1:1 and may close), off(v) (closed by the drag),
  //      lip() (true: tucked: a drag up untucks), up(), head (true: a drag that starts outside the body,
  //      on the sheet's top row, always moves the sheet and never the body's scroll; the modal's) }
  function drag(el, body, k) {
    let g = null, eat = false, glide = 0;
    const hiOf = () => { const s = k.stops(); return s[s.length - 1].h; };
    const loOf = () => k.stops()[0].h;
    const maxScroll = () => Math.max(0, body.scrollHeight - body.clientHeight);
    // Tucked, the lip is the only stop: a drag up moves the sheet (to untuck), never the hidden list.
    const lipped = () => !!(k.lip && k.lip());
    function show(raw) {
      const hi = hiOf(), lo = loOf();
      let h = raw;
      if (h > hi) h = hi + (h - hi) / 3;
      else if (h < lo && !k.below()) h = lo - (lo - h) / 3;
      k.put(Math.max(0, h));
    }
    // One move of the finger, up positive: the sheet up to its tallest, then the body; down, the body
    // back to its top, then the sheet.
    function step(d) {
      const hi = hiOf(), max = lipped() || g.head ? 0 : maxScroll();
      if (d > 0) {
        if (g.raw < hi) { const t = Math.min(d, hi - g.raw); g.raw += t; d -= t; }
        if (d > 0 && g.raw >= hi && body.scrollTop < max) { const t = Math.min(d, max - body.scrollTop); body.scrollTop += t; d -= t; g.scrolled = true; }
        if (d > 0) g.raw += d;
      } else if (d < 0) {
        if (g.raw > hi) { const t = Math.min(-d, g.raw - hi); g.raw -= t; d += t; }
        if (d < 0 && g.raw >= hi - .5 && body.scrollTop > 0 && !lipped() && !g.head) { const t = Math.min(-d, body.scrollTop); body.scrollTop -= t; d += t; g.scrolled = true; }
        if (d < 0) g.raw += d;
      }
      show(g.raw);
    }
    const speed = (s, t, y) => {
      const a = s.filter(p => p.t >= t - SPAN).concat([{ t, y }]);
      if (a.length < 2) return 0;
      const dt = a[a.length - 1].t - a[0].t;
      return dt > 0 ? (a[0].y - a[a.length - 1].y) / dt : 0;
    };
    function coast(v) {
      cancelAnimationFrame(glide);
      let last = performance.now();
      const f = now => {
        const dt = Math.min(48, now - last); last = now;
        const before = body.scrollTop;
        body.scrollTop = Math.max(0, Math.min(maxScroll(), before + v * dt));
        v *= Math.pow(.95, dt / 16);
        if (Math.abs(v) > .02 && body.scrollTop !== before) glide = requestAnimationFrame(f);
      };
      glide = requestAnimationFrame(f);
    }
    // A gesture's move, end and cancel are heard on the window while it lasts (added at its start, gone at
    // its end): the page drawn again under the finger (the minute's redraw moves the app into a new slot,
    // which drops the touch's capture) never leaves a gesture open, so the sheet never freezes (round 1's
    // check). A new touch with another one still open drops the old one first.
    const hear = on => ['pointermove', 'pointerup', 'pointercancel'].forEach(t => window[on ? 'addEventListener' : 'removeEventListener'](t, t === 'pointermove' ? move : end, true));
    function drop() {
      if (!g) return;
      const G = g; g = null; hear(false);
      el.classList.remove('is-dragging');
      if (G.moved) { const st = k.stops(), h = k.h(); k.settle(st.reduce((m, s) => Math.abs(s.h - h) < Math.abs(m.h - h) ? s : m, st[0]).name); }
    }
    el.addEventListener('pointerdown', e => {
      if ((e.pointerType === 'mouse' && e.button !== 0) || (k.on && !k.on())) return;
      if (g) { if (e.pointerId === g.id) return; drop(); }
      // (A field or a link that drags on its own isn't the sheet's.)
      if (e.target.closest && e.target.closest('input, textarea, select, [data-sheet-own]')) return;
      cancelAnimationFrame(glide);
      g = { id: e.pointerId, x0: e.clientX, y0: e.clientY, y: e.clientY, raw: k.h(), moved: false, scrolled: false, s: [{ t: e.timeStamp, y: e.clientY }], mouse: e.pointerType === 'mouse', at: performance.now(), head: !!k.head && !body.contains(e.target) };
      hear(true);
    });
    function move(e) {
      if (!g || e.pointerId !== g.id) return;
      g.at = performance.now();
      if (!g.moved) {
        const dx = Math.abs(e.clientX - g.x0), dy = Math.abs(e.clientY - g.y0);
        if (dx < TAP && dy < TAP) return;
        if (dx > dy * 1.5) { g = null; hear(false); return; }
        g.moved = true;
        el.classList.add('is-dragging');
        k.put(k.h());
        if (g.mouse) { try { el.setPointerCapture(e.pointerId); } catch (x) { /* it follows while over the sheet */ } }
      }
      step(g.y - e.clientY);
      g.y = e.clientY;
      g.s.push({ t: e.timeStamp, y: e.clientY });
      if (g.s.length > 12) g.s.shift();
      if (e.cancelable) e.preventDefault();
    }
    function end(e) {
      if (!g || e.pointerId !== g.id) return;
      const G = g; g = null; hear(false);
      el.classList.remove('is-dragging');
      if (!G.moved) return;
      eat = true; setTimeout(() => { eat = false; }, 400);
      const v = e.type === 'pointercancel' ? 0 : speed(G.s, e.timeStamp, e.clientY), st = k.stops(), hi = st[st.length - 1].h, lo = st[0].h, h = k.h();
      // Dragged up from the lip: everything comes back.
      if (k.lip && k.lip()) { if (h > LIP + 20 || v > FLICK) k.up(); else k.settle('lip'); return; }
      // The body was scrolling at the tallest stop: it coasts on.
      if (G.scrolled && G.raw >= hi - 1 && G.raw <= hi + 1) { if (Math.abs(v) > .05) coast(v); k.settle(st[st.length - 1].name, true); return; }
      // Down past the lowest: from a place's peek, past 30% of it or a flick down closes it.
      if (G.raw < lo - 1 && k.below() && (v < -FLICK || lo - G.raw > lo * .3)) { k.off(v); return; }
      let to;
      if (v > FLICK) to = st.find(s => s.h > h + 1) || st[st.length - 1];
      else if (v < -FLICK) to = st.slice().reverse().find(s => s.h < h - 1) || st[0];
      else to = st.reduce((m, s) => Math.abs(s.h - h) < Math.abs(m.h - h) ? s : m, st[0]);
      k.settle(to.name);
    }
    el.addEventListener('lostpointercapture', e => { if (g && g.mouse && e.pointerId === g.id) end(e); });
    // A tap after a drag isn't a tap.
    el.addEventListener('click', e => { if (eat) { eat = false; e.stopPropagation(); e.preventDefault(); } }, true);
    // A wheel or trackpad (a laptop's narrow window): below the tallest stop it moves the sheet a stop.
    let wheelAt = 0;
    el.addEventListener('wheel', e => {
      const st = k.stops(), top = st[st.length - 1];
      const at = st.findIndex(s => Math.abs(s.h - k.h()) < 2);
      if (Math.abs(e.deltaY) < 4 || e.ctrlKey) return;
      const atTop = at === st.length - 1;
      if (atTop && (e.deltaY > 0 || body.scrollTop > 0)) return;
      e.preventDefault();
      if (performance.now() - wheelAt < 350) return;
      wheelAt = performance.now();
      if (e.deltaY > 0 && at < st.length - 1) k.settle((st[at + 1] || top).name);
      else if (e.deltaY < 0 && at > 0) k.settle(st[at - 1].name);
    }, { passive: false });
    // (A finger resting 2 s without moving no longer holds back what the app draws.)
    return { busy: () => !!g && performance.now() - g.at < 2000 };
  }

  /* ------------------------------------------------------------ docked */

  function docked(el, o) {
    o = o || {};
    const grab = el.querySelector('.ogc-sheet__grab'), body = el.querySelector('.ogc-sheet__body');
    const S = { stop: 'peek', h: 0, y: 0, tucked: false, back: 'peek', H: { lip: LIP, peek: 92, half: 92, full: 92 }, list: ['peek'] };
    el.classList.add('ogc-sheet', 'ogc-sheet--docked');
    const canvas = () => (el.parentElement && el.parentElement.getBoundingClientRect().height) || innerHeight;
    const floor = () => Math.max(0, o.floor ? o.floor() : 0);
    function measure() {
      const s = o.stops ? o.stops() : { peek: 120, half: 300, full: 600 };
      const peek = Math.round(s.peek), half = Math.round(Math.max(peek, s.half)), full = Math.round(Math.max(half, s.full));
      S.H = { lip: LIP, peek, half, full };
      S.list = ['peek'].concat(half > peek + 8 ? ['half'] : [], full > Math.max(peek, half) + 8 ? ['full'] : []);
      // The box is as tall as the tallest stop, so the body's foot is the screen's at full.
      el.style.height = S.H[S.list[S.list.length - 1]] + 'px';
      return S.H;
    }
    const tallest = () => S.list[S.list.length - 1];
    const hOf = stop => stop === 'lip' ? LIP : S.H[stop];
    function put(h, ms) {
      const C = canvas(), y = Math.round(C - floor() - h);
      S.h = h; S.y = y;
      el.style.transition = ms ? 'transform ' + ms + 'ms ' + EASE : 'none';
      el.style.transform = 'translate3d(0,' + y + 'px,0)';
      if (o.moved) o.moved(C - y, ms || 0);
    }
    const dur = d => still() ? 0 : Math.round(200 + 80 * Math.min(1, Math.abs(d) / 400));
    function set(stop, how, quiet) {
      measure();
      if (stop !== 'lip' && S.list.indexOf(stop) < 0) stop = stop === 'peek' ? 'peek' : tallest();
      if (S.tucked && stop !== 'lip') { S.back = stop; stop = 'lip'; }
      S.stop = stop;
      const h = hOf(stop), C = canvas();
      if (how === 'rise' && !still()) {
        put(-24, 0);
        void el.offsetHeight;
        put(h, 280);
      } else put(h, how === 'ease' ? dur(C - floor() - h - S.y) : 0);
      // Only the tallest stop scrolls; below it the body is at its top.
      const top = stop === tallest() && stop !== 'lip';
      el.classList.toggle('is-top', top);
      if (!top && !api.busy()) body.scrollTop = 0;
      el.classList.toggle('is-lip', stop === 'lip');
      if (grab) {
        const more = stop === 'lip' || S.list.indexOf(stop) < S.list.length - 1;
        grab.setAttribute('aria-label', more ? 'More' : 'Less');
        grab.setAttribute('title', more ? 'More' : 'Less');
      }
      if (o.settled && !quiet) o.settled(stop);
    }
    // Off the screen downwards (a layer closing, 140 ms), then fn.
    function leave(fn) {
      if (still()) { fn(); return; }
      put(-24, 140);
      setTimeout(fn, 150);
    }
    const eng = drag(el, body, {
      stops: () => (S.tucked ? [{ name: 'lip', h: LIP }] : S.list.map(n => ({ name: n, h: S.H[n] }))),
      h: () => S.h,
      put: h => put(h, 0),
      settle: (stop, quiet) => set(stop, 'ease', quiet && stop === S.stop),
      below: () => !S.tucked && !!o.below,
      off: () => { if (o.below) o.below(); },
      lip: () => S.tucked,
      up: () => { if (o.raised) o.raised(); else tuck(false, 'ease'); }
    });
    const api = { busy: eng.busy };
    // The grabber: a tap moves up one stop, and from the top back to peek; ↑ and ↓ move a stop.
    if (grab) {
      grab.addEventListener('click', () => {
        if (S.tucked) { if (o.raised) o.raised(); else tuck(false, 'ease'); return; }
        const i = S.list.indexOf(S.stop);
        set(i < S.list.length - 1 ? S.list[i + 1] : 'peek', 'ease');
      });
      grab.addEventListener('keydown', e => {
        if (e.key !== 'ArrowUp' && e.key !== 'ArrowDown') return;
        e.preventDefault();
        if (S.tucked) { if (e.key === 'ArrowUp') { if (o.raised) o.raised(); else tuck(false, 'ease'); } return; }
        const i = S.list.indexOf(S.stop), j = Math.max(0, Math.min(S.list.length - 1, i + (e.key === 'ArrowUp' ? 1 : -1)));
        if (j !== i) set(S.list[j], 'ease');
      });
    }
    // Tabbing to something the sheet hides raises it to its tallest stop. Only a keyboard's focus: a tap
    // (Chrome on a phone focuses the button tapped) or the app's own focus after a tap never moves it (round
    // 1's check: × on a room, then the list's row focused, threw the sheet to full). Measured against the
    // stop the sheet is going to, not where a rise has it now (round 2: Barnes chosen in Search with Enter
    // focused its heading while the sheet was still rising, and threw it to the tallest stop).
    el.addEventListener('focusin', e => {
      if (e.target === grab || S.tucked || !keyed) return;
      requestAnimationFrame(() => {
        if (!el.contains(document.activeElement)) return;
        const r = document.activeElement.getBoundingClientRect(), down = r.bottom - el.getBoundingClientRect().top;
        if (down > hOf(S.stop) - 2 && S.stop !== tallest()) set(tallest(), 'ease');
        if (S.stop !== tallest()) body.scrollTop = 0;
      });
    });
    function tuck(on, how) {
      if (on === S.tucked) return;
      if (on) { S.back = S.stop === 'lip' ? 'peek' : S.stop; S.tucked = true; el.classList.add('is-tucked'); set('lip', how); }
      else { S.tucked = false; el.classList.remove('is-tucked'); set(S.back || 'peek', how); }
    }
    // (defineProperties, not Object.assign: assign would copy the getters' values once, never live.)
    return Object.defineProperties(Object.assign(api, {
      el, body, set, measure, leave, tuck,
      heights: () => Object.assign({}, S.H),
      // Its top, from the canvas's top (as laid out at its stop, not mid-ease).
      top: () => canvas() - floor() - hOf(S.stop)
    }), {
      stop: { get: () => S.stop, enumerable: true },
      h: { get: () => S.h, enumerable: true },
      tucked: { get: () => S.tucked, enumerable: true },
      stops: { get: () => S.list.slice(), enumerable: true }
    });
  }

  /* ------------------------------------------------------------ modal */

  const wide = () => !!(window.matchMedia && matchMedia('(min-width: 768px)').matches);
  // The status bar's height (env(safe-area-inset-top), 0 in a browser tab), read once from a probe.
  let satEl = null;
  function sat() {
    if (!satEl) {
      satEl = document.createElement('div');
      satEl.setAttribute('aria-hidden', 'true');
      satEl.style.cssText = 'position:fixed;left:0;top:0;width:0;height:env(safe-area-inset-top,0px);visibility:hidden;pointer-events:none';
      document.body.appendChild(satEl);
    }
    return satEl.offsetHeight || 0;
  }
  const opened = []; // the modal sheets open now, oldest first
  let mseq = 0;
  function modal(html, o) {
    o = o || {};
    const n = ++mseq;
    const d = document.createElement('dialog');
    d.className = 'ogc ogc-sheet ogc-sheet--modal' + (o.className ? ' ' + o.className : '');
    d.innerHTML = '<div class="ogc-sheet__top"><button type="button" class="ogc-sheet__grab" aria-label="More" title="More"></button>' +
      '<div class="ogc-sheet__head">' + (o.head || '') + '</div>' +
      '<div class="ogc-sheet__tools">' + (o.tools || '') + '<button type="button" class="ogc-sheet__x" data-sheet-close aria-label="Close" title="Close">' + X + '</button></div></div>' +
      '<div class="ogc-sheet__body"><div class="ogc-sheet__in">' + (html || '') + '</div></div>';
    document.body.appendChild(d);
    const top = d.querySelector('.ogc-sheet__top'), head = d.querySelector('.ogc-sheet__head');
    const body = d.querySelector('.ogc-sheet__body'), inner = d.querySelector('.ogc-sheet__in'), grab = d.querySelector('.ogc-sheet__grab');
    // (o.node: an element of the page's own moved in, the account's menu; it goes back in o.onClose.)
    if (o.node) inner.appendChild(o.node);
    // (o.prep(el): the page's last touches, before it's measured: Share's link written as typed.)
    if (o.prep) o.prep(d);
    // Its name: the first heading (given an id of its own, so two sheets never share one), else o.label.
    const named = () => {
      const h = d.querySelector('h2, h1');
      if (h) { h.id = 'ogc-sheet-h' + n; d.setAttribute('aria-labelledby', h.id); d.removeAttribute('aria-label'); }
      else if (o.label) { d.setAttribute('aria-label', o.label); d.removeAttribute('aria-labelledby'); }
    };
    named();
    const rec = { n, d, opener: o.opener || document.activeElement, refocus: o.refocus || null };
    let h = 0, stop = 'open', done = false, layer = null, last = null;
    const pad = () => { const cs = getComputedStyle(body); return (parseFloat(cs.paddingTop) || 0) + (parseFloat(cs.paddingBottom) || 0); };
    // open: its content, at most 62% of the screen (o.fit: all of it, Share's QR and buttons at once);
    // full: 24 px under the status bar, no taller than its content.
    const H = () => {
      const content = Math.ceil(top.offsetHeight + inner.offsetHeight + pad());
      const full = Math.max(120, innerHeight - 24 - sat());
      const open = Math.min(content, o.fit ? full : Math.round(innerHeight * .62), full);
      return { open, full: Math.min(full, Math.max(open, content)) };
    };
    const two = hs => hs.full > hs.open + 8;
    function put(v, ms) { h = v; d.style.transition = ms ? 'transform ' + ms + 'ms ' + EASE : 'none'; d.style.transform = wide() ? '' : 'translate3d(0,' + Math.round(d.offsetHeight - v) + 'px,0)'; }
    const dur = dy => Math.round(200 + 80 * Math.min(1, Math.abs(dy) / 400));
    function set(s, how) {
      if (wide()) { d.style.transform = ''; d.style.height = ''; d.classList.add('is-top'); stop = 'open'; return; }
      const hs = last = H();
      d.style.height = hs.full + 'px';
      stop = s === 'full' && two(hs) ? 'full' : 'open';
      put(hs[stop], how === 'jump' || still() ? 0 : how === 'rise' ? 280 : dur(hs[stop] - h));
      // Only its tallest stop scrolls; below it the body goes back to its top (smoothly, after a drag on
      // the top row left it scrolled).
      const tallest = stop === 'full' || !two(hs);
      d.classList.toggle('is-top', tallest);
      if (!tallest && body.scrollTop > 0) { if (how === 'jump' || still()) body.scrollTop = 0; else body.scrollTo({ top: 0, behavior: 'smooth' }); }
      // The grabber: More or Less; a sheet with one stop has nothing to say (it still drags).
      if (two(hs)) { const w = stop === 'full' ? 'Less' : 'More'; grab.setAttribute('aria-label', w); grab.setAttribute('title', w); grab.removeAttribute('tabindex'); grab.removeAttribute('aria-hidden'); }
      else { grab.setAttribute('tabindex', '-1'); grab.setAttribute('aria-hidden', 'true'); grab.removeAttribute('title'); }
    }
    const eng = drag(d, body, {
      on: () => !wide(),
      stops: () => { const hs = H(); return two(hs) ? [{ name: 'open', h: hs.open }, { name: 'full', h: hs.full }] : [{ name: 'open', h: hs.open }]; },
      h: () => h,
      put: v => put(v, 0),
      settle: s => set(s, 'ease'),
      below: () => true,
      off: () => close('drag'),
      head: true
    });
    grab.addEventListener('click', () => set(stop === 'full' ? 'open' : 'full', 'ease'));
    grab.addEventListener('keydown', e => {
      if (e.key !== 'ArrowUp' && e.key !== 'ArrowDown') return;
      e.preventDefault();
      set(e.key === 'ArrowUp' ? 'full' : 'open', 'ease');
    });
    // Tabbing to something below the open stop raises it to full (a keyboard's focus only, as docked).
    d.addEventListener('focusin', e => {
      if (!keyed || wide() || e.target === grab || stop === 'full') return;
      requestAnimationFrame(() => {
        if (done || !d.contains(document.activeElement)) return;
        // (Where it will be once the sheet has settled, not mid-rise: the heading it opens on stays put.)
        const r = document.activeElement.getBoundingClientRect(), at = d.getBoundingClientRect().top;
        if (innerHeight - h + (r.bottom - at) > innerHeight - 2) set('full', 'ease');
      });
    });
    // The content grew or shrank (its small map arrived, Copied): the stop follows, never mid-drag.
    let ro = null;
    if (window.ResizeObserver) {
      ro = new ResizeObserver(() => {
        if (done || wide() || eng.busy()) return;
        const hs = H();
        if (!last || Math.abs(hs.open - last.open) > 2 || Math.abs(hs.full - last.full) > 2) set(stop, 'ease');
      });
      ro.observe(inner);
      ro.observe(top);
    }
    const onResize = () => { if (!done) set(stop, 'jump'); };
    addEventListener('resize', onResize);
    function refocus(r) {
      const t = r.opener;
      if (t && t.focus && document.contains(t) && !t.closest('[inert]')) t.focus({ preventScroll: true });
      else if (r.refocus) { try { r.refocus(); } catch (x) { /* nothing to go back to */ } }
    }
    function finish(how) {
      if (done) return; done = true;
      removeEventListener('resize', onResize);
      if (ro) ro.disconnect();
      const i = opened.indexOf(rec);
      if (i > -1) opened.splice(i, 1);
      const end = () => {
        if (d.open) d.close();
        d.remove();
        // The sheet under it has its own scrim again.
        const under = opened[opened.length - 1];
        if (under) under.d.classList.remove('is-under');
        // The focus back to what opened it, unless a newer sheet has it (Share from the menu): that one
        // goes back to this one's opener instead of a row that's gone with it.
        const above = opened.filter(r => r.n > n);
        if (above.length) above.forEach(r => { if (!r.opener || !document.contains(r.opener) || d.contains(r.opener)) { r.opener = rec.opener; r.refocus = rec.refocus; } });
        else if (how !== 'go') refocus(rec);
        if (o.onClose) o.onClose(how);
      };
      if (wide() || still()) end(); else { d.classList.add('is-leaving'); put(0, 140); setTimeout(end, 150); }
    }
    // Closed by the person or the app: its history entry goes (Back closes it too, through the layer).
    function close(how) {
      if (done) return;
      if (layer && layers.top() === layer) layers.pop(1);
      layer = null;
      finish(how || 'close');
    }
    d.addEventListener('cancel', e => { e.preventDefault(); close('esc'); });
    d.addEventListener('click', e => {
      if (e.target === d) { const r = d.getBoundingClientRect(); if (e.clientY < r.top || e.clientY > r.bottom || e.clientX < r.left || e.clientX > r.right) close('outside'); return; }
      if (e.target.closest('[data-sheet-close]')) close('x');
    });
    // A sheet over a sheet: one scrim, the newest's, over the one under it too.
    // (And one still sliding away under it: Share from the menu.)
    const prev = opened[opened.length - 1];
    if (prev) prev.d.classList.add('is-under');
    document.querySelectorAll('dialog.ogc-sheet--modal.is-leaving').forEach(x => x.classList.add('is-under'));
    opened.push(rec);
    d.showModal();
    // (o.here 'own': opened again on its own entry, come back to with Back; layers.push.)
    layer = layers.push('sheet', { close: () => { layer = null; finish('back'); }, el: d, url: o.url, here: o.here || '' });
    if (wide()) set('open', 'jump'); else { d.style.height = H().full + 'px'; put(0, 0); void d.offsetHeight; set('open', 'rise'); }
    const hd = d.querySelector('[data-sheet-focus]') || d.querySelector('h2, h1');
    if (hd) { hd.setAttribute('tabindex', '-1'); hd.focus({ preventScroll: true }); }
    // Put away to go somewhere else (Directions from another tab): it closes, its entry stays where it is.
    function leave() {
      if (done) return;
      if (layer) layers.drop(layer);
      layer = null;
      finish('go');
    }
    const api = {
      el: d, body: inner, scroller: body, head, close, set, leave,
      // New content (the campus read, the small map drawn): the stop follows it.
      // (Where it was read to, and the heading's focus, stay.)
      html(b, hh) {
        const had = d.contains(document.activeElement) && /^H[12]$/.test(document.activeElement.tagName), y = body.scrollTop;
        if (b != null) inner.innerHTML = b;
        if (hh != null) head.innerHTML = hh;
        named();
        body.scrollTop = y;
        if (had) { const x = d.querySelector('[data-sheet-focus]') || d.querySelector('h2, h1'); if (x) { x.setAttribute('tabindex', '-1'); x.focus({ preventScroll: true }); } }
        set(stop, 'ease');
      },
      isOpen: () => !done
    };
    Object.defineProperty(api, 'stop', { get: () => stop, enumerable: true });
    return api;
  }

  /* ------------------------------------------------------------ layers */

  const stack = [];
  let seq = 0, busy = null, busyT = 0;
  const queue = [];
  // Two addresses on the same view of the same year (a place's ?to= aside): closing a layer there draws
  // nothing again.
  const sameView = (a, b) => {
    try {
      const u = new URL(a, location.href), v = new URL(b, location.href);
      ['to', 'dirs', 'room', 'event', 'need', 'care', 'at', 'share'].forEach(k => { u.searchParams.delete(k); v.searchParams.delete(k); });
      u.hash = v.hash = '';
      return u.href === v.href;
    } catch (e) { return false; }
  };
  const run = f => { if (busy) queue.push(f); else f(); };
  function flush() { while (queue.length && !busy) queue.shift()(); }
  function stateFor(n, id) { const s = Object.assign({}, history.state || {}); delete s.wkSheet; s.ogcL = n; s.ogcId = id; return s; }
  const layers = {
    names: () => stack.map(l => l.name),
    top: () => stack[stack.length - 1] || null,
    get depth() { return stack.length; },
    // A tab's own history entry carries the layers under it, so Back to it closes none of them.
    state: () => stack.length ? { ogcL: stack.length } : null,
    // o.here (round 3's fix pass): the layer takes the entry it's on instead of adding one. 'tab': the entry
    // a tab's change has just made (a sheet's Directions, a Search result, opening Places from another
    // tab); Back from it goes straight to what was under it, and closing it by hand (×, a drag) leaves the
    // tab's entry as it was (l.base), on the plain tab. 'own': a sheet's own entry come back to (opened
    // again from its address); it closes as any sheet does.
    push(name, o) {
      o = o || {};
      const l = { name, close: o.close || null, el: o.el || null, id: 'L' + (++seq), base: '', url: '', here: o.here || '' };
      stack.push(l);
      const n = stack.length;
      run(() => {
        l.base = location.href;
        l.url = o.url ? new URL(o.url, location.href).href : location.href;
        try { if (l.here) history.replaceState(stateFor(n, l.id), '', l.url); else history.pushState(stateFor(n, l.id), '', l.url); } catch (e) { /* the layer works without its entry */ }
      });
      return l;
    },
    // Taken off without its entry going (a sheet put away for Directions, its entry kept to open it again).
    drop(l) { const i = stack.indexOf(l); if (i > -1) stack.splice(i, 1); },
    swap(name, o) {
      o = o || {};
      const l = stack[stack.length - 1];
      if (!l) return layers.push(name, o);
      l.name = name;
      if (o.close) l.close = o.close;
      if (o.url) run(() => {
        const url = new URL(o.url, location.href).href;
        l.url = url;
        if (history.state && history.state.ogcId === l.id && url !== location.href) { try { history.replaceState(history.state, '', url); } catch (e) { /* kept as it was */ } }
      });
      return l;
    },
    // Closed by the app (×, Esc, a choice): the layers go now; their entries go when the history's top
    // is still theirs (after a tab change it isn't: they're forgotten, the entries stay).
    pop(n) {
      n = Math.min(n || 1, stack.length);
      if (!n) return;
      const gone = stack.splice(stack.length - n, n), depth = stack.length, under = stack[depth - 1] || null;
      run(() => {
        const s = history.state;
        if (!(s && s.ogcId === gone[gone.length - 1].id)) {
          // Not its own entry, but one on the same view still naming it (an event's sheet left over it):
          // that entry stops naming it, and its address drops the place, so Back never lands on a place
          // that's closed (round 1's check).
          if (s && (s.ogcL || 0) > depth && sameView(gone[0].base, location.href)) {
            const t = Object.assign({}, s); delete t.ogcId; t.ogcL = depth;
            try { history.replaceState(t, '', (under && under.url) || gone[0].base || location.href); } catch (e) { /* kept as it was */ }
          }
          return;
        }
        // (The bottom one on a tab's own entry: that entry stays, as the plain tab it was.)
        const keep = gone[0].here === 'tab', back = keep ? n - 1 : n;
        const plain = () => { const t = Object.assign({}, history.state || {}); delete t.ogcId; t.ogcL = depth; try { history.replaceState(t, '', gone[0].base || location.href); } catch (e) { /* kept as it was */ } };
        if (!back) { plain(); return; }
        busy = { base: gone[0].base };
        clearTimeout(busyT);
        busyT = setTimeout(() => { busy = null; flush(); }, 900);
        history.go(-back);
        if (keep) run(plain);
      });
    },
    forget() { stack.length = 0; },
    // fn once the history is still (a layer's Back has landed): what opens a sheet of its own (Share from
    // the account's menu) waits for the menu's entry to go first.
    after: f => run(f),
    sameView: (a, b) => sameView(a, b)
  };
  // Back (the phone's, the browser's): the layers above the entry come back to close, the top first.
  // Registered before week.js's own listener, so a layer closed on the same view stops it drawing again.
  addEventListener('popstate', e => {
    if (busy) {
      const b = busy; busy = null; clearTimeout(busyT);
      if (sameView(b.base, location.href)) e.stopImmediatePropagation();
      flush();
      return;
    }
    const d = (e.state && e.state.ogcL) || 0;
    if (stack.length <= d) return;
    let base = '';
    while (stack.length > d) {
      const l = stack.pop();
      base = l.base || base;
      if (l.close) { try { l.close('back'); } catch (x) { if (window.console) console.error(x); } }
    }
    if (base && sameView(base, location.href)) e.stopImmediatePropagation();
  });

  O.sheet = { docked, modal };
  O.layers = layers;
})();
