/*
 * ogc-map-pins.js — the campus walk-through, for whoever the COA asks (the map area, Oct 10).
 *
 * Once per campus, standing at each door with a phone: pin the schedule's rooms, name and check the
 * buildings' doors, pin the fields and the lots, mark a hall's plan as checked, and note what's closed.
 * It's kept per campus (includes/module-map.php), so the next Conference there starts with it done.
 *
 * The audit: Pin here and Cancel sat far below the map, nothing showed the phone's accuracy, a pin
 * saved at once with no way to move it, "All 20 on the map" was said with nothing pinned, the help
 * was in tooltips, and a room upstairs had nowhere to say so. Now: one visible line of help; what's
 * left, counted; a bar under the thumb while pinning; a preview pin to move before Save; ± metres;
 * a gentle flag when a pin isn't in its building; Floor, Inside and Door for each room; Undo.
 *
 * Polish 1: one action a row, Pin. On a phone it centres the map on the blue dot and its accuracy
 * circle, and the person taps the door: the location helps aim and never blocks (a GPS fix at an inside
 * door is rarely within 25 m). "Locating", "Location off" or "± 40 m" says how it's going. The rooms of
 * the building you're standing in come first. Each tab has its own help; the first view is the
 * Conference's buildings (not the fieldhouse across the fields); doors are numbered on the map; pinned
 * or not is a filled or hollow pin; every tap is 44 px.
 *
 * O.map.pins({ year, places (the year's places.csv rows), onSaved(row) }) → { mount(slot), year }
 */
(function () {
  'use strict';
  const O = window.OGC, esc = O.esc, M = O.map;
  if (!M) return;
  const svg = d => '<svg class="pm-i" viewBox="0 0 24 24" aria-hidden="true"><path d="' + d + '" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  const I = {
    pin: svg('M12 20.5s-6.5-5.4-6.5-10.8a6.5 6.5 0 0 1 13 0c0 5.4-6.5 10.8-6.5 10.8ZM12 12a2.3 2.3 0 1 0 0-4.6 2.3 2.3 0 0 0 0 4.6Z'),
    pinned: '<svg class="pm-i pp-pinned" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 20.5s-6.5-5.4-6.5-10.8a6.5 6.5 0 0 1 13 0c0 5.4-6.5 10.8-6.5 10.8Z" fill="currentColor" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/><circle cx="12" cy="9.7" r="2.3" fill="#fff"/></svg>',
    here: svg('M12 3v3M12 18v3M3 12h3M18 12h3M12 17a5 5 0 1 0 0-10 5 5 0 0 0 0 10Z'),
    check: svg('M5.5 12.5l4 4 9-9'),
    plus: svg('M12 5v14M5 12h14'),
    undo: svg('M9 7 4.5 11.5 9 16M5 11.5h9.5a5 5 0 0 1 0 10H12')
  };
  const touch = () => window.matchMedia && matchMedia('(pointer: coarse)').matches && 'geolocation' in navigator;
  // "Tap" on a touch screen, "Click" with a mouse (polish 3: the laptop said Tap).
  const tapWord = () => window.matchMedia && matchMedia('(pointer: coarse)').matches ? 'Tap' : 'Click';
  const today = () => { const d = new Date(); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); };
  const FLOORS = [['Lower', 'Lower'], ['Ground', 'Ground'], ['2', '2nd'], ['3', '3rd']];
  const SPOTS = ['camper', 'parking', 'accessible', 'carts', 'desk'];
  const TABS = [['rooms', 'Rooms'], ['doors', 'Doors'], ['outdoors', 'Outdoors'], ['halls', 'Halls'], ['closures', 'Closures']];
  // A room named for its building ("Piazza Terrace (Barnes)") drops the building under its building.
  const inBuilding = (name, b) => String(name).replace(/\s*\(([^)]+)\)$/, (m, w) => String(b).toLowerCase().indexOf(w.split(' ')[0].toLowerCase()) > -1 ? '' : m);
  // Each tab's own help, in a line (a phone stands at the door; a laptop taps the map).
  const HELP = {
    rooms: [`Tap Pin at a room's door, then tap the door on the map`, 'Click Pin, then the door on the map'],
    doors: ['Add the doors people use, with their names', 'Add the doors people use, with their names'],
    outdoors: ['Pin the fields, the lots and the camper lot', 'Pin the fields, the lots and the camper lot'],
    halls: ['Upload each hall’s plan from the university, then check it. Households see a plan once it’s from the university', 'Upload each hall’s plan from the university, then check it. Households see a plan once it’s from the university'],
    closures: ['A closed path or door, with its dates; routes go around it', 'A closed path or door, with its dates; routes go around it']
  };

  M.pins = function (opts) {
    const startTab = new URLSearchParams(location.search).get('tab');
    const T = { year: opts.year, parts: null, c: null, R: null, map: null, mapEl: null, el: null, tab: TABS.some(t => t[0] === startTab) ? startTab : 'rooms', mode: null, open: '', err: '', watch: null, gps: null, gpsState: '', saving: false, toastT: 0 };
    T.el = document.createElement('div');
    T.el.className = 'pp';

    /* ---------------------------------------------------------- data */

    const rows = k => T.parts && T.parts[k] ? T.parts[k].rows : [];
    function campusRows() {
      const out = rows('buildings').slice();
      rows('doors').forEach(d => out.push({ code: '', name: d.building, kind: 'door', short: d.label, points: d.x + ' ' + d.y, door: d.id, step_free: d.step_free, open: d.open, key_only: d.key_only, checked: d.checked }));
      rows('spots').forEach(s => { if (s.x !== '') out.push({ code: '', name: s.name, kind: 'spot', points: s.x + ' ' + s.y, door: s.id, spot: s.kind, note: s.note }); });
      rows('closures').forEach(s => out.push({ code: '', name: s.note, kind: 'closed', points: s.x + ' ' + s.y, door: s.id, from: s.from, to: s.to }));
      return out;
    }
    // The year's places, each with what the campus has for it (its pin, floor, note, door).
    function places() {
      const pins = {};
      rows('places').forEach(p => { pins[String(p.code).toUpperCase()] = p; });
      const out = {};
      (opts.places || []).filter(r => r.code && !/^#/.test(r.code)).forEach(r => {
        const p = pins[String(r.code).toUpperCase()] || {};
        out[String(r.code).toUpperCase()] = Object.assign({}, r, { x: p.x != null ? p.x : '', y: p.y != null ? p.y : '', floor: p.floor || '', inside: p.inside || '', door: p.door || '', outdoor: p.outdoor || '', checked: p.checked || '', mapped: p.mapped || '' }, p.mapped ? { building: p.mapped } : {});
      });
      return out;
    }
    const hasPin = p => p && p.x !== '' && p.x != null && !isNaN(+p.x);
    // A building as the schedule names it (places.csv), not as OpenStreetMap does.
    function siteName(bname, ps) {
      ps = ps || places();
      const main = Object.values(ps).find(p => String(p.code).indexOf('/') < 0 && p.outdoor !== 'yes' && (M.buildingFor(T.c, p, ps) || {}).name === bname);
      return main ? main.name : bname;
    }
    function load() {
      return M.store.load(T.year).then(d => {
        T.parts = d.parts || {}; T.may = d.may || null;
        T.c = M.campus(campusRows()); T.R = M.router(T.c);
        if (T.map) { T.mapEl.remove(); T.map = null; }
        draw();
      }).catch(e => { T.err = e.status === 403 || e.status === 401 ? 'Members only' : 'Couldn’t load the campus'; draw(); });
    }
    // The campus again after a door, spot or closure changed; the map redrawn (keeping its view) when what it draws changed.
    function rebuild(redraw) {
      T.c = M.campus(campusRows()); T.R = M.router(T.c);
      if (redraw && T.map) { const v = T.map.view(); T.mapEl.remove(); T.map = null; T.keepView = v; }
    }
    // One row saved on the server; Undo puts the old one back.
    function save(part, row, before, msg) {
      T.saving = true; status('Saving');
      return M.store.row(T.year, part, row).then(res => {
        const list = rows(part), key = { places: 'code', doors: 'id', spots: 'id', halls: 'hall', closures: 'id' }[part];
        const i = list.findIndex(r => String(r[key]).toUpperCase() === String(row[key]).toUpperCase());
        if (row._gone) { if (i > -1) list.splice(i, 1); } else if (i > -1) Object.assign(list[i], res.row || row); else list.push(res.row || row);
        T.parts[part].version = res.version;
        T.saving = false; status('Saved');
        if (part !== 'halls' && part !== 'places') rebuild(part === 'spots' || part === 'closures');
        if (opts.onSaved && part === 'places') opts.onSaved(res.row || row);
        draw();
        if (msg) toast(msg, before ? () => save(part, before, null, 'Undone') : null);
      }).catch(e => { T.saving = false; status(''); toast(e.status === 400 && e.data && e.data.message ? e.data.message : 'Not saved · ' + (e.message || 'Try again')); throw e; });
    }

    /* ---------------------------------------------------------- what's left */

    // The rooms are the work: the main buildings are found by their code and need only their doors.
    function work() {
      const ps = places(), all = Object.values(ps);
      const rooms = all.filter(p => String(p.code).indexOf('/') > -1 || p.outdoor === 'yes');
      const pinned = rooms.filter(hasPin).length;
      const lost = all.filter(p => String(p.code).indexOf('/') < 0 && p.outdoor !== 'yes' && !M.buildingFor(T.c, p, ps));
      return { ps, rooms, pinned, lost };
    }
    const counted = (n, of) => n ? n + ' of ' + of + ' pinned' : of + ' rooms to pin';

    /* ---------------------------------------------------------- drawing */

    function mount(slot) {
      slot.appendChild(T.el);
      if (!T.parts) { T.el.innerHTML = '<p class="pp-help">Loading</p>'; load(); return; }
      draw();
    }
    function draw() {
      if (T.err) { T.el.innerHTML = '<div class="ws-blank"><p class="ws-blank__h">' + esc(T.err) + '</p></div>'; return; }
      if (!T.parts) return;
      if (!rows('buildings').length) { T.el.innerHTML = '<div class="ws-blank"><p class="ws-blank__h">No campus map</p><p class="ws-blank__p">The webmasters add it from OpenStreetMap</p></div>'; return; }
      const w = work(), doors = rows('doors'), checked = doors.filter(d => d.checked).length;
      const stat = '<p class="pp-stat">' + esc(w.rooms.length ? (w.pinned === w.rooms.length ? 'All ' + w.rooms.length + ' rooms pinned' : counted(w.pinned, w.rooms.length)) : 'No rooms on the schedule') +
        (doors.length ? ' · ' + esc(checked ? checked + ' of ' + doors.length + ' doors checked' : doors.length + ' doors to check') : '') + (w.lost.length ? ' · <b class="pp-warn">' + w.lost.length + ' not on the map</b>' : '') + M.check(T.c, w.ps, rows('halls').map(h => h.hall)).filter(x => x.kind !== 'place').map(x => ' · <b class="pp-warn">' + esc(x.text + (x.kind === 'hall' ? ' · ' + x.name : '')) + '</b>').join('') + '<span class="pp-saving" aria-live="polite"></span></p>';
      const tabs = '<div class="pp-tabs" role="tablist" aria-label="Walk-through">' + TABS.map(t => '<button type="button" role="tab" aria-selected="' + (T.tab === t[0]) + '" data-pp="tab" data-v="' + t[0] + '">' + t[1] + '</button>').join('') + '</div>';
      const body = T.tab === 'rooms' ? roomsTab(w) : T.tab === 'doors' ? doorsTab(w) : T.tab === 'outdoors' ? outdoorsTab(w) : T.tab === 'halls' ? hallsTab() : closuresTab();
      const wb = document.querySelector('.ws-bar'); if (wb) T.el.style.setProperty('--pp-top', Math.round(wb.getBoundingClientRect().height + 12) + 'px');
      const keep = T.el.querySelector('.pp-list'), y = keep ? keep.scrollTop : 0, focusKey = document.activeElement && T.el.contains(document.activeElement) ? document.activeElement.getAttribute('data-k') : '';
      // (Doors, closures and halls are the campus map's owner's, when the COA has picked one: said, not hidden.)
      const owned = T.may && T.may.doors === false && (T.tab === 'doors' || T.tab === 'closures' || T.tab === 'halls');
      T.el.innerHTML = stat + tabs + '<p class="pp-help">' + esc(owned ? 'Changed by the campus map’s owner' : HELP[T.tab][touch() ? 0 : 1]) + '</p>' +
        '<div class="pp-grid"><div class="pp-mapcol"><div class="pp-map"></div>' + (T.mode ? '<button type="button" class="pp-close" data-pp="cancel" aria-label="Close" title="Close"><svg class="pm-i" viewBox="0 0 24 24" aria-hidden="true"><path d="M6.5 6.5l11 11M17.5 6.5l-11 11" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg></button>' : '') + '</div><div class="pp-list">' + body + '</div></div>' + bar() + '<div class="pp-toast" role="status" hidden></div>';
      if (!T.map) { makeMap(); if (T.keepView) { const v = T.keepView; T.keepView = null; requestAnimationFrame(() => T.map.fit(v, 0)); } } else T.el.querySelector('.pp-map').appendChild(T.mapEl);
      const l = T.el.querySelector('.pp-list'); if (l) l.scrollTop = y;
      if (focusKey) { const f = T.el.querySelector('[data-k="' + focusKey + '"]'); if (f) f.focus(); }
      drawMap();
    }
    function status(t) { const s = T.el.querySelector('.pp-saving'); if (s) s.textContent = t ? ' · ' + t : ''; }
    // The buildings in the middle of things, as the guide frames them (a fieldhouse across the fields is left out).
    function core(names) {
      const its = names.map(n => M.find(T.c, n)).filter(Boolean);
      const med = xs => xs.slice().sort((p, q) => p - q)[Math.floor(xs.length / 2)] || 0;
      const mx = med(its.map(i => i.lx)), my = med(its.map(i => i.ly)), d = i => Math.hypot(i.lx - mx, i.ly - my), md = med(its.map(d));
      return its.filter(i => d(i) <= Math.max(md * 2.5, 180)).map(i => i.name);
    }
    function makeMap() {
      T.mapEl = document.createElement('div'); T.mapEl.style.cssText = 'position:absolute;inset:0';
      const ps = places(), used = Object.values(ps).map(p => M.buildingFor(T.c, p, ps)).filter(Boolean).map(b => b.name);
      T.map = M.viewer(T.mapEl, T.c, { title: 'Campus map', cooperative: true, expand: true, locate: false, used, shorts: M.shortsFor ? M.shortsFor(T.c, ps) : {}, start: core(Array.from(new Set(used.concat(rows('halls').map(h => h.hall))))),
        onTap: (pt, b, spot, door) => tap(pt, b, spot, door) });
      T.el.querySelector('.pp-map').appendChild(T.mapEl);
    }
    function drawMap() {
      if (!T.map) return;
      const ps = places(), m = T.mode;
      const pins = [];
      Object.values(ps).filter(hasPin).forEach(p => pins.push({ x: +p.x, y: +p.y, kind: 'room', label: p.code }));
      if (m && m.draft) pins.push({ x: m.draft.x, y: m.draft.y, kind: 'draft', label: m.label });
      T.map.pins(pins);
      // Doors numbered as the Doors tab lists them, per building.
      const num = {}, n = d => { const k = M.norm(d.building); num[k] = (num[k] || 0) + 1; return num[k]; };
      T.map.doors(T.tab === 'doors' || (m && m.kind === 'door') ? rows('doors').map(d => ({ x: +d.x, y: +d.y, id: d.id, n: n(d), named: !!d.label, on: T.open === 'd:' + d.id, label: T.open === 'd:' + d.id ? d.label || '' : '' })) : []);
      T.map.me(T.gps || null);
      const op = T.open && T.open.indexOf('p:') === 0 ? ps[T.open.slice(2)] : null;
      const b = m && m.building ? m.building : op && op.outdoor !== 'yes' ? (M.buildingFor(T.c, op, ps) || {}).name : T.open.indexOf('b:') === 0 ? T.open.slice(2) : '';
      T.map.select(b || '');
    }
    // While pinning: the bar under the thumb. "First Aid Room · B/131" over "Tap its door"; on a phone,
    // how the location is doing (it helps aim, never blocks).
    function bar() {
      const m = T.mode; if (!m) return '';
      const flag = m.draft && m.building ? outside(m) : '';
      // Polish 2: feet as everywhere else; "Tap to move", "Tap the door"; the room as the list says it.
      const gps = touch() && m.kind !== 'building' ? (T.gpsState === 'off' ? 'Location off' : T.gps ? '± ' + M.feet(T.gps.acc) : 'Locating') : '';
      const tw = tapWord(), say = m.draft ? (flag || (m.kind === 'building' ? tw + ' another building' : tw + ' to move')) : m.kind === 'door' ? tw + ' the door' : m.kind === 'building' ? tw + ' the building' : m.kind === 'place' && m.outdoor ? tw + ' where it is' : m.kind === 'place' ? tw + ' the door' : tw + ' the map';
      const name = m.kind === 'place' && m.building ? inBuilding(m.label, siteName(m.building)) : m.label;
      return '<div class="pp-bar" role="region" aria-label="Pinning"><p class="pp-bar__t"><b>' + esc(name) + '</b>' + (m.code ? ' <code>' + esc(m.code) + '</code>' : '') + '<span>' +
        esc(say) + (gps ? ' <i class="pp-gps' + (T.gpsState === 'off' ? ' is-off' : '') + '">' + I.here + esc(gps) + '</i>' : '') + '</span></p>' +
        '<p class="pm-btns">' + (m.draft ? '<button type="button" class="pm-btn" data-pp="save">' + I.check + (flag ? 'Keep' : 'Save') + '</button>' : '') + '<button type="button" class="pm-link" data-pp="cancel">Cancel</button></p></div>';
    }
    // A pin outside the building its place is in: said, not stopped (gentle flags, not gates).
    function outside(m) {
      const b = M.find(T.c, m.building);
      if (!b || b.pts.length < 3) return '';
      const d = m.draft, inn = M.inPoly(d.x, d.y, b.pts);
      if (inn) return '';
      const near = b.pts.some((p, i) => { const q = b.pts[(i + 1) % b.pts.length], dx = q[0] - p[0], dy = q[1] - p[1], L = dx * dx + dy * dy, t = L ? Math.max(0, Math.min(1, ((d.x - p[0]) * dx + (d.y - p[1]) * dy) / L)) : 0; return Math.hypot(p[0] + t * dx - d.x, p[1] + t * dy - d.y) < 8; });
      return near ? '' : 'Not in ' + M.shortOf(b);
    }

    const pills = (k, cur, list, attrs) => '<span class="pp-pills" role="group">' + list.map(x => '<button type="button" data-pp="set" data-f="' + k + '" data-v="' + esc(x[0]) + '" aria-pressed="' + (String(cur) === String(x[0])) + '"' + (attrs || '') + '>' + esc(x[1]) + '</button>').join('') + '</span>';
    const field = (k, v, ph, attrs) => '<input class="pp-in" data-pp="text" data-f="' + k + '" data-k="' + esc(k + ':' + (attrs || '')) + '" value="' + esc(v || '') + '" placeholder="' + esc(ph) + '" autocomplete="off"' + (attrs ? ' data-row="' + esc(attrs) + '"' : '') + '>';

    // The rooms by building, the one you're standing in first (on a phone with a fix); places out of
    // doors in their own group at the end (polish 1: the field was listed under the Rec Center).
    function roomsTab(w) {
      const ps = w.ps, groups = {}, order = [], out = [];
      Object.values(ps).forEach(p => {
        if (p.outdoor === 'yes') { out.push(p); return; }
        const k = String(p.code).split('/')[0].toUpperCase();
        if (!groups[k]) { groups[k] = { main: null, rooms: [] }; order.push(k); }
        if (String(p.code).toUpperCase() === k) groups[k].main = p; else groups[k].rooms.push(p);
      });
      const here = T.gps ? M.whereAmI(T.c, T.gps) : null, hereName = here && here.inside ? here.b.name : '';
      const bOf = g => g.main ? M.buildingFor(T.c, g.main, ps) : g.rooms.length ? M.buildingFor(T.c, g.rooms[0], ps) : null;
      order.sort((a, z) => ((bOf(groups[z]) || {}).name === hereName && hereName ? 1 : 0) - ((bOf(groups[a]) || {}).name === hereName && hereName ? 1 : 0));
      const html = order.map(k => {
        const g = groups[k], main = g.main, b = bOf(g);
        if (!main && !g.rooms.length) return '';
        const name = main ? main.name : b ? siteName(b.name, ps) : k;
        const ds = b ? rows('doors').filter(d => M.norm(d.building) === M.norm(b.name)).length : 0;
        const head = '<div class="pp-b"><p class="pp-b__h"><b>' + esc(name) + '</b> <code>' + esc(k) + '</code>' + (b && b.name === hereName ? ' <span class="pp-here">' + I.here + 'Here</span>' : '') + '</p>' +
          (b ? '<p class="pp-b__s">' + toPin(g.rooms) + '<button type="button" class="pm-link" data-pp="tab" data-v="doors" data-open="b:' + esc(b.name) + '"' + (ds ? '' : ' title="Routes end at the nearest side of the building"') + '>' + (ds ? (ds === 1 ? '1 door' : ds + ' doors') : 'No doors') + '</button></p>'
            : main ? '<p class="pp-b__s"><b class="pp-warn">Not on the map</b> · <button type="button" class="pm-link" data-pp="choose" data-code="' + esc(main.code) + '">Choose building</button></p>' : '') + '</div>';
        return g.rooms.length || !b ? '<section class="pp-group">' + head + '<ul class="pp-rows">' + g.rooms.map(p => roomRow(p, ps, name)).join('') + '</ul></section>' : '';
      }).join('');
      return html + (out.length ? '<section class="pp-group"><div class="pp-b"><p class="pp-b__h"><b>Outdoors</b></p>' + (toPin(out) ? '<p class="pp-b__s">' + toPin(out) + '</p>' : '') + '</div><ul class="pp-rows">' + out.map(p => roomRow(p, ps, '')).join('') + '</ul></section>' : '');
    }
    const toPin = list => { const n = list.filter(p => !hasPin(p)).length; return n ? '<span>' + n + ' to pin</span>' : ''; };
    // A room: its name, pinned or not as a filled or hollow pin, and one action, Pin (or Move).
    function roomRow(p, ps, bname) {
      const on = T.open === 'p:' + p.code, has = hasPin(p), b = M.buildingFor(T.c, p, ps);
      // Pinned or not, in words beside the pin (polish 2: an icon alone hid it from a once-a-year user).
      // (Polish 3: only a pinned row says so; the group's line counts the rest, "2 to pin".)
      const st = has ? '<span class="pp-pin is-on">' + I.pinned + 'Pinned' + (p.floor ? ' · ' + esc(M.placeLine(T.c, { floor: p.floor }, ps)) : '') + '</span>' : '';
      const ds = b ? rows('doors').filter(d => M.norm(d.building) === M.norm(b.name)) : [];
      const detail = on && has ? '<div class="pp-detail">' +
        '<p class="pp-f"><span>Floor</span>' + pills('floor', p.floor, FLOORS, ' data-row="' + esc(p.code) + '"') + '</p>' +
        '<p class="pp-f"><label><span>Inside</span>' + field('inside', p.inside, 'Past the bookstore', p.code) + '</label></p>' +
        (ds.length ? '<p class="pp-f"><span>Door</span>' + pills('door', p.door, [['', 'Nearest']].concat(ds.map((d, i) => [d.id, d.label || 'Door ' + (i + 1)])), ' data-row="' + esc(p.code) + '"') + '</p>' : '') +
        '<p class="pp-f"><span>Outdoors</span>' + pills('outdoor', p.outdoor === 'yes' ? 'yes' : '', [['', 'No'], ['yes', 'Yes']], ' data-row="' + esc(p.code) + '"') + '</p>' +
        '<p class="pm-btns"><button type="button" class="pm-link" data-pp="clear" data-code="' + esc(p.code) + '">Clear</button>' + (p.checked ? '<span class="pp-dim">Checked ' + esc(p.checked) + '</span>' : '<button type="button" class="pm-link" data-pp="checked" data-code="' + esc(p.code) + '">Checked</button>') + '</p></div>' : '';
      return '<li class="pp-row' + (on ? ' is-on' : '') + (T.mode && T.mode.code === p.code ? ' is-pinning' : '') + '"><button type="button" class="pp-row__n" data-pp="open" data-v="p:' + esc(p.code) + '" aria-expanded="' + on + '"><b>' + esc(bname ? inBuilding(p.name, bname) : p.name) + '</b><code>' + esc(p.code) + '</code>' + (st ? '<small>' + st + '</small>' : '') + '</button>' +
        '<span class="pp-row__b"><button type="button" class="pm-link pp-pinbtn" data-pp="pin" data-code="' + esc(p.code) + '" aria-label="' + esc((has ? 'Move ' : 'Pin ') + p.name) + '">' + I.pin + (has ? 'Move' : 'Pin') + '</button></span>' + detail + '</li>';
    }
    // Every building people go to, by the schedule's name; the main ones with no doors first, "To add".
    function doorsTab(w) {
      const ps = w.ps, names = [];
      Object.values(ps).forEach(p => { if (p.outdoor === 'yes') return; const b = M.buildingFor(T.c, p, ps); if (b && names.indexOf(b.name) < 0) names.push(b.name); });
      rows('halls').forEach(h => { const b = M.find(T.c, h.hall); if (b && names.indexOf(b.name) < 0) names.push(b.name); });
      const count = n => rows('doors').filter(d => M.norm(d.building) === M.norm(n)).length;
      const none = names.filter(n => !count(n)), some = names.filter(n => count(n));
      const group = n => {
        const ds = rows('doors').filter(d => M.norm(d.building) === M.norm(n));
        return '<section class="pp-group"><div class="pp-b"><p class="pp-b__h"><b>' + esc(siteName(n, ps)) + '</b></p><p class="pp-b__s">' + (ds.length ? '' : '<span title="Routes end at the nearest side of the building">No doors</span>') + '<button type="button" class="pm-link" data-pp="adddoor" data-b="' + esc(n) + '">' + I.plus + 'Add door</button></p></div>' +
          '<ul class="pp-rows">' + ds.map((d, i) => {
            const on = T.open === 'd:' + d.id;
            return '<li class="pp-row' + (on ? ' is-on' : '') + '"><button type="button" class="pp-row__n" data-pp="open" data-v="d:' + esc(d.id) + '" aria-expanded="' + on + '"><b><span class="pp-num">' + (i + 1) + '</span>' + esc(d.label || 'Door ' + (i + 1)) + '</b><small>' + esc([d.step_free === 'yes' ? 'Step-free' : d.step_free === 'no' ? 'Steps' : '', d.key_only ? 'Key only' : '', d.open, d.checked ? 'Checked' : 'Not checked'].filter(Boolean).join(' · ')) + '</small></button>' +
              (on ? '<div class="pp-detail"><p class="pp-f"><label><span>Name</span>' + field('label', d.label, 'West doors', 'd:' + d.id) + '</label></p>' +
                '<p class="pp-f"><span>Step-free</span>' + pills('step_free', d.step_free, [['yes', 'Yes'], ['no', 'No']], ' data-row="d:' + esc(d.id) + '"') + '</p>' +
                '<p class="pp-f"><span>Key only</span>' + pills('key_only', d.key_only, [['', 'No'], ['yes', 'Yes']], ' data-row="d:' + esc(d.id) + '"') + '</p>' +
                '<p class="pp-f"><label><span>Open</span>' + field('open', d.open, '7 AM–11 PM', 'd:' + d.id) + '</label></p>' +
                '<p class="pm-btns">' + (d.checked ? '<span class="pp-dim">Checked ' + esc(d.checked) + '</span>' : '<button type="button" class="pm-btn pm-btn--line" data-pp="checkdoor" data-id="' + esc(d.id) + '">' + I.check + 'Checked</button>') + '<button type="button" class="pm-link" data-pp="movedoor" data-id="' + esc(d.id) + '">Move</button><button type="button" class="pm-link" data-pp="rmdoor" data-id="' + esc(d.id) + '">Remove</button></p></div>' : '') + '</li>';
          }).join('') + '</ul></section>';
      };
      return (none.length ? '<p class="pm-k pp-k">To add</p>' + none.map(group).join('') + (some.length ? '<p class="pm-k pp-k">Buildings</p>' : '') : '') + some.map(group).join('');
    }
    function outdoorsTab(w) {
      const out = Object.values(w.ps).filter(p => p.outdoor === 'yes');
      const spots = rows('spots');
      return (out.length ? '<section class="pp-group"><div class="pp-b"><p class="pp-b__h"><b>Fields and greens</b></p></div><ul class="pp-rows">' + out.map(p => roomRow(p, w.ps, '')).join('') + '</ul></section>' : '') +
        '<section class="pp-group"><div class="pp-b"><p class="pp-b__h"><b>Parking and services</b></p><p class="pp-b__s">' + SPOTS.map(k => '<button type="button" class="pm-link" data-pp="addspot" data-v="' + k + '">' + I.plus + esc(M.SPOT[k]) + '</button>').join(' ') + '</p></div>' +
        '<ul class="pp-rows">' + spots.map(s => {
          const on = T.open === 's:' + s.id;
          return '<li class="pp-row' + (on ? ' is-on' : '') + '"><button type="button" class="pp-row__n" data-pp="open" data-v="s:' + esc(s.id) + '" aria-expanded="' + on + '"><b>' + esc(s.name || M.SPOT[s.kind]) + '</b><small>' + esc(M.SPOT[s.kind] || '') + '</small></button>' +
            (on ? '<div class="pp-detail"><p class="pp-f"><label><span>Name</span>' + field('name', s.name, M.SPOT[s.kind], 's:' + s.id) + '</label></p><p class="pp-f"><label><span>Note</span>' + field('note', s.note, '45th Street entrance', 's:' + s.id) + '</label></p>' +
              '<p class="pm-btns"><button type="button" class="pm-link" data-pp="movespot" data-id="' + esc(s.id) + '">Move</button><button type="button" class="pm-link" data-pp="rmspot" data-id="' + esc(s.id) + '">Remove</button></p></div>' : '') + '</li>';
        }).join('') + '</ul></section>';
    }
    // Polish 2: "From the university" comes only from uploading the university's plan (Template, then
    // Upload, with each floor shown before it's used); "Checked" only on such a plan, with who and when.
    // A sample plan can't be marked as fact by a tap (households would see IWU's sample as their hall).
    function hallsTab() {
      const hs = rows('halls');
      if (!hs.length) return '<div class="ws-blank"><p class="ws-blank__h">No halls</p></div>';
      const day = d => d ? O.fmtDate ? O.fmtDate(d, 'mdShort') : d : '';
      // Polish 3: the plan's state in words ("Sample plan", "From the university · Oct 9 · Sarah C.",
      // "Checked · Oct 10 · Nathan K."), never a disabled Checked button that reads as a status; Mark
      // checked appears only once the university's plan is in.
      return '<ul class="pp-rows">' + hs.map(h => {
        const st = h.status === 'checked' ? ['Checked', day(h.checked_on), h.checked_name].filter(Boolean).join(' · ') : h.status === 'university' ? ['From the university', day(h.uploaded_on), h.uploaded_name].filter(Boolean).join(' · ') : 'Sample plan';
        const up = T.upload && T.upload.hall === h.hall ? T.upload : null;
        const check = h.status === 'university' ? '<button type="button" class="pm-btn pm-btn--line" data-pp="planchecked" data-hall="' + esc(h.hall) + '" title="The plan matches the hall: rooms, numbers, floors">' + I.check + 'Mark checked</button>' : '';
        return '<li class="pp-row is-on"><div class="pp-row__n"><b>' + esc(h.hall) + '</b><small>' + esc(st) + (M.find(T.c, h.hall) ? '' : ' · Not on the map') + '</small></div>' +
          '<div class="pp-detail"><p class="pp-f"><span>Plan</span><span class="pm-btns">' + check + '<button type="button" class="pm-link" data-pp="plantpl" data-hall="' + esc(h.hall) + '" title="This hall’s plan as a spreadsheet, to fill in from the university’s">Template</button>' +
          '<button type="button" class="pm-link" data-pp="planpick" title="The filled-in spreadsheet">Upload</button><input type="file" accept=".csv,text/csv" data-pp="planfile" data-hall="' + esc(h.hall) + '" hidden></span></p>' +
          (up ? upPreview(up) : '') +
          ['elevator', 'step_free', 'ac'].map(k => '<p class="pp-f"><span>' + ({ elevator: 'Elevator', step_free: 'Step-free entrance', ac: 'Air conditioning' })[k] + '</span>' + pills(k, h[k], [['yes', 'Yes'], ['no', 'No']], ' data-row="h:' + esc(h.hall) + '"') + '</p>').join('') + '</div></li>';
      }).join('') + '</ul>';
    }
    // An upload, before it's used: what it holds, and each floor drawn.
    function upPreview(up) {
      if (up.err) return '<p class="pp-f pp-warn">' + esc(up.err) + '</p>';
      if (!up.sum) return '<p class="pp-f pp-dim">Reading</p>';
      const fl = Object.keys(up.sum.floors);
      const halls = M.plans(up.rows.map(r => Object.assign({}, r, { hall: up.hall, status: 'university' })));
      const drawn = halls[up.hall] ? halls[up.hall].list.map(f => '<div class="pp-upfloor"><p class="pm-k">' + esc(M.floorName(f.floor)) + ' · ' + f.rooms.length + ' rooms</p>' + M.floorSvg(f, { state: () => 'plain', sampleHref: '' }) + '</div>').join('') : '';
      return '<div class="pp-up"><p class="pp-f"><b>' + esc(fl.length + (fl.length === 1 ? ' floor · ' : ' floors · ') + up.sum.rooms + ' rooms') + '</b></p>' + drawn +
        '<p class="pm-btns"><button type="button" class="pm-btn" data-pp="planapply" data-hall="' + esc(up.hall) + '">' + I.check + 'Use this plan</button><button type="button" class="pm-link" data-pp="plancancel">Cancel</button></p></div>';
    }
    const csvCell = v => /[",\n]/.test(String(v)) ? '"' + String(v).replace(/"/g, '""') + '"' : String(v);
    function planTemplate(hall) {
      const cols = ['hall', 'floor', 'kind', 'label', 'x', 'y', 'w', 'h', 'note'];
      const list = rows('plans').filter(r => M.norm(r.hall) === M.norm(hall));
      const text = [cols.join(',')].concat((list.length ? list : [{ hall, floor: 1, kind: 'room', label: '101', x: 0, y: 0, w: 16, h: 16, note: '' }]).map(r => cols.map(k => csvCell(r[k] == null ? '' : r[k])).join(','))).join('\r\n') + '\r\n';
      const a = document.createElement('a');
      a.href = URL.createObjectURL(new Blob([text], { type: 'text/csv' }));
      a.download = 'plan-' + hall.toLowerCase().replace(/[^a-z0-9]+/g, '-') + '.csv';
      document.body.appendChild(a); a.click(); a.remove();
      setTimeout(() => URL.revokeObjectURL(a.href), 2000);
    }
    function planFile(input) {
      const f = input.files && input.files[0], hall = input.dataset.hall; if (!f) return;
      T.upload = { hall, rows: [] }; draw();
      f.text().then(text => {
        const rs = O.csvToObjects(text).filter(r => r.kind);
        T.upload.rows = rs;
        return OGC_WP.api('POST', 'years/' + T.year + '/campus-plan', { hall, rows: rs, apply: false });
      }).then(sum => { if (T.upload && T.upload.hall === hall) { T.upload.sum = sum; draw(); } })
        .catch(e => { if (T.upload) { T.upload.err = e.data && e.data.message ? e.data.message : 'Couldn’t read the file'; draw(); } });
    }
    function planApply(hall) {
      const up = T.upload; if (!up || up.hall !== hall) return;
      status('Saving');
      OGC_WP.api('POST', 'years/' + T.year + '/campus-plan', { hall, rows: up.rows, apply: true })
        .then(() => { T.upload = null; status('Saved'); return load(); }).then(() => toast(hall + ' · From the university'))
        .catch(e => { status(''); toast(e.data && e.data.message ? e.data.message : 'Not saved'); });
    }
    function closuresTab() {
      const cs = rows('closures');
      return '<p class="pp-b__s"><button type="button" class="pm-link" data-pp="addclosure">' + I.plus + 'Add closure</button></p><ul class="pp-rows">' + cs.map(s => '<li class="pp-row is-on"><div class="pp-row__n"><b>' + esc(s.note || 'Closed') + '</b><small>' + esc([s.from, s.to].filter(Boolean).join(' – ') || 'Every day') + '</small></div>' +
        '<div class="pp-detail"><p class="pp-f"><label><span>Note</span>' + field('note', s.note, 'Sidewalk closed', 'c:' + s.id) + '</label></p><p class="pp-f"><label><span>From</span><input type="date" class="pp-in" data-pp="text" data-f="from" data-row="c:' + esc(s.id) + '" value="' + esc(s.from) + '"></label></p><p class="pp-f"><label><span>To</span><input type="date" class="pp-in" data-pp="text" data-f="to" data-row="c:' + esc(s.id) + '" value="' + esc(s.to) + '"></label></p>' +
        '<p class="pm-btns"><button type="button" class="pm-link" data-pp="rmclosure" data-id="' + esc(s.id) + '">Remove</button></p></div></li>').join('') + '</ul>';
    }

    /* ---------------------------------------------------------- pinning */

    // On a phone, pinning opens the map full screen with the bar under the thumb (polish 2: a 330 px map
    // under the sticky header and the Save bar).
    const phone = () => window.matchMedia && matchMedia('(max-width: 899px)').matches;
    function lockFull(on) { T.el.classList.toggle('is-pinning', !!on && phone()); document.documentElement.classList.toggle('pp-lock', !!on && phone()); }
    function start(mode) {
      T.mode = mode;
      lockFull(true);
      if (touch() && mode.kind !== 'building') watchGps();
      draw();
      const m = places()[mode.code];
      const b = mode.building ? M.find(T.c, mode.building) : null;
      // On a phone with a fix: the blue dot and its circle, to tap the door beside it.
      if (T.gps && M.onCampus(T.c, T.gps)) T.map.fit({ x: T.gps.x - 40, y: T.gps.y - 40, w: 80, h: 80 }, 30, true);
      else if (m && hasPin(m)) T.map.fit({ x: +m.x - 60, y: +m.y - 60, w: 120, h: 120 }, 30, true);
      else if (b) T.map.fit(M.boxOf(T.c, [b.name], 30), 30, true);
      else if (mode.outdoor && m) { const g = greenNear(m); if (g) T.map.fit({ x: g.lx - 60, y: g.ly - 60, w: 120, h: 120 }, 30, true); }
      if (!phone()) T.el.querySelector('.pp-map').scrollIntoView({ block: 'nearest', behavior: 'smooth' });
    }
    function stop() { T.mode = null; lockFull(false); draw(); }
    // What a tab is about, framed when it opens (polish 3: the Halls tab kept Barnes picked and cut Evans
    // off): the halls with rooms, the main buildings for Doors, the fields and spots for Outdoors.
    function tabBox() {
      const ps = places(), used = Object.values(ps).filter(p => p.outdoor !== 'yes').map(p => M.buildingFor(T.c, p, ps)).filter(Boolean).map(b => b.name);
      if (T.tab === 'halls') return M.boxOf(T.c, rows('halls').map(h => (M.find(T.c, h.hall) || {}).name).filter(Boolean), 30);
      if (T.tab === 'outdoors') {
        const pts = Object.values(ps).filter(p => p.outdoor === 'yes' && hasPin(p)).map(p => [+p.x, +p.y]).concat(rows('spots').filter(r => r.x !== '').map(r => [+r.x, +r.y]));
        Object.values(ps).filter(p => p.outdoor === 'yes' && !hasPin(p)).forEach(p => { const g = greenNear(p); if (g) g.pts.forEach(q => pts.push(q)); });
        if (!pts.length) return null;
        const xs = pts.map(q => q[0]), ys = pts.map(q => q[1]), x0 = Math.min.apply(null, xs), y0 = Math.min.apply(null, ys);
        return { x: x0 - 30, y: y0 - 30, w: Math.max.apply(null, xs) - x0 + 60, h: Math.max.apply(null, ys) - y0 + 60 };
      }
      return M.boxOf(T.c, core(Array.from(new Set(used))), 30);
    }
    // An outdoor place's green: the field nearest its building (a field isn't its building).
    function greenNear(p) {
      const b = M.buildingFor(T.c, p, places()); if (!b) return null;
      return T.c.items.filter(i => i.kind === 'green' && i.pts.length > 2).sort((a, z) => Math.hypot(a.lx - b.lx, a.ly - b.ly) - Math.hypot(z.lx - b.lx, z.ly - b.ly))[0] || null;
    }
    function tap(pt, bname, spot, door) {
      const m = T.mode;
      if (!m) {
        if (door) { T.open = 'd:' + door; T.tab = 'doors'; draw(); }
        return;
      }
      if (m.kind === 'building') { if (!bname) return; m.draft = pt; m.building = bname; m.label = bname; draw(); return; }
      m.draft = { x: pt.x, y: pt.y };
      draw();
      if (T.map.view().w > 200) T.map.fit({ x: pt.x - 60, y: pt.y - 60, w: 120, h: 120 }, 30, true);
    }
    // The location, on a phone, from the first Pin until the page is hidden: it aims the map and
    // puts the building you're in first; it never blocks a pin.
    function watchGps() {
      if (!touch() || T.watch != null) return;
      T.gpsState = 'locating';
      T.watch = navigator.geolocation.watchPosition(pos => {
        const p = M.toMap(T.c, pos.coords.latitude, pos.coords.longitude);
        if (!p) return;
        const first = !T.gps;
        p.acc = pos.coords.accuracy; T.gps = p; T.gpsState = 'on';
        const b = T.el.querySelector('.pp-bar'); if (b) b.outerHTML = bar();
        T.map.me(p);
        if (first && T.mode && M.onCampus(T.c, p) && !T.mode.draft) T.map.fit({ x: p.x - 40, y: p.y - 40, w: 80, h: 80 }, 30, true);
      }, () => { T.gpsState = 'off'; stopGps(); const b = T.el.querySelector('.pp-bar'); if (b) b.outerHTML = bar(); }, { enableHighAccuracy: true, maximumAge: 2000, timeout: 20000 });
    }
    function stopGps() { if (T.watch != null) navigator.geolocation.clearWatch(T.watch); T.watch = null; T.gps = null; if (T.map) T.map.me(null); }
    document.addEventListener('visibilitychange', () => { if (document.hidden) stopGps(); else if (T.mode && touch()) watchGps(); });
    function commit() {
      const m = T.mode; if (!m || !m.draft) return;
      const d = m.draft, x = d.x.toFixed(1), y = d.y.toFixed(1);
      lockFull(false);
      if (m.kind === 'place') {
        const p = places()[m.code], before = rows('places').find(r => String(r.code).toUpperCase() === m.code);
        const row = { code: p.code, name: p.name, building: p.building || '', x, y, checked: today() };
        stop(); T.open = 'p:' + p.code;
        save('places', row, before ? { code: before.code, x: before.x, y: before.y } : { code: p.code, x: '', y: '' }, p.name + ' pinned');
      } else if (m.kind === 'building') {
        const p = places()[m.code];
        stop();
        save('places', { code: p.code, name: p.name, building: p.building || '', mapped: m.building }, { code: p.code, mapped: '' }, p.name + ' · ' + m.building);
      } else if (m.kind === 'door') {
        const id = m.id || 'd' + Math.random().toString(36).slice(2, 9), before = m.id ? rows('doors').find(r => r.id === m.id) : null;
        stop(); T.open = 'd:' + id;
        save('doors', Object.assign({}, before || { label: '', step_free: '', open: '', key_only: '', checked: '' }, { id, building: m.building, x, y }), before ? Object.assign({}, before) : { id, _gone: 1 }, before ? 'Door moved' : 'Door added');
      } else if (m.kind === 'spot') {
        const id = m.id || 's' + Math.random().toString(36).slice(2, 9), before = m.id ? rows('spots').find(r => r.id === m.id) : null;
        stop(); T.open = 's:' + id;
        save('spots', Object.assign({}, before || { name: M.SPOT[m.spot], note: '' }, { id, kind: m.spot, x, y }), before ? Object.assign({}, before) : { id, _gone: 1 }, (before ? before.name : M.SPOT[m.spot]) + ' pinned');
      } else if (m.kind === 'closure') {
        const id = 'c' + Math.random().toString(36).slice(2, 9);
        stop();
        save('closures', { id, x, y, from: '', to: '', note: '' }, { id, _gone: 1 }, 'Closure added');
      }
    }

    /* ---------------------------------------------------------- acting */

    function rowOf(ref) {
      const k = ref.slice(0, 2), v = ref.slice(2);
      if (k === 'd:') return ['doors', rows('doors').find(r => r.id === v)];
      if (k === 's:') return ['spots', rows('spots').find(r => r.id === v)];
      if (k === 'h:') return ['halls', rows('halls').find(r => r.hall === v)];
      if (k === 'c:') return ['closures', rows('closures').find(r => r.id === v)];
      const p = places()[String(ref).toUpperCase()];
      return ['places', p ? Object.assign({ code: p.code, name: p.name, building: p.building }, rows('places').find(r => String(r.code).toUpperCase() === String(p.code).toUpperCase()) || {}) : null];
    }
    function setField(ref, f, v) {
      const [part, r] = rowOf(ref); if (!r) return;
      const key = { places: 'code', doors: 'id', spots: 'id', halls: 'hall', closures: 'id' }[part];
      const row = { [key]: r[key], [f]: v }, before = { [key]: r[key], [f]: r[f] == null ? '' : r[f] };
      if (part === 'places') Object.assign(row, { name: r.name, building: r.building || '' });
      save(part, row, before, null);
    }
    T.el.addEventListener('click', e => {
      const b = e.target.closest('[data-pp]'); if (!b || b.disabled) return;
      const k = b.dataset.pp, ps = places();
      if (k === 'tab') { T.tab = b.dataset.v; T.open = b.dataset.open || ''; T.mode = null; lockFull(false); draw(); const bx = tabBox(); if (bx && !b.dataset.open) T.map.fit(bx, 20, true); else if (b.dataset.open && b.dataset.open.indexOf('b:') === 0) T.map.fit(M.boxOf(T.c, [b.dataset.open.slice(2)], 30), 30, true); }
      else if (k === 'open') { T.open = T.open === b.dataset.v ? '' : b.dataset.v; draw(); }
      else if (k === 'pin') { const p = ps[b.dataset.code], bl = M.buildingFor(T.c, p, ps); T.open = 'p:' + p.code; start({ kind: 'place', code: p.code, label: p.name, outdoor: p.outdoor === 'yes', building: p.outdoor === 'yes' ? '' : bl ? bl.name : '' }); }
      else if (k === 'save') commit();
      else if (k === 'cancel') stop();
      else if (k === 'clear') { const p = ps[b.dataset.code], r = rows('places').find(x => String(x.code).toUpperCase() === p.code) || {}; save('places', { code: p.code, name: p.name, building: p.building || '', x: '', y: '' }, { code: p.code, x: r.x || '', y: r.y || '' }, p.name + ' unpinned'); }
      else if (k === 'checked') setField(b.dataset.code, 'checked', today());
      else if (k === 'set') setField(b.dataset.row || T.open.slice(2), b.dataset.f, b.dataset.v);
      else if (k === 'choose') { const p = ps[b.dataset.code]; start({ kind: 'building', code: p.code, label: p.name }); }
      else if (k === 'adddoor') start({ kind: 'door', building: b.dataset.b, label: 'New door · ' + siteName(b.dataset.b) });
      else if (k === 'movedoor') { const d = rows('doors').find(r => r.id === b.dataset.id); start({ kind: 'door', id: d.id, building: d.building, label: d.label || 'Door' }); }
      else if (k === 'checkdoor') setField('d:' + b.dataset.id, 'checked', today());
      else if (k === 'rmdoor') { const d = rows('doors').find(r => r.id === b.dataset.id); T.open = ''; save('doors', { id: d.id, _gone: 1 }, Object.assign({}, d), 'Door removed'); }
      else if (k === 'addspot') start({ kind: 'spot', spot: b.dataset.v, label: M.SPOT[b.dataset.v] });
      else if (k === 'movespot') { const s = rows('spots').find(r => r.id === b.dataset.id); start({ kind: 'spot', id: s.id, spot: s.kind, label: s.name || M.SPOT[s.kind] }); }
      else if (k === 'rmspot') { const s = rows('spots').find(r => r.id === b.dataset.id); T.open = ''; save('spots', { id: s.id, _gone: 1 }, Object.assign({}, s), (s.name || 'Spot') + ' removed'); }
      else if (k === 'addclosure') start({ kind: 'closure', label: 'Closure' });
      else if (k === 'plantpl') planTemplate(b.dataset.hall);
      else if (k === 'planpick') { const f = b.nextElementSibling; if (f) { f.value = ''; f.click(); } }
      else if (k === 'planapply') planApply(b.dataset.hall);
      else if (k === 'plancancel') { T.upload = null; draw(); }
      else if (k === 'planchecked') setField('h:' + b.dataset.hall, 'status', 'checked');
      else if (k === 'rmclosure') { const s = rows('closures').find(r => r.id === b.dataset.id); save('closures', { id: s.id, _gone: 1 }, Object.assign({}, s), 'Closure removed'); }
    });
    // Text: saved when it's left (or Enter), not on every key.
    T.el.addEventListener('change', e => { const t = e.target; if (t.matches('[data-pp="text"]')) setField(t.dataset.row, t.dataset.f, t.value.trim()); else if (t.matches('[data-pp="planfile"]')) planFile(t); });
    T.el.addEventListener('keydown', e => { if (e.key === 'Enter' && e.target.matches('[data-pp="text"]')) e.target.blur(); if (e.key === 'Escape' && T.mode) stop(); });

    function toast(t, undo) {
      const el = T.el.querySelector('.pp-toast'); if (!el) return;
      el.innerHTML = '<span>' + esc(t) + '</span>' + (undo ? '<button type="button">' + I.undo + 'Undo</button>' : '');
      el.hidden = false;
      if (undo) el.querySelector('button').onclick = () => { el.hidden = true; undo(); };
      clearTimeout(T.toastT); T.toastT = setTimeout(() => { el.hidden = true; }, undo ? 10000 : 4000);
    }

    return { mount, year: opts.year, reload: load };
  };
})();
