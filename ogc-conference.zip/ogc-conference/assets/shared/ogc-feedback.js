/*
 * ogc-feedback.js — the shared prototype's feedback board (Oct 31, 2026; it replaces the Oct 30 Feedback
 * button). Loaded with ogc-dev-nav.js and ogc-feedback-api.js: the local site and the shared prototype
 * only, never on ogbbc.org. Michael: "a very clear button for somebody who's looking at it, who's not very
 * tech-savvy, to be able to leave feedback… make it clear that it's not part of the interface", "by
 * default it needs to capture the screen", "require their name", and "a public community center for
 * feedback": a count on each screen, a feed others comment on and upvote, all screens in one spot.
 *
 * It draws, in the demo's own look (ogc-dev-nav.js: near-black, the system font, white for the one action):
 *   - in the dock, beside the demo pill: Leave feedback, and this screen's count of open ideas (only when
 *     there are some here; with none here but some elsewhere, the same place is a plain icon to the board);
 *   - the composer: Leave feedback takes a picture of the screen as the visitor sees it (without our own
 *     controls), then asks for the idea and a name (required, remembered). Point to it: tap the thing you
 *     mean; a pin is drawn on the picture. Retake, Remove. It sends by itself the screen, the page, the day
 *     the pill holds, who's signed in and the screen's size;
 *   - the board (Nov 4, after the Oct 31 three panes; Michael: the feed first, "and then like a sidebar…
 *     that contains like a Screen selector"; "ease of use and just simplicity for the end user"): a light
 *     page of its own over the demo. At the left every screen of the demo by area, each with its own
 *     picture (taken from the demo, never an idea's) and its count; All feedback and All screens (a tile a
 *     screen) above them. In the middle the feed, newest first by day: each idea a card with who, the
 *     screen, when, the words, its picture cropped around the pin (it enlarges), then Upvote, Reply and its
 *     replies, the same on every card; the day, person, device, what was pointed at, Go to screen, Delete,
 *     Resolve or Reopen wait behind its ⋯. Sort (newest, oldest, most upvoted, most replies), people and
 *     Open or Resolved float at the top, with Leave feedback, ⋯ (Admin) and Close. ← → step through the
 *     screens, J/K through the ideas, Escape closes. On a phone the screens are a menu at the top left.
 *     One's own idea or reply has Delete. The ⋯ menu's Admin asks once for the admin key; then every idea
 *     has Resolve or Reopen, and Delete.
 *
 * Over a pop-up: everything here draws into the dock's root (OGC_DOCK.root, ogc-dev-nav.js), which moves
 * into an open modal dialog's top layer, so Leave feedback, the board and Point to it work over a sheet
 * without closing it, and the picture shows the sheet over the page, dimmed as on screen.
 *
 * The store is behind window.OGC_FEEDBACK (ogc-feedback-api.js). With no store (the prototype without a
 * board address), nothing is drawn.
 *
 * The screen an idea is about (its key): the page's path from the site's home, plus only the parameters
 * that choose what the screen is, sorted: view, s, c, v, edit, part, committee, tab, tool, role by their
 * value, and shift by its name only (a shift's sheet is one screen, whichever shift). Everything else is
 * left out (year, as-of, tz, preview, return, id, at, f, from, as, team, pages…), so the same screen on two
 * days, or with another record open beside it, counts once. Examples:
 *   /annual-conference/?year=2027&as-of=2027-03-02T09:00      → annual-conference/
 *   /annual-conference/app/?year=2027&s=shifts&c=food&id=12  → annual-conference/app/?c=food&s=shifts
 *   /annual-conference/volunteer/?committee=food&shift=f-3   → annual-conference/volunteer/?committee=food&shift
 * The board names each screen plainly ("Conference page", "Register", "Your sign-ups", "Guide · Help"):
 * a key can hold ideas left under several titles ("2026 Annual Conference", "2027 Annual Conference").
 *
 * The picture: html-to-image 1.11.11 from jsDelivr (pinned, with its integrity hash), loaded only when
 * Leave feedback is first pressed. It draws the page from its own styles, so text, shadows and closed
 * folds come out as on screen (html2canvas 1.4.1 moved text and showed closed folds on these pages). The
 * page is drawn at its scroll position, with its fixed bars put back where they are on screen, inner
 * scrolled panels at their scroll, and an open modal dialog over the page with its dimming. If it can't
 * load (offline, a blocked script) the idea goes without one.
 */
(function () {
  'use strict';
  const W = window.OGC_WP || {};
  if (!W.dev && !W.prototype) return;
  const framed = (() => { try { return window.top !== window && !!(window.parent && window.parent.OGC_WP); } catch (e) { return false; } })();
  if (framed) return;
  const API = window.OGC_FEEDBACK;
  if (!API || !API.mode) return;

  const LIB = 'https://cdn.jsdelivr.net/npm/html-to-image@1.11.11/dist/html-to-image.js';
  const LIB_SRI = 'sha384-UbfRVKN3/elS1r7JcK2FhmPP+KlJ4CvYwbyYD7tH+uTkbT9bNJr9eJeQ0FoFbAgz';
  const SANS = 'system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,sans-serif';
  const home = W.home || '/';
  const base = W.base || '/annual-conference/';
  const baseRel = base.indexOf(home) === 0 ? base.slice(home.length) : base.replace(/^\//, '');
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
  const narrow = () => innerWidth < 600;
  const touchy = () => !!(window.matchMedia && matchMedia('(pointer: coarse)').matches);
  const SS = {
    get(k, d) { try { const v = sessionStorage.getItem(k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } },
    set(k, v) { try { sessionStorage.setItem(k, JSON.stringify(v)); } catch (e) { /* not kept */ } }
  };
  const dockInfo = () => window.OGC_DOCK || {};
  // Where our surfaces draw: the dock's root (it follows an open pop-up), else the page's body.
  const layer = () => dockInfo().root || document.body;

  /* ------------------------------------------------------------------ the screen an idea is about */

  const BY_VALUE = ['view', 's', 'c', 'v', 'edit', 'part', 'committee', 'tab', 'tool', 'role'];
  const BY_NAME = ['shift'];
  const part = s => String(s).replace(/[^\w\-.%~]/g, c => encodeURIComponent(c).replace(/[!'()*]/g, x => '%' + x.charCodeAt(0).toString(16).toUpperCase()));
  function screenKey(href) {
    const u = new URL(href || location.href, location.href);
    let p = u.pathname.indexOf(home) === 0 ? u.pathname.slice(home.length) : u.pathname.replace(/^\//, '');
    p = p.split('/').map(part).join('/').replace(/\/{2,}/g, '/');
    if (p && !/\/$/.test(p) && !/\.[a-z0-9]{1,5}$/i.test(p)) p += '/';
    const q = [];
    BY_VALUE.forEach(k => { const v = u.searchParams.get(k); if (v) q.push(k + '=' + part(v)); });
    BY_NAME.forEach(k => { if (u.searchParams.get(k)) q.push(k); });
    q.sort();
    return ((p || '/') + (q.length ? '?' + q.join('&') : '')).slice(0, 300);
  }
  // The page's name, without the site's.
  const screenTitle = () => String(document.title || '').split(' – ')[0].replace(/ · \d{4} Conference$/, '').trim().slice(0, 120);
  // This page from the site's home, as it is now ("/annual-conference/register/?year=2027&as-of=…").
  const pagePath = () => { const p = location.pathname; return '/' + (p.indexOf(home) === 0 ? p.slice(home.length) : p.replace(/^\//, '')) + location.search; };
  function context() {
    const d = dockInfo(), m = d.moment || {};
    const at = m.at || (new URLSearchParams(location.search).get('as-of') || '').slice(0, 16);
    return {
      screen: screenKey(), title: screenTitle(), page: pagePath().slice(0, 600),
      at: /^\d{4}-\d\d-\d\dT\d\d:\d\d$/.test(at) ? at : '', moment: m.text && m.text !== 'Today' ? m.text : '',
      as: noEmail(d.who || (W.me ? W.me.name || 'Signed in' : 'Visitor')), size: innerWidth + '×' + innerHeight
    };
  }
  // Who was signed in, never their email: the board is public to everyone with the link.
  function noEmail(v) { return /@/.test(String(v || '')) ? 'Signed in' : String(v || ''); }

  // What the idea was left on, from its screen size ("390×844"): a page looks different on a phone, so an
  // idea about it may be too (Oct 31, Michael).
  function deviceOf(size) {
    const w = parseInt(String(size || ''), 10);
    return !w ? '' : w < 600 ? 'Phone' : w < 1024 ? 'Tablet' : 'Computer';
  }

  // A screen's plain name, from its key: the page (from the Conference's own address), then its view.
  // Pages not named here are named by the titles their ideas were left under, years taken out.
  const PAGES = {
    '': ['Conference page', { full: 'Conference page · Schedule', places: 'Conference page · Places', help: 'Conference page · Help', today: 'Conference page · Today', services: 'Conference page' }],
    'guide/': ['Guide', { full: 'Guide · Schedule', today: 'Guide · Today', places: 'Guide · Places', help: 'Guide · Help', services: 'Guide · Services' }],
    'register/': ['Register', { mine: 'Your sign-ups', receipt: 'Receipt', edit: 'Change registration', done: 'Registered', approve: 'Parent approval', checkout: 'Checkout' }],
    'volunteer/': ['Volunteer', { mine: 'Your sign-ups', lead: 'Who’s signed up' }],
    'tournaments/': ['Tournaments', { mine: 'My teams', teams: 'Tournament teams' }],
    'packet/': ['Information packet'], 'schedule/': ['Printed schedule'], 'lodging/': ['Lodging'], 'lists/': ['Lists'],
    'signin/': ['Sign in'], 'members/': ['Members'], 'mail/': ['Mail log'], 'admin/': ['Admin'], 'year/': ['The year'], 'app/': ['App']
  };
  const plainTitle = t => String(t || '').replace(/\s*·\s*\d{4} Conference guide$/, '').replace(/\b(19|20)\d\d\b\s*/g, '').replace(/\s*·\s*$/, '').trim();
  function nameOf(key, items) {
    const q = key.indexOf('?'), path = q < 0 ? key : key.slice(0, q), ps = new URLSearchParams(q < 0 ? '' : key.slice(q + 1));
    const rel = path.indexOf(baseRel) === 0 ? path.slice(baseRel.length) : null;
    const tally = {};
    (items || []).forEach(x => { const t = plainTitle(x.title); if (t) tally[t] = (tally[t] || 0) + 1; });
    const common = Object.keys(tally).sort((a, b) => tally[b] - tally[a])[0] || '';
    const pg = rel != null ? PAGES[rel] : null;
    if (!pg) return common || key;
    const view = ps.get('view');
    let n = pg[0];
    if (view && pg[1] && pg[1][view]) n = pg[1][view];
    else if (rel === 'volunteer/' && ps.get('committee')) n = 'Volunteer · ' + (common || ps.get('committee'));
    else if ((view || [...ps.keys()].length) && common && common !== n) n += ' · ' + common;
    if (rel === 'volunteer/' && ps.has('shift')) n += ' · Shift';
    if (rel === 'app/' && ps.get('c')) n += ' · ' + ps.get('c').charAt(0).toUpperCase() + ps.get('c').slice(1).replace(/-/g, ' ');
    return n;
  }

  /* ------------------------------------------------------------------ the look */

  const LINE = 'rgba(255,255,255,.08)';
  const css =
    // In the dock: this screen's count, then Leave feedback (a white pill inside the 44 px tap).
    '.ogc-fb-n{display:inline-flex;align-items:center;justify-content:center;gap:6px;min-width:44px;height:44px;margin:0;padding:0 10px;border:0;border-radius:22px;background:transparent;color:#f2f2f2;font:600 13px/1 ' + SANS + ';cursor:pointer}' +
    '.ogc-fb-n:hover,.ogc-fb-n[aria-expanded=true]{background:rgba(255,255,255,.08)}.ogc-fb-n[hidden]{display:none}' +
    '.ogc-fb-n svg{flex:none;width:16px;height:16px;color:#d4d4d4}' +
    '.ogc-fb-go{display:inline-flex;align-items:center;height:44px;margin:0;padding:0 4px 0 2px;border:0;border-radius:22px;background:transparent;cursor:pointer;font:600 13px/1 ' + SANS + '}' +
    '.ogc-fb-go__in{display:inline-flex;align-items:center;gap:6px;height:36px;padding:0 14px 0 11px;border-radius:18px;background:#f2f2f2;color:#111;white-space:nowrap;box-shadow:inset 0 1px 0 rgba(255,255,255,.16)}' +
    '.ogc-fb-go:hover .ogc-fb-go__in{background:#fff}.ogc-fb-go[aria-expanded=true] .ogc-fb-go__in{background:#d4d4d4}' +
    '.ogc-fb-go svg{flex:none;width:14px;height:14px}.ogc-fb-go__s{display:none}' +
    '.ogc-pill .ogc-fb-go:focus-visible{outline:none}.ogc-fb-go:focus-visible .ogc-fb-go__in{outline:2px solid #f2f2f2;outline-offset:2px}' +
    '@media (max-width:399px){.ogc-fb-go__l{display:none}.ogc-fb-go__s{display:inline}}' +

    // The demo's surfaces: the composer, the board, the toast, the picture enlarged.
    '.ogc-fbx-ui{box-sizing:border-box;color:#f2f2f2;font:400 14px/1.45 ' + SANS + ';letter-spacing:0;text-transform:none;-webkit-font-smoothing:antialiased;text-align:left}' +
    '.ogc-fbx-ui *{box-sizing:border-box}.ogc-fbx-ui[hidden],.ogc-fbx-ui [hidden]{display:none!important}' +
    '.ogc-fbx-ui h2,.ogc-fbx-ui h3{margin:0;padding:0;color:#f2f2f2;font:650 16px/1.25 ' + SANS + ';letter-spacing:0;text-transform:none}' +
    '.ogc-fbx-ui p{margin:0;padding:0}.ogc-fbx-ui ul{margin:0;padding:0;list-style:none}.ogc-fbx-ui li{margin:0;padding:0}' +
    '.ogc-fbx-ui button{font-family:' + SANS + ';letter-spacing:0;text-transform:none;text-decoration:none}' +
    '.ogc-fbx-ui :focus-visible{outline:2px solid #f2f2f2;outline-offset:2px}.ogc-fbx-ui :focus:not(:focus-visible){outline:none}' +
    '.ogc-fbx-ui [tabindex="-1"]:focus{outline:none}' +
    // Buttons: one filled (white) a view; quiet ones are words on the dark.
    '.ogc-fbp{display:inline-flex;align-items:center;justify-content:center;gap:6px;min-height:44px;margin:0;padding:0 18px;border:0;border-radius:12px;background:#f2f2f2;color:#111;font-weight:600;font-size:14px;cursor:pointer;white-space:nowrap}' +
    '.ogc-fbp:hover{background:#fff}.ogc-fbp:disabled{opacity:.6;cursor:default}.ogc-fbp svg{flex:none;width:14px;height:14px}' +
    '.ogc-fbp--sm{position:relative;min-height:36px;padding:0 12px;border-radius:10px;font-size:13px}' +
    // Its tap is 44 px all the same: the button is drawn smaller inside it.
    '.ogc-fbp--sm::after{content:"";position:absolute;left:0;right:0;top:-4px;bottom:-4px}' +
    '.ogc-fbq{display:inline-flex;align-items:center;justify-content:center;gap:6px;min-height:44px;min-width:44px;margin:0;padding:0 12px;border:0;border-radius:10px;background:transparent;color:#d4d4d4;font-weight:500;font-size:13.5px;cursor:pointer;white-space:nowrap}' +
    '.ogc-fbq:hover{background:rgba(255,255,255,.07);color:#fff}.ogc-fbq svg{flex:none;width:16px;height:16px}' +
    '.ogc-fbq--danger{color:#fca5a5}.ogc-fbq--danger:hover{color:#fecaca;background:rgba(248,113,113,.12)}' +
    '.ogc-fbq--chip{min-height:36px;padding:0 12px;border-radius:999px;background:rgba(255,255,255,.07);color:#e6e6e6;font-size:13px}' +
    '.ogc-fbq--chip:hover{background:rgba(255,255,255,.12)}' +
    // A chip's tap is 44 px: the chip is drawn smaller inside it.
    '.ogc-fbc__tools .ogc-fbq--chip{position:relative}.ogc-fbc__tools .ogc-fbq--chip::after{content:"";position:absolute;left:0;right:0;top:-4px;bottom:-4px}' +
    '.ogc-fbx-ui label{display:block;margin:14px 0 6px;color:#d4d4d4;font-size:13px;font-weight:600}' +
    '.ogc-fbx-ui textarea,.ogc-fbx-ui input[type=text],.ogc-fbx-ui input[type=password]{display:block;width:100%;margin:0;padding:10px 12px;border:1px solid rgba(255,255,255,.14);border-radius:10px;background:#0c0c0c;color:#f2f2f2;font:400 16px/1.4 ' + SANS + ';box-shadow:none;-webkit-appearance:none;appearance:none}' +
    '.ogc-fbx-ui input{min-height:44px}.ogc-fbx-ui textarea{min-height:96px;resize:vertical}' +
    '.ogc-fbx-ui textarea::placeholder,.ogc-fbx-ui input::placeholder{color:#8a8a8a}' +
    '.ogc-fbx-ui textarea:focus,.ogc-fbx-ui input:focus{outline:none;border-color:rgba(255,255,255,.55);box-shadow:0 0 0 3px rgba(255,255,255,.12)}' +
    '.ogc-fbx-ui [aria-invalid=true]{border-color:#f87171}' +
    '.ogc-fb-err{margin:6px 0 0!important;color:#fca5a5;font-size:13px}.ogc-fb-err:empty{display:none}' +
    '.ogc-fbx{flex:none;display:inline-flex;align-items:center;justify-content:center;width:44px;height:44px;margin:0;padding:0;border:0;border-radius:10px;background:transparent;color:#a3a3a3;cursor:pointer}' +
    '.ogc-fbx:hover{background:rgba(255,255,255,.08);color:#fff}.ogc-fbx svg{width:18px;height:18px}' +

    // The composer: a card above the dock on a laptop, a sheet from the foot on a phone.
    '.ogc-fbc{position:fixed;z-index:2147482000;right:16px;bottom:calc(68px + var(--ogc-pill-lift,0px) + env(safe-area-inset-bottom));width:min(392px,calc(100vw - 32px));max-height:calc(100vh - 92px - var(--ogc-pill-lift,0px));overflow:auto;overscroll-behavior:contain;padding:6px 16px 16px;border-radius:18px;background:#161616;box-shadow:inset 0 0 0 1px rgba(255,255,255,.09),0 24px 60px rgba(0,0,0,.42)}' +
    '.ogc-fbc__head{display:flex;align-items:center;gap:8px;margin:0 -8px 0 0}.ogc-fbc__head h2{flex:1}' +
    '.ogc-fbc__ctx{margin:-6px 0 12px!important;color:#a3a3a3;font-size:12.5px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}' +
    '.ogc-fbc__shot{position:relative;display:flex;align-items:center;justify-content:center;height:196px;border-radius:12px;background:#0c0c0c;box-shadow:inset 0 0 0 1px rgba(255,255,255,.08);overflow:hidden}' +
    '.ogc-fbc__shot img{display:block;max-width:100%;max-height:100%;object-fit:contain}' +
    '.ogc-fbc__ph{color:#a3a3a3;font-size:13px}' +
    '.ogc-fbc__tools{display:flex;flex-wrap:wrap;align-items:center;gap:6px;margin:8px 0 0}' +
    '.ogc-fbc__pin{flex:1 1 100%;margin:2px 0 0!important;color:#a3a3a3;font-size:12.5px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}' +
    '.ogc-fbc__foot{display:flex;align-items:center;justify-content:flex-end;gap:8px;margin:16px 0 0}' +
    '.ogc-fbc__status{flex:1;color:#a3a3a3;font-size:13px}' +
    '@media (max-width:599px){.ogc-fbc{left:0;right:0;bottom:0;width:auto;max-height:92vh;max-height:92dvh;border-radius:20px 20px 0 0;padding-bottom:calc(16px + env(safe-area-inset-bottom))}' +
    'html.ogc-fb-composing .ogc-pill{visibility:hidden}}' +

    // Point to it: the page under a clear layer; the thing under the pointer outlined.
    '.ogc-fba{position:fixed;inset:0;z-index:2147482500;cursor:crosshair;background:rgba(0,0,0,.08);touch-action:pan-x pan-y}' +
    '.ogc-fba__box{position:fixed;z-index:2147482501;pointer-events:none;border:2px solid #111;border-radius:6px;background:rgba(17,17,17,.06);box-shadow:0 0 0 2px rgba(255,255,255,.85);display:none}' +
    '.ogc-fba__tip{position:fixed;left:50%;top:calc(12px + env(safe-area-inset-top));transform:translateX(-50%);z-index:2147482502;display:flex;align-items:center;gap:4px;padding:0 4px 0 16px;border-radius:999px;background:#161616;box-shadow:inset 0 0 0 1px rgba(255,255,255,.09),0 8px 24px rgba(0,0,0,.3);white-space:nowrap}' +
    '.ogc-fba__tip span{font-weight:600;font-size:13.5px}' +

    // The board (Nov 4): a light page of its own over the demo. The screens at the left, the feed (or every
    // screen as a tile) in the middle, sort, people and Open or Resolved floating at the top. On a phone the
    // screens are a menu at the top left.
    '.ogc-fbb{--bg:#f4f3ef;--card:#fff;--ink:#1c1d22;--ink2:#43454c;--mute:#6e6f75;--line:rgba(28,29,34,.08);--line2:rgba(28,29,34,.14);--fill:rgba(28,29,34,.045);--fill2:rgba(28,29,34,.08);' +
    '--acc:#14809d;--acct:#0c6780;--accw:rgba(20,128,157,.1);--e1:inset 0 0 0 1px rgba(28,29,34,.07),0 1px 2px rgba(28,29,34,.04);--e2:inset 0 0 0 1px rgba(28,29,34,.06),0 8px 26px rgba(28,29,34,.08);--e3:inset 0 0 0 1px rgba(28,29,34,.08),0 18px 50px rgba(28,29,34,.16);' +
    'position:fixed;inset:0;z-index:2147482000;background:var(--bg);color:var(--ink);font-size:15px}' +
    '.ogc-fbb :focus-visible{outline:2px solid var(--acc);outline-offset:2px}' +
    '.ogc-fbb h2,.ogc-fbb h3{color:var(--ink)}' +
    '.ogc-fbb .ogc-fbp{background:var(--ink);color:#fff}.ogc-fbb .ogc-fbp:hover{background:#000}' +
    '.ogc-fbb .ogc-fbq{color:var(--ink2)}.ogc-fbb .ogc-fbq:hover{background:var(--fill);color:var(--ink)}' +
    '.ogc-fbb .ogc-fbq--danger,.ogc-fbb .ogc-fbq--danger:hover{color:#b42318}.ogc-fbb .ogc-fbq--danger:hover{background:rgba(180,35,24,.08)}' +
    '.ogc-fbb .ogc-fbx{color:var(--mute)}.ogc-fbb .ogc-fbx:hover{background:var(--fill);color:var(--ink)}' +
    '.ogc-fbb label{color:var(--ink2)}.ogc-fbb .ogc-fb-err{color:#b42318}' +
    '.ogc-fbb textarea,.ogc-fbb input[type=text],.ogc-fbb input[type=password]{border-color:var(--line2);background:#fff;color:var(--ink)}' +
    '.ogc-fbb textarea::placeholder,.ogc-fbb input::placeholder{color:#8a8b90}' +
    '.ogc-fbb textarea:focus,.ogc-fbb input:focus{border-color:var(--acc);box-shadow:0 0 0 3px var(--accw)}' +
    '.ogc-fbb .num{font-variant-numeric:tabular-nums}' +
    // A person's initials in a round of their own colour
    '.ogc-fb-av{flex:none;display:inline-flex;align-items:center;justify-content:center;width:32px;height:32px;border-radius:50%;color:#fff;font-size:12px;font-weight:700}' +
    '.ogc-fb-av--sm{width:22px;height:22px;font-size:9.5px}' +
    // The screens
    '.ogc-fbb__side{position:absolute;z-index:3;top:16px;left:16px;bottom:16px;width:288px;display:flex;flex-direction:column;border-radius:20px;background:var(--card);box-shadow:var(--e2);overflow:hidden}' +
    '.ogc-fbb__sh{flex:none;padding:16px 18px 8px}.ogc-fbb__sh b{display:block;font-size:16px;font-weight:650}.ogc-fbb__sh span{display:block;color:var(--mute);font-size:13px}' +
    '.ogc-fbb__side nav{flex:1;min-height:0;overflow:auto;overscroll-behavior:contain;padding:4px 8px 14px}' +
    '.ogc-fbb__cap{margin:14px 10px 4px!important;color:var(--mute);font-size:11px;font-weight:600;letter-spacing:.08em;text-transform:uppercase}' +
    '.ogc-fbsr{display:flex;align-items:center;gap:10px;width:100%;min-height:44px;margin:0 0 2px;padding:6px 10px;border:0;border-radius:12px;background:transparent;color:var(--ink);font:500 14px/1.3 ' + SANS + ';text-align:left;cursor:pointer}' +
    '.ogc-fbsr:hover{background:var(--fill)}.ogc-fbsr[aria-current=true]{background:var(--accw);color:var(--acct);font-weight:600}' +
    '.ogc-fbsr__n{flex:1;min-width:0}.ogc-fbsr__n b{display:block;font-weight:inherit;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}' +
    '.ogc-fbsr__n small{display:block;color:var(--mute);font-size:11.5px;font-weight:500}' +
    '.ogc-fbsr__c{flex:none;color:var(--mute);font-size:13px;font-weight:500;font-variant-numeric:tabular-nums}' +
    '.ogc-fbsr--quiet .ogc-fbsr__n b{color:var(--mute)}' +
    '.ogc-fbsr__ic{flex:none;display:flex;align-items:center;justify-content:center;width:44px;height:30px;border-radius:7px;background:var(--fill);color:var(--ink2)}.ogc-fbsr__ic svg{width:16px;height:16px}' +
    '.ogc-fbsr[aria-current=true] .ogc-fbsr__ic{background:rgba(20,128,157,.14);color:var(--acct)}' +
    // A screen's own picture: the top of the page; the guide's standing up in the middle.
    '.ogc-fbsh{flex:none;display:block;background:#e9e7e1 no-repeat center top/cover;box-shadow:inset 0 0 0 1px var(--line)}' +
    '.ogc-fbsh--phone{background-color:#ece9e1;background-size:auto 100%}.ogc-fbsh--none{background:var(--fill)}' +
    '.ogc-fbsr .ogc-fbsh{width:44px;height:30px;border-radius:6px}' +
    // Floating at the top
    '.ogc-fbb__top{position:absolute;z-index:4;top:16px;left:320px;right:16px;display:flex;align-items:center;gap:8px;pointer-events:none}' +
    '.ogc-fbb__top>*{pointer-events:auto}.ogc-fbb__grow{flex:1;pointer-events:none!important}' +
    '.ogc-fbb__scroll{display:flex;align-items:center;gap:8px;min-width:0}' +
    '.ogc-fbb__pill{display:inline-flex;align-items:center;gap:2px;height:44px;padding:0 4px;border-radius:999px;background:var(--card);box-shadow:var(--e2)}' +
    '.ogc-fbb__pill>button{display:inline-flex;align-items:center;gap:6px;height:36px;margin:0;padding:0 14px;border:0;border-radius:999px;background:transparent;color:var(--ink);font:550 14px/1 ' + SANS + ';white-space:nowrap;cursor:pointer}' +
    '.ogc-fbb__pill>button:hover,.ogc-fbb__pill>button[aria-expanded=true]{background:var(--fill)}' +
    // Its tap is 44 px all the same: the button is drawn smaller inside the pill.
    '.ogc-fbb__pill>button{position:relative}.ogc-fbb__pill>button::after{content:"";position:absolute;left:0;right:0;top:-4px;bottom:-4px}' +
    '.ogc-fbb__pill>button svg{width:12px;height:12px;color:var(--mute)}.ogc-fbb__pill .n{color:var(--mute);font-weight:500}' +
    '.ogc-fbb__scr{display:none!important}.ogc-fbb__scr b{max-width:46vw;overflow:hidden;text-overflow:ellipsis;font-weight:inherit}' +
    '.ogc-fbb__round{display:inline-flex;align-items:center;justify-content:center;width:44px;height:44px;margin:0;padding:0;border:0;border-radius:50%;background:var(--card);color:var(--ink2);box-shadow:var(--e2);cursor:pointer}' +
    '.ogc-fbb__round:hover{color:var(--ink)}.ogc-fbb__round svg{width:18px;height:18px}' +
    '.ogc-fbb__new{min-height:44px;border-radius:999px;box-shadow:var(--e2)}' +
    '.ogc-fbb__badge{display:inline-flex;align-items:center;height:28px;padding:0 10px;border-radius:999px;background:var(--accw);color:var(--acct);font-size:12px;font-weight:600}' +
    // Menus under their pill
    '.ogc-fbb__pop{position:absolute;z-index:6;min-width:240px;max-width:calc(100vw - 24px);max-height:60vh;overflow:auto;padding:6px;border-radius:16px;background:var(--card);box-shadow:var(--e3)}' +
    '.ogc-fbb__pop>button{display:flex;align-items:center;gap:10px;width:100%;min-height:44px;margin:0;padding:0 12px;border:0;border-radius:10px;background:transparent;color:var(--ink);font:400 14px/1.2 ' + SANS + ';text-align:left;cursor:pointer}' +
    '.ogc-fbb__pop>button:hover,.ogc-fbb__pop>button:focus-visible{background:var(--fill);outline:none}' +
    '.ogc-fbb__pop>button[aria-checked=true]{color:var(--acct);font-weight:600}.ogc-fbb__pop>button .n{margin-left:auto;color:var(--mute);font-weight:400}' +
    '.ogc-fbb__pop .ogc-fbb__cap{margin:10px 12px 4px!important}' +
    '.ogc-fbb__key{width:300px;padding:12px 14px 14px}.ogc-fbb__key label{margin-top:0}.ogc-fbb__key div{display:flex;gap:8px;margin-top:10px;justify-content:flex-end}' +
    // The feed
    '.ogc-fbb__main{position:absolute;inset:0;overflow:auto;overscroll-behavior:contain;padding:96px 24px 96px 336px}' +
    '.ogc-fbb__col{max-width:680px;margin:0 auto}.ogc-fbb__wide{max-width:1120px;margin:0 auto}' +
    '.ogc-fbb__head{display:flex;align-items:center;gap:14px;margin:0 0 26px}.ogc-fbb__head>div{flex:1;min-width:0}' +
    '.ogc-fbb__head h2{font-size:26px;font-weight:650;letter-spacing:-.015em;line-height:1.2}' +
    '.ogc-fbb__head p{margin:3px 0 0!important;color:var(--mute);font-size:14px}' +
    '.ogc-fbb__head .ogc-fbsh{width:132px;height:84px;border-radius:10px;box-shadow:var(--e1)}' +
    '.ogc-fbb__steps{flex:none;display:flex;gap:4px}' +
    '.ogc-fbb__steps button{display:inline-flex;align-items:center;justify-content:center;width:44px;height:44px;margin:0;padding:0;border:0;border-radius:50%;background:var(--card);color:var(--mute);box-shadow:var(--e1);cursor:pointer}' +
    '.ogc-fbb__steps button:hover{color:var(--ink)}.ogc-fbb__steps svg{width:16px;height:16px}' +
    '.ogc-fbb__day{margin:28px 0 10px!important;color:var(--mute);font-size:11px;font-weight:600;letter-spacing:.08em;text-transform:uppercase}.ogc-fbb__day:first-of-type{margin-top:0!important}' +
    '.ogc-fbb__line{margin:56px 16px!important;color:var(--mute);font-size:14.5px;text-align:center}' +
    // An idea
    '.ogc-fbk{margin:0 0 12px;padding:16px 18px 8px;border-radius:18px;background:var(--card);box-shadow:var(--e1)}' +
    '.ogc-fbk:focus{outline:none;box-shadow:inset 0 0 0 2px var(--acc),var(--e1)}' +
    '.ogc-fbk--flash{box-shadow:inset 0 0 0 2px var(--acc),var(--e2)}.ogc-fbk--done{opacity:.66}' +
    '.ogc-fbk__who{display:flex;align-items:center;gap:8px;min-width:0;color:var(--mute);font-size:13.5px}' +
    '.ogc-fbk__who b{color:var(--ink);font-weight:600;white-space:nowrap}' +
    '.ogc-fbk__who em{min-width:0;font-style:normal;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}' +
    '.ogc-fbk__who time{flex:none;margin-left:auto}' +
    '.ogc-fbk .ogc-fb-av{width:28px;height:28px;font-size:11px}' +
    '.ogc-fbk__res{flex:none;padding:1px 8px;border-radius:999px;background:rgba(47,138,87,.1);color:#2f7a4f;font-size:11.5px;font-weight:600}' +
    '.ogc-fbk__t{margin:10px 0 0!important;font-size:15px;line-height:1.55;white-space:pre-wrap;overflow-wrap:anywhere}' +
    '.ogc-fbk__pic{display:block;width:100%;margin:14px 0 4px;padding:0;border:0;border-radius:12px;background:transparent;cursor:zoom-in}' +
    '.ogc-fbk__crop{position:relative;display:block;height:190px;border-radius:12px;overflow:hidden;background:#e9e7e1 no-repeat;box-shadow:inset 0 0 0 1px var(--line)}' +
    '.ogc-fbk__pic:hover .ogc-fbk__crop{box-shadow:inset 0 0 0 1px var(--line2),0 4px 14px rgba(28,29,34,.08)}' +
    '.ogc-fbk__dot{position:absolute;width:14px;height:14px;margin:-7px 0 0 -7px;border-radius:50%;background:var(--acc);box-shadow:0 0 0 3px #fff,0 2px 8px rgba(28,29,34,.3)}' +
    // Upvote, Reply, the replies: the same on every idea
    '.ogc-fbk__acts{display:flex;flex-wrap:wrap;align-items:center;gap:2px;margin:6px -12px 0}' +
    '.ogc-fbk__a,.ogc-fbb .ogc-fb-up{display:inline-flex;align-items:center;gap:7px;min-width:44px;height:44px;margin:0;padding:0 12px;border:0;border-radius:999px;background:transparent;color:var(--ink2);font:600 13.5px/1 ' + SANS + ';cursor:pointer}' +
    '.ogc-fbk__a:hover,.ogc-fbb .ogc-fb-up:hover{background:var(--fill);color:var(--ink)}' +
    '.ogc-fbk__a svg,.ogc-fbb .ogc-fb-up svg{flex:none;width:14px;height:14px}' +
    '.ogc-fbb .ogc-fb-up .c{display:inline-flex;align-items:center;justify-content:center;min-width:20px;height:20px;padding:0 6px;border-radius:999px;background:var(--fill2);font-size:12px}' +
    '.ogc-fbb .ogc-fb-up[aria-pressed=true]{background:var(--accw);color:var(--acct)}.ogc-fbb .ogc-fb-up[aria-pressed=true] .c{background:var(--acc);color:#fff}' +
    '.ogc-fbk__a--quiet{color:var(--mute);font-weight:500}.ogc-fbk__a--end{margin-left:auto}' +
    '.ogc-fbk__form{margin:6px 0 10px}.ogc-fbk__form textarea{min-height:76px;font-size:15px}' +
    '.ogc-fbk__form .ogc-fbc__foot{flex-wrap:wrap;margin-top:8px}.ogc-fbk__form .ogc-fbk__name{flex:1 1 180px;min-width:0}' +
    '.ogc-fbk__form .ogc-fbk__name input{min-height:40px;padding:8px 12px;font-size:15px}' +
    '.ogc-fbk__thread{margin:4px 0 8px;border-top:1px solid var(--line)}' +
    '.ogc-fbk__r{display:flex;gap:10px;padding:10px 0 2px}.ogc-fbk__r .ogc-fb-av{width:22px;height:22px;font-size:9.5px}' +
    '.ogc-fbk__r>div{flex:1;min-width:0}.ogc-fbk__r header{display:flex;align-items:center;gap:8px;font-size:13px;color:var(--mute)}.ogc-fbk__r header b{color:var(--ink);font-weight:600}' +
    '.ogc-fbk__r header .ogc-fbq{min-height:32px;margin:-6px -8px -6px auto;padding:0 8px;font-size:12.5px}' +
    // Its tap is 44 px all the same: the button is drawn smaller inside it.
    '.ogc-fbk__r header .ogc-fbq{position:relative}.ogc-fbk__r header .ogc-fbq::after{content:"";position:absolute;left:0;right:0;top:-6px;bottom:-6px}' +
    '.ogc-fbk__r p{margin:2px 0 0!important;color:var(--ink2);font-size:14px;line-height:1.5;white-space:pre-wrap;overflow-wrap:anywhere}' +
    '.ogc-fbk__more{display:flex;flex-wrap:wrap;align-items:center;gap:4px 8px;margin:2px 0 8px;padding-top:8px;border-top:1px solid var(--line);color:var(--mute);font-size:13px}' +
    '.ogc-fbk__more>span{flex:1 1 220px;min-width:0;padding:6px 0;overflow-wrap:anywhere}' +
    // Every screen
    '.ogc-fbb__area{margin:28px 0 12px!important;color:var(--mute);font-size:11px!important;font-weight:600!important;letter-spacing:.08em!important;text-transform:uppercase}.ogc-fbb__area:first-of-type{margin-top:0!important}' +
    '.ogc-fbb__tiles{display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:16px}' +
    '.ogc-fbtl{display:block;width:100%;margin:0;padding:0;border:0;border-radius:18px;background:var(--card);box-shadow:var(--e1);overflow:hidden;color:var(--ink);font:400 14px/1.4 ' + SANS + ';text-align:left;cursor:pointer}' +
    '.ogc-fbtl:hover{box-shadow:var(--e2)}.ogc-fbtl .ogc-fbsh{height:150px;box-shadow:none;border-bottom:1px solid var(--line)}' +
    '.ogc-fbtl__b{display:block;padding:12px 16px 14px}.ogc-fbtl__b b{display:block;font-size:15.5px;font-weight:650}' +
    '.ogc-fbtl__b>span{display:block;margin-top:2px;color:var(--ink2);font-size:13px}' +
    '.ogc-fbtl__b>small{display:flex;align-items:center;gap:8px;margin-top:6px;color:var(--mute);font-size:13px}' +
    '.ogc-fbtl__b .ogc-fb-av{width:22px;height:22px;font-size:9.5px;box-shadow:0 0 0 2px #fff}.ogc-fbtl__b .ogc-fb-av+.ogc-fb-av{margin-left:-6px}' +
    '.ogc-fbtl--quiet{background:rgba(255,255,255,.55);box-shadow:inset 0 0 0 1px var(--line)}.ogc-fbtl--quiet .ogc-fbsh{opacity:.7}' +
    // A phone: the screens are a menu at the top left
    '@media (max-width:760px){' +
    '.ogc-fbb__side{display:none}.ogc-fbb__scr{display:inline-flex!important}' +
    '.ogc-fbb__top{left:12px;right:12px;top:calc(12px + env(safe-area-inset-top))}' +
    '.ogc-fbb__top{flex-wrap:wrap;row-gap:8px}.ogc-fbb__scroll{display:contents}' +
    '.ogc-fbb__scr{order:1;flex:1;min-width:0}.ogc-fbb__scr>button{min-width:0;max-width:100%}.ogc-fbb__scr b{min-width:0;max-width:none}' +
    '.ogc-fbb__badge,.ogc-fbb__new,.ogc-fbb__round{order:2}.ogc-fbb__scroll>.ogc-fbb__pill:not(.ogc-fbb__scr){order:3}' +
    '.ogc-fbb__grow{display:none}.ogc-fbb__new .ogc-fbb__l{display:none}.ogc-fbb__new{width:44px;padding:0;justify-content:center}' +
    '.ogc-fbb__main{padding:calc(128px + env(safe-area-inset-top)) 12px calc(48px + env(safe-area-inset-bottom))}' +
    '.ogc-fbb__head h2{font-size:22px}.ogc-fbb__head .ogc-fbsh,.ogc-fbb__hint{display:none}' +
    '.ogc-fbk{padding:14px 14px 6px}.ogc-fbk__crop{height:150px}' +
    '.ogc-fbb__tiles{grid-template-columns:1fr 1fr;gap:10px}.ogc-fbtl .ogc-fbsh{height:104px}.ogc-fbtl__b{padding:10px 12px 12px}.ogc-fbtl__b>span{display:none}}' +
    '@media (min-width:761px) and (max-width:1000px){.ogc-fbb__side{width:240px}.ogc-fbb__top{left:272px}.ogc-fbb__main{padding-left:288px}}' +
    '.ogc-fb-sr{position:absolute!important;width:1px!important;height:1px!important;margin:-1px!important;padding:0!important;overflow:hidden!important;clip:rect(0 0 0 0)!important;white-space:nowrap!important}' +

    // A toast: what just happened, with what to do next.
    '.ogc-fbt{position:fixed;left:50%;bottom:calc(72px + var(--ogc-pill-lift,0px) + env(safe-area-inset-bottom));z-index:2147482100;transform:translateX(-50%);display:flex;align-items:center;gap:6px;max-width:calc(100vw - 32px);padding:0 6px 0 16px;border-radius:14px;background:#1f1f1f;box-shadow:inset 0 0 0 1px rgba(255,255,255,.1),0 10px 30px rgba(0,0,0,.32)}' +
    '.ogc-fbt span{font-weight:600;padding:12px 0}' +
    '.ogc-fbb~.ogc-fbt,.ogc-fbt--board{bottom:calc(24px + env(safe-area-inset-bottom))}' +
    // The picture, enlarged.
    '.ogc-fbl{position:fixed;inset:0;z-index:2147482600;display:flex;align-items:center;justify-content:center;padding:56px 16px 16px;background:rgba(10,10,10,.94);cursor:zoom-out}' +
    '.ogc-fbl img{max-width:100%;max-height:100%;border-radius:8px;box-shadow:0 20px 60px rgba(0,0,0,.5)}' +
    '.ogc-fbl .ogc-fbx{position:absolute;top:8px;right:8px;color:#e6e6e6}' +
    '@media (prefers-reduced-motion:no-preference){' +
    '.ogc-fbc{animation:ogc-fb-up .16s ease-out}.ogc-fbb{animation:ogc-fb-fade .14s ease-out}' +
    '.ogc-fbt{animation:ogc-fb-fade .16s ease-out}.ogc-fbc__shot--wait .ogc-fbc__ph{animation:ogc-fb-wait 1.2s ease-in-out infinite alternate}' +
    '@keyframes ogc-fb-up{from{opacity:0;transform:translateY(8px)}}' +
    '@keyframes ogc-fb-fade{from{opacity:0}}@keyframes ogc-fb-wait{to{opacity:.45}}}' +
    '@media print{.ogc-fbc,.ogc-fbb,.ogc-fbt,.ogc-fbl,.ogc-fba,.ogc-fba__box,.ogc-fba__tip{display:none!important}}';

  const I = {
    talk: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 5.5h14a1.5 1.5 0 0 1 1.5 1.5v8.5A1.5 1.5 0 0 1 19 17h-7.5L7 20.5V17H5a1.5 1.5 0 0 1-1.5-1.5V7A1.5 1.5 0 0 1 5 5.5Z" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/></svg>',
    reply: '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 3.5h10a1 1 0 0 1 1 1v6a1 1 0 0 1-1 1H8l-3 2.5v-2.5H3a1 1 0 0 1-1-1v-6a1 1 0 0 1 1-1Z" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/></svg>',
    plus: '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M8 3v10M3 8h10" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>',
    x: '<svg viewBox="0 0 20 20" aria-hidden="true"><path d="m5 5 10 10M15 5 5 15" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>',
    back: '<svg viewBox="0 0 20 20" aria-hidden="true"><path d="M12.5 4.5 7 10l5.5 5.5" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    up: '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M8 3.5 13 10H3z" fill="currentColor"/></svg>',
    text: '<svg viewBox="0 0 20 20" aria-hidden="true"><path d="M4 5.5h12M4 10h12M4 14.5h7" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg>',
    more: '<svg viewBox="0 0 20 20" aria-hidden="true"><circle cx="4.5" cy="10" r="1.6" fill="currentColor"/><circle cx="10" cy="10" r="1.6" fill="currentColor"/><circle cx="15.5" cy="10" r="1.6" fill="currentColor"/></svg>',
    next: '<svg viewBox="0 0 20 20" aria-hidden="true"><path d="M7.5 4.5 13 10l-5.5 5.5" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    list: '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 4.5h10M3 8h10M3 11.5h7" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg>',
    grid: '<svg viewBox="0 0 16 16" aria-hidden="true"><g fill="none" stroke="currentColor" stroke-width="1.5"><rect x="2.5" y="2.5" width="4.5" height="4.5" rx="1.2"/><rect x="9" y="2.5" width="4.5" height="4.5" rx="1.2"/><rect x="2.5" y="9" width="4.5" height="4.5" rx="1.2"/><rect x="9" y="9" width="4.5" height="4.5" rx="1.2"/></g></svg>'
  };

  function ui(tag, cls, html) {
    const el = document.createElement(tag);
    el.className = 'ogc-fbx-ui ' + cls;
    el.setAttribute('data-ogc-tool', '');
    if (html != null) el.innerHTML = html;
    return el;
  }
  const MON = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'June', 'July', 'Aug', 'Sept', 'Oct', 'Nov', 'Dec'];
  function ago(iso) {
    const t = Date.parse(iso || '');
    if (!t) return '';
    const s = (Date.now() - t) / 1000;
    if (s < 60) return 'Just now';
    if (s < 3600) return Math.floor(s / 60) + ' min ago';
    if (s < 86400) return Math.floor(s / 3600) + ' h ago';
    if (s < 172800) return 'Yesterday';
    const d = new Date(t);
    return MON[d.getMonth()] + ' ' + d.getDate() + (d.getFullYear() !== new Date().getFullYear() ? ', ' + d.getFullYear() : '');
  }
  const TONES = ['#2750C7', '#00707E', '#A86F00', '#8E357E', '#1D7D3E', '#555555', '#7A5230', '#8B2A2A'];
  function avatar(name, small) {
    const w = String(name || '?').trim().split(/\s+/).filter(Boolean);
    const ini = ((w[0] || '?').charAt(0) + (w.length > 1 ? w[w.length - 1].charAt(0) : '')).toUpperCase();
    let h = 0;
    for (const c of String(name)) h = (h * 31 + c.charCodeAt(0)) >>> 0;
    return '<span class="ogc-fb-av' + (small ? ' ogc-fb-av--sm' : '') + '" style="background:' + TONES[h % TONES.length] + '" aria-hidden="true">' + esc(ini) + '</span>';
  }
  // The day an idea was left on, short: "Mar 2" from "Registration · Mar 2, 2027".
  const dayShort = m => { const x = /· ([A-Z][a-z]+ \d{1,2})/.exec(m || ''); return x ? x[1] : ''; };
  const errWords = code => ({
    name: 'Add your name', text: 'Write your idea', slow: 'Too many at once · Try again in a few minutes', offline: 'Offline · Try again when connected',
    network: 'Couldn’t reach the board · Try again', forbidden: 'Not allowed', not_found: 'That idea is gone', busy: 'Busy · Try again'
  })[code] || 'Something went wrong · Try again';

  /* ------------------------------------------------------------------ the picture of the screen */

  let libP = null;
  function loadLib() {
    if (window.htmlToImage && window.htmlToImage.toSvg) return Promise.resolve(window.htmlToImage);
    if (libP) return libP;
    libP = new Promise((res, rej) => {
      const s = document.createElement('script');
      s.src = LIB;
      s.async = true;
      s.crossOrigin = 'anonymous';
      s.integrity = LIB_SRI;
      s.referrerPolicy = 'no-referrer';
      s.setAttribute('data-ogc-tool', '');
      s.onload = () => (window.htmlToImage && window.htmlToImage.toSvg ? res(window.htmlToImage) : rej(new Error('lib')));
      s.onerror = () => { libP = null; s.remove(); rej(new Error('lib')); };
      document.head.appendChild(s);
    });
    return libP;
  }
  const within = (p, ms) => Promise.race([p, new Promise((res, rej) => setTimeout(() => rej(new Error('timeout')), ms))]);
  const frame = () => new Promise(r => requestAnimationFrame(() => r()));
  const XHTML = 'http://www.w3.org/1999/xhtml';

  // The screen as the visitor sees it now, without our own things: {url (JPEG data URL), w, h, sx, sy, k}.
  async function capture() {
    const H = await within(loadLib(), 12000);
    const de = document.documentElement;
    const w = de.clientWidth || innerWidth, h = innerHeight, sx = scrollX, sy = scrollY;
    // What moves when drawn from the top: fixed things (put back where they are) and scrolled panels.
    const marks = [];
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_ELEMENT, { acceptNode: n => n.hasAttribute('data-ogc-tool') ? NodeFilter.FILTER_REJECT : NodeFilter.FILTER_ACCEPT });
    for (let n = walker.nextNode(); n; n = walker.nextNode()) {
      if ((n.scrollTop || n.scrollLeft) && n !== document.scrollingElement) { n.setAttribute('data-ogc-cap-sc', n.scrollLeft + ',' + n.scrollTop); marks.push(n); }
      if (getComputedStyle(n).position === 'fixed') {
        const r = n.getBoundingClientRect();
        if (r.width && r.height) { n.setAttribute('data-ogc-cap-fx', [r.left + sx, r.top + sy, r.width, r.height].map(v => Math.round(v * 100) / 100).join(',')); marks.push(n); }
      }
    }
    // Open modal dialogs (a sheet) are in the top layer: drawn last, over the page, each over its own
    // dimming, as on screen (in the picture they'd sit in the page's order, under its header).
    const mods = (dockInfo().modals ? dockInfo().modals() : [...document.querySelectorAll('dialog[open]')]).filter(d => !d.hasAttribute('data-ogc-tool'));
    const dims = mods.map((d, i) => {
      d.setAttribute('data-ogc-cap-top', String(i));
      marks.push(d);
      let c = '';
      try { c = getComputedStyle(d, '::backdrop').backgroundColor || ''; } catch (e) { c = ''; }
      return /^(transparent|rgba\(0, 0, 0, 0\))$/.test(c) ? '' : c;
    });
    let svg;
    try {
      svg = await within(H.toSvg(de, {
        width: w, height: h, cacheBust: false, skipAutoScale: true,
        imagePlaceholder: 'data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==',
        filter: n => !(n && n.nodeType === 1 && n.hasAttribute && n.hasAttribute('data-ogc-tool')),
        style: { transform: 'translate(' + (-sx) + 'px,' + (-sy) + 'px)', transformOrigin: '0 0' }
      }), 20000);
    } finally {
      marks.forEach(n => { n.removeAttribute('data-ogc-cap-sc'); n.removeAttribute('data-ogc-cap-fx'); n.removeAttribute('data-ogc-cap-top'); });
    }
    const PRE = 'data:image/svg+xml;charset=utf-8,';
    if (svg.indexOf(PRE) === 0) {
      try {
        const doc = new DOMParser().parseFromString(decodeURIComponent(svg.slice(PRE.length)), 'image/svg+xml');
        if (!doc.querySelector('parsererror')) {
          const add = (el, more) => el.setAttribute('style', (el.getAttribute('style') || '') + ';' + more);
          doc.querySelectorAll('[data-ogc-cap-sc]').forEach(el => {
            const [l, t] = el.getAttribute('data-ogc-cap-sc').split(',').map(Number);
            [...el.children].forEach(c => add(c, 'translate:' + (-l) + 'px ' + (-t) + 'px'));
          });
          doc.querySelectorAll('[data-ogc-cap-fx]').forEach(el => {
            const [l, t, ww, hh] = el.getAttribute('data-ogc-cap-fx').split(',').map(Number);
            add(el, 'position:fixed;inset:auto;left:' + l + 'px;top:' + t + 'px;width:' + ww + 'px;height:' + hh + 'px;margin:0;transform:none;translate:none;box-sizing:border-box');
          });
          const body = doc.getElementsByTagName('body')[0];
          // No scrollbars drawn in the picture (a sheet's own, which a screen shows only while scrolling).
          if (body) {
            const st = doc.createElementNS(body.namespaceURI || XHTML, 'style');
            st.textContent = '*{scrollbar-width:none!important}*::-webkit-scrollbar{display:none!important}';
            body.insertBefore(st, body.firstChild);
          }
          if (body) {
            [...doc.querySelectorAll('[data-ogc-cap-top]')].sort((a, b) => a.getAttribute('data-ogc-cap-top') - b.getAttribute('data-ogc-cap-top')).forEach(el => {
              const i = +el.getAttribute('data-ogc-cap-top'), z = 2147482000 + i * 2;
              if (dims[i]) {
                const dim = doc.createElementNS(el.namespaceURI || XHTML, 'div');
                dim.setAttribute('style', 'position:fixed;left:' + sx + 'px;top:' + sy + 'px;width:' + w + 'px;height:' + h + 'px;margin:0;padding:0;border:0;background:' + dims[i] + ';z-index:' + z);
                body.appendChild(dim);
              }
              add(el, 'z-index:' + (z + 1));
              body.appendChild(el);
            });
          }
          svg = PRE + encodeURIComponent(new XMLSerializer().serializeToString(doc));
        }
      } catch (e) { /* drawn as the library made it */ }
    }
    const img = new Image();
    img.decoding = 'sync';
    await within(new Promise((res, rej) => { img.onload = res; img.onerror = () => rej(new Error('draw')); img.src = svg; }), 15000);
    // At most 1600 px on its long side.
    const k = Math.min(window.devicePixelRatio || 1, 1600 / Math.max(w, h));
    const c = document.createElement('canvas');
    c.width = Math.round(w * k);
    c.height = Math.round(h * k);
    const g = c.getContext('2d');
    const paint = () => { g.fillStyle = '#fff'; g.fillRect(0, 0, c.width, c.height); g.drawImage(img, 0, 0, c.width, c.height); };
    paint();
    // Safari can paint a picture's own pictures a moment late: once more after two frames.
    await frame(); await frame();
    paint();
    return { url: c.toDataURL('image/jpeg', 0.85), w, h, sx, sy, k };
  }

  // One at a time: a capture marks the page's fixed things while it runs.
  let capQ = Promise.resolve();
  function captureOne() {
    const p = capQ.then(capture, capture);
    capQ = p.catch(() => {});
    return p;
  }

  // The picture with the pin (and an outline round the thing pointed at) drawn on it.
  function withPin(shot, pin) {
    if (!shot || !pin || pin.cx == null) return Promise.resolve(shot ? shot.url : '');
    return new Promise(res => {
      const img = new Image();
      img.onload = () => {
        const c = document.createElement('canvas');
        c.width = img.naturalWidth; c.height = img.naturalHeight;
        const g = c.getContext('2d'), k = c.width / shot.w;
        g.drawImage(img, 0, 0);
        if (pin.box) {
          const [x, y, bw, bh] = pin.box.map(v => v * k);
          g.lineWidth = Math.max(2, 2 * k);
          g.strokeStyle = '#111';
          g.fillStyle = 'rgba(17,17,17,.08)';
          const r = 6 * k;
          g.beginPath();
          if (g.roundRect) g.roundRect(x, y, bw, bh, r); else g.rect(x, y, bw, bh);
          g.fill(); g.stroke();
        }
        const x = pin.cx * k, y = pin.cy * k;
        g.beginPath(); g.arc(x, y, 18 * k, 0, Math.PI * 2); g.fillStyle = 'rgba(0,0,0,.22)'; g.fill();
        g.beginPath(); g.arc(x, y, 10 * k, 0, Math.PI * 2); g.fillStyle = '#111'; g.fill();
        g.lineWidth = 3 * k; g.strokeStyle = '#fff'; g.stroke();
        res(c.toDataURL('image/jpeg', 0.85));
      };
      img.onerror = () => res(shot.url);
      img.src = shot.url;
    });
  }

  // The words of what was tapped: its own label, or the nearest bit of text around it, as written (not
  // as styled: "Register", not "REGISTER").
  function labelOf(el) {
    for (let e = el, i = 0; e && e !== document.body && i < 6; e = e.parentElement, i++) {
      const t = (e.getAttribute && (e.getAttribute('aria-label') || e.getAttribute('title') || e.getAttribute('alt'))) || e.textContent || '';
      const s = t.replace(/\s+/g, ' ').trim();
      if (s) return s.length > 70 ? s.slice(0, 67) + '…' : s;
    }
    return '';
  }

  /* ------------------------------------------------------------------ the dock's part */

  let dock = null, nBtn = null, goBtn = null, counts = SS.get('ogc-fb-counts', null);
  let here = screenKey();

  function drawCount() {
    if (!nBtn) return;
    const c = (counts && counts.c) || {};
    const n = c[here] || 0, all = Object.keys(c).reduce((a, k) => a + c[k], 0);
    nBtn.hidden = !n && !all;
    nBtn.innerHTML = I.talk + (n ? '<span>' + n + '</span>' : '');
    const say = n ? 'Feedback on this screen · ' + n : 'All feedback';
    nBtn.setAttribute('aria-label', say);
    nBtn.title = say;
    nBtn.dataset.ogcN = String(n);
  }
  let countsP = null;
  function refreshCounts(fresh) {
    if (!fresh && counts && Date.now() - counts.t < 15000) { drawCount(); return Promise.resolve(); }
    if (countsP) return countsP;
    countsP = API.counts().then(c => { counts = { t: Date.now(), c }; SS.set('ogc-fb-counts', counts); drawCount(); }, () => { drawCount(); })
      .then(() => { countsP = null; });
    return countsP;
  }

  function mount(d) {
    dock = d;
    const st = document.createElement('style');
    st.textContent = d.scope ? d.scope(css) : css;
    document.head.appendChild(st);
    nBtn = document.createElement('button');
    nBtn.type = 'button';
    nBtn.className = 'ogc-fb-n';
    nBtn.hidden = true;
    nBtn.setAttribute('aria-haspopup', 'dialog');
    nBtn.setAttribute('aria-expanded', 'false');
    goBtn = document.createElement('button');
    goBtn.type = 'button';
    goBtn.className = 'ogc-fb-go';
    goBtn.setAttribute('aria-haspopup', 'dialog');
    goBtn.setAttribute('aria-expanded', 'false');
    goBtn.title = 'Leave feedback on this screen';
    goBtn.innerHTML = '<span class="ogc-fb-go__in">' + I.plus + '<span class="ogc-fb-go__l">Leave feedback</span><span class="ogc-fb-go__s">Feedback</span></span>';
    d.slot.append(nBtn, goBtn);
    d.slot.hidden = false;
    drawCount();
    refreshCounts(false);
    // The count opens this screen's ideas; the plain icon (none here, some elsewhere) opens the board on
    // its screens.
    nBtn.addEventListener('click', () => { if (board.open) closeBoard(); else openBoard(+nBtn.dataset.ogcN ? here : '', nBtn); });
    goBtn.addEventListener('click', () => { if (comp.open) closeComposer(); else openComposer(); });
    // The app changes its address as people move about in it: the count follows the screen.
    const follow = () => { const k = screenKey(); if (k !== here) { here = k; drawCount(); } };
    addEventListener('popstate', follow);
    setInterval(follow, 700);
    document.addEventListener('visibilitychange', () => { if (!document.hidden) refreshCounts(false); });
    // Something of ours is open: an Escape closes it, never a sheet under it (ogc-dev-nav's root).
    if (d.onBusy) d.onBusy(() => comp.open || board.open || !!lightbox);
    if (d.lift) setTimeout(d.lift, 50);
  }

  /* ------------------------------------------------------------------ the composer */

  const comp = { open: false, el: null, shot: null, pin: null, removed: false, busy: false, failed: false, ctx: null, img: '', sending: false, token: 0 };

  function openComposer() {
    closeBoard(false);
    comp.ctx = context();
    comp.pin = null;
    comp.removed = false;
    comp.failed = false;
    comp.shot = null;
    comp.img = '';
    if (!comp.el) {
      comp.el = ui('section', 'ogc-fbc');
      comp.el.setAttribute('role', 'dialog');
      comp.el.setAttribute('aria-labelledby', 'ogc-fbc-h');
      comp.el.hidden = true;
      comp.el.addEventListener('click', onComposerClick);
      comp.el.addEventListener('keydown', e => { if (e.key === 'Escape') { e.preventDefault(); closeComposer(true); } else if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) { e.preventDefault(); send(); } });
      comp.el.addEventListener('input', e => { if (e.target.getAttribute('aria-invalid') === 'true') { e.target.removeAttribute('aria-invalid'); const er = comp.el.querySelector('#' + e.target.id + '-e'); if (er) er.textContent = ''; } });
    }
    layer().appendChild(comp.el);
    comp.el.innerHTML = composerHtml();
    comp.el.hidden = false;
    comp.open = true;
    goBtn.setAttribute('aria-expanded', 'true');
    document.documentElement.classList.add('ogc-fb-composing');
    take();
    // On a laptop, straight into the words; on a phone no field takes focus by itself (the keyboard).
    if (!touchy() && !narrow()) comp.el.querySelector('textarea').focus();
    else comp.el.querySelector('h2').focus();
  }
  function closeComposer(back) {
    if (!comp.open) return;
    comp.open = false;
    comp.token++;
    comp.el.hidden = true;
    goBtn.setAttribute('aria-expanded', 'false');
    document.documentElement.classList.remove('ogc-fb-composing');
    if (back !== false) goBtn.focus();
  }
  function composerHtml() {
    const c = comp.ctx || {};
    const ctx = [c.title, dayShort(c.moment), c.as].filter(Boolean).join(' · ');
    return '<header class="ogc-fbc__head"><h2 id="ogc-fbc-h" tabindex="-1">Leave feedback</h2><button type="button" class="ogc-fbx" data-ogc-a="close" aria-label="Close">' + I.x + '</button></header>' +
      (ctx ? '<p class="ogc-fbc__ctx" title="Sent with it">' + esc(ctx) + '</p>' : '') +
      '<div class="ogc-fbc__pic"></div>' +
      '<label for="ogc-fbc-t">Your idea</label>' +
      '<textarea id="ogc-fbc-t" rows="4" maxlength="4000" placeholder="What would make this better?" aria-describedby="ogc-fbc-t-e"></textarea>' +
      '<p class="ogc-fb-err" id="ogc-fbc-t-e"></p>' +
      '<label for="ogc-fbc-n">Your name</label>' +
      '<input type="text" id="ogc-fbc-n" maxlength="60" autocomplete="name" value="' + esc(API.name()) + '" aria-describedby="ogc-fbc-n-e">' +
      '<p class="ogc-fb-err" id="ogc-fbc-n-e"></p>' +
      '<div class="ogc-fbc__foot"><span class="ogc-fbc__status" role="status" aria-live="polite"></span><button type="button" class="ogc-fbq" data-ogc-a="close">Cancel</button><button type="button" class="ogc-fbp" data-ogc-a="send">Send</button></div>';
  }
  // The picture's part of the composer, as things stand.
  function drawPic() {
    if (!comp.el) return;
    const box = comp.el.querySelector('.ogc-fbc__pic');
    if (!box) return;
    const pinLine = comp.pin && comp.pin.label ? '<p class="ogc-fbc__pin">Pointed at “' + esc(comp.pin.label) + '”</p>' : '';
    if (comp.busy) {
      box.innerHTML = '<div class="ogc-fbc__shot ogc-fbc__shot--wait" aria-busy="true"><span class="ogc-fbc__ph">Capturing screen</span></div>';
    } else if (comp.shot && !comp.removed) {
      box.innerHTML = '<div class="ogc-fbc__shot"><img alt="Screenshot of this screen" src="' + esc(comp.img || comp.shot.url) + '"></div>' +
        '<div class="ogc-fbc__tools"><button type="button" class="ogc-fbq ogc-fbq--chip" data-ogc-a="point" title="Tap the thing on the page you mean">' + (comp.pin ? 'Point again' : 'Point to it') + '</button>' +
        '<button type="button" class="ogc-fbq ogc-fbq--chip" data-ogc-a="retake" title="Take the picture again, as the screen is now">Retake</button>' +
        '<button type="button" class="ogc-fbq ogc-fbq--chip" data-ogc-a="unshot">Remove</button>' + pinLine + '</div>';
    } else {
      box.innerHTML = '<div class="ogc-fbc__tools">' + (comp.failed ? '' : '<button type="button" class="ogc-fbq ogc-fbq--chip" data-ogc-a="retake">Add screenshot</button>') +
        '<button type="button" class="ogc-fbq ogc-fbq--chip" data-ogc-a="point" title="Tap the thing on the page you mean">' + (comp.pin ? 'Point again' : 'Point to it') + '</button>' + pinLine + '</div>';
    }
  }
  async function take(after) {
    const t = ++comp.token;
    comp.busy = true;
    comp.removed = false;
    drawPic();
    let shot = null;
    try { shot = await captureOne(); comp.failed = false; } catch (e) { shot = null; comp.failed = true; }
    if (t !== comp.token) return; // closed, or taken again, meanwhile
    comp.busy = false;
    comp.shot = shot;
    if (after) after();
    comp.img = shot ? await withPin(shot, comp.pin) : '';
    if (t !== comp.token) return;
    drawPic();
  }

  // Point to it: the composer steps aside; the next tap marks what it was on (in a sheet too: the layer
  // is in the dock's root, over the sheet).
  function aim() {
    comp.el.hidden = true;
    document.documentElement.classList.add('ogc-fb-aiming');
    const lay = ui('div', 'ogc-fba');
    const box = ui('div', 'ogc-fba__box');
    const tip = ui('div', 'ogc-fba__tip', '<span>Tap what you mean</span><button type="button" class="ogc-fbq">Cancel</button>');
    tip.setAttribute('role', 'status');
    layer().append(lay, box, tip);
    const under = (x, y) => {
      lay.style.pointerEvents = 'none'; box.style.display = 'none';
      let el = document.elementFromPoint(x, y);
      lay.style.pointerEvents = '';
      // A sheet's backdrop is the sheet itself to the pointer: nothing there.
      if (el && el.tagName === 'DIALOG') { const b = el.getBoundingClientRect(); if (x < b.left || x > b.right || y < b.top || y > b.bottom) el = null; }
      return el && !el.closest('[data-ogc-tool]') ? el : null;
    };
    const target = el => { if (!el) return null; const m = el.closest('a,button,input,select,textarea,label,summary,[role=button],img,svg,h1,h2,h3,h4,li,tr,p') || el; return m === document.body || m === document.documentElement ? null : m; };
    const finish = () => {
      lay.remove(); box.remove(); tip.remove();
      document.removeEventListener('keydown', onKey, true);
      document.documentElement.classList.remove('ogc-fb-aiming');
      if (comp.open) { comp.el.hidden = false; const p = comp.el.querySelector('[data-ogc-a="point"]'); (p || comp.el.querySelector('h2')).focus(); }
    };
    const onKey = e => { if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); finish(); } };
    document.addEventListener('keydown', onKey, true);
    tip.querySelector('button').addEventListener('click', finish);
    lay.addEventListener('pointermove', e => {
      if (e.pointerType !== 'mouse') return;
      const el = target(under(e.clientX, e.clientY));
      if (!el) { box.style.display = 'none'; return; }
      const r = el.getBoundingClientRect();
      Object.assign(box.style, { display: 'block', left: (r.left - 3) + 'px', top: (r.top - 3) + 'px', width: (r.width + 6) + 'px', height: (r.height + 6) + 'px' });
    });
    lay.addEventListener('click', async e => {
      e.preventDefault();
      const el = target(under(e.clientX, e.clientY));
      const r = el ? el.getBoundingClientRect() : null;
      const pin = { label: labelOf(el || under(e.clientX, e.clientY)), px: e.clientX + scrollX, py: e.clientY + scrollY, box: r ? [r.left + scrollX, r.top + scrollY, r.width, r.height] : null };
      finish();
      setPin(pin);
    });
  }
  // A pin at a place on the page: on the picture when the picture holds it, else the picture again first.
  function setPin(p) {
    const fit = s => s && p.px >= s.sx && p.px <= s.sx + s.w && p.py >= s.sy && p.py <= s.sy + s.h;
    const place = () => {
      const s = comp.shot && !comp.removed ? comp.shot : null;
      const ox = s ? s.sx : scrollX, oy = s ? s.sy : scrollY, w = s ? s.w : innerWidth, h = s ? s.h : innerHeight;
      comp.pin = {
        label: p.label, cx: p.px - ox, cy: p.py - oy,
        box: p.box ? [p.box[0] - ox, p.box[1] - oy, p.box[2], p.box[3]] : null,
        x: Math.round((p.px - ox) / w * 1000) / 10, y: Math.round((p.py - oy) / h * 1000) / 10
      };
    };
    if (comp.shot && !comp.removed && !fit(comp.shot)) { take(place); return; }
    place();
    if (comp.shot && !comp.removed) withPin(comp.shot, comp.pin).then(u => { comp.img = u; drawPic(); });
    else drawPic();
  }

  function onComposerClick(e) {
    const b = e.target.closest('[data-ogc-a]');
    if (!b) return;
    const a = b.getAttribute('data-ogc-a');
    if (a === 'close') closeComposer();
    else if (a === 'send') send();
    else if (a === 'point') aim();
    else if (a === 'retake') take();
    else if (a === 'unshot') { comp.removed = true; comp.img = ''; drawPic(); const p = comp.el.querySelector('[data-ogc-a="point"]'); if (p) p.focus(); }
  }
  function fieldError(id, msg) {
    const f = comp.el.querySelector('#' + id), er = comp.el.querySelector('#' + id + '-e');
    if (er) er.textContent = msg;
    if (f) { f.setAttribute('aria-invalid', msg ? 'true' : 'false'); if (msg) f.focus(); }
  }
  async function send() {
    if (comp.sending) return;
    const t = comp.el.querySelector('#ogc-fbc-t'), n = comp.el.querySelector('#ogc-fbc-n'), status = comp.el.querySelector('.ogc-fbc__status');
    const text = t.value.trim(), name = n.value.trim();
    fieldError('ogc-fbc-n', name ? '' : 'Add your name');
    fieldError('ogc-fbc-t', text ? '' : 'Write your idea');
    if (!text) { t.focus(); return; }
    if (!name) { n.focus(); return; }
    API.setName(name);
    const sendBtn = comp.el.querySelector('[data-ogc-a="send"]');
    comp.sending = true;
    sendBtn.disabled = true;
    status.textContent = comp.busy ? 'Waiting for the picture' : 'Sending';
    // A picture still being taken: wait for it (at most a few seconds).
    for (let i = 0; comp.busy && i < 60; i++) await new Promise(r => setTimeout(r, 100));
    status.textContent = 'Sending';
    const c = comp.ctx || context();
    const pin = comp.pin ? { x: comp.pin.x, y: comp.pin.y, label: comp.pin.label } : null;
    const image = comp.shot && !comp.removed ? (comp.img || comp.shot.url) : '';
    const fields = { name, text, screen: c.screen, title: c.title, page: c.page, at: c.at, moment: c.moment, as: c.as, size: c.size, pin, image };
    let item = null, err = null;
    try { item = await API.add(fields); } catch (e) { err = e; }
    // A picture the store won't take: the idea goes without it.
    if (err && err.code === 'image' && image) { try { item = await API.add(Object.assign({}, fields, { image: '' })); err = null; } catch (e) { err = e; } }
    comp.sending = false;
    sendBtn.disabled = false;
    if (err) {
      if (err.code === 'name') fieldError('ogc-fbc-n', errWords('name'));
      else if (err.code === 'text') fieldError('ogc-fbc-t', errWords('text'));
      status.textContent = err.code === 'name' || err.code === 'text' ? '' : errWords(err.code);
      return;
    }
    closeComposer(false);
    lastNew = item ? item.id : '';
    refreshCounts(true);
    toast('Sent', 'View', () => openBoard(c.screen, goBtn, { sel: lastNew }));
    goBtn.focus();
  }

  /* ------------------------------------------------------------------ the toast */

  let toastEl = null, toastT = 0;
  function toast(words, act, fn) {
    if (!toastEl) {
      toastEl = ui('div', 'ogc-fbt');
      toastEl.setAttribute('role', 'status');
    }
    layer().appendChild(toastEl);
    toastEl.classList.toggle('ogc-fbt--board', board.open);
    toastEl.innerHTML = '<span>' + esc(words) + '</span>' + (act ? '<button type="button" class="ogc-fbq">' + esc(act) + '</button>' : '');
    toastEl.hidden = false;
    const b = toastEl.querySelector('button');
    if (b) b.addEventListener('click', () => { toastEl.hidden = true; fn(); });
    clearTimeout(toastT);
    toastT = setTimeout(() => { toastEl.hidden = true; }, 6000);
  }

  /* ------------------------------------------------------------------ the board */

  // Every screen of the demo, by area, in the order people meet them: [the path after the Conference's own
  // address, its name, what it is, its picture (img/screens/, taken from the demo, never from an idea),
  // 'phone' for the guide's]. Nov 4, Michael: plain names, and each screen's picture "the screen itself".
  const AREAS = [
    ['Conference page', [
      ['', 'Conference page', 'The main page: dates, services, news', 'conference'],
      ['?view=full', 'Full schedule', 'Every day of the week', 'full-schedule']]],
    ['Signing up', [
      ['register/', 'Registration form', 'Signing up a household: who, rooms, meals', 'register'],
      ['register/?view=mine', 'My registration', 'After registering: your rooms, meals, shifts', 'my-signups'],
      ['register/?view=receipt', 'Receipt', 'What was paid, to print or keep', 'receipt'],
      ['volunteer/', 'Volunteer shifts', 'Every committee’s shifts to sign up for', 'volunteer'],
      ['tournaments/', 'Youngfolks tournaments', 'Signing up a team', 'tournaments']]],
    ['At Conference', [
      ['guide/', 'Guide · Today', 'The phone guide during the week', 'guide', 'phone'],
      ['guide/?view=places', 'Guide · Places', 'Buildings, rooms, directions', 'guide-places', 'phone'],
      ['guide/?view=help', 'Guide · Help', 'Who to ask, and the packet', 'guide-help', 'phone']]],
    ['To print', [
      ['packet/', 'Information packet', 'Everything to know for the week', 'packet'],
      ['schedule/', 'Printed schedule', 'The week on one sheet', 'printed']]],
    ['Committees', [
      ['app/', 'COA home', 'What’s on the website, part by part', 'coa'],
      ['app/?s=lod-rooms', 'Lodging · Rooms', 'Placing households in rooms', 'lodging'],
      ['app/?s=years', 'Webmasters', 'Years and who can sign in', 'webmasters']]]
  ];
  const PICS = (W.assets || '') + 'shared/img/screens/';
  const LISTED = [];
  AREAS.forEach(([area, list]) => list.forEach(([p, name, hint, img, device]) => LISTED.push({ key: baseRel + p, name, hint, img, phone: device === 'phone', area })));
  // A screen's name: from the list, else from its address and the titles its ideas were left under.
  const screenName = (key, items) => { const s = LISTED.find(x => x.key === key); return s ? s.name : nameOf(key, items || []); };

  // view: 'feed' (every idea, or one screen's when screen is set) or 'tiles' (every screen). sort: new, old,
  // votes, replies. who: one person's ideas only. status: open, resolved, all. menu: the pill whose menu is
  // open. replies[id]: a card's replies shown; more[id]: its ⋯ shown; reply[id]: its reply being written.
  const board = { open: false, el: null, from: null, token: 0, items: null, admin: false, err: '', loading: false,
    view: 'feed', screen: '', sort: 'new', who: '', status: ['open', 'resolved', 'all'].includes(SS.get('ogc-fb-filter', 'open')) ? SS.get('ogc-fb-filter', 'open') : 'open',
    reply: {}, replies: {}, more: {}, confirm: '', menu: '', keyForm: false, keyErr: '', overflow: null, flash: '' };
  let lastNew = '';
  const SORTS = { new: 'Newest', old: 'Oldest', votes: 'Most upvoted', replies: 'Most replies' };
  const STATUS = { open: 'Open', resolved: 'Resolved', all: 'Open and resolved' };

  // The screen the count opens on: this one when it has ideas; else every idea.
  function openBoard(screen, from, o) {
    o = o || {};
    closeComposer(false);
    board.from = from || null;
    board.items = null;
    board.err = '';
    board.menu = '';
    board.keyForm = false;
    board.confirm = '';
    board.reply = {};
    board.replies = {};
    board.more = {};
    board.view = 'feed';
    board.screen = screen || '';
    board.flash = o.sel || '';
    if (!board.el) {
      board.el = ui('div', 'ogc-fbb');
      board.el.setAttribute('role', 'dialog');
      board.el.setAttribute('aria-modal', 'true');
      board.el.setAttribute('aria-labelledby', 'ogc-fbb-h');
      board.el.hidden = true;
      board.el.addEventListener('click', onBoardClick);
      board.el.addEventListener('keydown', onBoardKey);
      board.el.addEventListener('submit', e => e.preventDefault());
      let rt = 0;
      addEventListener('resize', () => { if (!board.open) return; clearTimeout(rt); rt = setTimeout(() => { fitCrops(); placeMenu(); }, 80); });
    }
    layer().appendChild(board.el);
    if (toastEl) toastEl.hidden = true;
    board.open = true;
    board.el.hidden = false;
    nBtn.setAttribute('aria-expanded', 'true');
    board.overflow = document.documentElement.style.overflow;
    document.documentElement.style.overflow = 'hidden';
    drawBoard({ top: true });
    focusIn('#ogc-fbb-h');
    load();
  }
  function closeBoard(back) {
    if (!board.open) return;
    board.open = false;
    board.token++;
    board.el.hidden = true;
    nBtn.setAttribute('aria-expanded', 'false');
    document.documentElement.style.overflow = board.overflow || '';
    lastNew = '';
    const f = board.from;
    board.from = null;
    if (back !== false && f && document.contains(f) && !f.hidden) f.focus();
    refreshCounts(true);
  }
  function load() {
    const t = ++board.token;
    board.loading = true;
    board.err = '';
    API.list('*').then(r => {
      if (t !== board.token) return;
      board.items = r.items;
      board.admin = r.admin;
      board.loading = false;
      drawBoard({ top: true });
      if (board.flash) {
        const c = board.el.querySelector('.ogc-fbk[data-ogc-id="' + CSS.escape(board.flash) + '"]');
        if (c) { c.scrollIntoView({ block: 'center' }); c.focus({ preventScroll: true }); }
      }
    }, e => {
      if (t !== board.token) return;
      board.loading = false;
      board.err = e.code || 'server';
      drawBoard();
    });
  }

  /* what's shown */
  const statusOk = x => board.status === 'all' || x.status === board.status;
  const passes = x => statusOk(x) && (!board.who || x.name === board.who);
  const BY = {
    new: (a, b) => (a.created < b.created ? 1 : -1),
    old: (a, b) => (a.created < b.created ? -1 : 1),
    votes: (a, b) => b.votes - a.votes || (a.created < b.created ? 1 : -1),
    replies: (a, b) => b.comments.length - a.comments.length || (a.created < b.created ? 1 : -1)
  };
  const byTime = () => board.sort === 'new' || board.sort === 'old';
  // Every listed screen, then any other screen with ideas (or this one), each with its ideas.
  function screens() {
    const by = new Map();
    (board.items || []).forEach(x => { if (!by.has(x.screen)) by.set(x.screen, []); by.get(x.screen).push(x); });
    const list = LISTED.map(s => Object.assign({}, s, { all: by.get(s.key) || [] }));
    [...by.keys()].concat(here).forEach(k => {
      if (list.find(s => s.key === k)) return;
      const all = by.get(k) || [];
      if (!all.length && k !== here) return;
      list.push({ key: k, name: nameOf(k, all.length ? all : [{ title: screenTitle() }]), hint: '', img: '', phone: false, area: 'Other', all });
    });
    list.forEach(s => { s.items = s.all.filter(passes); });
    return list;
  }
  const areas = ss => [...new Set(ss.map(s => s.area))].map(a => [a, ss.filter(s => s.area === a)]);
  const shown = () => (board.items || []).filter(x => passes(x) && (!board.screen || x.screen === board.screen)).sort(BY[board.sort]);
  // The screens ‹ › steps through: every idea, then each screen with some, in the list's order.
  const stops = () => [''].concat(screens().filter(s => s.items.length).map(s => s.key));
  function summary(xs) {
    const people = new Set(xs.map(x => x.name)).size;
    const st = board.status === 'all' ? '' : board.status + ' ';
    return xs.length + ' ' + st + (xs.length === 1 ? 'idea' : 'ideas') + (board.who ? ' from ' + board.who : xs.length ? ' · ' + people + (people === 1 ? ' person' : ' people') : '');
  }
  const DAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  function dayOf(iso) {
    const d = new Date(iso), t = new Date();
    t.setHours(0, 0, 0, 0);
    const x = new Date(d); x.setHours(0, 0, 0, 0);
    const n = Math.round((t - x) / 864e5);
    return n === 0 ? 'Today' : n === 1 ? 'Yesterday' : n > 1 && n < 7 ? DAYS[d.getDay()] + ', ' + MON[d.getMonth()] + ' ' + d.getDate() : MON[d.getMonth()] + ' ' + d.getDate() + (d.getFullYear() !== new Date().getFullYear() ? ', ' + d.getFullYear() : '');
  }
  const clock = iso => new Date(iso).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });

  /* pictures */
  function shot(s) {
    return s && s.img ? '<span class="ogc-fbsh' + (s.phone ? ' ogc-fbsh--phone' : '') + '" style="background-image:url(\'' + esc(PICS + s.img + '.jpg') + '\')" aria-hidden="true"></span>'
      : '<span class="ogc-fbsh ogc-fbsh--none" aria-hidden="true"></span>';
  }
  // An idea's picture cropped round what was pointed at: zoomed so it covers the box, placed in percent,
  // so the pin's point of the picture lands at the same percent of the box, where its dot is drawn.
  function crop(x) {
    const src = x.thumb || x.image;
    const m = /^(\d{2,5})×(\d{2,5})$/.exec(x.size || '');
    const p = x.pin ? { x: Math.max(0, Math.min(100, x.pin.x)), y: Math.max(0, Math.min(100, x.pin.y)) } : { x: 50, y: 0 };
    return '<button type="button" class="ogc-fbk__pic" data-ogc-a="pic" data-ogc-src="' + esc(x.image || src) + '" aria-label="Enlarge the screenshot">' +
      '<span class="ogc-fbk__crop" data-w="' + (m ? m[1] : 1600) + '" data-h="' + (m ? m[2] : 1000) + '" style="background-image:url(\'' + esc(src) + '\');background-position:' + p.x + '% ' + p.y + '%">' +
      (x.pin ? '<i class="ogc-fbk__dot" style="left:' + p.x + '%;top:' + p.y + '%"></i>' : '') + '</span></button>';
  }
  function fitCrops() {
    if (!board.el) return;
    board.el.querySelectorAll('.ogc-fbk__crop').forEach(el => {
      const iw = +el.dataset.w, ih = +el.dataset.h, bw = el.clientWidth, bh = el.clientHeight;
      if (!iw || !ih || !bw || !bh) return;
      const k = Math.max(bw / iw, bh / ih) * 1.5;
      el.style.backgroundSize = Math.round(iw * k) + 'px ' + Math.round(ih * k) + 'px';
    });
  }

  /* drawing */
  // The control that has the focus, as a selector that finds it again after the board is drawn anew.
  function focusKey() {
    const el = document.activeElement;
    if (!el || !board.el || !board.el.contains(el)) return '';
    if (el.id) return '#' + CSS.escape(el.id);
    const a = el.getAttribute('data-ogc-a');
    if (!a) return el.classList.contains('ogc-fbk') ? '.ogc-fbk[data-ogc-id="' + CSS.escape(el.getAttribute('data-ogc-id')) + '"]' : '';
    let s = '[data-ogc-a="' + a + '"]';
    ['data-ogc-id', 'data-ogc-v', 'data-ogc-k'].forEach(k => { const v = el.getAttribute(k); if (v) s += '[' + k + '="' + CSS.escape(v) + '"]'; });
    return s;
  }
  function refocus(k) {
    if (!k || (document.activeElement && board.el.contains(document.activeElement) && document.activeElement !== document.body)) return;
    const n = board.el.querySelector(k);
    if (n && n.getClientRects().length) n.focus({ preventScroll: true });
  }
  const focusIn = sel => { const el = board.el.querySelector(sel); if (el && el.getClientRects().length) { el.focus({ preventScroll: false }); return true; } return false; };

  function drawBoard(o) {
    if (!board.el) return;
    o = o || {};
    const fk = focusKey();
    keepReplies();
    const nav = board.el.querySelector('.ogc-fbb__side nav'), main = board.el.querySelector('.ogc-fbb__main');
    const navTop = nav ? nav.scrollTop : 0, mainTop = main ? main.scrollTop : 0;
    const ss = screens(), s = ss.find(t => t.key === board.screen);
    if (board.screen && !s) board.screen = '';
    const all = (board.items || []).filter(passes);
    const caret = '<svg viewBox="0 0 12 12" aria-hidden="true"><path d="M3 4.5 6 7.5l3-3" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg>';
    const pill = (k, words, n) => '<button type="button" data-ogc-a="m" data-ogc-k="' + k + '" aria-haspopup="true" aria-expanded="' + (board.menu === k) + '">' + words + (n != null ? '<span class="n num">' + n + '</span>' : '') + caret + '</button>';
    const where = board.view === 'tiles' ? 'All screens' : s ? s.name : 'All feedback';

    // The screens
    const row = (attrs, cur, pic, name, n, small, quiet) => '<button type="button" class="ogc-fbsr' + (quiet ? ' ogc-fbsr--quiet' : '') + '" ' + attrs + ' aria-current="' + cur + '">' + pic +
      '<span class="ogc-fbsr__n"><b>' + esc(name) + '</b>' + (small ? '<small>' + esc(small) + '</small>' : '') + '</span>' + (n ? '<span class="ogc-fbsr__c">' + n + '</span>' : '') + '</button>';
    const side = '<aside class="ogc-fbb__side" aria-label="Screens"><div class="ogc-fbb__sh"><b>Feedback</b><span>' + esc(board.items ? summary(all) : '') + '</span></div><nav>' +
      row('data-ogc-a="all"', board.view === 'feed' && !board.screen, '<span class="ogc-fbsr__ic">' + I.list + '</span>', 'All feedback', all.length) +
      row('data-ogc-a="tiles"', board.view === 'tiles', '<span class="ogc-fbsr__ic">' + I.grid + '</span>', 'All screens') +
      areas(ss).map(([area, list]) => '<p class="ogc-fbb__cap">' + esc(area) + '</p>' + list.map(t =>
        row('data-ogc-a="screen" data-ogc-v="' + esc(t.key) + '" title="' + esc(t.hint) + '"', board.view === 'feed' && board.screen === t.key, shot(t), t.name, t.items.length, t.key === here ? 'This screen' : '', !t.items.length)).join('')).join('') +
      '</nav></aside>';

    // Floating at the top
    const top = '<div class="ogc-fbb__top"><div class="ogc-fbb__scroll">' +
      '<div class="ogc-fbb__pill ogc-fbb__scr">' + pill('screen', '<b>' + esc(where) + '</b>', board.view === 'tiles' ? null : shown().length) + '</div>' +
      '<div class="ogc-fbb__pill">' + pill('sort', SORTS[board.sort]) + pill('who', esc(board.who || 'Everyone')) + pill('status', STATUS[board.status]) + '</div></div>' +
      '<span class="ogc-fbb__grow"></span>' + (board.admin ? '<span class="ogc-fbb__badge">Admin</span>' : '') +
      '<button type="button" class="ogc-fbp ogc-fbb__new" data-ogc-a="new" title="Leave feedback on this screen">' + I.plus + '<span class="ogc-fbb__l">Leave feedback</span></button>' +
      '<button type="button" class="ogc-fbb__round" data-ogc-a="m" data-ogc-k="more" aria-haspopup="true" aria-expanded="' + (board.menu === 'more' || board.keyForm) + '" aria-label="More">' + I.more + '</button>' +
      '<button type="button" class="ogc-fbb__round" data-ogc-a="close" aria-label="Close" title="Esc">' + I.x + '</button></div>';

    // The middle
    let mid;
    if (board.loading && !board.items) mid = '<div class="ogc-fbb__col"><header class="ogc-fbb__head"><div><h2 id="ogc-fbb-h" tabindex="-1">' + esc(where) + '</h2></div></header><p class="ogc-fbb__line" role="status">Loading</p></div>';
    else if (board.err) mid = '<div class="ogc-fbb__col"><header class="ogc-fbb__head"><div><h2 id="ogc-fbb-h" tabindex="-1">Feedback</h2></div></header><p class="ogc-fbb__line" role="status">' + esc(errWords(board.err)) + '</p><p style="text-align:center"><button type="button" class="ogc-fbp ogc-fbp--sm" data-ogc-a="reload">Try again</button></p></div>';
    else if (board.view === 'tiles') mid = drawTiles(ss, all);
    else mid = drawFeed(s);

    board.el.innerHTML = side + top + '<main class="ogc-fbb__main">' + mid + '</main>' + popHtml(ss, all);
    const nav2 = board.el.querySelector('.ogc-fbb__side nav'), main2 = board.el.querySelector('.ogc-fbb__main');
    if (nav2) nav2.scrollTop = navTop;
    if (main2) main2.scrollTop = o.top ? 0 : mainTop;
    if (o.top && nav2) { const c = nav2.querySelector('[aria-current="true"]'); if (c) c.scrollIntoView({ block: 'nearest' }); }
    fitCrops();
    placeMenu();
    refocus(fk);
  }

  function drawFeed(s) {
    const xs = shown();
    const st = stops();
    let h = '<div class="ogc-fbb__col"><header class="ogc-fbb__head">' + (s ? shot(s) : '') + '<div><h2 id="ogc-fbb-h" tabindex="-1">' + esc(s ? s.name : 'All feedback') + '</h2>' +
      '<p>' + (s && s.hint ? '<span class="ogc-fbb__hint">' + esc(s.hint) + '<br></span>' : '') + esc(summary(xs)) + '</p></div>' +
      (s && st.length > 2 ? '<div class="ogc-fbb__steps"><button type="button" data-ogc-a="step" data-ogc-v="-1" aria-label="Previous screen" title="Previous screen (←)">' + I.back + '</button><button type="button" data-ogc-a="step" data-ogc-v="1" aria-label="Next screen" title="Next screen (→)">' + I.next + '</button></div>' : '') +
      '</header>';
    if (!xs.length) {
      const any = (board.items || []).some(x => !board.screen || x.screen === board.screen);
      h += '<p class="ogc-fbb__line">' + (board.who ? 'Nothing from ' + esc(board.who) + ' here' : any && board.status === 'open' ? 'Nothing open' : any && board.status === 'resolved' ? 'Nothing resolved yet' : board.screen === here ? 'No feedback on this screen yet' : 'No feedback yet') + '</p>';
    }
    let last = '';
    xs.forEach(x => {
      if (byTime()) { const d = dayOf(x.created); if (d !== last) { h += '<p class="ogc-fbb__day">' + d + '</p>'; last = d; } }
      h += card(x);
    });
    return h + '</div>';
  }

  // One idea: who, the screen, when; the words; its picture; Upvote, Reply and the replies; ⋯ for the rest.
  function card(x) {
    const r = x.comments.length, open = !!board.replies[x.id], more = !!board.more[x.id];
    const del = x.mine || board.admin, conf = board.confirm === 'i:' + x.id;
    // What was pointed at only when its words are short enough to read (a whole card's run together isn't).
    const seen = [x.moment, noEmail(x.as), deviceOf(x.size), x.pin && x.pin.label && x.pin.label.length <= 48 ? 'Pointed at “' + x.pin.label + '”' : ''].filter(Boolean).join(' · ');
    const thread = x.comments.map(c => {
      const cc = board.confirm === 'c:' + c.id;
      return '<div class="ogc-fbk__r">' + avatar(c.name, true) + '<div><header><b>' + esc(c.name) + '</b><span>' + esc(ago(c.created)) + '</span>' +
        (c.mine || board.admin ? '<button type="button" class="ogc-fbq' + (cc ? ' ogc-fbq--danger' : '') + '" data-ogc-a="delc" data-ogc-id="' + esc(c.id) + '" data-ogc-item="' + esc(x.id) + '">' + (cc ? 'Confirm delete' : 'Delete') + '</button>' : '') +
        '</header><p>' + esc(c.text) + '</p></div></div>';
    }).join('');
    return '<article class="ogc-fbk' + (x.status === 'resolved' ? ' ogc-fbk--done' : '') + (x.id === board.flash ? ' ogc-fbk--flash' : '') + '" data-ogc-id="' + esc(x.id) + '" tabindex="-1" aria-label="' + esc(x.name + ', ' + x.text.slice(0, 80)) + '">' +
      '<div class="ogc-fbk__who">' + avatar(x.name) + '<b>' + esc(x.name) + '</b>' + (board.screen ? '' : '<em>' + esc(screenName(x.screen, [x])) + '</em>') +
        (x.status === 'resolved' ? '<span class="ogc-fbk__res">Resolved</span>' : '') +
        '<time datetime="' + esc(x.created) + '" title="' + esc(dayOf(x.created) + ', ' + clock(x.created)) + '">' + esc(byTime() ? clock(x.created) : dayOf(x.created)) + '</time></div>' +
      '<p class="ogc-fbk__t">' + esc(x.text) + '</p>' +
      (x.thumb || x.image ? crop(x) : '') +
      '<div class="ogc-fbk__acts">' +
        '<button type="button" class="ogc-fb-up" data-ogc-a="vote" data-ogc-id="' + esc(x.id) + '" aria-pressed="' + !!x.voted + '" aria-label="Upvote' + (x.votes ? ', ' + x.votes : '') + '">' + I.up + 'Upvote' + (x.votes ? '<span class="c num">' + x.votes + '</span>' : '') + '</button>' +
        '<button type="button" class="ogc-fbk__a" data-ogc-a="reply" data-ogc-id="' + esc(x.id) + '" aria-expanded="' + !!board.reply[x.id] + '">' + I.reply + 'Reply</button>' +
        (r ? '<button type="button" class="ogc-fbk__a ogc-fbk__a--quiet" data-ogc-a="replies" data-ogc-id="' + esc(x.id) + '" aria-expanded="' + open + '">' + (open ? 'Hide replies' : r + (r === 1 ? ' reply' : ' replies')) + '</button>' : '') +
        '<button type="button" class="ogc-fbk__a ogc-fbk__a--quiet ogc-fbk__a--end" data-ogc-a="more" data-ogc-id="' + esc(x.id) + '" aria-expanded="' + more + '" aria-label="Details" title="Details">' + I.more + '</button>' +
      '</div>' +
      (board.reply[x.id] ? replyForm(x.id) : '') +
      (open && r ? '<div class="ogc-fbk__thread">' + thread + '</div>' : '') +
      (more ? '<div class="ogc-fbk__more"><span>' + esc(seen || 'No details') + '</span>' +
        (x.page ? '<button type="button" class="ogc-fbq" data-ogc-a="goto" data-ogc-id="' + esc(x.id) + '" title="That screen, on the day and as the person it was left on">Go to screen</button>' : '') +
        (board.admin ? '<button type="button" class="ogc-fbq" data-ogc-a="' + (x.status === 'resolved' ? 'reopen' : 'resolve') + '" data-ogc-id="' + esc(x.id) + '">' + (x.status === 'resolved' ? 'Reopen' : 'Resolve') + '</button>' : '') +
        (del ? '<button type="button" class="ogc-fbq' + (conf ? ' ogc-fbq--danger' : '') + '" data-ogc-a="deli" data-ogc-id="' + esc(x.id) + '">' + (conf ? 'Confirm delete' : 'Delete') + '</button>' : '') +
        '</div>' : '') +
      '</article>';
  }
  // Writing a reply: the words, then the name (kept from last time) beside Cancel and Reply.
  function replyForm(id) {
    const r = board.reply[id] || {};
    return '<form class="ogc-fbk__form" data-ogc-a="replyform" data-ogc-id="' + esc(id) + '">' +
      '<label class="ogc-fb-sr" for="ogc-fbr-t-' + esc(id) + '">Your reply</label><textarea id="ogc-fbr-t-' + esc(id) + '" rows="3" maxlength="2000" placeholder="Write a reply" aria-describedby="ogc-fbr-t-' + esc(id) + '-e">' + esc(r.text || '') + '</textarea>' +
      '<p class="ogc-fb-err" id="ogc-fbr-t-' + esc(id) + '-e">' + esc(r.tErr || '') + '</p>' +
      '<div class="ogc-fbc__foot"><span class="ogc-fbk__name"><label class="ogc-fb-sr" for="ogc-fbr-n-' + esc(id) + '">Your name</label><input type="text" id="ogc-fbr-n-' + esc(id) + '" maxlength="60" autocomplete="name" placeholder="Your name" value="' + esc(r.name != null ? r.name : API.name()) + '" aria-describedby="ogc-fbr-n-' + esc(id) + '-e">' +
      '<span class="ogc-fb-err" id="ogc-fbr-n-' + esc(id) + '-e">' + esc(r.nErr || '') + '</span></span>' +
      '<span class="ogc-fbc__status" role="status">' + esc(r.status || '') + '</span><button type="button" class="ogc-fbq" data-ogc-a="noreply" data-ogc-id="' + esc(id) + '">Cancel</button><button type="submit" class="ogc-fbp ogc-fbp--sm" data-ogc-a="sendreply" data-ogc-id="' + esc(id) + '">Reply</button></div></form>';
  }

  function drawTiles(ss, all) {
    return '<div class="ogc-fbb__wide"><header class="ogc-fbb__head"><div><h2 id="ogc-fbb-h" tabindex="-1">All screens</h2><p>' + ss.length + ' screens · ' + esc(summary(all)) + '</p></div></header>' +
      areas(ss).map(([area, list]) => '<h3 class="ogc-fbb__area">' + esc(area) + '</h3><div class="ogc-fbb__tiles">' + list.map(t => {
        const xs = t.items.slice().sort(BY.new), names = [...new Set(xs.map(x => x.name))];
        return '<button type="button" class="ogc-fbtl' + (xs.length ? '' : ' ogc-fbtl--quiet') + '" data-ogc-a="screen" data-ogc-v="' + esc(t.key) + '">' + shot(t) +
          '<span class="ogc-fbtl__b"><b>' + esc(t.name) + '</b>' + (t.hint ? '<span>' + esc(t.hint) + '</span>' : '') +
          '<small>' + (xs.length ? '<span>' + names.slice(0, 4).map(n => avatar(n, true)).join('') + '</span><span class="num">' + xs.length + (xs.length === 1 ? ' idea' : ' ideas') + '</span><span>·</span><span>' + esc(ago(xs[0].created)) + '</span>' : t.key === here ? 'This screen · No ideas yet' : 'No ideas yet') + '</small></span></button>';
      }).join('') + '</div>').join('') + '</div>';
  }

  // The open pill's menu: the screens (on a phone), sort, people, open or resolved, or ⋯ (Admin).
  function popHtml(ss, all) {
    if (board.keyForm) {
      return '<form class="ogc-fbb__pop ogc-fbb__key" data-ogc-for="more" data-ogc-a="keyform"><label for="ogc-fbb-key">Admin key</label><input type="password" id="ogc-fbb-key" autocomplete="off" spellcheck="false" aria-describedby="ogc-fbb-key-e"' + (board.keyErr ? ' aria-invalid="true"' : '') + '>' +
        '<p class="ogc-fb-err" id="ogc-fbb-key-e">' + esc(board.keyErr) + '</p><div><button type="button" class="ogc-fbq" data-ogc-a="nokey">Cancel</button><button type="submit" class="ogc-fbp ogc-fbp--sm" data-ogc-a="unlock">Unlock</button></div></form>';
    }
    const k = board.menu;
    if (!k) return '';
    const opt = (v, words, on, n) => '<button type="button" role="menuitemradio" data-ogc-a="opt" data-ogc-k="' + k + '" data-ogc-v="' + esc(v) + '" aria-checked="' + on + '">' + esc(words) + (n ? '<span class="n num">' + n + '</span>' : '') + '</button>';
    let h = '';
    if (k === 'screen') {
      h = opt('', 'All feedback', board.view === 'feed' && !board.screen, all.length) + opt('@tiles', 'All screens', board.view === 'tiles') +
        areas(ss).map(([area, list]) => '<p class="ogc-fbb__cap">' + esc(area) + '</p>' + list.map(t => opt(t.key, t.name, board.view === 'feed' && board.screen === t.key, t.items.length)).join('')).join('');
    } else if (k === 'sort') {
      h = Object.keys(SORTS).map(v => opt(v, SORTS[v], board.sort === v)).join('');
    } else if (k === 'who') {
      const t = {};
      (board.items || []).filter(statusOk).forEach(x => { t[x.name] = (t[x.name] || 0) + 1; });
      h = opt('', 'Everyone', !board.who, (board.items || []).filter(statusOk).length) + Object.keys(t).sort((a, b) => t[b] - t[a] || a.localeCompare(b)).map(n => opt(n, n, board.who === n, t[n])).join('');
    } else if (k === 'status') {
      const c = v => (board.items || []).filter(x => (v === 'all' || x.status === v) && (!board.who || x.name === board.who)).length;
      h = Object.keys(STATUS).map(v => opt(v, STATUS[v], board.status === v, c(v))).join('');
    } else if (k === 'more') {
      h = board.admin ? '<button type="button" role="menuitem" data-ogc-a="unadmin">Exit admin</button>' : '<button type="button" role="menuitem" data-ogc-a="admin" title="Resolve and delete anyone’s ideas">Admin</button>';
    }
    return '<div class="ogc-fbb__pop" role="menu" data-ogc-for="' + k + '">' + h + '</div>';
  }
  // A menu sits under its pill, inside the window.
  function placeMenu() {
    const p = board.el && board.el.querySelector('.ogc-fbb__pop');
    if (!p) return;
    const b = board.el.querySelector('[data-ogc-a="m"][data-ogc-k="' + p.getAttribute('data-ogc-for') + '"]');
    if (!b) return;
    const r = b.getBoundingClientRect(), w = p.offsetWidth;
    p.style.top = Math.round(r.bottom + 8) + 'px';
    p.style.left = Math.round(Math.max(12, Math.min(r.right > innerWidth - 120 ? r.right - w : r.left, innerWidth - w - 12))) + 'px';
  }

  const find = id => (board.items || []).find(x => x.id === id);
  // Keep what's typed in an open reply before drawing again.
  function keepReplies() {
    if (!board.el) return;
    Object.keys(board.reply).forEach(id => {
      const t = board.el.querySelector('#ogc-fbr-t-' + CSS.escape(id)), n = board.el.querySelector('#ogc-fbr-n-' + CSS.escape(id));
      if (t) board.reply[id].text = t.value;
      if (n) board.reply[id].name = n.value;
    });
  }
  function go(view, screen) {
    board.view = view;
    board.screen = screen || '';
    board.menu = '';
    board.confirm = '';
    board.flash = '';
    drawBoard({ top: true });
    focusIn('#ogc-fbb-h');
  }
  function step(d) {
    const st = stops();
    if (board.view !== 'feed' || st.length < 2) return;
    const i = Math.max(0, st.indexOf(board.screen));
    go('feed', st[(i + d + st.length) % st.length]);
  }

  async function onBoardClick(e) {
    const b = e.target.closest('[data-ogc-a]');
    if (!b || b.tagName === 'FORM') {
      if ((board.menu || board.keyForm) && !e.target.closest('.ogc-fbb__pop')) { board.menu = ''; board.keyForm = false; drawBoard(); }
      return;
    }
    const a = b.getAttribute('data-ogc-a'), id = b.getAttribute('data-ogc-id') || '';
    if (board.menu && a !== 'm' && a !== 'opt' && a !== 'admin') board.menu = '';
    if (a !== 'deli' && a !== 'delc') board.confirm = '';
    if (a === 'close') return closeBoard();
    if (a === 'new') { closeBoard(false); return openComposer(); }
    if (a === 'm') {
      const k = b.getAttribute('data-ogc-k');
      const was = board.menu === k || (k === 'more' && board.keyForm);
      board.menu = was ? '' : k;
      board.keyForm = false;
      drawBoard();
      // The checked choice, else the first (one selector list would give whichever comes first).
      if (board.menu) return focusIn('.ogc-fbb__pop [aria-checked="true"]') || focusIn('.ogc-fbb__pop button');
      return focusIn('[data-ogc-a="m"][data-ogc-k="' + k + '"]');
    }
    if (a === 'opt') {
      const k = b.getAttribute('data-ogc-k'), v = b.getAttribute('data-ogc-v');
      board.menu = '';
      if (k === 'screen') return v === '@tiles' ? go('tiles') : go('feed', v);
      if (k === 'sort') board.sort = v;
      if (k === 'who') board.who = v;
      if (k === 'status') { board.status = v; SS.set('ogc-fb-filter', v); }
      drawBoard({ top: true });
      return focusIn('[data-ogc-a="m"][data-ogc-k="' + k + '"]');
    }
    if (a === 'admin') { board.menu = ''; board.keyForm = true; board.keyErr = ''; drawBoard(); return focusIn('#ogc-fbb-key'); }
    if (a === 'unadmin') { API.setAdminKey(''); board.admin = false; board.menu = ''; drawBoard(); return focusIn('#ogc-fbb-h'); }
    if (a === 'nokey') { board.keyForm = false; drawBoard(); return focusIn('[data-ogc-a="m"][data-ogc-k="more"]'); }
    if (a === 'unlock') { e.preventDefault(); return unlock(); }
    if (a === 'all') return go('feed', '');
    if (a === 'tiles') return go('tiles');
    if (a === 'screen') return go('feed', b.getAttribute('data-ogc-v'));
    if (a === 'step') return step(+b.getAttribute('data-ogc-v'));
    if (a === 'reload') return load();
    if (a === 'pic') return enlarge(b.getAttribute('data-ogc-src'), b);
    if (a === 'goto') { const x = find(id); if (x && dockInfo().travel) dockInfo().travel(x.page, x.at, x.as); else if (x) location.href = home.replace(/\/$/, '') + x.page; return; }
    if (a === 'replies') { board.replies[id] = !board.replies[id]; drawBoard(); return focusIn('[data-ogc-a="replies"][data-ogc-id="' + CSS.escape(id) + '"]'); }
    if (a === 'more') { board.more[id] = !board.more[id]; drawBoard(); return focusIn('[data-ogc-a="more"][data-ogc-id="' + CSS.escape(id) + '"]'); }
    if (a === 'reply') { keepReplies(); if (board.reply[id]) delete board.reply[id]; else board.reply[id] = {}; drawBoard(); return focusIn(board.reply[id] ? '#ogc-fbr-t-' + CSS.escape(id) : '[data-ogc-a="reply"][data-ogc-id="' + CSS.escape(id) + '"]'); }
    if (a === 'noreply') { delete board.reply[id]; drawBoard(); return focusIn('[data-ogc-a="reply"][data-ogc-id="' + CSS.escape(id) + '"]'); }
    if (a === 'sendreply') { e.preventDefault(); return reply(id); }
    if (a === 'vote') {
      const x = find(id);
      if (!x) return;
      // Shown at once; put back if the store says no.
      const was = { votes: x.votes, voted: x.voted };
      x.voted = !x.voted; x.votes = Math.max(0, x.votes + (x.voted ? 1 : -1));
      drawBoard(); focusIn('[data-ogc-a="vote"][data-ogc-id="' + CSS.escape(id) + '"]');
      try { const r = await API.vote(id); x.votes = r.votes; x.voted = r.voted; } catch (er) { Object.assign(x, was); toast(errWords(er.code)); }
      if (!board.open) return;
      drawBoard(); return focusIn('[data-ogc-a="vote"][data-ogc-id="' + CSS.escape(id) + '"]');
    }
    if (a === 'deli' || a === 'delc') {
      const k = (a === 'deli' ? 'i:' : 'c:') + id;
      if (board.confirm !== k) { board.confirm = k; drawBoard(); return focusIn('[data-ogc-a="' + a + '"][data-ogc-id="' + CSS.escape(id) + '"]'); }
      board.confirm = '';
      const item = a === 'deli' ? id : b.getAttribute('data-ogc-item');
      try {
        if (a === 'deli') {
          await API.removeItem(id);
          board.items = board.items.filter(x => x.id !== id);
          refreshCounts(true);
        } else { await API.removeComment(id); const x = find(item); if (x) x.comments = x.comments.filter(c => c.id !== id); }
        toast('Deleted');
      } catch (er) { toast(errWords(er.code)); }
      if (!board.open) return;
      drawBoard();
      return a === 'deli' ? focusIn('#ogc-fbb-h') : focusIn('.ogc-fbk[data-ogc-id="' + CSS.escape(item) + '"]');
    }
    if (a === 'resolve' || a === 'reopen') {
      try {
        const st = await API[a](id);
        const x = find(id);
        if (x) x.status = st;
        toast(a === 'resolve' ? 'Resolved' : 'Reopened');
        refreshCounts(true);
      } catch (er) { toast(errWords(er.code)); }
      if (!board.open) return;
      drawBoard();
      return focusIn('.ogc-fbk[data-ogc-id="' + CSS.escape(id) + '"]') || focusIn('#ogc-fbb-h');
    }
  }
  async function unlock() {
    const f = board.el.querySelector('#ogc-fbb-key');
    const k = f ? f.value.trim() : '';
    if (!k) { board.keyErr = 'Type the admin key'; drawBoard(); return focusIn('#ogc-fbb-key'); }
    let ok = false;
    try { ok = await API.checkAdmin(k); } catch (er) { board.keyErr = errWords(er.code); drawBoard(); return focusIn('#ogc-fbb-key'); }
    if (!ok) { board.keyErr = 'Not the admin key'; drawBoard(); return focusIn('#ogc-fbb-key'); }
    board.keyForm = false;
    board.keyErr = '';
    board.admin = true;
    drawBoard();
    focusIn('#ogc-fbb-h');
    load();
  }
  async function reply(id) {
    keepReplies();
    const r = board.reply[id];
    if (!r) return;
    const text = String(r.text || '').trim(), name = String(r.name != null ? r.name : API.name()).trim();
    r.tErr = text ? '' : 'Write your reply';
    r.nErr = name ? '' : 'Add your name';
    if (!text || !name) { drawBoard(); return focusIn('#ogc-fbr-' + (!text ? 't' : 'n') + '-' + CSS.escape(id)); }
    API.setName(name);
    r.status = 'Sending';
    drawBoard();
    try {
      const c = await API.comment(id, name, text);
      const x = find(id);
      if (x) x.comments.push(c);
      delete board.reply[id];
      board.replies[id] = true;
      if (!board.open) return;
      drawBoard();
      focusIn('[data-ogc-a="reply"][data-ogc-id="' + CSS.escape(id) + '"]');
    } catch (er) {
      r.status = '';
      if (er.code === 'name') r.nErr = errWords('name'); else if (er.code === 'text') r.tErr = 'Write your reply'; else r.status = errWords(er.code);
      drawBoard();
    }
  }
  function onBoardKey(e) {
    const t = e.target, typing = t && t.matches && t.matches('input, textarea, select, [contenteditable]');
    if (e.key === 'Escape') {
      e.preventDefault();
      if (board.keyForm || board.menu) { const k = board.keyForm ? 'more' : board.menu; board.menu = ''; board.keyForm = false; drawBoard(); return focusIn('[data-ogc-a="m"][data-ogc-k="' + k + '"]'); }
      if (board.confirm) { board.confirm = ''; drawBoard(); return; }
      if (typing && t.closest('.ogc-fbk__form')) { const id = t.closest('.ogc-fbk__form').getAttribute('data-ogc-id'); delete board.reply[id]; drawBoard(); return focusIn('[data-ogc-a="reply"][data-ogc-id="' + CSS.escape(id) + '"]'); }
      return closeBoard();
    }
    if (e.key === 'Enter' && t.matches('#ogc-fbb-key')) { e.preventDefault(); return unlock(); }
    if (e.key === 'Enter' && (e.metaKey || e.ctrlKey) && t.closest('.ogc-fbk__form')) { e.preventDefault(); return reply(t.closest('.ogc-fbk__form').getAttribute('data-ogc-id')); }
    // In a menu, the arrows move between its choices.
    if (board.menu && t.closest('.ogc-fbb__pop') && (e.key === 'ArrowDown' || e.key === 'ArrowUp')) {
      e.preventDefault();
      const bs = [...board.el.querySelectorAll('.ogc-fbb__pop button')], i = bs.indexOf(t);
      const n = bs[(i + (e.key === 'ArrowDown' ? 1 : -1) + bs.length) % bs.length];
      if (n) n.focus();
      return;
    }
    if (!typing && !e.altKey && !e.metaKey && !e.ctrlKey && !board.menu && !board.keyForm) {
      const k = e.key;
      // ← → the screens; J K (or ↓ ↑ from a card) the ideas.
      if (k === 'ArrowLeft' || k === 'ArrowRight') { e.preventDefault(); return step(k === 'ArrowRight' ? 1 : -1); }
      const down = k === 'j' || k === 'J' || (k === 'ArrowDown' && t.classList.contains('ogc-fbk')), up = k === 'k' || k === 'K' || (k === 'ArrowUp' && t.classList.contains('ogc-fbk'));
      if (down || up) {
        const cards = [...board.el.querySelectorAll('.ogc-fbk')];
        if (!cards.length) return;
        e.preventDefault();
        const cur = t.closest('.ogc-fbk'), i = cards.indexOf(cur);
        const n = cards[Math.max(0, Math.min(cards.length - 1, i < 0 ? 0 : i + (down ? 1 : -1)))];
        n.focus({ preventScroll: true });
        n.scrollIntoView({ block: 'nearest' });
        return;
      }
    }
    // Tab stays inside the board.
    if (e.key === 'Tab') {
      const f = [...board.el.querySelectorAll('button, input, textarea, h2[tabindex]')].filter(x => x.getClientRects().length && !x.disabled);
      if (!f.length) return;
      const i = f.indexOf(document.activeElement);
      if (e.shiftKey && i <= 0) { e.preventDefault(); f[f.length - 1].focus(); } else if (!e.shiftKey && i === f.length - 1) { e.preventDefault(); f[0].focus(); }
    }
  }

  /* ------------------------------------------------------------------ the picture, enlarged */

  let lightbox = null;
  function enlarge(src, from) {
    if (!src) return;
    const l = ui('div', 'ogc-fbl', '<button type="button" class="ogc-fbx" aria-label="Close">' + I.x + '</button><img alt="Screenshot" src="' + esc(src) + '">');
    l.setAttribute('role', 'dialog');
    l.setAttribute('aria-modal', 'true');
    l.setAttribute('aria-label', 'Screenshot');
    layer().appendChild(l);
    lightbox = l;
    const done = () => { l.remove(); lightbox = null; document.removeEventListener('keydown', key, true); if (from && document.contains(from)) from.focus(); };
    const key = ev => { if (ev.key === 'Escape') { ev.preventDefault(); ev.stopPropagation(); done(); } else if (ev.key === 'Tab') { ev.preventDefault(); l.querySelector('button').focus(); } };
    document.addEventListener('keydown', key, true);
    l.addEventListener('click', done);
    l.querySelector('button').focus();
  }

  /* ------------------------------------------------------------------ start */

  // For the tests: the screen key rule and the screen names, as the board uses them.
  window.OGC_FEEDBACK.screenKey = screenKey;
  window.OGC_FEEDBACK.screenName = screenName;
  const start = () => { if (!dock && window.OGC_DOCK) mount(window.OGC_DOCK); };
  if (window.OGC_DOCK) start(); else document.addEventListener('ogc-dock', start, { once: true });
})();
