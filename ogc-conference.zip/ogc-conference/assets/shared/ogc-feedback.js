/*
 * ogc-feedback.js — the shared prototype's Feedback button (Oct 30, after the COA meeting; Michael: "a very
 * easy way for anybody who's looking at it to quickly know, okay, I want to give some feedback regarding
 * this item right here… leave a picture… and it goes to me"). Loaded with ogc-dev-nav.js: the local site
 * and the shared prototype only, never on ogbbc.org.
 *
 * The prototype runs WordPress inside the visitor's browser and keeps nothing, so a note is posted to the
 * webmasters' Google Apps Script (tools/feedback-apps-script.gs: a row in a Sheet, the picture in Drive, an
 * email). Its address is OGC_WP.feedback (the OGC_FEEDBACK_URL constant). With none set, the local site keeps
 * notes in this browser (localStorage "ogc-feedback-local") so the button can be tried; the prototype draws
 * no button.
 *
 * A note carries what it's about by itself: the page, the previewed moment, who's signed in, the screen,
 * and, with "Point to it", the thing tapped (its words and where it is on the page).
 */
(function () {
  'use strict';
  const W = window.OGC_WP || {};
  if (!W.dev && !W.prototype) return;
  // The prototype has dev on too, but a note kept in a visitor's own browser reaches no one.
  if (W.prototype && !W.feedback) return;
  const framed = (() => { try { return window.top !== window && !!(window.parent && window.parent.OGC_WP); } catch (e) { return false; } })();
  if (framed) return;

  const LS = {
    get(k, d) { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch (e) { return d; } },
    set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { /* nothing kept */ } }
  };
  const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
  const still = () => window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;

  const css = document.createElement('style');
  css.textContent =
    '.ogc-fb-btn{position:fixed;left:16px;bottom:calc(16px + var(--ogc-pill-lift,0px) + env(safe-area-inset-bottom));z-index:62;display:inline-flex;align-items:center;gap:8px;min-height:44px;padding:0 16px;border:0;border-radius:999px;background:#1f1f1f;color:#e8c98f;font:700 12px/1 var(--ogb-sans,Arial,sans-serif);letter-spacing:1.2px;text-transform:uppercase;cursor:pointer;box-shadow:0 2px 10px rgba(0,0,0,.18)}' +
    '.ogc-fb-btn:hover{background:#333}.ogc-fb-btn:focus-visible,.ogc-fb :focus-visible{outline:2px solid #76623F;outline-offset:2px}' +
    '.ogc-fb-btn svg{width:16px;height:16px}' +
    '.ogc-fb{position:fixed;left:16px;bottom:calc(16px + var(--ogc-pill-lift,0px) + env(safe-area-inset-bottom));z-index:63;width:min(360px,calc(100vw - 32px));max-height:calc(100vh - 32px - var(--ogc-pill-lift,0px));overflow:auto;background:#fff;border-radius:10px;box-shadow:0 8px 32px rgba(0,0,0,.22);font:15px/1.45 var(--ogb-sans,Arial,sans-serif);color:#333;padding:18px 18px 16px}' +
    '.ogc-fb[hidden],.ogc-fb-btn[hidden]{display:none}' +
    '.ogc-fb h2{margin:0 0 12px;font:700 20px/1.2 var(--ogb-serif,"Noto Serif",Georgia,serif);color:#333}' +
    '.ogc-fb label{display:block;margin:12px 0 4px;font:700 12px/1.2 var(--ogb-sans,Arial,sans-serif);letter-spacing:1.2px;text-transform:uppercase;color:#76623F}' +
    '.ogc-fb textarea,.ogc-fb input[type=text]{box-sizing:border-box;width:100%;border:1px solid #c9c2b2;border-radius:6px;padding:10px 12px;font:16px/1.4 var(--ogb-sans,Arial,sans-serif);color:#333;background:#fff}' +
    '.ogc-fb textarea{min-height:96px;resize:vertical}' +
    '.ogc-fb__row{display:flex;flex-wrap:wrap;gap:8px;margin-top:10px}' +
    '.ogc-fb__chip{display:inline-flex;align-items:center;gap:6px;min-height:44px;padding:0 14px;border:1px solid #C0AB85;border-radius:999px;background:#fff;color:#333;font:600 14px/1 var(--ogb-sans,Arial,sans-serif);cursor:pointer}' +
    '.ogc-fb__chip:hover{background:#F3F2EB}' +
    '.ogc-fb__got{display:flex;align-items:center;gap:8px;margin-top:10px;padding:6px 6px 6px 12px;background:#F3F2EB;border-radius:8px;font-size:14px}' +
    '.ogc-fb__got span{flex:1;min-width:0;overflow-wrap:anywhere}' +
    '.ogc-fb__got img{width:44px;height:44px;object-fit:cover;border-radius:4px}' +
    '.ogc-fb__x{flex:none;width:44px;height:44px;border:0;background:none;color:#555;font-size:20px;cursor:pointer;border-radius:6px}' +
    '.ogc-fb__x:hover{background:#e9e6dc}' +
    '.ogc-fb__foot{display:flex;align-items:center;justify-content:flex-end;gap:16px;margin-top:16px}' +
    '.ogc-fb__cancel{min-height:44px;border:0;background:none;color:#333;font:15px var(--ogb-sans,Arial,sans-serif);text-decoration:underline;cursor:pointer}' +
    '.ogc-fb__send{min-height:44px;padding:0 22px;border:0;border-radius:4px;background:#C0AB85;color:#333;font:700 13px/1 var(--ogb-sans,Arial,sans-serif);letter-spacing:1.2px;text-transform:uppercase;cursor:pointer}' +
    '.ogc-fb__send:hover{background:#b19b72}.ogc-fb__send:disabled{opacity:.55;cursor:default}' +
    '.ogc-fb__status{margin:10px 0 0;font-size:14px;color:#76623F;min-height:1em}' +
    '.ogc-fb-aim{position:fixed;inset:0;z-index:64;cursor:crosshair;background:rgba(31,31,31,.06)}' +
    '.ogc-fb-aim__tip{position:fixed;left:50%;top:12px;transform:translateX(-50%);z-index:65;padding:10px 16px;border-radius:999px;background:#1f1f1f;color:#e8c98f;font:700 13px/1 var(--ogb-sans,Arial,sans-serif);pointer-events:none}' +
    '.ogc-fb-pin{position:absolute;z-index:61;width:22px;height:22px;margin:-11px 0 0 -11px;border-radius:50%;background:#C0AB85;border:3px solid #1f1f1f;box-shadow:0 0 0 4px rgba(192,171,133,.35);pointer-events:none}' +
    '@media print{.ogc-fb-btn,.ogc-fb,.ogc-fb-pin,.ogc-fb-aim,.ogc-fb-aim__tip{display:none!important}}';
  document.head.appendChild(css);

  const btn = document.createElement('button');
  btn.type = 'button';
  btn.className = 'ogc-fb-btn';
  btn.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 5h16v11H9l-5 4z" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/></svg>Feedback';
  document.body.appendChild(btn);

  const box = document.createElement('section');
  box.className = 'ogc-fb';
  box.hidden = true;
  box.setAttribute('role', 'dialog');
  box.setAttribute('aria-label', 'Feedback');
  document.body.appendChild(box);

  const st = { note: '', pin: null, image: null, sending: false, sent: false };
  let pinEl = null;

  function draw() {
    box.innerHTML =
      '<h2>Feedback</h2>' +
      '<label for="ogc-fb-note">Note</label>' +
      '<textarea id="ogc-fb-note" placeholder="What works, what doesn’t, what’s missing">' + esc(st.note) + '</textarea>' +
      (st.pin ? '<div class="ogc-fb__got"><span>Pointed at ' + esc(st.pin.label ? '“' + st.pin.label + '”' : 'a spot') + '</span><button type="button" class="ogc-fb__x" data-fb="unpin" aria-label="Remove the point">×</button></div>' : '') +
      (st.image ? '<div class="ogc-fb__got"><img src="' + st.image + '" alt=""><span>Picture</span><button type="button" class="ogc-fb__x" data-fb="unpic" aria-label="Remove the picture">×</button></div>' : '') +
      '<div class="ogc-fb__row">' +
        (st.pin ? '' : '<button type="button" class="ogc-fb__chip" data-fb="point" title="Tap the thing on the page you mean">Point to it</button>') +
        (st.image ? '' : '<button type="button" class="ogc-fb__chip" data-fb="pic">Add picture</button>') +
      '</div>' +
      '<input type="file" accept="image/*" hidden data-fb="file">' +
      '<label for="ogc-fb-name">Your name</label>' +
      '<input type="text" id="ogc-fb-name" autocomplete="name" value="' + esc(LS.get('ogc-feedback-name', '')) + '">' +
      '<p class="ogc-fb__status" role="status" aria-live="polite"></p>' +
      '<div class="ogc-fb__foot"><button type="button" class="ogc-fb__cancel" data-fb="close">Cancel</button><button type="button" class="ogc-fb__send" data-fb="send">Send</button></div>';
  }

  function open(focusNote) {
    draw();
    box.hidden = false;
    btn.hidden = true;
    if (focusNote !== false) { const t = box.querySelector('textarea'); if (t) t.focus(); }
  }
  function close() {
    keep();
    box.hidden = true;
    btn.hidden = false;
    if (pinEl) { pinEl.remove(); pinEl = null; }
    btn.focus();
  }
  function keep() {
    const t = box.querySelector('textarea');
    if (t) st.note = t.value;
    const n = box.querySelector('#ogc-fb-name');
    if (n) LS.set('ogc-feedback-name', n.value.trim());
  }
  function say(msg) { const s = box.querySelector('.ogc-fb__status'); if (s) s.textContent = msg; }

  // Point to it: the panel steps aside, the next tap anywhere marks what it was on.
  function aim() {
    keep();
    box.hidden = true;
    const layer = document.createElement('div');
    layer.className = 'ogc-fb-aim';
    const tip = document.createElement('div');
    tip.className = 'ogc-fb-aim__tip';
    tip.textContent = 'Tap what you mean · Esc to cancel';
    document.body.append(layer, tip);
    const done = () => { layer.remove(); tip.remove(); document.removeEventListener('keydown', onKey, true); open(false); };
    const onKey = e => { if (e.key === 'Escape') { e.preventDefault(); done(); } };
    document.addEventListener('keydown', onKey, true);
    layer.addEventListener('click', e => {
      e.preventDefault();
      layer.style.pointerEvents = 'none';
      const el = document.elementFromPoint(e.clientX, e.clientY);
      layer.style.pointerEvents = '';
      const doc = document.documentElement;
      const x = e.clientX + scrollX, y = e.clientY + scrollY;
      st.pin = {
        label: labelOf(el),
        x: Math.round(x / Math.max(doc.scrollWidth, 1) * 100),
        y: Math.round(y / Math.max(doc.scrollHeight, 1) * 100),
        px: x, py: y
      };
      if (pinEl) pinEl.remove();
      pinEl = document.createElement('div');
      pinEl.className = 'ogc-fb-pin';
      pinEl.style.left = x + 'px';
      pinEl.style.top = y + 'px';
      document.body.appendChild(pinEl);
      done();
    });
  }
  // The words of what was tapped: its own label, or the nearest heading-sized bit of text around it.
  function labelOf(el) {
    for (let e = el, i = 0; e && e !== document.body && i < 6; e = e.parentElement, i++) {
      const t = (e.getAttribute && (e.getAttribute('aria-label') || e.getAttribute('title'))) || e.innerText || '';
      const s = t.replace(/\s+/g, ' ').trim();
      if (s) return s.length > 70 ? s.slice(0, 67) + '…' : s;
    }
    return '';
  }

  // A picture is shrunk to at most 1600 px on its long side before it's sent.
  function addPicture(file) {
    if (!file || !/^image\//.test(file.type)) return;
    const img = new Image();
    const url = URL.createObjectURL(file);
    img.onload = () => {
      const k = Math.min(1, 1600 / Math.max(img.width, img.height));
      const c = document.createElement('canvas');
      c.width = Math.round(img.width * k);
      c.height = Math.round(img.height * k);
      c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
      st.image = c.toDataURL('image/jpeg', 0.85);
      URL.revokeObjectURL(url);
      keep();
      open(false);
    };
    img.onerror = () => { URL.revokeObjectURL(url); say('That picture can’t be read'); };
    img.src = url;
  }

  // What the note is about, said by the page itself.
  function context() {
    const q = new URLSearchParams(location.search);
    const asOf = q.get('as-of') || '';
    const home = W.home || '/';
    const path = location.pathname.indexOf(home) === 0 ? '/' + location.pathname.slice(home.length) : location.pathname;
    // The demo pill (ogc-dev-nav.js) says which day is previewed.
    const pill = document.querySelector('[data-ogc-moment]');
    return {
      page: path + location.search,
      moment: (pill && pill.getAttribute('data-ogc-moment')) || asOf,
      as: W.me ? (W.me.name || W.me.email) : 'Visitor',
      screen: innerWidth + '×' + innerHeight
    };
  }

  async function send() {
    keep();
    const name = (LS.get('ogc-feedback-name', '') || '').trim();
    if (!st.note.trim() && !st.image) { say('Add a note or a picture'); const t = box.querySelector('textarea'); if (t) t.focus(); return; }
    const b = box.querySelector('.ogc-fb__send');
    b.disabled = true;
    say('Sending');
    const body = Object.assign({ name, note: st.note.trim(), pin: st.pin ? { label: st.pin.label, x: st.pin.x, y: st.pin.y } : null, image: st.image }, context());
    try {
      if (W.feedback) {
        // Apps Script answers from another address, so the reply can't be read: a sent note is one that left.
        await fetch(W.feedback, { method: 'POST', mode: 'no-cors', headers: { 'Content-Type': 'text/plain;charset=utf-8' }, body: JSON.stringify(body) });
      } else {
        const all = LS.get('ogc-feedback-local', []);
        all.push(Object.assign({ at: new Date().toISOString() }, body, { image: body.image ? '(picture)' : null }));
        LS.set('ogc-feedback-local', all);
      }
      st.note = ''; st.pin = null; st.image = null;
      if (pinEl) { pinEl.remove(); pinEl = null; }
      box.innerHTML = '<h2>Sent</h2><p style="margin:0">Thank you.</p>';
      setTimeout(() => { if (!box.hidden) close(); }, still() ? 2500 : 1800);
    } catch (e) {
      b.disabled = false;
      say('Not sent · Check the connection and try again');
    }
  }

  btn.addEventListener('click', () => open());
  box.addEventListener('click', e => {
    const a = e.target.closest('[data-fb]');
    if (!a) return;
    const k = a.getAttribute('data-fb');
    if (k === 'close') close();
    else if (k === 'send') send();
    else if (k === 'point') aim();
    else if (k === 'pic') { keep(); box.querySelector('[data-fb="file"]').click(); }
    else if (k === 'unpin') { keep(); st.pin = null; if (pinEl) { pinEl.remove(); pinEl = null; } open(false); }
    else if (k === 'unpic') { keep(); st.image = null; open(false); }
  });
  box.addEventListener('change', e => { if (e.target.matches('[data-fb="file"]')) addPicture(e.target.files && e.target.files[0]); });
  box.addEventListener('keydown', e => { if (e.key === 'Escape') { e.preventDefault(); close(); } });
  // A picture pasted while the panel is open (a screenshot on the clipboard) is taken too.
  box.addEventListener('paste', e => {
    const f = [...((e.clipboardData && e.clipboardData.files) || [])].find(x => /^image\//.test(x.type));
    if (f) { e.preventDefault(); addPicture(f); }
  });
})();
