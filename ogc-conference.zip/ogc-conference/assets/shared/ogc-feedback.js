/*
 * ogc-feedback.js — the shared prototype's feedback board (Oct 31, 2026; it replaces the Oct 30 Feedback
 * button). Loaded with ogc-dev-nav.js and ogc-feedback-api.js: the local site and the shared prototype
 * only, never on ogbbc.org. Michael: "a very clear button for somebody who's looking at it, who's not very
 * tech-savvy, to be able to leave feedback… make it clear that it's not part of the interface", "by
 * default it needs to capture the screen", "require their name", and "a public community center for
 * feedback": a count on each screen, a feed others comment on and upvote, all screens in one spot.
 *
 * It draws, in the demo's own look (ogc-dev-nav.js: near-black, the system font, one indigo accent):
 *   - in the dock, beside the demo pill: Leave feedback, and this screen's count of open ideas (only when
 *     there are some here; with none here but some elsewhere, the same place is a plain icon to the board);
 *   - the composer: Leave feedback takes a picture of the screen as the visitor sees it (without our own
 *     controls), then asks for the idea and a name (required, remembered). Point to it: tap the thing you
 *     mean; a pin is drawn on the picture. Retake, Remove. It sends by itself the screen, the page, the day
 *     the pill holds, who's signed in and the screen's size;
 *   - the board: a side sheet on a laptop, the whole screen on a phone. This screen or All screens
 *     (grouped by screen, each idea with Go to screen at its day), Open or Resolved, Top or New. Each idea:
 *     name, time, its picture (tap to enlarge), the words, an upvote (no downvote; a toggle) and replies.
 *     One's own idea or reply has Delete. The ⋯ menu's Admin asks once for the admin key; then every idea
 *     has Resolve or Reopen, and Delete.
 *
 * The store is behind window.OGC_FEEDBACK (ogc-feedback-api.js). With no store (the prototype without a
 * board address), nothing is drawn.
 *
 * The screen an idea is about (its key): the page's path from the site's home, plus only the parameters
 * that choose what the screen is, sorted: view, s, c, v, edit, part, committee, tab, tool, role by their
 * value, and shift by its name only (a shift's sheet is one screen, whichever shift). Everything else is
 * left out (year, as-of, tz, preview, return, id, at, f, from, as, team, pages…), so the same screen on two
 * days, or with another record open beside it, counts once. Examples:
 *   /annual-conference/?year=2027&as-of=2027-03-02T09:00      → annual-conference/
 *   /annual-conference/app/?year=2027&s=shifts&c=food&id=12  → annual-conference/app/?c=food&s=shifts
 *   /annual-conference/volunteer/?committee=food&shift=f-3   → annual-conference/volunteer/?committee=food&shift
 *
 * The picture: html-to-image 1.11.11 from jsDelivr (pinned, with its integrity hash), loaded only when
 * Leave feedback is first pressed. It draws the page from its own styles, so text, shadows and closed
 * folds come out as on screen (html2canvas 1.4.1 moved text and showed closed folds on these pages). The
 * page is drawn at its scroll position, with its fixed bars put back where they are on screen and inner
 * scrolled panels at their scroll. If it can't load (offline, a blocked script) the idea goes without one.
 */
(function () {
  'use strict';
  const W = window.OGC_WP || {};
  if (!W.dev && !W.prototype) return;
  const framed = (() => { try { return window.top !== window && !!(window.parent && window.parent.OGC_WP); } catch (e) { return false; } })();
  if (framed) return;
  const API = window.OGC_FEEDBACK;
  if (!API || !API.mode) return;

  const LIB = 'https://cdn.jsdelivr.net/npm/html-to-image@1.11.11/dist/html-to-image.js';
  const LIB_SRI = 'sha384-UbfRVKN3/elS1r7JcK2FhmPP+KlJ4CvYwbyYD7tH+uTkbT9bNJr9eJeQ0FoFbAgz';
  const SANS = 'system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,sans-serif';
  const home = W.home || '/';
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
  const still = () => !!(window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches);
  const narrow = () => innerWidth < 600;
  const touchy = () => !!(window.matchMedia && matchMedia('(pointer: coarse)').matches);
  const SS = {
    get(k, d) { try { const v = sessionStorage.getItem(k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } },
    set(k, v) { try { sessionStorage.setItem(k, JSON.stringify(v)); } catch (e) { /* not kept */ } }
  };

  /* ------------------------------------------------------------------ the screen an idea is about */

  const BY_VALUE = ['view', 's', 'c', 'v', 'edit', 'part', 'committee', 'tab', 'tool', 'role'];
  const BY_NAME = ['shift'];
  const part = s => String(s).replace(/[^\w\-.%~]/g, c => encodeURIComponent(c).replace(/[!'()*]/g, x => '%' + x.charCodeAt(0).toString(16).toUpperCase()));
  function screenKey(href) {
    const u = new URL(href || location.href, location.href);
    let p = u.pathname.indexOf(home) === 0 ? u.pathname.slice(home.length) : u.pathname.replace(/^\//, '');
    p = p.split('/').map(part).join('/').replace(/\/{2,}/g, '/');
    if (p && !/\/$/.test(p) && !/\.[a-z0-9]{1,5}$/i.test(p)) p += '/';
    const q = [];
    BY_VALUE.forEach(k => { const v = u.searchParams.get(k); if (v) q.push(k + '=' + part(v)); });
    BY_NAME.forEach(k => { if (u.searchParams.get(k)) q.push(k); });
    q.sort();
    return ((p || '/') + (q.length ? '?' + q.join('&') : '')).slice(0, 300);
  }
  // The page's name, without the site's.
  const screenTitle = () => String(document.title || '').split(' – ')[0].replace(/ · \d{4} Conference$/, '').trim().slice(0, 120);
  // This page from the site's home, as it is now ("/annual-conference/register/?year=2027&as-of=…").
  const pagePath = () => { const p = location.pathname; return '/' + (p.indexOf(home) === 0 ? p.slice(home.length) : p.replace(/^\//, '')) + location.search; };
  const dockInfo = () => window.OGC_DOCK || {};
  function context() {
    const d = dockInfo(), m = d.moment || {};
    const at = m.at || (new URLSearchParams(location.search).get('as-of') || '').slice(0, 16);
    return {
      screen: screenKey(), title: screenTitle(), page: pagePath().slice(0, 600),
      at: /^\d{4}-\d\d-\d\dT\d\d:\d\d$/.test(at) ? at : '', moment: m.text && m.text !== 'Today' ? m.text : '',
      as: d.who || (W.me ? (W.me.name || W.me.email) : 'Visitor'), size: innerWidth + '×' + innerHeight
    };
  }

  /* ------------------------------------------------------------------ the look */

  const css =
    // In the dock: this screen's count, then Leave feedback (an indigo pill inside the 44 px tap).
    '.ogc-fb-n{display:inline-flex;align-items:center;justify-content:center;gap:6px;min-width:44px;height:44px;margin:0;padding:0 10px;border:0;border-radius:22px;background:transparent;color:#f4f4f5;font:600 13px/1 ' + SANS + ';cursor:pointer}' +
    '.ogc-fb-n:hover,.ogc-fb-n[aria-expanded=true]{background:rgba(255,255,255,.08)}.ogc-fb-n[hidden]{display:none}' +
    '.ogc-fb-n svg{flex:none;width:16px;height:16px;color:#a5b4fc}' +
    '.ogc-fb-go{display:inline-flex;align-items:center;height:44px;margin:0;padding:0 4px 0 2px;border:0;border-radius:22px;background:transparent;cursor:pointer;font:600 13px/1 ' + SANS + '}' +
    '.ogc-fb-go__in{display:inline-flex;align-items:center;gap:6px;height:36px;padding:0 14px 0 11px;border-radius:18px;background:#4f46e5;color:#fff;white-space:nowrap;box-shadow:inset 0 1px 0 rgba(255,255,255,.16)}' +
    '.ogc-fb-go:hover .ogc-fb-go__in{background:#4338ca}.ogc-fb-go[aria-expanded=true] .ogc-fb-go__in{background:#3730a3}' +
    '.ogc-fb-go svg{flex:none;width:14px;height:14px}.ogc-fb-go__s{display:none}' +
    '.ogc-pill .ogc-fb-go:focus-visible{outline:none}.ogc-fb-go:focus-visible .ogc-fb-go__in{outline:2px solid #c7d2fe;outline-offset:2px}' +
    '@media (max-width:399px){.ogc-fb-go__l{display:none}.ogc-fb-go__s{display:inline}}' +

    // The demo's surfaces: the composer, the board, the toast, the picture enlarged.
    '.ogc-fbx-ui{box-sizing:border-box;color:#f4f4f5;font:400 14px/1.45 ' + SANS + ';letter-spacing:0;text-transform:none;-webkit-font-smoothing:antialiased;text-align:left}' +
    '.ogc-fbx-ui *{box-sizing:border-box}.ogc-fbx-ui[hidden],.ogc-fbx-ui [hidden]{display:none!important}' +
    '.ogc-fbx-ui h2{margin:0;color:#f4f4f5;font:650 16px/1.25 ' + SANS + ';letter-spacing:0}' +
    '.ogc-fbx-ui button{font-family:' + SANS + ';letter-spacing:0;text-transform:none}' +
    '.ogc-fbx-ui :focus-visible{outline:2px solid #a5b4fc;outline-offset:2px}.ogc-fbx-ui :focus:not(:focus-visible){outline:none}' +
    // Buttons: one filled (indigo) a view; quiet ones are words on the dark.
    '.ogc-fbp{display:inline-flex;align-items:center;justify-content:center;gap:6px;min-height:44px;margin:0;padding:0 18px;border:0;border-radius:12px;background:#4f46e5;color:#fff;font-weight:600;font-size:14px;cursor:pointer;white-space:nowrap}' +
    '.ogc-fbp:hover{background:#4338ca}.ogc-fbp:disabled{opacity:.6;cursor:default}' +
    '.ogc-fbp--sm{min-height:36px;padding:0 12px;border-radius:10px;font-size:13px}' +
    '.ogc-fbq{display:inline-flex;align-items:center;justify-content:center;gap:6px;min-height:44px;min-width:44px;margin:0;padding:0 12px;border:0;border-radius:10px;background:transparent;color:#d4d4d8;font-weight:500;font-size:13.5px;cursor:pointer;white-space:nowrap}' +
    '.ogc-fbq:hover{background:rgba(255,255,255,.07);color:#fff}.ogc-fbq svg{flex:none;width:16px;height:16px}' +
    '.ogc-fbq--danger{color:#fca5a5}.ogc-fbq--danger:hover{color:#fecaca;background:rgba(248,113,113,.12)}' +
    '.ogc-fbq--chip{min-height:36px;padding:0 12px;border-radius:999px;background:rgba(255,255,255,.07);color:#e4e4e7;font-size:13px}' +
    '.ogc-fbq--chip:hover{background:rgba(255,255,255,.12)}' +
    // A chip's tap is 44 px: the chip is drawn smaller inside it.
    '.ogc-fbc__tools .ogc-fbq--chip{position:relative}.ogc-fbc__tools .ogc-fbq--chip::after{content:"";position:absolute;left:0;right:0;top:-4px;bottom:-4px}' +
    '.ogc-fbx-ui label{display:block;margin:14px 0 6px;color:#d4d4d8;font-size:13px;font-weight:600}' +
    '.ogc-fbx-ui textarea,.ogc-fbx-ui input[type=text],.ogc-fbx-ui input[type=password]{display:block;width:100%;margin:0;padding:10px 12px;border:1px solid rgba(255,255,255,.14);border-radius:10px;background:#0c0c10;color:#f4f4f5;font:400 16px/1.4 ' + SANS + ';-webkit-appearance:none;appearance:none}' +
    '.ogc-fbx-ui input{min-height:44px}.ogc-fbx-ui textarea{min-height:96px;resize:vertical}' +
    '.ogc-fbx-ui textarea::placeholder,.ogc-fbx-ui input::placeholder{color:#8b8b94}' +
    '.ogc-fbx-ui textarea:focus,.ogc-fbx-ui input:focus{outline:none;border-color:#818cf8;box-shadow:0 0 0 3px rgba(129,140,248,.28)}' +
    '.ogc-fbx-ui [aria-invalid=true]{border-color:#f87171}' +
    '.ogc-fb-err{margin:6px 0 0;color:#fca5a5;font-size:13px}.ogc-fb-err:empty{display:none}' +
    '.ogc-fb-muted{color:#a1a1aa}' +
    '.ogc-fbx{flex:none;display:inline-flex;align-items:center;justify-content:center;width:44px;height:44px;margin:0;padding:0;border:0;border-radius:10px;background:transparent;color:#a1a1aa;cursor:pointer}' +
    '.ogc-fbx:hover{background:rgba(255,255,255,.08);color:#fff}.ogc-fbx svg{width:18px;height:18px}' +

    // The composer: a card above the dock on a laptop, a sheet from the foot on a phone.
    '.ogc-fbc{position:fixed;z-index:2147482000;right:16px;bottom:calc(68px + var(--ogc-pill-lift,0px) + env(safe-area-inset-bottom));width:min(392px,calc(100vw - 32px));max-height:calc(100vh - 92px - var(--ogc-pill-lift,0px));overflow:auto;overscroll-behavior:contain;padding:6px 16px 16px;border-radius:18px;background:#131318;box-shadow:inset 0 0 0 1px rgba(255,255,255,.09),0 24px 60px rgba(12,12,20,.42)}' +
    '.ogc-fbc__head{display:flex;align-items:center;gap:8px;margin:0 -8px 0 0}.ogc-fbc__head h2{flex:1}' +
    '.ogc-fbc__ctx{margin:-6px 0 12px;color:#a1a1aa;font-size:12.5px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}' +
    '.ogc-fbc__shot{position:relative;display:flex;align-items:center;justify-content:center;height:196px;border-radius:12px;background:#0c0c10;box-shadow:inset 0 0 0 1px rgba(255,255,255,.08);overflow:hidden}' +
    '.ogc-fbc__shot img{display:block;max-width:100%;max-height:100%;object-fit:contain}' +
    '.ogc-fbc__ph{color:#a1a1aa;font-size:13px}' +
    '.ogc-fbc__shot--wait{background:linear-gradient(100deg,#0c0c10 30%,#1a1a22 50%,#0c0c10 70%) 0 0/300% 100%}' +
    '.ogc-fbc__tools{display:flex;flex-wrap:wrap;align-items:center;gap:6px;margin:8px 0 0}' +
    '.ogc-fbc__pin{flex:1 1 100%;margin:2px 0 0;color:#a1a1aa;font-size:12.5px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}' +
    '.ogc-fbc__foot{display:flex;align-items:center;justify-content:flex-end;gap:8px;margin:16px 0 0}' +
    '.ogc-fbc__status{flex:1;color:#a1a1aa;font-size:13px}' +
    '@media (max-width:599px){.ogc-fbc{left:0;right:0;bottom:0;width:auto;max-height:92vh;max-height:92dvh;border-radius:20px 20px 0 0;padding-bottom:calc(16px + env(safe-area-inset-bottom))}' +
    'html.ogc-fb-composing .ogc-pill{visibility:hidden}}' +

    // Point to it: the page under a clear layer; the thing under the pointer outlined.
    '.ogc-fba{position:fixed;inset:0;z-index:2147482500;cursor:crosshair;background:rgba(12,12,20,.08);touch-action:pan-x pan-y}' +
    '.ogc-fba__box{position:fixed;z-index:2147482501;pointer-events:none;border:2px solid #6366f1;border-radius:6px;background:rgba(99,102,241,.08);display:none}' +
    '.ogc-fba__tip{position:fixed;left:50%;top:calc(12px + env(safe-area-inset-top));transform:translateX(-50%);z-index:2147482502;display:flex;align-items:center;gap:4px;padding:0 4px 0 16px;border-radius:999px;background:#131318;box-shadow:inset 0 0 0 1px rgba(255,255,255,.09),0 8px 24px rgba(12,12,20,.3);white-space:nowrap}' +
    '.ogc-fba__tip span{font-weight:600;font-size:13.5px}' +

    // The board: a side sheet on a laptop, the whole screen on a phone.
    '.ogc-fbb{position:fixed;inset:0;z-index:2147482000}' +
    '.ogc-fbb__scrim{position:absolute;inset:0;background:rgba(12,12,20,.36)}' +
    '.ogc-fbb__sheet{position:absolute;top:0;right:0;bottom:0;display:flex;flex-direction:column;width:min(480px,100vw);background:#111115;box-shadow:inset 1px 0 0 rgba(255,255,255,.08),-24px 0 60px rgba(12,12,20,.3)}' +
    '@media (max-width:599px){.ogc-fbb__sheet{width:100vw;box-shadow:none}.ogc-fbb__scrim{display:none}}' +
    '.ogc-fbb__head{flex:none;padding:6px 12px 10px 20px;padding-top:calc(6px + env(safe-area-inset-top));border-bottom:1px solid rgba(255,255,255,.08)}' +
    '.ogc-fbb__top{display:flex;align-items:center;gap:4px;min-height:52px}.ogc-fbb__top h2{flex:1;font-size:18px}' +
    '.ogc-fbb__badge{display:inline-block;margin-left:8px;padding:2px 8px;border-radius:999px;background:rgba(99,102,241,.22);color:#c7d2fe;font-size:12px;font-weight:600;vertical-align:2px}' +
    '.ogc-fbb__tabs{display:flex;gap:4px;margin:4px 0 0}' +
    '.ogc-fbb__tab{position:relative;display:inline-flex;align-items:center;gap:6px;min-height:44px;margin:0;padding:0 12px;border:0;border-radius:10px;background:transparent;color:#a1a1aa;font-size:14px;font-weight:600;cursor:pointer}' +
    '.ogc-fbb__tab:hover{color:#f4f4f5;background:rgba(255,255,255,.05)}' +
    '.ogc-fbb__tab[aria-selected=true]{color:#f4f4f5}' +
    '.ogc-fbb__tab[aria-selected=true]::after{content:"";position:absolute;left:12px;right:12px;bottom:2px;height:2px;border-radius:2px;background:#818cf8}' +
    '.ogc-fbb__tab em{font-style:normal;color:#a1a1aa;font-weight:500}' +
    '.ogc-fbb__bar{display:flex;flex-wrap:wrap;align-items:center;justify-content:space-between;gap:8px;margin:8px 0 0}' +
    '.ogc-fbs{display:inline-flex;padding:3px;border-radius:12px;background:rgba(255,255,255,.06)}' +
    '.ogc-fbs button{position:relative;min-height:38px;margin:0;padding:0 12px;border:0;border-radius:9px;background:transparent;color:#a1a1aa;font-size:13px;font-weight:600;cursor:pointer}' +
    '.ogc-fbs button::after{content:"";position:absolute;left:0;right:0;top:-3px;bottom:-3px}' +
    '.ogc-fbs button:hover{color:#f4f4f5}.ogc-fbs button[aria-pressed=true]{background:#2a2a33;color:#f4f4f5;box-shadow:0 1px 2px rgba(0,0,0,.3)}' +
    '.ogc-fbb__body{flex:1;overflow:auto;overscroll-behavior:contain;padding:12px 16px calc(24px + env(safe-area-inset-bottom))}' +
    '.ogc-fbb__line{margin:24px 4px;color:#a1a1aa;font-size:14px;text-align:center}' +
    '.ogc-fbb__where{margin:4px 4px 12px;color:#a1a1aa;font-size:12.5px}' +
    '.ogc-fbb__where b{color:#e4e4e7;font-weight:600}' +
    '.ogc-fbb__group{margin:18px 4px 8px;display:flex;align-items:baseline;gap:8px}.ogc-fbb__group:first-child{margin-top:4px}' +
    '.ogc-fbb__group b{color:#f4f4f5;font-size:13.5px;font-weight:650}.ogc-fbb__group span{color:#8b8b94;font-size:12px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;min-width:0}' +
    '.ogc-fbb__menu{position:absolute;z-index:3;top:52px;right:12px;min-width:180px;padding:6px;border-radius:12px;background:#1c1c22;box-shadow:inset 0 0 0 1px rgba(255,255,255,.1),0 12px 32px rgba(0,0,0,.4)}' +
    '.ogc-fbb__menu button{display:flex;width:100%;justify-content:flex-start}' +
    '.ogc-fbb__admin{margin:0 0 12px;padding:12px 14px 14px;border-radius:14px;background:#1a1a20;box-shadow:inset 0 0 0 1px rgba(255,255,255,.08)}' +
    '.ogc-fbb__admin label{margin-top:0}.ogc-fbb__admin div{display:flex;gap:8px;margin-top:8px}.ogc-fbb__admin input{flex:1}' +
    // One idea.
    '.ogc-fbi{margin:0 0 10px;padding:14px 14px 6px;border-radius:14px;background:#1a1a20;box-shadow:inset 0 0 0 1px rgba(255,255,255,.07)}' +
    '.ogc-fbi--new{box-shadow:inset 0 0 0 1px rgba(129,140,248,.7)}' +
    '.ogc-fbi__top{display:flex;align-items:flex-start;gap:10px}' +
    '.ogc-fb-av{flex:none;display:inline-flex;align-items:center;justify-content:center;width:30px;height:30px;border-radius:50%;color:#fff;font-size:12px;font-weight:700}' +
    '.ogc-fbi__who{flex:1;min-width:0;padding-top:1px}.ogc-fbi__who b{display:block;font-weight:600;font-size:14px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}' +
    '.ogc-fbi__who span{display:block;color:#a1a1aa;font-size:12.5px}' +
    '.ogc-fbi__res{display:inline-block;margin-left:6px;padding:1px 7px;border-radius:999px;background:rgba(52,211,153,.16);color:#6ee7b7;font-size:12px;font-weight:600}' +
    '.ogc-fb-up{flex:none;display:inline-flex;align-items:center;justify-content:center;gap:5px;min-width:52px;height:44px;margin:-6px -4px 0 0;padding:0 12px;border:0;border-radius:12px;background:rgba(255,255,255,.06);color:#d4d4d8;font-size:13.5px;font-weight:650;cursor:pointer}' +
    '.ogc-fb-up:hover{background:rgba(255,255,255,.11);color:#fff}.ogc-fb-up svg{width:14px;height:14px}' +
    '.ogc-fb-up[aria-pressed=true]{background:#4f46e5;color:#fff}.ogc-fb-up[aria-pressed=true]:hover{background:#4338ca}' +
    '.ogc-fbi__pic{display:block;width:100%;margin:12px 0 0;padding:0;border:0;border-radius:10px;background:#0c0c10;overflow:hidden;cursor:zoom-in;box-shadow:inset 0 0 0 1px rgba(255,255,255,.08)}' +
    '.ogc-fbi__pic img{display:block;width:100%;height:auto;max-height:200px;object-fit:cover;object-position:top}' +
    '.ogc-fbi__text{margin:10px 0 0;color:#e4e4e7;font-size:14.5px;line-height:1.5;white-space:pre-wrap;overflow-wrap:anywhere}' +
    '.ogc-fbi__at{margin:6px 0 0;color:#a1a1aa;font-size:12.5px;overflow-wrap:anywhere}' +
    '.ogc-fbi__acts{display:flex;flex-wrap:wrap;align-items:center;gap:2px;margin:6px -8px 0}' +
    '.ogc-fbi__acts .ogc-fbq{min-height:44px;padding:0 10px;font-size:13px;color:#a1a1aa}.ogc-fbi__acts .ogc-fbq:hover{color:#fff}' +
    '.ogc-fbi__acts .ogc-fbq--danger{color:#fca5a5}' +
    '.ogc-fbi__acts .ogc-fbi__sp{flex:1}' +
    '.ogc-fbr{margin:4px 0 0 14px;padding:2px 0 0 14px;border-left:2px solid rgba(255,255,255,.1)}' +
    '.ogc-fbr__one{padding:8px 0 2px}.ogc-fbr__one header{display:flex;align-items:center;gap:6px;font-size:13px}' +
    '.ogc-fbr__one header b{font-weight:600}.ogc-fbr__one header span{color:#a1a1aa}' +
    '.ogc-fbr__one p{margin:2px 0 0;color:#d4d4d8;font-size:14px;line-height:1.45;white-space:pre-wrap;overflow-wrap:anywhere}' +
    '.ogc-fbr__one .ogc-fbq{min-height:44px;margin:0 0 0 auto;padding:0 8px;font-size:12.5px}' +
    '.ogc-fbr__one header .ogc-fbq{margin:-10px -8px -10px auto}' +
    '.ogc-fbr__form{padding:8px 0 10px}.ogc-fbr__form textarea{min-height:72px}.ogc-fbr__form label{margin-top:10px}' +
    '.ogc-fbr__form .ogc-fbc__foot{margin-top:10px}' +

    // A toast: what just happened, with what to do next.
    '.ogc-fbt{position:fixed;left:50%;bottom:calc(72px + var(--ogc-pill-lift,0px) + env(safe-area-inset-bottom));z-index:2147482100;transform:translateX(-50%);display:flex;align-items:center;gap:6px;max-width:calc(100vw - 32px);padding:0 6px 0 16px;border-radius:14px;background:#131318;box-shadow:inset 0 0 0 1px rgba(255,255,255,.09),0 10px 30px rgba(12,12,20,.32)}' +
    '.ogc-fbt span{font-weight:600;padding:12px 0}' +
    // The picture, enlarged.
    '.ogc-fbl{position:fixed;inset:0;z-index:2147482600;display:flex;align-items:center;justify-content:center;padding:56px 16px 16px;background:rgba(8,8,12,.92);cursor:zoom-out}' +
    '.ogc-fbl img{max-width:100%;max-height:100%;border-radius:8px;box-shadow:0 20px 60px rgba(0,0,0,.5)}' +
    '.ogc-fbl .ogc-fbx{position:absolute;top:8px;right:8px;color:#e4e4e7}' +
    '@media (prefers-reduced-motion:no-preference){' +
    '.ogc-fbc{animation:ogc-fb-up .16s ease-out}.ogc-fbb__sheet{animation:ogc-fb-in .2s ease-out}.ogc-fbb__scrim{animation:ogc-fb-fade .2s ease-out}' +
    '.ogc-fbt{animation:ogc-fb-fade .16s ease-out}.ogc-fbc__shot--wait{animation:ogc-fb-wait 1.2s linear infinite}' +
    '@keyframes ogc-fb-up{from{opacity:0;transform:translateY(8px)}}@keyframes ogc-fb-in{from{transform:translateX(24px);opacity:.4}}' +
    '@keyframes ogc-fb-fade{from{opacity:0}}@keyframes ogc-fb-wait{to{background-position:-300% 0}}}' +
    '@media print{.ogc-fbc,.ogc-fbb,.ogc-fbt,.ogc-fbl,.ogc-fba,.ogc-fba__box,.ogc-fba__tip{display:none!important}}';

  const I = {
    talk: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 5.5h14a1.5 1.5 0 0 1 1.5 1.5v8.5A1.5 1.5 0 0 1 19 17h-7.5L7 20.5V17H5a1.5 1.5 0 0 1-1.5-1.5V7A1.5 1.5 0 0 1 5 5.5Z" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/></svg>',
    plus: '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M8 3v10M3 8h10" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>',
    x: '<svg viewBox="0 0 20 20" aria-hidden="true"><path d="m5 5 10 10M15 5 5 15" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>',
    up: '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M8 3.5 13 10H3z" fill="currentColor"/></svg>',
    more: '<svg viewBox="0 0 20 20" aria-hidden="true"><circle cx="4.5" cy="10" r="1.6" fill="currentColor"/><circle cx="10" cy="10" r="1.6" fill="currentColor"/><circle cx="15.5" cy="10" r="1.6" fill="currentColor"/></svg>'
  };

  function ui(tag, cls, html) {
    const el = document.createElement(tag);
    el.className = 'ogc-fbx-ui ' + cls;
    el.setAttribute('data-ogc-tool', '');
    if (html != null) el.innerHTML = html;
    return el;
  }
  const MON = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'June', 'July', 'Aug', 'Sept', 'Oct', 'Nov', 'Dec'];
  function ago(iso) {
    const t = Date.parse(iso || '');
    if (!t) return '';
    const s = (Date.now() - t) / 1000;
    if (s < 60) return 'Just now';
    if (s < 3600) return Math.floor(s / 60) + ' min ago';
    if (s < 86400) return Math.floor(s / 3600) + ' h ago';
    if (s < 172800) return 'Yesterday';
    const d = new Date(t);
    return MON[d.getMonth()] + ' ' + d.getDate() + (d.getFullYear() !== new Date().getFullYear() ? ', ' + d.getFullYear() : '');
  }
  const TONES = ['#4f46e5', '#0e7490', '#b45309', '#be185d', '#047857', '#6d28d9', '#1d4ed8', '#9f1239'];
  function avatar(name) {
    const w = String(name || '?').trim().split(/\s+/).filter(Boolean);
    const ini = ((w[0] || '?').charAt(0) + (w.length > 1 ? w[w.length - 1].charAt(0) : '')).toUpperCase();
    let h = 0;
    for (const c of String(name)) h = (h * 31 + c.charCodeAt(0)) >>> 0;
    return '<span class="ogc-fb-av" style="background:' + TONES[h % TONES.length] + '" aria-hidden="true">' + esc(ini) + '</span>';
  }
  // The day an idea was left on, short: "Mar 2" from "Registration · Mar 2, 2027".
  const dayShort = m => { const x = /· ([A-Z][a-z]+ \d{1,2})/.exec(m || ''); return x ? x[1] : ''; };
  const errWords = code => ({
    name: 'Add your name', text: 'Write your idea', slow: 'Too many at once · Try again in a few minutes', offline: 'Offline · Try again when connected',
    network: 'Couldn’t reach the board · Try again', forbidden: 'Not allowed', not_found: 'That idea is gone', busy: 'Busy · Try again'
  })[code] || 'Something went wrong · Try again';

  /* ------------------------------------------------------------------ the picture of the screen */

  let libP = null;
  function loadLib() {
    if (window.htmlToImage && window.htmlToImage.toSvg) return Promise.resolve(window.htmlToImage);
    if (libP) return libP;
    libP = new Promise((res, rej) => {
      const s = document.createElement('script');
      s.src = LIB;
      s.async = true;
      s.crossOrigin = 'anonymous';
      s.integrity = LIB_SRI;
      s.referrerPolicy = 'no-referrer';
      s.setAttribute('data-ogc-tool', '');
      s.onload = () => (window.htmlToImage && window.htmlToImage.toSvg ? res(window.htmlToImage) : rej(new Error('lib')));
      s.onerror = () => { libP = null; s.remove(); rej(new Error('lib')); };
      document.head.appendChild(s);
    });
    return libP;
  }
  const within = (p, ms) => Promise.race([p, new Promise((res, rej) => setTimeout(() => rej(new Error('timeout')), ms))]);
  const frame = () => new Promise(r => requestAnimationFrame(() => r()));

  // The screen as the visitor sees it now, without our own things: {url (JPEG data URL), w, h, sx, sy, k}.
  async function capture() {
    const H = await within(loadLib(), 12000);
    const de = document.documentElement;
    const w = de.clientWidth || innerWidth, h = innerHeight, sx = scrollX, sy = scrollY;
    // What moves when drawn from the top: fixed things (put back where they are) and scrolled panels.
    const marks = [];
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_ELEMENT, { acceptNode: n => n.hasAttribute('data-ogc-tool') ? NodeFilter.FILTER_REJECT : NodeFilter.FILTER_ACCEPT });
    for (let n = walker.nextNode(); n; n = walker.nextNode()) {
      if ((n.scrollTop || n.scrollLeft) && n !== document.scrollingElement) { n.setAttribute('data-ogc-cap-sc', n.scrollLeft + ',' + n.scrollTop); marks.push(n); }
      if (getComputedStyle(n).position === 'fixed') {
        const r = n.getBoundingClientRect();
        if (r.width && r.height) { n.setAttribute('data-ogc-cap-fx', [r.left + sx, r.top + sy, r.width, r.height].map(v => Math.round(v * 100) / 100).join(',')); marks.push(n); }
      }
    }
    let svg;
    try {
      svg = await within(H.toSvg(de, {
        width: w, height: h, cacheBust: false, skipAutoScale: true,
        imagePlaceholder: 'data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==',
        filter: n => !(n && n.nodeType === 1 && n.hasAttribute && n.hasAttribute('data-ogc-tool')),
        style: { transform: 'translate(' + (-sx) + 'px,' + (-sy) + 'px)', transformOrigin: '0 0' }
      }), 20000);
    } finally {
      marks.forEach(n => { n.removeAttribute('data-ogc-cap-sc'); n.removeAttribute('data-ogc-cap-fx'); });
    }
    const PRE = 'data:image/svg+xml;charset=utf-8,';
    if (svg.indexOf(PRE) === 0 && marks.length) {
      try {
        const doc = new DOMParser().parseFromString(decodeURIComponent(svg.slice(PRE.length)), 'image/svg+xml');
        if (!doc.querySelector('parsererror')) {
          const add = (el, more) => el.setAttribute('style', (el.getAttribute('style') || '') + ';' + more);
          doc.querySelectorAll('[data-ogc-cap-sc]').forEach(el => {
            const [l, t] = el.getAttribute('data-ogc-cap-sc').split(',').map(Number);
            [...el.children].forEach(c => add(c, 'translate:' + (-l) + 'px ' + (-t) + 'px'));
          });
          doc.querySelectorAll('[data-ogc-cap-fx]').forEach(el => {
            const [l, t, ww, hh] = el.getAttribute('data-ogc-cap-fx').split(',').map(Number);
            add(el, 'position:fixed;inset:auto;left:' + l + 'px;top:' + t + 'px;width:' + ww + 'px;height:' + hh + 'px;margin:0;transform:none;translate:none;box-sizing:border-box');
          });
          svg = PRE + encodeURIComponent(new XMLSerializer().serializeToString(doc));
        }
      } catch (e) { /* drawn as the library made it */ }
    }
    const img = new Image();
    img.decoding = 'sync';
    await within(new Promise((res, rej) => { img.onload = res; img.onerror = () => rej(new Error('draw')); img.src = svg; }), 15000);
    // At most 1600 px on its long side.
    const k = Math.min(window.devicePixelRatio || 1, 1600 / Math.max(w, h));
    const c = document.createElement('canvas');
    c.width = Math.round(w * k);
    c.height = Math.round(h * k);
    const g = c.getContext('2d');
    const paint = () => { g.fillStyle = '#fff'; g.fillRect(0, 0, c.width, c.height); g.drawImage(img, 0, 0, c.width, c.height); };
    paint();
    // Safari can paint a picture's own pictures a moment late: once more after two frames.
    await frame(); await frame();
    paint();
    return { url: c.toDataURL('image/jpeg', 0.85), w, h, sx, sy, k };
  }

  // One at a time: a capture marks the page's fixed things while it runs.
  let capQ = Promise.resolve();
  function captureOne() {
    const p = capQ.then(capture, capture);
    capQ = p.catch(() => {});
    return p;
  }

  // The picture with the pin (and an outline round the thing pointed at) drawn on it.
  function withPin(shot, pin) {
    if (!shot || !pin || pin.cx == null) return Promise.resolve(shot ? shot.url : '');
    return new Promise(res => {
      const img = new Image();
      img.onload = () => {
        const c = document.createElement('canvas');
        c.width = img.naturalWidth; c.height = img.naturalHeight;
        const g = c.getContext('2d'), k = c.width / shot.w;
        g.drawImage(img, 0, 0);
        if (pin.box) {
          const [x, y, bw, bh] = pin.box.map(v => v * k);
          g.lineWidth = Math.max(2, 2 * k);
          g.strokeStyle = '#6366f1';
          g.fillStyle = 'rgba(99,102,241,.10)';
          const r = 6 * k;
          g.beginPath();
          if (g.roundRect) g.roundRect(x, y, bw, bh, r); else g.rect(x, y, bw, bh);
          g.fill(); g.stroke();
        }
        const x = pin.cx * k, y = pin.cy * k;
        g.beginPath(); g.arc(x, y, 18 * k, 0, Math.PI * 2); g.fillStyle = 'rgba(79,70,229,.28)'; g.fill();
        g.beginPath(); g.arc(x, y, 10 * k, 0, Math.PI * 2); g.fillStyle = '#4f46e5'; g.fill();
        g.lineWidth = 3 * k; g.strokeStyle = '#fff'; g.stroke();
        res(c.toDataURL('image/jpeg', 0.85));
      };
      img.onerror = () => res(shot.url);
      img.src = shot.url;
    });
  }

  // The words of what was tapped: its own label, or the nearest bit of text around it, as written (not
  // as styled: "Register", not "REGISTER").
  function labelOf(el) {
    for (let e = el, i = 0; e && e !== document.body && i < 6; e = e.parentElement, i++) {
      const t = (e.getAttribute && (e.getAttribute('aria-label') || e.getAttribute('title') || e.getAttribute('alt'))) || e.textContent || '';
      const s = t.replace(/\s+/g, ' ').trim();
      if (s) return s.length > 70 ? s.slice(0, 67) + '…' : s;
    }
    return '';
  }

  /* ------------------------------------------------------------------ the dock's part */

  let dock = null, nBtn = null, goBtn = null, counts = SS.get('ogc-fb-counts', null);
  let here = screenKey();

  function drawCount() {
    if (!nBtn) return;
    const c = (counts && counts.c) || {};
    const n = c[here] || 0, all = Object.keys(c).reduce((a, k) => a + c[k], 0);
    nBtn.hidden = !n && !all;
    nBtn.innerHTML = I.talk + (n ? '<span>' + n + '</span>' : '');
    const say = n ? 'Feedback on this screen · ' + n : 'All feedback';
    nBtn.setAttribute('aria-label', say);
    nBtn.title = say;
    nBtn.dataset.n = String(n);
  }
  let countsP = null;
  function refreshCounts(fresh) {
    if (!fresh && counts && Date.now() - counts.t < 15000) { drawCount(); return Promise.resolve(); }
    if (countsP) return countsP;
    countsP = API.counts().then(c => { counts = { t: Date.now(), c }; SS.set('ogc-fb-counts', counts); drawCount(); }, () => { drawCount(); })
      .then(() => { countsP = null; });
    return countsP;
  }

  function mount(d) {
    dock = d;
    const st = document.createElement('style');
    st.textContent = css;
    document.head.appendChild(st);
    nBtn = document.createElement('button');
    nBtn.type = 'button';
    nBtn.className = 'ogc-fb-n';
    nBtn.hidden = true;
    nBtn.setAttribute('aria-haspopup', 'dialog');
    nBtn.setAttribute('aria-expanded', 'false');
    goBtn = document.createElement('button');
    goBtn.type = 'button';
    goBtn.className = 'ogc-fb-go';
    goBtn.setAttribute('aria-haspopup', 'dialog');
    goBtn.setAttribute('aria-expanded', 'false');
    goBtn.title = 'Leave feedback on this screen';
    goBtn.innerHTML = '<span class="ogc-fb-go__in">' + I.plus + '<span class="ogc-fb-go__l">Leave feedback</span><span class="ogc-fb-go__s">Feedback</span></span>';
    d.slot.append(nBtn, goBtn);
    d.slot.hidden = false;
    drawCount();
    refreshCounts(false);
    nBtn.addEventListener('click', () => { if (board.open) closeBoard(); else openBoard(+nBtn.dataset.n ? 'here' : 'all', nBtn); });
    goBtn.addEventListener('click', () => { if (comp.open) closeComposer(); else openComposer(); });
    // The app changes its address as people move about in it: the count follows the screen.
    const follow = () => { const k = screenKey(); if (k !== here) { here = k; drawCount(); } };
    addEventListener('popstate', follow);
    setInterval(follow, 700);
    document.addEventListener('visibilitychange', () => { if (!document.hidden) refreshCounts(false); });
    if (d.lift) setTimeout(d.lift, 50);
  }

  /* ------------------------------------------------------------------ the composer */

  const comp = { open: false, el: null, shot: null, pin: null, removed: false, busy: false, failed: false, ctx: null, img: '', sending: false, token: 0 };

  function openComposer() {
    closeBoard();
    comp.ctx = context();
    comp.pin = null;
    comp.removed = false;
    comp.failed = false;
    comp.shot = null;
    comp.img = '';
    if (!comp.el) {
      comp.el = ui('section', 'ogc-fbc');
      comp.el.setAttribute('role', 'dialog');
      comp.el.setAttribute('aria-labelledby', 'ogc-fbc-h');
      comp.el.hidden = true;
      document.body.appendChild(comp.el);
      comp.el.addEventListener('click', onComposerClick);
      comp.el.addEventListener('keydown', e => { if (e.key === 'Escape') { e.preventDefault(); closeComposer(true); } else if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) { e.preventDefault(); send(); } });
      comp.el.addEventListener('input', e => { if (e.target.getAttribute('aria-invalid') === 'true') { e.target.removeAttribute('aria-invalid'); const er = comp.el.querySelector('#' + e.target.id + '-e'); if (er) er.textContent = ''; } });
    }
    comp.el.innerHTML = composerHtml();
    comp.el.hidden = false;
    comp.open = true;
    goBtn.setAttribute('aria-expanded', 'true');
    document.documentElement.classList.add('ogc-fb-composing');
    take();
    // On a laptop, straight into the words; on a phone no field takes focus by itself (the keyboard).
    if (!touchy() && !narrow()) comp.el.querySelector('textarea').focus();
    else comp.el.querySelector('h2').focus();
  }
  function closeComposer(back) {
    if (!comp.open) return;
    comp.open = false;
    comp.token++;
    comp.el.hidden = true;
    goBtn.setAttribute('aria-expanded', 'false');
    document.documentElement.classList.remove('ogc-fb-composing');
    if (back !== false) goBtn.focus();
  }
  function composerHtml() {
    const c = comp.ctx || {};
    const ctx = [c.title, dayShort(c.moment), c.as].filter(Boolean).join(' · ');
    return '<header class="ogc-fbc__head"><h2 id="ogc-fbc-h" tabindex="-1">Leave feedback</h2><button type="button" class="ogc-fbx" data-a="close" aria-label="Close">' + I.x + '</button></header>' +
      (ctx ? '<p class="ogc-fbc__ctx" title="Sent with it">' + esc(ctx) + '</p>' : '') +
      '<div class="ogc-fbc__pic"></div>' +
      '<label for="ogc-fbc-t">Your idea</label>' +
      '<textarea id="ogc-fbc-t" rows="4" maxlength="4000" placeholder="What would make this better?" aria-describedby="ogc-fbc-t-e"></textarea>' +
      '<p class="ogc-fb-err" id="ogc-fbc-t-e"></p>' +
      '<label for="ogc-fbc-n">Your name</label>' +
      '<input type="text" id="ogc-fbc-n" maxlength="60" autocomplete="name" value="' + esc(API.name()) + '" aria-describedby="ogc-fbc-n-e">' +
      '<p class="ogc-fb-err" id="ogc-fbc-n-e"></p>' +
      '<div class="ogc-fbc__foot"><span class="ogc-fbc__status" role="status" aria-live="polite"></span><button type="button" class="ogc-fbq" data-a="close">Cancel</button><button type="button" class="ogc-fbp" data-a="send">Send</button></div>';
  }
  // The picture's part of the composer, as things stand.
  function drawPic() {
    if (!comp.el) return;
    const box = comp.el.querySelector('.ogc-fbc__pic');
    if (!box) return;
    const pinLine = comp.pin && comp.pin.label ? '<p class="ogc-fbc__pin">Pointed at “' + esc(comp.pin.label) + '”</p>' : '';
    if (comp.busy) {
      box.innerHTML = '<div class="ogc-fbc__shot ogc-fbc__shot--wait" aria-busy="true"><span class="ogc-fbc__ph">Capturing screen</span></div>';
    } else if (comp.shot && !comp.removed) {
      box.innerHTML = '<div class="ogc-fbc__shot"><img alt="Screenshot of this screen" src="' + esc(comp.img || comp.shot.url) + '"></div>' +
        '<div class="ogc-fbc__tools"><button type="button" class="ogc-fbq ogc-fbq--chip" data-a="point" title="Tap the thing on the page you mean">' + (comp.pin ? 'Point again' : 'Point to it') + '</button>' +
        '<button type="button" class="ogc-fbq ogc-fbq--chip" data-a="retake" title="Take the picture again, as the screen is now">Retake</button>' +
        '<button type="button" class="ogc-fbq ogc-fbq--chip" data-a="unshot">Remove</button>' + pinLine + '</div>';
    } else {
      box.innerHTML = '<div class="ogc-fbc__tools">' + (comp.failed ? '' : '<button type="button" class="ogc-fbq ogc-fbq--chip" data-a="retake">Add screenshot</button>') +
        '<button type="button" class="ogc-fbq ogc-fbq--chip" data-a="point" title="Tap the thing on the page you mean">' + (comp.pin ? 'Point again' : 'Point to it') + '</button>' + pinLine + '</div>';
    }
  }
  async function take(after) {
    const t = ++comp.token;
    comp.busy = true;
    comp.removed = false;
    drawPic();
    let shot = null;
    try { shot = await captureOne(); comp.failed = false; } catch (e) { shot = null; comp.failed = true; }
    if (t !== comp.token) return; // closed, or taken again, meanwhile
    comp.busy = false;
    comp.shot = shot;
    if (after) after();
    comp.img = shot ? await withPin(shot, comp.pin) : '';
    if (t !== comp.token) return;
    drawPic();
  }

  // Point to it: the composer steps aside; the next tap marks what it was on.
  function aim() {
    comp.el.hidden = true;
    document.documentElement.classList.add('ogc-fb-aiming');
    const layer = ui('div', 'ogc-fba');
    const box = ui('div', 'ogc-fba__box');
    const tip = ui('div', 'ogc-fba__tip', '<span>Tap what you mean</span><button type="button" class="ogc-fbq">Cancel</button>');
    tip.setAttribute('role', 'status');
    document.body.append(layer, box, tip);
    const under = (x, y) => {
      layer.style.pointerEvents = 'none'; box.style.display = 'none';
      const el = document.elementFromPoint(x, y);
      layer.style.pointerEvents = '';
      return el && !el.closest('[data-ogc-tool]') ? el : null;
    };
    const target = el => { if (!el) return null; const m = el.closest('a,button,input,select,textarea,label,summary,[role=button],img,svg,h1,h2,h3,h4,li,tr,p') || el; return m === document.body || m === document.documentElement ? null : m; };
    const finish = () => {
      layer.remove(); box.remove(); tip.remove();
      document.removeEventListener('keydown', onKey, true);
      document.documentElement.classList.remove('ogc-fb-aiming');
      if (comp.open) { comp.el.hidden = false; const p = comp.el.querySelector('[data-a="point"]'); (p || comp.el.querySelector('h2')).focus(); }
    };
    const onKey = e => { if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); finish(); } };
    document.addEventListener('keydown', onKey, true);
    tip.querySelector('button').addEventListener('click', finish);
    layer.addEventListener('pointermove', e => {
      if (e.pointerType !== 'mouse') return;
      const el = target(under(e.clientX, e.clientY));
      if (!el) { box.style.display = 'none'; return; }
      const r = el.getBoundingClientRect();
      Object.assign(box.style, { display: 'block', left: (r.left - 3) + 'px', top: (r.top - 3) + 'px', width: (r.width + 6) + 'px', height: (r.height + 6) + 'px' });
    });
    layer.addEventListener('click', async e => {
      e.preventDefault();
      const el = target(under(e.clientX, e.clientY));
      const r = el ? el.getBoundingClientRect() : null;
      const pin = { label: labelOf(el || under(e.clientX, e.clientY)), px: e.clientX + scrollX, py: e.clientY + scrollY, box: r ? [r.left + scrollX, r.top + scrollY, r.width, r.height] : null };
      finish();
      setPin(pin);
    });
  }
  // A pin at a place on the page: on the picture when the picture holds it, else the picture again first.
  function setPin(p) {
    const fit = s => s && p.px >= s.sx && p.px <= s.sx + s.w && p.py >= s.sy && p.py <= s.sy + s.h;
    const place = () => {
      const s = comp.shot && !comp.removed ? comp.shot : null;
      const ox = s ? s.sx : scrollX, oy = s ? s.sy : scrollY, w = s ? s.w : innerWidth, h = s ? s.h : innerHeight;
      comp.pin = {
        label: p.label, cx: p.px - ox, cy: p.py - oy,
        box: p.box ? [p.box[0] - ox, p.box[1] - oy, p.box[2], p.box[3]] : null,
        x: Math.round((p.px - ox) / w * 1000) / 10, y: Math.round((p.py - oy) / h * 1000) / 10
      };
    };
    if (comp.shot && !comp.removed && !fit(comp.shot)) { take(place); return; }
    place();
    if (comp.shot && !comp.removed) withPin(comp.shot, comp.pin).then(u => { comp.img = u; drawPic(); });
    else drawPic();
  }

  function onComposerClick(e) {
    const b = e.target.closest('[data-a]');
    if (!b) return;
    const a = b.getAttribute('data-a');
    if (a === 'close') closeComposer();
    else if (a === 'send') send();
    else if (a === 'point') aim();
    else if (a === 'retake') take();
    else if (a === 'unshot') { comp.removed = true; comp.img = ''; drawPic(); const p = comp.el.querySelector('[data-a="point"]'); if (p) p.focus(); }
  }
  function fieldError(id, msg) {
    const f = comp.el.querySelector('#' + id), er = comp.el.querySelector('#' + id + '-e');
    if (er) er.textContent = msg;
    if (f) { f.setAttribute('aria-invalid', msg ? 'true' : 'false'); if (msg) f.focus(); }
  }
  async function send() {
    if (comp.sending) return;
    const t = comp.el.querySelector('#ogc-fbc-t'), n = comp.el.querySelector('#ogc-fbc-n'), status = comp.el.querySelector('.ogc-fbc__status');
    const text = t.value.trim(), name = n.value.trim();
    fieldError('ogc-fbc-n', name ? '' : 'Add your name');
    fieldError('ogc-fbc-t', text ? '' : 'Write your idea');
    if (!text) { t.focus(); return; }
    if (!name) { n.focus(); return; }
    API.setName(name);
    const sendBtn = comp.el.querySelector('[data-a="send"]');
    comp.sending = true;
    sendBtn.disabled = true;
    status.textContent = comp.busy ? 'Waiting for the picture' : 'Sending';
    // A picture still being taken: wait for it (at most a few seconds).
    for (let i = 0; comp.busy && i < 60; i++) await new Promise(r => setTimeout(r, 100));
    status.textContent = 'Sending';
    const c = comp.ctx || context();
    const pin = comp.pin ? { x: comp.pin.x, y: comp.pin.y, label: comp.pin.label } : null;
    const image = comp.shot && !comp.removed ? (comp.img || comp.shot.url) : '';
    const fields = { name, text, screen: c.screen, title: c.title, page: c.page, at: c.at, moment: c.moment, as: c.as, size: c.size, pin, image };
    let item = null, err = null;
    try { item = await API.add(fields); } catch (e) { err = e; }
    // A picture the store won't take: the idea goes without it.
    if (err && err.code === 'image' && image) { try { item = await API.add(Object.assign({}, fields, { image: '' })); err = null; } catch (e) { err = e; } }
    comp.sending = false;
    sendBtn.disabled = false;
    if (err) {
      if (err.code === 'name') fieldError('ogc-fbc-n', errWords('name'));
      else if (err.code === 'text') fieldError('ogc-fbc-t', errWords('text'));
      status.textContent = err.code === 'name' || err.code === 'text' ? '' : errWords(err.code);
      return;
    }
    closeComposer(false);
    lastNew = item ? item.id : '';
    refreshCounts(true);
    toast('Sent', 'View', () => openBoard('here', goBtn));
    goBtn.focus();
  }

  /* ------------------------------------------------------------------ the toast */

  let toastEl = null, toastT = 0;
  function toast(words, act, fn) {
    if (!toastEl) {
      toastEl = ui('div', 'ogc-fbt');
      toastEl.setAttribute('role', 'status');
      document.body.appendChild(toastEl);
    }
    toastEl.innerHTML = '<span>' + esc(words) + '</span>' + (act ? '<button type="button" class="ogc-fbq">' + esc(act) + '</button>' : '');
    toastEl.hidden = false;
    const b = toastEl.querySelector('button');
    if (b) b.addEventListener('click', () => { toastEl.hidden = true; fn(); });
    clearTimeout(toastT);
    toastT = setTimeout(() => { toastEl.hidden = true; }, 6000);
  }

  /* ------------------------------------------------------------------ the board */

  const board = { open: false, el: null, tab: 'here', filter: SS.get('ogc-fb-filter', 'open'), sort: SS.get('ogc-fb-sort', 'top'), items: null, admin: false, err: '', loading: false, reply: {}, confirm: '', menu: false, keyForm: false, keyErr: '', from: null, token: 0, key: '' };
  let lastNew = '';

  function openBoard(tab, from) {
    closeComposer(false);
    board.tab = tab || 'here';
    board.from = from || null;
    board.items = null;
    board.err = '';
    board.menu = false;
    board.keyForm = false;
    board.confirm = '';
    board.key = here;
    if (!board.el) {
      board.el = ui('div', 'ogc-fbb');
      board.el.hidden = true;
      document.body.appendChild(board.el);
      board.el.addEventListener('click', onBoardClick);
      board.el.addEventListener('keydown', onBoardKey);
      board.el.addEventListener('submit', e => e.preventDefault());
    }
    board.open = true;
    board.el.hidden = false;
    nBtn.setAttribute('aria-expanded', 'true');
    document.documentElement.style.overflow = 'hidden';
    drawBoard();
    board.el.querySelector('h2').focus();
    load();
  }
  function closeBoard() {
    if (!board.open) return;
    board.open = false;
    board.token++;
    board.el.hidden = true;
    nBtn.setAttribute('aria-expanded', 'false');
    document.documentElement.style.overflow = '';
    lastNew = '';
    const f = board.from;
    board.from = null;
    if (f && document.contains(f) && !f.hidden) f.focus();
    refreshCounts(true);
  }
  function load() {
    const t = ++board.token;
    board.loading = true;
    board.err = '';
    drawBody();
    API.list(board.tab === 'all' ? '*' : board.key).then(r => {
      if (t !== board.token) return;
      board.items = r.items;
      board.admin = r.admin;
      board.loading = false;
      drawBoard();
    }, e => {
      if (t !== board.token) return;
      board.loading = false;
      board.err = e.code || 'server';
      drawBody();
    });
  }
  // The control that has the focus, as a selector that finds it again after the board is drawn anew.
  function focusKey() {
    const el = document.activeElement;
    if (!el || !board.el || !board.el.contains(el)) return '';
    if (el.id) return '#' + CSS.escape(el.id);
    if (el.tagName === 'H2') return 'h2';
    const a = el.getAttribute('data-a');
    if (!a) return '';
    let s = '[data-a="' + a + '"]';
    ['data-id', 'data-v'].forEach(k => { const v = el.getAttribute(k); if (v) s += '[' + k + '="' + CSS.escape(v) + '"]'; });
    return s;
  }
  function refocus(k) {
    if (!k || (document.activeElement && board.el.contains(document.activeElement) && document.activeElement !== document.body)) return;
    const n = board.el.querySelector(k);
    if (n) n.focus({ preventScroll: true });
  }
  function drawBoard() {
    if (!board.el) return;
    const fk = focusKey();
    const c = (counts && counts.c) || {};
    const nHere = c[board.key] || 0, nAll = Object.keys(c).reduce((a, k) => a + c[k], 0);
    const tab = (id, words, n) => '<button type="button" role="tab" class="ogc-fbb__tab" data-a="tab" data-v="' + id + '" aria-selected="' + (board.tab === id) + '" aria-controls="ogc-fbb-body">' + words + (n ? ' <em>' + n + '</em>' : '') + '</button>';
    const seg = (name, list, cur, label) => '<div class="ogc-fbs" role="group" aria-label="' + label + '">' + list.map(x => '<button type="button" data-a="' + name + '" data-v="' + x[0] + '" aria-pressed="' + (cur === x[0]) + '">' + x[1] + '</button>').join('') + '</div>';
    board.el.innerHTML =
      '<div class="ogc-fbb__scrim" data-a="close"></div>' +
      '<section class="ogc-fbb__sheet" role="dialog" aria-modal="true" aria-labelledby="ogc-fbb-h">' +
      '<header class="ogc-fbb__head"><div class="ogc-fbb__top"><h2 id="ogc-fbb-h" tabindex="-1">Feedback' + (board.admin ? '<span class="ogc-fbb__badge">Admin</span>' : '') + '</h2>' +
      '<button type="button" class="ogc-fbp ogc-fbp--sm" data-a="new">' + I.plus + 'Leave feedback</button>' +
      '<button type="button" class="ogc-fbx" data-a="menu" aria-haspopup="true" aria-expanded="' + board.menu + '" aria-label="More">' + I.more + '</button>' +
      '<button type="button" class="ogc-fbx" data-a="close" aria-label="Close">' + I.x + '</button></div>' +
      (board.menu ? '<div class="ogc-fbb__menu" role="menu">' + (board.admin ? '<button type="button" role="menuitem" class="ogc-fbq" data-a="unadmin">Exit admin</button>' : '<button type="button" role="menuitem" class="ogc-fbq" data-a="admin">Admin</button>') + '</div>' : '') +
      '<div class="ogc-fbb__tabs" role="tablist" aria-label="Which screens">' + tab('here', 'This screen', nHere) + tab('all', 'All screens', nAll) + '</div>' +
      '<div class="ogc-fbb__bar">' + seg('filter', [['open', 'Open'], ['resolved', 'Resolved']], board.filter, 'Show') + seg('sort', [['top', 'Top'], ['new', 'New']], board.sort, 'Sort') + '</div></header>' +
      '<div class="ogc-fbb__body" id="ogc-fbb-body" role="tabpanel"></div></section>';
    drawBody();
    refocus(fk);
  }
  function drawBody() {
    const body = board.el && board.el.querySelector('.ogc-fbb__body');
    if (!body) return;
    const keep = body.scrollTop, fk = focusKey();
    let h = '';
    if (board.keyForm) {
      h += '<form class="ogc-fbb__admin" data-a="keyform"><label for="ogc-fbb-key">Admin key</label><div><input type="password" id="ogc-fbb-key" autocomplete="off" spellcheck="false" aria-describedby="ogc-fbb-key-e"' + (board.keyErr ? ' aria-invalid="true"' : '') + '>' +
        '<button type="submit" class="ogc-fbp ogc-fbp--sm" data-a="unlock">Unlock</button><button type="button" class="ogc-fbq" data-a="nokey">Cancel</button></div><p class="ogc-fb-err" id="ogc-fbb-key-e">' + esc(board.keyErr) + '</p></form>';
    }
    if (board.tab === 'here') {
      const t = (board.items || []).find(x => x.title) || {};
      const title = (board.key === here ? screenTitle() : t.title) || board.key;
      h += '<p class="ogc-fbb__where"><b>' + esc(title) + '</b></p>';
    }
    if (board.loading && !board.items) h += '<p class="ogc-fbb__line" role="status">Loading</p>';
    else if (board.err) h += '<p class="ogc-fbb__line" role="status">' + esc(errWords(board.err)) + '</p><p style="text-align:center;margin:0"><button type="button" class="ogc-fbq ogc-fbq--chip" data-a="reload">Try again</button></p>';
    else {
      const list = (board.items || []).filter(x => x.status === board.filter);
      const order = (a, b) => board.sort === 'top' ? (b.votes - a.votes) || (a.created < b.created ? 1 : -1) : (a.created < b.created ? 1 : -1);
      list.sort(order);
      if (!list.length) {
        h += '<p class="ogc-fbb__line">' + (board.filter === 'resolved' ? 'Nothing resolved yet' : board.tab === 'here' ? 'No feedback on this screen yet' : 'No feedback yet') + '</p>';
      } else if (board.tab === 'all') {
        const groups = [];
        list.forEach(x => { let g = groups.find(y => y.key === x.screen); if (!g) groups.push(g = { key: x.screen, items: [] }); g.items.push(x); });
        groups.forEach(g => { g.title = (g.items.find(x => x.title) || {}).title || g.key; });
        groups.forEach(g => {
          const twin = groups.some(o => o !== g && o.title === g.title);
          const note = g.key === here ? 'This screen' : twin ? g.key : '';
          h += '<div class="ogc-fbb__group"><b>' + esc(g.title) + '</b>' + (note ? '<span>' + esc(note) + '</span>' : '') + '</div>' + g.items.map(x => idea(x, true)).join('');
        });
      } else h += list.map(x => idea(x, false)).join('');
    }
    body.innerHTML = h;
    body.scrollTop = keep;
    refocus(fk);
  }
  function idea(x, all) {
    const del = x.mine || board.admin;
    // Under the words: the day and person the pill held (as the pill says them), and what was pointed at.
    const seen = [dayShort(x.moment), x.as, x.pin && x.pin.label ? 'Pointed at “' + x.pin.label + '”' : ''].filter(Boolean).join(' · ');
    const conf = board.confirm === 'i:' + x.id;
    const replies = x.comments.map(c => {
      const cc = board.confirm === 'c:' + c.id;
      return '<div class="ogc-fbr__one"><header><b>' + esc(c.name) + '</b><span>' + esc(ago(c.created)) + '</span>' +
        (c.mine || board.admin ? '<button type="button" class="ogc-fbq' + (cc ? ' ogc-fbq--danger' : '') + '" data-a="delc" data-id="' + esc(c.id) + '" data-item="' + esc(x.id) + '">' + (cc ? 'Confirm delete' : 'Delete') + '</button>' : '') +
        '</header><p>' + esc(c.text) + '</p></div>';
    }).join('');
    const form = board.reply[x.id] ? replyForm(x.id) : '';
    return '<article class="ogc-fbi' + (x.id === lastNew ? ' ogc-fbi--new' : '') + '" data-id="' + esc(x.id) + '">' +
      '<div class="ogc-fbi__top">' + avatar(x.name) + '<div class="ogc-fbi__who"><b>' + esc(x.name) + '</b><span>' + esc(ago(x.created)) + (x.status === 'resolved' ? '<span class="ogc-fbi__res">Resolved</span>' : '') + '</span></div>' +
      '<button type="button" class="ogc-fb-up" data-a="vote" data-id="' + esc(x.id) + '" aria-pressed="' + x.voted + '" aria-label="Upvote' + (x.votes ? ', ' + x.votes : '') + '" title="' + (x.voted ? 'Upvoted' : 'Upvote') + '">' + I.up + (x.votes ? '<span>' + x.votes + '</span>' : '') + '</button></div>' +
      (x.thumb ? '<button type="button" class="ogc-fbi__pic" data-a="pic" data-src="' + esc(x.image || x.thumb) + '" aria-label="Enlarge the screenshot"><img src="' + esc(x.thumb) + '" alt="" loading="lazy" decoding="async"></button>' : '') +
      '<p class="ogc-fbi__text">' + esc(x.text) + '</p>' +
      (seen ? '<p class="ogc-fbi__at">' + esc(seen) + '</p>' : '') +
      '<div class="ogc-fbi__acts"><button type="button" class="ogc-fbq" data-a="reply" data-id="' + esc(x.id) + '" aria-expanded="' + !!board.reply[x.id] + '">Reply</button>' +
      (all && x.page ? '<button type="button" class="ogc-fbq" data-a="goto" data-id="' + esc(x.id) + '">Go to screen</button>' : '') +
      '<span class="ogc-fbi__sp"></span>' +
      (board.admin ? '<button type="button" class="ogc-fbq" data-a="' + (x.status === 'resolved' ? 'reopen' : 'resolve') + '" data-id="' + esc(x.id) + '">' + (x.status === 'resolved' ? 'Reopen' : 'Resolve') + '</button>' : '') +
      (del ? '<button type="button" class="ogc-fbq' + (conf ? ' ogc-fbq--danger' : '') + '" data-a="deli" data-id="' + esc(x.id) + '">' + (conf ? 'Confirm delete' : 'Delete') + '</button>' : '') +
      '</div>' + (replies || form ? '<div class="ogc-fbr">' + replies + form + '</div>' : '') + '</article>';
  }
  function replyForm(id) {
    const r = board.reply[id] || {};
    return '<form class="ogc-fbr__form" data-a="replyform" data-id="' + esc(id) + '">' +
      '<label for="ogc-fbr-t-' + esc(id) + '">Your reply</label><textarea id="ogc-fbr-t-' + esc(id) + '" rows="3" maxlength="2000" aria-describedby="ogc-fbr-t-' + esc(id) + '-e">' + esc(r.text || '') + '</textarea>' +
      '<p class="ogc-fb-err" id="ogc-fbr-t-' + esc(id) + '-e">' + esc(r.tErr || '') + '</p>' +
      '<label for="ogc-fbr-n-' + esc(id) + '">Your name</label><input type="text" id="ogc-fbr-n-' + esc(id) + '" maxlength="60" autocomplete="name" value="' + esc(r.name != null ? r.name : API.name()) + '" aria-describedby="ogc-fbr-n-' + esc(id) + '-e">' +
      '<p class="ogc-fb-err" id="ogc-fbr-n-' + esc(id) + '-e">' + esc(r.nErr || '') + '</p>' +
      '<div class="ogc-fbc__foot"><span class="ogc-fbc__status" role="status">' + esc(r.status || '') + '</span><button type="button" class="ogc-fbq" data-a="noreply" data-id="' + esc(id) + '">Cancel</button><button type="submit" class="ogc-fbp ogc-fbp--sm" data-a="sendreply" data-id="' + esc(id) + '">Reply</button></div></form>';
  }
  const find = id => (board.items || []).find(x => x.id === id);
  // Keep what's typed in an open reply before drawing again.
  function keepReplies() {
    Object.keys(board.reply).forEach(id => {
      const t = board.el.querySelector('#ogc-fbr-t-' + CSS.escape(id)), n = board.el.querySelector('#ogc-fbr-n-' + CSS.escape(id));
      if (t) board.reply[id].text = t.value;
      if (n) board.reply[id].name = n.value;
    });
  }
  const redraw = () => { keepReplies(); drawBody(); };
  const focusIn = sel => { const el = board.el.querySelector(sel); if (el) el.focus(); };

  async function onBoardClick(e) {
    const b = e.target.closest('[data-a]');
    if (!b || b.tagName === 'FORM') { if (board.menu && !e.target.closest('.ogc-fbb__menu')) { board.menu = false; keepReplies(); drawBoard(); } return; }
    const a = b.getAttribute('data-a'), id = b.getAttribute('data-id') || '';
    if (a !== 'menu' && board.menu) { board.menu = false; }
    if (a !== 'deli' && a !== 'delc') board.confirm = '';
    if (a === 'close') return closeBoard();
    if (a === 'new') { closeBoard(); return openComposer(); }
    if (a === 'menu') { board.menu = !board.menu; keepReplies(); drawBoard(); return focusIn(board.menu ? '.ogc-fbb__menu button' : '[data-a="menu"]'); }
    if (a === 'admin') { board.keyForm = true; board.keyErr = ''; keepReplies(); drawBoard(); return focusIn('#ogc-fbb-key'); }
    if (a === 'unadmin') { API.setAdminKey(''); board.admin = false; keepReplies(); drawBoard(); return focusIn('h2'); }
    if (a === 'nokey') { board.keyForm = false; redraw(); return focusIn('[data-a="menu"]'); }
    if (a === 'unlock') { e.preventDefault(); return unlock(); }
    if (a === 'tab') { board.tab = b.getAttribute('data-v'); board.items = null; drawBoard(); focusIn('[data-a="tab"][aria-selected="true"]'); return load(); }
    if (a === 'filter' || a === 'sort') { board[a] = b.getAttribute('data-v'); SS.set('ogc-fb-' + a, board[a]); keepReplies(); drawBoard(); return focusIn('[data-a="' + a + '"][aria-pressed="true"]'); }
    if (a === 'reload') return load();
    if (a === 'pic') return enlarge(b.getAttribute('data-src'), b);
    if (a === 'goto') { const x = find(id); if (x && dockInfo().travel) dockInfo().travel(x.page, x.at, x.as); else if (x) location.href = home.replace(/\/$/, '') + x.page; return; }
    if (a === 'reply') { if (board.reply[id]) delete board.reply[id]; else board.reply[id] = {}; redraw(); return focusIn(board.reply[id] ? '#ogc-fbr-t-' + CSS.escape(id) : '[data-a="reply"][data-id="' + CSS.escape(id) + '"]'); }
    if (a === 'noreply') { delete board.reply[id]; redraw(); return focusIn('[data-a="reply"][data-id="' + CSS.escape(id) + '"]'); }
    if (a === 'sendreply') { e.preventDefault(); return reply(id); }
    if (a === 'vote') {
      const x = find(id);
      if (!x) return;
      // Shown at once; put back if the store says no.
      const was = { votes: x.votes, voted: x.voted };
      x.voted = !x.voted; x.votes = Math.max(0, x.votes + (x.voted ? 1 : -1));
      redraw(); focusIn('[data-a="vote"][data-id="' + CSS.escape(id) + '"]');
      try { const r = await API.vote(id); x.votes = r.votes; x.voted = r.voted; } catch (er) { Object.assign(x, was); toast(errWords(er.code)); }
      redraw(); return focusIn('[data-a="vote"][data-id="' + CSS.escape(id) + '"]');
    }
    if (a === 'deli' || a === 'delc') {
      const k = (a === 'deli' ? 'i:' : 'c:') + id;
      if (board.confirm !== k) { board.confirm = k; redraw(); return focusIn('[data-a="' + a + '"][data-id="' + CSS.escape(id) + '"]'); }
      board.confirm = '';
      try {
        if (a === 'deli') { await API.removeItem(id); board.items = board.items.filter(x => x.id !== id); refreshCounts(true).then(() => { if (board.open) { keepReplies(); drawBoard(); } }); }
        else { await API.removeComment(id); const x = find(b.getAttribute('data-item')); if (x) x.comments = x.comments.filter(c => c.id !== id); }
        toast('Deleted');
      } catch (er) { toast(errWords(er.code)); }
      redraw(); return focusIn('h2');
    }
    if (a === 'resolve' || a === 'reopen') {
      try {
        const st = await API[a](id);
        const x = find(id);
        if (x) x.status = st;
        toast(a === 'resolve' ? 'Resolved' : 'Reopened');
        refreshCounts(true).then(() => { if (board.open) { keepReplies(); drawBoard(); } });
      } catch (er) { toast(errWords(er.code)); }
      redraw(); return focusIn('h2');
    }
  }
  async function unlock() {
    const f = board.el.querySelector('#ogc-fbb-key');
    const k = f ? f.value.trim() : '';
    if (!k) { board.keyErr = 'Type the admin key'; redraw(); return focusIn('#ogc-fbb-key'); }
    let ok = false;
    try { ok = await API.checkAdmin(k); } catch (er) { board.keyErr = errWords(er.code); redraw(); return focusIn('#ogc-fbb-key'); }
    if (!ok) { board.keyErr = 'Not the admin key'; redraw(); return focusIn('#ogc-fbb-key'); }
    board.keyForm = false;
    board.keyErr = '';
    board.admin = true;
    keepReplies();
    drawBoard();
    focusIn('h2');
    load();
  }
  async function reply(id) {
    keepReplies();
    const r = board.reply[id];
    if (!r) return;
    const text = String(r.text || '').trim(), name = String(r.name != null ? r.name : API.name()).trim();
    r.tErr = text ? '' : 'Write your reply';
    r.nErr = name ? '' : 'Add your name';
    if (!text || !name) { redraw(); return focusIn('#ogc-fbr-' + (!text ? 't' : 'n') + '-' + CSS.escape(id)); }
    API.setName(name);
    r.status = 'Sending';
    redraw();
    try {
      const c = await API.comment(id, name, text);
      const x = find(id);
      if (x) x.comments.push(c);
      delete board.reply[id];
      redraw();
      focusIn('[data-a="reply"][data-id="' + CSS.escape(id) + '"]');
    } catch (er) {
      r.status = '';
      if (er.code === 'name') r.nErr = errWords('name'); else if (er.code === 'text') r.tErr = 'Write your reply'; else r.status = errWords(er.code);
      redraw();
    }
  }
  function onBoardKey(e) {
    if (e.key === 'Escape') {
      e.preventDefault();
      if (board.menu) { board.menu = false; keepReplies(); drawBoard(); return focusIn('[data-a="menu"]'); }
      return closeBoard();
    }
    if (e.key === 'Enter' && e.target.matches('#ogc-fbb-key')) { e.preventDefault(); return unlock(); }
    if (e.key === 'Enter' && (e.metaKey || e.ctrlKey) && e.target.closest('.ogc-fbr__form')) { e.preventDefault(); return reply(e.target.closest('.ogc-fbr__form').getAttribute('data-id')); }
    // Tab stays inside the board.
    if (e.key === 'Tab') {
      const f = [...board.el.querySelectorAll('button, input, textarea, [tabindex="0"], h2[tabindex]')].filter(x => x.getClientRects().length && !x.disabled);
      if (!f.length) return;
      const i = f.indexOf(document.activeElement);
      if (e.shiftKey && i <= 0) { e.preventDefault(); f[f.length - 1].focus(); } else if (!e.shiftKey && i === f.length - 1) { e.preventDefault(); f[0].focus(); }
    }
  }
  function enlarge(src, from) {
    if (!src) return;
    const l = ui('div', 'ogc-fbl', '<button type="button" class="ogc-fbx" aria-label="Close">' + I.x + '</button><img alt="Screenshot" src="' + esc(src) + '">');
    l.setAttribute('role', 'dialog');
    l.setAttribute('aria-modal', 'true');
    l.setAttribute('aria-label', 'Screenshot');
    document.body.appendChild(l);
    const done = () => { l.remove(); document.removeEventListener('keydown', key, true); if (from && document.contains(from)) from.focus(); };
    const key = ev => { if (ev.key === 'Escape') { ev.preventDefault(); ev.stopPropagation(); done(); } else if (ev.key === 'Tab') { ev.preventDefault(); l.querySelector('button').focus(); } };
    document.addEventListener('keydown', key, true);
    l.addEventListener('click', done);
    l.querySelector('button').focus();
  }

  /* ------------------------------------------------------------------ start */

  // For the tests: the screen key rule, as the board uses it.
  window.OGC_FEEDBACK.screenKey = screenKey;
  const start = () => { if (!dock && window.OGC_DOCK) mount(window.OGC_DOCK); };
  if (window.OGC_DOCK) start(); else document.addEventListener('ogc-dock', start, { once: true });
})();
