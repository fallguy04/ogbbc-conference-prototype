/*
 * ogc-feedback.js — the shared prototype's feedback board (Oct 31, 2026; it replaces the Oct 30 Feedback
 * button). Loaded with ogc-dev-nav.js and ogc-feedback-api.js: the local site and the shared prototype
 * only, never on ogbbc.org. Michael: "a very clear button for somebody who's looking at it, who's not very
 * tech-savvy, to be able to leave feedback… make it clear that it's not part of the interface", "by
 * default it needs to capture the screen", "require their name", and "a public community center for
 * feedback": a count on each screen, a feed others comment on and upvote, all screens in one spot.
 *
 * It draws, in the demo's own look (ogc-dev-nav.js: near-black, the system font, white for the one action):
 *   - in the dock, beside the demo pill: Leave feedback, and this screen's count of open ideas (only when
 *     there are some here; with none here but some elsewhere, the same place is a plain icon to the board);
 *   - the composer: Leave feedback takes a picture of the screen as the visitor sees it (without our own
 *     controls), then asks for the idea and a name (required, remembered). Point to it: tap the thing you
 *     mean; a pin is drawn on the picture. Retake, Remove. It sends by itself the screen, the page, the day
 *     the pill holds, who's signed in and the screen's size;
 *   - the board (Oct 31, evening; Michael: "more of an immersive full screen thing… each screen you can see
 *     kind of a list of feedback by person… what kind of feedback was left on this screen?"): the whole
 *     screen. On a laptop three panes: Screens (each screen's plain name and its count; this screen chosen
 *     first and marked), the chosen screen's ideas grouped by person (the name and their count, then their
 *     ideas in the order they left them, each one compact row: a thumbnail cropped around the pin, the words,
 *     upvotes and replies when there are some, the day and device), and the chosen idea in full (the
 *     picture, the words, the day, person, device and what was pointed at, upvote, Reply and the thread, Go
 *     to screen, Delete, Resolve or Reopen). On a phone one pane at a time, with Back. Open or Resolved.
 *     The arrows or J/K move between ideas, Enter opens one, Escape closes (on a phone it steps back). One's
 *     own idea or reply has Delete. The ⋯ menu's Admin asks once for the admin key; then every idea has
 *     Resolve or Reopen, and Delete.
 *
 * Over a pop-up: everything here draws into the dock's root (OGC_DOCK.root, ogc-dev-nav.js), which moves
 * into an open modal dialog's top layer, so Leave feedback, the board and Point to it work over a sheet
 * without closing it, and the picture shows the sheet over the page, dimmed as on screen.
 *
 * The store is behind window.OGC_FEEDBACK (ogc-feedback-api.js). With no store (the prototype without a
 * board address), nothing is drawn.
 *
 * The screen an idea is about (its key): the page's path from the site's home, plus only the parameters
 * that choose what the screen is, sorted: view, s, c, v, edit, part, committee, tab, tool, role by their
 * value, and shift by its name only (a shift's sheet is one screen, whichever shift). Everything else is
 * left out (year, as-of, tz, preview, return, id, at, f, from, as, team, pages…), so the same screen on two
 * days, or with another record open beside it, counts once. Examples:
 *   /annual-conference/?year=2027&as-of=2027-03-02T09:00      → annual-conference/
 *   /annual-conference/app/?year=2027&s=shifts&c=food&id=12  → annual-conference/app/?c=food&s=shifts
 *   /annual-conference/volunteer/?committee=food&shift=f-3   → annual-conference/volunteer/?committee=food&shift
 * The board names each screen plainly ("Conference page", "Register", "Your sign-ups", "Guide · Help"):
 * a key can hold ideas left under several titles ("2026 Annual Conference", "2027 Annual Conference").
 *
 * The picture: html-to-image 1.11.11 from jsDelivr (pinned, with its integrity hash), loaded only when
 * Leave feedback is first pressed. It draws the page from its own styles, so text, shadows and closed
 * folds come out as on screen (html2canvas 1.4.1 moved text and showed closed folds on these pages). The
 * page is drawn at its scroll position, with its fixed bars put back where they are on screen, inner
 * scrolled panels at their scroll, and an open modal dialog over the page with its dimming. If it can't
 * load (offline, a blocked script) the idea goes without one.
 */
(function () {
  'use strict';
  const W = window.OGC_WP || {};
  if (!W.dev && !W.prototype) return;
  const framed = (() => { try { return window.top !== window && !!(window.parent && window.parent.OGC_WP); } catch (e) { return false; } })();
  if (framed) return;
  const API = window.OGC_FEEDBACK;
  if (!API || !API.mode) return;

  const LIB = 'https://cdn.jsdelivr.net/npm/html-to-image@1.11.11/dist/html-to-image.js';
  const LIB_SRI = 'sha384-UbfRVKN3/elS1r7JcK2FhmPP+KlJ4CvYwbyYD7tH+uTkbT9bNJr9eJeQ0FoFbAgz';
  const SANS = 'system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,sans-serif';
  const home = W.home || '/';
  const base = W.base || '/annual-conference/';
  const baseRel = base.indexOf(home) === 0 ? base.slice(home.length) : base.replace(/^\//, '');
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
  const narrow = () => innerWidth < 600;
  const touchy = () => !!(window.matchMedia && matchMedia('(pointer: coarse)').matches);
  // The board's three panes side by side from here; one at a time below.
  const WIDE = 960;
  const SS = {
    get(k, d) { try { const v = sessionStorage.getItem(k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } },
    set(k, v) { try { sessionStorage.setItem(k, JSON.stringify(v)); } catch (e) { /* not kept */ } }
  };
  const dockInfo = () => window.OGC_DOCK || {};
  // Where our surfaces draw: the dock's root (it follows an open pop-up), else the page's body.
  const layer = () => dockInfo().root || document.body;

  /* ------------------------------------------------------------------ the screen an idea is about */

  const BY_VALUE = ['view', 's', 'c', 'v', 'edit', 'part', 'committee', 'tab', 'tool', 'role'];
  const BY_NAME = ['shift'];
  const part = s => String(s).replace(/[^\w\-.%~]/g, c => encodeURIComponent(c).replace(/[!'()*]/g, x => '%' + x.charCodeAt(0).toString(16).toUpperCase()));
  function screenKey(href) {
    const u = new URL(href || location.href, location.href);
    let p = u.pathname.indexOf(home) === 0 ? u.pathname.slice(home.length) : u.pathname.replace(/^\//, '');
    p = p.split('/').map(part).join('/').replace(/\/{2,}/g, '/');
    if (p && !/\/$/.test(p) && !/\.[a-z0-9]{1,5}$/i.test(p)) p += '/';
    const q = [];
    BY_VALUE.forEach(k => { const v = u.searchParams.get(k); if (v) q.push(k + '=' + part(v)); });
    BY_NAME.forEach(k => { if (u.searchParams.get(k)) q.push(k); });
    q.sort();
    return ((p || '/') + (q.length ? '?' + q.join('&') : '')).slice(0, 300);
  }
  // The page's name, without the site's.
  const screenTitle = () => String(document.title || '').split(' – ')[0].replace(/ · \d{4} Conference$/, '').trim().slice(0, 120);
  // This page from the site's home, as it is now ("/annual-conference/register/?year=2027&as-of=…").
  const pagePath = () => { const p = location.pathname; return '/' + (p.indexOf(home) === 0 ? p.slice(home.length) : p.replace(/^\//, '')) + location.search; };
  function context() {
    const d = dockInfo(), m = d.moment || {};
    const at = m.at || (new URLSearchParams(location.search).get('as-of') || '').slice(0, 16);
    return {
      screen: screenKey(), title: screenTitle(), page: pagePath().slice(0, 600),
      at: /^\d{4}-\d\d-\d\dT\d\d:\d\d$/.test(at) ? at : '', moment: m.text && m.text !== 'Today' ? m.text : '',
      as: noEmail(d.who || (W.me ? W.me.name || 'Signed in' : 'Visitor')), size: innerWidth + '×' + innerHeight
    };
  }
  // Who was signed in, never their email: the board is public to everyone with the link.
  function noEmail(v) { return /@/.test(String(v || '')) ? 'Signed in' : String(v || ''); }

  // What the idea was left on, from its screen size ("390×844"): a page looks different on a phone, so an
  // idea about it may be too (Oct 31, Michael).
  function deviceOf(size) {
    const w = parseInt(String(size || ''), 10);
    return !w ? '' : w < 600 ? 'Phone' : w < 1024 ? 'Tablet' : 'Computer';
  }

  // A screen's plain name, from its key: the page (from the Conference's own address), then its view.
  // Pages not named here are named by the titles their ideas were left under, years taken out.
  const PAGES = {
    '': ['Conference page', { full: 'Conference page · Schedule', places: 'Conference page · Places', help: 'Conference page · Help', today: 'Conference page · Today', services: 'Conference page' }],
    'guide/': ['Guide', { full: 'Guide · Schedule', today: 'Guide · Today', places: 'Guide · Places', help: 'Guide · Help', services: 'Guide · Services' }],
    'register/': ['Register', { mine: 'Your sign-ups', receipt: 'Receipt', edit: 'Change registration', done: 'Registered', approve: 'Parent approval', checkout: 'Checkout' }],
    'volunteer/': ['Volunteer', { mine: 'Your sign-ups', lead: 'Who’s signed up' }],
    'tournaments/': ['Tournaments', { mine: 'My teams', teams: 'Tournament teams' }],
    'packet/': ['Information packet'], 'schedule/': ['Printed schedule'], 'lodging/': ['Lodging'], 'lists/': ['Lists'],
    'signin/': ['Sign in'], 'members/': ['Members'], 'mail/': ['Mail log'], 'admin/': ['Admin'], 'year/': ['The year'], 'app/': ['App']
  };
  const yearOf = x => { const m = /[?&]year=(\d{4})/.exec(x.page || '') || /\b(20\d\d)\b/.exec(x.title || ''); return m ? m[1] : ''; };
  const plainTitle = t => String(t || '').replace(/\s*·\s*\d{4} Conference guide$/, '').replace(/\b(19|20)\d\d\b\s*/g, '').replace(/\s*·\s*$/, '').trim();
  function nameOf(key, items) {
    const q = key.indexOf('?'), path = q < 0 ? key : key.slice(0, q), ps = new URLSearchParams(q < 0 ? '' : key.slice(q + 1));
    const rel = path.indexOf(baseRel) === 0 ? path.slice(baseRel.length) : null;
    const tally = {};
    (items || []).forEach(x => { const t = plainTitle(x.title); if (t) tally[t] = (tally[t] || 0) + 1; });
    const common = Object.keys(tally).sort((a, b) => tally[b] - tally[a])[0] || '';
    const pg = rel != null ? PAGES[rel] : null;
    if (!pg) return common || key;
    const view = ps.get('view');
    let n = pg[0];
    if (view && pg[1] && pg[1][view]) n = pg[1][view];
    else if (rel === 'volunteer/' && ps.get('committee')) n = 'Volunteer · ' + (common || ps.get('committee'));
    else if ((view || [...ps.keys()].length) && common && common !== n) n += ' · ' + common;
    if (rel === 'volunteer/' && ps.has('shift')) n += ' · Shift';
    if (rel === 'app/' && ps.get('c')) n += ' · ' + ps.get('c').charAt(0).toUpperCase() + ps.get('c').slice(1).replace(/-/g, ' ');
    return n;
  }

  /* ------------------------------------------------------------------ the look */

  const LINE = 'rgba(255,255,255,.08)';
  const css =
    // In the dock: this screen's count, then Leave feedback (a white pill inside the 44 px tap).
    '.ogc-fb-n{display:inline-flex;align-items:center;justify-content:center;gap:6px;min-width:44px;height:44px;margin:0;padding:0 10px;border:0;border-radius:22px;background:transparent;color:#f2f2f2;font:600 13px/1 ' + SANS + ';cursor:pointer}' +
    '.ogc-fb-n:hover,.ogc-fb-n[aria-expanded=true]{background:rgba(255,255,255,.08)}.ogc-fb-n[hidden]{display:none}' +
    '.ogc-fb-n svg{flex:none;width:16px;height:16px;color:#d4d4d4}' +
    '.ogc-fb-go{display:inline-flex;align-items:center;height:44px;margin:0;padding:0 4px 0 2px;border:0;border-radius:22px;background:transparent;cursor:pointer;font:600 13px/1 ' + SANS + '}' +
    '.ogc-fb-go__in{display:inline-flex;align-items:center;gap:6px;height:36px;padding:0 14px 0 11px;border-radius:18px;background:#f2f2f2;color:#111;white-space:nowrap;box-shadow:inset 0 1px 0 rgba(255,255,255,.16)}' +
    '.ogc-fb-go:hover .ogc-fb-go__in{background:#fff}.ogc-fb-go[aria-expanded=true] .ogc-fb-go__in{background:#d4d4d4}' +
    '.ogc-fb-go svg{flex:none;width:14px;height:14px}.ogc-fb-go__s{display:none}' +
    '.ogc-pill .ogc-fb-go:focus-visible{outline:none}.ogc-fb-go:focus-visible .ogc-fb-go__in{outline:2px solid #f2f2f2;outline-offset:2px}' +
    '@media (max-width:399px){.ogc-fb-go__l{display:none}.ogc-fb-go__s{display:inline}}' +

    // The demo's surfaces: the composer, the board, the toast, the picture enlarged.
    '.ogc-fbx-ui{box-sizing:border-box;color:#f2f2f2;font:400 14px/1.45 ' + SANS + ';letter-spacing:0;text-transform:none;-webkit-font-smoothing:antialiased;text-align:left}' +
    '.ogc-fbx-ui *{box-sizing:border-box}.ogc-fbx-ui[hidden],.ogc-fbx-ui [hidden]{display:none!important}' +
    '.ogc-fbx-ui h2,.ogc-fbx-ui h3{margin:0;padding:0;color:#f2f2f2;font:650 16px/1.25 ' + SANS + ';letter-spacing:0;text-transform:none}' +
    '.ogc-fbx-ui p{margin:0;padding:0}.ogc-fbx-ui ul{margin:0;padding:0;list-style:none}.ogc-fbx-ui li{margin:0;padding:0}' +
    '.ogc-fbx-ui button{font-family:' + SANS + ';letter-spacing:0;text-transform:none;text-decoration:none}' +
    '.ogc-fbx-ui :focus-visible{outline:2px solid #f2f2f2;outline-offset:2px}.ogc-fbx-ui :focus:not(:focus-visible){outline:none}' +
    '.ogc-fbx-ui [tabindex="-1"]:focus{outline:none}' +
    // Buttons: one filled (white) a view; quiet ones are words on the dark.
    '.ogc-fbp{display:inline-flex;align-items:center;justify-content:center;gap:6px;min-height:44px;margin:0;padding:0 18px;border:0;border-radius:12px;background:#f2f2f2;color:#111;font-weight:600;font-size:14px;cursor:pointer;white-space:nowrap}' +
    '.ogc-fbp:hover{background:#fff}.ogc-fbp:disabled{opacity:.6;cursor:default}.ogc-fbp svg{flex:none;width:14px;height:14px}' +
    '.ogc-fbp--sm{position:relative;min-height:36px;padding:0 12px;border-radius:10px;font-size:13px}' +
    // Its tap is 44 px all the same: the button is drawn smaller inside it.
    '.ogc-fbp--sm::after{content:"";position:absolute;left:0;right:0;top:-4px;bottom:-4px}' +
    '.ogc-fbq{display:inline-flex;align-items:center;justify-content:center;gap:6px;min-height:44px;min-width:44px;margin:0;padding:0 12px;border:0;border-radius:10px;background:transparent;color:#d4d4d4;font-weight:500;font-size:13.5px;cursor:pointer;white-space:nowrap}' +
    '.ogc-fbq:hover{background:rgba(255,255,255,.07);color:#fff}.ogc-fbq svg{flex:none;width:16px;height:16px}' +
    '.ogc-fbq--danger{color:#fca5a5}.ogc-fbq--danger:hover{color:#fecaca;background:rgba(248,113,113,.12)}' +
    '.ogc-fbq--chip{min-height:36px;padding:0 12px;border-radius:999px;background:rgba(255,255,255,.07);color:#e6e6e6;font-size:13px}' +
    '.ogc-fbq--chip:hover{background:rgba(255,255,255,.12)}' +
    // A chip's tap is 44 px: the chip is drawn smaller inside it.
    '.ogc-fbc__tools .ogc-fbq--chip{position:relative}.ogc-fbc__tools .ogc-fbq--chip::after{content:"";position:absolute;left:0;right:0;top:-4px;bottom:-4px}' +
    '.ogc-fbx-ui label{display:block;margin:14px 0 6px;color:#d4d4d4;font-size:13px;font-weight:600}' +
    '.ogc-fbx-ui textarea,.ogc-fbx-ui input[type=text],.ogc-fbx-ui input[type=password]{display:block;width:100%;margin:0;padding:10px 12px;border:1px solid rgba(255,255,255,.14);border-radius:10px;background:#0c0c0c;color:#f2f2f2;font:400 16px/1.4 ' + SANS + ';box-shadow:none;-webkit-appearance:none;appearance:none}' +
    '.ogc-fbx-ui input{min-height:44px}.ogc-fbx-ui textarea{min-height:96px;resize:vertical}' +
    '.ogc-fbx-ui textarea::placeholder,.ogc-fbx-ui input::placeholder{color:#8a8a8a}' +
    '.ogc-fbx-ui textarea:focus,.ogc-fbx-ui input:focus{outline:none;border-color:rgba(255,255,255,.55);box-shadow:0 0 0 3px rgba(255,255,255,.12)}' +
    '.ogc-fbx-ui [aria-invalid=true]{border-color:#f87171}' +
    '.ogc-fb-err{margin:6px 0 0!important;color:#fca5a5;font-size:13px}.ogc-fb-err:empty{display:none}' +
    '.ogc-fbx{flex:none;display:inline-flex;align-items:center;justify-content:center;width:44px;height:44px;margin:0;padding:0;border:0;border-radius:10px;background:transparent;color:#a3a3a3;cursor:pointer}' +
    '.ogc-fbx:hover{background:rgba(255,255,255,.08);color:#fff}.ogc-fbx svg{width:18px;height:18px}' +

    // The composer: a card above the dock on a laptop, a sheet from the foot on a phone.
    '.ogc-fbc{position:fixed;z-index:2147482000;right:16px;bottom:calc(68px + var(--ogc-pill-lift,0px) + env(safe-area-inset-bottom));width:min(392px,calc(100vw - 32px));max-height:calc(100vh - 92px - var(--ogc-pill-lift,0px));overflow:auto;overscroll-behavior:contain;padding:6px 16px 16px;border-radius:18px;background:#161616;box-shadow:inset 0 0 0 1px rgba(255,255,255,.09),0 24px 60px rgba(0,0,0,.42)}' +
    '.ogc-fbc__head{display:flex;align-items:center;gap:8px;margin:0 -8px 0 0}.ogc-fbc__head h2{flex:1}' +
    '.ogc-fbc__ctx{margin:-6px 0 12px!important;color:#a3a3a3;font-size:12.5px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}' +
    '.ogc-fbc__shot{position:relative;display:flex;align-items:center;justify-content:center;height:196px;border-radius:12px;background:#0c0c0c;box-shadow:inset 0 0 0 1px rgba(255,255,255,.08);overflow:hidden}' +
    '.ogc-fbc__shot img{display:block;max-width:100%;max-height:100%;object-fit:contain}' +
    '.ogc-fbc__ph{color:#a3a3a3;font-size:13px}' +
    '.ogc-fbc__tools{display:flex;flex-wrap:wrap;align-items:center;gap:6px;margin:8px 0 0}' +
    '.ogc-fbc__pin{flex:1 1 100%;margin:2px 0 0!important;color:#a3a3a3;font-size:12.5px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}' +
    '.ogc-fbc__foot{display:flex;align-items:center;justify-content:flex-end;gap:8px;margin:16px 0 0}' +
    '.ogc-fbc__status{flex:1;color:#a3a3a3;font-size:13px}' +
    '@media (max-width:599px){.ogc-fbc{left:0;right:0;bottom:0;width:auto;max-height:92vh;max-height:92dvh;border-radius:20px 20px 0 0;padding-bottom:calc(16px + env(safe-area-inset-bottom))}' +
    'html.ogc-fb-composing .ogc-pill{visibility:hidden}}' +

    // Point to it: the page under a clear layer; the thing under the pointer outlined.
    '.ogc-fba{position:fixed;inset:0;z-index:2147482500;cursor:crosshair;background:rgba(0,0,0,.08);touch-action:pan-x pan-y}' +
    '.ogc-fba__box{position:fixed;z-index:2147482501;pointer-events:none;border:2px solid #111;border-radius:6px;background:rgba(17,17,17,.06);box-shadow:0 0 0 2px rgba(255,255,255,.85);display:none}' +
    '.ogc-fba__tip{position:fixed;left:50%;top:calc(12px + env(safe-area-inset-top));transform:translateX(-50%);z-index:2147482502;display:flex;align-items:center;gap:4px;padding:0 4px 0 16px;border-radius:999px;background:#161616;box-shadow:inset 0 0 0 1px rgba(255,255,255,.09),0 8px 24px rgba(0,0,0,.3);white-space:nowrap}' +
    '.ogc-fba__tip span{font-weight:600;font-size:13.5px}' +

    // The board: the whole screen. A bar, then three panes (Screens, a screen's ideas by person, an idea),
    // or on a phone one pane at a time.
    '.ogc-fbb{position:fixed;inset:0;z-index:2147482000;display:flex;flex-direction:column;background:#131313;color:#f2f2f2}' +
    '.ogc-fbb__head{position:relative;flex:none;display:flex;align-items:center;gap:6px;min-height:56px;padding:6px 10px 6px 20px;padding-top:calc(6px + env(safe-area-inset-top));border-bottom:1px solid ' + LINE + '}' +
    '.ogc-fbb__head h2{flex:1;min-width:0;font-size:15px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}' +
    '.ogc-fbb__badge{display:inline-block;margin-left:8px;padding:2px 8px;border-radius:999px;background:rgba(255,255,255,.12);color:#e6e6e6;font-size:12px;font-weight:600;vertical-align:1px}' +
    '.ogc-fbb__back{flex:none;display:inline-flex;align-items:center;gap:2px;min-width:44px;min-height:44px;margin:0 0 0 -12px;padding:0 10px 0 6px;border:0;border-radius:10px;background:transparent;color:#e6e6e6;font-size:14px;font-weight:500;cursor:pointer}' +
    '.ogc-fbb__back:hover{background:rgba(255,255,255,.07)}.ogc-fbb__back svg{width:18px;height:18px}' +
    '.ogc-fbb__sub{flex:none;display:flex;align-items:center;justify-content:space-between;gap:8px;padding:8px 12px;border-bottom:1px solid ' + LINE + '}' +
    // Open | Resolved
    '.ogc-fbs{display:inline-flex;padding:3px;border-radius:12px;background:rgba(255,255,255,.06)}' +
    '.ogc-fbs button{position:relative;min-height:38px;margin:0;padding:0 12px;border:0;border-radius:9px;background:transparent;color:#a3a3a3;font-size:13px;font-weight:600;cursor:pointer}' +
    '.ogc-fbs button::after{content:"";position:absolute;left:0;right:0;top:-3px;bottom:-3px}' +
    '.ogc-fbs button:hover{color:#f2f2f2}.ogc-fbs button[aria-pressed=true]{background:#2e2e2e;color:#f2f2f2;box-shadow:0 1px 2px rgba(0,0,0,.3)}' +
    '.ogc-fbb__menu{position:absolute;z-index:5;top:calc(54px + env(safe-area-inset-top));right:10px;min-width:200px;max-width:calc(100vw - 20px);padding:6px;border-radius:12px;background:#1f1f1f;box-shadow:inset 0 0 0 1px rgba(255,255,255,.1),0 12px 32px rgba(0,0,0,.45)}' +
    '.ogc-fbb__menu>button{display:flex;width:100%;justify-content:flex-start}' +
    '.ogc-fbb__key{width:300px;padding:12px 14px 14px}.ogc-fbb__key label{margin-top:0}.ogc-fbb__key div{display:flex;gap:8px;margin-top:10px;justify-content:flex-end}' +
    '.ogc-fbb__panes{flex:1;min-height:0;display:grid;grid-template-columns:264px minmax(360px,460px) minmax(0,1fr)}' +
    '.ogc-fbb__pane{min-height:0;overflow:auto;overscroll-behavior:contain}' +
    '.ogc-fbb__screens{padding:12px 8px 24px;border-right:1px solid ' + LINE + '}' +
    '.ogc-fbb__list{padding:0 0 24px;border-right:1px solid ' + LINE + '}' +
    '.ogc-fbb__idea{background:#181818;padding:24px 32px 48px}' +
    '.ogc-fbb--one .ogc-fbb__panes{display:block}.ogc-fbb--one .ogc-fbb__pane{display:none;height:100%;border-right:0}' +
    '.ogc-fbb--one[data-pane=screens] .ogc-fbb__screens,.ogc-fbb--one[data-pane=list] .ogc-fbb__list,.ogc-fbb--one[data-pane=idea] .ogc-fbb__idea{display:block}' +
    '.ogc-fbb--one .ogc-fbb__idea{background:#131313;padding:16px 16px calc(32px + env(safe-area-inset-bottom))}' +
    '.ogc-fbb--one .ogc-fbb__screens,.ogc-fbb--one .ogc-fbb__list{padding-bottom:calc(24px + env(safe-area-inset-bottom))}' +
    '.ogc-fbb__line{margin:28px 16px!important;color:#a3a3a3;font-size:14px;text-align:center}' +
    '.ogc-fbb__cap{margin:0 12px 6px!important;color:#8f8f8f;font-size:12px;font-weight:600}' +
    // Screens
    '.ogc-fbsc{display:flex;align-items:center;gap:10px;width:100%;min-height:44px;margin:0 0 2px;padding:6px 10px 6px 12px;border:0;border-radius:8px;background:transparent;color:#d4d4d4;text-align:left;font:500 13.5px/1.3 ' + SANS + ';cursor:pointer}' +
    '.ogc-fbsc:hover{background:rgba(255,255,255,.05);color:#f2f2f2}' +
    '.ogc-fbsc[aria-current=true]{background:#2a2a2a;color:#fff}' +
    '.ogc-fbsc__n{flex:1;min-width:0}.ogc-fbsc__n b{display:block;font-weight:inherit;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}' +
    '.ogc-fbsc__n small{display:block;margin-top:1px;color:#8f8f8f;font-size:11.5px;font-weight:500}.ogc-fbsc[aria-current=true] small{color:#b5b5b5}' +
    '.ogc-fbsc__c{flex:none;min-width:20px;color:#a3a3a3;font-size:12.5px;text-align:right;font-variant-numeric:tabular-nums}.ogc-fbsc[aria-current=true] .ogc-fbsc__c{color:#e6e6e6}' +
    '.ogc-fbb--one .ogc-fbsc{min-height:52px;font-size:15px}' +
    // A screen's ideas, by person
    '.ogc-fbl__head{position:sticky;top:0;z-index:2;padding:16px 20px 12px;background:#131313}' +
    '.ogc-fbl__head h3{font-size:15px}.ogc-fbl__head p{margin:3px 0 0!important;color:#8f8f8f;font-size:12.5px}' +
    '.ogc-fbb--one .ogc-fbl__head{position:static;padding:12px 16px 4px}.ogc-fbb--one .ogc-fbl__head h3{position:absolute;width:1px;height:1px;margin:-1px;overflow:hidden;clip:rect(0 0 0 0);white-space:nowrap}' +
    '.ogc-fbg{padding:0 8px}' +
    '.ogc-fbg__who{display:flex;align-items:center;gap:8px;margin:14px 12px 6px!important;color:#e6e6e6;font-size:13px;font-weight:600}' +
    '.ogc-fbg__who>span:not(.ogc-fb-av){color:#8f8f8f;font-weight:500;font-variant-numeric:tabular-nums}' +
    '.ogc-fbrow{display:flex;align-items:flex-start;gap:12px;width:100%;margin:0 0 2px;padding:10px 12px;border:0;border-radius:10px;background:transparent;color:#e6e6e6;text-align:left;font:400 13.5px/1.4 ' + SANS + ';cursor:pointer}' +
    '.ogc-fbrow:hover{background:rgba(255,255,255,.04)}.ogc-fbrow[aria-current=true]{background:#2a2a2a}' +
    '.ogc-fbrow--new{box-shadow:inset 0 0 0 1px rgba(255,255,255,.3)}' +
    '.ogc-fbrow__pic{flex:none;position:relative;display:block;width:84px;height:56px;border-radius:6px;overflow:hidden;background:#0b0b0b;box-shadow:inset 0 0 0 1px rgba(255,255,255,.08)}' +
    '.ogc-fbrow__pic img{display:block;width:100%;height:100%;object-fit:cover}' +
    '.ogc-fbrow__pic--none{display:flex;align-items:center;justify-content:center;color:#575757}.ogc-fbrow__pic--none svg{width:18px;height:18px}' +
    '.ogc-fbrow__b{flex:1;min-width:0;display:block}' +
    '.ogc-fbrow__t{display:-webkit-box;-webkit-box-orient:vertical;-webkit-line-clamp:2;line-clamp:2;overflow:hidden;overflow-wrap:anywhere;color:#e6e6e6}' +
    '.ogc-fbrow__m{display:flex;align-items:center;gap:10px;margin-top:4px;color:#8f8f8f;font-size:12px;white-space:nowrap}' +
    '.ogc-fbrow__m em{min-width:0;font-style:normal;overflow:hidden;text-overflow:ellipsis}' +
    '.ogc-fbrow__s{flex:none;display:inline-flex;align-items:center;gap:3px;color:#c4c4c4;font-variant-numeric:tabular-nums}.ogc-fbrow__s svg{width:11px;height:11px}' +
    '.ogc-fbrow[aria-current=true] .ogc-fbrow__m{color:#a8a8a8}' +
    // An idea in full
    '.ogc-fbd{max-width:780px;margin:0 auto}' +
    '.ogc-fbd__top{display:flex;align-items:center;gap:10px}.ogc-fbd__top>div{flex:1;min-width:0}' +
    '.ogc-fbd__top h3{font-size:15px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}' +
    '.ogc-fbd__top>div>span{display:block;color:#8f8f8f;font-size:12.5px}' +
    '.ogc-fbd__res{flex:none;padding:2px 9px;border-radius:999px;background:rgba(255,255,255,.1);color:#d4d4d4;font-size:12px;font-weight:600}' +
    '.ogc-fb-av{flex:none;display:inline-flex;align-items:center;justify-content:center;width:32px;height:32px;border-radius:50%;color:#fff;font-size:12px;font-weight:700}' +
    '.ogc-fb-av--sm{width:22px;height:22px;font-size:9.5px}' +
    '.ogc-fbd__pic{display:block;width:100%;margin:16px 0 0;padding:0;border:0;border-radius:10px;background:#0b0b0b;overflow:hidden;cursor:zoom-in;box-shadow:inset 0 0 0 1px rgba(255,255,255,.08)}' +
    '.ogc-fbd__pic img{display:block;width:100%;height:auto;max-height:54vh;object-fit:contain}' +
    '.ogc-fbd__text{margin:16px 0 0!important;color:#ededed;font-size:15px;line-height:1.55;white-space:pre-wrap;overflow-wrap:anywhere}' +
    '.ogc-fbd__at{margin:10px 0 0!important;color:#8f8f8f;font-size:12.5px;overflow-wrap:anywhere}' +
    '.ogc-fbd__pin{display:-webkit-box;-webkit-box-orient:vertical;-webkit-line-clamp:2;line-clamp:2;overflow:hidden}' +
    '.ogc-fbd__acts{display:flex;flex-wrap:wrap;align-items:center;gap:4px;margin:16px -8px 0;padding-top:12px;border-top:1px solid ' + LINE + '}' +
    '.ogc-fbd__acts .ogc-fbq{padding:0 10px;font-size:13.5px;color:#c4c4c4}.ogc-fbd__acts .ogc-fbq:hover{color:#fff}.ogc-fbd__acts .ogc-fbq--danger{color:#fca5a5}' +
    '.ogc-fbd__sp{flex:1}' +
    '.ogc-fb-up{flex:none;display:inline-flex;align-items:center;justify-content:center;gap:6px;min-width:44px;height:44px;margin:0;padding:0 14px;border:0;border-radius:12px;background:rgba(255,255,255,.07);color:#e6e6e6;font-size:13.5px;font-weight:600;cursor:pointer}' +
    '.ogc-fb-up:hover{background:rgba(255,255,255,.12);color:#fff}.ogc-fb-up svg{width:13px;height:13px}' +
    '.ogc-fb-up[aria-pressed=true]{background:#f2f2f2;color:#111}.ogc-fb-up[aria-pressed=true]:hover{background:#fff}' +
    // The thread
    '.ogc-fbth{margin:4px 0 0}' +
    '.ogc-fbth__one{padding:12px 0 4px;border-top:1px solid rgba(255,255,255,.06)}.ogc-fbth__one:first-child{border-top:0}' +
    '.ogc-fbth__one header{display:flex;align-items:center;gap:8px;font-size:13px}.ogc-fbth__one header b{font-weight:600}.ogc-fbth__one header>span:not(.ogc-fb-av){color:#8f8f8f}' +
    '.ogc-fbth__one header .ogc-fbq{margin:-10px -8px -10px auto;padding:0 8px;font-size:12.5px;color:#a3a3a3}' +
    '.ogc-fbth__one p{margin:4px 0 0 30px!important;color:#d9d9d9;font-size:14px;line-height:1.5;white-space:pre-wrap;overflow-wrap:anywhere}' +
    '.ogc-fbth__form{padding:6px 0 4px}.ogc-fbth__form textarea{min-height:72px}.ogc-fbth__form label{margin-top:10px}.ogc-fbth__form .ogc-fbc__foot{margin-top:10px}' +

    // A toast: what just happened, with what to do next.
    '.ogc-fbt{position:fixed;left:50%;bottom:calc(72px + var(--ogc-pill-lift,0px) + env(safe-area-inset-bottom));z-index:2147482100;transform:translateX(-50%);display:flex;align-items:center;gap:6px;max-width:calc(100vw - 32px);padding:0 6px 0 16px;border-radius:14px;background:#1f1f1f;box-shadow:inset 0 0 0 1px rgba(255,255,255,.1),0 10px 30px rgba(0,0,0,.32)}' +
    '.ogc-fbt span{font-weight:600;padding:12px 0}' +
    '.ogc-fbb~.ogc-fbt,.ogc-fbt--board{bottom:calc(24px + env(safe-area-inset-bottom))}' +
    // The picture, enlarged.
    '.ogc-fbl{position:fixed;inset:0;z-index:2147482600;display:flex;align-items:center;justify-content:center;padding:56px 16px 16px;background:rgba(10,10,10,.94);cursor:zoom-out}' +
    '.ogc-fbl img{max-width:100%;max-height:100%;border-radius:8px;box-shadow:0 20px 60px rgba(0,0,0,.5)}' +
    '.ogc-fbl .ogc-fbx{position:absolute;top:8px;right:8px;color:#e6e6e6}' +
    '@media (prefers-reduced-motion:no-preference){' +
    '.ogc-fbc{animation:ogc-fb-up .16s ease-out}.ogc-fbb{animation:ogc-fb-fade .14s ease-out}' +
    '.ogc-fbt{animation:ogc-fb-fade .16s ease-out}.ogc-fbc__shot--wait .ogc-fbc__ph{animation:ogc-fb-wait 1.2s ease-in-out infinite alternate}' +
    '@keyframes ogc-fb-up{from{opacity:0;transform:translateY(8px)}}' +
    '@keyframes ogc-fb-fade{from{opacity:0}}@keyframes ogc-fb-wait{to{opacity:.45}}}' +
    '@media print{.ogc-fbc,.ogc-fbb,.ogc-fbt,.ogc-fbl,.ogc-fba,.ogc-fba__box,.ogc-fba__tip{display:none!important}}';

  const I = {
    talk: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 5.5h14a1.5 1.5 0 0 1 1.5 1.5v8.5A1.5 1.5 0 0 1 19 17h-7.5L7 20.5V17H5a1.5 1.5 0 0 1-1.5-1.5V7A1.5 1.5 0 0 1 5 5.5Z" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/></svg>',
    reply: '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 3.5h10a1 1 0 0 1 1 1v6a1 1 0 0 1-1 1H8l-3 2.5v-2.5H3a1 1 0 0 1-1-1v-6a1 1 0 0 1 1-1Z" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/></svg>',
    plus: '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M8 3v10M3 8h10" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>',
    x: '<svg viewBox="0 0 20 20" aria-hidden="true"><path d="m5 5 10 10M15 5 5 15" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>',
    back: '<svg viewBox="0 0 20 20" aria-hidden="true"><path d="M12.5 4.5 7 10l5.5 5.5" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    up: '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M8 3.5 13 10H3z" fill="currentColor"/></svg>',
    text: '<svg viewBox="0 0 20 20" aria-hidden="true"><path d="M4 5.5h12M4 10h12M4 14.5h7" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg>',
    more: '<svg viewBox="0 0 20 20" aria-hidden="true"><circle cx="4.5" cy="10" r="1.6" fill="currentColor"/><circle cx="10" cy="10" r="1.6" fill="currentColor"/><circle cx="15.5" cy="10" r="1.6" fill="currentColor"/></svg>'
  };

  function ui(tag, cls, html) {
    const el = document.createElement(tag);
    el.className = 'ogc-fbx-ui ' + cls;
    el.setAttribute('data-ogc-tool', '');
    if (html != null) el.innerHTML = html;
    return el;
  }
  const MON = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'June', 'July', 'Aug', 'Sept', 'Oct', 'Nov', 'Dec'];
  function ago(iso) {
    const t = Date.parse(iso || '');
    if (!t) return '';
    const s = (Date.now() - t) / 1000;
    if (s < 60) return 'Just now';
    if (s < 3600) return Math.floor(s / 60) + ' min ago';
    if (s < 86400) return Math.floor(s / 3600) + ' h ago';
    if (s < 172800) return 'Yesterday';
    const d = new Date(t);
    return MON[d.getMonth()] + ' ' + d.getDate() + (d.getFullYear() !== new Date().getFullYear() ? ', ' + d.getFullYear() : '');
  }
  const TONES = ['#2750C7', '#00707E', '#A86F00', '#8E357E', '#1D7D3E', '#555555', '#7A5230', '#8B2A2A'];
  function avatar(name, small) {
    const w = String(name || '?').trim().split(/\s+/).filter(Boolean);
    const ini = ((w[0] || '?').charAt(0) + (w.length > 1 ? w[w.length - 1].charAt(0) : '')).toUpperCase();
    let h = 0;
    for (const c of String(name)) h = (h * 31 + c.charCodeAt(0)) >>> 0;
    return '<span class="ogc-fb-av' + (small ? ' ogc-fb-av--sm' : '') + '" style="background:' + TONES[h % TONES.length] + '" aria-hidden="true">' + esc(ini) + '</span>';
  }
  // The day an idea was left on, short: "Mar 2" from "Registration · Mar 2, 2027"; and the moment's name.
  const dayShort = m => { const x = /· ([A-Z][a-z]+ \d{1,2})/.exec(m || ''); return x ? x[1] : ''; };
  const momentName = m => { const x = /^([^·]+?) · /.exec(m || ''); return x ? x[1] : ''; };
  const errWords = code => ({
    name: 'Add your name', text: 'Write your idea', slow: 'Too many at once · Try again in a few minutes', offline: 'Offline · Try again when connected',
    network: 'Couldn’t reach the board · Try again', forbidden: 'Not allowed', not_found: 'That idea is gone', busy: 'Busy · Try again'
  })[code] || 'Something went wrong · Try again';

  /* ------------------------------------------------------------------ the picture of the screen */

  let libP = null;
  function loadLib() {
    if (window.htmlToImage && window.htmlToImage.toSvg) return Promise.resolve(window.htmlToImage);
    if (libP) return libP;
    libP = new Promise((res, rej) => {
      const s = document.createElement('script');
      s.src = LIB;
      s.async = true;
      s.crossOrigin = 'anonymous';
      s.integrity = LIB_SRI;
      s.referrerPolicy = 'no-referrer';
      s.setAttribute('data-ogc-tool', '');
      s.onload = () => (window.htmlToImage && window.htmlToImage.toSvg ? res(window.htmlToImage) : rej(new Error('lib')));
      s.onerror = () => { libP = null; s.remove(); rej(new Error('lib')); };
      document.head.appendChild(s);
    });
    return libP;
  }
  const within = (p, ms) => Promise.race([p, new Promise((res, rej) => setTimeout(() => rej(new Error('timeout')), ms))]);
  const frame = () => new Promise(r => requestAnimationFrame(() => r()));
  const XHTML = 'http://www.w3.org/1999/xhtml';

  // The screen as the visitor sees it now, without our own things: {url (JPEG data URL), w, h, sx, sy, k}.
  async function capture() {
    const H = await within(loadLib(), 12000);
    const de = document.documentElement;
    const w = de.clientWidth || innerWidth, h = innerHeight, sx = scrollX, sy = scrollY;
    // What moves when drawn from the top: fixed things (put back where they are) and scrolled panels.
    const marks = [];
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_ELEMENT, { acceptNode: n => n.hasAttribute('data-ogc-tool') ? NodeFilter.FILTER_REJECT : NodeFilter.FILTER_ACCEPT });
    for (let n = walker.nextNode(); n; n = walker.nextNode()) {
      if ((n.scrollTop || n.scrollLeft) && n !== document.scrollingElement) { n.setAttribute('data-ogc-cap-sc', n.scrollLeft + ',' + n.scrollTop); marks.push(n); }
      if (getComputedStyle(n).position === 'fixed') {
        const r = n.getBoundingClientRect();
        if (r.width && r.height) { n.setAttribute('data-ogc-cap-fx', [r.left + sx, r.top + sy, r.width, r.height].map(v => Math.round(v * 100) / 100).join(',')); marks.push(n); }
      }
    }
    // Open modal dialogs (a sheet) are in the top layer: drawn last, over the page, each over its own
    // dimming, as on screen (in the picture they'd sit in the page's order, under its header).
    const mods = (dockInfo().modals ? dockInfo().modals() : [...document.querySelectorAll('dialog[open]')]).filter(d => !d.hasAttribute('data-ogc-tool'));
    const dims = mods.map((d, i) => {
      d.setAttribute('data-ogc-cap-top', String(i));
      marks.push(d);
      let c = '';
      try { c = getComputedStyle(d, '::backdrop').backgroundColor || ''; } catch (e) { c = ''; }
      return /^(transparent|rgba\(0, 0, 0, 0\))$/.test(c) ? '' : c;
    });
    let svg;
    try {
      svg = await within(H.toSvg(de, {
        width: w, height: h, cacheBust: false, skipAutoScale: true,
        imagePlaceholder: 'data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==',
        filter: n => !(n && n.nodeType === 1 && n.hasAttribute && n.hasAttribute('data-ogc-tool')),
        style: { transform: 'translate(' + (-sx) + 'px,' + (-sy) + 'px)', transformOrigin: '0 0' }
      }), 20000);
    } finally {
      marks.forEach(n => { n.removeAttribute('data-ogc-cap-sc'); n.removeAttribute('data-ogc-cap-fx'); n.removeAttribute('data-ogc-cap-top'); });
    }
    const PRE = 'data:image/svg+xml;charset=utf-8,';
    if (svg.indexOf(PRE) === 0) {
      try {
        const doc = new DOMParser().parseFromString(decodeURIComponent(svg.slice(PRE.length)), 'image/svg+xml');
        if (!doc.querySelector('parsererror')) {
          const add = (el, more) => el.setAttribute('style', (el.getAttribute('style') || '') + ';' + more);
          doc.querySelectorAll('[data-ogc-cap-sc]').forEach(el => {
            const [l, t] = el.getAttribute('data-ogc-cap-sc').split(',').map(Number);
            [...el.children].forEach(c => add(c, 'translate:' + (-l) + 'px ' + (-t) + 'px'));
          });
          doc.querySelectorAll('[data-ogc-cap-fx]').forEach(el => {
            const [l, t, ww, hh] = el.getAttribute('data-ogc-cap-fx').split(',').map(Number);
            add(el, 'position:fixed;inset:auto;left:' + l + 'px;top:' + t + 'px;width:' + ww + 'px;height:' + hh + 'px;margin:0;transform:none;translate:none;box-sizing:border-box');
          });
          const body = doc.getElementsByTagName('body')[0];
          // No scrollbars drawn in the picture (a sheet's own, which a screen shows only while scrolling).
          if (body) {
            const st = doc.createElementNS(body.namespaceURI || XHTML, 'style');
            st.textContent = '*{scrollbar-width:none!important}*::-webkit-scrollbar{display:none!important}';
            body.insertBefore(st, body.firstChild);
          }
          if (body) {
            [...doc.querySelectorAll('[data-ogc-cap-top]')].sort((a, b) => a.getAttribute('data-ogc-cap-top') - b.getAttribute('data-ogc-cap-top')).forEach(el => {
              const i = +el.getAttribute('data-ogc-cap-top'), z = 2147482000 + i * 2;
              if (dims[i]) {
                const dim = doc.createElementNS(el.namespaceURI || XHTML, 'div');
                dim.setAttribute('style', 'position:fixed;left:' + sx + 'px;top:' + sy + 'px;width:' + w + 'px;height:' + h + 'px;margin:0;padding:0;border:0;background:' + dims[i] + ';z-index:' + z);
                body.appendChild(dim);
              }
              add(el, 'z-index:' + (z + 1));
              body.appendChild(el);
            });
          }
          svg = PRE + encodeURIComponent(new XMLSerializer().serializeToString(doc));
        }
      } catch (e) { /* drawn as the library made it */ }
    }
    const img = new Image();
    img.decoding = 'sync';
    await within(new Promise((res, rej) => { img.onload = res; img.onerror = () => rej(new Error('draw')); img.src = svg; }), 15000);
    // At most 1600 px on its long side.
    const k = Math.min(window.devicePixelRatio || 1, 1600 / Math.max(w, h));
    const c = document.createElement('canvas');
    c.width = Math.round(w * k);
    c.height = Math.round(h * k);
    const g = c.getContext('2d');
    const paint = () => { g.fillStyle = '#fff'; g.fillRect(0, 0, c.width, c.height); g.drawImage(img, 0, 0, c.width, c.height); };
    paint();
    // Safari can paint a picture's own pictures a moment late: once more after two frames.
    await frame(); await frame();
    paint();
    return { url: c.toDataURL('image/jpeg', 0.85), w, h, sx, sy, k };
  }

  // One at a time: a capture marks the page's fixed things while it runs.
  let capQ = Promise.resolve();
  function captureOne() {
    const p = capQ.then(capture, capture);
    capQ = p.catch(() => {});
    return p;
  }

  // The picture with the pin (and an outline round the thing pointed at) drawn on it.
  function withPin(shot, pin) {
    if (!shot || !pin || pin.cx == null) return Promise.resolve(shot ? shot.url : '');
    return new Promise(res => {
      const img = new Image();
      img.onload = () => {
        const c = document.createElement('canvas');
        c.width = img.naturalWidth; c.height = img.naturalHeight;
        const g = c.getContext('2d'), k = c.width / shot.w;
        g.drawImage(img, 0, 0);
        if (pin.box) {
          const [x, y, bw, bh] = pin.box.map(v => v * k);
          g.lineWidth = Math.max(2, 2 * k);
          g.strokeStyle = '#111';
          g.fillStyle = 'rgba(17,17,17,.08)';
          const r = 6 * k;
          g.beginPath();
          if (g.roundRect) g.roundRect(x, y, bw, bh, r); else g.rect(x, y, bw, bh);
          g.fill(); g.stroke();
        }
        const x = pin.cx * k, y = pin.cy * k;
        g.beginPath(); g.arc(x, y, 18 * k, 0, Math.PI * 2); g.fillStyle = 'rgba(0,0,0,.22)'; g.fill();
        g.beginPath(); g.arc(x, y, 10 * k, 0, Math.PI * 2); g.fillStyle = '#111'; g.fill();
        g.lineWidth = 3 * k; g.strokeStyle = '#fff'; g.stroke();
        res(c.toDataURL('image/jpeg', 0.85));
      };
      img.onerror = () => res(shot.url);
      img.src = shot.url;
    });
  }

  // The words of what was tapped: its own label, or the nearest bit of text around it, as written (not
  // as styled: "Register", not "REGISTER").
  function labelOf(el) {
    for (let e = el, i = 0; e && e !== document.body && i < 6; e = e.parentElement, i++) {
      const t = (e.getAttribute && (e.getAttribute('aria-label') || e.getAttribute('title') || e.getAttribute('alt'))) || e.textContent || '';
      const s = t.replace(/\s+/g, ' ').trim();
      if (s) return s.length > 70 ? s.slice(0, 67) + '…' : s;
    }
    return '';
  }

  /* ------------------------------------------------------------------ the dock's part */

  let dock = null, nBtn = null, goBtn = null, counts = SS.get('ogc-fb-counts', null);
  let here = screenKey();

  function drawCount() {
    if (!nBtn) return;
    const c = (counts && counts.c) || {};
    const n = c[here] || 0, all = Object.keys(c).reduce((a, k) => a + c[k], 0);
    nBtn.hidden = !n && !all;
    nBtn.innerHTML = I.talk + (n ? '<span>' + n + '</span>' : '');
    const say = n ? 'Feedback on this screen · ' + n : 'All feedback';
    nBtn.setAttribute('aria-label', say);
    nBtn.title = say;
    nBtn.dataset.ogcN = String(n);
  }
  let countsP = null;
  function refreshCounts(fresh) {
    if (!fresh && counts && Date.now() - counts.t < 15000) { drawCount(); return Promise.resolve(); }
    if (countsP) return countsP;
    countsP = API.counts().then(c => { counts = { t: Date.now(), c }; SS.set('ogc-fb-counts', counts); drawCount(); }, () => { drawCount(); })
      .then(() => { countsP = null; });
    return countsP;
  }

  function mount(d) {
    dock = d;
    const st = document.createElement('style');
    st.textContent = d.scope ? d.scope(css) : css;
    document.head.appendChild(st);
    nBtn = document.createElement('button');
    nBtn.type = 'button';
    nBtn.className = 'ogc-fb-n';
    nBtn.hidden = true;
    nBtn.setAttribute('aria-haspopup', 'dialog');
    nBtn.setAttribute('aria-expanded', 'false');
    goBtn = document.createElement('button');
    goBtn.type = 'button';
    goBtn.className = 'ogc-fb-go';
    goBtn.setAttribute('aria-haspopup', 'dialog');
    goBtn.setAttribute('aria-expanded', 'false');
    goBtn.title = 'Leave feedback on this screen';
    goBtn.innerHTML = '<span class="ogc-fb-go__in">' + I.plus + '<span class="ogc-fb-go__l">Leave feedback</span><span class="ogc-fb-go__s">Feedback</span></span>';
    d.slot.append(nBtn, goBtn);
    d.slot.hidden = false;
    drawCount();
    refreshCounts(false);
    // The count opens this screen's ideas; the plain icon (none here, some elsewhere) opens the board on
    // its screens.
    nBtn.addEventListener('click', () => { if (board.open) closeBoard(); else openBoard(+nBtn.dataset.ogcN ? here : '', nBtn); });
    goBtn.addEventListener('click', () => { if (comp.open) closeComposer(); else openComposer(); });
    // The app changes its address as people move about in it: the count follows the screen.
    const follow = () => { const k = screenKey(); if (k !== here) { here = k; drawCount(); } };
    addEventListener('popstate', follow);
    setInterval(follow, 700);
    document.addEventListener('visibilitychange', () => { if (!document.hidden) refreshCounts(false); });
    // Something of ours is open: an Escape closes it, never a sheet under it (ogc-dev-nav's root).
    if (d.onBusy) d.onBusy(() => comp.open || board.open || !!lightbox);
    if (d.lift) setTimeout(d.lift, 50);
  }

  /* ------------------------------------------------------------------ the composer */

  const comp = { open: false, el: null, shot: null, pin: null, removed: false, busy: false, failed: false, ctx: null, img: '', sending: false, token: 0 };

  function openComposer() {
    closeBoard(false);
    comp.ctx = context();
    comp.pin = null;
    comp.removed = false;
    comp.failed = false;
    comp.shot = null;
    comp.img = '';
    if (!comp.el) {
      comp.el = ui('section', 'ogc-fbc');
      comp.el.setAttribute('role', 'dialog');
      comp.el.setAttribute('aria-labelledby', 'ogc-fbc-h');
      comp.el.hidden = true;
      comp.el.addEventListener('click', onComposerClick);
      comp.el.addEventListener('keydown', e => { if (e.key === 'Escape') { e.preventDefault(); closeComposer(true); } else if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) { e.preventDefault(); send(); } });
      comp.el.addEventListener('input', e => { if (e.target.getAttribute('aria-invalid') === 'true') { e.target.removeAttribute('aria-invalid'); const er = comp.el.querySelector('#' + e.target.id + '-e'); if (er) er.textContent = ''; } });
    }
    layer().appendChild(comp.el);
    comp.el.innerHTML = composerHtml();
    comp.el.hidden = false;
    comp.open = true;
    goBtn.setAttribute('aria-expanded', 'true');
    document.documentElement.classList.add('ogc-fb-composing');
    take();
    // On a laptop, straight into the words; on a phone no field takes focus by itself (the keyboard).
    if (!touchy() && !narrow()) comp.el.querySelector('textarea').focus();
    else comp.el.querySelector('h2').focus();
  }
  function closeComposer(back) {
    if (!comp.open) return;
    comp.open = false;
    comp.token++;
    comp.el.hidden = true;
    goBtn.setAttribute('aria-expanded', 'false');
    document.documentElement.classList.remove('ogc-fb-composing');
    if (back !== false) goBtn.focus();
  }
  function composerHtml() {
    const c = comp.ctx || {};
    const ctx = [c.title, dayShort(c.moment), c.as].filter(Boolean).join(' · ');
    return '<header class="ogc-fbc__head"><h2 id="ogc-fbc-h" tabindex="-1">Leave feedback</h2><button type="button" class="ogc-fbx" data-ogc-a="close" aria-label="Close">' + I.x + '</button></header>' +
      (ctx ? '<p class="ogc-fbc__ctx" title="Sent with it">' + esc(ctx) + '</p>' : '') +
      '<div class="ogc-fbc__pic"></div>' +
      '<label for="ogc-fbc-t">Your idea</label>' +
      '<textarea id="ogc-fbc-t" rows="4" maxlength="4000" placeholder="What would make this better?" aria-describedby="ogc-fbc-t-e"></textarea>' +
      '<p class="ogc-fb-err" id="ogc-fbc-t-e"></p>' +
      '<label for="ogc-fbc-n">Your name</label>' +
      '<input type="text" id="ogc-fbc-n" maxlength="60" autocomplete="name" value="' + esc(API.name()) + '" aria-describedby="ogc-fbc-n-e">' +
      '<p class="ogc-fb-err" id="ogc-fbc-n-e"></p>' +
      '<div class="ogc-fbc__foot"><span class="ogc-fbc__status" role="status" aria-live="polite"></span><button type="button" class="ogc-fbq" data-ogc-a="close">Cancel</button><button type="button" class="ogc-fbp" data-ogc-a="send">Send</button></div>';
  }
  // The picture's part of the composer, as things stand.
  function drawPic() {
    if (!comp.el) return;
    const box = comp.el.querySelector('.ogc-fbc__pic');
    if (!box) return;
    const pinLine = comp.pin && comp.pin.label ? '<p class="ogc-fbc__pin">Pointed at “' + esc(comp.pin.label) + '”</p>' : '';
    if (comp.busy) {
      box.innerHTML = '<div class="ogc-fbc__shot ogc-fbc__shot--wait" aria-busy="true"><span class="ogc-fbc__ph">Capturing screen</span></div>';
    } else if (comp.shot && !comp.removed) {
      box.innerHTML = '<div class="ogc-fbc__shot"><img alt="Screenshot of this screen" src="' + esc(comp.img || comp.shot.url) + '"></div>' +
        '<div class="ogc-fbc__tools"><button type="button" class="ogc-fbq ogc-fbq--chip" data-ogc-a="point" title="Tap the thing on the page you mean">' + (comp.pin ? 'Point again' : 'Point to it') + '</button>' +
        '<button type="button" class="ogc-fbq ogc-fbq--chip" data-ogc-a="retake" title="Take the picture again, as the screen is now">Retake</button>' +
        '<button type="button" class="ogc-fbq ogc-fbq--chip" data-ogc-a="unshot">Remove</button>' + pinLine + '</div>';
    } else {
      box.innerHTML = '<div class="ogc-fbc__tools">' + (comp.failed ? '' : '<button type="button" class="ogc-fbq ogc-fbq--chip" data-ogc-a="retake">Add screenshot</button>') +
        '<button type="button" class="ogc-fbq ogc-fbq--chip" data-ogc-a="point" title="Tap the thing on the page you mean">' + (comp.pin ? 'Point again' : 'Point to it') + '</button>' + pinLine + '</div>';
    }
  }
  async function take(after) {
    const t = ++comp.token;
    comp.busy = true;
    comp.removed = false;
    drawPic();
    let shot = null;
    try { shot = await captureOne(); comp.failed = false; } catch (e) { shot = null; comp.failed = true; }
    if (t !== comp.token) return; // closed, or taken again, meanwhile
    comp.busy = false;
    comp.shot = shot;
    if (after) after();
    comp.img = shot ? await withPin(shot, comp.pin) : '';
    if (t !== comp.token) return;
    drawPic();
  }

  // Point to it: the composer steps aside; the next tap marks what it was on (in a sheet too: the layer
  // is in the dock's root, over the sheet).
  function aim() {
    comp.el.hidden = true;
    document.documentElement.classList.add('ogc-fb-aiming');
    const lay = ui('div', 'ogc-fba');
    const box = ui('div', 'ogc-fba__box');
    const tip = ui('div', 'ogc-fba__tip', '<span>Tap what you mean</span><button type="button" class="ogc-fbq">Cancel</button>');
    tip.setAttribute('role', 'status');
    layer().append(lay, box, tip);
    const under = (x, y) => {
      lay.style.pointerEvents = 'none'; box.style.display = 'none';
      let el = document.elementFromPoint(x, y);
      lay.style.pointerEvents = '';
      // A sheet's backdrop is the sheet itself to the pointer: nothing there.
      if (el && el.tagName === 'DIALOG') { const b = el.getBoundingClientRect(); if (x < b.left || x > b.right || y < b.top || y > b.bottom) el = null; }
      return el && !el.closest('[data-ogc-tool]') ? el : null;
    };
    const target = el => { if (!el) return null; const m = el.closest('a,button,input,select,textarea,label,summary,[role=button],img,svg,h1,h2,h3,h4,li,tr,p') || el; return m === document.body || m === document.documentElement ? null : m; };
    const finish = () => {
      lay.remove(); box.remove(); tip.remove();
      document.removeEventListener('keydown', onKey, true);
      document.documentElement.classList.remove('ogc-fb-aiming');
      if (comp.open) { comp.el.hidden = false; const p = comp.el.querySelector('[data-ogc-a="point"]'); (p || comp.el.querySelector('h2')).focus(); }
    };
    const onKey = e => { if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); finish(); } };
    document.addEventListener('keydown', onKey, true);
    tip.querySelector('button').addEventListener('click', finish);
    lay.addEventListener('pointermove', e => {
      if (e.pointerType !== 'mouse') return;
      const el = target(under(e.clientX, e.clientY));
      if (!el) { box.style.display = 'none'; return; }
      const r = el.getBoundingClientRect();
      Object.assign(box.style, { display: 'block', left: (r.left - 3) + 'px', top: (r.top - 3) + 'px', width: (r.width + 6) + 'px', height: (r.height + 6) + 'px' });
    });
    lay.addEventListener('click', async e => {
      e.preventDefault();
      const el = target(under(e.clientX, e.clientY));
      const r = el ? el.getBoundingClientRect() : null;
      const pin = { label: labelOf(el || under(e.clientX, e.clientY)), px: e.clientX + scrollX, py: e.clientY + scrollY, box: r ? [r.left + scrollX, r.top + scrollY, r.width, r.height] : null };
      finish();
      setPin(pin);
    });
  }
  // A pin at a place on the page: on the picture when the picture holds it, else the picture again first.
  function setPin(p) {
    const fit = s => s && p.px >= s.sx && p.px <= s.sx + s.w && p.py >= s.sy && p.py <= s.sy + s.h;
    const place = () => {
      const s = comp.shot && !comp.removed ? comp.shot : null;
      const ox = s ? s.sx : scrollX, oy = s ? s.sy : scrollY, w = s ? s.w : innerWidth, h = s ? s.h : innerHeight;
      comp.pin = {
        label: p.label, cx: p.px - ox, cy: p.py - oy,
        box: p.box ? [p.box[0] - ox, p.box[1] - oy, p.box[2], p.box[3]] : null,
        x: Math.round((p.px - ox) / w * 1000) / 10, y: Math.round((p.py - oy) / h * 1000) / 10
      };
    };
    if (comp.shot && !comp.removed && !fit(comp.shot)) { take(place); return; }
    place();
    if (comp.shot && !comp.removed) withPin(comp.shot, comp.pin).then(u => { comp.img = u; drawPic(); });
    else drawPic();
  }

  function onComposerClick(e) {
    const b = e.target.closest('[data-ogc-a]');
    if (!b) return;
    const a = b.getAttribute('data-ogc-a');
    if (a === 'close') closeComposer();
    else if (a === 'send') send();
    else if (a === 'point') aim();
    else if (a === 'retake') take();
    else if (a === 'unshot') { comp.removed = true; comp.img = ''; drawPic(); const p = comp.el.querySelector('[data-ogc-a="point"]'); if (p) p.focus(); }
  }
  function fieldError(id, msg) {
    const f = comp.el.querySelector('#' + id), er = comp.el.querySelector('#' + id + '-e');
    if (er) er.textContent = msg;
    if (f) { f.setAttribute('aria-invalid', msg ? 'true' : 'false'); if (msg) f.focus(); }
  }
  async function send() {
    if (comp.sending) return;
    const t = comp.el.querySelector('#ogc-fbc-t'), n = comp.el.querySelector('#ogc-fbc-n'), status = comp.el.querySelector('.ogc-fbc__status');
    const text = t.value.trim(), name = n.value.trim();
    fieldError('ogc-fbc-n', name ? '' : 'Add your name');
    fieldError('ogc-fbc-t', text ? '' : 'Write your idea');
    if (!text) { t.focus(); return; }
    if (!name) { n.focus(); return; }
    API.setName(name);
    const sendBtn = comp.el.querySelector('[data-ogc-a="send"]');
    comp.sending = true;
    sendBtn.disabled = true;
    status.textContent = comp.busy ? 'Waiting for the picture' : 'Sending';
    // A picture still being taken: wait for it (at most a few seconds).
    for (let i = 0; comp.busy && i < 60; i++) await new Promise(r => setTimeout(r, 100));
    status.textContent = 'Sending';
    const c = comp.ctx || context();
    const pin = comp.pin ? { x: comp.pin.x, y: comp.pin.y, label: comp.pin.label } : null;
    const image = comp.shot && !comp.removed ? (comp.img || comp.shot.url) : '';
    const fields = { name, text, screen: c.screen, title: c.title, page: c.page, at: c.at, moment: c.moment, as: c.as, size: c.size, pin, image };
    let item = null, err = null;
    try { item = await API.add(fields); } catch (e) { err = e; }
    // A picture the store won't take: the idea goes without it.
    if (err && err.code === 'image' && image) { try { item = await API.add(Object.assign({}, fields, { image: '' })); err = null; } catch (e) { err = e; } }
    comp.sending = false;
    sendBtn.disabled = false;
    if (err) {
      if (err.code === 'name') fieldError('ogc-fbc-n', errWords('name'));
      else if (err.code === 'text') fieldError('ogc-fbc-t', errWords('text'));
      status.textContent = err.code === 'name' || err.code === 'text' ? '' : errWords(err.code);
      return;
    }
    closeComposer(false);
    lastNew = item ? item.id : '';
    refreshCounts(true);
    toast('Sent', 'View', () => openBoard(c.screen, goBtn, { sel: lastNew }));
    goBtn.focus();
  }

  /* ------------------------------------------------------------------ the toast */

  let toastEl = null, toastT = 0;
  function toast(words, act, fn) {
    if (!toastEl) {
      toastEl = ui('div', 'ogc-fbt');
      toastEl.setAttribute('role', 'status');
    }
    layer().appendChild(toastEl);
    toastEl.classList.toggle('ogc-fbt--board', board.open);
    toastEl.innerHTML = '<span>' + esc(words) + '</span>' + (act ? '<button type="button" class="ogc-fbq">' + esc(act) + '</button>' : '');
    toastEl.hidden = false;
    const b = toastEl.querySelector('button');
    if (b) b.addEventListener('click', () => { toastEl.hidden = true; fn(); });
    clearTimeout(toastT);
    toastT = setTimeout(() => { toastEl.hidden = true; }, 6000);
  }

  /* ------------------------------------------------------------------ the board */

  // screen: the chosen screen's key; sel: the chosen idea; pane: on a phone, the one pane shown
  // ('screens' | 'list' | 'idea'). Each idea's reply form: reply[id].
  const board = { open: false, el: null, from: null, token: 0, items: null, admin: false, err: '', loading: false, filter: SS.get('ogc-fb-filter', 'open') === 'resolved' ? 'resolved' : 'open',
    screen: '', sel: '', pane: 'list', one: false, reply: {}, confirm: '', menu: false, keyForm: false, keyErr: '', overflow: null };
  let lastNew = '';
  const wideNow = () => innerWidth >= WIDE;

  function openBoard(screen, from, o) {
    o = o || {};
    closeComposer(false);
    board.from = from || null;
    board.items = null;
    board.err = '';
    board.menu = false;
    board.keyForm = false;
    board.confirm = '';
    board.reply = {};
    board.one = !wideNow();
    board.screen = screen || '';
    board.sel = o.sel || '';
    board.pane = board.one ? (board.sel ? 'idea' : screen ? 'list' : 'screens') : 'list';
    if (!board.el) {
      board.el = ui('div', 'ogc-fbb');
      board.el.setAttribute('role', 'dialog');
      board.el.setAttribute('aria-modal', 'true');
      board.el.setAttribute('aria-labelledby', 'ogc-fbb-h');
      board.el.hidden = true;
      board.el.addEventListener('click', onBoardClick);
      board.el.addEventListener('keydown', onBoardKey);
      board.el.addEventListener('submit', e => e.preventDefault());
      addEventListener('resize', () => { if (board.open && board.one !== !wideNow()) { board.one = !wideNow(); if (board.one) board.pane = board.sel ? 'idea' : 'list'; else autoPick(); drawBoard(); } });
    }
    layer().appendChild(board.el);
    if (toastEl) toastEl.hidden = true;
    board.open = true;
    board.el.hidden = false;
    nBtn.setAttribute('aria-expanded', 'true');
    board.overflow = document.documentElement.style.overflow;
    document.documentElement.style.overflow = 'hidden';
    drawBoard();
    board.el.querySelector('h2').focus();
    load();
  }
  function closeBoard(back) {
    if (!board.open) return;
    board.open = false;
    board.token++;
    board.el.hidden = true;
    nBtn.setAttribute('aria-expanded', 'false');
    document.documentElement.style.overflow = board.overflow || '';
    lastNew = '';
    const f = board.from;
    board.from = null;
    if (back !== false && f && document.contains(f) && !f.hidden) f.focus();
    refreshCounts(true);
  }
  function load() {
    const t = ++board.token;
    board.loading = true;
    board.err = '';
    drawPanes();
    API.list('*').then(r => {
      if (t !== board.token) return;
      board.items = r.items;
      board.admin = r.admin;
      board.loading = false;
      autoPick();
      drawBoard();
    }, e => {
      if (t !== board.token) return;
      board.loading = false;
      board.err = e.code || 'server';
      drawPanes();
    });
  }

  // The screens, as the filter shows them: this screen first (always, marked), then the most ideas.
  function screens() {
    const by = new Map();
    (board.items || []).forEach(x => { if (!by.has(x.screen)) by.set(x.screen, []); by.get(x.screen).push(x); });
    if (!by.has(here)) by.set(here, []);
    const list = [...by].map(([key, all]) => ({ key, all, items: all.filter(x => x.status === board.filter), name: nameOf(key, all.length ? all : [{ title: key === here ? screenTitle() : '' }]) }))
      .filter(s => s.key === here || s.key === board.screen || s.items.length);
    // Two screens of one name: each with what tells them apart.
    list.forEach(s => { if (list.some(o => o !== s && o.name === s.name)) s.name += ' · ' + (s.key.split('?')[1] || s.key).replace(/&/g, ' · '); });
    list.sort((a, b) => (b.key === here) - (a.key === here) || b.items.length - a.items.length || a.name.localeCompare(b.name));
    return list;
  }
  // A screen's ideas by person: the most ideas first, each person's in the order they left them.
  function people(items) {
    const groups = [];
    items.slice().sort((a, b) => a.created < b.created ? -1 : 1).forEach(x => {
      const k = String(x.name || '').trim().toLowerCase();
      let g = groups.find(y => y.k === k);
      if (!g) groups.push(g = { k, name: x.name, items: [] });
      g.items.push(x);
    });
    groups.sort((a, b) => b.items.length - a.items.length || (a.items[0].created < b.items[0].created ? -1 : 1));
    return groups;
  }
  const chosen = () => screens().find(s => s.key === board.screen) || null;
  // The ideas in the order the list shows them (for the arrows).
  const flat = () => { const s = chosen(); return s ? people(s.items).reduce((a, g) => a.concat(g.items), []) : []; };
  // On a laptop something is always chosen: a screen (this one when it has ideas, else the first that
  // does), and its first idea. On a phone nothing is chosen for them: they open what they tap.
  function autoPick() {
    if (!board.one && !board.screen) {
      const ss = screens(), h = ss.find(s => s.key === here);
      board.screen = h && h.items.length ? here : ((ss.find(s => s.items.length) || h || {}).key || here);
    }
    const f = flat();
    if (board.sel && !f.find(x => x.id === board.sel)) board.sel = '';
    if (!board.sel && !board.one && f.length) board.sel = f[0].id;
    if (board.one && board.pane === 'idea' && !board.sel) board.pane = board.screen ? 'list' : 'screens';
    if (board.one && board.pane === 'list' && !board.screen) board.pane = 'screens';
  }

  // The control that has the focus, as a selector that finds it again after the board is drawn anew.
  function focusKey() {
    const el = document.activeElement;
    if (!el || !board.el || !board.el.contains(el)) return '';
    if (el.id) return '#' + CSS.escape(el.id);
    if (el.tagName === 'H2' || el.tagName === 'H3') return el.tagName.toLowerCase() + (el.id ? '#' + el.id : '');
    const a = el.getAttribute('data-ogc-a');
    if (!a) return '';
    let s = '[data-ogc-a="' + a + '"]';
    ['data-ogc-id', 'data-ogc-v'].forEach(k => { const v = el.getAttribute(k); if (v) s += '[' + k + '="' + CSS.escape(v) + '"]'; });
    return s;
  }
  function refocus(k) {
    if (!k || (document.activeElement && board.el.contains(document.activeElement) && document.activeElement !== document.body)) return;
    const n = board.el.querySelector(k);
    if (n && n.getClientRects().length) n.focus({ preventScroll: true });
  }
  const focusIn = sel => { const el = board.el.querySelector(sel); if (el && el.getClientRects().length) { el.focus({ preventScroll: false }); return true; } return false; };

  function drawBoard() {
    if (!board.el) return;
    const fk = focusKey();
    // Each pane keeps its scroll through a drawing anew (a delete, a resolve, Admin).
    const kept = [...board.el.querySelectorAll('.ogc-fbb__pane')].map(p => [p.className, p.scrollTop, p.getAttribute('data-ogc-id')]);
    const one = board.one, s = chosen(), x = find(board.sel);
    board.el.classList.toggle('ogc-fbb--one', one);
    board.el.setAttribute('data-pane', one ? board.pane : 'all');
    const seg = '<div class="ogc-fbs" role="group" aria-label="Show">' + [['open', 'Open'], ['resolved', 'Resolved']].map(v => '<button type="button" data-ogc-a="filter" data-ogc-v="' + v[0] + '" aria-pressed="' + (board.filter === v[0]) + '">' + v[1] + '</button>').join('') + '</div>';
    const leave = '<button type="button" class="ogc-fbp ogc-fbp--sm" data-ogc-a="new" title="Leave feedback on this screen">' + I.plus + 'Leave feedback</button>';
    // On a phone the bar names the pane, with Back to the one before it.
    const title = !one || board.pane === 'screens' ? 'Feedback' : (s ? s.name : 'Feedback');
    const back = one && board.pane !== 'screens' ? '<button type="button" class="ogc-fbb__back" data-ogc-a="back" title="' + (board.pane === 'idea' ? 'Back to the ideas' : 'Back to the screens') + '">' + I.back + 'Back</button>' : '';
    let menu = '';
    if (board.keyForm) {
      menu = '<form class="ogc-fbb__menu ogc-fbb__key" data-ogc-a="keyform"><label for="ogc-fbb-key">Admin key</label><input type="password" id="ogc-fbb-key" autocomplete="off" spellcheck="false" aria-describedby="ogc-fbb-key-e"' + (board.keyErr ? ' aria-invalid="true"' : '') + '>' +
        '<p class="ogc-fb-err" id="ogc-fbb-key-e">' + esc(board.keyErr) + '</p><div><button type="button" class="ogc-fbq" data-ogc-a="nokey">Cancel</button><button type="submit" class="ogc-fbp ogc-fbp--sm" data-ogc-a="unlock">Unlock</button></div></form>';
    } else if (board.menu) {
      menu = '<div class="ogc-fbb__menu" role="menu">' + (board.admin ? '<button type="button" role="menuitem" class="ogc-fbq" data-ogc-a="unadmin">Exit admin</button>' : '<button type="button" role="menuitem" class="ogc-fbq" data-ogc-a="admin" title="Resolve and delete anyone’s ideas">Admin</button>') + '</div>';
    }
    board.el.innerHTML =
      '<header class="ogc-fbb__head">' + back + '<h2 id="ogc-fbb-h" tabindex="-1">' + esc(title) + (board.admin && (!one || board.pane === 'screens') ? '<span class="ogc-fbb__badge">Admin</span>' : '') + '</h2>' +
      (one ? '' : seg + leave) +
      '<button type="button" class="ogc-fbx" data-ogc-a="menu" aria-haspopup="true" aria-expanded="' + (board.menu || board.keyForm) + '" aria-label="More">' + I.more + '</button>' +
      '<button type="button" class="ogc-fbx" data-ogc-a="close" aria-label="Close" title="Esc">' + I.x + '</button>' + menu + '</header>' +
      (one && board.pane !== 'idea' ? '<div class="ogc-fbb__sub">' + seg + leave + '</div>' : '') +
      '<div class="ogc-fbb__panes">' +
      '<nav class="ogc-fbb__pane ogc-fbb__screens" aria-label="Screens"></nav>' +
      '<section class="ogc-fbb__pane ogc-fbb__list" aria-labelledby="ogc-fbl-h"></section>' +
      '<section class="ogc-fbb__pane ogc-fbb__idea" aria-label="Idea"' + (!x ? ' aria-hidden="true"' : '') + '></section></div>';
    kept.forEach(([cls, top, id]) => { const p = board.el.querySelector('.' + cls.split(' ').join('.')); if (p) { p.scrollTop = top; if (id) p.setAttribute('data-ogc-id', id); } });
    drawPanes();
    refocus(fk);
  }
  // The three panes' insides, each keeping its own scroll.
  function drawPanes() {
    if (!board.el || !board.el.querySelector('.ogc-fbb__panes')) return;
    const fk = focusKey();
    drawScreens(); drawList(); drawIdea();
    refocus(fk);
  }
  function keepScroll(pane, html) {
    const t = pane.scrollTop;
    pane.innerHTML = html;
    pane.scrollTop = t;
  }
  function drawScreens() {
    const pane = board.el.querySelector('.ogc-fbb__screens');
    if (!pane) return;
    if (board.loading && !board.items) return keepScroll(pane, '');
    if (board.err) return keepScroll(pane, '');
    const ss = screens();
    keepScroll(pane, '<p class="ogc-fbb__cap" id="ogc-fbs-h">Screens</p><ul aria-labelledby="ogc-fbs-h">' + ss.map(s => {
      const n = s.items.length;
      return '<li><button type="button" class="ogc-fbsc" data-ogc-a="screen" data-ogc-v="' + esc(s.key) + '" aria-current="' + (s.key === board.screen) + '" title="' + esc(s.key) + '">' +
        '<span class="ogc-fbsc__n"><b>' + esc(s.name) + '</b>' + (s.key === here ? '<small>This screen</small>' : '') + '</span>' +
        (n ? '<span class="ogc-fbsc__c" aria-label="' + n + (board.filter === 'open' ? ' open' : ' resolved') + '">' + n + '</span>' : '') + '</button></li>';
    }).join('') + '</ul>');
  }
  function drawList() {
    const pane = board.el.querySelector('.ogc-fbb__list');
    if (!pane) return;
    if (board.loading && !board.items) return keepScroll(pane, '<p class="ogc-fbb__line" role="status">Loading</p>');
    if (board.err) return keepScroll(pane, '<p class="ogc-fbb__line" role="status">' + esc(errWords(board.err)) + '</p><p style="text-align:center"><button type="button" class="ogc-fbq ogc-fbq--chip" data-ogc-a="reload">Try again</button></p>');
    const s = chosen();
    if (!s) return keepScroll(pane, '');
    const n = s.items.length;
    const gs = people(s.items);
    // What tells this screen's ideas apart, said only when they differ: the Conference's year, the moment.
    const years = new Set(s.items.map(yearOf).filter(Boolean)), moments = new Set(s.items.map(x => momentName(x.moment)).filter(Boolean));
    const sub = [s.key === here ? 'This screen' : '', n ? n + ' ' + (board.filter === 'open' ? 'open' : 'resolved') : ''].filter(Boolean).join(' · ');
    let h = '<header class="ogc-fbl__head"><h3 id="ogc-fbl-h" tabindex="-1">' + esc(s.name) + '</h3>' + (sub ? '<p>' + esc(sub) + '</p>' : '') + '</header>';
    // Nothing to show here: what's true of it (resolved ones count as feedback left).
    if (!n) h += '<p class="ogc-fbb__line">' + (s.all.length ? (board.filter === 'resolved' ? 'Nothing resolved yet' : 'Nothing open') : s.key === here ? 'No feedback on this screen yet' : 'No feedback yet') + '</p>';
    gs.forEach((g, gi) => {
      h += '<section class="ogc-fbg" aria-labelledby="ogc-fbg-' + gi + '"><h4 class="ogc-fbg__who" id="ogc-fbg-' + gi + '">' + avatar(g.name, true) + esc(g.name) + ' <span>' + g.items.length + '</span></h4><ul>' +
        g.items.map(x => '<li>' + row(x, years.size > 1, moments.size > 1) + '</li>').join('') + '</ul></section>';
    });
    keepScroll(pane, h);
  }
  // One idea in the list: a thumbnail cropped around the pin, the words, then what's true of it.
  function row(x, showYear, showMoment) {
    const meta = [showYear ? yearOf(x) : '', showMoment ? momentName(x.moment) : '', dayShort(x.moment), deviceOf(x.size)].filter(Boolean).join(' · ');
    const stats = (x.votes ? '<span class="ogc-fbrow__s" title="Upvotes">' + I.up + x.votes + '</span>' : '') + (x.comments.length ? '<span class="ogc-fbrow__s" title="Replies">' + I.reply + x.comments.length + '</span>' : '');
    const px = x.pin ? Math.max(0, Math.min(100, x.pin.x)) : 50, py = x.pin ? Math.max(0, Math.min(100, x.pin.y)) : 0;
    const pic = x.thumb
      ? '<span class="ogc-fbrow__pic"><img src="' + esc(x.thumb) + '" alt="" loading="lazy" decoding="async" style="object-position:' + px + '% ' + py + '%' + (x.pin ? ';transform:scale(3);transform-origin:' + px + '% ' + py + '%' : '') + '"></span>'
      : '<span class="ogc-fbrow__pic ogc-fbrow__pic--none">' + I.text + '</span>';
    const say = [x.name, x.text.slice(0, 80), meta, x.votes ? x.votes + ' upvotes' : '', x.comments.length ? x.comments.length + ' replies' : ''].filter(Boolean).join(', ');
    return '<button type="button" class="ogc-fbrow' + (x.id === lastNew ? ' ogc-fbrow--new' : '') + '" data-ogc-a="pick" data-ogc-id="' + esc(x.id) + '" aria-current="' + (x.id === board.sel) + '" aria-label="' + esc(say) + '">' + pic +
      '<span class="ogc-fbrow__b"><span class="ogc-fbrow__t">' + esc(x.text) + '</span><span class="ogc-fbrow__m"><em>' + esc(meta) + '</em>' + stats + '</span></span></button>';
  }
  function drawIdea() {
    const pane = board.el.querySelector('.ogc-fbb__idea');
    if (!pane) return;
    const x = find(board.sel);
    if (!x || board.loading && !board.items || board.err) { pane.setAttribute('aria-hidden', 'true'); return keepScroll(pane, ''); }
    pane.removeAttribute('aria-hidden');
    const del = x.mine || board.admin, conf = board.confirm === 'i:' + x.id;
    // The day and person the pill held (as the pill says them), the device, and what was pointed at.
    const seen = [x.moment, noEmail(x.as), deviceOf(x.size)].filter(Boolean).join(' · ');
    const replies = x.comments.map(c => {
      const cc = board.confirm === 'c:' + c.id;
      return '<div class="ogc-fbth__one"><header>' + avatar(c.name, true) + '<b>' + esc(c.name) + '</b><span>' + esc(ago(c.created)) + '</span>' +
        (c.mine || board.admin ? '<button type="button" class="ogc-fbq' + (cc ? ' ogc-fbq--danger' : '') + '" data-ogc-a="delc" data-ogc-id="' + esc(c.id) + '" data-ogc-item="' + esc(x.id) + '">' + (cc ? 'Confirm delete' : 'Delete') + '</button>' : '') +
        '</header><p>' + esc(c.text) + '</p></div>';
    }).join('');
    const form = board.reply[x.id] ? replyForm(x.id) : '';
    const html = '<article class="ogc-fbd" data-ogc-id="' + esc(x.id) + '">' +
      '<header class="ogc-fbd__top">' + avatar(x.name) + '<div><h3 id="ogc-fbd-h" tabindex="-1">' + esc(x.name) + '</h3><span>' + esc(ago(x.created)) + '</span></div>' + (x.status === 'resolved' ? '<span class="ogc-fbd__res">Resolved</span>' : '') + '</header>' +
      (x.image || x.thumb ? '<button type="button" class="ogc-fbd__pic" data-ogc-a="pic" data-ogc-src="' + esc(x.image || x.thumb) + '" aria-label="Enlarge the screenshot"><img src="' + esc(x.image || x.thumb) + '" alt="Screenshot" decoding="async"></button>' : '') +
      '<p class="ogc-fbd__text">' + esc(x.text) + '</p>' +
      (seen ? '<p class="ogc-fbd__at">' + esc(seen) + '</p>' : '') +
      (x.pin && x.pin.label ? '<p class="ogc-fbd__at ogc-fbd__pin" title="' + esc(x.pin.label) + '">Pointed at “' + esc(x.pin.label) + '”</p>' : '') +
      '<div class="ogc-fbd__acts"><button type="button" class="ogc-fb-up" data-ogc-a="vote" data-ogc-id="' + esc(x.id) + '" aria-pressed="' + x.voted + '" aria-label="Upvote' + (x.votes ? ', ' + x.votes : '') + '" title="' + (x.voted ? 'Upvoted' : 'Upvote') + '">' + I.up + '<span>' + (x.votes ? x.votes : 'Upvote') + '</span></button>' +
      '<button type="button" class="ogc-fbq" data-ogc-a="reply" data-ogc-id="' + esc(x.id) + '" aria-expanded="' + !!board.reply[x.id] + '">Reply</button>' +
      (x.page ? '<button type="button" class="ogc-fbq" data-ogc-a="goto" data-ogc-id="' + esc(x.id) + '" title="That screen, on the day and as the person it was left on">Go to screen</button>' : '') +
      '<span class="ogc-fbd__sp"></span>' +
      (board.admin ? '<button type="button" class="ogc-fbq" data-ogc-a="' + (x.status === 'resolved' ? 'reopen' : 'resolve') + '" data-ogc-id="' + esc(x.id) + '">' + (x.status === 'resolved' ? 'Reopen' : 'Resolve') + '</button>' : '') +
      (del ? '<button type="button" class="ogc-fbq' + (conf ? ' ogc-fbq--danger' : '') + '" data-ogc-a="deli" data-ogc-id="' + esc(x.id) + '">' + (conf ? 'Confirm delete' : 'Delete') + '</button>' : '') +
      '</div>' + (replies || form ? '<div class="ogc-fbth">' + replies + form + '</div>' : '') + '</article>';
    if (pane.getAttribute('data-ogc-id') !== x.id) { pane.innerHTML = html; pane.scrollTop = 0; pane.setAttribute('data-ogc-id', x.id); } else keepScroll(pane, html);
  }
  function replyForm(id) {
    const r = board.reply[id] || {};
    return '<form class="ogc-fbth__form" data-ogc-a="replyform" data-ogc-id="' + esc(id) + '">' +
      '<label for="ogc-fbr-t-' + esc(id) + '">Your reply</label><textarea id="ogc-fbr-t-' + esc(id) + '" rows="3" maxlength="2000" aria-describedby="ogc-fbr-t-' + esc(id) + '-e">' + esc(r.text || '') + '</textarea>' +
      '<p class="ogc-fb-err" id="ogc-fbr-t-' + esc(id) + '-e">' + esc(r.tErr || '') + '</p>' +
      '<label for="ogc-fbr-n-' + esc(id) + '">Your name</label><input type="text" id="ogc-fbr-n-' + esc(id) + '" maxlength="60" autocomplete="name" value="' + esc(r.name != null ? r.name : API.name()) + '" aria-describedby="ogc-fbr-n-' + esc(id) + '-e">' +
      '<p class="ogc-fb-err" id="ogc-fbr-n-' + esc(id) + '-e">' + esc(r.nErr || '') + '</p>' +
      '<div class="ogc-fbc__foot"><span class="ogc-fbc__status" role="status">' + esc(r.status || '') + '</span><button type="button" class="ogc-fbq" data-ogc-a="noreply" data-ogc-id="' + esc(id) + '">Cancel</button><button type="submit" class="ogc-fbp ogc-fbp--sm" data-ogc-a="sendreply" data-ogc-id="' + esc(id) + '">Reply</button></div></form>';
  }
  const find = id => (board.items || []).find(x => x.id === id);
  // Keep what's typed in an open reply before drawing again.
  function keepReplies() {
    if (!board.el) return;
    Object.keys(board.reply).forEach(id => {
      const t = board.el.querySelector('#ogc-fbr-t-' + CSS.escape(id)), n = board.el.querySelector('#ogc-fbr-n-' + CSS.escape(id));
      if (t) board.reply[id].text = t.value;
      if (n) board.reply[id].name = n.value;
    });
  }
  const redraw = () => { keepReplies(); drawPanes(); };
  // The chosen idea and its row, without drawing the list again (its pictures stay as they are).
  function pick(id, how) {
    keepReplies();
    board.sel = id;
    board.confirm = '';
    board.el.querySelectorAll('.ogc-fbrow').forEach(b => b.setAttribute('aria-current', String(b.getAttribute('data-ogc-id') === id)));
    if (board.one) { if (how !== 'key-move') { board.pane = 'idea'; drawBoard(); focusIn('#ogc-fbd-h'); return; } }
    drawIdea();
    const r = board.el.querySelector('.ogc-fbrow[data-ogc-id="' + CSS.escape(id) + '"]');
    if (r) r.scrollIntoView({ block: 'nearest' });
    if (how === 'enter') focusIn('#ogc-fbd-h');
    else if (how === 'key-move' && r) r.focus({ preventScroll: true });
  }
  function chooseScreen(key) {
    keepReplies();
    board.screen = key;
    board.sel = '';
    board.confirm = '';
    if (board.one) { board.pane = 'list'; drawBoard(); focusIn('#ogc-fbl-h'); return; }
    autoPick();
    drawPanes();
  }
  // After an idea leaves the list (deleted, resolved, reopened): the next one, else the one before.
  function pickNear(id) {
    const f = flat(), i = f.findIndex(x => x.id === id);
    return i < 0 ? '' : (f[i + 1] || f[i - 1] || {}).id || '';
  }
  function back() {
    if (board.pane === 'idea') { const id = board.sel; board.pane = 'list'; drawBoard(); if (!focusIn('.ogc-fbrow[data-ogc-id="' + CSS.escape(id) + '"]')) focusIn('#ogc-fbl-h'); return true; }
    if (board.pane === 'list') { const k = board.screen; board.pane = 'screens'; drawBoard(); if (!focusIn('[data-ogc-a="screen"][data-ogc-v="' + CSS.escape(k) + '"]')) focusIn('h2'); return true; }
    return false;
  }

  async function onBoardClick(e) {
    const b = e.target.closest('[data-ogc-a]');
    if (!b || b.tagName === 'FORM') { if ((board.menu || board.keyForm) && !e.target.closest('.ogc-fbb__menu')) { board.menu = false; board.keyForm = false; keepReplies(); drawBoard(); } return; }
    const a = b.getAttribute('data-ogc-a'), id = b.getAttribute('data-ogc-id') || '';
    if (a !== 'menu' && a !== 'admin' && a !== 'unlock' && board.menu) board.menu = false;
    if (a !== 'deli' && a !== 'delc') board.confirm = '';
    if (a === 'close') return closeBoard();
    if (a === 'back') return back();
    if (a === 'new') { closeBoard(false); return openComposer(); }
    if (a === 'menu') { board.menu = !(board.menu || board.keyForm); board.keyForm = false; keepReplies(); drawBoard(); return focusIn(board.menu ? '.ogc-fbb__menu button' : '[data-ogc-a="menu"]'); }
    if (a === 'admin') { board.menu = false; board.keyForm = true; board.keyErr = ''; keepReplies(); drawBoard(); return focusIn('#ogc-fbb-key'); }
    if (a === 'unadmin') { API.setAdminKey(''); board.admin = false; board.menu = false; keepReplies(); drawBoard(); return focusIn('h2'); }
    if (a === 'nokey') { board.keyForm = false; keepReplies(); drawBoard(); return focusIn('[data-ogc-a="menu"]'); }
    if (a === 'unlock') { e.preventDefault(); return unlock(); }
    if (a === 'filter') {
      board.filter = b.getAttribute('data-ogc-v'); SS.set('ogc-fb-filter', board.filter);
      board.sel = '';
      if (board.one && board.pane === 'idea') board.pane = 'list';
      keepReplies(); autoPick(); drawBoard(); return focusIn('[data-ogc-a="filter"][aria-pressed="true"]');
    }
    if (a === 'screen') return chooseScreen(b.getAttribute('data-ogc-v'));
    if (a === 'pick') return pick(id, e.detail === 0 ? 'enter' : 'click');
    if (a === 'reload') return load();
    if (a === 'pic') return enlarge(b.getAttribute('data-ogc-src'), b);
    if (a === 'goto') { const x = find(id); if (x && dockInfo().travel) dockInfo().travel(x.page, x.at, x.as); else if (x) location.href = home.replace(/\/$/, '') + x.page; return; }
    if (a === 'reply') { if (board.reply[id]) delete board.reply[id]; else board.reply[id] = {}; redraw(); return focusIn(board.reply[id] ? '#ogc-fbr-t-' + CSS.escape(id) : '[data-ogc-a="reply"][data-ogc-id="' + CSS.escape(id) + '"]'); }
    if (a === 'noreply') { delete board.reply[id]; redraw(); return focusIn('[data-ogc-a="reply"][data-ogc-id="' + CSS.escape(id) + '"]'); }
    if (a === 'sendreply') { e.preventDefault(); return reply(id); }
    if (a === 'vote') {
      const x = find(id);
      if (!x) return;
      // Shown at once; put back if the store says no.
      const was = { votes: x.votes, voted: x.voted };
      x.voted = !x.voted; x.votes = Math.max(0, x.votes + (x.voted ? 1 : -1));
      redraw(); focusIn('[data-ogc-a="vote"][data-ogc-id="' + CSS.escape(id) + '"]');
      try { const r = await API.vote(id); x.votes = r.votes; x.voted = r.voted; } catch (er) { Object.assign(x, was); toast(errWords(er.code)); }
      if (!board.open) return;
      redraw(); return focusIn('[data-ogc-a="vote"][data-ogc-id="' + CSS.escape(id) + '"]');
    }
    if (a === 'deli' || a === 'delc') {
      const k = (a === 'deli' ? 'i:' : 'c:') + id;
      if (board.confirm !== k) { board.confirm = k; redraw(); return focusIn('[data-ogc-a="' + a + '"][data-ogc-id="' + CSS.escape(id) + '"]'); }
      board.confirm = '';
      try {
        if (a === 'deli') {
          const next = pickNear(id);
          await API.removeItem(id);
          board.items = board.items.filter(x => x.id !== id);
          board.sel = board.one ? '' : next;
          if (board.one) board.pane = 'list';
          refreshCounts(true).then(() => { if (board.open) { keepReplies(); drawBoard(); } });
        } else { await API.removeComment(id); const x = find(b.getAttribute('data-ogc-item')); if (x) x.comments = x.comments.filter(c => c.id !== id); }
        toast('Deleted');
      } catch (er) { toast(errWords(er.code)); }
      if (!board.open) return;
      keepReplies(); autoPick(); drawBoard();
      return a === 'deli' ? (focusIn('.ogc-fbrow[aria-current="true"]') || focusIn('#ogc-fbl-h')) : focusIn('#ogc-fbd-h');
    }
    if (a === 'resolve' || a === 'reopen') {
      try {
        const next = pickNear(id);
        const st = await API[a](id);
        const x = find(id);
        if (x) x.status = st;
        // It leaves this list (Open or Resolved): the next idea is chosen.
        if (x && x.status !== board.filter) { board.sel = board.one ? '' : next; if (board.one) board.pane = 'list'; }
        toast(a === 'resolve' ? 'Resolved' : 'Reopened');
        refreshCounts(true).then(() => { if (board.open) { keepReplies(); drawBoard(); } });
      } catch (er) { toast(errWords(er.code)); }
      if (!board.open) return;
      keepReplies(); autoPick(); drawBoard();
      return focusIn('.ogc-fbrow[aria-current="true"]') || focusIn('#ogc-fbl-h');
    }
  }
  async function unlock() {
    const f = board.el.querySelector('#ogc-fbb-key');
    const k = f ? f.value.trim() : '';
    if (!k) { board.keyErr = 'Type the admin key'; drawBoard(); return focusIn('#ogc-fbb-key'); }
    let ok = false;
    try { ok = await API.checkAdmin(k); } catch (er) { board.keyErr = errWords(er.code); drawBoard(); return focusIn('#ogc-fbb-key'); }
    if (!ok) { board.keyErr = 'Not the admin key'; drawBoard(); return focusIn('#ogc-fbb-key'); }
    board.keyForm = false;
    board.keyErr = '';
    board.admin = true;
    keepReplies();
    drawBoard();
    focusIn('h2');
    load();
  }
  async function reply(id) {
    keepReplies();
    const r = board.reply[id];
    if (!r) return;
    const text = String(r.text || '').trim(), name = String(r.name != null ? r.name : API.name()).trim();
    r.tErr = text ? '' : 'Write your reply';
    r.nErr = name ? '' : 'Add your name';
    if (!text || !name) { redraw(); return focusIn('#ogc-fbr-' + (!text ? 't' : 'n') + '-' + CSS.escape(id)); }
    API.setName(name);
    r.status = 'Sending';
    redraw();
    try {
      const c = await API.comment(id, name, text);
      const x = find(id);
      if (x) x.comments.push(c);
      delete board.reply[id];
      if (!board.open) return;
      redraw();
      focusIn('[data-ogc-a="reply"][data-ogc-id="' + CSS.escape(id) + '"]');
    } catch (er) {
      r.status = '';
      if (er.code === 'name') r.nErr = errWords('name'); else if (er.code === 'text') r.tErr = 'Write your reply'; else r.status = errWords(er.code);
      redraw();
    }
  }
  function onBoardKey(e) {
    const t = e.target, typing = t && t.matches && t.matches('input, textarea, select, [contenteditable]');
    if (e.key === 'Escape') {
      e.preventDefault();
      if (board.keyForm || board.menu) { board.menu = false; board.keyForm = false; keepReplies(); drawBoard(); return focusIn('[data-ogc-a="menu"]'); }
      if (board.confirm) { board.confirm = ''; redraw(); return; }
      if (board.one && back()) return;
      return closeBoard();
    }
    if (e.key === 'Enter' && t.matches('#ogc-fbb-key')) { e.preventDefault(); return unlock(); }
    if (e.key === 'Enter' && (e.metaKey || e.ctrlKey) && t.closest('.ogc-fbth__form')) { e.preventDefault(); return reply(t.closest('.ogc-fbth__form').getAttribute('data-ogc-id')); }
    if (!typing && !e.altKey && !e.metaKey && !e.ctrlKey) {
      const k = e.key, down = k === 'ArrowDown' || k === 'j' || k === 'J', up = k === 'ArrowUp' || k === 'k' || k === 'K';
      // In Screens, the arrows move between screens (and choose them on a laptop).
      if ((k === 'ArrowDown' || k === 'ArrowUp') && t.closest('.ogc-fbb__screens')) {
        const all = [...board.el.querySelectorAll('.ogc-fbsc')], i = all.indexOf(t.closest('.ogc-fbsc'));
        const n = all[Math.max(0, Math.min(all.length - 1, i + (k === 'ArrowDown' ? 1 : -1)))];
        e.preventDefault();
        if (n && n !== all[i]) { if (!board.one) chooseScreen(n.getAttribute('data-ogc-v')); const m = board.el.querySelector('.ogc-fbsc[data-ogc-v="' + CSS.escape(n.getAttribute('data-ogc-v')) + '"]'); if (m) m.focus(); }
        return;
      }
      if ((down || up) && (!board.one || board.pane !== 'screens')) {
        const f = flat();
        if (!f.length) return;
        e.preventDefault();
        const i = f.findIndex(x => x.id === board.sel);
        const n = f[Math.max(0, Math.min(f.length - 1, i < 0 ? 0 : i + (down ? 1 : -1)))];
        if (!n) return;
        // On a phone's list, the arrows move the focus; in an idea, they show the next idea.
        if (board.one && board.pane === 'list') {
          const rows = [...board.el.querySelectorAll('.ogc-fbrow')], j = rows.indexOf(document.activeElement);
          const r = rows[Math.max(0, Math.min(rows.length - 1, j < 0 ? 0 : j + (down ? 1 : -1)))];
          if (r) r.focus();
          return;
        }
        if (board.one) { board.sel = n.id; board.confirm = ''; drawBoard(); focusIn('#ogc-fbd-h'); return; }
        pick(n.id, 'key-move');
        return;
      }
    }
    // Tab stays inside the board.
    if (e.key === 'Tab') {
      const f = [...board.el.querySelectorAll('button, input, textarea, [tabindex="0"], h2[tabindex]')].filter(x => x.getClientRects().length && !x.disabled);
      if (!f.length) return;
      const i = f.indexOf(document.activeElement);
      if (e.shiftKey && i <= 0) { e.preventDefault(); f[f.length - 1].focus(); } else if (!e.shiftKey && i === f.length - 1) { e.preventDefault(); f[0].focus(); }
    }
  }

  /* ------------------------------------------------------------------ the picture, enlarged */

  let lightbox = null;
  function enlarge(src, from) {
    if (!src) return;
    const l = ui('div', 'ogc-fbl', '<button type="button" class="ogc-fbx" aria-label="Close">' + I.x + '</button><img alt="Screenshot" src="' + esc(src) + '">');
    l.setAttribute('role', 'dialog');
    l.setAttribute('aria-modal', 'true');
    l.setAttribute('aria-label', 'Screenshot');
    layer().appendChild(l);
    lightbox = l;
    const done = () => { l.remove(); lightbox = null; document.removeEventListener('keydown', key, true); if (from && document.contains(from)) from.focus(); };
    const key = ev => { if (ev.key === 'Escape') { ev.preventDefault(); ev.stopPropagation(); done(); } else if (ev.key === 'Tab') { ev.preventDefault(); l.querySelector('button').focus(); } };
    document.addEventListener('keydown', key, true);
    l.addEventListener('click', done);
    l.querySelector('button').focus();
  }

  /* ------------------------------------------------------------------ start */

  // For the tests: the screen key rule and the screen names, as the board uses them.
  window.OGC_FEEDBACK.screenKey = screenKey;
  window.OGC_FEEDBACK.screenName = nameOf;
  const start = () => { if (!dock && window.OGC_DOCK) mount(window.OGC_DOCK); };
  if (window.OGC_DOCK) start(); else document.addEventListener('ogc-dock', start, { once: true });
})();
