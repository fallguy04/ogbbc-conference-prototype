/*
 * register.js — registering for the Annual Conference, and Your sign-ups (register area, Oct 10).
 *
 * Views, by address:
 *   ?year=2027                 the form: one page of sections that fold to a summary once done, so the
 *                              form is its own review; a bar at the bottom with the total and the one
 *                              next action. It follows who's coming (never a separate Young Folk path).
 *   ?view=mine                 Your sign-ups: every registration this email owns or manages, shifts,
 *                              teams, one calendar file. Sign in by a code or link sent by email.
 *   ?view=edit&id=…            Change a registration (pay only the difference, or a refund).
 *   ?view=done&id=…            Registered: the receipt.
 *   ?view=receipt&id=…         A receipt to print.
 *   ?approve=…                 A parent approving a Young Folk under 18 (alone, or when the grown-up
 *                              registering isn't the parent and chose "Ask a parent").
 *   ?checkout=…&t=…            (local only) the payment provider's checkout, stood in for.
 *
 * The server judges everything (includes/module-registration*.php): what's allowed, the price, what's
 * left, who may see what. This page mirrors its rules (settle, problems, priceOf) only so answers and
 * totals follow each tap; what is saved and charged is what the server works out.
 *
 * One update path (Michael, Oct 9: the people part was "really glitchy"): every change runs settle(),
 * then the whole view is drawn again as text and morphed into the page: only what changed is touched,
 * so the field being typed in keeps its focus, its keyboard and its place.
 */
(function () {
  'use strict';
  const O = window.OGC, esc = O.esc, SU = O.signups, W = window.OGC_WP || {};
  const root = document.getElementById('ogc-reg');
  const BASE = root.dataset.base;
  const q = new URLSearchParams(location.search);
  const reduced = () => window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const svg = d => '<svg class="wk-i" viewBox="0 0 24 24" aria-hidden="true"><path d="' + d + '" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  const I = {
    cal: svg('M7.5 3.5v3M16.5 3.5v3M4 9.5h16M5.5 5.5h13A1.5 1.5 0 0 1 20 7v11.5a1.5 1.5 0 0 1-1.5 1.5h-13A1.5 1.5 0 0 1 4 18.5V7a1.5 1.5 0 0 1 1.5-1.5Z'),
    pin: svg('M12 20.5s-6.5-5.4-6.5-10.8a6.5 6.5 0 0 1 13 0c0 5.4-6.5 10.8-6.5 10.8ZM12 12a2.3 2.3 0 1 0 0-4.6 2.3 2.3 0 0 0 0 4.6Z'),
    check: svg('m5.5 12.5 4 4 9-9'),
    clock: svg('M12 7.5V12l3 2M12 20.5a8.5 8.5 0 1 0 0-17 8.5 8.5 0 0 0 0 17Z'),
    plus: svg('M12 5v14M5 12h14'),
    minus: svg('M5 12h14'),
    x: svg('m6.5 6.5 11 11M17.5 6.5l-11 11'),
    lock: svg('M6.5 11h11v9h-11zM8.5 11V8a3.5 3.5 0 0 1 7 0v3'),
    mail: svg('M4 6.5h16v11H4zM4.5 7l7.5 6 7.5-6'),
    key: svg('M14.5 9.5a3.5 3.5 0 1 1-1-2.45M13.4 12.6 20 19.2M17.5 16.7l1.8-1.8M15.6 14.8l1.4-1.4'),
    bed: svg('M3.5 18.5v-11M3.5 14.5h17v4M20.5 14.5v-2a3 3 0 0 0-3-3h-7v5M7 12a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3Z'),
    hand: svg('M8 11V5.5a1.5 1.5 0 0 1 3 0V11M11 10V4.5a1.5 1.5 0 0 1 3 0V11M14 10.5V6a1.5 1.5 0 0 1 3 0v7.5a6 6 0 0 1-6 6h-.6a6 6 0 0 1-4.6-2.2L3.6 14.6a1.5 1.5 0 0 1 2.2-2L8 14.5V11'),
    trophy: svg('M8 4.5h8v5a4 4 0 0 1-8 0zM8 6.5H4.5v1a3 3 0 0 0 3.5 3M16 6.5h3.5v1a3 3 0 0 1-3.5 3M12 13.5v3M8.5 19.5h7M9.5 19.5l.5-3h4l.5 3'),
    info: svg('M12 20.5a8.5 8.5 0 1 0 0-17 8.5 8.5 0 0 0 0 17ZM12 11v5M12 8h.01'),
    card: svg('M3.5 6.5h17v11h-17zM3.5 10h17M7 14.5h4'),
    print: svg('M7 9V4h10v5M7 17H5a1.5 1.5 0 0 1-1.5-1.5v-5A1.5 1.5 0 0 1 5 9h14a1.5 1.5 0 0 1 1.5 1.5v5A1.5 1.5 0 0 1 19 17h-2M7 14h10v6H7z'),
    copy: svg('M9 9h10v11H9zM5 15V4h10'),
    people: svg('M4 20v-1.5A4.5 4.5 0 0 1 8.5 14h3a4.5 4.5 0 0 1 4.5 4.5V20M10 11a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7ZM16.5 4.3a3.5 3.5 0 0 1 0 6.4M18.5 14.2a4.5 4.5 0 0 1 2 3.8v2'),
    moon: svg('M19.5 14.5A8 8 0 0 1 9.5 4.5a8 8 0 1 0 10 10Z'),
    note: svg('M7 3.5h7.5L19 8v12.5H7zM14.5 3.5V8H19M10 12.5h6M10 16h6'),
    back: svg('M14.5 6.5 9 12l5.5 5.5'),
    up: svg('m6.5 14.5 5.5-5.5 5.5 5.5'),
    down: svg('m7 10 5 5 5-5'),
    hall: svg('M4.5 20.5v-15h10v15M14.5 9.5h5v11M3 20.5h18M7.5 8.5h1M10.5 8.5h1M7.5 11.5h1M10.5 11.5h1M7.5 14.5h1M10.5 14.5h1M8.5 20.5v-3h2v3'),
    out: svg('M10 4.5H5.5v15H10M14 8l4 4-4 4M18 12H9'),
    meal: svg('M6.5 3.5v5a2.5 2.5 0 0 0 5 0v-5M9 3.5v17M17 20.5v-17c-2 .8-3.5 3-3.5 6.5v4.5H17')
  };
  const say = document.createElement('p');
  say.className = 'ogc-sr';
  say.setAttribute('aria-live', 'polite');
  root.after(say);
  const tell = t => { say.textContent = ''; setTimeout(() => { say.textContent = t; }, 30); };
  // A short note at the foot of the screen for something just done ("Left shift" · "Server · Sat, May 29 ·
  // Edna"): seen, and heard (role status). It goes after 8 seconds, or with its ×.
  const toastEl = document.createElement('div');
  // The one toast (D2: shared/ogc-ui.css .ogc-toast); the rf- names stay as this script's hooks.
  toastEl.className = 'ogc ogc-toast rf-toast';
  toastEl.setAttribute('role', 'status');
  toastEl.hidden = true;
  document.body.appendChild(toastEl);
  let toastT = 0;
  const hideToast = () => { toastEl.hidden = true; document.body.classList.remove('has-rf-toast'); };
  // undo (optional): an Undo beside it for two minutes, as the volunteer page's Sign up and Leave have
  // (after the third critic, Oct 15); the note stays as long.
  function toast(text, line, undo) {
    clearTimeout(toastT);
    toastEl.innerHTML = '<p>' + I.check + '<span><b>' + esc(text) + '</b>' + (line ? '<small>' + esc(line) + '</small>' : '') + '</span></p>' + (undo ? '<button type="button" class="ogc-toast__b rf-toast__b" data-undo>Undo</button>' : '') + '<button type="button" class="ogc-toast__x rf-toast__x" aria-label="Close">' + I.x + '</button>';
    toastEl.hidden = false;
    document.body.classList.add('has-rf-toast');
    toastEl.querySelector('.rf-toast__x').onclick = hideToast;
    const u = toastEl.querySelector('[data-undo]');
    if (u) u.onclick = () => { u.disabled = true; undo(); };
    toastT = setTimeout(hideToast, undo ? 120000 : 8000);
  }

  const state = {
    year: q.get('year') || '', view: q.get('view') || 'form', asOf: (q.get('as-of') || '').slice(0, 10),
    row: null, model: null, F: null, cfg: {}, meals: [], shifts: [], days: [],
    floors: [], rooms: [], plans: {}, campus: null, mp: null,
    d: null, open: '', errors: {}, check: {}, ui: {}, editing: null, waitlist: false,
    verify: { step: '', email: '', code: '', to: '', err: '', busy: false, dev: '', retryAt: 0 },
    busy: false, barNote: '', undo: null, mine: null, step: 'contact', fromReview: false, mineErr: '', another: false, signin: { step: '', email: '', to: '', code: '', err: '', dev: '', retryAt: 0 }
  };

  /* ================================================================ talking to the server */

  const asOfQ = () => state.asOf ? 'as_of=' + encodeURIComponent(state.asOf) : '';
  const withQ = (path, extra) => { const p = [asOfQ(), extra || ''].filter(Boolean).join('&'); return path + (p ? (path.indexOf('?') > -1 ? '&' : '?') + p : ''); };
  const api = (m, p, b) => W.api(m, p, b);
  // Local walk-through only: the page's own addresses keep ?as-of (the date being previewed), so Register
  // another or Change doesn't land back on today. here() is for script navigation; links are fixed in draw().
  const devAsOf = () => !!(W.dev && state.asOf);
  const here = qs => '?' + qs + (devAsOf() && !/(^|&)as-of=/.test(qs) ? '&as-of=' + encodeURIComponent(state.asOf) : '');
  const keepAsOf = () => {
    if (!devAsOf()) return;
    root.querySelectorAll('a[href^="?"], a[href^="../volunteer/"], a[href^="../tournaments/"]').forEach(a => { const h = a.getAttribute('href'); if (!/[?&]as-of=/.test(h)) a.setAttribute('href', h + (h.indexOf('?') > -1 ? '&' : '?') + 'as-of=' + encodeURIComponent(state.asOf)); });
  };
  const idem = () => 'k' + Date.now().toString(36) + Math.random().toString(36).slice(2, 10);
  const loadForm = () => api('GET', withQ('reg/' + state.year + '/form')).then(F => { state.F = F; state.cfg = F.cfg || {}; return F; });
  // Signed in on this device (a code or a link): the page carries on with the new nonce.
  const signedIn = out => { W.nonce = out.nonce; W.me = out.me; };

  /* ================================================================ the draft */

  // A draft belongs to one person: its key names the signed-in email (a short hash), or "anon" before
  // anyone has confirmed one. Signing in as someone else in the same tab never shows the last person's
  // household (polish 1: the Hoovers' children appeared for the next person to sign in).
  const hashOf = t => { let h = 2166136261; for (let i = 0; i < t.length; i++) { h ^= t.charCodeAt(i); h = Math.imul(h, 16777619); } return (h >>> 0).toString(36); };
  const meKey = () => { const me = SU.me(); return me && !me.pending ? hashOf(String(me.email).toLowerCase()) : 'anon'; };
  const KEY = () => 'ogc-register-draft-' + state.year + (state.desk ? '-desk' : '') + '-' + meKey();
  // On load: drop every draft of this year that isn't this person's (a sign-in elsewhere in this tab).
  // An anonymous draft is carried into a sign-in only when it holds nothing from last year (no Reuse).
  function sweepDrafts() {
    try {
      const pre = 'ogc-register-draft-' + state.year, mine = KEY(), anon = pre + (state.desk ? '-desk' : '') + '-anon';
      if (mine !== anon && !sessionStorage.getItem(mine)) { const a = JSON.parse(sessionStorage.getItem(anon) || 'null'); if (a && !a.from && !a.owner) sessionStorage.setItem(mine, JSON.stringify(a)); }
      for (let i = sessionStorage.length - 1; i >= 0; i--) { const k = sessionStorage.key(i); if (k && k.indexOf(pre) === 0 && k !== mine) sessionStorage.removeItem(k); }
    } catch (e) { /* nothing kept */ }
  }
  const newPid = () => 'p' + Math.random().toString(36).slice(2, 10);
  // linens: a Young Folk in a hall orders their own packet (the server keeps it). lin: a packet for this
  // sleeper in the household's rooms (page only; sent as stay.linenFor). Both null until the household's
  // one linens choice says (polish 2: linens asked once, not once a person). roomSet: the room was chosen
  // by hand (else the rooms are balanced as people are added), page only.
  // ptSet: the preteen program's Yes or No was answered (page only; the answer itself is ptOff).
  const person = o => Object.assign({ pid: newPid(), name: '', kind: 'adult', age: '', band: 'adult', yf: false, yfHall: '', minor: false, ptOff: false, ptSet: false, preteen: false, nights: [], rooming: '', sleeps: 'hall', linens: null, lin: null, communing: false, room: null, roomSet: false, ground: false, walker: false, restroom: false, crib: false }, o || {});
  const blank = () => ({
    household: { name: '', contact: '', phone: '', email: '' },
    helper: { on: false, name: '', phone: '', email: '' },
    people: [],
    stay: { withHh: '', type: '', nights: [], days: [], perPerson: false, rooms: 1, roomsSet: false, linens: 0, linenChoice: '', linenFor: [], mattresses: 0, ground: false, walker: false, nearW: false, nearM: false, restroom: false, near: '', arrive: '', yfOk: false, ask: false, keys: [], needs: '', parentEmail: '', chosen: [], campers: 1, camperLen: '' },
    // every: Every meal is chosen (page only): the meals follow each person's stay as it changes.
    meals: { off: {}, who: {}, every: true },
    preteens: {}, contacts: [{ name: '', rel: '', phone: '' }, { name: '', rel: '', phone: '' }], pickupWho: [], pickupOther: '',
    gift: 0, pay: 'card', finished: []
  });
  function fresh() {
    const d = blank(), me = SU.me();
    if (me && !me.pending && !state.desk) Object.assign(d.household, { contact: me.name || '', email: me.email });
    // Nothing that costs money is chosen for them: the stay (and then its nights) waits for a choice.
    d.pay = state.desk ? 'checkin' : payChoices()[0][0];
    d.finished = ['meals'];   // every meal while here, until someone says otherwise (drawn as to come until stay is done)
    return d;
  }
  // How a household may pay today: Card (when a provider is set up) and Check until check_by; after that
  // the COA's late choice (late_pay): At check-in, or card only.
  function payChoices() {
    const F = state.F, o = [];
    // A member entering a household's change never takes a card (area-households-money H22): a check by
    // mail while checks are taken, or at check-in.
    if (state.forHh) return (F.late ? [] : [['check', 'Check']]).concat([['checkin', 'At check-in']]);
    if (F.card) o.push(['card', 'Card']);
    if (!F.late) o.push(['check', 'Check']);
    else if (F.latePay !== 'card' || !F.card) o.push(['checkin', 'At check-in']);
    return o;
  }
  const payOk = v => payChoices().some(o => o[0] === v);
  // A draft is kept in this tab (sessionStorage), and once the email is confirmed also on the server as
  // the person's own (reg/{y}/draft; polish 3: a grandmother who left Safari to read the code, or closed
  // the tab, typed everything again). Before it's confirmed, nothing leaves this tab.
  const signedNow = () => { const me = SU.me(); return !!(me && !me.pending); };
  const serverKeeps = () => signedNow() && !state.desk && !state.editing && state.view === 'form' && !!state.d && !!state.d.owner;
  function keep() {
    try { if (state.d && !state.editing) sessionStorage.setItem(KEY(), JSON.stringify(state.d)); } catch (e) { /* not kept */ }
    if (!serverKeeps()) return;
    clearTimeout(state.draftT);
    state.draftT = setTimeout(sendDraft, 1200);
  }
  function sendDraft(leaving) {
    clearTimeout(state.draftT);
    if (!serverKeeps()) return;
    const body = JSON.stringify({ data: state.d });
    if (body === state.draftSent) return;
    state.draftSent = body;
    const url = (W.rest || '/wp-json/ogc/v1/') + 'reg/' + state.year + '/draft';
    // keepalive: still sent while the tab closes or the phone switches to Mail.
    try { fetch(url, { method: 'PUT', credentials: 'same-origin', keepalive: !!leaving && body.length < 60000, headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': W.nonce || '' }, body }).catch(() => { state.draftSent = ''; }); } catch (e) { state.draftSent = ''; }
  }
  document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'hidden') sendDraft(true); });
  window.addEventListener('pagehide', () => sendDraft(true));
  function loadDraft() {
    try {
      const d = JSON.parse(sessionStorage.getItem(KEY())), me = SU.me();
      // A draft whose owner isn't the person signed in now is never shown.
      if (d && d.owner && !(me && !me.pending && SU.sameEmail(d.owner, me.email))) { dropDraft(); return null; }
      if (!d || !d.people) return null;
      const x = Object.assign(blank(), d, { stay: Object.assign(blank().stay, d.stay) });
      needsToPeople(x);
      return x;
    } catch (e) { return null; }
  }
  function dropDraft(server) {
    try { sessionStorage.removeItem(KEY()); } catch (e) { /* nothing kept */ }
    // Start over also clears the one kept for this person (registering clears it on the server's side).
    if (server && signedNow() && !state.desk) { clearTimeout(state.draftT); state.draftSent = ''; api('DELETE', 'reg/' + state.year + '/draft').catch(() => {}); }
  }
  // The draft kept for this person on the server (inlined with the page), when this tab has none.
  function serverDraft() {
    const P0 = W.preload && W.preload.draft, d = P0 && P0.data, me = SU.me();
    if (!d || !d.people || !me || me.pending || !d.owner || !SU.sameEmail(d.owner, me.email)) return null;
    state.draftSent = JSON.stringify({ data: d });
    const x = Object.assign(blank(), d, { stay: Object.assign(blank().stay, d.stay) });
    needsToPeople(x);
    return x;
  }
  // The answers a registration keeps (what the server cleans), from a saved one. reuse: last year's,
  // whose rooms are balanced again (a hand choice is only one made this year).
  const answersOf = (data, reuse) => {
    const d = JSON.parse(JSON.stringify(data)), b = blank();
    ['household', 'helper', 'people', 'meals', 'preteens', 'contacts', 'pickupWho', 'pickupOther', 'gift', 'pay'].forEach(k => { if (d[k] == null) d[k] = b[k]; });
    d.stay = Object.assign(b.stay, d.stay || {});
    d.meals = { off: Object.assign({}, d.meals.off), who: Object.assign({}, d.meals.who) };
    // Every meal or not: last year's with no meal skipped is this year's Every meal (its stay may differ);
    // a saved one is read from its meals as they are (settle), so opening Change never changes them.
    if (reuse && !Object.keys(d.meals.off).length && !Object.keys(d.meals.who).length) d.meals.every = true;
    if (!Array.isArray(d.contacts) || d.contacts.length < 2) d.contacts = b.contacts.map((c, i) => Object.assign(c, (d.contacts || [])[i] || {}));
    if (Array.isArray(d.preteens)) d.preteens = {};
    // A saved (or last year's) registration has made these choices already: who has a packet in the
    // rooms (linenFor, or the first so many sleepers for one saved before it was kept by name).
    const s = d.stay, sl = (d.people || []).filter(p => String(p.name || '').trim() && p.band !== 'baby' && !(p.yf && (s.type === 'yf' || p.sleeps !== 'family')));
    const forSet = new Set(Array.isArray(s.linenFor) && s.linenFor.length ? s.linenFor : s.type === 'dorm' ? sl.slice(0, +s.linens || 0).map(p => p.pid) : []);
    d.keep_next_year = !!d.keep_next_year;
    needsToPeople(d);
    (d.people || []).forEach(p => {
      // Who sleeps where is kept as it was (last year's too: as much as possible carries).
      p.roomSet = p.room != null;
      // A saved answer stands (a child new to the program this year is asked: applyReuse).
      p.ptSet = true;
      p.lin = s.linenChoice ? forSet.has(p.pid) : null;
      if (p.yf && s.linenChoice) p.linens = !!p.linens;
    });
    return d;
  };

  // A registration saved before the boxes were each person's (household boxes only): each box goes to the
  // contact, or the first adult, so it's seen and can be changed (a mark is never lost or made up).
  function needsToPeople(d) {
    const s = d.stay || {}, ppl = (d.people || []).filter(p => String(p.name || '').trim()), ad = ppl.filter(p => (p.kind || (p.yf ? 'yf' : p.band === 'adult' ? 'adult' : 'child')) === 'adult');
    const to = ad.find(p => p.name.trim() === String((d.household || {}).contact || '').trim()) || ad[0];
    if (!to) return;
    if (s.ground && !ppl.some(p => p.ground)) to.ground = true;
    if (s.walker && !ppl.some(p => p.walker)) to.walker = true;
    if ((s.restroom || s.nearW || s.nearM) && !ppl.some(p => p.restroom)) to.restroom = true;
  }

  /* ================================================================ rules (mirroring the server's) */

  const C = k => state.cfg[k] || '';
  const cents = k => { const v = state.cfg[k]; return v !== undefined && v !== '' && !isNaN(+v) ? Math.round(+v * 100) : 0; };
  const $ = c => (c < 0 ? '−' : '') + SU.money(Math.abs(c) / 100);
  const plural = SU.plural;
  const first = n => String(n || '').trim().split(/\s+/)[0] || '';
  const firstL = n => SU.firstL(n);
  const nights = () => SU.nightsOf(state.cfg);
  const mainNights = () => SU.mainNights(state.cfg);
  const early = SU.isEarly;
  const named = () => state.d.people.filter(p => p.name.trim());
  const adults = () => named().filter(p => p.kind === 'adult');
  const yfs = () => named().filter(p => p.yf);
  const yfOnly = () => named().length > 0 && named().every(p => p.yf);
  const inHall = (p, d) => p.yf && (((d || state.d).stay || {}).type === 'yf' || p.sleeps !== 'family');
  const minorsAlone = () => !adults().length && named().some(p => p.minor);
  const beds = () => (+C('room_beds') || 2) + 1;
  const sleepers = d => (d || state.d).people.filter(p => p.name.trim() && p.band !== 'baby' && !inHall(p, d));
  const emailOk = e => /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(String(e || '').trim());
  const ptDays = () => C('preteen_days').split('|').map(s => s.trim()).filter(Boolean);
  const preteensOnline = () => C('preteen_details') !== 'paper';
  const dayIndex = n => { const k = String(n).slice(0, 3).toLowerCase(); return state.days.findIndex(d => d.name.slice(0, 3).toLowerCase() === k || d.date === n); };
  const nightDate = n => early(n) ? SU.earlyDate(n, (state.days[0] || {}).date) : ((state.days[dayIndex(n)] || {}).date || '');
  const nightsFor = (p, d) => (p.nights && p.nights.length) ? p.nights : (d.stay && d.stay.nights && d.stay.nights.length) ? d.stay.nights : p.yf ? mainNights() : [];
  const shortDate = iso => iso ? O.fmtDate(iso, 'short').replace(',', '') : '';
  // "Fri May 28 – Wed Jun 2": the first night's day to the morning after the last.
  const spanOf = ns => { if (!ns.length) return ''; const a = nightDate(ns[0]), b = O.isoAddDays(nightDate(ns[ns.length - 1]), 1); return shortDate(a) + ' – ' + shortDate(b); };
  const hallWord = h => h === 'women' ? 'Young women’s hall' : 'Young men’s hall';

  // The parts that follow from the answers: age groups, preteens, who's under 18, nights, rooms, keys.
  function settle(d) {
    d = d || state.d;
    d.people.forEach(p => {
      if (!p.pid) p.pid = newPid();
      p.yf = p.kind === 'yf';
      if (p.kind === 'adult') p.age = '';
      const a = /^\d{1,3}$/.test(String(p.age).trim()) ? +p.age : -1, ptAge = p.kind === 'child' && a >= 10 && a <= 13;
      p.band = p.kind !== 'child' ? 'adult' : a < 0 ? 'child' : a < 3 ? 'baby' : a <= 11 ? 'child' : 'adult';
      if (!ptAge) { p.ptOff = false; p.ptSet = false; }
      // In the preteen program once the household says Yes (Caleb, Oct 24: the form must ask it).
      p.preteen = ptAge && !!p.ptSet && !p.ptOff;
      p.minor = p.yf && a >= 0 && a < 18;
      if (!p.yf) { p.yfHall = ''; p.rooming = ''; p.sleeps = 'hall'; p.linens = false; p.lc = ''; }
      if (p.kind === 'child') p.communing = false;
      // A person's own needs (Oct 23): an adult's three boxes, a crib for a child under 3.
      if (p.kind !== 'adult') { p.ground = false; p.walker = false; p.restroom = false; }
      if (p.band !== 'baby') p.crib = false;
    });
    const s = d.stay, ppl = d.people.filter(p => p.name.trim()), only = ppl.length > 0 && ppl.every(p => p.yf);
    // The household's need boxes (what Lodging filters by, and the records' Needs) follow from its people's;
    // the two restroom boxes are one (decision 20 A), so nearW and nearM are no longer set by the form.
    s.ground = ppl.some(p => p.ground); s.walker = ppl.some(p => p.walker); s.restroom = ppl.some(p => p.restroom); s.nearW = false; s.nearM = false;
    // Young Folks on their own: their hall, a camper or off campus; a family: a dorm room, a camper or off campus.
    // A family's stay is never chosen for them: the hall stay, once a grown-up is added, waits for a choice.
    if (only && s.type === 'dorm') s.type = 'yf'; else if (!only && s.type === 'yf') s.type = '';
    if (!s.type) d.finished = d.finished.filter(k => k !== 'stay');
    // A Young Folk alone sleeps in their hall unless the stay says a camper or off campus (polish 2: they
    // were "with family" until the stay was chosen, so Rooming with was never asked going forward).
    d.people.forEach(p => { if (p.yf && s.type === 'yf') p.sleeps = 'hall'; else if (p.yf && only) p.sleeps = s.type === 'camper' || s.type === 'elsewhere' ? 'family' : 'hall'; });
    // A parent's approval for Young Folks under 18 in the halls: "I'm the parent" (yfOk) or "Ask a parent" (ask).
    const hallMinors = ppl.some(p => p.minor && inHall(p, d)), grown = ppl.some(p => p.kind === 'adult');
    if (!(grown && hallMinors)) { s.yfOk = false; s.ask = false; }
    if (s.ask) s.yfOk = false;
    if (s.type === 'elsewhere') s.nights = []; else s.days = [];
    d.people.forEach(p => { if (!s.perPerson || (s.type === 'elsewhere' && !inHall(p, d))) p.nights = []; });
    if (s.perPerson && s.type !== 'elsewhere') {
      const set = new Set();
      ppl.forEach(p => { if (s.type === 'yf' || !inHall(p, d)) p.nights.forEach(n => set.add(n)); });
      if (set.size) s.nights = nights().filter(n => set.has(n));
    }
    const sl = sleepers(d);
    if (s.type === 'dorm') {
      if (!s.roomsSet) s.rooms = Math.max(1, Math.min(6, Math.ceil(sl.length / beds())));
      // Who sleeps where: balanced by default, grown-ups first, one to a room in turn, so no child is
      // put alone in a room while grown-ups share; a room chosen by hand stays as chosen.
      d.people.forEach(p => { if (!p.name.trim() || p.band === 'baby' || inHall(p, d)) { p.room = null; p.roomSet = false; } else if (p.roomSet && (p.room == null || p.room >= s.rooms)) p.roomSet = false; });
      const count = Array(s.rooms).fill(0);
      sl.forEach(p => { if (p.roomSet) count[p.room]++; });
      sl.filter(p => !p.roomSet).sort((a, b) => (a.kind === 'child') - (b.kind === 'child')).forEach(p => {
        let r = 0; for (let i = 1; i < s.rooms; i++) if (count[i] < count[r]) r = i;
        p.room = r; count[r]++;
      });
      const ok = ppl.filter(p => p.kind === 'adult').map(p => p.name.trim());
      s.keys = Array.from({ length: s.rooms }, (_, i) => ok.indexOf(s.keys[i]) > -1 ? s.keys[i] : ok.length ? ok[i % ok.length] : d.household.contact);
    } else d.people.forEach(p => { p.room = null; });
    // Linens, asked once for the household: bring our own, or packets for those chosen (each sleeper in
    // the rooms, each Young Folk in a hall), every one chosen to start. The count follows the choices.
    const roomSl = s.type === 'dorm' ? sl : [], hall = ppl.filter(p => inHall(p, d)), req = C('linens_required') === 'yes' && s.type === 'dorm';
    if (!roomSl.length && !hall.length) s.linenChoice = '';
    if (req && roomSl.length) s.linenChoice = 'order';
    d.people.forEach(p => {
      if (roomSl.indexOf(p) < 0) p.lin = null; else if (s.linenChoice === 'own') p.lin = false; else if (s.linenChoice === 'order' && (p.lin == null || req)) p.lin = true;
      if (hall.indexOf(p) < 0) p.linens = null; else if (s.linenChoice === 'own') p.linens = false; else if (s.linenChoice === 'order' && p.linens == null) p.linens = true;
    });
    s.linenFor = roomSl.filter(p => p.lin).map(p => p.pid);
    s.linens = s.linenFor.length;
    d.pickupWho = (d.pickupWho || []).filter(n => ppl.some(p => p.kind === 'adult' && p.name.trim() === n));
    if (!d.household.name && d.household.contact.trim()) d.household.name = d.household.contact.trim().split(/\s+/).pop();
    // Every meal: the meals follow each person's stay (their nights, the day they arrive); one ticked or
    // unticked by hand is kept as it is. A registration read in (a draft, a saved one) says which by its meals.
    if (state.meals.length) {
      const mm = d.meals = d.meals || { off: {}, who: {} };
      // A draft kept on the server comes back with an empty list as [] (PHP): a meal set on it would be lost.
      ['off', 'who'].forEach(k => { if (!mm[k] || Array.isArray(mm[k])) mm[k] = {}; });
      if (typeof mm.every !== 'boolean') mm.every = isEveryMeal(d);
      if (mm.every) Object.assign(mm, everyMeal(d));
    }
    return d;
  }

  // The days a person is here, and so the meals they're counted for (as the server's ogc_reg_person_days).
  function personDays(p, d) {
    // A saved registration may have no days for a stay elsewhere (after the seventh critic, Oct 15: a
    // TypeError here stopped Your sign-ups): no days, no meals counted, nothing broken.
    const st = d.stay || {};
    if (st.type === 'elsewhere' && !inHall(p, d)) return state.days.filter(x => (st.days || []).indexOf(x.date) > -1).map(x => x.date);
    const all = nightsFor(p, d), main = all.filter(n => !early(n)), e = all.length > main.length;
    if (!main.length) return e && state.days.length ? [state.days[0].date] : [];
    const a = e ? 0 : dayIndex(main[0]), b = dayIndex(main[main.length - 1]);
    return a < 0 || b < 0 ? [] : state.days.slice(a, b + 2).map(x => x.date);
  }
  const mealDate = m => m.day.date;
  // A saved registration may hold meals as { off, custom } with no "who" (samples, older saves): every one eats.
  const mOff = d => (d.meals && d.meals.off) || {}, mWho = d => (d.meals && d.meals.who) || {};
  const eats = (p, m, d) => !mOff(d)[m.id] && personDays(p, d).indexOf(mealDate(m)) > -1 && (!mWho(d)[m.id] || mWho(d)[m.id].indexOf(p.pid) > -1);
  // The meals while anyone is here.
  const mealsHere = d => { d = d || state.d; const ppl = d.people.filter(p => p.name.trim()); const days = new Set(); ppl.forEach(p => personDays(p, d).forEach(x => days.add(x))); return state.meals.filter(m => days.has(mealDate(m))); };

  // What a household pays, line by line in cents (the server's ogc_reg_price, for display).
  function priceOf(d, cfgOver) {
    const save = state.cfg;
    if (cfgOver) state.cfg = Object.assign({}, state.cfg, cfgOver);
    try {
      const lines = [], s = d.stay, add = (key, label, c) => { if (c) lines.push({ key, label, cents: c }); };
      const ppl = d.people.filter(p => p.name.trim()), room = cents('room_price'), bedsN = Math.max(1, +C('room_beds') || 2);
      if (s.type === 'dorm' && s.nights.length) {
        if ((C('charge') || 'room') === 'person') {
          [['adult', 'Adults'], ['child', 'Children'], ['baby', 'Under 3']].forEach(([b, label]) => {
            const pr = cents('person_price_' + b), n = ppl.filter(p => p.band === b && !inHall(p, d)).reduce((k, p) => k + nightsFor(p, d).length, 0);
            add('person_' + b, label + ' · ' + plural(n, 'night') + ' × ' + $(pr), n * pr);
          });
        } else if (s.perPerson && s.rooms > 1) {
          for (let i = 0; i < s.rooms; i++) {
            const set = new Set();
            ppl.forEach(p => { if (p.room === i) nightsFor(p, d).forEach(n => set.add(n)); });
            const n = set.size || s.nights.length;
            add('room_' + i, 'Room ' + (i + 1) + ' · ' + plural(n, 'night') + ' × ' + $(room), n * room);
          }
        } else add('rooms', plural(s.rooms, 'dorm room') + ' · ' + plural(s.nights.length, 'night') + ' × ' + $(room), s.rooms * s.nights.length * room);
        if (s.mattresses) add('mattresses', plural(s.mattresses, 'air mattress', 'air mattresses') + ' × ' + $(cents('mattress_price')), s.mattresses * cents('mattress_price'));
      }
      const yfc = C('yf_charge') || 'share', per = yfc === 'person' ? cents('yf_price') : yfc === 'room' ? room : Math.round(room / bedsN);
      ppl.forEach(p => { if (inHall(p, d)) { const n = nightsFor(p, d).length; add('yf_' + p.pid, first(p.name) + ' · ' + hallWord(p.yfHall) + ' · ' + plural(n, 'night') + ' × ' + $(per), n * per); } });
      // Every packet on one line, the rooms' and each Young Folk's in a hall (polish 3; the server's too).
      const lp = cents('linen_price'), rl = (s.type === 'dorm' || s.type === 'yf' ? (+s.linens || 0) : 0) + ppl.filter(p => p.linens && inHall(p, d)).length;
      if (rl) add('linens', plural(rl, 'linen packet') + ' × ' + $(lp), rl * lp);
      if (s.type === 'camper' && s.nights.length) {
        const cp = cents('camper_price'), c = Math.max(1, s.campers || 1);
        if (C('camper_per') === 'stay') add('camper', 'Camper lot · ' + plural(c, 'camper') + ' × ' + $(cp), c * cp);
        else add('camper', 'Camper lot · ' + (c > 1 ? c + ' campers · ' : '') + plural(s.nights.length, 'night') + ' × ' + $(cp), c * s.nights.length * cp);
      }
      if ((C('meals_free') || 'yes') === 'no') {
        [['adult', 'Meals, 12 and up'], ['child', 'Meals, 3 to 11']].forEach(([b, label]) => {
          const n = state.meals.reduce((k, m) => k + ppl.filter(p => p.band === b && eats(p, m, d)).length, 0), mp = cents('meal_price_' + b);
          add('meals_' + b, label + ' · ' + n + ' × ' + $(mp), n * mp);
        });
      }
      const lodging = lines.reduce((k, l) => k + l.cents, 0), gift = Math.max(0, Math.floor(+d.gift || 0)) * 100;
      if (gift) lines.push({ key: 'gift', label: 'Gift · ' + giftFor(), cents: gift });
      return { lines, lodging_cents: lodging, gift_cents: gift, total_cents: lodging + gift };
    } finally { state.cfg = save; }
  }
  // What the gift goes to, as a label ("Kit packing"), as the server's ogc_reg_gift_for.
  const giftFor = () => { const g = (C('gift_for') || 'the Conference fund').trim().replace(/^the\s+/i, ''); return g.charAt(0).toUpperCase() + g.slice(1); };
  const total = () => priceOf(state.d, state.editing && state.editing.data.price && state.editing.data.price.prices).total_cents;

  // What's missing, by the field it belongs to (the server's ogc_reg_problems; the same words).
  function problems(k) {
    const d = state.d, e = {}, h = d.household, x = d.helper, s = d.stay, need = (p, v) => { if (!String(v || '').trim()) e[p] = 'Required'; };
    const member = state.F && state.F.member;
    if (!k || k === 'contact') {
      need('household.contact', h.contact);
      if (x.on) {
        need('helper.name', x.name);
        // The household must be reachable (Lodging calls them, not the helper): its email or its phone.
        if (!h.email.trim() && !h.phone.trim()) e['household.phone'] = 'Enter an email or a phone';
        if (!emailOk(x.email)) e['helper.email'] = x.email ? 'Enter an email like name@example.com' : 'Required';
        if (h.email && !emailOk(h.email)) e['household.email'] = 'Enter an email like name@example.com';
      } else {
        need('household.phone', h.phone);
        if (!emailOk(h.email) && !(member && !h.email)) e['household.email'] = h.email ? 'Enter an email like name@example.com' : 'Required';
      }
    }
    if (!k || k === 'people') {
      if (!named().length) e.people = 'Add who’s coming';
      named().forEach(p => {
        const at = 'people.' + p.pid;
        if (p.kind !== 'adult' && !/^\d{1,3}$/.test(String(p.age).trim())) e[at + '.age'] = 'Enter an age';
        else if (p.kind === 'child' && +p.age >= 18) e[at + '.age'] = '18 and over · Choose Adult or Young Folk';
        else if (p.age !== '' && +p.age > 110) e[at + '.age'] = 'Enter an age';
        if (p.yf && !p.yfHall && inHall(p)) e[at + '.yfHall'] = 'Choose a hall';
        if (ptAge(p) && !p.ptSet && !e[at + '.age']) e[at + '.pt'] = 'Choose one';
      });
      if (named().length > MAXP) e.people = 'Up to ' + MAXP + ' · Register another for the rest';
      // Where people sleep is kept safe (the Advisors, Oct 9): a Young Folk is the COA's age and up, and
      // a child comes with a grown-up on the registration (or, when the COA allows it, with a household
      // named for Lodging). The desk may enter one anyway; Lodging's Review lists it.
      const min = minYf();
      named().forEach(p => { const at = 'people.' + p.pid + '.age'; if (p.yf && min && p.age !== '' && +p.age < min && !e[at]) e[at] = min + ' and up · Choose Child'; });
      if (!e.people && !state.desk && named().some(p => p.kind === 'child') && !adults().length) {
        if (C('child_with_household') !== 'yes') e.people = NOADULT;
        else if (!String(s.withHh || '').trim()) e['stay.withHh'] = 'Required';
      }
      if (minorsAlone()) parentProblem(e);
      // A parent's approval is asked in the young person's own card (polish 2), so it's checked here.
      else if (adults().length && named().some(p => p.minor && inHall(p))) { if (s.ask) parentProblem(e); else if (!s.yfOk) e['stay.yfOk'] = 'Choose one'; }
    }
    if (!k || k === 'stay') {
      if (!s.type) { e['stay.type'] = 'Choose one'; return e; }
      if (s.type === 'elsewhere') { if (!s.days.length) e['stay.days'] = 'Choose at least one day'; }
      else if (!s.nights.length) e['stay.nights'] = 'Choose at least one night';
      if (s.perPerson) named().forEach(p => { if (!p.nights.length && (s.type !== 'elsewhere' || inHall(p))) e['people.' + p.pid + '.nights'] = 'Choose at least one night'; });
      if (s.type === 'dorm' && sleepers().length > s.rooms * beds()) e['stay.rooms'] = sleepers().length + ' people need ' + Math.ceil(sleepers().length / beds()) + ' rooms';
      // Linens: one choice for everyone sleeping in a dorm room or a hall (nothing that costs money is pre-chosen).
      if (!state.editing && !s.linenChoice && linenPeople().length) e['stay.linenChoice'] = 'Choose linens';
      const L = state.F.left || {};
      if (!state.waitlist && s.type === 'dorm' && L.rooms != null && s.rooms > L.rooms && !state.editing) e['stay.type'] = L.rooms ? 'Only ' + plural(L.rooms, 'room') + ' left' : 'Rooms full';
    }
    if (!k || k === 'preteens') {
      if (preteensOnline() && named().some(p => p.preteen) && !d.contacts.some(c => c.withheld)) d.contacts.forEach((c, j) => { if (j > 0 && !c.name.trim() && !c.phone.trim()) return; if (!c.name.trim()) e['contacts.' + j + '.name'] = 'Required'; if (!c.phone.trim()) e['contacts.' + j + '.phone'] = 'Required'; });
    }
    // How to pay is asked only when something is owed (a change that costs nothing more, even one first paid
    // by card and now entered by a member, who never takes a card, needs no choice).
    if ((!k || k === 'pay') && !state.desk && !state.waitlist && owesNow() && !payOk(d.pay)) e.pay = 'Choose how to pay';
    return e;
  }
  const owesNow = () => { if (!state.editing) return total() > 0; const M = moneyNow(); return M.due > 0 || M.newCheck > M.check; };
  // A parent's email: required, valid, and not the email of the person registering.
  function parentProblem(e) {
    const s = state.d.stay, mine = [state.d.household.email, state.d.helper.email].map(x => String(x || '').trim().toLowerCase()).filter(Boolean);
    if (!emailOk(s.parentEmail)) e['stay.parentEmail'] = s.parentEmail ? 'Enter an email like name@example.com' : 'Required';
    else if (mine.indexOf(s.parentEmail.trim().toLowerCase()) > -1) e['stay.parentEmail'] = 'Use a parent’s email';
    else {
      // A likely typo (gmial.com) stops Continue once, as the household's own email does.
      const t = s.parentEmail.trim().toLowerCase(), fix = typoOf(t);
      if (fix && fix !== t && state.ui.parentTypoAsked !== t) e['stay.parentEmail'] = 'Check ' + t.slice(t.indexOf('@') + 1) + ' · Did you mean ' + fix.slice(fix.indexOf('@') + 1) + '?';
    }
  }
  // Who a linen packet may be for: each sleeper in the household's rooms, each Young Folk in a hall.
  const linenPeople = d => { d = d || state.d; return d.people.filter(p => p.name.trim() && ((d.stay.type === 'dorm' && p.band !== 'baby' && !inHall(p, d)) || inHall(p, d))); };
  const hasPacket = (p, d) => inHall(p, d || state.d) ? !!p.linens : !!p.lin;
  const MAXP = 20;
  const NOADULT = 'A child needs a grown-up on this registration';
  const minYf = () => { const v = C('yf_min_age'); return v === '' ? 16 : (+v || 0); };

  /* ================================================================ drawing: one path */

  // Text → nodes → morphed into the page. Elements with data-k are matched by key (people, sections),
  // the rest in order. A field with focus keeps its value as typed.
  const keyOf = n => n.nodeType === 1 ? n.getAttribute('data-k') : null;
  function morph(a, b) {
    if (a.nodeType !== 1) { if (a.nodeValue !== b.nodeValue) a.nodeValue = b.nodeValue; return; }
    Array.from(a.attributes).forEach(x => { if (!b.hasAttribute(x.name)) a.removeAttribute(x.name); });
    Array.from(b.attributes).forEach(x => { if (a.getAttribute(x.name) !== x.value) a.setAttribute(x.name, x.value); });
    const tag = a.tagName;
    if (tag === 'INPUT') {
      if (a.type === 'checkbox' || a.type === 'radio') a.checked = b.hasAttribute('checked');
      else if (a !== document.activeElement) { const v = b.getAttribute('value') || ''; if (a.value !== v) a.value = v; }
      return;
    }
    if (tag === 'TEXTAREA') { if (a !== document.activeElement && a.value !== b.textContent) a.value = b.textContent; return; }
    if (a.hasAttribute('data-own')) return;
    const keyed = new Map(), used = new Set();
    Array.from(a.childNodes).forEach(n => { const k = keyOf(n); if (k) keyed.set(k, n); });
    let cur = a.firstChild;
    Array.from(b.childNodes).forEach(nb => {
      while (cur && used.has(cur)) cur = cur.nextSibling;
      const k = keyOf(nb);
      let m = null;
      if (k) { m = keyed.get(k) || null; if (m && m.nodeName !== nb.nodeName) m = null; }
      else { let c = cur; while (c && (used.has(c) || keyOf(c))) c = c.nextSibling; if (c && c.nodeName === nb.nodeName && c.nodeType === nb.nodeType) m = c; }
      if (m) { used.add(m); if (m !== cur) a.insertBefore(m, cur); morph(m, nb); }
      else { a.insertBefore(nb, cur); used.add(nb); if (nb.nodeType === 1 && nb.hasAttribute('data-reveal') && !reduced()) { nb.classList.add('is-new'); setTimeout(() => nb.classList.remove('is-new'), 400); } }
    });
    Array.from(a.childNodes).forEach(n => { if (!used.has(n)) n.remove(); });
  }
  // The page's one draw: the current view, morphed in.
  function draw() {
    root.removeAttribute('aria-busy');
    const sk = root.querySelector('.reg-skel'); if (sk) sk.remove();
    const ld = root.querySelector('.reg-loading'); if (ld) ld.remove();
    const html = '<div class="reg-view">' + VIEWS[state.view]() + '</div>';
    const t = document.createElement('div');
    t.innerHTML = html;
    const now = root.querySelector(':scope > .reg-view');
    if (now) morph(now, t.firstElementChild); else root.appendChild(t.firstElementChild);
    keepAsOf();
    gridTabStop();
    fitWeek();
  }
  // Your week's "Meals" sits where its first day leaves room; in a narrower week only its icon shows, and
  // with no room at all, none (never cut, never over a mark; the key under the week says the letters).
  function fitWeek() {
    root.querySelectorAll('.gx--view').forEach(g => {
      const over = () => { const l = g.querySelector('.gx-ml'), m = l && l.parentNode.querySelector('.gx-m'); return !!(l && m && l.offsetWidth && l.getBoundingClientRect().right > m.getBoundingClientRect().left - 3); };
      g.classList.remove('is-tight', 'is-tighter');
      if (over()) { g.classList.add('is-tight'); if (over()) g.classList.add('is-tighter'); }
    });
  }
  window.addEventListener('resize', () => { cancelAnimationFrame(state.fitT); state.fitT = requestAnimationFrame(fitWeek); });
  if (document.fonts && document.fonts.ready) document.fonts.ready.then(fitWeek, () => {});
  // A grid's cells (a night a person, or the meals) are one tab stop (the last one used, else the first);
  // arrow keys move between them.
  const gridCells = () => Array.from(root.querySelectorAll('.rg .rg-row:not(.rg-head)')).map(r => Array.from(r.querySelectorAll('[data-act="gnight"], [data-act="gmeal"]:not([disabled])')));
  const cellKey = b => b.dataset.pid + '|' + (b.dataset.v || b.dataset.id);
  function gridTabStop() {
    const all = [].concat.apply([], gridCells());
    if (all.length && !all.some(b => b.tabIndex === 0)) all[0].tabIndex = 0;
  }
  function gridMove(b, key) {
    const rows = gridCells(), r = rows.findIndex(x => x.indexOf(b) > -1);
    if (r < 0) return false;
    const i = rows[r].indexOf(b), xOf = el => el.getBoundingClientRect().left;
    let to = null;
    if (key === 'ArrowLeft') to = rows[r][i - 1];
    else if (key === 'ArrowRight') to = rows[r][i + 1];
    else if (key === 'Home') to = rows[r][0];
    else if (key === 'End') to = rows[r][rows[r].length - 1];
    else {
      const nr = rows[r + (key === 'ArrowDown' ? 1 : -1)];
      if (nr && nr.length) { const x = xOf(b); to = nr.reduce((best, c) => Math.abs(xOf(c) - x) < Math.abs(xOf(best) - x) ? c : best, nr[0]); }
    }
    if (!to) return true;
    rows.forEach(x => x.forEach(c => { c.tabIndex = -1; })); to.tabIndex = 0; state.ui.gcell = cellKey(to); to.focus();
    return true;
  }
  // A change: the derived parts worked out, kept for this tab, drawn.
  function update() { state.override = null; if (state.d) { settle(); keep(); } draw(); }

  /* ================================================================ small parts */

  const errId = path => 'err-' + path.replace(/[^A-Za-z0-9]+/g, '-');
  const err = path => state.errors[path] ? '<p class="rf-err" id="' + errId(path) + '">' + esc(state.errors[path]) + '</p>' : '';
  const bad = path => state.errors[path] ? ' aria-invalid="true" aria-describedby="' + errId(path) + '"' : '';
  const help = (t, id) => t ? '<p class="rf-help"' + (id ? ' id="' + id + '"' : '') + '>' + esc(t) + '</p>' : '';
  // What must stay on one line keeps together (Michael: nothing split mid-word): a number and its unit
  // ("5 nights"), "× $32.50", a phone (555-555-0142), a date ("Sat May 29"). escn() escapes it too.
  const nb = t => String(t == null ? '' : t).replace(/(\d) (?=[A-Za-z$])/g, '$1\u00a0').replace(/ × /g, '\u00a0×\u00a0').replace(/ · /g, '\u00a0· ').replace(/check-in/g, 'check\u2011in').replace(/\b(\d{3})-(\d{3})-(\d{4})\b/g, '$1\u2011$2\u2011$3').replace(/\b(Mon|Tue|Wed|Thu|Fri|Sat|Sun) (Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec) /g, '$1\u00a0$2\u00a0')
    // A date range holds together (a line breaks at " · ", never at its dash); "linen packet" holds; a time range holds
    // digit to digit ("7:30–9 PM"), so "10 AM–12 PM" may still wrap in a narrow day column.
    // A line may still break after an en dash before a no-break space (UAX 14, LB12a), which started the next line
    // with a space (" Wed Jun 2"); the word joiner after the dash forbids that break.
    .replace(/ – /g, '\u00a0–\u2060\u00a0').replace(/linen packet/g, 'linen\u00a0packet').replace(/(\d)–(\d)/g, '$1\u2060–\u2060$2');
  const escn = t => esc(nb(t));
  // A text field: its label (only the label: its accessible name), then the field, its help and its
  // error, both joined to it with aria-describedby.
  function field(label, path, value, o) {
    o = o || {};
    // While an error shows, the help steps aside (polish 3: three lines stacked under Email); a fix for
    // the error sits on the error's own line (o.fix: a button).
    if (state.errors[path]) o = Object.assign({}, o, { help: '' });
    const fid = 'f-' + path.replace(/[^A-Za-z0-9]+/g, '-'), hid = o.help ? 'help-' + path.replace(/[^A-Za-z0-9]+/g, '-') : '', desc = [state.errors[path] ? errId(path) : '', hid].filter(Boolean).join(' ');
    return '<div class="reg-field' + (o.cls ? ' ' + o.cls : '') + '"><label class="reg-label" for="' + fid + '">' + esc(label) + (o.optional ? ' <span class="reg-opt">(optional)</span>' : '') + '</label>' +
      (o.area ? '<textarea id="' + fid + '" name="' + path + '" rows="2"' + (o.ph ? ' placeholder="' + esc(o.ph) + '"' : '') + (state.errors[path] ? ' aria-invalid="true"' : '') + (desc ? ' aria-describedby="' + desc + '"' : '') + ' maxlength="500">' + esc(value) + '</textarea>'
        : '<input id="' + fid + '" name="' + path + '" type="' + (o.type || 'text') + '" value="' + esc(value) + '"' + (o.attrs || '') + (o.ph ? ' placeholder="' + esc(o.ph) + '"' : '') + (state.errors[path] ? ' aria-invalid="true"' : '') + (desc ? ' aria-describedby="' + desc + '"' : '') + '>') +
      (o.help ? '<span class="rf-help" id="' + hid + '">' + esc(o.help) + '</span>' : '') + (o.fix && state.errors[path] ? '<p class="rf-err" id="' + errId(path) + '">' + esc(state.errors[path]) + ' ' + o.fix + '</p>' : err(path)) + (o.after || '') + '</div>';
  }
  // A choice of a few: a radio group of pills (arrow keys move between them).
  // after: { value: html } placed right after that pill (an (i) for the pill it explains).
  function radios(label, act, value, opts, extra, errPath, after, plain) {
    return '<span class="rf-seg' + (plain ? ' rf-seg--plain' : '') + '" role="radiogroup" aria-label="' + esc(label) + '"' + (errPath && state.errors[errPath] ? ' aria-invalid="true" aria-describedby="' + errId(errPath) + '"' : '') + '>' + opts.map(o => {
      const on = value === o[0];
      return '<button type="button" role="radio" aria-checked="' + on + '" tabindex="' + (on || (!opts.some(x => x[0] === value) && o === opts[0]) ? '0' : '-1') + '" data-act="' + act + '" data-v="' + esc(o[0]) + '"' + (extra || '') + (o[2] ? ' disabled' : '') + '>' + (plain ? '' : I.check) + esc(o[1]) + '</button>' + (after && after[o[0]] ? after[o[0]] : '');
    }).join('') + '</span>';
  }
  // A yes/no: one pill, on or off.
  const tog = (path, on, label, o) => '<label class="rf-tog' + (o && o.cls ? ' ' + o.cls : '') + '"><input type="checkbox" name="' + path + '"' + (on ? ' checked' : '') + bad(path) + (o && o.dis ? ' disabled' : '') + '><span>' + I.check + esc(label) + '</span></label>';
  const togAct = (act, on, label, extra) => '<button type="button" class="rf-pill" aria-pressed="' + !!on + '" data-act="' + act + '"' + (extra || '') + '>' + I.check + esc(label) + '</button>';
  const stepper = (path, value, min, max, label) => '<span class="reg-stepper" role="group" aria-label="' + esc(label) + '"><button type="button" data-act="step" data-path="' + path + '" data-by="-1" aria-label="Fewer ' + esc(label.toLowerCase()) + '"' + (value <= min ? ' disabled' : '') + '>' + I.minus + '</button><output aria-live="polite" aria-label="' + esc(label) + '">' + value + '</output><button type="button" data-act="step" data-path="' + path + '" data-by="1" aria-label="More ' + esc(label.toLowerCase()) + '"' + (value >= max ? ' disabled' : '') + '>' + I.plus + '</button></span>';
  // An (i) that opens its explanation in place (never only on hover: phones have none).
  const infoBtn = (id, label) => '<button type="button" class="rf-i" data-act="info" data-id="' + id + '" aria-expanded="' + !!state.ui['i-' + id] + '" aria-label="' + esc(label) + '">' + I.info + '</button>';
  const infoText = (id, text) => state.ui['i-' + id] ? '<span class="rf-itext" role="note">' + esc(text) + '</span>' : '';
  const info = (id, label, text) => infoBtn(id, label) + infoText(id, text);
  // The same explanation as plain help on its own line under what it explains (polish 3: inline, it
  // took the uppercase label style and shouted).
  const infoLine = (id, text) => state.ui['i-' + id] ? '<p class="rf-help rf-help--i-open" role="note">' + esc(text) + '</p>' : '';

  // One ledger: rows of [label, amount or words, {sum, cls}], amounts right-aligned. Never a $0 row.
  const ledger = (rows, cap) => '<table class="reg-total"><caption class="ogc-sr">' + esc(cap || 'Total') + '</caption><tbody>' + rows.filter(Boolean).map(r => '<tr' + (r[2] && r[2].sum ? ' class="reg-total__sum"' : '') + '><td>' + escn(r[0]) + '</td><td>' + escn(typeof r[1] === 'number' ? $(r[1]) : r[1]) + '</td></tr>').join('') + '</tbody></table>';
  // What's been received and what's promised, kept apart (a check to come is never counted as paid).
  // A check not received by check_by (m.late) is due at check-in (the COA's late_pay), never "to come".
  const lateIn = m => !!(m && m.late) && !(state.F && state.F.latePay === 'card');
  function moneyRows(m, d) {
    const late = (d && d.pay === 'checkin') || lateIn(m);
    return [m.paid > 0 ? ['Paid', m.paid] : null, m.check > 0 ? ['Check to come', m.check] : null, m.refund > 0 ? ['Refund requested', m.refund] : null, m.refunded > 0 ? ['Refunded', m.refunded] : null,
      !m.check && m.due > 0 ? [late ? 'Due at check-in' : m.paid > 0 ? 'Balance' : 'Due', m.due, { sum: true }] : null];
  }

  /* ================================================================ the hero */

  function hero(title, o) {
    o = o || {};
    const s = state.model ? state.model.settings : {}, r = state.row || {};
    // A year with no dates yet still says who hosts it (the Advisors, Oct 9: show 2028 with its hosts).
    const facts = o.facts !== false ? '<ul class="wk-facts">' + (r.start ? '<li>' + I.cal + '<span>' + esc(O.fmtDateSpan(r.start, r.end)) + '</span></li>' : r.hosts ? '<li>' + I.people + '<span>' + esc('Hosted by the ' + r.hosts.replace(/^the\s+/i, '')) + '</span></li>' : '') + (s.venue ? '<li>' + I.pin + '<span>' + esc(s.venue) + '<small>' + esc(s.city || '') + '</small></span></li>' : '') + (o.more || '') + '</ul>' : '';
    const photo = o.photo ? '<div class="wk-hero__side"><figure class="wk-photo"><img src="' + esc(SU.photoOf(s)) + '" alt="" loading="lazy" decoding="async"></figure></div>' : '';
    return '<header class="wk-hero"><div class="wk-wrap' + (photo ? ' wk-hero__in' : '') + '"><div class="wk-hero__text vol-hero">' +
      '<p class="wk-kicker"><a class="reg-kick" href="../schedule-hub/?year=' + esc(state.year) + '">' + esc(state.year) + ' Annual Conference</a></p>' +
      '<h1 class="vol-title">' + esc(title) + '</h1>' + facts + (o.sub || '') + '</div>' + photo + '</div></header>';
  }
  const page = (head, body, bar) => '<div class="wk reg">' + head + '<section class="wk-main"><div class="wk-wrap"><div class="reg-wrap">' + body + '</div></div></section>' + (bar || '') + '</div>';
  const blankCard = (h, p, btn) => '<section class="ws-blank reg-blank"><p class="ws-blank__h">' + h + '</p>' + (p ? '<p class="ws-blank__p">' + p + '</p>' : '') + (btn ? '<p class="ws-blank__btn">' + btn + '</p>' : '') + '</section>';
  const mineLink = (label) => '<a href="?year=' + esc(state.year) + '&view=mine">' + esc(label || 'Your sign-ups') + '</a>';
  const ownerOr = (k, fallback) => (state.F && state.F[k]) || fallback || '';
  const today = () => (state.F && state.F.today) || O.wallNow(state.model ? state.model.tz : 'America/Indiana/Indianapolis').date;

  /* ================================================================ the form: short steps (Oct 23) */

  // Michael, Oct 23: "It needs to be a lot cleaner… refined restraint… really minimalistic and purposeful
  // design. You don't want to have a lot of duplicated information." Caleb (Oct 20): "paginate them, but
  // carry forward the data from page to page." So the form is short steps in one calm column: Contact (and
  // the emailed code), then Who's coming · Stay · Meals · Communion · Review, each its own page with Back and
  // Continue at its foot. Answers carry forward, any step done can be gone back to, and the record saved is
  // the same as before (the back end, Lodging, the meal counts and Your sign-ups read it as they did).

  // Line drawings for the stay, in the site's tan (no photos but the year's).
  const DRAW = {
    dorm: '<svg class="rx-draw" viewBox="0 0 92 62" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M4 55h84"/><path d="M14 55V14h44v41"/><path d="M11 14h50"/><path d="M14 9h44v5"/><path d="M21 21h6v6h-6zM33 21h6v6h-6zM45 21h6v6h-6zM21 33h6v6h-6zM33 33h6v6h-6zM45 33h6v6h-6z"/><path d="M31 55V45h10v10"/><path d="M36 45v10"/><circle cx="73" cy="36" r="9"/><path d="M73 45v10M73 40l-3-3M73 42l3-3"/></svg>',
    camper: '<svg class="rx-draw" viewBox="0 0 92 62" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M4 55h84"/><path d="M10 47V27a10 10 0 0 1 10-10h34c9 0 16 7 16 16v14Z"/><path d="M17 26h14v9H17z"/><path d="M41 26h9v21"/><path d="M50 26v21"/><path d="M57 27h7"/><circle cx="31" cy="49" r="5.5"/><path d="M70 43h12M82 43v12M79 55h6"/><path d="M14 47h12M36 47h4"/></svg>',
    elsewhere: '<svg class="rx-draw" viewBox="0 0 92 62" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M4 55h84"/><path d="M14 31 35 14l21 17"/><path d="M19 27v28h32V27"/><path d="M30 55V42h9v13"/><path d="M43 34h5v5h-5z"/><path d="M45 20v-7h5v11"/><path d="M60 55c1.5-9 6-13 11-13s9.5 4 11 13"/><path d="M71 42v-5"/></svg>'
  };
  DRAW.yf = DRAW.dorm;
  // A phone: the meals one person at a time (the laptop's grid needs the width).
  const narrow = () => window.matchMedia('(max-width: 759px)').matches;

  /* ---------------------------------------------------------------- the steps */

  const STEP = { contact: 'Contact', people: 'Who’s coming', stay: 'Stay', meals: 'Meals', communion: 'Communion', review: 'Review' };
  const communers = () => named().filter(p => p.kind !== 'child');
  const ptAge = p => { const a = /^\d{1,3}$/.test(String(p.age).trim()) ? +p.age : -1; return p.kind === 'child' && a >= 10 && a <= 13; };
  // A preteen's details are asked on Communion for each child in the program (the Yes on Who's coming).
  const ptAsk = () => preteensOnline() && named().some(p => p.preteen);
  // The steps after Contact. A step with nothing to ask isn't drawn (never a zero): Meals when the year has
  // none; Communion when there's no one who communes and no preteen in the program.
  const steps = () => ['people', 'stay', 'meals', 'communion', 'review'].filter(k => k === 'meals' ? state.meals.length > 0 : k === 'communion' ? communers().length > 0 || ptAsk() : true);
  const order = () => ['contact'].concat(steps());
  const stepName = k => k === 'communion' && !communers().length ? 'Preteens' : STEP[k];
  // Which step a problem belongs to, by its field.
  const stepOf = path => /^(household|helper|verify)\./.test(path) ? 'contact'
    : path === 'people' || path === 'stay.withHh' || /^people\.[^.]+\.(name|age|kind|pt)$/.test(path) ? 'people'
      : /^(contacts|preteens|pickup)/.test(path) ? 'communion'
        : /^(people|stay)/.test(path) ? 'stay' : 'review';
  const errsOf = (k, p) => { const o = {}; Object.keys(p).forEach(x => { if (stepOf(x) === k) o[x] = p[x]; }); return o; };
  const badIn = (k, p) => Object.keys(p).some(x => stepOf(x) === k);
  // The first step with something missing ('' when none).
  const firstBad = p => { p = p || problems(); return order().find(k => k !== 'review' && badIn(k, p)) || ''; };
  // A step may be gone to when it's this one or one before it, or when every step before it is complete.
  function reachable(k, p) {
    const o = order(), i = o.indexOf(k), cur = o.indexOf(state.step);
    if (i < 0) return false;
    if (i <= cur) return true;
    p = p || problems();
    return o.slice(0, i).every(x => !badIn(x, p));
  }
  // After the form closes, a change online is Contact and the preteens' details only (communing too).
  const locked = k => !!(state.editing && !state.editing.can.all && ['contact', 'communion', 'review'].indexOf(k) < 0);
  // Where a signed-in household starts: Contact while something's missing there, else Who's coming.
  const landStep = () => badIn('contact', problems('contact')) ? 'contact' : 'people';
  const STEP_KEY = () => 'ogc-register-step-' + state.year + '-' + meKey();
  function goStep(k, errors) {
    state.step = k;
    if (k === 'review') state.fromReview = false;
    state.errors = errors || {};
    state.barNote = '';
    try { if (!state.editing && !state.desk) sessionStorage.setItem(STEP_KEY(), k); } catch (x) { /* not kept */ }
    keep(); draw();
    const top = root.querySelector('.rs-col');
    if (top && top.getBoundingClientRect().top < 0) window.scrollTo({ top: Math.max(0, top.getBoundingClientRect().top + window.scrollY - 12), behavior: 'auto' });
    if (errors && Object.keys(errors).length) { focusProblem(); tell(Object.keys(errors).length === 1 ? Object.values(errors)[0] : Object.keys(errors).length + ' fields need attention'); return; }
    setTimeout(() => { const h = root.querySelector('#rs-h'); if (h) h.focus({ preventScroll: true, focusVisible: false }); }, 30);
    tell(stepName(k));
  }
  // A step's errors go with it: one not yet open is gone to, with what's missing marked.
  function goToOrFix(k) {
    const p = problems();
    if (reachable(k, p)) return goStep(k);
    const f = firstBad(p);
    if (f) { if (state.step === 'review' || state.fromReview) state.fromReview = true; goStep(f, errsOf(f, p)); }
  }

  /* ---------------------------------------------------------------- the page */

  const isPreview = () => !!(state.F && state.F.phase !== 'open' && state.F.member && q.get('preview') === '1' && !state.desk);
  // Several of last year's to choose from (or Register another), before anything is filled in.
  const chooser = () => { const F = state.F, d = state.d; return !state.editing && !state.desk && F.reuse.length > 0 && (F.reuse.length > 1 || state.another) && !d.from && d.start !== 'new' && named().length <= 1 && !d.stay.type; };

  // The header (Your sign-ups and Registered): the year and the title; on the right, the dates and place,
  // when it closes, and who's signed in (Not you?).
  function rxHero(title, closesText, sub, who) {
    const s = state.model ? state.model.settings : {}, r = state.row || {}, me = SU.me();
    const facts = [r.start ? O.fmtDateSpan(r.start, r.end) : '', [s.venue, s.city].filter(Boolean).join(', ')].filter(Boolean).join(' · ');
    const meLine = who && me && !me.pending && !state.editing && !state.desk ? '<span class="rx-me">' + esc(me.name || me.email) + ' · <button type="button" class="wk-linklike" data-act="signout">Not you?</button></span>' : '';
    return '<header class="rx-hero"><div class="wk-wrap rx-hero__in"><div class="rx-hero__t"><p class="wk-kicker"><a class="reg-kick" href="../schedule-hub/?year=' + esc(state.year) + '">' + esc(state.year) + ' Annual Conference</a></p>' +
      '<h1 class="vol-title">' + esc(title) + '</h1>' + (sub || '') + '</div>' +
      (facts || closesText || meLine ? '<div class="rx-facts">' + (facts ? '<p>' + escn(facts) + '</p>' : '') + (closesText || meLine ? '<p>' + (closesText ? '<span>' + esc(closesText) + '</span>' : '') + (closesText && meLine ? ' · ' : '') + meLine + '</p>' : '') + '</div>' : '') + '</div></header>';
  }
  // The form's header, in the column: the year, the title, the dates and place once, then when it closes
  // and who's signed in (Not you?).
  function rsHero(title, closesText, sub) {
    const s = state.model ? state.model.settings : {}, r = state.row || {}, me = SU.me();
    const facts = [r.start ? O.fmtDateSpan(r.start, r.end) : '', [s.venue, s.city].filter(Boolean).join(', ')].filter(Boolean).join(' · ');
    const meLine = me && !me.pending && !state.editing && !state.desk ? '<span class="rs-me">' + esc(me.name || me.email) + ' · <button type="button" class="wk-linklike" data-act="signout">Not you?</button></span>' : '';
    const meta = [closesText ? '<span>' + esc(closesText) + '</span>' : '', meLine].filter(Boolean).join('<span aria-hidden="true"> · </span>');
    return '<header class="rs-hero"><div class="wk-wrap"><div class="rs-col"><p class="wk-kicker"><a class="reg-kick" href="../schedule-hub/?year=' + esc(state.year) + '">' + esc(state.year) + ' Annual Conference</a></p>' +
      '<h1 class="vol-title">' + esc(title) + '</h1>' + (facts ? '<p class="rs-facts">' + escn(facts) + '</p>' : '') + (meta ? '<p class="rs-meta">' + meta + '</p>' : '') + (sub || '') + '</div></div></header>';
  }
  const stepPage = (head, body) => '<div class="wk reg rs-page">' + head + '<section class="rs-main"><div class="wk-wrap"><div class="rs-col">' + body + '</div></div></section></div>';

  function formView() {
    const F = state.F, ph = F.phase, closes = C('closes');
    const preview = isPreview();
    if (!state.editing && !preview && !state.desk) {
      // The header is drawn the same in every state (the year's photo too), so the page keeps its shape.
      const H = hero('Register', { photo: true });
      if (ph === 'none' && F.blocked === 'samples') return page(H, blankCard('Not open yet', esc('Sample households in ' + state.year), '<button type="button" class="wk-btn wk-btn--line wk-btn--small" data-act="clearsamples">Clear samples</button>'));
      // Every state the same shape (polish 3): one serif line, then at most one action.
      if (ph === 'none' || !state.model) return page(H, blankCard('Not open yet'));
      if (ph === 'before') return page(H, blankCard('Opens ' + esc(O.fmtDate(C('opens'), 'md')), '', F.member ? '<a class="wk-btn wk-btn--line wk-btn--small" href="?year=' + esc(state.year) + '&preview=1">Preview</a>' : ''));
      if (ph === 'closed') return page(H, blankCard('Register at check-in', C('checkin_place') ? esc(C('checkin_place')) : '', mineLink()));
      if (ph === 'held') {
        // A past year: when it was held, and the next year's registration (open, or when it opens).
        const N = state.nextF, ny = N ? String(N.year) : '', r = state.row || {};
        const open = N && N.phase === 'open', when = N && N.phase === 'before' && N.cfg && N.cfg.opens ? ny + ' · Opens ' + O.fmtDate(N.cfg.opens, 'md') : '';
        return page(H, blankCard(esc('Held ' + (r.start ? O.fmtDateSpan(r.start, r.end) : r.year)), esc(when), open ? '<a class="wk-btn wk-btn--small" href="?year=' + esc(ny) + '">Register for ' + esc(ny) + '</a>' : mineLink()));
      }
    }
    const left = closes && !state.editing && ph === 'open' ? (() => { const n = O.daysBetween ? O.daysBetween(today(), closes) : 99; return n >= 0 && n <= 7 ? 'Closes ' + O.fmtDate(closes, 'weekday') : 'Closes ' + O.fmtDate(closes, 'md'); })() : '';
    // The desk works in the editors' frame (no site header): household after household.
    // For a household, from the app (Round 5): the editors' frame, ‹ Households back, How it came first.
    const head = state.forHh ? hhHead(state.editing ? 'Change · ' + regName(state.editing.data) : 'New household', state.editing ? state.editing.rid : '')
      : state.desk ? SU.wsHead({ year: state.year, part: ['registration', 'Registration'], kicker: 'Desk · ' + state.year, title: 'Register a household' })
        : rsHero(state.editing ? 'Change registration' : 'Register', left);
    let top = '';
    if (state.desk && state.deskSaved) top += '<p class="rf-banner" role="status">' + I.check + '<span>' + esc('Saved · ' + state.deskSaved.rid + ' · ' + regName(state.deskSaved.data)) + '</span><span class="rf-banner__next">Next household</span></p>';
    if (preview) top += '<p class="reg-preview">' + I.info + '<span><b>Preview</b> · ' + esc(ph === 'before' ? 'Opens ' + O.fmtDate(C('opens'), 'md') : 'Not open') + ' · Nothing is saved</span></p>';
    if (state.editing && !state.forHh) top += '<p class="rf-status"><span>' + esc(state.editing.rid) + ' · ' + esc(regName(state.editing.data)) + '</span><a class="wk-linklike" href="?year=' + esc(state.year) + '&view=mine">' + (editChanged() ? 'Discard changes' : I.back + 'Your sign-ups') + '</a></p>';
    if (state.editing && !state.editing.can.all) top += '<p class="reg-preview">' + I.info + '<span>Closed online · Contact and preteen details only · Other changes at check-in</span></p>';
    else if (!state.editing && !state.desk && state.flashTop) top += '<p class="rf-flash" role="status">' + I.check + '<span>' + esc(state.flashTop) + '</span></p>';
    // Signed in with a registration already: see it, or register another (a helper, a sibling).
    if (!state.editing && !state.desk && F.mine.length && !state.another) {
      return stepPage(head, top + '<section class="rf-card"><h2 class="rf-card__h">' + I.bed + (F.mine.length > 1 ? 'Your registrations' : 'Your registration') + '</h2><ul class="rf-items">' + F.mine.map(m => '<li><span><b>' + esc(m.label) + '</b><small>' + escn([m.rid, statusWords(m)].filter(Boolean).join(' · ')) + '</small></span></li>').join('') + '</ul>' +
        '<p class="rf-card__btns"><a class="wk-btn wk-btn--small" href="?year=' + esc(state.year) + '&view=mine">Your sign-ups</a></p></section>' +
        '<p class="rf-quiet rf-another"><button type="button" class="wk-linklike" data-act="another">Register another</button></p>');
    }
    // Not signed in on this device: Contact alone. The code confirms the email; then the steps, filled in
    // from last year when this email kept one.
    const gate = !state.editing && !state.desk && !verified();
    if (gate) state.step = 'contact';
    // Several of last year's under this email (a helper's households), or Register another: choose one.
    if (!gate && chooser()) {
      return stepPage(head, top + F.reuse.map((r, i) => '<section class="rx-card rf-last" data-k="reuse-' + i + '"><div><h2 class="rf-last__h">Your ' + esc(r.from) + ' registration' + (F.reuse.length > 1 ? ' · ' + esc(r.label) : '') + '</h2><p>' + esc(r.line + ' · ' + r.names.slice(0, 4).join(', ') + (r.names.length > 4 ? '…' : '')) + '</p></div>' +
        '<p class="rf-last__btns"><button type="button" class="wk-btn" data-act="reuse" data-i="' + i + '">Reuse</button>' + (i === F.reuse.length - 1 ? '<button type="button" class="wk-linklike" data-act="startnew">Start new</button>' : '') + '</p></section>').join(''));
    }
    if (!STEPVIEW[state.step] || (state.step !== 'contact' && steps().indexOf(state.step) < 0)) state.step = state.step === 'communion' || state.step === 'meals' ? 'review' : 'people';
    const k = state.step;
    const body = top + (state.forHh && (k === 'contact' || k === 'review') ? howCard() : '') + (gate ? '' : progress()) + (k === 'people' ? fromLine() + againLine() : '') +
      '<section class="rs-card rs-card--' + k + '" data-k="step-' + k + '" data-reveal aria-labelledby="rs-h"><h2 class="ogc-sr" id="rs-h" tabindex="-1">' + esc(stepName(k)) + '</h2>' +
      (locked(k) ? '<fieldset class="rx-lock" disabled><legend class="ogc-sr">' + esc(stepName(k)) + '</legend>' + STEPVIEW[k]() + '</fieldset>' : STEPVIEW[k]()) + stepFoot() + '</section>' +
      (gate ? whoLine() : '') + afterCard(k);
    return stepPage(head, body);
  }
  // Under the card: the desk's day (Contact); Cancel registration, Start over and the local Clear (Review).
  function afterCard(k) {
    const F = state.F;
    if (k === 'contact') return state.desk && !state.forHh && (state.deskToday || []).length ? deskList() : '';
    if (k !== 'review') return '';
    return (state.editing && state.editing.can.cancel && !state.forHh ? '<p class="rf-quiet rf-cancel"><button type="button" class="wk-linklike" data-act="cancelreg" data-id="' + state.editing.id + '">Cancel registration</button></p>' : '') +
      (!state.editing && !state.desk ? '<p class="rf-quiet rs-over"><button type="button" class="wk-linklike" data-act="startover">Start over</button></p>' : '') +
      (W.dev && !W.prototype && F.member && !state.editing && !state.desk ? '<p class="rf-mock"><button type="button" class="ogc-mock" data-act="cleartests">Local · Clear test registrations</button></p>' : '');
  }

  // The quiet line of steps: the one open is marked; those that may be gone to are links.
  function progress() {
    const p = problems(), list = steps();
    return '<nav class="rs-prog" aria-label="Steps"><ol>' + list.map(k => {
      const name = esc(stepName(k));
      if (k === state.step) return '<li><span class="is-here" aria-current="step">' + name + '</span></li>';
      return '<li>' + (reachable(k, p) ? '<button type="button" class="rs-prog__b" data-act="goto" data-v="' + k + '">' + name + '</button>' : '<span class="is-later">' + name + '</span>') + '</li>';
    }).join('') + '</ol></nav>';
  }
  // Back and the one action, at the card's foot.
  function stepFoot() {
    const o = order(), i = o.indexOf(state.step), back = i > 0 && !(state.forHh && !state.editing && state.step === 'contact');
    return '<div class="rs-foot">' + (state.barNote ? '<p class="rx-note" role="status">' + esc(state.barNote) + '</p>' : '') +
      // Back names the step it goes to (B10); with no Back, nothing holds its place, so the one action
      // keeps the card's left edge on a phone (and margin-left: auto keeps it at the right on a laptop).
      (back ? '<button type="button" class="wk-linklike rs-back" data-act="back" aria-label="' + esc('Back to ' + stepName(o[i - 1])) + '">' + I.back + '<span>' + esc(stepName(o[i - 1])) + '</span></button>' : '') + primaryBtn(isPreview()) + '</div>';
  }
  const STEPVIEW = { contact: () => contactSec(), people: peopleStep, stay: stayStep, meals: mealsStep, communion: communionStep, review: reviewStep };

  // Filled in from last year: said once, over Who's coming, with what changed that isn't a person's (each
  // person's own change is on their row). Go to Review, or Start new.
  function fromLine() {
    const d = state.d, n = d.news || {};
    if (!d.from || state.editing || state.desk) return '';
    // The heading names the year once: "Kept 3 linen packets", not "Kept from 2026: …" (the server's
    // words keep the year, for the COA's lists and the emails).
    const items = (d.changes || []).filter(c => !c.pid).map(c => c.text.replace(/^Kept from \d{4}: /, 'Kept ')).concat(n.prices || []);
    return '<div class="rs-from" data-k="from"><p class="rs-from__h">' + I.check + '<span>From your ' + esc(d.from) + ' registration</span></p>' +
      (items.length ? '<p class="rs-from__sub">' + escn(items.join(' · ')) + '</p>' : '') +
      '<p class="rs-from__a"><button type="button" class="wk-linklike" data-act="goto" data-v="review">Go to Review</button><button type="button" class="wk-linklike" data-act="startnew">Start new</button></p></div>';
  }
  // Started new while last year's is there: a way back, until anything is filled in.
  const againLine = () => { const F = state.F, d = state.d; return !state.editing && !state.desk && d.start === 'new' && F.reuse.length === 1 && named().length <= 1 && !d.stay.type ? '<p class="rf-quiet rx-again"><button type="button" class="wk-linklike" data-act="reuse" data-i="0">' + esc('Fill in from ' + F.reuse[0].from) + '</button></p>' : ''; };

  // Today at the desk: the households entered here today.
  function deskList() {
    const list = (state.deskToday || []).slice().reverse();
    return '<aside class="reg-desklist" aria-label="Today at the desk"><p class="rf-label">Today at the desk</p><ul class="rf-items">' + list.map(r => '<li><span><b>' + esc(regName(r.data)) + '</b><small>' + escn([r.data.rid, statusWords({ data: r.data })].filter(Boolean).join(' · ')) + '</small></span></li>').join('') + '</ul></aside>';
  }
  /* ---------------------------------------------------------------- for a household, from the app (Round 5) */

  // Where Save and Back go: an address of this site's app only (area-households-money H9); anything else
  // is dropped and the form ends on its own page.
  function safeReturn(r) {
    if (!r) return '';
    try {
      const u = new URL(r, location.origin);
      return u.origin === location.origin && /\/annual-conference\/app\/$/.test(u.pathname) ? u.pathname + u.search : '';
    } catch (x) { return ''; }
  }
  // The screen it goes back to, by name: "‹ Households", "‹ Rooms".
  const RET = { households: 'Households', 'lod-households': 'Households', 'lod-rooms': 'Rooms', 'lod-checkin': 'Check-in', 'lod-yf': 'Young Folks', 'lod-campers': 'Campers', home: 'Home' };
  const retName = () => { try { return RET[new URL(state.ret, location.origin).searchParams.get('s') || 'home'] || 'Back'; } catch (x) { return 'Back'; } };
  // The return address with the household open (its R-number), and nothing to act on again.
  function backTo(rid) {
    const u = new URL(state.ret, location.origin);
    if (rid) u.searchParams.set('id', rid);
    u.searchParams.delete('at');
    return u.pathname + u.search;
  }
  // Say what was done once the app has loaded (its toast reads this: app.js A.flash).
  const flashApp = msg => { try { sessionStorage.setItem('ogc-app-flash', msg); } catch (x) { /* the app shows the record */ } };
  // The registration number (rid) is kept whole on one line: the title wraps only before it.
  function hhHead(title, rid) {
    document.documentElement.classList.add('adm-full');
    // No app address to go back to (one that wasn't this site's app was dropped): Your sign-ups.
    const to = state.ret || '?year=' + state.year + '&view=mine';
    return '<header class="ws-bar ws-bar--page"><div class="ws-bar__in"><a class="ws-back" data-act="leave" href="' + esc(to) + '">' + I.back + '<span>' + esc(state.ret ? retName() : 'Your sign-ups') + '</span></a>' +
      '<div class="ws-title"><p class="wk-kicker">' + esc(state.year + ' Annual Conference') + '</p><h1>' + esc(title) + (rid ? ' · <span style="white-space:nowrap">' + esc(rid) + '</span>' : '') + '</h1></div></div></header>';
  }
  // How it came (first, always open): Phone · Paper · Desk; Received on for a new call or letter.
  function howCard() {
    const paperOff = C('paper_forms') !== 'yes';
    const recv = state.desk && state.how !== 'desk';
    return '<section class="rs-how" aria-labelledby="rf-h-how"><p class="rs-k" id="rf-h-how">How it came</p>' +
      radios('How it came', 'hhhow', state.how, [['phone', 'Phone'], ['paper', 'Paper', paperOff && state.how !== 'paper'], ['desk', 'Desk']]) +
      (paperOff ? '<p class="rf-help">Paper forms off · Registration</p>' : '') +
      (recv ? '<div class="reg-field reg-field--date"><label class="reg-label" for="f-received">Received on</label><input class="reg-input" id="f-received" type="date" style="max-width:220px" data-recv max="' + esc(today()) + '" value="' + esc(state.received || today()) + '"></div>' : '') + '</section>';
  }
  // A household that may not be opened here (or no longer can be changed): what's true, and the way back.
  const goneView = () => page(hhHead('Not found'), blankCard('Not found', '', '<a class="wk-btn wk-btn--line wk-btn--small" href="' + esc(state.ret) + '">' + esc(retName()) + '</a>'));
  const loadDesk = () => api('GET', 'years/' + state.year + '/records?kinds=registrations').then(out => {
    state.deskToday = ((out && out.registrations) || []).map(x => ({ id: x.id, data: x.data || {} })).filter(r => r.data.source === 'desk' && r.data.at === today());
  }, () => { state.deskToday = []; });
  const editChanged = () => !!state.editing && JSON.stringify(cleanForCompare(state.d)) !== JSON.stringify(cleanForCompare(answersOf(state.editing.data)));

  // A way in for someone already registered (only while not signed in).
  function whoLine() {
    const me = SU.me();
    if (me && !me.pending) return '';
    return '<p class="rf-who rf-who--form rs-who"><a class="reg-tap" href="?year=' + esc(state.year) + '&view=mine">Already registered? Sign in</a></p>';
  }

  /* ---------------------------------------------------------------- words used in more than one place */

  // Who's coming, said once: "2 adults · 1 Young Folk · 3 children"; one person, their name.
  function peopleLine(d) {
    const ppl = d ? (d.people || []).filter(p => String(p.name || '').trim()) : named(), a = ppl.filter(p => p.kind === 'adult').length, y = ppl.filter(p => p.kind === 'yf').length, c = ppl.filter(p => p.kind === 'child').length;
    if (ppl.length === 1) return ppl[0].name.trim();
    return [a ? plural(a, 'adult') : '', y ? plural(y, 'Young Folk') : '', c ? plural(c, 'child', 'children') : ''].filter(Boolean).join(' · ');
  }
  // One meals phrase everywhere: "All 13 meals" or "11 of 13 meals".
  const summaryText = d => { d = d || state.d; const all = mealsHere(d), off = all.filter(m => mOff(d)[m.id]).length; return !all.length ? 'No meals' : off ? (all.length - off) + ' of ' + plural(all.length, 'meal') : 'All ' + plural(all.length, 'meal'); };
  // Each person's meals: "All 13 meals", or "65 meals · Anna none · Joel 8 of 13".
  function mealsWords(d) {
    const ppl = (d.people || []).filter(p => String(p.name || '').trim());
    const on = ppl.reduce((k, p) => k + mealsOn(p, d).length, 0), all = ppl.reduce((k, p) => k + myMeals(p, d).length, 0);
    if (!all) return 'No meals';
    // Every meal of each stay (the first day from supper, Oct 24): the meals in anyone's stay.
    if (isEveryMeal(d)) return 'All ' + plural(mealsAllIn(d).length, 'meal');
    // "Joy 12 of 13", never "Joy 12" (read as her age); one with more than her stay's, "Esther 10 meals".
    return [plural(on, 'meal')].concat(ppl.filter(p => !sameMeals(p, d)).map(p => first(p.name) + ' ' + mealsOf(p, d).replace(/^None$/, 'none'))).join(' · ');
  }
  const mealName = m => O.fmtDate(mealDate(m), 'weekdayShort') + ' ' + String(m.title).replace(/^(Breakfast|Lunch|Supper|Dinner).*$/i, '$1').toLowerCase();
  // Linens in words, one function for the form, Your sign-ups and the receipt (the server's
  // ogc_reg_linen_words for the emails): "Own linens", "4 linen packets".
  function linenWords(d) {
    d = d || state.d;
    const s = d.stay, rooms = s.type === 'dorm', ppl = d.people.filter(p => String(p.name || '').trim()), hall = ppl.filter(p => inHall(p, d)), yf = hall.filter(p => p.linens);
    const n = (rooms ? (+s.linens || 0) : 0) + yf.length;
    if (n) return ppl.length === 1 && n === 1 ? 'Linen packet' : plural(n, 'linen packet');
    return s.linenChoice && (rooms || hall.length) ? 'Own linens' : '';
  }
  const ARRIVE = { afternoon: 'Arriving afternoon', evening: 'Arriving evening', late: 'Arriving after 9 PM' };
  // The need boxes (docs/25, decision 20 A): each person's own (Oct 23: tied to the person, not a side
  // panel); the household's boxes Lodging filters by follow from them (settle). A crib for a child under 3.
  const NEED_P = [['ground', 'Ground floor'], ['walker', 'No stairs'], ['restroom', 'Near a restroom']];
  const NEED_ALL = NEED_P.concat([['crib', 'Crib']]);
  // "Adult", "Young Folk · 17", "Child · 10 · Preteen" (and Communing): who someone is, in a line.
  const kindLine = p => (p.kind === 'adult' ? 'Adult' : p.kind === 'yf' ? 'Young Folk' : 'Child') + (p.kind !== 'adult' && p.age !== '' ? ' · ' + p.age : '') + (p.preteen ? ' · Preteen' : '') + (p.communing ? ' · Communing' : '');
  // A person as the form says them: the first name, or the whole name when another shares it.
  const nameIn = p => { const f = first(p.name); return named().filter(x => first(x.name) === f).length > 1 ? p.name.trim() : f; };

  /* ---------------------------------------------------------------- 1 · Contact */

  function contactSec() {
    const h = state.d.household, x = state.d.helper, me = SU.me(), signed = me && !me.pending;
    const typo = e => { const t = typoOf(e), path = x.on ? 'helper.email' : 'household.email'; return t && /Did you mean/.test(state.errors[path] || '') ? '<button type="button" class="rf-fix rf-fix--pill" data-act="typo" data-path="' + path + '" data-v="' + esc(t) + '">Use ' + esc(t.slice(t.indexOf('@') + 1)) + '</button>' : ''; };
    const one = f => '<div class="reg-grid reg-grid--1">' + f + '</div>', pair = (a, b) => '<div class="reg-grid">' + a + b + '</div>';
    // The desk enters a household that isn't the one signed in: the email is theirs, optional, never locked.
    if (state.desk) return one(field('Name', 'household.contact', h.contact, { attrs: ' maxlength="80"' })) +
      pair(field('Email', 'household.email', h.email, { type: 'email', optional: true, attrs: ' inputmode="email" maxlength="120"', help: 'For the confirmation', fix: typo(h.email) }), field('Phone', 'household.phone', h.phone, { type: 'tel', attrs: ' maxlength="30"' }));
    const lockMail = signed && !state.editing ? ' readonly' : '';
    const phoneHelp = state.ui.phoneNew && !h.phone ? 'Add this year’s' : '';
    return '<p class="rf-row rx-first">' + radios('Registering', 'helper', x.on ? 'other' : 'me', [['me', 'For me'], ['other', 'For someone else']]) + '</p>' +
      (x.on ? '<p class="rf-label">You</p>' + one(field('Name', 'helper.name', x.name, { attrs: ' autocomplete="name" maxlength="80"' })) +
        pair(field('Email', 'helper.email', x.email, { type: 'email', attrs: ' autocomplete="email" inputmode="email" maxlength="120"' + (signed ? ' readonly' : ''), help: signed || codeSent() ? '' : 'A code is emailed to confirm it', fix: signed ? '' : typo(x.email) }), field('Phone', 'helper.phone', x.phone, { type: 'tel', optional: true, attrs: ' autocomplete="tel" maxlength="30"' })) +
        // The household must be reachable: its email or its phone, either one (the rule said once).
        '<p class="rf-label">Household contact</p>' + help('Email or phone, at least one') + one(field('Name', 'household.contact', h.contact, { attrs: ' maxlength="80"' })) +
        pair(field('Email', 'household.email', h.email, { type: 'email', optional: true, attrs: ' inputmode="email" maxlength="120"' + (state.editing ? ' readonly' : '') }), field('Phone', 'household.phone', h.phone, { type: 'tel', optional: true, attrs: ' maxlength="30"' }))
        : one(field('Name', 'household.contact', h.contact, { attrs: ' autocomplete="name" maxlength="80"' })) +
        pair(field('Email', 'household.email', h.email, { type: 'email', attrs: ' autocomplete="email" inputmode="email" maxlength="120"' + (lockMail || (state.editing ? ' readonly' : '')), help: signed || state.editing || codeSent() ? '' : 'A code is emailed to confirm it', fix: signed || state.editing ? '' : typo(h.email) }),
          field('Phone', 'household.phone', h.phone, { type: 'tel', attrs: ' autocomplete="tel" maxlength="30"', help: phoneHelp }))) + codeBox();
  }
  // The code, under the email it confirms: sent by Continue; six digits confirm it and the form goes
  // straight on. Code only (never a link to open in another tab, away from this draft).
  function codeBox() {
    const v = state.verify, want = wantEmail();
    if (state.editing || state.desk || verified() || !(v.step === 'sent' && v.email === want)) return v.err && v.step !== 'sent' ? '<p class="rf-err" role="alert">' + esc(v.err) + '</p>' : '';
    return '<div class="rf-verify" data-k="verify"><p class="rf-help rf-verify__to">Code sent · <button type="button" class="wk-linklike" data-act="otheremail">Use another email</button></p>' +
      field('Code', 'verify.code', v.code, { attrs: ' inputmode="numeric" autocomplete="one-time-code" pattern="[0-9 ]*" maxlength="9" enterkeyhint="done"', cls: 'rf-code', help: 'Keep this page open · Expires in 30 min' }) + (v.err ? '<p class="rf-err" role="alert">' + esc(v.err) + '</p>' : '') +
      '<p class="rf-quiet rf-verify__more"><button type="button" class="wk-linklike" data-act="resend"' + (Date.now() < v.retryAt ? ' disabled' : '') + '>' + esc(resendLabel()) + '</button></p>' +
      (v.dev ? '<p class="rf-mock"><span class="ogc-mock ogc-mock--tag">' + (W.prototype ? 'No email in the prototype · Code ' : 'Local: code ') + esc(v.dev) + '</span></p>' : '') + '</div>';
  }
  const codeSent = () => state.verify.step === 'sent' && state.verify.email === wantEmail() && !verified();
  // "Resend in 0:24", counting down, then "Resend".
  const resendLabel = () => { const t = Math.ceil((state.verify.retryAt - Date.now()) / 1000); return t > 0 ? 'Resend in ' + Math.floor(t / 60) + ':' + String(t % 60).padStart(2, '0') : 'Resend'; };
  function tickResend() {
    clearInterval(state.resendT);
    state.resendT = setInterval(() => {
      const b = root.querySelector('[data-act="resend"]');
      if (b) { b.textContent = resendLabel(); b.disabled = Date.now() < state.verify.retryAt; }
      if (Date.now() >= state.verify.retryAt) clearInterval(state.resendT);
    }, 1000);
  }
  // "Use gmail.com" beside a parent's address that looks mistyped (OGC_AUTH.suggest, the server's list).
  const parentFix = e => { const t = typoOf(e); return t && /Did you mean/.test(state.errors['stay.parentEmail'] || '') ? '<button type="button" class="rf-fix rf-fix--pill" data-act="typo" data-path="stay.parentEmail" data-v="' + esc(t) + '">Use ' + esc(t.slice(t.indexOf('@') + 1)) + '</button>' : ''; };
  const typoOf = e => { const t = String(e || '').trim().toLowerCase(); return t && window.OGC_AUTH && OGC_AUTH.suggest ? OGC_AUTH.suggest(t) || '' : ''; };
  // "Check gmial.com · Did you mean gmail.com?" (the server's words, ogc_typo).
  const typoWords = (e, fix) => 'Check ' + e.slice(e.indexOf('@') + 1) + ' · Did you mean ' + fix.slice(fix.indexOf('@') + 1) + '?';

  /* ---------------------------------------------------------------- 2 · Who's coming */

  // A person a row: their name, Adult · Young Folk · Child (with the age), and under it only their own
  // needs (an adult's three boxes, a crib for a child under 3; a Young Folk none). Nothing else is asked
  // here: where a Young Folk sleeps is in Stay, communing in Communion.
  function peopleStep() {
    const d = state.d, lock = locked('people');
    if (!d.people.length) d.people.push(person({ name: d.helper.on ? '' : d.household.contact }));
    const full = d.people.length >= MAXP;
    const peopleErr = state.errors.people === NOADULT ? '<p class="rf-err" id="' + errId('people') + '">' + esc(NOADULT) + ' · <button type="button" class="rf-fix" data-act="addadult">Add a grown-up</button></p>' : err('people');
    const kidsAlone = named().some(p => p.kind === 'child') && !adults().length && !state.desk;
    const withHh = kidsAlone && C('child_with_household') === 'yes' && !lock ? field('With household', 'stay.withHh', d.stay.withHh || '', { attrs: ' maxlength="80"', help: 'The household they’re with at Conference · For Lodging' }) : '';
    const needsShown = d.people.some(p => needBoxes(p));
    const ages = d.people.some(p => p.kind !== 'adult') && state.days.length;
    return '<ul class="rp-list">' + d.people.map((p, i) => personRow(p, i)).join('') + '</ul>' + peopleErr + withHh +
      (state.undo ? '<p class="rf-undo" role="status">Removed ' + esc(first(state.undo.p.name) || 'person') + ' · <button type="button" class="wk-linklike" data-act="undo">Undo</button></p>' : '') +
      (lock ? '' : '<p class="rp-add"><button type="button" class="wk-btn wk-btn--line wk-btn--small" data-act="add"' + (full ? ' disabled aria-describedby="help-maxp"' : '') + '>' + I.plus + 'Add person</button></p>' + (full ? help('Up to ' + MAXP + ' · Register another for the rest', 'help-maxp') : '')) +
      (ages || needsShown ? '<p class="rp-notes">' + (ages ? '<span>' + esc('Ages on ' + O.fmtDate(state.days[0].date, 'md')) + '</span>' : '') + (needsShown ? '<span>Only if needed · Lodging places by need</span>' : '') + '</p>' : '');
  }
  function personRow(p, i) {
    const at = 'people.' + p.pid, a = parseInt(p.age, 10), who = p.name.trim() || 'Person ' + (i + 1);
    const yfI = C('yf_help') ? { yf: infoBtn('yf-' + p.pid, 'Young Folk') } : null;
    const ageErr = () => { const t = state.errors[at + '.age'] || '', m = /^(.*) · Choose Child$/.exec(t); return m ? '<p class="rf-err" id="' + errId(at + '.age') + '">' + esc(m[1]) + ' · <button type="button" class="rf-fix" data-act="kind" data-pid="' + p.pid + '" data-v="child">Choose Child</button></p>' : err(at + '.age'); };
    const hint = p.kind === 'child' && (a === 16 || a === 17) ? '<p class="rf-help">16 and up · <button type="button" class="rf-fix" data-act="kind" data-pid="' + p.pid + '" data-v="yf">Young Folk?</button></p>' : '';
    const age = '<span class="rp-age">' + (p.kind !== 'adult' ? '<input name="' + at + '.age" type="text" inputmode="numeric" pattern="[0-9]*" maxlength="3" value="' + esc(p.age) + '" placeholder="Age" aria-label="' + esc(who + ', age' + (state.days.length ? ' on ' + O.fmtDate(state.days[0].date, 'md') : '')) + '"' + bad(at + '.age') + '>' : '') + '</span>';
    const rm = state.d.people.length > 1 && !locked('people') ? '<button type="button" class="reg-remove rp-rm" data-act="remove" data-pid="' + p.pid + '" aria-label="' + esc('Remove ' + who) + '">' + I.x + '</button>' : '';
    const tags = tagsOf(p);
    return '<li class="rp" data-k="p-' + esc(p.pid) + '"><div class="rp-top"><label class="rp-name"><span class="ogc-sr">' + esc('Name' + (i ? ', person ' + (i + 1) : '')) + '</span><input name="' + at + '.name" value="' + esc(p.name) + '" placeholder="Name" autocomplete="' + (i ? 'off' : 'name') + '" maxlength="80"' + bad(at + '.name') + '></label>' +
      '<span class="rp-kind rf-kind">' + radios(who + ': adult, Young Folk or child', 'kind', p.kind, [['adult', 'Adult'], ['yf', 'Young Folk'], ['child', 'Child']], ' data-pid="' + p.pid + '"', '', yfI) + '</span>' + age + rm + '</div>' +
      (yfI ? infoLine('yf-' + p.pid, C('yf_help')) : '') + ageErr() + hint +
      (tags.length ? '<p class="rx-ptags">' + tags.map(t => '<span class="rx-ptag">' + I.check + escn(t) + '</span>').join('') + '</p>' : '') + needBoxes(p) + ptQuestion(p) + '</li>';
  }
  // A child 10 to 13: the preteen program, Yes or No (Caleb, Oct 24: the 2026 form asked whether a child
  // takes part; this one didn't). Asked of the household, never ticked for them; their days, medical needs
  // and contacts follow on Communion when the COA collects them online.
  function ptQuestion(p) {
    if (!ptAge(p)) return '';
    const at = 'people.' + p.pid + '.pt', v = p.ptSet ? (p.ptOff ? 'no' : 'yes') : '';
    return '<div class="rp-pt"><span class="rp-pt__k" aria-hidden="true">Preteen program</span>' + radios((first(p.name) || 'This child') + ': preteen program', 'ptin', v, [['yes', 'Yes'], ['no', 'No']], ' data-pid="' + p.pid + '"', at) + '</div>' + err(at);
  }
  // A person's own needs, as a few boxes: only for a dorm room (or before the stay is chosen).
  function needBoxes(p) {
    const s = state.d.stay;
    if (s.type && s.type !== 'dorm') return '';
    const list = p.kind === 'adult' ? NEED_P : p.kind === 'child' && p.band === 'baby' ? [['crib', 'Crib']] : [];
    if (!list.length) return '';
    return '<div class="rp-needs" role="group" aria-label="' + esc((first(p.name) || 'This person') + ': needs') + '">' + list.map(x => '<label class="rf-check rp-need"><input type="checkbox" name="people.' + p.pid + '.' + x[0] + '"' + (p[x[0]] ? ' checked' : '') + '><span class="rf-check__b" aria-hidden="true">' + I.check + '</span><span>' + esc(x[1]) + '</span></label>').join('') + '</div>';
  }
  // What's new for this person this year (from dates and ages), marked on their row.
  // (The preteen program's own Yes or No is asked right there, so "10 · Preteen program" isn't said again.)
  const tagsOf = p => state.editing ? [] : (state.d.changes || []).filter(c => c.pid === p.pid && !(/ · Preteen program$/.test(c.text) && ptAge(p))).map(c => c.text.replace(/^\S+\s/, ''));

  /* ---------------------------------------------------------------- 3 · Stay */

  // The stay's price in the COA's words: a room or a person a night (charge), never assumed per bed.
  const roomPrice = () => C('charge') === 'person' ? $(cents('person_price_adult')) + ' a person a night' : $(cents('room_price')) + ' a room a night';
  function stayTiles() {
    const s = state.d.stay, L = state.F.left || {}, full = L.rooms === 0 && !state.editing, lock = locked('stay');
    const tile = (v, t, sub) => { const on = s.type === v; return '<button type="button" role="radio" aria-checked="' + on + '" tabindex="' + (on || (!s.type && v !== 'camper' && v !== 'elsewhere') ? 0 : -1) + '" class="rx-tile' + (on ? ' is-on' : '') + '" data-act="type" data-v="' + v + '"' + (lock && !on ? ' disabled' : lock ? ' aria-disabled="true"' : '') + '>' + DRAW[v] + '<span class="rx-tile__t"><b>' + esc(t) + '</b><small>' + escn(sub) + '</small></span><span class="rx-tile__ok" aria-hidden="true">' + I.check + '</span></button>'; };
    const camperSub = $(cents('camper_price')) + (C('camper_per') === 'stay' ? ' a camper' : ' a night') + ' · No hookups';
    // Young Folks on their own get the same three choices, their hall in place of a dorm room.
    const first3 = yfOnly() ? tile('yf', 'Young Folks hall', $(yfPer()) + ' a night') : tile('dorm', 'Dorm room', roomPrice() + (full ? ' · Full' : ''));
    return '<div class="rx-tiles rs-tiles' + (lock ? ' is-ro' : '') + '" role="radiogroup" aria-label="Where you’ll stay"' + (state.errors['stay.type'] ? ' aria-invalid="true" aria-describedby="' + errId('stay.type') + '"' : '') + '>' + first3 + tile('camper', 'Camper lot', camperSub) + tile('elsewhere', 'Off campus', yfOnly() ? 'Home or family nearby' : 'Meals only') + '</div>';
  }
  const blk = (k, label, body, cls) => body ? '<div class="rs-blk' + (cls ? ' ' + cls : '') + '" data-k="b-' + k + '">' + (label ? '<p class="rs-k">' + esc(label) + '</p>' : '') + body + '</div>' : '';
  function stayStep() {
    const d = state.d, s = d.stay, F = state.F, L = F.left || {}, full = L.rooms === 0 && !state.editing;
    let h = stayTiles() + err('stay.type') + (full && s.type === 'dorm' ? '<div class="rs-wl">' + togAct('waitlist', state.waitlist, 'Join waitlist') + help('Nothing is charged · ' + (ownerOr('owner') ? 'The ' + ownerOr('owner') + ' contacts you if a room opens' : 'You’re contacted if a room opens')) + '</div>' : '');
    if (!s.type) return h;
    h += s.type === 'elsewhere' ? daysPart() : nightsPart();
    if (s.type === 'dorm') h += roomsPart();
    if (s.type === 'camper') h += blk('camper', '', '<div class="rs-row"><span><b>Campers</b></span>' + stepper('stay.campers', s.campers || 1, 1, 4, 'Campers') + '</div><div class="rs-q"><p class="rs-k">Length</p>' + radios('Camper length', 'len', s.camperLen, [['short', 'Under 25 ft'], ['mid', '25–35 ft'], ['long', 'Over 35 ft']]) + '</div>');
    h += yfPart() + linensPart();
    if (s.type === 'dorm' || s.type === 'camper') h += blk('near', '', field('Near another household', 'stay.near', s.near || '', { optional: true, attrs: ' maxlength="60" autocomplete="off"', ph: 'Household name' }));
    if (s.type !== 'elsewhere') h += blk('arrive', 'Arriving', radios('Arriving', 'arrive', s.arrive, [['afternoon', 'Afternoon'], ['evening', 'Evening'], ['late', 'After 9 PM']]));
    if (s.type !== 'elsewhere') h += notePart();
    return h;
  }
  // The nights: every night to start; "Not everyone every night" opens a night a person.
  function nightsPart() {
    const s = state.d.stay, ns = nights(), per = s.perPerson || !!state.ui.perNights, who = named().filter(p => hasNights(p));
    const pills = '<div class="rs-pills" role="group" aria-label="Nights">' + ns.map(n => { const on = s.nights.indexOf(n) > -1; return '<button type="button" class="rs-pill' + (on ? ' is-on' : '') + (early(n) ? ' is-early' : '') + '" data-act="hnight" data-v="' + esc(n) + '" aria-pressed="' + on + '" aria-label="' + esc(O.fmtDate(nightDate(n), 'long') + ' night' + (early(n) ? ', early' : '')) + '">' + (early(n) ? '<i>Early</i>' : '') + '<b>' + esc(SU.nightShort(n)) + '</b><small>' + esc(O.fmtDate(nightDate(n), 'mdShort')) + '</small></button>'; }).join('') + '</div>';
    const span = gridSpan();
    const toggle = who.length > 1 ? '<label class="rf-check rs-per"><input type="checkbox" name="perNights"' + (per ? ' checked' : '') + '><span class="rf-check__b" aria-hidden="true">' + I.check + '</span><span>Not everyone every night</span></label>' : '';
    return blk('nights', 'Nights', (per ? nightsGrid(who, ns) : pills + (span ? '<p class="rf-help rs-span">' + escn(span) + '</p>' : '')) + err('stay.nights') + toggle);
  }
  // A night a person: names down the side, the nights across (44 px each).
  function nightsGrid(who, ns) {
    const errs = who.map(p => err('people.' + p.pid + '.nights')).join('');
    return '<div class="rg rg--nights" style="--n:' + ns.length + '"><div class="rg-row rg-head" aria-hidden="true"><span></span>' + ns.map(n => '<span class="rg-d' + (early(n) ? ' is-early' : '') + '"><b>' + esc(SU.nightShort(n)) + '</b><small>' + esc(O.fmtDate(nightDate(n), 'mdShort')) + '</small></span>').join('') + '</div>' +
      who.map(p => { const mine = nightsShown(p); return '<div class="rg-row" data-k="rgn-' + esc(p.pid) + '"><span class="rg-n">' + esc(nameIn(p)) + '</span>' + ns.map(n => { const on = mine.indexOf(n) > -1; return '<button type="button" class="rg-cell' + (on ? ' is-on' : '') + (early(n) ? ' is-early' : '') + '" data-act="gnight" data-pid="' + p.pid + '" data-v="' + esc(n) + '" aria-pressed="' + on + '" tabindex="' + (state.ui.gcell === p.pid + '|' + n ? 0 : -1) + '" aria-label="' + esc(nameIn(p) + ', ' + O.fmtDate(nightDate(n), 'long') + ' night') + '">' + I.check + '</button>'; }).join('') + '</div>'; }).join('') + '</div>' + errs;
  }
  // Off campus: the days here (for the meal counts).
  function daysPart() {
    const s = state.d.stay, days = visitDays();
    return blk('days', 'Days here', '<div class="rs-pills" role="group" aria-label="Days here">' + days.map(x => { const on = s.days.indexOf(x.date) > -1; return '<button type="button" class="rs-pill' + (on ? ' is-on' : '') + '" data-act="gday" data-v="' + esc(x.date) + '" aria-pressed="' + on + '" aria-label="' + esc(O.fmtDate(x.date, 'long')) + '"><b>' + esc(x.name.slice(0, 3)) + '</b><small>' + esc(O.fmtDate(x.date, 'mdShort')) + '</small></button>'; }).join('') + '</div>' + err('stay.days') +
      (C('nearby_lodging') ? help('Nearby: ' + C('nearby_lodging').split('|').join(' · ')) : ''));
  }
  // A dorm: the rooms (following who's sleeping, changeable), who sleeps where and the keys, air mattresses.
  function roomsPart() {
    const s = state.d.stay, L = state.F.left || {}, sl = sleepers().length, over = sl > s.rooms * beds(), extra = sl - s.rooms * (beds() - 1), need = Math.ceil(sl / beds());
    const leftT = n => n == null || n > 10 ? '' : n === 0 ? ' · None left' : ' · Only ' + n + ' left';
    const words = mattressWords(over, extra);
    return blk('rooms', '', '<div class="rs-row"><span><b>Rooms</b><small>' + esc(plural(beds() - 1, 'bed') + ' a room') + '</small></span>' + stepper('stay.rooms', s.rooms, 1, 6, 'Rooms') + '</div>' +
      (state.errors['stay.rooms'] || over ? '<p class="rf-err" id="' + errId('stay.rooms') + '">' + esc(sl + ' people need ' + need + ' rooms') + ' · <button type="button" class="rf-fix" data-act="userooms" data-v="' + need + '">Use ' + need + ' rooms</button></p>' : '') +
      // The air mattresses right under the rooms they make up for, the fact in their own line; the
      // stepper is the one way to change them.
      (C('mattress_price') ? '<div class="rs-row rs-row--sub"><span><b>Air mattresses</b><small>' + escn($(cents('mattress_price')) + ' each' + leftT(L.mattresses) + (words ? ' · ' + words : '')) + '</small></span>' + stepper('stay.mattresses', s.mattresses, 0, Math.max(s.mattresses, Math.min(6, L.mattresses == null ? 6 : L.mattresses)), 'Air mattresses') + '</div>' + err('stay.mattresses') : '') +
      whereLine() + pickRow() + err('stay.chosen'));
  }
  // Who sleeps in which room, and who picks up each room's keys: said in a line; Change opens the choices.
  function whereLine() {
    const s = state.d.stay, ok = adults(), sl = sleepers(), babies = named().filter(p => p.band === 'baby' && !inHall(p));
    const multi = s.rooms > 1 && sl.length > 1;
    if (!sl.length || (!multi && ok.length < 2)) return '';
    const dup = n => ok.filter(p => first(p.name) === first(n)).length > 1, keyName = n => dup(n) ? firstL(n) : first(n);
    const open = !!state.ui.where;
    const rooms = Array.from({ length: s.rooms }, (_, i) => ({ i, who: sl.filter(p => p.room === i).concat(s.rooms === 1 ? babies : []), key: s.keys[i] }));
    const lines = rooms.map(r => '<li><span class="rs-room__n">' + esc(s.rooms > 1 ? 'Room ' + (r.i + 1) : 'Keys') + '</span><span>' + escn(s.rooms > 1 ? (r.who.map(nameIn).join(', ') || 'Nobody yet') + (r.key ? ' · Keys: ' + keyName(r.key) : '') : keyName(r.key || '')) + '</span>' + (s.rooms > 1 && r.who.length && !r.who.some(p => p.kind === 'adult') ? '<small class="rs-room__flag">No adult in this room</small>' : '') + '</li>').join('');
    const pick = open ? '<div class="rs-where__edit">' + (multi ? sl.map(p => '<div class="rs-where__p"><span>' + esc(nameIn(p)) + '</span>' + radios(nameIn(p) + '’s room', 'room', String(p.room), Array.from({ length: s.rooms }, (_, k) => [String(k), 'Room ' + (k + 1)]), ' data-pid="' + p.pid + '"', '', null, true) + '</div>').join('') : '') +
      (ok.length > 1 ? rooms.map(r => '<div class="rs-where__p"><span>' + esc(s.rooms > 1 ? 'Room ' + (r.i + 1) + ' keys' : 'Keys') + '</span>' + radios((s.rooms > 1 ? 'Room ' + (r.i + 1) + ' ' : '') + 'keys', 'key', s.keys[r.i], ok.map(p => [p.name.trim(), keyName(p.name)]), ' data-i="' + r.i + '"', '', null, true) + '</div>').join('') + help('Only the person named picks up a room’s keys') : '') + '</div>' : '';
    const head = multi ? '<b>Who sleeps where</b>' : '<b>Keys</b>' + (open ? '' : '<small>' + esc(keyName(s.keys[0] || '')) + '</small>');
    return '<div class="rs-where" data-k="where"><div class="rs-row rs-row--sub"><span>' + head + '</span><button type="button" class="wk-linklike rs-where__a" data-act="where" aria-expanded="' + open + '">' + (open ? 'Done' : 'Change') + '</button></div>' + (open ? pick : multi ? '<ul class="rs-rooms">' + lines + '</ul>' : '') + '</div>';
  }
  // Linens, asked once for the whole household: Bring our own · Order packets, then a pill a sleeper.
  function linensPart() {
    const s = state.d.stay, who = linenPeople(), L = state.F.left || {};
    if (!who.length) return '';
    const req = C('linens_required') === 'yes' && s.type === 'dorm', one = named().length === 1, hallToo = who.some(p => inHall(p));
    const low = L.linens != null && L.linens <= 10 ? (L.linens === 0 ? ' · None left' : ' · Only ' + L.linens + ' left') : '';
    const choice = req && !hallToo ? '' : radios('Linens', 'linenchoice', s.linenChoice, [['own', one ? 'Bring my own' : 'Bring our own'], ['order', one ? 'Order a packet' : 'Order packets']], '', 'stay.linenChoice');
    const pick = !one && (s.linenChoice === 'order' || req) ? '<span class="rf-asks rf-linwho" role="group" aria-label="Linen packets for">' + who.map(p => togAct('linfor', hasPacket(p), nameIn(p), ' data-pid="' + p.pid + '"' + (req && !inHall(p) ? ' disabled' : ''))).join('') + '</span>' : '';
    return blk('linens', 'Linens', choice + err('stay.linenChoice') + err('stay.linens') + pick + help((req ? 'One packet each in the rooms · ' : 'Sheets, pillow, blanket, towels · ') + $(cents('linen_price')) + ' a packet' + low));
  }
  // Young Folks, only when there are some: where each sleeps (a hall, or with the family), who they're
  // rooming with (a note for Lodging, never matched: docs/25), and a parent's approval when under 18.
  function yfPart() {
    const ys = yfs(), s = state.d.stay;
    if (!ys.length) return '';
    const alone = minorsAlone(), grown = adults().length > 0, firstHallMinor = named().find(x => x.minor && inHall(x));
    const rows = ys.map(yfRow).join('');
    const appr = alone ? field('Parent’s email', 'stay.parentEmail', s.parentEmail, { type: 'email', cls: 'rf-parent', attrs: ' inputmode="email" maxlength="120"', help: 'Under 18 · Emailed to approve', fix: parentFix(s.parentEmail) }) : grown && firstHallMinor ? approvalPart() : '';
    const rule = C('yf_age_split') === 'yes' && ys.some(p => inHall(p)) ? help('Rooms: all 17 and under, or all 18 and over (state law)') : '';
    const keys = C('yf_keys') && ys.some(p => inHall(p)) ? help(C('yf_keys')) : '';
    return rows || appr ? blk('yf', 'Young Folks', rows + appr + rule + keys) : '';
  }
  function yfRow(p) {
    const s = state.d.stay, at = 'people.' + p.pid, grown = adults().length > 0, who = first(p.name) || 'Young Folk';
    const halls = [['men', 'Young men’s hall'], ['women', 'Young women’s hall']];
    const q2 = grown ? radios(who + ' sleeps in', 'hall', p.sleeps === 'family' ? 'family' : p.yfHall, halls.concat([['family', s.type === 'camper' ? 'In the camper' : s.type === 'elsewhere' ? 'With us' : 'In our rooms']]), ' data-pid="' + p.pid + '"', at + '.yfHall')
      : s.type === 'yf' ? radios(who + ' sleeps in', 'hall', p.yfHall, halls, ' data-pid="' + p.pid + '"', at + '.yfHall') : '';
    if (!q2) return '';
    return '<div class="rs-yf" data-k="yf-' + esc(p.pid) + '"><p class="rs-yf__n">' + esc(p.name.trim()) + (p.age !== '' ? ' <small>' + esc(p.age) + '</small>' : '') + '</p>' + q2 + err(at + '.yfHall') +
      (inHall(p) && p.yfHall ? '<label class="rs-rooming"><span>Rooming with</span><input name="' + at + '.rooming" type="text" value="' + esc(p.rooming) + '" autocomplete="off" maxlength="80"></label>' : '') + '</div>';
  }
  // Under 18 in the halls with a grown-up along: the grown-up is the parent, or a parent is asked by email
  // (a grandmother bringing a grandson). Carried from last year, so a returning household isn't stopped.
  function approvalPart() {
    const s = state.d.stay, who = named().filter(p => p.minor && inHall(p));
    return '<div class="rf-approval rs-appr" data-k="approval"><p class="rs-sub">' + esc('Under 18' + (who.length ? ' · ' + andList(who.map(p => first(p.name))) : '')) + '</p>' + radios('Under 18: parent approval', 'approval', s.yfOk ? 'self' : s.ask ? 'ask' : '', [['self', 'I’m the parent'], ['ask', 'Ask a parent']], '', 'stay.yfOk') + err('stay.yfOk') +
      (s.ask ? field('Parent’s email', 'stay.parentEmail', s.parentEmail, { type: 'email', cls: 'rf-parent', attrs: ' inputmode="email" maxlength="120"', help: 'Emailed to approve', fix: parentFix(s.parentEmail) }) : '') + '</div>';
  }
  // The one note for people (docs/25: never read by the site): a quiet link until there's something in it.
  function notePart() {
    const s = state.d.stay, d = state.d, owner = ownerOr('owner'), label = owner ? 'Note to the ' + owner : 'Note';
    const carried = d.from && !state.editing && s.needs && d.was && s.needs === d.was.note;
    if (!state.ui.note && !s.needs) return '<p class="rf-quiet rs-note"><button type="button" class="wk-linklike" data-act="note" aria-expanded="false">' + esc(owner ? 'Add a note to the ' + owner : 'Add a note') + '</button></p>';
    return blk('note', '', '<div class="reg-field"><label class="reg-label" for="f-stay-needs">' + esc(label) + (carried ? ' <span class="rx-tag rx-tag--check">From ' + esc(d.from) + ' · Check</span>' : '') + '</label><textarea id="f-stay-needs" name="stay.needs" rows="3" maxlength="500">' + esc(s.needs) + '</textarea>' + err('stay.needs') + '</div>');
  }
  // The air mattresses' fact, in plain words on their own row: one more person than beds ("1 more person
  // than beds"), or more kept than are needed ("1 needed", "Not needed"). (The data-act="mattress" fix
  // that drew beside the rooms is gone; its handler is kept.)
  function mattressWords(over, extra) {
    const s = state.d.stay;
    if (over || !C('mattress_price')) return '';
    const need = Math.max(0, extra);
    if (s.mattresses > need) return need ? need + ' needed' : 'Not needed';
    if (need > s.mattresses) return plural(need, 'more person', 'more people') + ' than beds';
    return '';
  }
  // The days worth coming for: those with meals or something on the schedule.
  function visitDays() {
    const on = new Set(state.meals.map(mealDate));
    ((state.model && state.model.days) || []).forEach(x => { if ((x.items || []).length) on.add(x.date); });
    const list = state.days.filter(x => on.has(x.date));
    return list.length ? list : state.days;
  }
  // What a Young Folk's hall costs a night (the server's yf_charge: a share of a room, a room, or a price).
  const yfPer = () => { const yfc = C('yf_charge') || 'share'; return yfc === 'person' ? cents('yf_price') : yfc === 'room' ? cents('room_price') : Math.round(cents('room_price') / Math.max(1, +C('room_beds') || 2)); };

  /* ---------------------------------------------------------------- the nights' and meals' arithmetic */

  const mealLetter = t => { const m = /^(breakfast|lunch|supper|dinner)/i.exec(String(t)); return m ? { breakfast: 'B', lunch: 'L', supper: 'S', dinner: 'S' }[m[1].toLowerCase()] : String(t).trim().charAt(0).toUpperCase(); };
  const mealWord = t => String(t).replace(/^(Breakfast|Lunch|Supper|Dinner).*$/i, '$1');
  function gridCols(d) {
    d = d || state.d;
    const s = d.stay, away = s.type === 'elsewhere';
    const out = [];
    if (!away) nights().filter(early).forEach(n => out.push({ key: n, date: nightDate(n), name: n.replace(/^Early /, ''), night: n, early: true, meals: [] }));
    const main = mainNights(), days = away ? visitDays() : state.days;
    days.forEach(x => {
      const n = away ? '' : main.find(m => m.slice(0, 3).toLowerCase() === x.name.slice(0, 3).toLowerCase()) || '';
      out.push({ key: x.date, date: x.date, name: x.name, night: n, meals: state.meals.filter(m => mealDate(m) === x.date) });
    });
    // Hall nights for Young Folks of a household off campus: the Conference's nights.
    if (away && (d.people || []).some(p => String(p.name || '').trim() && inHall(p, d))) state.days.forEach(x => { const c = out.find(y => y.date === x.date), n = main.find(m => m.slice(0, 3).toLowerCase() === x.name.slice(0, 3).toLowerCase()); if (c && n) c.night = n; });
    return out;
  }
  const hasNights = (p, d) => { d = d || state.d; return d.stay.type !== 'elsewhere' || inHall(p, d); };
  const nightsShown = (p, d) => { d = d || state.d; if (!hasNights(p, d)) return []; return d.stay.perPerson ? (p.nights || []) : nightsFor(p, d); };
  // "Check-in Fri May 28 · Check-out Wed Jun 2", from the nights chosen.
  const gridSpan = () => { const s = state.d.stay; if (!s.type) return ''; if (s.type === 'elsewhere') return s.days.length ? plural(s.days.length, 'day') + ' here' : ''; const ns = s.nights; return ns.length ? 'Check-in ' + shortDate(nightDate(ns[0])) + ' · Check-out ' + shortDate(O.isoAddDays(nightDate(ns[ns.length - 1]), 1)) : ''; };
  // A night on or off for one person: their own nights from then on, until every row is the same again.
  function setNight(p, n, on) {
    const d = state.d, s = d.stay;
    if (!s.perPerson) { named().forEach(x => { x.nights = hasNights(x) ? nightsFor(x, d).slice() : []; }); s.perPerson = true; }
    const set = new Set(p.nights || []);
    if (on) set.add(n); else set.delete(n);
    p.nights = nights().filter(x => set.has(x));
    sameNights();
  }
  function sameNights() {
    const d = state.d, s = d.stay, rows = named().filter(x => hasNights(x));
    if (!s.perPerson || !rows.length || s.type === 'elsewhere') return;
    const k = rows[0].nights.join('|');
    if (k && rows.every(x => x.nights.join('|') === k)) { s.nights = rows[0].nights.slice(); s.perPerson = false; named().forEach(x => { x.nights = []; }); }
  }
  // A meal on or off for one person: a meal nobody eats is skipped; one everyone eats lists no one.
  function setMeal(p, m, on) {
    const d = state.d, all = named().map(x => x.pid), mm = d.meals;
    const cur = new Set(mm.off[m.id] ? [] : mm.who[m.id] || all);
    if (on) cur.add(p.pid); else cur.delete(p.pid);
    if (!cur.size) { mm.off[m.id] = true; delete mm.who[m.id]; }
    else { delete mm.off[m.id]; if (all.every(x => cur.has(x))) delete mm.who[m.id]; else mm.who[m.id] = all.filter(x => cur.has(x)); }
    // A meal changed by hand: Every meal holds only while every meal of each stay is still ticked.
    mm.every = isEveryMeal(d);
  }
  const myMeals = (p, d) => { d = d || state.d; const ds = personDays(p, d); return state.meals.filter(m => ds.indexOf(mealDate(m)) > -1); };
  const mealsOn = (p, d) => { d = d || state.d; return myMeals(p, d).filter(m => eats(p, m, d)); };
  // The meals inside a person's stay, which Every meal ticks (Caleb, Oct 24: "if somebody arrives on Sunday
  // night… only supper is selected by default, but you can toggle them on"): every meal on the days they're
  // here, but on the day of their first night only from supper on, and none that day when the household
  // arrives after 9 PM. Here from an early night, or off campus on the days chosen: every meal those days.
  // The rest of the first day can still be ticked by hand.
  function mealsIn(p, d) {
    d = d || state.d;
    const st = d.stay || {}, all = myMeals(p, d);
    if (!all.length || (st.type === 'elsewhere' && !inHall(p, d))) return all;
    const ns = nightsFor(p, d);
    if (!ns.length || ns.some(early)) return all;
    const day0 = nightDate(ns[0]), today = all.filter(m => mealDate(m) === day0);
    const late = st.arrive === 'late' && ns[0] === (st.nights || [])[0];
    const k = late ? -1 : today.findIndex(m => /^(supper|dinner)/i.test(mealWord(m.title)));
    const keep = k < 0 ? [] : today.slice(k);
    return all.filter(m => mealDate(m) !== day0 || keep.indexOf(m) > -1);
  }
  // Every meal as the meals are kept (off: a meal no one here eats; who: those who do, when not everyone
  // here does), so the server's counts follow each person as before.
  function everyMeal(d) {
    const ppl = d.people.filter(p => String(p.name || '').trim()), off = {}, who = {};
    const ins = {}, days = {};
    ppl.forEach(p => { ins[p.pid] = mealsIn(p, d).map(m => m.id); days[p.pid] = personDays(p, d); });
    state.meals.forEach(m => {
      const here = ppl.filter(p => days[p.pid].indexOf(mealDate(m)) > -1), eat = here.filter(p => ins[p.pid].indexOf(m.id) > -1);
      if (!here.length || eat.length === here.length) return;
      if (!eat.length) off[m.id] = true; else who[m.id] = eat.map(p => p.pid);
    });
    return { off, who };
  }
  // Does each person eat exactly the meals of their stay?
  const sameMeals = (p, d) => { const a = mealsOn(p, d).map(m => m.id), b = mealsIn(p, d).map(m => m.id); return a.length === b.length && a.every(x => b.indexOf(x) > -1); };
  const isEveryMeal = d => d.people.filter(p => String(p.name || '').trim()).every(p => sameMeals(p, d));
  // The meals in anyone's stay, in order (the "All 13 meals" and "Fri supper to Tue supper" of Every meal).
  const mealsAllIn = d => { const ids = new Set(); d.people.filter(p => String(p.name || '').trim()).forEach(p => mealsIn(p, d).forEach(m => ids.add(m.id))); return state.meals.filter(m => ids.has(m.id)); };
  // A person's meals in a few words: "All 13", "11 of 13", "None"; more than their stay's: "10 meals".
  const mealsOf = (p, d) => { const n = mealsOn(p, d), k = mealsIn(p, d); if (sameMeals(p, d)) return k.length ? 'All ' + k.length : 'None'; if (!n.length) return 'None'; return n.every(m => k.indexOf(m) > -1) ? n.length + ' of ' + k.length : plural(n.length, 'meal'); };
  // The baseline a change compares with: last year's, as filled in (or a change's saved registration).
  function wasSnap(d) {
    const o = { p: {}, note: d.stay.needs || '', days: (d.stay.days || []).slice() };
    d.people.filter(p => String(p.name || '').trim()).forEach(p => { o.p[p.pid] = { name: p.name, n: nightsShown(p, d).slice(), m: mealsOn(p, d).map(m => m.id) }; });
    return o;
  }

  /* ---------------------------------------------------------------- 4 · Meals */

  // Every meal · Not every meal, with the grid always under it (Caleb, Oct 24: "if you do every meal, then they
  // see that every one of them is checked off… until they click it, they don't see the options below").
  // Every meal ticks each person's stay (mealsIn: the first day from supper); a meal tapped in the grid
  // makes it Not every meal. A grid on a laptop; one person at a time on a phone.
  function mealsStep() {
    const d = state.d, all = mealsAllIn(d), every = !!d.meals.every;
    const span = all.length > 1 ? mealName(all[0]) + ' to ' + mealName(all[all.length - 1]) : '';
    const priced = (C('meals_free') || 'yes') === 'no' ? help($(cents('meal_price_adult')) + ' a meal, 12 and up · ' + $(cents('meal_price_child')) + ', 3 to 11 · Under 3 free') : '';
    const line = every ? [all.length ? plural(all.length, 'meal') : 'No meals', span].filter(Boolean).join(' · ') : mealsWords(d);
    return blk('msum', '', radios('Meals', 'mealsmode', every ? 'every' : 'some', [['every', 'Every meal'], ['some', 'Not every meal']]) + '<p class="rf-help rs-span">' + escn(line) + '</p>' + priced, 'rs-blk--top') +
      (mealsHere(d).length ? blk('mgrid', '', narrow() ? mealsOne() : mealsGrid()) : '');
  }
  // A person's own "All 13" (every meal of their stay; tapped again, none).
  const mealsPill = (p, label) => { const d = state.d, all = sameMeals(p, d), none = !mealsOn(p, d).length; return '<button type="button" class="rg-cnt' + (all && !none ? ' is-all' : none ? ' is-none' : '') + '" data-act="gmeals" data-pid="' + p.pid + '" aria-pressed="' + (all && !none) + '"' + (label ? '' : ' aria-label="' + esc(nameIn(p) + ': every meal') + '"') + '>' + esc((label ? nameIn(p) + ' · ' : '') + mealsOf(p, d)) + '</button>'; };
  const mealDays = () => state.days.filter(x => state.meals.some(m => mealDate(m) === x.date));
  function mealsGrid() {
    const d = state.d, ppl = named(), days = mealDays();
    return '<div class="rg rg--meals" style="--n:' + days.length + '"><div class="rg-row rg-head" aria-hidden="true"><span></span>' + days.map(x => '<span class="rg-d"><b>' + esc(x.name.slice(0, 3)) + '</b><small>' + esc(O.fmtDate(x.date, 'mdShort')) + '</small></span>').join('') + '<span></span></div>' +
      ppl.map(p => {
        const here = personDays(p, d);
        return '<div class="rg-row" data-k="rgm-' + esc(p.pid) + '"><span class="rg-n">' + esc(nameIn(p)) + '</span>' + days.map(x => '<span class="rg-ms">' + state.meals.filter(m => mealDate(m) === x.date).map(m => {
          const in_ = here.indexOf(x.date) > -1, e = in_ && eats(p, m, d);
          return '<button type="button" class="rg-m' + (e ? ' is-on' : '') + '" data-act="gmeal" data-pid="' + p.pid + '" data-id="' + esc(m.id) + '" aria-pressed="' + e + '"' + (in_ ? '' : ' disabled') + ' tabindex="' + (state.ui.gcell === p.pid + '|' + m.id ? 0 : -1) + '" aria-label="' + esc(nameIn(p) + ', ' + O.fmtDate(x.date, 'weekday') + ' ' + mealWord(m.title).toLowerCase()) + '" data-tip="' + esc(mealWord(m.title)) + '">' + esc(mealLetter(m.title)) + '</button>';
        }).join('') + '</span>').join('') +
          '<span class="rg-all">' + mealsPill(p) + '</span></div>';
      }).join('') + '</div><p class="rf-help rg-key">B breakfast · L lunch · S supper</p>';
  }
  // A phone's meal line keeps each meal in its own column, so Friday's lone Supper sits under the Suppers.
  const MEALCOL = { breakfast: 1, lunch: 2, supper: 3, dinner: 3 };
  function mealsOne() {
    const d = state.d, ppl = named(), p = ppl.find(x => x.pid === state.ui.mealP) || ppl[0];
    if (!p) return '';
    const here = personDays(p, d), on = mealsOn(p).length, all = myMeals(p).length;
    return (ppl.length > 1 ? radios('Whose meals', 'mealp', p.pid, ppl.map(x => [x.pid, nameIn(x)]), '', '', null, true) : '') +
      '<div class="rm-days" data-k="rm-' + esc(p.pid) + '">' + mealDays().map(x => { const in_ = here.indexOf(x.date) > -1; return '<div class="rm-day"><span class="rm-day__d"><b>' + esc(x.name.slice(0, 3)) + '</b><small>' + esc(O.fmtDate(x.date, 'mdShort')) + '</small></span><span class="rm-day__m">' + state.meals.filter(m => mealDate(m) === x.date).map(m => { const e = in_ && eats(p, m, d); return '<button type="button" class="rm-m' + (e ? ' is-on' : '') + '" style="grid-column:' + (MEALCOL[mealWord(m.title).toLowerCase()] || 'auto') + '" data-act="gmeal" data-pid="' + p.pid + '" data-id="' + esc(m.id) + '" aria-pressed="' + e + '"' + (in_ ? '' : ' disabled') + ' aria-label="' + esc(nameIn(p) + ', ' + O.fmtDate(x.date, 'weekday') + ' ' + mealWord(m.title).toLowerCase()) + '">' + esc(mealWord(m.title)) + '</button>'; }).join('') + '</span></div>'; }).join('') + '</div>' +
      '<p class="rm-all">' + mealsPill(p, true) + '</p>';
  }

  /* ---------------------------------------------------------------- 5 · Communion (and preteens) */

  function communionStep() {
    const cs = communers(), help_ = C('communing_help') ? help(C('communing_help')) : '';
    return (cs.length ? blk('comm', 'Communing', '<div class="rs-checks">' + cs.map(p => '<label class="rf-check"><input type="checkbox" name="people.' + p.pid + '.communing"' + (p.communing ? ' checked' : '') + '><span class="rf-check__b" aria-hidden="true">' + I.check + '</span><span>' + esc(p.name.trim()) + '</span></label>').join('') + '</div>' + help_, 'rs-blk--top') : '') +
      (ptAsk() ? preteenPart() : '');
  }
  function preteenPart() {
    // Only the children in the program (their Yes is on Who's coming), each by name.
    const d = state.d, kids = named().filter(p => p.preteen), pts = kids, ok = adults(), pd = ptDays();
    const inBox = p => '<p class="reg-pt__n">' + esc(p.name.trim()) + '</p>';
    const days = (p, pt) => pd.length ? '<div class="rf-pline rf-pline--opts"><span class="rf-plabel" aria-hidden="true">Days</span><span class="rf-asks" role="group" aria-label="' + esc(first(p.name) + '’s days') + '">' + pd.map(x => togAct('ptday', (pt.days || []).indexOf(x) > -1, x.slice(0, 3), ' data-pid="' + p.pid + '" data-v="' + esc(x) + '"')).join('') + '</span></div>' : '';
    // The PRETEENS label is right above it, and who's in was asked on Who's coming.
    const head = '';
    // Opened by someone who may not see children's details (Lodging at the desk; decision 25): the days
    // only, and one line saying who keeps the rest. The server keeps what's withheld as it was.
    if (d.contacts.some(c => c.withheld) || pts.some(p => d.preteens[p.pid] && d.preteens[p.pid].withheld)) {
      return blk('pt', 'Preteens', head + kids.map(p => { const pt = d.preteens[p.pid] || (d.preteens[p.pid] = { days: pd.slice() }); return '<div class="reg-pt" data-k="pt-' + p.pid + '">' + inBox(p) + (p.preteen ? '<div class="reg-pt__in">' + days(p, pt) + '</div>' : '') + '</div>'; }).join('') +
        '<p class="rf-help rf-help--i">' + esc('Pick-ups, medical needs and emergency contacts · ' + (ownerOr('ptOwner') ? 'The ' + ownerOr('ptOwner') : 'Preteens') + ' or the COA') + '</p>');
    }
    const someone = !!state.ui.pickOther || !!d.pickupOther;
    const kidRows = kids.map(p => { const pt = d.preteens[p.pid] || (d.preteens[p.pid] = { medical: '', days: pd.slice() }); return '<div class="reg-pt" data-k="pt-' + p.pid + '">' + inBox(p) + (p.preteen ? '<div class="reg-pt__in">' + days(p, pt) +
        field('Allergies, medical needs', 'preteens.' + p.pid + '.medical', pt.medical || '', { area: true, optional: true }) +
        '<p class="rf-help rf-help--i">' + esc(ownerOr('ptOwner') ? 'Seen by the ' + ownerOr('ptOwner') : 'Private') + info('pt-' + p.pid, 'Who sees this', 'Your household · ' + (ownerOr('ptOwner') ? 'The ' + ownerOr('ptOwner') : 'Those the COA names') + ' · The COA · Not other households') + '</p></div>' : '') + '</div>'; }).join('');
    if (!pts.length) return blk('pt', 'Preteens', head + kidRows);
    // The second emergency contact waits behind a link until it's wanted (or has something in it).
    const c2 = state.ui.contact2 || d.contacts.slice(1).some(c => String(c.name || '').trim() || String(c.phone || '').trim() || String(c.rel || '').trim());
    return blk('pt', 'Preteens', head + kidRows +
      (ok.length ? '<div class="rs-q"><p class="rs-sub">Picked up by</p><span class="rf-asks">' + ok.map(p => togAct('pickup', !d.pickupWho.length || d.pickupWho.indexOf(p.name.trim()) > -1, nameIn(p), ' data-v="' + esc(p.name.trim()) + '"')).join('') + togAct('pickother', someone, 'Someone else') + '</span>' + (someone ? field('Someone else', 'pickupOther', d.pickupOther, { attrs: ' maxlength="120"', ph: 'Name and relationship' }) : '') + '</div>' : '') +
      '<p class="rs-sub rs-sub--gap">Emergency contacts</p>' + help('If you can’t be reached') +
      d.contacts.slice(0, c2 ? 2 : 1).map((c, j) => '<div class="reg-contact" data-k="c-' + j + '">' + (c2 ? '<p class="rf-q">Contact ' + (j + 1) + (j ? ' <span class="reg-opt">(optional)</span>' : '') + '</p>' : '') + '<div class="reg-grid reg-grid--3">' +
        field('Name', 'contacts.' + j + '.name', c.name, { attrs: ' maxlength="80"' }) + field('Phone', 'contacts.' + j + '.phone', c.phone, { type: 'tel', attrs: ' maxlength="30"' }) + field('Relationship', 'contacts.' + j + '.rel', c.rel, { optional: true, attrs: ' maxlength="40"', ph: 'Aunt, neighbor…' }) + '</div></div>').join('') +
      (c2 ? '' : '<p class="rf-quiet rs-note"><button type="button" class="wk-linklike" data-act="contact2">Add a second contact</button></p>'));
  }

  /* ---------------------------------------------------------------- 6 · Review and pay */

  // Each step said once, in a few lines, with Change; then the total (once), how to pay, Keep for next year.
  function reviewStep() {
    const list = steps(), row = (k, lines) => !lines.length ? '' : '<div class="rv-row" data-k="rv-' + k + '"><div class="rv-h"><p class="rs-k">' + esc(stepName(k)) + '</p>' + (locked(k) ? '' : '<button type="button" class="wk-linklike rv-ch" data-act="goto" data-v="' + k + '" aria-label="' + esc('Change, ' + stepName(k)) + '">Change</button>') + '</div>' +
      lines.map((l, i) => '<p class="rv-l' + (i ? ' rv-l--sub' : '') + '">' + escn(l) + '</p>').join('') + '</div>';
    return '<div class="rv">' + row('contact', contactLines()) + row('people', peopleLines()) + row('stay', stayLines()) +
      (list.indexOf('meals') > -1 ? row('meals', [mealsWords(state.d)]) : '') + (list.indexOf('communion') > -1 ? row('communion', communionLines()) : '') + '</div>' + moneyPart();
  }
  function contactLines() {
    const h = state.d.household, x = state.d.helper;
    if (x.on) return [[x.name, x.phone].filter(Boolean).join(' · '), 'For ' + [h.contact, h.phone, h.email].filter(Boolean).join(' · ')];
    return [[h.contact, h.phone].filter(Boolean).join(' · '), h.email].filter(Boolean);
  }
  function peopleLines() {
    const ppl = named(), s = state.d.stay;
    // Each person holds together ("Levi (Young Folk, 17)"): a line wraps only at " · ".
    const who = ppl.map(p => (nameIn(p) + (p.kind === 'yf' ? ' (Young Folk' + (p.age !== '' ? ', ' + p.age : '') + ')' : p.kind === 'child' && p.age !== '' ? ' (' + p.age + ')' : '')).replace(/ /g, '\u00a0')).join(' · ');
    const needs = !s.type || s.type === 'dorm' ? NEED_ALL.map(x => { const n = ppl.filter(p => p[x[0]]).map(nameIn); return n.length ? x[1] + ': ' + andList(n) : ''; }).filter(Boolean).join(' · ') : '';
    // The preteen program's answers, once: "Preteen program: Lydia" (and "· Not Micah" for a No).
    const kids = ppl.filter(ptAge), yes = kids.filter(p => p.preteen).map(nameIn), no = kids.filter(p => !p.preteen).map(nameIn);
    const pt = kids.length ? 'Preteen program: ' + (yes.length ? andList(yes) + (no.length ? ' · Not ' + andList(no) : '') : 'No') : '';
    return [who].concat(needs ? [needs] : [], pt ? [pt] : []).filter(Boolean);
  }
  function stayLines() {
    const d = state.d, s = d.stay, ppl = named(), out = [];
    if (!s.type) return ['Not chosen'];
    out.push(stayWords(d, true));
    if (s.perPerson) ppl.filter(p => hasNights(p)).forEach(p => { const ns = nightsShown(p); if (ns.join('|') !== s.nights.join('|')) out.push(nameIn(p) + ': ' + (ns.length ? spanOf(ns) + ' · ' + plural(ns.length, 'night') : 'No nights')); });
    if (s.type !== 'yf') ppl.filter(p => p.yf && inHall(p)).forEach(p => out.push(nameIn(p) + ' · ' + hallWord(p.yfHall) + (p.rooming ? ' · With ' + p.rooming : '')));
    else ppl.filter(p => p.rooming).forEach(p => out.push(nameIn(p) + ' · With ' + p.rooming));
    if (minorsAlone() && s.parentEmail) out.push('Parent asked · ' + s.parentEmail);
    else if (adults().length && ppl.some(p => p.minor && inHall(p))) out.push(s.ask ? 'Parent asked · ' + s.parentEmail : s.yfOk ? 'Under 18 · I’m the parent' : '');
    if (s.type === 'dorm' && adults().length) out.push('Keys: ' + (s.keys || []).map(first).filter(Boolean).join(', '));
    if (s.type === 'camper' && (s.campers > 1 || s.camperLen)) out.push([s.campers > 1 ? plural(s.campers, 'camper') : '', { short: 'Under 25 ft', mid: '25–35 ft', long: 'Over 35 ft' }[s.camperLen] || ''].filter(Boolean).join(' · '));
    out.push([linenWords(d), s.mattresses ? plural(s.mattresses, 'air mattress', 'air mattresses') : ''].filter(Boolean).join(' · '));
    if (canChoose() && (s.chosen || []).length) out.push(roomsWords(s.chosen));
    out.push([s.near ? 'Near ' + s.near : '', s.arrive ? ARRIVE[s.arrive] : ''].filter(Boolean).join(' · '));
    if (s.needs) out.push('Note: ' + s.needs);
    return out.filter(Boolean);
  }
  function communionLines() {
    const d = state.d, cs = communers(), on = cs.filter(p => p.communing).map(nameIn), pts = named().filter(p => p.preteen), out = [];
    if (cs.length) out.push(on.length ? 'Communing: ' + andList(on) : 'No one communing');
    if (ptAsk() && pts.length) {
      // Who's in is said under Who's coming; here, who picks them up.
      if (adults().length) out.push('Preteens picked up by ' + pickupOf(d));
      const cn = (d.contacts || []).filter(c => String(c.name || '').trim()).map(c => c.name.trim());
      if (cn.length) out.push('Emergency: ' + cn.join(', '));
    }
    return out;
  }
  // The money: the total once (the charges a tap away), a change's balance, a gift, how to pay, Keep for
  // next year. The one action is the card's foot.
  function moneyPart() {
    const d = state.d, M = moneyNow(), t = M.total, ed = state.editing, owe = ed ? M.due > 0 || M.newCheck > M.check : t > 0, open = !!state.ui.charges;
    if (state.waitlist && !ed) return '<div class="rv-pay" data-k="pay"><p class="reg-fine">' + I.info + '<span>' + esc('Waitlist · Nothing is charged · ' + (ownerOr('owner') ? 'The ' + ownerOr('owner') + ' contacts you if a room opens' : 'You’re contacted if a room opens')) + '</span></p>' + keepBox() + '</div>';
    const total = '<div class="rx-total rv-total"><span><b>Total</b>' + ((C('meals_free') || 'yes') !== 'no' && mealsHere().length ? '<small>Meals provided</small>' : '') + '</span><b class="rx-total__n" data-k="rx-total">' + esc($(t)) + '</b></div>';
    const lines = priceLines();
    const charges = lines ? '<p class="rf-quiet rv-chg"><button type="button" class="wk-linklike" data-act="charges" aria-expanded="' + open + '">' + (open ? 'Hide charges' : 'Charges') + '</button></p>' + (open ? lines : '') : '';
    const money = ed ? changeRows(M).filter(Boolean) : [];
    let how = '';
    // A call or a letter (Round 5): a check by mail, or at check-in; never a card taken by a member (H22).
    if (state.desk && state.forHh && state.how !== 'desk') how = t > 0 ? '<div class="rs-q"><p class="rs-sub">How they’ll pay</p>' + radios('How they’ll pay', 'hhpay', d.pay, (state.F.late ? [] : [['check', 'Check by mail']]).concat([['checkin', 'At check-in']])) + '</div>' : '';
    else if (state.desk) how = t > 0 ? '<div class="rs-q"><p class="rs-sub">Paid at the desk</p>' + radios('Paid at the desk', 'deskpaid', d.deskPaid || '', [['cash', 'Cash'], ['check', 'Check'], ['card', 'Card'], ['', 'Not yet']]) + '</div>' : '';
    else {
      const check = owe && d.pay === 'check' ? checkBox(ed ? M.newCheck : t, false) : '';
      const atDesk = owe && d.pay === 'checkin' ? '<p class="reg-fine">' + I.key + '<span>' + esc('Pay at check-in' + (C('checkin_place') ? ' · ' + C('checkin_place') : '')) + '</span></p>' : '';
      const card_ = owe && d.pay === 'card' ? '<p class="reg-fine">' + I.lock + '<span>Card details go to the payment provider, never this site</span></p>' : '';
      const refund = !ed && C('refunds_by') && d.stay.nights.length && owe ? help('Refund requests until ' + O.fmtDate(C('refunds_by'), 'md')) : '';
      how = payBy(owe) + '<div class="rv-fine">' + card_ + check + atDesk + parentWords() + refund + (!owe && !ed ? '<p class="reg-fine">' + I.check + '<span>Nothing to pay</span></p>' : '') + '</div>';
    }
    return '<div class="rv-pay" data-k="pay">' + total + charges + (money.length ? ledger(money, 'Payment') : '') + giftPart() + how + keepBox() + '</div>';
  }

  /* ---------------------------------------------------------------- the week, drawn (Registered, Your sign-ups) */

  // The Conference's services over the days (only once the schedule is posted: never a placeholder): the
  // worship services, Communion and the council, as the Conference page counts them (settings
  // services_kinds, else those three; Caleb and Michael, Oct 24: "match it to the worship services", not the
  // singings or the teaching). In rows by time across the days (Michael: "It's not in a clear sequence"):
  // a row holds the services starting within an hour of its first, one a day, so Sunday's 10 AM worship
  // sits beside Saturday's.
  function serviceRows() {
    const s = (state.model && state.model.settings) || {}, v = String(s.services_kinds || '').split(/[,|;]+/).map(O.slug).filter(Boolean), kinds = v.length ? v : ['worship', 'communion', 'council'];
    const all = [], rows = [];
    ((state.model && state.model.days) || []).forEach(x => (x.items || []).forEach(it => {
      if (kinds.indexOf(it.kind) < 0 || (it.audience !== 'all' && it.audience !== 'conference') || it.start == null) return;
      all.push({ date: x.date, start: +it.start, title: it.title, time: O.formatRange(it.start, it.end, { compact: true }) });
    }));
    all.sort((a, b) => a.start - b.start || (a.date < b.date ? -1 : a.date > b.date ? 1 : 0)).forEach(x => {
      const r = rows[rows.length - 1];
      if (r && x.start - r.at <= 60 && !r.days[x.date]) r.days[x.date] = x;
      else rows.push({ at: x.start, days: { [x.date]: x } });
    });
    return rows;
  }
  // The household's week, read only: people down the side, the days across, each cell the night and that
  // day's meals; on Your week, the services over each day and the household's shifts.
  function weekHTML(d, o) {
    o = o || {};
    if (narrow()) return miniWeek(d, o);
    const ppl = (d.people || []).filter(p => String(p.name || '').trim()), cols = gridCols(d);
    const shifts = o.week ? myShifts() : [];
    // A shift goes on the row of the person it's for (by name); anyone else's on a row of its own.
    const rowOf = u => { const n = String(u.name || '').trim().toLowerCase(); const p = ppl.find(x => x.name.trim().toLowerCase() === n) || ppl.find(x => first(x.name).toLowerCase() === n.split(/\s+/)[0]); return p ? p.pid : 'n:' + u.name; };
    const extra = Array.from(new Set(shifts.map(x => rowOf(x.u)).filter(k => /^n:/.test(k))));
    const svc = o.week ? serviceRows() : [];
    let h = '<div class="gx gx--view' + (o.week ? ' gx--week' : '') + '" style="--n:' + cols.length + '">';
    h += '<div class="gx-row gx-head"><div class="gx-name"></div>' + cols.map((c, i) => {
      const out = !c.night && !c.meals.length && i > 0;
      const inner = '<span class="gx-dw">' + esc(c.early ? 'Early' : c.name.slice(0, 3)) + '</span><span class="gx-dd">' + esc(c.early ? c.name.slice(0, 3) + ' ' + O.fmtDate(c.date, 'day') : O.fmtDate(c.date, 'mdShort')) + '</span>' + (out ? '<span class="gx-dx">Check-out</span>' : '');
      return '<div class="gx-c gx-h' + (i % 2 ? ' is-alt' : '') + (c.early ? ' is-early' : '') + '"><div class="gx-dh">' + inner + '</div></div>';
    }).join('') + '</div>';
    // A service is its name, then its time on a line of its own that never breaks (Caleb: "spillovers annoy me").
    svc.forEach((r, k) => { h += '<div class="gx-row gx-svc' + (k ? ' gx-svc--more' : '') + (k === svc.length - 1 ? ' gx-svc--last' : '') + '"><div class="gx-name">' + (k ? '' : '<span class="gx-k">Services</span>') + '</div>' + cols.map((c, i) => { const x = r.days[c.date]; return '<div class="gx-c' + (i % 2 ? ' is-alt' : '') + '">' + (x ? '<span class="gx-sv"><i>' + esc(x.title) + '</i><small>' + esc(x.time) + '</small></span>' : '') + '</div>'; }).join('') + '</div>'; });
    ppl.forEach(p => { h += gridRow(p, d, cols, shifts.filter(x => rowOf(x.u) === p.pid)); });
    extra.forEach(k => { h += gridRow({ pid: k, name: k.slice(2), kind: 'shifts', nights: [] }, d, cols, shifts.filter(x => rowOf(x.u) === k)); });
    // The letters said once, for a tablet and for paper (no hover there).
    return h + '</div>' + (cols.some(c => c.meals.length) && ppl.length ? '<p class="rf-help gx-key">B breakfast · L lunch · S supper</p>' : '');
  }
  // A day's meals in their places: breakfast 1, lunch 2, supper 3 (a day with other meals, in order), and
  // how many places are empty before the first (room for the line's name).
  const mealSlots = ms => { const k = ms.map(m => MEALCOL[mealWord(m.title).toLowerCase()] || 0), col = k.every(Boolean) && new Set(k).size === k.length ? k : ms.map((m, j) => j + 1); return { col, lead: Math.min.apply(null, col) - 1 }; };
  function gridRow(p, d, cols, shifts) {
    const firstM = cols.findIndex(c => c.meals.length);
    const s = d.stay, other = p.kind === 'shifts', ns = other ? [] : nightsShown(p, d), here = other ? [] : personDays(p, d);
    const label = !hasNights(p, d) ? '' : inHall(p, d) ? hallWord(p.yfHall) : s.type === 'camper' ? 'Camper' : s.type === 'yf' ? 'Hall' : p.band === 'baby' ? (s.rooms > 1 ? 'In our rooms' : 'Room') : s.rooms > 1 && p.room != null ? 'Room ' + (p.room + 1) : 'Room';
    let h = '<div class="gx-row gx-person" data-k="gx-' + esc(p.pid) + '">';
    h += '<div class="gx-name"><div class="gx-id"><b class="gx-nm">' + esc(p.name) + '</b>' + (other ? '' : '<small>' + escn(kindLine(p).replace(/ · Communing$/, '')) + '</small>') + '</div></div>';
    cols.forEach((c, i) => {
      h += '<div class="gx-c' + (i % 2 ? ' is-alt' : '') + (c.early ? ' is-early' : '') + '">';
      if (c.night && hasNights(p, d) && !other) {
        const on = ns.indexOf(c.night) > -1, prev = i > 0 && cols[i - 1].night && ns.indexOf(cols[i - 1].night) > -1, nx = i < cols.length - 1 && ((cols[i + 1].night && ns.indexOf(cols[i + 1].night) > -1) || !cols[i + 1].night);
        const start = on && !prev;
        const cls = 'gx-n' + (on ? ' is-on' : '') + (on && prev ? ' jl' : '') + (on && nx ? ' jr' : '') + (c.early ? ' is-early' : '');
        // The label once, at a run's start, when the run has room for it.
        let run = 0; for (let k = i; k < cols.length && cols[k].night && ns.indexOf(cols[k].night) > -1; k++) run++;
        const lab = start && label && (run > 1 || label.length < 8) ? '<span class="gx-nl">' + esc(label) + '</span>' : '';
        h += '<span class="' + cls + '">' + (start ? (inHall(p, d) ? I.hall : I.bed) : '') + lab + '</span>';
      } else if (!other && hasNights(p, d) && i > 0 && cols[i - 1].night && ns.indexOf(cols[i - 1].night) > -1) h += '<span class="gx-n gx-cap" title="Check-out" aria-hidden="true">' + I.out + '</span>';
      else if (!other && !hasNights(p, d) && here.indexOf(c.date) > -1) h += '<span class="gx-n gx-here is-on' + (i > 0 && here.indexOf(cols[i - 1].date) > -1 ? ' jl' : '') + (i < cols.length - 1 && here.indexOf(cols[i + 1].date) > -1 ? ' jr' : '') + '" aria-hidden="true">' + (i === 0 || here.indexOf(cols[i - 1].date) < 0 ? '<span class="gx-nl">Here</span>' : '') + '</span>';
      else if (!other) h += '<span class="gx-n gx-none" aria-hidden="true"></span>';
      if (c.meals.length && !other) {
        // Breakfast, lunch and supper each in their own place, so a first day's lone supper sits under the
        // other days' suppers (Michael, Oct 24); the line named "Meals" where its first day leaves room, as
        // the bar above names its room (Caleb: "nothing to say that the second line below it is meals"); a
        // mark's word shows at once over the whole mark ("make it the whole button").
        const in_ = here.indexOf(c.date) > -1, at = mealSlots(c.meals);
        const lab = i === firstM && at.lead > 0 ? '<span class="gx-ml" style="grid-column:1/' + (at.lead + 2) + '">' + I.meal + '<span>Meals</span></span>' : '';
        h += '<span class="gx-ms">' + lab + c.meals.map((m, j) => { const on = in_ && eats(p, m, d), w = mealWord(m.title); return '<span class="gx-m' + (on ? ' is-on' : '') + '" style="grid-column:' + (at.col[j] + 1) + '" data-tip="' + esc(w) + '"><span aria-hidden="true">' + esc(mealLetter(m.title)) + '</span><span class="ogc-sr">' + esc(on ? w : 'No ' + w.toLowerCase()) + '</span></span>'; }).join('') + '</span>';
      }
      shifts.filter(x => x.sh.day.date === c.date).forEach(x => { h += '<span class="gx-shift"><b>' + esc(x.sh.role) + '</b>' + escn(shiftTime(x.sh)) + '</span>'; });
      h += '</div>';
    });
    return h + '</div>';
  }
  // The week in miniature (a phone): each person's nights as bars and their meals as a count.
  function miniWeek(d, o) {
    o = o || {};
    const cols = gridCols(d).filter(c => c.night || d.stay.type === 'elsewhere'), ppl = (d.people || []).filter(p => String(p.name || '').trim());
    let h = '<div class="gm" style="--n:' + cols.length + '"><div class="gm-h" aria-hidden="true"><span></span>' + cols.map(c => '<span>' + esc(c.early ? 'E' + c.name.slice(0, 1) : c.name.slice(0, 2)) + '</span>').join('') + '<span>Meals</span></div>';
    ppl.forEach(p => {
      const ns = nightsShown(p, d), here = personDays(p, d), on = c => c.night && hasNights(p, d) ? ns.indexOf(c.night) > -1 : here.indexOf(c.date) > -1;
      h += '<div class="gm-r"><span class="gm-n"><b>' + esc(first(p.name)) + '</b><small>' + escn(kindLine(p).replace(/ · Communing$/, '')) + '</small></span>' + cols.map(c => '<i class="' + (on(c) ? 'is-on' : '') + '"></i>').join('') + '<em>' + mealsOn(p, d).length + '</em></div>';
    });
    h += '</div>';
    // Under it, the shifts: one line a shift, its people from this email.
    if (o.week) { const gs = shiftGroups(); if (gs.length) h += '<ul class="rf-items gm-shifts">' + gs.map(({ us, sh: x }) => '<li><span><b>' + esc(x.role) + '</b><small>' + escn([namesOn(us), shDay(x), shiftTime(x)].join(' · ')) + '</small></span></li>').join('') + '</ul>'; }
    return h;
  }

  /* ---------------------------------------------------------------- the money */

  // The money after a change, as the server will work it out (ogc_reg_rebalance).
  function moneyNow() {
    const ed = state.editing, p = state.override || priceOf(state.d, ed && ed.data.price && ed.data.price.prices), t = p.total_cents;
    if (!ed) return { price: p, total: t, paid: 0, check: 0, newCheck: 0, refund: 0, refundWas: 0, due: t, over: 0 };
    const m = ed.data.money || {}, paid = m.paid || 0, check = m.check || 0, pending = m.pending || 0;
    let newCheck = check, committed = paid + check + pending;
    if (t < committed && check) { newCheck = check - Math.min(committed - t, check); committed = paid + newCheck + pending; }
    const over = Math.max(0, committed - t), refund = ed.can.refund ? over : (m.refund || 0), owed = Math.max(0, t - committed);
    if (owed && state.d.pay === 'check') newCheck += owed;
    return { price: p, total: t, paid, check, newCheck, refund, refundWas: m.refund || 0, due: state.d.pay === 'check' ? 0 : owed, over, wasTotal: ed.data.price.total_cents };
  }
  function changeRows(M) {
    const ed = state.editing;
    return [M.paid > 0 ? ['Paid', M.paid] : null,
      M.check || M.newCheck ? ['Check to come', M.check !== M.newCheck ? (M.check ? $(M.check) + ' → ' : '') + (M.newCheck ? $(M.newCheck) : 'Not needed') : $(M.newCheck)] : null,
      M.refund > 0 ? [M.refund !== M.refundWas ? 'Refund' : 'Refund requested', M.refund, { sum: true }] : null,
      M.over > 0 && !ed.can.refund ? ['No refund after ' + O.fmtDate(C('refunds_by'), 'md'), M.over] : null,
      M.due > 0 ? [state.d.pay === 'checkin' ? 'Due at check-in' : 'Balance', M.due, { sum: true }] : null];
  }
  // "Keep for next year": opt-in, unticked by default (Michael, Oct 13), and what it keeps said plainly.
  const keepBox = () => '<div class="rv-keep"><label class="rf-check"><input type="checkbox" name="keep_next_year"' + (state.d.keep_next_year ? ' checked' : '') + ' aria-describedby="help-keep"><span class="rf-check__b" aria-hidden="true">' + I.check + '</span><span>Keep for next year</span></label>' +
    '<p class="rf-help" id="help-keep">Who’s coming and the stay, for next year’s form · Cleared when next year’s form closes</p></div>';
  // How to pay: Card, Check by mail, At check-in (as the COA's dates allow).
  function payBy(owe) {
    const d = state.d, ed = state.editing;
    const choices = payChoices().concat(ed && !payOk(d.pay) && d.pay ? [[d.pay, d.pay === 'checkin' ? 'At check-in' : d.pay === 'check' ? 'Check' : 'Card']] : []).map(o => [o[0], { card: 'Card', check: 'Check by mail', checkin: 'At check-in' }[o[0]] || o[1]]);
    if (!owe || state.waitlist || choices.length < 2) return '';
    return '<div class="rs-q"><p class="rs-sub">Pay by</p>' + radios('Pay by', 'payby', d.pay, choices, '', 'pay') + err('pay') + '</div>';
  }
  // The gift, a quiet "Add a gift" that opens its box.
  function giftPart() {
    const d = state.d, ed = state.editing, giftOn = C('gift_for') !== 'none' && !state.waitlist, open = giftOn && (state.ui.gift || (ed && ed.data.gift) || +d.gift > 0);
    if (!giftOn) return '';
    return open ? '<div class="reg-field reg-money" data-k="gift"><label class="reg-label" for="f-gift">Gift <span class="reg-opt">(optional)</span></label><span class="reg-money__in"><span aria-hidden="true">$</span><input id="f-gift" name="gift" type="text" inputmode="numeric" pattern="[0-9]*" maxlength="5" value="' + esc(d.gift ? String(d.gift) : '') + '" aria-describedby="help-gift"></span><span class="rf-help" id="help-gift">' + esc('For ' + (C('gift_for') || 'the Conference fund') + (ed && ed.data.gift ? ' · Can be raised, not lowered' : '')) + '</span></div>'
      : '<p class="rf-quiet rx-gift" data-k="gift"><button type="button" class="wk-linklike" data-act="gift" aria-expanded="false">Add a gift</button></p>';
  }
  // A parent asked to approve: who approves, and what a decline means for the money.
  function parentWords() {
    const d = state.d;
    if (state.editing || state.desk || !emailOk(d.stay.parentEmail)) return '';
    const to = d.stay.parentEmail.trim();
    let t = '';
    if (minorsAlone()) t = to + ' approves · Cancelled if declined';
    else if (adults().length && d.stay.ask) {
      const who = named().filter(p => p.minor && inHall(p)), share = who.reduce((k, p) => k + nightsFor(p, d).length * yfPer() + (p.linens ? cents('linen_price') : 0), 0);
      const pron = who.length > 1 ? 'Their' : who[0] && who[0].yfHall === 'women' ? 'Her' : 'His';
      if (who.length) t = to + ' approves ' + who.map(p => first(p.name)).join(' and ') + ' · ' + pron + ' ' + $(share) + ' comes off if declined';
    }
    return t ? '<p class="reg-fine">' + I.mail + '<span>' + escn(t) + '</span></p>' : '';
  }
  // The charges, a line each, and the meals.
  function priceLines() {
    const d = state.d, s = d.stay, M = moneyNow(), ppl = named(), lines = [];
    M.price.lines.forEach(l => { const i = l.label.lastIndexOf(' · '); lines.push([i > 0 ? '<b>' + escn(l.label.slice(0, i)) + '</b><small>' + escn(l.label.slice(i + 3)) + '</small>' : '<b>' + escn(l.label) + '</b>', '<span class="rx-amt">' + esc($(l.cents)) + '</span>']); });
    if (s.type === 'elsewhere' && !lines.length) return '';
    return lines.length ? '<ul class="rx-lines">' + lines.map(l => '<li><span class="rx-l">' + l[0] + '</span>' + l[1] + '</li>').join('') + '</ul>' : '';
  }
  // Check instructions: the amount, payee and address (its first line left out when it only repeats the
  // payee), the date it must arrive by, and the registration number.
  const checkAddress = () => { const a = C('check_address').split('|').map(x => x.trim()).filter(Boolean); if (a.length && a[0].toLowerCase() === C('check_payee').trim().toLowerCase()) a.shift(); return a; };
  // amt === false: the amount is said just above it (the status's Check to come, the receipt's Total),
  // so the box says only "Mail a check".
  function checkBox(cents_, rid, amt) {
    return '<div class="reg-check">' + I.mail + '<div><p><b>' + esc(rid ? (amt === false ? 'Mail a check' : 'Mail a check for ' + $(cents_)) : 'Check by mail · ' + $(cents_)) + '</b></p>' + (C('check_payee') ? '<p>Payable to ' + esc(C('check_payee')) + '</p>' : '') + (checkAddress().length ? '<p>' + checkAddress().map(esc).join('<br>') + '</p>' : '') +
      (C('check_by') ? '<p>Arrives by ' + esc(O.fmtDate(C('check_by'), 'md')) + '</p>' : '') + (rid ? '<p>Write <b>' + esc(rid) + '</b> on it</p>' : '<p class="rf-help">Write your registration number on it</p>') + '</div></div>';
  }

  /* ---------------------------------------------------------------- the one action */

  // Is the email this registration goes to the one signed in on this device? (the desk needs none)
  const wantEmail = () => (state.d.helper.on ? state.d.helper.email : state.d.household.email).trim().toLowerCase();
  const verified = () => { const me = SU.me(); return state.desk || !!(me && !me.pending && me.email.toLowerCase() === wantEmail()); };
  // The one filled button: Continue on a step (Review when come from Review); on Review, Register, Pay,
  // Join waitlist, or a change's Save.
  function primaryBtn(preview) {
    const ed = state.editing, M = moneyNow();
    const b = (act, label, o) => '<button type="button" class="wk-btn rs-go' + (o && o.cls ? ' ' + o.cls : '') + '" data-act="' + act + '"' + (state.busy || (o && o.dis) ? ' disabled' : '') + (state.busy ? ' aria-busy="true"' : '') + '>' + (o && o.icon && !state.busy ? o.icon : '') + esc(state.busy ? 'Processing…' : label) + '</button>';
    if (state.step !== 'review') return b('next', state.fromReview ? 'Review' : 'Continue');
    if (preview) return b('noop', 'Preview', { dis: true });
    if (ed) return !editChanged() ? b('noop', 'No changes', { dis: true }) : M.due > 0 && state.d.pay === 'card' ? b('save', 'Pay ' + $(M.due), { icon: I.lock }) : b('save', 'Save');
    if (state.desk) return b('register', 'Register');
    if (state.waitlist) return b('register', 'Join waitlist');
    // The Total is said right above it, so the button says only "Pay".
    return M.total > 0 && state.d.pay === 'card' ? b('register', 'Pay', { icon: I.lock }) : b('register', 'Register');
  }
  // The answers that matter when comparing a change with what's saved.
  function cleanForCompare(d) {
    const x = settle(JSON.parse(JSON.stringify(d)));
    return { h: x.household, x: x.helper, p: x.people.filter(p => p.name.trim()).map(p => [p.name, p.kind, p.age, p.yfHall, p.nights, p.rooming, p.sleeps, p.linens, p.communing, p.ptOff, p.room, !!p.ground, !!p.walker, !!p.restroom, !!p.crib]), s: x.stay, m: x.people.filter(p => p.name.trim()).map(p => mealsOn(p, x).map(m => m.id)), pt: x.preteens, c: x.contacts, pw: x.pickupWho, po: x.pickupOther, g: +x.gift || 0, k: !!x.keep_next_year };
  }

  /* ================================================================ the map picker (when households choose rooms) */

  // Only when the COA lets households choose (room_choice = households) and Lodging has marked the year's
  // floor plans confirmed (plans_confirmed = yes): the sample floors must never look real.
  const famFloors = () => state.floors.filter(f => f.for === 'families');
  const roomBy = id => state.rooms.find(r => r.id === id);
  // A household's own posted room: its facts from the halls list, which a visitor's page isn't sent
  // (where people sleep stays with Lodging), so else from its id, "Reed Hall|301" (integration).
  const roomOf = id => roomBy(id) || (/^[^|]+\|[^|]+$/.test(String(id)) ? { id, hall: String(id).split('|')[0], num: String(id).split('|')[1], floor: null, beds: 2 } : null);
  const planHalls = () => Array.from(new Set(famFloors().map(f => f.hall))).filter(h => state.plans[h] && state.plans[h].list.length);
  const canChoose = () => C('room_choice') === 'households' && C('plans_confirmed') === 'yes' && planHalls().length > 0 && !!O.map;
  const floorWord = n => n === 1 ? 'ground floor' : ['', '', 'second', 'third', 'fourth', 'fifth'][n] ? ['', '', 'second', 'third', 'fourth', 'fifth'][n] + ' floor' : 'floor ' + n;
  function roomsWords(ids) {
    const by = [];
    ids.map(roomOf).filter(Boolean).forEach(r => { let g = by.find(x => x.hall === r.hall); if (!g) by.push(g = { hall: r.hall, nums: [], floors: new Set() }); g.nums.push(r.num); g.floors.add(r.floor); });
    return by.map(g => g.hall + ' ' + g.nums.join(', ') + (g.floors.size === 1 && Array.from(g.floors)[0] ? ', ' + floorWord(Array.from(g.floors)[0]) : '')).join(' · ');
  }
  const takenSet = () => { const t = {}; (state.F.taken || []).forEach(id => { t[id] = 1; }); ((state.editing && state.editing.data.stay.chosen) || []).forEach(id => { delete t[id]; }); return t; };
  function pickRow() {
    if (!canChoose()) return '';
    const c = (state.d.stay.chosen || []).filter(roomBy);
    return '<div class="reg-row reg-row--pick"><span><b>Your rooms</b><small>' + (c.length ? esc(roomsWords(c)) : esc(ownerOr('owner') ? 'Not chosen · The ' + ownerOr('owner') + ' assigns them' : 'Not chosen · Assigned for you')) + '</small></span><button type="button" class="wk-btn wk-btn--line wk-btn--small" data-act="pickrooms">' + I.pin + (c.length ? 'Change' : 'Choose rooms') + '</button></div>';
  }
  const mapDlg = document.createElement('dialog');
  mapDlg.className = 'ogc reg-mapdlg';
  mapDlg.setAttribute('aria-labelledby', 'reg-map-t');
  document.body.appendChild(mapDlg);
  function openPicker() {
    const s = state.d.stay, sel = (s.chosen || []).filter(roomBy), f0 = roomBy(sel[0]), halls = planHalls();
    state.mp = { sel: sel.slice(), hall: f0 ? f0.hall : halls[0], floor: f0 ? f0.floor : 0, focus: sel[0] || '', full: '' };
    drawPicker(); mapDlg.showModal();
    const g = mapDlg.querySelector('.pl-room.is-sel, .pl-room[role="button"]'); if (g) g.focus();
  }
  function drawPicker() {
    const s = state.d.stay, m = state.mp, t = takenSet(), halls = planHalls(), narrow = matchMedia('(max-width: 759px)').matches;
    const P = state.plans[m.hall], fl = P.list.find(f => f.floor === m.floor) || P.list[0];
    m.floor = fl.floor;
    const held = r => r.floor === 1 && !s.ground && !s.walker;
    const st = sh => { const r = roomBy(sh.id); return m.sel.indexOf(sh.id) > -1 ? 'sel' : !r ? 'off' : t[sh.id] ? 'taken' : held(r) ? 'held' : 'free'; };
    const free = list => list.filter(sh => st(sh) === 'free').length;
    const words = { sel: 'yours', off: 'unavailable', taken: 'taken', held: 'reserved', free: 'free' };
    const label = (sh, x) => 'Room ' + sh.label + ', ' + words[x] + ', ' + ((roomBy(sh.id) || {}).beds || 2) + ' beds';
    const hallBtns = '<div class="reg-halls" role="group" aria-label="Hall">' + halls.map(h => '<button type="button" data-mphall="' + esc(h) + '" aria-pressed="' + (h === m.hall) + '"><b>' + esc(h) + '</b><small>' + free([].concat.apply([], state.plans[h].list.map(f => f.rooms))) + ' free</small></button>').join('') + '</div>';
    const floorBtns = '<div class="reg-floors" role="group" aria-label="Floor">' + P.list.map(f => '<button type="button" data-mpfloor="' + f.floor + '" aria-pressed="' + (f.floor === fl.floor) + '">' + esc(f.floor === 1 ? 'Ground floor' : 'Floor ' + f.floor) + '<small>' + free(f.rooms) + ' free</small></button>').join('') + '</div>';
    const legend = '<ul class="reg-legend" aria-hidden="true"><li><i class="is-free"></i>Free</li><li><i class="is-sel"></i>Yours</li><li><i class="is-taken"></i>Taken</li>' + (fl.floor === 1 && !s.ground ? '<li><i class="is-held"></i>Reserved</li>' : '') + '</ul>';
    const n = m.sel.length;
    mapDlg.innerHTML = '<div class="reg-mapdlg__in"><header class="reg-mapdlg__bar"><div><p class="wk-kicker">' + esc(state.year + ' · ' + (state.model.settings.venue || '')) + '</p><h2 id="reg-map-t">Choose rooms</h2></div><button type="button" class="wk-sheet__x" data-mapclose aria-label="Close without saving">' + I.x + '</button></header>' +
      '<div class="reg-mapdlg__body"><aside class="reg-mapdlg__side">' + hallBtns + '</aside><section class="reg-mapdlg__main" aria-label="' + esc(m.hall) + '">' + floorBtns + legend +
      '<div class="reg-plan">' + O.map.floorSvg(fl, { state: st, label, pick: true, turn: O.map.turnFor(fl, narrow), px: narrow ? 3 : 0, beds: sh => (roomBy(sh.id) || {}).beds || 2, title: m.hall + ', ' + floorWord(fl.floor) }) + '</div></section></div>' +
      '<footer class="reg-mapdlg__foot"><p class="reg-mapdlg__sum"><b>' + n + ' of ' + plural(s.rooms, 'room') + '</b>' + (n ? ' · ' + esc(roomsWords(m.sel)) : '') + '</p>' + (m.full ? '<p class="reg-mapdlg__full">Limit reached</p>' : '') +
      '<p class="reg-mapdlg__btns">' + (n ? '<button type="button" class="wk-linklike" data-mpclear>Clear</button>' : '') + '<button type="button" class="wk-btn" data-mapdone>' + I.check + 'Done</button></p></footer></div>';
    O.map.reveal(mapDlg.querySelector('.reg-plan'), m.focus || m.sel.find(id => fl.rooms.some(r => r.id === id)));
  }
  function tapRoom(id) {
    const m = state.mp, s = state.d.stay, t = takenSet(), r = roomBy(id), i = m.sel.indexOf(id);
    m.focus = id; m.full = '';
    if (i > -1) m.sel.splice(i, 1);
    else if (r && !t[id] && !(r.floor === 1 && !s.ground && !s.walker)) { if (m.sel.length < s.rooms) m.sel.push(id); else m.full = id; }
    drawPicker();
    const g = mapDlg.querySelector('[data-room="' + CSS.escape(id) + '"]'); if (g) g.focus();
  }
  // Done keeps the choice; × and Escape leave it as it was.
  function closePicker(save) {
    if (save) { state.d.stay.chosen = state.mp.sel.slice(); tell(state.mp.sel.length ? 'Rooms: ' + roomsWords(state.mp.sel) : 'Rooms not chosen'); }
    mapDlg.close(); update();
    const b = root.querySelector('[data-act="pickrooms"]'); if (b) b.focus();
  }
  mapDlg.addEventListener('click', e => {
    const b = e.target.closest('[data-mapclose], [data-mapdone], [data-mphall], [data-mpfloor], [data-mpclear], [data-room]');
    if (!b) return;
    const m = state.mp, ds = b.dataset;
    if (b.hasAttribute('data-mapclose')) closePicker(false);
    else if (b.hasAttribute('data-mapdone')) closePicker(true);
    else if (ds.mphall) { m.hall = ds.mphall; m.floor = 0; m.focus = ''; drawPicker(); }
    else if (ds.mpfloor) { m.floor = +ds.mpfloor; m.focus = ''; drawPicker(); }
    else if (b.hasAttribute('data-mpclear')) { m.sel = []; m.focus = ''; drawPicker(); }
    else if (ds.room) tapRoom(ds.room);
  });
  mapDlg.addEventListener('keydown', e => { const g = e.target.closest && e.target.closest('[data-room][role="button"]'); if (g && (e.key === 'Enter' || e.key === ' ')) { e.preventDefault(); tapRoom(g.dataset.room); } });
  mapDlg.addEventListener('cancel', e => { e.preventDefault(); closePicker(false); });

  /* ================================================================ registered: the receipt */

  // A registration's name: one person alone is named ("Caleb Yoder"); else "Hoover household".
  const regName = d => { const ppl = (d.people || []).filter(p => String(p.name || '').trim()); return ppl.length === 1 ? ppl[0].name.trim() : SU.householdName(d); };
  // From a week before the Conference, a parent's approval still waiting is settled at check-in.
  const nearStart = () => !!(state.row && state.row.start && today() >= O.isoAddDays(state.row.start, -7));
  const STATUS = { registered: 'Registered', payment_due: 'Payment due', balance_due: 'Balance due', check_to_come: 'Check to come', refund_due: 'Refund requested', waitlist: 'Waitlist', cancelled: 'Cancelled' };
  function statusWords(it) {
    const d = it.data, m = d.money || {}, ap = d.approval;
    const a = [STATUS[d.status] || 'Registered'];
    if (d.status === 'registered' && m.paid > 0) a[0] = 'Paid ' + $(m.paid);
    if ((d.status === 'payment_due' || d.status === 'balance_due') && (d.pay === 'checkin' || lateIn(m))) a[0] = 'Due at check-in · ' + $(m.due || 0);
    // Only what's still open: an approval given isn't an exception any more (polish 3), and one held
    // back while a card payment is open hasn't been sent.
    if (ap && ap.state === 'waiting' && !ap.held) a.push(nearStart() ? 'Approval needed at check-in' : 'Waiting for parent');
    // Held while a card payment is open: said, so a Young Folk knows the parent hears once it's paid.
    else if (ap && ap.state === 'waiting' && ap.held && d.status !== 'cancelled') a.push('Parent asked once paid');
    // Nothing about rooms until they're posted (a status about something that hasn't happened is noise).
    if (d.status !== 'cancelled' && it.rooms && it.rooms.length) a.push('Rooms posted');
    return a.join(' · ');
  }
  // The stay in a line. listed: the people are listed just above (each with their hall), so the halls
  // aren't said again; else a family's Young Folks are named with theirs ("Levi in the Young men's hall").
  function stayWords(d, listed) {
    const s = d.stay;
    const halls = listed ? [] : d.people.filter(p => p.yf && inHall(p, d)).map(p => first(p.name) + ' in the ' + hallWord(p.yfHall));
    // Off campus: its days only when there are some (never a dangling "Off campus ·").
    if (s.type === 'elsewhere') return ['Off campus', (s.days || []).map(x => O.fmtDate(x, 'weekdayShort')).join(', ')].filter(Boolean).join(' · ') + (halls.length ? ' · ' + halls.join(', ') : '');
    const ns = s.nights || [], span = spanOf(ns) + '\u00a0·\u00a0' + plural(ns.length, 'night');
    if (s.type === 'yf') return Array.from(new Set(d.people.map(p => hallWord(p.yfHall)))).join(', ') + ' · ' + span;
    return (s.type === 'camper' ? 'Camper lot · ' + span : plural(s.rooms, 'dorm room') + ' · ' + span) + (halls.length ? ' · ' + halls.join(', ') : '');
  }
  function checkCard(it, amt) {
    const m = it.data.money || {};
    if (m.check) return checkBox(m.check, it.rid, amt);
    // Past check_by with no check received: where it's due, with the key (never "Mail a check").
    if (lateIn(m) && m.due > 0) return '<div class="reg-check">' + I.key + '<div>' + (C('checkin_place') ? '<p><b>' + esc(C('checkin_place')) + '</b></p>' : '') + (C('check_by') ? '<p>' + escn('No check received by ' + O.fmtDate(C('check_by'), 'md')) + '</p>' : '') + '</div></div>';
    return '';
  }
  // Paid, declined or cancelled at the provider's checkout: a line at the top (with Try again).
  const payBanner = () => state.payNote ? '<p class="rf-banner' + (state.payNote.bad ? ' is-bad' : '') + '" role="status">' + (state.payNote.bad ? I.info : I.check) + '<span>' + esc(state.payNote.text) + '</span>' + (state.payNote.retry ? ' <button type="button" class="wk-btn wk-btn--small" data-act="paydue" data-id="' + state.payNote.retry + '">Try again</button>' + (state.payNote.check && !state.F.late ? '<button type="button" class="wk-linklike" data-act="paycheck" data-id="' + state.payNote.retry + '">Pay by check</button>' : '') : '') + '</p>' : '';
  const METHOD = { card: 'Card', check: 'Check', cash: 'Cash' };
  // What's been received, from the ledger: date · how · amount (refunds sent as minus).
  function paymentRows(it) {
    return (it.ledger || []).filter(p => p.status === 'paid' || (p.kind === 'refund' && p.status === 'sent')).map(p => [shortDate(p.at) + ' · ' + (p.kind === 'refund' ? 'Refund' : (METHOD[p.method] || 'Paid') + (p.kind === 'desk' ? ' at the desk' : '')), p.kind === 'refund' ? -p.cents : p.cents]);
  }
  // Registered: the household's week (people by days, their nights, meals and shifts, the services over
  // each day) with Add to Calendar and Print; the receipt beside it (the ID, the charges, how to pay); then
  // Helping out. How ever it was paid, the same page.
  function doneView() {
    const it = state.done;
    if (!it) return page(hero('Registration', { facts: false }), SU.me() && !SU.me().pending ? blankCard('Not found', mineLink()) : signinCard());
    const d = it.data, ap = d.approval, signupsOpen = (state.model.settings.signups_posted || '9999') <= today();
    const dorm = signupsOpen && dormAskFor(d);
    const who = state.desk ? d.household.contact : d.helper && d.helper.on ? d.helper.name : d.household.contact;
    // A card cancelled or declined with money still due: the title says what's true, and Try again is
    // the one filled button.
    const unpaid = !!(state.payNote && state.payNote.bad && state.payNote.retry);
    // Registered, settling into place (docs/30 flair 1): a tan check and the one word, with a parent still
    // to answer said beside it. The money is the receipt's to say (its Total, payments and check box).
    // The desk, a payment still due and a waitlist keep their status words.
    const apW = ap && ap.state === 'waiting' && d.status !== 'cancelled' ? (ap.held ? 'Parent asked once paid' : nearStart() ? 'Approval needed at check-in' : 'Waiting for parent') : '';
    const settled = !state.desk && !unpaid && d.status !== 'waitlist' && d.status !== 'cancelled';
    const sub = settled ? '<p class="reg-done__st reg-done__ok"><span class="reg-done__mark" aria-hidden="true">' + I.check + '</span><span>' + escn(['Registered', apW].filter(Boolean).join(' · ')) + '</span></p>'
      : '<p class="reg-done__st">' + escn(statusWords(it)) + '</p>';
    const head = rxHero(state.desk ? 'Registered' : unpaid ? 'Registered · Payment due' : 'Thank you, ' + (first(who) || 'friend'), '', sub);
    // Helping out first, its Find a shift the one filled button (Caleb, Oct 24: "put the volunteering up top…
    // people are going to hit this and they're going to click off of it"); Your week under it, its Add to
    // calendar quiet. A payment still due keeps Try again as the one filled button.
    const help = state.desk || !signupsOpen ? '' : '<section class="rx-card rf-next"><p class="rf-next__k">' + I.hand + 'Helping out</p><p>' + esc(dorm ? C('dorm_ask') : 'Volunteer shifts are open') + '</p><p class="rf-next__btns">' + findShift(dorm, !unpaid) + '</p></section>';
    return '<div class="wk reg rx-page rx-page--done">' + head + '<section class="rx-main"><div class="wk-wrap">' + (state.payNote && state.payNote.bad ? payBanner() : '') +
      '<div class="rx"><div class="rx-work reg-done">' + help + (state.desk ? '' : weekCard(it, !unpaid && !help, true)) + '</div>' +
      '<aside class="rx-side" aria-label="Receipt">' + doneReceipt(it) + approvalLine(it) + (ap && ap.state === 'waiting' && !ap.held ? flashOf(it.id) : '') + '</aside></div></div></section></div>';
  }
  // The receipt beside Your week: the ID (Copy), the charges, what's paid and to come, a check's details.
  function doneReceipt(it) {
    const d = it.data, m = d.money || {}, paidRows = paymentRows(it), set = state.model ? state.model.settings : {};
    const rows = moneyRows(m, d).filter(r => r && !(paidRows.length && r[0] === 'Paid') && !(m.check && r[0] === 'Check to come'));
    const to = d.helper && d.helper.on && d.helper.email ? d.helper.email : d.household.email;
    return '<div class="rx-receipt"><div class="rx-photo"><img src="' + esc(SU.photoOf(set)) + '" alt="" loading="lazy" decoding="async"></div><div class="rx-body">' +
      '<p class="rf-receipt__id"><span>' + esc(it.rid) + '</span><button type="button" class="wk-linklike" data-act="copy" data-v="' + esc(it.rid) + '">' + I.copy + esc(state.ui.copied || 'Copy') + '</button></p>' +
      '<p class="rx-rsub">' + escn(regName(d) + (d.people.length > 1 ? ' · ' + plural(d.people.length, 'person', 'people') : '')) + '</p>' +
      (d.price.lines.length ? '<ul class="rx-lines">' + d.price.lines.map(l => { const i = l.label.lastIndexOf(' · '); return '<li><span class="rx-l">' + (i > 0 ? '<b>' + escn(l.label.slice(0, i)) + '</b><small>' + escn(l.label.slice(i + 3)) + '</small>' : '<b>' + escn(l.label) + '</b>') + '</span><span class="rx-amt">' + esc($(l.cents)) + '</span></li>'; }).join('') + '</ul>' : '') +
      '<div class="rx-total"><span><b>Total</b></span><b class="rx-total__n">' + esc($(d.price.total_cents)) + '</b></div>' +
      (rows.length ? ledger(rows, 'Payment') : '') + (paidRows.length ? '<p class="rf-q">Payments</p>' + ledger(paidRows, 'Payments') : '') + checkCard(it, m.check !== d.price.total_cents) +
      (to ? '<p class="rf-help">Confirmation sent to ' + esc(to) + '</p>' : '') +
      (state.desk ? '' : '<p class="rx-foot"><a class="wk-linklike" href="?year=' + esc(state.year) + '&view=mine">Your sign-ups</a></p>') + '</div></div>';
  }
  // Your week: the household's days, with Add to Calendar (the page's one filled button unless something
  // is owed) and Print.
  // A registration saved before the form's own shape (the samples: "band", no pid or age; meals with no
  // "who") is read the same way, so its week draws every person.
  const asShown = data => {
    const d = JSON.parse(JSON.stringify(data || {}));
    d.meals = { off: mOff(d), who: mWho(d) };
    d.stay = d.stay || {};
    d.people = (d.people || []).map((p, i) => Object.assign(p, { pid: p.pid || 'p' + i, kind: p.kind || (p.yf ? 'yf' : (p.band === 'child' || p.band === 'baby') ? 'child' : 'adult'), age: p.age == null ? '' : p.age }));
    return d;
  };
  // The line under its title says only what the week and the cards around it don't: the dates and nights,
  // the keys (until Lodging's posted rooms say them), and the linens (left to the receipt on the
  // thank-you: lean). The household's name and its rooms are in the status head and the receipt.
  function weekCard(it, primary, lean) {
    const d = asShown(it.data), live = d.status !== 'cancelled';
    // Add to calendar is filled only when nothing else is the page's one action; else a quiet link like Print.
    const btns = live ? '<p class="rx-weekbtns"><a class="' + (primary ? 'wk-btn wk-btn--small' : 'wk-linklike') + '" href="' + esc(icsHref(it.id)) + '" data-icsa>' + I.cal + 'Add to calendar</a><button type="button" class="wk-linklike" data-act="printweek">' + I.print + 'Print</button></p>' : '';
    const s = d.stay;
    const when = s.type === 'elsewhere' ? (s.days || []).map(x => O.fmtDate(x, 'weekdayShort')).join(', ') : (s.nights || []).length ? spanOf(s.nights) + ' · ' + plural(s.nights.length, 'night') : '';
    const bits = [when, s.type === 'dorm' && (s.keys || []).length && !(it.rooms || []).length ? 'Keys: ' + s.keys.map(first).join(', ') : '', lean ? '' : linenWords(d)].filter(Boolean);
    return '<section class="rx-card rx-week" data-k="week-' + it.id + '" aria-labelledby="rx-week-' + it.id + '"><div class="rx-card__head"><div class="rx-card__t"><h2 class="rx-h2" id="rx-week-' + it.id + '">Your week</h2>' + (bits.length ? '<p class="rx-card__sub">' + escn(bits.join(' · ')) + '</p>' : '') + '</div>' + btns + '</div>' +
      weekHTML(d, { week: true }) + '</section>';
  }

  // The COA's own ask of households with Young Folks in the halls (dorm_ask, their words; blank: none),
  // opening the committee they chose (dorm_committee). The site makes up no rule and assumes no owner
  // (polish 3: it matched /young folks/ and /dorm/ in the shifts).
  const dormAskFor = d => !!C('dorm_ask') && d.people.some(p => p.yf && inHall(p, d)) && d.people.some(p => p.kind === 'adult');
  const shiftsHref = ask => '../volunteer/?year=' + encodeURIComponent(state.year) + (ask && C('dorm_committee') ? '&committee=' + encodeURIComponent(C('dorm_committee')) : '');
  // The ask's own link: the committee, its job chosen (the volunteer page's ?job=).
  const dormHref = () => shiftsHref(true) + (C('dorm_job') ? '&job=' + encodeURIComponent(C('dorm_job')) : '');
  // Find a shift always opens the committees (Michael, Oct 24: it "dumps me into Young Folks for dorm
  // chaperone for some random arbitrary reason"). The ask's committee is its own quiet link, named for
  // where it goes ("Dorm chaperone shifts"), beside it; with no committee chosen, there's none.
  // filled: Find a shift is the page's one call to action (Caleb and Michael, Oct 24: "fill in the whole
  // button… that highlights the action"; Add to calendar is quieter than Find a shift).
  const findShift = (ask, filled) => '<a class="wk-btn wk-btn--small' + (filled ? '' : ' wk-btn--line') + '" href="' + esc(shiftsHref(false)) + '">Find a shift</a>' +
    (ask && C('dorm_committee') ? '<span class="rf-card__links"><a class="wk-linklike" href="' + esc(dormHref()) + '">' + esc((C('dorm_job') || C('dorm_committee')) + ' shifts') + '</a></span>' : '');

  /* ================================================================ Your sign-ups */

  // One door (signin area, Oct 10): the server sends anyone not signed in from Your sign-ups to the
  // site's one sign-in page (same words, same limits) before this draws. Should it ever show, it's that
  // page's button.
  function signinCard() {
    return '<section class="rf-signin"><p class="wk-sheet__btns"><a class="wk-btn" href="' + esc(window.OGC_AUTH ? OGC_AUTH.signinUrl() : (W.signin || '../signin/')) + '">Sign in</a></p></section>';
  }

  // A shift's time as the volunteer page writes it ("2–6 PM").
  const shiftTime = sh => O.formatRange ? O.formatRange(sh.start, sh.end, { compact: true }) : SU.span(sh);
  // This email's places on shifts, one a person, by the volunteer page's own rule (ogc_vol_owns): one
  // under this email once it's confirmed (a sign-up someone else typed this address into isn't listed until
  // its emailed Confirm answers it), and anyone this email added under their own (Add someone), confirmed
  // or waiting. The week puts each on its person's row.
  const myShifts = () => {
    const me = SU.me();
    if (!me || me.pending) return [];
    const ours = u => !u._pub && (SU.sameEmail(u.email, me.email) ? !!u.confirmed : !!u.helper_email && SU.sameEmail(u.helper_email, me.email));
    return (SU.load('signups', state.year, []) || []).filter(ours).map(u => ({ u, sh: state.shifts.find(x => x.id === u.id) })).filter(x => x.sh);
  };
  // A shift's day as the volunteer page says it: "Fri night, May 28" for Saturday's 12–3 AM (one rule,
  // SU.dayShort; after the eighth critic, Oct 16).
  const shDay = sh => SU.dayShort(sh, (state.model && state.model.days) || []);
  // "Martha and Henry", "Daniel, Esther and Lydia": the volunteer page's and the emails' words.
  const andList = n => n.length > 1 ? n.slice(0, -1).join(', ') + ' and ' + n[n.length - 1] : n[0] || '';
  const namesOn = us => andList(Array.from(new Set(us.map(u => first(u.name)))));
  // The address's own person on a place: not someone it signed up (Walter on Edna's email) or added under
  // their own email. A shift's people are named unless the only one on it is that person (after the
  // second critic, Oct 15: Edna left, Walter stayed, and the line said no name, as if she were still on).
  const selfU = u => { const me = SU.me(); return !!me && SU.sameEmail(u.email, me.email) && !u.helper_email && !u.for && u.by !== 'helper'; };
  // Named on every line, the signed-in person too (after the seventh critic, Oct 15: Saturday said "Mark
  // and Anna" and Sunday, Mark's alone, said nobody), so a line never reads as if no one were on it.
  const namedOn = us => us.length > 0;
  // A shift once, with everyone of this email's on it (after the critic, Oct 15: a couple's one shift was
  // two lines, two Leaves and two calendar events), in time order.
  const shiftGroups = () => {
    const out = [];
    myShifts().forEach(x => { const g = out.find(o => o.sh === x.sh); if (g) g.us.push(x.u); else out.push({ sh: x.sh, us: [x.u] }); });
    return out.sort((a, b) => a.sh.day.date < b.sh.day.date ? -1 : a.sh.day.date > b.sh.day.date ? 1 : a.sh.start - b.sh.start);
  };
  // What's still open on a line, naming whom when it isn't everyone on it: "Lydia · Waiting to confirm"
  // (someone added under their own email), "Swap open". As the volunteer page says them.
  const shiftTags = us => {
    const me = SU.me(), wait = us.filter(u => !u.confirmed && !SU.sameEmail(u.email, me.email)), swap = us.filter(u => u.swap);
    const who = l => l.length < us.length ? namesOn(l) + ' · ' : '';
    return [wait.length ? who(wait) + 'Waiting to confirm' : '', swap.length ? who(swap) + 'Swap open' : ''].filter(Boolean);
  };
  // This email's waitlists (the volunteer page's own answer, GET vol/{y}), a shift once with its people.
  const myWaits = () => {
    const out = [];
    ((state.vol && state.vol.waits) || []).forEach(w => { const sh = state.shifts.find(x => x.id === w.shift); if (!sh) return; const g = out.find(o => o.sh === sh); if (g) g.ws.push(w); else out.push({ sh, ws: [w] }); });
    return out.sort((a, b) => a.sh.day.date < b.sh.day.date ? -1 : a.sh.day.date > b.sh.day.date ? 1 : a.sh.start - b.sh.start);
  };
  // Would a Leave of these places reach the head now (GET vol/{y}'s mine › tells)? Unknown: yes, as before.
  const tellsHead = us => { const v = state.vol && state.vol.mine; if (!v || !us.length) return true; return us.some(u => { const m = v.find(x => x.rid === u._rid); return !m || m.tells !== false; }); };
  // This email's places another device made, still to confirm (GET vol/{y}'s pending), a shift once.
  const myPending = () => {
    const out = [];
    ((state.vol && state.vol.pending) || []).forEach(x => { const sh = state.shifts.find(y => y.id === x.shift); if (!sh) return; const g = out.find(o => o.sh === sh); if (g) g.ps.push(x); else out.push({ sh, ps: [x] }); });
    return out.sort((a, b) => a.sh.day.date < b.sh.day.date ? -1 : a.sh.day.date > b.sh.day.date ? 1 : a.sh.start - b.sh.start);
  };
  const myTeams = () => { const me = SU.me(); return me && !me.pending ? (SU.load('teams', state.year, []) || []).filter(t => SU.sameEmail(t.email, me.email)) : []; };

  // lean: under Your week, whose rows already say the age, the hall, Preteen and the nights; only what
  // the week doesn't show is said, and a person with nothing more isn't listed ('').
  function personLine(p, d, it, lean) {
    const bits = [];
    // Sentence case, as every line around it (polish 3).
    if (p.kind === 'child' && !lean) bits.push(p.age !== '' ? 'Age ' + p.age : 'Child');
    if (p.yf && !lean) bits.push(inHall(p, d) ? hallWord(p.yfHall) : 'With family');
    if (p.rooming) bits.push('With ' + p.rooming);
    if (p.minor && inHall(p, d)) bits.push('Under 18');
    if (p.preteen && !lean) bits.push('Preteen');
    if (p.communing) bits.push('Communing');
    // Their own needs (Oct 23), for a dorm room.
    if ((d.stay || {}).type === 'dorm') NEED_ALL.forEach(x => { if (p[x[0]]) bits.push(x[1]); });
    // Someone not here every night: how many, and which they're not (the nights are the days' names).
    if (!lean && d.stay.perPerson && (p.nights || []).length && (p.nights || []).length !== (d.stay.nights || []).length) { const miss = (d.stay.nights || []).filter(n => p.nights.indexOf(n) < 0); bits.push(plural(p.nights.length, 'night') + (miss.length ? ' · Not ' + miss.map(SU.nightShort).join(', ') : '')); }
    if (lean && !bits.length) return '';
    return '<li><b>' + esc(p.name) + '</b>' + (bits.length ? '<small>' + escn(bits.join(' · ')) + '</small>' : '') + '</li>';
  }
  /* ---------------------------------------------------------------- the status line (canonical, Oct 14) */

  // Each registration headed by its number, then where it stands in the record's fixed order:
  // Registered · Paid (or the true Money word) · Rooms · Checked in. Every word is the server's own
  // (it.standing: the records module's status and Money, the same the COA's Households shows; it.rooms:
  // the rooms Lodging published); a step that isn't true of this record isn't drawn: Rooms and Checked in
  // only for dorm rooms (the desk keeps check-in for them; the camper lot and off campus keep none).
  const stayKind = d => {
    const s = d.stay || {};
    if (s.type === 'yf') return Array.from(new Set(d.people.filter(p => p.yf).map(p => hallWord(p.yfHall)))).join(', ');
    return s.type === 'dorm' ? plural(s.rooms || 1, 'dorm room') : s.type === 'camper' ? 'Camper lot' : s.type === 'elsewhere' ? 'Off campus' : '';
  };
  // How it was paid, from the ledger ("Card", "Check"), only when it was one way.
  const paidHow = it => { const ms = Array.from(new Set((it.ledger || []).filter(p => p.status === 'paid' && p.kind !== 'refund').map(p => METHOD[p.method] || ''))).filter(Boolean); return ms.length === 1 ? ms[0] : ''; };
  function statusSteps(it) {
    const d = it.data, s = d.stay || {}, ap = d.approval, g = it.standing;
    const n = d.people.filter(p => String(p.name || '').trim()).length;
    const who = [plural(n, 'person', 'people'), stayKind(d)].filter(Boolean).join(' · ');
    if (g.status === 'cancelled') return [{ k: 'Cancelled', st: 'off', v: who, s: g.refund > 0 ? 'Refund due · ' + $(g.refund) : g.refunded > 0 ? 'Refunded · ' + $(g.refunded) : '' }];
    if (g.status === 'waitlist') return [{ k: 'Waitlist', st: 'wait', v: who, s: 'Nothing charged' }];
    const apS = ap && ap.state === 'waiting' ? (ap.held ? 'Parent asked once paid' : nearStart() ? 'Approval needed at check-in' : 'Waiting for parent') : '';
    const steps = [{ k: 'Registered', st: 'done', v: who, s: apS }];
    const paidS = g.paid > 0 ? 'Paid ' + $(g.paid) : '';
    // The Money word, as the server says it. A check's arrive-by date and address are in its box under
    // the line (checkCard), said once.
    const money = {
      none: { st: 'done' },
      paid: { st: 'done', v: [$(g.paid), paidHow(it)].filter(Boolean).join(' · ') },
      refunded: { st: 'done', v: $(g.refunded) },
      check: { st: 'wait', v: $(g.check), s: paidS },
      checkin: { st: 'wait', v: $(g.balance), s: g.late > 0 && C('check_by') ? 'No check received by ' + O.fmtDate(C('check_by'), 'md') : C('checkin_place') },
      due: { st: 'todo', v: $(Math.max(0, g.balance - g.check)) },
      balance: { st: 'todo', v: $(Math.max(0, g.balance - g.check)), s: paidS },
      refund: { st: 'wait', v: $(g.refund) },
      form_paid: { st: 'done' }
    }[g.money] || { st: 'wait' };
    steps.push(Object.assign({ k: g.money_words, v: '', s: '' }, money));
    if (s.type === 'dorm') {
      const rs = it.rooms || [], keys = (s.keys || []).map(first).filter(Boolean);
      steps.push(rs.length ? { k: 'Rooms', st: 'done', v: roomsWords(rs), s: keys.length ? 'Keys: ' + keys.join(', ') : '', plan: !!planOf(rs) } : { k: 'Rooms', st: 'todo', v: 'Not posted yet' });
      const ns = s.nights || [];
      steps.push(g.status === 'noshow' ? { k: 'Checked in', st: 'off', v: 'Didn’t come' }
        : g.status === 'checked_in' || g.status === 'checked_out' ? { k: 'Checked in', st: 'done', v: g.checked_in ? shortDate(g.checked_in) : 'Yes', s: g.status === 'checked_out' ? 'Checked out' : '' }
        : { k: 'Checked in', st: 'todo', v: 'Not yet', s: ns.length && nightDate(ns[0]) ? 'Check-in ' + shortDate(nightDate(ns[0])) : '' });
    }
    return steps;
  }
  // calQuiet: Find a shift is the page's one filled button, so Add to calendar is a quiet link here.
  function statusCard(it, week, calQuiet) {
    const d = it.data, m = d.money || {}, y = esc(state.year), live = d.status !== 'cancelled';
    const steps = it.standing ? statusSteps(it) : [], open = !!state.ui['plan-' + it.id];
    const dot = x => '<span class="rs-dot" aria-hidden="true">' + (x.st === 'done' ? I.check : '') + '</span>';
    const line = !steps.length ? '<p class="rf-card__st">' + escn(statusWords(it)) + '</p>' : '<ol class="rs-steps" style="--rs-n:' + steps.length + '">' + steps.map(x => '<li class="rs-step is-' + x.st + '">' + dot(x) + '<span class="rs-tx"><span class="rs-k">' + esc(x.k) + '</span>' +
      (x.v ? '<span class="rs-v">' + escn(x.v) + '</span>' : '') + (x.s ? '<span class="rs-s">' + escn(x.s) + '</span>' : '') +
      (x.plan ? '<button type="button" class="wk-linklike rs-plan" data-act="plan" data-id="' + it.id + '" aria-expanded="' + open + '" aria-controls="rs-plan-' + it.id + '">Floor plan</button>' : '') + '</span></li>').join('') + '</ol>';
    const plan = open && steps.some(x => x.plan) ? '<div class="rs-planbox" id="rs-plan-' + it.id + '">' + planOf(it.rooms) + '</div>' : '';
    // The one filled action is Pay what's due; during the week, the guide; else Add to Calendar when
    // Your week isn't above it. The rest are quiet links.
    const during = !!(state.row && state.row.start && today() >= state.row.start && today() <= (state.row.end || state.row.start));
    const pay = it.can.pay && it.can.card;
    const main = pay ? '<button type="button" class="wk-btn wk-btn--small" data-act="paydue" data-id="' + it.id + '">' + I.lock + 'Pay ' + esc($(m.due - (m.check || 0))) + '</button>'
      : live && during ? '<a class="wk-btn wk-btn--small" href="../guide/?year=' + y + '">Open the guide</a>'
      : live && !week && !calQuiet ? '<a class="wk-btn wk-btn--small" href="' + esc(icsHref()) + '" data-icsa>' + I.cal + 'Add to calendar</a>' : '';
    const links = [
      live && !week && calQuiet && !pay && !during ? '<a class="wk-linklike" href="' + esc(icsHref()) + '" data-icsa>Add to calendar</a>' : '',
      // Paying by check stays a choice beside the card (it was only in the one-time banner after a
      // cancelled checkout; a Young Folk with no card had no way back to it).
      it.can.pay && !state.F.late ? '<button type="button" class="wk-linklike" data-act="paycheck" data-id="' + it.id + '">Pay by check</button>' : '',
      it.can.change ? '<a class="wk-linklike" href="?year=' + y + '&view=edit&id=' + it.id + '">Change</a>' : '',
      '<a class="wk-linklike" href="?year=' + y + '&view=receipt&id=' + it.id + '">Receipt</a>',
      it.can.leave ? '<button type="button" class="wk-linklike" data-act="leave" data-id="' + it.id + '">Leave early</button>' : '',
      // Cancel lives at the bottom of the Change page; here only when there's no Change.
      it.can.cancel && !it.can.change ? '<button type="button" class="wk-linklike" data-act="cancelreg" data-id="' + it.id + '">Cancel registration</button>' : ''
    ].filter(Boolean).join('');
    return '<section class="rf-card rs-card" data-k="st-' + it.id + '" aria-labelledby="rs-h-' + it.id + '"><div class="rs-head"><h2 class="rs-id" id="rs-h-' + it.id + '">' + esc(it.rid) + '</h2><p class="rs-who">' + escn(regName(d)) + '</p></div>' +
      flashOf(it.id) + line + plan + approvalLine(it) + checkCard(it, it.standing && it.standing.money === 'check' ? false : undefined) +
      '<div class="rf-card__btns">' + main + (links ? '<span class="rf-card__links">' + links + '</span>' : '') + '</div></section>';
  }

  // The rest of a registration (who, the stay's details, meals, preteens, the money as a ledger), under
  // its status card. Its actions are on the status card.
  // withWeek: Your week is drawn above it, with the status card's number and name, so this card is only
  // the details the week doesn't show (headed "Details").
  function regCard(it, withWeek) {
    const d = it.data, m = d.money || {}, held = it.phase === 'held', y = esc(state.year), s = d.stay;
    // A past year: the header already says when it was held; the card says only what's true of it.
    if (held) {
      const st = [d.people.length > 1 ? plural(d.people.length, 'person', 'people') : '', m.paid ? 'Paid ' + $(m.paid) : ''].filter(Boolean).join(' · ');
      return '<section class="rf-card" data-k="r-' + it.id + '"><h2 class="rf-card__h">' + I.bed + esc(regName(d)) + '</h2>' + (st ? '<p class="rf-card__st">' + escn(st) + '</p>' : '') +
        '<p class="rf-card__btns"><span class="rf-card__links"><a class="wk-linklike" href="?year=' + y + '&view=receipt&id=' + it.id + '">Receipt</a></span></p></section>';
    }
    // A part with three lines or more folds; one or two are shown as they are (no tap to read one line).
    const part = (title, lines) => !lines.length ? '' : lines.length >= 3 ? '<details class="rf-fold"><summary><span>' + esc(title) + '</span></summary><div class="rf-fold__b">' + lines.map(l => '<p>' + escn(l) + '</p>').join('') + '</div></details>'
      : '<div class="rf-part"><p class="rf-part__k">' + esc(title) + '</p>' + lines.map(l => '<p>' + escn(l) + '</p>').join('') + '</div>';
    // The household reading its own page: first names (full names only on the receipt), as the form says them.
    const extras = [!withWeek && s.type === 'dorm' && (s.keys || []).length ? 'Keys: ' + (s.keys || []).map(first).join(', ') : '', withWeek ? '' : linenWords(d), s.mattresses ? plural(s.mattresses, 'air mattress', 'air mattresses') : '', d.people.length > 1 && d.people.some(p => p.ground || p.walker || p.restroom || p.crib) ? '' : [s.ground ? 'Ground floor' : '', s.walker ? 'No stairs' : '', s.restroom ? 'Near a restroom' : '', s.nearW ? 'Near the women’s restroom' : '', s.nearM ? 'Near the men’s restroom' : ''].filter(Boolean).join(', '), s.near ? 'Near ' + s.near : '', s.arrive ? ARRIVE[s.arrive] : '', s.needs ? 'Note: ' + s.needs : ''].filter(Boolean);
    const pts = d.people.filter(p => p.preteen);
    // The ledger only when something is owed, promised or coming back; else the status says it ("Paid $340").
    // A check to come is said once, in its box with the address.
    const mrows = moneyRows(m, d).filter(r => r && !(m.check && r[0] === 'Check to come') && !(lateIn(m) && r[0] === 'Due at check-in'));
    const money = mrows.length && ((m.due > 0 && !lateIn(m)) || m.check > 0 || m.refund > 0 || m.refunded > 0) ? ledger([['Total', m.total || 0]].concat(mrows), 'Payment') : '';
    const listed = d.people.length > 1;
    const plines = listed ? d.people.map(p => personLine(p, d, it, withWeek)).join('') : '';
    const body = (plines ? '<ul class="rf-people-l">' + plines + '</ul>' : '') +
      (withWeek ? '' : '<p class="rf-card__line">' + escn(stayWords(d, listed)) + '</p>') +
      part('Room details', extras) +
      (withWeek ? '' : part('Meals', [mealsWords(answersOf(d))])) +
      part('Preteens', pts.length ? [pts.map(p => first(p.name)).join(', ') + ' · Picked up by ' + pickupOf(d)].concat((d.contacts || []).some(c => c.name) ? ['Contacts: ' + d.contacts.filter(c => c.name).map(c => c.name + (c.rel ? ' (' + c.rel + ')' : '')).join(', ')] : []) : []) +
      money;
    // Under Your week with nothing more to say: no card (never an empty one).
    if (withWeek && !body) return '';
    // Its number and status head the status card above; this card is who and what (with the week: the
    // details it doesn't show).
    return '<section class="rf-card" data-k="r-' + it.id + '"><h2 class="rf-card__h">' + I.bed + (withWeek ? 'Details' : esc(regName(d)) + '<small>' + esc(it.rid) + '</small>') + '</h2>' +
      // One person: the card's title already names them; only what's true of them follows.
      body + '</section>';
  }
  // Where a parent's approval went, in full (the household typed it; polish 3: masked, a typo couldn't be
  // seen), with Resend and Change (just that address, and a new link). Nothing while it's held back for
  // a card payment still open.
  function approvalLine(it) {
    const ap = it.data.approval;
    if (!ap || ap.state !== 'waiting' || ap.held || it.data.status === 'cancelled') return '';
    return '<p class="reg-wait">' + I.mail + '<span>' + esc('Approval sent to ' + ap.to) + ' · <button type="button" class="wk-linklike" data-act="resendapproval" data-id="' + it.id + '">Resend</button> · <button type="button" class="wk-linklike" data-act="approvalto" data-id="' + it.id + '">Change</button></span></p>';
  }
  function approvalToSheet(id) {
    const it = (state.mine || []).find(x => x.id === id) || (state.done && state.done.id === id ? state.done : null);
    if (!it) return;
    openSheet('Parent’s email', '<div class="reg-field"><label class="reg-label" for="f-apto">Parent’s email</label><input id="f-apto" type="email" inputmode="email" maxlength="120" value="' + esc(it.data.approval.to) + '" aria-describedby="help-apto"><span class="rf-help" id="help-apto">A new link is sent · The old one stops working</span></div>',
      () => {
        const to = String(sheet.querySelector('#f-apto').value || '').trim();
        if (!emailOk(to)) return Promise.reject({ status: 400, message: 'Enter an email like name@example.com' });
        return api('POST', 'reg/r/' + id + '/approval', { to }).then(out => {
          state.flash = { id, text: 'Sent to ' + to };
          if (state.done && state.done.id === id) state.done = out.item;
          return state.view === 'done' ? null : loadMine();
        }).then(draw);
      }, 'Send', false, 'Cancel');
    setTimeout(() => { const i = sheet.querySelector('#f-apto'); if (i) { i.focus(); i.select(); } }, 30);
  }
  // Who may pick the preteens up, in first names ("Martha or John"), as the form says it.
  const pickupOf = d => [].concat((d.pickupWho || []).length ? d.pickupWho.map(first) : d.people.filter(p => p.kind === 'adult').map(p => first(p.name)), d.pickupOther ? [d.pickupOther] : []).join(' or ') || (d.pickup || '');
  // A line under a card after something was done to it ("Sent to the parent again"), or why it wasn't.
  const flashOf = id => state.flash && state.flash.id === id ? '<p class="rf-flash' + (state.flash.bad ? ' is-bad' : '') + '" role="' + (state.flash.bad ? 'alert' : 'status') + '">' + (state.flash.bad ? I.info : I.check) + '<span>' + esc(state.flash.text) + '</span></p>' : '';
  function mineView() {
    const me = SU.me();
    if (!me || me.pending) return page(hero('Your sign-ups', { facts: false }), signinCard());
    const sub = '<p class="rf-who">' + esc(me.email) + ' · <button type="button" class="wk-linklike" data-act="signout">Sign out</button></p>';
    if (state.mineErr) return page(hero('Your sign-ups', { sub, photo: true }), blankCard('Couldn’t load', '', '<button type="button" class="wk-btn wk-btn--line wk-btn--small" data-act="retry">Retry</button>'));
    const items = (state.mine || []).filter(it => it.data.status !== 'cancelled' || state.ui.showCancelled), cancelled = (state.mine || []).filter(it => it.data.status === 'cancelled');
    const shifts = shiftGroups(), teams = myTeams(), F = state.F, held = F.phase === 'held';
    const signupsOpen = (state.model.settings.signups_posted || '9999') <= today();
    const banner = payBanner();
    // Your week at the top (Michael, Oct 13): each of this household's own registrations (a helper's
    // households keep their cards); after the Conference, only the cards.
    const during0 = !!(state.row && state.row.start && today() >= state.row.start && today() <= (state.row.end || state.row.start));
    const own = held ? [] : items.filter(it => it.data.status !== 'cancelled' && (items.length === 1 || SU.sameEmail(it.data.household.email || '', me.email)));
    // Helping out, up top while this email has no shift yet (Caleb, Oct 24, on the thank-you; the same here):
    // under the household's status, before its week, with Find a shift the one filled button unless Pay or
    // the guide is. Once there are shifts, they're listed in the cards below as before.
    const wgs = myWaits(), pgs = myPending();
    const dormAsk = items.some(it => it.data.status !== 'cancelled' && dormAskFor(it.data));
    const cta = !held && signupsOpen && own.length > 0 && !shifts.length && !wgs.length && !pgs.length;
    const ctaFill = cta && !during0 && !items.some(it => it.can.pay && it.can.card);
    const ctaCard = cta ? '<section class="rx-card rf-next"><p class="rf-next__k">' + I.hand + 'Helping out</p><p>' + esc(dormAsk ? C('dorm_ask') : 'Volunteer shifts are open') + '</p><p class="rf-next__btns">' + findShift(dormAsk, ctaFill) + '</p></section>' : '';
    // Each registration: its number and status line (with Pay, Change and the rest), then its week.
    const weeks = (held ? [] : items).map(it => statusCard(it, own.indexOf(it) > -1, ctaFill) + (it === own[0] ? ctaCard : '') + (own.indexOf(it) > -1 ? weekCard(it, !(it.can.pay && it.can.card) && !during0 && !ctaFill) : '')).join('');
    const cards = items.map(it => regCard(it, own.indexOf(it) > -1)).join('') +
      (cancelled.length && !state.ui.showCancelled ? '<p class="rf-quiet"><button type="button" class="wk-linklike" data-act="showcancelled">' + esc(plural(cancelled.length, 'cancelled registration')) + '</button></p>' : '');
    // Someone who only volunteers (shifts, no registration): the shifts are the page's point, so they come
    // first and Register is a plain card with an outlined button, never the filled one (after the fourth
    // critic, Oct 15). With nothing at all, Register stays the one filled action.
    const none = !items.length ? (F.phase === 'open' ? '<section class="rf-card"><h2 class="rf-card__h">' + I.bed + 'Lodging and meals</h2><p class="rf-card__btns"><a class="wk-btn' + (shifts.length ? ' wk-btn--line' : '') + ' wk-btn--small" href="?year=' + esc(state.year) + '">Register</a></p></section>' : '') : '';
    const another = items.length && F.phase === 'open' ? '<p class="rf-quiet rf-another"><a href="?year=' + esc(state.year) + '&another=1">Register another</a></p>' : '';
    // Helping out says its one true thing: the dorm-shift ask for parents with Young Folks in the halls,
    // or that shifts are open (when this email has none yet).
    // The ask is a way to its shifts, not a rule with no action (after the third critic, Oct 15): its
    // committee's job (dorm_committee › dorm_job, the COA's settings) as a quiet link beside Find a shift,
    // which opens the committees (Oct 24), as on the thank-you.
    const helpLine = held ? '' : dormAsk ? '<p class="rf-card__line">' + esc(C('dorm_ask')) + '</p>' : !shifts.length && !myPending().length ? '<p class="rf-card__line">Volunteer shifts are open</p>' : '';
    // The same words as the volunteer page (after the critic, Oct 15): a shift once, "Fri, May 28", and its
    // people from this email ("Daniel and Esther", or "Walter" once Edna has left it): only the signed-in
    // person alone on it isn't named. Waiting to confirm / Swap open said for whom it's true.
    // The waitlists this email is on (after the fifth critic, Oct 15: they showed only on the volunteer
    // page), a shift once with its people, each with Leave waitlist.
    const waitList = wgs.length ? '<p class="rf-sub">Waitlist</p><ul class="rf-items rf-items--wait">' + wgs.map(({ ws, sh }) => '<li data-k="w-' + esc(sh.id) + '"><span><b>' + esc(SU.jobWords(sh.role, sh.committee)) + '</b><small>' + escn([shDay(sh), shiftTime(sh), sh.place ? sh.place.name : ''].filter(Boolean).join(' · ')) + '</small><small class="rf-on">' + esc(namesOn(ws) + ' · Email when a place opens') + '</small></span>' +
      (held ? '' : '<button type="button" class="wk-linklike" data-act="unwait" data-v="' + esc(ws.map(w => w.rid).join(' ')) + '" aria-label="' + esc('Leave waitlist, ' + sh.role + ', ' + shDay(sh)) + '">Leave waitlist</button>') + '</li>').join('') + '</ul>' : '';
    // This email's places another device made, still waiting for its Confirm (the volunteer page's
    // pending; after the eighth critic, Oct 16: Hannah's second place wasn't listed at all): said, with
    // Resend, in time order.
    const pendList = pgs.length ? '<p class="rf-sub">Waiting to confirm</p><ul class="rf-items rf-items--wait">' + pgs.map(({ ps, sh }) => '<li data-k="p-' + esc(sh.id) + '"><span><b>' + esc(SU.jobWords(sh.role, sh.committee)) + '</b><small>' + escn([shDay(sh), shiftTime(sh), sh.place ? sh.place.name : ''].filter(Boolean).join(' · ')) + '</small><small class="rf-on">' + esc(namesOn(ps)) + '</small> <small class="rf-tag">Waiting to confirm</small></span>' +
      (held ? '' : '<button type="button" class="wk-linklike" data-act="resendvol" data-v="' + esc(ps.map(x => x.rid).join(' ')) + '" aria-label="' + esc('Resend the Confirm email, ' + sh.role + ', ' + shDay(sh)) + '">Resend</button>') + '</li>').join('') + '</ul>' : '';
    const help = cta ? '' : shifts.length || wgs.length || pgs.length || (signupsOpen && !held) ? '<section class="rf-card"><h2 class="rf-card__h">' + I.hand + (shifts.length || wgs.length || pgs.length ? 'Your shifts' : 'Helping out') + '</h2>' + helpLine + (shifts.length ? '<ul class="rf-items">' + shifts.map(({ us, sh }) => '<li data-k="s-' + esc(sh.id) + '"><span><b>' + esc(SU.jobWords(sh.role, sh.committee)) + '</b><small>' + escn([shDay(sh), shiftTime(sh), sh.place ? sh.place.name : ''].filter(Boolean).join(' · ')) + '</small>' + (namedOn(us) ? '<small class="rf-on">' + esc(namesOn(us)) + '</small>' : '') + shiftTags(us).map(t => ' <small class="rf-tag">' + escn(t) + '</small>').join('') + '</span>' + (held ? '' : '<button type="button" class="wk-linklike" data-act="leaveshift" data-v="' + esc(sh.id) + '" aria-label="' + esc('Leave shift, ' + sh.role + ', ' + shDay(sh) + (namedOn(us) ? ', ' + namesOn(us) : '')) + '">Leave shift</button>') + '</li>').join('') + '</ul>' : '') +
      pendList + waitList + (held ? '' : '<p class="rf-card__btns">' + findShift(dormAsk) + '</p>') + '</section>' : '';
    const tOpen = (state.model.settings.tournaments_posted || '') && state.model.settings.tournaments_posted <= today();
    const tourn = teams.length || (tOpen && items.some(it => it.data.people.some(p => p.yf))) ? '<section class="rf-card"><h2 class="rf-card__h">' + I.trophy + 'Tournaments</h2>' + (teams.length ? '<ul class="rf-items">' + teams.map(t => '<li><span><b>' + esc(t.team || (t.players || [])[0] || '') + '</b><small>' + esc((t.players || []).join(', ')) + '</small></span></li>').join('') + '</ul>' : '') +
      '<p class="rf-card__btns"><a class="wk-btn wk-btn--line wk-btn--small" href="../tournaments/?year=' + esc(state.year) + (teams.length ? '&view=mine' : '') + '">' + (teams.length ? 'Change' : 'Sign up a team') + '</a></p></section>' : '';
    // Add to Calendar is the registration card's own action; with shifts only, it's under them.
    const during = !!(state.row && state.row.start && today() >= state.row.start && today() <= (state.row.end || state.row.start));
    const cal = !held && !during && !items.some(it => it.data.status !== 'cancelled') && shifts.length ? '<p class="rf-cal"><a class="wk-btn wk-btn--line wk-btn--small" href="' + esc(icsHref()) + '" data-icsa>' + I.cal + 'Add to calendar</a></p>' : '';
    const nothing = !items.length && !shifts.length && !none && !tourn && !help ? blankCard(held ? 'Nothing for ' + state.year : 'Nothing yet', '') : '';
    return '<div class="wk reg rx-page rx-page--mine">' + rxHero('Your sign-ups', '', sub) + '<section class="rx-main"><div class="wk-wrap">' + banner + weeks +
      '<div class="rf-cards rx-cards2">' + cards + (shifts.length && !items.length ? help + none : none + help) + tourn + '</div>' + cal + nothing + another + '</div></section></div>';
  }

  // Your rooms on their floor, once Lodging posts them (the status card's Floor plan): '' when the
  // hall's plan isn't there to draw (the rooms are then said in words only).
  function planOf(ids) {
    const rs = (ids || []).map(roomOf).filter(Boolean);
    if (!rs.length) return '';
    const r = rs[0], P = O.map && state.plans[r.hall], fl = P && r.floor != null && P.floors[r.floor];
    if (!fl) return '';
    const narrow = matchMedia('(max-width: 759px)').matches, st = sh => ids.indexOf(sh.id) > -1 ? 'mine' : roomBy(sh.id) ? 'free' : 'off';
    return '<div class="rf-rooms__plan" data-own>' + O.map.floorSvg(fl, { state: st, turn: O.map.turnFor(fl, narrow), px: narrow ? 3 : 0, beds: sh => (roomBy(sh.id) || {}).beds || 2, title: r.hall + ', ' + floorWord(r.floor) + ': your rooms' }) + '</div>';
  }

  // A receipt to print or keep: who issued it, the number, who, what, the charges, the payments
  // received (date · how · amount), what's still to come. One page on paper.
  function receiptView() {
    const it = (state.mine || []).find(x => String(x.id) === q.get('id'));
    if (!it) return page(hero('Receipt', { facts: false }), SU.me() && !SU.me().pending ? blankCard('Not found', mineLink()) : signinCard());
    const d = it.data, m = d.money || {}, paidRows = paymentRows(it);
    // On screen: the site's cream band and a white card (polish 3: it looked like plain HTML); on paper
    // the band and card fall away and it prints as before. The dates a treasurer needs: registered, issued.
    const issued = 'Registered ' + longDate(d.at || (d.created || '').slice(0, 10)) + ' · Issued ' + longDate(today());
    return '<div class="wk reg reg-print"><header class="wk-hero reg-print__band"><div class="wk-wrap"><div class="wk-hero__text vol-hero"><p class="wk-kicker">' + esc(state.year) + ' Annual Conference</p><h1 class="vol-title">Receipt <span class="reg-print__id">' + esc(it.rid) + '</span></h1>' +
      '<p class="reg-print__dates">' + escn(issued) + '</p></div></div></header>' +
      '<section class="wk-main"><div class="wk-wrap"><div class="reg-wrap"><div class="rf-card reg-print__card">' +
      '<p class="reg-print__where">' + escn(O.fmtDateSpan(state.row.start, state.row.end) + ' · ' + (state.model.settings.venue || '')) + '</p>' +
      '<h2 class="rf-pname">' + esc(regName(d)) + '</h2><ul class="rf-people-l">' + d.people.map(p => personLine(p, d, it)).join('') + '</ul><p>' + escn(stayWords(d, true)) + '</p>' +
      (linenWords(d) ? '<p>' + escn(linenWords(d)) + '</p>' : '') +
      (d.stay.type === 'dorm' && (d.stay.keys || []).length ? '<p>Keys: ' + esc((d.stay.keys || []).join(', ')) + '</p>' : '') + (it.rooms && it.rooms.length ? '<p>Rooms: ' + esc(roomsWords(it.rooms)) + '</p>' : '') +
      ledger(d.price.lines.map(l => [l.label, l.cents]).concat([['Total', m.total || 0, { sum: true }]]), 'Charges') +
      (paidRows.length ? '<h2 class="rf-q">Payments</h2>' + ledger(paidRows.concat([['Paid', m.paid || 0, { sum: true }]]), 'Payments') : '') +
      ledger(moneyRows(m, d).filter(r => r && r[0] !== 'Paid'), 'Still to come') +
      '<p class="reg-print__by">' + esc('Issued by the ' + state.year + ' Committee of Arrangements, Old German Baptist Brethren Church, New Conference') + '</p></div>' +
      '<p class="rf-card__btns reg-noprint reg-print__btns"><button type="button" class="wk-btn" data-act="print">' + I.print + 'Print</button><a class="wk-linklike" href="?year=' + esc(state.year) + '&view=mine">Your sign-ups</a></p></div></div></section></div>';
  }
  // "March 2, 2027": a date a treasurer files by.
  const longDate = iso => iso ? O.fmtDate(iso, 'mdy') : '';

  /* ================================================================ a parent's approval */

  // A parent's approval: who registered their child first (so the email's link is plainly expected),
  // then the child's hall, nights and roommate, their own cost only, Approve (filled) or Decline (quiet,
  // confirmed in a sheet that says what is cancelled and refunded).
  // The parent's link: the server moves its token into a short cookie and opens a clean address
  // (?approve=1), so it isn't kept in history or sent on to other sites.
  function approveToken() {
    const v = q.get('approve') || '';
    if (v !== '1') return v;
    const m = /(?:^|;\s*)ogc_approve=([^;]+)/.exec(document.cookie);
    return m ? decodeURIComponent(m[1]) : '';
  }
  function approveView() {
    const A = state.approve, yfo = ownerOr('yfOwner');
    if (!A) return page(hero('Approval', { facts: false }), blankCard('Link expired', esc('Ask the person who registered' + (yfo ? ', or the ' + yfo : ''))));
    const yf = A.who, names = yf.map(p => first(p.name)).join(' and ');
    // One date format in the area: "Sat Oct 10" (polish 2: the approved state said "October 10").
    // The answer once, with what follows (polish 3: "Declined" was said twice).
    const whose = yf.length === 1 ? first(yf[0].name) + '’s registration is cancelled' : 'The registration is cancelled';
    const done = A.state === 'approved' ? blankCard(escn('Approved · ' + shortDate(A.at)), escn(names + ' · ' + A.rid)) : A.state === 'declined' ? blankCard('Declined', escn((A.status === 'cancelled' ? whose : names + (yf.length > 1 ? ' come' : ' comes') + ' off the registration') + (A.refund ? ' · Refund requested · ' + $(A.refund) : ''))) : '';
    const rows = A.lines.map(l => [l.label, l.cents]).concat(A.lines.length > 1 ? [['Total', A.total, { sum: true }]] : [], A.alone ? moneyRows({ paid: A.paid, check: A.check, due: A.due }, null) : []);
    // What's being approved, plainly, under the title (the email's own line).
    const what = yf.map(p => first(p.name) + ' staying in the ' + p.hall).join(' · ') + ' · Under 18';
    return page(hero(done ? 'Approval' : 'Approve ' + names, { facts: true, sub: done ? '' : '<p class="reg-approve__what">' + escn(what) + '</p>' }), done ||
      ('<p class="reg-preview">' + I.info + '<span><b>Registered by ' + esc(A.by) + '</b> · ' + esc(A.rid) + '</span></p>' +
        '<section class="rf-card"><ul class="rf-people-l">' + yf.map(p => '<li><b>' + esc(p.name) + (p.age ? ', ' + esc(p.age) : '') + '</b><small>' + escn(p.hall + (p.rooming ? ' · Rooming with ' + p.rooming : p.rooming_other ? ' · A roommate they named' : '')) + '</small><small>' + escn('Check-in ' + shortDate(p.from) + ' · Check-out ' + shortDate(p.to) + ' · ' + plural(p.nights.length, 'night')) + '</small></li>').join('') + '</ul>' +
        (A.keys ? '<p class="rf-hall">' + I.key + '<span>' + esc(A.keys) + '</span></p>' : '') +
        (rows.length ? ledger(rows, 'Cost') : '') + (A.alone ? '' : '<p class="rf-card__st">' + esc(A.covered) + '</p>') +
        (A.questions ? '<p class="rf-help">' + esc('Questions: ' + A.questions) + '</p>' : '') +
        (state.approveErr ? '<p class="rf-err" role="alert">' + esc(state.approveErr) + '</p>' : '') +
        '<p class="rf-card__btns"><button type="button" class="wk-btn" data-act="approve" data-v="approve">' + I.check + 'Approve</button><button type="button" class="wk-linklike" data-act="approve" data-v="decline">Decline</button></p></section>'));
  }

  /* ================================================================ the test checkout (local only) */

  function checkoutView() {
    const P = state.checkout;
    if (!P) return page(hero('Checkout', { facts: false }), blankCard('Not found', mineLink()));
    if (P.status !== 'pending') return page(hero('Checkout', { facts: false }), blankCard(P.status === 'paid' ? 'Paid' : 'Closed', mineLink()));
    return page(hero('Checkout', { facts: false }), '<section class="rf-card reg-checkout"><p class="wk-kicker">Test checkout</p><h2 class="wk-h">Pay ' + esc($(P.cents)) + '</h2><p>' + esc(P.rid) + '</p>' +
      '<p class="ogc-mock ogc-mock--tag">' + (W.prototype ? 'Prototype' : 'Local') + ' · The payment company’s own page opens here · Nothing is charged</p>' +
      '<p class="rf-card__btns"><button type="button" class="wk-btn" data-act="testpay" data-v="paid">' + I.card + 'Pay (test)</button><button type="button" class="wk-btn wk-btn--line" data-act="testpay" data-v="declined">Decline (test)</button><button type="button" class="wk-linklike" data-act="testpay" data-v="cancelled">Cancel</button></p></section>');
  }

  const VIEWS = { gone: () => goneView(), form: formView, edit: formView, mine: mineView, done: doneView, receipt: receiptView, approve: approveView, checkout: checkoutView, error: () => page(hero('Register', { facts: false }), blankCard('Couldn’t load', '', '<button type="button" class="wk-btn wk-btn--line wk-btn--small" data-act="reload">Retry</button>')) };

  /* ================================================================ input */

  function setPath(path, value) {
    const parts = path.split('.'), d = state.d;
    if (parts[0] === 'people') { const p = d.people.find(x => x.pid === parts[1]); if (p) p[parts[2]] = value; return; }
    if (parts[0] === 'preteens') { const o = d.preteens[parts[1]] || (d.preteens[parts[1]] = { medical: '', days: ptDays() }); o[parts[2]] = value; return; }
    let o = d;
    for (let i = 0; i < parts.length - 1; i++) o = o[isNaN(parts[i]) ? parts[i] : +parts[i]];
    o[parts[parts.length - 1]] = value;
  }
  const clearErr = path => { delete state.errors[path]; };

  root.addEventListener('input', e => {
    const t = e.target;
    if (!t.name || t.type === 'checkbox' || t.type === 'radio') return;
    if (t.name === 'verify.code') { state.verify.code = t.value.replace(/\D/g, '').slice(0, 6); state.verify.err = ''; if (state.verify.code.length === 6) verifyCode(); return; }
    if (t.name === 'signin.code') { state.signin.code = t.value.replace(/\D/g, '').slice(0, 6); state.signin.err = ''; if (state.signin.code.length === 6) signinCode(); return; }
    if (t.name === 'signin.email') { state.signin.email = t.value; return; }
    if (!state.d) return;
    if (t.name === 'gift') { if (/\D/.test(t.value)) t.value = t.value.replace(/\D/g, ''); state.d.gift = Math.max(0, Math.min(5000, parseInt(t.value, 10) || 0)); }
    else if (/\.age$/.test(t.name)) { if (/\D/.test(t.value)) t.value = t.value.replace(/\D/g, '').slice(0, 3); setPath(t.name, t.value); }
    else setPath(t.name, t.value);
    clearErr(t.name);
    if (/email$/.test(t.name)) { state.verify.err = ''; if (t.name !== 'stay.parentEmail' && state.verify.step === 'sent' && state.verify.email !== wantEmail()) state.verify.step = ''; }
    state.barNote = '';
    peopleChanged(() => {});
  });
  root.addEventListener('change', e => {
    const t = e.target;
    // Received on (Round 5): the call's day, or the postmark; never after today.
    if (t.hasAttribute && t.hasAttribute('data-recv')) { state.received = /^\d{4}-\d\d-\d\d$/.test(t.value) && t.value <= today() ? t.value : today(); return; }
    if (!t.name || !state.d) return;
    const s = state.d.stay;
    // Not everyone every night: a night a person (each starts with the household's); off again, the
    // household's nights are every night anyone was here.
    if (t.name === 'perNights') { state.ui.perNights = t.checked; if (!t.checked) { s.perPerson = false; state.d.people.forEach(p => { p.nights = []; }); } clearErr('stay.nights'); named().forEach(p => clearErr('people.' + p.pid + '.nights')); }
    else if (t.type === 'checkbox') { setPath(t.name, t.checked); clearErr(t.name); }
    else return;
    update();
  });
  // A change in who's coming: what follows from it (rooms, keys, linens) is worked out, kept and drawn;
  // every card is open, so the rooms and keys it changed show where they are.
  function peopleChanged(fn) {
    state.override = null;
    fn();
    settle();
    keep(); draw();
  }

  // A ten-digit phone is written 555-555-0142 when the field is left.
  root.addEventListener('focusout', e => {
    const t = e.target;
    if (!state.d || !t.name || t.type !== 'tel') return;
    const f = fmtPhone(t.value);
    if (f !== t.value) { t.value = f; setPath(t.name, f); keep(); draw(); }
  });

  root.addEventListener('submit', e => {
    if (e.target.matches('[data-form="signin"]')) { e.preventDefault(); signinSend(); }
  });

  // Return moves to the next box; on the last name it adds a person; on the last box it continues.
  root.addEventListener('keydown', e => {
    const t = e.target;
    if (t.matches && t.matches('.rg [data-act="gnight"], .rg [data-act="gmeal"]') && /^(Arrow(Left|Right|Up|Down)|Home|End)$/.test(e.key)) { if (gridMove(t, e.key)) e.preventDefault(); return; }
    if (t.getAttribute && t.getAttribute('role') === 'radio' && /^Arrow(Left|Right|Up|Down)$/.test(e.key)) {
      const g = t.closest('[role="radiogroup"]'), all = Array.from(g.querySelectorAll('[role="radio"]:not([disabled])')), i = all.indexOf(t), n = all[(i + (/Left|Up/.test(e.key) ? -1 : 1) + all.length) % all.length];
      e.preventDefault(); if (n) { n.click(); const again = root.querySelector('[data-act="' + n.dataset.act + '"][data-v="' + CSS.escape(n.dataset.v) + '"]' + (n.dataset.pid ? '[data-pid="' + n.dataset.pid + '"]' : '') + (n.dataset.i != null ? '[data-i="' + n.dataset.i + '"]' : '')); if (again) again.focus(); }
      return;
    }
    if (e.key !== 'Enter' || t.tagName !== 'INPUT' || t.type === 'checkbox') return;
    if (t.name === 'verify.code') { e.preventDefault(); verifyCode(); return; }
    if (t.name === 'signin.code') { e.preventDefault(); signinCode(); return; }
    if (t.name === 'signin.email') return;
    e.preventDefault();
    const sec = t.closest('.rs-card');
    if (!sec) return;
    const boxes = Array.from(sec.querySelectorAll('input:not([type="checkbox"]):not([type="radio"]):not([readonly]):not([type="date"]), textarea')), i = boxes.indexOf(t);
    const names = Array.from(sec.querySelectorAll('.rp-name input'));
    if (names.length && t === names[names.length - 1] && t.value.trim()) { act({ dataset: { act: 'add' } }); return; }
    // The last box of a step: Continue (on Review, nothing: its one action is pressed, never typed into).
    if (boxes[i + 1]) boxes[i + 1].focus();
    else if (state.step !== 'review') { const n = root.querySelector('[data-act="next"]'); if (n && !n.disabled) n.click(); }
  });

  root.addEventListener('click', e => {
    const b = e.target.closest('[data-act]');
    if (!b || b.disabled) return;
    // ‹ Households (Round 5): straight back, or asked first when something was typed (area-households-money 6.2).
    if (b.dataset.act === 'leave') {
      const typed = state.editing ? editChanged() : !!(state.d && (named().length || state.d.household.contact.trim() || state.d.stay.type));
      if (typed && state.view !== 'gone') { e.preventDefault(); openSheet('Leave without saving?', '', () => { location.href = b.getAttribute('href'); return new Promise(() => {}); }, 'Leave', false, 'Keep typing'); }
      return;
    }
    // A mouse press on a night or a meal already did it (so a drag can go on from there).
    if (state.painted && (b.dataset.act === 'gnight' || b.dataset.act === 'gmeal')) return;
    act(b);
  });

  // Click or drag across the grid with a mouse: the first cell's new state is painted onto each cell the
  // pointer crosses (a phone's finger taps, so the page still scrolls under it).
  root.addEventListener('pointerdown', e => {
    if (e.pointerType !== 'mouse' || e.button !== 0) return;
    const b = e.target.closest('[data-act="gnight"], [data-act="gmeal"]');
    if (!b || b.disabled || !root.contains(b)) return;
    e.preventDefault();
    state.paint = { act: b.dataset.act, on: b.getAttribute('aria-pressed') !== 'true', did: {} };
    state.painted = true;
    state.ui.gcell = cellKey(b);
    paintCell(b);
    const again = root.querySelector('[data-act="' + b.dataset.act + '"][data-pid="' + b.dataset.pid + '"]' + (b.dataset.v ? '[data-v="' + CSS.escape(b.dataset.v) + '"]' : '[data-id="' + CSS.escape(b.dataset.id) + '"]'));
    // Focus follows the mouse quietly: the ring is for the keyboard only.
    if (again) again.focus({ preventScroll: true, focusVisible: false });
  });
  root.addEventListener('pointerover', e => {
    if (!state.paint) return;
    const b = e.target.closest('[data-act="' + state.paint.act + '"]');
    if (b && !b.disabled) paintCell(b);
  });
  window.addEventListener('pointerup', () => { if (state.paint) { const n = Object.keys(state.paint.did).length; state.paint = null; if (n > 1) tell(n + ' changed'); } setTimeout(() => { state.painted = false; }, 0); });
  function paintCell(b) {
    const P = state.paint, k = b.dataset.pid + '|' + (b.dataset.v || b.dataset.id);
    if (P.did[k]) return;
    P.did[k] = 1;
    const p = state.d.people.find(x => x.pid === b.dataset.pid);
    if (!p) return;
    if (P.act === 'gnight') setNight(p, b.dataset.v, P.on);
    else { const m = state.meals.find(x => x.id === b.dataset.id); if (m) setMeal(p, m, P.on); }
    clearErr('people.' + p.pid + '.nights'); clearErr('stay.nights');
    update();
  }

  // The layout follows the width (the meals one person at a time below 760 px).
  try { window.matchMedia('(max-width: 759px)').addEventListener('change', () => { if (state.F && state.view) draw(); }); } catch (e) { /* an old browser keeps its first layout */ }

  // Every button: what it does, by its data-act.
  function act(b) {
    const ds = b.dataset, d = state.d, a = ds.act, P = () => d.people.find(p => p.pid === ds.pid);
    const focusAfter = sel => { const el = sel && root.querySelector(sel); if (el && !el.disabled) el.focus({ preventScroll: true, focusVisible: el.classList.contains('rf-h') ? false : undefined }); };
    const same = () => '[data-act="' + a + '"]' + (ds.pid ? '[data-pid="' + ds.pid + '"]' : '') + (ds.v != null ? '[data-v="' + CSS.escape(ds.v) + '"]' : '') + (ds.i != null ? '[data-i="' + ds.i + '"]' : '') + (ds.id != null ? '[data-id="' + CSS.escape(ds.id) + '"]' : '') + (ds.path ? '[data-path="' + ds.path + '"][data-by="' + ds.by + '"]' : '');
    switch (a) {
      case 'info': state.ui['i-' + ds.id] = !state.ui['i-' + ds.id]; draw(); return focusAfter(same());
      case 'reload': return location.reload();
      case 'retry': state.mineErr = ''; return loadMine().then(draw);
      case 'another': state.another = true; draw(); return;
      // Start new: a blank form, the contact from the sign-in (Fill in from 2026 takes it back).
      case 'startnew': state.d = Object.assign(fresh(), { start: 'new' }); state.ui = {}; state.fromReview = false; settle(); window.scrollTo(0, 0); return goStep(landStep());
      case 'startover': return openSheet('Start over', '<p class="wk-sheet__note">Everything typed here is cleared</p>', () => { dropDraft(true); state.d = Object.assign(fresh(), { start: 'new' }); state.ui = {}; state.fromReview = false; settle(); window.scrollTo(0, 0); goStep(landStep()); return Promise.resolve(); }, 'Start over', true, 'Cancel');
      case 'reuse': applyReuse(state.F.reuse[+ds.i], true); window.scrollTo(0, 0); return goStep(landStep());
      // Signing out clears this tab's draft: the next person here mustn't see this household's answers.
      // Not you? on the form: signed out here, the draft cleared, a fresh form at Contact (the page stays).
      // Your sign-ups' Sign out goes through the site's sign-out.
      case 'signout': {
        if (state.view !== 'form') { dropDraft(); return SU.signOut(); }
        // A household typed past Contact is asked first (one tap threw it all away).
        const typed = state.d && !state.editing && (named().length > 1 || (state.d.finished || []).some(k => k !== 'contact'));
        if (typed && !ds.sure) return openSheet('Sign out', '<p>Everything typed here is cleared</p>', () => { const b = document.createElement('button'); b.dataset.act = 'signout'; b.dataset.sure = '1'; return act(b); }, 'Sign out', true, 'Keep');
        dropDraft();
        state.busy = true; draw();
        return api('POST', 'reg/signout').then(out => {
          W.me = null; W.nonce = out.nonce;
          try { localStorage.removeItem('ogc-me-pending'); } catch (x) { /* nothing kept */ }
          state.verify = { step: '', email: '', code: '', to: '', err: '', busy: false, dev: '', retryAt: 0 };
          state.another = false; state.errors = {}; state.ui = {}; state.step = 'contact'; state.fromReview = false;
          return loadForm();
        }).then(() => {
          state.busy = false; state.d = fresh(); settle(); state.flashTop = 'Signed out';
          try { sessionStorage.removeItem(STEP_KEY()); } catch (x) { /* none kept */ }
          draw(); window.scrollTo(0, 0); tell('Signed out'); focusSoon('[name="household.contact"]');
          clearTimeout(state.flashTopT); state.flashTopT = setTimeout(() => { state.flashTop = ''; draw(); }, 4000);
        }, () => { state.busy = false; state.barNote = 'Not signed out · Try again'; draw(); });
      }
      case 'helper': {
        const on = ds.v === 'other';
        if (on === d.helper.on) return;
        if (on) { d.helper = { on: true, name: d.household.contact, phone: d.household.phone, email: d.household.email }; d.household = { name: '', contact: '', phone: '', email: '' }; d.people = d.people.filter(p => p.name.trim() && p.name.trim() !== d.helper.name.trim()); }
        else { d.household = { name: '', contact: d.helper.name, phone: d.helper.phone, email: d.helper.email }; d.helper = { on: false, name: '', phone: '', email: '' }; }
        state.errors = {}; update(); return focusAfter(same());
      }
      case 'typo': setPath(ds.path, ds.v); clearErr(ds.path); state.verify.typoAsked = ''; update(); tell('Email ' + ds.v); return focusAfter('[data-act="next"]');
      case 'next': return next();
      // Back: the step before (Who's coming's is Contact). A step in the line, or a Review row's Change:
      // that step (from Review, its button then says Review).
      case 'back': { const o = order(), i = o.indexOf(state.step); return i > 0 ? goStep(o[i - 1]) : undefined; }
      case 'goto': if (state.step === 'review' && ds.v !== 'review') state.fromReview = true; return goToOrFix(ds.v);
      // A night for the household, a night a person, a meal a person, a day off campus.
      case 'hnight': { const st = d.stay, set = new Set(st.nights); if (set.has(ds.v)) set.delete(ds.v); else set.add(ds.v); st.nights = nights().filter(n => set.has(n)); clearErr('stay.nights'); update(); return focusAfter(same()); }
      case 'gnight': { const p = P(); if (!p) return; if (b.closest('.rg')) state.ui.gcell = cellKey(b); setNight(p, ds.v, b.getAttribute('aria-pressed') !== 'true'); clearErr('people.' + p.pid + '.nights'); clearErr('stay.nights'); update(); return focusAfter(same()); }
      case 'gmeal': { const p = P(), m = state.meals.find(x => x.id === ds.id); if (!p || !m) return; if (b.closest('.rg')) state.ui.gcell = cellKey(b); setMeal(p, m, b.getAttribute('aria-pressed') !== 'true'); update(); return focusAfter(same()); }
      case 'where': state.ui.where = !state.ui.where; draw(); return focusAfter('[data-act="where"]');
      case 'note': state.ui.note = true; draw(); return focusAfter('#f-stay-needs');
      case 'contact2': state.ui.contact2 = true; draw(); return focusAfter('[name="contacts.1.name"]');
      case 'charges': state.ui.charges = !state.ui.charges; draw(); return focusAfter('[data-act="charges"]');
      case 'gday': { const st = d.stay, set = new Set(st.days); if (set.has(ds.v)) set.delete(ds.v); else set.add(ds.v); st.days = state.days.map(x => x.date).filter(x => set.has(x)); clearErr('stay.days'); update(); return focusAfter(same()); }
      // A person's own All: every meal of their stay (and only those); tapped again, none.
      case 'gmeals': { const p = P(); if (!p) return; const on = !sameMeals(p, d) || !mealsOn(p, d).length, ids = on ? mealsIn(p, d).map(m => m.id) : []; myMeals(p, d).forEach(m => setMeal(p, m, ids.indexOf(m.id) > -1)); update(); tell(first(p.name) + (on ? ' · Every meal' : ' · No meals')); return focusAfter(same()); }
      // Every meal: each stay's meals, following the stay from now on; Not every meal keeps the grid as it is.
      case 'mealsmode': d.meals.every = ds.v === 'every'; update(); tell(ds.v === 'every' ? 'Every meal' : 'Not every meal'); return focusAfter(same());
      case 'addadult': {
        if (d.people.length >= MAXP) return;
        const np = person({ kind: 'adult' }); d.people.push(np); delete state.errors.people; state.undo = null; draw();
        return focusAfter('[name="people.' + np.pid + '.name"]');
      }
      case 'add': {
        if (d.people.length >= MAXP) return;
        const np = person(); d.people.push(np); state.undo = null; update();
        return focusAfter('[name="people.' + np.pid + '.name"]');
      }
      case 'remove': {
        const i = d.people.findIndex(p => p.pid === ds.pid);
        if (i < 0) return;
        const p = d.people[i];
        peopleChanged(() => { d.people.splice(i, 1); });
        state.undo = { p, i }; clearTimeout(state.undoT); state.undoT = setTimeout(() => { state.undo = null; draw(); }, 10000);
        draw(); tell('Removed ' + (first(p.name) || 'person') + ' · Undo');
        return focusAfter('[data-act="undo"]');
      }
      case 'undo': if (state.undo) { const u = state.undo; state.undo = null; peopleChanged(() => { d.people.splice(u.i, 0, u.p); }); tell('Restored ' + first(u.p.name)); focusAfter('[name="people.' + u.p.pid + '.name"]'); } return;
      case 'kind': { const p = P(); if (!p) return; peopleChanged(() => { p.kind = ds.v; if (ds.v === 'yf' && !p.yfHall) p.yfHall = ''; }); clearErr('people.' + p.pid + '.age'); draw(); return focusAfter(same()); }
      // Sleeps in. A Young Folk alone: a hall chooses the hall stay (the card is chosen for them, since it
      // follows from this answer); Off campus chooses that stay. The stay and this answer always agree.
      case 'hall': {
        const p = P(); if (!p) return;
        peopleChanged(() => {
          const s = d.stay;
          if (ds.v === 'family') p.sleeps = 'family';
          else if (ds.v === 'elsewhere' || ds.v === 'camper') { if (s.type !== ds.v) { s.type = ds.v; if (ds.v === 'elsewhere' && !s.days.length) s.days = visitDays().map(x => x.date); if (ds.v === 'camper' && !s.nights.length) s.nights = mainNights().slice(); } }
          else { p.sleeps = 'hall'; p.yfHall = ds.v; if (yfOnly() && s.type !== 'yf') { s.type = 'yf'; if (!s.nights.length) s.nights = mainNights().slice(); } }
        });
        clearErr('people.' + p.pid + '.yfHall'); clearErr('stay.type'); draw(); return focusAfter(same());
      }
      case 'approval': d.stay.yfOk = ds.v === 'self'; d.stay.ask = ds.v === 'ask'; clearErr('stay.yfOk'); clearErr('stay.parentEmail'); update(); return focusAfter(ds.v === 'ask' && !d.stay.parentEmail ? '[name="stay.parentEmail"]' : same());
      // Linens for the household: Order chooses a packet for everyone to start; a pill takes one away.
      case 'linenchoice': d.stay.linenChoice = ds.v; if (ds.v === 'order') linenPeople().forEach(p => { if (inHall(p)) p.linens = true; else p.lin = true; }); clearErr('stay.linenChoice'); update(); return focusAfter(same());
      case 'linfor': { const p = P(); if (!p) return; if (inHall(p)) p.linens = !p.linens; else p.lin = !p.lin; update(); tell(first(p.name) + (hasPacket(p) ? ': linen packet' : ': own linens')); return focusAfter(same()); }
      // The preteen program, Yes or No, under a child 10 to 13 on Who's coming.
      case 'ptin': { const p = P(); if (!p) return; p.ptSet = true; p.ptOff = ds.v === 'no'; clearErr('people.' + p.pid + '.pt'); update(); return focusAfter(same()); }
      case 'communing': { const p = P(); if (!p) return; p.communing = !p.communing; update(); return focusAfter(same()); }
      // The stay chosen: its nights (or, off campus, its days) are all chosen to start, since they follow a choice.
      case 'type': if (state.editing && !state.editing.can.all) return; d.stay.type = ds.v; if (ds.v !== 'dorm') state.waitlist = false; if (ds.v !== 'elsewhere' && !d.stay.nights.length) d.stay.nights = mainNights().slice(); if (ds.v === 'elsewhere' && !d.stay.days.length) d.stay.days = visitDays().map(x => x.date); if (ds.v === 'yf') named().forEach(p => { p.sleeps = 'hall'; }); clearErr('stay.type'); update(); return focusAfter(same());
      case 'waitlist': state.waitlist = !state.waitlist; clearErr('stay.type'); update(); return focusAfter(same());
      case 'room': { const p = P(); if (p) { p.room = +ds.v; p.roomSet = true; update(); } return focusAfter(same()); }
      case 'key': d.stay.keys[+ds.i] = ds.v; update(); return focusAfter(same());
      case 'arrive': d.stay.arrive = d.stay.arrive === ds.v ? '' : ds.v; update(); return focusAfter(same());
      case 'len': d.stay.camperLen = d.stay.camperLen === ds.v ? '' : ds.v; update(); return focusAfter(same());
      case 'userooms': d.stay.rooms = +ds.v; d.stay.roomsSet = true; clearErr('stay.rooms'); update(); tell(plural(+ds.v, 'room')); return focusAfter('[data-path="stay.rooms"][data-by="1"]');
      case 'mattress': d.stay.mattresses = Math.max(0, Math.min(6, +ds.v)); update(); tell(d.stay.mattresses ? plural(d.stay.mattresses, 'air mattress', 'air mattresses') : 'No air mattress'); return focusAfter('[data-path="stay.rooms"][data-by="1"]');
      case 'step': {
        const k = ds.path.split('.')[1], by = +ds.by, s = d.stay;
        const lim = { rooms: [1, 6], linens: [0, 24], mattresses: [0, 6], campers: [1, 4] }[k] || [0, 99];
        s[k] = Math.max(lim[0], Math.min(lim[1], (+s[k] || 0) + by));
        if (k === 'rooms') { s.roomsSet = true; clearErr('stay.rooms'); }
        clearErr('stay.' + k);
        update(); tell(plural(s[k], { rooms: 'room', linens: 'linen packet', mattresses: 'air mattress', campers: 'camper' }[k] || k, k === 'mattresses' ? 'air mattresses' : ''));
        const btn = root.querySelector(same()); if (btn && !btn.disabled) btn.focus({ preventScroll: true }); else focusAfter('[data-path="' + ds.path + '"][data-by="' + (-by) + '"]');
        return;
      }
      case 'mealp': state.ui.mealP = ds.v; draw(); return focusAfter(same());
      case 'pickup': {
        const all = adults().map(p => p.name.trim()), cur = new Set(d.pickupWho.length ? d.pickupWho : all);
        if (cur.has(ds.v)) cur.delete(ds.v); else cur.add(ds.v);
        d.pickupWho = all.filter(n => cur.has(n)); if (!d.pickupWho.length && !d.pickupOther) d.pickupWho = [];
        update(); return focusAfter(same());
      }
      case 'pickother': state.ui.pickOther = !(state.ui.pickOther || d.pickupOther); if (!state.ui.pickOther) d.pickupOther = ''; update(); return focusAfter(state.ui.pickOther ? '[name="pickupOther"]' : same());
      case 'ptday': { const pt = d.preteens[ds.pid] || (d.preteens[ds.pid] = { medical: '', days: ptDays() }), set = new Set(pt.days || []); if (set.has(ds.v)) set.delete(ds.v); else set.add(ds.v); pt.days = ptDays().filter(x => set.has(x)); update(); return focusAfter(same()); }
      case 'payby': d.pay = ds.v; clearErr('pay'); update(); return focusAfter(same());
      case 'gift': state.ui.gift = true; draw(); return focusAfter('#f-gift');
      case 'deskpaid': d.deskPaid = ds.v; update(); return focusAfter(same());
      case 'pickrooms': return openPicker();
      case 'resend': return sendCode(true);
      case 'otheremail': state.verify = Object.assign(state.verify, { step: '', code: '', err: '' }); draw(); return focusAfter('[name="' + (d.helper.on ? 'helper.email' : 'household.email') + '"]');
      case 'clearsamples': return openSheet('Clear samples', '<p class="wk-sheet__note">' + esc('Sample households in ' + state.year + ' are removed · Registration opens') + '</p>', () => api('DELETE', 'reg/' + state.year + '/samples').then(() => loadForm()).then(() => { state.d = state.d || fresh(); settle(); draw(); tell('Samples cleared'); }), 'Clear samples', true, 'Cancel');
      case 'cleartests': return openSheet('Clear test registrations', '<p class="wk-sheet__note">' + esc('Registrations in ' + state.year + ' that aren’t samples · Local only') + '</p>', () => api('DELETE', 'reg/' + state.year + '/tests').then(out => { dropDraft(); tell('Cleared ' + out.cleared); location.reload(); }), 'Clear', true, 'Cancel');
      case 'register': return register();
      case 'save': return saveChange();
      // For a household (Round 5): how it came, and how a call or a letter pays.
      case 'hhhow':
        if (ds.v === 'paper' && C('paper_forms') !== 'yes') return;
        state.how = ds.v;
        if (state.desk) d.pay = state.how === 'desk' || state.F.late ? 'checkin' : 'check';
        update(); return focusAfter(same());
      case 'hhpay': d.pay = ds.v; update(); return focusAfter(same());
      case 'copy': {
        const said = t => { state.ui.copied = t; draw(); tell(t); clearTimeout(state.copyT); state.copyT = setTimeout(() => { state.ui.copied = ''; draw(); }, 3000); };
        try { return navigator.clipboard.writeText(ds.v).then(() => said('Copied'), () => said('Not copied')); } catch (x) { return said('Not copied'); }
      }
      case 'print': return window.print();
      // Print the week alone (the rest of the page steps aside on paper).
      case 'printweek': { document.body.classList.add('rx-pw'); const off = () => { document.body.classList.remove('rx-pw'); window.removeEventListener('afterprint', off); }; window.addEventListener('afterprint', off); window.print(); return setTimeout(off, 1000); }
      case 'paydue': return payDue(+ds.id, 'card');
      case 'paycheck': return payDue(+ds.id, 'check');
      case 'cancelreg': return cancelSheet(+ds.id);
      case 'leave': return leaveSheet(+ds.id);
      case 'resendapproval': return api('POST', 'reg/r/' + ds.id + '/approval').then(() => { tell('Sent'); state.flash = { id: +ds.id, text: 'Sent to the parent again' }; return loadMine(); }).then(draw, x => { state.flash = { id: +ds.id, text: x.status === 429 ? (x.message || 'Sent · Wait a minute') : 'Not sent · Try again', bad: true }; draw(); tell(state.flash.text); });
      case 'approvalto': return approvalToSheet(+ds.id);
      case 'showcancelled': state.ui.showCancelled = true; draw(); return;
      // The status line's Floor plan: the household's rooms on their floor, under the line.
      case 'plan': state.ui['plan-' + ds.id] = !state.ui['plan-' + ds.id]; draw(); return focusAfter(same());
      case 'leaveshift': return leaveShiftSheet(ds.v);
      case 'resendvol': {
        const ids = String(ds.v || '').split(' ').map(Number).filter(Boolean);
        return api('POST', 'vol/' + state.year + '/resend', { ids }).then(out => toast('Sent', (out && out.email) || ''), x => toast(x && x.status === 429 ? 'Sent · Just now' : 'Not sent · Retry'));
      }
      case 'unwait': {
        const ids = String(ds.v || '').split(' ').map(Number).filter(Boolean), g = myWaits().find(x => x.ws.some(w => ids.indexOf(w.rid) > -1));
        return api('POST', 'vol/' + state.year + '/unwait', { ids }).then(out => {
          state.vol = Object.assign({}, state.vol || {}, { waits: out.waits || [] }); state.volP = null;
          draw(); toast('Off the waitlist', g ? [g.sh.role, shDay(g.sh), namesOn(g.ws)].join(' · ') : '');
        }, () => toast('Not saved · Retry'));
      }
      case 'signincode': return signinCode();
      case 'signinresend': return signinSend(true);
      case 'signinother': state.signin = { step: '', email: '', to: '', code: '', err: '', dev: '', retryAt: 0 }; draw(); return focusAfter('[name="signin.email"]');
      case 'approve': return decide(ds.v);
      case 'testpay': return testPay(ds.v);
    }
  }

  function scrollTo(sel) {
    const el = root.querySelector(sel);
    if (!el) return;
    el.scrollIntoView({ block: 'start', behavior: reduced() ? 'auto' : 'smooth' });
    // Moved to by the script: screen readers land here, but no focus ring is drawn on a heading.
    el.focus({ preventScroll: true, focusVisible: false });
  }

  // Continue: this step checked (each problem at its field), then the next step; come from Review, back to
  // Review (or to the first step something's now missing from).
  function next() {
    // Not signed in on this device: Contact first; the code under the email confirms it (and then the
    // rest of the form shows, filled in from last year when this email saved one).
    if (!state.editing && !state.desk && !verified()) {
      const p = problems('contact');
      state.errors = p;
      if (Object.keys(p).length) { draw(); focusProblem(); tell(Object.keys(p).length === 1 ? Object.values(p)[0] : Object.keys(p).length + ' fields need attention'); return; }
      const v = state.verify;
      if (v.step === 'sent' && v.email === wantEmail()) { if (v.code.length === 6) verifyCode(); else { v.err = 'Enter the 6 digits'; draw(); focusSoon('[name="verify.code"]'); } }
      else sendCode();
      return;
    }
    const k = state.step, all = problems(), p = errsOf(k, all), n = Object.keys(p).length;
    if (n) {
      state.errors = p;
      // The parent's address asked about once: Continue again takes it as typed.
      if (/Did you mean/.test(p['stay.parentEmail'] || '')) state.ui.parentTypoAsked = String(state.d.stay.parentEmail || '').trim().toLowerCase();
      draw(); focusProblem();
      tell(n === 1 ? Object.values(p)[0] : n + ' fields need attention');
      return;
    }
    const o = order(), to = state.fromReview ? firstBad(all) || 'review' : o[o.indexOf(k) + 1] || 'review';
    goStep(to, to !== 'review' && state.fromReview ? errsOf(to, all) : null);
  }
  // The first problem on screen gets the focus: a field, or a choice of pills (its chosen pill, or the first).
  function focusProblem() {
    const el = root.querySelector('[aria-invalid="true"]') || root.querySelector('.rf-err');
    if (!el) return;
    el.scrollIntoView({ block: 'center', behavior: reduced() ? 'auto' : 'smooth' });
    const target = el.getAttribute('role') === 'radiogroup' ? (el.querySelector('[role="radio"][aria-checked="true"]') || el.querySelector('[role="radio"]')) : el;
    if (target && target.focus) target.focus({ preventScroll: true });
  }

  /* ================================================================ last year's, filled in */

  // Last year's registration as this year's form: every answer the server carried (ogc_reg_reuse), the
  // baseline the grid marks its changes against, and what's new this year. typed: what was just typed at
  // Contact (before the code) wins over last year's contact.
  function applyReuse(r, typed) {
    const was = state.d.household, owner = state.d.owner || (SU.me() && !SU.me().pending ? SU.me().email : '');
    state.d = Object.assign(answersOf(r.draft, true), { from: String(r.from), changes: r.changes || [], news: { dates: r.dates || null, prices: r.prices || [], first: r.first || '' }, owner, start: 'reuse', keep_next_year: false });
    if (typed) ['contact', 'phone', 'email'].forEach(k => { if (was && String(was[k] || '').trim()) state.d.household[k] = was[k]; });
    // Never carried: emergency contacts (other people's phones).
    state.d.contacts = blank().contacts;
    // A child new to the preteen ages this year is asked Yes or No (last year's answer stands for the rest).
    (r.changes || []).forEach(c => { const p = c.pid && / · Preteen program$/.test(c.text) ? state.d.people.find(x => x.pid === c.pid) : null; if (p) p.ptSet = false; });
    if (!payOk(state.d.pay)) state.d.pay = payChoices()[0][0];
    state.ui.phoneNew = !!r.cleared;
    state.errors = {}; state.step = 'people'; state.fromReview = false;
    settle();
    state.d.was = wasSnap(state.d);
    keep();
  }
  // Signed in, nothing filled in yet, and one of last year's saved for this year: it fills the form at
  // once (Michael, Oct 13: a returning household lands on its whole registration, ready to change).
  function maybeReuse(typed) {
    const F = state.F, d = state.d;
    if (state.editing || state.desk || state.another || !verified() || F.mine.length || F.reuse.length !== 1) return false;
    if (d.from || d.start === 'new' || named().length > 1 || d.stay.type) return false;
    applyReuse(F.reuse[0], typed);
    return true;
  }

  /* ================================================================ confirming the email, registering */

  // Before Register or Save: anything missing takes the household to its step, marked at the field.
  function allProblems() {
    const p = problems(), k = Object.keys(p);
    if (!k.length) return false;
    const to = firstBad(p) || 'review';
    if (to !== 'review') { state.fromReview = true; goStep(to, errsOf(to, p)); return true; }
    state.errors = errsOf('review', p);
    draw(); focusProblem();
    tell(k.length === 1 ? p[k[0]] : k.length + ' fields need attention');
    return true;
  }
  // The code, from the site's one sign-in (auth/send, for=register: a code and no link, to an address the
  // site may not know yet). A likely typo stops Continue once, at the field ("Check gmial.com · Did you
  // mean gmail.com?" with Use gmail.com); Continue again sends to the address as typed.
  function sendCode(again) {
    const p = problems('contact');
    if (Object.keys(p).length) { state.errors = p; draw(); focusProblem(); return; }
    const v = state.verify, email = wantEmail(), path = state.d.helper.on ? 'helper.email' : 'household.email';
    const fix = typoOf(email);
    if (fix && fix !== email && v.typoAsked !== email) { typoStop(email, fix, path); return; }
    state.busy = true; draw();
    api('POST', 'auth/send', { email, for: 'register', typos_ok: v.typoAsked === email ? 1 : 0, return: location.pathname + location.search }).then(out => {
      Object.assign(v, { step: 'sent', email, to: email, code: '', err: '', dev: out.dev_code || '', retryAt: out.next ? out.next * 1000 : Date.now() + 60000 });
      state.busy = false; draw(); focusSoon('[name="verify.code"]'); tell((again ? 'Sent again' : 'Code sent') + ' to ' + email);
      tickResend();
    }, x => {
      state.busy = false;
      const d = (x && x.data && x.data.data) || {};
      if (x.status === 409 && d.fix) { typoStop(email, d.fix, path); return; }
      if (x.status === 429 && d.until) { v.retryAt = d.until * 1000; tickResend(); }
      v.err = x.status === 429 || x.status === 400 ? (x.message || 'Not sent · Try again') : 'Not sent · Try again'; draw();
    });
  }
  function typoStop(email, fix, path) {
    state.verify.typoAsked = email;
    state.errors = { [path]: typoWords(email, fix) }; draw();
    tell(state.errors[path]); focusSoon('[data-act="typo"]');
  }
  // Phones are kept as 555-555-0142 once a ten-digit number is typed (the field, the summaries, the lists).
  const fmtPhone = v => { const t = String(v || '').trim(), dgt = t.replace(/\D/g, ''), n = dgt.length === 11 && dgt[0] === '1' ? dgt.slice(1) : dgt; return n.length === 10 && /^[\d\s().+-]+$/.test(t) ? n.slice(0, 3) + '-' + n.slice(3, 6) + '-' + n.slice(6) : t; };
  function verifyCode() {
    const v = state.verify;
    if (state.busy || v.code.length !== 6) { if (v.code.length !== 6) { v.err = 'Enter the 6 digits'; draw(); } return; }
    state.busy = true; draw();
    const name = state.d.helper.on ? state.d.helper.name : state.d.household.contact;
    api('POST', 'auth/code', { code: v.code }).then(out => {
      // The draft moves from "anon" to this person's own key (keep() writes it there next).
      dropDraft();
      signedIn({ nonce: out.nonce, me: { email: v.email, name } }); state.busy = false; v.step = 'done';
      // A draft started under another email isn't carried into this one (a shared computer).
      if (state.d.owner && state.d.owner !== v.email) { const h = state.d.household, x = state.d.helper; state.d = fresh(); state.d.household = h; state.d.helper = x; }
      state.d.owner = v.email;
      return loadForm();
    }).then(() => {
      tell('Confirmed');
      // Straight on: Contact is done and Who's coming opens, filled in from last year when this email
      // kept one.
      maybeReuse(true);
      window.scrollTo(0, 0);
      if (chooser()) { state.errors = {}; update(); focusSoon('[data-act="reuse"]'); return; }
      goStep(landStep());
    }, x => { state.busy = false; v.err = x.status === 400 || x.status === 410 ? (x.message || 'Code not valid') : 'Not checked · Try again'; v.code = ''; draw(); focusSoon('[name="verify.code"]'); });
  }
  const focusSoon = sel => setTimeout(() => { const el = root.querySelector(sel); if (el) el.focus(); }, 30);

  // What's sent: the answers only (the server works out the rest).
  function answersOut() {
    const d = JSON.parse(JSON.stringify(settle(state.d)));
    ['finished', 'from', 'changes', 'was', 'news', 'start'].forEach(k => delete d[k]);
    d.people = d.people.filter(p => p.name.trim());
    return d;
  }
  function failed(x, sel) {
    state.busy = false;
    const data = x && x.data && x.data.data || {};
    if (x && x.status === 409 && data.price) { state.override = data.price; state.barNote = x.message; draw(); tell(x.message); return; }
    if (x && (x.status === 400 || x.status === 409) && data.errors) {
      state.errors = data.errors;
      if (data.data && data.data.stay) { state.d.stay.linens = data.data.stay.linens; state.d.stay.mattresses = data.data.stay.mattresses; }
      // A problem in an earlier step takes the household back to it, at the field.
      const k = Object.keys(data.errors)[0], to = order().indexOf(stepOf(k)) > -1 ? stepOf(k) : 'review';
      if (to !== 'review') { state.fromReview = true; goStep(to, errsOf(to, data.errors)); return; }
      draw(); focusProblem(); tell(Object.values(data.errors).join(', '));
      return;
    }
    if (x && x.status === 409 && data.item) { state.barNote = 'Changed elsewhere · Reloaded'; state.editing = data.item; state.d = answersOf(data.item.data); settle(); state.d.was = wasSnap(state.d); draw(); return; }
    state.barNote = x && x.status && x.status < 500 ? (x.message || 'Not saved') : 'Not saved · Retry';
    draw(); tell(state.barNote);
  }
  function register() {
    if (state.busy || allProblems()) return;
    const M = moneyNow();
    state.busy = true; state.barNote = ''; draw();
    state.idem = state.idem || idem();
    // For a household from the app (Round 5): how it came and, for a call or a letter, the day it came.
    const atDesk = state.desk && (!state.forHh || state.how === 'desk');
    const desk = state.desk ? Object.assign({ source: state.forHh ? state.how : 'desk' }, atDesk ? { desk_paid: state.d.deskPaid || '' } : { received: state.received || today() }) : {};
    const data = answersOut();
    if (atDesk) data.pay = 'checkin';
    api('POST', withQ('reg/' + state.year), Object.assign({ data, expect: M.total, idem: state.idem, waitlist: state.waitlist ? 1 : 0 }, desk)).then(out => {
      state.idem = ''; dropDraft();
      if (out.next && out.next.checkout) { location.href = out.next.checkout; return; }
      // Back to the app, the new household open, and what was done said there.
      if (state.forHh && state.ret) { flashApp('Registered · ' + out.item.rid + ' · ' + ({ phone: 'Phone', paper: 'Paper', desk: 'Desk' })[state.how]); location.href = backTo(out.item.rid); return; }
      // The desk: saved, the form cleared for the next household, and today's list grows.
      if (state.desk) {
        state.busy = false; state.deskSaved = out.item; (state.deskToday = state.deskToday || []).push({ id: out.item.id, data: out.item.data });
        state.d = fresh(); state.d.pay = 'checkin'; settle(); state.errors = {}; state.ui = {}; state.step = 'contact'; state.fromReview = false;
        draw(); window.scrollTo(0, 0); tell('Saved · ' + out.item.rid + ' · Next household'); focusSoon('[name="household.contact"]');
        return;
      }
      state.done = out.item; state.busy = false; state.view = 'done'; document.title = 'Registered – ' + state.year + ' Annual Conference';
      if (!state.desk) history.replaceState(null, '', here('year=' + state.year + '&view=done&id=' + out.item.id));
      draw(); window.scrollTo(0, 0); focusSoon('.reg-done h2'); tell('Registered · ' + out.item.rid);
    }, failed);
  }
  function saveChange() {
    if (state.busy || allProblems()) return;
    const M = moneyNow(), ed = state.editing;
    state.busy = true; state.barNote = ''; draw();
    state.idem = state.idem || idem();
    api('PUT', withQ('reg/r/' + ed.id), Object.assign({ data: answersOut(), expect: M.total, v: ed.data._v || 0, idem: state.idem, pay: state.d.pay }, state.forHh ? { how: state.how } : {})).then(out => {
      state.idem = '';
      if (out.next && out.next.checkout) { location.href = out.next.checkout; return; }
      // Back to the household in the app (Round 5); its History says what changed, who and how.
      if (state.forHh && state.ret) { flashApp(out.same ? 'No changes' : 'Saved · ' + String(out.changed || '').split(' · ').slice(0, 2).join(' · ') + ' · ' + ({ phone: 'Phone', paper: 'Paper', desk: 'Desk' })[state.how]); location.href = backTo(ed.rid); return; }
      try { sessionStorage.setItem('ogc-reg-flash', JSON.stringify({ id: ed.id, text: out.same ? 'No changes' : 'Saved · ' + (out.changed || '') })); } catch (x) { /* none */ }
      location.href = here('year=' + state.year + '&view=mine');
    }, failed);
  }

  /* ================================================================ Your sign-ups: actions */

  const loadMine = () => !state.year ? Promise.resolve().then(() => { state.mine = []; state.mineErr = 'year'; }) : api('GET', withQ('reg/' + state.year + '/mine')).then(out => { state.mine = out.items; state.mineErr = ''; }, x => { state.mineErr = x.message || 'error'; state.mine = []; });
  function payDue(id, method) {
    state.busy = true; draw();
    api('POST', withQ('reg/r/' + id + '/pay'), { method, idem: idem() }).then(out => {
      if (out.next && out.next.checkout) { location.href = out.next.checkout; return; }
      state.busy = false; state.payNote = { text: 'Check to come' }; return loadMine().then(draw);
    }, x => { state.busy = false; state.payNote = { text: x.message || 'Not started', bad: true }; draw(); });
  }
  const sheet = document.createElement('dialog');
  sheet.className = 'ogc wk-sheet reg-sheet';
  sheet.setAttribute('aria-labelledby', 'reg-sheet-t');
  document.body.appendChild(sheet);
  sheet.addEventListener('click', e => { if (e.target === sheet || e.target.closest('[data-close]')) sheet.close(); });
  // A failure says so inside the sheet, above its buttons, until the next tap (never only to a screen reader).
  const sheetErr = x => x && (x.status === 400 || x.status === 403 || x.status === 409 || x.status === 429) && x.message ? x.message : 'Not saved · Try again';
  function openSheet(title, body, go, goLabel, alert, dismiss) {
    sheet.onchange = null; sheet.onclick = null;
    sheet.innerHTML = '<div class="wk-sheet__in"><button type="button" class="wk-sheet__x" data-close aria-label="Close">' + I.x + '</button><h2 class="wk-sheet__h" id="reg-sheet-t">' + esc(title) + '</h2>' + body +
      '<p class="rf-err reg-sheet__err" role="alert" hidden></p><p class="wk-sheet__btns"><button type="button" class="wk-btn' + (alert ? ' wk-btn--alert' : '') + '" data-go>' + esc(goLabel) + '</button><button type="button" class="wk-linklike" data-close>' + esc(dismiss || 'Cancel') + '</button></p></div>';
    const errP = sheet.querySelector('.reg-sheet__err');
    sheet.querySelector('[data-go]').onclick = () => {
      const btn = sheet.querySelector('[data-go]'); btn.disabled = true; btn.textContent = 'Processing…'; errP.hidden = true;
      Promise.resolve().then(go).then(() => sheet.close(), x => { btn.disabled = false; btn.textContent = goLabel; errP.textContent = sheetErr(x); errP.hidden = false; tell(errP.textContent); });
    };
    sheet.showModal();
  }
  function cancelSheet(id) {
    const it = (state.mine || []).find(x => x.id === id) || state.editing, m = it.data.money || {}, gift = it.data.price.gift_cents || 0, back = Math.max(0, (m.paid || 0) - (m.refund || 0) - gift);
    openSheet('Cancel registration', '<ul class="rf-sheetlist">' + (back && it.can.refund ? '<li>' + esc($(back)) + ' refund requested</li>' : m.paid && !it.can.refund ? '<li>No refund after ' + esc(O.fmtDate(C('refunds_by'), 'md')) + '</li>' : '') + (gift ? '<li>Gift ' + esc($(gift)) + ' kept for ' + esc(C('gift_for') || 'the Conference fund') + '</li>' : '') + (m.check ? '<li>The check to come isn’t needed</li>' : '') + '<li>Rooms, linens and meals are freed</li></ul>',
      () => api('POST', 'reg/r/' + id + '/cancel').then(() => { if (state.view === 'edit') { location.href = here('year=' + state.year + '&view=mine'); return new Promise(() => {}); } return loadMine(); }).then(() => { state.flash = null; draw(); tell('Cancelled'); }), 'Cancel registration', true, 'Keep registration');
  }
  function leaveSheet(id) {
    // Who's leaving (everyone at first: Harold may go home Sunday while Ruth stays), and their last night:
    // last night at the earliest (leaving this morning). No night is chosen for them (polish 2: the latest
    // was chosen, with its refund showing, so one tap filed a request nobody chose).
    const it = state.mine.find(x => x.id === id), d0 = answersOf(it.data), ppl = d0.people.filter(p => nightsFor(p, d0).length);
    const ns = it.data.stay.nights.filter(n => !early(n)), from = O.isoAddDays(today(), -1);
    const choices = ns.slice(0, -1).filter(n => nightDate(n) >= from);
    if (!choices.length) { tell('No nights left to free'); return; }
    const pick = new Set(ppl.map(p => p.pid));
    const body = (ppl.length > 1 ? '<p class="wk-sheet__note">Who’s leaving</p><p class="rf-asks reg-sheet__who" role="group" aria-label="Who’s leaving">' + ppl.map(p => togAct('leavewho', true, first(p.name), ' data-pid="' + p.pid + '"')).join('') + '</p>' : '') +
      '<p class="wk-sheet__note">Last night</p><fieldset class="reg-nights"><legend class="ogc-sr">Last night</legend><span class="reg-nights__row" style="--n:' + choices.length + '">' + choices.map(n => '<label class="reg-night"><input type="radio" name="last" value="' + esc(n) + '"><span>' + I.check + '<i>' + esc(SU.nightShort(n)) + '</i><b>' + esc(O.fmtDate(nightDate(n), 'mdShort')) + '</b></span></label>').join('') + '</span></fieldset><p class="reg-sum" data-say></p>';
    openSheet('Leave early', body, () => {
      if (!pick.size) return Promise.reject({ status: 400, message: 'Choose who’s leaving' });
      if (leftAlone().length) return Promise.reject({ status: 400, message: leftWords() });
      const lastIn = sheet.querySelector('[name=last]:checked');
      if (!lastIn) return Promise.reject({ status: 400, message: 'Choose last night' });
      return api('POST', withQ('reg/r/' + id + '/leave'), { last: lastIn.value, who: Array.from(pick) }).then(out => { state.flash = { id, text: out.refund ? $(out.refund) + ' refund requested · After the keys are back' : 'Saved' }; return loadMine(); }).then(draw);
    }, 'Leave early', false, 'Cancel');
    const go = sheet.querySelector('[data-go]');
    // No child is left in a room with no grown-up (polish 3: every adult could leave while Ruthie, 1,
    // stayed on alone, and the room kept being charged).
    const leftAlone = () => { const stay = ppl.filter(p => !pick.has(p.pid)); return !ppl.some(p => p.kind === 'adult') || stay.some(p => p.kind === 'adult') ? [] : stay.filter(p => p.kind === 'child' || p.minor); };
    const leftWords = () => { const k = leftAlone().map(p => first(p.name)); return (k.length > 1 ? k.slice(0, -1).join(', ') + ' and ' + k[k.length - 1] : k[0]) + ' would stay with no grown-up'; };
    const list = n => n.length > 1 ? n.slice(0, -1).join(', ') + ' and ' + n[n.length - 1] : n[0] || '';
    const show = () => {
      const lastIn = sheet.querySelector('[name=last]:checked'), who = ppl.filter(p => pick.has(p.pid));
      sheet.querySelectorAll('.reg-night').forEach(l => l.classList.toggle('is-on', l.querySelector('input').checked));
      go.disabled = !lastIn || !who.length || leftAlone().length > 0;
      if (!who.length) { sheet.querySelector('[data-say]').textContent = 'Choose who’s leaving'; return; }
      if (leftAlone().length) { sheet.querySelector('[data-say]').textContent = leftWords(); return; }
      if (!lastIn) { sheet.querySelector('[data-say]').textContent = 'Choose last night'; return; }
      const last = lastIn.value, keep = ns.slice(0, ns.indexOf(last) + 1), x = answersOf(it.data);
      x.people.forEach(p => { p.nights = nightsFor(p, x).filter(n => !pick.has(p.pid) || keep.indexOf(n) > -1 || early(n)); }); x.stay.perPerson = true; settle(x);
      // What comes back: a refund only of what was paid past the new total; else what's no longer owed
      // (a check to come shrinks first, as the server's ogc_reg_rebalance does).
      const less = it.data.price.lodging_cents - priceOf(x, it.data.price.prices).lodging_cents, m = it.data.money || {};
      const back = Math.max(0, Math.min(less, (m.paid || 0) - (m.refund || 0) - (it.data.price.total_cents - less)));
      // "Martha, John, Eli and Anna · Last night Sat May 29 · $65 less to pay"; everyone: no names.
      sheet.querySelector('[data-say]').textContent = nb((who.length === ppl.length ? '' : list(who.map(p => first(p.name))) + ' · ') + 'Last night ' + shortDate(nightDate(last)) + (back > 0 && it.can.refund ? ' · ' + $(back) + ' refund' : back > 0 ? ' · No refund after ' + O.fmtDate(C('refunds_by'), 'md') : less > 0 ? ' · ' + $(less) + ' less to pay' : ''));
    };
    sheet.onchange = show;
    sheet.onclick = e => { const b = e.target.closest('[data-act="leavewho"]'); if (!b) return; if (pick.has(b.dataset.pid)) pick.delete(b.dataset.pid); else pick.add(b.dataset.pid); b.setAttribute('aria-pressed', pick.has(b.dataset.pid)); show(); };
    show();
  }
  // Leave a shift through the volunteer page's own route (the head is told, a waiting person offered
  // the place); confirmed first. The one Leave sheet (SU.leaveSheet; after the fourth critic, Oct 15: this
  // one had a red button, other pills, and Find replacement with three people chosen): the same as the
  // volunteer page's and the emailed link's. With several on it, a toggle a person, everyone on at first;
  // who goes is always said ("Walter leaves"); Leave shift is the one filled button; Find replacement only
  // for one person's one place (the place stays theirs, marked Swap open, and the link is copied); Keep
  // shift. The toast has Undo for two minutes.
  function leaveShiftSheet(id) {
    const g = shiftGroups().find(x => x.sh.id === id);
    if (!g) return;
    const sh = g.sh, us = g.us, pick = new Set(us.map(u => String(u._rid)));
    let busy = false, err = '';
    const goers = () => us.filter(u => pick.has(String(u._rid)));
    const leavesWords = () => goers().length ? namesOn(goers()) + (goers().length === 1 ? ' leaves' : ' leave') : 'Choose who’s leaving';
    const drawLv = focusSel => {
      const gs = goers();
      sheet.innerHTML = '<div class="wk-sheet__in reg-lv"><button type="button" class="wk-sheet__x" data-close aria-label="Close">' + I.x + '</button>' +
        SU.leaveSheet({ scope: 'reg', id: 'reg-sheet', hTag: 'h2', heading: 'Leave this shift?', when: sh.role + ' · ' + shDay(sh) + ' · ' + shiftTime(sh),
          people: us.length > 1 ? us.map(u => ({ value: String(u._rid), label: first(u.name), on: pick.has(String(u._rid)) })) : [],
          // Said only when a Leave now reaches the head (the volunteer page's own answer, GET vol/{y}:
          // tells; after the eighth critic, Oct 16). Not known yet: as before.
          goes: leavesWords(), head: tellsHead(gs) ? 'The ' + sh.committee + ' foreman is told' : false, swap: gs.length === 1 && !gs[0].swap, busy, disabled: !gs.length, err }) + '</div>';
      // The one sheet's heading is the dialog's name.
      const hd = sheet.querySelector('.ogc-lv__h');
      if (hd) hd.id = 'reg-sheet-t';
      const f = focusSel && sheet.querySelector(focusSel);
      if (f) f.focus();
    };
    const go = () => {
      const ids = goers().map(u => u._rid);
      if (!ids.length || busy) return;
      busy = true; err = ''; drawLv();
      api('POST', 'vol/' + state.year + '/leave', { ids }).then(out => {
        if (!out.left || !out.left.length) throw new Error('Not left');
        state.volP = null;
        const gone = us.filter(u => out.left.map(String).indexOf(String(u._rid)) > -1);
        // Said where it can be seen (not only to a screen reader): "Left shift · Server · Sat, May 29 ·
        // Edna" (yourself alone on it isn't named). Undo for two minutes, as the volunteer page's.
        const left = gone.map(u => u._rid);
        sheet.close();
        return O.records.load(state.year, ['signups'], true).then(() => { draw(); toast('Left shift', [sh.role, shDay(sh), namedOn(us) ? namesOn(gone) : ''].filter(Boolean).join(' · '), () => unleaveShift(left, sh, us, gone)); });
      }).catch(x => { busy = false; err = x && x.data && x.data.why === 'started' ? 'Started · Call the foreman' : sheetErr(x); drawLv('[data-lv="go"]'); tell(err); });
    };
    // Find replacement: the place stays theirs, marked Swap open; the link to it is shared or copied.
    const swapIt = () => {
      const gs = goers();
      if (gs.length !== 1 || busy) return;
      busy = true; drawLv();
      api('POST', 'vol/' + state.year + '/swap', { id: gs[0]._rid, on: true }).then(out => {
        sheet.close();
        const url = location.origin + (W.base || '/annual-conference/') + 'volunteer/?year=' + state.year + '&shift=' + encodeURIComponent(sh.id) + '&swap=' + encodeURIComponent(out.swap || '');
        const text = 'Could you take my place? ' + sh.role + ', ' + shDay(sh) + ' · ' + shiftTime(sh);
        const done = () => O.records.load(state.year, ['signups'], true).then(() => { draw(); toast('Swap open', 'Link copied · ' + first(gs[0].name) + '’s place stays until someone takes it'); });
        if (navigator.share && /Mobi|Android/i.test(navigator.userAgent)) { navigator.share({ text, url }).catch(() => {}); return done(); }
        return (navigator.clipboard ? navigator.clipboard.writeText(url) : Promise.reject()).then(done, () => O.records.load(state.year, ['signups'], true).then(() => { draw(); toast('Swap open', url); }));
      }).catch(x => { busy = false; err = sheetErr(x); drawLv('[data-lv="swap"]'); tell(err); });
    };
    sheet.onclick = e => {
      const b = e.target.closest('[data-lv]');
      if (!b) return;
      if (b.dataset.lv === 'go') go();
      else if (b.dataset.lv === 'swap') swapIt();
      else if (b.dataset.lv === 'keep') sheet.close();
    };
    sheet.onchange = e => {
      const t = e.target;
      if (!t.matches('[name=lvwho]')) return;
      if (t.checked) pick.add(t.value); else pick.delete(t.value);
      err = ''; drawLv('[name=lvwho][value="' + CSS.escape(t.value) + '"]');
    };
    drawLv();
    sheet.showModal();
    const f = sheet.querySelector('[data-lv="go"]');
    if (f) f.focus();
  }

  // Undo a Leave: the same places again, if they're still free (the volunteer page's own route).
  const UNLEAVE_NO = { full: 'Place taken · Sign up again', busy: 'Busy then · Not undone', dup: 'Already signed up', started: 'Started', late: 'Too late · Sign up again' };
  function unleaveShift(ids, sh, us, gone) {
    api('POST', 'vol/' + state.year + '/unleave', { ids }).then(out => {
      if (!out.back || !out.back.length) { const w = (out.no || [])[0]; toast((w && UNLEAVE_NO[w.why]) || 'Not undone'); return; }
      state.volP = null;
      return O.records.load(state.year, ['signups'], true).then(() => { draw(); toast('Undone', [sh.role, shDay(sh), namedOn(us) ? namesOn(gone) : ''].filter(Boolean).join(' · ')); });
    }, () => toast('Not undone · Retry'));
  }

  // Sign in on Your sign-ups: a code and a link by email.
  function signinSend(again) {
    const si = state.signin, email = (again ? si.email : (root.querySelector('[name="signin.email"]') || {}).value || si.email).trim();
    if (!emailOk(email)) { si.err = 'Enter an email like name@example.com'; draw(); return; }
    si.email = email; state.busy = true; draw();
    // The site's own sign-in (the signin area: a link and a code, mail only to an address it knows);
    // the form's code route where that isn't installed.
    const back = location.pathname + '?year=' + state.year + '&view=mine';
    const mask = e => e.replace(/^(.)[^@]*(@.*)$/, '$1•••$2');
    api('POST', 'auth/send', { email, return: back }).then(() => ({ to: mask(email), via: 'auth' })).then(out => {
      Object.assign(si, { step: 'sent', via: out.via, to: out.to, code: '', err: '', dev: out.dev_code || '', retryAt: Date.now() + (out.retry || 30) * 1000 });
      state.busy = false; draw(); focusSoon('[name="signin.code"]'); tell('Link sent to ' + out.to);
      setTimeout(draw, 30500);
    }, x => { state.busy = false; si.err = x.message || 'Not sent · Try again'; draw(); });
  }
  function signinCode() {
    const si = state.signin;
    if (state.busy) return;
    if (si.code.length !== 6) { si.err = 'Enter the 6 digits'; draw(); return; }
    state.busy = true; draw();
    api('POST', 'auth/code', { code: si.code }).then(() => location.reload(), x => { state.busy = false; si.err = x.message || 'Code not valid'; si.code = ''; draw(); });
  }
  function decide(v) {
    const send = () => api('POST', 'reg/approve/' + encodeURIComponent(approveToken()), { decision: v }).then(A => { state.approve = A; state.approveErr = ''; draw(); tell(v === 'approve' ? 'Approved' : 'Declined'); });
    if (v === 'approve') return send().catch(x => { state.approveErr = sheetErr(x); draw(); tell(state.approveErr); });
    const A = state.approve, D = A.decline || {}, names = (D.names && D.names.length ? D.names : [first(A.who[0].name)]).join(' and ');
    openSheet('Decline', '<ul class="rf-sheetlist">' + (D.whole ? '<li>' + esc(names + '’s registration is cancelled') + '</li>' : '<li>' + esc(names + ' comes off the registration') + '</li>') + (D.refund ? '<li>' + escn('Refund requested · ' + $(D.refund)) + '</li>' : '') + '</ul>', send, 'Decline', true, 'Cancel');
  }
  function testPay(outcome) {
    api('POST', 'pay/test/' + q.get('checkout') + '?t=' + encodeURIComponent(q.get('t') || ''), { outcome }).then(out => {
      // Back where the provider would send them: Registered for a new registration, else Your sign-ups.
      location.href = here('year=' + out.year + (q.get('then') === 'done' ? '&view=done&id=' + out.record : '&view=mine') + '&paid=' + out.id);
    }, x => tell(x.message || 'Not done'));
  }

  // The volunteer page's own answer (GET vol/{y}), asked once: the waitlists, the places still to
  // confirm, whether a Leave reaches the head.
  const volInfo = () => state.volP || (state.volP = api('GET', 'vol/' + state.year).catch(() => { state.volP = null; return null; }));
  // One calendar file: the household's days, and every shift this email has, once each. Served by the
  // site at a real address (after the eighth critic, Oct 16: made in the browser, a phone kept it as a
  // download; iOS Safari offers "Add to Calendar" only for a file a site serves): GET vol/{y}/ics with
  // reg (the registration's days, r: one of them) and s (the shifts), the same events as before and as
  // every email's file. Signed in, WordPress's nonce says who asks; nothing personal is in the address.
  const icsHref = id => {
    const ids = shiftGroups().map(g => g.sh.id), n = W.me && W.nonce ? W.nonce : '';
    return (W.rest || '/wp-json/ogc/v1/') + 'vol/' + encodeURIComponent(state.year) + '/ics?reg=1' + (id ? '&r=' + encodeURIComponent(id) : '') + (ids.length ? '&s=' + encodeURIComponent(ids.join(',')) : '') + (n ? '&_wpnonce=' + encodeURIComponent(n) : '');
  };

  /* ================================================================ the bar steps aside for the keyboard */

  // The phone's keyboard is up when the visible part of the page is much shorter than the window.
  const vv = window.visualViewport;
  if (vv) vv.addEventListener('resize', () => { document.body.classList.toggle('reg-typing', window.innerHeight - vv.height > 150 && /^(INPUT|TEXTAREA)$/.test((document.activeElement || {}).tagName || '')); });

  // Local only: the page's rules, for the parity check against the server (tools: the register CHANGES).
  if (W.dev) window.OGC_REG_TEST = { priceOf: d => priceOf(settle(d)), settle, blank, person, state };

  /* ================================================================ boot */

  (async function boot() {
    try {
      // The first answers come inlined with the page (OGC_WP.preload: the form and this person's
      // registrations; the store takes the years, files and records), so the first draw waits for no
      // request. Without them (an old cached page), the requests run side by side.
      const P0 = W.preload && Date.now() / 1000 - (W.preload.at || 0) < 600 ? W.preload : null;
      const signed0 = !!(W.me && W.me.email);
      const formP = P0 && P0.form ? Promise.resolve(P0.form).then(F => { state.F = F; state.cfg = F.cfg || {}; return F; }) : null;
      // Your sign-ups is asked for only once its year is known (after the sixth critic, Oct 15: with no
      // ?year= it asked for reg//mine and said "Couldn't load"): the address's, else the one this person
      // is on (OGC_WP.mine carries it; the server also redirects a signed-in visit to it).
      if (!state.year && W.mine) { const my = /[?&]year=(\d{4})/.exec(W.mine); if (my) state.year = my[1]; }
      const mineP = P0 && P0.mine ? Promise.resolve(P0.mine).then(out => { state.mine = out.items; state.mineErr = ''; }) : signed0 && state.year && ['mine', 'edit', 'done', 'receipt'].indexOf(q.get('view') || 'form') > -1 ? loadMine() : null;
      if (O.ready) await O.ready;
      const years = O.csvToObjects(await (await fetch(BASE + 'years.csv', { cache: 'no-store' })).text()).filter(y => y.year).sort((a, b) => b.year - a.year);
      state.row = years.find(y => y.year === state.year) || years.find(y => y.data) || years[0];
      state.year = state.row.year;
      if (q.get('approve')) state.view = 'approve';
      if (q.get('checkout')) state.view = 'checkout';
      const tasks = [formP || loadForm()].concat(mineP ? [mineP] : []);
      if (state.row.data) {
        const folder = BASE + state.row.data + '/';
        tasks.push(O.loadSchedule(folder).then(m => { state.model = m; }));
        tasks.push(Promise.all(['shifts', 'rooms', 'plans', 'campus'].map(f => fetch(folder + f + '.csv', { cache: 'no-store' }).then(r => r.ok ? r.text() : ''))).then(([sh, rooms, plans, campus]) => {
          state.shiftRows = O.csvToObjects(sh);
          Object.assign(state, SU.readRooms(O.csvToObjects(rooms)));
          if (O.map) { state.plans = O.map.plans(O.csvToObjects(plans)); O.map.orderFloors(state.floors, state.plans); const c = O.map.campus(O.csvToObjects(campus)); state.campus = c.items.length ? c : null; }
        }));
      }
      // A past year's page points to the next one: its registration, open or when it opens.
      const nextRow = years.find(y => +y.year === +state.year + 1);
      if (state.view === 'form' && nextRow && state.row.end && state.row.end < O.wallNow('America/Indiana/Indianapolis').date) tasks.push(api('GET', 'reg/' + nextRow.year + '/form').then(N => { state.nextF = N; }, () => null));
      if (state.view === 'approve') tasks.push(api('GET', 'reg/approve/' + encodeURIComponent(approveToken())).then(A => { state.approve = A; }, () => { state.approve = null; }));
      if (state.view === 'checkout') tasks.push(api('GET', 'pay/test/' + q.get('checkout') + '?t=' + encodeURIComponent(q.get('t') || '')).then(P => { state.checkout = P; }, () => { state.checkout = null; }));
      await Promise.all(tasks);
      // The days and meals come from the server (the schedule itself may not be posted yet).
      state.days = (state.F.days || []).map(x => ({ name: x.name, date: x.date }));
      state.meals = (state.F.meals || []).map(m => ({ id: m.key, day: { date: m.date }, title: m.title }));
      if (state.model) state.shifts = SU.expandShifts(state.shiftRows || [], state.model);
      const me = SU.me(), signed = me && !me.pending;
      if (['mine', 'edit', 'done', 'receipt'].indexOf(state.view) > -1 && signed && !mineP) await loadMine();
      if (state.view === 'mine' || state.view === 'done') {
        if (state.view === 'mine') try { const f = JSON.parse(sessionStorage.getItem('ogc-reg-flash')); if (f) { state.flash = f; sessionStorage.removeItem('ogc-reg-flash'); } } catch (x) { /* none */ }
        const paid = q.get('paid');
        if (paid) {
          const it = (state.mine || []).find(x => (x.ledger || []).some(p => String(p.id) === paid)), p = it && it.ledger.find(x => String(x.id) === paid);
          if (p) state.payNote = p.status === 'paid' ? { text: 'Paid ' + $(p.cents) } : p.status === 'failed' ? { text: 'Card declined', bad: true, retry: it.id, check: true } : { text: 'Payment cancelled · ' + $(p.cents) + ' due', bad: true, retry: it.id, check: true };
          const u = new URL(location.href); u.searchParams.delete('paid'); history.replaceState(null, '', u);
        }
      }
      if (state.view === 'done') state.done = (state.mine || []).find(x => String(x.id) === q.get('id')) || null;
      // Opened from the app for a household (Round 5; area-households-money 6): where Save and Back go.
      state.ret = safeReturn(q.get('return'));
      state.how = ['phone', 'paper', 'desk'].indexOf(q.get('how')) > -1 ? q.get('how') : 'phone';
      if (state.view === 'edit') {
        let it = (state.mine || []).find(x => String(x.id) === q.get('id'));
        // Change for a household: a member (the COA, Lodging) opens a registration that isn't their own.
        // The server decides who may (GET reg/r/{id}: 404 for anyone else).
        if (!it && q.get('id') && state.F.member) it = await api('GET', withQ('reg/r/' + encodeURIComponent(q.get('id')))).then(out => out.item, () => null);
        if (it && state.F.member && !(state.mine || []).some(x => x.id === it.id)) state.forHh = true;
        if (!it || !it.can.change) { state.view = state.ret ? 'gone' : 'mine'; }
        else { state.editing = it; state.d = answersOf(it.data); state.d.pay = it.data.pay || payChoices()[0][0];
          // Past check_by a check isn't offered for what's owed: the late way (at check-in, or card).
          if (state.d.pay === 'check' && state.F.late) state.d.pay = payChoices()[0][0];
          // The marks compare with what's saved. A change lands on Review: every step said once, each with
          // Change (Oct 23).
          settle(); state.d.was = wasSnap(state.d); state.step = 'review'; }
      }
      if (state.view === 'form') {
        if (q.get('another')) state.another = true;
        // The desk (a member): the same form for a household at check-in, by phone or on paper.
        state.desk = !!(state.F.member && q.get('desk') === '1');
        // New household from the app (a call, a letter, the desk): one household, then back to it.
        state.forHh = state.desk && !!state.ret;
        if (state.desk && !state.ret) await loadDesk();
        sweepDrafts();
        state.d = loadDraft() || (state.desk ? null : serverDraft()) || fresh();
        // Signed in already: the draft is this person's (and is kept for them on the server).
        if (!state.desk && signedNow() && !state.d.owner) state.d.owner = SU.me().email;
        // At the desk they pay there; by phone or on paper, a check by mail, or at check-in once checks close.
        if (state.desk) state.d.pay = state.how === 'desk' || !state.forHh || state.F.late ? 'checkin' : 'check';
        else if (!payOk(state.d.pay)) state.d.pay = payChoices()[0][0];
        settle();
        // A returning household lands on last year's registration, filled in (Michael, Oct 13). Signed in,
        // the steps open at Who's coming (or Contact while something's missing there), or where this tab
        // left off; the desk starts at Contact.
        maybeReuse(false);
        let was = '';
        try { was = sessionStorage.getItem(STEP_KEY()) || ''; } catch (x) { /* none kept */ }
        state.step = state.desk || !verified() ? 'contact' : was && was !== 'contact' && order().indexOf(was) > -1 && reachable(was) ? was : landStep();
      }
      document.title = state.forHh ? (state.editing ? 'Change · ' + regName(state.editing.data) : 'New household') : { mine: 'Your sign-ups', edit: 'Change registration', done: 'Registered', receipt: 'Receipt', approve: 'Approval', checkout: 'Checkout', gone: 'Not found' }[state.view] || 'Register';
      document.title += ' – ' + state.year + ' Annual Conference';
      draw();
      // The shifts' calendar UIDs, asked ahead so Add to Calendar is one tap; and the waitlists.
      if ((state.view === 'mine' || state.view === 'done') && SU.me() && !SU.me().pending) volInfo().then(v => { if (v) { state.vol = v; if ((v.waits || []).length || (v.pending || []).length) draw(); } });
    } catch (x) {
      console.error(x);
      state.view = 'error';
      try { draw(); } catch (y) { root.textContent = 'Couldn’t load'; }
    }
  })();
})();
