/*
 * register.js — registering for the Annual Conference, and Your sign-ups (register area, Oct 10).
 *
 * Views, by address:
 *   ?year=2027                 the form: one page of sections that fold to a summary once done, so the
 *                              form is its own review; a bar at the bottom with the total and the one
 *                              next action. It follows who's coming (never a separate Young Folk path).
 *   ?view=mine                 Your sign-ups: every registration this email owns or manages, shifts,
 *                              teams, one calendar file. Sign in by a code or link sent by email.
 *   ?view=edit&id=…            Change a registration (pay only the difference, or a refund).
 *   ?view=done&id=…            Registered: the receipt.
 *   ?view=receipt&id=…         A receipt to print.
 *   ?approve=…                 A parent approving a Young Folk under 18 (alone, or when the grown-up
 *                              registering isn't the parent and chose "Ask a parent").
 *   ?checkout=…&t=…            (local only) the payment provider's checkout, stood in for.
 *
 * The server judges everything (includes/module-registration*.php): what's allowed, the price, what's
 * left, who may see what. This page mirrors its rules (settle, problems, priceOf) only so answers and
 * totals follow each tap; what is saved and charged is what the server works out.
 *
 * One update path (Michael, Oct 9: the people part was "really glitchy"): every change runs settle(),
 * then the whole view is drawn again as text and morphed into the page: only what changed is touched,
 * so the field being typed in keeps its focus, its keyboard and its place.
 */
(function () {
  'use strict';
  const O = window.OGC, esc = O.esc, SU = O.signups, W = window.OGC_WP || {};
  const root = document.getElementById('ogc-reg');
  const BASE = root.dataset.base;
  const q = new URLSearchParams(location.search);
  const reduced = () => window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const svg = d => '<svg class="wk-i" viewBox="0 0 24 24" aria-hidden="true"><path d="' + d + '" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  const I = {
    cal: svg('M7.5 3.5v3M16.5 3.5v3M4 9.5h16M5.5 5.5h13A1.5 1.5 0 0 1 20 7v11.5a1.5 1.5 0 0 1-1.5 1.5h-13A1.5 1.5 0 0 1 4 18.5V7a1.5 1.5 0 0 1 1.5-1.5Z'),
    pin: svg('M12 20.5s-6.5-5.4-6.5-10.8a6.5 6.5 0 0 1 13 0c0 5.4-6.5 10.8-6.5 10.8ZM12 12a2.3 2.3 0 1 0 0-4.6 2.3 2.3 0 0 0 0 4.6Z'),
    check: svg('m5.5 12.5 4 4 9-9'),
    clock: svg('M12 7.5V12l3 2M12 20.5a8.5 8.5 0 1 0 0-17 8.5 8.5 0 0 0 0 17Z'),
    plus: svg('M12 5v14M5 12h14'),
    minus: svg('M5 12h14'),
    x: svg('m6.5 6.5 11 11M17.5 6.5l-11 11'),
    lock: svg('M6.5 11h11v9h-11zM8.5 11V8a3.5 3.5 0 0 1 7 0v3'),
    mail: svg('M4 6.5h16v11H4zM4.5 7l7.5 6 7.5-6'),
    key: svg('M14.5 9.5a3.5 3.5 0 1 1-1-2.45M13.4 12.6 20 19.2M17.5 16.7l1.8-1.8M15.6 14.8l1.4-1.4'),
    bed: svg('M3.5 18.5v-11M3.5 14.5h17v4M20.5 14.5v-2a3 3 0 0 0-3-3h-7v5M7 12a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3Z'),
    hand: svg('M8 11V5.5a1.5 1.5 0 0 1 3 0V11M11 10V4.5a1.5 1.5 0 0 1 3 0V11M14 10.5V6a1.5 1.5 0 0 1 3 0v7.5a6 6 0 0 1-6 6h-.6a6 6 0 0 1-4.6-2.2L3.6 14.6a1.5 1.5 0 0 1 2.2-2L8 14.5V11'),
    trophy: svg('M8 4.5h8v5a4 4 0 0 1-8 0zM8 6.5H4.5v1a3 3 0 0 0 3.5 3M16 6.5h3.5v1a3 3 0 0 1-3.5 3M12 13.5v3M8.5 19.5h7M9.5 19.5l.5-3h4l.5 3'),
    info: svg('M12 20.5a8.5 8.5 0 1 0 0-17 8.5 8.5 0 0 0 0 17ZM12 11v5M12 8h.01'),
    card: svg('M3.5 6.5h17v11h-17zM3.5 10h17M7 14.5h4'),
    print: svg('M7 9V4h10v5M7 17H5a1.5 1.5 0 0 1-1.5-1.5v-5A1.5 1.5 0 0 1 5 9h14a1.5 1.5 0 0 1 1.5 1.5v5A1.5 1.5 0 0 1 19 17h-2M7 14h10v6H7z'),
    copy: svg('M9 9h10v11H9zM5 15V4h10'),
    people: svg('M4 20v-1.5A4.5 4.5 0 0 1 8.5 14h3a4.5 4.5 0 0 1 4.5 4.5V20M10 11a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7ZM16.5 4.3a3.5 3.5 0 0 1 0 6.4M18.5 14.2a4.5 4.5 0 0 1 2 3.8v2')
  };
  const say = document.createElement('p');
  say.className = 'ogc-sr';
  say.setAttribute('aria-live', 'polite');
  root.after(say);
  const tell = t => { say.textContent = ''; setTimeout(() => { say.textContent = t; }, 30); };

  const state = {
    year: q.get('year') || '', view: q.get('view') || 'form', asOf: (q.get('as-of') || '').slice(0, 10),
    row: null, model: null, F: null, cfg: {}, meals: [], shifts: [], days: [],
    floors: [], rooms: [], plans: {}, campus: null, mp: null,
    d: null, open: '', errors: {}, check: {}, ui: {}, editing: null, waitlist: false,
    verify: { step: '', email: '', code: '', to: '', err: '', busy: false, dev: '', retryAt: 0 },
    busy: false, barNote: '', undo: null, mine: null, mineErr: '', another: false, signin: { step: '', email: '', to: '', code: '', err: '', dev: '', retryAt: 0 }
  };

  /* ================================================================ talking to the server */

  const asOfQ = () => state.asOf ? 'as_of=' + encodeURIComponent(state.asOf) : '';
  const withQ = (path, extra) => { const p = [asOfQ(), extra || ''].filter(Boolean).join('&'); return path + (p ? (path.indexOf('?') > -1 ? '&' : '?') + p : ''); };
  const api = (m, p, b) => W.api(m, p, b);
  // Local walk-through only: the page's own addresses keep ?as-of (the date being previewed), so Register
  // another or Change doesn't land back on today. here() is for script navigation; links are fixed in draw().
  const devAsOf = () => !!(W.dev && state.asOf);
  const here = qs => '?' + qs + (devAsOf() && !/(^|&)as-of=/.test(qs) ? '&as-of=' + encodeURIComponent(state.asOf) : '');
  const keepAsOf = () => {
    if (!devAsOf()) return;
    root.querySelectorAll('a[href^="?"], a[href^="../volunteer/"], a[href^="../tournaments/"]').forEach(a => { const h = a.getAttribute('href'); if (!/[?&]as-of=/.test(h)) a.setAttribute('href', h + (h.indexOf('?') > -1 ? '&' : '?') + 'as-of=' + encodeURIComponent(state.asOf)); });
  };
  const idem = () => 'k' + Date.now().toString(36) + Math.random().toString(36).slice(2, 10);
  const loadForm = () => api('GET', withQ('reg/' + state.year + '/form')).then(F => { state.F = F; state.cfg = F.cfg || {}; return F; });
  // Signed in on this device (a code or a link): the page carries on with the new nonce.
  const signedIn = out => { W.nonce = out.nonce; W.me = out.me; };

  /* ================================================================ the draft */

  // A draft belongs to one person: its key names the signed-in email (a short hash), or "anon" before
  // anyone has confirmed one. Signing in as someone else in the same tab never shows the last person's
  // household (polish 1: the Hoovers' children appeared for the next person to sign in).
  const hashOf = t => { let h = 2166136261; for (let i = 0; i < t.length; i++) { h ^= t.charCodeAt(i); h = Math.imul(h, 16777619); } return (h >>> 0).toString(36); };
  const meKey = () => { const me = SU.me(); return me && !me.pending ? hashOf(String(me.email).toLowerCase()) : 'anon'; };
  const KEY = () => 'ogc-register-draft-' + state.year + (state.desk ? '-desk' : '') + '-' + meKey();
  // On load: drop every draft of this year that isn't this person's (a sign-in elsewhere in this tab).
  // An anonymous draft is carried into a sign-in only when it holds nothing from last year (no Reuse).
  function sweepDrafts() {
    try {
      const pre = 'ogc-register-draft-' + state.year, mine = KEY(), anon = pre + (state.desk ? '-desk' : '') + '-anon';
      if (mine !== anon && !sessionStorage.getItem(mine)) { const a = JSON.parse(sessionStorage.getItem(anon) || 'null'); if (a && !a.from && !a.owner) sessionStorage.setItem(mine, JSON.stringify(a)); }
      for (let i = sessionStorage.length - 1; i >= 0; i--) { const k = sessionStorage.key(i); if (k && k.indexOf(pre) === 0 && k !== mine) sessionStorage.removeItem(k); }
    } catch (e) { /* nothing kept */ }
  }
  const newPid = () => 'p' + Math.random().toString(36).slice(2, 10);
  // linens: a Young Folk in a hall orders their own packet (the server keeps it). lin: a packet for this
  // sleeper in the household's rooms (page only; sent as stay.linenFor). Both null until the household's
  // one linens choice says (polish 2: linens asked once, not once a person). roomSet: the room was chosen
  // by hand (else the rooms are balanced as people are added), page only.
  const person = o => Object.assign({ pid: newPid(), name: '', kind: 'adult', age: '', band: 'adult', yf: false, yfHall: '', minor: false, ptOff: false, preteen: false, nights: [], rooming: '', sleeps: 'hall', linens: null, lin: null, communing: false, room: null, roomSet: false }, o || {});
  const blank = () => ({
    household: { name: '', contact: '', phone: '', email: '' },
    helper: { on: false, name: '', phone: '', email: '' },
    people: [],
    stay: { withHh: '', type: '', nights: [], days: [], perPerson: false, rooms: 1, roomsSet: false, linens: 0, linenChoice: '', linenFor: [], mattresses: 0, ground: false, walker: false, nearW: false, nearM: false, near: '', arrive: '', yfOk: false, ask: false, keys: [], needs: '', parentEmail: '', chosen: [], campers: 1, camperLen: '' },
    meals: { off: {}, who: {} },
    preteens: {}, contacts: [{ name: '', rel: '', phone: '' }, { name: '', rel: '', phone: '' }], pickupWho: [], pickupOther: '',
    gift: 0, pay: 'card', finished: []
  });
  function fresh() {
    const d = blank(), me = SU.me();
    if (me && !me.pending && !state.desk) Object.assign(d.household, { contact: me.name || '', email: me.email });
    // Nothing that costs money is chosen for them: the stay (and then its nights) waits for a choice.
    d.pay = state.desk ? 'checkin' : payChoices()[0][0];
    d.finished = ['meals'];   // every meal while here, until someone says otherwise (drawn as to come until stay is done)
    return d;
  }
  // How a household may pay today: Card (when a provider is set up) and Check until check_by; after that
  // the COA's late choice (late_pay): At check-in, or card only.
  function payChoices() {
    const F = state.F, o = [];
    if (F.card) o.push(['card', 'Card']);
    if (!F.late) o.push(['check', 'Check']);
    else if (F.latePay !== 'card' || !F.card) o.push(['checkin', 'At check-in']);
    return o;
  }
  const payOk = v => payChoices().some(o => o[0] === v);
  // A draft is kept in this tab (sessionStorage), and once the email is confirmed also on the server as
  // the person's own (reg/{y}/draft; polish 3: a grandmother who left Safari to read the code, or closed
  // the tab, typed everything again). Before it's confirmed, nothing leaves this tab.
  const signedNow = () => { const me = SU.me(); return !!(me && !me.pending); };
  const serverKeeps = () => signedNow() && !state.desk && !state.editing && state.view === 'form' && !!state.d && !!state.d.owner;
  function keep() {
    try { if (state.d && !state.editing) sessionStorage.setItem(KEY(), JSON.stringify(state.d)); } catch (e) { /* not kept */ }
    if (!serverKeeps()) return;
    clearTimeout(state.draftT);
    state.draftT = setTimeout(sendDraft, 1200);
  }
  function sendDraft(leaving) {
    clearTimeout(state.draftT);
    if (!serverKeeps()) return;
    const body = JSON.stringify({ data: state.d });
    if (body === state.draftSent) return;
    state.draftSent = body;
    const url = (W.rest || '/wp-json/ogc/v1/') + 'reg/' + state.year + '/draft';
    // keepalive: still sent while the tab closes or the phone switches to Mail.
    try { fetch(url, { method: 'PUT', credentials: 'same-origin', keepalive: !!leaving && body.length < 60000, headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': W.nonce || '' }, body }).catch(() => { state.draftSent = ''; }); } catch (e) { state.draftSent = ''; }
  }
  document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'hidden') sendDraft(true); });
  window.addEventListener('pagehide', () => sendDraft(true));
  function loadDraft() {
    try {
      const d = JSON.parse(sessionStorage.getItem(KEY())), me = SU.me();
      // A draft whose owner isn't the person signed in now is never shown.
      if (d && d.owner && !(me && !me.pending && SU.sameEmail(d.owner, me.email))) { dropDraft(); return null; }
      return d && d.people ? Object.assign(blank(), d, { stay: Object.assign(blank().stay, d.stay) }) : null;
    } catch (e) { return null; }
  }
  function dropDraft(server) {
    try { sessionStorage.removeItem(KEY()); } catch (e) { /* nothing kept */ }
    // Start over also clears the one kept for this person (registering clears it on the server's side).
    if (server && signedNow() && !state.desk) { clearTimeout(state.draftT); state.draftSent = ''; api('DELETE', 'reg/' + state.year + '/draft').catch(() => {}); }
  }
  // The draft kept for this person on the server (inlined with the page), when this tab has none.
  function serverDraft() {
    const P0 = W.preload && W.preload.draft, d = P0 && P0.data, me = SU.me();
    if (!d || !d.people || !me || me.pending || !d.owner || !SU.sameEmail(d.owner, me.email)) return null;
    state.draftSent = JSON.stringify({ data: d });
    return Object.assign(blank(), d, { stay: Object.assign(blank().stay, d.stay) });
  }
  // The answers a registration keeps (what the server cleans), from a saved one. reuse: last year's,
  // whose rooms are balanced again (a hand choice is only one made this year).
  const answersOf = (data, reuse) => {
    const d = JSON.parse(JSON.stringify(data)), b = blank();
    ['household', 'helper', 'people', 'meals', 'preteens', 'contacts', 'pickupWho', 'pickupOther', 'gift', 'pay'].forEach(k => { if (d[k] == null) d[k] = b[k]; });
    d.stay = Object.assign(b.stay, d.stay || {});
    d.meals = { off: Object.assign({}, d.meals.off), who: Object.assign({}, d.meals.who) };
    if (!Array.isArray(d.contacts) || d.contacts.length < 2) d.contacts = b.contacts.map((c, i) => Object.assign(c, (d.contacts || [])[i] || {}));
    if (Array.isArray(d.preteens)) d.preteens = {};
    // A saved (or last year's) registration has made these choices already: who has a packet in the
    // rooms (linenFor, or the first so many sleepers for one saved before it was kept by name).
    const s = d.stay, sl = (d.people || []).filter(p => String(p.name || '').trim() && p.band !== 'baby' && !(p.yf && (s.type === 'yf' || p.sleeps !== 'family')));
    const forSet = new Set(Array.isArray(s.linenFor) && s.linenFor.length ? s.linenFor : s.type === 'dorm' ? sl.slice(0, +s.linens || 0).map(p => p.pid) : []);
    (d.people || []).forEach(p => {
      p.roomSet = !reuse && p.room != null;
      p.lin = s.linenChoice ? forSet.has(p.pid) : null;
      if (p.yf && s.linenChoice) p.linens = !!p.linens;
    });
    return d;
  };

  /* ================================================================ rules (mirroring the server's) */

  const C = k => state.cfg[k] || '';
  const cents = k => { const v = state.cfg[k]; return v !== undefined && v !== '' && !isNaN(+v) ? Math.round(+v * 100) : 0; };
  const $ = c => (c < 0 ? '−' : '') + SU.money(Math.abs(c) / 100);
  const plural = SU.plural;
  const first = n => String(n || '').trim().split(/\s+/)[0] || '';
  const firstL = n => SU.firstL(n);
  const nights = () => SU.nightsOf(state.cfg);
  const mainNights = () => SU.mainNights(state.cfg);
  const early = SU.isEarly;
  const named = () => state.d.people.filter(p => p.name.trim());
  const adults = () => named().filter(p => p.kind === 'adult');
  const yfs = () => named().filter(p => p.yf);
  const yfOnly = () => named().length > 0 && named().every(p => p.yf);
  const inHall = (p, d) => p.yf && ((d || state.d).stay.type === 'yf' || p.sleeps !== 'family');
  const minorsAlone = () => !adults().length && named().some(p => p.minor);
  const beds = () => (+C('room_beds') || 2) + 1;
  const sleepers = d => (d || state.d).people.filter(p => p.name.trim() && p.band !== 'baby' && !inHall(p, d));
  const emailOk = e => /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(String(e || '').trim());
  const ptDays = () => C('preteen_days').split('|').map(s => s.trim()).filter(Boolean);
  const preteensOnline = () => C('preteen_details') !== 'paper';
  const dayIndex = n => { const k = String(n).slice(0, 3).toLowerCase(); return state.days.findIndex(d => d.name.slice(0, 3).toLowerCase() === k || d.date === n); };
  const nightDate = n => early(n) ? SU.earlyDate(n, (state.days[0] || {}).date) : ((state.days[dayIndex(n)] || {}).date || '');
  const nightsFor = (p, d) => (p.nights && p.nights.length) ? p.nights : (d.stay.nights && d.stay.nights.length) ? d.stay.nights : p.yf ? mainNights() : [];
  const shortDate = iso => iso ? O.fmtDate(iso, 'short').replace(',', '') : '';
  // "Fri May 28 – Wed Jun 2": the first night's day to the morning after the last.
  const spanOf = ns => { if (!ns.length) return ''; const a = nightDate(ns[0]), b = O.isoAddDays(nightDate(ns[ns.length - 1]), 1); return shortDate(a) + ' – ' + shortDate(b); };
  const hallWord = h => h === 'women' ? 'Young women’s hall' : 'Young men’s hall';

  // The parts that follow from the answers: age groups, preteens, who's under 18, nights, rooms, keys.
  function settle(d) {
    d = d || state.d;
    d.people.forEach(p => {
      if (!p.pid) p.pid = newPid();
      p.yf = p.kind === 'yf';
      if (p.kind === 'adult') p.age = '';
      const a = /^\d{1,3}$/.test(String(p.age).trim()) ? +p.age : -1, ptAge = p.kind === 'child' && a >= 10 && a <= 13;
      p.band = p.kind !== 'child' ? 'adult' : a < 0 ? 'child' : a < 3 ? 'baby' : a <= 11 ? 'child' : 'adult';
      if (!ptAge) p.ptOff = false;
      p.preteen = ptAge && !p.ptOff;
      p.minor = p.yf && a >= 0 && a < 18;
      if (!p.yf) { p.yfHall = ''; p.rooming = ''; p.sleeps = 'hall'; p.linens = false; p.lc = ''; }
      if (p.kind === 'child') p.communing = false;
    });
    const s = d.stay, ppl = d.people.filter(p => p.name.trim()), only = ppl.length > 0 && ppl.every(p => p.yf);
    // Young Folks on their own: their hall, a camper or off campus; a family: a dorm room, a camper or off campus.
    // A family's stay is never chosen for them: the hall stay, once a grown-up is added, waits for a choice.
    if (only && s.type === 'dorm') s.type = 'yf'; else if (!only && s.type === 'yf') s.type = '';
    if (!s.type) d.finished = d.finished.filter(k => k !== 'stay');
    // A Young Folk alone sleeps in their hall unless the stay says a camper or off campus (polish 2: they
    // were "with family" until the stay was chosen, so Rooming with was never asked going forward).
    d.people.forEach(p => { if (p.yf && s.type === 'yf') p.sleeps = 'hall'; else if (p.yf && only) p.sleeps = s.type === 'camper' || s.type === 'elsewhere' ? 'family' : 'hall'; });
    // A parent's approval for Young Folks under 18 in the halls: "I'm the parent" (yfOk) or "Ask a parent" (ask).
    const hallMinors = ppl.some(p => p.minor && inHall(p, d)), grown = ppl.some(p => p.kind === 'adult');
    if (!(grown && hallMinors)) { s.yfOk = false; s.ask = false; }
    if (s.ask) s.yfOk = false;
    if (s.type === 'elsewhere') s.nights = []; else s.days = [];
    d.people.forEach(p => { if (!s.perPerson || (s.type === 'elsewhere' && !inHall(p, d))) p.nights = []; });
    if (s.perPerson && s.type !== 'elsewhere') {
      const set = new Set();
      ppl.forEach(p => { if (s.type === 'yf' || !inHall(p, d)) p.nights.forEach(n => set.add(n)); });
      if (set.size) s.nights = nights().filter(n => set.has(n));
    }
    const sl = sleepers(d);
    if (s.type === 'dorm') {
      if (!s.roomsSet) s.rooms = Math.max(1, Math.min(6, Math.ceil(sl.length / beds())));
      // Who sleeps where: balanced by default, grown-ups first, one to a room in turn, so no child is
      // put alone in a room while grown-ups share; a room chosen by hand stays as chosen.
      d.people.forEach(p => { if (!p.name.trim() || p.band === 'baby' || inHall(p, d)) { p.room = null; p.roomSet = false; } else if (p.roomSet && (p.room == null || p.room >= s.rooms)) p.roomSet = false; });
      const count = Array(s.rooms).fill(0);
      sl.forEach(p => { if (p.roomSet) count[p.room]++; });
      sl.filter(p => !p.roomSet).sort((a, b) => (a.kind === 'child') - (b.kind === 'child')).forEach(p => {
        let r = 0; for (let i = 1; i < s.rooms; i++) if (count[i] < count[r]) r = i;
        p.room = r; count[r]++;
      });
      const ok = ppl.filter(p => p.kind === 'adult').map(p => p.name.trim());
      s.keys = Array.from({ length: s.rooms }, (_, i) => ok.indexOf(s.keys[i]) > -1 ? s.keys[i] : ok.length ? ok[i % ok.length] : d.household.contact);
    } else d.people.forEach(p => { p.room = null; });
    // Linens, asked once for the household: bring our own, or packets for those chosen (each sleeper in
    // the rooms, each Young Folk in a hall), every one chosen to start. The count follows the choices.
    const roomSl = s.type === 'dorm' ? sl : [], hall = ppl.filter(p => inHall(p, d)), req = C('linens_required') === 'yes' && s.type === 'dorm';
    if (!roomSl.length && !hall.length) s.linenChoice = '';
    if (req && roomSl.length) s.linenChoice = 'order';
    d.people.forEach(p => {
      if (roomSl.indexOf(p) < 0) p.lin = null; else if (s.linenChoice === 'own') p.lin = false; else if (s.linenChoice === 'order' && (p.lin == null || req)) p.lin = true;
      if (hall.indexOf(p) < 0) p.linens = null; else if (s.linenChoice === 'own') p.linens = false; else if (s.linenChoice === 'order' && p.linens == null) p.linens = true;
    });
    s.linenFor = roomSl.filter(p => p.lin).map(p => p.pid);
    s.linens = s.linenFor.length;
    d.pickupWho = (d.pickupWho || []).filter(n => ppl.some(p => p.kind === 'adult' && p.name.trim() === n));
    if (!d.household.name && d.household.contact.trim()) d.household.name = d.household.contact.trim().split(/\s+/).pop();
    return d;
  }

  // The days a person is here, and so the meals they're counted for (as the server's ogc_reg_person_days).
  function personDays(p, d) {
    if (d.stay.type === 'elsewhere' && !inHall(p, d)) return state.days.filter(x => d.stay.days.indexOf(x.date) > -1).map(x => x.date);
    const all = nightsFor(p, d), main = all.filter(n => !early(n)), e = all.length > main.length;
    if (!main.length) return e && state.days.length ? [state.days[0].date] : [];
    const a = e ? 0 : dayIndex(main[0]), b = dayIndex(main[main.length - 1]);
    return a < 0 || b < 0 ? [] : state.days.slice(a, b + 2).map(x => x.date);
  }
  const mealDate = m => m.day.date;
  const eats = (p, m, d) => !d.meals.off[m.id] && personDays(p, d).indexOf(mealDate(m)) > -1 && (!d.meals.who[m.id] || d.meals.who[m.id].indexOf(p.pid) > -1);
  // The meals while anyone is here.
  const mealsHere = d => { d = d || state.d; const ppl = d.people.filter(p => p.name.trim()); const days = new Set(); ppl.forEach(p => personDays(p, d).forEach(x => days.add(x))); return state.meals.filter(m => days.has(mealDate(m))); };

  // What a household pays, line by line in cents (the server's ogc_reg_price, for display).
  function priceOf(d, cfgOver) {
    const save = state.cfg;
    if (cfgOver) state.cfg = Object.assign({}, state.cfg, cfgOver);
    try {
      const lines = [], s = d.stay, add = (key, label, c) => { if (c) lines.push({ key, label, cents: c }); };
      const ppl = d.people.filter(p => p.name.trim()), room = cents('room_price'), bedsN = Math.max(1, +C('room_beds') || 2);
      if (s.type === 'dorm' && s.nights.length) {
        if ((C('charge') || 'room') === 'person') {
          [['adult', 'Adults'], ['child', 'Children'], ['baby', 'Under 3']].forEach(([b, label]) => {
            const pr = cents('person_price_' + b), n = ppl.filter(p => p.band === b && !inHall(p, d)).reduce((k, p) => k + nightsFor(p, d).length, 0);
            add('person_' + b, label + ' · ' + plural(n, 'night') + ' × ' + $(pr), n * pr);
          });
        } else if (s.perPerson && s.rooms > 1) {
          for (let i = 0; i < s.rooms; i++) {
            const set = new Set();
            ppl.forEach(p => { if (p.room === i) nightsFor(p, d).forEach(n => set.add(n)); });
            const n = set.size || s.nights.length;
            add('room_' + i, 'Room ' + (i + 1) + ' · ' + plural(n, 'night') + ' × ' + $(room), n * room);
          }
        } else add('rooms', plural(s.rooms, 'dorm room') + ' · ' + plural(s.nights.length, 'night') + ' × ' + $(room), s.rooms * s.nights.length * room);
        if (s.mattresses) add('mattresses', plural(s.mattresses, 'air mattress', 'air mattresses') + ' × ' + $(cents('mattress_price')), s.mattresses * cents('mattress_price'));
      }
      const yfc = C('yf_charge') || 'share', per = yfc === 'person' ? cents('yf_price') : yfc === 'room' ? room : Math.round(room / bedsN);
      ppl.forEach(p => { if (inHall(p, d)) { const n = nightsFor(p, d).length; add('yf_' + p.pid, first(p.name) + ' · ' + hallWord(p.yfHall) + ' · ' + plural(n, 'night') + ' × ' + $(per), n * per); } });
      // Every packet on one line, the rooms' and each Young Folk's in a hall (polish 3; the server's too).
      const lp = cents('linen_price'), rl = (s.type === 'dorm' || s.type === 'yf' ? (+s.linens || 0) : 0) + ppl.filter(p => p.linens && inHall(p, d)).length;
      if (rl) add('linens', plural(rl, 'linen packet') + ' × ' + $(lp), rl * lp);
      if (s.type === 'camper' && s.nights.length) {
        const cp = cents('camper_price'), c = Math.max(1, s.campers || 1);
        if (C('camper_per') === 'stay') add('camper', 'Camper lot · ' + plural(c, 'camper') + ' × ' + $(cp), c * cp);
        else add('camper', 'Camper lot · ' + (c > 1 ? c + ' campers · ' : '') + plural(s.nights.length, 'night') + ' × ' + $(cp), c * s.nights.length * cp);
      }
      if ((C('meals_free') || 'yes') === 'no') {
        [['adult', 'Meals, 12 and up'], ['child', 'Meals, 3 to 11']].forEach(([b, label]) => {
          const n = state.meals.reduce((k, m) => k + ppl.filter(p => p.band === b && eats(p, m, d)).length, 0), mp = cents('meal_price_' + b);
          add('meals_' + b, label + ' · ' + n + ' × ' + $(mp), n * mp);
        });
      }
      const lodging = lines.reduce((k, l) => k + l.cents, 0), gift = Math.max(0, Math.floor(+d.gift || 0)) * 100;
      if (gift) lines.push({ key: 'gift', label: 'Gift · ' + giftFor(), cents: gift });
      return { lines, lodging_cents: lodging, gift_cents: gift, total_cents: lodging + gift };
    } finally { state.cfg = save; }
  }
  // What the gift goes to, as a label ("Kit packing"), as the server's ogc_reg_gift_for.
  const giftFor = () => { const g = (C('gift_for') || 'the Conference fund').trim().replace(/^the\s+/i, ''); return g.charAt(0).toUpperCase() + g.slice(1); };
  const total = () => priceOf(state.d, state.editing && state.editing.data.price && state.editing.data.price.prices).total_cents;

  // What's missing, by the field it belongs to (the server's ogc_reg_problems; the same words).
  function problems(k) {
    const d = state.d, e = {}, h = d.household, x = d.helper, s = d.stay, need = (p, v) => { if (!String(v || '').trim()) e[p] = 'Required'; };
    const member = state.F && state.F.member;
    if (!k || k === 'contact') {
      need('household.contact', h.contact);
      if (x.on) {
        need('helper.name', x.name);
        // The household must be reachable (Lodging calls them, not the helper): its email or its phone.
        if (!h.email.trim() && !h.phone.trim()) e['household.phone'] = 'Enter an email or a phone';
        if (!emailOk(x.email)) e['helper.email'] = x.email ? 'Enter an email like name@example.com' : 'Required';
        if (h.email && !emailOk(h.email)) e['household.email'] = 'Enter an email like name@example.com';
      } else {
        need('household.phone', h.phone);
        if (!emailOk(h.email) && !(member && !h.email)) e['household.email'] = h.email ? 'Enter an email like name@example.com' : 'Required';
      }
    }
    if (!k || k === 'people') {
      if (!named().length) e.people = 'Add who’s coming';
      named().forEach(p => {
        const at = 'people.' + p.pid;
        if (p.kind !== 'adult' && !/^\d{1,3}$/.test(String(p.age).trim())) e[at + '.age'] = 'Enter an age';
        else if (p.kind === 'child' && +p.age >= 18) e[at + '.age'] = '18 and over · Choose Adult or Young Folk';
        else if (p.age !== '' && +p.age > 110) e[at + '.age'] = 'Enter an age';
        if (p.yf && !p.yfHall && inHall(p)) e[at + '.yfHall'] = 'Choose a hall';
      });
      if (named().length > MAXP) e.people = 'Up to ' + MAXP + ' · Register another for the rest';
      // Where people sleep is kept safe (the Advisors, Oct 9): a Young Folk is the COA's age and up, and
      // a child comes with a grown-up on the registration (or, when the COA allows it, with a household
      // named for Lodging). The desk may enter one anyway; Lodging's Review lists it.
      const min = minYf();
      named().forEach(p => { const at = 'people.' + p.pid + '.age'; if (p.yf && min && p.age !== '' && +p.age < min && !e[at]) e[at] = min + ' and up · Choose Child'; });
      if (!e.people && !state.desk && named().some(p => p.kind === 'child') && !adults().length) {
        if (C('child_with_household') !== 'yes') e.people = NOADULT;
        else if (!String(s.withHh || '').trim()) e['stay.withHh'] = 'Required';
      }
      if (minorsAlone()) parentProblem(e);
      // A parent's approval is asked in the young person's own card (polish 2), so it's checked here.
      else if (adults().length && named().some(p => p.minor && inHall(p))) { if (s.ask) parentProblem(e); else if (!s.yfOk) e['stay.yfOk'] = 'Choose one'; }
    }
    if (!k || k === 'stay') {
      if (!s.type) { e['stay.type'] = 'Choose one'; return e; }
      if (s.type === 'elsewhere') { if (!s.days.length) e['stay.days'] = 'Choose at least one day'; }
      else if (!s.nights.length) e['stay.nights'] = 'Choose at least one night';
      if (s.perPerson) named().forEach(p => { if (!p.nights.length && (s.type !== 'elsewhere' || inHall(p))) e['people.' + p.pid + '.nights'] = 'Choose at least one night'; });
      if (s.type === 'dorm' && sleepers().length > s.rooms * beds()) e['stay.rooms'] = sleepers().length + ' people need ' + Math.ceil(sleepers().length / beds()) + ' rooms';
      // Linens: one choice for everyone sleeping in a dorm room or a hall (nothing that costs money is pre-chosen).
      if (!state.editing && !s.linenChoice && linenPeople().length) e['stay.linenChoice'] = 'Choose linens';
      const L = state.F.left || {};
      if (!state.waitlist && s.type === 'dorm' && L.rooms != null && s.rooms > L.rooms && !state.editing) e['stay.type'] = L.rooms ? 'Only ' + plural(L.rooms, 'room') + ' left' : 'Rooms full';
    }
    if (!k || k === 'preteens') {
      if (preteensOnline() && named().some(p => p.preteen)) d.contacts.forEach((c, j) => { if (j > 0 && !c.name.trim() && !c.phone.trim()) return; if (!c.name.trim()) e['contacts.' + j + '.name'] = 'Required'; if (!c.phone.trim()) e['contacts.' + j + '.phone'] = 'Required'; });
    }
    if ((!k || k === 'pay') && !state.desk && !state.waitlist && total() > 0 && !payOk(d.pay)) e.pay = 'Choose how to pay';
    return e;
  }
  // A parent's email: required, valid, and not the email of the person registering.
  function parentProblem(e) {
    const s = state.d.stay, mine = [state.d.household.email, state.d.helper.email].map(x => String(x || '').trim().toLowerCase()).filter(Boolean);
    if (!emailOk(s.parentEmail)) e['stay.parentEmail'] = s.parentEmail ? 'Enter an email like name@example.com' : 'Required';
    else if (mine.indexOf(s.parentEmail.trim().toLowerCase()) > -1) e['stay.parentEmail'] = 'Use a parent’s email';
    else {
      // A likely typo (gmial.com) stops Continue once, as the household's own email does.
      const t = s.parentEmail.trim().toLowerCase(), fix = typoOf(t);
      if (fix && fix !== t && state.ui.parentTypoAsked !== t) e['stay.parentEmail'] = 'Check ' + t.slice(t.indexOf('@') + 1) + ' · Did you mean ' + fix.slice(fix.indexOf('@') + 1) + '?';
    }
  }
  // Which section a field's problem belongs to (a parent's approval is in Who's coming).
  const sectionOf = path => /^(household|helper)\./.test(path) ? 'contact' : /^stay\.(parentEmail|yfOk|withHh)/.test(path) ? 'people' : /\.nights$/.test(path) || /^stay\./.test(path) ? 'stay' : /^people/.test(path) ? 'people' : /^(contacts|preteens|pickup)/.test(path) ? 'preteens' : 'pay';
  // Who a linen packet may be for: each sleeper in the household's rooms, each Young Folk in a hall.
  const linenPeople = d => { d = d || state.d; return d.people.filter(p => p.name.trim() && ((d.stay.type === 'dorm' && p.band !== 'baby' && !inHall(p, d)) || inHall(p, d))); };
  const hasPacket = (p, d) => inHall(p, d || state.d) ? !!p.linens : !!p.lin;
  const MAXP = 20;
  const NOADULT = 'A child needs a grown-up on this registration';
  const minYf = () => { const v = C('yf_min_age'); return v === '' ? 16 : (+v || 0); };

  /* ================================================================ sections */

  function sections() {
    const pt = preteensOnline() && named().some(p => p.preteen);
    return ['contact', 'people', 'stay', 'meals'].concat(pt ? ['preteens'] : [], ['pay']);
  }
  // The names never change while filling in (polish 2: "Confirm" became "Payment" once a stay was
  // priced). With nothing to pay, the bar's button says Register. The desk speaks of the household.
  const TITLES = { contact: 'Contact', people: 'Who’s coming', stay: 'Where you’ll stay', meals: 'Meals', preteens: 'Preteens', pay: 'Payment' };
  const titleOf = k => state.desk && k === 'stay' ? 'Where they’ll stay' : TITLES[k];
  const isDone = k => state.d.finished.indexOf(k) > -1;
  // The next section to fill in: the first not done; then Payment.
  const nextOf = k => sections().find(x => x !== k && x !== 'pay' && !isDone(x)) || (k === 'pay' ? '' : 'pay');
  // In a change after the form closes, only contact and the preteens' details may be changed online.
  const locked = k => !!(state.editing && !state.editing.can.all && ['contact', 'preteens', 'pay'].indexOf(k) < 0);

  /* ================================================================ drawing: one path */

  // Text → nodes → morphed into the page. Elements with data-k are matched by key (people, sections),
  // the rest in order. A field with focus keeps its value as typed.
  const keyOf = n => n.nodeType === 1 ? n.getAttribute('data-k') : null;
  function morph(a, b) {
    if (a.nodeType !== 1) { if (a.nodeValue !== b.nodeValue) a.nodeValue = b.nodeValue; return; }
    Array.from(a.attributes).forEach(x => { if (!b.hasAttribute(x.name)) a.removeAttribute(x.name); });
    Array.from(b.attributes).forEach(x => { if (a.getAttribute(x.name) !== x.value) a.setAttribute(x.name, x.value); });
    const tag = a.tagName;
    if (tag === 'INPUT') {
      if (a.type === 'checkbox' || a.type === 'radio') a.checked = b.hasAttribute('checked');
      else if (a !== document.activeElement) { const v = b.getAttribute('value') || ''; if (a.value !== v) a.value = v; }
      return;
    }
    if (tag === 'TEXTAREA') { if (a !== document.activeElement && a.value !== b.textContent) a.value = b.textContent; return; }
    if (a.hasAttribute('data-own')) return;
    const keyed = new Map(), used = new Set();
    Array.from(a.childNodes).forEach(n => { const k = keyOf(n); if (k) keyed.set(k, n); });
    let cur = a.firstChild;
    Array.from(b.childNodes).forEach(nb => {
      while (cur && used.has(cur)) cur = cur.nextSibling;
      const k = keyOf(nb);
      let m = null;
      if (k) { m = keyed.get(k) || null; if (m && m.nodeName !== nb.nodeName) m = null; }
      else { let c = cur; while (c && (used.has(c) || keyOf(c))) c = c.nextSibling; if (c && c.nodeName === nb.nodeName && c.nodeType === nb.nodeType) m = c; }
      if (m) { used.add(m); if (m !== cur) a.insertBefore(m, cur); morph(m, nb); }
      else { a.insertBefore(nb, cur); used.add(nb); if (nb.nodeType === 1 && nb.hasAttribute('data-reveal') && !reduced()) { nb.classList.add('is-new'); setTimeout(() => nb.classList.remove('is-new'), 400); } }
    });
    Array.from(a.childNodes).forEach(n => { if (!used.has(n)) n.remove(); });
  }
  // The page's one draw: the current view, morphed in.
  function draw() {
    root.removeAttribute('aria-busy');
    const sk = root.querySelector('.reg-skel'); if (sk) sk.remove();
    const ld = root.querySelector('.reg-loading'); if (ld) ld.remove();
    const html = '<div class="reg-view">' + VIEWS[state.view]() + '</div>';
    const t = document.createElement('div');
    t.innerHTML = html;
    const now = root.querySelector(':scope > .reg-view');
    if (now) morph(now, t.firstElementChild); else root.appendChild(t.firstElementChild);
    keepAsOf();
    document.body.classList.toggle('has-regbar', !!root.querySelector('.reg-bar'));
  }
  // A change: the derived parts worked out, kept for this tab, drawn.
  function update() { state.override = null; if (state.d) { settle(); keep(); } draw(); }

  /* ================================================================ small parts */

  const errId = path => 'err-' + path.replace(/[^A-Za-z0-9]+/g, '-');
  const err = path => state.errors[path] ? '<p class="rf-err" id="' + errId(path) + '">' + esc(state.errors[path]) + '</p>' : '';
  const bad = path => state.errors[path] ? ' aria-invalid="true" aria-describedby="' + errId(path) + '"' : '';
  const help = (t, id) => t ? '<p class="rf-help"' + (id ? ' id="' + id + '"' : '') + '>' + esc(t) + '</p>' : '';
  // What must stay on one line keeps together (Michael: nothing split mid-word): a number and its unit
  // ("5 nights"), "× $32.50", a phone (555-555-0142), a date ("Sat May 29"). escn() escapes it too.
  const nb = t => String(t == null ? '' : t).replace(/(\d) (?=[A-Za-z$])/g, '$1\u00a0').replace(/ × /g, '\u00a0×\u00a0').replace(/ · /g, '\u00a0· ').replace(/check-in/g, 'check\u2011in').replace(/\b(\d{3})-(\d{3})-(\d{4})\b/g, '$1\u2011$2\u2011$3').replace(/\b(Mon|Tue|Wed|Thu|Fri|Sat|Sun) (Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec) /g, '$1\u00a0$2\u00a0');
  const escn = t => esc(nb(t));
  // A text field: its label (only the label: its accessible name), then the field, its help and its
  // error, both joined to it with aria-describedby.
  function field(label, path, value, o) {
    o = o || {};
    // While an error shows, the help steps aside (polish 3: three lines stacked under Email); a fix for
    // the error sits on the error's own line (o.fix: a button).
    if (state.errors[path]) o = Object.assign({}, o, { help: '' });
    const fid = 'f-' + path.replace(/[^A-Za-z0-9]+/g, '-'), hid = o.help ? 'help-' + path.replace(/[^A-Za-z0-9]+/g, '-') : '', desc = [state.errors[path] ? errId(path) : '', hid].filter(Boolean).join(' ');
    return '<div class="reg-field' + (o.cls ? ' ' + o.cls : '') + '"><label class="reg-label" for="' + fid + '">' + esc(label) + (o.optional ? ' <span class="reg-opt">(optional)</span>' : '') + '</label>' +
      (o.area ? '<textarea id="' + fid + '" name="' + path + '" rows="2"' + (o.ph ? ' placeholder="' + esc(o.ph) + '"' : '') + (state.errors[path] ? ' aria-invalid="true"' : '') + (desc ? ' aria-describedby="' + desc + '"' : '') + ' maxlength="500">' + esc(value) + '</textarea>'
        : '<input id="' + fid + '" name="' + path + '" type="' + (o.type || 'text') + '" value="' + esc(value) + '"' + (o.attrs || '') + (o.ph ? ' placeholder="' + esc(o.ph) + '"' : '') + (state.errors[path] ? ' aria-invalid="true"' : '') + (desc ? ' aria-describedby="' + desc + '"' : '') + '>') +
      (o.help ? '<span class="rf-help" id="' + hid + '">' + esc(o.help) + '</span>' : '') + (o.fix && state.errors[path] ? '<p class="rf-err" id="' + errId(path) + '">' + esc(state.errors[path]) + ' ' + o.fix + '</p>' : err(path)) + (o.after || '') + '</div>';
  }
  // A choice of a few: a radio group of pills (arrow keys move between them).
  // after: { value: html } placed right after that pill (an (i) for the pill it explains).
  function radios(label, act, value, opts, extra, errPath, after, plain) {
    return '<span class="rf-seg' + (plain ? ' rf-seg--plain' : '') + '" role="radiogroup" aria-label="' + esc(label) + '"' + (errPath && state.errors[errPath] ? ' aria-invalid="true" aria-describedby="' + errId(errPath) + '"' : '') + '>' + opts.map(o => {
      const on = value === o[0];
      return '<button type="button" role="radio" aria-checked="' + on + '" tabindex="' + (on || (!opts.some(x => x[0] === value) && o === opts[0]) ? '0' : '-1') + '" data-act="' + act + '" data-v="' + esc(o[0]) + '"' + (extra || '') + (o[2] ? ' disabled' : '') + '>' + (plain ? '' : I.check) + esc(o[1]) + '</button>' + (after && after[o[0]] ? after[o[0]] : '');
    }).join('') + '</span>';
  }
  // A yes/no: one pill, on or off.
  const tog = (path, on, label, o) => '<label class="rf-tog' + (o && o.cls ? ' ' + o.cls : '') + '"><input type="checkbox" name="' + path + '"' + (on ? ' checked' : '') + bad(path) + (o && o.dis ? ' disabled' : '') + '><span>' + I.check + esc(label) + '</span></label>';
  const togAct = (act, on, label, extra) => '<button type="button" class="rf-pill" aria-pressed="' + !!on + '" data-act="' + act + '"' + (extra || '') + '>' + I.check + esc(label) + '</button>';
  const stepper = (path, value, min, max, label) => '<span class="reg-stepper" role="group" aria-label="' + esc(label) + '"><button type="button" data-act="step" data-path="' + path + '" data-by="-1" aria-label="Fewer ' + esc(label.toLowerCase()) + '"' + (value <= min ? ' disabled' : '') + '>' + I.minus + '</button><output aria-live="polite" aria-label="' + esc(label) + '">' + value + '</output><button type="button" data-act="step" data-path="' + path + '" data-by="1" aria-label="More ' + esc(label.toLowerCase()) + '"' + (value >= max ? ' disabled' : '') + '>' + I.plus + '</button></span>';
  // An (i) that opens its explanation in place (never only on hover: phones have none).
  const infoBtn = (id, label) => '<button type="button" class="rf-i" data-act="info" data-id="' + id + '" aria-expanded="' + !!state.ui['i-' + id] + '" aria-label="' + esc(label) + '">' + I.info + '</button>';
  const infoText = (id, text) => state.ui['i-' + id] ? '<span class="rf-itext" role="note">' + esc(text) + '</span>' : '';
  const info = (id, label, text) => infoBtn(id, label) + infoText(id, text);
  // The same explanation as plain help on its own line under what it explains (polish 3: inline, it
  // took the uppercase label style and shouted).
  const infoLine = (id, text) => state.ui['i-' + id] ? '<p class="rf-help rf-help--i-open" role="note">' + esc(text) + '</p>' : '';

  // One ledger: rows of [label, amount or words, {sum, cls}], amounts right-aligned. Never a $0 row.
  const ledger = (rows, cap) => '<table class="reg-total"><caption class="ogc-sr">' + esc(cap || 'Total') + '</caption><tbody>' + rows.filter(Boolean).map(r => '<tr' + (r[2] && r[2].sum ? ' class="reg-total__sum"' : '') + '><td>' + escn(r[0]) + '</td><td>' + escn(typeof r[1] === 'number' ? $(r[1]) : r[1]) + '</td></tr>').join('') + '</tbody></table>';
  // What's been received and what's promised, kept apart (a check to come is never counted as paid).
  // A check not received by check_by (m.late) is due at check-in (the COA's late_pay), never "to come".
  const lateIn = m => !!(m && m.late) && !(state.F && state.F.latePay === 'card');
  function moneyRows(m, d) {
    const late = (d && d.pay === 'checkin') || lateIn(m);
    return [m.paid > 0 ? ['Paid', m.paid] : null, m.check > 0 ? ['Check to come', m.check] : null, m.refund > 0 ? ['Refund requested', m.refund] : null, m.refunded > 0 ? ['Refunded', m.refunded] : null,
      !m.check && m.due > 0 ? [late ? 'Due at check-in' : m.paid > 0 ? 'Balance' : 'Due', m.due, { sum: true }] : null];
  }

  /* ================================================================ the hero */

  function hero(title, o) {
    o = o || {};
    const s = state.model ? state.model.settings : {}, r = state.row || {};
    // A year with no dates yet still says who hosts it (the Advisors, Oct 9: show 2028 with its hosts).
    const facts = o.facts !== false ? '<ul class="wk-facts">' + (r.start ? '<li>' + I.cal + '<span>' + esc(O.fmtDateSpan(r.start, r.end)) + '</span></li>' : r.hosts ? '<li>' + I.people + '<span>' + esc('Hosted by the ' + r.hosts.replace(/^the\s+/i, '')) + '</span></li>' : '') + (s.venue ? '<li>' + I.pin + '<span>' + esc(s.venue) + '<small>' + esc(s.city || '') + '</small></span></li>' : '') + (o.more || '') + '</ul>' : '';
    const photo = o.photo ? '<div class="wk-hero__side"><figure class="wk-photo"><img src="' + esc(SU.photoOf(s)) + '" alt="" loading="lazy" decoding="async"></figure></div>' : '';
    return '<header class="wk-hero"><div class="wk-wrap' + (photo ? ' wk-hero__in' : '') + '"><div class="wk-hero__text vol-hero">' +
      '<p class="wk-kicker"><a class="reg-kick" href="../schedule-hub/?year=' + esc(state.year) + '">' + esc(state.year) + ' Annual Conference</a></p>' +
      '<h1 class="vol-title">' + esc(title) + '</h1>' + facts + (o.sub || '') + '</div>' + photo + '</div></header>';
  }
  const page = (head, body, bar) => '<div class="wk reg">' + head + '<section class="wk-main"><div class="wk-wrap"><div class="reg-wrap">' + body + '</div></div></section>' + (bar || '') + '</div>';
  const blankCard = (h, p, btn) => '<section class="ws-blank reg-blank"><p class="ws-blank__h">' + h + '</p>' + (p ? '<p class="ws-blank__p">' + p + '</p>' : '') + (btn ? '<p class="ws-blank__btn">' + btn + '</p>' : '') + '</section>';
  const mineLink = (label) => '<a href="?year=' + esc(state.year) + '&view=mine">' + esc(label || 'Your sign-ups') + '</a>';
  const ownerOr = (k, fallback) => (state.F && state.F[k]) || fallback || '';
  const today = () => (state.F && state.F.today) || O.wallNow(state.model ? state.model.tz : 'America/Indiana/Indianapolis').date;

  /* ================================================================ the form */

  function formView() {
    const F = state.F, ph = F.phase, closes = C('closes');
    const preview = ph !== 'open' && F.member && q.get('preview') === '1' && !state.desk;
    if (!state.editing && !preview && !state.desk) {
      // The header is drawn the same in every state (the year's photo too), so the page keeps its shape.
      const H = hero('Register', { photo: true });
      if (ph === 'none' && F.blocked === 'samples') return page(H, blankCard('Not open yet', esc('Sample households in ' + state.year), '<button type="button" class="wk-btn wk-btn--line wk-btn--small" data-act="clearsamples">Clear samples</button>'));
      // Every state the same shape (polish 3): one serif line, then at most one action.
      if (ph === 'none' || !state.model) return page(H, blankCard('Not open yet'));
      if (ph === 'before') return page(H, blankCard('Opens ' + esc(O.fmtDate(C('opens'), 'md')), '', F.member ? '<a class="wk-btn wk-btn--line wk-btn--small" href="?year=' + esc(state.year) + '&preview=1">Preview</a>' : ''));
      if (ph === 'closed') return page(H, blankCard('Register at check-in', C('checkin_place') ? esc(C('checkin_place')) : '', mineLink()));
      if (ph === 'held') {
        // A past year: when it was held, and the next year's registration (open, or when it opens).
        const N = state.nextF, ny = N ? String(N.year) : '', r = state.row || {};
        const open = N && N.phase === 'open', when = N && N.phase === 'before' && N.cfg && N.cfg.opens ? ny + ' · Opens ' + O.fmtDate(N.cfg.opens, 'md') : '';
        return page(H, blankCard(esc('Held ' + (r.start ? O.fmtDateSpan(r.start, r.end) : r.year)), esc(when), open ? '<a class="wk-btn wk-btn--small" href="?year=' + esc(ny) + '">Register for ' + esc(ny) + '</a>' : mineLink()));
      }
    }
    const left = closes && !state.editing ? (() => { const n = O.daysBetween ? O.daysBetween(today(), closes) : 99; return n >= 0 && n <= 7 ? 'Closes ' + O.fmtDate(closes, 'weekday') : 'Closes ' + O.fmtDate(closes, 'md'); })() : '';
    // The desk works in the editors' frame (no site header): household after household.
    const head = state.desk ? SU.wsHead({ year: state.year, part: ['registration', 'Registration'], kicker: 'Desk · ' + state.year, title: 'Register a household' })
      : hero(state.editing ? 'Change registration' : 'Register', { photo: true, more: left && ph === 'open' ? '<li>' + I.clock + '<span>' + esc(left) + '</span></li>' : '' });
    let top = '';
    if (state.desk && state.deskSaved) top += '<p class="rf-banner" role="status">' + I.check + '<span>' + esc('Saved · ' + state.deskSaved.rid + ' · ' + regName(state.deskSaved.data)) + '</span><span class="rf-banner__next">Next household</span></p>';
    if (preview) top += '<p class="reg-preview">' + I.info + '<span><b>Preview</b> · ' + esc(ph === 'before' ? 'Opens ' + O.fmtDate(C('opens'), 'md') : 'Not open') + ' · Nothing is saved</span></p>';
    if (state.editing) top += '<p class="rf-status"><span>' + esc(state.editing.rid) + ' · ' + esc(regName(state.editing.data)) + '</span><a class="wk-linklike" href="?year=' + esc(state.year) + '&view=mine">' + (editChanged() ? 'Discard changes' : 'Back') + '</a></p>' +
      (!state.editing.can.all ? '<p class="reg-preview">' + I.info + '<span>Closed online · Contact and preteen details only · Other changes at check-in</span></p>' : '');
    else if (!state.desk) top += (state.flashTop ? '<p class="rf-flash" role="status">' + I.check + '<span>' + esc(state.flashTop) + '</span></p>' : '') + whoLine();
    // Signed in with a registration already: see it, or register another (a helper, a sibling).
    if (!state.editing && !state.desk && F.mine.length && !state.another) {
      // One way in (polish 3: Open and Your sign-ups went to the same place): the filled Your sign-ups.
      return page(head, top + '<section class="rf-card"><h2 class="rf-card__h">' + I.bed + (F.mine.length > 1 ? 'Your registrations' : 'Your registration') + '</h2><ul class="rf-items">' + F.mine.map(m => '<li><span><b>' + esc(m.label) + '</b><small>' + escn([m.rid, statusWords(m)].filter(Boolean).join(' · ')) + '</small></span></li>').join('') + '</ul>' +
        '<p class="rf-card__btns"><a class="wk-btn wk-btn--small" href="?year=' + esc(state.year) + '&view=mine">Your sign-ups</a></p></section>' +
        '<p class="rf-quiet rf-another"><button type="button" class="wk-linklike" data-act="another">Register another</button></p>');
    }
    // A returning household: last year's, picked up (the empty form waits behind Start new). It shows
    // before anyone is named: at once when signed in, or right after the email is confirmed at Contact.
    const isFresh = !state.editing && !state.d.from && !named().length;
    if (isFresh && !state.desk && F.reuse.length && !state.ui.skipReuse) {
      return page(head, top + F.reuse.map((r, i) => '<section class="rf-last" data-k="reuse-' + i + '"><div><h2 class="rf-last__h">Your ' + esc(r.from) + ' registration' + (F.reuse.length > 1 ? ' · ' + esc(r.label) : '') + '</h2><p>' + esc(r.line + ' · ' + r.names.slice(0, 4).join(', ') + (r.names.length > 4 ? '…' : '')) + '</p>' +
        (r.was && r.now && r.was !== r.now ? '<p class="rf-last__note">' + esc(r.from + ': ' + $(r.was) + ' · ' + state.year + ': ' + $(r.now)) + '</p>' : '') + '</div>' +
        '<p class="rf-last__btns"><button type="button" class="wk-btn" data-act="reuse" data-i="' + i + '">Reuse</button>' + (i === F.reuse.length - 1 ? '<button type="button" class="wk-linklike" data-act="startnew">Start new</button>' : '') + '</p></section>').join(''));
    }
    const ks = sections();
    return page(head, top +
      (state.d.from && !state.editing ? '<p class="rf-from">' + I.check + 'From your ' + esc(state.d.from) + ' registration</p>' : '') +
      (!state.editing && (state.d.finished.length > 1 || named().length) ? '<p class="rf-draft"><span>Draft</span><button type="button" class="wk-linklike" data-act="startover">Start over</button></p>' : '') +
      '<div class="rf">' + ks.map(k => sectionView(k, ks)).join('') + '</div>' + (state.desk && (state.deskToday || []).length ? deskList() : '') +
      (state.editing && state.editing.can.cancel ? '<p class="rf-quiet rf-cancel"><button type="button" class="wk-linklike" data-act="cancelreg" data-id="' + state.editing.id + '">Cancel registration</button></p>' : '') +
      (W.dev && F.member && !state.editing && !state.desk ? '<p class="rf-mock"><button type="button" class="ogc-mock" data-act="cleartests">Local · Clear test registrations</button></p>' : ''), barView(preview));
  }
  // Today at the desk: the households entered here today (beside the form on a laptop).
  function deskList() {
    const list = (state.deskToday || []).slice().reverse();
    return '<aside class="reg-desklist" aria-label="Today at the desk"><p class="rf-label">Today at the desk</p><ul class="rf-items">' + list.map(r => '<li><span><b>' + esc(regName(r.data)) + '</b><small>' + escn([r.data.rid, statusWords({ data: r.data })].filter(Boolean).join(' · ')) + '</small></span></li>').join('') + '</ul></aside>';
  }
  const loadDesk = () => api('GET', 'years/' + state.year + '/records?kinds=registrations').then(out => {
    state.deskToday = ((out && out.registrations) || []).map(x => ({ id: x.id, data: x.data || {} })).filter(r => r.data.source === 'desk' && r.data.at === today());
  }, () => { state.deskToday = []; });
  const editChanged = () => !!state.editing && JSON.stringify(cleanForCompare(state.d)) !== JSON.stringify(cleanForCompare(answersOf(state.editing.data)));

  // Who this is: signed in (and Not you?), or a way in for someone already registered.
  function whoLine() {
    const me = SU.me();
    // Signed in: said once, in Contact's Email field (with Not you?); a done Contact's line names it too.
    if (me && !me.pending) return '';
    return '<p class="rf-who rf-who--form"><a class="reg-tap" href="?year=' + esc(state.year) + '&view=mine">Already registered? Sign in</a></p>';
  }

  // A section: open (being filled in), done (its summary and Change), or still to come (its name).
  function sectionView(k, ks) {
    // In a change, Payment stays open at the end (the balance follows each change above it).
    const open = state.open === k || (k === 'pay' && !!state.editing && !state.open), done = isDone(k) && !open && !(k === 'meals' && !isDone('stay')), lock = locked(k);
    const cls = 'rf-sec' + (open ? ' is-open' : done ? ' is-done' : ' is-next') + (state.check[k] ? ' is-check' : '');
    // A mark, not a number (polish 2: adding an 11-year-old renumbered Payment): a check when done, a
    // filled dot while open, a ring still to come. The names never change.
    const sr = done ? '<span class="ogc-sr"> · Done</span>' : '';
    const head = '<div class="rf-head"><h2 class="rf-h" id="rf-h-' + k + '" tabindex="-1"><span class="rf-n" aria-hidden="true">' + (done ? I.check : '') + '</span>' + esc(titleOf(k)) + sr + '</h2>' +
      (done && !lock && k !== 'pay' ? '<button type="button" class="wk-linklike rf-change" data-act="open" data-sec="' + k + '" aria-label="Change ' + esc(titleOf(k)) + '">Change</button>' : '') + '</div>';
    if (!open) return '<section class="' + cls + '" data-k="sec-' + k + '" data-reveal>' + head + (done ? summaryView(k) : '') + '</section>';
    return '<section class="' + cls + '" data-k="sec-' + k + '" aria-labelledby="rf-h-' + k + '">' + head + '<div class="rf-body">' + BODY[k]() + '</div></section>';
  }
  const BODY = { contact: () => contactSec(), people: () => peopleSec(), stay: () => staySec(), meals: () => mealsSec(), preteens: () => preteenSec(), pay: () => paySec() };

  /* ---------------------------------------------------------------- summaries: two lines each */

  const sum2 = (a, b) => '<div class="rf-sum"><p>' + a + '</p>' + (b ? '<p class="rf-sum__d">' + b + '</p>' : '') + '</div>';
  // Who's coming, said once: "2 adults", "2 adults, 1 Young Folk, 3 children"; one person, their name.
  function peopleLine() {
    const ppl = named(), a = ppl.filter(p => p.kind === 'adult').length, y = ppl.filter(p => p.yf).length, c = ppl.filter(p => p.kind === 'child').length;
    if (ppl.length === 1) return ppl[0].name.trim();
    return [a ? plural(a, 'adult') : '', y ? plural(y, 'Young Folk') : '', c ? plural(c, 'child', 'children') : ''].filter(Boolean).join(', ');
  }
  function summaryView(k) {
    const d = state.d, s = d.stay, mark = t => state.check[k] ? '<mark>' + esc(state.check[k]) + '</mark> · ' + t : t;
    if (k === 'contact') {
      const h = d.household, x = d.helper;
      const me = SU.me(), notYou = me && !me.pending && !state.editing && !state.desk ? ' · <button type="button" class="wk-linklike" data-act="signout">Not you?</button>' : '';
      return x.on ? sum2(escn([h.contact, h.email, h.phone].filter(Boolean).join(' · ')), escn('By ' + x.name + ' · ' + x.email) + notYou) : sum2(escn([h.contact, h.email, h.phone].filter(Boolean).join(' · ')) + notYou);
    }
    if (k === 'people') {
      // One person: the name is the first line, so only what's true of them follows.
      // Every first name, in order (polish 3: an adult not communing was left out, which reads as not
      // registered), with details only where there are some.
      const one = named().length === 1;
      const det = named().map(p => {
        const bits = [p.age !== '' ? p.age : '', p.yf ? (inHall(p) ? hallWord(p.yfHall) + (p.rooming ? ', with ' + p.rooming : '') : yfOnly() ? '' : 'with family') : '', p.minor && inHall(p) && !yfOnly() ? (s.yfOk ? 'approved' : s.ask ? 'parent to approve' : '') : '', p.preteen ? 'preteen' : '', p.communing ? 'communing' : ''].filter(Boolean);
        return one ? bits.join(' · ') : first(p.name) + (bits[0] === p.age && p.age !== '' ? ' ' + bits.shift() : '') + (bits.length ? ', ' + bits.join(', ') : '');
      });
      return sum2(escn(peopleLine()), escn(det.join(' · ')));
    }
    if (k === 'stay') {
      // Where each Young Folk sleeps is in Who's coming's summary just above; it isn't said again.
      if (s.type === 'elsewhere') return sum2(mark(escn('Off campus · ' + s.days.map(x => O.fmtDate(x, 'weekdayShort')).join(', '))), escn(linenWords()));
      const span = spanOf(s.nights) + '\u00a0·\u00a0' + plural(s.nights.length, 'night');
      if (s.type === 'yf') return sum2(escn(Array.from(new Set(named().map(p => hallWord(p.yfHall)))).join(', ') + ' · ' + span), escn([nightsDiffer(), linenWords()].filter(Boolean).join(' · ')));
      if (s.type === 'camper') return sum2(mark(escn('Camper lot' + (s.campers > 1 ? ' · ' + s.campers + ' campers' : '') + ' · ' + span)), escn([nightsDiffer(), s.near ? 'Group: ' + s.near : '', linenWords()].filter(Boolean).join(' · ')));
      return sum2(mark(escn(plural(s.rooms, 'dorm room') + ' · ' + span)), escn([nightsDiffer(), detailsLine()].filter(Boolean).join(' · ')));
    }
    if (k === 'meals') {
      const all = mealsHere(), off = all.filter(m => d.meals.off[m.id]), some = all.filter(m => !d.meals.off[m.id] && d.meals.who[m.id]);
      if (!all.length) return sum2('No meals on your days');
      return sum2(escn(summaryText()), escn([off.length ? 'Not: ' + off.map(mealName).join(', ') : '', some.map(m => mealName(m) + ': ' + (d.meals.who[m.id] || []).length + ' of ' + named().length).join(', ')].filter(Boolean).join(' · ')));
    }
    if (k === 'pay') {
      // Payment folded (in a change, while another part is open): its line like every other part's.
      const M = moneyNow(), ed = state.editing, how = { card: 'Card', check: 'Check by mail', checkin: 'At check-in' }[d.pay] || '';
      const st = !ed ? how : M.newCheck ? 'Check to come ' + $(M.newCheck) : M.due > 0 ? (d.pay === 'checkin' ? 'Due at check-in ' : 'Balance ') + $(M.due) : M.refund > 0 ? 'Refund ' + $(M.refund) : M.paid > 0 ? 'Paid' : '';
      return sum2(escn(['Total ' + $(M.total), st].filter(Boolean).join(' · ')));
    }
    if (k === 'preteens') {
      const pts = named().filter(p => p.preteen), pd = ptDays();
      return sum2(escn(pts.map(p => first(p.name) + (pd.length && ((d.preteens[p.pid] || {}).days || []).length && (d.preteens[p.pid].days.length < pd.length) ? ' (' + d.preteens[p.pid].days.map(x => x.slice(0, 3)).join(', ') + ')' : '')).join(', ') + ' · Picked up by ' + pickupWords()), escn('Contacts: ' + d.contacts.filter(c => c.name).map(c => c.name.trim()).join(', ')));
    }
    return '';
  }
  // Who isn't here every night, by name ("Joel: Fri–Sun"); nothing when everyone has the same nights.
  function nightsDiffer(d) {
    d = d || state.d;
    const s = d.stay;
    if (!s.perPerson || s.type === 'elsewhere') return '';
    const days = ns => { const m = ns.filter(n => !early(n)); return m.length ? SU.nightShort(m[0]) + (m.length > 1 ? '–' + SU.nightShort(m[m.length - 1]) : '') : ns.map(SU.nightShort).join(', '); };
    return d.people.filter(p => String(p.name || '').trim() && (s.type === 'yf' || !inHall(p, d)) && (p.nights || []).length && p.nights.length !== s.nights.length).map(p => first(p.name) + ': ' + days(p.nights)).join(' · ');
  }
  const mealName = m => O.fmtDate(mealDate(m), 'weekdayShort') + ' ' + String(m.title).replace(/^(Breakfast|Lunch|Supper|Dinner).*$/i, '$1').toLowerCase();
  const pickupWords = () => [].concat(state.d.pickupWho.length ? state.d.pickupWho.map(first) : adults().map(p => first(p.name)), state.d.pickupOther ? [state.d.pickupOther] : []).join(' or ');
  // Room details in a line: only what's true (never "No requests").
  // lin: with the linens (the summary); the fold's own line leaves them out, the Linens row is just above.
  function detailsLine(lin) {
    const s = state.d.stay, adultsN = adults().length;
    return [roomsLine(), adultsN > 1 || s.rooms > 1 ? 'Keys: ' + s.keys.map(first).join(', ') : '', lin === false ? '' : linenWords(), s.mattresses ? plural(s.mattresses, 'air mattress', 'air mattresses') : '',
      [s.ground ? 'Ground floor' : '', s.walker ? 'Walker or wheelchair' : '', s.nearW ? 'Near women’s restroom' : '', s.nearM ? 'Near men’s restroom' : ''].filter(Boolean).join(', '),
      s.near ? 'Group: ' + s.near : '', s.arrive ? ARRIVE[s.arrive] : '', s.needs ? 'Note' : ''].filter(Boolean).join(' · ');
  }
  // Linens in words, one function for the form, Your sign-ups and the receipt (the server's
  // ogc_reg_linen_words for the emails): "Own linens · Levi: linen packet", "2 linen packets".
  function linenWords(d) {
    d = d || state.d;
    const s = d.stay, rooms = s.type === 'dorm', ppl = d.people.filter(p => String(p.name || '').trim()), hall = ppl.filter(p => inHall(p, d)), yf = hall.filter(p => p.linens);
    // Every packet counted together, as on the price line ("4 linen packets"); where each Young Folk
    // sleeps is said in the stay's words.
    const n = (rooms ? (+s.linens || 0) : 0) + yf.length;
    if (n) return ppl.length === 1 && n === 1 ? 'Linen packet' : plural(n, 'linen packet');
    return s.linenChoice && (rooms || hall.length) ? 'Own linens' : '';
  }
  const ARRIVE = { afternoon: 'Arriving afternoon', evening: 'Arriving evening', late: 'Arriving after 9 PM' };

  /* ---------------------------------------------------------------- 1 · Contact */

  function contactSec() {
    const h = state.d.household, x = state.d.helper, me = SU.me(), signed = me && !me.pending;
    const typo = e => { const t = typoOf(e), path = x.on ? 'helper.email' : 'household.email'; return t && /Did you mean/.test(state.errors[path] || '') ? '<button type="button" class="rf-fix rf-fix--pill" data-act="typo" data-path="' + path + '" data-v="' + esc(t) + '">Use ' + esc(t.slice(t.indexOf('@') + 1)) + '</button>' : ''; };
    // The desk enters a household that isn't the one signed in: the email is theirs, optional, never locked.
    if (state.desk) return '<div class="reg-grid reg-grid--1">' + field('Name', 'household.contact', h.contact, { attrs: ' maxlength="80"' }) + '</div><div class="reg-grid">' +
      field('Email', 'household.email', h.email, { type: 'email', optional: true, attrs: ' inputmode="email" maxlength="120"', help: 'For the confirmation', fix: typo(h.email) }) +
      field('Phone', 'household.phone', h.phone, { type: 'tel', attrs: ' maxlength="30"' }) + '</div>';
    const lockMail = signed && !state.editing ? ' readonly' : '';
    // Signed in: the email is said once, as the field's value, with Not you? beside it (polish 3: a line
    // above repeated it). The code box sits right under the email it confirms.
    const notYou = signed && !state.editing ? '<button type="button" class="wk-linklike rf-notyou" data-act="signout">Not you?</button>' : '';
    return '<p class="rf-row">' + radios('Registering', 'helper', x.on ? 'other' : 'me', [['me', 'For me'], ['other', 'For someone else']]) + '</p>' +
      (x.on ? '<p class="rf-label">You</p><div class="reg-grid reg-grid--1">' + field('Name', 'helper.name', x.name, { attrs: ' autocomplete="name" maxlength="80"' }) + '</div><div class="reg-grid">' +
        field('Email', 'helper.email', x.email, { type: 'email', attrs: ' autocomplete="email" inputmode="email" maxlength="120"' + (signed ? ' readonly' : ''), help: signed || codeSent() ? '' : 'A code is emailed to confirm it', fix: signed ? '' : typo(x.email), after: notYou + codeBox() }) + field('Phone', 'helper.phone', x.phone, { type: 'tel', optional: true, attrs: ' autocomplete="tel" maxlength="30"' }) + '</div>' +
        // The household must be reachable: its email or its phone, either one (the rule said once).
        '<p class="rf-label">Household contact</p>' + help('Email or phone, at least one') + '<div class="reg-grid reg-grid--1">' + field('Name', 'household.contact', h.contact, { attrs: ' maxlength="80"' }) + '</div><div class="reg-grid">' +
        field('Email', 'household.email', h.email, { type: 'email', optional: true, attrs: ' inputmode="email" maxlength="120"' + (state.editing ? ' readonly' : '') }) + field('Phone', 'household.phone', h.phone, { type: 'tel', optional: true, attrs: ' maxlength="30"' }) + '</div>'
        : '<div class="reg-grid reg-grid--1">' + field('Name', 'household.contact', h.contact, { attrs: ' autocomplete="name" maxlength="80"' }) + '</div><div class="reg-grid">' +
        field('Email', 'household.email', h.email, { type: 'email', attrs: ' autocomplete="email" inputmode="email" maxlength="120"' + (lockMail || (state.editing ? ' readonly' : '')), help: signed || state.editing || codeSent() ? '' : 'A code is emailed to confirm it', fix: signed || state.editing ? '' : typo(h.email), after: notYou + codeBox() }) +
        field('Phone', 'household.phone', h.phone, { type: 'tel', attrs: ' autocomplete="tel" maxlength="30"' }) + '</div>');
  }
  // The code, under the email it confirms: sent when Contact is continued; six digits confirm it and the
  // form goes straight on. Code only (never a link to open in another tab, away from this draft).
  function codeBox() {
    const v = state.verify, want = wantEmail();
    if (state.editing || state.desk || verified() || !(v.step === 'sent' && v.email === want)) return v.err && v.step !== 'sent' ? '<p class="rf-err" role="alert">' + esc(v.err) + '</p>' : '';
    // The address just typed on this device is shown whole (it's theirs), with Change beside it.
    return '<div class="rf-verify" data-k="verify"><p class="rf-help rf-verify__to">Code sent to <b>' + esc(v.email) + '</b> · <button type="button" class="wk-linklike" data-act="otheremail">Change</button></p>' +
      field('Code', 'verify.code', v.code, { attrs: ' inputmode="numeric" autocomplete="one-time-code" pattern="[0-9 ]*" maxlength="9" enterkeyhint="done"', cls: 'rf-code', help: 'Keep this page open · Expires in 30 min' }) + (v.err ? '<p class="rf-err" role="alert">' + esc(v.err) + '</p>' : '') +
      '<p class="rf-quiet rf-verify__more"><button type="button" class="wk-linklike" data-act="resend"' + (Date.now() < v.retryAt ? ' disabled' : '') + '>' + esc(resendLabel()) + '</button></p>' +
      (v.dev ? '<p class="rf-mock"><span class="ogc-mock ogc-mock--tag">Local: code ' + esc(v.dev) + '</span></p>' : '') + '</div>';
  }
  const codeSent = () => state.verify.step === 'sent' && state.verify.email === wantEmail() && !verified();
  // "Resend in 0:24", counting down, then "Resend".
  const resendLabel = () => { const t = Math.ceil((state.verify.retryAt - Date.now()) / 1000); return t > 0 ? 'Resend in ' + Math.floor(t / 60) + ':' + String(t % 60).padStart(2, '0') : 'Resend'; };
  function tickResend() {
    clearInterval(state.resendT);
    state.resendT = setInterval(() => {
      const b = root.querySelector('[data-act="resend"]');
      if (b) { b.textContent = resendLabel(); b.disabled = Date.now() < state.verify.retryAt; }
      if (Date.now() >= state.verify.retryAt) clearInterval(state.resendT);
    }, 1000);
  }
  // A likely typo ("gmial.com"): the site's one list and rule (OGC_AUTH.suggest, the same as the server's
  // ogc_email_suggest), never a second table here.
  // "Use gmail.com" beside a parent's address that looks mistyped.
  const parentFix = e => { const t = typoOf(e); return t && /Did you mean/.test(state.errors['stay.parentEmail'] || '') ? '<button type="button" class="rf-fix rf-fix--pill" data-act="typo" data-path="stay.parentEmail" data-v="' + esc(t) + '">Use ' + esc(t.slice(t.indexOf('@') + 1)) + '</button>' : ''; };
  const typoOf = e => { const t = String(e || '').trim().toLowerCase(); return t && window.OGC_AUTH && OGC_AUTH.suggest ? OGC_AUTH.suggest(t) || '' : ''; };
  // "Check gmial.com · Did you mean gmail.com?" (the server's words, ogc_typo).
  const typoWords = (e, fix) => 'Check ' + e.slice(e.indexOf('@') + 1) + ' · Did you mean ' + fix.slice(fix.indexOf('@') + 1) + '?';

  /* ---------------------------------------------------------------- 2 · Who's coming */

  function peopleSec() {
    const d = state.d, ch = state.d.changes || [], s = d.stay;
    if (!d.people.length) d.people.push(person({ name: d.helper.on ? '' : d.household.contact }));
    const alone = minorsAlone(), firstMinor = named().find(p => p.minor), firstHallMinor = named().find(p => p.minor && inHall(p));
    const grown = adults().length > 0, many = d.people.length > 1, full = d.people.length >= MAXP;
    const rows = d.people.map((p, i) => {
      const at = 'people.' + p.pid, a = parseInt(p.age, 10), who = p.name || 'Person ' + (i + 1);
      const ageBox = p.kind !== 'adult' ? '<label class="rf-age"><span>Age</span><input name="' + at + '.age" type="text" inputmode="numeric" pattern="[0-9]*" maxlength="3" value="' + esc(p.age) + '" aria-label="' + esc(who + ' age at Conference') + '"' + bad(at + '.age') + '></label>' : '';
      // Communing is a yes/no of its own, a box on its own line (polish 2: as a pill on the kind line it
      // read as a fourth kind). Drawn from the first moment (off until there's a name), so nothing moves
      // when the first letter is typed.
      // What the two words mean is the COA's text (yf_help, communing_help), behind an (i) beside each;
      // none is drawn when it's blank (polish 3: statements on fellowship are the Advisors' to word).
      const comm = p.kind !== 'child' ? '<div class="rf-pline rf-pline--comm"><label class="rf-check"><input type="checkbox" name="' + at + '.communing"' + (p.communing ? ' checked' : '') + (p.name.trim() ? '' : ' disabled') + '><span class="rf-check__b" aria-hidden="true">' + I.check + '</span><span>Communing</span></label>' + (C('communing_help') ? infoBtn('cm-' + p.pid, 'Communing') : '') + '</div>' + (C('communing_help') ? infoLine('cm-' + p.pid, C('communing_help')) : '') : '';
      const yfI = C('yf_help') ? { yf: infoBtn('yf-' + p.pid, 'Young Folk') } : null;
      // An age that's too young for a Young Folk says so with the fix beside it.
      const ageErr = () => { const t = state.errors[at + '.age'] || '', m = /^(.*) · Choose Child$/.exec(t); return m ? '<p class="rf-err" id="' + errId(at + '.age') + '">' + esc(m[1]) + ' · <button type="button" class="rf-fix" data-act="kind" data-pid="' + p.pid + '" data-v="child">Choose Child</button></p>' : err(at + '.age'); };
      const hint = p.kind === 'child' && (a === 16 || a === 17) ? '<p class="rf-help">16 and up · <button type="button" class="rf-fix" data-act="kind" data-pid="' + p.pid + '" data-v="yf">Young Folk?</button></p>' : '';
      // Where a Young Folk sleeps, asked once, here. With a grown-up along: their hall or with the family.
      // Alone: their hall, or off campus (a local Young Folk at home); a camper shows when the stay says so.
      // The stay follows this answer, and this answer follows the stay.
      const hallOpts = [['men', 'Young men’s hall'], ['women', 'Young women’s hall']];
      const sleepsV = grown ? (p.sleeps === 'family' ? 'family' : p.yfHall) : s.type === 'camper' ? 'camper' : s.type === 'elsewhere' ? 'elsewhere' : p.yfHall;
      const sleepsOpts = grown ? hallOpts.concat([['family', 'With family']]) : hallOpts.concat([['elsewhere', 'Off campus']], s.type === 'camper' ? [['camper', 'Camper lot']] : []);
      const yfPart = p.yf ? '<div class="rf-pmore rf-pmore--yf"><div class="rf-pline rf-pline--opts"><span class="rf-plabel" aria-hidden="true">Sleeps in</span>' + radios(who + ' sleeps in', 'hall', sleepsV, sleepsOpts, ' data-pid="' + p.pid + '"', at + '.yfHall') + '</div>' + err(at + '.yfHall') +
        // Rooming with, as soon as a hall is chosen (polish 2: a Young Folk alone was never asked).
        (inHall(p) && p.yfHall ? field('Rooming with', at + '.rooming', p.rooming, { optional: true, cls: 'rf-rooming', ph: 'A name, or a group name', attrs: ' autocomplete="off" maxlength="80"' }) : '') +
        (alone && firstMinor === p ? field('Parent’s email', 'stay.parentEmail', s.parentEmail, { type: 'email', cls: 'rf-parent', attrs: ' inputmode="email" maxlength="120"', help: 'Emailed to approve', fix: parentFix(s.parentEmail) }) : '') +
        // Under 18 in a hall with a grown-up along: approved right here, in the young person's card.
        (!alone && firstHallMinor === p ? approvalPart() : '') + '</div>' : '';
      return '<li class="rf-person" data-k="' + p.pid + '">' +
        // Line 1: the name, full width (and × when there's more than one person).
        '<div class="rf-pline rf-pline--main"><label class="rf-name"><span class="ogc-sr">Person ' + (i + 1) + ' name</span><input name="' + at + '.name" value="' + esc(p.name) + '" placeholder="Name" autocomplete="off" maxlength="80" enterkeyhint="next"></label>' +
        (many ? '<button type="button" class="reg-remove" data-act="remove" data-pid="' + p.pid + '" aria-label="Remove ' + esc(p.name || 'person ' + (i + 1)) + '">' + I.x + '</button>' : '') + '</div>' +
        // Line 2: who they are (Adult · Young Folk · Child) and the age; the same place on every card.
        '<div class="rf-pline rf-pline--kind"><span class="rf-kind">' + radios(who + ': adult, Young Folk or child', 'kind', p.kind, [['adult', 'Adult'], ['yf', 'Young Folk'], ['child', 'Child']], ' data-pid="' + p.pid + '"', '', yfI) + '</span>' + ageBox + '</div>' +
        (yfI ? infoLine('yf-' + p.pid, C('yf_help')) : '') +
        comm +
        (state.errors[at + '.age'] || hint ? '<div class="rf-pmore">' + ageErr() + hint + '</div>' : '') +
        yfPart +
        (p.kind === 'child' && a >= 10 && a <= 13 ? '<div class="rf-pmore"><div class="rf-pline rf-pline--opts">' + togAct('preteen', p.preteen, 'Preteen program', ' data-pid="' + p.pid + '"') + '<span class="rf-help rf-help--inline">Ages 10–13' + (ptDays().length ? ' · ' + ptDays().map(x => x.slice(0, 3)).join(', ') : '') + '</span></div></div>' : '') +
        '</li>';
    }).join('');
    // A child with no grown-up: Add person (an adult) right there; or, when the COA allows children with
    // another household, that household's name.
    const kidsAlone = named().some(p => p.kind === 'child') && !adults().length && !state.desk;
    const peopleErr = state.errors.people === NOADULT ? '<p class="rf-err" id="' + errId('people') + '">' + esc(NOADULT) + ' · <button type="button" class="rf-fix" data-act="addadult">Add a grown-up</button></p>' : err('people');
    const withHh = kidsAlone && C('child_with_household') === 'yes' ? field('With household', 'stay.withHh', s.withHh || '', { attrs: ' maxlength="80"', help: 'The household they’re with at Conference · For Lodging' }) : '';
    return (ch.length ? '<ul class="rf-changes" aria-label="Changed since last year">' + ch.map(c => '<li>' + esc(c.text) + (c.open ? ' · <button type="button" class="wk-linklike" data-act="open" data-sec="' + esc(c.open) + '">Change</button>' : '') + '</li>').join('') + '</ul>' : '') +
      '<ul class="rf-people">' + rows + '</ul>' + peopleErr + withHh +
      (state.undo ? '<p class="rf-undo" role="status">Removed ' + esc(first(state.undo.p.name) || 'person') + ' · <button type="button" class="wk-linklike" data-act="undo">Undo</button></p>' : '') +
      '<p class="rf-add"><button type="button" class="wk-btn wk-btn--line wk-btn--small" data-act="add"' + (full ? ' disabled aria-describedby="help-maxp"' : '') + '>' + I.plus + 'Add person</button></p>' +
      (full ? help('Up to ' + MAXP + ' · Register another for the rest', 'help-maxp') : '');
  }
  // Under 18 in the halls with a grown-up along: the grown-up is the parent, or a parent is asked by
  // email (a grandmother bringing a grandson), the same approval a Young Folk alone gets. Asked in the
  // first such young person's card, where their age and hall were just set.
  function approvalPart() {
    const s = state.d.stay, who = named().filter(p => p.minor && inHall(p));
    return '<div class="rf-approval" data-k="approval"><div class="rf-pline rf-pline--opts"><span class="rf-plabel" aria-hidden="true">Under 18</span>' + radios('Under 18: parent approval' + (who.length > 1 ? ' for ' + who.map(p => first(p.name)).join(' and ') : ''), 'approval', s.yfOk ? 'self' : s.ask ? 'ask' : '', [['self', 'I’m the parent'], ['ask', 'Ask a parent']], '', 'stay.yfOk') + '</div>' +
      (who.length > 1 ? help('For ' + who.map(p => first(p.name)).join(' and ')) : '') + err('stay.yfOk') +
      (s.ask ? field('Parent’s email', 'stay.parentEmail', s.parentEmail, { type: 'email', cls: 'rf-parent', attrs: ' inputmode="email" maxlength="120"', help: 'Emailed to approve', fix: parentFix(s.parentEmail) }) : '') + '</div>';
  }

  /* ---------------------------------------------------------------- 3 · Where you'll stay */

  function nightsPick() {
    const s = state.d.stay, all = nights(), ea = all.filter(early), main = all.filter(n => !early(n));
    const pill = n => { const on = s.nights.indexOf(n) > -1; return '<label class="reg-night' + (on ? ' is-on' : '') + (early(n) ? ' is-early' : '') + '"><input type="checkbox" name="stay.night" value="' + esc(n) + '"' + (on ? ' checked' : '') + '><span>' + I.check + '<i>' + esc(SU.nightShort(n)) + '</i><b>' + esc(O.fmtDate(nightDate(n), 'mdShort')) + '</b></span></label>'; };
    return '<fieldset class="reg-nights"' + (state.errors['stay.nights'] ? ' aria-describedby="' + errId('stay.nights') + '"' : '') + '><legend>Nights</legend>' +
      (ea.length ? '<span class="reg-nights__g reg-nights__g--early"><span class="rf-glabel">Early ' + infoBtn('early', 'Early nights') + '</span>' + (state.ui['i-early'] ? '<span class="rf-help rf-help--i-open" role="note">Before the Conference · For committees and helpers</span>' : '') + '<span class="reg-nights__row" style="--n:' + Math.min(6, ea.length) + '">' + ea.map(pill).join('') + '</span></span>' : '') +
      '<span class="reg-nights__g">' + (ea.length ? '<span class="rf-glabel">Conference</span>' : '') + '<span class="reg-nights__row" style="--n:' + Math.min(6, main.length) + '">' + main.map(pill).join('') + '</span></span></fieldset>' + err('stay.nights') +
      (s.nights.length ? '<p class="rf-help">Check-in ' + esc(shortDate(nightDate(s.nights[0]))) + ' · Check-out ' + esc(shortDate(O.isoAddDays(nightDate(s.nights[s.nights.length - 1]), 1))) + '</p>' : '');
  }
  // Not everyone here every night: a row of nights for each person.
  function perGrid() {
    const s = state.d.stay, all = nights(), who = named().filter(p => s.type !== 'elsewhere' || inHall(p));
    return '<div class="rf-grid" role="group" aria-label="Nights per person" style="--n:' + all.length + '"><div class="rf-grid__head" aria-hidden="true"><span></span>' + all.map(n => '<span>' + esc(SU.nightShort(n)) + '<small>' + esc(O.fmtDate(nightDate(n), 'day')) + '</small></span>').join('') + '</div>' +
      who.map(p => {
        const mine = nightsFor(p, state.d);
        return '<div class="rf-grid__row" data-k="g-' + p.pid + '"><span class="rf-grid__n">' + esc(first(p.name)) + (p.yf && inHall(p) ? '<small>' + esc(hallWord(p.yfHall).replace('’s hall', '')) + '</small>' : '') + '</span>' +
          all.map(n => '<button type="button" class="rf-nt" data-act="pnight" data-pid="' + p.pid + '" data-v="' + esc(n) + '" aria-pressed="' + (mine.indexOf(n) > -1) + '" aria-label="' + esc(first(p.name) + ', ' + n + ' night') + '">' + I.check + '<span>' + esc(SU.nightShort(n)) + '</span></button>').join('') +
          '</div>' + err('people.' + p.pid + '.nights');
      }).join('') + '</div>';
  }
  // Who sleeps where, with two rooms or more: balanced by default and said in one line (Room details);
  // the pills only once Room details is opened. Names sit in a fixed column so the pills line up.
  const twoRooms = () => { const s = state.d.stay; return s.type === 'dorm' && s.rooms > 1 && sleepers().length > 1; };
  const roomsLine = () => twoRooms() ? Array.from({ length: state.d.stay.rooms }, (_, i) => 'Room ' + (i + 1) + ': ' + (sleepers().filter(p => p.room === i).map(p => first(p.name)).join(', ') || 'Nobody yet')).join(' · ') : '';
  function whoWhere() {
    const s = state.d.stay, sl = sleepers();
    if (!twoRooms()) return '';
    return '<div class="reg-row reg-row--wrap" data-k="who-where"><span><b>Who sleeps where</b></span><div class="rf-keys rf-keys--cols">' +
      sl.map(p => '<div class="rf-keyroom"><span class="rf-keyroom__n">' + esc(first(p.name)) + '</span>' + radios(first(p.name) + '’s room', 'room', String(p.room), Array.from({ length: s.rooms }, (_, i) => [String(i), 'Room ' + (i + 1)]), ' data-pid="' + p.pid + '"') + '</div>').join('') + '</div></div>';
  }
  function staySec() {
    const d = state.d, s = d.stay, F = state.F, L = F.left || {};
    const showPer = named().length > 1 || (named().length && s.type === 'elsewhere' && yfs().some(p => inHall(p)));
    const perToggle = showPer && s.type !== 'elsewhere' || (s.type === 'elsewhere' && yfs().some(p => inHall(p))) ? '<p class="rf-quiet"><button type="button" class="wk-linklike" data-act="perperson">' + (s.perPerson ? 'Same nights for everyone' : 'Nights per person') + '</button></p>' : '';
    const nightsPart = s.perPerson ? '<p class="rf-q">Nights</p>' + perGrid() + (s.nights.length ? '<p class="rf-help">Check-in ' + esc(shortDate(nightDate(s.nights[0]))) + ' · Check-out ' + esc(shortDate(O.isoAddDays(nightDate(s.nights[s.nights.length - 1]), 1))) + '</p>' : '') : nightsPick();
    const ageRule = C('yf_age_split') === 'yes' ? help('Rooms: all 17 and under, or all 18 and over (state law)') : '';
    const full = L.rooms === 0 && !state.editing;
    const card = (v, t, sub) => { const on = s.type === v; return '<button type="button" role="radio" aria-checked="' + on + '" tabindex="' + (on || (!s.type && v !== 'camper' && v !== 'elsewhere') ? 0 : -1) + '" class="reg-choice' + (on ? ' is-on' : '') + '" data-act="type" data-v="' + v + '">' + '<span class="reg-choice__o" aria-hidden="true">' + I.check + '</span><span><b>' + esc(t) + '</b><small>' + esc(sub) + '</small></span></button>'; };
    const camperSub = $(cents('camper_price')) + (C('camper_per') === 'stay' ? ' a camper' : ' a night') + ' · No hookups';
    const roomSub = (C('charge') === 'person' ? $(cents('person_price_adult')) + ' a person a night' : $(cents('room_price')) + ' a night') + ' · ' + (C('room_beds') || 2) + ' beds' + (full ? ' · Full' : '');
    // Young Folks on their own get the same three choices, their hall in place of a dorm room (a local
    // Young Folk may sleep at home; one may stay in a camper).
    const halls = Array.from(new Set(named().map(p => p.yfHall).filter(Boolean)));
    const hallName = halls.length ? halls.map(hallWord).join(' and ') : 'Young Folks hall';
    const first3 = yfOnly() ? card('yf', hallName, $(yfPer()) + ' a night · ' + plural(beds() - 1, 'bed') + ' a room') : card('dorm', 'Dorm room', roomSub);
    let out = '<div class="reg-choices" role="radiogroup" aria-label="Where you’ll stay"' + (state.errors['stay.type'] ? ' aria-invalid="true" aria-describedby="' + errId('stay.type') + '"' : '') + '>' + first3 + card('camper', 'Camper lot', camperSub) + card('elsewhere', 'Off campus', yfOnly() ? 'Home, family nearby, or day visits' : 'A motel, family nearby, or day visits') + '</div>' + err('stay.type');
    // Nothing else until the stay is chosen: its nights follow from the choice.
    if (!s.type) return out;
    if (s.type === 'yf') {
      // Rooming with is asked in Who's coming as soon as a hall is chosen; here too, beside the hall.
      const hy = named().filter(p => inHall(p));
      // Rooming with is asked once, in Who's coming (polish 3); here it's said on the hall line.
      const hallLine = p => (hy.length > 1 ? first(p.name) + ' · ' : '') + hallWord(p.yfHall) + (p.rooming ? ' · With ' + p.rooming : '');
      return out + hy.filter(p => p.rooming || hy.length > 1).map(p => '<p class="rf-hall">' + I.bed + '<span>' + escn(hallLine(p)) + '</span></p>').join('') +
        (C('yf_keys') ? '<p class="rf-hall">' + I.key + '<span>' + esc(C('yf_keys')) + '</span></p>' : '') + ageRule + nightsPart + perToggle +
        '<div class="reg-rows">' + linensRow() + '</div>' + noteField();
    }
    // Who's told when a room opens is the COA's choice of owner (never assumed to be Lodging).
    if (full && s.type === 'dorm') out += '<p class="rf-row">' + togAct('waitlist', state.waitlist, 'Join waitlist') + '</p>' + help('Nothing is charged · ' + (ownerOr('owner') ? 'The ' + ownerOr('owner') + ' contacts you if a room opens' : 'You’re contacted if a room opens'));
    if (s.type === 'elsewhere') {
      const dh = visitDays();
      out += '<fieldset class="reg-nights"' + (state.errors['stay.days'] ? ' aria-describedby="' + errId('stay.days') + '"' : '') + '><legend>Days here</legend><span class="reg-nights__row" style="--n:' + Math.min(6, dh.length) + '">' + dh.map(x => { const on = s.days.indexOf(x.date) > -1; return '<label class="reg-night' + (on ? ' is-on' : '') + '"><input type="checkbox" name="stay.day" value="' + esc(x.date) + '"' + (on ? ' checked' : '') + '><span>' + I.check + '<i>' + esc(x.name.slice(0, 3)) + '</i><b>' + esc(O.fmtDate(x.date, 'mdShort')) + '</b></span></label>'; }).join('') + '</span></fieldset>' + err('stay.days') + help('For the meal counts');
      if (s.perPerson) out += '<p class="rf-q">Young Folks’ nights</p>' + perGrid();
      out += perToggle.replace('Nights per person', 'Young Folks’ nights');
    } else out += nightsPart + perToggle;
    if (s.type === 'dorm') {
      const sl = sleepers().length, over = sl > s.rooms * beds(), extra = sl - s.rooms * (beds() - 1);
      out += '<div class="reg-rows"><div class="reg-row"><span><b>Rooms</b><small>Up to ' + beds() + ' people a room' + (sl ? ' · ' + plural(sl, 'person', 'people') + ' in your rooms' : '') + '</small></span>' + stepper('stay.rooms', s.rooms, 1, 6, 'Rooms') + '</div>' +
        (state.errors['stay.rooms'] || over ? '<p class="rf-err" id="' + errId('stay.rooms') + '">' + esc(sl + ' people need ' + Math.ceil(sl / beds()) + ' rooms') + ' · <button type="button" class="rf-fix" data-act="userooms" data-v="' + Math.ceil(sl / beds()) + '">Use ' + Math.ceil(sl / beds()) + ' rooms</button></p>' : '') +
        bedsLine(over, extra) + linensRow() + (yfs().some(p => inHall(p)) ? ageRule : '') +
        pickRow() + detailsFold() + '</div>';
    }
    if (s.type === 'camper') {
      out += '<div class="reg-rows"><div class="reg-row"><span><b>Campers</b><small>' + esc(camperSub) + '</small></span>' + stepper('stay.campers', s.campers || 1, 1, 4, 'Campers') + '</div>' +
        '<div class="reg-row reg-row--wrap"><span><b>Length</b><small>Optional</small></span>' + radios('Camper length', 'len', s.camperLen, [['short', 'Under 25 ft'], ['mid', '25–35 ft'], ['long', 'Over 35 ft']]) + '</div></div>' +
        field('Group name', 'stay.near', s.near, { optional: true, attrs: ' maxlength="60"', help: 'Campers with the same group name park together' }) + arriveRow() + noteField();
    }
    if (yfOnly() && s.type === 'elsewhere') out += noteField();
    // Young Folks in the halls from a family in a camper or off campus: their linens (in a dorm room
    // they're in the household's one Linens row).
    const lin = s.type !== 'dorm' && !yfOnly() ? linensRow() : '';
    if (lin) out += '<div class="reg-yf"><p class="rf-label">Young Folks</p>' + ageRule + '<div class="reg-rows reg-rows--flush">' + lin + '</div></div>';
    if (s.type === 'elsewhere' && C('nearby_lodging')) out += help('Nearby: ' + C('nearby_lodging').split('|').join(' · '));
    return out;
  }
  // Beds, right under Rooms: one more person than beds asks for an air mattress; one ordered that isn't
  // needed (a Reuse from last year) says so. While Room details is open, its stepper says it all.
  function bedsLine(over, extra) {
    const s = state.d.stay;
    if (over || !C('mattress_price') || state.ui.details) return '';
    const need = Math.max(0, extra);
    if (s.mattresses > need) return '<p class="rf-help rf-help--row">' + escn(plural(s.mattresses, 'air mattress', 'air mattresses') + ' · Not needed') + ' · <button type="button" class="rf-fix" data-act="mattress" data-v="' + need + '">Remove</button></p>';
    if (need > 0 && s.mattresses < need) return '<p class="rf-help rf-help--row">' + escn(plural(need, 'more person', 'more people') + ' than beds') + ' · <button type="button" class="rf-fix" data-act="mattress" data-v="' + need + '">Add air mattress' + (need > 1 ? 'es' : '') + '</button></p>';
    return '';
  }
  // The days worth coming for: those with meals or something on the schedule (polish 3: check-out
  // morning, with nothing on, was offered).
  function visitDays() {
    const on = new Set(state.meals.map(mealDate));
    ((state.model && state.model.days) || []).forEach(x => { if ((x.items || []).length) on.add(x.date); });
    const list = state.days.filter(x => on.has(x.date));
    return list.length ? list : state.days;
  }
  // What a Young Folk's hall costs a night (the server's yf_charge: a share of a room, a room, or a price).
  const yfPer = () => { const yfc = C('yf_charge') || 'share'; return yfc === 'person' ? cents('yf_price') : yfc === 'room' ? cents('room_price') : Math.round(cents('room_price') / Math.max(1, +C('room_beds') || 2)); };
  // Linens, asked once for the whole household (polish 2: the rooms, then Levi, then Anna, each with its
  // own choice and its own "Choose one"): Bring our own · Order packets. Packets: one pill a sleeper
  // (each in the rooms, each Young Folk in a hall), all chosen to start; the count follows. A missing
  // choice is said inside the row, above its rule.
  function linensRow() {
    const s = state.d.stay, who = linenPeople(), L = state.F.left || {};
    if (!who.length) return '';
    const req = C('linens_required') === 'yes' && s.type === 'dorm', one = named().length === 1, hallToo = who.some(p => inHall(p));
    const low = L.linens != null && L.linens <= 10 ? (L.linens === 0 ? ' · None left' : ' · Only ' + L.linens + ' left') : '';
    const sub = (req ? 'One each in the rooms · ' : 'Beds come bare · ') + $(cents('linen_price')) + ' a packet' + low;
    const choice = req && !hallToo ? '' : radios('Linens', 'linenchoice', s.linenChoice, [['own', one ? 'Bring my own' : 'Bring our own'], ['order', one ? 'Order a packet' : 'Order packets']], '', 'stay.linenChoice');
    const pick = !one && (s.linenChoice === 'order' || req) ? '<span class="rf-asks rf-linwho" role="group" aria-label="Linen packets for">' + who.map(p => togAct('linfor', hasPacket(p), first(p.name), ' data-pid="' + p.pid + '"' + (req && !inHall(p) ? ' disabled' : ''))).join('') + '</span>' : '';
    return '<div class="reg-row reg-row--wrap" data-k="linens"><span><b>Linens</b><small>' + escn(sub) + '</small></span>' + choice + err('stay.linenChoice') + pick + '</div>';
  }
  // Keys, mattresses, requests, a group name, arriving, a note: one line until it's needed.
  function detailsFold() {
    const s = state.d.stay, L = state.F.left || {}, open = state.ui.details || ['stay.mattresses'].some(k => state.errors[k]);
    if (!open) return '<div class="reg-row reg-row--fold"><span><b>Room details</b><small>' + escn(detailsLine(false) || 'Keys, requests, arriving') + '</small></span><button type="button" class="wk-linklike" data-act="details" aria-expanded="false">Change</button></div>';
    const ok = adults(), dup = n => ok.filter(p => first(p.name) === first(n)).length > 1;
    // Stock only when it's running low.
    const leftT = n => n == null || n > 10 ? '' : n === 0 ? ' · None left' : ' · Only ' + n + ' left';
    return '<div class="reg-fold" data-k="fold">' + whoWhere() +
      (ok.length && s.type === 'dorm' ? '<div class="reg-row reg-row--wrap"><span><b>Keys</b><small>Only the person named picks up a room’s keys</small></span><div class="rf-keys">' + s.keys.map((k, i) => '<div class="rf-keyroom"><span>Room ' + (i + 1) + '</span>' + radios('Room ' + (i + 1) + ' keys', 'key', k, ok.map(p => [p.name.trim(), dup(p.name) ? firstL(p.name) : first(p.name)]), ' data-i="' + i + '"') + '</div>').join('') + '</div></div>' : '') +
      (C('mattress_price') ? '<div class="reg-row"><span><b>Air mattresses</b><small>' + esc($(cents('mattress_price')) + leftT(L.mattresses)) + '</small></span>' + stepper('stay.mattresses', s.mattresses, 0, Math.max(s.mattresses, Math.min(6, L.mattresses == null ? 6 : L.mattresses)), 'Air mattresses') + '</div>' + err('stay.mattresses') : '') +
      '<div class="reg-row reg-row--wrap"><span><b>Requests</b><small>Optional</small></span><span class="rf-asks">' + tog('stay.ground', s.ground, 'Ground floor') + tog('stay.walker', s.walker, 'Walker or wheelchair') + tog('stay.nearW', s.nearW, 'Near the women’s restroom') + tog('stay.nearM', s.nearM, 'Near the men’s restroom') + '</span></div>' +
      field('Group name', 'stay.near', s.near, { optional: true, attrs: ' maxlength="60"', help: 'Households with the same group name are placed near each other' }) +
      arriveRow() + noteField() +
      '<p class="rf-quiet"><button type="button" class="wk-linklike" data-act="details" aria-expanded="true">Done</button></p></div>';
  }
  // Who the arrival time is for follows the stay: the keys for a dorm room, the camper host at the lot.
  const arriveRow = () => '<div class="reg-row reg-row--wrap"><span><b>Arriving</b><small>' + (state.d.stay.type === 'camper' ? 'Optional · For the camper host' : 'Optional · For the keys') + '</small></span>' + radios('Arriving', 'arrive', state.d.stay.arrive, [['afternoon', 'Afternoon'], ['evening', 'Evening'], ['late', 'After 9 PM']]) + '</div>';
  const noteField = () => field('Note', 'stay.needs', state.d.stay.needs, { area: true, optional: true, ph: ownerOr('owner') ? 'Anything the ' + ownerOr('owner') + ' should know' : 'Anything to know for your stay', help: ownerOr('owner') ? 'Seen by the ' + ownerOr('owner') : '' });

  /* ---------------------------------------------------------------- 4 · Meals */

  // Meals: a line a day, a pill a meal (on: served to the household). "Not everyone at a meal" asks
  // who misses meals: one person at a time, and only their meals (polish 1: 13 meals × 3 names of
  // pills was more than 4,000 px of choices on a phone).
  function mealsSec() {
    const d = state.d, list = mealsHere(), ppl = named(), per = state.ui.mealWho;
    if (!list.length) return '<p class="rf-hint">No meals on your days</p>';
    const byDay = ms => { const out = []; ms.forEach(m => { let g = out.find(x => x.date === mealDate(m)); if (!g) out.push(g = { date: mealDate(m), items: [] }); g.items.push(m); }); return out; };
    const short = m => String(m.title).replace(/^(Breakfast|Lunch|Supper|Dinner).*$/i, '$1');
    const priced = C('meals_free') === 'no';
    const dayRow = (g, inner, k) => '<div class="rf-mday" data-k="' + k + g.date + '"><p class="rf-mname">' + esc(O.fmtDate(g.date, 'weekdayShort')) + '<small>' + esc(O.fmtDate(g.date, 'mdShort')) + '</small></p><div class="rf-mlist">' + g.items.map(inner).join('') + '</div></div>';
    // While one person's meals are open, the household's grid folds to its line (polish 2: two identical
    // grids, one meaning "served", the other "eats", made 1,300 px of pills at 390).
    let out = '<p class="reg-sum">' + escn(summaryText()) + (priced ? '' : ' · Provided') + '</p>' + (C('sunday_supper_note') ? help(C('sunday_supper_note')) : '') +
      (per && ppl.length > 1 ? '' : '<div class="rf-meals">' + byDay(list).map(g => dayRow(g, m => { const on = !d.meals.off[m.id], who = d.meals.who[m.id]; return '<div class="rf-meal" data-k="m-' + m.id + '">' + togAct('meal', on, short(m) + (on && who ? ' · ' + who.length + ' of ' + ppl.length : ''), ' data-id="' + esc(m.id) + '"') + '</div>'; }, 'md-')).join('') + '</div>');
    if (ppl.length > 1 && per) {
      const missed = p => list.filter(m => !d.meals.off[m.id] && personDays(p, d).indexOf(mealDate(m)) > -1 && !eats(p, m, d)).length;
      const pick = ppl.find(p => p.pid === state.ui.mealP);
      // The question says what a tick means (polish 3: "Who misses meals?" over ticks that mean "eats").
      // People are plain names (no tick), so they don't look like meals.
      out += '<div class="rf-mper" data-k="mper"><p class="rf-q">Meals each person eats</p><p class="rf-row">' + radios('Meals each person eats', 'mealp', pick ? pick.pid : '', ppl.map(p => { const n = missed(p); return [p.pid, first(p.name) + (n ? ' · ' + n + ' missed' : '')]; }), '', '', null, true) + '</p>';
      if (pick) {
        const theirs = list.filter(m => !d.meals.off[m.id] && personDays(pick, d).indexOf(mealDate(m)) > -1);
        out += '<p class="rf-q rf-q--sub">' + esc(first(pick.name) + '’s meals') + '</p>' + help('Untick any ' + first(pick.name) + ' will miss') + '<div class="rf-meals" role="group" aria-label="' + esc(first(pick.name) + '’s meals') + '">' + (theirs.length ? byDay(theirs).map(g => dayRow(g, m => '<div class="rf-meal" data-k="mp-' + m.id + '">' + togAct('mealwho', eats(pick, m, d), short(m), ' data-id="' + esc(m.id) + '" data-pid="' + pick.pid + '"') + '</div>', 'mpd-')).join('') : '<p class="rf-hint">No meals on their days</p>') + '</div>';
      }
      out += '</div>';
    }
    return out + (ppl.length > 1 ? '<p class="rf-quiet"><button type="button" class="wk-linklike" data-act="mealper" aria-expanded="' + !!per + '">' + (per ? 'Done' : 'Not everyone at a meal') + '</button></p>' : '');
  }
  // One meals phrase everywhere: "All 13 meals" or "11 of 13 meals".
  const summaryText = d => { d = d || state.d; const all = mealsHere(d), off = all.filter(m => d.meals.off[m.id]).length; return !all.length ? 'No meals' : off ? (all.length - off) + ' of ' + plural(all.length, 'meal') : 'All ' + plural(all.length, 'meal'); };

  /* ---------------------------------------------------------------- 5 · Preteens */

  function preteenSec() {
    const d = state.d, pts = named().filter(p => p.preteen), ok = adults(), pd = ptDays();
    const someone = !!state.ui.pickOther || !!d.pickupOther;
    return '<div class="reg-row reg-row--wrap"><span><b>Picked up by</b><small>Who may check them in and pick them up</small></span><span class="rf-asks">' +
      ok.map(p => togAct('pickup', !d.pickupWho.length || d.pickupWho.indexOf(p.name.trim()) > -1, first(p.name), ' data-v="' + esc(p.name.trim()) + '"')).join('') + togAct('pickother', someone, 'Someone else') + '</span></div>' +
      (someone ? field('Someone else', 'pickupOther', d.pickupOther, { attrs: ' maxlength="120"', ph: 'Name and relationship' }) : '') +
      // One label rule (polish 2): uppercase only for a group's heading; every question bold, in sentence
      // case; a person's name in the face names have everywhere.
      pts.map(p => { const pt = d.preteens[p.pid] || (d.preteens[p.pid] = { medical: '', days: pd.slice() }); return '<div class="reg-pt" data-k="pt-' + p.pid + '"><p class="rf-pname">' + esc(p.name) + '</p>' +
        (pd.length ? '<div class="rf-pline rf-pline--opts"><span class="rf-plabel" aria-hidden="true">Days</span><span class="rf-asks" role="group" aria-label="' + esc(first(p.name) + '’s days') + '">' + pd.map(x => togAct('ptday', (pt.days || []).indexOf(x) > -1, x.slice(0, 3), ' data-pid="' + p.pid + '" data-v="' + esc(x) + '"')).join('') + '</span></div>' : '') +
        field('Allergies, medical needs', 'preteens.' + p.pid + '.medical', pt.medical || '', { area: true, optional: true }) +
        '<p class="rf-help rf-help--i">' + esc(ownerOr('ptOwner') ? 'Seen by the ' + ownerOr('ptOwner') : 'Private') + info('pt-' + p.pid, 'Who sees this', 'Your household · The webmasters · ' + (ownerOr('ptOwner') ? 'The ' + ownerOr('ptOwner') : 'Those the COA names') + ' · Not other households') + '</p></div>'; }).join('') +
      '<p class="rf-label rf-label--h">Emergency contacts</p>' + help('If you can’t be reached') +
      // One contact required, a second optional (until the Preteens committee answers question 39).
      d.contacts.map((c, j) => '<div class="reg-contact" data-k="c-' + j + '"><p class="rf-q">Contact ' + (j + 1) + (j ? ' <span class="reg-opt">(optional)</span>' : '') + '</p><div class="reg-grid reg-grid--3">' +
        field('Name', 'contacts.' + j + '.name', c.name, { attrs: ' maxlength="80"' }) + field('Phone', 'contacts.' + j + '.phone', c.phone, { type: 'tel', attrs: ' maxlength="30"' }) + field('Relationship', 'contacts.' + j + '.rel', c.rel, { optional: true, attrs: ' maxlength="40"', ph: 'Aunt, neighbor…' }) + '</div></div>').join('');
  }

  /* ---------------------------------------------------------------- 6 · Payment */

  // The money after a change, as the server will work it out (ogc_reg_rebalance): a check still to come
  // shrinks first, then what was paid past the new total is refunded (until the refund date); more owed is
  // paid by card, added to the check, or due at check-in. Paid and promised are never added together.
  function moneyNow() {
    const ed = state.editing, p = state.override || priceOf(state.d, ed && ed.data.price && ed.data.price.prices), t = p.total_cents;
    if (!ed) return { price: p, total: t, paid: 0, check: 0, newCheck: 0, refund: 0, refundWas: 0, due: t, over: 0 };
    const m = ed.data.money || {}, paid = m.paid || 0, check = m.check || 0, pending = m.pending || 0;
    let newCheck = check, committed = paid + check + pending;
    if (t < committed && check) { newCheck = check - Math.min(committed - t, check); committed = paid + newCheck + pending; }
    const over = Math.max(0, committed - t), refund = ed.can.refund ? over : (m.refund || 0), owed = Math.max(0, t - committed);
    if (owed && state.d.pay === 'check') newCheck += owed;
    return { price: p, total: t, paid, check, newCheck, refund, refundWas: m.refund || 0, due: state.d.pay === 'check' ? 0 : owed, over, wasTotal: ed.data.price.total_cents };
  }
  // A change's payment rows: received, the check to come (and what it becomes), a refund, what's due.
  function changeRows(M) {
    const ed = state.editing;
    return [M.paid > 0 ? ['Paid', M.paid] : null,
      M.check || M.newCheck ? ['Check to come', M.check !== M.newCheck ? (M.check ? $(M.check) + ' → ' : '') + (M.newCheck ? $(M.newCheck) : 'Not needed') : $(M.newCheck)] : null,
      M.refund > 0 ? [M.refund !== M.refundWas ? 'Refund' : 'Refund requested', M.refund, { sum: true }] : null,
      M.over > 0 && !ed.can.refund ? ['No refund after ' + O.fmtDate(C('refunds_by'), 'md'), M.over] : null,
      M.due > 0 ? [state.d.pay === 'checkin' ? 'Due at check-in' : 'Balance', M.due, { sum: true }] : null];
  }
  // Payment reads in the order it's paid (polish 2): what's owed and the total first, then how to pay
  // and the check's details, then a quiet "Add a gift" that opens its box at the bottom. While the box
  // is open the gift is in the total but has no line of its own, so typing changes only the Total figure
  // above it and nothing moves.
  function paySec() {
    const d = state.d, M = moneyNow(), t = M.total, ed = state.editing;
    const giftOn = C('gift_for') !== 'none' && !state.waitlist, giftOpen = giftOn && (state.ui.gift || (ed && ed.data.gift) || +d.gift > 0);
    const lines = M.price.lines.filter(l => !(giftOpen && l.key === 'gift'));
    const gift = !giftOn ? '' : giftOpen ? '<div class="reg-field reg-money" data-k="gift"><label class="reg-label" for="f-gift">Gift <span class="reg-opt">(optional)</span></label><span class="reg-money__in"><span aria-hidden="true">$</span><input id="f-gift" name="gift" type="text" inputmode="numeric" pattern="[0-9]*" maxlength="5" value="' + esc(d.gift ? String(d.gift) : '') + '" aria-describedby="help-gift"></span><span class="rf-help" id="help-gift">' + esc('For ' + (C('gift_for') || 'the Conference fund') + (ed && ed.data.gift ? ' · Can be raised, not lowered' : '')) + '</span></div>'
      : '<p class="rf-quiet" data-k="gift"><button type="button" class="wk-linklike" data-act="gift" aria-expanded="false">Add a gift</button></p>';
    const table = ledger(lines.map(l => [l.label, l.cents]).concat([lines.length ? null : ['No charge', '—'], ['Total', t, { sum: true }]], ed ? changeRows(M) : []));
    const owe = ed ? M.due > 0 || M.newCheck > M.check : t > 0;
    const choices = payChoices().concat(ed && !payOk(d.pay) && d.pay ? [[d.pay, d.pay === 'checkin' ? 'At check-in' : d.pay === 'check' ? 'Check' : 'Card']] : []);
    const method = owe && !state.waitlist ? (choices.length > 1 ? '<div class="reg-row reg-row--pay"><span><b>Pay by</b></span>' + radios('Pay by', 'payby', d.pay, choices, '', 'pay') + err('pay') + '</div>' : '') : '';
    const check = owe && d.pay === 'check' && !state.waitlist ? checkBox(ed ? M.newCheck : t, false) : '';
    const atDesk = owe && d.pay === 'checkin' && !state.waitlist ? '<p class="reg-fine">' + I.key + '<span>' + esc('Pay at check-in' + (C('checkin_place') ? ' · ' + C('checkin_place') : '')) + '</span></p>' : '';
    const fine = owe && d.pay === 'card' && !state.waitlist ? '<p class="reg-fine">' + I.lock + '<span>Card details go to the payment provider, never this site</span></p>' : '';
    const refund = C('refunds_by') && (d.stay.nights.length) && t > 0 ? help('Refund requests until ' + O.fmtDate(C('refunds_by'), 'md')) : '';
    // A parent asked to approve: who approves, and what a decline means for the money. A Young Folk alone:
    // the whole registration; in a family's (a grandmother asking a parent), only the young people's share.
    let parent = '';
    if (!ed && !state.desk && emailOk(d.stay.parentEmail)) {
      const to = d.stay.parentEmail.trim();
      if (minorsAlone()) parent = to + ' approves · Cancelled if declined';
      else if (adults().length && d.stay.ask) {
        const who = named().filter(p => p.minor && inHall(p)), share = who.reduce((k, p) => k + nightsFor(p, d).length * yfPer() + (p.linens ? cents('linen_price') : 0), 0);
        const pron = who.length > 1 ? 'Their' : who[0] && who[0].yfHall === 'women' ? 'Her' : 'His';
        if (who.length) parent = to + ' approves ' + who.map(p => first(p.name)).join(' and ') + ' · ' + pron + ' ' + $(share) + ' comes off if declined';
      }
      if (parent) parent = '<p class="reg-fine">' + I.mail + '<span>' + escn(parent) + '</span></p>';
    }
    if (state.desk) return table + (t > 0 ? '<div class="reg-row reg-row--pay"><span><b>Paid at the desk</b></span>' + radios('Paid at the desk', 'deskpaid', state.d.deskPaid || '', [['cash', 'Cash'], ['check', 'Check'], ['card', 'Card'], ['', 'Not yet']]) + '</div>' : '') + gift;
    return table + parent + method + check + atDesk + fine + refund + gift;
  }
  // Check instructions: the amount, payee and address (its first line left out when it only repeats the
  // payee), the date it must arrive by, and the registration number.
  const checkAddress = () => { const a = C('check_address').split('|').map(x => x.trim()).filter(Boolean); if (a.length && a[0].toLowerCase() === C('check_payee').trim().toLowerCase()) a.shift(); return a; };
  function checkBox(cents_, rid) {
    return '<div class="reg-check">' + I.mail + '<div><p><b>' + esc(rid ? 'Mail a check for ' + $(cents_) : 'Check by mail · ' + $(cents_)) + '</b></p>' + (C('check_payee') ? '<p>Payable to ' + esc(C('check_payee')) + '</p>' : '') + (checkAddress().length ? '<p>' + checkAddress().map(esc).join('<br>') + '</p>' : '') +
      (C('check_by') ? '<p>Arrives by ' + esc(O.fmtDate(C('check_by'), 'md')) + '</p>' : '') + (rid ? '<p>Write <b>' + esc(rid) + '</b> on it</p>' : '<p class="rf-help">Write your registration number on it</p>') + '</div></div>';
  }

  /* ---------------------------------------------------------------- the bar: the total and the one next thing */

  // Is the email this registration goes to the one signed in on this device? (the desk needs none)
  const wantEmail = () => (state.d.helper.on ? state.d.helper.email : state.d.household.email).trim().toLowerCase();
  const verified = () => { const me = SU.me(); return state.desk || !!(me && !me.pending && me.email.toLowerCase() === wantEmail()); };
  function barView(preview) {
    const ed = state.editing, M = moneyNow();
    let btn, left = '';
    // A total only once there's something to price (the stay chosen): never "$0" before a choice.
    const priced = ed || ((state.open === 'stay' || isDone('stay') || state.open === 'pay') && !!state.d.stay.type);
    const changed = editChanged();
    const sum = (k, v) => '<p class="reg-bar__t"><small>' + esc(k) + '</small><b data-k="bar-total">' + esc(v) + '</b></p>';
    // A change says only what moves money: a refund, what's due, or the check's new amount; never the
    // amount again on the button.
    if (priced) left = ed && changed ? (M.refund > M.refundWas ? sum('Refund', $(M.refund)) : M.due > 0 ? sum(state.d.pay === 'checkin' ? 'Due at check-in' : 'Balance', $(M.due)) : M.newCheck !== M.check ? sum('Check to come', (M.check ? $(M.check) + ' → ' : '') + (M.newCheck ? $(M.newCheck) : 'Not needed')) : sum('Total', $(M.total))) : sum('Total', $(M.total));
    const b = (act, label, o) => '<button type="button" class="wk-btn' + (o && o.cls ? ' ' + o.cls : '') + '" data-act="' + act + '"' + (state.busy || (o && o.dis) ? ' disabled' : '') + '>' + (o && o.icon && !state.busy ? o.icon : '') + esc(state.busy ? 'Processing…' : label) + '</button>';
    if (state.open && state.open !== 'pay') btn = b('next', 'Continue');
    else if (preview) btn = b('noop', 'Preview', { dis: true });
    else if (ed) btn = !changed ? b('noop', 'No changes', { dis: true }) : M.due > 0 && state.d.pay === 'card' ? b('save', 'Pay', { icon: I.lock }) : b('save', 'Save');
    else if (!verified()) btn = b('confirmemail', 'Confirm email');
    else if (state.waitlist) btn = b('register', 'Join waitlist');
    else btn = M.total > 0 && state.d.pay === 'card' ? b('register', 'Pay', { icon: I.lock }) : b('register', 'Register');
    return '<div class="reg-bar" role="region" aria-label="' + (priced ? 'Total' : 'Next') + '"><div class="wk-wrap"><div class="reg-bar__in">' + (left || '<span></span>') +
      (state.barNote ? '<p class="reg-bar__note" role="status">' + esc(state.barNote) + '</p>' : '') + btn + '</div></div></div>';
  }
  // The answers that matter when comparing a change with what's saved.
  function cleanForCompare(d) {
    const x = settle(JSON.parse(JSON.stringify(d)));
    return { h: x.household, x: x.helper, p: x.people.filter(p => p.name.trim()).map(p => [p.name, p.kind, p.age, p.yfHall, p.nights, p.rooming, p.sleeps, p.linens, p.communing, p.ptOff, p.room]), s: x.stay, m: x.meals, pt: x.preteens, c: x.contacts, pw: x.pickupWho, po: x.pickupOther, g: +x.gift || 0 };
  }

  /* ================================================================ the map picker (when households choose rooms) */

  // Only when the COA lets households choose (room_choice = households) and Lodging has marked the year's
  // floor plans confirmed (plans_confirmed = yes): the sample floors must never look real.
  const famFloors = () => state.floors.filter(f => f.for === 'families');
  const roomBy = id => state.rooms.find(r => r.id === id);
  // A household's own posted room: its facts from the halls list, which a visitor's page isn't sent
  // (where people sleep stays with Lodging), so else from its id, "Reed Hall|301" (integration).
  const roomOf = id => roomBy(id) || (/^[^|]+\|[^|]+$/.test(String(id)) ? { id, hall: String(id).split('|')[0], num: String(id).split('|')[1], floor: null, beds: 2 } : null);
  const planHalls = () => Array.from(new Set(famFloors().map(f => f.hall))).filter(h => state.plans[h] && state.plans[h].list.length);
  const canChoose = () => C('room_choice') === 'households' && C('plans_confirmed') === 'yes' && planHalls().length > 0 && !!O.map;
  const floorWord = n => n === 1 ? 'ground floor' : ['', '', 'second', 'third', 'fourth', 'fifth'][n] ? ['', '', 'second', 'third', 'fourth', 'fifth'][n] + ' floor' : 'floor ' + n;
  function roomsWords(ids) {
    const by = [];
    ids.map(roomOf).filter(Boolean).forEach(r => { let g = by.find(x => x.hall === r.hall); if (!g) by.push(g = { hall: r.hall, nums: [], floors: new Set() }); g.nums.push(r.num); g.floors.add(r.floor); });
    return by.map(g => g.hall + ' ' + g.nums.join(', ') + (g.floors.size === 1 && Array.from(g.floors)[0] ? ', ' + floorWord(Array.from(g.floors)[0]) : '')).join(' · ');
  }
  const takenSet = () => { const t = {}; (state.F.taken || []).forEach(id => { t[id] = 1; }); ((state.editing && state.editing.data.stay.chosen) || []).forEach(id => { delete t[id]; }); return t; };
  function pickRow() {
    if (!canChoose()) return '';
    const c = (state.d.stay.chosen || []).filter(roomBy);
    return '<div class="reg-row reg-row--pick"><span><b>Your rooms</b><small>' + (c.length ? esc(roomsWords(c)) : esc(ownerOr('owner') ? 'Not chosen · The ' + ownerOr('owner') + ' assigns them' : 'Not chosen · Assigned for you')) + '</small></span><button type="button" class="wk-btn wk-btn--line wk-btn--small" data-act="pickrooms">' + I.pin + (c.length ? 'Change' : 'Choose rooms') + '</button></div>';
  }
  const mapDlg = document.createElement('dialog');
  mapDlg.className = 'ogc reg-mapdlg';
  mapDlg.setAttribute('aria-labelledby', 'reg-map-t');
  document.body.appendChild(mapDlg);
  function openPicker() {
    const s = state.d.stay, sel = (s.chosen || []).filter(roomBy), f0 = roomBy(sel[0]), halls = planHalls();
    state.mp = { sel: sel.slice(), hall: f0 ? f0.hall : halls[0], floor: f0 ? f0.floor : 0, focus: sel[0] || '', full: '' };
    drawPicker(); mapDlg.showModal();
    const g = mapDlg.querySelector('.pl-room.is-sel, .pl-room[role="button"]'); if (g) g.focus();
  }
  function drawPicker() {
    const s = state.d.stay, m = state.mp, t = takenSet(), halls = planHalls(), narrow = matchMedia('(max-width: 759px)').matches;
    const P = state.plans[m.hall], fl = P.list.find(f => f.floor === m.floor) || P.list[0];
    m.floor = fl.floor;
    const held = r => r.floor === 1 && !s.ground && !s.walker;
    const st = sh => { const r = roomBy(sh.id); return m.sel.indexOf(sh.id) > -1 ? 'sel' : !r ? 'off' : t[sh.id] ? 'taken' : held(r) ? 'held' : 'free'; };
    const free = list => list.filter(sh => st(sh) === 'free').length;
    const words = { sel: 'yours', off: 'unavailable', taken: 'taken', held: 'reserved', free: 'free' };
    const label = (sh, x) => 'Room ' + sh.label + ', ' + words[x] + ', ' + ((roomBy(sh.id) || {}).beds || 2) + ' beds';
    const hallBtns = '<div class="reg-halls" role="group" aria-label="Hall">' + halls.map(h => '<button type="button" data-mphall="' + esc(h) + '" aria-pressed="' + (h === m.hall) + '"><b>' + esc(h) + '</b><small>' + free([].concat.apply([], state.plans[h].list.map(f => f.rooms))) + ' free</small></button>').join('') + '</div>';
    const floorBtns = '<div class="reg-floors" role="group" aria-label="Floor">' + P.list.map(f => '<button type="button" data-mpfloor="' + f.floor + '" aria-pressed="' + (f.floor === fl.floor) + '">' + esc(f.floor === 1 ? 'Ground floor' : 'Floor ' + f.floor) + '<small>' + free(f.rooms) + ' free</small></button>').join('') + '</div>';
    const legend = '<ul class="reg-legend" aria-hidden="true"><li><i class="is-free"></i>Free</li><li><i class="is-sel"></i>Yours</li><li><i class="is-taken"></i>Taken</li>' + (fl.floor === 1 && !s.ground ? '<li><i class="is-held"></i>Reserved</li>' : '') + '</ul>';
    const n = m.sel.length;
    mapDlg.innerHTML = '<div class="reg-mapdlg__in"><header class="reg-mapdlg__bar"><div><p class="wk-kicker">' + esc(state.year + ' · ' + (state.model.settings.venue || '')) + '</p><h2 id="reg-map-t">Choose rooms</h2></div><button type="button" class="wk-sheet__x" data-mapclose aria-label="Close without saving">' + I.x + '</button></header>' +
      '<div class="reg-mapdlg__body"><aside class="reg-mapdlg__side">' + hallBtns + '</aside><section class="reg-mapdlg__main" aria-label="' + esc(m.hall) + '">' + floorBtns + legend +
      '<div class="reg-plan">' + O.map.floorSvg(fl, { state: st, label, pick: true, turn: O.map.turnFor(fl, narrow), px: narrow ? 3 : 0, beds: sh => (roomBy(sh.id) || {}).beds || 2, title: m.hall + ', ' + floorWord(fl.floor) }) + '</div></section></div>' +
      '<footer class="reg-mapdlg__foot"><p class="reg-mapdlg__sum"><b>' + n + ' of ' + plural(s.rooms, 'room') + '</b>' + (n ? ' · ' + esc(roomsWords(m.sel)) : '') + '</p>' + (m.full ? '<p class="reg-mapdlg__full">Limit reached</p>' : '') +
      '<p class="reg-mapdlg__btns">' + (n ? '<button type="button" class="wk-linklike" data-mpclear>Clear</button>' : '') + '<button type="button" class="wk-btn" data-mapdone>' + I.check + 'Done</button></p></footer></div>';
    O.map.reveal(mapDlg.querySelector('.reg-plan'), m.focus || m.sel.find(id => fl.rooms.some(r => r.id === id)));
  }
  function tapRoom(id) {
    const m = state.mp, s = state.d.stay, t = takenSet(), r = roomBy(id), i = m.sel.indexOf(id);
    m.focus = id; m.full = '';
    if (i > -1) m.sel.splice(i, 1);
    else if (r && !t[id] && !(r.floor === 1 && !s.ground && !s.walker)) { if (m.sel.length < s.rooms) m.sel.push(id); else m.full = id; }
    drawPicker();
    const g = mapDlg.querySelector('[data-room="' + CSS.escape(id) + '"]'); if (g) g.focus();
  }
  // Done keeps the choice; × and Escape leave it as it was.
  function closePicker(save) {
    if (save) { state.d.stay.chosen = state.mp.sel.slice(); tell(state.mp.sel.length ? 'Rooms: ' + roomsWords(state.mp.sel) : 'Rooms not chosen'); }
    mapDlg.close(); update();
    const b = root.querySelector('[data-act="pickrooms"]'); if (b) b.focus();
  }
  mapDlg.addEventListener('click', e => {
    const b = e.target.closest('[data-mapclose], [data-mapdone], [data-mphall], [data-mpfloor], [data-mpclear], [data-room]');
    if (!b) return;
    const m = state.mp, ds = b.dataset;
    if (b.hasAttribute('data-mapclose')) closePicker(false);
    else if (b.hasAttribute('data-mapdone')) closePicker(true);
    else if (ds.mphall) { m.hall = ds.mphall; m.floor = 0; m.focus = ''; drawPicker(); }
    else if (ds.mpfloor) { m.floor = +ds.mpfloor; m.focus = ''; drawPicker(); }
    else if (b.hasAttribute('data-mpclear')) { m.sel = []; m.focus = ''; drawPicker(); }
    else if (ds.room) tapRoom(ds.room);
  });
  mapDlg.addEventListener('keydown', e => { const g = e.target.closest && e.target.closest('[data-room][role="button"]'); if (g && (e.key === 'Enter' || e.key === ' ')) { e.preventDefault(); tapRoom(g.dataset.room); } });
  mapDlg.addEventListener('cancel', e => { e.preventDefault(); closePicker(false); });

  /* ================================================================ registered: the receipt */

  // A registration's name: one person alone is named ("Caleb Yoder"); else "Hoover household".
  const regName = d => { const ppl = (d.people || []).filter(p => String(p.name || '').trim()); return ppl.length === 1 ? ppl[0].name.trim() : SU.householdName(d); };
  // From a week before the Conference, a parent's approval still waiting is settled at check-in.
  const nearStart = () => !!(state.row && state.row.start && today() >= O.isoAddDays(state.row.start, -7));
  const STATUS = { registered: 'Registered', payment_due: 'Payment due', balance_due: 'Balance due', check_to_come: 'Check to come', refund_due: 'Refund requested', waitlist: 'Waitlist', cancelled: 'Cancelled' };
  function statusWords(it) {
    const d = it.data, m = d.money || {}, ap = d.approval;
    const a = [STATUS[d.status] || 'Registered'];
    if (d.status === 'registered' && m.paid > 0) a[0] = 'Paid ' + $(m.paid);
    if ((d.status === 'payment_due' || d.status === 'balance_due') && (d.pay === 'checkin' || lateIn(m))) a[0] = 'Due at check-in · ' + $(m.due || 0);
    // Only what's still open: an approval given isn't an exception any more (polish 3), and one held
    // back while a card payment is open hasn't been sent.
    if (ap && ap.state === 'waiting' && !ap.held) a.push(nearStart() ? 'Approval needed at check-in' : 'Waiting for parent');
    // Held while a card payment is open: said, so a Young Folk knows the parent hears once it's paid.
    else if (ap && ap.state === 'waiting' && ap.held && d.status !== 'cancelled') a.push('Parent asked once paid');
    // Nothing about rooms until they're posted (a status about something that hasn't happened is noise).
    if (d.status !== 'cancelled' && it.rooms && it.rooms.length) a.push('Rooms posted');
    return a.join(' · ');
  }
  // The stay in a line. listed: the people are listed just above (each with their hall), so the halls
  // aren't said again; else a family's Young Folks are named with theirs ("Levi in the Young men's hall").
  function stayWords(d, listed) {
    const s = d.stay;
    const halls = listed ? [] : d.people.filter(p => p.yf && inHall(p, d)).map(p => first(p.name) + ' in the ' + hallWord(p.yfHall));
    // Off campus: its days only when there are some (never a dangling "Off campus ·").
    if (s.type === 'elsewhere') return ['Off campus', (s.days || []).map(x => O.fmtDate(x, 'weekdayShort')).join(', ')].filter(Boolean).join(' · ') + (halls.length ? ' · ' + halls.join(', ') : '');
    const ns = s.nights || [], span = spanOf(ns) + '\u00a0·\u00a0' + plural(ns.length, 'night');
    if (s.type === 'yf') return Array.from(new Set(d.people.map(p => hallWord(p.yfHall)))).join(', ') + ' · ' + span;
    return (s.type === 'camper' ? 'Camper lot · ' + span : plural(s.rooms, 'dorm room') + ' · ' + span) + (halls.length ? ' · ' + halls.join(', ') : '');
  }
  function checkCard(it) {
    const m = it.data.money || {};
    if (m.check) return checkBox(m.check, it.rid);
    // Past check_by with no check received: where it's due, with the key (never "Mail a check").
    if (lateIn(m) && m.due > 0) return '<div class="reg-check">' + I.key + '<div>' + (C('checkin_place') ? '<p><b>' + esc(C('checkin_place')) + '</b></p>' : '') + (C('check_by') ? '<p>' + escn('No check received by ' + O.fmtDate(C('check_by'), 'md')) + '</p>' : '') + '</div></div>';
    return '';
  }
  // Paid, declined or cancelled at the provider's checkout: a line at the top (with Try again).
  const payBanner = () => state.payNote ? '<p class="rf-banner' + (state.payNote.bad ? ' is-bad' : '') + '" role="status">' + (state.payNote.bad ? I.info : I.check) + '<span>' + esc(state.payNote.text) + '</span>' + (state.payNote.retry ? ' <button type="button" class="wk-btn wk-btn--small" data-act="paydue" data-id="' + state.payNote.retry + '">Try again</button>' + (state.payNote.check && !state.F.late ? '<button type="button" class="wk-linklike" data-act="paycheck" data-id="' + state.payNote.retry + '">Pay by check</button>' : '') : '') + '</p>' : '';
  const METHOD = { card: 'Card', check: 'Check', cash: 'Cash' };
  // What's been received, from the ledger: date · how · amount (refunds sent as minus).
  function paymentRows(it) {
    return (it.ledger || []).filter(p => p.status === 'paid' || (p.kind === 'refund' && p.status === 'sent')).map(p => [shortDate(p.at) + ' · ' + (p.kind === 'refund' ? 'Refund' : (METHOD[p.method] || 'Paid') + (p.kind === 'desk' ? ' at the desk' : '')), p.kind === 'refund' ? -p.cents : p.cents]);
  }
  // Registered: how ever it was paid (card, check, at check-in), the same page: the status, the ID,
  // the receipt, a check's details, then one filled Add to Calendar and the Helping out ask.
  function doneView() {
    const it = state.done;
    if (!it) return page(hero('Registration', { facts: false }), SU.me() && !SU.me().pending ? blankCard('Not found', mineLink()) : signinCard());
    const d = it.data, m = d.money || {}, ap = d.approval, signupsOpen = (state.model.settings.signups_posted || '9999') <= today();
    const dorm = signupsOpen && dormAskFor(d);
    const who = state.desk ? d.household.contact : d.helper && d.helper.on ? d.helper.name : d.household.contact;
    const paidRows = paymentRows(it);
    // Said once each: the status in the header, the payments in their table, the check in its box.
    const rows = d.price.lines.map(l => [l.label, l.cents]).concat([['Total', d.price.total_cents, { sum: true }]], moneyRows(m, d).filter(r => r && !(paidRows.length && r[0] === 'Paid') && !(m.check && r[0] === 'Check to come')));
    // The header is the form's own (dates, place, the year's photo), with the thank-you as its title.
    // A card cancelled or declined with money still due: the title says what's true (not a thank-you
    // for something unfinished), and Try again is the one filled button.
    const unpaid = !!(state.payNote && state.payNote.bad && state.payNote.retry);
    const H = hero(state.desk ? 'Registered' : unpaid ? 'Registered · Payment due' : 'Thank you, ' + (first(who) || 'friend'), { photo: true, sub: '<p class="reg-done__st">' + escn(statusWords(it)) + '</p>' });
    return page(H, (state.payNote && state.payNote.bad ? payBanner() : '') + '<section class="reg-done">' +
      '<div class="rf-receipt"><p class="rf-receipt__id"><span>' + esc(it.rid) + '</span><button type="button" class="wk-linklike" data-act="copy" data-v="' + esc(it.rid) + '">' + I.copy + esc(state.ui.copied || 'Copy') + '</button></p>' +
      '<p>' + escn(regName(d) + (d.people.length > 1 ? ' · ' + plural(d.people.length, 'person', 'people') : '')) + '</p><p>' + escn(stayWords(d)) + '</p>' +
      (linenWords(d) ? '<p>' + escn(linenWords(d)) + '</p>' : '') +
      (d.price.lines.length ? ledger(rows, 'Receipt') : '') +
      (paidRows.length ? '<p class="rf-q">Payments</p>' + ledger(paidRows, 'Payments') : '') +
      ((it.data.helper && it.data.helper.on && it.data.helper.email) || d.household.email ? '<p class="rf-help">Confirmation sent to ' + esc(it.data.helper && it.data.helper.on && it.data.helper.email ? it.data.helper.email : d.household.email) + '</p>' : '') + '</div>' +
      checkCard(it) +
      approvalLine(it) + (ap && ap.state === 'waiting' && !ap.held ? flashOf(it.id) : '') +
      (state.desk ? '' :
      '<p class="wk-sheet__btns"><button type="button" class="' + (unpaid ? 'wk-linklike' : 'wk-btn') + '" data-act="ics" data-id="' + it.id + '">' + (unpaid ? '' : I.cal) + 'Add to Calendar</button><a class="wk-linklike" href="?year=' + esc(state.year) + '&view=mine">Your sign-ups</a>' + '</p>') +
      (state.desk || !signupsOpen ? '' : '<div class="rf-next"><p class="rf-next__k">' + I.hand + 'Helping out</p><p>' + esc(dorm ? C('dorm_ask') : 'Volunteer shifts are open') + '</p><p class="rf-next__btns"><a class="wk-btn wk-btn--line wk-btn--small" href="' + esc(shiftsHref(dorm)) + '">Find a shift</a></p></div>') +
      '</section>');
  }

  // The COA's own ask of households with Young Folks in the halls (dorm_ask, their words; blank: none),
  // opening the committee they chose (dorm_committee). The site makes up no rule and assumes no owner
  // (polish 3: it matched /young folks/ and /dorm/ in the shifts).
  const dormAskFor = d => !!C('dorm_ask') && d.people.some(p => p.yf && inHall(p, d)) && d.people.some(p => p.kind === 'adult');
  const shiftsHref = ask => '../volunteer/?year=' + encodeURIComponent(state.year) + (ask && C('dorm_committee') ? '&committee=' + encodeURIComponent(C('dorm_committee')) : '');

  /* ================================================================ Your sign-ups */

  // One door (signin area, Oct 10): the server sends anyone not signed in from Your sign-ups to the
  // site's one sign-in page (same words, same limits) before this draws. Should it ever show, it's that
  // page's button.
  function signinCard() {
    return '<section class="rf-signin"><p class="wk-sheet__btns"><a class="wk-btn" href="' + esc(window.OGC_AUTH ? OGC_AUTH.signinUrl() : (W.signin || '../signin/')) + '">Sign in</a></p></section>';
  }

  // A shift's time as the volunteer page writes it ("2–6 PM").
  const shiftTime = sh => O.formatRange ? O.formatRange(sh.start, sh.end, { compact: true }) : SU.span(sh);
  const myShifts = () => { const me = SU.me(); return me && !me.pending ? (SU.load('signups', state.year, []) || []).filter(u => SU.sameEmail(u.email, me.email)).map(u => ({ u, sh: state.shifts.find(x => x.id === u.id) })).filter(x => x.sh) : []; };
  const myTeams = () => { const me = SU.me(); return me && !me.pending ? (SU.load('teams', state.year, []) || []).filter(t => SU.sameEmail(t.email, me.email)) : []; };

  function personLine(p, d, it) {
    const bits = [];
    // Sentence case, as every line around it (polish 3).
    if (p.kind === 'child') bits.push(p.age !== '' ? 'Age ' + p.age : 'Child');
    if (p.yf) bits.push(inHall(p, d) ? hallWord(p.yfHall) : 'With family');
    if (p.rooming) bits.push('With ' + p.rooming);
    if (p.minor && inHall(p, d)) bits.push('Under 18');
    if (p.preteen) bits.push('Preteen');
    if (p.communing) bits.push('Communing');
    if (d.stay.perPerson && (p.nights || []).length && (p.nights || []).length !== (d.stay.nights || []).length) bits.push(spanOf(p.nights));
    return '<li><b>' + esc(p.name) + '</b>' + (bits.length ? '<small>' + escn(bits.join(' · ')) + '</small>' : '') + '</li>';
  }
  function regCard(it) {
    const d = it.data, m = d.money || {}, held = it.phase === 'held', y = esc(state.year), s = d.stay;
    // A past year: the header already says when it was held; the card says only what's true of it.
    if (held) {
      const st = [d.people.length > 1 ? plural(d.people.length, 'person', 'people') : '', m.paid ? 'Paid ' + $(m.paid) : ''].filter(Boolean).join(' · ');
      return '<section class="rf-card" data-k="r-' + it.id + '"><h2 class="rf-card__h">' + I.bed + esc(regName(d)) + '</h2>' + (st ? '<p class="rf-card__st">' + escn(st) + '</p>' : '') +
        '<p class="rf-card__btns"><span class="rf-card__links"><a class="wk-linklike" href="?year=' + y + '&view=receipt&id=' + it.id + '">Receipt</a></span></p></section>';
    }
    // A part with three lines or more folds; one or two are shown as they are (no tap to read one line).
    const part = (title, lines) => !lines.length ? '' : lines.length >= 3 ? '<details class="rf-fold"><summary><span>' + esc(title) + '</span></summary><div class="rf-fold__b">' + lines.map(l => '<p>' + escn(l) + '</p>').join('') + '</div></details>'
      : '<div class="rf-part"><p class="rf-part__k">' + esc(title) + '</p>' + lines.map(l => '<p>' + escn(l) + '</p>').join('') + '</div>';
    // The household reading its own page: first names (full names only on the receipt), as the form says them.
    const extras = [s.type === 'dorm' && (s.keys || []).length ? 'Keys: ' + (s.keys || []).map(first).join(', ') : '', linenWords(d), s.mattresses ? plural(s.mattresses, 'air mattress', 'air mattresses') : '', [s.ground ? 'Ground floor' : '', s.walker ? 'Walker or wheelchair' : '', s.nearW ? 'Near the women’s restroom' : '', s.nearM ? 'Near the men’s restroom' : ''].filter(Boolean).join(', '), s.near ? 'Group: ' + s.near : '', s.arrive ? ARRIVE[s.arrive] : '', s.needs ? 'Note: ' + s.needs : ''].filter(Boolean);
    const pts = d.people.filter(p => p.preteen);
    // The ledger only when something is owed, promised or coming back; else the status says it ("Paid $340").
    // A check to come is said once, in its box with the address.
    const mrows = moneyRows(m, d).filter(r => r && !(m.check && r[0] === 'Check to come') && !(lateIn(m) && r[0] === 'Due at check-in'));
    const money = mrows.length && ((m.due > 0 && !lateIn(m)) || m.check > 0 || m.refund > 0 || m.refunded > 0) ? ledger([['Total', m.total || 0]].concat(mrows), 'Payment') : '';
    const ap = d.approval, live = d.status !== 'cancelled';
    // During the week the card is about being here (polish 2): the filled action is the guide, and
    // Add to Calendar goes away. Before, it's Pay what's due, else Add to Calendar. The rest are quiet.
    const during = !!(state.row && state.row.start && today() >= state.row.start && today() <= (state.row.end || state.row.start));
    const pay = it.can.pay && it.can.card;
    const main = pay ? '<button type="button" class="wk-btn wk-btn--small" data-act="paydue" data-id="' + it.id + '">' + I.lock + 'Pay ' + esc($(m.due - (m.check || 0))) + '</button>'
      : live && during ? '<a class="wk-btn wk-btn--small" href="../guide/?year=' + y + '">Open the guide</a>'
      : live ? '<button type="button" class="wk-btn wk-btn--small" data-act="ics">' + I.cal + 'Add to Calendar</button>' : '';
    const links = [
      // Paying by check stays a choice beside the card (it was only in the one-time banner after a
      // cancelled checkout; a Young Folk with no card had no way back to it).
      it.can.pay && !state.F.late ? '<button type="button" class="wk-linklike" data-act="paycheck" data-id="' + it.id + '">Pay by check</button>' : '',
      it.can.change ? '<a class="wk-linklike" href="?year=' + y + '&view=edit&id=' + it.id + '">Change</a>' : '',
      '<a class="wk-linklike" href="?year=' + y + '&view=receipt&id=' + it.id + '">Receipt</a>',
      it.can.leave ? '<button type="button" class="wk-linklike" data-act="leave" data-id="' + it.id + '">Leave early</button>' : '',
      // Cancel lives at the bottom of the Change page; here only when there's no Change.
      it.can.cancel && !it.can.change ? '<button type="button" class="wk-linklike" data-act="cancelreg" data-id="' + it.id + '">Cancel registration</button>' : ''
    ].filter(Boolean).join('');
    const listed = d.people.length > 1;
    return '<section class="rf-card" data-k="r-' + it.id + '"><h2 class="rf-card__h">' + I.bed + esc(regName(d)) + '<small>' + esc(it.rid) + '</small></h2>' + flashOf(it.id) +
      // The status once, at the top; a parent's approval adds only where it went and Resend.
      '<p class="rf-card__st">' + escn(statusWords(it)) + '</p>' +
      approvalLine(it) +
      // One person: the card's title already names them; only what's true of them follows.
      (listed ? '<ul class="rf-people-l">' + d.people.map(p => personLine(p, d, it)).join('') + '</ul>' : '') +
      '<p class="rf-card__line">' + escn(stayWords(d, listed)) + '</p>' +
      part('Room details', extras) +
      part('Meals', [summaryText(answersOf(d))]) +
      part('Preteens', pts.length ? [pts.map(p => first(p.name)).join(', ') + ' · Picked up by ' + pickupOf(d)].concat((d.contacts || []).some(c => c.name) ? ['Contacts: ' + d.contacts.filter(c => c.name).map(c => c.name + (c.rel ? ' (' + c.rel + ')' : '')).join(', ')] : []) : []) +
      money + checkCard(it) + '<div class="rf-card__btns">' + main + (links ? '<span class="rf-card__links">' + links + '</span>' : '') + '</div></section>' + yourRooms(it.rooms || []);
  }
  // Where a parent's approval went, in full (the household typed it; polish 3: masked, a typo couldn't be
  // seen), with Resend and Change (just that address, and a new link). Nothing while it's held back for
  // a card payment still open.
  function approvalLine(it) {
    const ap = it.data.approval;
    if (!ap || ap.state !== 'waiting' || ap.held || it.data.status === 'cancelled') return '';
    return '<p class="reg-wait">' + I.mail + '<span>' + esc('Approval sent to ' + ap.to) + ' · <button type="button" class="wk-linklike" data-act="resendapproval" data-id="' + it.id + '">Resend</button> · <button type="button" class="wk-linklike" data-act="approvalto" data-id="' + it.id + '">Change</button></span></p>';
  }
  function approvalToSheet(id) {
    const it = (state.mine || []).find(x => x.id === id) || (state.done && state.done.id === id ? state.done : null);
    if (!it) return;
    openSheet('Parent’s email', '<div class="reg-field"><label class="reg-label" for="f-apto">Parent’s email</label><input id="f-apto" type="email" inputmode="email" maxlength="120" value="' + esc(it.data.approval.to) + '" aria-describedby="help-apto"><span class="rf-help" id="help-apto">A new link is sent · The old one stops working</span></div>',
      () => {
        const to = String(sheet.querySelector('#f-apto').value || '').trim();
        if (!emailOk(to)) return Promise.reject({ status: 400, message: 'Enter an email like name@example.com' });
        return api('POST', 'reg/r/' + id + '/approval', { to }).then(out => {
          state.flash = { id, text: 'Sent to ' + to };
          if (state.done && state.done.id === id) state.done = out.item;
          return state.view === 'done' ? null : loadMine();
        }).then(draw);
      }, 'Send', false, 'Cancel');
    setTimeout(() => { const i = sheet.querySelector('#f-apto'); if (i) { i.focus(); i.select(); } }, 30);
  }
  // Who may pick the preteens up, in first names ("Martha or John"), as the form says it.
  const pickupOf = d => [].concat((d.pickupWho || []).length ? d.pickupWho.map(first) : d.people.filter(p => p.kind === 'adult').map(p => first(p.name)), d.pickupOther ? [d.pickupOther] : []).join(' or ') || (d.pickup || '');
  // A line under a card after something was done to it ("Sent to the parent again"), or why it wasn't.
  const flashOf = id => state.flash && state.flash.id === id ? '<p class="rf-flash' + (state.flash.bad ? ' is-bad' : '') + '" role="' + (state.flash.bad ? 'alert' : 'status') + '">' + (state.flash.bad ? I.info : I.check) + '<span>' + esc(state.flash.text) + '</span></p>' : '';
  function mineView() {
    const me = SU.me();
    if (!me || me.pending) return page(hero('Your sign-ups', { facts: false }), signinCard());
    const sub = '<p class="rf-who">' + esc(me.email) + ' · <button type="button" class="wk-linklike" data-act="signout">Sign out</button></p>';
    if (state.mineErr) return page(hero('Your sign-ups', { sub, photo: true }), blankCard('Couldn’t load', '', '<button type="button" class="wk-btn wk-btn--line wk-btn--small" data-act="retry">Retry</button>'));
    const items = (state.mine || []).filter(it => it.data.status !== 'cancelled' || state.ui.showCancelled), cancelled = (state.mine || []).filter(it => it.data.status === 'cancelled');
    const shifts = myShifts(), teams = myTeams(), F = state.F, held = F.phase === 'held';
    // Everyone on these shifts is one person: their name isn't repeated on each.
    const oneName = new Set(shifts.map(x => x.u.name)).size <= 1;
    const signupsOpen = (state.model.settings.signups_posted || '9999') <= today();
    const banner = payBanner();
    const cards = items.map(regCard).join('') +
      (cancelled.length && !state.ui.showCancelled ? '<p class="rf-quiet"><button type="button" class="wk-linklike" data-act="showcancelled">' + esc(plural(cancelled.length, 'cancelled registration')) + '</button></p>' : '');
    const none = !items.length ? (F.phase === 'open' ? '<section class="rf-card"><h2 class="rf-card__h">' + I.bed + 'Lodging and meals</h2><p class="rf-card__btns"><a class="wk-btn wk-btn--small" href="?year=' + esc(state.year) + '">Register</a></p></section>' : '') : '';
    const another = items.length && F.phase === 'open' ? '<p class="rf-quiet rf-another"><a href="?year=' + esc(state.year) + '&another=1">Register another</a></p>' : '';
    // Helping out says its one true thing: the dorm-shift ask for parents with Young Folks in the halls,
    // or that shifts are open (when this email has none yet).
    const dormAsk = items.some(it => it.data.status !== 'cancelled' && dormAskFor(it.data));
    const helpLine = held ? '' : dormAsk ? '<p class="rf-card__line">' + esc(C('dorm_ask')) + '</p>' : !shifts.length ? '<p class="rf-card__line">Volunteer shifts are open</p>' : '';
    // The same words as the volunteer page's Your shifts (volunteer area, Oct 11): the person first for a
    // household ("Esther · Server · Dining hall"), "Fri, May 28", and its Unconfirmed / Swap open tags.
    const help = shifts.length || (signupsOpen && !held) ? '<section class="rf-card"><h2 class="rf-card__h">' + I.hand + (shifts.length ? 'Your shifts' : 'Helping out') + '</h2>' + helpLine + (shifts.length ? '<ul class="rf-items">' + shifts.map(({ u, sh }) => '<li data-k="s-' + esc(sh.id + u.name) + '"><span><b>' + esc((oneName ? '' : String(u.name).split(' ')[0] + ' · ') + sh.role + (sh.role.toLowerCase() === sh.committee.toLowerCase() ? '' : ' · ' + sh.committee)) + '</b><small>' + escn([O.fmtDate(sh.day.date, 'short'), shiftTime(sh), sh.place ? sh.place.name : ''].filter(Boolean).join(' · ')) + '</small>' + [u.confirmed === false ? 'Unconfirmed' : '', u.swap ? 'Swap open' : ''].filter(Boolean).map(t => ' <small class="rf-tag">' + esc(t) + '</small>').join('') + '</span>' + (held ? '' : '<button type="button" class="wk-linklike" data-act="leaveshift" data-v="' + esc(sh.id + '|' + u.name) + '">Leave shift</button>') + '</li>').join('') + '</ul>' : '') +
      (held ? '' : '<p class="rf-card__btns"><a class="wk-btn wk-btn--line wk-btn--small" href="' + esc(shiftsHref(dormAsk)) + '">Find a shift</a></p>') + '</section>' : '';
    const tOpen = (state.model.settings.tournaments_posted || '') && state.model.settings.tournaments_posted <= today();
    const tourn = teams.length || (tOpen && items.some(it => it.data.people.some(p => p.yf))) ? '<section class="rf-card"><h2 class="rf-card__h">' + I.trophy + 'Tournaments</h2>' + (teams.length ? '<ul class="rf-items">' + teams.map(t => '<li><span><b>' + esc(t.team || (t.players || [])[0] || '') + '</b><small>' + esc((t.players || []).join(', ')) + '</small></span></li>').join('') + '</ul>' : '') +
      '<p class="rf-card__btns"><a class="wk-btn wk-btn--line wk-btn--small" href="../tournaments/?year=' + esc(state.year) + (teams.length ? '&view=mine' : '') + '">' + (teams.length ? 'Change' : 'Sign up a team') + '</a></p></section>' : '';
    // Add to Calendar is the registration card's own action; with shifts only, it's under them.
    const during = !!(state.row && state.row.start && today() >= state.row.start && today() <= (state.row.end || state.row.start));
    const cal = !held && !during && !items.some(it => it.data.status !== 'cancelled') && shifts.length ? '<p class="rf-cal"><button type="button" class="wk-btn wk-btn--line wk-btn--small" data-act="ics">' + I.cal + 'Add to Calendar</button></p>' : '';
    const nothing = !items.length && !shifts.length && !none && !tourn && !help ? blankCard(held ? 'Nothing for ' + state.year : 'Nothing yet', '') : '';
    return page(hero('Your sign-ups', { sub, photo: true }), banner + '<div class="rf-cards">' + cards + none + help + tourn + '</div>' + cal + nothing + another);
  }

  // Your rooms on their floor, once Lodging posts them.
  function yourRooms(ids) {
    const rs = ids.map(roomOf).filter(Boolean);
    if (!rs.length) return '';
    const r = rs[0], P = O.map && state.plans[r.hall], fl = P && r.floor != null && P.floors[r.floor];
    if (!fl) return '<section class="rf-card"><h2 class="rf-card__h">' + I.key + 'Your rooms</h2><p class="rf-rooms__h">' + esc(roomsWords(ids)) + '</p></section>';
    const narrow = matchMedia('(max-width: 759px)').matches, st = sh => ids.indexOf(sh.id) > -1 ? 'mine' : roomBy(sh.id) ? 'free' : 'off';
    return '<section class="rf-card rf-card--rooms"><h2 class="rf-card__h">' + I.key + 'Your rooms</h2><p class="rf-rooms__h">' + esc(roomsWords(ids)) + '</p>' +
      '<div class="rf-rooms__plan" data-own>' + O.map.floorSvg(fl, { state: st, turn: O.map.turnFor(fl, narrow), px: narrow ? 3 : 0, beds: sh => (roomBy(sh.id) || {}).beds || 2, title: r.hall + ', ' + floorWord(r.floor) + ': your rooms' }) + '</div></section>';
  }

  // A receipt to print or keep: who issued it, the number, who, what, the charges, the payments
  // received (date · how · amount), what's still to come. One page on paper.
  function receiptView() {
    const it = (state.mine || []).find(x => String(x.id) === q.get('id'));
    if (!it) return page(hero('Receipt', { facts: false }), SU.me() && !SU.me().pending ? blankCard('Not found', mineLink()) : signinCard());
    const d = it.data, m = d.money || {}, paidRows = paymentRows(it);
    // On screen: the site's cream band and a white card (polish 3: it looked like plain HTML); on paper
    // the band and card fall away and it prints as before. The dates a treasurer needs: registered, issued.
    const issued = 'Registered ' + longDate(d.at || (d.created || '').slice(0, 10)) + ' · Issued ' + longDate(today());
    return '<div class="wk reg reg-print"><header class="wk-hero reg-print__band"><div class="wk-wrap"><div class="wk-hero__text vol-hero"><p class="wk-kicker">' + esc(state.year) + ' Annual Conference</p><h1 class="vol-title">Receipt <span class="reg-print__id">' + esc(it.rid) + '</span></h1>' +
      '<p class="reg-print__dates">' + escn(issued) + '</p></div></div></header>' +
      '<section class="wk-main"><div class="wk-wrap"><div class="reg-wrap"><div class="rf-card reg-print__card">' +
      '<p class="reg-print__where">' + escn(O.fmtDateSpan(state.row.start, state.row.end) + ' · ' + (state.model.settings.venue || '')) + '</p>' +
      '<h2 class="rf-pname">' + esc(regName(d)) + '</h2><ul class="rf-people-l">' + d.people.map(p => personLine(p, d, it)).join('') + '</ul><p>' + escn(stayWords(d, true)) + '</p>' +
      (linenWords(d) ? '<p>' + escn(linenWords(d)) + '</p>' : '') +
      (d.stay.type === 'dorm' && (d.stay.keys || []).length ? '<p>Keys: ' + esc((d.stay.keys || []).join(', ')) + '</p>' : '') + (it.rooms && it.rooms.length ? '<p>Rooms: ' + esc(roomsWords(it.rooms)) + '</p>' : '') +
      ledger(d.price.lines.map(l => [l.label, l.cents]).concat([['Total', m.total || 0, { sum: true }]]), 'Charges') +
      (paidRows.length ? '<h2 class="rf-q">Payments</h2>' + ledger(paidRows.concat([['Paid', m.paid || 0, { sum: true }]]), 'Payments') : '') +
      ledger(moneyRows(m, d).filter(r => r && r[0] !== 'Paid'), 'Still to come') +
      '<p class="reg-print__by">' + esc('Issued by the ' + state.year + ' Committee of Arrangements, Old German Baptist Brethren Church, New Conference') + '</p></div>' +
      '<p class="rf-card__btns reg-noprint reg-print__btns"><button type="button" class="wk-btn" data-act="print">' + I.print + 'Print</button><a class="wk-linklike" href="?year=' + esc(state.year) + '&view=mine">Your sign-ups</a></p></div></div></section></div>';
  }
  // "March 2, 2027": a date a treasurer files by.
  const longDate = iso => iso ? O.fmtDate(iso, 'mdy') : '';

  /* ================================================================ a parent's approval */

  // A parent's approval: who registered their child first (so the email's link is plainly expected),
  // then the child's hall, nights and roommate, their own cost only, Approve (filled) or Decline (quiet,
  // confirmed in a sheet that says what is cancelled and refunded).
  // The parent's link: the server moves its token into a short cookie and opens a clean address
  // (?approve=1), so it isn't kept in history or sent on to other sites.
  function approveToken() {
    const v = q.get('approve') || '';
    if (v !== '1') return v;
    const m = /(?:^|;\s*)ogc_approve=([^;]+)/.exec(document.cookie);
    return m ? decodeURIComponent(m[1]) : '';
  }
  function approveView() {
    const A = state.approve, yfo = ownerOr('yfOwner');
    if (!A) return page(hero('Approval', { facts: false }), blankCard('Link expired', esc('Ask the person who registered' + (yfo ? ', or the ' + yfo : ''))));
    const yf = A.who, names = yf.map(p => first(p.name)).join(' and ');
    // One date format in the area: "Sat Oct 10" (polish 2: the approved state said "October 10").
    // The answer once, with what follows (polish 3: "Declined" was said twice).
    const whose = yf.length === 1 ? first(yf[0].name) + '’s registration is cancelled' : 'The registration is cancelled';
    const done = A.state === 'approved' ? blankCard(escn('Approved · ' + shortDate(A.at)), escn(names + ' · ' + A.rid)) : A.state === 'declined' ? blankCard('Declined', escn((A.status === 'cancelled' ? whose : names + (yf.length > 1 ? ' come' : ' comes') + ' off the registration') + (A.refund ? ' · Refund requested · ' + $(A.refund) : ''))) : '';
    const rows = A.lines.map(l => [l.label, l.cents]).concat(A.lines.length > 1 ? [['Total', A.total, { sum: true }]] : [], A.alone ? moneyRows({ paid: A.paid, check: A.check, due: A.due }, null) : []);
    // What's being approved, plainly, under the title (the email's own line).
    const what = yf.map(p => first(p.name) + ' staying in the ' + p.hall).join(' · ') + ' · Under 18';
    return page(hero(done ? 'Approval' : 'Approve ' + names, { facts: true, sub: done ? '' : '<p class="reg-approve__what">' + escn(what) + '</p>' }), done ||
      ('<p class="reg-preview">' + I.info + '<span><b>Registered by ' + esc(A.by) + '</b> · ' + esc(A.rid) + '</span></p>' +
        '<section class="rf-card"><ul class="rf-people-l">' + yf.map(p => '<li><b>' + esc(p.name) + (p.age ? ', ' + esc(p.age) : '') + '</b><small>' + escn(p.hall + (p.rooming ? ' · Rooming with ' + p.rooming : p.rooming_other ? ' · A roommate they named' : '')) + '</small><small>' + escn('Check-in ' + shortDate(p.from) + ' · Check-out ' + shortDate(p.to) + ' · ' + plural(p.nights.length, 'night')) + '</small></li>').join('') + '</ul>' +
        (A.keys ? '<p class="rf-hall">' + I.key + '<span>' + esc(A.keys) + '</span></p>' : '') +
        (rows.length ? ledger(rows, 'Cost') : '') + (A.alone ? '' : '<p class="rf-card__st">' + esc(A.covered) + '</p>') +
        (A.questions ? '<p class="rf-help">' + esc('Questions: ' + A.questions) + '</p>' : '') +
        (state.approveErr ? '<p class="rf-err" role="alert">' + esc(state.approveErr) + '</p>' : '') +
        '<p class="rf-card__btns"><button type="button" class="wk-btn" data-act="approve" data-v="approve">' + I.check + 'Approve</button><button type="button" class="wk-linklike" data-act="approve" data-v="decline">Decline</button></p></section>'));
  }

  /* ================================================================ the test checkout (local only) */

  function checkoutView() {
    const P = state.checkout;
    if (!P) return page(hero('Checkout', { facts: false }), blankCard('Not found', mineLink()));
    if (P.status !== 'pending') return page(hero('Checkout', { facts: false }), blankCard(P.status === 'paid' ? 'Paid' : 'Closed', mineLink()));
    return page(hero('Checkout', { facts: false }), '<section class="rf-card reg-checkout"><p class="wk-kicker">Test checkout</p><h2 class="wk-h">Pay ' + esc($(P.cents)) + '</h2><p>' + esc(P.rid) + '</p>' +
      '<p class="ogc-mock ogc-mock--tag">Local · The payment provider’s checkout page goes here</p>' +
      '<p class="rf-card__btns"><button type="button" class="wk-btn" data-act="testpay" data-v="paid">' + I.card + 'Pay (test)</button><button type="button" class="wk-btn wk-btn--line" data-act="testpay" data-v="declined">Decline (test)</button><button type="button" class="wk-linklike" data-act="testpay" data-v="cancelled">Cancel</button></p></section>');
  }

  const VIEWS = { form: formView, edit: formView, mine: mineView, done: doneView, receipt: receiptView, approve: approveView, checkout: checkoutView, error: () => page(hero('Register', { facts: false }), blankCard('Couldn’t load', '', '<button type="button" class="wk-btn wk-btn--line wk-btn--small" data-act="reload">Retry</button>')) };

  /* ================================================================ input */

  function setPath(path, value) {
    const parts = path.split('.'), d = state.d;
    if (parts[0] === 'people') { const p = d.people.find(x => x.pid === parts[1]); if (p) p[parts[2]] = value; return; }
    if (parts[0] === 'preteens') { const o = d.preteens[parts[1]] || (d.preteens[parts[1]] = { medical: '', days: ptDays() }); o[parts[2]] = value; return; }
    let o = d;
    for (let i = 0; i < parts.length - 1; i++) o = o[isNaN(parts[i]) ? parts[i] : +parts[i]];
    o[parts[parts.length - 1]] = value;
  }
  const clearErr = path => { delete state.errors[path]; };

  root.addEventListener('input', e => {
    const t = e.target;
    if (!t.name || t.type === 'checkbox' || t.type === 'radio') return;
    if (t.name === 'verify.code') { state.verify.code = t.value.replace(/\D/g, '').slice(0, 6); state.verify.err = ''; if (state.verify.code.length === 6) verifyCode(); return; }
    if (t.name === 'signin.code') { state.signin.code = t.value.replace(/\D/g, '').slice(0, 6); state.signin.err = ''; if (state.signin.code.length === 6) signinCode(); return; }
    if (t.name === 'signin.email') { state.signin.email = t.value; return; }
    if (!state.d) return;
    if (t.name === 'gift') { if (/\D/.test(t.value)) t.value = t.value.replace(/\D/g, ''); state.d.gift = Math.max(0, Math.min(5000, parseInt(t.value, 10) || 0)); }
    else if (/\.age$/.test(t.name)) { if (/\D/.test(t.value)) t.value = t.value.replace(/\D/g, '').slice(0, 3); setPath(t.name, t.value); }
    else setPath(t.name, t.value);
    clearErr(t.name);
    if (/email$/.test(t.name)) { state.verify.err = ''; if (t.name !== 'stay.parentEmail' && state.verify.step === 'sent' && state.verify.email !== wantEmail()) state.verify.step = ''; }
    state.barNote = '';
    peopleChanged(() => {});
  });
  root.addEventListener('change', e => {
    const t = e.target;
    if (!t.name || !state.d) return;
    const s = state.d.stay;
    if (t.name === 'stay.night') { const n = new Set(s.nights); if (t.checked) n.add(t.value); else n.delete(t.value); s.nights = nights().filter(x => n.has(x)); clearErr('stay.nights'); }
    else if (t.name === 'stay.day') { const n = new Set(s.days); if (t.checked) n.add(t.value); else n.delete(t.value); s.days = state.days.map(x => x.date).filter(x => n.has(x)); clearErr('stay.days'); }
    else if (t.type === 'checkbox') { setPath(t.name, t.checked); clearErr(t.name); }
    else return;
    update();
  });
  // A change in who's coming can change a finished Where you'll stay: mark it, and say what changed.
  function peopleChanged(fn) {
    state.override = null;
    const s = state.d.stay, before = { rooms: s.rooms, keys: s.keys.join('|') };
    fn();
    settle();
    if (isDone('stay') && state.open !== 'stay' && s.type === 'dorm') {
      // Against the rooms the stay had before any of these changes (2 → 1 → 2 is no change at all).
      const base = state.roomsBase != null ? state.roomsBase : before.rooms;
      if (base !== s.rooms) { state.roomsBase = base; state.check.stay = 'Rooms ' + base + ' → ' + s.rooms; }
      else if (/^Rooms /.test(state.check.stay || '')) { delete state.check.stay; state.roomsBase = null; }
      else if (before.keys !== s.keys.join('|') && !state.check.stay) state.check.stay = 'Keys changed';
    }
    keep(); draw();
  }

  // A ten-digit phone is written 555-555-0142 when the field is left.
  root.addEventListener('focusout', e => {
    const t = e.target;
    if (!state.d || !t.name || t.type !== 'tel') return;
    const f = fmtPhone(t.value);
    if (f !== t.value) { t.value = f; setPath(t.name, f); keep(); draw(); }
  });

  root.addEventListener('submit', e => {
    if (e.target.matches('[data-form="signin"]')) { e.preventDefault(); signinSend(); }
  });

  // Return moves to the next box; on the last name it adds a person; on the last box it continues.
  root.addEventListener('keydown', e => {
    const t = e.target;
    if (t.getAttribute && t.getAttribute('role') === 'radio' && /^Arrow(Left|Right|Up|Down)$/.test(e.key)) {
      const g = t.closest('[role="radiogroup"]'), all = Array.from(g.querySelectorAll('[role="radio"]:not([disabled])')), i = all.indexOf(t), n = all[(i + (/Left|Up/.test(e.key) ? -1 : 1) + all.length) % all.length];
      e.preventDefault(); if (n) { n.click(); const again = root.querySelector('[data-act="' + n.dataset.act + '"][data-v="' + CSS.escape(n.dataset.v) + '"]' + (n.dataset.pid ? '[data-pid="' + n.dataset.pid + '"]' : '') + (n.dataset.i != null ? '[data-i="' + n.dataset.i + '"]' : '')); if (again) again.focus(); }
      return;
    }
    if (e.key !== 'Enter' || t.tagName !== 'INPUT' || t.type === 'checkbox') return;
    if (t.name === 'verify.code') { e.preventDefault(); verifyCode(); return; }
    if (t.name === 'signin.code') { e.preventDefault(); signinCode(); return; }
    if (t.name === 'signin.email') return;
    e.preventDefault();
    const sec = t.closest('.rf-body');
    if (!sec) return;
    const boxes = Array.from(sec.querySelectorAll('input:not([type="checkbox"]):not([type="radio"]):not([readonly]), textarea')), i = boxes.indexOf(t);
    const names = Array.from(sec.querySelectorAll('.rf-name input'));
    if (names.length && t === names[names.length - 1] && t.value.trim()) { act({ dataset: { act: 'add' } }); return; }
    if (boxes[i + 1]) boxes[i + 1].focus(); else { const n = root.querySelector('[data-act="next"]'); if (n) n.click(); }
  });

  root.addEventListener('click', e => {
    const b = e.target.closest('[data-act]');
    if (!b || b.disabled) return;
    act(b);
  });

  // Every button: what it does, by its data-act.
  function act(b) {
    const ds = b.dataset, d = state.d, a = ds.act, P = () => d.people.find(p => p.pid === ds.pid);
    const focusAfter = sel => { const el = sel && root.querySelector(sel); if (el && !el.disabled) el.focus({ preventScroll: true, focusVisible: el.classList.contains('rf-h') ? false : undefined }); };
    const same = () => '[data-act="' + a + '"]' + (ds.pid ? '[data-pid="' + ds.pid + '"]' : '') + (ds.v != null ? '[data-v="' + CSS.escape(ds.v) + '"]' : '') + (ds.i != null ? '[data-i="' + ds.i + '"]' : '') + (ds.id != null ? '[data-id="' + CSS.escape(ds.id) + '"]' : '') + (ds.path ? '[data-path="' + ds.path + '"][data-by="' + ds.by + '"]' : '');
    switch (a) {
      case 'info': state.ui['i-' + ds.id] = !state.ui['i-' + ds.id]; draw(); return focusAfter(same());
      case 'reload': return location.reload();
      case 'retry': state.mineErr = ''; return loadMine().then(draw);
      case 'another': state.another = true; draw(); return;
      case 'startnew': state.ui.skipReuse = true; state.open = 'contact'; draw(); return focusAfter('#rf-h-contact');
      case 'startover': return openSheet('Start over', '<p class="wk-sheet__note">Everything typed here is cleared</p>', () => { dropDraft(true); state.d = fresh(); state.open = 'contact'; state.errors = {}; state.check = {}; state.ui = {}; update(); setTimeout(() => focusAfter('#rf-h-contact'), 30); return Promise.resolve(); }, 'Start over', true, 'Cancel');
      case 'reuse': {
        const r = state.F.reuse[+ds.i];
        // Where you'll stay waits to be checked when a Young Folk under 18 needs approving again.
        const typed = state.d.household, owner = state.d.owner;
        state.d = Object.assign(answersOf(r.draft), { from: String(r.from), changes: r.changes, owner, finished: ['contact', 'meals'].concat(r.draft.people.some(p => p.minor && p.yf && p.sleeps !== 'family') ? [] : ['stay']) });
        // What was just typed at Contact wins over last year's.
        ['contact', 'phone', 'email'].forEach(k => { if (typed && String(typed[k] || '').trim()) state.d.household[k] = typed[k]; });
        state.d.contacts = blank().contacts;
        if (!payOk(state.d.pay)) state.d.pay = payChoices()[0][0];
        state.errors = {};
        // Contact is checked, never assumed (polish 3: the Hoovers' phone, cleared after 2026 as the
        // security plan says, came back blank, and Register threw them back to the top). Anything missing
        // opens Contact first, at the field; Who's coming is next.
        settle();
        const cp = problems('contact');
        if (Object.keys(cp).length) {
          if (cp['household.phone'] === 'Required' && r.cleared) cp['household.phone'] = 'Add this year’s';
          state.d.finished = state.d.finished.filter(k => k !== 'contact');
          state.open = 'contact'; state.errors = cp; update();
          scrollTo('#rf-h-contact'); focusProblem(); tell('From your ' + r.from + ' registration · ' + Object.values(cp)[0]);
          return;
        }
        state.open = 'people'; update();
        scrollTo('#rf-h-people'); tell('From your ' + r.from + ' registration · Check who’s coming');
        return;
      }
      // Signing out clears this tab's draft: the next person here mustn't see this household's answers.
      // Not you? on the form: signed out here, the draft cleared, a fresh form at Contact (the page stays).
      // Your sign-ups' Sign out goes through the site's sign-out.
      case 'signout': {
        if (state.view !== 'form') { dropDraft(); return SU.signOut(); }
        // A household typed past Contact is asked first (one tap threw it all away).
        const typed = state.d && !state.editing && (named().length > 1 || (state.d.finished || []).some(k => k !== 'contact'));
        if (typed && !ds.sure) return openSheet('Sign out', '<p>Everything typed here is cleared</p>', () => { const b = document.createElement('button'); b.dataset.act = 'signout'; b.dataset.sure = '1'; return act(b); }, 'Sign out', true, 'Keep');
        dropDraft();
        state.busy = true; draw();
        return api('POST', 'reg/signout').then(out => {
          W.me = null; W.nonce = out.nonce;
          try { localStorage.removeItem('ogc-me-pending'); } catch (x) { /* nothing kept */ }
          state.verify = { step: '', email: '', code: '', to: '', err: '', busy: false, dev: '', retryAt: 0 };
          state.another = false; state.errors = {}; state.check = {}; state.ui = {};
          return loadForm();
        }).then(() => {
          state.busy = false; state.d = fresh(); settle(); state.open = 'contact'; state.flashTop = 'Signed out';
          draw(); window.scrollTo(0, 0); tell('Signed out'); focusSoon('[name="household.contact"]');
          clearTimeout(state.flashTopT); state.flashTopT = setTimeout(() => { state.flashTop = ''; draw(); }, 4000);
        }, () => { state.busy = false; state.barNote = 'Not signed out · Try again'; draw(); });
      }
      case 'helper': {
        const on = ds.v === 'other';
        if (on === d.helper.on) return;
        if (on) { d.helper = { on: true, name: d.household.contact, phone: d.household.phone, email: d.household.email }; d.household = { name: '', contact: '', phone: '', email: '' }; d.people = d.people.filter(p => p.name.trim() && p.name.trim() !== d.helper.name.trim()); }
        else { d.household = { name: '', contact: d.helper.name, phone: d.helper.phone, email: d.helper.email }; d.helper = { on: false, name: '', phone: '', email: '' }; }
        state.errors = {}; update(); return focusAfter(same());
      }
      case 'typo': setPath(ds.path, ds.v); clearErr(ds.path); state.verify.typoAsked = ''; update(); tell('Email ' + ds.v); return focusAfter('[data-act="next"]');
      case 'open': {
        state.open = ds.sec; state.errors = {}; delete state.check[ds.sec]; if (ds.sec === 'stay') state.roomsBase = null; draw();
        scrollTo('#rf-h-' + ds.sec); return;
      }
      case 'next': return next();
      case 'addadult': {
        if (d.people.length >= MAXP) return;
        const np = person({ kind: 'adult' }); d.people.push(np); delete state.errors.people; state.undo = null; draw();
        return focusAfter('[name="people.' + np.pid + '.name"]');
      }
      case 'add': {
        if (d.people.length >= MAXP) return;
        d.people.push(person()); state.undo = null; draw();
        const ins = root.querySelectorAll('.rf-name input'); if (ins.length) ins[ins.length - 1].focus();
        return;
      }
      case 'remove': {
        const i = d.people.findIndex(p => p.pid === ds.pid);
        if (i < 0) return;
        const p = d.people[i];
        peopleChanged(() => { d.people.splice(i, 1); });
        state.undo = { p, i }; clearTimeout(state.undoT); state.undoT = setTimeout(() => { state.undo = null; draw(); }, 10000);
        draw(); tell('Removed ' + (first(p.name) || 'person') + ' · Undo');
        return focusAfter('[data-act="undo"]');
      }
      case 'undo': if (state.undo) { const u = state.undo; state.undo = null; peopleChanged(() => { d.people.splice(u.i, 0, u.p); }); tell('Restored ' + first(u.p.name)); focusAfter('[name="people.' + u.p.pid + '.name"]'); } return;
      case 'kind': { const p = P(); if (!p) return; peopleChanged(() => { p.kind = ds.v; if (ds.v === 'yf' && !p.yfHall) p.yfHall = ''; }); clearErr('people.' + p.pid + '.age'); draw(); return focusAfter(same()); }
      // Sleeps in. A Young Folk alone: a hall chooses the hall stay (the card is chosen for them, since it
      // follows from this answer); Off campus chooses that stay. The stay and this answer always agree.
      case 'hall': {
        const p = P(); if (!p) return;
        peopleChanged(() => {
          const s = d.stay;
          if (ds.v === 'family') p.sleeps = 'family';
          else if (ds.v === 'elsewhere' || ds.v === 'camper') { if (s.type !== ds.v) { s.type = ds.v; if (ds.v === 'elsewhere' && !s.days.length) s.days = visitDays().map(x => x.date); if (ds.v === 'camper' && !s.nights.length) s.nights = mainNights().slice(); } }
          else { p.sleeps = 'hall'; p.yfHall = ds.v; if (yfOnly() && s.type !== 'yf') { s.type = 'yf'; if (!s.nights.length) s.nights = mainNights().slice(); } }
        });
        clearErr('people.' + p.pid + '.yfHall'); clearErr('stay.type'); draw(); return focusAfter(same());
      }
      case 'approval': d.stay.yfOk = ds.v === 'self'; d.stay.ask = ds.v === 'ask'; clearErr('stay.yfOk'); clearErr('stay.parentEmail'); update(); return focusAfter(ds.v === 'ask' && !d.stay.parentEmail ? '[name="stay.parentEmail"]' : same());
      // Linens for the household: Order chooses a packet for everyone to start; a pill takes one away.
      case 'linenchoice': d.stay.linenChoice = ds.v; if (ds.v === 'order') linenPeople().forEach(p => { if (inHall(p)) p.linens = true; else p.lin = true; }); clearErr('stay.linenChoice'); update(); return focusAfter(same());
      case 'linfor': { const p = P(); if (!p) return; if (inHall(p)) p.linens = !p.linens; else p.lin = !p.lin; update(); tell(first(p.name) + (hasPacket(p) ? ': linen packet' : ': own linens')); return focusAfter(same()); }
      case 'preteen': { const p = P(); if (!p) return; p.ptOff = p.preteen; update(); return focusAfter(same()); }
      case 'communing': { const p = P(); if (!p) return; p.communing = !p.communing; update(); return focusAfter(same()); }
      // The stay chosen: its nights (or, off campus, its days) are all chosen to start, since they follow a choice.
      case 'type': if (state.editing && !state.editing.can.all) return; d.stay.type = ds.v; if (ds.v !== 'dorm') state.waitlist = false; if (ds.v !== 'elsewhere' && !d.stay.nights.length) d.stay.nights = mainNights().slice(); if (ds.v === 'elsewhere' && !d.stay.days.length) d.stay.days = visitDays().map(x => x.date); if (ds.v === 'yf') named().forEach(p => { p.sleeps = 'hall'; }); clearErr('stay.type'); update(); return focusAfter(same());
      case 'waitlist': state.waitlist = !state.waitlist; clearErr('stay.type'); update(); return focusAfter(same());
      case 'perperson': {
        const s = d.stay; s.perPerson = !s.perPerson;
        named().forEach(p => { p.nights = s.perPerson ? nightsFor(p, Object.assign({}, d, { people: [] })).slice() : []; if (s.perPerson && !p.nights.length) p.nights = (s.nights.length ? s.nights : mainNights()).slice(); });
        update(); return focusAfter(same());
      }
      case 'pnight': {
        const p = P(); if (!p) return;
        const ns = new Set(p.nights.length ? p.nights : nightsFor(p, d)); if (ns.has(ds.v)) ns.delete(ds.v); else ns.add(ds.v);
        p.nights = nights().filter(n => ns.has(n)); clearErr('people.' + p.pid + '.nights'); clearErr('stay.nights'); update(); return focusAfter(same());
      }
      case 'room': { const p = P(); if (p) { p.room = +ds.v; p.roomSet = true; update(); } return focusAfter(same()); }
      case 'sleeps': { const p = P(); if (!p) return; peopleChanged(() => { p.sleeps = ds.v; }); return focusAfter(same()); }
      case 'details': state.ui.details = !state.ui.details; draw(); return focusAfter('[data-act="details"]');
      case 'key': d.stay.keys[+ds.i] = ds.v; update(); return focusAfter(same());
      case 'arrive': d.stay.arrive = d.stay.arrive === ds.v ? '' : ds.v; update(); return focusAfter(same());
      case 'len': d.stay.camperLen = d.stay.camperLen === ds.v ? '' : ds.v; update(); return focusAfter(same());
      case 'userooms': d.stay.rooms = +ds.v; d.stay.roomsSet = true; clearErr('stay.rooms'); update(); tell(plural(+ds.v, 'room')); return focusAfter('[data-path="stay.rooms"][data-by="1"]');
      case 'mattress': d.stay.mattresses = Math.max(0, Math.min(6, +ds.v)); update(); tell(d.stay.mattresses ? plural(d.stay.mattresses, 'air mattress', 'air mattresses') : 'No air mattress'); return focusAfter('[data-path="stay.rooms"][data-by="1"]');
      case 'step': {
        const k = ds.path.split('.')[1], by = +ds.by, s = d.stay;
        const lim = { rooms: [1, 6], linens: [0, 24], mattresses: [0, 6], campers: [1, 4] }[k] || [0, 99];
        s[k] = Math.max(lim[0], Math.min(lim[1], (+s[k] || 0) + by));
        if (k === 'rooms') { s.roomsSet = true; clearErr('stay.rooms'); delete state.check.stay; }
        clearErr('stay.' + k);
        update(); tell(plural(s[k], { rooms: 'room', linens: 'linen packet', mattresses: 'air mattress', campers: 'camper' }[k] || k, k === 'mattresses' ? 'air mattresses' : ''));
        const btn = root.querySelector(same()); if (btn && !btn.disabled) btn.focus({ preventScroll: true }); else focusAfter('[data-path="' + ds.path + '"][data-by="' + (-by) + '"]');
        return;
      }
      case 'meal': {
        const m = d.meals; if (m.off[ds.id]) delete m.off[ds.id]; else { m.off[ds.id] = true; delete m.who[ds.id]; }
        update(); return focusAfter(same());
      }
      case 'mealper': state.ui.mealWho = !state.ui.mealWho; draw(); return focusAfter(state.ui.mealWho ? '[data-act="mealp"]' : '[data-act="mealper"]');
      case 'mealp': state.ui.mealP = ds.v; draw(); return focusAfter(same());
      case 'mealwho': {
        const all = named().map(p => p.pid), cur = new Set(d.meals.who[ds.id] || all);
        if (cur.has(ds.pid)) cur.delete(ds.pid); else cur.add(ds.pid);
        if (!cur.size) { d.meals.off[ds.id] = true; delete d.meals.who[ds.id]; } else if (cur.size === all.length) delete d.meals.who[ds.id]; else d.meals.who[ds.id] = all.filter(x => cur.has(x));
        update(); return focusAfter(same());
      }
      case 'pickup': {
        const all = adults().map(p => p.name.trim()), cur = new Set(d.pickupWho.length ? d.pickupWho : all);
        if (cur.has(ds.v)) cur.delete(ds.v); else cur.add(ds.v);
        d.pickupWho = all.filter(n => cur.has(n)); if (!d.pickupWho.length && !d.pickupOther) d.pickupWho = [];
        update(); return focusAfter(same());
      }
      case 'pickother': state.ui.pickOther = !(state.ui.pickOther || d.pickupOther); if (!state.ui.pickOther) d.pickupOther = ''; update(); return focusAfter(state.ui.pickOther ? '[name="pickupOther"]' : same());
      case 'ptday': { const pt = d.preteens[ds.pid] || (d.preteens[ds.pid] = { medical: '', days: ptDays() }), set = new Set(pt.days || []); if (set.has(ds.v)) set.delete(ds.v); else set.add(ds.v); pt.days = ptDays().filter(x => set.has(x)); update(); return focusAfter(same()); }
      case 'payby': d.pay = ds.v; clearErr('pay'); update(); return focusAfter(same());
      case 'gift': state.ui.gift = true; draw(); return focusAfter('#f-gift');
      case 'deskpaid': d.deskPaid = ds.v; update(); return focusAfter(same());
      case 'pickrooms': return openPicker();
      case 'confirmemail': state.open = 'contact'; draw(); scrollTo('#rf-h-contact'); return sendCode();
      case 'resend': return sendCode(true);
      case 'otheremail': state.verify = Object.assign(state.verify, { step: '', code: '', err: '' }); draw(); return focusAfter('[name="' + (d.helper.on ? 'helper.email' : 'household.email') + '"]');
      case 'clearsamples': return openSheet('Clear samples', '<p class="wk-sheet__note">' + esc('Sample households in ' + state.year + ' are removed · Registration opens') + '</p>', () => api('DELETE', 'reg/' + state.year + '/samples').then(() => loadForm()).then(() => { state.d = state.d || fresh(); settle(); state.open = state.open || 'contact'; draw(); tell('Samples cleared'); }), 'Clear samples', true, 'Cancel');
      case 'cleartests': return openSheet('Clear test registrations', '<p class="wk-sheet__note">' + esc('Registrations in ' + state.year + ' that aren’t samples · Local only') + '</p>', () => api('DELETE', 'reg/' + state.year + '/tests').then(out => { dropDraft(); tell('Cleared ' + out.cleared); location.reload(); }), 'Clear', true, 'Cancel');
      case 'register': return register();
      case 'save': return saveChange();
      case 'copy': {
        const said = t => { state.ui.copied = t; draw(); tell(t); clearTimeout(state.copyT); state.copyT = setTimeout(() => { state.ui.copied = ''; draw(); }, 3000); };
        try { return navigator.clipboard.writeText(ds.v).then(() => said('Copied'), () => said('Not copied')); } catch (x) { return said('Not copied'); }
      }
      case 'ics': return downloadIcs(ds.id);
      case 'print': return window.print();
      case 'paydue': return payDue(+ds.id, 'card');
      case 'paycheck': return payDue(+ds.id, 'check');
      case 'cancelreg': return cancelSheet(+ds.id);
      case 'leave': return leaveSheet(+ds.id);
      case 'resendapproval': return api('POST', 'reg/r/' + ds.id + '/approval').then(() => { tell('Sent'); state.flash = { id: +ds.id, text: 'Sent to the parent again' }; return loadMine(); }).then(draw, x => { state.flash = { id: +ds.id, text: x.status === 429 ? (x.message || 'Sent · Wait a minute') : 'Not sent · Try again', bad: true }; draw(); tell(state.flash.text); });
      case 'approvalto': return approvalToSheet(+ds.id);
      case 'showcancelled': state.ui.showCancelled = true; draw(); return;
      case 'leaveshift': return leaveShiftSheet(ds.v);
      case 'signincode': return signinCode();
      case 'signinresend': return signinSend(true);
      case 'signinother': state.signin = { step: '', email: '', to: '', code: '', err: '', dev: '', retryAt: 0 }; draw(); return focusAfter('[name="signin.email"]');
      case 'approve': return decide(ds.v);
      case 'testpay': return testPay(ds.v);
    }
  }

  function scrollTo(sel) {
    const el = root.querySelector(sel);
    if (!el) return;
    el.scrollIntoView({ block: 'start', behavior: reduced() ? 'auto' : 'smooth' });
    // Moved to by the script: screen readers land here, but no focus ring is drawn on a heading.
    el.focus({ preventScroll: true, focusVisible: false });
  }

  // Continue: the open section checked; the next one opened (a new section appears where it belongs).
  function next() {
    const k = state.open, p = problems(k);
    state.errors = p;
    const n = Object.keys(p).length;
    if (n) {
      if (k === 'stay' && p['stay.mattresses']) state.ui.details = true;
      // The parent's address asked about once: Continue again takes it as typed.
      if (/Did you mean/.test(p['stay.parentEmail'] || '')) state.ui.parentTypoAsked = String(state.d.stay.parentEmail || '').trim().toLowerCase();
      draw();
      focusProblem();
      tell(n === 1 ? Object.values(p)[0] : n + ' fields need attention');
      return;
    }
    // Contact: the email is confirmed here, before the rest of the work (a code under the email field).
    if (k === 'contact' && !state.editing && !verified()) {
      const v = state.verify;
      if (v.step === 'sent' && v.email === wantEmail()) { if (v.code.length === 6) verifyCode(); else { v.err = 'Enter the 6 digits'; draw(); focusSoon('[name="verify.code"]'); } }
      else sendCode();
      return;
    }
    finish(k);
  }
  // The first problem on screen gets the focus: a field, or a choice of pills (its chosen pill, or the first).
  function focusProblem() {
    const el = root.querySelector('[aria-invalid="true"]') || root.querySelector('.rf-err');
    if (!el) return;
    el.scrollIntoView({ block: 'center', behavior: reduced() ? 'auto' : 'smooth' });
    const target = el.getAttribute('role') === 'radiogroup' ? (el.querySelector('[role="radio"][aria-checked="true"]') || el.querySelector('[role="radio"]')) : el;
    if (target && target.focus) target.focus({ preventScroll: true });
  }
  // A section done: marked, and the next one opened.
  function finish(k) {
    if (state.d.finished.indexOf(k) < 0) state.d.finished.push(k);
    delete state.check[k];
    state.d.changes = k === 'people' ? [] : state.d.changes;
    state.open = nextOf(k);
    update();
    scrollTo(state.open ? '#rf-h-' + state.open : '.reg-bar .wk-btn');
    tell(state.open ? titleOf(state.open) : 'Ready');
  }

  /* ================================================================ confirming the email, registering */

  function allProblems() {
    const p = problems();
    const k = Object.keys(p);
    if (!k.length) return false;
    state.errors = p;
    const sec = sectionOf(k[0]);
    state.open = sec; draw(); scrollTo('#rf-h-' + sec);
    tell(k.length === 1 ? p[k[0]] : k.length + ' fields need attention');
    return true;
  }
  // The code, from the site's one sign-in (auth/send, for=register: a code and no link, to an address the
  // site may not know yet). A likely typo stops Continue once, at the field ("Check gmial.com · Did you
  // mean gmail.com?" with Use gmail.com); Continue again sends to the address as typed.
  function sendCode(again) {
    const p = problems('contact');
    if (Object.keys(p).length) { state.errors = p; state.open = 'contact'; draw(); focusProblem(); return; }
    const v = state.verify, email = wantEmail(), path = state.d.helper.on ? 'helper.email' : 'household.email';
    const fix = typoOf(email);
    if (fix && fix !== email && v.typoAsked !== email) { typoStop(email, fix, path); return; }
    state.busy = true; draw();
    api('POST', 'auth/send', { email, for: 'register', typos_ok: v.typoAsked === email ? 1 : 0, return: location.pathname + location.search }).then(out => {
      Object.assign(v, { step: 'sent', email, to: email, code: '', err: '', dev: out.dev_code || '', retryAt: out.next ? out.next * 1000 : Date.now() + 60000 });
      state.busy = false; draw(); focusSoon('[name="verify.code"]'); tell((again ? 'Sent again' : 'Code sent') + ' to ' + email);
      tickResend();
    }, x => {
      state.busy = false;
      const d = (x && x.data && x.data.data) || {};
      if (x.status === 409 && d.fix) { typoStop(email, d.fix, path); return; }
      if (x.status === 429 && d.until) { v.retryAt = d.until * 1000; tickResend(); }
      v.err = x.status === 429 || x.status === 400 ? (x.message || 'Not sent · Try again') : 'Not sent · Try again'; draw();
    });
  }
  function typoStop(email, fix, path) {
    state.verify.typoAsked = email;
    state.errors = { [path]: typoWords(email, fix) }; state.open = 'contact'; draw();
    tell(state.errors[path]); focusSoon('[data-act="typo"]');
  }
  // Phones are kept as 555-555-0142 once a ten-digit number is typed (the field, the summaries, the lists).
  const fmtPhone = v => { const t = String(v || '').trim(), dgt = t.replace(/\D/g, ''), n = dgt.length === 11 && dgt[0] === '1' ? dgt.slice(1) : dgt; return n.length === 10 && /^[\d\s().+-]+$/.test(t) ? n.slice(0, 3) + '-' + n.slice(3, 6) + '-' + n.slice(6) : t; };
  function verifyCode() {
    const v = state.verify;
    if (state.busy || v.code.length !== 6) { if (v.code.length !== 6) { v.err = 'Enter the 6 digits'; draw(); } return; }
    state.busy = true; draw();
    const name = state.d.helper.on ? state.d.helper.name : state.d.household.contact;
    api('POST', 'auth/code', { code: v.code }).then(out => {
      // The draft moves from "anon" to this person's own key (keep() writes it there next).
      dropDraft();
      signedIn({ nonce: out.nonce, me: { email: v.email, name } }); state.busy = false; v.step = 'done';
      // A draft started under another email isn't carried into this one (a shared computer).
      if (state.d.owner && state.d.owner !== v.email) { const h = state.d.household, x = state.d.helper; state.d = fresh(); state.d.household = h; state.d.helper = x; }
      state.d.owner = v.email;
      return loadForm();
    }).then(() => {
      tell('Confirmed');
      // Straight on: Contact is done and the next section opens (or, at the end, the bar's one action).
      if (state.open === 'contact') finish('contact'); else { draw(); focusSoon('.reg-bar .wk-btn'); }
    }, x => { state.busy = false; v.err = x.status === 400 || x.status === 410 ? (x.message || 'Code not valid') : 'Not checked · Try again'; v.code = ''; draw(); focusSoon('[name="verify.code"]'); });
  }
  const focusSoon = sel => setTimeout(() => { const el = root.querySelector(sel); if (el) el.focus(); }, 30);

  // What's sent: the answers only (the server works out the rest).
  function answersOut() {
    const d = JSON.parse(JSON.stringify(settle(state.d)));
    ['finished', 'from', 'changes'].forEach(k => delete d[k]);
    d.people = d.people.filter(p => p.name.trim());
    return d;
  }
  function failed(x, sel) {
    state.busy = false;
    const data = x && x.data && x.data.data || {};
    if (x && x.status === 409 && data.price) { state.override = data.price; state.barNote = x.message; draw(); tell(x.message); return; }
    if (x && (x.status === 400 || x.status === 409) && data.errors) {
      state.errors = data.errors;
      if (data.data && data.data.stay) { state.d.stay.linens = data.data.stay.linens; state.d.stay.mattresses = data.data.stay.mattresses; }
      const k = Object.keys(data.errors)[0], sec = sectionOf(k);
      if (sec !== 'pay') { state.open = sec; if (sec === 'stay') state.ui.details = true; }
      draw(); scrollTo('#rf-h-' + sec); tell(Object.values(data.errors).join(', '));
      return;
    }
    if (x && x.status === 409 && data.item) { state.barNote = 'Changed elsewhere · Reloaded'; state.editing = data.item; state.d = answersOf(data.item.data); state.d.finished = sections().slice(); draw(); return; }
    state.barNote = x && x.status && x.status < 500 ? (x.message || 'Not saved') : 'Not saved · Retry';
    draw(); tell(state.barNote);
  }
  function register() {
    if (state.busy || allProblems()) return;
    const M = moneyNow();
    state.busy = true; state.barNote = ''; draw();
    state.idem = state.idem || idem();
    const desk = state.desk ? { source: 'desk', desk_paid: state.d.deskPaid || '' } : {};
    const data = answersOut();
    if (state.desk) data.pay = 'checkin';
    api('POST', withQ('reg/' + state.year), Object.assign({ data, expect: M.total, idem: state.idem, waitlist: state.waitlist ? 1 : 0 }, desk)).then(out => {
      state.idem = ''; dropDraft();
      if (out.next && out.next.checkout) { location.href = out.next.checkout; return; }
      // The desk: saved, the form cleared for the next household, and today's list grows.
      if (state.desk) {
        state.busy = false; state.deskSaved = out.item; (state.deskToday = state.deskToday || []).push({ id: out.item.id, data: out.item.data });
        state.d = fresh(); state.d.pay = 'checkin'; settle(); state.open = 'contact'; state.errors = {}; state.check = {}; state.ui = {};
        draw(); window.scrollTo(0, 0); tell('Saved · ' + out.item.rid + ' · Next household'); focusSoon('[name="household.contact"]');
        return;
      }
      state.done = out.item; state.busy = false; state.view = 'done';
      if (!state.desk) history.replaceState(null, '', here('year=' + state.year + '&view=done&id=' + out.item.id));
      draw(); window.scrollTo(0, 0); focusSoon('.reg-done h2'); tell('Registered · ' + out.item.rid);
    }, failed);
  }
  function saveChange() {
    if (state.busy || allProblems()) return;
    const M = moneyNow(), ed = state.editing;
    state.busy = true; state.barNote = ''; draw();
    state.idem = state.idem || idem();
    api('PUT', withQ('reg/r/' + ed.id), { data: answersOut(), expect: M.total, v: ed.data._v || 0, idem: state.idem, pay: state.d.pay }).then(out => {
      state.idem = '';
      if (out.next && out.next.checkout) { location.href = out.next.checkout; return; }
      try { sessionStorage.setItem('ogc-reg-flash', JSON.stringify({ id: ed.id, text: out.same ? 'No changes' : 'Saved · ' + (out.changed || '') })); } catch (x) { /* none */ }
      location.href = here('year=' + state.year + '&view=mine');
    }, failed);
  }

  /* ================================================================ Your sign-ups: actions */

  const loadMine = () => api('GET', withQ('reg/' + state.year + '/mine')).then(out => { state.mine = out.items; state.mineErr = ''; }, x => { state.mineErr = x.message || 'error'; state.mine = []; });
  function payDue(id, method) {
    state.busy = true; draw();
    api('POST', withQ('reg/r/' + id + '/pay'), { method, idem: idem() }).then(out => {
      if (out.next && out.next.checkout) { location.href = out.next.checkout; return; }
      state.busy = false; state.payNote = { text: 'Check to come' }; return loadMine().then(draw);
    }, x => { state.busy = false; state.payNote = { text: x.message || 'Not started', bad: true }; draw(); });
  }
  const sheet = document.createElement('dialog');
  sheet.className = 'ogc wk-sheet reg-sheet';
  sheet.setAttribute('aria-labelledby', 'reg-sheet-t');
  document.body.appendChild(sheet);
  sheet.addEventListener('click', e => { if (e.target === sheet || e.target.closest('[data-close]')) sheet.close(); });
  // A failure says so inside the sheet, above its buttons, until the next tap (never only to a screen reader).
  const sheetErr = x => x && (x.status === 400 || x.status === 403 || x.status === 409 || x.status === 429) && x.message ? x.message : 'Not saved · Try again';
  function openSheet(title, body, go, goLabel, alert, dismiss) {
    sheet.onchange = null; sheet.onclick = null;
    sheet.innerHTML = '<div class="wk-sheet__in"><button type="button" class="wk-sheet__x" data-close aria-label="Close">' + I.x + '</button><h2 class="wk-sheet__h" id="reg-sheet-t">' + esc(title) + '</h2>' + body +
      '<p class="rf-err reg-sheet__err" role="alert" hidden></p><p class="wk-sheet__btns"><button type="button" class="wk-btn' + (alert ? ' wk-btn--alert' : '') + '" data-go>' + esc(goLabel) + '</button><button type="button" class="wk-linklike" data-close>' + esc(dismiss || 'Cancel') + '</button></p></div>';
    const errP = sheet.querySelector('.reg-sheet__err');
    sheet.querySelector('[data-go]').onclick = () => {
      const btn = sheet.querySelector('[data-go]'); btn.disabled = true; btn.textContent = 'Processing…'; errP.hidden = true;
      Promise.resolve().then(go).then(() => sheet.close(), x => { btn.disabled = false; btn.textContent = goLabel; errP.textContent = sheetErr(x); errP.hidden = false; tell(errP.textContent); });
    };
    sheet.showModal();
  }
  function cancelSheet(id) {
    const it = (state.mine || []).find(x => x.id === id) || state.editing, m = it.data.money || {}, gift = it.data.price.gift_cents || 0, back = Math.max(0, (m.paid || 0) - (m.refund || 0) - gift);
    openSheet('Cancel registration', '<ul class="rf-sheetlist">' + (back && it.can.refund ? '<li>' + esc($(back)) + ' refund requested</li>' : m.paid && !it.can.refund ? '<li>No refund after ' + esc(O.fmtDate(C('refunds_by'), 'md')) + '</li>' : '') + (gift ? '<li>Gift ' + esc($(gift)) + ' kept for ' + esc(C('gift_for') || 'the Conference fund') + '</li>' : '') + (m.check ? '<li>The check to come isn’t needed</li>' : '') + '<li>Rooms, linens and meals are freed</li></ul>',
      () => api('POST', 'reg/r/' + id + '/cancel').then(() => { if (state.view === 'edit') { location.href = here('year=' + state.year + '&view=mine'); return new Promise(() => {}); } return loadMine(); }).then(() => { state.flash = null; draw(); tell('Cancelled'); }), 'Cancel registration', true, 'Keep registration');
  }
  function leaveSheet(id) {
    // Who's leaving (everyone at first: Harold may go home Sunday while Ruth stays), and their last night:
    // last night at the earliest (leaving this morning). No night is chosen for them (polish 2: the latest
    // was chosen, with its refund showing, so one tap filed a request nobody chose).
    const it = state.mine.find(x => x.id === id), d0 = answersOf(it.data), ppl = d0.people.filter(p => nightsFor(p, d0).length);
    const ns = it.data.stay.nights.filter(n => !early(n)), from = O.isoAddDays(today(), -1);
    const choices = ns.slice(0, -1).filter(n => nightDate(n) >= from);
    if (!choices.length) { tell('No nights left to free'); return; }
    const pick = new Set(ppl.map(p => p.pid));
    const body = (ppl.length > 1 ? '<p class="wk-sheet__note">Who’s leaving</p><p class="rf-asks reg-sheet__who" role="group" aria-label="Who’s leaving">' + ppl.map(p => togAct('leavewho', true, first(p.name), ' data-pid="' + p.pid + '"')).join('') + '</p>' : '') +
      '<p class="wk-sheet__note">Last night</p><fieldset class="reg-nights"><legend class="ogc-sr">Last night</legend><span class="reg-nights__row" style="--n:' + choices.length + '">' + choices.map(n => '<label class="reg-night"><input type="radio" name="last" value="' + esc(n) + '"><span>' + I.check + '<i>' + esc(SU.nightShort(n)) + '</i><b>' + esc(O.fmtDate(nightDate(n), 'mdShort')) + '</b></span></label>').join('') + '</span></fieldset><p class="reg-sum" data-say></p>';
    openSheet('Leave early', body, () => {
      if (!pick.size) return Promise.reject({ status: 400, message: 'Choose who’s leaving' });
      if (leftAlone().length) return Promise.reject({ status: 400, message: leftWords() });
      const lastIn = sheet.querySelector('[name=last]:checked');
      if (!lastIn) return Promise.reject({ status: 400, message: 'Choose last night' });
      return api('POST', withQ('reg/r/' + id + '/leave'), { last: lastIn.value, who: Array.from(pick) }).then(out => { state.flash = { id, text: out.refund ? $(out.refund) + ' refund requested · After the keys are back' : 'Saved' }; return loadMine(); }).then(draw);
    }, 'Leave early', false, 'Cancel');
    const go = sheet.querySelector('[data-go]');
    // No child is left in a room with no grown-up (polish 3: every adult could leave while Ruthie, 1,
    // stayed on alone, and the room kept being charged).
    const leftAlone = () => { const stay = ppl.filter(p => !pick.has(p.pid)); return !ppl.some(p => p.kind === 'adult') || stay.some(p => p.kind === 'adult') ? [] : stay.filter(p => p.kind === 'child' || p.minor); };
    const leftWords = () => { const k = leftAlone().map(p => first(p.name)); return (k.length > 1 ? k.slice(0, -1).join(', ') + ' and ' + k[k.length - 1] : k[0]) + ' would stay with no grown-up'; };
    const list = n => n.length > 1 ? n.slice(0, -1).join(', ') + ' and ' + n[n.length - 1] : n[0] || '';
    const show = () => {
      const lastIn = sheet.querySelector('[name=last]:checked'), who = ppl.filter(p => pick.has(p.pid));
      sheet.querySelectorAll('.reg-night').forEach(l => l.classList.toggle('is-on', l.querySelector('input').checked));
      go.disabled = !lastIn || !who.length || leftAlone().length > 0;
      if (!who.length) { sheet.querySelector('[data-say]').textContent = 'Choose who’s leaving'; return; }
      if (leftAlone().length) { sheet.querySelector('[data-say]').textContent = leftWords(); return; }
      if (!lastIn) { sheet.querySelector('[data-say]').textContent = 'Choose last night'; return; }
      const last = lastIn.value, keep = ns.slice(0, ns.indexOf(last) + 1), x = answersOf(it.data);
      x.people.forEach(p => { p.nights = nightsFor(p, x).filter(n => !pick.has(p.pid) || keep.indexOf(n) > -1 || early(n)); }); x.stay.perPerson = true; settle(x);
      // What comes back: a refund only of what was paid past the new total; else what's no longer owed
      // (a check to come shrinks first, as the server's ogc_reg_rebalance does).
      const less = it.data.price.lodging_cents - priceOf(x, it.data.price.prices).lodging_cents, m = it.data.money || {};
      const back = Math.max(0, Math.min(less, (m.paid || 0) - (m.refund || 0) - (it.data.price.total_cents - less)));
      // "Martha, John, Eli and Anna · Last night Sat May 29 · $65 less to pay"; everyone: no names.
      sheet.querySelector('[data-say]').textContent = nb((who.length === ppl.length ? '' : list(who.map(p => first(p.name))) + ' · ') + 'Last night ' + shortDate(nightDate(last)) + (back > 0 && it.can.refund ? ' · ' + $(back) + ' refund' : back > 0 ? ' · No refund after ' + O.fmtDate(C('refunds_by'), 'md') : less > 0 ? ' · ' + $(less) + ' less to pay' : ''));
    };
    sheet.onchange = show;
    sheet.onclick = e => { const b = e.target.closest('[data-act="leavewho"]'); if (!b) return; if (pick.has(b.dataset.pid)) pick.delete(b.dataset.pid); else pick.add(b.dataset.pid); b.setAttribute('aria-pressed', pick.has(b.dataset.pid)); show(); };
    show();
  }
  // Leave a shift through the volunteer page's own route (the head is told, a waiting person offered
  // the place); confirmed first, since it can't be taken back.
  function leaveShiftSheet(v) {
    const [id, name] = v.split('|'), x = myShifts().find(s => s.sh.id === id && s.u.name === name);
    if (!x) return;
    // As the volunteer page asks it, steering to a replacement first (the place still needs filling).
    openSheet('Leave this shift?', '<p class="wk-sheet__when">' + esc(x.sh.role + ' · ' + O.fmtDate(x.sh.day.date, 'short') + ' · ' + shiftTime(x.sh)) + '</p><p class="rf-help">The committee head is told · <a href="../volunteer/?year=' + esc(state.year) + '&shift=' + encodeURIComponent(x.sh.id) + '">Find replacement</a></p>',
      () => api('POST', 'vol/' + state.year + '/leave', { ids: [x.u._rid] }).then(out => {
        if (!out.left || !out.left.length) throw new Error('Not left');
        return O.records.load(state.year, ['signups'], true);
      }).then(() => { draw(); tell('Left ' + x.sh.role); }), 'Leave shift', true, 'Keep shift');
  }

  // Sign in on Your sign-ups: a code and a link by email.
  function signinSend(again) {
    const si = state.signin, email = (again ? si.email : (root.querySelector('[name="signin.email"]') || {}).value || si.email).trim();
    if (!emailOk(email)) { si.err = 'Enter an email like name@example.com'; draw(); return; }
    si.email = email; state.busy = true; draw();
    // The site's own sign-in (the signin area: a link and a code, mail only to an address it knows);
    // the form's code route where that isn't installed.
    const back = location.pathname + '?year=' + state.year + '&view=mine';
    const mask = e => e.replace(/^(.)[^@]*(@.*)$/, '$1•••$2');
    api('POST', 'auth/send', { email, return: back }).then(() => ({ to: mask(email), via: 'auth' })).then(out => {
      Object.assign(si, { step: 'sent', via: out.via, to: out.to, code: '', err: '', dev: out.dev_code || '', retryAt: Date.now() + (out.retry || 30) * 1000 });
      state.busy = false; draw(); focusSoon('[name="signin.code"]'); tell('Link sent to ' + out.to);
      setTimeout(draw, 30500);
    }, x => { state.busy = false; si.err = x.message || 'Not sent · Try again'; draw(); });
  }
  function signinCode() {
    const si = state.signin;
    if (state.busy) return;
    if (si.code.length !== 6) { si.err = 'Enter the 6 digits'; draw(); return; }
    state.busy = true; draw();
    api('POST', 'auth/code', { code: si.code }).then(() => location.reload(), x => { state.busy = false; si.err = x.message || 'Code not valid'; si.code = ''; draw(); });
  }
  function decide(v) {
    const send = () => api('POST', 'reg/approve/' + encodeURIComponent(approveToken()), { decision: v }).then(A => { state.approve = A; state.approveErr = ''; draw(); tell(v === 'approve' ? 'Approved' : 'Declined'); });
    if (v === 'approve') return send().catch(x => { state.approveErr = sheetErr(x); draw(); tell(state.approveErr); });
    const A = state.approve, D = A.decline || {}, names = (D.names && D.names.length ? D.names : [first(A.who[0].name)]).join(' and ');
    openSheet('Decline', '<ul class="rf-sheetlist">' + (D.whole ? '<li>' + esc(names + '’s registration is cancelled') + '</li>' : '<li>' + esc(names + ' comes off the registration') + '</li>') + (D.refund ? '<li>' + escn('Refund requested · ' + $(D.refund)) + '</li>' : '') + '</ul>', send, 'Decline', true, 'Cancel');
  }
  function testPay(outcome) {
    api('POST', 'pay/test/' + q.get('checkout') + '?t=' + encodeURIComponent(q.get('t') || ''), { outcome }).then(out => {
      // Back where the provider would send them: Registered for a new registration, else Your sign-ups.
      location.href = here('year=' + out.year + (q.get('then') === 'done' ? '&view=done&id=' + out.record : '&view=mine') + '&paid=' + out.id);
    }, x => tell(x.message || 'Not done'));
  }

  // One calendar file: the household's days, and every shift this email has.
  function downloadIcs(id) {
    const r = state.row, s = state.model.settings, ev = [];
    const regs = (state.done ? [state.done] : (state.mine || [])).filter(it => it.data.status !== 'cancelled' && (!id || String(it.id) === String(id)));
    regs.forEach(it => {
      const d = it.data, days = new Set();
      d.people.forEach(p => personDays(p, d).forEach(x => days.add(x)));
      const list = Array.from(days).sort();
      if (list.length) ev.push({ uid: 'annual-conference-' + r.year + '-' + it.rid, date: list[0], endDate: list[list.length - 1], summary: r.year + ' Annual Conference', location: s.address || r.venue, description: it.rid });
    });
    if (!regs.length) ev.push({ uid: 'annual-conference-' + r.year, date: r.start, endDate: r.end || r.start, summary: r.year + ' Annual Conference', location: s.address || r.venue });
    myShifts().forEach(({ u, sh }) => ev.push(SU.shiftEvent(sh, s, state.year, u.name)));
    SU.save(SU.ics(ev, state.model.tz), 'text/calendar', 'annual-conference-' + r.year + '.ics');
  }

  /* ================================================================ the bar steps aside for the keyboard */

  // The phone's keyboard is up when the visible part of the page is much shorter than the window.
  const vv = window.visualViewport;
  if (vv) vv.addEventListener('resize', () => { document.body.classList.toggle('reg-typing', window.innerHeight - vv.height > 150 && /^(INPUT|TEXTAREA)$/.test((document.activeElement || {}).tagName || '')); });

  // Local only: the page's rules, for the parity check against the server (tools: the register CHANGES).
  if (W.dev) window.OGC_REG_TEST = { priceOf: d => priceOf(settle(d)), settle, blank, person, state };

  /* ================================================================ boot */

  (async function boot() {
    try {
      // The first answers come inlined with the page (OGC_WP.preload: the form and this person's
      // registrations; the store takes the years, files and records), so the first draw waits for no
      // request. Without them (an old cached page), the requests run side by side.
      const P0 = W.preload && Date.now() / 1000 - (W.preload.at || 0) < 600 ? W.preload : null;
      const signed0 = !!(W.me && W.me.email);
      const formP = P0 && P0.form ? Promise.resolve(P0.form).then(F => { state.F = F; state.cfg = F.cfg || {}; return F; }) : null;
      const mineP = P0 && P0.mine ? Promise.resolve(P0.mine).then(out => { state.mine = out.items; state.mineErr = ''; }) : signed0 && ['mine', 'edit', 'done', 'receipt'].indexOf(q.get('view') || 'form') > -1 ? loadMine() : null;
      if (O.ready) await O.ready;
      const years = O.csvToObjects(await (await fetch(BASE + 'years.csv', { cache: 'no-store' })).text()).filter(y => y.year).sort((a, b) => b.year - a.year);
      state.row = years.find(y => y.year === state.year) || years.find(y => y.data) || years[0];
      state.year = state.row.year;
      if (q.get('approve')) state.view = 'approve';
      if (q.get('checkout')) state.view = 'checkout';
      const tasks = [formP || loadForm()].concat(mineP ? [mineP] : []);
      if (state.row.data) {
        const folder = BASE + state.row.data + '/';
        tasks.push(O.loadSchedule(folder).then(m => { state.model = m; }));
        tasks.push(Promise.all(['shifts', 'rooms', 'plans', 'campus'].map(f => fetch(folder + f + '.csv', { cache: 'no-store' }).then(r => r.ok ? r.text() : ''))).then(([sh, rooms, plans, campus]) => {
          state.shiftRows = O.csvToObjects(sh);
          Object.assign(state, SU.readRooms(O.csvToObjects(rooms)));
          if (O.map) { state.plans = O.map.plans(O.csvToObjects(plans)); O.map.orderFloors(state.floors, state.plans); const c = O.map.campus(O.csvToObjects(campus)); state.campus = c.items.length ? c : null; }
        }));
      }
      // A past year's page points to the next one: its registration, open or when it opens.
      const nextRow = years.find(y => +y.year === +state.year + 1);
      if (state.view === 'form' && nextRow && state.row.end && state.row.end < O.wallNow('America/Indiana/Indianapolis').date) tasks.push(api('GET', 'reg/' + nextRow.year + '/form').then(N => { state.nextF = N; }, () => null));
      if (state.view === 'approve') tasks.push(api('GET', 'reg/approve/' + encodeURIComponent(approveToken())).then(A => { state.approve = A; }, () => { state.approve = null; }));
      if (state.view === 'checkout') tasks.push(api('GET', 'pay/test/' + q.get('checkout') + '?t=' + encodeURIComponent(q.get('t') || '')).then(P => { state.checkout = P; }, () => { state.checkout = null; }));
      await Promise.all(tasks);
      // The days and meals come from the server (the schedule itself may not be posted yet).
      state.days = (state.F.days || []).map(x => ({ name: x.name, date: x.date }));
      state.meals = (state.F.meals || []).map(m => ({ id: m.key, day: { date: m.date }, title: m.title }));
      if (state.model) state.shifts = SU.expandShifts(state.shiftRows || [], state.model);
      const me = SU.me(), signed = me && !me.pending;
      if (['mine', 'edit', 'done', 'receipt'].indexOf(state.view) > -1 && signed && !mineP) await loadMine();
      if (state.view === 'mine' || state.view === 'done') {
        if (state.view === 'mine') try { const f = JSON.parse(sessionStorage.getItem('ogc-reg-flash')); if (f) { state.flash = f; sessionStorage.removeItem('ogc-reg-flash'); } } catch (x) { /* none */ }
        const paid = q.get('paid');
        if (paid) {
          const it = (state.mine || []).find(x => (x.ledger || []).some(p => String(p.id) === paid)), p = it && it.ledger.find(x => String(x.id) === paid);
          if (p) state.payNote = p.status === 'paid' ? { text: 'Paid ' + $(p.cents) } : p.status === 'failed' ? { text: 'Card declined', bad: true, retry: it.id, check: true } : { text: 'Payment cancelled · ' + $(p.cents) + ' due', bad: true, retry: it.id, check: true };
          const u = new URL(location.href); u.searchParams.delete('paid'); history.replaceState(null, '', u);
        }
      }
      if (state.view === 'done') state.done = (state.mine || []).find(x => String(x.id) === q.get('id')) || null;
      if (state.view === 'edit') {
        const it = (state.mine || []).find(x => String(x.id) === q.get('id'));
        if (!it || !it.can.change) { state.view = 'mine'; }
        else { state.editing = it; state.d = answersOf(it.data); state.d.pay = it.data.pay || payChoices()[0][0];
          // Past check_by a check isn't offered for what's owed: the late way (at check-in, or card).
          if (state.d.pay === 'check' && state.F.late) state.d.pay = payChoices()[0][0];
          settle(); state.d.finished = sections().slice(); state.open = ''; }
      }
      if (state.view === 'form') {
        if (q.get('another')) state.another = true;
        // The desk (a member): the same form for a household at check-in, by phone or on paper.
        state.desk = !!(state.F.member && q.get('desk') === '1');
        if (state.desk) await loadDesk();
        sweepDrafts();
        state.d = loadDraft() || (state.desk ? null : serverDraft()) || fresh();
        // Signed in already: the draft is this person's (and is kept for them on the server).
        if (!state.desk && signedNow() && !state.d.owner) state.d.owner = SU.me().email;
        if (state.desk) state.d.pay = 'checkin';
        else if (!payOk(state.d.pay)) state.d.pay = payChoices()[0][0];
        settle();
        if (state.F && state.d.finished) state.open = nextOf('');
        if (state.open === 'pay' && !state.d.finished.length) state.open = 'contact';
        if (!state.d.finished.some(k => k !== 'meals')) state.open = 'contact';
      }
      document.title = { mine: 'Your sign-ups', edit: 'Change registration', done: 'Registered', receipt: 'Receipt', approve: 'Approval', checkout: 'Checkout' }[state.view] || 'Register';
      document.title += ' – ' + state.year + ' Annual Conference';
      draw();
    } catch (x) {
      console.error(x);
      state.view = 'error';
      try { draw(); } catch (y) { root.textContent = 'Couldn’t load'; }
    }
  })();
})();
