/*
 * week.js — the Annual Conference page, in the site's own look: a cream header band, the
 * season's one list on white, and the things you look up as cards on a second cream band.
 *
 *   1. The header       the year switcher (‹ › beside the year, the ← / → keys, a swipe on the title,
 *                       the year list), when, where and who hosts (each with its icon), a notice
 *                       while one is true, and the season's one button (with at most one quieter
 *                       one beside it). Beside it on a laptop (under it on a phone): News, before and
 *                       during the Conference; during the week Now and Next come first.
 *   2. The season       the one list there is to follow: the week (Services · Full schedule), and
 *                       after the Conference its recordings.
 *                       On a laptop each day's name sits in a column beside its rows.
 *   3. The shelf        cards: News (after the Conference), the information packet, the papers,
 *                       Coming up. Then one last line.
 *
 * The on-site guide is a page of its own (../guide/, data-guide on the block): the same parts drawn
 * as an app for a phone at Conference, four tabs at the bottom. The Conference page never turns into
 * it (Andrew, Oct 7: two pages, or it confuses people); from a week before, it links to it.
 *
 * Nothing is a placeholder: every part appears when its thing is posted, and the server sends the
 * public only what is published (includes/module-public.php: one table of gates).
 * Data: the plugin's REST API, read through ogc-wp.js and ogc-store.js as v3's years.csv and one
 * folder per year (docs/05 has the columns).
 * Previews: ?as-of= views the page on another date, ?tz= from another time zone, and ?preview=1 shows
 * what isn't published yet. Only the year's members, webmasters and the local site may use them (the
 * server says who: OGC_WP.preview); for anyone else they do nothing and aren't passed on.
 */
(function () {
  'use strict';
  const O = window.OGC, esc = O.esc;
  const root = document.getElementById('ogc-week');
  const BASE = root.dataset.base;
  const q = new URLSearchParams(location.search);
  const GUIDE = root.hasAttribute('data-guide');
  const TZ = 'America/Indiana/Indianapolis';

  const svg = (d, fill) => '<svg class="wk-i" viewBox="0 0 24 24" aria-hidden="true">' +
    (fill ? '<path d="' + d + '" fill="currentColor"/>' : '<path d="' + d + '" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/>') + '</svg>';
  const I = {
    play: svg('M8.5 6v12l10-6z', true),
    pause: svg('M7.5 5.5h3v13h-3zM13.5 5.5h3v13h-3z', true),
    prev: svg('M14.5 5.5 8 12l6.5 6.5'),
    next: svg('m9.5 5.5 6.5 6.5-6.5 6.5'),
    skip: svg('M6.5 6v12l8.5-6zM17 6v12'),
    close: svg('m6.5 6.5 11 11M17.5 6.5l-11 11'),
    info: svg('M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18ZM12 11v5.5M12 7.6v.1'),
    notice: svg('M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18ZM12 7.5V13M12 16.4v.1'),
    down: svg('m6 9.5 6 6 6-6'),
    cal: svg('M7.5 3.5v3M16.5 3.5v3M4 9.5h16M5.5 5.5h13A1.5 1.5 0 0 1 20 7v11.5a1.5 1.5 0 0 1-1.5 1.5h-13A1.5 1.5 0 0 1 4 18.5V7a1.5 1.5 0 0 1 1.5-1.5Z'),
    pin: svg('M12 20.5s-6.5-5.4-6.5-10.8a6.5 6.5 0 0 1 13 0c0 5.4-6.5 10.8-6.5 10.8ZM12 12a2.3 2.3 0 1 0 0-4.6 2.3 2.3 0 0 0 0 4.6Z'),
    people: svg('M9 11a3.4 3.4 0 1 0 0-6.8A3.4 3.4 0 0 0 9 11ZM3 19.5c.6-3.3 3-5.2 6-5.2s5.4 1.9 6 5.2M15.8 4.5a3.2 3.2 0 0 1 0 6.2M17.6 14.6c1.8.7 3 2.3 3.4 4.9'),
    phone: svg('M6.2 4h2.6l1.6 4.1-2 1.4a11.5 11.5 0 0 0 6.1 6.1l1.4-2 4.1 1.6v2.6a1.6 1.6 0 0 1-1.7 1.6C11 19 5 13 4.6 5.7A1.6 1.6 0 0 1 6.2 4Z'),
    book: svg('M3.5 6c2.8-1.2 5.9-1.1 8.5.9 2.6-2 5.7-2.1 8.5-.9v12.5c-2.8-1.2-5.9-1.1-8.5.9-2.6-2-5.7-2.1-8.5-.9ZM12 6.9v12.5'),
    doc: svg('M6.5 3.5h7.5l4 4v12a1 1 0 0 1-1 1h-10.5a1 1 0 0 1-1-1v-15a1 1 0 0 1 1-1ZM13.5 3.5V8H18M9 12.5h6M9 16h6'),
    news: svg('M4.5 5.5h11v13.5h-10a1 1 0 0 1-1-1ZM15.5 9h4v8.5a1.5 1.5 0 0 1-3 0V9M7.5 9h5M7.5 12.5h5M7.5 16h3'),
    right: svg('m9.5 6 6 6-6 6'),
    clock: svg('M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18ZM12 7.5V12l3 2'),
    check: svg('m5.5 12.5 4 4 9-9'),
    save: svg('M12 4v10.5M7.5 10 12 14.5 16.5 10M5 19.5h14'),
    help: svg('M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18ZM12 15.8a3.8 3.8 0 1 0 0-7.6 3.8 3.8 0 0 0 0 7.6ZM5.6 5.6l3.7 3.7M14.7 14.7l3.7 3.7M18.4 5.6l-3.7 3.7M9.3 14.7l-3.7 3.7'),
    // Directions (Oct 13: Google Maps' walking directions).
    dirs: svg('M12 3.2 20.8 12 12 20.8 3.2 12ZM9.8 14.5v-2.2a1.6 1.6 0 0 1 1.6-1.6h3.4M13.3 8.5l2 2.2-2 2.2'),
    // Oct 10 (the plugin): search, share, a link, leaving the site, the player's skips, retry, and the
    // iPhone's own Share and Add icons for the two steps of Add to Home Screen.
    search: svg('M10.5 17.5a7 7 0 1 0 0-14 7 7 0 0 0 0 14ZM15.5 15.5l5 5'),
    share: svg('M12 15V3.5M7.5 8 12 3.5 16.5 8M5 12.5v6a1.5 1.5 0 0 0 1.5 1.5h11a1.5 1.5 0 0 0 1.5-1.5v-6'),
    shareios: svg('M12 14.5V3.5M8 7.5l4-4 4 4M8.5 10.5H6.5a1 1 0 0 0-1 1v8a1 1 0 0 0 1 1h11a1 1 0 0 0 1-1v-8a1 1 0 0 0-1-1h-2'),
    addsq: svg('M5.5 4h13A1.5 1.5 0 0 1 20 5.5v13a1.5 1.5 0 0 1-1.5 1.5h-13A1.5 1.5 0 0 1 4 18.5v-13A1.5 1.5 0 0 1 5.5 4ZM12 8v8M8 12h8'),
    link: svg('M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1-1'),
    out: svg('M14 4.5h5.5V10M19.5 4.5 11 13M17 13.5v5a1 1 0 0 1-1 1H5.5a1 1 0 0 1-1-1V8a1 1 0 0 1 1-1h5'),
    back15: svg('M4.5 12a7.5 7.5 0 1 0 2.2-5.3M4.5 4.5v3.5H8M10 10v5M12.5 10h2.5M12.5 10v2.3h1.3a1.4 1.4 0 0 1 0 2.7h-1.3'),
    fwd30: svg('M19.5 12a7.5 7.5 0 1 1-2.2-5.3M19.5 4.5v3.5H16M8.7 10h1.8a1.2 1.2 0 0 1 0 2.4H9.6M10.5 12.4a1.3 1.3 0 0 1 0 2.6H8.7M14.6 10a1.3 1.3 0 0 1 1.3 1.3v2.4a1.3 1.3 0 0 1-2.6 0v-2.4a1.3 1.3 0 0 1 1.3-1.3Z'),
    retry: svg('M19.5 12a7.5 7.5 0 1 1-2.2-5.3M19.5 4.5V9H15')
  };
  // The plugin's own pages for signing up (registration goes to the COA's link instead when they
  // chose another tool: the server's reg_mode).
  const OWN = { volunteer: '../volunteer/', register: '../register/', tournaments: '../tournaments/' };
  const WP = window.OGC_WP || {};
  // ?as-of, ?tz and ?preview are for the year's members, webmasters and the local site (the server
  // says who: OGC_WP.preview). For anyone else they do nothing, and they aren't passed on.
  const MAY = !!WP.preview;
  const qp = k => MAY ? q.get(k) || '' : '';
  // The page's preview date goes along, so the sign-up pages and the papers show that day too (Oct 8
  // review), while it applies to the year (previewOf).
  const asOfParam = () => previewOf(yearRow(state.year)) ? '&as-of=' + encodeURIComponent(qp('as-of')) : '';
  // The player's artwork on a lock screen: the plugin's own copy of the auditorium, so nothing loads
  // from another site. (The header has no picture since Oct 20.)
  const PHOTO = (WP.assets || '../') + 'shared/img/conference-auditorium.jpg';
  // A link taken from data: http(s), tel, sms, mailto or this site's own; anything else isn't a link.
  const safeUrl = u => {
    u = String(u == null ? '' : u).trim();
    const chk = u.replace(/[\x00-\x20]+/g, '');
    return !u || (/^[a-z][a-z0-9+.-]*:/i.test(chk) && !/^(https?|tel|sms|mailto):/i.test(chk)) ? '' : u;
  };

  // queue: this year's recordings, in order. pq: the list the player is working through, which
  // stays with the player when the page turns to another year. open: the folds a reader has opened.
  const state = { now: null, years: [], year: '', featured: '', model: null, view: '', day: '', queue: [], pq: [], playing: '', enter: '', open: new Set(), tz: qp('tz'),
    changes: [], synced: 0, sig: '', updated: '', failed: false,
    // The campus map (shared/ogc-map.js). Directions open Google Maps (Oct 13).
    campus: null, rooms: null, mapEl: null, map: null };
  // The views a reader can pick (state.view; '' is the season's own first view). The Conference page:
  // Services · Schedule. The guide, its own page:
  // Today · Schedule · Places · Help. The Conference page never turns into the guide.
  const VIEWS = ['services', 'full', 'today', 'places', 'help'];
  const viewParam = p => VIEWS.indexOf(p.get('view')) > -1 ? p.get('view') : '';

  // Said out loud when the page changes under a screen reader (a year, a view).
  const say = document.createElement('p');
  say.className = 'ogc-sr';
  say.setAttribute('aria-live', 'polite');
  root.after(say);

  /* ================================================================ data */

  const known = () => state.years.filter(r => !r.announced || r.announced <= state.now.date);
  const yearRow = y => state.years.find(r => r.year === String(y));
  // A preview date applies only to a Conference not yet over (Michael, Oct 16: "nobody's going to be
  // registering for 2026"): a past year is drawn as it is today, Past, whatever ?as-of says. Over is the
  // server's word for the year (years: status_word), by the site's own clock.
  const previewOf = r => qp('as-of') && !(r && r.status_word === 'Past') ? O.parseAsOf(qp('as-of')) : null;
  // A year whose hosts are announced but that has no data yet (2028) opens as a short page of its own.
  const isStub = r => !!r && !r.data && !r.page && !!r.hosts;
  const opens = r => !!r && (!!r.data || isStub(r));
  const S = () => state.model.settings;
  const yes = O.yes;
  const stamp = n => n.date + 'T' + String(Math.floor(n.minutes / 60)).padStart(2, '0') + ':' + String(n.minutes % 60).padStart(2, '0');
  // A member's preview (the year page's See it, ?preview=1) shows what isn't published yet.
  const PREVIEW = qp('preview') === '1';
  const postedBy = iso => PREVIEW || !iso || (iso.length <= 10 ? iso <= state.now.date : iso.slice(0, 16) <= stamp(state.now));
  // Published by the real clock (not a preview date): what the public can see today.
  const realNow = () => O.wallNow(venueTZ());
  const publicBy = iso => { const n = realNow(); return !iso || (iso.length <= 10 ? iso <= n.date : iso.slice(0, 16) <= stamp(n)); };
  const ext = url => /^https?:/.test(url) && url.indexOf(location.host) === -1 && url.indexOf('ogbbc.org') === -1 ? ' target="_blank" rel="noopener"' : '';
  const span = y => { const r = yearRow(y); return r && r.start ? O.fmtDateSpan(r.start, r.end || r.start) : ''; };
  const noYear = t => t.replace(/, \d{4}$/, '');
  const plays = it => (it.attachments || []).filter(a => (a.kind === 'sermon' || a.kind === 'recording') && postedBy(a.posted));
  const docs = it => (it.attachments || []).filter(a => a.kind === 'document' && postedBy(a.posted));
  const cap = t => t.charAt(0).toUpperCase() + t.slice(1);
  // A date in a narrow column, the way the rest of the page writes months (AP style: May, June and
  // July in full, the long ones shortened).
  const AP = ['Jan.', 'Feb.', 'March', 'April', 'May', 'June', 'July', 'Aug.', 'Sept.', 'Oct.', 'Nov.', 'Dec.'];
  const shortDate = iso => { const p = O.parseISODate(iso); return p ? AP[p.m - 1] + ' ' + p.d : ''; };
  // A PIN read out in groups: 6883602 → 688 3602.
  const pinText = p => { const d = String(p || '').replace(/\s+/g, ''); return /^\d{6,}$/.test(d) ? d.slice(0, d.length - 4) + ' ' + d.slice(-4) : d; };

  // The year the page opens on: the one the webmasters set to show first (years: featured); else the
  // latest whose COA announcement is out; else the latest that has begun. And from Nov 1 after a
  // Conference, the next one once it's announced, so the page never stays on last year into winter
  // (Advisors, Oct 9: move forward before Jan 1).
  // also as soon as the next year asks people to do something (its sign-ups or registration
  // are open: the server's `open`), so someone coming to volunteer in October lands on 2027.
  function featuredYear(now) {
    const ys = state.years.filter(y => y.data && (!y.announced || y.announced <= now.date));
    const set = ys.find(y => yes(y.featured));
    if (set) return set.year;
    let pick = ys.find(y => y.coa_announced && y.coa_announced <= now.date) || ys.find(y => y.start && y.start <= now.date) || ys[ys.length - 1];
    if (pick && pick.end && pick.end < now.date) {
      const later = ys.filter(y => +y.year > +pick.year && (y.open || now.date >= pick.year + '-11-01'));
      if (later.length) pick = later[later.length - 1];
    }
    return (pick || {}).year;
  }
  // The guide (a home-screen icon kept for years) opens on the next Conference whose dates are out.
  function guideYear(now) {
    const ys = state.years.filter(y => y.data && y.start && (!y.announced || y.announced <= now.date) && (y.end || y.start) >= O.isoAddDays(now.date, -1));
    return ys.length ? ys[ys.length - 1].year : featuredYear(now);
  }

  const schedulePosted = () => state.model.days.some(d => d.items.length) && postedBy(S().schedule_posted);
  // A carried-over call-in line is shown once this year's COA has confirmed it (the server leaves an
  // unconfirmed one out for the public, and tells a member it's held: call_in_held), so a member sees
  // what the public will, unless previewing.
  const callIn = () => { const s = S(); return s.call_in_number && (s.call_in_held !== 'yes' || PREVIEW) ? { num: s.call_in_number, pin: s.call_in_pin || '' } : null; };

  // The services: the worship services, Communion and the council (Caleb, Oct 24: "just the worship
  // services"; the singings, the teaching and the outreach meeting are in the Schedule). They fill the
  // Services list and set the main place. The COA may name the kinds itself (settings services_kinds,
  // "worship|communion|council"); blank is those three.
  const SERVICE_KINDS = ['worship', 'communion', 'council'];
  let kindsOf = null, kinds = SERVICE_KINDS;
  const serviceKinds = () => {
    const s = S() || {};
    if (kindsOf !== s) { kindsOf = s; const v = String(s.services_kinds || '').split(/[,|;]+/).map(O.slug).filter(Boolean); kinds = v.length ? v : SERVICE_KINDS; }
    return kinds;
  };
  const isService = it => serviceKinds().indexOf(it.kind) > -1;
  // What someone at home can follow in the week (the header's Now and Next): the services, and anything
  // else carried on the call-in line.
  const fromHome = it => isService(it) || !!it.callIn;
  const serviceItems = d => d.items.filter(isService);

  // The Conference runs from its first day through its last day of services (years.csv `end`, or
  // the last day in the schedule with a service). A departure day after that is not the week.
  function conf() {
    const days = state.model.days, r = yearRow(state.year) || {};
    const withSvc = days.filter(d => d.items.some(isService));
    return { first: r.start || days[0].date, end: r.end || (withSvc.length ? withSvc[withSvc.length - 1].date : days[days.length - 1].date), last: days[days.length - 1].date };
  }

  // Where the year stands. The same rules as the server's (module-public.php ogc_pub_status_word), so
  // the word the server drew is the word this draws, at every minute ("Past" turned into
  // "This week" as the page loaded on check-out morning). tools/smoke-conference.sh compares them.
  function status() {
    if (!state.model.days.length) return { kind: 'announced' };
    const now = state.now.date, c = conf(), r = reg();
    if (now >= c.first && now <= c.end) return { kind: 'live' };
    // staying: people are still on campus (the morning of check-out day), so the campus numbers and
    // the packet stay until the last thing in the schedule is over.
    if (now > c.end) return { kind: 'past', staying: staying(c) };
    if (regIsOpen(r, now)) return { kind: 'registration', left: r.closes ? O.daysBetween(now, r.closes) : 99 };
    if (r.mode !== 'none' && ((r.closes && now > r.closes) || (r.closed && r.closed <= now))) return { kind: 'closed' };
    return { kind: 'upcoming' };
  }
  // How the year registers, from the server (years: reg_mode, reg_opens, reg_closes, reg_closed): the
  // COA's chosen tool ('site', 'link' or 'none') and its dates. Never a default, and never a date the
  // pickup carried from last year that nobody scheduled (2027 would have opened by itself
  // on Feb 25), so the page has no Register button until the COA chooses.
  const isoDay = v => /^\d{4}-\d{2}-\d{2}$/.test(String(v || '')) && String(v).indexOf('9999') !== 0;
  function reg() {
    const r = yearRow(state.year) || {}, m = String(r.reg_mode || '').toLowerCase();
    return { mode: /^(site|link)$/.test(m) ? m : 'none', opens: isoDay(r.reg_opens) ? r.reg_opens : '', closes: isoDay(r.reg_closes) ? r.reg_closes : '', closed: isoDay(r.reg_closed) ? r.reg_closed : '' };
  }
  const regIsOpen = (r, now) => r.mode !== 'none' && !!r.opens && r.opens <= now && (!r.closes || now <= r.closes) && !(r.closed && r.closed <= now);
  const regMode = () => reg().mode;
  // Postponed or cancelled after it was announced (years: status).
  const held = () => { const v = String((yearRow(state.year) || {}).status || '').toLowerCase(); return v === 'postponed' ? 'Postponed' : /^cancell?ed$|^canceled$/.test(v) ? 'Cancelled' : ''; };
  // The time of year, one word: Announced · Upcoming · Registration open · Next week · This week ·
  // Past (Luke, Oct 9). What to do once online registration closes ("Register at check-in") is a line
  // under the buttons, never the time of year.
  function statusWord(st) {
    if (held()) return held();
    if (st.kind === 'announced') return 'Announced';
    if (st.kind === 'live' || st.staying) return 'This week';
    if (st.kind === 'past') return 'Past';
    if (st.kind === 'registration') return 'Registration open';
    return O.daysBetween(state.now.date, conf().first) <= 7 ? 'Next week' : 'Upcoming';
  }

  function staying(c) {
    if (c.last <= c.end || state.now.date > c.last) return false;
    if (state.now.date < c.last) return true;
    const d = state.model.days[state.model.days.length - 1];
    const leave = Math.max.apply(null, d.items.map(it => it.end != null ? it.end : startOf(it) != null ? startOf(it) : 0).concat(0));
    return state.now.minutes < leave;
  }

  // Conference week, and the morning people check out: the page is a guide to the day.
  // The week (and the morning people check out): the header is the day, rows know what's on now.
  const theWeek = st => st.kind === 'live' || !!st.staying;
  // News sits in the header before and during the Conference, so the COA's announcement is never
  // under the schedule (webmasters, Oct 20); once it's over, it goes back under the week.
  const newsUp = st => st.kind !== 'past';
  // From a week before: Places and Help can be looked over before travelling.
  const nearWeek = st => theWeek(st) || (schedulePosted() && /^(upcoming|registration|closed)$/.test(st.kind) &&
    O.daysBetween(state.now.date, conf().first) >= 0 && O.daysBetween(state.now.date, conf().first) <= 7);
  // Once the schedule is posted (and until the Conference is over), a row opens its sheet.
  const sheets = st => schedulePosted() && (st.kind !== 'past' || !!st.staying) && st.kind !== 'announced';
  const phoneQ = matchMedia('(max-width: 767px)');
  // The guide's page is the app; the Conference page is always the page (Services · Schedule only).
  const onSite = () => GUIDE;
  // Between the two pages, the year (and a member's preview date and time zone) go along.
  const pass = k => qp(k) ? '&' + k + '=' + encodeURIComponent(qp(k)) : '';
  const pageUrl = (which, extra) => (which === 'guide' ? '../guide/' : '../schedule-hub/') + '?year=' + state.year + (extra || '') + pass('as-of') + pass('tz') + pass('preview');
  // The views this reader can pick, first one the default.
  function weekViews(st) {
    const full = hasFull(st) ? ['full'] : [], extra = (placeGroups().length ? ['places'] : []).concat(helpRows().length || schedulePosted() ? ['help'] : []);
    // The guide holds the schedule, Places and Help from the day the schedule is posted (so it can be
    // saved at home, before the trip); Today comes in the week.
    // In the week itself the guide always has Help (911 and the campus address) and Places, published
    // schedule or not (it was a blank page saying "Schedule not posted yet").
    if (onSite(st)) return sheets(st) || PREVIEW ? (theWeek(st) ? ['today'] : []).concat(full, extra)
      : theWeek(st) ? ['help'].concat(placeGroups().length ? ['places'] : []) : [];
    // The Conference page keeps its own two views in every season, on every device. Places and Help
    // belong to the guide, reached by its one link (Michael, Oct 13: not on every screen).
    return ['services'].concat(full);
  }
  function viewFor(st) {
    const vs = weekViews(st);
    return vs.indexOf(state.view) > -1 ? state.view : vs[0];
  }
  const hasPlaces = st => weekViews(st).indexOf('places') > -1;
  // One name for each view on every page and device ("Full schedule" on a phone, "Schedule" elsewhere).
  const viewLabel = (v, st) => ({ services: 'Services', today: 'Today', places: 'Places', help: 'Help', full: 'Schedule' })[v];

  function mainItems(d, st) {
    if (st.kind === 'past' && !st.staying) return d.items.filter(it => isService(it) || plays(it).length);
    return d.items.filter(it => it.audience === 'conference' || it.audience === 'all');
  }

  function mainPlace() {
    const n = {};
    let best = null;
    state.model.days.forEach(d => d.items.filter(isService).forEach(it => {
      if (!it.place) return;
      n[it.place.name] = (n[it.place.name] || 0) + 1;
      if (!best || n[it.place.name] > n[best.name]) best = it.place;
    }));
    return best;
  }

  // A row with no clock time but a sort time ("After Communion") starts at its sort time. A row with
  // no end ("Council continues", "Pick up children") runs until the next thing for the same people
  // starts, or to the end of the day.
  const startOf = it => it.start != null ? it.start : it.sort < 1439 ? it.sort : null;
  const group = a => a === 'all' ? 'conference' : a;
  function endOf(it, d) {
    if (it.end != null) return it.end;
    const s = startOf(it);
    const later = d.items.filter(x => group(x.audience) === group(it.audience) && startOf(x) != null && startOf(x) > s).map(startOf);
    return later.length ? Math.min.apply(null, later) : 1440;
  }
  function rowState(it, d, st) {
    if (!theWeek(st)) return '';
    if (d.date < state.now.date) return 'past';
    if (d.date > state.now.date) return 'upcoming';
    const s = startOf(it), m = state.now.minutes;
    if (s == null) return 'upcoming';
    return m < s ? 'upcoming' : m < endOf(it, d) ? 'now' : 'past';
  }
  // "Now" is marked once: of the rows on at this moment, the one that began last (a service first).
  function nowOne(items, d, st) {
    let best = null;
    items.forEach(it => {
      if (rowState(it, d, st) !== 'now') return;
      if (!best || startOf(it) > startOf(best) || (startOf(it) === startOf(best) && isService(it) && !isService(best))) best = it;
    });
    return best;
  }
  // At home, the service on now: the one the Services list marks NOW, so the card and the list agree.
  const homeNow = (d, st) => nowOne(serviceItems(d), d, st);

  function nextService(st) {
    if (st.kind !== 'live') return null;
    let next = null;
    for (const d of state.model.days) for (const it of serviceItems(d)) {
      const s = rowState(it, d, st);
      if (s === 'now') return null;
      if (s === 'upcoming' && !next) next = it;
    }
    return next;
  }

  function buildQueue() {
    state.queue = [];
    state.model.days.forEach(d => d.items.forEach(it => plays(it).forEach(a => {
      // Attachment ids repeat from year to year, so the year is part of a recording's id.
      if (a.audio) state.queue.push(Object.assign({}, a, { id: state.year + ':' + a.id, year: state.year, where: d.name + ' ' + (it.start != null ? O.formatTime(it.start) : '') }));
    })));
  }
  const recId = a => state.year + ':' + a.id;

  /* ------------------------------------------------ the schedule's changes (the server's change marks) */

  // changes.csv, kept by the server once the schedule is published: a row moved, a room changed, a row
  // removed. A row shows its change for a day ("Moved · was 6:00 PM"); a removed row stays, struck
  // through, until its day is over.
  const MARK_HOURS = 24;
  const changeAge = c => { const p = /^(\d{4}-\d{2}-\d{2})T(\d{2}):(\d{2})/.exec(c.at || ''); if (!p) return Infinity; return O.daysBetween(p[1], state.now.date) * 1440 + state.now.minutes - (+p[2] * 60 + +p[3]); };
  const freshChanges = () => state.changes.filter(c => { const a = changeAge(c); return a >= 0 && a <= MARK_HOURS * 60; });
  function changeOf(it) {
    const hits = freshChanges().filter(c => c.what !== 'cancelled' && c.what !== 'added' && (c.row ? c.row === it.row : O.slug(c.title) === O.slug(it.title) && dayOf(c.day) === it.day));
    return hits.length ? hits[hits.length - 1] : null;
  }
  const dayOf = v => { const d = state.model.days.find(x => O.slug(x.name) === O.slug(v) || x.key === O.slug(v) || x.date === v); return d ? d.key : ''; };
  function changeText(c) {
    if (!c) return '';
    if (c.what === 'moved') {
      const t = O.parseTime(c.was);
      const wasDay = c.was_day && dayOf(c.was_day) !== dayOf(c.day) ? ' ' + c.was_day : '';
      return 'Moved · was ' + (t != null ? O.formatTime(t) : c.was) + wasDay;
    }
    if (c.what === 'room') { const p = state.model.places[String(c.was || '').toUpperCase()]; return 'Room changed' + (p ? ' · was ' + p.name : ''); }
    return '';
  }
  // Removed rows still to show on a day (through the end of that day).
  function cancelledOn(d) {
    return state.changes.filter(c => c.what === 'cancelled' && dayOf(c.day) === d.key && d.date >= state.now.date && changeAge(c) >= 0).map(c => {
      const start = O.parseTime(c.start), sort = start != null ? start : O.parseTime(c.sort_time);
      return { id: 'gone-' + O.slug((c.row || '') + c.title + c.day), cancelled: true, title: c.title, start, end: O.parseTime(c.end), sort: sort == null ? 1439 : sort,
        startText: start == null ? c.start : '', audience: O.normAudience(c.audience), kind: 'other', place: c.place ? state.model.places[c.place.toUpperCase()] || null : null, attachments: [] };
    });
  }
  /* ============================================================ render */

  // No word, time or Scripture reference breaks across two lines at a phone's width (Michael's rule:
  // never "call- / in", "2 / Corinthians 4", "Matthew / 16" or "2:30 / PM"). After each drawing the text
  // gets a non-breaking hyphen in a hyphenated word ("call-in", "sign-ups") and non-breaking spaces
  // before AM/PM, after a book's number ("2 Corinthians") and between a name and its number
  // ("Matthew 16", "June 5").
  // A span of time never breaks at its dash ("7:00 AM–" / "11:00 PM"): word joiners hold it.
  // A line may end with " ·" but never start with it ("Room 131 / · Barnes"): the space before the dot holds.
  const NB = [[/(\d|AM|PM)–(?=\d)/g, '$1\u2060–\u2060'], [/\b([A-Za-z]{2,10})-([A-Za-z]{2,10})\b/g, '$1\u2011$2'], [/(\d) (AM|PM|ET|CT|MT|PT)\b/g, '$1\u00a0$2'], [/\b(AM|PM) (ET|CT|MT|PT|AKT|HT)\b/g, '$1\u00a0$2'], [/(^|[\s(;])([1-3]) (?=[A-Z][a-z])/g, '$1$2\u00a0'], [/\b([A-Z][a-z]+) (\d{1,3}(?::\d[\d–-]*)?)\b/g, '$1\u00a0$2'], [/ · /g, '\u00a0· ']];
  function tidy(el) {
    if (!el) return;
    const w = document.createTreeWalker(el, NodeFilter.SHOW_TEXT);
    for (let n = w.nextNode(); n; n = w.nextNode()) {
      const v = n.nodeValue;
      if (!/\d|[A-Za-z]-[A-Za-z]/.test(v) || v.indexOf('\u2060') > -1 || (n.parentNode && /^(SCRIPT|STYLE|TEXTAREA)$/.test(n.parentNode.nodeName))) continue;
      let t = v;
      NB.forEach(([re, to]) => { t = t.replace(re, to); });
      if (t !== v) n.nodeValue = t;
    }
  }

  // keep: the same year re-drawn (a day, a view, the width, the minute): the folds a reader opened
  // stay open and the control just pressed keeps the focus.
  function render(keep) {
    const focus = keep ? focusKey(document.activeElement) : '';
    const st = status();
    if (st.kind === 'announced') { renderStub(st); return; }
    buildQueue();
    const days = state.model.days.filter(d => mainItems(d, st).length);
    if (!days.some(d => d.key === state.day)) state.day = firstDay(st, days);
    const v = viewFor(st), full = v === 'full', app = onSite(st);
    const enter = state.enter;
    state.enter = '';
    state.zonesSaid = false;
    appMode(app);
    if (app) root.innerHTML = previewBar() + appView(st, v, days, enter === 'fade');
    else {
      // One list on screen: the week once it is posted. Everything else waits closed below. (News is
      // in the header until the Conference is over; after it, a year with no schedule lists it here.)
      const season = schedulePosted() ? (nearWeek(st) ? weekBand(st, v, days) : weekPart(st, full, days)) : newsUp(st) ? '' : news(st);
      const M = season ? '<section class="wk-main' + (enter === 'fade' ? ' wk--fade' : '') + '"><div class="wk-wrap">' + season + '</div></section>' : '';
      root.innerHTML = previewBar() + '<div class="wk' + (enter === 'next' || enter === 'prev' ? ' wk--' + enter : '') + '">' + head(st) + M + shelf(st) + '</div>';
    }
    root.querySelectorAll('details[data-k]').forEach(d => { if (state.open.has(d.dataset.k)) d.open = true; });
    document.title = GUIDE ? (v ? viewLabel(v, st) + ' · ' : '') + state.year + ' Conference guide'
      : (v === 'full' || v === 'help' || v === 'places' ? viewLabel(v, st) + ' · ' : '') + state.year + ' Annual Conference – Old German Baptist Brethren Church, New Conference';
    tidy(root);
    // Drawn: the page no longer holds a screen's height for it (see week.css).
    root.classList.add('is-drawn');
    if (focus) { const el = root.querySelector(focus); if (el) el.focus({ preventScroll: true }); }
    markSeen(st);
    syncPlayer();
    mountMap();
  }

  // A member's preview (the year page's See it, or a date chosen there): one bar that says so, the
  // date being viewed, and Exit. (Never in the public header.)
  function previewBar() {
    const asOf = !!previewOf(yearRow(state.year));
    if (!PREVIEW && !(asOf && (WP.member || []).length + (WP.webmaster ? 1 : 0))) return '';
    const u = new URL(location.href);
    ['preview', 'as-of', 'tz'].forEach(k => u.searchParams.delete(k));
    // A standard label, and the time viewed where the Conference is ("Sat, May 29 · 10:15 AM in
    // Marion").
    const town = state.model ? String(S().city || S().venue || '').split(',')[0] : '';
    const at = asOf ? O.fmtDate(state.now.date, 'short') + ' · ' + O.formatTime(state.now.minutes) + (town ? ' in ' + town : '') : '';
    return '<p class="wk-pvbar" role="status"><b>Preview</b>' + (PREVIEW ? '<span>Drafts shown</span>' : '') + (at ? '<span>' + esc(at) + '</span>' : '') +
      '<a href="' + esc(u.pathname + u.search) + '">Exit</a></p>';
  }
  // A part the public can't see yet, marked in a member's preview.
  const unpub = iso => PREVIEW && iso && !publicBy(iso) ? ' <em class="wk-tag wk-tag--draft">Not published</em>' : '';

  // A selector for the control that has the focus, to find its twin after the page is re-drawn.
  function focusKey(el) {
    if (!el || !root.contains(el) || !el.dataset) return '';
    for (const k of ['view', 'day', 'play', 'act', 'ev', 'hx', 'aud', 'year', 'open']) if (el.dataset[k]) return '[data-' + k + '="' + el.dataset[k] + '"]';
    if (el.hasAttribute('data-menu')) return '[data-menu]';
    if (el.tagName === 'SUMMARY' && el.parentElement.dataset.k) return 'details[data-k="' + el.parentElement.dataset.k + '"] > summary';
    return '';
  }

  function firstDay(st, days) {
    const today = days.find(d => d.date === state.now.date);
    if (theWeek(st) && today) return today.key;
    return days.length ? days[0].key : '';
  }

  /* ------------------------------------------------ "New" since the last visit (this device only) */

  // Parts appear by themselves (the schedule, the packet, recordings, the call-in line). On this device,
  // one that appeared since the last visit carries a small "New" for seven days, so a returning reader
  // sees what changed rather than wondering. Kept in this browser only; a preview never counts.
  const SEEN = 'ogc-seen-';
  let seen = null;
  function seenRead() {
    if (seen && seen.year === state.year) return seen;
    let v = null;
    try { v = JSON.parse(localStorage.getItem(SEEN + state.year)); } catch (e) { /* private window */ }
    seen = Object.assign({ year: state.year, first: '', parts: {} }, v || {});
    return seen;
  }
  function partsShown(st) {
    const p = [];
    if (schedulePosted()) p.push('schedule');
    if (packetParts().length && postedBy(S().packet_posted)) p.push('packet');
    if (state.queue.length) p.push('recordings');
    if (callIn() && /^(registration|closed|live)$/.test(st.kind)) p.push('callin');
    if (paperDocs().length) p.push('papers');
    return p;
  }
  function markSeen(st) {
    if (qp('as-of') || PREVIEW) return;
    const s = seenRead(), today = state.now.date;
    let changed = !s.first;
    partsShown(st).forEach(k => { if (!s.parts[k]) { s.parts[k] = s.first ? today : '0'; changed = true; } });
    if (!s.first) s.first = today;
    if (changed) try { localStorage.setItem(SEEN + state.year, JSON.stringify({ first: s.first, parts: s.parts })); } catch (e) { /* not kept */ }
  }
  // A part first seen within seven days, on a visit after the first one.
  function isNew(k) {
    if (qp('as-of') || PREVIEW) return false;
    const s = seenRead(), at = s.parts[k];
    return !!at && at !== '0' && O.daysBetween(at, state.now.date) <= 7;
  }
  const newTag = k => isNew(k) ? ' <em class="wk-tag wk-tag--new">New</em>' : '';

  /* ------------------------------------------------ 1. the Conference */

  // Every Conference, for the list the year opens: the years with this page first, then the older
  // years, which are their own pages on the site. The year on screen has the tick; the next Conference
  // to come carries the header's own word for it ("Upcoming"), and a year whose recordings are posted
  // says Recordings (the server's `recordings`), the way back to last year's sermons.
  function yearList() {
    const to = known().filter(r => r.start ? (r.end || r.start) >= state.now.date : r.hosts && +r.year > +state.now.date.slice(0, 4)).sort((a, b) => a.year - b.year);
    const nx = to.find(r => r.start) || to[0];
    const tag = r => nx && r.year === nx.year && r.status_word && r.status_word !== 'Past' ? r.status_word : r.recordings && !(nx && r.year === nx.year) ? 'Recordings' : '';
    const item = r => {
      const t = '<b>' + esc(r.year) + '</b><span>' + esc(r.hosts) + '</span>' + (tag(r) ? '<em>' + esc(tag(r)) + '</em>' : '');
      if (r.year === state.year) return '<li><span class="is-on" aria-current="true">' + t + I.check + '</span></li>';
      if (opens(r)) return '<li>' + yearLink(r.year, t) + '</li>';
      if (r.page && safeUrl(r.page)) return '<li><a href="' + esc(safeUrl(r.page)) + '">' + t + I.out + '</a></li>';
      return '';
    };
    const ys = known(), here = ys.filter(opens), old = ys.filter(r => !opens(r) && r.page);
    return here.map(item).join('') + (old.length ? '<li class="wk-years__k" aria-hidden="true">Older pages</li>' + old.map(item).join('') : '');
  }

  // The year, its status, the way to the years beside it: the same on every season's header.
  // ‹ 2026 and 2028 › name the year they go to; with nowhere to go, there's no arrow.
  // The time of year is always the kicker's second word, in every season and on 2028's short page:
  // "ANNUAL CONFERENCE · UPCOMING" (Luke: which time of year the page is showing).
  function yearBlock(st) {
    const ys = known(), i = ys.findIndex(y => y.year === state.year);
    const go = r => r && (opens(r) || r.page) ? r : null;
    const prevR = go(ys[i + 1]), nextR = go(ys[i - 1]);
    const arrow = (r, dir) => {
      if (!r) return '';
      const cls = 'wk-arrow wk-arrow--' + dir;
      const inner = dir === 'prev' ? I.prev + '<span>' + esc(r.year) + '</span>' : '<span>' + esc(r.year) + '</span>' + I.next;
      const label = (dir === 'prev' ? 'Previous year, ' : 'Next year, ') + r.year;
      if (opens(r)) return yearLink(r.year, inner, cls, ' aria-label="' + esc(label) + '"');
      return safeUrl(r.page) ? '<a class="' + cls + '" href="' + esc(safeUrl(r.page)) + '" aria-label="' + esc(label + ', its own page') + '">' + inner + '</a>' : '';
    };
    const word = statusWord(st);
    // Who's signed in (the signin area's mark) sits at the right of the kicker's row (alone on
    // a row of its own, it added 64 px to a phone's header).
    return '<div class="wk-yr"><div class="wk-yr__top">' +
      '<p class="wk-kicker" aria-hidden="true">Annual Conference' + (word ? '<span class="wk-status' + (held() ? ' is-held' : '') + '"> · ' + esc(word) + '</span>' : '') + '</p>' + acct() + '</div>' +
      '<div class="wk-yrline">' +
        '<h1 class="wk-title"><span class="ogc-sr">Annual Conference </span>' +
          '<button type="button" class="wk-year" data-menu aria-expanded="false" aria-controls="wk-years" aria-label="' + esc(state.year + (word ? ', ' + word.toLowerCase() : '') + '. Choose another year') + '">' + esc(state.year) + I.down + '</button></h1>' +
        (prevR || nextR ? '<span class="wk-arrows">' + arrow(prevR, 'prev') + arrow(nextR, 'next') + '</span>' : '') +
      '</div>' +
      '<ul class="wk-years" id="wk-years" hidden>' + yearList() + '</ul>' +
    '</div>';
  }
  // The next Conference after this one, when it's announced and this page isn't over yet: one quiet
  // line under the buttons ("2028 · Hosted by the Ohio and Tennessee districts ›"), in place of a
  // Coming up card that only repeated the arrow. (A past year says it with nextLine.)
  function nextYearLine(st) {
    if (st.kind === 'past') return '';
    const nx = ahead().find(r => +r.year > +state.year);
    if (!nx) return '';
    const txt = esc(nx.year) + ' · ' + (nx.start ? lw(nx) + esc(noYear(O.fmtDateSpan(nx.start, nx.end))) : 'Hosted by the ' + esc(nx.hosts));
    return '<p class="wk-sub wk-sub--next">' + (opens(nx) ? yearLink(nx.year, txt + ' ›', 'wk-linklike') : txt) + '</p>';
  }
  // A year opened on this page: a real link (?year=2026, so it opens in a new tab and works without
  // JavaScript), turned in place by the click handler.
  const yearHref = y => { const u = new URL(location.href); u.search = ''; u.hash = ''; u.searchParams.set('year', y); ['as-of', 'tz', 'preview'].forEach(k => { if (qp(k)) u.searchParams.set(k, qp(k)); }); return u.pathname + u.search; };
  const yearLink = (y, inner, cls, attrs) => '<a href="' + esc(yearHref(y)) + '"' + (cls ? ' class="' + cls + '"' : '') + ' data-year="' + esc(y) + '"' + (attrs || '') + '>' + inner + '</a>';

  // Who's signed in (the signin area's mark: Your sign-ups, Sign out), on the kicker's row. Signing out
  // clears what this phone kept for the guide (there was no way to sign out but the dev
  // button). ogc-account.js fills the slot.
  const acct = () => WP.me && WP.me.email ? '<div class="wk-acct"><span class="ws-bar__in"></span></div>' : '';
  // Beside the words on a laptop (under the buttons on a phone): News, where the picture was. The
  // picture went (Oct 20, Caleb and Andrew: not needed, and a phone never showed it); it stays only as
  // the link preview's image and the player's artwork.
  function head(st) {
    if (theWeek(st)) return guideHead(st);
    const nw = newsUp(st) ? news(st) : '';
    return '<header class="wk-hero"><div class="wk-wrap wk-hero__in"><div class="wk-hero__text">' + yearBlock(st) +
      facts(st) + heldLine() + notices(st) + action(st) + guideDoor(st) + nextYearLine(st) +
      '</div>' + (nw ? '<div class="wk-hero__news">' + nw + '</div>' : '') + '</div></header>';
  }
  // When, where, who hosts: an icon and a line each.
  // inWeek: today's line stands in for the dates, so they aren't said twice; the place and hosts stay
  // only while there's no schedule to name the place.
  function facts(st, inWeek) {
    const s = S();
    if (inWeek && schedulePosted()) return '';
    const future = st.kind === 'upcoming' || st.kind === 'registration' || st.kind === 'closed';
    // The dates themselves never break ("May 28 – / June 1"): the line breaks after "Lord willing,".
    const when = (future && !held() ? esc('Lord willing, ') : '') + '<span class="wk-nowrap">' + esc(noYear(span(state.year))) + '</span>';
    // The hosts line is never a link, in any year (it was one only where a post said it); the post
    // that announced them is in News.
    const hosts = 'Hosted by the ' + esc(s.hosts);
    const fact = (icon, body) => '<li>' + icon + '<span>' + body + '</span></li>';
    const dirs = safeUrl(s.directions) || O.mapUrl({ name: s.venue }, s);
    return '<ul class="wk-facts">' +
      (inWeek ? '' : fact(I.cal, when)) +
      fact(I.pin, '<a href="' + esc(dirs) + '" target="_blank" rel="noopener" title="Open in Maps">' + esc(s.venue) + '</a>' + (s.city ? '<small>' + esc(s.city) + '</small>' : '')) +
      (s.hosts ? fact(I.people, hosts) : '') +
      '</ul>';
  }
  // A Conference postponed or cancelled after it was announced: said once, in red, and no buttons.
  const heldLine = () => held() ? '<p class="wk-notice wk-notice--urgent">' + I.notice + '<span>' + esc(held()) + '</span></p>' : '';

  // A year with only its hosts announced (2028): the year, Announced, who hosts it (linked to where it
  // was announced), and its dates and place once they're out. Never a date or place that isn't.
  function renderStub(st) {
    const r = yearRow(state.year) || {};
    appMode(GUIDE);
    const facts = '<ul class="wk-facts">' +
      (r.start ? '<li>' + I.cal + '<span>Lord willing, ' + esc(noYear(O.fmtDateSpan(r.start, r.end || r.start))) + '</span></li>' : '') +
      (r.start && r.venue ? '<li>' + I.pin + '<span>' + esc(r.venue) + (r.city ? '<small>' + esc(r.city) + '</small>' : '') + '</span></li>' : '') +
      (r.hosts ? '<li>' + I.people + '<span>Hosted by the ' + esc(r.hosts) + '</span></li>' : '') + '</ul>';
    const cards = [coming(st)].filter(Boolean), about = aboutLine();
    // No picture: its place isn't announced, and a photo of a campus would say one.
    root.innerHTML = '<div class="wk' + (state.enter === 'next' || state.enter === 'prev' ? ' wk--' + state.enter : '') + '"><header class="wk-hero wk-hero--bare"><div class="wk-wrap wk-hero__in"><div class="wk-hero__text">' + yearBlock(st) + facts +
      '</div></div></header>' + (cards.length || about ?
      '<section class="wk-shelf' + (cards.length ? '' : ' wk-shelf--bare') + '"><div class="wk-wrap">' + (cards.length ? '<div class="wk-cards wk-cards--1">' + cards.join('') + '</div>' : '') + about + '</div></section>' : '') + '</div>';
    state.enter = '';
    tidy(root);
    document.title = state.year + ' Annual Conference – Old German Baptist Brethren Church, New Conference';
    root.classList.add('is-drawn');
  }

  // During the week the header is still the year (Luke, Oct 9: a page that changes shape loses people),
  // with today under it: the day, the time where the Conference is, what's on now and next, and the
  // one button. The guide, its own page, is the one titled by the day.
  // News goes under Now and Next (on a phone, under the button).
  function guideHead(st) {
    const s = S(), nn = nowNext(st), nw = newsUp(st) ? news(st) : '';
    const today = O.fmtDate(state.now.date, 'long') + ' · ' + O.formatTime(state.now.minutes) + ' in ' + String(s.city || s.venue || '').split(',')[0];
    return '<header class="wk-hero wk-hero--guide"><div class="wk-wrap wk-hero__in">' +
      '<div class="wk-hero__top">' + yearBlock(st) +
        '<p class="wk-today2">' + esc(today) + '</p>' + facts(st, true) + heldLine() + notices(st) +
      '</div>' +
      (nn || nw ? '<div class="wk-hero__aside">' + (nn ? '<div class="wk-hero__now">' + nn + '</div>' : '') + (nw ? '<div class="wk-hero__news">' + nw + '</div>' : '') + '</div>' : '') +
      '<div class="wk-hero__act">' + action(st) + guideDoor(st) + '</div>' +
      '</div></header>';
  }

  // A time with its zone when the reader is elsewhere ("7:00 PM ET · 4:00 PM PT"); the venue's time alone otherwise.
  function bothClocks(date, minutes) {
    const c = theirClock(date, minutes);
    if (!c) return O.formatTime(minutes);
    return O.formatTime(minutes) + ' ' + zoneShort(venueTZ(), c.inst) + ' · ' + c.time + ' ' + zoneShort(viewTZ(), c.inst) + (c.day ? ' ' + c.day : '');
  }

  // A time at the venue, with its zone when the reader is somewhere else ("4:00 PM ET"). Every time is
  // labelled once the reader is elsewhere; only the call-in line's rows add the reader's own clock
  // (breakfast and check-out read "4:00 AM PT" to someone at home).
  const zt = (date, m) => { const c = theirClock(date, m); return O.formatTime(m) + (c ? ' ' + zoneShort(venueTZ(), c.inst) : ''); };
  // A span of time. One that starts at noon writes both halves ("12:00 PM–11:00 PM":
  // "12:00–11:00 PM" read as midnight).
  const fmtRange = (a, b) => b != null && b !== a && Math.floor((((a % 1440) + 1440) % 1440) / 60) === 12 ? O.formatTime(a) + '–' + O.formatTime(b) : O.formatRange(a, b);
  const zoneAt = (date, a) => { const c = theirClock(date, a); return c ? ' ' + zoneShort(venueTZ(), c.inst) : ''; };
  const ztRange = (date, a, b) => fmtRange(a, b) + zoneAt(date, a);

  // A span on both clocks: "2:30–4:00 PM ET · 11:30 AM–1:00 PM PT".
  function rangeBoth(date, start, end) {
    const c = theirClock(date, start);
    if (!c) return fmtRange(start, end);
    const off = (O.wallNow(viewTZ(), c.inst).minutes - start + 2880) % 1440;
    const theirs = fmtRange((start + off) % 1440, end != null ? (end + off) % 1440 : null);
    return fmtRange(start, end) + ' ' + zoneShort(venueTZ(), c.inst) + ' · ' + theirs + ' ' + zoneShort(viewTZ(), c.inst) + (c.day ? ' ' + c.day : '');
  }

  // What's on now and what's next. At home: the services and anything else on the call-in line, whoever
  // it's for; a service on now is the one the Services list marks NOW, so the two agree. In the guide:
  // the Conference's rows and the programs chosen on this device (a chosen program's row leads). On
  // check-out morning, check-out itself.
  function nowNext(st) {
    state.cardNow = ''; state.cardShown = [];
    const days = state.model.days, i = days.findIndex(d => d.date === state.now.date), today = days[i];
    if (!today || !schedulePosted()) return '';
    const m = state.now.minutes;
    const pool = d => onSite(st) || st.staying && !d.items.some(fromHome) ? d.items.filter(shows) : d.items.filter(fromHome);
    const items = pool(today);
    let on = onSite(st) ? nowOne(items, today, st) : homeNow(today, st) || nowOne(items.filter(fromHome), today, st);
    // In the guide a chosen program on now (Preteens, Young Folks) leads over the Conference's own row.
    if (onSite(st) && on) {
      const prog = nowOne(items.filter(it => it.audience === 'preteens' || it.audience === 'youngfolks'), today, st);
      if (prog) on = prog;
    }
    // Your shift, when you're on one now, takes the Now line: the card is two lines at most, Now and
    // Next, so the first screen doesn't repeat itself.
    const shift = onSite(st) ? myShifts().find(sh => sh.start <= m && m < sh.end) : null;
    let next = items.find(it => it !== on && startOf(it) != null && startOf(it) > m), nd = today;
    if (!next) for (const d of days.slice(i + 1)) {
      const f = pool(d).find(it => startOf(it) != null);
      if (f) { next = f; nd = d; break; }
    }
    if (!on && !next && !shift) return '';
    // At home, the Call in button under the card already says these are on the line; before and after
    // the week, a row on the line says so instead of its building. A room is written the one way.
    const button = st.kind === 'live' && !!callIn();
    const where = it => !onSite(st) && it.callIn && callIn() ? (button ? '' : 'On the call-in line') : it.place && !it.place.unknown ? roomText(it.place, it.title) : '';
    // The reader's own clock only for what they can follow from home (the call-in line's rows).
    const at = (it, date, m) => it.callIn && !onSite(st) ? bothClocks(date, m) : zt(date, m);
    const when = (it, d) => (d === today ? '' : (d === days[i + 1] ? 'Tomorrow' : O.fmtDate(d.date, 'weekday')) + ', ') + (it.start != null ? at(it, d.date, it.start) : it.startText);
    // The whole line is one tap (its title's button stretches over it).
    const line = (k, it, info, extra) => '<div class="wk-nn' + (k === 'Now' ? ' is-now' : '') + (sheets(st) ? ' is-tap' : '') + '"><span class="wk-nn__k">' + k + '</span><div class="wk-nn__c">' +
      (sheets(st) ? '<button type="button" class="wk-nn__t" data-ev="' + esc(it.id) + '">' + esc(it.title) + '</button>' : '<b>' + esc(it.title) + '</b>') +
      '<small>' + esc(info.filter(Boolean).join(' · ')) + '</small>' + (extra || '') + '</div></div>';
    const mins = next && nd === today ? startOf(next) - m : null;
    const soon = mins != null && mins <= 60 ? '<em class="wk-soon">Starts in ' + (mins === 60 ? '1 hr' : mins + ' min') + '</em>' : '';
    const until = it => endOf(it, today) < 1440 ? 'Until ' + at(it, today.date, endOf(it, today)) : '';
    // Check-out's card is a status line: "10:00 AM · Keys · drop box, Barnes SE foyer" (its short note,
    // note_short); the whole note is in its sheet.
    // In the guide a meal next says its window ("4:05–7:00 PM"): it can be come to any time in it.
    const meal = it => onSite(st) && it.kind === 'meal' && it.start != null && it.end != null && it.end > it.start;
    const whenNext = (it, d) => meal(it) ? (d === today ? '' : (d === days[i + 1] ? 'Tomorrow' : O.fmtDate(d.date, 'weekday')) + ', ') + ztRange(d.date, it.start, it.end) : when(it, d);
    const nextInfo = next ? (next.kind === 'lodging' && next.noteShort ? [when(next, nd), next.noteShort] : [whenNext(next, nd), where(next)]) : [];
    const mineLine = shift ? '<div class="wk-nn is-now is-mine"><span class="wk-nn__k">Now</span><div class="wk-nn__c"><b>' + esc(shift.role) + '</b><small>' +
      esc(['Your shift', 'Until ' + zt(state.now.date, shift.end), shift.place && roomText(shift.place, shift.role)].filter(Boolean).join(' · ')) + '</small></div></div>' : '';
    state.cardShift = shift ? shift.id : '';
    state.cardNow = on ? on.id : '';
    // The rows the card shows today, which the guide's Today list doesn't show again.
    state.cardShown = [mineLine ? '' : state.cardNow, next && nd === today ? next.id : ''].filter(Boolean);
    return '<section class="wk-nowcard" aria-label="Now and next">' + (mineLine || (on ? line('Now', on, [until(on), where(on)]) : '')) +
      (next ? line('Next', next, nextInfo, soon) : '') + '</section>';
  }

  // The buttons follow what's published, not the season: Register once registration is open (by the
  // COA's choice of how), Volunteer from the day sign-ups are published, Add to calendar while there's
  // nothing else to do. One filled button; the rest are outlines or a quiet link.
  function action(st) {
    const s = S(), ci = callIn(), r = reg();
    if (held()) return '';
    const tel = ci ? '<a href="' + O.telHref(ci.num, ci.pin) + '" title="The phone dials the PIN by itself">' + esc(ci.num) + '</a>' : '';
    // From registration on, the call-in line has one place: here. During the week it becomes the button.
    // Said the same way everywhere: "Call-in line · 717-908-1961 · PIN 688 3602".
    const callLine = tel ? '<p class="wk-sub">' + I.phone + '<span>Call-in line · ' + tel + (ci.pin ? ' · <span class="wk-nowrap wk-pinnum">PIN ' + esc(pinText(ci.pin)) + '</span>' : '') + '</span>' + newTag('callin') + '</p>' : '';
    const link = (cls, url, label) => '<a class="' + cls + '" href="' + esc(url) + '"' + ext(url) + '>' + label + '</a>';
    const before = /^(upcoming|registration|closed)$/.test(st.kind);
    const regUrl = st.kind === 'registration' ? (r.mode === 'link' ? safeUrl(s.registration_url) : OWN.register + '?year=' + state.year + asOfParam()) : '';
    const vol = before && s.signups_posted && postedBy(s.signups_posted) ? OWN.volunteer + '?year=' + state.year + asOfParam()
      : before && st.kind !== 'upcoming' && safeUrl(s.volunteer_url) ? safeUrl(s.volunteer_url) : '';
    const ics = (WP.base || '/annual-conference/') + state.year + '.ics';
    let btns = '', sub = '';
    if (before) {
      // Register, with its last day in small type under it ("Closes May 21": bold in its last week,
      // "Last day" on the day). On a phone both buttons are full width.
      if (regUrl) btns += '<span class="wk-btnstack">' + link('wk-btn', regUrl, 'Register') + (r.closes ? '<small class="wk-closes' + (st.left <= 7 ? ' is-soon' : '') + '">' +
        esc(st.left === 0 ? 'Last day' : 'Closes ' + O.fmtDate(r.closes, 'md')) + '</small>' : '') + '</span>';
      if (vol) btns += link(regUrl ? 'wk-btn wk-btn--line' : 'wk-btn', vol, 'Volunteer');
      const dated = yearRow(state.year) && yearRow(state.year).start;
      if (!regUrl && !vol && dated) btns = '<a class="wk-btn" href="' + esc(ics) + '">' + I.cal + 'Add to calendar</a>';
      // In the last week the guide's door stands in for Add to calendar.
      else if (dated && !nearWeek(st)) sub += '<p class="wk-sub wk-sub--quiet">' + I.cal + '<span><a href="' + esc(ics) + '">Add to calendar</a></span></p>';
      // The call-in line once someone could use it: the schedule is posted, or the Conference is a week
      // away (it showed from March, three months early).
      if (schedulePosted() || O.daysBetween(state.now.date, conf().first) <= 7) sub = callLine + sub;
      if (st.kind === 'closed') {
        const gone = r.closed && (!r.closes || r.closed <= r.closes) ? r.closed : r.closes;
        const word = String(s.registration_after || 'checkin').toLowerCase() === 'none' ? 'Registration closed' : 'Register at check-in';
        sub = '<p class="wk-sub wk-sub--quiet">' + I.info + '<span title="' + esc('Online registration closed ' + O.fmtDate(gone, 'md')) + '">' + word + '</span></p>' + sub;
      }
    } else if (st.kind === 'live' || st.staying) {
      // The number is on the button (a phone dials it, a laptop reads it), the PIN centred under it.
      // The campus numbers are in Help.
      if (ci && st.kind === 'live') btns = '<span class="wk-btnstack wk-btnstack--call"><a class="wk-btn wk-btn--call" href="' + O.telHref(ci.num, ci.pin) + '" title="The phone dials the PIN by itself">' + I.phone + 'Call in&nbsp;· <span class="wk-btn__num">' + esc(ci.num) + '</span></a>' +
        (ci.pin ? '<small class="wk-pin">PIN ' + esc(pinText(ci.pin)) + '</small>' : '') + '</span>';
    } else if (st.kind === 'past') {
      // After a Conference: Play all, the one button, and when the next one is. Its minutes are in the
      // Minutes and papers card (a second full-width button said them twice); with nothing
      // to play, the minutes are the button.
      const m = theMinutes();
      if (state.queue.length) btns = '<button type="button" class="wk-btn" data-act="playall">' + playAllInner() + '</button>';
      else if (m) btns = link('wk-btn', m.url, 'Read the minutes');
      sub = state.queue.length ? nextLine() : '';
    }
    return btns || sub ? '<div class="wk-action' + (btns ? '' : ' wk-action--quiet') + '">' + (btns ? '<p class="wk-btns">' + btns + '</p>' : '') + sub + '</div>' : '';
  }

  // Play all: once the player is working through this year's list, the button pauses and resumes
  // the recording that is on (the player's own button), rather than starting the list again.
  const ownList = () => !!state.playing && state.queue.some(x => x.id === state.playing);
  const playAllInner = () => !ownList() ? I.play + 'Play all' : audio.paused ? I.play + 'Resume' : I.pause + 'Pause';
  function playAll() {
    if (!ownList()) { if (state.queue.length) play(state.queue[0].id); return; }
    audio.paused ? audio.play() : audio.pause();
  }

  // A notice: one line while it is true (a time of day or whole days), the words themselves the link to
  // the post. An urgent one (weather, a closed entrance) is the one red line.
  const atOrAfter = (iso, end) => { if (!iso) return true; const n = stamp(state.now); return iso.length <= 10 ? (end ? iso >= state.now.date : iso <= state.now.date) : (end ? iso.slice(0, 16) >= n : iso.slice(0, 16) <= n); };
  const liveNotices = () => (state.model.notices || []).filter(n => atOrAfter(n.from, false) && (!n.to || atOrAfter(n.to, true)));
  function notices(st) {
    const line = (text, url, urgent) => '<p class="wk-notice' + (urgent ? ' wk-notice--urgent' : '') + '"' + (urgent ? ' role="alert"' : '') + '>' + I.notice + '<span>' + (safeUrl(url) ? '<a href="' + esc(safeUrl(url)) + '"' + ext(url) + '>' + esc(text) + '</a>' : esc(text)) + '</span></p>';
    const ns = liveNotices().sort((a, b) => (b.kind === 'urgent') - (a.kind === 'urgent'));
    // (That online registration has closed is the kicker's status now, not a second line here.)
    return ns.map(n => line(n.text, n.url, n.kind === 'urgent')).join('');
  }

  // The Conferences still ahead of today, nearest first (not counted from the year on the page:
  // an old page never says "Lord willing" about a year that has passed).
  const ahead = () => known()
    .filter(r => r.year !== state.year && (r.start ? (r.end || r.start) >= state.now.date : r.hosts && +r.year > +state.now.date.slice(0, 4)))
    .sort((a, b) => a.year - b.year);
  // "Lord willing" only while a Conference has not begun.
  const lw = r => r.start && r.start > state.now.date ? 'Lord willing, ' : '';

  // After a Conference, the next one, once its dates are out: the question asked most.
  function nextLine() {
    const nx = ahead()[0];
    if (!nx || !nx.start) return '';
    // When it already asks people to do something, that ("2027 · Volunteer ›"); else when it is.
    if (OWN[nx.open] && /^(volunteer|register)$/.test(nx.open)) return '<p class="wk-sub">' + I.cal + '<span><a href="' + esc(OWN[nx.open] + '?year=' + nx.year) + '">' + esc(nx.year) + ' · ' + (nx.open === 'register' ? 'Register' : 'Volunteer') + ' ›</a></span></p>';
    const txt = esc(nx.year) + ' · ' + lw(nx) + esc(noYear(O.fmtDateSpan(nx.start, nx.end)));
    return '<p class="wk-sub">' + I.cal + '<span>' + (opens(nx) ? yearLink(nx.year, txt + ' ›', 'wk-linklike') : txt) + '</span></p>';
  }

  // After a Conference, its minutes, once they are posted: the quieter button beside Play all.
  const theMinutes = () => paperDocs().find(a => a.paper === 'minutes' || /minutes/i.test(a.title));

  /* ---------------------------------------------------- 2. the season */

  const hasFull = st => (st.kind !== 'past' || st.staying) && !yes(S().services_only) && schedulePosted() && state.model.days.some(d => d.items.some(it => !isService(it)));

  function printLink() {
    const s = S();
    if (!yes(s.services_only)) return '<a class="wk-print" href="../schedule/?data=' + esc(state.year) + '&print=preview' + esc(asOfParam()) + '" aria-label="Printable schedule">Print</a>';
    if (safeUrl(s.schedule_pdf)) return '<a class="wk-print" href="' + esc(safeUrl(s.schedule_pdf)) + '"' + ext(s.schedule_pdf) + ' aria-label="Printable schedule (PDF)">Print</a>';
    return '';
  }
  // Search: the week's rows, places, Help and the packet (and after a Conference, its recordings).
  const searchBtn = recs => '<button type="button" class="wk-searchbtn" data-act="search" aria-label="' + (recs ? 'Search recordings' : 'Search') + '" title="' + (recs ? 'Search recordings' : 'Search') + '">' + I.search + '</button>';

  // One heading row that never changes shape: the two views (the one on screen underlined) and Print.
  // Under it, once, the place most of it happens.
  function weekPart(st, full, days) {
    const recs = st.kind === 'past' && state.queue.length;
    let title;
    if (hasFull(st)) {
      const tab = (v, label, on) => '<button type="button" data-view="' + v + '" data-label="' + label + '" aria-pressed="' + on + '">' + label + '</button>';
      title = '<h2 class="ogc-sr">Schedule</h2><div class="wk-tabs" role="group" aria-label="Schedule">' + tab('services', 'Services', !full) + tab('full', 'Schedule', full) + '</div>';
    } else title = '<h2 class="wk-h">' + (recs ? 'Recordings' + newTag('recordings') : 'Services') + '</h2>';
    const bar = '<div class="wk-bar">' + title + '<span class="wk-bar__tools">' + (recs ? searchBtn(true) : st.kind === 'past' ? '' : printLink()) + '</span></div>';
    const p = st.kind === 'past' ? null : mainPlace();
    const place = p ? '<p class="wk-place">' + I.pin + '<span>' + placeOpen(p) + '</span></p>' : '';
    const upd = st.kind === 'past' ? '' : updatedLine();
    const mark = st.kind === 'past' ? '' : newTag('schedule').replace(' <em', '<p class="wk-newline"><em').replace('</em>', '</em></p>') + (PREVIEW ? unpub(S().schedule_posted).replace(' <em', '<p class="wk-newline"><em').replace('</em>', '</em></p>') : '');
    if (full) return '<section class="wk-sec wk-week-sec">' + bar + mark + dayTabs(days) + dayList(st) + upd + '</section>';
    return '<section class="wk-sec wk-week-sec">' + bar + mark + place + (recs ? recordings() + pastLinks() : weekList(st)) + upd + '</section>';
  }
  // A past year keeps its schedule and packet to read and print, quietly, under its recordings.
  function pastLinks() {
    const ls = [];
    if (state.model.days.some(d => d.items.length) && !yes(S().services_only)) ls.push('<a href="../schedule/?data=' + esc(state.year) + '">Schedule</a>');
    if (packetParts().length) ls.push('<a href="../packet/?year=' + esc(state.year) + '">Information packet</a>');
    return ls.length ? '<p class="wk-pastlinks">' + ls.join('<span aria-hidden="true"> · </span>') + '</p>' : '';
  }

  // A day's heading: its weekday over its date (on a laptop, in the column beside its rows).
  // Someone listening from home, in another time zone, sees each service on their own clock under
  // the venue's time, each labelled (ET, PT), and one line names both zones.
  const viewTZ = () => state.tz || O.viewerZone();
  const venueTZ = () => (state.model && (S().timezone || state.model.tz)) || TZ;
  function theirClock(date, minutes) {
    const vz = viewTZ();
    if (!vz || minutes == null || !date) return null;
    const inst = O.wallToInstant(date, minutes, venueTZ());
    const a = O.wallNow(venueTZ(), inst), b = O.wallNow(vz, inst);
    if (a.date === b.date && a.minutes === b.minutes) return null;
    return { time: O.formatTime(b.minutes), day: a.date !== b.date ? O.fmtDate(b.date, 'weekdayShort') : '', inst };
  }
  // "ET", "PT" (or "BST" where there's no short general name).
  function zoneShort(tz, inst) {
    const get = style => { try { return (new Intl.DateTimeFormat('en-US', { timeZone: tz, timeZoneName: style }).formatToParts(inst).find(x => x.type === 'timeZoneName') || {}).value || ''; } catch (e) { return ''; } };
    const g = get('shortGeneric');
    return g && g.length <= 4 ? g : get('short');
  }
  // (no "Eastern Time · Pacific below" line; every row already says its zone.)

  // When the schedule was last changed, so a saved copy can be trusted: the latest change's time
  // (or the COA's revised date), opening the list of changes. Offline, when this phone last had the
  // year's data.
  function updatedLine() {
    const s = S(), cs = state.changes.filter(c => c.at && c.at.slice(0, 10) <= state.now.date);
    let when = '';
    if (cs.length) {
      const at = cs.map(c => c.at).sort().pop(), p = /^(\d{4}-\d{2}-\d{2})T(\d{2}):(\d{2})/.exec(at);
      if (p) when = O.fmtDate(p[1], 'md') + ', ' + O.formatTime(+p[2] * 60 + +p[3]);
    } else if (s.revised && O.parseISODate(s.revised) && s.revised <= state.now.date) when = O.fmtDate(s.revised, 'md');
    if (!when) return '';
    return '<p class="wk-updated">' + (cs.length ? '<button type="button" class="wk-linklike" data-act="changes">Updated ' + esc(when) + ' ›</button>' : 'Updated ' + esc(when)) + '</p>';
  }
  // Offline (or on one bar that gave up): a slim line at the top of the guide, with when this phone
  // last had the year's data, and Retry.
  const offline = () => navigator.onLine === false || state.failed;
  function offlineLine() {
    if (!offline()) return '';
    const t = state.synced ? new Date(state.synced) : null;
    const at = t ? O.wallNow(venueTZ(), t) : null;
    // The time saved is the venue's, labelled for a reader elsewhere ("Saved 2:10 PM ET").
    return '<p class="wk-offline" role="status"><b>Offline</b>' + (at ? '<span>Saved ' + esc((at.date !== state.now.date ? O.fmtDate(at.date, 'md') + ', ' : '') + zt(at.date, at.minutes)) + '</span>' : '') +
      '<button type="button" class="wk-linklike" data-act="retry">Retry</button></p>';
  }
  const installed = () => matchMedia('(display-mode: standalone)').matches || navigator.standalone === true;
  // Add to Home Screen: the browser's own install on Android and Chrome; on an iPhone, a picture of the
  // two steps. Gone once installed, or once dismissed on this device.
  const A2HS = 'ogc-a2hs-off';
  let installEvt = null;
  addEventListener('beforeinstallprompt', e => { e.preventDefault(); installEvt = e; if (state.model) render(true); });
  addEventListener('appinstalled', () => { try { localStorage.setItem(A2HS, '1'); } catch (e) { /* */ } if (state.model) render(true); });
  const isIOS = () => /iPhone|iPad|iPod/.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
  function homeLine() {
    let off = false;
    try { off = localStorage.getItem(A2HS) === '1'; } catch (e) { /* */ }
    // Only on a phone or tablet, online, and where the browser can install the page (or an iPhone's two
    // steps): never on a laptop or offline.
    const touch = matchMedia('(pointer: coarse)').matches;
    if (!GUIDE || installed() || off || !touch || navigator.onLine === false || (!installEvt && !isIOS())) return '';
    return '<div class="wk-a2hs"><button type="button" class="wk-btn wk-btn--line wk-btn--small" data-act="install" title="Works offline">' + I.save + 'Add to Home Screen</button>' +
      '<button type="button" class="wk-a2hs__x" data-act="install-off" aria-label="Dismiss" title="Dismiss">' + I.close + '</button></div>';
  }

  // The week, and the week before: one row of tabs, from weekViews (Services or Today first, then
  // the full schedule, Places and Help), the same look as Services · Full schedule.
  function weekBand(st, v, days) {
    const vs = weekViews(st);
    const tab = k => '<button type="button" data-view="' + k + '" data-label="' + viewLabel(k, st) + '" aria-pressed="' + (v === k) + '">' + viewLabel(k, st) + '</button>';
    // With nothing to switch to (a year entered with its services alone), the one view is just the heading.
    const tabs = vs.length > 1 ? '<h2 class="ogc-sr">This week</h2><div class="wk-tabs" role="group" aria-label="This week">' + vs.map(tab).join('') + '</div>' : '<h2 class="wk-h">' + viewLabel(vs[0], st) + '</h2>';
    const bar = '<div class="wk-bar' + (vs.length > 3 ? ' wk-bar--four' : '') + '">' + tabs + '<span class="wk-bar__tools">' + searchBtn() + printLink() + '</span></div>';
    const p = mainPlace();
    const place = v === 'services' && p ? '<p class="wk-place">' + I.pin + '<span>' + (hasPlaces(st) ? placeLink(p) : placeOpen(p)) + '</span></p>' : '';
    // On a laptop in the week, what's open now (the outreach room) is with Help, not over the Services
    // most readers follow from home.
    const open = v === 'help' && theWeek(st) ? openNow(state.model.days.find(x => x.date === state.now.date), st) : '';
    const body = v === 'full' ? dayTabs(days) + dayList(st) : v === 'places' ? placesView(st) : v === 'help' ? helpView(st, open)
      : v === 'today' ? todayView(st) : place + weekList(st);
    const draft = unpub(S().schedule_posted) ? '<p class="wk-newline">' + unpub(S().schedule_posted).trim() + '</p>' : '';
    return '<section class="wk-sec wk-week-sec wk-guide-sec">' + bar + draft + (v === 'places' ? liveNotices().length ? notices(st) : '' : '') + body + (v === 'places' || v === 'help' ? '' : updatedLine()) + '</section>';
  }

  // The way to the guide in the week (and the week before, once the schedule is up): a link to its own
  // page, not a switch. One standard label in every season ("At Conference? Open the guide"
  // was a question, and untrue a week before). In the week it's there even with no schedule posted:
  // the guide then has Help, 911 and the campus address.
  function guideDoor(st) {
    if (GUIDE || held() || !(theWeek(st) || nearWeek(st))) return '';
    return '<a class="wk-door" href="' + esc(pageUrl('guide')) + '" title="Works offline">' + I.pin + '<span><b>Conference guide</b></span>' + I.right + '</a>';
  }

  // The guide on a phone: the whole screen is the Conference. The site's header and footer step aside
  // (week.css, from the class on <html>), each tab has its own heading, the tabs sit at the bottom
  // where a thumb is, and one small link at the top leads back to the page.
  function appMode(on) {
    document.documentElement.classList.toggle('ogc-app', on);
    let m = document.querySelector('meta[name="theme-color"]');
    if (on && !m) { m = document.createElement('meta'); m.name = 'theme-color'; m.content = '#f3f2eb'; document.head.appendChild(m); }
    if (!on && m && !GUIDE) m.remove();
  }
  const TAB_ICON = { today: I.clock, full: I.cal, places: I.pin, help: I.help };
  function appView(st, v, days, fade) {
    const s = S(), h1 = t => '<h1 class="wk-apph" tabindex="-1">' + t + '</h1>';
    const conf = c => '<a class="wk-btn' + (c ? '' : ' wk-btn--line wk-btn--small') + '" href="' + esc(pageUrl('page')) + '"' + (installed() ? ' target="_blank" rel="noopener"' : '') + '>Conference page</a>';
    let top, body;
    if (!v) {
      // Outside the week, the next Conference as far as it's known. The guide opens the day its schedule
      // is posted (not a date anyone can promise), so until then it says so. The Conference page is the
      // one thing to do.
      top = h1('Guide') + '<p class="wk-here">' + esc([noYear(span(state.year)), s.venue].filter(Boolean).join(' · ')) + '</p>';
      // The page's own status words ("Closed" read as shut for now).
      body = '<p class="wk-guide-none">' + (st.kind === 'past' ? 'Past' : 'Schedule · Not posted') + '</p>' +
        '<p class="wk-guide-btn">' + conf(true) + '</p>';
    } else if (v === 'today') {
      const nn = nowNext(st);
      top = h1('<span class="ogc-sr">Today, </span>' + esc(O.fmtDate(state.now.date, 'long'))) +
        '<p class="wk-here">' + esc(O.formatTime(state.now.minutes)) + ' in ' + esc(String(s.city || s.venue).split(',')[0]) + '</p>' + notices(st) + nn;
      body = mineToday(st) + todayView(st);
    } else if (v === 'full') {
      top = h1('Schedule') + (theWeek(st) ? '' : '<p class="wk-here">' + esc(noYear(span(state.year))) + '</p>') + notices(st);
      body = dayTabs(days) + dayList(st) + (theWeek(st) ? '' : homeLine());
    } else if (v === 'places') {
      top = h1('Places') + notices(st);
      body = placesView(st);
    } else {
      // Help, then the information packet a part at a time (on the page it is a card on the shelf). In a
      // week whose schedule isn't posted, Help says so first.
      top = h1('Help') + (theWeek(st) && !schedulePosted() ? '<p class="wk-here">Schedule · Not posted</p>' : '') + notices(st);
      // Last, once the worker has everything this year needs: a quiet "Saved for offline", so a person
      // knows it's ready before the trip.
      body = helpView(st) + '<div class="wk-app__packet">' + packet(st) + '</div>' +
        (savedFor() ? '<p class="wk-saved">' + I.check + '<span>Saved for offline</span></p>' : '');
    }
    const vs = weekViews(st);
    const tabs = vs.length > 1 ? '<nav class="wk-tabbar" aria-label="Guide">' + vs.map(k => '<a href="' + esc(viewHref(k, vs)) + '" data-view="' + k + '"' + (v === k ? ' aria-current="page"' : '') + '>' +
      TAB_ICON[k] + '<span>' + viewLabel(k, st) + '</span></a>').join('') + '</nav>' : '';
    return '<div class="wk wk-app">' + offlineLine() +
      // One kicker whether or not anyone is signed in ("2026 Conference"). The way to the
      // Conference page goes while offline: it isn't kept on the phone (an error page).
      '<header class="wk-apphead"><div class="wk-wrap"><div class="wk-appbar"><p class="wk-kicker">' + esc(state.year) + ' Conference</p>' +
        '<span class="wk-appbar__end">' + (v ? searchBtn() : '') + (v && !offline() ? '<a class="wk-leave" href="' + esc(pageUrl('page')) + '"' + (installed() ? ' target="_blank" rel="noopener"' : '') + '>Conference page</a>' : '') +
        (WP.me && WP.me.email ? '<span class="ws-bar__in wk-acctslot"></span>' : '') + '</span></div>' + top + '</div></header>' +
      '<section class="wk-main wk-appmain' + (fade ? ' wk--fade' : '') + '"><div class="wk-wrap">' + body + (!v || v === 'places' || v === 'help' ? '' : updatedLine()) + '</div></section>' +
      tabs + '</div>';
  }
  // A view's own address (so it can be shared, or opened in a new tab); the first view is the bare page.
  const viewHref = (k, vs) => { const u = new URL(location.href); if (k === vs[0]) u.searchParams.delete('view'); else u.searchParams.set('view', k); u.hash = ''; return u.pathname + u.search; };

  // Today: what's open now, then the rest of the day (what is over folds away), then tomorrow. The All
  // day band is the Schedule tab's; on Today, Open now lists the places with hours.
  // Late at night (from 9 PM, or once the day's rows are over), tomorrow's first rows, through its
  // first service and breakfast: what people look up then.
  function todayView(st) {
    const days = state.model.days, i = days.findIndex(d => d.date === state.now.date), d = days[i];
    if (!d) return '';
    const tm = days[i + 1];
    const over = !d.items.filter(shows).some(it => rowState(it, d, st) !== 'past');
    let early = '';
    if (tm && (over || state.now.minutes >= 21 * 60)) {
      // Through the first service and the first meal, whichever is later (breakfast may follow the
      // morning service), at most five rows.
      const rows = tm.items.filter(it => shows(it) && startOf(it) != null), k = Math.max(rows.findIndex(isService), rows.findIndex(it => it.kind === 'meal'));
      const first = rows.slice(0, k > -1 ? Math.min(k + 1, 5) : 3);
      if (first.length) early = '<section class="wk-tmrw" aria-labelledby="wk-tmrw-t"><h3 class="wk-eyebrow" id="wk-tmrw-t">Tomorrow morning</h3>' +
        '<ol class="wk-list">' + first.map(it => row(it, tm, st)).join('') + '</ol></section>';
    }
    const more = tm && mainItems(tm, st).length ? '<p class="wk-tomorrow"><button type="button" class="wk-linklike" data-act="tomorrow" data-dayto="' + tm.key + '">' +
      'Tomorrow · ' + esc(O.fmtDate(tm.date, 'weekday')) + ' ›</button></p>' : '';
    // Saving the page for the days ahead, while there are days ahead.
    return openNow(d, st) + '<div class="wk-todaylist">' + dayList(st, d.key) + '</div>' + early + more + (tm ? homeLine() : '');
  }

  // Your own commitments today, for someone signed in: their volunteer shifts (from their own sign-ups,
  // never anyone else's), tagged in tan, each with its place. One on now says so ("Now · until
  // 11:00 AM"). (Kept on the phone for offline only if the Advisors allow it: question 6.)
  function myShifts() {
    if (!WP.me || !state.shifts) return [];
    const ids = new Set(mineOf('signups').map(m => m.id));
    return state.shifts.filter(sh => ids.has(sh.id) && sh.day.date === state.now.date && sh.end > state.now.minutes);
  }
  function mineToday(st) {
    if (!theWeek(st)) return '';
    // The shift already in the Now card isn't listed again.
    const list = myShifts().filter(sh => sh.id !== state.cardShift), m = state.now.minutes;
    if (!list.length) return '';
    const away = theirClock(state.now.date, list[0].start) ? ' has-tz' : '';
    return '<section class="wk-mine' + away + '" aria-label="Your shifts today"><h3 class="wk-eyebrow">Your shifts</h3><ul>' + list.map(sh => {
      const on = sh.start <= m;
      return '<li' + (on ? ' class="is-now"' : '') + '><span class="wk-t">' + (on ? '<em class="wk-tag">Now</em>' : esc(zt(state.now.date, sh.start))) + '</span><span><b>' + esc(sh.role) + '</b><small>' +
        esc([sh.committee, sh.place && roomText(sh.place, sh.role), 'Until ' + zt(state.now.date, sh.end)].filter(Boolean).join(' · ')) + '</small></span></li>';
    }).join('') +
      '</ul><p class="wk-mine__more"><a href="' + esc(OWN.register + '?view=mine&year=' + state.year) + '">Your sign-ups</a></p></section>';
  }

  // Open now: the Lodging Desk (its hours are rows in schedule.csv), what's open all day (the prayer
  // rooms, the outreach display), and whatever help.csv gives hours and a name to (the First Aid Room).
  // the heading says only what's true. "Open now" lists the places open at this minute, one
  // line each ("First Aid Room · Room 131 · Barnes · until 11:00 PM"); the places that open later
  // today fold under it into one line, "Opens later · 3", soonest first; with nothing open, no box (it
  // pushed the day's schedule below the fold). A room shut during a service (closed_during) is one that
  // reopens later. The outreach room keeps its place in the list (Advisors).
  function openNow(d, st) {
    if (!d) return '';
    const m = state.now.minutes, out = [];
    helpRows().filter(h => h.open && h.hours).forEach(h => {
      const hs = hoursState(h, d);
      if (!hs || (!hs.open && (hs.next == null || hs.tomorrow))) return;
      const code = h.place || (h.hours === 'desk' && hs.row && hs.row.place ? hs.row.place.code : '');
      out.push({ name: h.open, code, open: hs.open, oncall: !!hs.oncall, until: hs.until, next: hs.next });
    });
    d.allDay.filter(it => (it.audience === 'all' || it.audience === 'conference') && !isDue(it) && it.start != null && m < endOf(it, d)).forEach(it => {
      const name = it.title.replace(/\s+open$/i, ''), p = it.place;
      const shut = it.start > m ? null : closedNow(it, d);
      out.push({ name, allDay: true, code: p && !p.unknown ? p.code : '', open: it.start <= m && !shut, until: endOf(it, d), next: it.start > m ? it.start : shut ? shut.end : null, reopens: !!shut });
    });
    // What the Conference itself keeps open all day (the prayer rooms, the outreach room: the Advisors'
    // ask) comes first; the desks and First Aid follow (they're also in Help).
    const open = out.filter(o => o.open).sort((a, b) => (b.allDay ? 1 : 0) - (a.allDay ? 1 : 0)), later = out.filter(o => !o.open && o.next != null).sort((a, b) => a.next - b.next);
    if (!open.length) return '';
    const word = o => o.open ? (o.oncall ? 'On call until ' : 'until ') + clock(o.until) : (o.reopens ? 'reopens ' : 'opens ') + clock(o.next);
    // One compact line each: the name and its room, and the time at the right ("First Aid Room ·
    // Room 131 · Barnes … until 11:00 PM"), so the day's own rows stay on a phone's first screen.
    const item = o => {
      const p = o.code ? state.model.places[o.code.toUpperCase()] : null;
      const where = p ? roomText(p, o.name) : '';
      const line = o.open ? (o.oncall ? cap(word(o)) : 'Open · ' + word(o)) : 'Closed · ' + word(o);
      const inner = '<span class="wk-open__n"><b>' + esc(o.name) + '</b>' + (where ? '<span> · ' + esc(where) + '</span>' : '') + '</span><em class="' + (o.open ? 'is-open' : 'is-shut') + '">' + esc(cap(word(o))) + '</em>';
      return '<li>' + (p ? '<button type="button" class="wk-open__b" data-open="' + esc(p.code) + '" data-name="' + esc(o.name) + '" data-line="' + esc(line) + '">' + inner + '</button>' : '<div class="wk-open__b">' + inner + '</div>') + '</li>';
    };
    // Two open places show; the rest open now, then what opens later today, fold into one line.
    const first = open.slice(0, 2), more = open.slice(2);
    const sum = more.length ? more.length + ' more' + (later.length ? ' · ' + later.length + ' later' : '') : 'Opens later · ' + later.length;
    return '<section class="wk-open" aria-labelledby="wk-open-t"><h3 class="wk-eyebrow" id="wk-open-t">Open now</h3><ul>' + first.map(item).join('') + '</ul>' +
      (more.length || later.length ? '<details class="wk-open__later" data-k="open-later"><summary><span>' + esc(sum) + '</span>' + I.down + '</summary>' +
        (more.length ? '<ul>' + more.map(item).join('') + '</ul>' : '') +
        (later.length ? (more.length ? '<p class="wk-open__k">Opens later</p>' : '') + '<ul>' + later.map(item).join('') + '</ul>' : '') + '</details>' : '') +
      '</section>';
  }
  // A room in one format everywhere: "Room 131 · Barnes", "Piazza Terrace · Barnes", "Chapel Loft"
  // ("Barnes Room 131", "Piazza Terrace (Barnes)" and "Henry West Room 143 (Barnes)" side
  // by side). The building is its short name, as people say it.
  function roomText(p, name) {
    let n = roomOf(p, name || ''), bldg = '';
    const paren = /^(.*?)\s*\(([^)]+)\)\s*$/.exec(n);
    if (paren) { n = paren[1]; bldg = paren[2]; }
    const r = /^(.*?)\s*\b(Rooms? [\w–-]+(?: [A-Z](?:–[A-Z])?)?)$/.exec(n);
    if (r) return r[2] + ' · ' + (bldg || r[1].trim() || String(p.building || '').split(' ')[0]);
    // A named room with its number in brackets, asked for without a title ("First Aid Room (Barnes
    // Room 131)" → "First Aid Room · Room 131 · Barnes").
    const rb = bldg && /^(.*?)\s*\b(Rooms? [\w–-]+(?: [A-Z](?:–[A-Z])?)?)$/.exec(bldg);
    if (rb) return n + ' · ' + rb[2] + (rb[1].trim() ? ' · ' + rb[1].trim() : '');
    return bldg && !/room/i.test(bldg) ? n + ' · ' + bldg : n;
  }
  // The room's own name beside what's in it: "First Aid Room (Barnes Room 131)" → "Barnes Room 131";
  // "Chapel Loft (prayer rooms)" → "Chapel Loft". Never the building (the prayer rooms read
  // "Chapel Auditorium", which sent people into the service).
  function roomOf(p, name) {
    const m = /^(.*?)\s*\(([^)]+)\)\s*$/.exec(p.name), n = name.toLowerCase();
    // Asked without a title (a place's own sheet, search): the whole name, written the one way.
    if (!m || !n) return p.name;
    const a = m[1].toLowerCase(), b = m[2].toLowerCase();
    if (a.indexOf(n) === 0 || n.indexOf(a) === 0) return m[2];
    if (b.indexOf(n.split(/\s+/)[0]) > -1) return m[1];
    return p.name;
  }
  // A row marked closed_during = services is shut while a service is on today: → the service, or null.
  function closedNow(it, d) {
    if (it.closedDuring !== 'services') return null;
    const m = state.now.minutes;
    const svc = d.items.filter(x => isService(x) && startOf(x) != null && startOf(x) <= m && m < endOf(x, d));
    return svc.length ? { end: Math.max.apply(null, svc.map(x => endOf(x, d))) } : null;
  }
  // The guide's sheet for a building or a room (Andrew's guide, Oct 13): Directions first; then what's
  // there for families and access (places.csv features, with the room); what's still on there today,
  // each opening its own sheet; a building's rooms, each opening its own; the small map last.
  // Just the room's number, inside its building's sheet ("Nursery · Room 114 · Chapel" → "Room 114").
  const roomOnly = r => { const ps = roomText(r, '').split(' · '); return ps.length >= 3 ? ps.slice(1, -1).join(' · ') : ps.slice(1).join(' · ') || ps[0]; };
  function placeSheet(p, st, name, line, phone) {
    const key = placeKey(p), grp = placeGroups().find(g => g.key === key), isB = !!grp && grp.main === p;
    const d = state.model.days.find(x => x.date === state.now.date);
    const here = !d ? [] : d.items.concat(d.allDay || []).filter(it => it.place && !it.place.unknown && (isB ? placeKey(it.place) === key : it.place.code.toUpperCase() === p.code.toUpperCase()) && rowState(it, d, st) !== 'past' && !isDue(it))
      .sort((a, b) => (startOf(a) == null ? 1e9 : startOf(a)) - (startOf(b) == null ? 1e9 : startOf(b)));
    const feats = (isB ? [{ p, fs: p.features || [] }].concat(grp.rooms.map(r => ({ p: r, fs: r.features || [] }))) : [{ p, fs: (p.features || []).filter(f => String(p.name).toLowerCase().indexOf(String(O.FEATURES[f] || f).toLowerCase()) < 0) }])
      .reduce((a, x) => a.concat(x.fs.map(f => ({ f, room: x.p === p ? null : x.p }))), []);
    const icon = f => O.map && O.map.featureIcon ? O.map.featureIcon(f) : '';
    const featured = feats.filter(x => x.room).map(x => x.room.code);
    const rooms = isB ? grp.rooms.filter(r => featured.indexOf(r.code) < 0) : [];
    const href = (theWeek(st) || nearWeek(st)) ? dirsUrl(p) : '';
    const title = name || (isB ? p.name : roomText(p, ''));
    return '<div class="wk-sheet__in">' + grabber() + '<button type="button" class="wk-sheet__x" data-close aria-label="Close">' + I.close + '</button>' +
      (isB ? '' : '<p class="wk-kicker">' + esc(grp && grp.main ? grp.main.name : p.building || '') + '</p>') +
      '<h2 class="wk-sheet__h" id="wk-sheet-t">' + esc(title) + '</h2>' +
      (!isB && roomOnly(p) && roomOnly(p).toLowerCase() !== String(title).toLowerCase() ? '<p class="wk-sheet__when">' + esc(roomOnly(p)) + '</p>' : '') +
      (line ? '<p class="wk-sheet__live"><em class="' + (/^Closed/.test(line) ? 'is-over' : 'is-on') + '">' + esc(line) + '</em></p>' : '') +
      (href || phone ? '<div class="wk-sheet__acts">' + (href ? '<a class="wk-btn wk-btn--big" href="' + esc(href) + '"' + DIRS_ATTRS + '>' + I.dirs + 'Directions</a>' : '') +
        (phone ? '<a class="wk-btn wk-btn--line wk-btn--big" href="' + O.telHref(phone) + '">' + I.phone + 'Call<span class="wk-btn__num">' + esc(phone) + '</span></a>' : '') + '</div>' : '') +
      (feats.length ? '<ul class="pm-feats wk-sheet__feats" aria-label="For families and access">' + feats.map(x => '<li>' + (x.room ? '<button type="button" class="pm-feat" data-open="' + esc(x.room.code) + '">' : '<div class="pm-feat">') + icon(x.f) +
        '<span><b>' + esc(O.FEATURES[x.f] || x.f) + '</b>' + (x.room ? '<small>' + esc(roomOnly(x.room)) + '</small>' : '') + '</span>' + (x.room ? '</button>' : '</div>') + '</li>').join('') + '</ul>' : '') +
      (here.length ? '<section class="wk-sheet__also"><h3 class="wk-eyebrow">Still today</h3><ul>' + here.map(it => {
        const on = rowState(it, d, st) === 'now', t = on ? 'Now' : startOf(it) != null ? zt(d.date, startOf(it)) : it.startText;
        return '<li><span class="wk-t wk-t--words' + (on ? ' is-on' : '') + '">' + esc(t) + '</span><span><button type="button" class="wk-linklike" data-ev="' + esc(it.id) + '">' + esc(it.title.replace(/\s+open$/i, '')) + '</button>' +
          (isB && it.place.code.toUpperCase() !== p.code.toUpperCase() ? '<small>' + esc(roomText(it.place, it.title)) + '</small>' : '') + '</span></li>';
      }).join('') + '</ul></section>' : '') +
      (rooms.length ? '<section class="wk-sheet__also"><h3 class="wk-eyebrow">Rooms</h3><ul class="wk-sheet__rooms">' + rooms.map(r => '<li><button type="button" class="wk-roomrow" data-open="' + esc(r.code) + '"><span>' + esc(roomText(r, '')) + '</span>' + (yes(r.signed) ? '<code>' + esc(r.code) + '</code>' : '') + I.right + '</button></li>').join('') + '</ul></section>' : '') +
      placeBlock(p, st, 'maponly', title) + '</div>';
  }
  // A place's own sheet, from Open now or Help: where it is, its hours today, Directions.
  function openPlaceSheet(code, name, line, phone) {
    const p = state.model.places[String(code).toUpperCase()];
    if (!p) return;
    sheetOpener = document.activeElement;
    const st = status();
    sheet.innerHTML = GUIDE ? placeSheet(p, st, name, line, phone) : '<div class="wk-sheet__in">' + grabber() + '<button type="button" class="wk-sheet__x" data-close aria-label="Close">' + I.close + '</button>' +
      '<h2 class="wk-sheet__h" id="wk-sheet-t">' + esc(name || p.name) + '</h2>' + (line ? '<p class="wk-sheet__when">' + esc(line) + '</p>' : '') +
      placeBlock(p, st, '', name || p.name) + (phone ? '<p class="wk-sheet__btns"><a class="wk-btn wk-btn--line" href="' + O.telHref(phone) + '">' + I.phone + 'Call</a></p><p class="wk-hnum2">' + esc(phone) + '</p>' : '') + '</div>';
    sheet.dataset.ev = 'place:' + p.code;
    openSheet();
    if (O.map && !state.campus) campusSoon().then(() => { if (sheet.open && state.campus && sheet.dataset.ev === 'place:' + p.code) { const o = sheetOpener; openPlaceSheet(code, name, line, phone); sheetOpener = o; } });
  }

  /* ------------------------------------------------ an event's sheet */

  // Once the schedule is posted, a row opens its sheet: when (and whether it's on now), where, with
  // Directions in the week, its note, its packet part, its menu, its recordings, Add to calendar, Share,
  // and what else is on in that building that day.
  const evName = (it, st) => sheets(st) && !it.cancelled ? '<button type="button" class="wk-evbtn" data-ev="' + esc(it.id) + '">' + esc(it.title) + '</button>' : esc(it.title);
  const sheet = document.createElement('dialog');
  sheet.className = 'ogc wk-sheet';
  sheet.setAttribute('aria-labelledby', 'wk-sheet-t');
  document.body.appendChild(sheet);
  let sheetOpener = null;
  const grabber = () => '<span class="wk-sheet__grab" aria-hidden="true"></span>';
  // The one sheet (Oct 13, after Andrew's guide): every item opens here, a service, a meal, a place, a
  // Help line, care nearby, a search. On a phone it slides up from the bottom under its handle; a long
  // one opens at half height and grows to full when it's scrolled or dragged up; it closes with a swipe
  // down, a tap outside, Esc, its × or the phone's Back. Under reduced motion it doesn't slide. On a
  // laptop it's a centred card: one column to read, and the guide's Places panel keeps its own side.
  // The focus goes to the sheet's heading, so the × shows its ring only when someone tabs to it
  // (the ring sat on the × after every tap). Search keeps its field's focus.
  const reduceQ = matchMedia('(prefers-reduced-motion: reduce)');
  let sheetPushed = false, popClean = false, dismissing = false;
  const snapTo = s => { sheet.dataset.snap = s; };
  const longSheet = () => { const i = sheet.querySelector('.wk-sheet__in'); return !!i && i.scrollHeight > innerHeight * .62; };
  function openSheet() {
    tidy(sheet);
    // Search is a full screen (the field at the top, results under it), so a phone's keyboard never
    // covers them; every other sheet comes up from the bottom.
    sheet.classList.toggle('wk-sheet--full', !!sheet.querySelector('.wk-search'));
    const fresh = !sheet.open;
    if (fresh) {
      sheet.style.transform = '';
      sheet.showModal();
      // The phone's Back closes it: one history entry while it's open.
      try { history.pushState(Object.assign({}, history.state || {}, { wkSheet: 1 }), ''); sheetPushed = true; } catch (e) { sheetPushed = false; }
      sheet.classList.remove('is-in'); void sheet.offsetWidth; sheet.classList.add('is-in');
    }
    sheet.scrollTop = 0;
    snapTo(phoneQ.matches && !sheet.classList.contains('wk-sheet--full') && longSheet() ? 'half' : 'fit');
    const h = sheet.querySelector('.wk-sheet__h');
    if (h && !sheet.querySelector('[data-q]')) { h.setAttribute('tabindex', '-1'); h.focus({ preventScroll: true }); }
  }
  // Put away by the person (×, a tap outside, a swipe, Esc): it slides down, and its history entry goes.
  function closeSheet() {
    if (!sheet.open) return;
    dismissing = true;
    if (!phoneQ.matches || reduceQ.matches) { sheet.close(); return; }
    sheet.style.transform = 'translateY(100%)';
    setTimeout(() => { if (sheet.open) sheet.close(); sheet.style.transform = ''; }, 180);
  }
  sheet.addEventListener('cancel', e => { e.preventDefault(); closeSheet(); });
  const cleanEvent = () => { const u = new URL(location.href); if (u.searchParams.has('event')) { u.searchParams.delete('event'); history.replaceState(history.state, '', u); } };
  // Closed: the focus goes back to the row (or button) that opened it.
  sheet.addEventListener('close', () => {
    const o = sheetOpener; sheetOpener = null;
    if (o && document.contains(o)) o.focus({ preventScroll: true });
    else if (o && o.dataset && o.dataset.ev) { const t = root.querySelector('[data-ev="' + o.dataset.ev + '"]'); if (t) t.focus({ preventScroll: true }); }
    sheet.classList.remove('is-in');
    const put = dismissing; dismissing = false;
    if (sheetPushed) {
      sheetPushed = false;
      const top = history.state && history.state.wkSheet;
      // Put away: Back over its own entry. Closed to go somewhere (a place, a view): its entry stays, unmarked.
      if (top && put) { popClean = true; history.back(); return; }
      if (top) { const s = Object.assign({}, history.state); delete s.wkSheet; history.replaceState(s, ''); }
    }
    cleanEvent();
  });
  // The phone's Back with a sheet open closes the sheet and nothing else (the view stays drawn).
  addEventListener('popstate', e => {
    if (popClean) { popClean = false; e.stopImmediatePropagation(); cleanEvent(); return; }
    if (sheetPushed && sheet.open) { sheetPushed = false; e.stopImmediatePropagation(); sheet.close(); }
  });
  // Half height grows to full as soon as it's scrolled.
  sheet.addEventListener('scroll', () => { if (sheet.dataset.snap === 'half' && sheet.scrollTop > 4) snapTo('full'); }, { passive: true });
  // From its top: a drag up grows a half sheet; a drag down shrinks a full one, else puts it away.
  let drag = null;
  sheet.addEventListener('touchstart', e => { drag = sheet.scrollTop <= 0 && e.touches.length === 1 ? { y: e.touches[0].clientY, dy: 0 } : null; }, { passive: true });
  sheet.addEventListener('touchmove', e => {
    if (!drag) return;
    drag.dy = e.touches[0].clientY - drag.y;
    if (drag.dy > 0 && phoneQ.matches) sheet.style.transform = 'translateY(' + drag.dy + 'px)';
  }, { passive: true });
  sheet.addEventListener('touchend', () => {
    if (!drag) return;
    const dy = drag.dy; drag = null;
    sheet.style.transform = '';
    if (!phoneQ.matches) return;
    if (dy < -30 && sheet.dataset.snap === 'half') snapTo('full');
    else if (dy > 90 && sheet.dataset.snap === 'full' && longSheet() && !sheet.classList.contains('wk-sheet--full')) snapTo('half');
    else if (dy > 90) closeSheet();
  }, { passive: true });

  function findEvent(id) {
    let it = null, d = null;
    state.model.days.forEach(x => x.items.concat(x.nightly, x.allDay).forEach(y => { if (y.id === id) { it = y; d = x; } }));
    return it ? { it, d } : null;
  }
  function openEvent(id, opener) {
    const f = findEvent(id);
    if (!f) return false;
    sheetOpener = opener || document.activeElement;
    sheet.innerHTML = eventSheet(f.it, f.d, status());
    sheet.dataset.ev = id;
    openSheet();
    // The map area (the Advisors' ask 4): before the week too, the campus is read the first
    // time a sheet opens, and the sheet gets its small map with the place marked.
    if (O.map && !state.campus) campusSoon().then(() => { if (sheet.open && state.campus && sheet.dataset.ev === id) { sheet.innerHTML = eventSheet(f.it, f.d, status()); tidy(sheet); } });
    return true;
  }
  // The room, and the way there: Directions opens Google Maps' walking directions to its building's
  // entrance (Oct 13, Michael: "for actual directions, let's rely on GPS and everything from Google
  // Maps"), from the guide and the Conference page alike; a phone hands it to its Maps app.
  // mode: 'quiet' (Directions as an outline, no map: the call-in line is the sheet's one action) or
  // 'bare' (where it is, nothing more: a reader in another time zone).
  function placeBlock(p, st, mode, title) {
    const grp = placeGroups().find(x => x.key === placeKey(p));
    // Under the room, its building's full name once ("Phillippe Performing Arts Center" under
    // "Room 150 · PPAC"), so a short name a newcomer wouldn't know is spelled out here.
    const full = p.building && p.building !== p.name ? p.building : grp && grp.main.name !== p.name ? grp.main.name : '';
    const code = yes(p.signed) ? '<code title="On the campus signs">' + esc(p.code) + '</code>' : '';
    let btns = '', dirs = null;
    const dcls = mode === 'quiet' ? 'wk-btn wk-btn--line' : 'wk-btn';
    // ('nodirs': the guide's sheet whose Directions is already its first button; the small map stays.)
    // ('maponly': the small map alone, under a place's own sheet that has already said where and Directions.)
    if ((theWeek(st) || nearWeek(st)) && mode !== 'bare' && mode !== 'nodirs' && mode !== 'maponly') {
      // (A place the map can't find, or a field not pinned yet, gets no Directions.)
      const href = dirsUrl(p);
      if (href) { dirs = { href }; btns += '<a class="' + dcls + '" href="' + esc(href) + '"' + DIRS_ATTRS + '>' + I.dirs + 'Directions</a>'; }
    }
    // The map area: the place on a small campus map, which itself opens the place (no
    // separate "Building" link), with the sheet's one Directions button under it.
    // (What the map is missing is told to members only.)
    const member = !!(WP.webmaster || (WP.member || []).map(String).indexOf(String(state.year)) > -1);
    const mini = state.campus && O.map.mini && (!mode || mode === 'nodirs' || mode === 'maponly') ? O.map.mini(state.campus, p, state.model.places, Object.assign({ member }, hasPlaces(st) ? { href: '?view=places#pl-' + placeKey(p), attrs: ' data-place="' + esc(p.code) + '"', hrefTitle: 'Open the map' } : {}, dirs ? { dirs, dirsAttrs: DIRS_TITLE } : {})) : '';
    // (The map area, polish 3: a place sheet titled with the place itself doesn't say its name again under it.)
    const again = title && String(title).trim().toLowerCase() === String(roomText(p, '')).trim().toLowerCase() && !full;
    return (again || mode === 'maponly' ? '' : '<div class="wk-sheet__where">' + I.pin + '<div><b>' + esc(roomText(p, '')) + '</b>' + (full && full !== roomText(p, '') ? '<small>' + esc(full) + '</small>' : '') + '</div>' + code + '</div>') +
      (btns && !mini ? '<p class="wk-sheet__btns">' + btns + '</p>' : '') + mini;
  }
  // Main dishes first, desserts last, by the station and never by one dish's name ("Corn
  // Pudding" sent the Savory station, the pork loin with it, after Bliss). A menu with a course column
  // (main · side · dessert, from the caterer's import) goes in that order; otherwise a dessert station
  // (Bliss, Desserts, Sweets) goes last and the rest keep the caterer's own order.
  const DESSERT_STATION = /^(bliss|desserts?|sweets?|treats?)$/i;
  const COURSE = { main: 0, entree: 0, side: 1, sides: 1, dessert: 2, desserts: 2 };
  const courseOf = x => x.course && COURSE[x.course] != null ? COURSE[x.course] : DESSERT_STATION.test(String(x.station || '').trim()) ? 2 : 0;
  const menuOrder = menu => menu.map((x, i) => [x, i]).sort((a, b) => courseOf(a[0]) - courseOf(b[0]) || a[1] - b[1]).map(p => p[0]);

  // A Young Folks tournament's sign-ups (tournaments.csv), by its `schedule_title`, the row's own title
  // as typed (case aside): open from `opens` until `closes_day` at `closes_time` (the soonest, for two on
  // one row). When the Young Folks run their own (tournaments_online = no), they say so instead.
  function tournamentOf(it) {
    if (it.audience !== 'youngfolks' || !state.tournaments) return null;
    const ts = state.tournaments.filter(t => String(t.schedule_title).trim().toLowerCase() === String(it.title).trim().toLowerCase());
    if (!ts.length) return null;
    if (String(S().tournaments_online || '').toLowerCase() === 'no') return { open: false, line: 'With the Young Folks committee' };
    const closes = ts.map(t => {
      const day = state.model.days.find(x => x.key === O.slug(t.closes_day) || O.slug(x.name) === O.slug(t.closes_day)), m = O.parseTime(t.closes_time);
      return day && m != null ? { date: day.date, m } : null;
    }).filter(Boolean).sort((a, b) => a.date < b.date ? -1 : a.date > b.date ? 1 : a.m - b.m)[0];
    const opens = ts.map(t => t.opens).filter(x => O.parseISODate(x)).sort()[0] || '', n = state.now;
    if (opens && n.date < opens) return { open: false, line: 'Sign-ups open ' + O.fmtDate(opens, 'md') };
    if (closes && (n.date > closes.date || (n.date === closes.date && n.minutes >= closes.m))) return { open: false, line: 'Sign-ups closed' };
    return { open: true, line: closes ? 'Sign-ups close ' + (closes.date === n.date ? 'today' : O.fmtDate(closes.date, 'weekday')) + ' at ' + zt(closes.date, closes.m) : '', url: OWN.tournaments + '?year=' + state.year };
  }

  function eventSheet(it, d, st) {
    // The one way ranges are written ("10:00 AM–12:00 PM", never split at the dash).
    const when = it.start != null ? ztRange(d.date, it.start, it.end) : it.startText;
    const aud = it.audience === 'preteens' ? 'Preteens' : it.audience === 'youngfolks' ? 'Young Folks' : '';
    const p = it.place && !it.place.unknown ? it.place : null;
    const g = packetParts().length && postedBy(S().packet_posted) ? (it.guides || []).map(id => state.model.guides[id]).filter(x => x && x.paras.length)[0] : null;
    const same = p ? d.items.filter(x => x !== it && x.place && placeKey(x.place) === placeKey(p) && rowState(x, d, st) !== 'past') : [];
    const recs = plays(it), today = d.date === state.now.date;
    // Now, soon or over, on its own day.
    let live = '', rs = '';
    const m = state.now.minutes;
    if (it.start != null && theWeek(st)) {
      rs = rowState(it, d, st);
      live = rs === 'now' ? 'Now · until ' + zt(d.date, endOf(it, d)) : rs === 'past' ? 'Over' : today && it.start - m <= 120 ? 'Starts in ' + (it.start - m >= 60 ? Math.floor((it.start - m) / 60) + ' hr ' : '') + ((it.start - m) % 60 ? (it.start - m) % 60 + ' min' : '') : '';
    }
    const theirs = it.start != null ? theirClock(d.date, it.start) : null;
    const chg = changeText(changeOf(it));
    const ics = (WP.base || '/annual-conference/') + state.year + '.ics?event=' + encodeURIComponent(it.id);
    const ci = callIn();
    // On the Conference page, a row on the call-in line that's on now (or within the hour) has Call in
    // as its one filled button; the room goes quiet, and for a reader in another time zone it's only
    // named (Directions and a campus map were offered to someone at home). The guide keeps
    // Directions first.
    const callNow = !GUIDE && it.callIn && ci && (rs === 'now' || (rs === 'upcoming' && today && it.start - m <= 60));
    // Once it's over, its recording is the one thing to do: a filled Play, and no Directions or Add to
    // calendar.
    const over = rs === 'past' || (!theWeek(st) && st.kind === 'past');
    const playBtn = over && recs.length && recs[0].audio ? '<p class="wk-sheet__btns"><button type="button" class="wk-btn" data-play="' + esc(recId(recs[0])) + '">' + I.play + 'Play</button></p>' : '';
    const callBtn = callNow ? '<p class="wk-sheet__btns"><a class="wk-btn wk-btn--call" href="' + O.telHref(ci.num, ci.pin) + '" title="The phone dials the PIN by itself">' + I.phone + 'Call in</a></p>' +
      '<p class="wk-sheet__pin">' + esc(ci.num) + (ci.pin ? ' · PIN ' + esc(pinText(ci.pin)) : '') + '</p>' : '';
    // In the guide (Andrew's guide, Oct 13) the sheet's big buttons come first, one under the other:
    // Directions (filled), then for a row on the call-in line Listen by phone with its number on it, and
    // a Young Folks tournament's Sign up while its sign-ups are open.
    const dirHref = GUIDE && p && !over && (theWeek(st) || nearWeek(st)) ? dirsUrl(p) : '';
    const listen = GUIDE && it.callIn && ci && !over;
    const tn = GUIDE && !over ? tournamentOf(it) : null;
    const acts = dirHref || listen || (tn && tn.open) ? '<div class="wk-sheet__acts">' +
      (dirHref ? '<a class="wk-btn wk-btn--big" href="' + esc(dirHref) + '"' + DIRS_ATTRS + '>' + I.dirs + 'Directions</a>' : '') +
      (listen ? '<a class="wk-btn wk-btn--line wk-btn--big" href="' + O.telHref(ci.num, ci.pin) + '" title="The phone dials the PIN by itself">' + I.phone + 'Listen by phone<span class="wk-btn__num">' + esc(ci.num) + '</span></a>' +
        (ci.pin ? '<small class="wk-sheet__pinline">PIN ' + esc(pinText(ci.pin)) + '</small>' : '') : '') +
      (tn && tn.open ? '<a class="wk-btn wk-btn--line wk-btn--big" href="' + esc(tn.url) + '">Sign up</a>' : '') + '</div>' : '';
    // The menu once the caterer's is posted (it goes up with the packet).
    const menu = it.menu && postedBy(S().packet_posted) ? it.menu : null;
    return '<div class="wk-sheet__in">' + grabber() + '<button type="button" class="wk-sheet__x" data-close aria-label="Close">' + I.close + '</button>' +
      '<p class="wk-kicker">' + esc(O.fmtDate(d.date, 'long')) + '</p>' +
      '<h2 class="wk-sheet__h" id="wk-sheet-t">' + esc(it.title) + '</h2>' +
      '<p class="wk-sheet__when">' + esc([theirs && it.callIn && !GUIDE ? rangeBoth(d.date, it.start, it.end) : theirs ? ztRange(d.date, it.start, it.end) : when, aud].filter(Boolean).join(' · ')) + '</p>' +
      (live || chg ? '<p class="wk-sheet__live">' + (live ? '<em class="' + (live === 'Over' ? 'is-over' : 'is-on') + '">' + esc(live) + '</em>' : '') + (chg ? '<em class="wk-chg">' + esc(chg) + '</em>' : '') + '</p>' : '') +
      callBtn + playBtn +
      // The guide: the buttons, the tournament's sign-up line, the note, the recordings, the menu, then
      // where it is on the small map (its Directions already the first button).
      (GUIDE ? acts + (tn && tn.line ? '<p class="wk-sheet__tn">' + esc(tn.line) + '</p>' : '') +
        (it.note ? '<p class="wk-sheet__note">' + esc(it.note) + '</p>' : '') +
        (recs.length ? '<div class="wk-sheet__recs">' + recs.map(a => rec(a, '')).join('') + '</div>' : '') +
        (menu ? '<section class="wk-sheet__menu"><h3 class="wk-eyebrow">Menu</h3><dl>' + menuOrder(menu).map(x => '<div>' + (x.station ? '<dt>' + esc(x.station) + '</dt>' : '') + '<dd>' + x.items.map(esc).join(' · ') + '</dd></div>').join('') + '</dl></section>' : '') +
        (p ? placeBlock(p, st, over ? 'bare' : dirHref ? 'nodirs' : '') : '') :
      (p ? placeBlock(p, st, over ? 'bare' : callNow ? (theirs ? 'bare' : 'quiet') : '') : '') +
      (it.callIn && ci && !onSite(st) && !callNow ? '<p class="wk-sheet__call">' + I.phone + '<span>Call-in line · <a href="' + O.telHref(ci.num, ci.pin) + '">' + esc(ci.num) + '</a>' + (ci.pin ? ' · PIN ' + esc(pinText(ci.pin)) : '') + '</span></p>' : '') +
      (it.note ? '<p class="wk-sheet__note">' + esc(it.note) + '</p>' : '') +
      // A Young Folks tournament (or its sign-up row) leads to the sign-up page itself.
      (it.audience === 'youngfolks' && (it.kind === 'signup' || /tournament/i.test(it.title)) && OWN.tournaments ? '<p class="wk-sheet__btns"><a class="wk-btn" href="' + esc(OWN.tournaments + '?year=' + state.year) + '">Tournament sign-ups</a></p>' : '') +
      (recs.length ? '<div class="wk-sheet__recs">' + recs.map(a => rec(a, '')).join('') + '</div>' : '') +
      (menu ? '<section class="wk-sheet__menu"><h3 class="wk-eyebrow">Menu</h3><dl>' + menuOrder(menu).map(x => '<div>' + (x.station ? '<dt>' + esc(x.station) + '</dt>' : '') + '<dd>' + x.items.map(esc).join(' · ') + '</dd></div>').join('') + '</dl></section>' : '')) +
      (g ? '<section class="wk-sheet__part"><h3>' + esc(g.title) + '</h3>' + rich(g.paras) + '</section>' : '') +
      // What else is on in the same building that day, each with its own room when it isn't this one
      // ("Also in Chapel Auditorium" listed rows in Chapel Room 132).
      (same.length ? '<section class="wk-sheet__also"><h3 class="wk-eyebrow">Also in this building' + (today ? ' today' : ' · ' + esc(O.fmtDate(d.date, 'weekday'))) + '</h3><ul>' +
        same.map(x => '<li><span class="wk-t wk-t--words">' + esc(x.start != null ? zt(d.date, x.start) : x.startText) + '</span><span><button type="button" class="wk-linklike" data-ev="' + esc(x.id) + '">' + esc(x.title) + '</button>' +
          (x.place.name !== p.name ? '<small>' + esc(roomText(x.place, x.title)) + '</small>' : '') + '</span></li>').join('') + '</ul></section>' : '') +
      '<p class="wk-sheet__foot">' + (it.start != null && !over && d.date >= state.now.date ? '<a class="wk-linklike" href="' + esc(ics) + '">' + I.cal + 'Add to calendar</a>' : '') +
        '<button type="button" class="wk-linklike" data-share="' + esc(it.id) + '">' + I.share + 'Share</button></p>' +
      memberTools(it) +
      '</div>';
  }
  sheet.addEventListener('click', e => {
    if (e.target === sheet || e.target.closest('[data-close]')) { closeSheet(); return; }
    const b = e.target.closest('[data-play]');
    if (b) { play(b.dataset.play); return; }
    const ev = e.target.closest('[data-ev]');
    if (ev) { const o = sheetOpener; openEvent(ev.dataset.ev, o); return; }
    // A room in a building's sheet (or its feature): that room's own sheet, in the same sheet.
    const op = e.target.closest('[data-open]');
    if (op) { const o = sheetOpener; openPlaceSheet(op.dataset.open); sheetOpener = o; return; }
    const sh = e.target.closest('[data-share]');
    if (sh) { shareEvent(sh.dataset.share, sh); return; }
    const pl = e.target.closest('[data-place]');
    if (pl) { e.preventDefault(); sheetOpener = null; sheet.close(); openPlace(pl.dataset.place); return; }
    const hit = e.target.closest('[data-hit]');
    if (hit) { sheetOpener = null; sheet.close(); goHit(hit.dataset.hit); }
  });
  // Share: the phone's own share sheet, else the link copied.
  function shareEvent(id, btn) {
    const f = findEvent(id);
    const u = new URL(location.origin + (WP.base || '/annual-conference/') + (GUIDE ? 'guide/' : ''));
    u.searchParams.set('year', state.year); u.searchParams.set('event', id);
    const title = f ? f.it.title + ' · ' + O.fmtDate(f.d.date, 'long') : 'Annual Conference ' + state.year;
    if (navigator.share) { navigator.share({ title, url: u.href }).catch(() => {}); return; }
    copyText(u.href, btn);
  }
  function copyText(text, btn) {
    const done = () => { if (btn) { const t = btn.innerHTML; btn.textContent = 'Copied'; setTimeout(() => { btn.innerHTML = t; }, 1600); } say.textContent = 'Copied'; };
    if (navigator.clipboard) navigator.clipboard.writeText(text).then(done, () => {}); else done();
  }
  // For a signed-in member of the year: the tools to change the event live in the back end, and the
  // sheet links straight to the row. The address is the back end's (OGC_WP.editRow, from the server's
  // ogc_edit_row_url filter: it was built here, and the back end is moving).
  function memberTools(it) {
    if (!(WP.member || []).some(y => String(y) === state.year) || !it.row || !WP.editRow) return '';
    const url = String(WP.editRow).replace('{year}', encodeURIComponent(state.year)).replace('{row}', encodeURIComponent(it.row));
    return '<p class="wk-sheet__member"><a href="' + esc(url) + '">Edit</a></p>';
  }

  // The schedule's changes since it was posted, newest first.
  function openChanges() {
    sheetOpener = document.activeElement;
    const cs = state.changes.filter(c => c.at && c.at.slice(0, 10) <= state.now.date).slice().sort((a, b) => a.at < b.at ? 1 : -1);
    sheet.innerHTML = '<div class="wk-sheet__in">' + grabber() + '<button type="button" class="wk-sheet__x" data-close aria-label="Close">' + I.close + '</button>' +
      '<h2 class="wk-sheet__h" id="wk-sheet-t">Changes</h2><ul class="wk-changes">' + cs.map(c => {
        const t = O.parseTime(c.now), what = c.what === 'cancelled' ? 'Cancelled' : c.what === 'added' ? 'Added' + (t != null ? ' · ' + O.formatTime(t) : '') : c.what === 'moved' ? 'Now ' + (t != null ? O.formatTime(t) : c.now) + ' · ' + changeText(c).replace('Moved · ', '') : changeText(c);
        const p = /^(\d{4}-\d{2}-\d{2})T(\d{2}):(\d{2})/.exec(c.at);
        return '<li><b>' + esc(c.title) + '</b><span>' + esc([c.day, what].filter(Boolean).join(' · ')) + '</span>' + (p ? '<small>' + esc(O.fmtDate(p[1], 'md') + ', ' + O.formatTime(+p[2] * 60 + +p[3])) + '</small>' : '') + '</li>';
      }).join('') + '</ul></div>';
    openSheet();
  }

  /* ------------------------------------------------ places */

  // The campus by building: a place's code before the slash is its building (B, B/PT, B/JLB are the
  // Barnes Student Center and two of its rooms), in the order places.csv lists them.
  const placeKey = p => String(p.code).split('/')[0].toUpperCase();
  function placeGroups() {
    const groups = [], by = {};
    Object.keys(state.model.places).forEach(k => {
      const p = state.model.places[k], key = placeKey(p);
      if (!by[key]) groups.push(by[key] = { key, main: null, rooms: [] });
      if (p.code.toUpperCase() === key) by[key].main = p; else by[key].rooms.push(p);
    });
    return groups.map(g => Object.assign(g, { main: g.main || g.rooms.shift() })).filter(g => g.main);
  }
  // A place in a row opens it on the campus map (Places), the room itself when it's one (B/131).
  const placeLink = (p, text) => '<a class="wk-placelink" href="?view=places#pl-' + esc(placeKey(p)) + '" data-place="' + esc(p.code) + '">' + esc(text || p.name) + '</a>';
  // Before the week (no Places yet), a place opens its own sheet with the small campus map (the map
  // area: the Advisors' ask 4, "tap a building, see it on the map", from the Conference page).
  const placeOpen = (p, text) => O.map ? '<button type="button" class="wk-placelink" data-open="' + esc(p.code) + '">' + esc(text || p.name) + '</button>' : esc(text || p.name);
  // A room named for its building ("Piazza Terrace (Barnes)") drops the building in its own card.
  const inBuilding = (room, b) => room.name.replace(/\s*\(([^)]+)\)$/, (m, w) => b.toLowerCase().indexOf(w.split(' ')[0].toLowerCase()) > -1 ? '' : m);

  // Places (the map area, Oct 10): the campus map is its own little app (shared/ogc-map-app.js): on a
  // phone's guide the map fills the screen with a sheet over it; on a laptop the panel sits beside it
  // and the buildings below. Without a campus map, the buildings as cards.
  function placesView(st) {
    // The guide: each one a line (its kind, its name, how far), opening its own sheet with Call and
    // Directions (Andrew's guide, Oct 13); fewer buttons in the list.
    // nearby.csv comes grouped by kind, so a row names its kind only when it starts a group ("Pharmacy"
    // once over CVS, Meijer, Walgreens); the rest say it to a screen reader only.
    const nearG = (n, i, a) => '<li class="wk-near wk-near--row"><button type="button" class="wk-near__b" data-near="' + (state.model.nearby || []).indexOf(n) + '"><span>' +
      (i > 0 && a[i - 1].kind === n.kind ? '<span class="ogc-sr">' + esc(n.kind) + ', </span>' : '<span class="wk-near__k">' + esc(n.kind) + '</span>') + '<span class="wk-near__n">' + esc(n.name) + '</span>' +
      (n.distance || n.hours ? '<span class="wk-near__s">' + esc([n.hours, n.distance].filter(Boolean).join(' · ')) + '</span>' : '') + '</span>' + I.right + '</button></li>';
    const near = (state.model.nearby || []).map((n, i, a) => GUIDE ? nearG(n, i, a) : '<li class="wk-near">' +
      '<p class="wk-near__k">' + esc(n.kind) + '</p><p class="wk-near__n">' + esc(n.name) + '</p>' +
      '<p class="wk-near__s">' + esc([n.address, n.hours, n.distance].filter(Boolean).join(' · ')) + '</p>' +
      '<p class="wk-near__btn">' + (n.phone ? '<a class="wk-btn wk-btn--line wk-btn--small" href="' + O.telHref(n.phone) + '">' + I.phone + 'Call<span class="wk-hnum"><span class="wk-hsep">&nbsp;· </span><span class="wk-btn__num">' + esc(n.phone) + '</span></span></a>' : '') +
      (n.address ? '<a class="wk-btn wk-btn--line wk-btn--small" href="https://www.google.com/maps/dir/?api=1&destination=' + encodeURIComponent(n.name + ', ' + n.address) + '" target="_blank" rel="noopener">Directions</a>' : '') + '</p></li>').join('');
    const nearby = near ? '<section class="wk-nearby" aria-labelledby="wk-near-t"><h3 class="wk-eyebrow" id="wk-near-t">Nearby, off campus</h3><ul>' + near + '</ul></section>' : '';
    if (state.campus && O.map && O.map.app) { state.mapExtra = nearby; return '<div class="wk-mapslot" id="wk-map"></div>'; }
    // The map still on its way: its shape in the site's colours, not "Loading…".
    if (O.map && state.campusLoaded !== state.year) return '<div class="wk-mapwait" aria-busy="true" aria-label="Campus map"></div>' + nearby;
    const d = state.model.days.find(x => x.date === state.now.date), m = state.now.minutes;
    const cards = placeGroups().map(g => {
      const later = !d ? [] : d.items.filter(it => it.place && placeKey(it.place) === g.key && rowState(it, d, st) !== 'past');
      const open = !d ? [] : d.allDay.filter(it => it.place && placeKey(it.place) === g.key && it.start != null && it.start <= m && m < endOf(it, d));
      const bits = open.map(it => '<li><span>Until ' + esc(clock(it.end)) + '</span>' + esc(it.title.replace(/\s+open$/i, '')) + '</li>').concat(later.slice(0, 4).map(it => '<li><span>' + esc(it.start != null ? zt(d.date, it.start) : it.startText) + '</span>' + esc(it.title) + '</li>'));
      const extra = later.length > 4 ? '<li><span></span>And ' + (later.length - 4) + ' more</li>' : '';
      // The map area: a building listed only by its rooms (Cedarville's "Stevens Student
      // Center Room 241") is named for the building, with every room under it; Still today before the
      // rooms, as on the mapped cards.
      const derived = String(g.main.code).toUpperCase() !== g.key, name = derived ? g.main.building || String(g.main.name).replace(/\s*(room|rm\.?|#)\s*[\w–-]+$/i, '') || g.main.name : g.main.name;
      // (A room named for its building drops the building inside its card: "Room 241"; the map area.)
      const rname = r => { const n = inBuilding(r, name); return n.toLowerCase().indexOf(name.toLowerCase() + ' ') === 0 && n.length > name.length + 1 ? n.slice(name.length + 1).replace(/^./, ch => ch.toUpperCase()) : n; };
      // (In number order: "240" before "241"; the map area, polish 3.)
      const num = r => { const m = /(\d+)\D*$/.exec(rname(r)); return m ? +m[1] : Infinity; };
      const rooms = (derived ? [g.main].concat(g.rooms) : g.rooms).slice().sort((a, b) => num(a) - num(b) || String(rname(a)).localeCompare(rname(b))).map(r => '<li><span>' + esc(rname(r)) + '</span><code>' + esc(r.code) + '</code></li>').join('');
      return '<section class="wk-pcard" id="pl-' + esc(g.key) + '" tabindex="-1" aria-labelledby="pl-' + esc(g.key) + '-t">' +
        '<div class="wk-pcard__head"><h3 id="pl-' + esc(g.key) + '-t">' + esc(name) + '</h3><code>' + esc(derived ? g.key : g.main.code) + '</code></div>' +
        (bits.length ? '<div class="wk-pcard__today"><b>Still today</b><ul>' + bits.join('') + extra + '</ul></div>' : '') +
        (rooms ? '<ul class="wk-pcard__rooms">' + rooms + '</ul>' : '') + '</section>';
    }).join('');
    return '<p class="wk-lede-sm">' + esc(S().venue) + '</p><div class="wk-places">' + cards + '</div>' + nearby;
  }
  // A place opened on the map, its sheet up (a schedule row's place, What's there, a ?to= link).
  function openPlace(code) {
    const p = state.model.places[String(code).toUpperCase()];
    setView('places');
    if (p && O.map && O.map.app) { if (state.app && document.getElementById('wk-map')) state.app.focus(p.code); else state.pendingPlace = p.code; return; }
    const el = p && document.getElementById('pl-' + placeKey(p));
    if (!el) return;
    el.scrollIntoView({ block: 'start' });
    el.focus({ preventScroll: true });
    el.classList.add('is-hit');
    say.textContent = 'Places, ' + el.querySelector('h3').textContent;
  }

  /* ------------------------------------------------ the campus map and directions */

  // The campus (campus.csv, OpenStreetMap, kept per campus on the server) with its buildings, doors and
  // pins, to see where things are; the map itself is ogc-map-app.js. Oct 13, Michael: "keep the Google
  // Maps stuff and not try to do our own maps… for actual directions, let's rely on GPS and everything
  // from Google Maps." So every Directions opens Google Maps' walking directions (dirsUrl, below).
  async function loadCampus(year, folder) {
    state.campus = state.rooms = null; state.mapEl = state.map = null;
    if (state.app) { state.app.destroy(); state.app = null; }
    if (!O.map) return;
    const get = n => fetch(folder + n + '.csv', { cache: 'no-store' }).then(r => r.ok ? r.text() : '').catch(() => '');
    const [ct, rt] = await Promise.all([get('campus'), get('rooms')]);
    const merge = (n, rows) => O.edits ? O.edits.merge(year, n, rows) : rows;
    const c = O.map.campus(merge('campus', O.csvToObjects(ct)));
    state.campusLoaded = year;
    if (!c.items.length) return;
    state.campus = c;
    // The halls with rooms this year, framed with the buildings the schedule uses when the map opens.
    state.halls = Array.from(new Set(merge('rooms', O.csvToObjects(rt)).filter(r => r.hall && !/^#/.test(r.hall)).map(r => r.hall)));
  }
  // A place's building on the map (the building places.csv names, else its code).
  const buildingOf = p => O.map && state.campus ? O.map.buildingFor(state.campus, p, state.model.places) : null;
  // Directions: Google Maps' walking directions to the place's building entrance (campus.csv lat, lng),
  // or a field's pin; '' while the campus isn't read, or for a place the map can't find.
  const dirsUrl = p => O.map && O.map.directionsUrl && state.campus && p ? O.map.directionsUrl(state.campus, p, state.model.places) : '';
  // Opened beside the page (a phone hands it to its Maps app), with what it does in its tooltip.
  const DIRS_TITLE = ' title="Walking directions in Google Maps"', DIRS_ATTRS = ' target="_blank" rel="noopener"' + DIRS_TITLE;
  // The app is made once a year and moved into each new drawing of the page, so it keeps its place.
  function mountMap() {
    const slot = document.getElementById('wk-map');
    if (!slot || !state.campus || !O.map || !O.map.app) { if (state.app) state.app.hide(); return; }
    if (!state.app) state.app = O.map.app();
    state.app.mount(slot, mapCtx());
    if (state.pendingPlace) { const c = state.pendingPlace; state.pendingPlace = ''; state.app.focus(c); }
  }
  // What the map needs from the page: today's rows with their state, every row (for search), Help.
  function mapCtx() {
    const rowsOf = d => d.items.concat(d.allDay || [], d.nightly || []).filter((it, i, a) => it.place && a.indexOf(it) === i);
    return {
      year: state.year, campus: state.campus, places: state.model.places, help: helpRows(), halls: state.halls || [],
      guide: GUIDE, full: GUIDE && phoneQ.matches, extra: state.mapExtra || '',
      now: () => ({ date: state.now.date, minutes: state.now.minutes }),
      // The guide's one way to say a time ("11:00 PM ET" to a reader elsewhere), for Places too (map area, polish 3).
      clock: m => zt(state.now.date, m),
      today: () => {
        const st = status(), d = state.model.days.find(x => x.date === state.now.date);
        // allDay and closed (the map area): a place open all day says "Closed · reopens noon"
        // during services, as Open now does.
        return !d ? [] : rowsOf(d).map(it => ({ id: it.id, title: it.title.replace(/\s+open$/i, ''), code: it.place.code, start: startOf(it), end: endOf(it, d), startText: it.startText, audience: it.audience, state: rowState(it, d, st), allDay: (d.allDay || []).indexOf(it) > -1, closed: (d.allDay || []).indexOf(it) > -1 ? closedNow(it, d) : null }));
      },
      events: () => [].concat.apply([], state.model.days.map(d => rowsOf(d).map(it => ({ title: it.title, code: it.place.code, start: startOf(it), when: (d.name || O.fmtDate(d.date, 'weekday')) + (it.start != null ? ' ' + O.formatTime(it.start) : '') })))),
      openEvent: id => openEvent(id),
      say: t => { say.textContent = t; }
    };
  }

  /* ------------------------------------------------ help, by what you need */

  // help.csv's needs. Emergency is always there (911 is always true), even for a campus whose Help
  // hasn't been written yet.
  function helpRows() {
    const hs = (state.model.help || []).filter(h => h.need);
    return hs.some(h => h.kind === 'emergency') ? hs : [{ need: 'Emergency', text: '', phone: '911', action: 'Call 911', kind: 'emergency', hours: '', open: '', link: '', pin: '' }].concat(hs);
  }
  // In the guide, the call-in line is a Help line too (Andrew's guide, Oct 13): for someone kept in their
  // room, the services by phone. From the COA's own number and PIN, while the schedule has rows on it.
  function callInHelp() {
    const ci = callIn();
    if (!GUIDE || !ci || !state.model.days.some(d => d.items.some(it => it.callIn))) return null;
    return { need: 'Call-in line', text: 'Listen to the services by phone.', phone: ci.num, pin: ci.pin, action: 'Call in', kind: 'callin', hours: '', open: '', link: '', place: '', search: ['call in', 'call-in', 'listen', 'phone'] };
  }
  // Whether something with hours is open right now: from help.csv's hours, or ("desk") from the
  // Lodging Desk rows in schedule.csv (a row whose start is in words, "End of Communion", by its sort
  // time). → { open, until, oncall, next, tomorrow, row }
  function hoursState(h, d) {
    const m = state.now.minutes;
    if (h.hours === 'desk') {
      const rows = d ? d.desk.filter(it => startOf(it) != null) : [];
      const cur = rows.find(it => startOf(it) <= m && m < endOf(it, d));
      if (cur) return { open: true, until: endOf(cur, d), oncall: cur.kind === 'on_call', row: cur };
      const nx = rows.find(it => startOf(it) > m);
      return { open: false, next: nx ? startOf(nx) : null, row: nx };
    }
    const hs = O.parseHours(h.hours);
    if (!hs) return null;
    const p = O.parseISODate(state.now.date), wd = new Date(Date.UTC(p.y, p.m - 1, p.d)).getUTCDay();
    const on = day => { const r = []; hs.forEach(x => { if (x.days.indexOf(day) > -1) x.ranges.forEach(g => r.push(g)); }); return r.sort((a, b) => a[0] - b[0]); };
    // Today's times, and last night's that run past midnight.
    const ranges = on(wd).concat(on((wd + 6) % 7).filter(g => g[1] > 1440).map(g => [g[0] - 1440, g[1] - 1440]));
    const cur = ranges.find(g => g[0] <= m && m < g[1]);
    if (cur) return { open: true, until: cur[1] };
    const nx = ranges.filter(g => g[0] > m).sort((a, b) => a[0] - b[0])[0];
    if (nx) return { open: false, next: nx[0] };
    const tm = on((wd + 1) % 7)[0];
    return { open: false, next: tm ? tm[0] : null, tomorrow: !!tm };
  }
  // Opening times in the schedule's one format ("4:00 PM", "12:00 PM"), with the venue's zone when
  // the reader is elsewhere (Open now wrote "4 PM" and "noon").
  const clock = m => zt(state.now.date, m);
  // Status words: Open · until 11:00 PM, Closed · opens 4:00 PM, On call · until 10:00 PM. With what
  // is open or closed named in Help ("Lodging Desk closed · opens 4:00 PM"), so a row's Call button
  // isn't read as closed too.
  function hoursLine(hs, what) {
    if (!hs) return '';
    if (hs.open) return (hs.oncall ? (what ? what + ' on call' : 'On call') : what ? what + ' open' : 'Open') + ' · until ' + clock(hs.until);
    return (what ? what + ' closed' : 'Closed') + (hs.next != null ? ' · opens ' + (hs.tomorrow ? 'tomorrow ' : '') + clock(hs.next) : '');
  }
  // Help: Emergency first, as a card with the campus address (what 911 asks). Then every other need
  // one line: the need, open or closed, its one button with the number under it. A line opens for its
  // sentence and Directions.
  // afterEm: what goes right under the Emergency card (Open now, on a laptop's Help tab).
  function helpView(st, afterEm) {
    const d = state.model.days.find(x => x.date === state.now.date), s = S();
    const rows = helpRows();
    const em = rows.filter(h => h.kind === 'emergency'), rest = rows.filter(h => h.kind !== 'emergency');
    const addr = s.address ? String(s.address).replace(/, [A-Z]{2} \d{5}$/, '') : '';
    const emCard = em.map(h => '<section class="wk-hemerg"><div><h3>' + esc(h.need) + '</h3>' + (addr ? '<p>Campus · ' + esc(addr) + '</p>' : '') + (h.text ? '<p>' + esc(h.text) + '</p>' : '') + '</div>' +
      '<a class="wk-btn wk-btn--alert" href="' + O.telHref(h.phone || '911') + '">' + I.phone + esc(h.action || 'Call 911') + '</a></section>').join('');
    const line = h => {
      const hs = h.hours ? hoursState(h, d) : null, k = 'h-' + O.slug(h.need), open = state.open.has(k);
      const url = safeUrl(h.link);
      const short = a => a && a.length <= 12 ? a : '';
      // A number to call while the place is closed is its after-hours line: the tooltip says so.
      const after = hs && !hs.open ? ' title="After hours"' : '';
      // A text's words over its number, under its button, as every Call shows its number:
      // "ConferenceGuest" / "to 226787" (it broke as "ConferenceGuest to" / "226787").
      const sms = /^sms:([^?]+)(?:\?.*?body=([^&]*))?/i.exec(url || '');
      let smsWords = '';
      try { smsWords = sms && sms[2] ? decodeURIComponent(sms[2]) : ''; } catch (e) { smsWords = ''; }
      const smsLine = sms ? (smsWords ? '<span>' + esc(smsWords) + '</span><span>to ' + esc(sms[1]) + '</span>' : '<span>' + esc(sms[1]) + '</span>') : '';
      const btn = h.phone ? '<span class="wk-hbtn"><a class="wk-btn wk-btn--line wk-btn--small" href="' + O.telHref(h.phone, h.pin) + '" aria-label="' + esc(h.action || 'Call') + ', ' + esc(h.phone) + '"' + after + '>' + I.phone + 'Call</a><small>' + esc(h.phone) + (h.pin ? '<span>PIN ' + esc(pinText(h.pin)) + '</span>' : '') + '</small></span>'
        : url && !(h.place && st.kind !== 'past') ? '<span class="wk-hbtn"><a class="wk-btn wk-btn--line wk-btn--small" href="' + esc(url) + '"' + ext(url) + (short(h.action) ? '' : ' aria-label="' + esc(h.action || 'Open') + '"') + '>' + esc(short(h.action) || (sms ? 'Text' : 'Open')) + '</a>' + (smsLine ? '<small>' + smsLine + '</small>' : '') + '</span>' : '';
      const p = h.place ? state.model.places[String(h.place).toUpperCase()] : null;
      const status = hs ? '<small class="' + (hs.open ? 'is-open' : 'is-shut') + '">' + esc(hoursLine(hs, h.open)) + '</small>' : p ? '<small>' + esc(roomText(p, h.need)) + '</small>' : '';
      const body = (h.text ? '<p>' + esc(h.text) + '</p>' : '') + (h.before && !theWeek(st) ? '<p>' + esc(h.before) + '</p>' : '') +
        (p ? placeBlock(p, st) : '');
      // The chevron at the row's right edge, after the button (a second way to open the row, for a thumb).
      return '<li class="wk-hrow' + (open ? ' is-open' : '') + '"><button type="button" class="wk-hrow__t" data-hx="' + esc(k) + '" aria-expanded="' + open + '"><b>' + esc(h.need) + '</b>' + status + '</button>' + (btn || '<span></span>') +
        '<button type="button" class="wk-hrow__chev" data-hx="' + esc(k) + '" tabindex="-1" aria-hidden="true">' + I.down + '</button>' +
        '<div class="wk-hrow__body"' + (open ? '' : ' hidden') + '>' + body + '</div></li>';
    };
    const ci = callInHelp();
    if (ci) rest.push(ci);
    // The guide (Andrew's guide, Oct 13): Emergency first, its button red and the full width; then each
    // need with its status and its one action as a full-width button with the number on it. The need's
    // name opens its sheet (what it's for, its hours, where it is, Directions).
    if (GUIDE) {
      const emG = em.map(h => '<section class="wk-hemerg wk-hemerg--big"><h3>' + esc(h.need) + '</h3>' + (addr ? '<p>Campus · ' + esc(addr) + '</p>' : '') + (h.text ? '<p>' + esc(h.text) + '</p>' : '') +
        '<a class="wk-btn wk-btn--alert wk-btn--big" href="' + O.telHref(h.phone || '911') + '">' + I.phone + esc(h.action || 'Call 911') + '</a></section>').join('');
      const card = h => {
        const hs = h.hours ? hoursState(h, d) : null, p = h.place ? state.model.places[String(h.place).toUpperCase()] : null;
        const status = hs ? '<small class="' + (hs.open ? 'is-open' : 'is-shut') + '">' + esc(hoursLine(hs, h.open)) + '</small>' : p ? '<small>' + esc(roomText(p, h.need)) + '</small>' : '';
        return '<li class="wk-hcard"><button type="button" class="wk-hcard__t" data-help="' + esc(O.slug(h.need)) + '"><span><b>' + esc(h.need) + '</b>' + status + '</span>' + I.right + '</button>' + helpAction(h, st, hs) + '</li>';
      };
      return '<div class="wk-help wk-help--big">' + emG + (afterEm || '') + (rest.length ? '<ul class="wk-hcards">' + rest.map(card).join('') + '</ul>' : '') + '</div>';
    }
    return '<div class="wk-help">' + emCard + (afterEm || '') + (rest.length ? '<ul class="wk-hlist">' + rest.map(line).join('') + '</ul>' : '') + '</div>';
  }
  // A Help need's one action, the full width: Call with its number on it (the PIN under it), else its
  // link in its own words ("Lost and found list"), a text as "Text ConferenceGuest to 226787".
  function helpAction(h, st, hs, filled) {
    const url = safeUrl(h.link), after = hs && !hs.open ? ' title="After hours"' : '';
    if (h.phone) return '<a class="wk-btn' + (filled ? '' : ' wk-btn--line') + ' wk-btn--big" href="' + O.telHref(h.phone, h.pin) + '"' + after + '>' + I.phone + 'Call<span class="wk-btn__num">' + esc(h.phone) + '</span></a>' +
      (h.pin ? '<small class="wk-sheet__pinline">PIN ' + esc(pinText(h.pin)) + '</small>' : '');
    if (!url) return '';
    const sms = /^sms:([^?]+)(?:\?.*?body=([^&]*))?/i.exec(url);
    let words = '';
    try { words = sms && sms[2] ? decodeURIComponent(sms[2]) : ''; } catch (e) { words = ''; }
    // A text keeps its words as typed (ConferenceGuest), out of the button's capitals.
    const label = sms ? 'Text<span class="wk-btn__num">' + esc((words ? words + ' to ' : '') + sms[1]) + '</span>' : esc(h.action || 'Open');
    return '<a class="wk-btn' + (filled ? '' : ' wk-btn--line') + ' wk-btn--big" href="' + esc(url) + '"' + ext(url) + '>' + label + '</a>';
  }
  // Care nearby, its own sheet: Call (the one filled button, the number on it), then Directions (driving,
  // in Google Maps), its address, hours and distance as nearby.csv has them.
  function openNearSheet(i, opener) {
    const n = (state.model.nearby || [])[i];
    if (!n) return;
    sheetOpener = opener || document.activeElement;
    const dir = n.address ? 'https://www.google.com/maps/dir/?api=1&destination=' + encodeURIComponent(n.name + ', ' + n.address) : '';
    sheet.innerHTML = '<div class="wk-sheet__in">' + grabber() + '<button type="button" class="wk-sheet__x" data-close aria-label="Close">' + I.close + '</button>' +
      '<p class="wk-kicker">' + esc(n.kind || 'Nearby') + '</p><h2 class="wk-sheet__h" id="wk-sheet-t">' + esc(n.name) + '</h2>' +
      (n.hours || n.distance ? '<p class="wk-sheet__when">' + esc([n.hours, n.distance].filter(Boolean).join(' · ')) + '</p>' : '') +
      (n.phone || dir ? '<div class="wk-sheet__acts">' + (n.phone ? '<a class="wk-btn wk-btn--big" href="' + O.telHref(n.phone) + '">' + I.phone + 'Call<span class="wk-btn__num">' + esc(n.phone) + '</span></a>' : '') +
        (dir ? '<a class="wk-btn wk-btn--line wk-btn--big" href="' + esc(dir) + '" target="_blank" rel="noopener" title="Directions in Google Maps">' + I.dirs + 'Directions</a>' : '') + '</div>' : '') +
      (n.address ? '<div class="wk-sheet__where">' + I.pin + '<div><b>' + esc(n.address) + '</b></div></div>' : '') + '</div>';
    sheet.dataset.ev = 'near:' + i;
    openSheet();
  }
  // A Help need's own sheet: what it's for, its hours, its action, where it is (with Directions).
  // A place's Directions link in the week (Google Maps, the map agent's dirsUrl), else none.
  const dirsOf = (p, st) => p && (theWeek(st) || nearWeek(st)) ? dirsUrl(p) : '';
  function openHelpSheet(key, opener) {
    const h = helpRows().concat(callInHelp() || []).find(x => O.slug(x.need) === key);
    if (!h) return;
    const st = status(), d = state.model.days.find(x => x.date === state.now.date), hs = h.hours ? hoursState(h, d) : null;
    const p = h.place ? state.model.places[String(h.place).toUpperCase()] : null;
    sheetOpener = opener || document.activeElement;
    sheet.innerHTML = '<div class="wk-sheet__in">' + grabber() + '<button type="button" class="wk-sheet__x" data-close aria-label="Close">' + I.close + '</button>' +
      '<p class="wk-kicker">Help</p><h2 class="wk-sheet__h" id="wk-sheet-t">' + esc(h.need) + '</h2>' +
      (hs ? '<p class="wk-sheet__live"><em class="' + (hs.open ? 'is-on' : 'is-over') + '">' + esc(hoursLine(hs, h.open)) + '</em></p>' : '') +
      // Its action filled (Call, or its link), then Directions as the outline under it; the small map last.
      (h.kind === 'emergency' ? '<div class="wk-sheet__acts"><a class="wk-btn wk-btn--alert wk-btn--big" href="' + O.telHref(h.phone || '911') + '">' + I.phone + esc(h.action || 'Call 911') + '</a></div>'
        : helpAction(h, st, hs) || dirsOf(p, st) ? '<div class="wk-sheet__acts">' + helpAction(h, st, hs, true) +
          (dirsOf(p, st) ? '<a class="wk-btn' + (helpAction(h, st, hs) ? ' wk-btn--line' : '') + ' wk-btn--big" href="' + esc(dirsOf(p, st)) + '"' + DIRS_ATTRS + '>' + I.dirs + 'Directions</a>' : '') + '</div>' : '') +
      (h.text ? '<p class="wk-sheet__note">' + esc(h.text) + '</p>' : '') + (h.before && !theWeek(st) ? '<p class="wk-sheet__note">' + esc(h.before) + '</p>' : '') +
      (p ? '<p class="wk-sheet__when wk-sheet__at">' + I.pin + '<span>' + esc(roomText(p, '')) + '</span></p>' + placeBlock(p, st, 'maponly', h.open || h.need) : '') + '</div>';
    sheet.dataset.ev = 'help:' + key;
    openSheet();
    if (O.map && !state.campus && p) campusSoon().then(() => { if (sheet.open && state.campus && sheet.dataset.ev === 'help:' + key) { const o = sheetOpener; openHelpSheet(key, o); } });
  }

  // Today's head has one label, "Saturday · Today", over its date (T8).
  const dayHead = (d, today) => '<h3 class="wk-dayname" id="rd-' + esc(d.key) + '"><span class="wk-dayname__w">' + esc(O.fmtDate(d.date, 'weekday')) + (today ? ' · Today' : '') + '<span class="ogc-sr">, </span></span>' +
    '<span class="wk-dayname__d">' + esc(O.fmtDate(d.date, 'md')) + '</span></h3>';

  // Before and during the week: the services, a day at a time. During the week the page opens on
  // today; the days before it fold into one line, so "Now" is near the top every day.
  function weekList(st) {
    const next = nextService(st);
    const day = d => {
      const items = serviceItems(d).concat(cancelledOn(d).filter(isService));
      if (!items.length) return '';
      items.sort((a, b) => a.sort - b.sort);
      const today = st.kind === 'live' && d.date === state.now.date;
      const on = today ? homeNow(d, st) : null;
      return '<section class="wk-day' + (today ? ' is-today' : '') + '" aria-label="' + esc(O.fmtDate(d.date, 'long')) + '">' + dayHead(d, today) + zoneHead(d, items) +
        '<ol class="wk-list">' + items.map(it => row(it, d, st, { next: it === next, now: it === on })).join('') + '</ol></section>';
    };
    const ds = state.model.days;
    if (st.kind !== 'live') return '<div class="wk-week">' + ds.map(day).join('') + '</div>';
    // The days before today fold into one line, and only when there is something in them to play.
    const before = ds.filter(d => d.date < state.now.date && serviceItems(d).length);
    const n = before.reduce((k, d) => k + serviceItems(d).reduce((m, it) => m + plays(it).length, 0), 0);
    // Today and after are drawn first, so the zones are named over today, not inside the fold.
    const ahead_ = ds.filter(d => d.date >= state.now.date).map(day).join('');
    const fold = n ? '<details class="wk-earlier" data-k="earlier-week"><summary>Earlier this week' +
      '<span> · ' + n + ' recording' + (n === 1 ? '' : 's') + '</span>' + I.down + '</summary>' + before.map(day).join('') + '</details>' : '';
    return '<div class="wk-week">' + fold + ahead_ + '</div>';
  }

  // After the Conference: its recordings, the ring on the row's edge. Each service names them once
  // ("Worship · 10:00 AM"; a recording named for its service says only the time), with its speaker,
  // length and Scripture. Every recorded row is here, services or not (the outreach meeting, the
  // Young Folks singing). On a phone, a row of day chips jumps to each day.
  function recordings() {
    const recorded = d => d.items.filter(it => plays(it).length);
    const ds = state.model.days.filter(d => recorded(d).length);
    const chips = ds.length > 1 ? '<nav class="wk-recdays" aria-label="Days">' + ds.map(d => '<a href="#rd-' + esc(d.key) + '">' + esc(O.fmtDate(d.date, 'weekdayShort')) + '</a>').join('') + '</nav>' : '';
    return chips + '<div class="wk-week wk-week--recs">' + ds.map(d => {
      const items = recorded(d);
      return '<section class="wk-day" aria-label="' + esc(O.fmtDate(d.date, 'long')) + '">' + dayHead(d) + '<ol class="wk-recs">' + items.map(it => {
        // The venue's time alone: in an archive it only tells morning from afternoon ("ET" on
        // every row for a listener elsewhere was noise).
        const recs = plays(it), time = it.start != null ? O.formatTime(it.start) : it.startText;
        const label = recs.every(a => O.slug(a.title) === O.slug(it.title)) ? time : it.title + ' · ' + time;
        return '<li><p class="wk-label">' + esc(label) + '</p>' + recs.map(a => rec(a, '')).join('') + '</li>';
      }).join('') + '</ol></section>';
    }).join('') + '</div>';
  }

  // A recording: the ring leads, then its title and a quiet line (the speaker, the length, the
  // Scripture). In a schedule row (inRow) the line is short, the first reference and how many more
  // ("Genesis 2 +2"), so it stays one line beside the row's ›; the sheet has them all (four
  // ragged lines and two tap targets side by side).
  // One psalm is a Psalm ("Psalms 13" → "Psalm 13"); a span of them stays Psalms.
  const refText = refs => (refs || []).map(x => String(x).replace(/^Psalms(?= \d+(?::[\d\s,–-]+)?$)/, 'Psalm')).join('; ');
  // In a row: the first two passages in full, then how many more in words ("Genesis 2, 3; Matthew 16
  // and 1 more"); the sheet has them all.
  const refShort = refs => { const r = refs || []; return r.length ? refText(r.slice(0, 2)) + (r.length > 2 ? ' and ' + (r.length - 2) + ' more' : '') : ''; };
  function rec(a, extra, inRow) {
    const id = recId(a), line = [a.by, O.fmtDuration(a.duration), inRow ? refShort(a.refs) : refText(a.refs), extra].filter(Boolean).join(' · ');
    const going = state.playing === id && !audio.paused;
    const btn = a.audio ? '<button type="button" class="wk-play" data-play="' + esc(id) + '" aria-label="' + (going ? 'Pause ' : 'Play ') + esc(a.title) + '">' + (going ? I.pause : I.play) + '</button>' : '<span class="wk-play wk-play--none"></span>';
    const url = safeUrl(a.url);
    const txt = '<p>' + (url ? '<a href="' + esc(url) + '">' + esc(a.title) + '</a>' : '<b>' + esc(a.title) + '</b>') + (line ? '<span>' + esc(line) + '</span>' : '') + '</p>';
    return '<div class="wk-rec' + (inRow ? ' wk-rec--row' : '') + (going ? ' is-on' : '') + '">' + btn + txt + '</div>';
  }

  /* ------------------------------------------------ the full schedule */

  function dayTabs(days) {
    if (days.length < 2) return '';
    const cur = days.find(d => d.key === state.day), end = conf().end;
    // The guide (Andrew's guide, Oct 13): each day a large block, its weekday over its date, today's dot
    // under it; check-out's is named in its tooltip and to a screen reader.
    if (GUIDE) return '<nav class="wk-days wk-days--blocks" aria-label="Day" style="--n:' + days.length + '">' + days.map(d => {
      const on = d.key === state.day, today = d.date === state.now.date, out = d.date > end;
      return '<button type="button" data-day="' + d.key + '" aria-pressed="' + on + '" title="' + esc((out ? 'Check-out · ' : '') + O.fmtDate(d.date, 'long')) + '">' +
        '<span class="wk-days__w">' + esc(O.fmtDate(d.date, 'weekdayShort')) + '</span><span class="wk-days__d">' + esc(O.fmtDate(d.date, 'day')) + '</span>' +
        '<i aria-hidden="true"' + (today ? '' : ' hidden') + '></i><span class="ogc-sr">' + (out ? ', Check-out' : '') + (today ? ', today' : '') + '</span></button>';
    }).join('') + '</nav>' + (cur ? '<p class="wk-dayfull">' + esc(O.fmtDate(cur.date, 'long')) + '</p>' : '');
    return '<nav class="wk-days" aria-label="Day">' + days.map(d => {
      const on = d.key === state.day, today = d.date === state.now.date;
      // The morning after the last day of services is Check-out, so the tabs agree with the dates
      // in the header ("June 5–9").
      const out = d.date > end;
      // Today's dot only on a tab that is not the one open (the open tab already has the line).
      return '<button type="button" data-day="' + d.key + '" aria-pressed="' + on + '"' + (out ? ' title="' + esc(O.fmtDate(d.date, 'long')) + '"' : '') + '>' +
        (out ? 'Check-out<span class="ogc-sr">, ' + esc(O.fmtDate(d.date, 'long')) + '</span>' : esc(O.fmtDate(d.date, 'weekdayShort')) + ' <span>' + esc(O.fmtDate(d.date, 'day')) + '</span>') +
        (today ? (on ? '' : '<i aria-hidden="true"></i>') + '<span class="ogc-sr">, today</span>' : '') + '</button>';
    }).join('') + '</nav>' + (cur ? '<p class="wk-dayfull">' + esc(O.fmtDate(cur.date, 'long')) + '</p>' : '');
  }

  // A deadline kept as an all-day row ("Chess and Dutch Blitz sign-ups close 10:15 PM"): it's a time,
  // not a place, so it goes among the day's rows at that time, never in the All day band.
  const DUE_T = /\s*(?:at\s+)?(\d{1,2}(?::\d{2})?\s*[ap]\.?m\.?|noon|midnight)\s*$/i;
  const isDue = it => it.kind === 'signup' || it.kind === 'deadline';
  function dueRow(it) {
    const m = DUE_T.exec(it.title), t = m ? O.parseTime(m[1]) : null;
    // A moment, not a span: never "Now".
    return t == null ? it : Object.assign({}, it, { title: it.title.replace(DUE_T, ''), start: t, end: t, sort: t });
  }

  // What runs all day (the prayer rooms, the outreach room, the Lodging Desk's hours, "No preteen
  // program today"): one quiet band at the top of the day, before the program chips.
  function allDayBand(d) {
    const rows = d.allDay.filter(it => shows(it) && !isDue(it)).map(it => {
      const p = it.place && !it.place.unknown ? it.place : null;
      const name = it.title.replace(/\s+open$/i, '');
      const where = p ? roomText(p, name) : '';
      const hours = it.start != null ? ztRange(d.date, it.start, it.end) : it.startText;
      return '<li><b>' + esc(name) + '</b><span>' + esc([where, hours, it.closedDuring === 'services' ? 'Closed during services' : ''].filter(Boolean).join(' · ')) + '</span></li>';
    });
    const desk = d.desk.filter(it => shows(it) && startOf(it) != null);
    if (desk.length) {
      // The zone once, at the end of the line ("ET" four times on the Lodging Desk's line).
      const fmt = it => (it.start != null ? fmtRange(it.start, it.end) : it.startText + (it.end != null ? '–' + O.formatTime(it.end) : ''));
      const open = desk.filter(it => it.kind !== 'on_call').map(fmt), call = desk.filter(it => it.kind === 'on_call').map(fmt);
      const p = desk[0].place && !desk[0].place.unknown ? roomText(desk[0].place, 'Lodging Desk') : '';
      const lodging = helpRows().find(h => h.hours === 'desk');
      rows.push('<li><b>' + esc(lodging && lodging.open ? lodging.open : 'Lodging Desk') + '</b><span>' + esc([p, open.join(', '), call.length ? 'On call ' + call.join(', ') : ''].filter(Boolean).join(' · ') + zoneAt(d.date, startOf(desk[0]))) + '</span></li>');
    }
    // Folded to one line ("All day · 3"), so a phone's first screen is the day's own rows.
    return rows.length ? '<details class="wk-allday" data-k="allday"><summary><b>All day</b><span>· ' + rows.length + '</span>' + I.down + '</summary><ul>' + rows.join('') + '</ul></details>' : '';
  }

  // key: Today's own list (no All day band, and what's over folds into one line). Without it, the
  // Schedule tab's whole day: the All day band, then every row, what's over dimmed.
  function dayList(st, key) {
    const d = state.model.days.find(x => x.key === (key || state.day));
    if (!d) return '';
    // The Conference's rows, and the Preteen and Young Folks programs the reader has chosen to see;
    // removed rows struck through for their day; a deadline at its time ("sign-ups close 10:15 PM");
    // the nightly rows (quiet time) at the day's end.
    const items = d.items.filter(shows).concat(cancelledOn(d).filter(shows), d.allDay.filter(it => shows(it) && isDue(it)).map(dueRow)).sort((a, b) => a.sort - b.sort);
    const nightly = d.nightly.filter(shows);
    // On the guide's Today, the row marked Now is the one the Now card names, so the two agree.
    const card = key && GUIDE && state.cardNow ? items.find(it => it.id === state.cardNow && rowState(it, d, st) === 'now') : null;
    const on = card || nowOne(items.filter(it => !it.cancelled), d, st);
    // The main place, on the days that use it (during the week it opens the building in Places).
    const mp = mainPlace();
    // Labelled, so it's plain that the services (whose rows name no room) are there.
    // (The guide's rows each name their place, so it has no such line.)
    const place = !key && !GUIDE && mp && d.items.some(it => it.place && it.place.name === mp.name) ? '<p class="wk-place wk-place--day">' + I.pin + '<span>Services · ' + (hasPlaces(st) ? placeLink(mp) : placeOpen(mp)) + '</span></p>' : '';
    // On Today, what is over folds into one line ("Earlier today · 3"), so the row on now is near the top.
    // The guide's Today (Andrew's guide, Oct 13) is only what's still to come, under "Still today", and
    // never the rows its Now and Next card already shows; the whole day is the Schedule tab's.
    const guideToday = key && GUIDE && d.date === state.now.date;
    const gone = key && d.date === state.now.date ? items.filter(it => rowState(it, d, st) === 'past') : [];
    const rest = items.filter(it => gone.indexOf(it) < 0 && !(guideToday && (state.cardShown || []).indexOf(it.id) > -1));
    const onRest = guideToday ? nowOne(rest.filter(it => !it.cancelled), d, st) : on;
    // The program chips sit right over the rows they filter.
    return place + (key ? '' : allDayBand(d)) + audChips(st) + (gone.length && !guideToday ? '<details class="wk-earlier wk-earlier--today" data-k="earlier-' + d.key + '"><summary>Earlier today' +
      '<span> · ' + gone.length + '</span>' + I.down + '</summary>' +
      '<ol class="wk-list">' + gone.map(it => row(it, d, st)).join('') + '</ol></details>' : '') +
      (rest.length || nightly.length ? (guideToday ? '<h3 class="wk-eyebrow wk-still">Still today</h3>' : '') + zoneHead(d, rest.concat(nightly)) + '<ol class="wk-list">' + rest.map(it => row(it, d, st, { now: it === onRest })).join('') +
      nightly.map(it => row(it, d, st, { night: true })).join('') + '</ol>' : '');
  }

  // Preteens · Young Folks: add-ons to the Conference's own rows (which always show), remembered on
  // this device. Someone signed in whose household brings a preteen or a Young Folk starts with theirs on.
  const AUDS = [['preteens', 'Preteens'], ['youngfolks', 'Young Folks']];
  // The plugin's key; a choice kept under v3's old one is carried over once.
  const AUD_KEY = 'ogc-week-shows';
  try { const old = localStorage.getItem('ogc3-week-shows'); if (old != null && localStorage.getItem(AUD_KEY) == null) localStorage.setItem(AUD_KEY, old); localStorage.removeItem('ogc3-week-shows'); } catch (e) { /* private window */ }
  const showing = (() => {
    try { const v = JSON.parse(localStorage.getItem(AUD_KEY)); if (Array.isArray(v)) return v.filter(k => k !== 'conference'); } catch (e) { /* private window */ }
    return null;
  })() || [];
  let chipsChosen = (() => { try { return localStorage.getItem(AUD_KEY) != null; } catch (e) { return false; } })();
  // The household's own programs, once, for a reader who hasn't chosen.
  function householdPrograms() {
    if (chipsChosen || !WP.me) return;
    const reg = mineOf('registrations').find(r => r.household);
    if (!reg) return;
    const ppl = (reg.people || []).filter(p => p && p.name);
    if (ppl.some(p => p.yf || p.kind === 'yf') && showing.indexOf('youngfolks') < 0) showing.push('youngfolks');
    if (ppl.some(p => p.preteen) && showing.indexOf('preteens') < 0) showing.push('preteens');
  }
  const hasPrograms = () => state.model.days.some(d => d.items.some(it => it.audience === 'preteens' || it.audience === 'youngfolks'));
  // The guide (Andrew's guide, Oct 13): the Conference's own rows are a toggle too, remembered on this
  // device ('0' = hidden); everyone's rows (all) always show. The Conference page keeps them always.
  const CONF_KEY = 'ogc-week-conf';
  let confShown = (() => { try { return localStorage.getItem(CONF_KEY) !== '0'; } catch (e) { return true; } })();
  const shows = it => it.audience === 'all' || (it.audience === 'conference' && (confShown || !GUIDE)) || showing.indexOf(it.audience) > -1;
  function audChips() {
    if (!hasPrograms()) return '';
    // The guide: three large toggles side by side, Conference · Preteens · Young Folks.
    if (GUIDE) return '<p class="wk-aud__k wk-aud__k--big" aria-hidden="true">Show</p><div class="wk-aud wk-aud--big" role="group" aria-label="Show">' +
      [['conference', 'Conference']].concat(AUDS).map(([k, label]) => '<button type="button" data-aud="' + k + '" aria-pressed="' + (k === 'conference' ? confShown : showing.indexOf(k) > -1) + '">' + I.check + '<span>' + label + '</span></button>').join('') + '</div>' +
      (!confShown && !showing.length ? '<p class="wk-allhidden">All hidden</p>' : '');
    return '<div class="wk-aud" role="group" aria-label="Also show"><span class="wk-aud__k" aria-hidden="true">Show</span>' +
      AUDS.map(([k, label]) => '<button type="button" data-aud="' + k + '" aria-pressed="' + (showing.indexOf(k) > -1) + '">' + I.check + label + '</button>').join('') + '</div>';
  }
  function toggleAud(k) {
    if (k === 'conference') {
      confShown = !confShown;
      try { localStorage.setItem(CONF_KEY, confShown ? '1' : '0'); } catch (e) { /* not remembered, still shown */ }
      render(true);
      say.textContent = 'Conference' + (confShown ? ' shown' : ' hidden');
      return;
    }
    const i = showing.indexOf(k);
    if (i > -1) showing.splice(i, 1); else showing.push(k);
    chipsChosen = true;
    try { localStorage.setItem(AUD_KEY, JSON.stringify(showing)); } catch (e) { /* not remembered, still shown */ }
    render(true);
    const label = AUDS.find(a => a[0] === k)[1];
    say.textContent = label + (i > -1 ? ' hidden' : ' shown');
  }

  // A row: its time, its title, at most one quiet line (who it's for, the room when it isn't the main
  // one, a change since it was posted). Once the schedule is posted the whole row is one tap that opens
  // its sheet (the › at its edge says so); its recording keeps its own play button.
  // o.now / o.next: the one row marked "Now" or "Next".
  function row(it, d, st, o) {
    o = o || {};
    const recs = plays(it);
    const time = it.start != null ? O.formatTime(it.start) : it.startText;
    // Now and Next live in the time column (the row's tint and its bold tan time say Now; a small
    // "Next" under the time), so a status never wraps under a long title. Cancelled stays by the title.
    const tag = it.cancelled ? ' <em class="wk-tag wk-tag--off">Cancelled</em>' : '';
    const tap = sheets(st) && !it.cancelled;
    const main = mainPlace();
    // In the guide every row says where it is, the services' own place too (Andrew's guide, Oct 13: "where
    // do I go now" is answered on the row, not in a line over the day).
    const softP = it.place && !it.place.unknown && (GUIDE || !main || it.place.name !== main.name) ? it.place : null;
    // A meal is a window, not a start: the guide says when the dining hall stops serving, under the time.
    const till = GUIDE && it.kind === 'meal' && it.start != null && it.end != null && it.end > it.start ? 'to ' + O.formatTime(it.end) : '';
    const aud = it.audience === 'preteens' ? 'Preteens' : it.audience === 'youngfolks' ? 'Young Folks' : '';
    const chg = changeText(changeOf(it));
    // A tag that says what the title already says ("Young Folks singing") is left off.
    const audShown = aud && it.title.toLowerCase().indexOf(aud.toLowerCase()) < 0;
    // On the Conference page, a row carried on the call-in line says so with the phone, so someone at
    // home sees which rows they can follow.
    const ci = !GUIDE && it.callIn && callIn() && st.kind !== 'past' ? '<span class="wk-ci" title="On the call-in line">' + I.phone + '<span class="ogc-sr">On the call-in line</span></span>' : '';
    const quiet = [audShown ? '<b class="wk-audtag">' + aud + '</b>' : '', softP ? esc(roomText(softP, it.title)) : '', o.night ? 'Every night' : '', chg ? '<em class="wk-chg">' + esc(chg) + '</em>' : ''].filter(Boolean).join(' · ');
    // The phone leads the quiet line when there is one; else it follows the title (never alone on a line).
    const name = '<p class="wk-name">' + (it.cancelled ? '<s>' + esc(it.title) + '</s>' : evName(it, st)) + (quiet ? '' : ci) + tag + '</p>';
    let c = name + (quiet ? '<p class="wk-soft">' + (ci ? ci.replace('wk-ci"', 'wk-ci wk-ci--lead"') : '') + quiet + '</p>' : '');
    if (recs.length && rowState(it, d, st) === 'past') c = name + recs.map(a => rec(a, '', true)).join('');
    // A time that is not a clock time ("After Communion") may wrap in its column.
    const tcls = it.start != null ? 'wk-t' : 'wk-t wk-t--words';
    // A reader in another zone: the zones are named once, over the day (zoneHead); on the Conference
    // page every timed row has the reader's own time under the venue's, in smaller muted type. The
    // guide is used on campus, so it keeps the venue's time alone.
    const away = it.start != null && !GUIDE ? theirClock(d.date, it.start) : null;
    const t = it.cancelled ? '<s>' + esc(time) + '</s>' : esc(time);
    const past = rowState(it, d, st) === 'past' && d.date === state.now.date;
    return '<li class="wk-row' + (tap ? ' is-tap' : '') + (it.emphasis ? ' is-em' : '') + (it.cancelled ? ' is-cancelled' : '') + (o.now ? ' is-now' : '') + (o.next ? ' is-next' : '') + (past ? ' is-past' : '') + '"><span class="' + tcls + '">' +
      (o.now ? '<span class="ogc-sr">Now, </span>' : '') + t +
      (away ? '<small class="wk-t2">' + esc(away.time) + (away.day ? '<span> ' + esc(away.day) + '</span>' : '') + '</small>' : '') +
      (till ? '<small class="wk-tend">' + esc(till) + '</small>' : '') + (o.next ? '<small class="wk-tnext">Next</small>' : '') + '</span><div class="wk-c">' + c + '</div>' +
      (tap ? '<span class="wk-chev" aria-hidden="true">' + I.right + '</span>' : '') + '</li>';
  }
  // Over a day's rows, for a reader in another time zone: the zones named once, in the time column
  // ("ET", and on the Conference page "Your time" under it), so the rows carry plain times.
  function zoneHead(d, items) {
    if (state.zonesSaid) return '';
    const it = items.find(x => x.start != null);
    const c = it ? theirClock(d.date, it.start) : null;
    if (!c) return '';
    state.zonesSaid = true;
    return '<p class="wk-zones" title="' + esc('Times where the Conference is' + (GUIDE ? '' : ', and yours under them')) + '"><span>' + esc(zoneShort(venueTZ(), c.inst)) + '</span>' +
      (GUIDE ? '' : '<small>Your time</small>') + '</p>';
  }

  // What has been posted, newest first: all of it until the schedule is in, then the three latest.
  // After the Conference, what came after it (a deadline only until it passes,
  // anything with an "until" only until then). A post whose facts the page already shows is not listed
  // again: "Schedules posted", the packet, registration,
  // the papers. During the week a post with nothing to open is left out.
  function news(st) {
    const s = S(), now = state.now.date, posted = schedulePosted(), past = st.kind === 'past';
    const shown = new Set([s.packet_url, s.registration_url, s.sermons_url, s.volunteer_url].filter(Boolean));
    paperDocs().forEach(a => shown.add(a.url));
    // A post about a schedule row (the communion notice) goes once that row is over.
    const over = new Set();
    state.model.days.forEach(d => d.items.forEach(it => docs(it).forEach(a => {
      if (a.url && (past || rowState(it, d, st) === 'past')) over.add(a.url);
    })));
    // The call-in line is on the page from registration on, so a post about it is not repeated.
    const callShown = !!callIn() && /^(registration|closed|live)$/.test(st.kind);
    const ms = (state.model.milestones || []).filter(m => m.date && !(m.url && (shown.has(m.url) || over.has(m.url))) && 
      !(m.until && m.until < now) &&
      !(posted && /^schedules? posted$/i.test(m.title)) && !(callShown && /\bcall-in\b/i.test(m.title)) &&
      // "Sign-ups open" with nothing to sign up on is left out.
      !(!m.url && /sign-?ups? open/i.test(m.title)) && (past
      ? m.phase === 'after' && m.kind !== 'business' && (m.kind === 'deadline' ? now <= m.date : m.date <= now)
      : m.phase === 'before' && m.date <= now && !/^(registration|deadline|alert)$/.test(m.kind) && !(st.kind === 'live' && !m.url)))
      .sort((a, b) => (a.date < b.date ? 1 : a.date > b.date ? -1 : 0))
      .slice(0, posted ? 3 : undefined);
    const all = safeUrl(s.news_url);
    if (!ms.length) return '';
    const list = '<ol class="wk-posts">' + ms.map(m => {
      // A refund or credit request goes to Your sign-ups once the year registers on the site.
      const url = /refund|credit/i.test(m.title) && regMode() === 'site' ? OWN.register + '?view=mine&year=' + state.year : safeUrl(m.url);
      const title = url ? '<a href="' + esc(url) + '"' + ext(url) + '>' + esc(m.title) + '</a>' : esc(m.title);
      // The date column is when a thing was posted; for a deadline, the day it is due.
      const due = m.kind === 'deadline', left = due ? O.daysBetween(now, m.date) : -1;
      const date = left === 0 ? 'Today' : left === 1 ? 'Tomorrow' : shortDate(m.date);
      // A post from another year than today's says its year on a line of its own, so "June 13" from
      // last summer never reads as a day still to come.
      const yr = left !== 0 && left !== 1 && String(m.date).slice(0, 4) !== String(now).slice(0, 4) ? '<br>' + esc(String(m.date).slice(0, 4)) : '';
      return '<li class="wk-post"><span class="wk-t">' + esc(date) + yr + '</span><span class="wk-c"><b>' + title + '</b>' +
        (m.note && !(url !== safeUrl(m.url) && /^Include /.test(m.note)) ? '<small>' + esc(m.note) + '</small>' : '') + '</span></li>';
    }).join('') + '</ol>';
    const foot = all ? '<a href="' + esc(all) + '"' + ext(all) + '>All news</a>' : '';
    // A card: in the header before and during the Conference, under the week after it. A past year
    // with no schedule lists it as the season.
    if (posted || newsUp(st)) return card('news', I.news, 'News', list, foot);
    return '<section class="wk-sec wk-news" aria-labelledby="wk-news-t"><h2 class="wk-h" id="wk-news-t">News</h2>' + list + (foot ? '<p class="wk-card__foot">' + foot + '</p>' : '') + '</section>';
  }

  /* ------------------------------------------------------ 3. the shelf */

  // What you look up rather than follow: a card each, side by side on a laptop, on the cream band
  // under the season. A card with nothing true in it is not drawn. A long packet takes a row of its own.
  function shelf(st) {
    const pk = packet(st), wide = pk && packetParts().length >= 4;
    const cards = [schedulePosted() && !newsUp(st) ? news(st) : '', wide ? '' : pk, papers(st), coming(st)].filter(Boolean);
    // Nothing to put on it: no band at all (never an empty cream strip).
    if (!cards.length && !wide && !aboutLine()) return '';
    return '<section class="wk-shelf' + (cards.length || wide ? '' : ' wk-shelf--bare') + '"><div class="wk-wrap">' +
      (wide ? '<div class="wk-cards wk-cards--wide">' + pk + '</div>' : '') +
      (cards.length ? '<div class="wk-cards wk-cards--' + cards.length + '">' + cards.join('') + '</div>' : '') + aboutLine() + '</div></section>';
  }
  // Only to a page that says what Annual Conference is (settings: about_url), once the Advisors approve
  // one (questions 5); the site's general About page didn't.
  const aboutLine = () => { const u = state.model ? safeUrl(S().about_url || '') : ''; return u ? '<p class="wk-new"><a href="' + esc(u) + '"' + ext(u) + '>About Annual Conference</a></p>' : ''; };
  const card = (k, icon, title, body, foot) => '<section class="wk-card wk-card--' + k + '" aria-labelledby="wk-' + k + '-t">' +
    '<h2 class="wk-card__h" id="wk-' + k + '-t">' + icon + '<span>' + title + '</span></h2>' + body + (foot ? '<p class="wk-card__foot">' + foot + '</p>' : '') + '</section>';

  // A packet paragraph's own small formatting, escaped first: "- " lines are a list, **bold**, and
  // [words](https://…) a link (an allowed address only).
  function inline(t) {
    return esc(t).replace(/\*\*([^*]+)\*\*/g, '<b>$1</b>').replace(/\[([^\]]+)\]\(([^)\s]+)\)/g, (m, w, u) => {
      const s = safeUrl(u.replace(/&amp;/g, '&'));
      return s ? '<a href="' + esc(s) + '"' + ext(s) + '>' + w + '</a>' : w;
    });
  }
  function rich(paras) {
    return paras.map(p => {
      const ls = String(p).split(/\n/);
      if (ls.length > 1 && ls.every(l => /^\s*[-•]\s+/.test(l) || !l.trim())) return '<ul>' + ls.filter(l => l.trim()).map(l => '<li>' + inline(l.replace(/^\s*[-•]\s+/, '')) + '</li>').join('') + '</ul>';
      return '<p>' + inline(p).replace(/\n/g, '<br>') + '</p>';
    }).join('');
  }

  // The information packet, a part at a time, each opening in place (before and during the week,
  // and on check-out day), each with its own address (#g-part) and Copy link; Print packet.
  const packetParts = () => Object.keys(state.model.guides || {}).map(k => state.model.guides[k]).filter(g => g.title && g.paras.length);
  function packet(st) {
    const s = S(), gs = packetParts();
    if ((st.kind === 'past' && !st.staying) || !s.packet_url && !gs.length || !postedBy(s.packet_posted)) return '';
    // To print: the packet made from these same parts (packet/); a separate PDF only when there are no parts.
    // One style for Print packet on the page and in the guide's Help.
    // Not in the guide: nobody prints from a phone at Conference; the Conference page has it.
    const pdf = GUIDE ? '' : gs.length ? '<a class="wk-btn wk-btn--line wk-btn--small" href="../packet/?year=' + esc(state.year) + esc(asOfParam()) + '">Print packet</a>'
      : safeUrl(s.packet_url) ? '<a class="wk-btn wk-btn--line wk-btn--small" href="' + esc(safeUrl(s.packet_url)) + '"' + ext(s.packet_url) + '>Packet (PDF)</a>' : '';
    const parts = gs.map(g => '<details class="wk-fold" id="g-' + esc(g.id) + '" data-k="g-' + esc(g.id) + '"><summary><b>' + esc(g.title) + I.down + '</b>' + (g.summary ? '<small>' + esc(g.summary) + '</small>' : '') + '</summary>' +
      '<div class="wk-fold__body">' + rich(g.paras) + '<p class="wk-fold__link"><button type="button" class="wk-linklike" data-copy="g-' + esc(g.id) + '">' + I.link + 'Copy link</button></p></div></details>').join('');
    return card('packet', I.book, 'Information packet' + newTag('packet') + unpub(s.packet_posted), parts ? '<div class="wk-folds">' + parts + '</div>' : '', pdf);
  }

  // The Conference's papers, as each is posted: the query before it, then the minutes first, the query
  // and the reports. (The communion notice is News.)
  function paperDocs() {
    const ds = [];
    state.model.days.forEach(d => d.items.forEach(it => { if (it.kind !== 'communion') docs(it).forEach(a => ds.push(a)); }));
    return ds.filter(a => safeUrl(a.url)).sort((a, b) => (/minutes/i.test(b.title) ? 1 : 0) - (/minutes/i.test(a.title) ? 1 : 0));
  }
  // Every paper has the same quiet line: when it went up, and for a file, what it is ("PDF · 4 pages").
  function paperLine(a) {
    const file = a.note && /^pdf/i.test(a.note) ? a.note.replace(/^PDF · /, 'PDF, ') : /\.pdf($|\?)/i.test(a.url) ? 'PDF' : '';
    return [a.posted ? 'Posted ' + O.fmtDate(a.posted.slice(0, 10), 'md') : '', file].filter(Boolean).join(' · ');
  }
  function papers() {
    const ds = paperDocs();
    if (!ds.length) return '';
    const label = ds.some(a => /minutes/i.test(a.title)) ? 'Minutes and papers' : 'Papers';
    return card('papers', I.doc, label + newTag('papers'), '<ul class="wk-links">' +
      ds.map(a => { const l = paperLine(a), u = safeUrl(a.url); return '<li><a href="' + esc(u) + '"' + ext(u) + '>' + esc(a.title) + '</a>' + (l ? '<small>' + esc(l) + '</small>' : '') + '</li>'; }).join('') + '</ul>');
  }

  // The Conferences still ahead, as far as each is known, leaving out any already named on the page
  // (this one, and the one said under the button after a Conference). Future dates are "Lord willing".
  // every announced year ahead (even one also named in the header), in one format:
  // "2027 · Lord willing, May 28 – June 1", then "Indiana Wesleyan University · Hosted by the …".
  function coming(st) {
    // On a past year's page, the next Conference is already in the header ("2027 · Volunteer ›"), so it
    // isn't listed again.
    const named = st.kind === 'past' && !st.staying && state.queue.length && ahead()[0] && ahead()[0].start ? ahead()[0].year : '';
    // Nor a year the header already reaches: its line under the buttons, or the arrow beside the year.
    const ys0 = known(), i = ys0.findIndex(y => y.year === state.year);
    const reach = [named, st.kind === 'past' ? '' : ((ahead().find(r => +r.year > +state.year)) || {}).year, (ys0[i + 1] || {}).year, (ys0[i - 1] || {}).year];
    const ys = ahead().filter(r => reach.indexOf(r.year) < 0).slice(0, 3);
    if (!ys.length) return '';
    return card('coming', I.cal, 'Coming up', '<ul class="wk-links">' +
      ys.map(r => {
        const main = r.start ? esc(r.year) + ' · ' + lw(r) + esc(noYear(O.fmtDateSpan(r.start, r.end))) : esc(r.year);
        const facts = [r.start && r.venue ? esc(r.venue) : '', r.hosts ? 'Hosted by the ' + esc(r.hosts) : ''].filter(Boolean).join(' · ');
        const title = opens(r) ? yearLink(r.year, main + ' ›', 'wk-linklike') : '<b>' + main + '</b>';
        return '<li>' + title + (facts ? '<small>' + facts + '</small>' : '') + '</li>';
      }).join('') + '</ul>');
  }

  addEventListener('resize', () => placePlayer());
  root.addEventListener('toggle', e => {
    const k = e.target.dataset && e.target.dataset.k;
    if (k) { if (e.target.open) state.open.add(k); else state.open.delete(k); }
    placePlayer();
  }, true);
  // A year or a view slides in; the player is measured again once it has landed.
  root.addEventListener('animationend', () => placePlayer());
  if (document.fonts && document.fonts.ready) document.fonts.ready.then(() => placePlayer());

  /* ============================================================ player */

  // The player: play and pause, back 15 s and ahead 30 s, where it is ("12:30 · −1:02:50"), the next
  // recording, and close. Each recording resumes where it was stopped on this device. On a phone it
  // plays from the lock screen (Media Session). A recording that can't play says so, with Retry.
  const player = document.getElementById('ogc-player');
  const audio = new Audio();
  audio.preload = 'none';
  let shown = '';   // the recording the player's controls are built for
  let failed = '';  // the recording that couldn't play
  const POS = 'ogc-pos';
  const positions = () => { try { return JSON.parse(localStorage.getItem(POS)) || {}; } catch (e) { return {}; } };
  function keepPos() {
    if (!state.playing || !audio.duration) return;
    const p = positions(), at = audio.currentTime, left = audio.duration - at;
    if (at < 15 || left < 30) delete p[state.playing]; else p[state.playing] = Math.round(at);
    const ks = Object.keys(p);
    if (ks.length > 60) delete p[ks[0]];
    try { localStorage.setItem(POS, JSON.stringify(p)); } catch (e) { /* not kept */ }
  }
  const hms = s => { s = Math.max(0, Math.round(s || 0)); const h = Math.floor(s / 3600), m = Math.floor(s % 3600 / 60), x = s % 60; return (h ? h + ':' + String(m).padStart(2, '0') : m) + ':' + String(x).padStart(2, '0'); };

  function play(id) {
    if (state.playing === id && failed !== id) { audio.paused ? audio.play().catch(onFail) : audio.pause(); return; }
    // From this page's recordings (the player then works through them), or the player's own Next.
    const here = state.queue.find(x => x.id === id);
    if (here) state.pq = state.queue.slice();
    const a = here || state.pq.find(x => x.id === id);
    if (!a) return;
    keepPos();
    state.playing = id; failed = '';
    audio.src = a.audio;
    const at = positions()[id];
    if (at) audio.addEventListener('loadedmetadata', function once() { audio.removeEventListener('loadedmetadata', once); if (at < audio.duration - 5) audio.currentTime = at; });
    audio.play().catch(onFail);
    media(a);
    syncPlayer();
  }
  function onFail(e) { if (e && e.name === 'AbortError') return; failed = state.playing; shown = ''; syncPlayer(); }
  audio.addEventListener('error', () => { if (state.playing) { failed = state.playing; shown = ''; syncPlayer(); } });

  // The lock screen's title, speaker and picture.
  function media(a) {
    if (!('mediaSession' in navigator)) return;
    try {
      navigator.mediaSession.metadata = new MediaMetadata({ title: a.title, artist: a.by || '', album: 'Annual Conference ' + a.year, artwork: [{ src: PHOTO, sizes: '1200x800', type: 'image/jpeg' }] });
      navigator.mediaSession.setActionHandler('play', () => audio.play());
      navigator.mediaSession.setActionHandler('pause', () => audio.pause());
      navigator.mediaSession.setActionHandler('seekbackward', () => { audio.currentTime = Math.max(0, audio.currentTime - 15); });
      navigator.mediaSession.setActionHandler('seekforward', () => { audio.currentTime = Math.min(audio.duration || 0, audio.currentTime + 30); });
      navigator.mediaSession.setActionHandler('nexttrack', () => { const i = state.pq.findIndex(x => x.id === state.playing); if (state.pq[i + 1]) play(state.pq[i + 1].id); });
    } catch (e) { /* older browsers: the page's own controls */ }
  }

  function stop() { keepPos(); audio.pause(); state.playing = ''; failed = ''; syncPlayer(); }

  // Updates the rings, Play all and the player in place, so the button just pressed keeps the focus.
  function syncPlayer() {
    const going = !audio.paused;
    const all = root.querySelector('[data-act="playall"]');
    if (all) all.innerHTML = playAllInner();
    document.querySelectorAll('button.wk-play').forEach(b => {
      const on = b.dataset.play === state.playing && going, r = b.closest('.wk-rec');
      if (!r) return;
      r.classList.toggle('is-on', on);
      b.innerHTML = on ? I.pause : I.play;
      const a = r.querySelector('a, b');
      b.setAttribute('aria-label', (on ? 'Pause ' : 'Play ') + (a ? a.textContent : ''));
    });
    const a = state.pq.find(x => x.id === state.playing);
    if (!a) {
      const had = player.contains(document.activeElement);
      player.hidden = true; player.innerHTML = ''; shown = '';
      document.body.classList.remove('has-player');
      if (had) { const b = root.querySelector('.wk-btn, .wk-year'); if (b) b.focus({ preventScroll: true }); }
      return;
    }
    if (shown !== a.id) {
      const f = document.activeElement, had = player.contains(f) && f.matches('[data-pa]') ? '[data-pa="' + f.dataset.pa + '"]' : '';
      const nx = state.pq[state.pq.indexOf(a) + 1];
      const bad = failed === a.id;
      player.innerHTML = '<div class="wk-player__in">' +
        '<button type="button" class="wk-player__pp" data-pa="pp"></button>' +
        '<div class="wk-player__txt"><b>' + esc(a.title) + '</b><span class="wk-player__sub"></span>' +
        (bad ? '' : '<input type="range" min="0" max="1000" value="0" aria-label="Position" data-seek>' +
          '<span class="wk-player__times"><span data-el></span><span data-left></span></span>') + '</div>' +
        '<span class="wk-player__skip">' + (bad ? '' : '<button type="button" class="wk-player__btn" data-pa="back" aria-label="Back 15 seconds" title="Back 15 seconds">' + I.back15 + '</button>' +
        '<button type="button" class="wk-player__btn" data-pa="fwd" aria-label="Ahead 30 seconds" title="Ahead 30 seconds">' + I.fwd30 + '</button>') +
        (nx ? '<button type="button" class="wk-player__btn wk-player__next" data-pa="next" data-play="' + esc(nx.id) + '" aria-label="Next: ' + esc(nx.title) + '">' + I.skip + '</button>' : '') + '</span>' +
        '<button type="button" class="wk-player__btn" data-pa="stop" aria-label="Close the player">' + I.close + '</button></div>';
      shown = a.id;
      if (had) { const el = player.querySelector(had) || player.querySelector('[data-pa="pp"]'); el.focus({ preventScroll: true }); }
    }
    const pp = player.querySelector('[data-pa="pp"]');
    const bad = failed === a.id;
    pp.innerHTML = bad ? I.retry : going ? I.pause : I.play;
    pp.setAttribute('aria-label', bad ? 'Retry' : going ? 'Pause' : 'Play');
    // Played from another year's page, the player says which year. Offline, it says so.
    player.querySelector('.wk-player__sub').textContent = bad ? (navigator.onLine === false ? 'Offline' : 'Couldn’t play') + ' · Retry'
      : [a.by, (a.year !== state.year ? a.year + ' ' : '') + a.where].filter(Boolean).join(' · ');
    player.hidden = false;
    document.body.classList.add('has-player');
    times();
    placePlayer();
  }
  function times() {
    const r = player.querySelector('[data-seek]');
    if (!r) return;
    const d = audio.duration, t = audio.currentTime;
    if (d && document.activeElement !== r) r.value = Math.round(t / d * 1000);
    r.setAttribute('aria-valuetext', d ? hms(t) + ' of ' + hms(d) : hms(t));
    const el = player.querySelector('[data-el]'), left = player.querySelector('[data-left]');
    if (el) el.textContent = hms(t);
    if (left) left.textContent = d ? '−' + hms(d - t) : '';
  }
  // From a tablet up the player floats over the page's column, measured from the column itself,
  // without the slide a year change plays, and again when it lands.
  const tabletUp = matchMedia('(min-width: 768px)');
  function placePlayer() {
    const col = root.querySelector('.wk-main .wk-sec') || root.querySelector('.wk-hero__text');
    if (player.hidden || !tabletUp.matches || !col || GUIDE) { player.style.removeProperty('left'); player.style.removeProperty('width'); return; }
    const r = col.getBoundingClientRect(), wk = col.closest('.wk-wrap');
    const shift = wk ? new DOMMatrixReadOnly(getComputedStyle(wk).transform === 'none' ? undefined : getComputedStyle(wk).transform).m41 : 0;
    player.style.left = Math.round(r.left - shift) + 'px';
    player.style.width = Math.round(Math.min(r.width, 720)) + 'px';
  }
  audio.addEventListener('play', syncPlayer);
  audio.addEventListener('pause', () => { keepPos(); syncPlayer(); });
  let lastKeep = 0;
  audio.addEventListener('timeupdate', () => { times(); if (Date.now() - lastKeep > 10000) { lastKeep = Date.now(); keepPos(); } });
  audio.addEventListener('loadedmetadata', times);
  // The next recording is the next one in the list the player came from, whatever year is on screen.
  audio.addEventListener('ended', () => {
    const p = positions(); delete p[state.playing]; try { localStorage.setItem(POS, JSON.stringify(p)); } catch (e) { /* */ }
    const i = state.pq.findIndex(x => x.id === state.playing);
    const nx = i >= 0 ? state.pq[i + 1] : null;
    if (nx) play(nx.id); else stop();
  });
  player.addEventListener('input', e => { if (e.target.matches('[data-seek]') && audio.duration) { audio.currentTime = e.target.value / 1000 * audio.duration; times(); } });
  player.addEventListener('click', e => {
    const b = e.target.closest('[data-pa]');
    if (!b) return;
    const k = b.dataset.pa;
    if (k === 'pp') { if (failed === state.playing) { const id = state.playing; state.playing = ''; play(id); } else audio.paused ? audio.play().catch(onFail) : audio.pause(); }
    else if (k === 'back') audio.currentTime = Math.max(0, audio.currentTime - 15);
    else if (k === 'fwd') audio.currentTime = Math.min(audio.duration || 0, audio.currentTime + 30);
    else if (k === 'stop') stop();
    else if (k === 'next') play(b.dataset.play);
  });
  addEventListener('pagehide', keepPos);

  /* ============================================================ search */

  // One field over the year: every row in every program and day, the places and their codes ("131"),
  // the Help needs, the packet's paragraphs, the menus, and the recordings. It reads what's already
  // here, so it works without signal. After a Conference, recordings from the other years too.
  let otherYears = null;
  // The words people use for what the schedule, Places and Help call otherwise ("dinner" and
  // "bathroom" found nothing). A typed word matches itself, or any of these it stands for. Kept here,
  // in the plugin; each year's own words come from its schedule and packet.
  const SYN = {
    dinner: ['supper'], lunch: ['dinner', 'supper'], food: ['breakfast', 'supper', 'meal', 'menu'], eat: ['breakfast', 'supper', 'meal'],
    showers: ['shower'],
    nurse: ['first aid'], doctor: ['first aid', 'urgent care'], medical: ['first aid', 'urgent care'], sick: ['first aid', 'urgent care'], hurt: ['first aid'], injury: ['first aid'], pharmacy: ['pharmacy', 'urgent care'],
    key: ['lodging'], keys: ['lodging'], checkin: ['check-in', 'lodging'], checkout: ['check-out', 'lodging'], dorm: ['lodging', 'room'],
    wifi: ['wi-fi', 'internet'], internet: ['wi-fi', 'wifi'], parking: ['parking', 'park', 'camper'], car: ['parking', 'ride'],
    ride: ['rides', 'golf cart'], cart: ['golf cart', 'rides'], lost: ['lost and found'],
    church: ['worship', 'service'], services: ['worship'], sermon: ['worship'], preaching: ['worship'], prayer: ['prayer'],
    // Oct 13, from Andrew's guide (his events' words): a whole phrase is one word here.
    'love feast': ['communion'], feetwashing: ['communion'], 'feet washing': ['communion'], pickup: ['pick up']
  };
  const termsOf = w => [w].concat(SYN[w] || SYN[w.replace(/s$/, '')] || []);
  // Words for a restroom find only places marked as one (never the campers' showers): with none on the
  // map yet, "bathroom" says No matches.
  const RESTROOM = /^(bathrooms?|restrooms?|toilets?|washrooms?|lavatory|lavatories)$/;
  // A result's own search words (places.csv and help.csv `search`, a place's features), matched whole:
  // "bathroom" is a word, "bath" isn't. A plural finds its word ("keys" → key).
  // A feature's own words are ogc-core.js's (O.featureWords: "baby" finds a nursery).
  const featureWords = fs => O.featureWords ? O.featureWords(fs) : (fs || []);
  const hasWord = (ws, w) => !!ws && ws.length > 0 && (ws.indexOf(w) > -1 || (w.length > 3 && /s$/.test(w) && ws.indexOf(w.slice(0, -1)) > -1));
  const hitWord = (x, w) => termsOf(w).some(v => x.text.indexOf(v) > -1) || hasWord(x.words, w) || (RESTROOM.test(w) && x.group === 'Places' && x.text.indexOf('restroom') > -1);
  // Why a result matched when the word isn't in what it shows ("Lunch · baby carrots"): the piece of
  // its note, menu or text that has it.
  function whyOf(x, words) {
    const shown = (x.title + ' ' + x.line).toLowerCase();
    for (const w of words) {
      if (termsOf(w).some(v => shown.indexOf(v) > -1)) continue;
      for (const seg of x.segs) {
        const l = seg.toLowerCase(), v = termsOf(w).find(t => l.indexOf(t) > -1);
        if (!v) continue;
        if (seg.length <= 48) return seg;
        // About six words around it, cut at spaces, never inside a word.
        let at = Math.max(0, l.indexOf(v) - 18), to = Math.min(seg.length, l.indexOf(v) + v.length + 26);
        if (at > 0) { const sp = seg.indexOf(' ', at); at = sp > -1 && sp < l.indexOf(v) ? sp + 1 : at; }
        if (to < seg.length) { const sp = seg.lastIndexOf(' ', to); to = sp > l.indexOf(v) + v.length ? sp : to; }
        return (at ? '…' : '') + seg.slice(at, to).trim().replace(/[,.;:]$/, '') + (to < seg.length ? '…' : '');
      }
    }
    return '';
  }
  // One field over the year: every row in every program and day (a row repeated each day is one
  // result), the places and their codes ("131") with what's in them all day, the Help needs, the
  // packet's paragraphs, the menus, and the recordings. It reads what's already here, so it works
  // without signal. After a Conference, recordings from the other years too.
  // in the week, what's on now and later today come first, then the days ahead, and what's
  // over last (dimmed); each row says who it's for ("Young Folks · Fri 10:45 PM").
  function searchIndex(st) {
    // segs: the other words a result is found by (its note, its menu's dishes, a Help line's text).
    const out = [], add = (group, title, line, hit, segs, rank, past, words) => { segs = (segs || []).filter(Boolean).map(String); out.push({ group, title, line, hit, segs, text: (title + ' ' + line + ' ' + segs.join(' ')).toLowerCase(), rank: rank || 0, past: !!past, words: words || [] }); };
    const week = theWeek(st);
    if (schedulePosted() && st.kind !== 'past') {
      const groups = {}, order = [];
      state.model.days.forEach((d, di) => d.items.concat(d.allDay, d.nightly).forEach(it => {
        // One result for a title, however many days and rooms it runs in ("Song, prayer and dismissal").
        const k = O.slug(it.title) + '|' + it.audience;
        if (!groups[k]) { groups[k] = []; order.push(k); }
        groups[k].push({ it, d, di });
      }));
      order.forEach(k => {
        const all = groups[k];
        const stateOf = x => rowState(x.it, x.d, st);
        // The one to open: today's (or on now), else the next to come, else the first.
        const pick = all.find(x => x.d.date === state.now.date && stateOf(x) !== 'past') || all.find(x => x.d.date > state.now.date) || all.find(x => x.d.date === state.now.date) || all[0];
        const it = pick.it, d = pick.d, rs = stateOf(pick);
        const aud = it.audience === 'preteens' ? 'Preteens' : it.audience === 'youngfolks' ? 'Young Folks' : '';
        const t = it.start != null ? zt(d.date, it.start) : it.startText;
        const sameTime = all.every(x => x.it.start === it.start);
        const days = all.length > 1 ? O.fmtDate(all[0].d.date, 'weekdayShort') + '–' + O.fmtDate(all[all.length - 1].d.date, 'weekdayShort') : '';
        // On now (or shut for a service: "Closed · reopens 4:00 PM"), else the day it opens on, with the
        // days it repeats ("Today 4:05 PM · Fri–Tue"; one time for all: "Fri–Tue 7:00 AM").
        const shut = rs === 'now' && week ? closedNow(it, d) : null;
        const dayWord = (week && d.date === state.now.date ? 'Today' : O.fmtDate(d.date, 'weekdayShort')) + (t ? ' ' + t : '');
        const when = shut ? 'Closed · reopens ' + zt(d.date, shut.end) : rs === 'now' && week ? 'Now · until ' + zt(d.date, endOf(it, d))
          : days ? (sameTime ? days + (t ? ' ' + t : '') : dayWord + ' · ' + days)
          : dayWord;
        const p = it.place && !it.place.unknown ? it.place : null;
        const rank = !week ? pick.di * 1440 + it.sort : rs === 'now' ? 0 : d.date === state.now.date && rs !== 'past' ? 1440 + it.sort : rs === 'past' ? 1e7 + pick.di * 1440 + it.sort : 2880 + pick.di * 1440 + it.sort;
        add('Schedule', it.title, [aud, when, p && roomText(p, it.title)].filter(Boolean).join(' · '), 'ev:' + it.id,
          [it.note, p && p.code, p && p.name].concat([].concat.apply([], (it.menu || []).map(m => m.items))), rank, week && rs === 'past' && !all.some(x => stateOf(x) !== 'past'));
      });
    }
    if (st.kind !== 'past') {
      // A place is found by what's in it all day too ("outreach" didn't list its room).
      const inside = {};
      state.model.days.forEach(d => (d.allDay || []).forEach(it => { if (it.place) { const c = it.place.code.toUpperCase(); (inside[c] = inside[c] || []).push(it.title); } }));
      // A room in the one room format ("Room 143 · Barnes"), its full name still found.
      placeGroups().forEach(g => [g.main].concat(g.rooms).forEach(p => add('Places', p === g.main ? p.name : roomText(p, ''), '', 'pl:' + g.key + ':' + p.code, [p.name, g.main.name, p.building, p.code, p.code.split('/').pop()].concat(inside[p.code.toUpperCase()] || []), 0, false, (p.search || []).concat(featureWords(p.features)))));
      helpRows().forEach(h => add('Help', h.need, h.phone || '', 'help:' + O.slug(h.need), [h.text, h.open, h.action], 0, false, h.search));
      const ci = callInHelp();
      if (ci) add('Help', ci.need, ci.phone, 'help:' + O.slug(ci.need), [ci.text], 0, false, ci.search);
      if (postedBy(S().packet_posted)) packetParts().forEach(g => add('Packet', g.title, g.summary || '', 'g:' + g.id, [].concat.apply([], g.paras.map(x => String(x).split(/(?<=[.!?])\s+|\n/)))));
    }
    // Recordings are grouped by their year ("2026", "2025"), each "Ed H. · Sat, June 6 · Romans 12".
    const day = iso => iso ? O.fmtDate(iso, 'weekdayShort') + ', ' + O.fmtDate(iso, 'md') : '';
    state.model.days.forEach(d => d.items.forEach(it => plays(it).forEach(a => add(state.year, a.title, [a.by, day(d.date), refText(a.refs)].filter(Boolean).join(' · '), 'rec:' + recId(a), [it.title]))));
    (otherYears || []).forEach(x => add(x.year, x.title, [x.by, day(x.date), refText(x.refs)].filter(Boolean).join(' · '), 'yr:' + x.year, [x.where]));
    return out;
  }
  function openSearch() {
    const st = status();
    sheetOpener = document.activeElement;
    sheet.innerHTML = '<div class="wk-sheet__in wk-search">' + grabber() + '<button type="button" class="wk-sheet__x" data-close aria-label="Close">' + I.close + '</button>' +
      '<h2 class="wk-sheet__h" id="wk-sheet-t">Search</h2><div class="wk-q"><label class="wk-navpick__q"><span class="ogc-sr">Search</span><input type="search" data-q placeholder="Search" autocomplete="off" enterkeyhint="search"></label>' +
      '<button type="button" class="wk-q__x" data-qx aria-label="Clear" title="Clear" hidden>' + I.close + '</button></div>' +
      '<div class="wk-results" aria-live="polite">' + suggestions(st) + '</div></div>';
    openSheet();
    sheet.querySelector('[data-q]').focus();
    // After a Conference, the other years' recordings are read once, in the background.
    if (st.kind === 'past' && !otherYears) loadOtherYears();
  }
  async function loadOtherYears() {
    otherYears = [];
    for (const r of state.years.filter(y => y.data && y.year !== state.year)) {
      try {
        const m = await O.loadSchedule(BASE + r.data + '/');
        m.days.forEach(d => d.items.forEach(it => (it.attachments || []).filter(a => (a.kind === 'sermon' || a.kind === 'recording') && a.audio).forEach(a => otherYears.push({ year: r.year, title: a.title, by: a.by, refs: a.refs, where: it.title, date: d.date }))));
      } catch (e) { /* that year is left out */ }
    }
    const q = sheet.querySelector('[data-q]');
    if (q && q.value) q.dispatchEvent(new Event('input', { bubbles: true }));
  }
  // Before anything is typed, in the week: a few things people ask for, one tap each (Andrew's guide,
  // Oct 13). One fixed list, in this order; each shows only when it finds something this year: the next
  // meal, a restroom, the nursery, then Help's First aid, Lost and found and Rides.
  function suggestions(st) {
    if (!(theWeek(st) || GUIDE) || st.kind === 'past' || !state.model) return '';
    const all = searchIndex(st), finds = w => all.some(x => hasWord(x.words, w) || w.split(' ').every(v => hitWord(x, v)));
    const days = state.model.days, i = days.findIndex(d => d.date === state.now.date);
    let meal = '';
    for (const d of i > -1 ? days.slice(i, i + 2) : []) {
      const it = d.items.find(x => x.kind === 'meal' && shows(x) && (d.date !== state.now.date || rowState(x, d, st) !== 'past'));
      if (it) { meal = it.title; break; }
    }
    const words = [meal, 'Restroom', 'Nursery', 'First aid', 'Lost and found', 'Rides'].filter(w => w && finds(w.toLowerCase())).slice(0, 5);
    return words.length ? '<div class="wk-suggest" role="group" aria-label="Suggestions">' + words.map(w => '<button type="button" data-suggest="' + esc(w) + '">' + esc(w) + '</button>').join('') + '</div>' : '';
  }
  sheet.addEventListener('click', e => {
    const b = e.target.closest('[data-suggest]');
    if (!b) return;
    const q = sheet.querySelector('[data-q]');
    // The phone's keyboard stays down, so the answer isn't under it.
    q.value = b.dataset.suggest; q.dispatchEvent(new Event('input', { bubbles: true }));
    if (!matchMedia('(pointer: coarse)').matches) q.focus();
  });
  sheet.addEventListener('click', e => {
    if (!e.target.closest('[data-qx]')) return;
    const q = sheet.querySelector('[data-q]');
    q.value = ''; q.dispatchEvent(new Event('input', { bubbles: true })); q.focus();
  });
  sheet.addEventListener('input', e => {
    if (!e.target.matches('[data-q]')) return;
    const x = sheet.querySelector('[data-qx]'); if (x) x.hidden = !e.target.value;
    const t = e.target.value.trim().toLowerCase().replace(/\s+/g, ' '), box = sheet.querySelector('.wk-results');
    if (!t) { box.innerHTML = suggestions(status()); tidy(box); return; }
    const st = status(), words = SYN[t] ? [t] : t.split(' '), all = searchIndex(st);
    const hits = all.filter(x => hasWord(x.words, t) || words.every(w => hitWord(x, w)));
    const groups = [];
    hits.forEach(h => { let g = groups.find(x => x.k === h.group); if (!g) groups.push(g = { k: h.group, l: [] }); g.l.push(h); });
    groups.forEach(g => { g.l = g.l.map((h, i) => [h, i]).sort((a, b) => a[0].rank - b[0].rank || a[1] - b[1]).map(p => p[0]).slice(0, 8); });
    const list = gs => gs.map(g => '<section><h3 class="wk-eyebrow">' + esc(g.k) + '</h3><ul>' + g.l.map(h =>
      { const why = whyOf(h, words), line = [h.line, why].filter(Boolean).join(' · '); return '<li' + (h.past ? ' class="is-past"' : '') + '><button type="button" data-hit="' + esc(h.hit) + '"><b>' + esc(h.title) + '</b>' + (line ? '<small>' + esc(line) + '</small>' : '') + '</button></li>'; }).join('') + '</ul></section>').join('');
    // Nothing found: the first Help rows instead (911 first), not a dead end.
    const help = all.filter(x => x.group === 'Help').slice(0, 3);
    box.innerHTML = groups.length ? list(groups) : '<p class="wk-results__none">No matches</p>' + (help.length ? list([{ k: 'Help', l: help }]) : '');
    tidy(box);
  });
  sheet.addEventListener('keydown', e => { if (e.key === 'Enter' && e.target.matches('[data-q]')) { const b = sheet.querySelector('[data-hit]'); if (b) b.click(); } });
  // A result: its sheet, its building, its Help line, its packet part, or its recording.
  function goHit(h) {
    const [k, a, b] = h.split(':');
    if (k === 'ev') { setTimeout(() => openEvent(h.slice(3)), 0); return; }
    if (k === 'pl') { openPlace(a); return; }
    // The guide: Help, with that need's sheet open over it.
    if (k === 'help' && GUIDE) { setView('help'); setTimeout(() => openHelpSheet(a, root.querySelector('[data-help="' + a + '"]')), 0); return; }
    if (k === 'help') { state.open.add('h-' + a); setView('help'); const el = root.querySelector('[data-hx="h-' + a + '"]'); if (el) { el.scrollIntoView({ block: 'center' }); el.focus({ preventScroll: true }); } return; }
    if (k === 'g') { openPart(a); return; }
    if (k === 'rec') { play(h.slice(4)); return; }
    if (k === 'yr') switchYear(a, true, true);
  }
  // A packet part by its address (#g-lodging): opened, in view.
  function openPart(id) {
    if (GUIDE && state.view !== 'help' && weekViews(status()).indexOf('help') > -1) setView('help');
    const el = document.getElementById('g-' + id);
    if (!el) return false;
    el.open = true; state.open.add('g-' + id);
    el.scrollIntoView({ block: 'start' });
    const s = el.querySelector('summary'); if (s) s.focus({ preventScroll: true });
    return true;
  }

  /* ============================================================ events */

  root.addEventListener('click', e => {
    const t = e.target.closest('[data-play], [data-year], [data-view], [data-day], [data-act], [data-menu], [data-place], [data-aud], [data-ev], [data-hx], [data-open], [data-copy], [data-help], [data-near]');
    if (!t) return;
    if (t.dataset.help) { openHelpSheet(t.dataset.help, t); return; }
    if (t.dataset.near) { openNearSheet(+t.dataset.near, t); return; }
    if (t.dataset.place) { e.preventDefault(); openPlace(t.dataset.place); return; }
    if (t.dataset.ev) { e.preventDefault(); openEvent(t.dataset.ev, t); return; }
    if (t.dataset.aud) { toggleAud(t.dataset.aud); return; }
    if (t.dataset.hx) {
      const k = t.dataset.hx, li = t.closest('.wk-hrow'), on = !state.open.has(k);
      if (on) state.open.add(k); else state.open.delete(k);
      li.querySelector('.wk-hrow__t').setAttribute('aria-expanded', String(on)); li.classList.toggle('is-open', on); li.querySelector('.wk-hrow__body').hidden = !on;
      return;
    }
    if (t.dataset.open) { openPlaceSheet(t.dataset.open, t.dataset.name, t.dataset.line); return; }
    if (t.dataset.copy) { const u = new URL(location.href); u.hash = t.dataset.copy; copyText(u.href, t); return; }
    if (t.dataset.play) { e.preventDefault(); play(t.dataset.play); }
    else if (t.dataset.year) {
      // A year is a link: a click with a modifier (or the middle button) opens it in a new tab.
      if (t.tagName === 'A' && (e.metaKey || e.ctrlKey || e.shiftKey || e.altKey || e.button > 0)) return;
      e.preventDefault();
      const dir = t.classList.contains('wk-arrow--prev') ? 'prev' : t.classList.contains('wk-arrow--next') ? 'next' : '';
      switchYear(t.dataset.year, true, true).then(() => {
        const back = (dir && root.querySelector('.wk-arrow--' + dir + '[data-year]')) || root.querySelector('.wk-year');
        if (back) back.focus({ preventScroll: true });
      });
    }
    else if (t.dataset.view) { e.preventDefault(); if (t.getAttribute('aria-pressed') !== 'true' && !t.hasAttribute('aria-current')) setView(t.dataset.view); }
    else if (t.dataset.day) { if (t.dataset.day !== state.day) { state.day = t.dataset.day; render(true); } }
    else if (t.dataset.act === 'tomorrow') { state.day = t.dataset.dayto; setView('full'); }
    else if (t.dataset.act === 'playall') playAll();
    else if (t.dataset.act === 'search') openSearch();
    else if (t.dataset.act === 'changes') openChanges();
    else if (t.dataset.act === 'retry') refresh(true);
    else if (t.dataset.act === 'install') install();
    else if (t.dataset.act === 'install-off') { try { localStorage.setItem(A2HS, '1'); } catch (x) { /* */ } render(true); }
    else if (t.hasAttribute('data-menu')) toggleYears(e.detail === 0);
  });
  // Add to Home Screen: Android and Chrome ask themselves; an iPhone needs its two steps shown.
  function install() {
    if (installEvt) { installEvt.prompt(); installEvt.userChoice.then(() => { installEvt = null; render(true); }); return; }
    sheetOpener = document.activeElement;
    sheet.innerHTML = '<div class="wk-sheet__in">' + grabber() + '<button type="button" class="wk-sheet__x" data-close aria-label="Close">' + I.close + '</button>' +
      '<h2 class="wk-sheet__h" id="wk-sheet-t">Add to Home Screen</h2><ol class="wk-steps">' +
      '<li><span class="wk-steps__i">' + I.shareios + '</span><span>Tap <b>Share</b> at the bottom of Safari</span></li>' +
      '<li><span class="wk-steps__i">' + I.addsq + '</span><span>Tap <b>Add to Home Screen</b></span></li></ol>' +
      '<p class="wk-sheet__note">The guide then opens from its own icon, and works offline.</p></div>';
    openSheet();
  }
  // The year list: opened from the year, closed by a click elsewhere or Escape (focus back on the year).
  function toggleYears(fromKeys) {
    const list = document.getElementById('wk-years'), btn = root.querySelector('[data-menu]');
    if (!list) return;
    const open = list.hidden;
    list.hidden = !open;
    btn.setAttribute('aria-expanded', String(open));
    if (open && fromKeys) { const first = list.querySelector('button, a'); if (first) first.focus(); }
  }
  function closeYears(refocus) {
    const list = document.getElementById('wk-years');
    if (!list || list.hidden) return false;
    list.hidden = true;
    const btn = root.querySelector('[data-menu]');
    btn.setAttribute('aria-expanded', 'false');
    if (refocus) btn.focus();
    return true;
  }
  document.addEventListener('click', e => {
    if (!(e.target.closest && e.target.closest('.wk-yr'))) closeYears(false);
  });
  // Tabbing out of the list closes it, so it never covers the control that has the focus.
  root.addEventListener('focusout', e => {
    const yr = e.target.closest && e.target.closest('.wk-yr');
    if (yr && !(e.relatedTarget && yr.contains(e.relatedTarget))) closeYears(false);
  });

  // The ← / → keys turn the year only while the year (or its arrows) has the focus: a stray key press
  // elsewhere never swaps the page for another year (Luke: no surprise changes). A year that has only
  // its own old page is not opened from a key; it is said instead.
  function step(dir) {
    const ys = known(), i = ys.findIndex(y => y.year === state.year), r = ys[i + (dir < 0 ? 1 : -1)];
    if (opens(r)) switchYear(r.year, true, true).then(() => {
      const y = root.querySelector('.wk-year');
      if (y) y.focus({ preventScroll: true });
    });
    else if (r && r.page) say.textContent = r.year + ' · On its own page';
  }
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape' && closeYears(true)) { e.preventDefault(); return; }
    if (e.altKey || e.ctrlKey || e.metaKey || e.shiftKey) return;
    if (e.key !== 'ArrowLeft' && e.key !== 'ArrowRight') return;
    const t = e.target;
    if (!(t && t.closest && t.closest('.wk-yrline'))) return;
    e.preventDefault();
    step(e.key === 'ArrowLeft' ? -1 : 1);
  });
  // A sideways swipe on the year (beside its visible ‹ › buttons) turns it too.
  let touch = null;
  root.addEventListener('touchstart', e => {
    const p = e.touches[0];
    touch = e.touches.length === 1 && e.target.closest('.wk-yrline') && p.clientX > 24 && p.clientX < innerWidth - 24 ? { x: p.clientX, y: p.clientY, t: Date.now() } : null;
  }, { passive: true });
  root.addEventListener('touchend', e => {
    if (!touch) return;
    const p = e.changedTouches[0], dx = p.clientX - touch.x, dy = p.clientY - touch.y;
    if (Math.abs(dx) > 80 && Math.abs(dy) < 40 && Date.now() - touch.t < 600) step(dx > 0 ? -1 : 1);
    touch = null;
  }, { passive: true });

  function setView(v) {
    state.view = VIEWS.indexOf(v) > -1 ? v : '';
    const u = new URL(location.href);
    const vs = weekViews(status());
    if (v && v !== vs[0]) u.searchParams.set('view', v); else u.searchParams.delete('view');
    u.hash = '';
    history.pushState(null, '', u);
    state.enter = 'fade';
    if (state.view === 'places' || GUIDE) campusSoon();
    render(true);
    if (document.documentElement.classList.contains('ogc-app')) scrollTo(0, 0);
    const st = status(), shown = viewFor(st);
    say.textContent = viewLabel(shown, st);
  }
  // Back and Forward: the view, and the year if it differs, said out loud as they change.
  addEventListener('popstate', () => {
    const p = new URLSearchParams(location.search);
    state.view = viewParam(p);
    if (!state.model) return;
    const y = p.get('year');
    const view = () => { const st = status(); say.textContent = (viewLabel(viewFor(st), st) || '') + ', Annual Conference ' + state.year; };
    if (y && y !== state.year && open_(y)) switchYear(y, true).then(view);
    else { render(true); view(); }
  });

  // A year opens only once it has been announced (years.csv `announced`), from a link or the address too.
  const open_ = y => known().some(r => r.year === String(y) && opens(r));

  // The signed-in person's own records for the year on screen, and nobody else's (every
  // visitor's browser fetched two years of the public's names with the page). The guide's Your shifts
  // reads their sign-ups; the program chips their registration.
  const mine = {};
  const mineOf = k => (mine[state.year + ':' + k] || []).map(x => x.data || {});
  function loadMine(y) {
    if (!WP.me || !WP.api || !/^\d{4}$/.test(String(y))) return Promise.resolve();
    const kinds = GUIDE ? ['registrations', 'signups'] : ['registrations'];
    return Promise.all(kinds.filter(k => !mine[y + ':' + k]).map(k => WP.api('GET', 'years/' + y + '/records/' + k + '?scope=mine')
      .then(l => { mine[y + ':' + k] = Array.isArray(l) ? l.filter(x => x && x.mine) : []; }, () => { mine[y + ':' + k] = []; })));
  }

  // The year's files that aren't in its schedule: the change marks, and the volunteer shifts (for
  // "Your shifts" in the guide).
  async function loadExtras(r) {
    const get = n => fetch(BASE + r.data + '/' + n + '.csv', { cache: 'no-store' }).then(x => x.ok ? x.text() : '').catch(() => '');
    const [ct, st, tt] = await Promise.all([get('changes'), GUIDE ? get('shifts') : Promise.resolve(''), GUIDE ? get('tournaments') : Promise.resolve('')]);
    state.changes = O.csvToObjects(ct).filter(c => c.what);
    // The guide's tournament sheets: each tournament's sign-up window (tournaments.csv), by its schedule row.
    state.tournaments = O.csvToObjects(tt).filter(t => t.id && t.schedule_title && !/^#/.test(t.id));
    state.shifts = GUIDE && O.signups && st ? O.signups.expandShifts(O.csvToObjects(st), state.model) : null;
  }
  // The campus map is read when it's needed (Places, Directions, the guide), not before the page draws.
  let campusFor = '';
  // (The map area: it answers with the load, so a sheet opened before the map can wait for it.)
  function campusSoon() {
    const r = yearRow(state.year);
    if (!r || !r.data || campusFor === state.year) return state.campusP || Promise.resolve();
    campusFor = state.year;
    state.campusP = loadCampus(state.year, BASE + r.data + '/').then(() => { if (state.model && campusFor === state.year) render(true); }).catch(() => {});
    return state.campusP;
  }

  // push: a year the reader chose (an arrow, the list, a key, a swipe) is its own Back step.
  function switchYear(y, moved, push) {
    const r = yearRow(y);
    if (!r || !open_(y)) return Promise.resolve();
    if (moved && state.year) state.enter = +y > +state.year ? 'next' : 'prev';
    if (y !== state.year) { state.open.clear(); campusFor = ''; state.campus = null; state.mapEl = state.map = null; }
    state.year = y; state.day = '';
    const done = () => {
      const u = new URL(location.href);
      u.searchParams.set('year', y);
      if (state.view && viewFor(status()) !== state.view) { state.view = ''; u.searchParams.delete('view'); }
      if (push && u.href !== location.href) history.pushState(null, '', u); else history.replaceState(null, '', u);
      render();
      if (moved) {
        // Back to the title only if it has scrolled away.
        if (root.getBoundingClientRect().top < 0) root.scrollIntoView({ block: 'start' });
        say.textContent = 'Annual Conference ' + y + (span(y) ? ', ' + span(y) : '') + (r.venue && r.start ? ', ' + r.venue : '');
      }
    };
    if (isStub(r)) { state.model = { days: [], settings: {}, places: {}, guides: {}, milestones: [], notices: [], help: [], nearby: [], problems: [] }; state.changes = []; done(); return Promise.resolve(); }
    return O.loadSchedule(BASE + r.data + '/').then(m => {
      state.model = m; state.sig = signature(m); fresh();
      if (m.problems.length) console.warn(y + ' data problems:\n' + m.problems.join('\n'));
      state.now = previewOf(r) || O.wallNow(venueTZ());
      return Promise.all([loadExtras(r), loadMine(y)]).then(householdPrograms);
    }).then(() => {
      done();
      if (GUIDE || hasPlaces(status())) campusSoon();
    });
  }
  // A copy just read: fresh from the server, unless the guide's worker said it answered from its kept copy.
  let cachedMsg = 0;
  function fresh() { state.failed = Date.now() - cachedMsg < 5000; if (!state.failed) state.synced = Date.now(); }
  // What the year says, compactly, to tell whether a fresh copy changed anything.
  const signature = m => JSON.stringify([m.days.map(d => d.items.map(it => [it.id, it.start, it.end, it.title, it.place && it.place.code])), m.notices, m.help, Object.keys(m.guides).length, m.settings.revised, m.settings.call_in_number]);

  /* ============================================================= boot */

  function go(asOf, reset) {
    state.now = O.parseAsOf(asOf) || O.wallNow(TZ);
    const u = new URL(location.href);
    if (asOf) u.searchParams.set('as-of', asOf); else u.searchParams.delete('as-of');
    if (reset) { u.searchParams.delete('year'); u.searchParams.delete('view'); }
    history.replaceState(null, '', u);
    state.view = viewParam(u.searchParams);
    audio.pause(); state.playing = ''; state.pq = []; state.open.clear();
    const asked = !reset && q.get('year');
    state.featured = GUIDE ? guideYear(state.now) : featuredYear(state.now);
    const y = asked && open_(asked) ? asked : state.featured;
    state.year = '';
    return switchYear(y).then(() => { keepOffline(); arrive(); });
  }
  // From another page (a shift's map, the packet, a tournament): ?to=CODE opens Places on that place, its
  // card up with Directions, once. ?event=<id> opens that event's sheet; #g-<part> opens that packet part.
  function arrive() {
    const p = new URLSearchParams(location.search);
    const to = p.get('to'), ev = p.get('event');
    if (to) {
      const u = new URL(location.href); u.searchParams.delete('to'); history.replaceState(null, '', u);
      const pl = state.model.places[to.toUpperCase()] || state.model.places[to.split('/')[0].toUpperCase()];
      if (pl && hasPlaces(status())) openPlace(pl.code);
    }
    if (ev && sheets(status())) openEvent(ev, null);
    if (/^#g-/.test(location.hash)) setTimeout(() => openPart(decodeURIComponent(location.hash.slice(3))), 0);
  }
  // Keeping the time right: every minute on the minute (and the moment the phone shows the page again,
  // after midnight too), the page is drawn again where it was, without moving the scroll or the focus.
  // During the week (and when the page comes back after five minutes) the year is read again; when
  // something changed, it's redrawn in place with "Updated 8:15 AM".
  let tickT = 0;
  function tick() {
    clearTimeout(tickT);
    tickT = setTimeout(() => { advance(); tick(); }, 60000 - Date.now() % 60000 + 30);
  }
  function advance() {
    if (!state.model || previewOf(yearRow(state.year)) || document.hidden) return;
    const n = O.wallNow(venueTZ());
    if (n.date === state.now.date && n.minutes === state.now.minutes) return;
    state.now = n;
    // Never while someone is typing in a field on the page.
    const f = document.activeElement;
    if (f && root.contains(f) && /^(INPUT|TEXTAREA|SELECT)$/.test(f.tagName)) return;
    const y = scrollY;
    render(true);
    if (Math.abs(scrollY - y) > 1) scrollTo(0, y);
    const st = status();
    if ((theWeek(st) || nearWeek(st)) && Date.now() - state.synced > 5 * 60000) refresh(false);
  }
  async function refresh(loud) {
    const r = yearRow(state.year);
    if (!r || !r.data) return;
    try {
      const m = await O.loadSchedule(BASE + r.data + '/');
      if (!m.days.length) throw new Error('empty');
      const sig = signature(m), changed = sig !== state.sig;
      state.model = m; state.sig = sig; fresh();
      await loadExtras(r);
      if (changed || loud) { render(true); if (changed) say.textContent = 'Updated'; }
    } catch (e) {
      state.failed = true;
      if (loud || GUIDE) render(true);
    }
  }
  addEventListener('visibilitychange', () => { if (!document.hidden) { advance(); tick(); } });
  addEventListener('pageshow', e => { if (e.persisted) { advance(); tick(); } });

  // Offline for the week: the guide's service worker (guide/sw.js) keeps the guide's page, its files
  // and the public year (never anything personal). It's told what to keep for this year as soon as
  // the year is drawn, the page and the year first and the files after (it waited for load
  // and 1.5 s, and a short first visit kept nothing), so every tab works offline after the first
  // visit; once it's all kept, Help says "Saved for offline". (The Conference page itself isn't kept.)
  const SAVED = 'ogc-guide-saved';
  let swReg = null, keptFor = '';
  const sent = new Set();
  // again: a second pass once the page has loaded, for the files that came after the first (the fonts).
  function keepOffline(again) {
    if (!swReg || !swReg.active || !state.model || (keptFor === state.year && !again)) return;
    keptFor = state.year;
    const rest = WP.rest || '/wp-json/ogc/v1/';
    const first = [location.pathname + location.search, rest + 'years', rest + 'years/' + state.year + '/bundle'];
    const man = document.querySelector('link[rel="manifest"]');
    const files = performance.getEntriesByType('resource').map(e => e.name).filter(u => /\/assets\/|fonts\.(googleapis|gstatic)\.com|(use|p)\.typekit\.net/.test(u))
      .concat(Array.from(document.querySelectorAll('script[src], link[rel="stylesheet"][href], link[rel="apple-touch-icon"]')).map(e => e.src || e.href))
      .concat(man ? [man.href] : []);
    // Signed out since the last visit on this phone: what was kept goes first.
    let was = '';
    try { was = localStorage.getItem('ogc-guide-me') || ''; localStorage.setItem('ogc-guide-me', WP.me ? '1' : ''); } catch (e) { /* */ }
    if (was && !WP.me) swReg.active.postMessage({ clear: true });
    const fresh = Array.from(new Set(files)).filter(u => !sent.has(u));
    if (again && !fresh.length) return;
    fresh.forEach(u => sent.add(u));
    swReg.active.postMessage({ first, keep: fresh, year: state.year });
  }
  addEventListener('load', () => setTimeout(() => keepOffline(true), 2000));
  const savedFor = () => { try { const v = JSON.parse(localStorage.getItem(SAVED) || 'null'); return v && v.year === state.year ? v : null; } catch (e) { return null; } };
  if (GUIDE && 'serviceWorker' in navigator && location.protocol !== 'file:') {
    navigator.serviceWorker.register('sw.js').then(() => navigator.serviceWorker.ready).then(reg => { swReg = reg; keepOffline(); })
      .catch(() => { /* the page works the same without it */ });
    // The worker answered with its kept copy (offline, or one bar): say how old it is; a fresh copy
    // that arrives later is drawn in place.
    navigator.serviceWorker.addEventListener('message', e => {
      const d = e.data || {};
      // The page itself came from the kept copy: offline only if the network doesn't answer now (a
      // request the worker lets through), since a slow page isn't a lost signal.
      if (d.ogc === 'cached' && d.page) {
        fetch(WP.rest || '/wp-json/', { method: 'HEAD', cache: 'no-store', credentials: 'omit' }).then(() => {}, () => {
          cachedMsg = Date.now(); state.failed = true; if (d.at) state.synced = d.at; if (state.model) render(true);
        });
      } else if (d.ogc === 'cached') { cachedMsg = Date.now(); state.failed = true; if (d.at) state.synced = d.at; if (state.model) render(true); }
      // The network answered after all (it was only slow): read again and take the Offline line down.
      else if (d.ogc === 'fresh' && state.failed) { cachedMsg = 0; refresh(true); }
      // Everything this year needs is on the phone.
      else if (d.ogc === 'kept' && d.year) { try { localStorage.setItem(SAVED, JSON.stringify({ year: d.year, at: d.at })); } catch (x) { /* */ } if (state.model && state.year === d.year) render(true); }
    });
    navigator.serviceWorker.startMessages();
  }
  addEventListener('online', () => { if (state.model) { state.failed = false; refresh(true); } });
  phoneQ.addEventListener('change', () => { if (state.model) render(true); });
  addEventListener('offline', () => { if (state.model) render(true); });

  // Couldn't load at all: said plainly in the site's look, with Retry (the details go to the console).
  function failed_(err) {
    console.error(err);
    root.innerHTML = '<div class="wk"><section class="wk-hero"><div class="wk-wrap"><p class="wk-kicker">Annual Conference</p>' +
      '<h1 class="wk-apph">Schedule unavailable</h1><p class="wk-action"><button type="button" class="wk-btn" data-boot>Retry</button></p></div></section></div>';
    root.classList.add('is-drawn');
    const b = root.querySelector('[data-boot]');
    if (b) b.addEventListener('click', boot);
  }
  function boot() {
    (O.ready || Promise.resolve()).then(() => fetch(BASE + 'years.csv', { cache: 'no-store' })).then(r => { if (!r.ok) throw new Error('years.csv ' + r.status); return r.text(); }).then(t => {
      state.years = (O.edits ? O.edits.mergeYears : x => x)(O.csvToObjects(t)).filter(y => y.year).sort((a, b) => b.year - a.year);
      if (!state.years.length) throw new Error('No years');
      return go(qp('as-of'), false);
    }).then(tick).catch(failed_);
  }
  boot();
})();
