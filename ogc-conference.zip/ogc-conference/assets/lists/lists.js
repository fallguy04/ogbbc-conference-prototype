/*
 * lists.js — the year's lists, for the COA and the committees that work from them (lists area).
 *
 *   ?view=meals       how many to cook for at each meal, by the caterer's age bands; what changed since
 *                     the last count sent; Send to caterer (or Export and Mark as sent)
 *   ?view=communion   how many will commune (the households under a fold)
 *   ?view=preteens    the preteen check-in list (the preteen committee's people only)
 *   ?view=payments    checks to come, refunds, balances, what's come in (the treasurer's people only)
 *   ?view=callin      the call-in line: what's live, and the playback numbers (given once, kept)
 *
 * Every list is worked out on the server (includes/module-lists.php) and comes as one answer: this page
 * never holds the year's households. Print and Download are the list as it stands, dated.
 */
(function () {
  'use strict';
  const O = window.OGC, esc = O.esc, W = window.OGC_WP || {};
  const root = document.getElementById('ogc-lists');
  const q = new URLSearchParams(location.search);
  const ASOF = q.get('as-of') || '';
  const VIEWS = [['meals', 'Meals'], ['communion', 'Communion'], ['preteens', 'Preteens'], ['payments', 'Payments'], ['callin', 'Call-in']];
  const TITLES = { meals: 'Meal counts', communion: 'Communion', preteens: 'Preteens', payments: 'Payments', callin: 'Call-in line' };
  const remembered = (() => { try { return localStorage.getItem('ogc-lists-view') || ''; } catch (e) { return ''; } })();
  const yearOf = () => q.get('year') || String((W.member || []).slice().sort().pop() || new Date().getFullYear());
  const state = { year: yearOf(), view: q.get('view') || remembered || 'meals', data: null, head: null, open: {}, find: '', filter: 'all', busy: false, access: null, panel: '' };
  if (!VIEWS.some(v => v[0] === state.view)) state.view = 'meals';

  const svg = d => '<svg class="wk-i" viewBox="0 0 24 24" aria-hidden="true"><path d="' + d + '" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  const I = {
    back: svg('M14.5 5.5 8 12l6.5 6.5'),
    print: svg('M7 9V4h10v5M7 17H5a1.5 1.5 0 0 1-1.5-1.5v-5A1.5 1.5 0 0 1 5 9h14a1.5 1.5 0 0 1 1.5 1.5v5A1.5 1.5 0 0 1 19 17h-2M7 14h10v6H7z'),
    down: svg('M12 4v10.5M7.5 10 12 14.5 16.5 10M5 19.5h14'),
    send: svg('M4 12 20 4l-4 16-4-7-8-1Z'),
    lock: svg('M7 11V8a5 5 0 0 1 10 0v3M5.5 11h13v9h-13z'),
    check: svg('m5.5 12.5 4 4 9-9'),
    chev: svg('m6 9 6 6 6-6'),
    phone: svg('M6.5 3.5h3l1.5 4-2 1.5a11 11 0 0 0 6 6l1.5-2 4 1.5v3A2 2 0 0 1 18.5 20 15.5 15.5 0 0 1 4.5 5.5a2 2 0 0 1 2-2Z'),
    find: svg('M10.5 17a6.5 6.5 0 1 0 0-13 6.5 6.5 0 0 0 0 13ZM15.5 15.5 20 20'),
    copy: svg('M8.5 8.5h10v11h-10zM5.5 15.5v-11h10')
  };

  /* ---------------------------------------------------------------- talking to the server */

  const api = (method, path, body) => W.api(method, path, body);
  const withAsOf = path => ASOF ? path + (path.indexOf('?') > -1 ? '&' : '?') + 'as_of=' + encodeURIComponent(ASOF) : path;
  const live = document.createElement('p');
  live.className = 'ogc-sr';
  live.setAttribute('aria-live', 'polite');
  root.after(live);
  const say = t => { live.textContent = ''; setTimeout(() => { live.textContent = t; }, 30); };

  // A file from the server (made there: cell-safe, dated, the list exactly as it stands).
  async function download(view, extra) {
    const res = await fetch((W.rest || '/wp-json/ogc/v1/') + withAsOf('lists/' + state.year + '/' + view + '?format=csv' + (extra || '')), { credentials: 'same-origin', headers: { 'X-WP-Nonce': W.nonce || '' } });
    if (!res.ok) throw Object.assign(new Error('Download failed'), { status: res.status });
    const blob = await res.blob(), cd = res.headers.get('Content-Disposition') || '', m = /filename="([^"]+)"/.exec(cd);
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = m ? m[1] : view + '-' + state.year + '.csv';
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 4000);
  }

  /* ---------------------------------------------------------------- words */

  const plural = (n, one, many) => n.toLocaleString('en-US') + ' ' + (n === 1 ? one : (many || one + 's'));
  const money = c => '$' + (c / 100).toLocaleString('en-US', { minimumFractionDigits: c % 100 ? 2 : 0, maximumFractionDigits: 2 });
  const md = iso => iso ? O.fmtDate(iso, 'mdShort') : '';
  const dayShort = iso => O.fmtDate(iso, 'short');
  const signed = n => n > 0 ? '+' + n : n < 0 ? '−' + Math.abs(n) : '0';
  const tz = () => (state.head && state.head.tz) || 'America/Indiana/Indianapolis';
  // A server time (UTC "2026-10-10 14:15:00") as the campus reads it: "Thu 4:10 PM" this week, else "Oct 3, 4:10 PM".
  function at(utc) {
    if (!utc) return '';
    const d = new Date(String(utc).replace(' ', 'T') + 'Z'), w = O.wallNow(tz(), d);
    const days = state.head ? O.daysBetween(w.date, state.head.today) : 99;
    return (days >= 0 && days < 6 ? O.fmtDate(w.date, 'weekdayShort') : md(w.date)) + ' ' + O.formatTime(w.minutes);
  }
  const nowWords = () => { const n = state.head && state.head.now; return n ? O.fmtDate(n.date, 'short') + ', ' + O.formatTime(n.min) : ''; };
  const tag = (t, cls) => '<span class="lst-tag' + (cls ? ' lst-tag--' + cls : '') + '">' + esc(t) + '</span>';
  const btn = (label, attrs, cls) => '<button type="button" class="' + (cls || 'lst-quiet') + '" ' + attrs + '>' + label + '</button>';
  const blank = (h, p, more) => '<section class="ws-blank lst-blank"><p class="ws-blank__h">' + esc(h) + '</p>' + (p ? '<p class="ws-blank__p">' + p + '</p>' : '') + (more || '') + '</section>';
  const telOf = p => { const d = String(p || '').replace(/[^\d+]/g, ''); return d ? 'tel:' + (d.length === 10 ? '+1' + d : d) : ''; };
  const tel = p => p ? (telOf(p) ? '<a class="lst-tel" href="' + esc(telOf(p)) + '">' + esc(p) + '</a>' : esc(p)) : '';
  const yearUrl = part => W.url('../year/?year=' + encodeURIComponent(state.year) + (part ? '&part=' + part : ''));
  const ownerWord = part => (state.head && state.head.owners && state.head.owners[part]) || '';

  /* ---------------------------------------------------------------- the frame */

  // Back goes where the person came from (a part's "Made from it" sends from=), else the year.
  function backTo() {
    const f = q.get('from') || '';
    const base = W.base || '/annual-conference/';
    if (f && f.indexOf(base) === 0 && f.indexOf('//') < 0 && !/[<>"']/.test(f)) return { href: f, label: /part=registration/.test(f) ? 'Registration' : /part=schedule|s=schedule/.test(f) ? 'Schedule' : /lodging/.test(f) ? 'Lodging' : state.year + ' Annual Conference' };
    return { href: yearUrl(''), label: state.year + ' Annual Conference' };
  }
  function frame() {
    const b = backTo();
    root.innerHTML = '<div class="wk ws lst">' +
      '<header class="ws-bar ws-bar--page"><div class="ws-bar__in">' +
        '<a class="ws-back" href="' + esc(b.href) + '">' + I.back + '<span>' + esc(b.label) + '</span></a>' +
        '<div class="ws-title"><p class="wk-kicker" id="lst-kicker">' + esc(state.year) + ' Annual Conference</p><h1 tabindex="-1">Lists</h1></div>' +
      '</div></header>' +
      '<div class="ws-body ws-body--page lst-body">' +
        '<div id="lst-banner"></div>' +
        '<nav class="lst-tabs" aria-label="Lists" id="lst-tabs">' + tabs() + '</nav>' +
        '<div id="lst-view" class="lst-view" aria-busy="true">' + skeleton() + '</div>' +
        '<p class="lst-more" id="lst-more"></p>' +
      '</div></div>';
  }
  function tabs() {
    const has = state.head ? state.head.has : null;
    // The other lists are the committees' screens in the app now (their addresses go there): only the
    // call-in list is kept here, so it has no tabs to nowhere.
    return VIEWS.filter(v => v[0] === 'callin' && (!has || has[v[0]] || v[0] === state.view)).map(v => {
      const href = '?' + new URLSearchParams(Object.assign({ year: state.year, view: v[0] }, q.get('from') ? { from: q.get('from') } : {}, ASOF ? { 'as-of': ASOF } : {})).toString();
      return '<a href="' + esc(href) + '" data-view="' + v[0] + '"' + (v[0] === state.view ? ' aria-current="page"' : '') + '>' + v[1] + '</a>';
    }).join('');
  }
  function skeleton() {
    return '<div class="lst-skel" aria-hidden="true"><span class="lst-skel__line lst-skel__line--w"></span>' + Array.from({ length: 7 }, () => '<span class="lst-skel__row"></span>').join('') + '</div><p class="ogc-sr">Loading</p>';
  }
  // The links that were here (rooms, who's signed up, teams) lead into the app now: none is drawn.
  function more() {
    document.getElementById('lst-more').innerHTML = '';
  }

  function banner() {
    const h = state.head, el = document.getElementById('lst-banner');
    if (!h) { el.innerHTML = ''; return; }
    const bits = [];
    if (h.samples) bits.push('<p class="lst-banner"><b>Sample data</b><span>Made-up households</span>' + (h.webmaster ? btn('Clear samples', 'data-clear-samples') : '') + '</p>');
    el.innerHTML = bits.join('');
    document.getElementById('lst-kicker').textContent = state.year + ' Annual Conference' + (h.cleared ? ' · Counts only' : h.held ? ' · Held' : '');
  }

  /* ---------------------------------------------------------------- loading a list */

  async function load(view, keepFocus) {
    state.view = view;
    try { localStorage.setItem('ogc-lists-view', view); } catch (e) { /* not kept */ }
    const el = document.getElementById('lst-view');
    if (!keepFocus) { el.setAttribute('aria-busy', 'true'); el.innerHTML = skeleton(); }
    document.getElementById('lst-tabs').innerHTML = tabs();
    document.title = (VIEWS.find(v => v[0] === view) || VIEWS[0])[1] + ' – Lists – ' + state.year + ' Annual Conference';
    try {
      const out = await api('GET', withAsOf('lists/' + state.year + '/' + view));
      if (state.view !== view) return;
      state.head = out.head; state.data = out.list || null; state.record = out.record || null;
      banner();
      document.getElementById('lst-tabs').innerHTML = tabs();
      draw();
    } catch (err) {
      failed(err);
    }
  }
  function failed(err) {
    const el = document.getElementById('lst-view');
    el.removeAttribute('aria-busy');
    if (err.status === 401) {
      const to = (window.OGC_AUTH && OGC_AUTH.signinUrl()) || W.signin || '../signin/';
      el.innerHTML = blank('Signed out', 'Members only', '<p class="ws-blank__btn"><a class="wk-btn" href="' + esc(to) + '">Email me a link</a></p>');
    } else if (err.status === 403) {
      el.innerHTML = blank('Not a member for ' + state.year, '');
    } else {
      el.innerHTML = blank('Couldn’t load', '', '<p class="ws-blank__btn"><button type="button" class="wk-btn wk-btn--line" data-retry>Retry</button></p>');
    }
    console.error(err);
  }

  /* ---------------------------------------------------------------- drawing */

  function draw() {
    const el = document.getElementById('lst-view');
    el.removeAttribute('aria-busy');
    const h = state.head;
    let html;
    if (!h.set_up) html = blank('Registration not set up', '', '<p class="ws-blank__btn"><a class="wk-btn wk-btn--line" href="' + esc(yearUrl('registration')) + '">Set up registration</a></p>');
    else if (state.record) html = recordView();
    else html = ({ meals: mealsView, communion: communionView, preteens: preteensView, payments: paymentsView, callin: callinView })[state.view]();
    el.innerHTML = html + printHead();
    pageStyle();
  }

  // Before the first registration, a registration-made list says when it opens; never a table of zeros.
  function noneYet() {
    const h = state.head;
    if (h.regs) return '';
    if (h.phase === 'before' && h.opens) return blank('Registration opens ' + md(h.opens), '');
    if (h.phase === 'none') return blank('Registration not open', '', '<p class="ws-blank__btn"><a class="wk-btn wk-btn--line" href="' + esc(yearUrl('registration')) + '">Registration</a></p>');
    return blank('No registrations', '');
  }

  function tools(view, extra) {
    return '<p class="lst-tools">' + (extra || '') + btn(I.print + 'Print', 'data-print="' + view + '"') + btn(I.down + 'Download', 'data-csv="' + view + '"') + '</p>';
  }
  function status(parts) {
    return '<p class="lst-status">' + parts.filter(Boolean).join('<span class="lst-dot" aria-hidden="true"> · </span>') + '</p>';
  }
  function findBox(label) {
    return '<label class="lst-find">' + I.find + '<span class="ogc-sr">' + esc(label) + '</span><input type="search" data-find placeholder="' + esc(label) + '" value="' + esc(state.find) + '" autocomplete="off"><kbd aria-hidden="true">/</kbd></label>';
  }
  const hit = text => !state.find || String(text).toLowerCase().indexOf(state.find.toLowerCase()) > -1;

  // The printed page's own header and footer ("2027 Annual Conference · Meal counts", "As of …", pages).
  function printHead() {
    const t = TITLES[state.view], d = state.data || {};
    const lines = { meals: d.busiest ? plural(d.busiest.total, 'person', 'people') + ' at the busiest meal' : '', communion: d.total != null ? plural(d.total, 'communing', 'communing') : '', preteens: d.count != null ? plural(d.count, 'preteen') : '', callin: d.rows ? plural(d.rows.length, 'row') : '', payments: '' };
    return '<div class="lst-print-head" aria-hidden="true"><p>' + esc(state.year + ' Annual Conference · ' + t) + '</p><p>As of ' + esc(nowWords()) + (lines[state.view] ? ' · ' + esc(lines[state.view]) : '') + '</p></div>';
  }
  function pageStyle(medical) {
    let s = document.getElementById('lst-page');
    if (!s) { s = document.createElement('style'); s.id = 'lst-page'; document.head.appendChild(s); }
    const left = (state.year + ' Annual Conference · ' + TITLES[state.view] + ' · As of ' + nowWords()).replace(/["\\\n]/g, '');
    const conf = medical ? 'Confidential · Shred after Conference · ' : '';
    s.textContent = '@page { @bottom-left { content: "' + conf + left + '"; font: 8pt Arial, sans-serif; color: #555; } @bottom-right { content: "Page " counter(page) " of " counter(pages); font: 8pt Arial, sans-serif; color: #555; } }';
  }

  /* ---------------------------------------------------------------- Meals */

  function mealsView() {
    const d = state.data, h = state.head, set = d.settings, none = noneYet();
    if (!d.meals.length) return blank('No meals in the schedule', '', '<p class="ws-blank__btn"><a class="wk-btn wk-btn--line" href="' + esc(yearUrl('schedule')) + '">Edit schedule</a></p>');
    if (none) return none;
    const sent = d.sent, due = set.counts_due, left = due ? O.daysBetween(h.today, due) : null;
    const st = [];
    if (d.busiest) st.push('<b>' + d.busiest.total.toLocaleString('en-US') + '</b> at most');
    if (sent) st.push((sent.final ? 'Final sent ' : 'Sent ') + esc(md(sent.day)) + (sent.by ? ' by ' + esc(sent.by) : ''));
    if (sent) st.push(d.changed ? '<b class="lst-warn">' + plural(d.changed, 'meal') + ' changed</b>, ' + esc(signed(d.net)) + ' in all' : 'No changes');
    if (due && !h.held) st.push(left > 0 ? 'Counts due ' + esc(md(due)) + ' · ' + plural(left, 'day') : left === 0 ? '<b>Counts due today</b>' : 'Counts were due ' + esc(md(due)));
    // One filled action, only while the Conference is ahead.
    let act = '';
    if (!h.held) {
      act = set.caterer_email ? '<button type="button" class="wk-btn wk-btn--small" data-send-open>' + I.send + 'Send to caterer</button>' + btn(I.down + 'Download', 'data-csv="meals"')
        : '<button type="button" class="wk-btn wk-btn--small" data-export>' + I.down + 'Export</button>' + btn('Mark as sent', 'data-send-open="mark"');
      act += btn(I.print + 'Print', 'data-print="meals"') + btn('Caterer', 'data-panel="caterer" aria-expanded="' + (state.panel === 'caterer') + '"');
    } else act = btn(I.print + 'Print', 'data-print="meals"') + btn(I.down + 'Download', 'data-csv="meals"');
    const undo = sent && sent.undo ? btn('Undo', 'data-send-undo') : '';
    return status(st) + '<p class="lst-tools">' + act + undo + '</p>' + mealsPanel() + mealsTable() + mealsHelp() + snacksTable();
  }

  function mealsPanel() {
    const d = state.data, set = d.settings;
    if (state.panel === 'caterer') {
      return '<form class="lst-panel" data-form="caterer"><h2 class="lst-h3">Caterer</h2>' +
        '<label class="lst-field"><span>Email</span><input type="email" name="caterer_email" value="' + esc(set.caterer_email) + '" placeholder="orders@caterer.example" autocomplete="off"><small>Members only · Never shown to households</small></label>' +
        '<label class="lst-field"><span>Counts due</span><input type="date" name="counts_due" value="' + esc(set.counts_due) + '"><small>' + (set.suggest_due ? 'Two weeks before is ' + esc(md(set.suggest_due)) : '') + '</small></label>' +
        (d.communion ? '<fieldset class="lst-field"><legend>Supper on communion day</legend><span class="lst-pills">' +
          [['all', 'Everyone'], ['skip', 'Not those communing']].map(o => '<label class="lst-pill"><input type="radio" name="communion_supper" value="' + o[0] + '"' + (set.communion_supper === o[0] ? ' checked' : '') + '><span>' + o[1] + '</span></label>').join('') + '</span><small>Those communing eat the communion meal · Ask Food and Communion</small></fieldset>' : '') +
        '<p class="lst-panel__btns"><button type="submit" class="wk-btn wk-btn--small">Save</button>' + btn('Cancel', 'data-panel=""') + '</p><p class="lst-err" role="alert" hidden></p></form>';
    }
    if (state.panel === 'send' || state.panel === 'mark') {
      const mark = state.panel === 'mark';
      return '<form class="lst-panel" data-form="send"><h2 class="lst-h3">' + (mark ? 'Mark as sent' : 'Send to caterer') + '</h2>' +
        '<dl class="lst-facts">' + (mark ? '' : '<dt>To</dt><dd>' + esc(d.settings.caterer_email) + '</dd><dt>Copy</dt><dd>You</dd>') +
        '<dt>Meals</dt><dd>' + plural(d.meals.filter(m => m.status !== 'removed').length, 'meal') + ' · ' + plural(d.week, 'plate') + '</dd>' +
        (d.sent ? '<dt>Since ' + esc(md(d.sent.day)) + '</dt><dd>' + (d.changed ? plural(d.changed, 'change') + ', ' + esc(signed(d.net)) : 'No changes') + '</dd>' : '') + '</dl>' +
        '<label class="lst-check"><input type="checkbox" name="final"> Final count</label>' +
        '<p class="lst-panel__btns"><button type="submit" class="wk-btn wk-btn--small">' + (mark ? 'Mark as sent' : I.send + 'Send') + '</button>' + btn('Cancel', 'data-panel=""') + '</p><p class="lst-err" role="alert" hidden></p></form>';
    }
    return '';
  }

  function mealsTable() {
    const d = state.data, sent = d.sent, communing = (d.meals.find(m => m.from === 'communion') || {}).total || 0;
    let prev = '';
    const rows = d.meals.map(m => {
      let out = '';
      if (m.date !== prev) { out += '<tr class="lst-day"><th colspan="' + (sent ? 6 : 5) + '" scope="rowgroup">' + esc(dayShort(m.date)) + '</th></tr>'; prev = m.date; }
      const gone = m.status === 'removed', open = state.open[m.key];
      const cell = k => {
        const was = m.was && m.was[k] !== m.counts[k] ? '<span class="ogc-sr"> (was ' + m.was[k] + ')</span>' : '';
        return '<td class="is-num">' + (gone ? '' : m.counts[k].toLocaleString('en-US')) + was + '</td>';
      };
      const notes = [];
      if (m.status === 'new') notes.push(tag('New'));
      if (gone) notes.push(tag('Removed · was ' + (m.was.adult + m.was.child + m.was.baby), 'alert'));
      if (m.notime) notes.push('<a class="lst-tag lst-tag--alert" href="' + esc(yearUrl('schedule')) + '">No time · Edit</a>');
      if (m.after_final) notes.push(tag('After final', 'alert'));
      if (m.from === 'communion') notes.push('<small>Those communing</small>');
      if (state.data.communion && m.date === state.data.communion.date && /^supper/i.test(m.title) && d.settings.communion_supper !== 'skip' && communing) notes.push('<small>Includes ' + communing + ' communing</small>');
      const chg = m.change != null ? m.change : m.status === 'new' ? m.total : 0;
      const why = sent && m.why && m.why.length;
      out += '<tr class="lst-meal' + (m.served ? ' is-served' : '') + (gone ? ' is-gone' : '') + '">' +
        '<th scope="row"><span class="lst-meal__t">' + esc(m.title) + '</span><span class="lst-meal__w">' + esc(m.when) + '</span>' + (notes.length ? '<span class="lst-meal__n">' + notes.join(' ') + '</span>' : '') + '</th>' +
        cell('adult') + cell('child') + cell('baby') +
        '<td class="is-num is-total">' + (gone ? '0' : m.total.toLocaleString('en-US')) + (m.est ? '<abbr class="lst-est" title="Includes ' + m.est + ' arriving or leaving that day">est.</abbr>' : '') + '</td>' +
        (sent ? '<td class="is-num lst-chg">' + (chg ? (why ? '<button type="button" class="lst-chgb' + (chg > 0 ? ' is-up' : ' is-down') + '" data-why="' + esc(m.key) + '" aria-expanded="' + !!open + '">' + esc(signed(chg)) + '<span class="ogc-sr"> since ' + esc(md(sent.day)) + ', show households</span></button>' : '<b class="' + (chg > 0 ? 'is-up' : 'is-down') + '">' + esc(signed(chg)) + '</b>') : '') + '</td>' : '') + '</tr>';
      if (open && why) {
        out += '<tr class="lst-why"><td colspan="' + (sent ? 6 : 5) + '"><ul>' + m.why.map(w => '<li><b>' + esc(w.label) + '</b><span>' + esc(w.what) + '</span><span class="is-num">' + esc(signed(w.now - w.was)) + '</span></li>').join('') + '</ul></td></tr>';
      }
      return out;
    }).join('');
    return '<div class="lst-scroll"><table class="lst-table lst-meals"><caption class="ogc-sr">Meal counts, ' + esc(state.year) + '</caption><thead><tr><th scope="col">Meal</th><th scope="col" class="is-num"><span class="lst-long">12 and up</span><abbr class="lst-short" title="12 and up">12+</abbr></th><th scope="col" class="is-num">3–11</th><th scope="col" class="is-num"><span class="lst-long">Under 3</span><abbr class="lst-short" title="Under 3">&lt;3</abbr></th><th scope="col" class="is-num">Total</th>' + (sent ? '<th scope="col" class="is-num"><span class="lst-long">Change</span><abbr class="lst-short" title="Change">+/−</abbr></th>' : '') + '</tr></thead><tbody>' + rows + '</tbody>' +
      '<tfoot><tr><th scope="row">Week</th><td colspan="3"></td><td class="is-num is-total">' + d.week.toLocaleString('en-US') + '</td>' + (sent ? '<td></td>' : '') + '</tr></tfoot></table></div>';
  }
  function mealsHelp() {
    const d = state.data, any = d.meals.some(m => m.est);
    return '<ul class="lst-help">' +
      '<li>12 and up includes Young Folks</li>' +
      '<li>Everyone registered · ' + plural(d.households, 'household') + ', ' + plural(d.people, 'person', 'people') + (d.elsewhere ? ' · ' + d.elsewhere + ' staying off campus' : '') + '</li>' +
      (any ? '<li><b>est.</b> Includes people arriving or leaving that day · The form doesn’t ask their first and last meal</li>' : '') +
      (d.sent ? '<li>Change: since ' + esc(md(d.sent.day)) + ' · Tap a change for the households</li>' : '') + '</ul>';
  }
  function snacksTable() {
    const s = state.data.snacks;
    if (!s || !s.length) return '';
    const who = { preteens: 'Preteens', youngfolks: 'Young Folks', all: 'Everyone' };
    return '<h2 class="lst-h2">Snacks</h2><div class="lst-scroll"><table class="lst-table lst-snacks"><caption class="ogc-sr">Snacks, ' + esc(state.year) + '</caption><thead><tr><th scope="col">Snack</th><th scope="col">For</th><th scope="col" class="is-num">Here that day</th></tr></thead><tbody>' +
      s.map(x => '<tr><th scope="row"><span class="lst-meal__t">' + esc(x.title) + '</span><span class="lst-meal__w">' + esc(dayShort(x.date) + (x.when ? ' · ' + x.when : '')) + '</span></th><td>' + esc(who[x.aud]) + '</td><td class="is-num is-total">' + x.count + '</td></tr>').join('') + '</tbody></table></div>';
  }

  /* ---------------------------------------------------------------- Communion */

  function communionView() {
    const d = state.data, none = noneYet();
    if (none) return none;
    if (!d.total) return blank('No one communing', 'From ' + plural(state.head.regs, 'household'));
    const rows = d.households.filter(r => hit(r.label + ' ' + r.rid));
    return '<div class="lst-figure"><p class="lst-big"><b>' + d.total.toLocaleString('en-US') + '</b> communing</p>' +
      '<p class="lst-sub">' + plural(d.households.length, 'household') + (d.date ? ' · ' + esc(dayShort(d.date)) : '') + (d.away ? ' · ' + d.away + ' not here that day' : '') + '</p></div>' +
      changesLine('communion') + tools('communion') +
      '<details class="lst-fold"' + (state.open.hh ? ' open' : '') + ' data-fold="hh"><summary><span>Households · ' + d.households.length + '</span>' + I.chev + '</summary>' + findBox('Find a household') +
      '<table class="lst-table lst-hh"><caption class="ogc-sr">Communion by household, ' + esc(state.year) + '</caption><thead><tr><th scope="col">Household</th><th scope="col">Registration</th><th scope="col" class="is-num">Communing</th></tr></thead><tbody>' +
      (rows.length ? rows.map(r => '<tr><th scope="row">' + esc(r.label) + (r.new ? ' ' + tag('New') : r.changed ? ' ' + tag('Changed', 'blue') : '') + '</th><td>' + esc(r.rid) + '</td><td class="is-num">' + r.n + '</td></tr>').join('') : '<tr><td colspan="3" class="lst-none">No match</td></tr>') + '</tbody></table></details>';
  }
  // "3 changes since printed Thu 4:10 PM" · "New · 6 · Mark all seen"
  function changesLine(view) {
    const d = state.data, bits = [];
    if (d.printed && d.changed) bits.push('<b>' + plural(d.changed, 'change') + '</b> since printed ' + esc(at(d.printed.at)));
    if (d.new) bits.push(tag('New') + ' ' + d.new + btn('Mark all seen', 'data-seen="' + view + '"'));
    return bits.length ? '<p class="lst-since">' + bits.join('<span aria-hidden="true"> · </span>') + '</p>' : '';
  }

  /* ---------------------------------------------------------------- Preteens */

  function preteensView() {
    const d = state.data, h = state.head, none = noneYet();
    if (none) return none;
    if (!d.count) return blank('No preteens registered', '');
    if (!d.viewer) {
      return status(['<b>' + plural(d.count, 'preteen') + '</b>', I.lock + 'Preteen committee only']) +
        (h.choose ? '<p class="lst-tools">' + btn('Choose who', 'data-access="preteens"') + '</p>' + accessPanel('preteens') : '');
    }
    const rows = d.rows.filter(r => hit(r.name + ' ' + r.household + ' ' + r.pickup));
    const withDays = d.rows.some(r => r.days), withMed = !d.paper && d.rows.some(r => r.medical), withCon = !d.paper && d.rows.some(r => r.contacts.length);
    const st = ['<b>' + plural(d.count, 'preteen') + '</b>'];
    if (d.paper) st.push('Medical notes and contacts on paper');
    const prints = btn(I.print + 'Print sheet', 'data-print="preteens"') + (withMed || withCon ? btn(I.print + 'Print medical', 'data-print="medical"') : '') + btn(I.down + 'Download', 'data-csv="preteens"') + (h.choose ? btn('Access', 'data-access="preteens"') : '');
    return status(st) + changesLine('preteens') + '<p class="lst-tools">' + prints + '</p>' + accessPanel('preteens') +
      '<div class="lst-sticky">' + findBox('Find a preteen') + '</div>' +
      '<div class="lst-scroll"><table class="lst-table lst-pt' + (withMed || withCon ? ' has-med' : '') + '"><caption class="ogc-sr">Preteens, ' + esc(state.year) + '</caption><thead><tr><th scope="col">Preteen</th>' + (withDays ? '<th scope="col">Days</th>' : '') + '<th scope="col">May pick up</th><th scope="col">Parent phone</th>' + (withMed ? '<th scope="col" class="lst-med">Medical notes</th>' : '') + (withCon ? '<th scope="col" class="lst-med">Emergency contacts</th>' : '') +
      ((d.days.length ? d.days : ['Fri', 'Sat', 'Sun']).map(x => '<th scope="col" class="lst-sign">' + esc(String(x).slice(0, 3)) + ' in / out</th>').join('')) + '</tr></thead><tbody>' +
      (rows.length ? rows.map(r => '<tr><th scope="row"><span class="lst-meal__t">' + esc(r.name) + '</span>' + (r.age ? '<span class="lst-meal__w">' + esc(r.age) + '</span>' : '') + (r.new ? ' ' + tag('New') : r.changed ? ' ' + tag('Changed', 'blue') : '') + '</th>' +
        (withDays ? '<td>' + esc(r.days || 'All') + '</td>' : '') +
        '<td>' + esc(r.pickup) + '</td><td>' + tel(r.phone) + '</td>' +
        (withMed ? '<td class="lst-med">' + esc(r.medical) + '</td>' : '') +
        (withCon ? '<td class="lst-med"><ul class="lst-contacts">' + r.contacts.map(c => '<li>' + esc(c.name) + (c.rel ? ' · ' + esc(c.rel) : '') + ' ' + tel(c.phone) + '</li>').join('') + '</ul></td>' : '') +
        (d.days.length ? d.days : ['Fri', 'Sat', 'Sun']).map(() => '<td class="lst-sign"></td>').join('') + '</tr>').join('')
        : '<tr><td colspan="9" class="lst-none">No match</td></tr>') + '</tbody></table></div>';
  }

  /* ---------------------------------------------------------------- who sees Preteens and Payments */

  function accessPanel(list) {
    if (state.panel !== 'access:' + list) return '';
    const a = state.access;
    if (!a) return '<div class="lst-panel"><p>Loading</p></div>';
    const chosen = new Set(a.lists[list].map(x => x.email));
    const what = list === 'preteens' ? 'Names, medical notes and emergency contacts' : 'Who owes, checks, refunds';
    return '<form class="lst-panel" data-form="access" data-list="' + list + '"><h2 class="lst-h3">Who sees ' + (list === 'preteens' ? 'Preteens' : 'Payments') + '</h2><p class="lst-panel__p">' + esc(what) + ' · Everyone else sees the count</p>' +
      (a.members.length ? '<ul class="lst-people">' + a.members.map(m => '<li><label class="lst-check"><input type="checkbox" name="emails" value="' + esc(m.email) + '"' + (chosen.has(m.email) ? ' checked' : '') + '><span><b>' + esc(m.name || m.email) + '</b><small>' + esc([m.role === 'coa' ? 'COA' : 'Helper', m.helps, m.name ? m.email : ''].filter(Boolean).join(' · ')) + '</small></span></label></li>').join('') + '</ul>'
        : '<p class="lst-panel__p">No members yet</p>') +
      '<p class="lst-panel__btns"><button type="submit" class="wk-btn wk-btn--small">Save</button>' + btn('Cancel', 'data-panel=""') + '</p><p class="lst-err" role="alert" hidden></p></form>';
  }

  /* ---------------------------------------------------------------- Payments */

  function paymentsView() {
    const d = state.data, h = state.head;
    if (!d.viewer) {
      return status(['<b>' + plural(d.households, 'household') + '</b>', I.lock + 'Treasurer only']) +
        (h.choose ? '<p class="lst-tools">' + btn('Choose who', 'data-access="payments"') + '</p>' + accessPanel('payments') : '');
    }
    if (d.none) return blank('Payments not set up', '');
    const t = d.totals, today = h.today;
    const st = ['<b>' + plural(t.paid_n, 'household') + ' paid</b> · ' + money(t.paid)];
    if (d.checks.length) st.push(plural(d.checks.length, 'check') + ' due ' + money(t.check));
    if (d.refunds.length) st.push('<b class="lst-warn">' + plural(d.refunds.length, 'refund') + ' ' + money(t.refund) + '</b>');
    if (d.due.length) st.push(plural(d.due.length, 'balance') + ' due ' + money(t.due));
    const dates = [];
    if (d.refunds_by) dates.push(today <= d.refunds_by ? 'Refund requests until ' + md(d.refunds_by) : 'Refund requests closed ' + md(d.refunds_by));
    if (d.check_by && d.checks.length) dates.push(today <= d.check_by ? 'Checks by ' + md(d.check_by) : 'Checks were due ' + md(d.check_by));
    const secs = [['checks', 'Checks due', d.checks.length], ['refunds', 'Refunds', d.refunds.length], ['due', 'Balance due', d.due.length], ['done', 'Received', d.done.length]].filter(s => s[2]);
    const pills = secs.length > 1 ? '<div class="lst-filter" role="group" aria-label="Show">' + [['all', 'All', 0]].concat(secs).map(s => '<button type="button" data-filter="' + s[0] + '" aria-pressed="' + (state.filter === s[0]) + '">' + s[1] + (s[2] ? ' <span>' + s[2] + '</span>' : '') + '</button>').join('') + '</div>' : '';
    const show = k => state.filter === 'all' || state.filter === k;
    let html = status(st) + (dates.length ? '<p class="lst-since">' + esc(dates.join(' · ')) + '</p>' : '') +
      '<p class="lst-tools">' + btn(I.print + 'Print', 'data-print="payments"') + btn(I.down + 'Download', 'data-csv="payments"') + (h.choose ? btn('Access', 'data-access="payments"') : '') + '</p>' + accessPanel('payments') +
      pills + '<div class="lst-sticky">' + findBox('Find a household or ID') + '</div>';
    if (!secs.length) html += blank('Nothing to collect', '');
    if (d.checks.length && show('checks')) html += paySection('Checks due', ['Household', 'Registration', 'Amount', 'Waiting', ''], d.checks.filter(r => hit(r.label + ' ' + r.rid)).map(r => payRow(r, [
      '<td>' + idCell(r.rid) + '</td>', '<td class="is-num"><b>' + money(r.cents) + '</b></td>',
      '<td>' + (r.waiting > 0 ? plural(r.waiting, 'day') : 'Today') + (r.late ? ' ' + tag('Overdue', 'alert') : '') + '</td>',
      '<td class="lst-acts">' + (d.can.checks ? btn('Received', 'data-pay-open="received:' + r.payment + '"') + (d.can.remind && r.email ? btn('Remind', 'data-remind="' + r.payment + '"') : '') : '') + '</td>'], 'received:' + r.payment, r)));
    if (d.refunds.length && show('refunds')) html += paySection('Refunds', ['Household', 'Registration', 'Amount', 'Asked', ''], d.refunds.filter(r => hit(r.label + ' ' + r.rid)).map(r => payRow(r, [
      '<td>' + idCell(r.rid) + '</td>', '<td class="is-num"><b>' + money(r.cents) + '</b></td>',
      '<td>' + esc(md(r.asked)) + (r.late ? ' ' + tag('Late', 'alert') : '') + '<small class="lst-cellnote">' + esc([r.note, r.method === 'card' ? 'Paid by card' : 'Paid by check'].filter(Boolean).join(' · ')) + '</small></td>',
      '<td class="lst-acts">' + (d.can.refund ? btn('Refunded', 'data-pay-open="refunded:' + r.payment + '"') + btn('Decline', 'data-pay-open="declined:' + r.payment + '"') : '') + '</td>'], 'refunded:' + r.payment, r) + payRow(r, null, 'declined:' + r.payment, r)));
    if (d.due.length && show('due')) html += paySection('Balance due', ['Household', 'Registration', 'Due', 'Paid', ''], d.due.filter(r => hit(r.label + ' ' + r.rid)).map(r => payRow(r, [
      '<td>' + idCell(r.rid) + '</td>', '<td class="is-num"><b>' + money(r.cents) + '</b></td>', '<td class="is-num">' + money(r.paid) + ' of ' + money(r.total) + '</td>',
      '<td class="lst-acts">' + (d.can.checks ? btn('Add payment', 'data-pay-open="desk:' + r.record + '"') : '') + '</td>'], 'desk:' + r.record, r)));
    if (d.done.length && show('done')) {
      const rows = d.done.filter(r => hit(r.label + ' ' + r.rid));
      const inner = '<table class="lst-table lst-pay"><caption class="ogc-sr">Received, ' + esc(state.year) + '</caption><thead><tr><th scope="col">Household</th><th scope="col">What</th><th scope="col" class="is-num">Amount</th><th scope="col">When</th><th scope="col"></th></tr></thead><tbody>' +
        rows.map(r => '<tr><th scope="row">' + esc(r.label) + '<small class="lst-cellnote">' + esc(r.rid) + '</small></th><td>' + esc(doneWhat(r)) + (r.ref ? '<small class="lst-cellnote">' + esc(r.ref) + '</small>' : '') + '</td><td class="is-num">' + (r.kind === 'refund' ? '−' : '') + money(r.cents) + '</td><td>' + esc(md(r.day)) + (r.by ? '<small class="lst-cellnote">' + esc(r.by) + '</small>' : '') + '</td><td class="lst-acts">' + (r.mark ? btn('Undo', 'data-pay-undo="' + esc(r.mark) + '"') : '') + '</td></tr>').join('') + '</tbody></table>';
      html += state.filter === 'done' ? '<h2 class="lst-h2">Received · ' + rows.length + '</h2>' + inner : '<details class="lst-fold" data-fold="done"' + (state.open.done ? ' open' : '') + '><summary><span>Received · ' + rows.length + '</span>' + I.chev + '</summary>' + inner + '</details>';
    }
    if (t.gifts) html += '<p class="lst-gifts"><b>Gifts</b> ' + money(t.gifts) + ' · ' + plural(t.gifts_n, 'household') + (d.gift_for && d.gift_for !== 'none' ? ' · For ' + esc(d.gift_for) : '') + '</p>';
    return html;
  }
  const doneWhat = r => r.kind === 'refund' ? (r.status === 'sent' ? 'Refunded' : 'Refund declined') : r.kind === 'desk' ? 'At the desk · ' + (r.method === 'check' ? 'Check' : 'Cash') : r.status === 'cancelled' ? 'Undone' : 'Check';
  const idCell = rid => rid ? '<button type="button" class="lst-id" data-copy="' + esc(rid) + '" title="Copy">' + esc(rid) + '<span class="ogc-sr"> · Copy</span></button>' : '';
  function paySection(title, cols, rows) {
    return '<h2 class="lst-h2">' + esc(title) + ' · ' + rows.length + '</h2><div class="lst-scroll"><table class="lst-table lst-pay"><caption class="ogc-sr">' + esc(title) + ', ' + esc(state.year) + '</caption><thead><tr>' + cols.map((c, i) => '<th scope="col"' + (i === 2 ? ' class="is-num"' : '') + '>' + esc(c) + '</th>').join('') + '</tr></thead><tbody>' + (rows.join('') || '<tr><td colspan="5" class="lst-none">No match</td></tr>') + '</tbody></table></div>';
  }
  // A row, and under it (when opened) its small form: the amount, the check number, the date.
  function payRow(r, cells, key, rec) {
    let out = '';
    if (cells) out += '<tr data-row="' + esc(key) + '"><th scope="row">' + esc(r.label) + (r.sample ? '' : '') + '</th>' + cells.join('') + '</tr>';
    if (state.panel !== 'pay:' + key) return out;
    const [act] = key.split(':');
    const today = state.head.today;
    const f = act === 'received' ? '<label class="lst-field lst-field--s"><span>Amount</span><input name="amount" inputmode="decimal" value="' + (rec.cents / 100).toFixed(2) + '" required></label><label class="lst-field lst-field--s"><span>Check no.</span><input name="ref" inputmode="numeric" autocomplete="off"></label><label class="lst-field lst-field--s"><span>Received</span><input type="date" name="date" value="' + today + '" max="' + today + '"></label>'
      : act === 'refunded' ? '<label class="lst-field lst-field--s"><span>' + (rec.method === 'card' ? 'Card refund ID' : 'Check no.') + '</span><input name="ref" autocomplete="off"></label><label class="lst-field lst-field--s"><span>Refunded</span><input type="date" name="date" value="' + today + '" max="' + today + '"></label>'
      : act === 'declined' ? '<p class="lst-panel__p">Decline ' + money(rec.cents) + ' for ' + esc(rec.label) + '?</p>'
      : '<label class="lst-field lst-field--s"><span>Amount</span><input name="amount" inputmode="decimal" value="' + (rec.cents / 100).toFixed(2) + '" required></label><fieldset class="lst-field lst-field--s"><legend>Paid by</legend><span class="lst-pills"><label class="lst-pill"><input type="radio" name="method" value="cash" checked><span>Cash</span></label><label class="lst-pill"><input type="radio" name="method" value="check"><span>Check</span></label></span></fieldset><label class="lst-field lst-field--s"><span>Check no.</span><input name="ref" autocomplete="off"></label>';
    const word = { received: 'Save', refunded: 'Save', declined: 'Decline', desk: 'Save' }[act];
    return out + '<tr class="lst-formrow"><td colspan="5"><form class="lst-inline" data-form="pay" data-key="' + esc(key) + '">' + f + '<p class="lst-panel__btns"><button type="submit" class="wk-btn wk-btn--small' + (act === 'declined' ? ' wk-btn--alert' : '') + '">' + word + '</button>' + btn('Cancel', 'data-panel=""') + '</p><p class="lst-err" role="alert" hidden></p></form></td></tr>';
  }

  /* ---------------------------------------------------------------- Call-in */

  function callinView() {
    const d = state.data;
    if (!d.rows.length) return blank('No rows on the call-in line', '', '<p class="ws-blank__btn"><a class="wk-btn wk-btn--line" href="' + esc(yearUrl('schedule')) + '">Edit schedule</a></p>');
    const showLive = d.rows.some(r => !r.live) || d.rows.some(r => !r.recorded);
    const st = ['<b>' + plural(d.rows.filter(r => r.live).length, 'service') + '</b> on the line'];
    if (d.number) st.push(esc(d.number) + (d.pin ? ' · PIN ' + esc(d.pin) : ''));
    if (d.zone) st.push(esc(d.zone));
    if (!d.posted) st.push(tag('Draft · Not published', 'blue'));
    let prev = '';
    const rows = d.rows.map(r => {
      let out = '';
      if (r.date !== prev) { out += '<tr class="lst-day"><th colspan="' + (showLive ? 4 : 3) + '" scope="rowgroup">' + esc(dayShort(r.date)) + '</th></tr>'; prev = r.date; }
      return out + '<tr><th scope="row"><span class="lst-meal__t">' + esc(r.title) + '</span><span class="lst-meal__w">' + esc(r.when) + '</span></th><td>' + esc(r.where) + '</td>' +
        (showLive ? '<td>' + (r.live ? I.check + '<span class="ogc-sr">Live</span>' : '<span class="lst-muted">Not live</span>') + '</td>' : '') +
        '<td class="lst-pb">' + (r.playback ? '<b>' + esc(r.playback) + '</b>' + (r.new ? ' ' + tag('New since printed') : '') : r.recorded ? tag('No number', 'alert') : '<span class="lst-muted">Not recorded</span>') + '</td></tr>';
    }).join('');
    return status(st) + tools('callin') + (d.printed ? '<p class="lst-since">Printed ' + esc(at(d.printed.at)) + (d.printed.by ? ' by ' + esc(d.printed.by) : '') + '</p>' : '') +
      '<div class="lst-scroll"><table class="lst-table lst-call"><caption class="ogc-sr">Call-in line, ' + esc(state.year) + '</caption><thead><tr><th scope="col">What</th><th scope="col">Where</th>' + (showLive ? '<th scope="col">Live</th>' : '') + '<th scope="col">Playback</th></tr></thead><tbody>' + rows + '</tbody></table></div>' +
      '<ul class="lst-help"><li>Playback numbers: the date and a number, given once and kept · A row added later gets the next number</li>' + (d.split ? '' : '<li>Every row on the line is counted as recorded · Mark Recorded on the schedule to tell them apart</li>') + '</ul>';
  }

  /* ---------------------------------------------------------------- a year whose people are cleared */

  function recordView() {
    const r = state.record || {}, h = state.head;
    if (!r.households) return blank('No registrations on the site', '');
    const head = status(['<b>Counts only</b>', 'Cleared ' + esc(md(h.cleared))]) +
      '<p class="lst-since">Phones, medical notes, emergency contacts and teams were erased ' + esc(md(h.cleared)) + ' · Household names stay for next year’s Reuse until the Advisors decide</p>';
    if (state.view === 'meals') {
      if (!r.meals || !r.meals.length) return head + blank('No meals kept', '');
      let prev = '';
      return head + '<p class="lst-tools">' + btn(I.print + 'Print', 'data-print="meals"') + btn(I.down + 'Download', 'data-csv="meals"') + '</p>' +
        '<div class="lst-scroll"><table class="lst-table lst-meals"><caption class="ogc-sr">Meal counts, ' + esc(state.year) + '</caption><thead><tr><th scope="col">Meal</th><th scope="col" class="is-num"><span class="lst-long">12 and up</span><abbr class="lst-short" title="12 and up">12+</abbr></th><th scope="col" class="is-num">3–11</th><th scope="col" class="is-num"><span class="lst-long">Under 3</span><abbr class="lst-short" title="Under 3">&lt;3</abbr></th><th scope="col" class="is-num">Total</th></tr></thead><tbody>' +
        r.meals.map(m => { let o = ''; if (m.date !== prev) { o += '<tr class="lst-day"><th colspan="5" scope="rowgroup">' + esc(dayShort(m.date)) + '</th></tr>'; prev = m.date; } return o + '<tr><th scope="row"><span class="lst-meal__t">' + esc(m.title) + '</span><span class="lst-meal__w">' + esc(m.when) + '</span></th><td class="is-num">' + m.counts.adult + '</td><td class="is-num">' + m.counts.child + '</td><td class="is-num">' + m.counts.baby + '</td><td class="is-num is-total">' + m.total + '</td></tr>'; }).join('') +
        '</tbody></table></div>' + (r.sent ? '<p class="lst-since">' + (r.sent.final ? 'Final sent ' : 'Last sent ') + esc(md(r.sent.day)) + (r.sent.by ? ' by ' + esc(r.sent.by) : '') + '</p>' : '');
    }
    if (state.view === 'communion') return head + '<div class="lst-figure"><p class="lst-big"><b>' + (r.communion || 0) + '</b> communing</p><p class="lst-sub">' + plural(r.households || 0, 'household') + '</p></div>';
    if (state.view === 'preteens') return head + '<div class="lst-figure"><p class="lst-big"><b>' + (r.preteens || 0) + '</b> preteens</p></div>';
    if (state.view === 'payments') {
      if (!r.money) return head + status([I.lock + 'Treasurer only']);
      const m = r.money, g = k => m[k] || 0;
      const lines = [['Card', g('charge:paid')], ['Checks', g('check:paid')], ['At the desk', g('desk:paid')], ['Refunded', -g('refund:sent')]].filter(x => x[1]);
      return head + '<table class="lst-table lst-tot"><caption class="ogc-sr">Payments, ' + esc(state.year) + '</caption><tbody>' + lines.map(x => '<tr><th scope="row">' + esc(x[0]) + '</th><td class="is-num">' + (x[1] < 0 ? '−' : '') + money(Math.abs(x[1])) + '</td></tr>').join('') +
        '<tr class="is-total"><th scope="row">In all</th><td class="is-num">' + money(lines.reduce((k, x) => k + x[1], 0)) + '</td></tr></tbody></table>';
    }
    return head;
  }

  /* ---------------------------------------------------------------- doing things */

  function toast(text, undo) {
    let t = document.getElementById('lst-toast');
    if (t) t.remove();
    t = document.createElement('div');
    t.id = 'lst-toast';
    t.className = 'lst-toast';
    t.setAttribute('role', 'status');
    t.innerHTML = '<span>' + esc(text) + '</span>' + (undo ? '<button type="button" data-toast-undo="' + esc(undo) + '">Undo</button>' : '');
    document.body.appendChild(t);
    requestAnimationFrame(() => t.classList.add('is-on'));
    clearTimeout(toast.timer);
    toast.timer = setTimeout(() => { t.classList.remove('is-on'); setTimeout(() => t.remove(), 300); }, undo ? 8000 : 3500);
    if (undo) t.querySelector('button').focus();
  }
  function formError(form, err) {
    const p = form.querySelector('.lst-err');
    if (p) { p.hidden = false; p.textContent = err.message || 'Not saved · Retry'; }
    const field = err.data && err.data.data && err.data.data.field;
    const input = field && form.querySelector('[name="' + field + '"], [name="' + (field === 'cents' ? 'amount' : field) + '"]');
    if (input) { input.setAttribute('aria-invalid', 'true'); input.focus(); }
  }
  // Redraw the list after a change, keeping the reader where they were.
  async function refresh(focusSel) {
    const y = scrollY;
    await load(state.view, true);
    scrollTo(0, y);
    const f = focusSel && document.querySelector(focusSel);
    if (f) f.focus({ preventScroll: true });
  }
  const busy = (form, on) => form.querySelectorAll('button, input').forEach(x => { x.disabled = on; });

  root.addEventListener('click', async e => {
    const a = e.target.closest('a[data-view]');
    if (a && !e.metaKey && !e.ctrlKey && !e.shiftKey && e.button === 0) {
      e.preventDefault();
      state.panel = ''; state.find = ''; state.filter = 'all';
      history.pushState(null, '', a.getAttribute('href'));
      load(a.dataset.view).then(() => { const cur = root.querySelector('a[data-view][aria-current]'); if (cur) cur.focus(); });
      return;
    }
    const b = e.target.closest('button');
    if (!b) return;
    const d = b.dataset;
    if (d.retry != null) { load(state.view); return; }
    if (d.print) {
      const medical = d.print === 'medical';
      document.documentElement.classList.toggle('lst-print-medical', medical);
      pageStyle(medical);
      api('POST', 'lists/' + state.year + '/printed', { view: d.print }).catch(() => {});
      window.print();
      return;
    }
    if (d.csv || d.export != null) {
      try { await download(d.csv || 'meals'); say('Downloaded'); } catch (err) { toast(err.status === 403 ? 'Not allowed' : 'Download failed'); }
      return;
    }
    if (d.panel != null) { state.panel = state.panel === d.panel ? '' : d.panel; draw(); const f = root.querySelector('.lst-panel input, .lst-inline input'); if (f) f.focus(); else { const back = root.querySelector('[data-panel="' + d.panel + '"]'); if (back) back.focus(); } return; }
    if (d.sendOpen != null) { state.panel = d.sendOpen === 'mark' ? 'mark' : 'send'; draw(); const f = root.querySelector('.lst-panel [type=submit]'); if (f) f.focus(); return; }
    if (d.sendUndo != null) { try { const r = await api('POST', 'lists/' + state.year + '/meals/undo'); toast(r.say); refresh(); } catch (err) { toast(err.message); } return; }
    if (d.why) { state.open[d.why] = !state.open[d.why]; draw(); const again = root.querySelector('[data-why="' + CSS.escape(d.why) + '"]'); if (again) again.focus(); return; }
    if (d.filter) { state.filter = d.filter; draw(); const again = root.querySelector('[data-filter="' + d.filter + '"]'); if (again) again.focus(); return; }
    if (d.seen) { try { await api('POST', 'lists/' + state.year + '/seen', { view: d.seen }); say('Marked as seen'); refresh(); } catch (err) { toast(err.message); } return; }
    if (d.copy) { try { await navigator.clipboard.writeText(d.copy); toast('Copied · ' + d.copy); } catch (x) { toast(d.copy); } return; }
    if (d.access) {
      state.panel = state.panel === 'access:' + d.access ? '' : 'access:' + d.access;
      draw();
      if (state.panel) { try { state.access = await api('GET', 'lists/' + state.year + '/access'); } catch (err) { toast(err.message); } draw(); const f = root.querySelector('.lst-panel input'); if (f) f.focus(); }
      return;
    }
    if (d.payOpen) { state.panel = 'pay:' + d.payOpen; draw(); const f = root.querySelector('.lst-inline input, .lst-inline [type=submit]'); if (f) f.focus(); return; }
    if (d.payUndo) { undoMark(d.payUndo); return; }
    if (d.remind) { remind(+d.remind, b); return; }
    if (d.clearSamples != null) {
      if (!confirm('Clear the sample households for ' + state.year + '?')) return;
      try { await api('DELETE', 'reg/' + state.year + '/samples'); toast('Samples cleared'); refresh(); } catch (err) { toast(err.message); }
    }
  });
  document.addEventListener('click', e => { const u = e.target.closest('[data-toast-undo]'); if (u) undoMark(u.dataset.toastUndo); });

  async function undoMark(id) {
    try { const r = await api('POST', 'lists/' + state.year + '/pay/undo', { mark: id }); const t = document.getElementById('lst-toast'); if (t) t.remove(); toast(r.say); refresh(); } catch (err) { toast(err.message); }
  }
  async function remind(payment, b) {
    try {
      const p = await api('POST', 'lists/' + state.year + '/pay/remind', { payment, preview: 1 });
      if (!confirm('Send to ' + p.to + '?\n\n' + p.subject + '\n\n' + p.body)) return;
      b.disabled = true;
      const r = await api('POST', 'lists/' + state.year + '/pay/remind', { payment });
      toast(r.say);
    } catch (err) { toast(err.message); } finally { b.disabled = false; }
  }

  root.addEventListener('toggle', e => { const f = e.target.closest && e.target.closest('details[data-fold]'); if (f) state.open[f.dataset.fold] = f.open; }, true);
  root.addEventListener('input', e => {
    if (e.target.matches('[data-find]')) {
      state.find = e.target.value;
      const pos = e.target.selectionStart;
      draw();
      const f = root.querySelector('[data-find]');
      if (f) { f.focus(); try { f.setSelectionRange(pos, pos); } catch (x) { /* fine */ } }
    }
    if (e.target.getAttribute('aria-invalid')) e.target.removeAttribute('aria-invalid');
  });
  root.addEventListener('change', e => {
    if (e.target.name === 'communion_supper') { /* saved with the form */ }
  });
  root.addEventListener('submit', async e => {
    const form = e.target.closest('form[data-form]');
    if (!form) return;
    e.preventDefault();
    const kind = form.dataset.form, v = n => (form.elements[n] ? form.elements[n].value : '').trim();
    busy(form, true);
    try {
      if (kind === 'caterer') {
        const body = { caterer_email: v('caterer_email'), counts_due: v('counts_due') };
        if (form.elements.communion_supper) body.communion_supper = (form.querySelector('[name=communion_supper]:checked') || {}).value || 'all';
        await api('PUT', 'lists/' + state.year + '/settings', body);
        state.panel = '';
        toast('Saved');
        await refresh('[data-panel="caterer"]');
      } else if (kind === 'send') {
        const final = form.elements.final.checked;
        const r = await api('POST', 'lists/' + state.year + '/meals/send', { how: state.panel === 'mark' ? 'mark' : 'email', final });
        state.panel = '';
        toast(r.say);
        await refresh();
      } else if (kind === 'access') {
        const emails = Array.from(form.querySelectorAll('[name=emails]:checked')).map(x => x.value);
        state.access = await api('PUT', 'lists/' + state.year + '/access', { list: form.dataset.list, emails });
        state.panel = '';
        toast('Saved');
        await refresh();
      } else if (kind === 'pay') {
        const [act, id] = form.dataset.key.split(':');
        const cents = Math.round(parseFloat(v('amount').replace(/[$,]/g, '')) * 100);
        let r;
        if (act === 'desk') r = await api('POST', 'lists/' + state.year + '/pay/add', { record: +id, cents, method: (form.querySelector('[name=method]:checked') || {}).value, ref: v('ref') });
        else r = await api('POST', 'lists/' + state.year + '/pay', { payment: +id, action: act, cents: act === 'received' ? cents : undefined, ref: v('ref'), date: v('date') });
        state.panel = '';
        await refresh();
        toast(r.say, r.mark);
      }
    } catch (err) {
      busy(form, false);
      formError(form, err);
    }
  });
  // "/" finds, Escape closes a panel.
  document.addEventListener('keydown', e => {
    if (e.key === '/' && !/^(INPUT|TEXTAREA|SELECT)$/.test(document.activeElement.tagName)) {
      const f = root.querySelector('[data-find]');
      if (f) { e.preventDefault(); const det = f.closest('details'); if (det) det.open = true; f.focus(); }
    } else if (e.key === 'Escape' && state.panel) {
      const was = state.panel;
      state.panel = '';
      draw();
      const back = root.querySelector('[data-panel="' + was + '"], [data-access="' + was.replace('access:', '') + '"]');
      if (back) back.focus();
    }
  });
  window.addEventListener('afterprint', () => { document.documentElement.classList.remove('lst-print-medical'); pageStyle(false); });
  window.addEventListener('popstate', () => {
    const v = new URLSearchParams(location.search).get('view') || 'meals';
    state.panel = ''; state.find = '';
    load(v);
  });

  frame();
  more();
  load(state.view);
})();
