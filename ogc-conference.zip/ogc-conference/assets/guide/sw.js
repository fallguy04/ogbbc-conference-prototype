/*
 * sw.js — keeps the on-site guide working without signal (and on one bar of it), for the week on
 * campus. Served at /annual-conference/guide/sw.js, so it looks after the guide's pages alone.
 *
 * What it keeps (nothing else is ever stored):
 *   - the guide's page as anyone not signed in gets it (the server marks it X-OGC-Public). A
 *     signed-in page carries a name, an email and a nonce, so it is never kept: the worker fetches
 *     the public page itself, without cookies, and offline everyone gets that one (the
 *     Millers' name was in the kept page on a family's shared phone);
 *   - the plugin's own files (scripts, styles, icons, the year's picture);
 *   - the public year: /wp-json/ogc/v1/years and /years/{y}/bundle, only when the server marks the
 *     answer public (X-OGC-Public: 1). A member's answer (drafts, the committees' lists), anyone's
 *     records, "my room", sign-in links and wp-admin are never kept;
 *   - the fonts (Google's, and the site's Typekit).
 * How: the network first, but never waiting more than 3 seconds for it. Past that, the kept copy,
 * while the network carries on and refreshes the copy in the background (the page is told, and says
 * "Offline · Saved 2:45 PM" until a fresh copy arrives). A guest Wi-Fi's sign-in page that answers in
 * place of the data is recognised (the wrong kind of answer) and never kept.
 * The page sends the list of what this year needs, so every tab works offline after the first visit:
 * the page and the year first, the files after (a short first visit on campus Wi-Fi could
 * leave with nothing kept), and once all of it is kept the page is told ("Saved for offline").
 * Signing out clears it all (the server sends Clear-Site-Data; the page also asks).
 */
const VERSION = 'ogc-guide-8';
const WAIT = 3000;

self.addEventListener('install', () => self.skipWaiting());
// A new version clears the old copies.
self.addEventListener('activate', e => e.waitUntil(
  caches.keys().then(ks => Promise.all(ks.filter(k => k !== VERSION).map(k => caches.delete(k)))).then(() => self.clients.claim())
));

const here = self.location.origin;
const scope = new URL(self.registration.scope).pathname;
// Which requests are kept, and how each is checked: 'page' | 'asset' | 'data' | 'font' | ''.
function kind(url) {
  const u = new URL(url);
  // The fonts: Google's (bare pages, locally) and the site's own Typekit Droid Serif on ogbbc.org, so
  // the offline guide keeps the site's type rather than falling back to Georgia.
  if (/^https:\/\/(fonts\.googleapis\.com|fonts\.gstatic\.com|use\.typekit\.net|p\.typekit\.net)$/.test(u.origin)) return 'font';
  if (u.origin !== here) return '';
  // Never the sign-in page or wp-admin. (The plugin's own files under assets/signin/ are kept: the
  // account mark's script and style are needed offline.)
  if (/\/(wp-admin|wp-login\.php)|dev-sign(in|out)/.test(u.pathname) || u.pathname.indexOf(scope.replace(/guide\/$/, '') + 'signin/') === 0) return '';
  if (/\/wp-json\/ogc\/v1\/years(\/\d{4}\/bundle)?\/?$/.test(u.pathname)) return 'data';
  if (u.pathname.indexOf('/wp-json/') > -1 || u.searchParams.has('rest_route')) return '';
  // The plugin's files, the guide's icons and its manifest (the manifest failed offline).
  if (/\/plugins\/ogc-conference\/assets\//.test(u.pathname) || /\/guide\/app\//.test(u.pathname) || u.pathname === scope + 'manifest.webmanifest') return 'asset';
  if (u.pathname === scope || u.pathname === scope + 'index.html') return 'page';
  return '';
}
// Is this answer the real thing, safe to keep?
async function keepable(k, res) {
  if (k === 'font') return res.ok || res.type === 'opaque';
  if (!res.ok || res.redirected) return false;
  const type = res.headers.get('Content-Type') || '';
  if (k === 'data') return /json/.test(type) && res.headers.get('X-OGC-Public') === '1';
  if (/no-store|private/.test(res.headers.get('Cache-Control') || '')) return false;
  if (k === 'page') return /text\/html/.test(type) && res.headers.get('X-OGC-Public') === '1' && (await res.clone().text()).indexOf('id="ogc-week"') > -1;
  return !/text\/html/.test(type);
}
// Kept with the time it was saved.
async function put(req, res, k) {
  if (!(await keepable(k, res))) return false;
  const c = await caches.open(VERSION);
  if (res.type === 'opaque') { await c.put(req, res); return true; }
  const h = new Headers(res.headers);
  h.set('X-OGC-Saved', String(Date.now()));
  await c.put(req, new Response(await res.clone().blob(), { status: res.status, statusText: res.statusText, headers: h }));
  return true;
}
const keyOf = (req, k) => k === 'page' ? new URL(req.url).pathname : req;
const tell = (clientId, msg) => clientId && self.clients.get(clientId).then(c => c && c.postMessage(msg));

self.addEventListener('fetch', e => {
  const r = e.request, k = r.method === 'GET' ? kind(r.url) : '';
  if (!k) return;
  e.respondWith((async () => {
    const c = await caches.open(VERSION);
    const kept = await c.match(keyOf(r, k), { ignoreSearch: k === 'page' });
    // A versioned file (?ver=) never changes: the kept copy straight away.
    if (k === 'asset' && kept && new URL(r.url).searchParams.has('ver')) return kept;
    // served: the kept copy went to the page first (the network was slow), so once the network does
    // answer, the page is told to read again, whether or not this answer may be kept (a
    // signed-in reader's answer is private, so "Offline" stayed up although the phone was online).
    let served = false;
    const net = fetch(r).then(async res => {
      const kept_ = await put(keyOf(r, k), res.clone(), k);
      if (k === 'data' && (kept_ || (served && res.ok))) tell(e.clientId || e.resultingClientId, { ogc: 'fresh' });
      return res;
    });
    if (!kept) return net.catch(() => Response.error());
    const late = new Promise(ok => setTimeout(() => ok('late'), WAIT));
    const first = await Promise.race([net.catch(() => 'failed'), late]);
    if (first !== 'late' && first !== 'failed') return first;
    // Offline, or too slow: the kept copy, and the page is told how old it is.
    served = true;
    if (k === 'data') tell(e.clientId, { ogc: 'cached', at: +kept.headers.get('X-OGC-Saved') || 0 });
    if (first === 'late') e.waitUntil(net.catch(() => {}));
    // The page itself from the kept copy: once it's running, it's told, so it says Offline and leaves
    // out the way to the Conference page (a page whose year came inlined never heard).
    if (k === 'page') e.waitUntil(new Promise(ok => setTimeout(ok, 1500)).then(() => tell(e.resultingClientId || e.clientId, { ogc: 'cached', page: true, at: +kept.headers.get('X-OGC-Saved') || 0 })));
    return kept;
  })());
});

// From the page: what this year's guide needs kept, the page and the year first (first), then its
// files (keep), fetched now so every tab works offline; or "clear" (signed out on this phone). Once
// everything first and most of the rest are kept, the page hears "kept".
const fetchKeep = u => {
  const abs = new URL(u, self.location).href, k = kind(abs);
  if (!k) return Promise.resolve(false);
  // Without cookies: the copy kept is the public one, whoever is signed in on this phone.
  return fetch(abs, { credentials: k === 'font' ? 'same-origin' : 'omit', mode: k === 'font' ? 'no-cors' : 'same-origin' })
    .then(res => put(keyOf(new Request(abs), k), res, k)).catch(() => false);
};
self.addEventListener('message', e => {
  const d = e.data || {};
  if (d.clear) { e.waitUntil(caches.delete(VERSION)); return; }
  const first = (d.first || []).filter(u => kind(new URL(u, self.location).href));
  const rest = (d.keep || []).filter(u => kind(new URL(u, self.location).href) && first.indexOf(u) < 0);
  if (!first.length && !rest.length) return;
  const src = e.source;
  e.waitUntil(Promise.all(first.map(fetchKeep)).then(async a => {
    const b = await Promise.all(rest.map(fetchKeep));
    const ok = a.every(Boolean) && b.filter(Boolean).length >= b.length * 0.9;
    if (ok && src) src.postMessage({ ogc: 'kept', year: d.year || '', at: Date.now() });
  }));
});
