/*
 * volunteer.js — volunteering at the Annual Conference, on our own site (replacing SignUpGenius).
 * Anyone, any time; it isn't part of registering. Every count, name and "you" comes from GET vol/{year}
 * (never cached), and every Sign up waits for the server's answer: "Signed up" is shown only when true.
 *
 * Oct 13 (Michael; concepts/signup/one): "the biggest thing that's busy about the helping out thing is
 * how they are all just right there boom in your face." So:
 *   (default)       the committees as calm cards (icon, name, jobs, days, how many open)
 *   ?committee=…    one committee's shifts, a clean list by day: day chips, Hide full (off: COA rehearsal,
 *                   Oct 28, a laptop's week looked like whole days were missing; a visitor turns it on); on a laptop
 *                   (1100 px and wider) its week as a grid, a card a shift, opening in place (Oct 15)
 *   ?view=all       every committee's shifts the same way (a quiet link under the cards)
 *   ?shift=…        that shift's committee, with its row open (emails, Invite, Find replacement)
 *   ?link=1         an emailed link (confirm, not me, leave, a place opened, your 2026 shifts): the
 *                   server moved its opaque token into a short cookie, so the address never carries it
 *   ?swap=…         a place offered for a swap (Take place, in the row)
 * Sign up opens the row in place and asks "Who's helping?": the signed-in person by their own name,
 * their household (or the people they've signed up before), and Add someone (a name and an email:
 * that person confirms by email, and shows "Waiting to confirm" until they do). Your week is beside the
 * list on a laptop (services faint, your shifts in tan, the one being looked at dashed), and a bar that
 * opens as a sheet on a phone. Mechanical (docs/25): nothing here looks anyone up by name.
 * The heads' list is the app's Helpers screen (?view=lead redirects there).
 *
 * After the critic (Oct 15, CHANGES/volunteer-vs-sug.md): a shift is said once with its people ("Server ·
 * Sat, May 29 · Martha and Henry"), in the toast, the banners and the calendar file (one event a shift);
 * someone typed into Add someone counts and goes on with Sign up; your own shift reads "✓ Yours" and opens
 * to its state, Calendar, Leave and a quiet Add someone; Under 18 is a box (never named, kept off 18-and-older
 * shifts); an age rule is two plain answers, "under" listing what's open to them; Your week only with
 * something real in it; a day in parts (Morning, Afternoon, Evening, Night); one way to close a row.
 *
 * After the fourth critic (Oct 15): one Leave sheet everywhere (SU.leaveSheet: the opened row, Your week,
 * the emailed link, Your sign-ups); an emailed link whose own person has left opens on that ("Miriam left ·
 * Glen is still on it", Done); no-limit shifts never counted "0 open"; Midday between Morning and
 * Afternoon; one row layout on a laptop; fields labelled above; a hidden name is a person's mark.
 *
 * After the sixth critic (Oct 15): each person's age is one plain field (Age · Under 18 · 18–20 · 21 or
 * older), asked once and kept (the Under 18 box and "I'm under 21" are gone); "For someone else" is the
 * contact's box, then a list of names (a first name and Enter each); Your week never draws a shift the
 * pointer passed over; Evening from 4:45; a committee's jobs by their shared stem; a certification each.
 */
(function () {
  'use strict';
  const O = window.OGC, esc = O.esc, SU = O.signups, W = window.OGC_WP || {};
  const root = document.getElementById('ogc-vol');
  if (!root) return;
  const BASE = root.dataset.base;
  const q = new URLSearchParams(location.search);

  // Your sign-ups holds "my" shifts with everything else.
  // With its year: the one asked for, else the one this person is on (OGC_WP.mine; after the sixth critic,
  // Oct 15: none led to "Couldn't load"). The server adds it too for anyone signed in.
  if (q.get('view') === 'mine') { location.replace(q.get('year') ? (W.base || '/annual-conference/') + 'register/?view=mine&year=' + encodeURIComponent(q.get('year')) : W.mine || (W.base || '/annual-conference/') + 'register/?view=mine'); return; }

  const svg = d => '<svg class="wk-i" viewBox="0 0 24 24" aria-hidden="true"><path d="' + d + '" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  const I = {
    cal: svg('M7.5 3.5v3M16.5 3.5v3M4 9.5h16M5.5 5.5h13A1.5 1.5 0 0 1 20 7v11.5a1.5 1.5 0 0 1-1.5 1.5h-13A1.5 1.5 0 0 1 4 18.5V7a1.5 1.5 0 0 1 1.5-1.5Z'),
    pin: svg('M12 20.5s-6.5-5.4-6.5-10.8a6.5 6.5 0 0 1 13 0c0 5.4-6.5 10.8-6.5 10.8ZM12 12a2.3 2.3 0 1 0 0-4.6 2.3 2.3 0 0 0 0 4.6Z'),
    check: svg('m5.5 12.5 4 4 9-9'),
    close: svg('m6.5 6.5 11 11M17.5 6.5l-11 11'),
    mail: svg('M4 6.5h16v11H4zM4.5 7l7.5 6 7.5-6'),
    back: svg('M14.5 5.5 8 12l6.5 6.5'),
    up: svg('m6 14.5 6-6 6 6'),
    link: svg('M10 14a4 4 0 0 0 5.66 0l3-3a4 4 0 0 0-5.66-5.66l-1 1M14 10a4 4 0 0 0-5.66 0l-3 3a4 4 0 0 0 5.66 5.66l1-1'),
    phone: svg('M6.5 3.5h3l1.5 4-2 1.5a11 11 0 0 0 6 6l1.5-2 4 1.5v3a2 2 0 0 1-2 2A16 16 0 0 1 4.5 5.5a2 2 0 0 1 2-2Z'),
    plus: svg('M12 5v14M5 12h14'),
    clock: svg('M12 20.5a8.5 8.5 0 1 0 0-17 8.5 8.5 0 0 0 0 17ZM12 7.5V12l3 2'),
    alert: svg('M12 7.5v5.5M12 16.5v.01M12 20.5a8.5 8.5 0 1 0 0-17 8.5 8.5 0 0 0 0 17Z'),
    info: svg('M12 11v5.5M12 7.5v.01M12 20.5a8.5 8.5 0 1 0 0-17 8.5 8.5 0 0 0 0 17Z'),
    week: svg('M4 9.5h16M7.5 3.5v3M16.5 3.5v3M5.5 5.5h13A1.5 1.5 0 0 1 20 7v11.5a1.5 1.5 0 0 1-1.5 1.5h-13A1.5 1.5 0 0 1 4 18.5V7a1.5 1.5 0 0 1 1.5-1.5ZM7 13.5h10'),
    person: svg('M12 11.5a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7ZM5 20c.6-3.6 3.4-5.8 7-5.8s6.4 2.2 7 5.8')
  };
  // Each committee's own sign, by its name (any the COA adds gets the raised hand).
  const HAND = 'M8 11V5.5a1.5 1.5 0 0 1 3 0V11M11 10V4.5a1.5 1.5 0 0 1 3 0V11M14 10.5V6a1.5 1.5 0 0 1 3 0v7.5a6 6 0 0 1-6 6h-.6a6 6 0 0 1-4.6-2.2L3.6 14.6a1.5 1.5 0 0 1 2.2-2L8 14.5V11';
  const MARKS = [
    [/transport|golf|cart|parking/i, 'M6 5.5h11M7 5.5v6M16 5.5v6M4.5 11.5h15v4h-15zM7.5 19a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3ZM16.5 19a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3Z'],
    [/dining|food|kitchen|meal/i, 'M7.5 3.5v6.5M5.5 3.5V8a2 2 0 0 0 4 0V3.5M7.5 10v10.5M16.5 20.5v-17c-2 1.2-3 3.6-3 7v3h3'],
    [/usher/i, 'M6.5 20.5v-16h11v16M4 20.5h16M14.5 12.5v.01'],
    [/first aid|medical|nurse/i, 'M12 8.5v7M8.5 12h7M6 4.5h12A1.5 1.5 0 0 1 19.5 6v12a1.5 1.5 0 0 1-1.5 1.5H6A1.5 1.5 0 0 1 4.5 18V6A1.5 1.5 0 0 1 6 4.5Z'],
    [/preteen|child|nursery/i, 'M8 7.5a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5ZM4 20.5v-6.5a4 4 0 0 1 8 0v6.5M17 11.5a2 2 0 1 0 0-4 2 2 0 0 0 0 4ZM14.5 20.5v-4.5a2.5 2.5 0 0 1 5 0v4.5'],
    [/young ?folk/i, 'M9 11a3.4 3.4 0 1 0 0-6.8A3.4 3.4 0 0 0 9 11ZM3 19.5c.6-3.3 3-5.2 6-5.2s5.4 1.9 6 5.2M15.8 4.5a3.2 3.2 0 0 1 0 6.2M17.6 14.6c1.8.7 3 2.3 3.4 4.9'],
    [/communion/i, 'M7.5 3.5h9l-.8 5.5a3.7 3.7 0 0 1-7.4 0L7.5 3.5ZM12 12.8v6.2M8.5 20h7'],
    [/kit|pack/i, 'M3.5 7.5 12 3.5l8.5 4v9L12 20.5l-8.5-4zM3.5 7.5l8.5 4 8.5-4M12 11.5v9'],
    [/lodging|desk|registration/i, 'M8 11.5a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7ZM10.5 10.5l9 9M16.5 16.5l2-2M14 14l1.5-1.5'],
    // A/V (sound, recording, the call-in line): a microphone (after the seventh critic, Oct 15: it had the
    // raised hand any unnamed committee gets).
    [/\ba\s*\/\s*v\b|audio|sound|video|record|call-in|technology/i, 'M12 3.5a2.5 2.5 0 0 0-2.5 2.5v5.5a2.5 2.5 0 0 0 5 0V6A2.5 2.5 0 0 0 12 3.5ZM6.5 11a5.5 5.5 0 0 0 11 0M12 16.5v4M9 20.5h6']
  ];
  const mark = c => svg((MARKS.find(m => m[0].test(c)) || [0, HAND])[1]);
  const ci = c => '<span class="vo-ci" aria-hidden="true">' + mark(c) + '</span>';

  const state = {
    year: root.dataset.year || q.get('year') || '', row: null, model: null, shifts: [], live: null, campus: null, years: [],
    committee: q.get('committee') || (q.get('view') === 'all' ? '*' : ''),
    day: {}, job: {}, also: [], ownAlso: [], ownAlsoFor: '', hideFull: false, open: '', pick: [], added: [], add: null, me1: {}, ans: {}, err: {}, footErr: '', bands: {},
    busyAct: '', leaving: '', wk: '', hover: '', flash: '', link: null, swap: q.get('swap') || '', mapOpen: '',
    emailEdit: '', emailVal: null, emailErr: '', emailFix: '', typoOk: ''
  };
  // ?job= (Your sign-ups' dorm ask: Youngfolks › Dorm chaperone): that committee's job chip, chosen.
  if (q.get('job') && state.committee && state.committee !== '*') state.job[state.committee] = q.get('job');
  const say = document.createElement('p');
  say.className = 'ogc-sr';
  say.setAttribute('aria-live', 'polite');
  root.after(say);

  /* ---------------------------------------------------------------- per-viewer conveniences (this browser) */

  const kept = {
    get(k, f) { try { const v = JSON.parse(localStorage.getItem('ogc-vol-' + k)); return v == null ? f : v; } catch (e) { return f; } },
    set(k, v) { try { localStorage.setItem('ogc-vol-' + k, JSON.stringify(v)); } catch (e) { /* not kept */ } }
  };
  // What a visitor typed, and the hold on what they just joined, live only in this tab (sessionStorage):
  // a shared tablet or family computer never shows the last person's shifts. (A first-timer's own name,
  // email, phone and age are kept on the device until they confirm or sign in: ME1, below.)
  const tab = {
    get(k, f) { try { const v = JSON.parse(sessionStorage.getItem('ogc-vol-' + k)); return v == null ? f : v; } catch (e) { return f; } },
    set(k, v) { try { sessionStorage.setItem('ogc-vol-' + k, JSON.stringify(v)); } catch (e) { /* not kept */ } },
    del(k) { try { sessionStorage.removeItem('ogc-vol-' + k); } catch (e) { /* nothing kept */ } }
  };
  try { Object.keys(localStorage).filter(k => /^ogc-vol-(typed|hold-|who-)/.test(k)).forEach(k => localStorage.removeItem(k)); } catch (e) { /* nothing kept */ }
  const holds = () => tab.get('hold-' + state.year, []).filter(Boolean).slice(-10);
  const addHold = t => { if (t) tab.set('hold-' + state.year, holds().concat(t).slice(-10)); };
  // A first-timer's own details (name, email, phone, age), kept on this device from their first sign-up
  // until they confirm or sign in, so coming back in a new tab they don't type them again (after the
  // seventh critic, Oct 15). Their own device: they just typed them there; it's never sent anywhere or
  // shown to anyone else, and it goes on confirming, signing in, "Not you?", or after 14 days.
  const ME1 = () => 'me1-' + state.year;
  const kept1 = () => { const v = kept.get(ME1(), null); return v && v.at && Date.now() - v.at < 14 * 864e5 ? v : null; };
  const forget1 = () => { try { localStorage.removeItem('ogc-vol-' + ME1()); } catch (e) { /* nothing kept */ } };
  const typed = () => holds().length ? tab.get('typed', {}) : (kept1() || {});
  let tabPhone = '';
  async function forgetMe() {
    tab.del('hold-' + state.year); tab.del('typed'); tabPhone = ''; forget1();
    if (!signed()) { try { await post('vol/' + state.year + '/forget', {}); } catch (e) { /* still forgotten here */ } }
    state.me1 = {}; state.added = []; state.pick = []; state.open = '';
    await loadLive().catch(() => {});
    render();
    say.textContent = 'Signed out';
  }

  /* ---------------------------------------------------------------- the server */

  const asOf = () => { const a = O.parseAsOf(q.get('as-of')); return a && W.dev ? Math.round(O.wallToInstant(a.date, a.minutes, tz()).getTime() / 1000) : 0; };
  const tz = () => (state.model && state.model.tz) || 'America/Indiana/Indianapolis';
  async function call(method, path, body) {
    // A visitor's read carries no nonce (a stale one would be refused even for the public counts).
    const h = (W.me || method !== 'GET') && W.nonce ? { 'X-WP-Nonce': W.nonce } : {};
    const hs = holds();
    if (hs.length) h['X-OGC-Hold'] = hs.join(',');
    if (asOf()) h['X-OGC-Now'] = String(asOf());
    if (body !== undefined) h['Content-Type'] = 'application/json';
    const res = await fetch((W.rest || '/wp-json/ogc/v1/') + path, { method, credentials: 'same-origin', headers: h, body: body === undefined ? undefined : JSON.stringify(body) });
    const fresh = res.headers.get('X-WP-Nonce');
    if (fresh) W.nonce = fresh;
    const type = res.headers.get('Content-Type') || '';
    const data = /json/.test(type) ? await res.json().catch(() => null) : await res.text();
    if (!res.ok) {
      const e = new Error((data && data.message) || ('HTTP ' + res.status));
      e.status = res.status; e.data = (data && data.data) || {}; e.code = data && data.code;
      throw e;
    }
    return data;
  }
  // A change: once more with a fresh nonce if the page has been open past a day.
  async function post(path, body) {
    try { return await call('POST', path, body); } catch (e) {
      if (e.status === 403 && (e.data.why === 'nonce' || e.code === 'rest_cookie_invalid_nonce')) { if (e.code && W.me && W.freshNonce) await W.freshNonce(); else { if (e.code) W.nonce = ''; await loadLive(); } return call('POST', path, body); }
      throw e;
    }
  }
  async function loadLive() {
    const d = await call('GET', 'vol/' + state.year);
    state.live = d;
    if (d.nonce) W.nonce = d.nonce;
    return d;
  }
  // Counts that came back with an action replace those shifts' only.
  function merge(d) {
    if (!d || !state.live) return;
    if (d.shifts) Object.keys(d.shifts).forEach(k => { state.live.shifts[k] = d.shifts[k]; });
    if (d.mine) state.live.mine = d.mine;
    if (d.waits) state.live.waits = d.waits;
    if (d.circle) state.live.circle = d.circle;
    if (d.hold) addHold(d.hold);
  }

  /* ---------------------------------------------------------------- the year and its shifts */

  const S = () => state.model.settings;
  const L = sh => (state.live && state.live.shifts[sh.id]) || { f: 0, o: sh.unlimited ? null : sh.needed, w: 0, st: 'not_open', s: [] };
  const find = id => state.shifts.find(s => s.id === id);
  const live = () => state.live || { mine: [], waits: [], committees: [], shifts: {} };
  const me = () => live().me;
  const signed = () => !!(me() && me().signed);
  // An emailed link (a place opened, your shifts again) vouches for the email: no need to type it.
  const vouched = () => !signed() && !!(state.link && /^(opened|again)$/.test(state.link.a || '') && state.link.email);
  const mine = () => live().mine || [];
  const minesOn = sh => mine().filter(m => m.shift === sh.id);
  // Signed in: this email's places another device made, still waiting for its Confirm (the server's
  // pending; after the eighth critic, Oct 16: Hannah's second place read "3 of 4 open · Sign up", and Sign
  // up said "Already signed up"). Shown as hers, "Waiting to confirm" with Resend; never her people.
  const pendOn = sh => minesOn(sh).length ? [] : (live().pending || []).filter(p => p.shift === sh.id);
  const pendAll = () => (live().pending || []).filter(p => find(p.shift) && !minesOn(find(p.shift)).length);
  const waitsOn = sh => (live().waits || []).filter(w => w.shift === sh.id);
  const open = sh => { const o = L(sh).o; return o == null ? Infinity : o; };
  const st = sh => L(sh).st;
  const joinable = sh => st(sh) === 'open';
  // Counted as open: open now, or (a preview before Publish) open once sign-ups go up.
  const counts = sh => st(sh) === 'open' || st(sh) === 'not_open';
  const openSum = list => list.filter(counts).reduce((k, sh) => k + (sh.unlimited ? 0 : Math.max(0, open(sh))), 0);
  // What's open in some shifts, said truly (after the fourth critic, Oct 15: a day with only Kit packing,
  // which has no limit, said "1 shift · 0 open" beside its Sign up): "5 open"; shifts with no limit add
  // nothing to that and, alone, say how many are coming ("13 coming", or "No limit"); "Full" only when
  // every one of them can fill and has; nothing when none is open to sign-ups.
  function openWords(list) {
    const c = list.filter(counts), o = openSum(c), un = c.filter(sh => sh.unlimited);
    if (o) return o + ' open';
    // "13 signed up" (after the fifth critic, Oct 15: "13 coming" read like "coming soon").
    if (un.length) { const f = un.reduce((k, sh) => k + L(sh).f, 0); return f ? f + ' signed up' : 'No limit'; }
    return c.length ? 'Full' : '';
  }
  // Some shift here can be full (Hide full means something only then).
  const canFill = list => list.some(sh => !sh.unlimited);
  const isFull = sh => !sh.unlimited && (st(sh) === 'full' || (counts(sh) && open(sh) <= 0));
  const opensWord = () => live().opens ? 'Opens ' + O.fmtDate(live().opens, 'mdShort') : 'Not open yet';
  const names = () => live().names !== false;
  const closed = () => !!live().closed;
  const committees = () => {
    const have = new Set(state.shifts.map(s => s.committee));
    const order = (live().committees || []).map(c => c.name).filter(n => have.has(n));
    have.forEach(n => { if (order.indexOf(n) < 0) order.push(n); });
    return order;
  };
  const comm = c => (live().committees || []).find(x => x.name === c) || {};
  // The committee's one instruction for every shift (its head's or the COA's words, Helpers).
  const instructionOf = c => String(comm(c).instruction || '').trim();
  const sameWords = (a, b) => { const n = s => String(s || '').toLowerCase().replace(/[^a-z0-9]+/g, ''); return !!n(a) && n(a) === n(b); };
  // What every shift of a committee has in common (the job, the place, the rule): said once above the
  // list, so each row says only what differs. A job named as the committee is ("Usher" for Ushers) isn't
  // said at all.
  const shared = c => sharedOf(state.shifts.filter(sh => sh.committee === c), c);
  function sharedOf(list, c) {
    if (!list.length) return { role: '', place: null, rule: '', roleShared: false };
    const one = (f, k) => { const v = list.map(f); return v.every(x => (k ? k(x) : x) === (k ? k(v[0]) : v[0])) ? v[0] : null; };
    const role = one(sh => sh.role, low), rule = one(sh => ruleShort(sh) || '');
    // The place: the committee's usual one, mechanically the place more than half of these shifts have
    // (after the seventh critic, Oct 15: 2026's First Aid on Tuesday at the Youngfolks' field said no
    // place anywhere, because not every shift shared one). Said once above; a shift elsewhere says its own.
    const by = {};
    list.forEach(sh => { if (sh.place && sh.place.code) { const k = String(sh.place.code).toUpperCase(); (by[k] = by[k] || { p: sh.place, n: 0 }).n++; } });
    const top = Object.values(by).sort((a, b) => b.n - a.n)[0];
    return { roleShared: role != null, role: role != null && !said(role, c) ? role : '', place: top && top.n * 2 > list.length ? top.p : null, rule: rule || '' };
  }
  const samePlace = (a, b) => !!(a && b && a.code && b.code && String(a.code).toUpperCase() === String(b.code).toUpperCase());
  const plural = SU.plural;
  const uniq = xs => Array.from(new Set(xs));
  const low = s => String(s || '').trim().toLowerCase().replace(/\s+/g, ' ');
  const first = n => String(n || '').trim().split(/\s+/)[0];
  const listAnd = a => a.length < 2 ? a.join('') : a.slice(0, -1).join(', ') + ' and ' + a[a.length - 1];
  // People named, never "You" (the house rule; COA rehearsal, Oct 28): one by first name ("Daniel"); two
  // or more who share a last name by it ("Millers"); else "Daniel and Ruth", "Daniel and 2 more".
  function namesWord(full) {
    const ns = uniq((full || []).map(n => String(n || '').trim()).filter(Boolean)), fs = uniq(ns.map(first));
    if (fs.length < 2) return fs.join('');
    const ls = uniq(ns.map(n => low(lastOf(n)))), l = lastOf(ns[0]);
    if (ls.length === 1 && ls[0]) return l + (/(s|x|z|ch|sh)$/i.test(l) ? 'es' : 's');
    return fs.length === 2 ? listAnd(fs) : fs[0] + ' and ' + (fs.length - 1) + ' more';
  }
  const possWord = w => w + (/s$/i.test(w) ? '’' : '’s');
  // A shift said once, with who's on it by first name ("Server · Sat, May 29 · Martha and Henry"): a
  // couple on one shift is one shift, everywhere (after the critic, Oct 15). Yourself alone isn't named.
  const dayShort = sh => AW(sh) ? 'All week' : SU.dayShort(sh, state.model.days);
  const whoWords = ms => { const ns = uniq((ms || []).map(m => first(m.name)).filter(Boolean)); return ns.length === 1 && selfName() && low(first(selfName())) === low(ns[0]) && (ms || []).every(m => !m.added) ? '' : listAnd(ns); };
  const shiftLine = (sh, ms) => [sh.role, dayShort(sh), whoWords(ms)].filter(Boolean).join(' · ');
  // Sign-ups a shift at a time, in time order: [{ sh, ms }].
  const byShift = ms => { const out = []; (ms || []).forEach(m => { const sh = find(m.shift); if (!sh) return; let g = out.find(x => x.sh === sh); if (!g) out.push(g = { sh, ms: [] }); g.ms.push(m); }); return out.sort((a, b) => sortKey(a.sh) - sortKey(b.sh)); };
  const initials = n => { const w = String(n || '').replace(/\./g, '').trim().split(/\s+/).filter(Boolean); return w.length ? (w[0][0] + (w.length > 1 ? w[w.length - 1][0] : '')).toUpperCase() : ''; };
  // "All week" (the one fixed choice beside exact times; 2025's dorm hosts): one shift for the days it
  // covers, listed before the days, never Busy against a timed shift (as the server).
  const AW = sh => !!(sh && sh.allweek);
  const weekDays = sh => dayWord(sh.day).slice(0, 3) + ' – ' + dayWord(sh.lastDay || sh.day).slice(0, 3);
  // "7–11 AM", "11:45 AM–2:15 PM", "10 PM–12 AM": one line, tabular.
  const span = sh => AW(sh) ? 'All week' : O.formatRange(sh.start, sh.end, { compact: true });
  const hours = sh => { if (AW(sh)) return weekDays(sh); const m = sh.end - sh.start, h = Math.floor(m / 60), r = m % 60; return (h ? h + ' hr' : '') + (h && r ? ' ' : '') + (r ? r + ' min' : ''); };
  // Saturday's 12–2 AM is Friday night: a shift from midnight to 5 AM belongs to the evening before. One
  // rule for every page and the server (SU.eveOf, ogc_vol_eve_date; after the eighth critic, Oct 16).
  const eve = sh => SU.eveOf(sh, state.model.days);
  const night = sh => !AW(sh) && SU.isNight(sh, state.model.days);
  const sortKey = sh => AW(sh) ? -1 : state.model.days.indexOf(eve(sh)) * 2880 + (night(sh) ? sh.start + 1440 : sh.start);
  const dayWord = d => O.fmtDate(d.date, 'weekday');
  const whenDay = d => d ? dayWord(d) + ', ' + O.fmtDate(d.date, 'md') : '';
  const weekRange = sh => O.fmtDate(sh.day.date, 'weekdayShort') + ', ' + O.fmtDate(sh.day.date, 'mdShort') + ' – ' + O.fmtDate((sh.lastDay || sh.day).date, 'weekdayShort') + ', ' + O.fmtDate((sh.lastDay || sh.day).date, 'mdShort');
  const whenShort = sh => AW(sh) ? 'All week · ' + weekRange(sh) : O.fmtDate(eve(sh).date, 'weekdayShort') + (night(sh) ? ' night' : '') + ', ' + O.fmtDate(eve(sh).date, 'mdShort') + ' · ' + span(sh);
  const whenLong = sh => AW(sh) ? 'All week, ' + whenDay(sh.day) + ' to ' + whenDay(sh.lastDay || sh.day) : dayWord(eve(sh)) + (night(sh) ? ' night' : '') + ', ' + O.fmtDate(eve(sh).date, 'md');
  // Real instants for overlap (as the server): the day's index × a day + minutes.
  const t0 = sh => state.model.days.indexOf(sh.day) * 1440 + sh.start, t1 = sh => state.model.days.indexOf(sh.day) * 1440 + sh.end;
  const overlaps = (a, b) => AW(a) === AW(b) && t0(a) < t1(b) && t0(b) < t1(a);
  const placeName = sh => sh.place ? sh.place.name : '';
  const isWeek = () => { const d = state.model.days, n = today(); return d.length && n >= O.isoAddDays(d[0].date, -7) && n <= d[d.length - 1].date; };
  const today = () => (state.live && state.live.now && state.live.now.date) || O.wallNow(tz()).date;
  const during = () => { const d = state.model.days, n = today(); return !!(d.length && n >= d[0].date && n <= d[d.length - 1].date); };
  const ahead = sh => !/^(started|ended)$/.test(st(sh));
  const helpedOf = c => { const h = live().helped; return h ? (c ? (h.committees || {})[c] || 0 : h.total || 0) : null; };
  const placesOf = list => list.reduce((k, sh) => k + L(sh).f, 0);
  const helpedWords = (c, list) => { const h = helpedOf(c); return h != null ? (h ? h + ' helped' : '') : placesOf(list) ? placesOf(list) + ' places filled' : ''; };
  const masked = e => { const m = /^(.)[^@]*(@.*)$/.exec(String(e || '')); return m ? m[1] + '…' + m[2] : ''; };

  // A shift's rule: an age ("21 or older"), a choice (First Aid's certification), or words to agree to.
  const minAge = sh => +sh.min_age || ((/\b(\d{1,2})\s*(\+|or older|and older|and up)/i.exec(sh.rule || '') || [])[1] | 0);
  const question = sh => sh.question ? sh.question.split('|').map(s => s.trim()).filter(Boolean) : (/certified/i.test(sh.rule) && /partner/i.test(sh.rule) ? ['Certified', 'With a certified partner'] : []);
  const screening = sh => /^(y|yes|1|true)$/i.test(sh.screening || '');
  // An age rule and a certification may go together (after the eighth critic, Oct 16: "21 or older ·
  // First-aid certified (or with a certified partner)" asks both, each in its own place).
  const ruleShort = sh => minAge(sh) && question(sh).length ? minAge(sh) + ' or older · Certified' : minAge(sh) ? minAge(sh) + ' or older' : question(sh).length ? 'Certified' : sh.rule;

  // A person's age (after the sixth critic, Oct 15: "I'm under 21" and "Under 18" were two ticks, and a
  // minor's privacy hung on noticing one): one plain fixed field, Age · Under 18 · 18–20 · 21 or older,
  // asked once a person where it matters and kept with them (this visit and on the server, data.band).
  // The registration's Adult is "18 or older" ('adult'): a 21-or-older shift asks it once more.
  const BANDS = [['u18', 'Under 18'], ['18', '18–20'], ['21', '21 or older']];
  const bandWords = b => (BANDS.find(x => x[0] === b) || [0, b === 'adult' ? '18 or older' : ''])[1];
  const BLO = { u18: 0, 18: 18, 21: 21, adult: 18 }, BHI = { u18: 17, 18: 20, 21: 999, adult: 999 };
  // Does a band meet a shift's age? true, false, or null (not known: asked).
  const bandOk = (b, min) => !min ? (b ? true : null) : !(b in BLO) ? null : BLO[b] >= min ? true : BHI[b] < min ? false : null;
  // What the registration says: a number, Under 18 (a child, a minor), or an Adult.
  const regBand = info => { if (!info) return ''; if (info.years != null) return info.years < 18 ? 'u18' : info.years < 21 ? '18' : '21'; if (info.age === 'minor' || info.age === 'child') return 'u18'; return info.band || (info.age === 'adult' && !info.yf ? 'adult' : ''); };
  // A person's band: answered on this visit, else theirs as known (their earlier sign-ups, the registration).
  function bandOf(p) {
    if (!p) return '';
    if (p.k === 'me' && formSelf()) return (state.me1 || {}).band || '';
    const exact = p.info && (p.info.years != null || p.info.age === 'minor' || p.info.age === 'child') ? regBand(p.info) : '';
    if (exact) return exact;
    if (state.bands[p.k]) return state.bands[p.k];
    if (p.band && p.band !== 'adult') return p.band;
    if (p.self && me() && me().band && me().band !== 'adult') return me().band;
    return regBand(p.info) || p.band || (p.self && me() && me().band) || '';
  }
  // Asked for this shift: nothing known, or "18 or older" on a 21-or-older shift.
  const needsBand = (b, sh) => !b || bandOk(b, minAge(sh)) === null;
  // Known to be 18 or older (a registration's Adult) before anything answered here: asked only 18–20 or 21
  // or older, the same pills before and after the answer.
  const baseAdult = p => regBand(p.info) === 'adult' || p.band === 'adult' || !!(p.self && me() && me().band === 'adult');
  // The choice itself: three pills, one per person (bag: me1 or add, or a person's key).
  // A registration's Adult is already 18 or older: only 18–20 or 21 or older is asked of them.
  // Its "Choose one" sits on the label's own line (after the ninth critic, Oct 16: answering one age took
  // its error line away and moved the next person's pills up under the finger), so nothing below moves.
  function ageSeg(key, cur, label, err, adult) {
    const nm = 'band-' + key.replace(/[^a-z0-9]+/gi, '-');
    return '<fieldset class="vo-q vo-ageq' + (err ? ' is-bad' : '') + '"><legend class="vo-label"><span>' + esc(label || 'Age') + '</span>' + (err ? '<span class="vo-errline vo-errline--in" role="alert">' + I.alert + esc(err) + '</span>' : '') + '</legend><span class="rf-seg" role="radiogroup">' + BANDS.filter(x => !adult || x[0] !== 'u18').map(x => '<label class="rf-tog"><input type="radio" name="' + esc(nm) + '" data-band="' + esc(key) + '" value="' + x[0] + '"' + (cur === x[0] ? ' checked' : '') + (err ? ' aria-invalid="true"' : '') + '><span>' + I.check + esc(x[1]) + '</span></label>').join('') + '</span></fieldset>';
  }

  /* ---------------------------------------------------------------- who's helping: the people this person may sign up */

  const hh = () => (live().household && live().household.people) || [];
  const myEmail = () => low(me() && me().email);
  const fullName = n => /\s/.test(String(n || '').trim());
  const myName = () => { const m = me(); return m && fullName(m.name) ? m.name.trim() : ''; };
  // The name to call this person by: theirs, or (not signed in) the one they signed up under.
  const selfName = () => myName() || (signed() ? '' : ((mine().find(m => !m.added && !m.for) || {}).name || [typed().first, typed().last].filter(Boolean).join(' ')));
  const personOf = n => hh().find(p => low(p.name) === low(n)) || null;
  // Each person has one key, mechanically: "me"; a name under this email ("n:…"); or an email and a
  // name for someone added by their own email ("e:…|…"). Never a guess that two names are one person.
  const keyOf = (name, email) => { const e = low(email); if (e && e !== myEmail()) return 'e:' + e + '|' + low(name); return selfName() && low(name) === low(selfName()) ? 'me' : 'n:' + low(name); };
  const keyOfMine = m => keyOf(m.name, m.added ? m.email : '');
  // Your own places (not those of people you signed up): what Show my name changes.
  const selfRecs = () => mine().filter(m => !m.added && (!m.for || (selfName() && low(m.name) === low(selfName()))));
  function circle() {
    const out = [], seen = new Set();
    const push = p => { if (!seen.has(p.k)) { seen.add(p.k); out.push(p); } };
    const self = myName();
    if (signed() && self) push({ k: 'me', name: self, self: true, info: personOf(self) });
    if (signed()) {
      hh().forEach(p => { if (low(p.name) !== low(self)) push({ k: 'n:' + low(p.name), name: p.name, info: p }); });
      (live().circle || []).forEach(c => push({ k: keyOf(c.name, c.email), name: c.name, email: c.email && low(c.email) !== myEmail() ? c.email : '', info: c.email ? null : personOf(c.name), band: c.band || '' }));
    }
    // An emailed link (a place opened, your shifts again) vouches for its email and names its people.
    if (vouched()) (state.link.names || []).forEach(n => push({ k: 'n:' + low(n), name: n, info: null }));
    // Not signed in: the others this tab signed up (its own places), to tick again on the next shift (a
    // contact signing up a family for several, Oct 15).
    if (!signed()) mine().forEach(m => { const k = keyOfMine(m); if (k !== 'me' && m.name) push({ k, name: m.name, email: m.added ? m.email : '', info: null, minor: !!m.minor, band: m.band || '' }); });
    state.added.forEach(push);
    return out;
  }
  // The first time (not signed in, no emailed link): name, email and phone in the row; that's one person.
  const formSelf = () => !signed() && !vouched();
  // "For someone else" (Michael, Oct 15: a district helper signs up others without being on the shift):
  // the first-time block is then the contact only (name, email, phone), never counted or put on the shift;
  // those added with Add someone go on. Signed in, unticking yourself does the same.
  const contactOnly = () => formSelf() && !!(state.me1 && state.me1.off);
  // Signed in without a full name yet (and no household to pick from): the name is asked once.
  const nameSelf = () => signed() && !myName() && !hh().length;
  const selfCount = () => (formSelf() && !contactOnly()) || nameSelf() ? 1 : 0;
  const kindWords = info => !info ? '' : info.yf ? 'Youngfolk' + (info.years != null ? ' · ' + info.years : '') : info.years != null && info.years < 18 ? 'Child · ' + info.years : 'Adult';
  // What keeps a person off this shift: on it already, the rule (an age the registration gives), Busy.
  const clashOf = (k, sh) => mine().filter(m => m.shift !== sh.id && keyOfMine(m) === k).map(m => find(m.shift)).find(x => x && overlaps(x, sh)) || null;
  const busyWords = b => 'Busy · ' + b.role + ' ' + span(b);
  // Greyed when their age doesn't meet the rule (after the sixth critic, Oct 15), by the one age field, in
  // words that can't be read as their age (after the ninth critic, Oct 16: "Sam Garber · 21 or older" read
  // like Sam's own age): what's true of them, "Under 18" or "Under 21", or, not known, "Needs 21 or older".
  const underWords = (b, min, minor) => b === 'u18' || (!b && minor) ? 'Under 18' : b === '18' ? 'Under 21' : 'Needs ' + min + ' or older';
  function ruleWhy(p, sh) {
    const a = minAge(sh);
    if (!a || question(sh).length) return '';
    const b = bandOf(p), ok = b ? bandOk(b, a) : (p.minor && a >= 18 ? false : null);
    return ok === false ? underWords(b, a, p.minor) : '';
  }
  function whyNot(p, sh) {
    if (minesOn(sh).some(m => keyOfMine(m) === p.k)) return { why: 'On this shift' };
    const r = ruleWhy(p, sh);
    if (r) return { why: r };
    const b = clashOf(p.k, sh);
    return b ? { why: busyWords(b), busy: b } : null;
  }
  const notHere = (p, sh) => !AW(sh) && p.info && p.info.days && p.info.days.length && p.info.days.indexOf(sh.day.date) < 0;
  const picked = sh => circle().filter(p => state.pick.indexOf(p.k) > -1 && !whyNot(p, sh));
  // How many go on with this Sign up: those ticked, yourself the first time (not when adding to a shift
  // you're on), and someone being typed into Add someone.
  const pickN = sh => picked(sh).length + (adding(sh) ? 0 : selfCount()) + (pendAdd() ? 1 : 0);
  // The same job at the same exact time on the committee's other days (golf carts 6:15 AM–2:30 PM,
  // Saturday to Tuesday): "Also on", a tap a day, in the one Sign up. Mechanical: the same committee,
  // job, start and end; nothing is guessed.
  const sameTime = sh => AW(sh) ? [] : state.shifts.filter(x => x !== sh && !AW(x) && x.committee === sh.committee && x.role === sh.role && x.start === sh.start && x.end === sh.end && eve(x) !== eve(sh)).sort((a, b) => sortKey(a) - sortKey(b));
  // Why a day can't be added for the people chosen: not open, too few places, or one of them can't.
  function alsoWhy(x, sh) {
    // The days the chosen people already have say so (after the fifth critic, Oct 15).
    const ps = picked(sh), onx = ps.filter(p => minesOn(x).some(m => keyOfMine(m) === p.k));
    if (ps.length && onx.length === ps.length) return 'Signed up';
    if (onx.length) return listAnd(onx.map(p => first(p.name))) + ' · Signed up';
    if (!joinable(x)) return stateWord(st(x)) || 'Full';
    const n = pickN(sh);
    if (!x.unlimited && open(x) < Math.max(1, n)) return open(x) ? plural(open(x), 'place') + ' left' : 'Full';
    const p = picked(sh).map(q => ({ q, w: whyNot(q, x) })).find(z => z.w);
    return p ? first(p.q.name) + ' · ' + p.w.why : '';
  }
  const alsoOn = sh => state.also.map(find).filter(x => x && sameTime(sh).indexOf(x) > -1 && !alsoWhy(x, sh));

  /* ---------------------------------------------------------------- render */

  function render() {
    root.removeAttribute('aria-busy');
    const posted = live().posted || closed() || q.get('preview') === '1';
    let body;
    state.gridNow = false;
    if (!state.shifts.length || !posted) body = notPosted();
    else if (state.committee && (state.committee === '*' || committees().indexOf(state.committee) > -1)) body = listView();
    else { state.committee = ''; body = homeView(); }
    // The week grid takes the whole width: Your week is then the bar and its sheet, as on a phone (its
    // calendar is the grid itself; the sheet keeps Leave, Calendar, Show my name and the rest).
    const grid = posted && state.gridNow;
    const side = !grid && showWeek();
    document.body.classList.toggle('vo-gridmode', grid);
    // A signed-in returner's "Your 2026 shifts", above the committees (the emailed link draws its own).
    const ag = !state.committee && posted && signed() && !(state.link && state.link.a === 'again' && state.link.again) ? againCard(live().again || [], false) : '';
    root.innerHTML = '<div class="wk vol vo' + (pbarOn() ? ' has-pbar' : '') + (grid ? ' vo--grid' : !side && state.committee ? ' vo--narrow' : '') + '">' + band() + '<section class="vo-stage"><div class="wk-wrap vo-grid' + (side ? '' : ' vo-grid--one') + '"><div class="vo-main">' + linkCard() + ag + body + '</div>' +
      (side ? '<aside class="vo-side" aria-label="' + esc(weekWord()) + '">' + weekCard() + '</aside>' : '') + '</div></section></div>';
    document.title = (state.committee === '*' ? 'All shifts – ' : state.committee ? state.committee + ' – ' : '') + 'Volunteer – ' + state.year + ' Annual Conference – Old German Baptist Brethren Church, New Conference';
    pbarDraw();
    if (wsheet.open) drawSheet();
    fitCal();
    fitBtns();
    if (grid) fitGrid();
  }
  // A button that says the people ("Sign up · Edna and Walter") keeps to one line: measured, and only if
  // it can't fit, the next shorter form from its data-fit list ("Sign up · 2 people", "Sign up 2").
  function fitBtns(scope) {
    (scope || root).querySelectorAll('[data-fit]').forEach(b => {
      let alts = [];
      try { alts = JSON.parse(b.dataset.fit || '[]'); } catch (e) { return; }
      for (let i = 0; i < alts.length && b.scrollWidth > b.clientWidth + 1; i++) b.textContent = alts[i];
    });
  }
  // Your week is drawn only when there's something real in it (never an empty frame; after the critic,
  // Oct 15): shifts or waits of yours, or (on a laptop, beside the list) the posted services to fit a
  // shift around. The phone's bar: only your own shifts and waits.
  const shiftsUp = () => !!(state.shifts.length && !closed() && (live().posted || q.get('preview') === '1'));
  const haveMine = () => !!(mine().some(m => find(m.shift)) || (live().waits || []).some(w => find(w.shift)) || pendAll().length);
  const showWeek = () => shiftsUp() && (haveMine() || services().length > 0);
  const pbarOn = () => shiftsUp() && haveMine();

  // The band: which Conference, the page's name, and who the page thinks you are.
  function band() {
    const s = S(), r = state.row, c = state.committee;
    const where = r.city || s.city || '';
    const when = r.start ? O.fmtDateSpan(r.start, r.end) : '';
    const list = c === '*' ? state.shifts : state.shifts.filter(sh => sh.committee === c);
    let t;
    if (c) {
      // What every shift of the committee shares, said once here, not on each row: the job, the place,
      // the rule. Then the committee's one instruction (its head's or the COA's words).
      const f = c === '*' ? null : shared(c);
      const fl = f ? [f.role ? '<span class="vo-fact">' + esc(f.role) + '</span>' : '', f.place ? '<span class="vo-fact">' + I.pin + '<span>' + esc(f.place.name) + '</span></span>' : '', f.rule ? '<span class="vo-fact vo-rule">' + esc(f.rule) + '</span>' : ''].filter(Boolean) : [];
      const ins = c === '*' || closed() ? '' : instructionOf(c);
      // On a phone the way back and the kicker are one line (after the fifth critic, Oct 15: about 570 px
      // of header came before the first shift at 390).
      // Back names where it goes, the same words at every width (B10; Oct 24: no breadcrumb beside it).
      const backTo = esc(state.year) + ' Annual Conference · Volunteer' + (closed() ? ' · Closed' : '');
      t = '<a class="vo-back vo-back--wide" href="?year=' + esc(state.year) + '" data-go="">' + I.back + '<span>' + backTo + '</span></a>' +
        '<a class="vo-back vo-back--k" href="?year=' + esc(state.year) + '" data-go="">' + I.back + '<span>' + backTo + '</span></a>' +
        '<h1 class="vo-title" tabindex="-1">' + (c === '*' ? 'All shifts' : '<span class="vo-title__ic">' + ci(c) + '<span>' + esc(c) + '</span></span>') + '</h1>' +
        // Each fact brings its own dot, clipped at the start of a line (no stray "·" when it wraps at 390).
        (fl.length ? '<p class="vo-facts"><span class="vo-facts__in">' + fl.join('') + '</span></p>' : '') +
        (ins ? '<p class="vo-instr">' + I.info + '<span>' + esc(ins) + '</span></p>' : '');
    } else {
      // A way back to the Conference page (Caleb, Nov 3: arriving here from registering, nothing said
      // where to go next), as the receipt's back to Your sign-ups.
      t = '<a class="vol-back" href="' + esc((W.base || '/annual-conference/') + '?year=' + encodeURIComponent(state.year) + keepQ()) + '">' + I.back + '<span>Conference page</span></a>' +
        '<p class="wk-kicker">' + esc(state.year) + ' Annual Conference</p><h1 class="vo-title" tabindex="-1">Volunteer</h1>' +
        (when ? '<p class="vo-when">' + esc(when) + (where ? ' · ' + esc(where) : '') + '</p>' : r.hosts ? '<p class="vo-when">' + esc(/^hosted/i.test(r.hosts) ? r.hosts : 'Hosted by the ' + r.hosts) + '</p>' : '') +
        (live().closes && !closed() ? '<p class="vo-when">Closes ' + esc(O.fmtDate(live().closes, 'md')) + '</p>' : '');
    }
    // Inside the page's width: a list with no Your week beside it keeps a laptop's line length, and the
    // band ends where the list does ("Sign in" lines up with Hide full; after the second critic, Oct 15).
    // A visitor's "Sign in" on a committee's page sits on the filters' line on a phone (the band ends sooner).
    const short = c && !me() && !mine().length;
    return '<header class="vo-band' + (c ? ' vo-band--c' : '') + '"><div class="wk-wrap"><div class="vo-band__in"><div class="vo-band__t">' + t + '</div><p class="vo-meta' + (short ? ' vo-meta--signin' : '') + '">' + idLine() + '</p></div></div></header>' + (list && !list.length && c && c !== '*' ? '' : '');
  }
  // Who the page thinks you are, with a way out on a shared device; or Sign in.
  // Your sign-ups for this page's year, keeping a previewed date and time zone (?as-of, ?tz), as the
  // Conference page's Register and Volunteer do (COA rehearsal, Oct 28: the preview's date was lost there).
  const keepQ = () => { const p = new URLSearchParams(location.search); return ['as-of', 'tz'].map(k => p.get(k) ? '&' + k + '=' + encodeURIComponent(p.get(k)) : '').join(''); };
  const mineHref = () => (W.base || '/annual-conference/') + 'register/?view=mine&year=' + encodeURIComponent(state.year) + keepQ();
  function idLine() {
    const m = me(), ret = encodeURIComponent(location.pathname + location.search);
    const signin = (W.signin || '/annual-conference/signin/') + '?return=' + ret;
    if (m && m.signed) {
      // Your sign-ups, one quiet link beside the name (after the seventh critic, Oct 15: nothing on the
      // volunteer page led there).
      // On a phone the two links take their own line, so no dot is left at a line's end (L2).
      return '<span class="vo-meta__line">' + (myName() ? '<b>' + esc(myName()) + '</b> · ' : '') + '<span class="vo-meta__em">' + esc(m.email) + '</span><span class="vo-meta__acts"><span class="vo-meta__sep"> · </span><a href="' + esc(mineHref()) + '">Your sign-ups</a> · <button type="button" class="wk-linklike" data-signout>Not you?</button></span></span>';
    }
    // Say only what's true (after the fifth critic, Oct 15: an emailed link proved the address and signed
    // up confirmed places, yet the header said "Check your email"): unconfirmed places of this address,
    // "Check your email"; confirmed ones, "Signed up".
    if ((m && m.email) || mine().length) {
      const own = mine().filter(x => !x.added), word = own.some(x => !x.confirmed) ? 'Check your email' : own.length ? 'Signed up' : '';
      return '<span class="vo-meta__line">' + (m && m.email ? esc(masked(m.email)) + ' · ' : '') + (word ? word + ' · ' : '') + '<button type="button" class="wk-linklike" data-forget>Not you?</button></span>';
    }
    return '<span class="vo-meta__line"><a href="' + esc(signin) + '">Sign in</a></span>';
  }

  // Nothing posted is said as that; a year with no shifts shows its own name and hosts.
  function notPosted() {
    const asked = kept.get('asked-' + state.year, false);
    const opens = live().opens;
    return '<section class="vol-blank"><h2 class="vol-blank__h">' + (opens ? 'Opens ' + esc(O.fmtDate(opens, 'md')) : 'Not posted yet') + '</h2>' +
      (asked ? '<p class="vol-blank__p">' + I.check + 'We’ll email you</p>'
        : '<form class="vol-notify" data-notify novalidate>' + (signed() ? '' : '<label class="vol-f"><span>Email</span><input name="email" type="email" autocomplete="email" inputmode="email"><small class="vol-err" hidden></small></label>') +
          '<input class="vol-hp" name="hp" tabindex="-1" autocomplete="off" aria-hidden="true"><button type="submit" class="wk-btn wk-btn--small">' + I.mail + 'Email me when it opens</button></form>') + '</section>';
  }

  // A link from an email, answered at the top of the page.
  function linkCard() {
    const k = state.link;
    if (!k) return '';
    const box = (h, p, act) => '<section class="vol-note" role="status"><p class="vol-note__h">' + h + '</p>' + (p ? '<p class="vol-note__p">' + p + '</p>' : '') + (act || '') + '</section>';
    if (k.error) return box('Link expired', 'Sign in to see your sign-ups.', '<p><a class="wk-btn wk-btn--small" href="' + esc((W.signin || '') + '?return=' + encodeURIComponent(location.pathname + '?year=' + state.year)) + '">Sign in</a></p>');
    if (k.a === 'confirm') {
      // The link's own person has left every one of its shifts since (after the fourth critic, Oct 15:
      // Miriam's used Confirm link, opened again, said "Confirmed · Usher · Sat, May 29 · Glen"): what's
      // true, never "Confirmed" for her. "Miriam left" · "Usher · Sat, May 29 · Glen is still on it".
      const gc = goneCard(k);
      if (gc) return box(esc(gc.h), gc.lines.map(esc).join('<br>'));
      // Someone added by another person confirms here; their phone is asked now (Add someone asks only a
      // name and an email), for the committee head.
      const need = signed() && !me().phone && mine().some(m => !m.added && m.nophone);
      // What was just confirmed, a shift a line with its people ("Server · Sat, May 29 · Martha and
      // Henry"), never "2 shifts" for a couple's one.
      const just = byShift(mine().filter(m => m.fresh)), lines = (k.follow ? followLines(k) : just.length ? just.map(g => shiftLine(g.sh, g.ms)) : (k.lines || [])).map(esc);
      const what = lines.length ? lines.join('<br>') : esc(plural(k.n || 1, 'shift'));
      if (k.phoneSaved) return box(I.check + 'Confirmed', what + '<br>Phone saved');
      const shown = names() && selfRecs().length && selfRecs().every(m => m.confirmed && !m.hide && !m.minor && (!m.for || m.shown));
      // Said truly for each of yours on it (after the third critic, Oct 15: a spouse added on the same
      // email is hidden until shown): "Harold's name hidden · Show". Several (a contact's family, after the
      // sixth critic) are one line, "Names hidden · Show all": one tap shows every adult of them. Under 18
      // is never named, so never offered.
      const freshOnes = mine().filter(m => m.fresh), others = uniq((freshOnes.length ? freshOnes : mine()).filter(m => selfRecs().indexOf(m) < 0 && !m.added && !m.minor && m.band !== 'u18' && !m.shown).map(m => m.name));
      const nowShown = (state.shownNow || []).filter(n => others.indexOf(n) < 0);
      // One plain line, what's true first (after the eighth critic, Oct 16: "Harold's name hidden · Show"
      // read oddly right after confirming): "Martha’s name shows · Harold’s doesn’t · Show Harold’s";
      // several, "Names don’t show · Show all"; once shown, "Harold’s name shows". People named, never
      // "Your name" (after the sixth critic).
      const selfShows = !need && shown && !!selfName();
      const bits = [];
      if (selfShows) bits.push(esc(first(selfName())) + '’s name shows');
      if (names() && !need) {
        if (others.length > 1) bits.push('Names don’t show · <button type="button" class="wk-linklike" data-showall="' + esc(JSON.stringify(others)) + '">Show all</button>');
        else if (others.length) bits.push(esc(first(others[0])) + (selfShows ? '’s doesn’t' : '’s name doesn’t show') + ' · <button type="button" class="wk-linklike" data-shownow="' + esc(others[0]) + '">' + esc('Show ' + first(others[0]) + '’s') + '</button>');
        if (nowShown.length) bits.push(esc(nowShown.length > 1 ? 'Names show · ' + listAnd(nowShown.map(first)) : first(nowShown[0]) + '’s name shows'));
      }
      return box(I.check + 'Confirmed', what + (bits.length ? '<br>' + bits.join(' · ') : ''),
        need ? '<form class="vo-phone" data-phoneform novalidate><label class="vo-in' + (state.err.cphone ? ' is-bad' : '') + '"><span>Phone</span><input name="phone" type="tel" autocomplete="tel" inputmode="tel"' + (state.err.cphone ? ' aria-invalid="true"' : '') + '><small class="' + (state.err.cphone ? '' : 'is-help') + '">' + esc(state.err.cphone || 'For the committee’s foreman') + '</small></label><button type="submit" class="wk-btn wk-btn--small">Save</button></form>' : '');
    }
    if (k.a === 'notme') return box('Removed', ((k.lines || []).length ? k.lines.map(esc).join('<br>') + '<br>' : '') + 'Under ' + esc(k.email) + ' · The committee’s foreman is told');
    if (k.a === 'unnotify') return box('Removed', 'No email when sign-ups open');
    if (k.a === 'leave') return linkLeaveCard(k, box);
    // The "Sign-ups open" email's Sign up again: the same card a signed-in returner gets (after the fifth
    // critic, Oct 15), each shift with only its own people from last year.
    if (k.a === 'again' && k.again) return k.done ? '' : againCard(k.again, true);
    if (k.a === 'again' || k.a === 'opened') {
      const shs = (k.shifts || []).map(find).filter(Boolean);
      if (k.done) return '';
      if (k.unwaited) return box('Off the waitlist', shs.map(sh => esc(sh.role + ' · ' + whenShort(sh))).join('<br>'));
      return box(k.a === 'opened' ? 'A place opened' : 'Your ' + (state.year - 1) + ' shifts', shs.map(sh => esc(sh.role + ' · ' + whenShort(sh) + ' · ' + openText(sh))).join('<br>'),
        '<p class="vol-note__btns"><button type="button" class="wk-btn wk-btn--small" data-linkjoin>' + (shs.length > 1 ? 'Sign up · ' + plural(shs.length, 'shift') : 'Sign up') + '</button>' +
        (k.a === 'opened' && k.waiting ? '<button type="button" class="wk-linklike" data-linkunwait>Leave waitlist</button>' : '') + '</p>');
    }
    return '';
  }
  const openText = sh => sh.unlimited ? 'No limit' + (L(sh).f ? ' · ' + L(sh).f + ' signed up' : '') : open(sh) > 0 ? open(sh) + ' open' : 'Full';

  /* ---------------------------------------------------------------- Your 2026 shifts: a returner's card */

  // Last year's shifts, each matched to this year's by its carried ID (the server's ogc_vol_again_view),
  // with this year's day, time and state, and only the people who were on it from this email, ticked
  // (after the fifth critic, Oct 15: the page never drew it, and the email's link opened the first row
  // with every name from all three shifts). One Sign up for every open one; a full one offers Join
  // waitlist; Busy and too young are said and never ticked; a rule is asked in place, for its shift only.
  // Signed in it shows on the committees' page; the emailed link draws the same card. Once done (or with
  // nothing left to take) it goes. Mechanical: the server's matches and states, nothing guessed.
  const AG = () => state.ag || (state.ag = { off: {}, offp: {}, ans: {}, err: {}, busy: '', done: false, phone: '', needPhone: false, foot: '' });
  const agEntries = () => state.link && state.link.a === 'again' && state.link.again ? state.link.again : signed() ? (live().again || []) : [];
  const agVia = () => state.link && state.link.a === 'again' && state.link.again ? state.link.via : null;
  // A person's age on the card: answered here (once, for every row), else as the server knows it.
  const agBand = (e, n) => state.bands['n:' + low(n)] || ((e && e.bands) || {})[n] || '';
  const agAsk = (e, ppl) => {
    // What a shift asks before the people go on, in place: its certification, the screening, or a rule in
    // words. An age is each person's own, asked once for the whole card (agAgeHtml; after the sixth
    // critic, Oct 15: "Hannah is 21 or older" was asked on every row).
    const sh = find(e.shift);
    if (!sh) return null;
    if (question(sh).length) return { kind: 'question', opts: question(sh) };
    const out = [];
    if (sh.rule && !minAge(sh)) {
      const need = ppl.filter(n => (e.aged || []).indexOf(n) < 0);
      if (need.length) out.push({ kind: 'claim', text: sh.rule });
    }
    if (screening(sh)) out.push({ kind: 'screen' });
    return out.length ? out : null;
  };
  // Each of last year's shifts as it stands for these people now.
  function agRows() {
    const g = AG();
    const rows = agEntries().map(e => {
      const sh = e.shift ? find(e.shift) : null;
      if (!sh) return { e, sh: null, kind: 'gone' };
      const people = (e.people || e.names || []).filter(Boolean), on = e.on || [], busy = e.busy || {};
      // Too young for its rule, by each one's age (the server's, or answered on the card).
      const under = uniq((e.under || []).filter(n => !state.bands['n:' + low(n)]).concat(minAge(sh) ? people.filter(n => bandOk(agBand(e, n), minAge(sh)) === false) : []));
      const free = people.filter(n => on.indexOf(n) < 0 && !busy[n] && under.indexOf(n) < 0);
      const s = e.st || st(sh), o = e.o == null ? Infinity : e.o;
      let kind;
      if (people.length && on.length >= people.length) kind = 'on';
      else if (!free.length) kind = 'blocked';
      else if (s === 'full' || (s === 'open' && o < 1)) kind = free.every(n => (e.waiting || []).indexOf(n) > -1) ? 'waiting' : 'full';
      else if (s !== 'open') kind = 'state';
      else kind = 'open';
      const offp = g.offp[e.shift] || [];
      const chosen = kind === 'open' && !g.off[e.shift] ? free.filter(n => offp.indexOf(n) < 0) : [];
      const a = g.ans[e.shift] || {};
      const asks = kind === 'open' ? agAsk(e, chosen.length ? chosen : free) : null;
      return { e, sh, kind, people, on, busy, under, free, chosen, o, s, asks, a, clash: {} };
    });
    // Two of last year's shifts at the same time this year: a person ticked on both goes on the first, and
    // the later says Busy for them (as the server would).
    const taken = {};
    rows.filter(r => r.sh).sort((x, y) => sortKey(x.sh) - sortKey(y.sh)).forEach(r => {
      r.chosen = r.chosen.filter(n => { const hit = (taken[n] || []).find(x => overlaps(x, r.sh)); if (hit) r.clash[n] = hit.role + ' ' + span(hit); return !hit; });
      r.chosen.forEach(n => (taken[n] = taken[n] || []).push(r.sh));
      if (r.kind === 'open' && !r.chosen.length && Object.keys(r.clash).length && !AG().off[r.sh.id]) r.kind = 'blocked';
    });
    return rows;
  }
  const agTake = rows => rows.filter(r => r.kind === 'open' && r.chosen.length);
  // Anything left to take (an open shift with someone free, or a full one to wait on).
  const agAny = rows => rows.some(r => r.kind === 'open' || r.kind === 'full');
  function agLabel(rows) {
    const t = agTake(rows), ns = uniq([].concat(...t.map(r => r.chosen.map(first))));
    const many = ns.length > 3 || uniq([].concat(...t.map(r => r.chosen))).length !== ns.length;
    const who = many ? plural(uniq([].concat(...t.map(r => r.chosen))).length, 'person', 'people') : listAnd(ns);
    const n = t.length;
    // Too long for one line at 390: the people first ("Sign up · Ruth and Amos"), then the count.
    return { full: 'Sign up · ' + who + (n > 1 ? ' · ' + n + ' shifts' : ''), alts: n > 1 ? ['Sign up · ' + who, 'Sign up · ' + n + ' shifts', 'Sign up'] : ['Sign up · ' + plural(uniq([].concat(...t.map(r => r.chosen))).length, 'person', 'people'), 'Sign up'] };
  }
  function againCard(entries, viaLink) {
    const g = AG();
    if (g.done || closed() || !entries || !entries.length || kept.get('agdone-' + state.year, false)) return '';
    const rows = agRows();
    if (!agAny(rows)) return '';
    const title = 'Your ' + (state.year - 1) + ' shifts';
    if (!viaLink && kept.get('agfold-' + state.year, false)) {
      return '<section class="vo-agfold"><span>' + esc(title) + '</span><button type="button" class="vo-link" data-agshow>Show</button></section>';
    }
    const take = agTake(rows), lab = agLabel(rows);
    const li = r => {
      const sh = r.sh;
      if (!sh) return '<li class="vo-ag is-gone"><span class="vo-ag__t"><b>' + esc(String(r.e.was || '').split(' · ')[0]) + '</b><small>' + esc(String(r.e.was || '').split(' · ').slice(1).join(' · ') + ' · Not in ' + state.year) + '</small></span></li>';
      const when = whenShort(sh), job = sh.role, com = SU.jobSaid(sh.role, sh.committee) ? '' : sh.committee;
      const stw = r.kind === 'on' ? 'Signed up' : r.kind === 'waiting' ? 'On waitlist' : r.kind === 'full' ? 'Full' : r.kind === 'state' ? (stateWord(r.s) || 'Closed') : r.kind === 'blocked' ? '' : r.o === Infinity ? 'No limit' : r.o + ' open';
      const who = r.kind === 'on' ? listAnd(r.on.map(first)) : r.kind === 'waiting' || r.kind === 'full' ? listAnd(r.free.map(first)) : r.free.length === 1 ? first(r.free[0]) : '';
      const said = [].concat(Object.keys(r.busy).filter(n => r.on.indexOf(n) < 0).map(n => first(n) + ' · Busy · ' + r.busy[n]), Object.keys(r.clash || {}).map(n => first(n) + ' · Busy · ' + r.clash[n]), r.under.map(n => first(n) + ' · ' + underWords(agBand(r.e, n), minAge(sh) || 18, false)));
      const ticked = r.kind === 'open' && r.chosen.length > 0;
      // A day and a time never break inside themselves ("11:45 AM–2:15 PM" whole), and each part brings its
      // own dot, clipped at a line's start (no "·" left at a line's end at 390; Oct 24).
      const parts = (AW(sh) ? [when] : [dayShort(sh), span(sh)]).concat(com ? [com] : []);
      const sub = '<small class="vo-ag__sub"><span class="vo-mis">' + parts.map(p => '<span class="vo-mi">' + esc(p) + '</span>').join('') + '</span></small>' + (who ? '<small class="vo-ag__who">' + esc(who) + '</small>' : '');
      let h = '<li class="vo-ag is-' + r.kind + (ticked ? ' is-ticked' : '') + '" data-ag="' + esc(sh.id) + '">';
      if (r.kind === 'open') {
        h += '<button type="button" class="vo-ag__tog" data-agtog="' + esc(sh.id) + '" aria-pressed="' + ticked + '" aria-label="' + esc([job, when, who || listAnd(r.free.map(first))].join(', ')) + '"><span class="vo-ag__box" aria-hidden="true">' + I.check + '</span><span class="vo-ag__t"><b>' + esc(job) + '</b>' + sub + '</span><span class="vo-ag__st">' + esc(stw) + '</span></button>';
      } else {
        h += '<div class="vo-ag__row"><span class="vo-ag__box is-none" aria-hidden="true">' + (r.kind === 'on' ? I.check : '') + '</span><span class="vo-ag__t"><b>' + esc(job) + '</b>' + sub + '</span>' + (stw ? '<span class="vo-ag__st">' + esc(stw) + '</span>' : '') + '</div>';
      }
      // Two or more free: a toggle a person (all on at first).
      if (r.kind === 'open' && !g.off[sh.id] && r.free.length > 1) h += '<div class="vo-ag__ppl" role="group" aria-label="' + esc('Who · ' + job) + '">' + r.free.map(n => '<button type="button" class="vo-ag__p" data-agp="' + esc(sh.id) + '" data-n="' + esc(n) + '" aria-pressed="' + (r.chosen.indexOf(n) > -1) + '">' + I.check + esc(first(n)) + '</button>').join('') + '</div>';
      if (said.length && r.kind !== 'on') h += '<p class="vo-ag__said">' + said.map(esc).join('<br>') + '</p>';
      // Asked in place, for this shift only.
      if (r.kind === 'open' && !g.off[sh.id] && r.asks) h += agAskHtml(r);
      if (r.kind === 'full') h += '<p class="vo-ag__acts"><button type="button" class="vo-link" data-agwait="' + esc(sh.id) + '"' + (g.busy ? ' disabled' : '') + '>' + (g.busy === 'wait:' + sh.id ? 'Joining…' : 'Join waitlist') + '</button></p>';
      if (g.err[sh.id]) h += '<p class="vo-errline" role="alert">' + I.alert + esc(g.err[sh.id]) + '</p>';
      return h + '</li>';
    };
    // The phone the head will see, when none is known yet for this email.
    const phoneAsk = take.length && (g.needPhone || (signed() && !(me() && me().phone)) || (viaLink && state.link && state.link.has_phone === false));
    const btnCls = 'wk-btn' + (state.open ? ' wk-btn--line' : '');
    return '<section class="vol-note vo-again" aria-labelledby="vo-ag-h"><div class="vo-again__top"><h2 class="vol-note__h" id="vo-ag-h">' + esc(title) + '</h2>' +
      (viaLink ? '' : '<button type="button" class="vo-link vo-again__x" data-agfold>Not now</button>') + '</div>' +
      '<ul class="vo-again__l">' + rows.map(li).join('') + '</ul>' + agAgeHtml(rows) +
      (phoneAsk ? '<div class="vo-again__phone">' + fld('agp', 'phone', 'Phone', 'tel', 'For the committee’s foreman', ' autocomplete="tel" inputmode="tel"') + '</div>' : '') +
      (take.length ? '<div class="vo-again__foot">' + (g.foot ? '<p class="vo-errline" role="alert">' + I.alert + esc(g.foot) + '</p>' : '') +
        '<button type="button" class="' + btnCls + '" data-agjoin data-fit="' + esc(JSON.stringify(lab.alts)) + '"' + (g.busy ? ' disabled' : '') + '>' + esc(g.busy === 'join' ? 'Signing up…' : lab.full) + '</button></div>' : '') +
      '</section>';
  }
  // Each person ticked whose age isn't known (or only "18 or older" for a 21-or-older shift): asked once,
  // by name, for every row of the card.
  function agAgeNeed(rows) {
    const out = [];
    agTake(rows).forEach(r => r.chosen.forEach(n => { if (out.indexOf(n) < 0 && needsBand(agBand(r.e, n), r.sh)) out.push(n); }));
    return out;
  }
  // An age once asked stays where it is, its answer chosen (after the ninth critic, Oct 16: answering
  // Daniel's age took his question away and moved Esther's pills 71 px under the finger): asked once, then
  // kept in place, a tap to change, until the card is done. Who's asked stays while they're ticked on a
  // shift, or kept off one by their answer (so a wrong tap can be put right).
  function agAgeHtml(rows) {
    const g = AG();
    g.asked = g.asked || [];
    agAgeNeed(rows).forEach(n => { if (g.asked.indexOf(n) < 0) g.asked.push(n); });
    const take = agTake(rows), on = n => take.some(r => r.chosen.indexOf(n) > -1) || rows.some(r => r.kind !== 'gone' && r.under.indexOf(n) > -1);
    const show = g.asked.filter(on);
    if (!show.length) return '';
    // A registration's Adult (the server's word, not this card's answer) is asked only 18–20 or 21 or older.
    const r0 = n => rows.find(r => r.sh && r.people.indexOf(n) > -1);
    const adult = n => { const r = r0(n); return !!r && ((r.e.bands || {})[n] === 'adult'); };
    return '<div class="vo-again__ages">' + show.map(n => ageSeg('k:n:' + low(n), state.bands['n:' + low(n)] || '', first(n) + ' · Age', g.err['age:' + n], adult(n))).join('') + '</div>';
  }
  function agAskHtml(r) {
    const sh = r.sh, a = r.a, e = AG().err[sh.id + ':ask'], nm = 'ag-' + sh.id;
    const radios = (name, opts, cur) => '<span class="rf-seg" role="radiogroup">' + opts.map(x => '<label class="rf-tog"><input type="radio" name="' + esc(name) + '" data-agans="' + esc(sh.id) + '" value="' + esc(x[0]) + '"' + (cur === x[0] ? ' checked' : '') + (e ? ' aria-invalid="true"' : '') + '><span>' + I.check + esc(x[1]) + '</span></label>').join('') + '</span>';
    if (!Array.isArray(r.asks)) return '<fieldset class="vo-q vo-ag__q"><legend class="vo-label">Certification</legend>' + radios(nm + '-q', r.asks.opts.map(x => [x, x]), a.question) + (e ? '<p class="vo-errline">' + I.alert + esc(e) + '</p>' : '') + '</fieldset>';
    return r.asks.map(x => {
      if (x.kind === 'age') {
        const ns = x.who.map(first), words = x.age + ' or older';
        const yes = ns.length === 1 ? ns[0] + ' is ' + words : listAnd(ns) + ' are ' + words;
        const no = ns.length === 1 ? ns[0] + ' is under ' + x.age : 'One of them is under ' + x.age;
        return '<fieldset class="vo-q vo-ag__q"><legend class="vo-label">' + esc(words) + '</legend>' + radios(nm + '-age', [['yes', yes], ['under', no]], a.age) + (e && a.age == null ? '<p class="vo-errline">' + I.alert + esc(e) + '</p>' : '') + '</fieldset>';
      }
      if (x.kind === 'claim') return '<label class="vo-claim vo-ag__q"><input type="checkbox" data-agans="' + esc(sh.id) + '" name="' + esc(nm) + '-claim"' + (a.claim ? ' checked' : '') + '><span>' + esc(x.text) + '</span></label>' + (e && !a.claim ? '<p class="vo-errline">' + I.alert + esc(e) + '</p>' : '');
      return '<fieldset class="vo-q vo-ag__q"><legend class="vo-label">Child-safety screening</legend>' + radios(nm + '-scr', [['yes', 'Screened'], ['not_yet', 'Not yet']], a.screened) + (e && !a.screened ? '<p class="vo-errline">' + I.alert + esc(e) + '</p>' : '') + '</fieldset>';
    }).join('');
  }
  // Every row's answers, checked here first (the server checks again).
  function agCheck(rows) {
    const g = AG();
    let bad = '';
    agTake(rows).forEach(r => {
      delete g.err[r.sh.id + ':ask'];
      const a = r.a;
      const miss = !r.asks ? false : !Array.isArray(r.asks) ? !a.question : r.asks.some(x => x.kind === 'claim' ? !a.claim : !a.screened);
      if (miss) { g.err[r.sh.id + ':ask'] = 'Choose one'; bad = bad || r.sh.id; }
    });
    Object.keys(g.err).forEach(k => { if (/^age:/.test(k)) delete g.err[k]; });
    agAgeNeed(rows).forEach(n => { g.err['age:' + n] = 'Choose one'; bad = bad || 'age'; });
    if (agTake(rows).length && (g.needPhone || (signed() && !(me() && me().phone)) || (agVia() && state.link.has_phone === false)) && String(state.agp && state.agp.phone || '').replace(/\D/g, '').length < 7) { state.err['agp.phone'] = 'A phone number'; bad = bad || 'phone'; }
    return bad;
  }
  async function agJoin() {
    const g = AG();
    if (g.busy) return;
    const rows = agRows(), take = agTake(rows);
    if (!take.length) return;
    g.foot = '';
    const bad = agCheck(rows);
    if (bad) { render(); const x = root.querySelector('.vo-again [aria-invalid="true"], .vo-again .vo-in.is-bad input'); if (x) { x.focus({ preventScroll: true }); x.scrollIntoView({ block: 'center' }); } return; }
    g.busy = 'join'; redraw('[data-agjoin]');
    const via = agVia(), phone = String(state.agp && state.agp.phone || '').trim();
    const made = [], nos = [];
    // One request for the whole card (after the seventh critic, Oct 15: a request a shift took 4 s for
    // eight, and closing the tab part way left some unsaved): each shift with its own people and answers
    // (POST vol/{y}/join › each). Twelve at most a request; the server takes all of a request before it
    // answers, and says each shift's own result.
    const each = take.map(r => {
      const e = { shift: r.sh.id, people: r.chosen, answers: {} }, bands = {};
      r.chosen.forEach(n => { const bd = agBand(r.e, n); if (BANDS.some(x => x[0] === bd)) bands[n] = bd; });
      if (Object.keys(bands).length) e.bands = bands;
      if (question(r.sh).length) e.answers.question = r.a.question;
      else if (r.sh.rule) e.answers.rule = true;
      if (screening(r.sh)) e.answers.screened = r.a.screened;
      return e;
    });
    for (let i = 0; i < each.length; i += 12) {
      const part = each.slice(i, i + 12), b = { each: part, show: true };
      if (phone) b.who = { phone };
      if (via) Object.assign(b, via);
      let d;
      try { d = await post('vol/' + state.year + '/join', b); }
      catch (err) {
        if (err.data && err.data.why === 'fields' && (err.data.fields || {}).phone) { g.needPhone = true; state.err['agp.phone'] = 'A phone number'; break; }
        part.forEach(e => { const sh = find(e.shift); nos.push(sh.role + ' · ' + dayShort(sh) + ' · ' + (err.status === 429 ? 'Too many at once' : 'Not saved')); });
        continue;
      }
      merge(d);
      (d.made || []).forEach(id => made.push(id));
      (d.results || []).filter(x => x.status !== 'ok').forEach(x => { const sh = find(x.shift) || find(part[0].shift); nos.push(sh.role + ' · ' + dayShort(sh) + ' · ' + refusal(x, sh).msg); });
    }
    g.busy = '';
    if (!made.length) {
      g.foot = g.needPhone ? '' : nos[0] || 'Not saved · Retry';
      render();
      const x = root.querySelector('.vo-again .vo-in.is-bad input, .vo-again [data-agjoin]');
      if (x) x.focus({ preventScroll: true });
      return;
    }
    // Who's on each now, as the page shows it; then the card goes.
    await loadLive().catch(() => {});
    if (via) await relink();
    g.done = true; g.needPhone = false; g.asked = []; state.agp = {};
    kept.set('agdone-' + state.year, true);
    render();
    // The card went: back to where it stood (the committees, now marked Yours), not mid-list.
    const top = root.querySelector('.vo-main');
    if (top && top.getBoundingClientRect().top < 0) top.scrollIntoView({ block: 'start', behavior: matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth' });
    const who = mine().filter(x => made.indexOf(x.rid) > -1), groups = byShift(who), lines = groups.map(gr => shiftLine(gr.sh, gr.ms));
    showToast({ kind: 'ok', text: groups.length > 1 ? 'Signed up · ' + plural(groups.length, 'shift') : 'Signed up', lines, sub: nos.length ? 'Not ' + nos.join(', ') : '', ids: made, shifts: groups.map(gr => gr.sh.id), ics: true, again: true });
    say.textContent = 'Signed up · ' + lines.join('; ');
  }
  // A full one: its people on the waitlist (the same who as the row's own).
  // A rule's answer, in place, for its shift.
  function agAns(t) {
    const g = AG(), id = t.dataset.agans, a = g.ans[id] = g.ans[id] || {};
    if (/-q$/.test(t.name)) a.question = t.value;
    else if (/-age$/.test(t.name)) a.age = t.value;
    else if (/-scr$/.test(t.name)) a.screened = t.value;
    else if (/-claim$/.test(t.name)) a.claim = t.checked;
    delete g.err[id + ':ask']; g.foot = '';
    redraw('[data-agans="' + CSS.escape(id) + '"][name="' + CSS.escape(t.name) + '"]' + (t.type === 'radio' ? '[value="' + CSS.escape(t.value) + '"]' : ''));
  }
  async function agWait(id) {
    const g = AG(), r = agRows().find(x => x.sh && x.sh.id === id);
    if (!r || g.busy) return;
    g.busy = 'wait:' + id; redraw('[data-agwait="' + CSS.escape(id) + '"]');
    try {
      const d = await post('vol/' + state.year + '/wait', Object.assign({ shift: id, people: r.free }, agVia() || {}));
      merge(d);
      g.busy = '';
      await loadLive().catch(() => {});
      if (agVia()) await relink();
      render();
      showToast({ kind: 'ok', text: 'On waitlist', lines: [r.sh.role + ' · ' + dayShort(r.sh) + ' · ' + listAnd(r.free.map(first))], sub: 'Email when a place opens' });
      say.textContent = 'On waitlist · ' + r.sh.role;
    } catch (e) { g.busy = ''; g.err[id] = 'Not saved · Retry'; render(); }
  }

  // A link's places as they are now (the server's groups: who of its email is still on each of its shifts,
  // and who isn't), in time order.
  const groupsOf = k => (k.groups || []).map(g => ({ g, sh: find(g.shift) })).filter(x => x.sh).sort((a, b) => sortKey(a.sh) - sortKey(b.sh));
  const stillOn = on => { const ns = uniq((on || []).map(first)); return ns.length ? listAnd(ns) + (ns.length > 1 ? ' are' : ' is') + ' still on it' : ''; };
  // The link's own person (the email's own sign-up) is off every one of its shifts: what's true for them,
  // first (after the fourth critic, Oct 15: Miriam's old link opened on "Leave this shift?" with Glen's
  // place as its one action, and her old Confirm link said "Confirmed"). "Miriam left", then a line a
  // shift with who's still on it.
  function goneCard(k) {
    if (!k || !k.self || k.self_on) return null;
    const gs = groupsOf(k), mine1 = (k.gone || []).filter(x => low(x.name) === low(k.self));
    if (!gs.length || !mine1.length) return null;
    const offAll = uniq((k.gone || []).filter(x => !gs.some(y => (y.g.on || []).some(n => low(n) === low(x.name)))).map(x => first(x.name)));
    const ns = offAll.length ? offAll : [first(k.self)];
    const h = mine1.every(x => x.how === 'left') ? listAnd(ns) + ' left' : 'Off ' + (gs.length > 1 ? 'these shifts' : 'this shift') + ' · ' + listAnd(ns);
    const lines = gs.length === 1 ? [gs[0].sh.role + ' · ' + whenShort(gs[0].sh)].concat(stillOn(gs[0].g.on) ? [stillOn(gs[0].g.on)] : [])
      : gs.map(x => [x.sh.role, dayShort(x.sh), stillOn(x.g.on)].filter(Boolean).join(' · '));
    return { h, lines, others: gs.some(x => (x.g.on || []).length) };
  }
  // The Confirm card's lines from the same groups: "Usher · Sat, May 29 · Miriam and Glen", and who of the
  // link has left one since ("· Glen left").
  const followLines = k => groupsOf(k).map(x => [x.sh.role, dayShort(x.sh), whoWords((x.g.on || []).map(n => ({ name: n })))].filter(Boolean).join(' · ') + ((x.g.gone || []).length ? ' · ' + listAnd(uniq(x.g.gone.map(y => first(y.name)))) + ' left' : ''));

  // The emailed "Can't make it? Leave shift" link: the one Leave sheet (SU.leaveSheet; after the fourth
  // critic, Oct 15), as on the page and in Your sign-ups. Only the people still on it, by name; a toggle a
  // person and a toggle a shift when it covers several, all on at first; the line under them says who goes
  // ("Harold leaves"); Leave shift is the one filled button; Find replacement only for one person's one
  // place; the toast has Undo. When the link's own person has left already, it opens on that (goneCard),
  // with Done, and leaving for the others is a quiet second choice.
  const linkRecs = k => (k.records || []).filter(r => find(r.shift));
  const linkPick = k => {
    const rs = linkRecs(k);
    if (!k.ps) k.ps = uniq(rs.map(r => r.shift));
    if (!k.pp) k.pp = uniq(rs.map(r => low(r.name)));
    return rs.filter(r => k.ps.indexOf(r.shift) > -1 && k.pp.indexOf(low(r.name)) > -1);
  };
  // "Harold leaves", "Daniel, Esther and Lydia leave · 2 shifts".
  function linkLeavesWords(k) {
    const go = linkPick(k), n = uniq(go.map(r => r.shift)).length;
    if (!go.length) return k.ps && !k.ps.length ? 'Choose a shift' : 'Choose who’s leaving';
    const ns = uniq(go.map(r => first(r.name)));
    return listAnd(ns) + (ns.length === 1 ? ' leaves' : ' leave') + (n > 1 ? ' · ' + plural(n, 'shift') : '');
  }
  const linkLeaveLabel = k => { const n = uniq(linkPick(k).map(r => r.shift)).length; return n > 1 ? 'Leave ' + n + ' shifts' : 'Leave shift'; };
  // "The Transportation foreman is told"; several committees: "The committees’ foremen are told"
  // (Caleb, Oct 24: "foreman, not head"). Only when a Leave of these places now reaches the head (the server's
  // ogc_vol_leave_tells, as the Leave follows it: false for a place taken minutes ago that no email has
  // gone about yet; after the eighth critic, Oct 16). recs: the places going; none tells, no line (false).
  const headWords = (shs, recs) => {
    if (recs && recs.length && !recs.some(m => m.tells !== false)) return false;
    const cs = uniq(shs.map(sh => sh.committee)); return cs.length === 1 ? 'The ' + cs[0] + ' foreman is told' : 'The committees’ foremen are told';
  };
  function linkLeaveCard(k, box) {
    const rs = linkRecs(k);
    if (k.left) {
      // What was left, a shift a line with who left it; and who of this email is still on those shifts.
      // Said once when the same people are on every one ("Esther and Lydia are still on both").
      const sg = byShift(rs.filter(r => k.left.shifts.indexOf(r.shift) > -1)).map(g => ({ g, ns: uniq(g.ms.map(m => first(m.name))) }));
      const isAre = ns => listAnd(ns) + (ns.length > 1 ? ' are' : ' is') + ' still on ';
      const n = k.left.lines.length, same = sg.length === n && sg.every(x => x.ns.join('|') === sg[0].ns.join('|'));
      const still = same && sg.length ? [isAre(sg[0].ns) + (n === 1 ? 'it' : n === 2 ? 'both' : 'all ' + n)] : sg.map(x => isAre(x.ns) + x.g.sh.role + ' · ' + dayShort(x.g.sh));
      return box(I.check + 'Left shift', k.left.lines.concat(still).map(esc).join('<br>'));
    }
    // The link's own person left already: that first, Done; leaving for the others still on it is a
    // quiet second choice that opens the sheet with their toggles.
    const gc = !k.others ? goneCard(k) : null;
    if (gc) return '<section class="vol-note vo-gone" role="status"><p class="vol-note__h">' + esc(gc.h) + '</p><p class="vol-note__p">' + gc.lines.map(esc).join('<br>') + '</p>' +
      '<p class="vol-note__btns"><button type="button" class="wk-btn wk-btn--small" data-linkdone>Done</button>' +
      (rs.length && gc.others ? '<button type="button" class="wk-linklike" data-linkothers>' + esc('Leave for ' + listAnd(uniq(rs.map(r => first(r.name))))) + '</button>' : '') + '</p></section>';
    if (!rs.length) return box('Not signed up', 'Nothing to leave under ' + esc(k.email));
    const go = linkPick(k), groups = byShift(rs), people = uniq(rs.map(r => low(r.name)));
    if (k.swap) { const g = groups.find(x => x.ms.some(m => m.rid === k.swapRid)) || groups[0]; return box('Swap open', esc(g.sh.role + ' · ' + whenShort(g.sh)) + '<br>The place is kept until someone takes it.', '<p class="vol-note__btns"><button type="button" class="wk-btn wk-btn--small" data-linkswapcopy>' + I.link + 'Copy link</button></p>'); }
    const many = groups.length > 1;
    const nameOf = p => { const r = rs.find(x => low(x.name) === p); return rs.filter(x => first(x.name) === first(r.name) && low(x.name) !== p).length ? r.name : first(r.name); };
    return '<div class="vol-note vo-lk">' + SU.leaveSheet({
      scope: 'link', id: 'vo-lk', heading: many ? 'Leave these shifts?' : 'Leave this shift?',
      when: many ? '' : groups[0].sh.role + ' · ' + whenShort(groups[0].sh),
      shifts: many ? groups.map(g => ({ value: g.sh.id, label: g.sh.role + ' · ' + dayShort(g.sh), sub: [span(g.sh), listAnd(uniq(g.ms.map(m => first(m.name))))].join(' · '), on: k.ps.indexOf(g.sh.id) > -1 })) : [],
      people: people.length > 1 ? people.map(p => ({ value: p, label: nameOf(p), on: k.pp.indexOf(p) > -1 })) : [],
      goes: linkLeavesWords(k), head: headWords(uniq(go.map(r => find(r.shift)).filter(Boolean)), go),
      // Find replacement (the place stays theirs until someone takes it) only for one person's one place.
      swap: go.length === 1, go: linkLeaveLabel(k), busy: state.busyAct === 'linkleave', disabled: !go.length,
      keep: many ? 'Keep shifts' : 'Keep shift', err: state.footErr && state.linkErr ? state.footErr : ''
    }) + '</div>';
  }

  /* ---------------------------------------------------------------- the committees as cards */

  function homeView() {
    if (closed()) {
      const vols = helpedWords('', state.shifts);
      // A past year's one action is the next Conference: its shifts when it has them, else Email me.
      const nx = (state.years || []).find(y => +y.year === +state.year + 1);
      const next = nx && nx.data ? '<p><a class="wk-btn wk-btn--small" href="?year=' + esc(nx.year) + '">' + esc(nx.year) + ' shifts</a></p>'
        : nx ? (kept.get('asked-' + nx.year, false) ? '<p class="vol-blank__p">' + I.check + 'We’ll email you when ' + esc(nx.year) + ' opens</p>'
          : '<form class="vol-notify" data-notify="' + esc(nx.year) + '" novalidate>' + (signed() ? '' : '<label class="vol-f"><span>Email</span><input name="email" type="email" autocomplete="email" inputmode="email"><small class="vol-err" hidden></small></label>') + '<input class="vol-hp" name="hp" tabindex="-1" autocomplete="off" aria-hidden="true"><button type="submit" class="wk-btn wk-btn--small">' + I.mail + 'Email me when ' + esc(nx.year) + ' opens</button></form>') : '';
      return '<section class="vol-blank"><h2 class="vol-blank__h">Closed</h2><p class="vol-blank__p">' + esc([plural(state.shifts.length, 'shift'), vols].filter(Boolean).join(' · ')) + '</p>' + next + '</section>' +
        '<ul class="vo-cards">' + committees().map(card).join('') + '</ul>';
    }
    // Every committee's shifts on one day, a tap from here (finding "something Saturday afternoon"
    // shouldn't mean opening nine committees). Quiet, under the cards: committees stay first.
    const ds = state.model.days.filter(d => state.shifts.some(sh => !AW(sh) && eve(sh) === d && (!during() || d.date >= today())));
    return '<ul class="vo-cards">' + committees().map(card).join('') + '</ul>' +
      '<nav class="vo-allrow" aria-label="Every committee"><a class="vo-link" href="?year=' + esc(state.year) + '&view=all" data-go="*">All shifts</a>' +
      (ds.length > 1 ? '<span class="vo-allrow__days">' + ds.map(d => { const ow = openWords(state.shifts.filter(sh => !AW(sh) && eve(sh) === d)); return '<a class="vo-dlink" href="?year=' + esc(state.year) + '&view=all&day=' + esc(d.key) + '" data-goday="' + esc(d.key) + '" title="' + esc('Every committee · ' + whenDay(d)) + '"><b>' + esc(dayWord(d).slice(0, 3)) + '</b><span>' + esc(O.fmtDate(d.date, 'day')) + '</span>' + (live().posted && !closed() && ow ? '<small>' + esc(ow) + '</small>' : '') + '</a>'; }).join('') + '</span>' : '') + '</nav>';
  }
  // A job named as its committee is ("Usher" for Ushers, "Preteen helper" for Preteens) isn't said twice.
  // One rule everywhere (SU.jobSaid; the server's ogc_vol_job_said): Your sign-ups, calendar files, emails.
  const said = (r, c) => SU.jobSaid(r, c);
  function daysWords(list) {
    const ds = state.model.days.filter(d => list.some(sh => AW(sh) ? d.date >= sh.day.date && d.date <= (sh.lastDay || sh.day).date : eve(sh) === d));
    if (!ds.length) return '';
    const idx = ds.map(d => state.model.days.indexOf(d));
    const run = idx.every((x, i) => i === 0 || x === idx[i - 1] + 1);
    return ds.length === 1 ? dayWord(ds[0]) : run ? dayWord(ds[0]).slice(0, 3) + ' – ' + dayWord(ds[ds.length - 1]).slice(0, 3) : ds.map(d => dayWord(d).slice(0, 3)).join(', ');
  }
  function card(c) {
    // During the week a card speaks of what's still ahead.
    const list = state.shifts.filter(sh => sh.committee === c && (closed() || !during() || ahead(sh)));
    if (!list.length) return '';
    const anyOpen = list.some(sh => counts(sh) && open(sh) > 0), ow = openWords(list), num = /^(\d+) (open)$/.exec(ow);
    // No limit (Kit packing): the big word says so, how many have signed up under it (after the fifth
    // critic, Oct 15: "13 COMING" read like "coming soon").
    const unl = /^(\d+) signed up$/.exec(ow);
    const roles = uniq(list.map(sh => sh.role));
    // The jobs in a few words: two, then how many more (Youngfolks has six). Jobs that share a stem are
    // said by it once (jobWords).
    // Two at least, a third when the words are short ("Breakfast · Lunch · Supper").
    const jw = jobWords(list), k = jw.length > 2 && jw.slice(0, 3).join(' · ').length <= 30 ? 3 : 2;
    // Each job whole, its dot clipped at a line's start ("Dorm chaperone" / "Snack helper", never "Snack" /
    // "helper" or a dot at a line's end; Oct 24).
    const jobs = roles.length === 1 && said(roles[0], c) ? [] : jw.slice(0, k).concat(jw.length > k ? [(jw.length - k) + ' more'] : []);
    // The household's shifts here on every committee card, a contact's too (after the ninth critic, Oct 16),
    // by who's on them, never "Yours" (COA rehearsal, Oct 28): "Daniel · 1", "Millers · 2".
    const yours = uniq(list.filter(sh => minesOn(sh).length).map(sh => sh.id)).length;
    const yw = yours ? namesWord([].concat.apply([], list.map(sh => minesOn(sh).map(m => m.name)))) : '';
    const helped = closed() ? helpedWords(c, list) : '';
    const n = closed() ? (helped ? '<strong>' + esc(helped.split(' ')[0]) + '</strong><span>' + esc(helped.split(' ').slice(1).join(' ')) + '</span>' : '')
      : num ? '<strong>' + num[1] + '</strong><span>' + esc(num[2]) + '</span>' : unl ? '<strong class="is-word is-nolimit">No limit</strong><span class="is-sub">' + esc(ow) + '</span>' : ow ? '<strong class="is-word">' + esc(ow) + '</strong>' : '';
    const label = c + ', ' + (closed() ? helped || plural(list.length, 'shift') : ow ? (unl ? 'No limit, ' : '') + ow.replace(/ open$/, ' places open') : plural(list.length, 'shift')) + ', ' + roles.join(', ') + ', ' + daysWords(list) + (yours ? ', ' + (yw || 'signed up') + ': ' + plural(yours, 'shift') : '');
    return '<li><a class="vo-cc' + (anyOpen || closed() ? '' : ' is-full') + '" href="?year=' + esc(state.year) + '&committee=' + encodeURIComponent(c) + '" data-go="' + esc(c) + '" aria-label="' + esc(label) + '">' +
      ci(c) + '<span class="vo-cc__n">' + n + '</span><span class="vo-cc__name">' + esc(c) + '</span>' + (jobs.length ? '<span class="vo-cc__jobs"><span class="vo-mis">' + jobs.map(j => '<span class="vo-mi">' + esc(j) + '</span>').join('') + '</span></span>' : '') +
      '<span class="vo-cc__days">' + esc(daysWords(list)) + '</span>' + (yours ? '<span class="vo-cc__yours"><span class="vo-tag" title="' + esc(plural(yours, 'shift')) + '">' + I.check + esc((yw || 'Signed up') + ' · ' + yours) + '</span></span>' : '') + '</a></li>';
  }

  /* ---------------------------------------------------------------- one committee (or all): shifts by day */

  function listView() {
    const c = state.committee, all = c === '*';
    let list = state.shifts.filter(sh => all || sh.committee === c).sort((a, b) => sortKey(a) - sortKey(b) || a.committee.localeCompare(b.committee));
    // During the week: the days still to come, today first (an All week post once begun: only yours).
    if (during() && !closed()) list = list.filter(sh => AW(sh) ? ahead(sh) || minesOn(sh).length : eve(sh).date >= today());
    // A committee with several jobs (Youngfolks: dorm chaperones, snacks, kit packing): a chip a job.
    const jobs = all ? [] : uniq(list.map(sh => sh.role));
    let jsel = jobs.length > 1 ? state.job[c] || '' : '';
    if (jsel && jobs.indexOf(jsel) < 0) jsel = '';
    state.job[c] = jsel;
    const inJob = list.filter(sh => !jsel || sh.role === jsel);
    const days = state.model.days.filter(d => inJob.some(sh => !AW(sh) && eve(sh) === d));
    const hasWeek = inJob.some(AW);
    let dsel = state.day[c] != null ? state.day[c] : kept.get('day-' + state.year + '-' + c, '');
    if (dsel && !(dsel === 'week' ? hasWeek : days.some(d => d.key === dsel))) dsel = '';
    state.day[c] = dsel;
    const inDay = inJob.filter(sh => !dsel || (dsel === 'week' ? AW(sh) : !AW(sh) && eve(sh).key === dsel));
    // Hide full never hides a shift of this household's (Michael, Oct 15): one someone of theirs is on, or
    // waits on, stays in view, so a person's own shift never vanishes from their view (the grid too).
    const vis = sh => closed() || !state.hideFull || !isFull(sh) || minesOn(sh).length || pendOn(sh).length || waitsOn(sh).length || state.open === sh.id;
    const hidden = inDay.filter(sh => !vis(sh)).length;
    const chip = (key, label, title, attr) => '<button type="button" class="vo-chip" ' + (attr || 'data-day') + '="' + esc(key) + '" aria-pressed="' + ((attr ? jsel : dsel) === key) + '"' + (title ? ' title="' + esc(title) + '"' : '') + ' data-label="' + esc(label) + '">' + esc(label) + '</button>';
    const dayChips = days.length + (hasWeek ? 1 : 0) > 1 ? '<div class="vo-chips' + (days.length + (hasWeek ? 2 : 1) > 6 ? ' vo-chips--many' : '') + '" role="group" aria-label="Day">' + chip('', 'All days') + (hasWeek ? chip('week', 'All week', 'One post for the whole Conference') : '') + days.map(d => chip(d.key, dayWord(d).slice(0, 3), whenDay(d))).join('') + '</div>' : '';
    const jobChips = jobs.length > 1 ? '<div class="vo-chips vo-chips--jobs" role="group" aria-label="Job">' + chip('', 'All jobs', '', 'data-job') + jobs.map(j => chip(j, j, '', 'data-job')).join('') + '</div>' : '';
    let h = (jobChips ? '<div class="vo-fbar vo-fbar--jobs">' + jobChips + '</div>' : '') + '<div class="vo-fbar">' + dayChips +
      (closed() || !canFill(inDay) ? '' : '<span class="vo-fbar__sp"></span><button type="button" class="vo-toggle" role="switch" aria-checked="' + state.hideFull + '" data-hidefull><span class="vo-toggle__sw" aria-hidden="true"></span>Hide full</button>' +
        (state.hideFull && hidden ? '<span class="vo-hidden">' + hidden + ' full hidden</span>' : '')) +
      (!me() && !mine().length ? '<span class="vo-fbar__in">' + idLine() + '</span>' : '') + '</div>';
    const groups = (hasWeek && (!dsel || dsel === 'week') ? [{ week: true, rows: inDay.filter(sh => AW(sh) && vis(sh)) }] : [])
      .concat(days.filter(d => !dsel || d.key === dsel).map(d => ({ d, rows: inDay.filter(sh => !AW(sh) && eve(sh) === d && vis(sh)) }))).filter(g => g.rows.length);
    // Nothing open, only full ones hidden: the next step is to see them (and their waitlist).
    if (!groups.length) return h + '<p class="vo-nothing">' + (inDay.length ? 'No open shifts' + (dsel && dsel !== 'week' ? ' on ' + esc(dayWord(days.find(d => d.key === dsel))) : '') : 'No shifts') +
      (hidden ? ' <button type="button" class="vo-link vo-nothing__b" data-hidefull>Show ' + hidden + ' full</button>' : '') + '</p>';
    // Within the chosen job, what its shifts share too (the dorm chaperones' hall): said once above the
    // list when the committee's own line above doesn't say it.
    const fc = all ? null : shared(c), f = all ? null : sharedOf(inJob, c);
    if (f && jsel) {
      const extra = [f.place && !samePlace(f.place, fc.place) ? '<span class="vo-fact">' + I.pin + '<span>' + esc(f.place.name) + '</span></span>' : '', f.rule && !fc.rule ? '<span class="vo-fact vo-rule">' + esc(f.rule) + '</span>' : ''].filter(Boolean);
      if (extra.length) h += '<p class="vo-facts vo-facts--list"><span class="vo-facts__in">' + extra.join('') + '</span></p>';
    }
    // On a laptop, one committee's week is a grid (Michael, Oct 15): the days across, the parts of the day
    // down, a card a shift; a card opens in place. The same shifts as the list, by the same filters.
    // (A committee whose shifts fall on one day keeps the list: a one-column grid is a list of wide cards.)
    if (gridOn() && days.length > 1) { state.gridNow = true; return h + weekGrid({ c, shown: inDay.filter(vis), all: inDay, days, jobs: jobs.length > 1 && !jsel, jsel, f }); }
    groups.forEach(g => {
      const ow = openWords(g.rows);
      const title = g.week ? 'All week' : whenDay(g.d), sub = g.week ? weekRange(g.rows[0]) + ' · ' : '';
      // Rows that would all say nothing beside their time (the job and place said above): time, who's
      // on it and Sign up only, like a list of times.
      const lean = g.rows.every(sh => !whatOf(sh, all, f, jsel));
      // A long day in parts (Morning, Afternoon, Evening, Night), each its own short list: found by the
      // time of day, by the start time only (after the critic, Oct 15). One part: no subhead.
      const parts = PARTS.map(p => ({ p, rows: g.rows.filter(sh => partOf(sh) === p) })).filter(x => x.rows.length);
      const list = rows => '<ol class="vo-list' + (lean ? ' vo-list--lean' : '') + '">' + rows.map(sh => row(sh, all, f, jsel, lean)).join('') + '</ol>';
      h += '<section class="vo-day' + (g.week ? ' vo-day--week' : '') + '" aria-label="' + esc(title) + '"><div class="vo-day__h"><h2>' + esc(title) + '</h2><span>' + esc(sub + (closed() || !ow ? plural(g.rows.length, 'shift') : ow)) + '</span></div>' +
        (parts.length > 1 ? parts.map(x => '<h3 class="vo-part">' + esc(x.p) + '</h3>' + list(x.rows)).join('') : list(g.rows)) + '</section>';
    });
    return h;
  }
  // The parts of a day, by the start time only (after the fourth critic, Oct 15: "Morning" over 11:45
  // lunches): Morning before 11:00, Midday 11:00–1:59, Afternoon 2:00–4:44, Evening from 4:45, and a
  // shift from midnight to 5 AM is the evening before's Night. Evening starts at 4:45 (after the sixth
  // critic, Oct 15: 2026's Preteens check-in at 4:45 Saturday sat under Afternoon and the same check-in
  // at 5:30 Friday under Evening); every 2026 supper (2:30–4:30 starts) stays Afternoon. All day comes
  // first (Michael, Oct 24: the ushers' one shift a day, 9:30 AM–4 PM, sat under "Morning"): a shift that
  // starts before 11:00 and ends at 3:00 PM or later (the ushers, the sound booth); Transportation's
  // 6:15 AM–2:30 PM stays Morning.
  const PARTS = ['All day', 'Morning', 'Midday', 'Afternoon', 'Evening', 'Night'];
  const EVE = 1005;
  const partOf = sh => AW(sh) ? '' : night(sh) ? 'Night' : sh.start < 660 && sh.end >= 900 ? 'All day' : sh.start < 660 ? 'Morning' : sh.start < 840 ? 'Midday' : sh.start < EVE ? 'Afternoon' : 'Evening';
  // A committee's jobs in a few words (after the sixth critic, Oct 15: Food's card read "Dining hall
  // (supper) · Dining hall (breakfast) · 1 more"). Mechanical: jobs that share the words before " (" are
  // one stem. When every job is of one stem, the words in the brackets, capitalised, in the order of the
  // day ("Breakfast · Lunch · Supper"); else the stem once beside the other jobs ("Dining hall ·
  // Clean-up"). Nothing else is read from a job's name.
  function jobWords(list) {
    const byTime = list.slice().sort((a, b) => (AW(a) ? -1 : a.start) - (AW(b) ? -1 : b.start));
    const roles = uniq(byTime.map(sh => sh.role)), stem = r => { const i = r.indexOf(' ('); return i > 0 && /\)$/.test(r) ? r.slice(0, i) : ''; };
    const stems = {};
    roles.forEach(r => { const s0 = stem(r); if (s0) stems[s0] = (stems[s0] || 0) + 1; });
    const one = Object.keys(stems).length === 1 && roles.every(r => stem(r));
    if (one && roles.length > 1) return roles.map(r => { const w = r.slice(r.indexOf(' (') + 2, -1); return w.charAt(0).toUpperCase() + w.slice(1); });
    return uniq(roles.map(r => stem(r) && stems[stem(r)] > 1 ? stem(r) : r));
  }
  // What a row says beside its time: the job (unless said above, or chosen by its chip), the place and
  // the rule (unless every shift of the committee shares them); on All shifts, the committee.
  function whatOf(sh, withC, f, jsel) {
    // Every committee at once: the committee, unless the job is named as it is ("First aid" under First
    // Aid, any case; after the eighth critic, Oct 16: "First aid · First Aid").
    const where = withC ? (said(sh.role, sh.committee) ? '' : sh.committee) : f && samePlace(sh.place, f.place) ? '' : placeName(sh);
    const rs = f && f.rule ? '' : ruleShort(sh);
    // Each part brings its own dot, clipped at a line's start (no stray "·" when it wraps).
    const meta = (where ? '<span class="vo-mi">' + (withC ? '' : I.pin) + '<span>' + esc(where) + '</span></span>' : '') + (rs ? '<span class="vo-mi vo-rule">' + esc(rs) + '</span>' : '');
    const showRole = withC || !f || !(f.roleShared || jsel);
    return (showRole ? '<b>' + esc(sh.role) + '</b>' : '') + (meta ? '<span class="vo-row__meta"><span class="vo-mis">' + meta + '</span></span>' : '');
  }

  /* ---------------------------------------------------------------- one committee on a laptop: the week as a grid */

  // Michael, Oct 15 (Claude Design's "B2 · Opens in place", chosen): on a laptop, 1100 px and wider, one
  // committee's shifts are its week: the days across, the parts of the day down (All day, Morning, Midday,
  // Afternoon, Evening, and Night holding the night after each day), each shift a small card in its cell in time order,
  // the week's services faint at the top of a cell. A card opens in place: a band the grid's width under
  // its row, with the opened row's own content in it. Phones and narrower windows, All shifts, a day across
  // committees and a past year keep the list. Mechanical: a shift's cell is its day and its start time's part
  // (All day by its start and end).
  const WIDE = matchMedia('(min-width: 1100px)');
  // One day chosen: that day's list (a one-column grid is a list with wide, empty cards; the list says the
  // names and has Sign up on each row).
  const gridOn = () => !!(WIDE.matches && state.committee && state.committee !== '*' && !closed() && shiftsUp() && committees().indexOf(state.committee) > -1 && !state.day[state.committee]);
  // The parts' hours (the list's rule: by the start time; a shift from midnight to 5 AM is the night before's).
  // A part holds the shifts that start in it, so its hours aren't drawn under its name (after the seventh
  // critic, Oct 15: "Midday 11 AM–2 PM" held a 12–4 PM shift, "Night 12–5 AM" a 3–6 AM one); each card
  // says its own time, and the label's title says what puts a shift there ("Starts 11 AM–2 PM"). All day
  // spans the day, so its faint line lists the day's services.
  const PART_SPAN = { 'All day': [300, 1440], Morning: [300, 660], Midday: [660, 840], Afternoon: [840, EVE], Evening: [EVE, 1440], Night: [1440, 1740] };
  const partHours = p => O.formatRange(PART_SPAN[p][0], PART_SPAN[p][1], { compact: true });
  const partTitle = p => p === 'Night' ? 'Starts 12–5 AM, the night after each day' : p === 'All day' ? 'Starts before 11 AM, ends 3 PM or later' : 'Starts ' + partHours(p);
  // A night shift's night, said on its card as the list and the band say it ("Sat night").
  const nightWord = sh => night(sh) ? dayWord(eve(sh)).slice(0, 3) + ' night' : '';
  // "10", "2:30": a clock time without AM or PM (the row says which part of the day).
  const hm = m => { m = ((m % 1440) + 1440) % 1440; const h = Math.floor(m / 60) % 12 || 12, r = m % 60; return h + (r ? ':' + String(r).padStart(2, '0') : ''); };
  // The services in one cell: those of that day that overlap the part ("Communion 4–9" in the Afternoon and
  // the Evening); one with no end only where it starts, as "Council from 2". Faint, at the top of the cell.
  function gridSvcs(d, p) {
    const [a, b] = PART_SPAN[p], i = state.model.days.indexOf(d);
    // The Night after a day is the next day's small hours.
    const src = p === 'Night' ? (state.model.days[i + 1] ? [{ d: state.model.days[i + 1], off: 1440 }] : []) : [{ d, off: 0 }];
    const out = [];
    src.forEach(x => (x.d.items || []).forEach(it => {
      if (!SVC[it.kind] || it.start == null || it.audience === 'preteens' || it.audience === 'youngfolks') return;
      const s = it.start + x.off, e = it.end != null ? it.end + x.off : null;
      if (e == null ? s >= a && s < b : s < b && e > a) out.push({ name: SVC[it.kind], s, e, title: it.title });
    }));
    if (!out.length) return '';
    out.sort((x, y) => x.s - y.s);
    // One name, its times in order: "Worship 7:30–8 · 10–12 · Communion 4–9".
    const names = uniq(out.map(x => x.name));
    const words = names.map(n => n + ' ' + out.filter(x => x.name === n).map(x => x.e == null ? 'from ' + hm(x.s) : hm(x.s) + '–' + hm(x.e)).join(' · ')).join(' · ');
    const open = out.some(x => x.e == null);
    return '<p class="vo-gs' + (open ? ' is-open' : '') + '" title="' + esc(out.map(x => x.title + ' · ' + (x.e == null ? 'From ' + O.formatTime(x.s % 1440, { compact: true }) : O.formatRange(x.s % 1440, x.e % 1440, { compact: true }))).join('; ')) + '">' + esc(words) + '</p>';
  }
  // Everyone the person could tick for a shift is Busy then: the card says so (its title says with what).
  function gridBusy(sh) {
    if (minesOn(sh).length || !joinable(sh)) return null;
    const ppl = circle().slice();
    // Not signed in: the person this tab signed up, by their own places.
    if (!signed() && selfName() && mine().some(m => keyOfMine(m) === 'me') && !ppl.some(p => p.k === 'me')) ppl.unshift({ k: 'me', name: selfName(), self: true });
    const can = ppl.filter(p => !ruleWhy(p, sh));
    if (!can.length) return null;
    const bs = can.map(p => clashOf(p.k, sh));
    return bs.every(Boolean) ? can.map((p, i) => first(p.name) + ' · ' + busyWords(bs[i])) : null;
  }
  // A shift as a card: the time and its length, the job (only when several jobs show), who's on it, what's
  // open; the household's people on it ("✓ Daniel"), On waitlist, Busy or the state said under them.
  // What a card says beside its job when the line above doesn't (after the seventh critic, Oct 15: with All
  // jobs, Youngfolks' cards hid "21 or older" and the dorm's hall): its place when it isn't the usual one
  // said above, its rule when the line above has none.
  function gfacts(sh, f) {
    const pl = sh.place && !(f && samePlace(sh.place, f.place)) ? sh.place.name : '', ru = f && f.rule ? '' : ruleShort(sh) || '';
    return { pl, ru };
  }
  // Whose a shift is, said truly and by name (after the seventh critic, Oct 15: a contact who signed others
  // up saw "Yours" on shifts she isn't on; COA rehearsal, Oct 28: never "Yours"): the household's people on
  // it, "Daniel", "Amos and Sarah", "Millers"; those still to confirm only when nobody else of theirs is.
  const onNow = ms => ms.filter(m => !(m.added && !m.confirmed));
  function whose(sh) {
    const you = minesOn(sh), on = onNow(you);
    return namesWord((on.length ? on : you).map(m => m.name)) || 'Signed up';
  }
  // Whose week, named (COA rehearsal, Oct 28: never "Your week"): the person shown ("Daniel’s week"), or
  // on the bar everyone of the household with a shift ("Daniel and Ruth’s week", "Millers’ week").
  function weekWord(who) {
    const w = who && who.name ? first(who.name) : namesWord(mine().map(m => m.name).concat(pendAll().map(p => p.name))) || first(selfName());
    return !w ? 'The week' : / more$/.test(w) ? 'Week · ' + w : possWord(w) + ' week';
  }
  function gcard(sh, o) {
    const you = minesOn(sh), s = st(sh), full = isFull(sh), isOpen = state.open === sh.id, waits = waitsOn(sh);
    const fx = gfacts(sh, o.f), nw = nightWord(sh);
    const busy = !you.length && !isOpen ? gridBusy(sh) : null;
    const cnt = sh.unlimited ? '<b>No limit</b>' + (L(sh).f ? ' · ' + L(sh).f + ' signed up' : '') : open(sh) > 0 ? '<b>' + open(sh) + ' of ' + sh.needed + '</b> open' : 'Full';
    const own = you.some(m => !m.added && !m.confirmed), pd = pendOn(sh).length > 0;
    const stw = you.length || pd ? '' : waits.length ? 'On waitlist' : busy ? 'Busy' : /^(open|full)$/.test(s) ? '' : stateWord(s);
    const pw = peopleLine(sh, 4), pdw = pd ? namesWord(pendOn(sh).map(p => p.name)) : '';
    const lbl = [whenLong(sh) + (AW(sh) ? '' : ', ' + span(sh).replace('–', ' to ')), sh.role, fx.pl, fx.ru, cnt.replace(/<[^>]+>/g, ''), you.length ? whose(sh) + (onNow(you).length ? ' signed up' : ' waiting to confirm') : pd ? pdw + ' waiting to confirm' : '', pw ? pw.text : '', stw].filter(Boolean).join(', ');
    return '<button type="button" class="vo-gc' + (isOpen ? ' is-open' : '') + (you.length || pd ? ' is-yours' : full ? ' is-full' : '') + (busy ? ' is-busy' : '') + (s === 'started' || s === 'ended' ? ' is-past' : '') + (state.flash === sh.id ? ' is-flash' + (state.flashJoin ? ' is-join' : '') : '') + '" id="vo-r-' + esc(sh.id) + '" data-row="' + esc(sh.id) + '" data-open="' + esc(sh.id) + '" aria-expanded="' + isOpen + '" aria-controls="vo-p-' + esc(sh.id) + '" aria-label="' + esc(lbl) + '"' + (busy ? ' title="' + esc(busy.join('; ')) + '"' : '') + '>' +
      // The time on one line; only where a long one can't fit (10:45 PM–12:15 AM at 1100 px) it breaks
      // after its dash, never inside a time and never smaller.
      (nw ? '<span class="vo-gc__nt">' + esc(nw) + '</span>' : '') +
      '<span class="vo-gc__t"><b>' + (AW(sh) ? esc(weekRange(sh)) : esc(span(sh)).replace(/ /g, '&nbsp;').replace('–', '–<wbr>')) + '</b>' + (AW(sh) ? '' : '<span class="vo-gc__h">' + esc(hours(sh)) + '</span>') + '</span>' +
      (o.jobs ? '<span class="vo-gc__j">' + esc(sh.role) + '</span>' : '') +
      (fx.pl || fx.ru ? '<span class="vo-gc__f">' + (fx.pl ? '<span class="vo-gc__pl">' + I.pin + '<span>' + esc(fx.pl) + '</span></span>' : '') + (fx.ru ? '<span class="vo-gc__ru">' + esc(fx.ru) + '</span>' : '') + '</span>' : '') +
      '<span class="vo-gc__p">' + marks(sh, 4) + '<span class="vo-gc__n">' + cnt + '</span></span>' +
      // The household first, by name (COA rehearsal, Oct 28: "Aaron S. and 2 more" didn't name Daniel, and
      // "✓ Yours" isn't a name), then the others on it.
      (you.length ? gyours(sh, you, own) : pd ? '<span class="vo-gc__y">' + I.clock + esc(pdw) + '</span><span class="vo-gc__w">Waiting to confirm</span>' : '') + gnames(sh) +
      (stw ? '<span class="vo-gc__w">' + esc(stw) + '</span>' : '') + '</button>';
  }
  // A card's own line for the household on it: "✓ Daniel" (and "Check your email" while his own email
  // isn't confirmed), someone added under their own email "Ruth · Waiting to confirm".
  function gyours(sh, you, own) {
    const on = onNow(you), wait = you.filter(m => m.added && !m.confirmed);
    if (!on.length) return '<span class="vo-gc__y">' + I.clock + esc(namesWord(wait.map(m => m.name))) + '</span><span class="vo-gc__w">Waiting to confirm</span>';
    return '<span class="vo-gc__y">' + I.check + esc(whose(sh)) + '</span>' + (own ? '<span class="vo-gc__w">Check your email</span>' : '') +
      (wait.length ? '<span class="vo-gc__w">' + esc(namesWord(wait.map(m => m.name)) + ' · Waiting to confirm') + '</span>' : '');
  }
  // Who else is on a card, by name, where it has room (after the eighth critic, Oct 16: names took a
  // click), by the row's rule (peopleLine; never the household's own, said by name just above; a hidden
  // name isn't said): "Faith R. and Paul H.", "Grace R., John D. and 4 more", "6 volunteers". Every card
  // with a name to say says it (COA rehearsal, Oct 28: one card read "4 volunteers" beside cards with
  // names). On one line, never wrapped or cut (fitGrid measures it): where the names don't fit, one name
  // fewer ("Grace R. and 5 more"), then the count; where the marks draw everyone and even that doesn't
  // fit, it isn't drawn. People the marks can't draw are always said.
  function gnames(sh) {
    const w = peopleLine(sh, 4);
    if (!w) return '';
    return '<span class="vo-gc__nm" data-short="' + esc(JSON.stringify(w.shorts)) + '"' + (w.need ? ' data-need="1"' : '') + '>' + esc(w.text) + '</span>';
  }
  // The household's shifts that aren't cards here (another committee's, or this one's other job): faintly,
  // once, where they start, with their whole time ("Daniel · Lodging desk", "2–5 PM").
  const gchip = g => '<p class="vo-gx" data-x="' + esc(g.sh.id) + '" title="' + esc([listAnd(uniq(g.ms.map(m => first(m.name)))), g.sh.role, g.sh.committee, whenShort(g.sh)].join(' · ')) + '"><b>' + esc(listAnd(uniq(g.ms.map(m => first(m.name)))) + ' · ' + g.sh.role) + '</b><span>' + esc(span(g.sh)) + '</span></p>';
  // The week: o = { c, shown (the shifts as cards, after the chips and Hide full), all (before Hide full),
  // days (the columns), jobs (say the job on each card), jsel }.
  function weekGrid(o) {
    const cols = o.days, n = cols.length, shown = o.shown.slice().sort((a, b) => sortKey(a) - sortKey(b));
    const at = (d, p) => shown.filter(sh => !AW(sh) && eve(sh) === d && partOf(sh) === p);
    const aw = shown.filter(AW);
    const parts = PARTS.filter(p => cols.some(d => at(d, p).length));
    const cards = new Set(shown.map(sh => sh.id));
    // The household's shifts drawn as a faint line where they start: those not a card here.
    const chips = byShift(mine().filter(m => !cards.has(m.shift))).filter(g => !AW(g.sh) && (g.sh.committee !== o.c || (o.jsel && g.sh.role !== o.jsel)));
    const openSh = state.open ? shown.find(sh => sh.id === state.open) : null;
    let h = '<div class="vo-wg" style="--vo-gn:' + n + '" role="group" aria-label="' + esc(o.c + ' · ' + (o.jsel || 'Shifts') + ' by day') + '" data-grid>';
    // The day across the top, pinned while the week scrolls.
    h += '<div class="vo-wg__hd vo-wg__c0" aria-hidden="true"></div>' + cols.map((d, i) => {
      const rows = o.all.filter(sh => !AW(sh) && eve(sh) === d), vis = shown.filter(sh => !AW(sh) && eve(sh) === d), ow = openWords(rows);
      // Every shift of the day full and hidden: the column stays, and says "Full" (never "0 shifts").
      // The cards under it are counted by the eye; the head says only how many places (Oct 24).
      const sub = vis.length ? (ow || plural(vis.length, 'shift')) : rows.length && rows.every(isFull) ? 'Full' : ow;
      return '<div class="vo-wg__hd' + (i % 2 ? ' is-alt' : '') + '"><span class="vo-wg__dw">' + esc(dayWord(d)) + '</span><span class="vo-wg__dd">' + esc(O.fmtDate(d.date, 'md')) + '</span>' + (sub ? '<span class="vo-wg__ds">' + esc(sub) + '</span>' : '') + '</div>';
    }).join('');
    // The part's name only; its title says what puts a shift in it (by the start time).
    const label = (p, title) => '<div class="vo-wg__rl"' + (title ? ' title="' + esc(title) + '"' : '') + '><span class="vo-wg__rn">' + esc(p) + '</span></div>';
    const band = (sh, x) => '<div class="vo-wg__band" id="vo-band" style="--vo-gx:' + x + '"><span class="vo-wg__caret" aria-hidden="true"></span>' + gband(sh) + '</div>';
    // All week posts: a row of their own, first, each card across the days it covers.
    if (aw.length) {
      h += label('All week', '') + '<div class="vo-wg__aw" style="grid-column: 2 / span ' + n + '">' + aw.map(sh => {
        const a = Math.max(0, cols.findIndex(d => d.date >= sh.day.date)), z = cols.reduce((k, d, i) => d.date <= (sh.lastDay || sh.day).date ? i : k, a);
        return '<div class="vo-wg__awc" style="grid-column: ' + (a + 1) + ' / ' + (z + 2) + '">' + gcard(sh, o) + '</div>';
      }).join('') + '</div>';
      if (openSh && AW(openSh)) { const a = Math.max(0, cols.findIndex(d => d.date >= openSh.day.date)), z = cols.reduce((k, d, i) => d.date <= (openSh.lastDay || openSh.day).date ? i : k, a); h += band(openSh, (a + z + 1) / 2); }
    }
    parts.forEach(p => {
      h += label(p, partTitle(p)) + cols.map((d, i) => {
        const here = at(d, p).map(sh => ({ k: sortKey(sh), h: gcard(sh, o) }))
          .concat(chips.filter(g => eve(g.sh) === d && partOf(g.sh) === p).map(g => ({ k: sortKey(g.sh) - .5, h: gchip(g) })))
          .sort((a, b) => a.k - b.k);
        return '<div class="vo-wg__cell' + (i % 2 ? ' is-alt' : '') + '" data-day="' + esc(d.date) + '" data-part="' + esc(p) + '">' + gridSvcs(d, p) + here.map(x => x.h).join('') + '</div>';
      }).join('');
      if (openSh && !AW(openSh) && partOf(openSh) === p) h += band(openSh, cols.indexOf(eve(openSh)) + .5);
    });
    return h + '</div>';
  }
  // The opened card's band: the shift said once ("Sat, May 29 · 2–4 PM · First Aid"), who's on it and what's
  // open, Close; then the opened row's own content (what it is, Who's helping, Sign up), unchanged.
  function gband(sh) {
    // Only what the header and the opened card above don't already say (Oct 24): the job when the
    // committee has several, and no second row of marks and "3 of 4 open".
    const f = shared(sh.committee), job = f.roleShared ? '' : (said(sh.role, sh.committee) ? sh.committee : sh.role);
    const title = [AW(sh) ? 'All week · ' + weekRange(sh) : dayShort(sh), AW(sh) ? '' : span(sh), job].filter(Boolean).join(' · ');
    return '<div class="vo-wg__bin" role="region" aria-labelledby="vo-band-t"><div class="vo-wg__bh"><div class="vo-wg__bt"><h2 id="vo-band-t">' + esc(title) + '</h2></div>' +
      '<button type="button" class="wk-btn wk-btn--line wk-btn--small" data-open="' + esc(sh.id) + '" aria-expanded="true" aria-controls="vo-p-' + esc(sh.id) + '" aria-label="' + esc('Close ' + sh.role + ', ' + whenLong(sh)) + '">Close</button></div>' + panel(sh) + '</div>';
  }
  // A card's length beside its time goes before anything else does: measured, it's hidden only where
  // the time and the length can't share a line (the type never shrinks).
  function fitGrid() {
    root.querySelectorAll('.vo-gc__t').forEach(t => {
      const b = t.querySelector('b'), hr = t.querySelector('.vo-gc__h');
      if (!b || !hr) return;
      hr.hidden = false;
      if (hr.offsetTop > b.offsetTop + 2) hr.hidden = true;
    });
    // A card's names: whole on one line; else one name fewer at a time, then the count; else (the marks
    // draw everyone) not drawn.
    root.querySelectorAll('.vo-gc__nm').forEach(n => {
      n.hidden = false;
      if (!n.dataset.full) n.dataset.full = n.textContent;
      n.textContent = n.dataset.full;
      let alts = [];
      try { alts = JSON.parse(n.dataset.short || '[]'); } catch (e) { alts = []; }
      for (let i = 0; i < alts.length && n.scrollWidth > n.clientWidth + 1; i++) n.textContent = alts[i];
      if (n.scrollWidth > n.clientWidth + 1 && !n.dataset.need) n.hidden = true;
    });
  }
  // The band in view, gently (none under reduced motion): the card above it and the band below the pinned
  // days, as much of both as the screen holds.
  function bandIntoView() {
    const band = document.getElementById('vo-band'), card = state.open && document.getElementById('vo-r-' + state.open);
    if (!band || !card) return;
    const hd = root.querySelector('.vo-wg__hd'), top = (hd ? hd.offsetHeight : 0) + 12, bottom = clearBottom();
    const c = card.getBoundingClientRect(), b = band.getBoundingClientRect();
    let dy = 0;
    // Both fit: as little as it takes. Else the whole band with the card's foot above it; else the band's
    // top (and its caret) just under the pinned days.
    if (b.bottom - c.top <= bottom - top) { if (b.bottom > bottom) dy = b.bottom - bottom; else if (c.top < top) dy = c.top - top; }
    else if (b.bottom - b.top + 48 <= bottom - top) dy = b.bottom - bottom;
    else dy = b.top - 48 - top;
    if (Math.abs(dy) > 2) window.scrollBy({ top: dy, behavior: matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth' });
  }

  // Who's on it: a round mark a person (initials; yours in tan; waiting to confirm a clock), then the
  // open places dashed. One rule everywhere (after the second critic, Oct 15: "DH EH LH GR +6" sat beside
  // "Grace R., Paul H., Esther S. +3", and "8 of 8" drew two open marks where "4 of 4" drew four): people
  // first (yours, then those named, then the rest), and at most six marks in all.
  const seatsOf = sh => (L(sh).s || []).map(x => ({ l: x[0], i: x[1], you: !!x[2], swap: x[3], n: x[4] || '' }));
  const MARK_ALL = 6;
  // The marks a row (6) or a card (4) draws: people first (the household's, then those named, then the
  // rest), keeping a place for one open mark while any is open; then the open places, dashed, as many as
  // fit. How many are open is said once, in "9 of 14 open" beside them (COA rehearsal, Oct 28: a dashed
  // "+8" beside faces read as eight more people, the way "+N" reads on every app's row of faces). People
  // the marks can't draw are said in words under them ("Seth S. and 3 more", "9 volunteers"; peopleLine).
  function markPlan(sh, most) {
    const M = most || MARK_ALL, O = sh.unlimited ? 0 : Math.max(0, open(sh));
    const ppl = seatsOf(sh), named = p => !p.you && p.l && names();
    const ord = ppl.filter(p => p.you).concat(ppl.filter(named), ppl.filter(p => !p.you && !named(p)));
    const a = Math.min(ord.length, O ? M - 1 : M);
    return { shown: ord.slice(0, a), more: ord.length - a, open: Math.min(O, M - a) };
  }
  // Waiting for someone else to confirm: only a person added under their own email. Someone on your own
  // email is confirmed with yours (one "Check your email" says it, never "waiting" for them).
  const waitingSeat = (sh, n) => minesOn(sh).some(m => low(m.name) === low(n) && !m.confirmed && m.added);
  // (A grid card is narrower: four marks in all there, the same rule.)
  function marks(sh, most) {
    const ss = markPlan(sh, most);
    const mk = p => {
      if (p.you && waitingSeat(sh, p.n)) return '<span class="vo-mk is-wait" title="' + esc(p.n + ' · Waiting to confirm') + '">' + I.clock + '</span>';
      if (p.you) return '<span class="vo-mk is-you" title="' + esc(p.n) + '">' + esc(initials(p.n)) + '</span>';
      if (p.l && names()) return '<span class="vo-mk' + (p.swap ? ' is-swap' : '') + '" title="' + esc(p.l) + '">' + esc(p.i || '') + '</span>';
      return '<span class="vo-mk is-anon' + (p.swap ? ' is-swap' : '') + '" title="Name hidden">' + I.person + '</span>';
    };
    return '<span class="vo-marks" aria-hidden="true">' + ss.shown.map(mk).join('') + Array.from({ length: ss.open }, () => '<span class="vo-mk is-open" title="Open"></span>').join('') + '</span>';
  }
  // Who else is on it, in words, under the marks: the names that may show ("Ruth K."; most: three on a row,
  // two on a card), then "and 3 more"; with none to name, a count ("4 volunteers", or "3 others" beside
  // the household's). Never the household's own (named by the row's button and the card's line). Said when
  // there's a name to say, or when the marks can't draw everyone (more). shorts: where the names don't fit
  // a card, one name fewer at a time ("Grace R. and 5 more"), then the count.
  function peopleLine(sh, M) {
    const ss = seatsOf(sh), others = ss.filter(p => !p.you), yours = ss.some(p => p.you);
    if (!others.length) return null;
    const more = markPlan(sh, M).more;
    const named = names() ? others.filter(p => p.l).slice(0, M < MARK_ALL ? 2 : 3).map(p => p.l) : [];
    const count = yours ? plural(others.length, 'other') : plural(others.length, 'volunteer');
    if (!named.length && !more) return null;
    const parts = named.length ? saidParts({ named, rest: others.length - named.length }) : [count];
    const shorts = [];
    for (let k = named.length - 1; k >= 1; k--) shorts.push(saidParts({ named: named.slice(0, k), rest: others.length - k }).join(' '));
    if (named.length) shorts.push(count);
    return { parts, text: parts.join(' '), short: count, shorts, need: more > 0 };
  }
  // A row's line: on a phone it's its own line under the marks; each part kept whole.
  function nameLine(sh) {
    const w = peopleLine(sh, MARK_ALL);
    return w ? '<span class="vo-names">' + w.parts.map(x => '<span class="vo-nw">' + esc(x) + '</span>').join(' ') + '</span>' : '';
  }
  const STATE_WORD = { started: 'Started', ended: 'Ended', closed: 'Closed', committee: 'By committee' };
  const stateWord = s => s === 'not_open' ? opensWord() : STATE_WORD[s] || '';
  // "3 of 4 open": what's open. Then, on your own shift (closed), who of yours is on it; opened, its
  // panel says them once (after the second critic, Oct 15: the names were said three times).
  function openLine(sh) {
    const n = closed() ? (L(sh).f ? L(sh).f + ' helped' : '') : sh.unlimited ? '<b>No limit</b>' + (L(sh).f ? ' · ' + L(sh).f + ' signed up' : '') : open(sh) > 0 ? '<b>' + open(sh) + ' of ' + sh.needed + '</b> open' : 'Full';
    return '<span class="vo-open">' + n + '</span>' + (closed() || state.open === sh.id ? '' : yoursLine(sh));
  }
  // What's still to do on the household's shift, said plainly (the row's button names who's on it, "✓
  // Martha and Henry"): "Check your email" while their own email isn't confirmed, and someone added under
  // their own email "Alex Bowman · Waiting to confirm".
  function yoursLine(sh) {
    const you = minesOn(sh), pd = pendOn(sh);
    if (pd.length) return '<span class="vo-waitline">' + I.clock + '<span><b>' + esc(listAnd(uniq(pd.map(p => first(p.name))))) + '</b> · <span class="vo-nw">Waiting to confirm</span></span></span>';
    if (!you.length) return '';
    const on = onNow(you), wait = you.filter(m => m.added && !m.confirmed);
    const check = you.some(m => !m.added && !m.confirmed);
    return (on.length && check ? '<span class="vo-yline">' + I.mail + '<span class="vo-nw">Check your email</span></span>' : '') +
      wait.map(m => '<span class="vo-waitline">' + I.clock + '<span><b>' + esc(m.name) + '</b> · <span class="vo-nw">Waiting to confirm</span></span></span>').join('');
  }
  function row(sh, withC, f, jsel, lean) {
    const you = minesOn(sh), s = st(sh), o = open(sh), full = isFull(sh), isOpen = state.open === sh.id;
    // Every committee at once: the committee where the place would be (the place is in the open row).
    // One committee: only what isn't said above the list (shared()).
    const what = whatOf(sh, withC, f, jsel);
    const lbl = sh.role + ', ' + whenLong(sh) + (AW(sh) ? '' : ', ' + span(sh).replace('–', ' to '));
    const ctl = ' data-open="' + esc(sh.id) + '" aria-expanded="' + isOpen + '" aria-controls="vo-p-' + esc(sh.id) + '"';
    // One way to close an opened row: its own button, where Sign up was (never a second Cancel below).
    // The household's own shift, closed, names who of theirs is on it (COA rehearsal, Oct 28: never "✓
    // Yours"): "✓ Daniel", "✓ Martha and Henry"; only someone still to confirm: "⏱ Ruth".
    let act;
    if (closed()) act = '';
    else if (isOpen) act = '<button type="button" class="wk-btn wk-btn--line wk-btn--small"' + ctl + ' aria-label="' + esc('Close ' + lbl) + '">Close</button>';
    else if (you.length) act = onNow(you).length ? '<button type="button" class="vo-yours"' + ctl + ' aria-label="' + esc(whose(sh) + ', signed up: ' + lbl) + '">' + I.check + esc(whose(sh)) + '</button>'
      : '<button type="button" class="vo-yours is-wait"' + ctl + ' aria-label="' + esc(whose(sh) + ', waiting to confirm: ' + lbl) + '">' + I.clock + esc(whose(sh)) + '</button>';
    else if (pendOn(sh).length) act = '<button type="button" class="vo-yours is-wait"' + ctl + ' aria-label="' + esc(namesWord(pendOn(sh).map(p => p.name)) + ', waiting to confirm: ' + lbl) + '">' + I.clock + esc(namesWord(pendOn(sh).map(p => p.name))) + '</button>';
    else if (s === 'open' && o > 0) act = '<button type="button" class="wk-btn wk-btn--line wk-btn--small"' + ctl + ' aria-label="' + esc('Sign up for ' + lbl) + '">Sign up</button>';
    else if (full && (s === 'full' || s === 'open')) act = waitsOn(sh).length ? '<button type="button" class="vo-yours"' + ctl + '>On waitlist</button>' : '<button type="button" class="wk-btn wk-btn--line wk-btn--small"' + ctl + ' aria-label="' + esc('Join waitlist for ' + lbl) + '" title="Email when a place opens">Join waitlist</button>';
    else act = '<span class="vo-state"' + (s === 'committee' ? ' title="Filled by the committee"' : '') + '>' + esc(stateWord(s)) + '</span>';
    return '<li class="vo-row' + (isOpen ? ' is-open' : '') + ((you.length || pendOn(sh).length) && !closed() ? ' is-yours' : '') + (state.flash === sh.id ? ' is-flash' + (state.flashJoin ? ' is-join' : '') : '') + (s === 'started' || s === 'ended' ? ' is-past' : '') + (AW(sh) ? ' is-week' : '') + '" id="vo-r-' + esc(sh.id) + '" data-row="' + esc(sh.id) + '">' +
      // Opened, the row says its day above the time (after the fifth critic, Oct 15: on a phone the day's
      // heading scrolls away while the form is filled in).
      '<div class="vo-row__top"><div class="vo-row__time">' + (isOpen && !AW(sh) ? '<span class="vo-row__night vo-row__od">' + esc(dayShort(sh)) + '</span>' : night(sh) ? '<span class="vo-row__night">' + esc(dayWord(eve(sh)).slice(0, 3)) + ' night</span>' : '') + '<b>' + esc(span(sh)) + '</b><span>' + esc(hours(sh)) + '</span></div>' +
      (lean ? '' : '<div class="vo-row__what">' + what + '</div>') +
      // Names wherever a row has room, by the same rules everywhere (All shifts too).
      '<div class="vo-row__places">' + (closed() ? '' : marks(sh)) + openLine(sh) + (closed() || isOpen ? '' : nameLine(sh)) + '</div>' +
      '<div class="vo-row__act">' + act + '</div></div>' + (isOpen ? panel(sh) : '') + '</li>';
  }

  /* ---------------------------------------------------------------- the row, opened */

  // On a phone: what the shift is, then the form (after the critic, Oct 15); on your own shift, its state
  // first. On a laptop: what it is beside who's helping.
  function panel(sh) {
    const who = '<div class="vo-who">' + whoSide(sh) + '</div>';
    if (!matchMedia('(max-width: 767px)').matches) return '<div class="vo-panel" id="vo-p-' + esc(sh.id) + '">' + info(sh) + who + '</div>';
    const d = desc(sh) + onLine(sh), yours = minesOn(sh).length > 0 && !closed();
    return '<div class="vo-panel" id="vo-p-' + esc(sh.id) + '">' + (yours ? who + (d ? '<div class="vo-info vo-info--desc">' + d + '</div>' : '') : (d ? '<div class="vo-info vo-info--desc">' + d + '</div>' : '') + who) + info(sh, true) + '</div>';
  }
  // Everyone on it, named where they may be (after the ninth critic, Oct 16: "On this shift · 3 volunteers"
  // left out Martha and Leroy on a shift of five): the household first by first name (theirs, so named to
  // them), then others as "First L."; a hidden name or an Under 18 is never named, only counted ("Leroy and
  // 4 more", "Martha, Leroy, Seth S. and 2 more", "5 volunteers").
  function peopleSaid(sh) {
    const ss = seatsOf(sh), own = ss.filter(p => p.you && p.n).map(p => first(p.n)), others = names() ? ss.filter(p => !p.you && p.l).map(p => p.l) : [];
    const named = own.concat(others);
    return { named, rest: ss.length - named.length, all: ss.length };
  }
  // The words, each kept whole on a line: "Martha," "Leroy," "Seth S." "and 2 more" / "Ruth and" "Amos".
  function saidParts(w) {
    const n = w.named.length;
    return w.named.map((x, i) => x + (w.rest ? (i < n - 1 ? ',' : '') : (i < n - 2 ? ',' : i === n - 2 ? ' and' : ''))).concat(w.rest ? [n ? 'and ' + w.rest + ' more' : plural(w.rest, 'volunteer')] : []);
  }
  function onLine(sh) {
    const w = peopleSaid(sh);
    if (!w.all) return '';
    // A name never breaks across lines; commas, so no line starts with a dot.
    return '<p class="vo-on"><b>On this shift</b> · ' + saidParts(w).map(x => '<span class="vo-nw">' + esc(x) + '</span>').join(' ') + '</p>';
  }
  // What to do: on All shifts the committee's instruction (not said above the list), and the shift's
  // own note (unless it only repeats the instruction).
  function desc(sh) {
    const ins = state.committee === '*' ? instructionOf(sh.committee) : '';
    const note = sh.note && sameWords(sh.note, instructionOf(sh.committee)) ? '' : sh.note;
    return (ins ? '<p class="vo-instr vo-instr--row">' + I.info + '<span><b>' + esc(sh.committee) + '</b> · ' + esc(ins) + '</span></p>' : '') + (note ? '<p class="vo-desc">' + esc(note) + '</p>' : '');
  }
  // What it is: what to do, who's on it, where, who to ask; Invite. (noDesc: said above already, with
  // who's on it.)
  function info(sh, noDesc) {
    const phone = comm(sh.committee).phone;
    const map = sh.place && whereMap(sh.place, true);
    return '<div class="vo-info">' + (noDesc ? '' : desc(sh) + onLine(sh)) +
      (sh.place ? '<p><b>Place</b> · ' + esc(sh.place.name) + (map ? ' · <button type="button" class="wk-linklike" data-map="' + esc(sh.id) + '" aria-expanded="' + (state.mapOpen === sh.id) + '">Map</button>' : '') + '</p>' + (state.mapOpen === sh.id ? '<div class="vo-map">' + whereMap(sh.place, false, st(sh) === 'ended') + '</div>' : '') : '') +
      (phone && !closed() ? '<p><b>Questions</b> · <a href="tel:' + esc(phone.replace(/[^\d+]/g, '')) + '">' + esc(phone) + '</a></p>' : '') +
      (closed() || !/^(open|full)$/.test(st(sh)) ? '' : '<p><button type="button" class="wk-linklike" data-invite="' + esc(sh.id) + '">Invite someone</button></p>') + '</div>';
  }
  function whoSide(sh) {
    const you = minesOn(sh), s = st(sh), o = open(sh), full = isFull(sh);
    const swapSeat = !you.length && seatsOf(sh).find(p => p.swap);
    // Your own shift: only its state, Calendar, Leave and a quiet Add someone (after the critic, Oct 15);
    // the form opens under it only when Add someone is tapped.
    if (you.length) return mineBlock(sh, you) + (!closed() && adding(sh) && s === 'open' && o > 0 ? whoBlock(sh) : '');
    if (closed()) return '';
    if (pendOn(sh).length) return pendBlock(sh);
    if (swapSeat && (state.swap || q.get('swap'))) return takeBlock(sh, swapSeat);
    if (s === 'open' && o > 0) return whoBlock(sh);
    if (full && (s === 'full' || s === 'open')) return waitBlock(sh, swapSeat);
    return '<p class="vo-full">' + esc(stateWord(s) || 'Full') + (s === 'started' && comm(sh.committee).phone ? ' · Call ' + esc(comm(sh.committee).phone) : '') + '</p>';
  }
  // A place of this email another device made, still to confirm: hers, said so, with Resend (the Confirm
  // goes to this same address). Leave and Calendar wait until it's confirmed (the email's own links work).
  function pendBlock(sh) {
    const ps = pendOn(sh), to = (me() && me().email) || '';
    return '<div class="vo-mine"><p class="vo-mine__h">' + I.clock + '<span>' + esc(listAnd(uniq(ps.map(p => first(p.name))))) + ' · <span class="vo-nw">Waiting to confirm</span></span></p>' +
      '<p class="vol-statehelp">Confirm link sent' + (to ? ' to <b>' + esc(to) + '</b>' : '') + '<br><span class="vol-ctools"><button type="button" class="wk-linklike" data-resend="' + esc(ps.map(p => p.rid).join(' ')) + '">Resend</button></span></p></div>';
  }
  // Adding someone to a shift you're already on (its quiet Add someone was tapped).
  const adding = sh => !!(sh && state.addMore === sh.id && minesOn(sh).length);

  // Your place on it: who, what's still to do (confirm), and its actions (Calendar, Leave, Add someone).
  function mineBlock(sh, you) {
    const on = you.filter(m => !(m.added && !m.confirmed)), addWait = you.filter(m => m.added && !m.confirmed);
    const ownWait = you.filter(m => !m.added && !m.confirmed);
    const swap = you.find(m => m.swap);
    const s = st(sh), started = s === 'started' || s === 'ended';
    let h = '<div class="vo-mine">';
    h += '<p class="vo-mine__h">' + I.check + '<span>Signed up' + (on.length ? ' · ' + esc(listAnd(uniq(on.map(m => first(m.name))))) : '') + '</span></p>';
    h += addWait.map(m => '<p class="vo-waitline">' + I.clock + '<span><b>' + esc(m.name) + '</b> · <span class="vo-nw">Waiting to confirm</span></span></p>').join('');
    if (ownWait.length) h += confirmHelp(ownWait.map(m => m.rid), 'row:' + sh.id);
    if (started) h += '<p class="vo-full">' + esc(STATE_WORD[s]) + (comm(sh.committee).phone ? ' · Can’t come? Call ' + esc(comm(sh.committee).phone) : '') + '</p>';
    else if (swap) h += '<p class="vo-full">Swap open · ' + esc(first(swap.name)) + '’s place stays until someone takes it</p><p class="vo-mine__acts"><button type="button" class="vo-link" data-swapcopy="' + esc(swap.swap) + '">' + I.link + 'Copy link</button><button type="button" class="vo-link" data-swapoff="' + swap.rid + '">Cancel swap</button></p>';
    else if (state.leaving === sh.id) h += leaveAsk(sh, you);
    else h += '<p class="vo-mine__acts"><a class="vo-link" href="' + esc(icsHref([sh.id])) + '" data-icsa>' + I.cal + 'Calendar</a><button type="button" class="vo-link" data-leave="' + esc(sh.id) + '">Leave</button>' +
      (st(sh) === 'open' && open(sh) > 0 && !adding(sh) ? '<button type="button" class="vo-link" data-addmore="' + esc(sh.id) + '">' + I.plus + 'Add someone</button>' : '') + '</p>' +
      (adding(sh) ? '' : ownAlsoBlock(sh));
    return h + '</div>';
  }
  // Your own shift's "Also on" (after the second critic, Oct 15): the same job at the same time on the
  // committee's other days, for the same people on it now ("Also on · Sun 30 · Mon 31 · Tue 1", then
  // "Sign up 3 · 2 days"). Signed in; a shift that asks for screening keeps its own row's form.
  const ownPeople = sh => uniq(minesOn(sh).map(keyOfMine)).map(k => { const m = minesOn(sh).find(x => keyOfMine(x) === k); return { k, name: m.name, email: m.added ? m.email : '', minor: !!m.minor, band: m.band || '', info: m.added ? null : personOf(m.name), answer: m.answer }; });
  const ownAlsoOk = sh => signed() && !closed() && !screening(sh) && sameTime(sh).length > 0 && ahead(sh);
  function ownAlsoWhy(x, sh) {
    if (!joinable(x)) return stateWord(st(x)) || 'Full';
    const ps = ownPeople(sh), on = ps.filter(p => minesOn(x).some(m => keyOfMine(m) === p.k));
    if (on.length === ps.length) return 'Signed up';
    if (!x.unlimited && open(x) < ps.length) return open(x) ? plural(open(x), 'place') + ' left' : 'Full';
    const p = ps.map(q => ({ q, w: whyNot(q, x) })).find(z => z.w);
    return p ? first(p.q.name) + ' · ' + p.w.why : '';
  }
  const ownAlsoOn = sh => (state.ownAlso || []).map(find).filter(x => x && sameTime(sh).indexOf(x) > -1 && !ownAlsoWhy(x, sh));
  function ownAlsoLabel(sh) {
    const ps = ownPeople(sh), a = ownAlsoOn(sh).length;
    return state.busyAct === 'ownalso' ? 'Signing up…' : 'Sign up · ' + (peopleWords(ps.map(p => first(p.name)), ps.length) || plural(ps.length, 'person', 'people')) + ' · ' + plural(a, 'day');
  }
  function ownAlsoBlock(sh) {
    if (!ownAlsoOk(sh) || st(sh) === 'started' || st(sh) === 'ended') return '';
    const xs = sameTime(sh), a = ownAlsoOn(sh).length;
    return '<div class="vo-also vo-also--own"><p class="vo-label" id="vo-oal-' + esc(sh.id) + '">Also on</p><div class="vo-also__days" role="group" aria-labelledby="vo-oal-' + esc(sh.id) + '">' + xs.map(x => {
      const why = ownAlsoWhy(x, sh), on = !why && (state.ownAlso || []).indexOf(x.id) > -1;
      return '<button type="button" class="vo-also__d" data-ownalso="' + esc(x.id) + '" aria-pressed="' + on + '"' + (why ? ' aria-disabled="true" title="' + esc(why) + '"' : ' title="' + esc(whenLong(x) + ' · ' + span(x)) + '"') + '>' + I.check +
        '<b>' + esc(dayWord(eve(x)).slice(0, 3) + (night(x) ? ' night' : ' ' + O.fmtDate(eve(x).date, 'day'))) + '</b><small>' + esc(why || (x.unlimited ? 'No limit' : open(x) + ' open')) + '</small></button>';
    }).join('') + '</div>' +
      (a ? '<p class="vo-also__go"><button type="button" class="wk-btn wk-btn--small" data-ownalsogo="' + esc(sh.id) + '" data-fit="' + esc(JSON.stringify(['Sign up ' + ownPeople(sh).length + ' · ' + plural(a, 'day'), 'Sign up'])) + '"' + (state.busyAct ? ' disabled' : '') + '>' + esc(ownAlsoLabel(sh)) + '</button></p>' : '') +
      (state.footErr && state.ownAlsoFor === sh.id ? '<p class="vo-errline" role="alert">' + I.alert + esc(state.footErr) + '</p>' : '') + '</div>';
  }
  async function ownAlsoJoin(sh) {
    const xs = ownAlsoOn(sh);
    if (state.busyAct || !xs.length) return;
    const ps = ownPeople(sh), b = { shifts: xs.map(x => x.id), answers: {}, show: true };
    // As Sign up sends them: names under your email; anyone added under their own email, or Under 18, as an Add.
    b.people = ps.filter(p => !p.email && !p.minor).map(p => p.name);
    const adds = ps.filter(p => p.email || p.minor).map(p => ({ name: p.name, email: p.email || myEmail(), minor: p.minor, band: bandOf(p) }));
    if (adds.length) b.add = adds;
    const bands = {};
    ps.forEach(p => { if (BANDS.some(x => x[0] === bandOf(p))) bands[p.name] = bandOf(p); });
    if (Object.keys(bands).length) b.bands = bands;
    // The same job's rule, already answered for this shift (each person's own certification).
    if (question(sh).length) { b.answers.question = (ps.find(p => p.answer) || {}).answer || ''; b.answers.questions = {}; ps.forEach(p => { if (p.answer) b.answers.questions[p.name] = p.answer; }); }
    else if (sh.rule) b.answers.rule = true;
    state.busyAct = 'ownalso'; state.footErr = ''; state.ownAlsoFor = sh.id; redraw('[data-ownalsogo]');
    let d;
    try { d = await post('vol/' + state.year + '/join', b); }
    catch (err) { state.busyAct = ''; state.footErr = err.status === 429 ? 'Too many at once · Try later' : 'Not saved · Retry'; redraw(); return; }
    state.busyAct = '';
    merge(d);
    const ok = d.results.filter(r => r.status === 'ok'), no = d.results.filter(r => r.status !== 'ok');
    if (!ok.length) { const r = no[0]; state.footErr = r ? (find(r.shift) ? dayWord(eve(find(r.shift))).slice(0, 3) + ' · ' : '') + refusal(r, find(r.shift) || sh).msg : 'Not saved'; redraw(); return; }
    const made = d.made || [], who = mine().filter(x => made.indexOf(x.rid) > -1), groups = byShift(who);
    const lines = groups.length ? groups.map(g => shiftLine(g.sh, g.ms)) : ok.map(r => find(r.shift)).filter(Boolean).map(x => shiftLine(x, []));
    const nos = no.map(r => { const x = find(r.shift); return (x ? dayWord(eve(x)).slice(0, 3) + ' · ' : '') + refusal(r, x || sh).msg; });
    state.ownAlso = []; state.ownAlsoFor = '';
    render();
    showToast({ kind: 'ok', text: lines.length > 1 ? 'Signed up · ' + plural(lines.length, 'shift') : 'Signed up', lines, sub: nos.length ? 'Not ' + nos.join(', ') : '', ids: made, shifts: (groups.length ? groups.map(g => g.sh) : []).map(x => x.id), ics: true });
    say.textContent = 'Signed up · ' + lines.join('; ');
  }
  // Leave asks first, in the one Leave sheet (SU.leaveSheet; the emailed link and Your sign-ups draw the
  // same): which of you (several on it, all on at first), who goes said ("Walter leaves"), Leave shift as
  // the one filled button, Find replacement only for one person's one place, Keep shift.
  const leaveChosen = you => you.filter(m => !state.leaveWho || state.leaveWho.indexOf(m.rid) > -1);
  const leavesWords = you => { const g = leaveChosen(you); return g.length ? listAnd(uniq(g.map(m => first(m.name)))) + (g.length === 1 ? ' leaves' : ' leave') : 'Choose who’s leaving'; };
  function leaveAsk(sh, you) {
    const g = leaveChosen(you);
    return '<div class="vo-lvwrap">' + SU.leaveSheet({
      scope: 'row:' + sh.id, id: 'vo-lv-' + sh.id, heading: 'Leave this shift?',
      people: you.length > 1 ? you.map(m => ({ value: m.rid, label: first(m.name), on: g.indexOf(m) > -1 })) : [],
      goes: leavesWords(you), head: headWords([sh], g), swap: g.length === 1 && !g[0].swap,
      busy: state.busyAct === 'leave', disabled: !g.length || !!state.busyAct,
      err: state.footErr && state.leaving === sh.id ? state.footErr : ''
    }) + '</div>';
  }

  // Who's helping: your own name first, then your household (or those you've signed up before), then
  // Add someone. The pills stop at the open places; Sign up says how many, counting someone being typed
  // into Add someone: they go on with the Sign up, never dropped without a word (after the critic, Oct 15).
  function whoBlock(sh) {
    const o = open(sh), more = adding(sh), n = pickN(sh), e = state.err;
    // Adding to a shift you're on: only those not on it yet.
    const ppl = circle().filter(p => !more || !minesOn(sh).some(m => keyOfMine(m) === p.k));
    // An age rule is asked first, before name and email (after the second critic, Oct 15), as the one age
    // field (after the sixth critic): the first time, "Age · Under 18 · 18–20 · 21 or older" at the top;
    // an age that doesn't meet it says so at once with what's open to them, and no form follows.
    const ageFirst = minAge(sh) > 0;
    const selfAge = !more && formSelf() && !contactOnly();
    const blocked = ageFirst && selfAge && bandOk(state.me1.band, minAge(sh)) === false;
    let h = '';
    if (ageFirst && selfAge) h += '<div class="vo-age">' + ageSeg('me1', state.me1.band, 'Age', e['me1.band']) + (blocked ? tooYoung(sh, underOf(state.me1.band, sh)) : '') + '</div>';
    if (blocked) return h;
    // One count on the row, one meaning (after the fourth critic, Oct 15: "1 of 8 places" here sat beside
    // the row's "8 of 8 open"): Sign up says how many go; this line speaks only when the open places stop
    // someone else being ticked ("Only 2 open").
    // "For someone else" (after the sixth critic): the contact's own fields come first, labelled so, then
    // the list of names right under them.
    const contact = !more && contactOnly();
    h += '<div class="vo-who__h"><span class="vo-label" id="vo-wh-' + esc(sh.id) + '">' + (contact ? 'Their contact' : more ? 'Add to this shift' : 'Who’s helping') + '</span><span class="vo-who__n" data-count>' + esc(contact ? '' : capWords(sh, ppl)) + '</span></div>';
    if (!more && formSelf()) h += selfBox(sh, true, true);
    else if (!more && nameSelf()) h += selfBox(sh, false);
    if (contact) h += namesBox(sh);
    else if (ppl.length || !state.add) {
      h += '<div class="vo-pills" role="group" aria-labelledby="vo-wh-' + esc(sh.id) + '">';
      ppl.forEach(p => {
        const no = whyNot(p, sh), on = !no && state.pick.indexOf(p.k) > -1, capped = !on && !no && n >= o;
        // Your own pill carries the phone the head will see, with Change beside it (after the third
        // critic, Oct 15).
        const ph = p.self && me().phone ? me().phone : '';
        const sub = no ? no.why : p.self ? (ph && !state.phoneEdit ? ph : '') : p.email ? p.email : kindWords(p.info) + (notHere(p, sh) ? ' · Not here ' + dayWord(sh.day).slice(0, 3) : '');
        h += '<button type="button" class="vo-wp' + (no && no.busy ? ' is-busy' : '') + (capped ? ' is-capped' : '') + '" data-pick="' + esc(p.k) + '" aria-pressed="' + on + '"' + (no ? ' aria-disabled="true"' : '') + (capped ? ' title="' + esc('Only ' + o + ' open') + '"' : '') + '>' +
          '<span class="vo-wp__av" aria-hidden="true">' + esc(initials(p.name)) + '</span><span class="vo-wp__tx"><b>' + esc(p.name) + '</b>' + (sub ? '<small>' + esc(sub) + '</small>' : '') + '</span></button>';
        if (ph && !no && !state.phoneEdit) h += '<button type="button" class="vo-link vo-wp__chg" data-phonechg aria-label="' + esc('Change phone, ' + ph) + '">Change</button>';
      });
      if (!state.add) h += '<button type="button" class="vo-wp is-add" data-addopen' + (n >= o ? ' title="' + esc('Only ' + o + ' open') + '"' : '') + '><span class="vo-wp__av" aria-hidden="true">' + I.plus + '</span><span class="vo-wp__tx"><b>Add someone</b>' + (!more && !ppl.length && canShare() ? '<small>' + (teen() ? 'Another person' : 'Husband, wife, child') + '</small>' : '') + '</span></button>';
      h += '</div>';
    }
    // Everyone ticked whose age isn't known (or only "18 or older" for a 21-or-older shift): asked once
    // each, by name, and kept. One that doesn't meet the rule is greyed with its words. An age answered here
    // stays in place, chosen, while the row is open (after the ninth critic, Oct 16: the answered question
    // went away and what was under it moved up under the finger).
    state.askedRow = state.askedRow || [];
    picked(sh).forEach(p => { if (needsBand(bandOf(p), sh) && state.askedRow.indexOf(p.k) < 0) state.askedRow.push(p.k); });
    // (Kept off the shift by the answer given here, the question stays too, so a wrong tap can be put right.)
    const pk = picked(sh).map(p => p.k);
    const askP = ppl.filter(p => state.askedRow.indexOf(p.k) > -1 && (pk.indexOf(p.k) > -1 ? needsBand(bandOf(p), sh) || state.bands[p.k] : !!state.bands[p.k] && !!ruleWhy(p, sh)));
    if (askP.length) h += '<div class="vo-ages">' + askP.map(p => ageSeg('k:' + p.k, state.bands[p.k] || '', first(p.name) + ' · Age', e['band.' + p.k], baseAdult(p))).join('') + '</div>';
    // A certification (First Aid's) is asked of each person going on, by name, as they're ticked (after
    // the sixth critic, Oct 15: once for a pair, and only checked at Sign up).
    if (question(sh).length) h += certBlock(sh);
    // Nobody here can take it for its age (signed in): what's open to them.
    const ruled = ageFirst && !contact && ppl.length && !state.add && ppl.every(p => ruleWhy(p, sh) || minesOn(sh).some(m => keyOfMine(m) === p.k));
    if (ruled && ppl.some(p => ruleWhy(p, sh))) h += tooYoung(sh, underOf(bandOf(ppl.find(p => ruleWhy(p, sh))), sh));
    if (state.add && !contact) h += addBox();
    // A phone for the people under this email, once (the one they gave this year, or the registration's,
    // is used); Change on your own pill asks it again, for this sign-up and your other shifts.
    const sameOnes = picked(sh).filter(p => !p.email);
    if (signed() && (!me().phone || state.phoneEdit) && (sameOnes.length || nameSelf())) h += '<div class="vo-box vo-box--me vo-box--one">' + fld('me1', 'phone', 'Phone', 'tel', state.phoneEdit ? 'For the committee’s foreman · Your other shifts too' : 'For the committee’s foreman', ' autocomplete="tel" inputmode="tel"', true) + '</div>';
    if (!ruleBlocks(sh)) h += alsoBlock(sh);
    if (!question(sh).length) h += ruleAsk(sh);
    if (screening(sh)) h += '<fieldset class="vo-q"><legend class="vo-label">Child-safety screening</legend><span class="rf-seg" role="radiogroup">' + [['yes', 'Screened'], ['not_yet', 'Not yet']].map(x => '<label class="rf-tog"><input type="radio" name="screened" value="' + x[0] + '"' + (state.ans.screened === x[0] ? ' checked' : '') + (e.screened ? ' aria-invalid="true"' : '') + '><span>' + I.check + x[1] + '</span></label>').join('') + '</span>' + (e.screened ? '<p class="vo-errline">' + I.alert + esc(e.screened) + '</p>' : '<p class="vo-help">Shown to the committee’s foreman only</p>') + '</fieldset>';
    h += '<details class="vo-notefld"' + (state.ans.noteOpen ? ' open' : '') + ' data-notefld><summary>Note for the foreman</summary><label class="vo-in"><span class="ogc-sr">Note for the foreman</span><input name="note" data-f="ans" maxlength="200" value="' + esc(state.ans.note || '') + '"><small class="is-help">For the committee’s foreman only</small></label></details>';
    // One way out of the opened row: its Close at the top (no Cancel here).
    h += '<div class="vo-who__foot">' + (state.footErr ? '<p class="vo-errline" role="alert">' + I.alert + esc(state.footErr) + '</p>' : '') + signupBtn(sh) + '</div>';
    return h;
  }
  // The age below a shift's rule, for "Open to under 21": the rule's own age, or 18 for Under 18.
  const underOf = (b, sh) => b === 'u18' ? 18 : minAge(sh);
  // Who a certification is asked of: yourself the first time, those ticked, someone being typed in.
  function certWho(sh) {
    const out = [];
    if (!adding(sh) && selfCount()) out.push({ k: 'me', name: first(state.me1.first) || '' });
    picked(sh).forEach(p => out.push({ k: p.k, name: first(p.name) }));
    if (pendAdd()) out.push({ k: 'add', name: first(state.add.first) || '' });
    return out;
  }
  const certOf = k => ((state.ans.q || {})[k]) || '';
  function certBlock(sh) {
    const who = certWho(sh), one = who.length < 2;
    if (!who.length) return '';
    return '<div class="vo-certs">' + who.map(p => {
      const e = state.err['q.' + p.k], nm = 'q-' + p.k.replace(/[^a-z0-9]+/gi, '-');
      return '<fieldset class="vo-q' + (e ? ' is-bad' : '') + '"><legend class="vo-label">' + esc(one || !p.name ? 'Certification' : p.name + ' · Certification') + '</legend><span class="rf-seg" role="radiogroup">' + question(sh).map(x => '<label class="rf-tog"><input type="radio" name="' + esc(nm) + '" data-cert="' + esc(p.k) + '" value="' + esc(x) + '"' + (certOf(p.k) === x ? ' checked' : '') + (e ? ' aria-invalid="true"' : '') + '><span>' + I.check + esc(x) + '</span></label>').join('') + '</span>' +
        (e ? '<p class="vo-errline" role="alert">' + I.alert + esc(e) + '</p>' : '') + '</fieldset>';
    }).join('') + '</div>';
  }
  // Someone typed into Add someone (a first name, or an email): they're counted, and go on with Sign up.
  const pendAdd = () => !!(state.add && (String(state.add.first || '').trim() || String(state.add.email || '').trim()));
  // "Only 2 open": said only while the places are all taken by those ticked and someone else could be.
  const capWords = (sh, ppl) => { const o = open(sh); if (o === Infinity || pickN(sh) < o) return ''; const more = adding(sh); return (ppl || circle().filter(p => !more || !minesOn(sh).some(m => keyOfMine(m) === p.k))).some(p => state.pick.indexOf(p.k) < 0 && !whyNot(p, sh)) ? 'Only ' + o + ' open' : ''; };
  // Sign up says the people (after the fifth critic, Oct 15: "Sign up 2 · 1 day" read oddly): "Sign up ·
  // Edna", "Sign up · Edna and Walter", "Sign up · Daniel, Esther and Lydia"; four or more "Sign up · 4
  // people"; with Also on days "… · 2 days". While a name is being typed, the count.
  function goNames(sh) {
    const ns = [];
    if (!adding(sh) && selfCount()) ns.push(first(state.me1.first));
    picked(sh).forEach(p => ns.push(first(p.name)));
    if (pendAdd()) ns.push(first(state.add.first));
    return ns;
  }
  function peopleWords(ns, n, typing) {
    const ok = ns.length === n && ns.every(Boolean) && uniq(ns.map(low)).length === ns.length;
    // Up to four names ("Amos, Sarah, Noah and Ella"; after the sixth critic, Oct 15), then a count; a
    // label that can't fit on one line falls back to the count (data-fit).
    return !n ? '' : n >= 5 || !ok || typing ? (n > 1 ? plural(n, 'person', 'people') : ok ? ns[0] : '') : listAnd(ns);
  }
  function signupWords(sh, typing) {
    const n = pickN(sh), a = alsoOn(sh).length, days = a ? ' · ' + (a + 1) + ' days' : '';
    if (state.busyAct === 'join') return { full: 'Signing up…', alts: [] };
    const who = peopleWords(goNames(sh), n, typing);
    const full = 'Sign up' + (who ? ' · ' + who : '') + days;
    return { full, alts: uniq([n > 1 ? 'Sign up · ' + plural(n, 'person', 'people') + days : '', 'Sign up' + (n > 1 ? ' ' + n : '') + days, 'Sign up']).filter(x => x && x !== full) };
  }
  const signupLabel = sh => signupWords(sh).full;
  const signupBtn = sh => { const w = signupWords(sh); return '<button type="button" class="wk-btn" data-signup="' + esc(sh.id) + '" data-fit="' + esc(JSON.stringify(w.alts)) + '"' + (pickN(sh) && !state.busyAct && !ruleBlocks(sh) ? '' : ' disabled') + '>' + esc(w.full) + '</button>'; };
  // While typing (no redraw, so the cursor stays): Sign up's words and the places line follow.
  function syncFoot(typing) {
    const sh = find(state.open);
    if (!sh) return;
    const b = root.querySelector('[data-signup]'), c = root.querySelector('[data-count]');
    if (b) { const w = signupWords(sh, typing); b.textContent = w.full; b.dataset.fit = JSON.stringify(w.alts); b.disabled = !(pickN(sh) && !state.busyAct && !ruleBlocks(sh)); fitBtns(b.parentNode); }
    if (c) c.textContent = capWords(sh);
  }
  function alsoBlock(sh) {
    const xs = sameTime(sh);
    if (!xs.length) return '';
    return '<div class="vo-also"><p class="vo-label" id="vo-al-' + esc(sh.id) + '">Also on</p><div class="vo-also__days" role="group" aria-labelledby="vo-al-' + esc(sh.id) + '">' + xs.map(x => {
      const why = alsoWhy(x, sh), on = !why && state.also.indexOf(x.id) > -1;
      return '<button type="button" class="vo-also__d" data-also="' + esc(x.id) + '" aria-pressed="' + on + '"' + (why ? ' aria-disabled="true" title="' + esc(why) + '"' : ' title="' + esc(whenLong(x) + ' · ' + span(x)) + '"') + '>' + I.check +
        '<b>' + esc(dayWord(eve(x)).slice(0, 3) + (night(x) ? ' night' : ' ' + O.fmtDate(eve(x).date, 'day'))) + '</b><small>' + esc(why || (x.unlimited ? 'No limit' : open(x) + ' open')) + '</small></button>';
    }).join('') + '</div></div>';
  }
  // A field: its label above it, always seen (after the fourth critic, Oct 15: the label was only the
  // placeholder, so a filled box said nothing of what it held), its error under it, in the house form's
  // style (bold, sentence case). f is the state bag (me1, add, ans).
  function fld(f, name, label, type, help, attrs, wide) {
    const v = (state[f] || {})[name], e = state.err[f + '.' + name];
    return '<label class="vo-in vo-in--l' + (e ? ' is-bad' : '') + (wide ? ' vo-full' : '') + '"><span class="vo-in__l">' + esc(label) + '</span><input name="' + name + '" data-f="' + f + '" type="' + type + '" value="' + esc(v || '') + '"' + (e ? ' aria-invalid="true"' : '') + (attrs || '') + '>' +
      (e ? '<small role="alert">' + (e.html || esc(e)) + '</small>' : help ? '<small class="is-help">' + esc(help) + '</small>' : '') + '</label>';
  }
  // The first time: who you are (one person). Signed in without a name: just the name. (signup: the Sign up
  // form, where "For someone else" is offered; the waitlist and Take place are for the person themselves.)
  // Their age goes with the name (after the sixth critic, Oct 15), one plain choice instead of the Under 18
  // box: asked of everyone going on, so a minor is never named by missing a tick. A shift with an age rule
  // asks it first, above the form (whoBlock), so it isn't asked twice; the waitlist doesn't ask it.
  function selfBox(sh, full, signup, noAge) {
    const t = typed();
    // Coming back on this tab after leaving: the phone given then, for the same email (the server's, from
    // the places this tab made; after the fifth critic, Oct 15: Abe's was blank).
    const heldPhone = !signed() && me() && me().phone && t.email && low(me().email) === low(t.email) ? me().phone : '';
    if (full && !state.me1.touched) state.me1 = Object.assign({ first: t.first || '', last: t.last || '', email: t.email || '', phone: tabPhone || heldPhone || t.phone || '', band: t.band || '' }, state.me1, { touched: true });
    const ret = encodeURIComponent(location.pathname + '?year=' + state.year + '&shift=' + sh.id);
    const contact = signup && contactOnly();
    const askAge = !noAge && !contact && !(minAge(sh) > 0 && signup) && (full || !(me() && me().band));
    return '<div class="vo-box vo-box--me' + (contact ? ' is-contact' : '') + '">' + autoPill(full) +
      fld('me1', 'first', 'First name', 'text', '', ' autocomplete="given-name"') + fld('me1', 'last', 'Last name', 'text', '', ' autocomplete="family-name"') +
      (full ? fld('me1', 'email', 'Email', 'email', '', ' autocomplete="email" inputmode="email"') + fld('me1', 'phone', 'Phone', 'tel', '', ' autocomplete="tel" inputmode="tel"') +
        '<input class="vol-hp" name="hp" data-f="me1" tabindex="-1" autocomplete="off" aria-hidden="true">' : '') +
      (askAge ? ageSeg('me1', state.me1.band, 'Age', state.err['me1.band']) : '') +
      // A quiet way to say "I'm not helping": the registration form's own words, "For someone else".
      (signup && !adding(sh) ? '<label class="vo-same vo-minor vo-forother"><input type="checkbox" data-forother' + (contactOnly() ? ' checked' : '') + '><span>For someone else</span>' + (contactOnly() ? '<small>Not on the shift</small>' : '') + '</label>' : '') +
      (full ? '<p class="vo-help">Confirmed by email · No password · Signed up before? <a href="' + esc((W.signin || '') + '?return=' + ret) + '">Sign in</a></p>' : '') + '</div>';
  }
  // The demo's Autofill (the local site and the shared prototype only; never on ogbbc.org), as on the
  // registration form: made-up details for a first-timer, so a demo needn't type them (Nov 1, Michael).
  // In the demo's own dark pill, so no one takes it for part of the sheet.
  const autoPill = full => (W.dev || W.prototype) && full ? '<p class="vo-auto"><button type="button" class="ogc-mock" data-autofill title="Fills these with made-up details · Demo only">' + svg('M14.5 9.5a3.5 3.5 0 1 1-1-2.45M13.4 12.6 20 19.2M17.5 16.7l1.8-1.8M15.6 14.8l1.4-1.4') + 'Autofill</button></p>' : '';
  const DEMO_ME = [['Anna', 'Porter', '765-555-0142'], ['Esther', 'Whitaker', '765-555-0153'], ['Leah', 'Hale', '765-555-0164'], ['Mary', 'Ellison', '765-555-0168']];
  function autofill() {
    let n = 0;
    try { n = +localStorage.getItem('ogc-autofill-n') || 0; localStorage.setItem('ogc-autofill-n', String(n + 1)); } catch (e) { /* the first again */ }
    const d = DEMO_ME[n % DEMO_ME.length], m = state.me1 = state.me1 || {};
    const put = (k, v) => { if (!String(m[k] || '').trim()) { m[k] = v; delete state.err['me1.' + k]; } };
    put('first', d[0]); put('last', d[1]); put('email', (m.first + '.' + m.last).toLowerCase().replace(/[^a-z.]+/g, '') + '@example.com'); put('phone', d[2]); put('band', '21');
    redraw('[data-signup]'); syncFoot(true);
    say.textContent = 'Filled in';
  }
  // Add someone: a name, and their own email (they confirm it), or "Uses Lois's email" for someone who
  // shares yours (a husband, a wife, a child): on your email, confirmed with yours. The last name starts
  // as yours; change it if it isn't.
  // Your email: signed in, typed the first time, or (adding to a shift you hold) that place's.
  const heldEmail = () => { const sh = find(state.open), m = sh && adding(sh) ? minesOn(sh).find(x => !x.added) : null; return m ? low(m.email) : ''; };
  const ownEmail = () => myEmail() || (formSelf() ? low(state.me1.email) || heldEmail() : '');
  const canShare = () => !vouched() && (signed() || formSelf());
  // Whose email it is, by name ("Uses Lois’s email"; never "my", after the sixth critic, Oct 15).
  const ownerFirst = () => first(myName() || (formSelf() ? state.me1.first : '') || selfName());
  const sameWordsLabel = () => ownerFirst() ? 'Uses ' + ownerFirst() + '’s email' : 'Same email';
  // Someone young signing up (Under 18, or a Youngfolk or a minor by the registration): Add someone
  // says "Another person", not "Husband, wife, child" (after the fifth critic, Oct 15).
  const teen = () => { if (state.me1 && state.me1.band && state.me1.band !== '21') return true; const p = circle().find(x => x.self), i = p && p.info; return !!(i && (i.yf || (i.years != null && i.years < 18) || i.age === 'minor')); };
  function addBox() {
    const a = state.add || {}, same = !!a.same && canShare();
    return '<div class="vo-box" data-addform><p class="vo-label">Add someone</p>' + fld('add', 'first', 'First name', 'text', '', ' autocomplete="off"') + fld('add', 'last', 'Last name', 'text', '', ' autocomplete="off"') +
      (same ? '' : fld('add', 'email', 'Their email', 'email', '', ' autocomplete="off" inputmode="email"', true)) +
      (canShare() ? '<label class="vo-same"><input type="checkbox" data-samemail' + (same ? ' checked' : '') + '><span>' + esc(sameWordsLabel()) + '</span></label>' : '') +
      ageSeg('add', a.band, 'Age', state.err['add.band']) +
      '<p class="vo-help">' + (same ? 'Confirmed with ' + (ownerFirst() ? ownerFirst() + '’s email' : 'the same email') : 'They confirm by email · The place is held until then') + '</p>' +
      '<div class="vo-box__acts"><button type="button" class="vo-link" data-addcancel>Cancel</button><button type="button" class="wk-btn wk-btn--line wk-btn--small" data-addsave>Add</button></div></div>';
  }
  // "For someone else" (after the sixth critic, Oct 15: about three taps for each extra person): right
  // under the contact, a list of names. One first name, their last name, their age, and Enter adds them
  // and leaves a fresh field. The first person's last name starts blank (after the ninth critic, Oct 16:
  // it was the contact's, "Miller" for Rachel Miller's Brubakers); each next one starts with the last
  // name of the person added before. The age is each person's own choice, never carried (after the eighth
  // critic, Oct 16: carried, a child was easily recorded as an adult): one tap a person. Each added is a
  // pill with ×; all go under the contact's email, so no email is asked for each.
  function namesBox(sh) {
    if (!state.add) state.add = { last: lastOf(state.lastAdded || ''), same: true, band: '' };
    const a = state.add, e = state.err, ppl = picked(sh);
    // Others this tab signed up before (the next shift, the same family): a tap puts them back on.
    const back = circle().filter(p => state.pick.indexOf(p.k) < 0 && !p.email && !whyNot(p, sh));
    let h = '<div class="vo-box vo-nl" data-addform><p class="vo-label" id="vo-nl-' + esc(sh.id) + '">Who’s helping</p>';
    if (ppl.length) h += '<ul class="vo-nl__l" aria-labelledby="vo-nl-' + esc(sh.id) + '">' + ppl.map(p => '<li class="vo-nl__p"><span class="vo-wp__av" aria-hidden="true">' + esc(initials(p.name)) + '</span><span class="vo-nl__t"><b>' + esc(p.name) + '</b>' + (bandOf(p) ? '<small>' + esc(bandWords(bandOf(p))) + '</small>' : '') + '</span><button type="button" class="vo-nl__x" data-unadd="' + esc(p.k) + '" aria-label="' + esc('Remove ' + p.name) + '">' + I.close + '</button></li>').join('') + '</ul>';
    if (back.length) h += '<p class="vo-nl__back">' + back.map(p => '<button type="button" class="vo-link" data-pick="' + esc(p.k) + '">' + I.plus + esc(first(p.name)) + '</button>').join('') + '</p>';
    h += fld('add', 'first', ppl.length ? 'Next first name' : 'First name', 'text', '', ' autocomplete="off" enterkeyhint="done"') + fld('add', 'last', 'Last name', 'text', '', ' autocomplete="off" enterkeyhint="done"') +
      ageSeg('add', a.band, 'Age', e['add.band']) +
      '<div class="vo-nl__go"><button type="button" class="wk-btn wk-btn--line wk-btn--small" data-addsave>Add</button><p class="vo-help">' + esc((open(sh) !== Infinity && ppl.length >= open(sh) ? 'Only ' + open(sh) + ' open · ' : 'Enter adds · ') + (ownerFirst() ? 'Under ' + ownerFirst() + '’s email' : 'Under the contact’s email')) + '</p></div></div>';
    return h;
  }
  const lastOf = n => { const w = String(n || '').trim().split(/\s+/); return w.length > 1 ? w[w.length - 1] : ''; };
  // A rule in words (not an age, not a certification): one claim for everyone going on. Ages are each
  // person's own field; a certification is asked of each person (certBlock).
  function needWho(sh) {
    if (!sh.rule || question(sh).length || minAge(sh)) return [];
    const ppl = picked(sh).map(p => ({ name: first(p.name), me: !!p.self }));
    if (selfCount() && !adding(sh)) ppl.unshift({ name: first(state.me1.first) || '', me: true });
    if (pendAdd()) ppl.push({ name: first(state.add.first) || 'They', me: false });
    return ppl;
  }
  const needTick = sh => needWho(sh);
  const ruleOk = () => state.ans.rule === true || state.ans.rule === 'yes';
  // An age that doesn't meet the rule keeps the shift off: yourself the first time (the age asked at the
  // top), or the one being typed into Add someone.
  const ruleBlocks = sh => !!sh && minAge(sh) > 0 && ((selfCount() && !adding(sh) && formSelf() && bandOk(state.me1.band, minAge(sh)) === false) || (pendAdd() && bandOk(state.add.band, minAge(sh)) === false));
  function ruleAsk(sh) {
    const e = state.err.rule;
    // Take place (one person): the certification, once.
    if (question(sh).length) return '<fieldset class="vo-q"><legend class="vo-label">Certification</legend><span class="rf-seg" role="radiogroup">' + question(sh).map(x => '<label class="rf-tog"><input type="radio" name="question" value="' + esc(x) + '"' + (state.ans.question === x ? ' checked' : '') + (e ? ' aria-invalid="true"' : '') + '><span>' + I.check + esc(x) + '</span></label>').join('') + '</span>' + (e ? '<p class="vo-errline">' + I.alert + esc(e) + '</p>' : '') + '</fieldset>';
    if (minAge(sh)) return '';
    const who = needWho(sh);
    if (!who.length) return '';
    return '<label class="vo-claim' + (e ? ' is-bad' : '') + '"><input type="checkbox" name="rule"' + (state.ans.rule === true ? ' checked' : '') + (e ? ' aria-invalid="true"' : '') + '><span>' + esc(sh.rule) + '</span></label>' + (e ? '<p class="vo-errline" role="alert">' + I.alert + esc(e) + '</p>' : '');
  }
  // Not for them: the shift's rule said plainly, and the open shifts whose own rule lets them on (none, or
  // a lower age, shown beside each). This committee and this day first.
  function tooYoung(sh, under) {
    // Every open shift whose own rule lets them on, in time order: the same day first, then the days
    // after, then any before (after the fifth critic, Oct 15: nearest-first jumbled the times and left out
    // the Youngfolks' own Snack helper). Four, then the rest a tap away.
    const di = x => state.model.days.indexOf(eve(x)), d0 = di(sh);
    const band = x => AW(x) ? 3 : di(x) === d0 ? 0 : di(x) > d0 ? 1 : 2;
    const xs = state.shifts.filter(x => x !== sh && joinable(x) && open(x) > 0 && minAge(x) < under && !question(x).length && !minesOn(x).length)
      .sort((a, b) => band(a) - band(b) || sortKey(a) - sortKey(b) || a.committee.localeCompare(b.committee));
    const all = state.youngAll === sh.id, shown = all ? xs : xs.slice(0, 4);
    // Said once (after the sixth critic, Oct 15: "For 21 or older · Open to under 21"): the row already says its rule.
    return '<div class="vo-young" role="status"><p class="vo-young__h">' + I.info + '<span><b>' + esc(xs.length ? 'Open to under ' + (under <= 18 ? 18 : under) : 'No other shift open now') + '</b></span></p>' +
      (xs.length ? '<ul class="vo-young__l">' + shown.map(x => '<li><button type="button" class="vo-young__go" data-goto="' + esc(x.id) + '"><b>' + esc(x.role) + '</b><small>' + esc([whenShort(x), x.committee === sh.committee ? '' : x.committee, minAge(x) ? minAge(x) + ' or older' : ''].filter(Boolean).join(' · ')) + '</small></button></li>').join('') + '</ul>' : '') +
      (xs.length > shown.length ? '<p class="vo-young__more"><button type="button" class="vo-link" data-youngall="' + esc(sh.id) + '">' + esc((xs.length - shown.length) + ' more') + '</button></p>' : '') + '</div>';
  }
  // Full: the waitlist (the first time, with who you are). A place offered for a swap: Take place.
  // Who may wait (after the fifth critic, Oct 15: Join waitlist didn't ask who): the same Who's helping
  // pills as Sign up, for the people on this email (yourself, your household); someone with their own
  // email waits under it.
  const waitPeople = sh => circle().filter(p => !p.email && !waitsOn(sh).some(w => low(w.name) === low(p.name)));
  const waitPicked = sh => waitPeople(sh).filter(p => state.pick.indexOf(p.k) > -1 && !whyNot(p, sh));
  function waitBlock(sh, swapSeat) {
    const ws = waitsOn(sh);
    let h = '';
    if (ws.length) {
      h += '<p class="vo-full">On waitlist · ' + esc(listAnd(uniq(ws.map(w => first(w.name))))) + ' · Email when a place opens</p><p class="vo-mine__acts">' +
        ws.map(w => '<button type="button" class="vo-link" data-unwait="' + w.rid + '">' + esc('Leave waitlist' + (ws.length > 1 ? ' · ' + first(w.name) : '')) + '</button>').join('') + '</p>';
      if (swapSeat || !(signed() || vouched()) || !waitPeople(sh).length) return h;
    }
    const ask = !swapSeat && (signed() || vouched());
    // One label: the people's own "Who's helping?" when they're asked; else "Full" over the form.
    h += ask ? (ws.length ? '' : '<p class="vo-full">Full · Email when a place opens</p>') : '<div class="vo-who__h"><span class="vo-label">Full</span></div>' + (swapSeat ? '<p class="vo-full">' + esc((swapSeat.l && names() ? swapSeat.l : 'Someone') + ' is looking for a replacement') + '</p>' : '');
    if (ask) {
      const ppl = waitPeople(sh);
      h += '<div class="vo-who__h"><span class="vo-label" id="vo-ww-' + esc(sh.id) + '">Who’s helping</span></div><div class="vo-pills" role="group" aria-labelledby="vo-ww-' + esc(sh.id) + '">' + ppl.map(p => {
        const no = whyNot(p, sh), on = !no && state.pick.indexOf(p.k) > -1, sub = no ? no.why : p.self ? '' : kindWords(p.info);
        return '<button type="button" class="vo-wp' + (no && no.busy ? ' is-busy' : '') + '" data-pick="' + esc(p.k) + '" aria-pressed="' + on + '"' + (no ? ' aria-disabled="true"' : '') + '><span class="vo-wp__av" aria-hidden="true">' + esc(initials(p.name)) + '</span><span class="vo-wp__tx"><b>' + esc(p.name) + '</b>' + (sub ? '<small>' + esc(sub) + '</small>' : '') + '</span></button>';
      }).join('') + '</div>';
    } else if (!signed()) h += selfBox(sh, true, false, true);
    const wn = ask ? waitPicked(sh).map(p => first(p.name)) : [], wl = ask ? peopleWords(wn, wn.length) : '';
    return h + '<div class="vo-who__foot">' + (state.footErr ? '<p class="vo-errline" role="alert">' + I.alert + esc(state.footErr) + '</p>' : '') +
      (swapSeat ? '<button type="button" class="wk-btn" data-take="' + esc(sh.id) + '">' + (state.busyAct === 'take' ? 'Taking…' : 'Take place') + '</button>'
        : '<button type="button" class="wk-btn" data-waitgo="' + esc(sh.id) + '" data-fit="' + esc(JSON.stringify(wn.length > 1 ? ['Join waitlist · ' + plural(wn.length, 'person', 'people'), 'Join waitlist'] : ['Join waitlist'])) + '"' + (state.busyAct || (ask && !wn.length) ? ' disabled' : '') + '>' + (state.busyAct === 'wait' ? 'Joining…' : esc('Join waitlist' + (wl ? ' · ' + wl : ''))) + '</button>') + '</div>' +
      (swapSeat || ws.length || ask ? '' : '<p class="vo-help vo-help--end">Email when a place opens</p>');
  }
  function takeBlock(sh, swapSeat) {
    // Signed in: their own age, when the rule needs it and it isn't known (asked once, kept).
    const selfP = signed() ? circle().find(p => p.self) : null, askSelf = selfP && minAge(sh) && needsBand(bandOf(selfP), sh);
    return '<div class="vo-who__h"><span class="vo-label">Take place</span></div><p class="vo-full">' + esc((swapSeat.l && names() ? swapSeat.l : 'Someone') + ' is looking for a replacement') + '</p>' +
      (askSelf ? ageSeg('k:me', '', 'Age', state.err['band.me']) : '') + (selfP && minAge(sh) && bandOk(bandOf(selfP), minAge(sh)) === false ? tooYoung(sh, underOf(bandOf(selfP), sh)) : '') +
      (!signed() ? selfBox(sh, true) + (bandOk(state.me1.band, minAge(sh)) === false ? tooYoung(sh, underOf(state.me1.band, sh)) : '') : '') + ruleAsk(sh) +
      '<div class="vo-who__foot">' + (state.footErr ? '<p class="vo-errline" role="alert">' + I.alert + esc(state.footErr) + '</p>' : '') + '<button type="button" class="wk-btn" data-take="' + esc(sh.id) + '"' + (state.busyAct || ruleBlocks(sh) ? ' disabled' : '') + '>' + (state.busyAct === 'take' ? 'Taking…' : 'Take place') + '</button></div>';
  }

  // Unconfirmed: where the email went (in full: she typed it, and may have mistyped it), Resend and
  // Change email for as long as it's unconfirmed.
  function confirmHelp(ids, where) {
    // Where it went: the address typed on this device (its places carry it), in full, to catch a typo.
    const to = (me() && me().email) || (mine().find(m => ids.indexOf(m.rid) > -1) || {}).email || '', h = +live().confirm_hours || 0;
    const ed = state.emailEdit === where;
    const box = ed ? '<form class="vol-chemail" data-emailform="' + esc(where) + '" data-ids="' + esc(ids.join(' ')) + '" novalidate><label class="vol-f' + (state.emailErr ? ' is-bad' : '') + '"><span>Email</span><input name="email" type="email" autocomplete="email" inputmode="email" value="' + esc(state.emailVal != null ? state.emailVal : to) + '"' + (state.emailErr ? ' aria-invalid="true"' : '') + '>' +
        (state.emailFix ? '<small class="vol-err">' + esc(domainOf(state.emailVal)) + '? · <button type="button" class="wk-linklike" data-emailfix>Use ' + esc(domainOf(state.emailFix)) + '</button> · <button type="button" class="wk-linklike" data-emailkeep>Keep</button></small>' : state.emailErr ? '<small class="vol-err">' + esc(state.emailErr) + '</small>' : '<small>The confirmation goes here</small>') + '</label>' +
        '<p class="vol-chemail__btns"><button type="submit" class="wk-btn wk-btn--small">Send</button> <button type="button" class="wk-linklike" data-emailoff>Cancel</button></p></form>' : '';
    return '<p class="vol-statehelp">Check your email' + (to ? ' · Sent to <b>' + esc(to) + '</b>' : '') + '<br>' +
      (ed ? '' : '<span class="vol-ctools"><button type="button" class="wk-linklike" data-resend="' + esc(ids.join(' ')) + '">Resend</button> · <button type="button" class="wk-linklike" data-chemail="' + esc(where) + '">Change email</button></span>') +
      (h > 0 ? '<br><small>Unconfirmed places open again after ' + h + ' hours</small>' : '') + '</p>' + box;
  }
  const domainOf = e => String(e || '').split('@')[1] || '';

  // Where the shift is, on the campus map; in the week (or a preview) the picture opens the guide's Places
  // on it, and Directions (Nov 5, docs/34 §6.1) is a quiet link under the line to the guide's own planner
  // (Sign up stays the sheet's filled button). A preview's as-of and tz go along, as the guide's links do.
  // (ended: the shift is over; its map stays, its Directions goes; r2c, last round.)
  function whereMap(p, test, ended) {
    const c = state.campus, b = c && O.map && O.map.buildingFor && O.map.buildingFor(c, p, state.model.places);
    if (!b) return '';
    if (test) return true;
    const preview = q.get('preview') === '1', pass = k => q.get(k) ? '&' + k + '=' + encodeURIComponent(q.get(k)) : '';
    const guide = (W.base || '/annual-conference/') + 'guide/?year=' + encodeURIComponent(state.year) + '&view=places&to=' + encodeURIComponent(p.code) + (preview ? '&preview=1' : '') + pass('as-of') + pass('tz');
    const w = O.map.whereIs ? O.map.whereIs(c, p, state.model.places) : { kind: 'building' }, walk = !ended && (w.kind === 'pin' || w.kind === 'building' || (w.kind === 'outdoor' && !!w.b));
    const marksB = [b.name].concat(c.items.filter(i => (i.kind === 'dining' || i.kind === 'worship') && i.name !== b.name).map(i => i.name));
    // (Nov 5, §6.1: with the year, a room in the build gets the door-to-room picture; before the week the
    // picture opens the place dialog, §5.2 (shared/ogc-map-dialog.js).)
    return (O.map.mini ? O.map.mini(c, p, state.model.places, Object.assign({ year: state.year }, isWeek() || preview ? Object.assign({ href: guide, hrefTitle: 'Open the map' }, walk ? { dirs: { href: guide + '&dirs=1' }, dirsQuiet: true } : {}) : { dialog: true })) : '<div class="vol-map">' + O.map.campusSvg(c, { mark: b.name, fit: marksB, small: true, aspect: 340 / 180, title: p.name + ' on the campus map' }) + '</div>');
  }

  // The place dialog (Nov 5, docs/34 §5.2; shared/ogc-map-dialog.js): a shift's small map before the week
  // opens the same dialog as the Conference page, so the sign-up is never left. The year's rows there
  // lead to the Conference page's own sheet for them; Directions only in the week (or a preview).
  if (O.map && typeof O.map.placeDialog === 'function' && O.map.placeDialog.use) O.map.placeDialog.use(() => {
    if (!state.model || !state.campus) return null;
    const preview = q.get('preview') === '1', pass = k => q.get(k) ? '&' + k + '=' + encodeURIComponent(q.get(k)) : '';
    const page = (W.base || '/annual-conference/') + '?year=' + encodeURIComponent(state.year), now = today();
    const rowsOf = d => (d.items || []).concat(d.allDay || [], d.nightly || []).filter((it, i, a) => it.place && !it.cancelled && a.indexOf(it) === i);
    return {
      year: state.year, places: state.model.places, care: state.model.nearby || [], member: false,
      campus: () => Promise.resolve({ c: state.campus, places: state.model.places }),
      rows: () => [].concat.apply([], state.model.days.map((d, i) => rowsOf(d).map(it => ({ id: it.id, code: it.place.code, title: it.title,
        day: O.fmtDate(d.date, 'weekdayShort'), time: it.start != null ? O.formatTime(it.start) : (it.startText || ''), at: i * 1440 + (it.start != null ? it.start : it.sort < 1439 ? it.sort : 0), past: d.date < now })))),
      rowHref: id => page + '&event=' + encodeURIComponent(id) + (preview ? '&preview=1' : '') + pass('as-of') + pass('tz'),
      dirs: (p, room) => {
        if (!(isWeek() || preview)) return '';
        const w = O.map.whereIs(state.campus, p, state.model.places);
        // (room: the dialog's room asked for by its number, the balcony: &room=2-220; r2c, last round.)
        const rm = room && room.number != null ? '&room=' + encodeURIComponent(room.floor + '-' + room.number) : '';
        return w.kind === 'pin' || w.kind === 'building' || (w.kind === 'outdoor' && !!w.b) ? (W.base || '/annual-conference/') + 'guide/?year=' + encodeURIComponent(state.year) + '&view=places&to=' + encodeURIComponent(p.code) + rm + '&dirs=1' + (preview ? '&preview=1' : '') + pass('as-of') + pass('tz') : '';
      }
    };
  });

  /* ---------------------------------------------------------------- Your week */

  // The Conference's services, drawn faintly behind the shifts (kinds from the schedule's fixed list).
  const SVC = { worship: 'Worship', communion: 'Communion', council: 'Council', singing: 'Singing' };
  function services() {
    const out = [];
    state.model.days.forEach(d => (d.items || []).forEach(it => {
      if (!SVC[it.kind] || it.start == null || it.audience === 'preteens' || it.audience === 'youngfolks') return;
      out.push({ day: d, start: it.start, end: it.end != null ? it.end : it.start + 150, name: SVC[it.kind], title: it.title });
    }));
    return out;
  }
  // Whose week: the people with shifts (you first). Pills switch between them.
  function weekPeople() {
    const ppl = circle(), self = signed() ? ppl.find(p => p.self) : null;
    const withShifts = ppl.filter(p => mine().some(m => keyOfMine(m) === p.k));
    // A visitor's own shifts (not signed in): under the name they signed up with (a contact who isn't on a
    // shift has only those of the people they signed up).
    if (!signed() && mine().some(m => keyOfMine(m) === 'me')) { const n = selfName(); if (n) withShifts.unshift({ k: 'me', name: n, self: true }); }
    const out = [];
    if (self) out.push(self);
    withShifts.forEach(p => { if (!out.some(x => x.k === p.k)) out.push(p); });
    return out;
  }
  let calColW = 50;
  function weekCard(inSheet) {
    const ppl = weekPeople();
    // Opens on someone with shifts (after the third critic, Oct 15: Edith, signed in, had left hers while
    // Harold stayed, and the sheet opened on her empty week under a bar saying "1 shift").
    const k = ppl.some(p => p.k === state.wk) ? state.wk : ((ppl.find(p => mine().some(m => keyOfMine(m) === p.k)) || ppl[0] || {}).k || '');
    const who = ppl.find(p => p.k === k);
    const shs = mine().filter(m => keyOfMine(m) === k).map(m => ({ m, sh: find(m.shift) })).filter(x => x.sh).sort((a, b) => sortKey(a.sh) - sortKey(b.sh));
    // The shift being looked at, dashed: the one opened for sign-up, or (beside the list on a laptop, never
    // in the sheet) the row under the pointer. After the sixth critic, Oct 15: a card hovered on the way
    // down to the bar showed in the sheet as if it were theirs.
    const pend = state.open ? find(state.open) : !inSheet && state.hover && root.querySelector('.vo-side') ? find(state.hover) : null;
    const pendShown = pend && !shs.some(x => x.sh === pend) ? pend : null;
    const clashW = pendShown && shs.find(x => overlaps(x.sh, pendShown));
    // Never a zero (after the eighth critic, Oct 16: Martha, after she left, still had an empty week drawn
    // with Add to calendar): someone shown with no shifts is "No shifts", with no week drawn unless it holds
    // something real (a shift being looked at, the posted services) and nothing to add to a calendar.
    const none = !shs.length && !!who;
    let h = '<div class="vo-card vo-wk"><div class="vo-wk__h"><h2' + (inSheet ? ' id="vo-wsheet-t"' : '') + '>' + esc(weekWord(who)) + '</h2><span class="vo-wk__sub">' + (shs.length ? esc(plural(shs.length, 'shift')) : none ? 'No shifts' : '') + '</span></div>';
    if (ppl.length > 1) h += '<div class="vo-wkp" role="group" aria-label="Whose week">' + ppl.map(p => '<button type="button" data-wk="' + esc(p.k) + '" aria-pressed="' + (p.k === k) + '">' + I.check + esc(first(p.name)) + '</button>').join('') + '</div>';
    // The days chosen with "Also on" show dashed too.
    const alsoShown = pendShown && state.open === pendShown.id ? alsoOn(pendShown).filter(x => !shs.some(y => y.sh === x)) : [];
    // Your own open shift's "Also on" days, chosen: dashed the same way.
    const ownA = !pendShown && pend && state.open === pend.id ? ownAlsoOn(pend).filter(x => !shs.some(y => y.sh === x)) : [];
    if (shs.length || pendShown || ownA.length || services().length) h += calendar(shs, pendShown ? [pendShown].concat(alsoShown) : ownA.length ? ownA : null, clashW);
    if (clashW) h += '<p class="vo-clash" role="status">' + esc((who ? first(who.name) + ' · ' : '') + busyWords(clashW.sh)) + '</p>';
    // What just happened, in the sheet itself (a Leave: who left, the shift, who's still on it, Undo).
    const nt = inSheet && state.wkNote;
    if (nt) h += '<div class="vo-wknote' + (nt.kind === 'ok' ? '' : ' is-no') + '" data-wknote><p>' + (nt.kind === 'ok' ? I.check : I.alert) + '<span><b>' + esc(nt.text) + '</b>' + (nt.lines || []).concat(nt.sub ? [nt.sub] : []).map(l => ' · ' + esc(l)).join('') + '</span></p>' +
      (nt.ids && nt.ids.length ? '<button type="button" class="vol-toast__b" data-wkundo>Undo</button>' : '') + '</div>';
    if (shs.length) {
      h += '<ul class="vo-wkl">' + shs.map(x => {
        // Waiting is only for someone added under their own email; on yours, it's your email to check.
        const sh = x.sh, m = x.m, tags = [!m.confirmed ? (m.added ? 'Waiting to confirm' : 'Check your email') : '', m.swap ? 'Swap open' : ''].filter(Boolean);
        const asking = state.wkLeave === m.rid;
        const started = !ahead(sh);
        return '<li><div class="vo-wkl__r"><button type="button" class="vo-wkl__go" data-goto="' + esc(sh.id) + '"><span class="vo-wkl__d">' + esc(AW(sh) ? 'All week' : night(sh) ? dayWord(eve(sh)).slice(0, 3) + ' night' : O.fmtDate(eve(sh).date, 'weekdayShort') + ' ' + O.fmtDate(eve(sh).date, 'mdShort')) + '</span><b>' + esc(sh.role) + '</b><small>' + esc((AW(sh) ? weekRange(sh) : span(sh)) + (placeName(sh) ? ' · ' + placeName(sh) : '')) + '</small>' +
          (tags.length ? '<span class="vo-tagline">' + tags.map(t => '<span class="vo-tag">' + esc(t) + '</span>').join('') + '</span>' : '') + '</button>' +
          (started || asking ? '' : '<button type="button" class="vo-link" data-wkleave="' + m.rid + '" aria-label="' + esc('Leave ' + sh.role + ', ' + whenShort(sh) + (ppl.length > 1 ? ', ' + m.name : '')) + '">Leave</button>') + '</div>' +
          (asking ? '<div class="vo-lvwrap">' + SU.leaveSheet({ scope: 'wk:' + m.rid, id: 'vo-wlv-' + m.rid, heading: 'Leave this shift?', goes: first(m.name) + ' leaves', head: headWords([sh], [m]), swap: !m.swap, busy: state.busyAct === 'leave' }) + '</div>' : '') + '</li>';
      }).join('') + '</ul>';
    }
    // This email's places another device made, still to confirm (the server's pending): said, with Resend.
    const pa = pendAll();
    if (pa.length) h += '<div class="vo-wk__sec"><p class="vo-label">' + I.clock + 'Waiting to confirm</p>' + pa.map(p => { const sh = find(p.shift); return '<div class="vo-wi"><b>' + esc(sh.role) + '</b><small>' + esc(first(p.name) + ' · ' + whenShort(sh)) + '</small></div>'; }).join('') +
      '<p class="vo-wi__acts"><small>Confirm link sent' + (me() && me().email ? ' to ' + esc(me().email) : '') + '</small><button type="button" class="wk-linklike" data-resend="' + esc(pa.map(p => p.rid).join(' ')) + '">Resend</button></p></div>';
    const allShifts = uniq(mine().map(m => m.shift)).filter(find);
    if (allShifts.length && !none) h += '<a class="wk-btn wk-btn--line wk-btn--wide" href="' + esc(icsHref(allShifts)) + '" data-icsa>' + I.cal + 'Add to calendar</a>';
    // People added by email: their places are held until they answer.
    const added = mine().filter(m => m.added && !m.confirmed);
    if (added.length) {
      const byP = {};
      added.forEach(m => { const kk = keyOfMine(m); (byP[kk] = byP[kk] || { name: m.name, list: [] }).list.push(m); });
      h += '<div class="vo-wk__sec"><p class="vo-label">' + I.clock + 'Waiting to confirm</p>' + Object.values(byP).map(p => '<div class="vo-wi"><b>' + esc(p.name) + '</b>' + p.list.map(m => { const sh = find(m.shift); return sh ? '<small>' + esc(sh.role + ' · ' + whenShort(sh)) + '</small>' : ''; }).join('') +
        '<span class="vo-wi__acts"><small>Emailed · Confirm or Not me</small><button type="button" class="wk-linklike" data-resend="' + esc(p.list.map(m => m.rid).join(' ')) + '">Resend</button></span></div>').join('') + '</div>';
    }
    // Your own unconfirmed places (the first time): where the email went, Resend, Change email.
    const own = mine().filter(m => !m.added && !m.confirmed);
    if (own.length) h += '<div class="vo-wk__sec">' + confirmHelp(own.map(m => m.rid), 'week') + '</div>';
    const ws = (live().waits || []).filter(w => find(w.shift));
    if (ws.length) h += '<div class="vo-wk__sec"><p class="vo-label">' + I.mail + 'Waitlist</p>' + ws.map(w => { const sh = find(w.shift); return '<div class="vo-wi"><b>' + esc(sh.role) + '</b><small>' + esc(whenShort(sh)) + '</small><span class="vo-wi__acts"><button type="button" class="wk-linklike" data-unwait="' + w.rid + '">Leave waitlist</button></span></div>'; }).join('') + '</div>';
    // Show my name (one setting, on the server); someone you signed up has their own switch.
    if (allShifts.length && names()) {
      // Someone Under 18 is never named on the lists (a count only): no switch for them.
      const self = selfRecs().filter(x => !x.minor), fors = uniq(mine().filter(x => x.for && !x.added && !x.minor && selfRecs().indexOf(x) < 0).map(x => x.name));
      const sw = (label, on, help, attr) => '<label class="vol-switch"><input type="checkbox" ' + attr + (on ? ' checked' : '') + '><span>' + esc(label) + '</span><small>' + esc(help) + '</small></label>';
      if (self.length || fors.length) h += '<div class="vo-wk__set">' + (self.length ? sw(selfName() ? 'Show ' + first(selfName()) + '’s name' : 'Show name', self.every(x => !x.hide && (!x.for || x.shown)), self.some(x => !x.confirmed) ? 'Shows once confirmed' : 'As ' + SU.firstL(selfName() || 'First L.') + ' on shift lists', 'data-showname') : '') +
        fors.map(n => sw('Show ' + first(n) + '’s name', mine().some(x => x.name === n && x.shown), 'As ' + SU.firstL(n) + ' on shift lists', 'data-showname="' + esc(n) + '"')).join('') + '</div>';
    }
    // The COA's volunteering phone (a role's, settings volunteer_phone), quietly at the foot; none set,
    // nothing (canonical, Oct 14).
    const vp = String(S().volunteer_phone || '').trim();
    if (vp) h += '<p class="vo-wk__phone">' + I.phone + '<span>Volunteering · <a href="tel:' + esc(vp.replace(/[^\d+]/g, '')) + '">' + esc(vp) + '</a></span></p>';
    // Everything signed up for this year (registration, shifts, tournaments) is on Your sign-ups.
    if (signed()) h += '<p class="vo-wk__mine"><a href="' + esc(mineHref()) + '">Your sign-ups</a></p>';
    return h + '</div>';
  }
  // The week as a small calendar: days across, hours down; services faint; this person's shifts in
  // tan; the shift being looked at dashed (red when it clashes). A name shows only where it fits whole.
  function calendar(shs, pend, clash) {
    const svcs = services();
    // All week posts are a bar over the days they cover, not a block that fills each column.
    const pl = (Array.isArray(pend) ? pend : [pend]).filter(Boolean);
    const wk = shs.filter(x => AW(x.sh)), tm = shs.filter(x => !AW(x.sh)), pendW = pl.find(AW) || null;
    const pends = pl.filter(x => !AW(x));
    const all = tm.map(x => x.sh).concat(pends);
    const used = state.model.days.filter(d => svcs.some(s => s.day === d) || state.shifts.some(sh => !AW(sh) && eve(sh) === d) || wk.concat(pendW ? [{ sh: pendW }] : []).some(x => d.date >= x.sh.day.date && d.date <= (x.sh.lastDay || x.sh.day).date));
    if (!used.length) return '';
    const at = sh => ({ col: used.indexOf(eve(sh)), s: night(sh) ? sh.start + 1440 : sh.start, e: night(sh) ? sh.end + 1440 : sh.end });
    let lo = 420, hi = 1440;
    svcs.forEach(s => { lo = Math.min(lo, s.start); hi = Math.max(hi, s.end); });
    all.forEach(sh => { const a = at(sh); lo = Math.min(lo, a.s); hi = Math.max(hi, a.e); });
    // Round the clock (a 3–6 AM dorm shift is drawn on the evening before, past midnight): up to 6 AM.
    lo = Math.max(300, Math.floor(lo / 60) * 60); hi = Math.min(1800, Math.ceil(hi / 60) * 60);
    const HH = 17, y = m => (m - lo) / 60 * HH, H = (hi - lo) / 60 * HH;
    const block = (cls, s, e, label, title) => {
      const top = y(Math.max(s, lo)), hgt = Math.max(5, y(Math.min(e, hi)) - top - 1);
      const font = /is-svc/.test(cls) ? 'italic 9px ' + serif() : '600 9.5px ' + sans();
      const nl = label ? fitLines(label, calColW, font) : 0;
      return '<div class="vo-b ' + cls + '" style="top:' + top.toFixed(1) + 'px;height:' + hgt.toFixed(1) + 'px" title="' + esc(title) + '">' + (nl && nl * 11 + 3 <= hgt ? '<span class="vo-b__t">' + esc(label) + '</span>' : '') + '</div>';
    };
    const ticks = []; for (let m = Math.ceil(lo / 240) * 240; m <= hi; m += 240) if (m > lo) ticks.push(m);
    let h = '<div class="vo-cal" style="--vo-cols:' + used.length + ';--vo-hh:' + HH + '" aria-hidden="true"><span></span>' + used.map(d => '<div class="vo-cal__h"><b>' + esc(dayWord(d).slice(0, 3)) + '</b><span>' + esc(O.fmtDate(d.date, 'day')) + '</span></div>').join('');
    // The All week bars, over the columns they cover.
    const bar = (sh, cls) => { const a = Math.max(0, used.findIndex(d => d.date >= sh.day.date)), z = used.reduce((k, d, i) => d.date <= (sh.lastDay || sh.day).date ? i : k, a); return '<div class="vo-cal__wk ' + cls + '" style="grid-column:' + (a + 2) + ' / ' + (z + 3) + '" title="' + esc(sh.role + ' · All week') + '"><span>' + esc(sh.role) + '</span></div>'; };
    const bars = wk.map(x => bar(x.sh, 'is-mine' + (x.m.confirmed ? '' : ' is-wait'))).join('') + (pendW && !wk.some(x => x.sh === pendW) ? bar(pendW, 'is-pend') : '');
    if (bars) h += '<div class="vo-cal__wks">' + bars + '</div>';
    h += '<div class="vo-cal__ax" style="height:' + H + 'px">' + ticks.map(m => '<span style="top:' + y(m) + 'px">' + esc(O.formatTime(m % 1440, { compact: true }).replace(' ', '')) + '</span>').join('') + '</div>';
    used.forEach((d, col) => {
      h += '<div class="vo-cal__col" style="height:' + H + 'px">';
      svcs.filter(s => s.day === d).forEach(s => { h += block('is-svc', s.start, s.end, s.name, s.title + ' · ' + O.formatRange(s.start, s.end, { compact: true })); });
      tm.forEach(x => { const a = at(x.sh); if (a.col === col) h += block('is-mine' + (x.m.confirmed ? '' : ' is-wait'), a.s, a.e, x.sh.role, x.sh.role + ' · ' + span(x.sh)); });
      pends.forEach((p, i) => { const a = at(p); if (a.col === col) h += block('is-pend' + (clash && !i ? ' is-clash' : ''), a.s, a.e, p.role, p.role + ' · ' + span(p)); });
      h += '</div>';
    });
    return h + '</div>' + '<p class="ogc-sr">' + esc(shs.length ? shs.map(x => x.sh.role + ', ' + whenShort(x.sh)).join('; ') : 'No shifts yet') + '</p>';
  }
  const cssVar = (n, f) => { try { return getComputedStyle(document.documentElement).getPropertyValue(n).trim() || f; } catch (e) { return f; } };
  const serif = () => cssVar('--wk-serif', 'Georgia, serif') || 'Georgia, serif';
  const sans = () => cssVar('--wk-sans', 'Arial, sans-serif') || 'Arial, sans-serif';
  let ctx2d;
  const textW = (t, font) => { ctx2d = ctx2d || document.createElement('canvas').getContext('2d'); ctx2d.font = font; return ctx2d.measureText(t).width; };
  // How many lines a label takes in a width, never splitting a word (0: a word doesn't fit at all).
  function fitLines(t, w, font) {
    const words = String(t).split(' '), lines = [];
    let cur = '';
    for (const wd of words) {
      if (textW(wd, font) > w) return 0;
      const tryL = cur ? cur + ' ' + wd : wd;
      if (textW(tryL, font) <= w) cur = tryL; else { lines.push(cur); cur = wd; }
    }
    if (cur) lines.push(cur);
    return lines.length;
  }
  // After a draw: the room a label has in one day's column, measured; drawn again if it changed.
  function fitCal() {
    const col = Array.from(document.querySelectorAll('.vo-cal__col')).find(x => x.offsetWidth > 0);
    if (!col) return;
    const w = Math.floor(col.getBoundingClientRect().width - 6);
    if (w > 16 && Math.abs(w - calColW) > 1) { calColW = w; drawWeek(); }
  }
  // Only Your week again (a hover, the open row, whose week): the list keeps its focus and scroll.
  function drawWeek() {
    const a = root.querySelector('.vo-side');
    if (a) a.innerHTML = weekCard();
    if (wsheet.open) drawSheet();
  }

  /* ---------------------------------------------------------------- on a phone: a bar, and Your week as a sheet */

  const pbar = document.createElement('button');
  pbar.type = 'button';
  pbar.className = 'ogc vo-pbar';
  pbar.hidden = true;
  pbar.setAttribute('aria-haspopup', 'dialog');
  document.body.appendChild(pbar);
  function pbarDraw() {
    const on = pbarOn();
    pbar.hidden = !on;
    document.body.classList.toggle('has-vo-pbar', on);
    if (!on) return;
    const n = uniq(mine().map(m => m.shift).concat(pendAll().map(p => p.shift))).filter(find).length, wl = (live().waits || []).filter(x => find(x.shift)).length;
    const w = uniq(mine().filter(m => m.added && !m.confirmed).map(m => low(m.email) + '|' + low(m.name))).length;
    pbar.innerHTML = '<span class="vo-pbar__t"><b>' + esc(weekWord()) + I.up + '</b><small>' + esc([n ? plural(n, 'shift') : '', wl ? 'Waitlist · ' + wl : ''].filter(Boolean).join(' · ')) + '</small></span>' + (w ? '<span class="vo-tag">' + I.clock + esc(w + ' waiting') + '</span>' : '');
    pbar.setAttribute('aria-label', weekWord() + (n ? ', ' + plural(n, 'shift') : ''));
  }
  const wsheet = document.createElement('dialog');
  wsheet.className = 'ogc wk-sheet vo-wsheet';
  wsheet.setAttribute('aria-labelledby', 'vo-wsheet-t');
  document.body.appendChild(wsheet);
  function drawSheet() {
    const y = wsheet.scrollTop;
    wsheet.innerHTML = '<div class="wk-sheet__in vo"><button type="button" class="vo-wsheet__x" data-wclose aria-label="Close">' + I.close + '</button>' + weekCard(true) + '</div>';
    wsheet.scrollTop = y;
    fitCal();
  }
  pbar.addEventListener('click', () => { state.hover = ''; state.wkNote = null; drawSheet(); wsheet.showModal(); wsheet.classList.add('is-in'); const x = wsheet.querySelector('[data-wclose]'); if (x) x.focus({ preventScroll: true }); });
  wsheet.addEventListener('click', e => {
    if (e.target === wsheet || e.target.closest('[data-wclose]')) { wsheet.close(); return; }
    onClick(e);
  });
  wsheet.addEventListener('change', onChange);
  wsheet.addEventListener('close', () => {
    wsheet.classList.remove('is-in'); pbar.focus({ preventScroll: true });
    // A note with Undo still in its two minutes comes back as the toast once the sheet is gone.
    const nt = state.wkNote;
    state.wkNote = null;
    if (nt && nt.ids && nt.ids.length && Date.now() - nt.at < 110000) showToast(nt);
  });

  /* ---------------------------------------------------------------- opening a row, choosing who */

  // The screen's usable foot: above whatever is fixed there (Your week's bar, the toast), so a row the
  // page brings into view is never left under one (after the fourth critic, Oct 15).
  function clearBottom() {
    let y = innerHeight;
    // (These are fixed, so offsetParent is always null: drawn or not is whether they have a box.)
    [pbar, bar].forEach(el => { if (el && !el.hidden && el.getClientRects().length) { const r = el.getBoundingClientRect(); if (r.height && r.top < y && r.top > innerHeight * 0.4) y = r.top; } });
    return y - 8;
  }

  function openRow(id, o) {
    o = o || {};
    const sh = find(id);
    if (!sh) return;
    if (state.open === id && !o.keep) { closeRow(); return; }
    state.open = id; state.add = null; state.err = {}; state.footErr = ''; state.ans = {}; state.leaving = ''; state.leaveWho = null; state.mapOpen = ''; state.also = []; state.addMore = ''; state.ownAlso = []; state.ownAlsoFor = ''; state.phoneEdit = false; state.askedRow = [];
    // Yourself, ticked to start with, when nothing keeps you off it (your own shift: nothing ticked); on
    // this visit, those chosen last (after the fifth critic, Oct 15), where they may go on.
    const self = circle().find(p => p.self);
    const last = minesOn(sh).length || !state.lastPick ? [] : state.lastPick.filter(k => { const p = circle().find(x => x.k === k); return p && !whyNot(p, sh); });
    state.pick = minesOn(sh).length ? [] : last.length ? last : self && !whyNot(self, sh) ? ['me'] : vouched() ? circle().filter(p => !p.email && !whyNot(p, sh)).map(p => p.k) : [];
    state.pick = state.pick.concat(state.added.map(p => p.k).filter(k => state.pick.indexOf(k) < 0)).slice(0, isFull(sh) ? 10 : Math.max(0, open(sh) - selfCount()));
    setUrl({ shift: id }, true);
    render();
    // In the week grid the row's content is the band under the card's row (the card keeps the row's id).
    const band = document.getElementById('vo-band');
    const r = band && band.querySelector('#vo-p-' + CSS.escape(id)) ? band : document.getElementById('vo-r-' + id);
    if (r === band && !o.noScroll) bandIntoView();
    else if (r && !o.noScroll) {
      const b = r.getBoundingClientRect();
      if (b.top < 0 || b.bottom > clearBottom()) r.scrollIntoView({ block: b.height > innerHeight - 140 ? 'start' : 'center', behavior: matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth' });
    }
    // Focus follows the page (after the fourth critic, Oct 15: the age question sat first and the cursor
    // jumped past it to First name): the age question's first answer when it leads, else the first field.
    // (Only what's drawn: the note's field inside its closed fold can't take focus.)
    const vis1 = sel => r ? Array.from(r.querySelectorAll(sel)).find(x => x.checkVisibility ? x.checkVisibility() : x.getClientRects().length) : null;
    // On a phone a text field is never focused by itself (after the eighth critic, Oct 16: the keyboard
    // came up over the shift's details): the age's answer, a person's pill, or the row's own Close keep
    // the place; the keyboard waits for a tap into the form.
    const phone = matchMedia('(max-width: 767px), (hover: none) and (pointer: coarse)').matches;
    const f = vis1('.vo-panel .vo-who .vo-age input[type=radio]') || (phone ? null : vis1('.vo-panel .vo-who input:not(.vol-hp):not([type=checkbox]):not([type=radio])')) || vis1('.vo-panel [data-pick]:not([aria-disabled="true"])') ||
      (phone ? vis1('[data-open="' + CSS.escape(id) + '"][aria-expanded="true"]') || (band ? vis1('.vo-wg__band [data-open]') : null) : vis1('.vo-panel .vo-who button') || vis1('.vo-panel button'));
    if (f && o.focus !== false) f.focus({ preventScroll: true });
    say.textContent = sh.role + ', ' + whenLong(sh) + ', ' + span(sh);
  }
  function closeRow(focusBack) {
    const id = state.open;
    state.open = ''; state.add = null; state.err = {}; state.footErr = ''; state.leaving = ''; state.addMore = ''; state.ownAlso = []; state.ownAlsoFor = ''; state.askedRow = [];
    setUrl({ shift: '', swap: '' }, true);
    render();
    const b = id && root.querySelector('[data-open="' + CSS.escape(id) + '"]');
    if (b && focusBack !== false) b.focus({ preventScroll: true });
  }
  // A redraw that keeps the cursor where it was (a pill, a field).
  function redraw(sel) {
    const a = document.activeElement, keep = sel || (a && a !== document.body && root.contains(a) ? keyFor(a) : '');
    const pos = a && a.selectionStart != null ? [a.selectionStart, a.selectionEnd] : null;
    render();
    const x = keep && root.querySelector(keep);
    if (x) { x.focus({ preventScroll: true }); if (pos && x.setSelectionRange && x.type !== 'email') try { x.setSelectionRange(pos[0], pos[1]); } catch (e) { /* not a text field */ } }
  }
  function keyFor(el) {
    const ds = el.dataset || {};
    // The band's Close shares the card's data-open: kept as itself.
    if ('open' in ds && el.closest && el.closest('#vo-band')) return '#vo-band [data-open]';
    for (const k of ['pick', 'open', 'day', 'job', 'also', 'ownalso', 'ownalsogo', 'wk', 'signup', 'addopen', 'addsave', 'addmore', 'leave', 'close', 'hidefull', 'samemail', 'minor']) if (k in ds) return '[data-' + k + (ds[k] ? '="' + CSS.escape(ds[k]) + '"' : '') + ']';
    if (el.name && el.dataset.f) return '[data-f="' + el.dataset.f + '"][name="' + el.name + '"]';
    if (el.name) return '[name="' + CSS.escape(el.name) + '"]' + (el.value && (el.type === 'radio' || el.type === 'checkbox') ? '[value="' + CSS.escape(el.value) + '"]' : '');
    return '';
  }
  function pick(k) {
    const sh = find(state.open), p = circle().find(x => x.k === k);
    if (!sh || !p || whyNot(p, sh)) return;
    const i = state.pick.indexOf(k);
    if (i > -1) state.pick.splice(i, 1);
    else if (isFull(sh) || pickN(sh) < open(sh)) state.pick.push(k);
    else { say.textContent = 'Only ' + open(sh) + ' open'; return; }
    // Who was chosen last, for the next row opened on this visit (after the fifth critic, Oct 15: Ruth
    // unticked herself on every row). Kept only on the page, never stored.
    state.lastPick = state.pick.slice();
    delete state.err.rule; state.footErr = '';
    redraw('[data-pick="' + CSS.escape(k) + '"]');
    drawWeek();
  }
  const emailOk = e => /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(String(e || '').trim());
  const DOMAINS = { 'gmial.com': 'gmail.com', 'gmai.com': 'gmail.com', 'gmal.com': 'gmail.com', 'gmail.co': 'gmail.com', 'gnail.com': 'gmail.com', 'yaho.com': 'yahoo.com', 'yahooo.com': 'yahoo.com', 'hotmial.com': 'hotmail.com', 'outlok.com': 'outlook.com', 'aol.co': 'aol.com', 'icloud.co': 'icloud.com' };
  const typoFix = e => { const m = /^([^@\s]+)@([^@\s]+)$/.exec(String(e || '').trim()); return m && DOMAINS[m[2].toLowerCase()] ? m[1] + '@' + DOMAINS[m[2].toLowerCase()] : ''; };
  // A likely typo is asked once, at the field: "gmial.com? · Use gmail.com · Keep".
  const typoErr = (bag, e) => { const fix = typoFix(e); return fix && state.typoOk !== bag + ':' + e ? { text: domainOf(e) + '? Use ' + domainOf(fix), html: esc(domainOf(e)) + '? · <button type="button" class="wk-linklike" data-typo="' + bag + '">Use ' + esc(domainOf(fix)) + '</button> · <button type="button" class="wk-linklike" data-typokeep="' + bag + '">Keep</button>' } : null; };
  // Add: the person typed becomes a pill, ticked. o.inline (from Sign up): no redraw here; false when
  // something's missing (the errors are at their fields).
  function addSave(o) {
    o = o || {};
    const sh = find(state.open), a = state.add || {}, e = {};
    // The contact's names list: always under the contact's email.
    const list = contactOnly() && !adding(sh || {});
    const share = (!!a.same || list) && canShare();
    const fn = String(a.first || '').trim(), ln = String(a.last || '').trim(), em = share ? ownEmail() : String(a.email || '').trim();
    // Enter in an empty name field of the list adds nobody and says nothing.
    if (list && !fn && !o.inline) return false;
    if (!fn) e['add.first'] = 'Their first name';
    if (!ln) e['add.last'] = 'Their last name';
    // (The list's names go under the contact's email, asked with Sign up: a name can come first.)
    if (share) { if (!emailOk(em) && !list) e['me1.email'] = 'Your email'; }
    else if (!emailOk(em)) e['add.email'] = em ? 'Check the email' : 'Their email';
    else { const t = typoErr('add', em); if (t) e['add.email'] = t; }
    // Their age, one plain choice (after the sixth critic, Oct 15); a shift whose age it doesn't meet
    // says the rule's words at it.
    if (!a.band) e['add.band'] = 'Choose one';
    else if (sh && minAge(sh) && bandOk(a.band, minAge(sh)) === false) e['add.band'] = 'Needs ' + minAge(sh) + ' or older';
    state.err = Object.assign({}, state.err, { 'add.first': '', 'add.last': '', 'add.email': '', 'add.band': '' }, e);
    Object.keys(state.err).forEach(k => { if (!state.err[k]) delete state.err[k]; });
    if (Object.keys(e).length) { if (!o.inline) { redraw(); focusBad(); } return false; }
    const name = fn + ' ' + ln;
    state.lastAdded = name; state.lastBand = a.band;
    // A person is their email and name (the same email as yours: someone under your email). Nothing
    // here looks anyone up.
    const same = share || low(em) === ownEmail();
    const p = { k: same ? 'n:' + low(name) : 'e:' + low(em) + '|' + low(name), name, email: same ? '' : em, info: null, minor: a.band === 'u18', band: a.band };
    state.bands[p.k] = a.band;
    // A certification answered while they were being typed goes with them.
    if (state.ans.q && state.ans.q.add) { state.ans.q[p.k] = state.ans.q.add; delete state.ans.q.add; }
    // The list keeps a fresh field and the last name carried; the age is asked of the next person again.
    state.add = list ? { last: ln, same: true, band: '' } : null;
    const was = state.added.findIndex(x => x.k === p.k);
    if (was > -1) state.added[was] = p; else if (!circle().some(x => x.k === p.k)) state.added.push(p);
    if (sh && state.pick.indexOf(p.k) < 0 && !whyNot(p, sh) && pickN(sh) < open(sh)) state.pick.push(p.k);
    if (o.inline) return true;
    redraw(list ? '[data-f="add"][name="first"]' : '[data-pick="' + CSS.escape(p.k) + '"]');
    drawWeek();
    say.textContent = name + ' added' + (sh && state.pick.indexOf(p.k) < 0 ? ' · Only ' + open(sh) + ' open' : '');
    return true;
  }
  function focusBad() {
    const x = root.querySelector('.vo-panel [aria-invalid="true"]');
    if (x) { x.focus({ preventScroll: true }); x.scrollIntoView({ block: 'center' }); }
  }

  /* ---------------------------------------------------------------- signing up */

  // What the server said no to, as a word and a next step.
  function refusal(r, sh) {
    const n = r.name ? first(r.name) + ' · ' : '';
    switch (r.status) {
      case 'full': return { msg: r.open ? plural(r.open, 'place') + ' left' : 'Just filled' };
      case 'busy': return { msg: n + 'Busy · ' + (find(r.busy.shift) || r.busy).role + (find(r.busy.shift) ? ' ' + span(find(r.busy.shift)) : '') };
      case 'minor': return { msg: n + 'Needs ' + r.min_age + ' or older' };
      case 'rule': return question(sh).length ? { msg: n + 'Certification · Choose one' } : minAge(sh) ? { msg: n + 'Age · Choose one' } : { msg: 'Confirm the rule', field: 'rule' };
      case 'screening': return { msg: 'Screening first', field: 'screened' };
      case 'dup': return { msg: n + 'Already signed up' };
      case 'started': return { msg: 'Started' };
      case 'ended': return { msg: 'Ended' };
      case 'closed': return { msg: 'Closed' };
      case 'not_open': return { msg: 'Not open yet' };
      case 'gone': return { msg: 'No longer offered' };
      default: return { msg: 'Not saved' };
    }
  }
  // Check here first (the server checks again): every error at its field, focus on the first.
  function check(sh, waiting) {
    const e = {}, m = state.me1 || {};
    // The waitlist and Take place ask who you are of anyone not signed in (an emailed link too). Adding
    // someone to a shift you hold a place on: you're known by that place.
    if ((formSelf() && !adding(sh)) || (waiting && !signed() && !vouched())) {
      if (!String(m.first || '').trim()) e['me1.first'] = 'Your first name';
      if (!String(m.last || '').trim()) e['me1.last'] = 'Your last name';
      if (!emailOk(m.email)) e['me1.email'] = String(m.email || '').trim() ? 'Check the email' : 'Your email';
      else { const t = typoErr('me1', String(m.email).trim()); if (t) e['me1.email'] = t; }
      if (String(m.phone || '').replace(/\D/g, '').length < 7) e['me1.phone'] = 'A phone number';
    } else if (nameSelf() && !waiting && !adding(sh)) {
      if (!String(m.first || '').trim()) e['me1.first'] = 'Your first name';
      if (!String(m.last || '').trim()) e['me1.last'] = 'Your last name';
    }
    if (!waiting) {
      // Each one's age, asked plainly (after the sixth critic, Oct 15): nobody goes on without it.
      if (((formSelf() && !contactOnly()) || nameSelf()) && !adding(sh) && !m.band && !(nameSelf() && me().band)) e['me1.band'] = 'Choose one';
      picked(sh).forEach(p => { if (needsBand(bandOf(p), sh)) e['band.' + p.k] = 'Choose one'; });
      if (signed() && (!me().phone || state.phoneEdit) && (picked(sh).some(p => !p.email) || nameSelf()) && String(m.phone || '').replace(/\D/g, '').length < 7) e['me1.phone'] = 'A phone number';
      if (question(sh).length) certWho(sh).forEach(p => { if (!certOf(p.k)) e['q.' + p.k] = 'Choose one'; });
      else if (needTick(sh).length && !ruleOk()) e.rule = 'Confirm the rule';
      if (screening(sh) && !state.ans.screened) e.screened = 'Choose one';
    }
    return e;
  }
  function joinBody(sh) {
    const m = state.me1 || {}, ppl = picked(sh);
    const b = { shifts: [sh.id].concat(alsoOn(sh).map(x => x.id)), answers: {}, show: true };
    const held = adding(sh) && !signed() ? minesOn(sh).find(x => !x.added) : null;
    if (held) { const w = String(held.name).trim().split(/\s+/); b.who = { first: w[0], last: w.slice(1).join(' '), email: held.email, phone: tabPhone || '' }; }
    else if (formSelf()) b.who = Object.assign({ first: String(m.first || '').trim(), last: String(m.last || '').trim(), email: String(m.email || '').trim(), phone: String(m.phone || '').trim(), minor: m.band === 'u18' && !contactOnly() }, contactOnly() ? { helping: false } : { band: m.band || '' });
    else if (signed() && (nameSelf() || ((!me().phone || state.phoneEdit) && m.phone))) b.who = { first: String(m.first || '').trim(), last: String(m.last || '').trim(), phone: String(m.phone || '').trim(), minor: m.band === 'u18' && nameSelf(), band: nameSelf() ? m.band || '' : '' };
    // Each one's age by name (bands), as answered or known; Under 18 also as the old mark.
    const bands = {};
    ppl.forEach(p => { const bd = bandOf(p); if (BANDS.some(x => x[0] === bd)) bands[p.name] = bd; });
    if (nameSelf() && m.band) bands[String(m.first || '').trim() + ' ' + String(m.last || '').trim()] = m.band;
    if (Object.keys(bands).length) b.bands = bands;
    const isMinor = p => bandOf(p) === 'u18' || (!bandOf(p) && !!p.minor);
    const adds = ppl.filter(p => p.email || isMinor(p)).map(p => ({ name: p.name, email: p.email || (held ? held.email : ownEmail()), minor: isMinor(p), band: bands[p.name] || '' }));
    // Signed in (or an emailed link): exactly the people ticked (perhaps only those added). The first
    // time: yourself, plus anyone added.
    // (Someone Under 18 goes with their mark, as an Add on your email.)
    const sameOnly = ppl.filter(p => !p.email && !isMinor(p)).map(p => p.name);
    if (held || (!formSelf() && !nameSelf())) b.people = sameOnly;
    // The first time: yourself (the server adds you) and anyone added on your email.
    else if (formSelf() && sameOnly.length) b.people = sameOnly;
    else if (nameSelf()) b.people = [String(m.first || '').trim() + ' ' + String(m.last || '').trim()].concat(sameOnly);
    if (adds.length) b.add = adds;
    // A certification each, by name (after the sixth critic, Oct 15); the first as the old single answer.
    if (question(sh).length) {
      const qs = {};
      certWho(sh).forEach(p => { const nm = p.k === 'me' ? (String(m.first || '').trim() + ' ' + String(m.last || '').trim()) : (circle().find(x => x.k === p.k) || {}).name; if (nm && certOf(p.k)) qs[nm.trim()] = certOf(p.k); });
      b.answers.question = Object.values(qs)[0] || state.ans.question || '';
      b.answers.questions = qs;
    }
    else if (sh.rule) b.answers.rule = true;
    if (state.ans.screened) b.answers.screened = state.ans.screened;
    if (state.ans.note) b.note = state.ans.note;
    if (m.hp) b.hp = m.hp;
    // An emailed link that vouches for the email goes with it (the server reads its token).
    if (vouched() && state.link.via) Object.assign(b, state.link.via);
    return b;
  }
  async function signUp(sh) {
    if (state.busyAct || !sh) return;
    // Someone typed into Add someone goes on with this Sign up (after the critic, Oct 15: "Amos" was
    // dropped without a word). Not complete: Sign up waits, and says so at their fields.
    if (pendAdd()) {
      // Your own fields first (a missing email is yours to fix, not theirs).
      const e0 = check(sh, false);
      if (Object.keys(e0).some(k => /^me1\./.test(k))) { state.err = e0; state.footErr = ''; redraw(); focusBad(); return; }
      const nm = first(state.add.first);
      if (!addSave({ inline: true })) { state.footErr = contactOnly() ? 'Finish adding ' + (nm || 'them') : (nm ? 'Finish adding ' + nm : 'Finish Add someone') + ' · Or Cancel it'; redraw(); focusBad(); return; }
    } else if (state.add) state.add = null;
    const e = check(sh, false);
    if (!pickN(sh)) { state.footErr = contactOnly() ? 'Add someone' : 'Choose who'; redraw(); if (contactOnly()) { const x = root.querySelector('.vo-panel [data-addopen]'); if (x) x.focus({ preventScroll: true }); } return; }
    state.err = e; state.footErr = '';
    if (Object.keys(e).length) { redraw(); focusBad(); say.textContent = Object.values(e).map(x => x.text || x).join('. '); return; }
    state.busyAct = 'join'; redraw('[data-signup]');
    let d;
    try { d = await post('vol/' + state.year + '/join', joinBody(sh)); }
    catch (err) {
      state.busyAct = '';
      if (err.data && err.data.why === 'fields') {
        const f = err.data.fields || {}, map = { first: 'me1.first', last: 'me1.last', email: 'me1.email', phone: 'me1.phone' };
        state.err = {}; Object.keys(f).forEach(k => { if (map[k]) state.err[map[k]] = f[k]; else state.footErr = f[k]; });
        redraw(); focusBad(); return;
      }
      state.footErr = err.status === 429 ? (err.data && err.data.why === 'confirm' ? 'Confirm your email first · The link is in your inbox' : 'Too many at once · Try later') : 'Not saved · Retry';
      redraw(); return;
    }
    state.busyAct = '';
    merge(d);
    const m = state.me1 || {};
    // A phone Changed on your own pill is now yours for the year (the server put it on your other shifts).
    if (signed() && m.phone && (state.phoneEdit || !me().phone) && live().me) { live().me.phone = String(m.phone).trim(); state.phoneEdit = false; }
    if (formSelf() && m.email) {
      const t1 = { first: m.first, last: m.last, email: d.email || m.email, band: contactOnly() ? '' : m.band || '' };
      tab.set('typed', t1); tabPhone = m.phone || '';
      if (!signed()) kept.set(ME1(), Object.assign({ phone: m.phone || '', at: Date.now() }, t1));
    }
    // Not signed in: the page learns who this device now holds places for (its hold), as on a reload.
    if (!signed() && d.hold) await loadLive().catch(() => {});
    const ok = d.results.filter(r => r.status === 'ok'), no = d.results.filter(r => r.status !== 'ok');
    if (ok.length) {
      const made = d.made || [], who = mine().filter(x => made.indexOf(x.rid) > -1);
      const waiting = who.filter(x => x.added && !x.confirmed).map(x => x.name);
      // Those who went on start the next row opened on this visit (never stored).
      state.lastPick = state.pick.filter(k => k === 'me' || circle().some(p => p.k === k));
      state.open = ''; state.pick = []; state.added = []; state.ans = {}; state.err = {}; state.footErr = ''; state.flash = sh.id; state.flashJoin = true; state.addMore = ''; state.add = null;
      setUrl({ shift: '', swap: '' }, true);
      render();
      // The row closed: keep it (now marked yours, flashing) in view, not the page's foot.
      const rr = document.getElementById('vo-r-' + sh.id);
      if (rr) { const bb = rr.getBoundingClientRect(); if (bb.top < 0 || bb.bottom > clearBottom()) rr.scrollIntoView({ block: 'center', behavior: matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth' }); }
      setTimeout(() => { if (state.flash === sh.id) { state.flash = ''; const r = document.getElementById('vo-r-' + sh.id); if (r) r.classList.remove('is-flash', 'is-join'); } }, 1700);
      // Several days at once: how many, and any day that said no ("Mon · Full"), at the toast.
      const days = ok.map(r => find(r.shift)).filter(Boolean), nos = no.map(r => { const x = find(r.shift); return (x ? dayWord(eve(x)).slice(0, 3) + ' · ' : '') + refusal(r, x || sh).msg; });
      state.also = [];
      // Shifts counted, people named: one line a shift ("Server · Sat, May 29 · Martha and Henry"),
      // never "2 shifts" for a couple's one (after the critic, Oct 15).
      const groups = byShift(who), lines = groups.length ? groups.map(g => shiftLine(g.sh, g.ms)) : days.map(x => shiftLine(x, []));
      const n = groups.length || days.length;
      const sub = [nos.length ? 'Not ' + nos.join(', ') : '', waiting.length ? listAnd(uniq(waiting)) + ' · Waiting to confirm' : '', !signed() && who.some(x => !x.added && !x.confirmed) ? 'Check your email' : ''].filter(Boolean).join(' · ');
      showToast({ kind: 'ok', text: n > 1 ? 'Signed up · ' + plural(n, 'shift') : 'Signed up', lines, sub, ids: made, shifts: (groups.length ? groups.map(g => g.sh) : days).map(x => x.id), ics: true });
      say.textContent = 'Signed up · ' + lines.join('; ');
      const x = root.querySelector('[data-open="' + CSS.escape(sh.id) + '"]') || bar.querySelector('[data-undo]');
      if (x) x.focus({ preventScroll: true });
    } else if (no.length) {
      const r = no[0], why = refusal(r, find(r.shift) || sh);
      if (why.field) state.err[why.field] = why.msg; else state.footErr = why.msg;
      redraw(); say.textContent = why.msg;
    }
  }

  async function undo(ids, t) {
    try {
      merge(await post('vol/' + state.year + '/undo', { ids })); hideToast();
      // The returner's card comes back with what it offered.
      if (t && t.again) { AG().done = false; kept.set('agdone-' + state.year, false); await loadLive().catch(() => {}); if (agVia()) await relink(); }
      render(); say.textContent = 'Undone';
    }
    catch (e) { showToast({ kind: 'error', text: 'Not undone · Leave instead' }); }
  }
  // Undo a Leave (the toast's, two minutes): the same places again, if they're still free. On the emailed
  // link's sheet, by its link; the sheet then shows them again.
  const UNLEAVE_NO = { full: 'Place taken · Sign up again', busy: 'Busy then · Not undone', dup: 'Already signed up', started: 'Started', late: 'Too late · Sign up again' };
  async function unleave(ids) {
    const via = state.link && state.link.a === 'leave' ? state.link.via : null;
    try {
      const d = await post('vol/' + state.year + '/unleave', Object.assign({ ids }, via || {}));
      merge(d);
      if (!(d.back || []).length) { const w = (d.no || [])[0]; showToast({ kind: 'error', text: (w && UNLEAVE_NO[w.why]) || 'Not undone' }); return; }
      if (via) await relink();
      hideToast(); render();
      const back = mine().filter(m => d.back.map(Number).indexOf(m.rid) > -1), lines = byShift(back).map(g => shiftLine(g.sh, g.ms));
      showToast({ kind: 'ok', text: 'Undone', lines: lines.length ? lines : [] });
      say.textContent = 'Undone' + (lines.length ? ' · ' + lines.join('; ') : '');
    } catch (e) { showToast({ kind: 'error', text: 'Not undone · Retry' }); }
  }
  // Who left and who's still on it, in the emailed Leave link's own words (after the seventh critic, Oct 15):
  // "Edna left" · "Usher · Sat, May 29 · Harold is still on it".
  function leftWords(sh, who) {
    const names = uniq(who.map(m => first(m.name)).filter(Boolean)), still = sh ? uniq(minesOn(sh).map(m => first(m.name)).filter(Boolean)) : [];
    return { text: names.length ? listAnd(names) + ' left' : 'Left shift', line: sh ? [sh.role, dayShort(sh)].concat(still.length ? [listAnd(still) + (still.length > 1 ? ' are' : ' is') + ' still on it'] : []).join(' · ') : '' };
  }
  async function leave(ids, sh, from) {
    if (!ids.length) return;
    // A "Confirmed · 2 shifts" line from the email's link no longer holds once one is left.
    if (state.link && state.link.a === 'confirm') state.link = null;
    const who = mine().filter(m => ids.indexOf(m.rid) > -1);
    state.busyAct = 'leave'; redraw();
    try {
      merge(await post('vol/' + state.year + '/leave', { ids }));
      state.busyAct = ''; state.leaving = ''; state.wkLeave = 0; state.footErr = '';
      // Left from Your week: it stays on the person who left (it switched silently to the other one).
      if (from === 'wk' && who[0]) state.wk = keyOfMine(who[0]);
      if (state.toast && (state.toast.ids || []).some(x => ids.indexOf(x) > -1)) hideToast();
      // Left from the opened row: it closes back to the row, kept in view (after the critic, Oct 15).
      const wasOpen = sh && state.open === sh.id;
      if (wasOpen) { state.open = ''; state.addMore = ''; state.add = null; state.flash = sh.id; state.flashJoin = false; setUrl({ shift: '', swap: '' }, true); }
      render();
      if (wasOpen) {
        const r = document.getElementById('vo-r-' + sh.id);
        if (r) { const bb = r.getBoundingClientRect(); if (bb.top < 0 || bb.bottom > clearBottom()) r.scrollIntoView({ block: 'center' }); const x = r.querySelector('[data-open]'); if (x) x.focus({ preventScroll: true }); }
        setTimeout(() => { if (state.flash === sh.id) { state.flash = ''; const q2 = document.getElementById('vo-r-' + sh.id); if (q2) q2.classList.remove('is-flash', 'is-join'); } }, 1700);
      }
      // Who left, the shift once, who's still on it ("Edna left · Usher · Sat, May 29 · Harold is still on
      // it"); Undo for two minutes, as Sign up has (after the third critic, Oct 15). Inside Your week's sheet
      // it's said in the sheet, with Undo there (showToast).
      const lw = leftWords(sh, who);
      showToast({ kind: 'ok', text: lw.text, lines: lw.line ? [lw.line] : [], ids, left: true });
    } catch (e) {
      state.busyAct = ''; state.footErr = e.data && e.data.why === 'started' ? 'Started · Call the foreman' : 'Not saved · Retry'; redraw();
      if (!state.leaving) showToast({ kind: 'error', text: state.footErr });
    }
  }
  // The one Leave sheet's buttons, wherever it's drawn: the opened row (row:ID), Your week (wk:RID), the
  // emailed link (link).
  function lvAct(act, sc) {
    if (sc === 'link') {
      const k = state.link;
      if (!k) return;
      if (act === 'go') return linkLeave();
      if (act === 'swap') { const one = linkPick(k); if (one.length === 1) linkSwap(one[0].rid); return; }
      if (act === 'keep') { state.link = null; state.footErr = ''; render(); say.textContent = 'Kept'; }
      return;
    }
    let m = /^row:(.+)$/.exec(sc);
    if (m) {
      const sh = find(m[1]);
      if (!sh) return;
      const g = leaveChosen(minesOn(sh));
      if (act === 'go') { if (g.length) leave(g.map(x => x.rid), sh); return; }
      if (act === 'swap') { if (g.length === 1) swap(g[0].rid, true, sh); return; }
      if (act === 'keep') { state.leaving = ''; state.leaveWho = null; state.footErr = ''; redraw('[data-leave="' + CSS.escape(sh.id) + '"]'); }
      return;
    }
    m = /^wk:(\d+)$/.exec(sc);
    if (m) {
      const rid = +m[1], r = mine().find(x => x.rid === rid), sh = r && find(r.shift);
      if (act === 'go') return leave([rid], sh, 'wk');
      if (act === 'swap') { if (r) swap(rid, true, sh); return; }
      if (act === 'keep') { state.wkLeave = 0; drawWeek(); }
    }
  }
  async function waitFor(sh) {
    if (state.busyAct) return;
    if (!signed()) { const e = check(sh, true); state.err = e; if (Object.keys(e).length) { redraw(); focusBad(); return; } }
    state.busyAct = 'wait'; redraw();
    try {
      const b = { shift: sh.id }, m = state.me1 || {};
      if (!signed() && !vouched()) b.who = { first: m.first, last: m.last, email: m.email, phone: m.phone };
      // The people chosen (yourself, your household); an emailed link that vouches for the email goes with it.
      const ppl = signed() || vouched() ? waitPicked(sh) : [];
      if ((signed() || vouched()) && !ppl.length) { state.busyAct = ''; state.footErr = 'Choose who'; redraw(); return; }
      if (ppl.length) b.people = ppl.map(p => p.name);
      if (vouched() && state.link.via) Object.assign(b, state.link.via);
      merge(await post('vol/' + state.year + '/wait', b));
      state.busyAct = ''; state.footErr = '';
      if (!signed()) await loadLive().catch(() => {});
      redraw();
      showToast({ kind: 'ok', text: 'On waitlist', lines: [sh.role + ' · ' + dayShort(sh) + (ppl.length ? ' · ' + listAnd(ppl.map(p => first(p.name))) : '')], sub: 'Email when a place opens' });
    } catch (e) {
      state.busyAct = '';
      if (e.data && e.data.why === 'fields') { const f = e.data.fields || {}; state.err = {}; Object.keys(f).forEach(k => { state.err['me1.' + k] = f[k]; }); redraw(); focusBad(); return; }
      state.footErr = 'Not saved · Retry'; redraw();
    }
  }
  // Find replacement: the place stays yours, marked Swap open; the link lets anyone take it at once.
  async function swap(rid, on, sh) {
    try {
      const d = await post('vol/' + state.year + '/swap', { id: rid, on });
      merge(d); state.leaving = ''; state.wkLeave = 0;
      await loadLive().catch(() => {});
      render();
      if (on && d.swap && sh) copyLink(swapUrl(sh, d.swap), 'Link copied', 'Could you take my place? ' + sh.role + ', ' + whenShort(sh));
    } catch (e) { showToast({ kind: 'error', text: 'Not saved · Retry' }); }
  }
  const swapUrl = (sh, token) => location.origin + location.pathname + '?year=' + state.year + '&shift=' + encodeURIComponent(sh.id) + '&swap=' + encodeURIComponent(token);
  async function take(sh) {
    if (state.busyAct) return;
    const seatSwap = seatsOf(sh).find(p => p.swap);
    const token = state.swap || q.get('swap') || (seatSwap ? seatSwap.swap + '.' : '');
    const selfP = signed() ? circle().find(p => p.self) : null;
    if (ruleBlocks(sh) || (selfP && minAge(sh) && bandOk(bandOf(selfP), minAge(sh)) === false)) return;
    {
      // Their age, the one plain field: the first time with the name; signed in, when the rule needs it.
      const e = signed() ? {} : check(sh, true);
      if (!signed() && !(state.me1 || {}).band) e['me1.band'] = 'Choose one';
      if (selfP && minAge(sh) && needsBand(bandOf(selfP), sh)) e['band.me'] = 'Choose one';
      if (sh.rule && !question(sh).length && !minAge(sh) && !ruleOk()) e.rule = 'Confirm the rule';
      state.err = e; if (Object.keys(e).length) { redraw(); focusBad(); return; }
    }
    state.busyAct = 'take'; redraw();
    try {
      const m = state.me1 || {};
      const d = await post('vol/' + state.year + '/take', { swap: String(token), who: signed() ? (selfP && BANDS.some(x => x[0] === bandOf(selfP)) ? { band: bandOf(selfP) } : undefined) : { first: m.first, last: m.last, email: m.email, phone: m.phone, band: m.band || '' }, answers: { rule: true } });
      merge(d); state.busyAct = ''; state.swap = ''; state.open = ''; state.footErr = '';
      setUrl({ shift: '', swap: '' }, true);
      render();
      showToast({ kind: 'ok', text: 'Signed up', sub: sh.role + ', ' + whenShort(sh) });
    } catch (e) {
      state.busyAct = ''; state.footErr = e.data && e.data.why === 'busy' ? 'Busy · ' + (find(e.data.busy.shift) || e.data.busy).role : e.data && e.data.why === 'taken' ? 'Taken' : 'Not saved · Retry'; redraw();
    }
  }
  // Invite someone: a link to this shift, by the phone's own Share, or copied.
  function invite(id) {
    const sh = find(id), u = location.origin + location.pathname + '?year=' + state.year + '&shift=' + encodeURIComponent(id);
    copyLink(u, 'Link copied', minesOn(sh).length ? 'Join me: ' + sh.role + ', ' + whenShort(sh) + ' · ' + state.year + ' Annual Conference' : sh.role + ' · ' + whenShort(sh) + ' · ' + state.year + ' Annual Conference' + (open(sh) > 0 && open(sh) !== Infinity ? ' · ' + open(sh) + ' open' : ''));
  }
  function copyLink(url, done, text) {
    if (navigator.share && /Mobi|Android/i.test(navigator.userAgent)) { navigator.share({ text, url }).catch(() => {}); return; }
    const ok = () => { showToast({ kind: 'ok', text: done }); say.textContent = done; };
    const manual = () => showToast({ kind: 'ok', text: 'Link', sub: url });
    try { navigator.clipboard.writeText(url).then(ok, manual); } catch (e) { manual(); }
  }

  // Resend and Change email (an unconfirmed place keeps its seat; the confirmation goes to the new address).
  async function resend(ids) {
    try { const d = await post('vol/' + state.year + '/resend', { ids: ids.map(Number) }); showToast({ kind: 'ok', text: 'Sent', sub: d.email || '' }); }
    catch (e) { showToast({ kind: e.status === 429 ? 'ok' : 'error', text: e.status === 429 ? 'Sent · Just now' : 'Not sent · Retry' }); }
  }
  async function changeEmail(form, typosOk) {
    const val = form.email.value.trim(), ids = form.dataset.ids.split(' ').map(Number);
    state.emailVal = val; state.emailErr = ''; state.emailFix = '';
    if (!emailOk(val)) { state.emailErr = 'Enter your email'; return redrawEmail(); }
    try {
      const d = await post('vol/' + state.year + '/email', { ids, email: val, typos_ok: !!typosOk });
      merge(d);
      if (!signed()) tab.set('typed', Object.assign({}, tab.get('typed', {}), { email: d.email }));
      if (live().me) live().me.email = d.email;
      state.emailEdit = ''; state.emailVal = null;
      render();
      showToast({ kind: 'ok', text: 'Sent', sub: d.email });
    } catch (e) {
      if (e.data && e.data.why === 'typo') state.emailFix = e.data.fix;
      else state.emailErr = e.data && e.data.fields ? e.data.fields.email : e.status === 429 ? 'Too many at once · Try later' : 'Not saved · Retry';
      redrawEmail();
    }
  }
  function redrawEmail() {
    render();
    const x = document.querySelector('[data-emailform] input');
    if (x) x.focus();
  }

  /* ---------------------------------------------------------------- the toast */

  // The toast is seen; the page's one live line says it to a screen reader, once (after the fifth critic,
  // Oct 15: the toast was a second live region, and it never went away).
  const bar = document.createElement('div');
  bar.className = 'ogc vol-toast';
  bar.hidden = true;
  document.body.appendChild(bar);
  let toastTimer = 0, chipTimer = 0;
  function showToast(t) {
    // Your week's sheet is a modal: anything fixed outside it draws under its backdrop, out of reach
    // (after the seventh critic, Oct 15: "Left shift · Undo" sat under it). While it's open the note is
    // said inside the sheet, with its Undo there; when the sheet closes, a note with Undo comes back as the
    // toast, so Undo is never lost.
    if (wsheet.open) {
      hideToast();
      state.wkNote = Object.assign({ at: Date.now() }, t);
      say.textContent = [t.text].concat(t.lines || [], t.sub ? [t.sub] : []).join(' · ');
      drawSheet();
      // Focus stays in the sheet: on Undo, else on the note itself.
      const n = wsheet.querySelector('[data-wknote]'), u = n && n.querySelector('button');
      if (u) u.focus({ preventScroll: true }); else if (n) { n.tabIndex = -1; n.focus({ preventScroll: true }); }
      return;
    }
    state.toast = t;
    clearTimeout(toastTimer); clearTimeout(chipTimer);
    bar.classList.remove('is-chip');
    say.textContent = [t.text].concat(t.lines || [], t.sub ? [t.sub] : []).join(' · ');
    const undoBtn = t.ids && t.ids.length ? '<button type="button" class="vol-toast__b" data-undo>Undo</button>' : '';
    bar.classList.toggle('is-no', t.kind !== 'ok');
    // Right after signing up, the calendar is one tap: the shift's own file.
    const icsBtn = t.ics && t.shifts && t.shifts.length ? '<a class="vol-toast__b" href="' + esc(icsHref(t.shifts)) + '" data-icsa>' + I.cal + 'Calendar</a>' : '';
    bar.innerHTML = '<p>' + (t.kind === 'ok' ? I.check : I.alert) + '<span><b>' + esc(t.text) + '</b>' + (t.lines || []).map(l => '<small class="vol-toast__l">' + esc(l) + '</small>').join('') + (t.sub ? '<small>' + esc(t.sub) + '</small>' : '') + '</span></p>' + icsBtn + undoBtn +
      (t.retry ? '<button type="button" class="vol-toast__b" data-retry>Retry</button>' : '') +
      '<button type="button" class="vol-toast__x" data-dismiss aria-label="Close">' + I.close + '</button>';
    bar.hidden = false;
    document.body.classList.add('has-toast');
    document.body.style.setProperty('--vol-toast-h', bar.offsetHeight + 'px');
    // Undo stays two minutes, as long as the email waits (the server takes it back quietly until then).
    // After about 8 seconds the toast shrinks to a small chip, "✓ Signed up · Undo", so it never covers a
    // quarter of a phone (after the fifth critic, Oct 15); then it goes with its Undo.
    if (t.ids) { chipTimer = setTimeout(shrinkToast, 8000); toastTimer = setTimeout(hideToast, 120000); }
    else toastTimer = setTimeout(hideToast, 8000);
  }
  function shrinkToast() {
    if (bar.hidden) return;
    // Not while it's being used (a finger or the keyboard on Undo or Calendar).
    if (bar.contains(document.activeElement) || bar.matches(':hover')) { chipTimer = setTimeout(shrinkToast, 3000); return; }
    bar.classList.add('is-chip');
    document.body.style.setProperty('--vol-toast-h', bar.offsetHeight + 'px');
  }
  function hideToast() { clearTimeout(chipTimer); bar.hidden = true; bar.classList.remove('is-chip'); state.toast = null; state.wkNote = null; document.body.classList.remove('has-toast'); }
  bar.addEventListener('click', e => {
    const b = e.target.closest('button');
    if (!b) return;
    const t = state.toast || {};
    if (b.hasAttribute('data-dismiss')) return hideToast();
    if (b.hasAttribute('data-undo')) return t.left ? unleave(t.ids) : undo(t.ids, t);
    if (b.hasAttribute('data-retry') && t.retry) { hideToast(); return t.retry(); }
  });

  /* ---------------------------------------------------------------- calendar file */

  // The calendar file is the server's, at a real address (after the eighth critic, Oct 16: the page made
  // it in the browser, which a phone keeps as a download; iOS Safari offers "Add to Calendar" only for a
  // file a site serves): GET vol/{y}/ics, one event a shift naming everyone of yours on it, the same UID
  // and alarm as every email's file (the server's ogc_vol_ics), so importing both never makes two. Signed
  // in, the page's nonce lets the server know who asks (WordPress's own way for a link); a visitor's own
  // places are this device's. Nothing personal is in the address.
  function icsHref(ids) {
    const n = signed() ? (W.nonce || live().nonce || '') : '';
    return (W.rest || '/wp-json/ogc/v1/') + 'vol/' + encodeURIComponent(state.year) + '/ics?s=' + encodeURIComponent(uniq(ids).join(',')) + (n ? '&_wpnonce=' + encodeURIComponent(n) : '');
  }

  /* ---------------------------------------------------------------- the address */

  function setUrl(o, replace) {
    const u = new URL(location.href);
    ['committee', 'shift', 'view', 'swap', 't', 'day', 'job'].forEach(k => { if (k in o) { if (o[k]) u.searchParams.set(k, o[k]); else u.searchParams.delete(k); } });
    if (u.href !== location.href) history[replace ? 'replaceState' : 'pushState'](null, '', u);
  }
  window.addEventListener('popstate', () => {
    const p = new URLSearchParams(location.search);
    state.committee = p.get('committee') || (p.get('view') === 'all' ? '*' : '');
    if (p.get('day') && state.committee) state.day[state.committee] = p.get('day');
    state.open = '';
    const id = p.get('shift');
    if (id && find(id)) { state.committee = state.committee || find(id).committee; state.open = id; }
    render();
  });
  function pickCommittee(c, day) {
    state.committee = c; state.open = ''; state.add = null; state.pick = [];
    if (day != null) state.day[c] = day;
    setUrl(c === '*' ? { committee: '', view: 'all', shift: '', day: day || '', job: '' } : { committee: c, view: '', shift: '', day: '', job: '' });
    render();
    window.scrollTo({ top: 0 });
    const h = root.querySelector('.vo-title');
    if (h) h.focus({ preventScroll: true });
    say.textContent = c === '*' ? 'All shifts' : c || 'Committees';
  }
  // A shift from Your week, an email or an Invite link: its committee, with its row open.
  function goShift(id) {
    const sh = find(id);
    if (!sh) return;
    if (wsheet.open) wsheet.close();
    if (state.committee !== '*' && state.committee !== sh.committee) { state.committee = sh.committee; setUrl({ committee: sh.committee, view: '' }); }
    const c = state.committee;
    if (state.day[c] && state.day[c] !== eve(sh).key) state.day[c] = '';
    if (isFull(sh) && !minesOn(sh).length) state.hideFull = false;
    state.open = '';
    openRow(id);
  }

  // Counts kept true while the page is open: on coming back to it. Only the numbers change; what's
  // being typed stays.
  async function refresh() {
    if (!state.model) return;
    try {
      await loadLive();
      const a = document.activeElement;
      if (a && a.matches && a.matches('input, textarea') && root.contains(a)) return;
      const y = scrollY;
      redraw();
      scrollTo(0, y);
    } catch (e) { /* the page stands as it was */ }
  }
  document.addEventListener('visibilitychange', () => { if (!document.hidden) refresh(); });

  /* ---------------------------------------------------------------- events */

  async function onClick(e) {
    const a = e.target.closest('[data-go]');
    if (a && !e.metaKey && !e.ctrlKey) { e.preventDefault(); pickCommittee(a.dataset.go); return; }
    const gd = e.target.closest('[data-goday]');
    if (gd && !e.metaKey && !e.ctrlKey) { e.preventDefault(); pickCommittee('*', gd.dataset.goday); return; }
    const b = e.target.closest('button');
    if (!b) return;
    const ds = b.dataset;
    if (emailClick(b)) return;
    if ('lv' in ds) { const f = b.closest('[data-lv-for]'); if (f) lvAct(ds.lv, f.dataset.lvFor); return; }
    if ('open' in ds) openRow(ds.open);
    else if ('pick' in ds) { if (b.getAttribute('aria-disabled') !== 'true') pick(ds.pick); }
    else if ('addopen' in ds) {
      const sh = find(state.open);
      if (sh && pickN(sh) >= open(sh)) { say.textContent = 'Only ' + open(sh) + ' open'; }
      // The last name starts as yours; with no household to pick from, the one added most often shares
      // your email (a husband, a wife, a child): "Uses my email" starts ticked. Untick for their own.
      // The last name starts as the last person added's (the Yoders after the first Yoder; after the fifth
      // critic, Oct 15), else yours.
      state.add = { last: lastOf(state.lastAdded || selfName() || [state.me1.first, state.me1.last].filter(Boolean).join(' ')), same: canShare() && !hh().length };
      redraw('[data-f="add"][name="first"]');
    }
    else if ('shownow' in ds) setMe({ show: true, name: ds.shownow });
    else if ('showall' in ds) { let ns = []; try { ns = JSON.parse(ds.showall); } catch (x) { /* none */ } if (ns.length) setMe({ show: true, names: ns }); }
    else if ('phonechg' in ds) { state.phoneEdit = true; state.me1 = Object.assign(state.me1 || {}, { phone: (me() && me().phone) || '' }); redraw('[data-f="me1"][name="phone"]'); }
    else if ('addcancel' in ds) { state.add = null; state.footErr = ''; ['add.first', 'add.last', 'add.email', 'add.band'].forEach(k => delete state.err[k]); redraw('[data-addopen]'); }
    // × on a name in the list: off this sign-up (someone typed only here is gone).
    else if ('unadd' in ds) { const k = ds.unadd, p = circle().find(x => x.k === k); state.pick = state.pick.filter(x => x !== k); state.added = state.added.filter(x => x.k !== k); redraw('[data-f="add"][name="first"]'); syncFoot(false); drawWeek(); say.textContent = (p ? first(p.name) : 'Name') + ' removed'; }
    else if ('addmore' in ds) { state.addMore = ds.addmore; state.pick = []; state.add = null; state.err = {}; state.footErr = ''; state.ans = {}; state.also = []; redraw(); const x = root.querySelector('.vo-panel [data-pick]:not([aria-disabled="true"]), .vo-panel [data-addopen]'); if (x) x.focus({ preventScroll: true }); }
    else if ('addsave' in ds) addSave();
    else if ('autofill' in ds) autofill();
    else if ('signup' in ds) signUp(find(ds.signup));
    else if ('close' in ds) closeRow();
    else if ('day' in ds) { state.day[state.committee] = ds.day; kept.set('day-' + state.year + '-' + state.committee, ds.day); setUrl({ day: '' }, true); redraw('[data-day="' + CSS.escape(ds.day) + '"]'); say.textContent = b.title || b.textContent; }
    else if ('also' in ds) { if (b.getAttribute('aria-disabled') !== 'true') { const i = state.also.indexOf(ds.also); if (i > -1) state.also.splice(i, 1); else state.also.push(ds.also); redraw('[data-also="' + CSS.escape(ds.also) + '"]'); drawWeek(); } }
    else if ('ownalso' in ds) { if (b.getAttribute('aria-disabled') !== 'true') { state.ownAlso = state.ownAlso || []; const i = state.ownAlso.indexOf(ds.ownalso); if (i > -1) state.ownAlso.splice(i, 1); else state.ownAlso.push(ds.ownalso); state.footErr = ''; redraw('[data-ownalso="' + CSS.escape(ds.ownalso) + '"]'); drawWeek(); } }
    else if ('ownalsogo' in ds) ownAlsoJoin(find(ds.ownalsogo));
    else if ('job' in ds) { state.job[state.committee] = ds.job; setUrl({ job: ds.job }, true); redraw('[data-job="' + CSS.escape(ds.job) + '"]'); say.textContent = ds.job || 'All jobs'; }
    else if ('hidefull' in ds) { state.hideFull = !state.hideFull; redraw('[data-hidefull]'); }
    else if ('wk' in ds) { state.wk = ds.wk; drawWeek(); const x = document.querySelector((wsheet.open ? '.vo-wsheet' : '.vo-side') + ' [data-wk="' + CSS.escape(ds.wk) + '"]'); if (x) x.focus(); }
    else if ('goto' in ds) goShift(ds.goto);
    else if ('leave' in ds) { state.leaving = ds.leave; state.leaveWho = null; state.footErr = ''; redraw('[data-lv-for="row:' + CSS.escape(ds.leave) + '"] [data-lv="go"]'); }
    else if ('swapoff' in ds) swap(+ds.swapoff, false, find(state.open));
    else if ('swapcopy' in ds) { const sh = find(state.open); if (sh) copyLink(swapUrl(sh, ds.swapcopy), 'Link copied', 'Could you take my place? ' + sh.role + ', ' + whenShort(sh)); }
    else if ('wkleave' in ds) { state.wkLeave = +ds.wkleave; drawWeek(); const x = document.querySelector((wsheet.open ? '.vo-wsheet' : '.vo-side') + ' [data-lv-for="wk:' + ds.wkleave + '"] [data-lv="go"]'); if (x) x.focus(); }
    else if ('wkundo' in ds) { const t = state.wkNote; if (t && t.ids) { if (t.left) unleave(t.ids); else undo(t.ids, t); } }
    else if ('waitgo' in ds) waitFor(find(ds.waitgo));
    else if ('unwait' in ds) { try { merge(await post('vol/' + state.year + '/unwait', { ids: [+ds.unwait] })); render(); say.textContent = 'Off the waitlist'; } catch (x) { showToast({ kind: 'error', text: 'Not saved' }); } }
    else if ('take' in ds) take(find(ds.take));
    else if ('invite' in ds) invite(ds.invite);
    else if ('map' in ds) { state.mapOpen = state.mapOpen === ds.map ? '' : ds.map; redraw('[data-map="' + CSS.escape(ds.map) + '"]'); }
    else if ('typo' in ds) { const bag = ds.typo, v = state[bag] || {}; v.email = typoFix(v.email) || v.email; delete state.err[bag + '.email']; if (bag === 'add') addSave(); else redraw('[data-f="' + bag + '"][name="email"]'); }
    else if ('typokeep' in ds) { const bag = ds.typokeep, v = state[bag] || {}; state.typoOk = bag + ':' + String(v.email || '').trim(); delete state.err[bag + '.email']; if (bag === 'add') addSave(); else redraw(); }
    else if ('signout' in ds) { tab.del('hold-' + state.year); tab.del('typed'); forget1(); SU.signOut(); }
    else if ('forget' in ds) forgetMe();
    else if ('linkswapcopy' in ds) { const r = linkRecs(state.link).find(x => x.rid === state.link.swapRid) || linkRecs(state.link)[0], sh = r && find(r.shift); if (sh) copyLink(swapUrl(sh, state.link.swap), 'Link copied', 'Could you take my place? ' + sh.role + ', ' + whenShort(sh)); }
    else if ('linkdone' in ds) { state.link = null; state.footErr = ''; render(); say.textContent = 'Done'; }
    else if ('linkothers' in ds) { state.link.others = true; state.footErr = ''; redraw('[data-lv="go"]'); }
    else if ('linkjoin' in ds) linkJoin();
    else if ('agtog' in ds) { const g = AG(); g.off[ds.agtog] = !g.off[ds.agtog]; if (!g.off[ds.agtog]) g.offp[ds.agtog] = []; delete g.err[ds.agtog + ':ask']; g.foot = ''; redraw('[data-agtog="' + CSS.escape(ds.agtog) + '"]'); }
    else if ('agp' in ds) { const g = AG(), l = g.offp[ds.agp] = g.offp[ds.agp] || [], i = l.indexOf(ds.n); if (i > -1) l.splice(i, 1); else l.push(ds.n); const r = agRows().find(x => x.sh && x.sh.id === ds.agp); if (r && !r.chosen.length) { g.off[ds.agp] = true; g.offp[ds.agp] = []; } g.foot = ''; redraw('[data-agp="' + CSS.escape(ds.agp) + '"][data-n="' + CSS.escape(ds.n) + '"]'); }
    else if ('agjoin' in ds) agJoin();
    else if ('youngall' in ds) { state.youngAll = ds.youngall; redraw(); const l = root.querySelectorAll('.vo-young__go'); if (l[4]) l[4].focus({ preventScroll: true }); }
    else if ('agwait' in ds) agWait(ds.agwait);
    else if ('agfold' in ds) { kept.set('agfold-' + state.year, true); redraw('[data-agshow]'); say.textContent = 'Hidden'; }
    else if ('agshow' in ds) { kept.set('agfold-' + state.year, false); redraw('[data-agjoin], [data-agfold]'); }
    else if ('linkunwait' in ds) linkUnwait();
  }
  function emailClick(b) {
    const ds = b.dataset;
    if (ds.resend) { resend(ds.resend.split(' ')); return true; }
    if (ds.chemail) { state.emailEdit = ds.chemail; state.emailVal = null; state.emailErr = ''; state.emailFix = ''; redrawEmail(); return true; }
    if (b.hasAttribute('data-emailoff')) { state.emailEdit = ''; render(); return true; }
    if (b.hasAttribute('data-emailfix')) { const f = b.closest('form'); f.email.value = state.emailVal.split('@')[0] + '@' + domainOf(state.emailFix); changeEmail(f, true); return true; }
    if (b.hasAttribute('data-emailkeep')) { changeEmail(b.closest('form'), true); return true; }
    return false;
  }
  function onChange(e) {
    const t = e.target;
    if (t.matches('[data-f="add"][name="first"], [data-f="me1"][name="first"]')) { syncFoot(false); return; }
    if (t.matches('[data-agans]')) { agAns(t); return; }
    if (t.matches('[name=rule]')) { state.ans.rule = t.checked; delete state.err.rule; redraw('[name=rule]'); }
    else if (t.matches('[name=question]')) { state.ans.question = t.value; delete state.err.rule; redraw(); }
    else if (t.matches('[name=screened]')) { state.ans.screened = t.value; delete state.err.screened; redraw(); }
    else if (t.matches('[name=lvshift], [name=lvwho]')) {
      const f = t.closest('[data-lv-for]'), sc = f ? f.dataset.lvFor : '', on = Array.from(f.querySelectorAll('[name=' + t.name + ']:checked')).map(x => x.value);
      const keep = '[data-lv-for="' + CSS.escape(sc) + '"] [name=' + t.name + '][value="' + CSS.escape(t.value) + '"]';
      if (sc === 'link' && state.link) { const k = state.link; linkPick(k); k[t.name === 'lvshift' ? 'ps' : 'pp'] = on; state.footErr = ''; state.linkErr = false; redraw(keep); }
      else if (/^row:/.test(sc)) { state.leaveWho = on.map(Number); state.footErr = ''; redraw(keep); }
    }
    else if (t.matches('[data-showname]')) setMe(t.dataset.showname ? { show: t.checked, name: t.dataset.showname } : { show: t.checked });
    else if (t.matches('[data-nextyear]')) setMe({ next_year: t.checked });
    else if (t.matches('[data-samemail]')) { state.add = Object.assign(state.add || {}, { same: t.checked }); delete state.err['add.email']; redraw('[data-samemail]'); }
    else if (t.matches('[data-forother]')) {
      // Ticked: the box above becomes "Their contact" and the list of names opens right under it (after
      // the sixth critic, Oct 15: it jumped into Add someone). Focus stays. The first name's last name is
      // blank, never the contact's (after the ninth critic, Oct 16); the person added before's, after one.
      state.me1 = Object.assign(state.me1 || {}, { off: t.checked });
      ['me1.band', 'rule'].forEach(k => delete state.err[k]); state.footErr = '';
      if (t.checked) { if (!state.add || !String(state.add.first || '').trim()) state.add = { last: lastOf(state.lastAdded || ''), same: true, band: (state.add && state.add.band) || '' }; }
      else if (state.add && !String(state.add.first || '').trim()) state.add = null;
      redraw('[data-forother]');
      syncFoot(false);
    }
    // An age (Under 18 · 18–20 · 21 or older): yours the first time, the one being added, or a ticked
    // person's (kept for this visit, and with them once they're signed up).
    else if (t.matches('[data-band]')) {
      const k = t.dataset.band, v = t.value;
      if (k === 'me1') { state.me1 = Object.assign(state.me1 || {}, { band: v }); delete state.err['me1.band']; }
      else if (k === 'add') { state.add = Object.assign(state.add || {}, { band: v }); delete state.err['add.band']; }
      else if (/^k:/.test(k)) { state.bands[k.slice(2)] = v; delete state.err['band.' + k.slice(2)]; if (state.ag) Object.keys(state.ag.err).forEach(x => { if (x === 'age:' || ('n:' + low(x.slice(4))) === k.slice(2)) delete state.ag.err[x]; }); }
      state.footErr = '';
      redraw('[data-band="' + CSS.escape(k) + '"][value="' + CSS.escape(v) + '"]');
      // Someone it keeps off the shift goes from those ticked (their pill says the rule's words).
      drawWeek();
    }
    else if (t.matches('[data-cert]')) { state.ans.q = Object.assign({}, state.ans.q, { [t.dataset.cert]: t.value }); delete state.err['q.' + t.dataset.cert]; state.footErr = ''; redraw('[data-cert="' + CSS.escape(t.dataset.cert) + '"][value="' + CSS.escape(t.value) + '"]'); }
  }
  root.addEventListener('click', onClick);
  root.addEventListener('change', onChange);
  root.addEventListener('input', e => {
    const t = e.target, f = t.dataset && t.dataset.f;
    if (!f) return;
    state[f] = state[f] || {};
    state[f][t.name] = t.value;
    // An error goes as soon as the field is changed; the rule's claim follows the first name.
    if (state.err[f + '.' + t.name]) { delete state.err[f + '.' + t.name]; const box = t.closest('.vo-in'); if (box) { box.classList.remove('is-bad'); t.removeAttribute('aria-invalid'); const sm = box.querySelector('small:not(.is-help)'); if (sm) sm.remove(); } }
    // Someone being typed into Add someone is counted at once ("Sign up · 2 people"); the names once typed.
    if (f === 'add' || (f === 'me1' && t.name === 'first')) syncFoot(true);
  });
  root.addEventListener('toggle', e => { if (e.target.matches && e.target.matches('[data-notefld]')) state.ans.noteOpen = e.target.open; }, true);
  root.addEventListener('keydown', e => {
    if (e.key === 'Enter' && e.target.matches && e.target.matches('[data-f="add"], [data-band="add"]')) { e.preventDefault(); addSave(); }
    else if (e.key === 'Enter' && e.target.matches && e.target.matches('[data-f="me1"], [data-f="ans"]') && state.open) { e.preventDefault(); const sh = find(state.open); if (sh && isFull(sh)) waitFor(sh); else signUp(sh); }
    else if (e.key === 'Escape' && state.open && !wsheet.open) { e.preventDefault(); closeRow(); }
  });
  // On a laptop, the shift under the pointer shows in Your week (dashed), red if it clashes.
  // Only where Your week sits beside the list (the grid's Your week is the bar and its sheet, which never
  // draws a hover); the pointer leaving the page clears it (after the sixth critic, Oct 15).
  root.addEventListener('mouseover', e => {
    if (state.open) return;
    const r = e.target.closest('[data-row]'), id = r && root.querySelector('.vo-side') ? r.dataset.row : '';
    if (id !== state.hover && matchMedia('(min-width: 1100px)').matches) { state.hover = id; drawWeek(); }
  });
  root.addEventListener('mouseleave', () => { if (state.hover) { state.hover = ''; drawWeek(); } });
  root.addEventListener('submit', async e => {
    e.preventDefault();
    const f = e.target;
    if (f.matches('[data-emailform]')) changeEmail(f);
    else if (f.matches('[data-phoneform]')) {
      const v = f.phone.value.trim();
      if (v.replace(/\D/g, '').length < 7) { state.err.cphone = 'A phone number'; render(); const x = root.querySelector('[data-phoneform] input'); if (x) x.focus(); return; }
      try { merge(await post('vol/' + state.year + '/me', { phone: v })); delete state.err.cphone; if (live().me) live().me.phone = v; state.link.phoneSaved = true; render(); say.textContent = 'Phone saved'; }
      catch (x) { state.err.cphone = 'Not saved · Retry'; render(); }
    } else if (f.matches('[data-notify]')) {
      const em = f.email ? f.email.value.trim() : '';
      const err = f.querySelector('.vol-err');
      if (f.email && !emailOk(em)) { err.hidden = false; err.textContent = 'Enter your email'; f.email.setAttribute('aria-invalid', 'true'); f.email.focus(); return; }
      const ny = f.dataset.notify || state.year;
      try { await post('vol/' + ny + '/notify', { email: em, hp: f.hp.value }); kept.set('asked-' + ny, true); render(); say.textContent = 'We’ll email you'; } catch (x) { if (err) { err.hidden = false; err.textContent = 'Not saved · Retry'; } }
    }
  });

  async function setMe(o) {
    try {
      merge(await post('vol/' + state.year + '/me', o));
      if (state.live.me && !o.name && !o.names) Object.assign(state.live.me, o);
      // The Confirmed card's Show says what it did ("Glen’s name shows"), not only to a screen reader.
      if ((o.name || o.names) && o.show) state.shownNow = uniq((state.shownNow || []).concat(o.names || [o.name]));
      redraw(); say.textContent = o.show != null ? (o.show ? (o.names ? 'Names show · ' + listAnd(o.names.map(first)) : o.name ? first(o.name) + '’s name shows' : 'Name shown') : 'Name hidden') : o.next_year ? 'We’ll email you next year' : 'Off';
    }
    catch (x) { showToast({ kind: 'error', text: 'Not saved' }); }
  }

  // Emailed links.
  // Only those chosen leave; the link's records are asked again after, so the card says who's still on.
  async function linkLeave() {
    const k = state.link, go = linkPick(k);
    if (!go.length || state.busyAct) return;
    const ids = go.map(r => r.rid), groups = byShift(go);
    state.busyAct = 'linkleave'; state.footErr = ''; state.linkErr = false; redraw('[data-lv-for="link"] [data-lv="go"]');
    try {
      const d = await post('vol/' + state.year + '/leave', Object.assign({ ids }, k.via));
      state.busyAct = '';
      merge(d);
      const left = (d.left || []).map(Number);
      if (!left.length) throw Object.assign(new Error('none'), { data: {} });
      const gone = groups.map(g => ({ sh: g.sh, ms: g.ms.filter(m => left.indexOf(m.rid) > -1) })).filter(g => g.ms.length);
      const lines = gone.map(g => g.sh.role + ' · ' + dayShort(g.sh) + ' · ' + listAnd(uniq(g.ms.map(m => first(m.name)))));
      await relink();
      state.link.left = { lines, shifts: gone.map(g => g.sh.id), ids: left };
      await refresh(); render();
      showToast({ kind: 'ok', text: 'Left shift', lines, ids: left, left: true });
      say.textContent = 'Left shift · ' + lines.join('; ');
    } catch (x) {
      state.busyAct = ''; state.linkErr = true;
      state.footErr = x.data && x.data.why === 'started' ? 'Started · Call the foreman' : 'Not saved · Retry';
      redraw();
    }
  }
  // The link's records again (who of this email is still on its shifts), keeping the link's own state.
  async function relink() {
    const k = state.link;
    try { const d = await post('vol/' + state.year + '/link', k.via); state.link = Object.assign({ via: k.via }, d); } catch (e) { /* the card keeps what it had */ }
  }
  async function linkSwap(rid) {
    const k = state.link, r = linkRecs(k).find(x => x.rid === rid) || linkPick(k)[0];
    if (!r) return;
    try { const d = await post('vol/' + state.year + '/swap', Object.assign({ id: r.rid, on: true }, k.via)); k.swap = d.swap; k.swapRid = r.rid; render(); const sh = find(r.shift); if (sh && d.swap) copyLink(swapUrl(sh, d.swap), 'Link copied', 'Could you take my place? ' + sh.role + ', ' + whenShort(sh)); }
    catch (x) { showToast({ kind: 'error', text: 'Not saved · Retry' }); }
  }
  async function linkJoin() {
    const k = state.link, shs = (k.shifts || []).map(find).filter(Boolean);
    if (!shs.length) return;
    // A rule to answer, or no names: the shift's own row, open. The same when the link names more people
    // than a shift has open now (one "Place open" email names everyone of the address who waits, and a
    // join is all or nothing for a shift): the row lists them, to choose who takes the place.
    const few = shs.find(sh => !sh.unlimited && open(sh) < (k.names || []).length);
    if (shs.some(sh => sh.rule || screening(sh)) || !(k.names || []).length || few) { goShift((few || shs[0]).id); return; }
    try {
      const d = await post('vol/' + state.year + '/join', Object.assign({ shifts: shs.map(s => s.id), people: k.names, show: true }, k.via));
      merge(d); const ok = d.results.filter(r => r.status === 'ok').length; k.done = true; render();
      const r = d.results.find(x => x.status !== 'ok');
      showToast({ kind: ok ? 'ok' : 'no', text: ok ? 'Signed up · ' + plural(ok, 'shift') : r && r.status === 'full' ? 'Taken · Still on waitlist' : refusal(r || {}, shs[0]).msg });
    } catch (x) { showToast({ kind: 'error', text: 'Not saved', retry: linkJoin }); }
  }
  async function linkUnwait() {
    try { const d = await post('vol/' + state.year + '/link', Object.assign({ do: 'unwait' }, state.link.via)); state.link = Object.assign(state.link, d); await refresh(); render(); }
    catch (x) { showToast({ kind: 'error', text: 'Not saved · Retry' }); }
  }

  let resizeT = 0;
  window.addEventListener('resize', () => { clearTimeout(resizeT); resizeT = setTimeout(() => { fitCal(); if (document.body.classList.contains('vo-gridmode')) fitGrid(); }, 150); });
  // Across 1100 px the committee's page changes between the list and the week grid: drawn again, an
  // opened shift kept open.
  WIDE.addEventListener('change', () => { if (!state.model || !state.committee || state.committee === '*') return; redraw(); if (state.open) { const b = document.getElementById('vo-band') || document.getElementById('vo-r-' + state.open); if (b) b.scrollIntoView({ block: 'nearest' }); } });

  /* ---------------------------------------------------------------- boot */

  (O.ready || Promise.resolve()).then(() => fetch(BASE + 'years.csv', { cache: 'no-store' })).then(r => r.text()).then(async text => {
    const years = O.csvToObjects(text).filter(y => y.year).sort((a, b) => b.year - a.year);
    state.years = years;
    state.row = years.find(y => y.year === String(state.year)) || years.find(y => y.data) || years[0];
    state.year = state.row.year;
    if (!state.row.data) {
      // A year with no shifts yet (2028): its own name and hosts, Not posted yet.
      state.model = { settings: {}, days: [], tz: 'America/Indiana/Indianapolis' };
      try { await loadLive(); } catch (e) { state.live = null; }
      state.shifts = [];
      return render();
    }
    const folder = BASE + state.row.data + '/';
    state.model = await O.loadSchedule(folder);
    const shiftsText = await fetch(folder + 'shifts.csv', { cache: 'no-store' }).then(r => r.ok ? r.text() : '');
    state.shifts = SU.expandShifts(O.csvToObjects(shiftsText), state.model, { allweek: true, lastDate: state.row.end });
    // ?day= (the home page's day links, a shared address): that day's chip, chosen.
    const qd = q.get('day');
    if (qd) state.day[state.committee || '*'] = qd === 'week' ? 'week' : ((state.model.days.find(d => d.key === qd || d.date === qd) || {}).key || '');
    if (O.map) {
      // (The year's floor-plan index alongside, a few KB: a shift's small map knows at once whether it
      // gets the door-to-room picture, docs/34 §6.1; a floor comes only when a Map is opened.)
      if (O.map.floors && O.map.floors.load) O.map.floors.load(state.year);
      const campusText = await fetch(folder + 'campus.csv', { cache: 'no-store' }).then(r => r.ok ? r.text() : '').catch(() => '');
      const c = O.map.campus(O.csvToObjects(campusText));
      state.campus = c.items.length ? c : null;
    }
    // An emailed link: the server put its token in a short cookie and opened this clean address
    // (?link=1), so the token is never in the address bar. What it is, answered before the page is
    // drawn; then ?link (or an old ?t=) leaves the address at once.
    const t = q.get('t'), via = t ? { t } : q.get('link') ? { link: 1 } : null;
    if (via) {
      try { state.link = Object.assign({ via }, await call('POST', 'vol/' + state.year + '/link', via).catch(async e => { if (e.status === 403) { await loadLive(); return post('vol/' + state.year + '/link', via); } throw e; })); } catch (e) { state.link = { error: true }; }
      const u = new URL(location.href); u.searchParams.delete('t'); u.searchParams.delete('link'); history.replaceState(null, '', u);
    }
    // Said once: the address loses ?confirmed= (a reload never repeats "2 shifts").
    if (q.get('confirmed') != null) {
      state.link = { a: 'confirm', n: +q.get('confirmed') };
      const u = new URL(location.href); u.searchParams.delete('confirmed'); history.replaceState(null, '', u);
    }
    await loadLive();
    // A first-timer's kept details go once they sign in or this device sees their places confirmed.
    { const k1 = kept1(); if (k1 && (signed() || mine().some(m => !m.added && m.confirmed && low(m.email) === low(k1.email)))) forget1(); }
    // A Confirm link's page (?confirmed=): what's true of that link's places now, from the server (who of
    // it is still on, who left since; after the fourth critic, Oct 15).
    if (state.link && state.link.a === 'confirm' && !state.link.groups && signed()) {
      try { const f = await post('vol/' + state.year + '/link', { cf: 1 }); if (f && f.follow) Object.assign(state.link, f); } catch (e) { /* the card says what it has */ }
    }
    const id = q.get('shift');
    if (id && find(id)) {
      const sh = find(id);
      if (!state.committee || (state.committee !== '*' && state.committee !== sh.committee)) state.committee = sh.committee;
      if (isFull(sh) && !minesOn(sh).length) state.hideFull = false;
      state.day[state.committee] = '';
      render();
      openRow(id, { keep: true, focus: false });
      return;
    }
    render();
    // ?place=CODE: the place dialog's own address (shared/ogc-map-dialog.js), over the page.
    if (q.get('place') && O.map && O.map.placeDialog && O.map.placeDialog.arrive) O.map.placeDialog.arrive();
  }).catch(err => {
    console.error(err);
    root.removeAttribute('aria-busy');
    const m = root.querySelector('.wk-main .wk-wrap') || root;
    m.innerHTML = '<section class="vol-blank"><h2 class="vol-blank__h">Couldn’t load</h2><p><button type="button" class="wk-btn wk-btn--line wk-btn--small" onclick="location.reload()">Retry</button></p></section>';
  });
})();
