/*
 * volunteer.js — volunteering at the Annual Conference, on our own site (replacing SignUpGenius).
 * Anyone, any time; it isn't part of registering. Every count, name and "you" comes from GET vol/{year}
 * (never cached), and every Sign up waits for the server's answer: "Signed up" is shown only when true.
 *
 * Oct 13 (Michael; concepts/signup/one): "the biggest thing that's busy about the helping out thing is
 * how they are all just right there boom in your face." So:
 *   (default)       the committees as calm cards (icon, name, jobs, days, how many open)
 *   ?committee=…    one committee's shifts, a clean list by day: day chips, Hide full (on)
 *   ?view=all       every committee's shifts the same way (a quiet link under the cards)
 *   ?shift=…        that shift's committee, with its row open (emails, Invite, Find replacement)
 *   ?link=1         an emailed link (confirm, not me, leave, a place opened, your 2026 shifts): the
 *                   server moved its opaque token into a short cookie, so the address never carries it
 *   ?swap=…         a place offered for a swap (Take place, in the row)
 * Sign up opens the row in place and asks "Who's helping?": the signed-in person by their own name,
 * their household (or the people they've signed up before), and Add someone (a name and an email:
 * that person confirms by email, and shows "Waiting to confirm" until they do). Your week is beside the
 * list on a laptop (services faint, your shifts in tan, the one being looked at dashed), and a bar that
 * opens as a sheet on a phone. Mechanical (docs/25): nothing here looks anyone up by name.
 * The heads' list is the app's Helpers screen (?view=lead redirects there).
 */
(function () {
  'use strict';
  const O = window.OGC, esc = O.esc, SU = O.signups, W = window.OGC_WP || {};
  const root = document.getElementById('ogc-vol');
  if (!root) return;
  const BASE = root.dataset.base;
  const q = new URLSearchParams(location.search);

  // Your sign-ups holds "my" shifts with everything else.
  if (q.get('view') === 'mine') { location.replace((W.base || '/annual-conference/') + 'register/?view=mine' + (q.get('year') ? '&year=' + encodeURIComponent(q.get('year')) : '')); return; }

  const svg = d => '<svg class="wk-i" viewBox="0 0 24 24" aria-hidden="true"><path d="' + d + '" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  const I = {
    cal: svg('M7.5 3.5v3M16.5 3.5v3M4 9.5h16M5.5 5.5h13A1.5 1.5 0 0 1 20 7v11.5a1.5 1.5 0 0 1-1.5 1.5h-13A1.5 1.5 0 0 1 4 18.5V7a1.5 1.5 0 0 1 1.5-1.5Z'),
    pin: svg('M12 20.5s-6.5-5.4-6.5-10.8a6.5 6.5 0 0 1 13 0c0 5.4-6.5 10.8-6.5 10.8ZM12 12a2.3 2.3 0 1 0 0-4.6 2.3 2.3 0 0 0 0 4.6Z'),
    check: svg('m5.5 12.5 4 4 9-9'),
    close: svg('m6.5 6.5 11 11M17.5 6.5l-11 11'),
    mail: svg('M4 6.5h16v11H4zM4.5 7l7.5 6 7.5-6'),
    back: svg('M14.5 5.5 8 12l6.5 6.5'),
    up: svg('m6 14.5 6-6 6 6'),
    link: svg('M10 14a4 4 0 0 0 5.66 0l3-3a4 4 0 0 0-5.66-5.66l-1 1M14 10a4 4 0 0 0-5.66 0l-3 3a4 4 0 0 0 5.66 5.66l1-1'),
    phone: svg('M6.5 3.5h3l1.5 4-2 1.5a11 11 0 0 0 6 6l1.5-2 4 1.5v3a2 2 0 0 1-2 2A16 16 0 0 1 4.5 5.5a2 2 0 0 1 2-2Z'),
    plus: svg('M12 5v14M5 12h14'),
    clock: svg('M12 20.5a8.5 8.5 0 1 0 0-17 8.5 8.5 0 0 0 0 17ZM12 7.5V12l3 2'),
    alert: svg('M12 7.5v5.5M12 16.5v.01M12 20.5a8.5 8.5 0 1 0 0-17 8.5 8.5 0 0 0 0 17Z')
  };
  // Each committee's own sign, by its name (any the COA adds gets the raised hand).
  const HAND = 'M8 11V5.5a1.5 1.5 0 0 1 3 0V11M11 10V4.5a1.5 1.5 0 0 1 3 0V11M14 10.5V6a1.5 1.5 0 0 1 3 0v7.5a6 6 0 0 1-6 6h-.6a6 6 0 0 1-4.6-2.2L3.6 14.6a1.5 1.5 0 0 1 2.2-2L8 14.5V11';
  const MARKS = [
    [/transport|golf|cart|parking/i, 'M6 5.5h11M7 5.5v6M16 5.5v6M4.5 11.5h15v4h-15zM7.5 19a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3ZM16.5 19a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3Z'],
    [/dining|food|kitchen|meal/i, 'M7.5 3.5v6.5M5.5 3.5V8a2 2 0 0 0 4 0V3.5M7.5 10v10.5M16.5 20.5v-17c-2 1.2-3 3.6-3 7v3h3'],
    [/usher/i, 'M6.5 20.5v-16h11v16M4 20.5h16M14.5 12.5v.01'],
    [/first aid|medical|nurse/i, 'M12 8.5v7M8.5 12h7M6 4.5h12A1.5 1.5 0 0 1 19.5 6v12a1.5 1.5 0 0 1-1.5 1.5H6A1.5 1.5 0 0 1 4.5 18V6A1.5 1.5 0 0 1 6 4.5Z'],
    [/preteen|child|nursery/i, 'M8 7.5a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5ZM4 20.5v-6.5a4 4 0 0 1 8 0v6.5M17 11.5a2 2 0 1 0 0-4 2 2 0 0 0 0 4ZM14.5 20.5v-4.5a2.5 2.5 0 0 1 5 0v4.5'],
    [/young folk/i, 'M9 11a3.4 3.4 0 1 0 0-6.8A3.4 3.4 0 0 0 9 11ZM3 19.5c.6-3.3 3-5.2 6-5.2s5.4 1.9 6 5.2M15.8 4.5a3.2 3.2 0 0 1 0 6.2M17.6 14.6c1.8.7 3 2.3 3.4 4.9'],
    [/communion/i, 'M7.5 3.5h9l-.8 5.5a3.7 3.7 0 0 1-7.4 0L7.5 3.5ZM12 12.8v6.2M8.5 20h7'],
    [/kit|pack/i, 'M3.5 7.5 12 3.5l8.5 4v9L12 20.5l-8.5-4zM3.5 7.5l8.5 4 8.5-4M12 11.5v9'],
    [/lodging|desk|registration/i, 'M8 11.5a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7ZM10.5 10.5l9 9M16.5 16.5l2-2M14 14l1.5-1.5']
  ];
  const mark = c => svg((MARKS.find(m => m[0].test(c)) || [0, HAND])[1]);
  const ci = c => '<span class="vo-ci" aria-hidden="true">' + mark(c) + '</span>';

  const state = {
    year: root.dataset.year || q.get('year') || '', row: null, model: null, shifts: [], live: null, campus: null, years: [],
    committee: q.get('committee') || (q.get('view') === 'all' ? '*' : ''),
    day: {}, hideFull: true, open: '', pick: [], added: [], add: null, me1: {}, ans: {}, err: {}, footErr: '',
    busyAct: '', leaving: '', wk: '', hover: '', flash: '', link: null, swap: q.get('swap') || '', mapOpen: '',
    emailEdit: '', emailVal: null, emailErr: '', emailFix: '', typoOk: ''
  };
  const say = document.createElement('p');
  say.className = 'ogc-sr';
  say.setAttribute('aria-live', 'polite');
  root.after(say);

  /* ---------------------------------------------------------------- per-viewer conveniences (this browser) */

  const kept = {
    get(k, f) { try { const v = JSON.parse(localStorage.getItem('ogc-vol-' + k)); return v == null ? f : v; } catch (e) { return f; } },
    set(k, v) { try { localStorage.setItem('ogc-vol-' + k, JSON.stringify(v)); } catch (e) { /* not kept */ } }
  };
  // What a visitor typed, and the hold on what they just joined, live only in this tab (sessionStorage):
  // a shared tablet or family computer never fills in, or shows, the last person's name and shifts.
  const tab = {
    get(k, f) { try { const v = JSON.parse(sessionStorage.getItem('ogc-vol-' + k)); return v == null ? f : v; } catch (e) { return f; } },
    set(k, v) { try { sessionStorage.setItem('ogc-vol-' + k, JSON.stringify(v)); } catch (e) { /* not kept */ } },
    del(k) { try { sessionStorage.removeItem('ogc-vol-' + k); } catch (e) { /* nothing kept */ } }
  };
  try { Object.keys(localStorage).filter(k => /^ogc-vol-(typed|hold-|who-)/.test(k)).forEach(k => localStorage.removeItem(k)); } catch (e) { /* nothing kept */ }
  const holds = () => tab.get('hold-' + state.year, []).filter(Boolean).slice(-10);
  const addHold = t => { if (t) tab.set('hold-' + state.year, holds().concat(t).slice(-10)); };
  const typed = () => holds().length ? tab.get('typed', {}) : {};
  let tabPhone = '';
  async function forgetMe() {
    tab.del('hold-' + state.year); tab.del('typed'); tabPhone = '';
    if (!signed()) { try { await post('vol/' + state.year + '/forget', {}); } catch (e) { /* still forgotten here */ } }
    state.me1 = {}; state.added = []; state.pick = []; state.open = '';
    await loadLive().catch(() => {});
    render();
    say.textContent = 'Signed out';
  }

  /* ---------------------------------------------------------------- the server */

  const asOf = () => { const a = O.parseAsOf(q.get('as-of')); return a && W.dev ? Math.round(O.wallToInstant(a.date, a.minutes, tz()).getTime() / 1000) : 0; };
  const tz = () => (state.model && state.model.tz) || 'America/Indiana/Indianapolis';
  async function call(method, path, body) {
    // A visitor's read carries no nonce (a stale one would be refused even for the public counts).
    const h = (W.me || method !== 'GET') && W.nonce ? { 'X-WP-Nonce': W.nonce } : {};
    const hs = holds();
    if (hs.length) h['X-OGC-Hold'] = hs.join(',');
    if (asOf()) h['X-OGC-Now'] = String(asOf());
    if (body !== undefined) h['Content-Type'] = 'application/json';
    const res = await fetch((W.rest || '/wp-json/ogc/v1/') + path, { method, credentials: 'same-origin', headers: h, body: body === undefined ? undefined : JSON.stringify(body) });
    const fresh = res.headers.get('X-WP-Nonce');
    if (fresh) W.nonce = fresh;
    const type = res.headers.get('Content-Type') || '';
    const data = /json/.test(type) ? await res.json().catch(() => null) : await res.text();
    if (!res.ok) {
      const e = new Error((data && data.message) || ('HTTP ' + res.status));
      e.status = res.status; e.data = (data && data.data) || {}; e.code = data && data.code;
      throw e;
    }
    return data;
  }
  // A change: once more with a fresh nonce if the page has been open past a day.
  async function post(path, body) {
    try { return await call('POST', path, body); } catch (e) {
      if (e.status === 403 && (e.data.why === 'nonce' || e.code === 'rest_cookie_invalid_nonce')) { if (e.code && W.me && W.freshNonce) await W.freshNonce(); else { if (e.code) W.nonce = ''; await loadLive(); } return call('POST', path, body); }
      throw e;
    }
  }
  async function loadLive() {
    const d = await call('GET', 'vol/' + state.year);
    state.live = d;
    if (d.nonce) W.nonce = d.nonce;
    return d;
  }
  // Counts that came back with an action replace those shifts' only.
  function merge(d) {
    if (!d || !state.live) return;
    if (d.shifts) Object.keys(d.shifts).forEach(k => { state.live.shifts[k] = d.shifts[k]; });
    if (d.mine) state.live.mine = d.mine;
    if (d.waits) state.live.waits = d.waits;
    if (d.circle) state.live.circle = d.circle;
    if (d.hold) addHold(d.hold);
  }

  /* ---------------------------------------------------------------- the year and its shifts */

  const S = () => state.model.settings;
  const L = sh => (state.live && state.live.shifts[sh.id]) || { f: 0, o: sh.unlimited ? null : sh.needed, w: 0, st: 'not_open', s: [] };
  const find = id => state.shifts.find(s => s.id === id);
  const live = () => state.live || { mine: [], waits: [], committees: [], shifts: {} };
  const me = () => live().me;
  const signed = () => !!(me() && me().signed);
  // An emailed link (a place opened, your shifts again) vouches for the email: no need to type it.
  const vouched = () => !signed() && !!(state.link && /^(opened|again)$/.test(state.link.a || '') && state.link.email);
  const mine = () => live().mine || [];
  const minesOn = sh => mine().filter(m => m.shift === sh.id);
  const waitsOn = sh => (live().waits || []).filter(w => w.shift === sh.id);
  const open = sh => { const o = L(sh).o; return o == null ? Infinity : o; };
  const st = sh => L(sh).st;
  const joinable = sh => st(sh) === 'open';
  // Counted as open: open now, or (a preview before Publish) open once sign-ups go up.
  const counts = sh => st(sh) === 'open' || st(sh) === 'not_open';
  const openSum = list => list.filter(counts).reduce((k, sh) => k + (sh.unlimited ? 0 : Math.max(0, open(sh))), 0);
  const isFull = sh => !sh.unlimited && (st(sh) === 'full' || (counts(sh) && open(sh) <= 0));
  const opensWord = () => live().opens ? 'Opens ' + O.fmtDate(live().opens, 'mdShort') : 'Not open yet';
  const names = () => live().names !== false;
  const closed = () => !!live().closed;
  const committees = () => {
    const have = new Set(state.shifts.map(s => s.committee));
    const order = (live().committees || []).map(c => c.name).filter(n => have.has(n));
    have.forEach(n => { if (order.indexOf(n) < 0) order.push(n); });
    return order;
  };
  const comm = c => (live().committees || []).find(x => x.name === c) || {};
  const plural = SU.plural;
  const uniq = xs => Array.from(new Set(xs));
  const low = s => String(s || '').trim().toLowerCase().replace(/\s+/g, ' ');
  const first = n => String(n || '').trim().split(/\s+/)[0];
  const listAnd = a => a.length < 2 ? a.join('') : a.slice(0, -1).join(', ') + ' and ' + a[a.length - 1];
  const initials = n => { const w = String(n || '').replace(/\./g, '').trim().split(/\s+/).filter(Boolean); return w.length ? (w[0][0] + (w.length > 1 ? w[w.length - 1][0] : '')).toUpperCase() : ''; };
  // "7–11 AM", "11:45 AM–2:15 PM", "10 PM–12 AM": one line, tabular.
  const span = sh => O.formatRange(sh.start, sh.end, { compact: true });
  const hours = sh => { const m = sh.end - sh.start, h = Math.floor(m / 60), r = m % 60; return (h ? h + ' hr' : '') + (h && r ? ' ' : '') + (r ? r + ' min' : ''); };
  // Saturday's 12–2 AM is Friday night: a shift from midnight to 5 AM belongs to the evening before.
  const eve = sh => { const i = state.model.days.indexOf(sh.day); return sh.start < 300 && i > 0 ? state.model.days[i - 1] : sh.day; };
  const night = sh => sh.start < 300 && eve(sh) !== sh.day;
  const sortKey = sh => state.model.days.indexOf(eve(sh)) * 2880 + (night(sh) ? sh.start + 1440 : sh.start);
  const dayWord = d => O.fmtDate(d.date, 'weekday');
  const whenDay = d => d ? dayWord(d) + ', ' + O.fmtDate(d.date, 'md') : '';
  const whenShort = sh => O.fmtDate(eve(sh).date, 'weekdayShort') + (night(sh) ? ' night' : '') + ', ' + O.fmtDate(eve(sh).date, 'mdShort') + ' · ' + span(sh);
  const whenLong = sh => dayWord(eve(sh)) + (night(sh) ? ' night' : '') + ', ' + O.fmtDate(eve(sh).date, 'md');
  // Real instants for overlap (as the server): the day's index × a day + minutes.
  const t0 = sh => state.model.days.indexOf(sh.day) * 1440 + sh.start, t1 = sh => state.model.days.indexOf(sh.day) * 1440 + sh.end;
  const overlaps = (a, b) => t0(a) < t1(b) && t0(b) < t1(a);
  const placeName = sh => sh.place ? sh.place.name : '';
  const isWeek = () => { const d = state.model.days, n = today(); return d.length && n >= O.isoAddDays(d[0].date, -7) && n <= d[d.length - 1].date; };
  const today = () => (state.live && state.live.now && state.live.now.date) || O.wallNow(tz()).date;
  const during = () => { const d = state.model.days, n = today(); return !!(d.length && n >= d[0].date && n <= d[d.length - 1].date); };
  const ahead = sh => !/^(started|ended)$/.test(st(sh));
  const helpedOf = c => { const h = live().helped; return h ? (c ? (h.committees || {})[c] || 0 : h.total || 0) : null; };
  const placesOf = list => list.reduce((k, sh) => k + L(sh).f, 0);
  const helpedWords = (c, list) => { const h = helpedOf(c); return h != null ? (h ? h + ' helped' : '') : placesOf(list) ? placesOf(list) + ' places filled' : ''; };
  const masked = e => { const m = /^(.)[^@]*(@.*)$/.exec(String(e || '')); return m ? m[1] + '…' + m[2] : ''; };

  // A shift's rule: an age ("21 or older"), a choice (First Aid's certification), or words to agree to.
  const minAge = sh => +sh.min_age || ((/\b(\d{1,2})\s*(\+|or older|and older|and up)/i.exec(sh.rule || '') || [])[1] | 0);
  const question = sh => sh.question ? sh.question.split('|').map(s => s.trim()).filter(Boolean) : (/certified/i.test(sh.rule) && /partner/i.test(sh.rule) ? ['Certified', 'With a certified partner'] : []);
  const screening = sh => /^(y|yes|1|true)$/i.test(sh.screening || '');
  const ruleShort = sh => minAge(sh) ? minAge(sh) + ' or older' : question(sh).length ? 'Certified' : sh.rule;

  /* ---------------------------------------------------------------- who's helping: the people this person may sign up */

  const hh = () => (live().household && live().household.people) || [];
  const myEmail = () => low(me() && me().email);
  const fullName = n => /\s/.test(String(n || '').trim());
  const myName = () => { const m = me(); return m && fullName(m.name) ? m.name.trim() : ''; };
  // The name to call this person by: theirs, or (not signed in) the one they signed up under.
  const selfName = () => myName() || (signed() ? '' : ((mine().find(m => !m.added && !m.for) || {}).name || [typed().first, typed().last].filter(Boolean).join(' ')));
  const personOf = n => hh().find(p => low(p.name) === low(n)) || null;
  // Each person has one key, mechanically: "me"; a name under this email ("n:…"); or an email and a
  // name for someone added by their own email ("e:…|…"). Never a guess that two names are one person.
  const keyOf = (name, email) => { const e = low(email); if (e && e !== myEmail()) return 'e:' + e + '|' + low(name); return selfName() && low(name) === low(selfName()) ? 'me' : 'n:' + low(name); };
  const keyOfMine = m => keyOf(m.name, m.added ? m.email : '');
  // Your own places (not those of people you signed up): what Show my name changes.
  const selfRecs = () => mine().filter(m => !m.added && (!m.for || (selfName() && low(m.name) === low(selfName()))));
  function circle() {
    const out = [], seen = new Set();
    const push = p => { if (!seen.has(p.k)) { seen.add(p.k); out.push(p); } };
    const self = myName();
    if (signed() && self) push({ k: 'me', name: self, self: true, info: personOf(self) });
    if (signed()) {
      hh().forEach(p => { if (low(p.name) !== low(self)) push({ k: 'n:' + low(p.name), name: p.name, info: p }); });
      (live().circle || []).forEach(c => push({ k: keyOf(c.name, c.email), name: c.name, email: c.email && low(c.email) !== myEmail() ? c.email : '', info: c.email ? null : personOf(c.name) }));
    }
    // An emailed link (a place opened, your shifts again) vouches for its email and names its people.
    if (vouched()) (state.link.names || []).forEach(n => push({ k: 'n:' + low(n), name: n, info: null }));
    state.added.forEach(push);
    return out;
  }
  // The first time (not signed in, no emailed link): name, email and phone in the row; that's one person.
  const formSelf = () => !signed() && !vouched();
  // Signed in without a full name yet (and no household to pick from): the name is asked once.
  const nameSelf = () => signed() && !myName() && !hh().length;
  const selfCount = () => formSelf() || nameSelf() ? 1 : 0;
  const kindWords = info => !info ? '' : info.yf ? 'Young Folk' + (info.years != null ? ' · ' + info.years : '') : info.years != null && info.years < 18 ? 'Child · ' + info.years : 'Adult';
  // What keeps a person off this shift: on it already, the rule (an age the registration gives), Busy.
  const clashOf = (k, sh) => mine().filter(m => m.shift !== sh.id && keyOfMine(m) === k).map(m => find(m.shift)).find(x => x && overlaps(x, sh)) || null;
  const busyWords = b => 'Busy · ' + b.role + ' ' + span(b);
  function ruleWhy(p, sh) {
    const a = minAge(sh), info = p.info;
    if (!a || !info) return '';
    if (info.years != null) return info.years < a ? 'Under ' + a : '';
    return a >= 18 && (info.age === 'minor' || info.age === 'child') ? 'Under ' + a : '';
  }
  function whyNot(p, sh) {
    if (minesOn(sh).some(m => keyOfMine(m) === p.k)) return { why: 'On this shift' };
    const r = ruleWhy(p, sh);
    if (r) return { why: r };
    const b = clashOf(p.k, sh);
    return b ? { why: busyWords(b), busy: b } : null;
  }
  const notHere = (p, sh) => p.info && p.info.days && p.info.days.length && p.info.days.indexOf(sh.day.date) < 0;
  const picked = sh => circle().filter(p => state.pick.indexOf(p.k) > -1 && !whyNot(p, sh));
  const pickN = sh => picked(sh).length + selfCount();

  /* ---------------------------------------------------------------- render */

  function render() {
    root.removeAttribute('aria-busy');
    const posted = live().posted || closed() || q.get('preview') === '1';
    let body;
    if (!state.shifts.length || !posted) body = notPosted();
    else if (state.committee && (state.committee === '*' || committees().indexOf(state.committee) > -1)) body = listView();
    else { state.committee = ''; body = homeView(); }
    const side = showWeek();
    root.innerHTML = '<div class="wk vol vo' + (side ? ' has-pbar' : '') + '">' + band() + '<section class="vo-stage"><div class="wk-wrap vo-grid"><div class="vo-main">' + linkCard() + body + '</div>' +
      (side ? '<aside class="vo-side" aria-label="Your week">' + weekCard() + '</aside>' : '') + '</div></section></div>';
    document.title = (state.committee === '*' ? 'All shifts – ' : state.committee ? state.committee + ' – ' : '') + 'Volunteer – ' + state.year + ' Annual Conference – Old German Baptist Brethren Church, New Conference';
    pbarDraw();
    if (wsheet.open) drawSheet();
    fitCal();
  }
  // Your week shows wherever there are shifts to sign up for (not for a year that's over).
  const showWeek = () => !!(state.shifts.length && !closed() && (live().posted || q.get('preview') === '1'));

  // The band: which Conference, the page's name, and who the page thinks you are.
  function band() {
    const s = S(), r = state.row, c = state.committee;
    const where = r.city || s.city || '';
    const when = r.start ? O.fmtDateSpan(r.start, r.end) : '';
    const list = c === '*' ? state.shifts : state.shifts.filter(sh => sh.committee === c);
    let t;
    if (c) {
      t = '<a class="vo-back" href="?year=' + esc(state.year) + '" data-go="">' + I.back + '<span>Committees</span></a>' +
        '<p class="wk-kicker">' + esc(state.year) + ' Annual Conference · Volunteer' + (closed() ? ' · Closed' : '') + '</p>' +
        '<h1 class="vo-title" tabindex="-1">' + (c === '*' ? 'All shifts' : '<span class="vo-title__ic">' + ci(c) + '<span>' + esc(c) + '</span></span>') + '</h1>';
    } else {
      t = '<p class="wk-kicker">' + esc(state.year) + ' Annual Conference</p><h1 class="vo-title" tabindex="-1">Volunteer</h1>' +
        (when ? '<p class="vo-when">' + esc(when) + (where ? ' · ' + esc(where) : '') + '</p>' : r.hosts ? '<p class="vo-when">' + esc(/^hosted/i.test(r.hosts) ? r.hosts : 'Hosted by the ' + r.hosts) + '</p>' : '') +
        (live().closes && !closed() ? '<p class="vo-when">Closes ' + esc(O.fmtDate(live().closes, 'md')) + '</p>' : '');
    }
    const facts = !c && state.shifts.length && live().posted && !closed() ? '<span class="vo-meta__line">' + esc(openSum(state.shifts) + ' places open · ' + plural(committees().length, 'committee')) + '</span>' : '';
    return '<header class="vo-band"><div class="wk-wrap vo-band__in"><div class="vo-band__t">' + t + '</div><p class="vo-meta">' + facts + idLine() + '</p></div></header>' + (list && !list.length && c && c !== '*' ? '' : '');
  }
  // Who the page thinks you are, with a way out on a shared device; or Sign in.
  function idLine() {
    const m = me(), ret = encodeURIComponent(location.pathname + location.search);
    const signin = (W.signin || '/annual-conference/signin/') + '?return=' + ret;
    if (m && m.signed) {
      return '<span class="vo-meta__line">' + (myName() ? '<b>' + esc(myName()) + '</b> · ' : '') + esc(m.email) + ' · <button type="button" class="wk-linklike" data-signout>Not you?</button></span>';
    }
    if ((m && m.email) || mine().some(x => !x.confirmed)) return '<span class="vo-meta__line">' + (m && m.email ? esc(masked(m.email)) + ' · ' : '') + 'Check your email · <button type="button" class="wk-linklike" data-forget>Not you?</button></span>';
    return '<span class="vo-meta__line"><a href="' + esc(signin) + '">Sign in</a></span>';
  }

  // Nothing posted is said as that; a year with no shifts shows its own name and hosts.
  function notPosted() {
    const asked = kept.get('asked-' + state.year, false);
    const opens = live().opens;
    return '<section class="vol-blank"><h2 class="vol-blank__h">' + (opens ? 'Opens ' + esc(O.fmtDate(opens, 'md')) : 'Not posted yet') + '</h2>' +
      (asked ? '<p class="vol-blank__p">' + I.check + 'We’ll email you</p>'
        : '<form class="vol-notify" data-notify novalidate>' + (signed() ? '' : '<label class="vol-f"><span>Email</span><input name="email" type="email" autocomplete="email" inputmode="email"><small class="vol-err" hidden></small></label>') +
          '<input class="vol-hp" name="hp" tabindex="-1" autocomplete="off" aria-hidden="true"><button type="submit" class="wk-btn wk-btn--small">' + I.mail + 'Email me when it opens</button></form>') + '</section>';
  }

  // A link from an email, answered at the top of the page.
  function linkCard() {
    const k = state.link;
    if (!k) return '';
    const box = (h, p, act) => '<section class="vol-note" role="status"><p class="vol-note__h">' + h + '</p>' + (p ? '<p class="vol-note__p">' + p + '</p>' : '') + (act || '') + '</section>';
    if (k.error) return box('Link expired', 'Sign in to see your sign-ups.', '<p><a class="wk-btn wk-btn--small" href="' + esc((W.signin || '') + '?return=' + encodeURIComponent(location.pathname + '?year=' + state.year)) + '">Sign in</a></p>');
    if (k.a === 'confirm') {
      // Someone added by another person confirms here; their phone is asked now (Add someone asks only a
      // name and an email), for the committee head.
      const need = signed() && !me().phone && mine().some(m => !m.added && m.nophone);
      if (k.phoneSaved) return box(I.check + 'Confirmed', esc(plural(k.n || 0, 'shift')) + ' · Phone saved');
      const shown = names() && selfRecs().length && selfRecs().every(m => m.confirmed && !m.hide && (!m.for || m.shown));
      return box(I.check + 'Confirmed', esc(plural(k.n || 0, 'shift')) + (need || !shown ? '' : ' · Your name shows on the list'),
        need ? '<form class="vo-phone" data-phoneform novalidate><label class="vo-in' + (state.err.cphone ? ' is-bad' : '') + '"><span>Phone</span><input name="phone" type="tel" autocomplete="tel" inputmode="tel"' + (state.err.cphone ? ' aria-invalid="true"' : '') + '><small class="' + (state.err.cphone ? '' : 'is-help') + '">' + esc(state.err.cphone || 'For the committee head') + '</small></label><button type="submit" class="wk-btn wk-btn--small">Save</button></form>' : '');
    }
    if (k.a === 'notme') return box('Removed', esc(plural(k.n || 0, 'sign-up')) + ' under ' + esc(k.email) + ' · The committee head is told');
    if (k.a === 'unnotify') return box('Removed', 'No email when sign-ups open');
    if (k.a === 'leave') {
      const rs = (k.records || []).filter(r => find(r.shift));
      if (!rs.length) return box('Not signed up', 'Nothing to leave under ' + esc(k.email));
      if (k.left) return box('Left shift', rs.map(r => esc(find(r.shift).role + ' · ' + whenShort(find(r.shift)))).join('<br>'));
      const lines = rs.map(r => esc(find(r.shift).role + ' · ' + whenShort(find(r.shift)) + (rs.length > 1 ? ' · ' + r.name : ''))).join('<br>');
      if (k.swap) return box('Swap open', lines + '<br>Your place stays yours until someone takes it.', '<p class="vol-note__btns"><button type="button" class="wk-btn wk-btn--small" data-linkswapcopy>' + I.link + 'Copy link</button></p>');
      return box('Leave this shift?', lines + '<br>The committee head is told.',
        '<p class="vol-note__btns"><button type="button" class="wk-btn wk-btn--small" data-linkswap>Find replacement</button><button type="button" class="wk-linklike" data-linkleave>Leave shift</button><button type="button" class="wk-linklike" data-linkkeep>Keep</button></p>');
    }
    if (k.a === 'again' || k.a === 'opened') {
      const shs = (k.shifts || []).map(find).filter(Boolean);
      if (k.done) return '';
      if (k.unwaited) return box('Off the waitlist', shs.map(sh => esc(sh.role + ' · ' + whenShort(sh))).join('<br>'));
      return box(k.a === 'opened' ? 'A place opened' : 'Your ' + (state.year - 1) + ' shifts', shs.map(sh => esc(sh.role + ' · ' + whenShort(sh) + ' · ' + openText(sh))).join('<br>'),
        '<p class="vol-note__btns"><button type="button" class="wk-btn wk-btn--small" data-linkjoin>' + (shs.length > 1 ? 'Sign up · ' + plural(shs.length, 'shift') : 'Sign up') + '</button>' +
        (k.a === 'opened' && k.waiting ? '<button type="button" class="wk-linklike" data-linkunwait>Leave waitlist</button>' : '') + '</p>');
    }
    return '';
  }
  const openText = sh => sh.unlimited ? L(sh).f + ' coming' : open(sh) > 0 ? open(sh) + ' open' : 'Full';

  /* ---------------------------------------------------------------- the committees as cards */

  function homeView() {
    if (closed()) {
      const vols = helpedWords('', state.shifts);
      // A past year's one action is the next Conference: its shifts when it has them, else Email me.
      const nx = (state.years || []).find(y => +y.year === +state.year + 1);
      const next = nx && nx.data ? '<p><a class="wk-btn wk-btn--small" href="?year=' + esc(nx.year) + '">' + esc(nx.year) + ' shifts</a></p>'
        : nx ? (kept.get('asked-' + nx.year, false) ? '<p class="vol-blank__p">' + I.check + 'We’ll email you when ' + esc(nx.year) + ' opens</p>'
          : '<form class="vol-notify" data-notify="' + esc(nx.year) + '" novalidate>' + (signed() ? '' : '<label class="vol-f"><span>Email</span><input name="email" type="email" autocomplete="email" inputmode="email"><small class="vol-err" hidden></small></label>') + '<input class="vol-hp" name="hp" tabindex="-1" autocomplete="off" aria-hidden="true"><button type="submit" class="wk-btn wk-btn--small">' + I.mail + 'Email me when ' + esc(nx.year) + ' opens</button></form>') : '';
      return '<section class="vol-blank"><h2 class="vol-blank__h">Closed</h2><p class="vol-blank__p">' + esc([plural(state.shifts.length, 'shift'), vols].filter(Boolean).join(' · ')) + '</p>' + next + '</section>' +
        '<ul class="vo-cards">' + committees().map(card).join('') + '</ul>';
    }
    return '<ul class="vo-cards">' + committees().map(card).join('') + '</ul>' +
      '<p class="vo-allrow"><a class="vo-link" href="?year=' + esc(state.year) + '&view=all" data-go="*">All shifts</a></p>';
  }
  const said = (r, c) => { const a = r.toLowerCase(), b = c.toLowerCase(); return a === b || a.replace(/\s+helpers?$/, '') === b; };
  function daysWords(list) {
    const ds = state.model.days.filter(d => list.some(sh => eve(sh) === d));
    if (!ds.length) return '';
    const idx = ds.map(d => state.model.days.indexOf(d));
    const run = idx.every((x, i) => i === 0 || x === idx[i - 1] + 1);
    return ds.length === 1 ? dayWord(ds[0]) : run ? dayWord(ds[0]).slice(0, 3) + ' – ' + dayWord(ds[ds.length - 1]).slice(0, 3) : ds.map(d => dayWord(d).slice(0, 3)).join(', ');
  }
  function card(c) {
    // During the week a card speaks of what's still ahead.
    const list = state.shifts.filter(sh => sh.committee === c && (closed() || !during() || ahead(sh)));
    if (!list.length) return '';
    const o = openSum(list), anyOpen = list.some(sh => counts(sh) && open(sh) > 0);
    const roles = uniq(list.map(sh => sh.role));
    const jobs = roles.length === 1 && said(roles[0], c) ? '' : roles.join(' · ');
    const yours = uniq(list.filter(sh => minesOn(sh).length).map(sh => sh.id)).length;
    const helped = closed() ? helpedWords(c, list) : '';
    const n = closed() ? (helped ? '<strong>' + esc(helped.split(' ')[0]) + '</strong><span>' + esc(helped.split(' ').slice(1).join(' ')) + '</span>' : '')
      : anyOpen ? (o ? '<strong>' + o + '</strong><span>open</span>' : '<strong class="is-word">No limit</strong>') : '<strong class="is-word">Full</strong>';
    const label = c + ', ' + (closed() ? helped || plural(list.length, 'shift') : anyOpen ? (o ? o + ' places open' : 'no limit') : 'full') + ', ' + roles.join(', ') + ', ' + daysWords(list) + (yours ? ', yours: ' + yours : '');
    return '<li><a class="vo-cc' + (anyOpen || closed() ? '' : ' is-full') + '" href="?year=' + esc(state.year) + '&committee=' + encodeURIComponent(c) + '" data-go="' + esc(c) + '" aria-label="' + esc(label) + '">' +
      ci(c) + '<span class="vo-cc__n">' + n + '</span><span class="vo-cc__name">' + esc(c) + '</span>' + (jobs ? '<span class="vo-cc__jobs">' + esc(jobs) + '</span>' : '') +
      '<span class="vo-cc__days">' + esc(daysWords(list)) + '</span>' + (yours ? '<span class="vo-cc__yours"><span class="vo-tag">' + I.check + 'Yours · ' + yours + '</span></span>' : '') + '</a></li>';
  }

  /* ---------------------------------------------------------------- one committee (or all): shifts by day */

  function listView() {
    const c = state.committee, all = c === '*';
    let list = state.shifts.filter(sh => all || sh.committee === c).sort((a, b) => sortKey(a) - sortKey(b) || a.committee.localeCompare(b.committee));
    // During the week: the days still to come, today first.
    if (during() && !closed()) list = list.filter(sh => eve(sh).date >= today());
    const days = state.model.days.filter(d => list.some(sh => eve(sh) === d));
    let dsel = state.day[c] != null ? state.day[c] : kept.get('day-' + state.year + '-' + c, '');
    if (dsel && !days.some(d => d.key === dsel)) dsel = '';
    state.day[c] = dsel;
    const inDay = list.filter(sh => !dsel || eve(sh).key === dsel);
    const vis = sh => closed() || !state.hideFull || !isFull(sh) || minesOn(sh).length || state.open === sh.id;
    const hidden = inDay.filter(sh => !vis(sh)).length;
    const chip = (key, label, title) => '<button type="button" class="vo-chip" data-day="' + esc(key) + '" aria-pressed="' + (dsel === key) + '"' + (title ? ' title="' + esc(title) + '"' : '') + '>' + esc(label) + '</button>';
    let h = '<div class="vo-fbar">' + (days.length > 1 ? '<div class="vo-chips" role="group" aria-label="Day">' + chip('', 'All days') + days.map(d => chip(d.key, dayWord(d).slice(0, 3), whenDay(d))).join('') + '</div>' : '') +
      (closed() ? '' : '<span class="vo-fbar__sp"></span><button type="button" class="vo-toggle" role="switch" aria-checked="' + state.hideFull + '" data-hidefull><span class="vo-toggle__sw" aria-hidden="true"></span>Hide full</button>' +
        (state.hideFull && hidden ? '<span class="vo-hidden">' + hidden + ' full hidden</span>' : '')) + '</div>';
    const groups = days.filter(d => !dsel || d.key === dsel).map(d => ({ d, rows: inDay.filter(sh => eve(sh) === d && vis(sh)) })).filter(g => g.rows.length);
    if (!groups.length) return h + '<p class="vo-nothing">' + (inDay.length ? 'No open shifts' + (dsel ? ' on ' + esc(dayWord(days.find(d => d.key === dsel))) : '') : 'No shifts') + '</p>';
    groups.forEach(g => {
      const o = g.rows.reduce((k, sh) => k + (counts(sh) && !sh.unlimited ? Math.max(0, open(sh)) : 0), 0);
      h += '<section class="vo-day" aria-label="' + esc(whenDay(g.d)) + '"><div class="vo-day__h"><h2>' + esc(whenDay(g.d)) + '</h2><span>' + esc(plural(g.rows.length, 'shift') + (closed() ? '' : ' · ' + o + ' open')) + '</span></div><ol class="vo-list">' + g.rows.map(sh => row(sh, all)).join('') + '</ol></section>';
    });
    return h;
  }

  // Who's on it: a round mark a person (initials; yours in tan; waiting to confirm a clock), then the
  // open places dashed. A big shift: the first few, "+ N", and two open marks.
  const seatsOf = sh => (L(sh).s || []).map(x => ({ l: x[0], i: x[1], you: !!x[2], swap: x[3], n: x[4] || '' }));
  const waitingSeat = (sh, n) => minesOn(sh).some(m => low(m.name) === low(n) && !m.confirmed);
  function marks(sh) {
    const ppl = seatsOf(sh), o = sh.unlimited ? 0 : Math.max(0, open(sh));
    const ord = ppl.filter(p => p.you).concat(ppl.filter(p => !p.you));
    const mk = p => {
      if (p.you && waitingSeat(sh, p.n)) return '<span class="vo-mk is-wait" title="' + esc(p.n + ' · Waiting to confirm') + '">' + I.clock + '</span>';
      if (p.you) return '<span class="vo-mk is-you" title="' + esc(p.n) + '">' + esc(initials(p.n)) + '</span>';
      if (p.l && names()) return '<span class="vo-mk' + (p.swap ? ' is-swap' : '') + '" title="' + esc(p.l) + '">' + esc(p.i || '') + '</span>';
      return '<span class="vo-mk is-anon' + (p.swap ? ' is-swap' : '') + '"></span>';
    };
    const opn = n => Array.from({ length: n }, () => '<span class="vo-mk is-open"></span>').join('');
    if (!sh.unlimited && sh.needed <= 7) return '<span class="vo-marks" aria-hidden="true">' + ord.map(mk).join('') + opn(o) + '</span>';
    const shown = ord.slice(0, 4), more = ord.length - shown.length;
    return '<span class="vo-marks" aria-hidden="true">' + shown.map(mk).join('') + (more > 0 ? '<span class="vo-mk is-more">+' + more + '</span>' : '') + opn(Math.min(2, o)) + '</span>';
  }
  const STATE_WORD = { started: 'Started', ended: 'Ended', closed: 'Closed', committee: 'By committee' };
  const stateWord = s => s === 'not_open' ? opensWord() : STATE_WORD[s] || '';
  // "3 of 4 open · Daniel and Esther": what's open, then your own (confirmed) on it by first name.
  function openLine(sh) {
    const you = minesOn(sh), ok = you.filter(m => m.confirmed);
    const n = closed() ? (L(sh).f ? L(sh).f + ' helped' : '') : sh.unlimited ? (L(sh).f ? L(sh).f + ' coming' : 'No limit') : open(sh) > 0 ? '<b>' + open(sh) + ' of ' + sh.needed + '</b> open' : 'Full';
    return '<span class="vo-open">' + n + (ok.length && !closed() ? ' · ' + esc(listAnd(uniq(ok.map(m => first(m.name))))) : '') + '</span>' +
      you.filter(m => !m.confirmed).map(m => '<span class="vo-waitline">' + I.clock + '<span><b>' + esc(m.name) + '</b> · <span class="vo-nw">Waiting to confirm</span></span></span>').join('');
  }
  function row(sh, withC) {
    const you = minesOn(sh), s = st(sh), o = open(sh), full = isFull(sh), isOpen = state.open === sh.id;
    // Every committee at once: the committee where the place would be (the place is in the open row).
    const where = withC ? sh.committee : placeName(sh);
    const meta = (where ? (withC ? '' : I.pin) + '<span>' + esc(where) + '</span>' : '') + (ruleShort(sh) ? (where ? '<span>·</span>' : '') + '<span class="vo-rule">' + esc(ruleShort(sh)) + '</span>' : '');
    const lbl = sh.role + ', ' + whenLong(sh) + ', ' + span(sh).replace('–', ' to ');
    let act;
    if (closed()) act = '';
    else if (you.length && (full || !joinable(sh))) act = '<button type="button" class="vo-yours" data-open="' + esc(sh.id) + '" aria-expanded="' + isOpen + '" aria-controls="vo-p-' + esc(sh.id) + '" aria-label="' + esc('Yours: ' + lbl) + '">' + I.check + 'Yours</button>';
    else if (s === 'open' && o > 0) act = '<button type="button" class="wk-btn wk-btn--line wk-btn--small" data-open="' + esc(sh.id) + '" aria-expanded="' + isOpen + '" aria-controls="vo-p-' + esc(sh.id) + '" aria-label="' + esc((isOpen ? 'Close ' : 'Sign up for ') + lbl) + '">' + (isOpen ? 'Close' : 'Sign up') + '</button>';
    else if (full && (s === 'full' || s === 'open')) act = waitsOn(sh).length ? '<button type="button" class="vo-yours" data-open="' + esc(sh.id) + '" aria-expanded="' + isOpen + '">On waitlist</button>' : '<button type="button" class="wk-btn wk-btn--line wk-btn--small" data-open="' + esc(sh.id) + '" aria-expanded="' + isOpen + '" aria-controls="vo-p-' + esc(sh.id) + '" aria-label="' + esc('Waitlist for ' + lbl) + '" title="Email when a place opens">' + (isOpen ? 'Close' : 'Waitlist') + '</button>';
    else act = '<span class="vo-state"' + (s === 'committee' ? ' title="Filled by the committee"' : '') + '>' + esc(stateWord(s)) + '</span>';
    return '<li class="vo-row' + (isOpen ? ' is-open' : '') + (state.flash === sh.id ? ' is-flash' : '') + (s === 'started' || s === 'ended' ? ' is-past' : '') + '" id="vo-r-' + esc(sh.id) + '" data-row="' + esc(sh.id) + '">' +
      '<div class="vo-row__top"><div class="vo-row__time">' + (night(sh) ? '<span class="vo-row__night">' + esc(dayWord(eve(sh)).slice(0, 3)) + ' night</span>' : '') + '<b>' + esc(span(sh)) + '</b><span>' + esc(hours(sh)) + '</span></div>' +
      '<div class="vo-row__what"><b>' + esc(sh.role) + '</b><span class="vo-row__meta">' + meta + '</span></div>' +
      '<div class="vo-row__places">' + (closed() ? '' : marks(sh)) + openLine(sh) + '</div>' +
      '<div class="vo-row__act">' + act + '</div></div>' + (isOpen ? panel(sh) : '') + '</li>';
  }

  /* ---------------------------------------------------------------- the row, opened */

  function panel(sh) {
    return '<div class="vo-panel" id="vo-p-' + esc(sh.id) + '">' + info(sh) + '<div class="vo-who">' + whoSide(sh) + '</div></div>';
  }
  // What it is: what to do, who's on it, where, who to ask; Invite.
  function info(sh) {
    const ppl = seatsOf(sh), phone = comm(sh.committee).phone;
    const shown = ppl.filter(p => p.you).map(p => first(p.n) || 'You').concat(names() ? ppl.filter(p => !p.you && p.l).map(p => p.l) : []);
    const rest = ppl.length - shown.length;
    const on = shown.length || rest ? '<p><b>On this shift</b> · ' + esc(shown.concat(rest ? [shown.length ? plural(rest, 'more', 'more') : plural(rest, 'volunteer')] : []).join(' · ')) + '</p>' : '';
    const map = sh.place && whereMap(sh.place, true);
    return '<div class="vo-info">' + (sh.note ? '<p class="vo-desc">' + esc(sh.note) + '</p>' : '') + on +
      (sh.place ? '<p><b>Place</b> · ' + esc(sh.place.name) + (map ? ' · <button type="button" class="wk-linklike" data-map="' + esc(sh.id) + '" aria-expanded="' + (state.mapOpen === sh.id) + '">Map</button>' : '') + '</p>' + (state.mapOpen === sh.id ? '<div class="vo-map">' + whereMap(sh.place) + '</div>' : '') : '') +
      (phone && !closed() ? '<p><b>Questions</b> · <a href="tel:' + esc(phone.replace(/[^\d+]/g, '')) + '">' + esc(phone) + '</a></p>' : '') +
      (closed() || !/^(open|full)$/.test(st(sh)) ? '' : '<p><button type="button" class="wk-linklike" data-invite="' + esc(sh.id) + '">Invite someone</button></p>') + '</div>';
  }
  function whoSide(sh) {
    const you = minesOn(sh), s = st(sh), o = open(sh), full = isFull(sh);
    const swapSeat = !you.length && seatsOf(sh).find(p => p.swap);
    let h = you.length ? mineBlock(sh, you) : '';
    if (closed()) return h;
    if (swapSeat && (state.swap || q.get('swap'))) return h + takeBlock(sh, swapSeat);
    if (s === 'open' && o > 0) return h + whoBlock(sh);
    if (full && !you.length && (s === 'full' || s === 'open')) return h + waitBlock(sh, swapSeat);
    if (!you.length) h += '<p class="vo-full">' + esc(stateWord(s) || 'Full') + (s === 'started' && comm(sh.committee).phone ? ' · Call ' + esc(comm(sh.committee).phone) : '') + '</p>';
    return h;
  }

  // Your place on it: who, what's still to do (confirm), and its actions (Calendar, Leave).
  function mineBlock(sh, you) {
    const ok = you.filter(m => m.confirmed), wait = you.filter(m => !m.confirmed);
    const ownWait = wait.filter(m => !m.added), addWait = wait.filter(m => m.added);
    const swap = you.find(m => m.swap);
    const s = st(sh), started = s === 'started' || s === 'ended';
    let h = '<div class="vo-mine">';
    h += '<p class="vo-mine__h">' + I.check + '<span>Signed up' + (ok.length ? ' · ' + esc(listAnd(uniq(ok.map(m => first(m.name))))) : '') + '</span></p>';
    h += addWait.map(m => '<p class="vo-waitline">' + I.clock + '<span><b>' + esc(m.name) + '</b> · <span class="vo-nw">Waiting to confirm</span></span></p>').join('');
    if (ownWait.length) h += confirmHelp(ownWait.map(m => m.rid), 'row:' + sh.id);
    if (started) h += '<p class="vo-full">' + esc(STATE_WORD[s]) + (comm(sh.committee).phone ? ' · Can’t come? Call ' + esc(comm(sh.committee).phone) : '') + '</p>';
    else if (swap) h += '<p class="vo-full">Swap open · ' + esc(first(swap.name)) + '’s place stays until someone takes it</p><p class="vo-mine__acts"><button type="button" class="vo-link" data-swapcopy="' + esc(swap.swap) + '">' + I.link + 'Copy link</button><button type="button" class="vo-link" data-swapoff="' + swap.rid + '">Cancel swap</button></p>';
    else if (state.leaving === sh.id) h += leaveAsk(sh, you);
    else h += '<p class="vo-mine__acts"><button type="button" class="vo-link" data-ics="' + esc(sh.id) + '">' + I.cal + 'Calendar</button><button type="button" class="vo-link" data-leave="' + esc(sh.id) + '">Leave</button></p>';
    return h + '</div>';
  }
  // Leave asks first: which of you (several on it), Leave shift, Find replacement where a place is hard
  // to fill again, or Keep.
  function leaveAsk(sh, you) {
    const k = isFull(sh) || open(sh) <= 1;
    return '<div class="vo-ask" role="group" aria-label="Leave this shift?"><p><b>Leave this shift?</b> The ' + esc(sh.committee) + ' head is told.</p>' +
      (you.length > 1 ? '<span class="rf-seg vo-seg">' + you.map(m => '<label class="rf-tog"><input type="checkbox" name="leavewho" value="' + m.rid + '"' + ((state.leaveWho || []).indexOf(m.rid) > -1 || !state.leaveWho ? ' checked' : '') + '><span>' + I.check + esc(first(m.name)) + '</span></label>').join('') + '</span>' : '') +
      '<p class="vo-ask__btns"><button type="button" class="wk-btn wk-btn--line wk-btn--small" data-leavego="' + esc(sh.id) + '"' + (state.busyAct ? ' disabled' : '') + '>' + (state.busyAct === 'leave' ? 'Leaving…' : 'Leave shift') + '</button>' +
      (k && !you.some(m => m.swap) ? '<button type="button" class="vo-link" data-swapon="' + esc(sh.id) + '">Find replacement</button>' : '') +
      '<button type="button" class="vo-link" data-leavekeep="' + esc(sh.id) + '">Keep</button></p>' + (state.footErr && state.leaving === sh.id ? '<p class="vo-errline" role="alert">' + I.alert + esc(state.footErr) + '</p>' : '') + '</div>';
  }

  // Who's helping: your own name first, then your household (or those you've signed up before), then
  // Add someone. The pills stop at the open places; Sign up says how many.
  function whoBlock(sh) {
    const o = open(sh), you = minesOn(sh), ppl = circle(), n = pickN(sh), e = state.err;
    let h = '<div class="vo-who__h"><span class="vo-label" id="vo-wh-' + esc(sh.id) + '">' + (you.length ? 'Add to this shift' : 'Who’s helping?') + '</span>' + (o !== Infinity ? '<span class="vo-who__n">' + n + ' of ' + o + (o === 1 ? ' place' : ' places') + '</span>' : '') + '</div>';
    if (formSelf()) h += selfBox(sh, true);
    else if (nameSelf()) h += selfBox(sh, false);
    h += '<div class="vo-pills" role="group" aria-labelledby="vo-wh-' + esc(sh.id) + '">';
    ppl.forEach(p => {
      const no = whyNot(p, sh), on = !no && state.pick.indexOf(p.k) > -1, capped = !on && !no && n >= o;
      const sub = no ? no.why : p.self ? 'Signed in' : p.email ? p.email : kindWords(p.info) + (notHere(p, sh) ? ' · Not here ' + dayWord(sh.day).slice(0, 3) : '');
      h += '<button type="button" class="vo-wp' + (no && no.busy ? ' is-busy' : '') + (capped ? ' is-capped' : '') + '" data-pick="' + esc(p.k) + '" aria-pressed="' + on + '"' + (no ? ' aria-disabled="true"' : '') + (capped ? ' title="' + esc(o + ' of ' + o + ' places chosen') + '"' : '') + '>' +
        '<span class="vo-wp__av" aria-hidden="true">' + esc(initials(p.name)) + '</span><span class="vo-wp__tx"><b>' + esc(p.name) + '</b>' + (sub ? '<small>' + esc(sub) + '</small>' : '') + '</span></button>';
    });
    if (!state.add) h += '<button type="button" class="vo-wp is-add" data-addopen' + (n >= o ? ' title="' + esc(o + ' of ' + o + ' places chosen') + '"' : '') + '><span class="vo-wp__av" aria-hidden="true">' + I.plus + '</span><span class="vo-wp__tx"><b>Add someone</b></span></button>';
    h += '</div>';
    if (state.add) h += addBox();
    // A phone for the people under this email, once (the household's or one given before is used).
    const sameOnes = picked(sh).filter(p => !p.email);
    if (signed() && !me().phone && (sameOnes.length || nameSelf())) h += '<div class="vo-box vo-box--me vo-box--one">' + fld('me1', 'phone', 'Phone', 'tel', 'For the committee head', ' autocomplete="tel" inputmode="tel"', true) + '</div>';
    h += ruleAsk(sh);
    if (screening(sh)) h += '<fieldset class="vo-q"><legend class="vo-label">Child-safety screening</legend><span class="rf-seg" role="radiogroup">' + [['yes', 'Screened'], ['not_yet', 'Not yet']].map(x => '<label class="rf-tog"><input type="radio" name="screened" value="' + x[0] + '"' + (state.ans.screened === x[0] ? ' checked' : '') + (e.screened ? ' aria-invalid="true"' : '') + '><span>' + I.check + x[1] + '</span></label>').join('') + '</span>' + (e.screened ? '<p class="vo-errline">' + I.alert + esc(e.screened) + '</p>' : '<p class="vo-help">Shown to the committee head only</p>') + '</fieldset>';
    h += '<details class="vo-notefld"' + (state.ans.noteOpen ? ' open' : '') + ' data-notefld><summary>Note for the head</summary><label class="vo-in"><span class="ogc-sr">Note for the head</span><input name="note" data-f="ans" maxlength="200" value="' + esc(state.ans.note || '') + '"><small class="is-help">For the committee head only</small></label></details>';
    h += '<div class="vo-who__foot">' + (state.footErr ? '<p class="vo-errline" role="alert">' + I.alert + esc(state.footErr) + '</p>' : '') +
      '<button type="button" class="vo-link" data-close="' + esc(sh.id) + '">Cancel</button>' +
      '<button type="button" class="wk-btn" data-signup="' + esc(sh.id) + '"' + (n && !state.busyAct ? '' : ' disabled') + '>' + (state.busyAct === 'join' ? 'Signing up…' : 'Sign up' + (n ? ' ' + n : '')) + '</button></div>';
    return h;
  }
  // A field: the label in the box (placeholder), its error under it. f is the state bag (me1, add, ans).
  function fld(f, name, label, type, help, attrs, wide) {
    const v = (state[f] || {})[name], e = state.err[f + '.' + name];
    return '<label class="vo-in' + (e ? ' is-bad' : '') + (wide ? ' vo-full' : '') + '"><span class="ogc-sr">' + esc(label) + '</span><input name="' + name + '" data-f="' + f + '" type="' + type + '" placeholder="' + esc(label) + '" value="' + esc(v || '') + '"' + (e ? ' aria-invalid="true"' : '') + (attrs || '') + '>' +
      (e ? '<small role="alert">' + (e.html || esc(e)) + '</small>' : help ? '<small class="is-help">' + esc(help) + '</small>' : '') + '</label>';
  }
  // The first time: who you are (one person). Signed in without a name: just the name.
  function selfBox(sh, full) {
    const t = typed();
    if (full && !state.me1.touched) state.me1 = Object.assign({ first: t.first || '', last: t.last || '', email: t.email || '', phone: tabPhone || '' }, state.me1, { touched: true });
    const ret = encodeURIComponent(location.pathname + '?year=' + state.year + '&shift=' + sh.id);
    return '<div class="vo-box vo-box--me"><p class="vo-label">' + (full ? 'Name, email and phone' : 'Your name') + '</p>' +
      fld('me1', 'first', 'First name', 'text', '', ' autocomplete="given-name"') + fld('me1', 'last', 'Last name', 'text', '', ' autocomplete="family-name"') +
      (full ? fld('me1', 'email', 'Email', 'email', '', ' autocomplete="email" inputmode="email"') + fld('me1', 'phone', 'Phone', 'tel', '', ' autocomplete="tel" inputmode="tel"') +
        '<input class="vol-hp" name="hp" data-f="me1" tabindex="-1" autocomplete="off" aria-hidden="true">' +
        '<p class="vo-help">Confirmed by email · No password · Signed up before? <a href="' + esc((W.signin || '') + '?return=' + ret) + '">Sign in</a></p>' : '') + '</div>';
  }
  function addBox() {
    return '<div class="vo-box" data-addform><p class="vo-label">Add someone</p>' + fld('add', 'first', 'First name', 'text', '', ' autocomplete="off"') + fld('add', 'last', 'Last name', 'text', '', ' autocomplete="off"') +
      fld('add', 'email', 'Their email', 'email', '', ' autocomplete="off" inputmode="email"', true) +
      '<p class="vo-help">They confirm by email · The place is held until then</p>' +
      '<div class="vo-box__acts"><button type="button" class="vo-link" data-addcancel>Cancel</button><button type="button" class="wk-btn wk-btn--line wk-btn--small" data-addsave>Add</button></div></div>';
  }
  // The rule, asked once for everyone ticked: an age the registration doesn't give, as a claim
  // ("Esther and Alex are 21 or older"); First Aid's certification as a choice.
  function needTick(sh) {
    if (!sh.rule || question(sh).length) return [];
    const ppl = picked(sh).filter(p => !(p.info && p.info.years != null)).map(p => first(p.name));
    if (formSelf() || nameSelf()) ppl.unshift(first(state.me1.first) || '');
    return ppl;
  }
  function ruleAsk(sh) {
    const e = state.err.rule;
    if (question(sh).length) return '<fieldset class="vo-q"><legend class="vo-label">Certification</legend><span class="rf-seg" role="radiogroup">' + question(sh).map(x => '<label class="rf-tog"><input type="radio" name="question" value="' + esc(x) + '"' + (state.ans.question === x ? ' checked' : '') + (e ? ' aria-invalid="true"' : '') + '><span>' + I.check + esc(x) + '</span></label>').join('') + '</span>' + (e ? '<p class="vo-errline">' + I.alert + esc(e) + '</p>' : '') + '</fieldset>';
    const who = needTick(sh);
    if (!who.length) return '';
    const known = who.filter(Boolean), age = minAge(sh);
    const words = age ? age + ' or older' : sh.rule;
    const text = !known.length ? (age ? 'I’m ' + words : words) : known.length === 1 && !who[0] && who.length === 1 ? 'I’m ' + words : listAnd(known) + (known.length > 1 ? ' are ' : ' is ') + words;
    return '<label class="vo-claim' + (e ? ' is-bad' : '') + '"><input type="checkbox" name="rule"' + (state.ans.rule ? ' checked' : '') + (e ? ' aria-invalid="true"' : '') + '><span>' + esc(age ? text : sh.rule) + '</span></label>' + (e ? '<p class="vo-errline" role="alert">' + I.alert + esc(e) + '</p>' : '');
  }
  // Full: the waitlist (the first time, with who you are). A place offered for a swap: Take place.
  function waitBlock(sh, swapSeat) {
    if (waitsOn(sh).length) return '<p class="vo-full">On waitlist · Email when a place opens</p><p class="vo-mine__acts"><button type="button" class="vo-link" data-unwait="' + waitsOn(sh)[0].rid + '">Leave waitlist</button></p>';
    return '<div class="vo-who__h"><span class="vo-label">Full</span></div>' + (swapSeat ? '<p class="vo-full">' + esc((swapSeat.l && names() ? swapSeat.l : 'Someone') + ' is looking for a replacement') + '</p>' : '') +
      (!signed() ? selfBox(sh, true) : '') +
      '<div class="vo-who__foot">' + (state.footErr ? '<p class="vo-errline" role="alert">' + I.alert + esc(state.footErr) + '</p>' : '') + '<button type="button" class="vo-link" data-close="' + esc(sh.id) + '">Cancel</button>' +
      (swapSeat ? '<button type="button" class="wk-btn" data-take="' + esc(sh.id) + '">' + (state.busyAct === 'take' ? 'Taking…' : 'Take place') + '</button>' : '<button type="button" class="wk-btn" data-waitgo="' + esc(sh.id) + '"' + (state.busyAct ? ' disabled' : '') + '>' + (state.busyAct === 'wait' ? 'Joining…' : 'Join waitlist') + '</button>') + '</div>' +
      (swapSeat ? '' : '<p class="vo-help" style="text-align:right;margin-top:6px!important">Email when a place opens</p>');
  }
  function takeBlock(sh, swapSeat) {
    return '<div class="vo-who__h"><span class="vo-label">Take place</span></div><p class="vo-full">' + esc((swapSeat.l && names() ? swapSeat.l : 'Someone') + ' is looking for a replacement') + '</p>' +
      (!signed() ? selfBox(sh, true) : '') + ruleAsk(sh) +
      '<div class="vo-who__foot">' + (state.footErr ? '<p class="vo-errline" role="alert">' + I.alert + esc(state.footErr) + '</p>' : '') + '<button type="button" class="vo-link" data-close="' + esc(sh.id) + '">Cancel</button><button type="button" class="wk-btn" data-take="' + esc(sh.id) + '"' + (state.busyAct ? ' disabled' : '') + '>' + (state.busyAct === 'take' ? 'Taking…' : 'Take place') + '</button></div>';
  }

  // Unconfirmed: where the email went (in full: she typed it, and may have mistyped it), Resend and
  // Change email for as long as it's unconfirmed.
  function confirmHelp(ids, where) {
    const to = (me() && me().email) || '', h = +live().confirm_hours || 0;
    const ed = state.emailEdit === where;
    const box = ed ? '<form class="vol-chemail" data-emailform="' + esc(where) + '" data-ids="' + esc(ids.join(' ')) + '" novalidate><label class="vol-f' + (state.emailErr ? ' is-bad' : '') + '"><span>Email</span><input name="email" type="email" autocomplete="email" inputmode="email" value="' + esc(state.emailVal != null ? state.emailVal : to) + '"' + (state.emailErr ? ' aria-invalid="true"' : '') + '>' +
        (state.emailFix ? '<small class="vol-err">' + esc(domainOf(state.emailVal)) + '? · <button type="button" class="wk-linklike" data-emailfix>Use ' + esc(domainOf(state.emailFix)) + '</button> · <button type="button" class="wk-linklike" data-emailkeep>Keep</button></small>' : state.emailErr ? '<small class="vol-err">' + esc(state.emailErr) + '</small>' : '<small>The confirmation goes here</small>') + '</label>' +
        '<p class="vol-chemail__btns"><button type="submit" class="wk-btn wk-btn--small">Send</button> <button type="button" class="wk-linklike" data-emailoff>Cancel</button></p></form>' : '';
    return '<p class="vol-statehelp">Check your email' + (to ? ' · Sent to <b>' + esc(to) + '</b>' : '') + '<br>' +
      (ed ? '' : '<span class="vol-ctools"><button type="button" class="wk-linklike" data-resend="' + esc(ids.join(' ')) + '">Resend</button> · <button type="button" class="wk-linklike" data-chemail="' + esc(where) + '">Change email</button></span>') +
      (h > 0 ? '<br><small>Unconfirmed places open again after ' + h + ' hours</small>' : '') + '</p>' + box;
  }
  const domainOf = e => String(e || '').split('@')[1] || '';

  // Where the shift is, on the campus map; in the week (or a preview), Directions in the guide.
  function whereMap(p, test) {
    const c = state.campus, b = c && O.map && O.map.buildingFor && O.map.buildingFor(c, p, state.model.places);
    if (!b) return '';
    if (test) return true;
    const preview = q.get('preview') === '1';
    const guide = (W.base || '/annual-conference/') + 'guide/?year=' + encodeURIComponent(state.year) + '&view=places&to=' + encodeURIComponent(p.code) + (preview ? '&preview=1' : '');
    const marksB = [b.name].concat(c.items.filter(i => (i.kind === 'dining' || i.kind === 'worship') && i.name !== b.name).map(i => i.name));
    return (O.map.mini ? O.map.mini(c, p, state.model.places, isWeek() || preview ? { href: guide, hrefTitle: 'Directions' } : {}) : '<div class="vol-map">' + O.map.campusSvg(c, { mark: b.name, fit: marksB, small: true, aspect: 340 / 180, title: p.name + ' on the campus map' }) + '</div>');
  }

  /* ---------------------------------------------------------------- Your week */

  // The Conference's services, drawn faintly behind the shifts (kinds from the schedule's fixed list).
  const SVC = { worship: 'Worship', communion: 'Communion', council: 'Council', singing: 'Singing' };
  function services() {
    const out = [];
    state.model.days.forEach(d => (d.items || []).forEach(it => {
      if (!SVC[it.kind] || it.start == null || it.audience === 'preteens' || it.audience === 'youngfolks') return;
      out.push({ day: d, start: it.start, end: it.end != null ? it.end : it.start + 150, name: SVC[it.kind], title: it.title });
    }));
    return out;
  }
  // Whose week: the people with shifts (you first). Pills switch between them.
  function weekPeople() {
    const ppl = circle(), self = signed() ? ppl.find(p => p.self) : null;
    const withShifts = ppl.filter(p => mine().some(m => keyOfMine(m) === p.k));
    // A visitor's own shifts (not signed in): under the name they signed up with.
    if (!signed() && mine().length) { const n = selfName(); if (n) withShifts.unshift({ k: 'me', name: n, self: true }); }
    const out = [];
    if (self) out.push(self);
    withShifts.forEach(p => { if (!out.some(x => x.k === p.k)) out.push(p); });
    return out;
  }
  let calColW = 50;
  function weekCard(inSheet) {
    const ppl = weekPeople();
    const k = ppl.some(p => p.k === state.wk) ? state.wk : (ppl[0] || {}).k || '';
    const who = ppl.find(p => p.k === k);
    const shs = mine().filter(m => keyOfMine(m) === k).map(m => ({ m, sh: find(m.shift) })).filter(x => x.sh).sort((a, b) => sortKey(a.sh) - sortKey(b.sh));
    const pend = state.open ? find(state.open) : state.hover ? find(state.hover) : null;
    const pendShown = pend && !shs.some(x => x.sh === pend) ? pend : null;
    const clashW = pendShown && shs.find(x => overlaps(x.sh, pendShown));
    let h = '<div class="vo-card vo-wk"><div class="vo-wk__h"><h2' + (inSheet ? ' id="vo-wsheet-t"' : '') + '>Your week</h2><span class="vo-wk__sub">' + (shs.length ? esc(plural(shs.length, 'shift')) : '') + '</span></div>';
    if (ppl.length > 1) h += '<div class="vo-wkp" role="group" aria-label="Whose week">' + ppl.map(p => '<button type="button" data-wk="' + esc(p.k) + '" aria-pressed="' + (p.k === k) + '">' + I.check + esc(first(p.name)) + '</button>').join('') + '</div>';
    h += calendar(shs, pendShown, clashW);
    if (clashW) h += '<p class="vo-clash" role="status">' + esc((who ? first(who.name) + ' · ' : '') + busyWords(clashW.sh)) + '</p>';
    if (shs.length) {
      h += '<ul class="vo-wkl">' + shs.map(x => {
        const sh = x.sh, m = x.m, tags = [!m.confirmed ? 'Waiting to confirm' : '', m.swap ? 'Swap open' : ''].filter(Boolean);
        const asking = state.wkLeave === m.rid;
        const started = !ahead(sh);
        return '<li><div class="vo-wkl__r"><button type="button" class="vo-wkl__go" data-goto="' + esc(sh.id) + '"><span class="vo-wkl__d">' + esc(night(sh) ? dayWord(eve(sh)).slice(0, 3) + ' night' : O.fmtDate(eve(sh).date, 'weekdayShort') + ' ' + O.fmtDate(eve(sh).date, 'mdShort')) + '</span><b>' + esc(sh.role) + '</b><small>' + esc(span(sh) + (placeName(sh) ? ' · ' + placeName(sh) : '')) + '</small>' +
          (tags.length ? '<span class="vo-tagline">' + tags.map(t => '<span class="vo-tag">' + esc(t) + '</span>').join('') + '</span>' : '') + '</button>' +
          (started || asking ? '' : '<button type="button" class="vo-link" data-wkleave="' + m.rid + '" aria-label="' + esc('Leave ' + sh.role + ', ' + whenShort(sh) + (ppl.length > 1 ? ', ' + m.name : '')) + '">Leave</button>') + '</div>' +
          (asking ? '<div class="vo-ask"><p><b>Leave this shift?</b> The ' + esc(sh.committee) + ' head is told.</p><p class="vo-ask__btns"><button type="button" class="wk-btn wk-btn--line wk-btn--small" data-wkleavego="' + m.rid + '"' + (state.busyAct ? ' disabled' : '') + '>' + (state.busyAct === 'leave' ? 'Leaving…' : 'Leave shift') + '</button>' +
            ((isFull(sh) || open(sh) <= 1) && !m.swap ? '<button type="button" class="vo-link" data-wkswap="' + m.rid + '">Find replacement</button>' : '') + '<button type="button" class="vo-link" data-wkkeep>Keep</button></p></div>' : '') + '</li>';
      }).join('') + '</ul>';
    }
    const allShifts = uniq(mine().map(m => m.shift)).filter(find);
    if (allShifts.length) h += '<button type="button" class="wk-btn wk-btn--line wk-btn--wide" data-icsall>' + I.cal + 'Add to calendar</button>';
    // People added by email: their places are held until they answer.
    const added = mine().filter(m => m.added && !m.confirmed);
    if (added.length) {
      const byP = {};
      added.forEach(m => { const kk = keyOfMine(m); (byP[kk] = byP[kk] || { name: m.name, list: [] }).list.push(m); });
      h += '<div class="vo-wk__sec"><p class="vo-label">' + I.clock + 'Waiting to confirm</p>' + Object.values(byP).map(p => '<div class="vo-wi"><b>' + esc(p.name) + '</b>' + p.list.map(m => { const sh = find(m.shift); return sh ? '<small>' + esc(sh.role + ' · ' + whenShort(sh)) + '</small>' : ''; }).join('') +
        '<span class="vo-wi__acts"><small>Emailed · Confirm or Not me</small><button type="button" class="wk-linklike" data-resend="' + esc(p.list.map(m => m.rid).join(' ')) + '">Resend</button></span></div>').join('') + '</div>';
    }
    // Your own unconfirmed places (the first time): where the email went, Resend, Change email.
    const own = mine().filter(m => !m.added && !m.confirmed);
    if (own.length) h += '<div class="vo-wk__sec">' + confirmHelp(own.map(m => m.rid), 'week') + '</div>';
    const ws = (live().waits || []).filter(w => find(w.shift));
    if (ws.length) h += '<div class="vo-wk__sec"><p class="vo-label">' + I.mail + 'Waitlist</p>' + ws.map(w => { const sh = find(w.shift); return '<div class="vo-wi"><b>' + esc(sh.role) + '</b><small>' + esc(whenShort(sh)) + '</small><span class="vo-wi__acts"><button type="button" class="wk-linklike" data-unwait="' + w.rid + '">Leave waitlist</button></span></div>'; }).join('') + '</div>';
    // Show my name (one setting, on the server); someone you signed up has their own switch.
    if (allShifts.length && names()) {
      const self = selfRecs(), fors = uniq(mine().filter(x => x.for && !x.added && self.indexOf(x) < 0).map(x => x.name));
      const sw = (label, on, help, attr) => '<label class="vol-switch"><input type="checkbox" ' + attr + (on ? ' checked' : '') + '><span>' + esc(label) + '</span><small>' + esc(help) + '</small></label>';
      h += '<div class="vo-wk__set">' + (self.length ? sw('Show my name', self.every(x => !x.hide && (!x.for || x.shown)), self.some(x => !x.confirmed) ? 'Shows once you confirm' : 'As ' + SU.firstL(selfName() || 'First L.') + ' on shift lists', 'data-showname') : '') +
        fors.map(n => sw('Show ' + first(n) + '’s name', mine().some(x => x.name === n && x.shown), 'As ' + SU.firstL(n) + ' on shift lists', 'data-showname="' + esc(n) + '"')).join('') + '</div>';
    }
    return h + '</div>';
  }
  // The week as a small calendar: days across, hours down; services faint; this person's shifts in
  // tan; the shift being looked at dashed (red when it clashes). A name shows only where it fits whole.
  function calendar(shs, pend, clash) {
    const svcs = services();
    const all = shs.map(x => x.sh).concat(pend ? [pend] : []);
    const used = state.model.days.filter(d => svcs.some(s => s.day === d) || state.shifts.some(sh => eve(sh) === d));
    if (!used.length) return '';
    const at = sh => ({ col: used.indexOf(eve(sh)), s: night(sh) ? sh.start + 1440 : sh.start, e: night(sh) ? sh.end + 1440 : sh.end });
    let lo = 420, hi = 1440;
    svcs.forEach(s => { lo = Math.min(lo, s.start); hi = Math.max(hi, s.end); });
    all.forEach(sh => { const a = at(sh); lo = Math.min(lo, a.s); hi = Math.max(hi, a.e); });
    lo = Math.max(300, Math.floor(lo / 60) * 60); hi = Math.min(1560, Math.ceil(hi / 60) * 60);
    const HH = 17, y = m => (m - lo) / 60 * HH, H = (hi - lo) / 60 * HH;
    const block = (cls, s, e, label, title) => {
      const top = y(Math.max(s, lo)), hgt = Math.max(5, y(Math.min(e, hi)) - top - 1);
      const font = /is-svc/.test(cls) ? 'italic 9px ' + serif() : '600 9.5px ' + sans();
      const nl = label ? fitLines(label, calColW, font) : 0;
      return '<div class="vo-b ' + cls + '" style="top:' + top.toFixed(1) + 'px;height:' + hgt.toFixed(1) + 'px" title="' + esc(title) + '">' + (nl && nl * 11 + 3 <= hgt ? '<span class="vo-b__t">' + esc(label) + '</span>' : '') + '</div>';
    };
    const ticks = []; for (let m = Math.ceil(lo / 240) * 240; m <= hi; m += 240) if (m > lo) ticks.push(m);
    let h = '<div class="vo-cal" style="--vo-cols:' + used.length + ';--vo-hh:' + HH + '" aria-hidden="true"><span></span>' + used.map(d => '<div class="vo-cal__h"><b>' + esc(dayWord(d).slice(0, 3)) + '</b><span>' + esc(O.fmtDate(d.date, 'day')) + '</span></div>').join('');
    h += '<div class="vo-cal__ax" style="height:' + H + 'px">' + ticks.map(m => '<span style="top:' + y(m) + 'px">' + esc(O.formatTime(m, { compact: true }).replace(' ', '')) + '</span>').join('') + '</div>';
    used.forEach((d, col) => {
      h += '<div class="vo-cal__col" style="height:' + H + 'px">';
      svcs.filter(s => s.day === d).forEach(s => { h += block('is-svc', s.start, s.end, s.name, s.title + ' · ' + O.formatRange(s.start, s.end, { compact: true })); });
      shs.forEach(x => { const a = at(x.sh); if (a.col === col) h += block('is-mine' + (x.m.confirmed ? '' : ' is-wait'), a.s, a.e, x.sh.role, x.sh.role + ' · ' + span(x.sh)); });
      if (pend) { const a = at(pend); if (a.col === col) h += block('is-pend' + (clash ? ' is-clash' : ''), a.s, a.e, pend.role, pend.role + ' · ' + span(pend)); }
      h += '</div>';
    });
    return h + '</div>' + '<p class="ogc-sr">' + esc(shs.length ? shs.map(x => x.sh.role + ', ' + whenShort(x.sh)).join('; ') : 'No shifts yet') + '</p>';
  }
  const cssVar = (n, f) => { try { return getComputedStyle(document.documentElement).getPropertyValue(n).trim() || f; } catch (e) { return f; } };
  const serif = () => cssVar('--wk-serif', 'Georgia, serif') || 'Georgia, serif';
  const sans = () => cssVar('--wk-sans', 'Arial, sans-serif') || 'Arial, sans-serif';
  let ctx2d;
  const textW = (t, font) => { ctx2d = ctx2d || document.createElement('canvas').getContext('2d'); ctx2d.font = font; return ctx2d.measureText(t).width; };
  // How many lines a label takes in a width, never splitting a word (0: a word doesn't fit at all).
  function fitLines(t, w, font) {
    const words = String(t).split(' '), lines = [];
    let cur = '';
    for (const wd of words) {
      if (textW(wd, font) > w) return 0;
      const tryL = cur ? cur + ' ' + wd : wd;
      if (textW(tryL, font) <= w) cur = tryL; else { lines.push(cur); cur = wd; }
    }
    if (cur) lines.push(cur);
    return lines.length;
  }
  // After a draw: the room a label has in one day's column, measured; drawn again if it changed.
  function fitCal() {
    const col = Array.from(document.querySelectorAll('.vo-cal__col')).find(x => x.offsetWidth > 0);
    if (!col) return;
    const w = Math.floor(col.getBoundingClientRect().width - 6);
    if (w > 16 && Math.abs(w - calColW) > 1) { calColW = w; drawWeek(); }
  }
  // Only Your week again (a hover, the open row, whose week): the list keeps its focus and scroll.
  function drawWeek() {
    const a = root.querySelector('.vo-side');
    if (a) a.innerHTML = weekCard();
    if (wsheet.open) drawSheet();
  }

  /* ---------------------------------------------------------------- on a phone: a bar, and Your week as a sheet */

  const pbar = document.createElement('button');
  pbar.type = 'button';
  pbar.className = 'ogc vo-pbar';
  pbar.hidden = true;
  pbar.setAttribute('aria-haspopup', 'dialog');
  document.body.appendChild(pbar);
  function pbarDraw() {
    const on = showWeek();
    pbar.hidden = !on;
    document.body.classList.toggle('has-vo-pbar', on);
    if (!on) return;
    const n = uniq(mine().map(m => m.shift)).filter(find).length, w = mine().filter(m => m.added && !m.confirmed).length;
    pbar.innerHTML = '<span class="vo-pbar__t"><b>Your week' + I.up + '</b><small>' + esc(n ? plural(n, 'shift') : 'Services and shifts') + '</small></span>' + (w ? '<span class="vo-tag">' + I.clock + esc(w + ' waiting') + '</span>' : '');
    pbar.setAttribute('aria-label', 'Your week' + (n ? ', ' + plural(n, 'shift') : ''));
  }
  const wsheet = document.createElement('dialog');
  wsheet.className = 'ogc wk-sheet vo-wsheet';
  wsheet.setAttribute('aria-labelledby', 'vo-wsheet-t');
  document.body.appendChild(wsheet);
  function drawSheet() {
    const y = wsheet.scrollTop;
    wsheet.innerHTML = '<div class="wk-sheet__in vo"><button type="button" class="vo-wsheet__x" data-wclose aria-label="Close">' + I.close + '</button>' + weekCard(true) + '</div>';
    wsheet.scrollTop = y;
    fitCal();
  }
  pbar.addEventListener('click', () => { drawSheet(); wsheet.showModal(); wsheet.classList.add('is-in'); const x = wsheet.querySelector('[data-wclose]'); if (x) x.focus({ preventScroll: true }); });
  wsheet.addEventListener('click', e => {
    if (e.target === wsheet || e.target.closest('[data-wclose]')) { wsheet.close(); return; }
    onClick(e);
  });
  wsheet.addEventListener('change', onChange);
  wsheet.addEventListener('close', () => { wsheet.classList.remove('is-in'); pbar.focus({ preventScroll: true }); });

  /* ---------------------------------------------------------------- opening a row, choosing who */

  function openRow(id, o) {
    o = o || {};
    const sh = find(id);
    if (!sh) return;
    if (state.open === id && !o.keep) { closeRow(); return; }
    state.open = id; state.add = null; state.err = {}; state.footErr = ''; state.ans = {}; state.leaving = ''; state.leaveWho = null; state.mapOpen = '';
    // Yourself, ticked to start with, when nothing keeps you off it.
    const self = circle().find(p => p.self);
    state.pick = self && !whyNot(self, sh) ? ['me'] : vouched() ? circle().filter(p => !p.email && !whyNot(p, sh)).map(p => p.k) : [];
    state.pick = state.pick.concat(state.added.map(p => p.k).filter(k => state.pick.indexOf(k) < 0)).slice(0, Math.max(0, open(sh) - selfCount()));
    setUrl({ shift: id }, true);
    render();
    const r = document.getElementById('vo-r-' + id);
    if (r && !o.noScroll) {
      const b = r.getBoundingClientRect();
      if (b.top < 0 || b.bottom > innerHeight - 70) r.scrollIntoView({ block: b.height > innerHeight - 140 ? 'start' : 'center', behavior: matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth' });
    }
    const f = r && (r.querySelector('.vo-panel input:not(.vol-hp):not([type=checkbox]):not([type=radio])') || r.querySelector('.vo-panel [data-pick]:not([aria-disabled="true"])') || r.querySelector('.vo-panel button'));
    if (f && o.focus !== false) f.focus({ preventScroll: true });
    say.textContent = sh.role + ', ' + whenLong(sh) + ', ' + span(sh);
  }
  function closeRow(focusBack) {
    const id = state.open;
    state.open = ''; state.add = null; state.err = {}; state.footErr = ''; state.leaving = '';
    setUrl({ shift: '', swap: '' }, true);
    render();
    const b = id && root.querySelector('[data-open="' + CSS.escape(id) + '"]');
    if (b && focusBack !== false) b.focus({ preventScroll: true });
  }
  // A redraw that keeps the cursor where it was (a pill, a field).
  function redraw(sel) {
    const a = document.activeElement, keep = sel || (a && a !== document.body && root.contains(a) ? keyFor(a) : '');
    const pos = a && a.selectionStart != null ? [a.selectionStart, a.selectionEnd] : null;
    render();
    const x = keep && root.querySelector(keep);
    if (x) { x.focus({ preventScroll: true }); if (pos && x.setSelectionRange && x.type !== 'email') try { x.setSelectionRange(pos[0], pos[1]); } catch (e) { /* not a text field */ } }
  }
  function keyFor(el) {
    const ds = el.dataset || {};
    for (const k of ['pick', 'open', 'day', 'wk', 'signup', 'addopen', 'addsave', 'leave', 'leavego', 'close', 'hidefull']) if (k in ds) return '[data-' + k + (ds[k] ? '="' + CSS.escape(ds[k]) + '"' : '') + ']';
    if (el.name && el.dataset.f) return '[data-f="' + el.dataset.f + '"][name="' + el.name + '"]';
    if (el.name) return '[name="' + CSS.escape(el.name) + '"]' + (el.value && (el.type === 'radio' || el.type === 'checkbox') ? '[value="' + CSS.escape(el.value) + '"]' : '');
    return '';
  }
  function pick(k) {
    const sh = find(state.open), p = circle().find(x => x.k === k);
    if (!sh || !p || whyNot(p, sh)) return;
    const i = state.pick.indexOf(k);
    if (i > -1) state.pick.splice(i, 1);
    else if (pickN(sh) < open(sh)) state.pick.push(k);
    else { say.textContent = open(sh) + ' of ' + open(sh) + ' places chosen'; return; }
    delete state.err.rule; state.footErr = '';
    redraw('[data-pick="' + CSS.escape(k) + '"]');
    drawWeek();
  }
  const emailOk = e => /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(String(e || '').trim());
  const DOMAINS = { 'gmial.com': 'gmail.com', 'gmai.com': 'gmail.com', 'gmal.com': 'gmail.com', 'gmail.co': 'gmail.com', 'gnail.com': 'gmail.com', 'yaho.com': 'yahoo.com', 'yahooo.com': 'yahoo.com', 'hotmial.com': 'hotmail.com', 'outlok.com': 'outlook.com', 'aol.co': 'aol.com', 'icloud.co': 'icloud.com' };
  const typoFix = e => { const m = /^([^@\s]+)@([^@\s]+)$/.exec(String(e || '').trim()); return m && DOMAINS[m[2].toLowerCase()] ? m[1] + '@' + DOMAINS[m[2].toLowerCase()] : ''; };
  // A likely typo is asked once, at the field: "gmial.com? · Use gmail.com · Keep".
  const typoErr = (bag, e) => { const fix = typoFix(e); return fix && state.typoOk !== bag + ':' + e ? { text: domainOf(e) + '? Use ' + domainOf(fix), html: esc(domainOf(e)) + '? · <button type="button" class="wk-linklike" data-typo="' + bag + '">Use ' + esc(domainOf(fix)) + '</button> · <button type="button" class="wk-linklike" data-typokeep="' + bag + '">Keep</button>' } : null; };
  function addSave() {
    const sh = find(state.open), a = state.add || {}, e = {};
    const fn = String(a.first || '').trim(), ln = String(a.last || '').trim(), em = String(a.email || '').trim();
    if (!fn) e['add.first'] = 'Their first name';
    if (!ln) e['add.last'] = 'Their last name';
    if (!emailOk(em)) e['add.email'] = em ? 'Check the email' : 'Their email';
    else { const t = typoErr('add', em); if (t) e['add.email'] = t; }
    state.err = Object.assign({}, state.err, { 'add.first': '', 'add.last': '', 'add.email': '' }, e);
    Object.keys(state.err).forEach(k => { if (!state.err[k]) delete state.err[k]; });
    if (Object.keys(e).length) { redraw(); focusBad(); return; }
    const name = fn + ' ' + ln;
    // A person is their email and name (the same email as yours: someone under your email). Nothing
    // here looks anyone up.
    const same = low(em) === myEmail();
    const p = { k: same ? 'n:' + low(name) : 'e:' + low(em) + '|' + low(name), name, email: same ? '' : em, info: null };
    if (!circle().some(x => x.k === p.k)) state.added.push(p);
    if (sh && state.pick.indexOf(p.k) < 0 && !whyNot(p, sh) && pickN(sh) < open(sh)) state.pick.push(p.k);
    state.add = null;
    redraw('[data-pick="' + CSS.escape(p.k) + '"]');
    drawWeek();
    say.textContent = name + ' added';
  }
  function focusBad() {
    const x = root.querySelector('.vo-panel [aria-invalid="true"]');
    if (x) { x.focus({ preventScroll: true }); x.scrollIntoView({ block: 'center' }); }
  }

  /* ---------------------------------------------------------------- signing up */

  // What the server said no to, as a word and a next step.
  function refusal(r, sh) {
    const n = r.name ? first(r.name) + ' · ' : '';
    switch (r.status) {
      case 'full': return { msg: r.open ? plural(r.open, 'place') + ' left' : 'Just filled' };
      case 'busy': return { msg: n + 'Busy · ' + r.busy.role + (find(r.busy.shift) ? ' ' + span(find(r.busy.shift)) : '') };
      case 'minor': return { msg: n + 'Under ' + r.min_age };
      case 'rule': return { msg: minAge(sh) ? 'Confirm ' + minAge(sh) + ' or older' : 'Choose one', field: 'rule' };
      case 'screening': return { msg: 'Screening first', field: 'screened' };
      case 'dup': return { msg: n + 'Already signed up' };
      case 'started': return { msg: 'Started' };
      case 'ended': return { msg: 'Ended' };
      case 'closed': return { msg: 'Closed' };
      case 'not_open': return { msg: 'Not open yet' };
      case 'gone': return { msg: 'No longer offered' };
      default: return { msg: 'Not saved' };
    }
  }
  // Check here first (the server checks again): every error at its field, focus on the first.
  function check(sh, waiting) {
    const e = {}, m = state.me1 || {};
    // The waitlist and Take place ask who you are of anyone not signed in (an emailed link too).
    if (formSelf() || (waiting && !signed())) {
      if (!String(m.first || '').trim()) e['me1.first'] = 'Your first name';
      if (!String(m.last || '').trim()) e['me1.last'] = 'Your last name';
      if (!emailOk(m.email)) e['me1.email'] = String(m.email || '').trim() ? 'Check the email' : 'Your email';
      else { const t = typoErr('me1', String(m.email).trim()); if (t) e['me1.email'] = t; }
      if (String(m.phone || '').replace(/\D/g, '').length < 7) e['me1.phone'] = 'A phone number';
    } else if (nameSelf() && !waiting) {
      if (!String(m.first || '').trim()) e['me1.first'] = 'Your first name';
      if (!String(m.last || '').trim()) e['me1.last'] = 'Your last name';
    }
    if (!waiting) {
      if (signed() && !me().phone && (picked(sh).some(p => !p.email) || nameSelf()) && String(m.phone || '').replace(/\D/g, '').length < 7) e['me1.phone'] = 'A phone number';
      if (question(sh).length && !state.ans.question) e.rule = 'Choose one';
      else if (needTick(sh).length && !state.ans.rule) e.rule = minAge(sh) ? 'Confirm ' + minAge(sh) + ' or older' : 'Confirm the rule';
      if (screening(sh) && !state.ans.screened) e.screened = 'Choose one';
    }
    return e;
  }
  function joinBody(sh) {
    const m = state.me1 || {}, ppl = picked(sh);
    const b = { shifts: [sh.id], answers: {}, show: true };
    if (formSelf()) b.who = { first: String(m.first || '').trim(), last: String(m.last || '').trim(), email: String(m.email || '').trim(), phone: String(m.phone || '').trim() };
    else if (signed() && (nameSelf() || (!me().phone && m.phone))) b.who = { first: String(m.first || '').trim(), last: String(m.last || '').trim(), phone: String(m.phone || '').trim() };
    const same = ppl.filter(p => !p.email).map(p => p.name), adds = ppl.filter(p => p.email).map(p => ({ name: p.name, email: p.email }));
    // Signed in (or an emailed link): exactly the people ticked (perhaps only those added). The first
    // time: yourself, plus anyone added.
    if (!formSelf() && !nameSelf()) b.people = same;
    else if (nameSelf()) b.people = [String(m.first || '').trim() + ' ' + String(m.last || '').trim()].concat(same);
    if (adds.length) b.add = adds;
    if (question(sh).length) b.answers.question = state.ans.question;
    else if (sh.rule) b.answers.rule = true;
    if (state.ans.screened) b.answers.screened = state.ans.screened;
    if (state.ans.note) b.note = state.ans.note;
    if (m.hp) b.hp = m.hp;
    // An emailed link that vouches for the email goes with it (the server reads its token).
    if (vouched() && state.link.via) Object.assign(b, state.link.via);
    return b;
  }
  async function signUp(sh) {
    if (state.busyAct || !sh) return;
    const e = check(sh, false);
    if (!pickN(sh)) { state.footErr = 'Choose who'; redraw(); return; }
    state.err = e; state.footErr = '';
    if (Object.keys(e).length) { redraw(); focusBad(); say.textContent = Object.values(e).map(x => x.text || x).join('. '); return; }
    state.busyAct = 'join'; redraw('[data-signup]');
    let d;
    try { d = await post('vol/' + state.year + '/join', joinBody(sh)); }
    catch (err) {
      state.busyAct = '';
      if (err.data && err.data.why === 'fields') {
        const f = err.data.fields || {}, map = { first: 'me1.first', last: 'me1.last', email: 'me1.email', phone: 'me1.phone' };
        state.err = {}; Object.keys(f).forEach(k => { if (map[k]) state.err[map[k]] = f[k]; else state.footErr = f[k]; });
        redraw(); focusBad(); return;
      }
      state.footErr = err.status === 429 ? (err.data && err.data.why === 'confirm' ? 'Confirm your email first · The link is in your inbox' : 'Too many at once · Try later') : 'Not saved · Retry';
      redraw(); return;
    }
    state.busyAct = '';
    merge(d);
    const m = state.me1 || {};
    if (formSelf() && m.email) { tab.set('typed', { first: m.first, last: m.last, email: d.email || m.email }); tabPhone = m.phone || ''; }
    // Not signed in: the page learns who this device now holds places for (its hold), as on a reload.
    if (!signed() && d.hold) await loadLive().catch(() => {});
    const ok = d.results.filter(r => r.status === 'ok'), no = d.results.filter(r => r.status !== 'ok');
    if (ok.length) {
      const made = d.made || [], who = mine().filter(x => made.indexOf(x.rid) > -1);
      const waiting = who.filter(x => x.added && !x.confirmed).map(x => x.name);
      state.open = ''; state.pick = []; state.added = []; state.ans = {}; state.err = {}; state.footErr = ''; state.flash = sh.id;
      setUrl({ shift: '', swap: '' }, true);
      render();
      setTimeout(() => { if (state.flash === sh.id) { state.flash = ''; const r = document.getElementById('vo-r-' + sh.id); if (r) r.classList.remove('is-flash'); } }, 1700);
      showToast({ kind: 'ok', text: 'Signed up' + (who.length > 1 ? ' · ' + plural(who.length, 'person', 'people') : ''), sub: sh.role + ', ' + whenShort(sh) + (waiting.length ? ' · ' + listAnd(waiting) + ' · Waiting to confirm' : formSelf() || (!signed() && who.some(x => !x.confirmed)) ? ' · Check your email' : ''), ids: made, shifts: [sh.id] });
      say.textContent = 'Signed up · ' + sh.role + ', ' + whenLong(sh);
      const x = root.querySelector('[data-open="' + CSS.escape(sh.id) + '"]') || bar.querySelector('[data-undo]');
      if (x) x.focus({ preventScroll: true });
    } else if (no.length) {
      const r = no[0], why = refusal(r, find(r.shift) || sh);
      if (why.field) state.err[why.field] = why.msg; else state.footErr = why.msg;
      redraw(); say.textContent = why.msg;
    }
  }

  async function undo(ids) {
    try { merge(await post('vol/' + state.year + '/undo', { ids })); hideToast(); render(); say.textContent = 'Undone'; }
    catch (e) { showToast({ kind: 'error', text: 'Not undone · Leave instead' }); }
  }
  async function leave(ids, sh) {
    if (!ids.length) return;
    // A "Confirmed · 2 shifts" line from the email's link no longer holds once one is left.
    if (state.link && state.link.a === 'confirm') state.link = null;
    state.busyAct = 'leave'; redraw();
    try {
      merge(await post('vol/' + state.year + '/leave', { ids }));
      state.busyAct = ''; state.leaving = ''; state.wkLeave = 0; state.footErr = '';
      if (state.toast && (state.toast.ids || []).some(x => ids.indexOf(x) > -1)) hideToast();
      render();
      showToast({ kind: 'ok', text: 'Left shift', sub: sh ? sh.role + ', ' + whenShort(sh) : '' });
      say.textContent = 'Left shift';
    } catch (e) {
      state.busyAct = ''; state.footErr = e.data && e.data.why === 'started' ? 'Started · Call the head' : 'Not saved · Retry'; redraw();
      if (!state.leaving) showToast({ kind: 'error', text: state.footErr });
    }
  }
  async function waitFor(sh) {
    if (state.busyAct) return;
    if (!signed()) { const e = check(sh, true); state.err = e; if (Object.keys(e).length) { redraw(); focusBad(); return; } }
    state.busyAct = 'wait'; redraw();
    try {
      const b = { shift: sh.id }, m = state.me1 || {};
      if (!signed()) b.who = { first: m.first, last: m.last, email: m.email, phone: m.phone };
      const self = circle().find(p => p.self);
      if (signed() && self) b.people = [self.name];
      merge(await post('vol/' + state.year + '/wait', b));
      state.busyAct = ''; state.footErr = '';
      redraw();
      showToast({ kind: 'ok', text: 'On waitlist', sub: sh.role + ' · Email when a place opens' });
    } catch (e) {
      state.busyAct = '';
      if (e.data && e.data.why === 'fields') { const f = e.data.fields || {}; state.err = {}; Object.keys(f).forEach(k => { state.err['me1.' + k] = f[k]; }); redraw(); focusBad(); return; }
      state.footErr = 'Not saved · Retry'; redraw();
    }
  }
  // Find replacement: the place stays yours, marked Swap open; the link lets anyone take it at once.
  async function swap(rid, on, sh) {
    try {
      const d = await post('vol/' + state.year + '/swap', { id: rid, on });
      merge(d); state.leaving = ''; state.wkLeave = 0;
      await loadLive().catch(() => {});
      render();
      if (on && d.swap && sh) copyLink(swapUrl(sh, d.swap), 'Link copied', 'Could you take my place? ' + sh.role + ', ' + whenShort(sh));
    } catch (e) { showToast({ kind: 'error', text: 'Not saved · Retry' }); }
  }
  const swapUrl = (sh, token) => location.origin + location.pathname + '?year=' + state.year + '&shift=' + encodeURIComponent(sh.id) + '&swap=' + encodeURIComponent(token);
  async function take(sh) {
    if (state.busyAct) return;
    const seatSwap = seatsOf(sh).find(p => p.swap);
    const token = state.swap || q.get('swap') || (seatSwap ? seatSwap.swap + '.' : '');
    if (!signed()) { const e = check(sh, true); if (sh.rule && !question(sh).length && !state.ans.rule) e.rule = minAge(sh) ? 'Confirm ' + minAge(sh) + ' or older' : 'Confirm the rule'; state.err = e; if (Object.keys(e).length) { redraw(); focusBad(); return; } }
    state.busyAct = 'take'; redraw();
    try {
      const m = state.me1 || {};
      const d = await post('vol/' + state.year + '/take', { swap: String(token), who: signed() ? undefined : { first: m.first, last: m.last, email: m.email, phone: m.phone }, answers: { rule: true } });
      merge(d); state.busyAct = ''; state.swap = ''; state.open = ''; state.footErr = '';
      setUrl({ shift: '', swap: '' }, true);
      render();
      showToast({ kind: 'ok', text: 'Signed up', sub: sh.role + ', ' + whenShort(sh) });
    } catch (e) {
      state.busyAct = ''; state.footErr = e.data && e.data.why === 'busy' ? 'Busy · ' + e.data.busy.role : e.data && e.data.why === 'taken' ? 'Taken' : 'Not saved · Retry'; redraw();
    }
  }
  // Invite someone: a link to this shift, by the phone's own Share, or copied.
  function invite(id) {
    const sh = find(id), u = location.origin + location.pathname + '?year=' + state.year + '&shift=' + encodeURIComponent(id);
    copyLink(u, 'Link copied', minesOn(sh).length ? 'Join me: ' + sh.role + ', ' + whenShort(sh) + ' · ' + state.year + ' Annual Conference' : sh.role + ' · ' + whenShort(sh) + ' · ' + state.year + ' Annual Conference' + (open(sh) > 0 && open(sh) !== Infinity ? ' · ' + open(sh) + ' open' : ''));
  }
  function copyLink(url, done, text) {
    if (navigator.share && /Mobi|Android/i.test(navigator.userAgent)) { navigator.share({ text, url }).catch(() => {}); return; }
    const ok = () => { showToast({ kind: 'ok', text: done }); say.textContent = done; };
    const manual = () => showToast({ kind: 'ok', text: 'Link', sub: url });
    try { navigator.clipboard.writeText(url).then(ok, manual); } catch (e) { manual(); }
  }

  // Resend and Change email (an unconfirmed place keeps its seat; the confirmation goes to the new address).
  async function resend(ids) {
    try { const d = await post('vol/' + state.year + '/resend', { ids: ids.map(Number) }); showToast({ kind: 'ok', text: 'Sent', sub: d.email || '' }); }
    catch (e) { showToast({ kind: e.status === 429 ? 'ok' : 'error', text: e.status === 429 ? 'Sent · Just now' : 'Not sent · Retry' }); }
  }
  async function changeEmail(form, typosOk) {
    const val = form.email.value.trim(), ids = form.dataset.ids.split(' ').map(Number);
    state.emailVal = val; state.emailErr = ''; state.emailFix = '';
    if (!emailOk(val)) { state.emailErr = 'Enter your email'; return redrawEmail(); }
    try {
      const d = await post('vol/' + state.year + '/email', { ids, email: val, typos_ok: !!typosOk });
      merge(d);
      if (!signed()) tab.set('typed', Object.assign({}, tab.get('typed', {}), { email: d.email }));
      if (live().me) live().me.email = d.email;
      state.emailEdit = ''; state.emailVal = null;
      render();
      showToast({ kind: 'ok', text: 'Sent', sub: d.email });
    } catch (e) {
      if (e.data && e.data.why === 'typo') state.emailFix = e.data.fix;
      else state.emailErr = e.data && e.data.fields ? e.data.fields.email : e.status === 429 ? 'Too many at once · Try later' : 'Not saved · Retry';
      redrawEmail();
    }
  }
  function redrawEmail() {
    render();
    const x = document.querySelector('[data-emailform] input');
    if (x) x.focus();
  }

  /* ---------------------------------------------------------------- the toast */

  const bar = document.createElement('div');
  bar.className = 'ogc vol-toast';
  bar.setAttribute('role', 'status');
  bar.hidden = true;
  document.body.appendChild(bar);
  let toastTimer = 0;
  function showToast(t) {
    state.toast = t;
    clearTimeout(toastTimer);
    const undoBtn = t.ids && t.ids.length ? '<button type="button" class="vol-toast__b" data-undo>Undo</button>' : '';
    bar.classList.toggle('is-no', t.kind !== 'ok');
    bar.innerHTML = '<p>' + (t.kind === 'ok' ? I.check : I.alert) + '<span><b>' + esc(t.text) + '</b>' + (t.sub ? '<small>' + esc(t.sub) + '</small>' : '') + '</span></p>' + undoBtn +
      (t.retry ? '<button type="button" class="vol-toast__b" data-retry>Retry</button>' : '') +
      '<button type="button" class="vol-toast__x" data-dismiss aria-label="Close">' + I.close + '</button>';
    bar.hidden = false;
    document.body.classList.add('has-toast');
    document.body.style.setProperty('--vol-toast-h', bar.offsetHeight + 'px');
    // Undo stays two minutes, as long as the email waits (the server takes it back quietly until then).
    if (t.ids) toastTimer = setTimeout(() => { const u = bar.querySelector('[data-undo]'); if (u) u.remove(); }, 120000);
    else toastTimer = setTimeout(hideToast, 8000);
  }
  function hideToast() { bar.hidden = true; state.toast = null; document.body.classList.remove('has-toast'); }
  bar.addEventListener('click', e => {
    const b = e.target.closest('button');
    if (!b) return;
    const t = state.toast || {};
    if (b.hasAttribute('data-dismiss')) return hideToast();
    if (b.hasAttribute('data-undo')) return undo(t.ids);
    if (b.hasAttribute('data-retry') && t.retry) { hideToast(); return t.retry(); }
  });

  /* ---------------------------------------------------------------- calendar file */

  function downloadIcs(ids) {
    const evs = [], s = S();
    ids.map(find).filter(Boolean).forEach(sh => {
      const on = minesOn(sh);
      (on.length ? on : [{ name: '' }]).forEach(m => evs.push({
        // The sign-up's record id, as in the emails (never a name: calendar servers keep the UID).
        uid: 'ogc-vol-' + (m.rid || String(sh.id).toLowerCase().replace(/[^a-z0-9]+/g, '-')), date: sh.day.date, start: sh.start, end: sh.end,
        summary: sh.role + ' · ' + sh.committee + (on.length > 1 ? ' · ' + first(m.name) : ''),
        location: [placeName(sh), s.venue, s.city].filter(Boolean).join(', '),
        description: (sh.note ? sh.note + '\n' : '') + 'Your sign-ups: ' + location.origin + (W.base || '/annual-conference/') + 'register/?year=' + state.year + '&view=mine',
        remind: 'Tomorrow: ' + sh.role
      }));
    });
    const one = ids.length === 1 && find(ids[0]);
    SU.save(SU.ics(evs, tz()), 'text/calendar', one ? 'volunteer-' + one.role.toLowerCase().replace(/[^a-z0-9]+/g, '-') + '-' + one.day.date + '.ics' : 'volunteer-' + state.year + '.ics');
  }

  /* ---------------------------------------------------------------- the address */

  function setUrl(o, replace) {
    const u = new URL(location.href);
    ['committee', 'shift', 'view', 'swap', 't'].forEach(k => { if (k in o) { if (o[k]) u.searchParams.set(k, o[k]); else u.searchParams.delete(k); } });
    if (u.href !== location.href) history[replace ? 'replaceState' : 'pushState'](null, '', u);
  }
  window.addEventListener('popstate', () => {
    const p = new URLSearchParams(location.search);
    state.committee = p.get('committee') || (p.get('view') === 'all' ? '*' : '');
    state.open = '';
    const id = p.get('shift');
    if (id && find(id)) { state.committee = state.committee || find(id).committee; state.open = id; }
    render();
  });
  function pickCommittee(c) {
    state.committee = c; state.open = ''; state.add = null; state.pick = [];
    setUrl(c === '*' ? { committee: '', view: 'all', shift: '' } : { committee: c, view: '', shift: '' });
    render();
    window.scrollTo({ top: 0 });
    const h = root.querySelector('.vo-title');
    if (h) h.focus({ preventScroll: true });
    say.textContent = c === '*' ? 'All shifts' : c || 'Committees';
  }
  // A shift from Your week, an email or an Invite link: its committee, with its row open.
  function goShift(id) {
    const sh = find(id);
    if (!sh) return;
    if (wsheet.open) wsheet.close();
    if (state.committee !== '*' && state.committee !== sh.committee) { state.committee = sh.committee; setUrl({ committee: sh.committee, view: '' }); }
    const c = state.committee;
    if (state.day[c] && state.day[c] !== eve(sh).key) state.day[c] = '';
    if (isFull(sh) && !minesOn(sh).length) state.hideFull = false;
    state.open = '';
    openRow(id);
  }

  // Counts kept true while the page is open: on coming back to it. Only the numbers change; what's
  // being typed stays.
  async function refresh() {
    if (!state.model) return;
    try {
      await loadLive();
      const a = document.activeElement;
      if (a && a.matches && a.matches('input, textarea') && root.contains(a)) return;
      const y = scrollY;
      redraw();
      scrollTo(0, y);
    } catch (e) { /* the page stands as it was */ }
  }
  document.addEventListener('visibilitychange', () => { if (!document.hidden) refresh(); });

  /* ---------------------------------------------------------------- events */

  async function onClick(e) {
    const a = e.target.closest('[data-go]');
    if (a && !e.metaKey && !e.ctrlKey) { e.preventDefault(); pickCommittee(a.dataset.go); return; }
    const b = e.target.closest('button');
    if (!b) return;
    const ds = b.dataset;
    if (emailClick(b)) return;
    if ('open' in ds) openRow(ds.open);
    else if ('pick' in ds) { if (b.getAttribute('aria-disabled') !== 'true') pick(ds.pick); }
    else if ('addopen' in ds) { const sh = find(state.open); if (sh && pickN(sh) >= open(sh)) { say.textContent = open(sh) + ' of ' + open(sh) + ' places chosen'; } state.add = {}; redraw('[data-f="add"][name="first"]'); }
    else if ('addcancel' in ds) { state.add = null; ['add.first', 'add.last', 'add.email'].forEach(k => delete state.err[k]); redraw('[data-addopen]'); }
    else if ('addsave' in ds) addSave();
    else if ('signup' in ds) signUp(find(ds.signup));
    else if ('close' in ds) closeRow();
    else if ('day' in ds) { state.day[state.committee] = ds.day; kept.set('day-' + state.year + '-' + state.committee, ds.day); redraw('[data-day="' + CSS.escape(ds.day) + '"]'); say.textContent = b.title || b.textContent; }
    else if ('hidefull' in ds) { state.hideFull = !state.hideFull; redraw('[data-hidefull]'); }
    else if ('wk' in ds) { state.wk = ds.wk; drawWeek(); const x = document.querySelector((wsheet.open ? '.vo-wsheet' : '.vo-side') + ' [data-wk="' + CSS.escape(ds.wk) + '"]'); if (x) x.focus(); }
    else if ('goto' in ds) goShift(ds.goto);
    else if ('leave' in ds) { state.leaving = ds.leave; state.leaveWho = null; state.footErr = ''; redraw('[data-leavego]'); }
    else if ('leavekeep' in ds) { state.leaving = ''; redraw('[data-leave="' + CSS.escape(ds.leavekeep) + '"]'); }
    else if ('leavego' in ds) { const sh = find(ds.leavego), box = root.querySelectorAll('[name=leavewho]'); leave(box.length ? Array.from(box).filter(x => x.checked).map(x => +x.value) : minesOn(sh).map(m => m.rid), sh); }
    else if ('swapon' in ds) { const sh = find(ds.swapon), m = minesOn(sh)[0]; if (m) swap(m.rid, true, sh); }
    else if ('swapoff' in ds) swap(+ds.swapoff, false, find(state.open));
    else if ('swapcopy' in ds) { const sh = find(state.open); if (sh) copyLink(swapUrl(sh, ds.swapcopy), 'Link copied', 'Could you take my place? ' + sh.role + ', ' + whenShort(sh)); }
    else if ('wkleave' in ds) { state.wkLeave = +ds.wkleave; drawWeek(); const x = document.querySelector('[data-wkleavego="' + ds.wkleave + '"]'); if (x) x.focus(); }
    else if ('wkkeep' in ds) { state.wkLeave = 0; drawWeek(); }
    else if ('wkleavego' in ds) { const m = mine().find(x => x.rid === +ds.wkleavego); leave([+ds.wkleavego], m && find(m.shift)); }
    else if ('wkswap' in ds) { const m = mine().find(x => x.rid === +ds.wkswap); if (m) swap(m.rid, true, find(m.shift)); }
    else if ('ics' in ds) downloadIcs([ds.ics]);
    else if ('icsall' in ds) downloadIcs(uniq(mine().map(m => m.shift)));
    else if ('waitgo' in ds) waitFor(find(ds.waitgo));
    else if ('unwait' in ds) { try { merge(await post('vol/' + state.year + '/unwait', { ids: [+ds.unwait] })); render(); say.textContent = 'Off the waitlist'; } catch (x) { showToast({ kind: 'error', text: 'Not saved' }); } }
    else if ('take' in ds) take(find(ds.take));
    else if ('invite' in ds) invite(ds.invite);
    else if ('map' in ds) { state.mapOpen = state.mapOpen === ds.map ? '' : ds.map; redraw('[data-map="' + CSS.escape(ds.map) + '"]'); }
    else if ('typo' in ds) { const bag = ds.typo, v = state[bag] || {}; v.email = typoFix(v.email) || v.email; delete state.err[bag + '.email']; if (bag === 'add') addSave(); else redraw('[data-f="' + bag + '"][name="email"]'); }
    else if ('typokeep' in ds) { const bag = ds.typokeep, v = state[bag] || {}; state.typoOk = bag + ':' + String(v.email || '').trim(); delete state.err[bag + '.email']; if (bag === 'add') addSave(); else redraw(); }
    else if ('signout' in ds) { tab.del('hold-' + state.year); tab.del('typed'); SU.signOut(); }
    else if ('forget' in ds) forgetMe();
    else if ('linkleave' in ds) linkLeave();
    else if ('linkswap' in ds) linkSwap();
    else if ('linkswapcopy' in ds) { const r = (state.link.records || [])[0], sh = r && find(r.shift); if (sh) copyLink(swapUrl(sh, state.link.swap), 'Link copied', 'Could you take my place? ' + sh.role + ', ' + whenShort(sh)); }
    else if ('linkkeep' in ds) { state.link = null; render(); }
    else if ('linkjoin' in ds) linkJoin();
    else if ('linkunwait' in ds) linkUnwait();
  }
  function emailClick(b) {
    const ds = b.dataset;
    if (ds.resend) { resend(ds.resend.split(' ')); return true; }
    if (ds.chemail) { state.emailEdit = ds.chemail; state.emailVal = null; state.emailErr = ''; state.emailFix = ''; redrawEmail(); return true; }
    if (b.hasAttribute('data-emailoff')) { state.emailEdit = ''; render(); return true; }
    if (b.hasAttribute('data-emailfix')) { const f = b.closest('form'); f.email.value = state.emailVal.split('@')[0] + '@' + domainOf(state.emailFix); changeEmail(f, true); return true; }
    if (b.hasAttribute('data-emailkeep')) { changeEmail(b.closest('form'), true); return true; }
    return false;
  }
  function onChange(e) {
    const t = e.target;
    if (t.matches('[name=rule]')) { state.ans.rule = t.checked; delete state.err.rule; redraw('[name=rule]'); }
    else if (t.matches('[name=question]')) { state.ans.question = t.value; delete state.err.rule; redraw(); }
    else if (t.matches('[name=screened]')) { state.ans.screened = t.value; delete state.err.screened; redraw(); }
    else if (t.matches('[name=leavewho]')) state.leaveWho = Array.from(document.querySelectorAll('[name=leavewho]:checked')).map(x => +x.value);
    else if (t.matches('[data-showname]')) setMe(t.dataset.showname ? { show: t.checked, name: t.dataset.showname } : { show: t.checked });
    else if (t.matches('[data-nextyear]')) setMe({ next_year: t.checked });
  }
  root.addEventListener('click', onClick);
  root.addEventListener('change', onChange);
  root.addEventListener('input', e => {
    const t = e.target, f = t.dataset && t.dataset.f;
    if (!f) return;
    state[f] = state[f] || {};
    state[f][t.name] = t.value;
    // An error goes as soon as the field is changed; the rule's claim follows the first name.
    if (state.err[f + '.' + t.name]) { delete state.err[f + '.' + t.name]; const box = t.closest('.vo-in'); if (box) { box.classList.remove('is-bad'); t.removeAttribute('aria-invalid'); const sm = box.querySelector('small:not(.is-help)'); if (sm) sm.remove(); } }
  });
  root.addEventListener('toggle', e => { if (e.target.matches && e.target.matches('[data-notefld]')) state.ans.noteOpen = e.target.open; }, true);
  root.addEventListener('keydown', e => {
    if (e.key === 'Enter' && e.target.matches && e.target.matches('[data-f="add"]')) { e.preventDefault(); addSave(); }
    else if (e.key === 'Enter' && e.target.matches && e.target.matches('[data-f="me1"], [data-f="ans"]') && state.open) { e.preventDefault(); const sh = find(state.open); if (sh && isFull(sh)) waitFor(sh); else signUp(sh); }
    else if (e.key === 'Escape' && state.open && !wsheet.open) { e.preventDefault(); closeRow(); }
  });
  // On a laptop, the shift under the pointer shows in Your week (dashed), red if it clashes.
  root.addEventListener('mouseover', e => {
    if (state.open) return;
    const r = e.target.closest('[data-row]'), id = r ? r.dataset.row : '';
    if (id !== state.hover && matchMedia('(min-width: 1100px)').matches) { state.hover = id; drawWeek(); }
  });
  root.addEventListener('submit', async e => {
    e.preventDefault();
    const f = e.target;
    if (f.matches('[data-emailform]')) changeEmail(f);
    else if (f.matches('[data-phoneform]')) {
      const v = f.phone.value.trim();
      if (v.replace(/\D/g, '').length < 7) { state.err.cphone = 'A phone number'; render(); const x = root.querySelector('[data-phoneform] input'); if (x) x.focus(); return; }
      try { merge(await post('vol/' + state.year + '/me', { phone: v })); delete state.err.cphone; if (live().me) live().me.phone = v; state.link.phoneSaved = true; render(); say.textContent = 'Phone saved'; }
      catch (x) { state.err.cphone = 'Not saved · Retry'; render(); }
    } else if (f.matches('[data-notify]')) {
      const em = f.email ? f.email.value.trim() : '';
      const err = f.querySelector('.vol-err');
      if (f.email && !emailOk(em)) { err.hidden = false; err.textContent = 'Enter your email'; f.email.setAttribute('aria-invalid', 'true'); f.email.focus(); return; }
      const ny = f.dataset.notify || state.year;
      try { await post('vol/' + ny + '/notify', { email: em, hp: f.hp.value }); kept.set('asked-' + ny, true); render(); say.textContent = 'We’ll email you'; } catch (x) { if (err) { err.hidden = false; err.textContent = 'Not saved · Retry'; } }
    }
  });

  async function setMe(o) {
    try { merge(await post('vol/' + state.year + '/me', o)); if (state.live.me && !o.name) Object.assign(state.live.me, o); redraw(); say.textContent = o.show != null ? (o.show ? 'Name shown' : 'Name hidden') : o.next_year ? 'We’ll email you next year' : 'Off'; }
    catch (x) { showToast({ kind: 'error', text: 'Not saved' }); }
  }

  // Emailed links.
  async function linkLeave() {
    const k = state.link;
    try { const d = await post('vol/' + state.year + '/leave', Object.assign({ ids: (k.records || []).map(r => r.rid) }, k.via)); merge(d); k.left = true; await refresh(); render(); }
    catch (x) { showToast({ kind: 'error', text: x.data && x.data.why === 'started' ? 'Started · Call the head' : 'Not saved' }); }
  }
  async function linkSwap() {
    const k = state.link, r = (k.records || [])[0];
    if (!r) return;
    try { const d = await post('vol/' + state.year + '/swap', Object.assign({ id: r.rid, on: true }, k.via)); k.swap = d.swap; render(); const sh = find(r.shift); if (sh && d.swap) copyLink(swapUrl(sh, d.swap), 'Link copied', 'Could you take my place? ' + sh.role + ', ' + whenShort(sh)); }
    catch (x) { showToast({ kind: 'error', text: 'Not saved · Retry' }); }
  }
  async function linkJoin() {
    const k = state.link, shs = (k.shifts || []).map(find).filter(Boolean);
    if (!shs.length) return;
    // A rule to answer, or no names: the shift's own row, open.
    if (shs.some(sh => sh.rule || screening(sh)) || !(k.names || []).length) { goShift(shs[0].id); return; }
    try {
      const d = await post('vol/' + state.year + '/join', Object.assign({ shifts: shs.map(s => s.id), people: k.names, show: true }, k.via));
      merge(d); const ok = d.results.filter(r => r.status === 'ok').length; k.done = true; render();
      const r = d.results.find(x => x.status !== 'ok');
      showToast({ kind: ok ? 'ok' : 'no', text: ok ? 'Signed up · ' + plural(ok, 'shift') : r && r.status === 'full' ? 'Taken · Still on waitlist' : refusal(r || {}, shs[0]).msg });
    } catch (x) { showToast({ kind: 'error', text: 'Not saved', retry: linkJoin }); }
  }
  async function linkUnwait() {
    try { const d = await post('vol/' + state.year + '/link', Object.assign({ do: 'unwait' }, state.link.via)); state.link = Object.assign(state.link, d); await refresh(); render(); }
    catch (x) { showToast({ kind: 'error', text: 'Not saved · Retry' }); }
  }

  let resizeT = 0;
  window.addEventListener('resize', () => { clearTimeout(resizeT); resizeT = setTimeout(fitCal, 150); });

  /* ---------------------------------------------------------------- boot */

  (O.ready || Promise.resolve()).then(() => fetch(BASE + 'years.csv', { cache: 'no-store' })).then(r => r.text()).then(async text => {
    const years = O.csvToObjects(text).filter(y => y.year).sort((a, b) => b.year - a.year);
    state.years = years;
    state.row = years.find(y => y.year === String(state.year)) || years.find(y => y.data) || years[0];
    state.year = state.row.year;
    if (!state.row.data) {
      // A year with no shifts yet (2028): its own name and hosts, Not posted yet.
      state.model = { settings: {}, days: [], tz: 'America/Indiana/Indianapolis' };
      try { await loadLive(); } catch (e) { state.live = null; }
      state.shifts = [];
      return render();
    }
    const folder = BASE + state.row.data + '/';
    state.model = await O.loadSchedule(folder);
    const shiftsText = await fetch(folder + 'shifts.csv', { cache: 'no-store' }).then(r => r.ok ? r.text() : '');
    state.shifts = SU.expandShifts(O.csvToObjects(shiftsText), state.model);
    if (O.map) {
      const campusText = await fetch(folder + 'campus.csv', { cache: 'no-store' }).then(r => r.ok ? r.text() : '').catch(() => '');
      const c = O.map.campus(O.csvToObjects(campusText));
      state.campus = c.items.length ? c : null;
    }
    // An emailed link: the server put its token in a short cookie and opened this clean address
    // (?link=1), so the token is never in the address bar. What it is, answered before the page is
    // drawn; then ?link (or an old ?t=) leaves the address at once.
    const t = q.get('t'), via = t ? { t } : q.get('link') ? { link: 1 } : null;
    if (via) {
      try { state.link = Object.assign({ via }, await call('POST', 'vol/' + state.year + '/link', via).catch(async e => { if (e.status === 403) { await loadLive(); return post('vol/' + state.year + '/link', via); } throw e; })); } catch (e) { state.link = { error: true }; }
      const u = new URL(location.href); u.searchParams.delete('t'); u.searchParams.delete('link'); history.replaceState(null, '', u);
    }
    // Said once: the address loses ?confirmed= (a reload never repeats "2 shifts").
    if (q.get('confirmed') != null) {
      state.link = { a: 'confirm', n: +q.get('confirmed') };
      const u = new URL(location.href); u.searchParams.delete('confirmed'); history.replaceState(null, '', u);
    }
    await loadLive();
    const id = q.get('shift');
    if (id && find(id)) {
      const sh = find(id);
      if (!state.committee || (state.committee !== '*' && state.committee !== sh.committee)) state.committee = sh.committee;
      if (isFull(sh) && !minesOn(sh).length) state.hideFull = false;
      state.day[state.committee] = '';
      render();
      openRow(id, { keep: true, focus: false });
      return;
    }
    render();
  }).catch(err => {
    console.error(err);
    root.removeAttribute('aria-busy');
    const m = root.querySelector('.wk-main .wk-wrap') || root;
    m.innerHTML = '<section class="vol-blank"><h2 class="vol-blank__h">Couldn’t load</h2><p><button type="button" class="wk-btn wk-btn--line wk-btn--small" onclick="location.reload()">Retry</button></p></section>';
  });
})();
