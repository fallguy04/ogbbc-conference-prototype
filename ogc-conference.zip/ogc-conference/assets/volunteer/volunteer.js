/*
 * volunteer.js — volunteering at the Annual Conference, on our own site (replacing SignUpGenius).
 * Anyone, any time; it isn't part of registering.
 *
 * Oct 8 (Michael): SignUpGenius showed the jobs by category and who had signed up ("I want to sign up
 * with these people"), and its replacement should be "so much superior". Oct 10: rebuilt on the server
 * (module-volunteer*.php). Every count, name and "you" comes from GET vol/{year} (never cached), and
 * every Join waits for the server's answer: "Signed up" is shown only when it's true.
 *
 *   (default)      the committees as cards; Days: every shift, a day at a time
 *   ?committee=…   one committee: its jobs, then its week (a grid on a laptop, a day at a time on a phone)
 *   ?shift=…       a shift's sheet: when, where, who, and the one action for its state in a bar
 *   ?view=lead     Who's signed up: a committee's list for its heads and the year's members
 *   ?link=1        an emailed link (confirm, not me, leave, a place opened, sign up again): the server
 *                  moved its opaque token into a short cookie, so the address never carries it
 *   ?swap=…        a place offered for a swap (Take place)
 *
 * Names show as "Ruth K." (the site's convention), or only how many when the COA chooses. Someone not
 * signed in joins with their name, email and phone; nothing signs them in: the emailed link does.
 */
(function () {
  'use strict';
  const O = window.OGC, esc = O.esc, SU = O.signups, W = window.OGC_WP || {};
  const root = document.getElementById('ogc-vol');
  if (!root) return;
  const BASE = root.dataset.base;
  const q = new URLSearchParams(location.search);

  const svg = d => '<svg class="wk-i" viewBox="0 0 24 24" aria-hidden="true"><path d="' + d + '" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  const I = {
    cal: svg('M7.5 3.5v3M16.5 3.5v3M4 9.5h16M5.5 5.5h13A1.5 1.5 0 0 1 20 7v11.5a1.5 1.5 0 0 1-1.5 1.5h-13A1.5 1.5 0 0 1 4 18.5V7a1.5 1.5 0 0 1 1.5-1.5Z'),
    pin: svg('M12 20.5s-6.5-5.4-6.5-10.8a6.5 6.5 0 0 1 13 0c0 5.4-6.5 10.8-6.5 10.8ZM12 12a2.3 2.3 0 1 0 0-4.6 2.3 2.3 0 0 0 0 4.6Z'),
    check: svg('m5.5 12.5 4 4 9-9'),
    close: svg('m6.5 6.5 11 11M17.5 6.5l-11 11'),
    mail: svg('M4 6.5h16v11H4zM4.5 7l7.5 6 7.5-6'),
    down: svg('M12 4v10.5M7.5 10 12 14.5 16.5 10M5 19.5h14'),
    print: svg('M7 9V4h10v5M7 17H5a1.5 1.5 0 0 1-1.5-1.5v-5A1.5 1.5 0 0 1 5 9h14a1.5 1.5 0 0 1 1.5 1.5v5A1.5 1.5 0 0 1 19 17h-2M7 14h10v6H7z'),
    back: svg('M14.5 5.5 8 12l6.5 6.5'),
    go: svg('m9.5 5.5 6.5 6.5-6.5 6.5'),
    link: svg('M10 14a4 4 0 0 0 5.66 0l3-3a4 4 0 0 0-5.66-5.66l-1 1M14 10a4 4 0 0 0-5.66 0l-3 3a4 4 0 0 0 5.66 5.66l1-1'),
    rule: svg('M12 3.5 4.5 6.5v5c0 4.5 3.2 7.8 7.5 9 4.3-1.2 7.5-4.5 7.5-9v-5L12 3.5ZM9 12l2 2 4-4'),
    phone: svg('M6.5 3.5h3l1.5 4-2 1.5a11 11 0 0 0 6 6l1.5-2 4 1.5v3a2 2 0 0 1-2 2A16 16 0 0 1 4.5 5.5a2 2 0 0 1 2-2Z'),
    plus: svg('M12 5v14M5 12h14'),
    search: svg('M10.5 17a6.5 6.5 0 1 0 0-13 6.5 6.5 0 0 0 0 13ZM15.5 15.5 20 20'),
    down2: svg('m6 9.5 6 6 6-6'),
    alert: svg('M12 7.5v5.5M12 16.5v.01M12 20.5a8.5 8.5 0 1 0 0-17 8.5 8.5 0 0 0 0 17Z'),
    more: '<svg class="wk-i" viewBox="0 0 24 24" aria-hidden="true"><circle cx="5.5" cy="12" r="1.7" fill="currentColor"/><circle cx="12" cy="12" r="1.7" fill="currentColor"/><circle cx="18.5" cy="12" r="1.7" fill="currentColor"/></svg>'
  };
  // Each committee's own sign, by its name (any the COA adds gets the raised hand).
  const HAND = 'M8 11V5.5a1.5 1.5 0 0 1 3 0V11M11 10V4.5a1.5 1.5 0 0 1 3 0V11M14 10.5V6a1.5 1.5 0 0 1 3 0v7.5a6 6 0 0 1-6 6h-.6a6 6 0 0 1-4.6-2.2L3.6 14.6a1.5 1.5 0 0 1 2.2-2L8 14.5V11';
  const MARKS = [
    [/transport|golf|cart|parking/i, 'M6 5.5h11M7 5.5v6M16 5.5v6M4.5 11.5h15v4h-15zM7.5 19a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3ZM16.5 19a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3Z'],
    [/dining|food|kitchen|meal/i, 'M7.5 3.5v6.5M5.5 3.5V8a2 2 0 0 0 4 0V3.5M7.5 10v10.5M16.5 20.5v-17c-2 1.2-3 3.6-3 7v3h3'],
    [/usher/i, 'M6.5 20.5v-16h11v16M4 20.5h16M14.5 12.5v.01'],
    [/first aid|medical|nurse/i, 'M12 8.5v7M8.5 12h7M6 4.5h12A1.5 1.5 0 0 1 19.5 6v12a1.5 1.5 0 0 1-1.5 1.5H6A1.5 1.5 0 0 1 4.5 18V6A1.5 1.5 0 0 1 6 4.5Z'],
    [/preteen|child|nursery/i, 'M8 7.5a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5ZM4 20.5v-6.5a4 4 0 0 1 8 0v6.5M17 11.5a2 2 0 1 0 0-4 2 2 0 0 0 0 4ZM14.5 20.5v-4.5a2.5 2.5 0 0 1 5 0v4.5'],
    [/young folk/i, 'M9 11a3.4 3.4 0 1 0 0-6.8A3.4 3.4 0 0 0 9 11ZM3 19.5c.6-3.3 3-5.2 6-5.2s5.4 1.9 6 5.2M15.8 4.5a3.2 3.2 0 0 1 0 6.2M17.6 14.6c1.8.7 3 2.3 3.4 4.9'],
    [/communion/i, 'M7.5 3.5h9l-.8 5.5a3.7 3.7 0 0 1-7.4 0L7.5 3.5ZM12 12.8v6.2M8.5 20h7'],
    [/kit|pack/i, 'M3.5 7.5 12 3.5l8.5 4v9L12 20.5l-8.5-4zM3.5 7.5l8.5 4 8.5-4M12 11.5v9'],
    [/lodging|desk|registration/i, 'M8 11.5a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7ZM10.5 10.5l9 9M16.5 16.5l2-2M14 14l1.5-1.5']
  ];
  const mark = c => svg((MARKS.find(m => m[0].test(c)) || [0, HAND])[1]);

  // Your sign-ups holds "my" shifts with everything else.
  if (q.get('view') === 'mine') { location.replace((W.base || '/annual-conference/') + 'register/?view=mine' + (q.get('year') ? '&year=' + encodeURIComponent(q.get('year')) : '')); return; }

  const state = {
    year: root.dataset.year || q.get('year') || '', row: null, model: null, shifts: [], live: null, campus: null,
    committee: q.get('committee') || '', by: q.get('by') || '', view: q.get('view') || '', day: '', openOnly: false,
    sheet: '', form: null, busyAct: '', leaving: '', done: null, toast: null, lead: null, link: null, swap: q.get('swap') || ''
  };
  const say = document.createElement('p');
  say.className = 'ogc-sr';
  say.setAttribute('aria-live', 'polite');
  root.after(say);

  /* ---------------------------------------------------------------- per-viewer conveniences (this browser) */

  const kept = {
    get(k, f) { try { const v = JSON.parse(localStorage.getItem('ogc-vol-' + k)); return v == null ? f : v; } catch (e) { return f; } },
    set(k, v) { try { localStorage.setItem('ogc-vol-' + k, JSON.stringify(v)); } catch (e) { /* not kept */ } }
  };
  // What a visitor typed, and the hold on what they just joined, live only in this tab (sessionStorage):
  // the Information Center's tablet, a family computer or the church office never fills in, or shows,
  // the last person's name, email and shifts. (Earlier builds kept them in localStorage: cleared here.)
  const tab = {
    get(k, f) { try { const v = JSON.parse(sessionStorage.getItem('ogc-vol-' + k)); return v == null ? f : v; } catch (e) { return f; } },
    set(k, v) { try { sessionStorage.setItem('ogc-vol-' + k, JSON.stringify(v)); } catch (e) { /* not kept */ } },
    del(k) { try { sessionStorage.removeItem('ogc-vol-' + k); } catch (e) { /* nothing kept */ } }
  };
  try { Object.keys(localStorage).filter(k => /^ogc-vol-(typed|hold-)/.test(k)).forEach(k => localStorage.removeItem(k)); } catch (e) { /* nothing kept */ }
  // Sign-ups made in this tab by someone not signed in: a short-lived hold from the server for just
  // those (Leave, Add to calendar, Resend). The records are on the server; this is only the key to them.
  const holds = () => tab.get('hold-' + state.year, []).filter(Boolean).slice(-10);
  const addHold = t => { if (t) tab.set('hold-' + state.year, holds().concat(t).slice(-10)); };
  // The name and email typed for this tab's own sign-ups (never the phone), while its hold lasts.
  const typed = () => holds().length ? tab.get('typed', {}) : {};
  // The phone typed for this tab's last sign-up, kept only in this page's memory (never in storage),
  // so a second shift in the same visit doesn't ask for it again.
  let tabPhone = '';
  // Not you? This tab forgets what was typed and held, and the server forgets this device's link.
  async function forgetMe() {
    tab.del('hold-' + state.year); tab.del('typed'); tabPhone = '';
    if (!signed()) { try { await post('vol/' + state.year + '/forget', {}); } catch (e) { /* still forgotten here */ } }
    state.form = null; state.done = null;
    await loadLive().catch(() => {});
    render();
    say.textContent = 'Signed out';
  }

  /* ---------------------------------------------------------------- the server */

  const asOf = () => { const a = O.parseAsOf(q.get('as-of')); return a && W.dev ? Math.round(O.wallToInstant(a.date, a.minutes, tz()).getTime() / 1000) : 0; };
  const tz = () => (state.model && state.model.tz) || 'America/Indiana/Indianapolis';
  async function call(method, path, body) {
    // A visitor's read carries no nonce (a stale one would be refused even for the public counts).
    const h = (W.me || method !== 'GET') && W.nonce ? { 'X-WP-Nonce': W.nonce } : {};
    const hs = holds();
    if (hs.length) h['X-OGC-Hold'] = hs.join(',');
    if (asOf()) h['X-OGC-Now'] = String(asOf());
    if (body !== undefined) h['Content-Type'] = 'application/json';
    const res = await fetch((W.rest || '/wp-json/ogc/v1/') + path, { method, credentials: 'same-origin', headers: h, body: body === undefined ? undefined : JSON.stringify(body) });
    const fresh = res.headers.get('X-WP-Nonce');
    if (fresh) W.nonce = fresh;
    const type = res.headers.get('Content-Type') || '';
    const data = /json/.test(type) ? await res.json().catch(() => null) : await res.text();
    if (!res.ok) {
      const e = new Error((data && data.message) || ('HTTP ' + res.status));
      e.status = res.status; e.data = (data && data.data) || {}; e.code = data && data.code;
      throw e;
    }
    return data;
  }
  // A change: once more with a fresh nonce if the page has been open past a day.
  async function post(path, body) {
    try { return await call('POST', path, body); } catch (e) {
      if (e.status === 403 && (e.data.why === 'nonce' || e.code === 'rest_cookie_invalid_nonce')) { if (e.code && W.me && W.freshNonce) await W.freshNonce(); else { if (e.code) W.nonce = ''; await loadLive(); } return call('POST', path, body); }
      throw e;
    }
  }
  async function loadLive() {
    const d = await call('GET', 'vol/' + state.year);
    state.live = d;
    if (d.nonce) W.nonce = d.nonce;
    return d;
  }
  // Counts that came back with an action replace those shifts' only.
  function merge(d) {
    if (!d || !state.live) return;
    if (d.shifts) Object.keys(d.shifts).forEach(k => { state.live.shifts[k] = d.shifts[k]; });
    if (d.mine) state.live.mine = d.mine;
    if (d.waits) state.live.waits = d.waits;
    if (d.hold) addHold(d.hold);
  }

  /* ---------------------------------------------------------------- the year and its shifts */

  const S = () => state.model.settings;
  const L = sh => (state.live && state.live.shifts[sh.id]) || { f: 0, o: sh.unlimited ? null : sh.needed, w: 0, st: 'not_open', s: [] };
  const find = id => state.shifts.find(s => s.id === id);
  const live = () => state.live || { mine: [], waits: [], committees: [], shifts: {} };
  const me = () => live().me;
  const signed = () => !!(me() && me().signed);
  // An emailed link (a place opened, sign up again) vouches for the email: no need to type it.
  const vouched = () => !signed() && !!(state.link && /^(opened|again)$/.test(state.link.a || '') && state.link.email);
  const mine = () => live().mine || [];
  const minesOn = sh => mine().filter(m => m.shift === sh.id);
  const waitsOn = sh => (live().waits || []).filter(w => w.shift === sh.id);
  const open = sh => { const o = L(sh).o; return o == null ? Infinity : o; };
  const st = sh => L(sh).st;
  const joinable = sh => st(sh) === 'open';
  // Counted as open: open now, or (a preview before Publish) open once sign-ups go up. A COA member's
  // See it before Publish shows the real numbers, never "Full" on every card.
  const counts = sh => st(sh) === 'open' || st(sh) === 'not_open';
  const openSum = list => list.filter(counts).reduce((k, sh) => k + (sh.unlimited ? 0 : Math.max(0, open(sh))), 0);
  // "Opens Mar 15" once the COA has set the day, else "Not open yet".
  const opensWord = () => live().opens ? 'Opens ' + O.fmtDate(live().opens, 'mdShort') : 'Not open yet';
  // A job with no limit: one quiet word on a card.
  const NOLIMIT = 'No limit';
  const names = () => live().names !== false;
  // The Conference is over: counts only (no names, no Join, no one to call).
  const closed = () => !!live().closed;
  const committees = () => {
    const have = new Set(state.shifts.map(s => s.committee));
    const order = (live().committees || []).map(c => c.name).filter(n => have.has(n));
    have.forEach(n => { if (order.indexOf(n) < 0) order.push(n); });
    return order;
  };
  const comm = c => (live().committees || []).find(x => x.name === c) || {};
  const plural = SU.plural;
  const uniq = xs => Array.from(new Set(xs));
  // "7–11 AM", "11:45 AM–2:15 PM", "10 PM–12 AM": one line, tabular.
  const span = sh => O.formatRange(sh.start, sh.end, { compact: true });
  const tm = m => O.formatTime(m, { compact: true });
  // Saturday's 12–2 AM is Friday night: a shift from midnight to 5 AM belongs to the evening before.
  const eve = sh => { const i = state.model.days.indexOf(sh.day); return sh.start < 300 && i > 0 ? state.model.days[i - 1] : sh.day; };
  const night = sh => sh.start < 300 && eve(sh) !== sh.day;
  const sortKey = sh => state.model.days.indexOf(eve(sh)) * 2880 + (night(sh) ? sh.start + 1440 : sh.start);
  const dayWord = d => O.fmtDate(d.date, 'weekday');
  const whenShort = sh => O.fmtDate(eve(sh).date, 'weekdayShort') + (night(sh) ? ' night' : '') + ', ' + O.fmtDate(eve(sh).date, 'mdShort') + ' · ' + span(sh);
  const whenLong = sh => dayWord(eve(sh)) + (night(sh) ? ' night' : '') + ', ' + O.fmtDate(eve(sh).date, 'md');
  // Real instants for overlap (as the server): the day's index × a day + minutes.
  const t0 = sh => state.model.days.indexOf(sh.day) * 1440 + sh.start, t1 = sh => state.model.days.indexOf(sh.day) * 1440 + sh.end;
  // A person already on a shift at that time (Busy), by name, among this device's own sign-ups.
  const clash = (name, sh) => mine().filter(m => m.shift !== sh.id && (!name || m.name === name)).map(m => find(m.shift)).find(x => x && t0(x) < t1(sh) && t0(sh) < t1(x));
  const placeName = sh => sh.place ? sh.place.name : '';
  const isWeek = () => { const d = state.model.days, n = today(); return d.length && n >= O.isoAddDays(d[0].date, -7) && n <= d[d.length - 1].date; };
  const today = () => (state.live && state.live.now && state.live.now.date) || O.wallNow(tz()).date;
  // The Conference is on (its first day to its last): the page opens on today's shifts.
  const during = () => { const d = state.model.days, n = today(); return !!(d.length && n >= d[0].date && n <= d[d.length - 1].date); };
  const nowMin = () => (live().now && live().now.minutes) || 0;
  // Minutes from the first day's midnight, for "now" and for a shift's start (as t0).
  const nowAt = () => Math.max(0, state.model.days.findIndex(d => d.date === today())) * 1440 + nowMin();
  const ahead = sh => !/^(started|ended)$/.test(st(sh));
  // A closed year: how many different people helped (one person on three shifts is one). Unknown for a
  // year cleared before that was kept: then what it is, places filled. Nothing at all when it's none.
  const helpedOf = c => { const h = live().helped; return h ? (c ? (h.committees || {})[c] || 0 : h.total || 0) : null; };
  const placesOf = list => list.reduce((k, sh) => k + L(sh).f, 0);
  const helpedWords = (c, list) => { const h = helpedOf(c); return h != null ? (h ? h + ' helped' : '') : placesOf(list) ? placesOf(list) + ' places filled' : ''; };
  // Someone's email shown back to them, not in full: "r…@gmail.com".
  const masked = e => { const m = /^(.)[^@]*(@.*)$/.exec(String(e || '')); return m ? m[1] + '…' + m[2] : ''; };

  // A shift's rule: an age ("21 or older"), a choice (First Aid's certification), or words to agree to.
  const minAge = sh => +sh.min_age || ((/\b(\d{1,2})\s*(\+|or older|and older|and up)/i.exec(sh.rule || '') || [])[1] | 0);
  const question = sh => sh.question ? sh.question.split('|').map(s => s.trim()).filter(Boolean) : (/certified/i.test(sh.rule) && /partner/i.test(sh.rule) ? ['Certified', 'With a certified partner'] : []);
  const screening = sh => /^(y|yes|1|true)$/i.test(sh.screening || '');
  const needsAsk = sh => !!(sh.rule || question(sh).length || screening(sh));
  const ruleShort = sh => minAge(sh) ? minAge(sh) + ' or older' : question(sh).length ? 'Certified, or with a partner who is' : sh.rule;

  /* ---------------------------------------------------------------- who's signing up */

  // The household from the registration (each person who may help, how old as far as it says, their
  // days); else the person.
  const hh = () => (live().household && live().household.people) || [];
  const myName = () => { const m = me(); return m && m.name && /\s/.test(m.name.trim()) ? m.name.trim() : ''; };
  // The name to call this person by: theirs, or (not signed in) the one they signed up under.
  const selfName = () => myName() || (mine()[0] || {}).name || '';
  const people = () => { const h = hh(); return h.length ? h.map(p => p.name) : [myName()].filter(Boolean); };
  // Who the row Joins sign up (a father of six chooses once): remembered on this device.
  function chosen() {
    const all = people(), k = kept.get('who-' + state.year, null);
    const pick = Array.isArray(k) ? k.filter(n => all.indexOf(n) > -1) : [];
    return pick.length ? pick : all.slice(0, 1);
  }
  const personOf = n => hh().find(p => p.name === n) || null;
  const tooYoung = (n, sh) => { const p = personOf(n), a = minAge(sh); if (!p || !a) return false; return p.years != null ? p.years < a : a >= 18 && (p.age === 'minor' || p.age === 'child'); };
  const notHere = (n, sh) => { const p = personOf(n); return p && p.days && p.days.length && p.days.indexOf(sh.day.date) < 0; };
  const first = n => String(n || '').split(' ')[0];

  // One tap from a line: signed in, a name and phone on file, no rule to answer, everyone free.
  const oneTap = sh => signed() && !!me().phone && chosen().length > 0 && !needsAsk(sh) && chosen().every(n => !clash(n, sh) && !minesOn(sh).some(m => m.name === n)) && open(sh) >= chosen().length;

  /* ---------------------------------------------------------------- the people on a shift */

  // A round mark per place: filled (initials, or blank when the name doesn't show), yours (a tick, in
  // tan), open (an outline). Count mode: marks only.
  // Inside a household everyone shares a last initial, so its own marks are the first name's first two
  // letters ("Aa", "Ad" for Aaron and Adam Adams); one person alone is a tick.
  const houseMany = () => people().length > 1 || uniq(mine().map(m => m.name)).length > 1;
  const hhInit = n => { const f = String(n || '').trim().split(/\s+/)[0] || ''; return f.charAt(0).toUpperCase() + f.charAt(1).toLowerCase(); };
  const seat = p => p ? '<span class="vol-seat' + (p.you ? ' is-you' : '') + (!p.l ? ' is-anon' : '') + (p.swap ? ' is-swap' : '') + '">' + (p.you ? (p.n && houseMany() ? esc(hhInit(p.n)) : I.check) : p.l && names() ? esc(p.i || '') : '') + '</span>' : '<span class="vol-seat is-open"></span>';
  const seatsOf = sh => (L(sh).s || []).map(x => ({ l: x[0], i: x[1], you: !!x[2], swap: x[3], n: x[4] || '' }));
  // Your own household's are named to you: "You" for yourself, "Esther" for the one you signed up.
  const ownWord = p => p.n && selfName() && p.n !== selfName() ? first(p.n) : 'You';
  function marks(sh, most) {
    const ppl = seatsOf(sh), o = open(sh), cap = most || 6;
    const ord = ppl.filter(p => p.you).concat(ppl.filter(p => !p.you));
    if (sh.unlimited) return '<span class="vol-seats" aria-hidden="true">' + ord.slice(0, cap).map(seat).join('') + (ord.length > cap ? '<span class="vol-seat is-more">+' + (ord.length - cap) + '</span>' : '') + '</span>';
    if (sh.needed <= cap) return '<span class="vol-seats" aria-hidden="true">' + ord.map(seat).join('') + Array.from({ length: Math.max(0, o) }, () => seat(null)).join('') + '</span>';
    return '';
  }
  // A bar for a big shift (past six places): filled out of needed.
  const fillBar = (sh, cap) => sh.unlimited || sh.needed <= (cap || 6) ? '' : '<span class="vol-fill" aria-hidden="true"><span style="width:' + Math.min(100, Math.round(100 * L(sh).f / sh.needed)) + '%"></span></span>';
  // "Ruth K., John M. + 2", yours first, cut at whole names; hidden names only counted.
  function whoLine(list, most) {
    if (!list.length) return '';
    if (!names()) return plural(list.length, 'volunteer');
    const shownL = list.filter(p => p.you).map(ownWord).concat(list.filter(p => !p.you && p.l).map(p => p.l));
    const head = uniq(shownL).slice(0, most || 2);
    const rest = list.length - head.length;
    return head.length ? head.join(', ') + (rest > 0 ? '\u00a0+\u00a0' + rest : '') : plural(list.length, 'volunteer');
  }
  const openText = sh => sh.unlimited ? L(sh).f + ' coming' : open(sh) > 0 ? open(sh) + ' open' : 'Full';

  /* ---------------------------------------------------------------- render */

  function render() {
    root.removeAttribute('aria-busy');
    if (state.view === 'lead') return leadRender();
    const s = S(), r = state.row, slim = !!state.committee;
    const where = [r.city || s.city].filter(Boolean).join('');
    const when = r.start ? O.fmtDateSpan(r.start, r.end) : '';
    const close = live().closes && !live().closed ? '<p class="vol-closes">Closes ' + esc(O.fmtDate(live().closes, 'md')) + '</p>' : '';
    const head = slim
      ? '<header class="wk-hero vol-hero-band is-slim"><div class="wk-wrap"><p class="vol-slim"><a class="vol-back" href="?year=' + esc(state.year) + '" data-pick="">' + I.back + '<span>Shifts</span></a>' +
        // Which Conference, always (an Invite link opens here): Luke's ask, Oct 9.
        '<span class="wk-kicker vol-slim__k">' + esc(state.year) + ' Annual Conference</span>' + (closed() ? '<span class="vol-closedtag">Closed</span>' : '') + '</p>' + idLine() + '</div></header>'
      : '<header class="wk-hero vol-hero-band"><div class="wk-wrap wk-hero__in"><div class="wk-hero__text vol-hero">' +
        '<p class="wk-kicker">' + esc(state.year) + ' Annual Conference</p><h1 class="vol-title">Volunteer</h1>' +
        (when ? '<p class="vol-when">' + esc(when) + (where ? ' · ' + esc(where) : '') + '</p>' : r.hosts ? '<p class="vol-when">' + esc(/^hosted/i.test(r.hosts) ? r.hosts : 'Hosted by the ' + r.hosts) + '</p>' : '') + close + idLine() +
        '</div>' + (!state.shifts.length ? '' : '<div class="wk-hero__side"><figure class="wk-photo"><img src="' + esc(SU.photoOf(s)) + '" alt="" loading="lazy" decoding="async"></figure></div>') + '</div></header>';
    let body;
    if (!state.shifts.length || (!live().posted && !live().closed && q.get('preview') !== '1')) body = notPosted();
    else if (state.committee && committees().indexOf(state.committee) > -1) body = committeeView(state.committee);
    else body = linkCard() + yoursCard() + againCard() + homeView();
    root.innerHTML = '<div class="wk vol">' + head + '<section class="wk-main"><div class="wk-wrap">' + body + '</div></section></div>';
    document.title = (state.committee ? state.committee + ' – ' : '') + 'Volunteer – ' + state.year + ' Annual Conference – Old German Baptist Brethren Church, New Conference';
  }

  // Who the page thinks you are, with a way out on a shared device; or Sign in.
  function idLine() {
    const m = me(), ret = encodeURIComponent(location.pathname + location.search);
    const signin = (W.signin || '/annual-conference/signin/') + '?return=' + ret;
    if (m && m.signed) {
      const who = myName() ? SU.firstL(myName()) : masked(m.email);
      const n = mine().length, card = n && !state.committee;
      return '<p class="vol-id"><span>' + esc(who) + '</span> · <button type="button" class="wk-linklike" data-signout>Not you?</button>' +
        (!card && n ? ' · <a href="../register/?year=' + esc(state.year) + '&view=mine">Your sign-ups · ' + uniq(mine().map(x => x.shift)).length + '</a>' : '') + '</p>';
    }
    // Not signed in, with sign-ups on this device still to confirm (a hold, or the device link).
    if ((m && m.email) || mine().some(x => !x.confirmed)) return '<p class="vol-id">' + (m && m.email ? '<span>' + esc(masked(m.email)) + '</span> · ' : '') + 'Check your email · <button type="button" class="wk-linklike" data-forget>Not you?</button></p>';
    return '<p class="vol-id"><a href="' + esc(signin) + '">Sign in</a></p>';
  }

  // Nothing posted is said as that; a year with no shifts shows its own name and hosts.
  function notPosted() {
    const asked = kept.get('asked-' + state.year, false);
    const opens = live().opens;
    return '<section class="vol-blank"><h2 class="vol-blank__h">' + (opens ? 'Opens ' + esc(O.fmtDate(opens, 'md')) : 'Not posted yet') + '</h2>' +
      (asked ? '<p class="vol-blank__p">' + I.check + 'We’ll email you</p>'
        : '<form class="vol-notify" data-notify novalidate>' + (signed() ? '' : '<label class="vol-f"><span>Email</span><input name="email" type="email" autocomplete="email" inputmode="email"><small class="vol-err" hidden></small></label>') +
          '<input class="vol-hp" name="hp" tabindex="-1" autocomplete="off" aria-hidden="true"><button type="submit" class="wk-btn wk-btn--small">' + I.mail + 'Email me when it opens</button></form>') + '</section>';
  }

  // A link from an email, answered at the top of the page.
  function linkCard() {
    const k = state.link;
    if (!k) return '';
    const box = (h, p, act) => '<section class="vol-note" role="status"><p class="vol-note__h">' + h + '</p>' + (p ? '<p class="vol-note__p">' + p + '</p>' : '') + (act || '') + '</section>';
    if (k.error) return box('Link expired', 'Sign in to see your sign-ups.', '<p><a class="wk-btn wk-btn--small" href="' + esc((W.signin || '') + '?return=' + encodeURIComponent(location.pathname + '?year=' + state.year)) + '">Sign in</a></p>');
    if (k.a === 'confirm') return box(I.check + 'Confirmed', esc(plural(k.n || 0, 'shift')) + ' · Your name shows on the list');
    if (k.a === 'notme') return box('Removed', esc(plural(k.n || 0, 'sign-up')) + ' under ' + esc(masked(k.email)) + ' · The committee head is told');
    if (k.a === 'unnotify') return box('Removed', 'No email when sign-ups open');
    if (k.a === 'leave') {
      const rs = (k.records || []).filter(r => find(r.shift));
      if (!rs.length) return box('Not signed up', 'Nothing to leave under ' + esc(masked(k.email)));
      if (k.left) return box('Left shift', rs.map(r => esc(find(r.shift).role + ' · ' + whenShort(find(r.shift)))).join('<br>'));
      const lines = rs.map(r => esc(find(r.shift).role + ' · ' + whenShort(find(r.shift)) + (rs.length > 1 ? ' · ' + r.name : ''))).join('<br>');
      // A swap opened from the email: the link to send, Cancel swap quiet.
      if (k.swap) return box('Swap open', lines + '<br>Your place stays yours until someone takes it.', '<p class="vol-note__btns"><button type="button" class="wk-btn wk-btn--small" data-linkswapcopy>' + I.link + 'Copy link</button></p>');
      // Leave asks first and steers to a replacement, as in the sheet.
      return box('Leave this shift?', lines + '<br>The committee head is told.',
        '<p class="vol-note__btns"><button type="button" class="wk-btn wk-btn--small" data-linkswap>Find replacement</button><button type="button" class="wk-linklike" data-linkleave>Leave shift</button><button type="button" class="wk-linklike" data-linkkeep>Keep</button></p>');
    }
    if (k.a === 'again' || k.a === 'opened') {
      const shs = (k.shifts || []).map(find).filter(Boolean);
      if (k.done) return '';
      if (k.unwaited) return box('Off the waitlist', shs.map(sh => esc(sh.role + ' · ' + whenShort(sh))).join('<br>'));
      return box(k.a === 'opened' ? 'A place opened' : 'Again this year', shs.map(sh => esc(sh.role + ' · ' + whenShort(sh) + ' · ' + openText(sh))).join('<br>'),
        '<p class="vol-note__btns"><button type="button" class="wk-btn wk-btn--small" data-linkjoin>' + (shs.length > 1 ? 'Sign up · ' + plural(shs.length, 'shift') : 'Join') + '</button>' +
        (k.a === 'opened' && k.waiting ? '<button type="button" class="wk-linklike" data-linkunwait>Leave waitlist</button>' : '') + '</p>');
    }
    return '';
  }

  /* ---------------------------------------------------------------- where you can help */

  function homeView() {
    const closed = live().closed;
    // During the Conference the page opens on today's shifts (Committees is one tap away).
    const by = state.by === 'day' || (!closed && during() && state.by !== 'committees');
    if (closed) {
      const vols = helpedWords('', state.shifts);
      // A past year's one action is the next Conference: its shifts when it has them, else Email me.
      const nx = (state.years || []).find(y => +y.year === +state.year + 1);
      const next = nx && nx.data ? '<p><a class="wk-btn wk-btn--small" href="?year=' + esc(nx.year) + '">' + esc(nx.year) + ' shifts</a></p>'
        : nx ? (kept.get('asked-' + nx.year, false) ? '<p class="vol-blank__p">' + I.check + 'We’ll email you when ' + esc(nx.year) + ' opens</p>'
          : '<form class="vol-notify" data-notify="' + esc(nx.year) + '" novalidate>' + (signed() ? '' : '<label class="vol-f"><span>Email</span><input name="email" type="email" autocomplete="email" inputmode="email"><small class="vol-err" hidden></small></label>') + '<input class="vol-hp" name="hp" tabindex="-1" autocomplete="off" aria-hidden="true"><button type="submit" class="wk-btn wk-btn--small">' + I.mail + 'Email me when ' + esc(nx.year) + ' opens</button></form>') : '';
      return '<section class="vol-blank"><h2 class="vol-blank__h">Closed</h2><p class="vol-blank__p">' + esc([plural(state.shifts.length, 'shift'), vols].filter(Boolean).join(' · ')) + '</p>' + next + '</section>' +
        '<ul class="vol-cards">' + committees().map(card).join('') + '</ul>';
    }
    // Who a row's Join signs up shows only where rows have Join (Days; a committee's page), not over cards.
    return '<div class="vol-top"><h2 class="vol-h" tabindex="-1">Shifts</h2>' + (by ? whoPick() : '') + '</div>' +
      '<div class="vol-pickers"><div class="wk-aud" role="group" aria-label="Show"><button type="button" data-by="committees" aria-pressed="' + !by + '">' + I.check + 'Committees</button><button type="button" data-by="day" aria-pressed="' + by + '">' + I.check + 'Days</button></div></div>' +
      (by ? byDay() : '<ul class="vol-cards">' + committees().map(card).join('') + '</ul>');
  }

  // Who the row Joins sign up, for a household: chosen once. People are round initials with the name in
  // a bordered group under "Who" (never the same pills as the days below them).
  const personChip = (n, on, extra) => '<span class="vol-pchip__seat" aria-hidden="true">' + esc(hhInit(n)) + '</span><span>' + esc(first(n)) + (extra || '') + '</span>';
  function whoPick() {
    if (people().length < 2 || closed()) return '';
    const c = chosen();
    return '<div class="vol-whopick"><p class="rf-label">Signing up</p>' + (state.whoOpen
      ? '<span class="vol-pchips" role="group" aria-label="Signing up">' + people().map(n => '<label class="vol-pchip"><input type="checkbox" data-who value="' + esc(n) + '"' + (c.indexOf(n) > -1 ? ' checked' : '') + '>' + personChip(n, c.indexOf(n) > -1) + '</label>').join('') + '</span> <button type="button" class="wk-linklike" data-whochange aria-expanded="true">Done</button>'
      : '<p class="vol-whopick__now"><span class="vol-pchips">' + c.map(n => '<span class="vol-pchip is-static">' + personChip(n, false) + '</span>').join('') + '</span> <button type="button" class="wk-linklike" data-whochange aria-expanded="false">Change</button></p>') + '</div>';
  }

  function card(c) {
    const closed = live().closed;
    // During the week a card speaks of what's still ahead ("Sat–Tue · 11 shifts").
    const list = state.shifts.filter(sh => sh.committee === c && (closed || !during() || ahead(sh)));
    if (!list.length) return '';
    const o = openSum(list);
    const anyOpen = list.some(sh => counts(sh) && open(sh) > 0);
    const roles = uniq(list.map(sh => sh.role)), ds = state.model.days.filter(d => list.some(sh => eve(sh) === d));
    const helped = closed ? helpedWords(c, list) : '';
    // The job line only when it says more than the name ("First aid" under First aid says nothing).
    // …nor when it only adds "helper" ("Communion helper" under Communion).
    const said = r => { const a = r.toLowerCase(), b = c.toLowerCase(); return a === b || a.replace(/\s+helpers?$/, '') === b; };
    const jobs = roles.length === 1 && said(roles[0]) ? '' : roles.join(' · ');
    const days = ds.length === 1 ? dayWord(ds[0]) : dayWord(ds[0]).slice(0, 3) + '–' + dayWord(ds[ds.length - 1]).slice(0, 3);
    const you = uniq(list.filter(sh => minesOn(sh).length).map(sh => sh.id)).length;
    const all = list.reduce((a, sh) => a.concat(seatsOf(sh)), []);
    const label = c + ', ' + (closed ? helped || plural(list.length, 'shift') : anyOpen ? (o ? o + ' places open' : 'open') : 'full') + ', ' + roles.join(', ') + (you ? ', you are signed up' : '');
    return '<li><a class="vol-card' + (anyOpen || closed ? '' : ' is-full') + '" href="?year=' + esc(state.year) + '&committee=' + encodeURIComponent(c) + '" data-pick="' + esc(c) + '" aria-label="' + esc(label) + '">' +
      '<span class="vol-card__mark">' + mark(c) + '</span>' +
      '<span class="vol-card__t"><h3>' + esc(c) + '</h3>' + (jobs ? '<small>' + esc(jobs) + '</small>' : '') + '<small class="vol-card__d">' + esc(days + ' · ' + plural(list.length, 'shift')) + '</small></span>' +
      '<span class="vol-card__n">' + (closed ? (helped ? '<span><b>' + esc(helped.split(' ')[0]) + '</b> ' + esc(helped.split(' ').slice(1).join(' ')) + '</span>' : '') : '<span>' + (anyOpen ? (o ? '<b>' + o + '</b> open' : '<span class="vol-muted">' + NOLIMIT + '</span>') : 'Full') + '</span>') + (you ? '<span class="vol-card__you">' + I.check + 'Signed up' + (you > 1 ? ' · ' + you : '') + '</span>' : '') + '</span>' +
      // Who's helping, by name; nothing when no one yet, or once the Conference is over.
      (all.length && !closed ? '<span class="vol-card__who">' + esc(whoLine(all, 2)) + '</span>' : '') +
      '<span class="vol-card__go">' + I.go + '</span></a></li>';
  }

  // Every shift, one day at a time (pills), each line with its committee's mark.
  function byDay() {
    const wk = during() && !closed();
    // During the week: only the days still to come, today first.
    const days = state.model.days.filter(d => state.shifts.some(sh => eve(sh) === d) && (!wk || d.date >= today()));
    const day = dayPick(days);
    const all = state.shifts.filter(sh => eve(sh) === day).sort((a, b) => sortKey(a) - sortKey(b));
    // Shifts already started or over fold to one line; the rest show.
    const gone = wk ? all.filter(sh => !ahead(sh)) : [];
    const list = all.filter(sh => gone.indexOf(sh) < 0 || state.showGone);
    const fold = gone.length ? '<p class="vol-folded">' + esc(plural(gone.length, 'shift') + ' started or over') + ' · <button type="button" class="wk-linklike" data-showgone>' + (state.showGone ? 'Hide' : 'Show') + '</button></p>' : '';
    return openNow() + dayPills(days, day, sh => true) + openToggle() + '<h3 class="vol-dayg__h">' + esc(whenDay(day)) + '</h3>' + fold + rows(list, true);
  }
  // On campus: what's open in the next three hours, first ("Open now"). The guide could show the same.
  function openNow() {
    if (!during() || closed()) return '';
    const at = nowAt();
    const soon = state.shifts.filter(sh => joinable(sh) && open(sh) > 0 && t0(sh) >= at && t0(sh) < at + 180).sort((a, b) => sortKey(a) - sortKey(b));
    if (!soon.length) return '';
    return '<section class="vol-now" aria-labelledby="vol-now-h"><h3 class="vol-now__h" id="vol-now-h">Open now <small>· next 3 hours</small></h3>' + rows(soon, true) + '</section>';
  }
  function dayPick(days) {
    const want = state.day || kept.get('day-' + state.year, '');
    // During the week, today unless another day was chosen just now.
    const d = (during() && !state.day ? days.find(x => x.date === today()) : null) || days.find(x => x.key === want) || days.find(x => x.date === today()) || days[0];
    state.day = d ? d.key : '';
    return d;
  }
  function dayPills(days, day, mineFilter) {
    if (days.length < 2) return '';
    return '<div class="wk-aud vol-daypills" role="group" aria-label="Day" style="--vol-days:' + days.length + '">' + days.map(d => {
      const list = state.shifts.filter(sh => eve(sh) === d && mineFilter(sh)), o = openSum(list);
      return '<button type="button" data-day="' + esc(d.key) + '" aria-pressed="' + (d === day) + '" aria-label="' + esc(dayWord(d) + ', ' + (o ? o + ' open' : 'full')) + '"><span>' + esc(dayWord(d).slice(0, 3)) + '</span><small>' + (o ? o + ' open' : list.some(counts) ? '' : list.some(sh => st(sh) === 'full') ? 'Full' : '') + '</small></button>';
    }).join('') + '</div>';
  }
  const openToggle = () => closed() ? '' : '<label class="vol-only"><input type="checkbox" data-openonly' + (state.openOnly ? ' checked' : '') + '> Open only</label>';

  function rows(list, withCommittee, oneJob) {
    const show = state.openOnly ? list.filter(sh => counts(sh) && open(sh) > 0 || minesOn(sh).length) : list;
    const hidden = list.length - show.length;
    if (!list.length) return '';
    return '<ol class="vol-rows">' + show.map(sh => row(sh, withCommittee, oneJob)).join('') + '</ol>' +
      (hidden ? '<p class="vol-folded">' + esc(plural(hidden, 'shift') + ' full or closed') + ' · <button type="button" class="wk-linklike" data-openonly-off>Show</button></p>' : '');
  }

  // A shift as a line: its time (opens its sheet), the job, who's on it, and the one action.
  const STATE_WORD = { started: 'Started', ended: 'Ended', closed: 'Closed', committee: 'By committee' };
  const stateWord = s => s === 'not_open' ? opensWord() : STATE_WORD[s] || '';
  const stateTip = s => s === 'committee' ? ' title="Filled by the committee"' : '';
  // "Busy · Usher 9:30–12 · View": the other shift's own span, so the clash explains itself.
  const busyWords = b => 'Busy · ' + b.role + ' ' + O.formatRange(b.start, b.end, { compact: true, bare: true }).replace(/\s?(AM|PM)/g, '');
  const busyOf = r => { const x = r && find(r.shift); return x ? busyWords(x) : 'Busy · ' + r.role + ' until ' + tm(r.until); };
  function row(sh, withCommittee, oneJob) {
    const you = minesOn(sh), s = st(sh), o = open(sh), full = s === 'full' || (s === 'open' && o <= 0);
    const busy = !you.length && signed() ? chosen().map(n => clash(n, sh)).find(Boolean) : null;
    const lbl = (verb) => verb + ' ' + sh.role + ', ' + whenLong(sh) + ', ' + span(sh).replace('–', ' to ') + (sh.unlimited ? '' : ', ' + (o > 0 ? o + ' open' : 'full'));
    let act;
    if (closed()) act = '';
    else if (you.length) act = '<span class="vol-on-it" data-status="' + esc(sh.id) + '" tabindex="-1">' + I.check + 'Signed up</span>';
    else if (STATE_WORD[s] || s === 'not_open') act = '<span class="vol-muted"' + stateTip(s) + '>' + esc(stateWord(s)) + '</span>';
    else if (busy) act = '<button type="button" class="vol-busy" data-shift="' + esc(busy.id) + '" aria-label="' + esc(busyWords(busy) + '. View') + '">' + esc(busyWords(busy)) + ' · <u>View</u></button>';
    else if (full) act = waitsOn(sh).length ? '<span class="vol-muted">On waitlist</span>' : '<button type="button" class="wk-btn wk-btn--line wk-btn--small vol-quiet" data-wait="' + esc(sh.id) + '" aria-label="' + esc(lbl('Join the waitlist for')) + '">Waitlist</button>';
    else act = '<button type="button" class="wk-btn wk-btn--line wk-btn--small" data-join="' + esc(sh.id) + '" aria-label="' + esc(lbl('Join')) + '">Join</button>';
    const ppl = seatsOf(sh), alone = oneJob && !withCommittee;
    // The committee only when it says more than the job ("First aid · First Aid Room", not "First aid · First aid").
    const soft = withCommittee ? [sh.committee.toLowerCase() === sh.role.toLowerCase() ? '' : sh.committee, placeName(sh)].filter(Boolean) : [];
    return '<li class="vol-r' + (you.length ? ' is-you' : '') + (full && !you.length && !closed() ? ' is-full' : '') + (s === 'started' || s === 'ended' ? ' is-past' : '') + '" data-row="' + esc(sh.id) + '">' +
      // The time opens the sheet (the only way in for a one-job committee, whose rows have no name).
      '<button type="button" class="vol-r__t" data-shift="' + esc(sh.id) + '"' + (alone ? ' aria-label="' + esc(sh.role + ', ' + whenLong(sh) + ', ' + span(sh)) + '"' : ' tabindex="-1" aria-hidden="true"') + '>' + esc(span(sh)) + (night(sh) ? '<small>night</small>' : '') + '</button>' +
      '<div class="vol-r__c">' + (alone ? '' : '<button type="button" class="vol-r__name" data-shift="' + esc(sh.id) + '">' + (withCommittee ? '<span class="vol-r__mark">' + mark(sh.committee) + '</span>' : '') + esc(sh.role) + '</button>') +
      (soft.length ? '<span class="vol-r__soft">' + soft.map(esc).join(' · ') + '</span>' : '') +
      (closed() ? (L(sh).f ? '<span class="vol-r__who"><span class="vol-r__names">' + esc(L(sh).f + ' helped') + '</span></span>' : '') : full && !you.length ? '' : '<span class="vol-r__who">' + marks(sh) + fillBar(sh) + '<span class="vol-r__names">' + esc(whoLine(ppl, 3)) + (ppl.length && !sh.unlimited ? ' · ' : '') + '<b class="vol-open' + (o > 0 ? '' : ' is-full') + '">' + esc(openText(sh)) + '</b></span></span>') +
      '</div><div class="vol-r__act">' + act + '</div></li>';
  }

  // One committee: its jobs said once, then its week.
  function committeeView(c) {
    const list = state.shifts.filter(sh => sh.committee === c).sort((a, b) => sortKey(a) - sortKey(b));
    const roles = uniq(list.map(sh => sh.role)), oneJob = roles.length === 1;
    const o = openSum(list), anyLimit = list.some(sh => !sh.unlimited);
    const days = state.model.days.filter(d => list.some(sh => eve(sh) === d));
    const others = committees().filter(x => x !== c);
    const phone = comm(c).phone;
    const jobs = roles.map(role => {
      const xs = list.filter(sh => sh.role === role), places = uniq(xs.map(placeName).filter(Boolean)), rule = xs.map(ruleShort).find(Boolean);
      // What every one of the job's shifts says (lunch and supper servers differ: each shift's sheet
      // has its own note; the job says only what's common to all).
      const note = commonNote(xs.map(sh => sh.note || ''));
      return '<li><b>' + esc(role) + '</b>' + (rule ? '<span class="vol-rulechip">' + I.rule + esc(rule) + '</span>' : '') + (note ? '<p>' + esc(note) + '</p>' : '') + (places.length ? '<p class="vol-jobs__where">' + I.pin + esc(places.join(' · ')) + '</p>' : '') + '</li>';
    }).join('');
    const day = dayPick(days);
    const dayList = list.filter(sh => eve(sh) === day);
    const helpedC = closed() ? helpedWords(c, list) : '';
    return '<div class="vol-chead"><span class="vol-chead__mark">' + mark(c) + '</span><div class="vol-chead__t"><h2 class="vol-h" tabindex="-1">' + esc(c) + '</h2>' +
      // One number on public pages: what's open.
      '<p>' + (closed() ? esc([helpedC, plural(list.length, 'shift')].filter(Boolean).join(' · ')) : !anyLimit ? NOLIMIT : o ? '<b>' + o + '</b> open' : 'Full') + (!closed() && !live().posted ? ' · ' + esc(opensWord()) : '') + '</p></div></div>' +
      '<ul class="vol-jobs">' + jobs + '</ul>' +
      // The committee is the heading just above: the phone alone.
      (phone ? '<p class="vol-ask">Questions · <a href="tel:' + esc(phone.replace(/[^\d+]/g, '')) + '">' + esc(phone) + '</a></p>' : '') +
      whoPick() +
      (days.length > 1 ? '<div class="vol-mxwrap">' + matrix(list, days) + '</div>' : '') +
      '<div class="vol-daylist' + (days.length > 1 ? ' vol-daylist--phone' : '') + '">' + dayPills(days, day, sh => sh.committee === c) + openToggle() +
      '<h3 class="vol-dayg__h">' + esc(whenDay(day)) + '</h3>' + rows(dayList, false, oneJob) + '</div>' +
      '<nav class="vol-others" aria-label="Other committees"><p class="vol-others__h">Other committees</p><ul>' + others.map(x => {
        const xs = state.shifts.filter(sh => sh.committee === x && counts(sh)), ox = openSum(xs);
        return '<li><a href="?year=' + esc(state.year) + '&committee=' + encodeURIComponent(x) + '" data-pick="' + esc(x) + '">' + mark(x) + '<span>' + esc(x) + '</span><small>' + (ox ? ox + ' open' : xs.some(sh => sh.unlimited) ? NOLIMIT : live().closed ? '' : 'Full') + '</small></a></li>';
      }).join('') + '</ul></nav>';
  }
  const whenDay = d => d ? dayWord(d) + ', ' + O.fmtDate(d.date, 'md') : '';
  // The sentences every note shares ("Hairnets and gloves are provided."), else the one note.
  function commonNote(ns) {
    const all = ns.filter(Boolean);
    if (!all.length || all.length < ns.length) return all.length === ns.length ? all[0] : '';
    if (uniq(all).length === 1) return all[0];
    const sent = t => t.match(/[^.!?]+[.!?]*/g).map(x => x.trim()).filter(Boolean);
    return sent(all[0]).filter(x => all.every(n => sent(n).indexOf(x) > -1)).join(' ');
  }

  // The grid (a laptop): a row for each job and time, a column for each day (overnight under the evening).
  function matrix(list, days) {
    const rws = [];
    list.forEach(sh => { const k = sh.role + '|' + sh.start + '|' + sh.end; let r = rws.find(x => x.k === k); if (!r) rws.push(r = { k, role: sh.role, sh, cells: {} }); r.cells[eve(sh).key] = sh; });
    rws.sort((a, b) => (night(a.sh) ? a.sh.start + 1440 : a.sh.start) - (night(b.sh) ? b.sh.start + 1440 : b.sh.start) || a.role.localeCompare(b.role));
    const oneRole = uniq(rws.map(r => r.role)).length === 1;
    return '<table class="vol-mx"><thead><tr><th scope="col"><span class="ogc-sr">Time</span></th>' + days.map(d => '<th scope="col">' + esc(dayWord(d).slice(0, 3)) + '<small>' + esc(O.fmtDate(d.date, 'md')) + '</small></th>').join('') + '</tr></thead><tbody>' +
      rws.map(r => '<tr><th scope="row"><b>' + esc(span(r.sh)) + '</b>' + (night(r.sh) ? '<small>Night</small>' : '') + (oneRole ? '' : '<small>' + esc(r.role) + '</small>') + '</th>' + days.map(d => { const sh = r.cells[d.key]; return '<td>' + (sh ? cell(sh) : '') + '</td>'; }).join('') + '</tr>').join('') + '</tbody></table>';
  }
  // A cell says what the phone's line says, in two rows so nothing runs under the button: the marks (or
  // a bar), who's on it by name; then what's open at the left, Join at the right on its own line.
  function cell(sh) {
    const you = minesOn(sh).length, o = open(sh), s = st(sh), ppl = seatsOf(sh), names2 = ppl.filter(p => p.l).map(p => p.l);
    const status = closed() ? (L(sh).f ? L(sh).f + ' helped' : '') : you ? 'Signed up' : s === 'open' ? (o > 0 ? openText(sh) : 'Full') : s === 'not_open' ? (o > 0 ? openText(sh) : 'Full') : ({ full: 'Full' })[s] || stateWord(s);
    const who = closed() ? '' : whoLine(ppl, 2);
    const label = sh.role + ', ' + whenLong(sh) + ', ' + span(sh) + ': ' + (who ? who + ', ' : '') + status + (s === 'not_open' ? ', ' + opensWord() : '');
    // Join on every open cell, for everyone: one tap when nothing needs asking, else the shift's sheet
    // with its form already open (the same as a phone's row). A full cell: Waitlist, quiet.
    const quick = !closed() && !you && s === 'open' && o > 0;
    const waitable = !closed() && !you && (s === 'full' || (s === 'open' && o <= 0));
    const fine = you || closed() || ((s === 'open' || s === 'not_open') && o > 0);
    return '<div class="vol-cell' + (you ? ' is-you' : fine ? '' : ' is-full') + (quick || waitable ? ' has-join' : '') + '"><button type="button" class="vol-cell__open" data-shift="' + esc(sh.id) + '" aria-label="' + esc(label) + '"' + (names2.length && names() ? ' title="' + esc(names2.join(', ')) + '"' : '') + '>' +
      (closed() ? '' : '<span class="vol-cell__top">' + marks(sh, 5) + fillBar(sh, 5) + '</span>') +
      (who && !you ? '<span class="vol-cell__who">' + esc(who) + '</span>' : '') +
      '<span class="vol-cell__n"><b>' + esc(status) + '</b></span></button>' +
      (quick ? '<button type="button" class="vol-cell__join" data-join="' + esc(sh.id) + '" aria-label="' + esc('Join ' + label) + '">Join</button>' : '') +
      (waitable ? (waitsOn(sh).length ? '<span class="vol-cell__wl is-on">On waitlist</span>' : '<button type="button" class="vol-cell__wl wk-linklike" data-wait="' + esc(sh.id) + '" aria-label="' + esc('Join the waitlist for ' + label) + '">Waitlist</button>') : '') + '</div>';
  }

  /* ---------------------------------------------------------------- your shifts, and last year's again */

  function yoursCard() {
    const ms = mine(), ws = (live().waits || []).filter(w => find(w.shift));
    if (!ms.length && !ws.length) return '';
    const byShift = uniq(ms.map(m => m.shift)).map(find).filter(Boolean).sort((a, b) => sortKey(a) - sortKey(b));
    const self = selfName();
    // The person first when it isn't only you ("Esther · Server · Dining hall"), as Again this year.
    const line = sh => {
      const on = minesOn(sh), names2 = on.map(m => m.name), others = names2.some(n => n !== self);
      const tags = [on.some(m => !m.confirmed) ? 'Unconfirmed' : '', on.some(m => m.swap) ? 'Swap open' : ''].filter(Boolean);
      const what = (others ? uniq(names2.map(first)).join(', ') + ' · ' : '') + sh.role + (sh.role.toLowerCase() === sh.committee.toLowerCase() ? '' : ' · ' + sh.committee);
      return '<li><button type="button" class="vol-yours__shift" data-shift="' + esc(sh.id) + '"><span class="vol-yours__mark">' + mark(sh.committee) + '</span><span><b>' + esc(what) + '</b><small>' + esc(whenShort(sh) + (placeName(sh) ? ' · ' + placeName(sh) : '')) + '</small>' +
        (tags.length ? '<small class="vol-tags">' + tags.map(t => '<span class="vol-tag">' + esc(t) + '</span>').join('') + '</small>' : '') + '</span></button></li>';
    };
    const m = me() || {}, unconf = ms.filter(x => !x.confirmed).map(x => x.rid);
    // Each other person in the household (signed up by you) has their own name switch: off until chosen.
    const fors = uniq(ms.filter(x => x.for).map(x => x.name));
    const nameSw = (n, on, help, attr, tip) => '<label class="vol-switch"' + (tip ? ' title="' + esc(tip) + '"' : '') + '><input type="checkbox" ' + attr + (on ? ' checked' : '') + '><span>' + esc(n) + '</span><small>' + esc(help) + '</small></label>';
    const switches = byShift.length && names() && !closed() ? (ms.some(x => !x.for) ? nameSw('Show my name', m.show !== false, ms.some(x => !x.confirmed) ? 'Shows once you confirm' : 'As ' + (self ? SU.firstL(self) : 'First L.') + ' on shift lists', 'data-showname') : '') +
      fors.map(n => nameSw('Show ' + first(n) + '’s name', ms.some(x => x.name === n && x.shown), 'As ' + SU.firstL(n) + ' on shift lists', 'data-showname="' + esc(n) + '"', 'Off: counted on the list, not named')).join('') : '';
    return '<section class="vol-yours" aria-labelledby="vol-yours-h"><h2 class="vol-yours__h" id="vol-yours-h">Your shifts</h2>' +
      (byShift.length ? '<ul class="vol-yours__list">' + byShift.map(line).join('') + '</ul>' : '') +
      (unconf.length ? confirmHelp(unconf, 'yours') : '') +
      (ws.length ? '<p class="vol-yours__k">Waitlist</p><ul class="vol-yours__list">' + ws.map(w => { const sh = find(w.shift); return '<li class="vol-yours__w"><button type="button" class="vol-yours__shift" data-shift="' + esc(sh.id) + '"><span class="vol-yours__mark">' + I.mail + '</span><span><b>' + esc(sh.role) + '</b><small>' + esc(whenShort(sh)) + '</small></span></button><button type="button" class="wk-linklike vol-yours__x" data-unwait="' + w.rid + '">Leave waitlist</button></li>'; }).join('') + '</ul>' : '') +
      '<div class="vol-yours__foot">' + (byShift.length ? '<button type="button" class="wk-linklike" data-icsall>' + I.cal + 'Add to calendar</button>' : '') + switches +
      // Next year is asked once the Conference is over, not on a first sign-up months ahead.
      (byShift.length && closed() ? '<label class="vol-switch"><input type="checkbox" data-nextyear' + (m.next_year ? ' checked' : '') + '><span>Next year</span><small>Email me when ' + (+state.year + 1) + ' sign-ups open</small></label>' : '') + '</div></section>';
  }

  // Last year's shifts again: each a toggle (on), any rule asked once, Busy and Full shown as such.
  function againCard() {
    const ag = (live().again || []);
    if (!ag.length || live().closed) return '';
    const rowsA = ag.map((a, i) => {
      const sh = a.shift && find(a.shift);
      // Once used, only what can still be acted on stays (a Full row with Waitlist); never a second list
      // of what's already in Your shifts.
      if (state.againUsed && (!sh || minesOn(sh).length || !(joinable(sh) && open(sh) > 0) && !(st(sh) === 'full' && !waitsOn(sh).length))) return '';
      if (!sh) return '<li class="is-off"><span class="vol-again__row"><span class="vol-again__x" aria-hidden="true"></span><span class="vol-again__t"><b>' + esc(a.was) + '</b><small>Not offered this year</small></span></span></li>';
      const onIt = minesOn(sh).length, busy = !onIt && a.names.map(n => clash(n, sh)).find(Boolean), full = joinable(sh) && open(sh) < a.names.length, s = st(sh);
      const why = onIt ? 'Signed up' : busy ? busyWords(busy) : s !== 'open' ? ({ full: 'Full', started: 'Started', ended: 'Ended', closed: 'Closed', not_open: 'Not open' })[s] || s : full ? 'Full' : '';
      const ok = !why;
      // The person first when it isn't only you ("Esther · Server · Dining hall"), then this year's day and time.
      const whoA = a.names.length > 1 || a.names[0] !== myName() ? a.names.map(first).join(', ') + ' · ' : '';
      // Every row keeps the checkbox column (a spacer where it can't be ticked), so the words line up;
      // what's in the way sits under the time.
      return '<li' + (ok ? '' : ' class="is-off"') + '><label class="vol-again__row">' + (ok ? '<input type="checkbox" data-again="' + esc(sh.id) + '" checked>' : '<span class="vol-again__x" aria-hidden="true"></span>') +
        '<span class="vol-again__t"><b>' + esc(whoA + sh.role + (sh.role.toLowerCase() === sh.committee.toLowerCase() ? '' : ' · ' + sh.committee)) + '</b><small>' + esc(whenShort(sh)) + '</small>' +
        (why ? '<small class="vol-again__why">' + esc(why) + (why === 'Full' && !waitsOn(sh).length ? ' · <button type="button" class="wk-linklike" data-wait="' + esc(sh.id) + '">Waitlist</button>' : '') + '</small>' : '') + '</span></label></li>';
    }).join('');
    const okShifts = ag.filter(a => a.shift && find(a.shift)).map(a => find(a.shift)).filter(sh => !minesOn(sh).length && joinable(sh) && open(sh) > 0);
    // Nothing left to do (all signed up, or nothing offered): the card goes.
    const waitable = ag.filter(a => a.shift && find(a.shift)).map(a => find(a.shift)).filter(sh => !minesOn(sh).length && !waitsOn(sh).length && st(sh) === 'full');
    if (!okShifts.length && !waitable.length) return '';
    const rules = uniq(okShifts.filter(needsAsk).map(sh => sh.committee));
    const ask = okShifts.filter(needsAsk);
    const qs = ask.length ? '<div class="vol-again__ask">' + uniq(ask.map(sh => question(sh).length ? 'q:' + sh.committee : 'r:' + ruleShort(sh))).map(k => {
      if (k.indexOf('q:') === 0) { const sh = ask.find(x => 'q:' + x.committee === k); return '<p class="rf-label">' + esc(sh.committee) + '</p><span class="rf-seg" role="radiogroup">' + question(sh).map(o => '<label class="rf-tog"><input type="radio" name="againq-' + esc(sh.committee) + '" value="' + esc(o) + '"><span>' + I.check + esc(o) + '</span></label>').join('') + '</span>'; }
      return '<label class="vol-claim"><input type="checkbox" data-againrule="' + esc(k.slice(2)) + '"> ' + esc(claim(k.slice(2), 2)) + '</label>';
    }).join('') + '</div>' : '';
    return '<section class="vol-again" aria-labelledby="vol-again-h"><h2 class="vol-again__h" id="vol-again-h">Again this year</h2><p class="vol-again__help">Like your ' + (state.year - 1) + ' shifts</p><ul>' + rowsA + '</ul>' + qs +
      '<p class="vol-again__err vol-err" hidden></p>' + (okShifts.length ? '<p class="vol-again__btn"><button type="button" class="wk-btn" data-againgo>Sign up · ' + plural(okShifts.length, 'shift') + '</button></p>' : '') + '</section>';
  }
  // "I'm 21 or older", or for several people "Each is 21 or older".
  const claim = (rule, n) => { const a = /(\d+) or older/.exec(rule); return a ? (n > 1 ? 'Each is ' : 'I’m ') + a[1] + ' or older' : rule; };

  /* ---------------------------------------------------------------- the shift's sheet */

  const sheet = document.createElement('dialog');
  sheet.className = 'ogc wk-sheet vol-sheet';
  sheet.setAttribute('aria-labelledby', 'vol-sheet-t');
  document.body.appendChild(sheet);
  let opener = '';

  function openShift(id, push) {
    if (!find(id)) return;
    state.sheet = id; state.form = null; state.leaving = ''; state.done = null; state.err = null; state.mapOpen = isWeek();
    // Someone who'd have to fill in the form (not signed in, or a rule to answer) sees it at once, below
    // the shift: one Join, not two.
    const sh0 = find(id);
    if (!minesOn(sh0).length && joinable(sh0) && open(sh0) > 0 && !oneTap(sh0) && !(seatsOf(sh0).some(p => p.swap) && (state.swap || q.get('swap')))) state.form = {};
    drawSheet();
    if (!sheet.open) sheet.showModal();
    if (push !== false) setUrl({ shift: id });
    const h = sheet.querySelector('#vol-sheet-t'); if (h) { h.setAttribute('tabindex', '-1'); h.focus({ preventScroll: true }); }
    sheet.scrollTop = 0;
    // Counts kept current while the sheet is open.
    clearInterval(state.tick); state.tick = setInterval(() => { if (sheet.open && !state.busyAct) refresh(true); }, 120000);
  }

  // The household's people for this shift, each with what's in the way.
  function whoPills(sh) {
    const ps = people(), you = minesOn(sh);
    if (!signed() || ps.length < 2) return '';
    const sel = state.form && state.form.people || chosen();
    return '<fieldset class="vol-whof"><legend class="rf-label">Signing up</legend><span class="vol-pchips">' + ps.map(n => {
      const on = you.some(m => m.name === n), k = clash(n, sh), young = tooYoung(n, sh), away = notHere(n, sh);
      const why = on ? 'On it' : k ? 'Busy' : young ? 'Under ' + minAge(sh) : '';
      const checked = !why && sel.indexOf(n) > -1;
      return '<label class="vol-pchip' + (why ? ' is-off' : '') + '"' + (young ? ' title="' + esc(ruleShort(sh)) + '"' : '') + '><input type="checkbox" name="who" value="' + esc(n) + '"' + (why ? ' disabled' : checked ? ' checked' : '') + '>' + personChip(n, checked, why ? ' · ' + esc(why) : away ? ' · Not here ' + esc(dayWord(eve(sh)).slice(0, 3)) : '') + '</label>';
    }).join('') + '</span></fieldset>';
  }

  // The form a newcomer fills in (unfolds above the bar after the first tap on Join), and the rule.
  function joinForm(sh, waiting) {
    const f = state.form || {}, e = state.err || {}, t = typed();
    // Filled in only from this tab's own sign-up, and never the phone.
    const fld = (name, label, type, help, attrs) => '<label class="vol-f' + (e[name] ? ' is-bad' : '') + '"><span>' + label + '</span><input name="' + name + '" type="' + type + '" value="' + esc(f[name] != null ? f[name] : name !== 'phone' ? t[name] || '' : holds().length ? tabPhone : '') + '"' + (e[name] ? ' aria-invalid="true" aria-describedby="vol-e-' + name + '"' : '') + (attrs || '') + '>' +
      (e[name] ? '<small class="vol-err" id="vol-e-' + name + '">' + (e[name].html || esc(e[name])) + '</small>' : help ? '<small>' + help + '</small>' : '') + '</label>';
    let out = '';
    if (vouched()) {
      out += '<p class="vol-before">' + esc(masked(state.link.email)) + '</p>';
    } else if (!signed()) {
      const ret = encodeURIComponent(location.pathname + '?year=' + state.year + '&shift=' + sh.id);
      out += '<p class="vol-before">Signed up before? <a href="' + esc((W.signin || '') + '?return=' + ret) + '">Sign in</a></p>' +
        '<div class="vol-fields"><div class="vol-row2">' + fld('first', 'First name', 'text', '', ' autocomplete="given-name"') + fld('last', 'Last name', 'text', '', ' autocomplete="family-name"') + '</div>' +
        fld('email', 'Email', 'email', state.typo ? 'Did you mean <button type="button" class="wk-linklike" data-typo>' + esc(state.typo) + '</button>?' : 'For your confirmation', ' autocomplete="email" inputmode="email"') +
        fld('phone', 'Phone', 'tel', 'For the committee head only', ' autocomplete="tel" inputmode="tel"') + '</div>' +
        '<input class="vol-hp" name="hp" tabindex="-1" autocomplete="off" aria-hidden="true">';
    } else if (!me().phone) {
      out += '<div class="vol-fields">' + (myName() ? '' : '<div class="vol-row2">' + fld('first', 'First name', 'text', '', ' autocomplete="given-name"') + fld('last', 'Last name', 'text', '', ' autocomplete="family-name"') + '</div>') + fld('phone', 'Phone', 'tel', 'For the committee head only', ' autocomplete="tel"') + '</div>';
    } else if (!myName() && !hh().length) {
      out += '<div class="vol-fields"><div class="vol-row2">' + fld('first', 'First name', 'text', '', ' autocomplete="given-name"') + fld('last', 'Last name', 'text', '', ' autocomplete="family-name"') + '</div></div>';
    }
    if (waiting) return out;
    out += whoPills(sh);
    // Someone else (a district helper signing up an older member): their name and phone on the shift.
    out += '<details class="vol-other"' + (f.other ? ' open' : '') + '><summary>For someone else</summary><div class="vol-fields">' + fld('oname', 'Their name', 'text', 'First and last', '') + fld('ophone', 'Their phone', 'tel', 'For the committee head', '') + '</div></details>';
    const n = Math.max(1, (f.people || (signed() ? chosen() : [])).length);
    if (question(sh).length) {
      out += '<fieldset class="vol-q' + (e.rule ? ' is-bad' : '') + '"><legend class="rf-label">' + (/certif/i.test(sh.rule + ' ' + question(sh).join(' ')) ? 'Certification' : 'Choose one') + '</legend><span class="rf-seg" role="radiogroup">' + question(sh).map(o => '<label class="rf-tog"><input type="radio" name="question" value="' + esc(o) + '"' + (f.question === o ? ' checked' : '') + '><span>' + I.check + esc(o) + '</span></label>').join('') + '</span>' + (e.rule ? '<small class="vol-err">' + esc(e.rule) + '</small>' : '') + '</fieldset>';
    } else if (sh.rule) {
      out += '<label class="vol-claim' + (e.rule ? ' is-bad' : '') + '"><input type="checkbox" name="rule"' + (f.rule ? ' checked' : '') + (e.rule ? ' aria-invalid="true"' : '') + '> ' + esc(minAge(sh) ? claim(minAge(sh) + ' or older', n) : sh.rule) + '</label>' + (e.rule ? '<small class="vol-err">' + esc(e.rule) + '</small>' : '');
    }
    if (screening(sh)) out += '<fieldset class="vol-q' + (e.screened ? ' is-bad' : '') + '"><legend class="rf-label">Child-safety screening</legend><span class="rf-seg" role="radiogroup">' + [['yes', 'Screened'], ['not_yet', 'Not yet']].map(o => '<label class="rf-tog"><input type="radio" name="screened" value="' + o[0] + '"' + (f.screened === o[0] ? ' checked' : '') + '><span>' + I.check + o[1] + '</span></label>').join('') + '</span>' + (e.screened ? '<small class="vol-err">' + esc(e.screened) + '</small>' : '<small>Shown to the committee head only</small>') + '</fieldset>';
    out += '<details class="vol-other"' + (f.note ? ' open' : '') + '><summary>Note</summary><label class="vol-f"><span class="ogc-sr">Note for the head</span><input name="note" maxlength="200" value="' + esc(f.note || '') + '"><small>For the committee head only</small></label></details>';
    return out;
  }

  // Same job, same time, Other days (the same words as a full shift's): only the days with a place open
  // and nothing in the way, and nothing drawn when there are none.
  function alsoDays(sh) {
    const xs = state.shifts.filter(x => x !== sh && x.committee === sh.committee && x.role === sh.role && x.start === sh.start && x.end === sh.end && !minesOn(x).length && joinable(x) && open(x) > 0 && !chosen().some(n => clash(n, x))).sort((a, b) => sortKey(a) - sortKey(b));
    if (!xs.length) return '';
    const sel = (state.form && state.form.also) || [];
    return '<fieldset class="vol-also"><legend class="rf-label">Other days</legend><span class="rf-seg">' + xs.map(x =>
      '<label class="rf-tog"><input type="checkbox" name="also" value="' + esc(x.id) + '"' + (sel.indexOf(x.id) > -1 ? ' checked' : '') + '><span>' + I.check + esc(dayWord(eve(x)).slice(0, 3)) + ' · ' + esc(openText(x)) + '</span></label>').join('') + '</span></fieldset>';
  }

  // Unconfirmed: where the email went (in full: she typed it, and may have mistyped it), Resend and
  // Change email for as long as it's unconfirmed (in the sheet and in Your shifts), and what happens
  // if it stays so (only when the COA lets places go).
  function confirmHelp(ids, where) {
    const to = (state.done && state.done.email) || (me() && me().email) || '', h = +live().confirm_hours || 0;
    const ed = state.emailEdit === where;
    const box = ed ? '<form class="vol-chemail" data-emailform="' + esc(where) + '" data-ids="' + esc(ids.join(' ')) + '" novalidate><label class="vol-f' + (state.emailErr ? ' is-bad' : '') + '"><span>Email</span><input name="email" type="email" autocomplete="email" inputmode="email" value="' + esc(state.emailVal != null ? state.emailVal : to) + '"' + (state.emailErr ? ' aria-invalid="true"' : '') + '>' +
        (state.emailFix ? '<small class="vol-err">' + esc(domainOf(state.emailVal)) + '? · <button type="button" class="wk-linklike" data-emailfix>Use ' + esc(domainOf(state.emailFix)) + '</button> · <button type="button" class="wk-linklike" data-emailkeep>Keep</button></small>' : state.emailErr ? '<small class="vol-err">' + esc(state.emailErr) + '</small>' : '<small>The confirmation goes here</small>') + '</label>' +
        '<p class="vol-chemail__btns"><button type="submit" class="wk-btn wk-btn--small">Send</button> <button type="button" class="wk-linklike" data-emailoff>Cancel</button></p></form>' : '';
    return '<p class="vol-statehelp">' + (to ? 'Sent to <b>' + esc(to) + '</b><br>' : '') +
      (ed ? '' : '<span class="vol-ctools"><button type="button" class="wk-linklike" data-resend="' + esc(ids.join(' ')) + '">Resend</button> · <button type="button" class="wk-linklike" data-chemail="' + esc(where) + '">Change email</button></span>') +
      (h > 0 ? '<br><small>Unconfirmed places open again after ' + h + ' hours</small>' : '') + '</p>' + box;
  }
  const domainOf = e => String(e || '').split('@')[1] || '';
  async function resend(ids) {
    try { const d = await post('vol/' + state.year + '/resend', { ids: ids.map(Number) }); showToast({ kind: 'ok', text: 'Sent', sub: d.email || '' }); }
    catch (e) { showToast({ kind: e.status === 429 ? 'ok' : 'error', text: e.status === 429 ? 'Sent · Just now' : 'Not sent · Retry' }); }
  }
  // Change email: the same place, the confirmation sent to the new address (a likely typo asked once).
  async function changeEmail(form, typosOk) {
    const val = form.email.value.trim(), ids = form.dataset.ids.split(' ').map(Number), where = form.dataset.emailform;
    state.emailVal = val; state.emailErr = ''; state.emailFix = '';
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(val)) { state.emailErr = 'Enter your email'; return redrawEmail(where); }
    try {
      const d = await post('vol/' + state.year + '/email', { ids, email: val, typos_ok: !!typosOk });
      merge(d);
      if (!signed()) tab.set('typed', Object.assign({}, tab.get('typed', {}), { email: d.email }));
      if (state.done) state.done.email = d.email;
      if (live().me) live().me.email = d.email;
      state.emailEdit = ''; state.emailVal = null;
      render(); if (sheet.open && state.sheet) drawSheet();
      showToast({ kind: 'ok', text: 'Sent', sub: d.email });
    } catch (e) {
      if (e.data && e.data.why === 'typo') state.emailFix = e.data.fix;
      else state.emailErr = e.data && e.data.fields ? e.data.fields.email : e.status === 429 ? 'Too many at once · Try later' : 'Not saved · Retry';
      redrawEmail(where);
    }
  }
  function redrawEmail(where) {
    if (where === 'sheet') drawSheet(); else render();
    const x = (where === 'sheet' ? sheet : root).querySelector('[data-emailform] input');
    if (x) x.focus();
  }
  function emailClick(b) {
    const ds = b.dataset;
    if (ds.resend) { resend(ds.resend.split(' ')); return true; }
    if (ds.chemail) { state.emailEdit = ds.chemail; state.emailVal = null; state.emailErr = ''; state.emailFix = ''; redrawEmail(ds.chemail); return true; }
    if (b.hasAttribute('data-emailoff')) { const w = state.emailEdit; state.emailEdit = ''; if (w === 'sheet') drawSheet(); else render(); return true; }
    if (b.hasAttribute('data-emailfix')) { const f = b.closest('form'); f.email.value = state.emailVal.split('@')[0] + '@' + domainOf(state.emailFix); changeEmail(f, true); return true; }
    if (b.hasAttribute('data-emailkeep')) { changeEmail(b.closest('form'), true); return true; }
    return false;
  }

  function drawSheet() {
    const sh = find(state.sheet);
    if (!sh) return;
    const you = minesOn(sh), s = st(sh), o = open(sh), ppl = seatsOf(sh), c = sh.committee, waiting = waitsOn(sh);
    const full = s === 'full' || (s === 'open' && o <= 0);
    const swapSeat = !you.length && ppl.find(p => p.swap);
    // Yourself isn't named back to you (a visitor's own name is the one she signed up under).
    const self = selfName();
    // The state first: on it, waiting, a swap offered.
    // The state, said once, under the title: "Signed up · Check your email", and under it the address it
    // went to (in full: she typed it on this device, and may have mistyped it) and what happens if not.
    const unconf = you.some(m => !m.confirmed);
    const chip = you.length ? '<p class="vol-chip">' + I.check + '<span>Signed up' + (you.length > 1 || (you[0] && you[0].name !== self) ? ' · ' + esc(you.map(m => first(m.name)).join(', ')) : '') + (unconf ? ' · Check your email' : '') + (you.some(m => m.swap) ? ' · Swap open' : '') + '</span></p>' +
        (unconf ? confirmHelp(you.filter(m => !m.confirmed).map(m => m.rid), 'sheet') : '')
      : waiting.length ? '<p class="vol-chip is-wait">' + I.mail + '<span>On waitlist' + (o > 0 && s === 'open' ? ' · ' + o + ' open' : '') + '</span></p>' : '';
    const placeLine = sh.place ? '<div class="vol-place">' + I.pin + '<span>' + esc(sh.place.name) + '</span>' + (whereMap(sh.place, true) ? '<button type="button" class="wk-linklike" data-map aria-expanded="' + !!state.mapOpen + '">Map</button>' : '') + '</div>' + (state.mapOpen ? whereMap(sh.place) : '') : '';
    const phone = comm(c).phone;
    // Who's on it: the people (yours first), then up to six outlines for the open places (the number is
    // said once, in the heading: "Volunteers · 19 open"; never "+ 13", which reads as more people).
    const ord = ppl.filter(p => p.you).concat(ppl.filter(p => !p.you && p.l), ppl.filter(p => !p.you && !p.l));
    const shownP = names() ? ord.filter(p => p.you || p.l) : ord.filter(p => p.you);
    const anonN = ord.length - shownP.length;
    const list = '<ul class="vol-onlist">' + shownP.map(p => '<li' + (p.you && state.done ? ' class="is-new"' : '') + '>' + seat(p) + '<span>' + esc(p.you ? ownWord(p) : p.l) + (p.swap ? ' <small class="vol-tag">Swap open</small>' : '') + '</span></li>').join('') + '</ul>' +
      '<p class="vol-onrest">' + (anonN ? '<span class="vol-seats" aria-hidden="true">' + ord.filter(p => !shownP.includes(p)).slice(0, 6).map(seat).join('') + '</span>' + esc((shownP.length ? '+ ' : '') + plural(anonN, 'volunteer')) + (sh.unlimited || o <= 0 ? '' : ' ') : '') +
      (sh.unlimited || o <= 0 ? '' : '<span class="vol-seats" aria-hidden="true">' + Array.from({ length: Math.min(6, o) }, () => seat(null)).join('') + '</span><span class="ogc-sr">' + o + ' open</span>') + '</p>';
    // One number, the public pages' own: "4 open" (or Full), "13 coming", or after the week "4 helped".
    const countH = closed() ? (L(sh).f ? L(sh).f + ' helped' : '') : sh.unlimited ? L(sh).f + ' coming' : o > 0 ? o + ' open' : 'Full';
    // Full: the same job with places open on other days, one tap each.
    const alt = full && !you.length ? state.shifts.filter(x => x !== sh && x.committee === c && x.role === sh.role && joinable(x) && open(x) > 0).sort((a, b) => sortKey(a) - sortKey(b)).slice(0, 4) : [];
    const altHtml = alt.length ? '<div class="vol-alt"><p class="rf-label">Other days</p><ul>' + alt.map(x => '<li><button type="button" class="wk-linklike" data-shift="' + esc(x.id) + '">' + esc(whenShort(x)) + '</button> · ' + esc(openText(x)) + '</li>').join('') + '</ul></div>' : '';
    const formOpen = !!state.form && !you.length;
    // While the form is open, the shift stays in sight: a line pinned at the top once its title scrolls away.
    const pin = formOpen ? '<p class="vol-pin" aria-hidden="true">' + esc(sh.role + ' · ' + whenShort(sh)) + '</p>' : '';
    sheet.classList.remove('is-pinned');
    sheet.innerHTML = '<div class="vol-sheet__scroll">' + pin + '<div class="wk-sheet__in"><button type="button" class="wk-sheet__x" data-close aria-label="Close">' + I.close + '</button>' +
      '<p class="wk-kicker">' + esc(whenLong(sh) + ', ' + eve(sh).date.slice(0, 4)) + (night(sh) ? ' <small class="vol-true">' + esc(O.fmtDate(sh.day.date, 'weekdayShort') + ' ' + span(sh)) + '</small>' : '') + '</p>' +
      '<h2 class="wk-sheet__h" id="vol-sheet-t">' + esc(sh.role) + '</h2>' +
      // The committee link, unless it only repeats the title (Kit packing · Kit packing).
      '<p class="wk-sheet__when">' + esc(span(sh)) + (c.toLowerCase() === sh.role.toLowerCase() ? '' : ' · <a href="?year=' + esc(state.year) + '&committee=' + encodeURIComponent(c) + '" data-pick="' + esc(c) + '">' + esc(c) + '</a>') + '</p>' + chip +
      placeLine + (sh.note ? '<p class="wk-sheet__note">' + esc(sh.note) + '</p>' : '') +
      (ruleShort(sh) ? '<p class="vol-rulechip">' + I.rule + esc(ruleShort(sh)) + '</p>' : '') +
      (phone ? '<p class="vol-ask">Questions · <a href="tel:' + esc(phone.replace(/[^\d+]/g, '')) + '">' + esc(phone) + '</a></p>' : '') +
      (closed() && !L(sh).f ? '' : '<div class="vol-on"><p class="vol-on__h"><span>Volunteers <small>· ' + esc(countH) + '</small></span>' + (closed() || (s !== 'open' && s !== 'full') ? '' : '<button type="button" class="wk-linklike vol-invite" data-invite="' + esc(sh.id) + '">' + I.link + 'Invite</button>') + '</p>' + (closed() ? '' : list) + '</div>') +
      altHtml + (formOpen ? '<form class="vol-join" novalidate data-form="' + esc(sh.id) + '">' + joinForm(sh, full) + (full ? '' : alsoDays(sh)) + '</form>' : '') +
      '<p class="vol-invited" data-invited hidden></p></div></div>' + sheetBar(sh, { you, s, o, full, waiting, swapSeat });
    sheet.querySelectorAll('[data-form] input, [data-form] details').forEach(x => x.addEventListener('change', keepForm));
  }

  // The bar at the bottom of the sheet: the one action for the shift's state.
  function sheetBar(sh, k) {
    const ab = state.busyAct, c = sh.committee;
    let inner;
    if (state.leaving === sh.id) {
      // Leave asks first, and steers to a replacement (the committee still needs the place filled).
      const ys = k.you;
      inner = '<div class="vol-bar__ask"><p>Leave this shift? <small>The ' + esc(c) + ' head is told.</small></p>' +
        (ys.length > 1 ? '<span class="rf-seg">' + ys.map(m => '<label class="rf-tog"><input type="checkbox" name="leavewho" value="' + m.rid + '" checked><span>' + I.check + esc(first(m.name)) + '</span></label>').join('') + '</span>' : '') +
        // The filled button is what they asked for (Leave shift). Find replacement only where a place is
        // hard to fill again: the shift is full or one place from it.
        '<p class="vol-bar__btns"><button type="button" class="wk-btn wk-btn--small" data-leavego' + (ab ? ' disabled' : '') + '>' + (ab === 'leave' ? 'Leaving…' : 'Leave shift') + '</button>' +
        (ys.some(m => m.swap) || !(k.full || k.o <= 1) ? '' : '<button type="button" class="wk-linklike" data-swapon' + (ab ? ' disabled' : '') + '>Find replacement</button>') +
        '<button type="button" class="wk-linklike" data-leaveoff>Keep</button></p></div>';
    } else if (k.you.length) {
      const swap = k.you.find(m => m.swap);
      inner = k.s === 'started' || k.s === 'ended'
        ? '<p class="vol-bar__msg">' + I.check + 'Signed up' + (comm(c).phone ? ' · Can’t come? Call ' + esc(comm(c).phone) : '') + '</p>'
        // A swap open: the link is the one thing to do; Cancel swap and Leave shift stay quiet.
        : swap ? '<p class="vol-bar__btns"><button type="button" class="wk-btn wk-btn--small" data-swapcopy="' + esc(swap.swap) + '">' + I.link + 'Copy link</button><button type="button" class="wk-linklike" data-swapoff="' + swap.rid + '">Cancel swap</button><button type="button" class="wk-linklike" data-leave="' + esc(sh.id) + '">Leave shift</button></p>'
        : '<p class="vol-bar__btns"><button type="button" class="wk-btn wk-btn--line wk-btn--small" data-ics="' + esc(sh.id) + '">' + I.cal + 'Calendar</button><button type="button" class="wk-linklike" data-leave="' + esc(sh.id) + '">Leave shift</button></p>';
    } else if (STATE_WORD[k.s] || k.s === 'not_open') {
      inner = '<p class="vol-bar__msg is-muted"' + stateTip(k.s) + '>' + esc(stateWord(k.s)) + '</p>';
    } else if (k.swapSeat && (state.swap || q.get('swap'))) {
      inner = '<p class="vol-bar__btns vol-bar__btns--one"><button type="button" class="wk-btn" data-take' + (ab ? ' disabled' : '') + '>' + (ab === 'take' ? 'Taking…' : 'Take place') + '</button></p>';
    } else if (k.full) {
      const busy = signed() && chosen().map(n => clash(n, sh)).find(Boolean);
      inner = k.waiting.length ? '<p class="vol-bar__msg">' + I.mail + 'On waitlist</p><p class="vol-bar__btns"><button type="button" class="wk-linklike" data-unwait="' + k.waiting[0].rid + '">Leave waitlist</button></p>'
        : busy ? busyBar(busy)
        : '<p class="vol-bar__btns vol-bar__btns--one">' + (k.swapSeat ? '<button type="button" class="wk-btn" data-take' + (ab ? ' disabled' : '') + '>' + (ab === 'take' ? 'Taking…' : 'Take place') + '</button>' : '<button type="button" class="wk-btn" data-waitnow' + (ab ? ' disabled' : '') + '>' + (ab === 'wait' ? 'Joining…' : 'Join waitlist') + '</button>') + '<small>' + (k.swapSeat ? esc((k.swapSeat.l && names() ? k.swapSeat.l : 'Someone') + ' is looking for a replacement') : 'Email when a place opens') + '</small></p>';
    } else {
      const busy = signed() && chosen().length === 1 && clash(chosen()[0], sh);
      // A household sees who before it taps: "Join · Esther", with Change (the Who pills open above).
      const who = signed() && people().length > 1 && !(state.form && state.form.people) ? ' <button type="button" class="wk-linklike" data-whoedit>Change</button>' : '';
      inner = busy ? busyBar(busy) : '<p class="vol-bar__btns vol-bar__btns--one"><button type="button" class="wk-btn vol-joinbtn" data-joinnow' + (ab ? ' disabled' : '') + '>' + (ab === 'join' ? 'Joining…' : esc(joinWord(sh))) + '</button>' + who + (state.barErr ? '<small class="vol-err" role="alert">' + esc(state.barErr) + '</small>' : '') + '</p>';
    }
    return '<div class="vol-bar">' + (state.barNote && state.barNote.until > Date.now() ? state.barNote.html : '') + inner + '</div>';
  }
  const busyBar = b => '<p class="vol-bar__msg">' + esc(busyWords(b)) + '</p><p class="vol-bar__btns"><button type="button" class="wk-btn wk-btn--line wk-btn--small" data-shift="' + esc(b.id) + '">View</button></p>';
  // Join names what it joins: who, for a household ("Join · Esther"); several days ("Join · 3 shifts");
  // else the shift itself ("Join · Fri 2–6 PM"), so the form's button never just repeats "Join".
  function joinWord(sh) {
    const f = state.form || {}, n = 1 + ((f.also || []).length);
    const ps = f.people && f.people.length ? f.people : signed() && people().length > 1 ? chosen() : [];
    return n > 1 ? 'Join · ' + plural(n, 'shift') : ps.length ? 'Join · ' + ps.map(first).join(', ') : 'Join · ' + O.fmtDate(eve(sh).date, 'weekdayShort') + (night(sh) ? ' night' : '') + ' ' + span(sh);
  }

  // The form's values, kept as they're typed (a redraw never loses them).
  function keepForm() {
    const f = sheet.querySelector('[data-form]');
    if (!f) return;
    const d = state.form || (state.form = {});
    ['first', 'last', 'email', 'phone', 'oname', 'ophone', 'note'].forEach(k => { if (f[k]) d[k] = f[k].value; });
    d.rule = !!(f.rule && f.rule.checked);
    const qv = f.querySelector('[name=question]:checked'); d.question = qv ? qv.value : '';
    const sv = f.querySelector('[name=screened]:checked'); d.screened = sv ? sv.value : '';
    d.people = Array.from(f.querySelectorAll('[name=who]:checked')).map(x => x.value);
    if (!f.querySelector('[name=who]')) delete d.people;
    d.also = Array.from(f.querySelectorAll('[name=also]:checked')).map(x => x.value);
    const det = f.querySelector('.vol-other'); d.other = !!(det && det.open && d.oname);
    // Common email typos, caught before Join.
    state.typo = typoFix(d.email);
    const ef = f.email && f.email.closest('.vol-f'), sm = ef && !ef.classList.contains('is-bad') && ef.querySelector('small');
    const want = state.typo ? 'Did you mean ' + state.typo + '?' : 'For your confirmation';
    if (sm && sm.textContent !== want) sm.innerHTML = state.typo ? 'Did you mean <button type="button" class="wk-linklike" data-typo>' + esc(state.typo) + '</button>?' : 'For your confirmation';
    const btn = sheet.querySelector('.vol-joinbtn'); if (btn && !state.busyAct) btn.textContent = joinWord(find(state.sheet));
  }
  const DOMAINS = { 'gmial.com': 'gmail.com', 'gmai.com': 'gmail.com', 'gmal.com': 'gmail.com', 'gmail.co': 'gmail.com', 'gnail.com': 'gmail.com', 'yaho.com': 'yahoo.com', 'yahooo.com': 'yahoo.com', 'hotmial.com': 'hotmail.com', 'outlok.com': 'outlook.com', 'aol.co': 'aol.com', 'icloud.co': 'icloud.com' };
  const typoFix = e => { const m = /^([^@\s]+)@([^@\s]+)$/.exec(String(e || '').trim()); return m && DOMAINS[m[2].toLowerCase()] ? m[1] + '@' + DOMAINS[m[2].toLowerCase()] : ''; };

  // Where the shift is, on the campus map; in the week (or a preview), Directions in the guide.
  function whereMap(p, test) {
    const c = state.campus, b = c && O.map && O.map.buildingFor(c, p, state.model.places);
    if (!b) return '';
    if (test) return true;
    const marksB = [b.name].concat(c.items.filter(i => (i.kind === 'dining' || i.kind === 'worship') && i.name !== b.name).map(i => i.name));
    const preview = q.get('preview') === '1';
    const guide = (W.base || '/annual-conference/') + 'guide/?year=' + encodeURIComponent(state.year) + '&view=places&to=' + encodeURIComponent(p.code) + (preview ? '&preview=1' : '');
    // The map area's small map: the shift's building in tan among grey, its pin or door named under it, the credit; in the week, a tap opens the guide's route.
    return (O.map.mini ? O.map.mini(c, p, state.model.places, isWeek() || preview ? { href: guide, hrefTitle: 'Directions' } : {}) : '<div class="vol-map">' + O.map.campusSvg(c, { mark: b.name, fit: marksB, small: true, aspect: 340 / 180, title: p.name + ' on the campus map' }) + '</div>') +
      (isWeek() || preview ? '<p class="wk-sheet__btns vol-map__go"><a class="wk-btn wk-btn--line wk-btn--small" href="' + esc(guide) + '">' + I.pin + 'Directions</a></p>' : '');
  }

  /* ---------------------------------------------------------------- joining */

  // What the server said no to, as a word and a next step.
  function refusal(r, sh) {
    const n = r.name ? first(r.name) + ' · ' : '';
    switch (r.status) {
      case 'full': return { msg: 'Just filled', act: 'wait' };
      case 'busy': return { msg: n + busyOf(r.busy), view: r.busy.shift };
      case 'minor': return { msg: n + 'Under ' + r.min_age };
      case 'rule': return { msg: minAge(sh) ? 'Confirm ' + minAge(sh) + ' or older' : 'Confirm the rule', field: 'rule' };
      case 'screening': return { msg: 'Screening first', field: 'screened' };
      case 'dup': return { msg: n + 'Already signed up' };
      case 'started': return { msg: 'Started' };
      case 'ended': return { msg: 'Ended' };
      case 'closed': return { msg: 'Closed' };
      case 'not_open': return { msg: 'Not open yet' };
      case 'gone': return { msg: 'No longer offered' };
      default: return { msg: 'Not saved' };
    }
  }

  // The body a Join sends: who, the rule's answer, the note; the people from the household pills or
  // the line's choice.
  function joinBody(sh, f, ids) {
    f = f || {};
    const b = { shifts: ids || [sh.id], answers: {}, show: true };
    if (vouched()) b.people = state.link.names && state.link.names.length ? state.link.names : undefined;
    else if (!signed()) b.who = { first: (f.first || '').trim(), last: (f.last || '').trim(), email: (f.email || '').trim(), phone: (f.phone || '').trim() };
    else if (f.phone || f.first) b.who = { first: (f.first || '').trim(), last: (f.last || '').trim(), phone: (f.phone || '').trim() };
    if (signed()) { const ps = f.people && f.people.length ? f.people : chosen(); if (ps.length && (ps.length > 1 || ps[0] !== myName())) b.people = ps; }
    if (f.other && f.oname) { b.for_other = { name: f.oname.trim(), phone: (f.ophone || '').trim() }; delete b.people; }
    if (f.rule) b.answers.rule = true;
    if (f.question) b.answers.question = f.question;
    if (f.screened) b.answers.screened = f.screened;
    if (f.note) b.note = f.note;
    if (f.hp) b.hp = f.hp;
    if (state.link && state.link.via && (state.link.a === 'opened' || state.link.a === 'again')) Object.assign(b, state.link.via);
    return b;
  }

  // Check the form here first (the server checks again): every error at its field, focus on the first.
  function checkForm(sh, waiting) {
    const f = state.form || {}, e = {};
    if (vouched()) { /* the link's email, the phone given before */ }
    else if (!signed()) {
      if (!String(f.first || '').trim()) e.first = 'Enter your first name';
      if (!String(f.last || '').trim()) e.last = 'Enter your last name';
      if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(String(f.email || '').trim())) e.email = 'Enter your email';
      if (String(f.phone || '').replace(/\D/g, '').length < 7) e.phone = 'Enter a phone number';
    } else if (!me().phone && String(f.phone || '').replace(/\D/g, '').length < 7 && !(f.other && f.oname)) e.phone = 'Enter a phone number';
    if (signed() && !myName() && !hh().length && !(f.other && f.oname)) { if (!String(f.first || '').trim()) e.first = 'Enter your first name'; if (!String(f.last || '').trim()) e.last = 'Enter your last name'; }
    if (f.other && f.oname && String(f.ophone || '').replace(/\D/g, '').length < 7) e.ophone = 'Enter their phone';
    if (f.other && f.oname && !/\s/.test(f.oname.trim())) e.oname = 'First and last';
    if (!waiting) {
      if (question(sh).length && !f.question) e.rule = 'Choose one';
      else if (sh.rule && !question(sh).length && !f.rule) e.rule = minAge(sh) ? 'Confirm ' + minAge(sh) + ' or older' : 'Confirm the rule';
      if (screening(sh) && !f.screened) e.screened = 'Choose one';
      if (signed() && people().length > 1 && f.people && !f.people.length) e.who = 'Choose who';
    }
    return e;
  }

  // Join from a row: scroll the form into view below the pinned line (which keeps the shift named), and
  // put the cursor in the first field (or the one named).
  function revealForm(name) {
    const sc = sheet.querySelector('.vol-sheet__scroll'), top = sheet.querySelector('.vol-before') || sheet.querySelector('[data-form]');
    if (sc && top) sc.scrollTop += top.getBoundingClientRect().top - sc.getBoundingClientRect().top - 56;
    pinCheck();
    const x = sheet.querySelector(name ? '[data-form] [name="' + name + '"]' : '[data-form] input:not([type=hidden]):not(.vol-hp)');
    if (x) { x.focus({ preventScroll: true }); if (name && x.select) x.select(); }
  }
  // The first field with an error, in the middle of the sheet, so its message is never under the bar.
  function revealError() {
    const bad = sheet.querySelector('[aria-invalid="true"], .is-bad input, .is-bad');
    if (!bad) return;
    const box = bad.closest('.vol-f, .vol-q, .vol-claim, .vol-whof') || bad;
    box.scrollIntoView({ block: 'center' });
    (bad.matches('input') ? bad : (box.querySelector('input') || bad)).focus({ preventScroll: true });
  }
  // The pinned line shows once the sheet's title has scrolled out of sight.
  function pinCheck() {
    const sc = sheet.querySelector('.vol-sheet__scroll'), h = sheet.querySelector('#vol-sheet-t');
    if (sc && h) sheet.classList.toggle('is-pinned', !!sheet.querySelector('.vol-pin') && h.getBoundingClientRect().bottom < sc.getBoundingClientRect().top + 4);
  }
  sheet.addEventListener('scroll', pinCheck, true);

  async function joinNow(sh) {
    if (state.busyAct) return;
    if (!state.form) {
      // One tap when nothing needs asking; otherwise the form unfolds above the bar.
      if (oneTap(sh)) return send(sh, {}, [sh.id]);
      state.form = {}; drawSheet(); revealForm();
      return;
    }
    keepForm();
    const e = checkForm(sh, false);
    // A likely typo in the email ("gmial.com") stops Join once, at the field: Use gmail.com · Keep.
    const fix = !signed() && !vouched() && typoFix(state.form.email);
    if (!Object.keys(e).length && fix && state.typoOk !== state.form.email) {
      e.email = { text: domainOf(state.form.email) + '? Use ' + domainOf(fix) + ' or keep', html: esc(domainOf(state.form.email)) + '? · <button type="button" class="wk-linklike" data-typo>Use ' + esc(domainOf(fix)) + '</button> · <button type="button" class="wk-linklike" data-typokeep>Keep</button>' };
    }
    state.err = Object.keys(e).length ? e : null;
    if (state.err) {
      drawSheet(); revealError();
      say.textContent = Object.values(e).map(x => x.text || x).join('. ');
      return;
    }
    send(sh, state.form, [sh.id].concat(state.form.also || []));
  }

  // Send a join and show what came back: success only when the server confirms it.
  async function send(sh, f, ids, fromRow) {
    state.busyAct = 'join'; state.barErr = '';
    if (sheet.open) drawSheet(); else rowBusy(sh.id, true);
    let d;
    try {
      d = await post('vol/' + state.year + '/join', joinBody(sh, f, ids));
    } catch (err) {
      state.busyAct = '';
      if (err.data && err.data.why === 'fields') { state.form = state.form || {}; state.err = err.data.fields; if (!sheet.open) openShift(sh.id); else drawSheet(); revealError(); return; }
      state.barErr = err.status === 429 ? (err.data && err.data.why === 'confirm' ? 'Confirm your email first · The link is in your inbox' : 'Too many at once · Try later') : 'Not saved · Retry';
      if (sheet.open) drawSheet(); else { rowBusy(sh.id, false); showToast({ kind: 'error', text: 'Not saved', retry: () => send(sh, f, ids, fromRow) }); }
      return;
    }
    state.busyAct = '';
    merge(d);
    if (f && !signed() && f.email) tab.set('typed', { first: f.first, last: f.last, email: d.email || f.email });
    if (f && !signed() && f.phone) tabPhone = f.phone;
    const ok = d.results.filter(r => r.status === 'ok'), no = d.results.filter(r => r.status !== 'ok');
    const made = d.made || (d.mine || []).filter(m => ok.some(r => r.shift === m.shift) && Date.now() - Date.parse(String(m.at).replace(' ', 'T') + 'Z') < 600000).map(m => m.rid);
    render();
    if (ok.length) {
      const names2 = ok[0].names || [];
      state.done = sheet.open && state.sheet === sh.id ? { names: names2, email: d.email || (f && f.email) || '', ids: made } : null;
      state.form = null; state.err = null;
      // From a line, a toast with Undo; in the sheet, its state line says it (a toast would sit behind it).
      if (!sheet.open) showToast({ kind: 'ok', text: 'Signed up', sub: ok.length > 1 ? plural(ok.length, 'shift') : sh.role + ', ' + whenShort(sh), ids: made, shifts: ok.map(r => r.shift) });
      say.textContent = 'Signed up · ' + (ok.length > 1 ? plural(ok.length, 'shift') : sh.role + ', ' + whenLong(sh));
    }
    if (no.length) {
      const r = no[0], why = refusal(r, find(r.shift) || sh);
      if (sheet.open) { state.barErr = why.msg; if (why.field) { state.form = state.form || {}; state.err = { [why.field]: why.msg }; } }
      else showToast({ kind: 'no', text: why.msg, sub: find(r.shift) ? find(r.shift).role : '', wait: why.act === 'wait' ? r.shift : '', view: why.view || '' });
      if (!ok.length) say.textContent = why.msg;
    }
    if (sheet.open) drawSheet();
    // Focus where the person is: the row's new status, or the toast's Undo.
    if (!sheet.open) { const x = root.querySelector('[data-status="' + CSS.escape(sh.id) + '"]') || bar.querySelector('[data-undo]'); if (x) x.focus(); }
    else if (state.err) revealError();
    else { const x = sheet.querySelector('.vol-chip, .vol-bar .wk-btn'); if (x) { if (!x.matches('button, input')) x.setAttribute('tabindex', '-1'); x.focus(); } }
  }
  function rowBusy(id, on) {
    const b = root.querySelector('[data-join="' + CSS.escape(id) + '"]');
    if (b) { b.disabled = on; b.textContent = on ? 'Joining…' : 'Join'; b.style.minWidth = on ? b.offsetWidth + 'px' : ''; }
  }

  // From a line: one tap when nothing needs asking; otherwise the sheet opens with the form unfolded.
  function join(id) {
    const sh = find(id);
    if (!sh) return;
    if (oneTap(sh)) return send(sh, {}, [id], true);
    openShift(id); state.form = state.form || {}; drawSheet(); revealForm();
  }

  async function undo(ids) {
    try { merge(await post('vol/' + state.year + '/undo', { ids })); hideToast(); render(); if (sheet.open) { state.done = null; drawSheet(); } say.textContent = 'Undone'; }
    catch (e) { showToast({ kind: 'error', text: 'Not undone · Leave shift instead' }); }
  }

  async function leave(sh) {
    // A "Confirmed · 2 shifts" line from the email's link no longer holds once one is left.
    if (state.link && state.link.a === 'confirm') state.link = null;
    const box = sheet.querySelectorAll('[name=leavewho]');
    const ids = box.length ? Array.from(box).filter(x => x.checked).map(x => +x.value) : minesOn(sh).map(m => m.rid);
    if (!ids.length) return;
    state.busyAct = 'leave'; drawSheet();
    try {
      merge(await post('vol/' + state.year + '/leave', { ids }));
      state.busyAct = ''; state.leaving = ''; state.done = null;
      // A Join's toast (Undo) for a place just left is out of date.
      if (state.toast && (state.toast.ids || []).some(x => ids.indexOf(x) > -1)) hideToast();
      render(); drawSheet();
      showToast({ kind: 'ok', text: 'Left shift', sub: sh.role + ', ' + whenShort(sh) });
      say.textContent = 'Left shift';
    } catch (e) {
      state.busyAct = ''; state.barErr = e.data && e.data.why === 'started' ? 'Started · Call the head' : 'Not saved · Retry'; drawSheet();
    }
  }

  async function waitFor(sh, f) {
    if (!signed() && !f) { openShift(sh.id); state.form = {}; drawSheet(); revealForm(); return; }
    if (f) { const e = checkForm(sh, true); if (Object.keys(e).length) { state.err = e; drawSheet(); revealError(); return; } }
    state.busyAct = 'wait'; if (sheet.open) drawSheet();
    try {
      const b = { shift: sh.id };
      if (f && !signed()) b.who = { first: f.first, last: f.last, email: f.email, phone: f.phone };
      if (signed() && people().length > 1) b.people = chosen();
      merge(await post('vol/' + state.year + '/wait', b));
      state.busyAct = ''; state.form = null;
      render(); if (sheet.open) drawSheet();
      showToast({ kind: 'ok', text: 'On waitlist', sub: sh.role + ' · Email when a place opens' });
    } catch (e) {
      state.busyAct = ''; state.barErr = 'Not saved · Retry'; if (sheet.open) drawSheet();
    }
  }

  // Find replacement: the place stays yours, marked Swap open; the link lets anyone take it at once.
  async function swap(sh, on, rid) {
    const r = rid || (minesOn(sh)[0] || {}).rid;
    try {
      const d = await post('vol/' + state.year + '/swap', { id: r, on });
      merge(d); state.leaving = ''; await refresh(true);
      if (on && d.swap) copyLink(swapUrl(sh, d.swap), 'Link copied', 'Could you take my place? ' + sh.role + ', ' + whenShort(sh));
      else drawSheet();
    } catch (e) { state.barErr = 'Not saved · Retry'; drawSheet(); }
  }
  const swapUrl = (sh, token) => location.origin + location.pathname + '?year=' + state.year + '&shift=' + encodeURIComponent(sh.id) + '&swap=' + encodeURIComponent(token);

  async function take(sh) {
    const seatSwap = seatsOf(sh).find(p => p.swap);
    const token = state.swap || q.get('swap') || (seatSwap ? seatSwap.swap + '.' : '');
    if (!signed() && !state.form) { state.form = {}; drawSheet(); revealForm(); return; }
    if (state.form) { keepForm(); const e = checkForm(sh, true); if (Object.keys(e).length) { state.err = e; drawSheet(); revealError(); return; } }
    state.busyAct = 'take'; drawSheet();
    try {
      const f = state.form || {};
      const d = await post('vol/' + state.year + '/take', { swap: String(token), who: signed() ? undefined : { first: f.first, last: f.last, email: f.email, phone: f.phone }, answers: { rule: true } });
      merge(d); state.busyAct = ''; state.form = null; state.swap = '';
      state.done = { names: [(f.first ? f.first + ' ' + f.last : myName())], email: f.email || (me() || {}).email };
      render(); drawSheet();
      showToast({ kind: 'ok', text: 'Signed up', sub: sh.role + ', ' + whenShort(sh) });
    } catch (e) {
      state.busyAct = ''; state.barErr = e.data && e.data.why === 'busy' ? busyOf(e.data.busy) : e.data && e.data.why === 'taken' ? 'Taken' : 'Not saved · Retry'; drawSheet();
    }
  }

  // Invite someone: a link to this shift, by the phone's own Share, or copied.
  function invite(id) {
    const sh = find(id), u = location.origin + location.pathname + '?year=' + state.year + '&shift=' + encodeURIComponent(id);
    // "Join me" only from someone on it; anyone else shares the shift and what's open.
    copyLink(u, 'Link copied', minesOn(sh).length ? 'Join me: ' + sh.role + ', ' + whenShort(sh) + ' · ' + state.year + ' Annual Conference' : sh.role + ' · ' + whenShort(sh) + ' · ' + state.year + ' Annual Conference' + (open(sh) > 0 && open(sh) !== Infinity ? ' · ' + open(sh) + ' open' : ''));
  }
  function copyLink(url, done, text) {
    const shown = msg => { const p = sheet.querySelector('[data-invited]'); if (p) { p.hidden = false; p.innerHTML = msg; } };
    if (navigator.share && /Mobi|Android/i.test(navigator.userAgent)) { navigator.share({ text, url }).catch(() => {}); return; }
    // Said where it's seen: a toast above the bar (the sheet's own line sat under it, out of sight).
    const ok = () => { showToast({ kind: 'ok', text: done }); say.textContent = done; };
    const manual = () => shown('<label>Link<input readonly value="' + esc(url) + '" onfocus="this.select()"></label>');
    try { navigator.clipboard.writeText(url).then(ok, manual); } catch (e) { manual(); }
  }

  /* ---------------------------------------------------------------- the toast */

  const bar = document.createElement('div');
  bar.className = 'ogc vol-toast';
  bar.setAttribute('role', 'status');
  bar.hidden = true;
  document.body.appendChild(bar);
  let toastTimer = 0;
  let noteTimer = 0;
  const barNoteHtml = t => '<p class="vol-bar__note' + (t.kind === 'ok' ? '' : ' is-no') + '" role="status">' + (t.kind === 'ok' ? I.check : I.alert) + '<span>' + esc(t.text + (t.sub ? ' · ' + t.sub : '')) + '</span></p>';
  function showToast(t) {
    // With the sheet open, the page's toast would sit behind it: a short note at the top of the sheet's
    // bar says it instead ("Link copied", "Sent").
    if (sheet.open && !(t.ids && t.ids.length)) {
      const b = sheet.querySelector('.vol-bar');
      if (b) {
        // Kept for six seconds even if the sheet is redrawn meanwhile (a count refresh).
        state.barNote = { html: barNoteHtml(t), until: Date.now() + 6000 };
        const old = b.querySelector(".vol-bar__note"); if (old) old.remove();
        b.insertAdjacentHTML('afterbegin', state.barNote.html);
        clearTimeout(noteTimer); noteTimer = setTimeout(() => { state.barNote = null; const n = sheet.querySelector('.vol-bar__note'); if (n) n.remove(); }, 6000);
        return;
      }
    }
    state.toast = t;
    clearTimeout(toastTimer);
    const undoBtn = t.ids && t.ids.length ? '<button type="button" class="vol-toast__b" data-undo>Undo</button>' : '';
    bar.classList.toggle('is-no', t.kind !== 'ok');
    bar.innerHTML = '<p>' + (t.kind === 'ok' ? I.check : I.alert) + '<span><b>' + esc(t.text) + '</b>' + (t.sub ? '<small>' + esc(t.sub) + '</small>' : '') + '</span></p>' + undoBtn +
      // Calendar only when Your shifts (with its Add to calendar) isn't on the page.
      (t.shifts && !root.querySelector('[data-icsall]') ? '<button type="button" class="vol-toast__b" data-icsids="' + esc(t.shifts.join(' ')) + '">' + I.cal + 'Calendar</button>' : '') +
      (t.wait ? '<button type="button" class="vol-toast__b" data-wait="' + esc(t.wait) + '">Join waitlist</button>' : '') +
      (t.view ? '<button type="button" class="vol-toast__b" data-shift="' + esc(t.view) + '">View</button>' : '') +
      (t.retry ? '<button type="button" class="vol-toast__b" data-retry>Retry</button>' : '') +
      '<button type="button" class="vol-toast__x" data-dismiss aria-label="Close">' + I.close + '</button>';
    bar.hidden = false;
    document.body.classList.add('has-toast');
    // The local site's Pages button moves above the toast, however tall it is (never over Undo).
    document.body.style.setProperty('--vol-toast-h', bar.offsetHeight + 'px');
    // Undo stays for two minutes, as long as the email waits (ten seconds was too quick for a slow reader;
    // the server takes it back quietly until the email goes, and as a Leave after). The toast stays until
    // it's closed or replaced.
    if (t.ids) toastTimer = setTimeout(() => { const u = bar.querySelector('[data-undo]'); if (u) u.remove(); }, 120000);
  }
  function hideToast() { bar.hidden = true; state.toast = null; document.body.classList.remove('has-toast'); }
  bar.addEventListener('click', e => {
    const b = e.target.closest('button');
    if (!b) return;
    const t = state.toast || {};
    if (b.hasAttribute('data-dismiss')) return hideToast();
    if (b.hasAttribute('data-undo')) return undo(t.ids);
    if (b.dataset.icsids) return downloadIcs(b.dataset.icsids.split(' '));
    if (b.dataset.wait) { hideToast(); return waitFor(find(b.dataset.wait)); }
    if (b.dataset.shift) { hideToast(); return openShift(b.dataset.shift); }
    if (b.hasAttribute('data-retry') && t.retry) { hideToast(); return t.retry(); }
  });

  /* ---------------------------------------------------------------- calendar */

  function downloadIcs(ids) {
    const evs = [];
    const s = S();
    ids.map(find).filter(Boolean).forEach(sh => {
      const on = minesOn(sh);
      (on.length ? on : [{ name: '' }]).forEach(m => evs.push({
        // The sign-up's record id, as in the emails (never a name: calendar servers keep the UID).
        uid: 'ogc-vol-' + (m.rid || String(sh.id).toLowerCase().replace(/[^a-z0-9]+/g, '-')), date: sh.day.date, start: sh.start, end: sh.end,
        summary: sh.role + ' · ' + sh.committee + (on.length > 1 ? ' · ' + first(m.name) : ''),
        location: [placeName(sh), s.venue, s.city].filter(Boolean).join(', '),
        description: (sh.note ? sh.note + '\n' : '') + 'Your sign-ups: ' + location.origin + (W.base || '/annual-conference/') + 'register/?year=' + state.year + '&view=mine',
        remind: 'Tomorrow: ' + sh.role
      }));
    });
    const one = ids.length === 1 && find(ids[0]);
    SU.save(SU.ics(evs, tz()), 'text/calendar', one ? 'volunteer-' + one.role.toLowerCase().replace(/[^a-z0-9]+/g, '-') + '-' + one.day.date + '.ics' : 'volunteer-' + state.year + '.ics');
  }

  /* ---------------------------------------------------------------- Who's signed up (committee heads) */

  const LD = () => state.lead || {};
  async function leadLoad(c) {
    try {
      state.lead = await call('GET', 'vol/' + state.year + '/lead' + (c != null ? '?committee=' + encodeURIComponent(c) : ''));
      state.committee = state.lead.committee || '';
      if (c == null && !state.committee && state.lead.all) { const last = kept.get('lead-' + state.year, ''); if (last && state.lead.committees.some(x => x.name === last)) return leadLoad(last); }
      if (state.committee) kept.set('lead-' + state.year, state.committee);
    } catch (e) { state.lead = { denied: e.status || 500 }; }
  }

  function leadRender() {
    const d = LD(), c = state.committee;
    const view = (W.base || '/annual-conference/') + 'volunteer/?year=' + state.year + (c ? '&committee=' + encodeURIComponent(c) : '');
    // A head sees their committee's name as the title; the year's committee sees "Who's signed up".
    let head = SU.wsHead({ year: state.year, part: ['helping', 'Volunteer shifts'], kicker: c ? 'Who’s signed up · ' + state.year : 'Volunteers · ' + state.year, title: c || 'Who’s signed up', tools: '<a href="' + esc(view) + '">View page</a>' });
    // Back to the year's Volunteer shifts only for its members; a committee's head who isn't one would
    // land on No access, so the bar has only View page (their committee's public page).
    if (!d.all) head = head.replace(/<a class="ws-back"[\s\S]*?<\/a>/, '');
    let body;
    if (d.denied) {
      const ret = encodeURIComponent(location.pathname + location.search);
      body = '<section class="vol-blank"><h2 class="vol-blank__h">' + (d.denied === 401 ? 'Sign in' : 'Not on this list') + '</h2><p class="vol-blank__p">' + (d.denied === 401 ? 'For the year’s committee and each committee’s heads' : esc((W.me && W.me.email) || '') + ' isn’t a head of this committee') + '</p><p><a class="wk-btn wk-btn--small" href="' + esc((W.signin || '') + '?return=' + ret) + '">Sign in</a></p></section>';
    } else body = (c ? leadChips() + leadCommittee() : leadAll());
    root.innerHTML = '<div class="wk vol ws vol-lead">' + head + '<div class="ws-body ws-body--page">' + body + '</div></div><div class="vol-print" aria-hidden="true"></div>';
    document.title = (c ? c + ' · ' : '') + 'Who’s signed up – ' + state.year + ' Annual Conference';
  }

  // Another committee (the year's committee, or a head of more than one): chips; on a phone, one line
  // with Change. All is the table, so it isn't drawn again as chips there.
  function leadChips() {
    const d = LD(), c = state.committee, list = d.committees || [];
    if (list.length < 2 && !d.all) return '';
    const chip = x => '<button type="button" data-lead="' + esc(x.name) + '" aria-pressed="' + (x.name === c) + '">' + mark(x.name) + esc(x.name) + (x.open ? ' <small>· ' + x.open + ' open</small>' : x.needed ? ' <small>· Full</small>' : '') + '</button>';
    return '<div class="vol-chipwrap' + (state.chipsOpen ? ' is-open' : '') + '"><p class="vol-chipnow"><span>Committee</span> <button type="button" class="wk-linklike" data-chips aria-expanded="' + !!state.chipsOpen + '">Change</button></p>' +
      '<div class="wk-aud vol-chips" role="group" aria-label="Committee">' + (d.all ? '<button type="button" data-lead="" aria-pressed="false">All</button>' : '') + list.map(chip).join('') + '</div></div>';
  }

  // All (the year's committee): what to do, then one table of the committees, the most open first,
  // with their heads and last year's numbers beside this year's.
  function leadAll() {
    const d = LD(), list = (d.committees || []).slice().sort((a, b) => b.open - a.open), n = list.length, prev = state.year - 1;
    const withC = list.filter(x => x.contact).length, withH = list.filter(x => x.heads).length;
    const noC = list.find(x => !x.contact), noH = list.find(x => !x.heads);
    const todo = d.all && n && !d.gone ? '<section class="vol-todo" aria-labelledby="vol-todo-h"><h2 class="rf-label" id="vol-todo-h">What to do</h2><ul>' +
      // Each step opens the work: the first committee with no contact; Members for the heads.
      step(withC === n, 'Contacts · ' + withC + ' of ' + n + ' set', 'Each committee’s email for notices, and the phone people may call', noC ? 'data-lead="' + esc(noC.name) + '" data-opencontact' : '') +
      step(withH === n, 'Heads · ' + withH + ' of ' + n, 'Who heads each committee, marked Head on Members', noH ? 'href="' + esc(addHeadUrl(noH.name)) + '"' : '') + '</ul></section>' : '';
    const lastCol = list.some(x => x.last);
    const table = '<table class="vol-all"><thead><tr><th scope="col">Committee</th><th scope="col">Filled</th><th scope="col">Open</th>' + (d.all ? '<th scope="col">Heads</th>' : '') + (lastCol ? '<th scope="col" title="How each committee ended ' + prev + '">' + prev + ' final</th>' : '') + '</tr></thead><tbody>' +
      list.map(x => '<tr><th scope="row"><button type="button" class="wk-linklike" data-lead="' + esc(x.name) + '">' + mark(x.name) + esc(x.name) + '</button></th>' +
        '<td>' + (x.needed ? x.filled + ' of ' + x.needed : x.filled) + '</td>' +
        '<td>' + (!x.needed ? '<span class="vol-muted">No limit</span>' : x.open ? '<b class="vol-open">' + x.open + '</b>' : 'Full') + '</td>' +
        // Who heads it, by name (the email in a tooltip), from the year's Members; else Add, on Members.
        // Who heads it, by name only (the emails are on the committee's own list, under Contact).
        (d.all ? '<td>' + ((x.head_names || []).length ? x.head_names.map(h => '<span class="vol-headname">' + esc(h.name) + '</span>').join(', ') : '<a class="wk-linklike" href="' + esc(addHeadUrl(x.name)) + '">Add head</a>') + '</td>' : '') +
        (lastCol ? '<td class="vol-muted">' + (x.last && x.last.filled ? (x.last.needed ? x.last.filled + ' of ' + x.last.needed : x.last.filled) : '') + '</td>' : '') + '</tr>').join('') + '</tbody></table>';
    const ask = state.clearAsk ? '<div class="vol-confirm" role="alert"><p>Clear the sample volunteers for ' + esc(state.year) + '?</p><p class="vol-bar__btns"><button type="button" class="wk-btn wk-btn--small" data-clearsamples-go>Clear samples</button><button type="button" class="wk-linklike" data-clearsamples-off>Keep</button></p></div>' : '';
    const foot = d.all ? '<p class="vol-leadfoot">' + (d.heads_n && !d.gone ? '<button type="button" class="wk-btn wk-btn--small" data-msgheads>' + I.mail + 'Message all heads</button>' : '') +
      '<button type="button" class="wk-linklike" data-csvall>' + I.down + 'Download all</button>' + (d.webmaster && !state.clearAsk ? '<button type="button" class="wk-linklike" data-clearsamples>Clear samples</button>' : '') + '</p>' + ask : '';
    return todo + table + foot + leadFooter();
  }
  const membersUrl = () => (W.base || '/annual-conference/') + 'members/?year=' + encodeURIComponent(state.year);
  // Members, with the committee to add a head to (the Members page picks it when it reads committee=).
  const addHeadUrl = c => membersUrl() + '&committee=' + encodeURIComponent(String(c).toLowerCase());
  // A step of What to do: a button (or link) that opens the work, with what it means said under it.
  const step = (done, label, help, attrs) => '<li class="vol-todo__s' + (done ? ' is-done' : '') + '">' +
    (attrs && !done ? (/^href=/.test(attrs) ? '<a class="vol-todo__b" ' + attrs + '>' : '<button type="button" class="vol-todo__b" ' + attrs + '>') : '<span class="vol-todo__b">') +
    (done ? I.check : '<span class="vol-todo__dot"></span>') + '<span><b>' + esc(label) + '</b><small>' + esc(help) + '</small></span>' +
    (attrs && !done ? (/^href=/.test(attrs) ? '</a>' : '</button>') : '</span>') + '</li>';
  const leadFooter = () => { const d = LD(); return d.cleared ? '<p class="vol-sheetline">Names cleared ' + esc(O.fmtDate(d.cleared, 'md')) + '</p>' : d.clears ? '<p class="vol-sheetline">Names cleared ' + esc(O.fmtDate(d.clears, 'mdy')) + '</p>' : ''; };

  function leadCommittee() {
    const d = LD(), c = state.committee, rowsL = (d.shifts || []).map(x => Object.assign({}, x, { sh: find(x.id) })).filter(x => x.sh).sort((a, b) => sortKey(a.sh) - sortKey(b.sh));
    const total = rowsL.reduce((k, x) => k + (x.sh.unlimited ? 0 : x.sh.needed), 0), have = rowsL.reduce((k, x) => k + x.n, 0);
    const openN = rowsL.reduce((k, x) => k + (x.sh.unlimited ? 0 : Math.max(0, x.sh.needed - x.n)), 0);
    const ppl = uniq(rowsL.reduce((a, x) => a.concat(x.people.map(p => (p.email || p.phone) + '|' + p.name)), [])).length;
    const roles = uniq(rowsL.map(x => x.sh.role)), oneRole = roles.length === 1;
    const by = state.leadBy || 'shifts', findQ = (state.findQ || '').toLowerCase();
    const days = state.model.days.filter(day => rowsL.some(x => eve(x.sh) === day));
    // What changed since this person last printed: said only when something did.
    const joined = rowsL.reduce((k, x) => k + x.people.filter(p => p.new).length, 0), left = d.left || [];
    // Its own Clear (or a Download) marks it read; printing never does (a cancelled print isn't a print).
    const changes = d.since && (joined || left.length) ? '<p class="vol-changes">Since ' + esc(O.fmtDate(d.since.slice(0, 10), 'mdShort')) + ' · ' + [joined ? joined + ' joined' : '', left.length ? left.length + ' left: <s>' + esc(uniq(left.map(x => x.name)).slice(0, 6).join(', ')) + '</s>' + (uniq(left.map(x => x.name)).length > 6 ? ' + ' + (uniq(left.map(x => x.name)).length - 6) : '') : ''].filter(Boolean).join(' · ') + ' · <button type="button" class="wk-linklike" data-seen>Clear</button></p>' : '';
    // Emails the per-address limit held back: said here, not only in the Mail log.
    const refused = (d.refused || []).length ? '<p class="vol-changes is-warn" title="Too many emails to one address in a day: call them">' + I.alert + 'Not emailed · ' + esc(d.refused.slice(0, 5).map(x => x.name).join(', ')) + (d.refused.length > 5 ? ' + ' + (d.refused.length - 5) : '') + ' · Email limit</p>' : '';
    // Printed? asked in the page after the print dialog (the dialog can't say whether it printed).
    const printedAsk = state.printAsk && !d.printed ? '<div class="vol-confirm" role="status"><p>Printed the sign-in sheets?</p><p class="vol-bar__btns"><button type="button" class="wk-btn wk-btn--small" data-printeddone>Printed</button><button type="button" class="wk-linklike" data-printedno>Not yet</button></p></div>' : '';
    const ct = d.contact || {};
    // A new head each year: what to do (ticking itself from the data), and last year's note on top.
    const todo = d.gone ? '' : '<section class="vol-todo" aria-labelledby="vol-todo-h"><h2 class="rf-label" id="vol-todo-h">What to do</h2><ul>' +
      step(!!(ct.email && ct.phone), 'Contact', 'Your committee’s phone shows to the public; notices come to its email', 'data-opencontact') +
      step(!!d.messaged, 'Message volunteers', 'A week before: where to meet, what to bring', 'data-message') +
      step(!!d.printed, 'Print sign-in sheets', 'One for each day, for the volunteers to tick as they arrive', 'data-printmenu') + '</ul></section>';
    const lastNote = d.last_note && d.last_note.text ? '<aside class="vol-lastnote"><p class="rf-label">From ' + (state.year - 1) + (d.last_note.by ? ' · ' + esc(d.last_note.by) : '') + '</p><p>' + esc(d.last_note.text).replace(/\n/g, '<br>') + '</p></aside>' : '';
    // One primary action (Message); Print and Download as quiet links beside it.
    const bar2 = '<div class="vol-leadbar"><p class="vol-count"><b>' + have + (total ? ' of ' + total : '') + '</b> ' + (d.gone ? 'helped' : 'filled') + (openN && !d.gone ? ' · <b class="vol-open">' + openN + ' open</b>' : '') + (d.gone ? '' : ' · ' + plural(ppl, 'person', 'people')) + (oneRole && roles[0].toLowerCase() !== c.toLowerCase() ? ' · ' + esc(roles[0]) : '') + '</p>' +
      (d.gone ? '' : '<p class="vol-leadbtns"><button type="button" class="wk-btn wk-btn--small" data-message>' + I.mail + 'Message</button>' +
      '<span class="vol-menu"><button type="button" class="wk-linklike" data-printmenu aria-expanded="' + !!state.printOpen + '">' + I.print + 'Print</button>' + (state.printOpen ? printMenu(days) : '') + '</span>' +
      '<button type="button" class="wk-linklike" data-csv>' + I.down + 'Download</button></p>') + '</div>';
    const tools = d.gone ? '' : '<div class="vol-leadtools"><div class="wk-aud" role="group" aria-label="View"><button type="button" data-leadby="shifts" aria-pressed="' + (by === 'shifts') + '">' + I.check + 'Shifts</button><button type="button" data-leadby="people" aria-pressed="' + (by === 'people') + '">' + I.check + 'People</button></div>' +
      (openN ? '<label class="vol-only"><input type="checkbox" data-leadopen' + (state.leadOpen ? ' checked' : '') + '> Open only</label>' : '') +
      '<label class="vol-find">' + I.search + '<span class="ogc-sr">Find a name or phone</span><input type="search" data-find placeholder="Find" value="' + esc(state.findQ || '') + '"></label></div>';
    const match = p => !findQ || (p.name.toLowerCase().indexOf(findQ) > -1 || String(p.phone).replace(/\D/g, '').indexOf(findQ.replace(/\D/g, '') || '§') > -1);
    // During the week: today first; days already over fold to one line ("Fri · 5 of 6 here").
    const week = isWeek() && d.begun, now = today();
    let main;
    if (by === 'people' && !d.gone) main = peopleView(rowsL, match);
    else {
      const order = week ? days.filter(x => x.date >= now).concat(days.filter(x => x.date < now)) : days;
      main = order.map(day => {
        const xs = rowsL.filter(x => eve(x.sh) === day && (!state.leadOpen || (!x.sh.unlimited && x.n < x.sh.needed)));
        if (!xs.length) return '';
        const past = week && day.date < now && !(state.leadDayOpen || {})[day.key];
        const here = xs.reduce((k, x) => k + x.people.filter(p => p.here).length, 0), on = xs.reduce((k, x) => k + x.people.length, 0);
        if (past) return '<section class="vol-lday is-past"><button type="button" class="vol-ldayfold" data-leadday="' + esc(day.key) + '" aria-expanded="false"><b>' + esc(dayWord(day).slice(0, 3)) + '</b> · ' + here + ' of ' + on + ' here' + I.down2 + '</button></section>';
        const o = xs.reduce((k, x) => k + (x.sh.unlimited ? 0 : Math.max(0, x.sh.needed - x.n)), 0);
        return '<section class="vol-lday"><h2 class="vol-ldayh">' + esc(whenDay(day)) + (week && day.date === now ? ' <small class="vol-today">Today</small>' : '') + (d.gone ? '' : ' <small>' + (week && day.date < now ? here + ' of ' + on + ' here' : o ? o + ' open' : 'Full') + '</small>') + '</h2><ul class="vol-lrows">' + xs.map(x => leadRow(x, oneRole, match)).join('') + '</ul></section>';
      }).join('');
    }
    const settings = d.gone ? '' : '<details class="vol-contact"' + (state.contactOpen ? ' open' : '') + '><summary>Contact and weekly email</summary><form data-contact novalidate class="vol-fields">' +
      '<label class="vol-f"><span>Contact email</span><input name="email" type="email" value="' + esc(ct.email || '') + '"><small>Notices and replies · Not shown on the page</small></label>' +
      '<label class="vol-f"><span>Contact phone</span><input name="phone" type="tel" value="' + esc(ct.phone || '') + '"><small>Shown to the public as the committee’s</small></label>' +
      '<label class="vol-switch"><input type="checkbox" name="weekly"' + (ct.weekly ? ' checked' : '') + '><span>Weekly summary</span><small>Mondays · To the contact email</small></label> <button type="button" class="wk-linklike" data-weekly>Preview</button>' +
      // Who heads it is set on Members (docs/23), not typed here.
      // Who heads it, from Members (with their emails, here only): Add head there.
      (d.all ? '<div class="vol-heads"><p class="rf-label">Heads</p>' + ((d.heads || []).length ? '<ul>' + d.heads.map(h => '<li><b>' + esc(h.name) + '</b> <small>' + esc(h.email) + '</small></li>').join('') + '</ul><p class="vol-help"><a href="' + esc(membersUrl()) + '">Members</a></p>' : '<p class="vol-help"><a href="' + esc(addHeadUrl(c)) + '">Add head</a> · On Members</p>') + '</div>' : '') +
      '<p><button type="submit" class="wk-btn wk-btn--line wk-btn--small">Save</button> <span class="vol-saved" data-saved></span></p></form></details>';
    const sent = (d.messages || []).length ? '<details class="vol-contact"><summary>Sent · ' + d.messages.length + '</summary><ul class="vol-sent">' + d.messages.map(m => '<li><b>' + esc(m.subject) + '</b><small>' + esc(O.fmtDate(m.at.slice(0, 10), 'mdShort') + ' · ' + plural(m.n, 'volunteer') + ' · ' + (m.to === 'all' ? 'Everyone' : m.to.indexOf('day:') === 0 ? O.fmtDate(m.to.slice(4), 'weekday') : 'One shift') + (m.by ? ' · ' + m.by : '')) + '</small></li>').join('') + '</ul></details>' : '';
    // Notes for next year's committee, at the end (one per committee, saved on Save).
    const nt = d.note || {};
    const notes = d.gone ? '' : '<section class="vol-notes" aria-labelledby="vol-notes-h"><h2 class="rf-label" id="vol-notes-h">Notes for ' + (+state.year + 1) + '</h2>' +
      (state.noteEdit || !nt.text ? '<form data-note novalidate><label class="vol-f"><span class="ogc-sr">Note for next year’s committee</span><textarea name="text" rows="3" title="What next year’s committee should know: what worked, what to change">' + esc(nt.text || '') + '</textarea></label><p><button type="submit" class="wk-btn wk-btn--line wk-btn--small">' + (nt.text ? 'Save' : 'Add note') + '</button>' + (nt.text ? ' <button type="button" class="wk-linklike" data-noteoff>Cancel</button>' : '') + ' <span class="vol-saved" data-notesaved></span></p></form>'
        : '<p class="vol-note__text">' + esc(nt.text).replace(/\n/g, '<br>') + '</p><p class="vol-help">' + esc([nt.by, nt.at ? O.fmtDate(nt.at.slice(0, 10), 'mdShort') : ''].filter(Boolean).join(' · ')) + ' · <button type="button" class="wk-linklike" data-noteedit>Edit</button></p>') + '</section>';
    // Young Folks: the households in the halls not yet on a dorm shift (never "Signed up 0"); Remind
    // only until the Conference begins.
    const y = d.yf;
    const yf = y && y.total && !d.gone ? '<div class="vol-yfh"><p>' + (y.not ? '<b>Not signed up · ' + esc(plural(y.not, 'household')) + '</b>' + (y.signed ? ' · ' + y.signed + ' signed up' : '') : '<b>Every household signed up · ' + y.total + '</b>') + '<small>Households with Young Folks in the halls</small></p>' + (y.not && !d.begun ? '<button type="button" class="wk-btn wk-btn--line wk-btn--small" data-remind title="One email to each household not yet on a shift">' + I.mail + 'Remind</button>' : '') + '</div>' : '';
    return lastNote + bar2 + printedAsk + todo + changes + refused + yf + tools + '<h2 class="vol-print-title">' + esc(c) + ' · ' + esc(state.year) + ' Annual Conference</h2>' + (main || '<p class="vol-none">Nothing open</p>') + notes + settings + sent + leadFooter();
  }

  // A shift on the head's list: time and job, what's open (or, once it's over, how many came), then
  // each person on one line (name, phone, email; a "…" for Edit, Resend, Move and Remove), who's
  // waiting, and Add (its form right under the shift's line).
  function leadRow(x, oneRole, match) {
    const d = LD(), sh = x.sh, o = sh.unlimited ? 0 : Math.max(0, sh.needed - x.n), week = isWeek() && sh.day.date === today();
    const over = st(sh) === 'ended' || (x.state === 'ended');
    const tags = p => [p.by === 'head' ? 'Added by head' : '', !p.email ? 'No email' : '', !p.confirmed ? 'Unconfirmed' : '', p.hidden ? 'Hidden' : '', p.swap ? 'Swap open' : '', p.check ? 'Check · also ' + p.check : '', p.helper ? 'By ' + p.helper : '', p.new ? 'New' : ''].filter(Boolean);
    const editing = p => state.editing === p.rid;
    const person = p => '<li class="vol-lp' + (match(p) ? '' : ' is-dim') + (p.new ? ' is-new' : '') + (state.findQ && match(p) ? ' is-hit' : '') + '">' +
      (week || over ? '<label class="vol-here"><input type="checkbox" data-here="' + p.rid + '"' + (p.here ? ' checked' : '') + '><span class="ogc-sr">Here</span></label>' : '') +
      '<span class="vol-lp__n"><b>' + esc(p.name) + '</b>' + tags(p).map(t => '<span class="vol-tag' + (/^Check|Unconfirmed|No email/.test(t) ? ' is-warn' : '') + '">' + esc(t) + '</span>').join('') +
      ((p.answer && p.answer !== 'yes') || p.note ? '<small>' + esc([p.answer && p.answer !== 'yes' ? p.answer : '', p.note].filter(Boolean).join(' · ')) + '</small>' : '') + '</span>' +
      (p.phone ? '<a class="vol-lp__tel" href="tel:' + esc(p.phone.replace(/[^\d+]/g, '')) + '">' + I.phone + '<span>' + esc(p.phone) + '</span></a>' : '<span class="vol-lp__tel"></span>') +
      // The email in full: always on a laptop, and on a phone for anyone unconfirmed (to spot "gmial.com").
      '<span class="vol-lp__mail' + (!p.confirmed && p.email ? ' is-shown' : '') + '">' + esc(p.email || '') + (p.household ? ' <small class="vol-tag" title="The household’s email, shared">Household</small>' : '') + '</span>' +
      '<button type="button" class="vol-lp__more" data-pmenu="' + p.rid + '" aria-expanded="' + (state.pmenu === p.rid) + '" aria-label="' + esc('More for ' + p.name) + '">' + I.more + '</button>' +
      (state.pmenu === p.rid && state.moving !== p.rid && !editing(p) ? '<span class="vol-lp__act"><button type="button" class="wk-linklike" data-pedit="' + p.rid + '">Edit</button>' + (p.email ? '<button type="button" class="wk-linklike" data-presend="' + p.rid + '">Resend</button>' : '') + '<button type="button" class="wk-linklike" data-move="' + p.rid + '">Move</button><button type="button" class="wk-linklike" data-remove="' + p.rid + '">Remove</button></span>' : '') +
      (editing(p) ? personForm('edit', p, sh) : '') +
      (state.moving === p.rid ? moveTo(sh, p) : '') + '</li>';
    const add = state.adding === sh.id ? personForm('add', null, sh) : '';
    const last = x.last ? '<small class="vol-lastyr">' + esc((state.year - 1) + ': ' + (x.last.needed ? x.last.filled + ' of ' + x.last.needed : x.last.filled) + (x.last.waiting ? ' · ' + x.last.waiting + ' waiting' : '') + (x.last.filled_on ? ' · full ' + O.fmtDate(x.last.filled_on, 'mdShort') : '')) + '</small>' : '';
    // One count: what's open (or Full, or over); "13 coming" without a limit; once over, how many came.
    const here = x.people.filter(p => p.here).length;
    const need = d.gone ? '<span>' + x.n + ' helped</span>' : over ? '<span>' + here + ' of ' + x.n + ' here</span>' : x.over ? '<b class="vol-over">' + x.over + ' over</b>' : sh.unlimited ? '<b>' + x.n + ' coming</b>' : o ? '<b class="vol-open">' + o + ' open</b>' : '<span>Full</span>';
    return '<li class="vol-lrow' + (o > 0 && !d.gone && !over ? ' is-short' : '') + '" data-lrow="' + esc(sh.id) + '"><div class="vol-lrow__h"><span class="vol-ltime"><b>' + esc(span(sh)) + (night(sh) ? ' · night' : '') + '</b>' + (oneRole ? '' : '<small>' + esc(sh.role) + '</small>') + last + '</span>' +
      '<span class="vol-lneed">' + need + (d.gone ? '' : '<button type="button" class="wk-linklike" data-addto="' + esc(sh.id) + '">' + I.plus + 'Add</button>' + (over ? '' : '<button type="button" class="wk-linklike" data-msgshift="' + esc(sh.id) + '">Message</button>')) + '</span></div>' + add +
      (d.gone ? '' : x.people.length ? '<ul class="vol-lppl">' + x.people.map(person).join('') + '</ul>' : '<p class="vol-none">No one yet</p>') +
      (x.waiting.length && !over ? '<div class="vol-lwait"><p class="rf-label">Waiting · ' + x.waiting.length + '</p><ul>' + x.waiting.map(w => '<li><span>' + esc(w.name) + '</span>' + (w.phone ? '<a href="tel:' + esc(w.phone.replace(/[^\d+]/g, '')) + '">' + esc(w.phone) + '</a>' : '') + '<button type="button" class="wk-linklike" data-offer="' + w.rid + '">Offer</button></li>').join('') + '</ul></div>' : '') + '</li>';
  }
  // Add someone, or Edit a person: name, phone, email, note; each error at its field (never a toast).
  function personForm(kind, p, sh) {
    const e = state.pErr || {}, v = state.pVal || (p ? { name: p.name, phone: p.phone, email: p.email, note: p.note } : {});
    const f = (name, label, type, help) => '<label class="vol-f' + (e[name] ? ' is-bad' : '') + '"><span>' + label + '</span><input name="' + name + '"' + (type ? ' type="' + type + '"' : '') + ' value="' + esc(v[name] || '') + '" autocomplete="off"' + (e[name] ? ' aria-invalid="true"' : '') + '>' + (e[name] ? '<small class="vol-err">' + esc(e[name]) + '</small>' : help ? '<small>' + help + '</small>' : '') + '</label>';
    return '<form class="vol-addform vol-fields" data-' + kind + '="' + esc(kind === 'add' ? sh.id : p.rid) + '" novalidate><div class="vol-row2">' + f('name', 'Name', '', 'First and last') + f('phone', 'Phone', 'tel', '') + '</div>' +
      f('email', 'Email', 'email', kind === 'add' ? 'Optional · Gets the confirmation' : 'A new email gets the confirmation') + (kind === 'add' ? f('note', 'Note', '', '') : '') +
      (e.form ? '<p class="vol-err">' + esc(e.form) + '</p>' : '') + '<p class="vol-addform__btns"><button type="submit" class="wk-btn wk-btn--small">' + (kind === 'add' ? 'Add' : 'Save') + '</button> <button type="button" class="wk-linklike" data-' + kind + 'off>Cancel</button></p></form>';
  }
  function moveTo(sh, p) {
    const xs = state.shifts.filter(x => x.committee === sh.committee && x.id !== sh.id).sort((a, b) => sortKey(a) - sortKey(b));
    return '<div class="vol-moveto"><p class="rf-label">Move ' + esc(first(p.name)) + ' to</p><ul>' + xs.map(x => { const lx = (LD().shifts || []).find(y => y.id === x.id), n = lx ? lx.n : 0; return '<li><button type="button" class="wk-linklike" data-moveto="' + esc(x.id) + '" data-rid="' + p.rid + '">' + esc(whenShort(x) + (x.role !== sh.role ? ' · ' + x.role : '')) + '</button> <small>' + (x.unlimited ? '' : Math.max(0, x.needed - n) ? Math.max(0, x.needed - n) + ' open' : 'Full') + '</small></li>'; }).join('') + '</ul><button type="button" class="wk-linklike" data-moveoff>Cancel</button></div>';
  }
  // Each person once, with their shifts in time order and the hours.
  function peopleView(rowsL, match) {
    const by = {};
    rowsL.forEach(x => x.people.forEach(p => { const k = (p.email || p.phone) + '|' + p.name; (by[k] = by[k] || { p, list: [] }).list.push(x.sh); }));
    const list = Object.values(by).filter(v => match(v.p)).sort((a, b) => lastName(a.p.name).localeCompare(lastName(b.p.name)));
    return '<ul class="vol-people">' + list.map(v => {
      const hrs = v.list.reduce((k, sh) => k + (sh.end - sh.start) / 60, 0), perDay = {};
      v.list.forEach(sh => { perDay[sh.day.date] = (perDay[sh.day.date] || 0) + 1; });
      const many = Object.values(perDay).some(n => n > 3);
      return '<li><span class="vol-lp__n"><b>' + esc(v.p.name) + '</b><small>' + esc(plural(v.list.length, 'shift') + ' · ' + (Math.round(hrs * 10) / 10) + ' hr') + (many ? ' · <span class="vol-tag is-warn">More than 3 a day</span>' : '') + '</small><small>' + v.list.sort((a, b) => sortKey(a) - sortKey(b)).map(sh => esc(whenShort(sh))).join('<br>') + '</small></span>' +
        (v.p.phone ? '<a class="vol-lp__tel" href="tel:' + esc(v.p.phone.replace(/[^\d+]/g, '')) + '">' + I.phone + '<span>' + esc(v.p.phone) + '</span></a>' : '') + '</li>';
    }).join('') + '</ul>';
  }
  const lastName = n => String(n || '').trim().split(/\s+/).pop() + ' ' + n;

  // Print: a sign-in sheet (Here box, name, phone, blank lines for walk-ups), the roster, or name tags
  // (one per person, their jobs joined, by last name).
  // The print menu: what (Sign-in sheet, Roster, Name tags) and which day (Every day, or one; today first
  // during the week, so a head on campus prints just today's).
  function printMenu(days) {
    const wk = isWeek(), order = wk ? days.filter(x => x.date === today()).concat(days.filter(x => x.date !== today())) : days;
    const pd = state.printDay != null ? state.printDay : wk && days.some(x => x.date === today()) ? today() : '';
    const pill = (v, l) => '<button type="button" data-printday="' + esc(v) + '" aria-pressed="' + (pd === v) + '">' + (pd === v ? I.check : '') + esc(l) + '</button>';
    return '<span class="vol-menu__list"><span class="vol-menu__days rf-seg" role="group" aria-label="Day">' + pill('', 'Every day') + order.map(x => pill(x.date, x.date === today() && wk ? 'Today' : dayWord(x).slice(0, 3))).join('') + '</span>' +
      '<button type="button" data-print="signin">Sign-in sheet</button><button type="button" data-print="roster">Roster</button><button type="button" data-print="tags">Name tags</button></span>';
  }
  function printAs(kind) {
    const d = LD(), c = state.committee, wk = isWeek(), dflt = wk && state.model.days.some(x => x.date === today()) ? today() : '';
    const pd = state.printDay != null ? state.printDay : dflt;
    const rowsL = (d.shifts || []).map(x => Object.assign({}, x, { sh: find(x.id) })).filter(x => x.sh && (!pd || eve(x.sh).date === pd)).sort((a, b) => sortKey(a.sh) - sortKey(b.sh));
    const stamp = new Date().toLocaleString('en-US', { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' });
    const title = '<h1>' + esc(c) + ' · ' + esc(state.year) + ' Annual Conference</h1><p class="vol-print__as">Printed ' + esc(stamp) + (d.contact && d.contact.phone ? ' · ' + esc(c) + ' ' + esc(d.contact.phone) : '') + '</p>';
    let html;
    if (kind === 'tags') {
      const by = {};
      rowsL.forEach(x => x.people.forEach(p => { const k = (p.email || p.phone || '') + '|' + p.name.toLowerCase(); (by[k] = by[k] || { name: p.name, jobs: [] }); if (by[k].jobs.indexOf(x.sh.role) < 0) by[k].jobs.push(x.sh.role); }));
      html = '<div class="vol-tagsheet">' + Object.values(by).sort((a, b) => lastName(a.name).localeCompare(lastName(b.name))).map(t => '<div class="vol-nametag"><b>' + esc(SU.firstL(t.name)) + '</b><span>' + esc(c) + '</span>' + (t.jobs.length === 1 && t.jobs[0].toLowerCase() === c.toLowerCase() ? '' : '<small>' + esc(t.jobs.join(' · ')) + '</small>') + '</div>').join('') + '</div>';
    } else html = title + rowsL.map(x => {
      const sh = x.sh, blanks = kind === 'signin' ? Math.max(3, sh.unlimited ? 3 : sh.needed - x.people.length) : Math.max(0, sh.unlimited ? 0 : sh.needed - x.people.length);
      // The same columns on every shift (fixed widths), so the page reads straight down.
      return '<section class="vol-pblock"><h2>' + esc(whenShort(sh)) + ' · ' + esc(sh.role) + (placeName(sh) ? ' · ' + esc(placeName(sh)) : '') + '</h2>' + (sh.note && kind === 'signin' ? '<p>' + esc(sh.note) + '</p>' : '') +
        '<table class="vol-ptable' + (kind === 'signin' ? ' has-here' : '') + '"><colgroup>' + (kind === 'signin' ? '<col class="vol-pc-here">' : '') + '<col class="vol-pc-name"><col class="vol-pc-phone"></colgroup><thead><tr>' + (kind === 'signin' ? '<th class="vol-pbox">Here</th>' : '') + '<th>Name</th><th>Phone</th></tr></thead><tbody>' +
        x.people.map(p => '<tr>' + (kind === 'signin' ? '<td class="vol-pbox">☐</td>' : '') + '<td>' + esc(p.name) + '</td><td>' + esc(p.phone) + '</td></tr>').join('') +
        Array.from({ length: blanks }, () => '<tr class="is-blank">' + (kind === 'signin' ? '<td class="vol-pbox">☐</td>' : '') + '<td></td><td></td></tr>').join('') + '</tbody></table></section>';
    }).join('');
    const box = root.querySelector('.vol-print');
    box.innerHTML = html;
    document.body.classList.add('vol-printing', 'vol-print--' + kind);
    const done = () => { document.body.classList.remove('vol-printing', 'vol-print--signin', 'vol-print--roster', 'vol-print--tags'); window.removeEventListener('afterprint', done); };
    window.addEventListener('afterprint', done);
    window.print();
    // Asked, not assumed: Printed ticks What to do.
    if (kind === 'signin') { state.printAsk = true; setTimeout(leadRender, 0); }
  }
  async function downloadCsv(all) {
    try {
      const text = await call('GET', 'vol/' + state.year + '/lead/export?' + (all ? 'scope=all' : 'committee=' + encodeURIComponent(state.committee)));
      SU.save(text, 'text/csv;charset=utf-8', (all ? 'volunteers' : state.committee.toLowerCase().replace(/[^a-z0-9]+/g, '-') + '-volunteers') + '-' + state.year + '.csv');
      if (!all) post('vol/' + state.year + '/lead/printed', { committee: state.committee, what: 'seen' }).catch(() => {});
    } catch (e) { showToast({ kind: 'error', text: 'Not downloaded', retry: () => downloadCsv(all) }); }
  }
  async function leadAct(path, body, toastText, undoFn) {
    try {
      const d = await post('vol/' + state.year + '/lead/' + path, Object.assign({ committee: state.committee }, body));
      await leadLoad(state.committee); leadRender();
      if (toastText) showToast({ kind: 'ok', text: toastText, retry: undefined });
      if (undoFn) { const b = document.createElement('button'); b.type = 'button'; b.className = 'vol-toast__b'; b.textContent = 'Undo'; b.addEventListener('click', () => { hideToast(); undoFn(d); }); bar.insertBefore(b, bar.querySelector('[data-dismiss]')); }
      return d;
    } catch (e) {
      const w = e.data || {};
      showToast({ kind: 'no', text: w.why === 'busy' ? busyOf(w.busy) : w.why === 'full' ? 'Full' : w.why === 'dup' ? 'Already on it' : w.why === 'fields' ? Object.values(w.fields || {}).join(' · ') : 'Not saved' });
      throw e;
    }
  }

  // A message to the committee's volunteers: everyone, a day's, or one shift's.
  // How many a message reaches: each person with an email once (the button says it before Send).
  function msgCount(to) {
    if (to === 'heads') return LD().heads_n || 0;
    const xs = (LD().shifts || []).filter(x => { const sh = find(x.id); return sh && (to.indexOf('day:') === 0 ? sh.day.date === to.slice(4) : to.indexOf('shift:') === 0 ? x.id === to.slice(6) : true); });
    return uniq(xs.reduce((a, x) => a.concat(x.people.filter(p => p.email).map(p => p.email.toLowerCase())), [])).length;
  }
  // A message to the committee's volunteers (everyone, a day's, or one shift's), or from the year's
  // committee to every committee's contact and heads.
  function messageSheet(to) {
    const c = state.committee, days = state.model.days.filter(d => state.shifts.some(sh => sh.committee === c && sh.day === d));
    to = to || state.msgTo || 'all'; state.msgTo = to;
    const heads = to === 'heads', shift = to.indexOf('shift:') === 0 && find(to.slice(6));
    const keep = state.msgKeep || {}, n = msgCount(to), mine = (W.me && W.me.email) || LD().me || '';
    const pills = heads ? '<button type="button" aria-pressed="true">' + I.check + 'Every committee’s heads</button>'
      : (shift ? '<button type="button" aria-pressed="true">' + I.check + esc(whenShort(shift)) + '</button>' : '') + [['all', 'Everyone']].concat(days.map(d => ['day:' + d.date, dayWord(d).slice(0, 3)])).map(o => '<button type="button" data-msgto="' + esc(o[0]) + '" aria-pressed="' + (to === o[0]) + '">' + (to === o[0] ? I.check : '') + esc(o[1]) + '</button>').join('');
    sheet.innerHTML = '<div class="vol-sheet__scroll"><form class="wk-sheet__in vol-msg" data-msg novalidate><button type="button" class="wk-sheet__x" data-close aria-label="Close">' + I.close + '</button>' +
      '<p class="wk-kicker">' + esc(heads ? state.year + ' Annual Conference' : c) + '</p><h2 class="wk-sheet__h" id="vol-sheet-t">New message</h2>' +
      '<div class="vol-pick"><p class="rf-label">To</p><span class="rf-seg">' + pills + '</span></div>' +
      '<div class="vol-fields"><label class="vol-f"><span>Subject</span><input name="subject" value="' + esc(keep.subject != null ? keep.subject : heads ? 'Volunteer shifts · ' + state.year + ' Conference' : c + ' at the ' + state.year + ' Conference') + '"></label><label class="vol-f"><span>Message</span><textarea name="body" rows="6" placeholder="' + (heads ? 'What each committee needs to do' : 'Where to meet, what to bring, a change of time') + '">' + esc(keep.body || '') + '</textarea></label>' +
      '<p class="vol-help">Replies go to you · <b>' + esc(mine) + '</b></p><label class="vol-switch"><input type="checkbox" name="copy" checked><span>Send me a copy</span></label></div><p class="vol-err" data-msgerr hidden></p></form></div>' +
      '<div class="vol-bar"><p class="vol-bar__btns vol-bar__btns--one"><button type="button" class="wk-btn" data-msgsend' + (n && LD().msgs_left !== 0 ? '' : ' disabled') + '>' + I.mail + (n ? 'Send · ' + esc(plural(n, 'person', 'people')) : 'No one to email') + '</button>' +
      // Five messages a day each: how many are left, said before the sixth is refused.
      (LD().msgs_left != null ? '<small' + (LD().msgs_left ? '' : ' class="vol-err"') + '>' + (LD().msgs_left ? esc(LD().msgs_left + ' left today') : 'None left today') + '</small>' : '') + '</p></div>';
    state.sheet = '';
    if (!sheet.open) sheet.showModal();
  }
  function weeklyPreview() {
    const c = state.committee, rowsL = (LD().shifts || []).map(x => Object.assign({}, x, { sh: find(x.id) })).filter(x => x.sh);
    const have = rowsL.reduce((k, x) => k + x.people.length, 0), total = rowsL.reduce((k, x) => k + (x.sh.unlimited ? 0 : x.sh.needed), 0);
    const short = rowsL.filter(x => !x.sh.unlimited && x.people.length < x.sh.needed);
    sheet.innerHTML = '<div class="vol-sheet__scroll"><div class="wk-sheet__in vol-email"><button type="button" class="wk-sheet__x" data-close aria-label="Close">' + I.close + '</button>' +
      '<p class="wk-kicker">Weekly summary · Mondays</p><h2 class="wk-sheet__h" id="vol-sheet-t">' + esc(c) + ' volunteers · ' + have + ' of ' + total + ' filled</h2>' +
      '<div class="vol-mail"><p><b>To:</b> ' + esc((LD().contact || {}).email || 'the committee’s contact') + '</p><p>' + have + ' of ' + total + ' filled · ' + (total - have) + ' open</p>' +
      (short.length ? '<p>Still open:</p><ul>' + short.map(x => '<li>' + esc(x.sh.role + ', ' + whenShort(x.sh) + ' · ' + (x.sh.needed - x.people.length) + ' open') + '</li>').join('') + '</ul>' : '<p>Every shift is full.</p>') + '<p>No names or phones in the email: Who’s signed up has them, signed in.</p></div></div></div>';
    state.sheet = '';
    sheet.showModal();
  }

  /* ---------------------------------------------------------------- the address */

  function setUrl(o) {
    const u = new URL(location.href);
    ['committee', 'shift', 'by', 'swap', 't'].forEach(k => { if (k in o) { if (o[k]) u.searchParams.set(k, o[k]); else u.searchParams.delete(k); } });
    if (u.href !== location.href) history.pushState(null, '', u);
  }
  window.addEventListener('popstate', () => {
    const p = new URLSearchParams(location.search);
    state.committee = p.get('committee') || ''; state.by = p.get('by') || '';
    render();
    const id = p.get('shift');
    if (id && find(id)) openShift(id, false); else if (sheet.open) { state.sheet = ''; sheet.close(); }
  });
  function pickCommittee(c) {
    state.committee = c; state.day = '';
    setUrl({ committee: c, shift: '' });
    render();
    window.scrollTo({ top: 0 });
    const h = root.querySelector('.vol-h');
    if (h) h.focus({ preventScroll: true });
    say.textContent = c || 'Every committee';
  }

  // Counts kept true while the page is open: on coming back to it, and every couple of minutes with a
  // sheet open. Only the numbers change; scroll and focus stay.
  async function refresh(quiet) {
    if (!state.model || state.view === 'lead') return;
    try {
      await loadLive();
      const y = scrollY, f = document.activeElement && document.activeElement.closest('[data-join],[data-shift]'), key = f && (f.dataset.join ? '[data-join="' + CSS.escape(f.dataset.join) + '"]' : '[data-shift="' + CSS.escape(f.dataset.shift) + '"]');
      render();
      scrollTo(0, y);
      if (key && !sheet.open) { const x = root.querySelector(key); if (x) x.focus({ preventScroll: true }); }
      if (sheet.open && state.sheet && !quiet) drawSheet();
      else if (sheet.open && state.sheet && !state.form) drawSheet();
    } catch (e) { /* the page stands as it was */ }
  }
  document.addEventListener('visibilitychange', () => { if (!document.hidden) refresh(true); });
  window.addEventListener('focus', () => { if (Date.now() - (state.lastFocus || 0) > 30000) { state.lastFocus = Date.now(); refresh(true); } });

  /* ---------------------------------------------------------------- events */

  root.addEventListener('click', async e => {
    const a = e.target.closest('[data-pick]');
    if (a && !e.metaKey && !e.ctrlKey) { e.preventDefault(); pickCommittee(a.dataset.pick); return; }
    const b = e.target.closest('button');
    if (!b) return;
    const ds = b.dataset;
    if (emailClick(b)) return;
    if (ds.join) join(ds.join);
    else if (ds.wait) waitFor(find(ds.wait));
    else if (ds.shift) openShift(ds.shift);
    else if ('by' in ds) { state.by = ds.by; setUrl({ by: ds.by }); render(); const x = root.querySelector('[data-by="' + ds.by + '"]'); if (x) x.focus(); }
    else if (ds.day) { state.day = ds.day; kept.set('day-' + state.year, ds.day); render(); const x = root.querySelector('.vol-daylist [data-day="' + CSS.escape(ds.day) + '"], .vol-daypills [data-day="' + CSS.escape(ds.day) + '"]'); if (x) x.focus(); say.textContent = b.textContent; }
    else if (b.hasAttribute('data-openonly-off')) { state.openOnly = false; render(); }
    else if (b.hasAttribute('data-whochange')) { state.whoOpen = !state.whoOpen; render(); const x = root.querySelector('[data-whochange]'); if (x) x.focus(); }
    else if (b.hasAttribute('data-signout')) { tab.del('hold-' + state.year); tab.del('typed'); SU.signOut(); }
    else if (b.hasAttribute('data-forget')) forgetMe();
    else if (b.hasAttribute('data-icsall')) downloadIcs(uniq(mine().map(m => m.shift)));
    else if (ds.unwait) { try { merge(await post('vol/' + state.year + '/unwait', { ids: [+ds.unwait] })); render(); say.textContent = 'Off the waitlist'; } catch (x) { showToast({ kind: 'error', text: 'Not saved' }); } }
    else if (b.hasAttribute('data-againgo')) againGo();
    else if (b.hasAttribute('data-linkleave')) linkLeave();
    else if (b.hasAttribute('data-linkswap')) linkSwap();
    else if (b.hasAttribute('data-linkswapcopy')) { const r = (state.link.records || [])[0], sh = r && find(r.shift); if (sh) copyLink(swapUrl(sh, state.link.swap), 'Link copied', 'Could you take my place? ' + sh.role + ', ' + whenShort(sh)); }
    else if (b.hasAttribute('data-linkkeep')) { state.link = null; render(); }
    else if (b.hasAttribute('data-linkjoin')) linkJoin();
    else if (b.hasAttribute('data-linkunwait')) linkUnwait();
    else if (b.hasAttribute('data-showgone')) { state.showGone = !state.showGone; render(); }
    // Who's signed up.
    else if ('lead' in ds) { state.chipsOpen = false; state.contactOpen = b.hasAttribute('data-opencontact'); state.clearAsk = false; await leadLoad(ds.lead); setUrl({ committee: ds.lead }); leadRender(); const x = root.querySelector(state.contactOpen ? '.vol-contact input' : '[data-lead="' + CSS.escape(ds.lead) + '"]'); if (x) { if (state.contactOpen) x.closest('.vol-contact').scrollIntoView({ block: 'center' }); x.focus({ preventScroll: state.contactOpen }); } }
    else if (b.hasAttribute('data-chips')) { state.chipsOpen = !state.chipsOpen; leadRender(); }
    else if (ds.leadby) { state.leadBy = ds.leadby; leadRender(); }
    else if (b.hasAttribute('data-printmenu')) { state.printOpen = !state.printOpen; leadRender(); const x = root.querySelector('[data-print]'); if (x) x.focus(); }
    else if (ds.print) { state.printOpen = false; leadRender(); printAs(ds.print); }
    else if ('printday' in ds) { state.printDay = ds.printday; leadRender(); const x = root.querySelector('[data-printday="' + CSS.escape(ds.printday) + '"]'); if (x) x.focus(); }
    else if (b.hasAttribute('data-printeddone')) { state.printAsk = false; try { await post('vol/' + state.year + '/lead/printed', { committee: state.committee, what: 'done' }); await leadLoad(state.committee); } catch (x) { /* stays unticked */ } leadRender(); say.textContent = 'Printed'; }
    else if (b.hasAttribute('data-printedno')) { state.printAsk = false; leadRender(); }
    else if (b.hasAttribute('data-seen')) { try { await post('vol/' + state.year + '/lead/printed', { committee: state.committee, what: 'seen' }); await leadLoad(state.committee); } catch (x) { /* kept */ } leadRender(); }
    else if (b.hasAttribute('data-opencontact') && !('lead' in ds)) { state.contactOpen = true; leadRender(); const x = root.querySelector('.vol-contact input'); if (x) { x.closest('.vol-contact').scrollIntoView({ block: 'center' }); x.focus({ preventScroll: true }); } }
    else if (b.hasAttribute('data-csv')) downloadCsv(false);
    else if (b.hasAttribute('data-csvall')) downloadCsv(true);
    else if (b.hasAttribute('data-message')) { state.msgKeep = null; messageSheet('all'); }
    else if (b.hasAttribute('data-msgheads')) { state.msgKeep = null; messageSheet('heads'); }
    else if (ds.pmenu) { const id = +ds.pmenu; state.pmenu = state.pmenu === id ? 0 : id; state.moving = 0; leadRender(); const x = root.querySelector(state.pmenu ? '[data-move="' + id + '"]' : '[data-pmenu="' + id + '"]'); if (x) x.focus(); }
    else if (ds.msgshift) { state.msgKeep = null; messageSheet('shift:' + ds.msgshift); }
    else if (b.hasAttribute('data-weekly')) weeklyPreview();
    else if (ds.leadday) { state.leadDayOpen = Object.assign({}, state.leadDayOpen, { [ds.leadday]: true }); leadRender(); }
    else if (ds.pedit) { state.editing = +ds.pedit; state.pmenu = 0; state.pErr = null; state.pVal = null; leadRender(); const x = root.querySelector('[data-edit] input'); if (x) x.focus(); }
    else if (b.hasAttribute('data-editoff')) { state.editing = 0; state.pErr = null; state.pVal = null; leadRender(); }
    else if (ds.presend) { try { await post('vol/' + state.year + '/lead/resend', { committee: state.committee, id: +ds.presend }); showToast({ kind: 'ok', text: 'Sent' }); } catch (x) { showToast({ kind: x.status === 429 ? 'ok' : 'no', text: x.status === 429 ? 'Sent · Just now' : 'Not sent' }); } state.pmenu = 0; leadRender(); }
    else if (b.hasAttribute('data-noteedit')) { state.noteEdit = true; leadRender(); const x = root.querySelector('[data-note] textarea'); if (x) x.focus(); }
    else if (b.hasAttribute('data-noteoff')) { state.noteEdit = false; leadRender(); }
    else if (ds.addto) { state.adding = ds.addto; state.pErr = null; state.pVal = null; leadRender(); const x = root.querySelector('[data-add] input'); if (x) { x.focus({ preventScroll: true }); x.closest('[data-add]').scrollIntoView({ block: 'nearest' }); } }
    else if (b.hasAttribute('data-addoff')) { state.adding = ''; state.pErr = null; state.pVal = null; leadRender(); }
    else if (ds.move) { state.moving = +ds.move; leadRender(); const x = root.querySelector('[data-moveto]'); if (x) x.focus(); }
    else if (b.hasAttribute('data-moveoff')) { state.moving = 0; leadRender(); }
    else if (ds.moveto) { state.moving = 0; leadAct('move', { id: +ds.rid, to: ds.moveto }, 'Moved').catch(() => {}); }
    else if (ds.remove) { const id = +ds.remove; leadAct('remove', { id }, 'Removed', () => leadAct('restore', { id }, 'Back on the list')).catch(() => {}); }
    else if (ds.offer) leadAct('offer', { id: +ds.offer }, 'Offered · Email sent').catch(() => {});
    else if (b.hasAttribute('data-remind')) { try { const d = await post('vol/' + state.year + '/lead/remind', { committee: state.committee }); showToast({ kind: 'ok', text: 'Sending · ' + plural(d.queued, 'household') }); } catch (x) { showToast({ kind: 'no', text: x.status === 429 ? 'Sent today' : 'Not sent' }); } }
    // Clear samples asks in the page (never a browser pop-up).
    else if (b.hasAttribute('data-clearsamples')) { state.clearAsk = true; leadRender(); const x = root.querySelector('[data-clearsamples-go]'); if (x) x.focus(); }
    else if (b.hasAttribute('data-clearsamples-off')) { state.clearAsk = false; leadRender(); }
    else if (b.hasAttribute('data-clearsamples-go')) { b.disabled = true; try { await call('DELETE', 'years/' + state.year + '/samples?kind=signups'); await call('DELETE', 'years/' + state.year + '/samples?kind=waits'); state.clearAsk = false; await leadLoad(''); leadRender(); showToast({ kind: 'ok', text: 'Samples cleared' }); } catch (x) { b.disabled = false; showToast({ kind: 'error', text: 'Not cleared' }); } }
  });
  root.addEventListener('change', async e => {
    const t = e.target;
    if (t.matches('[data-openonly]')) { state.openOnly = t.checked; render(); const x = root.querySelector('[data-openonly]'); if (x) x.focus(); }
    else if (t.matches('[data-who]')) { const v = Array.from(root.querySelectorAll('[data-who]:checked')).map(x => x.value); if (!v.length) { t.checked = true; return; } kept.set('who-' + state.year, v); render(); const x = root.querySelector('[data-who][value="' + CSS.escape(t.value) + '"]'); if (x) x.focus(); }
    else if (t.matches('[data-showname]')) setMe(t.dataset.showname ? { show: t.checked, name: t.dataset.showname } : { show: t.checked });
    else if (t.matches('[data-nextyear]')) setMe({ next_year: t.checked });
    else if (t.matches('[data-leadopen]')) { state.leadOpen = t.checked; leadRender(); }
    else if (t.matches('[data-here]')) post('vol/' + state.year + '/lead/here', { committee: state.committee, id: +t.dataset.here, here: t.checked }).catch(() => { t.checked = !t.checked; });
  });
  root.addEventListener('input', e => {
    if (e.target.matches('[data-find]')) { state.findQ = e.target.value; clearTimeout(state.findT); state.findT = setTimeout(() => { const pos = e.target.selectionStart; leadRender(); const x = root.querySelector('[data-find]'); if (x) { x.focus(); x.setSelectionRange(pos, pos); } const hit = root.querySelector('.is-hit'); if (hit) hit.scrollIntoView({ block: 'center' }); }, 200); }
  });
  root.addEventListener('submit', async e => {
    e.preventDefault();
    const f = e.target;
    if (f.matches('[data-emailform]')) changeEmail(f);
    else if (f.matches('[data-notify]')) {
      const em = f.email ? f.email.value.trim() : '';
      const err = f.querySelector('.vol-err');
      if (f.email && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(em)) { err.hidden = false; err.textContent = 'Enter your email'; f.email.setAttribute('aria-invalid', 'true'); f.email.focus(); return; }
      const ny = f.dataset.notify || state.year;
      try { await post('vol/' + ny + '/notify', { email: em, hp: f.hp.value }); kept.set('asked-' + ny, true); render(); say.textContent = 'We’ll email you'; } catch (x) { if (err) { err.hidden = false; err.textContent = 'Not saved · Retry'; } }
    } else if (f.matches('[data-add]') || f.matches('[data-edit]')) {
      // Add or Edit: each error at its field, the form kept as typed (never a toast).
      const add = f.matches('[data-add]');
      state.pVal = { name: f.name.value, phone: f.phone.value, email: f.email.value, note: f.note ? f.note.value : '' };
      try {
        await post('vol/' + state.year + '/lead/' + (add ? 'add' : 'edit'), Object.assign({ committee: state.committee }, add ? { shift: f.dataset.add, note: state.pVal.note } : { id: +f.dataset.edit }, { name: state.pVal.name, phone: state.pVal.phone, email: state.pVal.email }));
        state.adding = ''; state.editing = 0; state.pErr = null; state.pVal = null;
        await leadLoad(state.committee); leadRender();
        say.textContent = add ? 'Added' : 'Saved';
      } catch (x) {
        const w = x.data || {};
        state.pErr = w.fields ? w.fields : { form: w.why === 'busy' ? busyOf(w.busy) : w.why === 'full' ? 'Full' : w.why === 'dup' ? 'Already on it' : 'Not saved · Retry' };
        leadRender();
        const bad = root.querySelector('[data-add] [aria-invalid="true"], [data-edit] [aria-invalid="true"]') || root.querySelector('[data-add] input, [data-edit] input');
        if (bad) bad.focus();
      }
    } else if (f.matches('[data-note]')) {
      const sv = f.querySelector('[data-notesaved]');
      try { const d = await post('vol/' + state.year + '/lead/note', { committee: state.committee, text: f.text.value }); state.lead.note = d.note; state.noteEdit = false; leadRender(); say.textContent = 'Saved'; }
      catch (x) { if (sv) sv.textContent = 'Not saved'; }
    } else if (f.matches('[data-contact]')) {
      try {
        const body = { email: f.email.value, phone: f.phone.value, weekly: f.weekly.checked };
        if (f.heads) body.heads = f.heads.value;
        const d = await post('vol/' + state.year + '/lead/contact', Object.assign({ committee: state.committee }, body));
        state.lead.contact = Object.assign({}, state.lead.contact, d);
        const s = f.querySelector('[data-saved]'); if (s) s.textContent = 'Saved';
      } catch (x) { const s = f.querySelector('[data-saved]'); if (s) s.textContent = x.data && x.data.fields ? Object.values(x.data.fields).join(' · ') : 'Not saved'; }
    }
  });

  async function setMe(o) {
    try { merge(await post('vol/' + state.year + '/me', o)); if (state.live.me && !o.name) Object.assign(state.live.me, o); render(); if (sheet.open && state.sheet) drawSheet(); say.textContent = o.show != null ? (o.show ? 'Name shown' : 'Name hidden') : o.next_year ? 'We’ll email you next year' : 'Off'; }
    catch (x) { showToast({ kind: 'error', text: 'Not saved' }); }
  }

  // Sign up again: the toggled rows, through the same Join as everything else (one result each).
  async function againGo() {
    const sec = root.querySelector('.vol-again'), ids = Array.from(sec.querySelectorAll('[data-again]:checked')).map(x => x.dataset.again);
    const err = sec.querySelector('.vol-again__err');
    if (!ids.length) return;
    const shs = ids.map(find), answers = {};
    let missing = '';
    shs.filter(needsAsk).forEach(sh => {
      if (question(sh).length) { const v = sec.querySelector('[name="againq-' + CSS.escape(sh.committee) + '"]:checked'); if (v) answers['q:' + sh.id] = v.value; else missing = 'Choose one for ' + sh.committee; }
      else { const c = sec.querySelector('[data-againrule="' + CSS.escape(ruleShort(sh)) + '"]'); if (!c || !c.checked) missing = 'Confirm: ' + claim(ruleShort(sh), 1); }
    });
    if (missing) { err.hidden = false; err.textContent = missing; return; }
    const btn = sec.querySelector('[data-againgo]'); btn.disabled = true; btn.textContent = 'Signing up…';
    const ag = live().again || [];
    let ok = 0; const no = [], made = [];
    // One request per group of the same people and answers (so each shift is its own result).
    for (const sh of shs) {
      const a = ag.find(x => x.shift === sh.id) || { names: [] };
      const body = { shifts: [sh.id], people: a.names, answers: { rule: true }, show: true };
      if (answers['q:' + sh.id]) body.answers.question = answers['q:' + sh.id];
      try { const d = await post('vol/' + state.year + '/join', body); merge(d); (d.made || []).forEach(x => made.push(x)); d.results.forEach(r => { if (r.status === 'ok') ok++; else no.push(refusal(r, sh).msg + ' · ' + sh.role); }); }
      catch (x) { no.push('Not saved · ' + sh.role); }
    }
    state.againUsed = true;
    render();
    // Undo, as for a row's Join: the sign-ups this made.
    showToast({ kind: ok ? 'ok' : 'no', text: ok ? 'Signed up · ' + plural(ok, 'shift') : no[0] || 'Not saved', sub: ok && no.length ? no.join(' · ') : '', ids: made.length ? made : undefined, shifts: ok ? uniq(mine().filter(m => made.indexOf(m.rid) > -1).map(m => m.shift)) : undefined });
  }

  // Emailed links.
  async function linkLeave() {
    const k = state.link;
    try { const d = await post('vol/' + state.year + '/leave', Object.assign({ ids: (k.records || []).map(r => r.rid) }, k.via)); merge(d); k.left = true; await refresh(true); }
    catch (x) { showToast({ kind: 'error', text: x.data && x.data.why === 'started' ? 'Started · Call the head' : 'Not saved' }); }
  }
  // Find replacement from the emailed Leave link (the link's own token vouches for it).
  async function linkSwap() {
    const k = state.link, r = (k.records || [])[0];
    if (!r) return;
    try { const d = await post('vol/' + state.year + '/swap', Object.assign({ id: r.rid, on: true }, k.via)); k.swap = d.swap; render(); const sh = find(r.shift); if (sh && d.swap) copyLink(swapUrl(sh, d.swap), 'Link copied', 'Could you take my place? ' + sh.role + ', ' + whenShort(sh)); }
    catch (x) { showToast({ kind: 'error', text: 'Not saved · Retry' }); }
  }
  async function linkJoin() {
    const k = state.link, shs = (k.shifts || []).map(find).filter(Boolean);
    if (!shs.length) return;
    if (shs.some(needsAsk) || !k.names.length) { openShift(shs[0].id); state.form = {}; drawSheet(); revealForm(); return; }
    try {
      const d = await post('vol/' + state.year + '/join', Object.assign({ shifts: shs.map(s => s.id), people: k.names, show: true }, k.via));
      merge(d); const ok = d.results.filter(r => r.status === 'ok').length; k.done = true; render();
      const r = d.results.find(x => x.status !== 'ok');
      showToast({ kind: ok ? 'ok' : 'no', text: ok ? 'Signed up · ' + plural(ok, 'shift') : r && r.status === 'full' ? 'Taken · Still on waitlist' : refusal(r || {}, shs[0]).msg, shifts: ok ? d.results.filter(x => x.status === 'ok').map(x => x.shift) : undefined });
    } catch (x) { showToast({ kind: 'error', text: 'Not saved', retry: linkJoin }); }
  }

  // Leave waitlist, from the emailed "A place opened".
  async function linkUnwait() {
    try { const d = await post('vol/' + state.year + '/link', Object.assign({ do: 'unwait' }, state.link.via)); state.link = Object.assign(state.link, d); await refresh(true); }
    catch (x) { showToast({ kind: 'error', text: 'Not saved · Retry' }); }
  }

  sheet.addEventListener('click', async e => {
    if (e.target === sheet || e.target.closest('[data-close]')) { sheet.close(); return; }
    const a = e.target.closest('[data-pick]');
    if (a && !e.metaKey && !e.ctrlKey) { e.preventDefault(); sheet.close(); pickCommittee(a.dataset.pick); return; }
    const b = e.target.closest('button');
    if (!b) return;
    const sh = find(state.sheet), ds = b.dataset;
    if (emailClick(b)) return;
    if (b.hasAttribute('data-whoedit')) { state.form = { people: chosen() }; drawSheet(); const x = sheet.querySelector('[name=who]'); if (x) { x.focus(); x.closest('.vol-whof').scrollIntoView({ block: 'nearest' }); } return; }
    if (b.hasAttribute('data-joinnow')) joinNow(sh);
    else if (b.hasAttribute('data-waitnow')) { if (!signed() && !state.form) { state.form = {}; drawSheet(); revealForm(); } else { keepForm(); waitFor(sh, signed() ? null : state.form); } }
    else if (ds.leave) { state.leaving = ds.leave; state.barErr = ''; drawSheet(); const x = sheet.querySelector('[data-leavego]'); if (x) x.focus(); }
    else if (b.hasAttribute('data-leaveoff')) { state.leaving = ''; drawSheet(); const x = sheet.querySelector('[data-leave]'); if (x) x.focus(); }
    else if (b.hasAttribute('data-leavego')) leave(sh);
    else if (b.hasAttribute('data-swapon')) swap(sh, true);
    else if (ds.swapoff) swap(sh, false, +ds.swapoff);
    else if (ds.swapcopy) copyLink(swapUrl(sh, ds.swapcopy), 'Link copied', 'Could you take my place? ' + sh.role + ', ' + whenShort(sh));
    else if (b.hasAttribute('data-take')) take(sh);
    else if (ds.unwait) { try { merge(await post('vol/' + state.year + '/unwait', { ids: [+ds.unwait] })); render(); drawSheet(); say.textContent = 'Off the waitlist'; } catch (x) { state.barErr = 'Not saved'; drawSheet(); } }
    else if (ds.invite) invite(ds.invite);
    else if (ds.ics) downloadIcs([ds.ics]);
    else if (ds.shift) openShift(ds.shift);
    else if (b.hasAttribute('data-map')) { state.mapOpen = !state.mapOpen; keepForm(); drawSheet(); const x = sheet.querySelector('[data-map]'); if (x) x.focus(); }
    else if (b.hasAttribute('data-typo')) {
      keepForm();
      const fixed = typoFix(state.form.email) || state.typo || state.form.email, inp = sheet.querySelector('[data-form] [name=email]');
      if (inp) inp.value = fixed;
      state.form.email = fixed; state.typo = '';
      if (state.err && state.err.email && state.err.email.html) { state.err = null; joinNow(sh); } else drawSheet();
    }
    else if (b.hasAttribute('data-typokeep')) { keepForm(); state.typoOk = state.form.email; state.err = null; joinNow(sh); }
    // A head's message.
    else if (ds.msgto) { const f = sheet.querySelector('[data-msg]'); state.msgKeep = { subject: f.subject.value, body: f.body.value }; messageSheet(ds.msgto); }
    else if (b.hasAttribute('data-msgsend')) {
      const f = sheet.querySelector('[data-msg]'), err = sheet.querySelector('[data-msgerr]');
      if (!f.body.value.trim()) { err.hidden = false; err.textContent = 'Write the message'; f.body.focus(); return; }
      b.disabled = true; b.textContent = 'Sending…';
      try {
        const d = await post('vol/' + state.year + '/lead/message', { committee: state.committee, to: state.msgTo, subject: f.subject.value, body: f.body.value, copy: f.copy.checked });
        sheet.close(); state.msgKeep = null; await leadLoad(state.committee); leadRender();
        showToast({ kind: 'ok', text: 'Sending · ' + plural(d.queued, state.msgTo === 'heads' ? 'person' : 'volunteer', state.msgTo === 'heads' ? 'people' : undefined), sub: d.call && d.call.length ? 'Call ' + d.call.length + ' with no email: ' + d.call.slice(0, 3).join(', ') : '' });
      } catch (x) { b.disabled = false; b.innerHTML = I.mail + 'Send · ' + esc(plural(msgCount(state.msgTo), 'person', 'people')); err.hidden = false; err.textContent = x.status === 429 ? 'Five messages a day' : 'Not sent · Retry'; }
    }
  });
  sheet.addEventListener('submit', e => { e.preventDefault(); if (e.target.matches('[data-emailform]')) return changeEmail(e.target); if (e.target.matches('[data-headedit]')) return; const sh = find(state.sheet); if (sh) { const f = sheet.querySelector('[data-form]'); if (f && open(sh) <= 0) { keepForm(); waitFor(sh, state.form); } else joinNow(sh); } });
  sheet.addEventListener('change', e => { if (e.target.matches('[data-showname]')) setMe({ show: e.target.checked }); });
  sheet.addEventListener('keydown', e => { if (e.key === 'Enter' && e.target.matches('[data-form] input:not([type=checkbox]):not([type=radio])')) { e.preventDefault(); joinNow(find(state.sheet)); } });
  sheet.addEventListener('close', () => {
    clearInterval(state.tick);
    const id = state.sheet;
    state.leaving = ''; state.form = null; state.err = null; state.barErr = ''; state.barNote = null; state.emailEdit = '';
    if (state.sheet) { state.sheet = ''; state.done = null; setUrl({ shift: '', swap: '' }); }
    // Focus back where the sheet was opened from: the row or cell, by shift id.
    const back = id && (root.querySelector('[data-row="' + CSS.escape(id) + '"] [data-shift], [data-shift="' + CSS.escape(id) + '"]'));
    if (back) back.focus(); else if (opener) { const x = root.querySelector(opener); if (x) x.focus(); }
  });

  /* ---------------------------------------------------------------- boot */

  (O.ready || Promise.resolve()).then(() => fetch(BASE + 'years.csv', { cache: 'no-store' })).then(r => r.text()).then(async text => {
    const years = O.csvToObjects(text).filter(y => y.year).sort((a, b) => b.year - a.year);
    state.years = years;
    state.row = years.find(y => y.year === String(state.year)) || years.find(y => y.data) || years[0];
    state.year = state.row.year;
    if (!state.row.data) {
      // A year with no shifts yet (2028): its own name and hosts, Not posted yet.
      state.model = { settings: {}, days: [], tz: 'America/Indiana/Indianapolis' };
      try { await loadLive(); } catch (e) { state.live = null; }
      state.shifts = [];
      return render();
    }
    const folder = BASE + state.row.data + '/';
    state.model = await O.loadSchedule(folder);
    const shiftsText = await fetch(folder + 'shifts.csv', { cache: 'no-store' }).then(r => r.ok ? r.text() : '');
    state.shifts = SU.expandShifts(O.csvToObjects(shiftsText), state.model);
    if (O.map) {
      const campusText = await fetch(folder + 'campus.csv', { cache: 'no-store' }).then(r => r.ok ? r.text() : '').catch(() => '');
      const c = O.map.campus(O.csvToObjects(campusText));
      state.campus = c.items.length ? c : null;
    }
    // An emailed link: the server put its token in a short cookie and opened this clean address
    // (?link=1), so the token is never in the address bar. What it is, answered before the page is
    // drawn; then ?link (or an old ?t=) leaves the address at once (history, bookmarks, a copied link).
    const t = q.get('t'), via = t ? { t } : q.get('link') ? { link: 1 } : null;
    if (via) {
      try { state.link = Object.assign({ via }, await call('POST', 'vol/' + state.year + '/link', via).catch(async e => { if (e.status === 403) { await loadLive(); return post('vol/' + state.year + '/link', via); } throw e; })); } catch (e) { state.link = { error: true }; }
      const u = new URL(location.href); u.searchParams.delete('t'); u.searchParams.delete('link'); history.replaceState(null, '', u);
    }
    // Said once: the address loses ?confirmed= (a reload, or a Leave after it, never repeats "2 shifts").
    if (q.get('confirmed') != null) {
      state.link = { a: 'confirm', n: +q.get('confirmed') };
      const u = new URL(location.href); u.searchParams.delete('confirmed'); history.replaceState(null, '', u);
    }
    await loadLive();
    if (state.view === 'lead') { await leadLoad(state.committee || null); return leadRender(); }
    render();
    const id = q.get('shift');
    if (id && find(id)) openShift(id, false);
  }).catch(err => {
    console.error(err);
    root.removeAttribute('aria-busy');
    const m = root.querySelector('.wk-main .wk-wrap') || root;
    m.innerHTML = '<section class="vol-blank"><h2 class="vol-blank__h">Couldn’t load</h2><p><button type="button" class="wk-btn wk-btn--line wk-btn--small" onclick="location.reload()">Retry</button></p></section>';
  });
})();
