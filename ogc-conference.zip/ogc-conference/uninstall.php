<?php
/**
 * Deleting the plugin in wp-admin. By default nothing a Conference kept is erased: the tables (the
 * years, their files, sign-ups, registrations, the ledger) stay, so a plugin deleted by mistake can be
 * installed again with everything there. Only the timers and the cached answers go.
 *
 * To erase everything, define in wp-config.php before deleting the plugin:
 *   define( 'OGC_UNINSTALL_ERASE', true );
 * Then the plugin's tables, its options (ogc_*), its user meta (ogc_*), the private files folder, and
 * the ogc_person role go. The WordPress users the plugin made (role ogc_person) are kept with the role
 * changed to subscriber: removing users is a webmaster's decision in Users.
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

foreach ( array( 'ogc_vol_tick', 'ogc_daily', 'ogc_reg_daily', 'ogc_lodging_daily', 'ogc_mail_queue' ) as $ogc_hook ) {
	wp_clear_scheduled_hook( $ogc_hook );
}

global $wpdb;
// Transients (sign-in throttles, editors' presence, rate counts).
$wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '\\_transient\\_ogc\\_%' OR option_name LIKE '\\_transient\\_timeout\\_ogc\\_%'" ); // phpcs:ignore -- no input.

if ( ! defined( 'OGC_UNINSTALL_ERASE' ) || true !== OGC_UNINSTALL_ERASE ) {
	return;
}

// The tables: every one named <prefix>ogc_…
$ogc_like   = $wpdb->esc_like( $wpdb->prefix . 'ogc_' ) . '%';
$ogc_tables = (array) $wpdb->get_col( $wpdb->prepare( 'SHOW TABLES LIKE %s', $ogc_like ) );
foreach ( $ogc_tables as $ogc_t ) {
	if ( 0 === strpos( $ogc_t, $wpdb->prefix . 'ogc_' ) && preg_match( '/^[A-Za-z0-9_]+$/', $ogc_t ) ) {
		$wpdb->query( "DROP TABLE IF EXISTS `$ogc_t`" ); // phpcs:ignore -- a name checked above.
	}
}
// Options and user meta.
$wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE 'ogc\\_%'" ); // phpcs:ignore -- no input.
$wpdb->query( "DELETE FROM {$wpdb->usermeta} WHERE meta_key LIKE 'ogc\\_%'" ); // phpcs:ignore -- no input.
// The plugin's people stay as subscribers; the role goes.
foreach ( get_users( array( 'role' => 'ogc_person', 'fields' => 'ID' ) ) as $ogc_uid ) {
	$ogc_u = get_userdata( (int) $ogc_uid );
	if ( $ogc_u ) {
		$ogc_u->set_role( 'subscriber' );
	}
}
remove_role( 'ogc_person' );
// The committees' private files.
$ogc_dir = defined( 'OGC_PRIVATE_DIR' ) ? OGC_PRIVATE_DIR : trailingslashit( wp_upload_dir()['basedir'] ) . 'ogc-private';
if ( is_dir( $ogc_dir ) && false === strpos( $ogc_dir, '://' ) ) {
	$ogc_it = new RecursiveIteratorIterator( new RecursiveDirectoryIterator( $ogc_dir, FilesystemIterator::SKIP_DOTS ), RecursiveIteratorIterator::CHILD_FIRST );
	foreach ( $ogc_it as $ogc_f ) {
		$ogc_f->isDir() ? rmdir( $ogc_f->getPathname() ) : unlink( $ogc_f->getPathname() );
	}
	rmdir( $ogc_dir );
}
delete_option( 'rewrite_rules' );
