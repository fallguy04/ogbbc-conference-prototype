<?php
/**
 * Lodging's page (lodging area): the frame the board draws into, with a quiet skeleton while the
 * year loads (no bare "Loading…"). A back-end page: no site header or footer.
 */
defined( 'ABSPATH' ) || exit;
?>
<main id="main" tabindex="-1">
	<div id="ogc-lodging" class="ogc" data-base="<?php echo esc_attr( trailingslashit( ogc_data_base() ) ); ?>" aria-busy="true">
		<div class="wk vol lod ws">
			<header class="ws-bar ws-bar--page"><div class="ws-bar__in"><div class="ws-title"><p class="wk-kicker">&nbsp;</p><h1><?php esc_html_e( 'Lodging', 'ogc-conference' ); ?></h1></div></div></header>
			<div class="ws-body ws-body--page lod-skel" aria-hidden="true">
				<p class="lod-skel__line"></p>
				<div class="lod-skel__grid"><span></span><span></span><span></span><span></span></div>
			</div>
			<p class="ogc-sr" role="status"><?php esc_html_e( 'Loading', 'ogc-conference' ); ?></p>
		</div>
	</div>
</main>
