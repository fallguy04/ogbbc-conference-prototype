<?php
/**
 * Sign-in: one page for everyone (signin area). The state comes from ogc_signin_page()
 * (includes/module-auth.php): form · sent · confirm (a link's card) · expired · used · invalid · hint ·
 * signedin · choose · refused · reauth. Every form works without scripts (the page posts to itself and
 * redirects); assets/signin/signin.js adds the inline checks, the code's auto-submit and Resend's wait.
 *
 * A cream band with the year and the heading, then one white card: one field, one filled button, at
 * most two quiet links.
 */
defined( 'ABSPATH' ) || exit;

// Drawn for a members' page that refused (core's ogc_page_refuse) without the page's own pass.
if ( empty( $GLOBALS['ogc_signin'] ) && function_exists( 'ogc_signin_page' ) ) {
	ogc_signin_page( 'signin' );
}
$s       = isset( $GLOBALS['ogc_signin'] ) ? (array) $GLOBALS['ogc_signin'] : array( 'state' => 'form' );
$st      = isset( $s['state'] ) ? $s['state'] : 'form';
$ret     = isset( $s['return'] ) ? (string) $s['return'] : '';
$email   = isset( $s['email'] ) ? (string) $s['email'] : '';
$err     = isset( $s['error'] ) ? (string) $s['error'] : '';
$year    = ! empty( $s['year'] ) ? (int) $s['year'] : ( function_exists( 'ogc_auth_year' ) ? ogc_auth_year( $ret, is_user_logged_in() ? ogc_current_email() : '' ) : (int) gmdate( 'Y' ) );
$self    = ogc_url( 'signin' );
$another = ogc_url( 'signin', array_filter( array( 'return' => rawurlencode( $ret ) ) ) );
$from    = function_exists( 'ogc_mail_from' ) ? ogc_mail_from() : array( 'email' => '' );
$heads   = array(
	'form'     => ! empty( $s['dest'] ) ? (string) $s['dest'] : 'Sign in',
	'sent'     => 'Check your email',
	'confirm'  => 'Sign in',
	'expired'  => 'Link expired',
	'used'     => 'Link already used',
	'invalid'  => 'Link not valid',
	'hint'     => 'Your sign-ups',
	'signedin' => 'Signed in',
	'choose'   => 'Choose a year',
	'refused'  => 'No access',
	'reauth'   => 'Confirm it’s you',
);
$kinds = function_exists( 'ogc_token_kinds' ) ? ogc_token_kinds() : array();
$tok   = isset( $s['token'] ) ? $s['token'] : null;
if ( 'confirm' === $st && $tok ) {
	$heads['confirm'] = ogc_token_word( $tok['kind'], 'heading', $tok, $heads['confirm'] );
}
$h1 = isset( $heads[ $st ] ) ? $heads[ $st ] : 'Sign in';

/** The email form (Sign in, and a link that isn't one of ours). */
$email_form = function ( $email, $err, $field_err ) use ( $ret, $self ) {
	?>
	<form class="si-form" method="post" action="<?php echo esc_url( $self ); ?>" novalidate data-si="send">
		<input type="hidden" name="ogc_do" value="send">
		<input type="hidden" name="return" value="<?php echo esc_attr( $ret ); ?>">
		<label class="si-label" for="si-email">Email</label>
		<input class="si-input" id="si-email" name="email" type="email" value="<?php echo esc_attr( $email ); ?>" autocomplete="email" inputmode="email" autocapitalize="none" autocorrect="off" spellcheck="false" enterkeyhint="send" maxlength="190" aria-describedby="si-email-err"<?php echo $field_err ? ' aria-invalid="true"' : ''; ?>>
		<p class="si-err" id="si-email-err"<?php echo $field_err && $err ? '' : ' hidden'; ?>><?php echo $field_err ? esc_html( $err ) : ''; ?></p>
		<p class="si-suggest" hidden></p>
		<button type="submit" class="wk-btn si-go">Send code</button>
		<p class="si-err si-err--send" role="alert"<?php echo ! $field_err && $err ? '' : ' hidden'; ?>><?php echo ! $field_err ? esc_html( $err ) : ''; ?></p>
	</form>
	<?php
};
?>
<main id="main" tabindex="-1">
	<div id="ogc-signin" class="ogc wk si" data-state="<?php echo esc_attr( $st ); ?>" data-return="<?php echo esc_attr( $ret ); ?>" data-base="<?php echo esc_attr( wp_make_link_relative( ogc_url() ) ); ?>">
		<section class="si-band">
			<div class="si-wrap">
				<p class="wk-kicker"><?php echo esc_html( 'choose' === $st ? 'Annual Conference' : $year . ' Annual Conference' ); ?></p>
				<h1 class="si-h" id="si-h" tabindex="-1"><?php echo esc_html( $h1 ); ?></h1>
				<?php if ( ! empty( $s['status'] ) ) : ?>
					<p class="si-status" role="status"><?php echo esc_html( $s['status'] ); ?></p>
				<?php endif; ?>
			</div>
		</section>
		<div class="si-wrap">
			<div class="si-card">
			<?php if ( 'sent' === $st ) : ?>
				<?php
				$resend_at = isset( $s['resend_at'] ) ? (int) $s['resend_at'] : 0;
				$wait      = $resend_at - time();
				?>
				<p class="si-addr"><?php echo ogc_email_wbr( $email ); ?></p>
				<?php if ( ! empty( $s['elsewhere'] ) ) : ?>
					<?php // The email's button was tapped on another device (a phone): that one is signed in; here the code still works. ?>
					<p class="si-status si-status--card" role="status">Signed in on another device · Code still works here</p>
				<?php endif; ?>
				<form class="si-form" method="post" action="<?php echo esc_url( $self ); ?>" novalidate data-si="code">
					<input type="hidden" name="ogc_do" value="code">
					<label class="si-label" for="si-code">Code</label>
					<input class="si-input si-input--code" id="si-code" name="code" type="text" value="<?php echo esc_attr( isset( $s['typed'] ) ? $s['typed'] : '' ); ?>" autocomplete="one-time-code" inputmode="numeric" pattern="[0-9 ]*" maxlength="9" enterkeyhint="done" aria-describedby="si-code-err si-code-help"<?php echo ! empty( $s['code_error'] ) ? ' aria-invalid="true"' : ''; ?>>
					<p class="si-err" id="si-code-err" role="alert"<?php echo empty( $s['code_error'] ) ? ' hidden' : ''; ?>><?php echo esc_html( isset( $s['code_error'] ) ? $s['code_error'] : '' ); ?></p>
					<?php // True of both emails: a code and a link, or (codes off) a link only. ?>
					<p class="si-help" id="si-code-help"><?php echo esc_html( 'Code or link in the email · From ' . $from['email'] . ' · Check spam' ); ?></p>
					<button type="submit" class="wk-btn si-go">Sign in</button>
				</form>
				<div class="si-links">
					<form method="post" action="<?php echo esc_url( $self ); ?>" class="si-inline">
						<input type="hidden" name="ogc_do" value="resend">
						<?php // Resend waits for the server's own limits: a minute, then the 15-minute window. ?>
						<button type="submit" class="si-quiet" data-resend data-at="<?php echo (int) $resend_at; ?>" data-now="<?php echo (int) time(); ?>"<?php echo $wait > 0 ? ' disabled' : ''; ?>><?php echo esc_html( $wait > 300 ? 'Resend in ' . ogc_wait_words( $resend_at ) : ( $wait > 0 ? 'Resend in ' . floor( $wait / 60 ) . ':' . str_pad( (string) ( $wait % 60 ), 2, '0', STR_PAD_LEFT ) : 'Resend' ) ); ?></button>
					</form>
					<a class="si-quiet" href="<?php echo esc_url( $another ); ?>">Use another email</a>
				</div>
				<?php if ( ! empty( $s['limited'] ) ) : ?>
					<p class="si-help si-help--limit" role="status">The code already sent still works</p>
				<?php endif; ?>
				<?php // The desk's laptop: a setting of this browser, kept for every later sign-in here. Off by default. ?>
				<form method="post" action="<?php echo esc_url( $self ); ?>" class="si-shared">
					<input type="hidden" name="ogc_do" value="shared">
					<input type="hidden" name="on" value="<?php echo empty( $s['shared'] ) ? '1' : '0'; ?>">
					<button type="submit" class="si-switch" role="switch" aria-checked="<?php echo empty( $s['shared'] ) ? 'false' : 'true'; ?>">
						<span class="si-switch__sw" aria-hidden="true"></span>
						<span class="si-switch__t"><b>Shared device</b><small>Signs out when the browser closes</small></span>
					</button>
				</form>

			<?php elseif ( 'confirm' === $st && $tok ) : ?>
				<p class="si-addr"><?php echo ogc_email_wbr( $tok['email'] ); ?></p>
				<?php if ( ogc_token_signs_in( $tok['kind'] ) && is_user_logged_in() && ogc_current_email() !== $tok['email'] ) : ?>
					<?php // A family iPad: someone else is signed in here, and this button changes that. ?>
					<p class="si-help"><?php echo esc_html( 'Signed in as ' . ogc_mask_email( ogc_current_email() ) . ' on this device' ); ?></p>
				<?php endif; ?>
				<?php if ( ! empty( $tok['data']['label'] ) ) : ?>
					<p class="si-from"><?php echo esc_html( (string) $tok['data']['label'] ); ?></p>
				<?php endif; ?>
				<?php
				// What the link is about, shown only now that it's opened (a parent's approval: who, which nights).
				$facts = isset( $kinds[ $tok['kind'] ]['facts'] ) && is_callable( $kinds[ $tok['kind'] ]['facts'] ) ? (array) call_user_func( $kinds[ $tok['kind'] ]['facts'], $tok ) : array();
				?>
				<?php if ( $facts ) : ?>
					<dl class="si-facts">
						<?php foreach ( $facts as $f ) : ?>
							<?php if ( is_array( $f ) && isset( $f[1] ) && '' !== (string) $f[1] ) : ?>
								<dt><?php echo esc_html( $f[0] ); ?></dt><dd><?php echo esc_html( $f[1] ); ?></dd>
							<?php endif; ?>
						<?php endforeach; ?>
					</dl>
				<?php endif; ?>
				<?php
				// Why one tap (a volunteer's Confirm on another device): a kind's own short help, never on
				// the card that posts itself.
				$tap_help = empty( $s['auto'] ) ? ogc_token_word( $tok['kind'], 'help', $tok, '' ) : '';
				?>
				<?php if ( '' !== $tap_help ) : ?>
					<p class="si-help si-help--tap"><?php echo esc_html( $tap_help ); ?></p>
				<?php endif; ?>
				<form class="si-form" method="post" action="<?php echo esc_url( $self ); ?>"<?php echo ! empty( $s['auto'] ) ? ' data-auto' : ''; ?>>
					<input type="hidden" name="ogc_do" value="link">
					<input type="hidden" name="t" value="<?php echo esc_attr( isset( $s['raw'] ) ? $s['raw'] : '' ); ?>">
					<input type="hidden" name="k" value="<?php echo esc_attr( isset( $s['land'] ) ? $s['land'] : '' ); ?>">
					<button type="submit" class="wk-btn si-go"><?php echo esc_html( ogc_token_word( $tok['kind'], 'button', $tok, 'Sign in' ) ); ?></button>
						<?php if ( ! empty( $kinds[ $tok['kind'] ]['decline'] ) ) : ?>
							<div class="si-links"><button type="submit" class="si-quiet" name="alt" value="1"><?php echo esc_html( isset( $kinds[ $tok['kind'] ]['decline']['label'] ) ? $kinds[ $tok['kind'] ]['decline']['label'] : 'Decline' ); ?></button></div>
						<?php endif; ?>
					</form>
					<?php if ( ogc_token_signs_in( $tok['kind'] ) ) : ?>
						<div class="si-links"><a class="si-quiet" href="<?php echo esc_url( $self ); ?>">Not you? Use another email</a></div>
					<?php endif; ?>

			<?php elseif ( 'expired' === $st || 'used' === $st ) : ?>
				<p class="si-addr"><?php echo ogc_email_wbr( isset( $s['masked'] ) ? $s['masked'] : '' ); ?></p>
				<?php
				// What's true of this link, not the rules for every kind.
				$lasts = array( 'signin' => 'Sign-in links last 30 minutes', 'invite' => 'Invite links last 7 days', 'webmaster' => 'Invite links last 7 days', 'confirm' => 'This link lasted 7 days' );
				$kind  = isset( $s['kind'] ) ? $s['kind'] : '';
				$why   = 'used' === $st ? 'Each link works once' : ( isset( $lasts[ $kind ] ) ? $lasts[ $kind ] : '' );
				?>
				<?php if ( $why ) : ?>
					<p class="si-help"><?php echo esc_html( $why ); ?></p>
				<?php endif; ?>
				<?php if ( ! empty( $s['again'] ) ) : ?>
					<form class="si-form" method="post" action="<?php echo esc_url( $self ); ?>">
						<input type="hidden" name="ogc_do" value="again">
						<input type="hidden" name="t" value="<?php echo esc_attr( isset( $s['raw'] ) ? $s['raw'] : '' ); ?>">
						<input type="hidden" name="k" value="<?php echo esc_attr( isset( $s['land'] ) ? $s['land'] : '' ); ?>">
						<button type="submit" class="wk-btn si-go">Send new code</button>
					</form>
				<?php endif; ?>
				<div class="si-links"><a class="si-quiet" href="<?php echo esc_url( $self ); ?>">Use another email</a></div>

			<?php elseif ( 'hint' === $st ) : ?>
				<?php
				// From a confirmation email: one tap sends a code to the address it went to. One plain line
				// says why, and the address shows as it's written, not in the button's capitals (after the
				// third critic, Oct 15).
				$hint_why = isset( $s['why'] ) ? (string) $s['why'] : '';
				$hint_say = 'used' === $hint_why ? 'Link already used · We’ll email a code' : ( 'expired' === $hint_why ? 'Link expired · We’ll email a code' : 'We’ll email a code' );
				?>
				<?php $hint_truth = ! empty( $s['truth']['h'] ) ? $s['truth'] : null; ?>
				<?php if ( $hint_truth ) : ?>
					<?php // What's true of the link's places, as the same email's Leave link says it (after the sixth critic, Oct 15). ?>
					<p class="si-what si-truth__h"><?php echo esc_html( $hint_truth['h'] ); ?></p>
					<?php foreach ( array_slice( (array) $hint_truth['lines'], 0, 6 ) as $truth_line ) : ?>
						<p class="si-help si-truth__l"><?php echo esc_html( $truth_line ); ?></p>
					<?php endforeach; ?>
					<p class="si-help si-help--hint si-truth__sign">Your sign-ups · We’ll email a code</p>
				<?php else : ?>
				<?php foreach ( isset( $s['what'] ) ? array_slice( (array) $s['what'], 0, 4 ) : array() as $what_line ) : ?>
					<p class="si-what"><?php echo esc_html( $what_line ); ?></p>
				<?php endforeach; ?>
				<p class="si-help si-help--hint"><?php echo esc_html( $hint_say ); ?></p>
				<p class="si-addr"><?php echo ogc_email_wbr( isset( $s['masked'] ) ? $s['masked'] : '' ); ?></p>
				<?php endif; ?>
				<form class="si-form" method="post" action="<?php echo esc_url( $self ); ?>">
					<input type="hidden" name="k" value="<?php echo esc_attr( isset( $s['land'] ) ? $s['land'] : '' ); ?>">
					<?php if ( ! empty( $s['again'] ) ) : ?>
						<input type="hidden" name="ogc_do" value="again">
						<input type="hidden" name="t" value="<?php echo esc_attr( isset( $s['raw'] ) ? $s['raw'] : '' ); ?>">
					<?php else : ?>
						<input type="hidden" name="ogc_do" value="hint">
						<input type="hidden" name="h" value="<?php echo esc_attr( isset( $s['hint'] ) ? $s['hint'] : '' ); ?>">
					<?php endif; ?>
					<button type="submit" class="wk-btn si-go"><?php echo esc_html( 'Send code' ); ?></button>
				</form>
				<div class="si-links"><a class="si-quiet" href="<?php echo esc_url( $another ); ?>">Use another email</a></div>

			<?php elseif ( 'signedin' === $st ) : ?>
				<p class="si-addr"><?php echo ogc_email_wbr( $email ); ?></p>
				<p class="si-btns"><a class="wk-btn si-go" href="<?php echo esc_url( home_url( $ret ? $ret : ogc_landing_for( get_current_user_id() ) ) ); ?>">Continue</a></p>
				<div class="si-links"><a class="si-quiet" href="<?php echo esc_url( ogc_url( 'signin', array( 'signout' => 1, '_wpnonce' => wp_create_nonce( 'ogc_signout' ) ) ) ); ?>">Sign out</a></div>

			<?php elseif ( 'choose' === $st ) : ?>
				<?php
				// The sooner Conference first.
				$ys = ogc_member_years();
				sort( $ys );
				?>
				<ul class="si-years">
					<?php foreach ( $ys as $y ) : ?>
						<?php $m = function_exists( 'ogc_member_me' ) ? ogc_member_me( $y ) : null; ?>
						<li><a class="si-year" href="<?php echo esc_url( function_exists( 'ogc_member_landing' ) ? home_url( ogc_member_landing( $y, ogc_current_email() ) ) : ogc_url( 'year', array( 'year' => $y ) ) ); ?>"><b><?php echo esc_html( $y . ' Annual Conference' ); ?></b><small><?php echo esc_html( $m ? ( 'coa' === $m['role'] ? 'Committee of Arrangements' : 'Helper' ) . ( $m['helps'] ? ' · ' . $m['helps'] : '' ) : 'Webmaster' ); ?></small></a></li>
					<?php endforeach; ?>
				</ul>
				<div class="si-links"><a class="si-quiet" href="<?php echo esc_url( ogc_url( 'signin', array( 'signout' => 1, '_wpnonce' => wp_create_nonce( 'ogc_signout' ) ) ) ); ?>">Sign out</a></div>

			<?php elseif ( 'refused' === $st ) : ?>
				<?php $ry = (int) ( isset( $s['year'] ) ? $s['year'] : 0 ); ?>
				<?php // The way on: the latest started year this person is on (never a year not started yet, which opens to "Not started"). ?>
				<?php $mine_years = array_values( array_filter( array_diff( ogc_member_years(), array( $ry ) ), function ( $yy ) { return ! function_exists( 'ogc_year_started' ) || ogc_year_started( $yy ); } ) ); ?>
				<?php rsort( $mine_years ); ?>
				<?php $can_ask = $ry && ogc_valid_year( $ry ) && ! empty( $s['can_ask'] ); ?>
				<p class="si-addr"><?php echo ogc_email_wbr( $email ); ?></p>
				<?php // On a shared family laptop the usual reason is being signed in as the spouse. ?>
				<p class="si-notyou"><a class="si-quiet" href="<?php echo esc_url( ogc_url( 'signin', array( 'signout' => 1, '_wpnonce' => wp_create_nonce( 'ogc_signout' ), 'return' => rawurlencode( ogc_safe_return( isset( $_SERVER['REQUEST_URI'] ) ? esc_url_raw( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : '' ) ) ) ) ); ?>">Not you? Sign out</a></p>
				<?php if ( ! empty( $s['why'] ) ) : ?>
					<p class="si-help"><?php echo esc_html( $s['why'] ); ?></p>
				<?php endif; ?>
				<?php if ( $can_ask && ! empty( $s['asked'] ) ) : ?>
					<p class="si-status si-status--card" role="status"><?php echo esc_html( 'Asked · ' . ogc_member_date( gmdate( 'Y-m-d H:i:s', (int) $s['asked'] ) ) ); ?></p>
				<?php elseif ( $can_ask ) : ?>
					<form class="si-form" method="post" action="<?php echo esc_url( $self ); ?>">
						<input type="hidden" name="ogc_do" value="ask">
						<input type="hidden" name="year" value="<?php echo (int) $ry; ?>">
						<input type="hidden" name="return" value="<?php echo esc_attr( ogc_safe_return( isset( $_SERVER['REQUEST_URI'] ) ? esc_url_raw( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : '' ) ); ?>">
						<?php wp_nonce_field( 'ogc_ask_' . $ry ); ?>
						<button type="submit" class="wk-btn si-go" title="<?php echo esc_attr( 'Tells the ' . $ry . ' Committee of Arrangements who asked' ); ?>">Ask for access</button>
					</form>
				<?php endif; ?>
				<?php if ( ! $can_ask && ! $mine_years ) : ?>
					<?php // Most who land here followed a stray committee link: their own sign-ups are the way on. ?>
					<p class="si-btns"><a class="wk-btn si-go" href="<?php echo esc_url( home_url( ogc_mine_link( ogc_current_email() ) ) ); ?>">Your sign-ups</a></p>
				<?php else : ?>
					<?php // Open 2027 is filled when it's the only way on; straight into the app, no redirect. ?>
					<?php foreach ( array_slice( $mine_years, 0, 1 ) as $my ) : ?>
						<p class="si-btns"><a class="<?php echo esc_attr( $can_ask ? 'si-quiet' : 'wk-btn si-go' ); ?>" href="<?php echo esc_url( ogc_url( 'app', array( 'year' => $my ) ) ); ?>"><?php echo esc_html( 'Open ' . $my ); ?></a></p>
					<?php endforeach; ?>
					<div class="si-links">
						<a class="si-quiet" href="<?php echo esc_url( home_url( ogc_mine_link( ogc_current_email() ) ) ); ?>">Your sign-ups</a>
					</div>
				<?php endif; ?>

			<?php elseif ( 'reauth' === $st ) : ?>
				<p class="si-addr"><?php echo ogc_email_wbr( $email ); ?></p>
				<p class="si-help">Committee pages ask every 30 days</p>
				<form class="si-form" method="post" action="<?php echo esc_url( $self ); ?>">
					<input type="hidden" name="ogc_do" value="send">
					<input type="hidden" name="email" value="<?php echo esc_attr( $email ); ?>">
					<input type="hidden" name="return" value="<?php echo esc_attr( $ret ); ?>">
					<button type="submit" class="wk-btn si-go">Send code</button>
				</form>
				<div class="si-links"><a class="si-quiet" href="<?php echo esc_url( ogc_url( 'signin', array( 'signout' => 1, '_wpnonce' => wp_create_nonce( 'ogc_signout' ) ) ) ); ?>">Sign out</a></div>

			<?php else : ?>
				<?php $email_form( $email, $err, ! empty( $s['field'] ) || 'Enter an email' === $err ); ?>
			<?php endif; ?>
			</div>

			<?php if ( in_array( $st, array( 'form', 'invalid', 'signedin', 'refused' ), true ) && function_exists( 'ogc_dev_tools_on' ) && ogc_dev_tools_on() && ! ( defined( 'OGC_PROTOTYPE' ) && OGC_PROTOTYPE ) ) : ?>
				<?php
				$dev_ret = $ret ? $ret : wp_make_link_relative( ogc_url( 'signin', array( 'continue' => 1 ) ) );
				$dev     = function ( $email, $extra = '' ) use ( $dev_ret ) {
					return ogc_url( 'dev-signin' ) . '?email=' . rawurlencode( $email ) . $extra . '&return=' . rawurlencode( $dev_ret );
				};
				$people = array(
					array( 'COA chair', $dev( 'nathan.keller@example.com' ) ),
					array( 'Helper', $dev( 'joel.marsh@example.com' ) ),
					array( 'Webmaster', $dev( 'webmaster@example.com', '&webmaster=1&name=Webmaster' ) ),
					array( 'A household', $dev( 'naomi.adams@example.com' ) ),
					array( 'A volunteer', $dev( 'ruth.kinsey@example.com' ) ),
				);
				?>
				<div class="si-dev">
					<p class="si-dev__k">Dev · Sign in as</p>
					<p class="si-dev__pills">
						<?php foreach ( $people as $p ) : ?>
							<a class="ogc-mock" href="<?php echo esc_url( $p[1] ); ?>"><?php echo esc_html( $p[0] ); ?></a>
						<?php endforeach; ?>
						<a class="ogc-mock" href="<?php echo esc_url( ogc_url( 'mail' ) ); ?>">Mail log</a>
					</p>
				</div>
			<?php endif; ?>
		</div>
		<p class="ogc-sr" id="si-live" role="status" aria-live="polite"></p>
	</div>
</main>
