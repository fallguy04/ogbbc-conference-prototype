<?php
/**
 * The Mail log (signin area): every email the plugin would have sent, kept instead (local site only,
 * webmasters only; anyone else gets the site's 404). Newest first: when, to, subject, kind. Open one
 * to read it as the recipient would, at a phone's width or a laptop's, with its links working (a
 * sign-in link signs you in as that person, which is how a walk-through signs in), and its text.
 *
 * ?preview=all draws every kind in the set from made-up people (ogc_mail_samples), to review the set
 * in one place without walking every flow.
 */
defined( 'ABSPATH' ) || exit;

// phpcs:disable WordPress.Security.NonceVerification -- reading which row to show.
$ogc_preview = isset( $_GET['preview'] );
$ogc_to      = isset( $_GET['to'] ) ? sanitize_text_field( wp_unslash( $_GET['to'] ) ) : '';
$ogc_pick    = isset( $_GET['id'] ) ? (int) $_GET['id'] : 0;
$ogc_kind    = isset( $_GET['kind'] ) ? sanitize_key( wp_unslash( $_GET['kind'] ) ) : '';
// phpcs:enable
$ogc_from  = ogc_mail_from();
$ogc_kinds = ogc_mail_kinds();
$ogc_items = array();
if ( $ogc_preview ) {
	foreach ( ogc_mail_samples() as $k => $data ) {
		$data = array_merge( array( 'year' => 2027, 'to' => 'daniel.hoover@example.com' ), $data );
		$m    = ogc_mail_template( $k, $data );
		if ( $m ) {
			$ogc_items[] = array( 'id' => $k, 'at' => '', 'to' => $data['to'], 'kind' => $k, 'subject' => $m['subject'], 'status' => 'sample', 'html' => $m['html'], 'text' => $m['text'], 'meta' => array() );
		}
	}
	$ogc_sel = $ogc_kind ? $ogc_kind : ( $ogc_items ? $ogc_items[0]['id'] : '' );
} else {
	foreach ( ogc_mail_rows( $ogc_to ) as $r ) {
		$ogc_items[] = array( 'id' => (int) $r['id'], 'at' => $r['at'], 'to' => $r['to_email'], 'kind' => $r['kind'], 'subject' => $r['subject'], 'status' => $r['status'], 'html' => (string) $r['html'], 'text' => (string) $r['text'], 'meta' => (array) ogc_unjson( $r['meta'], array() ), 'send_after' => $r['send_after'] );
	}
	$ogc_sel = $ogc_pick ? $ogc_pick : ( $ogc_items ? $ogc_items[0]['id'] : 0 );
}
// One email was asked for (a row tapped): a phone shows it alone; with none asked, a phone shows the list.
// A laptop shows the first one beside the list either way.
$ogc_asked = $ogc_preview ? '' !== $ogc_kind : $ogc_pick > 0;
$ogc_cur = null;
foreach ( $ogc_items as $it ) {
	if ( (string) $it['id'] === (string) $ogc_sel ) {
		$ogc_cur = $it;
	}
}
$ogc_queued = 0;
foreach ( $ogc_items as $it ) {
	$ogc_queued += 'queued' === $it['status'] ? 1 : 0;
}
$ogc_pill = function ( $kind ) {
	$k = array( 'signin' => 'Sign-in', 'no_signups' => 'Sign-in', 'signin_wplogin' => 'Sign-in', 'codes_off' => 'Sign-in', 'confirm_email' => 'Sign-in', 'access_asked' => 'Invite', 'invite' => 'Invite', 'webmaster' => 'Invite', 'access_ending' => 'Invite', 'rooms_posted' => 'Rooms', 'rooms_changed' => 'Rooms', 'wp_mail' => 'Plain', 'app_message' => 'Message', 'app_weekly' => 'Weekly' );
	if ( isset( $k[ $kind ] ) ) {
		return $k[ $kind ];
	}
	if ( preg_match( '/^(registration|registered|parent|payment|credit|email_changed)/', $kind ) ) {
		return 'Registration';
	}
	if ( preg_match( '/^(signed_up|reminder|shift|you_left|volunteer|spot|weekly|message|vol)/', $kind ) ) {
		return 'Volunteer';
	}
	if ( 'team_signed_up' === $kind ) {
		return 'Tournaments';
	}
	return 'Other';
};
$ogc_when = function ( $at ) {
	$t = strtotime( (string) $at . ' UTC' );
	return $t ? wp_date( 'M j · g:i A', $t ) : '';
};
$ogc_status = array( 'captured' => 'Kept', 'queued' => 'Queued', 'refused' => 'Refused · limit', 'sent' => 'Sent', 'failed' => 'Failed', 'sample' => 'Sample' );
// A tester's address on a staging copy (OGC_MAIL_ALLOW): really sent.
$ogc_state  = function ( $it ) use ( $ogc_status ) {
	if ( 'sent' === $it['status'] && ! empty( $it['meta']['allowed'] ) ) {
		return 'Sent (allowed)';
	}
	return isset( $ogc_status[ $it['status'] ] ) ? $ogc_status[ $it['status'] ] : $it['status'];
};
$ogc_local  = function_exists( 'ogc_is_local_host' ) && ogc_is_local_host();
$ogc_link   = function ( $args ) use ( $ogc_preview, $ogc_to ) {
	return ogc_url( 'mail', array_filter( array_merge( array( 'preview' => $ogc_preview ? 'all' : null, 'to' => $ogc_to ? $ogc_to : null ), $args ) ) );
};
?>
<main id="main" tabindex="-1">
	<div class="ogc wk ws ml<?php echo $ogc_cur && $ogc_asked ? ' is-reading' : ''; ?>">
		<p class="ml-dev"><?php echo esc_html( $ogc_local ? 'Dev · Nothing is sent' : 'Staging · Kept, not sent · Links and codes removed' ); ?></p>
		<header class="ws-bar ws-bar--page"><div class="ws-bar__in">
			<?php // Reached from the app's Email screen (Open Mail log), so Back goes there. ?>
			<a class="ws-back" href="<?php echo esc_url( ogc_url( 'app', array( 's' => 'email' ) ) ); ?>"><svg class="wk-i" viewBox="0 0 24 24" aria-hidden="true"><path d="M14.5 5.5 8 12l6.5 6.5" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg><span>Email</span></a>
			<div class="ws-title"><h1><?php echo esc_html( $ogc_preview ? 'Samples' : 'Mail log' ); ?></h1></div>
			<p class="ws-tools">
				<?php if ( $ogc_preview ) : ?>
					<a href="<?php echo esc_url( ogc_url( 'mail' ) ); ?>">Mail log</a>
				<?php else : ?>
					<a href="<?php echo esc_url( ogc_url( 'mail', array( 'preview' => 'all' ) ) ); ?>" title="Every kind of email, from made-up people">Samples</a>
				<?php endif; ?>
			</p>
		</div></header>
		<div class="ml-body<?php echo $ogc_cur && $ogc_asked ? ' has-pick' : ''; ?>">
			<section class="ml-list" aria-label="Emails">
				<?php if ( ! $ogc_preview ) : ?>
					<form class="ml-filter" method="get" action="<?php echo esc_url( ogc_url( 'mail' ) ); ?>">
						<label class="ogc-sr" for="ml-to">To</label>
						<input id="ml-to" name="to" type="search" value="<?php echo esc_attr( $ogc_to ); ?>" placeholder="Filter by To" autocomplete="off" autocapitalize="none" spellcheck="false">
						<button type="submit" class="wk-btn wk-btn--line wk-btn--small">Filter</button>
					</form>
					<div class="ml-acts">
						<?php // The log reads at most 200 (ogc_mail_rows), so 200 means "the latest 200", not "all". ?>
						<span><?php echo esc_html( count( $ogc_items ) >= 200 ? 'Latest 200' : count( $ogc_items ) . ( 1 === count( $ogc_items ) ? ' email' : ' emails' ) ); ?></span>
						<?php if ( $ogc_queued ) : ?>
							<form method="post"><?php wp_nonce_field( 'ogc_mail_log' ); ?><input type="hidden" name="ogc_mail_do" value="queue"><button type="submit" class="ml-quiet"><?php echo esc_html( 'Send ' . $ogc_queued . ' queued' ); ?></button></form>
						<?php endif; ?>
						<?php if ( $ogc_items ) : ?>
							<form method="post" data-ml-clear><?php wp_nonce_field( 'ogc_mail_log' ); ?><input type="hidden" name="ogc_mail_do" value="clear"><button type="submit" class="ml-quiet ml-quiet--del">Clear</button></form>
						<?php endif; ?>
					</div>
				<?php endif; ?>
				<?php if ( ! $ogc_items ) : ?>
					<p class="ml-blank"><?php echo esc_html( $ogc_to ? 'No emails to ' . $ogc_to : 'No emails yet' ); ?></p>
				<?php else : ?>
					<ol class="ml-rows">
						<?php foreach ( $ogc_items as $it ) : ?>
							<li><a class="ml-row<?php echo (string) $it['id'] === (string) $ogc_sel ? ' is-on' : ''; ?>" href="<?php echo esc_url( $ogc_link( $ogc_preview ? array( 'kind' => $it['id'] ) : array( 'id' => $it['id'] ) ) ); ?>"<?php echo (string) $it['id'] === (string) $ogc_sel ? ' aria-current="true"' : ''; ?>>
								<span class="ml-row__top"><span class="ml-pill ml-pill--<?php echo esc_attr( strtolower( $ogc_pill( $it['kind'] ) ) ); ?>"><?php echo esc_html( $ogc_pill( $it['kind'] ) ); ?></span><small><?php echo esc_html( $ogc_preview ? $ogc_kinds[ $it['kind'] ] : $ogc_when( $it['at'] ) . ( 'captured' !== $it['status'] ? ' · ' . $ogc_state( $it ) : '' ) ); ?></small></span>
								<b><?php echo esc_html( $it['subject'] ); ?></b>
								<span class="ml-row__to"><?php echo esc_html( $it['to'] ); ?></span>
							</a></li>
						<?php endforeach; ?>
					</ol>
				<?php endif; ?>
			</section>
			<?php if ( $ogc_cur ) : ?>
				<section class="ml-read" aria-label="The email">
					<p class="ml-back"><a href="<?php echo esc_url( $ogc_link( array() ) ); ?>"><svg class="wk-i" viewBox="0 0 24 24" aria-hidden="true"><path d="M14.5 5.5 8 12l6.5 6.5" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg><span>All emails</span></a></p>
					<dl class="ml-meta">
						<dt>From</dt><dd><?php echo esc_html( $ogc_from['name'] . ' <' . $ogc_from['email'] . '>' ); ?></dd>
						<?php // To, Subject and Kind repeat the chosen row beside it on a laptop (shown on a phone, where the list is hidden). ?>
						<dt class="ml-meta__dup">To</dt><dd class="ml-meta__dup"><?php echo esc_html( $ogc_cur['to'] ); ?></dd>
						<?php if ( ! empty( $ogc_cur['meta']['reply_to'] ) ) : ?><dt>Reply-To</dt><dd><?php echo esc_html( $ogc_cur['meta']['reply_to'] ); ?></dd><?php endif; ?>
						<dt class="ml-meta__dup">Subject</dt><dd class="ml-meta__dup"><?php echo esc_html( $ogc_cur['subject'] ); ?></dd>
						<dt class="ml-meta__dup">Kind</dt><dd class="ml-meta__dup"><?php echo esc_html( isset( $ogc_kinds[ $ogc_cur['kind'] ] ) ? $ogc_kinds[ $ogc_cur['kind'] ] : $ogc_cur['kind'] ); ?><?php echo $ogc_cur['at'] ? ' · ' . esc_html( $ogc_when( $ogc_cur['at'] ) ) : ''; ?></dd>
						<?php if ( 'queued' === $ogc_cur['status'] && ! empty( $ogc_cur['send_after'] ) ) : ?><dt>Status</dt><dd><?php echo esc_html( 'Queued · ' . $ogc_when( $ogc_cur['send_after'] ) ); ?></dd><?php endif; ?>
					</dl>
					<div class="ml-bar">
						<div class="ml-tabs" role="tablist" aria-label="View">
							<button type="button" role="tab" aria-selected="true" data-ml-tab="html">HTML</button>
							<button type="button" role="tab" aria-selected="false" data-ml-tab="text">Text</button>
						</div>
						<div class="ml-tabs" role="group" aria-label="Width">
							<button type="button" aria-pressed="false" data-ml-w="390">390</button>
							<button type="button" aria-pressed="true" data-ml-w="600">600</button>
						</div>
					</div>
					<?php if ( '' !== $ogc_cur['html'] ) : ?>
						<div class="ml-frame" data-ml-pane="html"><iframe title="<?php echo esc_attr( $ogc_cur['subject'] ); ?>" sandbox="allow-popups allow-popups-to-escape-sandbox allow-top-navigation-by-user-activation" srcdoc="<?php echo esc_attr( str_replace( '<head>', '<head><base target="_top">', $ogc_cur['html'] ) ); ?>"></iframe></div>
					<?php else : ?>
						<p class="ml-blank" data-ml-pane="html"><?php echo esc_html( 'captured' === $ogc_cur['status'] && ! $ogc_local ? 'Not kept · A sign-in code' : 'Not kept' ); ?></p>
					<?php endif; ?>
					<pre class="ml-text" data-ml-pane="text" hidden><?php echo esc_html( $ogc_cur['text'] ); ?></pre>
					<?php if ( ! empty( $ogc_cur['meta']['ics'] ) ) : ?>
						<p class="ml-att"><a download="<?php echo esc_attr( ! empty( $ogc_cur['meta']['ics_name'] ) ? $ogc_cur['meta']['ics_name'] : 'event.ics' ); ?>" href="<?php echo esc_attr( 'data:text/calendar;charset=utf-8,' . rawurlencode( $ogc_cur['meta']['ics'] ) ); ?>">Calendar file · <?php echo esc_html( ! empty( $ogc_cur['meta']['ics_name'] ) ? $ogc_cur['meta']['ics_name'] : 'event.ics' ); ?></a></p>
					<?php endif; ?>
				</section>
			<?php endif; ?>
		</div>
	</div>
</main>
