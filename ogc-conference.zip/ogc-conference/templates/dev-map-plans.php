<?php
/**
 * The map area's floor-plan fixture (module-map-dev.php): local development only.
 */
defined( 'ABSPATH' ) || exit;
// phpcs:ignore WordPress.Security.NonceVerification -- which year to draw.
$ogc_y = isset( $_GET['year'] ) ? (int) $_GET['year'] : 2026;
?>
<main id="main" class="ogc" style="padding:16px">
	<h1 style="font:700 22px/1.2 var(--wk-serif, Georgia, serif);margin:0 0 12px">Floor plans · <?php echo esc_html( (string) $ogc_y ); ?></h1>
	<div id="ogc-plans-fixture"></div>
	<script type="application/json" id="ogc-plans-data"><?php echo wp_json_encode( ogc_map_dev_plans( $ogc_y ), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT ); ?></script>
</main>
