<?php
/**
 * The registration form, Your sign-ups (?view=mine), a parent's approval (?approve=) and, locally, the
 * test checkout (?checkout=) (register area). register.js draws them all; while it loads, the page
 * shows the shape of what's coming (a cream header and the form's section rows), not a bare "Loading".
 */
defined( 'ABSPATH' ) || exit;
?>
<main id="main" tabindex="-1">
	<div id="ogc-reg" class="ogc" data-base="<?php echo esc_attr( trailingslashit( ogc_data_base() ) ); ?>" aria-busy="true">
		<div class="wk reg reg-skel" aria-hidden="true">
			<header class="wk-hero"><div class="wk-wrap vol-hero"><span class="reg-skel__k"></span><span class="reg-skel__h"></span><span class="reg-skel__l"></span><span class="reg-skel__l reg-skel__l--short"></span></div></header>
			<section class="wk-main"><div class="wk-wrap"><div class="reg-wrap">
				<span class="reg-skel__row"></span><span class="reg-skel__row"></span><span class="reg-skel__row"></span><span class="reg-skel__row"></span>
			</div></div></section>
		</div>
		<p class="ogc-sr reg-loading">Loading</p>
	</div>
</main>
