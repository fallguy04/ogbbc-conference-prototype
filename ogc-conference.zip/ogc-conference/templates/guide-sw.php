<?php
/**
 * The guide's service worker, served from the guide's own address so its scope is the guide
 * (/annual-conference/guide/). The script is assets/guide/sw.js.
 */
defined( 'ABSPATH' ) || exit;
status_header( 200 );
header( 'Content-Type: application/javascript; charset=utf-8' );
header( 'Cache-Control: no-cache' );
header( 'X-Content-Type-Options: nosniff' );
readfile( OGC_DIR . 'assets/guide/sw.js' ); // phpcs:ignore -- a fixed file in the plugin.
