<?php
/**
 * Members (signin area): one year's members on a page of their own, /annual-conference/members/?year=.
 * The editors' frame (a cream bar, back to the year); assets/signin/ogc-members.js fills the card.
 */
defined( 'ABSPATH' ) || exit;

// phpcs:ignore WordPress.Security.NonceVerification -- which year is shown; the page's rule checked it.
$y    = isset( $_GET['year'] ) ? (int) $_GET['year'] : 0;
$y    = ogc_valid_year( $y ) ? $y : ogc_auth_year();
$back = '<svg class="wk-i" viewBox="0 0 24 24" aria-hidden="true"><path d="M14.5 5.5 8 12l6.5 6.5" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>';
?>
<main id="main" tabindex="-1">
	<div class="ogc ws om-page">
		<header class="ws-bar ws-bar--page">
			<div class="ws-bar__in">
				<a class="ws-back" href="<?php echo esc_url( ogc_url( 'year', array( 'year' => $y ) ) ); ?>"><?php echo $back; // phpcs:ignore -- fixed markup. ?><span><?php echo esc_html( $y . ' Annual Conference' ); ?></span></a>
				<?php // The back link already names the year; no kicker repeating it. ?>
				<div class="ws-title"><h1 tabindex="-1">Members</h1></div>
			</div>
		</header>
		<div class="ws-body">
			<section class="om-card" data-ogc-members="<?php echo (int) $y; ?>" data-om-full aria-label="Members"></section>
		</div>
	</div>
</main>
