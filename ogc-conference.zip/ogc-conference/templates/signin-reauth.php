<?php
/**
 * Confirm it's you (signin area), opening a members' page after 30 days: the page's own frame, empty,
 * with the same dialog as over an open page (assets/signin/ogc-account.js opens it on
 * [data-ogc-reauth] and reloads the page once the code is confirmed). Without scripts, a Send code
 * button posts to the sign-in page.
 */
defined( 'ABSPATH' ) || exit;

$from = isset( $GLOBALS['ogc_reauth_from'] ) ? (array) $GLOBALS['ogc_reauth_from'] : array( 'title' => '' );
// phpcs:ignore WordPress.Security.NonceVerification -- which year the page was for.
$y    = isset( $_GET['year'] ) && ogc_valid_year( (int) $_GET['year'] ) ? (int) $_GET['year'] : 0;
$here = ogc_safe_return( isset( $_SERVER['REQUEST_URI'] ) ? esc_url_raw( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : '' );
?>
<main id="main" tabindex="-1">
	<div class="ogc ws om-page" data-ogc-reauth>
		<header class="ws-bar ws-bar--page">
			<div class="ws-bar__in">
				<div class="ws-title">
					<?php if ( $y ) : ?><p class="wk-kicker"><?php echo esc_html( $y . ' Annual Conference' ); ?></p><?php endif; ?>
					<h1 tabindex="-1"><?php echo esc_html( $from['title'] ? $from['title'] : 'Confirm it’s you' ); ?></h1>
				</div>
			</div>
		</header>
		<div class="ws-body">
			<noscript>
				<section class="om-card">
					<h2 class="om-h">Confirm it’s you</h2>
					<p class="om-help">Committee pages ask every 30 days</p>
					<form method="post" action="<?php echo esc_url( ogc_url( 'signin' ) ); ?>">
						<input type="hidden" name="ogc_do" value="send">
						<input type="hidden" name="email" value="<?php echo esc_attr( ogc_current_email() ); ?>">
						<input type="hidden" name="return" value="<?php echo esc_attr( $here ); ?>">
						<button type="submit" class="wk-btn">Send code</button>
					</form>
				</section>
			</noscript>
		</div>
	</div>
</main>
