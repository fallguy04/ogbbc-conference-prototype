<?php
/**
 * The printable schedule (/schedule/): the paper itself, on screen as it will print, with one Print
 * button (on a phone, Print first and the two pages as thumbnails side by side). Reading the schedule
 * on screen is the Conference page's and the guide's.
 * What this person may see is decided before this is drawn (module-print.php): a year not posted
 * is "Not posted yet" for the public, with no rows in the page; a year that doesn't exist is a 404.
 */
defined( 'ABSPATH' ) || exit;

$c    = ogc_print_ctx( 'schedule' );
$s    = $c['settings'];
$r    = (array) $c['row'];
$y    = $c['year'];
$span = ogc_print_span( isset( $r['start'] ) ? $r['start'] : '', isset( $r['end'] ) ? $r['end'] : '' );
$fact = implode( ' · ', array_filter( array( $span, isset( $r['venue'] ) ? $r['venue'] : '' ) ) );
// A Conference with no dates yet (2028 before its COA posts them) says whose it is.
if ( ! $fact && ! empty( $r['hosts'] ) ) {
	$fact = 'Hosted by the ' . $r['hosts'];
}
?>
<main id="main" class="ogc" tabindex="-1">
	<div id="ogc-print" class="wk ogc-pp pp--schedule">
		<header class="wk-hero pp-hero">
			<div class="wk-wrap">
				<?php if ( 'missing' === $c['state'] ) : ?>
					<h1 class="pp-title"><?php echo esc_html( $y ? 'No schedule for ' . $y : 'No such schedule' ); ?></h1>
					<p class="pp-links"><a href="<?php echo esc_url( ogc_url() ); ?>">Conference page</a></p>
				<?php else : ?>
					<p class="wk-kicker"><?php echo esc_html( $y . ' Annual Conference' ); ?></p>
					<h1 class="pp-title">Printable schedule</h1>
					<?php if ( $fact ) : ?>
						<p class="pp-fact"><?php echo esc_html( $fact ); ?></p>
					<?php endif; ?>
					<?php if ( $c['draft'] ) : ?>
						<p class="pp-draft" title="Only the year’s committee sees this until the schedule is published">Draft · Not posted</p>
					<?php endif; ?>
					<?php if ( 'ok' === $c['state'] ) : ?>
						<div class="pp-tools" id="pp-tools"></div>
					<?php else : ?>
						<p class="pp-links"><a href="<?php echo esc_url( ogc_url( '', array( 'year' => $y ) ) ); ?>">Conference page</a></p>
					<?php endif; ?>
				<?php endif; ?>
			</div>
		</header>
		<?php if ( 'wait' === $c['state'] ) : ?>
			<?php if ( $c['empty'] ) : ?>
				<?php // A member of the year: the way to make it (its part on the year page). ?>
				<section class="pp-wait"><div class="wk-wrap"><div class="pp-wait__h pp-wait__h--act"><p>No schedule yet</p><a class="wk-btn" href="<?php echo esc_url( ogc_url( 'year', array( 'year' => $y, 'part' => 'schedule' ) ) ); ?>">Edit schedule</a></div></div></section>
			<?php else : ?>
				<section class="pp-wait"><div class="wk-wrap"><p class="pp-wait__h">Not posted yet</p></div></section>
			<?php endif; ?>
		<?php elseif ( 'ok' === $c['state'] ) : ?>
			<section class="pp-paper" aria-label="The printout">
				<div class="pp-checks" id="pp-checks" hidden></div>
				<div class="pp-sheets" id="pp-sheets" aria-busy="true"></div>
				<noscript><p class="pp-wait__h">Printing needs JavaScript</p></noscript>
			</section>
		<?php endif; ?>
	</div>
</main>
