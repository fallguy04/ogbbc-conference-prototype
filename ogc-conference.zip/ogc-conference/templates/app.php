<?php
/**
 * The committees' app (module-app.php): one root that assets/app/app.js draws into, the sidebar and the
 * card. Signed out or off the year never reaches here (a members' page: sign-in, or No access).
 */
defined( 'ABSPATH' ) || exit;
?>
<div id="ogc-app" class="ap" data-state="loading">
	<aside class="ap-side" aria-label="Sections"></aside>
	<main class="ap-card" id="ap-main" tabindex="-1">
		<div class="ap-loading" role="status">Loading</div>
	</main>
</div>
<noscript><p class="ap-noscript">This page needs JavaScript.</p></noscript>
