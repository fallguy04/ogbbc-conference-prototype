<?php
/**
 * The information packet (/packet/), made from the year's own data: the paper itself, page by page,
 * with the one-sheet schedule after its cover (reading it on screen is the Conference page's). What this person may see is decided before this is
 * drawn (module-print.php).
 */
defined( 'ABSPATH' ) || exit;

$c    = ogc_print_ctx( 'packet' );
$y    = $c['year'];
$r    = (array) $c['row'];
$span = ogc_print_span( isset( $r['start'] ) ? $r['start'] : '', isset( $r['end'] ) ? $r['end'] : '' );
// The same fact line as the schedule's wait page: the dates and the place, or whose it is.
$fact = implode( ' · ', array_filter( array( $span, isset( $r['venue'] ) ? $r['venue'] : '' ) ) );
if ( ! $fact && ! empty( $r['hosts'] ) ) {
	$fact = 'Hosted by the ' . $r['hosts'];
}
?>
<main id="main" class="ogc" tabindex="-1">
	<div id="ogc-packet" class="wk ogc-pp pk">
		<?php if ( 'ok' === $c['state'] ) : ?>
			<div id="pk-root" aria-busy="true"></div>
			<noscript><div class="wk-wrap"><p class="pp-wait__h">The packet needs JavaScript</p></div></noscript>
		<?php else : ?>
			<header class="wk-hero pp-hero">
				<div class="wk-wrap">
					<?php if ( 'missing' === $c['state'] ) : ?>
						<h1 class="pp-title"><?php echo esc_html( $y ? 'No packet for ' . $y : 'No such packet' ); ?></h1>
						<p class="pp-links"><a href="<?php echo esc_url( ogc_url() ); ?>">Conference page</a></p>
					<?php else : ?>
						<p class="wk-kicker"><?php echo esc_html( $y . ' Annual Conference' ); ?></p>
						<h1 class="pp-title">Information packet</h1>
						<?php if ( $fact ) : ?>
							<p class="pp-fact"><?php echo esc_html( $fact ); ?></p>
						<?php endif; ?>
						<p class="pp-links"><a href="<?php echo esc_url( ogc_url( '', array( 'year' => $y ) ) ); ?>">Conference page</a></p>
					<?php endif; ?>
				</div>
			</header>
			<?php if ( 'wait' === $c['state'] ) : ?>
				<?php if ( $c['empty'] ) : ?>
					<?php // A member of the year: the way to make it (its part on the year page). ?>
					<section class="pp-wait"><div class="wk-wrap"><div class="pp-wait__h pp-wait__h--act"><p>No packet yet</p><a class="wk-btn" href="<?php echo esc_url( ogc_url( 'year', array( 'year' => $y, 'part' => 'packet' ) ) ); ?>">Edit packet</a></div></div></section>
				<?php else : ?>
					<section class="pp-wait"><div class="wk-wrap"><p class="pp-wait__h">Not posted yet</p></div></section>
				<?php endif; ?>
			<?php endif; ?>
		<?php endif; ?>
	</div>
</main>
