<?php
/**
 * Volunteer shifts (assets/volunteer/volunteer.js draws the rest). The header is drawn here, so the
 * page opens on its year with no "Loading…": the year, its dates and its place (the same for everyone).
 */
defined( 'ABSPATH' ) || exit;
// phpcs:ignore WordPress.Security.NonceVerification -- which year to show.
$ogc_y   = isset( $_GET['year'] ) && ogc_valid_year( wp_unslash( $_GET['year'] ) ) ? (int) $_GET['year'] : ogc_vol_default_year();
$ogc_row = ogc_year_get( $ogc_y );
$ogc_fmt = function ( $d ) {
	return $d ? wp_date( 'F j', strtotime( $d . ' 12:00 UTC' ), new DateTimeZone( 'UTC' ) ) : '';
};
$ogc_when = '';
if ( $ogc_row && ! empty( $ogc_row['start'] ) ) {
	$ogc_when = $ogc_fmt( $ogc_row['start'] ) . ( ! empty( $ogc_row['end'] ) ? ' – ' . $ogc_fmt( $ogc_row['end'] ) : '' ) . ', ' . substr( $ogc_row['start'], 0, 4 );
}
?>
<main id="main" tabindex="-1">
	<div id="ogc-vol" class="ogc" data-base="<?php echo esc_attr( trailingslashit( ogc_data_base() ) ); ?>" data-year="<?php echo esc_attr( $ogc_y ); ?>" aria-busy="true">
		<div class="wk vol">
			<header class="wk-hero vol-hero-band"><div class="wk-wrap wk-hero__in"><div class="wk-hero__text vol-hero">
				<p class="wk-kicker"><?php echo esc_html( $ogc_y . ' Annual Conference' ); ?></p>
				<h1 class="vol-title">Volunteer</h1>
				<?php if ( $ogc_when ) : ?>
					<p class="vol-when"><?php echo esc_html( $ogc_when ); ?><?php echo $ogc_row && ! empty( $ogc_row['city'] ) ? ' · ' . esc_html( $ogc_row['city'] ) : ''; ?></p>
				<?php elseif ( $ogc_row && ! empty( $ogc_row['hosts'] ) ) : ?>
					<p class="vol-when"><?php echo esc_html( $ogc_row['hosts'] ); ?></p>
				<?php endif; ?>
			</div></div></header>
			<section class="wk-main"><div class="wk-wrap"><div class="vol-skel" aria-hidden="true"><span></span><span></span><span></span></div></div></section>
		</div>
	</div>
</main>
