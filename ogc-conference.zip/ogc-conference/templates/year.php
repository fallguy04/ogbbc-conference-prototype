<?php
/**
 * The COA's year (v3 year/): the year's page (?year=) and each part's (?part=). A back-end page.
 * v3's markup, minus the mockup's scripts (ogc_pages() in includes/core-pages.php loads the page's).
 */
defined( 'ABSPATH' ) || exit;
?>
<main id="main" tabindex="-1">
	<div id="ogc-year" class="ogc" data-base="<?php echo esc_attr( trailingslashit( ogc_data_base() ) ); ?>">
		<div class="shell-container" style="padding:48px 16px"><p>Loading…</p></div>
	</div>
</main>
