<?php
/**
 * The Conference page (conference area). The block week.js draws, with the year's facts and buttons
 * already in it from the server, in the same places week.js puts them: someone without JavaScript, a
 * search engine or a link preview still reads when, where and who hosts, and the header doesn't jump
 * when week.js takes over.
 */
defined( 'ABSPATH' ) || exit;
$ogc_y = ogc_pub_page_year();
$ogc_b = $ogc_y ? ogc_pub_first_buttons( $ogc_y ) : array( 'btns' => '', 'sub' => '' );
$ogc_n = $ogc_y ? ogc_pub_next_after( $ogc_y ) : null;
?>
<main id="main" tabindex="-1">
	<div id="ogc-week" class="ogc" data-base="<?php echo esc_attr( trailingslashit( ogc_data_base() ) ); ?>">
		<?php if ( $ogc_y ) : ?>
		<div class="wk"><header class="wk-hero"><div class="wk-wrap wk-hero__in"><div class="wk-hero__text">
			<div class="wk-yr">
				<div class="wk-yr__top"><p class="wk-kicker">Annual Conference<?php echo $ogc_y['status'] ? '<span class="wk-status' . ( in_array( $ogc_y['status'], array( 'Postponed', 'Cancelled' ), true ) ? ' is-held' : '' ) . '"> · ' . esc_html( $ogc_y['status'] ) . '</span>' : ''; ?></p></div>
				<div class="wk-yrline"><h1 class="wk-title"><span class="ogc-sr">Annual Conference </span><span class="wk-year"><?php echo esc_html( $ogc_y['year'] ); ?></span></h1></div>
			</div>
			<ul class="wk-facts">
				<?php if ( $ogc_y['when'] ) : ?><li><span></span><span><?php echo esc_html( $ogc_y['when'] ); ?></span></li><?php endif; ?>
				<?php if ( $ogc_y['venue'] && $ogc_y['when'] ) : ?><li><span></span><span><?php echo esc_html( $ogc_y['venue'] ); ?><?php echo $ogc_y['city'] ? '<small>' . esc_html( $ogc_y['city'] ) . '</small>' : ''; ?></span></li><?php endif; ?>
				<?php if ( $ogc_y['hosts'] ) : ?><li><span></span><span>Hosted by the <?php echo esc_html( $ogc_y['hosts'] ); ?></span></li><?php endif; ?>
			</ul>
			<?php if ( $ogc_b['btns'] || $ogc_b['sub'] ) : ?>
			<div class="wk-action<?php echo $ogc_b['btns'] ? '' : ' wk-action--quiet'; ?>"><?php echo $ogc_b['btns'] ? '<p class="wk-btns">' . $ogc_b['btns'] . '</p>' : ''; ?><?php echo $ogc_b['sub']; // phpcs:ignore -- built from escaped parts in ogc_pub_first_buttons(). ?></div>
			<?php endif; ?>
			<?php if ( $ogc_n ) : ?>
			<p class="wk-sub wk-sub--next"><a class="wk-linklike" href="<?php echo esc_url( ogc_url( '', array( 'year' => $ogc_n['year'] ) ) ); ?>"><?php echo esc_html( $ogc_n['text'] ); ?> ›</a></p>
			<?php endif; ?>
		</div><?php if ( $ogc_y['photo'] ) : ?><div class="wk-hero__side"><figure class="wk-photo"><img src="<?php echo esc_url( $ogc_y['photo'] ); ?>" alt="" fetchpriority="high" decoding="async"></figure></div><?php endif; ?></div></header></div>
		<?php else : ?>
		<div class="shell-container" style="padding:48px 16px"><p>Annual Conference</p></div>
		<?php endif; ?>
	</div>
</main>
<div id="ogc-player" class="ogc wk-player" role="region" aria-label="Sermon player" hidden></div>
