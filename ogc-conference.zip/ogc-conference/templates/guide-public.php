<?php
/**
 * The on-site guide (conference area): a page of its own, apart from the Conference page. The same
 * block as the Conference page, marked data-guide, so week.js draws it as an app (Today · Schedule ·
 * Places · Help at the bottom). Until it runs, the year and its dates.
 */
defined( 'ABSPATH' ) || exit;
$ogc_y = ogc_pub_page_year();
?>
<main id="main" tabindex="-1">
	<div id="ogc-week" class="ogc" data-base="<?php echo esc_attr( trailingslashit( ogc_data_base() ) ); ?>" data-guide>
		<div class="wk wk-app"><header class="wk-apphead"><div class="wk-wrap">
			<div class="wk-appbar"><p class="wk-kicker"><?php echo $ogc_y ? esc_html( $ogc_y['year'] ) . ' ' : ''; ?>Conference</p></div>
			<h1 class="wk-apph">Conference app</h1>
			<?php if ( $ogc_y && $ogc_y['when'] ) : ?><p class="wk-here"><?php echo esc_html( preg_replace( '/^Lord willing, /', '', $ogc_y['when'] ) ); ?></p><?php endif; ?>
		</div></header></div>
	</div>
</main>
<div id="ogc-player" class="ogc wk-player" role="region" aria-label="Sermon player" hidden></div>
