<?php
/**
 * The guide's head: added to a phone's home screen, it opens full screen.
 */
defined( 'ABSPATH' ) || exit;
$ogc_g = trailingslashit( ogc_url( 'guide' ) );
?>
<meta name="theme-color" content="#f3f2eb">
<link rel="manifest" href="<?php echo esc_url( $ogc_g . 'manifest.webmanifest' ); ?>">
<link rel="apple-touch-icon" href="<?php echo esc_url( $ogc_g . 'app/apple-touch-icon.png' ); ?>">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-title" content="Conference">
