<?php
/**
 * The guide's web app manifest, served at /annual-conference/guide/manifest.webmanifest.
 */
defined( 'ABSPATH' ) || exit;
status_header( 200 );
header( 'Content-Type: application/manifest+json; charset=utf-8' );
header( 'Cache-Control: no-cache' );
echo wp_json_encode( array(
	'name'             => 'Annual Conference guide',
	'short_name'       => 'Conference',
	'description'      => 'The Annual Conference guide: today, the schedule, places and help. Works without signal once opened.',
	'start_url'        => './',
	'scope'            => './',
	'display'          => 'standalone',
	'background_color' => '#f3f2eb',
	'theme_color'      => '#f3f2eb',
	'icons'            => array(
		// A tan calendar on a deeper cream (the Conference's days, not a maps pin). The maskable one keeps
		// the mark inside the safe circle; "any" and "maskable" are separate files, as the spec advises.
		array( 'src' => 'app/icon-192.png', 'sizes' => '192x192', 'type' => 'image/png', 'purpose' => 'any' ),
		array( 'src' => 'app/icon-512.png', 'sizes' => '512x512', 'type' => 'image/png', 'purpose' => 'any' ),
		array( 'src' => 'app/icon-maskable-512.png', 'sizes' => '512x512', 'type' => 'image/png', 'purpose' => 'maskable' ),
	),
), JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT );
