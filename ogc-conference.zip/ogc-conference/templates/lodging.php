<?php
/**
 * The lodging committee's page (v3 lodging/). A back-end page: no site header or footer.
 * v3's markup, minus the mockup's scripts (ogc_pages() in includes/core-pages.php loads the page's).
 */
defined( 'ABSPATH' ) || exit;
?>
<main id="main" tabindex="-1">
	<div id="ogc-lodging" class="ogc" data-base="<?php echo esc_attr( trailingslashit( ogc_data_base() ) ); ?>">
		<div class="shell-container" style="padding:48px 16px"><p>Loading…</p></div>
	</div>
</main>
