# ogc-conference: working on the plugin

The Annual Conference plugin for ogbbc.org: v3's pages (`v3/`), served by WordPress from the plugin's own tables. The plan and its decisions are in `docs/21-build-plan.md`; what the Advisors asked is in `docs/20-advisors-oct9.md`. CLAUDE.md's design, wording and privacy rules bind everything here.

The foundation (Oct 10) is the skeleton, plus v3's front end copied as it was. The areas below rework each part.

## Run it

Nothing gets installed on the Mac. WordPress Playground runs WordPress 7.1.3 and PHP 8.5 (the CLI's default) inside Node, on SQLite, through `npx -y @wp-playground/cli@3.1.57`.

```sh
tools/wp-local.sh start       # the main site, http://127.0.0.1:9420/annual-conference/
tools/wp-local.sh status
tools/wp-local.sh stop        # stops only the server on this site's port
tools/wp-local.sh reset       # erase and start fresh (the seed loads again)
tools/wp-local.sh php x.php   # run a PHP file inside the site: start it with  require '/wordpress/wp-load.php';
tools/smoke.sh                # the foundation's checks (below)
```

- `start` is idempotent: if the site is already running, it prints the address.
- Env:
  - `PORT` (default 9420)
  - `SITE` (default `.wp-local/main`)
  - `WORKERS` (default 2; area copies use 1)
- What `start` does:
  - mounts `plugin/ogc-conference` and the stand-in theme `plugin/ogbbc-standin`;
  - defines `OGC_DEV` true;
  - sets pretty permalinks and activates the plugin and theme (blueprint at `<site>.blueprint.json`);
  - logs to `<site>.log` and waits until the REST API answers.
- The site's files and its SQLite database stay in `<site>/`, so data survives a restart.
- Every request is a whole WordPress start, about 0.5 s locally. That's why the pages read a year's files in one request (`/bundle`).

**An area's own copy.** Clone the main site, then start the copy on your area's port:

```sh
tools/wp-local.sh clone volunteer
PORT=9437 SITE=.wp-local/volunteer WORKERS=1 tools/wp-local.sh start
```

**Ports:**

- 9420 is the main site, the integrated one (`tools/e2e.mjs` and `tools/smoke.sh` run against it). Leave it running; areas clone it.
- Areas use 9431–9440, in the order of the list under Areas: conference 9431, map 9432, print 9433, signin 9434, year 9435, editors 9436, volunteer 9437, register 9438, lodging 9439, lists 9440. The app frame: 9441. The COA's screens (app-coa): 9442. The committees' screens (app-committees): 9443.
- Stop only your own port.

### Signing in locally

These work only with `OGC_DEV` on a local address (127.0.0.1, localhost, `*.localhost`, `*.test`). They don't exist on ogbbc.org or on a staging copy.

| Who | How |
|---|---|
| Anyone, by email | `/annual-conference/dev-signin/?email=ruth@example.com&return=/annual-conference/register/?year=2027` finds the WordPress user for that email (or makes one) and signs them in. |
| A member of a year | add `&member=2027` (comma for several; `&member=none` removes). Kept in the `ogc_dev_members` option. |
| A webmaster | add `&webmaster=1` (`0` takes it away): the `ogc_manage_all` capability (`OGC_CAP_WEBMASTER`). |
| A display name | `&name=Sarah%20C.` for a new user. |
| Sign out | `/annual-conference/dev-signout/?return=/annual-conference/` |
| wp-admin | `admin` / `password` (Playground's default, local only). |

- The **Tour** (bottom right, local and the shared prototype only: `assets/shared/ogc-dev-nav.js`, Oct 13) replaced the Pages button: nine scenes with Back · Next, each signing in the right made-up person on the date that fills its screen; **Scenes** lists them, **See as** (Visitor, Household, COA, Lodging, Webmaster), the old list's other stops under More pages (local only) and **Start over** (clears this browser's `ogc*` keys; for a webmaster on the local site, also reloads the seed). Locally it starts as a pill (`?pages=1` opens it). A thin "Early prototype" banner tops every page. `NOTES/early-link.md` has the scenes and the prototype's sample data (`PROTOTYPE=1 tools/wp-local.sh start` to see them; `tools/build-prototype.sh` builds the package).
- **No email is ever sent locally.** `wp_mail` is stopped, and each message is noted in the change log as `mail_dev`. The signin area's Mail log takes over before that.
- **The sign-in page has "Dev · Sign in as" pills** (COA chair, Helper, Webmaster, A household, A volunteer, Mail log). The made-up members are in `seed/members.json`.
- **The Mail log** is `/annual-conference/mail/` (webmasters; local, or a staging copy with `OGC_MAIL_CAPTURE`): every email kept, readable at 390 or 600, with links that work (open a sign-in link there to sign in as that person). `?preview=all` draws every kind in the set.

## Sign-in, members and email (signin area)

**Sign-in** (`module-auth.php`, `templates/signin.php`): one page, `/annual-conference/signin/`, for everyone. Type an email → **Send code** → **Check your email** (a 6-digit code, or the link in the email). Your sign-ups (`register/?view=mine` and `?view=receipt`) sends anyone not signed in here first (302, `?return=` encoded), so there is one door with one set of words.

- Tokens: 32 random bytes, kept only as HMAC-SHA256 with `wp_salt`, single use, 30 minutes (invites, confirmations: 7 days). A code works only in the browser that asked (cookie `ogc_req`), 5 tries a code ("Code not valid · 3 tries left"), each try counted in one `UPDATE … WHERE tries < 5` before the hash is compared. Resend keeps that browser's three newest codes for the address working (mail comes out of order); a code another device asked for is never touched. No code is made at all for an address that may not sign in this way (unknown, or an editor's).
- **Wrong codes:** from a device that has never signed in as the address, 10 a day, the same for every address, turn codes off for 24 hours on such devices ("Too many tries · Send a new code", the same words for every address, known or not); every open code for the address ends and the address gets `codes_off` once. The person's own devices (user meta `ogc_devices`) keep getting codes. Webmasters get codes like everyone; whether they should (or use a device-bound link, or wp-login's two-step) is questions-signin Q5, for the Nov 6 security plan.
- **The code and the link are separate:** the email's link, opened on another device than the one that asked (the phone, while the laptop waits), signs that device in and keeps the code good on the asking one (a new row holding the same code, `data.cth`), whose Check your email then says "Signed in on another device · Code still works here". The email's button reads "Sign in on this device".
- **A link for the person already signed in here** (an invite on a phone signed in since registration; Confirm it's you's own link) is spent at once and starts a fresh sign-in, so a members' page doesn't ask again. No tap: a mail scanner has no sign-in there.
- **Counting** (`ogc_throttle`): table `ogc_hits`, one row a counted try (insert, then count; a request over the limit takes its row back out), never transients.
- **Send limits:** per address *and* device (cookie `ogc_device`): 1 a minute, 3 per 15 minutes, 10 a day. Per address across devices: 15 a day, skipped on a device that has signed in as that address before (user meta `ogc_devices`, the last ten), so a script can't lock the real person out. Per IP: 300 an hour (`ogc_signin_ip_per_hour`; the campus Wi-Fi). Over a limit: "Too many codes · Try in 14 min" (waits are relative, never a clock in another time zone).
- **Same-site only:** `auth/send`, `auth/code` and the page's own POSTs need `Sec-Fetch-Site: same-origin`, or (older browsers) a matching Origin or Referer; a request with none is refused (`ogc_same_origin_strict()`). This guards against other sites (CSRF) only: a script that forges the headers passes it, and the limits above are what hold scripts back. A link card's POSTs (Origin `null`, no referrer) must carry the card's landing cookie back (`ogc_land` = field `k`).
- **The same answer for every address.** Mail goes after the response: a known address gets `signin`; an unknown one gets `no_signups` (fixed words: Register, Volunteer, "Sign in with another email"), at most once a day; an editor or admin's gets `signin_wplogin`. Nothing typed goes into either, so it isn't a relay.
- A link's GET (`?t=`) puts the token in a 15-minute cookie (`ogc_lt`) and 303s to `?confirm=1`, so the token is never in the address bar, history or an analytics script's page address. That page is the card (whose sign-in + one button; an invite says "Nathan K. added you", its Role and "Open 2027"; "Signed in as r***@… on this device" when someone else is); the token is spent on the POST, then a 303 to a clean address. Expired, used and tampered links have their own cards, with **Send new code** where it can. Check your email reopened after 30 minutes shows the form again with the address filled in and "Code expired".
- `?return=` is a path under `/annual-conference/` only (encode it: `ogc_url()` doesn't). The heading then names it ("Your sign-ups", "Lodging", "Members": `ogc_signin_dest_label()`). With none: webmasters land on the webmasters' page; a member on their year (their committee's page when "Helps with" names one: `ogc_member_landing`); a member of two years on the sooner Conference (the other is "Open 2028" beside the account mark); everyone else on Your sign-ups.
- Links and codes sign in only users whose roles are `ogc_person` or `subscriber`; editors and admins use wp-login. The plugin's people get no wp-admin, admin bar, password reset, application passwords or WordPress account emails, and can't sign in with a password.
- A sign-in lasts a year on a device; **Shared device** is a setting of the device (cookie `ogc_shared`, a year), off by default: every sign-in on that browser then ends when it closes, at most 4 hours. Its switch is on Check your email (a POST, `ogc_do=shared`) and in the account menu (`OGC_WP.sharedUrl`, `?shared=1` + nonce; `?shared=0` turns it off and restores the year). `OGC_WP.sharedDevice` is true while it's on. Your sign-ups shows the same account control as every page (`.rf-who` is replaced by it); someone without a full name sees "Sign out" in words beside the mark. Members' pages ask for a code again after 30 days: over an open page, the Confirm it's you dialog (a REST 401 `ogc_reauth`); opening a members' page, that page's own frame (page `reauth`, `templates/signin-reauth.php`, 403) with the same dialog, which reloads the page once confirmed. The dialog also resolves when the email's link is opened in another tab: it listens for the `ogc-signed-in` storage event and checks on focus with `GET /annual-conference/signin/?session=1` (same site only; `{email, fresh, nonce}`). Added webmasters: 7 days.
- **No access** (`refused`): the address, "Not you? Sign out", what's true ("Access ended Sep 1", "Removed Oct 9"), then **Ask for access** only for someone who had a row for that year; for anyone else **Your sign-ups** is the one button.
- Sign out: `OGC_WP.logout` → "Signed out". `OGC_WP.signoutAll` ends every other session.
- REST: `POST auth/send {email, return?}` → `{sent, email}` (429 with `until` and "Too many codes · Try in 14 min"); `POST auth/code {code}` → `{ok, go, nonce}` (400 `ogc_code_bad` with `left`, `ogc_code_tries`, `ogc_code_gone`).
- PHP: `ogc_signin_request()`, `ogc_signin_code()`, `ogc_auth_sign_in_user( $user, $remember, $how )`, `ogc_signin_link_for( $email, $return, $kind )`, `ogc_mine_url( $email, $year )`, `ogc_token_create()` and the `ogc_token_kinds` filter, `ogc_email_confirmed( $email )`, `ogc_safe_return()`, `ogc_landing_for( $user_id )`, `ogc_wait_words( $until )`, `ogc_email_wbr( $email )`. Action `ogc_signed_in( $user_id, $row, &$go )`.
- **A device's own records:** someone who typed an email but hasn't confirmed it may create the kinds in `ogc_anon_kinds`, and this device (cookie `ogc_device`) may see, change and leave only what it made. Records linked to a second email (`ogc_record_link_add( $id, $email, 'helper'|'parent' )`) are that person's too; a helper may change, a parent only see.
- `window.OGC_AUTH`: `signinUrl( ret )`, `notYouUrl( ret )`, `reauth()`, `suggest( email )` ("ruth@gmail.com" for "ruth@gmial.com"). The account mark is drawn by `assets/signin/ogc-account.js` at the end of every `.ws-bar__in`.
- **The dev sign-in and its pills** exist only with `OGC_DEV` **and** a local address (127.0.0.1, localhost, `*.localhost`, `*.test`: `ogc_is_local_host()` in core-dev.php). It sets `ogc_last_signin` like every other sign-in.
- **For Corey's staging copy:** define `OGC_MAIL_CAPTURE` (mail is kept in the Mail log, never sent) and `OGC_MAIL_ALLOW` with the testers: `define( 'OGC_MAIL_ALLOW', 'chair@example.org, @coa-testers.org' );` (addresses, or `@domain`). Testers' mail really goes ("Sent (allowed)" in the log), so the COA can sign in during Nov 7–20. On any address that isn't local, the Mail log keeps no sign-in or confirm words at all and every one-time link reads `?t=link-removed` (a webmaster reading it can't sign in as anyone). Sign-in and confirm emails are tried once: never queued or retried; a failure blanks the row and logs Failed.
- **For Corey's review:** check any plugin that syncs WordPress users (a newsletter's "WordPress Users" list, MailPoet and the like): every household that signs in is a WordPress user (role `ogc_person`), so exclude that role. If Nexcess serves PHP through LiteSpeed, `litespeed_finish_request()` is used (so a known address doesn't answer slower than an unknown one).

**Members** (`module-members.php`, table `ogc_members`: year, email, role `coa`|`helper`, name, **committees** (keys, comma-separated), **head**, helps (a label in the COA's words), invited_by, invited_at, signed_in_at, access_years, expires_at, removed_at…). `ogc_is_member` reads it on every request. Access: helpers 1 year after the Conference's last day, the COA 2 (`ogc_member_default_years`); webmasters choose 1–3.

- **Committees** come from the year's list the COA writes (`committees.csv`, carried to next year by the pickup); with none kept yet, the names the year's requests and shifts use (`ogc_members_committee_list( $year )` → key → name). "New committee" in Invite or Edit adds a row to `committees.csv`. **For the app area:** `ogc_member_committees( $year, $email )` → the keys someone's screens follow (empty for the COA, who see everything); `ogc_member_role_words( $m )` ("Lodging · Head"); filter `ogc_committee_screens( '', $year, $key )` → the screens' names in words, which the invite then says. Screens are gated by committee in the app (`ogc_app_can_see`; DEV.md › App), and every committee route asks the same rule.

| Route | Who may | What |
|---|---|---|
| `GET /years/{y}/members` | members of y, webmasters | `{year, dates, signin, page (the Members page), viewer: {webmaster, coa, invite, roles}, until: {coa, helper} (the date most of each shares), years: {coa, helper}, committees: [{key, name}], landings: {committee key: "Lodging"}, members: [...]}`. Every row: `{id, name, role, helps, committees: [keys], committee (the first's name), head, state (active\|invited\|expired), until, expired, ending, removed, you, can}`. For those who may invite (and a person's own row), also `email, invited ("today", "yesterday", "Oct 6"), signed_in, invite_expired, suspect (a never-used address that looks mistyped: the likely fix), by`; `can.email` while the row has never signed in. A helper sees others' names (or a masked address), committee and the coarse `state` only. |
| `POST /years/{y}/members` `{emails, role?, years?, committees?: [keys], new_committee?, head?, helps?, typos_ok?}` | the year's COA (helpers only); webmasters (any role; years 1–3, 0 = the role's default) | invite. `emails` is text as pasted: lines, commas, semicolons, "Name <email>", Outlook's "Last, First <email>", a spreadsheet's name and email columns. Each new person gets their own invite (a one-use link, 7 days); more than 5 at once go through the mail queue. → `{added: [ids], already: [ids], bad: [text], list}`. Up to 40 at once, 60 an hour (the old `coa/{y}/members` POST goes through this route too). **A likely typo** in a common domain ("gmial.com", `ogc_email_suggest()`) is refused once: 409 `ogc_typo` `{message: "Check x@gmial.com · Did you mean gmail.com? · Invite again to send as typed", data: {suspect: [{email, fix}]}}`, nothing added. Sending the same address again within 15 minutes, or `typos_ok: true` (after the page has asked), goes ahead. Show `message` at the field. |
| `PATCH /members/{id}` `{name?, email?, committees?, new_committee?, head?, helps?, role?, renew?, restore?, typos_ok?}` | name: the COA, webmasters, the person; committees, head, helps: the COA, webmasters; email: the COA for helpers, webmasters, only while the row has never signed in; role: webmasters; renew: the COA for helpers, webmasters; restore: undo a removal within the hour | → `{member, list}`. The last COA member can't be made a helper. A new email ends the old address's open invite, sends the new one its own, and is logged ("Nathan K. changed Esther H.'s address"); a likely typo is refused once (409 `ogc_typo`) unless `typos_ok`. |
| `DELETE /members/{id}` | the COA for helpers (never themselves); webmasters (the last COA member too) | access ends now; their unused invite links for the year end. Their sign-in stays (their household's Your sign-ups still opens). → `{removed, id, list}` |
| `POST /members/{id}/resend` | the COA, webmasters | a new invite link (once a minute; 429 "Sent · Just now") |
| `GET /years/{y}/members/history` | those who may invite: the year's COA, webmasters | `[{at, words, n}]`: "Nathan K. invited Joel M." (the name as it was when written), a time for today's lines, the same line on the same day once with `n`. |
| `GET /years/{y}/members/preview?role=&years=&committees[]=&new_committee=&head=` | the year's COA, webmasters | the invite exactly as sent, by the invite's own rule (a webmaster's years, else the role's default): `{from, subject, html, text}` |

- **The Members component** (`assets/signin/ogc-members.js`, `OGC_MEMBERS.mount( el, year )`, or any `data-ogc-members="2027"`; add `data-om-full` for the whole list), one component with two layouts. Narrow (a phone, the year page's column): Invite first (chips, then Committee pills + New committee + Head), then COA and each committee, each with its own end date under its label, one line a person with one status; a row opens to its address, committee and actions; Edit replaces the actions with the form. When the card is 860 px or wider and the viewer may invite: a table (Name · Email · Committee · Status · Invited by · Until; a column with nothing in it isn't drawn) with the card's whole width; choosing a row opens its panel beside it (Edit, Resend, Renew, Remove; Close), and Invited by and Until give way while it's open, so nothing scrolls or is cut off at 1180–1440. A helper gets the list as a directory at every width, their own committee first. `?open=<id>` opens a row. Committee pills are A–Z, "One or more"; Head is its own switch ("Head of committee") once a committee is picked. On the year page and the webmasters' page a list longer than 8 is a summary ("14 members · 8 not signed in") and **Manage**, which opens the **Members page**, `/annual-conference/members/?year=2027` (`templates/signin-members.php`). The webmasters' page mounts it too (`admin-web.js` `membersCard()`).
- The year area's first routes (`coa/{y}/members`, `…/resend`, `…/remove`, `…/set`) answer from this list, in their old shape.
- `access_ending` goes 14 days before access ends, only to COA members and helpers who signed in within the last 90 days.
- **Webmasters:** site admins, and anyone given `ogc_manage_all`. **One rule, wherever it's asked** (the webmasters' page's REST `webmasters`, `webmasters/confirm`, and **Settings › Conference webmasters** in wp-admin): one webmaster asks to add or remove, a second confirms (`ogc_webmaster_ask`, `ogc_webmaster_confirm`, `ogc_webmaster_cancel`); while there's only one webmaster, their ask goes ahead. Adding sends `webmaster` from the one who asked (Reply-To them). Site admins can't be removed there. One list for both screens: `ogc_webmasters_payload()` (names as "First L.", never a login; last sign-in from `ogc_last_signin()`). `ogc_webmasters()` reads by capability (`capability__in`), never "the first 500 users". Settings › Conference webmasters also holds "Replies to", the webmasters' role address.

**Email** (`module-mail.php`, `module-mail-templates.php`, table `ogc_mail`):

- `ogc_mail_send_kind( $kind, $to, $data, $context )`: a designed email from the set. `ogc_mail_template( $kind, $data )` → `{subject, html, text}`.
- `ogc_send_mail( $to, $subject, $html_or_text, $context )`: one message to each address (never To/CC lists). Context: `kind`, `year`, `text`, `reply_to`, `ics` + `ics_name`, `delay`, `coalesce`, `queue`.
- `ogc_send_mail_many( $items )`: over 20 go through the queue (WP-Cron, 25 at a time); `GET mail/batches/{id}` → `{sent, failed, queued, total}`.
- An address nobody has proved gets at most 6 an hour and 20 a day of anything but sign-in codes: past the hour's 6 a message waits an hour and a later one of the same kind takes its place; past the day's 20 it's refused ("Refused · limit" in the Mail log, `mail_refused` in Activity). Never capped (`ogc_mail_cap_exempt`): members and webmasters (context `to_member`), role addresses (`contact_*` settings, committees' `contact_email`, Replies to), and the signed-in person's own address.
- **A parent's approval** sent any way but the set's `parent_approval` is rebuilt from the set in `ogc_send_mail` (only its link kept; logged `mail_guarded`): it goes to an address a teenager typed, so it names no one.
- `tools/check-mail.php` (`tools/wp-local.sh php tools/check-mail.php`) checks every kind (subject = heading, no "!", no "Lord willing", the parent's approval names no one) and lists every place that builds its own email instead of using `ogc_mail_send_kind` (exit 1). On ogbbc.org only who, what kind, when and Sent/Failed are kept, 60 days.
- From "ogbbc.org Annual Conference" `<conference@…>` (filter `ogc_mail_from`).
- The layout: headings bold; **the subject is the heading**, word for word; sign-in emails name no year. Under the one button, the page it ends on (for a one-time link, its return page, or just the site when it has none; a template may give a third button part to say it), never `/signin` or a token. The footer gives a reason only when no line above already says it.
- Kinds and their data (all take `year`; times as `day` + `start` + `end`, or `when`; names are cleaned):

| Kind | Data |
|---|---|
| `signin` | code (empty: a link-only email, which says "Open the link on the device you're signing in on"), url, codes_off. Subject "Sign-in code" for everyone (no code, no year in a subject). Button "Sign in on this device". |
| `no_signups` | members_page, return. Offers only what's open now: Register while registration is open on the site, Volunteer once sign-ups are posted, else Sign in with another email. From a members' page: "Not on the 2027 members list". |
| `signin_wplogin`, `codes_off` | (none). `codes_off`: "Codes off · 24 hours", what still works. |
| `invite` | by_name (or by_webmaster: "A webmaster added you"), role, committee_words ("Lodging (Head)": `ogc_member_committee_words`), open_label ("Open Lodging", "Open 2027" for the COA: `ogc_member_open_label`), access (default "Every 2027 page and list", true today for helpers too), landing_url, until, url, reply_by. Subject and heading "Nathan K. added you"; the year is the line above. Reply-To the inviter (context `reply_to`). |
| `webmaster` | by_name, url, reply_by. Subject "Caleb J. added you · Conference webmasters"; Reply-To the one who asked. |
| `access_ending` | until, role, committee_words, open_label, url (their landing). A helper's names their committee and page; the COA's says to hand over. |
| `access_asked` | name, email, was, url |
| `registration_received` | household, id, people, nights, rooms, total, method (card\|check), paid, payee, address, closes |
| `registration_changed` | household, id, changes [[label, before, after]], difference |
| `registered_for_you` | by_name, id, nights, total |
| `parent_approval` | approve_url, again ("Reminder · Approval needed"). The email names no one: "For a Young Folk's registration". |
| `payment_received` | id, amount, method, due |
| `credit_asked` / `credit_given` | id, nights, amount, by / how |
| `rooms_posted` / `rooms_changed` | checkin (never the rooms themselves) |
| `signed_up` | title, day, start, end, place, committee, note, notme_url, has_ics; or shifts [[title, when, place, name]…] gathered in one email; confirm_url + confirm_hours (a first-time volunteer's place); by (a head signed them up) |
| `reminder` | title, day, start, end, place, note, map_url, leave_url ("Can't make it? Leave shift"; falls back to Your sign-ups) |
| `shift_changed` | title, before, after |
| `shift_removed`, `you_left` | title, day, start, end, join_url |
| `volunteer_left` | name, title, day…, open, needed, committee, list_url |
| `spot_open` | title, day…, place, join_url, leave_url |
| `team_signed_up` | title, team, day…, place |
| `message` | subject, from (a role), about, body (plain), link |
| `weekly` | committee, filled, needed, new, left, open_shifts [[title, when, open]] |
| `confirm_email` | code |
| `email_changed` | new_masked, by |

## The plugin's files

```
ogc-conference.php      header, constants, loads every includes/*.php (core* first, then module*), activation
includes/core.php       helpers: ogc_table, ogc_url, ogc_current_email, ogc_is_webmaster, ogc_is_member, ogc_log, CSV
includes/core-schema.php  tables (ogc_schema filter + dbDelta), activation
includes/core-store.php the data layer: years, files, state, records
includes/core-rest.php  the REST routes and their permission checks
includes/core-pages.php the pages: address, shell, template, assets; OGC_WP; drawing
includes/core-routes.php  rewrite rules, the data addresses, the guide's manifest/sw/icons
includes/core-import.php  the seed importer
includes/core-dev.php   OGC_DEV only: dev sign-in, dev import route, no mail
includes/module-*.php   the areas' modules (an area adds a file; nothing else changes)
templates/*.php         one per page (v3's markup minus the mockup scripts), guide-head/-manifest/-sw
                        (an area's own replaces one through ogc_pages: the volunteer page uses only
                        volunteer-v2.php; volunteer.php is the foundation's v3 copy, unused)
assets/                 v3's front end, same folder layout (shared/, schedule-hub/, year/, …)
seed/                   2025–2027 as v3's pages see them (picked up), made by tools/seed-from-v3.mjs
NOTES/<area>.md         each area's log of changes to shared files
```

**Constants:**

- `OGC_VERSION`
- `OGC_DB_VERSION`
- `OGC_DIR`, `OGC_URL`
- `OGC_DEV` (false unless defined before the plugin loads)
- `OGC_NS` (`ogc/v1`)

**Prefixes:** `ogc_` for PHP functions and options, `OGC_` for constants, `ogc-` for handles, CSS and storage keys.

## Pages

| Address | Page (v3 folder) | Shell | Who |
|---|---|---|---|
| `/annual-conference/` | Conference page (`schedule-hub`) | theme | everyone |
| `/annual-conference/guide/` | the guide (`guide`), plus `manifest.webmanifest`, `sw.js` (scope `/annual-conference/guide/`), `app/<icon>` | bare (`ogc-app`) | everyone |
| `/annual-conference/schedule/` | printed schedule | theme | everyone |
| `/annual-conference/packet/` | the packet | theme | everyone |
| `/annual-conference/register/` | the form, Your sign-ups | theme | everyone |
| `/annual-conference/volunteer/` | volunteer shifts | theme | everyone |
| `/annual-conference/tournaments/` | tournaments | theme | everyone |
| `/annual-conference/app/` | **the back end, one app** (DEV.md › App): Home, Committees, Tasks, the COA's and each committee's screens, Members, Years | bare | members of the year, webmasters |
| `/annual-conference/admin/?edit=shifts:<committee>` · `?edit=tournaments` | the shift and tournament editors (not in the app yet; from Helpers' and Teams' More menus, `return=` back) | bare | members |
| `/annual-conference/year/`, `/admin/` (any other), `/lists/`, `/lodging/`, `/members/`, `/volunteer/?view=lead`, `/tournaments/?view=teams` | **redirect (302) into the app**, to the matching screen (`ogc_coa_app_landing`, module-app-committees.php, module-integration.php); signed out, through sign-in with the app to return to. `/lists/?view=callin` is the one old page still drawn. | | |
| `/annual-conference/signin/` | sign-in, the link card (`?confirm=1`), No access | theme | everyone |
| `/annual-conference/mail/` | Mail log, `?preview=all` every email | bare | webmasters, only where mail is captured (local, or `OGC_MAIL_CAPTURE`); a 404 for anyone else |

**Shells:**

- **theme**: the site's `get_header()` and `get_footer()` around the template. Locally that's the stand-in theme. Theme pages load `shared/ogc-tokens.css` (the colours and the container), never the theme's own base styles.
- **bare**: the plugin writes the whole document and loads `shared/site-shell.css` for the base type.
- Noto Serif comes from Google Fonts on bare pages. The theme brings its own font on theme pages.

**Members' pages:**

- A members' page needs a member of the year in `?year=` (or of any year, if there's no `?year=`). Webmasters may open every page.
- Not signed in: a 302 to `/signin/?return=…`. Signed in but not a member: 403 and the sign-in card. A member whose sign-in on that device is older than 30 days: 403 and the page's own frame with Confirm it's you.
- The filter is `ogc_page_allowed`.

**v3's own addresses still land:** `/annual-conference/schedule-hub/` and any `…/index.html` redirect with 301, keeping the query.

**Changing a page** (from your module, never by editing core-pages.php):

```php
add_filter( 'ogc_pages', function ( $p ) {
	$p['volunteer']['scripts'][] = 'volunteer/extra.js';   // paths relative to assets/
	$p['volunteer']['template']  = 'volunteer-v2.php';      // in templates/
	return $p;
} );
```

- A page's keys:
  - `path`, `folder` (its v3 folder, for links), `shell`, `members`;
  - `title`, `description`, `noindex`, `html_class`;
  - `header` (the stand-in's topbar and crumb hints), `head` (a template printed in `<head>`);
  - `fonts`, `styles`, `scripts`.
- `ogc-wp.js` is always first. `ogc-dev-nav.js` is last, and only with `OGC_DEV`.
- Assets are versioned by their file's time. A logged-in page is never cached (`nocache_headers`, `DONOTCACHEPAGE`).

## Tables

`dbDelta` applies these whenever `OGC_DB_VERSION` or the SQL changes. An area adds its own table through `add_filter( 'ogc_schema', fn( $sql, $charset ) … )` (see core-schema.php).

| Table | Columns | What |
|---|---|---|
| `ogc_years` | year PK, fields (JSON), updated_at | years.csv, one row a Conference |
| `ogc_files` | id, year, name, rows_json, cols, version, updated_by, updated_at; unique (year, name) | a year's parts as the pages read them, already merged. `rows_json`, not `rows`: ROWS is reserved in MySQL 8. `cols` keeps the column order, so a header-only file (contacts) still exists. |
| `ogc_records` | id, year, kind, email (lowercased, indexed), data (JSON), sample, source, created_at, updated_at, deleted_at | what people sign up for, one row each. Delete only sets deleted_at. |
| `ogc_state` | id, year, skey, value (JSON), version, updated_by, updated_at; unique (year, skey) | small values a year keeps (`picked`: the pickup log; Lodging's `rooms`…) |
| `ogc_log` | id, at, user, year, action, target, detail (JSON) | the change log. detail never holds personal data: members' History lines keep the member's id (target `member:ID`) and are named when read. |

## REST routes (`/wp-json/ogc/v1/…`)

WordPress needs the `X-WP-Nonce` (`wp_rest`) header on any request from a signed-in browser: without it, the request is treated as signed out. `OGC_WP.api` sends it every time. Every change is logged.

**Never cached** (core-rest.php, a `rest_post_dispatch` filter): a person's own answers (`records`, `me/`, `rooms/`, `state/`, `log`) and every answer to a member of the year in the address are sent `Cache-Control: private, no-store, max-age=0`, so neither the browser nor the guide's offline copy keeps them. (It was in the map module until Oct 10.)

| Route | Who may | What |
|---|---|---|
| `GET /years` (`?format=csv`) | everyone | years.csv (filter `ogc_years_public`) |
| `PATCH /years/{y}` `{fields:{k:v}}` | members of y; **webmasters only** to start a new year | set a year's fields (`O.edits.setYear`) |
| `GET /years/{y}/bundle` | everyone (each file only if readable) | every file of the year: `{name:{rows,cols,version}}` (how ogc-store.js reads a year) |
| `GET /years/{y}/files` | members | the year's files: versions, row counts |
| `GET /years/{y}/files/{name}` (`?format=json`) | everyone; private files (`needs`, `notes`: filter `ogc_private_files`) members only; an area withholds others with `ogc_file_visible` | CSV text (default), or `{rows, cols, version}`. Unreadable or missing files read as empty (200), so a withheld file can't be told from a missing one. |
| `PUT /years/{y}/files/{name}` `{rows, version, cols?}` | members | replace the rows. **409** if the version isn't the current one (`{data:{version}}`). Rows are flat objects: ≤5000 rows, ≤2 MB, keys `[A-Za-z0-9_][A-Za-z0-9_ .-]*`. Filter `ogc_file_rows_valid`. |
| `PATCH /years/{y}/files/{name}` `{op:'row', row}` or `{op:'key', key, value}` | members | change one row on the server's copy (`saveRow`: key column `help→need`, `places→code`, `nearby→name`, filter `ogc_file_row_keys`; `_gone` removes) or one key (`setKey`). No version needed. |
| `GET /years/{y}/state/{key}` | members | `{value, version}` (404 if none) |
| `PUT /years/{y}/state/{key}` `{value, version?}` | members | set it (409 on a stale version, when given) |
| `GET /years/{y}/records?kinds=a,b` | everyone | per kind: a member gets every record; anyone else gets their own whole, plus others' public views (marked `public`). Each record is `{id, mine, data, sample?}`. |
| `GET /years/{y}/records/{kind}?scope=mine` | signed in | your own (by your email) |
| `…?scope=all` | members | all of the year's |
| `…?scope=public` | everyone | the kind's public view (`ogc_record_public`). With no filter, nothing. |
| `POST /years/{y}/records/{kind}` `{data}` | default: members; anyone signed in for a record that's theirs (its email is theirs, or none); filter `ogc_record_can_write` | create (201) |
| `PUT /records/{id}` `{data}` | default: members of its year; its owner (and it stays theirs) | replace its data |
| `DELETE /records/{id}` | as PUT | remove (soft) |
| `DELETE /years/{y}/samples` (`?kind=`) | webmasters | erase the year's sample records |
| `GET /log?year=&limit=` | webmasters; members for their year | the change log |
| `POST /dev/import` `{force: year or true}` | webmasters, **OGC_DEV only** | reload the seed |

**Records:**

- The kinds are `signups`, `registrations`, `credits`, `waits` and `teams`. An area adds more with `ogc_record_kinds`; any other kind gets 404.
- A record's owner is `data.email`, or else `data.household.email` (filter `ogc_record_email`). It's kept lowercased in `email`.
- Data is limited to 64 KB. `_rid`, `_pub` and `mine` are stripped.
- Validation goes through the filter `ogc_record_validate` (return a `WP_Error` to refuse).
- After a create, change or remove, the action `ogc_record_saved( $record, $action, $req )` runs (for emails and the like).
- Someone else's record answers 404, not 403, so its existence isn't given away.

**Other hooks:**

- Files: `ogc_file_saved( $year, $name, $version )` (action).
- Pages: `ogc_pages`, `ogc_client_config`, `ogc_template`, `ogc_page_allowed`, `ogc_before_page` (action).
- Members and addresses: `ogc_is_member( false, $year, $user_id, $email )` (the signin area answers), `ogc_is_webmaster`, `ogc_base_path` (the address, an open Advisors' question).
- Seed and schema: `ogc_seed_dir`, `ogc_seed_year` (action), `ogc_schema`, `ogc_rewrites` (action).

## The JS seams

Every page loads, in order: `ogc-wp.js`, `ogc-core.js`, `ogc-store.js`, `ogc-pickup.js`, then the page's own scripts.

**`window.OGC_WP`**, written by the page (`ogc_client_config()`, filter `ogc_client_config`):

```js
{ rest, nonce, base: '/annual-conference/', page: 'conference', folder: 'schedule-hub', assets,
  me: { email, name } | null, member: [2027], webmaster: false, dev: true, signin, logout, version }
```

**`shared/ogc-wp.js`** (loaded first):

- **Data:** any `fetch` of `…/schedule/data/years.csv` or `…/schedule/data/<year>/<name>.csv` is answered by `OGC_WP.data`. That's the REST fallback, or ogc-store.js once it's loaded. So v3's `data-base`, `ogc-core.js` and the pages' own loaders work unchanged. The same addresses also answer on the server, as CSV.
- **Links:** v3 links folders relatively. `OGC_WP.url(href)` resolves a link from the page's v3 folder, so on the Conference page `../register/` becomes `/annual-conference/register/`, `../schedule-hub/` becomes `/annual-conference/`, and `index.html` is dropped. Every `a[href]` is fixed as it's drawn.
- **Script navigations aren't fixed.** `location.href = '../x/'` works from every page except the Conference page (at `/annual-conference/`). Use `OGC_WP.url()` there.
- **`OGC_WP.api(method, path, body)`** makes a REST call with the nonce and parses the JSON. Errors are thrown with `.status` and `.data`, and a refreshed nonce is kept.
- **See it:** a page framed beside the year page reloads, where it was, after any save in this browser (the `localStorage` key `ogc-saved`, set by the store).

**`shared/ogc-store.js`** replaces v3's `ogc-local-edits.js`.

- **`O.edits`** keeps the same API: `get`, `merge`, `saveRow`, `saveFile`, `setKey`, `setYear`, `mergeYears`, `clear`.
  - The server holds the rows already merged. `merge` and `mergeYears` hand back the server's rows for any file the page has read (lossless: `_id`/`_look` are kept). For a file it hasn't read, they hand back what the page passed in.
  - A year's files come in one `GET /bundle`, shared by every read within 2 s.
  - Writes show at once in this browser and are sent in order:
    - `saveFile` is a PUT with the version; an unsent save of the same file is replaced;
    - `saveRow` and `setKey` are PATCHes;
    - `setYear` is a PATCH on the year.
  - While a file has unsent changes, reads of it come from this browser.
  - Offline or 5xx: it retries with backoff (1 s up to 30 s). Leaving the page asks first.
  - 401/403/400: it's dropped, with `console.error` and an `ogc:save` `{state:'error'}` event.
  - 409 on a PUT: an `ogc:conflict` `{year, name, theirs, mine}` event is sent. Unless a listener calls `preventDefault()` (which keeps theirs), this browser's rows are saved over theirs. v3's editors have no merge yet; that's the editors area's job.
  - Status events go out on `window` as `ogc:save` `{state: 'saving'|'saved'|'offline'|'error', pending}`. **v3's pages still print "Saved" when they call the store, not when the server answers: the editors and year areas wire their `.ws-status` to these events.**
  - `O.store.flush()` resolves once everything has been sent.
  - `clear()` does nothing (the server keeps the year).
- **`O.state`**: `load(y, key)` returns a Promise; `get(y, key, fallback)`, `has` and `loaded` are synchronous after a load; `set(y, key, value)` queues a PUT. Members only.
- **`O.records`**:
  - `load(y, kinds?, force?)` calls the bundle route;
  - `list(kind, y)` returns a copy of the array (the objects are shared) or null;
  - `store(kind, y, list)` diffs against what was loaded: new objects are POSTed, changed ones PUT, missing ones DELETEd. A new object with the same `id`/`email`/`name` as a removed one is a PUT on that record.
  - Each object carries `_rid` (its record id). Others' public views carry `_pub` and are never written.
  - An object still being created isn't sent twice.
  - `ogc:records` is sent when a year's records arrive.
- **`O.ready`** resolves once the store has the years, plus the records of `?year=` and the year before (or of the two newest years).

**`shared/ogc-signups.js`** (the plugin's copy):

- `SU.load` and `SU.store` keep their signatures. `signups`, `registrations`, `credits`, `waits` and `teams` are `O.records`; `rooms` is `O.state` (`rooms`).
- `SU.me()` is `OGC_WP.me`. Someone who typed their email but isn't signed in is kept in this browser as `pending` (`ogc-me-pending`). **The server refuses their writes until the signin and volunteer areas let them through** (the emailed link).
- `SU.signOut()` goes to WordPress's logout.
- **The samples are off:**
  - shifts start with `base: 0, sample: []`;
  - `SU.households()` is the registrations this viewer may see (a member sees every one; anyone else sees their own), with `mine` set;
  - `sampleHouseholds`, `seatSamples`, `sampleFilled` and `POOL` are still exported, for making seed rows.
- The year's picture is the plugin's `shared/img/conference-auditorium.jpg`, not a file on another site.

**`shared/ogc-pickup.js`** (the year area's): the seed holds 2025–2027 already picked up, and the pickup log is the state value `picked`. Nothing runs on page load. `O.pickup.run()` (the webmasters' Start) picks up the years this person is a member of, through `O.edits`.

**Browser keys.** Every key v3 kept for the COA or a committee (`ogc3-…`) now lives on the server (`O.state`, records, or an area's table). What stays in a browser is per-viewer convenience only: an unsent form (`ogc3-register-<y>`, this tab), the Preteens filter (`ogc-week-shows`; week.js moves an old `ogc3-week-shows` over once), the app's last committee (`ogc-app-team`), the volunteer page's own hold.

## Seed

- `node tools/seed-from-v3.mjs` makes `seed/` from v3 as its pages see it:
  - it serves the repo, opens v3's year page in headless Chrome, and lets the pickup run;
  - it dumps every file the pages read, merged (2027 picked up from 2026), plus `years.csv` and each year's pickup log (`<year>/state.json`);
  - headers are kept exactly as written, including `_id` and `_look`;
  - a header-only file (contacts) is kept.
- The importer (`ogc_import_seed()`) runs on activation, on a schema change, and from `POST /dev/import`. It loads any year that isn't in the tables yet. With `force`, it replaces that year's files, state and sample records; people's own records are never touched.
- **Sample records:** drop `seed/<year>/records/<kind>.json` (a list of data objects). They're loaded with `sample = 1`, `source = 'seed'`. The volunteer and register areas seed their sample people this way, all made-up names. The action `ogc_seed_year( $year )` is there for seeding in code.

## Areas and what each owns

```
conference → assets/schedule-hub/*, assets/guide/*, includes/module-public*.php, the guide templates (manifest, sw.js, app/)
map → assets/shared/ogc-map.js, assets/shared/ogc-map.css (and small targeted edits to the Places/directions functions in assets/schedule-hub/week.js only)
print → assets/schedule/*, assets/packet/*
signin → includes/module-auth*.php, includes/module-members*.php, includes/module-mail*.php, templates/signin*, assets/signin/*, the email templates
year → assets/year/*, assets/shared/ogc-pickup.js, includes/module-coa*.php
editors → assets/admin/*
volunteer → assets/volunteer/*, includes/module-volunteer*.php, seed samples for signups
register → assets/register/*, includes/module-registration*.php, includes/module-payments*.php, seed samples for households
lodging → assets/lodging/*, includes/module-lodging*.php
lists → assets/lists/*, assets/tournaments/*, includes/module-lists*.php, includes/module-tournaments*.php
app → assets/app/*, includes/module-app*.php, templates/app.php (the frame; the COA's and committees' screens add files beside it)
app-committees → assets/app/screens/committee-*, includes/module-app-committees.php, and (taken over from lodging and lists) assets/lodging/*, assets/lists/*, the volunteer heads' view
foundation/integration → ogc-conference.php, includes/core*.php, includes/module-integration.php (joins between areas), assets/shared/* (except ogc-map.* and ogc-pickup.js), tools/; the shared files' log from Oct 11 is NOTES/integration.md
```

The other templates (`templates/<page>.php`) belong to foundation/integration. Change one from your module, with `ogc_pages` (`template`) and a file of your own in `templates/`.

**The shared-file rule.** For a file you don't own (`assets/shared/*`, `includes/core*`, `ogc-conference.php`, another area's files):

- make only small, targeted edits with the Edit tool, never a rewrite of the whole file;
- if an Edit fails because the file changed, re-read it and try again;
- log each change (file, what, why) in `NOTES/<your area>.md`.

Prefer a filter from your own `includes/module-<area>.php` to editing core.

## App (the committees' back end, docs/23)

One app for the COA, the committees and the webmasters, at the plugin's own address: `/annual-conference/app/`. Files: `includes/module-app.php` (tables, page, viewer, screen registry, carry-forward, status, log words), `includes/module-app-seed.php` (the first year's committees and tasks; local samples), `includes/module-app-rest.php` (routes, the message email), `templates/app.php`, `assets/app/` (`app.css`, `app.js` = kit + shell, `screen-*.js`). The COA's and committees' screens move in here.

### Addresses

`/annual-conference/app/?year=2027&s=<screen>&c=<committee key>&id=<record>&v=<saved view>&as=<committee>&team=<committee>&past=<year>&at=<anchor>`. Every state is in the address, so Back, Reload and a link in an email all work.

- A members' page (`members => true`): signed out → `/signin/?return=…`; signed in but not on the year → the signin area's No access card (403). Webmasters open every year. With no `?year`: the viewer's soonest Conference not yet over (`ogc_app_default_year`).
- `s`: `home` (default), `committees` (with `c` = a committee's page, `past=2026` its year read-only), `tasks`, `overview` (your own committee's page), `members`, `years`.
- `as`: **See as** (COA and webmasters only; webmasters may also see as `coa`). The server answers as that committee (`ogc_app_viewer`), every write is refused (403 `ogc_read_only`), the shell shows "Seeing as Lodging · Back", and it is logged (`app_see_as`, once in 30 minutes per person, year and committee). It lives only in the address, never in storage.
- `team`: which committee's section the sidebar shows for someone on two (also remembered per browser, `ogc-app-team`).

### The shell

Sidebar: the year ("2027 · IWU"; a menu only for someone in more than one year), the committee switcher (only for someone on two), Search ⌘K, then Home · Committees · Tasks, then ONE section named for who you are (COA, Lodging…, Webmasters) with only your screens, then the person and Sign out. The page is one white card in a light grey frame; its title row holds a small title, a line of fact and the actions at the right. Below 1024 px the sidebar is a drawer (the ≡ in the title row).

### The screen registry

A screen is registered twice with the same id: its **rule** in PHP, its **drawing** in JS.

```php
add_filter( 'ogc_app_screens', function ( $s, $year ) {
	$s['rooms'] = array( 'title' => 'Rooms', 'section' => 'own', 'who' => array( 'lodging' ) );
	$s['schedule'] = array( 'title' => 'Schedule', 'section' => 'own', 'who' => array( 'coa' ) ); // handable by default
	return $s;
}, 10, 2 );
add_filter( 'ogc_pages', function ( $p ) { $p['app']['scripts'][] = 'app/screen-rooms.js'; return $p; }, 20 );
```

```js
OGC_APP.screen({ id: 'rooms', title: 'Rooms', icon: 'overview', section: 'own', who: ['lodging'],
  render(ctx) { ctx.head('Rooms', '54 to place', [OGC_APP.btn('Assign all', { primary: true, write: true, onClick })]); ctx.body.append(…); } });
```

- `who`: `all` (anyone who may open the year), `coa`, `webmaster`, `committee` (anyone on a committee: their own one), or committee keys (`lodging`, `a/v`, `young folks`: `ogc_committee_key( name )`).
- **The rule lives in PHP.** `/boot` lists only the screens the viewer may see (`ogc_app_screens_for`); the shell draws only those. Every data route of a screen asks the same rule: `ogc_app_can_see( ogc_app_req_viewer( $req ), 'rooms' )` in its `permission_callback`, and filters what it returns by `ogc_app_on_committee( $v, $ckey )`. A JS `who` is documentation only.
- **Handing a screen:** the COA hands a `handable` screen (any not in the frame) to one committee on that committee's page (Screens pills; `POST /app/{y}/hand`). It moves into that committee's sidebar section and out of the COA's (the COA still opens it from the committee's page or ⌘K); `ogc_app_can_see` lets the committee's members see it and its data. Kept in `ogc_committees.screens`, carried to next year.
- `ctx`: `body`, `head(title, fact, actions[], { crumb: { label, to } })`, `params`, `boot`, `api`, `go`, `readonly` (seeing as), `split()` (a list with the record panel beside it). `render` may return a cleanup function.
- ⌘K actions: `OGC_APP.action({ id, title, screen, when: boot => bool, run })`.
- The invite's "your screens" words come from the registry (filter `ogc_committee_screens`).

### The kit (`assets/app/app.js`, `app.css`)

| JS | What |
|---|---|
| `OGC_APP.h(tag, attrs, ...kids)` | DOM without innerHTML. `text`, `on: {click}`, `class`, `href` (own paths and `https:` only). Never put user text anywhere else. |
| `btn(label, { primary, ghost, danger, big, icon, iconOnly, write, href, onClick })` | One `primary` per view (tan). `write: true` disables it while seeing as. |
| `tag(text, 'tan' \| 'late' \| 'ok')`, `face(name, you)`, `icon(name)` | Small marks; icons are 16 px strokes (`home committees tasks members overview years search plus x chev down menu mail eye file out back note report link upload`). |
| `empty({ title, line, action, inset })` | The one empty state (a dashed card, never a bare line). Never a zero: a section with nothing true isn't drawn. |
| `toast(msg, { undo })` | What just happened ("Done · Campus tour", "Added 1 person · Sign-in link sent"), with Undo when it can be undone. `fail(err)` says why something wasn't saved. |
| `views(views, current, onPick)` | Saved-view chips over a list (`[{ id, label, n }]`); the view is `?v=`. |
| `table({ cols: [{ label, cls, wide, render }], rows, key, selected, onOpen, group, empty, label })` | A dense table; arrow keys and Enter, the mouse always enough; `group` draws heading rows; `wide` columns hide on a phone. |
| `ctx.split()` → `{ main, open({ title, body, foot, onClose }), close() }` | The record panel beside the list (the whole screen on a phone). Panels, never pop-up forms. |
| `menu(anchor, items)`, `openSearch()` | A small menu; the ⌘K palette (screens, actions, committees, people, tasks). |
| `api(method, path, body)` | `app/<year>/<path>` (a path starting `/` is from `ogc/v1/`), with `?as=` added. |
| `go(to, { replace })`, `href(to)`, `link(to, kids, cls)`, `setParams(to)` | Moving between screens; `setParams` changes the address without drawing again. |
| `team()`, `committee(key)`, `allowed(id)`, `boot()`, `refreshBoot()`, `toggleTask`, `message(ctx, { to, label })`, `noteCard` | Shared pieces. |

CSS classes: `ap-section`, `ap-h2` (+ `__n`, `__act`), `ap-cols` (main + 340 px side from 1100 px), `ap-list` / `ap-item` (+ `__main __title __why __side`), `ap-note`, `ap-banner`, `ap-person`, `ap-field`, `ap-input`, `ap-textarea`, `ap-pills` / `ap-pill[aria-pressed]`, `ap-chip`, `ap-switch`, `ap-check`, `ap-facts`, `ap-drop`, `ap-quiet`, `ap-muted`, `ap-label`. Tokens on `:root` (`--ap-*`). Type: system sans; the Home headline in the serif.

### Data (tables via `ogc_schema`; seeding idempotent)

| Table | Columns | What |
|---|---|---|
| `ogc_committees` | year, ckey, name, duties, sort, screens, link, from_year, checked_at, removed_at | A year's committees in the COA's order. `ckey` = `ogc_committee_key( name )`, the key `ogc_members.committees` holds; `coa` is the COA itself. `committees.csv` is kept in step (`ogc_app_sync_csv`) for the members' Invite pills; a name added there comes in (`ogc_app_reconcile`). |
| `ogc_tasks` | year, ckey, title, note, due_offset (days from the first day, the Friday) \| due_date, owner (member id), done_by, done_at, source (seed\|carried\|added), carried_from | What each committee does by when. |
| `ogc_cfiles` | year, ckey, name, fkey (random stored name), mime, size, uploaded_by, carried_from | Files, in `ogc_app_private_dir()`: `OGC_PRIVATE_DIR` (wp-config; best outside the web root), else `uploads/ogc-private/` with Apache and IIS deny rules. **For Corey:** on nginx add `location ^~ /wp-content/uploads/ogc-private/ { deny all; }`, or set `OGC_PRIVATE_DIR`. Served only by `GET /app/files/{id}` (a download, `octet-stream`, `nosniff`, sandbox CSP, no cache), never a media URL. Types: documents, spreadsheets, pictures (`ogc_app_file_types`), 20 MB (`ogc_app_file_max`). |
| `ogc_cnotes` | year, ckey, body, author, done_by, done_at | Notes for next year; the next year's committee marks each Done. v3's `notes.csv` (part,text) moved in once by `owner_<part>`. |
| `ogc_creports` | year, ckey, answers (JSON), updated_by, sent_at | The report. Questions: `ogc_app_report_questions()` (settings `report_q1…5`, filter `ogc_report_questions`). **Placeholders** until the COA's own five are found. |

- **Membership is the members list** (`ogc_members.committees`, `head`), not a second table: the COA manages it on Members through the signin area's routes (invite = a sign-in link). Read it with `ogc_app_people( $year, $ckey )`.
- **A year carries forward** (`ogc_app_ensure_year`, run on `/boot`): committees, responsibilities, order, screens handed, folder link, every task undone (dates moved a year; offsets kept), every file (by reference). A first year starts from `ogc_app_seed_committees()` / `ogc_app_seed_tasks()` (docs/16's eleven and their fixed dates). Pre-app `committees.csv` names nobody is on are dropped then.
- **Status words:** `ogc_app_committee_status( $year, $c )` → `{ line, look[] }`. Default "Next: First meeting · Nov 1" (never "0 of 6"); a committee's module writes its own with `add_filter( 'ogc_committee_status', fn( $line, $year, $ckey, $ctx ) … )` (`$ctx`: tasks, done, total, next, late, people, head, after); the board's mark: `ogc_committee_look`.
- **Local samples (OGC_DEV only):** made-up "First L." people on every 2026 and 2027 committee (`ogc_app_seed_people`; Ada Turner heads Lodging, Hannah Cole helps Food, Levi Stone is on A/V and Ushers), 2026's notes and A/V's report, past tasks done.

### Routes (`/wp-json/ogc/v1/app/…`; `?c=` is a committee key, `?as=` see-as)

| Route | Who | What |
|---|---|---|
| `GET {y}/boot` | anyone who may open the year | year, years (switcher), conference (label, dates, phase), viewer, screens, committees, people (names the viewer may see: everyone for the COA and committees, the COA for webmasters), questions, logout |
| `GET {y}/home` | all | headline, fact, needs, coming (collapsed across committees), last (last year's notes), activity (`ogc_app_activity`, by viewer) |
| `GET {y}/committees` | all | `view`: board (COA: line, look, done/total, people, head) · directory (committees: duties, people names, own first) · structure (webmasters: counts) |
| `POST {y}/committees` `{name, duties}` | COA | add |
| `GET {y}/committee?c=` | all | `access`: full (COA, its people: tasks, files, notes, last notes, report, last report, past years, handable screens) · directory · structure |
| `PATCH {y}/committee?c=` `{name?, duties?, sort?}` (COA) `{link?, checked?}` (its people) · `DELETE` (COA, empty only) | | |
| `GET {y}/committee/past?c=&from=` | the COA, its people, webmasters | a past year read-only, no names |
| `POST {y}/committee/notes?c=` · `PATCH /notes/{id}` `{done}` (next year's committee) · `DELETE /notes/{id}` | its people, COA | |
| `PUT {y}/committee/report?c=` `{answers[], send?}` | its people, COA | saves as typed; `send` marks it sent |
| `POST {y}/committee/files?c=` (multipart `file`) · `GET /files/{id}?_wpnonce=` · `DELETE /files/{id}` | its people, COA | |
| `GET {y}/tasks?view=mine\|committee\|all` · `POST {y}/tasks?c=` · `PATCH /tasks/{id}` `{title, note, date, offset, owner, done, committee (COA)}` · `DELETE` | all to read their scope; writes: its people, COA | |
| `POST {y}/message` `{to: 'member:ID'\|'committee:KEY', subject, body}` | members (webmasters: the COA only) | email `app_message` through the site, Reply-To the sender; no address returned; 20 an hour, 60 a day |
| `POST {y}/hand` `{screen, c}` | COA | hand a screen (`c: ''` takes it back) |

Rows by id answer 404 to anyone who may not see them. Every write is logged (`app_*` actions, detail `{ckey, title}`, never personal data).

### What needs whom (`includes/module-app-needs.php`, polish round 1)

- **Needs** (`ogc_app_needs( $year, $viewer )`): Home's headline is the first, its one button that need's act; the rest are "Also needs you". Each screen's work adds its own: `add_filter( 'ogc_app_needs', fn( $rows, $year, $ckey, $ctx ) … )` (`$ckey` is a committee key, or `coa` for the COA's screens; `$ctx`: today, phase, viewer). A row: `key, words, why, go {s, c, v, id, at}, button, tone (late|look), due, rank (0 late · 1 first steps · 2 now · 3 by date), kind`. Tasks due within 14 days (the COA's 30) join unless a need of the same `kind` already says it. The weekly note (`app_weekly`, Mondays from 7 AM, every member of the committee, on unless the COA turns it off: `committees.csv` `weekly`) is the same needs. `GET|PUT {y}/weekly?c=`.
- **Task kinds** (`ogc_tasks.kind`; `ogc_app_task_kinds()`, filter `ogc_app_task_kinds`): a task tied to its screen and to what marks it done — `requests_answer`, `requests_sent`, `meals_sent`, `reg_open`, `reg_tell`, `announce`, `schedule`, `signups_open`, `rooms_published`. It ticks itself (`auto`: "Done · from Meal counts · May 12"), takes a setting's date where one decides it (Registration opens = `registration.opens`), and moves with its screen when the COA hands it on. Added tasks have none.
- **Seasons** (`ogc_app_screen_opens( $year )`, filter of the same name): when a screen comes into season. Before, the sidebar shows it after the rest, quietly, with its date; work already there (a registration) puts it in season.
- **Previews:** a read of any `app/…` route may carry `?as_of=YYYY-MM-DD` (the shell passes `?as-of=` from the address); a change with it is refused. `ogc_app_today( $year )` is the date everything in the app counts from.
- `POST {y}/seen {screen}` → `{was}`: when this person last opened a screen (Households' New view).
- Invites land in the app (filter `ogc_member_landing_pre`) and say what the person can open (`ogc_member_access`).
- **Polish round 2 (Oct 11):** the ranking is work due within 14 days → late work done on a screen → first steps (rank 1) → dated within 30 days → waiting now (rank 2) → the rest; a need with `manual` (a task with no screen) never takes the headline (upcoming: "Next: …"; past: asked once, `ask` = task id, Done · Not yet → `POST {y}/later {id}`, lapses after 14 days; two or more are one line). A need may carry `op` (`remind:requests`) instead of a link. `POST {y}/remind {what: 'requests', c?}` (the COA): each committee with requests left, its head gets its weekly email now (once a day a committee). `GET|PUT {y}/phones {id, phone}`: the COA's phones for people on the year (state `app-phones`, the COA only). Home's `first` is the COA's first-visit line (`seen` home). Activity is by day, merged, without your own actions.
- **Only what's true:** `ogc_records` (core-store) is filtered (`ogc_records` filter): a **sample** record dated after today (`data.created`, else `data.at`) isn't counted anywhere; a signed-in GET with `?as_of=` counts as of that day. The invite's first job: filter `ogc_member_first` (the app: the soonest undone task done on a screen).
- **Start before the last year is over** carries only what repeats (committees, responsibilities, seeded/carried tasks; state `app-carry.partial`); its files and the undone tasks it added follow once it's over (`ogc_app_carry_rest`).

### The COA's screens (`includes/module-coa-app.php`, `assets/app/screens/coa-*.js`, `coa.css`)

Dates and place (`dates`), Campus (`campus`: `?v=halls|nearby|pins`), Schedule (`schedule`: `?v=<day>|check|live|all`, `?at=grid` Day view, `?id=` a row), Requests (`requests`: who `coa` + `committee`; `?c=` a committee), Registration, Money, Packet (`?v=menus`), Help and notices (`help`: `?v=notices|numbers`), and the webmasters' Years (replaces the frame's). Shared helpers are `window.OGC_COA` (`coa-kit.js`): `K.load(y)` (bundle + `coa/{y}`), `K.rows(y, name, d)` (one `ED.Rows` per file per visit), `K.status`, `K.textIn` / `K.dateIn` / `K.pills` / `K.field` / `K.facts` / `K.section` / `K.link`, `K.looks` ("From 2026 · Looks right"), `K.confirm(sp, …)` (a decision in the record panel), `K.undoKeys`, `K.replay`.

- `/annual-conference/year/…` and `/admin/…` redirect to the matching screen (`ogc_coa_app_landing`).
- **Who may change what:** members not on the COA change the COA's files and settings keys, and act on `coa/{y}/…`, only through a screen handed to their committee (`ogc_coa_app_may`); a committee reads and answers only its own requests. Webmasters always pass.
- **The published copy:** once a part is public, visitors read state `live_<file>` (schedule, changes, guide, menus), taken at Publish (`coa/{y}/publish` acts `publish` and `update`; action `ogc_coa_published`). Members read the working copy.
- Routes: `GET app/{y}/live?f=schedule,guide` → `{file: {public, at, by, added[], changed[], removed[]}}` (Schedule, Packet); `GET app/{y}/public?f=help,notices` → `{file: {public, rows}}` as a visitor would get it; `GET app/{y}/money` → totals, no names (`viewer`: may see each payment through `lists/{y}/payments`; `choose`: names the treasurer).
- `ogc_ed_files` (filter): files kept row by row by `years/{y}/rows/{name}` (the screens add `guide`, `menus`). Notices carry `draft` (never sent to visitors).

### The committees' screens (app-committees, Oct 11)

`includes/module-app-committees.php` (the rules, the old pages' redirects, Lodging's households route, status lines) and `assets/app/screens/committee-*.js` + `committee.css` (the drawing). Shared pieces: `window.OGC_CK` (`committee-kit.js`: `bundle`, `days`, `md`/`day`/`at`, `download`, `fetchFile`, `print`, `find`, `steps`, `seg`, `pills`, `more`, `icon`, `iconBtn`) and `OGC_APP.committeeWork` (a committee's page lists its screens with a line each: `GET app/{y}/work?c=`).

| Screen id | Title | Who | Data |
|---|---|---|---|
| `lod-households`, `lod-rooms`, `lod-checkin` (`?v=desk\|setup\|counts`), `lod-yf`, `lod-campers`, `lod-import` | Lodging's | `lodging` | `GET years/{y}/lodging?hh=1` (the board plus the households as Lodging needs them: `ogc_appc_lod_households`, no emails, money only as owed), `POST …/lodging/ops`, `/undo`, `/publish`, `/import` (module-lodging*.php) |
| `food-meals`, `food-menus` | Meal counts, Menus | `food` | `lists/{y}/meals`, `/meals/send`, `/settings`; menus.csv through the files route |
| `preteens-list` | Children | `preteens` | `lists/{y}/preteens` (children's details: the COA and Preteens, `ogc_reg_sensitive_viewer` filter) |
| `communion-list` | Communing | `communion` | `lists/{y}/communion` |
| `yf-teams` | Teams | `young folks` | `tn/{y}/teams`, `/add`, `/message`, `tn/r/{id}…`; settings `tournaments_online`, `tournaments_how` |
| `helpers` | Helpers | every committee whose key matches a shift committee (`ogc_appc_shift_keys`) | `vol/{y}/lead…` (`?committee=` the shift committee's name) |

- Each screen is `coa_opens`: the COA may open it (committee page, ⌘K) without it joining the COA's sidebar (`ogc_app_can_see`). Webmasters only by See as.
- Every route above asks `ogc_appc_can( $req, $screen )`: the screen's rule with `?as=`, and a change refused while seeing as (403 `ogc_read_only`) or with `as_of` (403 `ogc_preview`). Lodging's routes through `ogc_lod_can`; the lists', tournaments' and heads' routes through a `rest_request_before_callbacks` guard; the heads' scope through `ogc_vol_lead_all()` / `ogc_appc_vol_scope()`.
- The old pages redirect into the app (302): `/lodging/` (`?view=` → the screen), `/lists/` meals·communion·preteens (payments and call-in stay on `/lists/`), `/volunteer/?view=lead` (`&committee=` → `c`), `/tournaments/?view=teams`.
- `?as-of=YYYY-MM-DD` in the app's address previews a date on Lodging's and the lists' screens (reads only).

## Testing

- **`node tools/e2e.mjs`** (integration, Oct 11): the whole plugin end to end, each person in their own headless Chrome profile, signed in only by the links and codes the Mail log keeps (the webmaster alone uses the dev sign-in). `ONLY=a,c` runs some parts; `SHOTS=dir` (default `.wp-local/shots/e2e/`). About 25 minutes on one worker. It changes the site's data (people invited, a registration, rooms published; the schedule row it publishes is put back); `tools/wp-local.sh reset` before it gives a clean run. Parts:
  - **a** a webmaster invites a COA member (app › Members) → the Mail log's link signs them in → they add a Lodging head → the head's link opens only Lodging's screens and the directory → the board shows Lodging's line → the COA renames a Saturday row and Publishes → a signed-out phone sees it on the Conference page and in the guide;
  - **b** a new volunteer joins, confirms by the emailed link → the public count drops and shows "First L." with no email or phone → the head's Helpers list has name and phone → Can't make it (the day before, `X-OGC-Now`) frees the place and mails the head;
  - **c** the Hoovers Reuse 2026 and register by check (previewing Mar 1, 2027) → Your sign-ups in another profile after a code from the Mail log → Lodging imports the sample Form export, assigns all, publishes → the household sees its rooms;
  - **d** a stranger and a signed-in non-member: no records, file writes, members' data or unpublished parts;
  - **e** the guide offline after one visit (the site is stopped, then started again);
  - **f** every public route and every screen each person's boot lists, at 390 and 1280: no console error, failed request or sideways scroll.

- `tools/smoke.sh` (main site, or `PORT=…`; `SHOTS=dir` for screenshots) checks:
  - every route answers, and the back end (the app, and the old pages through it) sends a visitor to sign-in;
  - each page at 390 and 1280 with no console error, failed request or sideways scroll;
  - the files route is CSV, and private files read empty;
  - unauthenticated writes are refused;
  - a member's change round-trips to a visitor's Conference page, a stale version gets 409, and another year gets 403;
  - a signed-in person's own sign-up (through `vol/{y}/join` and `leave`) is kept across a reload and left, while a sign-up through the generic records route and everyone's records get 403;
  - the app's Sign out ends the session.
- `node tools/browse.mjs <url> <steps.json | - | '[…]'>` drives headless Chrome step by step: `nav`, `eval` (with `out`), `assert`, `click`, `type`, `key`, `wait`, `waitFor`, `shot` (with `sel`), `pdf`, `viewport`.
  - Env: `W`, `H`, `DPR`, `MOBILE`, `PROFILE` (cookies kept between runs: sign in once with the dev sign-in, then reuse the folder), `STRICT=1`, `KEEPGOING=1`, `QUIET=1`, `CONSOLE=1`.
  - It prints exceptions, console errors and failed requests (≥ 400). The exit code is non-zero on an exception or a failed step, and also on console errors and failed requests with `STRICT=1`.
- Phone screenshots: `W=390 H=844 node tools/browse.mjs <url> '[{"shot":"out.png"}]'`.
