# ogc-conference: working on the plugin

The Annual Conference plugin for ogbbc.org: v3's pages (`v3/`), served by WordPress from the plugin's own tables. The plan and its decisions are in `docs/21-build-plan.md`; what the Advisors asked is in `docs/20-advisors-oct9.md`. CLAUDE.md's design, wording and privacy rules bind everything here.

The foundation (Oct 10) is the skeleton, plus v3's front end copied as it was. The areas below rework each part.

## Run it

Nothing gets installed on the Mac. WordPress Playground runs WordPress 7.1.3 and PHP 8.5 (the CLI's default) inside Node, on SQLite, through `npx -y @wp-playground/cli@3.1.57`.

```sh
tools/wp-local.sh start       # the main site, http://127.0.0.1:9420/annual-conference/
tools/wp-local.sh status
tools/wp-local.sh stop        # stops only the server on this site's port
tools/wp-local.sh reset       # erase and start fresh (the seed loads again)
tools/wp-local.sh php x.php   # run a PHP file inside the site: start it with  require '/wordpress/wp-load.php';
tools/smoke.sh                # the foundation's checks (below)
```

- `start` is idempotent: if the site is already running, it prints the address.
- Env:
  - `PORT` (default 9420)
  - `SITE` (default `.wp-local/main`)
  - `WORKERS` (default 2; area copies use 1)
- What `start` does:
  - mounts `plugin/ogc-conference` and the stand-in theme `plugin/ogbbc-standin`;
  - defines `OGC_DEV` true;
  - sets pretty permalinks and activates the plugin and theme (blueprint at `<site>.blueprint.json`);
  - logs to `<site>.log` and waits until the REST API answers.
- The site's files and its SQLite database stay in `<site>/`, so data survives a restart.
- Every request is a whole WordPress start, about 0.5 s locally. That's why the pages read a year's files in one request (`/bundle`).

**An area's own copy.** Clone the main site, then start the copy on your area's port:

```sh
tools/wp-local.sh clone volunteer
PORT=9437 SITE=.wp-local/volunteer WORKERS=1 tools/wp-local.sh start
```

**Ports:**

- 9420 is the main site, the integrated one (`tools/e2e.mjs` and `tools/smoke.sh` run against it). Leave it running; areas clone it.
- Areas use 9431–9440, in the order of the list under Areas: conference 9431, map 9432, print 9433, signin 9434, year 9435, editors 9436, volunteer 9437, register 9438, lodging 9439, lists 9440. The app frame: 9441. The COA's screens (app-coa): 9442. The committees' screens (app-committees): 9443.
- Stop only your own port.

### Signing in locally

These work only with `OGC_DEV` on a local address (127.0.0.1, localhost, `*.localhost`, `*.test`). They don't exist on ogbbc.org or on a staging copy.

| Who | How |
|---|---|
| Anyone, by email | `/annual-conference/dev-signin/?email=ruth@example.com&return=/annual-conference/register/?year=2027` finds the WordPress user for that email (or makes one) and signs them in. |
| A member of a year | add `&member=2027` (comma for several; `&member=none` removes). Kept in the `ogc_dev_members` option. |
| A webmaster | add `&webmaster=1` (`0` takes it away): the `ogc_manage_all` capability (`OGC_CAP_WEBMASTER`). |
| A display name | `&name=Sarah%20C.` for a new user. |
| Sign out | `/annual-conference/dev-signout/?return=/annual-conference/` |
| wp-admin | `admin` / `password` (Playground's default, local only). |

- The **Tour** (bottom right, local and the shared prototype only: `assets/shared/ogc-dev-nav.js`, Oct 13) replaced the Pages button: nine scenes with Back · Next, each signing in the right made-up person on the date that fills its screen; **Scenes** lists them, **See as** (Visitor, Household, COA, Lodging, Webmaster), the old list's other stops under More pages (local only) and **Start over** (clears this browser's `ogc*` keys; for a webmaster on the local site, also reloads the seed). Locally it starts as a pill (`?pages=1` opens it). Open, it is two lines (after the ninth critic, Oct 16): on a phone the scene's number and title with ‹ › Scenes ×, then the caption on one line (whole under Scenes, with Back to this scene and Through the year); on a laptop, where the margin can't hold the whole card, a strip as tall as the closed one (57 px) with Back · Next (Next outlined: the Tour has no filled button of its own), Scenes and ×; on a page with a bar of its own at its foot (the guide's tabs, Your week's), the open strip sits on that bar. At rest the pill moves up off any button, count or phone number it would cover (after the fifth critic, Oct 15). On a laptop it rests in the page's margin beside the column (measured by its words, controls and boxes) or in a strip the page reserves at its foot, never over content; the app's sidebar and a record's panel end above the strip (after the eighth critic, Oct 16). A thin "Early prototype" banner tops every page. `NOTES/early-link.md` has the scenes and the prototype's sample data (`PROTOTYPE=1 tools/wp-local.sh start` to see them; `tools/build-prototype.sh` builds the package).
- **No email is ever sent locally.** `wp_mail` is stopped, and each message is noted in the change log as `mail_dev`. The signin area's Mail log takes over before that.
- **The tests tidy after themselves** (after the critic, Oct 14): `POST /wp-json/ogc/v1/dev/tidy` (webmasters, local only, core-dev.php) takes `{mark: true}` → `{mark}` (the change log's last id), then `{since, actions: ['app_hand', …]}` (those actions' lines after the mark; only actions a test performs) and `{emails: ['e2e.….@example.com']}` (those members, `e2e.*@example.com` only, and every change-log line about them). `tools/smoke.sh` takes out its Registration hand lines; `tools/e2e.mjs`'s put back its members and their invited, signed-in and removed lines, so Home's Activity keeps no test lines. The Mail log's copies of test emails, the e2e WordPress users and See as lines (Privacy) stay.
- **The sign-in page has "Dev · Sign in as" pills** (COA chair, Helper, Webmaster, A household, A volunteer, Mail log). The made-up members are in `seed/members.json`.
- **The Mail log** is `/annual-conference/mail/` (webmasters; local, or a staging copy with `OGC_MAIL_CAPTURE`): every email kept, readable at 390 or 600, with links that work (open a sign-in link there to sign in as that person). `?preview=all` draws every kind in the set.

## Sign-in, members and email (signin area)

**Sign-in** (`module-auth.php`, `templates/signin.php`): one page, `/annual-conference/signin/`, for everyone. Type an email → **Send code** → **Check your email** (a 6-digit code, or the link in the email). Your sign-ups (`register/?view=mine` and `?view=receipt`) sends anyone not signed in here first (302, `?return=` encoded), so there is one door with one set of words.

- Tokens: 32 random bytes, kept only as HMAC-SHA256 with `wp_salt`, single use, 30 minutes (invites, confirmations: 7 days). A code works only in the browser that asked (cookie `ogc_req`), 5 tries a code ("Code not valid · 3 tries left"), each try counted in one `UPDATE … WHERE tries < 5` before the hash is compared. Resend keeps that browser's three newest codes for the address working (mail comes out of order); a code another device asked for is never touched. No code is made at all for an address that may not sign in this way (unknown, or an editor's).
- **Wrong codes:** from a device that has never signed in as the address, 10 a day, the same for every address, turn codes off for 24 hours on such devices ("Too many tries · Send a new code", the same words for every address, known or not); every open code for the address ends and the address gets `codes_off` once. The person's own devices (user meta `ogc_devices`) keep getting codes. Webmasters get codes like everyone; whether they should (or use a device-bound link, or wp-login's two-step) is questions-signin Q5, for the Nov 6 security plan.
- **The code and the link are separate:** the email's link, opened on another device than the one that asked (the phone, while the laptop waits), signs that device in and keeps the code good on the asking one (a new row holding the same code, `data.cth`), whose Check your email then says "Signed in on another device · Code still works here". The email's button reads "Sign in on this device".
- **A link for the person already signed in here** (an invite on a phone signed in since registration; Confirm it's you's own link) is spent at once and starts a fresh sign-in, so a members' page doesn't ask again. No tap: a mail scanner has no sign-in there.
- **Counting** (`ogc_throttle`): table `ogc_hits`, one row a counted try (insert, then count; a request over the limit takes its row back out), never transients.
- **Send limits:** per address *and* device (cookie `ogc_device`): 1 a minute, 3 per 15 minutes, 10 a day. Per address across devices: 15 a day, skipped on a device that has signed in as that address before (user meta `ogc_devices`, the last ten), so a script can't lock the real person out. Per IP: 300 an hour (`ogc_signin_ip_per_hour`; the campus Wi-Fi). Over a limit: "Too many codes · Try in 14 min" (waits are relative, never a clock in another time zone).
- **Same-site only:** `auth/send`, `auth/code` and the page's own POSTs need `Sec-Fetch-Site: same-origin`, or (older browsers) a matching Origin or Referer; a request with none is refused (`ogc_same_origin_strict()`). This guards against other sites (CSRF) only: a script that forges the headers passes it, and the limits above are what hold scripts back. A link card's POSTs (Origin `null`, no referrer) must carry the card's landing cookie back (`ogc_land` = field `k`).
- **The same answer for every address.** Mail goes after the response: a known address gets `signin`; an unknown one gets `no_signups` (fixed words: Register, Volunteer, "Sign in with another email"), at most once a day; an editor or admin's gets `signin_wplogin`. Nothing typed goes into either, so it isn't a relay.
- A link's GET (`?t=`) puts the token in a 15-minute cookie (`ogc_lt`) and 303s to `?confirm=1`, so the token is never in the address bar, history or an analytics script's page address. That page is the card (whose sign-in + one button; an invite says "Nathan K. added you", its Role and "Open 2027"; "Signed in as r***@… on this device" when someone else is); the token is spent on the POST, then a 303 to a clean address. Expired, used and tampered links have their own cards, with **Send new code** where it can. Check your email reopened after 30 minutes shows the form again with the address filled in and "Code expired".
- `?return=` is a path under `/annual-conference/` only (encode it: `ogc_url()` doesn't). The heading then names it ("Your sign-ups", "Lodging", "Members": `ogc_signin_dest_label()`). With none: webmasters land on the webmasters' page; a member on their year (their committee's page when "Helps with" names one: `ogc_member_landing`); a member of two years on the sooner Conference (the other is "Open 2028" beside the account mark); everyone else on Your sign-ups.
- Links and codes sign in only users whose roles are `ogc_person` or `subscriber`; editors and admins use wp-login. The plugin's people get no wp-admin, admin bar, password reset, application passwords or WordPress account emails, and can't sign in with a password.
- A sign-in lasts a year on a device; **Shared device** is a setting of the device (cookie `ogc_shared`, a year), off by default: every sign-in on that browser then ends when it closes, at most 4 hours. Its switch is on Check your email (a POST, `ogc_do=shared`) and in the account menu (`OGC_WP.sharedUrl`, `?shared=1` + nonce; `?shared=0` turns it off and restores the year). `OGC_WP.sharedDevice` is true while it's on. Your sign-ups shows the same account control as every page (`.rf-who` is replaced by it); someone without a full name sees "Sign out" in words beside the mark. Members' pages ask for a code again after 30 days: over an open page, the Confirm it's you dialog (a REST 401 `ogc_reauth`); opening a members' page, that page's own frame (page `reauth`, `templates/signin-reauth.php`, 403) with the same dialog, which reloads the page once confirmed. The dialog also resolves when the email's link is opened in another tab: it listens for the `ogc-signed-in` storage event and checks on focus with `GET /annual-conference/signin/?session=1` (same site only; `{email, fresh, nonce}`). Added webmasters: 7 days.
- **No access** (`refused`): the address, "Not you? Sign out", what's true ("Access ended Sep 1", "Removed Oct 9"), then **Ask for access** only for someone who had a row for that year; for anyone else **Your sign-ups** is the one button.
- Sign out: `OGC_WP.logout` → "Signed out". `OGC_WP.signoutAll` ends every other session.
- REST: `POST auth/send {email, return?}` → `{sent, email}` (429 with `until` and "Too many codes · Try in 14 min"); `POST auth/code {code}` → `{ok, go, nonce}` (400 `ogc_code_bad` with `left`, `ogc_code_tries`, `ogc_code_gone`).
- PHP: `ogc_signin_request()`, `ogc_signin_code()`, `ogc_auth_sign_in_user( $user, $remember, $how )`, `ogc_signin_link_for( $email, $return, $kind )`, `ogc_mine_url( $email, $year )`, `ogc_token_create()` and the `ogc_token_kinds` filter, `ogc_email_confirmed( $email )`, `ogc_safe_return()`, `ogc_landing_for( $user_id )`, `ogc_wait_words( $until )`, `ogc_email_wbr( $email )`. Action `ogc_signed_in( $user_id, $row, &$go )`.
- **A device's own records:** someone who typed an email but hasn't confirmed it may create the kinds in `ogc_anon_kinds`, and this device (cookie `ogc_device`) may see, change and leave only what it made. Records linked to a second email (`ogc_record_link_add( $id, $email, 'helper'|'parent' )`) are that person's too; a helper may change, a parent only see.
- `window.OGC_AUTH`: `signinUrl( ret )`, `notYouUrl( ret )`, `reauth()`, `suggest( email )` ("ruth@gmail.com" for "ruth@gmial.com"). The account mark is drawn by `assets/signin/ogc-account.js` at the end of every `.ws-bar__in`.
- **The dev sign-in and its pills** exist only with `OGC_DEV` **and** a local address (127.0.0.1, localhost, `*.localhost`, `*.test`: `ogc_is_local_host()` in core-dev.php). It sets `ogc_last_signin` like every other sign-in.
- **For Corey's staging copy:** define `OGC_MAIL_CAPTURE` (mail is kept in the Mail log, never sent) and `OGC_MAIL_ALLOW` with the testers: `define( 'OGC_MAIL_ALLOW', 'chair@example.org, @coa-testers.org' );` (addresses, or `@domain`). Testers' mail really goes ("Sent (allowed)" in the log), so the COA can sign in during Nov 7–20. On any address that isn't local, the Mail log keeps no sign-in or confirm words at all and every one-time link reads `?t=link-removed` (a webmaster reading it can't sign in as anyone). Sign-in and confirm emails are tried once: never queued or retried; a failure blanks the row and logs Failed.
- **For Corey's review:** check any plugin that syncs WordPress users (a newsletter's "WordPress Users" list, MailPoet and the like): every household that signs in is a WordPress user (role `ogc_person`), so exclude that role. If Nexcess serves PHP through LiteSpeed, `litespeed_finish_request()` is used (so a known address doesn't answer slower than an unknown one).

**Members** (`module-members.php`, table `ogc_members`: year, email, role `coa`|`helper`, name, **committees** (keys, comma-separated), **head**, helps (a label in the COA's words), invited_by, invited_at, signed_in_at, access_years, expires_at, removed_at…). `ogc_is_member` reads it on every request. Access: helpers 1 year after the Conference's last day, the COA 2 (`ogc_member_default_years`); webmasters choose 1–3.

- **Committees** come from the year's list the COA writes (`committees.csv`, carried to next year by the pickup); with none kept yet, the names the year's requests and shifts use (`ogc_members_committee_list( $year )` → key → name). "New committee" in Invite or Edit adds a row to `committees.csv`. **For the app area:** `ogc_member_committees( $year, $email )` → the keys someone's screens follow (empty for the COA, who see everything); `ogc_member_role_words( $m )` ("Lodging · Head"); filter `ogc_committee_screens( '', $year, $key )` → the screens' names in words, which the invite then says. Screens are gated by committee in the app (`ogc_app_can_see`; DEV.md › App), and every committee route asks the same rule.

| Route | Who may | What |
|---|---|---|
| `GET /years/{y}/members` | members of y, webmasters | `{year, dates, signin, page (the Members page), viewer: {webmaster, coa, invite, roles}, until: {coa, helper} (the date most of each shares), years: {coa, helper}, committees: [{key, name}], landings: {committee key: "Lodging"}, members: [...]}`. Every row: `{id, name, role, helps, committees: [keys], committee (the first's name), head, state (active\|invited\|expired), until, expired, ending, removed, you, can}`. For those who may invite (and a person's own row), also `email, invited ("today", "yesterday", "Oct 6"), signed_in, invite_expired, suspect (a never-used address that looks mistyped: the likely fix), by`; `can.email` while the row has never signed in. A helper sees others' names (or a masked address), committee and the coarse `state` only. |
| `POST /years/{y}/members` `{emails, role?, years?, committees?: [keys], new_committee?, head?, helps?, typos_ok?}` | the year's COA (helpers only); webmasters (any role; years 1–3, 0 = the role's default) | invite. `emails` is text as pasted: lines, commas, semicolons, "Name <email>", Outlook's "Last, First <email>", a spreadsheet's name and email columns. Each new person gets their own invite (a one-use link, 7 days); more than 5 at once go through the mail queue. → `{added: [ids], already: [ids], bad: [text], list}`. Up to 40 at once, 60 an hour (the old `coa/{y}/members` POST goes through this route too). **A likely typo** in a common domain ("gmial.com", `ogc_email_suggest()`) is refused once: 409 `ogc_typo` `{message: "Check x@gmial.com · Did you mean gmail.com? · Invite again to send as typed", data: {suspect: [{email, fix}]}}`, nothing added. Sending the same address again within 15 minutes, or `typos_ok: true` (after the page has asked), goes ahead. Show `message` at the field. |
| `PATCH /members/{id}` `{name?, email?, committees?, new_committee?, head?, helps?, role?, renew?, restore?, typos_ok?}` | name: the COA, webmasters, the person; committees, head, helps: the COA, webmasters; email: the COA for helpers, webmasters, only while the row has never signed in; role: webmasters; renew: the COA for helpers, webmasters; restore: undo a removal within the hour | → `{member, list}`. The last COA member can't be made a helper. A new email ends the old address's open invite, sends the new one its own, and is logged ("Nathan K. changed Esther H.'s address"); a likely typo is refused once (409 `ogc_typo`) unless `typos_ok`. |
| `DELETE /members/{id}` | the COA for helpers (never themselves); webmasters (the last COA member too) | access ends now; their unused invite links for the year end. Their sign-in stays (their household's Your sign-ups still opens). → `{removed, id, list}` |
| `POST /members/{id}/resend` | the COA, webmasters | a new invite link (once a minute; 429 "Sent · Just now") |
| `GET /years/{y}/members/history` | those who may invite: the year's COA, webmasters | `[{at, words, n}]`: "Nathan K. invited Joel M." (the name as it was when written), a time for today's lines, the same line on the same day once with `n`. |
| `GET /years/{y}/members/preview?role=&years=&committees[]=&new_committee=&head=` | the year's COA, webmasters | the invite exactly as sent, by the invite's own rule (a webmaster's years, else the role's default): `{from, subject, html, text}` |

- **The Members component** (`assets/signin/ogc-members.js`, `OGC_MEMBERS.mount( el, year )`, or any `data-ogc-members="2027"`; add `data-om-full` for the whole list), one component with two layouts. Narrow (a phone, the year page's column): Invite first (chips, then Committee pills + New committee + Head), then COA and each committee, each with its own end date under its label, one line a person with one status; a row opens to its address, committee and actions; Edit replaces the actions with the form. When the card is 860 px or wider and the viewer may invite: a table (Name · Email · Committee · Status · Invited by · Until; a column with nothing in it isn't drawn) with the card's whole width; choosing a row opens its panel beside it (Edit, Resend, Renew, Remove; Close), and Invited by and Until give way while it's open, so nothing scrolls or is cut off at 1180–1440. A helper gets the list as a directory at every width, their own committee first. `?open=<id>` opens a row. Committee pills are A–Z, "One or more"; Head is its own switch ("Head of committee") once a committee is picked. On the year page and the webmasters' page a list longer than 8 is a summary ("14 members · 8 not signed in") and **Manage**, which opens the **Members page**, `/annual-conference/members/?year=2027` (`templates/signin-members.php`). The webmasters' page mounts it too (`admin-web.js` `membersCard()`).
- The year area's first routes (`coa/{y}/members`, `…/resend`, `…/remove`, `…/set`) answer from this list, in their old shape.
- `access_ending` goes 14 days before access ends, only to COA members and helpers who signed in within the last 90 days.
- **Handles money** (decision 4, Oct 13): `PATCH /members/{id}` `{money: true|false, own_email?}`, the year's COA only (never a webmaster for being one), never on one's own row (403; untick is fine). The first tick answers 409 `ogc_own_email` ("Only this person reads this email?") until sent again with `own_email: true`; logged `member_money_on`/`_off`. Each row carries `money` and `can.money`; `viewer.money` says who may tick. Kept as the year's `payment_viewers` list, the same one the Money screen's Choose treasurer writes (the older `money_people` is read as the same tick): `ogc_member_money_emails()`, `ogc_member_handles_money( $year, $email )`, `ogc_member_set_money()`.
- **Webmasters:** site admins, and anyone given `ogc_manage_all`. **One rule, wherever it's asked** (the webmasters' page's REST `webmasters`, `webmasters/confirm`, and **Settings › Conference webmasters** in wp-admin): one webmaster asks to add or remove, a second confirms (`ogc_webmaster_ask`, `ogc_webmaster_confirm`, `ogc_webmaster_cancel`); while there's only one webmaster, their ask goes ahead. Adding sends `webmaster` from the one who asked (Reply-To them). Site admins can't be removed there. One list for both screens: `ogc_webmasters_payload()` (names as "First L.", never a login; last sign-in from `ogc_last_signin()`). `ogc_webmasters()` reads by capability (`capability__in`), never "the first 500 users". Settings › Conference webmasters also holds "Replies to", the webmasters' role address.

**Email** (`module-mail.php`, `module-mail-templates.php`, table `ogc_mail`):

- `ogc_mail_send_kind( $kind, $to, $data, $context )`: a designed email from the set. `ogc_mail_template( $kind, $data )` → `{subject, html, text}`.
- `ogc_send_mail( $to, $subject, $html_or_text, $context )`: one message to each address (never To/CC lists). Context: `kind`, `year`, `text`, `reply_to`, `ics` + `ics_name`, `delay`, `coalesce`, `queue`.
- `ogc_send_mail_many( $items )`: over 20 go through the queue (WP-Cron, 25 at a time); `GET mail/batches/{id}` → `{sent, failed, queued, total}`.
- An address nobody has proved gets at most 6 an hour and 20 a day of anything but sign-in codes: past the hour's 6 a message waits an hour and a later one of the same kind takes its place; past the day's 20 it's refused ("Refused · limit" in the Mail log, `mail_refused` in Activity). Never capped (`ogc_mail_cap_exempt`): members and webmasters (context `to_member`), role addresses (`contact_*` settings, committees' `contact_email`, Replies to), and the signed-in person's own address.
- **A parent's approval** sent any way but the set's `parent_approval` is rebuilt from the set in `ogc_send_mail` (only its link kept; logged `mail_guarded`): it goes to an address a teenager typed, so it names no one.
- `tools/check-mail.php` (`tools/wp-local.sh php tools/check-mail.php`) checks every kind (subject = heading, no "!", no "Lord willing", the parent's approval names no one) and lists every place that builds its own email instead of using `ogc_mail_send_kind` (exit 1). On ogbbc.org only who, what kind, when and Sent/Failed are kept, 60 days.
- From "ogbbc.org Annual Conference" `<conference@…>` (filter `ogc_mail_from`).
- The layout: headings bold; **the subject is the heading**, word for word; sign-in emails name no year. One exception: a registration's own emails also name the year and its number around the heading ("2027 Annual Conference · Registered · R-2027-0014"), so an inbox keeps a household's years apart (`tools/check-mail.php` allows it for `registration_received`). Under the one button, the page it ends on (for a one-time link, its return page, or just the site when it has none; a template may give a third button part to say it), never `/signin` or a token. The footer gives a reason only when no line above already says it.
- Kinds and their data (all take `year`; times as `day` + `start` + `end`, or `when`; names are cleaned):

| Kind | Data |
|---|---|
| `signin` | code (empty: a link-only email, which says "Open the link on the device you're signing in on"), url, codes_off. Subject "Sign-in code" for everyone (no code, no year in a subject). Button "Sign in on this device". |
| `no_signups` | members_page, return. Offers only what's open now: Register while registration is open on the site, Volunteer once sign-ups are posted, else Sign in with another email. From a members' page: "Not on the 2027 members list". |
| `signin_wplogin`, `codes_off` | (none). `codes_off`: "Codes off · 24 hours", what still works. |
| `invite` | by_name (or by_webmaster: "A webmaster added you"), role, committee_words ("Lodging (Head)": `ogc_member_committee_words`), open_label ("Open Lodging", "Open 2027" for the COA: `ogc_member_open_label`), access (default "Every 2027 page and list", true today for helpers too), landing_url, until, url, reply_by. Subject and heading "Nathan K. added you"; the year is the line above. Reply-To the inviter (context `reply_to`). |
| `webmaster` | by_name, url, reply_by. Subject "Caleb J. added you · Conference webmasters"; Reply-To the one who asked. |
| `access_ending` | until, role, committee_words, open_label, url (their landing). A helper's names their committee and page; the COA's says to hand over. |
| `access_asked` | name, email, was, url |
| `registration_received` | rec (a registration record): drawn by the registration area's own builder, `ogc_reg_mail_receipt_parts()` + `ogc_reg_mail_render()` (module-registration-mail.php), the same email it sends: the number and the Conference's dates and place, Who's coming, The stay (nights, each Young Folk's hall, "Rooms · On Your sign-ups once posted", check-in and check-out), Charges, what's owed and how to pay, Your sign-ups. Never a room number. Without rec, the older flat data still draws: household, id, people, nights, rooms, total, method (card\|check), paid, payee, address, closes |
| `registration_changed` | household, id, changes [[label, before, after]], difference |
| `registered_for_you` | by_name, id, nights, total |
| `parent_approval` | approve_url, again ("Reminder · Approval needed"). The email names no one: "For a Young Folk's registration". |
| `payment_received` | id, amount, method, due |
| `credit_asked` / `credit_given` | id, nights, amount, by / how |
| `rooms_posted` / `rooms_changed` | checkin (never the rooms themselves) |
| `signed_up` | title, day, start, end, place, committee, note, notme_url, has_ics; or shifts [[title, when, place, name]…] gathered in one email; confirm_url + confirm_hours (a first-time volunteer's place); by (a head signed them up) |
| `reminder` | title, day, start, end, place, note, map_url, leave_url ("Can't make it? Leave shift"; falls back to Your sign-ups) |
| `shift_changed` | title, before, after; who (the address's people on it, named), reason (why it came: the volunteer area's `ogc_vol_addr()`) |
| `shift_removed`, `you_left` | title, day, start, end, join_url; `shift_removed` also who, reason |
| `volunteer_left` | name, title, day…, open, needed, committee, list_url |
| `spot_open` | title, day…, place, join_url, leave_url; who ("For: Wren and Wade Wait": everyone of the address waiting, one email an address) |
| `team_signed_up` | title, team, day…, place |
| `message` | subject, from (a role), about, body (plain), link |
| `weekly` | committee, filled, needed, new, left, open_shifts [[title, when, open]] |
| `confirm_email` | code |
| `email_changed` | new_masked, by |

## The plugin's files

```
ogc-conference.php      header, constants, loads every includes/*.php (core* first, then module*), activation
includes/core.php       helpers: ogc_table, ogc_url, ogc_current_email, ogc_is_webmaster, ogc_is_member, ogc_log, CSV
includes/core-schema.php  tables (ogc_schema filter + dbDelta), activation
includes/core-store.php the data layer: years, files, state, records
includes/core-rest.php  the REST routes and their permission checks
includes/core-pages.php the pages: address, shell, template, assets; OGC_WP; drawing
includes/core-routes.php  rewrite rules, the data addresses, the guide's manifest/sw/icons
includes/core-import.php  the seed importer
includes/core-dev.php   OGC_DEV only: dev sign-in, dev import route, no mail
includes/module-*.php   the areas' modules (an area adds a file; nothing else changes)
templates/*.php         one per page (v3's markup minus the mockup scripts), guide-head/-manifest/-sw
                        (an area's own replaces one through ogc_pages: the volunteer page uses only
                        volunteer-v2.php; volunteer.php is the foundation's v3 copy, unused)
assets/                 v3's front end, same folder layout (shared/, schedule-hub/, year/, …)
seed/                   2025–2027 as v3's pages see them (picked up), made by tools/seed-from-v3.mjs
NOTES/<area>.md         each area's log of changes to shared files
```

**Constants:**

- `OGC_VERSION`
- `OGC_DB_VERSION`
- `OGC_DIR`, `OGC_URL`
- `OGC_DEV` (false unless defined before the plugin loads)
- `OGC_NS` (`ogc/v1`)

**Prefixes:** `ogc_` for PHP functions and options, `OGC_` for constants, `ogc-` for handles, CSS and storage keys.

## Pages

| Address | Page (v3 folder) | Shell | Who |
|---|---|---|---|
| `/annual-conference/` | Conference page (`schedule-hub`) | theme | everyone |
| `/annual-conference/guide/` | the guide (`guide`), plus `manifest.webmanifest`, `sw.js` (scope `/annual-conference/guide/`), `app/<icon>` | bare (`ogc-app`) | everyone |
| `/annual-conference/schedule/` | printed schedule | theme | everyone |
| `/annual-conference/packet/` | the packet | theme | everyone |
| `/annual-conference/register/` | the form, Your sign-ups | theme | everyone |
| `/annual-conference/volunteer/` | volunteer shifts | theme | everyone |
| `/annual-conference/tournaments/` | tournaments | theme | everyone |
| `/annual-conference/app/` | **the back end, one app** (DEV.md › App): Home, Committees, Tasks, the COA's and each committee's screens, Members, Years | bare | members of the year, webmasters |
| `/annual-conference/admin/?edit=shifts:<committee>` · `?edit=tournaments` | the shift and tournament editors (not in the app yet; from Helpers' and Teams' More menus, `return=` back) | bare | members |
| `/annual-conference/year/`, `/admin/` (any other), `/lists/`, `/lodging/`, `/members/`, `/volunteer/?view=lead`, `/tournaments/?view=teams` | **redirect (302) into the app**, to the matching screen (`ogc_coa_app_landing`, module-app-committees.php, module-integration.php); signed out, through sign-in with the app to return to. `/lists/?view=callin` is the one old page still drawn. | | |
| `/annual-conference/signin/` | sign-in, the link card (`?confirm=1`), No access | theme | everyone |
| `/annual-conference/mail/` | Mail log, `?preview=all` every email | bare | webmasters, only where mail is captured (local, or `OGC_MAIL_CAPTURE`); a 404 for anyone else |

**Shells:**

- **theme**: the site's `get_header()` and `get_footer()` around the template. Locally that's the stand-in theme. Theme pages load `shared/ogc-tokens.css` (the colours and the container), never the theme's own base styles.
- **bare**: the plugin writes the whole document and loads `shared/site-shell.css` for the base type.
- Noto Serif comes from Google Fonts on bare pages. The theme brings its own font on theme pages.

**Members' pages:**

- A members' page needs a member of the year in `?year=` (or of any year, if there's no `?year=`). Webmasters may open every page.
- Not signed in: a 302 to `/signin/?return=…`. Signed in but not a member: 403 and the sign-in card. A member whose sign-in on that device is older than 30 days: 403 and the page's own frame with Confirm it's you.
- The filter is `ogc_page_allowed`.

**v3's own addresses still land:** `/annual-conference/schedule-hub/` and any `…/index.html` redirect with 301, keeping the query.

**Changing a page** (from your module, never by editing core-pages.php):

```php
add_filter( 'ogc_pages', function ( $p ) {
	$p['volunteer']['scripts'][] = 'volunteer/extra.js';   // paths relative to assets/
	$p['volunteer']['template']  = 'volunteer-v2.php';      // in templates/
	return $p;
} );
```

- A page's keys:
  - `path`, `folder` (its v3 folder, for links), `shell`, `members`;
  - `title`, `description`, `noindex`, `html_class`;
  - `header` (the stand-in's topbar and crumb hints), `head` (a template printed in `<head>`);
  - `fonts`, `styles`, `scripts`.
- `ogc-wp.js` is always first. `ogc-dev-nav.js` is last, and only with `OGC_DEV`.
- Assets are versioned by their file's time. A logged-in page is never cached (`nocache_headers`, `DONOTCACHEPAGE`).

## Tables

`dbDelta` applies these whenever `OGC_DB_VERSION` or the SQL changes. An area adds its own table through `add_filter( 'ogc_schema', fn( $sql, $charset ) … )` (see core-schema.php).

| Table | Columns | What |
|---|---|---|
| `ogc_years` | year PK, fields (JSON), updated_at | years.csv, one row a Conference |
| `ogc_files` | id, year, name, rows_json, cols, version, updated_by, updated_at; unique (year, name) | a year's parts as the pages read them, already merged. `rows_json`, not `rows`: ROWS is reserved in MySQL 8. `cols` keeps the column order, so a header-only file (contacts) still exists. |
| `ogc_records` | id, year, kind, email (lowercased, indexed), data (JSON), sample, source, created_at, updated_at, deleted_at | what people sign up for, one row each. Delete only sets deleted_at. |
| `ogc_state` | id, year, skey, value (JSON), version, updated_by, updated_at; unique (year, skey) | small values a year keeps (`picked`: the pickup log; Lodging's `rooms`…) |
| `ogc_log` | id, at, user, year, action, target, detail (JSON) | the change log. detail never holds personal data: members' History lines keep the member's id (target `member:ID`) and are named when read. |

## REST routes (`/wp-json/ogc/v1/…`)

WordPress needs the `X-WP-Nonce` (`wp_rest`) header on any request from a signed-in browser: without it, the request is treated as signed out. `OGC_WP.api` sends it every time. Every change is logged.

**Never cached** (core-rest.php, a `rest_post_dispatch` filter): a person's own answers (`records`, `me/`, `rooms/`, `state/`, `log`) and every answer to a member of the year in the address are sent `Cache-Control: private, no-store, max-age=0`, so neither the browser nor the guide's offline copy keeps them. (It was in the map module until Oct 10.)

| Route | Who may | What |
|---|---|---|
| `GET /years` (`?format=csv`) | everyone | years.csv (filter `ogc_years_public`) |
| `PATCH /years/{y}` `{fields:{k:v}}` | members of y; **webmasters only** to start a new year | set a year's fields (`O.edits.setYear`) |
| `GET /years/{y}/bundle` | everyone (each file only if readable) | every file of the year: `{name:{rows,cols,version}}` (how ogc-store.js reads a year) |
| `GET /years/{y}/files` | members | the year's files: versions, row counts |
| `GET /years/{y}/files/{name}` (`?format=json`) | everyone; private files (`needs`, `notes`: filter `ogc_private_files`) members only; an area withholds others with `ogc_file_visible` | CSV text (default), or `{rows, cols, version}`. Unreadable or missing files read as empty (200), so a withheld file can't be told from a missing one. |
| `PUT /years/{y}/files/{name}` `{rows, version, cols?}` | members | replace the rows. **409** if the version isn't the current one (`{data:{version}}`). Rows are flat objects: ≤5000 rows, ≤2 MB, keys `[A-Za-z0-9_][A-Za-z0-9_ .-]*`. Filter `ogc_file_rows_valid`. |
| `PATCH /years/{y}/files/{name}` `{op:'row', row}` or `{op:'key', key, value}` | members | change one row on the server's copy (`saveRow`: key column `help→need`, `places→code`, `nearby→name`, filter `ogc_file_row_keys`; `_gone` removes) or one key (`setKey`). No version needed. |
| `GET /years/{y}/state/{key}` | members | `{value, version}` (404 if none) |
| `PUT /years/{y}/state/{key}` `{value, version?}` | members | set it (409 on a stale version, when given) |
| `GET /years/{y}/records?kinds=a,b` | everyone | per kind: the year's COA gets every record (`ogc_records_all_ok`; also the committee handed Registration for registrations and credits, the Young Folks committee for teams); anyone else, webmasters included, gets their own whole, plus others' public views (marked `public`). Each record is `{id, mine, data, sample?}`. |
| `GET /years/{y}/records/{kind}?scope=mine` | signed in | your own (by your email) |
| `…?scope=all` | members | all of the year's |
| `…?scope=public` | everyone | the kind's public view (`ogc_record_public`). With no filter, nothing. |
| `POST /years/{y}/records/{kind}` `{data}` | default: members; anyone signed in for a record that's theirs (its email is theirs, or none); filter `ogc_record_can_write` | create (201) |
| `PUT /records/{id}` `{data}` | default: members of its year; its owner (and it stays theirs) | replace its data |
| `DELETE /records/{id}` | as PUT | remove (soft) |
| `DELETE /years/{y}/samples` (`?kind=`) | webmasters | erase the year's sample records |
| `GET /log?year=&limit=` | webmasters; the year's COA | the change log (a committee sees its own lines in the app's Activity) |
| `POST /dev/import` `{force: year or true}` | webmasters, **OGC_DEV only** | reload the seed |

**Records:**

- The kinds are `signups`, `registrations`, `credits`, `waits` and `teams`. An area adds more with `ogc_record_kinds`; any other kind gets 404.
- A record's owner is `data.email`, or else `data.household.email` (filter `ogc_record_email`). It's kept lowercased in `email`.
- Data is limited to 64 KB. `_rid`, `_pub` and `mine` are stripped.
- Validation goes through the filter `ogc_record_validate` (return a `WP_Error` to refuse).
- After a create, change or remove, the action `ogc_record_saved( $record, $action, $req )` runs (for emails and the like).
- Someone else's record answers 404, not 403, so its existence isn't given away.

**Other hooks:**

- Files: `ogc_file_saved( $year, $name, $version )` (action).
- Pages: `ogc_pages`, `ogc_client_config`, `ogc_template`, `ogc_page_allowed`, `ogc_before_page` (action).
- Members and addresses: `ogc_is_member( false, $year, $user_id, $email )` (the signin area answers), `ogc_is_webmaster`, `ogc_base_path` (the address, an open Advisors' question).
- Seed and schema: `ogc_seed_dir`, `ogc_seed_year` (action), `ogc_schema`, `ogc_rewrites` (action).

## The JS seams

Every page loads, in order: `ogc-wp.js`, `ogc-core.js`, `ogc-store.js`, `ogc-pickup.js`, then the page's own scripts.

**`window.OGC_WP`**, written by the page (`ogc_client_config()`, filter `ogc_client_config`):

```js
{ rest, nonce, base: '/annual-conference/', page: 'conference', folder: 'schedule-hub', assets,
  me: { email, name } | null, member: [2027], webmaster: false, dev: true, signin, logout, version }
```

**`shared/ogc-wp.js`** (loaded first):

- **Data:** any `fetch` of `…/schedule/data/years.csv` or `…/schedule/data/<year>/<name>.csv` is answered by `OGC_WP.data`. That's the REST fallback, or ogc-store.js once it's loaded. So v3's `data-base`, `ogc-core.js` and the pages' own loaders work unchanged. The same addresses also answer on the server, as CSV.
- **Links:** v3 links folders relatively. `OGC_WP.url(href)` resolves a link from the page's v3 folder, so on the Conference page `../register/` becomes `/annual-conference/register/`, `../schedule-hub/` becomes `/annual-conference/`, and `index.html` is dropped. Every `a[href]` is fixed as it's drawn.
- **Script navigations aren't fixed.** `location.href = '../x/'` works from every page except the Conference page (at `/annual-conference/`). Use `OGC_WP.url()` there.
- **`OGC_WP.api(method, path, body)`** makes a REST call with the nonce and parses the JSON. Errors are thrown with `.status` and `.data`, and a refreshed nonce is kept.
- **See it:** a page framed beside the year page reloads, where it was, after any save in this browser (the `localStorage` key `ogc-saved`, set by the store).

**`shared/ogc-store.js`** replaces v3's `ogc-local-edits.js`.

- **`O.edits`** keeps the same API: `get`, `merge`, `saveRow`, `saveFile`, `setKey`, `setYear`, `mergeYears`, `clear`.
  - The server holds the rows already merged. `merge` and `mergeYears` hand back the server's rows for any file the page has read (lossless: `_id`/`_look` are kept). For a file it hasn't read, they hand back what the page passed in.
  - A year's files come in one `GET /bundle`, shared by every read within 2 s.
  - Writes show at once in this browser and are sent in order:
    - `saveFile` is a PUT with the version; an unsent save of the same file is replaced;
    - `saveRow` and `setKey` are PATCHes;
    - `setYear` is a PATCH on the year.
  - While a file has unsent changes, reads of it come from this browser.
  - Offline or 5xx: it retries with backoff (1 s up to 30 s). Leaving the page asks first.
  - 401/403/400: it's dropped, with `console.error` and an `ogc:save` `{state:'error'}` event.
  - 409 on a PUT: an `ogc:conflict` `{year, name, theirs, mine}` event is sent. Unless a listener calls `preventDefault()` (which keeps theirs), this browser's rows are saved over theirs. v3's editors have no merge yet; that's the editors area's job.
  - Status events go out on `window` as `ogc:save` `{state: 'saving'|'saved'|'offline'|'error', pending}`. **v3's pages still print "Saved" when they call the store, not when the server answers: the editors and year areas wire their `.ws-status` to these events.**
  - `O.store.flush()` resolves once everything has been sent.
  - `clear()` does nothing (the server keeps the year).
- **`O.state`**: `load(y, key)` returns a Promise; `get(y, key, fallback)`, `has` and `loaded` are synchronous after a load; `set(y, key, value)` queues a PUT. Members only.
- **`O.records`**:
  - `load(y, kinds?, force?)` calls the bundle route;
  - `list(kind, y)` returns a copy of the array (the objects are shared) or null;
  - `store(kind, y, list)` diffs against what was loaded: new objects are POSTed, changed ones PUT, missing ones DELETEd. A new object with the same `id`/`email`/`name` as a removed one is a PUT on that record.
  - Each object carries `_rid` (its record id). Others' public views carry `_pub` and are never written.
  - An object still being created isn't sent twice.
  - `ogc:records` is sent when a year's records arrive.
- **`O.ready`** resolves once the store has the years, plus the records of `?year=` and the year before (or of the two newest years).

**`shared/ogc-signups.js`** (the plugin's copy):

- `SU.load` and `SU.store` keep their signatures. `signups`, `registrations`, `credits`, `waits` and `teams` are `O.records`; `rooms` is `O.state` (`rooms`).
- `SU.me()` is `OGC_WP.me`. Someone who typed their email but isn't signed in is kept in this browser as `pending` (`ogc-me-pending`). **The server refuses their writes until the signin and volunteer areas let them through** (the emailed link).
- `SU.signOut()` goes to WordPress's logout.
- **The samples are off:**
  - shifts start with `base: 0, sample: []`;
  - `SU.households()` is the registrations this viewer may see (a member sees every one; anyone else sees their own), with `mine` set;
  - `sampleHouseholds`, `seatSamples`, `sampleFilled` and `POOL` are still exported, for making seed rows.
- The year's picture is the plugin's `shared/img/conference-auditorium.jpg`, not a file on another site.

**`shared/ogc-pickup.js`** (the year area's): the seed holds 2025–2027 already picked up, and the pickup log is the state value `picked`. Nothing runs on page load. `O.pickup.run()` (the webmasters' Start) picks up the years this person is a member of, through `O.edits`.

**The campus map and Directions** (`shared/ogc-map.js`, `ogc-map-app.js`; Oct 13, `CHANGES/guide-maps.md`):

- The guide's Places is a map to see where things are: buildings with their codes and names, the rooms' pins, Search, the blue dot. It draws no routes and gives no steps.
- Every Directions (Places' cards, event sheets, Help, Open now) is a link to Google Maps' walking directions, opened in a new tab (a phone's Maps app): `O.map.directionsUrl(campus, place, places)` → `https://www.google.com/maps/dir/?api=1&destination=LAT,LNG&travelmode=walking`, or '' (no button) for a place the map can't find or a field not pinned yet. No key, no paid service.
- Where it goes: a link pasted in places.csv's `map` column (https) wins; else a room (pinned or not) goes to its building's entrance, `lat`, `lng` on the building's row in campus.csv (kept with the campus record); else the building's first door that isn't key only, else its middle, from the map's projection (the `geo` row). A field pinned out of doors goes to its pin. `O.map.entrance(c, name)`, `O.map.toLatLng(c, x, y)`.
- `O.map.router` / `walkMin` stay for walking times (Lodging, the packet, the pins tool's guessed doors); the step wording (`legs`) is gone.

**Browser keys.** Every key v3 kept for the COA or a committee (`ogc3-…`) now lives on the server (`O.state`, records, or an area's table). What stays in a browser is per-viewer convenience only: an unsent form (`ogc3-register-<y>`, this tab), the Preteens filter (`ogc-week-shows`; week.js moves an old `ogc3-week-shows` over once), the app's last committee (`ogc-app-team`), the volunteer page's own hold.

## Seed

- `node tools/seed-from-v3.mjs` makes `seed/` from v3 as its pages see it:
  - it serves the repo, opens v3's year page in headless Chrome, and lets the pickup run;
  - it dumps every file the pages read, merged (2027 picked up from 2026), plus `years.csv` and each year's pickup log (`<year>/state.json`);
  - headers are kept exactly as written, including `_id` and `_look`;
  - a header-only file (contacts) is kept.
- The importer (`ogc_import_seed()`) runs on activation, on a schema change, and from `POST /dev/import`. It loads any year that isn't in the tables yet. With `force`, it replaces that year's files, state and sample records; people's own records are never touched.
- **Sample records:** drop `seed/<year>/records/<kind>.json` (a list of data objects). They're loaded with `sample = 1`, `source = 'seed'`. The volunteer and register areas seed their sample people this way, all made-up names. The action `ogc_seed_year( $year )` is there for seeding in code.

## Areas and what each owns

```
conference → assets/schedule-hub/*, assets/guide/*, includes/module-public*.php, the guide templates (manifest, sw.js, app/)
map → assets/shared/ogc-map.js, assets/shared/ogc-map.css (and small targeted edits to the Places/directions functions in assets/schedule-hub/week.js only)
print → assets/schedule/*, assets/packet/*
signin → includes/module-auth*.php, includes/module-members*.php, includes/module-mail*.php, templates/signin*, assets/signin/*, the email templates
year → assets/year/*, assets/shared/ogc-pickup.js, includes/module-coa*.php
editors → assets/admin/*
volunteer → assets/volunteer/*, includes/module-volunteer*.php, seed samples for signups
register → assets/register/*, includes/module-registration*.php, includes/module-payments*.php, seed samples for households
lodging → assets/lodging/*, includes/module-lodging*.php
lists → assets/lists/*, assets/tournaments/*, includes/module-lists*.php, includes/module-tournaments*.php
app → assets/app/*, includes/module-app*.php, templates/app.php (the frame; the COA's and committees' screens add files beside it)
app-committees → assets/app/screens/committee-*, includes/module-app-committees.php, and (taken over from lodging and lists) assets/lodging/*, assets/lists/*, the volunteer heads' view
foundation/integration → ogc-conference.php, includes/core*.php, includes/module-integration.php (joins between areas), assets/shared/* (except ogc-map.* and ogc-pickup.js), tools/; the shared files' log from Oct 11 is NOTES/integration.md
```

The other templates (`templates/<page>.php`) belong to foundation/integration. Change one from your module, with `ogc_pages` (`template`) and a file of your own in `templates/`.

**The shared-file rule.** For a file you don't own (`assets/shared/*`, `includes/core*`, `ogc-conference.php`, another area's files):

- make only small, targeted edits with the Edit tool, never a rewrite of the whole file;
- if an Edit fails because the file changed, re-read it and try again;
- log each change (file, what, why) in `NOTES/<your area>.md`.

Prefer a filter from your own `includes/module-<area>.php` to editing core.

## App (the committees' back end, docs/23)

One app for the COA, the committees and the webmasters, at the plugin's own address: `/annual-conference/app/`. Files: `includes/module-app.php` (tables, page, viewer, screen registry, carry-forward, status, log words), `includes/module-app-seed.php` (the first year's committees and tasks; local samples), `includes/module-app-rest.php` (routes, the message email), `templates/app.php`, `assets/app/` (`app.css`, `app.js` = kit + shell, `screen-*.js`). The COA's and committees' screens move in here.

### Addresses

`/annual-conference/app/?year=2027&s=<screen>&c=<committee key>&past=<year>&v=<view>&f=<filters>&o=<sort>&at=<part or act>&id=<record>&from=<screen:record>&as=<committee>&as-role=&team=<committee>&as-of=<date>`. Every state is in the address, so Back, Reload and a link in an email all work. The contract is docs/27-back-end-map/area-shell.md section 1.

- **A click changes the level it names** (Round 1, Oct 14; `A.ladder` in app.js). The keys rank `s` › `c` › `past` › `v` › `f`, `o` › `at` › `id`. A move keeps every coarser key it doesn't name, clears every finer one, and sets what it names: `{ c: 'lodging' }` on the board is Lodging's page, `{ v: 'all' }` on Tasks is Tasks' All, `{ id: 74 }` opens a record beside the list, `{}` is this screen again. Only `{ s: 'home' }` (or nothing named, on Home) is Home. `year`, `as`, `as-role`, `team` and `as-of` stay unless named; `from` lives only while a record stays open on the same screen; for someone on two committees, `team` follows `c` into that committee's own section.
- **`at` is a part or an act.** A part is kept (a page's `report`, the schedule's `grid`: the `PARTS` table in app.js, or `OGC_APP.screen({ parts })`). Any other word is an act (`assign`, `head`): the screen reads it from `ctx.params.at` while drawing, then the router takes it out of the address, so Reload and Back never open it again.
- **No silent Home.** A screen that doesn't exist draws Not found, and one this viewer can't open draws No access with its name; both offer Home and keep the address. The router writes what it drew on the root: `#ogc-app[data-screen]` (`home`, `tasks`, …, `notfound`, `noaccess`, `notstarted`) and `data-c`.
- **See as the server didn't grant** (`&as=nosuch`, or a head opening `&as=food`) is taken out of the address once, with "See as · Not available": boot is never asked twice for one address.
- **A year that isn't started** (`ogc_year_started()`: its years.csv row has no `data`) answers boot with 404 `ogc_not_started` and writes nothing; the app draws "2028 · Not started" with Years (webmasters), Open 2027 and Your sign-ups. The year menu lists started years only, plus a member's own year not started yet, greyed with its reason under it ("Not started · Webmasters start each year"). When boot doesn't answer (not started, no access), the sidebar still says the year ("2028 · Not started", with the year menu from the 404's `years`) and keeps the person and Sign out (`viewer`, `logout`), and the tab says "2028 · Not started" (after the critic, Oct 14).
- **Your own committee's page has one address**, `s=committees&c=<yours>` (after the critic, Oct 14): no crumb, its own sidebar item current, named for the committee (never "Overview"). `s=overview` is its old name: `A.ladder` writes `{ s: 'overview' }` as it, and the router turns an old `s=overview` address (an email, a server `go`) into it in place. The COA's own page is `s=committees&c=coa` (Round 2): first in the COA's section ("COA"), no crumb, Who runs what at `at=who`.
- **Which sidebar item is current** (area-shell 2.7, one rule, `currentItem` in app.js): the item whose screen the address shows (your own committee's page by its `c`; Home and Tasks whatever the filter); else, for another committee's page or a committee's screen not in your sidebar (the COA on Nursery's Requests or Lodging's Rooms), Committees; else none (No access, Not found: `A.noAccess` takes the mark off).
- **A record opened beside its list on Tasks is its own history entry** (`A.openRecord`): Back closes the panel first; another task in its place replaces that entry; Close goes back to the list's entry without drawing it again (`A.closeRecord`). Other screens still replace (`setParams`).
- **A move to another screen, committee or year opens at the top** of the page (`A.go`), never where the last page was scrolled to.

- A members' page (`members => true`): signed out → `/signin/?return=…`; signed in but not on the year → the signin area's No access card (403). Webmasters open every year. With no `?year`: the viewer's soonest Conference not yet over (`ogc_app_default_year`).
- `s`: `home` (default), `committees` (with `c` = a committee's page, your own included, `past=2026` its year read-only), `tasks` (`c` one committee's; `f=kind:first_meeting` one kind of task across committees, with a "First meeting ×" pill), `overview` (the old name of your own committee's page), `members`, `years`.
- `as`: **See as** (COA and webmasters only; webmasters may also see as `coa`). The server answers as that committee (`ogc_app_viewer`), every write is refused (403 `ogc_read_only`), the shell shows "Seeing as Lodging · Back", and it is logged (`app_see_as`, once in 30 minutes per person, year and committee). It lives only in the address, never in storage.
- `team`: which committee's section the sidebar shows for someone on two (also remembered per browser, `ogc-app-team`).

### The shell

Sidebar: the year ("2027 · IWU"; a menu only for someone in more than one year), the committee switcher (only for someone on two), Search ⌘K, then Home · Committees · Tasks, then ONE section named for who you are (COA, Lodging…, Webmasters) with only your screens, then the person and Sign out. The page is one white card in a light grey frame; its title row holds a small title, a line of fact and the actions at the right. Below 1024 px the sidebar is a drawer (the ≡ in the title row).

### The screen registry

A screen is registered twice with the same id: its **rule** in PHP, its **drawing** in JS.

```php
add_filter( 'ogc_app_screens', function ( $s, $year ) {
	$s['rooms'] = array( 'title' => 'Rooms', 'section' => 'own', 'who' => array( 'lodging' ) );
	$s['schedule'] = array( 'title' => 'Schedule', 'section' => 'own', 'who' => array( 'coa' ) ); // handable by default
	return $s;
}, 10, 2 );
add_filter( 'ogc_pages', function ( $p ) { $p['app']['scripts'][] = 'app/screen-rooms.js'; return $p; }, 20 );
```

```js
OGC_APP.screen({ id: 'rooms', title: 'Rooms', icon: 'overview', section: 'own', who: ['lodging'],
  render(ctx) { ctx.head('Rooms', '54 to place', [OGC_APP.btn('Assign all', { primary: true, write: true, onClick })]); ctx.body.append(…); } });
```

- `who`: `all` (anyone who may open the year), `coa`, `webmaster`, `committee` (anyone on a committee: their own one), or committee keys (`lodging`, `a/v`, `young folks`: `ogc_committee_key( name )`).
- **The rule lives in PHP.** `/boot` lists only the screens the viewer may see (`ogc_app_screens_for`); the shell draws only those. Every data route of a screen asks the same rule: `ogc_app_can_see( ogc_app_req_viewer( $req ), 'rooms' )` in its `permission_callback`, and filters what it returns by `ogc_app_on_committee( $v, $ckey )`. A JS `who` is documentation only.
- **Handing a screen** (Round 2, Oct 16): the COA hands a `handable` screen (any not in the frame; Money isn't, the Handles money tick brings it) on **Who runs what**, its own page's part (`s=committees&c=coa&at=who`; `id=screen:<id>` opens a row's Run by panel): `GET app/{y}/handing` (rows: who runs it, last year's holder, what it grants, the tasks that move with it), `POST app/{y}/hand` (one), `POST app/{y}/handing/same` (Same as last year; 409 `ogc_hand_people` with the list when Households is among them, until sent with `confirm`). It joins that committee's sidebar and Work rows and **stays in the COA's**, marked with its holder ("Intake · A/V"); `ogc_app_can_see` lets the committee's members see it and its data. Kept in `ogc_committees.screens`; **not carried** to next year (a new year starts with every screen at the COA, and its tasks come back with them).
- `ctx`: `body`, `head(title, fact, actions[], { crumb: { label, to } })`, `params`, `boot`, `api`, `go`, `readonly` (seeing as), `split()` (a list with the record panel beside it). `render` may return a cleanup function.
- ⌘K actions: `OGC_APP.action({ id, title, screen, when: boot => bool, run })`.
- The invite's "your screens" words come from the registry (filter `ogc_committee_screens`).

### The year as a line (Round 2, Oct 16; `includes/module-app-line.php`, `assets/app/screens/year-line.js` + `.css`)

A committee's page and Home read down one line with Today marked (docs/27 README 12; `CHANGES/round2-committee-home.md`).
- **Server** (one count, one place: each line comes from the functions its screen counts with): `ogc_app_committee_needs( $y, $k )` (a committee's needs as its head sees them, memoised), `ogc_app_work_rows( $y, $k, $v )` (Requests, Shifts, its own screens, handed ones: line, need, season `on`/`until`, `done`, `handed`, `need.top` = the one filled button), `ogc_app_line_tasks`, `ogc_app_next_rows` (For next year), `ogc_app_committee_fact` (the board's Where it stands = the page's title fact), `ogc_app_committee_marks` (nobody, nohead, late with reasons, unchecked, soon), `ogc_app_handoffs()` / `ogc_app_works_with( $y, $k, $other )` (the fixed hand-off table, states only), `ogc_app_first_steps`, `ogc_app_final_counts`, `ogc_app_home_committees`, `ogc_app_handing`. The COA's own check of a committee is state `app-duties-checked` (`PATCH committee {duties_checked}`); Who runs what's answer is state `app-first-steps`.
- **`GET committee?c=`** adds `version` (`coa | own | other | structure`), `fact`, `work`, `line_tasks`, `next`, `works_with`, `runs`, `step` (‹ ›), `next_unchecked`, `source`, `from_year`, `duties_checked`, `head_checked`, `today`; drops `handable`. `other` sends only duties, people (names), `works_with` (you) and `contacts` (Our phone, committees.csv `contact_phone`). **`GET committees`** (board) adds `fact`, `marks`, `views`. **`GET home`** adds `steps`, `parts` (the Final counts line under the headline), `committees` (the COA's block), `today`, `start`, `end`, `venue`; the COA's notes from last year come in `last`.
- **Client:** `A.yl` (`stages(items, today)`: screens group by the month their season starts, tasks join the stage whose months hold their date, For next year last; a stage is above Today once its first day has come), `stage`, `today`, `row`, `task`, `listRow`, `fill`, `at`, `lab`. The page (`screen-committees.js` › `yearPage`) and Home (`screen-home.js`) draw with it.
- **Every committee has Shifts** (today's Helpers screen, titled Shifts; Round 4 builds Shifts in the app). A committee with no shifts says "No shifts", never another's.
- Check: `node tools/r2-test.mjs` (read only; `BASE=` for a copy).

### The kit (`assets/app/app.js`, `app.css`)

| JS | What |
|---|---|
| `OGC_APP.h(tag, attrs, ...kids)` | DOM without innerHTML. `text`, `on: {click}`, `class`, `href` (own paths and `https:` only). Never put user text anywhere else. |
| `btn(label, { primary, ghost, danger, big, icon, iconOnly, write, href, onClick })` | One `primary` per view (tan). `write: true` disables it while seeing as. |
| `tag(text, 'tan' \| 'late' \| 'ok')`, `face(name, you)`, `icon(name)` | Small marks; icons are 16 px strokes (`home committees tasks members overview years search plus x chev down menu mail eye file out back note report link upload`). |
| `empty({ title, line, action, inset })` | The one empty state (a dashed card, never a bare line). Never a zero: a section with nothing true isn't drawn. |
| `toast(msg, { undo })` | What just happened ("Done · Campus tour", "Added 1 person · Sign-in link sent"), with Undo when it can be undone. `fail(err)` says why something wasn't saved. |
| `views(views, current, onPick)` | Saved-view chips over a list (`[{ id, label, n }]`); the view is `?v=`. |
| `table({ cols: [{ label, cls, wide, render }], rows, key, selected, onOpen, group, empty, label })` | A dense table; arrow keys and Enter, the mouse always enough; `group` draws heading rows; `wide` columns hide on a phone. |
| `ctx.split()` → `{ main, open({ title, body, foot, onClose, focus }), close() }` | The record panel beside the list (the whole screen on a phone). Panels, never pop-up forms. `focus: 'head'` puts focus on the panel's heading (a record opened to read, a task), never in a field; otherwise a `[data-autofocus]` field (an Add panel). |
| `menu(anchor, items)`, `openSearch()` | A small menu (`items: [{ label, current, disabled, hint, run }]`; `hint` says in words, under the label, why a greyed item can't be chosen); the ⌘K palette (screens, actions, committees, people, tasks). |
| `openRecord(to)`, `closeRecord()`, `noAccess(ctx, { title, line, action })`, `ownPage(c)`, `unmarkSide()` | A record as its own history entry (Back closes it); a screen's own No access card naming whose ("Lodging’s requests"), nothing marked current; is this committee's page the viewer's own; take the sidebar's mark off. |
| `api(method, path, body)` | `app/<year>/<path>` (a path starting `/` is from `ogc/v1/`), with `?as=` added. |
| `go(to, { replace })`, `href(to)`, `ladder(to)`, `link(to, kids, cls)`, `setParams(to)`, `reload()` | Moving between screens, by the rule above (`ladder` gives the keys `href` writes). `setParams` changes the address without drawing again: a merge of exactly the keys named (closing a record, `id: ''`, also drops `from`). `go({})` and `reload()` draw the same screen again (screen, committee, view, record) after a change; Home is `go({ s: 'home' })`. Better still, redraw only the section that changed. |
| `team()`, `committee(key)`, `allowed(id)`, `boot()`, `refreshBoot()`, `toggleTask`, `message(ctx, { to, label })`, `noteCard` | Shared pieces. |

CSS classes: `ap-section`, `ap-h2` (+ `__n`, `__act`), `ap-cols` (main + 340 px side from 1100 px), `ap-list` / `ap-item` (+ `__main __title __why __side`), `ap-note`, `ap-banner`, `ap-person`, `ap-field`, `ap-input`, `ap-textarea`, `ap-pills` / `ap-pill[aria-pressed]`, `ap-chip`, `ap-switch`, `ap-check`, `ap-facts`, `ap-drop`, `ap-quiet`, `ap-muted`, `ap-label`. Tokens on `:root` (`--ap-*`). Type: system sans; the Home headline in the serif.

### Data (tables via `ogc_schema`; seeding idempotent)

| Table | Columns | What |
|---|---|---|
| `ogc_committees` | year, ckey, name, duties, sort, screens, link, from_year, checked_at, removed_at | A year's committees in the COA's order. `ckey` = `ogc_committee_key( name )`, the key `ogc_members.committees` holds; `coa` is the COA itself. `committees.csv` is kept in step (`ogc_app_sync_csv`) for the members' Invite pills; a name added there comes in (`ogc_app_reconcile`). |
| `ogc_tasks` | year, ckey, title, note, due_offset (days from the first day, the Friday) \| due_date, owner (member id), done_by, done_at, source (seed\|carried\|added), carried_from | What each committee does by when. |
| `ogc_cfiles` | year, ckey, name, fkey (random stored name), mime, size, uploaded_by, carried_from | Files, in `ogc_app_private_dir()`: `OGC_PRIVATE_DIR` (wp-config; best outside the web root), else `uploads/ogc-private/` with Apache and IIS deny rules. **For Corey:** on nginx add `location ^~ /wp-content/uploads/ogc-private/ { deny all; }`, or set `OGC_PRIVATE_DIR`. Served only by `GET /app/files/{id}` (a download, `octet-stream`, `nosniff`, sandbox CSP, no cache), never a media URL. Types: documents, spreadsheets, pictures (`ogc_app_file_types`), 20 MB (`ogc_app_file_max`). |
| `ogc_cnotes` | year, ckey, body, author, done_by, done_at | Notes for next year; the next year's committee marks each Done. v3's `notes.csv` (part,text) moved in once by `owner_<part>`. |
| `ogc_creports` | year, ckey, answers (JSON), updated_by, sent_at | The report. Questions: `ogc_app_report_questions()` (settings `report_q1…5`, filter `ogc_report_questions`). **Placeholders** until the COA's own five are found. |

- **Membership is the members list** (`ogc_members.committees`, `head`), not a second table: the COA manages it on Members through the signin area's routes (invite = a sign-in link). Read it with `ogc_app_people( $year, $ckey )`.
- **A year carries forward** (`ogc_app_start_year`, called only by Years › Start, `ogc_coa_rest_start`, and the local seed): committees, responsibilities, order, screens handed, folder link, every task undone (dates moved a year; offsets kept), every file (by reference). A first year starts from `ogc_app_seed_committees()` / `ogc_app_seed_tasks()` (docs/16's eleven and their fixed dates). Pre-app `committees.csv` names nobody is on are dropped then. **Opening a year never sets it up** (Round 1, Oct 14): `/boot` runs only `ogc_app_keep_year` (reconcile with committees.csv, contacts in step, the rest of a partial carry), and only for a year that already has committees. `ogc_app_ensure_year` is kept as a name for `ogc_app_start_year`.
- **Status words:** `ogc_app_committee_status( $year, $c )` → `{ line, look[] }`. Default "Next: First meeting · Nov 1" (never "0 of 6"); a committee's module writes its own with `add_filter( 'ogc_committee_status', fn( $line, $year, $ckey, $ctx ) … )` (`$ctx`: tasks, done, total, next, late, people, head, after); the board's mark: `ogc_committee_look`.
- **Local samples (OGC_DEV only):** made-up "First L." people on every 2026 and 2027 committee (`ogc_app_seed_people`; Ada Turner heads Lodging, Hannah Cole helps Food, Levi Stone is on A/V and Ushers), 2026's notes and A/V's report, past tasks done; 2027 announced and its dates checked on Nov 1, 2026, and Intake with A/V in 2026 as in 2027 (`ogc_app_seed_walkthrough`, Oct 16).

### Routes (`/wp-json/ogc/v1/app/…`; `?c=` is a committee key, `?as=` see-as)

| Route | Who | What |
|---|---|---|
| `GET {y}/boot` | anyone who may open the year | year, years (switcher), conference (label, dates, phase), viewer, screens, committees, people (names the viewer may see: everyone for the COA and committees, the COA for webmasters), questions, logout |
| `GET {y}/home` | all | headline, fact, needs, coming (merged across committees by kind and due date, never title; each row carries `go`: one task `{s: tasks, id}`, a merged row `{s: tasks, v: all\|committee, f: kind:<kind>}`, and `kind`, `n`), last (last year's notes), activity (`ogc_app_activity`, by viewer) |
| `GET {y}/committees` | all | `view`: board (COA: line, look, done/total, people, head) · directory (committees: duties, people names, own first) · structure (webmasters: counts) |
| `POST {y}/committees` `{name, duties}` | COA | add |
| `GET {y}/committee?c=` | all | `access`: full (COA, its people: tasks, files, notes, last notes, report, last report, past years, handable screens) · directory · structure |
| `PATCH {y}/committee?c=` `{name?, duties?, sort?}` (COA) `{link?, checked?}` (its people) · `DELETE` (COA, empty only) | | |
| `GET {y}/committee/past?c=&from=` | the COA, its people, webmasters | a past year read-only, no names |
| `POST {y}/committee/notes?c=` · `PATCH /notes/{id}` `{done}` (next year's committee) · `DELETE /notes/{id}` | its people, COA | |
| `PUT {y}/committee/report?c=` `{answers[], send?}` | its people, COA | saves as typed; `send` marks it sent |
| `POST {y}/committee/files?c=` (multipart `file`) · `GET /files/{id}?_wpnonce=` · `DELETE /files/{id}` | its people, COA | |
| `GET {y}/tasks?view=mine\|committee\|all` · `POST {y}/tasks?c=` · `PATCH /tasks/{id}` `{title, note, date, offset, owner, done, committee (COA)}` · `DELETE` | all to read their scope; writes: its people, COA | Each task carries `due_from` ("Set on Intake") when a setting decides its date (`ogc_app_task_kind_due`); its `due` is that date everywhere, the panel shows it as text, and a `date` or `offset` for it is refused (400 `ogc_due_set`, "Due · Set on Intake") |
| `POST {y}/message` `{to: 'member:ID'\|'committee:KEY', subject, body}` | members (webmasters: the COA only) | email `app_message` through the site, Reply-To the sender; no address returned; 20 an hour, 60 a day |
| `POST {y}/hand` `{screen, c}` | COA | hand a screen (`c: ''` takes it back) |

Rows by id answer 404 to anyone who may not see them. Every write is logged (`app_*` actions, detail `{ckey, title}`, never personal data).

### What needs whom (`includes/module-app-needs.php`, polish round 1)

- **Needs** (`ogc_app_needs( $year, $viewer )`): Home's headline is the first, its one button that need's act; the rest are "Also needs you". Each screen's work adds its own: `add_filter( 'ogc_app_needs', fn( $rows, $year, $ckey, $ctx ) … )` (`$ckey` is a committee key, or `coa` for the COA's screens; `$ctx`: today, phase, viewer). A row: `key, words, why, go {s, c, v, id, at}, button, tone (late|look), due, rank (0 late · 1 first steps · 2 now · 3 by date), kind`. Tasks due within 14 days (the COA's 30) join unless a need of the same `kind` already says it. The weekly note (`app_weekly`, Mondays from 7 AM, every member of the committee, on unless the COA turns it off: `committees.csv` `weekly`) is the same needs. `GET|PUT {y}/weekly?c=`.
- **Task kinds** (`ogc_tasks.kind`; `ogc_app_task_kinds()`, filter `ogc_app_task_kinds`): a task tied to its screen and to what marks it done — `requests_answer`, `requests_sent`, `meals_sent`, `reg_open`, `reg_tell`, `announce`, `schedule`, `signups_open`, `rooms_published`. It ticks itself (`auto`: "Done · from Meal counts · May 12"), takes a setting's date where one decides it (Registration opens = `registration.opens`), and moves with its screen when the COA hands it on. Added tasks have none. Two kinds only merge (no screen, never tick): `first_meeting` and `notes_next`, every committee's copy of one job, so Home's Coming up merges them by kind (seeded; on a site made before, named once from the plugin's own seed titles, option `ogc_app_task_kinds` 4).
- **Seasons** (`ogc_app_screen_opens( $year )`, filter of the same name): when a screen comes into season. Before, the sidebar shows it after the rest, quietly, with its date; work already there (a registration) puts it in season.
- **Previews:** a read of any `app/…` route may carry `?as_of=YYYY-MM-DD` (the shell passes `?as-of=` from the address); a change with it is refused. `ogc_app_today( $year )` is the date everything in the app counts from.
- `POST {y}/seen {screen}` → `{was}`: when this person last opened a screen (Households' New view).
- Invites land in the app (filter `ogc_member_landing_pre`) and say what the person can open (`ogc_member_access`).
- **Polish round 2 (Oct 11):** the ranking is work due within 14 days → late work done on a screen → first steps (rank 1) → dated within 30 days → waiting now (rank 2) → the rest; a need with `manual` (a task with no screen) never takes the headline (upcoming: "Next: …"; past: asked once, `ask` = task id, Done · Not yet → `POST {y}/later {id}`, lapses after 14 days; two or more are one line). A need may carry `op` (`remind:requests`) instead of a link. `POST {y}/remind {what: 'requests', c?}` (the COA): each committee with requests left, its head gets its weekly email now (once a day a committee). `GET|PUT {y}/phones {id, phone}`: the COA's phones for people on the year (state `app-phones`, the COA only). Home's `first` is the COA's first-visit line (`seen` home). Activity is by day, merged, without your own actions.
- **Shifts and a committee's own work (Oct 16):** a committee's Shifts (`helpers:<key>`, act **Fill shifts**) lead its needs in the last four weeks (`first`), except a need that opens one of the committee's own screens (the registry's `who` names it, or it was handed the screen; never Requests or Shifts), which keeps its own order ahead of them: Lodging's "Place · 48", Food's Meal counts. A COA check (`conf:dates` …) or a kept first step counts from its own day (`ogc_app_done_by`; `K.looks` the same).
- **Only what's true:** `ogc_records` (core-store) is filtered (`ogc_records` filter): a **sample** record dated after today (`data.created`, else `data.at`) isn't counted anywhere; a signed-in GET with `?as_of=` counts as of that day. The invite's first job: filter `ogc_member_first` (the app: the soonest undone task done on a screen).
- **Start before the last year is over** carries only what repeats (committees, responsibilities, seeded/carried tasks; state `app-carry.partial`); its files and the undone tasks it added follow once it's over (`ogc_app_carry_rest`).

### Who sees what (access, Oct 13; `includes/module-guard.php`, `includes/module-access.php`)

One rule for people's details, asked by every route that holds them (docs/26 decision 25; the Advisors' plan: `NOTES/security-plan.md`). `ogc_access( $year, $what )` reads the real viewer (never `?as=`, never a webmaster for being one); `ogc_access_for( $viewer, $year, $what, $email )` is the same rule for any member (the Privacy screen asks it per person).

| `$what` | Who |
|---|---|
| `households` | enter a household (desk, paper, phone) and open or change any registration: the COA, Lodging (`lod-households`), a committee handed the COA's `households` screen (`ogc_reg_enters()`, `ogc_reg_may()`; the generic records route's `scope=all` too). Never `registration` (prices and dates, Oct 14). |
| `children` | preteens' medical notes, emergency contacts, pick-up: the COA, Preteens (`preteens-list`), and whoever entered a desk, paper or phone registration on the day they entered it (`data.entered_by`, never sent to a page; `ogc_reg_children_ok( $rec )`). Everyone else, Lodging and a webmaster seeing as Preteens included, gets them withheld (`ogc_reg_withhold_children()`). A change from them that types a note, contact or pick-up name is refused: 403 `ogc_children` "Children’s details · Preteens or the COA change them" with `errors` at the form's field names (`ogc_reg_children_touched()`); blank or `withheld` fields stay as they were and a preteen's `days` go through (`ogc_reg_children_keep()`); the emergency-contact Required errors are left out for them. |
| `rooms` | the COA, Lodging (`lod-rooms`); the state value `rooms` and the other people-holding keys (`ogc_guard_state_people()`) read by the COA only |
| `yf_rooms` | each Young Folk's hall, room and rooming note: the COA, Lodging, Young Folks (`yf-halls`); for the Privacy screen |
| `money` | each payment line (`reg/{y}/ledger`, `lists/{y}/payments`, `pay`, `pay/undo`, `pay/remind`): Handles money only; with no one ticked, no one |
| `desk_pay` | a desk payment (`reg/r/{id}/ledger` `desk_payment`, `lists/{y}/pay/add`): Handles money, or Lodging (`lod-checkin`) |
| `owed`, `meals`, `communion` | for the Privacy screen's rows |

- **Handing a screen that carries people:** `ogc_access_hand_people()` (filter of the same name; today `households` → "Opens every household · Names, phones, emails"). `POST app/{y}/hand` answers 409 `ogc_hand_people` with those words until sent with `confirm: true`; the committee page's `handable` rows carry `people`, shown under the pills, and the pill asks Yes · No.
- **Nobody gives themselves access:** `POST years/{y}/members` with the caller's own address is 403 `ogc_self` ("Not your own email · Another webmaster adds you"); a webmaster can't change their own row's role, committees, head, label, end date or address (`ogc_member_can`), but may remove it; no one ticks Handles money on their own row (403 "Another COA member ticks it"; unticking is fine). The COA may remove a COA member who is a webmaster (`ogc_member_is_webmaster_row()`); member rows carry `webmaster` for those who see them whole, and Privacy's `on_year` lists them with who added them.
- Webmasters change structure (years, files, settings, publishing) as before; people only by See as, which is now logged however a screen's route is called with `?as=`, or by being put on the year by someone else. wp-admin › Users leaves out role `ogc_person` (filter `ogc_admin_list_people`). A privacy export is logged (`privacy_export`) like the erase.
- **Paper forms:** a registration entered with `source: 'paper'` needs registration.csv `paper_forms = yes` (400 `ogc_paper_off` otherwise). A Paper or Phone entry takes `received` (Y-m-d: the postmark or the call; never after today; the opening day if before it), kept as `data.received`.
- **Privacy screen** (`s=privacy`, the COA and webmasters; `GET app/{y}/privacy`): each kind of detail and who sees it, by the place that gives it (the COA sees names, webmasters counts), every See as in the last 30 days, every privacy request.
- **No name matching** (decision 6): `ogc_reg_dups()` finds nothing; Lodging's "on 2 registrations" warning is gone.

### The COA's screens (`includes/module-coa-app.php`, `assets/app/screens/coa-*.js`, `coa.css`)

Dates and place (`dates`), Campus (`campus`: `?v=halls|nearby|pins`), Schedule (`schedule`: `?v=<day>|check|live|all`, `?at=grid` Day view, `?id=` a row), Requests (`requests`: who `coa` + `committee`; `?c=` a committee), Registration, Money, Packet (`?v=menus`), Help and notices (`help`: `?v=notices|numbers`), and the webmasters' Years (replaces the frame's). Shared helpers are `window.OGC_COA` (`coa-kit.js`): `K.load(y)` (bundle + `coa/{y}`), `K.rows(y, name, d)` (one `ED.Rows` per file per visit), `K.status`, `K.textIn` / `K.dateIn` / `K.pills` / `K.field` / `K.facts` / `K.section` / `K.link`, `K.looks` ("From 2026 · Looks right"), `K.confirm(sp, …)` (a decision in the record panel), `K.undoKeys`, `K.replay`.

- `/annual-conference/year/…` and `/admin/…` redirect to the matching screen (`ogc_coa_app_landing`).
- **The volunteering phone** (canonical, Oct 14): Dates and place › Volunteering phone, settings `volunteer_phone` (ten digits, kept as 765-555-0100; blank: none shown). A role's phone, never a person's own (docs/scope/04, "The year's volunteering phone"). The volunteer page says "Volunteering · 765-555-0100" at the foot of Your week (`.vo-wk__phone`, also in the phone's Your week sheet); blank, nothing. Not carried to next year by the pickup: the next COA adds its own.
- **Who may change what:** members not on the COA change the COA's files and settings keys, and act on `coa/{y}/…`, only through a screen handed to their committee (`ogc_coa_app_may`); a committee reads and answers only its own requests. Webmasters always pass.
- **The published copy:** once a part is public, visitors read state `live_<file>` (schedule, changes, guide, menus), taken at Publish (`coa/{y}/publish` acts `publish` and `update`; action `ogc_coa_published`). Members read the working copy.
- Routes: `GET app/{y}/live?f=schedule,guide` → `{file: {public, at, by, added[], changed[], removed[]}}` (Schedule, Packet); `GET app/{y}/public?f=help,notices` → `{file: {public, rows}}` as a visitor would get it; `GET app/{y}/money` → totals, no names (`viewer`: may see each payment through `lists/{y}/payments`; `choose`: names the treasurer).
- `ogc_ed_files` (filter): files kept row by row by `years/{y}/rows/{name}` (the screens add `guide`, `menus`). Notices carry `draft` (never sent to visitors).

### The schedule, mechanical, and the call-in line (`includes/module-schedule.php`, night-schedule, Oct 13)

docs/25 rule 4; CHANGES/night-schedule.md has the whole of it.

- **Time is exact.** A new or changed `start`/`end` must be a clock time in 5-minute steps; words, "until finished" and a new `sort_time` are refused (400, said at the field). A new row needs both (after the critique, Oct 14), and a new or changed `place` must be one of the year's place codes (`ogc_sched_places()`, any case) or blank. Rows kept as they were are never refused, and the Schedule screen flags them "Set exact time". `noon`/`midnight` (and "19:30") are written as "12:00 PM" etc. on the next save of their row (`ogc_file_rows`, never the seed). PHP: `ogc_sched_clock()`, `ogc_sched_exact()`, `ogc_sched_when()`, `ogc_sched_sorted()`.
- **Kinds:** one fixed list, `ogc_sched_kinds()` (filter `ogc_sched_kinds`; key => label, listing), the older words read through `ogc_sched_kind_old()`; a new or changed `kind` must be on the list. The app gets both as `OGC_WP.sched`. JS: `window.OGC_SCHED` (`coa-schedule-read.js`: the one strict line format, paste, spreadsheet rows; `node tools/check-schedule-read.mjs`).
- **Export** `GET app/{y}/schedule/export?format=xlsx|csv` (any member of the year since Oct 14: they read the same rows through `files/schedule`): `ogc_sched_export_spec()`, the same columns every year, A/V's `tools/export-schedule.py` columns first, ID last. A row still without a clock start sits where its old `sort_time` put it. On screen: Schedule › File, Call-in › Download › Whole schedule, ⌘K › Export schedule (`A.exportSchedule(fmt)`). Import matches by ID only; Day/Date or Where/Place code that disagree, or a cell not on its list, leave that row as it is and say why (`row._errs` from `OGC_SCHED.grid`); a blank cell in a column the Export fills means none.
- **Call-in** (`s=callin`, handable on its own): settings `call_in_provider` (fcc · midwest · other: `ogc_sched_providers()`), `call_in_number`, `call_in_pin`, `call_in_pin_hash`, `call_in_account`, `call_in_trouble_role`, `call_in_trouble_phone`, `call_in_first`, `call_in_off`; playback numbers in state `callin_playback` (`{rows: {rowId: {n, st: numbered|not, note, by, at}}}`, written only by the route). Visitors get `call_in_number` and `call_in_pin` only, and not while `call_in_off`.
- Routes: `GET app/{y}/callin` (`?format=xlsx|csv`: the rows on the line with times in five zones) · `PATCH app/{y}/callin {fields}` · `POST app/{y}/callin/rows {ids, call_in?, recorded?}` (Schedule or Call-in; also on the published copy at once: docs/26 #3's exception) · `POST app/{y}/callin/playback {id, number?, status?, note?}` · `POST app/{y}/callin/confirm {done}` (`conf:callin`). Expected numbers: `ogc_sched_expected()` (FCC: in order from `call_in_first`; Midwest: date and order that day; the count goes on from a typed number, and a row marked Not recorded takes none). The playback route answers `{playback, expected}`.

### The year's request round (`includes/module-requests.php`, night-requests, Oct 13)

One round a year: each committee answers, once, what it tells the others (its requests to the campus, its packet parts and Help cards, its head and phone), starting from last year's. CHANGES/night-requests.md has the whole of it.

- **Screens.** `requests` is every committee's own list (`who: committee`, `coa_opens`; `?c=` a committee). `intake` is the round (the COA's, **handable**: whoever holds it is the coordinator, `ogc_round_coord( $v )`, and reads and answers every committee's rows).
- **Kept.** State `round` per year: `send_off`, `due_off` (days from the Friday), `remind` (days before due; 0 off), `asks`, `skip`, `owners` ({`guide:<part id>` / `help:<need slug>`: committee key or `coa`}), `sent_at`, `auto`. It is carried from last year's on first read. Table `ogc_round_lines` (sent, opened, started, returned, reminded per committee) and `ogc_round_answers` (packet part, Help card, contact). Requests keep their answers on their own row in needs.csv, through `coa/{y}/needs`.
- **Routes** (`app/{y}/round…`):
  - `GET` (board) · `PATCH` (settings) · `POST send {c?}` · `POST remind {c?}` · `POST assign {item, c}` · `GET email?c=`: the coordinator.
  - `GET mine?c=` · `POST answer {c, item, answer, note?, fields?}` · `POST return {c}` · `POST reopen {c}`: the committee's people and the coordinator.
  - A returned committee's writes get 423. `coa/{y}/sent` is the coordinator's.
- **Emails** `round_ask`, `round_remind`. The one automatic reminder runs on `ogc_vol_tick`. "Answer requests" takes the round's due date and is done on Return.
- **Exact requests** (after the critique, Oct 14). `coa/{y}/needs` calls `ogc_round_need_check()` on every row it changes or adds: Qty a whole number ≥ 1, days one day name or two joined by –, -, to, through (`ogc_round_need_day`), times as `parseTime` reads them, both or neither, written "9:00 AM"; kept, changed and new rows need days and a place (`ogc_round_need_incomplete`, counted as left until fixed). Refused with 400 `{field, id}`, nothing written. A carried row keeps what it had when first changed in `was` (JSON `{"in":year,…}`); answering it '' puts that back; values that match again make it Kept. Rows added this year carry `added_in` and go back to New, never To answer. Mark sent fingerprints only confirmed, complete rows.
- **Reminders** never within `remind_gap` days (3) of a committee's first email (`remind_from` on the board), by hand or by the tick; a round sent within the gap of its reminder date skips it (`auto: 'skip'`). The default reminder is 14 days before, and a reminder date from Dec 24 to Jan 1 is Dec 23 (`remind_moved`). Export for campus is kept as `exported` (PATCH `round {exported: true}`) so Mark as sent stays on the board.

### Households and Money (night-records, Oct 13)

The COA's records as a CRM (docs/25 rule 5; docs/26 #2, #4). Files: `includes/module-records.php` (statuses, Money, Households' routes), `includes/module-payments-ledger.php` (the treasurer's routes), `includes/module-payments.php` (the ledger table), `includes/module-records-dev.php` (local samples), `assets/app/screens/coa-households.js`, `coa-money.js` (also the shared `window.OGC_REC` list kit and `window.OGC_MONEY` acts), `coa-records.css`. CHANGES/night-records.md has the whole of it.

- **Status**, one fixed list, worked out (never typed): `ogc_rec_status_of()` → waitlist · registered · placed (Lodging's `hh:<rid>.rooms`) · checked_in (`checkin.at`) · checked_out (keys back for every room) · noshow (state `reg_marks`, the COA's Didn't come from the first day) · cancelled.
- **Money**, worked out from the payment lines only: `ogc_rec_money_of()` → none · paid · due · balance · check · checkin · refund · refunded, with `total`, `paid`, `balance`, `refund`, `unasked` (paid over the total, no refund asking for it). A declined refund is money kept. A household imported from the Google Form has the Form's own words: form_due ("Unpaid on the Form") · form_paid · form ("On the Form"), so "Payment due" always means owed here. "Still owes" is `ogc_rec_owing_keys()` (due · balance · checkin · form_due) on every screen and export. Lodging's owed comes from the same function (`ogc_rec_money_lodging()`, used by `ogc_appc_lod_households`), so a waitlisted household owes nothing on both.
- **History holds no money details** (docs/26 #25): a money act writes one plain word from `ogc_ledger_words()` (Payment recorded · Payment changed · Refund asked · approved · sent · declined), stamped with the act's own day; amounts, numbers, payers and a returned check stay on the payment lines. Older and other areas' lines ("Paid $455 by card") are read through `ogc_rec_hist_plain()` by everyone but Handles money (Households and Lodging's data). **Notes** (`POST …/households/note {rid, text}` · `{rid, undo: id}`, own note, a day): people's words on a household, dated and signed, kept in state `reg_notes` (never in the registration), shown in History.
- **Receipts wait out Undo:** a check marked received (or a payment recorded) queues the household's receipt in state `ledger_receipts`; it goes after `ogc_ledger_receipt_wait()` (10 min, filter `ogc_ledger_receipt_wait`) on the event `ogc_ledger_receipts_send`, the five-minute tick, or when Money or Households is opened; an undone act's receipt never goes, and two acts on one household within the wait are one receipt. Never for a sample. Filter `ogc_ledger_receipts` (false) turns receipts off.
- **State keys** `reg_marks`, `reg_notes`, `ledger_undo`, `ledger_receipts` are written only by these routes; the generic state route refuses them (the COA may read `reg_*`).
- **Your sign-ups reads the same** (canonical, Oct 14): each registration item from `reg/{y}/mine` (and every other `ogc_reg_view`) carries `standing` = `ogc_reg_standing()`: `{status, status_words, money, money_words, total, paid, balance, check, late, refund, refunded, checked_in}` (cents; `checked_in` the desk's day, venue time), worked out by `ogc_rec_status_of` / `ogc_rec_money_of` as of the day viewed. The page's status line (`statusCard` in register.js) draws only from it, `rooms` (published) and the record.
- **Who:** Households is the COA's (`households`, handable). Each payment line only for `ogc_access( y, 'money' )` (the access area's Handles money tick on Members); the rest of the COA gets totals and each household's Money word. Never while seeing as.
- **Routes:** `GET app/{y}/households` (`?format=csv&rids=`: the same columns every year) · `GET …/households/{rid}` · `POST …/households/mark {rid, mark: noshow|''}`. `GET app/{y}/ledger` (totals; for a handler every line, households, deposits; `?format=csv`) · `POST …/ledger/received {items[{line, cents?, ref?}]|lines[]|records[], cents?, ref?, day?, again?}` (less than expected leaves the rest as a check to come) · `…/check {ref, cents, paid_by, day, parts[{record, cents}], again?}` (must add up; a short part leaves the rest to come too) · `…/add {record, how: check|cash|card, again?}` (a check with the same number and amount already received answers 409 `data.dup` until sent again with `again`) · `…/refund {lines[], action: approve|send|decline, ref?}` · `…/refund/ask {record, cents}` (only what was paid over) · `…/mark {line, action: returned|disputed}` · `…/edit` · `…/remind` · `…/deposits` (POST; `/{id}` PATCH bank, DELETE) · `…/undo {token}` (24 h; refused, 409, once a line it touched has changed since).
- **Ledger columns** (dbDelta): `day`, `paid_by`, `grp` (one check's lines), `deposit_id`, `fee`; table `ogc_deposits` (day, kind checks|cash|card, bank_cents, removed_at).
- **Samples (local):** 48 households R-2027-2001…2048 with every kind of payment and two deposits, on each seed of 2027, or `POST /dev/records-samples` (webmaster), which takes the old ones and their lines out and makes them again. Seen as of Apr 15, 2027. Miriam K. handles money. `POST /dev/records-receipts {make?, send?}`: a household that isn't a sample (R-2027-2099, its check to come back as it was), and every waiting receipt sent now (tests).

### The committees' screens (app-committees, Oct 11)

`includes/module-app-committees.php` (the rules, the old pages' redirects, Lodging's households route, status lines) and `assets/app/screens/committee-*.js` + `committee.css` (the drawing). Shared pieces: `window.OGC_CK` (`committee-kit.js`: `bundle`, `days`, `md`/`day`/`at`, `download`, `fetchFile`, `print`, `find`, `steps`, `seg`, `pills`, `more`, `icon`, `iconBtn`) and `OGC_APP.committeeWork` (a committee's page lists its screens with a line each: `GET app/{y}/work?c=`).

| Screen id | Title | Who | Data |
|---|---|---|---|
| `lod-households`, `lod-rooms`, `lod-checkin` (`?v=desk\|setup\|counts`), `lod-yf`, `lod-campers`, `lod-import` | Lodging's | `lodging` | `GET years/{y}/lodging?hh=1` (the board plus the households as Lodging needs them: `ogc_appc_lod_households`, no emails, money only as owed), `POST …/lodging/ops`, `/undo`, `/publish`, `/import` (module-lodging*.php) |
| `food-meals`, `food-menus` | Meal counts, Menus | `food` | `lists/{y}/meals`, `/meals/send`, `/meals/sent` (every send kept; `?at=` one send's rows as it went, for Print; `&format=xlsx` the same as a workbook), `/settings`; menus.csv through the files route |
| `preteens-list` | Children | `preteens` | `lists/{y}/preteens` (children's details: the COA and Preteens, `ogc_reg_sensitive_viewer` filter); by day `?v=<date>` |
| `communion-list` | Communing | `communion` | `lists/{y}/communion` |
| `yf-teams` | Teams | `young folks` | `tn/{y}/teams`, `/add`, `/message`, `tn/r/{id}…`; settings `tournaments_online`, `tournaments_how` |
| `yf-halls` | Halls | `young folks` | `lists/{y}/halls`: the Young Folks in the halls by hall; rooms only once Lodging publishes (lists area, Oct 13) |
| `nursery-list` | Counts by day | `nursery` | `lists/{y}/nursery`: under 3, 3–5 and households each day; counts only (lists area, Oct 13) |
| `helpers` | Helpers | every committee whose key matches a shift committee (`ogc_appc_shift_keys`) | `vol/{y}/lead…` (`?committee=` the shift committee's name); `lead/setup` the committee's instruction and reminders (its head, the COA) |

- **Helpers' Download** (`GET vol/{y}/lead/export`, CSV, the same columns every year, added to, never reordered): Committee, **Weekday** (the Date's own weekday; "Day" until the ninth critic, Oct 16, renamed so it can't be read as the shift's day), **Date** (the calendar date), **Shift day** (the night's or day's words, "Fri night, May 28"; all week: "All week"), Start, End, Shift, Place, Name, Phone, Email, Household contact, Signed up, the rule's question (or "Rule"), Note, Status. A Saturday 12–3 AM row: Weekday "Saturday", Date 2027-05-29, Shift day "Fri night, May 28".
- Each screen is `coa_opens`: the COA may open it (committee page, ⌘K) without it joining the COA's sidebar (`ogc_app_can_see`). Webmasters only by See as.
- **Every list for Excel** (lists area, Oct 13): `?format=xlsx` on `lists/{y}/meals|communion|preteens|nursery|halls` and `tn/{y}/teams` gives a workbook: the list (header frozen, filters on), then a **Columns** sheet (what each column holds, As of, the counts). The columns are fixed per list in `ogc_lst_spec()` (`module-lists-more.php`), the same every year; the writer is `ogc_lst_xlsx()` (`module-lists-xlsx.php`, no library). In the screens: `OGC_CK.excel(path, name, as)`, with the path after the namespace (`'lists/2027/meals'`; `OGC_CK.restUrl` also trims a leading `ogc/v1/`, which used to double and 404). `POST lists/{y}/printed` keeps nothing while previewing a date (`as_of`), and each view has an owner (`ogc_lst_view_screen`: payments → Money or the payment viewers, callin → Call-in).
- Every route above asks `ogc_appc_can( $req, $screen )`: the screen's rule with `?as=`, and a change refused while seeing as (403 `ogc_read_only`) or with `as_of` (403 `ogc_preview`). Lodging's routes through `ogc_lod_can`; the lists', tournaments' and heads' routes through a `rest_request_before_callbacks` guard; the heads' scope through `ogc_vol_lead_all()` / `ogc_appc_vol_scope()`.
- The old pages redirect into the app (302): `/lodging/` (`?view=` → the screen), `/lists/` meals·communion·preteens (payments and call-in stay on `/lists/`), `/volunteer/?view=lead` (`&committee=` → `c`), `/tournaments/?view=teams`.
- `?as-of=YYYY-MM-DD` in the app's address previews a date on Lodging's and the lists' screens (reads only).

### The hand-down (night-handdown, Oct 13; `includes/module-handdown.php`, `assets/app/screens/committee-handdown.js`, `handdown.css`)

What one year's committee leaves the next, on the committee's page (docs/23 "The hand-down lives in the system"; CHANGES/night-handdown.md has the whole of it).

- **On the page** (`screen-committees.js` draws it, `OGC_APP.hd` gives the parts): last year's notes on top with Done and **Keep for 2028** (copies the note into this year's, source `kept:<id>`, and nothing else: Done stays the doer's; the copy reads "From 2026 · Kept by Aaron W.", and a year later "Written Jul 1, 2026 · Kept in 2027", `ogc_hd_kept_notes`); last year's report, open until the page is checked, with its numbers; Responsibilities (the COA's) and **How we work** (the committee's own standards; anyone on it or the COA writes it); **Contacts** by role (side column; each opens in the record panel, saves as typed); Files with what each is for, **Next year** (whether it's passed on, with where it stands: Goes to 2027 · In 2027 · Stays with 2026 · Kept in 2027 · Removed in 2027) and Remove with Undo (a day); the report: the COA's questions, **Numbers** (last year's labels to fill only while the list was never saved, `numbers.saved`; last year's values beside), the contacts' count; Send stays on the report (Sent Oct 14 · Send again; Changed since sending when it's edited after); **Export ▾**: Print ("Your part", made from the records), Excel, Excel and files (.zip). The COA's board has a **Hand-down** view (what came from last year, what's going to next; a row opens that committee's report in the panel, ↑ ↓ and Previous · Next move through them) and **Export reports**. Every change on the page redraws only its own section (or `A.reload()`, app.js: the same screen again); none goes back to Home.
- **Table** `ogc_handdown` (year, ckey, how, contacts, numbers, files; each with `_by`/`_at`; `questions`: the report's wording when it was answered; `sent_hash`: what it said when sent). A NULL column is "not written this year": `ogc_hd_field( $y, $ckey, 'how'|'contacts'|'numbers' )` reads the nearest earlier year's ("From 2026"), copy on write; numbers are the year's own. `files` is keyed by the stored file's `fkey`, which a carried file shares, so a file's note follows it (`ogc_hd_files_map`).
- **The carry** asks `ogc_app_carry_file` (filter, module-app.php) before carrying each file: a file switched off stays behind, and one already passed on isn't copied twice. Default on, as built (`ogc_hd_pass_default`; scope 08 Q17 suggests off). **After next year is started** (and its files have come), `ogc_hd_file_sync` keeps next year's copy true: a file uploaded, switched on or put back goes there at once; switched off or removed, it leaves, unless next year's committee has made it theirs (a note or switch of its own there). Uploads and removals are caught after module-app-rest.php's routes (`rest_request_after_callbacks`).
- **The report's status**, one rule for the page, the board and the workbooks (`ogc_hd_report_row`): Not started · Draft (an answer or a number) · Sent · Changed since sending (answers or numbers differ from `sent_hash`; still counts as in). A report save records the questions' wording it was answered under (`ogc_hd_questions`); last year's answers read under it.
- **Routes** (`app/{y}/handdown…`, `?c=`; the committee's people and the COA; 404 for anyone else's; writes refused while seeing as or previewing): `GET` (`&from=2026`: a past year, read only, no names) · `PUT how {text}` · `PUT contacts {rows}` · `PUT numbers {rows}` · `PATCH file {id, note?, pass?, restore?}` · `POST keep {id, undo?}` · `GET export?format=xlsx|zip` · the COA: `GET board`, `GET reports?format=xlsx`.
- **Hooks it adds to the app** (shared files, NOTES/night-handdown.md): `ogc_app_carry_file`, `ogc_app_log_words` (Activity words), `ogc_app_task_auto` (task kind `report_sent`: "Report to the COA" ticks itself when the report is sent), `ogc_year_export_files` (the year's Export carries `Committee reports.xlsx` when the COA exports it). Home's after-the-Conference headline "Reports · 3 of 11 in" gets its button (See reports) from the need with the same words.
- **Samples (local):** 2026 How we work, contacts and numbers for Ushers, A/V, Food (Lodging: contacts), Ushers' report and notes, Food's draft, four small files (made on the fly, in the private folder) carried into 2027. `tools/wp-local.sh php tools/handdown-test.php` checks the carry, inheritance, the export, the task, the files' sync with next year, Keep, the report's status and wording, and phones with ext. (35 checks; it cleans up after itself).

## Testing

- **`node tools/e2e.mjs`** (integration, Oct 11): the whole plugin end to end, each person in their own headless Chrome profile, signed in only by the links and codes the Mail log keeps (the webmaster alone uses the dev sign-in). `ONLY=a,c` runs some parts; `SHOTS=dir` (default `.wp-local/shots/e2e/`). About 25 minutes on one worker. It changes the site's data (people invited, a registration, rooms published; the schedule row it publishes is put back); `tools/wp-local.sh reset` before it gives a clean run. Parts:
  - **a** a webmaster invites a COA member (app › Members) → the Mail log's link signs them in → they add a Lodging head → the head's link opens only Lodging's screens and the directory → the board shows Lodging's line → the COA renames a Saturday row and Publishes → a signed-out phone sees it on the Conference page and in the guide;
  - **b** a new volunteer joins, confirms by the emailed link → the public count drops and shows "First L." with no email or phone → the head's Helpers list has name and phone → Can't make it (the day before, `X-OGC-Now`) frees the place and mails the head;
  - **c** the Hoovers' form is filled in from 2026 (they saved it for next year) and they register by check (previewing Mar 1, 2027) → Your sign-ups in another profile after a code from the Mail log → Lodging imports the sample Form export, places the Hoovers by hand (`lod-rooms&id=`, a free room tapped on the plan), publishes → the household sees its rooms;
  - **d** a stranger and a signed-in non-member: no records, file writes, members' data or unpublished parts;
  - **e** the guide offline after one visit (the site is stopped, then started again);
  - **f** every public route and every screen each person's boot lists, at 390 and 1280: no console error, failed request or sideways scroll.

- `tools/smoke.sh` (main site, or `PORT=…`; `SHOTS=dir` for screenshots) checks:
  - every route answers, and the back end (the app, and the old pages through it) sends a visitor to sign-in;
  - each page at 390 and 1280 with no console error, failed request or sideways scroll;
  - the files route is CSV, and private files read empty;
  - unauthenticated writes are refused;
  - a member's change round-trips to a visitor's Conference page, a stale version gets 409, and another year gets 403;
  - a signed-in person's own sign-up (through `vol/{y}/join` and `leave`) is kept across a reload and left, while a sign-up through the generic records route and everyone's records get 403;
  - boot of a year not started (2028) answers 404 `ogc_not_started` and leaves it without committees;
  - handing Registration to Food and back, then taking its two Activity lines out again (`dev/tidy`, below);
  - the app's Sign out ends the session.
- **`node tools/route-check.mjs`** (the doors, Round 1, Oct 14; docs/27 area-shell 13–14): signs in as the COA, Lodging's head and a Lodging helper, Food's and Nursery's heads, a webmaster, and the webmaster seeing as the COA and as Lodging (dev sign-in, a fresh headless Chrome each, one at a time). For each it opens every screen boot lists (and, for the COA, every committee's page) and presses every link, view chip, tab and table row in the app (the committees board every row, other tables the first `ROWS`), each on the screen as first drawn, then Back. It reports every dead end, one line each (who · screen · what was pressed · where it landed · what it named):
  - `home` (landed on Home though it didn't name Home), `screen` (another screen than it names), `not-open` (`?id=` named and nothing opened), `broken` (Not shown, Not loaded, No access or Not found from a link the app drew; Loading that never ends), `boot-loop`, `console` (a console error, exception or failed request ≥ 400), `no-way-back` (no crumb, no Back, nothing current in the sidebar), `back` (Back doesn't return), `dead-link` (`href="#"`), `promise` (after the critic, Oct 14: `PROMISES` in the script, each for its person: the COA's merged Coming up lines open Tasks with every committee's task, one row each; Lodging / Tasks lists Lodging's open tasks with no other scope's chip; for Nursery's head the sidebar, the Tasks crumb and a task's Committee link are one address and the page's own item is current; another committee's Requests says No access and whose; for Joel M., No access on 2023 offers Open 2027, never the 2028 not started);
  - as notes: links that leave the app, into another year or a year not started, rows that open nothing, the table's own "Nothing here", and any write it stopped.
  - **It never saves:** it presses only links, chips, tabs and rows (never a button that acts), and every request to the REST API that isn't a GET is stopped in the browser (DevTools Fetch) and noted, except the two reads that use POST (an editor's who's-here `years/{y}/sync/{name}`, and `app/{y}/seen`). It skips sign-out, downloads and exports, wp-admin and other sites, and other years unless `OTHER_YEARS=1`. Opening screens is logged as it always is (See as on Privacy).
  - Env: `ONLY=coa,lodging-head` (roles: `coa`, `lodging-head`, `lodging-helper`, `food-head`, `nursery-head`, `webmaster`, `seeas-coa`, `seeas-lodging`), `QUICK=1` (the COA and Lodging's head, one row a table), `TIMING=1`, `PORT`, `YEAR` (2027), `W`/`H` (1440 × 900), `MAX` (500 addresses a person), `ROWS` (2), `OTHER_YEARS=1`, `QUIET=1`, `BASELINE=<report.json>` (fixed · left · new), `SUMMARIZE=<report.json>` (count an earlier report again by today's rules).
  - The report: `.wp-local/route-check/<date>-<time>.json`, each dead end once however many people meet it. Exit 1 on any. A whole run takes about 40 minutes on the main site; the COA alone, about 10; `TIMING=1` says how long each press took. Round 1's baseline and after-run: `CHANGES/round1-doors.md`.
- `node tools/browse.mjs <url> <steps.json | - | '[…]'>` drives headless Chrome step by step: `nav`, `eval` (with `out`), `assert`, `click`, `hover` (the pointer onto an element, then along a `path`), `type`, `key`, `wait`, `waitFor`, `shot` (with `sel`, or `view: true` for only what's on screen), `pdf`, `viewport`.
- `tools/wp-local.sh php tools/vol-add-test.php`: the volunteer page's Add someone on the server (a place held for someone added by name and email, Confirm and Not me, the adder's Leave, their phone after confirming); it removes what it made.
- `tools/wp-local.sh php tools/vol-sug-test.php` (Oct 15, `CHANGES/volunteer-vs-sug.md`): All week shifts (one shift, its words and calendar file, never Busy against a timed shift), each committee's instruction and reminders (`POST vol/{y}/lead/setup`: the COA and the committee's head only; on the public page, Helpers and the emails), a committee's day-before reminder off and on, and the heads' message limits (20 a day, 4 a day to any one volunteer). 27 checks; it puts back everything it changed.
- `tools/wp-local.sh php tools/vol-critic-test.php` (Oct 15, after the critic): a sign-up made by someone not signed in with a confirmed person's email changes nothing of theirs (phone, people, page, Your sign-ups' records) until that email confirms it, and a sign-in from the device that made it confirms it; a couple on one shift is one shift (the email's subject and facts, the Confirm card, one calendar event, Left shift); Add someone on a shift a visitor already holds; Under 18 never named, and refused by an age rule; no volunteer email replies to a person's own address. After the second critic: a first-timer's Confirm email has Your sign-ups and Can't make it? Leave shift (the Leave link works before confirming), "Didn't sign up? Remove this address" by the footer's reason (`reason_link`); the used Confirm link's card leads to Your sign-ups; one of two leaving gets "Abe is still on it" and the calendar event updated in place naming Abe; a leave more than two days out goes in the heads' evening email ("Left today · Lodging", `ogc_vol_head_digest()`, from 6 PM venue time, once a day); the head's copy of a message names the shift. After the third critic: an emailed Leave link opened after one of two left lists only who's still on it, by name, and its old choice can't take the other off (nothing chosen, no one leaves); Undo of a Leave (`POST vol/{y}/unleave`) by the same link within ten minutes, quietly, never a head's Remove; a person's phone (`ogc_vol_known_phone()`: this year's registration over last year's sign-up, Change on one's own pill onto every place, kept after the last shift is left, an exact email match only); "Usher", not "Usher · Ushers"; both reminders named. After the fourth critic: the Leave link of someone who has left since says so (`self`, `self_on`, `groups`), the used Confirm link's page (`vol/{y}/link { cf: 1 }`) says who left and who's on, a shift with no limit is never full, the head's "who left" keeps what came before a print (`group`, `on`, `shift_short`), and a Confirm opened on the device that made the sign-up posts itself while a GET alone confirms nothing (`ogc_link_auto`). After the fifth critic: one privacy rule on every path (a household's list, Add someone, "for someone else", a first-timer's added person, a head's Add, the "Sign-ups open" email's link: off the public list until shown, in GET vol/{y} and the records route's public view; Under 18 never; one's own Show my name on a place a head made; older records marked once, `ogc_vol_others_fix()`), the again link's per-shift people and state (`ogc_vol_again_view()`), its sign-up confirmed and its waitlist without typing who, the phone kept for a tab that comes back after leaving, a used Confirm link's card naming the shift (`ogc_link_what`), the head's `me_name`. The week grid (Oct 15): "For someone else" (`who.helping: false`): the contact isn't on the shift, those added go on under her email with her phone marked `via`, the head's list says "via Martha Seven", the Confirm email says who it's for, the privacy rule holds, Leave per person; a signed-in person who unticks themselves ends the same way. After the sixth critic: Your sign-ups' year (`ogc_mine_year()`: the soonest Conference with the email's records, else the coming one; the link carries it); each person's age as one fixed field (`band`: an 18–20 is refused a 21-or-older shift even with the old claim, an Under 18 by name, both 21 or older go on with no claim and each sign-up keeps it, `mine[].band`; an Under 18 is a minor by the band; Show all by `names` never shows one; only a confirmed sign-up gives an age; the registration's groups map plainly); a certification each (`answers.questions`, refused by the missing one's name, each kept); the used Confirm link's truth (`ogc_vol_link_truth()`, "Ada left · … · Al is still on it", no phone or email); a missed day-before reminder caught up on the shift's day as "Today", once, never for a place taken that day (`ogc_vol_day_before_due()`); the confirm reminder a day on is "Still to confirm". After the seventh critic: a day skipped, the run that catches up one place sends the next day's too in one email, "Today and tomorrow · 2 shifts", each line headed by its own day (`ogc_vol_day_before_mail()`), alone each its own; the week-before only before the Conference and for places taken before that week (`ogc_vol_week_before_due()`); a contact's reminder says "This address is their contact." (`ogc_vol_via_of()`, `ogc_vol_remind_reason()`); "Fri night, May 28 · 12–2 AM" in the emails and the "Sign-ups open" lines (`ogc_vol_again_lines()`); "Still to confirm" promises no reminder; the heads' evening email "Left today" only when every leave was today, else "Who left" with dated lines; several shifts with their own people in one request (`join` › `each`, signed in or by a link only); a head's Undo of a Remove never takes a place since taken, and a head's chosen add past the count is kept and marked `over`. After the eighth critic: a shift from midnight to 5 AM is its night's on the heads' side (`eve`, `night`, `day_words`; Message › a day reaches its night's shifts and not the next day's; the export's "Shift day"; the calendar alarm at 6 PM on its evening); a first-timer's two sign-ups before confirming (the second Confirm email lists only its own shift and says the earlier Confirm does it too; the older link on another device confirms both, never a stranger's place under the same address, `confirmed_via`; signed in, a place another device made is `pending`, and Resend works; a sign-in on the device that made a place confirms it); a Leave's "head is told" (`mine[].tells`, `ogc_vol_leave_tells()`); `GET vol/{y}/ics` (text/calendar, inline, only the asker's own). After the ninth critic: every volunteer email kind sent to a single person, a couple where one left and a contact (signed in, and not), read for "you" of anyone but the reader and for its reason (`ogc_vol_addr()`: "This address is signed up for this shift.", "This address is their contact.", "Cal is signed up on this address.", and "was" for those that came off); a head's message says each shift once with the address's people on it and goes to no address with nobody on it; the Copy's To / Sent / Call and no "0"; one email an address for a changed, removed or let-go shift and for a place opened (its link holding every wait); "Confirm the places" to a contact; "Signed up in 2026" lines with their people; a night shift's calendar title ("Fri night · 12–2 AM"); "First Aid" and the Committee line; a missed day-before reminder caught up before the shift starts, not at it, once. 264 checks (259 on 2026's shape); it removes what it made.
- `node tools/vol-link-test.mjs` (`PORT` for a copy; after the third critic, Oct 15): the emailed "Can't make it? Leave shift" link in a browser, signed in by the dev sign-in and read from the Mail log: three people on two shifts get a toggle a shift and a person, all on, and the line says who goes ("Daniel leaves · 2 shifts"); Leave takes off only those chosen; the toast's Undo puts them back; an old link after its own person left opens on that ("Edith left · Harold is still on it", Done the filled button) and only its quiet "Leave for Harold" opens the sheet ("Harold leaves"); the one Leave sheet is the same on the page, the link and Your sign-ups (words, toggles, the filled tan Leave shift, Find replacement only for one place). After the sixth critic: Your sign-ups with no year (the account menu's `OGC_WP.mine`, register/?view=mine, volunteer/?view=mine, the app's link) opens on the person's year, never a request for reg//mine; a first-timer's used Confirm link opened on another device says what's true ("Abe left · … · Ida is still on it"), with no phone or email and Send code only for signing in, as the Leave link does. After the seventh critic: Your sign-ups names the people on every shift line (the signed-in person alone too), and a registration staying elsewhere with no days draws (it was a TypeError). After the ninth critic: a "Place open" link naming more people than the shift has open opens the row to choose who, and sends nothing. 44 checks; shots in `.wp-local/shots/vs-sug/after-critic7/link-test/`. Its made-up people leave their places at the end.
- `node tools/vol-again-test.mjs` (`PORT` and `SITE` for a copy; after the fifth critic, Oct 15): a returning volunteer in a browser. A made-up couple's 2026 sign-ups (made inside the site with `tools/wp-local.sh php`) on four shifts that carry on by their ID: the signed-in page's "Your 2026 shifts" card (each shift with only its own people, open / Full / Busy, one Sign up saying the people, Not now and Show), the "Sign-ups open" email's link as a visitor (the same card; the age rule asked in place; one Sign up for both shifts, confirmed; the header "Signed up"; Undo; the toast becoming an Undo chip), the public answer (Ruth named, Amos not), Join waitlist from the card and from a full row (who, by the same pills), Your sign-ups' waitlist with Leave waitlist, and the next row opening with the people chosen last ("Sign up · Amos" on one line at 390). After the sixth critic, each person's age is asked once for the whole card (not on each row) and not again after Undo. After the seventh critic, the card's Sign up is one request for every shift on it (`join` › `each`). After the ninth critic: an age once asked stays in place with its answer, so the next person's pills move 0 px (390 and 1440). 34 checks; shots in `.wp-local/shots/vs-sug/after-critic7/again-test/`. It removes what it made.
- `node tools/vol-grid-test.mjs` (`PORT` and `SITE` for a copy, `SHOTS`; the week grid, Oct 15): a committee's week on a laptop in a browser. A made-up couple signed in at 1440: Hide full keeps their full shift and hides the rest; their other committee's shift is one faint line where it starts; a shift at the same time says Busy; Your week is the bar. Hide full off: every shift a card exactly once, in the cell of its day and its start's part (midnight to 5 AM the Night before). A card opens the band under its row (caret, focus, `?shift=`, in view above the bar); Sign up from it; Esc gives the card focus back; Tab goes card to card; the days stay pinned. At 1099 px and for a one-day committee, the list. For someone else as a first-timer (the box, Add someone with Uses my email, "Sign up · Amos and Ruth", `via` on the server). Fit at 1100, 1280 and 1440 for First Aid, Ushers, Young Folks and Food, all jobs and each: nothing past a card's edge, no time split, nothing under 12 px. After the sixth critic: a card hovered on the way down to Your week's bar never shows in its sheet, and beside All shifts the row under the pointer is dashed only while the pointer is on the page; For someone else is the contact's box and the names list; Evening from 4:45. After the seventh critic: the parts of the day say their names only (the title says "Starts …"), in the grid and the list; every night shift (the committee with the most) once, under the day before its date, in Night, its card saying "Fri night"; with All jobs a card says its place when it isn't the usual one and its rule when the line above has none, fitting at 1100; every card's and row's dashed marks and "+N" add up to what's open (four on a card, six on a row); Your sign-ups beside the name and in Your week's sheet; Your week's Leave at 390 and 1440 said in the sheet with Undo there, the toast on top once the sheet closes; the A/V card's microphone; the Tour docked in a strip the page reserves (390), its title wrapping, and the laptop's open card in the margin or the strip. After the eighth critic: names on a card with one or two people ("First L.", one line inside the card, at 1100, 1280 and 1440); the opened row's Close in the tan outline; on a phone no text field takes focus by itself, on a laptop the first does; Calendar a link to `GET vol/{y}/ics` (text/calendar, inline, one event naming Gail and Hal); All shifts' "First aid" said once; the names list asks each person's age (none carried); Your week for someone who has left their only shift: "No shifts", no week, no Add to calendar; the Tour pill in the margin or the strip at 1100, 1280 and 1440, its taps 44 px at 390. After the ninth critic: the names list's first last name blank, then the last added person's; a greyed pill's "Under 18" / "Under 21" / "Needs 21 or older"; "+N" only for open places (dashed), people beyond the marks in words, the open marks and their "+N" adding up to the open count; "On this shift" counting everyone; "Yours · N" on every card; "First Aid"; a chosen pill never filled tan, and one filled button a view. 138 checks on the main site (154 on 2026's shape); shots in `.wp-local/shots/vs-sug/after-critic9/grid-test/`. It removes what it made.
- `node tools/vol-head-test.mjs` (`PORT` and `SITE` for a copy, `SHOTS`; after the seventh critic, Oct 15): a committee head's Helpers in a browser. The browser's own Print (⌘P; here Chrome's print to PDF, read back with PyMuPDF) prints the clean sheet More › Print makes (its title with the year and the committee, the date printed, "Transportation only"), never the screen; a made-up volunteer joins and leaves a shift and its panel lists "Lena Headtest left · Oct 16" under "Left · N"; on the head's phone list the Tour sits in a strip the page reserves at its foot from the first moment and after a scroll. After the eighth critic, as the COA on the committee with the most night shifts: every night shift under its night's day named "Fri night · 12–2 AM" (1440 and 390), its panel "Fri night, May 28 · …", Move's pills by the night, the printout (read back from the PDF), Message › that day counting the server's day-and-night people; the list at 390 never wider than the screen, itself included, and at 1100 with a panel open in the phone's layout; the Tour on Helpers at 1440 in the strip, never over the list or a panel. 20 checks; shots in `.wp-local/shots/vs-sug/after-critic8/head-test/`. After the ninth critic: a message counts people (a couple under one email is two), and the sheet, toast, answer and Copy agree; who has no email is named to call in the toast, a panel that stays until ×, and the Copy, never a 0; every tap at 390 is 44 px; day headings stay under the title row (390, and 1100 with a panel); a leave's time; the print's names on one line, "N open" past 8 and "No limit" with three lines to write in; the export's Weekday. 45 checks on the main site, 41 on 2026's shape; shots in `.wp-local/shots/vs-sug/after-critic9/helpers/head-test/`. It puts back the change log, the evening list, the printed marks, the Sent list and the senders' counts.
- `node tools/vol-someone-test.mjs` (`PORT` and `SITE` for a copy, `SHOTS`; after the sixth critic, Oct 15): "For someone else" and each person's age in a browser. At 1440 a first-timer as the contact: ticking the box keeps focus there, the box becomes "Their contact" and the names list opens under it with her last name; Enter without an age asks it; four people are four first names and four Enters (the age carried); four pills with × and "Sign up · Amos, Sarah, Noah and Ella"; on the server each under her email via her with their age (Ella Under 18); her email names them once (Who) with commas; Confirmed on her device is one line "Names hidden · Show all" and Show all shows the three adults, never Ella. It counts the interactions. At 390 the first-timer's age is required at its field; a 21-or-older shift asks it first and 18–20 shows "Open to under 21" with no form. Signed in with a registration (two Adults, a Young Folk of 15): the 15-year-old greyed "21 or older"; each Adult asked 18–20 or 21 or older once; the next such shift and a shift with no rule ask nothing; a certification asked of each, each kept. After the seventh critic: the contact, on none of the shifts, sees "4 people" (whose they are) and "Their week", never "Yours"; a new tab on her device has her name, email and phone filled in, and they go once the Confirm link signs her in; an age chosen on a refused shift goes with her to one open to her. After the eighth critic: each name's age asked (not carried); "Names don’t show · Show all"; a first-timer's place made on one device, then signed in on another: "Yours", "Pia · Waiting to confirm", Resend, no Sign up, and Your sign-ups lists it under Waiting to confirm. After the ninth critic: the first added person's last name starts blank, then carries the last added person's. 39 checks; shots in `.wp-local/shots/vs-sug/after-critic8/someone-test/`. It removes what it made.
- `node tools/vol-tour-test.mjs` (`PORT` for a copy, `SHOTS`; after the ninth critic, Oct 16): the Tour's open card at 390, 1100, 1280 and 1440 on Food's grid and Helpers (two lines; 72 px on a phone, 57 on a laptop, as tall as the closed strip; the spacer and `scroll-padding-bottom` following it), at 768, on the guide's tabs (sitting on the bar) and in a 1920 margin (over nothing); every tap 44 px, nothing under 12 px, no filled button of its own. 51 checks; it changes no data.
- `bash tools/vol-swap-2026.sh` (not run until Michael says yes): 2026's real SignUpGenius structure (`docs/28-signupgenius-2026-shifts.csv`) as 2027's shifts, in the seed and on the running site (`tools/vol-swap-shifts.php`), with the seed's Lodging desk rows kept and fresh made-up volunteers.
  - Env: `W`, `H`, `DPR`, `MOBILE`, `PROFILE` (cookies kept between runs: sign in once with the dev sign-in, then reuse the folder), `STRICT=1`, `KEEPGOING=1`, `QUIET=1`, `CONSOLE=1`.
  - It prints exceptions, console errors and failed requests (≥ 400). The exit code is non-zero on an exception or a failed step, and also on console errors and failed requests with `STRICT=1`.
- Phone screenshots: `W=390 H=844 node tools/browse.mjs <url> '[{"shot":"out.png"}]'`.
