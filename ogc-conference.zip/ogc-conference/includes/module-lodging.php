<?php
/**
 * Lodging (lodging area, Oct 10): the rooms board behind /annual-conference/lodging/.
 *
 * Households come from the registrations (records, kind "registrations"; register area). What Lodging
 * adds is kept here, in its own table, one row per thing, each with a version, so two members working at
 * once never overwrite each other (a stale change gets 409 and the row as it is now):
 *
 *   hh:<rid>      a household's rooms and Lodging's marks: rooms, older, ok (Looks right), near (a
 *                 household Lodging linked), note, keys (who gets a room's keys, when Lodging changes
 *                 it), snap (the registration as it was when its rooms were given, to see changes),
 *                 checkin, back (keys back per room), setup (linens and mattresses per room)
 *   yf:<pid>      a Youngfolk's room in their hall and who Lodging paired them with (mate)
 *   room:<id>     a room's own facts: hold (kept for whom), out (out of service), access, beds
 *   meta:*        published (the snapshot households see), mapping (the Form import's columns),
 *                 steps (What to do, ticked by hand), seen:<user> (for "Since Tuesday"), numbers
 *                 (the year in counts, kept after names are cleared)
 *   note:<id>     Notes for next year
 *   undo:<n>      the last changes, with what each row was before (Undo, ⌘Z, after a reload too)
 *   imp:<n>       an import's before-values (Undo import)
 *
 * What households see is the published snapshot only: the state value "rooms" ({rid: [room ids]}),
 * which register's Your sign-ups and the map's me/stay already read, and registration.csv's
 * rooms_posted. Moves after that wait for Send update.
 *
 * The routes are in module-lodging-rest.php, the Google Form import in module-lodging-import.php.
 */

defined( 'ABSPATH' ) || exit;

/* ================================================================== the table */

add_filter( 'ogc_schema', function ( $sql, $charset ) {
	$sql[] = 'CREATE TABLE ' . ogc_table( 'lodging' ) . " (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  year smallint(5) unsigned NOT NULL,
  rkey varchar(96) NOT NULL,
  data longtext NOT NULL,
  version int(10) unsigned NOT NULL DEFAULT 1,
  updated_by bigint(20) unsigned NOT NULL DEFAULT 0,
  updated_at datetime NULL,
  PRIMARY KEY  (id),
  UNIQUE KEY year_rkey (year,rkey)
) $charset;";
	return $sql;
}, 30, 2 );

// The table is new: make sure it exists on a site already installed (dbDelta runs when the SQL changes).
add_action( 'init', function () {
	if ( get_option( 'ogc_lodging_table' ) !== '1' && function_exists( 'ogc_install_schema' ) ) {
		ogc_install_schema( true );
		update_option( 'ogc_lodging_table', '1', false );
	}
}, 5 );

/* ================================================================== the page */

add_filter( 'ogc_pages', function ( $p ) {
	if ( isset( $p['lodging'] ) ) {
		$p['lodging']['template'] = 'lodging-board.php';
		$p['lodging']['scripts']  = array_values( array_diff( $p['lodging']['scripts'], array( 'lodging/lodging.js' ) ) );
		foreach ( array( 'lodging/lodging.js', 'lodging/lodging-plan.js', 'lodging/lodging-board.js', 'lodging/lodging-lists.js', 'lodging/lodging-import.js' ) as $s ) {
			$p['lodging']['scripts'][] = $s;
		}
		$p['lodging']['html_class']  = trim( $p['lodging']['html_class'] . ' adm-full' );
		$p['lodging']['description'] = 'Rooms, Youngfolks halls, the camper lot and check-in for the year\'s Lodging.';
	}
	return $p;
}, 20 );

// The board reads this year's registrations only (members get every one of the year).
add_filter( 'ogc_client_config', function ( $cfg, $key ) {
	if ( 'lodging' === $key ) {
		$cfg['recordKinds'] = array( 'registrations' );
		$cfg['recordYears'] = 1;
	}
	return $cfg;
}, 10, 2 );

/*
 * A household sees its own rooms (polish 1: "Rooms posted" with no room on Your sign-ups). rooms.csv
 * and plans.csv are withheld from the public (module-public.php: where people sleep is Lodging's), so
 * Your sign-ups, which draws the rooms from them, found nothing. Someone signed in whose own household
 * has published rooms gets back only the rows of the hall floors their rooms are on; the floor plans go
 * through the map's own rules first (a sample plan stays withheld), then the same cut. Nobody else's
 * rooms, names or halls are in it.
 */
add_filter( 'ogc_file_rows_out', function ( $rows, $year, $name, $member ) {
	if ( $member || ( 'rooms' !== $name && 'plans' !== $name ) || $rows ) {
		return $rows;
	}
	$floors = ogc_lod_my_floors( (int) $year );
	if ( ! $floors ) {
		return $rows;
	}
	$f = ogc_file_get( (int) $year, $name );
	if ( 'plans' === $name ) {
		$f = apply_filters( 'ogc_file_out', $f, (int) $year, 'plans' );
	}
	$out = array();
	foreach ( $f ? (array) $f['rows'] : array() as $r ) {
		$h  = isset( $r['hall'] ) ? (string) $r['hall'] : '';
		$fl = isset( $r['floor'] ) && '' !== (string) $r['floor'] ? (int) $r['floor'] : 0;
		if ( isset( $floors[ $h ] ) && ( ! $fl || isset( $floors[ $h ][ $fl ] ) ) ) {
			$out[] = $r;
		}
	}
	if ( $out ) {
		$GLOBALS['ogc_lod_private'] = true;
	}
	return $out;
}, 20, 4 );

// That answer is this person's alone: never kept by a browser cache or the guide's offline copy.
add_filter( 'rest_post_dispatch', function ( $res ) {
	if ( ! empty( $GLOBALS['ogc_lod_private'] ) && $res instanceof WP_REST_Response ) {
		$h = $res->get_headers();
		unset( $h['X-OGC-Public'], $h['ETag'] );
		$h['Cache-Control'] = 'private, no-store, max-age=0';
		$res->set_headers( $h );
	}
	return $res;
}, 40 );

/** The hall floors of the signed-in person's own published rooms: hall => [ floor => true ]. */
function ogc_lod_my_floors( $year ) {
	$email = ogc_current_email();
	if ( '' === $email ) {
		return array();
	}
	$cfg = ogc_lod_kv( $year, 'registration' );
	if ( empty( $cfg['rooms_posted'] ) ) {
		return array();
	}
	$st    = ogc_state_get( $year, 'rooms' );
	$snap  = $st && is_array( $st['value'] ) ? $st['value'] : array();
	$rooms = ogc_lod_rooms( $year );
	$out   = array();
	foreach ( ogc_records( $year, 'registrations', $email ) as $rec ) {
		$rid = isset( $rec['data']['rid'] ) ? (string) $rec['data']['rid'] : ( isset( $rec['data']['id'] ) ? (string) $rec['data']['id'] : '' );
		foreach ( '' !== $rid && isset( $snap[ $rid ] ) ? (array) $snap[ $rid ] : array() as $id ) {
			if ( isset( $rooms[ (string) $id ] ) ) {
				$out[ $rooms[ (string) $id ]['hall'] ][ $rooms[ (string) $id ]['floor'] ] = true;
			}
		}
	}
	return $out;
}

/* ================================================================== who may open Lodging */

/**
 * Who sees the board (where every household and every Youngfolk sleeps). Today: every member of the
 * year ("one level of access", Oct 6). The Advisors asked on Oct 9 that where people sleep be
 * "extremely secure", so registration.csv's lodging_access = lodging narrows it to the COA, helpers
 * whose "Helps with" names Lodging, and webmasters. Which one is the Advisors' and the COA's decision
 * (NOTES/questions-lodging.md); the default stays as decided until they say.
 */
function ogc_lod_may_see( $year ) {
	if ( ! ogc_is_member( $year ) ) {
		return false;
	}
	if ( ogc_is_webmaster() ) {
		return true;
	}
	$cfg = ogc_lod_kv( $year, 'registration' );
	if ( 'lodging' !== strtolower( isset( $cfg['lodging_access'] ) ? trim( $cfg['lodging_access'] ) : '' ) || ! function_exists( 'ogc_member_me' ) ) {
		return true;
	}
	$m = ogc_member_me( $year );
	if ( ! $m ) {
		return (bool) apply_filters( 'ogc_lod_may_see', false, $year );
	}
	$helps = function_exists( 'ogc_committee_key' ) ? ogc_committee_key( isset( $m['helps'] ) ? $m['helps'] : '' ) : strtolower( (string) ( isset( $m['helps'] ) ? $m['helps'] : '' ) );
	return 'coa' === $m['role'] || false !== strpos( $helps, 'lodging' ) || (bool) apply_filters( 'ogc_lod_may_see', false, $year );
}

/* ================================================================== rows */

function ogc_lod_key_ok( $k ) {
	return (bool) preg_match( '/^(hh|yf|room|meta|note|undo|imp):[A-Za-z0-9|._ :@-]{1,88}$/', (string) $k );
}

/** Every row of a year (optionally only keys starting with $prefix): rkey => array( data, v, by, at ). */
function ogc_lod_rows( $year, $prefix = '' ) {
	global $wpdb;
	$sql = 'SELECT rkey, data, version, updated_by, updated_at FROM ' . ogc_table( 'lodging' ) . ' WHERE year = %d';
	$arg = array( (int) $year );
	if ( '' !== $prefix ) {
		$sql  .= ' AND rkey LIKE %s';
		$arg[] = $wpdb->esc_like( $prefix ) . '%';
	}
	$out = array();
	foreach ( (array) $wpdb->get_results( $wpdb->prepare( $sql . ' ORDER BY id', $arg ), ARRAY_A ) as $r ) {
		$out[ $r['rkey'] ] = array( 'data' => ogc_unjson( $r['data'], array() ), 'v' => (int) $r['version'], 'by' => (int) $r['updated_by'], 'at' => $r['updated_at'] );
	}
	return $out;
}

function ogc_lod_row( $year, $key ) {
	global $wpdb;
	$r = $wpdb->get_row( $wpdb->prepare( 'SELECT data, version, updated_by, updated_at FROM ' . ogc_table( 'lodging' ) . ' WHERE year = %d AND rkey = %s', $year, $key ), ARRAY_A );
	return $r ? array( 'data' => ogc_unjson( $r['data'], array() ), 'v' => (int) $r['version'], 'by' => (int) $r['updated_by'], 'at' => $r['updated_at'] ) : null;
}

/**
 * Rows a member changes (a household's, a Youngfolk's, a room's facts, the steps) are never removed:
 * emptied, they stay as an empty row, so their version only ever goes up. A row removed and made again
 * would start at version 1 again, and a screen holding the old version 1 would overwrite it (red team,
 * Nov 4: ATK1-aba-ops; Undo the same, ATK1-aba-undo).
 */
function ogc_lod_keeps_version( $key ) {
	return (bool) preg_match( '/^(hh|yf|room):|^meta:(steps|notes_done)$/', (string) $key );
}

/** A row's data as the page gets it: an object, also when empty (an emptied row is {}). */
function ogc_lod_out( $data ) {
	return is_array( $data ) && ! $data ? (object) array() : $data;
}

/**
 * Write a row: $data null removes it (a row a member changes is emptied instead: ogc_lod_keeps_version).
 * With $expect (the version last seen; 0 = new) a newer row isn't overwritten. While this request holds
 * Lodging's lock, every write first checks it still does (and keeps it), so a change whose lock lapsed
 * and was taken by another never writes over theirs (ATK1-lock-lapse-double). Returns the new version
 * (0 when removed) or a WP_Error (409; 503 when the lock was lost).
 */
function ogc_lod_put( $year, $key, $data, $expect = null ) {
	global $wpdb;
	$t   = ogc_table( 'lodging' );
	if ( 'meta:lock' !== $key && ogc_lod_holding( $year ) && ! ogc_lod_lock_keep( $year ) ) {
		return ogc_lod_busy();
	}
	$cur = ogc_lod_row( $year, $key );
	$v   = $cur ? $cur['v'] : 0;
	if ( null !== $expect && (int) $expect !== $v ) {
		return new WP_Error( 'ogc_conflict', 'Changed since', array( 'status' => 409, 'key' => $key, 'version' => $v ) );
	}
	if ( null === $data ) {
		if ( ! $cur ) {
			return 0;
		}
		if ( ! ogc_lod_keeps_version( $key ) ) {
			$wpdb->query( $wpdb->prepare( "DELETE FROM $t WHERE year = %d AND rkey = %s AND version = %d", $year, $key, $v ) );
			return 0;
		}
		if ( ! $cur['data'] ) {
			return $v;   // already empty
		}
		$data = array();
	}
	if ( ! $cur ) {
		$ok = $wpdb->insert( $t, array( 'year' => (int) $year, 'rkey' => $key, 'data' => ogc_json( $data ), 'version' => 1, 'updated_by' => get_current_user_id(), 'updated_at' => ogc_now() ), array( '%d', '%s', '%s', '%d', '%d', '%s' ) );
		return $ok ? 1 : new WP_Error( 'ogc_conflict', 'Changed since', array( 'status' => 409, 'key' => $key ) );
	}
	$n = $wpdb->query( $wpdb->prepare( "UPDATE $t SET data = %s, version = version + 1, updated_by = %d, updated_at = %s WHERE year = %d AND rkey = %s AND version = %d", ogc_json( $data ), get_current_user_id(), ogc_now(), $year, $key, $v ) );
	return 1 === (int) $n ? $v + 1 : new WP_Error( 'ogc_conflict', 'Changed since', array( 'status' => 409, 'key' => $key ) );
}

/** Rows as the page gets them: { rkey: { data, v, by (a name), at } }, the bookkeeping rows left out. */
function ogc_lod_public_rows( $rows ) {
	$out   = array();
	$names = array();
	foreach ( $rows as $k => $r ) {
		// A registration change waiting for the lock (meta:pend:) is the server's own, never the board's.
		if ( preg_match( '/^(undo|imp|meta:seen|meta:sent|meta:pend):|^meta:lock$/', $k ) ) {
			continue;
		}
		$r['data'] = ogc_lod_out( $r['data'] );
		if ( ! isset( $names[ $r['by'] ] ) ) {
			$names[ $r['by'] ] = ogc_lod_name_of( $r['by'] );
		}
		$out[ $k ] = array( 'data' => $r['data'], 'v' => $r['v'], 'by' => $names[ $r['by'] ], 'at' => $r['at'] );
	}
	return (object) $out;
}

/* ================================================================== who and when */

/** A member as the page names them: "Ruth K." */
function ogc_lod_name_of( $user_id ) {
	$u = $user_id ? get_userdata( (int) $user_id ) : null;
	if ( ! $u ) {
		return '';
	}
	$n = trim( (string) $u->display_name );
	if ( '' === $n || false !== strpos( $n, '@' ) ) {
		$n = ucfirst( strtok( (string) $u->user_email, '@.' ) );
	}
	$w = preg_split( '/\s+/', $n );
	return count( $w ) > 1 ? $w[0] . ' ' . mb_substr( end( $w ), 0, 1 ) . '.' : $n;
}

function ogc_lod_me() {
	return ogc_lod_name_of( get_current_user_id() );
}

/** Today at the venue. A preview date (as_of) is taken on a local site, or from a webmaster. */
function ogc_lod_today( $year, $req = null, $real = false ) {
	// The app's own day for this request, when it has one (a read of the app previewing a date); never
	// for the real date (names are cleared by that alone).
	if ( ! $real && ! empty( $GLOBALS['ogc_app_as_of'] ) && preg_match( '/^\d{4}-\d\d-\d\d$/', (string) $GLOBALS['ogc_app_as_of'] ) ) {
		return (string) $GLOBALS['ogc_app_as_of'];
	}
	$as = $req instanceof WP_REST_Request && ( 'GET' === $req->get_method() || ogc_proto_saves() ) ? (string) $req->get_param( 'as_of' ) : '';
	// A preview date only reads (a change made while previewing is refused: ogc_appc_can), except in the shared prototype.
	if ( preg_match( '/^\d{4}-\d\d-\d\d$/', $as ) && ( ( function_exists( 'ogc_dev_tools_on' ) && ogc_dev_tools_on() ) || ogc_is_webmaster() ) ) {
		return $as;
	}
	$tz = function_exists( 'ogc_reg_tz' ) ? ogc_reg_tz( $year ) : new DateTimeZone( 'America/Indiana/Indianapolis' );
	$d  = new DateTime( 'now', $tz );
	return $d->format( 'Y-m-d' );
}

function ogc_lod_add_days( $iso, $n ) {
	$d = DateTime::createFromFormat( '!Y-m-d', (string) $iso, new DateTimeZone( 'UTC' ) );
	if ( ! $d ) {
		return '';
	}
	$d->modify( ( $n >= 0 ? '+' : '' ) . (int) $n . ' days' );
	return $d->format( 'Y-m-d' );
}

/** A file's key/value rows (registration.csv, settings.csv) as an array. */
function ogc_lod_kv( $year, $name ) {
	$f   = ogc_file_get( $year, $name );
	$out = array();
	foreach ( $f ? $f['rows'] : array() as $r ) {
		if ( isset( $r['key'] ) && '' !== $r['key'] && '#' !== substr( $r['key'], 0, 1 ) ) {
			$out[ $r['key'] ] = isset( $r['value'] ) ? (string) $r['value'] : '';
		}
	}
	return $out;
}

/**
 * Where the year stands for Lodging: start, end, the morning after the last night (checkout), held
 * (the Conference is over: rooms no longer move), the day names are cleared, and whether that day has
 * passed. The desk (Check in, Keys back) and Notes for next year keep working until the names are
 * cleared: the last morning is when most keys come back, and credits depend on them (the 2022 rule).
 * Cleared is decided by the real date too, so a preview date (as_of) never brings names back.
 */
function ogc_lod_phase( $year, $today ) {
	$row   = ogc_year_get( $year );
	$cfg   = ogc_lod_kv( $year, 'registration' );
	$end   = $row && ! empty( $row['end'] ) ? $row['end'] : '';
	$clear = $end ? ogc_lod_add_days( $end, ogc_lod_clear_days( $cfg ) ) : '';
	$real  = ogc_lod_today( $year, null, true );
	return array(
		'start'    => $row && ! empty( $row['start'] ) ? $row['start'] : '',
		'end'      => $end,
		'checkout' => $end ? ogc_lod_add_days( $end, 1 ) : '',
		'today'    => $today,
		'held'     => $end && $today > $end,
		'clear'    => $clear,
		'cleared'  => $clear && ( $today >= $clear || $real >= $clear ),
		'gone'     => $clear && $real >= $clear,   // by the real date: the rows may be removed
	);
}

/** How many days after the Conference's last day names are cleared (registration.csv clear_after_days, set
 * by the webmasters): 60 when blank or not a number, and never before the morning after check-out morning,
 * so the desk always keeps check-out morning, when most keys come back (red team round 3, ATK4-r3-07 to
 * -09, -12: 0, -60 or -60000 cleared every placement the moment the board was opened). */
function ogc_lod_clear_days( $cfg ) {
	$v = isset( $cfg['clear_after_days'] ) ? trim( (string) $cfg['clear_after_days'] ) : '';
	return is_numeric( $v ) ? max( 2, (int) $v ) : 60;
}

/** A change only the desk makes (Check in, keys out, Keys back), which may go on after the Conference. */
function ogc_lod_desk_only( $old, $new ) {
	$desk = array( 'checkin' => 1, 'back' => 1, 'keysout' => 1, 'left' => 1 );
	$a    = array_diff_key( is_array( $old ) ? $old : array(), $desk );
	$b    = array_diff_key( is_array( $new ) ? $new : array(), $desk );
	return ogc_lod_same( $a, $b );
}

/** The same data, whatever order its keys were written in. */
function ogc_lod_same( $a, $b ) {
	$norm = function ( $v ) use ( &$norm ) {
		if ( is_object( $v ) ) {
			$v = (array) $v;
		}
		if ( is_array( $v ) ) {
			ksort( $v );
			return array_map( $norm, $v );
		}
		return $v;
	};
	return ogc_json( $norm( $a ) ) === ogc_json( $norm( $b ) );
}

/* ================================================================== the year's rooms and households */

/** Every room id in the year's halls (rooms.csv: hall, first, last, floor, beds, for): id => array( hall,
 * num, floor, for, beds ). beds is the hall's own number (0 when blank); ogc_lod_beds() is the one answer. */
function ogc_lod_rooms( $year ) {
	return ogc_lod_rooms_of_rows( ( $f = ogc_file_get( $year, 'rooms' ) ) ? $f['rows'] : array() );
}

/** The rooms some rows of rooms.csv make (the halls as they are, or as a change would leave them). */
function ogc_lod_rooms_of_rows( $rows ) {
	$out = array();
	foreach ( (array) $rows as $r ) {
		$r = (array) $r;
		if ( empty( $r['hall'] ) || '#' === substr( $r['hall'], 0, 1 ) || ! is_numeric( isset( $r['first'] ) ? $r['first'] : '' ) || ! is_numeric( isset( $r['last'] ) ? $r['last'] : '' ) ) {
			continue;
		}
		for ( $n = (int) $r['first']; $n <= (int) $r['last'] && $n - (int) $r['first'] < 400; $n++ ) {
			$out[ $r['hall'] . '|' . $n ] = array( 'hall' => $r['hall'], 'num' => $n, 'floor' => (int) ( isset( $r['floor'] ) ? $r['floor'] : 1 ), 'for' => strtolower( trim( isset( $r['for'] ) && '' !== $r['for'] ? $r['for'] : 'families' ) ), 'beds' => isset( $r['beds'] ) && is_numeric( $r['beds'] ) ? max( 0, min( 8, (int) $r['beds'] ) ) : 0 );   // 1–8 as Lodging's own fact; the halls' door refuses others (red team round 2, K3_E3)
		}
	}
	return $out;
}

/**
 * A room's beds, from one place for every check (invariant 6): Lodging's own fact for the room this
 * year, else the fact carried from the last Conference at this campus, else the hall's beds in
 * rooms.csv, else registration.csv's room_beds, else 2.
 */
function ogc_lod_beds( $y, $id, $rooms = null, $facts = null ) {
	$rooms = null === $rooms ? ogc_lod_rooms( $y ) : $rooms;
	$facts = null === $facts ? ogc_lod_facts( $y ) : $facts;
	if ( ! empty( $facts[ $id ]['beds'] ) ) {
		return max( 1, (int) $facts[ $id ]['beds'] );
	}
	if ( ! empty( $rooms[ $id ]['beds'] ) ) {
		return (int) $rooms[ $id ]['beds'];
	}
	// A change to registration.csv's room_beds is judged with the number it would set (ogc_lod_cfg_change_wrong).
	if ( isset( $GLOBALS['ogc_lod_try_room_beds'][ (int) $y ] ) ) {
		return max( 1, (int) $GLOBALS['ogc_lod_try_room_beds'][ (int) $y ] );
	}
	$cfg = ogc_lod_kv( $y, 'registration' );
	return isset( $cfg['room_beds'] ) && is_numeric( $cfg['room_beds'] ) && (int) $cfg['room_beds'] > 0 ? (int) $cfg['room_beds'] : 2;
}

/** Each room's facts this year: the last Conference's at this campus (beds, access, out), with this
 * year's own on top. id => facts. */
function ogc_lod_facts( $y ) {
	$out = array();
	$c   = function_exists( 'ogc_lod_carry' ) ? ogc_lod_carry( $y ) : null;
	foreach ( $c ? (array) $c['rooms'] : array() as $id => $f ) {
		$out[ $id ] = (array) $f;
	}
	foreach ( ogc_lod_rows( $y, 'room:' ) as $k => $r ) {
		$id         = substr( $k, 5 );
		$out[ $id ] = array_merge( isset( $out[ $id ] ) ? $out[ $id ] : array(), (array) $r['data'] );
	}
	return $out;
}

/** The year's rooms, read once a request for as long as rooms.csv stays the same version (the lists). */
function ogc_lod_rooms_memo( $y ) {
	$f   = ogc_file_get( $y, 'rooms' );
	$key = (int) $y . '|' . ( $f ? $f['version'] . '|' . ( isset( $f['updated_at'] ) ? $f['updated_at'] : '' ) : '0' );
	if ( ! isset( $GLOBALS['ogc_lod_rooms_memo'][ $key ] ) ) {
		$GLOBALS['ogc_lod_rooms_memo'] = array( $key => ogc_lod_rooms_of_rows( $f ? $f['rows'] : array() ) );
	}
	return $GLOBALS['ogc_lod_rooms_memo'][ $key ];
}

/** Has Lodging given this registration a room (a family room, or a hall room to one of its Youngfolks)? */
function ogc_lod_has_rooms( $rec ) {
	$y     = (int) $rec['year'];
	$rid   = ogc_lod_rid( $rec );
	$rooms = ogc_lod_rooms_memo( $y );
	$row   = '' !== $rid ? ogc_lod_row( $y, 'hh:' . $rid ) : null;
	if ( $row && ogc_lod_real( isset( $row['data']['rooms'] ) ? $row['data']['rooms'] : array(), $rooms ) ) {
		return true;
	}
	foreach ( (array) ( isset( $rec['data']['people'] ) ? $rec['data']['people'] : array() ) as $p ) {
		$yr = ! empty( $p['yf'] ) && ! empty( $p['pid'] ) ? ogc_lod_row( $y, 'yf:' . $p['pid'] ) : null;
		if ( $yr && ! empty( $yr['data']['room'] ) && isset( $rooms[ (string) $yr['data']['room'] ] ) ) {
			return true;
		}
	}
	return false;
}

/** Is this room for families (rooms.csv For)? Every other For (young men, young women) is a hall's. */
function ogc_lod_family_room( $room ) {
	return is_array( $room ) && 'families' === ( isset( $room['for'] ) ? $room['for'] : 'families' );
}

/** Which hall a Youngfolks room is for: 'men', 'women', or '' (not a Youngfolks room). */
function ogc_lod_yf_hall_of( $room ) {
	$f = is_array( $room ) && isset( $room['for'] ) ? (string) $room['for'] : '';
	if ( 0 !== strpos( $f, 'young' ) ) {
		return '';
	}
	return false !== strpos( $f, 'women' ) ? 'women' : ( false !== strpos( $f, 'men' ) ? 'men' : '' );
}

/** A household's rooms as Lodging gave them, real ones only, in order (no empty places, none a change
 * to the halls took away). */
function ogc_lod_real( $list, $rooms ) {
	$out = array();
	foreach ( (array) $list as $id ) {
		$id = (string) $id;
		if ( '' !== $id && isset( $rooms[ $id ] ) && ! in_array( $id, $out, true ) ) {
			$out[] = $id;
		}
	}
	return $out;
}

function ogc_lod_room_words( $id ) {
	$p = explode( '|', (string) $id );
	return count( $p ) > 1 ? $p[0] . ' ' . $p[1] : (string) $id;
}

/** The year's registrations, by their rid: rid => record. */
function ogc_lod_households( $year ) {
	$out = array();
	foreach ( ogc_records( (int) $year, 'registrations' ) as $r ) {
		$rid = isset( $r['data']['rid'] ) ? (string) $r['data']['rid'] : ( isset( $r['data']['id'] ) ? (string) $r['data']['id'] : '' );
		if ( '' !== $rid ) {
			$out[ $rid ] = $r;
		}
	}
	return $out;
}

/** Is this household in dorm rooms now (not cancelled, not moved to the camper lot)? */
function ogc_lod_in_dorm( $rec ) {
	$d = $rec['data'];
	return 'dorm' === ( isset( $d['stay']['type'] ) ? $d['stay']['type'] : '' ) && 'cancelled' !== ( isset( $d['status'] ) ? $d['status'] : '' );
}

/** The COA's Didn't come marks for the year: rid => { s, at, by }. */
function ogc_lod_marks( $y ) {
	$m = ogc_state_get( (int) $y, 'reg_marks' );
	return $m && is_array( $m['value'] ) ? $m['value'] : array();
}

function ogc_lod_rid( $rec ) {
	$d = isset( $rec['data'] ) && is_array( $rec['data'] ) ? $rec['data'] : array();
	return isset( $d['rid'] ) && '' !== $d['rid'] ? (string) $d['rid'] : ( isset( $d['id'] ) ? (string) $d['id'] : '' );
}

/** Marked Didn't come by the COA? */
function ogc_lod_noshow( $rec, $marks ) {
	$rid = ogc_lod_rid( $rec );
	return '' !== $rid && isset( $marks[ $rid ]['s'] ) && 'noshow' === $marks[ $rid ]['s'];
}

/**
 * May this household hold family rooms now? In dorm rooms, not cancelled, not marked Didn't come. A
 * household on the waiting list keeps any it was given (invariant 40: nothing is freed silently) but is
 * never given new ones, never shown its rooms and never counted (ogc_lod_coming).
 */
function ogc_lod_holds( $rec, $marks = array() ) {
	return ogc_lod_in_dorm( $rec ) && ! ogc_lod_noshow( $rec, $marks );
}

/** Will this registration come? Not cancelled, not on the waiting list, not Didn't come. */
function ogc_lod_reg_coming( $rec, $marks = array() ) {
	$st = isset( $rec['data']['status'] ) ? (string) $rec['data']['status'] : '';
	return ! in_array( $st, array( 'cancelled', 'waitlist' ), true ) && ! ogc_lod_noshow( $rec, $marks );
}

/** A household that will come to its dorm rooms: what households see, Counts and the year card follow these. */
function ogc_lod_coming( $rec, $marks = array() ) {
	return ogc_lod_holds( $rec, $marks ) && ogc_lod_reg_coming( $rec, $marks );
}

/** Does this person sleep in a Youngfolks hall on this registration? */
function ogc_lod_in_hall( $p, $d ) {
	$type = isset( $d['stay']['type'] ) ? (string) $d['stay']['type'] : '';
	return ! empty( $p['yf'] ) && ( 'yf' === $type || 'family' !== ( isset( $p['sleeps'] ) ? $p['sleeps'] : 'hall' ) );
}

/** May this Youngfolk keep a hall room: sleeping in the hall, on a registration not cancelled or marked
 * Didn't come, and approved by a parent where one must approve (one on the waiting list keeps it, and is
 * never given one). */
function ogc_lod_yf_holds( $p, $rec, $marks = array() ) {
	return '' === ogc_lod_yf_why_not( $p, $rec, $marks );
}

/** Why this Youngfolk may not keep a hall room now, in words ('' when they may). An under-18 whose
 * parent must approve and hasn't (a registration changed after placing: an age corrected to 17, the one
 * grown-up taken off) holds no hall room until the parent says yes (invariant 34; red team A6, B8). */
function ogc_lod_yf_why_not( $p, $rec, $marks = array() ) {
	$d = isset( $rec['data'] ) && is_array( $rec['data'] ) ? $rec['data'] : array();
	if ( 'cancelled' === ( isset( $d['status'] ) ? $d['status'] : '' ) ) {
		return 'Cancelled';
	}
	if ( ogc_lod_noshow( $rec, $marks ) ) {
		return 'Didn’t come';
	}
	if ( ! ogc_lod_in_hall( $p, $d ) ) {
		return 'With the family';
	}
	if ( ogc_lod_approval_waits( $p, $d ) ) {
		return ogc_lod_approval_words( $p, $d );
	}
	// Under the COA's youngest age for Youngfolks (yf_min_age, read as the form reads it): never a hall
	// room, however the age came to be (red team round 3, ATK3 A4: the Form sent again with the age
	// corrected to 12 kept the hall room).
	$y = isset( $rec['year'] ) ? (int) $rec['year'] : 0;
	if ( $y && is_numeric( isset( $p['age'] ) ? trim( (string) $p['age'] ) : '' ) ) {
		$min = ogc_lod_yf_min( ogc_lod_kv( $y, 'registration' ) );
		if ( $min && (int) $p['age'] < $min ) {
			return 'Under ' . $min;
		}
	}
	return '';
}

/** The youngest age for a Youngfolk, as the form reads it (ogc_reg_c's default: 16 when blank; red team
 * round 3, ATK3 A3: blank read as 16 by the form and as no limit by Lodging). 0: no limit. */
function ogc_lod_yf_min( $cfg ) {
	$v = isset( $cfg['yf_min_age'] ) && '' !== (string) $cfg['yf_min_age'] ? $cfg['yf_min_age'] : '16';
	return max( 0, (int) $v );
}

/**
 * Must a parent approve this Youngfolk, and hasn't yet? (the register area's rule, ogc_reg_approval_people)
 * A parent's yes is for the people it named (approval.who, kept when they approved): someone added to the
 * registration since waits for the parent too (red team round 3, ATK3 A1: a 16-year-old added weeks after
 * his friend's approval was given a hall room no parent approved). An older approval that names nobody
 * covers everyone, as it did.
 */
function ogc_lod_approval_waits( $p, $d ) {
	if ( empty( $p['pid'] ) || ! function_exists( 'ogc_reg_approval_people' ) ) {
		return false;
	}
	if ( ! in_array( (string) $p['pid'], array_map( 'strval', wp_list_pluck( ogc_reg_approval_people( $d ), 'pid' ) ), true ) ) {
		return false;
	}
	if ( 'approved' !== ( isset( $d['approval']['state'] ) ? $d['approval']['state'] : '' ) ) {
		return true;
	}
	$who = isset( $d['approval']['who'] ) && is_array( $d['approval']['who'] ) ? $d['approval']['who'] : array();
	return $who && ! in_array( (string) $p['pid'], array_map( 'strval', wp_list_pluck( $who, 'pid' ) ), true );
}

/** Why a parent's approval holds this Youngfolk, in words: declined, not named in the approval given, or
 * still waiting. */
function ogc_lod_approval_words( $p, $d ) {
	$st = isset( $d['approval']['state'] ) ? (string) $d['approval']['state'] : '';
	return 'declined' === $st ? 'Parent declined' : ( 'approved' === $st ? 'Not in the parent’s approval' : 'Approval waiting' );
}

/* ================================================================== one change at a time */

/**
 * Lodging's lock: one change to who holds which room at a time, for the whole year (two Lodging members,
 * the desk, a registration change, an import, a Publish). A row of Lodging's own table is the lock, so
 * taking it is a single insert the database refuses twice (atomic on MySQL and SQLite alike); a lock left
 * by a request that died lapses after 30 seconds. Waits up to $tenths tenths of a second.
 *
 * Order, so two locks never wait on each other: the registration's lock (ogc_reg_lock) first, then this.
 *
 * Each taking has its own mark (a token in the row), so only its holder removes it: a change that held
 * the lock past 30 seconds never removes the lock someone took after it lapsed (ATK1-lock-lapse-double),
 * and its own later writes are refused (ogc_lod_put checks the mark before every write and keeps the lock
 * for another 30 seconds). Returns the token, or false.
 */
function ogc_lod_lock( $y, $tenths = 30 ) {
	global $wpdb;
	// A step inside a change this request already holds the lock for (a guard holds it for the whole
	// request): nested, let go by the outer one.
	if ( ogc_lod_holding( $y ) ) {
		$GLOBALS['ogc_lod_nest'][ (int) $y ] = ( isset( $GLOBALS['ogc_lod_nest'][ (int) $y ] ) ? (int) $GLOBALS['ogc_lod_nest'][ (int) $y ] : 0 ) + 1;
		return $GLOBALS['ogc_lod_held'][ (int) $y ];
	}
	$t     = ogc_table( 'lodging' );
	$prev  = $wpdb->suppress_errors( true );
	$token = '';
	for ( $i = 0; $i < $tenths; $i++ ) {
		$try = strtolower( wp_generate_password( 16, false, false ) );
		if ( $wpdb->insert( $t, array( 'year' => (int) $y, 'rkey' => 'meta:lock', 'data' => ogc_json( array( 'until' => time() + 30, 't' => $try ) ), 'version' => 1, 'updated_by' => get_current_user_id(), 'updated_at' => ogc_now() ), array( '%d', '%s', '%s', '%d', '%d', '%s' ) ) ) {
			$token = $try;
			break;
		}
		$cur = ogc_lod_row( $y, 'meta:lock' );
		if ( $cur && (int) ( isset( $cur['data']['until'] ) ? $cur['data']['until'] : 0 ) < time() ) {
			$wpdb->query( $wpdb->prepare( "DELETE FROM $t WHERE year = %d AND rkey = 'meta:lock' AND version = %d", $y, $cur['v'] ) );
			continue;
		}
		usleep( 100000 );
	}
	$wpdb->suppress_errors( $prev );
	if ( '' === $token ) {
		return false;
	}
	$GLOBALS['ogc_lod_held'][ (int) $y ] = $token;
	// Whatever was read before the lock may be stale now: read the year's files and state again.
	ogc_store_forget();
	$GLOBALS['ogc_reg_cfg_stale'] = true;
	unset( $GLOBALS['ogc_lod_rooms_memo'] );
	// A registration change that couldn't wait for the lock is freed first (ogc_lod_reg_saved).
	ogc_lod_pending( $y );
	return $token;
}

/** Let go of Lodging's lock: only the taking named by $token (this request's own when not given). */
function ogc_lod_unlock( $y, $token = null ) {
	global $wpdb;
	if ( null === $token && ! empty( $GLOBALS['ogc_lod_nest'][ (int) $y ] ) ) {
		$GLOBALS['ogc_lod_nest'][ (int) $y ]--;
		return;
	}
	unset( $GLOBALS['ogc_lod_nest'][ (int) $y ] );
	$mine  = isset( $GLOBALS['ogc_lod_held'][ (int) $y ] ) ? (string) $GLOBALS['ogc_lod_held'][ (int) $y ] : '';
	$token = null === $token ? $mine : (string) $token;
	if ( '' !== $mine && $mine === $token ) {
		// Before letting go: a registration change that came while this change held the lock (and so
		// couldn't free its rooms) is freed now, against the rows as this change wrote them (red team round
		// 2, ATK1-r2-busy-free-lost: a camper household's row kept the dorm room Assign all wrote).
		ogc_lod_pending( $y );
		unset( $GLOBALS['ogc_lod_held'][ (int) $y ] );
	}
	if ( '' === $token ) {
		return;
	}
	$wpdb->query( $wpdb->prepare( 'DELETE FROM ' . ogc_table( 'lodging' ) . " WHERE year = %d AND rkey = 'meta:lock' AND data LIKE %s", $y, '%' . $wpdb->esc_like( '"t":"' . $token . '"' ) . '%' ) );
}

/** Does this request still hold Lodging's lock? Keeps it for another 30 seconds when it does. */
function ogc_lod_lock_keep( $y ) {
	global $wpdb;
	$token = isset( $GLOBALS['ogc_lod_held'][ (int) $y ] ) ? (string) $GLOBALS['ogc_lod_held'][ (int) $y ] : '';
	if ( '' === $token ) {
		return false;
	}
	// The version moves too, so the row always changes (MySQL counts an unchanged row as not updated).
	$n = $wpdb->query( $wpdb->prepare( 'UPDATE ' . ogc_table( 'lodging' ) . " SET data = %s, version = version + 1 WHERE year = %d AND rkey = 'meta:lock' AND data LIKE %s", ogc_json( array( 'until' => time() + 30, 't' => $token ) ), $y, '%' . $wpdb->esc_like( '"t":"' . $token . '"' ) . '%' ) );
	if ( 1 !== (int) $n ) {
		unset( $GLOBALS['ogc_lod_held'][ (int) $y ] );
		return false;
	}
	return true;
}

/** Does this request already hold Lodging's lock (a step inside one of its own changes)? */
function ogc_lod_holding( $y ) {
	return ! empty( $GLOBALS['ogc_lod_held'][ (int) $y ] );
}

function ogc_lod_busy() {
	return new WP_Error( 'ogc_busy', 'Busy · Try again', array( 'status' => 503 ) );
}

/* ================================================================== who holds which room */

/** Has the desk checked this household in (its Lodging row)? A household checked in holds its rooms,
 * whatever its registration says since, until the desk undoes the check-in (invariant 57; red team H1,
 * H3, G1: the room was freed with the keys still out, and given to a walk-in). */
function ogc_lod_checked_in( $d ) {
	return is_array( $d ) && ! empty( $d['checkin']['at'] );
}

/** Is a Youngfolk's hall key out (their Lodging row: Key out, not handed back)? The room is held, as a
 * checked-in household's is, until the key is recorded back (rule 61). */
function ogc_lod_key_out( $d ) {
	return is_array( $d ) && ! empty( $d['keyout'] ) && ! empty( $d['room'] );
}

/** Has Lodging decided this household's rooms (its row: rooms given, or once given and taken away, or
 * freed by a change)? A room it chose on the map counts only until then. */
function ogc_lod_decided( $d ) {
	return is_array( $d ) && ( ! empty( $d['rooms'] ) || ! empty( $d['given'] ) || ! empty( $d['cleared'] ) || ! empty( $d['freed'] ) );
}

/** The keys a registration has out now: its household's check-in, its Youngfolks' hall keys. Words for a
 * refusal ("Checked in", "Key out · Hope"), or '' when none. */
function ogc_lod_keys_out_words( $y, $rec ) {
	$rid = ogc_lod_rid( $rec );
	$row = '' !== $rid ? ogc_lod_row( $y, 'hh:' . $rid ) : null;
	if ( $row && ogc_lod_checked_in( (array) $row['data'] ) ) {
		return 'Checked in';
	}
	foreach ( (array) ( isset( $rec['data']['people'] ) ? $rec['data']['people'] : array() ) as $p ) {
		$yr = ! empty( $p['yf'] ) && ! empty( $p['pid'] ) ? ogc_lod_row( $y, 'yf:' . $p['pid'] ) : null;
		if ( $yr && ogc_lod_key_out( (array) $yr['data'] ) ) {
			return 'Key out · ' . ogc_lod_first( $p['name'] );
		}
	}
	return '';
}

/**
 * Every claim on a room that counts, from Lodging's rows ($rows: rkey => data) and the households in
 * $ctx (hh, marks, rooms): a household that may hold rooms (ogc_lod_holds) or that the desk checked in, a
 * Youngfolk who may keep a hall room (ogc_lod_yf_holds), a room still in the halls. Where households
 * choose their rooms on the map (room_choice = households: $ctx['chosen']), a household Lodging hasn't
 * given rooms claims the rooms it chose, as the board shows them (L.given); $except is a row left out
 * (whose rooms are being judged). room => [rkeys].
 */
function ogc_lod_claims( $ctx, $rows, $except = '' ) {
	$own = array();
	$yfp = ogc_lod_yf_people( $ctx );
	$got = array();
	foreach ( $rows as $k => $d ) {
		$d    = (array) $d;
		$list = array();
		if ( 0 === strpos( $k, 'hh:' ) ) {
			$rid = substr( $k, 3 );
			// The desk's keys are out: the rooms are held whatever the registration says, even with the
			// registration gone (red team round 2, I2 / K3_F5: an import removed a checked-in household and
			// its room read as free to a walk-in).
			if ( ( isset( $ctx['hh'][ $rid ] ) && ogc_lod_holds( $ctx['hh'][ $rid ], $ctx['marks'] ) ) || ogc_lod_checked_in( $d ) ) {
				$list = ogc_lod_real( isset( $d['rooms'] ) ? $d['rooms'] : array(), $ctx['rooms'] );
			}
			if ( $list || ogc_lod_decided( $d ) ) {
				$got[ $rid ] = true;
			}
		} elseif ( 0 === strpos( $k, 'yf:' ) && ! empty( $d['room'] ) && isset( $ctx['rooms'][ (string) $d['room'] ] ) ) {
			$pid = substr( $k, 3 );
			// A Youngfolk whose key is out holds the hall room, as a checked-in household does (red team
			// round 2, D1, D2: cancelled or marked Didn't come with the key out, the room went to three others).
			if ( ( isset( $yfp[ $pid ] ) && ogc_lod_yf_holds( $yfp[ $pid ]['p'], $ctx['hh'][ $yfp[ $pid ]['rid'] ], $ctx['marks'] ) ) || ogc_lod_key_out( $d ) ) {
				$list = array( (string) $d['room'] );
			}
		}
		foreach ( $list as $room ) {
			$own[ $room ][] = $k;
		}
	}
	// A room chosen on the map counts only until Lodging decides the household's rooms (gives, moves or
	// takes them, or a change frees them): "chosen until Lodging changes it" (red team round 2,
	// ATK1-r2-unplace-old-choice, -old-choice-comes-back: an old choice came back as a claim).
	foreach ( isset( $ctx['chosen'] ) ? (array) $ctx['chosen'] : array() as $rid => $list ) {
		if ( isset( $got[ $rid ] ) || 'hh:' . $rid === $except || ! isset( $ctx['hh'][ $rid ] ) || ! ogc_lod_holds( $ctx['hh'][ $rid ], $ctx['marks'] ) ) {
			continue;
		}
		if ( isset( $rows[ 'hh:' . $rid ] ) && ogc_lod_decided( (array) $rows[ 'hh:' . $rid ] ) ) {
			continue;
		}
		foreach ( ogc_lod_real( $list, $ctx['rooms'] ) as $room ) {
			$own[ $room ][] = 'hh:' . $rid;
		}
	}
	return $own;
}

/** Every Youngfolk of the year's registrations: pid => { p, rid }. */
function ogc_lod_yf_people( $ctx ) {
	if ( isset( $ctx['yfp'] ) ) {
		return $ctx['yfp'];
	}
	$out = array();
	foreach ( $ctx['hh'] as $rid => $rec ) {
		foreach ( (array) ( isset( $rec['data']['people'] ) ? $rec['data']['people'] : array() ) as $p ) {
			if ( ! empty( $p['yf'] ) && ! empty( $p['pid'] ) ) {
				$out[ (string) $p['pid'] ] = array( 'p' => $p, 'rid' => (string) $rid );
			}
		}
	}
	return $out;
}

/** How many Youngfolks a hall room takes: its beds + 1, three at most (lodging-assumptions B19; Lodging
 * Q3 asks two or three). */
function ogc_lod_yf_cap( $ctx, $room ) {
	return min( 3, ogc_lod_beds( $ctx['y'], $room, $ctx['rooms'], $ctx['facts'] ) + 1 );
}

/** Who holds a claim, in words: the household ("Hammond · Levi and Ruth"), or "Youngfolks". */
function ogc_lod_who( $ctx, $k ) {
	if ( 0 === strpos( $k, 'hh:' ) ) {
		return isset( $ctx['hh'][ substr( $k, 3 ) ] ) ? ogc_lod_label( $ctx['hh'][ substr( $k, 3 ) ]['data'] ) : 'Not registered';
	}
	return 'Youngfolks';
}

/** How many places (the form's Room 1, Room 2…) a household's rooms have: the rooms Lodging gave, in
 * place, or the rooms it asked for, the more (one rule for the beds check and the counts: red team D1). */
function ogc_lod_places( $d, $list ) {
	return max( 1, count( (array) $list ), (int) ( isset( $d['stay']['rooms'] ) ? $d['stay']['rooms'] : 1 ) );
}

/** The place a person sleeps in, among $n: the form's Room i+1 (0 when not said). */
function ogc_lod_slot( $p, $n ) {
	return isset( $p['room'] ) && null !== $p['room'] && '' !== $p['room'] ? min( max( 0, (int) $p['room'] ), max( 1, (int) $n ) - 1 ) : 0;
}

/** The people sleeping in a household's rooms (no hall Youngfolk; a baby under 3 isn't counted): all of
 * them, or those in place $slot of $n. */
function ogc_lod_sleepers( $d, $n = 1, $slot = null ) {
	$out = array();
	foreach ( (array) ( isset( $d['people'] ) ? $d['people'] : array() ) as $p ) {
		if ( empty( $p['name'] ) || ogc_lod_in_hall( $p, $d ) || 'baby' === ( isset( $p['band'] ) ? $p['band'] : '' ) ) {
			continue;
		}
		if ( null === $slot || ogc_lod_slot( $p, $n ) === (int) $slot ) {
			$out[] = $p;
		}
	}
	return $out;
}

/** A household from the Google Form: nobody there chose who sleeps in which room (the import's split is a
 * guess), so its rooms are judged together: everyone sleeping against all its rooms' beds + 1 (red team
 * A6: seven people and "1 room" could never be placed in three rooms). */
function ogc_lod_pooled( $rec ) {
	$src = isset( $rec['source'] ) ? (string) $rec['source'] : '';
	return 'form' === $src || ( '' === $src && 'form' === ( isset( $rec['data']['source'] ) ? $rec['data']['source'] : '' ) );
}

/**
 * What's wrong with a room's holders: the one check every path uses (placing, Undo, Cancel's Undo, Undo
 * import, coming back, the halls changing, the board's list, Publish). array( code, words, status, err )
 * or null. Codes: taken (two households, or a household with Youngfolks: invariants 1, 4), full (more
 * Youngfolks than it takes: 29), for (a family in a room not for families: 3), hall (a Youngfolk in a room
 * not of their hall: 26), over (more sleeping in a family room than its beds + 1, babies under 3 not
 * counted: 5), ages (an under-18 and an 18-and-up together where the campus has the state's rule: 32).
 * With $all, also what is flagged but never refused: out (a room out of service with someone in it: 37),
 * held (a household the desk checked in that its registration no longer lets hold rooms: 57).
 * $keys: the room's holders (ogc_lod_claims); $rows: Lodging's rows (rkey => data) their places are read
 * from; $mine: the keys of the change being checked (the other holder is the one named).
 */
function ogc_lod_room_issue( $ctx, $room, $keys, $rows, $all = false, $mine = array() ) {
	$r     = isset( $ctx['rooms'][ $room ] ) ? $ctx['rooms'][ $room ] : null;
	$words = ogc_lod_room_words( $room );
	$mk    = function ( $code, $w, $status, $err ) {
		return array( 'code' => $code, 'words' => $w, 'status' => $status, 'err' => $err );
	};
	if ( ! $r ) {
		return $mk( 'gone', $words . ' · Not in the halls', 400, 'ogc_bad' );
	}
	$fam   = array_values( array_filter( $keys, function ( $k ) { return 0 === strpos( $k, 'hh:' ); } ) );
	$yfs   = array_values( array_filter( $keys, function ( $k ) { return 0 === strpos( $k, 'yf:' ); } ) );
	$other = array_values( array_diff( $keys, $mine ) );
	if ( count( $fam ) > 1 || ( $fam && $yfs ) ) {
		return $mk( 'taken', 'Room ' . $words . ' is taken · ' . ogc_lod_who( $ctx, $other ? $other[0] : $keys[0] ), 409, 'ogc_conflict' );
	}
	$facts = isset( $ctx['facts'][ $room ] ) ? (array) $ctx['facts'][ $room ] : array();
	$beds  = ogc_lod_beds( $ctx['y'], $room, $ctx['rooms'], $ctx['facts'] );
	if ( $fam ) {
		$k   = $fam[0];
		$rid = substr( $k, 3 );
		$rec = isset( $ctx['hh'][ $rid ] ) ? $ctx['hh'][ $rid ] : null;
		if ( ! ogc_lod_family_room( $r ) ) {
			return $mk( 'for', $words . ' · For ' . $r['for'], 400, 'ogc_not_family' );
		}
		if ( $rec ) {
			$d    = $rec['data'];
			$list = isset( $rows[ $k ]['rooms'] ) ? array_values( array_map( 'strval', (array) $rows[ $k ]['rooms'] ) ) : array();
			if ( ! ogc_lod_real( $list, $ctx['rooms'] ) && isset( $ctx['chosen'][ $rid ] ) ) {
				$list = array_values( array_map( 'strval', (array) $ctx['chosen'][ $rid ] ) );
			}
			if ( ogc_lod_pooled( $rec ) ) {
				$cap = 0;
				foreach ( ogc_lod_real( $list, $ctx['rooms'] ) as $id ) {
					$cap += ogc_lod_beds( $ctx['y'], $id, $ctx['rooms'], $ctx['facts'] ) + 1;
				}
				$n = count( ogc_lod_sleepers( $d ) );
				if ( $n > $cap ) {
					return $mk( 'over', $words . ' · ' . $n . ' people · Rooms sleep ' . $cap, 409, 'ogc_over' );
				}
			} else {
				$slot = array_search( (string) $room, $list, true );
				$n    = count( ogc_lod_sleepers( $d, ogc_lod_places( $d, $list ), false === $slot ? 0 : $slot ) );
				if ( $n > $beds + 1 ) {
					return $mk( 'over', $words . ' sleeps ' . ( $beds + 1 ) . ' · ' . $n . ' in Room ' . ( ( false === $slot ? 0 : $slot ) + 1 ), 409, 'ogc_over' );
				}
			}
			if ( $all && ogc_lod_checked_in( isset( $rows[ $k ] ) ? (array) $rows[ $k ] : array() ) && ! ogc_lod_holds( $rec, $ctx['marks'] ) ) {
				return $mk( 'held', $words . ' · Checked in · ' . ogc_lod_why( $d, $ctx['marks'] ), 409, 'ogc_conflict' );
			}
		} elseif ( $all && ogc_lod_checked_in( isset( $rows[ $k ] ) ? (array) $rows[ $k ] : array() ) ) {
			// Checked in, keys out, and the registration gone (removed some other way): held, and listed.
			return $mk( 'held', $words . ' · Checked in · Not registered', 409, 'ogc_conflict' );
		}
		// Out of service with someone in it; not once its keys are back (red team round 3, X2-H2: a room
		// found damaged after its household checked out was listed as held wrongly, and Publish refused for
		// everyone, though nobody was in it).
		if ( $all && ! empty( $facts['out'] ) && empty( $rows[ $k ]['back'][ $room ] ) ) {
			return $mk( 'out', $words . ' · Out of service', 409, 'ogc_conflict' );
		}
		return null;
	}
	if ( ! $yfs ) {
		return null;
	}
	$cap = min( 3, $beds + 1 );
	if ( count( $yfs ) > $cap ) {
		return $mk( 'full', 'Room ' . $words . ' is full · ' . $cap . ' Youngfolks', 409, 'ogc_conflict' );
	}
	$yfp  = ogc_lod_yf_people( $ctx );
	$hall = ogc_lod_yf_hall_of( $r );
	$ages    = array();
	$unknown = '';
	foreach ( $yfs as $k ) {
		$pid = substr( $k, 3 );
		if ( ! isset( $yfp[ $pid ] ) ) {
			continue;
		}
		$p = $yfp[ $pid ]['p'];
		if ( $hall !== ( isset( $p['yfHall'] ) ? (string) $p['yfHall'] : '' ) ) {
			return $mk( 'hall', '' === $hall ? $words . ' · Not a Youngfolks room' : ( 'men' === $hall ? 'Young men’s hall' : 'Young women’s hall' ) . ' · Not for ' . ogc_lod_first( $p['name'] ), 400, 'ogc_bad' );
		}
		$ages[ empty( $p['minor'] ) ? 'adult' : 'minor' ] = true;
		if ( '' === $unknown && '' === trim( (string) ( isset( $p['age'] ) ? $p['age'] : '' ) ) ) {
			$unknown = ogc_lod_first( $p['name'] );
		}
	}
	$split = 'yes' === strtolower( trim( isset( $ctx['cfg']['yf_age_split'] ) ? (string) $ctx['cfg']['yf_age_split'] : '' ) );
	if ( count( $ages ) > 1 && $split ) {
		return $mk( 'ages', 'Ages mixed · Under 18 room apart', 409, 'ogc_ages' );
	}
	// Where the state's age rule applies, an age not known is never read as 18 and up: a Youngfolk with
	// no age shares with nobody until it's known (red team round 3, ATK3 A5: the Form sent again without
	// a 17-year-old's age, and a 19-year-old was put in beside him).
	if ( $split && '' !== $unknown && count( $yfs ) > 1 ) {
		return $mk( 'ages', 'Age not known · ' . $unknown . ' · Room apart', 409, 'ogc_ages' );
	}
	// A Youngfolk whose key is out but who may no longer hold the room (cancelled, Didn't come): held,
	// and listed until the key is back.
	if ( $all ) {
		foreach ( $yfs as $k ) {
			$pid = substr( $k, 3 );
			if ( isset( $rows[ $k ] ) && ogc_lod_key_out( (array) $rows[ $k ] ) && ( ! isset( $yfp[ $pid ] ) || ! ogc_lod_yf_holds( $yfp[ $pid ]['p'], $ctx['hh'][ $yfp[ $pid ]['rid'] ], $ctx['marks'] ) ) ) {
				$why = isset( $yfp[ $pid ] ) ? ogc_lod_yf_why_not( $yfp[ $pid ]['p'], $ctx['hh'][ $yfp[ $pid ]['rid'] ], $ctx['marks'] ) : 'Not registered';
				return $mk( 'held', $words . ' · Key out · ' . $why, 409, 'ogc_conflict' );
			}
		}
	}
	if ( $all && ! empty( $facts['out'] ) ) {
		return $mk( 'out', $words . ' · Out of service', 409, 'ogc_conflict' );
	}
	return null;
}

/** What's wrong with a room's holders, in words ('' when nothing): taken twice, or full (kept for older
 * callers; ogc_lod_room_issue is the whole check). */
function ogc_lod_room_wrong( $ctx, $room, $keys, $mine = array() ) {
	$i = ogc_lod_room_issue( $ctx, $room, $keys, array(), false, $mine );
	return $i && in_array( $i['code'], array( 'taken', 'full' ), true ) ? $i['words'] : '';
}

/**
 * The rooms held wrongly now, for the board to show at the top of Rooms and Publish to refuse: every
 * room ogc_lod_room_issue finds wrong (held twice, full, a family in a room not for families, a Youngfolk
 * in the other hall, more sleeping than its beds + 1, ages mixed, out of service, checked in and no
 * longer holding), and a room a halls change took away from someone placed in it. [{ room, words, keys }].
 */
function ogc_lod_conflicts( $y, $ctx = null ) {
	$ctx  = $ctx ? $ctx : ogc_lod_ctx( $y );
	$rows = array();
	foreach ( ogc_lod_rows( $y ) as $k => $r ) {
		if ( 0 === strpos( $k, 'hh:' ) || 0 === strpos( $k, 'yf:' ) ) {
			$rows[ $k ] = $r['data'];
		}
	}
	$out = array();
	foreach ( ogc_lod_claims( $ctx, $rows ) as $room => $keys ) {
		$i = ogc_lod_room_issue( $ctx, $room, $keys, $rows, true );
		if ( ! $i ) {
			continue;
		}
		$names = array_values( array_unique( array_map( function ( $k ) use ( $ctx ) { return ogc_lod_who( $ctx, $k ); }, $keys ) ) );
		if ( 'taken' === $i['code'] ) {
			$w = ogc_lod_room_words( $room ) . ' · Held twice · ' . implode( ' and ', $names );
		} elseif ( 'full' === $i['code'] ) {
			$w = ogc_lod_room_words( $room ) . ' · Full';
		} elseif ( 0 === strpos( $i['words'], ogc_lod_room_words( $room ) ) ) {
			$w = $i['words'] . ( 'Youngfolks' !== $names[0] ? ' · ' . $names[0] : '' );
		} else {
			$w = ogc_lod_room_words( $room ) . ' · ' . $i['words'];
		}
		$out[] = array( 'room' => $room, 'words' => $w, 'keys' => $keys, 'code' => $i['code'] );
	}
	// A room a household holds that isn't in the halls any more.
	foreach ( $rows as $k => $d ) {
		$rid = substr( $k, 3 );
		if ( 0 === strpos( $k, 'hh:' ) && isset( $ctx['hh'][ $rid ] ) && ( ogc_lod_holds( $ctx['hh'][ $rid ], $ctx['marks'] ) || ogc_lod_checked_in( (array) $d ) ) ) {
			foreach ( (array) ( isset( $d['rooms'] ) ? $d['rooms'] : array() ) as $id ) {
				if ( '' !== (string) $id && ! isset( $ctx['rooms'][ (string) $id ] ) ) {
					$out[] = array( 'room' => (string) $id, 'words' => ogc_lod_room_words( $id ) . ' · Not in the halls · ' . ogc_lod_label( $ctx['hh'][ $rid ]['data'] ), 'keys' => array( $k ), 'code' => 'gone' );
				}
			}
		}
	}
	return $out;
}

/**
 * What a change would leave wrong: every room it touches, as the room would be after against the room
 * as it is now. Only what the change adds is wrong (a room already held wrongly never locks the desk out
 * of either household: invariant 1); a change that moves a household's rooms between its places (red
 * team A1), sets a room's beds under the people in it (A2, A4) or brings a household back into a room
 * (Undo, Cancel's Undo, Undo import, coming back) is judged the same way as Place. $before: Lodging's
 * rows now (rkey => data); $after: the rows the change writes (null: emptied), room facts (room:<id>)
 * included; $ctx2: how the year will be after (a registration put back, the halls changed), else $ctx.
 * Returns every issue: [ { room, code, words, status, err } ].
 */
function ogc_lod_plan_issues( $ctx, $before, $after, $ctx2 = null ) {
	$ctx2  = $ctx2 ? $ctx2 : $ctx;
	$facts = array();
	foreach ( $after as $k => $d ) {
		if ( 0 === strpos( $k, 'room:' ) ) {
			$facts[ substr( $k, 5 ) ] = is_array( $d ) ? $d : array();
		}
	}
	if ( $facts ) {
		$carry = function_exists( 'ogc_lod_carry' ) ? ogc_lod_carry( $ctx['y'] ) : null;
		foreach ( $facts as $id => $d ) {
			$ctx2['facts'][ $id ] = array_merge( isset( $carry['rooms'][ $id ] ) ? (array) $carry['rooms'][ $id ] : array(), $d );
		}
	}
	$next = $before;
	$mine = array();
	foreach ( $after as $k => $d ) {
		if ( 0 !== strpos( $k, 'hh:' ) && 0 !== strpos( $k, 'yf:' ) ) {
			continue;
		}
		$mine[] = $k;
		if ( null === $d ) {
			unset( $next[ $k ] );
		} else {
			$next[ $k ] = $d;
		}
	}
	$cb    = ogc_lod_claims( $ctx, $before );
	$ca    = ogc_lod_claims( $ctx2, $next );
	$touch = array();
	foreach ( array( $cb, $ca ) as $c ) {
		foreach ( $c as $room => $holders ) {
			if ( array_intersect( $holders, $mine ) || isset( $facts[ $room ] ) ) {
				$touch[ $room ] = true;
			}
		}
	}
	// A changed registration (ctx2) is judged in every room its household holds; so is one coming back
	// (in ctx2, not in ctx: Undo import putting a removed household back: red team round 2, I2b).
	if ( $ctx2 !== $ctx ) {
		foreach ( $ca as $room => $holders ) {
			foreach ( $holders as $k ) {
				$rid = 0 === strpos( $k, 'hh:' ) ? substr( $k, 3 ) : ( isset( $ctx2['yfp'][ substr( $k, 3 ) ] ) ? $ctx2['yfp'][ substr( $k, 3 ) ]['rid'] : '' );
				if ( '' !== $rid && isset( $ctx2['hh'][ $rid ] ) && ( ! isset( $ctx['hh'][ $rid ] ) || $ctx2['hh'][ $rid ]['data'] !== $ctx['hh'][ $rid ]['data'] ) ) {
					$touch[ $room ] = true;
				}
			}
		}
	}
	$out = array();
	foreach ( array_keys( $touch ) as $room ) {
		if ( empty( $ca[ $room ] ) ) {
			continue;
		}
		$ia = ogc_lod_room_issue( $ctx2, (string) $room, $ca[ $room ], $next, false, $mine );
		if ( ! $ia ) {
			continue;
		}
		$ib = ! empty( $cb[ $room ] ) ? ogc_lod_room_issue( $ctx, (string) $room, $cb[ $room ], $before, false, $mine ) : null;
		// A room already held wrongly, the same way, isn't the change's doing, and never locks the desk out
		// of its holders; but the change may add no one to it (red team round 2: ATK1-r2-third-into-double,
		// -ages-third, -full-takes-fifth: the words read the same with two holders or three, so a third
		// household, an 18-year-old beside a 17-year-old and a fifth Youngfolk were all taken).
		$added = array_diff( $ca[ $room ], ! empty( $cb[ $room ] ) ? $cb[ $room ] : array() );
		if ( $ib && $ib['code'] === $ia['code'] && $ib['words'] === $ia['words'] && ! $added ) {
			continue;
		}
		$out[] = array_merge( $ia, array( 'room' => (string) $room ) );
	}
	return $out;
}

/** The first thing a change would leave wrong, as the refusal (null when nothing): see ogc_lod_plan_issues. */
function ogc_lod_check_plan( $ctx, $before, $after, $ctx2 = null ) {
	$i = ogc_lod_plan_issues( $ctx, $before, $after, $ctx2 );
	return $i ? new WP_Error( $i[0]['err'], $i[0]['words'], array( 'status' => $i[0]['status'], 'room' => $i[0]['room'], 'issue' => $i[0]['code'] ) ) : null;
}

/** The year's context with some registrations as they will be ($recs: rid => data; null: gone). */
function ogc_lod_ctx_with( $ctx, $recs ) {
	foreach ( $recs as $rid => $d ) {
		if ( null === $d ) {
			unset( $ctx['hh'][ $rid ] );
		} elseif ( isset( $ctx['hh'][ $rid ] ) ) {
			$ctx['hh'][ $rid ]['data'] = $d;
		} else {
			$ctx['hh'][ $rid ] = array( 'id' => 0, 'year' => $ctx['y'], 'source' => isset( $d['source'] ) ? $d['source'] : '', 'data' => $d );
		}
	}
	unset( $ctx['yfp'] );
	$ctx['yfp'] = ogc_lod_yf_people( $ctx );
	$ctx['yf']  = array();
	foreach ( $ctx['yfp'] as $pid => $x ) {
		$ctx['yf'][ $pid ] = $x['rid'];
	}
	return $ctx;
}

/** A refusal's short reason, for a room freed because of it ("Freed Reed 101 · Given since"). */
function ogc_lod_issue_why( $i ) {
	$w = array( 'taken' => 'Given since', 'full' => 'Given since', 'for' => 'Not for families', 'hall' => 'Other hall', 'over' => 'Too many for its beds', 'ages' => 'Ages mixed', 'gone' => 'Not in the halls' );
	return isset( $w[ $i['code'] ] ) ? $w[ $i['code'] ] : 'Given since';
}

/* ================================================================== when a registration changes */

/** What about a registration matters to its rooms: its status, its stay and rooms asked, each person
 * (who, kind, age, the hall and bed of a Youngfolk, their place), and a parent's approval (who may take
 * keys, who may keep a hall room, how many sleep in each room). */
function ogc_lod_reg_sig( $d ) {
	$d = is_array( $d ) ? $d : array();
	$p = array();
	foreach ( (array) ( isset( $d['people'] ) ? $d['people'] : array() ) as $x ) {
		$x   = (array) $x;
		$p[] = array( isset( $x['pid'] ) ? $x['pid'] : '', isset( $x['name'] ) ? $x['name'] : '', isset( $x['kind'] ) ? $x['kind'] : '', isset( $x['age'] ) ? (string) $x['age'] : '', ! empty( $x['minor'] ), isset( $x['sleeps'] ) ? $x['sleeps'] : '', isset( $x['yfHall'] ) ? $x['yfHall'] : '', isset( $x['room'] ) ? $x['room'] : null );
	}
	// Only Cancelled changes what may be held (a payment's status never does; the waiting list keeps its rooms).
	return ogc_json( array( 'cancelled' === ( isset( $d['status'] ) ? $d['status'] : '' ), isset( $d['stay']['type'] ) ? $d['stay']['type'] : '', isset( $d['stay']['rooms'] ) ? (int) $d['stay']['rooms'] : 0, ! empty( $d['stay']['ask'] ), isset( $d['approval']['state'] ) ? $d['approval']['state'] : '', $p ) );
}

/**
 * After any registration is saved (ogc_reg_save; the import calls it too): a room it may no longer hold
 * is freed on Lodging's row at once, and kept there as `freed` (which, when, why) for Lodging to see. A
 * household or Youngfolk coming back never gets a room back by itself: Lodging places by hand (docs/25;
 * Lodging Q9 asks otherwise). One coming back still holding a room someone else was given since keeps
 * only the rooms nobody else has. Under Lodging's lock, unless this request already holds it. $why
 * names the reason when the registration itself is gone ("Not in this file").
 */
function ogc_lod_reg_saved( $y, $old, $new, $why = '' ) {
	$y   = (int) $y;
	$old = is_array( $old ) ? $old : array();
	$new = is_array( $new ) ? $new : array();
	if ( ogc_lod_reg_sig( $old ) === ogc_lod_reg_sig( $new ) && '' === $why ) {
		return array();
	}
	$rid = isset( $new['rid'] ) && '' !== $new['rid'] ? (string) $new['rid'] : ( isset( $old['rid'] ) ? (string) $old['rid'] : '' );
	if ( '' === $rid ) {
		return array();
	}
	$mine = ! ogc_lod_holding( $y );
	if ( $mine && ! ogc_lod_lock( $y ) ) {
		// Busy for 3 seconds (a long Assign all): the registration is saved already, so its freeing can't be
		// refused. It goes ahead now (each row is written at its version), and is kept as pending, so the
		// change holding the lock frees it again before it lets go, against the rows as that change wrote
		// them (red team round 2, ATK1-r2-busy-free-lost). The register's own routes never get here: their
		// guard holds Lodging's lock for the whole request, and is told Busy before anything is saved.
		ogc_lod_pend( $y, $rid, $old );
		return ogc_lod_release( $y, $rid, $old, $new, $why );
	}
	try {
		return ogc_lod_release( $y, $rid, $old, $new, $why );
	} finally {
		if ( $mine ) {
			ogc_lod_unlock( $y );
		}
	}
}

/** What a registration said before a change whose freeing waits for Lodging's lock: the parts freeing
 * reads (status, stay, people, approval). The first one waiting is kept (it's the "before"). */
function ogc_lod_pend( $y, $rid, $old ) {
	global $wpdb;
	$keep = array_intersect_key( is_array( $old ) ? $old : array(), array_flip( array( 'rid', 'id', 'status', 'stay', 'people', 'approval' ) ) );
	// Only what freeing reads: never a parent's address, a note or an approval's token.
	if ( isset( $keep['stay'] ) && is_array( $keep['stay'] ) ) {
		unset( $keep['stay']['parentEmail'], $keep['stay']['needs'], $keep['stay']['near'] );
	}
	if ( isset( $keep['approval'] ) && is_array( $keep['approval'] ) ) {
		$keep['approval'] = array_intersect_key( $keep['approval'], array( 'state' => 1 ) );
	}
	$prev = $wpdb->suppress_errors( true );
	$wpdb->insert( ogc_table( 'lodging' ), array( 'year' => (int) $y, 'rkey' => 'meta:pend:' . substr( $rid, 0, 60 ), 'data' => ogc_json( array( 'old' => $keep, 'at' => ogc_now() ) ), 'version' => 1, 'updated_by' => get_current_user_id(), 'updated_at' => ogc_now() ), array( '%d', '%s', '%s', '%d', '%d', '%s' ) );
	$wpdb->suppress_errors( $prev );
}

/** Free what each pending registration change may no longer hold (see ogc_lod_pend), as its registration is
 * stored now. Called by the holder of Lodging's lock: when it takes it and before it lets it go. */
function ogc_lod_pending( $y ) {
	global $wpdb;
	if ( ! empty( $GLOBALS['ogc_lod_pending_busy'] ) ) {
		return;
	}
	$rows = ogc_lod_rows( $y, 'meta:pend:' );
	if ( ! $rows ) {
		return;
	}
	$GLOBALS['ogc_lod_pending_busy'] = true;
	try {
		$hh = ogc_lod_households( $y );
		foreach ( $rows as $k => $r ) {
			$rid = substr( $k, strlen( 'meta:pend:' ) );
			$old = isset( $r['data']['old'] ) ? (array) $r['data']['old'] : array();
			$new = isset( $hh[ $rid ] ) ? $hh[ $rid ]['data'] : array();
			ogc_lod_release( $y, $rid, $old, $new, $new ? '' : 'Not registered' );
			$wpdb->query( $wpdb->prepare( 'DELETE FROM ' . ogc_table( 'lodging' ) . ' WHERE year = %d AND rkey = %s AND version = %d', $y, $k, $r['v'] ) );
		}
	} finally {
		$GLOBALS['ogc_lod_pending_busy'] = false;
	}
}

/** The words for why a household's rooms were freed. */
function ogc_lod_why( $d, $marks = array() ) {
	$st = isset( $d['status'] ) ? (string) $d['status'] : '';
	$ty = isset( $d['stay']['type'] ) ? (string) $d['stay']['type'] : '';
	if ( 'cancelled' === $st ) {
		return 'Cancelled';
	}
	if ( 'dorm' !== $ty ) {
		$w = array( 'camper' => 'Camper lot', 'elsewhere' => 'Off campus', 'yf' => 'Youngfolks halls' );
		return isset( $w[ $ty ] ) ? $w[ $ty ] : 'Not in dorm rooms';
	}
	return 'Didn’t come';
}

/** Lodging's rows of the year that hold rooms, but one: rkey => data. */
function ogc_lod_claim_rows( $y, $except = '' ) {
	$rows = array();
	foreach ( ogc_lod_rows( $y ) as $k => $r ) {
		if ( $except !== $k && ( 0 === strpos( $k, 'hh:' ) || 0 === strpos( $k, 'yf:' ) ) ) {
			$rows[ $k ] = $r['data'];
		}
	}
	return $rows;
}

/**
 * Free what a registration may no longer hold (see ogc_lod_reg_saved). Returns the rooms freed, as ids.
 * A household the desk checked in keeps its rooms (invariant 57: the keys are out). One coming back (from
 * the camper lot, a Cancel undone, Didn't come taken back) keeps only the rooms it may hold now, judged
 * as Place judges them (ogc_lod_plan_issues: nobody given them since, still for families, its people
 * fit, the age rule): "Given since" and the like. A Youngfolk whose parent must now approve keeps no hall
 * room until they do. Who Lodging named for a room's keys is dropped once they may not take them.
 */
function ogc_lod_release( $y, $rid, $old, $new, $why = '' ) {
	$ctx   = ogc_lod_ctx_with( ogc_lod_ctx( $y ), array( $rid => $new ? $new : null ) );
	$rooms = $ctx['rooms'];
	$marks = $ctx['marks'];
	$rec   = isset( $ctx['hh'][ $rid ] ) ? $ctx['hh'][ $rid ] : array( 'data' => $new );
	$was   = array_merge( $rec, array( 'data' => $old ) );
	$freed = array();
	$now   = ogc_now();
	$me    = ogc_lod_me();
	$by    = '' !== $me ? $me : 'Registration';

	// The household's family rooms: all of them when it may hold none now; when it may hold rooms again,
	// the ones it may not keep.
	for ( $try = 0; $try < 4; $try++ ) {
		$row  = ogc_lod_row( $y, 'hh:' . $rid );
		$real = $row ? ogc_lod_real( isset( $row['data']['rooms'] ) ? $row['data']['rooms'] : array(), $rooms ) : array();
		if ( ! $real || ogc_lod_checked_in( (array) $row['data'] ) ) {
			break;
		}
		$drop = array();
		$w    = '';
		if ( '' !== $why || ! ogc_lod_holds( $rec, $marks ) ) {
			$drop = $real;
			$w    = '' !== $why ? $why : ogc_lod_why( $new, $marks );
		} elseif ( ! ogc_lod_holds( $was, $marks ) ) {
			list( $drop, $w ) = ogc_lod_unfit( $ctx, 'hh:' . $rid, (array) $row['data'] );
		}
		if ( ! $drop ) {
			break;
		}
		$d    = (array) $row['data'];
		$keep = array();
		foreach ( (array) $d['rooms'] as $id ) {
			$keep[] = in_array( (string) $id, $drop, true ) ? '' : (string) $id;
		}
		while ( $keep && '' === end( $keep ) ) {
			array_pop( $keep );
		}
		if ( $keep ) {
			$d['rooms'] = $keep;
		} else {
			unset( $d['rooms'], $d['given'] );
		}
		$d['freed'] = array( 'rooms' => array_values( $drop ), 'list' => array_values( array_map( 'strval', (array) $row['data']['rooms'] ) ), 'why' => $w, 'by' => $by, 'at' => $now );
		if ( ! is_wp_error( ogc_lod_put( $y, 'hh:' . $rid, $d, $row['v'] ) ) ) {
			$freed = array_merge( $freed, $drop );
			break;
		}
	}
	ogc_lod_keys_fix( $y, $rid, $new );

	// Its Youngfolks' hall rooms: anyone no longer on it, no longer in a hall, on a registration
	// cancelled or marked Didn't come, waiting on a parent's approval, or in the other hall now; one
	// coming back, a room they may not keep now.
	$was_p = array();
	$now_p = array();
	foreach ( (array) ( isset( $old['people'] ) ? $old['people'] : array() ) as $p ) {
		if ( ! empty( $p['pid'] ) ) {
			$was_p[ (string) $p['pid'] ] = $p;
		}
	}
	foreach ( (array) ( isset( $new['people'] ) ? $new['people'] : array() ) as $p ) {
		if ( ! empty( $p['pid'] ) ) {
			$now_p[ (string) $p['pid'] ] = $p;
		}
	}
	$gone = 'cancelled' === ( isset( $new['status'] ) ? $new['status'] : '' );
	foreach ( array_keys( $was_p + $now_p ) as $pid ) {
		$p  = isset( $now_p[ $pid ] ) ? $now_p[ $pid ] : null;
		$p0 = isset( $was_p[ $pid ] ) ? $was_p[ $pid ] : null;
		if ( empty( $p['yf'] ) && empty( $p0['yf'] ) ) {
			continue;
		}
		for ( $try = 0; $try < 4; $try++ ) {
			$row = ogc_lod_row( $y, 'yf:' . $pid );
			$id  = $row && ! empty( $row['data']['room'] ) ? (string) $row['data']['room'] : '';
			// A hall key out: the room is kept until the key is back, as a checked-in household's rooms are.
			if ( '' === $id || ogc_lod_key_out( (array) $row['data'] ) ) {
				break;
			}
			$w = '';
			if ( '' !== $why ) {
				$w = $why;
			} elseif ( ! $p || empty( $p['yf'] ) ) {
				$w = $gone ? 'Cancelled' : 'Not on the registration';
			} elseif ( '' !== ( $no = ogc_lod_yf_why_not( $p, $rec, $marks ) ) ) {
				$w = $no;
			} elseif ( isset( $rooms[ $id ] ) && ogc_lod_yf_hall_of( $rooms[ $id ] ) !== ( isset( $p['yfHall'] ) ? (string) $p['yfHall'] : '' ) ) {
				$w = 'Hall changed';
			} elseif ( ! $p0 || ! ogc_lod_yf_holds( $p0, $was, $marks ) ) {
				list( $d0, $w0 ) = ogc_lod_unfit( $ctx, 'yf:' . $pid, (array) $row['data'] );
				$w = $d0 ? $w0 : '';
			}
			if ( '' === $w ) {
				break;
			}
			$d = (array) $row['data'];
			unset( $d['room'] );
			$d['freed'] = array( 'room' => $id, 'why' => $w, 'by' => $by, 'at' => $now );
			if ( ! is_wp_error( ogc_lod_put( $y, 'yf:' . $pid, $d, $row['v'] ) ) ) {
				$freed[] = $id;
				break;
			}
		}
	}
	if ( $freed ) {
		ogc_log( 'lodging_freed', $y, 'lodging', array( 'rooms' => count( $freed ) ) );
	}
	return $freed;
}

/**
 * The rooms on a row it may not keep now, and why (the first reason): judged as Place judges them, against
 * everyone else's rows. For a household or Youngfolk coming back after a registration change. Returns
 * array( room ids, why ).
 */
function ogc_lod_unfit( $ctx, $key, $data ) {
	$others = ogc_lod_claim_rows( $ctx['y'], $key );
	$drop   = array();
	$why    = '';
	for ( $i = 0; $i < 9; $i++ ) {
		$iss = ogc_lod_plan_issues( $ctx, $others, array( $key => $data ) );
		if ( ! $iss ) {
			break;
		}
		$room = (string) $iss[0]['room'];
		if ( 0 === strpos( $key, 'hh:' ) ) {
			$list = array_map( 'strval', (array) ( isset( $data['rooms'] ) ? $data['rooms'] : array() ) );
			if ( ! in_array( $room, $list, true ) ) {
				break;
			}
			$data['rooms'] = array_map( function ( $r ) use ( $room ) { return $r === $room ? '' : $r; }, $list );
		} else {
			if ( ! isset( $data['room'] ) || (string) $data['room'] !== $room ) {
				break;
			}
			unset( $data['room'] );
		}
		$drop[] = $room;
		$why    = '' !== $why ? $why : ogc_lod_issue_why( $iss[0] );
	}
	return array( array_values( array_unique( $drop ) ), $why );
}

/** Who Lodging named to take a room's keys is kept only while they may (on the registration, a grown-up
 * or a Youngfolk 18 and up: invariant 20; red team A9). */
function ogc_lod_keys_fix( $y, $rid, $d ) {
	for ( $try = 0; $try < 3; $try++ ) {
		$row = ogc_lod_row( $y, 'hh:' . $rid );
		if ( ! $row || empty( $row['data']['keys'] ) || ! is_array( $row['data']['keys'] ) || ! function_exists( 'ogc_lod_key_holder' ) ) {
			return;
		}
		$ok = array();
		foreach ( (array) ( isset( $d['people'] ) ? $d['people'] : array() ) as $p ) {
			if ( ! empty( $p['name'] ) && ogc_lod_key_holder( $p ) ) {
				$ok[ (string) $p['name'] ] = true;
			}
		}
		$keys = array();
		foreach ( $row['data']['keys'] as $i => $n ) {
			if ( isset( $ok[ (string) $n ] ) ) {
				$keys[ $i ] = (string) $n;
			}
		}
		if ( count( $keys ) === count( $row['data']['keys'] ) ) {
			return;
		}
		$nd = (array) $row['data'];
		if ( $keys ) {
			$nd['keys'] = $keys;
		} else {
			unset( $nd['keys'] );
		}
		if ( ! is_wp_error( ogc_lod_put( $y, 'hh:' . $rid, $nd, $row['v'] ) ) ) {
			return;
		}
	}
}

/** "Hammond · Levi and Ruth": the surname, then the adults' first names (one form everywhere). */
function ogc_lod_label( $d ) {
	$sur    = isset( $d['household']['name'] ) ? trim( preg_replace( '/^the\s+|\s+(family|household)$/i', '', (string) $d['household']['name'] ) ) : '';
	$adults = array();
	foreach ( isset( $d['people'] ) ? (array) $d['people'] : array() as $p ) {
		if ( 'adult' === ( isset( $p['kind'] ) ? $p['kind'] : ( isset( $p['band'] ) ? $p['band'] : '' ) ) && empty( $p['yf'] ) && ! empty( $p['name'] ) ) {
			$adults[] = strtok( trim( $p['name'] ), ' ' );
		}
	}
	if ( '' === $sur ) {
		$c   = isset( $d['household']['contact'] ) ? trim( (string) $d['household']['contact'] ) : '';
		$sur = $c ? substr( $c, strrpos( ' ' . $c, ' ' ) ) : 'Household';
	}
	if ( ! $adults ) {
		return $sur;
	}
	$last = array_pop( $adults );
	return $sur . ' · ' . ( $adults ? implode( ', ', $adults ) . ' and ' : '' ) . $last;
}

/** What a registration looked like when its rooms were given (the board shows what changed since). */
function ogc_lod_snap( $d ) {
	$s = isset( $d['stay'] ) ? (array) $d['stay'] : array();
	$n = 0;
	foreach ( isset( $d['people'] ) ? (array) $d['people'] : array() as $p ) {
		if ( ! empty( $p['name'] ) ) {
			$n++;
		}
	}
	return array(
		'type'   => isset( $s['type'] ) ? (string) $s['type'] : '',
		'nights' => array_values( (array) ( isset( $s['nights'] ) ? $s['nights'] : array() ) ),
		'rooms'  => (int) ( isset( $s['rooms'] ) ? $s['rooms'] : 0 ),
		'n'      => $n,
		'status' => isset( $d['status'] ) ? (string) $d['status'] : '',
		'ground' => ! empty( $s['ground'] ) || ! empty( $s['walker'] ),
		'at'     => ogc_now(),
	);
}

/* ================================================================== clearing names */

/**
 * The nights a household's room i is slept in (invariant 12): every night of anyone in it (the form's
 * Room i+1, among as many places as rooms given or asked: ogc_lod_places, the beds check's own rule), and
 * none for a room nobody sleeps in (red team A7, D1). A household from the Google Form has no one placed
 * by room: each of its rooms on every night of the household. The desk's keys back early (left: the first
 * night not used) end them all (C3). $list: Lodging's rooms, in place; $row: its Lodging row.
 */
function ogc_lod_room_nights( $d, $list, $i, $cfg, $row = array(), $pooled = false ) {
	$all = array_values( (array) ( isset( $d['stay']['nights'] ) ? $d['stay']['nights'] : array() ) );
	if ( $pooled ) {
		$out = $all;
	} else {
		$n   = ogc_lod_places( $d, $list );
		$set = array();
		foreach ( ogc_lod_sleepers( $d, $n, (int) $i ) as $p ) {
			foreach ( ! empty( $p['nights'] ) ? (array) $p['nights'] : $all as $x ) {
				$set[ $x ] = true;
			}
		}
		// A baby under 3 sleeps there too (not counted for beds, but the room is used), when its room is
		// said. One with no room of its own (the form never keeps a baby's room) sleeps with a grown-up and
		// makes no room slept in by itself (red team round 2, K3_B4: its nights went on Room 1).
		foreach ( (array) ( isset( $d['people'] ) ? $d['people'] : array() ) as $p ) {
			if ( ! isset( $p['room'] ) || null === $p['room'] || '' === $p['room'] ) {
				continue;
			}
			if ( ! empty( $p['name'] ) && 'baby' === ( isset( $p['band'] ) ? $p['band'] : '' ) && ! ogc_lod_in_hall( $p, $d ) && ogc_lod_slot( $p, $n ) === (int) $i ) {
				foreach ( ! empty( $p['nights'] ) ? (array) $p['nights'] : $all as $x ) {
					$set[ $x ] = true;
				}
			}
		}
		$out = array_values( array_filter( $all, function ( $x ) use ( $set ) { return isset( $set[ $x ] ); } ) );
		foreach ( array_keys( $set ) as $x ) {
			if ( ! in_array( $x, $out, true ) ) {
				$out[] = $x;
			}
		}
	}
	$left = is_array( $row ) && ! empty( $row['left']['night'] ) ? (string) $row['left']['night'] : '';
	$at   = '' !== $left ? array_search( $left, $all, true ) : false;
	if ( false !== $at ) {
		$gone = array_slice( $all, $at );
		$out  = array_values( array_diff( $out, $gone ) );
	}
	return $out;
}

/**
 * The year in counts: what stays once names are cleared (Lodging's final report, next year's set-up),
 * and the server's own numbers that Counts' Mark sent is checked against. Households that will come
 * only (not the waiting list, not Didn't come: invariant 79); family rooms in the halls; each room on
 * the nights someone sleeps in it (invariant 12); Youngfolks by the hall set, "hall not set" apart
 * (invariant 83); linen packets as the form sold them, the rooms' and each hall Youngfolk's own
 * (invariant 80).
 */
function ogc_lod_numbers( $year ) {
	$rows   = ogc_lod_rows( $year, 'hh:' );
	$rooms  = ogc_lod_rooms( $year );
	$cfg    = function_exists( 'ogc_reg_cfg' ) ? ogc_reg_cfg( $year ) : ogc_lod_kv( $year, 'registration' );
	$kv     = ogc_lod_kv( $year, 'registration' );
	$nights = function_exists( 'ogc_reg_nights' ) ? ogc_reg_nights( $cfg ) : array_values( array_filter( array_map( 'trim', explode( '|', isset( $kv['nights'] ) ? $kv['nights'] : '' ) ) ) );
	$marks  = ogc_lod_marks( $year );
	$hh     = ogc_lod_households( $year );
	$out    = array( 'households' => 0, 'rooms' => 0, 'by_hall' => array(), 'per_night' => array(), 'campers' => array(), 'yf' => array(), 'linens' => 0, 'yf_linens' => 0, 'mattresses' => 0 );
	foreach ( $hh as $rid => $rec ) {
		if ( ! ogc_lod_reg_coming( $rec, $marks ) ) {
			continue;
		}
		$d  = $rec['data'];
		$s  = isset( $d['stay'] ) ? $d['stay'] : array();
		$ns = (array) ( isset( $s['nights'] ) ? $s['nights'] : array() );
		$t  = isset( $s['type'] ) ? $s['type'] : '';
		if ( 'dorm' === $t ) {
			$out['households']++;
			$out['linens']     += (int) ( isset( $s['linens'] ) ? $s['linens'] : 0 );
			$out['mattresses'] += (int) ( isset( $s['mattresses'] ) ? $s['mattresses'] : 0 );
			$list = array_values( (array) ( isset( $rows[ 'hh:' . $rid ]['data']['rooms'] ) ? $rows[ 'hh:' . $rid ]['data']['rooms'] : array() ) );
			foreach ( $list as $i => $id ) {
				$id = (string) $id;
				if ( '' === $id || ! isset( $rooms[ $id ] ) || ! ogc_lod_family_room( $rooms[ $id ] ) ) {
					continue;
				}
				$h = $rooms[ $id ]['hall'];
				$out['rooms']++;
				$out['by_hall'][ $h ] = ( isset( $out['by_hall'][ $h ] ) ? $out['by_hall'][ $h ] : 0 ) + 1;
				foreach ( ogc_lod_room_nights( $d, $list, $i, $cfg, isset( $rows[ 'hh:' . $rid ]['data'] ) ? (array) $rows[ 'hh:' . $rid ]['data'] : array(), ogc_lod_pooled( $rec ) ) as $n ) {
					$out['per_night'][ $n ][ $h ] = ( isset( $out['per_night'][ $n ][ $h ] ) ? $out['per_night'][ $n ][ $h ] : 0 ) + 1;
				}
			}
		} elseif ( 'camper' === $t ) {
			foreach ( $ns as $n ) {
				$out['campers'][ $n ] = ( isset( $out['campers'][ $n ] ) ? $out['campers'][ $n ] : 0 ) + max( 1, (int) ( isset( $s['campers'] ) ? $s['campers'] : 1 ) );
			}
		} elseif ( 'yf' === $t ) {
			// A Youngfolk registered on their own: linens for their hall, counted apart from the rooms'.
			$out['yf_linens'] += (int) ( isset( $s['linens'] ) ? $s['linens'] : 0 );
		}
		foreach ( (array) ( isset( $d['people'] ) ? $d['people'] : array() ) as $p ) {
			// Each hall Youngfolk's own packet, as the form counts it (ogc_reg_usage).
			if ( ! empty( $p['linens'] ) ) {
				$out['yf_linens']++;
			}
			if ( ogc_lod_in_hall( $p, $d ) ) {
				$hk   = isset( $p['yfHall'] ) ? (string) $p['yfHall'] : '';
				$hall = 'women' === $hk ? 'young women' : ( 'men' === $hk ? 'young men' : 'hall not set' );
				$out['yf'][ $hall ] = ( isset( $out['yf'][ $hall ] ) ? $out['yf'][ $hall ] : 0 ) + 1;
			}
		}
	}
	$ctx  = array( 'y' => (int) $year, 'rooms' => $rooms, 'hh' => $hh, 'marks' => $marks, 'facts' => array() );
	$yfp  = ogc_lod_yf_people( $ctx );
	$held = 0;
	foreach ( ogc_lod_claims( $ctx, array_map( function ( $r ) { return $r['data']; }, ogc_lod_rows( $year, 'yf:' ) ) ) as $room => $keys ) {
		// Only rooms of Youngfolks who will come, as the per-hall counts above are (red team round 2, E1: a
		// household on the waiting list keeps its Youngfolk's room, and the two counts disagreed).
		foreach ( $keys as $k ) {
			$pid = substr( $k, 3 );
			if ( isset( $yfp[ $pid ] ) && ogc_lod_reg_coming( $hh[ $yfp[ $pid ]['rid'] ], $marks ) ) {
				$held++;
				break;
			}
		}
	}
	$out['yf_rooms'] = $held;
	$row             = ogc_year_get( $year );
	$out['start']    = $row && ! empty( $row['start'] ) ? $row['start'] : '';
	$out['end']      = $row && ! empty( $row['end'] ) ? $row['end'] : '';
	// A night households have that the year no longer offers (early nights turned off after some chose
	// one: red team B1) is still a night someone sleeps here: listed, so Counts and Mark sent carry it.
	$extra = array_values( array_diff( array_keys( $out['per_night'] + $out['campers'] ), $nights ) );
	$early = array_values( array_filter( $extra, function ( $n ) { return 0 === strpos( (string) $n, 'Early ' ); } ) );
	usort( $early, function ( $a, $b ) { return ( false !== stripos( $a, 'wed' ) ? 0 : 1 ) - ( false !== stripos( $b, 'wed' ) ? 0 : 1 ); } );
	$out['nights']   = array_values( array_merge( $early, $nights, array_diff( $extra, $early ) ) );
	$out['at']       = ogc_now();
	return $out;
}

/**
 * Once a year's names are due to be cleared: keep its counts, then remove every row that names or
 * points at a household (hh, yf, undo, imp, seen) and the published snapshot. Rooms' facts (holds,
 * out of service, accessible) and Notes for next year stay. The registrations themselves are the
 * register area's to clear.
 */
function ogc_lod_clear( $year ) {
	global $wpdb;
	if ( ! ogc_lod_row( $year, 'meta:numbers' ) ) {
		ogc_lod_put( $year, 'meta:numbers', ogc_lod_numbers( $year ) );
	}
	$t = ogc_table( 'lodging' );
	$n = 0;
	// Counts' kept copies keep their date, who and the counts; the rooming list (key holders) and the
	// room setup list (drawn by the screen, so anything typed into it: red team round 2, R2A4-16) go.
	foreach ( ogc_lod_rows( $year, 'meta:sent:' ) as $k => $r ) {
		$d = (array) $r['data'];
		if ( isset( $d['copy']['rooming'] ) || isset( $d['copy']['setup'] ) ) {
			unset( $d['copy']['rooming'], $d['copy']['setup'] );
			ogc_lod_put( $year, $k, $d );
		}
	}
	foreach ( array( 'hh:', 'yf:', 'undo:', 'imp:', 'meta:seen:', 'meta:published', 'meta:lock', 'meta:pend:' ) as $p ) {
		$n += (int) $wpdb->query( $wpdb->prepare( "DELETE FROM $t WHERE year = %d AND rkey LIKE %s", $year, $wpdb->esc_like( $p ) . '%' ) );
	}
	// What households saw (registration number → rooms) goes with the names (invariant 92).
	$st = ogc_state_get( $year, 'rooms' );
	if ( $st && (array) $st['value'] ) {
		ogc_state_put( $year, 'rooms', (object) array() );
	}
	ogc_log( 'lodging_cleared', $year, 'lodging', array( 'rows' => $n ) );
	return $n;
}

add_action( 'init', function () {
	if ( ! wp_next_scheduled( 'ogc_lodging_daily' ) ) {
		wp_schedule_event( time() + 2 * HOUR_IN_SECONDS, 'daily', 'ogc_lodging_daily' );
	}
} );

add_action( 'ogc_lodging_daily', function () {
	foreach ( ogc_years_list() as $y ) {
		$ph = ogc_lod_phase( $y, ogc_lod_today( $y, null, true ) );
		if ( $ph['gone'] && ( ogc_lod_rows( $y, 'hh:' ) || ogc_lod_rows( $y, 'yf:' ) || ! ogc_lod_row( $y, 'meta:numbers' ) ) ) {
			ogc_lod_clear( $y );
		}
	}
} );

/* ================================================================== for other areas */

/**
 * The rooms of $list a household may be shown (invariant 89). Its published rooms, as published (a move
 * Lodging made since waits for Send update: invariant 45), but none it holds no longer: a household
 * whose rooms a change freed sees none of them (red team A4-22: freed by its own change and given to
 * another, the room was shown until the next Send update). Of the rooms it chose on the map ($chose),
 * only those nobody else holds (J1).
 */
function ogc_lod_seen_rooms( $rec, $list, $chose = false ) {
	$list = array_values( array_map( 'strval', (array) $list ) );
	if ( ! $list ) {
		return $list;
	}
	$y   = (int) $rec['year'];
	$rid = ogc_lod_rid( $rec );
	$row = ogc_lod_row( $y, 'hh:' . $rid );
	$d   = $row ? (array) $row['data'] : array();
	if ( ! $chose ) {
		$held = ogc_lod_real( isset( $d['rooms'] ) ? $d['rooms'] : array(), ogc_lod_rooms_memo( $y ) );
		if ( ! $held ) {
			return array();
		}
		// A room freed by a change is never shown, unless Lodging has given it back since (red team round
		// 2, A1: placed again in the room it was freed from, the household was shown none).
		$gone = isset( $d['freed']['rooms'] ) ? array_diff( array_map( 'strval', (array) $d['freed']['rooms'] ), $held ) : array();
		return array_values( array_diff( $list, $gone ) );
	}
	// A room chosen on the map is shown only until Lodging decides the household's rooms (red team round
	// 2, R2A4-18: replaced and given to another, the old choice was still "my room").
	if ( ogc_lod_decided( $d ) ) {
		return array();
	}
	$taken = array_flip( ogc_lod_taken_rooms( $y, $rid ) );
	return array_values( array_filter( $list, function ( $id ) use ( $taken ) { return ! isset( $taken[ $id ] ); } ) );
}

/** Every room held now by anyone but household $rid (Lodging's rows, Youngfolks' hall rooms, rooms chosen
 * on the map): room ids. For the form's own check of a room chosen on the map (red team J1). */
function ogc_lod_taken_rooms( $y, $rid = '' ) {
	$out = array();
	foreach ( ogc_lod_claims( ogc_lod_ctx( (int) $y ), ogc_lod_claim_data( (int) $y ) ) as $room => $keys ) {
		if ( array_diff( $keys, array( 'hh:' . $rid ) ) ) {
			$out[] = (string) $room;
		}
	}
	return $out;
}

/** Is anything of this year's still to clear (rows naming households, what households saw, the counts to keep)? */
function ogc_lod_to_clear( $y ) {
	$st = ogc_state_get( $y, 'rooms' );
	return ogc_lod_rows( $y, 'hh:' ) || ogc_lod_rows( $y, 'yf:' ) || ! ogc_lod_row( $y, 'meta:numbers' ) || ( $st && (array) $st['value'] );
}

/**
 * Is a household Placed (the one fixed status, ogc_rec_status_of in module-records.php)? Every family room
 * it asked for given, when anyone sleeps with the family (1 of 2 is still to place: Michael Q3 waits), and
 * every Youngfolk of it in a hall given a hall room still in the halls (red team round 3, ATK3 D1: a
 * Youngfolk on his own read Registered, "still to place", with his hall room given). Campers and those
 * off campus as before. $given: its family rooms still in the halls; $ctx: ogc_rec_ctx (lodyf: the
 * Youngfolks' rows), or null.
 */
function ogc_lod_status_placed( $rec, $given, $ctx = null ) {
	$d     = is_array( $rec['data'] ) ? $rec['data'] : array();
	$type  = isset( $d['stay']['type'] ) ? (string) $d['stay']['type'] : '';
	$asked = max( 1, (int) ( isset( $d['stay']['rooms'] ) ? $d['stay']['rooms'] : 1 ) );
	$fam   = $given && count( $given ) >= $asked;
	if ( ! in_array( $type, array( 'dorm', 'yf' ), true ) ) {
		return $fam;
	}
	$hall   = array();
	$family = 0;
	foreach ( (array) ( isset( $d['people'] ) ? $d['people'] : array() ) as $p ) {
		if ( empty( $p['name'] ) ) {
			continue;
		}
		if ( ogc_lod_in_hall( $p, $d ) ) {
			$hall[] = $p;
		} else {
			$family++;
		}
	}
	if ( ! $hall ) {
		return $fam;
	}
	$y     = (int) $rec['year'];
	$rooms = ogc_lod_rooms_memo( $y );
	$yf    = is_array( $ctx ) && isset( $ctx['lodyf'] ) ? $ctx['lodyf'] : ogc_lod_rows( $y, 'yf:' );
	foreach ( $hall as $p ) {
		$r = ! empty( $p['pid'] ) && isset( $yf[ 'yf:' . $p['pid'] ]['data']['room'] ) ? (string) $yf[ 'yf:' . $p['pid'] ]['data']['room'] : '';
		if ( '' === $r || ! isset( $rooms[ $r ] ) ) {
			return false;
		}
	}
	return 'yf' === $type || ! $family ? true : $fam;
}

/**
 * Where a year's rooms stand, in counts (no names): for the year page's card ("Rooms · 82 to assign").
 * array( dorm, assigned, waiting, published (date or ''), changed_since ). Households that will come
 * only (invariant 41); a household is assigned once every room it asked for has a real room (16).
 */
function ogc_lod_summary( $year ) {
	$rows  = ogc_lod_rows( $year, 'hh:' );
	$rooms = ogc_lod_rooms( $year );
	$marks = ogc_lod_marks( $year );
	$pub   = ogc_lod_row( $year, 'meta:published' );
	$snap  = $pub && isset( $pub['data']['snap'] ) ? (array) $pub['data']['snap'] : array();
	$out   = array( 'dorm' => 0, 'assigned' => 0, 'waiting' => 0, 'published' => $pub && ! empty( $pub['data']['date'] ) ? $pub['data']['date'] : '', 'changed' => 0 );
	$sctx  = array( 'lodyf' => ogc_lod_rows( $year, 'yf:' ) );
	foreach ( ogc_lod_households( $year ) as $rid => $rec ) {
		if ( ! ogc_lod_coming( $rec, $marks ) ) {
			continue;
		}
		$out['dorm']++;
		$given = ogc_lod_real( isset( $rows[ 'hh:' . $rid ]['data']['rooms'] ) ? $rows[ 'hh:' . $rid ]['data']['rooms'] : array(), $rooms );
		// Assigned as the status says Placed (the same rule: a hall Youngfolk still to place is still to assign).
		ogc_lod_status_placed( $rec, $given, $sctx ) ? $out['assigned']++ : $out['waiting']++;
		if ( $out['published'] && array_values( isset( $snap[ $rid ] ) ? (array) $snap[ $rid ] : array() ) !== $given ) {
			$out['changed']++;
		}
	}
	return $out;
}

/* ================================================================== guards */

// What households see is written by Lodging's Publish only (invariant 91): the generic state route
// refuses it for everyone, webmasters included.
add_filter( 'rest_request_before_callbacks', function ( $resp, $handler, $req ) {
	if ( ! is_wp_error( $resp ) && 'GET' !== $req->get_method() && preg_match( '#^/' . preg_quote( OGC_NS, '#' ) . '/years/\d{4}/state/rooms$#', (string) $req->get_route() ) ) {
		return new WP_Error( 'ogc_forbidden', 'Published by Lodging only', array( 'status' => 403 ) );
	}
	return $resp;
}, 6, 3 );

/* ------------------------------------------------------------------ a guard's hold on the locks */

/**
 * A guard below takes Lodging's lock for the request it watches, so its check and the request's own
 * write are one change, never interleaved with Place (red team ATK1-halls-retype-race, G1). It is let
 * go when the request is answered (rest_request_after_callbacks, whatever the answer).
 */
function ogc_lod_guard_lock( $req, $y ) {
	if ( ogc_lod_holding( $y ) ) {
		return true;
	}
	$t = ogc_lod_lock( $y );
	if ( ! $t ) {
		return false;
	}
	$GLOBALS['ogc_lod_guard'][ spl_object_hash( $req ) ] = array( (int) $y, $t );
	return true;
}

function ogc_lod_guard_unlock( $req ) {
	$h = spl_object_hash( $req );
	// Lodging's first, then the registration's: the reverse of taking them.
	if ( isset( $GLOBALS['ogc_lod_guard'][ $h ] ) ) {
		list( $y, $t ) = $GLOBALS['ogc_lod_guard'][ $h ];
		unset( $GLOBALS['ogc_lod_guard'][ $h ], $GLOBALS['ogc_lod_halls_check'][ $y ] );
		ogc_lod_unlock( $y, $t );
	}
	if ( isset( $GLOBALS['ogc_lod_guard_reg'][ $h ] ) ) {
		$ry = $GLOBALS['ogc_lod_guard_reg'][ $h ];
		unset( $GLOBALS['ogc_lod_guard_reg'][ $h ], $GLOBALS['ogc_reg_nest'][ (int) $ry ] );
		ogc_reg_unlock( $ry );
	}
}

/**
 * The guard's hold on both locks, in their order (the registration's, then Lodging's), for a request that
 * changes a registration Lodging's rooms depend on: its checks and the route's own write are one change,
 * never interleaved with Place, the desk or another registration change (red team round 2: the register's
 * guards read Lodging's rows before any lock and never again, ATK1-r2-map-choice-race, -checkin-vs-camper,
 * -checkin-vs-cancel, -checkin-vs-records, -checkin-vs-hh-cancel, -early-night-race, A5). The route's own
 * ogc_reg_lock and ogc_lod_lock are nested in it. Busy for a few seconds: 503 "Busy · Try again", before
 * anything is saved. Let go when the request is answered.
 */
function ogc_lod_guard_both( $req, $y ) {
	$h = spl_object_hash( $req );
	if ( ! function_exists( 'ogc_reg_lock' ) ) {
		return ogc_lod_guard_lock( $req, $y );
	}
	if ( ! ogc_reg_holding( $y ) ) {
		if ( ! ogc_reg_lock( $y ) ) {
			return false;
		}
		$GLOBALS['ogc_lod_guard_reg'][ $h ] = (int) $y;
	}
	if ( ! ogc_lod_guard_lock( $req, $y ) ) {
		ogc_lod_guard_unlock( $req );
		return false;
	}
	ogc_store_forget();
	$GLOBALS['ogc_reg_cfg_stale'] = true;
	unset( $GLOBALS['ogc_rec_ctx'], $GLOBALS['ogc_lod_rooms_memo'] );
	return true;
}

add_filter( 'rest_request_after_callbacks', function ( $resp, $handler, $req ) {
	ogc_lod_guard_unlock( $req );
	return $resp;
}, 99, 3 );

/* ------------------------------------------------------------------ the halls */

/**
 * A change to the halls never takes away a room someone holds, or leaves it wrong for who is in it: not
 * for families any more, the other hall, fewer beds than the people in it, fewer than its Youngfolks
 * (invariants 2, 3, 5, 26, 29; red team A3, ATK1-beds-lowered-halls, A4-27, I2). Every door to rooms.csv:
 * the files route (PUT, PATCH a row), the editors' rows route, a new campus (apply), Restore, and the
 * year picked up again. Checked and written under Lodging's lock. Refused, saying which room and, to
 * those who may see rooms, who.
 */
add_filter( 'rest_request_before_callbacks', function ( $resp, $handler, $req ) {
	if ( is_wp_error( $resp ) || 'GET' === $req->get_method() ) {
		return $resp;
	}
	$ns    = preg_quote( OGC_NS, '#' );
	$route = (string) $req->get_route();
	if ( preg_match( '#^/' . $ns . '/years/(\d{4})/files/rooms$#', $route, $m ) ) {
		$kind = 'file';
	} elseif ( preg_match( '#^/' . $ns . '/years/(\d{4})/rows/rooms$#', $route, $m ) ) {
		$kind = 'rows';
	} elseif ( 'POST' === $req->get_method() && preg_match( '#^/' . $ns . '/coa/(\d{4})/(campus|campus-restore|pickup)$#', $route, $m ) ) {
		$kind = $m[2];
	} else {
		return $resp;
	}
	$y = (int) $m[1];
	if ( ! ogc_is_member( $y ) || null === ogc_year_get( $y ) ) {
		return $resp;   // the route refuses
	}
	if ( ( 'campus' === $kind && ! $req->get_param( 'apply' ) ) || ( 'pickup' === $kind && ! $req->get_param( 'force' ) ) ) {
		return $resp;   // only says what it would do
	}
	if ( ! ogc_lod_guard_lock( $req, $y ) ) {
		return ogc_lod_busy();
	}
	$words = '';
	if ( 'file' === $kind && 'PATCH' === $req->get_method() ) {
		if ( 'row' === $req->get_param( 'op' ) && is_array( $req->get_param( 'row' ) ) ) {
			$cur     = ogc_file_get( $y, 'rooms' );
			$after   = $cur ? (array) $cur['rows'] : array();
			$after[] = $req->get_param( 'row' );
			$words   = ogc_lod_halls_beds_wrong( array( $req->get_param( 'row' ) ) );
			$words   = '' !== $words ? $words : ogc_lod_halls_names_wrong( $after );
			$words   = '' !== $words ? $words : ogc_lod_halls_change_wrong( $y, ogc_lod_rooms_of_rows( $after ) );
		}
	} elseif ( 'file' === $kind || 'rows' === $kind ) {
		// The rows as they'll be written are checked where the route checks them (ogc_file_rows_valid).
		$GLOBALS['ogc_lod_halls_check'][ $y ] = true;
	} elseif ( 'campus-restore' === $kind ) {
		$s    = ogc_state_get( $y, 'campus_undo' );
		$v    = $s ? (array) $s['value'] : array();
		$rows = isset( $v['files'] ) && is_array( $v['files'] ) && isset( $v['files']['rooms'] ) ? (array) $v['files']['rooms'] : null;
		if ( null !== $rows ) {
			$words = ogc_lod_halls_change_wrong( $y, ogc_lod_rooms_of_rows( $rows ) );
		}
	} else {
		// A new campus, or the year picked up again: its halls are replaced.
		$n = 0;
		foreach ( ogc_lod_claims( ogc_lod_ctx( $y ), ogc_lod_claim_data( $y ) ) as $keys ) {
			$n++;
		}
		if ( $n ) {
			$words = $n . ( 1 === $n ? ' room given · Lodging frees it first' : ' rooms given · Lodging frees them first' );
		}
	}
	if ( '' !== $words ) {
		ogc_lod_guard_unlock( $req );
		return new WP_Error( 'ogc_conflict', $words, array( 'status' => 409 ) );
	}
	return $resp;
}, 7, 3 );

add_filter( 'ogc_file_rows_valid', function ( $ok, $rows, $y, $name ) {
	if ( true !== $ok || 'rooms' !== $name ) {
		return $ok;
	}
	$b = ogc_lod_halls_beds_wrong( $rows );
	$b = '' !== $b ? $b : ogc_lod_halls_names_wrong( $rows );
	if ( '' !== $b ) {
		return new WP_Error( 'ogc_invalid', $b, array( 'status' => 400 ) );
	}
	if ( empty( $GLOBALS['ogc_lod_halls_check'][ (int) $y ] ) ) {
		return $ok;
	}
	$w = ogc_lod_halls_change_wrong( (int) $y, ogc_lod_rooms_of_rows( $rows ) );
	return '' === $w ? $ok : new WP_Error( 'ogc_conflict', $w, array( 'status' => 409 ) );
}, 10, 4 );

/** A hall's beds a room, as rooms.csv may say them: blank (registration.csv's room_beds), or 1 to 8, as
 * Lodging's own beds fact (red team round 2, K3_E3: 0 read as room_beds, 40 slept 41). Words, or ''. */
function ogc_lod_halls_beds_wrong( $rows ) {
	foreach ( (array) $rows as $r ) {
		$r = (array) $r;
		$b = isset( $r['beds'] ) ? trim( (string) $r['beds'] ) : '';
		if ( empty( $r['hall'] ) || '#' === substr( (string) $r['hall'], 0, 1 ) || '' === $b ) {
			continue;
		}
		if ( ! preg_match( '/^\d+$/', $b ) || (int) $b < 1 || (int) $b > 8 ) {
			return $r['hall'] . ( isset( $r['first'] ) ? ' ' . $r['first'] : '' ) . ' · Beds 1 to 8';
		}
	}
	return '';
}

/** One room on the campus is one room on the board: a hall's name with space around it, a hall named
 * twice in different cases, or a room listed in two rows would each be a room of its own, given to a
 * household each (red team round 3, ATK3 C1: "X3 Reed 101" three times, three households told it was
 * theirs). Words, or ''. */
function ogc_lod_halls_names_wrong( $rows ) {
	$names = array();
	$seen  = array();
	foreach ( (array) $rows as $r ) {
		$r    = (array) $r;
		$hall = isset( $r['hall'] ) ? (string) $r['hall'] : '';
		if ( '' === trim( $hall ) || '#' === substr( trim( $hall ), 0, 1 ) ) {
			continue;
		}
		if ( trim( $hall ) !== $hall || preg_match( '/\s{2,}/', $hall ) ) {
			return 'Hall “' . $hall . '” · Extra space';
		}
		$low = function_exists( 'mb_strtolower' ) ? mb_strtolower( $hall ) : strtolower( $hall );
		if ( isset( $names[ $low ] ) && $names[ $low ] !== $hall ) {
			return 'Hall “' . $hall . '” · Same as ' . $names[ $low ];
		}
		$names[ $low ] = $hall;
		if ( ! is_numeric( isset( $r['first'] ) ? $r['first'] : '' ) || ! is_numeric( isset( $r['last'] ) ? $r['last'] : '' ) ) {
			continue;
		}
		for ( $n = (int) $r['first']; $n <= (int) $r['last'] && $n - (int) $r['first'] < 400; $n++ ) {
			if ( isset( $seen[ $hall . '|' . $n ] ) ) {
				return $hall . ' ' . $n . ' · Listed twice';
			}
			$seen[ $hall . '|' . $n ] = true;
		}
	}
	return '';
}

/** What a change to the halls would leave wrong, in words ('' when nothing): every room someone holds,
 * judged in the halls as they'd be (ogc_lod_room_issue), for what the change adds. */
function ogc_lod_halls_change_wrong( $y, $after ) {
	$ctx           = ogc_lod_ctx( $y );
	$rows          = ogc_lod_claim_data( $y );
	$ctx2          = $ctx;
	$ctx2['rooms'] = $after;
	$see           = function_exists( 'ogc_access' ) ? ogc_access( $y, 'rooms' ) : false;
	foreach ( ogc_lod_claims( $ctx, $rows ) as $room => $keys ) {
		$k   = $keys[0];
		$who = $see && 0 === strpos( $k, 'hh:' ) && isset( $ctx['hh'][ substr( $k, 3 ) ] ) ? ogc_lod_label( $ctx['hh'][ substr( $k, 3 ) ]['data'] ) : ( 0 === strpos( $k, 'yf:' ) ? 'Youngfolks' : 'A household' );
		if ( ! isset( $after[ $room ] ) ) {
			return ogc_lod_room_words( $room ) . ' is given · ' . $who . ' · Lodging frees it first';
		}
		$i2 = ogc_lod_room_issue( $ctx2, $room, $keys, $rows );
		if ( ! $i2 ) {
			continue;
		}
		$i1 = ogc_lod_room_issue( $ctx, $room, $keys, $rows );
		if ( $i1 && $i1['code'] === $i2['code'] && $i1['words'] === $i2['words'] ) {
			continue;
		}
		$beds = ogc_lod_beds( $y, $room, $after, $ctx['facts'] );
		$why  = array( 'for' => 'Not for ' . $after[ $room ]['for'], 'hall' => 'Not for ' . $after[ $room ]['for'], 'over' => 'Sleeps ' . ( $beds + 1 ), 'full' => 'Takes ' . min( 3, $beds + 1 ) );
		return ogc_lod_room_words( $room ) . ' is given · ' . $who . ' · ' . ( isset( $why[ $i2['code'] ] ) ? $why[ $i2['code'] ] : $i2['words'] );
	}
	return '';
}

/* ------------------------------------------------------------------ Didn't come */

/**
 * The COA marks a household Didn't come (module-records.php): refused while the desk has it checked in
 * (the keys are out: invariant 57); else its rooms, and its Youngfolks' hall rooms, are freed at once for
 * walk-ins (invariant 60; Lodging Q7 asks when) and named on Lodging's rows. The mark and the freeing are
 * one change under Lodging's lock, so the desk's check-in never lands between them (red team G1). Taking
 * the mark back gives nothing back by itself: Lodging places by hand.
 */
add_filter( 'rest_request_before_callbacks', function ( $resp, $handler, $req ) {
	if ( is_wp_error( $resp ) || 'POST' !== $req->get_method() || 'noshow' !== $req->get_param( 'mark' ) || ! preg_match( '#^/' . preg_quote( OGC_NS, '#' ) . '/app/(\d{4})/households/mark$#', (string) $req->get_route(), $m ) ) {
		return $resp;
	}
	$y   = (int) $m[1];
	$rec = function_exists( 'ogc_rec_by_rid' ) && is_scalar( $req->get_param( 'rid' ) ) && ogc_is_member( $y ) ? ogc_rec_by_rid( $y, (string) $req->get_param( 'rid' ) ) : null;
	if ( ! $rec ) {
		return $resp;
	}
	if ( ! ogc_lod_guard_lock( $req, $y ) ) {
		return ogc_lod_busy();
	}
	// Checked in, or a Youngfolk's hall key out (red team round 2, D2: a Youngfolk on her own has no
	// household row, and her room was freed with the key out).
	$w = ogc_lod_keys_out_words( $y, $rec );
	if ( '' !== $w ) {
		ogc_lod_guard_unlock( $req );
		return new WP_Error( 'ogc_checked_in', $w . ( 'Checked in' === $w ? ' · Undo check-in first' : ' · Undo key out first' ), array( 'status' => 409 ) );
	}
	// Not before the household's own first night (red team round 2, G1: marked Saturday, due Sunday, its
	// room went to a walk-in a day early). Lodging Q7 asks when Didn't come frees; meanwhile not before.
	$first = ogc_lod_first_night( $y, $rec['data'] );
	$today = ogc_lod_today( $y, $req );
	if ( $first && $today < $first['date'] ) {
		ogc_lod_guard_unlock( $req );
		return new WP_Error( 'ogc_not_now', 'First night ' . $first['night'] . ' · Not yet', array( 'status' => 409 ) );
	}
	return $resp;
}, 8, 3 );

/** The Conference's days, each dated from the Conference's own first day (the year's row), as the desk's
 * opening and the end of the Conference are: the two never disagree about which day is which. */
function ogc_lod_days( $y ) {
	if ( ! function_exists( 'ogc_reg_days' ) ) {
		return array();
	}
	$days = ogc_reg_days( (int) $y );
	$row  = ogc_year_get( (int) $y );
	if ( $days && $row && ! empty( $row['start'] ) && (string) $row['start'] !== $days[0]['date'] && function_exists( 'ogc_reg_add_days' ) ) {
		foreach ( $days as $i => $dd ) {
			$days[ $i ]['date'] = ogc_reg_add_days( (string) $row['start'], $i );
		}
	}
	return $days;
}

/** A night's date ("Friday", "Early Thursday"), or '' when it isn't one of the year's. */
function ogc_lod_night_on( $y, $night ) {
	return function_exists( 'ogc_reg_night_date' ) ? (string) ogc_reg_night_date( ogc_lod_days( $y ), (string) $night ) : '';
}

/** A registration's own nights (every night one of its people sleeps here) with their dates, in date
 * order: night => date. An early night is the day it names before the Conference. */
function ogc_lod_nights_dated( $y, $d ) {
	if ( ! function_exists( 'ogc_reg_night_date' ) || ! function_exists( 'ogc_reg_days' ) ) {
		return array();
	}
	$days   = ogc_lod_days( $y );
	$nights = (array) ( isset( $d['stay']['nights'] ) ? $d['stay']['nights'] : array() );
	foreach ( (array) ( isset( $d['people'] ) ? $d['people'] : array() ) as $p ) {
		$nights = array_merge( $nights, (array) ( isset( $p['nights'] ) ? $p['nights'] : array() ) );
	}
	$out = array();
	foreach ( array_unique( array_map( 'strval', $nights ) ) as $n ) {
		$date = (string) ogc_reg_night_date( $days, $n );
		if ( '' !== $date ) {
			$out[ $n ] = $date;
		}
	}
	asort( $out );
	return $out;
}

/** A registration's first night and its date: array( night, date ), or null (no nights, no dates). */
function ogc_lod_first_night( $y, $d ) {
	$n = ogc_lod_nights_dated( $y, $d );
	if ( ! $n ) {
		return null;
	}
	reset( $n );
	return array( 'night' => (string) key( $n ), 'date' => (string) current( $n ) );
}

/** A registration's last night and its date: array( night, date ), or null. */
function ogc_lod_last_night( $y, $d ) {
	$n = ogc_lod_nights_dated( $y, $d );
	if ( ! $n ) {
		return null;
	}
	end( $n );
	return array( 'night' => (string) key( $n ), 'date' => (string) current( $n ) );
}

/** The day the desk recorded something (a check-in, a room's keys back): its own day, kept since round 3,
 * else the day of its stamp. */
function ogc_lod_desk_day( $stamp ) {
	if ( ! is_array( $stamp ) ) {
		return '';
	}
	return ! empty( $stamp['day'] ) ? (string) $stamp['day'] : ( ! empty( $stamp['at'] ) ? substr( (string) $stamp['at'], 0, 10 ) : '' );
}

/**
 * The nights the desk saw a household sleep in its rooms: its own nights from the day it checked in, up to
 * its first night not used, or the day the last of its keys came back, or today. None before a check-in. A
 * check-in recorded after the Conference counts from the household's first night. night => date.
 * Red team round 3, X2-C1, X2-C2: Change took away a night already slept, at the desk and after check-out.
 */
function ogc_lod_slept( $y, $rec, $today ) {
	$row = ogc_lod_row( $y, 'hh:' . ogc_lod_rid( $rec ) );
	$d   = $row ? (array) $row['data'] : array();
	if ( ! ogc_lod_checked_in( $d ) ) {
		return array();
	}
	$own   = ogc_lod_nights_dated( $y, (array) $rec['data'] );
	$first = $own ? reset( $own ) : '';
	$in    = ! empty( $d['checkin']['late'] ) ? $first : ogc_lod_desk_day( $d['checkin'] );
	$in    = '' !== $in ? $in : $first;
	$end   = (string) $today;
	if ( ! empty( $d['left']['night'] ) ) {
		$ld  = ogc_lod_night_on( $y, $d['left']['night'] );
		$end = '' !== $ld ? min( $end, $ld ) : $end;
	}
	$rooms = ogc_lod_real( isset( $d['rooms'] ) ? $d['rooms'] : array(), ogc_lod_rooms( $y ) );
	$back  = isset( $d['back'] ) ? (array) $d['back'] : array();
	$last  = '';
	foreach ( $rooms as $r ) {
		if ( empty( $back[ $r ] ) ) {
			$last = '';
			break;
		}
		$last = max( $last, ogc_lod_desk_day( (array) $back[ $r ] ) );
	}
	$end = '' !== $last ? min( $end, $last ) : $end;
	$out = array();
	foreach ( $own as $n => $date ) {
		if ( $date >= $in && $date < $end ) {
			$out[ $n ] = $date;
		}
	}
	return $out;
}

/** A change to a registration ($new, cleaned) that would take away a night the desk saw slept in its
 * family rooms, for anyone who slept it: words ("Friday · Already stayed", "Levi · Already stayed"), or ''.
 * Leave early ends the stay from last night on; a night already slept stays the household's. */
function ogc_lod_slept_words( $y, $rec, $new, $today ) {
	$slept = ogc_lod_slept( $y, $rec, $today );
	if ( ! $slept || ! function_exists( 'ogc_reg_nights_for' ) ) {
		return '';
	}
	$cfg = ogc_reg_cfg( $y );
	$old = (array) $rec['data'];
	$new = is_array( $new ) ? $new : array();
	$now = array();
	foreach ( (array) ( isset( $new['people'] ) ? $new['people'] : array() ) as $q ) {
		if ( is_array( $q ) && ! empty( $q['pid'] ) ) {
			$now[ 'p:' . $q['pid'] ] = $q;
		}
		if ( is_array( $q ) && ! empty( $q['name'] ) ) {
			$now[ 'n:' . strtolower( (string) $q['name'] ) ] = isset( $now[ 'n:' . strtolower( (string) $q['name'] ) ] ) ? $now[ 'n:' . strtolower( (string) $q['name'] ) ] : $q;
		}
	}
	foreach ( (array) ( isset( $old['people'] ) ? $old['people'] : array() ) as $p ) {
		if ( empty( $p['name'] ) || ogc_lod_in_hall( $p, $old ) ) {
			continue;
		}
		$had = array_values( array_intersect( array_keys( $slept ), array_map( 'strval', (array) ogc_reg_nights_for( $p, $old, $cfg ) ) ) );
		if ( ! $had ) {
			continue;
		}
		$q = ! empty( $p['pid'] ) && isset( $now[ 'p:' . $p['pid'] ] ) ? $now[ 'p:' . $p['pid'] ] : ( isset( $now[ 'n:' . strtolower( (string) $p['name'] ) ] ) ? $now[ 'n:' . strtolower( (string) $p['name'] ) ] : null );
		if ( ! $q ) {
			return ogc_lod_first( $p['name'] ) . ' · Already stayed';
		}
		$has = ogc_lod_in_hall( $q, $new ) || 'dorm' !== ( isset( $new['stay']['type'] ) ? $new['stay']['type'] : 'dorm' ) ? array() : array_map( 'strval', (array) ogc_reg_nights_for( $q, $new, $cfg ) );
		foreach ( $had as $n ) {
			if ( ! in_array( $n, $has, true ) ) {
				return $n . ' · Already stayed';
			}
		}
	}
	return '';
}

/** Are all of a household's rooms' keys back (the desk's Checked out)? */
function ogc_lod_all_back( $y, $d ) {
	$rooms = ogc_lod_real( isset( $d['rooms'] ) ? $d['rooms'] : array(), ogc_lod_rooms( $y ) );
	foreach ( $rooms as $r ) {
		if ( empty( $d['back'][ $r ] ) ) {
			return false;
		}
	}
	return (bool) $rooms;
}

add_filter( 'rest_request_after_callbacks', function ( $resp, $handler, $req ) {
	if ( is_wp_error( $resp ) || 'POST' !== $req->get_method() || 'noshow' !== $req->get_param( 'mark' ) || ! preg_match( '#^/' . preg_quote( OGC_NS, '#' ) . '/app/(\d{4})/households/mark$#', (string) $req->get_route(), $m ) ) {
		return $resp;
	}
	if ( $resp instanceof WP_REST_Response && $resp->get_status() >= 300 ) {
		return $resp;
	}
	$y   = (int) $m[1];
	$rec = function_exists( 'ogc_rec_by_rid' ) && is_scalar( $req->get_param( 'rid' ) ) ? ogc_rec_by_rid( $y, (string) $req->get_param( 'rid' ) ) : null;
	if ( $rec ) {
		ogc_lod_reg_saved( $y, $rec['data'], $rec['data'], 'Didn’t come' );
	}
	return $resp;
}, 10, 3 );

/* ------------------------------------------------------------------ registrations */

/**
 * Each person's lasting id (pid) is theirs alone in the year: an id another registration of the year
 * has (or had: a household an import removed may come back) is given a new one. Lodging's hall rooms are
 * kept by pid, so a household's own change could otherwise take another family's Youngfolk's hall room
 * (red team A4-20, A4-21). $people as sent; $own: the record's id (0 for a new one).
 */
function ogc_lod_own_pids( $y, $people, $own = 0 ) {
	global $wpdb;
	$mine   = array();
	$theirs = array();
	foreach ( (array) $wpdb->get_results( $wpdb->prepare( 'SELECT id, data FROM ' . ogc_table( 'records' ) . " WHERE year = %d AND kind = 'registrations'", $y ), ARRAY_A ) as $r ) {
		$d = ogc_unjson( $r['data'], array() );
		foreach ( (array) ( isset( $d['people'] ) ? $d['people'] : array() ) as $p ) {
			if ( is_array( $p ) && ! empty( $p['pid'] ) ) {
				if ( (int) $r['id'] === (int) $own ) {
					$mine[ (string) $p['pid'] ] = true;
				} else {
					$theirs[ (string) $p['pid'] ] = true;
				}
			}
		}
	}
	foreach ( $people as $i => $p ) {
		if ( is_array( $p ) && ! empty( $p['pid'] ) && isset( $theirs[ (string) $p['pid'] ] ) && ! isset( $mine[ (string) $p['pid'] ] ) ) {
			$people[ $i ]['pid'] = function_exists( 'ogc_reg_new_pid' ) ? ogc_reg_new_pid() : '';
		}
	}
	return $people;
}

/**
 * Which of the doors Lodging guards a request is: array( door, year, record ) or null. A registration's
 * change, Cancel, Leave early, a parent's approval sent again, a new registration, a parent's Approve,
 * the committee's Cancel and Offer, the generic records route, registration.csv, the year's own row.
 */
function ogc_lod_door( $req ) {
	$ns    = preg_quote( OGC_NS, '#' );
	$route = (string) $req->get_route();
	$m     = $req->get_method();
	$door  = '';
	$rec   = null;
	if ( 'PUT' === $m && preg_match( '#^/' . $ns . '/reg/r/(\d+)$#', $route, $x ) ) {
		$door = 'change';
		$rec  = ogc_record_get( (int) $x[1] );
	} elseif ( 'POST' === $m && preg_match( '#^/' . $ns . '/reg/r/(\d+)/(cancel|leave|approval)$#', $route, $x ) ) {
		$door = $x[2];
		$rec  = ogc_record_get( (int) $x[1] );
	} elseif ( 'POST' === $m && preg_match( '#^/' . $ns . '/reg/approve/([^/]+)$#', $route, $x ) ) {
		$door = 'approve';
		$rec  = function_exists( 'ogc_reg_by_approval' ) ? ogc_reg_by_approval( rawurldecode( $x[1] ) ) : null;
	} elseif ( 'POST' === $m && preg_match( '#^/' . $ns . '/reg/(\d{4})$#', $route, $x ) ) {
		return array( 'new', (int) $x[1], null );
	} elseif ( 'POST' === $m && preg_match( '#^/' . $ns . '/app/(\d{4})/households/(cancel|offer)$#', $route, $x ) ) {
		$door = 'hh-' . $x[2];
		$rec  = function_exists( 'ogc_rec_by_rid' ) && is_scalar( $req->get_param( 'rid' ) ) && ogc_is_member( (int) $x[1] ) ? ogc_rec_by_rid( (int) $x[1], (string) $req->get_param( 'rid' ) ) : null;
	} elseif ( 'PUT' === $m && preg_match( '#^/' . $ns . '/records/(\d+)$#', $route, $x ) ) {
		$door = 'record';
		$rec  = ogc_record_get( (int) $x[1] );
	} elseif ( ( in_array( $m, array( 'PUT', 'PATCH' ), true ) && preg_match( '#^/' . $ns . '/years/(\d{4})/files/registration$#', $route, $x ) ) || ( 'POST' === $m && preg_match( '#^/' . $ns . '/coa/(\d{4})/reg$#', $route, $x ) ) ) {
		// registration.csv, through the files route or the year page's own (coa/{y}/reg writes the same file).
		return array( 'regfile', (int) $x[1], null );
	} elseif ( in_array( $m, array( 'PUT', 'PATCH', 'POST' ), true ) && preg_match( '#^/' . $ns . '/years/(\d{4})$#', $route, $x ) ) {
		return array( 'year', (int) $x[1], null );
	} elseif ( 'POST' === $m && preg_match( '#^/' . $ns . '/coa/(\d{4})/dates$#', $route, $x ) ) {
		return array( 'dates', (int) $x[1], null );
	} else {
		return null;
	}
	if ( ! $rec || 'registrations' !== $rec['kind'] ) {
		return null;
	}
	return array( $door, (int) $rec['year'], $rec );
}

/** Is the person signed in seeing this registration as Lodging's version (area-households-money 5.1:
 * Lodging's head and helpers, not the COA, not the committee holding Households, not Handles money, not
 * the household itself)? Then no email, no helper's email or phone, no parent's address, no payment lines. */
function ogc_lod_lodging_version( $rec ) {
	$y = (int) $rec['year'];
	if ( ! function_exists( 'ogc_access_viewer' ) || ! function_exists( 'ogc_app_can_see' ) || ( function_exists( 'ogc_reg_is_household' ) && ogc_reg_is_household( $rec ) ) ) {
		return false;
	}
	$v = ogc_access_viewer( $y );
	if ( ! empty( $v['coa'] ) || ogc_app_can_see( $v, 'households' ) || ( function_exists( 'ogc_access' ) && ogc_access( $y, 'money' ) ) ) {
		return false;
	}
	return ogc_app_can_see( $v, 'lod-households' ) || ogc_app_can_see( $v, 'lod-rooms' ) || ogc_app_can_see( $v, 'lod-checkin' );
}

/** May the person signed in see this registration's rooms (its own household, or ogc_access rooms)? */
function ogc_lod_sees_rooms( $rec ) {
	if ( function_exists( 'ogc_reg_is_household' ) && ogc_reg_is_household( $rec ) ) {
		return true;
	}
	return ! function_exists( 'ogc_access' ) || ogc_access( (int) $rec['year'], 'rooms' );
}

/** What someone who couldn't see it sent back blank is kept as it was: Lodging's version (the emails, the
 * helper's phone, the parent's address) and, without Rooms, the rooms chosen on the map. $in: the data as
 * sent; returns it with those fields as stored. */
function ogc_lod_keep_withheld( $rec, $in ) {
	$old = (array) $rec['data'];
	if ( ogc_lod_lodging_version( $rec ) ) {
		foreach ( array( array( 'household', 'email' ), array( 'helper', 'email' ), array( 'helper', 'phone' ), array( 'stay', 'parentEmail' ) ) as $f ) {
			if ( isset( $in[ $f[0] ] ) && is_array( $in[ $f[0] ] ) ) {
				$in[ $f[0] ][ $f[1] ] = isset( $old[ $f[0] ][ $f[1] ] ) ? $old[ $f[0] ][ $f[1] ] : '';
			}
		}
	}
	if ( ! ogc_lod_sees_rooms( $rec ) && isset( $in['stay'] ) && is_array( $in['stay'] ) ) {
		$in['stay']['chosen'] = isset( $old['stay']['chosen'] ) ? $old['stay']['chosen'] : array();
	}
	return $in;
}

/** Where households don't choose on the map (room_choice isn't households), nobody's rooms chosen change:
 * Lodging gives rooms (red team round 2, R2A4-04, R2A4-05: a household saved another's published room as
 * its own, and the guide's map named it, with the hall's key-only doors). */
function ogc_lod_keep_chosen( $y, $old, $in ) {
	$cfg = ogc_lod_kv( $y, 'registration' );
	if ( 'households' !== ( isset( $cfg['room_choice'] ) ? $cfg['room_choice'] : '' ) && isset( $in['stay'] ) && is_array( $in['stay'] ) ) {
		$in['stay']['chosen'] = isset( $old['stay']['chosen'] ) ? $old['stay']['chosen'] : array();
	}
	return $in;
}

/**
 * What's wrong with the rooms a household chose on the map, as the form would save them ($d, cleaned), in
 * words ('' when nothing): judged as Place judges a room (red team round 2, R2A4-12, R2A4-19, -map-choice-
 * race): a room for families, not out of service or kept, sleeping no more than its beds + 1, held by no one
 * else. Only where households choose; a household whose rooms Lodging has decided keeps Lodging's.
 */
function ogc_lod_chosen_wrong( $y, $rid, $d ) {
	$cfg = ogc_lod_kv( $y, 'registration' );
	if ( 'households' !== ( isset( $cfg['room_choice'] ) ? $cfg['room_choice'] : '' ) || 'dorm' !== ( isset( $d['stay']['type'] ) ? $d['stay']['type'] : '' ) ) {
		return '';
	}
	$chosen = isset( $d['stay']['chosen'] ) ? array_values( array_filter( array_map( 'strval', (array) $d['stay']['chosen'] ) ) ) : array();
	if ( ! $chosen ) {
		return '';
	}
	$rid  = '' !== (string) $rid ? (string) $rid : 'new';
	$rows = ogc_lod_claim_data( $y );
	if ( isset( $rows[ 'hh:' . $rid ] ) && ogc_lod_decided( (array) $rows[ 'hh:' . $rid ] ) ) {
		return '';
	}
	$ctx = ogc_lod_ctx( $y );
	foreach ( $chosen as $id ) {
		if ( ! isset( $ctx['rooms'][ $id ] ) ) {
			return 'Choose the rooms again · One isn’t on the map';
		}
		if ( ! ogc_lod_family_room( $ctx['rooms'][ $id ] ) ) {
			return ogc_lod_room_words( $id ) . ' · For ' . $ctx['rooms'][ $id ]['for'];
		}
		if ( ! empty( $ctx['facts'][ $id ]['out'] ) ) {
			return ogc_lod_room_words( $id ) . ' · Out of service';
		}
		if ( ! empty( $ctx['facts'][ $id ]['hold'] ) ) {
			return ogc_lod_room_words( $id ) . ' · Not open';
		}
	}
	$ctx2 = ogc_lod_ctx_with( $ctx, array( $rid => array_merge( $d, array( 'rid' => $rid ) ) ) );
	$ctx2['chosen'][ $rid ] = $chosen;
	$cl = ogc_lod_claims( $ctx2, $rows );
	foreach ( $chosen as $id ) {
		$i = ogc_lod_room_issue( $ctx2, $id, isset( $cl[ $id ] ) ? $cl[ $id ] : array( 'hh:' . $rid ), $rows, false, array( 'hh:' . $rid ) );
		if ( $i ) {
			return 'taken' === $i['code'] || 'full' === $i['code'] ? 'Taken since you chose it · Choose again' : $i['words'];
		}
	}
	return '';
}

/**
 * A child, or an under-18 Youngfolk sleeping with the family, left in a room with no grown-up on a night
 * a grown-up slept there before (rule 14: the household's own Change is held to it as Leave early is; red
 * team round 2, A4). Only for a household Lodging has given rooms, and not one from the Google Form (no one
 * there chose who sleeps where). Words ("Sam would be alone in Room 2 · Sunday"), or ''.
 */
function ogc_lod_alone_words( $y, $rec, $new ) {
	if ( ! function_exists( 'ogc_reg_nights_for' ) || ogc_lod_pooled( $rec ) ) {
		return '';
	}
	$old = (array) $rec['data'];
	$row = ogc_lod_row( $y, 'hh:' . ogc_lod_rid( $rec ) );
	$own = $row ? ogc_lod_real( isset( $row['data']['rooms'] ) ? $row['data']['rooms'] : array(), ogc_lod_rooms( $y ) ) : array();
	if ( ! $own || 'dorm' !== ( isset( $new['stay']['type'] ) ? $new['stay']['type'] : '' ) ) {
		return '';
	}
	$cfg  = ogc_reg_cfg( $y );
	$grid = function ( $d ) use ( $cfg ) {
		$n  = max( 1, (int) ( isset( $d['stay']['rooms'] ) ? $d['stay']['rooms'] : 1 ) );
		$at = array();
		foreach ( (array) ( isset( $d['people'] ) ? $d['people'] : array() ) as $p ) {
			if ( empty( $p['name'] ) || ( ! empty( $p['yf'] ) && ogc_lod_in_hall( $p, $d ) ) ) {
				continue;
			}
			$r   = ogc_lod_slot( $p, $n );
			$kid = 'child' === ( isset( $p['kind'] ) ? $p['kind'] : '' ) || ( ! empty( $p['yf'] ) && ! empty( $p['minor'] ) );
			foreach ( (array) ogc_reg_nights_for( $p, $d, $cfg ) as $night ) {
				if ( 'adult' === ( isset( $p['kind'] ) ? $p['kind'] : '' ) ) {
					$at[ $r ][ $night ]['grown'] = true;
				} elseif ( $kid ) {
					$at[ $r ][ $night ]['kids'][] = ogc_lod_first( $p['name'] );
				}
			}
		}
		return $at;
	};
	$was = $grid( $old );
	foreach ( $grid( $new ) as $r => $ns ) {
		foreach ( $ns as $night => $x ) {
			if ( empty( $x['kids'] ) || ! empty( $x['grown'] ) ) {
				continue;
			}
			// Alone where a grown-up was, or on a night with no grown-up that they weren't alone on before (red
			// team round 3, X2-A5: a 6-year-old given Early Thursday, a night no grown-up of his had). A child
			// already alone on a night, as the registration was placed, isn't made so by this change.
			$before  = isset( $was[ $r ][ $night ] ) ? $was[ $r ][ $night ] : array();
			$already = empty( $before['grown'] ) && ! empty( $before['kids'] ) ? $before['kids'] : array();
			$newly   = array_values( array_diff( array_unique( $x['kids'] ), $already ) );
			if ( $newly || ! empty( $before['grown'] ) ) {
				return implode( ' and ', $newly ? $newly : array_unique( $x['kids'] ) ) . ' would be alone in Room ' . ( $r + 1 ) . ' · ' . $night;
			}
		}
	}
	return '';
}

/** A Youngfolk whose hall key is out, whom a change would take out of the hall room (off the
 * registration, with the family, the other hall, a parent's approval now needed): words, or ''. */
function ogc_lod_key_out_moved( $y, $rec, $new ) {
	$now = array();
	foreach ( (array) ( isset( $new['people'] ) ? $new['people'] : array() ) as $p ) {
		if ( ! empty( $p['pid'] ) ) {
			$now[ (string) $p['pid'] ] = $p;
		}
	}
	$after = array_merge( $rec, array( 'data' => $new ) );
	foreach ( (array) ( isset( $rec['data']['people'] ) ? $rec['data']['people'] : array() ) as $p ) {
		$yr = ! empty( $p['yf'] ) && ! empty( $p['pid'] ) ? ogc_lod_row( $y, 'yf:' . $p['pid'] ) : null;
		if ( ! $yr || ! ogc_lod_key_out( (array) $yr['data'] ) ) {
			continue;
		}
		$q     = isset( $now[ (string) $p['pid'] ] ) ? $now[ (string) $p['pid'] ] : null;
		$rooms = ogc_lod_rooms( $y );
		$id    = (string) $yr['data']['room'];
		if ( ! $q || empty( $q['yf'] ) || '' !== ogc_lod_yf_why_not( $q, $after, ogc_lod_marks( $y ) ) || ( isset( $rooms[ $id ] ) && ogc_lod_yf_hall_of( $rooms[ $id ] ) !== ( isset( $q['yfHall'] ) ? (string) $q['yfHall'] : '' ) ) ) {
			return 'Key out · ' . ogc_lod_first( $p['name'] );
		}
	}
	return '';
}

/** A night already slept, as the one changing it is told: the desk undoes its own record first (keys
 * back, or the check-in); a household asks at the Lodging desk. */
function ogc_lod_slept_say( $y, $rec, $w, $enters ) {
	if ( ! $enters ) {
		return $w . ' · Ask at the Lodging desk';
	}
	$row = ogc_lod_row( $y, 'hh:' . ogc_lod_rid( $rec ) );
	return $w . ' · ' . ( $row && ogc_lod_all_back( $y, (array) $row['data'] ) ? 'Undo keys back first' : 'Undo check-in first' );
}

/**
 * A household's own change that would take away a parent's no: the registration's approval was declined,
 * and the change no longer asks a parent at all (a grown-up added who says they're the parent) while
 * someone the parent declined still sleeps in a Youngfolks hall (red team round 3, ATK3 A2: the parent's
 * no was gone without a trace, and Lodging gave her the hall room). The COA, who may know the parent,
 * may make the change. Words, or ''.
 */
function ogc_lod_decline_words( $rec, $new ) {
	$old = (array) $rec['data'];
	if ( 'declined' !== ( isset( $old['approval']['state'] ) ? $old['approval']['state'] : '' ) || ! function_exists( 'ogc_reg_needs_approval' ) || ! is_array( $new ) ) {
		return '';
	}
	if ( ogc_reg_needs_approval( $new ) ) {
		return '';   // asked again: the parent answers
	}
	$was = array();
	foreach ( ogc_reg_approval_people( $old ) as $p ) {
		if ( ! empty( $p['pid'] ) ) {
			$was[ (string) $p['pid'] ] = true;
		}
	}
	foreach ( (array) ( isset( $new['people'] ) ? $new['people'] : array() ) as $q ) {
		if ( is_array( $q ) && ! empty( $q['pid'] ) && isset( $was[ (string) $q['pid'] ] ) && ! empty( $q['minor'] ) && ogc_lod_in_hall( $q, $new ) ) {
			return ogc_lod_first( isset( $q['name'] ) ? $q['name'] : '' ) . ' · Parent declined · Ask the COA';
		}
	}
	return '';
}

/** A refusal at one of the register's doors. */
function ogc_lod_door_err( $code, $msg, $status, $field = '' ) {
	$data = array( 'status' => $status );
	if ( '' !== $field ) {
		$data['errors'] = array( $field => $msg );
	}
	return new WP_Error( $code, $msg, $data );
}

/**
 * The register's doors and the committee's (see ogc_lod_door): both locks for the whole request
 * (ogc_lod_guard_both), then, as the registration and Lodging's rows are now, under them:
 *  · a household the desk checked in, or with a Youngfolk's hall key out, isn't cancelled or moved out of
 *    its rooms (invariant 57; red team round 2: the check was read before any lock);
 *  · rooms chosen on the map are judged as Place judges them, and only where households choose;
 *  · a placed household's own Change never leaves a child alone in a room (rule 14);
 *  · what the person couldn't see is kept as it was (Lodging's version, rooms withheld);
 *  · each person's id stays theirs alone (ogc_lod_own_pids).
 * registration.csv (early nights, the Conference's nights, room_beds) and the year's own row (the
 * campus's name, which the beds carried from the last Conference there follow) are judged too.
 */
add_filter( 'rest_request_before_callbacks', function ( $resp, $handler, $req ) {
	if ( is_wp_error( $resp ) ) {
		return $resp;
	}
	$door = ogc_lod_door( $req );
	if ( ! $door ) {
		return $resp;
	}
	list( $kind, $y, $rec ) = $door;
	// Only for someone the route itself would let through (the route says no to anyone else).
	if ( in_array( $kind, array( 'change', 'cancel', 'leave', 'approval' ), true ) && ( ! function_exists( 'ogc_reg_may' ) || ! ogc_reg_may( $rec ) ) ) {
		return $resp;
	}
	if ( in_array( $kind, array( 'hh-cancel', 'hh-offer' ), true ) && ( '' !== (string) $req->get_param( 'as' ) || ! function_exists( 'ogc_access' ) || ! ogc_access( $y, 'households' ) ) ) {
		return $resp;
	}
	if ( in_array( $kind, array( 'record', 'regfile', 'year', 'dates' ), true ) && ( ! ogc_is_member( $y ) || null === ogc_year_get( $y ) ) ) {
		return $resp;
	}
	$in = $req->get_param( 'data' );
	if ( 'new' === $kind ) {
		// A new registration matters to rooms only where households choose them on the map.
		$cfg = ogc_lod_kv( $y, 'registration' );
		if ( ! is_array( $in ) || ! ogc_valid_year( $y ) ) {
			return $resp;
		}
		if ( 'households' !== ( isset( $cfg['room_choice'] ) ? $cfg['room_choice'] : '' ) ) {
			if ( isset( $in['stay'] ) && is_array( $in['stay'] ) && ! empty( $in['stay']['chosen'] ) ) {
				$in['stay']['chosen'] = array();
				$req->set_param( 'data', $in );
			}
		} elseif ( empty( $in['stay']['chosen'] ) ) {
			$in = null;
		}
		if ( is_array( $in ) && ! empty( $in['people'] ) && is_array( $in['people'] ) ) {
			$fixed = ogc_lod_own_pids( $y, $in['people'], 0 );
			if ( $fixed !== $in['people'] ) {
				$in['people'] = $fixed;
				$req->set_param( 'data', $in );
			}
		}
		if ( ! is_array( $in ) || empty( $in['stay']['chosen'] ) ) {
			return $resp;
		}
	}
	$yr_end = null;
	if ( 'year' === $kind ) {
		// A change to the campus's name (the beds carried from the last Conference there follow it), or to
		// the Conference's dates (the day names are cleared follows its last day).
		$f     = $req->get_param( 'fields' );
		$get   = function ( $k ) use ( $f, $req ) {
			return is_array( $f ) && array_key_exists( $k, $f ) ? ( null === $f[ $k ] ? '' : (string) $f[ $k ] ) : ( null !== $req->get_param( $k ) ? (string) $req->get_param( $k ) : null );
		};
		$row   = ogc_year_get( $y );
		$venue = $get( 'venue' );
		if ( null !== $venue && $row && isset( $row['venue'] ) && (string) $row['venue'] === $venue ) {
			$venue = null;
		}
		$end = $get( 'end' );
		if ( null !== $end || null !== $get( 'start' ) ) {
			$yr_end = null !== $end ? sanitize_text_field( $end ) : ( $row && ! empty( $row['end'] ) ? (string) $row['end'] : '' );
			if ( $row && (string) ( isset( $row['end'] ) ? $row['end'] : '' ) === $yr_end ) {
				$yr_end = null;
			}
		}
		if ( null === $venue && null === $yr_end ) {
			return $resp;
		}
	}
	if ( 'dates' === $kind ) {
		$yr_end = ogc_lod_dates_end( $y, $req );
		if ( null === $yr_end ) {
			return $resp;
		}
	}
	if ( 'regfile' === $kind && null === ogc_lod_regfile_after( $req, $y ) ) {
		return $resp;
	}
	if ( ! ogc_lod_guard_both( $req, $y ) ) {
		return ogc_lod_busy();
	}
	$no = function ( $e ) use ( $req ) {
		ogc_lod_guard_unlock( $req );
		return $e;
	};
	if ( $rec ) {
		$rec = ogc_record_get( (int) $rec['id'] );
		if ( ! $rec ) {
			return $no( new WP_Error( 'ogc_not_found', 'Not found.', array( 'status' => 404 ) ) );
		}
	}
	$enters = function_exists( 'ogc_reg_enters' ) && ogc_reg_enters( $y );
	$out    = function ( $w ) use ( $enters ) {
		return 'Checked in' === $w ? ( $enters ? 'Checked in · Undo check-in first' : 'Checked in · Ask at the Lodging desk' ) : ( $enters ? $w . ' · Undo key out first' : $w . ' · Ask at the Lodging desk' );
	};
	switch ( $kind ) {
		case 'cancel':
		case 'hh-cancel':
			if ( 'hh-cancel' === $kind && '' !== (string) $req->get_param( 'undo' ) ) {
				break;
			}
			$w = ogc_lod_keys_out_words( $y, $rec );
			if ( '' !== $w && 'cancelled' !== ( isset( $rec['data']['status'] ) ? $rec['data']['status'] : '' ) ) {
				return $no( new WP_Error( 'ogc_checked_in', $out( $w ), array( 'status' => 409 ) ) );
			}
			// From the Conference's first day a registration isn't cancelled: Didn't come (from its own first
			// night) or Leave early, as the committee's Cancel says (red team round 3, X2-E1: the register's
			// Cancel, by the COA, freed a room on Saturday that was due Sunday, and it went to a walk-in). The
			// household's own Cancel already closes then.
			$yrow = ogc_year_get( $y );
			$from = $yrow && ! empty( $yrow['start'] ) ? (string) $yrow['start'] : '';
			if ( 'cancel' === $kind && '' !== $from && ogc_lod_today( $y, $req ) >= $from && 'cancelled' !== ( isset( $rec['data']['status'] ) ? $rec['data']['status'] : '' ) ) {
				return $no( new WP_Error( 'ogc_not_now', 'From ' . ogc_lod_md( $from ) . ' · Didn’t come or Leave early', array( 'status' => 409 ) ) );
			}
			break;
		case 'change':
		case 'record':
			if ( ! is_array( $in ) ) {
				break;
			}
			$in = ogc_lod_keep_withheld( $rec, $in );
			$in = ogc_lod_keep_chosen( $y, $rec['data'], $in );
			if ( ! empty( $in['people'] ) && is_array( $in['people'] ) ) {
				$in['people'] = ogc_lod_own_pids( $y, $in['people'], (int) $rec['id'] );
			}
			$req->set_param( 'data', $in );
			if ( 'record' === $kind ) {
				// The version it was read at (red team round 2, ATK1-r2-records-stale-overwrite: a screen
				// opened before the household's change saved over it). Judged in ogc_record_validate.
				break;
			}
			$clean = function_exists( 'ogc_reg_clean' ) ? ogc_reg_clean( $in, $y ) : $in;
			$row   = ogc_lod_row( $y, 'hh:' . ogc_lod_rid( $rec ) );
			if ( $row && ogc_lod_checked_in( (array) $row['data'] ) && 'dorm' !== ( isset( $clean['stay']['type'] ) ? $clean['stay']['type'] : 'dorm' ) ) {
				return $no( new WP_Error( 'ogc_checked_in', $out( 'Checked in' ), array( 'status' => 409 ) ) );
			}
			$w = ogc_lod_key_out_moved( $y, $rec, $clean );
			if ( '' !== $w ) {
				return $no( new WP_Error( 'ogc_checked_in', $out( $w ), array( 'status' => 409 ) ) );
			}
			$w = ogc_lod_chosen_wrong( $y, ogc_lod_rid( $rec ), $clean );
			if ( '' !== $w ) {
				return $no( ogc_lod_door_err( 'ogc_invalid', $w, 400, 'stay.chosen' ) );
			}
			$w = ogc_lod_alone_words( $y, $rec, $clean );
			if ( '' !== $w ) {
				return $no( ogc_lod_door_err( 'ogc_alone', $w, 400 ) );
			}
			$w = ogc_lod_slept_words( $y, $rec, $clean, ogc_lod_today( $y, $req ) );
			if ( '' !== $w ) {
				return $no( new WP_Error( 'ogc_stayed', ogc_lod_slept_say( $y, $rec, $w, $enters ), array( 'status' => 409 ) ) );
			}
			if ( ! $enters ) {
				$w = ogc_lod_decline_words( $rec, $clean );
				if ( '' !== $w ) {
					return $no( new WP_Error( 'ogc_declined', $w, array( 'status' => 409 ) ) );
				}
			}
			break;
		case 'new':
			$clean = function_exists( 'ogc_reg_clean' ) ? ogc_reg_clean( $in, $y ) : $in;
			$w     = ogc_lod_chosen_wrong( $y, '', $clean );
			if ( '' !== $w ) {
				return $no( ogc_lod_door_err( 'ogc_invalid', $w, 400, 'stay.chosen' ) );
			}
			break;
		case 'regfile':
			$w = ogc_lod_regfile_wrong( $y, ogc_lod_regfile_after( $req, $y ) );
			if ( is_wp_error( $w ) ) {
				return $no( $w );
			}
			if ( '' !== $w ) {
				return $no( new WP_Error( 'ogc_conflict', $w, array( 'status' => 409 ) ) );
			}
			break;
		case 'year':
		case 'dates':
			if ( 'year' === $kind && null !== $venue ) {
				$w = ogc_lod_venue_wrong( $y, $venue );
				if ( '' !== $w ) {
					return $no( new WP_Error( 'ogc_conflict', $w, array( 'status' => 409 ) ) );
				}
			}
			if ( null !== $yr_end ) {
				$w = ogc_lod_dates_wrong( $y, $yr_end );
				if ( '' !== $w ) {
					return $no( new WP_Error( 'ogc_conflict', $w, array( 'status' => 409 ) ) );
				}
			}
			break;
	}
	return $resp;
}, 7, 3 );

/**
 * The generic records route (the COA's, or the committee handed Households): judged as the register's own
 * door is. Before the registration area cleans it, the version: a copy read before the registration last
 * changed is refused, never saved over it (red team round 2, ATK1-r2-records-stale-overwrite). After it,
 * under both locks (the guard above): a household checked in, or with a hall key out, isn't moved out.
 */
add_filter( 'ogc_record_validate', function ( $data, $kind, $year, $existing, $req ) {
	if ( 'registrations' !== $kind || ! $existing || is_wp_error( $data ) || ! is_array( $data ) ) {
		return $data;
	}
	$had = isset( $existing['data']['_v'] ) ? (int) $existing['data']['_v'] : 0;
	if ( ! array_key_exists( '_v', $data ) || (int) $data['_v'] !== $had ) {
		return new WP_Error( 'ogc_changed', 'Changed since you opened it · Reload', array( 'status' => 409 ) );
	}
	return $data;
}, 5, 5 );

add_filter( 'ogc_record_validate', function ( $data, $kind, $year, $existing, $req ) {
	if ( 'registrations' !== $kind || ! $existing || is_wp_error( $data ) || ! is_array( $data ) ) {
		return $data;
	}
	$y   = (int) $year;
	$row = ogc_lod_row( $y, 'hh:' . ogc_lod_rid( $existing ) );
	$to  = isset( $data['stay']['type'] ) ? (string) $data['stay']['type'] : 'dorm';
	if ( $row && ogc_lod_checked_in( (array) $row['data'] ) && ( 'dorm' !== $to || 'cancelled' === ( isset( $data['status'] ) ? $data['status'] : '' ) ) ) {
		return new WP_Error( 'ogc_checked_in', 'Checked in · Undo check-in first', array( 'status' => 409 ) );
	}
	$w = ogc_lod_key_out_moved( $y, $existing, $data );
	if ( '' !== $w ) {
		return new WP_Error( 'ogc_checked_in', $w . ' · Undo key out first', array( 'status' => 409 ) );
	}
	$w = ogc_lod_slept_words( $y, $existing, $data, ogc_lod_today( $y, $req instanceof WP_REST_Request ? $req : null ) );
	if ( '' !== $w ) {
		return new WP_Error( 'ogc_stayed', ogc_lod_slept_say( $y, $existing, $w, true ), array( 'status' => 409 ) );
	}
	if ( ! empty( $data['people'] ) && is_array( $data['people'] ) ) {
		$data['people'] = ogc_lod_own_pids( $y, $data['people'], (int) $existing['id'] );
	}
	$GLOBALS['ogc_lod_rec_old'][ (int) $existing['id'] ] = $existing['data'];
	return $data;
}, 20, 5 );

add_action( 'ogc_record_saved', function ( $rec, $what = '', $req = null ) {
	if ( 'update' !== $what || ! is_array( $rec ) || 'registrations' !== $rec['kind'] || ! isset( $GLOBALS['ogc_lod_rec_old'][ (int) $rec['id'] ] ) ) {
		return;
	}
	$old = $GLOBALS['ogc_lod_rec_old'][ (int) $rec['id'] ];
	unset( $GLOBALS['ogc_lod_rec_old'][ (int) $rec['id'] ] );
	ogc_lod_reg_saved( (int) $rec['year'], is_array( $old ) ? $old : array(), $rec['data'] );
}, 10, 3 );

/* ------------------------------------------------------------------ registration.csv and the year's row */

/** registration.csv as a change would leave it (PUT rows; PATCH a key; PATCH a row, appended, since the
 * file has no row key): key => value as the register reads it (trimmed keys, the last row wins), or null
 * when the change doesn't say. */
function ogc_lod_regfile_after( $req, $y ) {
	$cur  = ogc_file_get( $y, 'registration' );
	$rows = $cur ? (array) $cur['rows'] : array();
	$coa  = 'POST' === $req->get_method() && preg_match( '#/coa/\d{4}/reg$#', (string) $req->get_route() );
	if ( 'PATCH' === $req->get_method() || $coa ) {
		if ( ( $coa || 'key' === $req->get_param( 'op' ) ) && is_scalar( $req->get_param( 'key' ) ) ) {
			$k   = trim( (string) $req->get_param( 'key' ) );
			if ( $coa ) {
				// As the year page's route writes it (ogc_coa_rest_reg).
				$req->set_param( 'value', trim( sanitize_text_field( (string) $req->get_param( 'value' ) ) ) );
			}
			$hit = false;
			foreach ( $rows as &$r ) {
				if ( isset( $r['key'] ) && trim( (string) $r['key'] ) === $k ) {
					$r['value'] = (string) $req->get_param( 'value' );
					$hit        = true;
				}
			}
			unset( $r );
			if ( ! $hit ) {
				$rows[] = array( 'key' => $k, 'value' => (string) $req->get_param( 'value' ) );
			}
		} elseif ( 'row' === $req->get_param( 'op' ) && is_array( $req->get_param( 'row' ) ) ) {
			$rows[] = $req->get_param( 'row' );
		} else {
			return null;
		}
	} elseif ( is_array( $req->get_param( 'rows' ) ) ) {
		$rows = $req->get_param( 'rows' );
	} else {
		return null;
	}
	$out = array();
	foreach ( $rows as $r ) {
		if ( is_array( $r ) && isset( $r['key'] ) && '' !== trim( (string) $r['key'] ) && '#' !== substr( trim( (string) $r['key'] ), 0, 1 ) ) {
			$out[ trim( (string) $r['key'] ) ] = isset( $r['value'] ) ? (string) $r['value'] : '';
		}
	}
	return $out;
}

/**
 * What a change to registration.csv would leave wrong (red team B1, B2; round 2, B1-early-off-by-row,
 * B2-main-night-off, K3_E1): a night taken away (an early night, or one of the Conference's own) while a
 * household not cancelled has it; room_beds set lower under the people in a room whose beds come from it.
 * Words, or ''. $after: the file as it would be (ogc_lod_regfile_after).
 */
function ogc_lod_regfile_wrong( $y, $after ) {
	$now  = ogc_lod_kv( $y, 'registration' );
	$read = function ( $v ) {
		return array_values( array_filter( array_map( 'trim', explode( '|', (string) $v ) ) ) );
	};
	$val  = function ( $a, $k ) {
		return isset( $a[ $k ] ) ? trim( (string) $a[ $k ] ) : '';
	};
	// Published is Lodging's own Publish, never a file's cell (red team round 3, ATK4-r3-10: the COA blanked
	// it and every household's rooms were hidden while Lodging's board still said published). Publish
	// writes it itself (ogc_lod_rest_publish), not through these doors.
	if ( $val( $now, 'rooms_posted' ) !== $val( $after, 'rooms_posted' ) ) {
		return new WP_Error( 'ogc_coa', 'Published by Lodging only', array( 'status' => 403 ) );
	}
	// The days after the Conference that names are cleared: the webmasters', from 2 to 365 (1 would clear
	// Lodging's names on check-out morning, when most keys come back), and never a day already past while
	// Lodging still has rows to clear (red team round 3, ATK4-r3-07 to -09, -12: set round the side, or as
	// 0, -60, -60000, every placement was wiped when the board was next opened).
	$c0 = $val( $now, 'clear_after_days' );
	$c1 = $val( $after, 'clear_after_days' );
	if ( $c0 !== $c1 ) {
		if ( ! ogc_is_webmaster() ) {
			return new WP_Error( 'ogc_coa', 'Set by the webmasters', array( 'status' => 403 ) );
		}
		if ( '' !== $c1 && ( ! preg_match( '/^\d{1,3}$/', $c1 ) || (int) $c1 < 2 || (int) $c1 > 365 ) ) {
			return new WP_Error( 'ogc_invalid', 'Days after · 2 to 365', array( 'status' => 400 ) );
		}
		$row   = ogc_year_get( $y );
		$clear = $row && ! empty( $row['end'] ) ? ogc_lod_add_days( $row['end'], ogc_lod_clear_days( array( 'clear_after_days' => $c1 ) ) ) : '';
		if ( '' !== $clear && ogc_lod_today( $y, null, true ) >= $clear && ogc_lod_to_clear( $y ) ) {
			return 'Names cleared ' . ogc_lod_md( $clear ) . ' · Already past · Lodging’s rooms would go';
		}
	}
	// The youngest age for Youngfolks raised over someone in a hall room (red team round 3, ATK3 A4b: the
	// change was taken and the board said nothing).
	$m0 = ogc_lod_yf_min( $now );
	$m1 = ogc_lod_yf_min( $after );
	if ( $m1 > $m0 ) {
		$ctx = ogc_lod_ctx( $y );
		$yfp = ogc_lod_yf_people( $ctx );
		$n   = 0;
		foreach ( ogc_lod_claims( $ctx, ogc_lod_claim_data( $y ) ) as $room => $keys ) {
			foreach ( $keys as $k ) {
				$pid = 0 === strpos( $k, 'yf:' ) ? substr( $k, 3 ) : '';
				$age = '' !== $pid && isset( $yfp[ $pid ]['p']['age'] ) ? trim( (string) $yfp[ $pid ]['p']['age'] ) : '';
				$n  += is_numeric( $age ) && (int) $age < $m1 ? 1 : 0;
			}
		}
		if ( $n ) {
			return 'Under ' . $m1 . ' · ' . $n . ( 1 === $n ? ' Youngfolk in a hall room' : ' Youngfolks in hall rooms' ) . ' · Move them first';
		}
	}
	$gone = array();
	foreach ( array_diff( $read( isset( $now['early_nights'] ) ? $now['early_nights'] : '' ), $read( isset( $after['early_nights'] ) ? $after['early_nights'] : '' ) ) as $day ) {
		$gone[] = 'Early ' . $day;
	}
	if ( isset( $now['nights'] ) || isset( $after['nights'] ) ) {
		$was = $read( isset( $now['nights'] ) ? $now['nights'] : '' );
		$is  = $read( isset( $after['nights'] ) ? $after['nights'] : '' );
		if ( $was && $is ) {
			$gone = array_merge( $gone, array_diff( $was, $is ) );
		}
	}
	foreach ( $gone as $night ) {
		$n = 0;
		foreach ( ogc_lod_households( $y ) as $rec ) {
			$d = $rec['data'];
			if ( 'cancelled' === ( isset( $d['status'] ) ? $d['status'] : '' ) ) {
				continue;
			}
			$has = in_array( $night, (array) ( isset( $d['stay']['nights'] ) ? $d['stay']['nights'] : array() ), true );
			foreach ( (array) ( isset( $d['people'] ) ? $d['people'] : array() ) as $p ) {
				$has = $has || in_array( $night, (array) ( isset( $p['nights'] ) ? $p['nights'] : array() ), true );
			}
			$n += $has ? 1 : 0;
		}
		if ( $n ) {
			return $night . ' · ' . $n . ( 1 === $n ? ' household' : ' households' ) . ' · Change them first';
		}
	}
	$rb0 = isset( $now['room_beds'] ) ? trim( (string) $now['room_beds'] ) : '';
	$rb1 = isset( $after['room_beds'] ) ? trim( (string) $after['room_beds'] ) : '';
	if ( $rb0 !== $rb1 ) {
		if ( '' !== $rb1 && ( ! preg_match( '/^\d+$/', $rb1 ) || (int) $rb1 < 1 || (int) $rb1 > 8 ) ) {
			return 'Beds a room · 1 to 8';
		}
		$GLOBALS['ogc_lod_try_room_beds'][ (int) $y ] = '' === $rb1 ? 2 : (int) $rb1;
		try {
			$w = ogc_lod_beds_change_wrong( $y );
		} finally {
			unset( $GLOBALS['ogc_lod_try_room_beds'][ (int) $y ] );
		}
		if ( '' !== $w ) {
			return $w;
		}
	}
	return '';
}

/** A change that sets some rooms' beds another way (room_beds, the campus carried from): every room
 * someone holds, judged with the beds as they'd be ($GLOBALS['ogc_lod_try_room_beds'], $facts2) against
 * now. Words, or ''. */
function ogc_lod_beds_change_wrong( $y, $facts2 = null ) {
	$ctx  = ogc_lod_ctx( $y );
	$rows = ogc_lod_claim_data( $y );
	$try  = isset( $GLOBALS['ogc_lod_try_room_beds'][ (int) $y ] ) ? $GLOBALS['ogc_lod_try_room_beds'][ (int) $y ] : null;
	$see  = function_exists( 'ogc_access' ) ? ogc_access( $y, 'rooms' ) : false;
	foreach ( ogc_lod_claims( $ctx, $rows ) as $room => $keys ) {
		unset( $GLOBALS['ogc_lod_try_room_beds'][ (int) $y ] );
		$i1 = ogc_lod_room_issue( $ctx, $room, $keys, $rows );
		if ( null !== $try ) {
			$GLOBALS['ogc_lod_try_room_beds'][ (int) $y ] = $try;
		}
		$ctx2 = $ctx;
		if ( null !== $facts2 ) {
			$ctx2['facts'] = $facts2;
		}
		$i2 = ogc_lod_room_issue( $ctx2, $room, $keys, $rows );
		if ( ! $i2 || ( $i1 && $i1['code'] === $i2['code'] && $i1['words'] === $i2['words'] ) ) {
			continue;
		}
		$k   = $keys[0];
		$who = $see && 0 === strpos( $k, 'hh:' ) && isset( $ctx['hh'][ substr( $k, 3 ) ] ) ? ogc_lod_label( $ctx['hh'][ substr( $k, 3 ) ]['data'] ) : ( 0 === strpos( $k, 'yf:' ) ? 'Youngfolks' : 'A household' );
		$b   = ogc_lod_beds( $y, $room, $ctx2['rooms'], $ctx2['facts'] );
		$why = array( 'over' => 'Sleeps ' . ( $b + 1 ), 'full' => 'Takes ' . min( 3, $b + 1 ) );
		return ogc_lod_room_words( $room ) . ' is given · ' . $who . ' · ' . ( isset( $why[ $i2['code'] ] ) ? $why[ $i2['code'] ] : $i2['words'] );
	}
	return '';
}

/** The last day a change to the Conference's dates (POST coa/{y}/dates, applied) would set, worked out as
 * the route does (ogc_coa_rest_dates: no end given keeps the Conference's length), or null when it sets
 * none or changes nothing. */
function ogc_lod_dates_end( $y, $req ) {
	if ( ! $req->get_param( 'apply' ) ) {
		return null;
	}
	$start = (string) $req->get_param( 'start' );
	$end   = (string) $req->get_param( 'end' );
	$row   = ogc_year_get( $y );
	$iso   = function ( $v ) {
		return (bool) preg_match( '/^\d{4}-\d\d-\d\d$/', (string) $v );
	};
	if ( ! $row || ! $iso( $start ) ) {
		return null;   // the route refuses
	}
	$was = ! empty( $row['start'] ) ? (string) $row['start'] : '';
	$gap = function ( $a, $b ) {
		$da = DateTime::createFromFormat( '!Y-m-d', $a, new DateTimeZone( 'UTC' ) );
		$db = DateTime::createFromFormat( '!Y-m-d', $b, new DateTimeZone( 'UTC' ) );
		return $da && $db ? (int) round( ( $db->getTimestamp() - $da->getTimestamp() ) / DAY_IN_SECONDS ) : 0;
	};
	if ( ! $iso( $end ) ) {
		$prev = function_exists( 'ogc_coa_prev_year' ) ? ogc_coa_prev_year( $y ) : null;
		$len  = $was && ! empty( $row['end'] ) ? $gap( $was, $row['end'] ) : ( $prev && ! empty( $prev['start'] ) && ! empty( $prev['end'] ) ? $gap( $prev['start'], $prev['end'] ) : 4 );
		$end  = ogc_lod_add_days( $start, $len );
	} elseif ( $end < $start ) {
		return null;   // the route refuses
	} elseif ( $was && ! empty( $row['end'] ) && $gap( $was, $start ) && $end === $row['end'] ) {
		$end = ogc_lod_add_days( $row['end'], $gap( $was, $start ) );
	}
	return isset( $row['end'] ) && (string) $row['end'] === $end ? null : $end;
}

/** The Conference moved to end on $end: refused when the day names are cleared would then be past while
 * Lodging still has rows to clear (red team round 3, ATK4-r3-11: this year typed for the year's own, and
 * every placement was cleared for good when the board was next opened). Words, or ''. */
function ogc_lod_dates_wrong( $y, $end ) {
	if ( ! preg_match( '/^\d{4}-\d\d-\d\d$/', (string) $end ) ) {
		return '';
	}
	$clear = ogc_lod_add_days( $end, ogc_lod_clear_days( ogc_lod_kv( $y, 'registration' ) ) );
	if ( ogc_lod_today( $y, null, true ) >= $clear && ogc_lod_to_clear( $y ) ) {
		return 'Ends ' . ogc_lod_md( $end ) . ', ' . substr( $end, 0, 4 ) . ' · Lodging’s rooms would be cleared';
	}
	return '';
}

/** Renaming the year's campus: the beds carried from the last Conference there follow its name (red team
 * round 2, K3_E2). Refused while a room someone holds would then hold more than its beds. Words, or ''. */
function ogc_lod_venue_wrong( $y, $venue ) {
	$carry = ogc_lod_carry( $y, $venue );
	$facts = array();
	foreach ( $carry ? (array) $carry['rooms'] : array() as $id => $f ) {
		$facts[ $id ] = (array) $f;
	}
	foreach ( ogc_lod_rows( $y, 'room:' ) as $k => $r ) {
		$id           = substr( $k, 5 );
		$facts[ $id ] = array_merge( isset( $facts[ $id ] ) ? $facts[ $id ] : array(), (array) $r['data'] );
	}
	return ogc_lod_beds_change_wrong( $y, $facts );
}

/* ------------------------------------------------------------------ what each one is sent */

/** Lodging's version of a registration's data (ogc_lod_lodging_version): no email, no helper's email or
 * phone, no parent's address, nobody's managing address, History's money lines in plain words. */
function ogc_lod_cut_lodging( $d ) {
	if ( ! is_array( $d ) ) {
		return $d;
	}
	foreach ( array( array( 'household', 'email' ), array( 'helper', 'email' ), array( 'helper', 'phone' ), array( 'stay', 'parentEmail' ), array( 'approval', 'to' ) ) as $f ) {
		if ( isset( $d[ $f[0] ] ) && is_array( $d[ $f[0] ] ) && isset( $d[ $f[0] ][ $f[1] ] ) ) {
			$d[ $f[0] ][ $f[1] ] = '';
		}
	}
	if ( isset( $d['managers'] ) ) {
		$d['managers'] = array();
	}
	if ( isset( $d['history'] ) && is_array( $d['history'] ) && function_exists( 'ogc_rec_hist_plain' ) ) {
		foreach ( $d['history'] as $i => $h ) {
			if ( is_array( $h ) && isset( $h['what'] ) ) {
				$d['history'][ $i ]['what'] = ogc_rec_hist_plain( $h['what'] );
			}
		}
	}
	$d['withheld'] = array( 'household.email', 'helper.email', 'helper.phone', 'stay.parentEmail' );
	return $d;
}

/** Rooms chosen on the map, left out of everything (data shaped like registrations) for someone who may
 * not see rooms (red team round 2, R2A4-13). */
function ogc_lod_cut_chosen( $v ) {
	if ( ! is_array( $v ) ) {
		return $v;
	}
	foreach ( $v as $k => $x ) {
		if ( 'stay' === $k && is_array( $x ) && array_key_exists( 'chosen', $x ) ) {
			$v[ $k ]['chosen'] = array();
		} elseif ( is_array( $x ) ) {
			$v[ $k ] = ogc_lod_cut_chosen( $x );
		}
	}
	return $v;
}

/**
 * What the register's routes and the records routes send, cut to what the person may see: Lodging's
 * version of a registration (red team round 2, R2A4-08), rooms chosen on the map only to those who see
 * rooms (R2A4-13); and the guide's "My room" (the map's me/stay), only the rooms the household is shown
 * on Your sign-ups (ogc_reg_rooms_of → ogc_lod_seen_rooms: never a room it holds no longer, never while
 * cancelled or on the waiting list, never a choice Lodging replaced: R2A4-01 to -05, -12, -18).
 */
add_filter( 'rest_request_after_callbacks', function ( $resp, $handler, $req ) {
	if ( ! ( $resp instanceof WP_REST_Response ) && ! is_wp_error( $resp ) && ! is_array( $resp ) ) {
		return $resp;
	}
	$ns    = preg_quote( OGC_NS, '#' );
	$route = (string) $req->get_route();
	if ( 'GET' === $req->get_method() && preg_match( '#^/' . $ns . '/years/(\d{4})/me/stay$#', $route, $m ) && $resp instanceof WP_REST_Response ) {
		$resp->set_data( ogc_lod_my_stay( (int) $m[1], $resp->get_data() ) );
		return $resp;
	}
	if ( preg_match( '#^/' . $ns . '/reg/r/(\d+)(/[a-z]+)?$#', $route, $m ) ) {
		$rec = ogc_record_get( (int) $m[1] );
		if ( ! $rec || 'registrations' !== $rec['kind'] ) {
			return $resp;
		}
		$fix = function ( $item ) use ( $rec ) {
			if ( ! is_array( $item ) || ! isset( $item['data'] ) ) {
				return $item;
			}
			if ( ogc_lod_lodging_version( $rec ) ) {
				$item['data'] = ogc_lod_cut_lodging( $item['data'] );
			}
			if ( ! ogc_lod_sees_rooms( $rec ) ) {
				$item['data'] = ogc_lod_cut_chosen( $item['data'] );
			}
			return $item;
		};
		if ( is_wp_error( $resp ) ) {
			$e = $resp->get_error_data();
			if ( is_array( $e ) && isset( $e['item'] ) ) {
				$e['item'] = $fix( $e['item'] );
				$resp->add_data( $e );
			}
			return $resp;
		}
		$data = $resp instanceof WP_REST_Response ? $resp->get_data() : $resp;
		if ( is_array( $data ) && isset( $data['item'] ) ) {
			$data['item'] = $fix( $data['item'] );
			if ( $resp instanceof WP_REST_Response ) {
				$resp->set_data( $data );
			} else {
				$resp = $data;
			}
		}
		return $resp;
	}
	if ( 'GET' === $req->get_method() && ( preg_match( '#^/' . $ns . '/years/(\d{4})/records(/registrations)?$#', $route, $m ) || preg_match( '#^/' . $ns . '/records/(\d+)$#', $route, $m2 ) ) ) {
		$y = isset( $m[1] ) ? (int) $m[1] : 0;
		if ( ! $y && isset( $m2[1] ) ) {
			$r = ogc_record_get( (int) $m2[1] );
			if ( ! $r || 'registrations' !== $r['kind'] || ogc_lod_sees_rooms( $r ) ) {
				return $resp;
			}
			$y = (int) $r['year'];
		}
		if ( $y && function_exists( 'ogc_access' ) && ! ogc_access( $y, 'rooms' ) && $resp instanceof WP_REST_Response ) {
			$resp->set_data( ogc_lod_cut_chosen( json_decode( wp_json_encode( $resp->get_data() ), true ) ) );
		}
	}
	return $resp;
}, 50, 3 );

/** The guide's "My room" (the map's me/stay answer), with the rooms the household is shown on Your
 * sign-ups: family rooms only, the hall's key-only doors only for a room it is shown. */
function ogc_lod_my_stay( $y, $out ) {
	if ( ! is_array( $out ) || 'dorm' !== ( isset( $out['type'] ) ? $out['type'] : '' ) || ! function_exists( 'ogc_reg_rooms_of' ) ) {
		return $out;
	}
	$email = ogc_current_email();
	$ids   = array();
	foreach ( '' !== $email ? ogc_records( $y, 'registrations', $email ) : array() as $rec ) {
		if ( 'dorm' === ( isset( $rec['data']['stay']['type'] ) ? $rec['data']['stay']['type'] : '' ) ) {
			$ids = ogc_reg_rooms_of( $rec );
		}
	}
	$rooms = ogc_lod_rooms( $y );
	$map   = function_exists( 'ogc_map_rooms' ) ? ogc_map_rooms( $y ) : array();
	$list  = array();
	foreach ( $ids as $id ) {
		if ( isset( $rooms[ (string) $id ], $map[ (string) $id ] ) && ogc_lod_family_room( $rooms[ (string) $id ] ) ) {
			$list[] = $map[ (string) $id ];
		}
	}
	$posted       = ! empty( $out['posted'] );
	$out['rooms'] = $posted ? $list : array();
	$out['doors'] = $posted && $list && function_exists( 'ogc_map_key_doors' ) ? ogc_map_key_doors( $y, array( $list[0]['hall'] ) ) : array();
	return $out;
}
