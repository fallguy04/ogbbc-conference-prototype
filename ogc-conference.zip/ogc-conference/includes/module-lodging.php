<?php
/**
 * Lodging (lodging area, Oct 10): the rooms board behind /annual-conference/lodging/.
 *
 * Households come from the registrations (records, kind "registrations"; register area). What Lodging
 * adds is kept here, in its own table, one row per thing, each with a version, so two members working at
 * once never overwrite each other (a stale change gets 409 and the row as it is now):
 *
 *   hh:<rid>      a household's rooms and Lodging's marks: rooms, older, ok (Looks right), near (a
 *                 household Lodging linked), note, keys (who gets a room's keys, when Lodging changes
 *                 it), snap (the registration as it was when its rooms were given, to see changes),
 *                 checkin, back (keys back per room), setup (linens and mattresses per room)
 *   yf:<pid>      a Youngfolk's room in their hall and who Lodging paired them with (mate)
 *   room:<id>     a room's own facts: hold (kept for whom), out (out of service), access, beds
 *   meta:*        published (the snapshot households see), mapping (the Form import's columns),
 *                 steps (What to do, ticked by hand), seen:<user> (for "Since Tuesday"), numbers
 *                 (the year in counts, kept after names are cleared)
 *   note:<id>     Notes for next year
 *   undo:<n>      the last changes, with what each row was before (Undo, ⌘Z, after a reload too)
 *   imp:<n>       an import's before-values (Undo import)
 *
 * What households see is the published snapshot only: the state value "rooms" ({rid: [room ids]}),
 * which register's Your sign-ups and the map's me/stay already read, and registration.csv's
 * rooms_posted. Moves after that wait for Send update.
 *
 * The routes are in module-lodging-rest.php, the Google Form import in module-lodging-import.php.
 */

defined( 'ABSPATH' ) || exit;

/* ================================================================== the table */

add_filter( 'ogc_schema', function ( $sql, $charset ) {
	$sql[] = 'CREATE TABLE ' . ogc_table( 'lodging' ) . " (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  year smallint(5) unsigned NOT NULL,
  rkey varchar(96) NOT NULL,
  data longtext NOT NULL,
  version int(10) unsigned NOT NULL DEFAULT 1,
  updated_by bigint(20) unsigned NOT NULL DEFAULT 0,
  updated_at datetime NULL,
  PRIMARY KEY  (id),
  UNIQUE KEY year_rkey (year,rkey)
) $charset;";
	return $sql;
}, 30, 2 );

// The table is new: make sure it exists on a site already installed (dbDelta runs when the SQL changes).
add_action( 'init', function () {
	if ( get_option( 'ogc_lodging_table' ) !== '1' && function_exists( 'ogc_install_schema' ) ) {
		ogc_install_schema( true );
		update_option( 'ogc_lodging_table', '1', false );
	}
}, 5 );

/* ================================================================== the page */

add_filter( 'ogc_pages', function ( $p ) {
	if ( isset( $p['lodging'] ) ) {
		$p['lodging']['template'] = 'lodging-board.php';
		$p['lodging']['scripts']  = array_values( array_diff( $p['lodging']['scripts'], array( 'lodging/lodging.js' ) ) );
		foreach ( array( 'lodging/lodging.js', 'lodging/lodging-plan.js', 'lodging/lodging-board.js', 'lodging/lodging-lists.js', 'lodging/lodging-import.js' ) as $s ) {
			$p['lodging']['scripts'][] = $s;
		}
		$p['lodging']['html_class']  = trim( $p['lodging']['html_class'] . ' adm-full' );
		$p['lodging']['description'] = 'Rooms, Youngfolks halls, the camper lot and check-in for the year\'s Lodging.';
	}
	return $p;
}, 20 );

// The board reads this year's registrations only (members get every one of the year).
add_filter( 'ogc_client_config', function ( $cfg, $key ) {
	if ( 'lodging' === $key ) {
		$cfg['recordKinds'] = array( 'registrations' );
		$cfg['recordYears'] = 1;
	}
	return $cfg;
}, 10, 2 );

/*
 * A household sees its own rooms (polish 1: "Rooms posted" with no room on Your sign-ups). rooms.csv
 * and plans.csv are withheld from the public (module-public.php: where people sleep is Lodging's), so
 * Your sign-ups, which draws the rooms from them, found nothing. Someone signed in whose own household
 * has published rooms gets back only the rows of the hall floors their rooms are on; the floor plans go
 * through the map's own rules first (a sample plan stays withheld), then the same cut. Nobody else's
 * rooms, names or halls are in it.
 */
add_filter( 'ogc_file_rows_out', function ( $rows, $year, $name, $member ) {
	if ( $member || ( 'rooms' !== $name && 'plans' !== $name ) || $rows ) {
		return $rows;
	}
	$floors = ogc_lod_my_floors( (int) $year );
	if ( ! $floors ) {
		return $rows;
	}
	$f = ogc_file_get( (int) $year, $name );
	if ( 'plans' === $name ) {
		$f = apply_filters( 'ogc_file_out', $f, (int) $year, 'plans' );
	}
	$out = array();
	foreach ( $f ? (array) $f['rows'] : array() as $r ) {
		$h  = isset( $r['hall'] ) ? (string) $r['hall'] : '';
		$fl = isset( $r['floor'] ) && '' !== (string) $r['floor'] ? (int) $r['floor'] : 0;
		if ( isset( $floors[ $h ] ) && ( ! $fl || isset( $floors[ $h ][ $fl ] ) ) ) {
			$out[] = $r;
		}
	}
	if ( $out ) {
		$GLOBALS['ogc_lod_private'] = true;
	}
	return $out;
}, 20, 4 );

// That answer is this person's alone: never kept by a browser cache or the guide's offline copy.
add_filter( 'rest_post_dispatch', function ( $res ) {
	if ( ! empty( $GLOBALS['ogc_lod_private'] ) && $res instanceof WP_REST_Response ) {
		$h = $res->get_headers();
		unset( $h['X-OGC-Public'], $h['ETag'] );
		$h['Cache-Control'] = 'private, no-store, max-age=0';
		$res->set_headers( $h );
	}
	return $res;
}, 40 );

/** The hall floors of the signed-in person's own published rooms: hall => [ floor => true ]. */
function ogc_lod_my_floors( $year ) {
	$email = ogc_current_email();
	if ( '' === $email ) {
		return array();
	}
	$cfg = ogc_lod_kv( $year, 'registration' );
	if ( empty( $cfg['rooms_posted'] ) ) {
		return array();
	}
	$st    = ogc_state_get( $year, 'rooms' );
	$snap  = $st && is_array( $st['value'] ) ? $st['value'] : array();
	$rooms = ogc_lod_rooms( $year );
	$out   = array();
	foreach ( ogc_records( $year, 'registrations', $email ) as $rec ) {
		$rid = isset( $rec['data']['rid'] ) ? (string) $rec['data']['rid'] : ( isset( $rec['data']['id'] ) ? (string) $rec['data']['id'] : '' );
		foreach ( '' !== $rid && isset( $snap[ $rid ] ) ? (array) $snap[ $rid ] : array() as $id ) {
			if ( isset( $rooms[ (string) $id ] ) ) {
				$out[ $rooms[ (string) $id ]['hall'] ][ $rooms[ (string) $id ]['floor'] ] = true;
			}
		}
	}
	return $out;
}

/* ================================================================== who may open Lodging */

/**
 * Who sees the board (where every household and every Youngfolk sleeps). Today: every member of the
 * year ("one level of access", Oct 6). The Advisors asked on Oct 9 that where people sleep be
 * "extremely secure", so registration.csv's lodging_access = lodging narrows it to the COA, helpers
 * whose "Helps with" names Lodging, and webmasters. Which one is the Advisors' and the COA's decision
 * (NOTES/questions-lodging.md); the default stays as decided until they say.
 */
function ogc_lod_may_see( $year ) {
	if ( ! ogc_is_member( $year ) ) {
		return false;
	}
	if ( ogc_is_webmaster() ) {
		return true;
	}
	$cfg = ogc_lod_kv( $year, 'registration' );
	if ( 'lodging' !== strtolower( isset( $cfg['lodging_access'] ) ? trim( $cfg['lodging_access'] ) : '' ) || ! function_exists( 'ogc_member_me' ) ) {
		return true;
	}
	$m = ogc_member_me( $year );
	if ( ! $m ) {
		return (bool) apply_filters( 'ogc_lod_may_see', false, $year );
	}
	$helps = function_exists( 'ogc_committee_key' ) ? ogc_committee_key( isset( $m['helps'] ) ? $m['helps'] : '' ) : strtolower( (string) ( isset( $m['helps'] ) ? $m['helps'] : '' ) );
	return 'coa' === $m['role'] || false !== strpos( $helps, 'lodging' ) || (bool) apply_filters( 'ogc_lod_may_see', false, $year );
}

/* ================================================================== rows */

function ogc_lod_key_ok( $k ) {
	return (bool) preg_match( '/^(hh|yf|room|meta|note|undo|imp):[A-Za-z0-9|._ :@-]{1,88}$/', (string) $k );
}

/** Every row of a year (optionally only keys starting with $prefix): rkey => array( data, v, by, at ). */
function ogc_lod_rows( $year, $prefix = '' ) {
	global $wpdb;
	$sql = 'SELECT rkey, data, version, updated_by, updated_at FROM ' . ogc_table( 'lodging' ) . ' WHERE year = %d';
	$arg = array( (int) $year );
	if ( '' !== $prefix ) {
		$sql  .= ' AND rkey LIKE %s';
		$arg[] = $wpdb->esc_like( $prefix ) . '%';
	}
	$out = array();
	foreach ( (array) $wpdb->get_results( $wpdb->prepare( $sql . ' ORDER BY id', $arg ), ARRAY_A ) as $r ) {
		$out[ $r['rkey'] ] = array( 'data' => ogc_unjson( $r['data'], array() ), 'v' => (int) $r['version'], 'by' => (int) $r['updated_by'], 'at' => $r['updated_at'] );
	}
	return $out;
}

function ogc_lod_row( $year, $key ) {
	global $wpdb;
	$r = $wpdb->get_row( $wpdb->prepare( 'SELECT data, version, updated_by, updated_at FROM ' . ogc_table( 'lodging' ) . ' WHERE year = %d AND rkey = %s', $year, $key ), ARRAY_A );
	return $r ? array( 'data' => ogc_unjson( $r['data'], array() ), 'v' => (int) $r['version'], 'by' => (int) $r['updated_by'], 'at' => $r['updated_at'] ) : null;
}

/**
 * Write a row: $data null removes it. With $expect (the version last seen; 0 = new) a newer row isn't
 * overwritten. Returns the new version (0 when removed) or a WP_Error (409).
 */
function ogc_lod_put( $year, $key, $data, $expect = null ) {
	global $wpdb;
	$t   = ogc_table( 'lodging' );
	$cur = ogc_lod_row( $year, $key );
	$v   = $cur ? $cur['v'] : 0;
	if ( null !== $expect && (int) $expect !== $v ) {
		return new WP_Error( 'ogc_conflict', 'Changed since', array( 'status' => 409, 'key' => $key, 'version' => $v ) );
	}
	if ( null === $data ) {
		if ( $cur ) {
			$wpdb->query( $wpdb->prepare( "DELETE FROM $t WHERE year = %d AND rkey = %s AND version = %d", $year, $key, $v ) );
		}
		return 0;
	}
	if ( ! $cur ) {
		$ok = $wpdb->insert( $t, array( 'year' => (int) $year, 'rkey' => $key, 'data' => ogc_json( $data ), 'version' => 1, 'updated_by' => get_current_user_id(), 'updated_at' => ogc_now() ), array( '%d', '%s', '%s', '%d', '%d', '%s' ) );
		return $ok ? 1 : new WP_Error( 'ogc_conflict', 'Changed since', array( 'status' => 409, 'key' => $key ) );
	}
	$n = $wpdb->query( $wpdb->prepare( "UPDATE $t SET data = %s, version = version + 1, updated_by = %d, updated_at = %s WHERE year = %d AND rkey = %s AND version = %d", ogc_json( $data ), get_current_user_id(), ogc_now(), $year, $key, $v ) );
	return 1 === (int) $n ? $v + 1 : new WP_Error( 'ogc_conflict', 'Changed since', array( 'status' => 409, 'key' => $key ) );
}

/** Rows as the page gets them: { rkey: { data, v, by (a name), at } }, the bookkeeping rows left out. */
function ogc_lod_public_rows( $rows ) {
	$out   = array();
	$names = array();
	foreach ( $rows as $k => $r ) {
		if ( preg_match( '/^(undo|imp|meta:seen|meta:sent):/', $k ) ) {
			continue;
		}
		if ( ! isset( $names[ $r['by'] ] ) ) {
			$names[ $r['by'] ] = ogc_lod_name_of( $r['by'] );
		}
		$out[ $k ] = array( 'data' => $r['data'], 'v' => $r['v'], 'by' => $names[ $r['by'] ], 'at' => $r['at'] );
	}
	return (object) $out;
}

/* ================================================================== who and when */

/** A member as the page names them: "Ruth K." */
function ogc_lod_name_of( $user_id ) {
	$u = $user_id ? get_userdata( (int) $user_id ) : null;
	if ( ! $u ) {
		return '';
	}
	$n = trim( (string) $u->display_name );
	if ( '' === $n || false !== strpos( $n, '@' ) ) {
		$n = ucfirst( strtok( (string) $u->user_email, '@.' ) );
	}
	$w = preg_split( '/\s+/', $n );
	return count( $w ) > 1 ? $w[0] . ' ' . mb_substr( end( $w ), 0, 1 ) . '.' : $n;
}

function ogc_lod_me() {
	return ogc_lod_name_of( get_current_user_id() );
}

/** Today at the venue. A preview date (as_of) is taken on a local site, or from a webmaster. */
function ogc_lod_today( $year, $req = null ) {
	$as = $req instanceof WP_REST_Request && ( 'GET' === $req->get_method() || ogc_proto_saves() ) ? (string) $req->get_param( 'as_of' ) : '';
	// A preview date only reads (a change made while previewing is refused: ogc_appc_can), except in the shared prototype.
	if ( preg_match( '/^\d{4}-\d\d-\d\d$/', $as ) && ( ( function_exists( 'ogc_dev_tools_on' ) && ogc_dev_tools_on() ) || ogc_is_webmaster() ) ) {
		return $as;
	}
	$tz = function_exists( 'ogc_reg_tz' ) ? ogc_reg_tz( $year ) : new DateTimeZone( 'America/Indiana/Indianapolis' );
	$d  = new DateTime( 'now', $tz );
	return $d->format( 'Y-m-d' );
}

function ogc_lod_add_days( $iso, $n ) {
	$d = DateTime::createFromFormat( '!Y-m-d', (string) $iso, new DateTimeZone( 'UTC' ) );
	if ( ! $d ) {
		return '';
	}
	$d->modify( ( $n >= 0 ? '+' : '' ) . (int) $n . ' days' );
	return $d->format( 'Y-m-d' );
}

/** A file's key/value rows (registration.csv, settings.csv) as an array. */
function ogc_lod_kv( $year, $name ) {
	$f   = ogc_file_get( $year, $name );
	$out = array();
	foreach ( $f ? $f['rows'] : array() as $r ) {
		if ( isset( $r['key'] ) && '' !== $r['key'] && '#' !== substr( $r['key'], 0, 1 ) ) {
			$out[ $r['key'] ] = isset( $r['value'] ) ? (string) $r['value'] : '';
		}
	}
	return $out;
}

/**
 * Where the year stands for Lodging: start, end, the morning after the last night (checkout), held
 * (the Conference is over: rooms no longer move), the day names are cleared, and whether that day has
 * passed. The desk (Check in, Keys back) and Notes for next year keep working until the names are
 * cleared: the last morning is when most keys come back, and credits depend on them (the 2022 rule).
 * Cleared is decided by the real date too, so a preview date (as_of) never brings names back.
 */
function ogc_lod_phase( $year, $today ) {
	$row   = ogc_year_get( $year );
	$cfg   = ogc_lod_kv( $year, 'registration' );
	$end   = $row && ! empty( $row['end'] ) ? $row['end'] : '';
	$days  = isset( $cfg['clear_after_days'] ) && is_numeric( $cfg['clear_after_days'] ) ? (int) $cfg['clear_after_days'] : 60;
	$clear = $end ? ogc_lod_add_days( $end, $days ) : '';
	$real  = ogc_lod_today( $year );
	return array(
		'start'    => $row && ! empty( $row['start'] ) ? $row['start'] : '',
		'end'      => $end,
		'checkout' => $end ? ogc_lod_add_days( $end, 1 ) : '',
		'today'    => $today,
		'held'     => $end && $today > $end,
		'clear'    => $clear,
		'cleared'  => $clear && ( $today >= $clear || $real >= $clear ),
		'gone'     => $clear && $real >= $clear,   // by the real date: the rows may be removed
	);
}

/** A change only the desk makes (Check in, keys out, Keys back), which may go on after the Conference. */
function ogc_lod_desk_only( $old, $new ) {
	$desk = array( 'checkin' => 1, 'back' => 1, 'keysout' => 1, 'left' => 1 );
	$a    = array_diff_key( is_array( $old ) ? $old : array(), $desk );
	$b    = array_diff_key( is_array( $new ) ? $new : array(), $desk );
	return ogc_lod_same( $a, $b );
}

/** The same data, whatever order its keys were written in. */
function ogc_lod_same( $a, $b ) {
	$norm = function ( $v ) use ( &$norm ) {
		if ( is_object( $v ) ) {
			$v = (array) $v;
		}
		if ( is_array( $v ) ) {
			ksort( $v );
			return array_map( $norm, $v );
		}
		return $v;
	};
	return ogc_json( $norm( $a ) ) === ogc_json( $norm( $b ) );
}

/* ================================================================== the year's rooms and households */

/** Every room id in the year's halls (rooms.csv: hall, first, last, floor): id => array( hall, num, floor, for ). */
function ogc_lod_rooms( $year ) {
	$f   = ogc_file_get( $year, 'rooms' );
	$out = array();
	foreach ( $f ? $f['rows'] : array() as $r ) {
		if ( empty( $r['hall'] ) || '#' === substr( $r['hall'], 0, 1 ) || ! is_numeric( isset( $r['first'] ) ? $r['first'] : '' ) || ! is_numeric( isset( $r['last'] ) ? $r['last'] : '' ) ) {
			continue;
		}
		for ( $n = (int) $r['first']; $n <= (int) $r['last'] && $n - (int) $r['first'] < 400; $n++ ) {
			$out[ $r['hall'] . '|' . $n ] = array( 'hall' => $r['hall'], 'num' => $n, 'floor' => (int) ( isset( $r['floor'] ) ? $r['floor'] : 1 ), 'for' => strtolower( isset( $r['for'] ) && '' !== $r['for'] ? $r['for'] : 'families' ) );
		}
	}
	return $out;
}

function ogc_lod_room_words( $id ) {
	$p = explode( '|', (string) $id );
	return count( $p ) > 1 ? $p[0] . ' ' . $p[1] : (string) $id;
}

/** The year's registrations, by their rid: rid => record. */
function ogc_lod_households( $year ) {
	$out = array();
	foreach ( ogc_records( (int) $year, 'registrations' ) as $r ) {
		$rid = isset( $r['data']['rid'] ) ? (string) $r['data']['rid'] : ( isset( $r['data']['id'] ) ? (string) $r['data']['id'] : '' );
		if ( '' !== $rid ) {
			$out[ $rid ] = $r;
		}
	}
	return $out;
}

/** Is this household in dorm rooms now (not cancelled, not moved to the camper lot)? */
function ogc_lod_in_dorm( $rec ) {
	$d = $rec['data'];
	return 'dorm' === ( isset( $d['stay']['type'] ) ? $d['stay']['type'] : '' ) && 'cancelled' !== ( isset( $d['status'] ) ? $d['status'] : '' );
}

/** "Hammond · Levi and Ruth": the surname, then the adults' first names (one form everywhere). */
function ogc_lod_label( $d ) {
	$sur    = isset( $d['household']['name'] ) ? trim( preg_replace( '/^the\s+|\s+(family|household)$/i', '', (string) $d['household']['name'] ) ) : '';
	$adults = array();
	foreach ( isset( $d['people'] ) ? (array) $d['people'] : array() as $p ) {
		if ( 'adult' === ( isset( $p['kind'] ) ? $p['kind'] : ( isset( $p['band'] ) ? $p['band'] : '' ) ) && empty( $p['yf'] ) && ! empty( $p['name'] ) ) {
			$adults[] = strtok( trim( $p['name'] ), ' ' );
		}
	}
	if ( '' === $sur ) {
		$c   = isset( $d['household']['contact'] ) ? trim( (string) $d['household']['contact'] ) : '';
		$sur = $c ? substr( $c, strrpos( ' ' . $c, ' ' ) ) : 'Household';
	}
	if ( ! $adults ) {
		return $sur;
	}
	$last = array_pop( $adults );
	return $sur . ' · ' . ( $adults ? implode( ', ', $adults ) . ' and ' : '' ) . $last;
}

/** What a registration looked like when its rooms were given (the board shows what changed since). */
function ogc_lod_snap( $d ) {
	$s = isset( $d['stay'] ) ? (array) $d['stay'] : array();
	$n = 0;
	foreach ( isset( $d['people'] ) ? (array) $d['people'] : array() as $p ) {
		if ( ! empty( $p['name'] ) ) {
			$n++;
		}
	}
	return array(
		'type'   => isset( $s['type'] ) ? (string) $s['type'] : '',
		'nights' => array_values( (array) ( isset( $s['nights'] ) ? $s['nights'] : array() ) ),
		'rooms'  => (int) ( isset( $s['rooms'] ) ? $s['rooms'] : 0 ),
		'n'      => $n,
		'status' => isset( $d['status'] ) ? (string) $d['status'] : '',
		'ground' => ! empty( $s['ground'] ) || ! empty( $s['walker'] ),
		'at'     => ogc_now(),
	);
}

/* ================================================================== clearing names */

/** The year in counts: what stays once names are cleared (Lodging's final report, next year's set-up). */
function ogc_lod_numbers( $year ) {
	$rows   = ogc_lod_rows( $year, 'hh:' );
	$yfrows = ogc_lod_rows( $year, 'yf:' );
	$rooms  = ogc_lod_rooms( $year );
	$cfg    = ogc_lod_kv( $year, 'registration' );
	$nights = array_values( array_filter( array_map( 'trim', explode( '|', isset( $cfg['nights'] ) ? $cfg['nights'] : '' ) ) ) );
	$out    = array( 'households' => 0, 'rooms' => 0, 'by_hall' => array(), 'per_night' => array(), 'campers' => array(), 'yf' => array(), 'linens' => 0, 'mattresses' => 0 );
	foreach ( ogc_lod_households( $year ) as $rid => $rec ) {
		$d = $rec['data'];
		if ( 'cancelled' === ( isset( $d['status'] ) ? $d['status'] : '' ) ) {
			continue;
		}
		$s  = isset( $d['stay'] ) ? $d['stay'] : array();
		$ns = (array) ( isset( $s['nights'] ) ? $s['nights'] : array() );
		$t  = isset( $s['type'] ) ? $s['type'] : '';
		if ( 'dorm' === $t ) {
			$out['households']++;
			$out['linens']     += (int) ( isset( $s['linens'] ) ? $s['linens'] : 0 );
			$out['mattresses'] += (int) ( isset( $s['mattresses'] ) ? $s['mattresses'] : 0 );
			$given = isset( $rows[ 'hh:' . $rid ] ) ? (array) ( isset( $rows[ 'hh:' . $rid ]['data']['rooms'] ) ? $rows[ 'hh:' . $rid ]['data']['rooms'] : array() ) : array();
			foreach ( $given as $id ) {
				if ( isset( $rooms[ $id ] ) ) {
					$h = $rooms[ $id ]['hall'];
					$out['rooms']++;
					$out['by_hall'][ $h ] = ( isset( $out['by_hall'][ $h ] ) ? $out['by_hall'][ $h ] : 0 ) + 1;
					foreach ( $ns as $n ) {
						$out['per_night'][ $n ][ $h ] = ( isset( $out['per_night'][ $n ][ $h ] ) ? $out['per_night'][ $n ][ $h ] : 0 ) + 1;
					}
				}
			}
		} elseif ( 'camper' === $t ) {
			foreach ( $ns as $n ) {
				$out['campers'][ $n ] = ( isset( $out['campers'][ $n ] ) ? $out['campers'][ $n ] : 0 ) + 1;
			}
		} elseif ( 'yf' === $t ) {
			// A Youngfolk registered on their own: linens for their hall, counted apart from the rooms'.
			$out['yf_linens'] = ( isset( $out['yf_linens'] ) ? $out['yf_linens'] : 0 ) + (int) ( isset( $s['linens'] ) ? $s['linens'] : 0 );
		}
		foreach ( (array) ( isset( $d['people'] ) ? $d['people'] : array() ) as $p ) {
			if ( ! empty( $p['yf'] ) && ( 'yf' === $t || 'family' !== ( isset( $p['sleeps'] ) ? $p['sleeps'] : 'hall' ) ) ) {
				$hall = isset( $p['yfHall'] ) && 'women' === $p['yfHall'] ? 'young women' : 'young men';
				$out['yf'][ $hall ] = ( isset( $out['yf'][ $hall ] ) ? $out['yf'][ $hall ] : 0 ) + 1;
			}
		}
	}
	$out['yf_rooms'] = count( array_filter( $yfrows, function ( $r ) { return ! empty( $r['data']['room'] ); } ) );
	$row             = ogc_year_get( $year );
	$out['start']    = $row && ! empty( $row['start'] ) ? $row['start'] : '';
	$out['end']      = $row && ! empty( $row['end'] ) ? $row['end'] : '';
	$out['nights']   = $nights;
	$out['at']       = ogc_now();
	return $out;
}

/**
 * Once a year's names are due to be cleared: keep its counts, then remove every row that names or
 * points at a household (hh, yf, undo, imp, seen) and the published snapshot. Rooms' facts (holds,
 * out of service, accessible) and Notes for next year stay. The registrations themselves are the
 * register area's to clear.
 */
function ogc_lod_clear( $year ) {
	global $wpdb;
	if ( ! ogc_lod_row( $year, 'meta:numbers' ) ) {
		ogc_lod_put( $year, 'meta:numbers', ogc_lod_numbers( $year ) );
	}
	$t = ogc_table( 'lodging' );
	$n = 0;
	// Counts' kept copies keep their date, who and the counts; the rooming list (key holders) goes.
	foreach ( ogc_lod_rows( $year, 'meta:sent:' ) as $k => $r ) {
		$d = (array) $r['data'];
		if ( isset( $d['copy']['rooming'] ) ) {
			unset( $d['copy']['rooming'] );
			ogc_lod_put( $year, $k, $d );
		}
	}
	foreach ( array( 'hh:', 'yf:', 'undo:', 'imp:', 'meta:seen:', 'meta:published' ) as $p ) {
		$n += (int) $wpdb->query( $wpdb->prepare( "DELETE FROM $t WHERE year = %d AND rkey LIKE %s", $year, $wpdb->esc_like( $p ) . '%' ) );
	}
	ogc_log( 'lodging_cleared', $year, 'lodging', array( 'rows' => $n ) );
	return $n;
}

add_action( 'init', function () {
	if ( ! wp_next_scheduled( 'ogc_lodging_daily' ) ) {
		wp_schedule_event( time() + 2 * HOUR_IN_SECONDS, 'daily', 'ogc_lodging_daily' );
	}
} );

add_action( 'ogc_lodging_daily', function () {
	foreach ( ogc_years_list() as $y ) {
		$ph = ogc_lod_phase( $y, ogc_lod_today( $y ) );
		if ( $ph['gone'] && ( ogc_lod_rows( $y, 'hh:' ) || ogc_lod_rows( $y, 'yf:' ) || ! ogc_lod_row( $y, 'meta:numbers' ) ) ) {
			ogc_lod_clear( $y );
		}
	}
} );

/* ================================================================== for other areas */

/**
 * Where a year's rooms stand, in counts (no names): for the year page's card ("Rooms · 82 to assign").
 * array( dorm, assigned, waiting, published (date or ''), changed_since ).
 */
function ogc_lod_summary( $year ) {
	$rows = ogc_lod_rows( $year, 'hh:' );
	$pub  = ogc_lod_row( $year, 'meta:published' );
	$snap = $pub && isset( $pub['data']['snap'] ) ? (array) $pub['data']['snap'] : array();
	$out  = array( 'dorm' => 0, 'assigned' => 0, 'waiting' => 0, 'published' => $pub && ! empty( $pub['data']['date'] ) ? $pub['data']['date'] : '', 'changed' => 0 );
	foreach ( ogc_lod_households( $year ) as $rid => $rec ) {
		if ( ! ogc_lod_in_dorm( $rec ) ) {
			continue;
		}
		$out['dorm']++;
		$given = isset( $rows[ 'hh:' . $rid ]['data']['rooms'] ) ? (array) $rows[ 'hh:' . $rid ]['data']['rooms'] : array();
		$given ? $out['assigned']++ : $out['waiting']++;
		if ( $out['published'] && ( isset( $snap[ $rid ] ) ? (array) $snap[ $rid ] : array() ) !== $given ) {
			$out['changed']++;
		}
	}
	return $out;
}
