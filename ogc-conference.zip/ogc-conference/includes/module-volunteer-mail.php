<?php
/**
 * Volunteer shifts: the emails, the calendar files, and the timed jobs.
 *
 * Every email is one of the set (the signin area's ogc_mail_send_kind, laid out by ogc_mail_compose):
 * the subject as the heading, the shift as a small block (job, day and time, place), one filled button,
 * quiet links under it (Not you? Remove · Leave shift · Directions), and never a raw address in the
 * words (the plain-text twin keeps the links). The set's own kinds are used where they fit one shift
 * (reminder, shift_changed, shift_removed, spot_open, volunteer_left); the rest are this area's vol_*
 * kinds, added to the set through the ogc_mail_template_kind filter (and shown in the Mail log's preview).
 * Replies go to the committee's role address. Locally nothing is sent: the signin area's Mail log keeps it.
 *
 * Sent by the timed job (ogc_vol_tick: every five minutes by WP-Cron, and a real system cron on the
 * live site, see Corey's README), each once:
 *   confirm   after a join. Unconfirmed (a visitor): at once, the one Confirm covering every place still
 *             unconfirmed under that email. Signed in: held two minutes (Undo takes it back) and gathered
 *   left      gathered over two minutes too: one email, one calendar file cancelling each shift
 *   changed, removed, swapped, opened again   to the person, with the calendar event updated or cancelled
 *   opened    a place opened: to everyone waiting, a one-tap Join (the first to tap gets it)
 *   head      to the committee's role address: a late leave (within 48 hours), a swap, "not me"
 *   message   a head's message, one email per volunteer, with that person's own shifts
 *   reminders the day before at 9 AM venue time; "Your shifts" a week before the Conference
 *   weekly    Mondays, to each committee's contact: how full, what's short, what changed
 *   open      when sign-ups open: those who asked, and last year's volunteers who ticked Next year
 * And: places held for an email never confirmed are let go after settings confirm_hours (0, the
 * default, never); names are cleared settings clear_after_days (default 60) after the Conference,
 * keeping only counts and, for those who asked, their email and last year's shifts.
 */

defined( 'ABSPATH' ) || exit;

/* ================================================================== sending */

/** One designed email (a kind of the set) to one address. */
function ogc_vol_mail( $kind, $to, $data, $ctx = array() ) {
	$to = strtolower( trim( (string) $to ) );
	if ( ! is_email( $to ) ) {
		return false;
	}
	if ( ! function_exists( 'ogc_mail_send_kind' ) ) {
		ogc_log( 'vol_mail_off', 0, $kind, array() );
		return false;
	}
	$data = array_merge( array( 'year' => isset( $GLOBALS['ogc_vol_mail_year'] ) ? (int) $GLOBALS['ogc_vol_mail_year'] : 0 ), (array) $data );
	return (bool) ogc_mail_send_kind( $kind, $to, $data, $ctx );
}

/** Queue an email for the timed job. */
function ogc_vol_queue( $year, $kind, $email, $payload, $delay = 0 ) {
	global $wpdb;
	$wpdb->insert( ogc_table( 'vol_outbox' ), array(
		'year'       => (int) $year,
		'kind'       => $kind,
		'email'      => strtolower( (string) $email ),
		'payload'    => ogc_json( $payload ),
		'send_after' => gmdate( 'Y-m-d H:i:s', ogc_vol_now() + (int) $delay ),
		'created_at' => ogc_now(),
	), array( '%d', '%s', '%s', '%s', '%s', '%s' ) );
	ogc_vol_tick_soon();
}

/**
 * A confirmation. Unconfirmed (someone who typed their email): sent at once, since the page has just
 * said "Check your email", and it covers every place still unconfirmed under that email this year (a
 * second shift joined before opening the first email: the newest email's one Confirm does both).
 * Signed in: two minutes after the last join (Undo can take it back; six joins in a row are one email).
 */
function ogc_vol_queue_confirm( $year, $email, $rids, $confirmed, $delay = null ) {
	global $wpdb;
	if ( ! is_email( $email ) ) {
		return;
	}
	$email = strtolower( $email );
	$delay = null === $delay ? ( $confirmed ? 120 : 0 ) : (int) $delay;
	$rids  = array_map( 'intval', (array) $rids );
	if ( ! $confirmed ) {
		foreach ( ogc_records( $year, 'signups', $email ) as $r ) {
			if ( empty( $r['data']['confirmed'] ) && empty( $r['sample'] ) && strtotime( $r['created_at'] . ' UTC' ) > ogc_vol_now() - DAY_IN_SECONDS ) {
				$rids[] = (int) $r['id'];
			}
		}
		$rids = array_values( array_unique( $rids ) );
	}
	$t   = ogc_table( 'vol_outbox' );
	$row = $wpdb->get_row( $wpdb->prepare( "SELECT id, payload FROM $t WHERE year = %d AND kind = 'confirm' AND email = %s AND sent_at IS NULL ORDER BY id DESC LIMIT 1", $year, $email ), ARRAY_A );
	if ( $row ) {
		$p              = (array) ogc_unjson( $row['payload'], array() );
		$p['rids']      = array_values( array_unique( array_merge( (array) $p['rids'], $rids ) ) );
		$p['confirmed'] = ! empty( $p['confirmed'] ) && $confirmed;
		$wpdb->update( $t, array( 'payload' => ogc_json( $p ), 'send_after' => gmdate( 'Y-m-d H:i:s', ogc_vol_now() + $delay ) ), array( 'id' => (int) $row['id'] ), array( '%s', '%s' ), array( '%d' ) );
		if ( ! $delay ) {
			ogc_vol_tick_soon();
		}
		return;
	}
	// Five confirmations an hour to one address at most (a script can't flood an inbox).
	if ( ! ogc_vol_rate( 'confirm|' . $email, 5 ) ) {
		return;
	}
	ogc_vol_queue( $year, 'confirm', $email, array( 'rids' => $rids, 'confirmed' => (bool) $confirmed ), $delay );
}

/** Was a confirmation for this sign-up already sent? */
function ogc_vol_outbox_sent_for( $rid ) {
	global $wpdb;
	$t = ogc_table( 'vol_outbox' );
	foreach ( (array) $wpdb->get_col( "SELECT payload FROM $t WHERE kind = 'confirm' AND sent_at IS NOT NULL ORDER BY id DESC LIMIT 200" ) as $p ) { // phpcs:ignore -- no input.
		if ( in_array( (int) $rid, array_map( 'intval', (array) ( ogc_unjson( $p, array() )['rids'] ?? array() ) ), true ) ) {
			return true;
		}
	}
	return false;
}

/** Take a sign-up out of any confirmation not yet sent (Undo, Leave). */
function ogc_vol_outbox_drop( $rid ) {
	global $wpdb;
	$t = ogc_table( 'vol_outbox' );
	foreach ( (array) $wpdb->get_results( "SELECT id, payload FROM $t WHERE kind = 'confirm' AND sent_at IS NULL", ARRAY_A ) as $row ) { // phpcs:ignore -- no input.
		$p    = (array) ogc_unjson( $row['payload'], array() );
		$left = array_values( array_diff( array_map( 'intval', (array) $p['rids'] ), array( (int) $rid ) ) );
		if ( count( $left ) === count( (array) $p['rids'] ) ) {
			continue;
		}
		if ( $left ) {
			$p['rids'] = $left;
			$wpdb->update( $t, array( 'payload' => ogc_json( $p ) ), array( 'id' => (int) $row['id'] ), array( '%s' ), array( '%d' ) );
		} else {
			$wpdb->delete( $t, array( 'id' => (int) $row['id'] ), array( '%d' ) );
		}
	}
}

/** An email to one person about one of their sign-ups (left, changed, removed, swapped). Leaving is
 * gathered: a family leaving three shifts in a minute gets one email with one calendar file. */
function ogc_vol_queue_person( $year, $rec, $what, $extra = array() ) {
	global $wpdb;
	if ( empty( $rec['data']['email'] ) || ! empty( $rec['data']['sample'] ) || ! empty( $rec['sample'] ) ) {
		return;
	}
	if ( 'left' !== $what ) {
		ogc_vol_queue( $year, 'person', $rec['data']['email'], array( 'rec' => $rec, 'what' => $what, 'extra' => $extra ) );
		return;
	}
	// Joined and left again before any email went (a signed-in person's quick change of mind): nothing to say.
	if ( ! ogc_vol_outbox_sent_for( $rec['id'] ) && strtotime( $rec['created_at'] . ' UTC' ) > ogc_vol_now() - 600 && empty( $extra['by_head'] ) ) {
		return;
	}
	$email = strtolower( $rec['data']['email'] );
	$t     = ogc_table( 'vol_outbox' );
	$row   = $wpdb->get_row( $wpdb->prepare( "SELECT id, payload FROM $t WHERE year = %d AND kind = 'left' AND email = %s AND sent_at IS NULL ORDER BY id DESC LIMIT 1", $year, $email ), ARRAY_A );
	$item  = array( 'rec' => $rec, 'by_head' => ! empty( $extra['by_head'] ), 'by_name' => isset( $extra['by_name'] ) ? (string) $extra['by_name'] : '' );
	if ( $row ) {
		$p          = (array) ogc_unjson( $row['payload'], array() );
		$p['items'][] = $item;
		$wpdb->update( $t, array( 'payload' => ogc_json( $p ), 'send_after' => gmdate( 'Y-m-d H:i:s', ogc_vol_now() + 120 ) ), array( 'id' => (int) $row['id'] ), array( '%s', '%s' ), array( '%d' ) );
		return;
	}
	ogc_vol_queue( $year, 'left', $email, array( 'items' => array( $item ) ), 120 );
}

/** A place opened: everyone waiting on the shift hears at once, each with a one-tap Join. */
function ogc_vol_notify_waitlist( $year, $sh ) {
	foreach ( ogc_records( $year, 'waits' ) as $w ) {
		if ( isset( $w['data']['id'] ) && $w['data']['id'] === $sh['id'] && empty( $w['sample'] ) ) {
			ogc_vol_queue( $year, 'opened', $w['email'], array( 'shift' => $sh['id'], 'name' => $w['data']['name'], 'wait' => $w['id'] ) );
		}
	}
}

/** Something the committee's head should hear at once. A committee with no contact yet: kept for the
 * weekly list instead, and logged. */
function ogc_vol_head_notice( $year, $sh, $what, $extra = array() ) {
	// The committee's heads as the COA set them on Members (integration, Oct 11), and its role address.
	$c  = ogc_vol_committees( $year );
	$to = array();
	foreach ( ogc_vol_heads_of( $year, $sh['committee'] ) as $h ) {
		$to[ strtolower( $h['email'] ) ] = true;
	}
	$e = isset( $c[ $sh['committee'] ] ) ? $c[ $sh['committee'] ]['contact_email'] : '';
	if ( is_email( $e ) ) {
		$to[ strtolower( $e ) ] = true;
	}
	if ( ! $to ) {
		ogc_log( 'vol_no_contact', $year, $sh['committee'], array( 'what' => $what ) );
		return;
	}
	foreach ( array_keys( $to ) as $e ) {
		ogc_vol_queue( $year, 'head', $e, array( 'shift' => $sh['id'], 'what' => $what, 'extra' => $extra ) );
	}
}

// A committee's role address is never held back by the per-address limit: the signin area's
// ogc_mail_cap_exempt() already counts committees.csv contact_email as a role address.

/* ================================================================== the words */

function ogc_vol_year_title( $year ) {
	return $year . ' Annual Conference';
}

/** "Fri, May 28" for a subject line (the evening before, for a night shift: as the page says it). The
 * year is the line above the heading, so it isn't repeated here. */
function ogc_vol_subject_day( $year, $sh ) {
	$t = strtotime( $sh['date'] . ' 00:00:00 UTC' ) - ( $sh['start'] < 300 ? 86400 : 0 );
	return gmdate( 'D, M j', $t ) . ( $sh['start'] < 300 ? ' night' : '' );
}

/** A plugin address with every query value encoded: ogc_url (add_query_arg) leaves them raw, and a
 * space in "Dining hall" ends the link in most mail programs. */
function ogc_vol_url( $path, $args = array() ) {
	return ogc_url( $path, array_map( 'rawurlencode', array_map( 'strval', $args ) ) );
}

/** The emailed Confirm link. Signing in is the signin area's: its single-use link (kept in its tokens
 * table, so a forwarded email can't sign in twice) confirms these sign-ups as it signs in, then opens the
 * page (ogc_signed_in). For an address a link may not sign in (an editor's or admin's), the link only
 * confirms the sign-ups (an opaque vol_confirm token) and signs no one in. */
function ogc_vol_confirm_link( $year, $email, $rids ) {
	if ( function_exists( 'ogc_signin_link_for' ) && function_exists( 'ogc_email_may_signin' ) && ogc_email_may_signin( $email ) ) {
		$back = wp_parse_url( ogc_vol_page( $year, array( 'confirmed' => count( $rids ) ) ) );
		return ogc_signin_link_for( $email, $back['path'] . '?' . $back['query'], 'confirm', array( 'vol' => array( 'y' => (int) $year, 'r' => array_map( 'intval', $rids ) ) ), ogc_vol_confirm_ttl( $year ) );
	}
	return ogc_vol_link( $year, 'confirm', $email, array( 'r' => array_values( $rids ) ), ogc_vol_confirm_ttl( $year ) );
}

/** A link to the page that carries an opaque token (nothing in the address says who or what). */
function ogc_vol_link( $year, $act, $email, $data, $ttl, $args = array() ) {
	$t = ogc_vol_token( array_merge( array( 'a' => $act, 'y' => (int) $year, 'e' => $email ), $data ), $ttl );
	return $t ? ogc_vol_page( $year, array_merge( $args, array( 't' => $t ) ) ) : '';
}

/** The Confirm link lasts as long as the place does: the COA's hours when it lets places go, else a
 * week (Resend sends a new one). */
function ogc_vol_confirm_ttl( $year ) {
	$h = ogc_vol_confirm_hours( $year );
	return $h > 0 ? $h * HOUR_IN_SECONDS : 7 * DAY_IN_SECONDS;
}

/** The page's address. */
function ogc_vol_page( $year, $args = array() ) {
	return ogc_vol_url( 'volunteer', array_merge( array( 'year' => (int) $year ), $args ) );
}

function ogc_vol_signups_url( $year ) {
	return ogc_vol_url( 'register', array( 'year' => (int) $year, 'view' => 'mine' ) );
}

/** Your sign-ups, as an email links it: the signin area's one-tap link (it signs in on that device). */
function ogc_vol_mine_link( $year, $email ) {
	return function_exists( 'ogc_mine_url' ) ? ogc_mine_url( $email, $year ) : ogc_vol_signups_url( $year );
}

/** The emailed Leave link for some sign-ups: good until the last of their shifts ends. */
function ogc_vol_leave_link( $year, $email, $rids ) {
	$shifts = ogc_vol_shifts( $year );
	$until  = ogc_vol_now() + HOUR_IN_SECONDS;
	foreach ( (array) $rids as $rid ) {
		$r = ogc_record_get( (int) $rid );
		if ( $r && isset( $shifts[ $r['data']['id'] ] ) ) {
			$until = max( $until, $shifts[ $r['data']['id'] ]['end_ts'] );
		}
	}
	return ogc_vol_link( $year, 'leave', $email, array( 'r' => array_map( 'intval', array_values( (array) $rids ) ) ), $until - ogc_vol_now() );
}

/** A shift as the emails show it: what, when (with the venue's zone), where, Directions. */
function ogc_vol_mail_shift( $y, $sh, $name = '' ) {
	$zone = function_exists( 'ogc_mail_zone' ) ? ogc_mail_zone( $y ) : '';
	$span = ogc_vol_span( $sh['start'], $sh['end'] ) . ( $zone ? ' ' . $zone : '' );
	return array(
		'title'     => $sh['role'],
		'committee' => $sh['committee'],
		'day'       => ogc_vol_subject_day( $y, $sh ),
		'span'      => $span,
		'when'      => ogc_vol_subject_day( $y, $sh ) . ' · ' . $span,
		'place'     => $sh['place_name'],
		'note'      => $sh['note'],
		'name'      => $name,
		'map'       => '' !== (string) $sh['place'] ? ogc_vol_url( 'guide', array( 'year' => (int) $y, 'view' => 'places', 'to' => $sh['place'] ) ) : '',
	);
}

/** Questions go to the committee: its role phone, and replies to its role address. */
function ogc_vol_mail_questions( $year, $committee ) {
	$p = ogc_vol_role_phone( $year, $committee );
	$r = ogc_vol_reply_to( $year, $committee );
	return trim( ( $p ? $p : '' ) . ( $p && $r ? ' · ' : '' ) . ( $r ? 'Reply to this email' : '' ) );
}

/** The committee's role address to reply to. */
function ogc_vol_reply_to( $year, $committee ) {
	$c = ogc_vol_committees( $year );
	return isset( $c[ $committee ] ) && is_email( $c[ $committee ]['contact_email'] ) ? $c[ $committee ]['contact_email'] : '';
}

/* ================================================================== the set's vol_* kinds */

add_filter( 'ogc_mail_kinds', function ( $k ) {
	return array_merge( (array) $k, array(
		'vol_confirm'     => 'Volunteer · Confirm your place, or Signed up',
		'vol_left'        => 'Volunteer · Left shift (gathered)',
		'vol_replaced'    => 'Volunteer · Replaced (a swap taken)',
		'vol_open_again'  => 'Volunteer · Place open again (not confirmed)',
		'vol_reminder'    => 'Volunteer · Tomorrow (two or more shifts)',
		'vol_week'        => 'Volunteer · Next week (every shift)',
		'vol_message'     => 'Volunteer · A head’s message',
		'vol_heads'       => 'Volunteer · Message to every committee’s heads',
		'vol_copy'        => 'Volunteer · Copy of a message',
		'vol_head'        => 'Volunteer · Notice to a committee (swap, unconfirmed, not me)',
		'vol_weekly'      => 'Volunteer · This week (to the committee)',
		'vol_remind'      => 'Volunteer · Dorm shifts (Young Folks parents)',
		'vol_open'        => 'Volunteer · Sign-ups open',
		'vol_notify'      => 'Volunteer · Email me when it opens',
	) );
} );
// Their subjects carry a volunteer's name or a head's own words: the live site's log keeps the label only.
add_filter( 'ogc_mail_private_kinds', function ( $k ) {
	return array_merge( (array) $k, array( 'vol_head', 'vol_message', 'vol_heads', 'vol_copy' ) );
} );

/** One shift's facts (When, Where, Committee; Who for someone else), or one line a shift for several. */
function ogc_vol_mail_facts( $shifts ) {
	$shifts = array_values( (array) $shifts );
	if ( 1 === count( $shifts ) ) {
		$s = $shifts[0];
		return array(
			array( 'Who', $s['name'] ),
			array( 'When', $s['when'] ),
			array( 'Where', $s['place'] ),
			array( 'Committee', 0 === strcasecmp( $s['committee'], $s['title'] ) ? '' : $s['committee'] ),
		);
	}
	$f = array();
	foreach ( $shifts as $s ) {
		$f[] = array( $s['day'], ( $s['name'] ? $s['name'] . ' · ' : '' ) . $s['title'] . ' · ' . $s['span'] . ( $s['place'] ? "\n" . $s['place'] : '' ) );
	}
	return $f;
}

/** "Golf cart driver · Fri, May 28", or "3 shifts". */
function ogc_vol_mail_what( $shifts ) {
	$shifts = array_values( (array) $shifts );
	return 1 === count( $shifts ) ? $shifts[0]['title'] . ' · ' . $shifts[0]['day'] : count( $shifts ) . ' shifts';
}

add_filter( 'ogc_mail_template_kind', 'ogc_vol_mail_template', 10, 4 );

/** The vol_* kinds, laid out by the set's own ogc_mail_compose. */
function ogc_vol_mail_template( $m, $kind, $d, $base ) {
	if ( $m || 0 !== strpos( (string) $kind, 'vol_' ) || ! function_exists( 'ogc_mail_compose' ) ) {
		return $m;
	}
	$g      = function ( $k, $def = '' ) use ( $d ) {
		return isset( $d[ $k ] ) && '' !== $d[ $k ] && null !== $d[ $k ] ? $d[ $k ] : $def;
	};
	$shifts = array_values( array_filter( (array) $g( 'shifts', array() ), 'is_array' ) );
	$one    = 1 === count( $shifts );
	$first  = $shifts ? $shifts[0] : array( 'title' => '', 'committee' => '', 'note' => '', 'map' => '', 'when' => '', 'place' => '', 'day' => '', 'span' => '', 'name' => '' );
	$map    = $one && $first['map'] ? array( '', 'Directions', $first['map'] ) : ( $shifts ? array( '', 'Campus map', ogc_vol_url( 'guide', array( 'year' => (int) $g( 'year' ), 'view' => 'places' ) ) ) : '' );
	$a      = null;
	switch ( $kind ) {
		case 'vol_confirm':
			$ok   = (bool) $g( 'confirmed' );
			$subj = ( $ok ? 'Signed up · ' : ( $one ? 'Confirm your place · ' : 'Confirm your places · ' ) ) . ogc_vol_mail_what( $shifts );
			$a    = array(
				'subject'   => $subj,
				'heading'   => $subj,
				'preheader' => $ok ? $first['when'] : 'One tap confirms it',
				'facts'     => ogc_vol_mail_facts( $shifts ),
				'lines'     => array_values( array_filter( array( $g( 'by_head' ) ? 'The ' . $g( 'by_head' ) . ' head signed you up.' : ( $g( 'by_name' ) ? ogc_mail_safe_name( $g( 'by_name' ) ) . ' signed you up.' : '' ), $one ? wp_strip_all_tags( (string) $first['note'] ) : '' ) ) ),
				// One button: Confirm while it needs a tap, else Your sign-ups.
				'button'    => $ok ? array( 'Your sign-ups', $g( 'mine_url' ) ) : array( 'Confirm', $g( 'confirm_url' ) ),
				'after'     => array(
					! $ok && (int) $g( 'hours' ) > 0 ? 'Unconfirmed places open again after ' . (int) $g( 'hours' ) . ' hours.' : '',
					$g( 'has_ics' ) ? 'Calendar file attached. A reminder comes the day before.' : '',
					$map,
					$ok ? array( 'Can’t make it?', 'Leave shift', $g( 'leave_url' ) ) : '',
					// Someone added by another person answers Not me; anyone else, Not you? Remove.
					$g( 'by_name' ) ? array( 'Wrong person?', 'Not me', $g( 'notme_url' ) ) : array( 'Not you?', 'Remove', $g( 'notme_url' ) ),
				),
				'reason'    => $g( 'by_name' ) ? ogc_mail_safe_name( $g( 'by_name' ) ) . ' added this address.' : 'This address signed up to help.',
			);
			break;

		case 'vol_left':
			$head = (bool) $g( 'by_head' );
			// Taken off by the person who added them (Add someone): said so, by name.
			$byn  = $head ? '' : (string) $g( 'by_name' );
			$subj = ( $head || $byn ? 'Removed · ' : 'Left shift · ' ) . ogc_vol_mail_what( $shifts );
			$a    = array(
				'subject' => $subj,
				'heading' => $subj,
				'facts'   => ogc_vol_mail_facts( $shifts ),
				'lines'   => array( $head ? 'The ' . $first['committee'] . ' head took you off ' . ( $one ? 'this shift' : 'these shifts' ) . '.' : ( $byn ? ogc_mail_safe_name( $byn ) . ' took you off ' . ( $one ? 'this shift' : 'these shifts' ) . '. ' : '' ) . 'The ' . $first['committee'] . ' head is told.' ),
				'button'  => array( $one ? 'Join again' : 'Volunteer shifts', $g( 'join_url' ) ),
				'after'   => array( $g( 'has_ics' ) ? 'The calendar ' . ( $one ? 'event is' : 'events are' ) . ' cancelled (file attached).' : '' ),
				'reason'  => 'This address was signed up for ' . ( $one ? 'this shift' : 'these shifts' ) . '.',
			);
			break;

		case 'vol_replaced':
			$subj = 'Replaced · ' . ogc_vol_mail_what( $shifts );
			$a    = array(
				'subject' => $subj,
				'heading' => $subj,
				'facts'   => ogc_vol_mail_facts( $shifts ),
				'lines'   => array( ogc_mail_safe_name( $g( 'to', 'Someone' ) ) . ' took your place. The ' . $first['committee'] . ' head is told.' ),
				'button'  => array( 'Your sign-ups', $g( 'mine_url' ) ),
				'after'   => array( $g( 'has_ics' ) ? 'The calendar event is cancelled (file attached).' : '' ),
				'reason'  => 'This address was signed up for this shift.',
			);
			break;

		case 'vol_open_again':
			$subj = 'Place open again · ' . ogc_vol_mail_what( $shifts );
			$a    = array(
				'subject' => $subj,
				'heading' => $subj,
				'facts'   => ogc_vol_mail_facts( $shifts ),
				'lines'   => array( 'Not confirmed, so the place is open again. The ' . $first['committee'] . ' head is told.' ),
				'button'  => array( 'Join again', $g( 'join_url' ) ),
				'reason'  => 'This address signed up for this shift.',
			);
			break;

		case 'vol_reminder':
		case 'vol_week':
			$subj = ( 'vol_week' === $kind ? 'Next week · Your shifts' : 'Tomorrow · ' . ogc_vol_mail_what( $shifts ) );
			$a    = array(
				'subject' => $subj,
				'heading' => $subj,
				'facts'   => ogc_vol_mail_facts( $shifts ),
				'button'  => $one && $first['map'] ? array( 'Directions', $first['map'] ) : array( 'Your sign-ups', $g( 'mine_url' ) ),
				'after'   => array( $one ? '' : $map, $g( 'has_ics' ) ? 'Calendar file attached.' : '', array( 'Can’t make it?', 'Leave shift', $g( 'leave_url' ) ) ),
				'reason'  => 'This address is signed up for ' . ( $one ? 'this shift' : 'these shifts' ) . '.',
			);
			break;

		case 'vol_message':
		case 'vol_heads':
		case 'vol_copy':
			$subj = wp_strip_all_tags( (string) $g( 'subject', 'Message' ) );
			$your = array();
			foreach ( $shifts as $s ) {
				$your[] = ( $s['name'] ? $s['name'] . ' · ' : '' ) . $s['title'] . ' · ' . $s['when'] . ( $s['place'] ? ' · ' . $s['place'] : '' );
			}
			$a = array(
				'subject'   => ( 'vol_copy' === $kind ? 'Copy · ' : '' ) . $subj,
				'heading'   => ( 'vol_copy' === $kind ? 'Copy · ' : '' ) . $subj,
				'facts'     => array( array( 'From', $g( 'from' ) ), array( 'To', $g( 'sent_to' ) ), array( count( $your ) > 1 ? 'Your shifts' : 'Your shift', implode( "\n", $your ) ) ),
				'plain'     => mb_substr( (string) $g( 'body' ), 0, 5000 ),
				'button'    => 'vol_message' === $kind && $g( 'mine_url' ) ? array( 'Your sign-ups', $g( 'mine_url' ) ) : null,
				'questions' => 'vol_copy' === $kind ? '' : 'Reply to this email',
				'reason'    => 'vol_heads' === $kind ? 'Sent to each committee’s contact and heads.' : ( 'vol_copy' === $kind ? '' : 'You’re signed up with ' . ogc_mail_the( $g( 'committee' ) ) . '.' ),
			);
			break;

		case 'vol_head':
			$w    = (string) $g( 'what' );
			$name = ogc_mail_safe_name( $g( 'name' ) );
			$subj = 'swap' === $w ? 'Swap · ' . ogc_mail_safe_name( $g( 'from' ) ) . ' → ' . ogc_mail_safe_name( $g( 'to' ) ) . ' · ' . $first['title']
				: ( 'unconfirmed' === $w ? 'Unconfirmed · ' . $name . ' · ' . $first['title'] : 'Removed · ' . $name . ' · ' . $first['title'] );
			$a    = array(
				'subject' => $subj,
				'heading' => $subj,
				'facts'   => array( array( 'When', $first['when'] ), array( 'Phone', 'unconfirmed' === $w ? $g( 'phone' ) : '' ), array( 'Open', '' !== (string) $g( 'open' ) ? (string) (int) $g( 'open' ) : '' ) ),
				'lines'   => array_values( array_filter( array(
					'unconfirmed' === $w ? 'The confirmation wasn’t opened, so the place is open again. To keep them on, call and add them back.' : '',
					'notme' === $w ? 'The owner of the email used for ' . $name . ' said it wasn’t them. The sign-up is removed.' : '',
				) ) ),
				'button'  => array( 'Who’s signed up', $g( 'list_url' ) ),
				'reason'  => 'Notices for ' . ogc_mail_the( $first['committee'] ) . ' come to this address.',
			);
			break;

		case 'vol_weekly':
			$lines = array();
			foreach ( (array) $g( 'open_shifts', array() ) as $s ) {
				$lines[] = $s[0] . ' · ' . $s[1] . ' · ' . (int) $s[2] . ' open';
			}
			$week = trim( ( (int) $g( 'joined' ) ? (int) $g( 'joined' ) . ' joined' : '' ) . ( (int) $g( 'joined' ) && (int) $g( 'left' ) ? ' · ' : '' ) . ( (int) $g( 'left' ) ? (int) $g( 'left' ) . ' left' : '' ) );
			$subj = $g( 'committee' ) . ' volunteers · ' . (int) $g( 'filled' ) . ' of ' . (int) $g( 'needed' ) . ' filled';
			$a    = array(
				'subject' => $subj,
				'heading' => $subj,
				'facts'   => array( array( 'Open', (int) $g( 'open' ) ? (string) (int) $g( 'open' ) : '' ), array( 'This week', $week ) ),
				'lines'   => $lines ? array( "Still open\n" . implode( "\n", array_slice( $lines, 0, 25 ) ) ) : array( 'Every shift is full.' ),
				'button'  => array( 'Who’s signed up', $g( 'list_url' ) ),
				'after'   => array( 'Names and phones are on the list, signed in. Turn this email off there.' ),
				'reason'  => 'The weekly summary for ' . ogc_mail_the( $g( 'committee' ) ) . '’s contact.',
			);
			break;

		case 'vol_remind':
			$a = array(
				'subject' => 'Dorm shifts · ' . $g( 'committee', 'Young Folks' ),
				'heading' => 'Dorm shifts · ' . $g( 'committee', 'Young Folks' ),
				'lines'   => array( 'One supervision shift is asked of each parent with Young Folks in the halls.' ),
				'button'  => array( 'Choose a shift', $g( 'page_url' ) ),
				'reason'  => 'This household has Young Folks staying in the halls.',
			);
			break;

		case 'vol_open':
			$was = (array) $g( 'again', array() );
			$a   = array(
				'subject' => 'Sign-ups open · Volunteer shifts',
				'heading' => 'Sign-ups open · Volunteer shifts',
				'lines'   => $was ? array( 'Your ' . ( (int) $g( 'year' ) - 1 ) . " shifts, on this year's days\n" . implode( "\n", array_slice( $was, 0, 12 ) ) ) : array(),
				'button'  => $was ? array( 'Sign up again', $g( 'again_url' ) ) : array( 'Volunteer shifts', $g( 'page_url' ) ),
				'after'   => array( $was ? array( '', 'Every shift', $g( 'page_url' ) ) : '' ),
				'reason'  => 'You asked to hear when sign-ups open.',
			);
			break;

		case 'vol_notify':
			$a = array(
				'subject' => 'Noted · ' . (int) $g( 'year' ) . ' volunteer sign-ups',
				'heading' => 'Noted · ' . (int) $g( 'year' ) . ' volunteer sign-ups',
				'lines'   => array( 'You’ll get one email when they open.' ),
				'after'   => array( array( 'Not you?', 'Remove me', $g( 'remove_url' ) ) ),
				'reason'  => 'Someone asked, on the volunteer page, to email this address once.',
			);
			break;
	}
	return $a ? ogc_mail_compose( array_merge( $base, $a ) ) : null;
}

// Made-up examples for the Mail log's preview (sample people only).
add_filter( 'ogc_mail_samples', function ( $s ) {
	$link  = ogc_url( 'volunteer', array( 'year' => 2027, 't' => 'SAMPLE-not-a-real-link' ) );
	$one   = array( 'title' => 'Golf cart driver', 'committee' => 'Transportation', 'day' => 'Fri, May 28', 'span' => '2–6 PM Eastern', 'when' => 'Fri, May 28 · 2–6 PM Eastern', 'place' => 'Barnes Student Center', 'note' => 'Keys at the Information Center.', 'name' => '', 'map' => ogc_url( 'guide', array( 'year' => 2027, 'view' => 'places', 'to' => 'B' ) ) );
	$two   = array_merge( $one, array( 'title' => 'Server', 'committee' => 'Food', 'day' => 'Sat, May 29', 'span' => '11:45 AM–2:15 PM Eastern', 'when' => 'Sat, May 29 · 11:45 AM–2:15 PM Eastern', 'place' => 'Baldwin Dining Hall', 'name' => 'Esther' ) );
	$c     = array( 'questions' => '765-555-0140 · Reply to this email' );
	return array_merge( (array) $s, array(
		'vol_confirm'    => $c + array( 'shifts' => array( $one ), 'confirmed' => false, 'confirm_url' => $link, 'notme_url' => $link, 'has_ics' => true ),
		'vol_left'       => $c + array( 'shifts' => array( $one, $two ), 'join_url' => $link, 'has_ics' => true ),
		'vol_replaced'   => $c + array( 'shifts' => array( $one ), 'to' => 'Tom P.', 'mine_url' => $link, 'has_ics' => true ),
		'vol_open_again' => $c + array( 'shifts' => array( $one ), 'join_url' => $link ),
		'vol_reminder'   => $c + array( 'shifts' => array( $one, $two ), 'mine_url' => $link, 'leave_url' => $link ),
		'vol_week'       => $c + array( 'shifts' => array( $one, $two ), 'mine_url' => $link, 'leave_url' => $link, 'has_ics' => true ),
		'vol_message'    => array( 'subject' => 'Carts moved', 'from' => 'Phoebe L. · Transportation head', 'committee' => 'Transportation', 'shifts' => array( $one ), 'body' => "The carts are behind the Fieldhouse this year, not at Barnes.\nKeys at the Information Center.", 'mine_url' => $link ),
		'vol_heads'      => array( 'subject' => 'Sign-in sheets', 'from' => 'Nathan K. · Committee of Arrangements', 'body' => 'Please print your sign-in sheets by Thursday.' ),
		'vol_copy'       => array( 'subject' => 'Carts moved', 'sent_to' => '18 volunteers · Transportation', 'body' => 'The carts are behind the Fieldhouse this year.' ),
		'vol_head'       => array( 'what' => 'unconfirmed', 'name' => 'Hannah T.', 'phone' => '765-555-0199', 'open' => 1, 'shifts' => array( $one ), 'list_url' => $link, 'to' => 'transportation@conference.example.org' ),
		'vol_weekly'     => array( 'committee' => 'Transportation', 'filled' => 31, 'needed' => 40, 'open' => 9, 'joined' => 6, 'left' => 1, 'open_shifts' => array( array( 'Golf cart driver', 'Sat, May 29 · 7–11 AM', 2 ) ), 'list_url' => $link, 'to' => 'transportation@conference.example.org' ),
		'vol_remind'     => array( 'committee' => 'Young Folks', 'page_url' => $link ),
		'vol_open'       => array( 'again' => array( 'Golf cart driver · Transportation · Saturday 7–11 AM' ), 'again_url' => $link, 'page_url' => $link ),
		'vol_notify'     => array( 'year' => 2028, 'remove_url' => $link ),
	) );
} );

/* ================================================================== calendar files */

function ogc_vol_ics_text( $v ) {
	return str_replace( array( '\\', ',', ';', "\n" ), array( '\\\\', '\,', '\;', '\n' ), (string) $v );
}

/** A calendar file for some sign-ups. Each event's UID lasts (the sign-up's record id), so an
 * update replaces it and a cancel removes it (METHOD and SEQUENCE). */
function ogc_vol_ics( $year, $items, $method = 'PUBLISH' ) {
	$snap = ogc_state_get( $year, 'vol-snap' );
	$snap = $snap ? (array) $snap['value'] : array();
	$L    = array( 'BEGIN:VCALENDAR', 'VERSION:2.0', 'PRODID:-//ogbbc.org//Annual Conference//EN', 'METHOD:' . $method );
	foreach ( $items as $it ) {
		$sh  = $it['shift'];
		// The sign-up's record id (never a name: calendar servers keep the UID), the same in every email.
		$uid = 'ogc-vol-' . ( ! empty( $it['rid'] ) ? (int) $it['rid'] : substr( md5( $sh['id'] . '|' . $it['name'] ), 0, 16 ) ) . '@ogbbc.org';
		$seq = isset( $snap[ $sh['id'] ]['seq'] ) ? (int) $snap[ $sh['id'] ]['seq'] : 0;
		$L[] = 'BEGIN:VEVENT';
		$L[] = 'UID:' . $uid;
		$L[] = 'SEQUENCE:' . ( 'CANCEL' === $method ? $seq + 1 : $seq );
		$L[] = 'DTSTAMP:' . gmdate( 'Ymd\THis\Z', ogc_vol_now() );
		$L[] = 'DTSTART:' . gmdate( 'Ymd\THis\Z', $sh['start_ts'] );
		$L[] = 'DTEND:' . gmdate( 'Ymd\THis\Z', $sh['end_ts'] );
		$L[] = 'SUMMARY:' . ogc_vol_ics_text( $sh['role'] . ' · ' . $sh['committee'] );
		$s   = ogc_vol_settings( $year );
		$loc = array_filter( array( $sh['place_name'], isset( $s['venue'] ) ? $s['venue'] : '', isset( $s['city'] ) ? $s['city'] : '' ) );
		if ( $loc ) {
			$L[] = 'LOCATION:' . ogc_vol_ics_text( implode( ', ', $loc ) );
		}
		$L[] = 'DESCRIPTION:' . ogc_vol_ics_text( ( $sh['note'] ? $sh['note'] . "\n" : '' ) . 'Your sign-ups: ' . ogc_vol_signups_url( $year ) );
		if ( 'CANCEL' === $method ) {
			$L[] = 'STATUS:CANCELLED';
		} else {
			$L[] = 'BEGIN:VALARM';
			$L[] = 'TRIGGER:-P1D';
			$L[] = 'ACTION:DISPLAY';
			$L[] = 'DESCRIPTION:' . ogc_vol_ics_text( 'Tomorrow: ' . $sh['role'] );
			$L[] = 'END:VALARM';
		}
		$L[] = 'END:VEVENT';
	}
	$L[] = 'END:VCALENDAR';
	return implode( "\r\n", $L ) . "\r\n";
}

/* ================================================================== the outbox */

/** A sign-up's shift as it is now, or as it was (a removed shift, from the snapshot kept with it). */
function ogc_vol_shift_of( $y, $rec, $was = null ) {
	$shifts = ogc_vol_shifts( $y );
	$id     = isset( $rec['data']['id'] ) ? $rec['data']['id'] : '';
	if ( isset( $shifts[ $id ] ) ) {
		return $shifts[ $id ];
	}
	if ( $was ) {
		$was = (array) $was;
		return array( 'id' => $id, 'uid' => '', 'role' => $was['role'], 'committee' => $was['committee'], 'date' => $was['date'], 'start' => (int) $was['start'], 'end' => (int) $was['end'], 'place' => isset( $was['place'] ) ? $was['place'] : '', 'place_name' => '', 'note' => '', 'start_ts' => ogc_vol_ts( $y, $was['date'], (int) $was['start'] ), 'end_ts' => ogc_vol_ts( $y, $was['date'], (int) $was['end'] ) );
	}
	return null;
}

/** Send one queued email. */
function ogc_vol_send_job( $job ) {
	$y      = (int) $job['year'];
	$GLOBALS['ogc_vol_mail_year'] = $y;
	$p      = (array) ogc_unjson( $job['payload'], array() );
	$email  = $job['email'];
	$shifts = ogc_vol_shifts( $y );
	$ics    = 'volunteer-' . $y . '.ics';
	switch ( $job['kind'] ) {
		case 'confirm':
			$items = array();
			$rids  = array();
			$by    = '';
			foreach ( (array) $p['rids'] as $rid ) {
				$r = ogc_record_get( (int) $rid );
				if ( $r && isset( $shifts[ $r['data']['id'] ] ) && $r['email'] === strtolower( $email ) ) {
					$items[] = array( 'shift' => $shifts[ $r['data']['id'] ], 'name' => $r['data']['name'], 'rid' => (int) $rid );
					$rids[]  = (int) $rid;
					// Added by someone else (Add someone): the email names them, "Daniel H. signed you up".
					if ( ! empty( $r['data']['helper_email'] ) && ! empty( $r['data']['helper'] ) ) {
						$by = ogc_vol_first_l( $r['data']['helper'] );
					}
				}
			}
			if ( ! $items ) {
				return true;
			}
			usort( $items, function ( $a, $b ) {
				return $a['shift']['start_ts'] - $b['shift']['start_ts'];
			} );
			// Each shift once; a household's names beside them when it isn't one person.
			$many  = count( array_unique( wp_list_pluck( $items, 'name' ) ) ) > 1;
			$list  = array_map( function ( $it ) use ( $y, $many ) {
				return ogc_vol_mail_shift( $y, $it['shift'], $many ? strtok( $it['name'], ' ' ) : '' );
			}, $items );
			// Still unconfirmed now (the person may have confirmed through another email meanwhile).
			$ok    = ! empty( $p['confirmed'] ) || ! array_filter( $rids, function ( $rid ) {
				$r = ogc_record_get( $rid );
				return $r && empty( $r['data']['confirmed'] );
			} );
			$first = $items[0]['shift'];
			return ogc_vol_mail( 'vol_confirm', $email, array(
				'shifts'      => $list,
				'confirmed'   => $ok,
				'confirm_url' => $ok ? '' : ogc_vol_confirm_link( $y, $email, $rids ),
				'notme_url'   => ogc_vol_link( $y, 'notme', $email, array( 'r' => $rids ), 30 * DAY_IN_SECONDS ),
				'leave_url'   => $ok ? ogc_vol_leave_link( $y, $email, $rids ) : '',
				'mine_url'    => $ok ? ogc_vol_mine_link( $y, $email ) : '',
				'hours'       => ogc_vol_confirm_hours( $y ),
				'by_head'     => ! empty( $p['by_head'] ) ? $first['committee'] : '',
				'by_name'     => $by,
				'questions'   => ogc_vol_mail_questions( $y, $first['committee'] ),
			), array( 'reply_to' => ogc_vol_reply_to( $y, $first['committee'] ), 'ics' => ogc_vol_ics( $y, $items, 'PUBLISH' ), 'ics_name' => $ics ) );

		case 'left':
			$items = array();
			$head  = false;
			foreach ( (array) $p['items'] as $it ) {
				$rec = (array) $it['rec'];
				$sh  = ogc_vol_shift_of( $y, $rec );
				if ( $sh ) {
					$items[] = array( 'shift' => $sh, 'name' => $rec['data']['name'], 'rid' => (int) $rec['id'] );
					$head    = $head || ! empty( $it['by_head'] );
					$byn     = ! empty( $it['by_name'] ) ? (string) $it['by_name'] : ( isset( $byn ) ? $byn : '' );
				}
			}
			if ( ! $items ) {
				return true;
			}
			$many  = count( array_unique( wp_list_pluck( $items, 'name' ) ) ) > 1;
			$first = $items[0]['shift'];
			return ogc_vol_mail( 'vol_left', $email, array(
				'shifts'    => array_map( function ( $it ) use ( $y, $many ) {
					return ogc_vol_mail_shift( $y, $it['shift'], $many ? strtok( $it['name'], ' ' ) : '' );
				}, $items ),
				'by_head'   => $head,
				'by_name'   => isset( $byn ) ? $byn : '',
				'join_url'  => 1 === count( $items ) ? ogc_vol_page( $y, array( 'shift' => $first['id'] ) ) : ogc_vol_page( $y ),
				'questions' => ogc_vol_mail_questions( $y, $first['committee'] ),
			), array( 'reply_to' => ogc_vol_reply_to( $y, $first['committee'] ), 'ics' => ogc_vol_ics( $y, $items, 'CANCEL' ), 'ics_name' => $ics ) );

		case 'person':
			$rec = $p['rec'];
			$was = isset( $p['extra']['was'] ) ? (array) $p['extra']['was'] : null;
			$sh  = 'removed' === $p['what'] && $was ? ogc_vol_shift_of( $y, array( 'data' => array( 'id' => '' ) ), $was ) : ogc_vol_shift_of( $y, $rec, $was );
			if ( ! $sh ) {
				return true;
			}
			$item = array( array( 'shift' => $sh, 'name' => $rec['data']['name'], 'rid' => (int) $rec['id'] ) );
			$ms   = ogc_vol_mail_shift( $y, $sh );
			$ctx  = array( 'reply_to' => ogc_vol_reply_to( $y, $sh['committee'] ), 'ics_name' => $ics );
			$q    = ogc_vol_mail_questions( $y, $sh['committee'] );
			if ( 'swapped' === $p['what'] ) {
				return ogc_vol_mail( 'vol_replaced', $email, array( 'shifts' => array( $ms ), 'to' => $p['extra']['to'], 'mine_url' => ogc_vol_mine_link( $y, $email ), 'questions' => $q ), $ctx + array( 'ics' => ogc_vol_ics( $y, $item, 'CANCEL' ) ) );
			}
			if ( 'changed' === $p['what'] ) {
				// The set's own: Was and Now.
				$before = $was ? gmdate( 'D, M j', strtotime( $was['date'] . ' UTC' ) ) . ' · ' . ogc_vol_span( (int) $was['start'], (int) $was['end'] ) : '';
				return ogc_vol_mail( 'shift_changed', $email, array( 'title' => $sh['role'], 'before' => $before, 'after' => $ms['when'] . ( $ms['place'] ? ' · ' . $ms['place'] : '' ), 'url' => ogc_vol_mine_link( $y, $email ), 'questions' => $q ), $ctx + array( 'ics' => ogc_vol_ics( $y, $item, 'PUBLISH' ) ) );
			}
			if ( 'removed' === $p['what'] ) {
				return ogc_vol_mail( 'shift_removed', $email, array( 'title' => $sh['role'], 'when' => $ms['when'], 'join_url' => ogc_vol_page( $y, array( 'committee' => $sh['committee'] ) ), 'questions' => $q ), $ctx + array( 'ics' => ogc_vol_ics( $y, $item, 'CANCEL' ) ) );
			}
			if ( 'opened_again' === $p['what'] ) {
				return ogc_vol_mail( 'vol_open_again', $email, array( 'shifts' => array( $ms ), 'join_url' => ogc_vol_page( $y, array( 'shift' => $sh['id'] ) ), 'questions' => $q ), $ctx + array( 'ics' => ogc_vol_ics( $y, $item, 'CANCEL' ) ) );
			}
			if ( 'head_added' === $p['what'] ) {
				return ogc_vol_mail( 'vol_confirm', $email, array( 'shifts' => array( $ms ), 'confirmed' => true, 'by_head' => $sh['committee'], 'mine_url' => ogc_vol_mine_link( $y, $email ), 'leave_url' => ogc_vol_leave_link( $y, $email, array( (int) $rec['id'] ) ), 'notme_url' => ogc_vol_link( $y, 'notme', $email, array( 'r' => array( (int) $rec['id'] ) ), 30 * DAY_IN_SECONDS ), 'questions' => $q ), $ctx + array( 'ics' => ogc_vol_ics( $y, $item, 'PUBLISH' ) ) );
			}
			return true;

		case 'opened':
			$sh = isset( $shifts[ $p['shift'] ] ) ? $shifts[ $p['shift'] ] : null;
			if ( ! $sh || ogc_vol_now() >= $sh['start_ts'] || ! ogc_record_get( (int) $p['wait'] ) ) {
				return true;
			}
			$ms   = ogc_vol_mail_shift( $y, $sh );
			$join = ogc_vol_link( $y, 'opened', $email, array( 's' => array( $sh['id'] ), 'n' => array( $p['name'] ), 'w' => (int) $p['wait'] ), max( HOUR_IN_SECONDS, $sh['start_ts'] - ogc_vol_now() ), array( 'shift' => $sh['id'] ) );
			// The set's own: Join, and Leave waitlist (the same link's card has both).
			return ogc_vol_mail( 'spot_open', $email, array( 'title' => $sh['role'], 'when' => $ms['when'], 'place' => $ms['place'], 'join_url' => $join, 'leave_url' => $join, 'questions' => ogc_vol_mail_questions( $y, $sh['committee'] ) ), array( 'reply_to' => ogc_vol_reply_to( $y, $sh['committee'] ) ) );

		case 'head':
			$sh = isset( $shifts[ $p['shift'] ] ) ? $shifts[ $p['shift'] ] : null;
			if ( ! $sh ) {
				return true;
			}
			$open = ogc_vol_open_count( $y, $sh );
			$x    = (array) $p['extra'];
			$list = ogc_vol_page( $y, array( 'view' => 'lead', 'committee' => $sh['committee'] ) );
			$ms   = ogc_vol_mail_shift( $y, $sh );
			if ( 'late' === $p['what'] ) {
				return ogc_vol_mail( 'volunteer_left', $email, array( 'name' => $x['name'], 'title' => $sh['role'], 'when' => $ms['when'], 'open' => $open, 'needed' => $sh['needed'], 'committee' => $sh['committee'], 'list_url' => $list ) );
			}
			if ( in_array( $p['what'], array( 'swap', 'unconfirmed', 'notme' ), true ) ) {
				return ogc_vol_mail( 'vol_head', $email, array( 'what' => $p['what'], 'name' => isset( $x['name'] ) ? $x['name'] : '', 'phone' => isset( $x['phone'] ) ? ogc_vol_phone_shown( $x['phone'] ) : '', 'from' => isset( $x['from'] ) ? $x['from'] : '', 'to' => isset( $x['to'] ) ? $x['to'] : '', 'open' => null === $open ? '' : $open, 'shifts' => array( $ms ), 'list_url' => $list ) );
			}
			return true;

		case 'message':
			// The head's own words, with this person's own shifts on the committee (what they need most).
			$mine = array();
			foreach ( ogc_vol_seat_map( $y ) as $id => $seats ) {
				$sh = isset( $shifts[ $id ] ) ? $shifts[ $id ] : null;
				if ( ! $sh || $sh['committee'] !== $p['committee'] || ! ogc_vol_message_reaches( (string) ( isset( $p['to'] ) ? $p['to'] : 'all' ), $id, $sh ) ) {
					continue;
				}
				foreach ( $seats as $s ) {
					if ( strtolower( (string) $s['record']['email'] ) === strtolower( $email ) ) {
						$mine[] = array( $sh, $s['record']['data']['name'] );
					}
				}
			}
			usort( $mine, function ( $a, $b ) {
				return $a[0]['start_ts'] - $b[0]['start_ts'];
			} );
			$many = count( array_unique( array_map( function ( $m ) {
				return $m[1];
			}, $mine ) ) ) > 1;
			return ogc_vol_mail( 'vol_message', $email, array(
				'subject'   => $p['subject'],
				'body'      => $p['body'],
				'from'      => isset( $p['from'] ) ? $p['from'] : '',
				'committee' => $p['committee'],
				'shifts'    => array_map( function ( $m ) use ( $y, $many ) {
					return ogc_vol_mail_shift( $y, $m[0], $many ? strtok( $m[1], ' ' ) : '' );
				}, array_slice( $mine, 0, 8 ) ),
				'mine_url'  => ogc_vol_mine_link( $y, $email ),
			), array( 'reply_to' => $p['reply_to'] ) );

		case 'heads':
			return ogc_vol_mail( 'vol_heads', $email, array( 'subject' => $p['subject'], 'body' => $p['body'], 'from' => isset( $p['from'] ) ? $p['from'] : '' ), array( 'reply_to' => $p['reply_to'] ) );

		case 'copy':
			return ogc_vol_mail( 'vol_copy', $email, array( 'subject' => $p['subject'], 'body' => $p['body'], 'sent_to' => isset( $p['sent_to'] ) ? $p['sent_to'] : '' ) );

		case 'remind':
			return ogc_vol_mail( 'vol_remind', $email, array( 'committee' => $p['committee'], 'page_url' => ogc_vol_page( $y, array( 'committee' => $p['committee'] ) ) ), array( 'reply_to' => ogc_vol_reply_to( $y, $p['committee'] ) ) );

		case 'notify':
			return ogc_vol_mail( 'vol_notify', $email, array( 'year' => $y, 'remove_url' => ogc_vol_link( $y, 'unnotify', $email, array(), 400 * DAY_IN_SECONDS ) ) );
	}
	return true;
}

/** Does a head's message (to: all, day:YYYY-MM-DD, shift:<id>) reach this shift? */
function ogc_vol_message_reaches( $to, $id, $sh ) {
	if ( 0 === strpos( $to, 'day:' ) ) {
		return $sh['date'] === substr( $to, 4 );
	}
	if ( 0 === strpos( $to, 'shift:' ) ) {
		return $id === substr( $to, 6 );
	}
	return true;
}

function ogc_vol_open_count( $year, $sh ) {
	global $wpdb;
	if ( $sh['unlimited'] ) {
		return null;
	}
	$n = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM ' . ogc_table( 'vol_seats' ) . ' s JOIN ' . ogc_table( 'records' ) . ' r ON r.id = s.record_id AND r.deleted_at IS NULL WHERE s.year = %d AND s.shift = %s', $year, $sh['id'] ) );
	return max( 0, $sh['needed'] - $n );
}

function ogc_vol_confirm_hours( $year ) {
	$s = ogc_vol_settings( $year );
	// Not let go until the COA chooses a number of hours (question 22): a confirmation lost in spam
	// mustn't cost an older volunteer the place. A reminder goes after a day either way.
	return isset( $s['confirm_hours'] ) && is_numeric( $s['confirm_hours'] ) ? max( 0, (int) $s['confirm_hours'] ) : 0;
}

/* ================================================================== the timed job */

add_filter( 'cron_schedules', function ( $s ) {
	$s['ogc_five_minutes'] = array( 'interval' => 300, 'display' => 'Every five minutes' );
	return $s;
} );
add_action( 'init', function () {
	if ( ! wp_next_scheduled( 'ogc_vol_tick' ) ) {
		wp_schedule_event( time() + 60, 'ogc_five_minutes', 'ogc_vol_tick' );
	}
} );
add_action( 'ogc_vol_tick', 'ogc_vol_tick' );

/** After a request that queued email: run the job when the answer has gone (a busy site doesn't wait
 * for WP-Cron's next visit). */
function ogc_vol_tick_soon() {
	if ( ! empty( $GLOBALS['ogc_vol_tick_soon'] ) ) {
		return;
	}
	$GLOBALS['ogc_vol_tick_soon'] = true;
	add_action( 'shutdown', function () {
		if ( function_exists( 'fastcgi_finish_request' ) ) {
			fastcgi_finish_request();
		}
		ogc_vol_send_due();
	} );
}

/** Only the outbox: what's due now (the rest of the timed work waits for the cron). */
function ogc_vol_send_due() {
	global $wpdb;
	$done = array();
	$t    = ogc_table( 'vol_outbox' );
	$jobs = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM $t WHERE sent_at IS NULL AND send_after <= %s ORDER BY id LIMIT 60", gmdate( 'Y-m-d H:i:s', ogc_vol_now() ) ), ARRAY_A );
	foreach ( (array) $jobs as $job ) {
		// Marked first, so a slow send never goes twice.
		$n = $wpdb->query( $wpdb->prepare( "UPDATE $t SET sent_at = %s WHERE id = %d AND sent_at IS NULL", gmdate( 'Y-m-d H:i:s', ogc_vol_now() ), $job['id'] ) );
		if ( 1 === (int) $n ) {
			ogc_vol_send_job( $job );
			$done[] = $job['kind'];
		}
	}
	return $done;
}

/** What's due: the outbox, then each year's timed emails, the let-go and the clearing. */
function ogc_vol_tick() {
	if ( get_transient( 'ogc_vol_tick_lock' ) && empty( $GLOBALS['ogc_vol_tick_force'] ) ) {
		return array();
	}
	set_transient( 'ogc_vol_tick_lock', 1, 50 );
	$done = ogc_vol_send_due();
	foreach ( ogc_years_list() as $y ) {
		if ( ! ogc_file_get( $y, 'shifts' ) ) {
			continue;
		}
		$done = array_merge( $done, ogc_vol_year_jobs( $y ) );
	}
	delete_transient( 'ogc_vol_tick_lock' );
	return $done;
}

/** One year's timed work. */
function ogc_vol_year_jobs( $y ) {
	$GLOBALS['ogc_vol_mail_year'] = $y;
	$done = array();
	$wall = ogc_vol_wall( $y );
	$last = ogc_vol_last_day( $y );
	$days = ogc_vol_days( $y );
	if ( ! $days ) {
		return $done;
	}
	$first  = $days[0]['date'];
	$shifts = ogc_vol_shifts( $y );
	$ended  = $last && $wall['date'] > $last;

	// Unconfirmed places: one reminder after a day (Confirm first). When the COA has chosen hours
	// (confirm_hours), a place still unconfirmed then opens again, and nobody is left out: the person is
	// told (with Join again), and the head by name and phone.
	$hours = ogc_vol_confirm_hours( $y );
	if ( ! $ended ) {
		$nudge = array();
		foreach ( ogc_records( $y, 'signups' ) as $r ) {
			if ( ! empty( $r['data']['confirmed'] ) || $r['sample'] || empty( $r['email'] ) ) {
				continue;
			}
			$age = ogc_vol_now() - strtotime( $r['created_at'] . ' UTC' );
			if ( $hours > 0 && $age > $hours * HOUR_IN_SECONDS ) {
				ogc_record_delete( $r['id'] );
				ogc_vol_after_leave( $y, $r, 'quiet' );
				if ( isset( $shifts[ $r['data']['id'] ] ) ) {
					$sh = $shifts[ $r['data']['id'] ];
					ogc_vol_change( $y, $sh, 'unconfirmed', $r['data']['name'] );
					ogc_vol_queue_person( $y, $r, 'opened_again' );
					ogc_vol_head_notice( $y, $sh, 'unconfirmed', array( 'name' => ogc_vol_first_l( $r['data']['name'] ), 'phone' => isset( $r['data']['phone'] ) ? $r['data']['phone'] : '' ) );
					ogc_vol_notify_waitlist( $y, $sh );
				}
				$done[] = 'let_go';
			} elseif ( $age > DAY_IN_SECONDS && empty( $r['data']['nudged'] ) && ( $hours <= 0 || $hours * HOUR_IN_SECONDS - $age > 3 * HOUR_IN_SECONDS ) ) {
				$d           = $r['data'];
				$d['nudged'] = gmdate( 'c', ogc_vol_now() );
				ogc_record_update( $r['id'], $d, $r['email'] );
				$nudge[ $r['email'] ][] = (int) $r['id'];
			}
		}
		foreach ( $nudge as $em => $rids ) {
			ogc_vol_queue( $y, 'confirm', $em, array( 'rids' => $rids, 'confirmed' => false, 'nudge' => true ) );
			$done[] = 'nudge';
		}
	}

	if ( ogc_vol_posted( $y ) && ! $ended ) {
		$done = array_merge( $done, ogc_vol_reminders( $y, $wall, $first, $shifts ) );
		$done = array_merge( $done, ogc_vol_weekly( $y, $wall ) );
	}
	if ( ogc_vol_posted( $y ) ) {
		$done = array_merge( $done, ogc_vol_opening( $y ) );
	}
	$s     = ogc_vol_settings( $y );
	$after = isset( $s['clear_after_days'] ) && is_numeric( $s['clear_after_days'] ) ? (int) $s['clear_after_days'] : 60;
	if ( $last && $wall['date'] > gmdate( 'Y-m-d', strtotime( $last . ' UTC' ) + $after * DAY_IN_SECONDS ) && ! ogc_state_get( $y, 'vol-cleared' ) ) {
		ogc_vol_clear_year( $y );
		$done[] = 'cleared';
	}
	ogc_vol_seats_tidy( $y );
	return $done;
}

/** The day before each shift (at 9 AM venue time), one email per person for the next day's shifts; and
 * a week before the Conference, one "Your shifts" email listing them all. Each goes once. */
function ogc_vol_reminders( $y, $wall, $first, $shifts ) {
	$done     = array();
	$tomorrow = gmdate( 'Y-m-d', strtotime( $wall['date'] . ' UTC' ) + DAY_IN_SECONDS );
	$week     = gmdate( 'Y-m-d', strtotime( $first . ' UTC' ) - 7 * DAY_IN_SECONDS );
	$by       = array();
	$all      = array();
	foreach ( ogc_records( $y, 'signups' ) as $r ) {
		$sh = isset( $shifts[ $r['data']['id'] ] ) ? $shifts[ $r['data']['id'] ] : null;
		if ( ! $sh || empty( $r['data']['email'] ) || $r['sample'] || empty( $r['data']['confirmed'] ) || ogc_vol_now() >= $sh['start_ts'] ) {
			continue;
		}
		// "Tomorrow" is the evening before for a shift after midnight (Friday night · 12–2 AM).
		$eve = $sh['start'] < 300 ? gmdate( 'Y-m-d', strtotime( $sh['date'] . ' UTC' ) - DAY_IN_SECONDS ) : $sh['date'];
		if ( $wall['minutes'] >= 540 && $eve === $tomorrow && empty( $r['data']['reminded'] ) ) {
			$by[ $r['email'] ][] = $r;
		}
		if ( $wall['date'] >= $week && $wall['minutes'] >= 540 && empty( $r['data']['week_sent'] ) ) {
			$all[ $r['email'] ][] = $r;
		}
	}
	$mark = function ( $r, $k ) {
		$d       = $r['data'];
		$d[ $k ] = true;
		ogc_record_update( $r['id'], $d, $r['email'] );
	};
	$listed = function ( $list ) use ( $y, $shifts ) {
		$items = array();
		foreach ( $list as $r ) {
			$items[] = array( 'shift' => $shifts[ $r['data']['id'] ], 'name' => $r['data']['name'], 'rid' => (int) $r['id'] );
		}
		usort( $items, function ( $a, $b ) {
			return $a['shift']['start_ts'] - $b['shift']['start_ts'];
		} );
		$many = count( array_unique( wp_list_pluck( $items, 'name' ) ) ) > 1;
		return array( $items, array_map( function ( $it ) use ( $y, $many ) {
			return ogc_vol_mail_shift( $y, $it['shift'], $many ? strtok( $it['name'], ' ' ) : '' );
		}, $items ) );
	};
	foreach ( $all as $email => $list ) {
		array_walk( $list, function ( $r ) use ( $mark ) {
			$mark( $r, 'week_sent' );
		} );
		list( $items, $ms ) = $listed( $list );
		ogc_vol_mail( 'vol_week', $email, array( 'shifts' => $ms, 'mine_url' => ogc_vol_mine_link( $y, $email ), 'leave_url' => ogc_vol_leave_link( $y, $email, wp_list_pluck( $items, 'rid' ) ) ), array( 'ics' => ogc_vol_ics( $y, $items, 'PUBLISH' ), 'ics_name' => 'volunteer-' . $y . '.ics' ) );
		$done[] = 'week';
	}
	foreach ( $by as $email => $list ) {
		array_walk( $list, function ( $r ) use ( $mark ) {
			$mark( $r, 'reminded' );
		} );
		list( $items, $ms ) = $listed( $list );
		$sh    = $items[0]['shift'];
		$leave = ogc_vol_leave_link( $y, $email, wp_list_pluck( $items, 'rid' ) );
		$q     = ogc_vol_mail_questions( $y, $sh['committee'] );
		$ctx   = array( 'reply_to' => ogc_vol_reply_to( $y, $sh['committee'] ) );
		if ( 1 === count( $items ) ) {
			// The set's own: Directions, and Can't make it? Leave shift.
			ogc_vol_mail( 'reminder', $email, array( 'title' => $sh['role'], 'when' => $ms[0]['when'], 'place' => $ms[0]['place'], 'note' => $sh['note'], 'map_url' => $ms[0]['map'], 'leave_url' => $leave, 'url' => ogc_vol_mine_link( $y, $email ), 'questions' => $q ), $ctx );
		} else {
			ogc_vol_mail( 'vol_reminder', $email, array( 'shifts' => $ms, 'mine_url' => ogc_vol_mine_link( $y, $email ), 'leave_url' => $leave, 'questions' => $q ), $ctx );
		}
		$done[] = 'reminder';
	}
	return $done;
}

/** A committee's numbers: places, filled, open, people waiting. */
function ogc_vol_committee_numbers( $y, $committee, $map = null ) {
	$map = null === $map ? ogc_vol_seat_map( $y ) : $map;
	$n   = array( 'needed' => 0, 'filled' => 0, 'open' => 0, 'shifts' => 0, 'short' => array() );
	foreach ( ogc_vol_shifts( $y ) as $id => $sh ) {
		if ( $sh['committee'] !== $committee ) {
			continue;
		}
		$f = isset( $map[ $id ] ) ? count( $map[ $id ] ) : 0;
		$n['shifts']++;
		$n['filled'] += $f;
		if ( ! $sh['unlimited'] ) {
			$n['needed'] += $sh['needed'];
			$o            = max( 0, $sh['needed'] - $f );
			$n['open']   += $o;
			if ( $o && $sh['start_ts'] > ogc_vol_now() ) {
				$n['short'][] = array( $sh, $o );
			}
		}
	}
	return $n;
}

/** Mondays, after 7 AM venue time: each committee's contact hears how it stands and what changed. */
function ogc_vol_weekly( $y, $wall ) {
	$done = array();
	if ( 1 !== (int) gmdate( 'N', strtotime( $wall['date'] . ' UTC' ) ) || $wall['minutes'] < 420 ) {
		return $done;
	}
	$sent = ogc_state_get( $y, 'vol-weekly' );
	$sent = $sent ? (array) $sent['value'] : array();
	$ch   = ogc_state_get( $y, 'vol-changes' );
	$ch   = $ch ? (array) $ch['value'] : array();
	$map  = ogc_vol_seat_map( $y );
	foreach ( ogc_vol_committees( $y ) as $c ) {
		if ( ! is_email( $c['contact_email'] ) || 'no' === strtolower( (string) $c['weekly'] ) || ( isset( $sent[ $c['name'] ] ) && $sent[ $c['name'] ] === $wall['date'] ) ) {
			continue;
		}
		$n     = ogc_vol_committee_numbers( $y, $c['name'], $map );
		$since = gmdate( 'Y-m-d H:i:s', ogc_vol_now() - 7 * DAY_IN_SECONDS );
		$j     = 0;
		$l     = 0;
		foreach ( $ch as $x ) {
			if ( $x['committee'] === $c['name'] && $x['at'] >= $since ) {
				$j += 'joined' === $x['act'] ? 1 : 0;
				$l += in_array( $x['act'], array( 'left', 'unconfirmed', 'notme' ), true ) ? 1 : 0;
			}
		}
		ogc_vol_mail( 'vol_weekly', $c['contact_email'], array(
			'committee'   => $c['name'],
			'filled'      => $n['filled'],
			'needed'      => $n['needed'],
			'open'        => $n['open'],
			'joined'      => $j,
			'left'        => $l,
			'open_shifts' => array_map( function ( $s ) use ( $y ) {
				return array( $s[0]['role'], ogc_vol_when( $y, $s[0] ), $s[1] );
			}, $n['short'] ),
			'list_url'    => ogc_vol_page( $y, array( 'view' => 'lead', 'committee' => $c['name'] ) ),
		) );
		$sent[ $c['name'] ] = $wall['date'];
		$done[]             = 'weekly';
	}
	ogc_state_put( $y, 'vol-weekly', $sent );
	return $done;
}

/** Everyone who asked to hear when the year's sign-ups open (records "notify"; older years kept a
 * list in the state value vol-notify). */
function ogc_vol_notify_list( $y ) {
	$out = array();
	foreach ( ogc_records( $y, 'notify' ) as $r ) {
		$out[ $r['email'] ] = (int) $r['id'];
	}
	$old = ogc_state_get( $y, 'vol-notify' );
	foreach ( $old ? (array) $old['value'] : array() as $e ) {
		if ( is_string( $e ) && is_email( $e ) && ! isset( $out[ strtolower( $e ) ] ) ) {
			$out[ strtolower( $e ) ] = 0;
		}
	}
	return $out;
}

/** When sign-ups open: one email to those who asked, and to last year's volunteers who ticked Next
 * year (their shifts, and Sign up again in one tap). Once. */
function ogc_vol_opening( $y ) {
	global $wpdb;
	if ( ogc_state_get( $y, 'vol-opened-sent' ) ) {
		return array();
	}
	$done = array();
	$back = array();
	$kept = ogc_state_get( $y, 'vol-return' );
	foreach ( $kept ? (array) $kept['value'] : array() as $k ) {
		$back[ $k['email'] ] = true;
	}
	foreach ( ogc_records( $y - 1, 'signups' ) as $r ) {
		if ( ! empty( $r['data']['next_year'] ) && ! $r['sample'] && ! empty( $r['data']['email'] ) ) {
			$back[ strtolower( $r['data']['email'] ) ] = true;
		}
	}
	$asked = ogc_vol_notify_list( $y );
	foreach ( array_unique( array_merge( array_keys( $back ), array_keys( $asked ) ) ) as $email ) {
		$again = isset( $back[ $email ] ) ? ogc_vol_again( $y, $email ) : array();
		$ids   = array_values( array_filter( wp_list_pluck( $again, 'shift' ) ) );
		$names = array();
		foreach ( $again as $a ) {
			$names = array_merge( $names, $a['names'] );
		}
		ogc_vol_mail( 'vol_open', $email, array(
			'year'      => $y,
			'again'     => $ids ? array_values( wp_list_pluck( $again, 'was' ) ) : array(),
			'again_url' => $ids ? ogc_vol_link( $y, 'again', $email, array( 's' => $ids, 'n' => array_values( array_unique( $names ) ) ), 60 * DAY_IN_SECONDS ) : '',
			'page_url'  => ogc_vol_page( $y ),
		) );
		$done[] = 'open';
	}
	ogc_state_put( $y, 'vol-opened-sent', ogc_now() );
	ogc_state_put( $y, 'vol-notify', array() );
	// Sent once: the addresses aren't kept.
	$wpdb->query( $wpdb->prepare( 'DELETE FROM ' . ogc_table( 'records' ) . " WHERE year = %d AND kind = 'notify'", $y ) );
	return $done;
}

/**
 * Names cleared after the Conference (the security plan: 60 days). What's kept: each shift's numbers
 * (needed, filled, waiting at the end, the date it filled) and how many different people helped, for
 * next year's committee; and, for those who ticked Next year, their email, first names and which
 * shifts (no phone), until next year opens. Sample rows are made-up people and stay.
 */
function ogc_vol_clear_year( $y ) {
	global $wpdb;
	$map    = ogc_vol_seat_map( $y );
	$stats  = array();
	$waits  = array();
	foreach ( ogc_records( $y, 'waits' ) as $w ) {
		$waits[ $w['data']['id'] ] = ( isset( $waits[ $w['data']['id'] ] ) ? $waits[ $w['data']['id'] ] : 0 ) + 1;
	}
	foreach ( ogc_vol_shifts( $y ) as $id => $sh ) {
		$on      = isset( $map[ $id ] ) ? $map[ $id ] : array();
		$filled  = '';
		if ( ! $sh['unlimited'] && count( $on ) >= $sh['needed'] ) {
			$at     = array_map( function ( $s ) {
				return ! empty( $s['record']['data']['at'] ) ? gmdate( 'Y-m-d H:i:s', strtotime( $s['record']['data']['at'] ) ) : $s['record']['created_at'];
			}, $on );
			sort( $at );
			$filled = min( substr( $at[ $sh['needed'] - 1 ], 0, 10 ), $sh['date'] );
		}
		$stats[ $id ] = array( 'committee' => $sh['committee'], 'role' => $sh['role'], 'day' => $sh['day'], 'start' => $sh['start'], 'needed' => $sh['unlimited'] ? null : $sh['needed'], 'filled' => count( $on ), 'filled_on' => $filled, 'waiting' => isset( $waits[ $id ] ) ? $waits[ $id ] : 0 );
	}
	ogc_state_put( $y, 'vol-stats', $stats );
	// How many different people helped (a person serving three meals is one), kept as numbers only.
	ogc_state_put( $y, 'vol-people', ogc_vol_people_counts( $y, $map ) );
	$back = array();
	$all  = ogc_vol_shifts( $y );
	foreach ( ogc_records( $y, 'signups' ) as $r ) {
		if ( $r['sample'] || empty( $r['data']['next_year'] ) || empty( $r['data']['email'] ) || ! isset( $all[ $r['data']['id'] ] ) ) {
			continue;
		}
		$sh = $all[ $r['data']['id'] ];
		$e  = strtolower( $r['data']['email'] );
		$w  = preg_split( '/\s+/', trim( $r['data']['name'] ) );
		$back[ $e ]['email']      = $e;
		$back[ $e ]['patterns'][] = array( 'uid' => $sh['uid'], 'committee' => $sh['committee'], 'role' => $sh['role'], 'day' => $sh['day'], 'start' => $sh['start'], 'end' => $sh['end'], 'name' => $w[0] );
	}
	if ( $back ) {
		ogc_state_put( $y + 1, 'vol-return', array_values( $back ) );
	}
	$rt = ogc_table( 'records' );
	$wpdb->query( $wpdb->prepare( "DELETE FROM $rt WHERE year = %d AND kind IN ('signups','waits') AND sample = 0", $y ) );
	ogc_vol_seats_tidy( $y );
	ogc_state_put( $y, 'vol-changes', array() );
	ogc_state_put( $y, 'vol-cleared', ogc_now() );
	ogc_log( 'vol_cleared', $y, 'signups', array( 'kept' => count( $back ) ) );
}

/* ================================================================== local testing */

if ( OGC_DEV ) {
	// A test may set the moment for this request (X-OGC-Now: a Unix time).
	add_filter( 'rest_pre_dispatch', function ( $r, $server, $req ) {
		$n = $req->get_header( 'X-OGC-Now' );
		if ( $n && ctype_digit( (string) $n ) ) {
			ogc_vol_set_now( (int) $n );
		}
		return $r;
	}, 1, 3 );
	add_action( 'rest_api_init', function () {
		// Run the timed job now, at a given moment (send everything queued when all=1). The emails are
		// in the signin area's Mail log (/annual-conference/mail/), the one log of everything sent.
		register_rest_route( OGC_NS, '/vol/dev/tick', array( 'methods' => 'POST', 'callback' => function ( WP_REST_Request $req ) {
			global $wpdb;
			if ( $req->get_param( 'at' ) ) {
				ogc_vol_set_now( (int) $req->get_param( 'at' ) );
			}
			if ( $req->get_param( 'all' ) ) {
				$wpdb->query( 'UPDATE ' . ogc_table( 'vol_outbox' ) . " SET send_after = '2000-01-01 00:00:00' WHERE sent_at IS NULL" ); // phpcs:ignore
			}
			$GLOBALS['ogc_vol_tick_force'] = true;
			return rest_ensure_response( array( 'done' => ogc_vol_tick() ) );
		}, 'permission_callback' => 'ogc_can_webmaster' ) );
	} );
	// The old second log (Oct 10) is gone: its stored bodies held live links.
	add_action( 'init', function () {
		if ( false !== get_option( 'ogc_vol_dev_mail', false ) ) {
			delete_option( 'ogc_vol_dev_mail' );
		}
	} );
}
