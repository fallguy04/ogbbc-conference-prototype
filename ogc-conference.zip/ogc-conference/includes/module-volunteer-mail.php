<?php
/**
 * Volunteer shifts: the emails, the calendar files, and the timed jobs.
 *
 * Every email is one of the set (the signin area's ogc_mail_send_kind, laid out by ogc_mail_compose):
 * the subject as the heading, the shift as a small block (job, day and time, place), one filled button,
 * quiet links under it (Not you? Remove · Leave shift · Directions), and never a raw address in the
 * words (the plain-text twin keeps the links). The set's own kinds are used where they fit one shift
 * (reminder, shift_changed, shift_removed, spot_open, volunteer_left); the rest are this area's vol_*
 * kinds, added to the set through the ogc_mail_template_kind filter (and shown in the Mail log's preview).
 * Replies go to the committee's role address. Locally nothing is sent: the signin area's Mail log keeps it.
 *
 * Sent by the timed job (ogc_vol_tick: every five minutes by WP-Cron, and a real system cron on the
 * live site, see Corey's README), each once:
 *   confirm   after a join. Unconfirmed (a visitor): at once, the one Confirm covering every place still
 *             unconfirmed under that email. Signed in: held two minutes (Undo takes it back) and gathered
 *   left      gathered over two minutes too: one email, one calendar file cancelling each shift
 *   changed, removed, swapped, opened again   to the person, with the calendar event updated or cancelled
 *   opened    a place opened: to everyone waiting, a one-tap Join (the first to tap gets it)
 *   head      to the committee's role address: a late leave (within 48 hours), a swap, "not me"
 *   message   a head's message, one email an address, each shift once with the address's people on it
 * Every email to a volunteer's address takes its shift lines and its reason ("This address is signed up",
 * "This address is their contact", "Leroy is signed up on this address") from ogc_vol_addr(), and names
 * people, never "you" of someone else (after the ninth critic, Oct 16).
 *   reminders the day before at 9 AM venue time; "Your shifts" a week before the Conference
 *   weekly    Mondays, to each committee's contact: how full, what's short, what changed
 *   open      when sign-ups open: those who asked, and last year's volunteers who ticked Next year
 * And: places held for an email never confirmed are let go after settings confirm_hours (0, the
 * default, never); names are cleared settings clear_after_days (default 60) after the Conference,
 * keeping only counts and, for those who asked, their email and last year's shifts.
 */

defined( 'ABSPATH' ) || exit;

/* ================================================================== sending */

/** One designed email (a kind of the set) to one address. */
function ogc_vol_mail( $kind, $to, $data, $ctx = array() ) {
	$to = strtolower( trim( (string) $to ) );
	if ( ! is_email( $to ) ) {
		return false;
	}
	if ( ! function_exists( 'ogc_mail_send_kind' ) ) {
		ogc_log( 'vol_mail_off', 0, $kind, array() );
		return false;
	}
	$data = array_merge( array( 'year' => isset( $GLOBALS['ogc_vol_mail_year'] ) ? (int) $GLOBALS['ogc_vol_mail_year'] : 0 ), (array) $data );
	return (bool) ogc_mail_send_kind( $kind, $to, $data, $ctx );
}

/** Queue an email for the timed job. */
function ogc_vol_queue( $year, $kind, $email, $payload, $delay = 0 ) {
	global $wpdb;
	$wpdb->insert( ogc_table( 'vol_outbox' ), array(
		'year'       => (int) $year,
		'kind'       => $kind,
		'email'      => strtolower( (string) $email ),
		'payload'    => ogc_json( $payload ),
		'send_after' => gmdate( 'Y-m-d H:i:s', ogc_vol_now() + (int) $delay ),
		'created_at' => ogc_now(),
	), array( '%d', '%s', '%s', '%s', '%s', '%s' ) );
	ogc_vol_tick_soon();
}

/**
 * A confirmation. Unconfirmed (someone who typed their email): sent at once, since the page has just
 * said "Check your email". It lists the places not yet in a Confirm email: a second shift joined before
 * the first email was confirmed is the only one in the second email, which says the earlier one's Confirm
 * does it too (after the eighth critic, Oct 16: two emails 6 seconds apart, the second listing the first
 * shift again). Either email's Confirm confirms both: ogc_vol_burst_ids(). Why not hold the first email
 * a few minutes and send one: the page has just said "Check your email", and a held email waits for the
 * timed job, which on ogbbc.org runs only when someone visits (no server cron is known), so it could come
 * many minutes late; sent at once, it's never late and never lost.
 * Signed in: two minutes after the last join (Undo can take it back; six joins in a row are one email).
 */
function ogc_vol_queue_confirm( $year, $email, $rids, $confirmed, $delay = null, $again = false ) {
	global $wpdb;
	if ( ! is_email( $email ) ) {
		return;
	}
	$email = strtolower( $email );
	$delay = null === $delay ? ( $confirmed ? 120 : 0 ) : (int) $delay;
	$rids  = array_map( 'intval', (array) $rids );
	if ( ! $confirmed ) {
		foreach ( ogc_records( $year, 'signups', $email ) as $r ) {
			// Not one an earlier Confirm email already listed (its link confirms this one's burst too); a
			// Resend ($again) lists them all again, as the one email to keep.
			if ( empty( $r['data']['confirmed'] ) && empty( $r['sample'] ) && strtotime( $r['created_at'] . ' UTC' ) > ogc_vol_now() - DAY_IN_SECONDS && ( $again || ! ogc_vol_outbox_sent_for( (int) $r['id'] ) ) ) {
				$rids[] = (int) $r['id'];
			}
		}
		$rids = array_values( array_unique( $rids ) );
	}
	$t   = ogc_table( 'vol_outbox' );
	// Gathered with a waiting one of the same kind only: a person's own signed-in places ("Signed up")
	// never go in one email with places someone typed their address for ("Confirm", after the critic).
	$row = null;
	foreach ( (array) $wpdb->get_results( $wpdb->prepare( "SELECT id, payload FROM $t WHERE year = %d AND kind = 'confirm' AND email = %s AND sent_at IS NULL ORDER BY id DESC LIMIT 5", $year, $email ), ARRAY_A ) as $w ) {
		$wp = (array) ogc_unjson( $w['payload'], array() );
		if ( ! $row && ! empty( $wp['confirmed'] ) === (bool) $confirmed ) {
			$row = $w;
		}
	}
	if ( $row ) {
		$p              = (array) ogc_unjson( $row['payload'], array() );
		$p['rids']      = array_values( array_unique( array_merge( (array) $p['rids'], $rids ) ) );
		$p['again']     = ! empty( $p['again'] ) || $again;
		$p['confirmed'] = ! empty( $p['confirmed'] ) && $confirmed;
		$wpdb->update( $t, array( 'payload' => ogc_json( $p ), 'send_after' => gmdate( 'Y-m-d H:i:s', ogc_vol_now() + $delay ) ), array( 'id' => (int) $row['id'] ), array( '%s', '%s' ), array( '%d' ) );
		if ( ! $delay ) {
			ogc_vol_tick_soon();
		}
		return;
	}
	// Five confirmations an hour to one address at most (a script can't flood an inbox).
	if ( ! ogc_vol_rate( 'confirm|' . $email, 5 ) ) {
		return;
	}
	ogc_vol_queue( $year, 'confirm', $email, array( 'rids' => $rids, 'confirmed' => (bool) $confirmed ) + ( $again ? array( 'again' => true ) : array() ), $delay );
}

/** Was a confirmation for this sign-up already sent? */
function ogc_vol_outbox_sent_for( $rid ) {
	global $wpdb;
	$t = ogc_table( 'vol_outbox' );
	foreach ( (array) $wpdb->get_col( "SELECT payload FROM $t WHERE kind = 'confirm' AND sent_at IS NOT NULL ORDER BY id DESC LIMIT 200" ) as $p ) { // phpcs:ignore -- no input.
		if ( in_array( (int) $rid, array_map( 'intval', (array) ( ogc_unjson( $p, array() )['rids'] ?? array() ) ), true ) ) {
			return true;
		}
	}
	return false;
}

/** Take a sign-up out of any confirmation not yet sent (Undo, Leave). */
function ogc_vol_outbox_drop( $rid ) {
	global $wpdb;
	$t = ogc_table( 'vol_outbox' );
	foreach ( (array) $wpdb->get_results( "SELECT id, payload FROM $t WHERE kind = 'confirm' AND sent_at IS NULL", ARRAY_A ) as $row ) { // phpcs:ignore -- no input.
		$p    = (array) ogc_unjson( $row['payload'], array() );
		$left = array_values( array_diff( array_map( 'intval', (array) $p['rids'] ), array( (int) $rid ) ) );
		if ( count( $left ) === count( (array) $p['rids'] ) ) {
			continue;
		}
		if ( $left ) {
			$p['rids'] = $left;
			$wpdb->update( $t, array( 'payload' => ogc_json( $p ) ), array( 'id' => (int) $row['id'] ), array( '%s' ), array( '%d' ) );
		} else {
			$wpdb->delete( $t, array( 'id' => (int) $row['id'] ), array( '%d' ) );
		}
	}
}

/** An email to one person about one of their sign-ups (left, changed, removed, swapped). Leaving is
 * gathered: a family leaving three shifts in a minute gets one email with one calendar file. */
function ogc_vol_queue_person( $year, $rec, $what, $extra = array() ) {
	global $wpdb;
	if ( empty( $rec['data']['email'] ) || ! empty( $rec['data']['sample'] ) || ! empty( $rec['sample'] ) ) {
		return;
	}
	if ( 'left' !== $what ) {
		// A changed, removed or let-go shift: everyone of one address on it in one email (after the ninth
		// critic, Oct 16: a couple got two "Shift changed" emails, a contact one a person). The COA's save
		// queues them all in one request, so a waiting job of the same address, kind and shift takes it.
		if ( in_array( $what, array( 'changed', 'removed', 'opened_again' ), true ) ) {
			$email = strtolower( (string) $rec['data']['email'] );
			$t     = ogc_table( 'vol_outbox' );
			foreach ( (array) $wpdb->get_results( $wpdb->prepare( "SELECT id, payload FROM $t WHERE year = %d AND kind = 'person' AND email = %s AND sent_at IS NULL ORDER BY id DESC LIMIT 20", $year, $email ), ARRAY_A ) as $row ) {
				$p    = (array) ogc_unjson( $row['payload'], array() );
				$prec = isset( $p['recs'][0] ) ? (array) $p['recs'][0] : ( isset( $p['rec'] ) ? (array) $p['rec'] : array() );
				if ( ( isset( $p['what'] ) ? $p['what'] : '' ) === $what && isset( $prec['data']['id'] ) && $prec['data']['id'] === $rec['data']['id'] ) {
					$p['recs']   = array_merge( isset( $p['recs'] ) ? (array) $p['recs'] : array( $p['rec'] ), array( $rec ) );
					$wpdb->update( $t, array( 'payload' => ogc_json( $p ) ), array( 'id' => (int) $row['id'] ), array( '%s' ), array( '%d' ) );
					return;
				}
			}
		}
		ogc_vol_queue( $year, 'person', $rec['data']['email'], array( 'rec' => $rec, 'what' => $what, 'extra' => $extra ) );
		return;
	}
	// Joined and left again before any email went (a signed-in person's quick change of mind): nothing to say.
	if ( ! ogc_vol_outbox_sent_for( $rec['id'] ) && strtotime( $rec['created_at'] . ' UTC' ) > ogc_vol_now() - 600 && empty( $extra['by_head'] ) ) {
		return;
	}
	$email = strtolower( $rec['data']['email'] );
	$t     = ogc_table( 'vol_outbox' );
	$row   = $wpdb->get_row( $wpdb->prepare( "SELECT id, payload FROM $t WHERE year = %d AND kind = 'left' AND email = %s AND sent_at IS NULL ORDER BY id DESC LIMIT 1", $year, $email ), ARRAY_A );
	$item  = array( 'rec' => $rec, 'by_head' => ! empty( $extra['by_head'] ), 'by_name' => isset( $extra['by_name'] ) ? (string) $extra['by_name'] : '' );
	if ( $row ) {
		$p          = (array) ogc_unjson( $row['payload'], array() );
		$p['items'][] = $item;
		$wpdb->update( $t, array( 'payload' => ogc_json( $p ), 'send_after' => gmdate( 'Y-m-d H:i:s', ogc_vol_now() + 120 ) ), array( 'id' => (int) $row['id'] ), array( '%s', '%s' ), array( '%d' ) );
		return;
	}
	ogc_vol_queue( $year, 'left', $email, array( 'items' => array( $item ) ), 120 );
}

/** A place opened: everyone waiting on the shift hears, each with a one-tap Join. After a person's own
 * Leave, two minutes later ($delay), marked with the sign-up ($left) so its Undo can take it back. */
function ogc_vol_notify_waitlist( $year, $sh, $delay = 0, $left = 0 ) {
	// One email an address, naming everyone of it waiting (after the ninth critic, Oct 16: a couple
	// waiting got two "Place open" emails, neither saying for whom). `waits` and `names` list them all;
	// `wait` and `name` stay the first, as older jobs had them.
	$by = array();
	foreach ( ogc_records( $year, 'waits' ) as $w ) {
		if ( isset( $w['data']['id'] ) && $w['data']['id'] === $sh['id'] && empty( $w['sample'] ) ) {
			$by[ strtolower( (string) $w['email'] ) ][] = $w;
		}
	}
	foreach ( $by as $email => $ws ) {
		ogc_vol_queue( $year, 'opened', $email, array( 'shift' => $sh['id'], 'name' => $ws[0]['data']['name'], 'wait' => (int) $ws[0]['id'], 'names' => array_values( array_map( function ( $w ) {
			return (string) $w['data']['name'];
		}, $ws ) ), 'waits' => array_map( 'intval', wp_list_pluck( $ws, 'id' ) ) ) + ( $left ? array( 'left' => (int) $left ) : array() ), (int) $delay );
	}
}

/** Something the committee's head should hear at once. A committee with no contact yet: kept for the
 * weekly list instead, and logged. */
function ogc_vol_head_notice( $year, $sh, $what, $extra = array(), $delay = 0, $left = 0 ) {
	// The committee's heads as the COA set them on Members (integration, Oct 11), and its role address.
	$c  = ogc_vol_committees( $year );
	$to = array();
	foreach ( ogc_vol_heads_of( $year, $sh['committee'] ) as $h ) {
		$to[ strtolower( $h['email'] ) ] = true;
	}
	$e = isset( $c[ $sh['committee'] ] ) ? $c[ $sh['committee'] ]['contact_email'] : '';
	if ( is_email( $e ) ) {
		$to[ strtolower( $e ) ] = true;
	}
	if ( ! $to ) {
		ogc_log( 'vol_no_contact', $year, $sh['committee'], array( 'what' => $what ) );
		return;
	}
	foreach ( array_keys( $to ) as $e ) {
		ogc_vol_queue( $year, 'head', $e, array( 'shift' => $sh['id'], 'what' => $what, 'extra' => $extra ) + ( $left ? array( 'left' => (int) $left ) : array() ), (int) $delay );
	}
}

/**
 * The day's leaves, for the heads (after the second critic, Oct 15): a leave more than two days before
 * its shift is kept here and sent that evening in one email a committee ("Left today · Transportation":
 * who, which shift, how many open now), to the same people as the at-once notices. Within two days of
 * the shift the head hears at once ("Late"), as before.
 */
function ogc_vol_head_digest_add( $year, $sh, $name, $rid = 0 ) {
	$s   = ogc_state_get( $year, 'vol-head-digest' );
	$v   = $s ? (array) $s['value'] : array();
	$l   = isset( $v['items'] ) ? (array) $v['items'] : array();
	$l[] = array( 'committee' => $sh['committee'], 'shift' => $sh['id'], 'name' => (string) $name, 'at' => ogc_now(), 'rid' => (int) $rid );
	$v['items'] = array_slice( $l, -400 );
	ogc_state_put( $year, 'vol-head-digest', $v );
}

/** From 6 PM venue time, once a day: each committee with leaves waiting gets its one email. */
function ogc_vol_head_digest( $y, $wall ) {
	$s = ogc_state_get( $y, 'vol-head-digest' );
	$v = $s ? (array) $s['value'] : array();
	if ( empty( $v['items'] ) || $wall['minutes'] < 18 * 60 || ( isset( $v['sent'] ) && $v['sent'] === $wall['date'] ) ) {
		return array();
	}
	$by = array();
	foreach ( (array) $v['items'] as $it ) {
		$by[ $it['committee'] ][] = $it;
	}
	$shifts = ogc_vol_shifts( $y );
	$done   = array();
	foreach ( $by as $c => $items ) {
		$sh = null;
		foreach ( $items as $it ) {
			$sh = $sh ? $sh : ( isset( $shifts[ $it['shift'] ] ) ? $shifts[ $it['shift'] ] : null );
		}
		if ( $sh ) {
			ogc_vol_head_notice( $y, $sh, 'digest', array( 'items' => array_values( $items ) ) );
			$done[] = 'digest';
		}
	}
	ogc_state_put( $y, 'vol-head-digest', array( 'items' => array(), 'sent' => $wall['date'] ) );
	return $done;
}

// A committee's role address is never held back by the per-address limit: the signin area's
// ogc_mail_cap_exempt() already counts committees.csv contact_email as a role address.

/* ================================================================== the words */

function ogc_vol_year_title( $year ) {
	return $year . ' Annual Conference';
}

/** "Fri, May 28" for a subject line (the evening before, for a night shift: as the page says it). The
 * year is the line above the heading, so it isn't repeated here. */
function ogc_vol_subject_day( $year, $sh ) {
	if ( ! empty( $sh['allweek'] ) ) {
		return 'All week';
	}
	$t = strtotime( ogc_vol_eve_date( $sh ) . ' 00:00:00 UTC' );
	// "Fri night, May 28", the page's own words (after the seventh critic, Oct 15: "Fri, May 28 night").
	return gmdate( 'D', $t ) . ( ogc_vol_is_night( $sh ) ? ' night' : '' ) . gmdate( ', M j', $t );
}

/** A shift said short, by its weekday (the Conference has one of each): "Sat 3–7 PM", "Fri night 12–2 AM",
 * "All week". The head's "who left" line (after the fourth critic, Oct 15). */
function ogc_vol_shift_short( $year, $sh ) {
	if ( ! empty( $sh['allweek'] ) ) {
		return 'All week';
	}
	$t = strtotime( ogc_vol_eve_date( $sh ) . ' 00:00:00 UTC' );
	return gmdate( 'D', $t ) . ( ogc_vol_is_night( $sh ) ? ' night' : '' ) . ' ' . ogc_vol_span_of( $sh );
}

/** A plugin address with every query value encoded: ogc_url (add_query_arg) leaves them raw, and a
 * space in "Dining hall" ends the link in most mail programs. */
function ogc_vol_url( $path, $args = array() ) {
	return ogc_url( $path, array_map( 'rawurlencode', array_map( 'strval', $args ) ) );
}

/** The emailed Confirm link. Signing in is the signin area's: its single-use link (kept in its tokens
 * table, so a forwarded email can't sign in twice) confirms these sign-ups as it signs in, then opens the
 * page (ogc_signed_in). For an address a link may not sign in (an editor's or admin's), the link only
 * confirms the sign-ups (an opaque vol_confirm token) and signs no one in. */
function ogc_vol_confirm_link( $year, $email, $rids ) {
	if ( function_exists( 'ogc_signin_link_for' ) && function_exists( 'ogc_email_may_signin' ) && ogc_email_may_signin( $email ) ) {
		// How many shifts (a couple's one shift is one), for the page's "Confirmed" line; it opens on their
		// committee's shifts when they're all one committee's, so the shift shows as theirs right there.
		$coms   = array();
		$shifts = ogc_vol_shifts( $year );
		foreach ( array_map( 'intval', (array) $rids ) as $rid ) {
			$r = ogc_record_get( $rid );
			if ( $r && isset( $shifts[ $r['data']['id'] ] ) ) {
				$coms[ $shifts[ $r['data']['id'] ]['committee'] ] = true;
			}
		}
		$args = array( 'confirmed' => max( 1, ogc_vol_shift_count( $rids ) ) );
		if ( 1 === count( $coms ) ) {
			$args['committee'] = (string) key( $coms );
		}
		$back = wp_parse_url( ogc_vol_page( $year, $args ) );
		return ogc_signin_link_for( $email, $back['path'] . '?' . $back['query'], 'confirm', array( 'vol' => array( 'y' => (int) $year, 'r' => array_map( 'intval', $rids ) ) ), ogc_vol_confirm_ttl( $year ) );
	}
	return ogc_vol_link( $year, 'confirm', $email, array( 'r' => array_values( $rids ) ), ogc_vol_confirm_ttl( $year ) );
}

/** A link to the page that carries an opaque token (nothing in the address says who or what). */
function ogc_vol_link( $year, $act, $email, $data, $ttl, $args = array() ) {
	$t = ogc_vol_token( array_merge( array( 'a' => $act, 'y' => (int) $year, 'e' => $email ), $data ), $ttl );
	return $t ? ogc_vol_page( $year, array_merge( $args, array( 't' => $t ) ) ) : '';
}

/** The Confirm link lasts as long as the place does: the COA's hours when it lets places go, else a
 * week (Resend sends a new one). */
function ogc_vol_confirm_ttl( $year ) {
	$h = ogc_vol_confirm_hours( $year );
	return $h > 0 ? $h * HOUR_IN_SECONDS : 7 * DAY_IN_SECONDS;
}

/** The page's address. */
function ogc_vol_page( $year, $args = array() ) {
	return ogc_vol_url( 'volunteer', array_merge( array( 'year' => (int) $year ), $args ) );
}

function ogc_vol_signups_url( $year ) {
	return ogc_vol_url( 'register', array( 'year' => (int) $year, 'view' => 'mine' ) );
}

/** Your sign-ups, as an email links it: the signin area's one-tap link (it signs in on that device). */
function ogc_vol_mine_link( $year, $email ) {
	return function_exists( 'ogc_mine_url' ) ? ogc_mine_url( $email, $year ) : ogc_vol_signups_url( $year );
}

/** The emailed Leave link for some sign-ups: good until the last of their shifts ends. */
function ogc_vol_leave_link( $year, $email, $rids ) {
	$shifts = ogc_vol_shifts( $year );
	$until  = ogc_vol_now() + HOUR_IN_SECONDS;
	foreach ( (array) $rids as $rid ) {
		$r = ogc_record_get( (int) $rid );
		if ( $r && isset( $shifts[ $r['data']['id'] ] ) ) {
			$until = max( $until, $shifts[ $r['data']['id'] ]['end_ts'] );
		}
	}
	return ogc_vol_link( $year, 'leave', $email, array( 'r' => array_map( 'intval', array_values( (array) $rids ) ) ), $until - ogc_vol_now() );
}

/** A shift as the emails show it: what, when (with the venue's zone), where, Directions. */
function ogc_vol_mail_shift( $y, $sh, $name = '' ) {
	$zone = function_exists( 'ogc_mail_zone' ) ? ogc_mail_zone( $y ) : '';
	// All week: the days it covers in place of a time ("All week · Fri, May 28 – Tue, Jun 1").
	$span = ! empty( $sh['allweek'] ) ? ogc_vol_week_range( $sh ) : ogc_vol_span( $sh['start'], $sh['end'] ) . ( $zone ? ' ' . $zone : '' );
	return array(
		// "First Aid", not "First aid", when the job's words are the committee's (after the ninth critic).
		'title'     => ogc_vol_role_shown( $sh['role'], $sh['committee'] ),
		'committee' => $sh['committee'],
		'day'       => ogc_vol_subject_day( $y, $sh ),
		'span'      => $span,
		'when'      => ogc_vol_subject_day( $y, $sh ) . ' · ' . $span,
		'place'     => $sh['place_name'],
		'note'      => $sh['note'],
		'name'      => $name,
		// The committee's one line for every shift (Helpers › Instruction), said once per committee.
		'instruction' => ogc_vol_instruction( $y, $sh['committee'] ),
		'map'       => '' !== (string) $sh['place'] ? ogc_vol_url( 'guide', array( 'year' => (int) $y, 'view' => 'places', 'to' => $sh['place'] ) ) : '',
	);
}

/**
 * People as one line: "Martha Crittenden"; "Martha and Henry Crittenden" (one surname); else "Martha
 * Crittenden and Alex Bowman". $short: first names only ("Martha and Henry").
 */
function ogc_vol_names_words( $names, $short = false ) {
	$names = array_values( array_unique( array_filter( array_map( 'trim', array_map( 'strval', (array) $names ) ), 'strlen' ) ) );
	if ( ! $names ) {
		return '';
	}
	$firsts = array();
	$lasts  = array();
	foreach ( $names as $n ) {
		$w        = preg_split( '/\s+/', $n );
		$firsts[] = $w[0];
		$lasts[]  = count( $w ) > 1 ? $w[ count( $w ) - 1 ] : '';
	}
	$and = function ( $a ) {
		return count( $a ) < 2 ? implode( '', $a ) : implode( ', ', array_slice( $a, 0, -1 ) ) . ' and ' . $a[ count( $a ) - 1 ];
	};
	if ( $short ) {
		return $and( array_values( array_unique( $firsts ) ) );
	}
	if ( 1 === count( $names ) ) {
		return $names[0];
	}
	return 1 === count( array_unique( array_map( 'strtolower', $lasts ) ) ) && '' !== $lasts[0] ? $and( $firsts ) . ' ' . $lasts[0] : $and( $names );
}

/**
 * Sign-ups (each { shift, name, rid, email }) a shift at a time: a couple on one shift is one shift, with
 * both names (after the critic, Oct 15). Each item gains names and rids; sorted by start.
 */
function ogc_vol_group_items( $items ) {
	$out = array();
	foreach ( (array) $items as $it ) {
		$k = $it['shift']['id'] . '|' . strtolower( isset( $it['email'] ) ? (string) $it['email'] : '' );
		if ( ! isset( $out[ $k ] ) ) {
			$out[ $k ] = array_merge( $it, array( 'names' => array(), 'rids' => array() ) );
		}
		$out[ $k ]['names'][] = (string) $it['name'];
		$out[ $k ]['rids'][]  = (int) $it['rid'];
	}
	$out = array_values( $out );
	usort( $out, function ( $a, $b ) {
		return $a['shift']['start_ts'] - $b['shift']['start_ts'];
	} );
	return $out;
}

/** Every sign-up id in grouped items. */
function ogc_vol_rids_of( $groups ) {
	$out = array();
	foreach ( (array) $groups as $g ) {
		$out = array_merge( $out, isset( $g['rids'] ) ? (array) $g['rids'] : array( (int) $g['rid'] ) );
	}
	return array_values( array_unique( array_map( 'intval', $out ) ) );
}

/** A shift's calendar event for one email: the same UID in every email and in the page's own file, so
 * a couple's shift is one event, updated or cancelled in place (never a name: servers keep the UID). */
function ogc_vol_cal_uid( $email, $shift_id ) {
	return 'ogc-vol-' . substr( md5( strtolower( trim( (string) $email ) ) . '|' . $shift_id ), 0, 16 ) . '@ogbbc.org';
}

/** The shifts' lines for an email: one a shift, the people on it named ("Martha and Henry Crittenden"). */
function ogc_vol_mail_list( $y, $groups ) {
	return array_map( function ( $g ) use ( $y ) {
		return ogc_vol_mail_shift( $y, $g['shift'], ogc_vol_names_words( $g['names'] ) );
	}, $groups );
}

/* ================================================================== who's on it, and why it came */

/**
 * A sign-up as the address it's under holds it (after the ninth critic, Oct 16): 'contact' when the
 * address only signed them up and isn't on the shift ("For someone else": `via`); 'own' when it's the
 * address's own person (no one else signed them up under it: no `for`; or added by someone else under
 * their own email, Add someone's `helper_email`); 'other' for anyone else on it (Leroy, whom Martha
 * signed up with herself under her address; someone a head added). Mechanical: the record's fields only.
 */
function ogc_vol_addr_role( $rec ) {
	$d = isset( $rec['data'] ) ? (array) $rec['data'] : array();
	if ( ! empty( $d['via'] ) ) {
		return 'contact';
	}
	return empty( $d['for'] ) || ! empty( $d['helper_email'] ) ? 'own' : 'other';
}

/**
 * The people of one address on an email's shifts, and the one reason that's true of them: every
 * volunteer email to a volunteer's address takes its shift lines and its reason from here (after the
 * ninth critic, Oct 16: a head's message told Rachel, who only signed the Brubakers up, "Your shifts" and
 * "You're signed up with the Food committee" and listed one shift four times, once a Brubaker; Martha,
 * who had left, got "Your shift" while only Leroy was on it; reminders to Martha's address said "This
 * address is signed up" when only Leroy was).
 *
 *   $items  this address's sign-ups the email is about, each { shift, name, rid, email, rec? } (rec, the
 *           record, when it's gone: a leave keeps it in the payload). Tense 'is': those on the shifts now;
 *           'was': those that came off (left, removed, replaced, let go); 'signed': a Confirm email's.
 *   $by     who put them on, for 'signed': array( 'head' => committee ) or array( 'name' => 'Daniel M.' ).
 * Gives:
 *   groups  each shift once, by start, with the names of this address's people on it (ogc_vol_group_items)
 *   shifts  the same as the emails show them (ogc_vol_mail_shift; 'name' = "Martha and Leroy Yoder")
 *   reason  the footer's why: ogc_vol_addr_reason()
 *   names   everyone's names; who  the same as words, first names ("Martha and Leroy")
 */
function ogc_vol_addr( $y, $email, $items, $tense = 'is', $by = array() ) {
	$own     = false;
	$contact = false;
	$others  = array();
	$names   = array();
	$clean   = array();
	foreach ( (array) $items as $it ) {
		$rec = isset( $it['rec'] ) ? (array) $it['rec'] : ( ! empty( $it['rid'] ) ? ogc_record_get( (int) $it['rid'] ) : null );
		$r   = $rec ? ogc_vol_addr_role( $rec ) : 'own';
		$own     = $own || 'own' === $r;
		$contact = $contact || 'contact' === $r;
		if ( 'other' === $r ) {
			$others[] = (string) $it['name'];
		}
		$names[] = (string) $it['name'];
		unset( $it['rec'] );
		$it['email'] = isset( $it['email'] ) && '' !== (string) $it['email'] ? strtolower( (string) $it['email'] ) : strtolower( (string) $email );
		$clean[]     = $it;
	}
	$groups = ogc_vol_group_items( $clean );
	$names  = array_values( array_unique( $names ) );
	return array(
		'groups' => $groups,
		'shifts' => ogc_vol_mail_list( $y, $groups ),
		'reason' => ogc_vol_addr_reason( $own, $others, $contact, 1 === count( $groups ), $tense, $by ),
		'names'  => $names,
		'who'    => ogc_vol_names_words( $names, true ),
		'own'    => $own,
		'contact' => $contact,
	);
}

/**
 * Why an email came to an address, true of the people on it (ogc_vol_addr()):
 *   own on it          "This address is signed up for this shift." ("…, or their contact, …" with a contact too)
 *   a contact only     "This address is their contact." (the shift lines name them)
 *   someone else only  "Leroy is signed up on this address." ("Leroy and Ruth are …")
 * 'was' says the same of those that came off ("This address was signed up for this shift."); 'signed'
 * says how the places were made, for a Confirm email ("This address signed up to help.", "This address
 * signed others up to help.", "The Ushers foreman added this address.", "Daniel M. added this address.").
 */
function ogc_vol_addr_reason( $own, $others, $contact, $one, $tense = 'is', $by = array() ) {
	$what = $one ? 'this shift' : 'these shifts';
	if ( 'signed' === $tense ) {
		if ( ! empty( $by['head'] ) ) {
			return 'The ' . $by['head'] . ' foreman added this address.';
		}
		if ( ! empty( $by['name'] ) ) {
			return ogc_mail_safe_name( $by['name'] ) . ' added this address.';
		}
		return $contact && ! $own && ! $others ? 'This address signed others up to help.' : 'This address signed up to help.';
	}
	$was    = 'was' === $tense;
	$is     = $was ? 'was' : 'is';
	$others = array_values( array_unique( array_filter( array_map( 'strval', (array) $others ), 'strlen' ) ) );
	if ( $own ) {
		return 'This address ' . $is . ' signed up' . ( $contact ? ', or their contact,' : '' ) . ' for ' . $what . '.';
	}
	if ( $others ) {
		$firsts = array_values( array_unique( array_map( function ( $n ) {
			return preg_split( '/\s+/', trim( $n ) )[0];
		}, $others ) ) );
		$verb   = count( $firsts ) > 1 ? ( $was ? 'were' : 'are' ) : $is;
		return ogc_vol_names_words( $others, true ) . ' ' . $verb . ' signed up on this address' . ( $contact ? ', and it’s a contact for others' : '' ) . '.';
	}
	return $contact ? 'This address ' . $is . ' their contact.' : 'This address ' . $is . ' signed up for ' . $what . '.';
}

/** "Jane’s", "Martha and Leroy’s": a place said as whose it was (a swap taken). */
function ogc_vol_whose( $names ) {
	$w = ogc_vol_names_words( $names, true );
	return '' === $w ? '' : $w . '’s';
}

/**
 * Each shift as the emails show it, with who of the same email is still on it after some left
 * ("still" => "Walter", "Walter and Ruth"; empty when no one is). After the second critic (Oct 15): one of
 * two leaving said "The calendar event is cancelled" while the other was still on it.
 */
function ogc_vol_with_still( $y, $groups ) {
	$list = ogc_vol_mail_list( $y, $groups );
	foreach ( array_values( $groups ) as $i => $g ) {
		$rids = array_map( 'intval', isset( $g['rids'] ) ? (array) $g['rids'] : array( (int) $g['rid'] ) );
		$ns   = array();
		foreach ( '' !== (string) $g['email'] ? ogc_records( $y, 'signups', strtolower( (string) $g['email'] ) ) : array() as $r ) {
			if ( isset( $r['data']['id'] ) && $r['data']['id'] === $g['shift']['id'] && ! in_array( (int) $r['id'], $rids, true ) ) {
				$ns[] = (string) $r['data']['name'];
			}
		}
		$list[ $i ]['still']   = ogc_vol_names_words( $ns, true );
		$list[ $i ]['still_n'] = count( array_unique( $ns ) );
	}
	return $list;
}

/** "Walter is still on it." for one shift; "Walter is still on Server · Sat, May 29." for several. */
function ogc_vol_still_lines( $shifts ) {
	$shifts = array_values( (array) $shifts );
	$out    = array();
	foreach ( $shifts as $s ) {
		if ( ! empty( $s['still'] ) ) {
			$out[] = $s['still'] . ( (int) $s['still_n'] > 1 ? ' are' : ' is' ) . ' still on ' . ( 1 === count( $shifts ) ? 'it' : $s['title'] . ' · ' . $s['day'] ) . '.';
		}
	}
	return $out;
}

/** What happened to the calendar after some left: cancelled, updated (someone is still on it), or both. */
function ogc_vol_cal_after_left( $shifts ) {
	$shifts = array_values( (array) $shifts );
	$kept   = count( array_filter( $shifts, function ( $s ) {
		return ! empty( $s['still'] );
	} ) );
	$one    = 1 === count( $shifts );
	if ( ! $kept ) {
		return 'The calendar ' . ( $one ? 'event is' : 'events are' ) . ' cancelled (file attached).';
	}
	return $kept === count( $shifts ) ? 'The calendar ' . ( $one ? 'event is' : 'events are' ) . ' updated (file attached).' : 'The calendar events are changed (file attached).';
}

/** The same words, apart from capitals, spaces and punctuation (a shift's note that only repeats its
 * committee's instruction is said once). */
function ogc_vol_same_words( $a, $b ) {
	$n = function ( $s ) {
		return preg_replace( '/[^a-z0-9]+/', '', strtolower( (string) $s ) );
	};
	return '' !== $n( $a ) && $n( $a ) === $n( $b );
}

/** Questions go to the committee: its role phone, and replies to its role address. */
function ogc_vol_mail_questions( $year, $committee ) {
	$p = ogc_vol_role_phone( $year, $committee );
	$r = ogc_vol_reply_to( $year, $committee );
	return trim( ( $p ? $p : '' ) . ( $p && $r ? ' · ' : '' ) . ( $r ? 'Reply to this email' : '' ) );
}

/** A person's own address, never a role's: anyone on the year's members list (they sign in with it), or
 * a committee's head in committees.csv. */
function ogc_vol_is_person_email( $year, $email ) {
	$email = strtolower( trim( (string) $email ) );
	if ( '' === $email ) {
		return false;
	}
	if ( function_exists( 'ogc_member_find' ) && ogc_member_find( (int) $year, $email, true ) ) {
		return true;
	}
	foreach ( ogc_vol_committees( $year ) as $c ) {
		if ( in_array( $email, array_map( 'strtolower', array_map( 'trim', explode( '|', (string) $c['heads'] ) ) ), true ) ) {
			return true;
		}
	}
	return false;
}

/**
 * Where a volunteer's reply goes: the committee's role address (committees.csv contact_email) when it
 * is one; else the coordinating role, the year's volunteering contact (settings contact_helping); else
 * the webmasters' Replies to. Never a person's own address (contacts by role; after the critic, Oct 15).
 * '' when there is none: the email then promises no reader.
 */
function ogc_vol_reply_to( $year, $committee ) {
	$c = ogc_vol_committees( $year );
	$e = isset( $c[ $committee ] ) ? trim( (string) $c[ $committee ]['contact_email'] ) : '';
	if ( is_email( $e ) && ! ogc_vol_is_person_email( $year, $e ) ) {
		return $e;
	}
	$s = ogc_vol_settings( $year );
	$h = isset( $s['contact_helping'] ) ? trim( (string) $s['contact_helping'] ) : '';
	if ( is_email( $h ) && ! ogc_vol_is_person_email( $year, $h ) ) {
		return $h;
	}
	$w = function_exists( 'ogc_mail_reply_default' ) ? ogc_mail_reply_default() : '';
	return is_email( $w ) ? $w : '';
}

/* ================================================================== the set's vol_* kinds */

add_filter( 'ogc_mail_kinds', function ( $k ) {
	return array_merge( (array) $k, array(
		'vol_confirm'     => 'Volunteer · Confirm your place, or Signed up',
		'vol_left'        => 'Volunteer · Left shift (gathered)',
		'vol_replaced'    => 'Volunteer · Replaced (a swap taken)',
		'vol_open_again'  => 'Volunteer · Place open again (not confirmed)',
		'vol_reminder'    => 'Volunteer · Tomorrow (each shift once, its people named)',
		'vol_week'        => 'Volunteer · Next week (every shift)',
		'vol_message'     => 'Volunteer · A head’s message',
		'vol_heads'       => 'Volunteer · Message to every committee’s heads',
		'vol_copy'        => 'Volunteer · Copy of a message',
		'vol_head'        => 'Volunteer · Notice to a committee (swap, unconfirmed, not me, the day’s leaves)',
		'vol_weekly'      => 'Volunteer · This week (to the committee)',
		'vol_remind'      => 'Volunteer · Dorm shifts (Young Folks parents)',
		'vol_open'        => 'Volunteer · Sign-ups open',
		'vol_notify'      => 'Volunteer · Email me when it opens',
	) );
} );
// Their subjects carry a volunteer's name or a head's own words: the live site's log keeps the label only.
add_filter( 'ogc_mail_private_kinds', function ( $k ) {
	return array_merge( (array) $k, array( 'vol_head', 'vol_message', 'vol_heads', 'vol_copy' ) );
} );

/** One shift's facts (When, Where, Committee; Who for someone else), or one line a shift for several. */
function ogc_vol_mail_facts( $shifts ) {
	$shifts = array_values( (array) $shifts );
	if ( 1 === count( $shifts ) ) {
		$s = $shifts[0];
		return array(
			array( 'Who', $s['name'] ),
			array( 'When', $s['when'] ),
			array( 'Where', $s['place'] ),
			// Always its own line (after the ninth critic, Oct 16: the Preteen helper's had none, by the
			// round-4 rule meant for one line, "Usher · Ushers"); only a job that is the committee's name
			// ("First Aid") doesn't say it twice.
			array( 'Committee', ogc_vol_same_words( $s['title'], $s['committee'] ) ? '' : $s['committee'] ),
		);
	}
	// One line a shift, its people named after it ("Server · 3:45–7 PM · Martha and Henry Crittenden").
	$f = array();
	foreach ( $shifts as $s ) {
		$f[] = array( $s['day'], $s['title'] . ' · ' . $s['span'] . ( $s['name'] ? ' · ' . $s['name'] : '' ) . ( $s['place'] ? "\n" . $s['place'] : '' ) );
	}
	return $f;
}

/** "Golf cart driver · Fri, May 28", or "3 shifts". */
function ogc_vol_mail_what( $shifts ) {
	$shifts = array_values( (array) $shifts );
	return 1 === count( $shifts ) ? $shifts[0]['title'] . ' · ' . $shifts[0]['day'] : count( $shifts ) . ' shifts';
}

add_filter( 'ogc_mail_template_kind', 'ogc_vol_mail_template', 10, 4 );

/** The vol_* kinds, laid out by the set's own ogc_mail_compose. */
function ogc_vol_mail_template( $m, $kind, $d, $base ) {
	if ( $m || 0 !== strpos( (string) $kind, 'vol_' ) || ! function_exists( 'ogc_mail_compose' ) ) {
		return $m;
	}
	$g      = function ( $k, $def = '' ) use ( $d ) {
		return isset( $d[ $k ] ) && '' !== $d[ $k ] && null !== $d[ $k ] ? $d[ $k ] : $def;
	};
	$shifts = array_values( array_filter( (array) $g( 'shifts', array() ), 'is_array' ) );
	$one    = 1 === count( $shifts );
	$first  = $shifts ? $shifts[0] : array( 'title' => '', 'committee' => '', 'note' => '', 'map' => '', 'when' => '', 'place' => '', 'day' => '', 'span' => '', 'name' => '' );
	$map    = $one && $first['map'] ? array( '', 'Directions', $first['map'] ) : ( $shifts ? array( '', 'Campus map', ogc_vol_url( 'guide', array( 'year' => (int) $g( 'year' ), 'view' => 'places' ) ) ) : '' );
	// Each committee's one instruction, once ("Be in the chapel 30 minutes before…"); the committee
	// named before it when the email covers several.
	$instr  = array();
	foreach ( $shifts as $s ) {
		if ( ! empty( $s['instruction'] ) ) {
			$instr[ $s['committee'] ] = $s['instruction'];
		}
	}
	$coms   = array_unique( wp_list_pluck( $shifts, 'committee' ) );
	$instr  = array_map( function ( $c, $t ) use ( $coms ) {
		return count( $coms ) > 1 ? $c . ' · ' . $t : $t;
	}, array_keys( $instr ), array_values( $instr ) );
	$a      = null;
	switch ( $kind ) {
		case 'vol_confirm':
			$ok   = (bool) $g( 'confirmed' );
			// The one reminder a day on, for a place still unconfirmed (after the sixth critic, Oct 15: it read
			// as the same email twice): "Still to confirm · Preteen helper · Fri, May 28".
			// "Confirm the places" when the address's own person isn't on them (a contact's, or Esther's that
			// Daniel made under her address): never "your" of someone else (after the ninth critic, Oct 16).
			$many = ! $one || count( array_filter( array_map( 'trim', preg_split( '/,| and /', (string) $first['name'] ) ) ) ) > 1;
			$subj = ( $ok ? 'Signed up · ' : ( $g( 'nudge' ) ? 'Still to confirm · ' : ( $g( 'theirs' ) ? ( $many ? 'Confirm the places · ' : 'Confirm the place · ' ) : ( $one ? 'Confirm your place · ' : 'Confirm your places · ' ) ) ) ) . ogc_vol_mail_what( $shifts );
			// Who was signed up, by name, never "you" (after the ninth critic, Oct 16): the head or the person
			// who added them may have used a household's shared address.
			$whom = (string) $g( 'who', 'this address' );
			$a    = array(
				'subject'   => $subj,
				'heading'   => $subj,
				'preheader' => $ok ? $first['when'] : 'One tap confirms it',
				'facts'     => ogc_vol_mail_facts( $shifts ),
				'lines'     => array_values( array_filter( array_merge( array( $g( 'by_head' ) ? 'The ' . $g( 'by_head' ) . ' foreman signed ' . $whom . ' up.' : ( $g( 'by_name' ) ? ogc_mail_safe_name( $g( 'by_name' ) ) . ' signed ' . $whom . ' up.' : ( $g( 'via_for' ) ? 'This address is their contact.' : '' ) ) ),
					// A second sign-up before the first was confirmed (after the eighth critic, Oct 16).
					array( ! $ok && $g( 'earlier' ) ? 'The Confirm in your earlier email confirms ' . ( $one ? 'this one' : 'these' ) . ' too.' : '' ), $instr, array( $one && ! ogc_vol_same_words( (string) $first['note'], isset( $first['instruction'] ) ? (string) $first['instruction'] : '' ) ? wp_strip_all_tags( (string) $first['note'] ) : '' ) ) ) ),
				// One button: Confirm while it needs a tap, else Your sign-ups.
				'button'    => $ok ? array( 'Your sign-ups', $g( 'mine_url' ) ) : array( 'Confirm', $g( 'confirm_url' ) ),
				// A first-timer's only email (after the second critic, Oct 15): Your sign-ups and Leave
				// shift are here from the start, so weeks later it still has a way in and a way out (they
				// work once the place is confirmed; Leave shift works by its own link either way).
				'after'     => array(
					! $ok && (int) $g( 'hours' ) > 0 ? 'Unconfirmed places open again after ' . (int) $g( 'hours' ) . ' hours.' : '',
					// Both reminders named when both go (after the third critic, Oct 15): ogc_vol_remind_words().
					trim( ( $g( 'has_ics' ) ? 'Calendar file attached. ' : '' ) . (string) $g( 'reminders' ) ),
					$map,
					$ok ? '' : array( '', 'Your sign-ups', $g( 'mine_url' ) ),
					array( 'Can’t make it?', 'Leave shift', $g( 'leave_url' ) ),
				),
				// ogc_vol_addr_reason( …, 'signed' ): how the places were made.
				'reason'    => $g( 'reason' ) ? $g( 'reason' ) : ( $g( 'by_head' ) ? 'The ' . $g( 'by_head' ) . ' foreman added this address.' : ( $g( 'by_name' ) ? ogc_mail_safe_name( $g( 'by_name' ) ) . ' added this address.' : ( $g( 'via_for' ) ? 'This address signed others up to help.' : 'This address signed up to help.' ) ) ),
				// For someone who never signed up, beside why it came, never next to Leave shift: it removes
				// every place in this email (a couple's both), so it isn't a way out of a shift.
				'reason_link' => array( $g( 'by_name' ) || $g( 'by_head' ) ? 'Not you?' : 'Didn’t sign up?', 'Remove this address', $g( 'notme_url' ) ),
			);
			break;

		case 'vol_left':
			$head = (bool) $g( 'by_head' );
			// Taken off by the person who added them (Add someone): said so, by name.
			$byn  = $head ? '' : (string) $g( 'by_name' );
			$subj = ( $head || $byn ? 'Removed · ' : 'Left shift · ' ) . ogc_vol_mail_what( $shifts );
			// Who came off, by name (after the ninth critic, Oct 16: "took you off" to a household's address).
			$whom = (string) $g( 'who', 'this address' );
			$a    = array(
				'subject' => $subj,
				'heading' => $subj,
				'facts'   => ogc_vol_mail_facts( $shifts ),
				'lines'   => array_merge( array( $head ? 'The ' . $first['committee'] . ' foreman took ' . $whom . ' off ' . ( $one ? 'this shift' : 'these shifts' ) . '.' : ( $byn ? ogc_mail_safe_name( $byn ) . ' took ' . $whom . ' off ' . ( $one ? 'this shift' : 'these shifts' ) . '. ' : '' ) . 'The ' . $first['committee'] . ' head is told.' ), ogc_vol_still_lines( $shifts ) ),
				'button'  => array( $one ? 'Join again' : 'Volunteer shifts', $g( 'join_url' ) ),
				'after'   => array( $g( 'has_ics' ) ? ogc_vol_cal_after_left( $shifts ) : '' ),
				'reason'  => $g( 'reason' ) ? $g( 'reason' ) : 'This address was signed up for ' . ( $one ? 'this shift' : 'these shifts' ) . '.',
			);
			break;

		case 'vol_replaced':
			$subj = 'Replaced · ' . ogc_vol_mail_what( $shifts );
			$a    = array(
				'subject' => $subj,
				'heading' => $subj,
				'facts'   => ogc_vol_mail_facts( $shifts ),
				// "Tom P. took Jane’s place." (after the ninth critic, Oct 16: "took your place"). Who took it is
				// `taker`: `to` is the address the footer names (it said "Sent to Tom P.."; Oct 24).
				'lines'   => array_merge( array( ogc_mail_safe_name( $g( 'taker', 'Someone' ) ) . ' took ' . ( $g( 'whose' ) ? $g( 'whose' ) : 'the' ) . ' place. The ' . $first['committee'] . ' foreman is told.' ), ogc_vol_still_lines( $shifts ) ),
				'button'  => array( 'Your sign-ups', $g( 'mine_url' ) ),
				'after'   => array( $g( 'has_ics' ) ? ogc_vol_cal_after_left( $shifts ) : '' ),
				'reason'  => $g( 'reason' ) ? $g( 'reason' ) : 'This address was signed up for this shift.',
			);
			break;

		case 'vol_open_again':
			$subj = 'Place open again · ' . ogc_vol_mail_what( $shifts );
			$a    = array(
				'subject' => $subj,
				'heading' => $subj,
				'facts'   => ogc_vol_mail_facts( $shifts ),
				'lines'   => array( 'Not confirmed, so the ' . ( count( (array) $g( 'names', array() ) ) > 1 ? 'places are' : 'place is' ) . ' open again. The ' . $first['committee'] . ' foreman is told.' ),
				'button'  => array( 'Join again', $g( 'join_url' ) ),
				'reason'  => $g( 'reason' ) ? $g( 'reason' ) : 'This address was signed up for this shift.',
			);
			break;

		case 'vol_reminder':
		case 'vol_week':
			// Each shift said by when it is (ogc_vol_day_before_mail): all today, all tomorrow, or both, with
			// each line headed "Today · Sun, May 30" / "Tomorrow · Mon, May 31".
			$rels  = array_values( array_unique( array_filter( array_map( function ( $s ) {
				return isset( $s['rel'] ) ? (string) $s['rel'] : '';
			}, $shifts ) ) ) );
			$mixed = 'vol_reminder' === $kind && count( $rels ) > 1;
			$tday  = $rels ? array( 'today' ) === $rels : (bool) $g( 'today' );
			$fsh   = $mixed ? array_map( function ( $s ) {
				$s['day'] = ( 'today' === $s['rel'] ? 'Today' : 'Tomorrow' ) . ' · ' . $s['day'];
				return $s;
			}, $shifts ) : $shifts;
			// "Next week · Usher · Sat, May 29" / "Next week · 3 shifts" (after the ninth critic, Oct 16: "Your
			// shifts" to a contact, whose people are on them and she isn't).
			$subj = ( 'vol_week' === $kind ? 'Next week · ' . ogc_vol_mail_what( $shifts ) : ( $mixed ? 'Today and tomorrow · ' . count( $shifts ) . ' shifts' : ( $tday ? 'Today · ' : 'Tomorrow · ' ) . ogc_vol_mail_what( $shifts ) ) );
			$a    = array(
				'subject' => $subj,
				'heading' => $subj,
				'facts'   => ogc_vol_mail_facts( $fsh ),
				'lines'   => array_values( array_filter( array_merge( $instr, array( $one && ! ogc_vol_same_words( (string) $first['note'], isset( $first['instruction'] ) ? (string) $first['instruction'] : '' ) ? wp_strip_all_tags( (string) $first['note'] ) : '' ) ) ) ),
				'button'  => $one && $first['map'] ? array( 'Directions', $first['map'] ) : array( 'Your sign-ups', $g( 'mine_url' ) ),
				'after'   => array( $one ? '' : $map, $g( 'has_ics' ) ? 'Calendar file attached.' : '', array( 'Can’t make it?', 'Leave shift', $g( 'leave_url' ) ) ),
				// Who of this address is on them (ogc_vol_addr): signed up, their contact, or "Leroy is signed
				// up on this address" (after the ninth critic, Oct 16).
				'reason'  => $g( 'reason' ) ? $g( 'reason' ) : ogc_vol_remind_reason( (string) $g( 'via' ), $one ),
			);
			break;

		case 'vol_message':
		case 'vol_heads':
		case 'vol_copy':
			$subj = wp_strip_all_tags( (string) $g( 'subject', 'Message' ) );
			// Each shift once, with the people from this address on it (after the ninth critic, Oct 16: a
			// contact's four Brubakers were four lines of one shift under "Your shifts"): "Server · Sat, May
			// 29 · 3:45–7 PM Eastern · Barnes Student Center · John, Mary, Ben and Lucy".
			$your = array();
			foreach ( $shifts as $s ) {
				$your[] = $s['title'] . ' · ' . $s['when'] . ( $s['place'] ? ' · ' . $s['place'] : '' ) . ( $s['name'] ? ' · ' . $s['name'] : '' );
			}
			// The copy to its sender: what it went to, how many people and emails (never "0"), and who has
			// no email, to call (after the ninth critic, Oct 16: "To: 0 volunteers" and no one named).
			$call = array_values( array_filter( array_map( 'strval', (array) $g( 'call', array() ) ) ) );
			$a = array(
				'subject'   => ( 'vol_copy' === $kind ? 'Copy · ' : '' ) . $subj,
				'heading'   => ( 'vol_copy' === $kind ? 'Copy · ' : '' ) . $subj,
				'facts'     => array( array( 'From', $g( 'from' ) ), array( 'To', $g( 'sent_to' ) ), array( 'Sent', 'vol_copy' === $kind ? (string) $g( 'sent' ) : '' ), array( 'Call', implode( "\n", array_slice( $call, 0, 40 ) ) ), array( count( $your ) > 1 ? 'Shifts' : 'Shift', implode( "\n", $your ) ) ),
				'plain'     => mb_substr( (string) $g( 'body' ), 0, 5000 ),
				'button'    => 'vol_message' === $kind && $g( 'mine_url' ) ? array( 'Your sign-ups', $g( 'mine_url' ) ) : null,
				'questions' => 'vol_copy' === $kind ? '' : 'Reply to this email',
				'reason'    => 'vol_heads' === $kind ? 'Sent to each committee’s contact and heads.' : ( 'vol_copy' === $kind ? '' : ( $g( 'reason' ) ? $g( 'reason' ) : 'This address is on ' . ogc_mail_the( $g( 'committee' ) ) . '’s list.' ) ),
			);
			break;

		case 'vol_head':
			$w    = (string) $g( 'what' );
			if ( 'digest' === $w ) {
				$xs   = array_values( array_filter( array_map( 'strval', (array) $g( 'lines', array() ) ) ) );
				$subj = ( false === $g( 'today', true ) ? 'Who left · ' : 'Left today · ' ) . $g( 'committee' );
				$a    = array(
					'subject' => $subj,
					'heading' => $subj,
					'lines'   => array( implode( "\n", array_slice( $xs, 0, 40 ) ) ),
					'button'  => array( 'Who’s signed up', $g( 'list_url' ) ),
					'reason'  => 'Notices for ' . ogc_mail_the( $g( 'committee' ) ) . ' come to this address.',
				);
				break;
			}
			$name = ogc_mail_safe_name( $g( 'name' ) );
			$subj = 'swap' === $w ? 'Swap · ' . ogc_mail_safe_name( $g( 'from' ) ) . ' → ' . ogc_mail_safe_name( $g( 'to' ) ) . ' · ' . $first['title']
				: ( 'unconfirmed' === $w ? 'Unconfirmed · ' . $name . ' · ' . $first['title'] : 'Removed · ' . $name . ' · ' . $first['title'] );
			$a    = array(
				'subject' => $subj,
				'heading' => $subj,
				'facts'   => array( array( 'When', $first['when'] ), array( 'Phone', 'unconfirmed' === $w ? $g( 'phone' ) : '' ), array( 'Open', '' !== (string) $g( 'open' ) ? (string) (int) $g( 'open' ) : '' ) ),
				'lines'   => array_values( array_filter( array(
					'unconfirmed' === $w ? 'The confirmation wasn’t opened, so the place is open again. To keep them on, call and add them back.' : '',
					'notme' === $w ? 'The owner of the email used for ' . $name . ' said it wasn’t them. The sign-up is removed.' : '',
				) ) ),
				'button'  => array( 'Who’s signed up', $g( 'list_url' ) ),
				'reason'  => 'Notices for ' . ogc_mail_the( $first['committee'] ) . ' come to this address.',
			);
			break;

		case 'vol_weekly':
			$lines = array();
			foreach ( (array) $g( 'open_shifts', array() ) as $s ) {
				$lines[] = $s[0] . ' · ' . $s[1] . ' · ' . (int) $s[2] . ' open';
			}
			$week = trim( ( (int) $g( 'joined' ) ? (int) $g( 'joined' ) . ' joined' : '' ) . ( (int) $g( 'joined' ) && (int) $g( 'left' ) ? ' · ' : '' ) . ( (int) $g( 'left' ) ? (int) $g( 'left' ) . ' left' : '' ) );
			$subj = $g( 'committee' ) . ' volunteers · ' . (int) $g( 'filled' ) . ' of ' . (int) $g( 'needed' ) . ' filled';
			$a    = array(
				'subject' => $subj,
				'heading' => $subj,
				'facts'   => array( array( 'Open', (int) $g( 'open' ) ? (string) (int) $g( 'open' ) : '' ), array( 'This week', $week ) ),
				'lines'   => $lines ? array( "Still open\n" . implode( "\n", array_slice( $lines, 0, 25 ) ) ) : array( 'Every shift is full.' ),
				'button'  => array( 'Who’s signed up', $g( 'list_url' ) ),
				'after'   => array( 'Names and phones are on the list, signed in. Turn this email off there.' ),
				'reason'  => 'The weekly summary for ' . ogc_mail_the( $g( 'committee' ) ) . '’s contact.',
			);
			break;

		case 'vol_remind':
			$a = array(
				'subject' => 'Dorm shifts · ' . $g( 'committee', 'Young Folks' ),
				'heading' => 'Dorm shifts · ' . $g( 'committee', 'Young Folks' ),
				'lines'   => array( 'One supervision shift is asked of each parent with Young Folks in the halls.' ),
				'button'  => array( 'Choose a shift', $g( 'page_url' ) ),
				'reason'  => 'This household has Young Folks staying in the halls.',
			);
			break;

		case 'vol_open':
			$was = (array) $g( 'again', array() );
			$a   = array(
				'subject' => 'Sign-ups open · Volunteer shifts',
				'heading' => 'Sign-ups open · Volunteer shifts',
				// Last year's shifts under this address, each with its people (after the ninth critic, Oct 16:
				// "Your 2026 shifts", whose each was unsaid): "Usher · Sat, May 29 · 9:30 AM–12 PM · Daniel and Esther".
				'lines'   => $was ? array( 'Signed up in ' . ( (int) $g( 'year' ) - 1 ) . ", on this year’s days\n" . implode( "\n", array_slice( $was, 0, 12 ) ) ) : array(),
				'button'  => $was ? array( 'Sign up again', $g( 'again_url' ) ) : array( 'Volunteer shifts', $g( 'page_url' ) ),
				'after'   => array( $was ? array( '', 'Every shift', $g( 'page_url' ) ) : '' ),
				'reason'  => 'This address asked to hear when sign-ups open.',
			);
			break;

		case 'vol_notify':
			$a = array(
				'subject' => 'Noted · ' . (int) $g( 'year' ) . ' volunteer sign-ups',
				'heading' => 'Noted · ' . (int) $g( 'year' ) . ' volunteer sign-ups',
				'lines'   => array( 'One email goes out when they open.' ),
				'after'   => array( array( 'Not you?', 'Remove me', $g( 'remove_url' ) ) ),
				'reason'  => 'Someone asked, on the volunteer page, to email this address once.',
			);
			break;
	}
	return $a ? ogc_mail_compose( array_merge( $base, $a ) ) : null;
}

// Made-up examples for the Mail log's preview (sample people only).
add_filter( 'ogc_mail_samples', function ( $s ) {
	$link  = ogc_url( 'volunteer', array( 'year' => 2027, 't' => 'SAMPLE-not-a-real-link' ) );
	$one   = array( 'title' => 'Golf cart driver', 'committee' => 'Transportation', 'day' => 'Fri, May 28', 'span' => '2–6 PM Eastern', 'when' => 'Fri, May 28 · 2–6 PM Eastern', 'place' => 'Barnes Student Center', 'note' => 'Keys at the Information Center.', 'name' => '', 'map' => ogc_url( 'guide', array( 'year' => 2027, 'view' => 'places', 'to' => 'B' ) ) );
	$two   = array_merge( $one, array( 'title' => 'Server', 'committee' => 'Food', 'day' => 'Sat, May 29', 'span' => '11:45 AM–2:15 PM Eastern', 'when' => 'Sat, May 29 · 11:45 AM–2:15 PM Eastern', 'place' => 'Baldwin Dining Hall', 'name' => 'Esther' ) );
	$c     = array( 'questions' => '765-555-0140 · Reply to this email' );
	return array_merge( (array) $s, array(
		'vol_confirm'    => $c + array( 'shifts' => array( $one ), 'confirmed' => false, 'confirm_url' => $link, 'notme_url' => $link, 'mine_url' => $link, 'leave_url' => $link, 'has_ics' => true, 'reminders' => 'Reminders come a week before the Conference and the day before.' ),
		'vol_left'       => $c + array( 'shifts' => array( $one, array_merge( $two, array( 'still' => 'Walter', 'still_n' => 1 ) ) ), 'join_url' => $link, 'has_ics' => true ),
		'vol_replaced'   => $c + array( 'shifts' => array( $one ), 'taker' => 'Tom P.', 'mine_url' => $link, 'has_ics' => true ),
		'vol_open_again' => $c + array( 'shifts' => array( $one ), 'join_url' => $link ),
		'vol_reminder'   => $c + array( 'shifts' => array( $one, $two ), 'mine_url' => $link, 'leave_url' => $link ),
		'vol_week'       => $c + array( 'shifts' => array( $one, $two ), 'mine_url' => $link, 'leave_url' => $link, 'has_ics' => true ),
		'vol_message'    => array( 'subject' => 'Carts moved', 'from' => 'Phoebe L. · Transportation foreman', 'committee' => 'Transportation', 'reason' => 'This address is signed up for this shift.', 'shifts' => array( array_merge( $one, array( 'name' => 'Martha and Leroy' ) ) ), 'body' => "The carts are behind the Fieldhouse this year, not at Barnes.\nKeys at the Information Center.", 'mine_url' => $link ),
		'vol_heads'      => array( 'subject' => 'Sign-in sheets', 'from' => 'Nathan K. · Committee of Arrangements', 'body' => 'Please print your sign-in sheets by Thursday.' ),
		'vol_copy'       => array( 'subject' => 'Carts moved', 'sent_to' => 'Golf cart driver · Sat, May 29 · 11 AM–3 PM', 'sent' => '5 people · 4 emails', 'call' => array( 'Lois B. · 555-0190' ), 'body' => 'The carts are behind the Fieldhouse this year.' ),
		'vol_head'       => array( 'what' => 'unconfirmed', 'name' => 'Hannah T.', 'phone' => '765-555-0199', 'open' => 1, 'shifts' => array( $one ), 'list_url' => $link, 'to' => 'transportation@conference.example.org' ),
		'vol_weekly'     => array( 'committee' => 'Transportation', 'filled' => 31, 'needed' => 40, 'open' => 9, 'joined' => 6, 'left' => 1, 'open_shifts' => array( array( 'Golf cart driver', 'Sat, May 29 · 7–11 AM', 2 ) ), 'list_url' => $link, 'to' => 'transportation@conference.example.org' ),
		'vol_remind'     => array( 'committee' => 'Young Folks', 'page_url' => $link ),
		'vol_open'       => array( 'again' => array( 'Golf cart driver · Transportation · Sat, May 29 · 7–11 AM · Daniel', 'Dorm chaperone · Young Folks · Fri night, May 28 · 12–2 AM · Daniel and Esther' ), 'again_url' => $link, 'page_url' => $link ),
		'vol_notify'     => array( 'year' => 2028, 'remove_url' => $link ),
	) );
} );

/* ================================================================== calendar files */

function ogc_vol_ics_text( $v ) {
	return str_replace( array( '\\', ',', ';', "\n" ), array( '\\\\', '\,', '\;', '\n' ), (string) $v );
}

/**
 * A calendar file for some sign-ups: one event a shift for each email, naming everyone on it under that
 * email ("Server · Food · Martha and Henry"), one alarm (after the critic, Oct 15: a couple got two of
 * each). Its UID lasts (ogc_vol_cal_uid: the email and the shift), so an update replaces it and a cancel
 * removes it (METHOD and SEQUENCE). A cancel for one of two leaves the shared event: the other is still on.
 *
 * LEFT (after the second critic, Oct 15): some of an email's people left a shift (Leave, a swap taken, a
 * place let go). With no one of that email still on it, the event is cancelled; with someone still on it
 * (Edna left, Walter stayed), the same event is sent again naming only them ("Server · Food · Walter"), so
 * it's never an empty file and never still says "Edna and Walter".
 *
 * The summary names the people when there are several, or when the one on it isn't the address's own
 * person (someone signed up for them on this email): yourself alone isn't named, as on the page.
 */
function ogc_vol_ics( $year, $items, $method = 'PUBLISH', $exact = false ) {
	$snap = ogc_state_get( $year, 'vol-snap' );
	$snap = $snap ? (array) $snap['value'] : array();
	$left = 'LEFT' === $method;
	// Each item's email (an old caller gives only the sign-up's id), then a shift at a time.
	foreach ( $items as &$it ) {
		if ( ! isset( $it['email'] ) && ! empty( $it['rid'] ) ) {
			$r           = ogc_record_get( (int) $it['rid'] );
			$it['email'] = $r ? (string) $r['email'] : '';
		}
	}
	unset( $it );
	// The address's own person: not signed up by someone else on it, not added under it by another.
	$own    = function ( $r ) {
		return $r && empty( $r['data']['for'] ) && empty( $r['data']['helper_email'] ) && 'helper' !== ( isset( $r['data']['by'] ) ? $r['data']['by'] : 'self' );
	};
	$groups = isset( $items[0]['names'] ) ? $items : ogc_vol_group_items( $items );
	$s      = ogc_vol_settings( $year );
	$E      = array();
	$update = false;
	foreach ( $groups as $g ) {
		$sh    = $g['shift'];
		$email = isset( $g['email'] ) ? strtolower( (string) $g['email'] ) : '';
		// Everyone under this email on the shift now (a cancel: those it cancels).
		$names = array_values( array_unique( array_map( 'strval', $g['names'] ) ) );
		$rids  = array_map( 'intval', isset( $g['rids'] ) ? (array) $g['rids'] : array( (int) $g['rid'] ) );
		$still      = array();
		$still_self = false;
		$self       = false;
		foreach ( $rids as $rid ) {
			$self = $self || $own( ogc_record_get( $rid ) );
		}
		// $exact (the page's own file, ogc_vol_rest_ics): the asker's places only, nobody else's under the email.
		if ( '' !== $email && ! $exact ) {
			foreach ( ogc_records( $year, 'signups', $email ) as $r ) {
				if ( isset( $r['data']['id'] ) && $r['data']['id'] === $sh['id'] && ! in_array( (int) $r['id'], $rids, true ) ) {
					$still[]    = (string) $r['data']['name'];
					$still_self = $still_self || $own( $r );
				}
			}
		}
		if ( 'CANCEL' === $method && $still ) {
			continue;
		}
		$cancel = 'CANCEL' === $method || ( $left && ! $still );
		if ( $left && $still ) {
			// Updated in place: only those still on it.
			$names  = array_values( array_unique( $still ) );
			$self   = $still_self;
			$update = true;
		} elseif ( ! $cancel ) {
			$names = array_values( array_unique( array_merge( $names, $still ) ) );
			$self  = $self || $still_self;
		}
		$uid = '' !== $email ? ogc_vol_cal_uid( $email, $sh['id'] ) : 'ogc-vol-' . substr( md5( $sh['id'] . '|' . implode( '|', $names ) ), 0, 16 ) . '@ogbbc.org';
		$seq = isset( $snap[ $sh['id'] ]['seq'] ) ? (int) $snap[ $sh['id'] ]['seq'] : 0;
		$L   = array();
		$L[] = 'BEGIN:VEVENT';
		$L[] = 'UID:' . $uid;
		$L[] = 'SEQUENCE:' . ( $cancel || $left ? $seq + 1 : $seq );
		$L[] = 'DTSTAMP:' . gmdate( 'Ymd\THis\Z', ogc_vol_now() );
		if ( ! empty( $sh['allweek'] ) ) {
			// All week: whole days, from the first to the day after the last (the calendar's own rule).
			$L[] = 'DTSTART;VALUE=DATE:' . str_replace( '-', '', $sh['date'] );
			$L[] = 'DTEND;VALUE=DATE:' . gmdate( 'Ymd', strtotime( ( ! empty( $sh['last_date'] ) ? $sh['last_date'] : $sh['date'] ) . ' 12:00:00 UTC' ) + DAY_IN_SECONDS );
		} else {
			$L[] = 'DTSTART:' . gmdate( 'Ymd\THis\Z', $sh['start_ts'] );
			$L[] = 'DTEND:' . gmdate( 'Ymd\THis\Z', $sh['end_ts'] );
		}
		$named = count( $names ) > 1 || ( ! $cancel && $names && ! $self );
		// A night shift says its night ("Dorm chaperone · Young Folks · Fri night · 12–2 AM"): a calendar files
		// it on the next date at 12 AM, with no hint which night it is (after the ninth critic, Oct 16).
		$nw    = ogc_vol_night_words( $sh );
		$L[]   = 'SUMMARY:' . ogc_vol_ics_text( ogc_vol_job_words( $sh['role'], $sh['committee'] ) . ( '' !== $nw ? ' · ' . $nw . ' · ' . ogc_vol_span_of( $sh ) : '' ) . ( $named ? ' · ' . ogc_vol_names_words( $names, true ) : '' ) );
		$loc = array_filter( array( $sh['place_name'], isset( $s['venue'] ) ? $s['venue'] : '', isset( $s['city'] ) ? $s['city'] : '' ) );
		if ( $loc ) {
			$L[] = 'LOCATION:' . ogc_vol_ics_text( implode( ', ', $loc ) );
		}
		$ins = ogc_vol_instruction( $year, $sh['committee'] );
		$L[] = 'DESCRIPTION:' . ogc_vol_ics_text( ( $names ? ogc_vol_names_words( $names ) . "\n" : '' ) . ( $ins ? $ins . "\n" : '' ) . ( $sh['note'] && ! ogc_vol_same_words( $sh['note'], $ins ) ? $sh['note'] . "\n" : '' ) . 'Your sign-ups: ' . ogc_vol_signups_url( $year ) );
		if ( $cancel ) {
			$L[] = 'STATUS:CANCELLED';
		} else {
			// A night shift's alarm at 6 PM on its evening, never in the middle of the night (after the eighth
			// critic, Oct 16: "Tomorrow" a day before 12 AM rang at midnight): "Tonight: Dorm chaperone ·
			// 12–3 AM". Any other: a day before, "Tomorrow: Server".
			$nt  = ogc_vol_is_night( $sh );
			$L[] = 'BEGIN:VALARM';
			$L[] = 'TRIGGER:' . ( $nt ? '-PT' . ( (int) $sh['start'] + 360 ) . 'M' : '-P1D' );
			$L[] = 'ACTION:DISPLAY';
			$L[] = 'DESCRIPTION:' . ogc_vol_ics_text( $nt ? 'Tonight: ' . ogc_vol_role_shown( $sh['role'], $sh['committee'] ) . ' · ' . ogc_vol_span_of( $sh ) : 'Tomorrow: ' . ogc_vol_role_shown( $sh['role'], $sh['committee'] ) );
			$L[] = 'END:VALARM';
		}
		$L[] = 'END:VEVENT';
		$E   = array_merge( $E, $L );
	}
	// LEFT: a file that still holds an event is a PUBLISH (a cancelled one in it says STATUS:CANCELLED).
	$m = $left ? ( $update ? 'PUBLISH' : 'CANCEL' ) : $method;
	return implode( "\r\n", array_merge( array( 'BEGIN:VCALENDAR', 'VERSION:2.0', 'PRODID:-//ogbbc.org//Annual Conference//EN', 'METHOD:' . $m ), $E, array( 'END:VCALENDAR' ) ) ) . "\r\n";
}

/* ================================================================== the outbox */

/** A sign-up's shift as it is now, or as it was (a removed shift, from the snapshot kept with it). */
function ogc_vol_shift_of( $y, $rec, $was = null ) {
	$shifts = ogc_vol_shifts( $y );
	$id     = isset( $rec['data']['id'] ) ? $rec['data']['id'] : '';
	if ( isset( $shifts[ $id ] ) ) {
		return $shifts[ $id ];
	}
	if ( $was ) {
		$was = (array) $was;
		return array( 'id' => $id, 'uid' => '', 'role' => $was['role'], 'committee' => $was['committee'], 'date' => $was['date'], 'start' => (int) $was['start'], 'end' => (int) $was['end'], 'place' => isset( $was['place'] ) ? $was['place'] : '', 'place_name' => '', 'note' => '', 'start_ts' => ogc_vol_ts( $y, $was['date'], (int) $was['start'] ), 'end_ts' => ogc_vol_ts( $y, $was['date'], (int) $was['end'] ) );
	}
	return null;
}

/**
 * The reminders a Confirm email's shifts will get, said plainly (after the third critic, Oct 15: it said
 * only "A reminder comes the day before" while the week-before email was on too). Each committee keeps
 * its own (Helpers › Reminders); said only when every committee in the email keeps it, and the week-
 * before one only while it's still ahead.
 */
function ogc_vol_remind_words( $y, $items ) {
	$coms = array_values( array_unique( array_map( function ( $it ) {
		return (string) $it['shift']['committee'];
	}, (array) $items ) ) );
	$week = (bool) $coms;
	$day  = (bool) $coms;
	foreach ( $coms as $c ) {
		$week = $week && ogc_vol_remind_on( $y, $c, 'week' );
		$day  = $day && ogc_vol_remind_on( $y, $c, 'day' );
	}
	$days = ogc_vol_days( $y );
	if ( $week && ( ! $days || ogc_vol_wall( $y )['date'] >= gmdate( 'Y-m-d', strtotime( $days[0]['date'] . ' UTC' ) - 7 * DAY_IN_SECONDS ) ) ) {
		$week = false;
	}
	if ( $week && $day ) {
		return 'Reminders come a week before the Conference and the day before.';
	}
	return $week ? 'A reminder comes a week before the Conference.' : ( $day ? 'A reminder comes the day before.' : '' );
}

/** Send one queued email. */
function ogc_vol_send_job( $job ) {
	$y      = (int) $job['year'];
	$GLOBALS['ogc_vol_mail_year'] = $y;
	$p      = (array) ogc_unjson( $job['payload'], array() );
	$email  = $job['email'];
	$shifts = ogc_vol_shifts( $y );
	$ics    = 'volunteer-' . $y . '.ics';
	switch ( $job['kind'] ) {
		case 'confirm':
			$items = array();
			$rids  = array();
			$by    = '';
			$via   = array();
			$self  = 0;
			foreach ( (array) $p['rids'] as $rid ) {
				$r = ogc_record_get( (int) $rid );
				if ( $r && isset( $shifts[ $r['data']['id'] ] ) && $r['email'] === strtolower( $email ) ) {
					$items[] = array( 'shift' => $shifts[ $r['data']['id'] ], 'name' => $r['data']['name'], 'rid' => (int) $rid, 'email' => $r['email'], 'rec' => $r );
					$rids[]  = (int) $rid;
					// Signed up through this address as their contact, not on the shift (Oct 15): said who for.
					if ( ! empty( $r['data']['via'] ) ) {
						$via[] = (string) $r['data']['name'];
					} else {
						$self++;
					}
					// Added by someone else (Add someone): the email names them, "Daniel M. signed you up".
					if ( ! empty( $r['data']['helper_email'] ) && ! empty( $r['data']['helper'] ) ) {
						$by = ogc_vol_first_l( $r['data']['helper'] );
					}
				}
			}
			if ( ! $items ) {
				return true;
			}
			// Each shift once, with everyone on it named: a couple's one shift is one shift, one layout
			// either way (Who · When · Where · Committee, then Directions). Its reason by how the places were
			// made (ogc_vol_addr, after the ninth critic, Oct 16).
			$addr  = ogc_vol_addr( $y, $email, $items, 'signed', ! empty( $p['by_head'] ) ? array( 'head' => $items[0]['shift']['committee'] ) : ( $by ? array( 'name' => $by ) : array() ) );
			$items = $addr['groups'];
			$list  = $addr['shifts'];
			// Still unconfirmed now (the person may have confirmed through another email meanwhile).
			$ok    = ! empty( $p['confirmed'] ) || ! array_filter( $rids, function ( $rid ) {
				$r = ogc_record_get( $rid );
				return $r && empty( $r['data']['confirmed'] );
			} );
			$first = $items[0]['shift'];
			// Places of the same burst an earlier Confirm email listed (ogc_vol_burst_ids: the same device,
			// still unconfirmed): this email lists only its own, and says the earlier Confirm does it too.
			$earlier = $ok || ! empty( $p['nudge'] ) || ! empty( $p['again'] ) ? array() : array_diff( ogc_vol_burst_ids( $y, $email, $rids ), $rids );
			return ogc_vol_mail( 'vol_confirm', $email, array(
				'shifts'      => $list,
				'earlier'     => (bool) $earlier,
				'confirmed'   => $ok,
				'confirm_url' => $ok ? '' : ogc_vol_confirm_link( $y, $email, $rids ),
				'notme_url'   => ogc_vol_link( $y, 'notme', $email, array( 'r' => $rids ), 30 * DAY_IN_SECONDS ),
				// Unconfirmed too: a first-timer's only email keeps a way to Your sign-ups and out of the shift.
				'leave_url'   => ogc_vol_leave_link( $y, $email, $rids ),
				'mine_url'    => ogc_vol_mine_link( $y, $email ),
				'hours'       => ogc_vol_confirm_hours( $y ),
				'by_head'     => ! empty( $p['by_head'] ) ? $first['committee'] : '',
				'by_name'     => $by,
				'who'         => $addr['who'],
				'reason'      => $addr['reason'],
				'theirs'      => ! $addr['own'],
				// Every place in it through this address as their contact: "For Amos and Ruth Yoder".
				'via_for'     => $via && ! $self ? ogc_vol_names_words( array_values( array_unique( $via ) ) ) : '',
				// The one reminder a day on (once, "nudged"): said as that, not the same email again.
				'nudge'       => ! empty( $p['nudge'] ),
				'questions'   => ogc_vol_mail_questions( $y, $first['committee'] ),
				// Reminders go only to confirmed places, so the "Still to confirm" email promises none (after
				// the seventh critic, Oct 15: it said "A reminder comes the day before").
				'reminders'   => ! empty( $p['nudge'] ) && ! $ok ? '' : ogc_vol_remind_words( $y, $items ),
			), array( 'reply_to' => ogc_vol_reply_to( $y, $first['committee'] ), 'ics' => ogc_vol_ics( $y, $items, 'PUBLISH' ), 'ics_name' => $ics ) );

		case 'left':
			$items = array();
			$head  = false;
			foreach ( (array) $p['items'] as $it ) {
				$rec = (array) $it['rec'];
				$sh  = ogc_vol_shift_of( $y, $rec );
				if ( $sh ) {
					$items[] = array( 'shift' => $sh, 'name' => $rec['data']['name'], 'rid' => (int) $rec['id'], 'email' => strtolower( (string) $rec['email'] ), 'rec' => $rec );
					$head    = $head || ! empty( $it['by_head'] );
					$byn     = ! empty( $it['by_name'] ) ? (string) $it['by_name'] : ( isset( $byn ) ? $byn : '' );
				}
			}
			if ( ! $items ) {
				return true;
			}
			// A couple leaving one shift is one shift ("Left shift · Server · Sat, May 29"). One of two leaving
			// (Edna; Walter stays): the email says so, and the calendar event is updated to name Walter only.
			$addr  = ogc_vol_addr( $y, $email, $items, 'was' );
			$items = $addr['groups'];
			$first = $items[0]['shift'];
			return ogc_vol_mail( 'vol_left', $email, array(
				'shifts'    => ogc_vol_with_still( $y, $items ),
				'by_head'   => $head,
				'by_name'   => isset( $byn ) ? $byn : '',
				'who'       => $addr['who'],
				'reason'    => $addr['reason'],
				'join_url'  => 1 === count( $items ) ? ogc_vol_page( $y, array( 'shift' => $first['id'] ) ) : ogc_vol_page( $y ),
				'questions' => ogc_vol_mail_questions( $y, $first['committee'] ),
			), array( 'reply_to' => ogc_vol_reply_to( $y, $first['committee'] ), 'ics' => ogc_vol_ics( $y, $items, 'LEFT' ), 'ics_name' => $ics ) );

		case 'person':
			// One email an address a shift (after the ninth critic, Oct 16): a couple's or a contact's people
			// on one changed, removed or let-go shift are gathered into one job (ogc_vol_queue_person: `recs`),
			// and named, never "you"; older jobs carry one `rec`.
			$recs = ! empty( $p['recs'] ) ? array_values( (array) $p['recs'] ) : array( $p['rec'] );
			$rec  = (array) $recs[0];
			$was  = isset( $p['extra']['was'] ) ? (array) $p['extra']['was'] : null;
			$sh   = 'removed' === $p['what'] && $was ? ogc_vol_shift_of( $y, array( 'data' => array( 'id' => '' ) ), $was ) : ogc_vol_shift_of( $y, $rec, $was );
			if ( ! $sh ) {
				return true;
			}
			// A removed shift keeps its old id for its calendar event (the same UID, so it's cancelled).
			if ( '' === (string) $sh['id'] && ! empty( $rec['data']['id'] ) ) {
				$sh['id'] = (string) $rec['data']['id'];
			}
			$item = array();
			foreach ( $recs as $rc ) {
				$rc     = (array) $rc;
				$item[] = array( 'shift' => $sh, 'name' => $rc['data']['name'], 'rid' => (int) $rc['id'], 'email' => strtolower( (string) $rc['email'] ), 'rec' => $rc );
			}
			$tense = 'head_added' === $p['what'] ? 'signed' : ( 'changed' === $p['what'] ? 'is' : 'was' );
			$addr  = ogc_vol_addr( $y, $email, $item, $tense, 'head_added' === $p['what'] ? array( 'head' => $sh['committee'] ) : array() );
			$item  = $addr['groups'];
			$ms    = $addr['shifts'][0];
			$rids  = ogc_vol_rids_of( $item );
			$ctx   = array( 'reply_to' => ogc_vol_reply_to( $y, $sh['committee'] ), 'ics_name' => $ics );
			$q     = ogc_vol_mail_questions( $y, $sh['committee'] );
			if ( 'swapped' === $p['what'] ) {
				return ogc_vol_mail( 'vol_replaced', $email, array( 'shifts' => ogc_vol_with_still( $y, $item ), 'taker' => $p['extra']['to'], 'whose' => ogc_vol_whose( $addr['names'] ), 'reason' => $addr['reason'], 'mine_url' => ogc_vol_mine_link( $y, $email ), 'questions' => $q ), $ctx + array( 'ics' => ogc_vol_ics( $y, $item, 'LEFT' ) ) );
			}
			if ( 'changed' === $p['what'] ) {
				// The set's own: Was and Now.
				// The night rule too ("Fri night, May 28 · 12–3 AM"; after the eighth critic, Oct 16).
				$before = $was ? ogc_vol_subject_day( $y, array( 'date' => $was['date'], 'start' => (int) $was['start'], 'eve' => isset( $was['eve'] ) ? $was['eve'] : '' ) ) . ' · ' . ogc_vol_span( (int) $was['start'], (int) $was['end'] ) : '';
				return ogc_vol_mail( 'shift_changed', $email, array( 'title' => $ms['title'], 'who' => $ms['name'], 'reason' => $addr['reason'], 'before' => $before, 'after' => $ms['when'] . ( $ms['place'] ? ' · ' . $ms['place'] : '' ), 'url' => ogc_vol_mine_link( $y, $email ), 'questions' => $q ), $ctx + array( 'ics' => ogc_vol_ics( $y, $item, 'PUBLISH' ) ) );
			}
			if ( 'removed' === $p['what'] ) {
				return ogc_vol_mail( 'shift_removed', $email, array( 'title' => $ms['title'], 'who' => $ms['name'], 'reason' => $addr['reason'], 'when' => $ms['when'], 'join_url' => ogc_vol_page( $y, array( 'committee' => $sh['committee'] ) ), 'questions' => $q ), $ctx + array( 'ics' => ogc_vol_ics( $y, $item, 'CANCEL' ) ) );
			}
			if ( 'opened_again' === $p['what'] ) {
				return ogc_vol_mail( 'vol_open_again', $email, array( 'shifts' => array( $ms ), 'names' => $addr['names'], 'reason' => $addr['reason'], 'join_url' => ogc_vol_page( $y, array( 'shift' => $sh['id'] ) ), 'questions' => $q ), $ctx + array( 'ics' => ogc_vol_ics( $y, $item, 'LEFT' ) ) );
			}
			if ( 'head_added' === $p['what'] ) {
				return ogc_vol_mail( 'vol_confirm', $email, array( 'shifts' => array( $ms ), 'confirmed' => true, 'by_head' => $sh['committee'], 'who' => $addr['who'], 'reason' => $addr['reason'], 'mine_url' => ogc_vol_mine_link( $y, $email ), 'leave_url' => ogc_vol_leave_link( $y, $email, $rids ), 'notme_url' => ogc_vol_link( $y, 'notme', $email, array( 'r' => $rids ), 30 * DAY_IN_SECONDS ), 'questions' => $q, 'reminders' => ogc_vol_remind_words( $y, array( array( 'shift' => $sh ) ) ) ), $ctx + array( 'ics' => ogc_vol_ics( $y, $item, 'PUBLISH' ) ) );
			}
			return true;

		case 'opened':
			$sh = isset( $shifts[ $p['shift'] ] ) ? $shifts[ $p['shift'] ] : null;
			// Everyone of the address still waiting (older jobs: the one wait).
			$ws = array();
			$ns = array();
			foreach ( ! empty( $p['waits'] ) ? (array) $p['waits'] : array( (int) $p['wait'] ) as $i => $wid ) {
				$w = ogc_record_get( (int) $wid );
				if ( $w && 'waits' === $w['kind'] && strtolower( (string) $w['email'] ) === strtolower( $email ) ) {
					$ws[] = (int) $wid;
					$ns[] = (string) $w['data']['name'];
				}
			}
			if ( ! $sh || ogc_vol_now() >= $sh['start_ts'] || ! $ws ) {
				return true;
			}
			$ms   = ogc_vol_mail_shift( $y, $sh, ogc_vol_names_words( $ns ) );
			$join = ogc_vol_link( $y, 'opened', $email, array( 's' => array( $sh['id'] ), 'n' => $ns, 'w' => $ws[0], 'ws' => $ws ), max( HOUR_IN_SECONDS, $sh['start_ts'] - ogc_vol_now() ), array( 'shift' => $sh['id'] ) );
			// The set's own: Join, and Leave waitlist (the same link's card has both). Who it's for, by name.
			return ogc_vol_mail( 'spot_open', $email, array( 'title' => $ms['title'], 'who' => $ms['name'], 'n' => count( $ns ), 'when' => $ms['when'], 'place' => $ms['place'], 'join_url' => $join, 'leave_url' => $join, 'questions' => ogc_vol_mail_questions( $y, $sh['committee'] ) ), array( 'reply_to' => ogc_vol_reply_to( $y, $sh['committee'] ) ) );

		case 'head':
			$sh = isset( $shifts[ $p['shift'] ] ) ? $shifts[ $p['shift'] ] : null;
			if ( ! $sh ) {
				return true;
			}
			// The day's leaves: one line a person, with how many are open on that shift now.
			if ( 'digest' === $p['what'] ) {
				// "Left today" only when every leave in it was today (after the seventh critic, Oct 15: a
				// leave after the evening's email waits for the next one, and it said "Left today" of
				// yesterday's). Otherwise "Who left", each line dated ("Oct 15 · Lois B. · …").
				$today = ogc_vol_wall( $y )['date'];
				$on    = function ( $it ) use ( $y ) {
					$t = ! empty( $it['at'] ) ? strtotime( $it['at'] . ' UTC' ) : 0;
					return $t ? ( new DateTimeImmutable( '@' . $t ) )->setTimezone( ogc_vol_tz( $y ) ) : null;
				};
				$all   = true;
				foreach ( (array) $p['extra']['items'] as $it ) {
					$d   = $on( $it );
					$all = $all && $d && $d->format( 'Y-m-d' ) === $today;
				}
				$lines = array();
				foreach ( (array) $p['extra']['items'] as $it ) {
					$x = isset( $shifts[ $it['shift'] ] ) ? $shifts[ $it['shift'] ] : null;
					if ( $x ) {
						$o       = ogc_vol_open_count( $y, $x );
						$d       = $on( $it );
						$lines[] = ( $all || ! $d ? '' : $d->format( 'M j' ) . ' · ' ) . $it['name'] . ' · ' . ogc_vol_role_shown( $x['role'], $x['committee'] ) . ' · ' . ogc_vol_when( $y, $x ) . ( null === $o ? '' : ' · ' . ( $o ? $o . ' open' : 'Full again' ) );
					}
				}
				return ! $lines || ogc_vol_mail( 'vol_head', $email, array( 'what' => 'digest', 'today' => $all, 'committee' => $sh['committee'], 'lines' => $lines, 'list_url' => ogc_vol_page( $y, array( 'view' => 'lead', 'committee' => $sh['committee'] ) ) ) );
			}
			$open = ogc_vol_open_count( $y, $sh );
			$x    = (array) $p['extra'];
			$list = ogc_vol_page( $y, array( 'view' => 'lead', 'committee' => $sh['committee'] ) );
			$ms   = ogc_vol_mail_shift( $y, $sh );
			if ( 'late' === $p['what'] ) {
				return ogc_vol_mail( 'volunteer_left', $email, array( 'name' => $x['name'], 'title' => $ms['title'], 'when' => $ms['when'], 'open' => $open, 'needed' => $sh['needed'], 'committee' => $sh['committee'], 'list_url' => $list ) );
			}
			if ( in_array( $p['what'], array( 'swap', 'unconfirmed', 'notme' ), true ) ) {
				return ogc_vol_mail( 'vol_head', $email, array( 'what' => $p['what'], 'name' => isset( $x['name'] ) ? $x['name'] : '', 'phone' => isset( $x['phone'] ) ? ogc_vol_phone_shown( $x['phone'] ) : '', 'from' => isset( $x['from'] ) ? $x['from'] : '', 'to' => isset( $x['to'] ) ? $x['to'] : '', 'open' => null === $open ? '' : $open, 'shifts' => array( $ms ), 'list_url' => $list ) );
			}
			return true;

		case 'message':
			// The head's own words, with this address's people on the committee's shifts the message went to,
			// built the way the reminders are (after the ninth critic, Oct 16: "Your shifts" listed one shift
			// four times, once a Brubaker, to Rachel, their contact; Martha, who had left, got "Your shift" and
			// "You're signed up" while only Leroy was on it). Each shift once, with the people from this
			// address *on* it named; the reason true of them (ogc_vol_addr). An address with nobody still on
			// any of them gets nothing.
			$items = array();
			foreach ( ogc_vol_seat_map( $y ) as $id => $seats ) {
				$sh = isset( $shifts[ $id ] ) ? $shifts[ $id ] : null;
				if ( ! $sh || $sh['committee'] !== $p['committee'] || ! ogc_vol_message_reaches( (string) ( isset( $p['to'] ) ? $p['to'] : 'all' ), $id, $sh ) ) {
					continue;
				}
				foreach ( $seats as $s ) {
					if ( strtolower( (string) $s['record']['email'] ) === strtolower( $email ) ) {
						$items[] = array( 'shift' => $sh, 'name' => $s['record']['data']['name'], 'rid' => (int) $s['record']['id'], 'email' => strtolower( $email ), 'rec' => $s['record'] );
					}
				}
			}
			if ( ! $items ) {
				return true;
			}
			$addr = ogc_vol_addr( $y, $email, $items, 'is' );
			// First names on a shift's line ("Usher · Sat, May 29 · 9:30 AM–12 PM Eastern · Chapel Auditorium · Leroy").
			$list = array_map( function ( $g ) use ( $y ) {
				return ogc_vol_mail_shift( $y, $g['shift'], ogc_vol_names_words( $g['names'], true ) );
			}, array_slice( $addr['groups'], 0, 8 ) );
			return ogc_vol_mail( 'vol_message', $email, array(
				'subject'   => $p['subject'],
				'body'      => $p['body'],
				'from'      => isset( $p['from'] ) ? $p['from'] : '',
				'committee' => $p['committee'],
				'shifts'    => $list,
				'reason'    => $addr['reason'],
				'mine_url'  => ogc_vol_mine_link( $y, $email ),
			), array( 'reply_to' => $p['reply_to'] ) );

		case 'heads':
			return ogc_vol_mail( 'vol_heads', $email, array( 'subject' => $p['subject'], 'body' => $p['body'], 'from' => isset( $p['from'] ) ? $p['from'] : '' ), array( 'reply_to' => $p['reply_to'] ) );

		case 'copy':
			// What it went to, how many (people and emails, never "0") and who to call (no email): set by
			// ogc_vol_lead_message() as `sent_to`, `sent` and `call` (after the ninth critic, Oct 16).
			return ogc_vol_mail( 'vol_copy', $email, array( 'subject' => $p['subject'], 'body' => $p['body'], 'sent_to' => isset( $p['sent_to'] ) ? $p['sent_to'] : '', 'sent' => isset( $p['sent'] ) ? $p['sent'] : '', 'call' => isset( $p['call'] ) ? (array) $p['call'] : array() ) );

		case 'remind':
			return ogc_vol_mail( 'vol_remind', $email, array( 'committee' => $p['committee'], 'page_url' => ogc_vol_page( $y, array( 'committee' => $p['committee'] ) ) ), array( 'reply_to' => ogc_vol_reply_to( $y, $p['committee'] ) ) );

		case 'notify':
			return ogc_vol_mail( 'vol_notify', $email, array( 'year' => $y, 'remove_url' => ogc_vol_link( $y, 'unnotify', $email, array(), 400 * DAY_IN_SECONDS ) ) );
	}
	return true;
}

/** Does a head's message (to: all, day:YYYY-MM-DD, shift:<id>) reach this shift? */
function ogc_vol_message_reaches( $to, $id, $sh ) {
	// A day is the day and its night (Friday's 12–3 AM is Friday night's; after the eighth critic, Oct 16).
	if ( 0 === strpos( $to, 'day:' ) ) {
		return ogc_vol_eve_date( $sh ) === substr( $to, 4 );
	}
	if ( 0 === strpos( $to, 'shift:' ) ) {
		return $id === substr( $to, 6 );
	}
	return true;
}

function ogc_vol_open_count( $year, $sh ) {
	global $wpdb;
	if ( $sh['unlimited'] ) {
		return null;
	}
	$n = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM ' . ogc_table( 'vol_seats' ) . ' s JOIN ' . ogc_table( 'records' ) . ' r ON r.id = s.record_id AND r.deleted_at IS NULL WHERE s.year = %d AND s.shift = %s', $year, $sh['id'] ) );
	return max( 0, $sh['needed'] - $n );
}

function ogc_vol_confirm_hours( $year ) {
	$s = ogc_vol_settings( $year );
	// Not let go until the COA chooses a number of hours (question 22): a confirmation lost in spam
	// mustn't cost an older volunteer the place. A reminder goes after a day either way.
	return isset( $s['confirm_hours'] ) && is_numeric( $s['confirm_hours'] ) ? max( 0, (int) $s['confirm_hours'] ) : 0;
}

/* ================================================================== the timed job */

add_filter( 'cron_schedules', function ( $s ) {
	$s['ogc_five_minutes'] = array( 'interval' => 300, 'display' => 'Every five minutes' );
	return $s;
} );
add_action( 'init', function () {
	if ( ! wp_next_scheduled( 'ogc_vol_tick' ) ) {
		wp_schedule_event( time() + 60, 'ogc_five_minutes', 'ogc_vol_tick' );
	}
} );
add_action( 'ogc_vol_tick', 'ogc_vol_tick' );

/** After a request that queued email: run the job when the answer has gone (a busy site doesn't wait
 * for WP-Cron's next visit). */
function ogc_vol_tick_soon() {
	if ( ! empty( $GLOBALS['ogc_vol_tick_soon'] ) ) {
		return;
	}
	$GLOBALS['ogc_vol_tick_soon'] = true;
	add_action( 'shutdown', function () {
		if ( function_exists( 'fastcgi_finish_request' ) ) {
			fastcgi_finish_request();
		}
		ogc_vol_send_due();
	} );
}

/** Only the outbox: what's due now (the rest of the timed work waits for the cron). */
function ogc_vol_send_due() {
	global $wpdb;
	$done = array();
	$t    = ogc_table( 'vol_outbox' );
	$jobs = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM $t WHERE sent_at IS NULL AND send_after <= %s ORDER BY id LIMIT 60", gmdate( 'Y-m-d H:i:s', ogc_vol_now() ) ), ARRAY_A );
	foreach ( (array) $jobs as $job ) {
		// Marked first, so a slow send never goes twice.
		$n = $wpdb->query( $wpdb->prepare( "UPDATE $t SET sent_at = %s WHERE id = %d AND sent_at IS NULL", gmdate( 'Y-m-d H:i:s', ogc_vol_now() ), $job['id'] ) );
		if ( 1 === (int) $n ) {
			ogc_vol_send_job( $job );
			$done[] = $job['kind'];
		}
	}
	return $done;
}

/** What's due: the outbox, then each year's timed emails, the let-go and the clearing. */
function ogc_vol_tick() {
	if ( get_transient( 'ogc_vol_tick_lock' ) && empty( $GLOBALS['ogc_vol_tick_force'] ) ) {
		return array();
	}
	set_transient( 'ogc_vol_tick_lock', 1, 50 );
	$done = ogc_vol_send_due();
	foreach ( ogc_years_list() as $y ) {
		if ( ! ogc_file_get( $y, 'shifts' ) ) {
			continue;
		}
		$done = array_merge( $done, ogc_vol_year_jobs( $y ) );
	}
	delete_transient( 'ogc_vol_tick_lock' );
	return $done;
}

/** One year's timed work. */
function ogc_vol_year_jobs( $y ) {
	$GLOBALS['ogc_vol_mail_year'] = $y;
	$done = array();
	$wall = ogc_vol_wall( $y );
	$last = ogc_vol_last_day( $y );
	$days = ogc_vol_days( $y );
	if ( ! $days ) {
		return $done;
	}
	$first  = $days[0]['date'];
	$shifts = ogc_vol_shifts( $y );
	$ended  = $last && $wall['date'] > $last;

	// Unconfirmed places: one reminder after a day (Confirm first). When the COA has chosen hours
	// (confirm_hours), a place still unconfirmed then opens again, and nobody is left out: the person is
	// told (with Join again), and the head by name and phone.
	$hours = ogc_vol_confirm_hours( $y );
	if ( ! $ended ) {
		$nudge = array();
		foreach ( ogc_records( $y, 'signups' ) as $r ) {
			if ( ! empty( $r['data']['confirmed'] ) || $r['sample'] || empty( $r['email'] ) ) {
				continue;
			}
			$age = ogc_vol_now() - strtotime( $r['created_at'] . ' UTC' );
			if ( $hours > 0 && $age > $hours * HOUR_IN_SECONDS ) {
				ogc_record_delete( $r['id'] );
				ogc_vol_after_leave( $y, $r, 'quiet' );
				if ( isset( $shifts[ $r['data']['id'] ] ) ) {
					$sh = $shifts[ $r['data']['id'] ];
					ogc_vol_change( $y, $sh, 'unconfirmed', $r['data']['name'] );
					ogc_vol_queue_person( $y, $r, 'opened_again' );
					ogc_vol_head_notice( $y, $sh, 'unconfirmed', array( 'name' => ogc_vol_first_l( $r['data']['name'] ), 'phone' => isset( $r['data']['phone'] ) ? $r['data']['phone'] : '' ) );
					ogc_vol_notify_waitlist( $y, $sh );
				}
				$done[] = 'let_go';
			} elseif ( $age > DAY_IN_SECONDS && empty( $r['data']['nudged'] ) && ( $hours <= 0 || $hours * HOUR_IN_SECONDS - $age > 3 * HOUR_IN_SECONDS ) ) {
				$d           = $r['data'];
				$d['nudged'] = gmdate( 'c', ogc_vol_now() );
				ogc_record_update( $r['id'], $d, $r['email'] );
				$nudge[ $r['email'] ][] = (int) $r['id'];
			}
		}
		foreach ( $nudge as $em => $rids ) {
			ogc_vol_queue( $y, 'confirm', $em, array( 'rids' => $rids, 'confirmed' => false, 'nudge' => true ) );
			$done[] = 'nudge';
		}
	}

	if ( ogc_vol_posted( $y ) && ! $ended ) {
		$done = array_merge( $done, ogc_vol_reminders( $y, $wall, $first, $shifts ) );
		$done = array_merge( $done, ogc_vol_weekly( $y, $wall ) );
		$done = array_merge( $done, ogc_vol_head_digest( $y, $wall ) );
	}
	if ( ogc_vol_posted( $y ) ) {
		$done = array_merge( $done, ogc_vol_opening( $y ) );
	}
	$s     = ogc_vol_settings( $y );
	$after = isset( $s['clear_after_days'] ) && is_numeric( $s['clear_after_days'] ) ? (int) $s['clear_after_days'] : 60;
	if ( $last && $wall['date'] > gmdate( 'Y-m-d', strtotime( $last . ' UTC' ) + $after * DAY_IN_SECONDS ) && ! ogc_state_get( $y, 'vol-cleared' ) ) {
		ogc_vol_clear_year( $y );
		$done[] = 'cleared';
	}
	ogc_vol_seats_tidy( $y );
	return $done;
}

/** The day before each shift (at 9 AM venue time), one email per person for the next day's shifts; and
 * a week before the Conference, one "Your shifts" email listing them all. Each goes once. */
/**
 * Is a place's day-before reminder due now? From 9 AM the day before ("Tomorrow" is the evening before
 * for a shift after midnight). A run that didn't happen that day is caught up on the next one, up to the
 * shift's start, once (after the sixth critic, Oct 15: "eve === tomorrow" alone never sent it late); only
 * for a place held before the shift's own day (one taken that day needs no reminder). The week-before
 * reminder already has this shape (from a week before, on any later run, once).
 */
function ogc_vol_day_before_due( $y, $r, $sh, $wall ) {
	if ( ! empty( $r['data']['reminded'] ) || ogc_vol_now() >= $sh['start_ts'] ) {
		return false;
	}
	$eve      = ogc_vol_eve_date( $sh );
	$day0     = gmdate( 'Y-m-d', strtotime( $eve . ' UTC' ) - DAY_IN_SECONDS );
	$on_time  = $wall['date'] === $day0 && $wall['minutes'] >= 540;
	$late     = $wall['date'] > $day0 && strtotime( $r['created_at'] . ' UTC' ) < ogc_vol_ts( $y, $eve, 0 );
	return $on_time || $late;
}

/**
 * The week-before email for a place: from 9 AM a week before the Conference, once; caught up on a later
 * run. "Next week · Your shifts" only while it's true (after the seventh critic, Oct 15): before the
 * Conference begins, and for places taken before that week began (a later one got its Confirm email with
 * the calendar file, which then promises only the day-before: ogc_vol_remind_words()).
 */
function ogc_vol_week_before_due( $y, $r, $wall, $first ) {
	$week = gmdate( 'Y-m-d', strtotime( $first . ' UTC' ) - 7 * DAY_IN_SECONDS );
	return $wall['date'] >= $week && $wall['minutes'] >= 540 && $wall['date'] < $first && empty( $r['data']['week_sent'] )
		&& strtotime( $r['created_at'] . ' UTC' ) < ogc_vol_ts( $y, $week, 0 );
}

function ogc_vol_reminders( $y, $wall, $first, $shifts ) {
	$done     = array();
	$by       = array();
	$all      = array();
	foreach ( ogc_records( $y, 'signups' ) as $r ) {
		$sh = isset( $shifts[ $r['data']['id'] ] ) ? $shifts[ $r['data']['id'] ] : null;
		if ( ! $sh || empty( $r['data']['email'] ) || $r['sample'] || empty( $r['data']['confirmed'] ) || ogc_vol_now() >= $sh['start_ts'] ) {
			continue;
		}
		// Each committee chooses its reminders (Helpers › Reminders): a week before and the day before,
		// both until it says otherwise.
		if ( ogc_vol_day_before_due( $y, $r, $sh, $wall ) && ogc_vol_remind_on( $y, $sh['committee'], 'day' ) ) {
			$by[ $r['email'] ][] = $r;
		}
		if ( ogc_vol_week_before_due( $y, $r, $wall, $first ) && ogc_vol_remind_on( $y, $sh['committee'], 'week' ) ) {
			$all[ $r['email'] ][] = $r;
		}
	}
	$mark = function ( $r, $k ) {
		$d       = $r['data'];
		$d[ $k ] = true;
		ogc_record_update( $r['id'], $d, $r['email'] );
	};
	foreach ( $all as $email => $list ) {
		array_walk( $list, function ( $r ) use ( $mark ) {
			$mark( $r, 'week_sent' );
		} );
		ogc_vol_week_mail( $y, $email, $list, $shifts );
		$done[] = 'week';
	}
	foreach ( $by as $email => $list ) {
		array_walk( $list, function ( $r ) use ( $mark ) {
			$mark( $r, 'reminded' );
		} );
		ogc_vol_day_before_mail( $y, $email, $list, $wall, $shifts );
		$done[] = 'reminder';
	}
	return $done;
}

/**
 * The week-before email for one email's places ("Next week · Usher · Sat, May 29"): a shift once, with
 * everyone on it under this email named, and why it came, true of them (ogc_vol_addr; after the ninth
 * critic, Oct 16: "Next week · Your shifts" to a contact).
 */
function ogc_vol_week_mail( $y, $email, $list, $shifts ) {
	$items = array();
	foreach ( $list as $r ) {
		$items[] = array( 'shift' => $shifts[ $r['data']['id'] ], 'name' => $r['data']['name'], 'rid' => (int) $r['id'], 'email' => strtolower( (string) $r['email'] ), 'rec' => $r );
	}
	$addr  = ogc_vol_addr( $y, $email, $items, 'is' );
	$items = $addr['groups'];
	return ogc_vol_mail( 'vol_week', $email, array( 'year' => (int) $y, 'shifts' => $addr['shifts'], 'mine_url' => ogc_vol_mine_link( $y, $email ), 'leave_url' => ogc_vol_leave_link( $y, $email, ogc_vol_rids_of( $items ) ), 'via' => ogc_vol_via_of( $list ), 'reason' => $addr['reason'] ), array( 'ics' => ogc_vol_ics( $y, $items, 'PUBLISH' ), 'ics_name' => 'volunteer-' . $y . '.ics' ) );
}

/**
 * The day-before reminder for one email's places: one email, each shift said by when it is. After the
 * seventh critic (Oct 15): a run that caught up a missed reminder sent "Today · 2 shifts" for one of
 * today's and one of tomorrow's (it looked only at the first). Each shift is now "today" (its evening is
 * today or past: a reminder caught up) or "tomorrow"; all of one, the subject says it ("Today · …",
 * "Tomorrow · …"); both, "Today and tomorrow · 4 shifts", each line headed by its own ("Today · Sun,
 * May 30", "Tomorrow · Mon, May 31").
 */
function ogc_vol_day_before_mail( $y, $email, $list, $wall, $shifts ) {
	$items = array();
	foreach ( $list as $r ) {
		$items[] = array( 'shift' => $shifts[ $r['data']['id'] ], 'name' => $r['data']['name'], 'rid' => (int) $r['id'], 'email' => strtolower( (string) $r['email'] ), 'rec' => $r );
	}
	// Who of this address is on them, and why it came (after the ninth critic, Oct 16: Martha's address,
	// with only Leroy on it after she left, read "This address is signed up").
	$addr  = ogc_vol_addr( $y, $email, $items, 'is' );
	$items = $addr['groups'];
	$ms    = $addr['shifts'];
	foreach ( $items as $i => $it ) {
		$ms[ $i ]['rel'] = ogc_vol_eve_date( $it['shift'] ) <= $wall['date'] ? 'today' : 'tomorrow';
	}
	$sh    = $items[0]['shift'];
	$leave = ogc_vol_leave_link( $y, $email, ogc_vol_rids_of( $items ) );
	$q     = ogc_vol_mail_questions( $y, $sh['committee'] );
	$ctx   = array( 'reply_to' => ogc_vol_reply_to( $y, $sh['committee'] ) );
	$today = ! array_filter( $ms, function ( $m ) {
		return 'today' !== $m['rel'];
	} );
	// One layout for one shift or several (Who · When · Where · Committee; Directions for one): the
	// committee's instruction first, then the shift's own note; Can't make it? Leave shift.
	return ogc_vol_mail( 'vol_reminder', $email, array( 'year' => (int) $y, 'shifts' => $ms, 'mine_url' => ogc_vol_mine_link( $y, $email ), 'leave_url' => $leave, 'questions' => $q, 'today' => $today, 'via' => ogc_vol_via_of( $list ), 'reason' => $addr['reason'] ), $ctx );
}

/**
 * Why a reminder came to this address (after the seventh critic, Oct 15: a contact who signed others up
 * and isn't on their shifts read "This address is signed up for this shift"): 'all' when every place in
 * it was made through this address as their contact (`via`), 'some' when it's both, '' when none.
 */
function ogc_vol_via_of( $records ) {
	$v = 0;
	foreach ( (array) $records as $r ) {
		$v += ! empty( $r['data']['via'] ) ? 1 : 0;
	}
	return ! $v ? '' : ( count( (array) $records ) === $v ? 'all' : 'some' );
}

/** The reason line under a reminder: signed up, their contact, or both. */
function ogc_vol_remind_reason( $via, $one ) {
	if ( 'all' === $via ) {
		return 'This address is their contact.';
	}
	if ( 'some' === $via ) {
		return 'This address is signed up, or their contact, for these shifts.';
	}
	return 'This address is signed up for ' . ( $one ? 'this shift' : 'these shifts' ) . '.';
}

/** A committee's numbers: places, filled, open, people waiting. */
function ogc_vol_committee_numbers( $y, $committee, $map = null ) {
	$map = null === $map ? ogc_vol_seat_map( $y ) : $map;
	$n   = array( 'needed' => 0, 'filled' => 0, 'open' => 0, 'shifts' => 0, 'short' => array() );
	foreach ( ogc_vol_shifts( $y ) as $id => $sh ) {
		if ( $sh['committee'] !== $committee ) {
			continue;
		}
		$f = isset( $map[ $id ] ) ? count( $map[ $id ] ) : 0;
		$n['shifts']++;
		$n['filled'] += $f;
		if ( ! $sh['unlimited'] ) {
			$n['needed'] += $sh['needed'];
			$o            = max( 0, $sh['needed'] - $f );
			$n['open']   += $o;
			if ( $o && $sh['start_ts'] > ogc_vol_now() ) {
				$n['short'][] = array( $sh, $o );
			}
		}
	}
	return $n;
}

/** Mondays, after 7 AM venue time: each committee's contact hears how it stands and what changed. */
function ogc_vol_weekly( $y, $wall ) {
	$done = array();
	if ( 1 !== (int) gmdate( 'N', strtotime( $wall['date'] . ' UTC' ) ) || $wall['minutes'] < 420 ) {
		return $done;
	}
	$sent = ogc_state_get( $y, 'vol-weekly' );
	$sent = $sent ? (array) $sent['value'] : array();
	$ch   = ogc_state_get( $y, 'vol-changes' );
	$ch   = $ch ? (array) $ch['value'] : array();
	$map  = ogc_vol_seat_map( $y );
	foreach ( ogc_vol_committees( $y ) as $c ) {
		if ( ! is_email( $c['contact_email'] ) || 'no' === strtolower( (string) $c['weekly'] ) || ( isset( $sent[ $c['name'] ] ) && $sent[ $c['name'] ] === $wall['date'] ) ) {
			continue;
		}
		$n     = ogc_vol_committee_numbers( $y, $c['name'], $map );
		$since = gmdate( 'Y-m-d H:i:s', ogc_vol_now() - 7 * DAY_IN_SECONDS );
		$j     = 0;
		$l     = 0;
		foreach ( $ch as $x ) {
			if ( $x['committee'] === $c['name'] && $x['at'] >= $since ) {
				$j += 'joined' === $x['act'] ? 1 : 0;
				$l += in_array( $x['act'], array( 'left', 'unconfirmed', 'notme' ), true ) ? 1 : 0;
			}
		}
		ogc_vol_mail( 'vol_weekly', $c['contact_email'], array(
			'committee'   => $c['name'],
			'filled'      => $n['filled'],
			'needed'      => $n['needed'],
			'open'        => $n['open'],
			'joined'      => $j,
			'left'        => $l,
			'open_shifts' => array_map( function ( $s ) use ( $y ) {
				return array( ogc_vol_role_shown( $s[0]['role'], $s[0]['committee'] ), ogc_vol_when( $y, $s[0] ), $s[1] );
			}, $n['short'] ),
			'list_url'    => ogc_vol_page( $y, array( 'view' => 'lead', 'committee' => $c['name'] ) ),
		) );
		$sent[ $c['name'] ] = $wall['date'];
		$done[]             = 'weekly';
	}
	ogc_state_put( $y, 'vol-weekly', $sent );
	return $done;
}

/** Everyone who asked to hear when the year's sign-ups open (records "notify"; older years kept a
 * list in the state value vol-notify). */
function ogc_vol_notify_list( $y ) {
	$out = array();
	foreach ( ogc_records( $y, 'notify' ) as $r ) {
		$out[ $r['email'] ] = (int) $r['id'];
	}
	$old = ogc_state_get( $y, 'vol-notify' );
	foreach ( $old ? (array) $old['value'] : array() as $e ) {
		if ( is_string( $e ) && is_email( $e ) && ! isset( $out[ strtolower( $e ) ] ) ) {
			$out[ strtolower( $e ) ] = 0;
		}
	}
	return $out;
}

/** Each of last year's shifts by this year's day and time, in the page's words ("Dorm chaperone · Young
 * Folks · Fri night, May 28 · 12–2 AM"; after the seventh critic, Oct 15: "Saturday 12–2 AM" with no
 * date), with whose it was ("· Daniel and Esther", after the ninth critic); one with no match this year
 * says so ("… · Not in 2027"). */
function ogc_vol_again_lines( $y, $again ) {
	$now   = ogc_vol_shifts( $y );
	$lines = array();
	foreach ( (array) $again as $a ) {
		// Whose it was, by first name (after the ninth critic, Oct 16): "… · Daniel and Esther".
		$who     = ! empty( $a['names'] ) ? ' · ' . ogc_vol_names_words( (array) $a['names'], true ) : '';
		$lines[] = ! empty( $a['shift'] ) && isset( $now[ $a['shift'] ] ) ? ogc_vol_job_words( $now[ $a['shift'] ]['role'], $now[ $a['shift'] ]['committee'] ) . ' · ' . ogc_vol_when( $y, $now[ $a['shift'] ] ) . $who : $a['was'] . $who . ' · Not in ' . $y;
	}
	return $lines;
}

/** When sign-ups open: one email to those who asked, and to last year's volunteers who ticked Next
 * year (their shifts, and Sign up again in one tap). Once. */
function ogc_vol_opening( $y ) {
	global $wpdb;
	if ( ogc_state_get( $y, 'vol-opened-sent' ) ) {
		return array();
	}
	$done = array();
	$back = array();
	$kept = ogc_state_get( $y, 'vol-return' );
	foreach ( $kept ? (array) $kept['value'] : array() as $k ) {
		$back[ $k['email'] ] = true;
	}
	foreach ( ogc_records( $y - 1, 'signups' ) as $r ) {
		if ( ! empty( $r['data']['next_year'] ) && ! $r['sample'] && ! empty( $r['data']['email'] ) ) {
			$back[ strtolower( $r['data']['email'] ) ] = true;
		}
	}
	$asked = ogc_vol_notify_list( $y );
	foreach ( array_unique( array_merge( array_keys( $back ), array_keys( $asked ) ) ) as $email ) {
		$again = isset( $back[ $email ] ) ? ogc_vol_again( $y, $email ) : array();
		$ids   = array_values( array_filter( wp_list_pluck( $again, 'shift' ) ) );
		$names = array();
		foreach ( $again as $a ) {
			$names = array_merge( $names, $a['names'] );
		}
		ogc_vol_mail( 'vol_open', $email, array(
			'year'      => $y,
			'again'     => $ids ? ogc_vol_again_lines( $y, $again ) : array(),
			'again_url' => $ids ? ogc_vol_link( $y, 'again', $email, array( 's' => $ids, 'n' => array_values( array_unique( $names ) ) ), 60 * DAY_IN_SECONDS ) : '',
			'page_url'  => ogc_vol_page( $y ),
		) );
		$done[] = 'open';
	}
	ogc_state_put( $y, 'vol-opened-sent', ogc_now() );
	ogc_state_put( $y, 'vol-notify', array() );
	// Sent once: the addresses aren't kept.
	$wpdb->query( $wpdb->prepare( 'DELETE FROM ' . ogc_table( 'records' ) . " WHERE year = %d AND kind = 'notify'", $y ) );
	return $done;
}

/**
 * Names cleared after the Conference (the security plan: 60 days). What's kept: each shift's numbers
 * (needed, filled, waiting at the end, the date it filled) and how many different people helped, for
 * next year's committee; and, for those who ticked Next year, their email, first names and which
 * shifts (no phone), until next year opens. Sample rows are made-up people and stay.
 */
function ogc_vol_clear_year( $y ) {
	global $wpdb;
	$map    = ogc_vol_seat_map( $y );
	$stats  = array();
	$waits  = array();
	foreach ( ogc_records( $y, 'waits' ) as $w ) {
		$waits[ $w['data']['id'] ] = ( isset( $waits[ $w['data']['id'] ] ) ? $waits[ $w['data']['id'] ] : 0 ) + 1;
	}
	foreach ( ogc_vol_shifts( $y ) as $id => $sh ) {
		$on      = isset( $map[ $id ] ) ? $map[ $id ] : array();
		$filled  = '';
		if ( ! $sh['unlimited'] && count( $on ) >= $sh['needed'] ) {
			$at     = array_map( function ( $s ) {
				return ! empty( $s['record']['data']['at'] ) ? gmdate( 'Y-m-d H:i:s', strtotime( $s['record']['data']['at'] ) ) : $s['record']['created_at'];
			}, $on );
			sort( $at );
			$filled = min( substr( $at[ $sh['needed'] - 1 ], 0, 10 ), $sh['date'] );
		}
		$stats[ $id ] = array( 'committee' => $sh['committee'], 'role' => $sh['role'], 'day' => $sh['day'], 'start' => $sh['start'], 'needed' => $sh['unlimited'] ? null : $sh['needed'], 'filled' => count( $on ), 'filled_on' => $filled, 'waiting' => isset( $waits[ $id ] ) ? $waits[ $id ] : 0 );
	}
	ogc_state_put( $y, 'vol-stats', $stats );
	// How many different people helped (a person serving three meals is one), kept as numbers only.
	ogc_state_put( $y, 'vol-people', ogc_vol_people_counts( $y, $map ) );
	$back = array();
	$all  = ogc_vol_shifts( $y );
	foreach ( ogc_records( $y, 'signups' ) as $r ) {
		if ( $r['sample'] || empty( $r['data']['next_year'] ) || empty( $r['data']['email'] ) || ! isset( $all[ $r['data']['id'] ] ) ) {
			continue;
		}
		$sh = $all[ $r['data']['id'] ];
		$e  = strtolower( $r['data']['email'] );
		$w  = preg_split( '/\s+/', trim( $r['data']['name'] ) );
		$back[ $e ]['email']      = $e;
		$back[ $e ]['patterns'][] = array( 'uid' => $sh['uid'], 'committee' => $sh['committee'], 'role' => $sh['role'], 'day' => $sh['day'], 'start' => $sh['start'], 'end' => $sh['end'], 'name' => $w[0] );
	}
	if ( $back ) {
		ogc_state_put( $y + 1, 'vol-return', array_values( $back ) );
	}
	$rt = ogc_table( 'records' );
	$wpdb->query( $wpdb->prepare( "DELETE FROM $rt WHERE year = %d AND kind IN ('signups','waits') AND sample = 0", $y ) );
	ogc_vol_seats_tidy( $y );
	ogc_state_put( $y, 'vol-changes', array() );
	ogc_state_put( $y, 'vol-cleared', ogc_now() );
	ogc_log( 'vol_cleared', $y, 'signups', array( 'kept' => count( $back ) ) );
}

/* ================================================================== local testing */

if ( OGC_DEV ) {
	// A test may set the moment for this request (X-OGC-Now: a Unix time; the volunteer page's ?as-of=).
	// Never for a Conference already over (Oct 16): a past year's sign-ups don't open by a preview. Only
	// on a local address (security pass, M10: a copy elsewhere with OGC_DEV left on took it from anyone).
	add_filter( 'rest_pre_dispatch', function ( $r, $server, $req ) {
		$n = $req->get_header( 'X-OGC-Now' );
		if ( $n && ctype_digit( (string) $n ) && ogc_dev_tools_on() && ! ( preg_match( '#/(\d{4})(/|$)#', (string) $req->get_route(), $m ) && function_exists( 'ogc_pub_over' ) && ogc_pub_over( (int) $m[1] ) ) ) {
			ogc_vol_set_now( (int) $n );
			// The same day for the sample records (Oct 24): the Millers' shifts, dated Mar 20, 2027, show as
			// theirs on a page previewed after it, as the app's ?as_of= does.
			if ( empty( $GLOBALS['ogc_records_as_of'] ) ) {
				$GLOBALS['ogc_records_as_of'] = wp_date( 'Y-m-d', (int) $n );
			}
		}
		return $r;
	}, 1, 3 );
	add_action( 'rest_api_init', function () {
		if ( ! ogc_dev_tools_on() ) {
			return;   // a local address only (security pass, M10)
		}
		// Run the timed job now, at a given moment (send everything queued when all=1). The emails are
		// in the signin area's Mail log (/annual-conference/mail/), the one log of everything sent.
		register_rest_route( OGC_NS, '/vol/dev/tick', array( 'methods' => 'POST', 'callback' => function ( WP_REST_Request $req ) {
			global $wpdb;
			if ( $req->get_param( 'at' ) ) {
				ogc_vol_set_now( (int) $req->get_param( 'at' ) );
			}
			if ( $req->get_param( 'all' ) ) {
				$wpdb->query( 'UPDATE ' . ogc_table( 'vol_outbox' ) . " SET send_after = '2000-01-01 00:00:00' WHERE sent_at IS NULL" ); // phpcs:ignore
			}
			$GLOBALS['ogc_vol_tick_force'] = true;
			return rest_ensure_response( array( 'done' => ogc_vol_tick() ) );
		}, 'permission_callback' => 'ogc_can_webmaster' ) );
	} );
	// The old second log (Oct 10) is gone: its stored bodies held live links.
	add_action( 'init', function () {
		if ( false !== get_option( 'ogc_vol_dev_mail', false ) ) {
			delete_option( 'ogc_vol_dev_mail' );
		}
	} );
}
