<?php
/**
 * Lodging's routes (/wp-json/ogc/v1/years/{y}/lodging…). Every one is for the year's members only
 * (ogc_lod_can), every change needs the wp_rest nonce (WordPress's cookie sign-in refuses a change
 * without it) and is written to the change log without anyone's personal data.
 *
 *   GET  /years/{y}/lodging            the board's rows, recent changes for Undo, the published
 *                                      snapshot, last year's notes, what the halls carry from the last
 *                                      year at this campus, the year in counts once names are cleared
 *   POST /years/{y}/lodging/ops        { ops: [{ key, data|null, v }], label }: change rows together;
 *                                      409 when a row changed since (with the rows as they are now) or
 *                                      a room was just given to someone else
 *   POST /years/{y}/lodging/undo       { id }: put a change back (409 when changed since)
 *   POST /years/{y}/lodging/publish    { mode: publish|update|unpublish, email }
 *   POST /years/{y}/lodging/log        { what: export|print, list }: who took which list, when
 *   GET  /years/{y}/lodging/summary    counts only (the year page's card)
 */

defined( 'ABSPATH' ) || exit;

add_action( 'rest_api_init', function () {
	$Y = '(?P<year>\d{4})';
	register_rest_route( OGC_NS, "/years/$Y/lodging", array(
		array( 'methods' => 'GET', 'callback' => 'ogc_lod_rest_get', 'permission_callback' => 'ogc_lod_can' ),
	) );
	register_rest_route( OGC_NS, "/years/$Y/lodging/ops", array(
		array( 'methods' => 'POST', 'callback' => 'ogc_lod_rest_ops', 'permission_callback' => 'ogc_lod_can' ),
	) );
	register_rest_route( OGC_NS, "/years/$Y/lodging/undo", array(
		array( 'methods' => 'POST', 'callback' => 'ogc_lod_rest_undo', 'permission_callback' => 'ogc_lod_can' ),
	) );
	register_rest_route( OGC_NS, "/years/$Y/lodging/publish", array(
		array( 'methods' => 'POST', 'callback' => 'ogc_lod_rest_publish', 'permission_callback' => 'ogc_lod_can' ),
	) );
	register_rest_route( OGC_NS, "/years/$Y/lodging/log", array(
		array( 'methods' => 'POST', 'callback' => 'ogc_lod_rest_log', 'permission_callback' => 'ogc_lod_can' ),
	) );
	register_rest_route( OGC_NS, "/years/$Y/lodging/summary", array(
		array( 'methods' => 'GET', 'callback' => function ( WP_REST_Request $req ) {
			return rest_ensure_response( ogc_lod_summary( (int) $req['year'] ) );
		}, 'permission_callback' => 'ogc_lod_can' ),
	) );
} );

/** The year's members (and webmasters), for a year that exists. */
function ogc_lod_can( WP_REST_Request $req ) {
	$y = (int) $req['year'];
	// The app (docs/23): Lodging's own people and the COA; webmasters only by seeing as (read only).
	// Every change needs a real viewer and today's date (ogc_appc_can).
	if ( function_exists( 'ogc_appc_can' ) ) {
		$ok = ogc_appc_can( $req, 'lod-rooms' );
		if ( true !== $ok ) {
			return $ok;
		}
	} elseif ( ! ogc_is_member( $y ) ) {
		return ogc_rest_denied();
	} elseif ( ! ogc_lod_may_see( $y ) ) {
		return ogc_lod_err( 'ogc_lodging_only', 'Lodging only', 403 );
	}
	return null === ogc_year_get( $y ) ? new WP_Error( 'ogc_no_year', 'Not started', array( 'status' => 404 ) ) : true;
}

function ogc_lod_err( $code, $msg, $status, $extra = array() ) {
	return new WP_Error( $code, $msg, array_merge( array( 'status' => $status ), $extra ) );
}

/* ================================================================== reading */

function ogc_lod_rest_get( WP_REST_Request $req ) {
	$y     = (int) $req['year'];
	$today = ogc_lod_today( $y, $req );
	$ph    = ogc_lod_phase( $y, $today );
	$rows  = ogc_lod_rows( $y );
	$uid   = get_current_user_id();
	$me    = ogc_lod_me();

	// When this member last sat down here: "Since Tuesday". A new sitting starts after three hours away.
	$seen = isset( $rows[ 'meta:seen:' . $uid ] ) ? $rows[ 'meta:seen:' . $uid ]['data'] : array();
	$now  = ogc_now();
	$prev = isset( $seen['prev'] ) ? $seen['prev'] : '';
	if ( empty( $seen['last'] ) || strtotime( $now ) - strtotime( $seen['last'] ) > 3 * HOUR_IN_SECONDS ) {
		$prev = isset( $seen['last'] ) ? $seen['last'] : '';
	}
	// Written when a sitting loads the board (?hh=1), not on every 25-second catch-up; never while seeing
	// as, on a previewed date or once names are cleared (invariant 87; red team round 2, R2A4-15, -17).
	if ( $req->get_param( 'hh' ) && empty( $req->get_param( 'as' ) ) && '' === (string) $req->get_param( 'as_of' ) && empty( $GLOBALS['ogc_app_as_of'] ) && ! $ph['cleared'] ) {
		ogc_lod_put( $y, 'meta:seen:' . $uid, array( 'last' => $now, 'prev' => $prev ) );
	}

	// The last changes, newest first, for Undo (anyone's; each says whose).
	$undo = array();
	foreach ( array_reverse( array_filter( $rows, function ( $r, $k ) { return 0 === strpos( $k, 'undo:' ); }, ARRAY_FILTER_USE_BOTH ), true ) as $k => $r ) {
		$undo[] = array( 'id' => substr( $k, 5 ), 'label' => isset( $r['data']['label'] ) ? $r['data']['label'] : '', 'at' => $r['at'], 'by' => ogc_lod_name_of( $r['by'] ), 'mine' => $r['by'] === $uid );
		if ( count( $undo ) >= 12 ) {
			break;
		}
	}
	$imports = array();
	foreach ( array_reverse( array_filter( $rows, function ( $r, $k ) { return 0 === strpos( $k, 'imp:' ); }, ARRAY_FILTER_USE_BOTH ), true ) as $k => $r ) {
		$imports[] = array( 'id' => substr( $k, 4 ), 'at' => $r['at'], 'by' => ogc_lod_name_of( $r['by'] ), 'summary' => isset( $r['data']['summary'] ) ? $r['data']['summary'] : array(), 'undone' => ! empty( $r['data']['undone'] ) );
		break;
	}

	$prev_year = ogc_lod_prev_year( $y );
	// Names due to be cleared are never sent, whether the daily job has run or not: cleared here first.
	if ( $ph['gone'] && ogc_lod_to_clear( $y ) ) {
		ogc_lod_clear( $y );
		$rows = ogc_lod_rows( $y );
	}
	$out       = array(
		'year'      => $y,
		// The app's screens ask for the households with the board (?hh=1), as Lodging needs them.
		'households' => $req->get_param( 'hh' ) && ! $ph['cleared'] && function_exists( 'ogc_appc_lod_households' ) ? ogc_lod_payload( $y, ogc_appc_lod_households( $y ) ) : null,
		// Rooms held wrongly (twice, or no longer in the halls): drawn at the top of Rooms until fixed.
		'conflicts' => $ph['cleared'] ? array() : array_map( function ( $c ) { return array( 'room' => $c['room'], 'words' => $c['words'], 'rids' => array_values( array_map( function ( $k ) { return 0 === strpos( $k, 'hh:' ) ? substr( $k, 3 ) : ''; }, $c['keys'] ) ) ); }, ogc_lod_conflicts( $y ) ),
		'phase'     => $ph,
		'me'        => $me,
		'rows'      => ogc_lod_public_rows( $ph['cleared'] ? array_filter( $rows, function ( $k ) { return 0 === strpos( $k, 'note:' ) || 0 === strpos( $k, 'room:' ) || 'meta:steps' === $k || 'meta:notes_done' === $k; }, ARRAY_FILTER_USE_KEY ) : $rows ),
		'undo'      => $undo,
		'import'    => $imports ? $imports[0] : null,
		'seen'      => $prev,
		'prev_year' => $prev_year,
		'prev'      => $prev_year ? ogc_lod_prev_parts( $prev_year ) : null,
		'carry'     => ogc_lod_carry( $y ),
		// Each room's beds before this year's own facts, where it isn't the hall's own number: the board's
		// count is the server's (invariant 6; red team A4_blank: a hall with no beds and room_beds 3).
		'beds'      => ogc_lod_beds_base( $y ),
		'numbers'   => null,
		// Counts (Round 5, module-lodging-counts.php): every send with its kept copy, who it may go to (the
		// committee's Contacts, by role), and when it's due.
		'sent'      => function_exists( 'ogc_lod_sent' ) && ! $ph['cleared'] ? ogc_lod_sent( $y ) : array(),
		'send_to'   => ogc_lod_send_to( $y ),
		'counts_due' => function_exists( 'ogc_lod_counts_due' ) ? ogc_lod_counts_due( $y ) : '',
	);
	if ( $ph['cleared'] ) {
		$out['conflicts'] = array();
	}
	if ( $ph['cleared'] ) {
		$n              = ogc_lod_row( $y, 'meta:numbers' );
		$out['numbers'] = $n ? $n['data'] : ogc_lod_numbers( $y );
		$out['undo']    = array();
		$out['import']  = null;
	}
	return rest_ensure_response( $out );
}

/** Each room's beds before this year's own facts (the fact carried from the last year at this campus,
 * the hall's beds, registration.csv's room_beds, else 2), only where that isn't the hall's own number in
 * rooms.csv (what the board reads by itself): id => beds. */
function ogc_lod_beds_base( $y ) {
	$rooms = ogc_lod_rooms( $y );
	$carry = ogc_lod_carry( $y );
	$facts = $carry ? (array) $carry['rooms'] : array();
	$out   = array();
	foreach ( $rooms as $id => $r ) {
		$b = ogc_lod_beds( $y, $id, $rooms, $facts );
		if ( $b !== ( $r['beds'] ? (int) $r['beds'] : 2 ) ) {
			$out[ $id ] = $b;
		}
	}
	return (object) $out;
}

/** Who Counts may be sent to: Lodging's Contacts by role (its page's hand-down), else none. */
function ogc_lod_send_to( $y ) {
	$c   = function_exists( 'ogc_hd_field' ) ? ogc_hd_field( (int) $y, 'lodging', 'contacts' ) : null;
	$out = array();
	foreach ( (array) ( is_array( $c ) && isset( $c['value'] ) ? $c['value'] : array() ) as $x ) {
		if ( is_array( $x ) && ! empty( $x['role'] ) ) {
			$out[] = mb_substr( wp_strip_all_tags( (string) $x['role'] ), 0, 80 );
		}
	}
	return array_values( array_unique( $out ) );
}

/**
 * The households as Lodging's screens get them (ogc_appc_lod_households), with what Lodging must see and
 * didn't: the one fixed status, the same the COA's Households shows (invariant 15: Waitlist, Registered,
 * Placed, Checked in, Checked out, Didn't come, Cancelled); the flags that matter to a room (noAdult: a
 * child entered at the desk with no grown-up, invariant 23; unpaid: kept placed though not paid); and
 * each hall Youngfolk's own linen packet (invariant 80).
 */
function ogc_lod_payload( $y, $list ) {
	$recs = ogc_lod_households( $y );
	$ctx  = function_exists( 'ogc_rec_ctx' ) ? ogc_rec_ctx( $y ) : null;
	foreach ( $list as &$x ) {
		$rec = isset( $recs[ $x['rid'] ] ) ? $recs[ $x['rid'] ] : null;
		if ( ! $rec ) {
			continue;
		}
		$d = $rec['data'];
		if ( $ctx && function_exists( 'ogc_rec_status_of' ) ) {
			$x['status'] = ogc_rec_status_of( $rec, $ctx );
		}
		// A note to Lodging is people's words, kept as typed, but an email or phone typed into it never
		// reaches Lodging (invariant 88; the import strips them too: rule 100; red team A4-23).
		foreach ( array( 'needs', 'near' ) as $f ) {
			if ( isset( $x['stay'][ $f ] ) && is_string( $x['stay'][ $f ] ) && '' !== $x['stay'][ $f ] && function_exists( 'ogc_lod_scrub' ) ) {
				$x['stay'][ $f ] = ogc_lod_scrub( $x['stay'][ $f ], 500 );
			}
		}
		// The flags as they are now, not as they were once set (red team round 3, X2-P1: "Not paid · Has a
		// room" kept after the household paid in full; X2-P2: "No grown-up" missing once the one grown-up
		// was taken off by a change).
		$f    = isset( $d['flags'] ) && is_array( $d['flags'] ) ? $d['flags'] : array();
		$keep = array_intersect_key( $f, array_flip( array( 'unpaid', 'changed' ) ) );
		if ( isset( $keep['unpaid'] ) && ( 'payment_due' !== ( isset( $d['status'] ) ? $d['status'] : '' ) || ! empty( $d['money']['paid'] ) || ! empty( $d['money']['check'] ) ) ) {
			unset( $keep['unpaid'] );
		}
		$kinds = array_map( function ( $p ) { return is_array( $p ) && isset( $p['kind'] ) ? (string) $p['kind'] : ''; }, (array) ( isset( $d['people'] ) ? $d['people'] : array() ) );
		if ( in_array( 'child', $kinds, true ) && ! in_array( 'adult', $kinds, true ) ) {
			$keep['noAdult'] = true;
		}
		$x['flags'] = (object) $keep;
		// The registration's version as the board read it: Looks right names it, so a change the board
		// hasn't shown is never marked seen (red team round 2, ATK1-r2-stale-looks-right).
		$x['regv'] = (int) ( isset( $d['_v'] ) ? $d['_v'] : 0 );
		$lin        = array();
		foreach ( (array) ( isset( $d['people'] ) ? $d['people'] : array() ) as $p ) {
			if ( ! empty( $p['pid'] ) ) {
				$lin[ (string) $p['pid'] ] = ! empty( $p['linens'] );
			}
		}
		foreach ( $x['people'] as &$p ) {
			$p['linens'] = isset( $lin[ $p['pid'] ] ) ? $lin[ $p['pid'] ] : false;
		}
		unset( $p );
	}
	unset( $x );
	return $list;
}

/** The Conference before this one that has a year in the table (for last year's notes). */
function ogc_lod_prev_year( $y ) {
	foreach ( ogc_years_list() as $x ) {
		if ( (int) $x < (int) $y && ogc_year_get( $x ) && ! empty( ogc_year_get( $x )['end'] ) ) {
			return (int) $x;
		}
	}
	return 0;
}

/** Last year's Notes for next year (members of this year may read them: they were written for them). */
function ogc_lod_prev_parts( $prev ) {
	$notes = array();
	foreach ( ogc_lod_rows( $prev, 'note:' ) as $k => $r ) {
		$notes[] = array( 'id' => substr( $k, 5 ), 'text' => isset( $r['data']['text'] ) ? ( function_exists( 'ogc_lod_scrub' ) ? ogc_lod_scrub( (string) $r['data']['text'], 600 ) : $r['data']['text'] ) : '', 'by' => isset( $r['data']['by'] ) ? $r['data']['by'] : '', 'at' => isset( $r['data']['at'] ) ? $r['data']['at'] : '', 'tab' => isset( $r['data']['tab'] ) ? $r['data']['tab'] : '' );
	}
	return array( 'notes' => $notes );
}

/**
 * Rooms' own facts carried from the last year at the same campus (accessible, beds, out of service).
 * This year's own facts are laid over them, room by room (the board's L.fact, ogc_lod_facts), so one
 * fact set this year never drops the rest (invariant 38). Holds are each year's own and never carried.
 */
function ogc_lod_carry( $y, $venue = null ) {
	$row = ogc_year_get( $y );
	$v   = null !== $venue ? (string) $venue : ( $row && ! empty( $row['venue'] ) ? $row['venue'] : '' );
	if ( '' === $v ) {
		return null;
	}
	foreach ( ogc_years_list() as $x ) {
		$r = ogc_year_get( $x );
		if ( (int) $x < $y && $r && isset( $r['venue'] ) && $r['venue'] === $v ) {
			$facts = array();
			foreach ( ogc_lod_rows( $x, 'room:' ) as $k => $rr ) {
				$d = array_filter( array_intersect_key( (array) $rr['data'], array_flip( array( 'access', 'beds', 'out' ) ) ) );
				if ( $d ) {
					$facts[ substr( $k, 5 ) ] = $d;
				}
			}
			return $facts ? array( 'year' => (int) $x, 'rooms' => $facts ) : null;
		}
	}
	return null;
}

/* ================================================================== changing rows */

/**
 * A household's rooms in place: Lodging's rooms[i] is the real room for the form's Room i+1, '' where
 * that room has none yet (invariant 19). A list sent with an empty place in it is taken as sent;
 * otherwise each room the household keeps stays in its place, and new rooms fill the empty places first,
 * then go on the end. So freeing Room 1 of two never moves Room 2's people or keys onto it.
 */
function ogc_lod_place_rooms( $in, $old ) {
	$in  = array_map( 'strval', array_slice( array_values( (array) $in ), 0, 8 ) );
	$old = array_map( 'strval', array_values( (array) $old ) );
	$out = array();
	if ( in_array( '', $in, true ) ) {
		$seen = array();
		foreach ( $in as $r ) {
			$out[]      = '' === $r || isset( $seen[ $r ] ) ? '' : $r;
			$seen[ $r ] = true;
		}
	} else {
		$want = array_values( array_unique( $in ) );
		foreach ( $old as $i => $r ) {
			$out[ $i ] = '' !== $r && in_array( $r, $want, true ) ? $r : '';
		}
		$new = array_values( array_diff( $want, $out ) );
		foreach ( $out as $i => $r ) {
			if ( '' === $r && $new ) {
				$out[ $i ] = array_shift( $new );
			}
		}
		foreach ( $new as $r ) {
			$out[] = $r;
		}
	}
	while ( $out && '' === end( $out ) ) {
		array_pop( $out );
	}
	return array_values( array_slice( $out, 0, 8 ) );
}

/** The first name, for a refusal ("Sam"). */
function ogc_lod_first( $name ) {
	return (string) strtok( trim( (string) $name ), ' ' );
}

/** May this person take a room's keys (Lodging Q10 waits): a grown-up, or a Youngfolk 18 and up. */
function ogc_lod_key_holder( $p ) {
	$kind = isset( $p['kind'] ) ? $p['kind'] : ( ! empty( $p['yf'] ) ? 'yf' : 'adult' );
	return 'adult' === $kind || ( 'yf' === $kind && empty( $p['minor'] ) && '' !== (string) ( isset( $p['age'] ) ? $p['age'] : '' ) );
}

/** The day the desk opens: the Conference's first day, or the first early night before it, offered by
 * the COA ("Early Thursday": the Thursday before) or on the household's own registration ($d: a night it
 * chose while it was offered stays its night: red team B2). */
function ogc_lod_desk_opens( $y, $d = null ) {
	// For a household: the day of its own first night (red team round 2, B3, B3b: checked in a day or two
	// before its nights, its room was slept in and never counted).
	if ( is_array( $d ) && function_exists( 'ogc_lod_first_night' ) ) {
		$f = ogc_lod_first_night( $y, $d );
		if ( $f ) {
			return $f['date'];
		}
	}
	$row   = ogc_year_get( $y );
	$start = $row && ! empty( $row['start'] ) ? (string) $row['start'] : '';
	if ( '' === $start ) {
		return '';
	}
	$open   = $start;
	$nights = function_exists( 'ogc_reg_nights' ) ? ogc_reg_nights( ogc_reg_cfg( $y ) ) : array();
	if ( is_array( $d ) ) {
		$nights = array_merge( $nights, (array) ( isset( $d['stay']['nights'] ) ? $d['stay']['nights'] : array() ) );
		foreach ( (array) ( isset( $d['people'] ) ? $d['people'] : array() ) as $p ) {
			$nights = array_merge( $nights, (array) ( isset( $p['nights'] ) ? $p['nights'] : array() ) );
		}
	}
	foreach ( array_unique( $nights ) as $n ) {
		if ( 0 !== strpos( (string) $n, 'Early ' ) ) {
			continue;
		}
		$want = strtolower( substr( (string) $n, 6 ) );
		for ( $k = 1; $k < 7; $k++ ) {
			$d2 = ogc_lod_add_days( $start, -$k );
			if ( strtolower( gmdate( 'l', strtotime( $d2 . ' 12:00:00 UTC' ) ) ) === $want ) {
				$open = min( $open, $d2 );
				break;
			}
		}
	}
	return $open;
}

/** Why this household may not be at the desk or given rooms now, in words ('' when it may). */
function ogc_lod_not_coming( $hh, $ctx ) {
	if ( ! ogc_lod_holds( $hh, $ctx['marks'] ) ) {
		return ogc_lod_why( $hh['data'], $ctx['marks'] );
	}
	return 'waitlist' === ( isset( $hh['data']['status'] ) ? $hh['data']['status'] : '' ) ? 'On the waiting list' : '';
}

/** A row's data cleaned, with the server's own marks (who, when) kept or added. Returns array, null or WP_Error. */
function ogc_lod_clean( $y, $key, $in, $old, $ctx ) {
	if ( null === $in ) {
		return null;
	}
	if ( ! is_array( $in ) ) {
		return ogc_lod_err( 'ogc_bad', 'Not saved · Bad row', 400 );
	}
	$old   = is_array( $old ) ? $old : array();
	$me    = $ctx['me'];
	$now   = ogc_now();
	$stamp = function ( $was ) use ( $me, $now ) {
		return is_array( $was ) && ! empty( $was['at'] ) ? array( 'by' => $was['by'], 'at' => $was['at'] ) : array( 'by' => $me, 'at' => $now );
	};
	$str   = function ( $v, $max ) {
		return mb_substr( trim( wp_strip_all_tags( (string) $v ) ), 0, $max );
	};
	list( $kind, $id ) = explode( ':', $key, 2 );

	if ( 'hh' === $kind ) {
		$hh = isset( $ctx['hh'][ $id ] ) ? $ctx['hh'][ $id ] : null;
		if ( ! $hh ) {
			return ogc_lod_err( 'ogc_bad', 'Household not found', 404 );
		}
		$out   = array();
		$was   = array_map( 'strval', array_values( (array) ( isset( $old['rooms'] ) ? $old['rooms'] : array() ) ) );
		$rooms = ogc_lod_place_rooms( isset( $in['rooms'] ) ? $in['rooms'] : array(), $was );
		foreach ( $rooms as $r ) {
			// A room already held stays (a halls change may have taken it away: the board says so); a new one must be in the halls.
			if ( '' !== $r && ! isset( $ctx['rooms'][ $r ] ) && ! in_array( $r, $was, true ) ) {
				return ogc_lod_err( 'ogc_bad', ogc_lod_room_words( $r ) . ' · Not in the halls', 400 );
			}
		}
		$added = array_values( array_diff( array_filter( $rooms ), $was ) );
		if ( $added ) {
			// Only a household in dorm rooms, not cancelled, not Didn't come, and not on the waiting list
			// (its place is offered first: area-lodging L22) is given a room. Unplacing is always taken.
			if ( ! ogc_lod_holds( $hh, $ctx['marks'] ) ) {
				return ogc_lod_err( 'ogc_not_dorm', ogc_lod_why( $hh['data'], $ctx['marks'] ) . ' · No rooms', 409 );
			}
			if ( 'waitlist' === ( isset( $hh['data']['status'] ) ? $hh['data']['status'] : '' ) ) {
				return ogc_lod_err( 'ogc_waitlist', 'On the waiting list · Offer place first', 409 );
			}
		}
		// Once checked in, rooms stay as they are until the check-in is undone (Lodging Q8 waits: a key swap at the desk).
		if ( $rooms !== $was && ! empty( $old['checkin']['at'] ) ) {
			return ogc_lod_err( 'ogc_checked_in', 'Checked in · Undo check-in first', 409 );
		}
		// Looks right takes the registration as it is now as seen: only from a screen that showed it, by its
		// version (red team round 2, ATK1-r2-stale-looks-right: "No stairs" asked after the board loaded was
		// marked seen though no screen showed it).
		$looks = ! empty( $in['snap'] ) && true === $in['snap'];
		if ( $looks && $rooms && ! empty( $old['snap'] ) && ( ! isset( $in['regv'] ) || (int) $in['regv'] !== (int) ( isset( $hh['data']['_v'] ) ? $hh['data']['_v'] : 0 ) ) ) {
			return ogc_lod_err( 'ogc_conflict', 'Changed since · Reload', 409 );
		}
		if ( $rooms ) {
			$out['rooms'] = $rooms;
			$out['given'] = ( $was === $rooms && isset( $old['given'] ) ) ? $old['given'] : array( 'by' => $me, 'at' => $now );
			// What the registration said when its rooms were given; again when Lodging says Looks right to a change.
			$out['snap'] = $looks || empty( $old['snap'] ) ? ogc_lod_snap( $hh['data'] ) : $old['snap'];
		} elseif ( ogc_lod_decided( $old ) ) {
			// Lodging decided this household's rooms once: a room it chose on the map never counts again.
			$out['cleared'] = ! empty( $old['cleared'] ) ? $old['cleared'] : array( 'by' => $me, 'at' => $now );
		}
		// Rooms a registration change freed (ogc_lod_release): kept until Lodging says Looks right, but none
		// Lodging has given back since (red team round 2, A1: placed again in the room it was freed from,
		// Your sign-ups showed no room).
		if ( ! empty( $old['freed'] ) && ! empty( $in['freed'] ) ) {
			$out['freed'] = $old['freed'];
			if ( isset( $out['freed']['rooms'] ) ) {
				$out['freed']['rooms'] = array_values( array_diff( array_map( 'strval', (array) $out['freed']['rooms'] ), array_filter( $rooms ) ) );
				if ( ! $out['freed']['rooms'] ) {
					unset( $out['freed'] );
				}
			}
		}
		if ( ! empty( $in['older'] ) ) {
			$out['older'] = $stamp( isset( $old['older'] ) ? $old['older'] : null );
		}
		if ( ! empty( $in['ok']['sig'] ) ) {
			$sig       = $str( $in['ok']['sig'], 400 );
			$out['ok'] = isset( $old['ok']['sig'] ) && $old['ok']['sig'] === $sig ? $old['ok'] : array( 'sig' => $sig, 'by' => $me, 'at' => $now );
		}
		if ( ! empty( $in['near'] ) && isset( $ctx['hh'][ (string) $in['near'] ] ) && (string) $in['near'] !== $id ) {
			$out['near'] = (string) $in['near'];
		}
		if ( isset( $in['note'] ) && '' !== $str( $in['note'], 500 ) ) {
			$out['note'] = $str( $in['note'], 500 );
		}
		$people = array();
		foreach ( (array) ( isset( $hh['data']['people'] ) ? $hh['data']['people'] : array() ) as $p ) {
			if ( ! empty( $p['name'] ) ) {
				$people[ $p['name'] ] = $p;
			}
		}
		// Keys go to a grown-up of the household, or a Youngfolk 18 and up (invariant 20); a name not on the
		// registration isn't kept.
		$holder = function ( $n ) use ( $people ) {
			if ( ! isset( $people[ (string) $n ] ) ) {
				return null;
			}
			return ogc_lod_key_holder( $people[ (string) $n ] ) ? true : ogc_lod_err( 'ogc_keys', 'Keys · ' . ogc_lod_first( $n ) . ' is under 18', 400 );
		};
		if ( ! empty( $in['keys'] ) && is_array( $in['keys'] ) ) {
			foreach ( $in['keys'] as $i => $n ) {
				$ok = $holder( $n );
				if ( is_wp_error( $ok ) ) {
					return $ok;
				}
				if ( $ok && is_numeric( $i ) && (int) $i >= 0 && (int) $i < 8 ) {
					$out['keys'][ (int) $i ] = (string) $n;
				}
			}
		}
		if ( ! empty( $in['checkin'] ) ) {
			if ( ! empty( $old['checkin']['at'] ) ) {
				$out['checkin'] = $old['checkin'];
			} else {
				// The desk checks in a household that will come, with a room, from the desk's first night
				// (invariant 53); after check-out morning, until names are cleared, to record what happened (58).
				$no = ogc_lod_not_coming( $hh, $ctx );
				if ( '' !== $no ) {
					return ogc_lod_err( 'ogc_not_now', $no . ' · No check-in', 409 );
				}
				$real = ogc_lod_real( $rooms, $ctx['rooms'] );
				if ( ! $real ) {
					return ogc_lod_err( 'ogc_not_now', 'No room · Place first', 409 );
				}
				$opens = ogc_lod_desk_opens( $y, $hh['data'] );
				if ( $opens && $ctx['today'] < $opens ) {
					$year_opens = ogc_lod_desk_opens( $y );
					$first      = function_exists( 'ogc_lod_first_night' ) ? ogc_lod_first_night( $y, $hh['data'] ) : null;
					return ogc_lod_err( 'ogc_not_now', $ctx['today'] < $year_opens || ! $first ? 'Desk opens ' . ogc_lod_md( $year_opens ? $year_opens : $opens ) : 'First night ' . $first['night'] . ' · Change nights first', 409 );
				}
				// Not after the household's own last night, during the Conference (red team round 3, X2-B1: a
				// household of Friday and Saturday checked in on Monday, keys out for a room Counts had on no
				// night). After the Conference a check-in is recorded late, for what happened (rule 58).
				$ph   = ogc_lod_phase( $y, $ctx['today'] );
				$last = function_exists( 'ogc_lod_last_night' ) ? ogc_lod_last_night( $y, $hh['data'] ) : null;
				if ( ! $ph['held'] && $last && $last['date'] < $ctx['today'] ) {
					return ogc_lod_err( 'ogc_not_now', 'Last night ' . $last['night'] . ' · Change nights first', 409 );
				}
				// Never the keys of a room out of service (red team round 2, H2: handed out without a word).
				foreach ( $real as $r ) {
					if ( ! empty( $ctx['facts'][ $r ]['out'] ) ) {
						return ogc_lod_err( 'ogc_room_out', ogc_lod_room_words( $r ) . ' · Out of service · Move them first', 409 );
					}
				}
				$keys = array();
				foreach ( (array) ( isset( $in['checkin']['keys'] ) ? $in['checkin']['keys'] : array() ) as $r => $n ) {
					$ok = $holder( $n );
					if ( is_wp_error( $ok ) ) {
						return $ok;
					}
					if ( $ok && in_array( (string) $r, $real, true ) ) {
						$keys[ (string) $r ] = (string) $n;
					}
				}
				// The day it happened, as the desk's day (a preview date plays one): the nights it slept are
				// counted from it (ogc_lod_slept). Recorded after the Conference: late.
				$out['checkin'] = array( 'at' => $now, 'by' => $me, 'day' => $ctx['today'], 'keys' => (object) $keys );
				if ( $ph['held'] ) {
					$out['checkin']['late'] = true;
				}
			}
		}
		// The desk's marks are for the household's own rooms only (red team D3: keys out, room setup and
		// keys back were kept for another household's room).
		$own = array_flip( array_filter( $rooms ) );
		// Keys handed out at check-in, per room (one a room unless the desk says more).
		if ( ! empty( $in['keysout'] ) && is_array( $in['keysout'] ) ) {
			foreach ( $in['keysout'] as $r => $n ) {
				if ( isset( $own[ (string) $r ] ) && is_numeric( $n ) ) {
					$out['keysout'][ (string) $r ] = max( 0, min( 12, (int) $n ) );
				}
			}
		}
		if ( ! empty( $in['back'] ) && is_array( $in['back'] ) ) {
			foreach ( $in['back'] as $r => $v ) {
				if ( $v && isset( $own[ (string) $r ] ) ) {
					$out['back'][ (string) $r ] = isset( $old['back'][ (string) $r ] ) ? $old['back'][ (string) $r ] : array( 'by' => $me, 'at' => $now, 'day' => $ctx['today'] );
				}
			}
		}
		// Leaving early (keys back before the last night): the first night not used, one of theirs (invariant 59).
		if ( ! empty( $in['left']['night'] ) ) {
			$night = $str( $in['left']['night'], 24 );
			$ns    = function_exists( 'ogc_lod_nights_dated' ) ? array_keys( ogc_lod_nights_dated( $y, $hh['data'] ) ) : (array) ( isset( $hh['data']['stay']['nights'] ) ? $hh['data']['stay']['nights'] : array() );
			if ( ! in_array( $night, array_map( 'strval', $ns ), true ) ) {
				return ogc_lod_err( 'ogc_bad', $night . ' · Not one of their nights', 400 );
			}
			$out['left'] = isset( $old['left']['night'] ) && $old['left']['night'] === $night ? $old['left'] : array( 'night' => $night, 'by' => $me, 'at' => $now );
		}
		// Keys back and the first night not used belong to a check-in (red team H2: recorded in November,
		// the household was Checked out the moment it checked in). Undoing the check-in takes them with it.
		if ( empty( $out['checkin']['at'] ) ) {
			$was_back = isset( $old['back'] ) ? (array) $old['back'] : array();
			$fresh    = ( ! empty( $out['back'] ) && array_diff_key( $out['back'], $was_back ) ) || ( ! empty( $out['left'] ) && empty( $old['left'] ) );
			if ( $fresh && empty( $old['checkin']['at'] ) ) {
				return ogc_lod_err( 'ogc_not_now', 'Not checked in · Check in first', 409 );
			}
			unset( $out['back'], $out['left'], $out['keysout'] );
		}
		// The first night not used, when the desk records it: every room's keys back (one room's keys back
		// while someone stays in the other isn't the household leaving: red team round 3, X2-D2), not before
		// the night it checked in (X2-D1: "Friday not used" for a household that came Sunday), and not after
		// the first of its nights from today on (its keys are back: the nights before it aren't slept).
		if ( ! empty( $out['left'] ) && ! empty( $out['checkin']['at'] ) && ( empty( $old['left']['night'] ) || $old['left']['night'] !== $out['left']['night'] ) ) {
			foreach ( ogc_lod_real( $rooms, $ctx['rooms'] ) as $r ) {
				if ( empty( $out['back'][ $r ] ) ) {
					return ogc_lod_err( 'ogc_keys_out', ogc_lod_room_words( $r ) . ' · Keys out · Take them back first', 409 );
				}
			}
			$own   = function_exists( 'ogc_lod_nights_dated' ) ? ogc_lod_nights_dated( $y, $hh['data'] ) : array();
			$ld    = isset( $own[ $out['left']['night'] ] ) ? $own[ $out['left']['night'] ] : '';
			$cin   = ! empty( $out['checkin']['late'] ) ? ( $own ? reset( $own ) : '' ) : ogc_lod_desk_day( $out['checkin'] );
			if ( '' !== $ld && '' !== $cin && $ld < $cin ) {
				return ogc_lod_err( 'ogc_bad', $out['left']['night'] . ' · Before their check-in', 400 );
			}
			$next = '';
			foreach ( $own as $n => $date ) {
				if ( $date >= $ctx['today'] ) {
					$next = $n;
					break;
				}
			}
			if ( '' !== $ld && '' !== $next && $ld > $own[ $next ] ) {
				return ogc_lod_err( 'ogc_bad', $out['left']['night'] . ' · Keys are back · ' . $next . ' at the latest', 400 );
			}
		}
		if ( ! empty( $in['setup'] ) && is_array( $in['setup'] ) ) {
			foreach ( $in['setup'] as $r => $v ) {
				if ( isset( $own[ (string) $r ] ) && is_array( $v ) ) {
					$out['setup'][ (string) $r ] = array( 'l' => max( 0, min( 24, (int) ( isset( $v['l'] ) ? $v['l'] : 0 ) ) ), 'm' => max( 0, min( 8, (int) ( isset( $v['m'] ) ? $v['m'] : 0 ) ) ) );
				}
			}
		}
		// The desk's check-in undone for a household that may no longer hold rooms (moved to the camper lot
		// or cancelled while its keys were out): its rooms are freed now, and named (red team round 2, I4:
		// a camper read Placed and its room was given again).
		if ( ! empty( $old['checkin']['at'] ) && empty( $out['checkin']['at'] ) && ! empty( $out['rooms'] ) && ! ogc_lod_holds( $hh, $ctx['marks'] ) ) {
			$out['freed'] = array( 'rooms' => array_values( array_filter( $out['rooms'] ) ), 'list' => $out['rooms'], 'why' => ogc_lod_why( $hh['data'], $ctx['marks'] ), 'by' => '' !== $me ? $me : 'Lodging', 'at' => $now );
			$out['cleared'] = array( 'by' => $me, 'at' => $now );
			unset( $out['rooms'], $out['given'], $out['keys'], $out['setup'] );
		}
		return $out ? $out : null;
	}

	if ( 'yf' === $kind ) {
		if ( ! isset( $ctx['yf'][ $id ] ) ) {
			return ogc_lod_err( 'ogc_bad', 'Youngfolk not found', 404 );
		}
		$yfp  = ogc_lod_yf_people( $ctx );
		$p    = $yfp[ $id ]['p'];
		$hh   = $ctx['hh'][ $yfp[ $id ]['rid'] ];
		$out  = array();
		$room = isset( $in['room'] ) ? (string) $in['room'] : '';
		$was  = isset( $old['room'] ) ? (string) $old['room'] : '';
		if ( '' !== $room && $room !== $was ) {
			$hall = isset( $ctx['rooms'][ $room ] ) ? ogc_lod_yf_hall_of( $ctx['rooms'][ $room ] ) : '';
			if ( ! isset( $ctx['rooms'][ $room ] ) ) {
				return ogc_lod_err( 'ogc_bad', ogc_lod_room_words( $room ) . ' · Not in the halls', 400 );
			}
			if ( '' === $hall ) {
				return ogc_lod_err( 'ogc_bad', 'Not a Youngfolks room', 400 );
			}
			$first = ogc_lod_first( $p['name'] );
			$mine  = isset( $p['yfHall'] ) ? (string) $p['yfHall'] : '';
			// Only a Youngfolk in a hall, with the hall set, in that hall (invariants 26, 28, 35).
			if ( '' === $mine ) {
				return ogc_lod_err( 'ogc_no_hall', 'Hall not set · ' . $first, 409 );
			}
			if ( $hall !== $mine ) {
				return ogc_lod_err( 'ogc_bad', ( 'men' === $hall ? 'Young men’s hall' : 'Young women’s hall' ) . ' · Not for ' . $first, 400 );
			}
			if ( ! ogc_lod_in_hall( $p, $hh['data'] ) ) {
				return ogc_lod_err( 'ogc_not_hall', 'With the family · No hall room', 409 );
			}
			$no = ogc_lod_not_coming( array( 'data' => array_merge( $hh['data'], array( 'stay' => array( 'type' => 'dorm' ) ) ) ), $ctx );
			if ( '' !== $no ) {
				return ogc_lod_err( 'waitlist' === $hh['data']['status'] ? 'ogc_waitlist' : 'ogc_not_now', 'On the waiting list' === $no ? 'On the waiting list · Offer place first' : $no . ' · No hall room', 409 );
			}
			// An under-18 Youngfolk a parent must approve gets a room once they have (Lodging Q5 waits: invariant
			// 34), and only someone the parent's yes named (red team round 3, ATK3 A1).
			if ( ogc_lod_approval_waits( $p, $hh['data'] ) ) {
				$aw = ogc_lod_approval_words( $p, $hh['data'] );
				return ogc_lod_err( 'ogc_approval', 'Approval waiting' === $aw ? 'Parent approval waiting' : $aw . ' · No hall room', 409 );
			}
			// An age the Google Form left out is held, never guessed (red team B3, B4): not where the state's
			// age rule applies, and not for a Youngfolk with no grown-up on the registration (a parent may
			// need to approve). The Form's Check says "No age"; the age comes with the next upload.
			if ( '' === trim( (string) ( isset( $p['age'] ) ? $p['age'] : '' ) ) ) {
				$grown = array_filter( (array) ( isset( $hh['data']['people'] ) ? $hh['data']['people'] : array() ), function ( $q ) { return 'adult' === ( isset( $q['kind'] ) ? $q['kind'] : '' ); } );
				if ( ! $grown || 'yes' === strtolower( trim( isset( $ctx['cfg']['yf_age_split'] ) ? (string) $ctx['cfg']['yf_age_split'] : '' ) ) ) {
					return ogc_lod_err( 'ogc_age', 'Age not known · ' . $first, 409 );
				}
			}
			// Under the COA's age for Youngfolks (yf_min_age), the form says Child: never a hall room (red team
			// round 2, K3_A2: a 12-year-old from the Google Form was given one).
			// Read as the form reads it: blank is 16 (red team round 3, ATK3 A3).
			$min = ogc_lod_yf_min( $ctx['cfg'] );
			if ( $min && is_numeric( isset( $p['age'] ) ? $p['age'] : '' ) && (int) $p['age'] < $min ) {
				return ogc_lod_err( 'ogc_age', 'Under ' . $min . ' · No hall room', 409 );
			}
		}
		if ( '' !== $room ) {
			$out['room'] = $room;
		}
		if ( ! empty( $old['freed'] ) && ! empty( $in['freed'] ) ) {
			$out['freed'] = $old['freed'];
		}
		if ( ! empty( $in['mate'] ) && ( 'none' === $in['mate'] || ( isset( $ctx['yf'][ (string) $in['mate'] ] ) && (string) $in['mate'] !== $id ) ) ) {
			$out['mate'] = (string) $in['mate'];   // "none": Lodging unpaired them
		}
		if ( ! empty( $in['ok']['sig'] ) ) {
			$sig       = $str( $in['ok']['sig'], 400 );
			$out['ok'] = isset( $old['ok']['sig'] ) && $old['ok']['sig'] === $sig ? $old['ok'] : array( 'sig' => $sig, 'by' => $me, 'at' => $now );
		}
		if ( ! empty( $in['out'] ) ) {
			// The hall key goes to a Youngfolk with a hall room, who will come, from their first night (red team
			// round 2, D3: Key out was kept in November for a cancelled Youngfolk with no room).
			if ( empty( $old['keyout'] ) ) {
				if ( empty( $out['room'] ) || ! isset( $ctx['rooms'][ (string) $out['room'] ] ) ) {
					return ogc_lod_err( 'ogc_not_now', 'No hall room · Place first', 409 );
				}
				$no = ogc_lod_yf_why_not( $p, $hh, $ctx['marks'] );
				if ( '' !== $no ) {
					return ogc_lod_err( 'ogc_not_now', $no . ' · No key', 409 );
				}
				if ( 'waitlist' === ( isset( $hh['data']['status'] ) ? $hh['data']['status'] : '' ) ) {
					return ogc_lod_err( 'ogc_not_now', 'On the waiting list · No key', 409 );
				}
				// Never the key to a room out of service, as the household desk refuses (red team round 3, X2-G1).
				if ( ! empty( $ctx['facts'][ (string) $out['room'] ]['out'] ) ) {
					return ogc_lod_err( 'ogc_room_out', ogc_lod_room_words( $out['room'] ) . ' · Out of service · Move them first', 409 );
				}
				// From the Youngfolk's own first night, not the household's (X2-G2: his father's Friday let
				// Cal's key out two nights before his own Sunday).
				$mine  = function_exists( 'ogc_reg_nights_for' ) ? array_map( 'strval', (array) ogc_reg_nights_for( $p, $hh['data'], ogc_reg_cfg( $y ) ) ) : array();
				$first = null;
				foreach ( $mine as $n ) {
					$date = function_exists( 'ogc_lod_night_on' ) ? ogc_lod_night_on( $y, $n ) : '';
					if ( '' !== $date && ( ! $first || $date < $first['date'] ) ) {
						$first = array( 'night' => $n, 'date' => $date );
					}
				}
				$opens = $first ? $first['date'] : ogc_lod_desk_opens( $y, $hh['data'] );
				if ( $opens && $ctx['today'] < $opens ) {
					$year_opens = ogc_lod_desk_opens( $y );
					return ogc_lod_err( 'ogc_not_now', $ctx['today'] < $year_opens || ! $first ? 'Desk opens ' . ogc_lod_md( $year_opens ? $year_opens : $opens ) : 'First night ' . $first['night'] . ' · Change nights first', 409 );
				}
			}
			$out['keyout'] = $stamp( isset( $old['keyout'] ) ? $old['keyout'] : null );
		}
		// While the key is out, the room stays (the key back first: rule 57's way, for a Youngfolk).
		if ( ! empty( $old['keyout'] ) && ! empty( $old['room'] ) && ! empty( $out['keyout'] ) && (string) $old['room'] !== ( isset( $out['room'] ) ? (string) $out['room'] : '' ) ) {
			return ogc_lod_err( 'ogc_checked_in', 'Key out · Undo key out first', 409 );
		}
		// The key back (Key out undone) for a Youngfolk who may no longer hold the room: freed now, named.
		if ( ! empty( $old['keyout'] ) && empty( $out['keyout'] ) && ! empty( $out['room'] ) ) {
			$no = ogc_lod_yf_why_not( $p, $hh, $ctx['marks'] );
			if ( '' !== $no ) {
				$out['freed'] = array( 'room' => (string) $out['room'], 'why' => $no, 'by' => $me, 'at' => $now );
				unset( $out['room'] );
			}
		}
		return $out ? $out : null;
	}

	if ( 'room' === $kind ) {
		if ( ! isset( $ctx['rooms'][ $id ] ) ) {
			return ogc_lod_err( 'ogc_bad', ogc_lod_room_words( $id ) . ' · Not in the halls', 400 );
		}
		// A room's facts are changed one at a time: a fact the op doesn't name stays as it is (red team round
		// 3, ATK1-r3-partial-room-op: an op naming only Accessible dropped the room's beds, 2 back to 3, and
		// a room sleeping three read as fine). null (or a blank Hold for) takes a fact off.
		$out = array();
		foreach ( array( 'hold', 'out', 'access', 'beds' ) as $f ) {
			if ( isset( $old[ $f ] ) ) {
				$out[ $f ] = $old[ $f ];
			}
		}
		if ( array_key_exists( 'hold', $in ) ) {
			$hv = null === $in['hold'] ? '' : $str( $in['hold'], 30 );
			if ( '' === $hv ) {
				unset( $out['hold'] );
			} else {
				$out['hold'] = $hv;
			}
		}
		foreach ( array( 'out', 'access' ) as $b ) {
			if ( ! array_key_exists( $b, $in ) ) {
				continue;
			}
			if ( false === $in[ $b ] ) {
				$out[ $b ] = false;   // this year, not what was carried from the last year here
			} elseif ( ! empty( $in[ $b ] ) ) {
				$out[ $b ] = true;
			} else {
				unset( $out[ $b ] );
			}
		}
		if ( array_key_exists( 'beds', $in ) ) {
			if ( null === $in['beds'] || '' === $in['beds'] ) {
				unset( $out['beds'] );
			} elseif ( ! is_numeric( $in['beds'] ) || (int) $in['beds'] < 1 || (float) $in['beds'] !== (float) (int) $in['beds'] ) {
				return ogc_lod_err( 'ogc_bad', 'Beds · 1 to 8', 400 );
			} else {
				$out['beds'] = min( 8, (int) $in['beds'] );
			}
		}
		return $out ? $out : null;
	}

	if ( 'note' === $kind ) {
		if ( ! preg_match( '/^[a-z0-9]{1,24}$/', $id ) ) {
			return ogc_lod_err( 'ogc_bad', 'Note not saved · Reload', 400 );
		}
		$text = $str( isset( $in['text'] ) ? $in['text'] : '', 600 );
		// People's words, but never a phone or an email (invariant 88, 100; red team round 2, R2A4-20).
		$text = function_exists( 'ogc_lod_scrub' ) ? ogc_lod_scrub( $text, 600 ) : $text;
		if ( '' === $text ) {
			return null;
		}
		$tab = isset( $in['tab'] ) && in_array( $in['tab'], array( 'rooms', 'yf', 'campers', 'checkin' ), true ) ? $in['tab'] : 'rooms';
		return isset( $old['text'] ) && $old['text'] === $text ? array_merge( $old, array( 'tab' => $tab ) ) : array( 'text' => $text, 'tab' => $tab, 'by' => $me, 'at' => $now );
	}

	if ( 'meta:steps' === $key || 'meta:notes_done' === $key ) {
		$out = array();
		foreach ( $in as $k => $v ) {
			if ( $v && preg_match( '/^[a-z0-9_-]{1,32}$/', (string) $k ) ) {
				$out[ (string) $k ] = $stamp( isset( $old[ $k ] ) ? $old[ $k ] : null );
			}
		}
		return $out ? $out : null;
	}
	return ogc_lod_err( 'ogc_bad', 'Not saved · Unknown row', 400 );
}

/** The context a change is checked against: rooms, their facts, households, Youngfolks, marks, who, today. */
function ogc_lod_ctx( $y, $req = null ) {
	$hh = ogc_lod_households( $y );
	$yf = array();
	foreach ( $hh as $rid => $rec ) {
		foreach ( (array) ( isset( $rec['data']['people'] ) ? $rec['data']['people'] : array() ) as $p ) {
			if ( ! empty( $p['yf'] ) && ! empty( $p['pid'] ) ) {
				$yf[ $p['pid'] ] = $rid;
			}
		}
	}
	$ctx        = array( 'y' => (int) $y, 'rooms' => ogc_lod_rooms( $y ), 'hh' => $hh, 'yf' => $yf, 'me' => ogc_lod_me(), 'marks' => ogc_lod_marks( $y ), 'facts' => ogc_lod_facts( $y ), 'today' => ogc_lod_today( $y, $req ), 'cfg' => ogc_lod_kv( $y, 'registration' ), 'chosen' => array() );
	$ctx['yfp'] = ogc_lod_yf_people( $ctx );
	// Where households choose their rooms on the map, the rooms each chose (ogc_lod_claims counts them for
	// a household Lodging hasn't given rooms: a room is never given to two: red team J1).
	if ( 'households' === ( isset( $ctx['cfg']['room_choice'] ) ? $ctx['cfg']['room_choice'] : '' ) ) {
		foreach ( $hh as $rid => $rec ) {
			$ch = isset( $rec['data']['stay']['chosen'] ) ? array_values( array_filter( array_map( 'strval', (array) $rec['data']['stay']['chosen'] ) ) ) : array();
			if ( $ch && 'dorm' === ( isset( $rec['data']['stay']['type'] ) ? $rec['data']['stay']['type'] : '' ) ) {
				$ctx['chosen'][ $rid ] = $ch;
			}
		}
	}
	return $ctx;
}

/** Lodging's rows that hold rooms, as data: rkey => data. */
function ogc_lod_claim_data( $y ) {
	$out = array();
	foreach ( ogc_lod_rows( $y ) as $k => $r ) {
		if ( 0 === strpos( $k, 'hh:' ) || 0 === strpos( $k, 'yf:' ) ) {
			$out[ $k ] = $r['data'];
		}
	}
	return $out;
}

/** Is the year past its Conference (no more changes)? Members may still print and download. */
function ogc_lod_held( $y, $req ) {
	$ph = ogc_lod_phase( $y, ogc_lod_today( $y, $req ) );
	return $ph['held'];
}

/**
 * After the Conference, rooms no longer move, but the desk keeps working until the names are cleared
 * (Check in, keys out, Keys back: the last morning is when most keys come back), and Notes for next
 * year can always be written. Is this change one of those?
 */
function ogc_lod_late_ok( $ph, $key, $old, $new ) {
	if ( 0 === strpos( $key, 'note:' ) || 'meta:notes_done' === $key ) {
		return true;
	}
	if ( $ph['cleared'] ) {
		return false;
	}
	if ( 'meta:steps' === $key ) {
		return true;
	}
	if ( 0 === strpos( $key, 'hh:' ) ) {
		return ogc_lod_desk_only( $old, $new );
	}
	if ( 0 === strpos( $key, 'yf:' ) ) {
		$a = array_diff_key( is_array( $old ) ? $old : array(), array( 'keyout' => 1 ) );
		$b = array_diff_key( is_array( $new ) ? $new : array(), array( 'keyout' => 1 ) );
		return ogc_lod_same( $a, $b );
	}
	return false;
}

/**
 * POST years/{y}/lodging/ops. Every op names the version it was made from (invariant 69: a change made
 * without one is refused, never written blind). Checked and written under Lodging's lock, so two members,
 * the desk or a registration change never interleave (70, 72): one change at a time sees the rows as they
 * are, and nothing has to be put back.
 */
function ogc_lod_rest_ops( WP_REST_Request $req ) {
	$y   = (int) $req['year'];
	$ops = (array) $req->get_param( 'ops' );
	if ( ! $ops || count( $ops ) > 400 ) {
		return ogc_lod_err( 'ogc_bad', 'Nothing to save', 400 );
	}
	$seen = array();
	foreach ( $ops as $op ) {
		$key = is_array( $op ) && isset( $op['key'] ) ? (string) $op['key'] : '';
		if ( ! ogc_lod_key_ok( $key ) || preg_match( '/^(undo|imp):|^meta:(published|mapping|numbers|seen|sent|lock)/', $key ) || isset( $seen[ $key ] ) ) {
			return ogc_lod_err( 'ogc_bad', 'Not saved · Unknown row', 400 );
		}
		if ( ! array_key_exists( 'v', $op ) || ! is_numeric( $op['v'] ) ) {
			return ogc_lod_err( 'ogc_bad', 'Not saved · Reload', 400 );
		}
		$seen[ $key ] = true;
	}
	$label = mb_substr( trim( wp_strip_all_tags( (string) $req->get_param( 'label' ) ) ), 0, 120 );
	if ( ! ogc_lod_lock( $y ) ) {
		return ogc_lod_busy();
	}
	try {
		$ph   = ogc_lod_phase( $y, ogc_lod_today( $y, $req ) );
		$ctx  = ogc_lod_ctx( $y, $req );
		$plan = array();
		foreach ( $ops as $op ) {
			$key = (string) $op['key'];
			$cur = ogc_lod_row( $y, $key );
			$v   = $cur ? $cur['v'] : 0;
			if ( (int) $op['v'] !== $v ) {
				// Said as it is (red team ATK1-retry-words): the same change sent again (a retry after a slow
				// answer) is saved already; one's own change made elsewhere; another member's.
				$msg = 'Changed by another member · Reload';
				if ( $cur && (int) $cur['by'] === get_current_user_id() ) {
					$same = ogc_lod_clean( $y, $key, array_key_exists( 'data', $op ) ? $op['data'] : null, $cur['data'], $ctx );
					$msg  = ! is_wp_error( $same ) && ogc_lod_same( null === $same ? array() : $same, $cur['data'] ) ? 'Saved already' : 'Changed since · Reload';
				}
				return ogc_lod_conflict( $y, $msg, array( $key ) );
			}
			$data = ogc_lod_clean( $y, $key, array_key_exists( 'data', $op ) ? $op['data'] : null, $cur ? $cur['data'] : null, $ctx );
			if ( is_wp_error( $data ) ) {
				return $data;
			}
			if ( $ph['held'] && ! ogc_lod_late_ok( $ph, $key, $cur ? $cur['data'] : null, $data ) ) {
				return ogc_lod_err( 'ogc_held', $ph['cleared'] ? 'Names cleared · No changes' : 'Conference over · Desk only', 403 );
			}
			$plan[ $key ] = array( 'before' => $cur, 'data' => $data, 'v' => $v );
		}
		// What the change would leave wrong is refused before anything is written.
		$bad = ogc_lod_check_plan( $ctx, ogc_lod_claim_data( $y ), array_map( function ( $p ) { return $p['data']; }, $plan ) );
		if ( is_wp_error( $bad ) ) {
			return 409 === ( isset( $bad->get_error_data()['status'] ) ? $bad->get_error_data()['status'] : 0 ) && 'ogc_conflict' === $bad->get_error_code() ? ogc_lod_conflict( $y, $bad->get_error_message(), array_keys( $plan ) ) : $bad;
		}
		$done = array();
		foreach ( $plan as $key => $p ) {
			if ( null === $p['data'] && ( ! $p['before'] || ! $p['before']['data'] ) ) {
				continue;
			}
			$r = ogc_lod_put( $y, $key, $p['data'], $p['v'] );
			if ( is_wp_error( $r ) ) {
				ogc_lod_rollback( $y, $done, $plan );
				return 'ogc_busy' === $r->get_error_code() ? $r : ogc_lod_conflict( $y, 'Changed by another member · Reload', array( $key ) );
			}
			$done[ $key ] = $r;
		}
		// Remember the change for Undo: each row as it was, and the version it is now.
		$id     = gmdate( 'ymdHis' ) . wp_rand( 100, 999 );
		$before = array();
		foreach ( $plan as $key => $p ) {
			$before[ $key ] = $p['before'] ? array( 'data' => $p['before']['data'] ) : null;
		}
		if ( $done ) {
			ogc_lod_put( $y, 'undo:' . $id, array( 'label' => $label, 'before' => $before, 'after' => $done ) );
			ogc_lod_prune( $y, 'undo:', 60 );
		}
	} finally {
		ogc_lod_unlock( $y );
	}
	ogc_log( 'lodging', $y, 'lodging', array( 'rows' => count( $done ), 'kinds' => array_values( array_unique( array_map( function ( $k ) { return strtok( $k, ':' ); }, array_keys( $done ) ) ) ) ) );
	$rows = array();
	foreach ( array_keys( $plan ) as $key ) {
		$r            = ogc_lod_row( $y, $key );
		$rows[ $key ] = $r ? array( 'data' => ogc_lod_out( $r['data'] ), 'v' => $r['v'], 'by' => ogc_lod_me(), 'at' => $r['at'] ) : null;
	}
	return rest_ensure_response( array( 'rows' => $rows, 'undo' => $done ? array( 'id' => $id, 'label' => $label, 'mine' => true, 'by' => ogc_lod_me() ) : null ) );
}

/** Put rows back as they were before a change that couldn't finish: each only if it's still as written. */
function ogc_lod_rollback( $y, $done, $plan ) {
	// Each row only at the version this change wrote, so nobody's later change is undone; this also when
	// the lock itself was lost (ogc_lod_put would refuse every write then).
	$held = isset( $GLOBALS['ogc_lod_held'][ (int) $y ] ) ? $GLOBALS['ogc_lod_held'][ (int) $y ] : null;
	unset( $GLOBALS['ogc_lod_held'][ (int) $y ] );
	foreach ( $done as $key => $v ) {
		$b = $plan[ $key ]['before'];
		ogc_lod_put( $y, $key, $b ? $b['data'] : null, (int) $v );
	}
	if ( null !== $held ) {
		$GLOBALS['ogc_lod_held'][ (int) $y ] = $held;
	}
}

/** 409 with the rows as they are now, so the page shows them and says what happened. */
function ogc_lod_conflict( $y, $msg, $keys ) {
	$rows = array();
	foreach ( $keys as $k ) {
		$r          = ogc_lod_row( $y, $k );
		$rows[ $k ] = $r ? array( 'data' => ogc_lod_out( $r['data'] ), 'v' => $r['v'], 'by' => ogc_lod_name_of( $r['by'] ), 'at' => $r['at'] ) : null;
	}
	return ogc_lod_err( 'ogc_conflict', $msg, 409, array( 'rows' => $rows ) );
}

/** Keep only the newest $keep rows with this prefix. */
function ogc_lod_prune( $y, $prefix, $keep ) {
	global $wpdb;
	$t   = ogc_table( 'lodging' );
	$ids = $wpdb->get_col( $wpdb->prepare( "SELECT id FROM $t WHERE year = %d AND rkey LIKE %s ORDER BY id DESC", $y, $wpdb->esc_like( $prefix ) . '%' ) );
	foreach ( array_slice( (array) $ids, $keep ) as $id ) {
		$wpdb->delete( $t, array( 'id' => (int) $id ), array( '%d' ) );
	}
}

/**
 * POST years/{y}/lodging/undo. Puts a change back only while nothing it touched changed since (75), and
 * only as far as the rules allow now (39): the rows as they were go through the same checks as a change
 * (the waiting list, a cancelled household, the halls, check-in) and the room checks, under the lock.
 */
function ogc_lod_rest_undo( WP_REST_Request $req ) {
	$y  = (int) $req['year'];
	$id = (string) $req->get_param( 'id' );
	if ( ! preg_match( '/^\d{12,20}$/', $id ) ) {
		return ogc_lod_err( 'ogc_bad', 'Nothing to undo', 400 );
	}
	if ( ! ogc_lod_lock( $y ) ) {
		return ogc_lod_busy();
	}
	try {
		$ph = ogc_lod_phase( $y, ogc_lod_today( $y, $req ) );
		$u  = ogc_lod_row( $y, 'undo:' . $id );
		if ( ! $u ) {
			return ogc_lod_err( 'ogc_gone', 'Nothing to undo', 404 );
		}
		$after  = (array) ( isset( $u['data']['after'] ) ? $u['data']['after'] : array() );
		$before = (array) ( isset( $u['data']['before'] ) ? $u['data']['before'] : array() );
		$ctx    = ogc_lod_ctx( $y, $req );
		$plan   = array();
		foreach ( $after as $key => $v ) {
			$cur = ogc_lod_row( $y, $key );
			if ( ( $cur ? $cur['v'] : 0 ) !== (int) $v ) {
				return ogc_lod_conflict( $y, 'Changed since · Can’t undo', array( $key ) );
			}
			$b    = isset( $before[ $key ] ) && is_array( $before[ $key ] ) ? $before[ $key ]['data'] : null;
			$data = $b;
			// The row as it was goes through every rule a change does now, check-in and its keys included
			// (red team ATK1-undo-checkin-keys, ATK1-undo-checkin-waitlist), and what's written is the row
			// so cleaned, with its own stamps (who and when) as they were.
			if ( null !== $b && preg_match( '/^(hh|yf|room):/', $key ) ) {
				$bb = (array) $b;
				if ( 0 === strpos( $key, 'room:' ) ) {
					// A room's facts are put back whole: one it didn't have then is taken off (a room op keeps
					// the facts it doesn't name).
					foreach ( array( 'hold', 'out', 'access', 'beds' ) as $f ) {
						if ( ! array_key_exists( $f, $bb ) ) {
							$bb[ $f ] = null;
						}
					}
				}
				$chk = ogc_lod_clean( $y, $key, $bb, $cur ? $cur['data'] : null, $ctx );
				if ( is_wp_error( $chk ) ) {
					if ( 404 !== (int) ( isset( $chk->get_error_data()['status'] ) ? $chk->get_error_data()['status'] : 0 ) ) {
						return ogc_lod_err( $chk->get_error_code(), $chk->get_error_message() . ' · Can’t undo', (int) $chk->get_error_data()['status'] );
					}
				} else {
					$data = ogc_lod_undo_stamps( $chk, (array) $b );
				}
			}
			if ( $ph['held'] && ! ogc_lod_late_ok( $ph, $key, $cur ? $cur['data'] : null, $data ) ) {
				return ogc_lod_err( 'ogc_held', 'Conference over · Desk only', 403 );
			}
			$plan[ $key ] = array( 'before' => $cur, 'data' => $data );
		}
		$bad = ogc_lod_check_plan( $ctx, ogc_lod_claim_data( $y ), array_map( function ( $p ) { return $p['data']; }, $plan ) );
		if ( is_wp_error( $bad ) ) {
			return ogc_lod_conflict( $y, $bad->get_error_message() . ' · Can’t undo', array_keys( $after ) );
		}
		$done = array();
		foreach ( $plan as $key => $p ) {
			$r = ogc_lod_put( $y, $key, $p['data'], $p['before'] ? $p['before']['v'] : 0 );
			if ( is_wp_error( $r ) ) {
				ogc_lod_rollback( $y, $done, $plan );
				return ogc_lod_conflict( $y, 'Changed since · Can’t undo', array( $key ) );
			}
			$done[ $key ] = $r;
		}
		ogc_lod_put( $y, 'undo:' . $id, null );
	} finally {
		ogc_lod_unlock( $y );
	}
	ogc_log( 'lodging_undo', $y, 'lodging', array( 'rows' => count( $done ) ) );
	$rows = array();
	foreach ( array_keys( $after ) as $key ) {
		$r            = ogc_lod_row( $y, $key );
		$rows[ $key ] = $r ? array( 'data' => ogc_lod_out( $r['data'] ), 'v' => $r['v'], 'by' => ogc_lod_me(), 'at' => $r['at'] ) : null;
	}
	return rest_ensure_response( array( 'rows' => $rows, 'label' => isset( $u['data']['label'] ) ? $u['data']['label'] : '' ) );
}

/** A row put back by Undo, cleaned by today's rules, keeps the stamps it had (who gave the rooms, checked
 * in, said Looks right, and when). */
function ogc_lod_undo_stamps( $data, $b ) {
	if ( ! is_array( $data ) || ! is_array( $b ) ) {
		return $data;
	}
	foreach ( array( 'given', 'snap', 'older', 'ok', 'keyout' ) as $f ) {
		if ( isset( $data[ $f ], $b[ $f ] ) ) {
			$data[ $f ] = $b[ $f ];
		}
	}
	if ( isset( $b['freed'] ) ) {
		$data['freed'] = $b['freed'];
	}
	if ( isset( $data['left']['night'], $b['left']['night'] ) && $data['left']['night'] === $b['left']['night'] ) {
		$data['left'] = $b['left'];
	}
	if ( isset( $data['checkin'], $b['checkin']['at'] ) ) {
		$data['checkin']['at'] = $b['checkin']['at'];
		$data['checkin']['by'] = isset( $b['checkin']['by'] ) ? $b['checkin']['by'] : $data['checkin']['by'];
		// The day it was checked in, as it was (the nights slept are counted from it).
		unset( $data['checkin']['day'], $data['checkin']['late'] );
		foreach ( array( 'day', 'late' ) as $f ) {
			if ( isset( $b['checkin'][ $f ] ) ) {
				$data['checkin'][ $f ] = $b['checkin'][ $f ];
			}
		}
	}
	if ( isset( $data['back'], $b['back'] ) && is_array( $data['back'] ) ) {
		foreach ( $data['back'] as $r => $st ) {
			if ( isset( $b['back'][ $r ] ) ) {
				$data['back'][ $r ] = $b['back'][ $r ];
			}
		}
	}
	return $data;
}

/* ================================================================== publishing */

/**
 * The rooms households would see now: { rid: [room ids] }. Households that will come only (invariant 47:
 * not the waiting list, not Didn't come, not cancelled), rooms in the halls only, and never a room held
 * wrongly (twice): that one waits until Lodging fixes it.
 */
function ogc_lod_snapshot( $y ) {
	$ctx  = ogc_lod_ctx( $y );
	$bad  = array();
	foreach ( ogc_lod_conflicts( $y, $ctx ) as $c ) {
		$bad[ $c['room'] ] = true;
	}
	$snap = array();
	foreach ( ogc_lod_rows( $y, 'hh:' ) as $k => $r ) {
		$rid = substr( $k, 3 );
		if ( ! isset( $ctx['hh'][ $rid ] ) || ! ogc_lod_coming( $ctx['hh'][ $rid ], $ctx['marks'] ) ) {
			continue;
		}
		$list = array_values( array_filter( ogc_lod_real( isset( $r['data']['rooms'] ) ? $r['data']['rooms'] : array(), $ctx['rooms'] ), function ( $id ) use ( $bad ) { return ! isset( $bad[ $id ] ); } ) );
		if ( $list ) {
			$snap[ $rid ] = $list;
		}
	}
	return $snap;
}

/** POST years/{y}/lodging/publish {mode, email}: under Lodging's lock, so two at once never leave what
 * households see and Lodging's record of it apart (invariant 77). Refused while a room is held wrongly. */
function ogc_lod_rest_publish( WP_REST_Request $req ) {
	$y = (int) $req['year'];
	if ( ogc_lod_held( $y, $req ) ) {
		return ogc_lod_err( 'ogc_held', 'Held · No changes', 403 );
	}
	$mode  = (string) $req->get_param( 'mode' );
	$email = (bool) $req->get_param( 'email' );
	$today = ogc_lod_today( $y, $req );
	if ( ! in_array( $mode, array( 'publish', 'update', 'unpublish' ), true ) ) {
		return ogc_lod_err( 'ogc_bad', 'Not published', 400 );
	}
	if ( ! ogc_lod_lock( $y ) ) {
		return ogc_lod_busy();
	}
	try {
		$pub = ogc_lod_row( $y, 'meta:published' );
		$was = $pub && ! empty( $pub['data']['snap'] ) ? (array) $pub['data']['snap'] : array();
		if ( 'unpublish' === $mode ) {
			ogc_state_put( $y, 'rooms', (object) array() );
			ogc_file_patch( $y, 'registration', array( 'op' => 'key', 'key' => 'rooms_posted', 'value' => '' ) );
			ogc_lod_put( $y, 'meta:published', array( 'date' => '', 'off' => array( 'by' => ogc_lod_me(), 'at' => ogc_now() ), 'first' => $pub && isset( $pub['data']['first'] ) ? $pub['data']['first'] : '' ) );
			ogc_log( 'lodging_unpublish', $y, 'rooms', array() );
			return rest_ensure_response( array( 'published' => ogc_lod_row( $y, 'meta:published' )['data'], 'notified' => 0 ) );
		}
		$wrong = ogc_lod_conflicts( $y );
		if ( $wrong ) {
			return ogc_lod_err( 'ogc_conflict', 'Fix first · ' . $wrong[0]['words'] . ( count( $wrong ) > 1 ? ' · ' . ( count( $wrong ) - 1 ) . ' more' : '' ), 409 );
		}
		$snap = ogc_lod_snapshot( $y );
		if ( ! $snap ) {
			return ogc_lod_err( 'ogc_bad', 'No rooms given', 400 );
		}
		ogc_state_put( $y, 'rooms', (object) $snap );
		ogc_file_patch( $y, 'registration', array( 'op' => 'key', 'key' => 'rooms_posted', 'value' => $today ) );
		// Who to tell: everyone on a first publish; on an update, the households whose rooms changed.
		$tell = array();
		foreach ( array_unique( array_merge( array_keys( $snap ), array_keys( $was ) ) ) as $rid ) {
			$now  = isset( $snap[ $rid ] ) ? $snap[ $rid ] : array();
			$then = isset( $was[ $rid ] ) ? array_values( (array) $was[ $rid ] ) : array();
			if ( 'publish' === $mode && ! $was ? (bool) $now : $now !== $then ) {
				$tell[] = $rid;
			}
		}
		$data = array(
			'date'    => $today,
			'by'      => ogc_lod_me(),
			'at'      => ogc_now(),
			'first'   => $pub && ! empty( $pub['data']['first'] ) ? $pub['data']['first'] : $today,
			'snap'    => (object) $snap,
			'told'    => count( $tell ),
			'emailed' => $email,
		);
		ogc_lod_put( $y, 'meta:published', $data );
	} finally {
		ogc_lod_unlock( $y );
	}
	// The emails go once what households see is written and the lock let go: sending them one by one
	// inside it could hold the lock past its 30 seconds (red team ATK1-lock-lapse-double).
	$sent = 0;
	if ( $email && function_exists( 'ogc_mail_send_kind' ) ) {
		$hh  = ogc_lod_households( $y );
		$cfg = ogc_lod_kv( $y, 'registration' );
		foreach ( $tell as $rid ) {
			$to = isset( $hh[ $rid ] ) ? $hh[ $rid ]['email'] : '';
			// Never a sample, never a cancelled household (it was told by its own email).
			if ( $to && is_email( $to ) && empty( $hh[ $rid ]['sample'] ) && 'cancelled' !== ( isset( $hh[ $rid ]['data']['status'] ) ? $hh[ $rid ]['data']['status'] : '' ) ) {
				$sent += ogc_mail_send_kind( $was ? 'rooms_changed' : 'rooms_posted', $to, array( 'year' => $y, 'checkin' => isset( $cfg['checkin_where'] ) ? $cfg['checkin_where'] : 'Lodging Desk' ), array( 'year' => $y ) ) ? 1 : 0;
			}
		}
	}
	ogc_log( 'lodging_publish', $y, 'rooms', array( 'mode' => $mode, 'households' => count( $snap ), 'changed' => count( $tell ), 'emailed' => $sent ) );
	return rest_ensure_response( array( 'published' => $data, 'notified' => $sent, 'changed' => count( $tell ) ) );
}

function ogc_lod_rest_log( WP_REST_Request $req ) {
	$y    = (int) $req['year'];
	$what = in_array( $req->get_param( 'what' ), array( 'export', 'print' ), true ) ? $req->get_param( 'what' ) : 'export';
	$list = preg_replace( '/[^a-z0-9_-]/', '', strtolower( (string) $req->get_param( 'list' ) ) );
	ogc_log( 'lodging_' . $what, $y, substr( $list, 0, 40 ), array( 'rows' => (int) $req->get_param( 'rows' ) ) );
	// The desk's "Printed" step, written only while the year's names are kept (red team A4-34).
	$ph = ogc_lod_phase( $y, ogc_lod_today( $y, $req ) );
	if ( 'print' === $what && 'checkin' === $list && ! $ph['cleared'] && '' === (string) $req->get_param( 'as' ) ) {
		$cur  = ogc_lod_row( $y, 'meta:steps' );
		$data = $cur ? (array) $cur['data'] : array();
		if ( empty( $data['print'] ) ) {
			$data['print'] = array( 'by' => ogc_lod_me(), 'at' => ogc_now() );
			ogc_lod_put( $y, 'meta:steps', $data );
		}
	}
	return rest_ensure_response( array( 'ok' => true ) );
}
