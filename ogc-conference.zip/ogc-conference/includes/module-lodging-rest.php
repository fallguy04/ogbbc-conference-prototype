<?php
/**
 * Lodging's routes (/wp-json/ogc/v1/years/{y}/lodging…). Every one is for the year's members only
 * (ogc_lod_can), every change needs the wp_rest nonce (WordPress's cookie sign-in refuses a change
 * without it) and is written to the change log without anyone's personal data.
 *
 *   GET  /years/{y}/lodging            the board's rows, recent changes for Undo, the published
 *                                      snapshot, last year's notes, what the halls carry from the last
 *                                      year at this campus, the year in counts once names are cleared
 *   POST /years/{y}/lodging/ops        { ops: [{ key, data|null, v }], label }: change rows together;
 *                                      409 when a row changed since (with the rows as they are now) or
 *                                      a room was just given to someone else
 *   POST /years/{y}/lodging/undo       { id }: put a change back (409 when changed since)
 *   POST /years/{y}/lodging/publish    { mode: publish|update|unpublish, email }
 *   POST /years/{y}/lodging/log        { what: export|print, list }: who took which list, when
 *   GET  /years/{y}/lodging/summary    counts only (the year page's card)
 */

defined( 'ABSPATH' ) || exit;

add_action( 'rest_api_init', function () {
	$Y = '(?P<year>\d{4})';
	register_rest_route( OGC_NS, "/years/$Y/lodging", array(
		array( 'methods' => 'GET', 'callback' => 'ogc_lod_rest_get', 'permission_callback' => 'ogc_lod_can' ),
	) );
	register_rest_route( OGC_NS, "/years/$Y/lodging/ops", array(
		array( 'methods' => 'POST', 'callback' => 'ogc_lod_rest_ops', 'permission_callback' => 'ogc_lod_can' ),
	) );
	register_rest_route( OGC_NS, "/years/$Y/lodging/undo", array(
		array( 'methods' => 'POST', 'callback' => 'ogc_lod_rest_undo', 'permission_callback' => 'ogc_lod_can' ),
	) );
	register_rest_route( OGC_NS, "/years/$Y/lodging/publish", array(
		array( 'methods' => 'POST', 'callback' => 'ogc_lod_rest_publish', 'permission_callback' => 'ogc_lod_can' ),
	) );
	register_rest_route( OGC_NS, "/years/$Y/lodging/log", array(
		array( 'methods' => 'POST', 'callback' => 'ogc_lod_rest_log', 'permission_callback' => 'ogc_lod_can' ),
	) );
	register_rest_route( OGC_NS, "/years/$Y/lodging/summary", array(
		array( 'methods' => 'GET', 'callback' => function ( WP_REST_Request $req ) {
			return rest_ensure_response( ogc_lod_summary( (int) $req['year'] ) );
		}, 'permission_callback' => 'ogc_lod_can' ),
	) );
} );

/** The year's members (and webmasters), for a year that exists. */
function ogc_lod_can( WP_REST_Request $req ) {
	$y = (int) $req['year'];
	// The app (docs/23): Lodging's own people and the COA; webmasters only by seeing as (read only).
	// Every change needs a real viewer and today's date (ogc_appc_can).
	if ( function_exists( 'ogc_appc_can' ) ) {
		$ok = ogc_appc_can( $req, 'lod-rooms' );
		if ( true !== $ok ) {
			return $ok;
		}
	} elseif ( ! ogc_is_member( $y ) ) {
		return ogc_rest_denied();
	} elseif ( ! ogc_lod_may_see( $y ) ) {
		return ogc_lod_err( 'ogc_lodging_only', 'Lodging only', 403 );
	}
	return null === ogc_year_get( $y ) ? new WP_Error( 'ogc_no_year', 'Not started', array( 'status' => 404 ) ) : true;
}

function ogc_lod_err( $code, $msg, $status, $extra = array() ) {
	return new WP_Error( $code, $msg, array_merge( array( 'status' => $status ), $extra ) );
}

/* ================================================================== reading */

function ogc_lod_rest_get( WP_REST_Request $req ) {
	$y     = (int) $req['year'];
	$today = ogc_lod_today( $y, $req );
	$ph    = ogc_lod_phase( $y, $today );
	$rows  = ogc_lod_rows( $y );
	$uid   = get_current_user_id();
	$me    = ogc_lod_me();

	// When this member last sat down here: "Since Tuesday". A new sitting starts after three hours away.
	$seen = isset( $rows[ 'meta:seen:' . $uid ] ) ? $rows[ 'meta:seen:' . $uid ]['data'] : array();
	$now  = ogc_now();
	$prev = isset( $seen['prev'] ) ? $seen['prev'] : '';
	if ( empty( $seen['last'] ) || strtotime( $now ) - strtotime( $seen['last'] ) > 3 * HOUR_IN_SECONDS ) {
		$prev = isset( $seen['last'] ) ? $seen['last'] : '';
	}
	// Written when a sitting loads the board (?hh=1), not on every 25-second catch-up.
	if ( $req->get_param( 'hh' ) && empty( $req->get_param( 'as' ) ) ) {
		ogc_lod_put( $y, 'meta:seen:' . $uid, array( 'last' => $now, 'prev' => $prev ) );
	}

	// The last changes, newest first, for Undo (anyone's; each says whose).
	$undo = array();
	foreach ( array_reverse( array_filter( $rows, function ( $r, $k ) { return 0 === strpos( $k, 'undo:' ); }, ARRAY_FILTER_USE_BOTH ), true ) as $k => $r ) {
		$undo[] = array( 'id' => substr( $k, 5 ), 'label' => isset( $r['data']['label'] ) ? $r['data']['label'] : '', 'at' => $r['at'], 'by' => ogc_lod_name_of( $r['by'] ), 'mine' => $r['by'] === $uid );
		if ( count( $undo ) >= 12 ) {
			break;
		}
	}
	$imports = array();
	foreach ( array_reverse( array_filter( $rows, function ( $r, $k ) { return 0 === strpos( $k, 'imp:' ); }, ARRAY_FILTER_USE_BOTH ), true ) as $k => $r ) {
		$imports[] = array( 'id' => substr( $k, 4 ), 'at' => $r['at'], 'by' => ogc_lod_name_of( $r['by'] ), 'summary' => isset( $r['data']['summary'] ) ? $r['data']['summary'] : array(), 'undone' => ! empty( $r['data']['undone'] ) );
		break;
	}

	$prev_year = ogc_lod_prev_year( $y );
	// Names due to be cleared are never sent, whether the daily job has run or not: cleared here first.
	if ( $ph['gone'] && ( ogc_lod_rows( $y, 'hh:' ) || ogc_lod_rows( $y, 'yf:' ) || ! ogc_lod_row( $y, 'meta:numbers' ) ) ) {
		ogc_lod_clear( $y );
		$rows = ogc_lod_rows( $y );
	}
	$out       = array(
		'year'      => $y,
		// The app's screens ask for the households with the board (?hh=1), as Lodging needs them.
		'households' => $req->get_param( 'hh' ) && ! $ph['cleared'] && function_exists( 'ogc_appc_lod_households' ) ? ogc_appc_lod_households( $y ) : null,
		'phase'     => $ph,
		'me'        => $me,
		'rows'      => ogc_lod_public_rows( $ph['cleared'] ? array_filter( $rows, function ( $k ) { return 0 === strpos( $k, 'note:' ) || 0 === strpos( $k, 'room:' ) || 'meta:steps' === $k || 'meta:notes_done' === $k; }, ARRAY_FILTER_USE_KEY ) : $rows ),
		'undo'      => $undo,
		'import'    => $imports ? $imports[0] : null,
		'seen'      => $prev,
		'prev_year' => $prev_year,
		'prev'      => $prev_year ? ogc_lod_prev_parts( $prev_year ) : null,
		'carry'     => ogc_lod_carry( $y ),
		'numbers'   => null,
		// Counts (Round 5, module-lodging-counts.php): every send with its kept copy, who it may go to (the
		// committee's Contacts, by role), and when it's due.
		'sent'      => function_exists( 'ogc_lod_sent' ) && ! $ph['cleared'] ? ogc_lod_sent( $y ) : array(),
		'send_to'   => ogc_lod_send_to( $y ),
		'counts_due' => function_exists( 'ogc_lod_counts_due' ) ? ogc_lod_counts_due( $y ) : '',
	);
	if ( $ph['cleared'] ) {
		$n              = ogc_lod_row( $y, 'meta:numbers' );
		$out['numbers'] = $n ? $n['data'] : ogc_lod_numbers( $y );
		$out['undo']    = array();
		$out['import']  = null;
	}
	return rest_ensure_response( $out );
}

/** Who Counts may be sent to: Lodging's Contacts by role (its page's hand-down), else none. */
function ogc_lod_send_to( $y ) {
	$c   = function_exists( 'ogc_hd_field' ) ? ogc_hd_field( (int) $y, 'lodging', 'contacts' ) : null;
	$out = array();
	foreach ( (array) ( is_array( $c ) && isset( $c['value'] ) ? $c['value'] : array() ) as $x ) {
		if ( is_array( $x ) && ! empty( $x['role'] ) ) {
			$out[] = mb_substr( wp_strip_all_tags( (string) $x['role'] ), 0, 80 );
		}
	}
	return array_values( array_unique( $out ) );
}

/** The Conference before this one that has a year in the table (for last year's notes). */
function ogc_lod_prev_year( $y ) {
	foreach ( ogc_years_list() as $x ) {
		if ( (int) $x < (int) $y && ogc_year_get( $x ) && ! empty( ogc_year_get( $x )['end'] ) ) {
			return (int) $x;
		}
	}
	return 0;
}

/** Last year's Notes for next year (members of this year may read them: they were written for them). */
function ogc_lod_prev_parts( $prev ) {
	$notes = array();
	foreach ( ogc_lod_rows( $prev, 'note:' ) as $k => $r ) {
		$notes[] = array( 'id' => substr( $k, 5 ), 'text' => isset( $r['data']['text'] ) ? $r['data']['text'] : '', 'by' => isset( $r['data']['by'] ) ? $r['data']['by'] : '', 'at' => isset( $r['data']['at'] ) ? $r['data']['at'] : '', 'tab' => isset( $r['data']['tab'] ) ? $r['data']['tab'] : '' );
	}
	return array( 'notes' => $notes );
}

/**
 * Rooms' own facts carried from the last year at the same campus (accessible, beds, out of service),
 * for a year that has none of its own yet. Holds are each year's own and never carried.
 */
function ogc_lod_carry( $y ) {
	if ( ogc_lod_rows( $y, 'room:' ) ) {
		return null;
	}
	$row = ogc_year_get( $y );
	$v   = $row && ! empty( $row['venue'] ) ? $row['venue'] : '';
	if ( '' === $v ) {
		return null;
	}
	foreach ( ogc_years_list() as $x ) {
		$r = ogc_year_get( $x );
		if ( (int) $x < $y && $r && isset( $r['venue'] ) && $r['venue'] === $v ) {
			$facts = array();
			foreach ( ogc_lod_rows( $x, 'room:' ) as $k => $rr ) {
				$d = array_intersect_key( (array) $rr['data'], array_flip( array( 'access', 'beds', 'out' ) ) );
				if ( array_filter( $d ) ) {
					$facts[ substr( $k, 5 ) ] = $d;
				}
			}
			return $facts ? array( 'year' => (int) $x, 'rooms' => $facts ) : null;
		}
	}
	return null;
}

/* ================================================================== changing rows */

/** A row's data cleaned, with the server's own marks (who, when) kept or added. Returns array, null or WP_Error. */
function ogc_lod_clean( $y, $key, $in, $old, $ctx ) {
	if ( null === $in ) {
		return null;
	}
	if ( ! is_array( $in ) ) {
		return ogc_lod_err( 'ogc_bad', 'Not saved · bad row', 400 );
	}
	$old   = is_array( $old ) ? $old : array();
	$me    = $ctx['me'];
	$now   = ogc_now();
	$stamp = function ( $was ) use ( $me, $now ) {
		return is_array( $was ) && ! empty( $was['at'] ) ? array( 'by' => $was['by'], 'at' => $was['at'] ) : array( 'by' => $me, 'at' => $now );
	};
	$str   = function ( $v, $max ) {
		return mb_substr( trim( wp_strip_all_tags( (string) $v ) ), 0, $max );
	};
	list( $kind, $id ) = explode( ':', $key, 2 );

	if ( 'hh' === $kind ) {
		$hh = isset( $ctx['hh'][ $id ] ) ? $ctx['hh'][ $id ] : null;
		if ( ! $hh ) {
			return ogc_lod_err( 'ogc_bad', 'Household not found', 404 );
		}
		$out   = array();
		$rooms = array();
		foreach ( array_slice( (array) ( isset( $in['rooms'] ) ? $in['rooms'] : array() ), 0, 8 ) as $r ) {
			$r = (string) $r;
			if ( ! isset( $ctx['rooms'][ $r ] ) ) {
				return ogc_lod_err( 'ogc_bad', 'No room ' . ogc_lod_room_words( $r ), 400 );
			}
			$rooms[ $r ] = true;
		}
		$rooms = array_keys( $rooms );
		if ( $rooms && ! ogc_lod_in_dorm( $hh ) && $rooms !== (array) ( isset( $old['rooms'] ) ? $old['rooms'] : array() ) ) {
			return ogc_lod_err( 'ogc_bad', 'Not in dorm rooms', 400 );
		}
		// A household on the waiting list isn't placed; its place is offered first (area-lodging L22).
		// Unplacing is still taken.
		if ( array_diff( $rooms, (array) ( isset( $old['rooms'] ) ? $old['rooms'] : array() ) ) && 'waitlist' === ( isset( $hh['data']['status'] ) ? $hh['data']['status'] : '' ) ) {
			return ogc_lod_err( 'ogc_waitlist', 'On the waiting list · Offer place first', 409 );
		}
		if ( $rooms ) {
			$out['rooms'] = $rooms;
			$out['given'] = ( isset( $old['rooms'] ) && $old['rooms'] === $rooms && isset( $old['given'] ) ) ? $old['given'] : array( 'by' => $me, 'at' => $now );
			// What the registration said when its rooms were given; again when Lodging says Looks right to a change.
			$out['snap'] = ( ! empty( $in['snap'] ) && true === $in['snap'] ) || empty( $old['snap'] ) ? ogc_lod_snap( $hh['data'] ) : $old['snap'];
		}
		if ( ! empty( $in['older'] ) ) {
			$out['older'] = $stamp( isset( $old['older'] ) ? $old['older'] : null );
		}
		if ( ! empty( $in['ok']['sig'] ) ) {
			$sig       = $str( $in['ok']['sig'], 400 );
			$out['ok'] = isset( $old['ok']['sig'] ) && $old['ok']['sig'] === $sig ? $old['ok'] : array( 'sig' => $sig, 'by' => $me, 'at' => $now );
		}
		if ( ! empty( $in['near'] ) && isset( $ctx['hh'][ (string) $in['near'] ] ) && (string) $in['near'] !== $id ) {
			$out['near'] = (string) $in['near'];
		}
		if ( isset( $in['note'] ) && '' !== $str( $in['note'], 500 ) ) {
			$out['note'] = $str( $in['note'], 500 );
		}
		$names = array();
		foreach ( (array) ( isset( $hh['data']['people'] ) ? $hh['data']['people'] : array() ) as $p ) {
			if ( ! empty( $p['name'] ) ) {
				$names[] = $p['name'];
			}
		}
		if ( ! empty( $in['keys'] ) && is_array( $in['keys'] ) ) {
			foreach ( $in['keys'] as $i => $n ) {
				if ( is_numeric( $i ) && (int) $i >= 0 && (int) $i < 8 && in_array( (string) $n, $names, true ) ) {
					$out['keys'][ (int) $i ] = (string) $n;
				}
			}
		}
		if ( ! empty( $in['checkin'] ) ) {
			if ( ! empty( $old['checkin']['at'] ) ) {
				$out['checkin'] = $old['checkin'];
			} else {
				$keys = array();
				foreach ( (array) ( isset( $in['checkin']['keys'] ) ? $in['checkin']['keys'] : array() ) as $r => $n ) {
					if ( isset( $ctx['rooms'][ (string) $r ] ) && in_array( (string) $n, $names, true ) ) {
						$keys[ (string) $r ] = (string) $n;
					}
				}
				$out['checkin'] = array( 'at' => $now, 'by' => $me, 'keys' => (object) $keys );
			}
		}
		// Keys handed out at check-in, per room (one a room unless the desk says more).
		if ( ! empty( $in['keysout'] ) && is_array( $in['keysout'] ) ) {
			foreach ( $in['keysout'] as $r => $n ) {
				if ( isset( $ctx['rooms'][ (string) $r ] ) && is_numeric( $n ) ) {
					$out['keysout'][ (string) $r ] = max( 0, min( 12, (int) $n ) );
				}
			}
		}
		if ( ! empty( $in['back'] ) && is_array( $in['back'] ) ) {
			foreach ( $in['back'] as $r => $v ) {
				if ( $v && isset( $ctx['rooms'][ (string) $r ] ) ) {
					$out['back'][ (string) $r ] = isset( $old['back'][ (string) $r ] ) ? $old['back'][ (string) $r ] : array( 'by' => $me, 'at' => $now );
				}
			}
		}
		// Leaving early (keys back before the last night): the first night not used, for the credit.
		if ( ! empty( $in['left']['night'] ) ) {
			$out['left'] = isset( $old['left']['night'] ) && $old['left']['night'] === $str( $in['left']['night'], 24 ) ? $old['left'] : array( 'night' => $str( $in['left']['night'], 24 ), 'by' => $me, 'at' => $now );
		}
		if ( ! empty( $in['setup'] ) && is_array( $in['setup'] ) ) {
			foreach ( $in['setup'] as $r => $v ) {
				if ( isset( $ctx['rooms'][ (string) $r ] ) && is_array( $v ) ) {
					$out['setup'][ (string) $r ] = array( 'l' => max( 0, min( 24, (int) ( isset( $v['l'] ) ? $v['l'] : 0 ) ) ), 'm' => max( 0, min( 8, (int) ( isset( $v['m'] ) ? $v['m'] : 0 ) ) ) );
				}
			}
		}
		return $out ? $out : null;
	}

	if ( 'yf' === $kind ) {
		if ( ! isset( $ctx['yf'][ $id ] ) ) {
			return ogc_lod_err( 'ogc_bad', 'Youngfolk not found', 404 );
		}
		$out  = array();
		$room = isset( $in['room'] ) ? (string) $in['room'] : '';
		if ( '' !== $room ) {
			if ( ! isset( $ctx['rooms'][ $room ] ) || 0 !== strpos( $ctx['rooms'][ $room ]['for'], 'young' ) ) {
				return ogc_lod_err( 'ogc_bad', 'Not a Youngfolks room', 400 );
			}
			$out['room'] = $room;
		}
		if ( ! empty( $in['mate'] ) && ( 'none' === $in['mate'] || ( isset( $ctx['yf'][ (string) $in['mate'] ] ) && (string) $in['mate'] !== $id ) ) ) {
			$out['mate'] = (string) $in['mate'];   // "none": Lodging unpaired them
		}
		if ( ! empty( $in['ok']['sig'] ) ) {
			$sig       = $str( $in['ok']['sig'], 400 );
			$out['ok'] = isset( $old['ok']['sig'] ) && $old['ok']['sig'] === $sig ? $old['ok'] : array( 'sig' => $sig, 'by' => $me, 'at' => $now );
		}
		if ( ! empty( $in['out'] ) ) {
			$out['keyout'] = $stamp( isset( $old['keyout'] ) ? $old['keyout'] : null );
		}
		return $out ? $out : null;
	}

	if ( 'room' === $kind ) {
		if ( ! isset( $ctx['rooms'][ $id ] ) ) {
			return ogc_lod_err( 'ogc_bad', 'No room ' . ogc_lod_room_words( $id ), 400 );
		}
		$out = array();
		if ( isset( $in['hold'] ) && '' !== $str( $in['hold'], 30 ) ) {
			$out['hold'] = $str( $in['hold'], 30 );
		}
		foreach ( array( 'out', 'access' ) as $b ) {
			if ( ! empty( $in[ $b ] ) ) {
				$out[ $b ] = true;
			}
		}
		if ( isset( $in['beds'] ) && (int) $in['beds'] > 0 ) {
			$out['beds'] = min( 8, (int) $in['beds'] );
		}
		return $out ? $out : null;
	}

	if ( 'note' === $kind ) {
		if ( ! preg_match( '/^[a-z0-9]{1,24}$/', $id ) ) {
			return ogc_lod_err( 'ogc_bad', 'Bad note', 400 );
		}
		$text = $str( isset( $in['text'] ) ? $in['text'] : '', 600 );
		if ( '' === $text ) {
			return null;
		}
		$tab = isset( $in['tab'] ) && in_array( $in['tab'], array( 'rooms', 'yf', 'campers', 'checkin' ), true ) ? $in['tab'] : 'rooms';
		return isset( $old['text'] ) && $old['text'] === $text ? array_merge( $old, array( 'tab' => $tab ) ) : array( 'text' => $text, 'tab' => $tab, 'by' => $me, 'at' => $now );
	}

	if ( 'meta:steps' === $key || 'meta:notes_done' === $key ) {
		$out = array();
		foreach ( $in as $k => $v ) {
			if ( $v && preg_match( '/^[a-z0-9_-]{1,32}$/', (string) $k ) ) {
				$out[ (string) $k ] = $stamp( isset( $old[ $k ] ) ? $old[ $k ] : null );
			}
		}
		return $out ? $out : null;
	}
	return ogc_lod_err( 'ogc_bad', 'Not saved · ' . $key, 400 );
}

/** The context a change is checked against: rooms, households, Youngfolks, who. */
function ogc_lod_ctx( $y ) {
	$hh = ogc_lod_households( $y );
	$yf = array();
	foreach ( $hh as $rid => $rec ) {
		foreach ( (array) ( isset( $rec['data']['people'] ) ? $rec['data']['people'] : array() ) as $p ) {
			if ( ! empty( $p['yf'] ) && ! empty( $p['pid'] ) ) {
				$yf[ $p['pid'] ] = $rid;
			}
		}
	}
	return array( 'rooms' => ogc_lod_rooms( $y ), 'hh' => $hh, 'yf' => $yf, 'me' => ogc_lod_me() );
}

/** A room given twice (after a change), as words: "Reed 214 · Lane, Mark and Ellen". '' when none. */
function ogc_lod_double( $y, $ctx, $touched, $planned = array() ) {
	$owner = array();
	$rows  = ogc_lod_rows( $y );
	// The rows as they'd be after the change (checked before anything is written).
	foreach ( $planned as $k => $d ) {
		if ( null === $d ) {
			unset( $rows[ $k ] );
		} else {
			$rows[ $k ] = array( 'data' => $d );
		}
	}
	foreach ( $rows as $k => $r ) {
		$list = array();
		if ( 0 === strpos( $k, 'hh:' ) ) {
			$rid = substr( $k, 3 );
			if ( ! isset( $ctx['hh'][ $rid ] ) || ! ogc_lod_in_dorm( $ctx['hh'][ $rid ] ) ) {
				continue;   // a household no longer in dorm rooms frees its rooms
			}
			$list = (array) ( isset( $r['data']['rooms'] ) ? $r['data']['rooms'] : array() );
		} elseif ( 0 === strpos( $k, 'yf:' ) && ! empty( $r['data']['room'] ) ) {
			$list = array( $r['data']['room'] );
		}
		foreach ( $list as $room ) {
			$owner[ $room ][] = $k;
		}
	}
	foreach ( $owner as $room => $keys ) {
		if ( count( $keys ) < 2 ) {
			continue;
		}
		// Up to three Youngfolks may share a room (a pair, or a pair and one more where the hall's rooms
		// sleep three: lodging-assumptions B19); a family's room never.
		$hhs = array_filter( $keys, function ( $k ) { return 0 === strpos( $k, 'hh:' ); } );
		if ( ! $hhs && count( $keys ) <= 3 ) {
			continue;
		}
		if ( ! array_intersect( $keys, $touched ) ) {
			continue;
		}
		$other = array_values( array_diff( $keys, $touched ) );
		$k     = $other ? $other[0] : $keys[0];
		$who   = 0 === strpos( $k, 'hh:' ) && isset( $ctx['hh'][ substr( $k, 3 ) ] ) ? ogc_lod_label( $ctx['hh'][ substr( $k, 3 ) ]['data'] ) : 'Youngfolks';
		return 'Room ' . ogc_lod_room_words( $room ) . ' is taken · ' . $who;
	}
	return '';
}

/** Is the year past its Conference (no more changes)? Members may still print and download. */
function ogc_lod_held( $y, $req ) {
	$ph = ogc_lod_phase( $y, ogc_lod_today( $y, $req ) );
	return $ph['held'];
}

/**
 * After the Conference, rooms no longer move, but the desk keeps working until the names are cleared
 * (Check in, keys out, Keys back: the last morning is when most keys come back), and Notes for next
 * year can always be written. Is this change one of those?
 */
function ogc_lod_late_ok( $ph, $key, $old, $new ) {
	if ( 0 === strpos( $key, 'note:' ) || 'meta:notes_done' === $key ) {
		return true;
	}
	if ( $ph['cleared'] ) {
		return false;
	}
	if ( 'meta:steps' === $key ) {
		return true;
	}
	if ( 0 === strpos( $key, 'hh:' ) ) {
		return ogc_lod_desk_only( $old, $new );
	}
	if ( 0 === strpos( $key, 'yf:' ) ) {
		$a = array_diff_key( is_array( $old ) ? $old : array(), array( 'keyout' => 1 ) );
		$b = array_diff_key( is_array( $new ) ? $new : array(), array( 'keyout' => 1 ) );
		return ogc_lod_same( $a, $b );
	}
	return false;
}

function ogc_lod_rest_ops( WP_REST_Request $req ) {
	$y  = (int) $req['year'];
	$ph = ogc_lod_phase( $y, ogc_lod_today( $y, $req ) );
	$ops = (array) $req->get_param( 'ops' );
	if ( ! $ops || count( $ops ) > 400 ) {
		return ogc_lod_err( 'ogc_bad', 'Nothing to save', 400 );
	}
	$label = mb_substr( trim( wp_strip_all_tags( (string) $req->get_param( 'label' ) ) ), 0, 120 );
	$ctx   = ogc_lod_ctx( $y );
	$plan  = array();
	foreach ( $ops as $op ) {
		$key = isset( $op['key'] ) ? (string) $op['key'] : '';
		if ( ! ogc_lod_key_ok( $key ) || preg_match( '/^(undo|imp):|^meta:(published|mapping|numbers|seen|sent)/', $key ) || isset( $plan[ $key ] ) ) {
			return ogc_lod_err( 'ogc_bad', 'Not saved · ' . $key, 400 );
		}
		$cur = ogc_lod_row( $y, $key );
		$v   = $cur ? $cur['v'] : 0;
		if ( array_key_exists( 'v', $op ) && null !== $op['v'] && (int) $op['v'] !== $v ) {
			return ogc_lod_conflict( $y, 'Changed by another member · Reload', array( $key ) );
		}
		$data = ogc_lod_clean( $y, $key, array_key_exists( 'data', $op ) ? $op['data'] : null, $cur ? $cur['data'] : null, $ctx );
		if ( is_wp_error( $data ) ) {
			return $data;
		}
		if ( $ph['held'] && ! ogc_lod_late_ok( $ph, $key, $cur ? $cur['data'] : null, $data ) ) {
			return ogc_lod_err( 'ogc_held', $ph['cleared'] ? 'Names cleared · No changes' : 'Conference over · Desk only', 403 );
		}
		$plan[ $key ] = array( 'before' => $cur, 'data' => $data, 'v' => $v );
	}
	// A room given twice is refused before anything is written.
	$double = ogc_lod_double( $y, $ctx, array_keys( $plan ), array_map( function ( $p ) { return $p['data']; }, $plan ) );
	if ( '' !== $double ) {
		return ogc_lod_conflict( $y, $double, array_keys( $plan ) );
	}
	// Apply; on a race part-way, put back what was already written.
	$done = array();
	foreach ( $plan as $key => $p ) {
		if ( null === $p['data'] && ! $p['before'] ) {
			continue;
		}
		$r = ogc_lod_put( $y, $key, $p['data'], $p['v'] );
		if ( is_wp_error( $r ) ) {
			ogc_lod_rollback( $y, $done, $plan );
			return ogc_lod_conflict( $y, 'Changed by another member · Reload', array( $key ) );
		}
		$done[ $key ] = $r;
	}
	$double = ogc_lod_double( $y, $ctx, array_keys( $plan ) );
	if ( '' !== $double ) {
		ogc_lod_rollback( $y, $done, $plan );
		return ogc_lod_conflict( $y, $double, array_keys( $plan ) );
	}
	// Remember the change for Undo: each row as it was, and the version it is now.
	$id     = gmdate( 'ymdHis' ) . wp_rand( 100, 999 );
	$before = array();
	foreach ( $plan as $key => $p ) {
		$before[ $key ] = $p['before'] ? array( 'data' => $p['before']['data'] ) : null;
	}
	if ( $done ) {
		ogc_lod_put( $y, 'undo:' . $id, array( 'label' => $label, 'before' => $before, 'after' => $done ) );
		ogc_lod_prune( $y, 'undo:', 60 );
	}
	ogc_log( 'lodging', $y, 'lodging', array( 'rows' => count( $done ), 'kinds' => array_values( array_unique( array_map( function ( $k ) { return strtok( $k, ':' ); }, array_keys( $done ) ) ) ) ) );
	$rows = array();
	foreach ( array_keys( $plan ) as $key ) {
		$r            = ogc_lod_row( $y, $key );
		$rows[ $key ] = $r ? array( 'data' => $r['data'], 'v' => $r['v'], 'by' => ogc_lod_me(), 'at' => $r['at'] ) : null;
	}
	return rest_ensure_response( array( 'rows' => $rows, 'undo' => $done ? array( 'id' => $id, 'label' => $label, 'mine' => true, 'by' => ogc_lod_me() ) : null ) );
}

/** Put rows back as they were before a change that couldn't finish. */
function ogc_lod_rollback( $y, $done, $plan ) {
	foreach ( $done as $key => $v ) {
		$b = $plan[ $key ]['before'];
		ogc_lod_put( $y, $key, $b ? $b['data'] : null );
	}
}

/** 409 with the rows as they are now, so the page shows them and says what happened. */
function ogc_lod_conflict( $y, $msg, $keys ) {
	$rows = array();
	foreach ( $keys as $k ) {
		$r          = ogc_lod_row( $y, $k );
		$rows[ $k ] = $r ? array( 'data' => $r['data'], 'v' => $r['v'], 'by' => ogc_lod_name_of( $r['by'] ), 'at' => $r['at'] ) : null;
	}
	return ogc_lod_err( 'ogc_conflict', $msg, 409, array( 'rows' => $rows ) );
}

/** Keep only the newest $keep rows with this prefix. */
function ogc_lod_prune( $y, $prefix, $keep ) {
	global $wpdb;
	$t   = ogc_table( 'lodging' );
	$ids = $wpdb->get_col( $wpdb->prepare( "SELECT id FROM $t WHERE year = %d AND rkey LIKE %s ORDER BY id DESC", $y, $wpdb->esc_like( $prefix ) . '%' ) );
	foreach ( array_slice( (array) $ids, $keep ) as $id ) {
		$wpdb->delete( $t, array( 'id' => (int) $id ), array( '%d' ) );
	}
}

function ogc_lod_rest_undo( WP_REST_Request $req ) {
	$y  = (int) $req['year'];
	$ph = ogc_lod_phase( $y, ogc_lod_today( $y, $req ) );
	$id = (string) $req->get_param( 'id' );
	if ( ! preg_match( '/^\d{12,20}$/', $id ) ) {
		return ogc_lod_err( 'ogc_bad', 'Nothing to undo', 400 );
	}
	$u = ogc_lod_row( $y, 'undo:' . $id );
	if ( ! $u ) {
		return ogc_lod_err( 'ogc_gone', 'Nothing to undo', 404 );
	}
	$after  = (array) ( isset( $u['data']['after'] ) ? $u['data']['after'] : array() );
	$before = (array) ( isset( $u['data']['before'] ) ? $u['data']['before'] : array() );
	foreach ( $after as $key => $v ) {
		$cur = ogc_lod_row( $y, $key );
		if ( ( $cur ? $cur['v'] : 0 ) !== (int) $v ) {
			return ogc_lod_conflict( $y, 'Changed since · Can’t undo', array( $key ) );
		}
		$b = isset( $before[ $key ] ) && is_array( $before[ $key ] ) ? $before[ $key ]['data'] : null;
		if ( $ph['held'] && ! ogc_lod_late_ok( $ph, $key, $cur ? $cur['data'] : null, $b ) ) {
			return ogc_lod_err( 'ogc_held', 'Conference over · Desk only', 403 );
		}
	}
	$done = array();
	$plan = array();
	foreach ( $after as $key => $v ) {
		$cur          = ogc_lod_row( $y, $key );
		$plan[ $key ] = array( 'before' => $cur );
		$b            = isset( $before[ $key ] ) && is_array( $before[ $key ] ) ? $before[ $key ]['data'] : null;
		$r            = ogc_lod_put( $y, $key, $b, $cur ? $cur['v'] : 0 );
		if ( is_wp_error( $r ) ) {
			ogc_lod_rollback( $y, $done, $plan );
			return ogc_lod_conflict( $y, 'Changed since · Can’t undo', array( $key ) );
		}
		$done[ $key ] = $r;
	}
	$double = ogc_lod_double( $y, ogc_lod_ctx( $y ), array_keys( $after ) );
	if ( '' !== $double ) {
		ogc_lod_rollback( $y, $done, $plan );
		return ogc_lod_conflict( $y, $double . ' · Can’t undo', array_keys( $after ) );
	}
	ogc_lod_put( $y, 'undo:' . $id, null );
	ogc_log( 'lodging_undo', $y, 'lodging', array( 'rows' => count( $done ) ) );
	$rows = array();
	foreach ( array_keys( $after ) as $key ) {
		$r            = ogc_lod_row( $y, $key );
		$rows[ $key ] = $r ? array( 'data' => $r['data'], 'v' => $r['v'], 'by' => ogc_lod_me(), 'at' => $r['at'] ) : null;
	}
	return rest_ensure_response( array( 'rows' => $rows, 'label' => isset( $u['data']['label'] ) ? $u['data']['label'] : '' ) );
}

/* ================================================================== publishing */

/** The rooms households would see now: { rid: [room ids] } for every household in dorm rooms with rooms. */
function ogc_lod_snapshot( $y ) {
	$hh   = ogc_lod_households( $y );
	$snap = array();
	foreach ( ogc_lod_rows( $y, 'hh:' ) as $k => $r ) {
		$rid = substr( $k, 3 );
		if ( isset( $hh[ $rid ] ) && ogc_lod_in_dorm( $hh[ $rid ] ) && ! empty( $r['data']['rooms'] ) ) {
			$snap[ $rid ] = array_values( (array) $r['data']['rooms'] );
		}
	}
	return $snap;
}

function ogc_lod_rest_publish( WP_REST_Request $req ) {
	$y = (int) $req['year'];
	if ( ogc_lod_held( $y, $req ) ) {
		return ogc_lod_err( 'ogc_held', 'Held · No changes', 403 );
	}
	$mode  = (string) $req->get_param( 'mode' );
	$email = (bool) $req->get_param( 'email' );
	$today = ogc_lod_today( $y, $req );
	$pub   = ogc_lod_row( $y, 'meta:published' );
	$was   = $pub && ! empty( $pub['data']['snap'] ) ? (array) $pub['data']['snap'] : array();
	if ( 'unpublish' === $mode ) {
		ogc_state_put( $y, 'rooms', (object) array() );
		ogc_file_patch( $y, 'registration', array( 'op' => 'key', 'key' => 'rooms_posted', 'value' => '' ) );
		ogc_lod_put( $y, 'meta:published', array( 'date' => '', 'off' => array( 'by' => ogc_lod_me(), 'at' => ogc_now() ), 'first' => $pub && isset( $pub['data']['first'] ) ? $pub['data']['first'] : '' ) );
		ogc_log( 'lodging_unpublish', $y, 'rooms', array() );
		return rest_ensure_response( array( 'published' => ogc_lod_row( $y, 'meta:published' )['data'], 'notified' => 0 ) );
	}
	if ( ! in_array( $mode, array( 'publish', 'update' ), true ) ) {
		return ogc_lod_err( 'ogc_bad', 'Not published', 400 );
	}
	$snap = ogc_lod_snapshot( $y );
	if ( ! $snap ) {
		return ogc_lod_err( 'ogc_bad', 'No rooms given', 400 );
	}
	ogc_state_put( $y, 'rooms', (object) $snap );
	ogc_file_patch( $y, 'registration', array( 'op' => 'key', 'key' => 'rooms_posted', 'value' => $today ) );
	// Who to tell: everyone on a first publish; on an update, the households whose rooms changed.
	$tell = array();
	foreach ( array_unique( array_merge( array_keys( $snap ), array_keys( $was ) ) ) as $rid ) {
		$now  = isset( $snap[ $rid ] ) ? $snap[ $rid ] : array();
		$then = isset( $was[ $rid ] ) ? (array) $was[ $rid ] : array();
		if ( 'publish' === $mode && ! $was ? (bool) $now : $now !== $then ) {
			$tell[] = $rid;
		}
	}
	$sent = 0;
	if ( $email && function_exists( 'ogc_mail_send_kind' ) ) {
		$hh  = ogc_lod_households( $y );
		$cfg = ogc_lod_kv( $y, 'registration' );
		foreach ( $tell as $rid ) {
			$to = isset( $hh[ $rid ] ) ? $hh[ $rid ]['email'] : '';
			if ( $to && is_email( $to ) && empty( $hh[ $rid ]['sample'] ) ) {
				$sent += ogc_mail_send_kind( $was ? 'rooms_changed' : 'rooms_posted', $to, array( 'year' => $y, 'checkin' => isset( $cfg['checkin_where'] ) ? $cfg['checkin_where'] : 'Lodging Desk' ), array( 'year' => $y ) ) ? 1 : 0;
			}
		}
	}
	$data = array(
		'date'    => $today,
		'by'      => ogc_lod_me(),
		'at'      => ogc_now(),
		'first'   => $pub && ! empty( $pub['data']['first'] ) ? $pub['data']['first'] : $today,
		'snap'    => (object) $snap,
		'told'    => count( $tell ),
		'emailed' => $email,
	);
	ogc_lod_put( $y, 'meta:published', $data );
	ogc_log( 'lodging_publish', $y, 'rooms', array( 'mode' => $mode, 'households' => count( $snap ), 'changed' => count( $tell ), 'emailed' => $sent ) );
	return rest_ensure_response( array( 'published' => $data, 'notified' => $sent, 'changed' => count( $tell ) ) );
}

function ogc_lod_rest_log( WP_REST_Request $req ) {
	$y    = (int) $req['year'];
	$what = in_array( $req->get_param( 'what' ), array( 'export', 'print' ), true ) ? $req->get_param( 'what' ) : 'export';
	$list = preg_replace( '/[^a-z0-9_-]/', '', strtolower( (string) $req->get_param( 'list' ) ) );
	ogc_log( 'lodging_' . $what, $y, substr( $list, 0, 40 ), array( 'rows' => (int) $req->get_param( 'rows' ) ) );
	if ( 'print' === $what && 'checkin' === $list ) {
		$cur  = ogc_lod_row( $y, 'meta:steps' );
		$data = $cur ? (array) $cur['data'] : array();
		if ( empty( $data['print'] ) ) {
			$data['print'] = array( 'by' => ogc_lod_me(), 'at' => ogc_now() );
			ogc_lod_put( $y, 'meta:steps', $data );
		}
	}
	return rest_ensure_response( array( 'ok' => true ) );
}
