<?php
/**
 * What needs whom, now (polish round 1, Oct 11): the one place Home, the board, the weekly email and
 * the tasks read what's true about the work.
 *
 *   ogc_app_today()            the campus's today, or the date a read previews (?as_of=, never saved)
 *   ogc_app_task_kinds()       a task tied to its screen and to what marks it done ("Meal counts sent")
 *   ogc_app_needs( y, v )      what needs this viewer, most pressing first: each row has its words, a
 *                              line under them, the screen it opens and the one button's label
 *   filter ogc_app_needs       each committee's (and the COA's) work adds its own rows:
 *                              add_filter( 'ogc_app_needs', fn( $rows, $year, $ckey, $ctx ) … )
 *   ogc_app_screen_opens()     when a screen comes into season (Check-in: the first day)
 *   the weekly note            Mondays, to each committee's members, from the same needs
 *
 * Nothing here returns a name, email or phone: needs are counts and dates.
 */

defined( 'ABSPATH' ) || exit;

/* ================================================================== today, or a preview */

/** Today at the campus (the year's own time zone when known), or the previewed date. */
function ogc_app_today( $year = 0 ) {
	if ( ! empty( $GLOBALS['ogc_app_as_of'] ) ) {
		return $GLOBALS['ogc_app_as_of'];
	}
	if ( $year && function_exists( 'ogc_coa_today' ) ) {
		return ogc_coa_today( (int) $year );
	}
	return wp_date( 'Y-m-d' );
}

// A read of the app's routes may preview a date (?as_of=2027-02-14): counts, seasons and needs as they
// would be then. A change while previewing is refused, so nothing is saved under a pretend date.
add_filter( 'rest_request_before_callbacks', function ( $res, $handler, $req ) {
	if ( is_wp_error( $res ) || 0 !== strpos( (string) $req->get_route(), '/' . OGC_NS . '/app/' ) ) {
		return $res;
	}
	$a = (string) $req->get_param( 'as_of' );
	if ( '' === $a ) {
		return $res;
	}
	if ( 'GET' !== $req->get_method() && ! ogc_proto_saves() ) {
		return new WP_Error( 'ogc_preview', 'Preview · Not saved', array( 'status' => 403 ) );
	}
	if ( preg_match( '/^(\d{4})-(\d{2})-(\d{2})$/', $a, $x ) && checkdate( (int) $x[2], (int) $x[3], (int) $x[1] ) ) {
		$GLOBALS['ogc_app_as_of'] = $a;
	}
	return $res;
}, 4, 3 );

// Say only what is true: a sample record dated after today (a made-up household "registered Mar 8,
// 2027", seen in October 2026) isn't counted anywhere yet: not in Households, Money, meal counts, the
// lists, Home or the board. Real records are never dated after now, so only samples are ever left out.
// A preview (?as_of=, a signed-in member's read) counts as of that day, so Mar 15 shows what was in.
add_action( 'rest_api_init', function () {
	add_filter( 'rest_request_before_callbacks', function ( $res, $handler, $req ) {
		$a = (string) $req->get_param( 'as_of' );
		if ( ( 'GET' === $req->get_method() || ogc_proto_saves() ) && is_user_logged_in() && preg_match( '/^(\d{4})-(\d{2})-(\d{2})$/', $a, $x ) && checkdate( (int) $x[2], (int) $x[3], (int) $x[1] ) ) {
			$GLOBALS['ogc_records_as_of'] = $a;
		}
		return $res;
	}, 3, 3 );
} );
add_filter( 'ogc_records', function ( $rows, $year, $kind ) {
	if ( ! in_array( $kind, array( 'registrations', 'credits', 'waits', 'teams', 'signups' ), true ) ) {
		return $rows;
	}
	$today = ! empty( $GLOBALS['ogc_records_as_of'] ) ? $GLOBALS['ogc_records_as_of'] : ogc_app_today( $year );
	return array_values( array_filter( (array) $rows, function ( $r ) use ( $today ) {
		if ( empty( $r['sample'] ) ) {
			return true;
		}
		$d  = isset( $r['data'] ) && is_array( $r['data'] ) ? $r['data'] : array();
		$at = ! empty( $d['created'] ) ? $d['created'] : ( ! empty( $d['at'] ) ? $d['at'] : (string) $r['created_at'] );
		return substr( (string) $at, 0, 10 ) <= $today;
	} ) );
}, 10, 3 );

/** "Jan 15": one short date format for the whole app (the year only when it isn't the Conference's). */
function ogc_app_md( $iso, $year = 0 ) {
	$t = strtotime( (string) $iso . ' 12:00:00 UTC' );
	if ( ! $t ) {
		return '';
	}
	// A Conference's own season runs from the July before it to the end of its year: "Nov 1" in a 2027
	// list is Nov 1, 2026. Anything outside it says its year ("Apr 3, 2026").
	$d    = gmdate( 'Y-m-d', $t );
	$same = $year ? ( $d >= ( (int) $year - 1 ) . '-07-01' && $d <= (int) $year . '-12-31' ) : gmdate( 'Y', $t ) === substr( ogc_app_today(), 0, 4 );
	// A no-break space keeps "Nov 1" on one line.
	return gmdate( 'M', $t ) . "\u{00a0}" . gmdate( $same ? 'j' : 'j, Y', $t );
}

function ogc_app_days_to( $iso, $today ) {
	return (int) round( ( strtotime( $iso . ' 12:00:00 UTC' ) - strtotime( $today . ' 12:00:00 UTC' ) ) / DAY_IN_SECONDS );
}

/* ================================================================== tasks tied to their screens */

/**
 * The kinds of task the year knows: the screen it's done on, and how the site can tell it's done.
 *   screen  the screen id (Open … on the task)
 *   from    the screen's words in "Done · from Meal counts · May 12"
 * A task's kind is set when it's seeded or carried; a task someone adds has none (ticked by hand).
 */
function ogc_app_task_kinds() {
	return (array) apply_filters( 'ogc_app_task_kinds', array(
		'requests_answer' => array( 'screen' => 'requests', 'from' => 'Requests' ),
		'requests_sent'   => array( 'screen' => 'requests', 'from' => 'Requests' ),
		'meals_sent'      => array( 'screen' => 'food-meals', 'from' => 'Meal counts' ),
		'reg_open'        => array( 'screen' => 'registration', 'from' => 'Registration' ),
		'reg_tell'        => array( 'screen' => 'registration', 'from' => '' ),
		'announce'        => array( 'screen' => 'dates', 'from' => 'Dates and place' ),
		'schedule'        => array( 'screen' => 'schedule', 'from' => 'Schedule' ),
		'signups_open'    => array( 'screen' => 'shifts', 'from' => 'Shifts' ),
		'rooms_published' => array( 'screen' => 'lod-rooms', 'from' => 'Rooms' ),
	) );
}

/** A setting that's a date on or before today ('' when it isn't: blank, "not yet", or later). */
function ogc_app_setting_on( $year, $file, $key, $today ) {
	$s = function_exists( 'ogc_coa_kv' ) ? ogc_coa_kv( (int) $year, $file ) : array();
	$v = isset( $s[ $key ] ) ? (string) $s[ $key ] : '';
	return preg_match( '/^\d{4}-\d{2}-\d{2}$/', $v ) && '9999-12-31' !== $v && $v <= $today ? $v : '';
}

/** The year's requests (needs.csv) by committee key: n, left (unanswered), last answered date. */
function ogc_app_requests( $year ) {
	static $memo = array();
	if ( isset( $memo[ $year ] ) ) {
		return $memo[ $year ];
	}
	$out = array();
	$f   = function_exists( 'ogc_file_get' ) ? ogc_file_get( (int) $year, 'needs' ) : null;
	foreach ( $f ? (array) $f['rows'] : array() as $r ) {
		$k = ogc_committee_key( isset( $r['committee'] ) ? (string) $r['committee'] : '' );
		if ( '' === $k ) {
			continue;
		}
		if ( ! isset( $out[ $k ] ) ) {
			$out[ $k ] = array( 'n' => 0, 'left' => 0, 'last' => '' );
		}
		$out[ $k ]['n']++;
		$a = isset( $r['answer'] ) ? (string) $r['answer'] : '';
		if ( '' === $a ) {
			$out[ $k ]['left']++;
		}
		$at = isset( $r['answered_at'] ) ? substr( (string) $r['answered_at'], 0, 10 ) : '';
		if ( preg_match( '/^\d{4}-\d{2}-\d{2}$/', $at ) && $at > $out[ $k ]['last'] ) {
			$out[ $k ]['last'] = $at;
		}
	}
	return $memo[ $year ] = $out;
}

/** When the requests went to the campus ('' if they haven't). */
function ogc_app_requests_sent( $year ) {
	if ( ! function_exists( 'ogc_coa_state' ) ) {
		return '';
	}
	$s = ogc_coa_state( (int) $year );
	return ! empty( $s['sent']['needs']['at'] ) ? (string) $s['sent']['needs']['at'] : '';
}

/** Is a kind of task done, by the data? The date it was done, or ''. */
function ogc_app_task_auto( $kind, $year, $ckey, $today ) {
	$year = (int) $year;
	switch ( $kind ) {
		case 'requests_answer':
			// Once the year's round has gone to the committee: done when it returns it (module-requests.php).
			$rd = function_exists( 'ogc_round_returned_on' ) ? ogc_round_returned_on( $year, $ckey, $today ) : null;
			if ( null !== $rd ) {
				return $rd;
			}
			$r = ogc_app_requests( $year );
			return isset( $r[ $ckey ] ) && $r[ $ckey ]['n'] && ! $r[ $ckey ]['left'] ? ( $r[ $ckey ]['last'] ? $r[ $ckey ]['last'] : $today ) : '';
		case 'requests_sent':
			$s = ogc_app_requests_sent( $year );
			return $s && $s <= $today ? $s : '';
		case 'meals_sent':
			if ( ! function_exists( 'ogc_lst_sent' ) ) {
				return '';
			}
			foreach ( ogc_lst_sent( $year ) as $v ) {
				if ( ! empty( $v['final'] ) && ! empty( $v['day'] ) && $v['day'] <= $today ) {
					return (string) $v['day'];
				}
			}
			return '';
		case 'reg_open':
			return ogc_app_setting_on( $year, 'registration', 'opens', $today );
		case 'announce':
			$row = ogc_year_get( $year );
			$on  = $row && ! empty( $row['coa_announced'] ) ? (string) $row['coa_announced'] : '';
			return preg_match( '/^\d{4}-\d{2}-\d{2}$/', $on ) && $on <= $today ? $on : '';
		case 'schedule':
			return ogc_app_setting_on( $year, 'settings', 'schedule_posted', $today );
		case 'signups_open':
			return ogc_app_setting_on( $year, 'settings', 'signups_posted', $today );
		case 'rooms_published':
			if ( ! function_exists( 'ogc_lod_summary' ) ) {
				return '';
			}
			$s = ogc_lod_summary( $year );
			return $s['published'] && substr( $s['published'], 0, 10 ) <= $today ? substr( $s['published'], 0, 10 ) : '';
	}
	// An area's own kinds (report_sent: module-handdown.php).
	return (string) apply_filters( 'ogc_app_task_auto', '', $kind, $year, $ckey, $today );
}

/** A kind's own date, when a setting decides it (Registration posted = the day it opens). */
function ogc_app_task_kind_due( $kind, $year ) {
	$year = (int) $year;
	// Answer requests: the round's due date (Intake's setting, module-requests.php).
	if ( 'requests_answer' === $kind && function_exists( 'ogc_round_kind_due' ) && '' !== ogc_round_kind_due( $kind, $year ) ) {
		return ogc_round_kind_due( $kind, $year );
	}
	if ( in_array( $kind, array( 'reg_open', 'reg_tell' ), true ) && function_exists( 'ogc_coa_kv' ) ) {
		$r = ogc_coa_kv( $year, 'registration' );
		$o = isset( $r['opens'] ) ? (string) $r['opens'] : '';
		return preg_match( '/^\d{4}-\d{2}-\d{2}$/', $o ) && '9999-12-31' !== $o ? $o : '';
	}
	if ( 'meals_sent' === $kind && function_exists( 'ogc_lst_state' ) ) {
		$s = ogc_lst_state( $year, 'lists_settings' );
		return ! empty( $s['counts_due'] ) && preg_match( '/^\d{4}-\d{2}-\d{2}$/', $s['counts_due'] ) ? (string) $s['counts_due'] : '';
	}
	return '';
}

/** Where a kind's own date is set, in words, for a task whose date a setting decides (the panel shows
 * "Nov 13 · Set on Intake" instead of a date field, and a typed date is refused). */
function ogc_app_task_due_from( $kind ) {
	$w = array(
		'requests_answer' => 'Set on Intake',
		'reg_open'        => 'Set on Registration',
		'reg_tell'        => 'Set on Registration',
		'meals_sent'      => 'Set on Meal counts',
	);
	return isset( $w[ $kind ] ) ? $w[ $kind ] : 'Set on its screen';
}

/** The seeded titles that name a kind (and their new names), for tasks made before kinds. */
function ogc_app_task_titles() {
	return array(
		'Requests to the campus'                  => array( 'requests_answer', 'Answer requests' ),
		'Answer requests'                         => array( 'requests_answer', '' ),
		'Needs to the campus'                     => array( 'requests_sent', 'Send requests to campus' ),
		'Send requests to campus'                 => array( 'requests_sent', '' ),
		'Final meal counts to the caterer'        => array( 'meals_sent', '' ),
		'Registration posted'                     => array( 'reg_open', 'Registration opens' ),
		'Registration opens'                      => array( 'reg_open', '' ),
		'Tell every district registration is open' => array( 'reg_tell', '' ),
		'COA announcement'                        => array( 'announce', 'Announce the Conference' ),
		'Announce the Conference'                 => array( 'announce', '' ),
		'Master schedule'                         => array( 'schedule', '' ),
		'Volunteer sign-ups open'                 => array( 'signups_open', '' ),
	);
}

// Once per site: name the kind of every seeded or carried task, and give the shared ones to the COA
// (no-assumed-owners: Registration and the schedule are the COA's until it hands their screen on).
add_action( 'init', function () {
	global $wpdb;
	if ( (int) get_option( 'ogc_app_task_kinds' ) >= 3 || ! function_exists( 'ogc_app_tables_ready' ) || ! ogc_app_tables_ready() ) {
		return;
	}
	$wpdb->suppress_errors( true );
	$ok = null !== $wpdb->get_var( 'SELECT kind FROM ' . ogc_table( 'tasks' ) . ' LIMIT 1' ) || '' === $wpdb->last_error; // phpcs:ignore -- no input.
	$wpdb->suppress_errors( false );
	if ( ! $ok ) {
		return; // The column comes with the schema's next run.
	}
	$map = ogc_app_task_titles();
	$rows = $wpdb->get_results( 'SELECT id, year, ckey, title, due_date, kind, source FROM ' . ogc_table( 'tasks' ) . " WHERE source IN ('seed','carried')", ARRAY_A ); // phpcs:ignore -- no input.
	foreach ( (array) $rows as $t ) {
		if ( ! isset( $map[ $t['title'] ] ) ) {
			continue;
		}
		list( $kind, $rename ) = $map[ $t['title'] ];
		$set = array( 'kind' => $kind );
		if ( $rename ) {
			$set['title'] = $rename;
		}
		if ( 'requests_answer' === $kind && preg_match( '/^(\d{4})-01-15$/', (string) $t['due_date'], $x ) ) {
			$set['due_date'] = $x[1] . '-01-08';
		}
		if ( in_array( $kind, array( 'reg_open', 'schedule' ), true ) && 'coa' !== $t['ckey'] ) {
			$to          = function_exists( 'ogc_app_handed_to' ) ? ogc_app_handed_to( (int) $t['year'], 'reg_open' === $kind ? 'registration' : 'schedule' ) : '';
			$set['ckey'] = '' !== $to ? $to : 'coa';
		}
		$wpdb->update( ogc_table( 'tasks' ), $set, array( 'id' => (int) $t['id'] ) );
	}
	update_option( 'ogc_app_task_kinds', '3', false );
}, 46 );

// Once per site (Round 1, after the critic): every committee's First meeting and Notes for next year get
// their kind, from the plugin's own seed titles (never anyone's typing), so Home merges them by kind. Only
// seeded or carried rows that have no kind yet; nothing else is touched.
add_action( 'init', function () {
	global $wpdb;
	if ( '3' !== (string) get_option( 'ogc_app_task_kinds' ) || ! function_exists( 'ogc_app_tables_ready' ) || ! ogc_app_tables_ready() ) {
		return;
	}
	foreach ( array( 'First meeting' => 'first_meeting', 'Notes for next year' => 'notes_next' ) as $title => $kind ) {
		$wpdb->query( $wpdb->prepare( 'UPDATE ' . ogc_table( 'tasks' ) . " SET kind = %s WHERE title = %s AND kind = '' AND source IN ('seed','carried')", $kind, $title ) );
	}
	update_option( 'ogc_app_task_kinds', '4', false );
}, 47 );

/** Hand a screen on: its year's open tasks of that screen go with it. */
function ogc_app_move_screen_tasks( $year, $screen, $to ) {
	global $wpdb;
	$kinds = array();
	foreach ( ogc_app_task_kinds() as $k => $d ) {
		if ( $d['screen'] === $screen ) {
			$kinds[] = $k;
		}
	}
	if ( ! $kinds ) {
		return 0;
	}
	$in = implode( ',', array_fill( 0, count( $kinds ), '%s' ) );
	return (int) $wpdb->query( $wpdb->prepare( 'UPDATE ' . ogc_table( 'tasks' ) . " SET ckey = %s WHERE year = %d AND done_at IS NULL AND removed_at IS NULL AND kind IN ($in)", array_merge( array( '' === $to ? 'coa' : $to, (int) $year ), $kinds ) ) ); // phpcs:ignore -- placeholders built above.
}

/* ================================================================== seasons */

/**
 * When each screen comes into season this year (ISO date), or '' for always. Before it, the sidebar
 * shows it quietly with its date and its screen says only when it opens. Filter: ogc_app_screen_opens.
 */
function ogc_app_screen_opens( $year ) {
	static $memo = array();
	if ( isset( $memo[ $year ] ) ) {
		return $memo[ $year ];
	}
	$y     = ogc_year_get( (int) $year );
	$start = $y && ! empty( $y['start'] ) ? (string) $y['start'] : '';
	$reg   = function_exists( 'ogc_coa_kv' ) ? ogc_coa_kv( (int) $year, 'registration' ) : array();
	$opens = isset( $reg['opens'] ) && preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) $reg['opens'] ) ? (string) $reg['opens'] : '';
	$s     = function_exists( 'ogc_coa_kv' ) ? ogc_coa_kv( (int) $year, 'settings' ) : array();
	$vol   = isset( $s['signups_posted'] ) && preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) $s['signups_posted'] ) ? (string) $s['signups_posted'] : '';
	// Work that's already there is in season, whatever the date (a household registered on paper early).
	$regs  = function_exists( 'ogc_records' ) && count( ogc_records( (int) $year, 'registrations' ) ) > 0;
	$opens = $regs ? '' : $opens;
	$out   = array(
		// The desk: the first day. Campers check in at the lot the same day.
		'lod-checkin'    => $start,
		'lod-campers'    => $opens,
		'lod-import'     => $opens,
		'lod-households' => $opens,
		'lod-rooms'      => $opens,
		'lod-yf'         => $opens,
		'food-meals'     => $opens,
		'preteens-list'  => $opens,
		'communion-list' => $opens,
		'money'          => $opens,
		'shifts'         => $vol,
	);
	return $memo[ $year ] = (array) apply_filters( 'ogc_app_screen_opens', $out, (int) $year );
}

/* ================================================================== needs */

/**
 * What needs this viewer now, most pressing first. A row:
 *   key     a stable id (dedupes a task of the same kind)
 *   words   what's true ("8 households to place")
 *   why     the line under it ("Due Jan 8", "Rooms")
 *   go      where the button goes: { s, c, v, id, at }
 *   button  the one act ("Assign all · 8")
 *   tone    'late' | 'look' | ''
 *   due     ISO date or ''
 *   rank    0 late · 1 first steps · 2 now · 3 by date
 *   ckey    whose it is
 *   kind    the task kind it stands for, if any
 */
function ogc_app_needs( $year, $v ) {
	$year  = (int) $year;
	$today = ogc_app_today( $year );
	$phase = ogc_app_phase( $year );
	$ctx   = array( 'today' => $today, 'phase' => $phase['phase'], 'viewer' => $v );
	$rows  = array();
	if ( $v['coa'] ) {
		$rows = array_merge( $rows, (array) apply_filters( 'ogc_app_needs', array(), $year, 'coa', $ctx ) );
		$rows = array_merge( $rows, ogc_app_needs_people( $year ) );
	}
	foreach ( (array) $v['committees'] as $k ) {
		foreach ( (array) apply_filters( 'ogc_app_needs', array(), $year, $k, $ctx ) as $r ) {
			$rows[] = array_merge( array( 'ckey' => $k ), $r );
		}
	}
	// Tasks: due soon or late, unless a screen already says the same thing. The COA's window is a month
	// (an announcement is planned weeks ahead); a committee's two weeks.
	$kinds = array();
	foreach ( $rows as $r ) {
		if ( ! empty( $r['kind'] ) ) {
			$kinds[ $r['kind'] . '|' . ( isset( $r['ckey'] ) ? $r['ckey'] : 'coa' ) ] = true;
		}
	}
	$scope = $v['coa'] ? array( 'coa' ) : (array) $v['committees'];
	// A task with no screen behind it (a meeting, a phone call) is asked about once it's past, never
	// put in the headline; past 14 days it lapses quietly (it stays on Tasks, marked Late). Two or more
	// late at once are one line.
	$later  = (array) get_user_meta( get_current_user_id(), 'ogc_app_later', true );
	$asks   = array();
	foreach ( ogc_app_tasks( $year, $scope ) as $t ) {
		if ( $t['done'] || ! $t['due'] || ( $t['kind'] && isset( $kinds[ $t['kind'] . '|' . $t['committee'] ] ) ) ) {
			continue;
		}
		$d = ogc_app_days_to( $t['due'], $today );
		if ( $d > ( 'coa' === $t['committee'] ? 30 : 14 ) ) {
			continue;
		}
		// Once the Conference has begun, what was due before it is past asking.
		$y0 = ogc_year_get( $year );
		if ( in_array( $phase['phase'], array( 'week', 'after' ), true ) && $y0 && ! empty( $y0['start'] ) && $t['due'] < $y0['start'] ) {
			continue;
		}
		$sc = $t['screen'] && ogc_app_can_see( $v, $t['screen'] ) ? $t['screen'] : '';
		if ( ! $sc && $t['late'] ) {
			if ( $d >= -14 && empty( $later[ $t['id'] ] ) ) {
				$asks[] = $t;
			}
			continue;
		}
		$rows[] = array(
			'key'    => 'task:' . $t['id'],
			'words'  => $t['title'],
			'why'    => $t['late'] ? 'Due ' . ogc_app_md( $t['due'], $year ) . ' · Late' : 'Due ' . ogc_app_md( $t['due'], $year ) . ( $d <= 7 ? ' · ' . ( 0 === $d ? 'Today' : $d . ' day' . ( 1 === $d ? '' : 's' ) ) : '' ),
			'go'     => $sc ? array( 's' => $sc ) : array( 's' => 'tasks', 'id' => $t['id'] ),
			'button' => $sc ? 'Open ' . ogc_app_screen_title( $year, $sc ) : 'Open task',
			'tone'   => $t['late'] ? 'late' : '',
			'due'    => $t['due'],
			'rank'   => $t['late'] ? 0 : 3,
			'ckey'   => $t['committee'],
			'kind'   => $t['kind'],
			'manual' => ! $sc,
		);
	}
	if ( 1 === count( $asks ) ) {
		$t      = $asks[0];
		$rows[] = array( 'key' => 'ask:' . $t['id'], 'words' => $t['title'] . ' · ' . ogc_app_md( $t['due'], $year ), 'why' => 'Was it done?', 'go' => array( 's' => 'tasks', 'id' => $t['id'] ), 'ask' => (int) $t['id'], 'button' => '', 'tone' => '', 'due' => $t['due'], 'ckey' => $t['committee'], 'manual' => true, 'late' => true );
	} elseif ( $asks ) {
		$rows[] = array( 'key' => 'asks', 'words' => count( $asks ) . ' late tasks', 'why' => implode( ' · ', array_map( function ( $t ) {
			return $t['title'];
		}, array_slice( $asks, 0, 3 ) ) ), 'go' => array( 's' => 'tasks', 'v' => 'late' ), 'button' => 'All tasks', 'tone' => '', 'due' => $asks[0]['due'], 'manual' => true, 'late' => true );
	}
	// Last year's notes and the responsibilities, the first time a committee opens its year.
	foreach ( $v['coa'] ? array() : (array) $v['committees'] as $k ) {
		$c = ogc_app_committee( $year, $k );
		// Only the head checks the page (the COA writes the responsibilities; helpers read last year's
		// notes on Home).
		if ( $c && $c['from_year'] && ! $c['checked_at'] && 'after' !== $phase['phase'] && ! empty( $v['head'] ) ) {
			$open = count( array_filter( ogc_app_notes( $c['from_year'], $k ), function ( $n ) {
				return ! $n['done'];
			} ) );
			$rows[] = array(
				'key'    => 'first:' . $k,
				'words'  => 'Check ' . $c['name'] . ( 's' === substr( $c['name'], -1 ) ? '’' : '’s' ) . ' page',
				'why'    => 'From ' . $c['from_year'] . ( $open ? ' · ' . ogc_app_plural( $open, 'note' ) . ' to read' : ' · Tasks and files' ),
				'go'     => array( 's' => 'overview', 'c' => $k ),
				'button' => 'Open ' . $c['name'],
				'tone'   => 'look',
				'due'    => '',
				'rank'   => 1,
				'ckey'   => $k,
			);
		}
		if ( 'after' === $phase['phase'] && 'coa' !== $k && ! ogc_app_report_sent( $year, $k ) ) {
			$rows[] = array( 'key' => 'report:' . $k, 'kind' => 'report_sent', 'words' => 'Report to the COA', 'why' => 'Questions, numbers and contacts · Next year’s committee reads it first', 'go' => array( 's' => 'overview', 'c' => $k, 'at' => 'report' ), 'button' => 'Write the report', 'tone' => 'look', 'due' => '', 'rank' => 2, 'ckey' => $k );
		}
	}
	// Most pressing first: work due within 14 days; then late work done on a screen; then the year's
	// first steps (no dates, last year's page to check); then what's dated within the month (the
	// announcement); then what's waiting now (households to place, a committee with no head); then
	// the rest by date. A task with no screen comes after all of
	// them, and never takes the headline (ogc_app_rest_home).
	// What the season is about leads: a committee's Shifts in the last four weeks (module-volunteer-lead.php,
	// `first`). But a committee's own work comes before its Shifts (Oct 16, Michael: Lodging's "Place · 48"
	// over "Shifts · 19 open" in May): a need that opens one of the committee's own screens (the registry's
	// `who` names it, or the COA handed it the screen; never the shared Requests or Shifts) keeps its own
	// order, ahead of the Shifts. Fixed by whose screen it is, nothing weighed.
	$lead = array();
	foreach ( $rows as $r ) {
		if ( ! empty( $r['first'] ) && ! empty( $r['ckey'] ) ) {
			$lead[ $r['ckey'] ] = true;
		}
	}
	$screens = $lead ? ogc_app_screens( $year ) : array();
	$own     = function ( $r ) use ( $lead, $screens, $year ) {
		$k = isset( $r['ckey'] ) ? (string) $r['ckey'] : '';
		$s = isset( $r['go']['s'] ) ? (string) $r['go']['s'] : '';
		if ( ! isset( $lead[ $k ] ) || ! empty( $r['first'] ) || ! empty( $r['manual'] ) || in_array( $s, array( '', 'requests', 'shifts' ), true ) || ! isset( $screens[ $s ] ) ) {
			return false;
		}
		return in_array( $k, (array) $screens[ $s ]['who'], true ) || ogc_app_handed_to( $year, $s ) === $k;
	};
	$base = function ( $r ) use ( $today ) {
		$k    = isset( $r['rank'] ) ? (int) $r['rank'] : 3;
		$d    = ! empty( $r['due'] ) ? ogc_app_days_to( $r['due'], $today ) : null;
		$late = ( null !== $d && $d < 0 ) || ( isset( $r['tone'] ) && 'late' === $r['tone'] ) || ! empty( $r['late'] );
		if ( ! empty( $r['manual'] ) ) {
			return $late ? 9 : 8;
		}
		if ( ! $late && null !== $d && $d <= 14 ) {
			return 0;
		}
		if ( $late ) {
			return 1;
		}
		if ( 1 === $k ) {
			return 2;
		}
		if ( null !== $d && $d <= 30 ) {
			return 3;
		}
		return 2 === $k ? 4 : 5;
	};
	$eff = function ( $r ) use ( $base, $own ) {
		if ( ! empty( $r['first'] ) ) {
			return -1;
		}
		// Its own screens' work, in its own order, above the Shifts that lead (-1).
		return $own( $r ) ? $base( $r ) - 20 : $base( $r );
	};
	usort( $rows, function ( $a, $b ) use ( $eff ) {
		$ra = $eff( $a );
		$rb = $eff( $b );
		if ( $ra !== $rb ) {
			return $ra - $rb;
		}
		$da = ! empty( $a['due'] ) ? $a['due'] : '9999';
		$db = ! empty( $b['due'] ) ? $b['due'] : '9999';
		return strcmp( $da, $db );
	} );
	$seen = array();
	$out  = array();
	foreach ( $rows as $r ) {
		$k = isset( $r['key'] ) ? $r['key'] : md5( wp_json_encode( $r ) );
		if ( isset( $seen[ $k ] ) ) {
			continue;
		}
		$seen[ $k ] = true;
		$out[]      = array_merge( array( 'why' => '', 'go' => array( 's' => 'home' ), 'button' => 'Open', 'tone' => '', 'due' => '', 'ckey' => '' ), $r );
	}
	return $out;
}

function ogc_app_plural( $n, $one, $many = '' ) {
	return $n . ' ' . ( 1 === (int) $n ? $one : ( $many ? $many : $one . 's' ) );
}

function ogc_app_screen_title( $year, $id ) {
	$s = ogc_app_screens( $year );
	return isset( $s[ $id ] ) ? $s[ $id ]['title'] : $id;
}

/** The COA's people needs: a committee with no one, or no head. The button adds them. */
function ogc_app_needs_people( $year ) {
	$nobody = array();
	$nohead = array();
	foreach ( ogc_app_committees( $year ) as $c ) {
		if ( 'coa' === $c['ckey'] ) {
			continue;
		}
		$people = ogc_app_people( $year, $c['ckey'] );
		$head   = array_filter( $people, function ( $m ) {
			return ! empty( $m['head'] );
		} );
		if ( ! $people ) {
			$nobody[] = $c;
		} elseif ( ! $head ) {
			$nohead[] = $c;
		}
	}
	// One committee: its name and what it does (its first responsibility, as the COA wrote it). Two or
	// more: one line, and Add people chooses the committee.
	$one = function ( $c, $words, $key ) {
		$first = trim( strtok( (string) $c['duties'], "\n" ) );
		return array( 'key' => $key . ':' . $c['ckey'], 'words' => $c['name'] . ' · ' . $words, 'why' => $first, 'go' => array( 's' => 'members', 'id' => 'new', 'c' => $c['ckey'], 'at' => 'head' ), 'button' => 'Add head', 'tone' => 'look', 'rank' => 2, 'ckey' => 'coa' );
	};
	$names = function ( $list ) {
		$n = array_map( function ( $c ) {
			return $c['name'];
		}, $list );
		return count( $n ) > 4 ? implode( ', ', array_slice( $n, 0, 3 ) ) . ' and ' . ( count( $n ) - 3 ) . ' more' : implode( ', ', $n );
	};
	$out = array();
	if ( 1 === count( $nobody ) ) {
		$out[] = $one( $nobody[0], 'No one on it', 'nobody' );
	} elseif ( $nobody ) {
		$out[] = array( 'key' => 'nobody', 'words' => count( $nobody ) . ' committees need people', 'why' => $names( $nobody ), 'go' => array( 's' => 'members', 'id' => 'new', 'at' => 'head' ), 'button' => 'Add people', 'tone' => 'look', 'rank' => 2, 'ckey' => 'coa' );
	}
	if ( 1 === count( $nohead ) ) {
		$out[] = $one( $nohead[0], 'No head', 'nohead' );
	} elseif ( $nohead ) {
		$out[] = array( 'key' => 'nohead', 'words' => count( $nohead ) . ' committees need a head', 'why' => $names( $nohead ), 'go' => array( 's' => 'members', 'id' => 'new', 'at' => 'head' ), 'button' => 'Add head', 'tone' => 'look', 'rank' => 2, 'ckey' => 'coa' );
	}
	return $out;
}

/* ------------------------------------------------------------------ the COA's screens */

add_filter( 'ogc_app_needs', function ( $rows, $year, $ckey, $ctx ) {
	// The year's preparations: past asking once the Conference has begun.
	if ( 'coa' !== $ckey || in_array( $ctx['phase'], array( 'after', 'week' ), true ) || ! function_exists( 'ogc_coa_kv' ) ) {
		return $rows;
	}
	$today = $ctx['today'];
	$v     = $ctx['viewer'];
	$due   = function ( $kind ) use ( $year ) {
		foreach ( ogc_app_tasks( $year, array( 'coa' ) ) as $t ) {
			if ( $kind === $t['kind'] && $t['due'] ) {
				return $t['due'];
			}
		}
		return '';
	};
	// One name for each thing: the task's own title where there's a task of that kind.
	$named = function ( $kind, $fallback ) use ( $year ) {
		foreach ( ogc_app_tasks( $year, array( 'coa' ) ) as $t ) {
			if ( $kind === $t['kind'] ) {
				return $t['title'];
			}
		}
		return $fallback;
	};
	// A year with no dates yet: its first step is the dates (and the campus); the tasks count from them.
	if ( 'nodates' === $ctx['phase'] ) {
		$row    = ogc_year_get( $year );
		$rows[] = array( 'key' => 'dates', 'ckey' => 'coa', 'words' => empty( $row['venue'] ) ? 'Set the dates and campus' : 'Set the dates', 'why' => 'Then the schedule and tasks move with them', 'go' => array( 's' => 'dates' ), 'button' => 'Set dates', 'due' => '', 'rank' => 1 );
		return $rows;
	}
	// The schedule: rows carried from last year, to check.
	$sched = ogc_file_get( $year, 'schedule' );
	$look  = 0;
	foreach ( $sched ? (array) $sched['rows'] : array() as $r ) {
		$look += ! empty( $r['_look'] ) ? 1 : 0;
	}
	if ( $look && ogc_app_can_see( $v, 'schedule' ) && '' === ogc_app_handed_to( $year, 'schedule' ) ) {
		$d      = $due( 'schedule' );
		$rows[] = array( 'key' => 'schedule-check', 'kind' => 'schedule', 'ckey' => 'coa', 'words' => ogc_app_plural( $look, 'schedule row' ) . ' to check', 'why' => $named( 'schedule', 'Master schedule' ) . ( $d ? ' · Due ' . ogc_app_md( $d, $year ) . ( $d < $today ? ' · Late' : '' ) : '' ), 'go' => array( 's' => 'schedule', 'v' => 'check' ), 'button' => 'Check ' . $look, 'due' => $d, 'rank' => $d && $d < $today ? 0 : 3, 'tone' => $d && $d < $today ? 'late' : '' );
	}
	// The packet: parts carried from last year nobody has read for this year.
	$picked = ogc_state_get( $year, 'picked' );
	$from   = $picked && ! empty( $picked['value']['from'] ) ? (int) $picked['value']['from'] : 0;
	if ( $from && ogc_app_can_see( $v, 'packet' ) && '' === ogc_app_handed_to( $year, 'packet' ) ) {
		$st    = ogc_coa_state( $year );
		$guide = ogc_file_get( $year, 'guide' );
		$ids   = array();
		foreach ( $guide ? (array) $guide['rows'] : array() as $r ) {
			if ( ! empty( $r['id'] ) && empty( $st['checks'][ 'packet:' . $r['id'] ] ) ) {
				$ids[ $r['id'] ] = true;
			}
		}
		if ( $ids ) {
			$rows[] = array( 'key' => 'packet-check', 'words' => ogc_app_plural( count( $ids ), 'packet part' ) . ' from ' . $from, 'why' => 'Read each for this year · Not public until published', 'go' => array( 's' => 'packet' ), 'button' => 'Check ' . count( $ids ), 'due' => '', 'rank' => 3 );
		}
		// The call-in line: not public until someone checks it.
		$s = ogc_coa_kv( $year, 'settings' );
		if ( ! empty( $s['call_in_number'] ) && function_exists( 'ogc_coa_is_confirmed' ) && ! ogc_coa_is_confirmed( $year, 'conf:callin' ) ) {
			$rows[] = array( 'key' => 'callin-check', 'words' => 'Call-in line from ' . $from, 'why' => 'Not public until checked', 'go' => array( 's' => 'callin' ), 'button' => 'Check', 'due' => '', 'rank' => 3 );
		}
	}
	// The announcement: a month ahead.
	$row = ogc_year_get( $year );
	$ann = $row && ! empty( $row['coa_announced'] ) ? (string) $row['coa_announced'] : '';
	$d   = $due( 'announce' );
	if ( '' === $ann && $d && ogc_app_days_to( $d, $today ) <= 30 ) {
		$late   = $d < $today;
		$rows[] = array( 'key' => 'announce', 'kind' => 'announce', 'ckey' => 'coa', 'words' => $named( 'announce', 'Announce the Conference' ), 'why' => 'Due ' . ogc_app_md( $d, $year ) . ( $late ? ' · Late' : '' ) . ' · The Conference page turns to ' . $year, 'go' => array( 's' => 'dates' ), 'button' => 'Announce', 'due' => $d, 'rank' => $late ? 0 : 3, 'tone' => $late ? 'late' : '' );
	}
	// Requests: the committees answer, the COA sends them to the campus.
	$req  = ogc_app_requests( $year );
	$sent = ogc_app_requests_sent( $year );
	if ( $req && ! $sent ) {
		// The committees answer their own; the COA sees progress by committee and can nudge the heads.
		$done = 0;
		$open = 0;
		foreach ( $req as $k => $x ) {
			if ( 'coa' === $k || ! ogc_app_committee( $year, $k ) ) {
				continue;
			}
			$done += $x['left'] ? 0 : 1;
			$open += $x['left'] ? 1 : 0;
		}
		$d    = $due( 'requests_sent' );
		$late = $d && $d < $today;
		$ans  = '';
		foreach ( ogc_app_tasks( $year, null ) as $t ) {
			if ( 'requests_answer' === $t['kind'] && $t['due'] && ( '' === $ans || $t['due'] < $ans ) ) {
				$ans = $t['due'];
			}
		}
		$rows[] = $open
			// What's left, never a zero; Remind heads opens Requests, which asks before it emails anyone.
			? array( 'key' => 'requests', 'kind' => 'requests_sent', 'ckey' => 'coa', 'words' => 'Requests · ' . ogc_app_plural( $open, 'committee' ) . ' to answer', 'why' => ( $ans ? 'Due ' . ogc_app_md( $ans, $year ) . ( $ans < $today ? ' · Late' : '' ) . ' · ' : '' ) . 'To the campus by ' . ( $d ? ogc_app_md( $d, $year ) : 'the COA' ), 'go' => array( 's' => 'requests', 'id' => 'remind' ), 'button' => 'Remind heads', 'due' => $ans ? $ans : $d, 'rank' => $late ? 0 : 3, 'tone' => $late ? 'late' : '' )
			: array( 'key' => 'requests', 'kind' => 'requests_sent', 'ckey' => 'coa', 'words' => 'Requests answered', 'why' => 'Send to the campus' . ( $d ? ' by ' . ogc_app_md( $d, $year ) : '' ), 'go' => array( 's' => 'requests' ), 'button' => 'Export for campus', 'due' => $d, 'rank' => $late ? 0 : 2, 'tone' => $late ? 'late' : '' );
	}
	// Help cards carried from last year: their phones and hours change most years.
	if ( ogc_app_can_see( $v, 'help' ) && '' === ogc_app_handed_to( $year, 'help' ) && $from ) {
		$st    = ogc_coa_state( $year );
		$p     = ogc_state_get( $year, 'picked' );
		$conf  = $p && ! empty( $p['value']['confirm'] ) ? (array) $p['value']['confirm'] : array();
		$left  = 0;
		foreach ( $conf as $id ) {
			$left += 0 === strpos( (string) $id, 'help:' ) && empty( $st['checks'][ $id ] ) ? 1 : 0;
		}
		if ( $left ) {
			$rows[] = array( 'key' => 'help-check', 'words' => ogc_app_plural( $left, 'help card' ) . ' from ' . $from, 'why' => 'Phones and hours change most years · Not public until checked', 'go' => array( 's' => 'help' ), 'button' => 'Check ' . $left, 'due' => '', 'rank' => 3 );
		}
	}
	// Registration: a date carried from last year isn't scheduled until someone chooses it; carried
	// prices are checked before it opens. From 30 days before.
	$R  = ogc_coa_kv( $year, 'registration' );
	$op = isset( $R['opens'] ) && preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) $R['opens'] ) && '9999-12-31' !== $R['opens'] ? (string) $R['opens'] : '';
	if ( $op && $op > $today && ogc_app_days_to( $op, $today ) <= 30 && ogc_app_can_see( $v, 'registration' ) && '' === ogc_app_handed_to( $year, 'registration' ) ) {
		$sched  = function_exists( 'ogc_pub_reg_confirmed' ) ? ogc_pub_reg_confirmed( $year ) : true;
		$prices = function_exists( 'ogc_coa_is_confirmed' ) ? ogc_coa_is_confirmed( $year, 'reg:prices' ) : true;
		if ( ! $sched || ! $prices ) {
			$rows[] = array( 'key' => 'reg-check', 'kind' => 'reg_open', 'ckey' => 'coa', 'words' => 'Registration opens ' . ogc_app_md( $op, $year ), 'why' => ! $sched ? 'From ' . ( $from ? $from : 'last year' ) . ' · Not scheduled' : 'Prices not checked', 'go' => array( 's' => 'registration' ), 'button' => ! $sched ? 'Schedule' : 'Check', 'due' => $op, 'rank' => 3 );
		}
	}
	return $rows;
}, 10, 4 );

/* ------------------------------------------------------------------ every committee: its requests */

add_filter( 'ogc_app_needs', function ( $rows, $year, $ckey, $ctx ) {
	if ( 'coa' === $ckey || 'before' !== $ctx['phase'] ) {
		return $rows;
	}
	$req = ogc_app_requests( $year );
	if ( empty( $req[ $ckey ]['left'] ) || ogc_app_requests_sent( $year ) ) {
		return $rows;
	}
	$d = '';
	foreach ( ogc_app_tasks( $year, array( $ckey ) ) as $t ) {
		if ( 'requests_answer' === $t['kind'] && $t['due'] ) {
			$d = $t['due'];
		}
	}
	// In season from about three months before they're due (the first meeting's time).
	if ( $d && ogc_app_days_to( $d, $ctx['today'] ) > 92 ) {
		return $rows;
	}
	$n      = $req[ $ckey ]['left'];
	$late   = $d && $d < $ctx['today'];
	$rows[] = array( 'key' => 'requests:' . $ckey, 'kind' => 'requests_answer', 'words' => ogc_app_plural( $n, 'request' ) . ' to answer', 'why' => ( $d ? 'Due ' . ogc_app_md( $d, $year ) . ( $late ? ' · Late' : '' ) . ' · ' : '' ) . 'What to ask the campus for again', 'go' => array( 's' => 'requests' ), 'button' => 'Answer ' . $n, 'due' => $d, 'rank' => $late ? 0 : 3, 'tone' => $late ? 'late' : '' );
	return $rows;
}, 10, 4 );

/* ------------------------------------------------------------------ Lodging and Food */

add_filter( 'ogc_app_needs', function ( $rows, $year, $ckey, $ctx ) {
	if ( 'lodging' === $ckey && function_exists( 'ogc_lod_summary' ) && 'after' !== $ctx['phase'] ) {
		$s = ogc_lod_summary( $year );
		if ( $s['waiting'] ) {
			$rows[] = array( 'key' => 'lod-place', 'words' => ogc_app_plural( $s['waiting'], 'household' ) . ' to place', 'why' => 'Rooms · Each household by hand', 'go' => array( 's' => 'lod-rooms', 'at' => 'assign' ), 'button' => 'Place · ' . $s['waiting'], 'due' => '', 'rank' => 2 );
		} elseif ( $s['dorm'] && ! $s['published'] ) {
			$rows[] = array( 'key' => 'lod-publish', 'kind' => 'rooms_published', 'words' => 'All ' . $s['dorm'] . ' placed · Not published', 'why' => 'Households see their rooms once published', 'go' => array( 's' => 'lod-rooms' ), 'button' => 'Open Rooms', 'due' => '', 'rank' => 2 );
		} elseif ( $s['changed'] ) {
			$rows[] = array( 'key' => 'lod-changed', 'words' => ogc_app_plural( $s['changed'], 'room' ) . ' changed since published', 'why' => 'Send the households their update', 'go' => array( 's' => 'lod-rooms' ), 'button' => 'Open Rooms', 'due' => '', 'rank' => 2 );
		}
		$new = ogc_app_new_households( $year, $ctx['viewer'] );
		if ( $new['n'] ) {
			$rows[] = array( 'key' => 'lod-new', 'words' => ogc_app_plural( $new['n'], 'new household' ), 'why' => ogc_app_since_words( $new['since'], $ctx['today'], $year ), 'go' => array( 's' => 'lod-households', 'v' => 'new' ), 'button' => 'Review ' . $new['n'], 'due' => '', 'rank' => 3 );
		}
	}
	if ( 'food' === $ckey && function_exists( 'ogc_lst_sent' ) && 'before' === $ctx['phase'] ) {
		$set   = ogc_lst_state( $year, 'lists_settings' );
		$due   = ! empty( $set['counts_due'] ) ? (string) $set['counts_due'] : '';
		$row   = ogc_year_get( $year );
		$due   = '' !== $due ? $due : ( $row && ! empty( $row['start'] ) ? gmdate( 'Y-m-d', strtotime( $row['start'] . ' 12:00 UTC' ) - 14 * DAY_IN_SECONDS ) : '' );
		$final = '' !== ogc_app_task_auto( 'meals_sent', $year, 'food', $ctx['today'] );
		if ( $due && ! $final && ogc_app_days_to( $due, $ctx['today'] ) <= 30 ) {
			$d      = ogc_app_days_to( $due, $ctx['today'] );
			$email  = ! empty( $set['caterer_email'] ) && is_email( $set['caterer_email'] );
			$rows[] = array( 'key' => 'food-counts', 'kind' => 'meals_sent', 'words' => 'Meal counts due ' . ogc_app_md( $due, $year ), 'why' => $d < 0 ? 'Late · Final counts to the caterer' : ( 0 === $d ? 'Today' : ogc_app_plural( $d, 'day' ) ) . ' · Final counts to the caterer', 'go' => array( 's' => 'food-meals' ), 'button' => $email ? 'Send counts' : 'Add caterer', 'due' => $due, 'rank' => $d < 0 ? 0 : 3, 'tone' => $d < 0 ? 'late' : '' );
		}
	}
	return $rows;
}, 10, 4 );

/** "Since your last look" (today), "Since Monday" (this week), "Since Oct 5". */
function ogc_app_since_words( $day, $today, $year ) {
	if ( '' === (string) $day ) {
		return '';
	}
	$d = ogc_app_days_to( $today, $day );
	if ( $d <= 0 ) {
		return 'Since your last look';
	}
	return $d < 7 ? 'Since ' . gmdate( 'l', strtotime( $day . ' 12:00 UTC' ) ) : 'Since ' . ogc_app_md( $day, $year );
}

/** Households registered since this person last opened Households (the first time: none are "new"). */
function ogc_app_new_households( $year, $v ) {
	$since = ogc_app_seen( $year, 'lod-households' );
	if ( ! $since || ! function_exists( 'ogc_appc_lod_households' ) ) {
		return array( 'n' => 0, 'since' => '' );
	}
	$n = 0;
	foreach ( ogc_appc_lod_households( $year ) as $hh ) {
		// Both as "Y-m-d H:i:s" (a registration keeps ISO with a T).
		$at = substr( str_replace( 'T', ' ', (string) $hh['created'] ), 0, 19 );
		if ( 'cancelled' !== $hh['status'] && $at > $since ) {
			$n++;
		}
	}
	return array( 'n' => $n, 'since' => substr( $since, 0, 10 ) );
}

/* ------------------------------------------------------------------ seen: "new since I last looked" */

/** When this person last opened a screen in a year ('Y-m-d H:i:s' UTC, or ''). */
function ogc_app_seen( $year, $screen, $uid = 0 ) {
	$uid  = $uid ? $uid : get_current_user_id();
	$seen = (array) get_user_meta( $uid, 'ogc_app_seen', true );
	$k    = (int) $year . '|' . sanitize_key( $screen );
	return isset( $seen[ $k ] ) ? (string) $seen[ $k ] : '';
}

add_action( 'rest_api_init', function () {
	register_rest_route( OGC_NS, '/app/(?P<year>\d{4})/seen', array(
		array(
			'methods'             => 'POST',
			'callback'            => function ( WP_REST_Request $req ) {
				$uid    = get_current_user_id();
				$screen = sanitize_key( (string) $req->get_param( 'screen' ) );
				$seen   = (array) get_user_meta( $uid, 'ogc_app_seen', true );
				$k      = (int) $req['year'] . '|' . $screen;
				$was    = isset( $seen[ $k ] ) ? (string) $seen[ $k ] : '';
				$seen[ $k ] = ogc_now();
				update_user_meta( $uid, 'ogc_app_seen', array_slice( $seen, -40, null, true ) );
				return rest_ensure_response( array( 'was' => $was ) );
			},
			'permission_callback' => function ( WP_REST_Request $req ) {
				$v = ogc_app_req_viewer( $req );
				$s = sanitize_key( (string) $req->get_param( 'screen' ) );
				// Seeing as is read only: it marks nothing seen for the person being seen as.
				return ! $v['as'] && ogc_app_can_see( $v, $s ) ? true : ogc_rest_denied();
			},
		),
	) );
} );

/* ================================================================== asked once, and the COA's nudge */

add_action( 'rest_api_init', function () {
	// "Not yet" on a past task with no screen (a meeting): Home stops asking this person about it.
	register_rest_route( OGC_NS, '/app/(?P<year>\d{4})/later', array(
		array(
			'methods'             => 'POST',
			'callback'            => function ( WP_REST_Request $req ) {
				$uid = get_current_user_id();
				$l   = (array) get_user_meta( $uid, 'ogc_app_later', true );
				$l[ (int) $req->get_param( 'id' ) ] = ogc_now();
				update_user_meta( $uid, 'ogc_app_later', array_slice( $l, -60, null, true ) );
				return rest_ensure_response( array( 'ok' => true ) );
			},
			'permission_callback' => function ( WP_REST_Request $req ) {
				global $wpdb;
				$v = ogc_app_req_viewer( $req );
				$t = $wpdb->get_row( $wpdb->prepare( 'SELECT year, ckey FROM ' . ogc_table( 'tasks' ) . ' WHERE id = %d AND removed_at IS NULL', (int) $req->get_param( 'id' ) ), ARRAY_A );
				return ! $v['as'] && $t && (int) $t['year'] === (int) $req['year'] && ogc_app_can_see( $v, 'tasks' ) && ogc_app_on_committee( $v, $t['ckey'] ) ? true : ogc_rest_denied();
			},
		),
	) );
	// Remind heads: each committee with requests left gets its weekly note now, at its head's address.
	register_rest_route( OGC_NS, '/app/(?P<year>\d{4})/remind', array(
		array(
			'methods'             => 'POST',
			'callback'            => 'ogc_app_rest_remind',
			'permission_callback' => function ( WP_REST_Request $req ) {
				$v = ogc_app_req_viewer( $req );
				return $v['coa'] && ! $v['as'] && ogc_app_can_see( $v, 'requests' ) ? true : ogc_rest_denied();
			},
		),
	) );
} );

function ogc_app_rest_remind( WP_REST_Request $req ) {
	$y    = (int) $req['year'];
	$what = (string) $req->get_param( 'what' );
	if ( 'requests' !== $what ) {
		return new WP_Error( 'ogc_bad', 'Nothing to remind', array( 'status' => 400 ) );
	}
	if ( ogc_throttle( 'app_remind:' . get_current_user_id(), 6, DAY_IN_SECONDS ) ) {
		return new WP_Error( 'ogc_rate', 'Sent today already · Try tomorrow', array( 'status' => 429 ) );
	}
	$st    = ogc_state_get( $y, 'app-remind' );
	$sent  = $st ? (array) $st['value'] : array();
	$today = ogc_app_today( $y );
	$heads = 0;
	$none  = 0;
	$again = 0;
	$only = ogc_committee_key( (string) $req->get_param( 'c' ) );
	foreach ( ogc_app_requests( $y ) as $k => $x ) {
		$c = ogc_app_committee( $y, $k );
		if ( ! $c || 'coa' === $k || ! $x['left'] || ( '' !== $only && $only !== $k ) ) {
			continue;
		}
		// Once a day per committee, however many times it's pressed.
		if ( isset( $sent[ $k ] ) && $sent[ $k ] === $today ) {
			$again++;
			continue;
		}
		$to = array_values( array_filter( ogc_app_people( $y, $k ), function ( $m ) {
			return ! empty( $m['head'] );
		} ) );
		if ( ! $to ) {
			$none++;
			continue;
		}
		$items = ogc_app_weekly_items( $y, $k );
		if ( ! $items ) {
			continue;
		}
		foreach ( $to as $m ) {
			ogc_mail_send_kind( 'app_weekly', $m['email'], array( 'year' => $y, 'committee' => $c['name'], 'items' => $items ), array( 'to_member' => true ) );
			$heads++;
		}
		$sent[ $k ] = $today;
	}
	ogc_state_put( $y, 'app-remind', $sent, $st ? $st['version'] : 0 );
	ogc_log( 'app_remind', $y, 'requests', array( 'n' => $heads ) );
	return rest_ensure_response( array( 'sent' => $heads, 'nohead' => $none, 'already' => $again ) );
}

/* ================================================================== the webmasters' Home */

/** Per year: what's public now, what goes public next, the COA's sign-in, access ending; and the mail. */
function ogc_app_webmaster_home( $today ) {
	global $wpdb;
	$years = array();
	$needs = array();
	$list  = ogc_years_list();
	rsort( $list );
	foreach ( array_slice( $list, 0, 3 ) as $yy ) {
		$row  = ogc_year_get( $yy );
		$coa  = array_filter( ogc_members_list( $yy ), function ( $m ) {
			return 'coa' === $m['role'] && ogc_member_active( $m );
		} );
		$in   = count( array_filter( $coa, function ( $m ) {
			return ! empty( $m['signed_in_at'] );
		} ) );
		$pub  = array();
		$next = array();
		$s    = function_exists( 'ogc_coa_kv' ) ? ogc_coa_kv( $yy, 'settings' ) : array();
		$r    = function_exists( 'ogc_coa_kv' ) ? ogc_coa_kv( $yy, 'registration' ) : array();
		$ann  = $row && ! empty( $row['coa_announced'] ) ? (string) $row['coa_announced'] : '';
		$gates = array(
			array( 'The Conference page', $ann ),
			// What the public reads: a date carried from last year that nobody scheduled isn't set.
			array( 'Registration', function_exists( 'ogc_pub_reg' ) ? (string) ogc_pub_reg( $yy )['opens'] : ( isset( $r['opens'] ) ? (string) $r['opens'] : '' ) ),
			array( 'Volunteer shifts', isset( $s['signups_posted'] ) ? (string) $s['signups_posted'] : '' ),
			array( 'The schedule', isset( $s['schedule_posted'] ) ? (string) $s['schedule_posted'] : '' ),
			array( 'The packet', isset( $s['packet_posted'] ) ? (string) $s['packet_posted'] : '' ),
		);
		foreach ( $gates as $g ) {
			if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $g[1] ) || '9999-12-31' === $g[1] ) {
				continue;
			}
			if ( $g[1] <= $today ) {
				$pub[] = $g[0];
			} else {
				$next[] = array( $g[0], $g[1] );
			}
		}
		usort( $next, function ( $a, $b ) {
			return strcmp( $a[1], $b[1] );
		} );
		$ending = 0;
		foreach ( $coa as $m ) {
			$x = function_exists( 'ogc_member_expiry' ) ? ogc_member_expiry( $m ) : null;
			$ending += $x && strtotime( $x . ' UTC' ) < strtotime( $today . ' UTC' ) + 30 * DAY_IN_SECONDS ? 1 : 0;
		}
		$years[] = array(
			'year'   => $yy,
			'label'  => $yy . ( $row && ! empty( $row['venue'] ) ? ' · ' . ogc_app_venue_short( $row['venue'] ) : '' ),
			'public' => $pub ? implode( ', ', $pub ) : 'Nothing yet',
			'next'   => $next ? $next[0][0] . ' · ' . ogc_app_md( $next[0][1], $yy ) : '',
			'coa'    => $coa ? $in . ' of ' . count( $coa ) . ' signed in' : 'No COA',
			'ending' => $ending,
		);
		if ( ! $coa ) {
			$needs[] = array( 'key' => 'nocoa:' . $yy, 'words' => $yy . ' · No COA yet', 'why' => 'Add the COA on Access', 'go' => array( 's' => 'members', 'year' => $yy ), 'button' => 'Add COA', 'tone' => 'look', 'rank' => 2 );
		} elseif ( $in < count( $coa ) ) {
			$needs[] = array( 'key' => 'coain:' . $yy, 'words' => $yy . ' · ' . ( count( $coa ) - $in ) . ' COA not signed in', 'why' => 'Resend from Access', 'go' => array( 's' => 'members', 'year' => $yy, 'v' => 'invited' ), 'button' => 'Open Access', 'rank' => 3 );
		}
		if ( $ending ) {
			$needs[] = array( 'key' => 'ending:' . $yy, 'words' => $yy . ' · ' . ogc_app_plural( $ending, 'COA member' ) . '’s access ends soon', 'why' => 'Within 30 days · Send again to renew', 'go' => array( 's' => 'members', 'year' => $yy ), 'button' => 'Open Access', 'rank' => 3 );
		}
	}
	// Mail that didn't go, in the last two weeks.
	$since = gmdate( 'Y-m-d H:i:s', strtotime( $today . ' 12:00 UTC' ) - 14 * DAY_IN_SECONDS );
	$wpdb->suppress_errors( true );
	$bad = $wpdb->get_results( $wpdb->prepare( 'SELECT status, COUNT(*) AS n FROM ' . ogc_table( 'mail' ) . " WHERE at > %s AND status IN ('failed','refused') GROUP BY status", $since ), ARRAY_A );
	$wpdb->suppress_errors( false );
	$mail = array( 'failed' => 0, 'refused' => 0 );
	foreach ( (array) $bad as $b ) {
		$mail[ $b['status'] ] = (int) $b['n'];
	}
	if ( $mail['failed'] || $mail['refused'] ) {
		$needs[] = array( 'key' => 'mail', 'words' => trim( ( $mail['failed'] ? ogc_app_plural( $mail['failed'], 'email' ) . ' failed' : '' ) . ( $mail['failed'] && $mail['refused'] ? ' · ' : '' ) . ( $mail['refused'] ? $mail['refused'] . ' refused' : '' ) ), 'why' => 'In the last two weeks', 'go' => array( 's' => 'mail' ), 'button' => 'Open Mail', 'tone' => 'late', 'rank' => 0 );
	}
	// From October, the next Conference: Start it (the Advisors asked for it before January).
	// "Started" is the app's own data (a year folder, or committees), never a years.csv row: a year
	// whose hosts were named (2028's row) isn't started by that.
	$max = 0;
	foreach ( $list as $yy ) {
		$r = ogc_year_get( $yy );
		if ( ( $r && ! empty( $r['data'] ) ) || ogc_app_committees( $yy ) ) {
			$max = max( $max, (int) $yy );
		}
	}
	$next = $max ? $max + 1 : 0;
	$row  = $max ? ogc_year_get( $max ) : null;
	$cur  = (int) substr( $today, 0, 4 );
	if ( $next && (int) substr( $today, 5, 2 ) >= 10 && $next <= $cur + 2 && $row && ! empty( $row['end'] ) && $row['end'] < $next . '-01-01' ) {
		$nr      = ogc_year_get( $next );
		// What Start does, said where it's offered: its COA may already be invited (Access works before).
		$needs[] = array( 'key' => 'start', 'words' => 'Start ' . $next, 'why' => 'Picks up ' . $max . '’s committees, tasks and files' . ( $nr && ! empty( $nr['hosts'] ) ? ' · Hosts: ' . $nr['hosts'] : '' ), 'go' => array( 's' => 'years', 'id' => 'start' ), 'button' => 'Start ' . $next, 'rank' => 1 );
	}
	usort( $needs, function ( $a, $b ) {
		return $a['rank'] - $b['rank'];
	} );
	return array( 'needs' => $needs, 'years' => $years );
}

/* ================================================================== the weekly note */

add_filter( 'ogc_mail_kinds', function ( $k ) {
	$k['app_weekly'] = 'Weekly note (committees)';
	return $k;
} );
add_filter( 'ogc_mail_samples', function ( $s ) {
	$s['app_weekly'] = array( 'committee' => 'Lodging', 'items' => array( array( '12 new households', 'Since Feb 8', 'Review 12', ogc_url( 'app' ) ), array( '6 requests to answer', 'Due Jan 8', 'Answer 6', ogc_url( 'app' ) ) ), 'link' => ogc_url( 'app' ) );
	return $s;
} );
add_filter( 'ogc_mail_template_kind', function ( $m, $kind, $d, $base ) {
	if ( 'app_weekly' !== $kind ) {
		return $m;
	}
	$items = isset( $d['items'] ) ? (array) $d['items'] : array();
	$com   = isset( $d['committee'] ) ? wp_strip_all_tags( (string) $d['committee'] ) : '';
	$first = $items ? $items[0] : array( '', '', '', '' );
	$facts = array();
	foreach ( array_slice( $items, 1, 5 ) as $it ) {
		$facts[] = array( 'Also', $it[0] . ( $it[1] ? ' · ' . $it[1] : '' ) );
	}
	return ogc_mail_compose( array_merge( $base, array(
		'subject'   => $first[0] . ( $com ? ' · ' . $com : '' ),
		'preheader' => $first[1],
		// The subject is the heading, word for word (the set's rule).
		'heading'   => $first[0] . ( $com ? ' · ' . $com : '' ),
		'lines'     => array_filter( array( $first[1] ) ),
		'facts'     => $facts,
		'button'    => $first[3] ? array( $first[2], $first[3] ) : null,
		'after'     => array( 'Each Monday while something needs ' . ( $com ? $com : 'the committee' ) . '. The COA can turn it off on the committee’s page.' ),
		'reason'    => 'You’re on the ' . ( isset( $d['year'] ) ? (int) $d['year'] . ' ' : '' ) . $com . ' committee.',
	) ) );
}, 10, 4 );

/** A committee's weekly note: its needs as email lines, each with the one link to the exact screen. */
function ogc_app_weekly_items( $year, $ckey ) {
	$v = array( 'year' => (int) $year, 'coa' => 'coa' === $ckey, 'webmaster' => false, 'committees' => 'coa' === $ckey ? array() : array( $ckey ), 'head' => true, 'member_id' => 0, 'as' => '', 'open' => true );
	$out = array();
	foreach ( ogc_app_needs( $year, $v ) as $n ) {
		if ( 0 === strpos( (string) $n['key'], 'first:' ) || 'lod-new' === $n['key'] ) {
			continue; // Personal: what this one person hasn't opened yet.
		}
		$go    = array_merge( array( 'year' => (int) $year ), (array) $n['go'] );
		$out[] = array( $n['words'], $n['why'], $n['button'], ogc_url( 'app', array_filter( array_map( 'strval', $go ), 'strlen' ) ) );
	}
	// New households for Lodging: since the committee's last weekly note (the same "new" for everyone
	// on it), or the last 7 days before the first one.
	if ( 'lodging' === $ckey && function_exists( 'ogc_appc_lod_households' ) ) {
		$st    = ogc_state_get( (int) $year, 'app-weekly' );
		$last  = $st && ! empty( $st['value'][ $ckey ] ) ? (string) $st['value'][ $ckey ] : '';
		$since = $last ? $last . ' 07:00:00' : gmdate( 'Y-m-d H:i:s', strtotime( ogc_app_today( $year ) . ' 12:00 UTC' ) - 7 * DAY_IN_SECONDS );
		$n     = 0;
		foreach ( ogc_appc_lod_households( $year ) as $hh ) {
			$at = substr( str_replace( 'T', ' ', (string) $hh['created'] ), 0, 19 );
			$n += 'cancelled' !== $hh['status'] && $at > $since ? 1 : 0;
		}
		if ( $n ) {
			array_unshift( $out, array( ogc_app_plural( $n, 'new household' ), $last ? 'Since ' . ogc_app_md( $last, $year ) : '', 'Review ' . $n, ogc_url( 'app', array( 'year' => (int) $year, 's' => 'lod-households', 'v' => 'week' ) ) ) );
		}
	}
	return array_slice( $out, 0, 6 );
}

/** Is a committee's weekly note on? (committees.csv "weekly"; on unless the COA turned it off) */
function ogc_app_weekly_on( $year, $ckey ) {
	$f = function_exists( 'ogc_file_get' ) ? ogc_file_get( (int) $year, 'committees' ) : null;
	foreach ( $f ? (array) $f['rows'] : array() as $r ) {
		if ( isset( $r['name'] ) && ogc_committee_key( $r['name'] ) === $ckey ) {
			return 'no' !== strtolower( trim( isset( $r['weekly'] ) ? (string) $r['weekly'] : '' ) );
		}
	}
	return true;
}

// Mondays from 7 AM at the campus, before and during the Conference: each committee whose work needs
// it hears once, at every member's own address.
add_action( 'ogc_vol_tick', 'ogc_app_weekly_tick', 20 );

function ogc_app_weekly_tick() {
	if ( ! function_exists( 'ogc_app_tables_ready' ) || ! ogc_app_tables_ready() ) {
		return;
	}
	foreach ( ogc_years_list() as $y ) {
		$p = ogc_app_phase( $y );
		if ( ! in_array( $p['phase'], array( 'before', 'week' ), true ) ) {
			continue;
		}
		$tz  = function_exists( 'ogc_coa_tz' ) ? ogc_coa_tz( $y ) : wp_timezone();
		$now = new DateTime( 'now', $tz );
		if ( '1' !== $now->format( 'N' ) || (int) $now->format( 'G' ) < 7 ) {
			continue;
		}
		$day  = $now->format( 'Y-m-d' );
		$st   = ogc_state_get( $y, 'app-weekly' );
		$sent = $st ? (array) $st['value'] : array();
		foreach ( ogc_app_committees( $y ) as $c ) {
			$k = $c['ckey'];
			if ( 'coa' === $k || ( isset( $sent[ $k ] ) && $sent[ $k ] === $day ) || ! ogc_app_weekly_on( $y, $k ) ) {
				continue;
			}
			$items = ogc_app_weekly_items( $y, $k );
			$sent[ $k ] = $day;
			if ( ! $items ) {
				continue;
			}
			foreach ( ogc_app_people( $y, $k ) as $m ) {
				ogc_mail_send_kind( 'app_weekly', $m['email'], array( 'year' => $y, 'committee' => $c['name'], 'items' => $items ), array( 'to_member' => true ) );
			}
		}
		ogc_state_put( $y, 'app-weekly', $sent, $st ? $st['version'] : 0 );
	}
}

add_action( 'rest_api_init', function () {
	register_rest_route( OGC_NS, '/app/(?P<year>\d{4})/weekly', array(
		array(
			'methods'             => 'GET',
			'callback'            => function ( WP_REST_Request $req ) {
				$y     = (int) $req['year'];
				$k     = ogc_committee_key( (string) $req->get_param( 'c' ) );
				$c     = ogc_app_committee( $y, $k );
				$items = ogc_app_weekly_items( $y, $k );
				$t     = $items ? ogc_mail_template( 'app_weekly', array( 'year' => $y, 'committee' => $c ? $c['name'] : '', 'items' => $items, 'to' => 'their address' ) ) : null;
				return rest_ensure_response( array( 'on' => ogc_app_weekly_on( $y, $k ), 'items' => count( $items ), 'subject' => $t ? $t['subject'] : '', 'html' => $t ? $t['html'] : '' ) );
			},
			'permission_callback' => function ( WP_REST_Request $req ) {
				$v = ogc_app_req_viewer( $req );
				$k = ogc_committee_key( (string) $req->get_param( 'c' ) );
				return ogc_app_committee( (int) $req['year'], $k ) && ogc_app_on_committee( $v, $k ) ? true : ogc_rest_denied();
			},
		),
		array(
			'methods'             => 'PUT',
			'callback'            => function ( WP_REST_Request $req ) {
				$y  = (int) $req['year'];
				$k  = ogc_committee_key( (string) $req->get_param( 'c' ) );
				$on = rest_sanitize_boolean( $req->get_param( 'on' ) );
				for ( $try = 0; $try < 3; $try++ ) {
					$cur  = ogc_file_get( $y, 'committees' );
					$rows = $cur ? (array) $cur['rows'] : array();
					foreach ( $rows as &$r ) {
						if ( isset( $r['name'] ) && ogc_committee_key( $r['name'] ) === $k ) {
							$r['weekly'] = $on ? 'yes' : 'no';
						}
					}
					unset( $r );
					$res = ogc_file_put( $y, 'committees', $rows, $cur ? $cur['version'] : 0, array( 'name', 'contact_email', 'contact_phone', 'heads', 'weekly', 'order' ) );
					if ( ! is_wp_error( $res ) ) {
						break;
					}
				}
				ogc_log( 'app_committee_edit', $y, 'committee:' . $k, array( 'ckey' => $k, 'fields' => array( 'weekly' ) ) );
				return rest_ensure_response( array( 'on' => $on ) );
			},
			'permission_callback' => function ( WP_REST_Request $req ) {
				$v = ogc_app_req_viewer( $req );
				$k = ogc_committee_key( (string) $req->get_param( 'c' ) );
				return $v['coa'] && ! $v['as'] && 'coa' !== $k && ogc_app_committee( (int) $req['year'], $k ) ? true : ogc_rest_denied();
			},
		),
	) );
} );

/* ================================================================== the invite: where it lands, what it opens */

/** "Lodging · Home, Committees, Tasks, Households, Rooms…" for someone on committees; the COA's whole year. */
function ogc_app_access_words( $year, $role, $keys ) {
	if ( 'coa' === $role ) {
		return 'Every ' . (int) $year . ' screen';
	}
	$out = array();
	foreach ( (array) $keys as $k ) {
		$c = ogc_app_committee( (int) $year, $k );
		if ( ! $c ) {
			continue;
		}
		$v     = array( 'year' => (int) $year, 'coa' => false, 'webmaster' => false, 'committees' => array( $k ), 'head' => false, 'member_id' => 0, 'as' => '', 'open' => true );
		$names = array( 'Home', 'Committees', 'Tasks' );
		foreach ( ogc_app_screens_for( $v ) as $s ) {
			if ( 'own' === $s['section'] && 'overview' !== $s['id'] ) {
				$names[] = $s['title'];
			}
		}
		$out[] = $c['name'] . ' · ' . implode( ', ', array_unique( $names ) );
	}
	return implode( "\n", $out );
}

// The invite's landing is the app: a committee's own page, the COA's Home.
add_filter( 'ogc_member_landing_pre', function ( $path, $year, $role, $helps ) {
	if ( null !== $path || ! function_exists( 'ogc_app_tables_ready' ) || ! ogc_app_tables_ready() ) {
		return $path;
	}
	if ( 'coa' === $role ) {
		return wp_make_link_relative( ogc_url( 'app', array( 'year' => (int) $year ) ) );
	}
	foreach ( explode( ',', (string) $helps ) as $h ) {
		$k = ogc_committee_key( $h );
		if ( '' !== $k && ogc_app_committee( (int) $year, $k ) ) {
			return wp_make_link_relative( ogc_url( 'app', array( 'year' => (int) $year, 's' => 'overview', 'team' => $k ) ) );
		}
	}
	return $path;
}, 10, 4 );

// The invite's one fact: the first job ("Answer requests by Jan 8", "Announce the Conference by Nov
// 1"): the soonest undone task done on a screen, else the soonest undone task with a date.
add_filter( 'ogc_member_first', function ( $words, $m ) {
	if ( '' !== $words || ! $m || ! function_exists( 'ogc_app_tables_ready' ) || ! ogc_app_tables_ready() ) {
		return $words;
	}
	$y     = (int) $m['year'];
	// A year with no dates: the COA's first job is the dates (every task counts from them).
	if ( 'coa' === $m['role'] && ! ogc_app_friday( $y ) ) {
		$r = ogc_year_get( $y );
		return empty( $r['venue'] ) ? 'Set the dates and campus' : 'Set the dates';
	}
	$keys  = 'coa' === $m['role'] ? array( 'coa' ) : ( is_array( $m['committees'] ) ? $m['committees'] : array_filter( explode( ',', (string) $m['committees'] ) ) );
	$today = ogc_app_today( $y );
	$pick  = null;
	$any   = null;
	// A task done on a screen: a kind in the kinds table (First meeting has a kind only for merging).
	$tk    = ogc_app_task_kinds();
	foreach ( ogc_app_tasks( $y, array_values( $keys ) ) as $t ) {
		if ( $t['done'] || ! $t['due'] || $t['due'] < $today ) {
			continue;
		}
		if ( ! $pick && $t['kind'] && isset( $tk[ $t['kind'] ] ) ) {
			$pick = $t;
		}
		if ( ! $any ) {
			$any = $t;
		}
	}
	$t = $pick ? $pick : $any;
	return $t ? $t['title'] . ' by ' . ogc_app_md( $t['due'], $y ) : $words;
}, 10, 2 );

add_filter( 'ogc_member_access', function ( $words, $m ) {
	if ( '' !== $words || ! $m || ! function_exists( 'ogc_app_tables_ready' ) || ! ogc_app_tables_ready() ) {
		return $words;
	}
	return ogc_app_access_words( (int) $m['year'], $m['role'], 'coa' === $m['role'] ? array() : ogc_member_committee_keys( $m ) );
}, 10, 2 );

/* ================================================================== a year started by mistake */

/** Has anyone done anything in the app's year (beyond carrying it forward)? */
function ogc_app_year_touched( $year ) {
	global $wpdb;
	$y = (int) $year;
	if ( ! ogc_app_tables_ready() ) {
		return false;
	}
	$n  = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM ' . ogc_table( 'committees' ) . ' WHERE year = %d AND ( checked_at IS NOT NULL OR from_year = 0 )', $y ) );
	$n += (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM ' . ogc_table( 'tasks' ) . " WHERE year = %d AND ( done_at IS NOT NULL OR source = 'added' OR removed_at IS NOT NULL )", $y ) );
	$n += (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM ' . ogc_table( 'cnotes' ) . ' WHERE year = %d', $y ) );
	$n += (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM ' . ogc_table( 'cfiles' ) . ' WHERE year = %d AND carried_from = 0', $y ) );
	$n += (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM ' . ogc_table( 'creports' ) . ' WHERE year = %d', $y ) );
	// Someone invited to it (the local site's made-up members don't count).
	$n += (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM ' . ogc_table( 'members' ) . ' WHERE year = %d AND sample = 0 AND removed_at IS NULL', $y ) );
	$n += (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM ' . ogc_table( 'log' ) . " WHERE year = %d AND action IN ('app_committee_add','app_committee_edit','app_hand')", $y ) );
	return $n > 0;
}

// The committees.csv the app writes when it carries a year forward isn't someone's work.
add_filter( 'ogc_untouched_skip', function ( $skip, $year ) {
	if ( function_exists( 'ogc_app_tables_ready' ) && ! ogc_app_year_touched( $year ) ) {
		$skip[] = 'committees';
	}
	return $skip;
}, 10, 2 );

// Removing a year started by mistake removes the app's rows for it (files stay while last year has them).
add_action( 'ogc_year_unstart', function ( $year ) {
	global $wpdb;
	if ( ! function_exists( 'ogc_app_tables_ready' ) || ! ogc_app_tables_ready() ) {
		return;
	}
	foreach ( array( 'committees', 'tasks', 'cfiles', 'cnotes', 'creports' ) as $t ) {
		$wpdb->query( $wpdb->prepare( 'DELETE FROM ' . ogc_table( $t ) . ' WHERE year = %d', (int) $year ) );
	}
	unset( $GLOBALS['ogc_app_c'][ (int) $year ], $GLOBALS['ogc_app_ensured'][ (int) $year ] );
} );
