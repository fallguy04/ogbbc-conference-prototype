<?php
/**
 * The emails, as one set in one voice. Every area sends through these:
 *
 *   $m = ogc_mail_template( 'signed_up', array( 'year' => 2027, 'to' => $email, 'title' => 'Golf cart driver', … ) );
 *   // → array( 'subject' => …, 'html' => …, 'text' => … ), or null for an unknown kind
 *   ogc_mail_send_kind( 'signed_up', $email, $data, array( 'ics' => $ics ) );   // template + send
 *
  * One layout (ogc_mail_compose): the site's name as words (no images, remote fonts or tracking), one
  * heading, two to four fact lines, one button in the site's tan with the page it opens written short
  * under it ("ogbbc.org/annual-conference/signin", never a token), secondary actions as quiet links
  * ("Not you? Remove"), a Questions line by role only when someone reads the replies, and a footer that
  * says who it was sent to and why. A plain-text twin with the same words and every address in full.
  * 600 px, readable in dark mode, Georgia standing in for Droid Serif.
 *
 * The rules every kind keeps:
  *   - The subject is the heading, word for word: what happened, then the thing ("Signed up · Golf cart
  *     driver · Sat, May 29", "Rooms posted", "Approval needed"), never a sentence. The sender's name
  *     says "Annual Conference" and the small line above the heading says which year (sign-in emails
  *     name none: signing in isn't about one year).
  *   - The footer says who it went to; it gives a reason only when no line above already says it.
 *   - Times end with the venue's zone ("7–11 AM Eastern"); dates read "Sat, May 29". Each template reads
 *     the year's settings when it's sent, so a moved date is never stale.
  *   - No children's names or ages, no preteen pick-ups, no emergency contacts, no room numbers, no one
  *     else's name or address (a parent's approval names no one: the details are on the link's card,
  *     after it's opened). Those stay behind sign-in (Your sign-ups, the committees' pages).
  *   - Replies go to the role that reads them: the part's contact (settings contact_<part>, named by
  *     owner_<part>), else the webmasters' address; with neither, no Questions line at all.
 *   - No exclamation marks, no "Lord willing" (kept to the Conference page's date), no links that
 *     sign someone in for longer than a few days.
 *   - Anything a visitor typed (a name) is cleaned (ogc_mail_safe_name) before it goes in.
 *
 * DEV.md lists every kind and its data. ogc_mail_samples() has a made-up example of each, drawn at
 * /annual-conference/mail/?preview=all on a local site.
 */

defined( 'ABSPATH' ) || exit;

/* ------------------------------------------------------------------ small helpers */

/** A name as it may go into an email: letters, spaces and ' - . only, up to 60, never a link. */
function ogc_mail_safe_name( $n ) {
	$n = wp_strip_all_tags( (string) $n );
	$n = preg_replace( '#(https?://|www\.)\S*#i', '', $n );
	$n = preg_replace( "/[^\\p{L}\\p{M} '.\\-]/u", '', $n );
	$n = trim( preg_replace( '/\s+/', ' ', (string) $n ) );
	return function_exists( 'mb_substr' ) ? mb_substr( $n, 0, 60 ) : substr( $n, 0, 60 );
}

/** "Ruth Kinsey" → "Ruth K." (the site's convention for names). */
function ogc_first_l( $n ) {
	$w = preg_split( '/\s+/', trim( ogc_mail_safe_name( $n ) ) );
	if ( count( $w ) < 2 ) {
		return (string) $w[0];
	}
	$last = end( $w );
	return $w[0] . ' ' . ( function_exists( 'mb_substr' ) ? mb_substr( $last, 0, 1 ) : substr( $last, 0, 1 ) ) . '.';
}

/** "ruth.kinsey@example.com" → "r***y@example.com", to name an address without spelling it out. */
function ogc_mask_email( $e ) {
	$e = strtolower( trim( (string) $e ) );
	if ( false === strpos( $e, '@' ) ) {
		return '';
	}
	list( $u, $d ) = explode( '@', $e, 2 );
	$u = strlen( $u ) <= 2 ? substr( $u, 0, 1 ) . '*' : substr( $u, 0, 1 ) . '***' . substr( $u, -1 );
	return $u . '@' . $d;
}

/** A year's settings (key → value), read now. */
function ogc_mail_settings( $year ) {
	$out = array();
	if ( ! ogc_valid_year( $year ) || ! function_exists( 'ogc_file_get' ) ) {
		return $out;
	}
	$f = ogc_file_get( (int) $year, 'settings' );
	foreach ( $f ? (array) $f['rows'] : array() as $r ) {
		if ( isset( $r['key'] ) ) {
			$out[ $r['key'] ] = isset( $r['value'] ) ? (string) $r['value'] : '';
		}
	}
	return $out;
}

/** "Eastern" from settings' timezone_label ("Eastern Time"). */
function ogc_mail_zone( $year ) {
	$s = ogc_mail_settings( $year );
	$z = isset( $s['timezone_label'] ) ? trim( preg_replace( '/\s+time$/i', '', $s['timezone_label'] ) ) : '';
	return $z;
}

/** "2027-05-29" → "Sat, May 29". */
function ogc_mail_date( $iso ) {
	$t = strtotime( (string) $iso . ' 12:00 UTC' );
	return $t ? gmdate( 'D, M j', $t ) : (string) $iso;
}

/** The date of a day name ("Saturday") in the year's Conference week, from settings first_day. */
function ogc_mail_day_date( $year, $day ) {
	if ( preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) $day ) ) {
		return $day;
	}
	$s     = ogc_mail_settings( $year );
	$first = isset( $s['first_day'] ) ? strtotime( $s['first_day'] . ' 12:00 UTC' ) : 0;
	if ( ! $first || '' === trim( (string) $day ) ) {
		return '';
	}
	$want = strtolower( substr( trim( $day ), 0, 3 ) );
	for ( $i = -1; $i < 7; $i++ ) {
		$t = $first + $i * DAY_IN_SECONDS;
		if ( strtolower( gmdate( 'D', $t ) ) === $want ) {
			return gmdate( 'Y-m-d', $t );
		}
	}
	return '';
}

/** "7:00 AM", "11:00 AM" → "7–11 AM"; "11:00 AM", "3:00 PM" → "11 AM–3 PM". Words ("After Communion")
 * pass through. */
function ogc_mail_span( $start, $end = '' ) {
	$p = function ( $t ) {
		if ( preg_match( '/^\s*(\d{1,2})(?::(\d{2}))?\s*([ap])\.?m?\.?\s*$/i', (string) $t, $m ) ) {
			return array( (int) $m[1] . ( isset( $m[2] ) && '00' !== $m[2] && '' !== $m[2] ? ':' . $m[2] : '' ), strtoupper( $m[3] ) . 'M' );
		}
		if ( 'noon' === strtolower( trim( (string) $t ) ) ) {
			return array( '12', 'PM' );
		}
		return null;
	};
	$a = $p( $start );
	$b = $p( $end );
	if ( ! $a ) {
		return trim( (string) $start );
	}
	if ( ! $b ) {
		return $a[0] . ' ' . $a[1];
	}
	return $a[1] === $b[1] ? $a[0] . '–' . $b[0] . ' ' . $b[1] : $a[0] . ' ' . $a[1] . '–' . $b[0] . ' ' . $b[1];
}

/** "Sat, May 29 · 7–11 AM Eastern", from a day (or date) and two times. */
function ogc_mail_when( $year, $day, $start = '', $end = '' ) {
	$date = ogc_mail_day_date( $year, $day );
	$d    = $date ? ogc_mail_date( $date ) : (string) $day;
	$span = ogc_mail_span( $start, $end );
	$zone = ogc_mail_zone( $year );
	if ( '' === $span ) {
		return $d;
	}
	return trim( $d . ' · ' . $span . ( $zone && preg_match( '/[AP]M$/', $span ) ? ' ' . $zone : '' ) );
}

/** Where a button ends up: its third part when a template says, else for a one-time link (signin/?t=)
 * the page it returns to, else the link itself. */
function ogc_mail_shown_url( $button ) {
	if ( ! empty( $button[2] ) ) {
		return (string) $button[2];
	}
	$url = (string) $button[1];
	$q   = array();
	wp_parse_str( (string) wp_parse_url( $url, PHP_URL_QUERY ), $q );
	if ( ! empty( $q['t'] ) ) {
		$t = function_exists( 'ogc_token_find' ) ? ogc_token_find( (string) $q['t'] ) : null;
		// A one-time link with no page to return to (where it lands depends on who signs in): the site.
		return $t && ! empty( $t['return_to'] ) ? home_url( $t['return_to'] ) : home_url( '/' );
	}
	return $url;
}

/** "ogbbc.org/annual-conference/signin": a link's site and page, without its query (never a token). */
function ogc_mail_short_url( $url ) {
	$u = wp_parse_url( (string) $url );
	if ( empty( $u['host'] ) ) {
		return '';
	}
	return preg_replace( '/^www\./', '', $u['host'] ) . ( isset( $u['port'] ) ? ':' . $u['port'] : '' ) . untrailingslashit( isset( $u['path'] ) ? $u['path'] : '' );
}

/**
 * Who reads the replies to a kind of email: the part's contact (settings contact_<part>, an address the
 * COA sets; its name is owner_<part>), else the webmasters' role address. Returns array( questions
 * words, reply_to ), or array( '', '' ) when nobody does: then the email promises no reader.
 */
function ogc_mail_questions( $kind, $year ) {
	$parts = (array) apply_filters( 'ogc_mail_kind_parts', array(
		'registration_received' => 'registration', 'registration_changed' => 'registration', 'registered_for_you' => 'registration',
		'parent_approval' => 'registration', 'payment_received' => 'registration', 'credit_asked' => 'registration', 'credit_given' => 'registration',
		'rooms_posted' => 'registration', 'rooms_changed' => 'registration',
		'signed_up' => 'helping', 'reminder' => 'helping', 'shift_changed' => 'helping', 'shift_removed' => 'helping', 'you_left' => 'helping', 'spot_open' => 'helping',
		'team_signed_up' => 'youngfolks',
		'invite' => '', 'access_ending' => '', 'email_changed' => '',
	) );
	if ( ! array_key_exists( $kind, $parts ) ) {
		return array( '', '' );
	}
	$s    = $year ? ogc_mail_settings( $year ) : array();
	$part = $parts[ $kind ];
	$addr = $part && ! empty( $s[ 'contact_' . $part ] ) && is_email( trim( $s[ 'contact_' . $part ] ) ) ? trim( $s[ 'contact_' . $part ] ) : '';
	if ( $addr ) {
		$role = $part && ! empty( $s[ 'owner_' . $part ] ) ? trim( preg_replace( '/\s+committee$/i', '', $s[ 'owner_' . $part ] ) ) . ' committee' : '';
		return array( ( $role ? $role . ' · ' : '' ) . 'Reply to this email', $addr );
	}
	$def = function_exists( 'ogc_mail_reply_default' ) ? ogc_mail_reply_default() : '';
	return $def ? array( 'Reply to this email', $def ) : array( '', '' );
}

/** What's open to the public for a year right now (event-driven: an email offers only what's posted):
 * register (registration open on the site), volunteer (sign-ups posted and not closed). */
function ogc_mail_open_now( $year ) {
	$y     = (int) $year;
	$today = function_exists( 'ogc_coa_today' ) ? ogc_coa_today( $y ) : wp_date( 'Y-m-d' );
	$reg   = $y && function_exists( 'ogc_reg_phase' ) && 'open' === ogc_reg_phase( $y, $today ) && ( ! function_exists( 'ogc_coa_posted' ) || ogc_coa_posted( $y, 'registration_opens' ) );
	$s     = $y ? ogc_mail_settings( $y ) : array();
	$f     = $y && function_exists( 'ogc_file_get' ) ? ogc_file_get( $y, 'shifts' ) : null;
	$shut  = ! empty( $s['signups_closed'] ) && preg_match( '/^\d{4}-\d{2}-\d{2}$/', $s['signups_closed'] ) && $s['signups_closed'] <= $today;
	$vol   = $y && $f && ! empty( $f['rows'] ) && ! $shut && ( function_exists( 'ogc_coa_posted' ) ? ogc_coa_posted( $y, 'signups_posted' ) : ( ! empty( $s['signups_posted'] ) && $s['signups_posted'] <= $today ) );
	return array( 'register' => (bool) $reg, 'volunteer' => (bool) $vol );
}

/** "$65" / "$1,234.50". */
function ogc_mail_money( $n ) {
	$n = (float) $n;
	return '$' . ( floor( $n ) == $n ? number_format( $n ) : number_format( $n, 2 ) ); // phpcs:ignore -- loose on purpose.
}

/* ------------------------------------------------------------------ the layout */

/**
 * One email, laid out. $a:
  *   subject, preheader, heading, code (big, spaced), facts (array of [label, value]), lines (short
  *   paragraphs), button ([label, url]), after (muted lines under the button: a string, or
  *   [words, link label, url] for a quiet link: "Not you? Remove"), questions ("Registration committee ·
  *   reply to this email"), year, to, reason (why they got it), reason_link ([words, label, url] after
  *   the reason: "Didn’t sign up? Remove this address"). Returns subject, html, text.
 */
function ogc_mail_compose( $a ) {
	$a      = array_merge( array( 'subject' => '', 'preheader' => '', 'heading' => '', 'code' => '', 'facts' => array(), 'lines' => array(), 'button' => null, 'after' => array(), 'questions' => '', 'year' => 0, 'to' => '', 'reason' => '', 'plain' => '' ), (array) $a );
	$year   = ogc_valid_year( $a['year'] ) ? (int) $a['year'] : 0;
	$conf   = $year ? $year . ' Annual Conference' : 'Annual Conference';
	$serif  = "'Droid Serif',Georgia,'Times New Roman',serif";
	$sans   = 'Arial,Helvetica,sans-serif';
	$e      = function ( $s ) {
		return esc_html( (string) $s );
	};
	$h = array();
	$t = array();

	$h[] = '<h1 class="o-ink" style="margin:0 0 18px;font-family:' . $serif . ';font-size:22px;line-height:1.3;font-weight:700;color:#333333;">' . $e( $a['heading'] ) . '</h1>';
	$t[] = $a['heading'];
	$t[] = '';
	if ( '' !== $a['code'] ) {
		$h[] = '<p class="o-code" style="margin:0 0 20px;padding:14px 0;background:#F3F2EB;border-radius:5px;text-align:center;font-family:' . $sans . ';font-size:32px;line-height:1;font-weight:700;letter-spacing:6px;color:#333333;">' . $e( $a['code'] ) . '</p>';
		$t[] = $a['code'];
		$t[] = '';
	}
	if ( $a['facts'] ) {
		$rows = '';
		foreach ( $a['facts'] as $f ) {
			if ( ! is_array( $f ) || '' === (string) $f[1] ) {
				continue;
			}
			$rows .= '<tr><td class="o-kick" valign="top" style="padding:6px 16px 6px 0;font-family:' . $sans . ';font-size:12px;line-height:20px;font-weight:700;letter-spacing:1.2px;text-transform:uppercase;color:#76623F;white-space:nowrap;">' . $e( $f[0] ) . '</td>' .
				'<td class="o-ink" valign="top" style="padding:6px 0;font-family:' . $serif . ';font-size:16px;line-height:22px;color:#333333;">' . nl2br( $e( $f[1] ) ) . '</td></tr>';
			$t[] = $f[0] . ': ' . $f[1];
		}
		$h[] = '<table role="presentation" cellpadding="0" cellspacing="0" border="0" style="margin:0 0 18px;border-collapse:collapse;">' . $rows . '</table>';
		$t[] = '';
	}
	foreach ( (array) $a['lines'] as $l ) {
		$h[] = '<p class="o-ink" style="margin:0 0 14px;font-family:' . $serif . ';font-size:16px;line-height:1.55;color:#333333;">' . nl2br( $e( $l ) ) . '</p>';
		$t[] = $l;
	}
	if ( '' !== $a['plain'] ) {
		// A head's own words (Message): kept exactly, as plain text.
		$h[] = '<div class="o-ink" style="margin:0 0 18px;padding:14px 16px;border-left:3px solid #C0AB85;font-family:' . $serif . ';font-size:16px;line-height:1.55;color:#333333;">' . nl2br( $e( $a['plain'] ) ) . '</div>';
		$t[] = $a['plain'];
		$t[] = '';
	}
	if ( $a['lines'] ) {
		$t[] = '';
	}
	if ( is_array( $a['button'] ) && ! empty( $a['button'][1] ) ) {
		$url = esc_url( $a['button'][1] );
		$h[] = '<table role="presentation" cellpadding="0" cellspacing="0" border="0" style="margin:6px 0 10px;"><tr><td bgcolor="#C0AB85" style="border-radius:5px;background:#C0AB85;">' .
			'<a href="' . $url . '" style="display:inline-block;padding:13px 26px;min-width:120px;text-align:center;font-family:' . $sans . ';font-size:15px;line-height:18px;font-weight:700;color:#333333;text-decoration:none;border-radius:5px;">' . $e( $a['button'][0] ) . '</a></td></tr></table>' .
			// Where it goes, short (the page it ends on, never a token): someone can see it's ogbbc.org
			// and which page before tapping.
			'<p class="o-muted" style="margin:0 0 18px;font-family:' . $sans . ';font-size:13px;line-height:1.5;color:#5f5a52;">' . $e( ogc_mail_short_url( ogc_mail_shown_url( $a['button'] ) ) ) . '</p>';
		$t[] = $a['button'][0] . ': ' . $a['button'][1];
		$t[] = '';
	}
	foreach ( (array) $a['after'] as $l ) {
		if ( is_array( $l ) ) {
			// A quiet link with a word: "Not you? Remove".
			if ( empty( $l[2] ) ) {
				continue;
			}
			$h[] = '<p class="o-muted" style="margin:0 0 8px;font-family:' . $sans . ';font-size:14px;line-height:1.5;color:#5f5a52;">' . ( '' !== (string) $l[0] ? $e( $l[0] ) . ' ' : '' ) .
				'<a href="' . esc_url( $l[2] ) . '" style="color:#76623F;text-decoration:underline;">' . $e( $l[1] ) . '</a></p>';
			$t[] = trim( $l[0] . ' ' . $l[1] ) . ': ' . $l[2];
			continue;
		}
			if ( '' === (string) $l ) {
				continue;
			}
			$h[] = '<p class="o-muted" style="margin:0 0 8px;font-family:' . $sans . ';font-size:14px;line-height:1.5;color:#5f5a52;">' . $e( $l ) . '</p>';
			$t[] = $l;
		}
	if ( $a['questions'] ) {
		$h[] = '<p class="o-muted" style="margin:14px 0 0;font-family:' . $sans . ';font-size:14px;line-height:1.5;color:#5f5a52;">Questions · ' . $e( $a['questions'] ) . '</p>';
		$t[] = 'Questions · ' . $a['questions'];
	}
	$foot = array();
	if ( $a['to'] ) {
		$foot[] = 'Sent to ' . $a['to'] . '.' . ( $a['reason'] ? ' ' . $a['reason'] : '' );
	}
	$foot[] = 'ogbbc.org never asks for a password or card number by email.';
	$foot[] = 'Old German Baptist Brethren Church, New Conference';
	// reason_link ([words, label, url]): a way out for someone who got it by mistake ("Didn’t sign up?
	// Remove this address"), said beside why it came, never among the email's own actions (volunteer,
	// after the second critic, Oct 15).
	$rl   = is_array( $a['reason_link'] ?? null ) && ! empty( $a['reason_link'][2] ) ? $a['reason_link'] : null;
	$fh   = array_map( $e, $foot );
	if ( $rl && $a['to'] ) {
		$fh[0] .= ' ' . $e( $rl[0] ) . ' <a href="' . esc_url( $rl[2] ) . '" style="color:#5f5a52;text-decoration:underline;">' . $e( $rl[1] ) . '</a>';
		$foot[0] .= ' ' . $rl[0] . ' ' . $rl[1] . ': ' . $rl[2];
	}

	$html = '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">' .
		'<meta name="color-scheme" content="light dark"><meta name="supported-color-schemes" content="light dark"><title>' . $e( $a['subject'] ) . '</title>' .
		'<style>:root{color-scheme:light dark}a{color:#76623F}' .
		'@media (prefers-color-scheme:dark){.o-bg{background:#1c1b18!important}.o-card{background:#272622!important;border-color:#3b3934!important}.o-ink{color:#ece8df!important}.o-muted,.o-muted a{color:#b9b2a4!important}.o-kick{color:#d9c49d!important}.o-code{background:#1c1b18!important;color:#ece8df!important}}' .
		'@media (max-width:620px){.o-pad{padding:26px 20px!important}}</style></head>' .
		'<body class="o-bg" style="margin:0;padding:0;background:#F3F2EB;-webkit-text-size-adjust:100%;">' .
		( $a['preheader'] ? '<div style="display:none;max-height:0;overflow:hidden;mso-hide:all;">' . $e( $a['preheader'] ) . '</div>' : '' ) .
		'<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" class="o-bg" bgcolor="#F3F2EB" style="background:#F3F2EB;"><tr><td align="center" style="padding:28px 12px 32px;">' .
		'<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="max-width:600px;">' .
		'<tr><td class="o-kick" style="padding:0 4px 12px;font-family:' . $sans . ';font-size:12px;line-height:1.4;font-weight:700;letter-spacing:1.2px;text-transform:uppercase;color:#76623F;">ogbbc.org · ' . $e( $conf ) . '</td></tr>' .
		'<tr><td class="o-card o-pad" bgcolor="#ffffff" style="background:#ffffff;border:1px solid #e6e2d8;border-radius:8px;padding:34px 38px 30px;">' . implode( '', $h ) . '</td></tr>' .
		'<tr><td class="o-muted" style="padding:18px 4px 0;font-family:' . $sans . ';font-size:12px;line-height:1.6;color:#5f5a52;">' . implode( '<br>', $fh ) . '</td></tr>' .
		'</table></td></tr></table></body></html>';

	$t[] = '';
	$t[] = '--';
	foreach ( $foot as $f ) {
		$t[] = $f;
	}
	$text = trim( preg_replace( "/\n{3,}/", "\n\n", implode( "\n", $t ) ) ) . "\n";
	return array( 'subject' => $a['subject'], 'html' => $html, 'text' => $text );
}

/** An email someone wrote as plain text, laid out in the house style: its subject as the heading,
 * its paragraphs as lines, addresses as links. */
function ogc_mail_from_text( $subject, $text, $year = 0, $to = '' ) {
	$m = ogc_mail_compose( array(
		'subject' => $subject,
		'heading' => $subject,
		'lines'   => array_values( array_filter( array_map( 'trim', preg_split( "/\n\s*\n/", (string) $text ) ), 'strlen' ) ),
		'year'    => $year,
		'to'      => $to,
	) );
	// Links in the words become links (escaped already: only http(s) addresses are matched).
	return preg_replace_callback( '#(?<![">])(https?://[^\s<]+)#', function ( $m ) {
		$u = esc_url( html_entity_decode( $m[1] ) );
		return '<a href="' . $u . '" style="color:#76623F;word-break:break-all;">' . $m[1] . '</a>';
	}, $m['html'] );
}

/* ------------------------------------------------------------------ the set */

/** Every kind, with a few words on what it's for (the Mail log's preview and DEV.md). */
function ogc_mail_kinds() {
	return array(
		'signin'                => 'Sign-in code',
		'no_signups'            => 'No sign-ups (an address the site doesn’t know)',
		'signin_wplogin'        => 'Sign in at wp-login (an editor or admin)',
		'codes_off'             => 'Codes off for a day (too many wrong)',
		'invite'                => 'Added to a year',
		'webmaster'             => 'Added as a webmaster',
		'access_ending'         => 'Access ending (14 days before)',
		'access_asked'          => 'Access asked (to the COA)',
		'registration_received' => 'Registration received',
		'registration_changed'  => 'Registration changed',
		'registered_for_you'    => 'Registered for you (the household’s copy)',
		'parent_approval'       => 'Approval needed (a parent)',
		'payment_received'      => 'Payment received',
		'credit_asked'          => 'Credit asked',
		'credit_given'          => 'Credit given',
		'rooms_posted'          => 'Rooms posted',
		'rooms_changed'         => 'Rooms changed',
		'signed_up'             => 'Signed up (a shift, or several gathered)',
		'reminder'              => 'Tomorrow (the day before)',
		'shift_changed'         => 'Shift changed',
		'shift_removed'         => 'Shift removed',
		'you_left'              => 'Left a shift',
		'volunteer_left'        => 'Place open (to the committee)',
		'spot_open'             => 'Place open (waitlist)',
		'team_signed_up'        => 'Team signed up',
		'message'               => 'Message (a head’s own words)',
		'weekly'                => 'This week (to the committee)',
		'confirm_email'         => 'Confirm email (a new address)',
		'email_changed'         => 'Email changed (to the old address)',
	) + (array) apply_filters( 'ogc_mail_kinds', array() );
}

/** Kinds whose subject holds a code or a name: the log on ogbbc.org keeps only the kind's label. */
function ogc_mail_private_kinds() {
	return array_merge( array( 'signin', 'confirm_email', 'parent_approval', 'access_asked', 'registration_received', 'registration_changed', 'registered_for_you', 'volunteer_left' ), (array) apply_filters( 'ogc_mail_private_kinds', array() ) );
}

/**
 * One email of the set. $kind is a key of ogc_mail_kinds(); $d its data (year and to always; the rest
 * per kind, as DEV.md lists). Returns array( subject, html, text, reply_to ) or null. reply_to is who
 * reads the replies (ogc_mail_questions); ogc_mail_send_kind uses it.
 */
function ogc_mail_template( $kind, $d ) {
	$d    = array_merge( array( 'year' => 0, 'to' => '', 'url' => '' ), (array) $d );
	$y    = ogc_valid_year( $d['year'] ) ? (int) $d['year'] : 0;
	$conf = $y ? $y . ' Annual Conference' : 'Annual Conference';
	$g    = function ( $k, $def = '' ) use ( $d ) {
		return isset( $d[ $k ] ) && '' !== $d[ $k ] && null !== $d[ $k ] ? $d[ $k ] : $def;
	};
	$name  = function ( $k ) use ( $g ) {
		return ogc_mail_safe_name( $g( $k ) );
	};
	$q     = ogc_mail_questions( $kind, $y );
	$mine  = $g( 'url', ogc_url( 'register', array_filter( array( 'view' => 'mine', 'year' => $y ?: null ) ) ) );
	$base  = array( 'year' => $y, 'to' => $d['to'], 'questions' => $g( 'questions', $q[0] ) );
	$when  = $g( 'when', $g( 'day' ) ? ogc_mail_when( $y, $g( 'day' ), $g( 'start' ), $g( 'end' ) ) : '' );
	$place = $g( 'place' );
	$title = $g( 'title' ) ? wp_strip_all_tags( (string) $g( 'title' ) ) : '';
	$short = $when ? preg_replace( '/ · .*$/', '', $when ) : '';
	// A shift's time before and after a change: built the same way as every other time.
	$at = function ( $v ) use ( $y ) {
		if ( is_array( $v ) ) {
			$v = array_merge( array( 'day' => '', 'start' => '', 'end' => '', 'place' => '' ), $v );
			return trim( ogc_mail_when( $y, $v['day'], $v['start'], $v['end'] ) . ( $v['place'] ? ' · ' . $v['place'] : '' ) );
		}
		return (string) $v;
	};
	$m     = null;

	switch ( $kind ) {
		case 'signin':
			$code = preg_replace( '/^(\d{3})(\d{3})$/', '$1 $2', (string) $g( 'code' ) );
			// One subject for everyone, with no code in it (a locked phone's screen shows the subject;
			// questions-signin Q2). No code at all for a webmaster, or while codes are off for the address.
			$mins = (int) $g( 'minutes', 30 );
			// The registration form's code (confirm): someone registering never asked to sign in.
			$what = '' !== $code ? ( $g( 'confirm' ) ? 'Confirm your email' : 'Sign-in code' ) : 'Sign-in link';
			$m    = ogc_mail_compose( array_merge( $base, array(
				'subject'   => $what,
				'preheader' => 'Works once, for ' . $mins . ' minutes',
				'heading'   => $what,
				'code'      => $code,
				// A link signs in the device it's opened on: asked on a laptop and read on a phone, it has
				// to be opened on the laptop.
				'lines'     => '' !== $code ? array() : array_values( array_filter( array( $g( 'codes_off' ) ? 'Codes are off for a day: too many wrong codes were typed for this address.' : '', 'Open the link on the device you’re signing in on.' ) ) ),
				// The link signs in whichever device opens it; the code is for the screen that asked.
				'button'    => array( 'Sign in on this device', $g( 'url' ) ),
				'after'     => array( 'Works once, for ' . $mins . ' minutes.', '' !== $code ? 'Never give this code to anyone, even someone from the Conference.' : '', 'Didn’t ask? Ignore this email.' ),
				'questions' => '',
				'year'      => 0,
			) ) );
			break;

		case 'no_signups':
			// An address the site doesn't know: the same fixed words for anyone who types it, at most once
			// a day. It offers only what's open now (event-driven): Register while registration is open on
			// the site, Volunteer once sign-ups are posted; with neither, just signing in with another email.
			// Asked from a committee's page: not on the members list, and who to ask.
			if ( $g( 'members_page' ) && $y ) {
				$m = ogc_mail_compose( array_merge( $base, array(
					'subject'   => 'Not on the ' . $y . ' members list',
					'heading'   => 'Not on the ' . $y . ' members list',
					'lines'     => array( 'Ask the Committee of Arrangements to invite this address, or sign in with the email they invited.' ),
					'button'    => array( 'Sign in with another email', ogc_url( 'signin', array_filter( array( 'return' => $g( 'return' ) ? rawurlencode( (string) $g( 'return' ) ) : null ) ) ), ogc_url( 'signin' ) ),
					'after'     => array( 'Didn’t ask? Ignore this email.' ),
					'questions' => '',
				) ) );
				break;
			}
			$open    = ogc_mail_open_now( $y );
			$actions = array();
			if ( $open['register'] ) {
				$actions[] = array( 'Register', ogc_url( 'register', array( 'year' => $y ) ) );
			}
			if ( $open['volunteer'] ) {
				$actions[] = array( 'Volunteer', ogc_url( 'volunteer', array( 'year' => $y ) ) );
			}
			$actions[] = array( 'Sign in with another email', ogc_url( 'signin' ) );
			$first     = array_shift( $actions );
			$m         = ogc_mail_compose( array_merge( $base, array(
				'subject'   => 'No sign-ups under this email',
				'heading'   => 'No sign-ups under this email',
				'lines'     => array( 'Registered or signed up with another email? Sign in with that one. A household registered by one person is under that person’s email.' ),
				'button'    => $first,
				'after'     => array_merge( array_map( function ( $a ) {
					return array( '', $a[0], $a[1] );
				}, $actions ), array( 'Didn’t ask? Ignore this email.' ) ),
				'questions' => '',
			) ) );
			break;

		case 'signin_wplogin':
			// An editor or admin of the site: they sign in at wp-login, with its two-step sign-in.
			$m = ogc_mail_compose( array_merge( $base, array(
				'subject'   => 'Sign in at wp-login',
				'heading'   => 'Sign in at wp-login',
				'lines'     => array( 'This address is an editor or administrator of ogbbc.org, so emailed codes don’t work for it.' ),
				'button'    => array( 'Sign in', wp_login_url( ogc_url( 'admin', array( 'role' => 'web' ) ) ), wp_login_url() ),
				'after'     => array( 'Didn’t ask? Ignore this email.' ),
				'questions' => '',
				'year'      => 0,
			) ) );
			break;

		case 'codes_off':
			// Status lines, not a paragraph: what's off, for how long, and what still works.
			$m = ogc_mail_compose( array_merge( $base, array(
				'subject'   => 'Codes off · 24 hours',
				'heading'   => 'Codes off · 24 hours',
				'facts'     => array( array( 'Why', 'Too many wrong codes' ), array( 'Still works', 'Your own devices · The link in a sign-in email' ) ),
				'button'    => array( 'Sign in', ogc_url( 'signin' ) ),
				'after'     => array( 'Not you? Nothing to do: no one signed in.' ),
				'questions' => '',
				'year'      => 0,
			) ) );
			break;

		case 'invite':
			// Named, always: an unnamed "Added" from a role address reads like spam. A webmaster with
			// no name on file is "A webmaster". The year is the line above the heading. What they can do
			// now is said as it is today: one level of access, every page and list of the year (Q3 is
			// with the Advisors). The button names the page it opens ("Open Lodging"); the COA's is the
			// year. Replies go to whoever added them (reply_by).
			// The app (Oct 11 polish): the subject says what they're on, not who pressed the button; the
			// line under it says who added them and in what role ("Added by Esther B. (COA)"), a webmaster
			// is "the webmasters"; one fact says the first job. The screens aren't listed.
			$by   = $g( 'by_name' ) && ! $g( 'by_webmaster' ) ? ogc_first_l( $g( 'by_name' ) ) : ( $g( 'by_webmaster' ) ? 'the webmasters' : '' );
			$coa  = 'coa' === $g( 'role' );
			$com  = wp_strip_all_tags( (string) $g( 'committee_words' ) );
			$com  = preg_replace( '/\s*\(Head\)/', '', $com );
			$head = $coa ? 'You’re on the ' . ( $y ? $y . ' ' : '' ) . 'COA' : ( '' !== $com ? 'You’re on ' . $com . ( $y ? ' for the ' . $y . ' Conference' : '' ) : 'You’re on the ' . ( $y ? $y . ' ' : '' ) . 'Conference members list' );
			$open = $g( 'open_label', 'Open ' . $y );
			$m    = ogc_mail_compose( array_merge( $base, array(
				'subject'   => $head,
				'preheader' => $open . ' with the link · Works once, for 7 days',
				'heading'   => $head,
				'facts'     => array(
					array( 'Added by', $by ? ucfirst( $by ) . ( $g( 'by_role' ) && 'the webmasters' !== $by ? ' (' . wp_strip_all_tags( (string) $g( 'by_role' ) ) . ')' : '' ) : '' ),
					array( 'First', $g( 'first' ) ),
					array( 'Until', $g( 'until' ) ),
				),
				'button'    => array( $open, $g( 'url' ), $g( 'landing_url' ) ),
				'after'     => array( 'Link works once, for 7 days. A new one any time at ' . ogc_mail_short_url( ogc_url( 'signin' ) ) . '.', 'Not expecting this? Ignore it.' ),
				'questions' => $g( 'reply_by' ) && $by && 'the webmasters' !== $by ? 'Reply to reach ' . $by : $base['questions'],
			) ) );
			break;

		case 'webmaster':
			$by   = $g( 'by_name' ) && 'site administrator' !== strtolower( trim( $g( 'by_name' ) ) ) ? ogc_first_l( $g( 'by_name' ) ) : '';
			$head = ( $by ? $by . ' added you' : 'Added' ) . ' · Conference webmasters';
			$m    = ogc_mail_compose( array_merge( $base, array(
				'subject'   => $head,
				'heading'   => $head,
				'facts'     => array( array( 'Access', 'Every year’s pages and lists' ), array( 'Starts on', 'Webmasters' ) ),
				'button'    => array( 'Sign in', $g( 'url', ogc_url( 'signin' ) ) ),
				'after'     => array( 'Link works once, for 7 days.', 'Not expecting this? Ignore it.' ),
				'questions' => $g( 'reply_by' ) && $by ? 'Reply to reach ' . $by : '',
				'year'      => 0,
			) ) );
			break;

		case 'access_ending':
			// Per role: the COA hands over to the next COA; a helper just needs the date and their page.
			$coa = 'helper' !== $g( 'role', 'coa' );
			$m   = ogc_mail_compose( array_merge( $base, array(
				'subject' => 'Access ending · ' . $g( 'until' ),
				'heading' => 'Access ending · ' . $g( 'until' ),
				'facts'   => $coa ? array( array( 'Committee', 'Committee of Arrangements' ) ) : array( array( 'Committee', $g( 'committee_words' ) ) ),
				'lines'   => $coa ? array( 'Handing over to the next Committee of Arrangements? Do it before then. To keep access longer, ask a webmaster to renew it.' ) : array(),
				'after'   => $coa ? array() : array( 'Need it longer? Ask the Committee of Arrangements.' ),
				'button'  => array( $g( 'open_label', 'Open ' . $y ), $g( 'url', ogc_url( 'year', array( 'year' => $y ) ) ) ),
				'reason'  => 'You’re a member of the ' . $y . ' year.',
			) ) );
			break;

		case 'access_asked':
			$who = $g( 'name' ) ? ogc_first_l( $g( 'name' ) ) : (string) $g( 'email' );
			$m   = ogc_mail_compose( array_merge( $base, array(
				'subject' => 'Access asked · ' . $who,
				'heading' => 'Access asked · ' . $who,
				'facts'   => array( array( 'Email', $g( 'email' ) ), array( 'Was', $g( 'was', 'Not a member' ) ) ),
				'lines'   => array( 'Renew or invite them under Members, or leave it.' ),
				'button'  => array( 'Members', $g( 'url', ogc_url( 'year', array( 'year' => $y ) ) ) ),
				'reason'  => 'You’re on the ' . $y . ' Committee of Arrangements.',
			) ) );
			break;

		case 'registration_received':
			// Given the registration itself (rec: the preview's sample below), it's the registration
			// area's own email, drawn by the one builder that sends it (canonical, Oct 14).
			if ( ! empty( $d['rec'] ) && function_exists( 'ogc_reg_mail_receipt_parts' ) ) {
				$p = ogc_reg_mail_receipt_parts( $d['rec'], 'new' );
				$m = ogc_reg_mail_render( array_merge( $p['args'], array( 'to' => $d['to'], 'button' => array( 'Your sign-ups', $mine ) ) ), $p['blocks'] );
				break;
			}
			$check = 'check' === $g( 'method' );
			$facts = array(
				array( 'Registration', $g( 'id' ) ),
				array( 'Coming', $g( 'people' ) ? ( (int) $g( 'people' ) . ( 1 === (int) $g( 'people' ) ? ' person' : ' people' ) ) : '' ),
				array( 'Nights', $g( 'nights' ) ),
				array( 'Rooms', $g( 'rooms' ) ? (string) (int) $g( 'rooms' ) : '' ),
				array( 'Total', '' !== $g( 'total' ) ? ogc_mail_money( $g( 'total' ) ) : '' ),
				array( $check ? 'Paying' : 'Paid', $check ? 'Check by mail' : ( '' !== $g( 'paid' ) ? ogc_mail_money( $g( 'paid' ) ) . ' · Card' : '' ) ),
			);
			$lines = array();
			if ( $check ) {
				$lines[] = 'Mail a check for ' . ogc_mail_money( $g( 'total' ) ) . ' to ' . $g( 'payee', 'the Conference treasurer' ) . ( $g( 'address' ) ? ":\n" . $g( 'address' ) : '.' );
				$lines[] = 'Write ' . $g( 'id' ) . ' on the check.';
			}
			$m = ogc_mail_compose( array_merge( $base, array(
				'subject'   => 'Registration received · ' . $name( 'household' ) . ' household',
				'preheader' => $g( 'id' ) . ' · ' . $g( 'nights' ),
				'heading'   => 'Registration received · ' . $name( 'household' ) . ' household',
				'facts'     => $facts,
				'lines'     => $lines,
				'button'    => array( 'Your sign-ups', $mine ),
				'after'     => array( 'Change it any time before ' . ( $g( 'closes' ) ? ogc_mail_date( $g( 'closes' ) ) : 'registration closes' ) . ' on Your sign-ups.' ),
			) ) );
			break;

		case 'registration_changed':
			$facts = array();
			foreach ( (array) $g( 'changes', array() ) as $c ) {
				// Only what changed: a line whose before and after match isn't news.
				if ( is_array( $c ) && isset( $c[0], $c[1], $c[2] ) && trim( (string) $c[1] ) !== trim( (string) $c[2] ) ) {
					$facts[] = array( $c[0], $c[1] . ' → ' . $c[2] );
				}
			}
			$diff = (float) $g( 'difference', 0 );
			if ( $diff ) {
				$facts[] = array( $diff > 0 ? 'To pay' : 'Credit', ogc_mail_money( abs( $diff ) ) );
			}
			$m = ogc_mail_compose( array_merge( $base, array(
				'subject'   => 'Registration changed · ' . $name( 'household' ) . ' household',
				'heading'   => 'Registration changed · ' . $name( 'household' ) . ' household',
				'facts'     => array_merge( array( array( 'Registration', $g( 'id' ) ) ), $facts ),
				'button'    => array( 'Your sign-ups', $mine ),
			) ) );
			break;

		case 'registered_for_you':
			$m = ogc_mail_compose( array_merge( $base, array(
				'subject' => 'Registered for you',
				'heading' => 'Registered for you',
				'facts'   => array( array( 'By', $g( 'by_name' ) ? ogc_first_l( $g( 'by_name' ) ) : '' ), array( 'Registration', $g( 'id' ) ), array( 'Nights', $g( 'nights' ) ), array( 'Total', '' !== $g( 'total' ) ? ogc_mail_money( $g( 'total' ) ) : '' ) ),
				'button'  => array( 'Your sign-ups', $mine ),
			) ) );
			break;

		case 'parent_approval':
			// Goes to an address a teenager typed: no name, no nights, no hall. Who and what are on the
			// link's card, once the parent opens it.
			$pa = ( $g( 'again' ) ? 'Reminder · ' : '' ) . 'Approval needed';
			$m  = ogc_mail_compose( array_merge( $base, array(
				'subject' => $pa,
				'heading' => $pa,
				'lines'   => array( 'For a Youngfolk’s registration. Who and which nights show once the link is opened.' ),
				'button'  => array( 'Review', $g( 'approve_url', $g( 'url' ) ) ),
				'after'   => array( 'Link works for 7 days.', 'Not expecting this? Ignore it.' ),
				'reason'  => 'This address was given as a parent’s.',
			) ) );
			break;

		case 'payment_received':
			$m = ogc_mail_compose( array_merge( $base, array(
				'subject' => 'Payment received · ' . ogc_mail_money( $g( 'amount' ) ),
				'heading' => 'Payment received · ' . ogc_mail_money( $g( 'amount' ) ),
				'facts'   => array( array( 'Registration', $g( 'id' ) ), array( 'Amount', ogc_mail_money( $g( 'amount' ) ) ), array( 'By', 'check' === $g( 'method' ) ? 'Check' : 'Card' ), array( 'Still to pay', $g( 'due' ) ? ogc_mail_money( $g( 'due' ) ) : '' ) ),
				'button'  => array( 'Your sign-ups', $mine ),
			) ) );
			break;

		case 'credit_asked':
			$m = ogc_mail_compose( array_merge( $base, array(
				'subject' => 'Credit asked · ' . ogc_mail_money( $g( 'amount' ) ),
				'heading' => 'Credit asked · ' . ogc_mail_money( $g( 'amount' ) ),
				'facts'   => array( array( 'Registration', $g( 'id' ) ), array( 'Nights freed', $g( 'nights' ) ), array( 'Amount', ogc_mail_money( $g( 'amount' ) ) ), array( 'Given by', $g( 'by' ) ? ogc_mail_date( $g( 'by' ) ) : 'After Conference' ) ),
				'button'  => array( 'Your sign-ups', $mine ),
			) ) );
			break;

		case 'credit_given':
			$m = ogc_mail_compose( array_merge( $base, array(
				'subject' => 'Credit given · ' . ogc_mail_money( $g( 'amount' ) ),
				'heading' => 'Credit given · ' . ogc_mail_money( $g( 'amount' ) ),
				'facts'   => array( array( 'Registration', $g( 'id' ) ), array( 'Amount', ogc_mail_money( $g( 'amount' ) ) ), array( 'To', $g( 'how', 'The card used' ) ) ),
			) ) );
			break;

		case 'rooms_posted':
		case 'rooms_changed':
			$label = 'rooms_changed' === $kind ? 'Rooms changed' : 'Rooms posted';
			$m     = ogc_mail_compose( array_merge( $base, array(
				'subject' => $label,
				'heading' => $label,
				'facts'   => array( array( 'Check-in', $g( 'checkin' ) ) ),
				'button'  => array( 'View rooms', $mine ),
				'after'   => array( 'Rooms show only after signing in.' ),
				'reason'  => 'This household registered for lodging.',
			) ) );
			break;

		case 'signed_up':
			// shifts: several gathered in one email ([[title, when, place, name]…]: a family signing up
			// together). confirm_url: a first-time volunteer's place waits for the link (confirm_hours).
			// by: the committee's head signed them up.
			$many = array_values( array_filter( (array) $g( 'shifts', array() ), 'is_array' ) );
			$head = count( $many ) > 1 ? 'Signed up · ' . count( $many ) . ' shifts' : 'Signed up · ' . $title . ( $short ? ' · ' . $short : '' );
			$facts = array();
			if ( count( $many ) > 1 ) {
				foreach ( $many as $sh ) {
					$sh      = array_pad( $sh, 4, '' );
					$facts[] = array( wp_strip_all_tags( (string) $sh[0] ), trim( implode( ' · ', array_filter( array( (string) $sh[1], (string) $sh[2], $sh[3] ? ogc_first_l( $sh[3] ) : '' ) ) ) ) );
				}
			} else {
				$facts = array( array( 'When', $when ), array( 'Where', $place ), array( 'Committee', $g( 'committee' ) ) );
			}
			$confirm = $g( 'confirm_url' );
			$m = ogc_mail_compose( array_merge( $base, array(
				'subject'   => ( $confirm ? 'Confirm · ' : '' ) . $head,
				'preheader' => $confirm ? 'Confirm your place' : $when,
				'heading'   => ( $confirm ? 'Confirm · ' : '' ) . $head,
				'facts'     => $facts,
				'lines'     => array_values( array_filter( array( $g( 'by' ) ? ucfirst( ogc_mail_the( $g( 'by' ) ) ) . ' foreman added this address.' : '', $g( 'note' ) ? wp_strip_all_tags( (string) $g( 'note' ) ) : '' ) ) ),
				'button'    => $confirm ? array( 'Confirm', $confirm ) : array( 'Your sign-ups', $mine ),
				'after'     => array( $confirm && $g( 'confirm_hours' ) ? 'Not confirmed in ' . (int) $g( 'confirm_hours' ) . ' hours, the place opens again.' : '', $g( 'has_ics' ) ? 'Calendar file attached.' : '', array( 'Not you?', 'Remove', $g( 'notme_url' ) ) ),
			) ) );
			break;

		case 'reminder':
			$m = ogc_mail_compose( array_merge( $base, array(
				'subject'   => 'Tomorrow · ' . $title,
				'heading'   => 'Tomorrow · ' . $title,
				'facts'     => array( array( 'When', $when ), array( 'Where', $place ) ),
				'lines'     => $g( 'note' ) ? array( wp_strip_all_tags( (string) $g( 'note' ) ) ) : array(),
				'button'    => $g( 'map_url' ) ? array( 'Directions', $g( 'map_url' ) ) : array( 'Your sign-ups', $mine ),
				// Leaving is one tap away, so the place opens for someone else.
				'after'     => array( array( 'Can’t make it?', 'Leave shift', $g( 'leave_url', $mine ) ) ),
				'reason'    => 'This address is signed up for a shift tomorrow.',
			) ) );
			break;

		case 'shift_changed':
			$m = ogc_mail_compose( array_merge( $base, array(
				'subject' => 'Shift changed · ' . $title,
				'heading' => 'Shift changed · ' . $title,
				// Who of this address is on it, and why it came (the volunteer area's ogc_vol_addr; after the
				// ninth critic, Oct 16: a contact read "This address is signed up").
				'facts'   => array( array( 'Who', $g( 'who' ) ), array( 'Was', $at( $g( 'before' ) ) ), array( 'Now', $at( $g( 'after' ) ) ) ),
				'button'  => array( 'Your sign-ups', $mine ),
				'after'   => array( 'Can’t make the new time? Leave the shift on Your sign-ups.' ),
				'reason'  => $g( 'reason', 'This address is signed up for this shift.' ),
			) ) );
			break;

		case 'shift_removed':
			$m = ogc_mail_compose( array_merge( $base, array(
				'subject' => 'Shift removed · ' . $title,
				'heading' => 'Shift removed · ' . $title,
				'facts'   => array( array( 'Who', $g( 'who' ) ), array( 'Was', $when ) ),
				'lines'   => array( 'The committee no longer needs this shift. Nothing to do.' ),
				'button'  => array( 'Other shifts', $g( 'join_url', ogc_url( 'volunteer', array( 'year' => $y ) ) ) ),
				'reason'  => $g( 'reason', 'This address was signed up for this shift.' ),
			) ) );
			break;

		case 'you_left':
			$m = ogc_mail_compose( array_merge( $base, array(
				'subject' => 'Left · ' . $title . ( $short ? ' · ' . $short : '' ),
				'heading' => 'Left · ' . $title . ( $short ? ' · ' . $short : '' ),
				'facts'   => array( array( 'When', $when ) ),
				'button'  => array( 'Join again', $g( 'join_url', ogc_url( 'volunteer', array( 'year' => $y ) ) ) ),
			) ) );
			break;

		case 'volunteer_left':
			$m = ogc_mail_compose( array_merge( $base, array(
				'subject' => 'Place open · ' . $title . ( $short ? ' · ' . $short : '' ),
				'heading' => 'Place open · ' . $title . ( $short ? ' · ' . $short : '' ),
				'facts'   => array( array( 'Left', ogc_first_l( $g( 'name' ) ) ), array( 'When', $when ), array( 'Open', $g( 'open' ) ? (int) $g( 'open' ) . ' of ' . (int) $g( 'needed' ) : '' ) ),
				'button'  => array( 'Who’s signed up', $g( 'list_url', ogc_url( 'volunteer', array( 'year' => $y, 'view' => 'lead' ) ) ) ),
				'reason'  => 'Notices for ' . ogc_mail_the( $g( 'committee' ) ) . ' come to this address.',
			) ) );
			break;

		case 'spot_open':
			$m = ogc_mail_compose( array_merge( $base, array(
				'subject' => 'Place open · ' . $title . ( $short ? ' · ' . $short : '' ),
				'heading' => 'Place open · ' . $title . ( $short ? ' · ' . $short : '' ),
				// For whom, by name (after the ninth critic, Oct 16: one email an address, everyone waiting named).
				'facts'   => array( array( 'For', $g( 'who' ) ), array( 'When', $when ), array( 'Where', $place ) ),
				'lines'   => array( 'First to join gets it.' ),
				'button'  => array( 'Join', $g( 'join_url', ogc_url( 'volunteer', array( 'year' => $y ) ) ) ),
				'after'   => array( array( '', 'Leave waitlist', $g( 'leave_url' ) ) ),
				'reason'  => 'This address is on the waitlist for this shift.',
			) ) );
			break;

		case 'team_signed_up':
			$m = ogc_mail_compose( array_merge( $base, array(
				'subject' => 'Team signed up · ' . $title,
				'heading' => 'Team signed up · ' . $title,
				'facts'   => array( array( 'Team', $name( 'team' ) ), array( 'When', $when ), array( 'Where', $place ) ),
				'button'  => array( 'My teams', $g( 'url', ogc_url( 'tournaments', array( 'year' => $y, 'view' => 'mine' ) ) ) ),
			) ) );
			break;

		case 'message':
			$m = ogc_mail_compose( array_merge( $base, array(
				'subject' => wp_strip_all_tags( (string) $g( 'subject', 'Message' ) ) . ' · ' . $g( 'from', 'Annual Conference' ),
				'heading' => wp_strip_all_tags( (string) $g( 'subject', 'Message' ) ) . ' · ' . $g( 'from', 'Annual Conference' ),
				'facts'   => array( array( 'From', $g( 'from' ) ), array( 'About', $g( 'about' ) ) ),
				'plain'   => substr( (string) $g( 'body' ), 0, 4000 ),
				'button'  => $g( 'link' ) ? array( 'View', $g( 'link' ) ) : null,
				'reason'  => 'You’re signed up with ' . ogc_mail_the( $g( 'from' ) ) . '.',
			) ) );
			break;

		case 'weekly':
			$lines = array();
			foreach ( (array) $g( 'open_shifts', array() ) as $sh ) {
				if ( is_array( $sh ) && isset( $sh[0] ) ) {
					$lines[] = $sh[0] . ' · ' . ( isset( $sh[1] ) ? $sh[1] : '' ) . ( isset( $sh[2] ) ? ' · ' . (int) $sh[2] . ' open' : '' );
				}
			}
			$m = ogc_mail_compose( array_merge( $base, array(
				'subject' => 'This week · ' . $g( 'committee', 'Volunteers' ) . ' · ' . (int) $g( 'filled' ) . ' of ' . (int) $g( 'needed' ) . ' filled',
				'heading' => 'This week · ' . $g( 'committee', 'Volunteers' ) . ' · ' . (int) $g( 'filled' ) . ' of ' . (int) $g( 'needed' ) . ' filled',
				'facts'   => array( array( 'Filled', (int) $g( 'filled' ) . ' of ' . (int) $g( 'needed' ) ), array( 'New', $g( 'new' ) ? (string) (int) $g( 'new' ) : '' ), array( 'Left', $g( 'left' ) ? (string) (int) $g( 'left' ) : '' ) ),
				'lines'   => $lines ? array_merge( array( 'Still open:' ), $lines ) : array( 'Every shift is filled.' ),
				'button'  => array( 'Who’s signed up', $g( 'list_url', ogc_url( 'volunteer', array( 'year' => $y, 'view' => 'lead' ) ) ) ),
				'after'   => array( 'Names and phones are on the list, after signing in.' ),
				'reason'  => 'Notices for ' . ogc_mail_the( $g( 'committee' ) ) . ' come to this address.',
			) ) );
			break;

		case 'confirm_email':
			$code = preg_replace( '/^(\d{3})(\d{3})$/', '$1 $2', (string) $g( 'code' ) );
			$m    = ogc_mail_compose( array_merge( $base, array(
				'subject' => 'Confirm new email',
				'heading' => 'Confirm new email',
				'code'    => $code,
				'after'   => array( 'Works once, for 30 minutes.', 'Never give this code to anyone, even someone from the Conference.', 'Didn’t ask? Ignore this email.' ),
			) ) );
			break;

		case 'email_changed':
			// One reply line, and only when someone reads the replies.
			$m = ogc_mail_compose( array_merge( $base, array(
				'subject'   => 'Email changed',
				'heading'   => 'Email changed',
				'facts'     => array( array( 'Now', $g( 'new_masked' ) ), array( 'Changed by', $g( 'by', 'You' ) ) ),
				'lines'     => array( 'Sign-ups for this household now go to the new address.' ),
				'questions' => $q[0] ? 'Not you? Reply to this email' : '',
				'reason'    => 'This was the household’s email.',
			) ) );
			break;
	}
	if ( ! $m ) {
		// An area's own kinds (the volunteer area's vol_*), laid out by ogc_mail_compose like the rest.
		$m = apply_filters( 'ogc_mail_template_kind', null, $kind, $d, $base );
	}
	if ( ! $m ) {
		return null;
	}
	$m['reply_to'] = $q[1];
	return $m;
}

/** "the Transportation committee" (and "the Transportation committee" left alone). */
function ogc_mail_the( $who ) {
	$who = trim( (string) $who );
	if ( '' === $who ) {
		return 'this committee';
	}
	$who = preg_match( '/committee$/i', $who ) ? $who : $who . ' committee';
	return preg_match( '/^the\s/i', $who ) ? $who : 'the ' . $who;
}

/** The made-up Millers' 2027 registration, a check to come, as the registration area keeps one: the
 * preview of registration_received is drawn from it by the email's own builder (canonical, Oct 14). */
function ogc_mail_sample_registration() {
	$p = function ( $pid, $name, $kind, $age = '', $hall = '' ) {
		return array( 'pid' => $pid, 'name' => $name, 'kind' => $kind, 'age' => $age, 'yf' => 'yf' === $kind, 'yfHall' => $hall, 'sleeps' => 'hall', 'nights' => array(), 'linens' => false );
	};
	$ns = array( 'Friday', 'Saturday', 'Sunday', 'Monday', 'Tuesday' );
	return array(
		'id'     => 0,
		'year'   => 2027,
		'sample' => true,
		'email'  => 'daniel.miller@example.com',
		'data'   => array(
			'rid'    => 'R-2027-0014',
			'status' => 'check_to_come',
			'pay'    => 'check',
			'people' => array( $p( 's1', 'Daniel Miller', 'adult' ), $p( 's2', 'Esther Miller', 'adult' ), $p( 's3', 'Samuel Miller', 'yf', '18', 'men' ), $p( 's4', 'Lydia Miller', 'child', '11' ), $p( 's5', 'Micah Miller', 'child', '7' ), $p( 's6', 'Anna Miller', 'child', '2' ) ),
			'stay'   => array( 'type' => 'dorm', 'rooms' => 2, 'nights' => $ns, 'days' => array(), 'keys' => array( 'Daniel Miller', 'Esther Miller' ), 'linens' => 3, 'linenChoice' => 'order', 'mattresses' => 1, 'campers' => 0 ),
			'meals'  => array( 'custom' => array() ),
			'price'  => array(
				'lines'       => array(
					array( 'label' => '2 dorm rooms · 5 nights × $65', 'cents' => 65000 ),
					array( 'label' => '1 air mattress × $15', 'cents' => 1500 ),
					array( 'label' => 'Samuel · Young men’s hall · 5 nights × $32.50', 'cents' => 16250 ),
					array( 'label' => '3 linen packets × $27', 'cents' => 8100 ),
				),
				'total_cents' => 90850,
			),
			'money'  => array( 'total' => 90850, 'paid' => 0, 'check' => 90850, 'pending' => 0, 'refund' => 0, 'refunded' => 0, 'due' => 90850, 'late' => 0 ),
		),
	);
}

/** A made-up example of every kind (sample people only), for the Mail log's preview. */
function ogc_mail_samples() {
	$y     = 2027;
	$link  = ogc_url( 'signin', array( 't' => 'SAMPLE-not-a-real-link' ) );
	$shift = array( 'title' => 'Golf cart driver', 'day' => 'Saturday', 'start' => '7:00 AM', 'end' => '11:00 AM', 'place' => 'Barnes Student Center (B)', 'committee' => 'Transportation', 'note' => 'Carts and keys are at the Barnes Student Center.' );
	return array(
		'signin'                => array( 'code' => '482913', 'url' => $link ),
		'no_signups'            => array( 'to' => 'first.timer@example.com' ),
		'signin_wplogin'        => array( 'to' => 'editor@example.com' ),
		'codes_off'             => array( 'to' => 'ruth.kinsey@example.com' ),
		'invite'                => array( 'by_name' => 'Nathan Keller', 'by_role' => 'COA', 'first' => 'Answer requests by Jan 8', 'role' => 'helper', 'committee_words' => 'Lodging', 'open_label' => 'Open Lodging', 'landing_url' => ogc_url( 'lodging', array( 'year' => 2027 ) ), 'until' => 'Jun 1, 2028', 'url' => $link, 'reply_by' => true, 'to' => 'joel.marsh@example.com' ),
		'webmaster'             => array( 'by_name' => 'Caleb Jennings', 'url' => $link, 'reply_by' => true, 'to' => 'webmaster@example.com' ),
		'access_ending'         => array( 'role' => 'helper', 'committee_words' => 'Lodging', 'open_label' => 'Open Lodging', 'url' => ogc_url( 'lodging', array( 'year' => 2027 ) ), 'until' => 'Jun 1, 2028', 'to' => 'joel.marsh@example.com' ),
		'access_asked'          => array( 'name' => 'Lois Ward', 'email' => 'lois.ward@example.com', 'was' => 'Access ended Sep 1', 'to' => 'nathan.keller@example.com' ),
		'registration_received' => array( 'url' => $link, 'to' => 'daniel.miller@example.com', 'rec' => ogc_mail_sample_registration() ),
		'registration_changed'  => array( 'household' => 'Miller', 'id' => 'R-2027-0014', 'changes' => array( array( 'Nights', 'Fri–Tue', 'Fri–Mon' ), array( 'Rooms', '2', '2' ) ), 'difference' => -130, 'url' => $link ),
		'registered_for_you'    => array( 'by_name' => 'Phoebe Lane', 'id' => 'R-2027-0015', 'nights' => 'Sat–Mon · 3 nights', 'total' => 195, 'url' => $link ),
		'parent_approval'       => array( 'approve_url' => $link, 'to' => 'esther.miller@example.com' ),
		'payment_received'      => array( 'id' => 'R-2027-0014', 'amount' => 731, 'method' => 'check', 'url' => $link ),
		'credit_asked'          => array( 'id' => 'R-2027-0014', 'nights' => 'Tue', 'amount' => 130, 'by' => '2027-06-12', 'url' => $link ),
		'credit_given'          => array( 'id' => 'R-2027-0014', 'amount' => 130, 'how' => 'Check by mail' ),
		'rooms_posted'          => array( 'checkin' => 'Information Center · Fri from 2 PM Eastern', 'url' => $link ),
		'rooms_changed'         => array( 'checkin' => 'Information Center · Fri from 2 PM Eastern', 'url' => $link ),
		'signed_up'             => array_merge( $shift, array( 'notme_url' => $link, 'has_ics' => true, 'url' => $link ) ),
		'reminder'              => array_merge( $shift, array( 'map_url' => ogc_url( 'guide', array( 'view' => 'places', 'to' => 'B' ) ) ) ),
		'shift_changed'         => array_merge( $shift, array( 'before' => array( 'day' => 'Saturday', 'start' => '7:00 AM', 'end' => '11:00 AM', 'place' => 'Barnes (B)' ), 'after' => array( 'day' => 'Saturday', 'start' => '8:00 AM', 'end' => '12:00 PM', 'place' => 'Barnes (B)' ), 'url' => $link ) ),
		'shift_removed'         => $shift,
		'you_left'              => $shift,
		'volunteer_left'        => array_merge( $shift, array( 'name' => 'Ruth Kinsey', 'open' => 1, 'needed' => 4, 'to' => 'phoebe.lane@example.com' ) ),
		'spot_open'             => array_merge( $shift, array( 'leave_url' => $link ) ),
		'team_signed_up'        => array( 'title' => 'Volleyball', 'team' => 'The Millers', 'day' => 'Monday', 'start' => '2:00 PM', 'end' => '4:00 PM', 'place' => 'Fieldhouse (F)' ),
		'message'               => array( 'subject' => 'Carts moved', 'from' => 'Transportation committee', 'about' => 'Golf cart driver', 'body' => "The carts are behind the Fieldhouse this year, not at Barnes.\nKeys at the Information Center." ),
		'weekly'                => array( 'committee' => 'Transportation', 'filled' => 31, 'needed' => 40, 'new' => 6, 'left' => 1, 'open_shifts' => array( array( 'Golf cart driver', 'Sat, May 29 · 7–11 AM', 2 ), array( 'Golf cart driver', 'Mon, May 31 · 3–7 PM', 1 ) ), 'to' => 'phoebe.lane@example.com' ),
		'confirm_email'         => array( 'code' => '305118' ),
		'email_changed'         => array( 'new_masked' => 'd***r@example.org', 'by' => 'Lodging' ),
	) + (array) apply_filters( 'ogc_mail_samples', array() );
}
