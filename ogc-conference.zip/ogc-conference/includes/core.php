<?php
/**
 * Core helpers every part of the plugin uses: table names, JSON, who's signed in, who may change a
 * year, the change log, CSV in and out.
 */

defined( 'ABSPATH' ) || exit;

/** The full name of one of the plugin's tables: ogc_table( 'files' ) → wp_ogc_files. */
function ogc_table( $name ) {
	global $wpdb;
	return $wpdb->prefix . 'ogc_' . $name;
}

/** The path the Conference pages live under, without slashes ("annual-conference"). The Advisors may
 * choose another (docs/21, open questions); an area or a site plugin changes it with this filter. */
function ogc_base_path() {
	return trim( (string) apply_filters( 'ogc_base_path', 'annual-conference' ), '/' );
}

/** A page's address: ogc_url( 'register', array( 'year' => 2027 ) ). '' is the Conference page. */
function ogc_url( $path = '', $args = array() ) {
	$path = trim( (string) $path, '/' );
	$url  = home_url( '/' . ogc_base_path() . '/' . ( '' === $path ? '' : $path . '/' ) );
	return $args ? add_query_arg( $args, $url ) : $url;
}

/** Now, in UTC, as the tables keep it. */
function ogc_now() {
	return gmdate( 'Y-m-d H:i:s' );
}

function ogc_json( $value ) {
	return wp_json_encode( $value, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
}

function ogc_unjson( $text, $fallback = null ) {
	if ( null === $text || '' === $text ) {
		return $fallback;
	}
	$v = json_decode( $text, true );
	return ( null === $v && 'null' !== trim( $text ) ) ? $fallback : $v;
}

/** A four-digit Conference year. */
function ogc_valid_year( $year ) {
	return is_scalar( $year ) && preg_match( '/^\d{4}$/', (string) $year ) && (int) $year >= 1900 && (int) $year <= 2200;
}

/** The Conference every page opens on with no ?year (the Conference page's rule, ogc_pub_featured_year,
 * by the server's clock, dev as-of included), so the Conference, volunteer and other pages agree. 0 when
 * there's none. Filter: ogc_featured_year. */
function ogc_featured_year() {
	$row = function_exists( 'ogc_pub_featured_year' ) && function_exists( 'ogc_pub_today' ) ? ogc_pub_featured_year( ogc_years_public(), ogc_pub_today() ) : null;
	return (int) apply_filters( 'ogc_featured_year', $row ? (int) $row['year'] : 0 );
}

/** A file's name as the pages use it (schedule, settings, needs…). */
function ogc_valid_name( $name ) {
	return is_string( $name ) && preg_match( '/^[a-z][a-z0-9_-]{0,47}$/', $name );
}

/* ------------------------------------------------------------------ who */

function ogc_user_email( $user_id = null ) {
	$user_id = null === $user_id ? get_current_user_id() : (int) $user_id;
	if ( ! $user_id ) {
		return '';
	}
	$u = get_userdata( $user_id );
	return $u ? strtolower( trim( $u->user_email ) ) : '';
}

/** The signed-in person's email, lowercased; '' when no one is signed in. */
function ogc_current_email() {
	return ogc_user_email( get_current_user_id() );
}

/** The Conference webmasters' capability: one name, given on Settings › Conference webmasters (signin
 * area) or by the dev sign-in's &webmaster=1. (It was ogc_webmaster; module-members.php moves it once.) */
if ( ! defined( 'OGC_CAP_WEBMASTER' ) ) {
	define( 'OGC_CAP_WEBMASTER', 'ogc_manage_all' );
}

/** Webmasters see and change every year. A site admin is one; so is anyone given OGC_CAP_WEBMASTER. */
function ogc_is_webmaster( $user_id = null ) {
	$user_id = null === $user_id ? get_current_user_id() : (int) $user_id;
	if ( ! $user_id ) {
		return false;
	}
	$ok = user_can( $user_id, 'manage_options' ) || user_can( $user_id, OGC_CAP_WEBMASTER );
	return (bool) apply_filters( 'ogc_is_webmaster', $ok, $user_id );
}

/** May this person see and change the year (the COA and their helpers)? One level of access per year
 * (Oct 6). The signin area answers through the ogc_is_member filter; webmasters are members of every year. */
function ogc_is_member( $year, $user_id = null ) {
	$user_id = null === $user_id ? get_current_user_id() : (int) $user_id;
	if ( ! $user_id || ! ogc_valid_year( $year ) ) {
		return false;
	}
	if ( ogc_is_webmaster( $user_id ) ) {
		return true;
	}
	return (bool) apply_filters( 'ogc_is_member', false, (int) $year, $user_id, ogc_user_email( $user_id ) );
}

/** The years this person is a member of, newest first. */
function ogc_member_years( $user_id = null ) {
	$user_id = null === $user_id ? get_current_user_id() : (int) $user_id;
	if ( ! $user_id ) {
		return array();
	}
	$out = array();
	foreach ( ogc_years_list() as $y ) {
		if ( ogc_is_member( $y, $user_id ) ) {
			$out[] = (int) $y;
		}
	}
	return $out;
}

/* ------------------------------------------------------------------ the change log */

/** One line in the change log: who did what to which part of which year. $detail never holds anyone's
 * personal data (counts, versions, a record's id). */
function ogc_log( $action, $year, $target, $detail = array() ) {
	global $wpdb;
	$wpdb->insert(
		ogc_table( 'log' ),
		array(
			'at'     => ogc_now(),
			'user'   => get_current_user_id(),
			'year'   => ogc_valid_year( $year ) ? (int) $year : 0,
			'action' => substr( (string) $action, 0, 32 ),
			'target' => substr( (string) $target, 0, 128 ),
			'detail' => ogc_json( $detail ),
		),
		array( '%s', '%d', '%d', '%s', '%s', '%s' )
	);
}

/* ------------------------------------------------------------------ CSV */

/** CSV text → rows (objects keyed by the header, exactly as written). Quoted fields may hold commas,
 * quotes and line breaks. Rows whose first cell starts with "#" are notes and are left out. */
function ogc_csv_read( $text, &$cols = null, &$problems = null ) {
	$text = preg_replace( '/^\xEF\xBB\xBF/', '', (string) $text );
	$fh   = fopen( 'php://temp', 'r+' );
	fwrite( $fh, $text );
	rewind( $fh );
	$cols     = null;
	$rows     = array();
	$problems = array();
	$line     = 1;
	while ( false !== ( $r = fgetcsv( $fh, 0, ',', '"', '' ) ) ) {
		if ( null === $cols ) {
			$cols = array_map( 'trim', $r );
			continue;
		}
		$line++;
		// More cells than the header: an unquoted comma, and the text after it would be lost.
		if ( count( $r ) > count( $cols ) && array_filter( array_slice( $r, count( $cols ) ), 'strlen' ) ) {
			$problems[] = 'row ' . $line . ': ' . count( $r ) . ' fields, header has ' . count( $cols );
		}
		if ( array( null ) === $r || ! array_filter( $r, 'strlen' ) ) {
			continue;
		}
		if ( 0 === strpos( ltrim( (string) $r[0] ), '#' ) ) {
			continue;
		}
		$o = array();
		foreach ( $cols as $i => $c ) {
			if ( '' !== $c ) {
				$o[ $c ] = isset( $r[ $i ] ) ? (string) $r[ $i ] : '';
			}
		}
		$rows[] = $o;
	}
	fclose( $fh );
	$cols = array_values( array_filter( (array) $cols, 'strlen' ) );
	return $rows;
}

/** Rows → CSV text: the given columns first, then any other key in the order first seen. */
function ogc_csv_write( $rows, $cols = array() ) {
	$cols = array_values( (array) $cols );
	foreach ( (array) $rows as $r ) {
		foreach ( (array) $r as $k => $v ) {
			if ( ! in_array( (string) $k, $cols, true ) ) {
				$cols[] = (string) $k;
			}
		}
	}
	$cell = function ( $v ) {
		if ( is_bool( $v ) ) {
			$v = $v ? '1' : '';
		}
		$v = null === $v ? '' : (string) $v;
		return preg_match( '/[",\r\n]|^\s|\s$/', $v ) ? '"' . str_replace( '"', '""', $v ) . '"' : $v;
	};
	$lines = array( implode( ',', array_map( $cell, $cols ) ) );
	foreach ( (array) $rows as $r ) {
		$line = array();
		foreach ( $cols as $c ) {
			$line[] = $cell( isset( $r[ $c ] ) ? $r[ $c ] : '' );
		}
		$lines[] = implode( ',', $line );
	}
	return implode( "\n", $lines ) . "\n";
}
