<?php
/**
 * Local development only. Nothing in this file exists unless OGC_DEV is true (tools/wp-local.sh
 * defines it; ogbbc.org never does):
 *
 *   /annual-conference/dev-signin/?email=ruth@example.com&return=/annual-conference/year/?year=2027
 *       signs in as that email (making the WordPress user if needed). Also:
 *       &member=2027[,2026]   make the email a member of those years (kept in the ogc_dev_members option)
 *       &member=none          no longer a member of any year
 *       &webmaster=1|0        give or take the webmasters' capability (OGC_CAP_WEBMASTER, ogc_manage_all)
 *       &name=Ruth%20K        the display name for a new user
 *   /annual-conference/dev-signout/?return=/annual-conference/   signs out
 *   POST /wp-json/ogc/v1/dev/import {"force": 2027 | true}   (webmasters) reload the seed
 *   No email is sent: wp_mail is stopped and each message noted in the change log ("mail_dev").
 */

defined( 'ABSPATH' ) || exit;

/** A local address: 127.0.0.1, localhost, [::1], *.localhost or *.test. */
function ogc_is_local_host() {
	$host = strtolower( (string) wp_parse_url( home_url(), PHP_URL_HOST ) );
	// The shared prototype runs in WordPress Playground: a WordPress in one visitor's own browser, nothing
	// shared and no real data. There, and only with OGC_PROTOTYPE set in its blueprint, it counts as local.
	if ( defined( 'OGC_PROTOTYPE' ) && OGC_PROTOTYPE && 'playground.wordpress.net' === $host ) {
		return true;
	}
	return in_array( $host, array( '127.0.0.1', 'localhost', '[::1]', '::1' ), true ) || (bool) preg_match( '/\.(localhost|test)$/', $host );
}

/**
 * May a change be saved under a previewed date (?as_of)? Only in the shared prototype, where each visitor
 * has their own copy in their own browser and the tour's scenes are dated (Lodging in April 2027). On
 * every real site a preview only reads.
 */
function ogc_proto_saves() {
	return defined( 'OGC_PROTOTYPE' ) && OGC_PROTOTYPE && ogc_is_local_host();
}

// Only on a local address, even with OGC_DEV on: a staging copy (where OGC_DEV might be left on to
// keep mail from going out; it should use OGC_MAIL_CAPTURE) never lets anyone sign in as anyone.
if ( ! OGC_DEV || ! ogc_is_local_host() ) {
	return;
}

add_action( 'ogc_rewrites', function ( $b ) {
	add_rewrite_rule( "^$b/dev-(signin|signout)/?$", 'index.php?ogc_dev=$matches[1]', 'top' );
} );
add_filter( 'query_vars', function ( $v ) {
	$v[] = 'ogc_dev';
	return $v;
} );
add_action( 'template_redirect', 'ogc_dev_dispatch', 0 );

// Members of a year, for trying things locally (the signin area keeps the real list).
add_filter( 'ogc_is_member', function ( $is, $year, $user_id, $email ) {
	$m = (array) get_option( 'ogc_dev_members', array() );
	return $is || ( $email && isset( $m[ $year ] ) && in_array( $email, (array) $m[ $year ], true ) );
}, 20, 4 );

function ogc_dev_return() {
	$r = isset( $_GET['return'] ) ? esc_url_raw( wp_unslash( $_GET['return'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification -- dev only.
	$r = $r && '/' === $r[0] && '/' !== substr( $r, 1, 1 ) ? home_url( $r ) : ogc_url();
	return wp_validate_redirect( $r, ogc_url() );
}

function ogc_dev_dispatch() {
	$what = get_query_var( 'ogc_dev' );
	if ( ! $what ) {
		return;
	}
	nocache_headers();
	// phpcs:disable WordPress.Security.NonceVerification -- dev only.
	if ( 'signout' === $what ) {
		wp_logout();
		// The real Sign out clears the browser's storage for the site (module-public.php). This dev one
		// keeps it: the tour remembers its scene there, and in WordPress Playground the whole WordPress
		// lives in that storage.
		if ( ! headers_sent() ) {
			header_remove( 'Clear-Site-Data' );
		}
		wp_safe_redirect( ogc_dev_return() );
		exit;
	}
	$email = isset( $_GET['email'] ) ? strtolower( sanitize_email( wp_unslash( $_GET['email'] ) ) ) : '';
	if ( ! is_email( $email ) ) {
		status_header( 400 );
		echo 'email= is needed';
		exit;
	}
	$user = get_user_by( 'email', $email );
	if ( ! $user ) {
		$login = sanitize_user( str_replace( '@', '-at-', $email ), true );
		$base  = $login;
		for ( $i = 2; username_exists( $login ); $i++ ) {
			$login = $base . '-' . $i;
		}
		$name = isset( $_GET['name'] ) ? sanitize_text_field( wp_unslash( $_GET['name'] ) ) : '';
		$id   = wp_insert_user( array(
			'user_login'   => $login,
			'user_email'   => $email,
			'user_pass'    => wp_generate_password( 32, true, true ),
			'display_name' => $name ? $name : ucwords( str_replace( array( '.', '_', '-' ), ' ', strstr( $email, '@', true ) ) ),
			'role'         => 'subscriber',
		) );
		if ( is_wp_error( $id ) ) {
			status_header( 500 );
			echo esc_html( $id->get_error_message() );
			exit;
		}
		$user = get_userdata( $id );
	}
	if ( isset( $_GET['webmaster'] ) ) {
		if ( '1' === $_GET['webmaster'] ) {
			$user->add_cap( OGC_CAP_WEBMASTER );
		} else {
			$user->remove_cap( OGC_CAP_WEBMASTER );
		}
	}
	if ( isset( $_GET['member'] ) ) {
		$m    = (array) get_option( 'ogc_dev_members', array() );
		$want = 'none' === $_GET['member'] ? array() : array_filter( array_map( 'intval', explode( ',', sanitize_text_field( wp_unslash( $_GET['member'] ) ) ) ), 'ogc_valid_year' );
		foreach ( $m as $y => $list ) {
			$m[ $y ] = array_values( array_diff( (array) $list, array( $email ) ) );
		}
		foreach ( $want as $y ) {
			$m[ $y ]   = isset( $m[ $y ] ) ? (array) $m[ $y ] : array();
			$m[ $y ][] = $email;
		}
		update_option( 'ogc_dev_members', $m, false );
	}
	// phpcs:enable
	wp_clear_auth_cookie();
	wp_set_current_user( $user->ID );
	wp_set_auth_cookie( $user->ID, true );
	// The one "last signed in" every list reads (signin area), set by every way of signing in.
	update_user_meta( $user->ID, 'ogc_last_signin', ogc_now() );
	wp_safe_redirect( ogc_dev_return() );
	exit;
}

add_action( 'rest_api_init', function () {
	register_rest_route( OGC_NS, '/dev/import', array(
		'methods'             => 'POST',
		'callback'            => function ( WP_REST_Request $req ) {
			$f = $req->get_param( 'force' );
			$f = true === $f || 'true' === $f ? true : ( ogc_valid_year( $f ) ? (int) $f : false );
			return rest_ensure_response( (object) ogc_import_seed( $f ) );
		},
		'permission_callback' => 'ogc_can_webmaster',
	) );
} );

// Never send email from a local site: note it in the change log instead (the signin area's Mail
// log, when it has one, takes over before this).
add_filter( 'pre_wp_mail', function ( $short, $atts ) {
	if ( null !== $short ) {
		return $short;
	}
	ogc_log( 'mail_dev', 0, substr( (string) ( is_array( $atts['to'] ) ? implode( ',', $atts['to'] ) : $atts['to'] ), 0, 128 ), array( 'subject' => (string) $atts['subject'] ) );
	return true;
}, 99, 2 );

/* ================================================================== the shared prototype */

/** The shared prototype (WordPress Playground, OGC_PROTOTYPE in its blueprint; locally PROTOTYPE=1
 * tools/wp-local.sh start). Presentation and sample data only: nothing here decides how anything works. */
function ogc_proto_on() {
	return defined( 'OGC_PROTOTYPE' ) && OGC_PROTOTYPE;
}

// The tour's scenes land on full screens, so the made-up year needs a little more than the seed gives:
// 2027 registers on this site's form with its dates scheduled (as the COA would), and one household
// that registered also signed up for two shifts (dated before today, so every page counts them).
// Once per site, after the seed has loaded.
add_action( 'wp_loaded', 'ogc_proto_setup', 30 );
function ogc_proto_setup() {
	if ( ! ogc_proto_on() || 1 <= (int) get_option( 'ogc_proto_setup', 0 ) ) {
		return;
	}
	$y = 2027;
	if ( ! ogc_year_get( $y ) || ! ogc_file_get( $y, 'settings' ) || ! function_exists( 'ogc_vol_shifts' ) || ! ogc_vol_shifts( $y, true ) ) {
		return; // The seed isn't in yet: the next request tries again.
	}
	update_option( 'ogc_proto_setup', 1, false );
	$admin = get_users( array( 'role' => 'administrator', 'number' => 1, 'fields' => 'ID' ) );
	if ( ! $admin ) {
		return;
	}
	$prev = get_current_user_id();
	wp_set_current_user( (int) $admin[0] );
	$call = function ( $method, $route, $params ) {
		$r = new WP_REST_Request( $method, '/' . OGC_NS . $route );
		foreach ( $params as $k => $v ) {
			$r->set_param( $k, $v );
		}
		return rest_do_request( $r );
	};
	// What the e2e walk-through does as the COA: this site's form, open Feb 25 to May 21.
	$call( 'PATCH', "/years/$y/files/settings", array( 'op' => 'key', 'key' => 'registration_mode', 'value' => 'site' ) );
	$call( 'POST', "/coa/$y/publish", array( 'part' => 'registration', 'act' => 'schedule', 'opens' => '2027-02-25', 'closes' => '2027-05-21' ) );
	// The sample 2027 schedule public, as it would be by the tour's spring dates: the volunteer page's
	// Your week then draws the services (worship) behind the shifts.
	$call( 'POST', "/coa/$y/publish", array( 'part' => 'schedule', 'act' => 'publish' ) );
	wp_set_current_user( $prev );
	ogc_proto_seat_household( $y );
}

/** The Adams household (a 2027 sample registration) on two shifts, signed up when sign-ups opened. */
function ogc_proto_seat_household( $y ) {
	global $wpdb;
	$t      = ogc_table( 'vol_seats' );
	$email  = 'naomi.adams@example.com';
	$want   = array( array( 'Naomi Adams', 'Food' ), array( 'Aaron Adams', 'Ushers' ) );
	$taken  = array();
	$busy   = array();
	foreach ( $want as $w ) {
		foreach ( ogc_vol_shifts( $y, true ) as $id => $sh ) {
			if ( $sh['committee'] !== $w[1] || ! empty( $sh['rule'] ) || ! empty( $sh['screening'] ) || ! empty( $sh['min_age'] ) || in_array( $sh['date'], $taken, true ) ) {
				continue;
			}
			$n = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $t WHERE year = %d AND shift = %s", $y, $id ) );
			if ( ! $sh['unlimited'] && $n >= (int) $sh['needed'] ) {
				continue;
			}
			$clash = false;
			foreach ( $busy as $b ) {
				$clash = $clash || ( $b[0] < $sh['end_ts'] && $sh['start_ts'] < $b[1] );
			}
			if ( $clash ) {
				continue;
			}
			$data = array( 'id' => $id, 'name' => $w[0], 'phone' => '555-0200', 'email' => $email, 'confirmed' => true, 'by' => 'self', 'at' => '2026-10-05T15:00:00+00:00', 'sample' => true );
			$rid  = ogc_record_insert( $y, 'signups', $data, $email, true, 'seed' );
			$wpdb->insert( $t, array( 'year' => $y, 'shift' => $id, 'seat_no' => $n + 1, 'pkey' => ogc_vol_pkey( $email, $w[0] ), 'record_id' => $rid, 'created_at' => ogc_now() ), array( '%d', '%s', '%d', '%s', '%d', '%s' ) );
			$taken[] = $sh['date'];
			$busy[]  = array( $sh['start_ts'], $sh['end_ts'] );
			break;
		}
	}
}

// In WordPress Playground the whole site lives in the browser's storage for playground.wordpress.net,
// so no sign-out in the prototype asks the browser to clear it (the real Sign out does, module-public.php).
add_action( 'wp_logout', function () {
	if ( ogc_proto_on() && ! headers_sent() ) {
		header_remove( 'Clear-Site-Data' );
	}
}, 99 );
