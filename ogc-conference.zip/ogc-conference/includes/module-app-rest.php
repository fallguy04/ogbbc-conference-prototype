<?php
/**
 * The app's routes, /wp-json/ogc/v1/app/… (DEV.md › App). Each one asks the screen registry who may
 * see its screen (ogc_app_can_see), with the viewer the request names (?as= for the COA and webmasters
 * seeing as a committee: read only). A committee's key goes in ?c= (keys hold spaces and "/").
 * Nothing here returns an address or phone except to the COA, and never to a webmaster seeing nothing.
 */

defined( 'ABSPATH' ) || exit;

add_action( 'rest_api_init', 'ogc_app_routes' );

function ogc_app_routes() {
	$Y   = '(?P<year>\d{4})';
	$see = function ( $screen, $write = false ) {
		return function ( WP_REST_Request $req ) use ( $screen, $write ) {
			if ( ! ogc_app_tables_ready() || null === ogc_year_get( (int) $req['year'] ) ) {
				return new WP_Error( 'ogc_not_found', 'Not found.', array( 'status' => 404 ) );
			}
			$v = ogc_app_req_viewer( $req );
			if ( ! ogc_app_can_see( $v, $screen ) ) {
				return ogc_rest_denied();
			}
			if ( $write && $v['as'] ) {
				return new WP_Error( 'ogc_read_only', 'Read only while seeing as', array( 'status' => 403 ) );
			}
			return true;
		};
	};
	$routes = array(
		"/app/$Y/boot"             => array( array( 'GET', 'ogc_app_rest_boot', $see( 'home' ) ) ),
		"/app/$Y/home"             => array( array( 'GET', 'ogc_app_rest_home', $see( 'home' ) ) ),
		"/app/$Y/committees"       => array(
			array( 'GET', 'ogc_app_rest_committees', $see( 'committees' ) ),
			array( 'POST', 'ogc_app_rest_committee_add', $see( 'committees', true ) ),
		),
		"/app/$Y/committee"        => array(
			array( 'GET', 'ogc_app_rest_committee', $see( 'committees' ) ),
			array( 'PATCH', 'ogc_app_rest_committee_patch', $see( 'committees', true ) ),
			array( 'DELETE', 'ogc_app_rest_committee_delete', $see( 'committees', true ) ),
		),
		"/app/$Y/committee/past"   => array( array( 'GET', 'ogc_app_rest_committee_past', $see( 'committees' ) ) ),
		"/app/$Y/committee/notes"  => array( array( 'POST', 'ogc_app_rest_note_add', $see( 'committees', true ) ) ),
		"/app/$Y/committee/report" => array( array( 'PUT', 'ogc_app_rest_report_put', $see( 'committees', true ) ) ),
		"/app/$Y/committee/files"  => array( array( 'POST', 'ogc_app_rest_file_add', $see( 'committees', true ) ) ),
		"/app/$Y/tasks"            => array(
			array( 'GET', 'ogc_app_rest_tasks', $see( 'tasks' ) ),
			array( 'POST', 'ogc_app_rest_task_add', $see( 'tasks', true ) ),
		),
		"/app/$Y/message"          => array( array( 'POST', 'ogc_app_rest_message', $see( 'committees', true ) ) ),
		"/app/$Y/hand"             => array( array( 'POST', 'ogc_app_rest_hand', $see( 'committees', true ) ) ),
		"/app/$Y/phones"           => array(
			array( 'GET', 'ogc_app_rest_phones', $see( 'members' ) ),
			array( 'PUT', 'ogc_app_rest_phone_put', $see( 'members', true ) ),
		),
	);
	foreach ( $routes as $path => $list ) {
		$defs = array();
		foreach ( $list as $r ) {
			$defs[] = array( 'methods' => $r[0], 'callback' => $r[1], 'permission_callback' => $r[2] );
		}
		register_rest_route( OGC_NS, $path, $defs );
	}
	// Rows by id: the row's own year decides (the viewer must see its screen in that year).
	$row = function ( $table, $screen ) {
		return function ( WP_REST_Request $req ) use ( $table, $screen ) {
			global $wpdb;
			if ( ! ogc_app_tables_ready() ) {
				return new WP_Error( 'ogc_not_found', 'Not found.', array( 'status' => 404 ) );
			}
			$r = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . ogc_table( $table ) . ' WHERE id = %d AND removed_at IS NULL', (int) $req['id'] ), ARRAY_A );
			$v = $r ? ogc_app_viewer( (int) $r['year'], (string) $req->get_param( 'as' ) ) : null;
			// Someone else's row reads as missing (404), so its existence isn't given away.
			if ( ! $r || ! ogc_app_can_see( $v, $screen ) || ! ogc_app_on_committee( $v, $r['ckey'] ) ) {
				return new WP_Error( 'ogc_not_found', 'Not found.', array( 'status' => 404 ) );
			}
			if ( 'GET' !== $req->get_method() && $v['as'] ) {
				return new WP_Error( 'ogc_read_only', 'Read only while seeing as', array( 'status' => 403 ) );
			}
			$req->set_param( '_row', $r );
			return true;
		};
	};
	register_rest_route( OGC_NS, '/app/tasks/(?P<id>\d+)', array(
		array( 'methods' => 'PATCH', 'callback' => 'ogc_app_rest_task_patch', 'permission_callback' => $row( 'tasks', 'tasks' ) ),
		array( 'methods' => 'DELETE', 'callback' => 'ogc_app_rest_task_delete', 'permission_callback' => $row( 'tasks', 'tasks' ) ),
	) );
	register_rest_route( OGC_NS, '/app/notes/(?P<id>\d+)', array(
		array( 'methods' => 'PATCH', 'callback' => 'ogc_app_rest_note_patch', 'permission_callback' => 'ogc_app_can_note' ),
		array( 'methods' => 'DELETE', 'callback' => 'ogc_app_rest_note_delete', 'permission_callback' => $row( 'cnotes', 'committees' ) ),
	) );
	register_rest_route( OGC_NS, '/app/files/(?P<id>\d+)', array(
		// A plain link (the browser sends _wpnonce in the address, as WordPress's REST cookie check asks).
		array( 'methods' => 'GET', 'callback' => 'ogc_app_rest_file_get', 'permission_callback' => $row( 'cfiles', 'committees' ) ),
		array( 'methods' => 'DELETE', 'callback' => 'ogc_app_rest_file_delete', 'permission_callback' => $row( 'cfiles', 'committees' ) ),
	) );
}

/* ================================================================== helpers */

function ogc_app_c( WP_REST_Request $req ) {
	return ogc_committee_key( (string) $req->get_param( 'c' ) );
}

/** The year and committee a write names, checked: the committee exists and the viewer is on it (or the
 * COA). Returns the committee, or a WP_Error. */
function ogc_app_write_committee( WP_REST_Request $req, $ckey = null ) {
	$y = (int) $req['year'];
	$v = ogc_app_req_viewer( $req );
	$k = null === $ckey ? ogc_app_c( $req ) : $ckey;
	$c = ogc_app_committee( $y, $k );
	if ( ! $c || ! ogc_app_on_committee( $v, $k ) ) {
		return new WP_Error( 'ogc_not_found', 'Not found.', array( 'status' => 404 ) );
	}
	return $c;
}

/** "Fri, May 28 – Tue, Jun 1, 2027" style range, short. */
function ogc_app_range_words( $y ) {
	if ( empty( $y['start'] ) ) {
		return 'Dates to come';
	}
	$s = strtotime( $y['start'] . ' 12:00:00 UTC' );
	$e = ! empty( $y['end'] ) ? strtotime( $y['end'] . ' 12:00:00 UTC' ) : $s;
	return gmdate( 'M j', $s ) . ' – ' . ( gmdate( 'm', $s ) === gmdate( 'm', $e ) ? gmdate( 'j', $e ) : gmdate( 'M j', $e ) ) . ', ' . gmdate( 'Y', $e );
}

/** Where the year stands: before | week | after | nodates, and how far off. */
function ogc_app_phase( $year ) {
	$y     = ogc_year_get( $year );
	$today = ogc_app_today( $year );
	if ( ! $y || empty( $y['start'] ) ) {
		return array( 'phase' => 'nodates', 'days' => null );
	}
	$end = ! empty( $y['end'] ) ? $y['end'] : $y['start'];
	if ( $today < $y['start'] ) {
		return array( 'phase' => 'before', 'days' => (int) round( ( strtotime( $y['start'] . ' 12:00 UTC' ) - strtotime( $today . ' 12:00 UTC' ) ) / DAY_IN_SECONDS ) );
	}
	if ( $today <= $end ) {
		return array( 'phase' => 'week', 'days' => 0, 'day' => 1 + (int) round( ( strtotime( $today . ' 12:00 UTC' ) - strtotime( $y['start'] . ' 12:00 UTC' ) ) / DAY_IN_SECONDS ) );
	}
	return array( 'phase' => 'after', 'days' => -(int) round( ( strtotime( $today . ' 12:00 UTC' ) - strtotime( $end . ' 12:00 UTC' ) ) / DAY_IN_SECONDS ) );
}

/** "33 weeks to go", "Day 2", "4 weeks ago". */
function ogc_app_phase_words( $p ) {
	if ( 'before' === $p['phase'] ) {
		$d = $p['days'];
		return $d > 13 ? floor( $d / 7 ) . ' weeks to go' : $d . ' day' . ( 1 === $d ? '' : 's' ) . ' to go';
	}
	if ( 'week' === $p['phase'] ) {
		return 'Day ' . $p['day'];
	}
	if ( 'after' === $p['phase'] ) {
		$d = -$p['days'];
		return $d > 13 ? floor( $d / 7 ) . ' weeks ago' : ( $d < 1 ? 'Ended today' : $d . ' day' . ( 1 === $d ? '' : 's' ) . ' ago' );
	}
	return '';
}

/** The venue as the sidebar says it: "IWU", "Cedarville". */
function ogc_app_venue_short( $venue ) {
	$map = array( 'Indiana Wesleyan University' => 'IWU', 'Cedarville University' => 'Cedarville', 'George Fox University' => 'George Fox' );
	return isset( $map[ $venue ] ) ? $map[ $venue ] : (string) $venue;
}

/** Log a See as once in 30 minutes for the same person, year and committee. */
function ogc_app_log_see_as( $v ) {
	if ( ! $v['as'] ) {
		return;
	}
	$uid  = get_current_user_id();
	$seen = (array) get_user_meta( $uid, 'ogc_app_seen_as', true );
	$k    = $v['year'] . '|' . $v['as'];
	if ( isset( $seen[ $k ] ) && $seen[ $k ] > time() - 30 * MINUTE_IN_SECONDS ) {
		return;
	}
	$seen[ $k ] = time();
	update_user_meta( $uid, 'ogc_app_seen_as', array_slice( $seen, -20, null, true ) );
	ogc_log( 'app_see_as', $v['year'], 'committee:' . $v['as'], array( 'ckey' => $v['as'] ) );
}

/* ================================================================== boot */

function ogc_app_rest_boot( WP_REST_Request $req ) {
	$y = (int) $req['year'];
	// Opening a year never sets it up (docs/27 area-shell 8.3): only Years › Start does. A year that
	// isn't started answers what's true, and the years this person may open instead.
	if ( ! ogc_year_started( $y ) ) {
		$open = array();
		foreach ( ogc_years_list() as $yy ) {
			if ( (int) $yy !== $y && ogc_year_started( $yy ) && ( ogc_is_webmaster() || ogc_is_member( $yy ) ) ) {
				$open[] = (int) $yy;
			}
		}
		rsort( $open );
		$feat = ogc_is_webmaster() && function_exists( 'ogc_featured_year' ) ? (int) ogc_featured_year() : 0;
		$name = ogc_person_name( get_current_user_id() );
		return new WP_Error( 'ogc_not_started', $y . ' · Not started', array(
			'status'    => 404,
			'year'      => $y,
			'webmaster' => ogc_is_webmaster(),
			// Where the webmasters' Years is (a started year), and the years to open instead (newest first).
			'years_in'  => $feat && ogc_year_started( $feat ) ? $feat : ( $open ? $open[0] : 0 ),
			'open'      => array_slice( $open, 0, 2 ),
			// The sidebar still says which year, and keeps the person and their way out (Round 1, after
			// the critic): the year menu, the name, Sign out.
			'years'     => ogc_app_years_menu(),
			'viewer'    => array( 'short' => $name ? ogc_first_l( $name ) : ogc_mask_email( ogc_current_email() ), 'email' => ogc_current_email() ),
			'logout'    => ogc_app_logout_path(),
		) );
	}
	ogc_app_keep_year( $y );
	$v = ogc_app_req_viewer( $req );
	ogc_app_log_see_as( $v );
	$row   = ogc_year_get( $y );
	$me    = ogc_current_email();
	$uid   = get_current_user_id();
	$name  = ogc_person_name( $uid );
	$years = ogc_app_years_menu();
	$coms = array();
	foreach ( ogc_app_committees( $y ) as $c ) {
		$coms[] = array( 'key' => $c['ckey'], 'name' => $c['name'], 'screens' => $c['screens'] );
	}
	// Names the viewer may see: the COA and committees see everyone on the year (the directory); a
	// webmaster sees the COA only (whom they manage).
	$people = array();
	foreach ( ogc_members_list( $y ) as $m ) {
		if ( ! ogc_member_active( $m ) || ( $v['webmaster'] && ! $v['coa'] && 'coa' !== $m['role'] ) ) {
			continue;
		}
		$people[] = array(
			'id'         => (int) $m['id'],
			'name'       => ogc_app_person_name( $m ),
			'committees' => 'coa' === $m['role'] ? array( 'coa' ) : ogc_member_committee_keys( $m ),
			'head'       => (bool) $m['head'],
		);
	}
	$mine = array();
	foreach ( $v['committees'] as $k ) {
		$c = ogc_app_committee( $y, $k );
		if ( $c ) {
			$mine[] = array( 'key' => $k, 'name' => $c['name'] );
		}
	}
	$phase = ogc_app_phase( $y );
	$real  = isset( $v['real'] ) ? $v['real'] : $v;
	return rest_ensure_response( array(
		'year'       => $y,
		'years'      => $years,
		'conference' => array(
			'label' => $y . ( ! empty( $row['venue'] ) ? ' · ' . ogc_app_venue_short( $row['venue'] ) : '' ),
			'venue' => isset( $row['venue'] ) ? (string) $row['venue'] : '',
			'dates' => ogc_app_range_words( $row ),
			'phase' => $phase['phase'],
			'when'  => ogc_app_phase_words( $phase ),
			'today' => ogc_app_today( $y ),
			'start' => isset( $row['start'] ) ? (string) $row['start'] : '',
			'end'   => isset( $row['end'] ) ? (string) $row['end'] : '',
		),
		'viewer'     => array(
			'name'       => $name ? $name : ogc_mask_email( $me ),
			'short'      => $name ? ogc_first_l( $name ) : ogc_mask_email( $me ),
			'email'      => $me,
			'coa'        => $v['coa'],
			'webmaster'  => $v['webmaster'],
			'committees' => $mine,
			'head'       => $v['head'],
			'member_id'  => $v['member_id'],
			'as'         => $v['as'],
			'as_name'    => $v['as'] ? ( 'coa' === $v['as'] ? 'COA' : ogc_app_committee( $y, $v['as'] )['name'] ) : '',
			'as_role'    => isset( $v['as_role'] ) ? $v['as_role'] : '',
			'can_see_as' => $real['coa'] || $real['webmaster'],
			'real_coa'   => $real['coa'],
		),
		'screens'    => ogc_app_screens_for( $v ),
		'committees' => $coms,
		'people'     => $people,
		'questions'  => ogc_app_report_questions( $y ),
		'logout'     => ogc_app_logout_path(),
	) );
}

/** The plugin's own sign-out (module-auth: a nonce, then the sign-in page with "Signed out"), as a path:
 * never wp-login's "Do you really want to log out?" screen, and no "&amp;" in it. */
function ogc_app_logout_path() {
	return wp_make_link_relative( ogc_url( 'signin', array( 'signout' => 1, '_wpnonce' => wp_create_nonce( 'ogc_signout' ) ) ) );
}

/** The year menu, for the signed-in person: started years they may open (webmasters: every started year),
 * and a member's own year not started yet, marked (it opens to its card); never a year only listed in
 * years.csv (area-shell D7). Each says what you are in it ("2028 · COA", "2027 · IWU · Lodging"), so
 * someone on two years can tell them apart. */
function ogc_app_years_menu() {
	$years = array();
	foreach ( ogc_years_list() as $yy ) {
		$started = ogc_year_started( $yy );
		$mm      = function_exists( 'ogc_member_me' ) ? ogc_member_me( $yy ) : null;
		if ( ( $started && ( ogc_is_webmaster() || ogc_is_member( $yy ) ) ) || ( ! $started && $mm ) ) {
			$r  = ogc_year_get( $yy );
			$as = '';
			if ( $mm ) {
				$as = 'coa' === $mm['role'] ? 'COA' : implode( ', ', array_filter( array_map( function ( $k ) use ( $yy ) {
					$c = ogc_app_committee( $yy, $k );
					return $c ? $c['name'] : '';
				}, ogc_member_committee_keys( $mm ) ) ) );
			}
			$years[] = array( 'year' => $yy, 'started' => $started, 'label' => $yy . ( ! empty( $r['venue'] ) ? ' · ' . ogc_app_venue_short( $r['venue'] ) : '' ) . ( '' !== $as ? ' · ' . $as : '' ) . ( $started ? '' : ' · Not started' ) );
		}
		if ( count( $years ) >= 6 ) {
			break;
		}
	}
	return $years;
}

/* ================================================================== home */

function ogc_app_rest_home( WP_REST_Request $req ) {
	$y     = (int) $req['year'];
	$v     = ogc_app_req_viewer( $req );
	$phase = ogc_app_phase( $y );
	$row   = ogc_year_get( $y );
	$today = ogc_app_today( $y );
	$cname = array();
	foreach ( ogc_app_committees( $y ) as $c ) {
		$cname[ $c['ckey'] ] = $c['name'];
	}
	$wm    = $v['webmaster'] && ! $v['coa'];
	$years = array();
	if ( $wm ) {
		// Years, access, email, publishing.
		$w     = ogc_app_webmaster_home( $today );
		$needs = $w['needs'];
		$years = $w['years'];
	} else {
		$needs = ogc_app_needs( $y, $v );
	}
	// The COA's Home (Round 2, area-home-tasks 1.4–1.7): First steps while any is undone; the people lines
	// live there and then in the Committees block, never also here; the round's progress isn't news (D6);
	// the Final counts line stands for its task.
	$steps = null;
	$final = null;
	if ( $v['coa'] && ! $wm && function_exists( 'ogc_app_first_steps' ) ) {
		$steps = ogc_app_first_steps( $y );
		$final = ogc_app_final_counts( $y );
		$needs = array_values( array_filter( $needs, function ( $n ) use ( $final ) {
			$k = isset( $n['key'] ) ? (string) $n['key'] : '';
			return 0 !== strpos( $k, 'nobody' ) && 0 !== strpos( $k, 'nohead' ) && 'round-coa' !== $k && ! ( $final && isset( $n['kind'] ) && 'final_counts' === $n['kind'] );
		} ) );
		if ( $final ) {
			$row_f = array( 'key' => 'final-counts', 'kind' => 'final_counts', 'words' => $final['words'], 'why' => '', 'parts' => $final['parts'], 'go' => $final['go'], 'button' => 'Open counts', 'tone' => $final['late'] ? 'late' : '', 'due' => $final['due'], 'ckey' => 'coa' );
			// Ranked as any dated need (1.6): within 14 days it leads, after only what's due sooner within them.
			$at = count( $needs );
			foreach ( $needs as $i => $n ) {
				$soon = ! empty( $n['due'] ) && $n['due'] >= $today && $n['due'] <= $final['due'] && empty( $n['manual'] ) && ( ! isset( $n['tone'] ) || 'late' !== $n['tone'] );
				if ( ! $soon ) {
					$at = $i;
					break;
				}
			}
			array_splice( $needs, $at, 0, array( $row_f ) );
		}
	}
	// While the dates aren't checked, Announce waits one line down, saying why (area-home-tasks 1.3).
	$check_dates = false;
	if ( $steps && empty( $steps[0]['done'] ) ) {
		foreach ( $needs as $i => $n ) {
			if ( isset( $n['kind'] ) && 'announce' === $n['kind'] ) {
				$needs[ $i ]['why']  = ( ! empty( $n['due'] ) ? 'Due ' . ogc_app_md( $n['due'], $y ) . ( $n['due'] < $today ? ' · Late' : '' ) . ' · ' : '' ) . 'After the dates are checked';
				$needs[ $i ]['wait'] = 'Not yet';
				$check_dates         = 0 === $i;
			}
		}
	}
	// A need's line names its committee only for someone on more than one.
	$many = ! $v['coa'] && count( $v['committees'] ) > 1;
	foreach ( $needs as &$n ) {
		if ( $many && ! empty( $n['ckey'] ) && isset( $cname[ $n['ckey'] ] ) ) {
			$n['why'] = $cname[ $n['ckey'] ] . ( $n['why'] ? ' · ' . $n['why'] : '' );
		}
		unset( $n['rank'], $n['key'] );
	}
	unset( $n );
	// The headline is the most pressing true thing; during the week and after, where the year is.
	$lede = '';
	if ( 'week' === $phase['phase'] && ! $wm ) {
		$head = 'Conference week · Day ' . $phase['day'];
	} elseif ( 'after' === $phase['phase'] && $v['coa'] ) {
		$in = 0;
		$of = 0;
		foreach ( ogc_app_committees( $y ) as $c ) {
			if ( 'coa' !== $c['ckey'] ) {
				$of++;
				$in += ogc_app_report_sent( $y, $c['ckey'] ) ? 1 : 0;
			}
		}
		$head = 'Reports · ' . $in . ' of ' . $of . ' in';
		// The need that says the same (module-handdown.php: See reports) is the headline's act, not a
		// second line under it.
		foreach ( $needs as $i => $n ) {
			if ( isset( $n['words'] ) && $n['words'] === $head ) {
				$lede          = $n['why'];
				$n['lead']     = true;
				array_splice( $needs, $i, 1 );
				array_unshift( $needs, $n );
				break;
			}
		}
	} elseif ( $check_dates ) {
		// A new COA's first press must not turn the public page on dates nobody has looked at: while the
		// dates aren't checked, the headline is Check dates and Announce waits one line down (1.3).
		$head = 'Check dates';
		$lede = ogc_app_range_words( $row ) . ( ! empty( $row['venue'] ) ? ' · ' . ogc_app_venue_short( $row['venue'] ) : '' ) . ' · Before you announce';
	} elseif ( $needs && empty( $needs[0]['manual'] ) ) {
		$head              = $needs[0]['words'];
		$lede              = $needs[0]['why'];
		$needs[0]['lead']  = true;
	} elseif ( $needs && empty( $needs[0]['late'] ) ) {
		// A task with no screen behind it (a meeting) is never the headline's act: it's what's next.
		$head             = 'Next: ' . $needs[0]['words'];
		$lede             = $needs[0]['why'];
		$needs[0]['lead'] = true;
	} else {
		$head = 'All caught up';
	}
	// What the headline already says isn't said again under it.
	$kinds = array();
	foreach ( $needs as $n ) {
		if ( ! empty( $n['kind'] ) ) {
			$kinds[ $n['kind'] ] = true;
		}
		if ( ! empty( $n['go']['id'] ) && 'tasks' === $n['go']['s'] ) {
			$kinds[ 'id:' . $n['go']['id'] ] = true;
		}
	}
	// The COA's requests line covers each committee's "Answer requests".
	if ( isset( $kinds['requests_sent'] ) ) {
		$kinds['requests_answer'] = true;
	}
	// Coming up: the next undone tasks by date (the COA: every committee's), from the Friday.
	// The same kind of task on the same day for several committees (First meeting) is one line, merged by
	// its kind (a fixed field), never its title (docs/27 area-home-tasks D7, 1.8). Each line carries where
	// it opens (go): one task, Tasks with it open; a merged line, Tasks listing every committee's
	// (f=kind:first_meeting), so the line opens what it names (Round 1, after the critic).
	$scope  = $v['coa'] || $v['webmaster'] ? null : $v['committees'];
	$coming = array();
	$at     = array();
	$solo   = ! $v['coa'] && ! $v['webmaster'] && count( $v['committees'] ) < 2;
	foreach ( $wm ? array() : ogc_app_tasks( $y, $scope ) as $t ) {
		if ( $t['done'] || ( $t['due'] && $t['due'] < $today ) || ( $t['kind'] && isset( $kinds[ $t['kind'] ] ) ) || isset( $kinds[ 'id:' . $t['id'] ] ) ) {
			continue;
		}
		$k = $t['kind'] ? $t['kind'] . '|' . $t['due'] . '|' . $t['due_words'] : 'id:' . $t['id'];
		if ( isset( $at[ $k ] ) ) {
			$i = $at[ $k ];
			$coming[ $i ]['n']++;
			$coming[ $i ]['committee'] = $coming[ $i ]['n'] . ' committees';
			$coming[ $i ]['ckey']      = '';
			$coming[ $i ]['go']        = array( 's' => 'tasks', 'v' => $v['coa'] || $v['webmaster'] ? 'all' : 'committee', 'f' => 'kind:' . $t['kind'] );
			continue;
		}
		if ( count( $coming ) >= 8 ) {
			continue;
		}
		$at[ $k ] = count( $coming );
		$coming[] = array( 'id' => $t['id'], 'title' => $t['title'], 'due' => $t['due'], 'when' => $t['due_words'], 'committee' => $solo || ( $v['coa'] && 'coa' === $t['committee'] ) ? '' : ( 'coa' === $t['committee'] ? 'COA' : ( isset( $cname[ $t['committee'] ] ) ? $cname[ $t['committee'] ] : '' ) ), 'ckey' => $t['committee'], 'n' => 1, 'kind' => $t['kind'], 'go' => array( 's' => 'tasks', 'id' => $t['id'] ) );
	}
	// Last year's notes: a committee's own; the COA's own from last year's COA (D13).
	$last = array();
	$prev = ogc_app_prev_year( $y );
	if ( $prev && ! $wm ) {
		foreach ( $v['coa'] ? array( 'coa' ) : $v['committees'] as $k ) {
			foreach ( ogc_app_notes( $prev, $k ) as $n ) {
				if ( ! $n['done'] ) {
					$last[] = array( 'id' => $n['id'], 'body' => $n['body'], 'committee' => $solo || $v['coa'] ? '' : $cname[ $k ], 'ckey' => $k, 'year' => $prev, 'on' => $n['on'] );
				}
			}
		}
	}
	// The COA's first look at a year: who's on it, in one quiet line under the headline.
	$first = '';
	if ( $v['coa'] && ! $v['as'] && ! $wm && function_exists( 'ogc_app_seen' ) && '' === ogc_app_seen( $y, 'home' ) ) {
		$cs = 0;
		$hs = 0;
		foreach ( ogc_app_committees( $y ) as $c ) {
			if ( 'coa' === $c['ckey'] ) {
				continue;
			}
			$cs++;
			$hs += array_filter( ogc_app_people( $y, $c['ckey'] ), function ( $m ) {
				return ! empty( $m['head'] );
			} ) ? 1 : 0;
		}
		$first = ogc_app_plural( $cs, 'committee' ) . ' · ' . ( $hs ? ogc_app_plural( $hs, 'head' ) : 'No heads yet' );
	}
	$button = $needs && $head === $needs[0]['words'] && '' !== $needs[0]['button'] ? array( 'label' => $needs[0]['button'], 'go' => $needs[0]['go'], 'op' => isset( $needs[0]['op'] ) ? $needs[0]['op'] : '' ) : null;
	if ( ! empty( $check_dates ) ) {
		$button = array( 'label' => 'Check dates', 'go' => array( 's' => 'dates' ), 'op' => '' );
	}
	// First steps replaces the first-visit line (1.4).
	if ( $steps ) {
		$first = '';
	}
	return rest_ensure_response( array(
		'steps'      => $steps,
		'parts'      => $needs && ! empty( $needs[0]['lead'] ) && ! empty( $needs[0]['parts'] ) ? $needs[0]['parts'] : null,
		'committees' => $v['coa'] && ! $wm && function_exists( 'ogc_app_home_committees' ) ? ogc_app_home_committees( $y, $steps ) : array(),
		'today'      => $today,
		'start'      => isset( $row['start'] ) ? (string) $row['start'] : '',
		'end'        => isset( $row['end'] ) ? (string) $row['end'] : '',
		'venue'      => ! empty( $row['venue'] ) ? ogc_app_venue_short( $row['venue'] ) : '',
		'first'    => $first,
		'headline' => $head,
		'lede'     => $lede,
		'button'   => $button,
		'fact'     => trim( ogc_app_range_words( $row ) . ( ! empty( $row['venue'] ) ? ' · ' . $row['venue'] : '' ) . ( ogc_app_phase_words( $phase ) ? ' · ' . ogc_app_phase_words( $phase ) : '' ) ),
		'phase'    => $phase['phase'],
		'needs'    => array_slice( $needs, 0, 12 ),
		'coming'   => $coming,
		'last'     => array_slice( $last, 0, 6 ),
		'prev'     => $prev,
		'years'    => $years,
		'activity' => ogc_app_activity( $v ),
	) );
}

/* ================================================================== committees */

function ogc_app_people_out( $people, $v, $year ) {
	$out = array();
	foreach ( $people as $m ) {
		$o = array( 'id' => (int) $m['id'], 'name' => ogc_app_person_name( $m ), 'head' => (bool) $m['head'] );
		if ( $v['coa'] && ! $v['as'] ) {
			// The COA sees each record whole: the address, whether they've signed in, and a phone the
			// COA keeps for them (docs/23: the COA sees heads' phones).
			$o['email'] = $m['email'];
			$o['state'] = $m['signed_in_at'] ? 'Active' : 'Invited';
			$ph         = ogc_app_phones( $year );
			if ( ! empty( $ph[ (int) $m['id'] ] ) ) {
				$o['phone'] = $ph[ (int) $m['id'] ];
			}
		}
		if ( (int) $m['id'] === (int) $v['member_id'] ) {
			$o['you'] = true;
		}
		$out[] = $o;
	}
	return $out;
}

function ogc_app_rest_committees( WP_REST_Request $req ) {
	$y   = (int) $req['year'];
	$v   = ogc_app_req_viewer( $req );
	$out = array();
	foreach ( ogc_app_committees( $y ) as $c ) {
		$people = ogc_app_people( $y, $c['ckey'] );
		$o      = array( 'key' => $c['ckey'], 'name' => $c['name'], 'duties' => $c['duties'], 'people_count' => count( $people ), 'screens' => $c['screens'] );
		if ( $v['coa'] ) {
			// Where it stands: the committee's one fact and its marks (area-committees 2.1, 2.2), the same
			// functions its page, Home and the weekly note read (README rule 10).
			$st     = ogc_app_committee_status( $y, $c, null, $people );
			$heads  = array_values( array_filter( $people, function ( $m ) {
				return ! empty( $m['head'] );
			} ) );
			$fact   = ogc_app_committee_fact( $y, $c['ckey'] );
			$marks  = ogc_app_committee_marks( $y, $c['ckey'] );
			$o['line']  = $fact['words'];
			$o['fact']  = $fact;
			$o['marks'] = $marks;
			// The marks beside the fact, never saying what the fact says.
			$o['look']  = array_values( array_filter( array_map( function ( $m ) use ( $fact ) {
				return 'soon' === $m['key'] || $m['words'] === $fact['words'] ? '' : $m['words'];
			}, $marks ) ) );
			$keys       = wp_list_pluck( $marks, 'key' );
			$o['views'] = array_values( array_filter( array(
				array_diff( $keys, array( 'soon' ) ) ? 'look' : '',
				array_intersect( $keys, array( 'nobody', 'nohead' ) ) ? 'nohead' : '',
				in_array( 'late', $keys, true ) ? 'late' : '',
				in_array( 'unchecked', $keys, true ) ? 'from' : '',
			) ) );
			$o['done']   = $st['done'];
			$o['total']  = $st['total'];
			$o['head']   = $heads ? ogc_app_person_name( $heads[0] ) : '';
			$o['from']   = in_array( 'unchecked', $keys, true ) ? ( $c['from_year'] ? $c['from_year'] : 'seeded' ) : 0;
			$o['late']   = $st['late'];
		} elseif ( ! $v['webmaster'] ) {
			// The directory: who's on each committee and what it does; no status or numbers of others.
			$o['people'] = ogc_app_people_out( $people, $v, $y );
			$o['mine']   = in_array( $c['ckey'], $v['committees'], true );
			unset( $o['people_count'] );
		}
		$out[] = $o;
	}
	if ( ! $v['coa'] && ! $v['webmaster'] ) {
		// Their own committee first.
		usort( $out, function ( $a, $b ) {
			return (int) ! empty( $b['mine'] ) - (int) ! empty( $a['mine'] );
		} );
	}
	return rest_ensure_response( array( 'view' => $v['coa'] ? 'board' : ( $v['webmaster'] ? 'structure' : 'directory' ), 'committees' => $out ) );
}

function ogc_app_rest_committee( WP_REST_Request $req ) {
	$y = (int) $req['year'];
	$v = ogc_app_req_viewer( $req );
	$k = ogc_app_c( $req );
	$c = ogc_app_committee( $y, $k );
	if ( ! $c ) {
		return new WP_Error( 'ogc_not_found', 'Not found.', array( 'status' => 404 ) );
	}
	$people = ogc_app_people( $y, $k );
	$on     = ogc_app_on_committee( $v, $k );
	$prev   = ogc_app_prev_year( $y );
	$out    = array(
		'key'    => $c['ckey'],
		'name'   => $c['name'],
		'duties' => $c['duties'],
		'access' => $on ? 'full' : ( $v['webmaster'] ? 'structure' : 'directory' ),
		'can'    => array(
			'edit'    => $v['coa'] && ! $v['as'],
			'write'   => $on && ! $v['as'],
			'message' => ! $v['as'] && ( $v['coa'] || (bool) $v['committees'] || $v['webmaster'] ),
			'see_as'  => ! $v['as'] && ( $v['coa'] || $v['webmaster'] ) && ! in_array( $k, $v['committees'], true ) && ! ( 'coa' === $k && $v['coa'] ),
			'hand'    => $v['coa'] && ! $v['as'] && 'coa' !== $k,
		),
	);
	// The four versions (area-committees 3.2, 7–10): the COA's, the committee's own, another committee's
	// (short), the webmasters' (structure). A past year is committee/past.
	$out['version'] = $v['coa'] ? 'coa' : ( $on ? 'own' : ( $v['webmaster'] ? 'structure' : 'other' ) );
	if ( $v['webmaster'] && ! $on ) {
		$out['people_count'] = count( $people );
		$out['screens']      = $c['screens'];
		$out['runs']         = array_map( function ( $id ) use ( $y ) {
			return ogc_app_screen_title( $y, $id );
		}, $c['screens'] );
		return rest_ensure_response( $out );
	}
	$out['people'] = ogc_app_people_out( $people, $v, $y );
	if ( ! $on ) {
		// Another committee's short page: what passes between the two (states only), and the phone it
		// gives out (committees.csv's own role phone, the one the volunteer page shows). Nothing else.
		$with = array();
		foreach ( (array) $v['committees'] as $mine ) {
			foreach ( function_exists( 'ogc_app_works_with' ) ? ogc_app_works_with( $y, $k, $mine ) : array() as $w ) {
				$with[] = $w;
			}
		}
		$phone           = function_exists( 'ogc_round_phone' ) ? ogc_round_phone( $y, $k ) : '';
		$out['works_with'] = $with;
		$out['contacts']   = '' !== $phone ? array( array( 'role' => 'Our phone', 'phone' => $phone ) ) : array();
		return rest_ensure_response( $out );
	}
	$who   = function ( $uid ) use ( $y ) {
		return $uid ? ogc_app_user_name( $uid, $y ) : '';
	};
	$tasks = array_map( function ( $t ) use ( $who ) {
		$t['done_by'] = $who( $t['done_by_id'] );
		unset( $t['done_by_id'] );
		return $t;
	}, ogc_app_tasks( $y, array( $k ) ) );
	$files = array_map( function ( $f ) use ( $who ) {
		$f['by'] = $who( $f['by_id'] );
		unset( $f['by_id'] );
		return $f;
	}, ogc_app_files( $y, $k ) );
	$notes = function ( $list ) use ( $who ) {
		return array_map( function ( $n ) use ( $who ) {
			$n['by']      = $who( $n['author'] );
			$n['done_by'] = $who( $n['done_by'] );
			unset( $n['author'] );
			return $n;
		}, $list );
	};
	$rep = ogc_app_report( $y, $k );
	if ( $rep ) {
		$rep['updated_by'] = $who( $rep['updated_by'] );
	}
	$last = $prev ? ogc_app_report( $prev, $k ) : null;
	if ( $last ) {
		unset( $last['updated_by'] );
	}
	// Previous and next committee in the board's order, for the COA's ‹ › (area-committees 2.5).
	$step = null;
	if ( $v['coa'] ) {
		$keys = array_map( function ( $x ) {
			return array( 'key' => $x['ckey'], 'name' => $x['name'] );
		}, ogc_app_committees( $y ) );
		foreach ( $keys as $i => $x ) {
			if ( $x['key'] === $k ) {
				$step = array( 'prev' => $i > 0 ? $keys[ $i - 1 ] : null, 'next' => $i < count( $keys ) - 1 ? $keys[ $i + 1 ] : null, 'i' => $i + 1, 'n' => count( $keys ) );
			}
		}
	}
	$dc = function_exists( 'ogc_app_duties_checked' ) ? ogc_app_duties_checked( $y ) : array();
	// The next committee in the board's order the COA hasn't checked (the banner's "Checked · Next").
	$next_unchecked = null;
	if ( $v['coa'] ) {
		$after = false;
		foreach ( ogc_app_committees( $y ) as $x ) {
			if ( $after && empty( $dc[ $x['ckey'] ] ) ) {
				$next_unchecked = array( 'key' => $x['ckey'], 'name' => $x['name'] );
				break;
			}
			$after = $after || $x['ckey'] === $k;
		}
		if ( ! $next_unchecked ) {
			foreach ( ogc_app_committees( $y ) as $x ) {
				if ( $x['ckey'] !== $k && empty( $dc[ $x['ckey'] ] ) ) {
					$next_unchecked = array( 'key' => $x['ckey'], 'name' => $x['name'] );
					break;
				}
			}
		}
	}
	$past = array();
	foreach ( ogc_years_list() as $py ) {
		if ( $py < $y && ogc_app_committee( $py, $k ) ) {
			$past[] = $py;
		}
	}
	$st = ogc_app_committee_status( $y, $c, null, $people );
	return rest_ensure_response( array_merge( $out, array(
		'link'        => $c['link'],
		'from'        => $c['from_year'] && ! $c['checked_at'] ? $c['from_year'] : 0,
		'status'      => array( 'line' => $st['line'], 'look' => $st['look'] ),
		'screens'     => $c['screens'],
		// The year as a line (Round 2, README 12): the fact, the Work rows, the open tasks and For next
		// year, each with its day; Works with (states only); what it runs; the checks.
		'fact'        => function_exists( 'ogc_app_committee_fact' ) ? ogc_app_committee_fact( $y, $k ) : null,
		'work'        => function_exists( 'ogc_app_work_rows' ) ? ogc_app_work_rows( $y, $k, $v ) : array(),
		'line_tasks'  => function_exists( 'ogc_app_line_tasks' ) ? ogc_app_line_tasks( $y, $k ) : array(),
		'next'        => function_exists( 'ogc_app_next_rows' ) ? ogc_app_next_rows( $y, $k ) : array(),
		'works_with'  => function_exists( 'ogc_app_works_with' ) ? ogc_app_works_with( $y, $k ) : array(),
		'runs'        => array_map( function ( $id ) use ( $y ) {
			return array( 'id' => $id, 'title' => ogc_app_screen_title( $y, $id ) );
		}, $c['screens'] ),
		'step'        => $step,
		'next_unchecked' => $next_unchecked,
		'source'      => $c['from_year'] ? 'carried' : 'seeded',
		'from_year'   => (int) $c['from_year'],
		'duties_checked' => isset( $dc[ $k ] ) ? ogc_app_md( $dc[ $k ], $y ) : '',
		'head_checked'   => $c['checked_at'] ? ogc_app_md( substr( (string) $c['checked_at'], 0, 10 ), $y ) : '',
		'today'       => ogc_app_today( $y ),
		'conference'  => array( 'start' => (string) ( ogc_year_get( $y )['start'] ?? '' ), 'end' => (string) ( ogc_year_get( $y )['end'] ?? '' ) ),
		'tasks'       => $tasks,
		'files'       => $files,
		'notes'       => $notes( ogc_app_notes( $y, $k ) ),
		'prev'        => $prev,
		'last_notes'  => $prev ? $notes( ogc_app_notes( $prev, $k ) ) : array(),
		'report'      => $rep,
		'last_report' => $last,
		'past'        => array_slice( $past, 0, 5 ),
		'phase'       => ogc_app_phase( $y )['phase'],
	) ) );
}

/** A committee's past year, read-only and never people: its notes, report, tasks and files. The COA
 * sees every committee's; a committee its own; webmasters all. */
function ogc_app_rest_committee_past( WP_REST_Request $req ) {
	$y  = (int) $req['year'];
	$py = (int) $req->get_param( 'from' );
	$v  = ogc_app_req_viewer( $req );
	$k  = ogc_app_c( $req );
	if ( $py >= $y || ! ogc_valid_year( $py ) || ! ( $v['webmaster'] || ogc_app_on_committee( $v, $k ) ) ) {
		return new WP_Error( 'ogc_not_found', 'Not found.', array( 'status' => 404 ) );
	}
	$c = ogc_app_committee( $py, $k );
	if ( ! $c ) {
		return new WP_Error( 'ogc_not_found', 'Not found.', array( 'status' => 404 ) );
	}
	$tasks = array_map( function ( $t ) {
		return array( 'title' => $t['title'], 'when' => $t['due_words'], 'done' => $t['done'], 'done_on' => $t['done_on'] );
	}, ogc_app_tasks( $py, array( $k ) ) );
	$notes = array_map( function ( $n ) {
		return array( 'body' => $n['body'], 'on' => $n['on'] );
	}, ogc_app_notes( $py, $k ) );
	$rep = ogc_app_report( $py, $k );
	if ( $rep ) {
		unset( $rep['updated_by'] );
	}
	$files = array_map( function ( $f ) {
		unset( $f['by_id'] );
		return $f;
	}, ogc_app_files( $py, $k ) );
	return rest_ensure_response( array(
		'year'   => $py,
		'name'   => $c['name'],
		'duties' => $c['duties'],
		'people' => count( ogc_app_people( $py, $k ) ),
		'tasks'  => $tasks,
		'notes'  => $notes,
		'report' => $rep,
		'files'  => $files,
	) );
}

function ogc_app_rest_committee_add( WP_REST_Request $req ) {
	$y = (int) $req['year'];
	$v = ogc_app_req_viewer( $req );
	if ( ! $v['coa'] ) {
		return ogc_rest_denied();
	}
	$c = ogc_app_committee_add( $y, (string) $req->get_param( 'name' ), (string) $req->get_param( 'duties' ) );
	if ( is_wp_error( $c ) ) {
		return $c;
	}
	if ( function_exists( 'ogc_app_set_duties_checked' ) ) {
		ogc_app_set_duties_checked( $y, $c['ckey'], true );
	}
	ogc_log( 'app_committee_add', $y, 'committee:' . $c['ckey'], array( 'ckey' => $c['ckey'] ) );
	return rest_ensure_response( array( 'key' => $c['ckey'], 'name' => $c['name'] ) );
}

function ogc_app_rest_committee_patch( WP_REST_Request $req ) {
	global $wpdb;
	$y = (int) $req['year'];
	$v = ogc_app_req_viewer( $req );
	$c = ogc_app_write_committee( $req );
	if ( is_wp_error( $c ) ) {
		return $c;
	}
	$set = array();
	// The COA writes a committee's name and responsibilities; its own people may mark "From 2026" as
	// checked and paste their working folder's link.
	if ( null !== $req->get_param( 'name' ) || null !== $req->get_param( 'duties' ) || null !== $req->get_param( 'sort' ) ) {
		if ( ! $v['coa'] ) {
			return ogc_rest_denied();
		}
		if ( null !== $req->get_param( 'name' ) ) {
			$n = trim( preg_replace( '/\s+committee$/i', '', sanitize_text_field( (string) $req->get_param( 'name' ) ) ) );
			if ( '' === $n || strlen( $n ) > 60 ) {
				return new WP_Error( 'ogc_bad', 'Name needed', array( 'status' => 400 ) );
			}
			$set['name'] = $n;
		}
		if ( null !== $req->get_param( 'duties' ) ) {
			$set['duties'] = ogc_app_clean_text( $req->get_param( 'duties' ), 4000 );
		}
		if ( null !== $req->get_param( 'sort' ) ) {
			$set['sort'] = (int) $req->get_param( 'sort' );
		}
	}
	if ( null !== $req->get_param( 'link' ) ) {
		$l = trim( (string) $req->get_param( 'link' ) );
		if ( '' !== $l && ( ! preg_match( '#^https://#i', $l ) || ! wp_http_validate_url( $l ) ) ) {
			return new WP_Error( 'ogc_bad', 'Link must start with https://', array( 'status' => 400 ) );
		}
		$set['link'] = '' === $l ? '' : esc_url_raw( $l, array( 'https' ) );
	}
	if ( $req->get_param( 'checked' ) ) {
		$set['checked_at'] = ogc_now();
		// The COA's own page: the COA is the committee, so its one check is both (area-committees 12.1).
		if ( 'coa' === $c['ckey'] && $v['coa'] && function_exists( 'ogc_app_set_duties_checked' ) ) {
			ogc_app_set_duties_checked( $y, 'coa', true );
		}
	}
	// The COA's own check of a committee's responsibilities and tasks (area-committees decision 1), or its Undo.
	if ( null !== $req->get_param( 'duties_checked' ) && function_exists( 'ogc_app_set_duties_checked' ) ) {
		if ( ! $v['coa'] ) {
			return ogc_rest_denied();
		}
		$on = ! in_array( (string) $req->get_param( 'duties_checked' ), array( '', '0', 'false' ), true );
		ogc_app_set_duties_checked( $y, $c['ckey'], $on );
		ogc_log( 'app_duties_checked', $y, 'committee:' . $c['ckey'], array( 'ckey' => $c['ckey'], 'done' => $on ? 1 : 0 ) );
		if ( ! $set ) {
			return ogc_app_rest_committee( $req );
		}
	}
	if ( ! $set ) {
		return new WP_Error( 'ogc_bad', 'Nothing to change.', array( 'status' => 400 ) );
	}
	$set['updated_at'] = ogc_now();
	$wpdb->update( ogc_table( 'committees' ), $set, array( 'id' => (int) $c['id'] ) );
	ogc_app_committees( $y, true );
	if ( isset( $set['name'] ) || isset( $set['sort'] ) ) {
		ogc_app_sync_csv( $y );
	}
	ogc_log( 'app_committee_edit', $y, 'committee:' . $c['ckey'], array( 'ckey' => $c['ckey'], 'fields' => array_keys( $set ) ) );
	return ogc_app_rest_committee( $req );
}

function ogc_app_rest_committee_delete( WP_REST_Request $req ) {
	global $wpdb;
	$y = (int) $req['year'];
	$v = ogc_app_req_viewer( $req );
	$c = ogc_app_write_committee( $req );
	if ( is_wp_error( $c ) ) {
		return $c;
	}
	if ( ! $v['coa'] || 'coa' === $c['ckey'] ) {
		return ogc_rest_denied();
	}
	if ( ogc_app_people( $y, $c['ckey'] ) ) {
		return new WP_Error( 'ogc_not_empty', 'Move its people first', array( 'status' => 409 ) );
	}
	$wpdb->update( ogc_table( 'committees' ), array( 'removed_at' => ogc_now(), 'screens' => '' ), array( 'id' => (int) $c['id'] ) );
	ogc_app_committees( $y, true );
	ogc_app_sync_csv( $y );
	ogc_log( 'app_committee_edit', $y, 'committee:' . $c['ckey'], array( 'ckey' => $c['ckey'], 'removed' => 1 ) );
	return rest_ensure_response( array( 'removed' => true ) );
}

/** Hand a screen to a committee (or back to the COA with c = ''). */
function ogc_app_rest_hand( WP_REST_Request $req ) {
	global $wpdb;
	$y  = (int) $req['year'];
	$v  = ogc_app_req_viewer( $req );
	$id = sanitize_key( (string) $req->get_param( 'screen' ) );
	$s  = ogc_app_screens( $y );
	if ( ! $v['coa'] || ! isset( $s[ $id ] ) || ! $s[ $id ]['handable'] ) {
		return ogc_rest_denied();
	}
	$to = ogc_app_c( $req );
	if ( '' !== $to && ( 'coa' === $to || ! ogc_app_committee( $y, $to ) ) ) {
		return new WP_Error( 'ogc_not_found', 'Not found.', array( 'status' => 404 ) );
	}
	// A screen that carries people (the COA's Households) is handed only once the COA has read what it
	// gives (the pill asks Yes · No): access area, module-guard.php ogc_access_hand_people.
	$people = function_exists( 'ogc_access_hand_people' ) ? ogc_access_hand_people() : array();
	if ( '' !== $to && isset( $people[ $id ] ) && ! $req->get_param( 'confirm' ) ) {
		return new WP_Error( 'ogc_hand_people', $people[ $id ], array( 'status' => 409, 'people' => $people[ $id ] ) );
	}
	// One committee a screen: taken from any other first.
	foreach ( ogc_app_committees( $y ) as $c ) {
		$list = array_values( array_diff( $c['screens'], array( $id ) ) );
		if ( $c['ckey'] === $to ) {
			$list[] = $id;
		}
		if ( $list !== $c['screens'] ) {
			$wpdb->update( ogc_table( 'committees' ), array( 'screens' => implode( ',', $list ), 'updated_at' => ogc_now() ), array( 'id' => (int) $c['id'] ) );
		}
	}
	ogc_app_committees( $y, true );
	// Its tasks go with it (Registration opens, the master schedule…).
	ogc_app_move_screen_tasks( $y, $id, $to );
	ogc_log( 'app_hand', $y, 'committee:' . ( '' === $to ? 'coa' : $to ), array( 'ckey' => '' === $to ? 'coa' : $to, 'title' => $s[ $id ]['title'] ) );
	// Handing or taking back on Who runs what answers the COA's first step (area-home-tasks 1.4).
	if ( function_exists( 'ogc_app_first_mark' ) ) {
		ogc_app_first_mark( $y, 'who' );
	}
	return rest_ensure_response( array( 'screen' => $id, 'to' => $to ) );
}

/* ================================================================== tasks */

/** Tasks for the Tasks screen: view = mine | committee | all (the COA; a webmaster reads all, no names). */
function ogc_app_rest_tasks( WP_REST_Request $req ) {
	$y    = (int) $req['year'];
	$v    = ogc_app_req_viewer( $req );
	$view = (string) $req->get_param( 'view' );
	$all  = $v['coa'] || $v['webmaster'];
	$keys = $all ? null : $v['committees'];
	$rows = ogc_app_tasks( $y, $keys );
	if ( 'mine' === $view ) {
		$rows = array_values( array_filter( $rows, function ( $t ) use ( $v ) {
			return $v['member_id'] && $t['owner'] === $v['member_id'];
		} ) );
	} elseif ( 'committee' === $view ) {
		$mine = $v['coa'] ? array( 'coa' ) : $v['committees'];
		$rows = array_values( array_filter( $rows, function ( $t ) use ( $mine ) {
			return in_array( $t['committee'], $mine, true );
		} ) );
	}
	$names = array();
	foreach ( ogc_members_list( $y ) as $m ) {
		$names[ (int) $m['id'] ] = ogc_app_person_name( $m );
	}
	$rows = array_map( function ( $t ) use ( $y, $v, $names ) {
		$named           = ! $v['webmaster'] || $v['coa'];
		$t['done_by']    = $named && $t['done_by_id'] ? ogc_app_user_name( $t['done_by_id'], $y ) : '';
		$t['owner_name'] = $named && $t['owner'] && isset( $names[ $t['owner'] ] ) ? $names[ $t['owner'] ] : '';
		unset( $t['done_by_id'] );
		return $t;
	}, $rows );
	return rest_ensure_response( array( 'tasks' => $rows, 'friday' => (bool) ogc_app_friday( $y ) ) );
}

/** A task's fields from a request, checked. $t is the row being changed (or null for a new one). */
function ogc_app_task_fields( WP_REST_Request $req, $year, $t = null ) {
	$set = array();
	if ( null !== $req->get_param( 'title' ) ) {
		$title = trim( sanitize_text_field( (string) $req->get_param( 'title' ) ) );
		if ( '' === $title ) {
			return new WP_Error( 'ogc_bad', 'Title needed', array( 'status' => 400 ) );
		}
		$set['title'] = substr( $title, 0, 190 );
	}
	if ( null !== $req->get_param( 'note' ) ) {
		$set['note'] = ogc_app_clean_text( $req->get_param( 'note' ), 2000 );
	}
	// One date, from one source: a task whose date a setting decides (Answer requests: the round's due
	// date) isn't given a second one here (Round 1, after the critic).
	if ( $t && ( null !== $req->get_param( 'date' ) || null !== $req->get_param( 'offset' ) ) && ! empty( $t['kind'] ) && '' !== ogc_app_task_kind_due( (string) $t['kind'], $year ) ) {
		return new WP_Error( 'ogc_due_set', 'Due · ' . ogc_app_task_due_from( (string) $t['kind'] ), array( 'status' => 400 ) );
	}
	if ( null !== $req->get_param( 'date' ) ) {
		$d = (string) $req->get_param( 'date' );
		if ( '' !== $d && ( ! preg_match( '/^(\d{4})-(\d{2})-(\d{2})$/', $d, $x ) || ! checkdate( (int) $x[2], (int) $x[3], (int) $x[1] ) ) ) {
			return new WP_Error( 'ogc_bad', 'Date not valid', array( 'status' => 400 ) );
		}
		$set['due_date'] = $d;
		if ( '' !== $d ) {
			$set['due_offset'] = null;
		}
	}
	if ( null !== $req->get_param( 'offset' ) ) {
		$o = $req->get_param( 'offset' );
		if ( '' === $o || null === $o ) {
			$set['due_offset'] = null;
		} else {
			$set['due_offset'] = max( -1000, min( 400, (int) $o ) );
			$set['due_date']   = '';
		}
	}
	if ( null !== $req->get_param( 'owner' ) ) {
		$o = (int) $req->get_param( 'owner' );
		if ( $o ) {
			$m = ogc_member_get( $o );
			if ( ! $m || (int) $m['year'] !== (int) $year || ! ogc_member_active( $m ) ) {
				return new WP_Error( 'ogc_bad', 'Not on the year', array( 'status' => 400 ) );
			}
		}
		$set['owner'] = $o;
	}
	return $set;
}

function ogc_app_rest_task_add( WP_REST_Request $req ) {
	global $wpdb;
	$y = (int) $req['year'];
	$c = ogc_app_write_committee( $req );
	if ( is_wp_error( $c ) ) {
		return $c;
	}
	if ( null === $req->get_param( 'title' ) ) {
		return new WP_Error( 'ogc_bad', 'Title needed', array( 'status' => 400 ) );
	}
	if ( ogc_throttle( 'app_task:' . get_current_user_id(), 200, HOUR_IN_SECONDS ) ) {
		return new WP_Error( 'ogc_rate', 'Too many · Try later', array( 'status' => 429 ) );
	}
	$set = ogc_app_task_fields( $req, $y );
	if ( is_wp_error( $set ) ) {
		return $set;
	}
	$wpdb->insert( ogc_table( 'tasks' ), array_merge( array( 'due_date' => '', 'due_offset' => null ), $set, array(
		'year'       => $y,
		'ckey'       => $c['ckey'],
		'sort'       => 1000,
		'source'     => 'added',
		'created_by' => get_current_user_id(),
		'created_at' => ogc_now(),
	) ) );
	$id = (int) $wpdb->insert_id;
	ogc_log( 'app_task_add', $y, 'task:' . $id, array( 'ckey' => $c['ckey'], 'title' => $set['title'] ) );
	return rest_ensure_response( ogc_app_task_out( $id ) );
}

function ogc_app_task_out( $id ) {
	global $wpdb;
	$t = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . ogc_table( 'tasks' ) . ' WHERE id = %d', $id ), ARRAY_A );
	$o = ogc_app_task_row( $t, ogc_app_friday( (int) $t['year'] ), (int) $t['year'] );
	$o['done_by'] = $o['done_by_id'] ? ogc_app_user_name( $o['done_by_id'], (int) $t['year'] ) : '';
	unset( $o['done_by_id'] );
	return $o;
}

function ogc_app_rest_task_patch( WP_REST_Request $req ) {
	global $wpdb;
	$t   = $req->get_param( '_row' );
	$y   = (int) $t['year'];
	$v   = ogc_app_viewer( $y );
	$set = ogc_app_task_fields( $req, $y, $t );
	if ( is_wp_error( $set ) ) {
		return $set;
	}
	if ( null !== $req->get_param( 'committee' ) ) {
		// Moving a task to another committee: the COA only (no-assumed-owners: the COA hands work on).
		$to = ogc_committee_key( (string) $req->get_param( 'committee' ) );
		if ( ! $v['coa'] || ! ogc_app_committee( $y, $to ) ) {
			return ogc_rest_denied();
		}
		$set['ckey'] = $to;
	}
	$act = '';
	if ( null !== $req->get_param( 'done' ) ) {
		$done = (bool) $req->get_param( 'done' );
		if ( $done && empty( $t['done_at'] ) ) {
			$set['done_at'] = ogc_now();
			$set['done_by'] = get_current_user_id();
			$act            = 'app_task_done';
		} elseif ( ! $done && ! empty( $t['done_at'] ) ) {
			$set['done_at'] = null;
			$set['done_by'] = 0;
			$act            = 'app_task_undone';
		}
	}
	if ( $set ) {
		$wpdb->update( ogc_table( 'tasks' ), $set, array( 'id' => (int) $t['id'] ) );
	}
	if ( $act ) {
		ogc_log( $act, $y, 'task:' . $t['id'], array( 'ckey' => isset( $set['ckey'] ) ? $set['ckey'] : $t['ckey'], 'title' => isset( $set['title'] ) ? $set['title'] : $t['title'] ) );
	} elseif ( $set ) {
		ogc_log( 'app_task_edit', $y, 'task:' . $t['id'], array( 'ckey' => $t['ckey'] ) );
	}
	return rest_ensure_response( ogc_app_task_out( (int) $t['id'] ) );
}

function ogc_app_rest_task_delete( WP_REST_Request $req ) {
	global $wpdb;
	$t = $req->get_param( '_row' );
	$wpdb->update( ogc_table( 'tasks' ), array( 'removed_at' => ogc_now() ), array( 'id' => (int) $t['id'] ) );
	ogc_log( 'app_task_remove', (int) $t['year'], 'task:' . $t['id'], array( 'ckey' => $t['ckey'], 'title' => $t['title'] ) );
	// Undo within the hour: PATCH { restore: true } isn't kept; the toast's Undo re-adds it instead.
	return rest_ensure_response( array( 'removed' => true, 'task' => array( 'title' => $t['title'], 'committee' => $t['ckey'], 'note' => $t['note'], 'offset' => null === $t['due_offset'] ? null : (int) $t['due_offset'], 'date' => $t['due_date'] ) ) );
}

/* ================================================================== notes, report, files */

function ogc_app_rest_note_add( WP_REST_Request $req ) {
	global $wpdb;
	$y = (int) $req['year'];
	$c = ogc_app_write_committee( $req );
	if ( is_wp_error( $c ) ) {
		return $c;
	}
	$body = trim( ogc_app_clean_text( $req->get_param( 'body' ), 2000 ) );
	if ( '' === $body ) {
		return new WP_Error( 'ogc_bad', 'Note needed', array( 'status' => 400 ) );
	}
	if ( ogc_throttle( 'app_note:' . get_current_user_id(), 100, HOUR_IN_SECONDS ) ) {
		return new WP_Error( 'ogc_rate', 'Too many · Try later', array( 'status' => 429 ) );
	}
	$wpdb->insert( ogc_table( 'cnotes' ), array( 'year' => $y, 'ckey' => $c['ckey'], 'body' => $body, 'author' => get_current_user_id(), 'created_at' => ogc_now() ) );
	ogc_log( 'app_note_add', $y, 'committee:' . $c['ckey'], array( 'ckey' => $c['ckey'] ) );
	return rest_ensure_response( array( 'id' => (int) $wpdb->insert_id ) );
}

/** A note is marked Done by the next year's committee (or the COA): the viewer of the note's next year. */
function ogc_app_can_note( WP_REST_Request $req ) {
	global $wpdb;
	if ( ! ogc_app_tables_ready() ) {
		return new WP_Error( 'ogc_not_found', 'Not found.', array( 'status' => 404 ) );
	}
	$n = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . ogc_table( 'cnotes' ) . ' WHERE id = %d AND removed_at IS NULL', (int) $req['id'] ), ARRAY_A );
	if ( ! $n ) {
		return new WP_Error( 'ogc_not_found', 'Not found.', array( 'status' => 404 ) );
	}
	foreach ( array( (int) $n['year'], (int) $req->get_param( 'year' ) ) as $y ) {
		if ( ! ogc_valid_year( $y ) || $y < (int) $n['year'] ) {
			continue;
		}
		$v = ogc_app_viewer( $y, (string) $req->get_param( 'as' ) );
		if ( $v['as'] ) {
			return new WP_Error( 'ogc_read_only', 'Read only while seeing as', array( 'status' => 403 ) );
		}
		if ( ogc_app_can_see( $v, 'committees' ) && ogc_app_on_committee( $v, $n['ckey'] ) && ( $y === (int) $n['year'] || ogc_app_prev_year( $y ) === (int) $n['year'] ) ) {
			$req->set_param( '_row', $n );
			return true;
		}
	}
	return new WP_Error( 'ogc_not_found', 'Not found.', array( 'status' => 404 ) );
}

function ogc_app_rest_note_patch( WP_REST_Request $req ) {
	global $wpdb;
	$n    = $req->get_param( '_row' );
	$done = (bool) $req->get_param( 'done' );
	$wpdb->update( ogc_table( 'cnotes' ), $done ? array( 'done_at' => ogc_now(), 'done_by' => get_current_user_id() ) : array( 'done_at' => null, 'done_by' => 0 ), array( 'id' => (int) $n['id'] ) );
	return rest_ensure_response( array( 'id' => (int) $n['id'], 'done' => $done ) );
}

function ogc_app_rest_note_delete( WP_REST_Request $req ) {
	global $wpdb;
	$n = $req->get_param( '_row' );
	$wpdb->update( ogc_table( 'cnotes' ), array( 'removed_at' => ogc_now() ), array( 'id' => (int) $n['id'] ) );
	return rest_ensure_response( array( 'removed' => true, 'body' => $n['body'] ) );
}

/** Save the report's answers (as typed); send: true marks it sent to the COA. */
function ogc_app_rest_report_put( WP_REST_Request $req ) {
	global $wpdb;
	$y = (int) $req['year'];
	$c = ogc_app_write_committee( $req );
	if ( is_wp_error( $c ) ) {
		return $c;
	}
	if ( 'coa' === $c['ckey'] ) {
		return ogc_rest_denied();
	}
	$q   = ogc_app_report_questions( $y );
	$ans = array();
	foreach ( array_values( (array) $req->get_param( 'answers' ) ) as $i => $a ) {
		if ( $i < count( $q ) ) {
			$ans[] = ogc_app_clean_text( is_scalar( $a ) ? $a : '', 6000 );
		}
	}
	$cur = $wpdb->get_row( $wpdb->prepare( 'SELECT id, sent_at FROM ' . ogc_table( 'creports' ) . ' WHERE year = %d AND ckey = %s', $y, $c['ckey'] ), ARRAY_A );
	$row = array( 'answers' => ogc_json( $ans ), 'updated_by' => get_current_user_id(), 'updated_at' => ogc_now() );
	$send = (bool) $req->get_param( 'send' );
	if ( $send ) {
		if ( ! array_filter( $ans, 'strlen' ) ) {
			return new WP_Error( 'ogc_bad', 'Answer at least one', array( 'status' => 400 ) );
		}
		$row['sent_at'] = ogc_now();
	}
	if ( $cur ) {
		$wpdb->update( ogc_table( 'creports' ), $row, array( 'id' => (int) $cur['id'] ) );
	} else {
		$wpdb->insert( ogc_table( 'creports' ), array_merge( $row, array( 'year' => $y, 'ckey' => $c['ckey'] ) ) );
	}
	if ( $send && ( ! $cur || ! $cur['sent_at'] ) ) {
		ogc_log( 'app_report_sent', $y, 'committee:' . $c['ckey'], array( 'ckey' => $c['ckey'] ) );
	}
	return rest_ensure_response( ogc_app_report( $y, $c['ckey'] ) );
}

/** Upload one file (multipart "file") to a committee: kept privately, named at random. */
function ogc_app_rest_file_add( WP_REST_Request $req ) {
	global $wpdb;
	$y = (int) $req['year'];
	$c = ogc_app_write_committee( $req );
	if ( is_wp_error( $c ) ) {
		return $c;
	}
	$files = $req->get_file_params();
	$f     = isset( $files['file'] ) ? $files['file'] : null;
	if ( ! $f || ! empty( $f['error'] ) || empty( $f['tmp_name'] ) || ! is_uploaded_file( $f['tmp_name'] ) ) {
		return new WP_Error( 'ogc_bad', 'No file', array( 'status' => 400 ) );
	}
	$max = (int) apply_filters( 'ogc_app_file_max', 20 * MB_IN_BYTES );
	if ( (int) $f['size'] > $max ) {
		return new WP_Error( 'ogc_too_big', 'Too large · ' . size_format( $max ) . ' at most', array( 'status' => 413 ) );
	}
	if ( ogc_throttle( 'app_file:' . get_current_user_id(), 60, HOUR_IN_SECONDS ) ) {
		return new WP_Error( 'ogc_rate', 'Too many · Try later', array( 'status' => 429 ) );
	}
	// The name as the committee knows it ("Usher posts by door.xlsx", spaces kept): it's only shown and
	// sent back as the download's name; the stored file has a random name. Path and control characters out.
	$name  = trim( preg_replace( '/\s{2,}/', ' ', preg_replace( '/[\\\\\/:*?"<>|\x00-\x1f]+/', ' ', sanitize_text_field( wp_basename( (string) $f['name'] ) ) ) ), " .\t" );
	$name  = '' === $name || false === strpos( $name, '.' ) ? sanitize_file_name( wp_basename( (string) $f['name'] ) ) : $name;
	$types = ogc_app_file_types();
	$check = wp_check_filetype_and_ext( $f['tmp_name'], $name, $types );
	$ext   = strtolower( (string) pathinfo( $name, PATHINFO_EXTENSION ) );
	if ( ! isset( $types[ $ext ] ) || ( ! $check['ext'] && ! in_array( $ext, array( 'csv', 'txt', 'heic' ), true ) ) ) {
		return new WP_Error( 'ogc_type', 'File type not allowed', array( 'status' => 415 ) );
	}
	if ( ! ogc_app_private_ok() ) {
		return new WP_Error( 'ogc_no_store', 'Files off · A webmaster sets where they’re kept', array( 'status' => 503 ) );
	}
	$dir    = ogc_app_private_dir();
	$stored = bin2hex( random_bytes( 16 ) );
	if ( ! @move_uploaded_file( $f['tmp_name'], $dir . '/' . $stored ) ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors -- reported below.
		return new WP_Error( 'ogc_store', 'Upload failed', array( 'status' => 500 ) );
	}
	$ok = $wpdb->insert( ogc_table( 'cfiles' ), array(
		'year'        => $y,
		'ckey'        => $c['ckey'],
		'name'        => substr( $name, 0, 190 ),
		'fkey'        => $stored,
		'mime'        => $types[ $ext ],
		'size'        => (int) $f['size'],
		'uploaded_by' => get_current_user_id(),
		'created_at'  => ogc_now(),
	) );
	if ( ! $ok ) {
		wp_delete_file( $dir . '/' . $stored );
		return new WP_Error( 'ogc_store', 'Upload failed', array( 'status' => 500 ) );
	}
	// By its random name, not insert_id (the local SQLite layer has answered another table's id).
	$id = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM ' . ogc_table( 'cfiles' ) . ' WHERE fkey = %s', $stored ) );
	ogc_log( 'app_file_add', $y, 'committee:' . $c['ckey'], array( 'ckey' => $c['ckey'], 'title' => substr( $name, 0, 80 ) ) );
	return rest_ensure_response( array( 'id' => $id, 'name' => $name ) );
}

/** The file itself, as a download (never shown in the browser), never cached. */
function ogc_app_rest_file_get( WP_REST_Request $req ) {
	$f    = $req->get_param( '_row' );
	$path = ogc_app_private_dir() . '/' . preg_replace( '/[^a-f0-9]/', '', (string) $f['fkey'] );
	if ( ! is_file( $path ) ) {
		return new WP_Error( 'ogc_not_found', 'Not found.', array( 'status' => 404 ) );
	}
	ogc_log( 'app_file_get', (int) $f['year'], 'file:' . (int) $f['id'], array( 'ckey' => $f['ckey'] ) );
	nocache_headers();
	header( 'Content-Type: application/octet-stream' );
	header( 'Content-Disposition: attachment; filename="' . str_replace( array( '"', "\r", "\n" ), '', $f['name'] ) . '"; filename*=UTF-8\'\'' . rawurlencode( $f['name'] ) );
	header( 'Content-Length: ' . filesize( $path ) );
	header( 'X-Content-Type-Options: nosniff' );
	header( "Content-Security-Policy: default-src 'none'; sandbox" );
	readfile( $path ); // phpcs:ignore WordPress.WP.AlternativeFunctions -- a private file, streamed.
	exit;
}

function ogc_app_rest_file_delete( WP_REST_Request $req ) {
	global $wpdb;
	$f = $req->get_param( '_row' );
	// The stored file stays while another year's row carries it (files carry forward by reference).
	$wpdb->update( ogc_table( 'cfiles' ), array( 'removed_at' => ogc_now() ), array( 'id' => (int) $f['id'] ) );
	ogc_log( 'app_file_remove', (int) $f['year'], 'committee:' . $f['ckey'], array( 'ckey' => $f['ckey'] ) );
	return rest_ensure_response( array( 'removed' => true ) );
}

/* ================================================================== message */

/** Email someone on the year, or a whole committee, through the site: no address is shown or sent
 * back. to: "member:ID" or "committee:KEY". Replies go to the sender. */
function ogc_app_rest_message( WP_REST_Request $req ) {
	$y       = (int) $req['year'];
	$v       = ogc_app_req_viewer( $req );
	$to      = (string) $req->get_param( 'to' );
	$subject = trim( sanitize_text_field( (string) $req->get_param( 'subject' ) ) );
	$body    = trim( ogc_app_clean_text( $req->get_param( 'body' ), 4000 ) );
	if ( '' === $body ) {
		return new WP_Error( 'ogc_bad', 'Message needed', array( 'status' => 400 ) );
	}
	$list = array();
	$ckey = '';
	if ( preg_match( '/^member:(\d+)$/', $to, $x ) ) {
		$m = ogc_member_get( (int) $x[1] );
		// A webmaster messages the COA only (the names they may see).
		if ( ! $m || (int) $m['year'] !== $y || ! ogc_member_active( $m ) || ( $v['webmaster'] && ! $v['coa'] && 'coa' !== $m['role'] ) ) {
			return new WP_Error( 'ogc_not_found', 'Not found.', array( 'status' => 404 ) );
		}
		$list[] = $m;
		$keys   = ogc_member_committee_keys( $m );
		$ckey   = 'coa' === $m['role'] ? 'coa' : ( $keys ? $keys[0] : '' );
	} elseif ( preg_match( '/^committee:(.+)$/', $to, $x ) ) {
		$ckey = ogc_committee_key( $x[1] );
		if ( ! ogc_app_committee( $y, $ckey ) || ( $v['webmaster'] && ! $v['coa'] && 'coa' !== $ckey ) ) {
			return new WP_Error( 'ogc_not_found', 'Not found.', array( 'status' => 404 ) );
		}
		$list = ogc_app_people( $y, $ckey );
	}
	$me   = ogc_current_email();
	$list = array_values( array_filter( $list, function ( $m ) use ( $me ) {
		return $m['email'] !== $me;
	} ) );
	if ( ! $list ) {
		return new WP_Error( 'ogc_nobody', 'No one to send to', array( 'status' => 400 ) );
	}
	if ( ogc_throttle( 'app_msg:' . get_current_user_id(), 20, HOUR_IN_SECONDS ) || ogc_throttle( 'app_msg_day:' . get_current_user_id(), 60, DAY_IN_SECONDS ) ) {
		return new WP_Error( 'ogc_rate', 'Too many messages · Try later', array( 'status' => 429 ) );
	}
	$from = ogc_app_user_name( get_current_user_id(), $y );
	$mine = $v['coa'] ? 'Committee of Arrangements' : ( $v['committees'] ? ogc_app_committee( $y, $v['committees'][0] )['name'] : ( $v['webmaster'] ? 'Conference webmasters' : '' ) );
	$c    = $ckey ? ogc_app_committee( $y, $ckey ) : null;
	$link = ogc_url( 'app', array_filter( array( 'year' => $y, 's' => 'committees', 'c' => $ckey ) ) );
	$items = array();
	foreach ( $list as $m ) {
		ogc_mail_send_kind( 'app_message', $m['email'], array(
			'year'      => $y,
			'subject'   => '' !== $subject ? $subject : 'Message',
			'from'      => $from . ( $mine ? ' · ' . $mine : '' ),
			'committee' => $c ? $c['name'] : '',
			'whole'     => 0 === strpos( $to, 'committee:' ),
			'body'      => $body,
			'link'      => $link,
		), array( 'reply_to' => $me, 'to_member' => true ) );
		$items[] = (int) $m['id'];
	}
	ogc_log( 'app_message', $y, 'committee:' . $ckey, array( 'ckey' => $ckey, 'n' => count( $items ) ) );
	return rest_ensure_response( array( 'sent' => count( $items ) ) );
}

/* ------------------------------------------------------------------ the message's email */

// One person's own words to someone on the year, or to a whole committee: "Linens · Ada T.". The
// subject names the sender, so the live site's log keeps only the kind (ogc_mail_private_kinds).
add_filter( 'ogc_mail_kinds', function ( $k ) {
	$k['app_message'] = 'Message (from the app)';
	return $k;
} );
add_filter( 'ogc_mail_private_kinds', function ( $k ) {
	$k[] = 'app_message';
	return $k;
} );
add_filter( 'ogc_mail_samples', function ( $s ) {
	$s['app_message'] = array( 'subject' => 'Linens', 'from' => 'Ada T. · Lodging', 'committee' => 'Food', 'whole' => true, 'body' => "Could Food set out the linen packets beside the dining hall doors on Friday?\nWe'll bring them at 2.", 'link' => ogc_url( 'app' ) );
	return $s;
} );
add_filter( 'ogc_mail_template_kind', function ( $m, $kind, $d, $base ) {
	if ( 'app_message' !== $kind ) {
		return $m;
	}
	$g    = function ( $k ) use ( $d ) {
		return isset( $d[ $k ] ) ? wp_strip_all_tags( (string) $d[ $k ] ) : '';
	};
	$who  = preg_replace( '/ · .*$/', '', $g( 'from' ) );
	$subj = ( '' !== $g( 'subject' ) ? $g( 'subject' ) : 'Message' ) . ( '' !== $who ? ' · ' . $who : '' );
	$y    = isset( $d['year'] ) ? (int) $d['year'] : 0;
	$com  = $g( 'committee' );
	return ogc_mail_compose( array_merge( $base, array(
		'subject' => $subj,
		'heading' => $subj,
		'facts'   => array( array( 'From', $g( 'from' ) ), array( 'To', ! empty( $d['whole'] ) && '' !== $com ? ( 'Committee of Arrangements' === $com ? $com : $com . ' committee' ) : '' ) ),
		'plain'   => substr( (string) ( isset( $d['body'] ) ? $d['body'] : '' ), 0, 4000 ),
		'button'  => '' !== $g( 'link' ) ? array( '' !== $com ? 'Open ' . $com : 'Open ' . ( $y ? $y : 'the app' ), $g( 'link' ) ) : null,
		'after'   => array( 'Reply to this email to answer.' ),
		'reason'  => '' !== $com ? 'You’re on the ' . ( $y ? $y . ' ' : '' ) . ( 'Committee of Arrangements' === $com ? $com : $com . ' committee' ) . '.' : 'You’re on the ' . ( $y ? $y . ' ' : '' ) . 'Conference members list.',
	) ) );
}, 10, 4 );

/* ================================================================== phones (the COA's, docs/23) */

/** The phones the COA keeps for people on the year: member id → phone. The COA only, never sent to
 * anyone else (not the members list's own column, which is the signin area's). */
function ogc_app_phones( $year ) {
	$s = ogc_state_get( (int) $year, 'app-phones' );
	return $s ? array_map( 'strval', (array) $s['value'] ) : array();
}

function ogc_app_rest_phones( WP_REST_Request $req ) {
	$v = ogc_app_req_viewer( $req );
	return rest_ensure_response( array( 'phones' => $v['coa'] && ! $v['as'] ? (object) ogc_app_phones( (int) $req['year'] ) : (object) array() ) );
}

function ogc_app_rest_phone_put( WP_REST_Request $req ) {
	$y  = (int) $req['year'];
	$v  = ogc_app_req_viewer( $req );
	$id = (int) $req->get_param( 'id' );
	$m  = $id ? ogc_member_get( $id ) : null;
	if ( ! $v['coa'] || ! $m || (int) $m['year'] !== $y ) {
		return new WP_Error( 'ogc_not_found', 'Not found.', array( 'status' => 404 ) );
	}
	$ph = trim( preg_replace( '/[^0-9+()\-. x]/', '', (string) $req->get_param( 'phone' ) ) );
	if ( strlen( $ph ) > 30 || ( '' !== $ph && strlen( preg_replace( '/\D/', '', $ph ) ) < 7 ) ) {
		return new WP_Error( 'ogc_bad', 'A phone number · Like 555-0100', array( 'status' => 400 ) );
	}
	for ( $try = 0; $try < 3; $try++ ) {
		$cur = ogc_state_get( $y, 'app-phones' );
		$all = $cur ? (array) $cur['value'] : array();
		if ( '' === $ph ) {
			unset( $all[ $id ] );
		} else {
			$all[ $id ] = $ph;
		}
		if ( ! is_wp_error( ogc_state_put( $y, 'app-phones', (object) $all, $cur ? $cur['version'] : 0 ) ) ) {
			break;
		}
	}
	ogc_log( 'app_phone', $y, 'member:' . $id, array() );
	return rest_ensure_response( array( 'phones' => (object) ogc_app_phones( $y ) ) );
}
