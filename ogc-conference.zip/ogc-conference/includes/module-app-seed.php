<?php
/**
 * What a first year starts from (a year with no year before it in the app): the COA and the eleven
 * committees, each with its responsibilities in plain words (docs/16, from the 2020 and 2027 Committee
 * Duties), and the year's tasks by their fixed dates (docs/16 "The year, by its fixed dates"; docs/14's
 * calendar), counted from the Conference's Friday where the documents count from it.
 * Every later year carries the one before (ogc_app_carry), so this runs once for the first year opened.
 *
 * On a local site (OGC_DEV) the seed also adds made-up people to each 2026 and 2027 committee ("First
 * L." names, @example.com addresses; never real people), marks 2027's past tasks done, and leaves a
 * few notes and one report from 2026 to show what the next committee sees. Idempotent: run on every
 * upgrade (ogc_seed_year, and once per site on init), it adds only what isn't there.
 */

defined( 'ABSPATH' ) || exit;

/** The committees a first year starts with: key-less names (the key is ogc_committee_key( name )),
 * as the committees' own lists spell them (the requests sheet), and their responsibilities. */
function ogc_app_seed_committees() {
	return array(
		array( 'Committee of Arrangements', "Choose the place and oversee the money\nName the foremen and hand out the work\nTalk with the campus for every committee\nCollect budgets and the committees’ reports\nAnnounce through the districts\nSend the website its materials", 'coa' ),
		array( 'A/V', "Sound with the campus\nOther committees’ sound and recording needs\nThe call-in line and the recordings\nThe master schedule, and posting the schedule and recordings" ),
		array( 'Ushers', "Seating, chairs, tables and podiums\nThe ministry’s and the Conference Committee’s needs\nOverflow services, service flow and ventilation\nWork with First Aid" ),
		array( 'Lodging', "Registration, rooms and assignments\nLinens and keys\nCheck-in and the Information Center\nLocal hotels and RV parks\nSpecial needs, and problems during the week" ),
		array( 'Food', "Help the caterer\nMenus, serving lines and traffic flow\nMeal counts\nSnacks for Young Folks, Preteens and all-age events" ),
		array( 'Communion', "Set-up for the communion service\nThe meal and the elements, with the food service\nFlow and supplies" ),
		array( 'First Aid', "The first aid rooms and supplies\nThe staff schedule\nWork with the Ushers, the campus and local authorities" ),
		array( 'Nursery', "The nursery rooms and their staff\nSupplies\nStroller parking" ),
		array( 'Transportation', "Parking for cars, RVs and accessible spaces\nSigns, and maps with Lodging\nGolf carts and drivers\nSafety near creeks and woods, campus security, trash" ),
		array( 'Preteens', "Activities and supervision for ages 10–13\nCheck-in and check-out\nKit packs and snacks" ),
		array( 'Young Folks', "Activities, devotions and meetings\nDorm supervision, with Lodging at check-in\nThe Monday night service\nTournaments and the kit-packing project" ),
		array( 'Public Relations', "News and local questions\nPublic-facing information" ),
	);
}

/**
 * The year's tasks by committee key. A when is an offset in days from the Conference's Friday
 * (array( 'off', -91 )), or a calendar date in the Conference's year or the year before
 * (array( 'md', '11-01', -1 )). Owners are only the committee a task is plainly theirs; anything
 * shared is the COA's to hand on (no-assumed-owners).
 */
function ogc_app_seed_tasks() {
	$every = array(
		array( 'First meeting', array( 'md', '11-01', -1 ) ),
		array( 'Answer requests', array( 'md', '01-08', 0 ), 'requests_answer' ),
		array( 'Notes for next year', array( 'off', 21 ) ),
		array( 'Report to the COA', array( 'off', 42 ), 'report_sent' ),
	);
	$own = array(
		'coa'            => array(
			array( 'Name the foremen', array( 'off', -420 ) ),
			array( 'Ask committees for options', array( 'off', -365 ) ),
			array( 'Campus tour', array( 'md', '10-15', -1 ) ),
			array( 'Announce the Conference', array( 'md', '11-01', -1 ), 'announce' ),
			array( 'Send requests to campus', array( 'md', '01-15', 0 ), 'requests_sent' ),
			array( 'Master schedule', array( 'md', '01-08', 0 ), 'schedule' ),
			array( 'Registration opens', array( 'off', -91 ), 'reg_open' ),
			array( 'Volunteer sign-ups open', array( 'md', '03-15', 0 ), 'signups_open' ),
			array( 'Tell every district registration is open', array( 'off', -91 ), 'reg_tell' ),
			array( 'Final counts and keys to the campus', array( 'off', -14 ) ),
			array( 'Last schedule revision', array( 'off', -1 ) ),
			array( 'Ask every committee for its report', array( 'off', 21 ) ),
		),
		'a/v'            => array(
			array( 'Call-in number to The Testimony', array( 'md', '04-22', 0 ) ),
		),
		'lodging'        => array(
			array( 'Final counts and dorm keys', array( 'off', -14 ) ),
		),
		'food'           => array(
			array( 'Final meal counts to the caterer', array( 'off', -14 ), 'meals_sent' ),
		),
		'young folks'    => array(
			array( 'Kit-packing money due', array( 'md', '04-15', 0 ) ),
			array( 'Tournament sign-ups open', array( 'md', '05-01', 0 ) ),
		),
	);
	$out = array();
	foreach ( ogc_app_seed_committees() as $c ) {
		$k     = isset( $c[2] ) ? $c[2] : ogc_committee_key( $c[0] );
		$list  = isset( $own[ $k ] ) ? $own[ $k ] : array();
		$out[ $k ] = 'coa' === $k ? $list : array_merge( array( $every[0], $every[1] ), $list, array( $every[2], $every[3] ) );
	}
	return $out;
}

/** Start a year from the seed: its committees and tasks. */
function ogc_app_seed_year( $year ) {
	global $wpdb;
	$year = (int) $year;
	if ( (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM ' . ogc_table( 'committees' ) . ' WHERE year = %d', $year ) ) ) {
		return;
	}
	$sort = 0;
	foreach ( ogc_app_seed_committees() as $c ) {
		$k = isset( $c[2] ) ? $c[2] : ogc_committee_key( $c[0] );
		$wpdb->insert( ogc_table( 'committees' ), array(
			'year'       => $year,
			'ckey'       => $k,
			'name'       => $c[0],
			'duties'     => $c[1],
			'sort'       => $sort,
			'created_at' => ogc_now(),
			'updated_at' => ogc_now(),
		) );
		$sort += 10;
	}
	ogc_app_committees( $year, true );
	if ( ! (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM ' . ogc_table( 'tasks' ) . ' WHERE year = %d', $year ) ) ) {
		foreach ( ogc_app_seed_tasks() as $k => $list ) {
			foreach ( $list as $i => $t ) {
				$w = $t[1];
				$wpdb->insert( ogc_table( 'tasks' ), array(
					'year'       => $year,
					'ckey'       => $k,
					'title'      => $t[0],
					'due_offset' => 'off' === $w[0] ? (int) $w[1] : null,
					'due_date'   => 'md' === $w[0] ? sprintf( '%04d-%s', $year + (int) $w[2], $w[1] ) : '',
					'sort'       => $i * 10,
					'source'     => 'seed',
					'kind'       => isset( $t[2] ) ? $t[2] : '',
					'created_at' => ogc_now(),
				) );
			}
		}
	}
	ogc_app_sync_csv( $year );
}

/* ------------------------------------------------------------------ the local site's samples */

/** Made-up people for the local site: year → list of [first last, committee key, head]. The first
 * two 2027 Lodging, Food and Transportation people are members.json's (signin area), kept as they are. */
function ogc_app_seed_people() {
	return array(
		2027 => array(
			array( 'Ada Turner', 'lodging', true ),
			array( 'Grace Turner', 'lodging', false ),
			array( 'Martha Brooks', 'food', true ),
			array( 'Hannah Cole', 'food', false ),
			array( 'Micah Rhodes', 'a/v', true ),
			array( 'Levi Stone', 'a/v,ushers', false ),
			array( 'Aaron Walsh', 'ushers', true ),
			array( 'Daniel Ford', 'communion', true ),
			array( 'Rachel Owens', 'first aid', true ),
			array( 'Lydia Parker', 'nursery', true ),
			array( 'Isaac Hart', 'transportation', false ),
			array( 'Naomi Reed', 'preteens', true ),
			array( 'Eli Barton', 'young folks', true ),
			array( 'Ruth Barton', 'young folks', false ),
		),
		2026 => array(
			array( 'Paul Mason', 'lodging', true ),
			array( 'Sarah Dean', 'food', true ),
			array( 'Jonah Wells', 'a/v', true ),
			array( 'Abigail Shaw', 'preteens', true ),
		),
	);
}

/** Notes 2026's committees left for 2027 (the year page's three from docs/14's findings, by committee),
 * and A/V's 2026 report: made up, in the committees' voice. */
function ogc_app_seed_samples( $year ) {
	global $wpdb;
	if ( 2026 !== (int) $year ) {
		return;
	}
	if ( ! (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM ' . ogc_table( 'cnotes' ) . " WHERE year = %d AND source = 'sample'", $year ) ) ) {
		$notes = array(
			array( 'a/v', 'Ask every committee for its recording and call-in needs by April 1. Three came the week before.' ),
			array( 'lodging', 'Ask the campus for the hall list in January. It came in April in 2026.' ),
			array( 'lodging', 'Young Folks roommates in one box were retyped by hand. Ask each by name.' ),
			array( 'food', 'The caterer’s menu came two weeks before. Ask for it in March.' ),
			array( 'coa', 'Send the website its materials by March 1, in the shape the page takes.' ),
		);
		foreach ( $notes as $n ) {
			$wpdb->insert( ogc_table( 'cnotes' ), array( 'year' => $year, 'ckey' => $n[0], 'body' => $n[1], 'source' => 'sample', 'created_at' => '2026-07-01 15:00:00' ) );
		}
	}
	if ( ! ogc_app_report( $year, 'a/v' ) ) {
		$wpdb->insert( ogc_table( 'creports' ), array(
			'year'       => $year,
			'ckey'       => 'a/v',
			'answers'    => ogc_json( array(
				'The call-in line held all week; Tuesday’s council had the most callers.',
				'Recording needs came late or never. We didn’t know what we didn’t know.',
				'Keep one list of events with the call-in and recording needs on each row.',
				'Within the budget. Two lapel microphones replaced.',
				'Start the schedule in December, and ask committees for needs by April 1.',
			) ),
			'updated_at' => '2026-07-14 15:00:00',
			'sent_at'    => '2026-07-14 15:00:00',
		) );
	}
}

/** Add the sample people as members (sample = 1), each on their committee. Only what isn't there. */
function ogc_app_seed_people_year( $year ) {
	global $wpdb;
	if ( ! OGC_DEV || ! function_exists( 'ogc_member_find' ) || null === ogc_year_get( (int) $year ) ) {
		return;
	}
	$all = ogc_app_seed_people();
	foreach ( isset( $all[ (int) $year ] ) ? $all[ (int) $year ] : array() as $p ) {
		$email = strtolower( str_replace( ' ', '.', $p[0] ) ) . '@example.com';
		if ( ogc_member_find( (int) $year, $email, true ) ) {
			continue;
		}
		$keys = array_map( 'trim', explode( ',', $p[1] ) );
		$wpdb->insert( ogc_table( 'members' ), array(
			'year'         => (int) $year,
			'email'        => $email,
			'role'         => 'helper',
			'name'         => $p[0],
			'helps'        => implode( ', ', array_map( function ( $k ) use ( $year ) {
				$c = ogc_app_committee( (int) $year, $k );
				return $c ? $c['name'] : $k;
			}, $keys ) ),
			'committees'   => implode( ',', $keys ),
			'head'         => $p[2] ? 1 : 0,
			'invited_at'   => ( (int) $year - 1 ) . '-10-06 15:00:00',
			'signed_in_at' => ( (int) $year - 1 ) . '-10-07 16:00:00',
			'access_years' => 1,
			'sample'       => 1,
			'created_at'   => ogc_now(),
		) );
	}
	ogc_members_cache( true );
}

/** Tasks already past on a local site: done, by a COA sample member (sample only). 2026 is over: all
 * done but most committees' notes and reports; 2027: up to today. */
function ogc_app_seed_done( $year ) {
	global $wpdb;
	$year = (int) $year;
	if ( ! OGC_DEV || ! in_array( $year, array( 2026, 2027 ), true ) || get_option( 'ogc_app_seed_done_' . $year ) ) {
		return;
	}
	if ( 2026 === $year ) {
		$coa = ogc_member_find( 2026, 'owen.fisher@example.com', true );
		$u   = $coa ? ogc_person_for_email( $coa['email'] ) : null;
		foreach ( ogc_app_tasks( 2026 ) as $t ) {
			$after = in_array( $t['title'], array( 'Notes for next year', 'Report to the COA' ), true );
			if ( $t['due'] && $t['due'] < wp_date( 'Y-m-d' ) && ( ! $after || in_array( $t['committee'], array( 'a/v' ), true ) ) ) {
				$wpdb->update( ogc_table( 'tasks' ), array( 'done_at' => $t['due'] . ' 18:00:00', 'done_by' => $u ? (int) $u->ID : 0 ), array( 'id' => $t['id'] ) );
			}
		}
		update_option( 'ogc_app_seed_done_2026', 1, false );
		return;
	}
	$coa = ogc_member_find( 2027, 'nathan.keller@example.com' );
	$u   = $coa ? ogc_person_for_email( $coa['email'] ) : null;
	$by  = $u ? (int) $u->ID : 0;
	$f   = ogc_app_friday( 2027 );
	foreach ( ogc_app_tasks( 2027 ) as $t ) {
		// Up to the first meeting (Nov 1): the foremen named, options asked, the campus tour.
		if ( $t['due'] && $t['due'] < wp_date( 'Y-m-d' ) ) {
			$wpdb->update( ogc_table( 'tasks' ), array( 'done_at' => $t['due'] . ' 18:00:00', 'done_by' => $by ), array( 'id' => $t['id'] ) );
		}
	}
	update_option( 'ogc_app_seed_done_2027', 1, false );
}

/** The whole seed for a year that exists: committees and tasks (carried or started), and on a local
 * site the samples. */
function ogc_app_seed_all() {
	if ( ! ogc_app_tables_ready() ) {
		return;
	}
	foreach ( array( 2026, 2027 ) as $y ) {
		if ( null === ogc_year_get( $y ) ) {
			continue;
		}
		ogc_app_ensure_year( $y );
		if ( OGC_DEV ) {
			ogc_app_seed_people_year( $y );
			ogc_app_seed_samples( $y );
			ogc_app_seed_done( $y );
		}
	}
}

// Once per site (and again when the seed's version changes), after the members' own seed.
add_action( 'init', function () {
	if ( '1' === get_option( 'ogc_app_seeded' ) || ! function_exists( 'ogc_year_get' ) ) {
		return;
	}
	ogc_app_seed_all();
	if ( ogc_app_tables_ready() ) {
		update_option( 'ogc_app_seeded', '1', false );
	}
}, 45 );

// A forced reload of the seed (Pages › Start over) removes the year's sample members: put the app's
// back (the members' own run first, at 10).
add_action( 'ogc_seed_year', function ( $year ) {
	if ( in_array( (int) $year, array( 2026, 2027 ), true ) && ogc_app_tables_ready() ) {
		ogc_app_ensure_year( (int) $year );
		ogc_app_seed_people_year( (int) $year );
	}
}, 20 );

// The members' seed said who heads a committee before the members list kept heads: a local site seeded
// then lost them (Phoebe L. heads Transportation in members.json). Once, sample rows only.
add_action( 'init', function () {
	global $wpdb;
	if ( ! OGC_DEV || get_option( 'ogc_app_seed_heads' ) || ! function_exists( 'ogc_seed_dir' ) ) {
		return;
	}
	$f   = ogc_seed_dir() . 'members.json';
	$all = file_exists( $f ) ? (array) ogc_unjson( file_get_contents( $f ), array() ) : array(); // phpcs:ignore -- a local file.
	foreach ( $all as $year => $list ) {
		foreach ( is_array( $list ) ? $list : array() as $m ) {
			if ( is_array( $m ) && ! empty( $m['head'] ) && ! empty( $m['email'] ) ) {
				$wpdb->query( $wpdb->prepare( 'UPDATE ' . ogc_table( 'members' ) . " SET head = 1 WHERE year = %d AND email = %s AND sample = 1 AND committees <> ''", (int) $year, strtolower( (string) $m['email'] ) ) );
			}
		}
	}
	if ( function_exists( 'ogc_members_cache' ) ) {
		ogc_members_cache( true );
	}
	update_option( 'ogc_app_seed_heads', 1, false );
}, 47 );

/* ------------------------------------------------------------------ the sample households, made true */

/**
 * The sample households (seed/2027/records/registrations.json) as the app's walk-through tells it:
 * registered Feb 26 – Mar 12, 2027, just after registration opens Feb 25 (a preview of Mar 15 shows
 * them all; October 2026 shows none: ogc_records leaves out a sample dated after today), and each with
 * first names of its own (two were "Joy and Eli", three "Esther"). The seed file says the same; this
 * brings a local site seeded before it in line, once. Sample records only.
 */
function ogc_app_sample_households() {
	return array(
		'dates' => array(
			'R-2027-1000' => '2027-02-26', 'R-2027-7109' => '2027-02-26', 'R-2027-4218' => '2027-02-27',
			'R-2027-1327' => '2027-02-28', 'R-2027-7436' => '2027-03-01', 'R-2027-4545' => '2027-03-02',
			'R-2027-1654' => '2027-03-03', 'R-2027-7763' => '2027-03-04', 'R-2027-4872' => '2027-03-06',
			'R-2027-1981' => '2027-03-08', 'R-2027-8090' => '2027-03-10', 'R-2027-5199' => '2027-03-12',
		),
		'names' => array(
			'Joy Fields' => 'Hope Fields', 'Eli Fields' => 'Simon Fields', 'joy.fields' => 'hope.fields',
			'Esther Hale' => 'Dorcas Hale', 'esther.hale' => 'dorcas.hale',
			'Esther Howell' => 'Priscilla Howell', 'esther.howell' => 'priscilla.howell',
		),
	);
}

add_action( 'init', function () {
	global $wpdb;
	if ( ! OGC_DEV || '2' === get_option( 'ogc_app_sample_dates' ) || ! function_exists( 'ogc_records' ) ) {
		return;
	}
	$map  = ogc_app_sample_households();
	$rows = $wpdb->get_results( 'SELECT id, email, data FROM ' . ogc_table( 'records' ) . " WHERE year = 2027 AND kind = 'registrations' AND sample = 1", ARRAY_A ); // phpcs:ignore -- no input.
	foreach ( (array) $rows as $r ) {
		$json  = strtr( (string) $r['data'], $map['names'] );
		$d     = (array) ogc_unjson( $json, array() );
		$id    = isset( $d['id'] ) ? (string) $d['id'] : '';
		if ( isset( $map['dates'][ $id ] ) ) {
			$d['at'] = $map['dates'][ $id ];
			// The site's own copy of when it was registered (the Households list reads it first).
			if ( ! empty( $d['created'] ) ) {
				$d['created'] = $map['dates'][ $id ] . substr( (string) $d['created'], 10 );
			}
		}
		$email = strtr( (string) $r['email'], $map['names'] );
		$wpdb->update( ogc_table( 'records' ), array( 'data' => ogc_json( $d ), 'email' => $email ), array( 'id' => (int) $r['id'] ) );
	}
	update_option( 'ogc_app_sample_dates', '2', false );
}, 48 );

/**
 * 2027's pickup log in the seed came from v3's pickup, which kept no list of what waits for "Looks
 * right". The year area's own pickup keeps one (module-coa-pickup.php): the call-in line, the prices,
 * the carried Help cards. A local site gets the same list once, so 2027 reads as a year really picked
 * up: carried phones and hours aren't public until this year's COA checks them.
 */
function ogc_app_seed_confirm() {
	if ( ! OGC_DEV || ! function_exists( 'ogc_state_get' ) || null === ogc_year_get( 2027 ) ) {
		return;
	}
	$p = ogc_state_get( 2027, 'picked' );
	$v = $p ? (array) $p['value'] : array();
	if ( ! $p || empty( $v['from'] ) ) {
		return;
	}
	$list = isset( $v['confirm'] ) ? (array) $v['confirm'] : array();
	$was  = $list;
	$list = array_merge( $list, array( 'conf:callin', 'reg:prices' ) );
	$help = ogc_file_get( 2027, 'help' );
	foreach ( $help ? (array) $help['rows'] : array() as $h ) {
		if ( ! empty( $h['_id'] ) && '911' !== ( isset( $h['phone'] ) ? (string) $h['phone'] : '' ) && 'emergency' !== ( isset( $h['kind'] ) ? (string) $h['kind'] : '' ) ) {
			$list[] = 'help:' . $h['_id'];
		}
	}
	$list = array_values( array_unique( $list ) );
	if ( $list !== $was ) {
		$v['confirm'] = $list;
		ogc_state_put( 2027, 'picked', $v, $p['version'] );
	}
}
add_action( 'init', function () {
	if ( OGC_DEV && '1' !== get_option( 'ogc_app_seed_confirm' ) ) {
		ogc_app_seed_confirm();
		update_option( 'ogc_app_seed_confirm', '1', false );
	}
}, 48 );
// Pages › Start over reloads 2027's pickup log from the seed: the list again.
add_action( 'ogc_seed_year', function ( $year ) {
	if ( 2027 === (int) $year ) {
		ogc_app_seed_confirm();
	}
}, 25 );
