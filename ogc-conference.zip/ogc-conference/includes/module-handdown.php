<?php
/**
 * The hand-down (night-handdown, Oct 13; docs/23 "The hand-down lives in the system", docs/14 idea 7,
 * scope ch. 6 "The hand-down" and ch. 8 §3). What one year's committee leaves the next, kept with the
 * committee in the app, never in someone's Drive:
 *
 *   Responsibilities   the COA's lines (ogc_committees.duties, module-app.php), unchanged here
 *   How we work        the committee's own standing text: its standards and the usual way (the 2023
 *                      Ushers: "a complete lack of communication on standards… passed on year to
 *                      year"). The committee and the COA write it.
 *   Contacts by role   offices and roles the committee calls (never a volunteer's own phone)
 *   Notes              ogc_cnotes (module-app.php); here: Keep for next year, which copies one of last
 *                      year's notes into this year's (so a standing note reaches the year after)
 *   Files              ogc_cfiles (module-app.php); here: a note on what each is for, Next year
 *                      (whether it's passed on), and Undo for Remove
 *   Report             the COA's questions (ogc_creports), plus Numbers (counts the next committee
 *                      compares) and the contacts: the same shape for every committee
 *
 * How it carries (copy on write, nothing copied on a timer): How we work, Contacts and each file's note
 * are read from this year's row, else from the nearest earlier year that has one, and shown "From 2026"
 * until someone changes them. Never people: no names from an earlier year are shown. Numbers are the
 * year's own (last year's are shown beside them). Files carry by reference as before; one switched off
 * (Next year) stays behind (filter ogc_app_carry_file, module-app.php's carry).
 *
 * Routes (/wp-json/ogc/v1/app/{y}/handdown…, ?c= a committee key, ?as= see-as; DEV.md › The hand-down):
 *   GET              ?c=[&from=2026]   the committee's hand-down (from: a past year, read only, no names)
 *   PUT  how         ?c=  {text}
 *   PUT  contacts    ?c=  {rows:[{id, role, phone, email, note}]}
 *   PUT  numbers     ?c=  {rows:[{id, what, n, note}]}
 *   PATCH file       ?c=  {id, note?, pass?, restore?}
 *   POST keep        ?c=  {id, undo?}       one of last year's notes, kept for next year
 *   GET  export      ?c=&format=xlsx|zip     the committee's hand-down workbook (zip: and its files)
 *   GET  board                               the COA: every committee's hand-down in counts
 *   GET  reports     ?format=xlsx            the COA: every committee's report in one workbook
 * Each asks the app's rule (ogc_app_can_see 'committees' + ogc_app_on_committee); a change is refused
 * while seeing as (403 ogc_read_only) or previewing a date (module-app-needs.php's guard).
 */

defined( 'ABSPATH' ) || exit;

/* ================================================================== the table */

add_filter( 'ogc_schema', 'ogc_hd_schema', 40, 2 );

/**
 * One row per committee per year. A NULL column means "not written this year": the nearest earlier
 * year's is read instead (ogc_hd_field). contacts and numbers are JSON lists; files is JSON keyed by
 * the stored file's random name (fkey), which a carried file shares with the row it was carried from,
 * so a file's note follows it from year to year. questions: the report's questions as they were worded
 * when the committee answered them (JSON list); sent_hash: what the report said when it was sent, so a
 * change after sending shows (both this year's own, never read from another year).
 */
function ogc_hd_schema( $sql, $charset ) {
	$sql[] = 'CREATE TABLE ' . ogc_table( 'handdown' ) . " (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  year smallint(5) unsigned NOT NULL,
  ckey varchar(60) NOT NULL,
  how longtext NULL,
  how_by bigint(20) unsigned NOT NULL DEFAULT 0,
  how_at datetime NULL,
  contacts longtext NULL,
  contacts_by bigint(20) unsigned NOT NULL DEFAULT 0,
  contacts_at datetime NULL,
  numbers longtext NULL,
  numbers_by bigint(20) unsigned NOT NULL DEFAULT 0,
  numbers_at datetime NULL,
  files longtext NULL,
  questions longtext NULL,
  sent_hash varchar(32) NOT NULL DEFAULT '',
  created_at datetime NULL,
  updated_at datetime NULL,
  PRIMARY KEY  (id),
  UNIQUE KEY year_ckey (year,ckey)
) $charset;";
	return $sql;
}

/** Has the table been made (the schema runs on the first request after an update)? */
function ogc_hd_ready() {
	global $wpdb;
	if ( isset( $GLOBALS['ogc_hd_ready'] ) ) {
		return $GLOBALS['ogc_hd_ready'];
	}
	$wpdb->suppress_errors( true );
	$wpdb->get_var( 'SELECT id FROM ' . ogc_table( 'handdown' ) . ' LIMIT 1' ); // phpcs:ignore -- no input.
	$wpdb->suppress_errors( false );
	$GLOBALS['ogc_hd_ready'] = '' === $wpdb->last_error;
	return $GLOBALS['ogc_hd_ready'];
}

/* ================================================================== reading */

/** This year's own row (or null). */
function ogc_hd_row( $year, $ckey ) {
	global $wpdb;
	$k = (int) $year . '|' . $ckey;
	if ( ! array_key_exists( $k, (array) ( isset( $GLOBALS['ogc_hd_rows'] ) ? $GLOBALS['ogc_hd_rows'] : array() ) ) ) {
		$GLOBALS['ogc_hd_rows'][ $k ] = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . ogc_table( 'handdown' ) . ' WHERE year = %d AND ckey = %s', (int) $year, (string) $ckey ), ARRAY_A );
	}
	return $GLOBALS['ogc_hd_rows'][ $k ];
}

function ogc_hd_forget() {
	$GLOBALS['ogc_hd_rows'] = array();
	$GLOBALS['ogc_hd_rep']  = array();
}

/**
 * A field as the year reads it: this year's, else the nearest earlier year's that has it.
 * → array( 'value', 'year' (where it came from), 'by' (user id), 'at' ) or null when no year has it.
 * $field: how | contacts | numbers.
 */
function ogc_hd_field( $year, $ckey, $field, $inherit = true ) {
	global $wpdb;
	if ( ! in_array( $field, array( 'how', 'contacts', 'numbers' ), true ) ) {
		return null;
	}
	$r = $wpdb->get_row( $wpdb->prepare(
		"SELECT year, $field AS v, {$field}_by AS by_id, {$field}_at AS at_t FROM " . ogc_table( 'handdown' ) . " WHERE ckey = %s AND year <= %d AND year >= %d AND $field IS NOT NULL ORDER BY year DESC LIMIT 1",
		(string) $ckey,
		(int) $year,
		$inherit ? 2000 : (int) $year
	), ARRAY_A );
	if ( ! $r ) {
		return null;
	}
	$v = 'how' === $field ? (string) $r['v'] : array_values( (array) ogc_unjson( $r['v'], array() ) );
	return array( 'value' => $v, 'year' => (int) $r['year'], 'by' => (int) $r['by_id'], 'at' => (string) $r['at_t'] );
}

/** Each file's note and Next year switch, by its stored name: earlier years first, this year's last. */
function ogc_hd_files_map( $year, $ckey ) {
	global $wpdb;
	$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT year, files FROM ' . ogc_table( 'handdown' ) . ' WHERE ckey = %s AND year <= %d AND files IS NOT NULL ORDER BY year ASC', (string) $ckey, (int) $year ), ARRAY_A );
	$map  = array();
	foreach ( (array) $rows as $r ) {
		foreach ( (array) ogc_unjson( $r['files'], array() ) as $fk => $o ) {
			$map[ (string) $fk ] = array_merge( isset( $map[ $fk ] ) ? $map[ $fk ] : array(), (array) $o, array( 'year' => (int) $r['year'] ) );
		}
	}
	return $map;
}

/** Is a file passed on to next year when nobody has said? (As built: yes. docs/scope 08 Q17 suggests
 * no, with a tick; the filter turns it.) */
function ogc_hd_pass_default() {
	return (bool) apply_filters( 'ogc_hd_pass_default', true );
}

/** Will this file (a row of ogc_cfiles) go on to next year? */
function ogc_hd_file_passes( $f ) {
	$map = ogc_hd_files_map( (int) $f['year'], (string) $f['ckey'] );
	$fk  = (string) $f['fkey'];
	return isset( $map[ $fk ]['pass'] ) ? (bool) $map[ $fk ]['pass'] : ogc_hd_pass_default();
}

// The carry (module-app.php) asks before it carries each file: not one switched off, and not one
// already passed on as it was uploaded (ogc_hd_file_sync).
add_filter( 'ogc_app_carry_file', function ( $carry, $f, $from = 0, $to = 0 ) {
	global $wpdb;
	if ( ! $carry || ! ogc_hd_ready() ) {
		return $carry;
	}
	if ( $to && (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM ' . ogc_table( 'cfiles' ) . ' WHERE year = %d AND carried_from = %d', (int) $to, (int) $f['id'] ) ) ) {
		return false;
	}
	return ogc_hd_file_passes( $f );
}, 10, 4 );

/**
 * The next Conference after $year that this committee is in, carried from $year (0 when there's none
 * yet). Its files have come (true) or wait for $year to be over (false): a year started early carries
 * the files once the one before is over (module-app.php, ogc_app_carry_rest).
 */
function ogc_hd_next_of( $year, $ckey ) {
	global $wpdb;
	$n = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT MIN(year) FROM ' . ogc_table( 'committees' ) . ' WHERE year > %d AND removed_at IS NULL', (int) $year ) );
	if ( ! $n || ogc_app_prev_year( $n ) !== (int) $year ) {
		return array( 0, false );
	}
	$c = ogc_app_committee( $n, $ckey );
	if ( ! $c || (int) $c['from_year'] !== (int) $year ) {
		return array( 0, false );
	}
	$st = function_exists( 'ogc_state_get' ) ? ogc_state_get( $n, 'app-carry' ) : null;
	$v  = $st ? (array) $st['value'] : array();
	return array( $n, empty( $v['partial'] ) || ! empty( $v['rest'] ) );
}

/**
 * Keep next year's copy of a file true to the switch, after the next year has been started (Michael's
 * COA starts 2028 long before 2027 is over). A file uploaded now, or switched on, goes to next year at
 * once (by reference, "From 2026"); one switched off or removed leaves next year, unless next year's
 * committee has made it theirs (a note or a switch of its own there). $apply false: only say where it
 * stands. → array( 'next' => year or 0, 'state' => '' | 'later' | 'in' | 'off' | 'theirs' | 'gone' )
 *   ''       no next year started yet: it goes when the year is started (if Next year is on)
 *   later    next year started early: it goes once this year is over
 *   in       in next year's files now
 *   off      stays with this year
 *   theirs   switched off here, but next year's committee has made it theirs: still there
 *   gone     on here, but next year's committee removed it there
 */
function ogc_hd_file_sync( $id, $apply = true ) {
	global $wpdb;
	$f = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . ogc_table( 'cfiles' ) . ' WHERE id = %d', (int) $id ), ARRAY_A );
	if ( ! $f ) {
		return array( 'next' => 0, 'state' => '' );
	}
	$y = (int) $f['year'];
	$k = (string) $f['ckey'];
	list( $n, $carried ) = ogc_hd_next_of( $y, $k );
	$want = empty( $f['removed_at'] ) && ogc_hd_file_passes( $f );
	if ( ! $n ) {
		return array( 'next' => 0, 'state' => $want ? '' : 'off' );
	}
	if ( ! $carried ) {
		return array( 'next' => $n, 'state' => $want ? 'later' : 'off' );
	}
	$copy = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . ogc_table( 'cfiles' ) . ' WHERE year = %d AND carried_from = %d ORDER BY id DESC LIMIT 1', $n, (int) $f['id'] ), ARRAY_A );
	$mine = (array) ogc_hd_files_map( $y, $k );
	$off  = isset( $mine[ $f['fkey'] ][ 'off_' . $n ] ) ? (int) $mine[ $f['fkey'] ][ 'off_' . $n ] : 0;
	if ( $want ) {
		if ( $copy && empty( $copy['removed_at'] ) ) {
			return array( 'next' => $n, 'state' => 'in' );
		}
		if ( $copy && (int) $copy['id'] !== $off ) {
			// Next year's committee removed it there itself: theirs to put back.
			return array( 'next' => $n, 'state' => 'gone' );
		}
		if ( $apply ) {
			if ( $copy ) {
				$wpdb->update( ogc_table( 'cfiles' ), array( 'removed_at' => null ), array( 'id' => (int) $copy['id'] ) );
			} else {
				$wpdb->insert( ogc_table( 'cfiles' ), array(
					'year'         => $n,
					'ckey'         => $k,
					'name'         => $f['name'],
					'fkey'         => $f['fkey'],
					'mime'         => $f['mime'],
					'size'         => (int) $f['size'],
					'uploaded_by'  => (int) $f['uploaded_by'],
					'carried_from' => (int) $f['id'],
					'created_at'   => $f['created_at'],
				) );
			}
			if ( $off ) {
				ogc_hd_put_file( $y, $k, (string) $f['fkey'], array( 'off_' . $n => 0 ) );
			}
		}
		return array( 'next' => $n, 'state' => $apply ? 'in' : 'later' );
	}
	if ( ! $copy || ! empty( $copy['removed_at'] ) ) {
		return array( 'next' => $n, 'state' => 'off' );
	}
	// Has next year's committee made it theirs (its own note or switch on its own row)?
	$own    = ogc_hd_row( $n, $k );
	$theirs = $own && null !== $own['files'] && array_key_exists( (string) $f['fkey'], (array) ogc_unjson( $own['files'], array() ) );
	if ( $theirs ) {
		return array( 'next' => $n, 'state' => 'theirs' );
	}
	if ( $apply ) {
		$wpdb->update( ogc_table( 'cfiles' ), array( 'removed_at' => ogc_now() ), array( 'id' => (int) $copy['id'] ) );
		ogc_hd_put_file( $y, $k, (string) $f['fkey'], array( 'off_' . $n => (int) $copy['id'] ) );
		return array( 'next' => $n, 'state' => 'off' );
	}
	return array( 'next' => $n, 'state' => 'in' );
}

// A file uploaded or removed (module-app-rest.php's routes): next year's copy follows, once next year
// has been started and its files have come.
add_filter( 'rest_request_after_callbacks', function ( $res, $handler, $req ) {
	if ( is_wp_error( $res ) || ! ( $req instanceof WP_REST_Request ) || ! ogc_hd_ready() ) {
		return $res;
	}
	$route = (string) $req->get_route();
	$data  = $res instanceof WP_REST_Response ? $res->get_data() : $res;
	if ( 'POST' === $req->get_method() && preg_match( '#^/' . preg_quote( OGC_NS, '#' ) . '/app/\d{4}/committee/files$#', $route ) && is_array( $data ) && ! empty( $data['id'] ) ) {
		ogc_hd_file_sync( (int) $data['id'] );
	} elseif ( 'DELETE' === $req->get_method() && preg_match( '#^/' . preg_quote( OGC_NS, '#' ) . '/app/files/(\d+)$#', $route, $m ) && is_array( $data ) && ! empty( $data['removed'] ) ) {
		ogc_hd_file_sync( (int) $m[1] );
	} elseif ( 'PUT' === $req->get_method() && preg_match( '#^/' . preg_quote( OGC_NS, '#' ) . '/app/(\d{4})/committee/report$#', $route, $m ) && is_array( $data ) ) {
		ogc_hd_report_saved( (int) $m[1], ogc_app_c( $req ), (bool) $req->get_param( 'send' ) );
	}
	return $res;
}, 10, 3 );

/**
 * A report saved (module-app-rest.php's route): keep the questions' wording it was answered under, and,
 * when it was sent, what it said (so a change after sending shows as "Changed since sending").
 */
function ogc_hd_report_saved( $y, $k, $sent ) {
	if ( '' === $k || ! ogc_app_committee( $y, $k ) ) {
		return;
	}
	$set = array();
	$q   = ogc_hd_json_list( ogc_app_report_questions( $y ) );
	$own = ogc_hd_row( $y, $k );
	if ( ! $own || (string) $own['questions'] !== $q ) {
		$set['questions'] = $q;
	}
	if ( $sent ) {
		$r               = ogc_app_report( $y, $k );
		$n               = ogc_hd_field( $y, $k, 'numbers', false );
		$set['sent_hash'] = ogc_hd_report_hash( $r ? $r['answers'] : array(), $n ? $n['value'] : array() );
	}
	if ( $set ) {
		ogc_hd_put( $y, $k, $set );
	}
}

function ogc_hd_json_list( $a ) {
	return (string) ogc_json( array_values( array_map( 'strval', (array) $a ) ) );
}

/** The year a carried file was first uploaded (following carried_from back). */
function ogc_hd_file_origin( $id ) {
	global $wpdb;
	$year = 0;
	for ( $i = 0; $i < 8 && $id; $i++ ) {
		$r = $wpdb->get_row( $wpdb->prepare( 'SELECT year, carried_from FROM ' . ogc_table( 'cfiles' ) . ' WHERE id = %d', (int) $id ), ARRAY_A );
		if ( ! $r ) {
			break;
		}
		$year = (int) $r['year'];
		$id   = (int) $r['carried_from'];
	}
	return $year;
}

/** A committee's files in a year with their hand-down: note, Next year, where from. Removed ones too
 * when $removed (for Undo). */
function ogc_hd_files( $year, $ckey, $removed = false ) {
	global $wpdb;
	$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . ogc_table( 'cfiles' ) . ' WHERE year = %d AND ckey = %s' . ( $removed ? '' : ' AND removed_at IS NULL' ) . ' ORDER BY id DESC', (int) $year, (string) $ckey ), ARRAY_A );
	$map  = ogc_hd_files_map( $year, $ckey );
	$out  = array();
	foreach ( (array) $rows as $f ) {
		$fk    = (string) $f['fkey'];
		$o     = isset( $map[ $fk ] ) ? $map[ $fk ] : array();
		$out[] = array(
			'id'      => (int) $f['id'],
			'name'    => (string) $f['name'],
			'type'    => strtoupper( (string) pathinfo( $f['name'], PATHINFO_EXTENSION ) ),
			'size'    => (int) $f['size'],
			'by_id'   => (int) $f['uploaded_by'],
			'at'      => (string) $f['created_at'],
			'from'    => (int) $f['carried_from'] ? ogc_hd_file_origin( (int) $f['carried_from'] ) : 0,
			'note'    => isset( $o['note'] ) ? (string) $o['note'] : '',
			'pass'    => isset( $o['pass'] ) ? (bool) $o['pass'] : ogc_hd_pass_default(),
			'removed' => ! empty( $f['removed_at'] ),
			'fkey'    => $fk,
		);
	}
	return $out;
}

/**
 * What a report says, as one fingerprint: its answers and this year's own numbers (label and number).
 * Kept when it's sent (sent_hash), so a change after sending shows.
 */
function ogc_hd_report_hash( $answers, $numbers ) {
	$a = array_values( array_map( function ( $x ) {
		return trim( (string) $x );
	}, (array) $answers ) );
	while ( $a && '' === end( $a ) ) {
		array_pop( $a );
	}
	$n = array();
	foreach ( (array) $numbers as $x ) {
		$n[] = array( strtolower( trim( (string) $x['what'] ) ), (string) $x['n'] );
	}
	return md5( wp_json_encode( array( $a, $n ) ) );
}

/**
 * A report's own row: status none | draft | sent | changed, and dates (ISO, campus day). One rule for
 * the page, the COA's board and the workbooks: started when an answer or a number is written; sent when
 * it was sent; changed when its answers or numbers differ from what was sent (it still counts as in).
 */
function ogc_hd_report_row( $year, $ckey ) {
	global $wpdb;
	$k = (int) $year . '|' . $ckey;
	if ( isset( $GLOBALS['ogc_hd_rep'][ $k ] ) ) {
		return $GLOBALS['ogc_hd_rep'][ $k ];
	}
	$r    = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . ogc_table( 'creports' ) . ' WHERE year = %d AND ckey = %s', (int) $year, (string) $ckey ), ARRAY_A );
	$num  = ogc_hd_ready() ? ogc_hd_field( $year, $ckey, 'numbers', false ) : null;
	$nums = $num ? $num['value'] : array();
	$has  = (bool) array_filter( $nums, function ( $x ) {
		return '' !== (string) $x['n'];
	} );
	$ans  = $r ? array_values( array_map( 'strval', (array) ogc_unjson( $r['answers'], array() ) ) ) : array();
	$said = (bool) array_filter( $ans, function ( $x ) {
		return '' !== trim( $x );
	} );
	$day  = function ( $t ) {
		return $t ? wp_date( 'Y-m-d', strtotime( $t . ' UTC' ) ) : '';
	};
	$status = $said || $has ? 'draft' : 'none';
	if ( $r && $r['sent_at'] ) {
		$own  = ogc_hd_ready() ? ogc_hd_row( $year, $ckey ) : null;
		$hash = $own && ! empty( $own['sent_hash'] ) ? (string) $own['sent_hash'] : '';
		if ( '' !== $hash ) {
			$changed = ogc_hd_report_hash( $ans, $nums ) !== $hash;
		} else {
			// Sent before the fingerprint was kept: changed when saved again after sending.
			$sent    = strtotime( $r['sent_at'] . ' UTC' );
			$changed = ( $r['updated_at'] && strtotime( $r['updated_at'] . ' UTC' ) > $sent + 2 ) || ( $num && $num['at'] && strtotime( $num['at'] . ' UTC' ) > $sent + 2 );
		}
		$status = $changed ? 'changed' : 'sent';
	}
	return $GLOBALS['ogc_hd_rep'][ $k ] = array(
		'status'  => $status,
		'answers' => $ans,
		'sent'    => $r ? $day( $r['sent_at'] ) : '',
		'updated' => $r ? $day( $r['updated_at'] ) : '',
	);
}

/** Is the report in (sent, or sent and changed since)? */
function ogc_hd_report_in( $status ) {
	return 'sent' === $status || 'changed' === $status;
}

/** "Not started" · "Draft" · "Sent" · "Changed since sending" (the register's words, scope ch. 6). */
function ogc_hd_status_word( $s ) {
	return 'sent' === $s ? 'Sent' : ( 'changed' === $s ? 'Changed since sending' : ( 'draft' === $s ? 'Draft' : 'Not started' ) );
}

/**
 * The report's questions as the committee answered them: the wording kept with its report, else the
 * year's questions as they read now (a report written before the wording was kept).
 */
function ogc_hd_questions( $year, $ckey ) {
	$own = ogc_hd_ready() ? ogc_hd_row( $year, $ckey ) : null;
	if ( $own && null !== $own['questions'] && '' !== (string) $own['questions'] ) {
		$q = array_values( array_map( 'strval', (array) ogc_unjson( $own['questions'], array() ) ) );
		if ( $q ) {
			return $q;
		}
	}
	return ogc_app_report_questions( $year );
}

/* ================================================================== cleaning what's typed */

function ogc_hd_line( $t, $max ) {
	$t = trim( sanitize_text_field( (string) $t ) );
	return function_exists( 'mb_substr' ) ? mb_substr( $t, 0, $max ) : substr( $t, 0, $max );
}

function ogc_hd_rid( $id ) {
	$id = (string) $id;
	return preg_match( '/^[a-z0-9]{6,16}$/', $id ) ? $id : substr( bin2hex( random_bytes( 6 ) ), 0, 10 );
}

/** Contacts by role: role (needed), phone, email, note. → list, or WP_Error naming the row. */
function ogc_hd_clean_contacts( $rows ) {
	$out = array();
	foreach ( array_slice( array_values( (array) $rows ), 0, 40 ) as $i => $r ) {
		$r     = (array) $r;
		$role  = ogc_hd_line( isset( $r['role'] ) ? $r['role'] : '', 80 );
		$phone = ogc_hd_line( isset( $r['phone'] ) ? $r['phone'] : '', 40 );
		$email = strtolower( trim( (string) ( isset( $r['email'] ) ? $r['email'] : '' ) ) );
		$note  = ogc_hd_line( isset( $r['note'] ) ? $r['note'] : '', 200 );
		if ( '' === $role && '' === $phone && '' === $email && '' === $note ) {
			continue;
		}
		if ( '' === $role ) {
			return new WP_Error( 'ogc_bad', 'Role needed', array( 'status' => 400, 'row' => $i, 'field' => 'role' ) );
		}
		// A number, with an extension when there is one: "765-555-0140 ext. 12", "x12", "#12".
		if ( '' !== $phone && ! preg_match( '/^[0-9+().\s\/-]{3,30}(?:\s*(?:ext\.?|x|#)\s*[0-9]{1,6})?$/i', $phone ) ) {
			return new WP_Error( 'ogc_bad', 'Phone · Numbers and ext. only', array( 'status' => 400, 'row' => $i, 'field' => 'phone' ) );
		}
		if ( '' !== $email && ! is_email( $email ) ) {
			return new WP_Error( 'ogc_bad', 'Email not valid', array( 'status' => 400, 'row' => $i, 'field' => 'email' ) );
		}
		$out[] = array( 'id' => ogc_hd_rid( isset( $r['id'] ) ? $r['id'] : '' ), 'role' => $role, 'phone' => $phone, 'email' => $email, 'note' => $note );
	}
	return $out;
}

/** Numbers: what (needed), n (a number, or blank while it isn't known), note. */
function ogc_hd_clean_numbers( $rows ) {
	$out = array();
	foreach ( array_slice( array_values( (array) $rows ), 0, 30 ) as $i => $r ) {
		$r    = (array) $r;
		$what = ogc_hd_line( isset( $r['what'] ) ? $r['what'] : '', 80 );
		$n    = str_replace( array( ',', ' ' ), '', trim( (string) ( isset( $r['n'] ) ? $r['n'] : '' ) ) );
		$note = ogc_hd_line( isset( $r['note'] ) ? $r['note'] : '', 120 );
		if ( '' === $what && '' === $n ) {
			continue;
		}
		if ( '' === $what ) {
			return new WP_Error( 'ogc_bad', 'Name the number', array( 'status' => 400, 'row' => $i, 'field' => 'what' ) );
		}
		if ( '' !== $n && ( ! is_numeric( $n ) || abs( (float) $n ) > 1e9 ) ) {
			return new WP_Error( 'ogc_bad', 'A number only', array( 'status' => 400, 'row' => $i, 'field' => 'n' ) );
		}
		$out[] = array( 'id' => ogc_hd_rid( isset( $r['id'] ) ? $r['id'] : '' ), 'what' => $what, 'n' => '' === $n ? '' : (string) ( 0 + $n ), 'note' => $note );
	}
	return $out;
}

/* ================================================================== writing */

/** Set columns on this year's row (made when it isn't there). */
function ogc_hd_put( $year, $ckey, $set ) {
	global $wpdb;
	$row               = ogc_hd_row( $year, $ckey );
	$set['updated_at'] = ogc_now();
	if ( $row ) {
		$wpdb->update( ogc_table( 'handdown' ), $set, array( 'id' => (int) $row['id'] ) );
	} else {
		$wpdb->insert( ogc_table( 'handdown' ), array_merge( $set, array( 'year' => (int) $year, 'ckey' => (string) $ckey, 'created_at' => ogc_now() ) ) );
	}
	ogc_hd_forget();
}

/** Set one file's hand-down on this year's row: note and/or pass. */
function ogc_hd_put_file( $year, $ckey, $fkey, $o ) {
	$row = ogc_hd_row( $year, $ckey );
	$all = $row && null !== $row['files'] ? (array) ogc_unjson( $row['files'], array() ) : array();
	$cur = isset( $all[ $fkey ] ) ? (array) $all[ $fkey ] : array();
	// What an earlier year said stays the starting point (a note written in 2026 is still the note).
	if ( ! $cur ) {
		$map = ogc_hd_files_map( $year, $ckey );
		if ( isset( $map[ $fkey ] ) ) {
			$cur = array_intersect_key( $map[ $fkey ], array( 'note' => 1, 'pass' => 1 ) );
		}
	}
	$all[ $fkey ] = array_merge( $cur, $o );
	ogc_hd_put( $year, $ckey, array( 'files' => ogc_json( $all ) ) );
}

/* ================================================================== routes */

add_action( 'rest_api_init', 'ogc_hd_routes' );

/** May this request read (or write) a committee's hand-down? $coa: the COA's own routes (board). */
function ogc_hd_perm( $write, $coa = false ) {
	return function ( WP_REST_Request $req ) use ( $write, $coa ) {
		$y = (int) $req['year'];
		if ( ! function_exists( 'ogc_app_tables_ready' ) || ! ogc_app_tables_ready() || ! ogc_hd_ready() || null === ogc_year_get( $y ) ) {
			return new WP_Error( 'ogc_not_found', 'Not found.', array( 'status' => 404 ) );
		}
		$v = ogc_app_req_viewer( $req );
		if ( ! ogc_app_can_see( $v, 'committees' ) ) {
			return ogc_rest_denied();
		}
		if ( $coa ) {
			if ( ! $v['coa'] ) {
				return ogc_rest_denied();
			}
		} else {
			$k = ogc_app_c( $req );
			// Someone else's committee reads as missing, so what it keeps isn't given away.
			if ( '' === $k || ! ogc_app_committee( $y, $k ) || ! ogc_app_on_committee( $v, $k ) ) {
				return new WP_Error( 'ogc_not_found', 'Not found.', array( 'status' => 404 ) );
			}
		}
		if ( $write && $v['as'] ) {
			return new WP_Error( 'ogc_read_only', 'Read only while seeing as', array( 'status' => 403 ) );
		}
		return true;
	};
}

function ogc_hd_routes() {
	$Y = '(?P<year>\d{4})';
	$r = array(
		"/app/$Y/handdown"          => array( 'GET', 'ogc_hd_rest_get', ogc_hd_perm( false ) ),
		"/app/$Y/handdown/how"      => array( 'PUT', 'ogc_hd_rest_how', ogc_hd_perm( true ) ),
		"/app/$Y/handdown/contacts" => array( 'PUT', 'ogc_hd_rest_contacts', ogc_hd_perm( true ) ),
		"/app/$Y/handdown/numbers"  => array( 'PUT', 'ogc_hd_rest_numbers', ogc_hd_perm( true ) ),
		"/app/$Y/handdown/file"     => array( 'PATCH', 'ogc_hd_rest_file', ogc_hd_perm( true ) ),
		"/app/$Y/handdown/keep"     => array( 'POST', 'ogc_hd_rest_keep', ogc_hd_perm( true ) ),
		"/app/$Y/handdown/export"   => array( 'GET', 'ogc_hd_rest_export', ogc_hd_perm( false ) ),
		"/app/$Y/handdown/board"    => array( 'GET', 'ogc_hd_rest_board', ogc_hd_perm( false, true ) ),
		"/app/$Y/handdown/reports"  => array( 'GET', 'ogc_hd_rest_reports', ogc_hd_perm( false, true ) ),
	);
	foreach ( $r as $path => $d ) {
		register_rest_route( OGC_NS, $path, array( 'methods' => $d[0], 'callback' => $d[1], 'permission_callback' => $d[2] ) );
	}
}

/** Who wrote it and when, in the app's words ("Aaron W. · Oct 3"), only for this year's own. */
function ogc_hd_by_on( $f, $year ) {
	if ( ! $f || (int) $f['year'] !== (int) $year ) {
		return array( 'by' => '', 'on' => '' );
	}
	return array(
		'by' => $f['by'] ? ogc_app_user_name( (int) $f['by'], (int) $year ) : '',
		'on' => $f['at'] ? ogc_app_md( wp_date( 'Y-m-d', strtotime( $f['at'] . ' UTC' ) ), (int) $year ) : '',
	);
}

/** The kinds of file a committee may keep, in words, and the size limit. */
function ogc_hd_file_rules() {
	$max = (int) apply_filters( 'ogc_app_file_max', 20 * MB_IN_BYTES );
	return array(
		'max'   => $max,
		'words' => 'PDF, Word, Excel, pictures · ' . size_format( $max ) . ' each',
		'accept' => implode( ',', array_map( function ( $e ) {
			return '.' . $e;
		}, array_keys( ogc_app_file_types() ) ) ),
	);
}

/**
 * GET: a committee's hand-down for the page. With ?from=2026 (an earlier year than the address's), that
 * year read only and without names, for the Past years view.
 */
function ogc_hd_rest_get( WP_REST_Request $req ) {
	$y    = (int) $req['year'];
	$k    = ogc_app_c( $req );
	$v    = ogc_app_req_viewer( $req );
	$from = (int) $req->get_param( 'from' );
	if ( $from ) {
		if ( $from >= $y || ! ogc_valid_year( $from ) || ! ogc_app_committee( $from, $k ) ) {
			return new WP_Error( 'ogc_not_found', 'Not found.', array( 'status' => 404 ) );
		}
		return rest_ensure_response( ogc_hd_payload( $from, $k, null ) );
	}
	return rest_ensure_response( ogc_hd_payload( $y, $k, $v ) );
}

/**
 * A year's notes that were kept from an earlier year's (source kept:<id>): id → where the words were
 * first written (year, and the day as "Jul 1, 2026"), following a note kept more than once back to the
 * first.
 */
function ogc_hd_kept_notes( $year, $ckey ) {
	global $wpdb;
	$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT id, source FROM ' . ogc_table( 'cnotes' ) . " WHERE year = %d AND ckey = %s AND removed_at IS NULL AND source LIKE 'kept:%%'", (int) $year, (string) $ckey ), ARRAY_A );
	$out  = array();
	foreach ( (array) $rows as $r ) {
		$src = (int) substr( (string) $r['source'], 5 );
		$at  = null;
		for ( $i = 0, $id = $src; $i < 8 && $id; $i++ ) {
			$n = $wpdb->get_row( $wpdb->prepare( 'SELECT id, year, source, created_at FROM ' . ogc_table( 'cnotes' ) . ' WHERE id = %d', $id ), ARRAY_A );
			if ( ! $n ) {
				break;
			}
			$at = $n;
			$id = 0 === strpos( (string) $n['source'], 'kept:' ) ? (int) substr( (string) $n['source'], 5 ) : 0;
		}
		if ( $at ) {
			$out[ (int) $r['id'] ] = array(
				'src'  => $src,
				'year' => (int) $at['year'],
				'on'   => $at['created_at'] ? wp_date( 'M j, Y', strtotime( $at['created_at'] . ' UTC' ) ) : '',
			);
		}
	}
	return $out;
}

/** The hand-down as the page draws it. $v null: a past year, read only, no names. */
function ogc_hd_payload( $y, $k, $v ) {
	$prev  = ogc_app_prev_year( $y );
	$past  = null === $v;
	$write = ! $past && ! $v['as'];
	$how   = ogc_hd_field( $y, $k, 'how' );
	$con   = ogc_hd_field( $y, $k, 'contacts' );
	$num   = ogc_hd_field( $y, $k, 'numbers', false );
	$lastn = $prev ? ogc_hd_field( $prev, $k, 'numbers', false ) : null;
	$files = array();
	$next  = $past ? array( 0, false ) : ogc_hd_next_of( $y, $k );
	foreach ( ogc_hd_files( $y, $k ) as $f ) {
		$files[ $f['id'] ] = array( 'note' => $f['note'], 'pass' => $f['pass'], 'from' => $f['from'], 'next' => $past ? '' : ogc_hd_file_sync( $f['id'], false )['state'] );
	}
	// Which of last year's notes this year's committee has kept for next year.
	$kept = array();
	if ( ! $past && $prev ) {
		global $wpdb;
		$src = $wpdb->get_col( $wpdb->prepare( 'SELECT source FROM ' . ogc_table( 'cnotes' ) . " WHERE year = %d AND ckey = %s AND removed_at IS NULL AND source LIKE 'kept:%%'", $y, $k ) );
		foreach ( (array) $src as $s ) {
			$kept[ (int) substr( (string) $s, 5 ) ] = true;
		}
	}
	// Notes kept from an earlier year's (this year's and last year's): where each was first written.
	$origin = array();
	foreach ( $past ? array() : array_filter( array( $y, $prev ) ) as $ny ) {
		foreach ( ogc_hd_kept_notes( $ny, $k ) as $id => $o ) {
			$origin[ $id ] = $o;
		}
	}
	$rep  = ogc_hd_report_row( $y, $k );
	$name = function ( $f ) use ( $y, $past ) {
		return $past ? array( 'by' => '', 'on' => '' ) : ogc_hd_by_on( $f, $y );
	};
	return array(
		'year'     => (int) $y,
		'key'      => $k,
		'prev'     => $prev,
		'how'      => array_merge( array( 'text' => $how ? $how['value'] : '', 'from' => $how && $how['year'] !== (int) $y ? $how['year'] : 0 ), $name( $how ) ),
		'contacts' => array_merge( array( 'rows' => $con ? $con['value'] : array(), 'from' => $con && $con['year'] !== (int) $y ? $con['year'] : 0 ), $name( $con ) ),
		'numbers'  => array_merge( array(
			// Saved (even as an empty list) or never: last year's labels fill only a list never saved.
			'saved' => (bool) $num,
			'rows' => $num ? $num['value'] : array(),
			'last' => $lastn ? array_values( array_map( function ( $n ) {
				return array( 'what' => $n['what'], 'n' => $n['n'] );
			}, $lastn['value'] ) ) : array(),
		), $name( $num ) ),
		'files'    => (object) $files,
		'file'     => ogc_hd_file_rules(),
		'kept'     => (object) $kept,
		'origin'   => (object) $origin,
		'next_year' => $next[0],
		'report'   => array( 'status' => $rep['status'], 'word' => ogc_hd_status_word( $rep['status'] ), 'sent' => $rep['sent'] ? ogc_app_md( $rep['sent'], $y ) : '' ),
		// The questions as they were asked: this year's report's, and last year's (read under its own).
		'questions'      => ogc_hd_questions( $y, $k ),
		'last_questions' => $prev ? ogc_hd_questions( $prev, $k ) : array(),
		'can'      => array(
			'write' => $write,
			'how'   => $write,
			'numbers' => $write && 'coa' !== $k,
		),
	);
}

function ogc_hd_rest_how( WP_REST_Request $req ) {
	$y    = (int) $req['year'];
	$k    = ogc_app_c( $req );
	$text = rtrim( ogc_app_clean_text( $req->get_param( 'text' ), 6000 ) );
	ogc_hd_put( $y, $k, array( 'how' => $text, 'how_by' => get_current_user_id(), 'how_at' => ogc_now() ) );
	ogc_log( 'app_hd_how', $y, 'committee:' . $k, array( 'ckey' => $k ) );
	return rest_ensure_response( ogc_hd_payload( $y, $k, ogc_app_req_viewer( $req ) ) );
}

function ogc_hd_rest_contacts( WP_REST_Request $req ) {
	$y    = (int) $req['year'];
	$k    = ogc_app_c( $req );
	$rows = ogc_hd_clean_contacts( $req->get_param( 'rows' ) );
	if ( is_wp_error( $rows ) ) {
		return $rows;
	}
	ogc_hd_put( $y, $k, array( 'contacts' => ogc_json( $rows ), 'contacts_by' => get_current_user_id(), 'contacts_at' => ogc_now() ) );
	ogc_log( 'app_hd_contacts', $y, 'committee:' . $k, array( 'ckey' => $k, 'n' => count( $rows ) ) );
	return rest_ensure_response( ogc_hd_payload( $y, $k, ogc_app_req_viewer( $req ) ) );
}

function ogc_hd_rest_numbers( WP_REST_Request $req ) {
	$y = (int) $req['year'];
	$k = ogc_app_c( $req );
	if ( 'coa' === $k ) {
		return ogc_rest_denied();
	}
	$rows = ogc_hd_clean_numbers( $req->get_param( 'rows' ) );
	if ( is_wp_error( $rows ) ) {
		return $rows;
	}
	ogc_hd_put( $y, $k, array( 'numbers' => ogc_json( $rows ), 'numbers_by' => get_current_user_id(), 'numbers_at' => ogc_now() ) );
	// Typed as the report is: one line in the log a day is enough (the report's own Sent is the act).
	if ( ! ogc_throttle( 'app_hd_numbers:' . $y . ':' . $k . ':' . get_current_user_id(), 1, DAY_IN_SECONDS ) ) {
		ogc_log( 'app_hd_numbers', $y, 'committee:' . $k, array( 'ckey' => $k ) );
	}
	return rest_ensure_response( ogc_hd_payload( $y, $k, ogc_app_req_viewer( $req ) ) );
}

/** One file: its note, Next year, or putting back a removed one (Undo). */
function ogc_hd_rest_file( WP_REST_Request $req ) {
	global $wpdb;
	$y = (int) $req['year'];
	$k = ogc_app_c( $req );
	$f = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . ogc_table( 'cfiles' ) . ' WHERE id = %d AND year = %d AND ckey = %s', (int) $req->get_param( 'id' ), $y, $k ), ARRAY_A );
	if ( ! $f ) {
		return new WP_Error( 'ogc_not_found', 'Not found.', array( 'status' => 404 ) );
	}
	if ( $req->get_param( 'restore' ) ) {
		if ( empty( $f['removed_at'] ) ) {
			return new WP_Error( 'ogc_bad', 'Not removed', array( 'status' => 400 ) );
		}
		// Undo is for a slip: within a day of the Remove.
		if ( strtotime( $f['removed_at'] . ' UTC' ) < time() - DAY_IN_SECONDS ) {
			return new WP_Error( 'ogc_late', 'Removed too long ago · Upload it again', array( 'status' => 409 ) );
		}
		$wpdb->update( ogc_table( 'cfiles' ), array( 'removed_at' => null ), array( 'id' => (int) $f['id'] ) );
		ogc_log( 'app_hd_file_back', $y, 'committee:' . $k, array( 'ckey' => $k, 'title' => substr( (string) $f['name'], 0, 80 ) ) );
		// Back in next year's files too, when its removal took it from there.
		$sync = ogc_hd_file_sync( (int) $f['id'] );
		return rest_ensure_response( array( 'id' => (int) $f['id'], 'restored' => true, 'next' => $sync['next'], 'state' => $sync['state'] ) );
	}
	if ( ! empty( $f['removed_at'] ) ) {
		return new WP_Error( 'ogc_not_found', 'Not found.', array( 'status' => 404 ) );
	}
	$o = array();
	if ( null !== $req->get_param( 'note' ) ) {
		$o['note'] = ogc_hd_line( $req->get_param( 'note' ), 160 );
	}
	if ( null !== $req->get_param( 'pass' ) ) {
		$o['pass'] = rest_sanitize_boolean( $req->get_param( 'pass' ) ) ? 1 : 0;
	}
	if ( ! $o ) {
		return new WP_Error( 'ogc_bad', 'Nothing to change.', array( 'status' => 400 ) );
	}
	ogc_hd_put_file( $y, $k, (string) $f['fkey'], $o );
	ogc_log( 'app_hd_file', $y, 'committee:' . $k, array( 'ckey' => $k, 'fields' => array_keys( $o ) ) );
	// Next year's copy follows the switch (when next year has been started).
	$sync = isset( $o['pass'] ) ? ogc_hd_file_sync( (int) $f['id'] ) : ogc_hd_file_sync( (int) $f['id'], false );
	$map  = ogc_hd_files_map( $y, $k );
	$m    = isset( $map[ $f['fkey'] ] ) ? $map[ $f['fkey'] ] : array();
	return rest_ensure_response( array(
		'id'    => (int) $f['id'],
		'note'  => isset( $m['note'] ) ? (string) $m['note'] : '',
		'pass'  => isset( $m['pass'] ) ? (bool) $m['pass'] : ogc_hd_pass_default(),
		'next'  => $sync['next'],
		'state' => $sync['state'],
	) );
}

/**
 * Keep one of last year's notes for next year: it's copied into this year's notes (so the committee
 * after this one reads it too), with where it came from (source kept:<id>). Nothing else: the note stays
 * open until someone does what it says and marks it Done. undo: the copy goes.
 */
function ogc_hd_rest_keep( WP_REST_Request $req ) {
	global $wpdb;
	$y    = (int) $req['year'];
	$k    = ogc_app_c( $req );
	$prev = ogc_app_prev_year( $y );
	$n    = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . ogc_table( 'cnotes' ) . ' WHERE id = %d AND ckey = %s AND removed_at IS NULL', (int) $req->get_param( 'id' ), $k ), ARRAY_A );
	if ( ! $n || ! $prev || (int) $n['year'] !== $prev ) {
		return new WP_Error( 'ogc_not_found', 'Not found.', array( 'status' => 404 ) );
	}
	$src  = 'kept:' . (int) $n['id'];
	$copy = $wpdb->get_row( $wpdb->prepare( 'SELECT id FROM ' . ogc_table( 'cnotes' ) . ' WHERE year = %d AND ckey = %s AND source = %s AND removed_at IS NULL', $y, $k, $src ), ARRAY_A );
	if ( $req->get_param( 'undo' ) ) {
		if ( $copy ) {
			$wpdb->update( ogc_table( 'cnotes' ), array( 'removed_at' => ogc_now() ), array( 'id' => (int) $copy['id'] ) );
		}
		return rest_ensure_response( array( 'kept' => false, 'id' => (int) $n['id'] ) );
	}
	if ( $copy ) {
		return new WP_Error( 'ogc_exists', 'Kept already', array( 'status' => 409 ) );
	}
	$wpdb->insert( ogc_table( 'cnotes' ), array( 'year' => $y, 'ckey' => $k, 'body' => (string) $n['body'], 'author' => get_current_user_id(), 'source' => $src, 'created_at' => ogc_now() ) );
	// By its source, not insert_id (the local SQLite layer has answered another table's id).
	$copy = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM ' . ogc_table( 'cnotes' ) . ' WHERE year = %d AND ckey = %s AND source = %s AND removed_at IS NULL ORDER BY id DESC LIMIT 1', $y, $k, $src ) );
	ogc_log( 'app_hd_keep', $y, 'committee:' . $k, array( 'ckey' => $k ) );
	$o = ogc_hd_kept_notes( $y, $k );
	return rest_ensure_response( array(
		'kept'   => true,
		'id'     => (int) $n['id'],
		'copy'   => $copy,
		'by'     => ogc_app_user_name( get_current_user_id(), $y ),
		'origin' => isset( $o[ $copy ] ) ? $o[ $copy ] : array( 'src' => (int) $n['id'], 'year' => $prev, 'on' => '' ),
	) );
}

/* ================================================================== the COA's view: every committee */

/** Every committee's hand-down, in counts: what came from last year and what's going to next year. */
function ogc_hd_board( $y ) {
	global $wpdb;
	$prev = ogc_app_prev_year( $y );
	$out  = array();
	foreach ( ogc_app_committees( $y ) as $c ) {
		$k     = $c['ckey'];
		$last  = $prev ? ogc_app_notes( $prev, $k ) : array();
		$open  = count( array_filter( $last, function ( $n ) {
			return ! $n['done'];
		} ) );
		$lr    = $prev ? ogc_hd_report_row( $prev, $k ) : array( 'status' => 'none', 'sent' => '' );
		$rep   = ogc_hd_report_row( $y, $k );
		$con   = ogc_hd_field( $y, $k, 'contacts' );
		$how   = ogc_hd_field( $y, $k, 'how' );
		$files = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM ' . ogc_table( 'cfiles' ) . ' WHERE year = %d AND ckey = %s AND removed_at IS NULL', $y, $k ) );
		$nm    = 'coa' === $k ? null : ogc_hd_field( $y, $k, 'numbers', false );
		$lnm   = 'coa' === $k || ! $prev ? null : ogc_hd_field( $prev, $k, 'numbers', false );
		// "Not checked" by the board's own rule (module-app-rest.php): only once the committee has met.
		$met = 'coa' === $k;
		foreach ( $met ? array() : ogc_app_tasks( $y, array( $k ) ) as $t ) {
			if ( 'First meeting' === $t['title'] && ( $t['done'] || ( $t['due'] && $t['due'] < ogc_app_today( $y ) ) ) ) {
				$met = true;
			}
		}
		$out[] = array(
			'key'        => $k,
			'name'       => 'coa' === $k ? 'COA' : $c['name'],
			'from'       => $c['from_year'],
			'checked'    => ! empty( $c['checked_at'] ),
			'unchecked'  => $c['from_year'] && empty( $c['checked_at'] ) && $met,
			'last_notes' => count( $last ),
			'last_open'  => $open,
			'last_report' => $lr['status'],
			'how'        => $how && '' !== trim( $how['value'] ),
			'contacts'   => $con ? count( $con['value'] ) : 0,
			'files'      => $files,
			'notes'      => count( ogc_app_notes( $y, $k ) ),
			'report'     => 'coa' === $k ? '' : $rep['status'],
			'report_word' => 'coa' === $k ? '' : ogc_hd_status_word( $rep['status'] ),
			'sent'       => $rep['sent'] ? ogc_app_md( $rep['sent'], $y ) : '',
			// The report itself, for the panel beside the list (the COA reads each without leaving it):
			// the questions as asked, the answers, this year's numbers and last year's beside them.
			'read'       => 'coa' === $k ? null : array(
				'questions' => ogc_hd_questions( $y, $k ),
				'answers'   => $rep['answers'],
				'numbers'   => $nm ? $nm['value'] : array(),
				'last'      => $lnm ? array_values( array_map( function ( $x ) {
					return array( 'what' => $x['what'], 'n' => $x['n'] );
				}, $lnm['value'] ) ) : array(),
			),
		);
	}
	return array( 'year' => (int) $y, 'prev' => $prev, 'phase' => ogc_app_phase( $y )['phase'], 'committees' => $out );
}

function ogc_hd_rest_board( WP_REST_Request $req ) {
	return rest_ensure_response( ogc_hd_board( (int) $req['year'] ) );
}

/* ================================================================== export */

/** The fixed columns of each sheet (the same every year; a new one is only ever added at the right). */
function ogc_hd_spec() {
	return array(
		'page'     => array( 'title' => 'Responsibilities', 'cols' => array(
			array( 'Part', 'Responsibility (one of the COA’s lines) or How we work (the committee’s own words)', 18 ),
			array( 'Text', 'One line each', 90 ),
		) ),
		'notes'    => array( 'title' => 'Notes', 'cols' => array(
			array( 'Year', 'The year the note was written in', 8 ),
			array( 'Note', 'For the next year’s committee', 80 ),
			array( 'Written', 'The day it was written', 12 ),
			array( 'Status', 'Open, or Done (the next year’s committee dealt with it)', 10 ),
		) ),
		'report'   => array( 'title' => 'Report', 'cols' => array(
			array( 'Question', 'The COA’s question', 44 ),
			array( 'Answer', 'As the committee wrote it', 90 ),
		) ),
		'numbers'  => array( 'title' => 'Numbers', 'cols' => array(
			array( 'What', 'What was counted', 44 ),
			array( 'Number', 'This year', 12 ),
			array( 'Last year', 'The same count the year before, when it was kept', 12 ),
			array( 'Note', 'A word about it', 40 ),
		) ),
		'contacts' => array( 'title' => 'Contacts', 'cols' => array(
			array( 'Role', 'A role or office, not a person', 34 ),
			array( 'Phone', '', 18 ),
			array( 'Email', '', 30 ),
			array( 'Note', 'What to call them for', 50 ),
		) ),
		'files'    => array( 'title' => 'Files', 'cols' => array(
			array( 'Name', 'As uploaded; download it from the committee’s page', 44 ),
			array( 'Type', 'PDF, XLSX, DOCX…', 8 ),
			array( 'Size KB', '', 10 ),
			array( 'Uploaded', 'The day it was first uploaded', 12 ),
			array( 'From', 'The year it was first uploaded', 8 ),
			array( 'Next year', 'Yes when it goes on to next year’s committee', 10 ),
			array( 'Note', 'What it’s for', 50 ),
		) ),
		'tasks'    => array( 'title' => 'Tasks', 'cols' => array(
			array( 'Task', '', 44 ),
			array( 'Due', 'This year’s date, or weeks from the first day', 16 ),
			array( 'Done', 'The day it was done, or blank', 12 ),
		) ),
	);
}

/** A committee's hand-down as sheets (the workbook's, before the Columns sheet). Never people. */
function ogc_hd_sheets( $y, $k ) {
	$spec = ogc_hd_spec();
	$c    = ogc_app_committee( $y, $k );
	$how  = ogc_hd_field( $y, $k, 'how' );
	$con  = ogc_hd_field( $y, $k, 'contacts' );
	$num  = ogc_hd_field( $y, $k, 'numbers', false );
	$prev = ogc_app_prev_year( $y );
	$ln   = $prev ? ogc_hd_field( $prev, $k, 'numbers', false ) : null;
	$safe = function ( $s ) {
		return function_exists( 'ogc_ed_safe_cell' ) ? ogc_ed_safe_cell( $s ) : (string) $s;
	};
	$page = array();
	foreach ( preg_split( '/\R/', (string) ( $c ? $c['duties'] : '' ) ) as $l ) {
		if ( '' !== trim( $l ) ) {
			$page[] = array( 'Responsibility', $safe( trim( $l ) ) );
		}
	}
	foreach ( preg_split( '/\R/', $how ? (string) $how['value'] : '' ) as $l ) {
		if ( '' !== trim( $l ) ) {
			$page[] = array( 'How we work', $safe( trim( $l ) ) );
		}
	}
	if ( $c && $c['link'] ) {
		$page[] = array( 'Folder link', $c['link'] );
	}
	$notes = array();
	foreach ( array_filter( array( $prev, $y ) ) as $ny ) {
		foreach ( ogc_app_notes( $ny, $k ) as $n ) {
			$notes[] = array( (int) $ny, $safe( $n['body'] ), $n['on'], $ny === $y ? 'Open' : ( $n['done'] ? 'Done' : 'Open' ) );
		}
	}
	$report = array();
	if ( 'coa' !== $k ) {
		$r = ogc_hd_report_row( $y, $k );
		foreach ( ogc_hd_questions( $y, $k ) as $i => $q ) {
			$report[] = array( $q, $safe( isset( $r['answers'][ $i ] ) ? $r['answers'][ $i ] : '' ) );
		}
	}
	$lastby = array();
	foreach ( $ln ? $ln['value'] : array() as $n ) {
		$lastby[ strtolower( $n['what'] ) ] = $n['n'];
	}
	$numbers = array();
	foreach ( $num ? $num['value'] : array() as $n ) {
		$numbers[] = array( $safe( $n['what'] ), '' === $n['n'] ? '' : 0 + $n['n'], isset( $lastby[ strtolower( $n['what'] ) ] ) && '' !== $lastby[ strtolower( $n['what'] ) ] ? 0 + $lastby[ strtolower( $n['what'] ) ] : '', $safe( $n['note'] ) );
	}
	$contacts = array();
	foreach ( $con ? $con['value'] : array() as $x ) {
		$contacts[] = array( $safe( $x['role'] ), $safe( $x['phone'] ), $x['email'], $safe( $x['note'] ) );
	}
	$files = array();
	foreach ( ogc_hd_files( $y, $k ) as $f ) {
		$files[] = array( $safe( $f['name'] ), $f['type'], (int) round( $f['size'] / 1024 ), $f['at'] ? wp_date( 'Y-m-d', strtotime( $f['at'] . ' UTC' ) ) : '', $f['from'] ? $f['from'] : (int) $y, $f['pass'] ? 'Yes' : 'No', $safe( $f['note'] ) );
	}
	$tasks = array();
	foreach ( ogc_app_tasks( $y, array( $k ) ) as $t ) {
		$tasks[] = array( $safe( $t['title'] ), $t['due'] ? $t['due'] : $t['due_words'], $t['done'] && $t['done_on'] ? $t['done_on'] : '' );
	}
	$out = array(
		ogc_lst_list_sheet( $spec['page'], $page ),
		ogc_lst_list_sheet( $spec['notes'], $notes ),
	);
	if ( 'coa' !== $k ) {
		$out[] = ogc_lst_list_sheet( $spec['report'], $report );
		$out[] = ogc_lst_list_sheet( $spec['numbers'], $numbers );
	}
	$out[] = ogc_lst_list_sheet( $spec['contacts'], $contacts );
	$out[] = ogc_lst_list_sheet( $spec['files'], $files );
	$out[] = ogc_lst_list_sheet( $spec['tasks'], $tasks );
	return $out;
}

/** A committee's hand-down workbook: its sheets, then Columns (what each column holds). */
function ogc_hd_workbook( $y, $k ) {
	$c     = ogc_app_committee( $y, $k );
	$spec  = ogc_hd_spec();
	$parts = array();
	foreach ( ogc_hd_sheets( $y, $k ) as $s ) {
		foreach ( $spec as $sp ) {
			if ( $sp['title'] === $s['name'] ) {
				$parts[] = $sp;
			}
		}
	}
	$first = array_shift( $parts );
	$cols  = ogc_lst_columns_sheet( $first, array(
		'Committee' => $c ? ( 'coa' === $k ? 'COA' : $c['name'] ) : $k,
		'Year'      => (string) (int) $y,
		'Exported'  => function_exists( 'ogc_lst_as_of_long' ) ? ogc_lst_as_of_long( $y ) : wp_date( 'M j, Y g:i A' ),
		'Kept'      => 'In the app, on the committee’s page. This file is a copy.',
	), $parts );
	return ogc_lst_xlsx( array_merge( ogc_hd_sheets( $y, $k ), array( $cols ) ) );
}

/** "2027 Ushers hand-down", the same every year but the year. */
function ogc_hd_file_name( $y, $k, $ext ) {
	$c = ogc_app_committee( $y, $k );
	$n = $c ? ( 'coa' === $k ? 'COA' : $c['name'] ) : $k;
	return (int) $y . ' ' . trim( preg_replace( '/[\\\\\/:*?"<>|]+/', ' ', $n ) ) . ' hand-down.' . $ext;
}

/** GET export: the workbook, or (zip) the workbook and every file the committee keeps this year. */
function ogc_hd_rest_export( WP_REST_Request $req ) {
	$y   = (int) $req['year'];
	$k   = ogc_app_c( $req );
	$fmt = 'zip' === $req->get_param( 'format' ) ? 'zip' : 'xlsx';
	if ( ! function_exists( 'ogc_lst_xlsx' ) ) {
		return new WP_Error( 'ogc_off', 'Not available', array( 'status' => 503 ) );
	}
	$book = ogc_hd_workbook( $y, $k );
	ogc_log( 'app_hd_export', $y, 'committee:' . $k, array( 'ckey' => $k, 'format' => $fmt ) );
	if ( 'xlsx' === $fmt ) {
		return ogc_lst_xlsx_response( $book, ogc_hd_file_name( $y, $k, 'xlsx' ) );
	}
	$files = array( ogc_hd_file_name( $y, $k, 'xlsx' ) => $book );
	$total = strlen( $book );
	$cap   = (int) apply_filters( 'ogc_hd_zip_max', 60 * MB_IN_BYTES );
	$dir   = ogc_app_private_dir();
	foreach ( ogc_hd_files( $y, $k ) as $f ) {
		$path = $dir . '/' . preg_replace( '/[^a-f0-9]/', '', $f['fkey'] );
		if ( ! is_file( $path ) ) {
			continue;
		}
		$total += (int) filesize( $path );
		if ( $total > $cap ) {
			return new WP_Error( 'ogc_too_big', 'Too large to zip · Download the files one by one', array( 'status' => 413 ) );
		}
		$name = 'Files/' . str_replace( array( '/', '\\' ), ' ', $f['name'] );
		for ( $i = 2; isset( $files[ $name ] ); $i++ ) {
			$name = 'Files/' . pathinfo( $f['name'], PATHINFO_FILENAME ) . ' (' . $i . ').' . pathinfo( $f['name'], PATHINFO_EXTENSION );
		}
		$files[ $name ] = (string) file_get_contents( $path ); // phpcs:ignore WordPress.WP.AlternativeFunctions -- a private file.
	}
	$zip = ogc_lst_zip( $files );
	$res = new WP_REST_Response( null, 200 );
	$res->header( 'Content-Type', 'application/zip' );
	$res->header( 'Content-Disposition', 'attachment; filename="' . str_replace( '"', '', ogc_hd_file_name( $y, $k, 'zip' ) ) . '"' );
	$res->header( 'Cache-Control', 'no-store' );
	$res->header( 'X-Content-Type-Options', 'nosniff' );
	add_filter( 'rest_pre_serve_request', function ( $served, $result ) use ( $zip, $res ) {
		if ( $result === $res ) {
			echo $zip; // phpcs:ignore WordPress.Security.EscapeOutput -- a zip's bytes, built above.
			return true;
		}
		return $served;
	}, 10, 2 );
	return $res;
}

/**
 * Every committee's hand-down in one workbook (the COA; the year's Export carries it too): Reports
 * (one row a committee, the answers as Answer 1…5: the questions are the COA's and may be reworded, so
 * the column names stay put and Columns says each question), Numbers, Contacts, Notes, How we work.
 */
function ogc_hd_reports_book( $y ) {
	$qs   = ogc_app_report_questions( $y );
	$prev = ogc_app_prev_year( $y );
	$safe = function ( $s ) {
		return function_exists( 'ogc_ed_safe_cell' ) ? ogc_ed_safe_cell( $s ) : (string) $s;
	};
	$rep  = array();
	$num  = array();
	$con  = array();
	$nts  = array();
	$how  = array();
	foreach ( ogc_app_committees( $y ) as $c ) {
		$k  = $c['ckey'];
		$nm = 'coa' === $k ? 'COA' : $c['name'];
		if ( 'coa' !== $k ) {
			$r   = ogc_hd_report_row( $y, $k );
			$row = array( $nm, ogc_hd_status_word( $r['status'] ), $r['sent'] );
			for ( $i = 0; $i < 5; $i++ ) {
				$row[] = $safe( isset( $r['answers'][ $i ] ) ? $r['answers'][ $i ] : '' );
			}
			$rep[] = $row;
			$n     = ogc_hd_field( $y, $k, 'numbers', false );
			$ln    = $prev ? ogc_hd_field( $prev, $k, 'numbers', false ) : null;
			$lastby = array();
			foreach ( $ln ? $ln['value'] : array() as $x ) {
				$lastby[ strtolower( $x['what'] ) ] = $x['n'];
			}
			foreach ( $n ? $n['value'] : array() as $x ) {
				$l     = isset( $lastby[ strtolower( $x['what'] ) ] ) ? $lastby[ strtolower( $x['what'] ) ] : '';
				$num[] = array( $nm, $safe( $x['what'] ), '' === $x['n'] ? '' : 0 + $x['n'], '' === $l ? '' : 0 + $l, $safe( $x['note'] ) );
			}
		}
		$cf = ogc_hd_field( $y, $k, 'contacts' );
		foreach ( $cf ? $cf['value'] : array() as $x ) {
			$con[] = array( $nm, $safe( $x['role'] ), $safe( $x['phone'] ), $x['email'], $safe( $x['note'] ) );
		}
		foreach ( ogc_app_notes( $y, $k ) as $x ) {
			$nts[] = array( $nm, $safe( $x['body'] ), $x['on'] );
		}
		$hf = ogc_hd_field( $y, $k, 'how' );
		foreach ( preg_split( '/\R/', $hf ? (string) $hf['value'] : '' ) as $l ) {
			if ( '' !== trim( $l ) ) {
				$how[] = array( $nm, $safe( trim( $l ) ) );
			}
		}
	}
	$specs = array(
		array( 'title' => 'Reports', 'cols' => array_merge( array(
			array( 'Committee', '', 18 ),
			array( 'Status', 'Not started, Draft, Sent, or Changed since sending (sent, then changed)', 14 ),
			array( 'Sent', 'The day it was sent to the COA', 11 ),
		), array_map( function ( $i ) use ( $qs ) {
			return array( 'Answer ' . ( $i + 1 ), isset( $qs[ $i ] ) ? $qs[ $i ] : '', 48 );
		}, range( 0, 4 ) ) ) ),
		array( 'title' => 'Numbers', 'cols' => array( array( 'Committee', '', 18 ), array( 'What', 'What was counted', 40 ), array( 'Number', 'This year', 10 ), array( 'Last year', 'The same count the year before', 10 ), array( 'Note', '', 36 ) ) ),
		array( 'title' => 'Contacts', 'cols' => array( array( 'Committee', '', 18 ), array( 'Role', 'A role or office, not a person', 32 ), array( 'Phone', '', 16 ), array( 'Email', '', 28 ), array( 'Note', '', 40 ) ) ),
		array( 'title' => 'Notes for next year', 'cols' => array( array( 'Committee', '', 18 ), array( 'Note', '', 80 ), array( 'Written', '', 12 ) ) ),
		array( 'title' => 'How we work', 'cols' => array( array( 'Committee', '', 18 ), array( 'Text', 'One line each, in the committee’s words', 90 ) ) ),
	);
	$data   = array( $rep, $num, $con, $nts, $how );
	$sheets = array();
	foreach ( $specs as $i => $s ) {
		$sheets[] = ogc_lst_list_sheet( $s, $data[ $i ] );
	}
	$first    = array_shift( $specs );
	$sheets[] = ogc_lst_columns_sheet( $first, array(
		'Year'     => (string) (int) $y,
		'Exported' => function_exists( 'ogc_lst_as_of_long' ) ? ogc_lst_as_of_long( $y ) : wp_date( 'M j, Y g:i A' ),
		'Kept'     => 'In the app, on each committee’s page. This file is a copy.',
	), $specs );
	return ogc_lst_xlsx( $sheets );
}

function ogc_hd_rest_reports( WP_REST_Request $req ) {
	$y = (int) $req['year'];
	if ( ! function_exists( 'ogc_lst_xlsx' ) ) {
		return new WP_Error( 'ogc_off', 'Not available', array( 'status' => 503 ) );
	}
	ogc_log( 'app_hd_export', $y, 'year:' . $y, array( 'what' => 'reports' ) );
	return ogc_lst_xlsx_response( ogc_hd_reports_book( $y ), (int) $y . ' Committee reports.xlsx' );
}

// The year's Export (module-editors.php) carries the committees' hand-down too, when the year's COA
// exports it: the record the Scheduling Committee keeps (scope ch. 8 §6). A webmaster's export leaves it
// out, as webmasters see committees' structure only (docs/23).
add_filter( 'ogc_year_export_files', function ( $files, $y ) {
	$coa = function_exists( 'ogc_app_viewer' ) && is_user_logged_in() ? ogc_app_viewer( (int) $y )['coa'] : false;
	if ( $coa && function_exists( 'ogc_lst_xlsx' ) && function_exists( 'ogc_app_tables_ready' ) && ogc_app_tables_ready() && ogc_hd_ready() && ogc_app_committees( $y ) ) {
		$files[ (int) $y . '/Committee reports.xlsx' ] = ogc_hd_reports_book( $y );
	}
	return $files;
}, 10, 2 );

/* ================================================================== the report ticks its task; Home */

add_filter( 'ogc_app_task_kinds', function ( $k ) {
	$k['report_sent'] = array( 'screen' => '', 'from' => 'the report' );
	return $k;
} );

add_filter( 'ogc_app_task_auto', function ( $done, $kind, $year, $ckey, $today ) {
	if ( 'report_sent' !== $kind || '' !== $done ) {
		return $done;
	}
	$r = ogc_hd_report_row( $year, $ckey );
	return $r['sent'] && $r['sent'] <= $today ? $r['sent'] : '';
}, 10, 5 );

// The seeded "Report to the COA" tasks made before the kind existed: tied once, on every site.
add_action( 'init', function () {
	global $wpdb;
	if ( '1' === get_option( 'ogc_hd_task_kind' ) || ! function_exists( 'ogc_app_tables_ready' ) || ! ogc_app_tables_ready() ) {
		return;
	}
	$wpdb->query( $wpdb->prepare( 'UPDATE ' . ogc_table( 'tasks' ) . " SET kind = %s WHERE title = %s AND ( kind = '' OR kind IS NULL )", 'report_sent', 'Report to the COA' ) );
	update_option( 'ogc_hd_task_kind', '1', false );
}, 46 );

// Once on every site (critique, Oct 14): files uploaded, switched off or removed after next year was
// started are made true in next year's files (ogc_hd_file_sync; nothing next year's committee made its
// own is taken).
add_action( 'init', function () {
	global $wpdb;
	if ( '1' === get_option( 'ogc_hd_files_synced' ) || ! function_exists( 'ogc_app_tables_ready' ) || ! ogc_app_tables_ready() || ! ogc_hd_ready() ) {
		return;
	}
	foreach ( (array) $wpdb->get_col( 'SELECT id FROM ' . ogc_table( 'cfiles' ) . ' WHERE removed_at IS NULL ORDER BY year, id' ) as $id ) { // phpcs:ignore -- no input.
		ogc_hd_file_sync( (int) $id );
	}
	update_option( 'ogc_hd_files_synced', '1', false );
}, 52 );

// The local A/V sample report (module-app-seed.php) was answered under the 4th question's first wording
// ("What did it cost, against the budget?"); kept with it, so it reads under what was asked.
add_action( 'init', function () {
	global $wpdb;
	if ( ! OGC_DEV || '1' === get_option( 'ogc_hd_av_q' ) || ! function_exists( 'ogc_app_tables_ready' ) || ! ogc_app_tables_ready() || ! ogc_hd_ready() ) {
		return;
	}
	$r = $wpdb->get_row( $wpdb->prepare( 'SELECT year, answers FROM ' . ogc_table( 'creports' ) . ' WHERE year = %d AND ckey = %s', 2026, 'a/v' ), ARRAY_A );
	if ( ! $r ) {
		return;
	}
	$a   = (array) ogc_unjson( $r['answers'], array() );
	$own = ogc_hd_row( 2026, 'a/v' );
	if ( isset( $a[3] ) && 'Within the budget. Two lapel microphones replaced.' === $a[3] && ( ! $own || null === $own['questions'] ) ) {
		$q = ogc_app_report_questions( 2026 );
		if ( isset( $q[3] ) && 'What did you use, and what did it cost?' === $q[3] ) {
			$q[3] = 'What did it cost, against the budget?';
		}
		ogc_hd_put( 2026, 'a/v', array( 'questions' => ogc_hd_json_list( $q ) ) );
	}
	update_option( 'ogc_hd_av_q', '1', false );
}, 53 );

// The COA's Home after the Conference: how many reports are still to come, one line (never a zero).
add_filter( 'ogc_app_needs', function ( $rows, $year, $ckey, $ctx ) {
	if ( 'coa' !== $ckey || 'after' !== $ctx['phase'] || ! ogc_hd_ready() ) {
		return $rows;
	}
	$all  = array_filter( ogc_app_committees( $year ), function ( $c ) {
		return 'coa' !== $c['ckey'];
	} );
	$left = array_filter( $all, function ( $c ) use ( $year ) {
		return ! ogc_hd_report_in( ogc_hd_report_row( $year, $c['ckey'] )['status'] );
	} );
	if ( ! $left ) {
		return $rows;
	}
	$in     = count( $all ) - count( $left );
	// The same words as Home's headline after the Conference (module-app-rest.php), which makes this its
	// button rather than a second line.
	$rows[] = array(
		'key'    => 'hd-reports',
		'words'  => 'Reports · ' . $in . ' of ' . count( $all ) . ' in',
		'why'    => count( $left ) . ' to come · Next year’s committees read them first',
		'go'     => array( 's' => 'committees', 'v' => 'handdown', 'c' => '' ),
		'button' => 'See reports',
		'tone'   => '',
		'due'    => '',
		'rank'   => 2,
	);
	return $rows;
}, 10, 4 );

// Activity: the hand-down's acts in words.
add_filter( 'ogc_app_log_words', function ( $w, $who, $cn, $d ) {
	$on = $cn ? ' · ' . $cn : '';
	$t  = isset( $d['title'] ) ? (string) $d['title'] : '';
	return array_merge( $w, array(
		'app_hd_how'       => $who . ' changed How we work' . $on,
		'app_hd_contacts'  => $who . ' changed the contacts' . $on,
		'app_hd_numbers'   => $who . ' filled in the numbers' . $on,
		'app_hd_keep'      => $who . ' kept a note for next year' . $on,
		'app_hd_file'      => '',
		'app_hd_file_back' => $who . ' put back ' . ( $t ? $t : 'a file' ) . $on,
		'app_hd_export'    => '',
	) );
}, 10, 4 );

/* ================================================================== the page's files */

add_filter( 'ogc_pages', function ( $p ) {
	if ( isset( $p['app'] ) ) {
		$p['app']['styles'][]  = 'app/screens/handdown.css';
		$p['app']['scripts'][] = 'app/screens/committee-handdown.js';
	}
	return $p;
}, 20 );

/* ================================================================== the local site's samples */

/** A one-page PDF with lines of text (Helvetica), for the samples. */
function ogc_hd_sample_pdf( $title, $lines ) {
	$esc    = function ( $s ) {
		return str_replace( array( '\\', '(', ')' ), array( '\\\\', '\\(', '\\)' ), iconv( 'UTF-8', 'windows-1252//TRANSLIT', $s ) );
	};
	$stream = "BT /F1 16 Tf 56 740 Td (" . $esc( $title ) . ") Tj ET\n";
	$y      = 708;
	foreach ( $lines as $l ) {
		$stream .= 'BT /F1 11 Tf 56 ' . $y . ' Td (' . $esc( $l ) . ") Tj ET\n";
		$y      -= 18;
	}
	$objs = array(
		'<< /Type /Catalog /Pages 2 0 R >>',
		'<< /Type /Pages /Kids [3 0 R] /Count 1 >>',
		'<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>',
		'<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>',
		'<< /Length ' . strlen( $stream ) . " >>\nstream\n" . $stream . 'endstream',
	);
	$pdf  = "%PDF-1.4\n";
	$offs = array();
	foreach ( $objs as $i => $o ) {
		$offs[] = strlen( $pdf );
		$pdf   .= ( $i + 1 ) . " 0 obj\n" . $o . "\nendobj\n";
	}
	$x    = strlen( $pdf );
	$pdf .= "xref\n0 " . ( count( $objs ) + 1 ) . "\n0000000000 65535 f \n";
	foreach ( $offs as $o ) {
		$pdf .= sprintf( "%010d 00000 n \n", $o );
	}
	return $pdf . "trailer\n<< /Size " . ( count( $objs ) + 1 ) . " /Root 1 0 R >>\nstartxref\n" . $x . "\n%%EOF\n";
}

/** 2026's hand-down for a few committees (made up, in the committees' voice, no one's details), and
 * 2027 carrying it: the files by reference, the rest read from 2026 ("From 2026"). Local sites only. */
function ogc_hd_seed() {
	global $wpdb;
	if ( ! OGC_DEV || ! function_exists( 'ogc_app_tables_ready' ) || ! ogc_app_tables_ready() || ! ogc_hd_ready() || null === ogc_year_get( 2026 ) || ! ogc_app_committees( 2026 ) ) {
		return;
	}
	$hd = array(
		'ushers'         => array(
			'how'      => "Two ushers at each chapel door from 30 minutes before every service.\nSeat older folks and anyone with a walker first, on the aisle seats near the front.\nOpen the overflow room when the chapel is two-thirds full; the gym is the overflow.\nAsk the campus to open the chapel windows an hour before the morning service.\nCommunion tables are set the evening before; First Aid’s chairs go at the back.",
			'contacts' => array(
				array( 'role' => 'Campus events office', 'phone' => '765-555-0140', 'email' => 'events@example.edu', 'note' => 'Room changes, chairs and keys' ),
				array( 'role' => 'Facilities night line', 'phone' => '765-555-0177', 'email' => '', 'note' => 'After 5 PM: lights, heat, locked doors' ),
				array( 'role' => 'Campus security desk', 'phone' => '765-555-0111', 'email' => '', 'note' => 'Doors that won’t open, parking trouble' ),
			),
			'numbers'  => array(
				array( 'what' => 'Ushers at a Sunday service', 'n' => '26', 'note' => '' ),
				array( 'what' => 'Chairs in the overflow room', 'n' => '400', 'note' => 'Set Saturday afternoon' ),
				array( 'what' => 'Services with overflow open', 'n' => '3', 'note' => '' ),
			),
			'report'   => array(
				'Seating on Sunday morning went smoothly with two at each door.',
				'Overflow chairs were set late on Saturday. Nobody knew who had asked the campus.',
				'Write down who asks the campus for overflow chairs, and by when.',
				'Two hundred programs, tape for the reserved rows, four radios borrowed from A/V. No costs.',
				'Read How we work first, then walk the chapel with the campus in March.',
			),
			'sent'     => '2026-07-09 15:00:00',
			'notes'    => array( 'Ask the campus for the overflow chairs by May 1, in writing.', 'Borrow the radios from A/V on Friday and give them back Tuesday.' ),
			'files'    => array(
				array( 'Usher posts by door.xlsx', 'Which door each usher takes, by service' ),
				array( 'Chapel seating plan.pdf', 'Reserved rows and the aisles kept clear' ),
			),
		),
		'a/v'            => array(
			'how'      => "Test the call-in line with the provider the Thursday before.\nRecord every service; the booth keeps the speaker’s name and the time it starts.\nOne list of events, with the call-in and recording needs on each row.",
			'contacts' => array(
				array( 'role' => 'Call-in line provider support', 'phone' => '800-555-0199', 'email' => 'support@example.com', 'note' => 'Account under the A/V role address' ),
				array( 'role' => 'Campus AV services', 'phone' => '765-555-0155', 'email' => 'av@example.edu', 'note' => 'Chapel sound board and the gym’s speakers' ),
			),
			'numbers'  => array(
				array( 'what' => 'Callers on the line, Tuesday council', 'n' => '212', 'note' => '' ),
				array( 'what' => 'Services recorded', 'n' => '14', 'note' => '' ),
			),
			'files'    => array( array( 'Call-in line checklist.pdf', 'Before, during and after each service' ) ),
		),
		'food'           => array(
			'how'      => "Final counts to the caterer two weeks before, and the changes each morning by 8.\nSnacks for Young Folks and Preteens come from the snack money, not the caterer.",
			'contacts' => array( array( 'role' => 'Caterer’s catering manager', 'phone' => '765-555-0160', 'email' => 'catering@example.com', 'note' => 'Counts, menus and the serving lines' ) ),
			'numbers'  => array( array( 'what' => 'Meals served, Sunday dinner', 'n' => '1840', 'note' => '' ) ),
			'report'   => array( 'The serving lines moved faster with four stations.', '', '', '', '' ),
			'files'    => array( array( 'Snack counts 2026.csv', 'Snacks by day and group' ) ),
		),
		'lodging'        => array(
			'contacts' => array( array( 'role' => 'Campus housing office', 'phone' => '765-555-0130', 'email' => 'housing@example.edu', 'note' => 'Hall lists, keys and linens' ) ),
		),
	);
	$dir = ogc_app_private_ok() ? ogc_app_private_dir() : '';
	foreach ( $hd as $k => $d ) {
		if ( ! ogc_app_committee( 2026, $k ) ) {
			continue;
		}
		if ( ! ogc_hd_row( 2026, $k ) ) {
			$set = array();
			if ( isset( $d['how'] ) ) {
				$set += array( 'how' => $d['how'], 'how_at' => '2026-06-30 15:00:00' );
			}
			if ( isset( $d['contacts'] ) ) {
				$set += array( 'contacts' => ogc_json( ogc_hd_clean_contacts( $d['contacts'] ) ), 'contacts_at' => '2026-06-30 15:00:00' );
			}
			if ( isset( $d['numbers'] ) ) {
				$set += array( 'numbers' => ogc_json( ogc_hd_clean_numbers( $d['numbers'] ) ), 'numbers_at' => '2026-07-08 15:00:00' );
			}
			if ( $set ) {
				ogc_hd_put( 2026, $k, $set );
				$wpdb->update( ogc_table( 'handdown' ), array( 'updated_at' => '2026-07-08 15:00:00', 'created_at' => '2026-06-30 15:00:00' ), array( 'year' => 2026, 'ckey' => $k ) );
			}
		}
		if ( isset( $d['report'] ) && ! ogc_app_report( 2026, $k ) ) {
			$wpdb->insert( ogc_table( 'creports' ), array( 'year' => 2026, 'ckey' => $k, 'answers' => ogc_json( $d['report'] ), 'updated_at' => isset( $d['sent'] ) ? $d['sent'] : '2026-07-02 15:00:00', 'sent_at' => isset( $d['sent'] ) ? $d['sent'] : null ) );
		}
		foreach ( isset( $d['notes'] ) ? $d['notes'] : array() as $body ) {
			if ( ! (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM ' . ogc_table( 'cnotes' ) . ' WHERE year = 2026 AND ckey = %s AND body = %s', $k, $body ) ) ) {
				// Its own source: the app's seed adds its notes only while no 'sample' note exists.
				$wpdb->insert( ogc_table( 'cnotes' ), array( 'year' => 2026, 'ckey' => $k, 'body' => $body, 'source' => 'sample-hd', 'created_at' => '2026-07-01 15:00:00' ) );
			}
		}
		if ( ! $dir ) {
			continue;
		}
		foreach ( isset( $d['files'] ) ? $d['files'] : array() as $fi ) {
			$name = $fi[0];
			$has  = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . ogc_table( 'cfiles' ) . ' WHERE year = 2026 AND ckey = %s AND name = %s', $k, $name ), ARRAY_A );
			if ( ! $has ) {
				$ext = strtolower( pathinfo( $name, PATHINFO_EXTENSION ) );
				if ( 'xlsx' === $ext && function_exists( 'ogc_lst_xlsx' ) ) {
					$bytes = ogc_lst_xlsx( array( array( 'name' => 'Posts', 'cols' => array( 'Door', 'Ushers', 'Service', 'Note' ), 'widths' => array( 22, 8, 22, 40 ), 'rows' => array(
						array( 'Chapel, north doors', 2, 'Every service', 'Walkers to the front aisle' ),
						array( 'Chapel, south doors', 2, 'Every service', '' ),
						array( 'Chapel, balcony stairs', 1, 'Sunday morning', 'Balcony opens when the floor is full' ),
						array( 'Gym (overflow)', 3, 'When the chapel is two-thirds full', 'Radio from A/V' ),
					) ) ) );
				} elseif ( 'pdf' === $ext ) {
					$bytes = ogc_hd_sample_pdf( preg_replace( '/\.pdf$/', '', $name ), 'a/v' === $k
						? array( 'Thursday: test call with the provider.', 'Each service: start the line 15 minutes early; check the recording runs.', 'After: note the start time and the speaker for the recording.' )
						: array( 'Rows 1-2 kept for the ministry.', 'Rows 3-4 kept for older folks and walkers.', 'Aisles kept clear for First Aid.' ) );
				} else {
					$bytes = "Day,Young Folks,Preteens,All ages\nFriday,180,60,0\nSaturday,190,64,300\nSunday,200,66,320\nMonday,195,62,0\n";
				}
				$stored = bin2hex( random_bytes( 16 ) );
				file_put_contents( $dir . '/' . $stored, $bytes ); // phpcs:ignore WordPress.WP.AlternativeFunctions -- the sample's private file.
				$types = ogc_app_file_types();
				$wpdb->insert( ogc_table( 'cfiles' ), array( 'year' => 2026, 'ckey' => $k, 'name' => $name, 'fkey' => $stored, 'mime' => isset( $types[ $ext ] ) ? $types[ $ext ] : 'application/octet-stream', 'size' => strlen( $bytes ), 'uploaded_by' => 0, 'created_at' => '2026-06-20 15:00:00' ) );
				$has = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . ogc_table( 'cfiles' ) . ' WHERE fkey = %s', $stored ), ARRAY_A );
				if ( $has && '' !== $fi[1] ) {
					ogc_hd_put_file( 2026, $k, $stored, array( 'note' => $fi[1] ) );
				}
			}
			// 2027 carries it by reference, as the app's own carry would have (it ran before the sample).
			if ( $has && ogc_app_committee( 2027, $k ) && ! (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM ' . ogc_table( 'cfiles' ) . ' WHERE year = 2027 AND carried_from = %d', (int) $has['id'] ) ) ) {
				$wpdb->insert( ogc_table( 'cfiles' ), array( 'year' => 2027, 'ckey' => $k, 'name' => $has['name'], 'fkey' => $has['fkey'], 'mime' => $has['mime'], 'size' => (int) $has['size'], 'uploaded_by' => 0, 'carried_from' => (int) $has['id'], 'created_at' => $has['created_at'] ) );
			}
		}
	}
}

add_action( 'init', function () {
	if ( '1' === get_option( 'ogc_hd_seeded' ) || ! OGC_DEV ) {
		return;
	}
	ogc_hd_seed();
	if ( function_exists( 'ogc_app_tables_ready' ) && ogc_app_tables_ready() && ogc_hd_ready() && null !== ogc_year_get( 2026 ) ) {
		update_option( 'ogc_hd_seeded', '1', false );
	}
}, 50 );

add_action( 'ogc_seed_year', function ( $year ) {
	if ( in_array( (int) $year, array( 2026, 2027 ), true ) && OGC_DEV ) {
		ogc_hd_seed();
	}
}, 30 );
