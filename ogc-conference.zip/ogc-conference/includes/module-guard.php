<?php
/**
 * Who may change what, across areas (review fixes, Oct 11). Michael's rule is "committees see only
 * their part": being a member of a year (the COA or any committee's helper) opens the year, not every
 * part of it. The areas' own routes already check their committee; this module closes the generic
 * routes that only asked "a member of the year?":
 *
 *   files     a file the COA's screens don't own (module-coa-app.php ogc_coa_app_file_screen) is the
 *             COA's to change, except shifts (each committee its own rows), tournaments (the Young
 *             Folks committee) and attachments (whoever has the Schedule). Settings keys no screen
 *             claims are the COA's too.
 *   state     the generic state route serves a short allow-list to members; every other key is read
 *             and written through its own module's route (rooms, phones, the volunteer lists, the
 *             published copy, who sees money), or by the COA and webmasters.
 *   records   who reads every record of a kind (ogc_records_all): the COA, plus the committee handed
 *             Registration for registrations and credits, and the Young Folks committee for teams.
 *   people    WordPress's author pages, feeds and user lists never list the people who signed in.
 *   access    who sees people's details (Oct 13, docs/26 decision 25): ogc_access() at the end of this
 *             file is the one rule (households, children, rooms, money), and the routes that hold people
 *             ask it. Webmasters change structure (the guards above let them) but see people only by
 *             seeing as a committee in the app, which is read only and logged. NOTES/security-plan.md.
 */

defined( 'ABSPATH' ) || exit;

/* ================================================================== the viewer */

/** The COA (or a webmaster, or a dev member on a local site): may change any part of the year. */
function ogc_guard_coa( $year ) {
	if ( ogc_is_webmaster() ) {
		return true;
	}
	return function_exists( 'ogc_coa_app_may' ) ? ogc_coa_app_may( (int) $year, '' ) : ogc_is_member( $year );
}

/** The committee keys this viewer works on in the year (never through ?as=, which is read only). */
function ogc_guard_mine( $year ) {
	if ( ! function_exists( 'ogc_app_viewer' ) ) {
		return array();
	}
	$v = ogc_app_viewer( (int) $year );
	return (array) $v['committees'];
}

/** May the viewer see this app screen (and so change what it holds)? */
function ogc_guard_screen( $year, $screen ) {
	if ( ogc_guard_coa( $year ) ) {
		return true;
	}
	return function_exists( 'ogc_app_can_see' ) && function_exists( 'ogc_app_viewer' ) && ogc_app_can_see( ogc_app_viewer( (int) $year ), $screen );
}

function ogc_guard_no() {
	return new WP_Error( 'ogc_not_yours', 'The COA’s · Ask the COA to hand it to your committee', array( 'status' => 403 ) );
}

/* ================================================================== files */

/** The committee keys a shifts change touches: rows added, changed or removed, by their committee. */
function ogc_guard_shift_keys( $before, $after ) {
	$bucket = function ( $rows ) {
		$out = array();
		foreach ( (array) $rows as $r ) {
			if ( ! is_array( $r ) ) {
				continue;
			}
			$k = ogc_committee_key( isset( $r['committee'] ) ? (string) $r['committee'] : '' );
			ksort( $r );
			$out[ $k ][] = wp_json_encode( array_map( 'strval', array_map( function ( $v ) { return is_scalar( $v ) || null === $v ? (string) $v : ''; }, $r ) ) );
		}
		foreach ( $out as &$l ) {
			sort( $l );
		}
		return $out;
	};
	$a    = $bucket( $before );
	$b    = $bucket( $after );
	$keys = array();
	foreach ( array_unique( array_merge( array_keys( $a ), array_keys( $b ) ) ) as $k ) {
		if ( ( isset( $a[ $k ] ) ? $a[ $k ] : array() ) !== ( isset( $b[ $k ] ) ? $b[ $k ] : array() ) ) {
			$keys[] = (string) $k;
		}
	}
	return $keys;
}

/** The committee keys a request to change shifts touches (files PUT/PATCH, or the editors' rows route). */
function ogc_guard_shift_request_keys( $year, $route_kind, WP_REST_Request $req ) {
	$cur  = ogc_file_get( (int) $year, 'shifts' );
	$rows = $cur ? array_values( (array) $cur['rows'] ) : array();
	$ck   = function ( $r ) {
		return ogc_committee_key( is_array( $r ) && isset( $r['committee'] ) ? (string) $r['committee'] : '' );
	};
	if ( 'files' === $route_kind && 'PUT' === $req->get_method() ) {
		return ogc_guard_shift_keys( $rows, (array) $req->get_param( 'rows' ) );
	}
	if ( 'files' === $route_kind ) {
		// PATCH: one row (merged by its key), or a key (shifts have none: the COA's).
		if ( 'row' !== $req->get_param( 'op' ) ) {
			return array( "\0" );
		}
		$row  = (array) $req->get_param( 'row' );
		$keys = array( $ck( $row ) );
		$k    = ogc_file_row_key( 'shifts' );
		foreach ( $rows as $r ) {
			if ( $k && isset( $row[ $k ], $r[ $k ] ) && (string) $r[ $k ] === (string) $row[ $k ] ) {
				$keys[] = $ck( $r );
			}
		}
		return array_values( array_unique( $keys ) );
	}
	// The editors' rows route: each op's row as it is now, and as it will be.
	$by = array();
	foreach ( $rows as $r ) {
		if ( isset( $r['_id'] ) ) {
			$by[ (string) $r['_id'] ] = $r;
		}
	}
	$keys = array();
	foreach ( (array) $req->get_param( 'ops' ) as $op ) {
		if ( ! is_array( $op ) || empty( $op['op'] ) || 'ids' === $op['op'] ) {
			continue;
		}
		if ( 'add' === $op['op'] ) {
			$keys[] = $ck( isset( $op['row'] ) ? $op['row'] : array() );
			continue;
		}
		$id = isset( $op['id'] ) ? (string) $op['id'] : '';
		if ( isset( $by[ $id ] ) ) {
			$keys[] = $ck( $by[ $id ] );
		}
		if ( 'set' === $op['op'] && isset( $op['fields']['committee'] ) ) {
			$keys[] = $ck( array( 'committee' => $op['fields']['committee'] ) );
		}
	}
	return array_values( array_unique( $keys ) );
}

add_filter( 'rest_request_before_callbacks', function ( $resp, $handler, $req ) {
	if ( is_wp_error( $resp ) ) {
		return $resp;
	}
	$route = (string) $req->get_route();
	if ( ! preg_match( '#^/' . preg_quote( OGC_NS, '#' ) . '/years/(\d{4})/(files|rows)/([a-z][a-z0-9_-]*)$#', $route, $m ) ) {
		return $resp;
	}
	$write = 'rows' === $m[2] || in_array( $req->get_method(), array( 'PUT', 'PATCH' ), true );
	$y     = (int) $m[1];
	$name  = $m[3];
	if ( ! $write || ! ogc_is_member( $y ) || ogc_guard_coa( $y ) ) {
		return $resp;   // reads, strangers (the route refuses them) and the COA: as before
	}
	// The COA's screens' own files keep their own rule (module-coa-app.php).
	if ( function_exists( 'ogc_coa_app_file_screen' ) && '' !== ogc_coa_app_file_screen( $name ) ) {
		return $resp;
	}
	switch ( $name ) {
		case 'settings':
			// Keys a screen claims are checked there (module-coa-app, module-app-committees); the rest
			// (sign-ups posted, names shown, how long a place is held…) are the COA's.
			$keys = array();
			if ( 'PATCH' === $req->get_method() ) {
				$keys[] = (string) $req->get_param( 'key' );
				$row    = $req->get_param( 'row' );
				if ( is_array( $row ) && isset( $row['key'] ) ) {
					$keys[] = (string) $row['key'];
				}
			} else {
				$cur = function_exists( 'ogc_coa_kv' ) ? ogc_coa_kv( $y, 'settings' ) : array();
				foreach ( (array) $req->get_param( 'rows' ) as $r ) {
					if ( is_array( $r ) && isset( $r['key'] ) && ( ! isset( $cur[ $r['key'] ] ) || (string) $cur[ $r['key'] ] !== (string) ( isset( $r['value'] ) ? $r['value'] : '' ) ) ) {
						$keys[] = (string) $r['key'];
					}
				}
			}
			foreach ( array_filter( $keys ) as $k ) {
				if ( 0 === strpos( $k, 'tournaments_' ) ) {
					if ( ! ogc_guard_screen( $y, 'yf-teams' ) ) {
						return ogc_guard_no();
					}
					continue;
				}
				if ( 'print_layout' === $k ) {
					if ( ! ogc_guard_screen( $y, 'schedule' ) ) {
						return ogc_guard_no();
					}
					continue;
				}
				if ( function_exists( 'ogc_coa_app_settings_screen' ) && '' !== ogc_coa_app_settings_screen( $k ) ) {
					continue;   // its screen's rule (module-coa-app.php)
				}
				return ogc_guard_no();
			}
			return $resp;
		case 'shifts':
			// Each committee its own shifts; another committee's rows, or moving a shift to one, the COA's.
			$mine = ogc_guard_mine( $y );
			foreach ( ogc_guard_shift_request_keys( $y, $m[2], $req ) as $k ) {
				if ( ! in_array( $k, $mine, true ) ) {
					return new WP_Error( 'ogc_not_yours', 'Another committee’s shifts · Ask the COA', array( 'status' => 403 ) );
				}
			}
			return $resp;
		case 'tournaments':
			return ogc_guard_screen( $y, 'yf-teams' ) ? $resp : ogc_guard_no();
		case 'attachments':
			return ogc_guard_screen( $y, 'schedule' ) ? $resp : ogc_guard_no();
	}
	// committees, milestones, notes and anything else: the COA's.
	return ogc_guard_no();
}, 7, 3 );

/* ================================================================== the year's small values (state) */

/** The state keys the generic route serves to any member of the year, and the screen that may change
 * each ('' = read only there). Everything else is its module's (through its own route) or the COA's. */
function ogc_guard_state_open() {
	return (array) apply_filters( 'ogc_state_open_keys', array(
		'picked'       => '',
		'started'      => '',
		'print_status' => 'schedule',
	) );
}

/** Keys that hold people, read through the generic route by the COA only (each is shown to its
 * committee through its own route): Lodging's rooms, the COA's phones, the volunteer heads' messages and
 * notes, the treasurer's marks, and who sees children's details or money. */
function ogc_guard_state_people( $key ) {
	return (bool) preg_match( '/^(rooms|app-phones|vol-(msgs|notify|notes|people|snap|changes)|pay_marks|pay_reminded|payment_viewers|preteen_viewers|money_people)$/', (string) $key );
}

/** Keys no one changes through the generic route, the COA and webmasters included: each is written by
 * its own module (Publish, Lodging's rooms, the treasurer's list, the volunteer lists). */
function ogc_guard_state_owned( $key ) {
	return (bool) preg_match( '/^(rooms|public_row|live_.*|app-.*|vol-.*|coa|members|reg_seq|money_people|payment_viewers|preteen_viewers|pay_marks|pay_reminded|lists_.*|campus_undo|exported)$/', (string) $key );
}

add_filter( 'rest_request_before_callbacks', function ( $resp, $handler, $req ) {
	if ( is_wp_error( $resp ) ) {
		return $resp;
	}
	if ( ! preg_match( '#^/' . preg_quote( OGC_NS, '#' ) . '/years/(\d{4})/state/(.+)$#', (string) $req->get_route(), $m ) ) {
		return $resp;
	}
	$y    = (int) $m[1];
	$key  = (string) $m[2];
	$open = ogc_guard_state_open();
	if ( ! ogc_is_member( $y ) ) {
		return $resp;   // the route refuses
	}
	if ( 'GET' === $req->get_method() ) {
		if ( isset( $open[ $key ] ) ) {
			return $resp;
		}
		// Values that hold people (where each household sleeps, phones, heads' messages, who handles
		// money): the COA's here; a webmaster isn't the COA (decision 25: people only by seeing as).
		if ( ogc_guard_state_people( $key ) ) {
			return ogc_access_coa( $y ) ? $resp : new WP_Error( 'ogc_forbidden', 'Not allowed.', array( 'status' => 403 ) );
		}
		if ( ogc_guard_coa( $y ) ) {
			return $resp;
		}
		return new WP_Error( 'ogc_forbidden', 'Not allowed.', array( 'status' => 403 ) );
	}
	if ( isset( $open[ $key ] ) ) {
		return '' !== $open[ $key ] && ogc_guard_screen( $y, $open[ $key ] ) ? $resp : ogc_guard_no();
	}
	if ( ogc_guard_state_owned( $key ) ) {
		return ogc_is_webmaster() ? $resp : new WP_Error( 'ogc_forbidden', 'Changed through its own page.', array( 'status' => 403 ) );
	}
	return ogc_guard_coa( $y ) ? $resp : ogc_guard_no();
}, 5, 3 );

/* ================================================================== every record of a kind */

// The committee the COA hands its Households screen reads households (never Registration's: that's
// prices and dates, critique Oct 14); the Young Folks committee reads the teams. Everyone else on a
// committee works through their committee's routes. The real viewer only (ogc_access_screen): a
// webmaster never reads everyone's records here (decision 25).
add_filter( 'ogc_records_all', function ( $ok, $year, $kind ) {
	if ( $ok ) {
		return true;
	}
	if ( in_array( $kind, array( 'registrations', 'credits' ), true ) ) {
		return ogc_access_screen( $year, 'households' );
	}
	if ( 'teams' === $kind ) {
		return ogc_access_screen( $year, 'yf-teams' );
	}
	return false;
}, 10, 3 );

// The volunteer page reads its shifts through /vol/{y}; it never loads the year's records.
add_filter( 'ogc_client_config', function ( $cfg, $key ) {
	if ( 'volunteer' === $key ) {
		$cfg['recordKinds'] = array();
	}
	// The form needs only this person's own sign-ups and teams, never others'.
	if ( 'register' === $key ) {
		$cfg['recordScope'] = 'mine';
	}
	return $cfg;
}, 20, 2 );

/* ================================================================== the people who signed in */

/** One of the plugin's own people (a household, a volunteer, a parent), not a site author. */
function ogc_guard_person( $user ) {
	$user = is_object( $user ) ? $user : get_userdata( (int) $user );
	if ( ! $user ) {
		return false;
	}
	if ( function_exists( 'ogc_is_person_only' ) && ogc_is_person_only( $user->ID ) ) {
		return true;
	}
	return in_array( 'ogc_person', (array) $user->roles, true );
}

// WordPress answers /?author=N and /author/<name>/ (and their feeds) for any user, posts or not: a
// stranger could walk the ids and list everyone who registered or volunteered. Not for our people.
add_action( 'template_redirect', function () {
	if ( ! is_author() ) {
		return;
	}
	$u = get_queried_object();
	if ( $u instanceof WP_User && ogc_guard_person( $u ) ) {
		global $wp_query;
		$wp_query->set_404();
		status_header( 404 );
		nocache_headers();
	}
}, 1 );

// Their author links, the sitemap's users and the REST users list leave them out.
add_filter( 'author_link', function ( $link, $author_id ) {
	return ogc_guard_person( (int) $author_id ) ? '' : $link;
}, 10, 2 );

add_filter( 'wp_sitemaps_users_query_args', function ( $args ) {
	$args['role__not_in'] = array_merge( isset( $args['role__not_in'] ) ? (array) $args['role__not_in'] : array(), array( 'ogc_person' ) );
	return $args;
} );

add_filter( 'rest_user_query', function ( $args ) {
	$args['role__not_in'] = array_merge( isset( $args['role__not_in'] ) ? (array) $args['role__not_in'] : array(), array( 'ogc_person' ) );
	return $args;
} );

// wp-admin › Users doesn't list them either, for anyone, site admins included (decision 25: a site admin
// doesn't browse Conference people; someone's own records are reached by a privacy request, Tools ›
// Export or Erase Personal Data, by email). Their role's filter link goes too. A site that needs the
// list back: add_filter( 'ogc_admin_list_people', '__return_true' ).
add_filter( 'users_list_table_query_args', function ( $args ) {
	if ( apply_filters( 'ogc_admin_list_people', false ) ) {
		return $args;
	}
	$args['role__not_in'] = array_merge( isset( $args['role__not_in'] ) ? (array) $args['role__not_in'] : array(), array( 'ogc_person' ) );
	return $args;
} );

add_filter( 'views_users', function ( $views ) {
	if ( ! apply_filters( 'ogc_admin_list_people', false ) ) {
		unset( $views['ogc_person'] );
	}
	return $views;
} );

/* ================================================================== committees.csv's contacts */

// committees.csv carries each committee's contact (its head's own email and phone, for the volunteer
// shifts' Monday email). A helper sees their own committees' contacts; others' only the COA.
add_filter( 'ogc_file_rows_out', function ( $rows, $year, $name ) {
	if ( 'committees' !== $name || ogc_guard_coa( $year ) ) {
		return $rows;
	}
	$mine = ogc_guard_mine( $year );
	foreach ( $rows as &$r ) {
		if ( is_array( $r ) && ! in_array( ogc_committee_key( isset( $r['name'] ) ? (string) $r['name'] : '' ), $mine, true ) ) {
			foreach ( array( 'contact_email', 'contact_phone', 'heads' ) as $k ) {
				if ( isset( $r[ $k ] ) ) {
					$r[ $k ] = '';
				}
			}
		}
	}
	unset( $r );
	return $rows;
}, 20, 3 );

/* ================================================================== the year's export */

// The year's export (every file, for the record) is the COA's and the webmasters': it read the files
// whole, around the read filters, for any helper of the year.
add_filter( 'rest_request_before_callbacks', function ( $resp, $handler, $req ) {
	if ( is_wp_error( $resp ) || ! preg_match( '#^/' . preg_quote( OGC_NS, '#' ) . '/years/(\d{4})/export$#', (string) $req->get_route(), $m ) ) {
		return $resp;
	}
	return ! ogc_is_member( (int) $m[1] ) || ogc_guard_coa( (int) $m[1] ) ? $resp : ogc_guard_no();
}, 5, 3 );

/* ================================================================== samples */

// Clearing a year's samples (DELETE /years/{y}/samples) also lets go of what the areas kept beside
// them: places on shifts held by sample sign-ups, the sample ledger, and sample notes.
add_action( 'ogc_samples_cleared', function ( $year, $kind ) {
	if ( function_exists( 'ogc_vol_seats_tidy' ) && ( ! $kind || in_array( $kind, array( 'signups', 'waits' ), true ) ) ) {
		ogc_vol_seats_tidy( (int) $year );
	}
	if ( function_exists( 'ogc_pay_clear_samples' ) && ( ! $kind || 'registrations' === $kind ) ) {
		ogc_pay_clear_samples( (int) $year );
	}
	if ( ! $kind || 'signups' === $kind ) {
		$n = ogc_state_get( (int) $year, 'vol-notes' );
		if ( $n && is_array( $n['value'] ) ) {
			$keep = array_filter( $n['value'], function ( $x ) {
				return ! ( is_array( $x ) && ! empty( $x['sample'] ) );
			} );
			if ( count( $keep ) !== count( $n['value'] ) ) {
				ogc_state_put( (int) $year, 'vol-notes', $keep ? $keep : new stdClass() );
			}
		}
	}
}, 10, 2 );

// Volunteer sign-ups aren't posted on ogbbc.org while made-up volunteers are in the year (as
// registration doesn't open while sample households are): their names would sit on real shifts.
add_filter( 'rest_request_before_callbacks', function ( $resp, $handler, $req ) {
	if ( is_wp_error( $resp ) || ! preg_match( '#^/' . preg_quote( OGC_NS, '#' ) . '/coa/(\d{4})/publish$#', (string) $req->get_route(), $m ) ) {
		return $resp;
	}
	if ( 'helping' !== (string) $req->get_param( 'part' ) || ! in_array( (string) $req->get_param( 'act' ), array( 'publish', 'reopen' ), true ) || ( function_exists( 'ogc_seed_samples' ) && ogc_seed_samples() ) ) {
		return $resp;
	}
	global $wpdb;
	$n = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM ' . ogc_table( 'records' ) . " WHERE year = %d AND kind IN ('signups','waits') AND sample = 1 AND deleted_at IS NULL", (int) $m[1] ) );
	return $n ? new WP_Error( 'ogc_samples', 'Sample volunteers in the year · A webmaster clears them first', array( 'status' => 409 ) ) : $resp;
}, 8, 3 );

/* ================================================================== loading the years on ogbbc.org */

// Activation on ogbbc.org makes the tables only (ogc_seed_on_activate). A webmaster then loads the
// plugin's reviewed years.csv and years' files once, deliberately: no made-up people, and a year still
// to come keeps everything waiting for the COA's Publish (ogc_seed_hold_back). A year already in the
// tables is never touched.
add_action( 'rest_api_init', function () {
	register_rest_route( OGC_NS, '/seed', array(
		'methods'             => 'POST',
		'callback'            => function () {
			$done = function_exists( 'ogc_import_seed' ) ? ogc_import_seed( false ) : array();
			ogc_log( 'seed_load', 0, 'seed', array( 'years' => array_keys( $done ) ) );
			return rest_ensure_response( array( 'loaded' => (object) $done ) );
		},
		'permission_callback' => 'ogc_can_webmaster',
	) );
} );

/* ================================================================== a parent's approval link */

// The parent's link carries its token in the address (/register/?year=…&approve=TOKEN). Like the
// sign-in links, it's moved into a short cookie (this page's path, an hour, same site) and the page
// opens at a clean address, so the token isn't kept in history or passed on in a referrer.
add_action( 'ogc_before_page', function ( $page ) {
	// phpcs:ignore WordPress.Security.NonceVerification -- a link from an email; nothing changes here.
	$t = 'register' === $page && isset( $_GET['approve'] ) ? sanitize_text_field( wp_unslash( $_GET['approve'] ) ) : '';
	if ( ! preg_match( '/^(\d{4})\.[a-z0-9]{32}$/', $t, $m ) || headers_sent() ) {
		return;
	}
	$path = wp_make_link_relative( ogc_url( 'register' ) );
	setcookie( 'ogc_approve', $t, array( 'expires' => time() + HOUR_IN_SECONDS, 'path' => $path, 'secure' => is_ssl(), 'httponly' => false, 'samesite' => 'Strict' ) );
	nocache_headers();
	wp_safe_redirect( ogc_url( 'register', array( 'year' => $m[1], 'approve' => '1' ) ), 303 );
	exit;
}, 4 );

/* ================================================================== one value, not a list */

// The routes read these as one value each (an email, a code, a date, an id). Sent as a list or an
// object, PHP warned "Array to string conversion" inside the callback (and with WP_DEBUG_DISPLAY on, the
// warning broke the JSON). Refused first, as WordPress's own args would (review, Oct 11).
function ogc_guard_scalar_params() {
	return (array) apply_filters( 'ogc_scalar_params', array( 'id', 'name', 'email', 'committee', 'format', 'as', 'as_of', 'part', 'c', 'shift', 'phone', 'key', 'what', 'scope', 'method', 'to', 'role', 'date', 'view', 'title', 'subject', 'sort', 'screen', 'preview', 'owner', 'op', 'link', 'hp', 'act', 't', 'source', 'ref', 'mode', 'offset', 'tid', 'text', 'kinds', 'kind', 'idem', 'how', 'hosts', 'hall', 'group', 'from', 'for', 'decision', 'code', 'closes', 'opens', 'reason', 'outcome', 'return', 'label', 'start', 'end', 'limit', 'version', 'year', 'cents', 'note', 'pay', 'step', 'v', 'at', 'money', 'own_email', 'received' ) );
}

add_filter( 'rest_request_before_callbacks', function ( $resp, $handler, $req ) {
	if ( is_wp_error( $resp ) || 0 !== strpos( (string) $req->get_route(), '/' . OGC_NS . '/' ) ) {
		return $resp;
	}
	foreach ( ogc_guard_scalar_params() as $p ) {
		$v = $req->get_param( $p );
		if ( null !== $v && ! is_scalar( $v ) ) {
			return new WP_Error( 'rest_invalid_param', 'One value: ' . $p, array( 'status' => 400, 'params' => array( $p => 'One value' ) ) );
		}
	}
	return $resp;
}, 1, 3 );

/* ================================================================== who sees people (decision 25) */

/*
 * The one rule for people's details (Oct 13: docs/26 decision 25, tentatively agreed; docs/scope/06,
 * "What each role sees and can change"; the Advisors' security plan, Nov 6: NOTES/security-plan.md).
 * Every route that holds people asks it. It reads the real viewer: never ?as= (See as reads through the
 * app's own routes, read only and logged) and never a webmaster for being one. A webmaster who is also on
 * the year (the COA, or a committee) sees what that place sees, like anyone on it. A webmaster can't
 * put themselves on a year (module-members.php): another webmaster or the COA does, and Privacy lists it.
 *
 *   households  enter a household (the desk, a paper form, a call) and open or change any registration:
 *               the COA, Lodging (its Households screen) and the committee the COA hands the COA's
 *               Households screen (the hand pill says so and asks first). Never Registration: that's
 *               prices and dates, not people (critique, Oct 14).
 *   children    preteens' medical notes, emergency contacts, who may pick a child up: the COA and the
 *               Preteens committee (its Children screen); the person who entered a household at the
 *               desk, that same day only, to correct what they typed (ogc_reg_children_ok)
 *   rooms       where each household sleeps: the COA and Lodging (its Rooms screen)
 *   yf_rooms    each Young Folk's hall, room and rooming note: the COA, Lodging, Young Folks (Halls)
 *   money       each payment line (checks received, refunds, the ledger): the members the COA ticks
 *               Handles money on Members, and no one else; with no one ticked, no one
 *   desk_pay    a payment taken at the desk: Handles money, or Lodging (its Check-in screen)
 *
 * Which committee holds a screen follows the COA's handing (ogc_app_can_see); who is on a committee is
 * the COA's (Members). Nothing here names a committee's people. Filter: ogc_access( $ok, $year, $what ).
 */

/** The real viewer of a year (the app's, without ?as=). */
function ogc_access_viewer( $year ) {
	$y = (int) $year;
	if ( function_exists( 'ogc_app_viewer' ) && function_exists( 'ogc_app_tables_ready' ) && ogc_app_tables_ready() ) {
		return ogc_app_viewer( $y );
	}
	// Before the app's tables exist (a fresh install): the members list alone.
	$m = function_exists( 'ogc_member_me' ) ? ogc_member_me( $y ) : null;
	return array(
		'year'       => $y,
		'coa'        => $m && 'coa' === $m['role'],
		'webmaster'  => ogc_is_webmaster(),
		'committees' => $m && function_exists( 'ogc_member_committee_keys' ) ? ogc_member_committee_keys( $m ) : array(),
		'open'       => (bool) $m,
		'as'         => '',
	);
}

/** On the year's COA (a webmaster only when also on the COA; a dev member on a local site). */
function ogc_access_coa( $year ) {
	if ( ! is_user_logged_in() || ! ogc_valid_year( $year ) ) {
		return false;
	}
	$v = ogc_access_viewer( $year );
	return ! empty( $v['coa'] );
}

/** May the real viewer open this app screen (the COA, the committee it belongs to or was handed to)?
 * A webmaster passes only for the webmasters' own screens (Members, Years), never a committee's. */
function ogc_access_screen( $year, $screen ) {
	if ( ! is_user_logged_in() || ! ogc_valid_year( $year ) ) {
		return false;
	}
	if ( ! function_exists( 'ogc_app_can_see' ) ) {
		return ogc_access_coa( $year );
	}
	return ogc_app_can_see( ogc_access_viewer( $year ), (string) $screen );
}

/** Ticked Handles money by the COA (Members), and still on the year. */
function ogc_access_money( $year ) {
	$me = ogc_current_email();
	if ( '' === $me || ! function_exists( 'ogc_member_me' ) || ! function_exists( 'ogc_member_handles_money' ) || ! ogc_member_me( (int) $year ) ) {
		return false;
	}
	return ogc_member_handles_money( (int) $year, $me );
}

/** May the signed-in person see (or act on) this kind of people's details for the year? */
function ogc_access( $year, $what ) {
	$y = (int) $year;
	if ( ! ogc_valid_year( $y ) || ! is_user_logged_in() ) {
		return false;
	}
	// Handles money needs an active row of one's own on the year (a removed member keeps no tick).
	$email = in_array( $what, array( 'money', 'desk_pay', 'owed' ), true ) && function_exists( 'ogc_member_me' ) && ogc_member_me( $y ) ? ogc_current_email() : '';
	return (bool) apply_filters( 'ogc_access', ogc_access_for( ogc_access_viewer( $y ), $y, (string) $what, $email ), $y, (string) $what );
}

/**
 * The rule itself, for any viewer (the app's viewer array: coa, committees, open) and their address
 * (for Handles money). ogc_access() asks it for the signed-in person; the Privacy screen asks it for
 * each member of the year, so what the page says is what the server does.
 */
function ogc_access_for( $v, $year, $what, $email = '' ) {
	$coa = ! empty( $v['coa'] );
	$see = function ( $screen ) use ( $v ) {
		return function_exists( 'ogc_app_can_see' ) && ogc_app_can_see( $v, $screen );
	};
	$money = '' !== (string) $email && function_exists( 'ogc_member_handles_money' ) && ogc_member_handles_money( (int) $year, $email );
	switch ( (string) $what ) {
		case 'households':
			// Lodging's Households, and the COA's Households (night-records) when handed. Not Registration.
			return $coa || $see( 'lod-households' ) || $see( 'households' );
		case 'children':
			return $coa || $see( 'preteens-list' );
		case 'rooms':
			return $coa || $see( 'lod-rooms' );
		case 'yf_rooms':
			return $coa || $see( 'lod-rooms' ) || $see( 'yf-halls' );
		case 'money':
			return $money;
		case 'desk_pay':
			return $money || $see( 'lod-checkin' );
		case 'owed':
			// What each household owes (paid or due, never the payment lines): Lodging's households list,
			// the COA's records, Handles money.
			return $money || $coa || $see( 'lod-households' ) || $see( 'households' );
		case 'meals':
			return $coa || $see( 'food-meals' );
		case 'communion':
			return $coa || $see( 'communion-list' );
	}
	return false;
}

/** The rows the Privacy screen draws, in order: the kind, its words, and who may (ogc_access_for). */
function ogc_access_rules() {
	return array(
		array( 'key' => 'children', 'what' => 'Children’s details', 'detail' => 'Medical notes, emergency contacts, who may pick up' ),
		array( 'key' => 'households', 'what' => 'Households', 'detail' => 'Names, ages, phones, nights, needs, the note' ),
		array( 'key' => 'rooms', 'what' => 'Rooms', 'detail' => 'Where each household sleeps' ),
		array( 'key' => 'yf_rooms', 'what' => 'Young Folks’ halls', 'detail' => 'Hall, room, nights, under 18, rooming note' ),
		array( 'key' => 'money', 'what' => 'Each payment', 'detail' => 'Checks, card payments, refunds' ),
		array( 'key' => 'owed', 'what' => 'Paid or due', 'detail' => 'Per household, never the payments' ),
		array( 'key' => 'meals', 'what' => 'Meal counts', 'detail' => 'Counts per meal, no names' ),
		array( 'key' => 'communion', 'what' => 'Communing', 'detail' => 'Households and how many commune' ),
	);
}

/**
 * The screens the COA can hand that carry people's details, and what handing one gives the committee,
 * in words. The hand pill shows it before the tap and asks Yes · No; the hand route refuses without
 * `confirm` (module-app-rest.php). Filter: ogc_access_hand_people.
 */
function ogc_access_hand_people() {
	return (array) apply_filters( 'ogc_access_hand_people', array(
		'households' => 'Opens every household · Names, phones, emails',
	) );
}

function ogc_access_no( $msg = 'Not allowed.' ) {
	return new WP_Error( 'ogc_forbidden', $msg, array( 'status' => is_user_logged_in() ? 403 : 401 ) );
}

// The routes that hold people and aren't already a committee screen's (those ask ogc_app_can_see):
// the treasurer's lists, a tournament team changed by someone else, and choosing who handles money.
// Each asks the rule above; the routes' own checks still run after.
add_filter( 'rest_request_before_callbacks', function ( $resp, $handler, $req ) {
	if ( is_wp_error( $resp ) ) {
		return $resp;
	}
	$route = (string) $req->get_route();
	$ns    = '#^/' . preg_quote( OGC_NS, '#' );
	$m     = array();
	// Money: each payment (Handles money); a payment at the desk (Lodging too); the COA names who.
	if ( preg_match( $ns . '/lists/(\d{4})/(pay|pay/undo|pay/remind|pay/add|access)$#', $route, $m ) ) {
		$y = (int) $m[1];
		if ( ! is_user_logged_in() ) {
			return ogc_access_no( 'Sign in first.' );
		}
		if ( 'access' === $m[2] ) {
			if ( 'GET' !== $req->get_method() && ! ogc_access_coa( $y ) ) {
				return ogc_access_no( 'The COA chooses' );
			}
			// The Money screen's Choose treasurer writes the same list as Members' Handles money: nobody
			// adds their own address there either (another COA member does; critique, Oct 14).
			$me = ogc_current_email();
			if ( 'GET' !== $req->get_method() && 'payments' === (string) $req->get_param( 'list' ) && '' !== $me && ! ogc_member_handles_money( $y, $me )
				&& in_array( $me, array_map( function ( $e ) { return strtolower( trim( (string) $e ) ); }, array_filter( (array) $req->get_param( 'emails' ), 'is_scalar' ) ), true ) ) {
				return ogc_access_no( 'Another COA member ticks it' );
			}
			return $resp;
		}
		if ( 'pay/add' === $m[2] ) {
			return ogc_access( $y, 'desk_pay' ) ? $resp : ogc_access_no( 'Handles money only' );
		}
		return ogc_access( $y, 'money' ) ? $resp : ogc_access_no( 'Handles money only' );
	}
	// A tournament team: its own signer, or the Young Folks committee and the COA (never another
	// committee's helper, nor a webmaster for being one).
	if ( preg_match( $ns . '/tn/r/(\d+)(/restore)?$#', $route, $m ) && 'GET' !== $req->get_method() ) {
		$r = ogc_record_get( (int) $m[1] );
		if ( $r && 'teams' === $r['kind'] && ! ( ogc_current_email() && $r['email'] === ogc_current_email() ) && ! ogc_access_screen( (int) $r['year'], 'yf-teams' ) ) {
			return is_user_logged_in() ? new WP_Error( 'ogc_not_found', 'Not found.', array( 'status' => 404 ) ) : ogc_access_no( 'Sign in first.' );
		}
	}
	return $resp;
}, 5, 3 );

// Seeing as is logged however the data is asked for (the app's boot logs it too; once in 30 minutes per
// person, year and committee): a screen's route called with ?as= on its own is logged the same.
add_filter( 'rest_request_before_callbacks', function ( $resp, $handler, $req ) {
	if ( is_wp_error( $resp ) || ! function_exists( 'ogc_app_log_see_as' ) || ! function_exists( 'ogc_app_viewer' ) ) {
		return $resp;
	}
	$as = $req->get_param( 'as' );
	if ( ! is_string( $as ) || '' === $as || ! preg_match( '#^/' . preg_quote( OGC_NS, '#' ) . '/(?:app/|years/|lists/|vol/|tn/)(\d{4})\b#', (string) $req->get_route(), $m ) ) {
		return $resp;
	}
	$v = ogc_app_viewer( (int) $m[1], $as );
	if ( ! empty( $v['as'] ) ) {
		ogc_app_log_see_as( $v );
	}
	return $resp;
}, 9, 3 );

// Paper forms (registration.csv paper_forms: "no" · "yes", the COA's Registration screen): only when the
// COA chooses "Lodging enters them" is a registration entered with Source Paper (docs/scope/02, flow K).
// Who may enter one at all is ogc_reg_enters (the COA, Lodging, the committee handed Registration).
add_filter( 'rest_request_before_callbacks', function ( $resp, $handler, $req ) {
	if ( is_wp_error( $resp ) || 'POST' !== $req->get_method() || ! preg_match( '#^/' . preg_quote( OGC_NS, '#' ) . '/reg/(\d{4})$#', (string) $req->get_route(), $m ) ) {
		return $resp;
	}
	if ( 'paper' !== (string) $req->get_param( 'source' ) || ! function_exists( 'ogc_reg_enters' ) || ! ogc_reg_enters( (int) $m[1] ) ) {
		return $resp;   // anyone else's source is ignored by the route
	}
	$cfg = function_exists( 'ogc_reg_cfg' ) ? ogc_reg_cfg( (int) $m[1] ) : array();
	if ( 'yes' !== strtolower( trim( isset( $cfg['paper_forms'] ) ? (string) $cfg['paper_forms'] : '' ) ) ) {
		return new WP_Error( 'ogc_paper_off', 'Paper forms off · Registration settings', array( 'status' => 400 ) );
	}
	return $resp;
}, 8, 3 );
