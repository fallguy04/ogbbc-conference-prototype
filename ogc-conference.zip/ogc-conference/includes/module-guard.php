<?php
/**
 * Who may change what, across areas (review fixes, Oct 11). Michael's rule is "committees see only
 * their part": being a member of a year (the COA or any committee's helper) opens the year, not every
 * part of it. The areas' own routes already check their committee; this module closes the generic
 * routes that only asked "a member of the year?":
 *
 *   files     a file the COA's screens don't own (module-coa-app.php ogc_coa_app_file_screen) is the
 *             COA's to change, except shifts (each committee its own rows), tournaments (the Young
 *             Folks committee) and attachments (whoever has the Schedule). Settings keys no screen
 *             claims are the COA's too.
 *   state     the generic state route serves a short allow-list to members; every other key is read
 *             and written through its own module's route (rooms, phones, the volunteer lists, the
 *             published copy, who sees money), or by the COA and webmasters.
 *   records   who reads every record of a kind (ogc_records_all): the COA, plus the committee handed
 *             Registration for registrations and credits, and the Young Folks committee for teams.
 *   people    WordPress's author pages, feeds and user lists never list the people who signed in.
 */

defined( 'ABSPATH' ) || exit;

/* ================================================================== the viewer */

/** The COA (or a webmaster, or a dev member on a local site): may change any part of the year. */
function ogc_guard_coa( $year ) {
	if ( ogc_is_webmaster() ) {
		return true;
	}
	return function_exists( 'ogc_coa_app_may' ) ? ogc_coa_app_may( (int) $year, '' ) : ogc_is_member( $year );
}

/** The committee keys this viewer works on in the year (never through ?as=, which is read only). */
function ogc_guard_mine( $year ) {
	if ( ! function_exists( 'ogc_app_viewer' ) ) {
		return array();
	}
	$v = ogc_app_viewer( (int) $year );
	return (array) $v['committees'];
}

/** May the viewer see this app screen (and so change what it holds)? */
function ogc_guard_screen( $year, $screen ) {
	if ( ogc_guard_coa( $year ) ) {
		return true;
	}
	return function_exists( 'ogc_app_can_see' ) && function_exists( 'ogc_app_viewer' ) && ogc_app_can_see( ogc_app_viewer( (int) $year ), $screen );
}

function ogc_guard_no() {
	return new WP_Error( 'ogc_not_yours', 'The COA’s · Ask the COA to hand it to your committee', array( 'status' => 403 ) );
}

/* ================================================================== files */

/** The committee keys a shifts change touches: rows added, changed or removed, by their committee. */
function ogc_guard_shift_keys( $before, $after ) {
	$bucket = function ( $rows ) {
		$out = array();
		foreach ( (array) $rows as $r ) {
			if ( ! is_array( $r ) ) {
				continue;
			}
			$k = ogc_committee_key( isset( $r['committee'] ) ? (string) $r['committee'] : '' );
			ksort( $r );
			$out[ $k ][] = wp_json_encode( array_map( 'strval', array_map( function ( $v ) { return is_scalar( $v ) || null === $v ? (string) $v : ''; }, $r ) ) );
		}
		foreach ( $out as &$l ) {
			sort( $l );
		}
		return $out;
	};
	$a    = $bucket( $before );
	$b    = $bucket( $after );
	$keys = array();
	foreach ( array_unique( array_merge( array_keys( $a ), array_keys( $b ) ) ) as $k ) {
		if ( ( isset( $a[ $k ] ) ? $a[ $k ] : array() ) !== ( isset( $b[ $k ] ) ? $b[ $k ] : array() ) ) {
			$keys[] = (string) $k;
		}
	}
	return $keys;
}

/** The committee keys a request to change shifts touches (files PUT/PATCH, or the editors' rows route). */
function ogc_guard_shift_request_keys( $year, $route_kind, WP_REST_Request $req ) {
	$cur  = ogc_file_get( (int) $year, 'shifts' );
	$rows = $cur ? array_values( (array) $cur['rows'] ) : array();
	$ck   = function ( $r ) {
		return ogc_committee_key( is_array( $r ) && isset( $r['committee'] ) ? (string) $r['committee'] : '' );
	};
	if ( 'files' === $route_kind && 'PUT' === $req->get_method() ) {
		return ogc_guard_shift_keys( $rows, (array) $req->get_param( 'rows' ) );
	}
	if ( 'files' === $route_kind ) {
		// PATCH: one row (merged by its key), or a key (shifts have none: the COA's).
		if ( 'row' !== $req->get_param( 'op' ) ) {
			return array( "\0" );
		}
		$row  = (array) $req->get_param( 'row' );
		$keys = array( $ck( $row ) );
		$k    = ogc_file_row_key( 'shifts' );
		foreach ( $rows as $r ) {
			if ( $k && isset( $row[ $k ], $r[ $k ] ) && (string) $r[ $k ] === (string) $row[ $k ] ) {
				$keys[] = $ck( $r );
			}
		}
		return array_values( array_unique( $keys ) );
	}
	// The editors' rows route: each op's row as it is now, and as it will be.
	$by = array();
	foreach ( $rows as $r ) {
		if ( isset( $r['_id'] ) ) {
			$by[ (string) $r['_id'] ] = $r;
		}
	}
	$keys = array();
	foreach ( (array) $req->get_param( 'ops' ) as $op ) {
		if ( ! is_array( $op ) || empty( $op['op'] ) || 'ids' === $op['op'] ) {
			continue;
		}
		if ( 'add' === $op['op'] ) {
			$keys[] = $ck( isset( $op['row'] ) ? $op['row'] : array() );
			continue;
		}
		$id = isset( $op['id'] ) ? (string) $op['id'] : '';
		if ( isset( $by[ $id ] ) ) {
			$keys[] = $ck( $by[ $id ] );
		}
		if ( 'set' === $op['op'] && isset( $op['fields']['committee'] ) ) {
			$keys[] = $ck( array( 'committee' => $op['fields']['committee'] ) );
		}
	}
	return array_values( array_unique( $keys ) );
}

add_filter( 'rest_request_before_callbacks', function ( $resp, $handler, $req ) {
	if ( is_wp_error( $resp ) ) {
		return $resp;
	}
	$route = (string) $req->get_route();
	if ( ! preg_match( '#^/' . preg_quote( OGC_NS, '#' ) . '/years/(\d{4})/(files|rows)/([a-z][a-z0-9_-]*)$#', $route, $m ) ) {
		return $resp;
	}
	$write = 'rows' === $m[2] || in_array( $req->get_method(), array( 'PUT', 'PATCH' ), true );
	$y     = (int) $m[1];
	$name  = $m[3];
	if ( ! $write || ! ogc_is_member( $y ) || ogc_guard_coa( $y ) ) {
		return $resp;   // reads, strangers (the route refuses them) and the COA: as before
	}
	// The COA's screens' own files keep their own rule (module-coa-app.php).
	if ( function_exists( 'ogc_coa_app_file_screen' ) && '' !== ogc_coa_app_file_screen( $name ) ) {
		return $resp;
	}
	switch ( $name ) {
		case 'settings':
			// Keys a screen claims are checked there (module-coa-app, module-app-committees); the rest
			// (sign-ups posted, names shown, how long a place is held…) are the COA's.
			$keys = array();
			if ( 'PATCH' === $req->get_method() ) {
				$keys[] = (string) $req->get_param( 'key' );
				$row    = $req->get_param( 'row' );
				if ( is_array( $row ) && isset( $row['key'] ) ) {
					$keys[] = (string) $row['key'];
				}
			} else {
				$cur = function_exists( 'ogc_coa_kv' ) ? ogc_coa_kv( $y, 'settings' ) : array();
				foreach ( (array) $req->get_param( 'rows' ) as $r ) {
					if ( is_array( $r ) && isset( $r['key'] ) && ( ! isset( $cur[ $r['key'] ] ) || (string) $cur[ $r['key'] ] !== (string) ( isset( $r['value'] ) ? $r['value'] : '' ) ) ) {
						$keys[] = (string) $r['key'];
					}
				}
			}
			foreach ( array_filter( $keys ) as $k ) {
				if ( 0 === strpos( $k, 'tournaments_' ) ) {
					if ( ! ogc_guard_screen( $y, 'yf-teams' ) ) {
						return ogc_guard_no();
					}
					continue;
				}
				if ( 'print_layout' === $k ) {
					if ( ! ogc_guard_screen( $y, 'schedule' ) ) {
						return ogc_guard_no();
					}
					continue;
				}
				if ( function_exists( 'ogc_coa_app_settings_screen' ) && '' !== ogc_coa_app_settings_screen( $k ) ) {
					continue;   // its screen's rule (module-coa-app.php)
				}
				return ogc_guard_no();
			}
			return $resp;
		case 'shifts':
			// Each committee its own shifts; another committee's rows, or moving a shift to one, the COA's.
			$mine = ogc_guard_mine( $y );
			foreach ( ogc_guard_shift_request_keys( $y, $m[2], $req ) as $k ) {
				if ( ! in_array( $k, $mine, true ) ) {
					return new WP_Error( 'ogc_not_yours', 'Another committee’s shifts · Ask the COA', array( 'status' => 403 ) );
				}
			}
			return $resp;
		case 'tournaments':
			return ogc_guard_screen( $y, 'yf-teams' ) ? $resp : ogc_guard_no();
		case 'attachments':
			return ogc_guard_screen( $y, 'schedule' ) ? $resp : ogc_guard_no();
	}
	// committees, milestones, notes and anything else: the COA's.
	return ogc_guard_no();
}, 7, 3 );

/* ================================================================== the year's small values (state) */

/** The state keys the generic route serves to any member of the year, and the screen that may change
 * each ('' = read only there). Everything else is its module's (through its own route) or the COA's. */
function ogc_guard_state_open() {
	return (array) apply_filters( 'ogc_state_open_keys', array(
		'picked'       => '',
		'started'      => '',
		'print_status' => 'schedule',
	) );
}

/** Keys no one changes through the generic route, the COA and webmasters included: each is written by
 * its own module (Publish, Lodging's rooms, the treasurer's list, the volunteer lists). */
function ogc_guard_state_owned( $key ) {
	return (bool) preg_match( '/^(rooms|public_row|live_.*|app-.*|vol-.*|coa|members|reg_seq|money_people|payment_viewers|preteen_viewers|pay_marks|pay_reminded|lists_.*|campus_undo|exported)$/', (string) $key );
}

add_filter( 'rest_request_before_callbacks', function ( $resp, $handler, $req ) {
	if ( is_wp_error( $resp ) ) {
		return $resp;
	}
	if ( ! preg_match( '#^/' . preg_quote( OGC_NS, '#' ) . '/years/(\d{4})/state/(.+)$#', (string) $req->get_route(), $m ) ) {
		return $resp;
	}
	$y    = (int) $m[1];
	$key  = (string) $m[2];
	$open = ogc_guard_state_open();
	if ( ! ogc_is_member( $y ) ) {
		return $resp;   // the route refuses
	}
	if ( 'GET' === $req->get_method() ) {
		if ( isset( $open[ $key ] ) || ogc_guard_coa( $y ) ) {
			return $resp;
		}
		return new WP_Error( 'ogc_forbidden', 'Not allowed.', array( 'status' => 403 ) );
	}
	if ( isset( $open[ $key ] ) ) {
		return '' !== $open[ $key ] && ogc_guard_screen( $y, $open[ $key ] ) ? $resp : ogc_guard_no();
	}
	if ( ogc_guard_state_owned( $key ) ) {
		return ogc_is_webmaster() ? $resp : new WP_Error( 'ogc_forbidden', 'Changed through its own page.', array( 'status' => 403 ) );
	}
	return ogc_guard_coa( $y ) ? $resp : ogc_guard_no();
}, 5, 3 );

/* ================================================================== every record of a kind */

// Registration's committee (when the COA hands it) reads households, as the desk does; the Young Folks
// committee reads the teams. Everyone else on a committee works through their committee's routes.
add_filter( 'ogc_records_all', function ( $ok, $year, $kind ) {
	if ( $ok ) {
		return true;
	}
	if ( in_array( $kind, array( 'registrations', 'credits' ), true ) ) {
		return ogc_guard_screen( $year, 'registration' );
	}
	if ( 'teams' === $kind ) {
		return ogc_guard_screen( $year, 'yf-teams' );
	}
	return false;
}, 10, 3 );

// The volunteer page reads its shifts through /vol/{y}; it never loads the year's records.
add_filter( 'ogc_client_config', function ( $cfg, $key ) {
	if ( 'volunteer' === $key ) {
		$cfg['recordKinds'] = array();
	}
	// The form needs only this person's own sign-ups and teams, never others'.
	if ( 'register' === $key ) {
		$cfg['recordScope'] = 'mine';
	}
	return $cfg;
}, 20, 2 );

/* ================================================================== the people who signed in */

/** One of the plugin's own people (a household, a volunteer, a parent), not a site author. */
function ogc_guard_person( $user ) {
	$user = is_object( $user ) ? $user : get_userdata( (int) $user );
	if ( ! $user ) {
		return false;
	}
	if ( function_exists( 'ogc_is_person_only' ) && ogc_is_person_only( $user->ID ) ) {
		return true;
	}
	return in_array( 'ogc_person', (array) $user->roles, true );
}

// WordPress answers /?author=N and /author/<name>/ (and their feeds) for any user, posts or not: a
// stranger could walk the ids and list everyone who registered or volunteered. Not for our people.
add_action( 'template_redirect', function () {
	if ( ! is_author() ) {
		return;
	}
	$u = get_queried_object();
	if ( $u instanceof WP_User && ogc_guard_person( $u ) ) {
		global $wp_query;
		$wp_query->set_404();
		status_header( 404 );
		nocache_headers();
	}
}, 1 );

// Their author links, the sitemap's users and the REST users list leave them out.
add_filter( 'author_link', function ( $link, $author_id ) {
	return ogc_guard_person( (int) $author_id ) ? '' : $link;
}, 10, 2 );

add_filter( 'wp_sitemaps_users_query_args', function ( $args ) {
	$args['role__not_in'] = array_merge( isset( $args['role__not_in'] ) ? (array) $args['role__not_in'] : array(), array( 'ogc_person' ) );
	return $args;
} );

add_filter( 'rest_user_query', function ( $args ) {
	$args['role__not_in'] = array_merge( isset( $args['role__not_in'] ) ? (array) $args['role__not_in'] : array(), array( 'ogc_person' ) );
	return $args;
} );

/* ================================================================== committees.csv's contacts */

// committees.csv carries each committee's contact (its head's own email and phone, for the volunteer
// shifts' Monday email). A helper sees their own committees' contacts; others' only the COA.
add_filter( 'ogc_file_rows_out', function ( $rows, $year, $name ) {
	if ( 'committees' !== $name || ogc_guard_coa( $year ) ) {
		return $rows;
	}
	$mine = ogc_guard_mine( $year );
	foreach ( $rows as &$r ) {
		if ( is_array( $r ) && ! in_array( ogc_committee_key( isset( $r['name'] ) ? (string) $r['name'] : '' ), $mine, true ) ) {
			foreach ( array( 'contact_email', 'contact_phone', 'heads' ) as $k ) {
				if ( isset( $r[ $k ] ) ) {
					$r[ $k ] = '';
				}
			}
		}
	}
	unset( $r );
	return $rows;
}, 20, 3 );

/* ================================================================== the year's export */

// The year's export (every file, for the record) is the COA's and the webmasters': it read the files
// whole, around the read filters, for any helper of the year.
add_filter( 'rest_request_before_callbacks', function ( $resp, $handler, $req ) {
	if ( is_wp_error( $resp ) || ! preg_match( '#^/' . preg_quote( OGC_NS, '#' ) . '/years/(\d{4})/export$#', (string) $req->get_route(), $m ) ) {
		return $resp;
	}
	return ! ogc_is_member( (int) $m[1] ) || ogc_guard_coa( (int) $m[1] ) ? $resp : ogc_guard_no();
}, 5, 3 );

/* ================================================================== samples */

// Clearing a year's samples (DELETE /years/{y}/samples) also lets go of what the areas kept beside
// them: places on shifts held by sample sign-ups, the sample ledger, and sample notes.
add_action( 'ogc_samples_cleared', function ( $year, $kind ) {
	if ( function_exists( 'ogc_vol_seats_tidy' ) && ( ! $kind || in_array( $kind, array( 'signups', 'waits' ), true ) ) ) {
		ogc_vol_seats_tidy( (int) $year );
	}
	if ( function_exists( 'ogc_pay_clear_samples' ) && ( ! $kind || 'registrations' === $kind ) ) {
		ogc_pay_clear_samples( (int) $year );
	}
	if ( ! $kind || 'signups' === $kind ) {
		$n = ogc_state_get( (int) $year, 'vol-notes' );
		if ( $n && is_array( $n['value'] ) ) {
			$keep = array_filter( $n['value'], function ( $x ) {
				return ! ( is_array( $x ) && ! empty( $x['sample'] ) );
			} );
			if ( count( $keep ) !== count( $n['value'] ) ) {
				ogc_state_put( (int) $year, 'vol-notes', $keep ? $keep : new stdClass() );
			}
		}
	}
}, 10, 2 );

// Volunteer sign-ups aren't posted on ogbbc.org while made-up volunteers are in the year (as
// registration doesn't open while sample households are): their names would sit on real shifts.
add_filter( 'rest_request_before_callbacks', function ( $resp, $handler, $req ) {
	if ( is_wp_error( $resp ) || ! preg_match( '#^/' . preg_quote( OGC_NS, '#' ) . '/coa/(\d{4})/publish$#', (string) $req->get_route(), $m ) ) {
		return $resp;
	}
	if ( 'helping' !== (string) $req->get_param( 'part' ) || ! in_array( (string) $req->get_param( 'act' ), array( 'publish', 'reopen' ), true ) || ( function_exists( 'ogc_seed_samples' ) && ogc_seed_samples() ) ) {
		return $resp;
	}
	global $wpdb;
	$n = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM ' . ogc_table( 'records' ) . " WHERE year = %d AND kind IN ('signups','waits') AND sample = 1 AND deleted_at IS NULL", (int) $m[1] ) );
	return $n ? new WP_Error( 'ogc_samples', 'Sample volunteers in the year · A webmaster clears them first', array( 'status' => 409 ) ) : $resp;
}, 8, 3 );

/* ================================================================== loading the years on ogbbc.org */

// Activation on ogbbc.org makes the tables only (ogc_seed_on_activate). A webmaster then loads the
// plugin's reviewed years.csv and years' files once, deliberately: no made-up people, and a year still
// to come keeps everything waiting for the COA's Publish (ogc_seed_hold_back). A year already in the
// tables is never touched.
add_action( 'rest_api_init', function () {
	register_rest_route( OGC_NS, '/seed', array(
		'methods'             => 'POST',
		'callback'            => function () {
			$done = function_exists( 'ogc_import_seed' ) ? ogc_import_seed( false ) : array();
			ogc_log( 'seed_load', 0, 'seed', array( 'years' => array_keys( $done ) ) );
			return rest_ensure_response( array( 'loaded' => (object) $done ) );
		},
		'permission_callback' => 'ogc_can_webmaster',
	) );
} );

/* ================================================================== a parent's approval link */

// The parent's link carries its token in the address (/register/?year=…&approve=TOKEN). Like the
// sign-in links, it's moved into a short cookie (this page's path, an hour, same site) and the page
// opens at a clean address, so the token isn't kept in history or passed on in a referrer.
add_action( 'ogc_before_page', function ( $page ) {
	// phpcs:ignore WordPress.Security.NonceVerification -- a link from an email; nothing changes here.
	$t = 'register' === $page && isset( $_GET['approve'] ) ? sanitize_text_field( wp_unslash( $_GET['approve'] ) ) : '';
	if ( ! preg_match( '/^(\d{4})\.[a-z0-9]{32}$/', $t, $m ) || headers_sent() ) {
		return;
	}
	$path = wp_make_link_relative( ogc_url( 'register' ) );
	setcookie( 'ogc_approve', $t, array( 'expires' => time() + HOUR_IN_SECONDS, 'path' => $path, 'secure' => is_ssl(), 'httponly' => false, 'samesite' => 'Strict' ) );
	nocache_headers();
	wp_safe_redirect( ogc_url( 'register', array( 'year' => $m[1], 'approve' => '1' ) ), 303 );
	exit;
}, 4 );

/* ================================================================== one value, not a list */

// The routes read these as one value each (an email, a code, a date, an id). Sent as a list or an
// object, PHP warned "Array to string conversion" inside the callback (and with WP_DEBUG_DISPLAY on, the
// warning broke the JSON). Refused first, as WordPress's own args would (review, Oct 11).
function ogc_guard_scalar_params() {
	return (array) apply_filters( 'ogc_scalar_params', array( 'id', 'name', 'email', 'committee', 'format', 'as', 'as_of', 'part', 'c', 'shift', 'phone', 'key', 'what', 'scope', 'method', 'to', 'role', 'date', 'view', 'title', 'subject', 'sort', 'screen', 'preview', 'owner', 'op', 'link', 'hp', 'act', 't', 'source', 'ref', 'mode', 'offset', 'tid', 'text', 'kinds', 'kind', 'idem', 'how', 'hosts', 'hall', 'group', 'from', 'for', 'decision', 'code', 'closes', 'opens', 'reason', 'outcome', 'return', 'label', 'start', 'end', 'limit', 'version', 'year', 'cents', 'note', 'pay', 'step', 'v', 'at' ) );
}

add_filter( 'rest_request_before_callbacks', function ( $resp, $handler, $req ) {
	if ( is_wp_error( $resp ) || 0 !== strpos( (string) $req->get_route(), '/' . OGC_NS . '/' ) ) {
		return $resp;
	}
	foreach ( ogc_guard_scalar_params() as $p ) {
		$v = $req->get_param( $p );
		if ( null !== $v && ! is_scalar( $v ) ) {
			return new WP_Error( 'rest_invalid_param', 'One value: ' . $p, array( 'status' => 400, 'params' => array( $p => 'One value' ) ) );
		}
	}
	return $resp;
}, 1, 3 );
