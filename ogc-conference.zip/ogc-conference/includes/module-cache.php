<?php
/**
 * WP Rocket (ogbbc.org's cache) and the plugin's pages (review, Oct 11). Nothing here runs unless WP
 * Rocket is installed: every hook is WP Rocket's own filter or a function_exists check.
 *
 * Why the plugin's pages stay out of the page cache:
 *   - they're drawn in the browser from the year's data (register, volunteer, tournaments, the app),
 *     so Remove Unused CSS, worked out from the server's HTML, would strip most of their styles;
 *   - the guide's offline copy is kept only from an answer marked X-OGC-Public, and the pages' own
 *     headers (frame-ancestors, Referrer-Policy) are missing from a cached copy;
 *   - the Conference page's facts change when the COA publishes, not when the cache expires.
 * And their scripts are never delayed, deferred, combined or minified: ogc-wp.js must run first, before
 * the inline OGC_WP config, in the order the page lists them.
 *
 * A webmaster who wants the Conference page cached anyway can narrow ogc_rocket_never_cache; the purge
 * below then keeps it fresh after a Publish.
 */

defined( 'ABSPATH' ) || exit;

/** The plugin's addresses WP Rocket never caches (patterns, as its "Never cache URLs" box takes them). */
function ogc_rocket_never_cache() {
	$b = '/' . ogc_base_path();
	return (array) apply_filters( 'ogc_rocket_never_cache', array( $b . '/?$', $b . '/(.*)' ) );
}

add_filter( 'rocket_cache_reject_uri', function ( $uris ) {
	return array_values( array_unique( array_merge( (array) $uris, ogc_rocket_never_cache() ) ) );
} );

// The plugin's scripts and styles as they are: not delayed, deferred, combined or minified.
add_filter( 'rocket_delay_js_exclusions', function ( $x ) {
	return array_merge( (array) $x, array( '/plugins/ogc-conference/', 'OGC_WP' ) );
} );
add_filter( 'rocket_exclude_defer_js', function ( $x ) {
	return array_merge( (array) $x, array( '/wp-content/plugins/ogc-conference/(.*).js' ) );
} );
add_filter( 'rocket_exclude_js', function ( $x ) {
	return array_merge( (array) $x, array( '/wp-content/plugins/ogc-conference/(.*).js' ) );
} );
add_filter( 'rocket_exclude_inline_js', function ( $x ) {
	return array_merge( (array) $x, array( 'OGC_WP' ) );
} );
add_filter( 'rocket_exclude_css', function ( $x ) {
	return array_merge( (array) $x, array( '/wp-content/plugins/ogc-conference/(.*).css' ) );
} );
// Remove Unused CSS keeps the plugin's stylesheets whole (their selectors are drawn by script).
add_filter( 'rocket_rucss_external_exclusions', function ( $x ) {
	return array_merge( (array) $x, array( '/wp-content/plugins/ogc-conference/(.*).css' ) );
} );
add_filter( 'rocket_rucss_safelist', function ( $x ) {
	return array_merge( (array) $x, array( '/wp-content/plugins/ogc-conference/(.*).css' ) );
} );

/** Clear the cached copies of the plugin's pages (when a webmaster lets WP Rocket cache any of them). */
function ogc_rocket_purge() {
	if ( function_exists( 'rocket_clean_files' ) ) {
		rocket_clean_files( array( ogc_url(), ogc_url( 'guide' ) ) );
	}
}
add_action( 'ogc_coa_published', 'ogc_rocket_purge' );
add_action( 'ogc_file_saved', function ( $year, $name ) {
	// A public file changed (the year's dates, the schedule, the packet): the facts on the page did too.
	if ( ! in_array( $name, function_exists( 'ogc_private_files' ) ? ogc_private_files() : array( 'needs', 'notes' ), true ) ) {
		ogc_rocket_purge();
	}
}, 10, 2 );

/* ================================================================== one-time flags, in one query */

// The areas' one-time migration flags (ogc_lodging_table, ogc_app_seeded…) are saved with autoload off,
// so each was its own query on every request across ogbbc.org (7 of the home page's 23). Read the
// plugin's options that WordPress doesn't autoload in one query, and remember the flags not set yet.
add_action( 'plugins_loaded', function () {
	global $wpdb;
	if ( wp_installing() ) {
		return;
	}
	$rows = (array) $wpdb->get_results( "SELECT option_name, option_value FROM {$wpdb->options} WHERE option_name LIKE 'ogc\\_%' AND autoload NOT IN ('yes','on','auto-on','auto')" ); // phpcs:ignore -- no input.
	$have = array();
	foreach ( $rows as $r ) {
		$have[ $r->option_name ] = true;
		wp_cache_add( $r->option_name, $r->option_value, 'options' );
	}
	$flags = array( 'ogc_lodging_table', 'ogc_members_from_state', 'ogc_log_who_cleared', 'ogc_members_committees_v1', 'ogc_app_notes_moved', 'ogc_app_seeded', 'ogc_app_task_kinds', 'ogc_cap_migrated', 'ogc_members_seeded', 'ogc_app_seed_confirm' );
	$all  = wp_load_alloptions();
	$not  = (array) wp_cache_get( 'notoptions', 'options' );
	foreach ( $flags as $f ) {
		if ( ! isset( $have[ $f ] ) && ! isset( $all[ $f ] ) ) {
			$not[ $f ] = true;
		}
	}
	wp_cache_set( 'notoptions', $not, 'options' );
}, 0 );
