<?php
/**
 * Import from the Google Form (docs/20's middle path: if the registration Form stays for 2027,
 * Lodging's board reads its responses instead of anyone retyping them).
 *
 *   POST /years/{y}/lodging/import       { step: columns|check|apply, text, name, mapping, choices, remove }
 *   POST /years/{y}/lodging/import/undo  { id }   the last import, put back
 *
 * The file is read here and never kept: only the mapped answers become registrations (source "form").
 * Free text loses anything that looks like a phone number or an email; the Young Folks' roommate box
 * keeps names only (2025's form collected phones and ages there). Members of the year only.
 *
 * Responses don't map one row to one household: 2025's form took one room per submission, and a change
 * meant submitting again. Rows are grouped by email (or by name and phone), and Lodging chooses for each
 * group: Combine (one household, rooms added up), Keep newest (a resubmission) or Keep both. A second
 * upload matches rows by the Form's response ID (or timestamp and email), skips what's unchanged, lists
 * what changed and what's missing (never removed unless Lodging says so). Undo import until the next one.
 */

defined( 'ABSPATH' ) || exit;

add_action( 'rest_api_init', function () {
	$Y = '(?P<year>\d{4})';
	register_rest_route( OGC_NS, "/years/$Y/lodging/import", array(
		array( 'methods' => 'POST', 'callback' => 'ogc_lod_rest_import', 'permission_callback' => 'ogc_lod_can' ),
	) );
	register_rest_route( OGC_NS, "/years/$Y/lodging/import/undo", array(
		array( 'methods' => 'POST', 'callback' => 'ogc_lod_rest_import_undo', 'permission_callback' => 'ogc_lod_can' ),
	) );
} );

/* ================================================================== the board's fields */

/**
 * What a column can fill, in the order headings are tried (the most particular first). Each: label,
 * help (the tooltip), the words that match it surely, the words that match it only to check, and
 * whether several columns may fill it.
 */
function ogc_lod_fields() {
	return array(
		'key'        => array( 'Response ID', 'The Form’s own number for a response, so a second upload finds it again', '/\b(response|submission|registration|entry)\s*(id|number|#)|^id$|edit (response )?(url|link)/i', '', false ),
		'at'         => array( 'Registered', 'When the response was sent (Timestamp)', '/^time\s*stamp$|timestamp|date submitted|submitted at/i', '/\bdate\b/i', false ),
		'email'      => array( 'Email', 'The household’s email: one registration per email', '/e-?mail/i', '', false ),
		'phone'      => array( 'Phone', 'The contact’s phone', '/phone|cell|mobile/i', '', false ),
		'pay'        => array( 'Payment', 'The Form’s payment status (Paid, Pending), shown as the Form says it', '/payment|paid\b|amount (paid|due)|balance/i', '', false ),
		'surname'    => array( 'Household name', 'The surname the household goes by', '/last name|surname|family name|household name/i', '', false ),
		'contact'    => array( 'Contact', 'Who registered (a name)', '/^(your )?(full )?name$|contact( person| name)?|name of (the )?person|first and last name|your name/i', '/\bname\b/i', false ),
		'rooming'    => array( 'Rooming with', 'Young Folks’ roommates: names only are kept', '/room ?mates?|rooming with|room with/i', '', false ),
		'yfMen'      => array( 'Young men', 'Young Folks staying in the young men’s hall (names, ages)', '/young (men|man)|boys?\b/i', '', false ),
		'yfWomen'    => array( 'Young women', 'Young Folks staying in the young women’s hall (names, ages)', '/young (women|woman|ladies)|girls?\b/i', '', false ),
		'yf'         => array( 'Young Folks', 'Young Folks (names, ages); their hall is chosen on the board', '/young folks?|youth|young people/i', '', false ),
		'children'   => array( 'Children', 'Children (names and ages)', '/child|kids|children/i', '', false ),
		'adults'     => array( 'Adults', 'Adults (names)', '/\badults?\b/i', '', false ),
		'people'     => array( 'Everyone coming', 'Everyone (names, ages): 13 and under as children', '/who(’|\')?s coming|who is coming|attending|everyone|all (persons|people)|names? (and ages )?of/i', '/\bpeople|persons|names\b/i', false ),
		'nearW'      => array( 'Near women’s restroom', 'Yes or no', '/wom[ae]n(’|\')?s? (rest|bath)\s?room/i', '', false ),
		'nearM'      => array( 'Near men’s restroom', 'Yes or no', '/\bmen(’|\')?s? (rest|bath)\s?room/i', '', false ),
		'walker'     => array( 'Step-free', 'A walker, wheelchair or no stairs at all (yes or no)', '/walker|wheel\s?chair|step.?free|mobility|handicap/i', '', false ),
		'ground'     => array( 'Ground floor', 'Yes or no', '/ground floor|first floor|no stairs|lower floor/i', '', false ),
		'mattresses' => array( 'Air mattresses', 'How many', '/mattress/i', '', false ),
		'linens'     => array( 'Linen packets', 'How many', '/linen|bedding|sheets/i', '', false ),
		'rooms'      => array( 'Rooms', 'How many dorm rooms', '/how many (dorm )?rooms|rooms? (needed|requested)|number of (dorm )?rooms|^(dorm )?rooms?$/i', '', false ),
		'near'       => array( 'Near', 'Another household or a group to be placed with (2025: “group name”)', '/group name|near (another|other)|placed (near|with)|together with|near family/i', '/\bnear\b|group/i', false ),
		'type'       => array( 'Staying', 'Dorm, camper lot or elsewhere', '/where (will|are) you stay|lodging (type|choice)|staying|accommodation|housing|dorm or camper/i', '/lodging|dorm|camper/i', false ),
		'camperLen'  => array( 'Camper length', 'Short, medium or long, or its length in feet (the camper host’s)', '/camper length|length of (your |the )?(camper|rv|trailer)|how long is (your |the )?(camper|rv|trailer)/i', '', false ),
		'arrive'     => array( 'Arrival', 'Afternoon, evening or late, or a time', '/arriv(al|ing|e) (time|at)|what time.*arriv|time of arrival|arrival time/i', '', false ),
		'nights'     => array( 'Nights', 'Which nights (Fri, Sat… or Friday–Monday)', '/nights?|which days|arrival|dates (staying|attending)/i', '', false ),
		'note'       => array( 'Note for Lodging', 'Anything Lodging should know; several columns may fill it', '/special|needs|note|comment|request|anything else|medical|accessib/i', '', true ),
	);
}

/* ================================================================== reading the file */

/** The file as UTF-8 text: Excel's re-saved CSV is Windows-1252; a byte-order mark is dropped. */
function ogc_lod_text( $text ) {
	$text = (string) $text;
	$enc  = 'UTF-8';
	if ( ! mb_check_encoding( $text, 'UTF-8' ) ) {
		$text = mb_convert_encoding( $text, 'UTF-8', 'Windows-1252' );
		$enc  = 'Windows-1252';
	}
	$text = preg_replace( '/^\xEF\xBB\xBF/', '', $text );
	return array( str_replace( array( "\r\n", "\r" ), "\n", $text ), $enc );
}

/** CSV (comma, semicolon or tab) → array( header, rows of cells, first line number of each row ). */
function ogc_lod_csv( $text ) {
	$first = strtok( $text, "\n" );
	$delim = ',';
	foreach ( array( "\t", ';' ) as $d ) {
		if ( substr_count( (string) $first, $d ) > substr_count( (string) $first, $delim ) ) {
			$delim = $d;
		}
	}
	$rows  = array();
	$lines = array();
	$row   = array();
	$cell  = '';
	$q     = false;
	$line  = 1;
	$start = 1;
	$len   = strlen( $text );
	for ( $i = 0; $i < $len; $i++ ) {
		$c = $text[ $i ];
		if ( $q ) {
			if ( '"' === $c ) {
				if ( $i + 1 < $len && '"' === $text[ $i + 1 ] ) {
					$cell .= '"';
					$i++;
				} else {
					$q = false;
				}
			} else {
				if ( "\n" === $c ) {
					$line++;
				}
				$cell .= $c;
			}
		} elseif ( '"' === $c && '' === $cell ) {
			$q = true;
		} elseif ( $c === $delim ) {
			$row[] = $cell;
			$cell  = '';
		} elseif ( "\n" === $c ) {
			$row[]   = $cell;
			$rows[]  = $row;
			$lines[] = $start;
			$row     = array();
			$cell    = '';
			$line++;
			$start = $line;
		} else {
			$cell .= $c;
		}
	}
	if ( '' !== $cell || $row ) {
		$row[]   = $cell;
		$rows[]  = $row;
		$lines[] = $start;
	}
	$head = $rows ? array_map( 'trim', array_shift( $rows ) ) : array();
	array_shift( $lines );
	// Blank rows go.
	$out = array();
	$at  = array();
	foreach ( $rows as $k => $r ) {
		if ( '' !== trim( implode( '', $r ) ) ) {
			$out[] = $r;
			$at[]  = $lines[ $k ];
		}
	}
	return array( $head, $out, $at );
}

/** The automatic match of each heading, with how sure it is: array( field, state ). */
function ogc_lod_guess( $head ) {
	$fields = ogc_lod_fields();
	$taken  = array();
	$out    = array();
	foreach ( $head as $i => $h ) {
		$out[ $i ] = array( '', 'unused' );
		if ( '' === trim( $h ) ) {
			continue;
		}
		foreach ( array( 2 => 'matched', 3 => 'check' ) as $slot => $state ) {
			foreach ( $fields as $f => $def ) {
				if ( '' !== $def[ $slot ] && preg_match( $def[ $slot ], $h ) && ( $def[4] || ! isset( $taken[ $f ] ) ) ) {
					$out[ $i ]   = array( $f, $state );
					$taken[ $f ] = true;
					break 2;
				}
			}
		}
	}
	return $out;
}

/* ================================================================== reading a cell */

function ogc_lod_yes( $v, &$problem ) {
	$v = strtolower( trim( (string) $v ) );
	if ( '' === $v || preg_match( '/^(no|n|none|false|0|no thanks|not needed|n\/a|-)\.?$/', $v ) ) {
		return false;
	}
	if ( preg_match( '/^(yes|y|x|true|1|✓|please|yes please|yes,? please|needed|required)\b/u', $v ) ) {
		return true;
	}
	$problem = 'Not yes or no';
	return false;
}

function ogc_lod_count( $v, &$problem, $max = 12 ) {
	$v = strtolower( trim( (string) $v ) );
	if ( '' === $v || preg_match( '/^(no|none|n\/a|-|zero)$/', $v ) ) {
		return 0;
	}
	$words = array( 'one' => 1, 'two' => 2, 'three' => 3, 'four' => 4, 'five' => 5, 'six' => 6 );
	if ( preg_match( '/\d+/', $v, $m ) ) {
		return min( $max, (int) $m[0] );
	}
	foreach ( $words as $w => $n ) {
		if ( false !== strpos( $v, $w ) ) {
			return $n;
		}
	}
	if ( preg_match( '/^(yes|y)$/', $v ) ) {
		return 1;
	}
	$problem = 'Not a number';
	return 0;
}

/** "Fri, Sat, Sun", "Friday-Monday", "Friday, June 5, Saturday, June 6", "All nights" → the year's nights. */
function ogc_lod_nights_of( $v, $nights, &$problem ) {
	$v = trim( (string) $v );
	if ( '' === $v ) {
		return null;
	}
	if ( preg_match( '/\b(all|every|whole|entire)\b/i', $v ) ) {
		return array_values( array_filter( $nights, function ( $n ) { return 0 !== strpos( $n, 'Early ' ); } ) );
	}
	preg_match_all( '/\b(mon|tue|wed|thu|fri|sat|sun)[a-z]*\.?/i', $v, $m, PREG_OFFSET_CAPTURE );
	if ( ! $m[0] ) {
		$problem = 'No nights';
		return null;
	}
	$idx = function ( $abbr ) use ( $nights ) {
		foreach ( $nights as $i => $n ) {
			if ( 0 !== strpos( $n, 'Early ' ) && strtolower( substr( $n, 0, 3 ) ) === strtolower( $abbr ) ) {
				return $i;
			}
		}
		return -1;
	};
	$found = array();
	$days  = $m[1];
	for ( $k = 0; $k < count( $days ); $k++ ) {
		$i = $idx( $days[ $k ][0] );
		// "Friday-Monday", "Fri to Mon": everything between.
		if ( $k + 1 < count( $days ) ) {
			$between = substr( $v, $days[ $k ][1] + strlen( $m[0][ $k ][0] ), $days[ $k + 1 ][1] - $days[ $k ][1] - strlen( $m[0][ $k ][0] ) );
			if ( preg_match( '/^\s*(-|–|—|to|through|thru)\s*$/iu', $between ) ) {
				$j = $idx( $days[ $k + 1 ][0] );
				if ( $i >= 0 && $j >= $i ) {
					for ( $x = $i; $x <= $j; $x++ ) {
						$found[ $x ] = true;
					}
					$k++;
					continue;
				}
			}
		}
		if ( $i >= 0 ) {
			$found[ $i ] = true;
		} elseif ( ! preg_match( '/^wed/i', $days[ $k ][0] ) ) {
			$problem = 'Night not offered';
		}
	}
	ksort( $found );
	$out = array();
	foreach ( array_keys( $found ) as $i ) {
		$out[] = $nights[ $i ];
	}
	if ( preg_match( '/\?|maybe|not sure|unsure/i', $v ) ) {
		$problem = 'Unsure';
	}
	return $out ? $out : null;
}

/** "6/3/2026 14:22:05", "2026-03-04 10:00", "3/9/26", Excel's "7-May" → 2026-06-03. */
function ogc_lod_date_of( $v, $year ) {
	$v = trim( (string) $v );
	if ( preg_match( '/^(\d{4})-(\d\d)-(\d\d)/', $v, $m ) ) {
		return "$m[1]-$m[2]-$m[3]";
	}
	if ( preg_match( '/^(\d{1,2})\/(\d{1,2})\/(\d{2,4})/', $v, $m ) ) {
		$yy = strlen( $m[3] ) === 2 ? 2000 + (int) $m[3] : (int) $m[3];
		return sprintf( '%04d-%02d-%02d', $yy, $m[1], $m[2] );
	}
	if ( preg_match( '/^(\d{1,2})-([A-Za-z]{3})/', $v, $m ) ) {
		$mo = array_search( strtolower( $m[2] ), array( 'jan', 'feb', 'mar', 'apr', 'may', 'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec' ), true );
		if ( false !== $mo ) {
			return sprintf( '%04d-%02d-%02d', $mo >= 9 ? $year - 1 : $year, $mo + 1, $m[1] );
		}
	}
	return '';
}

/** Free text without phone numbers or emails (the committees don't need them there). */
function ogc_lod_scrub( $v, $max = 500 ) {
	$v = preg_replace( '/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i', '', (string) $v );
	$v = preg_replace( '/(\+?1[\s.-]?)?\(?\d{3}\)?[\s.-]?\d{3}[\s.-]?\d{4}/', '', $v );
	$v = preg_replace( '/\b\d{3}[\s.-]\d{4}\b/', '', $v );   // a local number, 555-0134
	$v = preg_replace( '/\s{2,}/', ' ', $v );
	return mb_substr( trim( wp_strip_all_tags( $v ), " \t\n,;·-" ), 0, $max );
}

/** "Daniel Miller (45), Esther, Samuel 17" → array( array( name, age ) ), a lone first name given the surname. */
function ogc_lod_names( $v, $surname ) {
	$v   = ogc_lod_scrub( $v, 800 );
	$out = array();
	foreach ( preg_split( '/\s*(?:,|;|\n|\/|&|\band\b)\s*/i', $v ) as $part ) {
		$part = trim( $part, " \t" );
		if ( '' === $part ) {
			continue;
		}
		$age = '';
		if ( preg_match( '/\(?\b(?:age\s*)?(\d{1,2})\s*(?:yrs?|years?( old)?)?\)?\s*$/i', $part, $m ) ) {
			$age  = $m[1];
			$part = trim( substr( $part, 0, - strlen( $m[0] ) ), " .-\t(" );
		}
		$part = trim( preg_replace( '/\s*\(.*?\)\s*/', ' ', $part ) );
		if ( '' === $part || ! preg_match( '/\pL/u', $part ) || mb_strlen( $part ) > 60 ) {
			continue;
		}
		$w = preg_split( '/\s+/', $part );
		if ( 1 === count( $w ) && '' !== $surname ) {
			$part .= ' ' . $surname;
		}
		// "SAMUEL" or "samuel" reads as "Samuel"; names written with care are kept as written.
		if ( ! preg_match( '/\p{Lu}/u', $part ) || ! preg_match( '/\p{Ll}/u', $part ) ) {
			$part = mb_convert_case( $part, MB_CASE_TITLE );
		}
		$out[] = array( $part, $age );
	}
	return $out;
}

/* ================================================================== a row → a household's answers */

/**
 * One response as the board's answers: array( answers, problems ). $cols: field => array of column
 * indexes. $nights: the year's nights.
 */
function ogc_lod_answers( $cells, $cols, $nights, $year, $line, $head ) {
	$problems = array();
	$get      = function ( $f ) use ( $cells, $cols ) {
		if ( empty( $cols[ $f ] ) ) {
			return '';
		}
		$v = array();
		foreach ( $cols[ $f ] as $i ) {
			if ( isset( $cells[ $i ] ) && '' !== trim( $cells[ $i ] ) ) {
				$v[] = trim( $cells[ $i ] );
			}
		}
		return implode( ' · ', $v );
	};
	$flag     = function ( $f, $reason ) use ( &$problems, $cols, $cells, $line, $head ) {
		$i          = isset( $cols[ $f ][0] ) ? $cols[ $f ][0] : -1;
		$problems[] = array( 'line' => $line, 'col' => $i >= 0 ? $head[ $i ] : $f, 'cell' => mb_substr( $i >= 0 && isset( $cells[ $i ] ) ? $cells[ $i ] : '', 0, 80 ), 'reason' => $reason, 'field' => $f );
	};
	$contact = ogc_lod_scrub( $get( 'contact' ), 80 );
	$surname = ogc_lod_scrub( $get( 'surname' ), 40 );
	$people  = array();
	$add     = function ( $list, $kind, $hall = '' ) use ( &$people ) {
		foreach ( $list as $p ) {
			foreach ( $people as $q ) {
				if ( strtolower( $q['name'] ) === strtolower( $p[0] ) ) {
					continue 2;
				}
			}
			$k = $kind;
			if ( 'any' === $kind ) {
				$k = '' !== $p[1] && (int) $p[1] <= 13 ? 'child' : 'adult';
			}
			$people[] = array( 'name' => $p[0], 'kind' => $k, 'age' => $p[1], 'yfHall' => $hall );
		}
	};
	if ( '' === $surname && '' !== $contact ) {
		$w       = preg_split( '/\s+/', $contact );
		$surname = count( $w ) > 1 ? end( $w ) : '';
	}
	$add( ogc_lod_names( $get( 'adults' ), $surname ), 'adult' );
	$add( ogc_lod_names( $get( 'people' ), $surname ), 'any' );
	$add( ogc_lod_names( $get( 'children' ), $surname ), 'child' );
	$add( ogc_lod_names( $get( 'yfMen' ), $surname ), 'yf', 'men' );
	$add( ogc_lod_names( $get( 'yfWomen' ), $surname ), 'yf', 'women' );
	$add( ogc_lod_names( $get( 'yf' ), $surname ), 'yf', '' );
	if ( '' !== $contact && ! array_filter( $people, function ( $p ) use ( $contact ) { return strtolower( $p['name'] ) === strtolower( $contact ); } ) ) {
		array_unshift( $people, array( 'name' => $contact, 'kind' => 'adult', 'age' => '', 'yfHall' => '' ) );
	}
	if ( '' === $contact && $people ) {
		$contact = $people[0]['name'];
	}
	if ( '' === $surname && '' !== $contact ) {
		$w       = preg_split( '/\s+/', $contact );
		$surname = end( $w );
	}
	foreach ( $people as $p ) {
		if ( 'yf' === $p['kind'] && '' === $p['yfHall'] ) {
			$flag( 'yf', 'Hall not given · ' . $p['name'] );
		}
		if ( 'child' === $p['kind'] && '' === $p['age'] ) {
			$flag( 'children', 'No age · ' . $p['name'] );
		}
	}
	if ( ! $people ) {
		$flag( 'contact', 'No names' );
	}
	// Where they'll stay.
	$tv    = strtolower( $get( 'type' ) );
	$p     = '';
	$rooms = ogc_lod_count( $get( 'rooms' ), $p, 6 );
	if ( $p ) {
		$flag( 'rooms', $p );
	}
	if ( preg_match( '/dorm|room|hall|on.?site/', $tv ) ) {
		$type = 'dorm';
	} elseif ( preg_match( '/camper|camping|\brv\b|trailer|tent|motor ?home|camp lot/', $tv ) ) {
		$type = 'camper';
	} elseif ( preg_match( '/else|hotel|motel|home|own|off|relative|friend|commut|day/', $tv ) ) {
		$type = 'elsewhere';
	} else {
		$type = $rooms > 0 || '' === $tv ? 'dorm' : 'elsewhere';
		if ( '' !== $tv ) {
			$flag( 'type', 'Not dorm, camper or elsewhere' );
		}
	}
	$p  = '';
	$ns = ogc_lod_nights_of( $get( 'nights' ), $nights, $p );
	if ( 'elsewhere' === $type ) {
		$ns = array();
	} elseif ( null === $ns ) {
		$flag( 'nights', $p ? $p . ' · imported as all nights' : 'Blank · imported as all nights' );
		$ns = array_values( array_filter( $nights, function ( $n ) { return 0 !== strpos( $n, 'Early ' ); } ) );
		$blank_nights = true;
	} elseif ( $p ) {
		$sp = 1 === count( $ns ) ? substr( $ns[0], 0, 3 ) : substr( $ns[0], 0, 3 ) . '–' . substr( end( $ns ), 0, 3 );
		$flag( 'nights', $p . ' · imported as ' . $sp );
	}
	$yn = array();
	foreach ( array( 'ground', 'walker', 'nearW', 'nearM' ) as $f ) {
		$p        = '';
		$yn[ $f ] = ogc_lod_yes( $get( $f ), $p );
		if ( $p ) {
			$flag( $f, $p . ' · kept as a note' );
		}
	}
	$p      = '';
	$linens = ogc_lod_count( $get( 'linens' ), $p, 24 );
	if ( $p ) {
		$flag( 'linens', $p );
	}
	$p   = '';
	$mat = ogc_lod_count( $get( 'mattresses' ), $p, 6 );
	if ( $p ) {
		$flag( 'mattresses', $p );
	}
	$notes = array();
	foreach ( (array) ( isset( $cols['note'] ) ? $cols['note'] : array() ) as $i ) {
		$v = isset( $cells[ $i ] ) ? ogc_lod_scrub( $cells[ $i ], 300 ) : '';
		if ( '' !== $v && ! preg_match( '/^(n\/?a|none|no|-)\.?$/i', $v ) ) {
			$notes[] = $v;
		}
	}
	// Answers that didn't read as yes or no are kept as words in the note, not dropped.
	foreach ( $problems as $pr ) {
		if ( in_array( $pr['field'], array( 'ground', 'walker', 'nearW', 'nearM' ), true ) && '' !== $pr['cell'] ) {
			$notes[] = ogc_lod_fields()[ $pr['field'] ][0] . ': ' . ogc_lod_scrub( $pr['cell'], 80 );
		}
	}
	$rooming = array();
	foreach ( ogc_lod_names( $get( 'rooming' ), '' ) as $n ) {
		$rooming[] = $n[0];
	}
	$email = strtolower( trim( $get( 'email' ) ) );
	if ( '' !== $email && ! is_email( $email ) ) {
		$flag( 'email', 'Not an email' );
		$email = '';
	}
	$at = ogc_lod_date_of( $get( 'at' ), $year );
	// The camper's length and the arrival time, where the Form asks them (the camper host's lists).
	$lv  = strtolower( $get( 'camperLen' ) );
	$len = preg_match( '/(\d{2})/', $lv, $mm ) ? ( (int) $mm[1] < 25 ? 'short' : ( (int) $mm[1] < 35 ? 'mid' : 'long' ) ) : ( preg_match( '/short|small/', $lv ) ? 'short' : ( preg_match( '/med|mid/', $lv ) ? 'mid' : ( preg_match( '/long|large|big/', $lv ) ? 'long' : '' ) ) );
	$av  = strtolower( $get( 'arrive' ) );
	$arr = preg_match( '/late|night|after (9|10|11)/', $av ) ? 'late' : ( preg_match( '/evening|supper|after (5|6|7|8)|\b(5|6|7|8)(:\d\d)?\s*pm/', $av ) ? 'evening' : ( preg_match( '/afternoon|noon|\b(12|1|2|3|4)(:\d\d)?\s*pm/', $av ) ? 'afternoon' : ( preg_match( '/\b(9|10|11)(:\d\d)?\s*pm/', $av ) ? 'late' : '' ) ) );
	// The Form's payment status, as it says it (never "Paid" unless it says paid).
	$pv  = strtolower( trim( $get( 'pay' ) ) );
	$pay = '' === $pv ? '' : ( preg_match( '/pend|due|owe|unpaid|not|partial|wait|no\b/', $pv ) ? 'pending' : ( preg_match( '/paid|complete|received|yes|done/', $pv ) ? 'paid' : 'other' ) );
	if ( 'other' === $pay ) {
		$flag( 'pay', 'Not paid or pending · shown as written' );
	}
	$a  = array(
		'key'     => mb_substr( trim( $get( 'key' ) ), 0, 120 ),
		'at'      => $at,
		'stamp'   => trim( $get( 'at' ) ),
		'email'   => $email,
		'phone'   => mb_substr( preg_replace( '/[^0-9+()\s.-]/', '', $get( 'phone' ) ), 0, 30 ),
		'contact' => $contact,
		'surname' => $surname,
		'people'  => $people,
		'type'    => $type,
		'nights'  => $ns,
		'rooms'   => 'dorm' === $type ? $rooms : 0,
		'linens'  => in_array( $type, array( 'dorm' ), true ) ? $linens : 0,
		'mats'    => 'dorm' === $type ? $mat : 0,
		'ground'  => $yn['ground'],
		'walker'  => $yn['walker'],
		'nearW'   => $yn['nearW'],
		'nearM'   => $yn['nearM'],
		'near'    => ogc_lod_scrub( $get( 'near' ), 60 ),
		'note'    => implode( ' · ', array_unique( $notes ) ),
		'rooming' => implode( ', ', $rooming ),
		'pay'     => $pay,
		'camperLen' => 'camper' === $type ? $len : '',
		'arrive'  => 'elsewhere' !== $type ? $arr : '',
		'payText' => ogc_lod_scrub( $get( 'pay' ), 30 ),
		'line'    => $line,
			'blankNights' => ! empty( $blank_nights ),
		);
		return array( $a, $problems );
}

/** A Form timestamp as people say it: "Mar 4, 7:02 PM" (or the date alone). */
function ogc_lod_stamp_words( $stamp, $iso ) {
	if ( preg_match( '/(\d{1,2}):(\d\d)/', (string) $stamp, $m ) && $iso ) {
		$d = DateTime::createFromFormat( '!Y-m-d', $iso );
		$h = (int) $m[1];
		return ( $d ? $d->format( 'M j' ) . ', ' : '' ) . ( ( $h % 12 ) ? $h % 12 : 12 ) . ':' . $m[2] . ( $h < 12 ? ' AM' : ' PM' );
	}
	$d = $iso ? DateTime::createFromFormat( '!Y-m-d', $iso ) : null;
	return $d ? $d->format( 'M j' ) : (string) $stamp;
}

/** Responses from one household: the same email; or the same name and phone; or else one each. */
function ogc_lod_group_key( $a ) {
	if ( '' !== $a['email'] ) {
		return 'e:' . $a['email'];
	}
	$digits = preg_replace( '/\D/', '', $a['phone'] );
	if ( '' !== $a['contact'] ) {
		return 'n:' . strtolower( $a['contact'] ) . '|' . substr( $digits, -4 );
	}
	return 'r:' . ( '' !== $a['key'] ? $a['key'] : $a['line'] );
}

/** A response's own key across uploads: the Form's response ID, or its timestamp and email. */
function ogc_lod_row_key( $a ) {
	return '' !== $a['key'] ? 'id:' . $a['key'] : 'ts:' . $a['stamp'] . '|' . ( '' !== $a['email'] ? $a['email'] : strtolower( $a['contact'] ) );
}

/** A group's rows as one household: combined (rooms added up), the newest one, or each row its own. */
function ogc_lod_merge( $rows, $choice ) {
	usort( $rows, function ( $a, $b ) { return strcmp( $a['at'] . $a['stamp'] . sprintf( '%06d', $a['line'] ), $b['at'] . $b['stamp'] . sprintf( '%06d', $b['line'] ) ); } );
	if ( 'newest' === $choice || 1 === count( $rows ) ) {
		$a         = end( $rows );
		$a['keys'] = array_map( 'ogc_lod_row_key', $rows );
		return $a;
	}
	$a = $rows[0];
	foreach ( array_slice( $rows, 1 ) as $r ) {
		foreach ( $r['people'] as $p ) {
			if ( ! array_filter( $a['people'], function ( $q ) use ( $p ) { return strtolower( $q['name'] ) === strtolower( $p['name'] ); } ) ) {
				$a['people'][] = $p;
			}
		}
		$a['rooms']  += $r['rooms'];
		$a['linens'] += $r['linens'];
		$a['mats']   += $r['mats'];
		$a['nights']  = array_values( array_unique( array_merge( $a['nights'], $r['nights'] ) ) );
		foreach ( array( 'ground', 'walker', 'nearW', 'nearM' ) as $f ) {
			$a[ $f ] = $a[ $f ] || $r[ $f ];
		}
		foreach ( array( 'near', 'phone', 'surname', 'contact' ) as $f ) {
			$a[ $f ] = '' !== $a[ $f ] ? $a[ $f ] : $r[ $f ];
		}
		$a['note']    = implode( ' · ', array_unique( array_filter( array( $a['note'], $r['note'] ) ) ) );
		$a['rooming'] = implode( ', ', array_unique( array_filter( array_merge( explode( ', ', $a['rooming'] ), explode( ', ', $r['rooming'] ) ) ) ) );
		if ( 'camper' === $r['type'] || 'dorm' === $r['type'] ) {
			$a['type'] = 'dorm' === $a['type'] || 'dorm' === $r['type'] ? 'dorm' : $r['type'];
		}
		$a['at'] = $r['at'] > $a['at'] ? $r['at'] : $a['at'];
		if ( '' !== $r['pay'] ) {
			// Several submissions: pending if any of them is.
			$a['pay']     = 'pending' === $a['pay'] || 'pending' === $r['pay'] ? 'pending' : $r['pay'];
			$a['payText'] = 'pending' === $r['pay'] || '' === $a['payText'] ? $r['payText'] : $a['payText'];
		}
	}
	$a['keys'] = array_map( 'ogc_lod_row_key', $rows );
	return $a;
}

/**
 * Who sleeps in which room, for a family of several rooms: a grown-up in each room first (the one who
 * picks up its keys sleeps in the room they open), then the children, each to the room with the fewest
 * people that has a grown-up, up to beds + 1 a room. With fewer grown-ups than rooms, the rest of the
 * children go together in the last room, and Review says "Children alone" (lodging-assumptions A7).
 * Returns array( people with 'room', keys per room ).
 */
function ogc_lod_split( $people, $rooms, $cap ) {
	$keys = array_fill( 0, $rooms, '' );
	if ( $rooms < 2 ) {
		foreach ( $people as $i => $p ) {
			if ( 'adult' === $p['kind'] && '' === $keys[0] ) {
				$keys[0] = $p['name'];
			}
		}
		return array( $people, $keys );
	}
	$n      = array_fill( 0, $rooms, 0 );
	$grown  = array_fill( 0, $rooms, false );
	$adults = array_keys( array_filter( $people, function ( $p ) { return 'adult' === $p['kind']; } ) );
	foreach ( $adults as $k => $i ) {
		$r                     = $k % $rooms;
		$people[ $i ]['room'] = $r;
		$n[ $r ]++;
		$grown[ $r ] = true;
		if ( '' === $keys[ $r ] ) {
			$keys[ $r ] = $people[ $i ]['name'];
		}
	}
	foreach ( $people as $i => $p ) {
		if ( 'adult' === $p['kind'] || 'yf' === $p['kind'] ) {
			continue;
		}
		$best = -1;
		for ( $r = 0; $r < $rooms; $r++ ) {
			if ( $n[ $r ] < $cap && ( -1 === $best || ( $grown[ $r ] && ! $grown[ $best ] ) || ( $grown[ $r ] === $grown[ $best ] && $n[ $r ] < $n[ $best ] ) ) ) {
				$best = $r;
			}
		}
		$best                  = -1 === $best ? $rooms - 1 : $best;
		$people[ $i ]['room'] = $best;
		$n[ $best ]++;
	}
	return array( $people, $keys );
}

/** The household's answers as a registration's data (the register area's shape, cleaned by its rules). */
function ogc_lod_registration( $a, $y, $nights ) {
	$people = array();
	$by     = isset( $a['roomingBy'] ) ? (array) $a['roomingBy'] : null;
	foreach ( $a['people'] as $p ) {
		$rm       = 'yf' !== $p['kind'] ? '' : ( null === $by ? $a['rooming'] : ( isset( $by[ $p['name'] ] ) ? $by[ $p['name'] ] : '' ) );
		$people[] = array( 'name' => $p['name'], 'kind' => $p['kind'], 'age' => $p['age'], 'yfHall' => $p['yfHall'], 'rooming' => $rm, 'room' => null );
	}
	$cfg   = ogc_lod_kv( $y, 'registration' );
	$beds  = max( 1, (int) ( isset( $cfg['room_beds'] ) && is_numeric( $cfg['room_beds'] ) ? $cfg['room_beds'] : 2 ) );
	$rooms = 'dorm' === $a['type'] ? max( 1, $a['rooms'] ) : 0;
	$keys  = array();
	if ( 'dorm' === $a['type'] ) {
		list( $people, $keys ) = ogc_lod_split( $people, $rooms, $beds + 1 );
	}
	$note = $a['note'];
	if ( ! empty( $a['roomingNote'] ) ) {
		$note = implode( ' · ', array_filter( array( $note, 'Young Folks rooming: ' . $a['roomingNote'] ) ) );
	}
	$in = array(
		'household' => array( 'name' => $a['surname'], 'contact' => $a['contact'], 'phone' => $a['phone'], 'email' => $a['email'] ),
		'people'    => $people,
		'stay'      => array(
			'type'       => $a['type'],
			'nights'     => $a['nights'],
			'rooms'      => max( 1, $a['rooms'] ),
			'roomsSet'   => $a['rooms'] > 0,
			'linens'     => $a['linens'],
			'mattresses' => $a['mats'],
			'ground'     => $a['ground'],
			'walker'     => $a['walker'],
			'nearW'      => $a['nearW'],
			'nearM'      => $a['nearM'],
			'near'       => $a['near'],
			'needs'      => $note,
			'camperLen'  => isset( $a['camperLen'] ) ? $a['camperLen'] : '',
			'arrive'     => isset( $a['arrive'] ) ? $a['arrive'] : '',
			'keys'       => array_values( array_filter( $keys ) ) ? $keys : array(),
		),
		'meals'     => array(),
		'gift'      => 0,
	);
	if ( function_exists( 'ogc_reg_clean' ) ) {
		$d = ogc_reg_clean( $in, $y );
		// The Form's own counts stand (the rules would cap mattresses when the year has no price for them).
		if ( 'dorm' === $d['stay']['type'] ) {
			$d['stay']['mattresses'] = $a['mats'];
		}
	} else {
		$d = $in;
	}
	// What the Form said about payment, as it said it ('' when the file has no such column), and the
	// oldest adult's age when written ("Grandma Ruth (82)"): Mark older suggests from it.
	$oldest = 0;
	foreach ( $a['people'] as $p ) {
		if ( 'adult' === $p['kind'] && is_numeric( $p['age'] ) ) {
			$oldest = max( $oldest, (int) $p['age'] );
		}
	}
	$d['form'] = array( 'pay' => isset( $a['pay'] ) ? $a['pay'] : '', 'payText' => isset( $a['payText'] ) ? $a['payText'] : '', 'oldest' => $oldest );
	return $d;
}

/**
 * The Form has one roommate box per household, not per Young Folk (2026). Each name in it goes to the
 * household's Young Folk in the hall that person is registered in; a name that matches nobody stays
 * with the only Young Folk (the board says "not registered"), or, with Young Folks in both halls, is
 * listed under Check and kept in Lodging's note. $yf: every Young Folk known (this file and the
 * year's registrations): array of array( name, hall, household key ).
 */
function ogc_lod_rooming_split( $a, $yf, &$probs, $gid ) {
	$mine = array_values( array_filter( $a['people'], function ( $p ) { return 'yf' === $p['kind']; } ) );
	$by   = array();
	$left = array();
	if ( ! $mine || '' === trim( $a['rooming'] ) ) {
		$a['roomingBy'] = $by;
		return $a;
	}
	$low  = function ( $t ) { return strtolower( trim( preg_replace( '/\s+/', ' ', (string) $t ) ) ); };
	$find = function ( $t ) use ( $yf, $low ) {
		$t  = $low( $t );
		$w  = explode( ' ', $t );
		$hits = array_values( array_filter( $yf, function ( $x ) use ( $t, $low ) { return $low( $x[0] ) === $t; } ) );
		if ( ! $hits && count( $w ) > 1 && 1 === strlen( rtrim( end( $w ), '.' ) ) ) {
			$hits = array_values( array_filter( $yf, function ( $x ) use ( $w, $low ) { $n = explode( ' ', $low( $x[0] ) ); return $n[0] === $w[0] && substr( end( $n ), 0, 1 ) === rtrim( end( $w ), '.' ); } ) );
		}
		if ( ! $hits && 1 === count( $w ) ) {
			$hits = array_values( array_filter( $yf, function ( $x ) use ( $w, $low ) { $n = explode( ' ', $low( $x[0] ) ); return $n[0] === $w[0]; } ) );
		}
		return 1 === count( $hits ) ? $hits[0] : null;
	};
	foreach ( array_filter( array_map( 'trim', explode( ',', $a['rooming'] ) ) ) as $t ) {
		$hit = $find( $t );
		$to  = null;
		if ( $hit ) {
			foreach ( $mine as $p ) {
				if ( $p['yfHall'] === $hit[1] && $low( $p['name'] ) !== $low( $hit[0] ) ) {
					$to = $p;
					break;
				}
			}
		} elseif ( 1 === count( $mine ) ) {
			$to = $mine[0];
			$probs[] = array( 'line' => $a['line'], 'col' => 'Rooming with', 'cell' => $t, 'reason' => 'Not a registered Young Folk · kept for ' . $mine[0]['name'], 'field' => 'rooming', 'gid' => $gid );
		}
		if ( $to ) {
			$by[ $to['name'] ] = isset( $by[ $to['name'] ] ) ? $by[ $to['name'] ] . ', ' . $t : $t;
		} else {
			$left[]  = $t;
			$probs[] = array( 'line' => $a['line'], 'col' => 'Rooming with', 'cell' => $t, 'reason' => $hit ? 'In the ' . ( 'women' === $hit[1] ? 'young women’s' : 'young men’s' ) . ' hall · no one from this household there · kept in the note' : 'Not matched to a Young Folk · kept in the note', 'field' => 'rooming', 'gid' => $gid );
		}
	}
	$a['roomingBy']   = $by;
	$a['roomingNote'] = implode( ', ', $left );
	return $a;
}

/** What changed between two registrations' answers, in a few words each. */
function ogc_lod_diff( $old, $new ) {
	$out = array();
	$sp  = function ( $ns ) {
		$ns = array_values( (array) $ns );
		if ( ! $ns ) {
			return 'none';
		}
		$s = function ( $n ) { return substr( preg_replace( '/^Early /', '', $n ), 0, 3 ); };
		return 1 === count( $ns ) ? $s( $ns[0] ) : $s( $ns[0] ) . '–' . $s( end( $ns ) );
	};
	$TY = array( 'dorm' => 'Dorm', 'camper' => 'Camper lot', 'elsewhere' => 'Elsewhere', 'yf' => 'Young Folks halls' );
	$os = (array) $old['stay'];
	$ns = (array) $new['stay'];
	if ( $os['type'] !== $ns['type'] ) {
		$out[] = 'Staying ' . ( isset( $TY[ $os['type'] ] ) ? $TY[ $os['type'] ] : $os['type'] ) . ' → ' . ( isset( $TY[ $ns['type'] ] ) ? $TY[ $ns['type'] ] : $ns['type'] );
	}
	if ( (array) $os['nights'] !== (array) $ns['nights'] ) {
		$out[] = 'Nights ' . $sp( $os['nights'] ) . ' → ' . $sp( $ns['nights'] );
	}
	foreach ( array( 'rooms' => 'Rooms', 'linens' => 'Linens', 'mattresses' => 'Air mattresses' ) as $k => $l ) {
		if ( (int) ( isset( $os[ $k ] ) ? $os[ $k ] : 0 ) !== (int) ( isset( $ns[ $k ] ) ? $ns[ $k ] : 0 ) ) {
			$out[] = $l . ' ' . (int) ( isset( $os[ $k ] ) ? $os[ $k ] : 0 ) . ' → ' . (int) ( isset( $ns[ $k ] ) ? $ns[ $k ] : 0 );
		}
	}
	$names = function ( $d ) {
		$n = array();
		foreach ( (array) $d['people'] as $p ) {
			$n[] = strtolower( $p['name'] );
		}
		sort( $n );
		return $n;
	};
	if ( $names( $old ) !== $names( $new ) ) {
		$out[] = 'People ' . count( $old['people'] ) . ' → ' . count( $new['people'] );
	}
	foreach ( array( 'ground' => 'Ground floor', 'walker' => 'Step-free', 'nearW' => 'Near women’s restroom', 'nearM' => 'Near men’s restroom' ) as $k => $l ) {
		if ( ! empty( $os[ $k ] ) !== ! empty( $ns[ $k ] ) ) {
			$out[] = $l . ( empty( $ns[ $k ] ) ? ' · no' : '' );
		}
	}
	if ( ( isset( $os['near'] ) ? $os['near'] : '' ) !== ( isset( $ns['near'] ) ? $ns['near'] : '' ) ) {
		$out[] = 'Near changed';
	}
	if ( ( isset( $os['needs'] ) ? $os['needs'] : '' ) !== ( isset( $ns['needs'] ) ? $ns['needs'] : '' ) ) {
		$out[] = 'Note changed';
	}
	$rm = function ( $d ) {
		return implode( '|', array_map( function ( $p ) { return isset( $p['rooming'] ) ? $p['rooming'] : ''; }, (array) $d['people'] ) );
	};
	if ( $rm( $old ) !== $rm( $new ) ) {
		$out[] = 'Rooming with changed';
	}
	$pw = function ( $d ) {
		$v = isset( $d['form']['pay'] ) ? (string) $d['form']['pay'] : '';
		return 'paid' === $v ? 'Paid' : ( 'pending' === $v ? 'Pending' : ( '' === $v ? '' : 'Other' ) );
	};
	if ( $pw( $new ) !== '' && $pw( $old ) !== $pw( $new ) ) {
		$out[] = 'Payment ' . ( '' !== $pw( $old ) ? $pw( $old ) . ' → ' : '' ) . $pw( $new );
	}
	return $out;
}

/* ================================================================== the route */

/** The mapping saved for this year, or last year's (headings → field). */
function ogc_lod_mapping( $y ) {
	$m = ogc_lod_row( $y, 'meta:mapping' );
	if ( $m ) {
		return (array) $m['data'];
	}
	$p = ogc_lod_prev_year( $y );
	$m = $p ? ogc_lod_row( $p, 'meta:mapping' ) : null;
	return $m ? array_merge( (array) $m['data'], array( 'from' => $p ) ) : array();
}

/** The household words for the preview: "Miller, Daniel and Esther · 3 rooms · Fri–Tue". */
function ogc_lod_words( $d ) {
	$s = $d['stay'];
	$b = array( function_exists( 'ogc_lod_label' ) ? ogc_lod_label( $d ) : $d['household']['contact'] );
	if ( 'dorm' === $s['type'] ) {
		$b[] = $s['rooms'] . ( 1 === (int) $s['rooms'] ? ' room' : ' rooms' );
	} elseif ( 'camper' === $s['type'] ) {
		$b[] = 'Camper lot';
	} else {
		$b[] = 'Elsewhere';
	}
	return implode( ' · ', $b );
}

function ogc_lod_rest_import( WP_REST_Request $req ) {
	$y = (int) $req['year'];
	if ( ogc_lod_held( $y, $req ) ) {
		return ogc_lod_err( 'ogc_held', 'Held · No changes', 403 );
	}
	$raw = (string) $req->get_param( 'text' );
	if ( strlen( $raw ) > 3 * MB_IN_BYTES ) {
		return ogc_lod_err( 'ogc_big', 'File too large', 413 );
	}
	list( $text, $enc )   = ogc_lod_text( $raw );
	list( $head, $rows, $lines ) = ogc_lod_csv( $text );
	if ( count( $head ) < 2 || ! $rows ) {
		return ogc_lod_err( 'ogc_bad', 'No responses in this file', 400 );
	}
	if ( count( $rows ) > 3000 || count( $head ) > 120 ) {
		return ogc_lod_err( 'ogc_big', 'File too large', 413 );
	}
	$fields = ogc_lod_fields();
	$step   = (string) $req->get_param( 'step' );
	$saved  = ogc_lod_mapping( $y );
	$guess  = ogc_lod_guess( $head );

	// Each column's field: what was asked now, else what was saved for this heading, else the guess.
	$asked = $req->get_param( 'mapping' );
	$map   = array();
	foreach ( $head as $i => $h ) {
		$f     = '';
		$state = 'unused';
		if ( is_array( $asked ) && array_key_exists( (string) $i, $asked ) ) {
			$f     = (string) $asked[ (string) $i ];
			$state = '' === $f ? 'unused' : 'matched';
		} elseif ( isset( $saved['cols'][ $h ] ) && ! ( '' === (string) $saved['cols'][ $h ] && (int) ( isset( $saved['v'] ) ? $saved['v'] : 1 ) < 2 && 'pay' === $guess[ $i ][0] ) ) {
			// A mapping saved before Payment existed (v1) left that column Not used: it's matched now.
			$f     = (string) $saved['cols'][ $h ];
			$state = '' === $f ? 'unused' : 'matched';
		} else {
			list( $f, $state ) = $guess[ $i ];
		}
		if ( '' !== $f && ! isset( $fields[ $f ] ) ) {
			$f     = '';
			$state = 'unused';
		}
		$map[ $i ] = array( $f, $state );
	}
	// A field (other than the note) filled by two columns: the second is to check.
	$seen = array();
	foreach ( $map as $i => $m ) {
		if ( '' !== $m[0] && ! $fields[ $m[0] ][4] ) {
			if ( isset( $seen[ $m[0] ] ) ) {
				$map[ $i ][1] = 'check';
			}
			$seen[ $m[0] ] = true;
		}
	}

	if ( 'columns' === $step ) {
		$cols = array();
		foreach ( $head as $i => $h ) {
			$ex = array();
			foreach ( $rows as $r ) {
				if ( isset( $r[ $i ] ) && '' !== trim( $r[ $i ] ) ) {
					// Cut at a whole name or word, never mid-name.
					$v = trim( $r[ $i ] );
					if ( mb_strlen( $v ) > 44 ) {
						$cut = mb_substr( $v, 0, 44 );
						$at  = max( (int) mb_strrpos( $cut, ', ' ), (int) mb_strrpos( $cut, ' ' ) );
						$v   = rtrim( mb_substr( $cut, 0, $at > 10 ? $at : 44 ), ' ,' ) . '…';
					}
					$ex[] = $v;
				}
				if ( count( $ex ) >= 2 ) {
					break;
				}
			}
			$cols[] = array( 'i' => $i, 'h' => $h, 'ex' => $ex, 'field' => $map[ $i ][0], 'state' => $map[ $i ][1] );
		}
		$fl = array();
		foreach ( $fields as $id => $d ) {
			$fl[] = array( 'id' => $id, 'label' => $d[0], 'help' => $d[1], 'multi' => $d[4] );
		}
		return rest_ensure_response( array( 'step' => 'columns', 'rows' => count( $rows ), 'encoding' => $enc, 'cols' => $cols, 'fields' => $fl, 'saved' => ! empty( $saved['cols'] ), 'from' => isset( $saved['from'] ) ? $saved['from'] : 0 ) );
	}

	// Read every row with the mapping.
	$cols = array();
	foreach ( $map as $i => $m ) {
		if ( '' !== $m[0] ) {
			$cols[ $m[0] ][] = $i;
		}
	}
	$cfg    = ogc_lod_kv( $y, 'registration' );
	$nights = function_exists( 'ogc_reg_nights' ) ? ogc_reg_nights( $cfg ) : array_values( array_filter( array_map( 'trim', explode( '|', isset( $cfg['nights'] ) ? $cfg['nights'] : '' ) ) ) );
	$groups = array();
	$probs  = array();
	foreach ( $rows as $k => $r ) {
		list( $a, $p ) = ogc_lod_answers( $r, $cols, $nights, $y, $lines[ $k ], $head );
		$g = ogc_lod_group_key( $a );
		$groups[ $g ][] = $a;
		foreach ( $p as $x ) {
			$x['gid'] = substr( md5( $g ), 0, 10 );
			$probs[]  = $x;
		}
	}
	// The form households already here, by their responses' keys and their group.
	$existing = array();
	$by_key   = array();
	$by_group = array();
	foreach ( ogc_records( $y, 'registrations' ) as $rec ) {
		if ( 'form' !== $rec['source'] ) {
			continue;
		}
		$rid              = isset( $rec['data']['rid'] ) ? $rec['data']['rid'] : '';
		$existing[ $rid ] = $rec;
		foreach ( (array) ( isset( $rec['data']['form']['keys'] ) ? $rec['data']['form']['keys'] : array() ) as $kk ) {
			$by_key[ $kk ] = $rid;
		}
		if ( ! empty( $rec['data']['form']['group'] ) ) {
			$by_group[ $rec['data']['form']['group'] ][] = $rid;
		}
	}
	// Every Young Folk known, for the roommate box: this file's and the year's other registrations'.
	$yfidx = array();
	foreach ( $groups as $g => $list ) {
		foreach ( $list as $a ) {
			foreach ( $a['people'] as $p ) {
				if ( 'yf' === $p['kind'] && '' !== $p['yfHall'] ) {
					$yfidx[ strtolower( $p['name'] ) ] = array( $p['name'], $p['yfHall'], $g );
				}
			}
		}
	}
	foreach ( ogc_records( $y, 'registrations' ) as $rec ) {
		foreach ( (array) ( isset( $rec['data']['people'] ) ? $rec['data']['people'] : array() ) as $p ) {
			if ( ! empty( $p['name'] ) && ( 'yf' === ( isset( $p['kind'] ) ? $p['kind'] : '' ) || ! empty( $p['yf'] ) ) && ! empty( $p['yfHall'] ) && ! isset( $yfidx[ strtolower( $p['name'] ) ] ) ) {
				$yfidx[ strtolower( $p['name'] ) ] = array( $p['name'], $p['yfHall'], '' );
			}
		}
	}
	$yfidx   = array_values( $yfidx );
	$choices = (array) $req->get_param( 'choices' );
	$plan    = array();
	$matched = array();
	foreach ( $groups as $g => $list ) {
		$gid   = substr( md5( $g ), 0, 10 );
		$same  = true;
		$names = function ( $a ) {
			$n = array_map( function ( $p ) { return strtolower( $p['name'] ); }, $a['people'] );
			sort( $n );
			return implode( '|', $n );
		};
		foreach ( $list as $a ) {
			$same = $same && $names( $a ) === $names( $list[0] ) && $a['type'] === $list[0]['type'];
		}
		// The same people sent again: a change (keep the newest). Different people: more rooms (combine).
		$suggest = count( $list ) < 2 ? 'one' : ( $same ? 'newest' : 'combine' );
		// Lodging's choice on the last upload stands until changed (polish: "Keep both" fell back to
		// Keep newest every week, and the households merged).
		$was = '';
		foreach ( isset( $by_group[ $g ] ) ? $by_group[ $g ] : array() as $cand ) {
			$c0 = isset( $existing[ $cand ]['data']['form']['choice'] ) ? (string) $existing[ $cand ]['data']['form']['choice'] : '';
			if ( in_array( $c0, array( 'combine', 'newest', 'both' ), true ) && count( $list ) > 1 ) {
				$was = $c0;
				break;
			}
		}
		$choice  = isset( $choices[ $gid ] ) && in_array( $choices[ $gid ], array( 'combine', 'newest', 'both' ), true ) ? $choices[ $gid ] : ( '' !== $was ? $was : ( 'one' === $suggest ? 'combine' : $suggest ) );
		$parts   = 'both' === $choice ? array_map( function ( $a ) { return array( $a ); }, $list ) : array( $list );
		foreach ( $parts as $pi => $part ) {
			$a   = ogc_lod_merge( $part, 'both' === $choice ? 'combine' : $choice );
			$a   = ogc_lod_rooming_split( $a, $yfidx, $probs, $gid );
			$d   = ogc_lod_registration( $a, $y, $nights );
			$rid = '';
			foreach ( $a['keys'] as $kk ) {
				if ( isset( $by_key[ $kk ] ) && ! isset( $matched[ $by_key[ $kk ] ] ) ) {
					$rid = $by_key[ $kk ];
					break;
				}
			}
			if ( '' === $rid && 'both' !== $choice && ! empty( $by_group[ $g ] ) ) {
				foreach ( $by_group[ $g ] as $cand ) {
					if ( ! isset( $matched[ $cand ] ) ) {
						$rid = $cand;
						break;
					}
				}
			}
			if ( '' !== $rid ) {
				$matched[ $rid ] = true;
			}
			// A blank nights cell on a later upload is no change: the household's nights stand.
			if ( '' !== $rid && ! empty( $a['blankNights'] ) && ! empty( $existing[ $rid ]['data']['stay']['nights'] ) ) {
				$d['stay']['nights'] = $existing[ $rid ]['data']['stay']['nights'];
			}
			$what   = '' !== $rid ? ogc_lod_diff( $existing[ $rid ]['data'], $d ) : array();
			$plan[] = array(
				'gid'     => $gid,
				'g'       => $g,
				'part'    => $pi,
				'a'       => $a,
				'd'       => $d,
				'rid'     => $rid,
				'state'   => '' === $rid ? 'new' : ( $what ? 'changed' : 'same' ),
				'what'    => $what,
				'n'       => count( $list ),
				'suggest' => $suggest,
				'choice'  => $choice,
				'rows'    => array_map( function ( $x ) {
					return array( 'line' => $x['line'], 'at' => $x['stamp'], 'when' => ogc_lod_stamp_words( $x['stamp'], $x['at'] ), 'names' => implode( ', ', array_map( function ( $p ) { return strtok( $p['name'], ' ' ); }, $x['people'] ) ), 'people' => count( $x['people'] ), 'rooms' => $x['rooms'], 'nights' => $x['nights'] ? substr( $x['nights'][0], 0, 3 ) . ( count( $x['nights'] ) > 1 ? '–' . substr( end( $x['nights'] ), 0, 3 ) : '' ) : '', 'type' => $x['type'] );
				}, $list ),
			);
		}
	}
	$missing = array();
	foreach ( $existing as $rid => $rec ) {
		if ( ! isset( $matched[ $rid ] ) && 'cancelled' !== ( isset( $rec['data']['status'] ) ? $rec['data']['status'] : '' ) ) {
			$missing[] = array( 'rid' => $rid, 'label' => ogc_lod_words( $rec['data'] ) );
		}
	}
	$count = function ( $s ) use ( $plan ) {
		return count( array_filter( $plan, function ( $p ) use ( $s ) { return $p['state'] === $s; } ) );
	};

	// What to check is said for new and changed responses only: an unchanged file lists nothing again.
	$live = array();
	foreach ( $plan as $p ) {
		if ( 'same' !== $p['state'] ) {
			$live[ $p['gid'] ] = true;
		}
	}
	$probs = array_values( array_filter( $probs, function ( $x ) use ( $live ) { return isset( $live[ $x['gid'] ] ); } ) );
	// Each household keeps its own (the board's Review shows them: "From the Form · Nights blank").
	$prob_of = array();
	foreach ( $probs as $x ) {
		$prob_of[ $x['gid'] ][] = mb_substr( $x['col'] . ' · ' . $x['reason'], 0, 120 );
	}

	if ( 'check' === $step ) {
		$groups_out = array();
		foreach ( $plan as $p ) {
			if ( $p['n'] > 1 && 0 === $p['part'] ) {
				$groups_out[] = array( 'gid' => $p['gid'], 'label' => ogc_lod_words( $p['d'] ), 'n' => $p['n'], 'suggest' => $p['suggest'], 'choice' => $p['choice'], 'rows' => $p['rows'] );
			}
		}
		$out = array(
			'step'     => 'check',
			'summary'  => array( 'rows' => count( $rows ), 'households' => count( $plan ), 'merged' => array_sum( array_map( function ( $p ) { return 'both' === $p['choice'] || 0 !== $p['part'] ? 0 : $p['n'] - 1; }, $plan ) ), 'check' => count( $probs ), 'new' => $count( 'new' ), 'changed' => $count( 'changed' ), 'same' => $count( 'same' ), 'missing' => count( $missing ) ),
			'groups'   => $groups_out,
			'problems' => array_slice( array_map( function ( $x ) use ( $plan ) {
				foreach ( $plan as $p ) {
					if ( $p['gid'] === $x['gid'] ) {
						$x['label'] = ogc_lod_words( $p['d'] );
						break;
					}
				}
				return $x;
			}, $probs ), 0, 300 ),
			'changes'  => array_values( array_map( function ( $p ) { return array( 'rid' => $p['rid'], 'label' => ogc_lod_words( $p['d'] ), 'what' => $p['what'] ); }, array_filter( $plan, function ( $p ) { return 'changed' === $p['state']; } ) ) ),
			'new'      => array_values( array_map( function ( $p ) { return array( 'label' => ogc_lod_words( $p['d'] ), 'line' => $p['rows'][0]['line'] ); }, array_slice( array_filter( $plan, function ( $p ) { return 'new' === $p['state']; } ), 0, 400 ) ) ),
			'missing'  => $missing,
		);
		return rest_ensure_response( $out );
	}

	if ( 'apply' !== $step ) {
		return ogc_lod_err( 'ogc_bad', 'Not imported', 400 );
	}
	// Remember the columns for the next upload (and next year's).
	$keep = array();
	foreach ( $head as $i => $h ) {
		if ( '' !== trim( $h ) ) {
			$keep[ $h ] = $map[ $i ][0];
		}
	}
	ogc_lod_put( $y, 'meta:mapping', array( 'cols' => $keep, 'v' => 2, 'by' => ogc_lod_me(), 'at' => ogc_now() ) );

	$me      = ogc_lod_me();
	$now     = ogc_now();
	$created = array();
	$updated = array();
	$removed = array();
	$locked  = function_exists( 'ogc_reg_lock' ) ? ogc_reg_lock( $y ) : false;
	foreach ( $plan as $p ) {
		if ( 'same' === $p['state'] ) {
			continue;
		}
		$d    = $p['d'];
		$form = array_merge( isset( $d['form'] ) ? (array) $d['form'] : array(), array( 'keys' => $p['a']['keys'], 'group' => $p['g'], 'choice' => $p['choice'], 'at' => $now, 'problems' => isset( $prob_of[ $p['gid'] ] ) ? array_slice( array_values( array_unique( $prob_of[ $p['gid'] ] ) ), 0, 6 ) : array() ) );
		if ( 'changed' === $p['state'] ) {
			$rec  = $existing[ $p['rid'] ];
			$kept = array_intersect_key( $rec['data'], array_flip( array( 'rid', 'id', 'created', 'at', 'status', 'source', 'price', 'money', 'paid', 'checkDue', 'history', 'pay', 'sample' ) ) );
			$new  = array_merge( $d, $kept, array( 'form' => $form, 'updated' => $now ) );
			$new['history']   = array_slice( array_merge( (array) ( isset( $kept['history'] ) ? $kept['history'] : array() ), array( array( 'at' => $now, 'by' => 'committee', 'what' => 'Form · ' . implode( ' · ', $p['what'] ) ) ) ), -30 );
			$updated[ $rec['id'] ] = $rec['data'];
			ogc_record_update( $rec['id'], $new, $new['household']['email'] );
			continue;
		}
		$rid  = function_exists( 'ogc_reg_next_rid' ) ? ogc_reg_next_rid( $y ) : 'F-' . $y . '-' . wp_rand( 1000, 9999 );
		$data = array_merge( $d, array(
			'rid'      => $rid,
			'id'       => $rid,
			'source'   => 'form',
			'status'   => 'registered',
			'pay'      => 'form',
			'at'       => '' !== $p['a']['at'] ? $p['a']['at'] : substr( $now, 0, 10 ),
			'created'  => $now,
			'managers' => array(),
			// Paid through the Form's own payment: nothing owed here, nothing guessed.
			'price'    => array( 'lines' => array(), 'lodging_cents' => 0, 'gift_cents' => 0, 'total_cents' => 0, 'form' => true ),
			'money'    => array( 'total' => 0, 'paid' => 0, 'check' => 0, 'pending' => 0, 'refund' => 0, 'refunded' => 0, 'due' => 0 ),
			'history'  => array( array( 'at' => $now, 'by' => 'committee', 'what' => 'Imported from the Form' ) ),
			'form'     => $form,
		) );
		$id = ogc_record_insert( $y, 'registrations', $data, $data['household']['email'], false, 'form' );
		if ( $id ) {
			$created[] = $id;
		}
	}
	if ( $locked && function_exists( 'ogc_reg_unlock' ) ) {
		ogc_reg_unlock( $y );
	}
	$want = array_map( 'strval', (array) $req->get_param( 'remove' ) );
	foreach ( $missing as $m ) {
		if ( in_array( $m['rid'], $want, true ) ) {
			ogc_record_delete( $existing[ $m['rid'] ]['id'] );
			$removed[] = $existing[ $m['rid'] ]['id'];
		}
	}
	$summary = array( 'rows' => count( $rows ), 'created' => count( $created ), 'updated' => count( $updated ), 'removed' => count( $removed ), 'name' => mb_substr( sanitize_file_name( (string) $req->get_param( 'name' ) ), 0, 80 ) );
	// Only the last import can be undone: older ones' before-values go.
	global $wpdb;
	$wpdb->query( $wpdb->prepare( 'DELETE FROM ' . ogc_table( 'lodging' ) . ' WHERE year = %d AND rkey LIKE %s', $y, 'imp:%' ) );
	$iid = gmdate( 'ymdHis' ) . wp_rand( 100, 999 );
	ogc_lod_put( $y, 'imp:' . $iid, array( 'summary' => $summary, 'created' => $created, 'updated' => (object) $updated, 'removed' => $removed ) );
	ogc_log( 'lodging_import', $y, 'form', $summary );
	return rest_ensure_response( array( 'step' => 'done', 'id' => $iid, 'summary' => $summary, 'by' => $me ) );
}

function ogc_lod_rest_import_undo( WP_REST_Request $req ) {
	global $wpdb;
	$y  = (int) $req['year'];
	$id = (string) $req->get_param( 'id' );
	if ( ! preg_match( '/^\d{12,20}$/', $id ) ) {
		return ogc_lod_err( 'ogc_bad', 'Nothing to undo', 400 );
	}
	$row = ogc_lod_row( $y, 'imp:' . $id );
	if ( ! $row || ! empty( $row['data']['undone'] ) ) {
		return ogc_lod_err( 'ogc_gone', 'Nothing to undo', 404 );
	}
	$d = $row['data'];
	if ( ogc_lod_held( $y, $req ) ) {
		return ogc_lod_err( 'ogc_held', 'Conference over · Can’t undo', 403 );
	}
	// Only while nothing has been done with those households since (polish 1: undoing 89 households
	// after Lodging gave them rooms left the board and the published rooms pointing at removed people).
	$rids   = array();
	$since  = 0;
	$imp_at = (string) $row['at'];
	// (The loop has its own name: it once reused $id, and the import's own row was never marked undone.)
	foreach ( array_merge( (array) $d['created'], array_keys( (array) $d['updated'] ) ) as $rec_id ) {
		$rec = ogc_record_get( (int) $rec_id );
		if ( ! $rec ) {
			continue;
		}
		$rid = isset( $rec['data']['rid'] ) ? (string) $rec['data']['rid'] : '';
		if ( '' !== $rid ) {
			$rids[ $rid ] = true;
		}
		if ( ! empty( $rec['updated_at'] ) && $rec['updated_at'] > $imp_at ) {
			$since++;
		}
	}
	$roomed = 0;
	$worked = 0;
	foreach ( ogc_lod_rows( $y, 'hh:' ) as $k => $r ) {
		if ( isset( $rids[ substr( $k, 3 ) ] ) ) {
			$worked++;
			$roomed += empty( $r['data']['rooms'] ) ? 0 : 1;
		}
	}
	$pub  = ogc_lod_row( $y, 'meta:published' );
	$snap = $pub && ! empty( $pub['data']['date'] ) ? (array) $pub['data']['snap'] : array();
	$shown = count( array_intersect_key( $snap, $rids ) );
	if ( $roomed || $worked || $since || $shown ) {
		$why = $roomed ? 'Rooms given since · ' . $roomed . ( 1 === $roomed ? ' household' : ' households' ) . ( $shown ? ' · ' . $shown . ' published' : '' ) : ( $worked ? 'Worked on since · ' . $worked . ( 1 === $worked ? ' household' : ' households' ) : 'Changed since' );
		return ogc_lod_err( 'ogc_conflict', $why . ' · Can’t undo', 409 );
	}
	foreach ( (array) $d['created'] as $rid ) {
		ogc_record_delete( (int) $rid );
	}
	foreach ( (array) $d['updated'] as $rid => $old ) {
		$rec = ogc_record_get( (int) $rid );
		if ( $rec ) {
			ogc_record_update( (int) $rid, $old, isset( $old['household']['email'] ) ? $old['household']['email'] : '' );
		}
	}
	foreach ( (array) $d['removed'] as $rid ) {
		$wpdb->update( ogc_table( 'records' ), array( 'deleted_at' => null ), array( 'id' => (int) $rid ), array( '%s' ), array( '%d' ) );
	}
	$d['undone'] = array( 'by' => ogc_lod_me(), 'at' => ogc_now() );
	ogc_lod_put( $y, 'imp:' . $id, $d );
	ogc_log( 'lodging_import_undo', $y, 'form', array( 'created' => count( (array) $d['created'] ) ) );
	return rest_ensure_response( array( 'ok' => true, 'summary' => $d['summary'] ) );
}
