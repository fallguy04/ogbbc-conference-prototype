<?php
/**
 * Import from the Google Form (docs/20's middle path: if the registration Form stays for 2027,
 * Lodging's board reads its responses instead of anyone retyping them).
 *
 *   POST /years/{y}/lodging/import       { step: columns|check|apply, text, name, mapping, choices, remove }
 *   POST /years/{y}/lodging/import/undo  { id }   the last import, put back
 *
 * The file is read here and never kept: only the mapped answers become registrations (source "form").
 * Free text loses anything that looks like a phone number or an email; the Youngfolks' roommate box
 * keeps names only (2025's form collected phones and ages there). Members of the year only.
 *
 * Responses don't map one row to one household: 2025's form took one room per submission, and a change
 * meant submitting again. Rows are grouped by email (or by name and phone), and Lodging chooses for each
 * group: Combine (one household, rooms added up), Keep newest (a resubmission) or Keep both. A second
 * upload matches rows by the Form's response ID (or timestamp and email), skips what's unchanged, lists
 * what changed and what's missing (never removed unless Lodging says so). Undo import until the next one.
 */

defined( 'ABSPATH' ) || exit;

add_action( 'rest_api_init', function () {
	$Y = '(?P<year>\d{4})';
	register_rest_route( OGC_NS, "/years/$Y/lodging/import", array(
		array( 'methods' => 'POST', 'callback' => 'ogc_lod_rest_import', 'permission_callback' => 'ogc_lod_can' ),
	) );
	register_rest_route( OGC_NS, "/years/$Y/lodging/import/undo", array(
		array( 'methods' => 'POST', 'callback' => 'ogc_lod_rest_import_undo', 'permission_callback' => 'ogc_lod_can' ),
	) );
} );

/* ================================================================== the board's fields */

/**
 * What a column can fill, in the order headings are tried (the most particular first). Each: label,
 * help (the tooltip), the words that match it surely, the words that match it only to check, and
 * whether several columns may fill it.
 */
function ogc_lod_fields() {
	return array(
		'key'        => array( 'Response ID', 'The Form’s own number for a response, so a second upload finds it again', '/\b(response|submission|registration|entry)\s*(id|number|#)|^id$|edit (response )?(url|link)/i', '', false ),
		'at'         => array( 'Registered', 'When the response was sent (Timestamp)', '/^time\s*stamp$|timestamp|date submitted|submitted at/i', '/\bdate\b/i', false ),
		'email'      => array( 'Email', 'The household’s email: one registration per email', '/e-?mail/i', '', false ),
		'phone'      => array( 'Phone', 'The contact’s phone', '/phone|cell|mobile/i', '', false ),
		'pay'        => array( 'Payment', 'The Form’s payment status (Paid, Pending), shown as the Form says it', '/payment|paid\b|amount (paid|due)|balance/i', '', false ),
		'surname'    => array( 'Household name', 'The surname the household goes by', '/last name|surname|family name|household name/i', '', false ),
		'contact'    => array( 'Contact', 'Who registered (a name)', '/^(your )?(full )?name$|contact( person| name)?|name of (the )?person|first and last name|your name/i', '/\bname\b/i', false ),
		'rooming'    => array( 'Rooming with', 'Youngfolks’ roommates: names only are kept', '/room ?mates?|rooming with|room with/i', '', false ),
		'yfMen'      => array( 'Young men', 'Youngfolks staying in the young men’s hall (names, ages)', '/young (men|man)|boys?\b/i', '', false ),
		'yfWomen'    => array( 'Young women', 'Youngfolks staying in the young women’s hall (names, ages)', '/young (women|woman|ladies)|girls?\b/i', '', false ),
		'yf'         => array( 'Youngfolks', 'Youngfolks (names, ages); their hall is chosen on the board', '/young ?folks?|youth|young people/i', '', false ),
		'children'   => array( 'Children', 'Children (names and ages)', '/child|kids|children/i', '', false ),
		'adults'     => array( 'Adults', 'Adults (names)', '/\badults?\b/i', '', false ),
		'people'     => array( 'Everyone coming', 'Everyone (names, ages): under 18 as children', '/who(’|\')?s coming|who is coming|attending|everyone|all (persons|people)|names? (and ages )?of/i', '/\bpeople|persons|names\b/i', false ),
		'nearW'      => array( 'Near women’s restroom', 'Yes or no', '/wom[ae]n(’|\')?s? (rest|bath)\s?room/i', '', false ),
		'nearM'      => array( 'Near men’s restroom', 'Yes or no', '/\bmen(’|\')?s? (rest|bath)\s?room/i', '', false ),
		'walker'     => array( 'Step-free', 'A walker, wheelchair or no stairs at all (yes or no)', '/walker|wheel\s?chair|step.?free|mobility|handicap/i', '', false ),
		'ground'     => array( 'Ground floor', 'Yes or no', '/ground floor|first floor|no stairs|lower floor/i', '', false ),
		'mattresses' => array( 'Air mattresses', 'How many', '/mattress/i', '', false ),
		'linens'     => array( 'Linen packets', 'How many', '/linen|bedding|sheets/i', '', false ),
		'rooms'      => array( 'Rooms', 'How many dorm rooms', '/how many (dorm )?rooms|rooms? (needed|requested)|number of (dorm )?rooms|^(dorm )?rooms?$/i', '', false ),
		'near'       => array( 'Near', 'Another household or a group to be placed with (2025: “group name”)', '/group name|near (another|other)|placed (near|with)|together with|near family/i', '/\bnear\b|group/i', false ),
		'type'       => array( 'Staying', 'Dorm, camper lot or elsewhere', '/where (will|are) you stay|lodging (type|choice)|staying|accommodation|housing|dorm or camper/i', '/lodging|dorm|camper/i', false ),
		'camperLen'  => array( 'Camper length', 'Short, medium or long, or its length in feet (the camper host’s)', '/camper length|length of (your |the )?(camper|rv|trailer)|how long is (your |the )?(camper|rv|trailer)/i', '', false ),
		'arrive'     => array( 'Arrival', 'Afternoon, evening or late, or a time', '/arriv(al|ing|e) (time|at)|what time.*arriv|time of arrival|arrival time/i', '', false ),
		'nights'     => array( 'Nights', 'Which nights (Fri, Sat… or Friday–Monday)', '/nights?|which days|arrival|dates (staying|attending)/i', '', false ),
		'note'       => array( 'Note for Lodging', 'Anything Lodging should know; several columns may fill it', '/special|needs|note|comment|request|anything else|medical|accessib/i', '', true ),
	);
}

/* ================================================================== reading the file */

/** The file as UTF-8 text: Excel's re-saved CSV is Windows-1252; a byte-order mark is dropped. */
function ogc_lod_text( $text ) {
	$text = (string) $text;
	$enc  = 'UTF-8';
	if ( ! mb_check_encoding( $text, 'UTF-8' ) ) {
		$text = mb_convert_encoding( $text, 'UTF-8', 'Windows-1252' );
		$enc  = 'Windows-1252';
	}
	$text = preg_replace( '/^\xEF\xBB\xBF/', '', $text );
	return array( str_replace( array( "\r\n", "\r" ), "\n", $text ), $enc );
}

/** CSV (comma, semicolon or tab) → array( header, rows of cells, first line number of each row ). */
function ogc_lod_csv( $text ) {
	$first = strtok( $text, "\n" );
	$delim = ',';
	foreach ( array( "\t", ';' ) as $d ) {
		if ( substr_count( (string) $first, $d ) > substr_count( (string) $first, $delim ) ) {
			$delim = $d;
		}
	}
	$rows  = array();
	$lines = array();
	$row   = array();
	$cell  = '';
	$q     = false;
	$line  = 1;
	$start = 1;
	$len   = strlen( $text );
	for ( $i = 0; $i < $len; $i++ ) {
		$c = $text[ $i ];
		if ( $q ) {
			if ( '"' === $c ) {
				if ( $i + 1 < $len && '"' === $text[ $i + 1 ] ) {
					$cell .= '"';
					$i++;
				} else {
					$q = false;
				}
			} else {
				if ( "\n" === $c ) {
					$line++;
				}
				$cell .= $c;
			}
		} elseif ( '"' === $c && '' === $cell ) {
			$q = true;
		} elseif ( $c === $delim ) {
			$row[] = $cell;
			$cell  = '';
		} elseif ( "\n" === $c ) {
			$row[]   = $cell;
			$rows[]  = $row;
			$lines[] = $start;
			$row     = array();
			$cell    = '';
			$line++;
			$start = $line;
		} else {
			$cell .= $c;
		}
	}
	if ( '' !== $cell || $row ) {
		$row[]   = $cell;
		$rows[]  = $row;
		$lines[] = $start;
	}
	$head = $rows ? array_map( 'trim', array_shift( $rows ) ) : array();
	array_shift( $lines );
	// Blank rows go.
	$out = array();
	$at  = array();
	foreach ( $rows as $k => $r ) {
		if ( '' !== trim( implode( '', $r ) ) ) {
			$out[] = $r;
			$at[]  = $lines[ $k ];
		}
	}
	return array( $head, $out, $at );
}

/** The automatic match of each heading, with how sure it is: array( field, state ). */
function ogc_lod_guess( $head ) {
	$fields = ogc_lod_fields();
	$taken  = array();
	$out    = array();
	foreach ( $head as $i => $h ) {
		$out[ $i ] = array( '', 'unused' );
		if ( '' === trim( $h ) ) {
			continue;
		}
		foreach ( array( 2 => 'matched', 3 => 'check' ) as $slot => $state ) {
			foreach ( $fields as $f => $def ) {
				if ( '' !== $def[ $slot ] && preg_match( $def[ $slot ], $h ) && ( $def[4] || ! isset( $taken[ $f ] ) ) ) {
					$out[ $i ]   = array( $f, $state );
					$taken[ $f ] = true;
					break 2;
				}
			}
		}
	}
	return $out;
}

/* ================================================================== reading a cell */

function ogc_lod_yes( $v, &$problem ) {
	$v = strtolower( trim( (string) $v ) );
	if ( '' === $v || preg_match( '/^(no|n|none|false|0|no thanks|not needed|n\/a|-)\.?$/', $v ) ) {
		return false;
	}
	if ( preg_match( '/^(yes|y|x|true|1|✓|please|yes please|yes,? please|needed|required)\b/u', $v ) ) {
		return true;
	}
	$problem = 'Not yes or no';
	return false;
}

function ogc_lod_count( $v, &$problem, $max = 12 ) {
	$v = strtolower( trim( (string) $v ) );
	if ( '' === $v || preg_match( '/^(no|none|n\/a|-|zero)$/', $v ) ) {
		return 0;
	}
	$words = array( 'one' => 1, 'two' => 2, 'three' => 3, 'four' => 4, 'five' => 5, 'six' => 6 );
	if ( preg_match( '/\d+/', $v, $m ) ) {
		return min( $max, (int) $m[0] );
	}
	foreach ( $words as $w => $n ) {
		if ( false !== strpos( $v, $w ) ) {
			return $n;
		}
	}
	if ( preg_match( '/^(yes|y)$/', $v ) ) {
		return 1;
	}
	$problem = 'Not a number';
	return 0;
}

/** "Fri, Sat, Sun", "Friday-Monday", "Friday, June 5, Saturday, June 6", "All nights" → the year's nights. */
function ogc_lod_nights_of( $v, $nights, &$problem ) {
	$v = trim( (string) $v );
	if ( '' === $v ) {
		return null;
	}
	$main = array_values( array_filter( $nights, function ( $n ) { return 0 !== strpos( $n, 'Early ' ); } ) );
	// "All but Sunday", "Every night except Sunday", "Fri - Mon (not Sunday)": the nights named after the
	// "but" are taken away, and Check says how it was read (red team round 2, F2).
	if ( preg_match( '/\b(?:but(?: not)?|except|not|no|without|other than|minus|skip(?:ping)?)\b(.*)$/is', $v, $mx, PREG_OFFSET_CAPTURE ) && ! preg_match( '/^\s*sure\b/i', $mx[1][0] ) ) {
		preg_match_all( '/\b(mon|tue|wed|thu|fri|sat|sun)[a-z]*\.?/i', $mx[1][0], $dm );
		if ( $dm[1] ) {
			$less = array_map( function ( $d ) { return strtolower( substr( $d, 0, 3 ) ); }, $dm[1] );
			$head = trim( substr( $v, 0, $mx[0][1] ), " \t,;(-–—" );
			$p0   = '';
			$got  = '' === $head || ! preg_match( '/\b(mon|tue|wed|thu|fri|sat|sun)/i', $head ) ? $main : ogc_lod_nights_of( $head, $nights, $p0 );
			$got  = array_values( array_filter( (array) $got, function ( $n ) use ( $less ) { return ! in_array( strtolower( substr( preg_replace( '/^Early /', '', $n ), 0, 3 ) ), $less, true ); } ) );
			$problem = '' !== $p0 ? $p0 : 'Except ' . implode( ', ', array_map( 'ucfirst', array_unique( $less ) ) );
			if ( preg_match( '/\?|maybe|not sure|unsure/i', $v ) ) {
				$problem = 'Unsure';
			}
			return $got ? $got : null;
		}
	}
	if ( preg_match( '/\b(all|every|whole|entire)\b/i', $v ) ) {
		return $main;
	}
	preg_match_all( '/\b(mon|tue|wed|thu|fri|sat|sun)[a-z]*\.?/i', $v, $m, PREG_OFFSET_CAPTURE );
	if ( ! $m[0] ) {
		$problem = 'No nights';
		return null;
	}
	// The morning they leave, said as a night ("Friday - Wednesday", "Fri to Wed"): the day after the last
	// night. A range to it runs to the last night; on its own it adds nothing (red team E1).
	$wk   = array( 'sun', 'mon', 'tue', 'wed', 'thu', 'fri', 'sat' );
	$li   = $main ? array_search( strtolower( substr( end( $main ), 0, 3 ) ), $wk, true ) : false;
	$dep  = false !== $li ? $wk[ ( $li + 1 ) % 7 ] : '';
	$last = $main ? array_search( end( $main ), $nights, true ) : -1;
	$idx  = function ( $abbr ) use ( $nights, $dep ) {
		foreach ( $nights as $i => $n ) {
			if ( 0 !== strpos( $n, 'Early ' ) && strtolower( substr( $n, 0, 3 ) ) === strtolower( $abbr ) ) {
				return $i;
			}
		}
		return '' !== $dep && strtolower( substr( $abbr, 0, 3 ) ) === $dep ? -2 : -1;
	};
	$found = array();
	$days  = $m[1];
	for ( $k = 0; $k < count( $days ); $k++ ) {
		$i = $idx( $days[ $k ][0] );
		// "Friday-Monday", "Fri to Mon": everything between.
		if ( $k + 1 < count( $days ) ) {
			$between = substr( $v, $days[ $k ][1] + strlen( $m[0][ $k ][0] ), $days[ $k + 1 ][1] - $days[ $k ][1] - strlen( $m[0][ $k ][0] ) );
			// The words people put between ("Friday night through Monday night", "Fri evening to Mon")
			// don't break the range (red team round 2, F1).
			$between = preg_replace( '/\b(?:nights?|evenings?|eve|p\.?m\.?)(?=\W|$)/i', ' ', $between );
			if ( preg_match( '/^\s*(-|–|—|to|through|thru|until|till|til)\s*$/iu', $between ) ) {
				$j = $idx( $days[ $k + 1 ][0] );
				$j = -2 === $j ? (int) $last : $j;
				if ( $i >= 0 && $j >= $i ) {
					for ( $x = $i; $x <= $j; $x++ ) {
						$found[ $x ] = true;
					}
				} else {
					$problem = 'Night not offered';   // "Wednesday - Tuesday": never guessed
				}
				$k++;
				continue;
			}
		}
		if ( $i >= 0 ) {
			$found[ $i ] = true;
		} elseif ( -1 === $i ) {
			$problem = 'Night not offered';
		}
	}
	ksort( $found );
	$out = array();
	foreach ( array_keys( $found ) as $i ) {
		$out[] = $nights[ $i ];
	}
	// "Monday morning" may be the morning they leave, or a night: never guessed.
	if ( preg_match( '/\?|maybe|not sure|unsure|morning/i', $v ) ) {
		$problem = 'Unsure';
	}
	return $out ? $out : null;
}

/** "6/3/2026 14:22:05", "2026-03-04 10:00", "3/9/26", Excel's "7-May" → 2026-06-03. */
function ogc_lod_date_of( $v, $year ) {
	$v = trim( (string) $v );
	if ( preg_match( '/^(\d{4})-(\d\d)-(\d\d)/', $v, $m ) ) {
		return "$m[1]-$m[2]-$m[3]";
	}
	if ( preg_match( '/^(\d{1,2})\/(\d{1,2})\/(\d{2,4})/', $v, $m ) ) {
		$yy = strlen( $m[3] ) === 2 ? 2000 + (int) $m[3] : (int) $m[3];
		return sprintf( '%04d-%02d-%02d', $yy, $m[1], $m[2] );
	}
	if ( preg_match( '/^(\d{1,2})-([A-Za-z]{3})/', $v, $m ) ) {
		$mo = array_search( strtolower( $m[2] ), array( 'jan', 'feb', 'mar', 'apr', 'may', 'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec' ), true );
		if ( false !== $mo ) {
			return sprintf( '%04d-%02d-%02d', $mo >= 9 ? $year - 1 : $year, $mo + 1, $m[1] );
		}
	}
	return '';
}

/** Free text without phone numbers or emails (the committees don't need them there). */
function ogc_lod_scrub( $v, $max = 500 ) {
	$v = preg_replace( '/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i', '', (string) $v );
	$v = preg_replace( '/(\+?1[\s.-]?)?\(?\d{3}\)?[\s.-]?\d{3}[\s.-]?\d{4}/', '', $v );
	$v = preg_replace( '/\b\d{3}[\s.-]\d{4}\b/', '', $v );   // a local number, 555-0134
	$v = preg_replace( '/\s{2,}/', ' ', $v );
	return mb_substr( trim( wp_strip_all_tags( $v ), " \t\n,;·-" ), 0, $max );
}

/**
 * An age as the Form writes it, in whole years, or null when the words aren't an age: "15", "15yo",
 * "15 y/o", "15 yrs old", "age 15", "17½", "18.5" (the years before the point), "sixteen", "18 months"
 * (1), "3 weeks", "10 days", "newborn", "infant", "baby" (0). Red team round 2, B1 and B2.
 */
function ogc_lod_age_of( $t ) {
	$t = strtolower( trim( (string) $t, " \t.,;:-" ) );
	$t = preg_replace( '/\s+/', ' ', $t );
	if ( '' === $t ) {
		return null;
	}
	if ( preg_match( '/^(?:a )?(?:new ?born|infant|baby|nb)$/', $t ) ) {
		return '0';
	}
	$t = preg_replace( '/^(?:age|aged)\s*:?\s*/', '', $t );
	$words = array( 'one' => 1, 'two' => 2, 'three' => 3, 'four' => 4, 'five' => 5, 'six' => 6, 'seven' => 7, 'eight' => 8, 'nine' => 9, 'ten' => 10, 'eleven' => 11, 'twelve' => 12, 'thirteen' => 13, 'fourteen' => 14, 'fifteen' => 15, 'sixteen' => 16, 'seventeen' => 17, 'eighteen' => 18, 'nineteen' => 19, 'twenty' => 20 );
	$num = '(\d{1,3}|' . implode( '|', array_keys( $words ) ) . ')';
	$val = function ( $n ) use ( $words ) {
		return isset( $words[ $n ] ) ? $words[ $n ] : (int) $n;
	};
	$old = '(?:\s*old)?';
	if ( preg_match( '/^' . $num . '\s*(?:wks?|weeks?|days?)\.?' . $old . '$/u', $t, $m ) ) {
		return '0';
	}
	if ( preg_match( '/^' . $num . '\s*(?:mo|mos|mths?|months?)\.?' . $old . '$/u', $t, $m ) ) {
		return (string) intdiv( $val( $m[1] ), 12 );
	}
	if ( preg_match( '/^' . $num . '(?:\.\d+|½|\s+and a half)?\s*(?:yo|y\.\s*o\.?|yrs?\.?|years?)?' . $old . '$/u', $t, $m ) ) {
		$n = $val( $m[1] );
		return $n <= 120 ? (string) $n : null;
	}
	return null;
}

/**
 * "Daniel Miller (45), Esther, Samuel 17" → array( array( name, age, extra words ) ), a lone first name
 * given the surname. Commas, slashes and "and" inside brackets never split a name ("Sam (15 y/o)", "Levi
 * (17, rooming with Sam)"); words in brackets that aren't an age come back as the third item, for the
 * note (red team round 2, A3, B3). Round 3 (B1–B5): "+" splits like "and"; "3 kids", "2 children", "the
 * baby" are nobody's name, so they come back in $odd (for Check and the note), never as a person; a lone
 * "Jr." or "III" after a comma joins the name before it; the surname alone ("Miller, Levi; Miller, Ruth")
 * is no one; "w/ Ben", "w/o Ruth", "with Ben" outside brackets are words beside the name, like brackets
 * ($rooming: the rooming wish's own field, where "w/ Ben" is Ben).
 */
function ogc_lod_names( $v, $surname, &$odd = null, $rooming = false ) {
	$odd = array();
	$v   = ogc_lod_scrub( $v, 800 );
	// "15 y/o" and "17 1/2" before the slash splits anything.
	$v = preg_replace( '/\by\s*\/\s*o\b/iu', 'yo', $v );
	$v = preg_replace( '/(\d)\s*1\s*\/\s*2\b/u', '$1½', $v );
	// Brackets kept whole: what's inside is set aside while the names are split.
	$bag = array();
	$v   = preg_replace_callback( '/\(([^()]*)(?:\)|$)/u', function ( $m ) use ( &$bag ) {
		$bag[] = $m[1];
		return "\x01" . ( count( $bag ) - 1 ) . "\x02";
	}, $v );
	// "w/ Ben Hoover", "w/o Ruth", "with Ben" outside brackets: words beside the name, up to the next comma.
	$with = '/(?:\bw\s*\/\s*o?|\bwith(?:out)?\b)\s*([^,;\n\x01]*)/iu';
	if ( $rooming ) {
		$v = preg_replace( '/(^|[,;\n&+])\s*(?:\bw\s*\/|\bwith\b)\s*/iu', '$1', $v );
	} else {
		$v = preg_replace_callback( $with, function ( $m ) use ( &$bag ) {
			$bag[] = trim( $m[0] );
			return "\x01" . ( count( $bag ) - 1 ) . "\x02";
		}, $v );
	}
	$count = '(?:\d{1,2}|a|an|one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|a few|few|some|several)';
	$noun  = '(?:kids?|children|child|boys?|girls?|grand ?(?:kids?|children|child|sons?|daughters?)|teens?|teenagers?|others?|more|people|persons?|guests?|family|babies|baby|infants?|toddlers?|sons?|daughters?|young ?folks?|youngfolks?|young (?:men|women|man|woman|people))';
	$out   = array();
	foreach ( preg_split( '/\s*(?:,|;|\n|\/|&|\+|\band\b|\bplus\b)\s*/i', $v ) as $part ) {
		$part = trim( $part, " \t" );
		if ( '' === $part ) {
			continue;
		}
		$inside = array();
		$part   = preg_replace_callback( '/\x01(\d+)\x02/', function ( $m ) use ( $bag, &$inside ) {
			$inside[] = $bag[ (int) $m[1] ];
			return ' ';
		}, $part );
		$part = trim( preg_replace( '/\s+/', ' ', preg_replace( '/[()]/', ' ', $part ) ), " .-\t" );
		// "3 kids", "two more children", "our 2 boys", "the baby": a count, never a person's name.
		if ( preg_match( '/^(?:(?:our|my|the|his|her|their|and)\s+)*(?:' . $count . '\s+)?(?:(?:more|other|small|little|young|older|younger)\s+)?' . $noun . '$/iu', $part ) ) {
			$odd[] = mb_substr( $part, 0, 40 );
			continue;
		}
		// "Sam Miller, Jr.": the Jr. after the comma is his.
		if ( preg_match( '/^(jr|sr|ii|iii|iv)$/i', $part, $sx ) ) {
			if ( $out ) {
				$out[ count( $out ) - 1 ][0] .= ' ' . ( in_array( strtolower( $sx[1] ), array( 'jr', 'sr' ), true ) ? ucfirst( strtolower( $sx[1] ) ) . '.' : strtoupper( $sx[1] ) );
			}
			continue;
		}
		$age = '';
		// An age written after the name, outside brackets ("Samuel 17", "Tia 6 mo", "Bo newborn").
		if ( preg_match( '/^(.*?\pL.*?)\s+((?:age\s*)?\d{1,3}(?:\.\d+|½)?\s*(?:yo|yrs?\.?|years?|wks?|weeks?|days?|mo|mos|mths?|months?)?\.?(?:\s*old)?|new ?born|infant)$/iu', $part, $m ) && null !== ogc_lod_age_of( $m[2] ) ) {
			$age  = ogc_lod_age_of( $m[2] );
			$part = trim( $m[1], " .-\t" );
		}
		// In brackets: the first bit that reads as an age is the age; the rest are words for the note.
		$extra = array();
		foreach ( $inside as $in ) {
			foreach ( preg_split( '/\s*[,;]\s*/', $in ) as $bit ) {
				$bit = trim( $bit );
				if ( '' === $bit ) {
					continue;
				}
				$a = ogc_lod_age_of( $bit );
				if ( null !== $a && '' === $age ) {
					$age = $a;
				} elseif ( null === $a || $a !== $age ) {
					$extra[] = $bit;
				}
			}
		}
		if ( '' === $part || ! preg_match( '/\pL/u', $part ) || mb_strlen( $part ) > 60 ) {
			continue;
		}
		$w = preg_split( '/\s+/', $part );
		if ( 1 === count( $w ) && '' !== $surname ) {
			// The surname alone ("Miller, Levi" as a church list writes it) is nobody.
			if ( 0 === strcasecmp( $part, $surname ) ) {
				continue;
			}
			$part .= ' ' . $surname;
		}
		// "SAMUEL" or "samuel" reads as "Samuel"; names written with care are kept as written.
		if ( ! preg_match( '/\p{Lu}/u', $part ) || ! preg_match( '/\p{Ll}/u', $part ) ) {
			$part = mb_convert_case( $part, MB_CASE_TITLE );
		}
		$out[] = array( $part, $age, mb_substr( implode( ', ', $extra ), 0, 80 ) );
	}
	return $out;
}

/* ================================================================== a row → a household's answers */

/**
 * One response as the board's answers: array( answers, problems ). $cols: field => array of column
 * indexes. $nights: the year's nights.
 */
function ogc_lod_answers( $cells, $cols, $nights, $year, $line, $head ) {
	$problems = array();
	$get      = function ( $f ) use ( $cells, $cols ) {
		if ( empty( $cols[ $f ] ) ) {
			return '';
		}
		$v = array();
		foreach ( $cols[ $f ] as $i ) {
			if ( isset( $cells[ $i ] ) && '' !== trim( $cells[ $i ] ) ) {
				$v[] = trim( $cells[ $i ] );
			}
		}
		return implode( ' · ', $v );
	};
	$flag     = function ( $f, $reason ) use ( &$problems, $cols, $cells, $line, $head ) {
		$i          = isset( $cols[ $f ][0] ) ? $cols[ $f ][0] : -1;
		$problems[] = array( 'line' => $line, 'col' => $i >= 0 ? $head[ $i ] : $f, 'cell' => mb_substr( $i >= 0 && isset( $cells[ $i ] ) ? $cells[ $i ] : '', 0, 80 ), 'reason' => $reason, 'field' => $f );
	};
	$contact = ogc_lod_scrub( $get( 'contact' ), 80 );
	$surname = ogc_lod_scrub( $get( 'surname' ), 40 );
	$people  = array();
	$besides = array();
	$uncount = array();
	$both    = array();
	$two     = array();
	$add     = function ( $list, $kind, $hall = '', $f = '' ) use ( &$people, &$besides, &$both, &$two ) {
		foreach ( $list as $p ) {
			// Words in brackets beside a name ("rooming with Sam"): kept in the note, never a person.
			if ( isset( $p[2] ) && '' !== $p[2] ) {
				$besides[] = array( $f, $p[0], $p[2] );
			}
			foreach ( $people as $qi => $q ) {
				if ( strtolower( $q['name'] ) === strtolower( $p[0] ) ) {
					// The same person with two ages ("Asa (17)" under Who's coming, "Asa (19)" under Young
					// men): neither is guessed; the age is left blank and Check says both (red team round 3, A6b).
					if ( '' !== $q['age'] && '' !== $p[1] && $q['age'] !== $p[1] ) {
						$two[ strtolower( $q['name'] ) ] = array( $f, $q['name'], $q['age'], $p[1] );
						$people[ $qi ]['age'] = '';
					} elseif ( '' === $q['age'] && '' !== $p[1] && ! isset( $two[ strtolower( $q['name'] ) ] ) ) {
						$people[ $qi ]['age'] = $p[1];
					}
					// Named under Everyone coming and again under a hall: a Youngfolk in that hall (red team B5).
					if ( 'yf' === $kind && 'any' === $q['src'] ) {
						$people[ $qi ]['kind']   = 'yf';
						$people[ $qi ]['yfHall'] = $hall;
						$people[ $qi ]['src']    = 'yf';
					} elseif ( 'any' === $q['src'] && 'any' !== $kind ) {
						// Under Everyone coming and again under Children or Adults: the column says which.
						$people[ $qi ]['kind'] = $kind;
						$people[ $qi ]['src']  = $kind;
					} elseif ( 'any' === $q['src'] && '' === $q['age'] && '' !== $people[ $qi ]['age'] ) {
						$people[ $qi ]['kind'] = (int) $people[ $qi ]['age'] < 18 ? 'child' : 'adult';
					} elseif ( 'yf' === $kind && 'yf' === $q['kind'] && '' !== $hall && '' !== $q['yfHall'] && $hall !== $q['yfHall'] ) {
						// Under Young men and again under Young women: no hall is guessed (red team round 3, A6).
						$people[ $qi ]['yfHall']          = '';
						$both[ strtolower( $q['name'] ) ] = array( $f, $q['name'] );
					}
					continue 2;
				}
			}
			$k = $kind;
			if ( 'any' === $kind ) {
				// Under 18 is a child of the household (never a grown-up who may take keys: red team B6).
				$k = '' !== $p[1] && (int) $p[1] < 18 ? 'child' : 'adult';
			}
			$people[] = array( 'name' => $p[0], 'kind' => $k, 'age' => $p[1], 'yfHall' => $hall, 'src' => $kind );
		}
	};
	if ( '' === $surname && '' !== $contact ) {
		$w       = preg_split( '/\s+/', $contact );
		$surname = count( $w ) > 1 ? end( $w ) : '';
	}
	foreach ( array( array( 'adults', 'adult', '' ), array( 'people', 'any', '' ), array( 'children', 'child', '' ), array( 'yfMen', 'yf', 'men' ), array( 'yfWomen', 'yf', 'women' ), array( 'yf', 'yf', '' ) ) as $g ) {
		$odd = array();
		$add( ogc_lod_names( $get( $g[0] ), $surname, $odd ), $g[1], $g[2], $g[0] );
		// "3 kids", "+ 2 children": nobody named, so nobody counted; Check and the note say so (red team
		// round 3, B1, B2). Lodging adds them by name if they come.
		foreach ( $odd as $o ) {
			$uncount[] = array( $g[0], $o );
		}
	}
	// The one who filled in the Form is coming unless the names say otherwise: their name as listed, or
	// their first name alone ("Ruth" for "Ruth Martin"), is that person. Youngfolks listed on their own
	// with someone else's name above them (a parent who isn't coming, a nickname): nobody is added, and
	// Check says so; a grown-up made up from "Your name" would take a family room and stand in for the
	// parent who must approve (red team round 2, A7).
	if ( '' !== $contact ) {
		$cl    = strtolower( trim( preg_replace( '/\s+/', ' ', $contact ) ) );
		$one   = false === strpos( $cl, ' ' );
		// "Sam Miller" is "Sam Miller Jr." when the names give the Jr. (red team round 3, B3).
		$bare  = function ( $n ) { return preg_replace( '/\s+(?:jr|sr|ii|iii|iv)\.?$/i', '', $n ); };
		$is_me = array_filter( $people, function ( $p ) use ( $cl, $one, $bare ) {
			$n = strtolower( $p['name'] );
			return $n === $cl || $bare( $n ) === $bare( $cl ) || ( $one && strtok( $n, ' ' ) === $cl );
		} );
		$yf_only = $people && count( array_filter( $people, function ( $p ) { return 'yf' === $p['kind']; } ) ) === count( $people );
		if ( ! $is_me && $yf_only ) {
			$flag( 'contact', 'Not under who’s coming · Not counted' );
		} elseif ( ! $is_me ) {
			array_unshift( $people, array( 'name' => $contact, 'kind' => 'adult', 'age' => '', 'yfHall' => '', 'src' => 'contact' ) );
		} elseif ( $one ) {
			$hit     = array_values( $is_me );
			$contact = $hit[0]['name'];
		}
	}
	if ( '' === $contact && $people ) {
		$contact = $people[0]['name'];
	}
	if ( '' === $surname && '' !== $contact ) {
		$w       = preg_split( '/\s+/', $contact );
		$surname = end( $w );
	}
	foreach ( $both as $b ) {
		$flag( $b[0], 'Both halls · ' . strtok( $b[1], ' ' ) );
	}
	foreach ( $two as $t ) {
		$flag( $t[0], 'Two ages · ' . strtok( $t[1], ' ' ) . ' · ' . $t[2] . ' and ' . $t[3] );
	}
	foreach ( $uncount as $u ) {
		$flag( $u[0], $u[1] . ' not named · Not counted' );
	}
	foreach ( $people as $p ) {
		$lk = strtolower( $p['name'] );
		if ( 'yf' === $p['kind'] && '' === $p['yfHall'] && ! isset( $both[ $lk ] ) ) {
			$flag( 'yf', 'Hall not given · ' . $p['name'] );
		}
		if ( isset( $two[ $lk ] ) ) {
			continue;
		}
		if ( 'child' === $p['kind'] && '' === $p['age'] ) {
			$flag( 'children', 'No age · ' . $p['name'] );
		}
		// A Youngfolk's age is never guessed: Lodging holds their hall room until it's known (red team B3, B4).
		if ( 'yf' === $p['kind'] && '' === $p['age'] ) {
			$flag( 'women' === $p['yfHall'] ? 'yfWomen' : ( 'men' === $p['yfHall'] ? 'yfMen' : 'yf' ), 'No age · ' . $p['name'] );
		}
	}
	if ( ! $people ) {
		$flag( 'contact', 'No names' );
	}
	// Where they'll stay.
	$tv    = strtolower( $get( 'type' ) );
	$p     = '';
	$rooms = ogc_lod_count( $get( 'rooms' ), $p, 6 );
	if ( $p ) {
		$flag( 'rooms', $p );
	}
	// Off campus is read first, whatever room the words name ("Hotel room in Marion", "Guest room at my
	// sister's", "Spare bedroom with relatives" are never a dorm room: red team E3, round 2 D2); then the
	// camper lot; then a room or hall on campus. Words that say two of them are imported as the first and
	// listed under Check.
	$off   = preg_match( '/else|hotel|motel|\binn\b|air ?bnb|off.?campus|relatives?|sister|brother|cousin|aunt|uncle|grand(?:ma|pa|parent)|friends?|guest ?room|spare|in town|staying with|\bwith (?:the|my|our)\b|(?<!motor )\bhome\b|commut|\bday(?:s| only)?\b|daily|local|nearby/', $tv );
	$camp  = preg_match( '/camper|camping|\brv\b|trailer|\btent\b|motor ?home|camp lot/', $tv );
	$onc   = preg_match( '/\bdorms?\b|dormitory|residence|\bhalls?\b|on.?site|(?<!off )(?<!off-)(?<!off)\bcampus\b|\brooms?\b|youngfolks/', $tv );
	$sure  = preg_match( '/\bdorms?\b|dormitory|residence|\bhalls?\b|on.?site|(?<!off )(?<!off-)(?<!off)\bcampus\b/', $tv );
	if ( $off ) {
		$type = 'elsewhere';
		if ( $camp || $sure ) {
			$flag( 'type', 'Read as Elsewhere · Check' );
		}
	} elseif ( $camp ) {
		$type = 'camper';
	} elseif ( $onc ) {
		$type = 'dorm';
	} else {
		$type = $rooms > 0 || '' === $tv ? 'dorm' : 'elsewhere';
		if ( '' !== $tv ) {
			$flag( 'type', 'Not dorm, camper or elsewhere' );
		}
	}
	$p  = '';
	$ns = ogc_lod_nights_of( $get( 'nights' ), $nights, $p );
	if ( 'elsewhere' === $type ) {
		$ns = array();
	} elseif ( null === $ns ) {
		$flag( 'nights', $p ? $p . ' · imported as all nights' : 'Blank · imported as all nights' );
		$ns = array_values( array_filter( $nights, function ( $n ) { return 0 !== strpos( $n, 'Early ' ); } ) );
		$blank_nights = true;
	} elseif ( $p ) {
		// Nights in a row as a span ("Fri–Mon"); with a gap, each one ("Fri, Sat, Mon").
		$at  = array_map( function ( $n ) use ( $nights ) { return (int) array_search( $n, $nights, true ); }, $ns );
		$row = end( $at ) - $at[0] === count( $at ) - 1;
		$ab  = function ( $n ) { return substr( preg_replace( '/^Early /', '', $n ), 0, 3 ); };
		$sp  = 1 === count( $ns ) ? $ab( $ns[0] ) : ( $row ? $ab( $ns[0] ) . '–' . $ab( end( $ns ) ) : implode( ', ', array_map( $ab, $ns ) ) );
		$flag( 'nights', $p . ' · imported as ' . $sp );
	}
	$yn = array();
	foreach ( array( 'ground', 'walker', 'nearW', 'nearM' ) as $f ) {
		$p        = '';
		$yn[ $f ] = ogc_lod_yes( $get( $f ), $p );
		if ( $p ) {
			$flag( $f, $p . ' · kept as a note' );
		}
	}
	$p      = '';
	$linens = ogc_lod_count( $get( 'linens' ), $p, 24 );
	if ( $p ) {
		$flag( 'linens', $p );
	}
	// Packets for a household with no dorm room (the camper lot, off campus) or of Youngfolks only are
	// the hall Youngfolks', one each (ogc_lod_registration); more than that is never counted, and Check
	// says so (red team round 2, D1).
	$yf_n    = count( array_filter( $people, function ( $q ) { return 'yf' === $q['kind']; } ) );
	$yf_only = $people && count( $people ) === $yf_n;
	if ( $linens > 0 && ( 'dorm' !== $type || $yf_only ) ) {
		$hall_n = $yf_only ? ( 'dorm' === $type ? $yf_n : 0 ) : $yf_n;
		if ( $linens > $hall_n ) {
			$flag( 'linens', $hall_n ? $hall_n . ' in the halls · ' . ( $linens - $hall_n ) . ' not counted' : 'No dorm room · Not counted' );
		}
	}
	$p   = '';
	$mat = ogc_lod_count( $get( 'mattresses' ), $p, 6 );
	if ( $p ) {
		$flag( 'mattresses', $p );
	}
	$notes = array();
	foreach ( (array) ( isset( $cols['note'] ) ? $cols['note'] : array() ) as $i ) {
		$v = isset( $cells[ $i ] ) ? ogc_lod_scrub( $cells[ $i ], 300 ) : '';
		if ( '' !== $v && ! preg_match( '/^(n\/?a|none|no|-)\.?$/i', $v ) ) {
			$notes[] = $v;
		}
	}
	foreach ( $besides as $b ) {
		$notes[] = strtok( $b[1], ' ' ) . ': ' . $b[2];
		$flag( $b[0], 'Words beside ' . strtok( $b[1], ' ' ) . ' · Kept in the note' );
	}
	foreach ( $uncount as $u ) {
		$notes[] = ogc_lod_fields()[ $u[0] ][0] . ': ' . $u[1];
	}
	foreach ( $two as $t ) {
		$notes[] = strtok( $t[1], ' ' ) . ': ' . $t[2] . ' and ' . $t[3];
	}
	// Answers that didn't read as yes or no are kept as words in the note, not dropped.
	foreach ( $problems as $pr ) {
		if ( in_array( $pr['field'], array( 'ground', 'walker', 'nearW', 'nearM' ), true ) && '' !== $pr['cell'] ) {
			$notes[] = ogc_lod_fields()[ $pr['field'] ][0] . ': ' . ogc_lod_scrub( $pr['cell'], 80 );
		}
	}
	$rooming = array();
	$odd = array();
	foreach ( ogc_lod_names( $get( 'rooming' ), '', $odd, true ) as $n ) {
		$rooming[] = $n[0];
	}
	$email = strtolower( trim( $get( 'email' ) ) );
	if ( '' !== $email && ! is_email( $email ) ) {
		$flag( 'email', 'Not an email' );
		$email = '';
	}
	$at = ogc_lod_date_of( $get( 'at' ), $year );
	// The camper's length and the arrival time, where the Form asks them (the camper host's lists).
	$lv  = strtolower( $get( 'camperLen' ) );
	$len = preg_match( '/(\d{2})/', $lv, $mm ) ? ( (int) $mm[1] < 25 ? 'short' : ( (int) $mm[1] < 35 ? 'mid' : 'long' ) ) : ( preg_match( '/short|small/', $lv ) ? 'short' : ( preg_match( '/med|mid/', $lv ) ? 'mid' : ( preg_match( '/long|large|big/', $lv ) ? 'long' : '' ) ) );
	$av  = strtolower( $get( 'arrive' ) );
	$arr = preg_match( '/late|night|after (9|10|11)/', $av ) ? 'late' : ( preg_match( '/evening|supper|after (5|6|7|8)|\b(5|6|7|8)(:\d\d)?\s*pm/', $av ) ? 'evening' : ( preg_match( '/afternoon|noon|\b(12|1|2|3|4)(:\d\d)?\s*pm/', $av ) ? 'afternoon' : ( preg_match( '/\b(9|10|11)(:\d\d)?\s*pm/', $av ) ? 'late' : '' ) ) );
	// The Form's payment status, as it says it (never "Paid" unless it says paid).
	$pv  = strtolower( trim( $get( 'pay' ) ) );
	$pay = '' === $pv ? '' : ( preg_match( '/pend|due|owe|unpaid|not|partial|wait|no\b/', $pv ) ? 'pending' : ( preg_match( '/paid|complete|received|yes|done/', $pv ) ? 'paid' : 'other' ) );
	if ( 'other' === $pay ) {
		$flag( 'pay', 'Not paid or pending · shown as written' );
	}
	$a  = array(
		'key'     => mb_substr( trim( $get( 'key' ) ), 0, 120 ),
		'at'      => $at,
		'stamp'   => trim( $get( 'at' ) ),
		'email'   => $email,
		'phone'   => mb_substr( preg_replace( '/[^0-9+()\s.-]/', '', $get( 'phone' ) ), 0, 30 ),
		'contact' => $contact,
		'surname' => $surname,
		'people'  => $people,
		'type'    => $type,
		'nights'  => $ns,
		'rooms'   => 'dorm' === $type ? $rooms : 0,
		'linens'  => $linens,
		'mats'    => 'dorm' === $type ? $mat : 0,
		'ground'  => $yn['ground'],
		'walker'  => $yn['walker'],
		'nearW'   => $yn['nearW'],
		'nearM'   => $yn['nearM'],
		'near'    => ogc_lod_scrub( $get( 'near' ), 60 ),
		'note'    => implode( ' · ', array_unique( $notes ) ),
		'rooming' => implode( ', ', $rooming ),
		'pay'     => $pay,
		'camperLen' => 'camper' === $type ? $len : '',
		'arrive'  => 'elsewhere' !== $type ? $arr : '',
		'payText' => ogc_lod_scrub( $get( 'pay' ), 30 ),
		'line'    => $line,
			'blankNights' => ! empty( $blank_nights ),
		);
		return array( $a, $problems );
}

/** A Form timestamp as people say it: "Mar 4, 7:02 PM" (or the date alone). */
function ogc_lod_stamp_words( $stamp, $iso ) {
	if ( preg_match( '/(\d{1,2}):(\d\d)/', (string) $stamp, $m ) && $iso ) {
		$d = DateTime::createFromFormat( '!Y-m-d', $iso );
		$h = (int) $m[1];
		return ( $d ? $d->format( 'M j' ) . ', ' : '' ) . ( ( $h % 12 ) ? $h % 12 : 12 ) . ':' . $m[2] . ( $h < 12 ? ' AM' : ' PM' );
	}
	$d = $iso ? DateTime::createFromFormat( '!Y-m-d', $iso ) : null;
	return $d ? $d->format( 'M j' ) : (string) $stamp;
}

/** Responses from one household: the same email; or the same name and phone; or else one each. */
function ogc_lod_group_key( $a ) {
	if ( '' !== $a['email'] ) {
		return 'e:' . $a['email'];
	}
	$digits = preg_replace( '/\D/', '', $a['phone'] );
	if ( '' !== $a['contact'] ) {
		return 'n:' . strtolower( $a['contact'] ) . '|' . substr( $digits, -4 );
	}
	return 'r:' . ( '' !== $a['key'] ? $a['key'] : $a['line'] );
}

/** A response's own key across uploads: the Form's response ID, or its timestamp and email. */
function ogc_lod_row_key( $a ) {
	return '' !== $a['key'] ? 'id:' . $a['key'] : 'ts:' . $a['stamp'] . '|' . ( '' !== $a['email'] ? $a['email'] : strtolower( $a['contact'] ) );
}

/** A group's rows as one household: combined (rooms added up), the newest one, or each row its own. */
function ogc_lod_merge( $rows, $choice ) {
	usort( $rows, function ( $a, $b ) { return strcmp( $a['at'] . $a['stamp'] . sprintf( '%06d', $a['line'] ), $b['at'] . $b['stamp'] . sprintf( '%06d', $b['line'] ) ); } );
	if ( 'newest' === $choice || 1 === count( $rows ) ) {
		$a         = end( $rows );
		$a['keys'] = array_map( 'ogc_lod_row_key', $rows );
		return $a;
	}
	$a = $rows[0];
	foreach ( array_slice( $rows, 1 ) as $r ) {
		foreach ( $r['people'] as $p ) {
			if ( ! array_filter( $a['people'], function ( $q ) use ( $p ) { return strtolower( $q['name'] ) === strtolower( $p['name'] ); } ) ) {
				$a['people'][] = $p;
			}
		}
		$a['rooms']  += $r['rooms'];
		$a['linens'] += $r['linens'];
		$a['mats']   += $r['mats'];
		$a['nights']  = array_values( array_unique( array_merge( $a['nights'], $r['nights'] ) ) );
		foreach ( array( 'ground', 'walker', 'nearW', 'nearM' ) as $f ) {
			$a[ $f ] = $a[ $f ] || $r[ $f ];
		}
		foreach ( array( 'near', 'phone', 'surname', 'contact' ) as $f ) {
			$a[ $f ] = '' !== $a[ $f ] ? $a[ $f ] : $r[ $f ];
		}
		$a['note']    = implode( ' · ', array_unique( array_filter( array( $a['note'], $r['note'] ) ) ) );
		$a['rooming'] = implode( ', ', array_unique( array_filter( array_merge( explode( ', ', $a['rooming'] ), explode( ', ', $r['rooming'] ) ) ) ) );
		if ( 'camper' === $r['type'] || 'dorm' === $r['type'] ) {
			$a['type'] = 'dorm' === $a['type'] || 'dorm' === $r['type'] ? 'dorm' : $r['type'];
		}
		$a['at'] = $r['at'] > $a['at'] ? $r['at'] : $a['at'];
		if ( '' !== $r['pay'] ) {
			// Several submissions: pending if any of them is.
			$a['pay']     = 'pending' === $a['pay'] || 'pending' === $r['pay'] ? 'pending' : $r['pay'];
			$a['payText'] = 'pending' === $r['pay'] || '' === $a['payText'] ? $r['payText'] : $a['payText'];
		}
	}
	$a['keys'] = array_map( 'ogc_lod_row_key', $rows );
	return $a;
}

/**
 * Who sleeps in which room, for a family of several rooms: a grown-up in each room first (the one who
 * picks up its keys sleeps in the room they open), then the children, each to the room with the fewest
 * people that has a grown-up, up to beds + 1 a room. With fewer grown-ups than rooms, the rest of the
 * children go together in the last room, and Review says "Children alone" (lodging-assumptions A7).
 * Returns array( people with 'room', keys per room ).
 */
function ogc_lod_split( $people, $rooms, $cap ) {
	$keys = array_fill( 0, $rooms, '' );
	if ( $rooms < 2 ) {
		foreach ( $people as $i => $p ) {
			if ( 'adult' === $p['kind'] && '' === $keys[0] ) {
				$keys[0] = $p['name'];
			}
		}
		return array( $people, $keys );
	}
	$n      = array_fill( 0, $rooms, 0 );
	$grown  = array_fill( 0, $rooms, false );
	$adults = array_keys( array_filter( $people, function ( $p ) { return 'adult' === $p['kind']; } ) );
	foreach ( $adults as $k => $i ) {
		$r                     = $k % $rooms;
		$people[ $i ]['room'] = $r;
		$n[ $r ]++;
		$grown[ $r ] = true;
		if ( '' === $keys[ $r ] ) {
			$keys[ $r ] = $people[ $i ]['name'];
		}
	}
	foreach ( $people as $i => $p ) {
		if ( 'adult' === $p['kind'] || 'yf' === $p['kind'] ) {
			continue;
		}
		$best = -1;
		for ( $r = 0; $r < $rooms; $r++ ) {
			if ( $n[ $r ] < $cap && ( -1 === $best || ( $grown[ $r ] && ! $grown[ $best ] ) || ( $grown[ $r ] === $grown[ $best ] && $n[ $r ] < $n[ $best ] ) ) ) {
				$best = $r;
			}
		}
		$best                  = -1 === $best ? $rooms - 1 : $best;
		$people[ $i ]['room'] = $best;
		$n[ $best ]++;
	}
	return array( $people, $keys );
}

/** The household's answers as a registration's data (the register area's shape, cleaned by its rules). */
function ogc_lod_registration( $a, $y, $nights ) {
	$people = array();
	$by     = isset( $a['roomingBy'] ) ? (array) $a['roomingBy'] : null;
	foreach ( $a['people'] as $p ) {
		$rm       = 'yf' !== $p['kind'] ? '' : ( null === $by ? $a['rooming'] : ( isset( $by[ $p['name'] ] ) ? $by[ $p['name'] ] : '' ) );
		$people[] = array( 'name' => $p['name'], 'kind' => $p['kind'], 'age' => $p['age'], 'yfHall' => $p['yfHall'], 'rooming' => $rm, 'room' => null );
	}
	// Youngfolks on their own: the packets the Form sold are theirs, one each (red team C3: a registration
	// of Youngfolks only keeps no room's packets, and the Form's were lost).
	// So are a camper or off-campus family's: their only beds the Conference makes up are the halls'
	// (red team round 2, D1).
	$yfs     = array_keys( array_filter( $people, function ( $p ) { return 'yf' === $p['kind']; } ) );
	$yf_only = $people && count( $yfs ) === count( $people );
	if ( $yfs && $a['linens'] > 0 && ( $yf_only || 'dorm' !== $a['type'] ) ) {
		foreach ( array_slice( $yfs, 0, (int) $a['linens'] ) as $i ) {
			$people[ $i ]['linens'] = true;
		}
	}
	$cfg   = ogc_lod_kv( $y, 'registration' );
	$beds  = max( 1, (int) ( isset( $cfg['room_beds'] ) && is_numeric( $cfg['room_beds'] ) ? $cfg['room_beds'] : 2 ) );
	$rooms = 'dorm' === $a['type'] ? max( 1, $a['rooms'] ) : 0;
	$keys  = array();
	if ( 'dorm' === $a['type'] ) {
		list( $people, $keys ) = ogc_lod_split( $people, $rooms, $beds + 1 );
	}
	$note = $a['note'];
	if ( ! empty( $a['roomingNote'] ) ) {
		$note = implode( ' · ', array_filter( array( $note, 'Youngfolks rooming: ' . $a['roomingNote'] ) ) );
	}
	$in = array(
		'household' => array( 'name' => $a['surname'], 'contact' => $a['contact'], 'phone' => $a['phone'], 'email' => $a['email'] ),
		'people'    => $people,
		'stay'      => array(
			'type'       => $a['type'],
			'nights'     => $a['nights'],
			'rooms'      => max( 1, $a['rooms'] ),
			'roomsSet'   => $a['rooms'] > 0,
			'linens'     => 'dorm' === $a['type'] && ! $yf_only ? $a['linens'] : 0,
			'mattresses' => $a['mats'],
			'ground'     => $a['ground'],
			'walker'     => $a['walker'],
			'nearW'      => $a['nearW'],
			'nearM'      => $a['nearM'],
			'near'       => $a['near'],
			'needs'      => $note,
			'camperLen'  => isset( $a['camperLen'] ) ? $a['camperLen'] : '',
			'arrive'     => isset( $a['arrive'] ) ? $a['arrive'] : '',
			'keys'       => array_values( array_filter( $keys ) ) ? $keys : array(),
		),
		'meals'     => array(),
		'gift'      => 0,
	);
	if ( function_exists( 'ogc_reg_clean' ) ) {
		$d = ogc_reg_clean( $in, $y );
		// The Form's own counts stand (the rules would cap mattresses when the year has no price for them).
		if ( 'dorm' === $d['stay']['type'] ) {
			$d['stay']['mattresses'] = $a['mats'];
		}
	} else {
		$d = $in;
	}
	// What the Form said about payment, as it said it ('' when the file has no such column), and the
	// oldest adult's age when written ("Grandma Ruth (82)"): Mark older suggests from it.
	$oldest = 0;
	foreach ( $a['people'] as $p ) {
		if ( 'adult' === $p['kind'] && is_numeric( $p['age'] ) ) {
			$oldest = max( $oldest, (int) $p['age'] );
		}
	}
	$d['form'] = array( 'pay' => isset( $a['pay'] ) ? $a['pay'] : '', 'payText' => isset( $a['payText'] ) ? $a['payText'] : '', 'oldest' => $oldest );
	return $d;
}

/**
 * The Form has one roommate box per household, not per Youngfolk (2026). Each name in it goes to the
 * household's Youngfolk in the hall that person is registered in; a name that matches nobody stays
 * with the only Youngfolk (the board says "not registered"), or, with Youngfolks in both halls, is
 * listed under Check and kept in Lodging's note. $yf: every Youngfolk known (this file and the
 * year's registrations): array of array( name, hall, household key ).
 */
function ogc_lod_rooming_split( $a, $yf, &$probs, $gid ) {
	$mine = array_values( array_filter( $a['people'], function ( $p ) { return 'yf' === $p['kind']; } ) );
	$by   = array();
	$left = array();
	if ( ! $mine || '' === trim( $a['rooming'] ) ) {
		$a['roomingBy'] = $by;
		return $a;
	}
	$low  = function ( $t ) { return strtolower( trim( preg_replace( '/\s+/', ' ', (string) $t ) ) ); };
	$find = function ( $t ) use ( $yf, $low ) {
		$t  = $low( $t );
		$w  = explode( ' ', $t );
		$hits = array_values( array_filter( $yf, function ( $x ) use ( $t, $low ) { return $low( $x[0] ) === $t; } ) );
		if ( ! $hits && count( $w ) > 1 && 1 === strlen( rtrim( end( $w ), '.' ) ) ) {
			$hits = array_values( array_filter( $yf, function ( $x ) use ( $w, $low ) { $n = explode( ' ', $low( $x[0] ) ); return $n[0] === $w[0] && substr( end( $n ), 0, 1 ) === rtrim( end( $w ), '.' ); } ) );
		}
		if ( ! $hits && 1 === count( $w ) ) {
			$hits = array_values( array_filter( $yf, function ( $x ) use ( $w, $low ) { $n = explode( ' ', $low( $x[0] ) ); return $n[0] === $w[0]; } ) );
		}
		return 1 === count( $hits ) ? $hits[0] : null;
	};
	foreach ( array_filter( array_map( 'trim', explode( ',', $a['rooming'] ) ) ) as $t ) {
		$hit = $find( $t );
		$to  = null;
		if ( $hit ) {
			foreach ( $mine as $p ) {
				if ( $p['yfHall'] === $hit[1] && $low( $p['name'] ) !== $low( $hit[0] ) ) {
					$to = $p;
					break;
				}
			}
		} elseif ( 1 === count( $mine ) ) {
			$to = $mine[0];
			$probs[] = array( 'line' => $a['line'], 'col' => 'Rooming with', 'cell' => $t, 'reason' => 'Not a registered Youngfolk · kept for ' . $mine[0]['name'], 'field' => 'rooming', 'gid' => $gid );
		}
		if ( $to ) {
			$by[ $to['name'] ] = isset( $by[ $to['name'] ] ) ? $by[ $to['name'] ] . ', ' . $t : $t;
		} else {
			$left[]  = $t;
			$probs[] = array( 'line' => $a['line'], 'col' => 'Rooming with', 'cell' => $t, 'reason' => $hit ? 'In the ' . ( 'women' === $hit[1] ? 'young women’s' : 'young men’s' ) . ' hall · no one from this household there · kept in the note' : 'Not matched to a Youngfolk · kept in the note', 'field' => 'rooming', 'gid' => $gid );
		}
	}
	$a['roomingBy']   = $by;
	$a['roomingNote'] = implode( ', ', $left );
	return $a;
}

/** What changed between two registrations' answers, in a few words each. */
function ogc_lod_diff( $old, $new ) {
	$out = array();
	$sp  = function ( $ns ) {
		$ns = array_values( (array) $ns );
		if ( ! $ns ) {
			return 'none';
		}
		$s = function ( $n ) { return substr( preg_replace( '/^Early /', '', $n ), 0, 3 ); };
		return 1 === count( $ns ) ? $s( $ns[0] ) : $s( $ns[0] ) . '–' . $s( end( $ns ) );
	};
	$TY = array( 'dorm' => 'Dorm', 'camper' => 'Camper lot', 'elsewhere' => 'Elsewhere', 'yf' => 'Youngfolks halls' );
	$os = (array) $old['stay'];
	$ns = (array) $new['stay'];
	if ( $os['type'] !== $ns['type'] ) {
		$out[] = 'Staying ' . ( isset( $TY[ $os['type'] ] ) ? $TY[ $os['type'] ] : $os['type'] ) . ' → ' . ( isset( $TY[ $ns['type'] ] ) ? $TY[ $ns['type'] ] : $ns['type'] );
	}
	if ( (array) $os['nights'] !== (array) $ns['nights'] ) {
		$out[] = 'Nights ' . $sp( $os['nights'] ) . ' → ' . $sp( $ns['nights'] );
	}
	foreach ( array( 'rooms' => 'Rooms', 'mattresses' => 'Air mattresses' ) as $k => $l ) {
		if ( (int) ( isset( $os[ $k ] ) ? $os[ $k ] : 0 ) !== (int) ( isset( $ns[ $k ] ) ? $ns[ $k ] : 0 ) ) {
			$out[] = $l . ' ' . (int) ( isset( $os[ $k ] ) ? $os[ $k ] : 0 ) . ' → ' . (int) ( isset( $ns[ $k ] ) ? $ns[ $k ] : 0 );
		}
	}
	// Linens: the rooms' packets and each hall Youngfolk's own.
	$lin = function ( $d ) {
		$n = (int) ( isset( $d['stay']['linens'] ) ? $d['stay']['linens'] : 0 );
		foreach ( (array) $d['people'] as $p ) {
			$n += empty( $p['linens'] ) ? 0 : 1;
		}
		return $n;
	};
	if ( $lin( $old ) !== $lin( $new ) ) {
		$out[] = 'Linens ' . $lin( $old ) . ' → ' . $lin( $new );
	}
	$key   = function ( $p ) {
		return strtolower( trim( preg_replace( '/\s+/', ' ', (string) ( isset( $p['name'] ) ? $p['name'] : '' ) ) ) );
	};
	$names = function ( $d ) use ( $key ) {
		$n = array_map( $key, (array) $d['people'] );
		sort( $n );
		return $n;
	};
	if ( $names( $old ) !== $names( $new ) ) {
		$out[] = 'People ' . count( $old['people'] ) . ' → ' . count( $new['people'] );
	}
	// The same person, said differently: an age corrected or filled in, a grown-up now a Youngfolk, the
	// other hall. Each is a change, so it's written (red team round 2, A1, A5: names alone were compared,
	// and the room kept a 17-year-old with a 20-year-old, or Jo in the young men's hall).
	$KIND = array( 'adult' => 'Grown-up', 'child' => 'Child', 'yf' => 'Youngfolk' );
	$HALL = array( 'men' => 'Young men', 'women' => 'Young women', '' => 'No hall' );
	$was  = array();
	foreach ( (array) $old['people'] as $p ) {
		$was[ $key( $p ) ][] = $p;
	}
	foreach ( (array) $new['people'] as $p ) {
		$k = $key( $p );
		if ( empty( $was[ $k ] ) ) {
			continue;
		}
		$q  = array_shift( $was[ $k ] );
		$f  = strtok( (string) $p['name'], ' ' );
		$ka = isset( $q['kind'] ) ? (string) $q['kind'] : '';
		$kb = isset( $p['kind'] ) ? (string) $p['kind'] : '';
		$aa = isset( $q['age'] ) ? (string) $q['age'] : '';
		$ab = isset( $p['age'] ) ? (string) $p['age'] : '';
		$ha = isset( $q['yfHall'] ) ? (string) $q['yfHall'] : '';
		$hb = isset( $p['yfHall'] ) ? (string) $p['yfHall'] : '';
		if ( $ka !== $kb ) {
			$out[] = $f . ' · ' . ( isset( $KIND[ $ka ] ) ? $KIND[ $ka ] : $ka ) . ' → ' . ( isset( $KIND[ $kb ] ) ? $KIND[ $kb ] : $kb );
		} elseif ( $aa !== $ab ) {
			$out[] = $f . ' · Age ' . ( '' === $aa ? '?' : $aa ) . ' → ' . ( '' === $ab ? '?' : $ab );
		}
		if ( 'yf' === $kb && 'yf' === $ka && $ha !== $hb ) {
			$out[] = $f . ' · ' . ( isset( $HALL[ $ha ] ) ? $HALL[ $ha ] : $ha ) . ' → ' . ( isset( $HALL[ $hb ] ) ? $HALL[ $hb ] : $hb );
		}
	}
	foreach ( array( 'ground' => 'Ground floor', 'walker' => 'Step-free', 'nearW' => 'Near women’s restroom', 'nearM' => 'Near men’s restroom' ) as $k => $l ) {
		if ( ! empty( $os[ $k ] ) !== ! empty( $ns[ $k ] ) ) {
			$out[] = $l . ( empty( $ns[ $k ] ) ? ' · no' : '' );
		}
	}
	if ( ( isset( $os['near'] ) ? $os['near'] : '' ) !== ( isset( $ns['near'] ) ? $ns['near'] : '' ) ) {
		$out[] = 'Near changed';
	}
	if ( ( isset( $os['needs'] ) ? $os['needs'] : '' ) !== ( isset( $ns['needs'] ) ? $ns['needs'] : '' ) ) {
		$out[] = 'Note changed';
	}
	$rm = function ( $d ) {
		return implode( '|', array_map( function ( $p ) { return isset( $p['rooming'] ) ? $p['rooming'] : ''; }, (array) $d['people'] ) );
	};
	if ( $rm( $old ) !== $rm( $new ) ) {
		$out[] = 'Rooming with changed';
	}
	$pw = function ( $d ) {
		$v = isset( $d['form']['pay'] ) ? (string) $d['form']['pay'] : '';
		return 'paid' === $v ? 'Paid' : ( 'pending' === $v ? 'Pending' : ( '' === $v ? '' : 'Other' ) );
	};
	if ( $pw( $new ) !== '' && $pw( $old ) !== $pw( $new ) ) {
		$out[] = 'Payment ' . ( '' !== $pw( $old ) ? $pw( $old ) . ' → ' : '' ) . $pw( $new );
	}
	return $out;
}

/* ================================================================== a re-import and the site's own changes */

/** The fields a Form response fills, each a path into the registration ("stay.nights"), and how to read them. */
function ogc_lod_form_fields() {
	return array( 'household.contact', 'household.phone', 'people', 'stay.type', 'stay.nights', 'stay.rooms', 'stay.linens', 'stay.mattresses', 'stay.ground', 'stay.walker', 'stay.nearW', 'stay.nearM', 'stay.near', 'stay.needs', 'stay.camperLen', 'stay.arrive' );
}

/** A field's value, comparable ("people" as who they are: name, kind, age, hall, where they sleep). */
function ogc_lod_form_val( $d, $path ) {
	if ( 'people' === $path ) {
		$out = array();
		foreach ( (array) ( isset( $d['people'] ) ? $d['people'] : array() ) as $p ) {
			$out[] = array( strtolower( trim( preg_replace( '/\s+/', ' ', (string) ( isset( $p['name'] ) ? $p['name'] : '' ) ) ) ), isset( $p['kind'] ) ? (string) $p['kind'] : '', isset( $p['age'] ) ? (string) $p['age'] : '', isset( $p['yfHall'] ) ? (string) $p['yfHall'] : '', isset( $p['sleeps'] ) ? (string) $p['sleeps'] : '' );
		}
		return $out;
	}
	list( $a, $b ) = explode( '.', $path );
	$v = isset( $d[ $a ][ $b ] ) ? $d[ $a ][ $b ] : null;
	return is_bool( $v ) ? $v : ( is_array( $v ) ? array_values( $v ) : ( null === $v ? '' : (string) $v ) );
}

/** The Form's answer as imported (kept as form.base), to tell the site's own changes from the Form's. */
function ogc_lod_form_base( $d ) {
	$out = array();
	foreach ( ogc_lod_form_fields() as $f ) {
		$out[ $f ] = ogc_lod_form_val( $d, $f );
	}
	return $out;
}

/**
 * A changed response laid onto the registration as it is now, field by field (invariant 98): what the
 * Form changed since the last upload is taken, unless the site changed it too (then the site's stays, and
 * Check says so); what the Form didn't change stays as the site has it. People keep who they are (their
 * pid) and the room they sleep in, matched by name within the household (invariant 96). A registration
 * imported before form.base was kept: the Form's answer is taken, as before. Returns array( data, kept ).
 */
function ogc_lod_form_merge( $cur, $new ) {
	$base = isset( $cur['form']['base'] ) && is_array( $cur['form']['base'] ) ? $cur['form']['base'] : null;
	$out  = $cur;
	$kept = array();
	foreach ( ogc_lod_form_fields() as $f ) {
		$theirs = ogc_lod_form_val( $new, $f );
		$ours   = ogc_lod_form_val( $cur, $f );
		if ( $base && array_key_exists( $f, $base ) ) {
			if ( $theirs == $base[ $f ] || $theirs == $ours ) {
				continue;   // the Form didn't change it, or says what the site says
			}
			if ( $ours != $base[ $f ] ) {
				$kept[] = $f;   // both changed it: the site's change stays
				continue;
			}
		} elseif ( $theirs == $ours ) {
			continue;
		}
		if ( 'people' === $f ) {
			$out['people'] = ogc_lod_keep_people( isset( $cur['people'] ) ? (array) $cur['people'] : array(), (array) $new['people'] );
			$out['stay']['keys'] = isset( $new['stay']['keys'] ) ? $new['stay']['keys'] : array();
		} else {
			list( $a, $b ) = explode( '.', $f );
			$out[ $a ][ $b ] = isset( $new[ $a ][ $b ] ) ? $new[ $a ][ $b ] : '';
		}
	}
	return array( $out, $kept );
}

/** The Form's people, each keeping the pid and room of the same name already on the registration. */
function ogc_lod_keep_people( $old, $new ) {
	$by = array();
	foreach ( $old as $p ) {
		$k = strtolower( trim( preg_replace( '/\s+/', ' ', (string) ( isset( $p['name'] ) ? $p['name'] : '' ) ) ) );
		if ( '' !== $k ) {
			$by[ $k ][] = $p;
		}
	}
	foreach ( $new as &$p ) {
		$k = strtolower( trim( preg_replace( '/\s+/', ' ', (string) ( isset( $p['name'] ) ? $p['name'] : '' ) ) ) );
		if ( ! empty( $by[ $k ] ) ) {
			$o        = array_shift( $by[ $k ] );
			$p['pid'] = isset( $o['pid'] ) ? $o['pid'] : ( isset( $p['pid'] ) ? $p['pid'] : '' );
			if ( isset( $o['room'] ) && null !== $o['room'] ) {
				$p['room'] = $o['room'];
			}
		}
	}
	unset( $p );
	return $new;
}

/** The form's own rules a response breaks (beds + 1 a room, the halls' beds), listed under Check (invariant 99). */
function ogc_lod_form_rules( $d, $y ) {
	if ( ! function_exists( 'ogc_reg_problems' ) ) {
		return array();
	}
	$out   = array();
	$names = array( 'stay.rooms' => 'Rooms', 'stay.yfMen' => 'Young men', 'stay.yfWomen' => 'Young women' );
	$who   = array();
	foreach ( (array) $d['people'] as $p ) {
		if ( ! empty( $p['pid'] ) ) {
			$who[ (string) $p['pid'] ] = $p;
		}
	}
	foreach ( ogc_reg_problems( $d, $y, true ) as $k => $msg ) {
		$k = (string) $k;
		// Only what Lodging can act on: the rooms, the halls' beds, a Youngfolk under the COA's age. The
		// form's own questions (I'm the parent · Ask a parent) aren't Lodging's (red team round 2, A8).
		if ( isset( $names[ $k ] ) ) {
			$out[] = mb_substr( $names[ $k ] . ' · ' . $msg, 0, 120 );
		} elseif ( preg_match( '/^people\.([^.]+)\.age$/', $k, $m ) && isset( $who[ $m[1] ] ) && ! empty( $who[ $m[1] ]['yf'] ) && false !== strpos( $msg, 'and up' ) ) {
			$out[] = mb_substr( 'Youngfolks · ' . ogc_lod_first( $who[ $m[1] ]['name'] ) . ' · ' . strtok( $msg, '·' ), 0, 120 );
		}
	}
	// A Youngfolk under 18 with no grown-up on the registration has no hall room until a parent approves.
	$adults = array_filter( (array) $d['people'], function ( $p ) { return 'adult' === ( isset( $p['kind'] ) ? $p['kind'] : '' ); } );
	if ( ! $adults ) {
		foreach ( (array) $d['people'] as $p ) {
			if ( ! empty( $p['minor'] ) ) {
				$out[] = 'Youngfolks · ' . ogc_lod_first( $p['name'] ) . ' · Under 18 alone · Parent approves first';
			}
		}
	}
	return array_values( array_unique( array_map( 'trim', $out ) ) );
}

/**
 * What the desk holds that an upload may not change, as the register's own doors refuse it (invariant 57):
 * a household checked in isn't moved out of the dorm, cancelled or removed; a Youngfolk's hall key out
 * isn't moved out of that room. $new null: the household is being removed. '' when nothing is held, else
 * the words ("Checked in", "Key out · Levi").
 */
function ogc_lod_desk_keeps( $y, $rec, $new ) {
	$row = ogc_lod_row( $y, 'hh:' . ogc_lod_rid( $rec ) );
	if ( $row && ogc_lod_checked_in( (array) $row['data'] ) ) {
		$to = null === $new ? '' : ( isset( $new['stay']['type'] ) ? (string) $new['stay']['type'] : 'dorm' );
		if ( null === $new || 'dorm' !== $to || 'cancelled' === ( isset( $new['status'] ) ? $new['status'] : '' ) ) {
			return 'Checked in';
		}
		// Nor are nights the desk saw slept taken away (red team round 3, X2-C1, as the register's doors).
		$w = function_exists( 'ogc_lod_slept_words' ) ? ogc_lod_slept_words( $y, $rec, $new, ogc_lod_today( $y ) ) : '';
		if ( '' !== $w ) {
			return $w;
		}
	}
	return null === $new ? ogc_lod_keys_out_words( $y, $rec ) : ogc_lod_key_out_moved( $y, $rec, $new );
}

/** "Checked in · Not updated · Undo check-in first", "Key out · Levi · Not removed · Undo key out first",
 * "Friday · Already stayed · Not updated · Undo check-in first". */
function ogc_lod_desk_words( $w, $what ) {
	return $w . ' · ' . $what . ' · ' . ( 'Checked in' === $w || false !== strpos( $w, 'Already stayed' ) ? 'Undo check-in first' : 'Undo key out first' );
}

/* ================================================================== the route */

/** The mapping saved for this year, or last year's (headings → field). */
function ogc_lod_mapping( $y ) {
	$m = ogc_lod_row( $y, 'meta:mapping' );
	if ( $m ) {
		return (array) $m['data'];
	}
	$p = ogc_lod_prev_year( $y );
	$m = $p ? ogc_lod_row( $p, 'meta:mapping' ) : null;
	return $m ? array_merge( (array) $m['data'], array( 'from' => $p ) ) : array();
}

/** The household words for the preview: "Miller, Daniel and Esther · 3 rooms · Fri–Tue". */
function ogc_lod_words( $d ) {
	$s = $d['stay'];
	$b = array( function_exists( 'ogc_lod_label' ) ? ogc_lod_label( $d ) : $d['household']['contact'] );
	if ( 'dorm' === $s['type'] ) {
		$b[] = $s['rooms'] . ( 1 === (int) $s['rooms'] ? ' room' : ' rooms' );
	} elseif ( 'camper' === $s['type'] ) {
		$b[] = 'Camper lot';
	} else {
		$b[] = 'Elsewhere';
	}
	return implode( ' · ', $b );
}

function ogc_lod_rest_import( WP_REST_Request $req ) {
	$y = (int) $req['year'];
	if ( ogc_lod_held( $y, $req ) ) {
		return ogc_lod_err( 'ogc_held', 'Held · No changes', 403 );
	}
	$raw = (string) $req->get_param( 'text' );
	if ( strlen( $raw ) > 3 * MB_IN_BYTES ) {
		return ogc_lod_err( 'ogc_big', 'File too large', 413 );
	}
	list( $text, $enc )   = ogc_lod_text( $raw );
	list( $head, $rows, $lines ) = ogc_lod_csv( $text );
	if ( count( $head ) < 2 || ! $rows ) {
		return ogc_lod_err( 'ogc_bad', 'No responses in this file', 400 );
	}
	if ( count( $rows ) > 3000 || count( $head ) > 120 ) {
		return ogc_lod_err( 'ogc_big', 'File too large', 413 );
	}
	$fields = ogc_lod_fields();
	$step   = (string) $req->get_param( 'step' );
	$saved  = ogc_lod_mapping( $y );
	$guess  = ogc_lod_guess( $head );

	// Each column's field: what was asked now, else what was saved for this heading, else the guess.
	$asked = $req->get_param( 'mapping' );
	$map   = array();
	foreach ( $head as $i => $h ) {
		$f     = '';
		$state = 'unused';
		if ( is_array( $asked ) && array_key_exists( (string) $i, $asked ) ) {
			$f     = (string) $asked[ (string) $i ];
			$state = '' === $f ? 'unused' : 'matched';
		} elseif ( isset( $saved['cols'][ $h ] ) && ! ( '' === (string) $saved['cols'][ $h ] && (int) ( isset( $saved['v'] ) ? $saved['v'] : 1 ) < 2 && 'pay' === $guess[ $i ][0] ) ) {
			// A mapping saved before Payment existed (v1) left that column Not used: it's matched now.
			$f     = (string) $saved['cols'][ $h ];
			$state = '' === $f ? 'unused' : 'matched';
		} else {
			list( $f, $state ) = $guess[ $i ];
		}
		if ( '' !== $f && ! isset( $fields[ $f ] ) ) {
			$f     = '';
			$state = 'unused';
		}
		$map[ $i ] = array( $f, $state );
	}
	// A field (other than the note) filled by two columns: the second is to check.
	$seen = array();
	foreach ( $map as $i => $m ) {
		if ( '' !== $m[0] && ! $fields[ $m[0] ][4] ) {
			if ( isset( $seen[ $m[0] ] ) ) {
				$map[ $i ][1] = 'check';
			}
			$seen[ $m[0] ] = true;
		}
	}

	if ( 'columns' === $step ) {
		$cols = array();
		foreach ( $head as $i => $h ) {
			$ex = array();
			foreach ( $rows as $r ) {
				if ( isset( $r[ $i ] ) && '' !== trim( $r[ $i ] ) ) {
					// Cut at a whole name or word, never mid-name.
					$v = trim( $r[ $i ] );
					if ( mb_strlen( $v ) > 44 ) {
						$cut = mb_substr( $v, 0, 44 );
						$at  = max( (int) mb_strrpos( $cut, ', ' ), (int) mb_strrpos( $cut, ' ' ) );
						$v   = rtrim( mb_substr( $cut, 0, $at > 10 ? $at : 44 ), ' ,' ) . '…';
					}
					$ex[] = $v;
				}
				if ( count( $ex ) >= 2 ) {
					break;
				}
			}
			$cols[] = array( 'i' => $i, 'h' => $h, 'ex' => $ex, 'field' => $map[ $i ][0], 'state' => $map[ $i ][1] );
		}
		$fl = array();
		foreach ( $fields as $id => $d ) {
			$fl[] = array( 'id' => $id, 'label' => $d[0], 'help' => $d[1], 'multi' => $d[4] );
		}
		return rest_ensure_response( array( 'step' => 'columns', 'rows' => count( $rows ), 'encoding' => $enc, 'cols' => $cols, 'fields' => $fl, 'saved' => ! empty( $saved['cols'] ), 'from' => isset( $saved['from'] ) ? $saved['from'] : 0 ) );
	}

	// Read every row with the mapping.
	$cols = array();
	foreach ( $map as $i => $m ) {
		if ( '' !== $m[0] ) {
			$cols[ $m[0] ][] = $i;
		}
	}
	$cfg    = ogc_lod_kv( $y, 'registration' );
	$nights = function_exists( 'ogc_reg_nights' ) ? ogc_reg_nights( $cfg ) : array_values( array_filter( array_map( 'trim', explode( '|', isset( $cfg['nights'] ) ? $cfg['nights'] : '' ) ) ) );
	$groups = array();
	$probs  = array();
	$heads  = array_map( function ( $h ) { return strtolower( trim( (string) $h ) ); }, $head );
	foreach ( $rows as $k => $r ) {
		// The heading row again (two downloads pasted into one file): never a household (red team round 2,
		// F3). Listed under Check whatever else the file holds (gid "file").
		$filled = 0;
		$same   = 0;
		foreach ( $r as $i => $c ) {
			$c = strtolower( trim( (string) $c ) );
			if ( '' !== $c ) {
				$filled++;
				$same += isset( $heads[ $i ] ) && $c === $heads[ $i ] ? 1 : 0;
			}
		}
		if ( $same >= 2 && 2 * $same >= $filled ) {
			$probs[] = array( 'line' => $lines[ $k ], 'col' => 'Row', 'cell' => '', 'reason' => 'Headings again · Not imported', 'field' => '', 'gid' => 'file' );
			continue;
		}
		list( $a, $p ) = ogc_lod_answers( $r, $cols, $nights, $y, $lines[ $k ], $head );
		$g = ogc_lod_group_key( $a );
		$groups[ $g ][] = $a;
		foreach ( $p as $x ) {
			$x['gid'] = substr( md5( $g ), 0, 10 );
			$probs[]  = $x;
		}
	}
	// An import is worked out and written under the registration's lock and Lodging's, from the
	// registrations as they are then: two imports at once never make a household twice (invariant 73),
	// and a change saved on the site meanwhile is never overwritten (74).
	$locked = false;
	if ( 'apply' === $step ) {
		if ( ! ogc_reg_lock( $y ) ) {
			return ogc_lod_busy();
		}
		if ( ! ogc_lod_lock( $y ) ) {
			ogc_reg_unlock( $y );
			return ogc_lod_busy();
		}
		$locked = true;
	}
	try {
	// The form households already here, by their responses' keys and their group.
	$existing = array();
	$by_key   = array();
	$by_group = array();
	foreach ( ogc_records( $y, 'registrations' ) as $rec ) {
		if ( 'form' !== $rec['source'] ) {
			continue;
		}
		$rid              = isset( $rec['data']['rid'] ) ? $rec['data']['rid'] : '';
		$existing[ $rid ] = $rec;
		foreach ( (array) ( isset( $rec['data']['form']['keys'] ) ? $rec['data']['form']['keys'] : array() ) as $kk ) {
			$by_key[ $kk ] = $rid;
		}
		if ( ! empty( $rec['data']['form']['group'] ) ) {
			$by_group[ $rec['data']['form']['group'] ][] = $rid;
		}
	}
	// Every Youngfolk known, for the roommate box: this file's and the year's other registrations'.
	$yfidx = array();
	foreach ( $groups as $g => $list ) {
		foreach ( $list as $a ) {
			foreach ( $a['people'] as $p ) {
				if ( 'yf' === $p['kind'] && '' !== $p['yfHall'] ) {
					$yfidx[ strtolower( $p['name'] ) ] = array( $p['name'], $p['yfHall'], $g );
				}
			}
		}
	}
	foreach ( ogc_records( $y, 'registrations' ) as $rec ) {
		foreach ( (array) ( isset( $rec['data']['people'] ) ? $rec['data']['people'] : array() ) as $p ) {
			if ( ! empty( $p['name'] ) && ( 'yf' === ( isset( $p['kind'] ) ? $p['kind'] : '' ) || ! empty( $p['yf'] ) ) && ! empty( $p['yfHall'] ) && ! isset( $yfidx[ strtolower( $p['name'] ) ] ) ) {
				$yfidx[ strtolower( $p['name'] ) ] = array( $p['name'], $p['yfHall'], '' );
			}
		}
	}
	$yfidx   = array_values( $yfidx );
	$choices = (array) $req->get_param( 'choices' );
	$plan    = array();
	$matched = array();
	foreach ( $groups as $g => $list ) {
		$gid   = substr( md5( $g ), 0, 10 );
		$same  = true;
		$names = function ( $a ) {
			$n = array_map( function ( $p ) { return strtolower( $p['name'] ); }, $a['people'] );
			sort( $n );
			return implode( '|', $n );
		};
		foreach ( $list as $a ) {
			$same = $same && $names( $a ) === $names( $list[0] ) && $a['type'] === $list[0]['type'];
		}
		// The same people sent again: a change (keep the newest). Different people: more rooms (combine).
		$suggest = count( $list ) < 2 ? 'one' : ( $same ? 'newest' : 'combine' );
		// Lodging's choice on the last upload stands until changed (polish: "Keep both" fell back to
		// Keep newest every week, and the households merged).
		$was = '';
		foreach ( isset( $by_group[ $g ] ) ? $by_group[ $g ] : array() as $cand ) {
			$c0 = isset( $existing[ $cand ]['data']['form']['choice'] ) ? (string) $existing[ $cand ]['data']['form']['choice'] : '';
			if ( in_array( $c0, array( 'combine', 'newest', 'both' ), true ) && count( $list ) > 1 ) {
				$was = $c0;
				break;
			}
		}
		$choice  = isset( $choices[ $gid ] ) && in_array( $choices[ $gid ], array( 'combine', 'newest', 'both' ), true ) ? $choices[ $gid ] : ( '' !== $was ? $was : ( 'one' === $suggest ? 'combine' : $suggest ) );
		$parts   = 'both' === $choice ? array_map( function ( $a ) { return array( $a ); }, $list ) : array( $list );
		foreach ( $parts as $pi => $part ) {
			$a   = ogc_lod_merge( $part, 'both' === $choice ? 'combine' : $choice );
			$a   = ogc_lod_rooming_split( $a, $yfidx, $probs, $gid );
			$d   = ogc_lod_registration( $a, $y, $nights );
			$rid = '';
			foreach ( $a['keys'] as $kk ) {
				if ( isset( $by_key[ $kk ] ) && ! isset( $matched[ $by_key[ $kk ] ] ) ) {
					$rid = $by_key[ $kk ];
					break;
				}
			}
			if ( '' === $rid && 'both' !== $choice && ! empty( $by_group[ $g ] ) ) {
				foreach ( $by_group[ $g ] as $cand ) {
					if ( ! isset( $matched[ $cand ] ) ) {
						$rid = $cand;
						break;
					}
				}
			}
			if ( '' !== $rid ) {
				$matched[ $rid ] = true;
			}
			// A blank nights cell on a later upload is no change: the household's nights stand.
			if ( '' !== $rid && ! empty( $a['blankNights'] ) && ! empty( $existing[ $rid ]['data']['stay']['nights'] ) ) {
				$d['stay']['nights'] = $existing[ $rid ]['data']['stay']['nights'];
			}
			$kept_site = array();
			if ( '' !== $rid ) {
				list( $merged, $kept_site ) = ogc_lod_form_merge( $existing[ $rid ]['data'], $d );
				$what = ogc_lod_diff( $existing[ $rid ]['data'], $merged );
			} else {
				$merged = $d;
				$what   = array();
			}
			$plan[] = array(
				'merged'  => $merged,
				'kept'    => $kept_site,
				'gid'     => $gid,
				'g'       => $g,
				'part'    => $pi,
				'a'       => $a,
				'd'       => $d,
				'rid'     => $rid,
				'state'   => '' === $rid ? 'new' : ( $what ? 'changed' : 'same' ),
				'what'    => $what,
				'n'       => count( $list ),
				'suggest' => $suggest,
				'choice'  => $choice,
				'rows'    => array_map( function ( $x ) {
					return array( 'line' => $x['line'], 'at' => $x['stamp'], 'when' => ogc_lod_stamp_words( $x['stamp'], $x['at'] ), 'names' => implode( ', ', array_map( function ( $p ) { return strtok( $p['name'], ' ' ); }, $x['people'] ) ), 'people' => count( $x['people'] ), 'rooms' => $x['rooms'], 'nights' => $x['nights'] ? substr( $x['nights'][0], 0, 3 ) . ( count( $x['nights'] ) > 1 ? '–' . substr( end( $x['nights'] ), 0, 3 ) : '' ) : '', 'type' => $x['type'] );
				}, $list ),
			);
		}
	}
	// A household already registered on the site, sending the Form too, is never made twice (invariant 95;
	// red team E2): listed under Check, and not imported.
	$on_site = array();
	foreach ( ogc_records( $y, 'registrations' ) as $rec ) {
		if ( 'form' !== $rec['source'] && 'cancelled' !== ( isset( $rec['data']['status'] ) ? $rec['data']['status'] : '' ) && '' !== (string) $rec['email'] ) {
			$on_site[ strtolower( (string) $rec['email'] ) ] = true;
		}
	}
	foreach ( $plan as &$pp ) {
		if ( 'new' === $pp['state'] && '' !== $pp['a']['email'] && isset( $on_site[ strtolower( $pp['a']['email'] ) ] ) ) {
			$pp['state'] = 'site';
			$ci          = isset( $cols['email'][0] ) ? $cols['email'][0] : -1;
			$probs[]     = array( 'line' => $pp['rows'][0]['line'], 'col' => $ci >= 0 ? $head[ $ci ] : 'Email', 'cell' => '', 'reason' => 'Already registered on the site · Not imported', 'field' => 'email', 'gid' => $pp['gid'] );
		}
	}
	unset( $pp );
	// A household the desk checked in (or with a Youngfolk's hall key out) isn't moved out of its rooms by
	// an upload, as it isn't from the register (red team round 2, F6, ATK2 I3): not updated, and Check
	// says why. The next upload says it again until the desk undoes the check-in.
	foreach ( $plan as &$pp ) {
		if ( 'changed' !== $pp['state'] ) {
			continue;
		}
		$w = ogc_lod_desk_keeps( $y, $existing[ $pp['rid'] ], $pp['merged'] );
		if ( '' !== $w ) {
			$pp['state'] = 'held';
			$probs[]     = array( 'line' => $pp['rows'][0]['line'], 'col' => 'Row', 'cell' => '', 'reason' => ogc_lod_desk_words( $w, 'Not updated' ), 'field' => '', 'gid' => $pp['gid'] );
		}
	}
	unset( $pp );
	$missing = array();
	foreach ( $existing as $rid => $rec ) {
		if ( ! isset( $matched[ $rid ] ) && 'cancelled' !== ( isset( $rec['data']['status'] ) ? $rec['data']['status'] : '' ) ) {
			// Checked in, or a hall key out: never removed (red team round 2, F5, ATK2 I2).
			$w         = ogc_lod_desk_keeps( $y, $rec, null );
			$missing[] = array( 'rid' => $rid, 'label' => ogc_lod_words( $rec['data'] ), 'held' => '' !== $w ? ogc_lod_desk_words( $w, 'Not removed' ) : '' );
		}
	}
	$count = function ( $s ) use ( $plan ) {
		return count( array_filter( $plan, function ( $p ) use ( $s ) { return $p['state'] === $s; } ) );
	};

	// What to check is said for new and changed responses only: an unchanged file lists nothing again.
	$live = array( 'file' => true );
	foreach ( $plan as $p ) {
		if ( 'same' !== $p['state'] ) {
			$live[ $p['gid'] ] = true;
		}
	}
	$probs = array_values( array_filter( $probs, function ( $x ) use ( $live ) { return isset( $live[ $x['gid'] ] ); } ) );
	// Each household keeps its own (the board's Review shows them: "From the Form · Nights blank").
	$prob_of = array();
	foreach ( $probs as $x ) {
		$prob_of[ $x['gid'] ][] = mb_substr( $x['col'] . ' · ' . $x['reason'], 0, 120 );
	}

	if ( 'check' === $step ) {
		$groups_out = array();
		foreach ( $plan as $p ) {
			if ( $p['n'] > 1 && 0 === $p['part'] ) {
				$groups_out[] = array( 'gid' => $p['gid'], 'label' => ogc_lod_words( $p['d'] ), 'n' => $p['n'], 'suggest' => $p['suggest'], 'choice' => $p['choice'], 'rows' => $p['rows'] );
			}
		}
		$out = array(
			'step'     => 'check',
			'summary'  => array( 'rows' => count( $rows ), 'households' => count( $plan ), 'merged' => array_sum( array_map( function ( $p ) { return 'both' === $p['choice'] || 0 !== $p['part'] ? 0 : $p['n'] - 1; }, $plan ) ), 'check' => count( $probs ), 'new' => $count( 'new' ), 'changed' => $count( 'changed' ), 'same' => $count( 'same' ), 'held' => $count( 'held' ), 'missing' => count( $missing ) ),
			'groups'   => $groups_out,
			'problems' => array_slice( array_map( function ( $x ) use ( $plan ) {
				foreach ( $plan as $p ) {
					if ( $p['gid'] === $x['gid'] ) {
						$x['label'] = ogc_lod_words( $p['d'] );
						break;
					}
				}
				return $x;
			}, $probs ), 0, 300 ),
			'changes'  => array_values( array_map( function ( $p ) { return array( 'rid' => $p['rid'], 'label' => ogc_lod_words( $p['d'] ), 'what' => $p['what'] ); }, array_filter( $plan, function ( $p ) { return 'changed' === $p['state']; } ) ) ),
			'new'      => array_values( array_map( function ( $p ) { return array( 'label' => ogc_lod_words( $p['d'] ), 'line' => $p['rows'][0]['line'] ); }, array_slice( array_filter( $plan, function ( $p ) { return 'new' === $p['state']; } ), 0, 400 ) ) ),
			'missing'  => $missing,
		);
		return rest_ensure_response( $out );
	}

	if ( 'apply' !== $step ) {
		return ogc_lod_err( 'ogc_bad', 'Not imported', 400 );
	}
	// Remember the columns for the next upload (and next year's).
	$keep = array();
	foreach ( $head as $i => $h ) {
		if ( '' !== trim( $h ) ) {
			$keep[ $h ] = $map[ $i ][0];
		}
	}
	ogc_lod_put( $y, 'meta:mapping', array( 'cols' => $keep, 'v' => 2, 'by' => ogc_lod_me(), 'at' => ogc_now() ) );

	$me      = ogc_lod_me();
	$now     = ogc_now();
	$created = array();
	$updated = array();
	$removed = array();
	$freed   = array();
	foreach ( $plan as $p ) {
		if ( in_array( $p['state'], array( 'same', 'site', 'held' ), true ) ) {
			continue;
		}
		$d     = 'changed' === $p['state'] ? $p['merged'] : $p['d'];
		$probs = isset( $prob_of[ $p['gid'] ] ) ? array_values( array_unique( $prob_of[ $p['gid'] ] ) ) : array();
		foreach ( $p['kept'] as $f ) {
			$probs[] = 'Kept the site’s change · ' . ucfirst( str_replace( array( 'stay.', 'household.' ), '', $f ) );
		}
		$probs = array_merge( $probs, ogc_lod_form_rules( $d, $y ) );
		$form  = array_merge( isset( $p['d']['form'] ) ? (array) $p['d']['form'] : array(), array( 'keys' => $p['a']['keys'], 'group' => $p['g'], 'choice' => $p['choice'], 'at' => $now, 'base' => ogc_lod_form_base( $p['d'] ), 'problems' => array_slice( $probs, 0, 8 ) ) );
		if ( 'changed' === $p['state'] ) {
			$rec  = $existing[ $p['rid'] ];
			$kept = array_intersect_key( $rec['data'], array_flip( array( 'rid', 'id', 'created', 'at', 'status', 'source', 'price', 'money', 'paid', 'checkDue', 'history', 'pay', 'sample', 'flags', 'approval' ) ) );
			$new  = array_merge( $d, $kept, array( 'form' => $form, 'updated' => $now ) );
			// The version moves on (a form opened before this is refused, never overwritten: invariant 74).
			$new['_v']      = (int) ( isset( $rec['data']['_v'] ) ? $rec['data']['_v'] : 0 ) + 1;
			$new['history'] = array_slice( array_merge( (array) ( isset( $kept['history'] ) ? $kept['history'] : array() ), array( array( 'at' => $now, 'by' => 'committee', 'what' => 'Form · ' . implode( ' · ', $p['what'] ) ) ) ), -30 );
			$updated[ $rec['id'] ] = $rec['data'];
			ogc_record_update( $rec['id'], $new, $new['household']['email'] );
			// Rooms it may no longer hold are freed and named on Lodging's rows (a Youngfolk gone, Dorm → Camper).
			$freed = array_merge( $freed, ogc_lod_reg_saved( $y, $rec['data'], $new ) );
			continue;
		}
		$rid  = function_exists( 'ogc_reg_next_rid' ) ? ogc_reg_next_rid( $y ) : 'F-' . $y . '-' . wp_rand( 1000, 9999 );
		$data = array_merge( $d, array(
			'rid'      => $rid,
			'id'       => $rid,
			'source'   => 'form',
			'status'   => 'registered',
			'pay'      => 'form',
			'at'       => '' !== $p['a']['at'] ? $p['a']['at'] : substr( $now, 0, 10 ),
			'created'  => $now,
			'managers' => array(),
			// Paid through the Form's own payment: nothing owed here, nothing guessed.
			'price'    => array( 'lines' => array(), 'lodging_cents' => 0, 'gift_cents' => 0, 'total_cents' => 0, 'form' => true ),
			'money'    => array( 'total' => 0, 'paid' => 0, 'check' => 0, 'pending' => 0, 'refund' => 0, 'refunded' => 0, 'due' => 0 ),
			'history'  => array( array( 'at' => $now, 'by' => 'committee', 'what' => 'Imported from the Form' ) ),
			'form'     => $form,
			'_v'       => 1,
		) );
		$id = ogc_record_insert( $y, 'registrations', $data, $data['household']['email'], false, 'form' );
		if ( $id ) {
			$created[] = $id;
		}
	}
	// "Not in this file", ticked: removed, and any room it held freed and named (invariant 97, 18).
	$want = array_map( 'strval', (array) $req->get_param( 'remove' ) );
	$gave = array();
	foreach ( $missing as $m ) {
		if ( in_array( $m['rid'], $want, true ) && '' === $m['held'] ) {
			$old = $existing[ $m['rid'] ]['data'];
			ogc_record_delete( $existing[ $m['rid'] ]['id'] );
			$removed[]          = $existing[ $m['rid'] ]['id'];
			$gave[ $m['rid'] ]  = ogc_lod_release( $y, $m['rid'], $old, array(), 'Not in this file' );
			$freed              = array_merge( $freed, $gave[ $m['rid'] ] );
		}
	}
	$summary = array( 'rows' => count( $rows ), 'created' => count( $created ), 'updated' => count( $updated ), 'removed' => count( $removed ), 'freed' => array_values( array_unique( array_map( 'ogc_lod_room_words', $freed ) ) ), 'name' => mb_substr( sanitize_file_name( (string) $req->get_param( 'name' ) ), 0, 80 ) );
	// Only the last import can be undone: older ones' before-values go.
	global $wpdb;
	$wpdb->query( $wpdb->prepare( 'DELETE FROM ' . ogc_table( 'lodging' ) . ' WHERE year = %d AND rkey LIKE %s', $y, 'imp:%' ) );
	$iid = gmdate( 'ymdHis' ) . wp_rand( 100, 999 );
	ogc_lod_put( $y, 'imp:' . $iid, array( 'summary' => $summary, 'created' => $created, 'updated' => (object) $updated, 'removed' => $removed ) );
	} finally {
		if ( $locked ) {
			ogc_lod_unlock( $y );
			ogc_reg_unlock( $y );
		}
	}
	ogc_log( 'lodging_import', $y, 'form', array_diff_key( $summary, array( 'freed' => 1 ) ) );
	return rest_ensure_response( array( 'step' => 'done', 'id' => $iid, 'summary' => $summary, 'by' => $me ) );
}

function ogc_lod_rest_import_undo( WP_REST_Request $req ) {
	global $wpdb;
	$y  = (int) $req['year'];
	$id = (string) $req->get_param( 'id' );
	if ( ! preg_match( '/^\d{12,20}$/', $id ) ) {
		return ogc_lod_err( 'ogc_bad', 'Nothing to undo', 400 );
	}
	if ( ogc_lod_held( $y, $req ) ) {
		return ogc_lod_err( 'ogc_held', 'Conference over · Can’t undo', 403 );
	}
	// Under the registration's lock and Lodging's: a household put back never takes a room given since.
	if ( ! ogc_reg_lock( $y ) ) {
		return ogc_lod_busy();
	}
	if ( ! ogc_lod_lock( $y ) ) {
		ogc_reg_unlock( $y );
		return ogc_lod_busy();
	}
	try {
		$row = ogc_lod_row( $y, 'imp:' . $id );
		if ( ! $row || ! empty( $row['data']['undone'] ) ) {
			return ogc_lod_err( 'ogc_gone', 'Nothing to undo', 404 );
		}
		$d = $row['data'];
		// Only while nothing has been done with those households since (polish 1: undoing 89 households
		// after Lodging gave them rooms left the board and the published rooms pointing at removed people).
		$rids   = array();
		$since  = 0;
		$imp_at = (string) $row['at'];
		// (The loop has its own name: it once reused $id, and the import's own row was never marked undone.)
		foreach ( array_merge( (array) $d['created'], array_keys( (array) $d['updated'] ) ) as $rec_id ) {
			$rec = ogc_record_get( (int) $rec_id );
			if ( ! $rec ) {
				continue;
			}
			$rid = isset( $rec['data']['rid'] ) ? (string) $rec['data']['rid'] : '';
			if ( '' !== $rid ) {
				$rids[ $rid ] = true;
			}
			if ( ! empty( $rec['updated_at'] ) && $rec['updated_at'] > $imp_at ) {
				$since++;
			}
		}
		$roomed = 0;
		$worked = 0;
		foreach ( ogc_lod_rows( $y, 'hh:' ) as $k => $r ) {
			// (An emptied row is nothing done: a row a member changes stays, emptied, so its version keeps going.)
			if ( isset( $rids[ substr( $k, 3 ) ] ) && $r['data'] ) {
				$worked++;
				$roomed += empty( $r['data']['rooms'] ) ? 0 : 1;
			}
		}
		// Their Youngfolks' hall rows too: a hall room given since is a room given (red team round 2, F7,
		// ATK2 I1: undoing left the row naming a room for a person who no longer exists).
		foreach ( array_merge( (array) $d['created'], array_keys( (array) $d['updated'] ) ) as $rec_id ) {
			$rec = ogc_record_get( (int) $rec_id );
			foreach ( (array) ( $rec && isset( $rec['data']['people'] ) ? $rec['data']['people'] : array() ) as $p ) {
				$yr = ! empty( $p['pid'] ) ? ogc_lod_row( $y, 'yf:' . $p['pid'] ) : null;
				if ( $yr && $yr['data'] ) {
					$worked++;
					$roomed += empty( $yr['data']['room'] ) ? 0 : 1;
				}
			}
		}
		$pub   = ogc_lod_row( $y, 'meta:published' );
		$snap  = $pub && ! empty( $pub['data']['date'] ) ? (array) $pub['data']['snap'] : array();
		$shown = count( array_intersect_key( $snap, $rids ) );
		if ( $roomed || $worked || $since || $shown ) {
			$why = $roomed ? 'Rooms given since · ' . $roomed . ( 1 === $roomed ? ' household' : ' households' ) . ( $shown ? ' · ' . $shown . ' published' : '' ) : ( $worked ? 'Worked on since · ' . $worked . ( 1 === $worked ? ' household' : ' households' ) : 'Changed since' );
			return ogc_lod_err( 'ogc_conflict', $why . ' · Can’t undo', 409 );
		}
		// A household it removed comes back with the rooms it had, only while nobody else was given them
		// (invariant 97); else the import stays.
		$ctx  = ogc_lod_ctx( $y );
		$back = array();
		foreach ( (array) $d['removed'] as $rec_id ) {
			$rec = ogc_record_get( (int) $rec_id, true );
			$rid = $rec && isset( $rec['data']['rid'] ) ? (string) $rec['data']['rid'] : '';
			if ( '' === $rid ) {
				continue;
			}
			$lr = ogc_lod_row( $y, 'hh:' . $rid );
			$ld = $lr ? (array) $lr['data'] : array();
			if ( isset( $ld['freed']['why'] ) && 'Not in this file' === $ld['freed']['why'] ) {
				$cl = ogc_lod_claims( $ctx, ogc_lod_claim_rows( $y, 'hh:' . $rid ) );
				foreach ( ogc_lod_real( $ld['freed']['rooms'], $ctx['rooms'] ) as $room ) {
					if ( ! empty( $cl[ $room ] ) ) {
						return ogc_lod_err( 'ogc_conflict', ogc_lod_room_words( $room ) . ' given since · Can’t undo', 409 );
					}
				}
				$nd          = $ld;
				$nd['rooms'] = array_values( (array) ( isset( $ld['freed']['list'] ) ? $ld['freed']['list'] : $ld['freed']['rooms'] ) );
				unset( $nd['freed'] );
				$back[ 'hh:' . $rid ] = array( $nd, $lr['v'] );
			}
			foreach ( (array) ( isset( $rec['data']['people'] ) ? $rec['data']['people'] : array() ) as $p ) {
				$yr = ! empty( $p['yf'] ) && ! empty( $p['pid'] ) ? ogc_lod_row( $y, 'yf:' . $p['pid'] ) : null;
				if ( ! $yr || 'Not in this file' !== ( isset( $yr['data']['freed']['why'] ) ? $yr['data']['freed']['why'] : '' ) ) {
					continue;
				}
				$room = (string) $yr['data']['freed']['room'];
				$cl   = ogc_lod_claims( $ctx, ogc_lod_claim_rows( $y, 'yf:' . $p['pid'] ) );
				if ( isset( $ctx['rooms'][ $room ] ) && ( ! empty( $cl[ $room ] ) && '' !== ogc_lod_room_wrong( $ctx, $room, array_merge( $cl[ $room ], array( 'yf:' . $p['pid'] ) ) ) ) ) {
					return ogc_lod_err( 'ogc_conflict', ogc_lod_room_words( $room ) . ' given since · Can’t undo', 409 );
				}
				$nd         = (array) $yr['data'];
				$nd['room'] = $room;
				unset( $nd['freed'] );
				$back[ 'yf:' . $p['pid'] ] = array( $nd, $yr['v'] );
			}
		}
		// Everything putting them back would leave wrong, judged as Place judges it, with the registrations
		// as they will be (red team ATK1-import-undo-yf-cap: each Youngfolk was checked alone).
		$recs = array();
		foreach ( (array) $d['removed'] as $rec_id ) {
			$rec = ogc_record_get( (int) $rec_id, true );
			if ( $rec && ! empty( $rec['data']['rid'] ) ) {
				$recs[ (string) $rec['data']['rid'] ] = $rec['data'];
			}
		}
		foreach ( (array) $d['updated'] as $rec_id => $old ) {
			if ( ! empty( $old['rid'] ) ) {
				$recs[ (string) $old['rid'] ] = $old;
			}
		}
		foreach ( (array) $d['created'] as $rec_id ) {
			$rec = ogc_record_get( (int) $rec_id );
			if ( $rec && ! empty( $rec['data']['rid'] ) ) {
				$recs[ (string) $rec['data']['rid'] ] = null;
			}
		}
		$after = array();
		foreach ( $back as $k => $x ) {
			$after[ $k ] = $x[0];
		}
		$bad = ogc_lod_check_plan( $ctx, ogc_lod_claim_data( $y ), $after, ogc_lod_ctx_with( $ctx, $recs ) );
		if ( is_wp_error( $bad ) ) {
			return ogc_lod_err( 'ogc_conflict', $bad->get_error_message() . ' · Can’t undo', 409 );
		}
		foreach ( (array) $d['created'] as $rid ) {
			ogc_record_delete( (int) $rid );
		}
		foreach ( (array) $d['updated'] as $rid => $old ) {
			$rec = ogc_record_get( (int) $rid );
			if ( $rec ) {
				ogc_record_update( (int) $rid, $old, isset( $old['household']['email'] ) ? $old['household']['email'] : '' );
				ogc_lod_reg_saved( $y, $rec['data'], $old );
			}
		}
		foreach ( (array) $d['removed'] as $rid ) {
			$wpdb->update( ogc_table( 'records' ), array( 'deleted_at' => null ), array( 'id' => (int) $rid ), array( '%s' ), array( '%d' ) );
		}
		foreach ( $back as $k => $x ) {
			ogc_lod_put( $y, $k, $x[0], $x[1] );
		}
		$d['undone'] = array( 'by' => ogc_lod_me(), 'at' => ogc_now() );
		ogc_lod_put( $y, 'imp:' . $id, $d );
	} finally {
		ogc_lod_unlock( $y );
		ogc_reg_unlock( $y );
	}
	ogc_log( 'lodging_import_undo', $y, 'form', array( 'created' => count( (array) $d['created'] ) ) );
	return rest_ensure_response( array( 'ok' => true, 'summary' => $d['summary'] ) );
}
