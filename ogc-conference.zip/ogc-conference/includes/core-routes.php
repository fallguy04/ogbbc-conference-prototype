<?php
/**
 * The pages' addresses, under /annual-conference/ (ogc_base_path), the same folders as v3:
 *   /annual-conference/                 the Conference page (v3's schedule-hub)
 *   /annual-conference/<page>/          guide, schedule, packet, register, volunteer, tournaments,
 *                                       lists, lodging, year, admin, signin
 *   /annual-conference/guide/manifest.webmanifest, /guide/sw.js, /guide/app/<icon>
 *   /annual-conference/schedule/data/years.csv and /schedule/data/<year>/<name>.csv
 *                                       the year's files as CSV (the same rules as the REST route)
 * v3's own addresses still land: /annual-conference/schedule-hub/ and any …/index.html redirect.
 */

defined( 'ABSPATH' ) || exit;

add_action( 'init', 'ogc_register_rewrites' );
add_filter( 'query_vars', function ( $v ) {
	return array_merge( $v, array( 'ogc_page', 'ogc_file', 'ogc_data' ) );
} );
add_action( 'template_redirect', 'ogc_dispatch', 1 );

/** Changes when the addresses do, so the rules are flushed once (not on every request). */
function ogc_rewrite_stamp() {
	// The rules themselves (every one that leads to ogc_…, an area's own through ogc_rewrites included),
	// so a changed pattern is flushed too, not only a new page (review, Oct 11).
	global $wp_rewrite;
	$ours = array();
	foreach ( (array) ( $wp_rewrite ? $wp_rewrite->extra_rules_top : array() ) as $re => $to ) {
		if ( false !== strpos( (string) $to, 'ogc_' ) ) {
			$ours[] = $re . '=' . $to;
		}
	}
	return OGC_VERSION . '|' . ogc_base_path() . '|' . md5( implode( ',', array_keys( ogc_pages() ) ) . '|' . implode( "\n", $ours ) ) . '|' . ( OGC_DEV ? 'dev' : '' );
}

function ogc_register_rewrites() {
	$b = preg_quote( ogc_base_path(), '' );
	add_rewrite_rule( "^$b/?$", 'index.php?ogc_page=conference', 'top' );
	add_rewrite_rule( "^$b/guide/(manifest\\.webmanifest|sw\\.js)$", 'index.php?ogc_page=guide&ogc_file=$matches[1]', 'top' );
	add_rewrite_rule( "^$b/guide/app/([A-Za-z0-9._-]+)$", 'index.php?ogc_page=guide&ogc_file=app/$matches[1]', 'top' );
	add_rewrite_rule( "^$b/schedule/data/(years\\.csv|[0-9]{4}/[a-z][a-z0-9_-]*\\.csv)$", 'index.php?ogc_data=$matches[1]', 'top' );
	add_rewrite_rule( "^$b/schedule-hub/?(index\\.html)?$", 'index.php?ogc_page=conference&ogc_file=v3', 'top' );
	foreach ( ogc_pages() as $key => $p ) {
		if ( '' === $p['path'] ) {
			continue;
		}
		$path = preg_quote( $p['path'], '' );
		add_rewrite_rule( "^$b/$path/?$", 'index.php?ogc_page=' . $key, 'top' );
		add_rewrite_rule( "^$b/$path/index\\.html$", 'index.php?ogc_page=' . $key . '&ogc_file=v3', 'top' );
	}
	// The dev routes (core-dev.php) and any area's own.
	do_action( 'ogc_rewrites', $b );
	if ( get_option( 'ogc_rewrite_stamp' ) !== ogc_rewrite_stamp() && did_action( 'init' ) ) {
		flush_rewrite_rules( false );
		update_option( 'ogc_rewrite_stamp', ogc_rewrite_stamp(), true );
	}
}

function ogc_dispatch() {
	$data = get_query_var( 'ogc_data' );
	if ( $data ) {
		ogc_serve_data( $data );
	}
	$page = get_query_var( 'ogc_page' );
	if ( ! $page ) {
		return;
	}
	$file = get_query_var( 'ogc_file' );
	// v3's addresses (…/schedule-hub/, …/register/index.html): the page's own, with the same query.
	if ( 'v3' === $file ) {
		$q = isset( $_SERVER['QUERY_STRING'] ) ? sanitize_text_field( wp_unslash( $_SERVER['QUERY_STRING'] ) ) : '';
		$pages = ogc_pages();
		wp_safe_redirect( ogc_url( $pages[ $page ]['path'] ) . ( $q ? '?' . $q : '' ), 301 );
		exit;
	}
	if ( 'guide' === $page && $file ) {
		ogc_serve_guide_file( $file );
	}
	do_action( 'ogc_before_page', $page );
	ogc_render_page( $page );
}

/** /schedule/data/years.csv and /schedule/data/<year>/<name>.csv: the same CSV as the REST route,
 * for anything that reads the files by address. */
function ogc_serve_data( $path ) {
	nocache_headers();
	header( 'X-Content-Type-Options: nosniff' );
	if ( 'years.csv' === $path ) {
		header( 'Content-Type: text/csv; charset=utf-8' );
		echo ogc_csv_write( ogc_years_public(), ogc_year_columns() ); // phpcs:ignore -- CSV text.
		exit;
	}
	if ( ! preg_match( '#^(\d{4})/([a-z][a-z0-9_-]*)\.csv$#', $path, $m ) || ! ogc_valid_name( $m[2] ) ) {
		status_header( 404 );
		exit;
	}
	$res = ogc_file_response( (int) $m[1], $m[2], 'csv' );
	if ( is_wp_error( $res ) ) {
		status_header( 404 );
		exit;
	}
	status_header( 200 );
	header( 'Content-Type: text/csv; charset=utf-8' );
	echo $res->get_data(); // phpcs:ignore -- CSV text.
	exit;
}

/** The guide's manifest, service worker and icons, at the guide's own address (so the service
 * worker's scope is /annual-conference/guide/). */
function ogc_serve_guide_file( $file ) {
	if ( 'manifest.webmanifest' === $file || 'sw.js' === $file ) {
		$t = ogc_template_path( 'manifest.webmanifest' === $file ? 'guide-manifest.php' : 'guide-sw.php' );
		if ( $t ) {
			include $t;
			exit;
		}
	}
	if ( preg_match( '#^app/([a-z0-9-]+\.(png|svg))$#', $file, $m ) ) {
		$path = OGC_DIR . 'assets/guide/app/' . $m[1];
		if ( file_exists( $path ) ) {
			status_header( 200 );
			header( 'Content-Type: ' . ( 'svg' === $m[2] ? 'image/svg+xml' : 'image/png' ) );
			header( 'Cache-Control: public, max-age=86400' );
			header( 'X-Content-Type-Options: nosniff' );
			readfile( $path ); // phpcs:ignore -- a fixed file in the plugin.
			exit;
		}
	}
	status_header( 404 );
	exit;
}
