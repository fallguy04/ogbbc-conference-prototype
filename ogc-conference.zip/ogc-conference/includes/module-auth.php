<?php
/**
 * Sign-in without passwords. A person is their email; the site emails a 6-digit code and a link.
 *
 *   /annual-conference/signin/            type your email → Send code → Check your email (type the code,
 *                                         or open the link). One page for everyone: who you are decides
 *                                         where you land, not which door you used. With ?return= the
 *                                         heading names where it goes back to ("Your sign-ups", "Lodging").
 *   /annual-conference/signin/?t=…        a link from an email. The token moves at once into a short-lived
 *                                         cookie and the browser goes to ?confirm=1, so it never sits in the
 *                                         address bar, the history or an analytics script's page address.
 *                                         That page is a card that says whose sign-in it is, with one
 *                                         button. The token is spent on that POST, never on a GET (mail
 *                                         scanners open every link first). A link already used on this
 *                                         device simply continues.
 *   /annual-conference/signin/?h=…        from an older confirmation email: "Send code to r***k@example.com"
 *
 * The rules:
 *   - Tokens are 32 random bytes; codes 6 digits. Both are kept only as HMAC-SHA256 (wp_salt), are
 *     single use and end after 30 minutes (invites and confirmations: 7 days). A code takes 5 tries,
 *     each counted in one statement before anything is compared (parallel guesses can't share a try).
 *   - A code works only in the browser that asked for it (a cookie holds the request), so a code can't
 *     be used to sign someone else's browser in. Resend keeps that browser's three newest codes working
 *     (mail arrives out of order). A link shows the address it signs in before it does.
 *   - The same answer whether the address is known or not, sent after the response so both take the
 *     same time. An address the site knows gets the code and link; one it doesn't gets one fixed short
 *     email (No sign-ups under this email · Register · Volunteer), at most once a day, and no code is
 *     made for it at all. Nothing typed goes into either, so the site isn't a mail relay.
 *   - Limits (module-auth's ogc_hits table, counted atomically): per address and device, once a minute,
 *     3 per 15 minutes, 10 a day. Per address across all devices, 15 a day, except on a device that has
 *     signed in as that address before (it can always get one more), so a script can't lock the real
 *     person out. An IP 300 an hour (a ceiling only: the campus Wi-Fi puts hundreds of families behind
 *     a few addresses; filter ogc_signin_ip_per_hour). Wrong codes from devices that haven't signed in
 *     as the address: 10 a day, the same for every address, then codes are off for 24 hours on those
 *     devices (the link still works, and the person's own devices keep codes) and the address is told once.
 *   - The link signs in whichever device opens it; opened on another device than the one that asked,
 *     the code keeps working on the asking one ("Signed in on another device · Code still works here").
 *   - auth/send, auth/code and the page's own forms are same-site only: Sec-Fetch-Site same-origin,
 *     else a matching Origin (or Referer). A request with neither is refused. That guards against other
 *     sites (CSRF); scripts are held back by the limits, not by this.
 *   - Return addresses are paths under /annual-conference/ only (never another site).
 *   - Links and codes sign in only people whose only role is the plugin's own (ogc_person, or a plain
 *     subscriber). Anyone with more (an editor, an administrator) is refused with the same answer: they
 *     use wp-login, with the site's own two-step sign-in.
 *   - The plugin's people (role ogc_person) can't reach wp-admin, have no admin bar, no password
 *     reset, no application passwords and get none of WordPress's own account emails.
 *   - Signed in a year on that device; "Shared device" (a setting of the browser: a switch on Check
 *     your email and in the account menu) makes every sign-in there end with the browser, or after 4
 *     hours, and switching it off again restores the year. Members' pages
 *     ask again (a code) after 30 days: over an open page, a small dialog; opening a members' page,
 *     the page's own frame with the same dialog. Conference webmasters' sessions last 7 days.
 *
 * Also here: a device's own records (someone who typed an email but hasn't confirmed it sees and can
 * leave only what they did on that device), and records reached through a second email (a helper who
 * registered a household; a parent).
 */

defined( 'ABSPATH' ) || exit;

const OGC_SIGNIN_TTL = 1800;          // a sign-in link and code: 30 minutes
const OGC_LINK_TTL   = 604800;        // an invite, a confirmation, a parent's approval: 7 days

add_filter( 'ogc_schema', 'ogc_auth_schema', 20, 2 );

function ogc_auth_schema( $sql, $charset ) {
	// One-time links and codes. thash: the link's HMAC; chash: the code's; rhash: the asking
	// browser's (a code works only there). Used rows stay a day, so a second tap on the same device
	// just continues; the rest are purged daily.
	$sql[] = 'CREATE TABLE ' . ogc_table( 'tokens' ) . " (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  thash char(64) NOT NULL,
  kind varchar(16) NOT NULL,
  email varchar(190) NOT NULL DEFAULT '',
  chash char(64) NULL,
  rhash char(64) NULL,
  tries tinyint(3) unsigned NOT NULL DEFAULT 0,
  return_to varchar(300) NOT NULL DEFAULT '',
  data longtext NULL,
  created_at datetime NOT NULL,
  expires_at datetime NOT NULL,
  used_at datetime NULL,
  used_by bigint(20) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY  (id),
  UNIQUE KEY thash (thash),
  KEY email (email),
  KEY rhash (rhash),
  KEY expires_at (expires_at)
) $charset;";
	// What a device did before its email was confirmed: it may see and leave only these.
	$sql[] = 'CREATE TABLE ' . ogc_table( 'devices' ) . " (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  dhash char(64) NOT NULL,
  record_id bigint(20) unsigned NOT NULL,
  created_at datetime NOT NULL,
  PRIMARY KEY  (id),
  KEY dhash (dhash),
  KEY record_id (record_id)
) $charset;";
	// A record reached through a second email: helper (registered it for them; may change it) or
	// parent (may see it).
	$sql[] = 'CREATE TABLE ' . ogc_table( 'record_links' ) . " (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  record_id bigint(20) unsigned NOT NULL,
  email varchar(190) NOT NULL,
  why varchar(16) NOT NULL DEFAULT 'helper',
  created_at datetime NOT NULL,
  PRIMARY KEY  (id),
  KEY record_id (record_id),
  KEY email (email)
) $charset;";
	// The limits' counts (ogc_throttle): one row a counted try, so a check and its count are one insert
	// and one read, never a read-modify-write that parallel requests can race. Purged daily.
	$sql[] = 'CREATE TABLE ' . ogc_table( 'hits' ) . " (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  bkey char(32) NOT NULL,
  at int(10) unsigned NOT NULL,
  PRIMARY KEY  (id),
  KEY bkey_at (bkey,at)
) $charset;";
	return $sql;
}

/* ================================================================== small parts */

function ogc_auth_hash( $s ) {
	return hash_hmac( 'sha256', (string) $s, wp_salt( 'auth' ) . '|ogc' );
}

function ogc_random_token() {
	return rtrim( strtr( base64_encode( random_bytes( 32 ) ), '+/', '-_' ), '=' );
}

function ogc_random_code() {
	return str_pad( (string) random_int( 0, 999999 ), 6, '0', STR_PAD_LEFT );
}

/** An address as typed: trimmed, lowercased, a trailing dot from phone autofill dropped. */
function ogc_clean_email( $e ) {
	return rtrim( strtolower( trim( (string) $e ) ), '.' );
}

/** The address as it was probably meant ("ruth@gmail.com" for "ruth@gmial.com"), or '' when it looks
 * right. The same built-in list and rule as OGC_AUTH.suggest (ogc-account.js); no outside service. */
function ogc_email_suggest( $email ) {
	static $domains = array( 'gmail.com', 'yahoo.com', 'outlook.com', 'hotmail.com', 'aol.com', 'icloud.com', 'comcast.net', 'live.com', 'msn.com', 'me.com', 'att.net', 'verizon.net', 'sbcglobal.net', 'bellsouth.net', 'charter.net', 'cox.net', 'frontier.com', 'windstream.net', 'protonmail.com', 'ymail.com' );
	$email = (string) $email;
	$at    = strrpos( $email, '@' );
	if ( ! $at ) {
		return '';
	}
	$dom = strtolower( substr( $email, $at + 1 ) );
	if ( '' === $dom || in_array( $dom, $domains, true ) ) {
		return '';
	}
	// Edit distance with swapped neighbours counted once (as the browser's), under 3.
	$dist = function ( $a, $b ) {
		$m = strlen( $a );
		$n = strlen( $b );
		$d = array();
		for ( $i = 0; $i <= $m; $i++ ) {
			$d[ $i ] = array_fill( 0, $n + 1, 0 );
			$d[ $i ][0] = $i;
		}
		for ( $j = 0; $j <= $n; $j++ ) {
			$d[0][ $j ] = $j;
		}
		for ( $i = 1; $i <= $m; $i++ ) {
			for ( $j = 1; $j <= $n; $j++ ) {
				$d[ $i ][ $j ] = min( $d[ $i - 1 ][ $j ] + 1, $d[ $i ][ $j - 1 ] + 1, $d[ $i - 1 ][ $j - 1 ] + ( $a[ $i - 1 ] === $b[ $j - 1 ] ? 0 : 1 ) );
				if ( $i > 1 && $j > 1 && $a[ $i - 1 ] === $b[ $j - 2 ] && $a[ $i - 2 ] === $b[ $j - 1 ] ) {
					$d[ $i ][ $j ] = min( $d[ $i ][ $j ], $d[ $i - 2 ][ $j - 2 ] + 1 );
				}
			}
		}
		return $d[ $m ][ $n ];
	};
	$best = '';
	$bd   = 3;
	foreach ( $domains as $d ) {
		$x = $dist( $dom, $d );
		if ( $x < $bd && $x > 0 ) {
			$bd   = $x;
			$best = $d;
		}
	}
	if ( ! $best ) {
		$stem = preg_replace( '/\.(con|cmo|cm|co|om|comm)$/', '.com', $dom );
		if ( $stem !== $dom && in_array( $stem, $domains, true ) ) {
			$best = $stem;
		}
	}
	if ( ! $best && in_array( $dom . '.com', $domains, true ) ) {
		$best = $dom . '.com';
	}
	return $best ? substr( $email, 0, $at + 1 ) . $best : '';
}

/** The visitor's address. Behind Nexcess's proxy, Corey says which header to trust (ogc_client_ip). */
function ogc_client_ip() {
	$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
	return (string) apply_filters( 'ogc_client_ip', $ip );
}

function ogc_cookie( $name, $value, $ttl, $http_only = true ) {
	if ( headers_sent() ) {
		return;
	}
	setcookie( $name, $value, array(
		'expires'  => $ttl ? time() + $ttl : 0,
		'path'     => COOKIEPATH ? COOKIEPATH : '/',
		'domain'   => COOKIE_DOMAIN ? COOKIE_DOMAIN : '',
		'secure'   => is_ssl(),
		'httponly' => $http_only,
		'samesite' => 'Lax',
	) );
	if ( $ttl < 0 ) {
		unset( $_COOKIE[ $name ] );
	} else {
		$_COOKIE[ $name ] = $value;
	}
}

function ogc_cookie_get( $name ) {
	return isset( $_COOKIE[ $name ] ) ? preg_replace( '/[^A-Za-z0-9_-]/', '', (string) wp_unslash( $_COOKIE[ $name ] ) ) : '';
}

/**
 * A rolling limit: at most $max in $window seconds for this bucket. Returns 0 when allowed (and counts
 * it, unless $count is false), or the time it's allowed again.
 * Counting inserts first and then counts, so parallel requests can't all slip under the limit: one
 * that finds itself over takes its own row back out and is refused. (Transients, as before, were a
 * read-modify-write that raced, and an object cache could evict them.)
 */
function ogc_throttle( $bucket, $max, $window, $count = true ) {
	global $wpdb;
	$t   = ogc_table( 'hits' );
	$key = substr( ogc_auth_hash( $bucket ), 0, 32 );
	$now = time();
	$id  = 0;
	if ( $count ) {
		$wpdb->insert( $t, array( 'bkey' => $key, 'at' => $now ), array( '%s', '%d' ) );
		$id = (int) $wpdb->insert_id;
	}
	$r     = $wpdb->get_row( $wpdb->prepare( "SELECT COUNT(*) AS n, MIN(at) AS first FROM $t WHERE bkey = %s AND at > %d", $key, $now - (int) $window ), ARRAY_A );
	$n     = $r ? (int) $r['n'] : 0;
	$again = ( $r && $r['first'] ? (int) $r['first'] : $now ) + (int) $window;
	if ( $count ) {
		if ( $n > $max ) {
			$wpdb->delete( $t, array( 'id' => $id ), array( '%d' ) );
			return $again;
		}
		return 0;
	}
	return $n >= $max ? $again : 0;
}

/** Run something after the answer has gone to the browser (so a known and an unknown email take the
 * same time). */
function ogc_after_response( $fn ) {
	add_action( 'shutdown', function () use ( $fn ) {
		// PHP-FPM, or LiteSpeed's LSAPI (Nexcess may serve PHP either way): without one of these the mail
		// would go before the answer, and a known address would answer slower than an unknown one.
		if ( function_exists( 'fastcgi_finish_request' ) ) {
			fastcgi_finish_request();
		} elseif ( function_exists( 'litespeed_finish_request' ) ) {
			litespeed_finish_request();
		}
		call_user_func( $fn );
	}, 1 );
}

/** An address, escaped, that breaks after its @ (never mid-word on a phone). */
function ogc_email_wbr( $e ) {
	return str_replace( '@', '@<wbr>', esc_html( (string) $e ) );
}

/** "9:40 PM" in the site's time zone. */
function ogc_clock( $ts ) {
	return wp_date( 'g:i A', (int) $ts );
}

/** "14 min", "2 hours": a wait in words, the same in every time zone (a family in California reads
 * the site's Eastern clock 3 hours off). */
function ogc_wait_words( $until ) {
	$s = max( 1, (int) $until - time() );
	if ( $s < 90 * MINUTE_IN_SECONDS ) {
		$m = (int) ceil( $s / MINUTE_IN_SECONDS );
		return $m . ' min';
	}
	$h = (int) round( $s / HOUR_IN_SECONDS );
	return $h . ' hours';
}

/**
 * The Conference a page is about when nothing else says: the year of the page it returns to; else the
 * person's own sooner member year; else the next Conference with dates that hasn't ended; else the
 * newest year (between one Conference and the next one's dates, that's the next one: the Advisors asked
 * for 2028 to show before its dates are known).
 */
function ogc_auth_year( $ret = '', $email = '' ) {
	$q = array();
	wp_parse_str( (string) wp_parse_url( (string) $ret, PHP_URL_QUERY ), $q );
	if ( ! empty( $q['year'] ) && ogc_valid_year( $q['year'] ) && function_exists( 'ogc_year_get' ) && ogc_year_get( (int) $q['year'] ) ) {
		return (int) $q['year'];
	}
	if ( $email && function_exists( 'ogc_member_rows_for' ) ) {
		$mine = array();
		foreach ( ogc_member_rows_for( $email ) as $m ) {
			if ( ogc_member_active( $m ) ) {
				$mine[] = (int) $m['year'];
			}
		}
		if ( $mine ) {
			return ogc_member_sooner_year( $mine );
		}
	}
	$today = gmdate( 'Y-m-d' );
	$all   = function_exists( 'ogc_years_all' ) ? ogc_years_all() : array();
	// ogc_years_all is newest first: reversed, the first with dates still ahead is the soonest.
	foreach ( array_reverse( $all ) as $y ) {
		if ( ! empty( $y['end'] ) && $y['end'] >= $today ) {
			return (int) $y['year'];
		}
	}
	return $all ? (int) $all[0]['year'] : (int) gmdate( 'Y' );
}

/* ================================================================== return addresses */

/** A return address, if it's a page of ours: a path under /annual-conference/ (not sign-in itself, not
 * the dev routes). Full addresses on this site are cut to their path; anything else is ''. */
function ogc_safe_return( $r ) {
	if ( ! is_string( $r ) ) {
		return '';
	}
	$r    = trim( $r );
	$home = untrailingslashit( home_url() );
	if ( 0 === stripos( $r, $home . '/' ) ) {
		$r = substr( $r, strlen( $home ) );
	}
	if ( '' === $r || strlen( $r ) > 300 || preg_match( '#[\\\\\s\x00-\x1f\x7f]|/\.\.?(/|$)|%2e|%2f|%5c#i', $r ) ) {
		return '';
	}
	if ( '/' !== $r[0] || ( isset( $r[1] ) && '/' === $r[1] ) ) {
		return '';
	}
	$base = wp_make_link_relative( ogc_url() );
	if ( 0 !== strpos( $r, $base ) && rtrim( $base, '/' ) !== $r ) {
		return '';
	}
	foreach ( array( 'signin', 'dev-', 'mail' ) as $not ) {
		if ( 0 === strpos( $r, $base . $not ) ) {
			return '';
		}
	}
	$ok = wp_validate_redirect( home_url( $r ), '' );
	return $ok ? $r : '';
}

/** Where someone lands after signing in when nothing asked for a page: a webmaster on the webmasters'
 * page; a member of one year where their invite lands them (ogc_member_landing: their committee's own
 * page when "Helps with" names one, else the year); of several, a choice of years; everyone else on
 * Your sign-ups. */
function ogc_landing_for( $user_id ) {
	if ( ogc_is_webmaster( $user_id ) ) {
		return wp_make_link_relative( ogc_url( 'admin', array( 'role' => 'web' ) ) );
	}
	$years = ogc_member_years( $user_id );
	if ( 1 === count( $years ) ) {
		return function_exists( 'ogc_member_landing' ) ? ogc_member_landing( (int) $years[0], ogc_user_email( $user_id ) ) : wp_make_link_relative( ogc_url( 'year', array( 'year' => (int) $years[0] ) ) );
	}
	if ( count( $years ) > 1 ) {
		// Two years (2027's Lodging and 2028's COA): the sooner Conference; the other is "Open 2028"
		// beside the account mark, so there's no chooser to pass through.
		$y = ogc_member_sooner_year( $years );
		return function_exists( 'ogc_member_landing' ) ? ogc_member_landing( $y, ogc_user_email( $user_id ) ) : wp_make_link_relative( ogc_url( 'year', array( 'year' => $y ) ) );
	}
	return ogc_mine_link( ogc_user_email( $user_id ) );
}

/** Of several years, the sooner Conference: the first that hasn't ended, else the newest. */
function ogc_member_sooner_year( $years ) {
	$years = array_map( 'intval', (array) $years );
	sort( $years );
	$today = gmdate( 'Y-m-d' );
	foreach ( $years as $y ) {
		$row = function_exists( 'ogc_year_get' ) ? ogc_year_get( $y ) : null;
		if ( ! $row || empty( $row['end'] ) || $row['end'] >= $today ) {
			return $y;
		}
	}
	return (int) end( $years );
}

/** The newest year with something under this email, else the Conference coming up. */
function ogc_records_year_for( $email ) {
	global $wpdb;
	$y = $email ? (int) $wpdb->get_var( $wpdb->prepare( 'SELECT MAX(year) FROM ' . ogc_table( 'records' ) . ' WHERE email = %s AND deleted_at IS NULL', $email ) ) : 0;
	return $y ? $y : ogc_auth_year();
}

/**
 * The year a person's Your sign-ups opens on (after the sixth critic, Oct 15: without one the page asked
 * for reg//mine and said "Couldn't load"): the soonest Conference they have sign-ups or a registration
 * for that hasn't ended (ogc_member_sooner_year), else the current one (ogc_auth_year). Mechanical: their
 * own records by an exact email match, nothing else.
 */
function ogc_mine_year( $email ) {
	global $wpdb;
	$email = strtolower( trim( (string) $email ) );
	$years = $email ? array_map( 'intval', (array) $wpdb->get_col( $wpdb->prepare( 'SELECT DISTINCT year FROM ' . ogc_table( 'records' ) . " WHERE email = %s AND deleted_at IS NULL AND kind IN ('signups','registrations','waits')", $email ) ) ) : array();
	$years = array_values( array_filter( $years, function ( $y ) {
		return function_exists( 'ogc_year_get' ) && ogc_year_get( $y );
	} ) );
	if ( $years ) {
		$y     = ogc_member_sooner_year( $years );
		$row   = ogc_year_get( $y );
		$today = gmdate( 'Y-m-d' );
		// All of them over: the Conference coming up, unless theirs is the newest there is.
		if ( empty( $row['end'] ) || $row['end'] >= $today ) {
			return $y;
		}
	}
	return ogc_auth_year();
}

/** Your sign-ups' address for a person: always with its year. */
function ogc_mine_link( $email ) {
	return wp_make_link_relative( ogc_url( 'register', array( 'view' => 'mine', 'year' => ogc_mine_year( $email ) ) ) );
}

/* ================================================================== the plugin's people */

add_action( 'init', function () {
	if ( ! get_role( 'ogc_person' ) ) {
		add_role( 'ogc_person', 'Conference person', array( 'read' => true ) );
	}
}, 5 );

/** May an emailed link or code sign this user in? Only if every role is the plugin's own or a plain
 * subscriber; an editor or administrator signs in at wp-login. */
function ogc_link_eligible( $user ) {
	if ( ! $user instanceof WP_User ) {
		return true;
	}
	$roles = (array) $user->roles;
	$ok    = ! array_diff( $roles, array( 'ogc_person', 'subscriber' ) ) && ! user_can( $user, 'manage_options' ) && ! user_can( $user, 'edit_posts' );
	return (bool) apply_filters( 'ogc_link_eligible', $ok, $user );
}

/** Only the plugin's role: kept out of wp-admin and WordPress's account mail. The site's own
 * subscribers keep WordPress as it was (their profile, password reset), unless the webmasters opt them
 * in (filter ogc_subscribers_are_people; on by default only on a local dev site, whose dev sign-in
 * makes subscribers). Review, Oct 11. */
function ogc_is_person_only( $user_id ) {
	$u = get_userdata( (int) $user_id );
	if ( ! $u || user_can( $u, 'manage_options' ) || user_can( $u, 'edit_posts' ) ) {
		return false;
	}
	$roles = (array) $u->roles;
	$ours  = array( 'ogc_person' );
	if ( apply_filters( 'ogc_subscribers_are_people', OGC_DEV ) ) {
		$ours[] = 'subscriber';
	}
	return $roles && ! array_diff( $roles, $ours );
}

/** The WordPress user for an email, made (role ogc_person, a random login, no public name) if asked. */
function ogc_person_for_email( $email, $create = false ) {
	$email = ogc_clean_email( $email );
	if ( ! is_email( $email ) ) {
		return null;
	}
	$u = get_user_by( 'email', $email );
	if ( $u || ! $create ) {
		return $u ? $u : null;
	}
	do {
		$login = 'ogc-' . strtolower( wp_generate_password( 10, false, false ) );
	} while ( username_exists( $login ) );
	$id = wp_insert_user( array(
		'user_login'   => $login,
		'user_email'   => $email,
		'user_pass'    => wp_generate_password( 40, true, true ),
		// Never the address itself: logs and lists show the masked one until a name is known.
		'display_name' => ogc_mask_email( $email ),
		'nickname'     => $login,
		'role'         => 'ogc_person',
	) );
	return is_wp_error( $id ) ? null : get_userdata( $id );
}

/** A person's name as they gave it (kept in user meta, never as WordPress's public display name). */
function ogc_person_name( $user_id ) {
	$n = (string) get_user_meta( (int) $user_id, 'ogc_name', true );
	if ( '' !== $n ) {
		return $n;
	}
	$u = get_userdata( (int) $user_id );
	if ( ! $u ) {
		return '';
	}
	// A site admin added in wp-admin: the name WordPress has for them (never a login).
	$full = trim( get_user_meta( $u->ID, 'first_name', true ) . ' ' . get_user_meta( $u->ID, 'last_name', true ) );
	if ( '' !== $full ) {
		return $full;
	}
	return 0 !== strpos( $u->display_name, 'ogc-' ) && $u->display_name !== $u->user_login && false === strpos( $u->display_name, '@' ) && false === strpos( $u->display_name, '*' ) ? $u->display_name : '';
}

function ogc_person_set_name( $user_id, $name ) {
	$name = ogc_mail_safe_name( $name );
	if ( $user_id && '' !== $name ) {
		update_user_meta( (int) $user_id, 'ogc_name', $name );
		// WordPress's own name for them (the change log's "who") is the site's "Ruth K.".
		if ( ogc_is_person_only( $user_id ) ) {
			wp_update_user( array( 'ID' => (int) $user_id, 'display_name' => ogc_first_l( $name ) ) );
		}
	}
}

// Out of wp-admin (to Your sign-ups), no admin bar, no password paths, none of WordPress's own emails.
add_action( 'admin_init', function () {
	if ( wp_doing_ajax() || ( defined( 'DOING_CRON' ) && DOING_CRON ) || ! is_user_logged_in() ) {
		return;
	}
	if ( ogc_is_person_only( get_current_user_id() ) ) {
		wp_safe_redirect( home_url( ogc_mine_link( ogc_user_email( get_current_user_id() ) ) ) );
		exit;
	}
} );
add_filter( 'show_admin_bar', function ( $show ) {
	return is_user_logged_in() && ogc_is_person_only( get_current_user_id() ) ? false : $show;
} );
add_filter( 'wp_is_application_passwords_available_for_user', function ( $ok, $user ) {
	return $user instanceof WP_User && ogc_is_person_only( $user->ID ) ? false : $ok;
}, 10, 2 );
add_filter( 'allow_password_reset', function ( $ok, $user_id ) {
	return ogc_is_person_only( $user_id ) ? false : $ok;
}, 10, 2 );
add_filter( 'send_email_change_email', function ( $send, $user ) {
	return isset( $user['ID'] ) && ogc_is_person_only( $user['ID'] ) ? false : $send;
}, 10, 2 );
add_filter( 'send_password_change_email', function ( $send, $user ) {
	return isset( $user['ID'] ) && ogc_is_person_only( $user['ID'] ) ? false : $send;
}, 10, 2 );
add_filter( 'wp_send_new_user_notification_to_user', function ( $send, $user ) {
	return $user instanceof WP_User && ogc_is_person_only( $user->ID ) ? false : $send;
}, 10, 2 );
add_filter( 'wp_send_new_user_notification_to_admin', function ( $send, $user ) {
	return $user instanceof WP_User && in_array( 'ogc_person', (array) $user->roles, true ) ? false : $send;
}, 10, 2 );
// No password sign-in at wp-login for the plugin's people: an emailed link or code is the only way.
add_filter( 'wp_authenticate_user', function ( $user ) {
	if ( $user instanceof WP_User && in_array( 'ogc_person', (array) $user->roles, true ) && ogc_is_person_only( $user->ID ) ) {
		return new WP_Error( 'ogc_link_only', 'Sign in at ' . esc_html( preg_replace( '#^https?://#', '', untrailingslashit( ogc_url( 'signin' ) ) ) ) . '.' );
	}
	return $user;
} );

// How long a sign-in lasts on a device.
add_filter( 'auth_cookie_expiration', function ( $len, $user_id, $remember ) {
	$u = $user_id ? get_userdata( $user_id ) : null;
	if ( ! $u || ! ogc_link_eligible( $u ) ) {
		return $len;
	}
	if ( ! $remember ) {
		return 4 * HOUR_IN_SECONDS;
	}
	return user_can( $u, 'ogc_manage_all' ) ? 7 * DAY_IN_SECONDS : YEAR_IN_SECONDS;
}, 10, 3 );

/** When this browser's sign-in started (WordPress's session token keeps it). */
function ogc_session_login_time( $user_id = null ) {
	$user_id = null === $user_id ? get_current_user_id() : (int) $user_id;
	if ( ! $user_id || get_current_user_id() !== $user_id ) {
		return 0;
	}
	$s = WP_Session_Tokens::get_instance( $user_id )->get( wp_get_session_token() );
	return $s && isset( $s['login'] ) ? (int) $s['login'] : 0;
}

/** Is this browser marked as a shared device (the Information Center's laptop)? A setting of the device,
 * not of one sign-in: a year-long cookie the Shared device switch sets, which every later sign-in on this
 * browser follows (it ends when the browser closes, or after 4 hours). Off by default. */
function ogc_device_shared() {
	return '1' === ogc_cookie_get( 'ogc_shared' );
}

/** Mark or unmark this browser as a shared device. */
function ogc_device_set_shared( $on ) {
	ogc_cookie( 'ogc_shared', $on ? '1' : '', $on ? YEAR_IN_SECONDS : -3600 );
}

/** Does this browser's sign-in end with the browser (a shared device)? Its session lasts 4 hours. */
function ogc_session_is_shared() {
	$uid = get_current_user_id();
	$s   = $uid ? WP_Session_Tokens::get_instance( $uid )->get( wp_get_session_token() ) : null;
	return $s && isset( $s['login'], $s['expiration'] ) && ( (int) $s['expiration'] - (int) $s['login'] ) <= 4 * HOUR_IN_SECONDS + 60;
}

/* ================================================================== who the site knows */

/** Does the site know this address (any record or linked record, a membership, a webmaster, someone
 * who has signed in before)? Only those get mail; the page answers the same either way. */
function ogc_email_known( $email ) {
	global $wpdb;
	$email = ogc_clean_email( $email );
	$known = (bool) $wpdb->get_var( $wpdb->prepare( 'SELECT 1 FROM ' . ogc_table( 'records' ) . ' WHERE email = %s AND deleted_at IS NULL LIMIT 1', $email ) )
		|| (bool) $wpdb->get_var( $wpdb->prepare( 'SELECT 1 FROM ' . ogc_table( 'record_links' ) . ' WHERE email = %s LIMIT 1', $email ) );
	if ( ! $known && function_exists( 'ogc_member_rows_for' ) ) {
		$known = (bool) ogc_member_rows_for( $email );
	}
	if ( ! $known ) {
		$u     = get_user_by( 'email', $email );
		$known = $u && ( user_can( $u, 'ogc_manage_all' ) || get_user_meta( $u->ID, 'ogc_confirmed_at', true ) );
	}
	return (bool) apply_filters( 'ogc_email_known', $known, $email );
}

/** Known, and a link may sign them in. */
function ogc_email_may_signin( $email ) {
	$u = get_user_by( 'email', ogc_clean_email( $email ) );
	return ogc_email_known( $email ) && ( ! $u || ogc_link_eligible( $u ) );
}

/* ================================================================== tokens */

/**
 * A one-time link (and, for sign-in, a code). Returns array( id, token, code, url ).
 * $a: ttl, return, data (kept with it: shared, intent…), code (bool), rhash (the asking browser).
 */
function ogc_token_create( $kind, $email, $a = array() ) {
	global $wpdb;
	$a     = array_merge( array( 'ttl' => OGC_SIGNIN_TTL, 'return' => '', 'data' => array(), 'code' => false, 'rhash' => null ), (array) $a );
	$token = ogc_random_token();
	$code  = $a['code'] ? ogc_random_code() : '';
	$th    = ogc_auth_hash( 't|' . $token );
	$wpdb->insert( ogc_table( 'tokens' ), array(
		'thash'      => $th,
		'kind'       => substr( (string) $kind, 0, 16 ),
		'email'      => ogc_clean_email( $email ),
		'chash'      => $code ? ogc_auth_hash( 'c|' . $code . '|' . $th ) : null,
		'rhash'      => $a['rhash'],
		'return_to'  => ogc_safe_return( (string) $a['return'] ),
		'data'       => ogc_json( (object) $a['data'] ),
		'created_at' => ogc_now(),
		'expires_at' => gmdate( 'Y-m-d H:i:s', time() + (int) $a['ttl'] ),
	) );
	return array( 'id' => (int) $wpdb->insert_id, 'token' => $token, 'code' => $code, 'url' => ogc_url( 'signin', array( 't' => $token ) ) );
}

/** A link that signs this email in and goes to $return, valid 7 days (invites, confirmations). */
function ogc_signin_link_for( $email, $return = '', $kind = 'confirm', $data = array(), $ttl = OGC_LINK_TTL ) {
	$t = ogc_token_create( $kind, $email, array( 'ttl' => $ttl, 'return' => $return, 'data' => $data ) );
	return $t['url'];
}

function ogc_token_find( $token ) {
	global $wpdb;
	if ( ! is_string( $token ) || strlen( $token ) < 20 || strlen( $token ) > 100 ) {
		return null;
	}
	$r = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . ogc_table( 'tokens' ) . ' WHERE thash = %s', ogc_auth_hash( 't|' . $token ) ), ARRAY_A );
	if ( $r ) {
		$r['data'] = (array) ogc_unjson( $r['data'], array() );
	}
	return $r;
}

/** ok | used | expired. */
function ogc_token_state( $row ) {
	if ( ! empty( $row['used_at'] ) ) {
		return 'used';
	}
	return strtotime( $row['expires_at'] . ' UTC' ) < time() ? 'expired' : 'ok';
}

/** Spend it: true only for the one request that did (two taps at once can't both sign in). */
function ogc_token_spend( $row, $user_id = 0 ) {
	global $wpdb;
	return 1 === (int) $wpdb->query( $wpdb->prepare( 'UPDATE ' . ogc_table( 'tokens' ) . ' SET used_at = %s, used_by = %d WHERE id = %d AND used_at IS NULL', ogc_now(), (int) $user_id, (int) $row['id'] ) );
}

/** Kinds of link: what its card says and what its button does. An area adds its own (a parent's
 * approval) with the ogc_token_kinds filter: kind → array( heading, button, run( $row ) → a URL to go
 * to, or WP_Error; optional facts( $row ) → [[label, value]…] shown on the card once the link is
 * opened (never in the email), and decline → array( label, run( $row ) ), a quiet second button ).
 * Sign-in kinds (signin, invite, confirm, webmaster) sign the person in. */
function ogc_token_kinds() {
	$kinds = array(
		'notme' => array(
			'heading' => 'Remove sign-up',
			'button'  => 'Remove',
			'run'     => function ( $row ) {
				$rid = isset( $row['data']['record'] ) ? (int) $row['data']['record'] : 0;
				$rec = $rid ? ogc_record_get( $rid ) : null;
				if ( $rec && $rec['email'] === $row['email'] ) {
					ogc_record_delete( $rid );
					ogc_log( 'record_notme', $rec['year'], $rec['kind'], array( 'id' => $rid ) );
					do_action( 'ogc_record_saved', $rec, 'delete', new WP_REST_Request( 'DELETE' ) );
				}
				ogc_cookie( 'ogc_flash', 'removed', 60, false );
				return ogc_url();
			},
		),
	);
	// A sign-in or confirmation link's card is headed with the page it opens ("Lodging", "Your sign-ups"),
	// as the form is, so the extra tap (it keeps mail scanners from spending the link) doesn't read as
	// "didn't that work?". The address sits under it, then the one button.
	$dest = function ( $row ) {
		$l = ogc_signin_link_dest( $row );
		return '' !== $l ? $l : 'Sign in';
	};
	$kinds['signin']  = array( 'heading' => $dest );
	$kinds['confirm'] = array( 'heading' => $dest );
	// An invite's card says what the email said: who added you, and "Open 2027" (module-members.php
	// keeps the year, the member row and who sent it with the link).
	$kinds['invite'] = array(
		'heading' => function ( $row ) {
			$by = ! empty( $row['data']['by'] ) ? ogc_person_name( (int) $row['data']['by'] ) : '';
			$y  = ! empty( $row['data']['year'] ) ? (int) $row['data']['year'] : 0;
			return $by ? ogc_first_l( $by ) . ' added you' : ( $y ? 'Added to ' . $y : 'Sign in' );
		},
		// The email's own words: "Open Lodging" (or "Open 2027" for the COA), the committee, the access.
		'button'  => function ( $row ) {
			$m = ! empty( $row['data']['member'] ) && function_exists( 'ogc_member_get' ) ? ogc_member_get( (int) $row['data']['member'] ) : null;
			if ( $m && ! $m['removed_at'] && $m['email'] === $row['email'] ) {
				return ogc_member_open_label( $m, $row['return_to'] ? $row['return_to'] : null );
			}
			return ! empty( $row['data']['year'] ) ? 'Open ' . (int) $row['data']['year'] : 'Sign in';
		},
		'facts'   => function ( $row ) {
			$m = ! empty( $row['data']['member'] ) && function_exists( 'ogc_member_get' ) ? ogc_member_get( (int) $row['data']['member'] ) : null;
			if ( ! $m || $m['removed_at'] || $m['email'] !== $row['email'] ) {
				return array();
			}
			$acc = (string) apply_filters( 'ogc_member_access', '', $m );
			return array( array( 'Committee', ogc_member_committee_words( $m ) ), array( 'Access', '' !== $acc ? $acc : 'Every ' . (int) $m['year'] . ' page and list' ) );
		},
	);
	$kinds['webmaster'] = array(
		'heading' => function ( $row ) {
			$by = ! empty( $row['data']['by'] ) ? ogc_person_name( (int) $row['data']['by'] ) : '';
			return $by ? ogc_first_l( $by ) . ' added you' : 'Conference webmasters';
		},
		'button'  => 'Sign in',
		'facts'   => function ( $row ) {
			return array( array( 'Role', 'Conference webmaster' ) );
		},
	);
	return (array) apply_filters( 'ogc_token_kinds', $kinds );
}

/** The name of the page a sign-in link opens: its return page, else where this person lands. */
function ogc_signin_link_dest( $row ) {
	$ret = (string) $row['return_to'];
	if ( '' === $ret ) {
		$u   = get_user_by( 'email', (string) $row['email'] );
		$ret = $u ? ogc_landing_for( $u->ID ) : ogc_mine_link( (string) $row['email'] );
	}
	return ogc_signin_dest_label( $ret );
}

/** A kind's heading or button for this link: a fixed word, or a function of the link. */
function ogc_token_word( $kind, $what, $row, $default ) {
	$k = ogc_token_kinds();
	if ( ! isset( $k[ $kind ][ $what ] ) ) {
		return $default;
	}
	$v = $k[ $kind ][ $what ];
	return $v instanceof Closure ? (string) call_user_func( $v, $row ) : (string) $v;
}

function ogc_token_signs_in( $kind ) {
	return in_array( $kind, array( 'signin', 'invite', 'confirm', 'webmaster' ), true );
}

/* ================================================================== signing in */

/**
 * Someone asked for a sign-in code and link. Same answer for every address (never says whether it's
 * known); mail goes out after the response: the code and link to an address the site knows, one fixed
 * "No sign-ups under this email" to one it doesn't (once a day), a fixed note to an editor's or
 * admin's (they use wp-login). No code is made for an address that may not sign in this way, so a
 * lucky guess can't make a user for an address nobody proved.
 * $a: return, shared (a shared device), intent (what to do after: an area's, kept on the server).
 * Returns array( email, until ) or WP_Error (ogc_bad_email; ogc_rate with data.until).
 */
function ogc_signin_request( $email, $a = array() ) {
	global $wpdb;
	$a     = array_merge( array( 'return' => '', 'shared' => false, 'intent' => null, 'mask' => false, 'for' => '', 'typos_ok' => false ), (array) $a );
	$email = ogc_clean_email( $email );
	if ( ! is_email( $email ) ) {
		return new WP_Error( 'ogc_bad_email', 'Check the email', array( 'status' => 400 ) );
	}
	// The registration form (for = register): a new household's address isn't known yet, so it gets a
	// code like a known one, with no link (the form's draft lives in its own tab). A likely typo is
	// asked about once first ("Check gmial.com"), before anything is counted or sent.
	$reg = 'register' === $a['for'];
	$fix = $reg && ! $a['typos_ok'] ? ogc_email_suggest( $email ) : '';
	if ( $fix && $fix !== $email ) {
		$was = substr( strrchr( $email, '@' ), 1 );
		return new WP_Error( 'ogc_typo', 'Check ' . $was . ' · Did you mean ' . substr( strrchr( $fix, '@' ), 1 ) . '?', array( 'status' => 409, 'fix' => $fix ) );
	}
	$until = ogc_signin_next_at( $email );
	// Each limit is counted as it's checked (ogc_throttle), so parallel requests can't all pass.
	foreach ( $until ? array() : ogc_signin_limits( $email ) as $c ) {
		$until = max( $until, ogc_throttle( $c[0], $c[1], $c[2] ) );
	}
	if ( $until ) {
		ogc_log( 'signin_limited', 0, 'h:' . substr( ogc_auth_hash( $email ), 0, 16 ), array() );
		return new WP_Error( 'ogc_rate', 'Too many codes · Try in ' . ogc_wait_words( $until ), array( 'status' => 429, 'until' => $until ) );
	}
	// This browser's request, kept while it waits. Its three newest codes for this address keep working
	// (Resend, and mail that arrives out of order); a code another device asked for is never touched.
	$req = ogc_cookie_get( 'ogc_req' );
	if ( ! $req ) {
		$req = ogc_random_token();
	}
	ogc_cookie( 'ogc_req', $req, OGC_SIGNIN_TTL );
	$rh   = ogc_auth_hash( 'r|' . $req );
	$tt   = ogc_table( 'tokens' );
	$wpdb->query( $wpdb->prepare( "DELETE FROM $tt WHERE kind = 'signin' AND used_at IS NULL AND rhash = %s AND email <> %s", $rh, $email ) );
	$keep = array_map( 'intval', (array) $wpdb->get_col( $wpdb->prepare( "SELECT id FROM $tt WHERE kind = 'signin' AND used_at IS NULL AND rhash = %s ORDER BY id DESC", $rh ) ) );
	foreach ( array_slice( $keep, 2 ) as $old ) {
		$wpdb->delete( $tt, array( 'id' => $old ), array( '%d' ) );
	}
	// Asked from a link (not typed): Check your email shows the address masked, as the link did.
	$data = array( 'shared' => (bool) $a['shared'], 'mask' => (bool) $a['mask'] );
	if ( is_array( $a['intent'] ) ) {
		$data['intent'] = $a['intent'];
	}
	$u     = get_user_by( 'email', $email );
	$known = ogc_email_known( $email ) || $reg;
	$may   = $known && ( ! $u || ogc_link_eligible( $u ) );
	// Webmasters get a code like everyone (they sign in on a laptop and read mail on a phone); their
	// wrong-code lock is tighter (ogc_signin_wrong_max). While codes are off, a link only.
	$codes_off = $may && ogc_signin_codes_off( $email );
	$t         = ogc_token_create( 'signin', $email, array( 'code' => $may && ! $codes_off, 'rhash' => $rh, 'return' => $a['return'], 'data' => $data ) );
	ogc_log( $may ? 'signin_sent' : ( $known ? 'signin_wplogin' : 'signin_unknown' ), 0, 'h:' . substr( ogc_auth_hash( $email ), 0, 16 ), array( 'token' => $t['id'] ) );
	if ( $may ) {
		$url = $reg && ! $codes_off ? '' : $t['url'];
		ogc_after_response( function () use ( $email, $t, $codes_off, $url, $reg ) {
			// confirm: the registration form's code ("Confirm your email": they're registering, not signing in).
			ogc_mail_send_kind( 'signin', $email, array( 'code' => $t['code'], 'url' => $url, 'minutes' => OGC_SIGNIN_TTL / 60, 'codes_off' => $codes_off, 'confirm' => $reg ) );
		} );
	} elseif ( ! ogc_throttle( 'nu:' . $email, 1, DAY_IN_SECONDS ) ) {
		// The same few fixed words for anyone who types this address, at most once a day.
		$kind = $known ? 'signin_wplogin' : 'no_signups';
		$year = ogc_auth_year( $a['return'] );
		// Asked from a committee's page: "Not on the 2027 members list" (fixed words, whoever types it).
		$data = array( 'year' => $year, 'members_page' => ogc_return_is_members_page( $a['return'] ), 'return' => ogc_safe_return( (string) $a['return'] ) );
		ogc_after_response( function () use ( $email, $data, $kind ) {
			ogc_mail_send_kind( $kind, $email, $data );
		} );
	}
	$out = array( 'email' => $email, 'until' => time() + OGC_SIGNIN_TTL, 'next' => ogc_signin_next_at( $email ) );
	// The form's walk-through, on a local dev site only (never a staging copy with OGC_DEV left on):
	// no mail goes out, so the code comes back for the tester's "Local: code" pill.
	if ( $reg && $may && $t['code'] && OGC_DEV && function_exists( 'ogc_is_local_host' ) && ogc_is_local_host() ) {
		$out['dev_code'] = $t['code'];
	}
	return $out;
}

/** Has this device signed in as this address before? Then it may always ask for one more code. */
function ogc_device_trusted( $email ) {
	$h = ogc_device_hash();
	$u = $h ? get_user_by( 'email', ogc_clean_email( $email ) ) : null;
	return $u && in_array( $h, (array) get_user_meta( $u->ID, 'ogc_devices', true ), true );
}

/** Note this device as one the user has signed in on (the last ten). */
function ogc_device_remember( $user_id ) {
	$h = ogc_device_hash( true );
	if ( ! $h ) {
		return;
	}
	$list = array_values( array_diff( (array) get_user_meta( $user_id, 'ogc_devices', true ), array( $h ) ) );
	array_unshift( $list, $h );
	update_user_meta( $user_id, 'ogc_devices', array_slice( $list, 0, 10 ) );
}

/** The limits on sending a sign-in code. Per address and device (the main guard); per address across
 * devices (skipped on a device that has signed in as it before); a high ceiling per IP (a campus or
 * church Wi-Fi puts many families behind one address; Corey names the real client-IP header before
 * go-live: ogc_client_ip). */
function ogc_signin_limits( $email ) {
	$per_ip = max( 20, (int) apply_filters( 'ogc_signin_ip_per_hour', 300 ) );
	$dev    = ogc_device_hash( true );
	$out    = array(
		array( 'sm:' . $email . '|' . $dev, 1, MINUTE_IN_SECONDS ),
		array( 'se:' . $email . '|' . $dev, 3, 15 * MINUTE_IN_SECONDS ),
		array( 'sd:' . $email . '|' . $dev, 10, DAY_IN_SECONDS ),
		array( 'si:' . ogc_client_ip(), $per_ip, HOUR_IN_SECONDS ),
	);
	if ( ! ogc_device_trusted( $email ) ) {
		$out[] = array( 'sa:' . $email, 15, DAY_IN_SECONDS );
	}
	return $out;
}

/** When this address may be sent another code (0: now). Resend counts down to it. */
function ogc_signin_next_at( $email ) {
	$until = 0;
	foreach ( ogc_signin_limits( ogc_clean_email( $email ) ) as $c ) {
		$until = max( $until, ogc_throttle( $c[0], $c[1], $c[2], false ) );
	}
	return $until;
}

/** Wrong codes an address takes in a day from devices that haven't signed in as it: 10, the same for
 * every address (a lower limit for webmasters told a stranger which addresses were webmasters). How
 * webmasters sign in (a code, a link bound to the asking device, or wp-login's two-step) is the
 * Advisors' choice for the Nov 6 security plan (questions-signin Q5). */
function ogc_signin_wrong_max( $email ) {
	return 10;
}

/** Too many wrong codes for this address today: codes are off for 24 hours (links still work). Not on
 * a device that has signed in as the address before: a stranger's guesses can't switch off the real
 * person's codes on their own phone. */
function ogc_signin_codes_off( $email ) {
	$email = ogc_clean_email( $email );
	if ( ogc_device_trusted( $email ) ) {
		return false;
	}
	return (bool) ogc_throttle( 'cf:' . $email, ogc_signin_wrong_max( $email ), DAY_IN_SECONDS, false );
}

/** The sign-in this browser asked for (its ogc_req cookie): the newest. */
function ogc_signin_pending() {
	global $wpdb;
	$req = ogc_cookie_get( 'ogc_req' );
	if ( ! $req ) {
		return null;
	}
	$r = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . ogc_table( 'tokens' ) . " WHERE rhash = %s AND kind = 'signin' ORDER BY id DESC LIMIT 1", ogc_auth_hash( 'r|' . $req ) ), ARRAY_A );
	if ( $r ) {
		$r['data'] = (array) ogc_unjson( $r['data'], array() );
	}
	return $r;
}

/** This browser's open codes for the same address (the newest three), any of which may be typed. */
function ogc_signin_open_rows( $row ) {
	global $wpdb;
	$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . ogc_table( 'tokens' ) . " WHERE rhash = %s AND email = %s AND kind = 'signin' AND used_at IS NULL AND chash IS NOT NULL AND expires_at > %s ORDER BY id DESC LIMIT 3", $row['rhash'], $row['email'], ogc_now() ), ARRAY_A );
	foreach ( $rows as &$r ) {
		$r['data'] = (array) ogc_unjson( $r['data'], array() );
	}
	unset( $r );
	return (array) $rows;
}

/** A code typed in the browser that asked. Returns the URL to go to, or WP_Error. */
function ogc_signin_code( $code ) {
	global $wpdb;
	$code = preg_replace( '/\D/', '', (string) $code );
	$row  = ogc_signin_pending();
	if ( ! $row || 'ok' !== ogc_token_state( $row ) ) {
		return new WP_Error( 'ogc_code_gone', 'Code expired · Send a new one', array( 'status' => 400 ) );
	}
	if ( ogc_signin_codes_off( $row['email'] ) ) {
		return new WP_Error( 'ogc_code_tries', 'Too many tries · Send a new code', array( 'status' => 400 ) );
	}
	// The try is counted before anything is compared, in one statement: parallel guesses can't all read
	// "tries < 5" before any of them adds one.
	$n = $wpdb->query( $wpdb->prepare( 'UPDATE ' . ogc_table( 'tokens' ) . ' SET tries = tries + 1 WHERE id = %d AND tries < 5 AND used_at IS NULL', $row['id'] ) );
	if ( 1 !== (int) $n ) {
		return new WP_Error( 'ogc_code_tries', 'Too many tries · Send a new code', array( 'status' => 400 ) );
	}
	$hit = null;
	if ( 6 === strlen( $code ) ) {
		foreach ( ogc_signin_open_rows( $row ) as $r ) {
			// A code kept after its link was used on another device is checked against that link (cth).
			$th = isset( $r['data']['cth'] ) ? (string) $r['data']['cth'] : $r['thash'];
			if ( hash_equals( $r['chash'], ogc_auth_hash( 'c|' . $code . '|' . $th ) ) ) {
				$hit = $r;
				break;
			}
		}
	}
	if ( ! $hit ) {
		ogc_log( 'signin_failed', 0, 'token:' . $row['id'], array( 'why' => 'code' ) );
		// A wrong code counts against the address only from a device that hasn't signed in as it.
		$trusted = ogc_device_trusted( $row['email'] );
		if ( ! $trusted ) {
			ogc_throttle( 'cf:' . $row['email'], ogc_signin_wrong_max( $row['email'] ), DAY_IN_SECONDS );
		}
		if ( ! $trusted && ogc_signin_codes_off( $row['email'] ) ) {
			// The limit reached: every open code for the address ends, and the address is told (once).
			// The person's own devices ask again and get a code.
			$wpdb->query( $wpdb->prepare( 'UPDATE ' . ogc_table( 'tokens' ) . " SET chash = NULL WHERE email = %s AND kind = 'signin' AND used_at IS NULL", $row['email'] ) );
			ogc_log( 'signin_codes_off', 0, 'h:' . substr( ogc_auth_hash( $row['email'] ), 0, 16 ) );
			if ( ogc_email_may_signin( $row['email'] ) && ! ogc_throttle( 'cfm:' . $row['email'], 1, DAY_IN_SECONDS ) ) {
				$to = $row['email'];
				ogc_after_response( function () use ( $to ) {
					ogc_mail_send_kind( 'codes_off', $to, array() );
				} );
			}
			return new WP_Error( 'ogc_code_tries', 'Too many tries · Send a new code', array( 'status' => 400 ) );
		}
		$left = 5 - ( (int) $row['tries'] + 1 );
		return new WP_Error( 'ogc_code_bad', $left <= 0 ? 'Too many tries · Send a new code' : 'Code not valid · ' . $left . ( 1 === $left ? ' try left' : ' tries left' ), array( 'status' => 400, 'left' => max( 0, $left ) ) );
	}
	return ogc_signin_finish( $hit, 'code' );
}

/** Is this browser the one that asked for this sign-in (its ogc_req cookie)? */
function ogc_signin_is_asker( $row ) {
	$req = ogc_cookie_get( 'ogc_req' );
	return ! empty( $row['rhash'] ) && '' !== $req && hash_equals( (string) $row['rhash'], ogc_auth_hash( 'r|' . $req ) );
}

/**
 * The link was used on another device (asked on the laptop, tapped on the phone): the code stays good
 * on the device that asked, which then says "Signed in on another device · Code still works here".
 * A new row holds the same code (checked against the old link, cth) under a link nobody has.
 */
function ogc_signin_keep_code( $row ) {
	global $wpdb;
	$data              = (array) $row['data'];
	$data['cth']       = $row['thash'];
	$data['elsewhere'] = 1;
	$wpdb->insert( ogc_table( 'tokens' ), array(
		'thash'      => ogc_auth_hash( 't|' . ogc_random_token() ),
		'kind'       => 'signin',
		'email'      => $row['email'],
		'chash'      => $row['chash'],
		'rhash'      => $row['rhash'],
		'tries'      => (int) $row['tries'],
		'return_to'  => (string) $row['return_to'],
		'data'       => ogc_json( (object) $data ),
		'created_at' => ogc_now(),
		'expires_at' => $row['expires_at'],
	) );
}

/** Spend a sign-in row and sign its email in on this browser. Returns where to go, or WP_Error. */
function ogc_signin_finish( $row, $how ) {
	$user = ogc_person_for_email( $row['email'], true );
	if ( ! $user || ! ogc_link_eligible( $user ) ) {
		ogc_log( 'signin_failed', 0, 'token:' . $row['id'], array( 'why' => 'eligible' ) );
		return new WP_Error( 'ogc_not_valid', 'Link not valid', array( 'status' => 400 ) );
	}
	$asker = ogc_signin_is_asker( $row );
	if ( ! ogc_token_spend( $row, $user->ID ) ) {
		return new WP_Error( 'ogc_used', 'Link already used', array( 'status' => 400 ) );
	}
	if ( 'link' === $how && 'signin' === $row['kind'] && ! $asker && ! empty( $row['chash'] ) && ! empty( $row['rhash'] ) && empty( $row['data']['cth'] ) ) {
		ogc_signin_keep_code( $row );
	}
	ogc_auth_sign_in_user( $user, empty( $row['data']['shared'] ), $how . ':' . $row['kind'] );
	if ( $asker ) {
		// This browser's other codes for the sign-in are spent with it (never another device's).
		global $wpdb;
		$wpdb->query( $wpdb->prepare( 'DELETE FROM ' . ogc_table( 'tokens' ) . " WHERE rhash = %s AND kind = 'signin' AND used_at IS NULL", $row['rhash'] ) );
		ogc_cookie( 'ogc_req', '', -3600 );
	}
	ogc_cookie( 'ogc_lt', '', -3600 );
	ogc_cookie( 'ogc_flash', 'signedin', 60, false );
	$go = '';
	do_action_ref_array( 'ogc_signed_in', array( $user->ID, $row, &$go ) );
	if ( ! $go ) {
		$go = $row['return_to'] ? $row['return_to'] : ogc_landing_for( $user->ID );
	}
	return home_url( $go );
}

/**
 * Sign a user in on this browser, the one way every area does it (this page's link and code, the
 * volunteer page's emailed link, the form's code): the session's length follows the rules above, the
 * address is marked confirmed, and it's logged. Never for someone a link may not sign in.
 */
function ogc_auth_sign_in_user( $user, $remember = true, $how = '' ) {
	if ( ! $user instanceof WP_User || ! ogc_link_eligible( $user ) ) {
		return false;
	}
	// A shared device (the desk's laptop) keeps no one signed in past the browser, whoever signs in next.
	$remember = $remember && ! ogc_device_shared();
	// Confirming again (after 30 days): the old session on this browser ends with the new one's start.
	if ( get_current_user_id() === $user->ID && wp_get_session_token() ) {
		WP_Session_Tokens::get_instance( $user->ID )->destroy( wp_get_session_token() );
	}
	wp_clear_auth_cookie();
	wp_set_current_user( $user->ID );
	wp_set_auth_cookie( $user->ID, (bool) $remember, is_ssl() );
	if ( ! get_user_meta( $user->ID, 'ogc_confirmed_at', true ) ) {
		update_user_meta( $user->ID, 'ogc_confirmed_at', ogc_now() );
	}
	update_user_meta( $user->ID, 'ogc_last_signin', ogc_now() );
	// This device may always ask for one more code for this address (ogc_signin_limits).
	ogc_device_remember( $user->ID );
	if ( ogc_person_name( $user->ID ) && 0 === strpos( $user->display_name, 'ogc-' ) ) {
		ogc_person_set_name( $user->ID, ogc_person_name( $user->ID ) );
	}
	ogc_log( 'signin_used', 0, 'user:' . $user->ID, array( 'how' => substr( (string) $how, 0, 32 ) ) );
	return true;
}

// The volunteer page's emailed link and the form's code have proved the address; signing in is ours.
add_filter( 'ogc_vol_signin', function ( $done, $email ) {
	if ( $done ) {
		return true;
	}
	$u = ogc_person_for_email( $email, true );
	if ( ! $u || ! ogc_link_eligible( $u ) ) {
		return false;
	}
	ogc_auth_sign_in_user( $u, true, 'volunteer' );
	$go = '';
	do_action_ref_array( 'ogc_signed_in', array( $u->ID, array( 'kind' => 'volunteer', 'email' => $u->user_email, 'data' => array() ), &$go ) );
	return true;
}, 10, 2 );
add_filter( 'ogc_vol_link_signs_in', function ( $ok, $email ) {
	$u = get_user_by( 'email', ogc_clean_email( $email ) );
	return $ok && ( ! $u || ogc_link_eligible( $u ) );
}, 10, 2 );
add_filter( 'ogc_reg_sign_in', function ( $done, $email, $name ) {
	if ( null !== $done ) {
		return $done;
	}
	$u = ogc_person_for_email( $email, true );
	if ( ! $u || ! ogc_link_eligible( $u ) ) {
		return new WP_Error( 'ogc_signin', 'Sign in at ' . preg_replace( '#^https?://#', '', untrailingslashit( ogc_url( 'signin' ) ) ), array( 'status' => 403 ) );
	}
	// The logged-in cookie is needed in this same request, for the nonce the form carries on with.
	$grab = function ( $cookie ) {
		$_COOKIE[ LOGGED_IN_COOKIE ] = $cookie;
	};
	add_action( 'set_logged_in_cookie', $grab );
	ogc_auth_sign_in_user( $u, true, 'register' );
	remove_action( 'set_logged_in_cookie', $grab );
	if ( $name && '' === ogc_person_name( $u->ID ) ) {
		ogc_person_set_name( $u->ID, $name );
	}
	$go = '';
	do_action_ref_array( 'ogc_signed_in', array( $u->ID, array( 'kind' => 'register', 'email' => $u->user_email, 'data' => array() ), &$go ) );
	return array( 'me' => array( 'email' => strtolower( $u->user_email ), 'name' => ogc_person_name( $u->ID ) ), 'nonce' => wp_create_nonce( 'wp_rest' ) );
}, 10, 3 );

/* ================================================================== the sign-in page */

add_filter( 'ogc_pages', function ( $p ) {
	if ( ! isset( $p['signin'] ) ) {
		return $p;
	}
	// A public page in the site's own shell (its header says this is ogbbc.org).
	$p['signin'] = array_merge( $p['signin'], array(
		'shell'       => 'theme',
		'html_class'  => '',
		'title'       => 'Sign in',
		'description' => '',
		'noindex'     => true,
		'header'      => array( 'topbar' => false, 'crumb' => false ),
		'styles'      => array( 'shared/ogc-tokens.css', 'shared/ogc-ui.css', 'schedule-hub/week.css', 'signin/signin.css' ),
		'scripts'     => array( 'signin/signin.js' ),
	) );
	// Confirm it's you, opening a members' page after 30 days: the page's own frame (the cream bar and
	// the account mark) with the same dialog as over an open page. Never opened by its address.
	$p['reauth'] = array(
		'path'        => 'confirm-it',
		'members'     => false,
		'folder'      => 'signin',
		'shell'       => 'bare',
		'template'    => 'signin-reauth.php',
		'html_class'  => 'adm-full',
		'title'       => 'Confirm it’s you',
		'noindex'     => true,
		'description' => '',
		'header'      => array(),
		'fonts'       => '',
		'head'        => '',
		'styles'      => array( 'shared/site-shell.css', 'shared/ogc-ui.css', 'schedule-hub/week.css', 'shared/ogc-ws.css' ),
		'scripts'     => array( 'shared/ogc-core.js' ),
	);
	// The account mark (who's signed in, Sign out) on every page that has an editors' bar.
	foreach ( $p as $k => &$page ) {
		if ( 'guide' === $k ) {
			continue;
		}
		$page['scripts'][] = 'signin/ogc-account.js';
		$page['styles'][]  = 'signin/ogc-account.css';
		// Members (module-members.php) on the COA's year page and the webmasters' page.
		if ( in_array( $k, array( 'year', 'admin', 'members' ), true ) ) {
			$page['scripts'][] = 'signin/ogc-members.js';
			$page['styles'][]  = 'signin/ogc-members.css';
		}
	}
	unset( $page );
	return $p;
}, 20 );

// A members' page that refused draws this page in its place (core's ogc_page_refuse): work out what to
// say before the shell prints the title.
// One page says "No access" for every members' page, in one voice, with what's true: a code to
// confirm after 30 days, the date access ended, the years this person does have.
add_filter( 'ogc_template', function ( $file, $name ) {
	if ( 'signin.php' !== $name ) {
		return $file;
	}
	if ( empty( $GLOBALS['ogc_signin'] ) ) {
		ogc_signin_page( 'signin' );
	}
	return OGC_DIR . 'templates/signin.php';
}, 20, 2 );

// The page's title says what's on screen ("Check your email – Annual Conference – …").
add_filter( 'pre_get_document_title', function ( $t ) {
	if ( 'signin' !== ogc_current_page() || empty( $GLOBALS['ogc_signin']['title'] ) ) {
		return $t;
	}
	return $GLOBALS['ogc_signin']['title'] . ' – Annual Conference – ' . get_bloginfo( 'name' );
}, 30 );

// What the page's scripts are told: the person's own name, how to sign out, the years they belong to.
add_filter( 'ogc_client_config', function ( $cfg, $key ) {
	$uid = get_current_user_id();
	if ( $uid ) {
		$cfg['me']['name'] = ogc_person_name( $uid );
		$cfg['logout']     = ogc_url( 'signin', array( 'signout' => 1, '_wpnonce' => wp_create_nonce( 'ogc_signout' ) ) );
		$cfg['signoutAll'] = ogc_url( 'signin', array( 'signout' => 'others', '_wpnonce' => wp_create_nonce( 'ogc_signout_others' ) ) );
		// With its year, the one this person is on (after the sixth critic, Oct 15).
		$cfg['mine']       = ogc_mine_link( ogc_user_email( $uid ) );
		if ( ogc_link_eligible( wp_get_current_user() ) ) {
			$cfg['sharedUrl']    = ogc_url( 'signin', array( 'shared' => 1, '_wpnonce' => wp_create_nonce( 'ogc_shared' ), 'return' => rawurlencode( ogc_safe_return( isset( $_SERVER['REQUEST_URI'] ) ? esc_url_raw( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : '' ) ) ) );
			$cfg['sharedDevice'] = ogc_device_shared() || ogc_session_is_shared();
		}
	}
	return $cfg;
}, 10, 2 );

/** Same-site only, strictly: the browser's Sec-Fetch-Site says same-origin, or (an older browser) an
 * Origin or Referer of this site is present. A request with none of them (a script) is refused. */
function ogc_same_origin_strict() {
	$sfs = isset( $_SERVER['HTTP_SEC_FETCH_SITE'] ) ? strtolower( (string) wp_unslash( $_SERVER['HTTP_SEC_FETCH_SITE'] ) ) : ''; // phpcs:ignore -- compared, not used.
	if ( '' !== $sfs ) {
		return 'same-origin' === $sfs;
	}
	$has = ( isset( $_SERVER['HTTP_ORIGIN'] ) && 'null' !== $_SERVER['HTTP_ORIGIN'] ) || ! empty( $_SERVER['HTTP_REFERER'] );
	return $has && ogc_same_origin();
}

/** Same-site POSTs only: the Origin (or Referer) must be this site. */
function ogc_same_origin() {
	$home = wp_parse_url( home_url() );
	$src  = isset( $_SERVER['HTTP_ORIGIN'] ) ? (string) wp_unslash( $_SERVER['HTTP_ORIGIN'] ) : ( isset( $_SERVER['HTTP_REFERER'] ) ? (string) wp_unslash( $_SERVER['HTTP_REFERER'] ) : '' ); // phpcs:ignore -- compared, not used.
	if ( '' === $src ) {
		return true;
	}
	$u = wp_parse_url( $src );
	return isset( $u['host'] ) && strtolower( $u['host'] ) === strtolower( $home['host'] ) && ( isset( $u['port'] ) ? (int) $u['port'] : 0 ) === ( isset( $home['port'] ) ? (int) $home['port'] : 0 );
}

/** The state the sign-in page draws (templates/signin.php reads $GLOBALS['ogc_signin']). */
function ogc_signin_state( $over = array() ) {
	$GLOBALS['ogc_signin'] = array_merge( isset( $GLOBALS['ogc_signin'] ) ? $GLOBALS['ogc_signin'] : array(), (array) $over );
	return $GLOBALS['ogc_signin'];
}

add_action( 'ogc_before_page', 'ogc_signin_page', 5 );

// A members' page refused only because this browser's sign-in is older than 30 days: its own frame and
// the Confirm it's you dialog, not the public sign-in page in the theme (which looked like being sent
// out to the public site). After the code, the page reloads as itself.
add_action( 'ogc_before_page', function ( $page ) {
	$pages = ogc_pages();
	if ( 'reauth' === $page ) {
		wp_safe_redirect( ogc_url( 'signin' ) );
		exit;
	}
	if ( ! isset( $pages[ $page ] ) || empty( $pages[ $page ]['members'] ) || ! is_user_logged_in() ) {
		return;
	}
	$GLOBALS['ogc_reauth'] = false;
	if ( ogc_page_allowed( $page, $pages[ $page ] ) || empty( $GLOBALS['ogc_reauth'] ) ) {
		return;
	}
	nocache_headers();
	$GLOBALS['ogc_refused']     = true;
	$GLOBALS['ogc_reauth_from'] = array( 'title' => (string) $pages[ $page ]['title'], 'key' => $page );
	status_header( 403 );
	ogc_render_page( 'reauth' );
}, 50 );

// One door: Your sign-ups (and a receipt) for someone not signed in is the sign-in page, coming back
// after. Before, the form drew a sign-in card of its own with other words. A link that carries its
// own sign-in (?signin=, the form's emailed code) is left to the form.
add_action( 'ogc_before_page', function ( $page ) {
	// phpcs:disable WordPress.Security.NonceVerification -- which view; nothing is changed.
	$view = isset( $_GET['view'] ) ? sanitize_key( wp_unslash( $_GET['view'] ) ) : '';
	if ( 'register' !== $page || is_user_logged_in() || ! in_array( $view, array( 'mine', 'receipt' ), true ) || isset( $_GET['signin'] ) ) {
		return;
	}
	// phpcs:enable
	$here = isset( $_SERVER['REQUEST_URI'] ) ? ogc_safe_return( esc_url_raw( wp_unslash( $_SERVER['REQUEST_URI'] ) ) ) : '';
	nocache_headers();
	wp_safe_redirect( ogc_url( 'signin', array_filter( array( 'return' => rawurlencode( $here ) ) ) ), 302 );
	exit;
}, 6 );

// Your sign-ups always has its year (after the sixth critic, Oct 15: the account menu's link, the app's
// and volunteer/?view=mine had none, and the page said "Couldn't load"). Signed in with none: the same
// address with the year this person is on (ogc_mine_year), everything else kept.
add_action( 'ogc_before_page', function ( $page ) {
	// phpcs:disable WordPress.Security.NonceVerification -- which view; nothing is changed.
	$view = isset( $_GET['view'] ) ? sanitize_key( wp_unslash( $_GET['view'] ) ) : '';
	if ( 'register' !== $page || ! is_user_logged_in() || ! in_array( $view, array( 'mine', 'receipt', 'edit', 'done' ), true ) || ( isset( $_GET['year'] ) && preg_match( '/^\d{4}$/', (string) wp_unslash( $_GET['year'] ) ) ) ) {
		return;
	}
	$q = array_map( 'sanitize_text_field', (array) wp_unslash( $_GET ) );
	// phpcs:enable
	$q['year'] = ogc_mine_year( ogc_current_email() );
	nocache_headers();
	wp_safe_redirect( ogc_url( 'register', array_map( 'rawurlencode', $q ) ), 302 );
	exit;
}, 7 );

/** Everything the sign-in page does before it's drawn: the form posts (PRG), the link's card, sign out. */
function ogc_signin_page( $page ) {
	if ( 'signin' !== $page ) {
		return;
	}
	nocache_headers();
	if ( ! defined( 'DONOTCACHEPAGE' ) ) {
		define( 'DONOTCACHEPAGE', true );
	}
	// A link's token never leaves in a Referer; the page can't be framed by another site.
	// (Only on a link's card: elsewhere "same-origin", so the page's own forms carry their Origin.)
	header( 'Referrer-Policy: ' . ( isset( $_GET['t'] ) || isset( $_GET['confirm'] ) || isset( $_GET['h'] ) || isset( $_POST['t'] ) ? 'no-referrer' : 'same-origin' ) ); // phpcs:ignore -- which header, not input used.
	header( "Content-Security-Policy: frame-ancestors 'self'" );
	// phpcs:disable WordPress.Security.NonceVerification -- each POST is checked below (same origin, request cookie, landing cookie, or a nonce).
	$get    = wp_unslash( $_GET );
	$ret    = isset( $get['return'] ) ? ogc_safe_return( (string) $get['return'] ) : '';
	$method = isset( $_SERVER['REQUEST_METHOD'] ) ? strtoupper( (string) $_SERVER['REQUEST_METHOD'] ) : 'GET';
	// Asked for a page: the heading names it ("Your sign-ups", "Lodging"), so what was tapped doesn't
	// vanish behind "Sign in".
	$dest = ogc_signin_dest_label( $ret );
	ogc_signin_state( array( 'state' => 'form', 'return' => $ret, 'email' => '', 'error' => '', 'title' => $dest ? $dest : 'Sign in', 'dest' => $dest ) );

	// Shared device (a switch in the account menu): on, this browser is marked shared (a cookie every
	// later sign-in here follows) and this sign-in now ends when it closes, or after 4 hours; off again,
	// it lasts the year it did.
	if ( isset( $get['shared'] ) && is_user_logged_in() ) {
		$on = '0' !== (string) $get['shared'];
		if ( wp_verify_nonce( isset( $get['_wpnonce'] ) ? (string) $get['_wpnonce'] : '', 'ogc_shared' ) ) {
			ogc_device_set_shared( $on );
			if ( ogc_auth_sign_in_user( wp_get_current_user(), ! $on, $on ? 'shared' : 'unshared' ) ) {
				ogc_cookie( 'ogc_flash', $on ? 'shared' : 'unshared', 60, false );
			}
		}
		wp_safe_redirect( home_url( $ret ? $ret : ogc_landing_for( get_current_user_id() ) ), 303 );
		exit;
	}

	// Confirm it's you, waiting over a page, asks whether a link opened in another tab has signed this
	// browser in again (same site only; a fresh nonce for the page to carry on with). Never cached.
	if ( isset( $get['session'] ) && 'GET' === $method ) {
		header( 'X-Content-Type-Options: nosniff' );
		if ( ! ogc_same_origin_strict() || ! is_user_logged_in() ) {
			wp_send_json( array( 'email' => '', 'fresh' => false ) );
		}
		$t = ogc_session_login_time();
		wp_send_json( array(
			'email' => ogc_current_email(),
			'fresh' => $t && $t >= time() - (int) apply_filters( 'ogc_member_reauth_days', 30 ) * DAY_IN_SECONDS,
			'nonce' => wp_create_nonce( 'wp_rest' ),
		) );
	}

	// Sign out (a link with a nonce, from the account menu or SU.signOut).
	if ( isset( $get['signout'] ) && is_user_logged_in() ) {
		$others = 'others' === $get['signout'];
		if ( ! wp_verify_nonce( isset( $get['_wpnonce'] ) ? (string) $get['_wpnonce'] : '', $others ? 'ogc_signout_others' : 'ogc_signout' ) ) {
			ogc_signin_state( array( 'state' => 'signedin' ) );
			return;
		}
		if ( $others ) {
			WP_Session_Tokens::get_instance( get_current_user_id() )->destroy_others( wp_get_session_token() );
			ogc_log( 'signout_others', 0, 'user:' . get_current_user_id() );
			ogc_cookie( 'ogc_flash', 'others', 60, false );
			wp_safe_redirect( home_url( $ret ? $ret : ogc_landing_for( get_current_user_id() ) ), 303 );
			exit;
		}
		ogc_log( 'signout', 0, 'user:' . get_current_user_id() );
		wp_logout();
		wp_safe_redirect( ogc_url( 'signin', array_filter( array( 'out' => 1, 'return' => rawurlencode( $ret ) ) ) ), 303 );
		exit;
	}

	if ( 'POST' === $method ) {
		$post = wp_unslash( $_POST );
		$do   = isset( $post['ogc_do'] ) ? sanitize_key( $post['ogc_do'] ) : '';
		// A link's card sends no Referrer, so its button's POST comes with Origin "null"; that one is
		// checked by its landing cookie instead (a page on another site can't set it). A sandboxed page
		// sends "null" too, so without that cookie it's refused.
		$null = isset( $_SERVER['HTTP_ORIGIN'] ) && 'null' === $_SERVER['HTTP_ORIGIN'] && in_array( $do, array( 'link', 'again', 'hint' ), true ) && ogc_signin_land_ok( $post );
		if ( ! $null && ! ogc_same_origin_strict() ) {
			status_header( 400 );
			ogc_signin_state( array( 'error' => 'Not valid · Try again' ) );
			return;
		}
		$ret = isset( $post['return'] ) ? ogc_safe_return( (string) $post['return'] ) : $ret;
		ogc_signin_state( array( 'return' => $ret ) );
		if ( 'shared' === $do ) {
			// The Shared device switch on Check your email: a setting of this browser, followed by the sign-in
			// the code or link makes here, and by every later one.
			ogc_device_set_shared( ! empty( $post['on'] ) );
			wp_safe_redirect( ogc_url( 'signin', array( 'sent' => 1 ) ), 303 );
			exit;
		}
		if ( 'send' === $do || 'resend' === $do || 'hint' === $do || 'again' === $do ) {
			$shared = ! empty( $post['shared'] );
			if ( 'resend' === $do ) {
				$p     = ogc_signin_pending();
				$email = $p ? $p['email'] : '';
				$ret   = $p ? $p['return_to'] : $ret;
				$shared = $p && ! empty( $p['data']['shared'] );
			} elseif ( 'hint' === $do ) {
				$h     = ogc_token_find( isset( $post['h'] ) ? (string) $post['h'] : '' );
				$email = $h && 'hint' === $h['kind'] && 'expired' !== ogc_token_state( $h ) ? $h['email'] : '';
				$ret   = $h && $h['return_to'] ? $h['return_to'] : $ret;
			} elseif ( 'again' === $do ) {
				// From an expired or used link: a new one to the same address, no typing.
				$t     = ogc_token_find( isset( $post['t'] ) ? (string) $post['t'] : '' );
				$email = $t && ogc_token_signs_in( $t['kind'] ) ? $t['email'] : '';
				$ret   = $t ? $t['return_to'] : $ret;
				// A volunteer's Confirm link already used: the place is confirmed, so Your sign-ups.
				if ( $t && 'used' === ogc_token_state( $t ) && ! empty( $t['data']['vol']['y'] ) ) {
					$ret = wp_make_link_relative( ogc_url( 'register', array( 'view' => 'mine', 'year' => (int) $t['data']['vol']['y'] ) ) );
				}
			} else {
				$email = isset( $post['email'] ) ? ogc_clean_email( $post['email'] ) : '';
			}
			if ( '' === $email ) {
				ogc_signin_state( array( 'state' => 'form', 'error' => 'send' === $do ? 'Enter an email' : 'Enter your email' ) );
				return;
			}
			$r = ogc_signin_request( $email, array( 'return' => $ret, 'shared' => $shared, 'mask' => in_array( $do, array( 'hint', 'again' ), true ) || ( 'resend' === $do && ! empty( $p['data']['mask'] ) ) ) );
			if ( is_wp_error( $r ) ) {
				// Over a limit while a code is already on its way to this address: stay on Check your
				// email, the code field kept, and say when Resend works again.
				$open = ogc_signin_pending();
				if ( 'ogc_rate' === $r->get_error_code() && $open && $open['email'] === $email && 'ok' === ogc_token_state( $open ) ) {
					ogc_signin_flash( array( 'resend' => 'limit' ) );
					wp_safe_redirect( ogc_url( 'signin', array( 'sent' => 1 ) ), 303 );
					exit;
				}
				ogc_signin_state( array( 'state' => 'form', 'email' => $email, 'error' => $r->get_error_message(), 'field' => 'ogc_bad_email' === $r->get_error_code() ) );
				return;
			}
			wp_safe_redirect( ogc_url( 'signin', array( 'sent' => 1 ) ), 303 );
			exit;
		}
		if ( 'code' === $do ) {
			$typed = isset( $post['code'] ) ? substr( preg_replace( '/[^0-9 ]/', '', (string) $post['code'] ), 0, 9 ) : '';
			$go    = ogc_signin_code( $typed );
			if ( is_wp_error( $go ) ) {
				// Post, redirect, get: the error and the digits as typed come back on Check your email,
				// so a reload doesn't spend another try.
				ogc_signin_flash( array( 'code_error' => $go->get_error_message(), 'typed' => $typed ) );
				wp_safe_redirect( ogc_signin_pending() ? ogc_url( 'signin', array( 'sent' => 1 ) ) : ogc_url( 'signin', array( 'gone' => 1 ) ), 303 );
				exit;
			}
			wp_safe_redirect( $go, 303 );
			exit;
		}
		if ( 'ask' === $do && is_user_logged_in() ) {
			// No access: ask the year's COA (or the webmasters when it has none).
			$y = isset( $post['year'] ) ? (int) $post['year'] : 0;
			if ( ogc_valid_year( $y ) && wp_verify_nonce( isset( $post['_wpnonce'] ) ? (string) $post['_wpnonce'] : '', 'ogc_ask_' . $y ) && function_exists( 'ogc_member_ask_access' ) && ogc_member_find( $y, ogc_current_email(), true ) ) {
				ogc_member_ask_access( $y );
			}
			wp_safe_redirect( $ret ? home_url( $ret ) : ogc_url( 'year', array( 'year' => $y ) ), 303 );
			exit;
		}
		if ( 'link' === $do ) {
			// The link's card was shown by this browser (its landing cookie) and the button pressed.
			$k = isset( $post['k'] ) ? (string) $post['k'] : '';
			$c = ogc_cookie_get( 'ogc_land' );
			$t = ogc_token_find( isset( $post['t'] ) ? (string) $post['t'] : '' );
			if ( ! $t || '' === $c || ! hash_equals( $c, $k ) ) {
				ogc_signin_state( array( 'state' => $t ? 'confirm' : 'invalid', 'token' => $t, 'raw' => isset( $post['t'] ) ? (string) $post['t'] : '', 'title' => $t ? ogc_token_word( $t['kind'], 'heading', $t, 'Sign in' ) : 'Link not valid' ) );
				ogc_signin_land_cookie();
				return;
			}
			ogc_cookie( 'ogc_land', '', -3600 );
		ogc_cookie( 'ogc_lt', '', -3600 );
		$st = ogc_token_state( $t );
			if ( 'ok' !== $st ) {
				ogc_signin_link_state( $t, (string) $post['t'] );
				return;
			}
			$kinds = ogc_token_kinds();
			$alt   = ! empty( $post['alt'] ) && isset( $kinds[ $t['kind'] ]['decline']['run'] );
			if ( ogc_token_signs_in( $t['kind'] ) ) {
				$go = ogc_signin_finish( $t, 'link' );
			} elseif ( $alt && ogc_token_spend( $t, get_current_user_id() ) ) {
				// The card's quiet second action (a parent's Decline).
				$go = call_user_func( $kinds[ $t['kind'] ]['decline']['run'], $t );
			} elseif ( isset( $kinds[ $t['kind'] ]['run'] ) && ogc_token_spend( $t, get_current_user_id() ) ) {
				$go = call_user_func( $kinds[ $t['kind'] ]['run'], $t );
			} else {
				$go = new WP_Error( 'ogc_not_valid', 'Link not valid' );
			}
			if ( is_wp_error( $go ) ) {
				ogc_signin_link_state( ogc_token_find( (string) $post['t'] ), (string) $post['t'] );
				return;
			}
			wp_safe_redirect( $go, 303 );
			exit;
		}
		return;
	}

	// GET: a link from an email. Its token goes into a cookie for 15 minutes and the address is made
	// clean (?confirm=1) before anything is drawn: never in the history, a bookmark, or the page address
	// an analytics script reads.
	if ( isset( $get['t'] ) ) {
		$tok = preg_replace( '/[^A-Za-z0-9_-]/', '', (string) $get['t'] );
		ogc_cookie( 'ogc_lt', substr( $tok, 0, 100 ), 15 * MINUTE_IN_SECONDS );
		wp_safe_redirect( ogc_url( 'signin', array( 'confirm' => 1 ) ), 303 );
		exit;
	}
	if ( ! empty( $get['confirm'] ) ) {
		$raw = ogc_cookie_get( 'ogc_lt' );
		$t   = ogc_token_find( $raw );
		if ( ! $t ) {
			ogc_signin_state( array( 'state' => 'invalid', 'title' => 'Link not valid' ) );
			return;
		}
		$st = ogc_token_state( $t );
		// The same link again, on the device it signed in: just carry on.
		if ( 'used' === $st && is_user_logged_in() && (int) $t['used_by'] === get_current_user_id() && ogc_token_signs_in( $t['kind'] ) ) {
			// An area may note it for the page it opens (the volunteer page says what's true of a Confirm
			// link's places now).
			do_action( 'ogc_link_again', $t );
			wp_safe_redirect( home_url( $t['return_to'] ? $t['return_to'] : ogc_landing_for( get_current_user_id() ) ), 303 );
			exit;
		}
		// A link an area says needs no tap here (a volunteer's Confirm opened on the device that made the
		// sign-up, or signed in here as that address): the card posts itself from the page (a GET alone
		// never confirms; a mail scanner has neither this device's cookie nor its sign-in, so it gets the
		// one-tap card). After the fourth critic, Oct 15.
		$auto = 'ok' === $st && ogc_token_signs_in( $t['kind'] ) && (bool) apply_filters( 'ogc_link_auto', false, $t );
		// Already signed in here as this address (an invite opened on a phone that signed in at
		// registration; Confirm it's you's link): the link is spent and a fresh sign-in starts, so a
		// committee page doesn't ask "Confirm it's you" again. No tap: a mail scanner has no sign-in here,
		// so it never gets this far.
		if ( ! $auto && 'ok' === $st && is_user_logged_in() && ogc_token_signs_in( $t['kind'] ) && ogc_current_email() === $t['email'] ) {
			ogc_cookie( 'ogc_lt', '', -3600 );
			$go = ogc_signin_finish( $t, 'link' );
			if ( ! is_wp_error( $go ) ) {
				wp_safe_redirect( $go, 303 );
				exit;
			}
			ogc_signin_link_state( ogc_token_find( $raw ), $raw );
			return;
		}
		if ( 'ok' !== $st ) {
			ogc_signin_link_state( $t, $raw );
			return;
		}
		ogc_signin_land_cookie();
		ogc_signin_state( array( 'state' => 'confirm', 'token' => $t, 'raw' => $raw, 'email' => $t['email'], 'auto' => $auto, 'title' => ogc_token_word( $t['kind'], 'heading', $t, ogc_token_signs_in( $t['kind'] ) ? 'Sign in' : 'Confirm' ) ) );
		return;
	}

	// A confirmation email's "Your sign-ups": signed in here, straight there; if not, one tap sends a link.
	if ( isset( $get['h'] ) ) {
		$h = ogc_token_find( (string) $get['h'] );
		if ( $h && 'hint' === $h['kind'] && is_user_logged_in() ) {
			wp_safe_redirect( home_url( $h['return_to'] ? $h['return_to'] : ogc_landing_for( get_current_user_id() ) ) );
			exit;
		}
		if ( $h && 'hint' === $h['kind'] && 'expired' !== ogc_token_state( $h ) ) {
			ogc_signin_land_cookie();
			ogc_signin_state( array( 'state' => 'hint', 'hint' => (string) $get['h'], 'masked' => ogc_mask_email( $h['email'] ), 'return' => $h['return_to'] ? $h['return_to'] : $ret, 'title' => 'Your sign-ups' ) );
			return;
		}
	}

	if ( ! empty( $get['sent'] ) ) {
		$p = ogc_signin_pending();
		$f = ogc_signin_flash_take();
		if ( $p && 'ok' === ogc_token_state( $p ) ) {
			ogc_signin_state( array(
				'state'      => 'sent',
				'email'      => empty( $p['data']['mask'] ) ? $p['email'] : ogc_mask_email( $p['email'] ),
				'resend_at'  => ogc_signin_next_at( $p['email'] ),
				'limited'    => ! empty( $f['resend'] ),
				'code_error' => isset( $f['code_error'] ) ? (string) $f['code_error'] : '',
				'typed'      => isset( $f['typed'] ) ? (string) $f['typed'] : '',
				// The link was used on another device: this one can still use the code.
				'elsewhere'  => ! empty( $p['data']['elsewhere'] ),
				'shared'     => ogc_device_shared(),
				'title'      => 'Check your email',
			) );
			return;
		}
		if ( isset( $f['code_error'] ) ) {
			ogc_signin_state( array( 'error' => $f['code_error'] ) );
		}
		// Check your email reopened after 30 minutes: the form again, the address filled in.
		if ( $p && 'expired' === ogc_token_state( $p ) ) {
			ogc_signin_state( array( 'email' => empty( $p['data']['mask'] ) ? $p['email'] : '', 'status' => 'Code expired', 'return' => $p['return_to'] ? $p['return_to'] : $ret ) );
		}
	}
	if ( ! empty( $get['gone'] ) ) {
		$f = ogc_signin_flash_take();
		ogc_signin_state( array( 'error' => isset( $f['code_error'] ) ? (string) $f['code_error'] : 'Code expired · Send a new one' ) );
	}

	// Refused by a members' page (core's ogc_page_refuse): say why, plainly.
	if ( ! empty( $GLOBALS['ogc_refused'] ) && is_user_logged_in() ) {
		ogc_signin_refused_state();
		return;
	}

	if ( is_user_logged_in() ) {
		if ( ! empty( $get['choose'] ) && count( ogc_member_years() ) > 1 ) {
			ogc_signin_state( array( 'state' => 'choose', 'title' => 'Choose a year' ) );
			return;
		}
		if ( ! empty( $get['continue'] ) ) {
			wp_safe_redirect( home_url( $ret ? $ret : ogc_landing_for( get_current_user_id() ) ) );
			exit;
		}
		ogc_signin_state( array( 'state' => 'signedin', 'email' => ogc_current_email(), 'title' => 'Signed in' ) );
		return;
	}
	if ( ! empty( $get['out'] ) ) {
		ogc_signin_state( array( 'status' => 'Signed out' ) );
	}
	// phpcs:enable
}

/** What a return page is called, for the sign-in heading: "Your sign-ups", "Members", "Lodging",
 * "Who's signed up · Food", "The schedule"; '' when it has no name of its own (then "Sign in"). */
function ogc_signin_dest_label( $ret ) {
	if ( ! $ret ) {
		return '';
	}
	$q = array();
	wp_parse_str( (string) wp_parse_url( $ret, PHP_URL_QUERY ), $q );
	$k = basename( trim( (string) wp_parse_url( $ret, PHP_URL_PATH ), '/' ) );
	if ( 'register' === $k && isset( $q['view'] ) && in_array( $q['view'], array( 'mine', 'receipt' ), true ) ) {
		return 'Your sign-ups';
	}
	if ( 'members' === $k ) {
		return 'Members';
	}
	if ( 'admin' === $k && isset( $q['role'] ) && 'web' === $q['role'] ) {
		return 'Webmasters';
	}
	return function_exists( 'ogc_member_landing_label' ) ? ogc_member_landing_label( $ret ) : '';
}

/** Is a return address one of the members' pages (the year, Lodging, the lists, Members…)? */
function ogc_return_is_members_page( $ret ) {
	$ret = ogc_safe_return( (string) $ret );
	if ( '' === $ret ) {
		return false;
	}
	$path = trim( (string) wp_parse_url( $ret, PHP_URL_PATH ), '/' );
	foreach ( ogc_pages() as $p ) {
		if ( ! empty( $p['members'] ) && isset( $p['path'] ) && '' !== $p['path'] && trim( wp_make_link_relative( ogc_url( $p['path'] ) ), '/' ) === $path ) {
			return true;
		}
	}
	return false;
}

/** The card for a link that can't be used: expired, used elsewhere, or not one of ours. */
function ogc_signin_link_state( $t, $raw ) {
	if ( ! $t ) {
		ogc_signin_state( array( 'state' => 'invalid', 'title' => 'Link not valid' ) );
		return;
	}
	$st = ogc_token_state( $t );
	$s  = 'used' === $st ? 'used' : ( 'expired' === $st ? 'expired' : 'invalid' );
	// Its "Send new code" button posts back with this (a page on another site can't set it).
	ogc_signin_land_cookie();
	// A confirmation email's Your sign-ups link, used or old: one tap sends a code to the same address.
	// So does a volunteer's Confirm link opened again weeks later (a first-timer's only email): the
	// place is confirmed, so the code opens Your sign-ups (after the second critic, Oct 15).
	if ( 'invalid' !== $s && ( ! empty( $t['data']['mine'] ) || ( 'used' === $s && ! empty( $t['data']['vol'] ) ) ) ) {
		// Already signed in here as that address: straight there, no code.
		if ( is_user_logged_in() && ogc_current_email() === $t['email'] && ! headers_sent() ) {
			wp_safe_redirect( home_url( ! empty( $t['data']['vol']['y'] ) ? wp_make_link_relative( ogc_url( 'register', array( 'view' => 'mine', 'year' => (int) $t['data']['vol']['y'] ) ) ) : ( $t['return_to'] ? $t['return_to'] : ogc_landing_for( get_current_user_id() ) ) ), 303 );
			exit;
		}
		// Why a code (after the third critic, Oct 15: the card had no words, only the button): the link was
		// used, or ran out.
		// What the link was for, when that's safe to say to anyone holding it (a volunteer's Confirm: the
		// shift, never who's on it; after the fifth critic, Oct 15). Filter ogc_link_what.
		// A volunteer's used Confirm link says what's true of its places, on any device, as the same email's
		// Leave link does (after the sixth critic, Oct 15: "Edna left · Harold is still on it"); the code is
		// only for signing in. Filter ogc_link_truth.
		$truth = 'used' === $s ? apply_filters( 'ogc_link_truth', null, $t ) : null;
		ogc_signin_state( array( 'state' => 'hint', 'again' => true, 'raw' => $raw, 'masked' => ogc_mask_email( $t['email'] ), 'title' => 'Your sign-ups', 'why' => $s, 'truth' => $truth, 'what' => $truth ? array() : array_values( array_filter( array_map( 'strval', (array) apply_filters( 'ogc_link_what', array(), $t ) ) ) ) ) );
		return;
	}
	ogc_signin_state( array(
		'state'  => $s,
		'masked' => ogc_mask_email( $t['email'] ),
		'raw'    => $raw,
		'again'  => ogc_token_signs_in( $t['kind'] ),
		'kind'   => $t['kind'],
		'title'  => array( 'used' => 'Link already used', 'expired' => 'Link expired', 'invalid' => 'Link not valid' )[ $s ],
	) );
}

/** A short note for the next page this browser opens (an error after a POST, then a redirect). Kept on
 * the server for two minutes under a random cookie; never in the address. */
function ogc_signin_flash( $data ) {
	$k = ogc_random_token();
	ogc_cookie( 'ogc_sf', $k, 120 );
	set_transient( 'ogc_sf_' . substr( ogc_auth_hash( 'f|' . $k ), 0, 32 ), (array) $data, 120 );
}

function ogc_signin_flash_take() {
	$k = ogc_cookie_get( 'ogc_sf' );
	if ( ! $k ) {
		return array();
	}
	$t = 'ogc_sf_' . substr( ogc_auth_hash( 'f|' . $k ), 0, 32 );
	$v = get_transient( $t );
	delete_transient( $t );
	ogc_cookie( 'ogc_sf', '', -3600 );
	return is_array( $v ) ? $v : array();
}

/** The landing cookie came back with the form's own copy of it ('k'). */
function ogc_signin_land_ok( $post ) {
	$c = ogc_cookie_get( 'ogc_land' );
	$k = isset( $post['k'] ) ? (string) $post['k'] : '';
	return '' !== $c && '' !== $k && hash_equals( $c, $k );
}

/** A cookie the link's card sets, sent back with its button (a page on another site can't). */
function ogc_signin_land_cookie() {
	$k = ogc_random_token();
	ogc_cookie( 'ogc_land', $k, 15 * MINUTE_IN_SECONDS );
	ogc_signin_state( array( 'land' => $k ) );
}

/** Signed in, but this page isn't theirs: what's true (access ended on a date, removed, a code to
 * confirm after 30 days), and where they can go. */
function ogc_signin_refused_state() {
	// phpcs:ignore WordPress.Security.NonceVerification -- which year was asked for.
	$y     = isset( $_GET['year'] ) ? (int) $_GET['year'] : 0;
	$email = ogc_current_email();
	if ( ! empty( $GLOBALS['ogc_reauth'] ) ) {
		ogc_signin_state( array( 'state' => 'reauth', 'email' => $email, 'title' => 'Confirm it’s you', 'return' => ogc_safe_return( isset( $_SERVER['REQUEST_URI'] ) ? esc_url_raw( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : '' ) ) );
		return;
	}
	$why = '';
	if ( function_exists( 'ogc_member_find' ) && ogc_valid_year( $y ) ) {
		$m = ogc_member_find( $y, $email, true );
		if ( $m && $m['removed_at'] ) {
			$why = 'Removed ' . ogc_member_date( $m['removed_at'] );
		} elseif ( $m ) {
			$x   = ogc_member_expiry( $m );
			$why = $x ? 'Access ended ' . ogc_member_date( $x ) : '';
		}
	}
	$asked = ogc_valid_year( $y ) ? (int) get_user_meta( get_current_user_id(), 'ogc_asked_' . $y, true ) : 0;
	// Ask for access only for someone who had it (removed or ended): anyone else following a stray
	// committee link would email every COA member.
	ogc_signin_state( array( 'state' => 'refused', 'email' => $email, 'year' => $y, 'why' => $why, 'can_ask' => '' !== $why, 'asked' => $asked > time() - DAY_IN_SECONDS ? $asked : 0, 'title' => 'No access' ) );
}

/* ================================================================== REST: signing in from any page */

add_action( 'rest_api_init', function () {
	// From any page (the guide's My room, a volunteer sheet): send a link and code, then type the code.
	register_rest_route( OGC_NS, '/auth/send', array(
		'methods'             => 'POST',
		'callback'            => function ( WP_REST_Request $req ) {
			if ( ! ogc_same_origin_strict() ) {
				return new WP_Error( 'ogc_origin', 'Not valid.', array( 'status' => 400 ) );
			}
			// for = register: the registration form's code (an address the site may not know yet; no link).
			$for = 'register' === $req->get_param( 'for' ) ? 'register' : '';
			$r   = ogc_signin_request( (string) $req->get_param( 'email' ), array( 'return' => (string) $req->get_param( 'return' ), 'shared' => (bool) $req->get_param( 'shared' ), 'for' => $for, 'typos_ok' => (bool) $req->get_param( 'typos_ok' ) ) );
			if ( is_wp_error( $r ) ) {
				$d = $r->get_error_data();
				return new WP_Error( $r->get_error_code(), $r->get_error_message(), array( 'status' => isset( $d['status'] ) ? $d['status'] : 400, 'until' => isset( $d['until'] ) ? $d['until'] : null, 'fix' => isset( $d['fix'] ) ? $d['fix'] : null ) );
			}
			$out = array( 'sent' => true, 'email' => $r['email'] );
			if ( $for ) {
				$out['next'] = $r['next'];
				if ( isset( $r['dev_code'] ) ) {
					$out['dev_code'] = $r['dev_code'];
				}
			}
			return rest_ensure_response( $out );
		},
		'permission_callback' => '__return_true',
	) );
	register_rest_route( OGC_NS, '/auth/code', array(
		'methods'             => 'POST',
		'callback'            => function ( WP_REST_Request $req ) {
			if ( ! ogc_same_origin_strict() ) {
				return new WP_Error( 'ogc_origin', 'Not valid.', array( 'status' => 400 ) );
			}
			// The new session's cookie is needed in this same request, for the nonce the page carries on with
			// (Confirm it's you over an open page: its unsaved changes go on with the new nonce).
			$grab = function ( $cookie ) {
				$_COOKIE[ LOGGED_IN_COOKIE ] = $cookie;
			};
			add_action( 'set_logged_in_cookie', $grab );
			$go = ogc_signin_code( (string) $req->get_param( 'code' ) );
			remove_action( 'set_logged_in_cookie', $grab );
			if ( is_wp_error( $go ) ) {
				return $go;
			}
			return rest_ensure_response( array( 'ok' => true, 'go' => wp_make_link_relative( $go ), 'nonce' => wp_create_nonce( 'wp_rest' ) ) );
		},
		'permission_callback' => '__return_true',
	) );
} );

// A members' route refused because this browser's sign-in is older than 30 days (ogc_is_member set
// ogc_reauth): 401 ogc_reauth, not 403, so the page can ask for a code over itself and carry on
// (ogc-account.js; OGC_WP.api retries once it's confirmed). Nothing unsaved is lost.
add_filter( 'rest_request_after_callbacks', function ( $response ) {
	if ( empty( $GLOBALS['ogc_reauth'] ) || ! is_wp_error( $response ) || ! is_user_logged_in() ) {
		return $response;
	}
	$d = $response->get_error_data();
	$s = is_array( $d ) && isset( $d['status'] ) ? (int) $d['status'] : 0;
	if ( 403 !== $s && 404 !== $s ) {
		return $response;
	}
	return new WP_Error( 'ogc_reauth', 'Confirm it’s you', array( 'status' => 401, 'email' => ogc_mask_email( ogc_current_email() ) ) );
}, 5 );

/* ================================================================== a device's own records */

/** This browser's device id (hashed), made when asked. */
function ogc_device_hash( $create = false ) {
	$d = ogc_cookie_get( 'ogc_device' );
	if ( ! $d && $create ) {
		$d = ogc_random_token();
		ogc_cookie( 'ogc_device', $d, 400 * DAY_IN_SECONDS );
	}
	return $d ? ogc_auth_hash( 'd|' . $d ) : '';
}

function ogc_device_has( $record_id ) {
	global $wpdb;
	$h = ogc_device_hash();
	return $h && (bool) $wpdb->get_var( $wpdb->prepare( 'SELECT 1 FROM ' . ogc_table( 'devices' ) . ' WHERE dhash = %s AND record_id = %d', $h, $record_id ) );
}

/** The kinds a visitor who typed an email (not yet confirmed) may make. */
function ogc_anon_kinds() {
	return (array) apply_filters( 'ogc_anon_kinds', array( 'signups', 'waits', 'registrations' ) );
}

/** Records reached through another email (helper, parent), for the signed-in person. */
function ogc_linked_records( $year, $kind, $email ) {
	global $wpdb;
	if ( ! $email ) {
		return array();
	}
	$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT r.* FROM ' . ogc_table( 'records' ) . ' r JOIN ' . ogc_table( 'record_links' ) . ' l ON l.record_id = r.id WHERE l.email = %s AND r.year = %d AND r.kind = %s AND r.deleted_at IS NULL', $email, $year, $kind ), ARRAY_A );
	return array_map( 'ogc_record_row', (array) $rows );
}

/** Link a record to a second email: helper (may change it) or parent (may see it). */
function ogc_record_link_add( $record_id, $email, $why = 'helper' ) {
	global $wpdb;
	$email = ogc_clean_email( $email );
	if ( ! is_email( $email ) || ! in_array( $why, array( 'helper', 'parent' ), true ) ) {
		return false;
	}
	if ( $wpdb->get_var( $wpdb->prepare( 'SELECT 1 FROM ' . ogc_table( 'record_links' ) . ' WHERE record_id = %d AND email = %s', $record_id, $email ) ) ) {
		return true;
	}
	return (bool) $wpdb->insert( ogc_table( 'record_links' ), array( 'record_id' => (int) $record_id, 'email' => $email, 'why' => $why, 'created_at' => ogc_now() ) );
}

function ogc_record_link_why( $record_id, $email ) {
	global $wpdb;
	return $email ? (string) $wpdb->get_var( $wpdb->prepare( 'SELECT why FROM ' . ogc_table( 'record_links' ) . ' WHERE record_id = %d AND email = %s', $record_id, $email ) ) : '';
}

// "Mine" also means: made on this device before the email was confirmed, or linked to my email.
add_filter( 'ogc_records_mine', function ( $list, $year, $kind ) {
	global $wpdb;
	$ids = wp_list_pluck( $list, 'id' );
	foreach ( ogc_linked_records( $year, $kind, ogc_current_email() ) as $r ) {
		if ( ! in_array( $r['id'], $ids, true ) ) {
			$list[] = $r;
			$ids[]  = $r['id'];
		}
	}
	$h = ogc_device_hash();
	if ( $h ) {
		$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT r.* FROM ' . ogc_table( 'records' ) . ' r JOIN ' . ogc_table( 'devices' ) . ' d ON d.record_id = r.id WHERE d.dhash = %s AND r.year = %d AND r.kind = %s AND r.deleted_at IS NULL', $h, $year, $kind ), ARRAY_A );
		foreach ( array_map( 'ogc_record_row', (array) $rows ) as $r ) {
			if ( ! in_array( $r['id'], $ids, true ) ) {
				$list[] = $r;
				$ids[]  = $r['id'];
			}
		}
	}
	return $list;
}, 10, 3 );

/** The ids this browser may treat as its own beyond its email: made on this device, or linked to the
 * signed-in email (one query each per request). */
function ogc_auth_own_ids() {
	static $ids = null;
	global $wpdb;
	if ( null !== $ids ) {
		return $ids;
	}
	$ids = array();
	$h   = ogc_device_hash();
	if ( $h ) {
		foreach ( (array) $wpdb->get_col( $wpdb->prepare( 'SELECT record_id FROM ' . ogc_table( 'devices' ) . ' WHERE dhash = %s', $h ) ) as $id ) {
			$ids[ (int) $id ] = 'device';
		}
	}
	$me = ogc_current_email();
	if ( $me ) {
		foreach ( (array) $wpdb->get_results( $wpdb->prepare( 'SELECT record_id, why FROM ' . ogc_table( 'record_links' ) . ' WHERE email = %s', $me ), ARRAY_A ) as $r ) {
			$ids[ (int) $r['record_id'] ] = $r['why'];
		}
	}
	return $ids;
}

add_filter( 'ogc_record_is_mine', function ( $mine, $rec ) {
	if ( $mine ) {
		return true;
	}
	$ids = ogc_auth_own_ids();
	return isset( $ids[ (int) $rec['id'] ] );
}, 10, 2 );

// A visitor who typed an email may make a sign-up, a waitlist place or a registration (it's labelled
// with that email, unconfirmed), and may change or leave what this device made. A helper may change
// what they registered for someone else; a parent may only see.
add_filter( 'ogc_record_can_write', function ( $allowed, $action, $kind, $year, $record, $data, $req ) {
	if ( $allowed ) {
		return true;
	}
	if ( is_user_logged_in() ) {
		if ( $record && 'create' !== $action && 'helper' === ogc_record_link_why( $record['id'], ogc_current_email() ) ) {
			$owner = null === $data ? $record['email'] : ogc_record_owner( $kind, $data, $year );
			return '' === $owner || $owner === $record['email'];
		}
		return false;
	}
	if ( 'create' === $action ) {
		if ( ! in_array( $kind, ogc_anon_kinds(), true ) || ! is_email( ogc_record_owner( $kind, (array) $data, $year ) ) ) {
			return false;
		}
		// A ceiling per IP, high for the campus Wi-Fi (the volunteer area holds each place until confirmed).
		return 0 === ogc_throttle( 'ac:' . ogc_client_ip(), max( 30, (int) apply_filters( 'ogc_anon_creates_per_hour', 300 ) ), HOUR_IN_SECONDS );
	}
	if ( $record && ogc_device_has( $record['id'] ) ) {
		$owner = null === $data ? $record['email'] : ogc_record_owner( $kind, $data, $year );
		return $owner === $record['email'];
	}
	return false;
}, 20, 7 );

add_action( 'ogc_record_saved', function ( $rec, $action, $req ) {
	global $wpdb;
	if ( 'create' !== $action || ! $rec ) {
		return;
	}
	if ( ! is_user_logged_in() ) {
		$h = ogc_device_hash( true );
		$wpdb->insert( ogc_table( 'devices' ), array( 'dhash' => $h, 'record_id' => (int) $rec['id'], 'created_at' => ogc_now() ) );
		return;
	}
	// Registered for someone else: the helper keeps a way to it.
	$me = ogc_current_email();
	if ( $me && $rec['email'] && $rec['email'] !== $me && 'registrations' === $rec['kind'] && ! ogc_is_member( $rec['year'] ) ) {
		ogc_record_link_add( $rec['id'], $me, 'helper' );
	}
}, 5, 3 );

/** Has this address ever signed in (a link or a code)? Lists mark the rest "Email not confirmed". */
function ogc_email_confirmed( $email ) {
	$u = get_user_by( 'email', ogc_clean_email( $email ) );
	return $u && (bool) get_user_meta( $u->ID, 'ogc_confirmed_at', true );
}

/** A confirmation email's "Your sign-ups" link: one tap and the card's button sign in, once, within 7
 * days (already signed in on that device, it just opens the page). Used or old, it becomes "Your
 * sign-ups · Send code to r***h@example.com". Older emails' ?h= links still work (the hint card). */
function ogc_mine_url( $email, $year = 0 ) {
	$ret = wp_make_link_relative( ogc_url( 'register', array_filter( array( 'view' => 'mine', 'year' => $year ? (int) $year : null ) ) ) );
	$t   = ogc_token_create( 'confirm', $email, array( 'ttl' => OGC_LINK_TTL, 'return' => $ret, 'data' => array( 'mine' => true ) ) );
	return $t['url'];
}

/* ================================================================== keeping it small */

add_action( 'ogc_daily', function () {
	global $wpdb;
	// Expired links and codes go after a day; device links after 400 days.
	$wpdb->query( $wpdb->prepare( 'DELETE FROM ' . ogc_table( 'tokens' ) . ' WHERE expires_at < %s', gmdate( 'Y-m-d H:i:s', time() - DAY_IN_SECONDS ) ) );
	$wpdb->query( $wpdb->prepare( 'DELETE FROM ' . ogc_table( 'devices' ) . ' WHERE created_at < %s', gmdate( 'Y-m-d H:i:s', time() - 400 * DAY_IN_SECONDS ) ) );
	// The limits look back a day at most.
	$wpdb->query( $wpdb->prepare( 'DELETE FROM ' . ogc_table( 'hits' ) . ' WHERE at < %d', time() - 2 * DAY_IN_SECONDS ) );
} );
