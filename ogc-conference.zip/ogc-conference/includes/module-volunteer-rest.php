<?php
/**
 * Volunteer shifts: the public page's routes, /wp-json/ogc/v1/vol/{year}/…
 *
 *   GET  vol/{y}          what this viewer may see now: each shift's count and who ("Ruth K." or a
 *                         blank mark), their own sign-ups and waits, their household, last year's
 *                         shifts again, and a fresh nonce. Never cached (counts, "you", the nonce).
 *   POST vol/{y}/join     take places (one or several shifts; one or several people, all or none)
 *   POST vol/{y}/undo     take back a sign-up made a moment ago (no email goes)
 *   POST vol/{y}/leave    leave a shift (per person); the person, the people waiting and the head hear
 *   POST vol/{y}/wait     join a full shift's waitlist;  vol/{y}/unwait  leave it
 *   POST vol/{y}/swap     find a replacement (the place stays yours until someone takes it)
 *   POST vol/{y}/take     take a place offered for a swap, at once
 *   POST vol/{y}/me       show my name or not; email me when next year's sign-ups open
 *   POST vol/{y}/link     an emailed link: confirm, not me, leave, a place opened, sign up again
 *   POST vol/{y}/notify   email me when sign-ups open
 *
 * Someone who isn't signed in may join with their name, email and phone: nothing signs them in. The
 * place is held, their name doesn't show until they open the emailed link, and this device gets a
 * short-lived hold for just those sign-ups (Leave, Add to calendar). Every change needs the wp_rest
 * nonce (for a visitor too) and is logged without personal data.
 */

defined( 'ABSPATH' ) || exit;

add_action( 'rest_api_init', function () {
	$Y = '/vol/(?P<year>\d{4})';
	register_rest_route( OGC_NS, $Y, array( 'methods' => 'GET', 'callback' => 'ogc_vol_rest_live', 'permission_callback' => 'ogc_vol_can_read' ) );
	foreach ( array( 'join', 'undo', 'leave', 'wait', 'unwait', 'swap', 'take', 'me', 'link', 'notify', 'forget', 'resend', 'email' ) as $a ) {
		register_rest_route( OGC_NS, "$Y/$a", array( 'methods' => 'POST', 'callback' => 'ogc_vol_rest_' . $a, 'permission_callback' => 'ogc_vol_can_post' ) );
	}
} );

function ogc_vol_can_read( WP_REST_Request $req ) {
	return ogc_valid_year( $req['year'] ) && null !== ogc_year_get( (int) $req['year'] );
}

/** Every change needs the wp_rest nonce, a visitor's too (it comes fresh with each GET vol/{y}). */
function ogc_vol_can_post( WP_REST_Request $req ) {
	if ( ! ogc_vol_can_read( $req ) ) {
		return new WP_Error( 'ogc_not_found', 'Not found.', array( 'status' => 404 ) );
	}
	if ( ! wp_verify_nonce( (string) $req->get_header( 'X-WP-Nonce' ), 'wp_rest' ) ) {
		return new WP_Error( 'ogc_nonce', 'Reload the page.', array( 'status' => 403, 'why' => 'nonce' ) );
	}
	return true;
}

/** No page cache may keep these answers (WP Rocket on the real site: Corey's README excludes the path). */
add_filter( 'rest_post_dispatch', function ( $res, $server, $req ) {
	if ( 0 === strpos( (string) $req->get_route(), '/' . OGC_NS . '/vol/' ) && $res instanceof WP_REST_Response ) {
		$res->header( 'Cache-Control', 'no-store, private' );
	}
	return $res;
}, 10, 3 );

/* ================================================================== links and holds */

/**
 * A link's token: 32 random bytes, kept only as a hash in the signin area's tokens table (kind vol_<act>),
 * with what it lets someone do (the year, the sign-ups or shifts) beside it. Nothing in the token says
 * who or what: an address bar, a history, a server log or a screenshot shows a meaningless string.
 */
function ogc_vol_token( $payload, $ttl ) {
	if ( ! function_exists( 'ogc_token_create' ) ) {
		return '';
	}
	$act = substr( preg_replace( '/[^a-z]/', '', (string) ( isset( $payload['a'] ) ? $payload['a'] : 'x' ) ), 0, 12 );
	$e   = isset( $payload['e'] ) ? (string) $payload['e'] : '';
	unset( $payload['a'], $payload['e'], $payload['x'] );
	$t = ogc_token_create( 'vol_' . $act, $e, array( 'ttl' => max( 60, (int) $ttl ), 'data' => $payload ) );
	return $t['token'];
}

/** The token's payload (a, y, e and its data), or null when it's unknown, used or has run out. */
function ogc_vol_untoken( $t ) {
	$t = (string) $t;
	if ( ! function_exists( 'ogc_token_find' ) || ! preg_match( '/^[A-Za-z0-9_-]{20,100}$/', $t ) ) {
		return null;
	}
	$row = ogc_token_find( $t );
	if ( ! $row || 0 !== strpos( (string) $row['kind'], 'vol_' ) || ! empty( $row['used_at'] ) || strtotime( $row['expires_at'] . ' UTC' ) < time() ) {
		return null;
	}
	$p        = (array) $row['data'];
	$p['a']   = substr( $row['kind'], 4 );
	$p['e']   = (string) $row['email'];
	$p['_id'] = (int) $row['id'];
	return $p;
}

/** The emailed link this request acts by: its token sent with it, or (asked for with link: 1) the one
 * the page's address handed to this browser's short cookie. */
function ogc_vol_link_of( WP_REST_Request $req ) {
	$t = (string) $req->get_param( 't' );
	if ( '' === $t && $req->get_param( 'link' ) && isset( $_COOKIE['ogc_vlt'] ) ) {
		$t = sanitize_text_field( wp_unslash( $_COOKIE['ogc_vlt'] ) );
	}
	return '' === $t ? null : ogc_vol_untoken( $t );
}

// An emailed link (/volunteer/?year=2027&t=…): the token goes into a 30-minute cookie and the page
// opens at a clean address (?link=1), so it's never in the address bar, a bookmark or a history.
add_action( 'ogc_before_page', function ( $page ) {
	if ( 'volunteer' !== $page || ! isset( $_GET['t'] ) ) { // phpcs:ignore -- a link's token, checked by its hash later.
		return;
	}
	$tok = substr( preg_replace( '/[^A-Za-z0-9_-]/', '', (string) wp_unslash( $_GET['t'] ) ), 0, 100 ); // phpcs:ignore
	if ( ! headers_sent() ) {
		setcookie( 'ogc_vlt', $tok, array( 'expires' => time() + 30 * MINUTE_IN_SECONDS, 'path' => COOKIEPATH ? COOKIEPATH : '/', 'domain' => COOKIE_DOMAIN ? COOKIE_DOMAIN : '', 'secure' => is_ssl(), 'httponly' => true, 'samesite' => 'Lax' ) );
	}
	$args = array();
	foreach ( array( 'year', 'shift', 'committee' ) as $k ) {
		if ( isset( $_GET[ $k ] ) ) { // phpcs:ignore
			$args[ $k ] = sanitize_text_field( wp_unslash( $_GET[ $k ] ) ); // phpcs:ignore
		}
	}
	$args['link'] = 1;
	nocache_headers();
	wp_safe_redirect( ogc_vol_url( 'volunteer', $args ), 303 );
	exit;
}, 1 );

/** Who is acting: the signed-in person, or a visitor whose device holds sign-ups it just made. */
function ogc_vol_actor( WP_REST_Request $req ) {
	$email = ogc_current_email();
	$holds = array();
	foreach ( array_slice( array_filter( explode( ',', (string) $req->get_header( 'X-OGC-Hold' ) ) ), 0, 20 ) as $t ) {
		$p = ogc_vol_untoken( trim( $t ) );
		if ( $p && 'hold' === $p['a'] && (int) $p['y'] === (int) $req['year'] ) {
			foreach ( (array) $p['r'] as $id ) {
				$holds[ (int) $id ] = strtolower( (string) $p['e'] );
			}
		}
	}
	return array( 'email' => $email, 'signed' => '' !== $email, 'holds' => $holds );
}

/** May this actor change this record (theirs by email, or held on this device)? */
function ogc_vol_owns( $actor, $rec ) {
	if ( $actor['signed'] && $rec['email'] === $actor['email'] ) {
		return true;
	}
	if ( isset( $actor['holds'][ (int) $rec['id'] ] ) && $actor['holds'][ (int) $rec['id'] ] === $rec['email'] ) {
		return true;
	}
	// This device made it (the signin area's device link): only while it's unconfirmed and less than a
	// week old. A confirmed place, or an old one, needs a sign-in (a shared tablet or office computer
	// mustn't show last month's visitor).
	return ! $actor['signed'] && empty( $rec['data']['confirmed'] ) && strtotime( $rec['created_at'] . ' UTC' ) > ogc_vol_now() - 7 * DAY_IN_SECONDS
		&& function_exists( 'ogc_device_has' ) && ogc_device_has( (int) $rec['id'] );
}

/** A few tries an hour from one address, or for one email. */
function ogc_vol_rate( $what, $max, $window = HOUR_IN_SECONDS ) {
	$k = 'ogc_vol_rl_' . md5( $what );
	$n = (int) get_transient( $k );
	if ( $n >= $max ) {
		return false;
	}
	set_transient( $k, $n + 1, $window );
	return true;
}

function ogc_vol_ip() {
	return isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
}

/** A refusal the page shows at the action: why (a word the page knows) and what more it needs. */
function ogc_vol_no( $why, $msg, $extra = array(), $status = 409 ) {
	return new WP_Error( 'ogc_vol_' . $why, $msg, array_merge( array( 'status' => $status, 'why' => $why ), $extra ) );
}

/** The sign-ups a Confirm link names, marked confirmed (their names may show). */
function ogc_vol_confirm_records( $year, $email, $ids ) {
	$n = 0;
	foreach ( array_map( 'intval', (array) $ids ) as $id ) {
		$r = ogc_record_get( $id );
		if ( $r && 'signups' === $r['kind'] && (int) $r['year'] === (int) $year && $r['email'] === strtolower( $email ) ) {
			if ( empty( $r['data']['confirmed'] ) ) {
				$d              = $r['data'];
				$d['confirmed'] = true;
				ogc_record_update( $r['id'], $d, $r['email'] );
			}
			$n++;
		}
	}
	return $n;
}

// The signin area's single-use Confirm link (ogc_vol_confirm_link) has just signed this email in.
add_action( 'ogc_signed_in', function ( $user_id, $row ) {
	if ( empty( $row['data']['vol'] ) || empty( $row['email'] ) ) {
		return;
	}
	$v = (array) $row['data']['vol'];
	$n = ogc_vol_confirm_records( (int) $v['y'], $row['email'], isset( $v['r'] ) ? $v['r'] : array() );
	// The first confirm: the name typed with the sign-up becomes theirs ("Grace T. · Not you?").
	if ( $user_id && function_exists( 'ogc_person_name' ) && '' === ogc_person_name( $user_id ) && function_exists( 'ogc_person_set_name' ) ) {
		foreach ( array_map( 'intval', isset( $v['r'] ) ? (array) $v['r'] : array() ) as $id ) {
			$r = ogc_record_get( $id );
			if ( $r && $r['email'] === $row['email'] && empty( $r['data']['for'] ) && 'self' === ( isset( $r['data']['by'] ) ? $r['data']['by'] : 'self' ) && false !== strpos( trim( (string) $r['data']['name'] ), ' ' ) ) {
				ogc_person_set_name( $user_id, $r['data']['name'] );
				break;
			}
		}
	}
	ogc_log( 'vol_confirm', (int) $v['y'], 'signups', array( 'n' => $n, 'signin' => 1 ) );
}, 10, 2 );

// The Confirm email's link opens the signin area's card: for a volunteer's places it says Confirm (the
// email's word) over the shift, never "Sign in"; any other confirm link keeps its own words.
add_filter( 'ogc_token_kinds', function ( $kinds ) {
	$prev = isset( $kinds['confirm'] ) ? $kinds['confirm'] : array();
	$word = function ( $what, $row, $def ) use ( $prev ) {
		if ( isset( $prev[ $what ] ) ) {
			return $prev[ $what ] instanceof Closure ? call_user_func( $prev[ $what ], $row ) : $prev[ $what ];
		}
		return $def;
	};
	$items = function ( $row ) {
		$v = isset( $row['data']['vol'] ) ? (array) $row['data']['vol'] : array();
		if ( empty( $v['y'] ) ) {
			return array();
		}
		$shifts = ogc_vol_shifts( (int) $v['y'] );
		$out    = array();
		foreach ( array_map( 'intval', isset( $v['r'] ) ? (array) $v['r'] : array() ) as $id ) {
			$r = ogc_record_get( $id );
			if ( $r && $r['email'] === $row['email'] && isset( $shifts[ $r['data']['id'] ] ) ) {
				$out[] = $shifts[ $r['data']['id'] ];
			}
		}
		return $out;
	};
	$kinds['confirm'] = array_merge( $prev, array(
		'heading' => function ( $row ) use ( $items, $word ) {
			$xs = $items( $row );
			if ( ! $xs ) {
				return $word( 'heading', $row, 'Sign in' );
			}
			return 1 === count( $xs ) ? $xs[0]['role'] . ' · ' . ogc_vol_subject_day( (int) $row['data']['vol']['y'], $xs[0] ) : 'Confirm · ' . count( $xs ) . ' shifts';
		},
		'button'  => function ( $row ) use ( $items, $word ) {
			return $items( $row ) ? 'Confirm' : $word( 'button', $row, 'Sign in' );
		},
		'facts'   => function ( $row ) use ( $items, $word, $prev ) {
			$xs = $items( $row );
			if ( ! $xs ) {
				return isset( $prev['facts'] ) ? call_user_func( $prev['facts'], $row ) : array();
			}
			$y = (int) $row['data']['vol']['y'];
			if ( 1 === count( $xs ) ) {
				return array_values( array_filter( array( array( 'When', ogc_vol_when( $y, $xs[0] ) ), $xs[0]['place_name'] ? array( 'Where', $xs[0]['place_name'] ) : null ) ) );
			}
			return array_map( function ( $sh ) use ( $y ) {
				return array( ogc_vol_subject_day( $y, $sh ), $sh['role'] . ' · ' . ogc_vol_span( $sh['start'], $sh['end'] ) );
			}, $xs );
		},
	) );
	return $kinds;
}, 20 );

/* ================================================================== what the viewer sees */

/** Each shift as anyone may see it, with "you" for this actor's own. */
function ogc_vol_public_shifts( $year, $actor ) {
	$map    = ogc_vol_seat_map( $year );
	$waits  = array();
	foreach ( ogc_records( $year, 'waits' ) as $w ) {
		$id            = isset( $w['data']['id'] ) ? $w['data']['id'] : '';
		$waits[ $id ] = ( isset( $waits[ $id ] ) ? $waits[ $id ] : 0 ) + 1;
	}
	// Once the Conference is over, only how many helped: no names (samples too, so the walk-through
	// draws a past year as a real one looks after its names are cleared), and after the clearing the
	// counts kept for next year's committee.
	$closed = ogc_vol_closed( $year );
	$stats  = ogc_state_get( $year, 'vol-cleared' ) ? ogc_state_get( $year, 'vol-stats' ) : null;
	$stats  = $stats ? (array) $stats['value'] : array();
	$out    = array();
	foreach ( ogc_vol_shifts( $year ) as $id => $sh ) {
		$seats  = isset( $map[ $id ] ) ? $map[ $id ] : array();
		$filled = isset( $stats[ $id ]['filled'] ) ? max( count( $seats ), (int) $stats[ $id ]['filled'] ) : count( $seats );
		$s      = array();
		foreach ( $closed ? array() : $seats as $seat ) {
			$rec = $seat['record'];
			$ok  = ogc_vol_label_ok( $year, $rec );
			$s[] = array(
				$ok ? ogc_vol_first_l( $rec['data']['name'] ) : null,
				$ok ? ogc_vol_initials( $rec['data']['name'] ) : null,
				ogc_vol_owns( $actor, $rec ) ? 1 : 0,
				! empty( $rec['data']['swap'] ) ? (int) $rec['id'] : 0,
				// Your own household's are named to you (Esther, even while hidden from the public).
				ogc_vol_owns( $actor, $rec ) ? (string) $rec['data']['name'] : null,
			);
		}
		$out[ $id ] = array(
			'f'  => $filled,
			'o'  => $sh['unlimited'] ? null : max( 0, $sh['needed'] - $filled ),
			'w'  => isset( $waits[ $id ] ) ? $waits[ $id ] : 0,
			'st' => ogc_vol_shift_state( $year, $sh, $filled ),
			's'  => $s,
		);
	}
	return $out;
}

/** A sign-up as its owner sees it. */
function ogc_vol_mine_out( $rec ) {
	$d = $rec['data'];
	return array(
		'rid'       => (int) $rec['id'],
		'shift'     => isset( $d['id'] ) ? $d['id'] : '',
		'name'      => isset( $d['name'] ) ? $d['name'] : '',
		'confirmed' => ! empty( $d['confirmed'] ),
		'hide'      => ! empty( $d['hide'] ),
		// Signed up by someone else in the household: shown publicly only once switched on.
		'for'       => ! empty( $d['for'] ),
		'shown'     => ! empty( $d['show'] ),
		'swap'      => ! empty( $d['swap'] ) ? (int) $rec['id'] . '.' . $d['swap'] : '',
		'at'        => $rec['created_at'],
		'by'        => isset( $d['by'] ) ? $d['by'] : 'self',
		'answer'    => isset( $d['rule']['answer'] ) ? $d['rule']['answer'] : '',
	);
}

/** This actor's sign-ups and waits for the year. */
function ogc_vol_mine( $year, $actor, $kind = 'signups' ) {
	$out = array();
	foreach ( ogc_records( $year, $kind ) as $r ) {
		if ( ogc_vol_owns( $actor, $r ) ) {
			$out[] = 'signups' === $kind ? ogc_vol_mine_out( $r ) : array( 'rid' => (int) $r['id'], 'shift' => isset( $r['data']['id'] ) ? $r['data']['id'] : '', 'name' => isset( $r['data']['name'] ) ? $r['data']['name'] : '' );
		}
	}
	return $out;
}

/** The household as the registration knows it: each person who may help (12 and up, or a Young Folk),
 * how old as far as it says, and the days each is here. */
function ogc_vol_household( $year, $email ) {
	$reg = ogc_vol_registration( $year, $email );
	if ( ! $reg || empty( $reg['people'] ) ) {
		return null;
	}
	$days  = ogc_vol_days( $year );
	$names = array_column( $days, 'name' );
	$out   = array();
	foreach ( (array) $reg['people'] as $p ) {
		// Who may help: everyone 10 and up (kit packing takes preteens); not babies or young children.
		$num = isset( $p['age'] ) && is_numeric( $p['age'] ) ? (int) $p['age'] : null;
		$kid = ( isset( $p['band'] ) && in_array( $p['band'], array( 'child', 'baby' ), true ) ) || ( isset( $p['kind'] ) && 'child' === $p['kind'] );
		if ( empty( $p['name'] ) || ( $kid && ( null === $num || $num < 10 ) ) ) {
			continue;
		}
		$age = ogc_vol_age_of( $reg, $p['name'] );
		// The nights each person is here, else the household's; a day guest any day.
		$ns  = ! empty( $p['nights'] ) ? (array) $p['nights'] : ( isset( $reg['stay']['nights'] ) ? (array) $reg['stay']['nights'] : array() );
		$ns  = array_values( array_filter( $ns, function ( $n ) { return 0 !== strpos( $n, 'Early ' ); } ) );
		$here = array();
		if ( $ns && ( ! isset( $reg['stay']['type'] ) || 'elsewhere' !== $reg['stay']['type'] ) ) {
			$a = ogc_vol_find_day( $days, $ns[0] );
			$b = ogc_vol_find_day( $days, $ns[ count( $ns ) - 1 ] );
			if ( $a > -1 && $b > -1 ) {
				for ( $i = $a; $i <= min( $b + 1, count( $days ) - 1 ); $i++ ) {
					$here[] = $days[ $i ]['date'];
				}
			}
		}
		$out[] = array( 'name' => $p['name'], 'age' => $age, 'years' => $num, 'yf' => ! empty( $p['yf'] ), 'days' => $here ?: array_column( $days, 'date' ) );
	}
	return array( 'people' => $out, 'phone' => isset( $reg['household']['phone'] ) ? $reg['household']['phone'] : '' );
}

/** Last year's shifts again: each matched to this year's by its lasting uid, else by committee, job and
 * weekday with the start within 90 minutes (a lunch moved by a quarter hour is still lunch). */
function ogc_vol_again( $year, $email ) {
	if ( ! $email ) {
		return array();
	}
	$prev = (int) $year - 1;
	$old  = array();
	$then = ogc_vol_shifts( $prev );
	foreach ( ogc_records( $prev, 'signups', $email ) as $r ) {
		$id = isset( $r['data']['id'] ) ? $r['data']['id'] : '';
		if ( isset( $then[ $id ] ) ) {
			$o        = $then[ $id ];
			$old[]    = array( 'uid' => $o['uid'], 'committee' => $o['committee'], 'role' => $o['role'], 'day' => $o['day'], 'start' => $o['start'], 'end' => $o['end'], 'name' => $r['data']['name'] );
		}
	}
	// Kept past the clearing for those who asked (Email me when next year's sign-ups open).
	$kept = ogc_state_get( $year, 'vol-return' );
	foreach ( $kept ? (array) $kept['value'] : array() as $k ) {
		if ( isset( $k['email'] ) && $k['email'] === $email ) {
			foreach ( (array) $k['patterns'] as $p ) {
				$old[] = $p;
			}
		}
	}
	$now = ogc_vol_shifts( $year );
	$out = array();
	foreach ( $old as $o ) {
		$best = null;
		$gap  = 91;
		foreach ( $now as $id => $sh ) {
			if ( 0 !== strcasecmp( $sh['day'], $o['day'] ) ) {
				continue;
			}
			if ( $o['uid'] && $sh['uid'] === $o['uid'] ) {
				$best = $id;
				break;
			}
			if ( 0 === strcasecmp( $sh['committee'], $o['committee'] ) && 0 === strcasecmp( $sh['role'], $o['role'] ) && abs( $sh['start'] - $o['start'] ) < $gap ) {
				$gap  = abs( $sh['start'] - $o['start'] );
				$best = $id;
			}
		}
		$key = $best ? $best : 'x:' . $o['committee'] . '|' . $o['role'] . '|' . $o['day'];
		if ( ! isset( $out[ $key ] ) ) {
			// As it was: its real end when kept (patterns kept before Oct 10 have none: the part of the day).
			$was         = isset( $o['end'] ) ? ogc_vol_span( (int) $o['start'], (int) $o['end'] ) : ( $o['start'] < 720 ? 'morning' : ( $o['start'] < 1020 ? 'afternoon' : 'evening' ) );
			$out[ $key ] = array( 'shift' => $best, 'names' => array(), 'was' => $o['role'] . ' · ' . $o['committee'] . ' · ' . $o['day'] . ' ' . $was );
		}
		if ( ! in_array( $o['name'], $out[ $key ]['names'], true ) ) {
			$out[ $key ]['names'][] = $o['name'];
		}
	}
	return array_values( $out );
}

function ogc_vol_rest_live( WP_REST_Request $req ) {
	$y = (int) $req['year'];
	ogc_vol_prepare_year( $y );
	$actor = ogc_vol_actor( $req );
	$email = $actor['email'] ?: ( $actor['holds'] ? reset( $actor['holds'] ) : '' );
	$mine  = ogc_vol_mine( $y, $actor );
	$u     = wp_get_current_user();
	// The phone and name they last gave (theirs only), so they aren't asked again. Someone not signed in
	// gets only what's in the records this device holds: an email typed is not proof, and other records
	// under it (last year's, a later sign-up by the real owner) may be someone else's.
	$phone = '';
	$name  = $u && $u->ID ? ( function_exists( 'ogc_person_name' ) ? ogc_person_name( $u->ID ) : $u->display_name ) : '';
	$own   = $actor['signed'] && $email
		? array_merge( ogc_records( $y - 1, 'signups', $email ), ogc_records( $y, 'waits', $email ), ogc_records( $y, 'signups', $email ) )
		: array_filter( array_merge( ogc_records( $y, 'waits' ), ogc_records( $y, 'signups' ) ), function ( $r ) use ( $actor ) {
			return ogc_vol_owns( $actor, $r );
		} );
	foreach ( $own as $r ) {
		$phone = ! empty( $r['data']['phone'] ) ? $r['data']['phone'] : $phone;
	}
	$hh = $actor['signed'] ? ogc_vol_household( $y, $email ) : null;
	if ( $hh && ! $phone ) {
		$phone = $hh['phone'];
	}
	$wall = ogc_vol_wall( $y );
	$coms = array();
	$closed = ogc_vol_closed( $y );
	foreach ( ogc_vol_committees( $y ) as $c ) {
		// A closed year has no one to call about it.
		$coms[] = array( 'name' => $c['name'], 'phone' => $closed ? '' : ogc_vol_phone_shown( $c['contact_phone'] ), 'contact' => '' !== $c['contact_email'] );
	}
	$first = null;
	foreach ( $mine as $m ) {
		if ( ! $m['for'] ) {
			$first = $m;
			break;
		}
	}
	return rest_ensure_response( array(
		'year'       => $y,
		'posted'     => ogc_vol_posted( $y ),
		'closed'     => $closed,
		// Unconfirmed places are let go after this many hours (said under "Check your email").
		'confirm_hours' => ogc_vol_confirm_hours( $y ),
		'closes'     => ogc_vol_close_date( $y ),
		// The day sign-ups open, once the COA has set one (never an expected date).
		'opens'      => ogc_vol_opens( $y ),
		'names'      => ogc_vol_names_shown( $y ),
		'now'        => $wall,
		'nonce'      => wp_create_nonce( 'wp_rest' ),
		'shifts'     => (object) ogc_vol_public_shifts( $y, $actor ),
		'committees' => $coms,
		'me'         => $actor['signed'] || $actor['holds'] ? array(
			'email'     => $email,
			'name'      => $actor['signed'] ? $name : '',
			'phone'     => $phone,
			'signed'    => $actor['signed'],
			'show'      => $first ? ! $first['hide'] : true,
			'next_year' => (bool) array_filter( $own, function ( $r ) use ( $y ) { return 'signups' === $r['kind'] && (int) $r['year'] === $y && ! empty( $r['data']['next_year'] ); } ),
			'lead'      => $actor['signed'] && ogc_vol_can_lead( $y ),
			'member'    => $actor['signed'] && ogc_is_member( $y ),
		) : null,
		'mine'       => $mine,
		// A closed year: how many different people helped, all and per committee (never places).
		'helped'     => $closed ? ogc_vol_people_shown( $y ) : null,
		'waits'      => ogc_vol_mine( $y, $actor, 'waits' ),
		'household'  => $hh,
		'again'      => $actor['signed'] ? ogc_vol_again( $y, $email ) : array(),
	) );
}

/* ================================================================== joining */

/** The person's name from the form: "First Last", trimmed. */
function ogc_vol_clean_name( $s ) {
	return mb_substr( trim( preg_replace( '/\s+/', ' ', sanitize_text_field( (string) $s ) ) ), 0, 80 );
}

function ogc_vol_clean_phone( $s ) {
	$s = mb_substr( trim( sanitize_text_field( (string) $s ) ), 0, 32 );
	// Kept the one way (765-555-0123) when it's a US number; anything else as typed.
	return strlen( preg_replace( '/\D+/', '', $s ) ) >= 7 ? ogc_vol_phone_shown( $s ) : '';
}

/**
 * Join one or more shifts.
 * Body: { shifts: [id…] (or shift), people: [names] (from the household; default the person),
 *   who: { first, last, email, phone } (not signed in), for_other: { name, phone } (signing someone
 *   else up), phone, answers: { rule: true | [names], question, screened }, note, show, next_year,
 *   t (an emailed link that vouches for the email), hp (left empty by people) }
 * Each shift is its own result; on one shift the people go on all together or not at all.
 */
function ogc_vol_rest_join( WP_REST_Request $req ) {
	$y = (int) $req['year'];
	ogc_vol_prepare_year( $y );
	if ( '' !== (string) $req->get_param( 'hp' ) ) {
		return rest_ensure_response( array( 'results' => array(), 'mine' => array() ) );
	}
	// Per address: a campus's shared wifi is many people, so the limit is generous (filterable).
	if ( ! ogc_vol_rate( 'join|' . ogc_vol_ip(), (int) apply_filters( 'ogc_vol_joins_per_hour', 120 ) ) ) {
		return ogc_vol_no( 'slow', 'Too many sign-ups at once. Try again later.', array(), 429 );
	}
	$actor = ogc_vol_actor( $req );
	$who   = (array) $req->get_param( 'who' );
	$link  = ogc_vol_link_of( $req );
	$errs  = array();
	if ( $actor['signed'] ) {
		$email     = $actor['email'];
		$confirmed = true;
	} elseif ( $link && in_array( $link['a'], array( 'opened', 'again', 'confirm' ), true ) ) {
		$email     = strtolower( (string) $link['e'] );
		$confirmed = true;
	} else {
		$email = strtolower( sanitize_email( isset( $who['email'] ) ? $who['email'] : '' ) );
		if ( ! is_email( $email ) ) {
			$errs['email'] = 'Enter your email';
		}
		$confirmed = false;
	}
	$first  = ogc_vol_clean_name( isset( $who['first'] ) ? $who['first'] : '' );
	$last   = ogc_vol_clean_name( isset( $who['last'] ) ? $who['last'] : '' );
	$typed  = trim( $first . ' ' . $last );
	$u      = wp_get_current_user();
	$known  = $u && $u->ID ? ( function_exists( 'ogc_person_name' ) ? ogc_person_name( $u->ID ) : $u->display_name ) : '';
	$myname = $typed ?: ( $actor['signed'] && false !== strpos( trim( $known ), ' ' ) ? $known : '' );
	$phone  = ogc_vol_clean_phone( isset( $who['phone'] ) ? $who['phone'] : $req->get_param( 'phone' ) );
	$other  = (array) $req->get_param( 'for_other' );
	$people = array_values( array_unique( array_filter( array_map( 'ogc_vol_clean_name', (array) $req->get_param( 'people' ) ) ) ) );
	if ( ! empty( $other['name'] ) ) {
		$people = array( ogc_vol_clean_name( $other['name'] ) );
		$phone  = ogc_vol_clean_phone( isset( $other['phone'] ) ? $other['phone'] : '' );
		if ( ! $phone ) {
			$errs['other_phone'] = 'Enter their phone';
		}
	}
	if ( ! $people ) {
		if ( ! $myname ) {
			$errs['first'] = $first ? '' : 'Enter your first name';
			$errs['last']  = $last ? '' : 'Enter your last name';
		}
		$people = array( $myname );
	}
	// The email is known to be theirs (signed in, or an emailed link): a phone they gave before will do.
	$vouched = $actor['signed'] || $confirmed;
	if ( ! $phone && ! $vouched && empty( $other['name'] ) ) {
		$errs['phone'] = 'Enter a phone number';
	}
	if ( ! $phone && $vouched ) {
		// A known phone: their last sign-up's, or the household's.
		foreach ( array_merge( ogc_records( $y - 1, 'signups', $email ), ogc_records( $y, 'waits', $email ), ogc_records( $y, 'signups', $email ) ) as $r ) {
			$phone = ! empty( $r['data']['phone'] ) ? $r['data']['phone'] : $phone;
		}
		$hh = ogc_vol_registration( $y, $email );
		$phone = $phone ?: ( $hh && ! empty( $hh['household']['phone'] ) ? $hh['household']['phone'] : '' );
		if ( ! $phone ) {
			$errs['phone'] = 'Enter a phone number';
		}
	}
	$errs = array_filter( $errs );
	if ( $errs ) {
		return ogc_vol_no( 'fields', 'Check the form.', array( 'fields' => $errs ), 400 );
	}
	$ids = $req->get_param( 'shifts' );
	$ids = is_array( $ids ) ? $ids : array( (string) $req->get_param( 'shift' ) );
	$ids = array_slice( array_values( array_unique( array_filter( array_map( 'strval', $ids ) ) ) ), 0, 12 );
	// A household at most on one sign-up; and an email not yet confirmed holds only so many places
	// (one request could fill a whole shift with made-up names, held for good while confirm_hours is 0).
	$people = array_slice( $people, 0, $vouched ? 10 : 4 );
	if ( ! $vouched ) {
		global $wpdb;
		$held = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM ' . ogc_table( 'vol_seats' ) . ' s JOIN ' . ogc_table( 'records' ) . " r ON r.id = s.record_id AND r.deleted_at IS NULL WHERE s.year = %d AND r.kind = 'signups' AND r.email = %s", $y, $email ) );
		$cap  = (int) apply_filters( 'ogc_vol_unconfirmed_places', 12 );
		if ( $held + count( $people ) * count( $ids ) > $cap ) {
			return ogc_vol_no( 'confirm', 'Confirm your email first · The link is in your inbox', array(), 429 );
		}
		// And places not yet confirmed, per address a day (generous: a campus's wifi is many people).
		$k = 'ogc_vol_us_' . md5( ogc_vol_ip() );
		$n = (int) get_transient( $k ) + count( $people ) * count( $ids );
		if ( $n > (int) apply_filters( 'ogc_vol_unconfirmed_per_day', 200 ) ) {
			return ogc_vol_no( 'slow', 'Too many sign-ups at once. Try again later.', array(), 429 );
		}
		set_transient( $k, $n, DAY_IN_SECONDS );
	}
	$answers = (array) $req->get_param( 'answers' );
	$note    = mb_substr( sanitize_text_field( (string) $req->get_param( 'note' ) ), 0, 200 );
	$show    = false !== $req->get_param( 'show' );
	$next    = (bool) $req->get_param( 'next_year' );
	$reg     = ogc_vol_registration( $y, $email );
	$shifts  = ogc_vol_shifts( $y );
	$results = array();
	$made    = array();
	foreach ( $ids as $id ) {
		$results[] = ogc_vol_join_one( $y, $id, $shifts, $people, compact( 'email', 'phone', 'confirmed', 'answers', 'note', 'show', 'next', 'reg', 'other', 'actor', 'myname' ), $made );
	}
	if ( $made ) {
		ogc_log( 'vol_join', $y, 'signups', array( 'n' => count( $made ) ) );
		ogc_vol_queue_confirm( $y, $email, $made, $confirmed );
	}
	$out = array( 'results' => $results );
	if ( $made && ! $actor['signed'] ) {
		ogc_vol_device_link( $made );
		$out['hold'] = ogc_vol_token( array( 'a' => 'hold', 'y' => $y, 'e' => $email, 'r' => $made ), DAY_IN_SECONDS );
		$actor['holds'] += array_fill_keys( $made, $email );
	}
	$out['mine']   = ogc_vol_mine( $y, $actor );
	// The sign-ups this Join made (Undo and "Wrong email? Change" take them back).
	$out['made']   = array_map( 'intval', $made );
	$out['shifts'] = (object) array_intersect_key( ogc_vol_public_shifts( $y, $actor ), array_flip( $ids ) );
	$out['email']  = $email;
	return rest_ensure_response( $out );
}

/** One shift of a join: checks, then the places, then the sign-ups. */
function ogc_vol_join_one( $y, $id, $shifts, $people, $o, &$made ) {
	global $wpdb;
	$res = array( 'shift' => $id, 'status' => 'ok', 'names' => $people );
	if ( ! isset( $shifts[ $id ] ) ) {
		return array_merge( $res, array( 'status' => 'gone' ) );
	}
	$sh = $shifts[ $id ];
	$st = ogc_vol_shift_state( $y, $sh, 0 );
	if ( 'open' !== $st ) {
		return array_merge( $res, array( 'status' => $st ) );
	}
	$ans = isset( $o['answers'] ) ? (array) $o['answers'] : array();
	// The shift's rule, per person.
	$rule = null;
	if ( $sh['min_age'] ) {
		foreach ( $people as $n ) {
			$age = ogc_vol_age_of( $o['reg'], $n );
			$num = ogc_vol_age_num( $o['reg'], $n );
			if ( ( $sh['min_age'] >= 18 && in_array( $age, array( 'minor', 'child' ), true ) ) || ( null !== $num && $num < $sh['min_age'] ) ) {
				return array_merge( $res, array( 'status' => 'minor', 'name' => $n, 'min_age' => $sh['min_age'] ) );
			}
		}
	}
	if ( $sh['question'] ) {
		$q = isset( $ans['question'] ) ? (string) $ans['question'] : '';
		if ( ! in_array( $q, $sh['question'], true ) ) {
			return array_merge( $res, array( 'status' => 'rule', 'question' => $sh['question'] ) );
		}
		$rule = array( 'text' => $sh['rule'], 'answer' => $q, 'at' => gmdate( 'c', ogc_vol_now() ) );
	} elseif ( $sh['rule'] ) {
		$r  = isset( $ans['rule'] ) ? $ans['rule'] : false;
		$ok = true === $r || 'true' === $r || '1' === $r || 1 === $r || ( is_array( $r ) && ! array_diff( $people, array_map( 'strval', $r ) ) );
		if ( ! $ok ) {
			return array_merge( $res, array( 'status' => 'rule', 'rule' => $sh['rule'] ) );
		}
		$rule = array( 'text' => $sh['rule'], 'answer' => 'yes', 'at' => gmdate( 'c', ogc_vol_now() ) );
	}
	$screen = '';
	if ( $sh['screening'] ) {
		$screen = isset( $ans['screened'] ) && in_array( $ans['screened'], array( 'yes', 'not_yet' ), true ) ? $ans['screened'] : '';
		$s      = ogc_vol_settings( $y );
		if ( ! $screen || ( 'not_yet' === $screen && ! empty( $s['screening_required'] ) && 'yes' === $s['screening_required'] ) ) {
			return array_merge( $res, array( 'status' => 'screening' ) );
		}
	}
	// Busy: already on a shift at that time.
	$pkeys = array();
	foreach ( $people as $n ) {
		$pk = ogc_vol_pkey( $o['email'], $n );
		$b  = ogc_vol_busy( $y, $sh, $pk );
		if ( $b ) {
			return array_merge( $res, array( 'status' => 'busy', 'name' => $n, 'busy' => array( 'shift' => $b['id'], 'role' => $b['role'], 'until' => $b['end'] ) ) );
		}
		$pkeys[ $pk ] = $n;
	}
	$seats = ogc_vol_take_seats( $y, $sh, array_keys( $pkeys ) );
	if ( is_wp_error( $seats ) ) {
		$d = $seats->get_error_data();
		if ( 'ogc_dup' === $seats->get_error_code() ) {
			return array_merge( $res, array( 'status' => 'dup', 'name' => isset( $pkeys[ $d['pkey'] ] ) ? $pkeys[ $d['pkey'] ] : '' ) );
		}
		return array_merge( $res, array( 'status' => 'full', 'open' => isset( $d['open'] ) ? $d['open'] : 0 ) );
	}
	// Two Joins at once by one person for two shifts at the same time (two tabs, a double tap across
	// rows) both passed Busy above before either had a place. Each now holds one; the later gives it back.
	foreach ( $seats as $pk => $seat_id ) {
		$b = ogc_vol_busy_race( $y, $sh, $pk, $seat_id );
		if ( $b ) {
			ogc_vol_release( $seats );
			return array_merge( $res, array( 'status' => 'busy', 'name' => $pkeys[ $pk ], 'busy' => array( 'shift' => $b['id'], 'role' => $b['role'], 'until' => $b['end'] ) ) );
		}
	}
	$by = ! empty( $o['other']['name'] ) ? 'helper' : 'self';
	foreach ( $seats as $pk => $seat_id ) {
		$n    = $pkeys[ $pk ];
		$age  = ogc_vol_age_of( $o['reg'], $n );
		$data = array(
			'id'        => $id,
			'name'      => $n,
			'phone'     => $o['phone'],
			'email'     => $o['email'],
			'confirmed' => (bool) $o['confirmed'],
			'by'        => $by,
			'at'        => gmdate( 'c', ogc_vol_now() ),
			'hide'      => ! $o['show'],
			'next_year' => (bool) $o['next'],
		);
		if ( 'helper' === $by ) {
			$data['helper'] = $o['myname'];
		}
		// Signed up by someone else in the household (Daniel for Esther): her name stays off the public
		// list (counted only) until she chooses; the head sees it.
		if ( 'self' === $by && '' !== $o['myname'] && strtolower( $n ) !== strtolower( $o['myname'] ) ) {
			$data['for'] = true;
		}
		if ( in_array( $age, array( 'minor', 'child' ), true ) ) {
			$data['minor'] = true;
		}
		if ( $rule ) {
			$data['rule'] = $rule;
		}
		if ( $screen ) {
			$data['screened'] = $screen;
		}
		if ( $o['note'] ) {
			$data['note'] = $o['note'];
		}
		$rid = ogc_record_insert( $y, 'signups', $data, $o['email'], false, 'web' );
		if ( ! $rid ) {
			ogc_vol_release( $seats );
			return array_merge( $res, array( 'status' => 'error' ) );
		}
		$wpdb->update( ogc_table( 'vol_seats' ), array( 'record_id' => $rid ), array( 'id' => $seat_id ), array( '%d' ), array( '%d' ) );
		$made[] = $rid;
		ogc_vol_change( $y, $sh, 'joined', $n );
	}
	// A place taken: off the waitlist for it.
	foreach ( ogc_records( $y, 'waits', $o['email'] ) as $w ) {
		if ( isset( $w['data']['id'] ) && $w['data']['id'] === $id && in_array( $w['data']['name'], $people, true ) ) {
			ogc_record_delete( $w['id'] );
		}
	}
	return $res;
}

/** A line in the committee's changes since a head last printed (members only; cleared with the year). */
function ogc_vol_change( $year, $sh, $act, $name, $extra = array() ) {
	$s = ogc_state_get( $year, 'vol-changes' );
	$l = $s ? (array) $s['value'] : array();
	$l[] = array_merge( array( 'at' => ogc_now(), 'committee' => $sh['committee'], 'shift' => $sh['id'], 'act' => $act, 'name' => $name ), $extra );
	ogc_state_put( $year, 'vol-changes', array_slice( $l, -800 ) );
}

/* ================================================================== taking it back, leaving */

/** Undo, within ten minutes of joining and before the confirmation goes: as if it never happened. */
function ogc_vol_rest_undo( WP_REST_Request $req ) {
	global $wpdb;
	$y     = (int) $req['year'];
	$actor = ogc_vol_actor( $req );
	$done  = array();
	foreach ( array_slice( array_map( 'intval', (array) $req->get_param( 'ids' ) ), 0, 20 ) as $id ) {
		$rec = ogc_record_get( $id );
		if ( ! $rec || 'signups' !== $rec['kind'] || (int) $rec['year'] !== $y || ! ogc_vol_owns( $actor, $rec ) ) {
			continue;
		}
		if ( ogc_vol_now() - strtotime( $rec['created_at'] . ' UTC' ) > 600 || ogc_vol_outbox_sent_for( $id ) ) {
			// Too late to take back quietly: an ordinary Leave.
			ogc_record_delete( $id );
			ogc_vol_after_leave( $y, $rec, 'self' );
		} else {
			$wpdb->delete( ogc_table( 'records' ), array( 'id' => $id ), array( '%d' ) );
			ogc_vol_release_record( $id );
			ogc_vol_outbox_drop( $id );
		}
		$done[] = $id;
	}
	if ( $done ) {
		ogc_log( 'vol_undo', $y, 'signups', array( 'n' => count( $done ) ) );
	}
	return rest_ensure_response( array( 'undone' => $done, 'mine' => ogc_vol_mine( $y, $actor ), 'shifts' => (object) ogc_vol_public_shifts( $y, $actor ) ) );
}

/** Leave a shift, one person at a time. After the shift has started, Leave is gone (call the head). */
function ogc_vol_rest_leave( WP_REST_Request $req ) {
	$y     = (int) $req['year'];
	$actor = ogc_vol_actor( $req );
	$link  = ogc_vol_link_of( $req );
	$left  = array();
	foreach ( array_slice( array_map( 'intval', (array) $req->get_param( 'ids' ) ), 0, 20 ) as $id ) {
		$rec = ogc_record_get( $id );
		if ( ! $rec || 'signups' !== $rec['kind'] || (int) $rec['year'] !== $y ) {
			continue;
		}
		$by_link = $link && 'leave' === $link['a'] && in_array( $id, (array) $link['r'], true ) && strtolower( $link['e'] ) === $rec['email'];
		if ( ! $by_link && ! ogc_vol_owns( $actor, $rec ) ) {
			continue;
		}
		$shifts = ogc_vol_shifts( $y );
		$sh     = isset( $shifts[ $rec['data']['id'] ] ) ? $shifts[ $rec['data']['id'] ] : null;
		if ( $sh && ogc_vol_now() >= $sh['start_ts'] ) {
			return ogc_vol_no( 'started', 'Started', array( 'phone' => ogc_vol_role_phone( $y, $sh['committee'] ) ) );
		}
		ogc_record_delete( $id );
		ogc_vol_after_leave( $y, $rec, 'self' );
		$left[] = $id;
	}
	if ( $left ) {
		ogc_log( 'vol_leave', $y, 'signups', array( 'n' => count( $left ) ) );
	}
	return rest_ensure_response( array( 'left' => $left, 'mine' => ogc_vol_mine( $y, $actor ), 'shifts' => (object) ogc_vol_public_shifts( $y, $actor ) ) );
}

/** The committee's role phone, for "Questions" and "Call the head". */
function ogc_vol_role_phone( $year, $committee ) {
	$c = ogc_vol_committees( $year );
	return isset( $c[ $committee ] ) ? $c[ $committee ]['contact_phone'] : '';
}

/**
 * After a sign-up ends (Leave, Your sign-ups, a head's Remove with notify): its place is let go; the
 * person gets a cancellation (with the calendar event cancelled); everyone waiting hears a place
 * opened; the head hears at once within 48 hours of the shift ("Late"), else in the weekly email.
 */
function ogc_vol_after_leave( $year, $rec, $how ) {
	ogc_vol_release_record( $rec['id'] );
	ogc_vol_outbox_drop( $rec['id'] );
	$shifts = ogc_vol_shifts( $year );
	$id     = isset( $rec['data']['id'] ) ? $rec['data']['id'] : '';
	if ( ! isset( $shifts[ $id ] ) ) {
		return;
	}
	$sh = $shifts[ $id ];
	ogc_vol_change( $year, $sh, 'left', $rec['data']['name'] );
	if ( 'quiet' === $how ) {
		return;
	}
	if ( ! empty( $rec['data']['email'] ) ) {
		ogc_vol_queue_person( $year, $rec, 'left' );
	}
	if ( ogc_vol_now() < $sh['start_ts'] ) {
		ogc_vol_notify_waitlist( $year, $sh );
		if ( $sh['start_ts'] - ogc_vol_now() < 2 * DAY_IN_SECONDS ) {
			ogc_vol_head_notice( $year, $sh, 'late', array( 'name' => ogc_vol_first_l( $rec['data']['name'] ) ) );
		}
	}
}

/* ================================================================== the waitlist */

function ogc_vol_rest_wait( WP_REST_Request $req ) {
	$y     = (int) $req['year'];
	$actor = ogc_vol_actor( $req );
	if ( '' !== (string) $req->get_param( 'hp' ) ) {
		return rest_ensure_response( array( 'waits' => array() ) );
	}
	if ( ! ogc_vol_rate( 'wait|' . ogc_vol_ip(), 30 ) ) {
		return ogc_vol_no( 'slow', 'Too many at once. Try again later.', array(), 429 );
	}
	$shifts = ogc_vol_shifts( $y );
	$id     = (string) $req->get_param( 'shift' );
	if ( ! isset( $shifts[ $id ] ) ) {
		return ogc_vol_no( 'gone', 'Not found', array(), 404 );
	}
	$who   = (array) $req->get_param( 'who' );
	$email = $actor['email'];
	$name  = ogc_vol_clean_name( trim( ( isset( $who['first'] ) ? $who['first'] : '' ) . ' ' . ( isset( $who['last'] ) ? $who['last'] : '' ) ) );
	$phone = ogc_vol_clean_phone( isset( $who['phone'] ) ? $who['phone'] : '' );
	if ( ! $actor['signed'] ) {
		$email = strtolower( sanitize_email( isset( $who['email'] ) ? $who['email'] : '' ) );
		$errs  = array_filter( array( 'email' => is_email( $email ) ? '' : 'Enter your email', 'first' => empty( $who['first'] ) ? 'Enter your first name' : '', 'last' => empty( $who['last'] ) ? 'Enter your last name' : '', 'phone' => $phone ? '' : 'Enter a phone number' ) );
		if ( $errs ) {
			return ogc_vol_no( 'fields', 'Check the form.', array( 'fields' => $errs ), 400 );
		}
	}
	$people = array_values( array_filter( array_map( 'ogc_vol_clean_name', (array) $req->get_param( 'people' ) ) ) );
	if ( ! $people ) {
		$u      = wp_get_current_user();
		$people = array( $name ?: ( $u && $u->ID ? $u->display_name : '' ) );
	}
	$made = array();
	$have = ogc_records( $y, 'waits', $email );
	foreach ( $people as $n ) {
		foreach ( $have as $w ) {
			if ( $w['data']['id'] === $id && 0 === strcasecmp( $w['data']['name'], $n ) ) {
				continue 2;
			}
		}
		$made[] = ogc_record_insert( $y, 'waits', array( 'id' => $id, 'name' => $n, 'email' => $email, 'phone' => $phone, 'at' => gmdate( 'c', ogc_vol_now() ), 'confirmed' => $actor['signed'] ), $email, false, 'web' );
	}
	ogc_log( 'vol_wait', $y, 'waits', array( 'n' => count( $made ) ) );
	$out = array();
	if ( $made && ! $actor['signed'] ) {
		ogc_vol_device_link( $made );
		$out['hold'] = ogc_vol_token( array( 'a' => 'hold', 'y' => $y, 'e' => $email, 'r' => $made ), DAY_IN_SECONDS );
		$actor['holds'] += array_fill_keys( $made, $email );
	}
	$out['waits'] = ogc_vol_mine( $y, $actor, 'waits' );
	return rest_ensure_response( $out );
}

function ogc_vol_rest_unwait( WP_REST_Request $req ) {
	$y     = (int) $req['year'];
	$actor = ogc_vol_actor( $req );
	foreach ( array_slice( array_map( 'intval', (array) $req->get_param( 'ids' ) ), 0, 20 ) as $id ) {
		$rec = ogc_record_get( $id );
		if ( $rec && 'waits' === $rec['kind'] && (int) $rec['year'] === $y && ogc_vol_owns( $actor, $rec ) ) {
			ogc_record_delete( $id );
		}
	}
	return rest_ensure_response( array( 'waits' => ogc_vol_mine( $y, $actor, 'waits' ) ) );
}

/* ================================================================== swaps */

/** Find a replacement: the place stays yours (and counted) until someone takes it; a link to send. */
function ogc_vol_rest_swap( WP_REST_Request $req ) {
	$y     = (int) $req['year'];
	$actor = ogc_vol_actor( $req );
	$rec   = ogc_record_get( (int) $req->get_param( 'id' ) );
	// The emailed Leave link may also Find replacement (the same token, for its own sign-ups).
	$link    = ogc_vol_link_of( $req );
	$by_link = $rec && $link && 'leave' === $link['a'] && in_array( (int) $rec['id'], array_map( 'intval', (array) $link['r'] ), true ) && strtolower( $link['e'] ) === $rec['email'];
	if ( ! $rec || 'signups' !== $rec['kind'] || (int) $rec['year'] !== $y || ! ( $by_link || ogc_vol_owns( $actor, $rec ) ) ) {
		return ogc_vol_no( 'gone', 'Not found', array(), 404 );
	}
	$d         = $rec['data'];
	$d['swap'] = $req->get_param( 'on' ) ? ( ! empty( $d['swap'] ) ? $d['swap'] : wp_generate_password( 16, false ) ) : '';
	ogc_record_update( $rec['id'], $d, $rec['email'] );
	$shifts = ogc_vol_shifts( $y );
	if ( isset( $shifts[ $d['id'] ] ) ) {
		ogc_vol_change( $y, $shifts[ $d['id'] ], $d['swap'] ? 'swap_open' : 'swap_off', $d['name'] );
	}
	return rest_ensure_response( array( 'swap' => $d['swap'] ? $rec['id'] . '.' . $d['swap'] : '', 'mine' => ogc_vol_mine( $y, $actor ) ) );
}

/** Take a place offered for a swap: the same place changes hands at once (the first to tap wins). */
function ogc_vol_rest_take( WP_REST_Request $req ) {
	global $wpdb;
	$y     = (int) $req['year'];
	$actor = ogc_vol_actor( $req );
	list( $rid, $tok ) = array_pad( explode( '.', (string) $req->get_param( 'swap' ), 2 ), 2, '' );
	$old = ogc_record_get( (int) $rid );
	if ( ! $old || 'signups' !== $old['kind'] || (int) $old['year'] !== $y ) {
		return ogc_vol_no( 'taken', 'Taken' );
	}
	// From the link, the token must match; from the page, the place must be offered.
	if ( empty( $old['data']['swap'] ) || ( '' !== $tok && ! hash_equals( (string) $old['data']['swap'], $tok ) ) ) {
		return ogc_vol_no( 'taken', 'Taken' );
	}
	$shifts = ogc_vol_shifts( $y );
	$sh     = isset( $shifts[ $old['data']['id'] ] ) ? $shifts[ $old['data']['id'] ] : null;
	if ( ! $sh || ogc_vol_now() >= $sh['start_ts'] ) {
		return ogc_vol_no( 'started', 'Started' );
	}
	$who   = (array) $req->get_param( 'who' );
	$email = $actor['email'];
	$u     = wp_get_current_user();
	$name  = ogc_vol_clean_name( trim( ( isset( $who['first'] ) ? $who['first'] : '' ) . ' ' . ( isset( $who['last'] ) ? $who['last'] : '' ) ) ) ?: ( $u && $u->ID ? $u->display_name : '' );
	$phone = ogc_vol_clean_phone( isset( $who['phone'] ) ? $who['phone'] : '' );
	if ( ! $actor['signed'] ) {
		$email = strtolower( sanitize_email( isset( $who['email'] ) ? $who['email'] : '' ) );
		$errs  = array_filter( array( 'email' => is_email( $email ) ? '' : 'Enter your email', 'first' => empty( $who['first'] ) ? 'Enter your first name' : '', 'last' => empty( $who['last'] ) ? 'Enter your last name' : '', 'phone' => $phone ? '' : 'Enter a phone number' ) );
		if ( $errs ) {
			return ogc_vol_no( 'fields', 'Check the form.', array( 'fields' => $errs ), 400 );
		}
	}
	if ( ! $phone ) {
		foreach ( ogc_records( $y, 'signups', $email ) as $r ) {
			$phone = ! empty( $r['data']['phone'] ) ? $r['data']['phone'] : $phone;
		}
	}
	$pk = ogc_vol_pkey( $email, $name );
	if ( $pk === ogc_vol_pkey( $old['email'], $old['data']['name'] ) ) {
		return ogc_vol_no( 'dup', 'Signed up' );
	}
	$b = ogc_vol_busy( $y, $sh, $pk );
	if ( $b ) {
		return ogc_vol_no( 'busy', 'Busy', array( 'busy' => array( 'shift' => $b['id'], 'role' => $b['role'], 'until' => $b['end'] ) ) );
	}
	if ( $sh['rule'] && ! $sh['question'] && empty( $req->get_param( 'answers' )['rule'] ) ) {
		return ogc_vol_no( 'rule', 'Rule', array( 'rule' => $sh['rule'] ) );
	}
	$data = array( 'id' => $sh['id'], 'name' => $name, 'phone' => $phone, 'email' => $email, 'confirmed' => $actor['signed'], 'by' => 'swap', 'at' => gmdate( 'c', ogc_vol_now() ), 'took_from' => ogc_vol_first_l( $old['data']['name'] ) );
	if ( $sh['rule'] ) {
		$q            = (array) $req->get_param( 'answers' );
		$data['rule'] = array( 'text' => $sh['rule'], 'answer' => ! empty( $q['question'] ) ? sanitize_text_field( $q['question'] ) : 'yes', 'at' => $data['at'] );
	}
	$new = ogc_record_insert( $y, 'signups', $data, $email, false, 'web' );
	$wpdb->suppress_errors( true );
	$n = $wpdb->query( $wpdb->prepare( 'UPDATE ' . ogc_table( 'vol_seats' ) . ' SET record_id = %d, pkey = %s WHERE year = %d AND record_id = %d', $new, $pk, $y, $old['id'] ) );
	$wpdb->suppress_errors( false );
	if ( 1 !== (int) $n ) {
		$wpdb->delete( ogc_table( 'records' ), array( 'id' => $new ), array( '%d' ) );
		return ogc_vol_no( 'taken', 'Taken' );
	}
	ogc_record_delete( $old['id'] );
	ogc_vol_change( $y, $sh, 'swap', $name, array( 'from' => $old['data']['name'] ) );
	ogc_vol_queue_person( $y, $old, 'swapped', array( 'to' => ogc_vol_first_l( $name ) ) );
	ogc_vol_queue_confirm( $y, $email, array( $new ), $actor['signed'] );
	ogc_vol_head_notice( $y, $sh, 'swap', array( 'from' => ogc_vol_first_l( $old['data']['name'] ), 'to' => ogc_vol_first_l( $name ) ) );
	ogc_log( 'vol_swap', $y, 'signups', array( 'from' => $old['id'], 'to' => $new ) );
	$out = array( 'taken' => $new );
	if ( ! $actor['signed'] ) {
		ogc_vol_device_link( array( $new ) );
		$out['hold']      = ogc_vol_token( array( 'a' => 'hold', 'y' => $y, 'e' => $email, 'r' => array( $new ) ), DAY_IN_SECONDS );
		$actor['holds'][ $new ] = $email;
	}
	$out['mine']   = ogc_vol_mine( $y, $actor );
	$out['shifts'] = (object) ogc_vol_public_shifts( $y, $actor );
	return rest_ensure_response( $out );
}

/* ================================================================== the person's settings */

/** Show my name (one setting for all my sign-ups), and email me when next year's sign-ups open. */
function ogc_vol_rest_me( WP_REST_Request $req ) {
	$y     = (int) $req['year'];
	$actor = ogc_vol_actor( $req );
	$show  = $req->get_param( 'show' );
	$next  = $req->get_param( 'next_year' );
	$who   = ogc_vol_clean_name( $req->get_param( 'name' ) );
	foreach ( ogc_records( $y, 'signups' ) as $r ) {
		if ( ! ogc_vol_owns( $actor, $r ) ) {
			continue;
		}
		$d = $r['data'];
		// Show my name is the person's own; another in the household is changed only by name.
		$for_me = $who ? 0 === strcasecmp( $who, (string) $d['name'] ) : empty( $d['for'] );
		if ( null !== $show && $for_me ) {
			$d['hide'] = ! $show;
			$d['show'] = (bool) $show;
		}
		if ( null !== $next ) {
			$d['next_year'] = (bool) $next;
		}
		ogc_record_update( $r['id'], $d, $r['email'] );
	}
	return rest_ensure_response( array( 'mine' => ogc_vol_mine( $y, $actor ), 'shifts' => (object) ogc_vol_public_shifts( $y, $actor ) ) );
}

/**
 * Email me when sign-ups open (before they're posted). Each request is its own record (kind notify, one
 * per address and year), so two at once can't lose one. The address gets one short email at once
 * ("You'll get one email when they open · Not you? Remove me"), so a neighbour's address typed in
 * isn't kept without them knowing. Sent once when sign-ups open, then the records are erased.
 */
function ogc_vol_rest_notify( WP_REST_Request $req ) {
	$y     = (int) $req['year'];
	$email = ogc_current_email() ?: strtolower( sanitize_email( (string) $req->get_param( 'email' ) ) );
	if ( '' !== (string) $req->get_param( 'hp' ) ) {
		return rest_ensure_response( array( 'ok' => true ) );
	}
	if ( ! is_email( $email ) ) {
		return ogc_vol_no( 'fields', 'Check the form.', array( 'fields' => array( 'email' => 'Enter your email' ) ), 400 );
	}
	if ( ! ogc_vol_rate( 'notify|' . ogc_vol_ip(), 10 ) ) {
		return ogc_vol_no( 'slow', 'Too many at once. Try again later.', array(), 429 );
	}
	if ( ! ogc_records( $y, 'notify', $email ) && ! in_array( $email, (array) ( ( ogc_state_get( $y, 'vol-notify' ) ?: array( 'value' => array() ) )['value'] ), true ) ) {
		ogc_record_insert( $y, 'notify', array( 'email' => $email, 'at' => gmdate( 'c', ogc_vol_now() ) ), $email, false, 'web' );
		ogc_vol_queue( $y, 'notify', $email, array() );
		ogc_log( 'vol_notify', $y, 'notify', array() );
	}
	return rest_ensure_response( array( 'ok' => true ) );
}

/* ================================================================== this device, a mistyped email */

/** Not you? (not signed in): this device forgets the sign-ups it made for the year. The places stay
 * (the emailed Confirm or Not you decides); only this browser stops seeing them. */
function ogc_vol_rest_forget( WP_REST_Request $req ) {
	global $wpdb;
	$y = (int) $req['year'];
	$h = function_exists( 'ogc_device_hash' ) ? ogc_device_hash() : '';
	if ( $h && ! is_user_logged_in() ) {
		$wpdb->query( $wpdb->prepare( 'DELETE d FROM ' . ogc_table( 'devices' ) . ' d JOIN ' . ogc_table( 'records' ) . " r ON r.id = d.record_id WHERE d.dhash = %s AND r.year = %d AND r.kind IN ('signups','waits')", $h, $y ) );
	}
	return rest_ensure_response( array( 'forgot' => true ) );
}

/** This actor's unconfirmed sign-ups among the ids asked for. */
function ogc_vol_unconfirmed_owned( $y, $actor, $ids ) {
	$out = array();
	foreach ( array_slice( array_map( 'intval', (array) $ids ), 0, 20 ) as $id ) {
		$r = ogc_record_get( $id );
		if ( $r && 'signups' === $r['kind'] && (int) $r['year'] === $y && empty( $r['data']['confirmed'] ) && ogc_vol_owns( $actor, $r ) ) {
			$out[] = $r;
		}
	}
	return $out;
}

/** Resend: the confirmation again, for unconfirmed sign-ups (once a minute, five an hour to one address). */
function ogc_vol_rest_resend( WP_REST_Request $req ) {
	$y    = (int) $req['year'];
	$recs = ogc_vol_unconfirmed_owned( $y, ogc_vol_actor( $req ), $req->get_param( 'ids' ) );
	if ( ! $recs ) {
		return ogc_vol_no( 'gone', 'Not found', array(), 404 );
	}
	$email = $recs[0]['email'];
	if ( ! ogc_vol_rate( 'resend1|' . $email, 1, MINUTE_IN_SECONDS ) ) {
		return ogc_vol_no( 'slow', 'Sent · Just now', array(), 429 );
	}
	ogc_vol_queue_confirm( $y, $email, wp_list_pluck( $recs, 'id' ), false, 0 );
	ogc_log( 'vol_resend', $y, 'signups', array( 'n' => count( $recs ) ) );
	return rest_ensure_response( array( 'sent' => true, 'email' => $email ) );
}

/** Change email: an unconfirmed sign-up moves to the address typed, keeping its place (the same seat),
 * and the confirmation goes there. A likely typo ("gmial.com") is asked about once (409 ogc_typo). */
function ogc_vol_rest_email( WP_REST_Request $req ) {
	global $wpdb;
	$y     = (int) $req['year'];
	$actor = ogc_vol_actor( $req );
	$email = strtolower( sanitize_email( (string) $req->get_param( 'email' ) ) );
	if ( ! is_email( $email ) ) {
		return ogc_vol_no( 'fields', 'Check the form.', array( 'fields' => array( 'email' => 'Enter your email' ) ), 400 );
	}
	$fix = function_exists( 'ogc_email_suggest' ) ? ogc_email_suggest( $email ) : '';
	if ( $fix && $fix !== $email && ! $req->get_param( 'typos_ok' ) ) {
		return ogc_vol_no( 'typo', 'Check the email', array( 'fix' => $fix ) );
	}
	if ( ! ogc_vol_rate( 'email|' . ogc_vol_ip(), 20 ) ) {
		return ogc_vol_no( 'slow', 'Too many at once. Try again later.', array(), 429 );
	}
	$recs = ogc_vol_unconfirmed_owned( $y, $actor, $req->get_param( 'ids' ) );
	if ( ! $recs ) {
		return ogc_vol_no( 'gone', 'Not found', array(), 404 );
	}
	$moved = array();
	foreach ( $recs as $r ) {
		$d          = $r['data'];
		$d['email'] = $email;
		ogc_vol_outbox_drop( $r['id'] );
		ogc_record_update( $r['id'], $d, $email );
		// The same place under the new address (the seat's person key follows the email).
		$wpdb->update( ogc_table( 'vol_seats' ), array( 'pkey' => ogc_vol_pkey( $email, $d['name'], isset( $d['phone'] ) ? $d['phone'] : '' ) ), array( 'record_id' => (int) $r['id'] ), array( '%s' ), array( '%d' ) );
		$moved[] = (int) $r['id'];
	}
	ogc_vol_queue_confirm( $y, $email, $moved, false, 0 );
	$out = array( 'email' => $email, 'moved' => $moved );
	if ( ! $actor['signed'] ) {
		// The device's hold names the new address.
		$out['hold'] = ogc_vol_token( array( 'a' => 'hold', 'y' => $y, 'e' => $email, 'r' => $moved ), DAY_IN_SECONDS );
		$actor['holds'] += array_fill_keys( $moved, $email );
	}
	$out['mine'] = ogc_vol_mine( $y, $actor );
	ogc_log( 'vol_email_changed', $y, 'signups', array( 'n' => count( $moved ) ) );
	return rest_ensure_response( $out );
}

/* ================================================================== emailed links */

/**
 * An emailed link, opened on the page: { link: 1 } (the token in this browser's short cookie) or { t }.
 *   confirm   the email is theirs: the sign-ups show their name (this one never signs in; the usual
 *             Confirm link is the signin area's single-use one, ogc_vol_confirm_link)
 *   notme     someone typed this email: the sign-ups are removed and the head is told (once)
 *   leave     a sign-up's Leave shift (asks first on the page)
 *   opened    a place opened on a shift they wait for: Join, one tap (the join route takes the link);
 *             do: unwait takes them off the waitlist instead
 *   again     next year's sign-ups are open: last year's shifts again (the join route takes the link)
 *   unnotify  Remove me: no email when sign-ups open
 * The answer names the address only masked ("h…@gmail.com"): the page shows no more than that.
 */
function ogc_vol_rest_link( WP_REST_Request $req ) {
	$y = (int) $req['year'];
	$p = ogc_vol_link_of( $req );
	if ( ! $p || (int) $p['y'] !== $y ) {
		return ogc_vol_no( 'expired', 'Link expired', array(), 410 );
	}
	$email = strtolower( (string) $p['e'] );
	$ids   = array_map( 'intval', (array) ( isset( $p['r'] ) ? $p['r'] : array() ) );
	$recs  = array();
	foreach ( $ids as $id ) {
		$r = ogc_record_get( $id );
		if ( $r && 'signups' === $r['kind'] && $r['email'] === $email ) {
			$recs[] = $r;
		}
	}
	$m   = preg_match( '/^(.)[^@]*(@.*)$/', $email, $mm ) ? $mm[1] . '…' . $mm[2] : '';
	$out = array( 'a' => $p['a'], 'email' => $m );
	if ( 'confirm' === $p['a'] ) {
		ogc_vol_confirm_records( $y, $email, $ids );
		$out['n'] = count( $recs );
		ogc_log( 'vol_confirm', $y, 'signups', array( 'n' => count( $recs ) ) );
	} elseif ( 'notme' === $p['a'] ) {
		// Once: the link is spent with it.
		if ( function_exists( 'ogc_token_spend' ) ) {
			ogc_token_spend( array( 'id' => $p['_id'] ), 0 );
		}
		$shifts = ogc_vol_shifts( $y );
		foreach ( $recs as $r ) {
			ogc_record_delete( $r['id'] );
			ogc_vol_release_record( $r['id'] );
			ogc_vol_outbox_drop( $r['id'] );
			if ( isset( $shifts[ $r['data']['id'] ] ) ) {
				ogc_vol_change( $y, $shifts[ $r['data']['id'] ], 'notme', $r['data']['name'] );
				ogc_vol_head_notice( $y, $shifts[ $r['data']['id'] ], 'notme', array( 'name' => ogc_vol_first_l( $r['data']['name'] ) ) );
				ogc_vol_notify_waitlist( $y, $shifts[ $r['data']['id'] ] );
			}
		}
		$out['n'] = count( $recs );
		ogc_log( 'vol_notme', $y, 'signups', array( 'n' => count( $recs ) ) );
	} elseif ( 'leave' === $p['a'] ) {
		$out['records'] = array_map( 'ogc_vol_mine_out', $recs );
	} elseif ( 'opened' === $p['a'] || 'again' === $p['a'] ) {
		$out['shifts'] = array_values( (array) ( isset( $p['s'] ) ? $p['s'] : array() ) );
		$out['names']  = array_values( (array) ( isset( $p['n'] ) ? $p['n'] : array() ) );
		$w             = ! empty( $p['w'] ) ? ogc_record_get( (int) $p['w'] ) : null;
		$out['waiting'] = $w && 'waits' === $w['kind'] && $w['email'] === $email;
		if ( 'unwait' === $req->get_param( 'do' ) && $out['waiting'] ) {
			ogc_record_delete( $w['id'] );
			$out['waiting'] = false;
			$out['unwaited'] = true;
		}
	} elseif ( 'unnotify' === $p['a'] ) {
		foreach ( ogc_records( $y, 'notify', $email ) as $r ) {
			ogc_record_delete( $r['id'] );
		}
		$out['removed'] = true;
	}
	return rest_ensure_response( $out );
}
