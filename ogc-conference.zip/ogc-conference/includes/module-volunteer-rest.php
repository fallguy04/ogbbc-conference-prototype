<?php
/**
 * Volunteer shifts: the public page's routes, /wp-json/ogc/v1/vol/{year}/…
 *
 *   GET  vol/{y}          what this viewer may see now: each shift's count and who ("Ruth K." or a
 *                         blank mark), their own sign-ups and waits, their household, last year's
 *                         shifts again, and a fresh nonce. Never cached (counts, "you", the nonce).
 *   POST vol/{y}/join     take places (one or several shifts; one or several people, all or none)
 *   POST vol/{y}/undo     take back a sign-up made a moment ago (no email goes)
 *   POST vol/{y}/leave    leave a shift (per person); the person, the people waiting and the head hear
 *   POST vol/{y}/unleave  take back a Leave made a moment ago (the toast's Undo): the same place again
 *   POST vol/{y}/wait     join a full shift's waitlist;  vol/{y}/unwait  leave it
 *   POST vol/{y}/swap     find a replacement (the place stays yours until someone takes it)
 *   POST vol/{y}/take     take a place offered for a swap, at once
 *   POST vol/{y}/me       show my name or not; email me when next year's sign-ups open
 *   POST vol/{y}/link     an emailed link: confirm, not me, leave, a place opened, sign up again
 *   POST vol/{y}/notify   email me when sign-ups open
 *
 * Someone who isn't signed in may join with their name, email and phone: nothing signs them in. The
 * place is held, their name doesn't show until they open the emailed link, and this device gets a
 * short-lived hold for just those sign-ups (Leave, Add to calendar). Every change needs the wp_rest
 * nonce (for a visitor too) and is logged without personal data.
 */

defined( 'ABSPATH' ) || exit;

add_action( 'rest_api_init', function () {
	$Y = '/vol/(?P<year>\d{4})';
	register_rest_route( OGC_NS, $Y, array( 'methods' => 'GET', 'callback' => 'ogc_vol_rest_live', 'permission_callback' => 'ogc_vol_can_read' ) );
	foreach ( array( 'join', 'undo', 'leave', 'unleave', 'wait', 'unwait', 'swap', 'take', 'me', 'link', 'notify', 'forget', 'resend', 'email' ) as $a ) {
		register_rest_route( OGC_NS, "$Y/$a", array( 'methods' => 'POST', 'callback' => 'ogc_vol_rest_' . $a, 'permission_callback' => 'ogc_vol_can_post' ) );
	}
	// The calendar file as a real address (after the eighth critic, Oct 16): a link a phone opens.
	register_rest_route( OGC_NS, "$Y/ics", array( 'methods' => 'GET', 'callback' => 'ogc_vol_rest_ics', 'permission_callback' => 'ogc_vol_can_read' ) );
} );

function ogc_vol_can_read( WP_REST_Request $req ) {
	return ogc_valid_year( $req['year'] ) && null !== ogc_year_get( (int) $req['year'] );
}

/** Every change needs the wp_rest nonce, a visitor's too (it comes fresh with each GET vol/{y}). */
function ogc_vol_can_post( WP_REST_Request $req ) {
	if ( ! ogc_vol_can_read( $req ) ) {
		return new WP_Error( 'ogc_not_found', 'Not found.', array( 'status' => 404 ) );
	}
	if ( ! wp_verify_nonce( (string) $req->get_header( 'X-WP-Nonce' ), 'wp_rest' ) ) {
		return new WP_Error( 'ogc_nonce', 'Reload the page.', array( 'status' => 403, 'why' => 'nonce' ) );
	}
	return true;
}

/** No page cache may keep these answers (WP Rocket on the real site: Corey's README excludes the path). */
add_filter( 'rest_post_dispatch', function ( $res, $server, $req ) {
	if ( 0 === strpos( (string) $req->get_route(), '/' . OGC_NS . '/vol/' ) && $res instanceof WP_REST_Response ) {
		$res->header( 'Cache-Control', 'no-store, private' );
	}
	return $res;
}, 10, 3 );

/* ================================================================== the calendar file */

/**
 * A calendar file to open, served (after the eighth critic, Oct 16: the page made it in the browser, a
 * blob a phone saves as a download; iOS Safari offers "Add to Calendar" only for a file a site serves).
 * GET vol/{y}/ics?s=<shift ids, commas>[&reg=1[&r=<registration id>]]: the asker's own places on those
 * shifts (ogc_vol_owns: their email's, signed in, or this device's), one event a shift naming them, the
 * same events as the emails' files (ogc_vol_ics: the same UID, the same alarm), so importing both never
 * makes two; with reg, their registration's Conference days too (Your sign-ups' one file). Served as
 * text/calendar, inline: a phone opens it in its calendar, a computer saves it. Signed in, the page adds
 * `_wpnonce` (WordPress's own way for a link) so it knows who asks; nothing in the address is personal.
 */
function ogc_vol_rest_ics( WP_REST_Request $req ) {
	$y      = (int) $req['year'];
	$actor  = ogc_vol_actor( $req );
	$want   = array_slice( array_values( array_filter( array_map( 'trim', explode( ',', (string) $req->get_param( 's' ) ) ) ) ), 0, 60 );
	$shifts = ogc_vol_shifts( $y );
	$items  = array();
	$email  = $actor['email'];
	if ( $want ) {
		foreach ( ogc_records( $y, 'signups' ) as $r ) {
			if ( ! isset( $r['data']['id'], $shifts[ $r['data']['id'] ] ) || ! in_array( (string) $r['data']['id'], $want, true ) || ! ogc_vol_owns( $actor, $r ) ) {
				continue;
			}
			if ( '' === $email ) {
				$email = (string) $r['email'];
			}
			$items[] = array( 'shift' => $shifts[ $r['data']['id'] ], 'name' => (string) $r['data']['name'], 'rid' => (int) $r['id'] );
		}
	}
	// One event a shift under the asker's email (the page's own rule: everyone of theirs on it, named).
	foreach ( $items as &$it ) {
		$it['email'] = $email;
	}
	unset( $it );
	$ics = $items ? ogc_vol_ics( $y, $items, 'PUBLISH', true ) : '';
	$E   = array();
	if ( $ics && preg_match_all( '/BEGIN:VEVENT.*?END:VEVENT/s', $ics, $m ) ) {
		$E = $m[0];
	}
	if ( $req->get_param( 'reg' ) && $actor['signed'] && function_exists( 'ogc_reg_person_days' ) ) {
		$E = array_merge( $E, ogc_vol_ics_reg_events( $y, $actor['email'], (int) $req->get_param( 'r' ) ) );
	}
	if ( ! $E ) {
		return ogc_vol_no( 'gone', 'Nothing to add', array(), 404 );
	}
	$text = implode( "\r\n", array_merge( array( 'BEGIN:VCALENDAR', 'VERSION:2.0', 'PRODID:-//ogbbc.org//Annual Conference//EN', 'METHOD:PUBLISH' ), $E, array( 'END:VCALENDAR' ) ) ) . "\r\n";
	$one  = 1 === count( $want ) && isset( $shifts[ $want[0] ] ) && ! $req->get_param( 'reg' ) ? $shifts[ $want[0] ] : null;
	$file = $one ? 'volunteer-' . trim( preg_replace( '/[^a-z0-9]+/', '-', strtolower( $one['role'] ) ), '-' ) . '-' . $one['date'] . '.ics' : ( $req->get_param( 'reg' ) ? 'annual-conference-' . $y . '.ics' : 'volunteer-' . $y . '.ics' );
	$res  = new WP_REST_Response( null, 200 );
	$res->header( 'Content-Type', 'text/calendar; charset=utf-8' );
	$res->header( 'Content-Disposition', 'inline; filename="' . $file . '"' );
	$res->header( 'Cache-Control', 'private, no-store, max-age=0' );
	$res->header( 'X-Content-Type-Options', 'nosniff' );
	add_filter( 'rest_pre_serve_request', function ( $served, $result ) use ( $text, $res ) {
		if ( $result === $res ) {
			echo $text; // phpcs:ignore WordPress.Security.EscapeOutput -- a calendar file, each value escaped (ogc_vol_ics_text).
			return true;
		}
		return $served;
	}, 10, 2 );
	return $res;
}

/** The Conference's days of this email's registrations as all-day events (Your sign-ups' one file, as
 * its page made it): each registration's people's days, first to last; with none, the Conference itself. */
function ogc_vol_ics_reg_events( $y, $email, $only = 0 ) {
	$cfg   = function_exists( 'ogc_reg_cfg' ) ? ogc_reg_cfg( $y ) : array();
	$days  = function_exists( 'ogc_reg_days' ) ? ogc_reg_days( $y ) : array();
	$s     = ogc_vol_settings( $y );
	$row   = ogc_year_get( $y );
	$where = ! empty( $s['address'] ) ? $s['address'] : ( $row && ! empty( $row['venue'] ) ? $row['venue'] : '' );
	$ev    = function ( $uid, $a, $b, $desc ) use ( $y, $where ) {
		$L = array( 'BEGIN:VEVENT', 'UID:' . $uid . '@ogbbc.org', 'DTSTAMP:' . gmdate( 'Ymd\THis\Z', ogc_vol_now() ), 'DTSTART;VALUE=DATE:' . str_replace( '-', '', $a ), 'DTEND;VALUE=DATE:' . gmdate( 'Ymd', strtotime( $b . ' 12:00:00 UTC' ) + DAY_IN_SECONDS ), 'SUMMARY:' . ogc_vol_ics_text( $y . ' Annual Conference' ) );
		if ( $where ) {
			$L[] = 'LOCATION:' . ogc_vol_ics_text( $where );
		}
		if ( $desc ) {
			$L[] = 'DESCRIPTION:' . ogc_vol_ics_text( $desc );
		}
		$L[] = 'END:VEVENT';
		return implode( "\r\n", $L );
	};
	$out  = array();
	$regs = ogc_records( $y, 'registrations', $email );
	if ( function_exists( 'ogc_linked_records' ) ) {
		$regs = array_merge( $regs, ogc_linked_records( $y, 'registrations', $email ) );
	}
	foreach ( $regs as $r ) {
		$d = (array) $r['data'];
		if ( ( $only && (int) $r['id'] !== $only ) || ( isset( $d['status'] ) && 'cancelled' === $d['status'] ) || empty( $d['people'] ) || empty( $d['stay'] ) ) {
			continue;
		}
		$all = array();
		foreach ( (array) $d['people'] as $p ) {
			$all = array_merge( $all, (array) ogc_reg_person_days( $p, $d, $cfg, $days ) );
		}
		$all = array_values( array_unique( $all ) );
		sort( $all );
		if ( $all ) {
			$rid   = isset( $d['rid'] ) ? (string) $d['rid'] : (string) $r['id'];
			$out[] = $ev( 'annual-conference-' . $y . '-' . $rid, $all[0], $all[ count( $all ) - 1 ], $rid );
		}
	}
	if ( ! $out && ! $only && $row && ! empty( $row['start'] ) ) {
		$out[] = $ev( 'annual-conference-' . $y, $row['start'], ! empty( $row['end'] ) ? $row['end'] : $row['start'], '' );
	}
	return $out;
}

/* ================================================================== links and holds */

/**
 * A link's token: 32 random bytes, kept only as a hash in the signin area's tokens table (kind vol_<act>),
 * with what it lets someone do (the year, the sign-ups or shifts) beside it. Nothing in the token says
 * who or what: an address bar, a history, a server log or a screenshot shows a meaningless string.
 */
function ogc_vol_token( $payload, $ttl ) {
	if ( ! function_exists( 'ogc_token_create' ) ) {
		return '';
	}
	$act = substr( preg_replace( '/[^a-z]/', '', (string) ( isset( $payload['a'] ) ? $payload['a'] : 'x' ) ), 0, 12 );
	$e   = isset( $payload['e'] ) ? (string) $payload['e'] : '';
	unset( $payload['a'], $payload['e'], $payload['x'] );
	$t = ogc_token_create( 'vol_' . $act, $e, array( 'ttl' => max( 60, (int) $ttl ), 'data' => $payload ) );
	return $t['token'];
}

/** The token's payload (a, y, e and its data), or null when it's unknown, used or has run out. */
function ogc_vol_untoken( $t ) {
	$t = (string) $t;
	if ( ! function_exists( 'ogc_token_find' ) || ! preg_match( '/^[A-Za-z0-9_-]{20,100}$/', $t ) ) {
		return null;
	}
	$row = ogc_token_find( $t );
	if ( ! $row || 0 !== strpos( (string) $row['kind'], 'vol_' ) || ! empty( $row['used_at'] ) || strtotime( $row['expires_at'] . ' UTC' ) < time() ) {
		return null;
	}
	$p        = (array) $row['data'];
	$p['a']   = substr( $row['kind'], 4 );
	$p['e']   = (string) $row['email'];
	$p['_id'] = (int) $row['id'];
	return $p;
}

/** The emailed link this request acts by: its token sent with it, or (asked for with link: 1) the one
 * the page's address handed to this browser's short cookie. */
function ogc_vol_link_of( WP_REST_Request $req ) {
	$t = (string) $req->get_param( 't' );
	if ( '' === $t && $req->get_param( 'link' ) && isset( $_COOKIE['ogc_vlt'] ) ) {
		$t = sanitize_text_field( wp_unslash( $_COOKIE['ogc_vlt'] ) );
	}
	return '' === $t ? null : ogc_vol_untoken( $t );
}

// An emailed link (/volunteer/?year=2027&t=…): the token goes into a 30-minute cookie and the page
// opens at a clean address (?link=1), so it's never in the address bar, a bookmark or a history.
add_action( 'ogc_before_page', function ( $page ) {
	if ( 'volunteer' !== $page || ! isset( $_GET['t'] ) ) { // phpcs:ignore -- a link's token, checked by its hash later.
		return;
	}
	$tok = substr( preg_replace( '/[^A-Za-z0-9_-]/', '', (string) wp_unslash( $_GET['t'] ) ), 0, 100 ); // phpcs:ignore
	if ( ! headers_sent() ) {
		setcookie( 'ogc_vlt', $tok, array( 'expires' => time() + 30 * MINUTE_IN_SECONDS, 'path' => COOKIEPATH ? COOKIEPATH : '/', 'domain' => COOKIE_DOMAIN ? COOKIE_DOMAIN : '', 'secure' => is_ssl(), 'httponly' => true, 'samesite' => 'Lax' ) );
	}
	$args = array();
	foreach ( array( 'year', 'shift', 'committee' ) as $k ) {
		if ( isset( $_GET[ $k ] ) ) { // phpcs:ignore
			$args[ $k ] = sanitize_text_field( wp_unslash( $_GET[ $k ] ) ); // phpcs:ignore
		}
	}
	$args['link'] = 1;
	nocache_headers();
	wp_safe_redirect( ogc_vol_url( 'volunteer', $args ), 303 );
	exit;
}, 1 );

/** Who is acting: the signed-in person, or a visitor whose device holds sign-ups it just made. */
function ogc_vol_actor( WP_REST_Request $req ) {
	$email = ogc_current_email();
	$holds = array();
	foreach ( array_slice( array_filter( explode( ',', (string) $req->get_header( 'X-OGC-Hold' ) ) ), 0, 20 ) as $t ) {
		$p = ogc_vol_untoken( trim( $t ) );
		if ( $p && 'hold' === $p['a'] && (int) $p['y'] === (int) $req['year'] ) {
			foreach ( (array) $p['r'] as $id ) {
				$holds[ (int) $id ] = strtolower( (string) $p['e'] );
			}
		}
	}
	return array( 'email' => $email, 'signed' => '' !== $email, 'holds' => $holds );
}

/** Is this sign-up (or wait) confirmed by its own email? Made signed in, by a head, or confirmed by the
 * emailed link (or a sign-in from the device that made it). */
function ogc_vol_rec_confirmed( $rec ) {
	return ! empty( $rec['data']['confirmed'] );
}

/** May this actor change this record (theirs by email, or held on this device)? */
function ogc_vol_owns( $actor, $rec ) {
	// Under their own email: only once that email has confirmed it. Someone not signed in may type a
	// confirmed person's email; until the emailed Confirm (or Not me) answers, that sign-up is nothing of
	// theirs: not on their page, not their phone, not their people (after the critic, Oct 15).
	if ( $actor['signed'] && $rec['email'] === $actor['email'] && ogc_vol_rec_confirmed( $rec ) ) {
		return true;
	}
	// Someone this person added by their own email (Add someone, Oct 13): the one who added them sees
	// the place and may leave it for them; it stays the added person's own too.
	$helper = isset( $rec['data']['helper_email'] ) ? strtolower( (string) $rec['data']['helper_email'] ) : '';
	if ( '' !== $helper && $actor['signed'] && $helper === $actor['email'] ) {
		return true;
	}
	// This tab made it a moment ago (its hold), not signed in. Signed in, the email decides (above): a
	// sign-in from the device that made it confirmed it (ogc_vol_confirm_device()).
	if ( ! $actor['signed'] && isset( $actor['holds'][ (int) $rec['id'] ] ) && in_array( $actor['holds'][ (int) $rec['id'] ], array( $rec['email'], $helper ), true ) ) {
		return true;
	}
	// This device made it (the signin area's device link): only while it's unconfirmed and less than a
	// week old. A confirmed place, or an old one, needs a sign-in (a shared tablet or office computer
	// mustn't show last month's visitor).
	return ! $actor['signed'] && empty( $rec['data']['confirmed'] ) && strtotime( $rec['created_at'] . ' UTC' ) > ogc_vol_now() - 7 * DAY_IN_SECONDS
		&& function_exists( 'ogc_device_has' ) && ogc_device_has( (int) $rec['id'] );
}

/** A few tries an hour from one address, or for one email. */
function ogc_vol_rate( $what, $max, $window = HOUR_IN_SECONDS ) {
	$k = 'ogc_vol_rl_' . md5( $what );
	$n = (int) get_transient( $k );
	if ( $n >= $max ) {
		return false;
	}
	set_transient( $k, $n + 1, $window );
	return true;
}

function ogc_vol_ip() {
	return isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
}

/** A refusal the page shows at the action: why (a word the page knows) and what more it needs. */
function ogc_vol_no( $why, $msg, $extra = array(), $status = 409 ) {
	return new WP_Error( 'ogc_vol_' . $why, $msg, array_merge( array( 'status' => $status, 'why' => $why ), $extra ) );
}

/**
 * The rest of a Confirm link's burst (after the eighth critic, Oct 16): the same email's places and
 * waits still unconfirmed, still ahead and not left, made on the same device as the link's own. A
 * first-timer who signs up twice before confirming gets two Confirm emails; the older one's link used
 * to confirm only its own shift, so the second place was stranded ("3 of 4 open · Sign up" on her page,
 * "Already signed up" when she tapped it). Mechanical: the device that made the link's places (the
 * signin area's device link, ogc_device_has), the email, unconfirmed, ahead. Why the device and not
 * every unconfirmed place of the email: someone else may have typed this address for a place of their
 * own (round 1's Someone Else); that one still waits for its own Confirm, or "Didn't sign up? Remove".
 */
function ogc_vol_burst_ids( $year, $email, $ids ) {
	global $wpdb;
	$email = strtolower( (string) $email );
	$ids   = array_values( array_filter( array_map( 'intval', (array) $ids ) ) );
	if ( ! $ids || ! is_email( $email ) || ! function_exists( 'ogc_device_has' ) ) {
		return array();
	}
	$dt = ogc_table( 'devices' );
	$hs = (array) $wpdb->get_col( 'SELECT DISTINCT dhash FROM ' . $dt . ' WHERE record_id IN (' . implode( ',', $ids ) . ')' ); // phpcs:ignore -- integers.
	if ( ! $hs ) {
		return array();
	}
	$ph   = implode( ',', array_fill( 0, count( $hs ), '%s' ) );
	$rids = (array) $wpdb->get_col( $wpdb->prepare( 'SELECT DISTINCT d.record_id FROM ' . $dt . ' d JOIN ' . ogc_table( 'records' ) . " r ON r.id = d.record_id WHERE d.dhash IN ($ph) AND r.year = %d AND r.email = %s AND r.kind IN ('signups','waits') AND r.deleted_at IS NULL", array_merge( $hs, array( (int) $year, $email ) ) ) ); // phpcs:ignore -- placeholders.
	$shifts = ogc_vol_shifts( $year );
	$out    = array();
	foreach ( $rids as $rid ) {
		$r = ogc_record_get( (int) $rid );
		if ( ! $r || ! empty( $r['data']['confirmed'] ) || ! isset( $r['data']['id'], $shifts[ $r['data']['id'] ] ) || ogc_vol_now() >= $shifts[ $r['data']['id'] ]['start_ts'] ) {
			continue;
		}
		$out[] = (int) $rid;
	}
	return $out;
}

/**
 * The sign-ups a Confirm link names, marked confirmed (their names may show), and with them the rest of
 * its burst (ogc_vol_burst_ids: the same email's other places made on the same device, still unconfirmed
 * and ahead; after the eighth critic, Oct 16). $via: the link's id, kept on each place it confirmed
 * (`confirmed_via`), so the page it opens can say every shift it confirmed. Returns how many of the
 * link's own it covered (as before); ogc_vol_confirmed_now() gives every id it confirmed.
 */
function ogc_vol_confirm_records( $year, $email, $ids, $via = 0 ) {
	$n     = 0;
	$email = strtolower( (string) $email );
	$own   = array_map( 'intval', (array) $ids );
	$all   = array_values( array_unique( array_merge( $own, ogc_vol_burst_ids( $year, $email, $own ) ) ) );
	$GLOBALS['ogc_vol_confirmed_now'] = array();
	foreach ( $all as $id ) {
		$r = ogc_record_get( $id );
		if ( $r && in_array( $r['kind'], array( 'signups', 'waits' ), true ) && (int) $r['year'] === (int) $year && $r['email'] === $email ) {
			if ( empty( $r['data']['confirmed'] ) ) {
				$d                 = $r['data'];
				$d['confirmed']    = true;
				$d['confirmed_at'] = gmdate( 'c', ogc_vol_now() );
				if ( $via ) {
					$d['confirmed_via'] = (int) $via;
				}
				ogc_record_update( $r['id'], $d, $r['email'] );
				$GLOBALS['ogc_vol_confirmed_now'][] = (int) $id;
			}
			if ( 'signups' === $r['kind'] && in_array( $id, $own, true ) ) {
				$n++;
			}
		}
	}
	return $n;
}

/** Every place the last ogc_vol_confirm_records() confirmed (the link's own and its burst). */
function ogc_vol_confirmed_now() {
	return isset( $GLOBALS['ogc_vol_confirmed_now'] ) ? (array) $GLOBALS['ogc_vol_confirmed_now'] : array();
}

/** A Confirm link's places as the page says them: its own, and the burst it confirmed with them (`via`). */
function ogc_vol_link_ids_with_burst( $year, $email, $ids, $via ) {
	$ids = array_map( 'intval', (array) $ids );
	if ( ! $via ) {
		return $ids;
	}
	foreach ( ogc_records( $year, 'signups', strtolower( (string) $email ) ) as $r ) {
		if ( ! empty( $r['data']['confirmed_via'] ) && (int) $r['data']['confirmed_via'] === (int) $via ) {
			$ids[] = (int) $r['id'];
		}
	}
	return array_values( array_unique( $ids ) );
}

/** Sign-ups as the page says them: one line a shift, its people named by first name. */
function ogc_vol_lines_of( $year, $recs ) {
	$shifts = ogc_vol_shifts( $year );
	$items  = array();
	foreach ( (array) $recs as $r ) {
		if ( isset( $r['data']['id'], $shifts[ $r['data']['id'] ] ) ) {
			$items[] = array( 'shift' => $shifts[ $r['data']['id'] ], 'name' => (string) $r['data']['name'], 'rid' => (int) $r['id'], 'email' => $r['email'] );
		}
	}
	return array_map( function ( $g ) use ( $year ) {
		return ogc_vol_role_shown( $g['shift']['role'], $g['shift']['committee'] ) . ' · ' . ogc_vol_subject_day( $year, $g['shift'] ) . ' · ' . ogc_vol_names_words( $g['names'], true );
	}, ogc_vol_group_items( $items ) );
}

/** How many different shifts some sign-ups are (a couple on one shift is one). */
function ogc_vol_shift_count( $ids ) {
	$s = array();
	foreach ( array_map( 'intval', (array) $ids ) as $id ) {
		$r = ogc_record_get( $id );
		if ( $r && isset( $r['data']['id'] ) ) {
			$s[ $r['data']['id'] ] = true;
		}
	}
	return count( $s );
}

/**
 * A sign-in (a code or a link) on the device that made sign-ups or waits under that same email, before
 * it was confirmed: the email is now proved on the device that made them, so they're confirmed. Made on
 * another device, they wait for the emailed Confirm (after the critic, Oct 15).
 */
function ogc_vol_confirm_device( $email ) {
	$email = strtolower( (string) $email );
	if ( ! is_email( $email ) || ! function_exists( 'ogc_device_has' ) ) {
		return 0;
	}
	$n = 0;
	foreach ( array_slice( (array) ogc_years_list(), 0, 3 ) as $y ) {
		foreach ( array( 'signups', 'waits' ) as $kind ) {
			foreach ( ogc_records( (int) $y, $kind, $email ) as $r ) {
				if ( ! ogc_vol_rec_confirmed( $r ) && empty( $r['data']['helper_email'] ) && ogc_device_has( (int) $r['id'] ) ) {
					$d                 = $r['data'];
					$d['confirmed']    = true;
					$d['confirmed_at'] = gmdate( 'c', ogc_vol_now() );
					ogc_record_update( $r['id'], $d, $r['email'] );
					$n++;
				}
			}
		}
	}
	if ( $n ) {
		ogc_log( 'vol_confirm', 0, 'signups', array( 'n' => $n, 'device' => 1 ) );
	}
	return $n;
}
add_action( 'ogc_signed_in', function ( $user_id, $row ) {
	if ( ! empty( $row['email'] ) ) {
		ogc_vol_confirm_device( $row['email'] );
	}
}, 5, 2 );

// The signin area's single-use Confirm link (ogc_vol_confirm_link) has just signed this email in.
add_action( 'ogc_signed_in', function ( $user_id, $row ) {
	if ( empty( $row['data']['vol'] ) || empty( $row['email'] ) ) {
		return;
	}
	$v = (array) $row['data']['vol'];
	// The link's own places and the rest of its burst (after the eighth critic, Oct 16).
	$n = ogc_vol_confirm_records( (int) $v['y'], $row['email'], isset( $v['r'] ) ? $v['r'] : array(), isset( $row['id'] ) ? (int) $row['id'] : 0 );
	// The first confirm: the name typed with the sign-up becomes theirs ("Grace T. · Not you?").
	if ( $user_id && function_exists( 'ogc_person_name' ) && '' === ogc_person_name( $user_id ) && function_exists( 'ogc_person_set_name' ) ) {
		foreach ( array_map( 'intval', isset( $v['r'] ) ? (array) $v['r'] : array() ) as $id ) {
			$r = ogc_record_get( $id );
			// Their own sign-up's name, or (added by someone else under this email) the name they were
			// added as, which they've just confirmed.
			$added = $r && ! empty( $r['data']['helper_email'] );
			if ( $r && $r['email'] === $row['email'] && ( $added || ( empty( $r['data']['for'] ) && 'self' === ( isset( $r['data']['by'] ) ? $r['data']['by'] : 'self' ) ) ) && false !== strpos( trim( (string) $r['data']['name'] ), ' ' ) ) {
				ogc_person_set_name( $user_id, $r['data']['name'] );
				break;
			}
		}
	}
	ogc_log( 'vol_confirm', (int) $v['y'], 'signups', array( 'n' => $n, 'signin' => 1 ) );
	ogc_vol_confirm_follow( $row );
}, 10, 2 );

/**
 * The page a Confirm link opens says what's true of that link's places now (after the fourth critic, Oct
 * 15: Miriam's used Confirm link, opened again after she'd left, said "Confirmed · Usher · Sat, May 29 ·
 * Glen", as if she were back on). The link's id goes into a short cookie of this browser; the page asks
 * POST vol/{y}/link { cf: 1 }, answered only to the same signed-in email.
 */
function ogc_vol_confirm_follow( $row ) {
	if ( ! empty( $row['data']['vol']['y'] ) && ! empty( $row['id'] ) && function_exists( 'ogc_cookie' ) ) {
		ogc_cookie( 'ogc_vcf', (string) (int) $row['id'], 30 * MINUTE_IN_SECONDS );
	}
}
// The same Confirm link again, on the device it signed in (the signin area carries straight on).
add_action( 'ogc_link_again', 'ogc_vol_confirm_follow' );

/**
 * A link's places as they are now, a shift at a time (the emailed Leave and Confirm links): who of its
 * email is still on each shift, who isn't (left, or removed), and the link's own person (the email's own
 * sign-up: not one made for someone else on it; someone added under their own email is theirs) and
 * whether they're still on any of its shifts. Mechanical: the link's own records, and the same name
 * back on the same shift under the same email by a new sign-up counts as on.
 */
function ogc_vol_link_groups( $year, $email, $ids ) {
	$email  = strtolower( (string) $email );
	$shifts = ogc_vol_shifts( $year );
	$self   = '';
	$groups = array();
	$recs   = array();
	foreach ( array_map( 'intval', (array) $ids ) as $id ) {
		$r = ogc_record_get( $id, true );
		if ( ! $r || 'signups' !== $r['kind'] || (int) $r['year'] !== (int) $year || $r['email'] !== $email || ! isset( $r['data']['id'], $shifts[ $r['data']['id'] ] ) ) {
			continue;
		}
		$recs[] = $r;
		if ( '' === $self && ( empty( $r['data']['for'] ) || ! empty( $r['data']['helper_email'] ) ) ) {
			$self = trim( (string) $r['data']['name'] );
		}
	}
	// Who of this email is on each of the link's shifts now, by any sign-up.
	$now = array();
	foreach ( ogc_records( $year, 'signups', $email ) as $r ) {
		if ( isset( $r['data']['id'] ) ) {
			$now[ $r['data']['id'] ][ strtolower( trim( (string) $r['data']['name'] ) ) ] = trim( (string) $r['data']['name'] );
		}
	}
	$self_on = false;
	$gone    = array();
	foreach ( $recs as $r ) {
		$sid = $r['data']['id'];
		$nm  = trim( (string) $r['data']['name'] );
		if ( ! isset( $groups[ $sid ] ) ) {
			$groups[ $sid ] = array( 'shift' => $sid, 'on' => array_values( isset( $now[ $sid ] ) ? $now[ $sid ] : array() ), 'gone' => array() );
		}
		$on = isset( $now[ $sid ][ strtolower( $nm ) ] );
		if ( $on && '' !== $self && 0 === strcasecmp( $nm, $self ) ) {
			$self_on = true;
		}
		if ( ! $on ) {
			$g = array( 'rid' => (int) $r['id'], 'shift' => $sid, 'name' => $nm, 'how' => ! empty( $r['data']['left_at'] ) ? 'left' : 'removed' );
			$groups[ $sid ]['gone'][] = $g;
			$gone[] = $g;
		}
	}
	// Only the link's own people are said as "still on" (not others on the shift under this email).
	$names = array();
	foreach ( $recs as $r ) {
		$names[ strtolower( trim( (string) $r['data']['name'] ) ) ] = true;
	}
	foreach ( $groups as &$g ) {
		$g['on'] = array_values( array_filter( $g['on'], function ( $n ) use ( $names ) {
			return isset( $names[ strtolower( $n ) ] );
		} ) );
	}
	unset( $g );
	return array( 'self' => $self, 'self_on' => $self_on, 'gone' => $gone, 'groups' => array_values( $groups ) );
}

// The Confirm email's link opens the signin area's card: for a volunteer's places it says Confirm (the
// email's word) over the shift, never "Sign in"; any other confirm link keeps its own words.
add_filter( 'ogc_token_kinds', function ( $kinds ) {
	$prev = isset( $kinds['confirm'] ) ? $kinds['confirm'] : array();
	$word = function ( $what, $row, $def ) use ( $prev ) {
		if ( isset( $prev[ $what ] ) ) {
			return $prev[ $what ] instanceof Closure ? call_user_func( $prev[ $what ], $row ) : $prev[ $what ];
		}
		return $def;
	};
	$items = function ( $row ) {
		$v = isset( $row['data']['vol'] ) ? (array) $row['data']['vol'] : array();
		if ( empty( $v['y'] ) ) {
			return array();
		}
		$shifts = ogc_vol_shifts( (int) $v['y'] );
		$out    = array();
		foreach ( array_map( 'intval', isset( $v['r'] ) ? (array) $v['r'] : array() ) as $id ) {
			$r = ogc_record_get( $id );
			if ( $r && $r['email'] === $row['email'] && isset( $shifts[ $r['data']['id'] ] ) ) {
				$out[] = array( 'shift' => $shifts[ $r['data']['id'] ], 'name' => $r['data']['name'], 'rid' => $id, 'email' => $r['email'] );
			}
		}
		// A shift once, its people named: Martha and Henry on one Server shift is one shift to confirm.
		return array_map( function ( $g ) {
			return array_merge( $g['shift'], array( 'who' => ogc_vol_names_words( $g['names'] ) ) );
		}, ogc_vol_group_items( $out ) );
	};
	$kinds['confirm'] = array_merge( $prev, array(
		'heading' => function ( $row ) use ( $items, $word ) {
			$xs = $items( $row );
			if ( ! $xs ) {
				return $word( 'heading', $row, 'Sign in' );
			}
			return 1 === count( $xs ) ? ogc_vol_role_shown( $xs[0]['role'], $xs[0]['committee'] ) . ' · ' . ogc_vol_subject_day( (int) $row['data']['vol']['y'], $xs[0] ) : 'Confirm · ' . count( $xs ) . ' shifts';
		},
		'button'  => function ( $row ) use ( $items, $word ) {
			return $items( $row ) ? 'Confirm' : $word( 'button', $row, 'Sign in' );
		},
		// Why the tap, on a device that didn't make the sign-up (after the fourth critic, Oct 15).
		'help'    => function ( $row ) use ( $items, $word ) {
			return $items( $row ) ? 'One tap to confirm' : $word( 'help', $row, '' );
		},
		'facts'   => function ( $row ) use ( $items, $word, $prev ) {
			$xs = $items( $row );
			if ( ! $xs ) {
				return isset( $prev['facts'] ) ? call_user_func( $prev['facts'], $row ) : array();
			}
			$y = (int) $row['data']['vol']['y'];
			// The email's layout: Who · When · Where · Committee for one shift (Committee always, unless the
			// job is the committee's name: after the ninth critic, Oct 16); one line a shift, its people
			// named, for several.
			if ( 1 === count( $xs ) ) {
				return array_values( array_filter( array( array( 'Who', $xs[0]['who'] ), array( 'When', ogc_vol_when( $y, $xs[0] ) ), $xs[0]['place_name'] ? array( 'Where', $xs[0]['place_name'] ) : null, ! ogc_vol_same_words( $xs[0]['role'], $xs[0]['committee'] ) ? array( 'Committee', $xs[0]['committee'] ) : null ) ) );
			}
			return array_map( function ( $sh ) use ( $y ) {
				return array( ogc_vol_subject_day( $y, $sh ), ogc_vol_role_shown( $sh['role'], $sh['committee'] ) . ' · ' . ogc_vol_span_of( $sh ) . ( $sh['who'] ? ' · ' . $sh['who'] : '' ) );
			}, $xs );
		},
	) );
	return $kinds;
}, 20 );

/**
 * A volunteer's used Confirm link opened on another device (the signin area's "Link already used" card):
 * the shift it was for, by job and day ("Usher · Sat, May 29"), never who's on it (the email may have
 * been forwarded). After the fifth critic, Oct 15.
 */
add_filter( 'ogc_link_what', function ( $what, $t ) {
	if ( $what || 'confirm' !== $t['kind'] || empty( $t['data']['vol']['y'] ) ) {
		return $what;
	}
	$y      = (int) $t['data']['vol']['y'];
	$shifts = ogc_vol_shifts( $y );
	$out    = array();
	foreach ( array_map( 'intval', isset( $t['data']['vol']['r'] ) ? (array) $t['data']['vol']['r'] : array() ) as $id ) {
		$r = ogc_record_get( $id, true );
		if ( $r && 'signups' === $r['kind'] && $r['email'] === strtolower( (string) $t['email'] ) && isset( $r['data']['id'], $shifts[ $r['data']['id'] ] ) ) {
			$sh = $shifts[ $r['data']['id'] ];
			$out[ $sh['id'] ] = array( $sh['start_ts'], ogc_vol_job_words( $sh['role'], $sh['committee'] ) . ' · ' . ogc_vol_subject_day( $y, $sh ) );
		}
	}
	uasort( $out, function ( $a, $b ) {
		return $a[0] - $b[0];
	} );
	return array_values( wp_list_pluck( $out, 1 ) );
}, 10, 2 );

/**
 * A volunteer's used Confirm link opened on any device (after the sixth critic, Oct 15: on another
 * device it asked for a code, while the same email's Leave link showed the truth anywhere): the same
 * true card as the Leave link's, "Edna left" · "Usher · Sat, May 29 · 9:30 AM–12 PM" · "Harold is still on
 * it", or "Confirmed" with who's on each shift. Only what the email's own Leave link already says: the
 * link's own shifts and the first names of its email's people on them; no phone, no email. A sign-in
 * still takes the code. Filter ogc_link_truth: array( 'h' => …, 'lines' => [ … ] ), or null.
 */
function ogc_vol_link_truth( $year, $email, $ids ) {
	$k = ogc_vol_link_groups( $year, $email, $ids );
	if ( ! $k['groups'] ) {
		return null;
	}
	$shifts = ogc_vol_shifts( $year );
	$first  = function ( $n ) {
		$w = preg_split( '/\s+/', trim( (string) $n ) );
		return $w[0];
	};
	$and    = function ( $a ) {
		$a = array_values( array_unique( $a ) );
		return count( $a ) < 2 ? implode( '', $a ) : implode( ', ', array_slice( $a, 0, -1 ) ) . ' and ' . $a[ count( $a ) - 1 ];
	};
	$still  = function ( $on ) use ( $first, $and ) {
		$ns = array_values( array_unique( array_map( $first, (array) $on ) ) );
		return $ns ? $and( $ns ) . ( count( $ns ) > 1 ? ' are' : ' is' ) . ' still on it' : '';
	};
	$line   = function ( $g, $long ) use ( $year, $shifts ) {
		$sh = $shifts[ $g['shift'] ];
		return ogc_vol_role_shown( $sh['role'], $sh['committee'] ) . ' · ' . ogc_vol_subject_day( $year, $sh ) . ( $long ? ' · ' . ogc_vol_span_of( $sh ) : '' );
	};
	$mine1 = array_filter( $k['gone'], function ( $x ) use ( $k ) {
		return '' !== $k['self'] && 0 === strcasecmp( $x['name'], $k['self'] );
	} );
	$one   = 1 === count( $k['groups'] );
	if ( '' !== $k['self'] && ! $k['self_on'] && $mine1 ) {
		$off = array();
		foreach ( $k['gone'] as $x ) {
			$back = false;
			foreach ( $k['groups'] as $g ) {
				foreach ( $g['on'] as $n ) {
					$back = $back || 0 === strcasecmp( $n, $x['name'] );
				}
			}
			if ( ! $back ) {
				$off[] = $first( $x['name'] );
			}
		}
		$off   = $off ? $off : array( $first( $k['self'] ) );
		$left  = ! array_filter( $mine1, function ( $x ) {
			return 'left' !== $x['how'];
		} );
		$h     = $left ? $and( $off ) . ' left' : 'Off ' . ( $one ? 'this shift' : 'these shifts' ) . ' · ' . $and( $off );
		$lines = $one ? array_values( array_filter( array( $line( $k['groups'][0], true ), $still( $k['groups'][0]['on'] ) ) ) ) : array_map( function ( $g ) use ( $line, $still ) {
			return implode( ' · ', array_filter( array( $line( $g, false ), $still( $g['on'] ) ) ) );
		}, $k['groups'] );
		return array( 'h' => $h, 'lines' => $lines );
	}
	return array( 'h' => 'Confirmed', 'lines' => array_map( function ( $g ) use ( $line, $first, $and ) {
		$on = array_map( $first, $g['on'] );
		return implode( ' · ', array_filter( array( $line( $g, false ), $and( $on ) ) ) ) . ( $g['gone'] ? ' · ' . $and( array_map( $first, wp_list_pluck( $g['gone'], 'name' ) ) ) . ' left' : '' );
	}, $k['groups'] ) );
}
add_filter( 'ogc_link_truth', function ( $truth, $t ) {
	if ( $truth || 'confirm' !== $t['kind'] || empty( $t['data']['vol']['y'] ) ) {
		return $truth;
	}
	return ogc_vol_link_truth( (int) $t['data']['vol']['y'], strtolower( (string) $t['email'] ), isset( $t['data']['vol']['r'] ) ? (array) $t['data']['vol']['r'] : array() );
}, 10, 2 );

/**
 * A volunteer's Confirm link needs no second tap on the device that made the sign-up (this browser's
 * device cookie holds one of its places), or signed in here as that address: the card posts itself from
 * the page (signin.js). Never while someone else is signed in here (that tap changes who's signed in).
 * A GET alone still confirms nothing, so a mail scanner (no device cookie, no sign-in) gets the one-tap
 * card and never taps it. After the fourth critic, Oct 15.
 */
add_filter( 'ogc_link_auto', function ( $auto, $t ) {
	if ( $auto || 'confirm' !== $t['kind'] || empty( $t['data']['vol']['y'] ) ) {
		return $auto;
	}
	if ( is_user_logged_in() ) {
		return ogc_current_email() === strtolower( (string) $t['email'] );
	}
	if ( ! function_exists( 'ogc_device_has' ) ) {
		return false;
	}
	foreach ( array_map( 'intval', (array) ( isset( $t['data']['vol']['r'] ) ? $t['data']['vol']['r'] : array() ) ) as $id ) {
		$r = ogc_record_get( $id );
		if ( $r && $r['email'] === strtolower( (string) $t['email'] ) && ogc_device_has( $id ) ) {
			return true;
		}
	}
	return false;
}, 10, 2 );

/* ================================================================== what the viewer sees */

/** Each shift as anyone may see it, with "you" for this actor's own. */
function ogc_vol_public_shifts( $year, $actor ) {
	$map    = ogc_vol_seat_map( $year );
	$waits  = array();
	foreach ( ogc_records( $year, 'waits' ) as $w ) {
		$id            = isset( $w['data']['id'] ) ? $w['data']['id'] : '';
		$waits[ $id ] = ( isset( $waits[ $id ] ) ? $waits[ $id ] : 0 ) + 1;
	}
	// Once the Conference is over, only how many helped: no names (samples too, so the walk-through
	// draws a past year as a real one looks after its names are cleared), and after the clearing the
	// counts kept for next year's committee.
	$closed = ogc_vol_closed( $year );
	$stats  = ogc_state_get( $year, 'vol-cleared' ) ? ogc_state_get( $year, 'vol-stats' ) : null;
	$stats  = $stats ? (array) $stats['value'] : array();
	$out    = array();
	foreach ( ogc_vol_shifts( $year ) as $id => $sh ) {
		$seats  = isset( $map[ $id ] ) ? $map[ $id ] : array();
		$filled = isset( $stats[ $id ]['filled'] ) ? max( count( $seats ), (int) $stats[ $id ]['filled'] ) : count( $seats );
		$s      = array();
		foreach ( $closed ? array() : $seats as $seat ) {
			$rec = $seat['record'];
			$ok  = ogc_vol_label_ok( $year, $rec );
			$s[] = array(
				$ok ? ogc_vol_first_l( $rec['data']['name'] ) : null,
				$ok ? ogc_vol_initials( $rec['data']['name'] ) : null,
				ogc_vol_owns( $actor, $rec ) ? 1 : 0,
				! empty( $rec['data']['swap'] ) ? (int) $rec['id'] : 0,
				// Your own household's are named to you (Esther, even while hidden from the public).
				ogc_vol_owns( $actor, $rec ) ? (string) $rec['data']['name'] : null,
			);
		}
		$out[ $id ] = array(
			'f'  => $filled,
			'o'  => $sh['unlimited'] ? null : max( 0, $sh['needed'] - $filled ),
			'w'  => isset( $waits[ $id ] ) ? $waits[ $id ] : 0,
			'st' => ogc_vol_shift_state( $year, $sh, $filled ),
			's'  => $s,
		);
	}
	return $out;
}

/** A sign-up as its owner sees it. */
function ogc_vol_mine_out( $rec, $viewer = '' ) {
	$d = $rec['data'];
	return array(
		'rid'       => (int) $rec['id'],
		'shift'     => isset( $d['id'] ) ? $d['id'] : '',
		'name'      => isset( $d['name'] ) ? $d['name'] : '',
		'confirmed' => ! empty( $d['confirmed'] ),
		'hide'      => ! empty( $d['hide'] ),
		// Signed up by someone else in the household: shown publicly only once switched on.
		'for'       => ! empty( $d['for'] ),
		'shown'     => ! empty( $d['show'] ),
		'swap'      => ! empty( $d['swap'] ) ? (int) $rec['id'] . '.' . $d['swap'] : '',
		'at'        => $rec['created_at'],
		'by'        => isset( $d['by'] ) ? $d['by'] : 'self',
		'answer'    => isset( $d['rule']['answer'] ) ? $d['rule']['answer'] : '',
		// Added by someone else under their own email (Add someone): who they are, as typed by the one
		// who added them, so both see "Alex Bowman · Waiting to confirm". Only owners get this view.
		'added'     => ! empty( $d['helper_email'] ) && $rec['email'] !== strtolower( (string) $viewer ),
		'email'     => (string) $rec['email'],
		'nophone'   => empty( $d['phone'] ),
		// Signed up through a contact who isn't on the shift (Oct 15): the contact's name.
		'via'       => ! empty( $d['via'] ) && ! empty( $d['helper'] ) ? (string) $d['helper'] : '',
		// Under 18: never named publicly, so the page offers no Show name for them.
		'minor'     => ! empty( $d['minor'] ),
		// Their age as answered ('u18', '18', '21'; after the sixth critic, Oct 15), so it isn't asked again.
		'band'      => ! empty( $d['band'] ) ? ogc_vol_band_norm( $d['band'] ) : ( ! empty( $d['minor'] ) ? 'u18' : '' ),
		// Confirmed within the last half hour (the page's "Confirmed" line names what was just confirmed).
		'fresh'     => ! empty( $d['confirmed_at'] ) && strtotime( $d['confirmed_at'] ) > ogc_vol_now() - 1800,
		// The shift's calendar event for this email (the same UID as the emails' calendar files).
		'cal'       => isset( $d['id'] ) ? ogc_vol_cal_uid( $rec['email'], $d['id'] ) : '',
		// Would a Leave now reach the committee's head (ogc_vol_leave_tells)? The Leave sheet says "The …
		// head is told" only then (after the eighth critic, Oct 16).
		'tells'     => isset( $d['id'] ) && ogc_vol_leave_tells( ogc_vol_shifts( (int) $rec['year'] )[ $d['id'] ] ?? null, $rec ),
	);
}

/**
 * The people this signed-in person may tick under "Who's helping?" besides themselves and their
 * household: the names on their own email's sign-ups (this year and last) when they registered no
 * household, and everyone they added by email (Add someone). Mechanical: a person is an email and a
 * name; nothing is looked up by name.
 */
function ogc_vol_circle( $year, $actor, $has_household ) {
	if ( ! $actor['signed'] ) {
		return array();
	}
	$me  = $actor['email'];
	$out = array();
	foreach ( array( (int) $year - 1, (int) $year ) as $yy ) {
		foreach ( ogc_records( $yy, 'signups' ) as $r ) {
			$d    = $r['data'];
			$name = isset( $d['name'] ) ? trim( (string) $d['name'] ) : '';
			// Only names their email confirmed (or that they added themselves, signed in).
			if ( '' === $name || false === strpos( $name, ' ' ) || ( $r['email'] === $me && ! ogc_vol_rec_confirmed( $r ) ) ) {
				continue;
			}
			// Each with their age as answered on a sign-up (after the sixth critic, Oct 15), not asked again.
			$band = ! empty( $d['band'] ) ? ogc_vol_band_norm( $d['band'] ) : ( ! empty( $d['minor'] ) ? 'u18' : '' );
			if ( $r['email'] === $me && empty( $d['helper_email'] ) && ! $has_household ) {
				$k         = 'n:' . strtolower( $name );
				$out[ $k ] = array( 'name' => $name, 'band' => $band ? $band : ( isset( $out[ $k ]['band'] ) ? $out[ $k ]['band'] : '' ) );
			} elseif ( ! empty( $d['helper_email'] ) && strtolower( (string) $d['helper_email'] ) === $me && $r['email'] !== $me ) {
				$k         = 'e:' . $r['email'] . '|' . strtolower( $name );
				$out[ $k ] = array( 'name' => $name, 'email' => $r['email'], 'band' => $band ? $band : ( isset( $out[ $k ]['band'] ) ? $out[ $k ]['band'] : '' ) );
			}
		}
	}
	return array_values( $out );
}

/** A signed-in person's own email's places still unconfirmed that aren't theirs yet (another device
 * made them), still ahead: [{ rid, shift, name }]. */
function ogc_vol_pending( $year, $actor ) {
	$out = array();
	if ( ! $actor['signed'] || '' === $actor['email'] ) {
		return $out;
	}
	$shifts = ogc_vol_shifts( $year );
	foreach ( ogc_records( $year, 'signups', $actor['email'] ) as $r ) {
		if ( ! empty( $r['data']['confirmed'] ) || ogc_vol_owns( $actor, $r ) || ! isset( $r['data']['id'], $shifts[ $r['data']['id'] ] ) || ogc_vol_now() >= $shifts[ $r['data']['id'] ]['start_ts'] ) {
			continue;
		}
		$out[] = array( 'rid' => (int) $r['id'], 'shift' => (string) $r['data']['id'], 'name' => (string) $r['data']['name'] );
	}
	return $out;
}

/** This actor's sign-ups and waits for the year. */
function ogc_vol_mine( $year, $actor, $kind = 'signups' ) {
	$out = array();
	foreach ( ogc_records( $year, $kind ) as $r ) {
		if ( ogc_vol_owns( $actor, $r ) ) {
			$out[] = 'signups' === $kind ? ogc_vol_mine_out( $r, $actor['email'] ?: ( $actor['holds'] ? reset( $actor['holds'] ) : '' ) ) : array( 'rid' => (int) $r['id'], 'shift' => isset( $r['data']['id'] ) ? $r['data']['id'] : '', 'name' => isset( $r['data']['name'] ) ? $r['data']['name'] : '' );
		}
	}
	return $out;
}

/** The household as the registration knows it: each person who may help (12 and up, or a Young Folk),
 * how old as far as it says, and the days each is here. */
function ogc_vol_household( $year, $email ) {
	$reg = ogc_vol_registration( $year, $email );
	if ( ! $reg || empty( $reg['people'] ) ) {
		return null;
	}
	$days  = ogc_vol_days( $year );
	$names = array_column( $days, 'name' );
	$out   = array();
	foreach ( (array) $reg['people'] as $p ) {
		// Who may help: everyone 10 and up (kit packing takes preteens); not babies or young children.
		$num = isset( $p['age'] ) && is_numeric( $p['age'] ) ? (int) $p['age'] : null;
		$kid = ( isset( $p['band'] ) && in_array( $p['band'], array( 'child', 'baby' ), true ) ) || ( isset( $p['kind'] ) && 'child' === $p['kind'] );
		if ( empty( $p['name'] ) || ( $kid && ( null === $num || $num < 10 ) ) ) {
			continue;
		}
		$age = ogc_vol_age_of( $reg, $p['name'] );
		// The nights each person is here, else the household's; a day guest any day.
		$ns  = ! empty( $p['nights'] ) ? (array) $p['nights'] : ( isset( $reg['stay']['nights'] ) ? (array) $reg['stay']['nights'] : array() );
		$ns  = array_values( array_filter( $ns, function ( $n ) { return 0 !== strpos( $n, 'Early ' ); } ) );
		$here = array();
		if ( $ns && ( ! isset( $reg['stay']['type'] ) || 'elsewhere' !== $reg['stay']['type'] ) ) {
			$a = ogc_vol_find_day( $days, $ns[0] );
			$b = ogc_vol_find_day( $days, $ns[ count( $ns ) - 1 ] );
			if ( $a > -1 && $b > -1 ) {
				for ( $i = $a; $i <= min( $b + 1, count( $days ) - 1 ); $i++ ) {
					$here[] = $days[ $i ]['date'];
				}
			}
		}
		// Their age as a band (the registration's, or an answer on a sign-up: ogc_vol_band_find).
		$out[] = array( 'name' => $p['name'], 'age' => $age, 'years' => $num, 'yf' => ! empty( $p['yf'] ), 'band' => ogc_vol_band_find( $year, $email, $p['name'] ), 'days' => $here ?: array_column( $days, 'date' ) );
	}
	return array( 'people' => $out, 'phone' => isset( $reg['household']['phone'] ) ? $reg['household']['phone'] : '' );
}

/**
 * A person's phone for the year, by an exact email match only (after the third critic, Oct 15: Daniel's
 * came from last year's sign-up, 555-0100, over this year's registration, 765-555-0142, and was gone
 * once he'd left his last shift). In this order, only what their email confirmed:
 *   1. the phone they gave the volunteer page this year (typed with a sign-up, or Changed on their own
 *      pill: phone_set), on a place they hold or one they've left since;
 *   2. this year's registration's own phone (theirs, not one a helper filled in for them);
 *   3. any of this year's places or waits, held or left;
 *   4. last year's places.
 * $cached: the head's list asks once per address per request.
 */
function ogc_vol_known_phone( $year, $email, $cached = false ) {
	global $wpdb;
	static $memo = array();
	$email = strtolower( trim( (string) $email ) );
	$k     = (int) $year . '|' . $email;
	if ( $cached && isset( $memo[ $k ] ) ) {
		return $memo[ $k ];
	}
	if ( ! is_email( $email ) ) {
		return '';
	}
	$set  = '';
	$any  = '';
	$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT data FROM ' . ogc_table( 'records' ) . " WHERE year = %d AND kind IN ('signups', 'waits') AND email = %s ORDER BY id", (int) $year, $email ), ARRAY_A );
	foreach ( (array) $rows as $row ) {
		$d = (array) ogc_unjson( $row['data'], array() );
		if ( empty( $d['confirmed'] ) || empty( $d['phone'] ) ) {
			continue;
		}
		if ( ! empty( $d['phone_set'] ) ) {
			$set = (string) $d['phone'];
		} else {
			$any = (string) $d['phone'];
		}
	}
	$out = $set;
	if ( '' === $out ) {
		foreach ( ogc_records( $year, 'registrations', $email ) as $r ) {
			if ( $r['email'] === $email && ! empty( $r['data']['household']['phone'] ) && 'cancelled' !== ( isset( $r['data']['status'] ) ? $r['data']['status'] : '' ) ) {
				$out = (string) $r['data']['household']['phone'];
			}
		}
	}
	if ( '' === $out ) {
		$out = $any;
	}
	if ( '' === $out ) {
		foreach ( array_filter( ogc_records( (int) $year - 1, 'signups', $email ), 'ogc_vol_rec_confirmed' ) as $r ) {
			$out = ! empty( $r['data']['phone'] ) ? (string) $r['data']['phone'] : $out;
		}
	}
	$out          = '' === $out ? '' : ogc_vol_phone_shown( $out );
	$memo[ $k ] = $out;
	return $out;
}

/** A whole name ("Daniel Hoover"), not a short one ("Daniel", "Daniel H."). */
function ogc_vol_whole_name( $n ) {
	$n = trim( preg_replace( '/\s+/', ' ', (string) $n ) );
	return (bool) preg_match( '/^\S+( \S+)+$/', $n ) && ! preg_match( '/ \S\.?$/', $n ) && false === strpos( $n, '@' );
}

/**
 * The email's own person, by name (after the fifth critic, Oct 15): who a sign-up under this email is
 * for when nobody typed a "who" (an emailed link vouching for the email). The account's own whole name
 * (the signin area's), else the name on that email's own latest sign-up (made by them: not for someone
 * else, not added by another), this year or last. '' when nothing says. An exact email match only.
 */
function ogc_vol_self_name( $year, $email ) {
	static $memo = array();
	$email = strtolower( trim( (string) $email ) );
	$k     = (int) $year . '|' . $email;
	if ( isset( $memo[ $k ] ) ) {
		return $memo[ $k ];
	}
	$name = '';
	if ( is_email( $email ) ) {
		$u = get_user_by( 'email', $email );
		$n = $u ? ( function_exists( 'ogc_person_name' ) ? ogc_person_name( $u->ID ) : $u->display_name ) : '';
		if ( ogc_vol_whole_name( $n ) ) {
			$name = trim( preg_replace( '/\s+/', ' ', $n ) );
		}
		foreach ( '' === $name ? array( (int) $year, (int) $year - 1 ) : array() as $yy ) {
			foreach ( array_reverse( ogc_records( $yy, 'signups', $email ) ) as $r ) {
				$d = $r['data'];
				if ( empty( $d['for'] ) && empty( $d['helper_email'] ) && 'self' === ( isset( $d['by'] ) ? $d['by'] : 'self' ) && ogc_vol_rec_confirmed( $r ) && ogc_vol_whole_name( isset( $d['name'] ) ? $d['name'] : '' ) ) {
					$name = trim( $d['name'] );
					break 2;
				}
			}
		}
	}
	$memo[ $k ] = $name;
	return $name;
}

/**
 * A name kept from last year as a first name only (the clearing keeps first names for those who asked to
 * hear next year) made whole from this email's own people, by an exact first-name match: the account's
 * own name, else one person of this year's registration under the email (only when exactly one has
 * that first name). Otherwise as it was. Nothing is looked up across other people's emails.
 */
function ogc_vol_whole_of( $year, $email, $name ) {
	$name = trim( (string) $name );
	if ( '' === $name || false !== strpos( $name, ' ' ) ) {
		return $name;
	}
	$self = ogc_vol_self_name( $year, $email );
	$fn   = function ( $n ) {
		$w = preg_split( '/\s+/', trim( (string) $n ) );
		return strtolower( $w[0] );
	};
	if ( '' !== $self && $fn( $self ) === strtolower( $name ) ) {
		return $self;
	}
	$reg  = ogc_vol_registration( $year, $email );
	$hits = array();
	foreach ( $reg && ! empty( $reg['people'] ) ? (array) $reg['people'] : array() as $p ) {
		if ( ! empty( $p['name'] ) && ogc_vol_whole_name( $p['name'] ) && $fn( $p['name'] ) === strtolower( $name ) ) {
			$hits[] = trim( $p['name'] );
		}
	}
	return 1 === count( array_unique( $hits ) ) ? $hits[0] : $name;
}

/**
 * Last year's shifts as this email can take them now (the page's "Your 2026 shifts" card and the
 * "Sign-ups open" email's link; after the fifth critic, Oct 15). Each entry of ogc_vol_again() with this
 * year's shift adds, mechanically:
 *   people   the names on it last year from this email (whole: ogc_vol_whole_of)
 *   st, o    the shift's state and open places now (o null: no limit)
 *   on       those of people already on it this year (under this email)
 *   busy     name → "Usher 1:30–3 PM", for those on another shift then
 *   under    those the registration says are too young for its rule (a count of years, or Under 18)
 *   aged     those whose age the registration already answers for its rule
 *   waiting  those already on its waitlist
 *   rule, min_age, question, screening   what it asks
 * Entries with no shift this year keep only was (said as "Not this year").
 */
function ogc_vol_again_view( $year, $email, $again = null ) {
	$email  = strtolower( (string) $email );
	$again  = null === $again ? ogc_vol_again( $year, $email ) : $again;
	$shifts = ogc_vol_shifts( $year );
	$map    = ogc_vol_seat_map( $year );
	$waits  = ogc_records( $year, 'waits', $email );
	$out    = array();
	foreach ( (array) $again as $a ) {
		$id = isset( $a['shift'] ) ? $a['shift'] : '';
		if ( ! $id || ! isset( $shifts[ $id ] ) ) {
			$out[] = array( 'shift' => null, 'names' => (array) $a['names'], 'people' => array(), 'was' => $a['was'] );
			continue;
		}
		$sh     = $shifts[ $id ];
		$seats  = isset( $map[ $id ] ) ? $map[ $id ] : array();
		$people = array_values( array_unique( array_map( function ( $n ) use ( $year, $email ) {
			return ogc_vol_whole_of( $year, $email, $n );
		}, (array) $a['names'] ) ) );
		$on     = array();
		foreach ( $seats as $s ) {
			$r = $s['record'];
			if ( $r['email'] === $email && isset( $r['data']['name'] ) ) {
				foreach ( $people as $n ) {
					if ( 0 === strcasecmp( trim( $r['data']['name'] ), $n ) ) {
						$on[] = $n;
					}
				}
			}
		}
		$busy = array();
		$under = array();
		$aged = array();
		$waiting = array();
		foreach ( $people as $n ) {
			if ( in_array( $n, $on, true ) ) {
				continue;
			}
			$b = ogc_vol_busy( $year, $sh, ogc_vol_pkey( $email, $n ) );
			if ( $b ) {
				$busy[ $n ] = ogc_vol_role_shown( $b['role'], $b['committee'] ) . ' ' . ogc_vol_span( (int) $b['start'], (int) $b['end'] );
			}
			if ( $sh['min_age'] ) {
				// By each one's age (the registration's, or an answer this year; after the sixth critic).
				$ok = ogc_vol_band_ok( ogc_vol_band_find( $year, $email, $n ), $sh['min_age'] );
				if ( false === $ok ) {
					$under[] = $n;
				} elseif ( true === $ok ) {
					$aged[] = $n;
				}
			}
			foreach ( $waits as $w ) {
				if ( isset( $w['data']['id'] ) && $w['data']['id'] === $id && 0 === strcasecmp( trim( (string) $w['data']['name'] ), $n ) ) {
					$waiting[] = $n;
				}
			}
		}
		$filled = count( $seats );
		$bands  = array();
		foreach ( $people as $n ) {
			$bands[ $n ] = ogc_vol_band_find( $year, $email, $n );
		}
		$out[]  = array(
			'shift'     => $id,
			'names'     => (array) $a['names'],
			'people'    => $people,
			// Each one's age where it's known ('u18', '18', '21', 'adult' or ''): asked once, not per row.
			'bands'     => (object) $bands,
			'was'       => $a['was'],
			'st'        => ogc_vol_shift_state( $year, $sh, $filled ),
			'o'         => $sh['unlimited'] ? null : max( 0, $sh['needed'] - $filled ),
			'on'        => array_values( array_unique( $on ) ),
			'busy'      => (object) $busy,
			'under'     => $under,
			'aged'      => $aged,
			'waiting'   => array_values( array_unique( $waiting ) ),
			'rule'      => (string) $sh['rule'],
			'min_age'   => (int) $sh['min_age'],
			'question'  => array_values( (array) $sh['question'] ),
			'screening' => ! empty( $sh['screening'] ),
		);
	}
	return $out;
}

/** Last year's shifts again: each matched to this year's by its lasting uid, else by committee, job and
 * weekday with the start within 90 minutes (a lunch moved by a quarter hour is still lunch). */
function ogc_vol_again( $year, $email ) {
	if ( ! $email ) {
		return array();
	}
	$prev = (int) $year - 1;
	$old  = array();
	$then = ogc_vol_shifts( $prev );
	foreach ( array_filter( ogc_records( $prev, 'signups', $email ), 'ogc_vol_rec_confirmed' ) as $r ) {
		$id = isset( $r['data']['id'] ) ? $r['data']['id'] : '';
		if ( isset( $then[ $id ] ) ) {
			$o        = $then[ $id ];
			$old[]    = array( 'uid' => $o['uid'], 'committee' => $o['committee'], 'role' => $o['role'], 'day' => $o['day'], 'start' => $o['start'], 'end' => $o['end'], 'name' => $r['data']['name'] );
		}
	}
	// Kept past the clearing for those who asked (Email me when next year's sign-ups open).
	$kept = ogc_state_get( $year, 'vol-return' );
	foreach ( $kept ? (array) $kept['value'] : array() as $k ) {
		if ( isset( $k['email'] ) && $k['email'] === $email ) {
			foreach ( (array) $k['patterns'] as $p ) {
				$old[] = $p;
			}
		}
	}
	$now = ogc_vol_shifts( $year );
	$out = array();
	foreach ( $old as $o ) {
		$best = null;
		$gap  = 91;
		foreach ( $now as $id => $sh ) {
			if ( 0 !== strcasecmp( $sh['day'], $o['day'] ) ) {
				continue;
			}
			if ( $o['uid'] && $sh['uid'] === $o['uid'] ) {
				$best = $id;
				break;
			}
			if ( 0 === strcasecmp( $sh['committee'], $o['committee'] ) && 0 === strcasecmp( $sh['role'], $o['role'] ) && abs( $sh['start'] - $o['start'] ) < $gap ) {
				$gap  = abs( $sh['start'] - $o['start'] );
				$best = $id;
			}
		}
		$key = $best ? $best : 'x:' . $o['committee'] . '|' . $o['role'] . '|' . $o['day'];
		if ( ! isset( $out[ $key ] ) ) {
			// As it was: its real end when kept (patterns kept before Oct 10 have none: the part of the day).
			$was         = isset( $o['end'] ) ? ogc_vol_span( (int) $o['start'], (int) $o['end'] ) : ( $o['start'] < 720 ? 'morning' : ( $o['start'] < 1020 ? 'afternoon' : 'evening' ) );
			$out[ $key ] = array( 'shift' => $best, 'names' => array(), 'was' => ogc_vol_job_words( $o['role'], $o['committee'] ) . ' · ' . $o['day'] . ' ' . $was );
		}
		if ( ! in_array( $o['name'], $out[ $key ]['names'], true ) ) {
			$out[ $key ]['names'][] = $o['name'];
		}
	}
	return array_values( $out );
}

function ogc_vol_rest_live( WP_REST_Request $req ) {
	$y = (int) $req['year'];
	ogc_vol_prepare_year( $y );
	$actor = ogc_vol_actor( $req );
	$email = $actor['email'] ?: ( $actor['holds'] ? reset( $actor['holds'] ) : '' );
	$mine  = ogc_vol_mine( $y, $actor );
	$u     = wp_get_current_user();
	// The phone and name they last gave (theirs only), so they aren't asked again. Someone not signed in
	// gets only what's in the records this device holds: an email typed is not proof, and other records
	// under it (last year's, a later sign-up by the real owner) may be someone else's.
	$phone = '';
	$name  = $u && $u->ID ? ( function_exists( 'ogc_person_name' ) ? ogc_person_name( $u->ID ) : $u->display_name ) : '';
	// Signed in: only what their email confirmed (a sign-up someone else typed their address into gives
	// them no phone, name or people until then).
	$own   = $actor['signed'] && $email
		? array_filter( array_merge( ogc_records( $y - 1, 'signups', $email ), ogc_records( $y, 'waits', $email ), ogc_records( $y, 'signups', $email ) ), 'ogc_vol_rec_confirmed' )
		: array_filter( array_merge( ogc_records( $y, 'waits' ), ogc_records( $y, 'signups' ) ), function ( $r ) use ( $actor ) {
			return ogc_vol_owns( $actor, $r );
		} );
	if ( $actor['signed'] ) {
		// This year's own first (after the third critic, Oct 15): ogc_vol_known_phone().
		$phone = ogc_vol_known_phone( $y, $email );
	} else {
		foreach ( $own as $r ) {
			$phone = ! empty( $r['data']['phone'] ) ? $r['data']['phone'] : $phone;
		}
		// Coming back on the same tab after leaving (after the fifth critic, Oct 15: Abe's name and email
		// were kept and his phone was blank): the phone typed with the places this tab made, left or not,
		// under the same email (its hold). The one chosen with a sign-up first.
		if ( '' === $phone && $actor['holds'] ) {
			$set = '';
			foreach ( array_slice( array_keys( $actor['holds'] ), 0, 20 ) as $rid ) {
				$r = ogc_record_get( (int) $rid, true );
				if ( $r && in_array( $r['kind'], array( 'signups', 'waits' ), true ) && (int) $r['year'] === $y && $r['email'] === $actor['holds'][ $rid ] && empty( $r['data']['helper_email'] ) && ! empty( $r['data']['phone'] ) ) {
					$phone = (string) $r['data']['phone'];
					$set   = ! empty( $r['data']['phone_set'] ) ? $phone : $set;
				}
			}
			$phone = '' !== $set ? $set : $phone;
		}
	}
	// (A registration a helper filled in for this address gives no phone: an exact email match only.)
	$hh = $actor['signed'] ? ogc_vol_household( $y, $email ) : null;
	$wall = ogc_vol_wall( $y );
	$coms = array();
	$closed = ogc_vol_closed( $y );
	foreach ( ogc_vol_committees( $y ) as $c ) {
		// A closed year has no one to call about it.
		// The committee's one instruction for every shift ("Meet in the chapel 30 minutes early"): the
		// head's or the COA's words, public like a shift's note (CHANGES/volunteer-vs-sug.md).
		$coms[] = array( 'name' => $c['name'], 'phone' => $closed ? '' : ogc_vol_phone_shown( $c['contact_phone'] ), 'contact' => '' !== $c['contact_email'], 'instruction' => $closed ? '' : trim( (string) $c['instruction'] ) );
	}
	$first = null;
	foreach ( $mine as $m ) {
		if ( ! $m['for'] ) {
			$first = $m;
			break;
		}
	}
	return rest_ensure_response( array(
		'year'       => $y,
		'posted'     => ogc_vol_posted( $y ),
		'closed'     => $closed,
		// Unconfirmed places are let go after this many hours (said under "Check your email").
		'confirm_hours' => ogc_vol_confirm_hours( $y ),
		'closes'     => ogc_vol_close_date( $y ),
		// The day sign-ups open, once the COA has set one (never an expected date).
		'opens'      => ogc_vol_opens( $y ),
		'names'      => ogc_vol_names_shown( $y ),
		'now'        => $wall,
		'nonce'      => wp_create_nonce( 'wp_rest' ),
		'shifts'     => (object) ogc_vol_public_shifts( $y, $actor ),
		'committees' => $coms,
		'me'         => $actor['signed'] || $actor['holds'] ? array(
			'email'     => $email,
			'name'      => $actor['signed'] ? $name : '',
			'phone'     => $phone,
			'signed'    => $actor['signed'],
			'show'      => $first ? ! $first['hide'] : true,
			// Their own age as answered before (or the registration's), so it's asked once (after the
			// sixth critic, Oct 15). Signed in only: a visitor's comes with the places this tab holds.
			'band'      => $actor['signed'] && ogc_vol_whole_name( $name ) ? ogc_vol_band_find( $y, $email, $name ) : '',
			'next_year' => (bool) array_filter( $own, function ( $r ) use ( $y ) { return 'signups' === $r['kind'] && (int) $r['year'] === $y && ! empty( $r['data']['next_year'] ); } ),
			'lead'      => $actor['signed'] && ogc_vol_can_lead( $y ),
			'member'    => $actor['signed'] && ogc_is_member( $y ),
		) : null,
		'mine'       => $mine,
		// Signed in: this email's places still waiting for its Confirm that another device made (after the
		// eighth critic, Oct 16: Hannah's second place showed "3 of 4 open · Sign up", and Sign up said
		// "Already signed up"). Shown as hers, "Waiting to confirm" with Resend; never her phone, her people
		// or her name list (round 1's rule: someone else may have typed the address).
		'pending'    => $actor['signed'] ? ogc_vol_pending( $y, $actor ) : array(),
		// A closed year: how many different people helped, all and per committee (never places).
		'helped'     => $closed ? ogc_vol_people_shown( $y ) : null,
		'waits'      => ogc_vol_mine( $y, $actor, 'waits' ),
		'household'  => $hh,
		'circle'     => ogc_vol_circle( $y, $actor, (bool) $hh ),
		// Last year's shifts as this person can take them now (the page's "Your 2026 shifts" card; after
		// the fifth critic, Oct 15): each with its people, state, who's on it or Busy (ogc_vol_again_view).
		'again'      => $actor['signed'] ? ogc_vol_again_view( $y, $email ) : array(),
	) );
}

/* ================================================================== joining */

/** The person's name from the form: "First Last", trimmed. */
function ogc_vol_clean_name( $s ) {
	return mb_substr( trim( preg_replace( '/\s+/', ' ', sanitize_text_field( (string) $s ) ) ), 0, 80 );
}

function ogc_vol_clean_phone( $s ) {
	$s = mb_substr( trim( sanitize_text_field( (string) $s ) ), 0, 32 );
	// Kept the one way (765-555-0123) when it's a US number; anything else as typed.
	return strlen( preg_replace( '/\D+/', '', $s ) ) >= 7 ? ogc_vol_phone_shown( $s ) : '';
}

/**
 * Join one or more shifts.
 * Body: { shifts: [id…] (or shift), people: [names] (under this email: the person, their household;
 *   signed in, exactly those given, which may be none when only others are added; default the person),
 *   add: [{ name, email, minor? }] (Add someone, Oct 13: each under their own email, held until they
 *   confirm; your own email: one of yours), who: { first, last, email, phone, minor? } (not signed in;
 *   minor: the Under 18 box, after the critic; helping: false, "For someone else" (Michael, Oct 15): the
 *   person is the contact only, not on the shift, and only those added go on), for_other: { name, phone } (signing someone
 *   else up), phone, answers: { rule: true | [names], question, screened }, note, show, next_year,
 *   t (an emailed link that vouches for the email), hp (left empty by people) }
 * Each shift is its own result; on one shift the people (and those added) go on all together or not
 * at all.
 */
function ogc_vol_rest_join( WP_REST_Request $req ) {
	$y = (int) $req['year'];
	ogc_vol_prepare_year( $y );
	if ( '' !== (string) $req->get_param( 'hp' ) ) {
		return rest_ensure_response( array( 'results' => array(), 'mine' => array() ) );
	}
	// Per address: a campus's shared wifi is many people, so the limit is generous (filterable).
	if ( ! ogc_vol_rate( 'join|' . ogc_vol_ip(), (int) apply_filters( 'ogc_vol_joins_per_hour', 120 ) ) ) {
		return ogc_vol_no( 'slow', 'Too many sign-ups at once. Try again later.', array(), 429 );
	}
	$actor = ogc_vol_actor( $req );
	$who   = (array) $req->get_param( 'who' );
	$link  = ogc_vol_link_of( $req );
	$errs  = array();
	if ( $actor['signed'] ) {
		$email     = $actor['email'];
		$confirmed = true;
	} elseif ( $link && in_array( $link['a'], array( 'opened', 'again', 'confirm' ), true ) ) {
		$email     = strtolower( (string) $link['e'] );
		$confirmed = true;
	} else {
		$email = strtolower( sanitize_email( isset( $who['email'] ) ? $who['email'] : '' ) );
		if ( ! is_email( $email ) ) {
			$errs['email'] = 'Enter your email';
		}
		$confirmed = false;
	}
	$first  = ogc_vol_clean_name( isset( $who['first'] ) ? $who['first'] : '' );
	$last   = ogc_vol_clean_name( isset( $who['last'] ) ? $who['last'] : '' );
	$typed  = trim( $first . ' ' . $last );
	$u      = wp_get_current_user();
	$known  = $u && $u->ID ? ( function_exists( 'ogc_person_name' ) ? ogc_person_name( $u->ID ) : $u->display_name ) : '';
	$myname = $typed ?: ( $actor['signed'] && ogc_vol_whole_name( $known ) ? trim( $known ) : '' );
	$phone  = ogc_vol_clean_phone( isset( $who['phone'] ) ? $who['phone'] : $req->get_param( 'phone' ) );
	$other  = (array) $req->get_param( 'for_other' );
	$people = array_values( array_unique( array_filter( array_map( 'ogc_vol_clean_name', (array) $req->get_param( 'people' ) ) ) ) );
	// Several shifts, each with its own people and answers, in one request (after the seventh critic,
	// Oct 15: the returner card made one request a shift, and closing the tab part way left some unsaved):
	// each [{ shift, people, answers?, bands? }]. For an email already vouched for (signed in, or an emailed
	// link) only. The server takes every shift before it answers; each is answered on its own (Full, Busy),
	// as several shifts always were.
	$each = array();
	foreach ( array_slice( array_filter( (array) $req->get_param( 'each' ), 'is_array' ), 0, 12 ) as $e ) {
		$sid = isset( $e['shift'] ) ? (string) $e['shift'] : '';
		$pp  = array_slice( array_values( array_unique( array_filter( array_map( 'ogc_vol_clean_name', isset( $e['people'] ) ? (array) $e['people'] : array() ) ) ) ), 0, 10 );
		if ( '' === $sid || ! $pp || isset( $each[ $sid ] ) ) {
			continue;
		}
		$each[ $sid ] = array( 'people' => $pp, 'answers' => isset( $e['answers'] ) && is_array( $e['answers'] ) ? $e['answers'] : array(), 'bands' => isset( $e['bands'] ) && is_array( $e['bands'] ) ? $e['bands'] : array() );
	}
	if ( $each ) {
		if ( ! $actor['signed'] && ! $confirmed ) {
			return ogc_vol_no( 'fields', 'Check the form.', array( 'fields' => array( 'each' => 'Sign in first' ) ), 400 );
		}
		$people = array();
		foreach ( $each as $e ) {
			$people = array_values( array_unique( array_merge( $people, $e['people'] ) ) );
		}
	}
	if ( ! empty( $other['name'] ) ) {
		$people = array( ogc_vol_clean_name( $other['name'] ) );
		$phone  = ogc_vol_clean_phone( isset( $other['phone'] ) ? $other['phone'] : '' );
		if ( ! $phone ) {
			$errs['other_phone'] = 'Enter their phone';
		}
	}
	// Add someone: a name and their own email. A person is their email and name (the same email as
	// this one: someone under it, like a household). Nothing is looked up by name.
	$adds = array();
	// Under 18 (the first-time form's box, or Add someone's): a fixed field, never a guess. Such a
	// person is never named publicly and an age rule of 18 or more refuses them (after the critic).
	$yes    = function ( $v ) {
		return true === $v || 1 === $v || '1' === $v || 'true' === $v;
	};
	$minors = array();
	// Each person's age (after the sixth critic, Oct 15), one plain fixed field: Under 18 · 18–20 · 21 or
	// older ('u18', '18', '21'), by name: who.band (the person typed), add[].band, bands { name: band }
	// for those under this email. Kept on each sign-up; Under 18 is also the old minor mark.
	$bands = array();
	$bsent = (array) $req->get_param( 'bands' );
	foreach ( $each as $e ) {
		$bsent = array_merge( $e['bands'], $bsent );
	}
	foreach ( $bsent as $bn => $bv ) {
		$bn = strtolower( ogc_vol_clean_name( $bn ) );
		if ( '' !== $bn && ogc_vol_band_norm( $bv ) ) {
			$bands[ $bn ] = ogc_vol_band_norm( $bv );
		}
	}
	if ( $typed && isset( $who['band'] ) && ogc_vol_band_norm( $who['band'] ) ) {
		$bands[ strtolower( $typed ) ] = ogc_vol_band_norm( $who['band'] );
	}
	if ( isset( $who['minor'] ) && $yes( $who['minor'] ) && $typed ) {
		$minors[] = strtolower( $typed );
	}
	foreach ( array_slice( array_filter( (array) $req->get_param( 'add' ), 'is_array' ), 0, 6 ) as $a ) {
		$an = ogc_vol_clean_name( isset( $a['name'] ) ? $a['name'] : '' );
		$ae = strtolower( sanitize_email( isset( $a['email'] ) ? $a['email'] : '' ) );
		if ( '' === $an || false === strpos( $an, ' ' ) ) {
			$errs['add'] = 'First and last name';
			continue;
		}
		if ( ! is_email( $ae ) ) {
			$errs['add'] = 'Check their email';
			continue;
		}
		if ( isset( $a['minor'] ) && $yes( $a['minor'] ) ) {
			$minors[] = strtolower( $an );
		}
		if ( isset( $a['band'] ) && ogc_vol_band_norm( $a['band'] ) ) {
			$bands[ strtolower( $an ) ] = ogc_vol_band_norm( $a['band'] );
		}
		if ( $ae === $email ) {
			$people[] = $an;
			continue;
		}
		$adds[ $ae . '|' . strtolower( $an ) ] = array( 'name' => $an, 'email' => $ae );
	}
	$people = array_values( array_unique( $people ) );
	// "For someone else" (Michael, Oct 15: a district helper signs up others without being on the shift):
	// the person typed is the contact (name, email, phone), never counted or put on the shift; only those
	// added go on, under the contact's email ("Uses my email") or their own.
	$helping = ! ( array_key_exists( 'helping', $who ) && in_array( $who['helping'], array( false, 0, '0', 'false', 'no' ), true ) );
	// Not signed in (the first time): always themselves, plus anyone added. Unless this device already
	// holds their own place on every shift asked (Add someone on a shift they're on, after the critic):
	// then only those added go on, and their name and phone are that place's.
	$anon = ! $actor['signed'] && ! $confirmed;
	$on   = false;
	if ( $anon && is_email( $email ) ) {
		$want = $req->get_param( 'shifts' );
		$want = array_values( array_filter( array_map( 'strval', is_array( $want ) ? $want : array( (string) $req->get_param( 'shift' ) ) ) ) );
		$held = array();
		foreach ( ogc_records( $y, 'signups', $email ) as $r ) {
			if ( empty( $r['data']['helper_email'] ) && empty( $r['data']['for'] ) && ogc_vol_owns( $actor, $r ) ) {
				$held[ (string) $r['data']['id'] ] = $r;
			}
		}
		$on = $want && $held && ! array_diff( $want, array_keys( $held ) ) && ( $people || $adds );
		if ( $on ) {
			$h0     = $held[ $want[0] ];
			$myname = $myname ? $myname : (string) $h0['data']['name'];
			$phone  = $phone ? $phone : (string) $h0['data']['phone'];
			$people = array_values( array_filter( $people, function ( $n ) use ( $myname ) {
				return 0 !== strcasecmp( $n, $myname );
			} ) );
			unset( $errs['email'] );
		}
	}
	if ( $anon && ! $on && empty( $other['name'] ) && $myname && $helping && ! in_array( $myname, $people, true ) ) {
		array_unshift( $people, $myname );
	}
	if ( ! $helping ) {
		// The contact's own name is asked (the head sees "via Martha Fry"); someone must be going on.
		$people = array_values( array_filter( $people, function ( $n ) use ( $myname ) {
			return 0 !== strcasecmp( $n, $myname );
		} ) );
		if ( ! $myname ) {
			$errs['first'] = $first ? '' : 'Enter your first name';
			$errs['last']  = $last ? '' : 'Enter your last name';
		}
		if ( ! $people && ! $adds ) {
			$errs['people'] = 'Add someone';
		}
	} elseif ( ! $people && ( ! $adds || ( $anon && ! $on ) ) ) {
		if ( ! $myname ) {
			$errs['first'] = $first ? '' : 'Enter your first name';
			$errs['last']  = $last ? '' : 'Enter your last name';
		}
		$people = array( $myname );
	}
	if ( $adds && ! ogc_vol_rate( 'add|' . ogc_vol_ip(), (int) apply_filters( 'ogc_vol_adds_per_hour', 40 ) ) ) {
		return ogc_vol_no( 'slow', 'Too many sign-ups at once. Try again later.', array(), 429 );
	}
	// The email is known to be theirs (signed in, or an emailed link): a phone they gave before will do.
	// Only those under this email need it (someone added gives theirs when they confirm).
	$vouched = $actor['signed'] || $confirmed;
	if ( ! $phone && ! $vouched && empty( $other['name'] ) ) {
		$errs['phone'] = 'Enter a phone number';
	}
	// A phone typed with this sign-up (or Changed on their own pill) is the one they chose for the year:
	// marked so, it's kept over the registration's (phone_set; after the third critic, Oct 15).
	$phone_set = '' !== $phone;
	if ( ! $phone && $vouched && $people ) {
		// A known phone, by an exact email match (ogc_vol_known_phone): this year's own first, then the
		// registration's, then last year's. Never one typed by someone not signed in with their address
		// (after the critic, Oct 15).
		$phone = ogc_vol_known_phone( $y, $email );
		if ( ! $phone ) {
			$errs['phone'] = 'Enter a phone number';
		}
	}
	$errs = array_filter( $errs );
	if ( $errs ) {
		return ogc_vol_no( 'fields', 'Check the form.', array( 'fields' => $errs ), 400 );
	}
	$ids = $each ? array_keys( $each ) : $req->get_param( 'shifts' );
	$ids = is_array( $ids ) ? $ids : array( (string) $req->get_param( 'shift' ) );
	$ids = array_slice( array_values( array_unique( array_filter( array_map( 'strval', $ids ) ) ) ), 0, 12 );
	// A household at most on one sign-up; and an email not yet confirmed holds only so many places
	// (one request could fill a whole shift with made-up names, held for good while confirm_hours is 0).
	$people = array_slice( $people, 0, $vouched ? 10 : 4 );
	$adds   = array_slice( $adds, 0, max( 0, ( $vouched ? 10 : 4 ) - count( $people ) ), true );
	// Someone added is known by their own email once they've confirmed a place as that person (the same
	// email and name, this year or last): no new Confirm. Anyone else confirms by email first.
	foreach ( $adds as $ak => $a ) {
		$adds[ $ak ]['confirmed'] = false;
		foreach ( array_merge( ogc_records( $y - 1, 'signups', $a['email'] ), ogc_records( $y, 'signups', $a['email'] ) ) as $r ) {
			if ( ! empty( $r['data']['confirmed'] ) && 0 === strcasecmp( trim( (string) $r['data']['name'] ), $a['name'] ) ) {
				$adds[ $ak ]['confirmed'] = true;
				break;
			}
		}
	}
	global $wpdb;
	$cap    = (int) apply_filters( 'ogc_vol_unconfirmed_places', 12 );
	$held_q = 'SELECT COUNT(*) FROM ' . ogc_table( 'vol_seats' ) . ' s JOIN ' . ogc_table( 'records' ) . " r ON r.id = s.record_id AND r.deleted_at IS NULL WHERE s.year = %d AND r.kind = 'signups' AND r.email = %s";
	if ( ! $vouched ) {
		$held = (int) $wpdb->get_var( $wpdb->prepare( $held_q, $y, $email ) ); // phpcs:ignore -- prepared.
		if ( $held + count( $people ) * count( $ids ) > $cap ) {
			return ogc_vol_no( 'confirm', 'Confirm your email first · The link is in your inbox', array(), 429 );
		}
	}
	// An email nobody has confirmed holds only so many places, whoever typed it.
	foreach ( $adds as $a ) {
		if ( ! $a['confirmed'] && (int) $wpdb->get_var( $wpdb->prepare( $held_q, $y, $a['email'] ) ) + count( $ids ) > $cap ) { // phpcs:ignore -- prepared.
			return ogc_vol_no( 'confirm', 'Too many places waiting for ' . $a['name'] . ' to confirm', array(), 429 );
		}
	}
	$unconf = ( $vouched ? 0 : count( $people ) ) + count( array_filter( $adds, function ( $a ) { return ! $a['confirmed']; } ) );
	if ( $unconf ) {
		// And places not yet confirmed, per address a day (generous: a campus's wifi is many people).
		$k = 'ogc_vol_us_' . md5( ogc_vol_ip() );
		$n = (int) get_transient( $k ) + $unconf * count( $ids );
		if ( $n > (int) apply_filters( 'ogc_vol_unconfirmed_per_day', 200 ) ) {
			return ogc_vol_no( 'slow', 'Too many sign-ups at once. Try again later.', array(), 429 );
		}
		set_transient( $k, $n, DAY_IN_SECONDS );
	}
	// Who is signing up (after the fifth critic, Oct 15: one privacy rule on every path): the name they
	// typed, or the signed-in person's own; through an emailed link that vouches for the email, that
	// email's own person (ogc_vol_self_name). Everyone else on the sign-up is someone they signed up, off
	// the public list until shown. Unknown: everyone is, until shown.
	$self    = '' !== $myname ? $myname : ( $vouched ? ogc_vol_self_name( $y, $email ) : '' );
	$answers = (array) $req->get_param( 'answers' );
	$note    = mb_substr( sanitize_text_field( (string) $req->get_param( 'note' ) ), 0, 200 );
	$show    = false !== $req->get_param( 'show' );
	$next    = (bool) $req->get_param( 'next_year' );
	$reg     = ogc_vol_registration( $y, $email );
	$shifts  = ogc_vol_shifts( $y );
	$results = array();
	$made    = array();
	$by_mail = array();
	foreach ( $ids as $id ) {
		$o1 = compact( 'email', 'phone', 'phone_set', 'confirmed', 'answers', 'note', 'show', 'next', 'reg', 'other', 'actor', 'myname', 'self', 'adds', 'minors', 'bands' );
		if ( isset( $each[ $id ] ) ) {
			$o1['answers'] = $each[ $id ]['answers'];
		}
		$results[] = ogc_vol_join_one( $y, $id, $shifts, isset( $each[ $id ] ) ? $each[ $id ]['people'] : $people, $o1, $made, $by_mail );
	}
	if ( $made ) {
		ogc_log( 'vol_join', $y, 'signups', array( 'n' => count( $made ) ) );
		// Signed in, a phone typed now (or Changed on their own pill): their other places this year carry it
		// too, so the head's list has one phone for them.
		if ( $actor['signed'] && $phone_set && empty( $other['name'] ) ) {
			ogc_vol_set_phone( $y, $email, $phone );
		}
		$mine_ids = isset( $by_mail[ $email ] ) ? $by_mail[ $email ] : array();
		if ( $mine_ids ) {
			ogc_vol_queue_confirm( $y, $email, $mine_ids, $confirmed );
		}
		// Each person added hears it themselves: Confirm and Not me (or, known by that email already,
		// Signed up with Leave shift and Not me), naming who signed them up. Two minutes later, so
		// Undo takes it back quietly and several shifts go in one email.
		foreach ( $by_mail as $to => $rids ) {
			if ( $to === $email ) {
				continue;
			}
			$known = false;
			foreach ( $adds as $a ) {
				$known = $known || ( $a['email'] === $to && $a['confirmed'] );
			}
			ogc_vol_queue_confirm( $y, $to, $rids, $known, 120 );
			if ( $actor['signed'] && function_exists( 'ogc_record_link_add' ) ) {
				foreach ( $rids as $rid ) {
					ogc_record_link_add( $rid, $email, 'helper' );
				}
			}
		}
	}
	$out = array( 'results' => $results );
	if ( $made && ! $actor['signed'] ) {
		ogc_vol_device_link( $made );
		$out['hold'] = ogc_vol_token( array( 'a' => 'hold', 'y' => $y, 'e' => $email, 'r' => $made ), DAY_IN_SECONDS );
		$actor['holds'] += array_fill_keys( $made, $email );
	}
	$out['mine']   = ogc_vol_mine( $y, $actor );
	// The sign-ups this Join made (Undo and "Wrong email? Change" take them back).
	$out['made']   = array_map( 'intval', $made );
	$out['shifts'] = (object) array_intersect_key( ogc_vol_public_shifts( $y, $actor ), array_flip( $ids ) );
	$out['email']  = $email;
	// Those just added are now people this person may tick again (Your week names them too).
	$out['circle'] = ogc_vol_circle( $y, $actor, (bool) $reg );
	return rest_ensure_response( $out );
}

/** A person's band for this join: the answer sent with it, else what's known (ogc_vol_band_find). */
function ogc_vol_bandof( $y, $o, $email, $name ) {
	$k = strtolower( trim( (string) $name ) );
	if ( isset( $o['bands'][ $k ] ) ) {
		return $o['bands'][ $k ];
	}
	if ( in_array( $k, isset( $o['minors'] ) ? (array) $o['minors'] : array(), true ) ) {
		return 'u18';
	}
	return ogc_vol_band_find( $y, $email, $name );
}

/** Under 18 by a fixed field: ticked with this join (o['minors']), or marked so on an earlier sign-up
 * this year under the same email and name. Never guessed from a name. */
function ogc_vol_is_minor( $y, $o, $email, $name ) {
	if ( in_array( strtolower( trim( (string) $name ) ), isset( $o['minors'] ) ? (array) $o['minors'] : array(), true ) ) {
		return true;
	}
	$bk = strtolower( trim( (string) $name ) );
	if ( isset( $o['bands'][ $bk ] ) ) {
		return 'u18' === $o['bands'][ $bk ];
	}
	foreach ( ogc_records( $y, 'signups', $email ) as $r ) {
		if ( ! empty( $r['data']['minor'] ) && 0 === strcasecmp( trim( (string) $r['data']['name'] ), trim( (string) $name ) ) ) {
			return true;
		}
	}
	return false;
}

/** One shift of a join: checks, then the places, then the sign-ups. $people are under the joining
 * email; $o['adds'] are people added under their own email (Add someone). $by_mail gathers the new
 * sign-ups by the email each confirmation goes to. */
function ogc_vol_join_one( $y, $id, $shifts, $people, $o, &$made, &$by_mail = array() ) {
	global $wpdb;
	$adds = isset( $o['adds'] ) ? array_values( (array) $o['adds'] ) : array();
	$res  = array( 'shift' => $id, 'status' => 'ok', 'names' => array_merge( $people, array_column( $adds, 'name' ) ) );
	if ( ! isset( $shifts[ $id ] ) ) {
		return array_merge( $res, array( 'status' => 'gone' ) );
	}
	$sh = $shifts[ $id ];
	$st = ogc_vol_shift_state( $y, $sh, 0 );
	if ( 'open' !== $st ) {
		return array_merge( $res, array( 'status' => $st ) );
	}
	$ans = isset( $o['answers'] ) ? (array) $o['answers'] : array();
	// The shift's rule, per person: each one's age (ogc_vol_bandof: this sign-up's answer, their earlier
	// sign-ups', their registration's). One who doesn't meet it is refused; with everyone's age known to
	// meet it, nothing more is asked; anyone not known needs the old claim (answers.rule).
	$rule    = null;
	$aged_ok = false;
	if ( $sh['min_age'] ) {
		$aged_ok = true;
		foreach ( array_merge( array_map( function ( $n ) use ( $o ) {
			return array( 'name' => $n, 'email' => $o['email'] );
		}, $people ), $adds ) as $p ) {
			$n   = $p['name'];
			$age = $p['email'] === $o['email'] ? ogc_vol_age_of( $o['reg'], $n ) : '';
			$num = $p['email'] === $o['email'] ? ogc_vol_age_num( $o['reg'], $n ) : null;
			$ok  = ogc_vol_band_ok( ogc_vol_bandof( $y, $o, $p['email'], $n ), $sh['min_age'] );
			if ( false === $ok || ( $sh['min_age'] >= 18 && ( in_array( $age, array( 'minor', 'child' ), true ) || ogc_vol_is_minor( $y, $o, $p['email'], $n ) ) ) || ( null !== $num && $num < $sh['min_age'] ) ) {
				return array_merge( $res, array( 'status' => 'minor', 'name' => $n, 'min_age' => $sh['min_age'] ) );
			}
			$aged_ok = $aged_ok && true === $ok;
		}
	}
	// A certification each (after the sixth critic, Oct 15): answers.questions { name: answer }, else the
	// one answers.question for everyone (as before).
	$qeach = array();
	if ( $sh['question'] ) {
		$q  = isset( $ans['question'] ) ? (string) $ans['question'] : '';
		$qs = array();
		foreach ( isset( $ans['questions'] ) && is_array( $ans['questions'] ) ? $ans['questions'] : array() as $qn => $qv ) {
			$qs[ strtolower( ogc_vol_clean_name( $qn ) ) ] = (string) $qv;
		}
		foreach ( $res['names'] as $n ) {
			$a1 = isset( $qs[ strtolower( trim( $n ) ) ] ) ? $qs[ strtolower( trim( $n ) ) ] : $q;
			if ( ! in_array( $a1, $sh['question'], true ) ) {
				return array_merge( $res, array( 'status' => 'rule', 'question' => $sh['question'], 'name' => $qs ? $n : '' ) );
			}
			$qeach[ strtolower( trim( $n ) ) ] = $a1;
		}
		$rule = array( 'text' => $sh['rule'], 'answer' => $q ? $q : reset( $qeach ), 'at' => gmdate( 'c', ogc_vol_now() ) );
	} elseif ( $sh['rule'] ) {
		$r  = isset( $ans['rule'] ) ? $ans['rule'] : false;
		$ok = $aged_ok || true === $r || 'true' === $r || '1' === $r || 1 === $r || ( is_array( $r ) && ! array_diff( $res['names'], array_map( 'strval', $r ) ) );
		if ( ! $ok ) {
			return array_merge( $res, array( 'status' => 'rule', 'rule' => $sh['rule'] ) );
		}
		$rule = array( 'text' => $sh['rule'], 'answer' => 'yes', 'at' => gmdate( 'c', ogc_vol_now() ) );
	}
	$screen = '';
	if ( $sh['screening'] ) {
		$screen = isset( $ans['screened'] ) && in_array( $ans['screened'], array( 'yes', 'not_yet' ), true ) ? $ans['screened'] : '';
		$s      = ogc_vol_settings( $y );
		if ( ! $screen || ( 'not_yet' === $screen && ! empty( $s['screening_required'] ) && 'yes' === $s['screening_required'] ) ) {
			return array_merge( $res, array( 'status' => 'screening' ) );
		}
	}
	// Each person once: under this email, or (added) under their own.
	$who = array();
	foreach ( $people as $n ) {
		$who[ ogc_vol_pkey( $o['email'], $n ) ] = array( 'name' => $n, 'email' => $o['email'], 'added' => null );
	}
	foreach ( $adds as $a ) {
		$who[ ogc_vol_pkey( $a['email'], $a['name'] ) ] = array( 'name' => $a['name'], 'email' => $a['email'], 'added' => $a );
	}
	// Busy: already on a shift at that time.
	foreach ( $who as $pk => $p ) {
		$b = ogc_vol_busy( $y, $sh, $pk );
		if ( $b ) {
			return array_merge( $res, array( 'status' => 'busy', 'name' => $p['name'], 'busy' => array( 'shift' => $b['id'], 'role' => $b['role'], 'until' => $b['end'] ) ) );
		}
	}
	$seats = ogc_vol_take_seats( $y, $sh, array_keys( $who ) );
	if ( is_wp_error( $seats ) ) {
		$d = $seats->get_error_data();
		if ( 'ogc_dup' === $seats->get_error_code() ) {
			return array_merge( $res, array( 'status' => 'dup', 'name' => isset( $who[ $d['pkey'] ] ) ? $who[ $d['pkey'] ]['name'] : '' ) );
		}
		return array_merge( $res, array( 'status' => 'full', 'open' => isset( $d['open'] ) ? $d['open'] : 0 ) );
	}
	// Two Joins at once by one person for two shifts at the same time (two tabs, a double tap across
	// rows) both passed Busy above before either had a place. Each now holds one; the later gives it back.
	foreach ( $seats as $pk => $seat_id ) {
		$b = ogc_vol_busy_race( $y, $sh, $pk, $seat_id );
		if ( $b ) {
			ogc_vol_release( $seats );
			return array_merge( $res, array( 'status' => 'busy', 'name' => $who[ $pk ]['name'], 'busy' => array( 'shift' => $b['id'], 'role' => $b['role'], 'until' => $b['end'] ) ) );
		}
	}
	$by = ! empty( $o['other']['name'] ) ? 'helper' : 'self';
	// Signed up through a contact who isn't on this shift (Michael, Oct 15): "For someone else" the first
	// time, or a signed-in person who unticked themselves; the same either way. Those going on under the
	// contact's email carry the contact's phone, and the head sees it marked: "via Martha Fry". Mechanical:
	// the person signing up (by name) is neither among those going on nor already on this shift.
	$self_n = trim( isset( $o['self'] ) ? (string) $o['self'] : (string) $o['myname'] );
	$via    = '' !== $self_n && empty( $o['other']['name'] ) && ! in_array( strtolower( $self_n ), array_map( function ( $n ) {
		return strtolower( trim( $n ) );
	}, $people ), true ) && ! ogc_vol_name_on( $y, $id, $o['email'], $self_n );
	foreach ( $seats as $pk => $seat_id ) {
		$p    = $who[ $pk ];
		$n    = $p['name'];
		$add  = $p['added'];
		$age  = $add ? '' : ogc_vol_age_of( $o['reg'], $n );
		$data = array(
			'id'        => $id,
			'name'      => $n,
			'phone'     => $add ? '' : $o['phone'],
			// Typed with this sign-up (or Changed): the phone they chose, kept over the registration's.
			'phone_set' => ! $add && ! empty( $o['phone_set'] ) && '' !== (string) $o['phone'],
			'email'     => $p['email'],
			'confirmed' => $add ? (bool) $add['confirmed'] : (bool) $o['confirmed'],
			'by'        => $add ? 'helper' : $by,
			'at'        => gmdate( 'c', ogc_vol_now() ),
			'hide'      => ! $o['show'],
			'next_year' => $add ? false : (bool) $o['next'],
		);
		if ( 'helper' === $data['by'] ) {
			$data['helper'] = $o['myname'];
		}
		if ( $via && ! $add ) {
			$data['by']     = 'helper';
			$data['helper'] = $self_n;
			$data['via']    = true;
		}
		// Added by their own email: who added them (that person sees the place and may leave it), and
		// off the public list until they choose, as anyone signed up by someone else.
		if ( $add ) {
			$data['helper_email'] = $o['email'];
			$data['for']          = true;
		}
		// Signed up by someone else (Daniel for Esther, from his household, Add someone, the returner card,
		// an emailed link, or "for someone else"): off the public list (counted only) until they, or the one
		// who signed them up on the same email, choose Show; the head sees it. One rule on every path
		// (after the fifth critic, Oct 15: the emailed link's sign-up named Esther publicly).
		$self = isset( $o['self'] ) ? (string) $o['self'] : (string) $o['myname'];
		if ( ! $add && ( '' === trim( $self ) || 0 !== strcasecmp( trim( $n ), trim( $self ) ) ) ) {
			$data['for'] = true;
		}
		if ( in_array( $age, array( 'minor', 'child' ), true ) || ogc_vol_is_minor( $y, $o, $p['email'], $n ) ) {
			$data['minor'] = true;
		}
		// The age, kept with the person (the next shift doesn't ask again): an answer or an exact one.
		$band = ogc_vol_bandof( $y, $o, $p['email'], $n );
		if ( isset( OGC_VOL_BANDS[ $band ] ) ) {
			$data['band'] = $band;
			if ( 'u18' === $band ) {
				$data['minor'] = true;
			}
		}
		if ( $rule ) {
			$data['rule'] = $rule;
			if ( isset( $qeach[ strtolower( trim( $n ) ) ] ) ) {
				$data['rule']['answer'] = $qeach[ strtolower( trim( $n ) ) ];
			}
		}
		if ( $screen ) {
			$data['screened'] = $screen;
		}
		if ( $o['note'] ) {
			$data['note'] = $o['note'];
		}
		$rid = ogc_record_insert( $y, 'signups', $data, $p['email'], false, 'web' );
		if ( ! $rid ) {
			ogc_vol_release( $seats );
			return array_merge( $res, array( 'status' => 'error' ) );
		}
		$wpdb->update( ogc_table( 'vol_seats' ), array( 'record_id' => $rid ), array( 'id' => $seat_id ), array( '%d' ), array( '%d' ) );
		$made[]                     = $rid;
		$by_mail[ $p['email'] ][] = $rid;
		ogc_vol_change( $y, $sh, 'joined', $n );
	}
	// A place taken: off the waitlist for it.
	foreach ( ogc_records( $y, 'waits', $o['email'] ) as $w ) {
		if ( isset( $w['data']['id'] ) && $w['data']['id'] === $id && in_array( $w['data']['name'], $people, true ) ) {
			ogc_record_delete( $w['id'] );
		}
	}
	return $res;
}

/** Someone (by name) holds a place on a shift under an email. */
function ogc_vol_name_on( $y, $id, $email, $name ) {
	foreach ( ogc_records( $y, 'signups', $email ) as $r ) {
		if ( isset( $r['data']['id'] ) && (string) $r['data']['id'] === (string) $id && 0 === strcasecmp( trim( (string) $r['data']['name'] ), trim( (string) $name ) ) ) {
			return true;
		}
	}
	return false;
}

/** A line in the committee's changes since a head last printed (members only; cleared with the year). */
function ogc_vol_change( $year, $sh, $act, $name, $extra = array() ) {
	$s = ogc_state_get( $year, 'vol-changes' );
	$l = $s ? (array) $s['value'] : array();
	$l[] = array_merge( array( 'at' => ogc_now(), 'committee' => $sh['committee'], 'shift' => $sh['id'], 'act' => $act, 'name' => $name ), $extra );
	ogc_state_put( $year, 'vol-changes', array_slice( $l, -800 ) );
}

/* ================================================================== taking it back, leaving */

/** Undo, within ten minutes of joining and before the confirmation goes: as if it never happened. */
function ogc_vol_rest_undo( WP_REST_Request $req ) {
	global $wpdb;
	$y     = (int) $req['year'];
	$actor = ogc_vol_actor( $req );
	$done  = array();
	foreach ( array_slice( array_map( 'intval', (array) $req->get_param( 'ids' ) ), 0, 20 ) as $id ) {
		$rec = ogc_record_get( $id );
		if ( ! $rec || 'signups' !== $rec['kind'] || (int) $rec['year'] !== $y || ! ogc_vol_owns( $actor, $rec ) ) {
			continue;
		}
		if ( ogc_vol_now() - strtotime( $rec['created_at'] . ' UTC' ) > 600 || ogc_vol_outbox_sent_for( $id ) ) {
			// Too late to take back quietly: an ordinary Leave.
			ogc_record_delete( $id );
			ogc_vol_after_leave( $y, $rec, 'self' );
		} else {
			$wpdb->delete( ogc_table( 'records' ), array( 'id' => $id ), array( '%d' ) );
			ogc_vol_release_record( $id );
			ogc_vol_outbox_drop( $id );
		}
		$done[] = $id;
	}
	if ( $done ) {
		ogc_log( 'vol_undo', $y, 'signups', array( 'n' => count( $done ) ) );
	}
	return rest_ensure_response( array( 'undone' => $done, 'mine' => ogc_vol_mine( $y, $actor ), 'shifts' => (object) ogc_vol_public_shifts( $y, $actor ) ) );
}

/** Leave a shift, one person at a time. After the shift has started, Leave is gone (call the head). */
function ogc_vol_rest_leave( WP_REST_Request $req ) {
	$y     = (int) $req['year'];
	$actor = ogc_vol_actor( $req );
	$link  = ogc_vol_link_of( $req );
	$left  = array();
	foreach ( array_slice( array_map( 'intval', (array) $req->get_param( 'ids' ) ), 0, 20 ) as $id ) {
		$rec = ogc_record_get( $id );
		if ( ! $rec || 'signups' !== $rec['kind'] || (int) $rec['year'] !== $y ) {
			continue;
		}
		$by_link = $link && 'leave' === $link['a'] && in_array( $id, (array) $link['r'], true ) && strtolower( $link['e'] ) === $rec['email'];
		if ( ! $by_link && ! ogc_vol_owns( $actor, $rec ) ) {
			continue;
		}
		$shifts = ogc_vol_shifts( $y );
		$sh     = isset( $shifts[ $rec['data']['id'] ] ) ? $shifts[ $rec['data']['id'] ] : null;
		if ( $sh && ogc_vol_now() >= $sh['start_ts'] ) {
			return ogc_vol_no( 'started', 'Started', array( 'phone' => ogc_vol_role_phone( $y, $sh['committee'] ) ) );
		}
		// When it was left, kept on the removed record: the toast's Undo (vol/{y}/unleave) brings back only
		// a place left by its own people a moment ago (never one a head removed).
		$rec['data']['left_at'] = gmdate( 'c', ogc_vol_now() );
		ogc_record_update( $id, $rec['data'], $rec['email'] );
		ogc_record_delete( $id );
		// The person who added someone, leaving it for them (not by the emailed link, which is theirs).
		$for_them = ! $by_link && ! empty( $rec['data']['helper_email'] ) && $rec['email'] !== ( $actor['email'] ?: ( isset( $actor['holds'][ $id ] ) ? $actor['holds'][ $id ] : '' ) );
		ogc_vol_after_leave( $y, $rec, $for_them ? 'helper' : 'self' );
		$left[] = $id;
	}
	if ( $left ) {
		ogc_log( 'vol_leave', $y, 'signups', array( 'n' => count( $left ) ) );
	}
	return rest_ensure_response( array( 'left' => $left, 'mine' => ogc_vol_mine( $y, $actor ), 'shifts' => (object) ogc_vol_public_shifts( $y, $actor ) ) );
}

/**
 * Undo a Leave (after the third critic, Oct 15: the toast's Undo, on the volunteer page, Your sign-ups and
 * the emailed Leave link's sheet). Body: { ids: [record ids], t | link }. Within ten minutes of the leave,
 * by the same people who could leave it (their own places, or the same emailed link), before the shift
 * starts: the same person back in a place, if one is still free and they haven't taken another shift at
 * that time meanwhile. Whatever the leave set going that hasn't gone yet is taken back quietly: the
 * person's "Left shift" email, the waitlist's "A place opened", the head's notice and the evening line,
 * and the line on the head's list. → { back: [ids], no: [{ rid, why: full|busy|dup|started|late }], mine,
 * shifts }.
 */
function ogc_vol_rest_unleave( WP_REST_Request $req ) {
	global $wpdb;
	$y      = (int) $req['year'];
	$actor  = ogc_vol_actor( $req );
	$link   = ogc_vol_link_of( $req );
	$shifts = ogc_vol_shifts( $y );
	$back   = array();
	$no     = array();
	foreach ( array_slice( array_map( 'intval', (array) $req->get_param( 'ids' ) ), 0, 20 ) as $id ) {
		$rec = ogc_record_get( $id, true );
		if ( ! $rec || 'signups' !== $rec['kind'] || (int) $rec['year'] !== $y || empty( $rec['deleted_at'] ) || empty( $rec['data']['left_at'] ) ) {
			continue;
		}
		$by_link = $link && 'leave' === $link['a'] && in_array( $id, array_map( 'intval', (array) $link['r'] ), true ) && strtolower( $link['e'] ) === $rec['email'];
		if ( ! $by_link && ! ogc_vol_owns( $actor, $rec ) ) {
			continue;
		}
		$sh = isset( $shifts[ $rec['data']['id'] ] ) ? $shifts[ $rec['data']['id'] ] : null;
		if ( ! $sh || ogc_vol_now() >= $sh['start_ts'] ) {
			$no[] = array( 'rid' => $id, 'why' => 'started' );
			continue;
		}
		if ( ogc_vol_now() - strtotime( $rec['data']['left_at'] ) > 600 ) {
			$no[] = array( 'rid' => $id, 'why' => 'late' );
			continue;
		}
		$pk = ogc_vol_pkey( $rec['email'], $rec['data']['name'], isset( $rec['data']['phone'] ) ? $rec['data']['phone'] : '' );
		if ( ogc_vol_busy( $y, $sh, $pk ) ) {
			$no[] = array( 'rid' => $id, 'why' => 'busy' );
			continue;
		}
		$seats = ogc_vol_take_seats( $y, $sh, array( $pk ) );
		if ( is_wp_error( $seats ) ) {
			$no[] = array( 'rid' => $id, 'why' => 'ogc_dup' === $seats->get_error_code() ? 'dup' : 'full' );
			continue;
		}
		$wpdb->update( ogc_table( 'vol_seats' ), array( 'record_id' => $id ), array( 'id' => (int) reset( $seats ) ), array( '%d' ), array( '%d' ) );
		$d = $rec['data'];
		unset( $d['left_at'] );
		ogc_record_update( $id, $d, $rec['email'] );
		$wpdb->query( $wpdb->prepare( 'UPDATE ' . ogc_table( 'records' ) . ' SET deleted_at = NULL WHERE id = %d', $id ) );
		ogc_vol_unleave_quiet( $y, $rec, $sh );
		$back[] = $id;
	}
	if ( $back ) {
		ogc_log( 'vol_unleave', $y, 'signups', array( 'n' => count( $back ) ) );
	}
	return rest_ensure_response( array( 'back' => $back, 'no' => $no, 'mine' => ogc_vol_mine( $y, $actor ), 'shifts' => (object) ogc_vol_public_shifts( $y, $actor ) ) );
}

/** What a leave set going and hasn't gone yet, taken back (Undo): each is marked with the sign-up's id. */
function ogc_vol_unleave_quiet( $year, $rec, $sh ) {
	global $wpdb;
	$rid = (int) $rec['id'];
	$t   = ogc_table( 'vol_outbox' );
	foreach ( (array) $wpdb->get_results( $wpdb->prepare( "SELECT id, kind, payload FROM $t WHERE year = %d AND sent_at IS NULL AND kind IN ('left', 'opened', 'head')", $year ), ARRAY_A ) as $row ) {
		$p = (array) ogc_unjson( $row['payload'], array() );
		if ( 'left' === $row['kind'] ) {
			$items = array_values( array_filter( (array) ( isset( $p['items'] ) ? $p['items'] : array() ), function ( $it ) use ( $rid ) {
				return (int) ( isset( $it['rec']['id'] ) ? $it['rec']['id'] : 0 ) !== $rid;
			} ) );
			if ( count( $items ) === count( (array) ( isset( $p['items'] ) ? $p['items'] : array() ) ) ) {
				continue;
			}
			if ( $items ) {
				$p['items'] = $items;
				$wpdb->update( $t, array( 'payload' => ogc_json( $p ) ), array( 'id' => (int) $row['id'] ), array( '%s' ), array( '%d' ) );
			} else {
				$wpdb->delete( $t, array( 'id' => (int) $row['id'] ), array( '%d' ) );
			}
		} elseif ( isset( $p['left'] ) && (int) $p['left'] === $rid ) {
			$wpdb->delete( $t, array( 'id' => (int) $row['id'] ), array( '%d' ) );
		}
	}
	// The evening's line for the head, and the line on the head's list ("Since you printed").
	$s = ogc_state_get( $year, 'vol-head-digest' );
	if ( $s ) {
		$v          = (array) $s['value'];
		$v['items'] = array_values( array_filter( (array) ( isset( $v['items'] ) ? $v['items'] : array() ), function ( $it ) use ( $rid ) {
			return (int) ( isset( $it['rid'] ) ? $it['rid'] : 0 ) !== $rid;
		} ) );
		ogc_state_put( $year, 'vol-head-digest', $v );
	}
	$c = ogc_state_get( $year, 'vol-changes' );
	if ( $c ) {
		ogc_state_put( $year, 'vol-changes', array_values( array_filter( (array) $c['value'], function ( $x ) use ( $rid ) {
			return ! ( 'left' === $x['act'] && isset( $x['rid'] ) && (int) $x['rid'] === $rid );
		} ) ) );
	}
}

/** The committee's role phone, for "Questions" and "Call the head". */
function ogc_vol_role_phone( $year, $committee ) {
	$c = ogc_vol_committees( $year );
	return isset( $c[ $committee ] ) ? $c[ $committee ]['contact_phone'] : '';
}

/**
 * After a sign-up ends (Leave, Your sign-ups, a head's Remove with notify): its place is let go; the
 * person gets a cancellation (with the calendar event cancelled, or updated when someone else of that
 * email is still on it); everyone waiting hears a place opened; the head hears at once within 48 hours
 * of the shift ("Late"), else that evening in one email for the day's leaves (after the second critic,
 * Oct 15: "The committee head is told" was true only in the last two days).
 */
function ogc_vol_after_leave( $year, $rec, $how ) {
	ogc_vol_release_record( $rec['id'] );
	ogc_vol_outbox_drop( $rec['id'] );
	$shifts = ogc_vol_shifts( $year );
	$id     = isset( $rec['data']['id'] ) ? $rec['data']['id'] : '';
	if ( ! isset( $shifts[ $id ] ) ) {
		return;
	}
	$sh = $shifts[ $id ];
	ogc_vol_change( $year, $sh, 'left', $rec['data']['name'], array( 'rid' => (int) $rec['id'] ) );
	if ( 'quiet' === $how ) {
		return;
	}
	if ( ! empty( $rec['data']['email'] ) ) {
		// Left for them by the one who added them (Add someone): the email names who.
		ogc_vol_queue_person( $year, $rec, 'left', 'helper' === $how && ! empty( $rec['data']['helper'] ) ? array( 'by_name' => ogc_vol_first_l( $rec['data']['helper'] ) ) : array() );
	}
	if ( ogc_vol_now() < $sh['start_ts'] ) {
		// Two minutes' hold, as long as the toast's Undo (and the person's own "Left shift" email) waits:
		// taken back, nobody hears of a place that didn't open (after the third critic, Oct 15).
		$hold = 120;
		ogc_vol_notify_waitlist( $year, $sh, $hold, (int) $rec['id'] );
		if ( $sh['start_ts'] - ogc_vol_now() < 2 * DAY_IN_SECONDS ) {
			ogc_vol_head_notice( $year, $sh, 'late', array( 'name' => ogc_vol_first_l( $rec['data']['name'] ) ), $hold, (int) $rec['id'] );
		} elseif ( ogc_vol_leave_tells( $sh, $rec ) ) {
			// Joined and left again within minutes, before any email went: no news for the head either.
			ogc_vol_head_digest_add( $year, $sh, ogc_vol_first_l( $rec['data']['name'] ), (int) $rec['id'] );
		}
	}
}

/**
 * Would this place's Leave reach the committee's head now? The rule the Leave itself follows
 * (ogc_vol_after_leave): within two days of the shift, at once ("Late"); otherwise in that evening's
 * email, unless the place was taken less than ten minutes ago and no email about it has gone yet (a
 * quick change of mind is no news). The Leave sheet says "The … head is told" only when this is true
 * (after the eighth critic, Oct 16: it said so for a leave minutes after joining, which never reaches
 * the head).
 */
function ogc_vol_leave_tells( $sh, $rec ) {
	if ( ! $sh || ogc_vol_now() >= $sh['start_ts'] ) {
		return false;
	}
	if ( $sh['start_ts'] - ogc_vol_now() < 2 * DAY_IN_SECONDS ) {
		return true;
	}
	return strtotime( $rec['created_at'] . ' UTC' ) <= ogc_vol_now() - 600 || ogc_vol_outbox_sent_for( $rec['id'] );
}

/* ================================================================== the waitlist */

function ogc_vol_rest_wait( WP_REST_Request $req ) {
	$y     = (int) $req['year'];
	$actor = ogc_vol_actor( $req );
	if ( '' !== (string) $req->get_param( 'hp' ) ) {
		return rest_ensure_response( array( 'waits' => array() ) );
	}
	if ( ! ogc_vol_rate( 'wait|' . ogc_vol_ip(), 30 ) ) {
		return ogc_vol_no( 'slow', 'Too many at once. Try again later.', array(), 429 );
	}
	$shifts = ogc_vol_shifts( $y );
	$id     = (string) $req->get_param( 'shift' );
	if ( ! isset( $shifts[ $id ] ) ) {
		return ogc_vol_no( 'gone', 'Not found', array(), 404 );
	}
	$who   = (array) $req->get_param( 'who' );
	$email = $actor['email'];
	$name  = ogc_vol_clean_name( trim( ( isset( $who['first'] ) ? $who['first'] : '' ) . ' ' . ( isset( $who['last'] ) ? $who['last'] : '' ) ) );
	$phone = ogc_vol_clean_phone( isset( $who['phone'] ) ? $who['phone'] : '' );
	// An emailed link that vouches for the email (a place opened, your shifts again: after the fifth
	// critic, Oct 15) puts its own people on the waitlist without typing who they are.
	$link  = $actor['signed'] ? null : ogc_vol_link_of( $req );
	$vouch = $link && in_array( $link['a'], array( 'opened', 'again' ), true ) && (int) $link['y'] === $y;
	if ( $vouch ) {
		$email = strtolower( (string) $link['e'] );
		$phone = $phone ? $phone : ogc_vol_known_phone( $y, $email );
	}
	if ( ! $actor['signed'] && ! $vouch ) {
		$email = strtolower( sanitize_email( isset( $who['email'] ) ? $who['email'] : '' ) );
		$errs  = array_filter( array( 'email' => is_email( $email ) ? '' : 'Enter your email', 'first' => empty( $who['first'] ) ? 'Enter your first name' : '', 'last' => empty( $who['last'] ) ? 'Enter your last name' : '', 'phone' => $phone ? '' : 'Enter a phone number' ) );
		if ( $errs ) {
			return ogc_vol_no( 'fields', 'Check the form.', array( 'fields' => $errs ), 400 );
		}
	}
	$people = array_slice( array_values( array_unique( array_filter( array_map( 'ogc_vol_clean_name', (array) $req->get_param( 'people' ) ) ) ) ), 0, 10 );
	if ( ! $people && $vouch ) {
		return ogc_vol_no( 'fields', 'Check the form.', array( 'fields' => array( 'people' => 'Choose who' ) ), 400 );
	}
	if ( ! $people ) {
		$u      = wp_get_current_user();
		$people = array( $name ?: ( $u && $u->ID ? $u->display_name : '' ) );
	}
	$made = array();
	$have = ogc_records( $y, 'waits', $email );
	foreach ( $people as $n ) {
		foreach ( $have as $w ) {
			if ( $w['data']['id'] === $id && 0 === strcasecmp( $w['data']['name'], $n ) ) {
				continue 2;
			}
		}
		$made[] = ogc_record_insert( $y, 'waits', array( 'id' => $id, 'name' => $n, 'email' => $email, 'phone' => $phone, 'at' => gmdate( 'c', ogc_vol_now() ), 'confirmed' => $actor['signed'] || $vouch ), $email, false, 'web' );
	}
	ogc_log( 'vol_wait', $y, 'waits', array( 'n' => count( $made ) ) );
	$out = array();
	if ( $made && ! $actor['signed'] ) {
		ogc_vol_device_link( $made );
		$out['hold'] = ogc_vol_token( array( 'a' => 'hold', 'y' => $y, 'e' => $email, 'r' => $made ), DAY_IN_SECONDS );
		$actor['holds'] += array_fill_keys( $made, $email );
	}
	$out['waits'] = ogc_vol_mine( $y, $actor, 'waits' );
	return rest_ensure_response( $out );
}

function ogc_vol_rest_unwait( WP_REST_Request $req ) {
	$y     = (int) $req['year'];
	$actor = ogc_vol_actor( $req );
	foreach ( array_slice( array_map( 'intval', (array) $req->get_param( 'ids' ) ), 0, 20 ) as $id ) {
		$rec = ogc_record_get( $id );
		if ( $rec && 'waits' === $rec['kind'] && (int) $rec['year'] === $y && ogc_vol_owns( $actor, $rec ) ) {
			ogc_record_delete( $id );
		}
	}
	return rest_ensure_response( array( 'waits' => ogc_vol_mine( $y, $actor, 'waits' ) ) );
}

/* ================================================================== swaps */

/** Find a replacement: the place stays yours (and counted) until someone takes it; a link to send. */
function ogc_vol_rest_swap( WP_REST_Request $req ) {
	$y     = (int) $req['year'];
	$actor = ogc_vol_actor( $req );
	$rec   = ogc_record_get( (int) $req->get_param( 'id' ) );
	// The emailed Leave link may also Find replacement (the same token, for its own sign-ups).
	$link    = ogc_vol_link_of( $req );
	$by_link = $rec && $link && 'leave' === $link['a'] && in_array( (int) $rec['id'], array_map( 'intval', (array) $link['r'] ), true ) && strtolower( $link['e'] ) === $rec['email'];
	if ( ! $rec || 'signups' !== $rec['kind'] || (int) $rec['year'] !== $y || ! ( $by_link || ogc_vol_owns( $actor, $rec ) ) ) {
		return ogc_vol_no( 'gone', 'Not found', array(), 404 );
	}
	$d         = $rec['data'];
	$d['swap'] = $req->get_param( 'on' ) ? ( ! empty( $d['swap'] ) ? $d['swap'] : wp_generate_password( 16, false ) ) : '';
	ogc_record_update( $rec['id'], $d, $rec['email'] );
	$shifts = ogc_vol_shifts( $y );
	if ( isset( $shifts[ $d['id'] ] ) ) {
		ogc_vol_change( $y, $shifts[ $d['id'] ], $d['swap'] ? 'swap_open' : 'swap_off', $d['name'] );
	}
	return rest_ensure_response( array( 'swap' => $d['swap'] ? $rec['id'] . '.' . $d['swap'] : '', 'mine' => ogc_vol_mine( $y, $actor ) ) );
}

/** Take a place offered for a swap: the same place changes hands at once (the first to tap wins). */
function ogc_vol_rest_take( WP_REST_Request $req ) {
	global $wpdb;
	$y     = (int) $req['year'];
	$actor = ogc_vol_actor( $req );
	list( $rid, $tok ) = array_pad( explode( '.', (string) $req->get_param( 'swap' ), 2 ), 2, '' );
	$old = ogc_record_get( (int) $rid );
	if ( ! $old || 'signups' !== $old['kind'] || (int) $old['year'] !== $y ) {
		return ogc_vol_no( 'taken', 'Taken' );
	}
	// From the link, the token must match; from the page, the place must be offered.
	if ( empty( $old['data']['swap'] ) || ( '' !== $tok && ! hash_equals( (string) $old['data']['swap'], $tok ) ) ) {
		return ogc_vol_no( 'taken', 'Taken' );
	}
	$shifts = ogc_vol_shifts( $y );
	$sh     = isset( $shifts[ $old['data']['id'] ] ) ? $shifts[ $old['data']['id'] ] : null;
	if ( ! $sh || ogc_vol_now() >= $sh['start_ts'] ) {
		return ogc_vol_no( 'started', 'Started' );
	}
	$who   = (array) $req->get_param( 'who' );
	$email = $actor['email'];
	$u     = wp_get_current_user();
	$name  = ogc_vol_clean_name( trim( ( isset( $who['first'] ) ? $who['first'] : '' ) . ' ' . ( isset( $who['last'] ) ? $who['last'] : '' ) ) ) ?: ( $u && $u->ID ? $u->display_name : '' );
	$phone = ogc_vol_clean_phone( isset( $who['phone'] ) ? $who['phone'] : '' );
	if ( ! $actor['signed'] ) {
		$email = strtolower( sanitize_email( isset( $who['email'] ) ? $who['email'] : '' ) );
		$errs  = array_filter( array( 'email' => is_email( $email ) ? '' : 'Enter your email', 'first' => empty( $who['first'] ) ? 'Enter your first name' : '', 'last' => empty( $who['last'] ) ? 'Enter your last name' : '', 'phone' => $phone ? '' : 'Enter a phone number' ) );
		if ( $errs ) {
			return ogc_vol_no( 'fields', 'Check the form.', array( 'fields' => $errs ), 400 );
		}
	}
	if ( ! $phone && $actor['signed'] ) {
		foreach ( array_filter( ogc_records( $y, 'signups', $email ), 'ogc_vol_rec_confirmed' ) as $r ) {
			$phone = ! empty( $r['data']['phone'] ) ? $r['data']['phone'] : $phone;
		}
	}
	$pk = ogc_vol_pkey( $email, $name );
	if ( $pk === ogc_vol_pkey( $old['email'], $old['data']['name'] ) ) {
		return ogc_vol_no( 'dup', 'Signed up' );
	}
	$b = ogc_vol_busy( $y, $sh, $pk );
	if ( $b ) {
		return ogc_vol_no( 'busy', 'Busy', array( 'busy' => array( 'shift' => $b['id'], 'role' => $b['role'], 'until' => $b['end'] ) ) );
	}
	// Their age (after the sixth critic, Oct 15): the answer sent, else what's known; one that doesn't
	// meet the shift's age is refused.
	$band = ogc_vol_band_find( $y, $email, $name, isset( $who['band'] ) ? $who['band'] : '' );
	if ( $sh['min_age'] && false === ogc_vol_band_ok( $band, $sh['min_age'] ) ) {
		return ogc_vol_no( 'minor', 'Age', array( 'min_age' => $sh['min_age'] ) );
	}
	if ( $sh['rule'] && ! $sh['question'] && empty( $req->get_param( 'answers' )['rule'] ) && ! ( $sh['min_age'] && true === ogc_vol_band_ok( $band, $sh['min_age'] ) ) ) {
		return ogc_vol_no( 'rule', 'Rule', array( 'rule' => $sh['rule'] ) );
	}
	$data = array( 'id' => $sh['id'], 'name' => $name, 'phone' => $phone, 'email' => $email, 'confirmed' => $actor['signed'], 'by' => 'swap', 'at' => gmdate( 'c', ogc_vol_now() ), 'took_from' => ogc_vol_first_l( $old['data']['name'] ) );
	if ( isset( OGC_VOL_BANDS[ $band ] ) ) {
		$data['band'] = $band;
		if ( 'u18' === $band ) {
			$data['minor'] = true;
		}
	}
	if ( $sh['rule'] ) {
		$q            = (array) $req->get_param( 'answers' );
		$data['rule'] = array( 'text' => $sh['rule'], 'answer' => ! empty( $q['question'] ) ? sanitize_text_field( $q['question'] ) : 'yes', 'at' => $data['at'] );
	}
	$new = ogc_record_insert( $y, 'signups', $data, $email, false, 'web' );
	$wpdb->suppress_errors( true );
	$n = $wpdb->query( $wpdb->prepare( 'UPDATE ' . ogc_table( 'vol_seats' ) . ' SET record_id = %d, pkey = %s WHERE year = %d AND record_id = %d', $new, $pk, $y, $old['id'] ) );
	$wpdb->suppress_errors( false );
	if ( 1 !== (int) $n ) {
		$wpdb->delete( ogc_table( 'records' ), array( 'id' => $new ), array( '%d' ) );
		return ogc_vol_no( 'taken', 'Taken' );
	}
	ogc_record_delete( $old['id'] );
	ogc_vol_change( $y, $sh, 'swap', $name, array( 'from' => $old['data']['name'] ) );
	ogc_vol_queue_person( $y, $old, 'swapped', array( 'to' => ogc_vol_first_l( $name ) ) );
	ogc_vol_queue_confirm( $y, $email, array( $new ), $actor['signed'] );
	ogc_vol_head_notice( $y, $sh, 'swap', array( 'from' => ogc_vol_first_l( $old['data']['name'] ), 'to' => ogc_vol_first_l( $name ) ) );
	ogc_log( 'vol_swap', $y, 'signups', array( 'from' => $old['id'], 'to' => $new ) );
	$out = array( 'taken' => $new );
	if ( ! $actor['signed'] ) {
		ogc_vol_device_link( array( $new ) );
		$out['hold']      = ogc_vol_token( array( 'a' => 'hold', 'y' => $y, 'e' => $email, 'r' => array( $new ) ), DAY_IN_SECONDS );
		$actor['holds'][ $new ] = $email;
	}
	$out['mine']   = ogc_vol_mine( $y, $actor );
	$out['shifts'] = (object) ogc_vol_public_shifts( $y, $actor );
	return rest_ensure_response( $out );
}

/* ================================================================== the person's settings */

/** Show my name (one setting for all my sign-ups), and email me when next year's sign-ups open. */
function ogc_vol_rest_me( WP_REST_Request $req ) {
	$y     = (int) $req['year'];
	$actor = ogc_vol_actor( $req );
	$show  = $req->get_param( 'show' );
	$next  = $req->get_param( 'next_year' );
	$who   = ogc_vol_clean_name( $req->get_param( 'name' ) );
	// Show all (after the sixth critic, Oct 15): several names at once, each by an exact name; never an
	// Under 18 (the public list never names one anyway).
	$names = array_map( 'strtolower', array_filter( array_map( 'ogc_vol_clean_name', array_slice( (array) $req->get_param( 'names' ), 0, 12 ) ) ) );
	// A phone, given once someone added by another person has confirmed (Add someone asks only a name
	// and an email): it goes on their own places that have none.
	$phone = null !== $req->get_param( 'phone' ) ? ogc_vol_clean_phone( $req->get_param( 'phone' ) ) : null;
	if ( null !== $phone && ( ! $phone || ! $actor['signed'] ) ) {
		return ogc_vol_no( 'fields', 'Check the form.', array( 'fields' => array( 'phone' => 'Enter a phone number' ) ), 400 );
	}
	// Their own name (a head or someone else may have signed them up under it: still theirs to show).
	$selfn = $actor['signed'] ? ogc_vol_self_name( $y, $actor['email'] ) : '';
	foreach ( ogc_records( $y, 'signups' ) as $r ) {
		if ( ! ogc_vol_owns( $actor, $r ) ) {
			continue;
		}
		$d    = $r['data'];
		$own  = $actor['signed'] && $r['email'] === $actor['email'];
		// Show my name is the person's own; another in the household is changed only by name. A place
		// someone added you to (under your own email) is yours to show; the one who added you can't.
		$for_me = $names ? in_array( strtolower( trim( (string) $d['name'] ) ), $names, true ) && empty( $d['minor'] ) : ( $who ? 0 === strcasecmp( $who, (string) $d['name'] ) : ( empty( $d['for'] ) || ( ! empty( $d['helper_email'] ) && $own ) || ( $own && '' !== $selfn && 0 === strcasecmp( $selfn, trim( (string) $d['name'] ) ) ) ) );
		if ( ! empty( $d['helper_email'] ) && ! $own ) {
			$for_me = false;
		}
		if ( null !== $show && $for_me ) {
			$d['hide'] = ! $show;
			$d['show'] = (bool) $show;
		}
		if ( null !== $next && ( $own || empty( $d['helper_email'] ) ) ) {
			$d['next_year'] = (bool) $next;
		}
		ogc_record_update( $r['id'], $d, $r['email'] );
	}
	// Their phone (Change on their own pill, or the one asked once someone added has confirmed): on every
	// place under their own email this year, as the one they chose (after the third critic, Oct 15).
	if ( $phone ) {
		ogc_vol_set_phone( $y, $actor['email'], $phone );
	}
	return rest_ensure_response( array( 'mine' => ogc_vol_mine( $y, $actor ), 'shifts' => (object) ogc_vol_public_shifts( $y, $actor ), 'phone' => $phone ? $phone : null ) );
}

/** A signed-in person's chosen phone on each of their own places this year (their email's, confirmed;
 * not someone they added under their own email). Records only: nothing else keeps it. */
function ogc_vol_set_phone( $year, $email, $phone ) {
	$email = strtolower( trim( (string) $email ) );
	if ( ! is_email( $email ) || '' === (string) $phone ) {
		return 0;
	}
	$n = 0;
	foreach ( array( 'signups', 'waits' ) as $kind ) {
		foreach ( ogc_records( $year, $kind, $email ) as $r ) {
			$d = $r['data'];
			if ( ! ogc_vol_rec_confirmed( $r ) || ( isset( $d['phone'] ) && $d['phone'] === $phone && ! empty( $d['phone_set'] ) ) ) {
				continue;
			}
			$d['phone']     = $phone;
			$d['phone_set'] = true;
			ogc_record_update( $r['id'], $d, $r['email'] );
			$n++;
		}
	}
	return $n;
}

/**
 * Email me when sign-ups open (before they're posted). Each request is its own record (kind notify, one
 * per address and year), so two at once can't lose one. The address gets one short email at once
 * ("You'll get one email when they open · Not you? Remove me"), so a neighbour's address typed in
 * isn't kept without them knowing. Sent once when sign-ups open, then the records are erased.
 */
function ogc_vol_rest_notify( WP_REST_Request $req ) {
	$y     = (int) $req['year'];
	$email = ogc_current_email() ?: strtolower( sanitize_email( (string) $req->get_param( 'email' ) ) );
	if ( '' !== (string) $req->get_param( 'hp' ) ) {
		return rest_ensure_response( array( 'ok' => true ) );
	}
	if ( ! is_email( $email ) ) {
		return ogc_vol_no( 'fields', 'Check the form.', array( 'fields' => array( 'email' => 'Enter your email' ) ), 400 );
	}
	if ( ! ogc_vol_rate( 'notify|' . ogc_vol_ip(), 10 ) ) {
		return ogc_vol_no( 'slow', 'Too many at once. Try again later.', array(), 429 );
	}
	if ( ! ogc_records( $y, 'notify', $email ) && ! in_array( $email, (array) ( ( ogc_state_get( $y, 'vol-notify' ) ?: array( 'value' => array() ) )['value'] ), true ) ) {
		ogc_record_insert( $y, 'notify', array( 'email' => $email, 'at' => gmdate( 'c', ogc_vol_now() ) ), $email, false, 'web' );
		ogc_vol_queue( $y, 'notify', $email, array() );
		ogc_log( 'vol_notify', $y, 'notify', array() );
	}
	return rest_ensure_response( array( 'ok' => true ) );
}

/* ================================================================== this device, a mistyped email */

/** Not you? (not signed in): this device forgets the sign-ups it made for the year. The places stay
 * (the emailed Confirm or Not you decides); only this browser stops seeing them. */
function ogc_vol_rest_forget( WP_REST_Request $req ) {
	global $wpdb;
	$y = (int) $req['year'];
	$h = function_exists( 'ogc_device_hash' ) ? ogc_device_hash() : '';
	if ( $h && ! is_user_logged_in() ) {
		$wpdb->query( $wpdb->prepare( 'DELETE d FROM ' . ogc_table( 'devices' ) . ' d JOIN ' . ogc_table( 'records' ) . " r ON r.id = d.record_id WHERE d.dhash = %s AND r.year = %d AND r.kind IN ('signups','waits')", $h, $y ) );
	}
	return rest_ensure_response( array( 'forgot' => true ) );
}

/** This actor's unconfirmed sign-ups among the ids asked for. */
function ogc_vol_unconfirmed_owned( $y, $actor, $ids ) {
	$out = array();
	foreach ( array_slice( array_map( 'intval', (array) $ids ), 0, 20 ) as $id ) {
		$r = ogc_record_get( $id );
		// Signed in, a place under one's own email made on another device (`pending`, after the eighth
		// critic, Oct 16) may be sent again too: the email goes to that same address.
		if ( $r && 'signups' === $r['kind'] && (int) $r['year'] === $y && empty( $r['data']['confirmed'] ) && ( ogc_vol_owns( $actor, $r ) || ( $actor['signed'] && $r['email'] === $actor['email'] ) ) ) {
			$out[] = $r;
		}
	}
	return $out;
}

/** Resend: the confirmation again, for unconfirmed sign-ups (once a minute, five an hour to one address). */
function ogc_vol_rest_resend( WP_REST_Request $req ) {
	$y    = (int) $req['year'];
	$recs = ogc_vol_unconfirmed_owned( $y, ogc_vol_actor( $req ), $req->get_param( 'ids' ) );
	if ( ! $recs ) {
		return ogc_vol_no( 'gone', 'Not found', array(), 404 );
	}
	$email = $recs[0]['email'];
	if ( ! ogc_vol_rate( 'resend1|' . $email, 1, MINUTE_IN_SECONDS ) ) {
		return ogc_vol_no( 'slow', 'Sent · Just now', array(), 429 );
	}
	ogc_vol_queue_confirm( $y, $email, wp_list_pluck( $recs, 'id' ), false, 0, true );
	ogc_log( 'vol_resend', $y, 'signups', array( 'n' => count( $recs ) ) );
	return rest_ensure_response( array( 'sent' => true, 'email' => $email ) );
}

/** Change email: an unconfirmed sign-up moves to the address typed, keeping its place (the same seat),
 * and the confirmation goes there. A likely typo ("gmial.com") is asked about once (409 ogc_typo). */
function ogc_vol_rest_email( WP_REST_Request $req ) {
	global $wpdb;
	$y     = (int) $req['year'];
	$actor = ogc_vol_actor( $req );
	$email = strtolower( sanitize_email( (string) $req->get_param( 'email' ) ) );
	if ( ! is_email( $email ) ) {
		return ogc_vol_no( 'fields', 'Check the form.', array( 'fields' => array( 'email' => 'Enter your email' ) ), 400 );
	}
	$fix = function_exists( 'ogc_email_suggest' ) ? ogc_email_suggest( $email ) : '';
	if ( $fix && $fix !== $email && ! $req->get_param( 'typos_ok' ) ) {
		return ogc_vol_no( 'typo', 'Check the email', array( 'fix' => $fix ) );
	}
	if ( ! ogc_vol_rate( 'email|' . ogc_vol_ip(), 20 ) ) {
		return ogc_vol_no( 'slow', 'Too many at once. Try again later.', array(), 429 );
	}
	$recs = ogc_vol_unconfirmed_owned( $y, $actor, $req->get_param( 'ids' ) );
	if ( ! $recs ) {
		return ogc_vol_no( 'gone', 'Not found', array(), 404 );
	}
	$moved = array();
	foreach ( $recs as $r ) {
		$d          = $r['data'];
		$d['email'] = $email;
		ogc_vol_outbox_drop( $r['id'] );
		ogc_record_update( $r['id'], $d, $email );
		// The same place under the new address (the seat's person key follows the email).
		$wpdb->update( ogc_table( 'vol_seats' ), array( 'pkey' => ogc_vol_pkey( $email, $d['name'], isset( $d['phone'] ) ? $d['phone'] : '' ) ), array( 'record_id' => (int) $r['id'] ), array( '%s' ), array( '%d' ) );
		$moved[] = (int) $r['id'];
	}
	ogc_vol_queue_confirm( $y, $email, $moved, false, 0 );
	$out = array( 'email' => $email, 'moved' => $moved );
	if ( ! $actor['signed'] ) {
		// The device's hold names the new address.
		$out['hold'] = ogc_vol_token( array( 'a' => 'hold', 'y' => $y, 'e' => $email, 'r' => $moved ), DAY_IN_SECONDS );
		$actor['holds'] += array_fill_keys( $moved, $email );
	}
	$out['mine'] = ogc_vol_mine( $y, $actor );
	ogc_log( 'vol_email_changed', $y, 'signups', array( 'n' => count( $moved ) ) );
	return rest_ensure_response( $out );
}

/* ================================================================== emailed links */

/**
 * An emailed link, opened on the page: { link: 1 } (the token in this browser's short cookie) or { t }.
 *   confirm   the email is theirs: the sign-ups show their name (this one never signs in; the usual
 *             Confirm link is the signin area's single-use one, ogc_vol_confirm_link)
 *   notme     someone typed this email: the sign-ups are removed and the head is told (once)
 *   leave     a sign-up's Leave shift (asks first on the page)
 *   opened    a place opened on a shift they wait for: Join, one tap (the join route takes the link);
 *             do: unwait takes them off the waitlist instead
 *   again     next year's sign-ups are open: last year's shifts again (the join route takes the link)
 *   unnotify  Remove me: no email when sign-ups open
 * The answer names the address only masked ("h…@gmail.com"): the page shows no more than that.
 */
function ogc_vol_rest_link( WP_REST_Request $req ) {
	$y = (int) $req['year'];
	// The page a Confirm link opened (?confirmed=): what's true of that link's places now, for the same
	// signed-in email only (ogc_vol_confirm_follow). Nothing is confirmed here.
	if ( $req->get_param( 'cf' ) ) {
		$tid = isset( $_COOKIE['ogc_vcf'] ) ? (int) $_COOKIE['ogc_vcf'] : 0; // phpcs:ignore -- an id, checked below.
		$me  = ogc_current_email();
		$t   = null;
		if ( $tid && '' !== $me ) {
			global $wpdb;
			$t = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . ogc_table( 'tokens' ) . ' WHERE id = %d', $tid ), ARRAY_A );
			if ( $t ) {
				$t['data'] = (array) ogc_unjson( $t['data'], array() );
			}
		}
		if ( ! $t || 'confirm' !== $t['kind'] || strtolower( (string) $t['email'] ) !== $me || empty( $t['data']['vol']['y'] ) || (int) $t['data']['vol']['y'] !== $y ) {
			return rest_ensure_response( array( 'a' => 'confirm', 'follow' => false ) );
		}
		$ids = isset( $t['data']['vol']['r'] ) ? array_map( 'intval', (array) $t['data']['vol']['r'] ) : array();
		// With the rest of the burst it confirmed: every shift is said ("Preteen helper · Snack helper").
		$ids = ogc_vol_link_ids_with_burst( $y, $me, $ids, (int) $t['id'] );
		return rest_ensure_response( array_merge( array( 'a' => 'confirm', 'follow' => true, 'n' => ogc_vol_shift_count( $ids ) ), ogc_vol_link_groups( $y, $me, $ids ) ) );
	}
	$p = ogc_vol_link_of( $req );
	if ( ! $p || (int) $p['y'] !== $y ) {
		return ogc_vol_no( 'expired', 'Link expired', array(), 410 );
	}
	$email = strtolower( (string) $p['e'] );
	$ids   = array_map( 'intval', (array) ( isset( $p['r'] ) ? $p['r'] : array() ) );
	$recs  = array();
	foreach ( $ids as $id ) {
		$r = ogc_record_get( $id );
		if ( $r && 'signups' === $r['kind'] && $r['email'] === $email ) {
			$recs[] = $r;
		}
	}
	$m   = preg_match( '/^(.)[^@]*(@.*)$/', $email, $mm ) ? $mm[1] . '…' . $mm[2] : '';
	$out = array( 'a' => $p['a'], 'email' => $m );
	// What it was for, one line a shift with its people ("Server · Sat, May 29 · Martha and Henry").
	$out['lines'] = ogc_vol_lines_of( $y, $recs );
	if ( 'confirm' === $p['a'] ) {
		$via  = isset( $p['_id'] ) ? (int) $p['_id'] : 0;
		ogc_vol_confirm_records( $y, $email, $ids, $via );
		// Every shift it confirmed, the burst's too (after the eighth critic, Oct 16).
		$all = ogc_vol_link_ids_with_burst( $y, $email, $ids, $via );
		foreach ( array_diff( $all, $ids ) as $id ) {
			$r = ogc_record_get( $id );
			if ( $r ) {
				$recs[] = $r;
			}
		}
		$out['lines'] = ogc_vol_lines_of( $y, $recs );
		$out['n']     = ogc_vol_shift_count( wp_list_pluck( $recs, 'id' ) );
		$out          = array_merge( $out, ogc_vol_link_groups( $y, $email, $all ) );
		ogc_log( 'vol_confirm', $y, 'signups', array( 'n' => count( $recs ) ) );
	} elseif ( 'notme' === $p['a'] ) {
		// Once: the link is spent with it.
		if ( function_exists( 'ogc_token_spend' ) ) {
			ogc_token_spend( array( 'id' => $p['_id'] ), 0 );
		}
		$shifts = ogc_vol_shifts( $y );
		foreach ( $recs as $r ) {
			ogc_record_delete( $r['id'] );
			ogc_vol_release_record( $r['id'] );
			ogc_vol_outbox_drop( $r['id'] );
			if ( isset( $shifts[ $r['data']['id'] ] ) ) {
				ogc_vol_change( $y, $shifts[ $r['data']['id'] ], 'notme', $r['data']['name'] );
				ogc_vol_head_notice( $y, $shifts[ $r['data']['id'] ], 'notme', array( 'name' => ogc_vol_first_l( $r['data']['name'] ) ) );
				ogc_vol_notify_waitlist( $y, $shifts[ $r['data']['id'] ] );
			}
		}
		$out['n'] = count( $out['lines'] );
		ogc_log( 'vol_notme', $y, 'signups', array( 'n' => count( $recs ) ) );
	} elseif ( 'leave' === $p['a'] ) {
		$out['records'] = array_map( 'ogc_vol_mine_out', $recs );
		// Who the link was sent for, and whether they're still on (after the fourth critic, Oct 15: Miriam's
		// old link, after she'd left, opened on "Leave this shift?" with Glen's place as its one action).
		$out = array_merge( $out, ogc_vol_link_groups( $y, $email, $ids ) );
	} elseif ( 'opened' === $p['a'] || 'again' === $p['a'] ) {
		$out['shifts'] = array_values( (array) ( isset( $p['s'] ) ? $p['s'] : array() ) );
		$out['names']  = array_values( (array) ( isset( $p['n'] ) ? $p['n'] : array() ) );
		// The "Sign-ups open" email's Sign up again (after the fifth critic, Oct 15): each of last year's
		// shifts as this email can take it now, with only its own people (the card the page draws for a
		// signed-in returner, the same).
		if ( 'again' === $p['a'] ) {
			$ids_s        = array_map( 'strval', $out['shifts'] );
			$out['again'] = array_values( array_filter( ogc_vol_again_view( $y, $email ), function ( $a ) use ( $ids_s ) {
				return ! $ids_s || ! $a['shift'] || in_array( (string) $a['shift'], $ids_s, true );
			} ) );
			// Whether a phone is known for the email (the card asks one only when not; never the number).
			$out['has_phone'] = '' !== ogc_vol_known_phone( $y, $email );
		}
		// Everyone of the address the email named as waiting (`ws`, after the ninth critic: one email an
		// address); an older link has its one `w`.
		$wl = array();
		foreach ( ! empty( $p['ws'] ) ? (array) $p['ws'] : ( ! empty( $p['w'] ) ? array( $p['w'] ) : array() ) as $wid ) {
			$w = ogc_record_get( (int) $wid );
			if ( $w && 'waits' === $w['kind'] && $w['email'] === $email ) {
				$wl[] = $w;
			}
		}
		$out['waiting'] = (bool) $wl;
		if ( 'unwait' === $req->get_param( 'do' ) && $out['waiting'] ) {
			foreach ( $wl as $w ) {
				ogc_record_delete( $w['id'] );
			}
			$out['waiting'] = false;
			$out['unwaited'] = true;
		}
	} elseif ( 'unnotify' === $p['a'] ) {
		foreach ( ogc_records( $y, 'notify', $email ) as $r ) {
			ogc_record_delete( $r['id'] );
		}
		$out['removed'] = true;
	}
	return rest_ensure_response( $out );
}
