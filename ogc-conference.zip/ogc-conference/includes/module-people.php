<?php
/**
 * People and access (Round 6b, Oct 17; docs/27-back-end-map/area-people-access.md; CHANGES/round6b-people-access.md).
 * The pieces the people screens share, on the server:
 *
 *   - the person (GET app/{y}/person?id=): one member as the viewer may see them, with Linked (committees,
 *     tasks given, screens run), History, and the phone for the COA only (never while seeing as);
 *   - asks to add someone (P20): a head or helper's "Ask the COA" is a record the COA answers on Members ›
 *     Asked (POST years/{y}/members/asks; GET …/asks; POST …/asks/{id}/dismiss), with the access asks from
 *     No access beside them; the address is kept only until it's answered, or 30 days;
 *   - Members' Export (GET years/{y}/members/export): the fixed columns, Email and Phone "Withheld" while
 *     seeing as;
 *   - the webmasters' facts: each year's state (GET app/{y}/years: started, the COA's state, Names cleared),
 *     and Email (GET app/{y}/email, …/email/day, …/email/preview: by kind and day, no one's address);
 *   - one rule for "ending soon" (30 days, P9) and for the COA's state (8.5).
 *
 * Nothing here decides who may do what to a member: that's ogc_member_can() (module-members.php), asked
 * by every route. Reads only, except the asks.
 */

defined( 'ABSPATH' ) || exit;

/* ================================================================== the screens */

// Email: the webmasters' screen (section 9). The webmasters' section reads Years · Access · Email ·
// Privacy (README 2.1): Years is moved before Access, Email after it. The COA's order isn't touched.
add_filter( 'ogc_app_screens', function ( $s, $year ) {
	$s['email'] = array( 'title' => 'Email', 'section' => 'own', 'who' => array( 'webmaster' ), 'handable' => false, 'icon' => 'mail' );
	if ( ! isset( $s['members'] ) ) {
		return $s;
	}
	$out = array();
	foreach ( $s as $id => $d ) {
		if ( 'years' === $id || 'email' === $id ) {
			continue;
		}
		if ( 'members' === $id ) {
			if ( isset( $s['years'] ) ) {
				$out['years'] = $s['years'];
			}
			$out['members'] = $d;
			$out['email']   = $s['email'];
			continue;
		}
		$out[ $id ] = $d;
	}
	return $out;
}, 1000, 2 );

add_filter( 'ogc_pages', function ( $p ) {
	if ( isset( $p['app'] ) ) {
		$p['app']['styles'][]  = 'app/screens/people.css';
		$p['app']['scripts'][] = 'app/screens/people-kit.js';
		$p['app']['scripts'][] = 'app/screens/webmaster-email.js';
	}
	return $p;
}, 26 );

/* ================================================================== one rule each */

/** Ending soon: access ends within 30 days, or has ended (P9). Members, Access and the webmasters' Home. */
function ogc_member_ending_soon( $m, $today = '' ) {
	if ( ! empty( $m['removed_at'] ) ) {
		return false;
	}
	$x = ogc_member_expiry( $m );
	if ( ! $x ) {
		return false;
	}
	$now = $today ? strtotime( $today . ' 12:00:00 UTC' ) : time();
	return strtotime( $x . ' UTC' ) < $now + 30 * DAY_IN_SECONDS;
}

/** The COA's state for a year (8.5): none | invited | active, how many of each, and Late (no one signed
 * in 8 weeks after the hosts were named). Years, Access and the webmasters' Home say the same. */
function ogc_year_coa_state( $year ) {
	$coa = array_values( array_filter( ogc_members_list( (int) $year ), function ( $m ) {
		return 'coa' === $m['role'] && ogc_member_active( $m );
	} ) );
	$active = count( array_filter( $coa, function ( $m ) {
		return ! empty( $m['signed_in_at'] );
	} ) );
	$row   = ogc_year_get( (int) $year );
	$named = $row && ! empty( $row['announced'] ) ? (string) $row['announced'] : '';
	$late  = ! $active && $named && strtotime( $named . ' 12:00 UTC' ) + 56 * DAY_IN_SECONDS < time();
	return array(
		'state'   => $active ? 'active' : ( $coa ? 'invited' : 'none' ),
		'invited' => count( $coa ),
		'active'  => $active,
		'late'    => (bool) $late,
		'words'   => $coa ? $active . ' of ' . count( $coa ) . ' signed in' : 'Not invited',
	);
}

/** When a year's names clear (read only, P16): the lists' own day (module-lists.php), and whether it has. */
function ogc_year_clears( $year ) {
	if ( ! function_exists( 'ogc_lst_ctx' ) ) {
		return array( 'on' => '', 'days' => 60, 'cleared' => '' );
	}
	$ctx  = ogc_lst_ctx( (int) $year );
	$cfg  = (array) $ctx['cfg'];
	$days = isset( $cfg['clear_after_days'] ) && is_numeric( $cfg['clear_after_days'] ) ? max( 1, (int) $cfg['clear_after_days'] ) : 60;
	return array(
		'on'      => (string) $ctx['clear_on'],
		'days'    => $days,
		'cleared' => $ctx['cleared'] && ! empty( $ctx['cleared']['day'] ) ? (string) $ctx['cleared']['day'] : '',
	);
}

/* ================================================================== asks to add someone (P20) */

/** The year's asks: a head's (kept here) and the access asks from No access (the log's member_ask). */
function ogc_people_asks_store( $year ) {
	$s = ogc_state_get( (int) $year, 'member_asks' );
	return $s && is_array( $s['value'] ) ? array_values( (array) $s['value'] ) : array();
}

function ogc_people_asks_put( $year, $list ) {
	return ogc_state_put( (int) $year, 'member_asks', array_values( $list ) );
}

/** An ask's address is kept only until it's answered, or 30 days. */
function ogc_people_ask_live( $a ) {
	return 'open' === $a['status'] && strtotime( (string) $a['at'] . ' UTC' ) > time() - 30 * DAY_IN_SECONDS;
}

/**
 * The open asks, as the COA reads them (Members › Asked), newest first: { id, kind (head|access), name,
 * email, c, cname, by, at, was }.
 */
function ogc_people_asks_open( $year ) {
	global $wpdb;
	$year = (int) $year;
	$coms = ogc_members_committee_list( $year );
	$out  = array();
	foreach ( ogc_people_asks_store( $year ) as $a ) {
		if ( ! ogc_people_ask_live( $a ) ) {
			continue;
		}
		$by    = ! empty( $a['by'] ) ? ogc_member_get( (int) $a['by'] ) : null;
		$out[] = array(
			'id'    => 'h' . (int) $a['id'],
			'kind'  => 'head',
			'name'  => (string) $a['name'],
			'email' => (string) $a['email'],
			'c'     => (string) $a['c'],
			'cname' => isset( $coms[ $a['c'] ] ) ? $coms[ $a['c'] ] : (string) $a['c'],
			'by'    => $by ? ogc_member_short( $by ) : '',
			'by_id' => $by ? (int) $by['id'] : 0,
			'at'    => substr( (string) $a['at'], 0, 10 ),
		);
	}
	// Ask for access (No access, module-members.php): only someone who had a row for the year can ask.
	$seen = ogc_state_get( $year, 'member_ask_seen' );
	$seen = $seen && is_array( $seen['value'] ) ? (array) $seen['value'] : array();
	$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT id, at, user, target FROM ' . ogc_table( 'log' ) . " WHERE year = %d AND action = 'member_ask' AND at > %s ORDER BY id DESC LIMIT 40", $year, gmdate( 'Y-m-d H:i:s', time() - 30 * DAY_IN_SECONDS ) ), ARRAY_A );
	$once = array();
	foreach ( (array) $rows as $r ) {
		if ( isset( $seen[ 'a' . $r['id'] ] ) ) {
			continue;
		}
		$m = preg_match( '/^member:(\d+)$/', (string) $r['target'], $x ) ? ogc_member_get( (int) $x[1] ) : null;
		// Back on the year since they asked: answered.
		if ( ! $m || ( ! $m['removed_at'] && ogc_member_active( $m ) ) || isset( $once[ $m['id'] ] ) ) {
			continue;
		}
		$once[ $m['id'] ] = true;
		$was = $m['removed_at'] ? 'Removed ' . ogc_member_date( $m['removed_at'] ) : ( ogc_member_expiry( $m ) ? 'Access ended ' . ogc_member_date( ogc_member_expiry( $m ) ) : '' );
		$keys = ogc_member_committee_keys( $m );
		$out[] = array(
			'id'     => 'a' . (int) $r['id'],
			'kind'   => 'access',
			'name'   => $m['name'] ? (string) $m['name'] : '',
			'email'  => (string) $m['email'],
			'c'      => $keys ? $keys[0] : '',
			'cs'     => $keys,
			'cname'  => $keys ? implode( ', ', array_map( function ( $k ) use ( $coms ) {
				return isset( $coms[ $k ] ) ? $coms[ $k ] : $k;
			}, $keys ) ) : ( 'coa' === $m['role'] ? 'COA' : '' ),
			'by'     => '',
			'member' => (int) $m['id'],
			'at'     => substr( (string) $r['at'], 0, 10 ),
			'was'    => $was,
		);
	}
	usort( $out, function ( $a, $b ) {
		return strcmp( $b['at'], $a['at'] );
	} );
	return $out;
}

/** Mark a head's ask answered (added or dismissed): its address goes. */
function ogc_people_ask_close( $year, $id, $status ) {
	$list = ogc_people_asks_store( $year );
	$hit  = false;
	foreach ( $list as &$a ) {
		if ( 'h' . (int) $a['id'] === (string) $id && 'open' === $a['status'] ) {
			$a['status']  = $status;
			$a['email']   = '';
			$a['done_at'] = ogc_now();
			$a['done_by'] = get_current_user_id();
			$hit          = true;
		}
	}
	unset( $a );
	if ( $hit ) {
		ogc_people_asks_put( $year, $list );
		ogc_log( 'member_ask_' . ( 'added' === $status ? 'added' : 'dismissed' ), (int) $year, 'ask:' . $id, array() );
	}
	return $hit;
}

// The address of an old ask goes after 30 days, whatever happened to it.
add_action( 'ogc_daily', function () {
	foreach ( ogc_years_list() as $y ) {
		$list = ogc_people_asks_store( $y );
		$ch   = false;
		foreach ( $list as &$a ) {
			if ( '' !== (string) $a['email'] && ! ogc_people_ask_live( $a ) ) {
				$a['email'] = '';
				$ch         = true;
			}
		}
		unset( $a );
		if ( $ch ) {
			ogc_people_asks_put( $y, $list );
		}
	}
} );

// The COA's Home: "1 ask to add · Lodging · Open" (area-home-tasks; P20).
add_filter( 'ogc_app_needs', function ( $rows, $year, $ckey, $ctx ) {
	if ( 'coa' !== $ckey || empty( $ctx['viewer']['coa'] ) ) {
		return $rows;
	}
	$asks = ogc_people_asks_open( $year );
	if ( ! $asks ) {
		return $rows;
	}
	$names = array_values( array_unique( array_filter( wp_list_pluck( $asks, 'cname' ) ) ) );
	$rows[] = array(
		'key'    => 'asks',
		'words'  => count( $asks ) . ' ' . ( 1 === count( $asks ) ? 'ask' : 'asks' ) . ' to add',
		'why'    => implode( ' · ', array_slice( $names, 0, 3 ) ),
		'go'     => array( 's' => 'members', 'v' => 'asked' ),
		'button' => 'Open',
		'tone'   => 'look',
		'rank'   => 2,
		'kind'   => 'asks',
	);
	return $rows;
}, 20, 4 );

/* ================================================================== the email to the COA */

add_filter( 'ogc_mail_kinds', function ( $k ) {
	$k['member_ask_add'] = 'Ask to add (a head, to the COA)';
	return $k;
} );
add_filter( 'ogc_mail_samples', function ( $s ) {
	$s['member_ask_add'] = array( 'by' => 'Ada T.', 'name' => 'Ruth K.', 'committee' => 'Lodging', 'url' => ogc_url( 'app', array( 's' => 'members', 'v' => 'asked' ) ), 'to' => 'nathan.keller@example.com' );
	return $s;
} );
add_filter( 'ogc_mail_template_kind', function ( $m, $kind, $d, $base ) {
	if ( 'member_ask_add' !== $kind ) {
		return $m;
	}
	$com = isset( $d['committee'] ) ? wp_strip_all_tags( (string) $d['committee'] ) : '';
	$by  = isset( $d['by'] ) ? wp_strip_all_tags( (string) $d['by'] ) : '';
	$who = isset( $d['name'] ) ? wp_strip_all_tags( (string) $d['name'] ) : '';
	return ogc_mail_compose( array_merge( $base, array(
		'subject' => 'Ask to add' . ( $com ? ' · ' . $com : '' ),
		'heading' => 'Ask to add' . ( $com ? ' · ' . $com : '' ),
		'facts'   => array( array( 'Who', $who ), array( 'Asked by', $by ), array( 'Committee', $com ) ),
		'lines'   => array( 'Add or dismiss it on Members.' ),
		'button'  => ! empty( $d['url'] ) ? array( 'Open Members', (string) $d['url'] ) : null,
		'reason'  => 'You’re on the ' . ( ! empty( $d['year'] ) ? (int) $d['year'] . ' ' : '' ) . 'COA.',
	) ) );
}, 10, 4 );

/* ================================================================== routes */

add_action( 'rest_api_init', function () {
	$Y = '(?P<year>\d{4})';
	// A write while seeing as is refused (the members routes ask the same in module-members.php).
	$ro = function ( WP_REST_Request $req ) {
		return '' !== (string) $req->get_param( 'as' ) ? new WP_Error( 'ogc_read_only', 'Read only while seeing as', array( 'status' => 403 ) ) : null;
	};
	register_rest_route( OGC_NS, "/years/$Y/members/asks", array(
		array( 'methods' => 'GET', 'callback' => 'ogc_people_rest_asks', 'permission_callback' => function ( WP_REST_Request $req ) {
			return ogc_valid_year( $req['year'] ) && ( ogc_is_member( (int) $req['year'] ) || ogc_is_webmaster() ) ? true : ogc_rest_denied();
		} ),
		array( 'methods' => 'POST', 'callback' => 'ogc_people_rest_ask_add', 'permission_callback' => function ( WP_REST_Request $req ) use ( $ro ) {
			$e = $ro( $req );
			if ( $e ) {
				return $e;
			}
			$me = ogc_member_me( (int) $req['year'] );
			return $me && 'coa' !== $me['role'] && ogc_member_active( $me ) ? true : ogc_rest_denied( 'Only someone on the committee asks' );
		} ),
	) );
	register_rest_route( OGC_NS, "/years/$Y/members/asks/(?P<id>[ah]\d+)/dismiss", array(
		array( 'methods' => 'POST', 'callback' => 'ogc_people_rest_ask_dismiss', 'permission_callback' => function ( WP_REST_Request $req ) use ( $ro ) {
			$e = $ro( $req );
			if ( $e ) {
				return $e;
			}
			return ogc_member_can( 'invite', (int) $req['year'] ) && ! ogc_is_webmaster() ? true : ogc_rest_denied();
		} ),
	) );
	register_rest_route( OGC_NS, "/years/$Y/members/export", array(
		array( 'methods' => 'GET', 'callback' => 'ogc_people_rest_export', 'permission_callback' => 'ogc_can_members_read' ),
	) );
	$app = function ( $screen ) {
		return function ( WP_REST_Request $req ) use ( $screen ) {
			if ( ! function_exists( 'ogc_app_req_viewer' ) || ! is_user_logged_in() ) {
				return ogc_rest_denied( 'Sign in first.' );
			}
			return ogc_app_can_see( ogc_app_req_viewer( $req ), $screen ) ? true : ogc_rest_denied();
		};
	};
	register_rest_route( OGC_NS, "/app/$Y/person", array( 'methods' => 'GET', 'callback' => 'ogc_people_rest_person', 'permission_callback' => $app( 'members' ) ) );
	register_rest_route( OGC_NS, "/app/$Y/years", array( 'methods' => 'GET', 'callback' => 'ogc_people_rest_years', 'permission_callback' => $app( 'years' ) ) );
	register_rest_route( OGC_NS, "/app/$Y/email", array( 'methods' => 'GET', 'callback' => 'ogc_people_rest_email', 'permission_callback' => $app( 'email' ) ) );
	register_rest_route( OGC_NS, "/app/$Y/email/day", array( 'methods' => 'GET', 'callback' => 'ogc_people_rest_email_day', 'permission_callback' => $app( 'email' ) ) );
	register_rest_route( OGC_NS, "/app/$Y/email/preview", array( 'methods' => 'GET', 'callback' => 'ogc_people_rest_email_preview', 'permission_callback' => $app( 'email' ) ) );
} );

/** A head's or helper's ask: { c, name, email }. Only someone on that committee; 10 a day. */
function ogc_people_rest_ask_add( WP_REST_Request $req ) {
	$y  = (int) $req['year'];
	$me = ogc_member_me( $y );
	$c  = ogc_committee_key( (string) $req->get_param( 'c' ) );
	if ( ! in_array( $c, ogc_member_committee_keys( $me ), true ) ) {
		return ogc_rest_denied( 'Only someone on the committee asks' );
	}
	$name  = ogc_mail_safe_name( (string) $req->get_param( 'name' ) );
	$email = ogc_clean_email( (string) $req->get_param( 'email' ) );
	if ( '' === $name ) {
		return new WP_Error( 'ogc_bad', 'Name needed', array( 'status' => 400, 'field' => 'name' ) );
	}
	if ( ! is_email( $email ) ) {
		return new WP_Error( 'ogc_bad', 'Email needed', array( 'status' => 400, 'field' => 'email' ) );
	}
	if ( $email === strtolower( (string) $me['email'] ) ) {
		return new WP_Error( 'ogc_self', 'Not your own email', array( 'status' => 403, 'field' => 'email' ) );
	}
	$have = ogc_member_find( $y, $email );
	if ( $have && ogc_member_active( $have ) && in_array( $c, ogc_member_committee_keys( $have ), true ) ) {
		return new WP_Error( 'ogc_exists', 'Already on it', array( 'status' => 409, 'field' => 'email' ) );
	}
	if ( ogc_throttle( 'askadd:' . get_current_user_id() . ':' . $y, 10, DAY_IN_SECONDS ) ) {
		return new WP_Error( 'ogc_rate', 'Ten asks a day · Try tomorrow', array( 'status' => 429 ) );
	}
	$list = ogc_people_asks_store( $y );
	foreach ( $list as $a ) {
		if ( ogc_people_ask_live( $a ) && strtolower( (string) $a['email'] ) === $email && $a['c'] === $c ) {
			return new WP_Error( 'ogc_exists', 'Asked already', array( 'status' => 409, 'field' => 'email' ) );
		}
	}
	$id     = 1 + array_reduce( $list, function ( $m, $a ) {
		return max( $m, (int) $a['id'] );
	}, 0 );
	$list[] = array( 'id' => $id, 'c' => $c, 'name' => $name, 'email' => $email, 'by' => (int) $me['id'], 'by_uid' => get_current_user_id(), 'at' => ogc_now(), 'status' => 'open' );
	$ok     = ogc_people_asks_put( $y, $list );
	if ( is_wp_error( $ok ) ) {
		return $ok;
	}
	ogc_log( 'member_ask_add', $y, 'ask:h' . $id, array( 'ckey' => $c ) );
	$coms = ogc_members_committee_list( $y );
	foreach ( ogc_members_list( $y ) as $m ) {
		if ( 'coa' === $m['role'] && ogc_member_active( $m ) ) {
			ogc_mail_send_kind( 'member_ask_add', $m['email'], array(
				'year'      => $y,
				'by'        => ogc_member_short( $me ),
				'name'      => ogc_first_l( $name ),
				'committee' => isset( $coms[ $c ] ) ? $coms[ $c ] : $c,
				'url'       => ogc_url( 'app', array( 'year' => $y, 's' => 'members', 'v' => 'asked' ) ),
			), array( 'to_member' => true, 'reply_to' => strtolower( (string) $me['email'] ) ) );
		}
	}
	return rest_ensure_response( array( 'asked' => 'h' . $id, 'asks' => ogc_people_asks_mine( $y, $c ) ) );
}

/** A committee's own asks, as its people see them (never an address): name, asked, and what came of it. */
function ogc_people_asks_mine( $year, $c ) {
	$out = array();
	foreach ( array_reverse( ogc_people_asks_store( $year ) ) as $a ) {
		if ( $a['c'] !== $c || strtotime( (string) $a['at'] . ' UTC' ) < time() - 30 * DAY_IN_SECONDS ) {
			continue;
		}
		$out[] = array(
			'id'     => 'h' . (int) $a['id'],
			'name'   => ogc_first_l( (string) $a['name'] ),
			'at'     => substr( (string) $a['at'], 0, 10 ),
			'status' => 'open' === $a['status'] && ! ogc_people_ask_live( $a ) ? 'lapsed' : (string) $a['status'],
			'done'   => ! empty( $a['done_at'] ) ? substr( (string) $a['done_at'], 0, 10 ) : '',
		);
	}
	return $out;
}

/** GET asks: the COA gets every open ask (Asked); someone on a committee, their committee's (?c=). */
function ogc_people_rest_asks( WP_REST_Request $req ) {
	$y = (int) $req['year'];
	$c = ogc_committee_key( (string) $req->get_param( 'c' ) );
	if ( ogc_member_can( 'invite', $y ) && ! ogc_is_webmaster() ) {
		return rest_ensure_response( array( 'asks' => '' !== $c ? ogc_people_asks_mine( $y, $c ) : ogc_people_asks_open( $y ) ) );
	}
	$me = ogc_member_me( $y );
	if ( ! $me || '' === $c || ! in_array( $c, ogc_member_committee_keys( $me ), true ) ) {
		return rest_ensure_response( array( 'asks' => array() ) );
	}
	return rest_ensure_response( array( 'asks' => ogc_people_asks_mine( $y, $c ) ) );
}

function ogc_people_rest_ask_dismiss( WP_REST_Request $req ) {
	$y  = (int) $req['year'];
	$id = (string) $req['id'];
	if ( 'a' === $id[0] ) {
		$s    = ogc_state_get( $y, 'member_ask_seen' );
		$seen = $s && is_array( $s['value'] ) ? (array) $s['value'] : array();
		$seen[ $id ] = array( 'status' => 'dismissed', 'at' => ogc_now(), 'by' => get_current_user_id() );
		ogc_state_put( $y, 'member_ask_seen', $seen );
		ogc_log( 'member_ask_dismissed', $y, 'ask:' . $id, array() );
	} elseif ( ! ogc_people_ask_close( $y, $id, 'dismissed' ) ) {
		return new WP_Error( 'ogc_not_found', 'Not found.', array( 'status' => 404 ) );
	}
	return rest_ensure_response( array( 'dismissed' => $id, 'asks' => ogc_people_asks_open( $y ) ) );
}

/* ================================================================== the person */

/** History for one person, in words without their name ("Invited · Nathan K."), newest first. */
function ogc_people_history( $year, $id ) {
	global $wpdb;
	$rows  = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . ogc_table( 'log' ) . " WHERE year = %d AND target = %s AND action LIKE 'member%%' ORDER BY id DESC LIMIT 60", (int) $year, 'member:' . (int) $id ), ARRAY_A );
	$words = array(
		'member_invite'    => 'Invited',
		'member_resend'    => 'New link sent',
		'member_remove'    => 'Removed',
		'member_restore'   => 'Restored',
		'member_signin'    => 'Signed in',
		'member_label'     => 'Committees changed',
		'member_name'      => 'Name changed',
		'member_email'     => 'Address changed',
		'member_renew'     => 'Renewed',
		'member_ending'    => 'Told access ends soon',
		'member_ask'       => 'Asked for access',
		'member_money_on'  => 'Handles money',
		'member_money_off' => 'Handles money taken off',
	);
	$out = array();
	foreach ( (array) $rows as $r ) {
		if ( ! isset( $words[ $r['action'] ] ) ) {
			continue;
		}
		$d    = (array) ogc_unjson( $r['detail'], array() );
		$what = 'member_role' === $r['action'] ? ( isset( $d['role'] ) && 'coa' === $d['role'] ? 'Made COA' : 'Made a helper' ) : $words[ $r['action'] ];
		$self = in_array( $r['action'], array( 'member_signin', 'member_ending', 'member_ask' ), true );
		$out[] = array( 'at' => substr( (string) $r['at'], 0, 10 ), 'what' => $what, 'by' => $self ? '' : ogc_app_user_name( (int) $r['user'], (int) $year ) );
	}
	return $out;
}

/**
 * GET app/{y}/person?id=: one member, as the viewer may see them. The phone is the COA's own record of
 * them, sent to the COA only (never a webmaster, never while seeing as: then it says Withheld). A webmaster
 * not seeing as opens COA rows only (Access).
 */
function ogc_people_rest_person( WP_REST_Request $req ) {
	global $wpdb;
	$y = (int) $req['year'];
	$v = ogc_app_req_viewer( $req );
	$m = ogc_member_get( (int) $req->get_param( 'id' ) );
	if ( ! $m || (int) $m['year'] !== $y || ( ! empty( $v['webmaster'] ) && empty( $v['as'] ) && 'coa' !== $m['role'] ) ) {
		return new WP_Error( 'ogc_not_found', 'Not found.', array( 'status' => 404 ) );
	}
	if ( $v['as'] ) {
		ogc_app_log_see_as( $v );
	}
	$out = ogc_member_out( $m, true );
	if ( $v['as'] ) {
		$out['can'] = array_fill_keys( array_keys( (array) $out['can'] ), false );
	}
	$phones = $v['coa'] && ! $v['as'] && function_exists( 'ogc_app_phones' ) ? ogc_app_phones( $y ) : array();
	$coms   = ogc_members_committee_list( $y );
	$keys   = 'coa' === $m['role'] ? array() : ogc_member_committee_keys( $m );
	$linked = array( 'committees' => array(), 'tasks' => 0, 'runs' => array(), 'webmaster' => ! empty( $out['webmaster'] ) );
	foreach ( $keys as $k ) {
		$linked['committees'][] = array( 'key' => $k, 'name' => isset( $coms[ $k ] ) ? $coms[ $k ] : $k, 'head' => ! empty( $m['head'] ) );
		$c = ogc_app_committee( $y, $k );
		foreach ( $c ? (array) $c['screens'] : array() as $sid ) {
			$linked['runs'][] = array( 'id' => $sid, 'title' => function_exists( 'ogc_app_screen_title' ) ? ogc_app_screen_title( $y, $sid ) : $sid, 'through' => isset( $coms[ $k ] ) ? $coms[ $k ] : $k );
		}
	}
	if ( function_exists( 'ogc_app_tables_ready' ) && ogc_app_tables_ready() ) {
		$linked['tasks'] = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM ' . ogc_table( 'tasks' ) . ' WHERE year = %d AND owner = %d AND done_at IS NULL AND removed_at IS NULL', $y, (int) $m['id'] ) );
	}
	return rest_ensure_response( array(
		'member'   => $out,
		'phone'    => isset( $phones[ (int) $m['id'] ] ) ? (string) $phones[ (int) $m['id'] ] : '',
		'withheld' => (bool) $v['as'],
		'linked'   => $linked,
		'history'  => ogc_people_history( $y, (int) $m['id'] ),
		'ending'   => ogc_member_ending_soon( $m, ogc_app_today( $y ) ),
		'years'    => array( 'coa' => ogc_member_default_years( 'coa' ), 'helper' => ogc_member_default_years( 'helper' ) ),
	) );
}

/* ================================================================== Members' Export (3.6) */

function ogc_people_rest_export( WP_REST_Request $req ) {
	$y    = (int) $req['year'];
	$as   = (string) $req->get_param( 'as' );
	$wm   = ogc_is_webmaster();
	$v    = function_exists( 'ogc_app_viewer' ) ? ogc_app_viewer( $y, $as ) : array( 'as' => '' );
	$seen = '' !== $as && 'coa' === $v['as'];
	if ( '' !== $as && ! $seen ) {
		return ogc_rest_denied();
	}
	// The COA (their whole list), a webmaster seeing as the COA (Email and Phone withheld, P19), or a
	// webmaster's own Access (the COA rows only).
	if ( ! $seen && ! ogc_member_can( 'invite', $y ) ) {
		return ogc_rest_denied();
	}
	if ( $seen ) {
		ogc_app_log_see_as( $v );
	}
	$ids    = array_filter( array_map( 'intval', explode( ',', (string) $req->get_param( 'ids' ) ) ) );
	$only   = ogc_committee_key( (string) $req->get_param( 'c' ) );
	$coms   = ogc_members_committee_list( $y );
	$phones = ! $seen && ! $wm && function_exists( 'ogc_app_phones' ) ? ogc_app_phones( $y ) : array();
	$coa    = $wm && ! $seen;
	$rows   = array();
	foreach ( ogc_members_list( $y ) as $m ) {
		if ( ( $ids && ! in_array( (int) $m['id'], $ids, true ) ) || ( $coa && 'coa' !== $m['role'] ) ) {
			continue;
		}
		$keys = 'coa' === $m['role'] ? array( 'coa' ) : ogc_member_committee_keys( $m );
		$o    = ogc_member_out( $m, true );
		$st   = $o['expired'] ? 'Ended' : ( ogc_member_ending_soon( $m ) ? 'Ending soon' : ( 'invited' === $o['state'] ? ( $o['invite_expired'] ? 'Link expired' : 'Invited' ) : 'Signed in' ) );
		foreach ( $keys as $k ) {
			if ( '' !== $only && $k !== $only ) {
				continue;
			}
			$row = array(
				'coa' === $k ? 'COA' : ( isset( $coms[ $k ] ) ? $coms[ $k ] : $k ),
				(string) $m['name'],
				'coa' !== $k && ! empty( $m['head'] ) ? 'Yes' : '',
				(string) $m['helps'],
				$seen ? 'Withheld' : (string) $m['email'],
			);
			if ( ! $coa ) {
				$row[] = $seen ? 'Withheld' : ( isset( $phones[ (int) $m['id'] ] ) ? (string) $phones[ (int) $m['id'] ] : '' );
				$row[] = ! empty( $o['money'] ) ? 'Yes' : '';
			}
			$row[]  = $st;
			$row[]  = $m['invited_at'] ? substr( (string) $m['invited_at'], 0, 10 ) : '';
			$row[]  = (string) $o['by'];
			$row[]  = $m['signed_in_at'] ? substr( (string) $m['signed_in_at'], 0, 10 ) : '';
			$x      = ogc_member_expiry( $m );
			$row[]  = $x ? substr( (string) $x, 0, 10 ) : '';
			$rows[] = $row;
		}
	}
	$cols = $coa
		? array( array( 'Committee', 'COA', 10 ), array( 'Name', 'As they want it shown', 22 ), array( 'Head', 'Not used for the COA', 6 ), array( 'Helps with', 'The COA’s short label', 16 ), array( 'Email', 'Their sign-in address', 30 ) )
		: array( array( 'Committee', 'One row per person per committee; COA rows say COA', 18 ), array( 'Name', 'As they want it shown', 22 ), array( 'Head', 'Yes, or blank', 6 ), array( 'Helps with', 'The COA’s short label', 16 ), array( 'Email', $seen ? 'Withheld while seeing as' : 'Their sign-in address', 30 ), array( 'Phone', $seen ? 'Withheld while seeing as' : 'The COA’s phone for them', 14 ), array( 'Handles money', 'Yes, or blank', 10 ) );
	$cols = array_merge( $cols, array( array( 'Status', 'Invited · Link expired · Signed in · Ending soon · Ended', 14 ), array( 'Invited', 'Date', 12 ), array( 'Invited by', 'First L.', 14 ), array( 'Signed in', 'Date', 12 ), array( 'Access until', 'Date', 12 ) ) );
	$spec = array( 'title' => $coa ? 'COA' : 'Members', 'cols' => $cols );
	$book = ogc_lst_xlsx( array( ogc_lst_list_sheet( $spec, $rows ), ogc_lst_columns_sheet( $spec, array( 'As of' => wp_date( 'M j, Y' ), 'Rows' => (string) count( $rows ), 'Keep' => 'Has names · Delete after the Conference' ) ) ) );
	ogc_log( 'list_download', $y, 'list:members', array( 'n' => count( $rows ), 'as' => $seen ? 'coa' : '' ) );
	return ogc_lst_xlsx_response( $book, $y . ' ' . ( $coa ? 'COA' : 'Members' ) . ' (' . wp_date( 'Y-m-d' ) . ').xlsx' );
}

/* ================================================================== the webmasters' Years (8) */

function ogc_people_rest_years( WP_REST_Request $req ) {
	$out = array();
	foreach ( ogc_years_list() as $y ) {
		$started = ogc_year_started( $y );
		$people  = count( array_filter( ogc_members_list( $y ), 'ogc_member_active' ) );
		$out[]   = array(
			'year'    => (int) $y,
			'started' => $started,
			'coa'     => $started || $people ? ogc_year_coa_state( $y ) : null,
			'people'  => $people,
			'clears'  => $started ? ogc_year_clears( $y ) : null,
		);
	}
	return rest_ensure_response( array( 'years' => $out ) );
}

/* ================================================================== Email (9) */

/** The kinds' words, and a status's word. Locally a message is "captured" (kept in the Mail log): sent. */
function ogc_people_mail_word( $s ) {
	return in_array( $s, array( 'sent', 'captured' ), true ) ? 'sent' : ( in_array( $s, array( 'failed', 'refused', 'queued' ), true ) ? $s : '' );
}

/** Failed and refused in the last $days (one count for the webmasters' Home and Email's Problems). */
function ogc_mail_problems( $days = 14 ) {
	global $wpdb;
	$wpdb->suppress_errors( true );
	$bad = $wpdb->get_results( $wpdb->prepare( 'SELECT status, COUNT(*) AS n FROM ' . ogc_table( 'mail' ) . " WHERE at > %s AND status IN ('failed','refused') GROUP BY status", gmdate( 'Y-m-d H:i:s', time() - (int) $days * DAY_IN_SECONDS ) ), ARRAY_A );
	$wpdb->suppress_errors( false );
	$out = array( 'failed' => 0, 'refused' => 0 );
	foreach ( (array) $bad as $b ) {
		$out[ $b['status'] ] = (int) $b['n'];
	}
	return $out;
}

/** GET app/{y}/email?days=14: by day and kind, counts only (never an address, a subject or a body). */
function ogc_people_rest_email( WP_REST_Request $req ) {
	global $wpdb;
	$days  = max( 1, min( 60, (int) ( $req->get_param( 'days' ) ? $req->get_param( 'days' ) : 14 ) ) );
	$kinds = ogc_mail_kinds();
	$rows  = $wpdb->get_results( $wpdb->prepare( 'SELECT at, kind, status FROM ' . ogc_table( 'mail' ) . ' WHERE at > %s ORDER BY id DESC LIMIT 20000', gmdate( 'Y-m-d H:i:s', time() - $days * DAY_IN_SECONDS ) ), ARRAY_A );
	$by    = array();
	$queue = array( 'n' => 0, 'oldest' => '' );
	foreach ( (array) $rows as $r ) {
		$w = ogc_people_mail_word( (string) $r['status'] );
		if ( '' === $w ) {
			continue;
		}
		$day = wp_date( 'Y-m-d', strtotime( $r['at'] . ' UTC' ) );
		$k   = $day . ':' . $r['kind'];
		if ( ! isset( $by[ $k ] ) ) {
			$by[ $k ] = array( 'id' => $k, 'day' => $day, 'kind' => (string) $r['kind'], 'label' => isset( $kinds[ $r['kind'] ] ) ? $kinds[ $r['kind'] ] : ( 'wp_mail' === $r['kind'] ? 'Other (WordPress)' : (string) $r['kind'] ), 'sent' => 0, 'failed' => 0, 'refused' => 0, 'queued' => 0 );
		}
		$by[ $k ][ $w ]++;
		if ( 'queued' === $w ) {
			$queue['n']++;
			$queue['oldest'] = (string) $r['at'];
		}
	}
	$order = array_keys( $kinds );
	$list  = array_values( $by );
	usort( $list, function ( $a, $b ) use ( $order ) {
		$ia = array_search( $a['kind'], $order, true );
		$ib = array_search( $b['kind'], $order, true );
		return strcmp( $b['day'], $a['day'] ) ?: ( ( false === $ia ? 99 : $ia ) - ( false === $ib ? 99 : $ib ) );
	} );
	$tot = array( 'sent' => 0, 'failed' => 0, 'refused' => 0, 'queued' => 0 );
	foreach ( $list as $r ) {
		foreach ( $tot as $k => $n ) {
			$tot[ $k ] += $r[ $k ];
		}
	}
	return rest_ensure_response( array(
		'days'     => $days,
		'rows'     => $list,
		'totals'   => $tot,
		'problems' => ogc_mail_problems( $days ),
		'queue'    => array( 'n' => $queue['n'], 'mins' => $queue['oldest'] ? (int) round( ( time() - strtotime( $queue['oldest'] . ' UTC' ) ) / 60 ) : 0 ),
		'log'      => function_exists( 'ogc_mail_log_on' ) && ogc_mail_log_on() ? wp_make_link_relative( ogc_url( 'mail' ) ) : '',
		'kinds'    => array_map( function ( $k, $l ) {
			return array( 'kind' => $k, 'label' => $l );
		}, array_keys( $kinds ), array_values( $kinds ) ),
	) );
}

/** GET app/{y}/email/day?d=&kind=: each message that day of that kind that didn't go, the domain only. */
function ogc_people_rest_email_day( WP_REST_Request $req ) {
	global $wpdb;
	$d    = (string) $req->get_param( 'd' );
	$kind = sanitize_key( (string) $req->get_param( 'kind' ) );
	if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $d ) ) {
		return new WP_Error( 'ogc_bad', 'A day', array( 'status' => 400 ) );
	}
	$from = get_gmt_from_date( $d . ' 00:00:00' );
	$to   = get_gmt_from_date( $d . ' 23:59:59' );
	$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT at, to_email, status, year, meta FROM ' . ogc_table( 'mail' ) . ' WHERE at BETWEEN %s AND %s AND kind = %s ORDER BY id DESC LIMIT 500', $from, $to, $kind ), ARRAY_A );
	$out  = array();
	$n    = array( 'sent' => 0, 'failed' => 0, 'refused' => 0, 'queued' => 0 );
	foreach ( (array) $rows as $r ) {
		$w = ogc_people_mail_word( (string) $r['status'] );
		if ( '' === $w ) {
			continue;
		}
		$n[ $w ]++;
		if ( 'sent' === $w ) {
			continue;
		}
		$meta  = (array) ogc_unjson( (string) $r['meta'], array() );
		$why   = 'refused' === $w ? 'Refused · Limit · 20 a day to an address nobody has proved' : ( 'queued' === $w ? 'Queued' : ( in_array( $kind, array( 'signin', 'confirm_email' ), true ) ? 'Failed · Sign-in codes are tried once' : 'Failed · After 5 tries' ) );
		$at    = strpos( (string) $r['to_email'], '@' );
		$out[] = array( 'at' => wp_date( 'g:i A', strtotime( $r['at'] . ' UTC' ) ), 'domain' => false === $at ? '' : substr( (string) $r['to_email'], $at ), 'status' => $w, 'why' => $why, 'year' => (int) $r['year'] );
	}
	$kinds = ogc_mail_kinds();
	return rest_ensure_response( array( 'day' => $d, 'kind' => $kind, 'label' => isset( $kinds[ $kind ] ) ? $kinds[ $kind ] : $kind, 'counts' => $n, 'rows' => $out ) );
}

/** GET app/{y}/email/preview?kind=: the kind as the set draws it, from made-up people only. */
function ogc_people_rest_email_preview( WP_REST_Request $req ) {
	$kind    = sanitize_key( (string) $req->get_param( 'kind' ) );
	$samples = ogc_mail_samples();
	if ( ! isset( $samples[ $kind ] ) ) {
		return new WP_Error( 'ogc_not_found', 'No preview', array( 'status' => 404 ) );
	}
	$t = ogc_mail_template( $kind, array_merge( array( 'year' => (int) $req['year'], 'to' => 'someone@example.com' ), (array) $samples[ $kind ] ) );
	if ( ! $t ) {
		return new WP_Error( 'ogc_not_found', 'No preview', array( 'status' => 404 ) );
	}
	return rest_ensure_response( array( 'kind' => $kind, 'subject' => $t['subject'], 'html' => $t['html'] ) );
}
