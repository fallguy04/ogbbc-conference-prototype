<?php
/**
 * Registration's emails, and checking an email inside the form (register area).
 *
 * A person is their email once they've shown it's theirs: at Contact the form asks the site's one
 * sign-in (module-auth: auth/send with for=register) for six digits (no link: a link opens a new tab,
 * and the draft is kept in this tab only); typing them (auth/code) signs the person in on this device,
 * and the form carries on where it was. Nothing says whether an email already has a registration until
 * it's confirmed.
 *
 * Emails are plain text, sent once by the site with wp_mail (locally, nothing is sent: core-dev.php
 * notes each one, and here the whole message is kept in the option ogc_reg_dev_mail for testing).
 * Sample households are never emailed.
 */

defined( 'ABSPATH' ) || exit;

/** Send one plain email. $lines are joined with line breaks. */
function ogc_reg_mail( $to, $subject, $lines, $kind = 'registration_received', $year = 0 ) {
	$to = strtolower( trim( (string) $to ) );
	if ( ! is_email( $to ) ) {
		return false;
	}
	$body = implode( "\n", (array) $lines ) . "\n";
	// The site's one way to send (module-mail.php: the house layout, the Mail log, the limits).
	if ( function_exists( 'ogc_send_mail' ) ) {
		return ogc_send_mail( $to, $subject, $body, array( 'kind' => $kind, 'year' => $year ) );
	}
	if ( ogc_reg_local() ) {
		$log   = (array) get_option( 'ogc_reg_dev_mail', array() );
		$log[] = array( 'at' => ogc_now(), 'to' => $to, 'subject' => $subject, 'body' => $body );
		update_option( 'ogc_reg_dev_mail', array_slice( $log, -40 ), false );
	}
	return wp_mail( $to, $subject, $body, array( 'Content-Type: text/plain; charset=UTF-8' ) );
}

/** Who to ask, by role (registration.csv questions_email), never a person's own address:
 * "lodging@example.org (Registration committee)". Nothing when the COA hasn't given an address: a name
 * with no way to reach it helps nobody. */
function ogc_reg_questions_words( $year ) {
	$q = ogc_reg_c( ogc_reg_cfg( $year ), 'questions_email' );
	if ( ! is_email( $q ) ) {
		return '';
	}
	$who = trim( ogc_reg_c( ogc_reg_settings( $year ), 'owner_registration' ) );
	return $q . ( $who ? ' (' . $who . ')' : '' );
}
function ogc_reg_questions_line( $year ) {
	$w = ogc_reg_questions_words( $year );
	return $w ? 'Questions: ' . $w : '';
}

/** The address of Your sign-ups for a year. */
function ogc_reg_mine_url( $year ) {
	return ogc_url( 'register', array( 'year' => (int) $year, 'view' => 'mine' ) );
}

/** The check address's lines, less a first line that only repeats the payee. */
function ogc_reg_check_address( $cfg ) {
	$lines = array_values( array_filter( array_map( 'trim', explode( '|', ogc_reg_c( $cfg, 'check_address' ) ) ) ) );
	if ( $lines && 0 === strcasecmp( $lines[0], trim( ogc_reg_c( $cfg, 'check_payee' ) ) ) ) {
		array_shift( $lines );
	}
	return $lines;
}

/** Everyone a registration's emails go to: its owner, and a helper who made it. */
function ogc_reg_recipients( $rec ) {
	$to = array();
	if ( is_email( $rec['email'] ) ) {
		$to[] = $rec['email'];
	}
	foreach ( (array) ( isset( $rec['data']['managers'] ) ? $rec['data']['managers'] : array() ) as $m ) {
		if ( is_email( $m ) ) {
			$to[] = $m;
		}
	}
	return array_values( array_unique( $to ) );
}

/* ------------------------------------------------------------------ laying an email out */

/**
 * One registration email in the house layout (ogc_mail_compose: the site's name, one heading, a button,
 * Questions by role, the footer), with blocks of its own the layout doesn't have (a money table, the
 * check's tinted box). $a: compose's arguments; $blocks: each array( html, text ), placed where
 * $a['lines'] holds '[[ogc:N]]'. Without the house layout (signin area missing): plain text.
 */
function ogc_reg_mail_send( $to, $a, $blocks, $kind, $year, $reply = '' ) {
	$a = array_merge( array( 'year' => $year, 'to' => $to ), $a );
	if ( ! function_exists( 'ogc_mail_compose' ) ) {
		$t = array( $a['heading'], '' );
		foreach ( (array) $a['lines'] as $l ) {
			$t[] = preg_match( '/^\[\[ogc:(\d+)\]\]$/', $l, $m ) ? $blocks[ (int) $m[1] ]['text'] : $l;
		}
		if ( ! empty( $a['button'] ) ) {
			$t[] = $a['button'][0] . ': ' . $a['button'][1];
		}
		return ogc_reg_mail( $to, $a['subject'], $t, $kind, $year );
	}
	$m = ogc_reg_mail_render( $a, $blocks );
	return ogc_send_mail( $to, $a['subject'], $m['html'], array( 'kind' => $kind, 'year' => $year, 'text' => $m['text'], 'reply_to' => $reply ) );
}

/** One registration email laid out (the house layout, its own blocks in place): subject, html, text.
 * The set's preview (module-mail-templates.php, registration_received) draws through it too. */
function ogc_reg_mail_render( $a, $blocks ) {
	$m    = ogc_mail_compose( $a );
	$html = $m['html'];
	$text = $m['text'];
	foreach ( $blocks as $i => $b ) {
		$html = preg_replace( '#<p[^>]*>\[\[ogc:' . $i . '\]\]</p>#', str_replace( array( '\\', '$' ), array( '\\\\', '\$' ), $b['html'] ), $html );
		$text = str_replace( '[[ogc:' . $i . ']]', $b['text'], $text );
	}
	return array( 'subject' => $a['subject'], 'html' => $html, 'text' => preg_replace( "/\n{3,}/", "\n\n", $text ) );
}

/** Words that must stay on one line keep together: a number and its unit ("5 nights"), "× $65",
 * a phone (555-555-0142) and a date ("Sat May 29"). Non-breaking spaces and hyphens (U+00A0, U+2011). */
function ogc_reg_nb( $t ) {
	$t = preg_replace( '/(\d) (?=[A-Za-z$])/u', "$1\u{00A0}", (string) $t );
	$t = preg_replace( '/ × /u', "\u{00A0}×\u{00A0}", $t );
	$t = preg_replace( '/ · /u', "\u{00A0}· ", $t );
	$t = str_replace( 'check-in', "check\u{2011}in", $t );
	$t = preg_replace( '/\b(\d{3})-(\d{3})-(\d{4})\b/u', "$1\u{2011}$2\u{2011}$3", $t );
	return preg_replace( '/\b(Mon|Tue|Wed|Thu|Fri|Sat|Sun) (Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec) /u', "$1\u{00A0}$2\u{00A0}", $t );
}

/** A money table: label left, amount right, the sum rows bold. $rows: array( label, cents, sum? ). */
function ogc_reg_mail_money( $rows ) {
	$sans = 'Arial,Helvetica,sans-serif';
	$h    = '';
	$t    = array();
	foreach ( $rows as $r ) {
		$sum = ! empty( $r[2] );
		$amt = is_int( $r[1] ) ? ogc_reg_money( $r[1] ) : (string) $r[1];
		$td  = 'padding:7px 0;border-bottom:1px solid #e4dfd2;font-family:' . $sans . ';font-size:15px;line-height:20px;color:#333333;' . ( $sum ? 'font-weight:700;' : '' );
		$h  .= '<tr><td class="o-ink" valign="top" style="' . $td . '">' . esc_html( ogc_reg_nb( $r[0] ) ) . '</td><td class="o-ink" valign="top" align="right" style="' . $td . 'padding-left:16px;white-space:nowrap;text-align:right;">' . esc_html( $amt ) . '</td></tr>';
		// Plain text: the amount at the right edge of a 56-character line.
		$pad = max( 2, 56 - ( function_exists( 'mb_strlen' ) ? mb_strlen( $r[0] ) : strlen( $r[0] ) ) - strlen( $amt ) );
		$t[] = $r[0] . str_repeat( ' ', $pad ) . $amt;
	}
	return array(
		'html' => '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="margin:0 0 18px;border-collapse:collapse;">' . $h . '</table>',
		'text' => implode( "\n", $t ) . "\n",
	);
}

/** Facts as the house layout draws them (a tan label, then the words), placed among the lines. */
function ogc_reg_mail_facts( $facts ) {
	$sans  = 'Arial,Helvetica,sans-serif';
	$serif = "'Droid Serif',Georgia,'Times New Roman',serif";
	$h     = '';
	$t     = array();
	foreach ( $facts as $f ) {
		if ( '' === (string) $f[1] ) {
			continue;
		}
		$h  .= '<tr><td class="o-kick" valign="top" style="padding:6px 16px 6px 0;font-family:' . $sans . ';font-size:12px;line-height:20px;font-weight:700;letter-spacing:1.2px;text-transform:uppercase;color:#76623F;white-space:nowrap;">' . esc_html( $f[0] ) . '</td>' .
			'<td class="o-ink" valign="top" style="padding:6px 0;font-family:' . $serif . ';font-size:16px;line-height:22px;color:#333333;">' . nl2br( esc_html( ogc_reg_nb( $f[1] ) ) ) . '</td></tr>';
		$t[] = $f[0] . ': ' . str_replace( "\n", ' · ', $f[1] );
	}
	return array( 'html' => '<table role="presentation" cellpadding="0" cellspacing="0" border="0" style="margin:0 0 18px;border-collapse:collapse;">' . $h . '</table>', 'text' => implode( "\n", $t ) . "\n" );
}

/** A tinted box of short lines (the check's details); $bold: its first line is what the box is about. */
function ogc_reg_mail_box( $lines, $bold = false ) {
	$sans = 'Arial,Helvetica,sans-serif';
	$html = array_map( 'esc_html', array_map( 'ogc_reg_nb', $lines ) );
	// A registration's number is never split at its hyphens ("Write R-2027-0014 on the check").
	$html = preg_replace( '/\bR-\d{4}-\d{3,}\b/', '<span style="white-space:nowrap">$0</span>', $html );
	if ( $bold && $html ) {
		$html[0] = '<b>' . $html[0] . '</b>';
	}
	return array(
		'html' => '<div class="o-code" style="margin:18px 0 18px;padding:14px 16px;background:#F3F2EB;border-radius:6px;font-family:' . $sans . ';font-size:15px;line-height:1.55;color:#333333;">' . implode( '<br>', $html ) . '</div>',
		'text' => ( $bold ? "\n" : '' ) . implode( "\n", $lines ) . "\n",
	);
}

/** "Sat May 29": the area's one date format. */
function ogc_reg_mail_date( $iso ) {
	$t = strtotime( (string) $iso . ' 12:00 UTC' );
	return $t ? gmdate( 'D M j', $t ) : (string) $iso;
}

/** The halls Youngfolks on their own are in, by name ("Young men’s hall", or both). */
function ogc_reg_halls_words( $d ) {
	$h = array();
	foreach ( (array) $d['people'] as $p ) {
		if ( ! empty( $p['yf'] ) ) {
			$h[ 'women' === $p['yfHall'] ? 'Young women’s hall' : 'Young men’s hall' ] = true;
		}
	}
	return $h ? implode( ' and ', array_keys( $h ) ) : 'Youngfolks hall';
}

/* ------------------------------------------------------------------ the emails */

/**
 * The confirmation (on registering, or on the card paying for a new registration), the receipt (a later
 * payment), "Changed" and "Cancelled" (canonical, Oct 14: the concept's email, in the house layout).
 * In order: the heading, then what changed (a change) or why (a cancellation); the registration's number
 * and the Conference's dates and place; Who's coming; The stay (its nights, each Youngfolk's hall,
 * where the rooms will be, check-in and check-out); the charges; what's owed and how to pay (for a
 * check: payable to the role, the address, the arrive-by date, the number to write on it); one button,
 * Your sign-ups; and who to ask (by role). Never a room number: rooms are only on the site, because an
 * email can't be taken back once it's sent.
 */
function ogc_reg_mail_receipt( $rec, $why ) {
	if ( $rec['sample'] ) {
		return;
	}
	$y   = (int) $rec['year'];
	$p   = ogc_reg_mail_receipt_parts( $rec, $why );
	$q   = ogc_reg_c( ogc_reg_cfg( $y ), 'questions_email' );
	foreach ( ogc_reg_recipients( $rec ) as $to ) {
		// Each address gets its own Your sign-ups link (the signin area's: it never signs anyone in by itself).
		$link = function_exists( 'ogc_mine_url' ) ? ogc_mine_url( $to, $y ) : ogc_reg_mine_url( $y );
		ogc_reg_mail_send( $to, array_merge( $p['args'], array( 'button' => array( 'Your sign-ups', $link ) ) ), $p['blocks'], $p['kind'], $y, is_email( $q ) ? $q : '' );
	}
	// Its confirmation has gone: a later card payment is a receipt ("Paid"), not a second "Registered".
	if ( $p['first'] && empty( $rec['data']['mailed'] ) && ! empty( $rec['id'] ) ) {
		$cur = ogc_record_get( $rec['id'] );
		if ( $cur && empty( $cur['data']['mailed'] ) ) {
			$cur['data']['mailed'] = 1;
			ogc_record_update( $cur['id'], $cur['data'], $cur['email'] );   // _v kept: an open page isn't stale
		}
	}
}

/** The receipt's words and blocks, for any address (the button is each address's own): args (for
 * ogc_mail_compose, less the button), blocks, kind, first (this is its confirmation). */
function ogc_reg_mail_receipt_parts( $rec, $why ) {
	$d     = $rec['data'];
	$y     = (int) $rec['year'];
	$cfg   = ogc_reg_cfg( $y );
	$m     = $d['money'];
	$WORDS = array( 'registered' => 'Registered', 'payment_due' => 'Payment due', 'balance_due' => 'Balance due', 'check_to_come' => 'Check to come', 'refund_due' => 'Refund requested', 'waitlist' => 'Waitlist', 'cancelled' => 'Cancelled' );
	$TITLE = array( 'new' => 'Registered', 'paid' => 'Paid', 'changed' => 'Registration changed', 'cancelled' => 'Registration cancelled' );
	// A card paid for a new registration: this is its confirmation (none went before the card was
	// answered), so it says Registered, as one paid by check or at check-in does.
	$first = 'new' === $why || ( 'paid' === $why && empty( $d['mailed'] ) );
	$title = $first ? $TITLE['new'] : $TITLE[ $why ];
	if ( 'waitlist' === $d['status'] && 'new' === $why ) {
		$title = 'Waitlist';
	}
	$st = isset( $WORDS[ $d['status'] ] ) ? $WORDS[ $d['status'] ] : $d['status'];
	if ( 'registered' === $d['status'] && $m['paid'] > 0 ) {
		$st = 'Paid ' . ogc_reg_money( $m['paid'] );
	}
	$late   = ! empty( $m['late'] ) && 'card' !== ogc_reg_c( $cfg, 'late_pay' );
	$atdesk = in_array( $d['status'], array( 'payment_due', 'balance_due' ), true ) && ( 'checkin' === ( isset( $d['pay'] ) ? $d['pay'] : '' ) || $late );
	if ( $atdesk ) {
		$st = 'Due at check-in · ' . ogc_reg_money( (int) $m['due'] );
	}
	if ( isset( $d['approval']['state'] ) && 'waiting' === $d['approval']['state'] && empty( $d['approval']['held'] ) ) {
		$st .= ' · Waiting for parent';
	}
	$lines  = array();
	$blocks = array();
	$put    = function ( $b ) use ( &$lines, &$blocks ) {
		$lines[]  = '[[ogc:' . count( $blocks ) . ']]';
		$blocks[] = $b;
	};
	$last = ! empty( $d['history'] ) ? end( $d['history'] ) : null;
	if ( 'changed' === $why && $last ) {
		$lines[] = $last['what'];
	}
	// Cancelled because a parent declined: the reason first (polish 3: a 17-year-old was told only
	// "Cancelled"). The heading already says cancelled.
	if ( 'cancelled' === $why && $last && 0 === strpos( $last['what'], 'Declined' ) ) {
		$lines[] = $last['what'];
	}
	$put( ogc_reg_mail_hero( $d['rid'], ogc_reg_mail_where( $y ) ) );
	$cancelled = 'cancelled' === $d['status'];
	if ( ! $cancelled ) {
		$put( ogc_reg_mail_section( 'Who’s coming', ogc_reg_mail_people( $d ) ) );
		$put( ogc_reg_mail_section( 'The stay', ogc_reg_mail_facts( ogc_reg_mail_stay_facts( $rec, $cfg ) ) ) );
		$put( ogc_reg_mail_section( 'Charges', ogc_reg_mail_charges( $d, $y, $cfg ) ) );
	}
	$box = ogc_reg_mail_owed( $rec, $cfg, $late, $atdesk );
	if ( $box ) {
		$put( ogc_reg_mail_box( $box, true ) );
	}
	$after = array();
	// The parent's address in full: the household typed it, and a typo must be seen to be fixed.
	if ( isset( $d['approval']['state'] ) && 'waiting' === $d['approval']['state'] && empty( $d['approval']['held'] ) ) {
		$after[] = 'Approval sent to ' . $d['approval']['to'];
	}
	if ( ogc_reg_c( $cfg, 'refunds_by' ) && ! $cancelled ) {
		$after[] = 'Refund requests until ' . gmdate( 'F j', strtotime( ogc_reg_c( $cfg, 'refunds_by' ) . ' UTC' ) );
	}
	$K = array( 'new' => 'registration_received', 'paid' => 'payment_received', 'changed' => 'registration_changed', 'cancelled' => 'registration_changed' );
	return array(
		'args'   => array(
			'subject'   => $y . ' Annual Conference · ' . $title . ' · ' . $d['rid'],
			'preheader' => $st . ' · ' . $d['rid'],
			'heading'   => $title,
			'lines'     => $lines,
			'after'     => $after,
			'questions' => ogc_reg_questions_words( $y ),
			'reason'    => 'You registered, or made this registration for someone.',
			'year'      => $y,
		),
		'blocks' => $blocks,
		'kind'   => $first ? 'registration_received' : $K[ $why ],
		'first'  => $first,
	);
}

/** The registration's number, then the Conference's dates and place, under the heading. */
function ogc_reg_mail_hero( $rid, $where ) {
	$sans  = 'Arial,Helvetica,sans-serif';
	$serif = "'Droid Serif',Georgia,'Times New Roman',serif";
	return array(
		'html' => '<p class="o-kick" style="margin:-10px 0 4px;font-family:' . $sans . ';font-size:15px;line-height:22px;font-weight:700;letter-spacing:1.2px;color:#76623F;">' . esc_html( $rid ) . '</p>' .
			( $where ? '<p class="o-muted" style="margin:0 0 6px;font-family:' . $serif . ';font-size:16px;line-height:1.5;color:#6b6659;">' . esc_html( ogc_reg_nb( $where ) ) . '</p>' : '' ),
		'text' => $rid . ( $where ? "\n" . $where : '' ) . "\n",
	);
}

/** "May 28 – June 1, 2027 · Indiana Wesleyan University, Marion, Indiana" (what's known of it). */
function ogc_reg_mail_where( $year ) {
	$row = ogc_year_get( $year );
	$s   = ogc_reg_settings( $year );
	$a   = $row && ! empty( $row['start'] ) ? strtotime( $row['start'] . ' 12:00 UTC' ) : 0;
	$b   = $row && ! empty( $row['end'] ) ? strtotime( $row['end'] . ' 12:00 UTC' ) : 0;
	$when = '';
	if ( $a && $b ) {
		$when = gmdate( 'n', $a ) === gmdate( 'n', $b ) ? gmdate( 'F j', $a ) . ' – ' . gmdate( 'j, Y', $b ) : gmdate( 'F j', $a ) . ' – ' . gmdate( 'F j, Y', $b );
	} elseif ( $a ) {
		$when = gmdate( 'F j, Y', $a );
	}
	$venue = trim( ogc_reg_c( $s, 'venue', $row && ! empty( $row['venue'] ) ? $row['venue'] : '' ) );
	$city  = trim( ogc_reg_c( $s, 'city', $row && ! empty( $row['city'] ) ? $row['city'] : '' ) );
	return implode( ' · ', array_filter( array( $when, implode( ', ', array_filter( array( $venue, $city ) ) ) ) ) );
}

/** A section: its label (tan, uppercase, a hairline above), then what's in it. */
function ogc_reg_mail_section( $title, $inner ) {
	$sans = 'Arial,Helvetica,sans-serif';
	return array(
		'html' => '<p class="o-kick" style="margin:22px 0 10px;padding-top:18px;border-top:1px solid #e4dfd2;font-family:' . $sans . ';font-size:12px;line-height:18px;font-weight:700;letter-spacing:1.2px;text-transform:uppercase;color:#76623F;">' . esc_html( $title ) . '</p>' . $inner['html'],
		'text' => "\n" . strtoupper( $title ) . "\n" . $inner['text'],
	);
}

/** Who's coming: each name, then what they are ("Youngfolk · 17", "Child · 10"). */
function ogc_reg_mail_people( $d ) {
	$sans  = 'Arial,Helvetica,sans-serif';
	$serif = "'Droid Serif',Georgia,'Times New Roman',serif";
	$h     = '';
	$t     = array();
	foreach ( (array) $d['people'] as $p ) {
		$name = trim( isset( $p['name'] ) ? (string) $p['name'] : '' );
		if ( '' === $name ) {
			continue;
		}
		$kind = isset( $p['kind'] ) ? $p['kind'] : ( ! empty( $p['yf'] ) ? 'yf' : ( in_array( isset( $p['band'] ) ? $p['band'] : '', array( 'child', 'baby' ), true ) ? 'child' : 'adult' ) );
		$age  = isset( $p['age'] ) && '' !== (string) $p['age'] ? (string) $p['age'] : '';
		$what = 'yf' === $kind ? 'Youngfolk' : ( 'child' === $kind ? 'Child' : 'Adult' );
		$what = $age && 'adult' !== $kind ? $what . ' · ' . $age : $what;
		$h   .= '<p class="o-ink" style="margin:0 0 6px;font-family:' . $serif . ';font-size:16px;line-height:22px;color:#333333;">' . esc_html( $name ) . ' <span class="o-muted" style="font-family:' . $sans . ';font-size:13px;color:#6b6659;white-space:nowrap;">' . esc_html( ogc_reg_nb( $what ) ) . '</span></p>';
		$t[]  = $name . ' · ' . $what;
	}
	return array( 'html' => '<div style="margin:0 0 6px;">' . $h . '</div>', 'text' => implode( "\n", $t ) . "\n" );
}

/** Nights in short words: a run "Fri–Tue", else "Fri, Sat, Sun, Tue" (early nights "Early Thu"). */
function ogc_reg_mail_nights( $ns, $cfg ) {
	$ns    = array_values( (array) $ns );
	$order = ogc_reg_nights( $cfg );
	$short = function ( $n ) {
		return ogc_reg_is_early( $n ) ? 'Early ' . substr( $n, 6, 3 ) : substr( (string) $n, 0, 3 );
	};
	if ( ! $ns ) {
		return '';
	}
	$idx = array_map( function ( $n ) use ( $order ) { return array_search( $n, $order, true ); }, $ns );
	$run = count( $ns ) > 2 && ! in_array( false, $idx, true ) && max( $idx ) - min( $idx ) === count( $ns ) - 1;
	return $run ? $short( $ns[0] ) . '–' . $short( $ns[ count( $ns ) - 1 ] ) : implode( ', ', array_map( $short, $ns ) );
}

/** The stay as facts: what and keys, the nights (anyone here other nights by name), each Youngfolk's
 * hall, where the rooms will be, check-in and check-out, linens. */
function ogc_reg_mail_stay_facts( $rec, $cfg ) {
	$d    = $rec['data'];
	$s    = $d['stay'];
	$days = ogc_reg_days( $rec['year'] );
	$keys = array_map( 'ogc_reg_first', array_values( array_filter( (array) ( isset( $s['keys'] ) ? $s['keys'] : array() ) ) ) );
	$and  = function ( $a ) { return count( $a ) > 1 ? implode( ', ', array_slice( $a, 0, -1 ) ) . ' and ' . end( $a ) : implode( '', $a ); };
	$TY   = array( 'dorm' => ogc_reg_plural( (int) $s['rooms'], 'dorm room' ), 'camper' => 'Camper lot' . ( ! empty( $s['campers'] ) ? ' · ' . ogc_reg_plural( (int) $s['campers'], 'camper' ) : '' ), 'elsewhere' => 'Off campus', 'yf' => ogc_reg_halls_words( $d ) );
	$f    = array( array( 'Stay', $TY[ $s['type'] ] . ( 'dorm' === $s['type'] && $keys ? ' · Keys with ' . $and( $keys ) : '' ) ) );
	$ns   = array_values( (array) $s['nights'] );
	if ( 'elsewhere' === $s['type'] ) {
		$here = array();
		foreach ( (array) $s['days'] as $x ) {
			$here[] = gmdate( 'D', strtotime( $x . ' 12:00 UTC' ) );
		}
		$f[] = array( 'Days', implode( ', ', $here ) );
	} elseif ( $ns ) {
		$odd = array();
		foreach ( (array) $d['people'] as $p ) {
			$own = ogc_reg_nights_for( $p, $d, $cfg );
			if ( ! empty( $p['name'] ) && $own && $own !== $ns ) {
				$odd[] = ogc_reg_first( $p['name'] ) . ': ' . ogc_reg_mail_nights( $own, $cfg );
			}
		}
		$f[] = array( 'Nights', ogc_reg_mail_nights( $ns, $cfg ) . ' · ' . ogc_reg_plural( count( $ns ), 'night' ) . ( $odd ? "\n" . implode( "\n", $odd ) : '' ) );
	}
	// A family's Youngfolks in their halls, each by name (Youngfolks alone: the hall is the stay).
	if ( 'yf' !== $s['type'] ) {
		foreach ( (array) $d['people'] as $p ) {
			if ( ogc_reg_in_hall( $p, $d ) && ! empty( $p['name'] ) ) {
				$f[] = array( ogc_reg_first( $p['name'] ), 'women' === $p['yfHall'] ? 'Young women’s hall' : 'Young men’s hall' );
			}
		}
	}
	if ( 'dorm' === $s['type'] ) {
		$f[] = array( 'Rooms', 'On Your sign-ups once posted' );
	}
	if ( $ns && 'elsewhere' !== $s['type'] ) {
		$main = array_values( array_filter( $ns, function ( $n ) { return ! ogc_reg_is_early( $n ); } ) );
		$in   = ogc_reg_night_date( $days, $ns[0] );
		$out  = $main ? ogc_reg_add_days( ogc_reg_night_date( $days, $main[ count( $main ) - 1 ] ), 1 ) : '';
		$f[]  = array( 'Check-in', $in ? ogc_reg_mail_date( $in ) : '' );
		$f[]  = array( 'Check-out', $out ? ogc_reg_mail_date( $out ) : '' );
	}
	$f[] = array( 'Linens', ogc_reg_linen_words( $d ) );
	return $f;
}

/** The charges: each line (what, then its arithmetic small), meals when the COA provides them, the total. */
function ogc_reg_mail_charges( $d, $year, $cfg ) {
	$sans = 'Arial,Helvetica,sans-serif';
	$h    = '';
	$t    = array();
	$row  = function ( $a, $small, $amt, $sum = false ) use ( $sans, &$h, &$t ) {
		$td = 'padding:8px 0;border-bottom:1px solid #e4dfd2;font-family:' . $sans . ';font-size:15px;line-height:20px;color:#333333;' . ( $sum ? 'font-weight:700;border-bottom:0;border-top:2px solid #333333;' : '' );
		$h .= '<tr><td class="o-ink" valign="top" style="' . $td . '">' . esc_html( ogc_reg_nb( $a ) ) . ( '' !== $small ? '<br><span class="o-muted" style="font-size:13px;line-height:18px;color:#6b6659;">' . esc_html( ogc_reg_nb( $small ) ) . '</span>' : '' ) . '</td>' .
			'<td class="o-ink" valign="top" align="right" style="' . $td . 'padding-left:16px;white-space:nowrap;text-align:right;">' . esc_html( $amt ) . '</td></tr>';
		$l   = $a . ( '' !== $small ? ' · ' . $small : '' );
		$pad = max( 2, 56 - ( function_exists( 'mb_strlen' ) ? mb_strlen( $l ) : strlen( $l ) ) - strlen( $amt ) );
		$t[] = $l . str_repeat( ' ', $pad ) . $amt;
	};
	foreach ( (array) $d['price']['lines'] as $l ) {
		$label = (string) $l['label'];
		$i     = strrpos( $label, ' · ' );
		$row( false === $i ? $label : substr( $label, 0, $i ), false === $i ? '' : substr( $label, $i + strlen( ' · ' ) ), ogc_reg_money( (int) $l['cents'] ) );
	}
	if ( 'no' !== ogc_reg_c( $cfg, 'meals_free', 'yes' ) ) {
		$n = 0;
		foreach ( (array) ( isset( $d['meals']['custom'] ) ? $d['meals']['custom'] : array() ) as $c ) {
			$n += array_sum( array_map( 'intval', (array) $c ) );
		}
		if ( $n ) {
			$row( 'Meals', ogc_reg_plural( $n, 'meal' ), 'Provided' );
		}
	}
	$row( 'Total', '', ogc_reg_money( (int) $d['price']['total_cents'] ), true );
	return array(
		'html' => '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="margin:0 0 18px;border-collapse:collapse;">' . $h . '</table>',
		'text' => implode( "\n", $t ) . "\n",
	);
}

/** What's owed and how to pay, its first line bold: Paid · Card, a check's details, at check-in, due. */
function ogc_reg_mail_owed( $rec, $cfg, $late, $atdesk ) {
	$d   = $rec['data'];
	$m   = $d['money'];
	$rid = $d['rid'];
	$how = array();
	foreach ( ogc_pay_rows( $rec['id'] ) as $p ) {
		if ( 'paid' === $p['status'] && 'refund' !== $p['kind'] ) {
			$how[ 'card' === $p['method'] ? 'Card' : ( 'check' === $p['method'] ? 'Check' : 'At the desk' ) ] = true;
		}
	}
	$paid = 'Paid ' . ogc_reg_money( (int) $m['paid'] ) . ( 1 === count( $how ) ? ' · ' . key( $how ) : '' );
	if ( 'cancelled' === $d['status'] ) {
		return $m['refund'] ? array( 'Refund due · ' . ogc_reg_money( (int) $m['refund'] ) ) : ( $m['refunded'] ? array( 'Refunded · ' . ogc_reg_money( (int) $m['refunded'] ) ) : array() );
	}
	if ( 'waitlist' === $d['status'] ) {
		return array( 'Waitlist · Nothing charged' );
	}
	if ( $m['refund'] ) {
		return array_values( array_filter( array( 'Refund due · ' . ogc_reg_money( (int) $m['refund'] ), $m['paid'] ? $paid : '' ) ) );
	}
	if ( $m['check'] ) {
		$by    = ogc_reg_c( $cfg, 'check_by' );
		$lines = array( 'Check to come · ' . ogc_reg_money( (int) $m['check'] ) );
		if ( ogc_reg_c( $cfg, 'check_payee' ) ) {
			$lines[] = 'Payable to ' . ogc_reg_c( $cfg, 'check_payee' );
		}
		$lines   = array_merge( $lines, ogc_reg_check_address( $cfg ) );
		$lines[] = ( $by ? 'To arrive by ' . gmdate( 'F j', strtotime( $by . ' UTC' ) ) . ' · ' : '' ) . 'Write ' . $rid . ' on the check';
		if ( $m['paid'] ) {
			$lines[] = $paid;
		}
		return $lines;
	}
	if ( $atdesk && $m['due'] ) {
		return array_values( array_filter( array( 'Due at check-in · ' . ogc_reg_money( (int) $m['due'] ), ogc_reg_c( $cfg, 'checkin_place' ), $late && ogc_reg_c( $cfg, 'check_by' ) ? 'No check received by ' . ogc_reg_mail_date( ogc_reg_c( $cfg, 'check_by' ) ) : '', $m['paid'] ? $paid : '' ) ) );
	}
	if ( $m['due'] ) {
		return array_values( array_filter( array( ( $m['paid'] ? 'Balance due · ' : 'Payment due · ' ) . ogc_reg_money( (int) $m['due'] ), 'Pay on Your sign-ups', $m['paid'] ? $paid : '' ) ) );
	}
	if ( $m['paid'] ) {
		return array( $paid, 'Nothing due' );
	}
	return (int) $d['price']['total_cents'] ? array() : array( 'Nothing due' );
}

/**
 * The parent's email: who registered their child, the child's hall and nights, their own cost only,
 * one button to the approval page (and the plain address as a fallback), and who to ask. No other
 * person's name (the roommate is on the page, behind the link).
 */
function ogc_reg_mail_parent( $rec, $token, $again = false ) {
	if ( $rec['sample'] ) {
		return;
	}
	$d     = $rec['data'];
	$y     = (int) $rec['year'];
	$link  = ogc_url( 'register', array( 'year' => $y, 'approve' => $token ) );
	$who   = ogc_reg_approval_people( $d );
	$days  = ogc_reg_days( $y );
	$cfg   = ogc_reg_cfg( $y );
	$names = array_map( 'ogc_reg_first', wp_list_pluck( $who, 'name' ) );
	$named = implode( ' and ', $names );
	$facts = array( array( 'Registered by', ogc_reg_approval_by( $d ) ) );
	foreach ( $who as $p ) {
		$ns  = ogc_reg_nights_for( $p, $d, $cfg );
		$hall = 'women' === $p['yfHall'] ? 'Young women’s hall' : 'Young men’s hall';
		$facts[] = array( count( $who ) > 1 ? ogc_reg_first( $p['name'] ) : 'Hall', ( count( $who ) > 1 ? $hall . "\n" : $hall ) . ( $ns ? "\n" . 'Check-in ' . ogc_reg_mail_date( ogc_reg_night_date( $days, $ns[0] ) ) . ' · Check-out ' . ogc_reg_mail_date( ogc_reg_add_days( ogc_reg_night_date( $days, $ns[ count( $ns ) - 1 ] ), 1 ) ) . ' · ' . ogc_reg_plural( count( $ns ), 'night' ) : '' ) );
	}
	$own  = ogc_reg_approval_lines( $d, $y );
	$rows = array();
	foreach ( $own['lines'] as $l ) {
		$rows[] = array( $l['label'], (int) $l['cents'] );
	}
	if ( count( $rows ) > 1 ) {
		$rows[] = array( 'Total', (int) $own['total'], true );
	}
	// How it's paid: a Youngfolk alone, the amounts (Paid, Check to come, Due), never a row without one;
	// in a family's registration, one line under the table ("Paid by the registration").
	$m     = isset( $d['money'] ) ? $d['money'] : array();
	$paidl = '';
	if ( ogc_reg_approval_alone( $d ) ) {
		foreach ( array( 'paid' => 'Paid', 'check' => 'Check to come', 'due' => 'Due' ) as $k => $label ) {
			if ( ! empty( $m[ $k ] ) && ! ( 'due' === $k && ! empty( $m['check'] ) ) ) {
				$rows[] = array( $label, (int) $m[ $k ] );
			}
		}
	} else {
		$paidl = ogc_reg_approval_covered( $d );
	}
	$q      = ogc_reg_c( $cfg, 'questions_email' );
	ogc_reg_mail_send( $d['approval']['to'], array(
		'subject'   => ( $again ? 'Reminder · ' : '' ) . 'Approve ' . $named . ' for the ' . $y . ' Annual Conference',
		'preheader' => 'Registered by ' . ogc_reg_approval_by( $d ),
		'heading'   => 'Approval needed',
		'lines'     => array_values( array_filter( array( 'Approve ' . $named . ' staying in the ' . ogc_reg_halls_words( array( 'people' => $who ) ) . ' (under 18).', '[[ogc:0]]', '[[ogc:1]]', $paidl ) ) ),
		'button'    => array( 'Review and approve', $link ),
		'after'     => array( array( 'Button not working?', 'Open the approval page', $link ), 'Not expecting this? Ignore it: nothing is approved without you.' ),
		'questions' => ogc_reg_questions_words( $y ),
		'reason'    => 'Someone registering a Youngfolk under 18 gave this address for a parent.',
	), array( ogc_reg_mail_facts( $facts ), ogc_reg_mail_money( $rows ) ), 'parent_approval', $y, is_email( $q ) ? $q : '' );
}
