<?php
/**
 * Registration's emails, and checking an email inside the form (register area).
 *
 * A person is their email once they've shown it's theirs: at Contact the form asks the site's one
 * sign-in (module-auth: auth/send with for=register) for six digits (no link: a link opens a new tab,
 * and the draft is kept in this tab only); typing them (auth/code) signs the person in on this device,
 * and the form carries on where it was. Nothing says whether an email already has a registration until
 * it's confirmed.
 *
 * Emails are plain text, sent once by the site with wp_mail (locally, nothing is sent: core-dev.php
 * notes each one, and here the whole message is kept in the option ogc_reg_dev_mail for testing).
 * Sample households are never emailed.
 */

defined( 'ABSPATH' ) || exit;

/** Send one plain email. $lines are joined with line breaks. */
function ogc_reg_mail( $to, $subject, $lines, $kind = 'registration_received', $year = 0 ) {
	$to = strtolower( trim( (string) $to ) );
	if ( ! is_email( $to ) ) {
		return false;
	}
	$body = implode( "\n", (array) $lines ) . "\n";
	// The site's one way to send (module-mail.php: the house layout, the Mail log, the limits).
	if ( function_exists( 'ogc_send_mail' ) ) {
		return ogc_send_mail( $to, $subject, $body, array( 'kind' => $kind, 'year' => $year ) );
	}
	if ( ogc_reg_local() ) {
		$log   = (array) get_option( 'ogc_reg_dev_mail', array() );
		$log[] = array( 'at' => ogc_now(), 'to' => $to, 'subject' => $subject, 'body' => $body );
		update_option( 'ogc_reg_dev_mail', array_slice( $log, -40 ), false );
	}
	return wp_mail( $to, $subject, $body, array( 'Content-Type: text/plain; charset=UTF-8' ) );
}

/** Who to ask, by role (registration.csv questions_email), never a person's own address:
 * "lodging@example.org (Registration committee)". Nothing when the COA hasn't given an address: a name
 * with no way to reach it helps nobody. */
function ogc_reg_questions_words( $year ) {
	$q = ogc_reg_c( ogc_reg_cfg( $year ), 'questions_email' );
	if ( ! is_email( $q ) ) {
		return '';
	}
	$who = trim( ogc_reg_c( ogc_reg_settings( $year ), 'owner_registration' ) );
	return $q . ( $who ? ' (' . $who . ')' : '' );
}
function ogc_reg_questions_line( $year ) {
	$w = ogc_reg_questions_words( $year );
	return $w ? 'Questions: ' . $w : '';
}

/** The address of Your sign-ups for a year. */
function ogc_reg_mine_url( $year ) {
	return ogc_url( 'register', array( 'year' => (int) $year, 'view' => 'mine' ) );
}

/** The registration's lines for an email: who, where, nights, total. */
function ogc_reg_mail_summary( $rec ) {
	$d     = $rec['data'];
	$s     = $d['stay'];
	$TY    = array( 'dorm' => ogc_reg_plural( (int) $s['rooms'], 'dorm room' ), 'camper' => 'Camper lot', 'elsewhere' => 'Off campus', 'yf' => ogc_reg_halls_words( $d ) );
	$lines = array(
		'Registration ' . $d['rid'],
		ogc_reg_label( $d ) . ' · ' . ogc_reg_plural( count( $d['people'] ), 'person', 'people' ),
		implode( ', ', wp_list_pluck( $d['people'], 'name' ) ),
		$TY[ $s['type'] ] . ( $s['nights'] ? ' · ' . ogc_reg_plural( count( $s['nights'] ), 'night' ) . ' · ' . implode( ', ', $s['nights'] ) : '' ),
	);
	foreach ( $d['price']['lines'] as $l ) {
		$lines[] = '  ' . $l['label'] . '  ' . ogc_reg_money( $l['cents'] );
	}
	$lines[] = 'Total ' . ogc_reg_money( $d['price']['total_cents'] );
	return $lines;
}

/** Check instructions: payee and mailing address (by role, set by the COA), the date it's due, the ID. */
function ogc_reg_check_lines( $rec ) {
	$cfg = ogc_reg_cfg( $rec['year'] );
	$out = array( 'Mail a check for ' . ogc_reg_money( $rec['data']['money']['check'] ) . ' with ' . $rec['data']['rid'] . ' on it.' );
	if ( ogc_reg_c( $cfg, 'check_payee' ) ) {
		$out[] = 'Payable to: ' . ogc_reg_c( $cfg, 'check_payee' );
	}
	if ( ogc_reg_c( $cfg, 'check_address' ) ) {
		$out[] = 'Mail to: ' . implode( ', ', ogc_reg_check_address( $cfg ) );
	}
	if ( ogc_reg_c( $cfg, 'check_by' ) ) {
		$out[] = 'Arrives by ' . gmdate( 'F j', strtotime( ogc_reg_c( $cfg, 'check_by' ) . ' UTC' ) );
	}
	return $out;
}

/** The check address's lines, less a first line that only repeats the payee. */
function ogc_reg_check_address( $cfg ) {
	$lines = array_values( array_filter( array_map( 'trim', explode( '|', ogc_reg_c( $cfg, 'check_address' ) ) ) ) );
	if ( $lines && 0 === strcasecmp( $lines[0], trim( ogc_reg_c( $cfg, 'check_payee' ) ) ) ) {
		array_shift( $lines );
	}
	return $lines;
}

/** Everyone a registration's emails go to: its owner, and a helper who made it. */
function ogc_reg_recipients( $rec ) {
	$to = array();
	if ( is_email( $rec['email'] ) ) {
		$to[] = $rec['email'];
	}
	foreach ( (array) ( isset( $rec['data']['managers'] ) ? $rec['data']['managers'] : array() ) as $m ) {
		if ( is_email( $m ) ) {
			$to[] = $m;
		}
	}
	return array_values( array_unique( $to ) );
}

/* ------------------------------------------------------------------ laying an email out */

/**
 * One registration email in the house layout (ogc_mail_compose: the site's name, one heading, a button,
 * Questions by role, the footer), with blocks of its own the layout doesn't have (a money table, the
 * check's tinted box). $a: compose's arguments; $blocks: each array( html, text ), placed where
 * $a['lines'] holds '[[ogc:N]]'. Without the house layout (signin area missing): plain text.
 */
function ogc_reg_mail_send( $to, $a, $blocks, $kind, $year, $reply = '' ) {
	$a = array_merge( array( 'year' => $year, 'to' => $to ), $a );
	if ( ! function_exists( 'ogc_mail_compose' ) ) {
		$t = array( $a['heading'], '' );
		foreach ( (array) $a['lines'] as $l ) {
			$t[] = preg_match( '/^\[\[ogc:(\d+)\]\]$/', $l, $m ) ? $blocks[ (int) $m[1] ]['text'] : $l;
		}
		if ( ! empty( $a['button'] ) ) {
			$t[] = $a['button'][0] . ': ' . $a['button'][1];
		}
		return ogc_reg_mail( $to, $a['subject'], $t, $kind, $year );
	}
	$m    = ogc_mail_compose( $a );
	$html = $m['html'];
	$text = $m['text'];
	foreach ( $blocks as $i => $b ) {
		$html = preg_replace( '#<p[^>]*>\[\[ogc:' . $i . '\]\]</p>#', str_replace( array( '\\', '$' ), array( '\\\\', '\$' ), $b['html'] ), $html );
		$text = str_replace( '[[ogc:' . $i . ']]', $b['text'], $text );
	}
	return ogc_send_mail( $to, $a['subject'], $html, array( 'kind' => $kind, 'year' => $year, 'text' => $text, 'reply_to' => $reply ) );
}

/** Words that must stay on one line keep together: a number and its unit ("5 nights"), "× $65",
 * a phone (555-555-0142) and a date ("Sat May 29"). Non-breaking spaces and hyphens (U+00A0, U+2011). */
function ogc_reg_nb( $t ) {
	$t = preg_replace( '/(\d) (?=[A-Za-z$])/u', "$1\u{00A0}", (string) $t );
	$t = preg_replace( '/ × /u', "\u{00A0}×\u{00A0}", $t );
	$t = preg_replace( '/ · /u', "\u{00A0}· ", $t );
	$t = str_replace( 'check-in', "check\u{2011}in", $t );
	$t = preg_replace( '/\b(\d{3})-(\d{3})-(\d{4})\b/u', "$1\u{2011}$2\u{2011}$3", $t );
	return preg_replace( '/\b(Mon|Tue|Wed|Thu|Fri|Sat|Sun) (Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec) /u', "$1\u{00A0}$2\u{00A0}", $t );
}

/** A money table: label left, amount right, the sum rows bold. $rows: array( label, cents, sum? ). */
function ogc_reg_mail_money( $rows ) {
	$sans = 'Arial,Helvetica,sans-serif';
	$h    = '';
	$t    = array();
	foreach ( $rows as $r ) {
		$sum = ! empty( $r[2] );
		$amt = is_int( $r[1] ) ? ogc_reg_money( $r[1] ) : (string) $r[1];
		$td  = 'padding:7px 0;border-bottom:1px solid #e4dfd2;font-family:' . $sans . ';font-size:15px;line-height:20px;color:#333333;' . ( $sum ? 'font-weight:700;' : '' );
		$h  .= '<tr><td class="o-ink" valign="top" style="' . $td . '">' . esc_html( ogc_reg_nb( $r[0] ) ) . '</td><td class="o-ink" valign="top" align="right" style="' . $td . 'padding-left:16px;white-space:nowrap;text-align:right;">' . esc_html( $amt ) . '</td></tr>';
		// Plain text: the amount at the right edge of a 56-character line.
		$pad = max( 2, 56 - ( function_exists( 'mb_strlen' ) ? mb_strlen( $r[0] ) : strlen( $r[0] ) ) - strlen( $amt ) );
		$t[] = $r[0] . str_repeat( ' ', $pad ) . $amt;
	}
	return array(
		'html' => '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="margin:0 0 18px;border-collapse:collapse;">' . $h . '</table>',
		'text' => implode( "\n", $t ) . "\n",
	);
}

/** Facts as the house layout draws them (a tan label, then the words), placed among the lines. */
function ogc_reg_mail_facts( $facts ) {
	$sans  = 'Arial,Helvetica,sans-serif';
	$serif = "'Droid Serif',Georgia,'Times New Roman',serif";
	$h     = '';
	$t     = array();
	foreach ( $facts as $f ) {
		if ( '' === (string) $f[1] ) {
			continue;
		}
		$h  .= '<tr><td class="o-kick" valign="top" style="padding:6px 16px 6px 0;font-family:' . $sans . ';font-size:12px;line-height:20px;font-weight:700;letter-spacing:1.2px;text-transform:uppercase;color:#76623F;white-space:nowrap;">' . esc_html( $f[0] ) . '</td>' .
			'<td class="o-ink" valign="top" style="padding:6px 0;font-family:' . $serif . ';font-size:16px;line-height:22px;color:#333333;">' . nl2br( esc_html( ogc_reg_nb( $f[1] ) ) ) . '</td></tr>';
		$t[] = $f[0] . ': ' . str_replace( "\n", ' · ', $f[1] );
	}
	return array( 'html' => '<table role="presentation" cellpadding="0" cellspacing="0" border="0" style="margin:0 0 18px;border-collapse:collapse;">' . $h . '</table>', 'text' => implode( "\n", $t ) . "\n" );
}

/** A tinted box of short lines (the check's details). */
function ogc_reg_mail_box( $lines ) {
	$sans = 'Arial,Helvetica,sans-serif';
	return array(
		'html' => '<div class="o-code" style="margin:0 0 18px;padding:14px 16px;background:#F3F2EB;border-radius:6px;font-family:' . $sans . ';font-size:15px;line-height:1.55;color:#333333;">' . implode( '<br>', array_map( 'esc_html', $lines ) ) . '</div>',
		'text' => implode( "\n", $lines ) . "\n",
	);
}

/** "Sat May 29": the area's one date format. */
function ogc_reg_mail_date( $iso ) {
	$t = strtotime( (string) $iso . ' 12:00 UTC' );
	return $t ? gmdate( 'D M j', $t ) : (string) $iso;
}

/** What a stay is, in a line ("1 dorm room · Fri May 28 – Wed Jun 2 · 5 nights"). */
function ogc_reg_mail_stay( $rec ) {
	$d    = $rec['data'];
	$s    = $d['stay'];
	$days = ogc_reg_days( $rec['year'] );
	$TY   = array( 'dorm' => ogc_reg_plural( (int) $s['rooms'], 'dorm room' ), 'camper' => 'Camper lot', 'elsewhere' => 'Off campus', 'yf' => ogc_reg_halls_words( $d ) );
	$ns   = array_values( (array) $s['nights'] );
	if ( ! $ns ) {
		return $TY[ $s['type'] ];
	}
	$a = ogc_reg_night_date( $days, $ns[0] );
	$b = ogc_reg_add_days( ogc_reg_night_date( $days, $ns[ count( $ns ) - 1 ] ), 1 );
	return $TY[ $s['type'] ] . ' · ' . ogc_reg_mail_date( $a ) . ' – ' . ogc_reg_mail_date( $b ) . ' · ' . ogc_reg_plural( count( $ns ), 'night' );
}

/** The halls Young Folks on their own are in, by name ("Young men’s hall", or both). */
function ogc_reg_halls_words( $d ) {
	$h = array();
	foreach ( (array) $d['people'] as $p ) {
		if ( ! empty( $p['yf'] ) ) {
			$h[ 'women' === $p['yfHall'] ? 'Young women’s hall' : 'Young men’s hall' ] = true;
		}
	}
	return $h ? implode( ' and ', array_keys( $h ) ) : 'Young Folks hall';
}

/* ------------------------------------------------------------------ the emails */

/**
 * The confirmation (on registering), the receipt (paid by card), "Changed" and "Cancelled". Laid out
 * like the thank-you page: the status, what changed (first, on a change), the ID, the money as a table,
 * the check's details in a tinted box, one button for Your sign-ups, and who to ask (by role).
 */
function ogc_reg_mail_receipt( $rec, $why ) {
	if ( $rec['sample'] ) {
		return;
	}
	$d     = $rec['data'];
	$y     = (int) $rec['year'];
	$cfg   = ogc_reg_cfg( $y );
	$m     = $d['money'];
	$WORDS = array( 'registered' => 'Registered', 'payment_due' => 'Payment due', 'balance_due' => 'Balance due', 'check_to_come' => 'Check to come', 'refund_due' => 'Refund requested', 'waitlist' => 'Waitlist', 'cancelled' => 'Cancelled' );
	$TITLE = array( 'new' => 'Registered', 'paid' => 'Paid', 'changed' => 'Registration changed', 'cancelled' => 'Registration cancelled' );
	$st    = isset( $WORDS[ $d['status'] ] ) ? $WORDS[ $d['status'] ] : $d['status'];
	if ( 'registered' === $d['status'] && $m['paid'] > 0 ) {
		$st = 'Paid ' . ogc_reg_money( $m['paid'] );
	}
	$late = ! empty( $m['late'] ) && 'card' !== ogc_reg_c( $cfg, 'late_pay' );
	if ( in_array( $d['status'], array( 'payment_due', 'balance_due' ), true ) && ( 'checkin' === ( isset( $d['pay'] ) ? $d['pay'] : '' ) || $late ) ) {
		$st = 'Due at check-in · ' . ogc_reg_money( (int) $m['due'] );
	}
	if ( isset( $d['approval']['state'] ) && 'waiting' === $d['approval']['state'] && empty( $d['approval']['held'] ) ) {
		$st .= ' · Waiting for parent';
	}
	$lines  = array();
	$blocks = array();
	$last = ! empty( $d['history'] ) ? end( $d['history'] ) : null;
	if ( 'changed' === $why && $last ) {
		$lines[] = $last['what'];
	}
	// Cancelled because a parent declined: the reason first (polish 3: a 17-year-old was told only
	// "Cancelled"). The heading already says cancelled.
	$why_line = 'cancelled' === $why && $last && 0 === strpos( $last['what'], 'Declined' ) ? $last['what'] : '';
	if ( $why_line ) {
		$lines[] = $why_line;
	} elseif ( ! ( 'paid' === $why && 0 === strpos( $st, 'Paid' ) && false === strpos( $st, '·' ) ) && ! ( 'cancelled' === $why && 'Cancelled' === $st ) ) {
		// The status, unless the heading already says it ("Paid", then "Paid $967.50").
		$lines[] = $st;
	}
	$lines[] = '[[ogc:0]]';
	$facts   = array(
		array( 'Registration', $d['rid'] ),
		array( 'Who', ogc_reg_label( $d ) . ( count( $d['people'] ) > 1 ? ' · ' . ogc_reg_plural( count( $d['people'] ), 'person', 'people' ) : '' ) ),
		array( 'Stay', ogc_reg_mail_stay( $rec ) ),
		array( 'Linens', ogc_reg_linen_words( $d ) ),
	);
	$rows = array();
	foreach ( $d['price']['lines'] as $l ) {
		$rows[] = array( $l['label'], (int) $l['cents'] );
	}
	$rows[] = array( 'Total', (int) $d['price']['total_cents'], true );
	if ( $m['paid'] ) {
		$rows[] = array( 'Paid', (int) $m['paid'] );
	}
	if ( $m['check'] ) {
		$rows[] = array( 'Check to come', (int) $m['check'] );
	}
	if ( $m['refund'] ) {
		$rows[] = array( 'Refund requested', (int) $m['refund'], true );
	}
	if ( $m['due'] && ! $m['check'] ) {
		$rows[] = array( 'checkin' === ( isset( $d['pay'] ) ? $d['pay'] : '' ) || $late ? 'Due at check-in' : ( $m['paid'] ? 'Balance due' : 'Due' ), (int) $m['due'], true );
	}
	$blocks[] = ogc_reg_mail_facts( $facts );
	$blocks[] = ogc_reg_mail_money( $rows );
	$lines[]  = '[[ogc:1]]';
	if ( $m['check'] ) {
		$blocks[] = ogc_reg_mail_box( ogc_reg_check_lines( $rec ) );
		$lines[]  = '[[ogc:2]]';
	} elseif ( $late && $m['due'] ) {
		// A check that didn't come by check_by: due at check-in, where (never "Mail a check").
		$blocks[] = ogc_reg_mail_box( array_values( array_filter( array( 'Due at check-in · ' . ogc_reg_money( (int) $m['due'] ), ogc_reg_c( $cfg, 'checkin_place' ), 'No check received by ' . ogc_reg_mail_date( ogc_reg_c( $cfg, 'check_by' ) ) ) ) ) );
		$lines[]  = '[[ogc:2]]';
	}
	$after = array();
	// The parent's address in full: the household typed it, and a typo must be seen to be fixed.
	if ( isset( $d['approval']['state'] ) && 'waiting' === $d['approval']['state'] && empty( $d['approval']['held'] ) ) {
		$after[] = 'Approval sent to ' . $d['approval']['to'];
	}
	if ( ogc_reg_c( $cfg, 'refunds_by' ) && 'cancelled' !== $d['status'] ) {
		$after[] = 'Refund requests until ' . gmdate( 'F j', strtotime( ogc_reg_c( $cfg, 'refunds_by' ) . ' UTC' ) );
	}
	$q = ogc_reg_c( $cfg, 'questions_email' );
	$K = array( 'new' => 'registration_received', 'paid' => 'payment_received', 'changed' => 'registration_changed', 'cancelled' => 'registration_changed' );
	foreach ( ogc_reg_recipients( $rec ) as $to ) {
		// Each address gets its own Your sign-ups link (the signin area's: it never signs anyone in by itself).
		$link = function_exists( 'ogc_mine_url' ) ? ogc_mine_url( $to, $y ) : ogc_reg_mine_url( $y );
		ogc_reg_mail_send( $to, array(
			'subject'   => $y . ' Annual Conference · ' . $TITLE[ $why ] . ' · ' . $d['rid'],
			'preheader' => $st . ' · ' . $d['rid'],
			'heading'   => $TITLE[ $why ],
			'lines'     => $lines,
			'button'    => array( 'Your sign-ups', $link ),
			'after'     => $after,
			'questions' => ogc_reg_questions_words( $y ),
			'reason'    => 'You registered, or made this registration for someone.',
		), $blocks, $K[ $why ], $y, is_email( $q ) ? $q : '' );
	}
}

/**
 * The parent's email: who registered their child, the child's hall and nights, their own cost only,
 * one button to the approval page (and the plain address as a fallback), and who to ask. No other
 * person's name (the roommate is on the page, behind the link).
 */
function ogc_reg_mail_parent( $rec, $token, $again = false ) {
	if ( $rec['sample'] ) {
		return;
	}
	$d     = $rec['data'];
	$y     = (int) $rec['year'];
	$link  = ogc_url( 'register', array( 'year' => $y, 'approve' => $token ) );
	$who   = ogc_reg_approval_people( $d );
	$days  = ogc_reg_days( $y );
	$cfg   = ogc_reg_cfg( $y );
	$names = array_map( 'ogc_reg_first', wp_list_pluck( $who, 'name' ) );
	$named = implode( ' and ', $names );
	$facts = array( array( 'Registered by', ogc_reg_approval_by( $d ) ) );
	foreach ( $who as $p ) {
		$ns  = ogc_reg_nights_for( $p, $d, $cfg );
		$hall = 'women' === $p['yfHall'] ? 'Young women’s hall' : 'Young men’s hall';
		$facts[] = array( count( $who ) > 1 ? ogc_reg_first( $p['name'] ) : 'Hall', ( count( $who ) > 1 ? $hall . "\n" : $hall ) . ( $ns ? "\n" . 'Check-in ' . ogc_reg_mail_date( ogc_reg_night_date( $days, $ns[0] ) ) . ' · Check-out ' . ogc_reg_mail_date( ogc_reg_add_days( ogc_reg_night_date( $days, $ns[ count( $ns ) - 1 ] ), 1 ) ) . ' · ' . ogc_reg_plural( count( $ns ), 'night' ) : '' ) );
	}
	$own  = ogc_reg_approval_lines( $d, $y );
	$rows = array();
	foreach ( $own['lines'] as $l ) {
		$rows[] = array( $l['label'], (int) $l['cents'] );
	}
	if ( count( $rows ) > 1 ) {
		$rows[] = array( 'Total', (int) $own['total'], true );
	}
	// How it's paid: a Young Folk alone, the amounts (Paid, Check to come, Due), never a row without one;
	// in a family's registration, one line under the table ("Paid by the registration").
	$m     = isset( $d['money'] ) ? $d['money'] : array();
	$paidl = '';
	if ( ogc_reg_approval_alone( $d ) ) {
		foreach ( array( 'paid' => 'Paid', 'check' => 'Check to come', 'due' => 'Due' ) as $k => $label ) {
			if ( ! empty( $m[ $k ] ) && ! ( 'due' === $k && ! empty( $m['check'] ) ) ) {
				$rows[] = array( $label, (int) $m[ $k ] );
			}
		}
	} else {
		$paidl = ogc_reg_approval_covered( $d );
	}
	$q      = ogc_reg_c( $cfg, 'questions_email' );
	ogc_reg_mail_send( $d['approval']['to'], array(
		'subject'   => ( $again ? 'Reminder · ' : '' ) . 'Approve ' . $named . ' for the ' . $y . ' Annual Conference',
		'preheader' => 'Registered by ' . ogc_reg_approval_by( $d ),
		'heading'   => 'Approval needed',
		'lines'     => array_values( array_filter( array( 'Approve ' . $named . ' staying in the ' . ogc_reg_halls_words( array( 'people' => $who ) ) . ' (under 18).', '[[ogc:0]]', '[[ogc:1]]', $paidl ) ) ),
		'button'    => array( 'Review and approve', $link ),
		'after'     => array( array( 'Button not working?', 'Open the approval page', $link ), 'Not expecting this? Ignore it: nothing is approved without you.' ),
		'questions' => ogc_reg_questions_words( $y ),
		'reason'    => 'Someone registering a Young Folk under 18 gave this address for a parent.',
	), array( ogc_reg_mail_facts( $facts ), ogc_reg_mail_money( $rows ) ), 'parent_approval', $y, is_email( $q ) ? $q : '' );
}
