<?php
/**
 * The plugin's tables, made and kept up to date with dbDelta.
 *
 * An area adds a table by adding to the ogc_schema filter from its own module file:
 *   add_filter( 'ogc_schema', function ( $sql, $charset ) { $sql[] = "CREATE TABLE " . ogc_table( 'x' ) . " ( … ) $charset;"; return $sql; }, 10, 2 );
 * The SQL is applied again whenever OGC_DB_VERSION or the SQL itself changes, so no version needs
 * bumping for an area's new table. Write it for both MySQL and SQLite (the local site): dbDelta's
 * format (one column a line, two spaces after PRIMARY KEY, KEY not INDEX), no ENUM, no JSON type
 * (longtext holds JSON), datetimes NULL rather than a zero default.
 */

defined( 'ABSPATH' ) || exit;

add_filter( 'ogc_schema', 'ogc_core_schema', 5, 2 );

function ogc_core_schema( $sql, $charset ) {
	// One row a Conference: its fields as years.csv has them (start, end, venue, city, hosts, data…).
	$sql[] = 'CREATE TABLE ' . ogc_table( 'years' ) . " (
  year smallint(5) unsigned NOT NULL,
  fields longtext NOT NULL,
  updated_at datetime NULL,
  PRIMARY KEY  (year)
) $charset;";
	// A year's parts, one row a file (schedule, settings, shifts…): the rows the pages read, as JSON.
	// version goes up on every change; a PUT that names an older version is refused (409).
	// ("rows_json", not "rows": ROWS is a reserved word in MySQL 8.)
	$sql[] = 'CREATE TABLE ' . ogc_table( 'files' ) . " (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  year smallint(5) unsigned NOT NULL,
  name varchar(48) NOT NULL,
  rows_json longtext NOT NULL,
  cols longtext NULL,
  version int(10) unsigned NOT NULL DEFAULT 1,
  updated_by bigint(20) unsigned NOT NULL DEFAULT 0,
  updated_at datetime NULL,
  PRIMARY KEY  (id),
  UNIQUE KEY year_name (year,name)
) $charset;";
	// What people sign up for (registrations, shifts, waits, teams…), one row each, with the email it
	// belongs to. Removed rows keep deleted_at until they're cleared.
	$sql[] = 'CREATE TABLE ' . ogc_table( 'records' ) . " (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  year smallint(5) unsigned NOT NULL,
  kind varchar(32) NOT NULL,
  email varchar(190) NOT NULL DEFAULT '',
  data longtext NOT NULL,
  sample tinyint(1) NOT NULL DEFAULT 0,
  source varchar(32) NOT NULL DEFAULT '',
  created_at datetime NULL,
  updated_at datetime NULL,
  deleted_at datetime NULL,
  PRIMARY KEY  (id),
  KEY year_kind (year,kind),
  KEY email (email)
) $charset;";
	// Small values a year keeps that aren't files (Lodging's rooms, meals sent, the pickup log…).
	$sql[] = 'CREATE TABLE ' . ogc_table( 'state' ) . " (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  year smallint(5) unsigned NOT NULL,
  skey varchar(64) NOT NULL,
  value longtext NOT NULL,
  version int(10) unsigned NOT NULL DEFAULT 1,
  updated_by bigint(20) unsigned NOT NULL DEFAULT 0,
  updated_at datetime NULL,
  PRIMARY KEY  (id),
  UNIQUE KEY year_skey (year,skey)
) $charset;";
	// The change log: who changed what, when.
	$sql[] = 'CREATE TABLE ' . ogc_table( 'log' ) . " (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  at datetime NOT NULL,
  user bigint(20) unsigned NOT NULL DEFAULT 0,
  year smallint(5) unsigned NOT NULL DEFAULT 0,
  action varchar(32) NOT NULL,
  target varchar(128) NOT NULL DEFAULT '',
  detail longtext NULL,
  PRIMARY KEY  (id),
  KEY year (year),
  KEY at (at)
) $charset;";
	return $sql;
}

function ogc_schema_sql() {
	global $wpdb;
	return (array) apply_filters( 'ogc_schema', array(), $wpdb->get_charset_collate() );
}

/** Apply the schema when it has changed since it was last applied. */
function ogc_install_schema( $force = false ) {
	$sql   = ogc_schema_sql();
	$stamp = OGC_DB_VERSION . ':' . md5( implode( "\n", $sql ) );
	if ( ! $force && get_option( 'ogc_db_version' ) === $stamp ) {
		return false;
	}
	// One request at a time applies it (two visitors after an update both ran it); a lock older than five
	// minutes is a request that died, and is taken over.
	if ( ! $force ) {
		$held = (int) get_option( 'ogc_upgrading', 0 );
		if ( $held && $held > time() - 300 ) {
			return false;
		}
		if ( ! add_option( 'ogc_upgrading', time(), '', false ) ) {
			update_option( 'ogc_upgrading', time(), false );
		}
	}
	require_once ABSPATH . 'wp-admin/includes/upgrade.php';
	dbDelta( $sql );
	// The stamp is kept only when every table is there (dbDelta says nothing when one fails).
	global $wpdb;
	$missing = array();
	foreach ( $sql as $q ) {
		if ( preg_match( '/CREATE TABLE\s+`?([A-Za-z0-9_]+)`?/i', $q, $m ) && $m[1] !== $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $m[1] ) ) ) ) {
			$missing[] = $m[1];
		}
	}
	delete_option( 'ogc_upgrading' );
	if ( $missing ) {
		error_log( 'ogc-conference: tables not made: ' . implode( ', ', $missing ) . ' · ' . $wpdb->last_error ); // phpcs:ignore -- for the webmaster.
		return false;
	}
	update_option( 'ogc_db_version', $stamp, true );
	return true;
}

/** On activation: the tables and the pages' addresses; the seed only on a local dev site
 * (ogc_seed_on_activate: on ogbbc.org a webmaster loads the reviewed years deliberately). */
function ogc_activate() {
	ogc_install_schema( true );
	if ( function_exists( 'ogc_import_seed' ) && ogc_seed_on_activate() ) {
		ogc_import_seed();
	}
	ogc_register_rewrites();
	flush_rewrite_rules( false );
	update_option( 'ogc_rewrite_stamp', ogc_rewrite_stamp(), true );
}

/** On deactivation: the plugin's timers stop and its addresses go (WordPress rebuilds the rules without
 * them on the next request). Every table and value stays; uninstall.php says how to erase them. */
function ogc_deactivate() {
	foreach ( array( 'ogc_vol_tick', 'ogc_daily', 'ogc_reg_daily', 'ogc_lodging_daily', 'ogc_mail_queue' ) as $hook ) {
		wp_clear_scheduled_hook( $hook );
	}
	// flush_rewrite_rules() here would write the plugin's rules back (they're still registered in this
	// request): delete them, so they're rebuilt without them.
	delete_option( 'rewrite_rules' );
	delete_option( 'ogc_rewrite_stamp' );
	delete_option( 'ogc_public_rewrites' );
}

// An updated plugin (or an area's new table) is applied on the next request.
add_action( 'plugins_loaded', function () {
	if ( ogc_install_schema() && function_exists( 'ogc_import_seed' ) && ogc_seed_on_activate() ) {
		ogc_import_seed();
	}
} );
