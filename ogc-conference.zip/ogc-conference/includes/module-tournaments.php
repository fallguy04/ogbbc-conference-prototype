<?php
/**
 * Young Folks tournaments (lists area): the public sign-up page, My teams, and the committee's list.
 * A team is a record of kind "teams", made, changed and withdrawn only through these routes, which
 * hold every rule on the server: the tournament is posted, sign-ups are open on the campus's clock,
 * the team's size, its rule, one sign-up per person per tournament, and a limit per email and address.
 *
 *   GET    tn/{y}             everyone   the tournaments: when and where (from the published schedule),
 *                                        sizes, when sign-ups open and close, how many teams; and for
 *                                        someone signed in, their own teams. Never anyone's names.
 *   POST   tn/{y}/teams       signed in  {tid, mode: team|solo, players, team, phone, rule, mates, for_other}
 *   PUT    tn/r/{id}          the signer (until it closes) or a member   the same fields
 *   DELETE tn/r/{id}          the signer (until it closes) or a member   withdraw (members: remove)
 *   POST   tn/r/{id}/restore  the same person, within 15 minutes, or a member   Undo
 *   GET    tn/{y}/teams       members    every team, with the captain's phone and email (?format=csv&tid=)
 *   POST   tn/{y}/add         members    {…} a team the committee takes in person (marked Late after close)
 *   PATCH  tn/r/{id}/flag     members    {no_show}
 *   POST   tn/{y}/message     members    {tid, subject, body, preview}  an email to every team
 *
 * Teams keep v3's fields (tid, team, players, phone, email) so Your sign-ups reads them unchanged.
 */

defined( 'ABSPATH' ) || exit;

/* ================================================================== the page */

add_filter( 'ogc_pages', function ( $p ) {
	if ( isset( $p['tournaments'] ) ) {
		$p['tournaments']['styles']  = array( 'shared/ogc-tokens.css', 'shared/ogc-ui.css', 'schedule-hub/week.css', 'shared/ogc-ws.css', 'tournaments/tournaments.css' );
		$p['tournaments']['scripts'] = array( 'shared/ogc-core.js', 'shared/ogc-store.js', 'shared/ogc-signups.js', 'tournaments/tournaments.js' );
		$p['tournaments']['description'] = 'Young Folks tournaments at the Annual Conference: when and where, team sizes, and sign-ups.';
	}
	return $p;
} );

add_filter( 'ogc_client_config', function ( $cfg, $key ) {
	if ( 'tournaments' === $key ) {
		$cfg['recordKinds'] = array( 'none' );
		$cfg['recordYears'] = 1;
	}
	return $cfg;
}, 10, 2 );

// The tournaments' sheet keeps two more columns: the most teams (a court's limit) and a close written
// as a real date and time ("2027-05-28 12:00"), which the year page's Close should write.
add_filter( 'ogc_file_columns', function ( $cols, $name ) {
	return 'tournaments' === $name ? array_values( array_unique( array_merge( (array) $cols, array( 'max_teams', 'closes' ) ) ) ) : $cols;
}, 10, 2 );

// Teams are made only through tn/ (the rules above): never through the generic record routes.
add_filter( 'ogc_record_can_write', function ( $ok, $action, $kind ) {
	return 'teams' === $kind ? false : $ok;
}, 40, 3 );

/* ================================================================== the year's tournaments */

function ogc_tn_slug( $s ) {
	return trim( preg_replace( '/[^a-z0-9]+/', '-', strtolower( (string) $s ) ), '-' );
}

/** Is a "posted" setting public at this date? Blank counts as posted (years before the year area). */
function ogc_tn_posted( $v, $today ) {
	$v = trim( (string) $v );
	if ( '' === $v ) {
		return true;
	}
	return preg_match( '/^\d{4}-\d\d-\d\d$/', $v ) && '9999-12-31' !== $v && $v <= $today;
}

/** A close as written: "2027-05-28 12:00", "2027-05-28 noon", or (older sheets) a day and a time, or
 * a date typed into the time ("May 25 noon"). Returns array( date, min ) or null. */
function ogc_tn_close_of( $r, $days, $year ) {
	$c = trim( isset( $r['closes'] ) ? (string) $r['closes'] : '' );
	if ( preg_match( '/^(\d{4}-\d\d-\d\d)(?:[ T](.+))?$/', $c, $m ) ) {
		$t = isset( $m[2] ) ? ogc_lst_min( $m[2] ) : null;
		return array( 'date' => $m[1], 'min' => null === $t ? 1439 : $t );
	}
	$time = trim( isset( $r['closes_time'] ) ? (string) $r['closes_time'] : '' );
	if ( preg_match( '/^([a-z]{3,9}\.?\s+\d{1,2})(?:,?\s*(.*))?$/i', $time, $m ) ) {
		$ts = strtotime( $m[1] . ' ' . $year . ' 12:00:00 UTC' );
		if ( $ts ) {
			$t = isset( $m[2] ) && '' !== $m[2] ? ogc_lst_min( $m[2] ) : null;
			return array( 'date' => gmdate( 'Y-m-d', $ts ), 'min' => null === $t ? 1439 : $t );
		}
	}
	$day = trim( isset( $r['closes_day'] ) ? (string) $r['closes_day'] : '' );
	if ( '' !== $day ) {
		$i = ogc_lst_day_index( $days, $day );
		if ( $i >= 0 ) {
			$t = ogc_lst_min( $time );
			return array( 'date' => $days[ $i ]['date'], 'min' => null === $t ? 1439 : $t );
		}
	}
	return null;
}

/** The year's place names by code. */
function ogc_tn_places( $year ) {
	$out = array();
	$f   = ogc_file_get( (int) $year, 'places' );
	foreach ( $f ? $f['rows'] : array() as $p ) {
		if ( ! empty( $p['code'] ) ) {
			$out[ strtoupper( trim( $p['code'] ) ) ] = isset( $p['name'] ) ? (string) $p['name'] : '';
		}
	}
	return $out;
}

/**
 * The year as the page sees it at $now: where things stand and each tournament with its schedule rows.
 * $draft: a member previewing (the schedule before it's published).
 */
function ogc_tn_year( $year, $now, $draft = false ) {
	$year  = (int) $year;
	$row   = ogc_year_get( $year );
	$s     = ogc_lst_kv( $year, 'settings' );
	$days  = function_exists( 'ogc_reg_days' ) ? ogc_reg_days( $year ) : array();
	$sched = ogc_tn_posted( isset( $s['schedule_posted'] ) ? $s['schedule_posted'] : '', $now['date'] );
	$held  = 'yes' === ( isset( $s['tournaments_held'] ) ? $s['tournaments_held'] : '' );
	$shut  = ! empty( $s['tournaments_closed'] ) && $s['tournaments_closed'] <= $now['date'];
	$online = 'no' !== ( isset( $s['tournaments_online'] ) ? $s['tournaments_online'] : '' );
	// Posted: the schedule is published, and (online) the Young Folks part scheduled its sign-ups.
	$posted = $sched && ( ! $online || ! $held );
	$f      = ogc_file_get( $year, 'tournaments' );
	$sf     = ogc_file_get( $year, 'schedule' );
	$places = ogc_tn_places( $year );
	$list   = array();
	foreach ( $f ? $f['rows'] : array() as $r ) {
		if ( empty( $r['id'] ) || empty( $r['name'] ) ) {
			continue;
		}
		$items = array();
		if ( $sched || $draft ) {
			foreach ( $sf ? $sf['rows'] : array() as $x ) {
				$match = ( ! empty( $r['schedule_id'] ) && isset( $x['_id'] ) && $x['_id'] === $r['schedule_id'] ) || ( '' !== ogc_tn_slug( isset( $r['schedule_title'] ) ? $r['schedule_title'] : '' ) && ogc_tn_slug( isset( $x['title'] ) ? $x['title'] : '' ) === ogc_tn_slug( $r['schedule_title'] ) );
				if ( ! $match ) {
					continue;
				}
				$i = ogc_lst_day_index( $days, isset( $x['day'] ) ? $x['day'] : '' );
				if ( $i < 0 ) {
					continue;
				}
				$code    = strtoupper( trim( isset( $x['place'] ) ? (string) $x['place'] : '' ) );
				$items[] = array(
					'date'  => $days[ $i ]['date'],
					'start' => ogc_lst_min( isset( $x['start'] ) ? $x['start'] : '' ),
					'end'   => ogc_lst_min( isset( $x['end'] ) ? $x['end'] : '' ),
					'when'  => ogc_lst_when( $x ),
					'note'  => isset( $x['note'] ) ? (string) $x['note'] : '',
					'code'  => $code,
					'place' => $code && isset( $places[ $code ] ) && $places[ $code ] ? $places[ $code ] : $code,
				);
			}
			usort( $items, function ( $a, $b ) { return strcmp( $a['date'], $b['date'] ) ?: ( (int) $a['start'] - (int) $b['start'] ); } );
		}
		$min   = max( 1, (int) ( isset( $r['min'] ) ? $r['min'] : 1 ) );
		$max   = max( $min, (int) ( isset( $r['max'] ) ? $r['max'] : $min ) );
		$solo  = $max > 1 && ( ogc_lst_yes( isset( $r['solo'] ) ? $r['solo'] : '' ) || 1 === $min );
		$close = ogc_tn_close_of( $r, $days, $year );
		$set   = (bool) $close;
		// No close written: sign-ups close when the tournament starts (true, and never left open).
		if ( ! $close && $items ) {
			$close = array( 'date' => $items[0]['date'], 'min' => null !== $items[0]['start'] ? $items[0]['start'] : 0 );
		}
		$opens = preg_match( '/^\d{4}-\d\d-\d\d$/', isset( $r['opens'] ) ? (string) $r['opens'] : '' ) ? $r['opens'] : '';
		$list[] = array(
			'id'        => (string) $r['id'],
			'name'      => (string) $r['name'],
			'items'     => $items,
			'min'       => $min,
			'max'       => $max,
			'solo'      => $solo,
			'team_min'  => 1 === $min ? min( 2, $max ) : $min,
			'rule'      => isset( $r['rule'] ) ? (string) $r['rule'] : '',
			'note'      => isset( $r['note'] ) ? (string) $r['note'] : '',
			'opens'     => $opens,
			'closes'    => $close,
			'close_set' => $set,
			'max_teams' => isset( $r['max_teams'] ) && is_numeric( $r['max_teams'] ) && (int) $r['max_teams'] > 0 ? (int) $r['max_teams'] : 0,
			'sample'    => ogc_lst_yes( isset( $r['sample'] ) ? $r['sample'] : '' ),
		);
	}
	return array(
		'year'    => $year,
		'row'     => $row,
		'start'   => $row && ! empty( $row['start'] ) ? $row['start'] : '',
		'end'     => $row && ! empty( $row['end'] ) ? $row['end'] : '',
		'venue'   => isset( $s['venue'] ) ? $s['venue'] : '',
		'city'    => isset( $s['city'] ) ? $s['city'] : '',
		'tz'      => isset( $s['timezone'] ) ? $s['timezone'] : 'America/Indiana/Indianapolis',
		'posted'  => $posted,
		'sched'   => $sched,
		'online'  => $online,
		'shut'    => $shut,
		'held'    => $held,
		'how'     => isset( $s['tournaments_how'] ) ? (string) $s['tournaments_how'] : '',
		'owner'   => isset( $s['owner_youngfolks'] ) ? (string) $s['owner_youngfolks'] : '',
		'over'    => $row && ! empty( $row['end'] ) && $now['date'] > $row['end'],
		'list'    => $list,
	);
}

function ogc_tn_find( $Y, $tid ) {
	foreach ( $Y['list'] as $t ) {
		if ( $t['id'] === $tid ) {
			return $t;
		}
	}
	return null;
}

/** Where a tournament's sign-ups stand at $now: soon · open · closed · full. */
function ogc_tn_state( $Y, $t, $now, $count ) {
	if ( $Y['shut'] || $Y['over'] ) {
		return 'closed';
	}
	if ( $t['closes'] && ( $now['date'] > $t['closes']['date'] || ( $now['date'] === $t['closes']['date'] && $now['min'] >= $t['closes']['min'] ) ) ) {
		return 'closed';
	}
	if ( $t['opens'] && $now['date'] < $t['opens'] ) {
		return 'soon';
	}
	if ( $t['max_teams'] && $count >= $t['max_teams'] ) {
		return 'full';
	}
	return 'open';
}

/** The year's live teams (not withdrawn or removed), by tournament. */
function ogc_tn_teams( $year, $with_gone = false ) {
	$out = array();
	foreach ( ogc_records( (int) $year, 'teams' ) as $r ) {
		$st = isset( $r['data']['status'] ) ? $r['data']['status'] : 'active';
		if ( ! $with_gone && in_array( $st, array( 'withdrawn', 'removed' ), true ) ) {
			continue;
		}
		$out[] = $r;
	}
	return $out;
}

function ogc_tn_counts( $teams, $tid ) {
	$c = array( 'teams' => 0, 'alone' => 0, 'players' => 0 );
	foreach ( $teams as $r ) {
		if ( ( isset( $r['data']['tid'] ) ? $r['data']['tid'] : '' ) !== $tid ) {
			continue;
		}
		$n = count( (array) ( isset( $r['data']['players'] ) ? $r['data']['players'] : array() ) );
		if ( ! empty( $r['data']['cleared'] ) ) {
			$n = (int) ( isset( $r['data']['size'] ) ? $r['data']['size'] : 1 );
		}
		$c['players'] += $n;
		if ( 1 === $n ) {
			$c['alone']++;
		} else {
			$c['teams']++;
		}
	}
	return $c;
}

/** Two of a tournament's rows at the same time as another's. */
function ogc_tn_overlap( $a, $b ) {
	foreach ( $a['items'] as $x ) {
		foreach ( $b['items'] as $y ) {
			if ( $x['date'] === $y['date'] && null !== $x['start'] && null !== $y['start'] && null !== $x['end'] && null !== $y['end'] && $x['start'] < $y['end'] && $y['start'] < $x['end'] ) {
				return true;
			}
		}
	}
	return false;
}

function ogc_tn_norm( $name ) {
	return trim( preg_replace( '/[^a-z]+/', ' ', strtolower( remove_accents( (string) $name ) ) ) );
}

function ogc_tn_first_l( $name ) {
	$w = preg_split( '/\s+/', trim( (string) $name ) );
	return count( $w ) > 1 ? $w[0] . ' ' . mb_substr( end( $w ), 0, 1 ) . '.' : $w[0];
}

/** The campus's clock (a local site honours ?as_of= for the walk-through; ogbbc.org never does). */
function ogc_tn_now( $year, $req ) {
	return ogc_lst_now( $year, $req );
}

/** A stored time (UTC) as the campus reads it: "2027-05-20 7:41 PM". */
function ogc_tn_local( $year, $utc ) {
	try {
		$d = new DateTime( (string) $utc, new DateTimeZone( 'UTC' ) );
		$d->setTimezone( ogc_lst_tz( $year ) );
		return $d->format( 'Y-m-d g:i A' );
	} catch ( Exception $e ) {
		return (string) $utc;
	}
}

function ogc_tn_err( $msg, $status = 400, $field = '' ) {
	return new WP_Error( 'ogc_tn', $msg, array_filter( array( 'status' => $status, 'field' => $field ) ) );
}

/** A team as its signer (or a teammate) sees it. */
function ogc_tn_mine_out( $r, $Y, $now ) {
	$d = $r['data'];
	$t = ogc_tn_find( $Y, isset( $d['tid'] ) ? $d['tid'] : '' );
	$st = $t ? ogc_tn_state( $Y, $t, $now, 0 ) : 'closed';
	$own = $r['email'] === ogc_current_email();
	return array(
		'id'        => $r['id'],
		'tid'       => isset( $d['tid'] ) ? $d['tid'] : '',
		'team'      => isset( $d['team'] ) ? $d['team'] : '',
		'players'   => array_values( (array) ( isset( $d['players'] ) ? $d['players'] : array() ) ),
		'mode'      => isset( $d['mode'] ) ? $d['mode'] : 'team',
		'phone'     => $own ? ( isset( $d['phone'] ) ? $d['phone'] : '' ) : '',
		'email'     => $own ? $r['email'] : '',
		'mates'     => $own ? array_values( (array) ( isset( $d['mates'] ) ? $d['mates'] : array() ) ) : array(),
		'rule'      => ! empty( $d['rule'] ),
		'for_other' => ! empty( $d['for_other'] ),
		'status'    => isset( $d['status'] ) ? $d['status'] : 'active',
		'own'       => $own,
		'captain'   => $own ? '' : ogc_tn_first_l( isset( $d['players'][0] ) ? $d['players'][0] : '' ),
		'can'       => $own && 'closed' !== $st && 'active' === ( isset( $d['status'] ) ? $d['status'] : 'active' ),
		'at'        => isset( $d['at'] ) ? $d['at'] : '',
	);
}

/* ================================================================== the rules */

/**
 * A team's answers, checked: the tournament's size, its rule, names, a phone. Returns the cleaned data or
 * a WP_Error naming the field. $warn collects what's worth saying but not refusing.
 */
function ogc_tn_clean( $Y, $t, $in, $existing, &$warn, $phone_optional = false ) {
	$mode = 'solo' === ( isset( $in['mode'] ) ? $in['mode'] : '' ) ? 'solo' : 'team';
	if ( 1 === $t['max'] ) {
		$mode = 'solo';
	}
	if ( 'solo' === $mode && $t['max'] > 1 && ! $t['solo'] ) {
		return ogc_tn_err( 'Teams only', 400, 'mode' );
	}
	$players = array();
	$seen    = array();
	foreach ( array_slice( (array) ( isset( $in['players'] ) ? $in['players'] : array() ), 0, 12 ) as $p ) {
		$p = trim( preg_replace( '/\s+/', ' ', sanitize_text_field( is_scalar( $p ) ? (string) $p : '' ) ) );
		if ( '' === $p ) {
			continue;
		}
		if ( mb_strlen( $p ) > 60 ) {
			return ogc_tn_err( 'Name too long', 400, 'players' );
		}
		if ( isset( $seen[ ogc_tn_norm( $p ) ] ) ) {
			return ogc_tn_err( 'Same name twice', 400, 'players' );
		}
		$seen[ ogc_tn_norm( $p ) ] = true;
		$players[]                 = $p;
	}
	$n = count( $players );
	if ( ! $n ) {
		return ogc_tn_err( 'Add your name', 400, 'players' );
	}
	if ( 'solo' === $mode && 1 !== $n ) {
		$players = array( $players[0] );
		$n       = 1;
	}
	if ( 'team' === $mode && ( $n < $t['team_min'] || $n > $t['max'] ) ) {
		return ogc_tn_err( $t['team_min'] === $t['max'] ? 'A team has ' . $t['max'] : 'A team has ' . $t['team_min'] . ' to ' . $t['max'], 400, 'players' );
	}
	if ( 'team' === $mode && $t['rule'] && empty( $in['rule'] ) ) {
		return ogc_tn_err( 'Check the rule', 400, 'rule' );
	}
	$team = 'team' === $mode ? mb_substr( trim( sanitize_text_field( (string) ( isset( $in['team'] ) ? $in['team'] : '' ) ) ), 0, 40 ) : '';
	$phone = trim( sanitize_text_field( (string) ( isset( $in['phone'] ) ? $in['phone'] : '' ) ) );
	$digits = preg_replace( '/\D/', '', $phone );
	if ( $phone_optional && '' === $phone ) {
		$digits = '0000000';
	}
	if ( strlen( $digits ) < 7 || strlen( $digits ) > 15 || mb_strlen( $phone ) > 24 ) {
		return ogc_tn_err( 'A phone number', 400, 'phone' );
	}
	$mates = array();
	// At most the team's other places, and never more than three (polish: eleven addresses made it a relay).
	foreach ( array_slice( (array) ( isset( $in['mates'] ) ? $in['mates'] : array() ), 0, max( 0, min( 3, (int) $t['max'] - 1 ) ) ) as $e ) {
		$e = strtolower( trim( sanitize_text_field( is_scalar( $e ) ? (string) $e : '' ) ) );
		if ( '' === $e ) {
			continue;
		}
		if ( ! is_email( $e ) ) {
			return ogc_tn_err( 'Not an email', 400, 'mates' );
		}
		$mates[] = $e;
	}
	// The same person on another team in this tournament: said, never refused. Only to the Young Folks
	// committee and the COA, who see the list anyway: a family signing up learns nothing of other teams'
	// players (review, Oct 11: anyone could probe which minors entered).
	$id    = $existing ? (int) $existing['id'] : 0;
	$sees  = function_exists( 'ogc_guard_screen' ) ? ogc_guard_screen( (int) $Y['year'], 'yf-teams' ) : ogc_is_member( $Y['year'] );
	foreach ( $sees ? ogc_tn_teams( $Y['year'] ) : array() as $r ) {
		if ( (int) $r['id'] === $id || ( isset( $r['data']['tid'] ) ? $r['data']['tid'] : '' ) !== $t['id'] ) {
			continue;
		}
		foreach ( (array) ( isset( $r['data']['players'] ) ? $r['data']['players'] : array() ) as $q ) {
			if ( isset( $seen[ ogc_tn_norm( $q ) ] ) ) {
				$warn[] = ogc_tn_first_l( $q ) . ' · Already on a team';
			}
		}
	}
	return array(
		'tid'       => $t['id'],
		'mode'      => $mode,
		'team'      => $team,
		'players'   => $players,
		'phone'     => $phone,
		'mates'     => array_values( array_unique( $mates ) ),
		'rule'      => 'team' === $mode && $t['rule'] ? true : false,
		'for_other' => ! empty( $in['for_other'] ),
	);
}

/* ================================================================== the routes */

add_action( 'rest_api_init', function () {
	$Y  = '(?P<year>\d{4})';
	$ID = '(?P<id>\d+)';
	$any      = function ( WP_REST_Request $q ) { return ogc_valid_year( $q['year'] ) ? true : ogc_tn_err( 'No such year', 404 ); };
	$signedin = function ( WP_REST_Request $q ) { return is_user_logged_in() && ogc_current_email() ? true : ogc_rest_denied( 'Sign in first.' ); };
	$member   = function ( WP_REST_Request $q ) { return ogc_valid_year( $q['year'] ) && ogc_is_member( $q['year'] ) ? true : ogc_rest_denied(); };
	$team     = function ( WP_REST_Request $q ) {
		$r = ogc_record_get( (int) $q['id'] );
		if ( ! $r || 'teams' !== $r['kind'] ) {
			return ogc_tn_err( 'Not found', 404 );
		}
		if ( ogc_is_member( $r['year'] ) || ( ogc_current_email() && $r['email'] === ogc_current_email() ) ) {
			return true;
		}
		return is_user_logged_in() ? ogc_tn_err( 'Not found', 404 ) : ogc_rest_denied( 'Sign in first.' );
	};
	$recmember = function ( WP_REST_Request $q ) {
		$r = ogc_record_get( (int) $q['id'] );
		return $r && 'teams' === $r['kind'] && ogc_is_member( $r['year'] ) ? true : ogc_rest_denied();
	};
	register_rest_route( OGC_NS, "/tn/$Y", array( 'methods' => 'GET', 'callback' => 'ogc_tn_rest_get', 'permission_callback' => $any ) );
	register_rest_route( OGC_NS, "/tn/$Y/teams", array(
		array( 'methods' => 'POST', 'callback' => 'ogc_tn_rest_create', 'permission_callback' => $signedin ),
		array( 'methods' => 'GET', 'callback' => 'ogc_tn_rest_list', 'permission_callback' => $member ),
	) );
	register_rest_route( OGC_NS, "/tn/r/$ID", array(
		array( 'methods' => 'PUT', 'callback' => 'ogc_tn_rest_update', 'permission_callback' => $team ),
		array( 'methods' => 'DELETE', 'callback' => 'ogc_tn_rest_withdraw', 'permission_callback' => $team ),
	) );
	register_rest_route( OGC_NS, "/tn/r/$ID/restore", array( 'methods' => 'POST', 'callback' => 'ogc_tn_rest_restore', 'permission_callback' => $team ) );
	register_rest_route( OGC_NS, "/tn/r/$ID/flag", array( 'methods' => 'PATCH', 'callback' => 'ogc_tn_rest_flag', 'permission_callback' => $recmember ) );
	register_rest_route( OGC_NS, "/tn/$Y/add", array( 'methods' => 'POST', 'callback' => 'ogc_tn_rest_add', 'permission_callback' => $member ) );
	register_rest_route( OGC_NS, "/tn/$Y/message", array( 'methods' => 'POST', 'callback' => 'ogc_tn_rest_message', 'permission_callback' => $member ) );
} );

function ogc_tn_rest_get( WP_REST_Request $req ) {
	$y      = (int) $req['year'];
	if ( ! ogc_year_get( $y ) ) {
		return ogc_tn_err( 'No such year', 404 );
	}
	if ( function_exists( 'ogc_lst_clear_due' ) && ogc_lst_clear_due( $y ) ) {
		ogc_lst_clear_year( $y );
	}
	$now    = ogc_tn_now( $y, $req );
	$member = ogc_is_member( $y );
	$draft  = $member && $req->get_param( 'preview' );
	$Y      = ogc_tn_year( $y, $now, $draft );
	$teams  = ogc_tn_teams( $y );
	$me     = ogc_current_email();
	$mine   = array();
	if ( $me ) {
		$own = ogc_records( $y, 'teams', $me );
		if ( function_exists( 'ogc_linked_records' ) ) {
			$own = array_merge( $own, ogc_linked_records( $y, 'teams', $me ) );
		}
		foreach ( $own as $r ) {
			if ( empty( $r['data']['cleared'] ) && 'removed' !== ( isset( $r['data']['status'] ) ? $r['data']['status'] : '' ) && 'withdrawn' !== ( isset( $r['data']['status'] ) ? $r['data']['status'] : '' ) ) {
				$mine[ $r['id'] ] = ogc_tn_mine_out( $r, $Y, $now );
			}
		}
	}
	$show = $Y['posted'] || $draft;
	$list = array();
	foreach ( $show ? $Y['list'] : array() as $t ) {
		$c     = ogc_tn_counts( $teams, $t['id'] );
		$state = ogc_tn_state( $Y, $t, $now, $c['teams'] + $c['alone'] );
		$list[] = array(
			'id'        => $t['id'],
			'name'      => $t['name'],
			'items'     => $t['items'],
			'min'       => $t['min'],
			'max'       => $t['max'],
			'solo'      => $t['solo'],
			'team_min'  => $t['team_min'],
			'rule'      => $t['rule'],
			'note'      => $t['note'],
			'opens'     => $t['opens'],
			'closes'    => $t['closes'],
			'state'     => $state,
			// Counts only, and only once there are some and sign-ups have opened.
			'counts'    => 'soon' === $state || ! $Y['online'] ? null : $c,
			'max_teams' => $t['max_teams'],
			'close_set' => $member ? $t['close_set'] : true,
			'sample'    => $member ? $t['sample'] : false,
		);
	}
	// Same time as another: said only while both are open.
	foreach ( $list as $i => $a ) {
		$list[ $i ]['clash'] = array();
		foreach ( $list as $b ) {
			if ( $a['id'] !== $b['id'] && 'closed' !== $a['state'] && 'closed' !== $b['state'] && ogc_tn_overlap( $a, $b ) ) {
				$list[ $i ]['clash'][] = array( 'id' => $b['id'], 'name' => $b['name'] );
			}
		}
	}
	return rest_ensure_response( array(
		'year'    => $y,
		'start'   => $Y['start'],
		'end'     => $Y['end'],
		'venue'   => $Y['venue'],
		'city'    => $Y['city'],
		'tz'      => $Y['tz'],
		'posted'  => $Y['posted'],
		'draft'   => $draft && ! $Y['posted'],
		'online'  => $Y['online'],
		'over'    => $Y['over'],
		'how'     => $Y['how'],
		'owner'   => $member ? $Y['owner'] : '',
		'now'     => $now,
		'member'  => $member,
		'me'      => $me ? array( 'email' => $me, 'name' => wp_get_current_user()->display_name ) : null,
		'list'    => $list,
		'mine'    => array_values( $mine ),
	) );
}

function ogc_tn_rest_create( WP_REST_Request $req ) {
	$y   = (int) $req['year'];
	$me  = ogc_current_email();
	$now = ogc_tn_now( $y, $req );
	$Y   = ogc_tn_year( $y, $now );
	$in  = (array) $req->get_json_params();
	$t   = ogc_tn_find( $Y, (string) ( isset( $in['tid'] ) ? $in['tid'] : '' ) );
	if ( ! $t || ! $Y['posted'] ) {
		return ogc_tn_err( 'Not posted', 404 );
	}
	if ( ! $Y['online'] ) {
		return ogc_tn_err( 'Not on the site', 403 );
	}
	$state = ogc_tn_state( $Y, $t, $now, ogc_tn_count_all( $y, $t['id'] ) );
	if ( 'soon' === $state ) {
		return ogc_tn_err( 'Opens ' . date_i18n( 'M j', strtotime( $t['opens'] . ' 12:00:00' ) ), 409 );
	}
	if ( 'closed' === $state ) {
		return ogc_tn_err( 'Closed', 409 );
	}
	if ( 'full' === $state ) {
		return ogc_tn_err( 'Full', 409 );
	}
	// A limit per person and per address (jokesters: Advisors, Oct 9). Only sign-ups that went in count,
	// so someone fixing a refused form isn't locked out.
	$ip = 'tn:ip:' . ( function_exists( 'ogc_client_ip' ) ? ogc_client_ip() : '' );
	if ( function_exists( 'ogc_throttle' ) && ( ogc_throttle( 'tn:e:' . $me, 10, HOUR_IN_SECONDS, false ) || ogc_throttle( $ip, 30, HOUR_IN_SECONDS, false ) ) ) {
		return ogc_tn_err( 'Too many · Try later', 429 );
	}
	$warn = array();
	$data = ogc_tn_clean( $Y, $t, $in, null, $warn );
	if ( is_wp_error( $data ) ) {
		return $data;
	}
	// One sign-up per person per tournament (for someone else: up to four).
	$same = array_filter( ogc_tn_teams( $y ), function ( $r ) use ( $me, $t ) {
		return $r['email'] === $me && ( isset( $r['data']['tid'] ) ? $r['data']['tid'] : '' ) === $t['id'];
	} );
	$mineself = array_filter( $same, function ( $r ) { return empty( $r['data']['for_other'] ); } );
	if ( ( ! $data['for_other'] && $mineself ) || count( $same ) >= 4 ) {
		$r = reset( $same );
		return ogc_tn_err( 'Already on ' . ( ! empty( $r['data']['team'] ) ? $r['data']['team'] : 'a team' ), 409 );
	}
	$data = array_merge( $data, array( 'email' => $me, 'status' => 'active', 'at' => ogc_now(), 'late' => false, 'by' => 'web' ) );
	$id   = ogc_record_insert( $y, 'teams', $data, $me, false, 'web' );
	if ( ! $id ) {
		return ogc_tn_err( 'Not saved · Retry', 500 );
	}
	if ( function_exists( 'ogc_throttle' ) ) {
		ogc_throttle( 'tn:e:' . $me, 10, HOUR_IN_SECONDS );
		ogc_throttle( $ip, 30, HOUR_IN_SECONDS );
	}
	foreach ( $data['mates'] as $e ) {
		if ( function_exists( 'ogc_record_link_add' ) && $e !== $me ) {
			ogc_record_link_add( $id, $e, 'parent' );
		}
	}
	ogc_log( 'team_add', $y, 'teams', array( 'id' => $id, 'tid' => $t['id'] ) );
	// Only the signer is emailed: teammates see the team in their own Your sign-ups (the link above),
	// so a sign-up never sends the church's email, with a typed team name, to typed addresses.
	ogc_tn_mail( 'team_signed_up', $y, $t, $data, array( $me ) );
	$rec = ogc_record_get( $id );
	return new WP_REST_Response( array( 'item' => ogc_tn_mine_out( $rec, $Y, $now ), 'warn' => array_values( array_unique( $warn ) ) ), 201 );
}

function ogc_tn_count_all( $y, $tid ) {
	$c = ogc_tn_counts( ogc_tn_teams( $y ), $tid );
	return $c['teams'] + $c['alone'];
}

function ogc_tn_mail( $kind, $y, $t, $data, $to ) {
	if ( ! function_exists( 'ogc_mail_send_kind' ) ) {
		return;
	}
	$it = $t['items'] ? $t['items'][0] : null;
	foreach ( array_unique( array_filter( $to ) ) as $e ) {
		ogc_mail_send_kind( $kind, $e, array(
			'year'  => $y,
			'title' => $t['name'],
			'team'  => $data['team'] ? $data['team'] : implode( ', ', array_map( 'ogc_tn_first_l', $data['players'] ) ),
			'when'  => $it ? date_i18n( 'D, M j', strtotime( $it['date'] . ' 12:00:00' ) ) . ', ' . $it['when'] : '',
			'place' => $it ? $it['place'] : '',
			'url'   => ogc_url( 'tournaments', array( 'year' => $y, 'view' => 'mine' ) ),
		), array( 'year' => $y ) );
	}
}

function ogc_tn_rest_update( WP_REST_Request $req ) {
	$rec    = ogc_record_get( (int) $req['id'] );
	$y      = (int) $rec['year'];
	$member = ogc_is_member( $y );
	$now    = ogc_tn_now( $y, $req );
	$Y      = ogc_tn_year( $y, $now, $member );
	$t      = ogc_tn_find( $Y, isset( $rec['data']['tid'] ) ? $rec['data']['tid'] : '' );
	if ( ! $t ) {
		return ogc_tn_err( 'Not found', 404 );
	}
	if ( ! $member && ( 'closed' === ogc_tn_state( $Y, $t, $now, 0 ) || 'active' !== ( isset( $rec['data']['status'] ) ? $rec['data']['status'] : 'active' ) ) ) {
		return ogc_tn_err( 'Closed · Changes at the tournament', 409 );
	}
	$warn = array();
	$in   = (array) $req->get_json_params();
	$data = ogc_tn_clean( $Y, $t, $in, $rec, $warn );
	if ( is_wp_error( $data ) ) {
		return $data;
	}
	$data = array_merge( $rec['data'], $data, array( 'changed_at' => ogc_now() ) );
	ogc_record_update( $rec['id'], $data, $rec['email'] );
	foreach ( $data['mates'] as $e ) {
		if ( function_exists( 'ogc_record_link_add' ) && $e !== $rec['email'] ) {
			ogc_record_link_add( $rec['id'], $e, 'parent' );
		}
	}
	ogc_log( 'team_set', $y, 'teams', array( 'id' => $rec['id'] ) );
	return rest_ensure_response( array( 'item' => ogc_tn_mine_out( ogc_record_get( $rec['id'] ), $Y, $now ), 'warn' => array_values( array_unique( $warn ) ) ) );
}

/** Withdraw (the signer) or Remove (a member): kept, marked, and undoable for a while. */
function ogc_tn_rest_withdraw( WP_REST_Request $req ) {
	$rec    = ogc_record_get( (int) $req['id'] );
	$y      = (int) $rec['year'];
	$member = ogc_is_member( $y );
	$now    = ogc_tn_now( $y, $req );
	$Y      = ogc_tn_year( $y, $now, true );
	$t      = ogc_tn_find( $Y, isset( $rec['data']['tid'] ) ? $rec['data']['tid'] : '' );
	$own    = $rec['email'] === ogc_current_email();
	if ( ! $member && ( ! $t || 'closed' === ogc_tn_state( $Y, $t, $now, 0 ) ) ) {
		return ogc_tn_err( 'Closed · Changes at the tournament', 409 );
	}
	$d           = $rec['data'];
	$d['status'] = $own ? 'withdrawn' : 'removed';
	$d['gone_at'] = ogc_now();
	$d['gone_by'] = get_current_user_id();
	ogc_record_update( $rec['id'], $d, $rec['email'] );
	ogc_log( 'team_' . $d['status'], $y, 'teams', array( 'id' => $rec['id'] ) );
	// Teammates who gave an email are told.
	if ( $t && function_exists( 'ogc_send_mail' ) ) {
		foreach ( (array) ( isset( $d['mates'] ) ? $d['mates'] : array() ) as $e ) {
			ogc_send_mail( $e, 'Withdrawn · ' . $t['name'], ( $d['team'] ? $d['team'] : 'The team' ) . ' is no longer signed up for ' . $t['name'] . '.', array( 'kind' => 'team_withdrawn', 'year' => $y ) );
		}
	}
	return rest_ensure_response( array( 'ok' => true, 'status' => $d['status'], 'say' => ( 'removed' === $d['status'] ? 'Removed' : 'Withdrawn' ) . ' · ' . ( $t ? $t['name'] : '' ) ) );
}

function ogc_tn_rest_restore( WP_REST_Request $req ) {
	$rec    = ogc_record_get( (int) $req['id'] );
	$member = ogc_is_member( $rec['year'] );
	$d      = $rec['data'];
	if ( ! in_array( isset( $d['status'] ) ? $d['status'] : '', array( 'withdrawn', 'removed' ), true ) ) {
		return ogc_tn_err( 'Nothing to undo', 409 );
	}
	if ( ! $member && ( (int) $d['gone_by'] !== get_current_user_id() || time() - strtotime( $d['gone_at'] . ' UTC' ) > 15 * MINUTE_IN_SECONDS ) ) {
		return ogc_tn_err( 'Can’t undo', 409 );
	}
	$d['status'] = 'active';
	unset( $d['gone_at'], $d['gone_by'] );
	ogc_record_update( $rec['id'], $d, $rec['email'] );
	ogc_log( 'team_restore', $rec['year'], 'teams', array( 'id' => $rec['id'] ) );
	return rest_ensure_response( array( 'ok' => true, 'say' => 'Undone' ) );
}

/* ------------------------------------------------------------------ the committee's list */

function ogc_tn_rest_list( WP_REST_Request $req ) {
	$y     = (int) $req['year'];
	if ( function_exists( 'ogc_lst_clear_due' ) && ogc_lst_clear_due( $y ) ) {
		ogc_lst_clear_year( $y );
	}
	$now   = ogc_tn_now( $y, $req );
	$Y     = ogc_tn_year( $y, $now, true );
	$only  = (string) $req->get_param( 'tid' );
	$all   = ogc_tn_teams( $y, true );
	$clear = ogc_lst_state( $y, 'lists_cleared', null );
	// Who's on two teams in a tournament, or on teams at the same time.
	$on = array();
	foreach ( $all as $r ) {
		if ( in_array( isset( $r['data']['status'] ) ? $r['data']['status'] : 'active', array( 'withdrawn', 'removed' ), true ) ) {
			continue;
		}
		foreach ( (array) ( isset( $r['data']['players'] ) ? $r['data']['players'] : array() ) as $p ) {
			$on[ ogc_tn_norm( $p ) ][] = array( 'id' => $r['id'], 'tid' => $r['data']['tid'], 'team' => ! empty( $r['data']['team'] ) ? $r['data']['team'] : ogc_tn_first_l( $r['data']['players'][0] ) );
		}
	}
	$teams = array();
	foreach ( $all as $r ) {
		$d = $r['data'];
		if ( $only && ( isset( $d['tid'] ) ? $d['tid'] : '' ) !== $only ) {
			continue;
		}
		$flags = array();
		$gone  = in_array( isset( $d['status'] ) ? $d['status'] : 'active', array( 'withdrawn', 'removed' ), true );
		foreach ( $gone ? array() : (array) ( isset( $d['players'] ) ? $d['players'] : array() ) as $p ) {
			foreach ( isset( $on[ ogc_tn_norm( $p ) ] ) ? $on[ ogc_tn_norm( $p ) ] : array() as $o ) {
				if ( $o['id'] === $r['id'] ) {
					continue;
				}
				if ( $o['tid'] === $d['tid'] ) {
					$flags[] = ogc_tn_first_l( $p ) . ' · Also on ' . $o['team'];
				} else {
					$a = ogc_tn_find( $Y, $d['tid'] );
					$b = ogc_tn_find( $Y, $o['tid'] );
					if ( $a && $b && ogc_tn_overlap( $a, $b ) ) {
						$flags[] = ogc_tn_first_l( $p ) . ' · Also in ' . $b['name'] . ', same time';
					}
				}
			}
		}
		$teams[] = array(
			'id'      => $r['id'],
			'tid'     => isset( $d['tid'] ) ? $d['tid'] : '',
			'team'    => isset( $d['team'] ) ? $d['team'] : '',
			'players' => array_values( (array) ( isset( $d['players'] ) ? $d['players'] : array() ) ),
			'mode'    => isset( $d['mode'] ) ? $d['mode'] : ( count( (array) ( isset( $d['players'] ) ? $d['players'] : array() ) ) > 1 ? 'team' : 'solo' ),
			'phone'   => isset( $d['phone'] ) ? $d['phone'] : '',
			'email'   => $r['email'],
			'rule'    => ! empty( $d['rule'] ),
			'status'  => isset( $d['status'] ) ? $d['status'] : 'active',
			'late'    => ! empty( $d['late'] ),
			'no_show' => ! empty( $d['no_show'] ),
			'at'      => isset( $d['at'] ) ? $d['at'] : $r['created_at'],
			'gone_at' => isset( $d['gone_at'] ) ? $d['gone_at'] : '',
			'flags'   => array_values( array_unique( $flags ) ),
			'cleared' => ! empty( $d['cleared'] ),
			'size'    => isset( $d['size'] ) ? (int) $d['size'] : 0,
			'sample'  => $r['sample'],
		);
	}
	if ( 'csv' === $req->get_param( 'format' ) ) {
		$most = 1;
		foreach ( $teams as $x ) {
			$most = max( $most, count( $x['players'] ) );
		}
		$names = array();
		foreach ( $Y['list'] as $t ) {
			$names[ $t['id'] ] = $t['name'];
		}
		$rows = array();
		foreach ( $teams as $x ) {
			if ( 'active' !== $x['status'] ) {
				continue;
			}
			$rows[] = array_merge(
				array( isset( $names[ $x['tid'] ] ) ? $names[ $x['tid'] ] : $x['tid'], $x['team'], 'solo' === $x['mode'] ? 'On their own' : 'Team' ),
				array_map( function ( $i ) use ( $x ) { return isset( $x['players'][ $i ] ) ? $x['players'][ $i ] : ''; }, range( 0, $most - 1 ) ),
				array( isset( $x['players'][0] ) ? $x['players'][0] : '', $x['phone'], $x['email'], $x['rule'] ? 'yes' : '', $x['late'] ? 'Late' : '', $x['no_show'] ? 'No-show' : '', ogc_tn_local( $y, $x['at'] ) )
			);
		}
		ogc_log( 'list_download', $y, 'teams', array() );
		return ogc_lst_csv_response( ogc_lst_csv( array_merge( array( 'Tournament', 'Team', 'Kind' ), array_map( function ( $i ) { return 'Player ' . ( $i + 1 ); }, range( 0, $most - 1 ) ), array( 'Captain', 'Phone', 'Email', 'Rule', 'Late', 'No-show', 'Signed up' ) ), $rows ), 'young-folks-' . ( $only ? sanitize_file_name( $only ) : 'teams' ) . '-' . $y . '.csv' );
	}
	$list = array();
	foreach ( $Y['list'] as $t ) {
		$c      = ogc_tn_counts( ogc_tn_teams( $y ), $t['id'] );
		$list[] = array_merge( $t, array( 'state' => ogc_tn_state( $Y, $t, $now, $c['teams'] + $c['alone'] ), 'counts' => $c ) );
	}
	return rest_ensure_response( array(
		'year'    => $y,
		'now'     => $now,
		'posted'  => $Y['posted'],
		'online'  => $Y['online'],
		'how'     => $Y['how'],
		'owner'   => $Y['owner'],
		'over'    => $Y['over'],
		'cleared' => $clear ? $clear['day'] : '',
		'list'    => $list,
		'teams'   => $teams,
	) );
}

function ogc_tn_rest_add( WP_REST_Request $req ) {
	$y    = (int) $req['year'];
	$now  = ogc_tn_now( $y, $req );
	$Y    = ogc_tn_year( $y, $now, true );
	$in   = (array) $req->get_json_params();
	$t    = ogc_tn_find( $Y, (string) ( isset( $in['tid'] ) ? $in['tid'] : '' ) );
	if ( ! $t ) {
		return ogc_tn_err( 'Choose a tournament', 400, 'tid' );
	}
	$in['rule'] = true;   // the committee checks the rule in person
	$warn = array();
	// In person, a phone may not be at hand.
	$data = ogc_tn_clean( $Y, $t, $in, null, $warn, true );
	if ( is_wp_error( $data ) ) {
		return $data;
	}
	$email = strtolower( trim( sanitize_text_field( (string) ( isset( $in['email'] ) ? $in['email'] : '' ) ) ) );
	$email = is_email( $email ) ? $email : '';
	$late  = 'closed' === ogc_tn_state( $Y, $t, $now, 0 );
	$data  = array_merge( $data, array( 'email' => $email, 'status' => 'active', 'at' => ogc_now(), 'late' => $late, 'by' => 'committee' ) );
	$id    = ogc_record_insert( $y, 'teams', $data, $email, false, 'committee' );
	ogc_log( 'team_add', $y, 'teams', array( 'id' => $id, 'tid' => $t['id'], 'by' => 'committee' ) );
	return new WP_REST_Response( array( 'ok' => true, 'id' => $id, 'warn' => $warn, 'say' => 'Added · ' . $t['name'] ), 201 );
}

function ogc_tn_rest_flag( WP_REST_Request $req ) {
	$rec = ogc_record_get( (int) $req['id'] );
	$d   = $rec['data'];
	$d['no_show'] = (bool) $req->get_param( 'no_show' );
	ogc_record_update( $rec['id'], $d, $rec['email'] );
	ogc_log( 'team_flag', $rec['year'], 'teams', array( 'id' => $rec['id'] ) );
	return rest_ensure_response( array( 'ok' => true ) );
}

/** One email to every team of a tournament (or all): weather, a moved start. Preview first. */
function ogc_tn_rest_message( WP_REST_Request $req ) {
	$y    = (int) $req['year'];
	$tid  = (string) $req->get_param( 'tid' );
	$subj = mb_substr( trim( sanitize_text_field( (string) $req->get_param( 'subject' ) ) ), 0, 120 );
	$body = mb_substr( trim( sanitize_textarea_field( (string) $req->get_param( 'body' ) ) ), 0, 3000 );
	$to   = array();
	foreach ( ogc_tn_teams( $y ) as $r ) {
		if ( $tid && ( isset( $r['data']['tid'] ) ? $r['data']['tid'] : '' ) !== $tid ) {
			continue;
		}
		foreach ( array_merge( array( $r['email'] ), (array) ( isset( $r['data']['mates'] ) ? $r['data']['mates'] : array() ) ) as $e ) {
			if ( is_email( $e ) ) {
				$to[ strtolower( $e ) ] = true;
			}
		}
	}
	$to = array_keys( $to );
	if ( $req->get_param( 'preview' ) ) {
		return rest_ensure_response( array( 'count' => count( $to ) ) );
	}
	if ( '' === $subj || '' === $body ) {
		return ogc_tn_err( '' === $subj ? 'Add a subject' : 'Add a message', 400, '' === $subj ? 'subject' : 'body' );
	}
	if ( ! $to ) {
		return ogc_tn_err( 'No one to send to', 400 );
	}
	$s    = ogc_lst_kv( $y, 'settings' );
	$from = ! empty( $s['owner_youngfolks'] ) ? $s['owner_youngfolks'] : 'Young Folks tournaments';
	$Y    = ogc_tn_year( $y, ogc_tn_now( $y, $req ), true );
	$t    = $tid ? ogc_tn_find( $Y, $tid ) : null;
	$items = array();
	foreach ( $to as $e ) {
		$m       = function_exists( 'ogc_mail_template' ) ? ogc_mail_template( 'message', array( 'year' => $y, 'subject' => $subj, 'from' => $from, 'about' => $t ? $t['name'] : 'Tournaments', 'body' => $body, 'link' => ogc_url( 'tournaments', array( 'year' => $y, 'view' => 'mine' ) ) ) ) : array( 'subject' => $subj, 'html' => $body, 'text' => $body );
		$items[] = array( $e, $m['subject'], $m['html'], array( 'kind' => 'message', 'year' => $y, 'text' => $m['text'], 'reply_to' => ogc_current_email() ) );
	}
	if ( function_exists( 'ogc_send_mail_many' ) ) {
		ogc_send_mail_many( $items );
	}
	ogc_log( 'team_message', $y, 'teams', array( 'n' => count( $to ), 'tid' => $tid ) );
	return rest_ensure_response( array( 'ok' => true, 'say' => 'Sent · ' . count( $to ) . ' ' . ( 1 === count( $to ) ? 'email' : 'emails' ) ) );
}

/* ================================================================== the year's record */

// When a year's people are cleared, the tournaments stay as counts.
add_filter( 'ogc_lists_record', function ( $rec, $year ) {
	$Y   = ogc_tn_year( $year, ogc_lst_now( $year ), true );
	$all = ogc_tn_teams( $year );
	$out = array();
	foreach ( $Y['list'] as $t ) {
		$out[] = array_merge( array( 'id' => $t['id'], 'name' => $t['name'] ), ogc_tn_counts( $all, $t['id'] ) );
	}
	$rec['tournaments'] = $out;
	return $rec;
}, 10, 2 );

// Your sign-ups (register area) reads a person's teams from the shared records: a team they withdrew,
// or one the committee removed, isn't theirs any more.
add_filter( 'ogc_records_mine', function ( $list, $year, $kind ) {
	if ( 'teams' !== $kind ) {
		return $list;
	}
	return array_values( array_filter( (array) $list, function ( $r ) {
		return ! in_array( isset( $r['data']['status'] ) ? $r['data']['status'] : 'active', array( 'withdrawn', 'removed' ), true ) && empty( $r['data']['cleared'] );
	} ) );
}, 30, 3 );
