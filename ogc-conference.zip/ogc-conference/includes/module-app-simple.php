<?php
/**
 * Simple mode (Oct 22, 2026; Michael: "strip down and simplify the back end… start with a view that
 * essentially is like here's how you get the information onto the website. And don't try to be an entire
 * project management system."). For 2027 the app shows only how the year's information gets onto the
 * website and how the lists get out; everything else stays in the code, hidden, for 2028.
 *
 *   ogc_app_simple()                   the switch: on unless turned off (below)
 *   ogc_app_simple_hidden( $v )        the screens simple mode hides from this viewer
 *   ogc_app_simple_parts( $y, $v )     Home's checklist: the year's parts and where each stands
 *   ogc_app_simple_lists( $y, $v )     Home's "Get it out": the lists that matter now, with their counts
 *   ogc_app_simple_page( $y, $k, $v )  a committee's page: Put it on the website · Get it out · Who's on it
 *   GET app/{y}/simple[?c=]            Home's payload, or a committee's page
 *
 * The switch, in order:
 *   - the constant OGC_APP_SIMPLE (wp-config.php: define( 'OGC_APP_SIMPLE', false ); for the full app);
 *   - the option ogc_app_simple ("0" turns it off; absent means on);
 *   - on a local development site only, the cookie ogc_app_simple=0|1 (the tests' way to look at both
 *     without writing to the site).
 * Simple mode changes what the app shows, never what a route allows: every screen's data answers as it
 * did (ogc_app_can_see is unchanged), so nothing underneath stops working and turning it off brings the
 * whole app back as it was.
 */

defined( 'ABSPATH' ) || exit;

/** Is simple mode on? (Default: yes.) */
function ogc_app_simple() {
	if ( isset( $GLOBALS['ogc_app_simple_memo'] ) ) {
		return $GLOBALS['ogc_app_simple_memo'];
	}
	if ( defined( 'OGC_APP_SIMPLE' ) ) {
		$on = (bool) OGC_APP_SIMPLE;
	} else {
		$opt = get_option( 'ogc_app_simple', '1' );
		$on  = ! in_array( (string) $opt, array( '0', 'no', 'off', '' ), true );
		// A local site's tests look at both modes without changing the site's data.
		if ( defined( 'OGC_DEV' ) && OGC_DEV && function_exists( 'ogc_is_local_host' ) && ogc_is_local_host() && isset( $_COOKIE['ogc_app_simple'] ) ) {
			$on = '0' !== (string) sanitize_key( wp_unslash( $_COOKIE['ogc_app_simple'] ) );
		}
	}
	return $GLOBALS['ogc_app_simple_memo'] = (bool) apply_filters( 'ogc_app_simple', $on );
}

/* ================================================================== what it hides */

/**
 * The screens simple mode leaves out of this viewer's app (their sidebar, ⌘K, and every door to them).
 * Tasks, the requests round (Intake), Campus, the call-in screen (its line is on Dates and place), Privacy
 * and Email for everyone; Money for anyone who doesn't handle money; a committee's Requests unless it has
 * packet or Help text to keep (then it's "Packet and Help").
 */
function ogc_app_simple_hidden( $v ) {
	if ( ! ogc_app_simple() ) {
		return array();
	}
	$key = (int) $v['year'] . '|' . ( $v['coa'] ? 'c' : '' ) . ( $v['webmaster'] ? 'w' : '' ) . '|' . implode( ',', (array) $v['committees'] ) . '|' . $v['as'];
	if ( isset( $GLOBALS['ogc_app_simple_hid'][ $key ] ) ) {
		return $GLOBALS['ogc_app_simple_hid'][ $key ];
	}
	$hide = array( 'tasks', 'intake', 'campus', 'callin', 'privacy', 'email' );
	if ( ! ogc_app_simple_money( $v ) ) {
		$hide[] = 'money';
	}
	// The webmasters' app is Years and Access: no Committees board (their See as opens a committee's page).
	if ( $v['webmaster'] && ! $v['coa'] && ! $v['committees'] ) {
		$hide[] = 'committees';
	}
	if ( ! $v['coa'] ) {
		$any = false;
		foreach ( (array) $v['committees'] as $k ) {
			$any = $any || ogc_app_simple_packet_items( (int) $v['year'], $k );
		}
		if ( ! $any ) {
			$hide[] = 'requests';
		}
	}
	return $GLOBALS['ogc_app_simple_hid'][ $key ] = $hide;
}

/** Does simple mode hide this screen from this viewer? */
function ogc_app_simple_hides( $v, $id ) {
	return in_array( (string) $id, ogc_app_simple_hidden( $v ), true );
}

/** Money is for whoever handles money (the person themselves, never someone seeing as the COA). */
function ogc_app_simple_money( $v ) {
	if ( empty( $v['coa'] ) || ! empty( $v['as'] ) ) {
		return false;
	}
	return function_exists( 'ogc_member_handles_money' ) && ogc_member_handles_money( (int) $v['year'], ogc_current_email() );
}

/** A committee's packet parts and Help cards (the round's owners table): how many of each. */
function ogc_app_simple_packet_items( $year, $ckey ) {
	if ( ! function_exists( 'ogc_round_ready' ) || ! ogc_round_ready() || ! function_exists( 'ogc_round_items' ) ) {
		return null;
	}
	$it = ogc_round_items( (int) $year, (string) $ckey );
	$n  = count( (array) $it['packet'] ) + count( (array) $it['help'] );
	return $n ? array( 'packet' => count( (array) $it['packet'] ), 'help' => count( (array) $it['help'] ) ) : null;
}

/* ================================================================== the year's parts */

/** A setting's date: '' (none or "not yet"), else the day. */
function ogc_app_simple_day( $v ) {
	$v = (string) $v;
	return preg_match( '/^\d{4}-\d{2}-\d{2}$/', $v ) && '9999-12-31' !== $v ? $v : '';
}

/** The Help cards' own day (with the schedule), in words, when it isn't the packet's: "Help published". */
function ogc_app_simple_help_words( $year, $pday, $today ) {
	$s    = function_exists( 'ogc_coa_kv' ) ? ogc_coa_kv( (int) $year, 'settings' ) : array();
	$hday = ogc_app_simple_day( isset( $s['schedule_posted'] ) ? $s['schedule_posted'] : '' );
	if ( '' === $hday || $hday === $pday || ( '' !== $pday && $pday <= $today && $hday <= $today ) ) {
		return '';
	}
	return $hday <= $today ? 'Help published' : 'Help public ' . ogc_app_md( $hday, $year );
}

/** How many rows a year's file has. */
function ogc_app_simple_rows( $year, $name ) {
	$f = function_exists( 'ogc_file_get' ) ? ogc_file_get( (int) $year, $name ) : null;
	return $f ? count( (array) $f['rows'] ) : 0;
}

/** A part's state from its publish date and whether anything is written: published · scheduled · draft · none. */
function ogc_app_simple_state( $day, $has, $today, $blank_public = false ) {
	if ( '' !== $day ) {
		return $day <= $today ? ( $has ? 'published' : 'none' ) : ( $has ? 'scheduled' : 'none' );
	}
	if ( $blank_public && $has ) {
		return 'published';
	}
	return $has ? 'draft' : 'none';
}

/**
 * The year's parts in the order the year uses them, each with where it stands on the website:
 *   key, title, state (published · scheduled · draft · none), words (the state in words), line (what it
 *   holds), go (its screen), act ('Edit' · 'Publish' · 'Announce' · 'Add', or '' when this viewer can't
 *   open it), icon.
 */
function ogc_app_simple_parts( $year, $v ) {
	$y     = (int) $year;
	$today = ogc_app_today( $y );
	$row   = ogc_year_get( $y );
	$s     = function_exists( 'ogc_coa_kv' ) ? ogc_coa_kv( $y, 'settings' ) : array();
	$md    = function ( $d ) use ( $y ) {
		return ogc_app_md( $d, $y );
	};
	$parts = array();

	// Dates and place: on the website once the COA announces the Conference (the page opens on it).
	$dated = $row && ! empty( $row['start'] );
	$ann   = ogc_app_simple_day( $row && isset( $row['coa_announced'] ) ? $row['coa_announced'] : '' );
	$st    = ! $dated ? 'none' : ( '' === $ann ? 'draft' : ( $ann <= $today ? 'published' : 'scheduled' ) );
	$venue = $row && ! empty( $row['venue'] ) ? ogc_app_venue_short( $row['venue'] ) : '';
	$parts[] = array(
		'key'   => 'dates',
		'title' => 'Dates and place',
		'icon'  => 'years',
		'state' => $st,
		'line'  => $dated ? implode( ' · ', array_filter( array( ogc_app_range_words( $row ), $venue ) ) ) : 'No dates yet',
		'when'  => 'scheduled' === $st ? $ann : '',
		'go'    => array( 's' => 'dates' ),
		'draft' => 'Announce',
	);

	// The schedule.
	$n     = ogc_app_simple_rows( $y, 'schedule' );
	$day   = ogc_app_simple_day( isset( $s['schedule_posted'] ) ? $s['schedule_posted'] : '' );
	$st    = ogc_app_simple_state( $day, $n > 0, $today, ! isset( $s['schedule_posted'] ) || '' === (string) $s['schedule_posted'] );
	$parts[] = array(
		'key'   => 'schedule',
		'title' => 'Schedule',
		'icon'  => 'clock',
		'state' => $st,
		'line'  => $n ? ogc_app_plural( $n, 'row' ) : 'No rows yet',
		'when'  => 'scheduled' === $st ? $day : '',
		'go'    => array( 's' => 'schedule' ),
	);

	// Registration: on the website from the day it opens (what the public reads: ogc_pub_reg).
	$reg   = function_exists( 'ogc_coa_kv' ) ? ogc_coa_kv( $y, 'registration' ) : array();
	$pub   = function_exists( 'ogc_pub_reg' ) ? ogc_pub_reg( $y ) : array( 'opens' => isset( $reg['opens'] ) ? $reg['opens'] : '', 'closes' => isset( $reg['closes'] ) ? $reg['closes'] : '' );
	$open  = ogc_app_simple_day( $pub['opens'] );
	$close = ogc_app_simple_day( $pub['closes'] );
	$has   = (bool) array_filter( (array) $reg, function ( $x ) {
		return '' !== trim( (string) $x );
	} );
	$st    = '' !== $open ? ( $open <= $today ? 'published' : 'scheduled' ) : ( $has ? 'draft' : 'none' );
	$line  = 'published' === $st ? ( '' !== $close && $today > $close ? 'Closed ' . $md( $close ) : 'Open' . ( '' !== $close ? ' · Closes ' . $md( $close ) : '' ) )
		: ( 'scheduled' === $st ? 'Opens ' . $md( $open ) . ( '' !== $close ? ' · Closes ' . $md( $close ) : '' ) : ( $has ? 'No opening day' : 'Prices and dates' ) );
	$parts[] = array(
		'key'   => 'registration',
		'title' => 'Registration',
		'icon'  => 'file',
		'state' => $st,
		'line'  => $line,
		'when'  => 'scheduled' === $st ? $open : '',
		'go'    => array( 's' => 'registration' ),
	);

	// Volunteer shifts.
	$n   = ogc_app_simple_rows( $y, 'shifts' );
	$day = ogc_app_simple_day( isset( $s['signups_posted'] ) ? $s['signups_posted'] : '' );
	$st  = ogc_app_simple_state( $day, $n > 0, $today, ! isset( $s['signups_posted'] ) || '' === (string) $s['signups_posted'] );
	$fill = '';
	if ( 'published' === $st && function_exists( 'ogc_shift_counts' ) && function_exists( 'ogc_shift_filled_words' ) ) {
		$fill = ogc_shift_filled_words( ogc_shift_counts( $y ) );
	}
	$parts[] = array(
		'key'   => 'shifts',
		'title' => 'Volunteer shifts',
		'icon'  => 'hand',
		'state' => $st,
		'line'  => '' !== $fill ? $fill : ( $n ? ogc_app_plural( $n, 'shift' ) : 'No shifts yet' ),
		'when'  => 'scheduled' === $st ? $day : '',
		'go'    => array( 's' => 'shifts' ),
	);

	// The packet and Help: the packet's state (its parts go up on packet_posted); the Help cards go up with
	// the schedule (ogc_pub_gates), said in the line when that's a different day.
	$parts_n = function_exists( 'ogc_round_guide_parts' ) ? count( ogc_round_guide_parts( $y ) ) : ogc_app_simple_rows( $y, 'guide' );
	$help_n  = ogc_app_simple_rows( $y, 'help' );
	$pday    = ogc_app_simple_day( isset( $s['packet_posted'] ) ? $s['packet_posted'] : '' );
	$st      = ogc_app_simple_state( $pday, ( $parts_n + $help_n ) > 0, $today, ! isset( $s['packet_posted'] ) || '' === (string) $s['packet_posted'] );
	$parts[] = array(
		'key'   => 'packet',
		'title' => 'Packet and Help',
		'icon'  => 'book',
		'state' => $st,
		'line'  => ( $parts_n + $help_n ) ? implode( ' · ', array_filter( array( $parts_n ? ogc_app_plural( $parts_n, 'part' ) : '', $help_n ? ogc_app_plural( $help_n, 'Help card' ) : '', $help_n ? ogc_app_simple_help_words( $y, $pday, $today ) : '' ) ) ) : 'Nothing written yet',
		'when'  => 'scheduled' === $st ? $pday : '',
		'go'    => array( 's' => 'packet' ),
	);

	// The caterer's menus: shown with the packet.
	$meals = 0;
	$mf    = function_exists( 'ogc_file_get' ) ? ogc_file_get( $y, 'menus' ) : null;
	$seen  = array();
	foreach ( $mf ? (array) $mf['rows'] : array() as $r ) {
		$k = strtolower( trim( ( isset( $r['day'] ) ? $r['day'] : '' ) . '|' . ( isset( $r['meal'] ) ? $r['meal'] : '' ) ) );
		if ( '|' !== $k && ! isset( $seen[ $k ] ) ) {
			$seen[ $k ] = true;
			$meals++;
		}
	}
	$st      = ogc_app_simple_state( $pday, $meals > 0, $today, ! isset( $s['packet_posted'] ) || '' === (string) $s['packet_posted'] );
	$parts[] = array(
		'key'   => 'menus',
		'title' => 'Menus',
		'icon'  => 'plate',
		'state' => $st,
		'line'  => $meals ? ogc_app_plural( $meals, 'meal' ) . ( 'published' === $st ? '' : ' · With the packet' ) : 'From the caterer',
		'when'  => 'scheduled' === $st ? $pday : '',
		'go'    => array( 's' => 'food-menus' ),
	);

	// Words and acts, by one rule: published or scheduled → Edit; written but not public → Publish (the
	// dates: Announce); nothing yet → Add. Only what this viewer may open has an act.
	foreach ( $parts as &$p ) {
		$p['words'] = 'published' === $p['state'] ? 'Published' : ( 'scheduled' === $p['state'] ? 'Scheduled' : ( 'draft' === $p['state'] ? 'Draft' : 'Not started' ) );
		$p['act']   = '';
		$go         = ogc_app_simple_door( $y, $v, $p['key'], $p['go'] );
		$p['go']    = $go;
		if ( $go ) {
			$p['act'] = in_array( $p['state'], array( 'published', 'scheduled' ), true ) ? 'Edit' : ( 'draft' === $p['state'] ? ( isset( $p['draft'] ) ? $p['draft'] : 'Publish' ) : 'Add' );
		}
		unset( $p['draft'] );
	}
	unset( $p );
	return $parts;
}

/**
 * Where a part opens for this viewer, or null. The COA opens every part's screen; a committee opens its
 * own share: its shifts (Shifts filtered to it), its packet or Help text (Packet and Help), Food its
 * menus.
 */
function ogc_app_simple_door( $y, $v, $key, $go ) {
	$open = function ( $id ) use ( $v ) {
		return ogc_app_can_see( $v, $id ) && ! ogc_app_simple_hides( $v, $id );
	};
	if ( $v['coa'] ) {
		return $open( $go['s'] ) ? $go : null;
	}
	$mine = (array) $v['committees'];
	if ( ! $mine ) {
		return null;
	}
	$k = $mine[0];
	if ( 'shifts' === $key && $open( 'shifts' ) ) {
		return array( 's' => 'shifts', 'c' => $k );
	}
	if ( 'packet' === $key && $open( 'requests' ) ) {
		foreach ( $mine as $mk ) {
			if ( ogc_app_simple_packet_items( $y, $mk ) ) {
				return array( 's' => 'requests', 'c' => $mk );
			}
		}
	}
	if ( 'menus' === $key && $open( 'food-menus' ) ) {
		return $go;
	}
	return null;
}

/* ================================================================== the lists */

/** A list's row: its screen, its words and the count it says. */
function ogc_app_simple_list( $id, $title, $line, $go, $icon, $n = null ) {
	return array( 'id' => $id, 'title' => $title, 'line' => (string) $line, 'go' => $go, 'icon' => $icon, 'n' => $n );
}

/**
 * Home's "Get it out": only the lists that matter now (each has something in it), each a door with its
 * count. The COA: registrations, meal counts, Lodging's rooms. A committee: its own lists.
 */
function ogc_app_simple_lists( $year, $v ) {
	$y   = (int) $year;
	$out = array();
	if ( $v['coa'] ) {
		$open = function ( $id ) use ( $v ) {
			return ogc_app_can_see( $v, $id ) && ! ogc_app_simple_hides( $v, $id );
		};
		if ( $open( 'households' ) && function_exists( 'ogc_rec_counts' ) && function_exists( 'ogc_rec_rows' ) ) {
			$c = ogc_rec_counts( ogc_rec_rows( $y ) );
			$n = (int) $c['coming'] + (int) $c['waiting'];
			if ( $n ) {
				// Named and counted as the Households screen it opens names and counts it ("57 coming · 158 people").
				$out[] = ogc_app_simple_list( 'households', 'Households', implode( ' · ', array_filter( array( $c['coming'] ? $c['coming'] . ' coming' : '', $c['people'] ? ogc_app_plural( (int) $c['people'], 'person', 'people' ) : '', $c['waiting'] ? $c['waiting'] . ' waiting' : '' ) ) ), array( 's' => 'households' ), 'house', $n );
			}
		}
		$regs = function_exists( 'ogc_records' ) ? count( ogc_records( $y, 'registrations' ) ) : 0;
		if ( $regs && $open( 'food-meals' ) && function_exists( 'ogc_appc_work_line' ) ) {
			$out[] = ogc_app_simple_list( 'food-meals', 'Meal counts', ogc_appc_work_line( $y, 'food-meals', 'food' ), array( 's' => 'food-meals' ), 'plate' );
		}
		if ( $regs && $open( 'lod-rooms' ) && function_exists( 'ogc_appc_work_line' ) ) {
			$line = ogc_appc_work_line( $y, 'lod-rooms', 'lodging' );
			if ( '' !== $line ) {
				$out[] = ogc_app_simple_list( 'lod-rooms', 'Lodging’s rooms', $line, array( 's' => 'lod-rooms' ), 'bed' );
			}
		}
		return $out;
	}
	$today = ogc_app_today( $y );
	foreach ( (array) $v['committees'] as $k ) {
		foreach ( ogc_app_simple_page_rows( $y, $k, $v )['out'] as $r ) {
			// Only what's in season and says something.
			if ( '' !== $r['line'] && ( '' === $r['on'] || $r['on'] <= $today ) ) {
				$out[] = ogc_app_simple_list( $r['id'], $r['title'], $r['line'], $r['go'], $r['icon'] );
			}
		}
	}
	return $out;
}

/* ================================================================== a committee's page */

/** Which of a committee's screens put something on the website (the rest are lists to get out). */
function ogc_app_simple_put_ids() {
	return array( 'shifts', 'requests', 'food-menus' );
}

/**
 * A committee's two halves, from its Work rows (ogc_app_work_rows: the same lines and needs the full page
 * shows), with the screens simple mode hides left out. Each row: id, title, line, on, done, go, icon,
 * need ({ button, go } or null).
 */
function ogc_app_simple_page_rows( $year, $ckey, $v ) {
	$y   = (int) $year;
	$key = $y . '|' . $ckey . '|' . ( $v['coa'] ? 'c' : '' ) . '|' . $v['as'];
	if ( isset( $GLOBALS['ogc_app_simple_rows'][ $key ] ) ) {
		return $GLOBALS['ogc_app_simple_rows'][ $key ];
	}
	$put  = array();
	$out  = array();
	$hide = ogc_app_simple_hidden( $v );
	$icon = array( 'shifts' => 'hand', 'requests' => 'book', 'food-menus' => 'note', 'lod-households' => 'house', 'lod-rooms' => 'bed', 'lod-yf' => 'bunk', 'lod-campers' => 'caravan', 'lod-counts' => 'report', 'lod-checkin' => 'key', 'food-meals' => 'plate', 'preteens-list' => 'child', 'communion-list' => 'cup', 'nursery-list' => 'report', 'yf-teams' => 'flag', 'yf-halls' => 'bunk', 'services' => 'clock', 'households' => 'house', 'money' => 'report' );
	$rows = function_exists( 'ogc_app_work_rows' ) ? ogc_app_work_rows( $y, $ckey, $v ) : array();
	$seen = array();
	foreach ( $rows as $r ) {
		$id = (string) $r['id'];
		if ( isset( $seen[ $id ] ) || in_array( $id, $hide, true ) || in_array( $id, array( 'intake', 'campus', 'callin', 'tasks', 'privacy', 'members', 'lod-import' ), true ) ) {
			continue;
		}
		$seen[ $id ] = true;
		if ( 'coa' === $ckey ) {
			continue; // The COA's page is drawn from the year's parts (below).
		}
		$go   = array( 's' => $id, 'c' => '' !== (string) $r['c'] ? (string) $r['c'] : ( in_array( $id, array( 'shifts', 'requests' ), true ) ? $ckey : '' ) );
		$need = ! empty( $r['need'] ) && ! empty( $r['need']['button'] ) && ! empty( $r['need']['go']['s'] ) && ! in_array( $r['need']['go']['s'], $hide, true ) ? array( 'button' => (string) $r['need']['button'], 'go' => (array) $r['need']['go'], 'tone' => (string) $r['need']['tone'], 'words' => (string) $r['need']['words'], 'top' => ! empty( $r['need']['top'] ) ) : null;
		$line = (string) $r['line'];
		if ( 'requests' === $id ) {
			// Its packet or Help text: what's in it and whether it's on the website.
			$items = ogc_app_simple_packet_items( $y, $ckey );
			if ( ! $items ) {
				continue;
			}
			$s    = function_exists( 'ogc_coa_kv' ) ? ogc_coa_kv( $y, 'settings' ) : array();
			$pday = ogc_app_simple_day( isset( $s['packet_posted'] ) ? $s['packet_posted'] : '' );
			$today = ogc_app_today( $y );
			$pub   = '' !== $pday ? ( $pday <= $today ? 'Published' : 'Public ' . ogc_app_md( $pday, $y ) ) : 'Not public yet';
			$hw    = $items['help'] ? ( $items['packet'] ? ogc_app_simple_help_words( $y, $pday, $today ) : ( '' !== ogc_app_simple_help_words( $y, '', $today ) ? ogc_app_simple_help_words( $y, '', $today ) : $pub ) ) : '';
			$hw    = ucfirst( (string) preg_replace( '/^Help /', '', $hw ) );
			$pc    = $items['packet'] ? ogc_app_plural( $items['packet'], 'packet part' ) : '';
			$hc    = $items['help'] ? ogc_app_plural( $items['help'], 'Help card' ) : '';
			// Each count followed by its own day ("3 packet parts · Public May 11 · 3 Help cards · Public Mar 15");
			// one day after both when they share it.
			$line  = implode( ' · ', array_filter( $items['packet'] && '' !== $hw ? array( $pc, $pub, $hc, $hw ) : array( $pc, $hc, $items['packet'] ? $pub : '', $hw ) ) );
			$need = null;
			$r['title'] = 'Packet and Help';
		} elseif ( 'shifts' === $id && '' === $line ) {
			$n = 0;
			$sf = function_exists( 'ogc_file_get' ) ? ogc_file_get( $y, 'shifts' ) : null;
			foreach ( $sf ? (array) $sf['rows'] : array() as $sr ) {
				$n += isset( $sr['committee'] ) && ogc_committee_key( (string) $sr['committee'] ) === $ckey ? 1 : 0;
			}
			$line = $n ? ogc_app_plural( $n, 'shift' ) . ' · Not public yet' : 'No shifts';
		}
		// Never a zero: a committee with no shifts has no shifts row (its Shifts screen still adds one).
		if ( 'shifts' === $id && 'No shifts' === $line ) {
			continue;
		}
		if ( 'lod-yf' === $id && '' === $line && function_exists( 'ogc_lst_fact' ) ) {
			// Young Folks in the halls, as their committee's Halls list counts them.
			$line = (string) ogc_lst_fact( $y, 'halls' )['line'];
		} elseif ( 'lod-campers' === $id && '' === $line && function_exists( 'ogc_lod_households' ) ) {
			$n = 0;
			foreach ( ogc_lod_households( $y ) as $rec ) {
				$d  = (array) $rec['data'];
				$n += 'camper' === ( isset( $d['stay']['type'] ) ? $d['stay']['type'] : '' ) && 'cancelled' !== ( isset( $d['status'] ) ? $d['status'] : '' ) ? 1 : 0;
			}
			$line = $n ? ogc_app_plural( $n, 'camper' ) : '';
		} elseif ( 'food-menus' === $id ) {
			foreach ( ogc_app_simple_parts( $y, $v ) as $p ) {
				if ( 'menus' === $p['key'] ) {
					// "With the packet" says when; the Packet and Help row above carries the day.
					$line = $p['line'];
				}
			}
		}
		$o = array(
			'id'    => $id,
			'title' => 'shifts' === $id ? 'Volunteer shifts' : (string) $r['title'],
			'line'  => $line,
			'on'    => (string) $r['on'],
			'done'  => ! empty( $r['done'] ),
			'go'    => $go,
			'open'  => ! isset( $r['open'] ) || ! empty( $r['open'] ),
			'icon'  => isset( $icon[ $id ] ) ? $icon[ $id ] : 'overview',
			'need'  => $need,
		);
		if ( in_array( $id, ogc_app_simple_put_ids(), true ) ) {
			$put[] = $o;
		} else {
			$out[] = $o;
		}
	}
	// Put it on the website in one order: its shifts, its packet or Help text, its menus.
	$order = array_flip( ogc_app_simple_put_ids() );
	usort( $put, function ( $a, $b ) use ( $order ) {
		return $order[ $a['id'] ] - $order[ $b['id'] ];
	} );
	return $GLOBALS['ogc_app_simple_rows'][ $key ] = array( 'put' => $put, 'out' => $out );
}

/** A committee's page in simple mode: its two halves and who's on it. */
function ogc_app_simple_page( $year, $ckey, $v ) {
	$y = (int) $year;
	$c = ogc_app_committee( $y, $ckey );
	if ( ! $c ) {
		return null;
	}
	$people = array();
	$asked  = 0;
	foreach ( ogc_app_people( $y, $ckey ) as $m ) {
		$name = ogc_app_person_name( $m );
		if ( false !== strpos( $name, '@' ) || false !== strpos( $name, '*' ) ) {
			$asked++;
			continue;
		}
		$people[] = array( 'id' => (int) $m['id'], 'name' => $name, 'head' => (bool) $m['head'], 'you' => (int) $m['id'] === (int) $v['member_id'] );
	}
	if ( 'coa' === $ckey ) {
		$put = array();
		foreach ( ogc_app_simple_parts( $y, $v ) as $p ) {
			$put[] = array( 'id' => $p['key'], 'title' => $p['title'], 'line' => $p['line'], 'state' => $p['state'], 'words' => $p['words'], 'when' => $p['when'], 'go' => $p['go'], 'act' => $p['act'], 'icon' => $p['icon'], 'on' => '', 'done' => 'published' === $p['state'], 'need' => null, 'open' => (bool) $p['go'] );
		}
		$out = array();
		$open = function ( $id ) use ( $v ) {
			return ogc_app_can_see( $v, $id ) && ! ogc_app_simple_hides( $v, $id );
		};
		$opens = function_exists( 'ogc_app_screen_opens' ) ? ogc_app_screen_opens( $y ) : array();
		foreach ( array( 'households' => array( 'Households', 'house' ), 'money' => array( 'Money', 'report' ) ) as $id => $d ) {
			if ( $open( $id ) ) {
				$out[] = array( 'id' => $id, 'title' => $d[0], 'line' => function_exists( 'ogc_app_coa_screen_line' ) ? ogc_app_coa_screen_line( $y, $id ) : '', 'on' => isset( $opens[ $id ] ) ? (string) $opens[ $id ] : '', 'done' => false, 'go' => array( 's' => $id ), 'icon' => $d[1], 'need' => null, 'open' => true );
			}
		}
		$rows = array( 'put' => $put, 'out' => $out );
	} else {
		$rows = ogc_app_simple_page_rows( $y, $ckey, $v );
	}
	return array(
		'key'    => $c['ckey'],
		'name'   => $c['name'],
		'mine'   => ogc_app_on_committee( $v, $ckey ),
		'put'    => $rows['put'],
		'out'    => $rows['out'],
		'people' => $people,
		'asked'  => $asked,
		'today'  => ogc_app_today( $y ),
		'can'    => array( 'members' => $v['coa'] && ! $v['as'] && ogc_app_can_see( $v, 'members' ), 'see_as' => ! $v['as'] && ( $v['coa'] || $v['webmaster'] ) && ! in_array( $ckey, (array) $v['committees'], true ) && ! ( 'coa' === $ckey && $v['coa'] ) ),
	);
}

/* ================================================================== the route */

add_action( 'rest_api_init', function () {
	register_rest_route( OGC_NS, '/app/(?P<year>\d{4})/simple', array(
		array(
			'methods'             => 'GET',
			'callback'            => 'ogc_app_rest_simple',
			'permission_callback' => function ( WP_REST_Request $req ) {
				if ( ! function_exists( 'ogc_app_tables_ready' ) || ! ogc_app_tables_ready() || null === ogc_year_get( (int) $req['year'] ) ) {
					return new WP_Error( 'ogc_not_found', 'Not found.', array( 'status' => 404 ) );
				}
				$c = ogc_committee_key( (string) $req->get_param( 'c' ) );
				return ogc_app_can_see( ogc_app_req_viewer( $req ), '' === $c ? 'home' : 'committees' ) ? true : ogc_rest_denied();
			},
		),
	) );
} );

/**
 * GET app/{y}/simple → Home: { parts, published, next, coming, lists }; ?c=<key> → that committee's page
 * (a committee the viewer isn't on, and isn't the COA's to see: 404).
 */
function ogc_app_rest_simple( WP_REST_Request $req ) {
	$y = (int) $req['year'];
	$v = ogc_app_req_viewer( $req );
	$c = ogc_committee_key( (string) $req->get_param( 'c' ) );
	if ( '' !== $c ) {
		if ( ! ogc_app_on_committee( $v, $c ) ) {
			return new WP_Error( 'ogc_not_found', 'Not found.', array( 'status' => 404 ) );
		}
		$p = ogc_app_simple_page( $y, $c, $v );
		return $p ? rest_ensure_response( $p ) : new WP_Error( 'ogc_not_found', 'Not found.', array( 'status' => 404 ) );
	}
	$parts = ogc_app_simple_parts( $y, $v );
	$pub   = count( array_filter( $parts, function ( $p ) {
		return 'published' === $p['state'];
	} ) );
	// The one filled button: the first part not on its way to the website that this viewer can do.
	$next = null;
	foreach ( $parts as $p ) {
		if ( in_array( $p['state'], array( 'draft', 'none' ), true ) && $p['act'] ) {
			$next = array( 'key' => $p['key'], 'label' => $p['act'] . ' ' . ( 'dates' === $p['key'] ? 'the Conference' : strtolower( $p['title'] ) ), 'go' => $p['go'] );
			break;
		}
	}
	// What goes up next by itself: the soonest scheduled part.
	$coming = null;
	foreach ( $parts as $p ) {
		if ( 'scheduled' === $p['state'] && ( ! $coming || $p['when'] < $coming['when'] ) ) {
			$coming = array( 'title' => $p['title'], 'when' => $p['when'], 'words' => ogc_app_md( $p['when'], $y ) );
		}
	}
	return rest_ensure_response( array(
		'parts'     => $parts,
		'published' => $pub,
		'next'      => $next,
		'coming'    => $coming,
		'lists'     => ogc_app_simple_lists( $y, $v ),
		'today'     => ogc_app_today( $y ),
	) );
}

/* ================================================================== the shell */

// The page's script and styles, after every screen has registered (simple mode wraps Home, a
// committee's page and the packet's title row at draw time; with it off they draw as before).
add_filter( 'ogc_pages', function ( $p ) {
	if ( empty( $p['app'] ) ) {
		return $p;
	}
	$p['app']['scripts'] = array_merge( (array) $p['app']['scripts'], array( 'app/screen-simple.js' ) );
	$p['app']['styles']  = array_merge( (array) $p['app']['styles'], array( 'app/simple.css' ) );
	return $p;
}, 990 );
