<?php
/**
 * Lists for Excel (lists area, Oct 13): every committee's list downloads as a real .xlsx, made here
 * with no library (a workbook is a zip of a few XML files). Each workbook has the list as its first
 * sheet (a header row that stays put, filters on, numbers as numbers) and a sheet named Columns that
 * says what every column holds, so the file explains itself next year to a committee that's new.
 *
 *   ogc_lst_xlsx( $sheets )                  → the file's bytes
 *     $sheets: array( array( 'name' => 'Meal counts', 'cols' => array( label… ), 'widths' => array( n… ),
 *                            'rows' => array( array( cell… )… ) ) … )
 *     A cell that's an int or a float is a number; true is "Yes"; anything else is text (never a
 *     formula: Excel doesn't evaluate inline text, so a typed "=…" stays words).
 *   ogc_lst_columns_sheet( $spec, $about )    the Columns sheet from a list's spec (and its facts)
 *   ogc_lst_xlsx_response( $bytes, $file )    the REST answer: the file as it is, never JSON
 *
 * The columns of each list are fixed in its spec (ogc_lst_spec), the same every year: a column with
 * nothing in it this year is still there, empty, so last year's spreadsheet formulas keep working.
 */

defined( 'ABSPATH' ) || exit;

/** Text as XML wants it: escaped, and without the control characters XML can't hold. */
function ogc_lst_x( $s ) {
	$s = preg_replace( '/[\x00-\x08\x0B\x0C\x0E-\x1F]/', '', (string) $s );
	return htmlspecialchars( $s, ENT_QUOTES | ENT_XML1, 'UTF-8' );
}

/** "A", "B", … "AA" for a 0-based column. */
function ogc_lst_col_letter( $i ) {
	$s = '';
	for ( $n = $i + 1; $n > 0; $n = (int) floor( ( $n - 1 ) / 26 ) ) {
		$s = chr( 65 + ( ( $n - 1 ) % 26 ) ) . $s;
	}
	return $s;
}

/** One worksheet's XML. Row 1 is the header (bold, a rule under it, frozen); the list's own sheet
 * also has Excel's filter on it ('filter' => false leaves it off, as the Columns sheet does). */
function ogc_lst_xlsx_sheet( $sheet ) {
	$cols   = array_values( (array) $sheet['cols'] );
	$rows   = array_values( (array) $sheet['rows'] );
	$widths = isset( $sheet['widths'] ) ? array_values( (array) $sheet['widths'] ) : array();
	$filter = ! isset( $sheet['filter'] ) || $sheet['filter'];
	$all    = array_merge( array( $cols ), $rows );
	$x      = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' . "\n"
		. '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
		. '<sheetViews><sheetView workbookViewId="0"' . ( empty( $sheet['first'] ) ? '' : ' tabSelected="1"' ) . '>'
		. '<pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/><selection pane="bottomLeft" activeCell="A2" sqref="A2"/>'
		. '</sheetView></sheetViews><sheetFormatPr defaultRowHeight="15"/>';
	if ( $cols ) {
		$x .= '<cols>';
		foreach ( $cols as $i => $c ) {
			$w  = isset( $widths[ $i ] ) && $widths[ $i ] ? (float) $widths[ $i ] : max( 8, min( 40, mb_strlen( (string) $c ) + 3 ) );
			$x .= '<col min="' . ( $i + 1 ) . '" max="' . ( $i + 1 ) . '" width="' . $w . '" customWidth="1"/>';
		}
		$x .= '</cols>';
	}
	$x .= '<sheetData>';
	foreach ( $all as $r => $row ) {
		$n  = $r + 1;
		$x .= '<row r="' . $n . '">';
		foreach ( array_values( (array) $row ) as $i => $v ) {
			if ( null === $v || '' === $v || false === $v ) {
				continue;
			}
			$ref = ogc_lst_col_letter( $i ) . $n;
			$s   = 0 === $r ? '1' : '2';
			if ( ( is_int( $v ) || is_float( $v ) ) && $r > 0 ) {
				$x .= '<c r="' . $ref . '" s="' . $s . '"><v>' . ( is_float( $v ) ? rtrim( rtrim( sprintf( '%.4F', $v ), '0' ), '.' ) : $v ) . '</v></c>';
			} else {
				$x .= '<c r="' . $ref . '" t="inlineStr" s="' . $s . '"><is><t xml:space="preserve">' . ogc_lst_x( true === $v ? 'Yes' : $v ) . '</t></is></c>';
			}
		}
		$x .= '</row>';
	}
	$x .= '</sheetData>';
	if ( $filter && $cols ) {
		$x .= '<autoFilter ref="A1:' . ogc_lst_col_letter( count( $cols ) - 1 ) . count( $all ) . '"/>';
	}
	$x .= '<pageMargins left="0.5" right="0.5" top="0.6" bottom="0.6" header="0.3" footer="0.3"/>'
		. '<pageSetup orientation="' . ( count( $cols ) > 6 ? 'landscape' : 'portrait' ) . '"/>'
		. '</worksheet>';
	return $x;
}

/** A sheet's name as Excel allows it: 31 characters, none of []:*?/\ */
function ogc_lst_sheet_name( $s, $taken ) {
	$s = trim( mb_substr( preg_replace( '#[\[\]:*?/\\\\]#', ' ', (string) $s ), 0, 31 ) );
	$s = '' === $s ? 'Sheet' : $s;
	$b = $s;
	for ( $i = 2; in_array( strtolower( $s ), $taken, true ); $i++ ) {
		$s = mb_substr( $b, 0, 28 ) . ' ' . $i;
	}
	return $s;
}

/** The workbook's bytes. */
function ogc_lst_xlsx( $sheets ) {
	$sheets = array_values( $sheets );
	$files  = array();
	$names  = array();
	$ct     = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' . "\n"
		. '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
		. '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
		. '<Default Extension="xml" ContentType="application/xml"/>'
		. '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
		. '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'
		. '<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>'
		. '<Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/>';
	$wb     = '';
	$rels   = '';
	foreach ( $sheets as $i => $s ) {
		$n       = $i + 1;
		$name    = ogc_lst_sheet_name( isset( $s['name'] ) ? $s['name'] : 'Sheet ' . $n, $names );
		$names[] = strtolower( $name );
		$s['first'] = 0 === $i;
		$ct     .= '<Override PartName="/xl/worksheets/sheet' . $n . '.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>';
		$wb     .= '<sheet name="' . ogc_lst_x( $name ) . '" sheetId="' . $n . '" r:id="rId' . $n . '"/>';
		$rels   .= '<Relationship Id="rId' . $n . '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet' . $n . '.xml"/>';
		$files[ 'xl/worksheets/sheet' . $n . '.xml' ] = ogc_lst_xlsx_sheet( $s );
	}
	$ct  .= '</Types>';
	$k    = count( $sheets ) + 1;
	$rels .= '<Relationship Id="rId' . $k . '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>';
	$now = gmdate( 'Y-m-d\TH:i:s\Z' );
	$files = array_merge( array(
		'[Content_Types].xml'        => $ct,
		'_rels/.rels'                => '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' . "\n" . '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/><Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/></Relationships>',
		'docProps/core.xml'          => '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' . "\n" . '<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"><dc:title>' . ogc_lst_x( $sheets ? $sheets[0]['name'] : '' ) . '</dc:title><dc:creator>ogbbc.org Annual Conference</dc:creator><dcterms:created xsi:type="dcterms:W3CDTF">' . $now . '</dcterms:created></cp:coreProperties>',
		'docProps/app.xml'           => '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' . "\n" . '<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties"><Application>ogbbc.org</Application></Properties>',
		'xl/workbook.xml'            => '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' . "\n" . '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><bookViews><workbookView activeTab="0"/></bookViews><sheets>' . $wb . '</sheets></workbook>',
		'xl/_rels/workbook.xml.rels' => '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' . "\n" . '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' . $rels . '</Relationships>',
		// Three looks: 0 plain, 1 the header (bold, a rule under it), 2 a cell (top-aligned, wrapping).
		'xl/styles.xml'              => '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' . "\n" . '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
			. '<fonts count="2"><font><sz val="11"/><name val="Calibri"/><family val="2"/></font><font><b/><sz val="11"/><name val="Calibri"/><family val="2"/></font></fonts>'
			. '<fills count="2"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill></fills>'
			. '<borders count="2"><border><left/><right/><top/><bottom/><diagonal/></border><border><left/><right/><top/><bottom style="thin"><color auto="1"/></bottom><diagonal/></border></borders>'
			. '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
			. '<cellXfs count="3"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>'
			. '<xf numFmtId="0" fontId="1" fillId="0" borderId="1" xfId="0" applyFont="1" applyBorder="1"><alignment vertical="top" wrapText="1"/></xf>'
			. '<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0" applyAlignment="1"><alignment vertical="top" wrapText="1"/></xf></cellXfs>'
			. '<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>',
	), $files );
	return ogc_lst_zip( $files );
}

/** A zip of the given files (name => bytes), deflated when PHP can, else stored. No library needed. */
function ogc_lst_zip( $files ) {
	$data    = '';
	$central = '';
	$n       = 0;
	$t       = getdate();
	$dtime   = ( $t['hours'] << 11 ) | ( $t['minutes'] << 5 ) | (int) floor( $t['seconds'] / 2 );
	$ddate   = ( ( $t['year'] - 1980 ) << 9 ) | ( $t['mon'] << 5 ) | $t['mday'];
	foreach ( $files as $name => $bytes ) {
		$bytes = (string) $bytes;
		$crc   = crc32( $bytes );
		$z     = function_exists( 'gzdeflate' ) ? gzdeflate( $bytes, 6 ) : false;
		$meth  = false === $z ? 0 : 8;
		$body  = false === $z ? $bytes : $z;
		$off   = strlen( $data );
		$head  = pack( 'vvvvvVVVvv', 20, 0x0800, $meth, $dtime, $ddate, $crc, strlen( $body ), strlen( $bytes ), strlen( $name ), 0 );
		$data .= "PK\x03\x04" . $head . $name . $body;
		$central .= "PK\x01\x02" . pack( 'vvvvvvVVVvvvvvVV', 20, 20, 0x0800, $meth, $dtime, $ddate, $crc, strlen( $body ), strlen( $bytes ), strlen( $name ), 0, 0, 0, 0, 0, $off ) . $name;
		$n++;
	}
	return $data . $central . "PK\x05\x06" . pack( 'vvvvVVv', 0, 0, $n, $n, strlen( $central ), strlen( $data ), 0 );
}

/**
 * The Columns sheet: what each column holds, then the list's facts (As of, how many, where from).
 * $spec: array( 'title', 'cols' => array( array( label, what, width ) ) ), $about: array( label => value ).
 */
function ogc_lst_columns_sheet( $spec, $about = array(), $extra = array() ) {
	$rows = array();
	foreach ( $spec['cols'] as $c ) {
		$rows[] = array( $c[0], $c[1] );
	}
	foreach ( $extra as $e ) {
		$rows[] = array( '', '' );
		$rows[] = array( $e['title'], '' );
		foreach ( $e['cols'] as $c ) {
			$rows[] = array( $c[0], $c[1] );
		}
	}
	if ( $about ) {
		$rows[] = array( '', '' );
		foreach ( $about as $k => $v ) {
			$rows[] = array( $k, $v );
		}
	}
	return array( 'name' => 'Columns', 'cols' => array( 'Column', 'What it holds' ), 'widths' => array( 22, 90 ), 'rows' => $rows, 'filter' => false );
}

/** A list's sheet from its spec and rows (cells in the spec's order). */
function ogc_lst_list_sheet( $spec, $rows, $name = '' ) {
	return array(
		'name'   => $name ? $name : $spec['title'],
		'cols'   => array_map( function ( $c ) { return $c[0]; }, $spec['cols'] ),
		'widths' => array_map( function ( $c ) { return isset( $c[2] ) ? $c[2] : 0; }, $spec['cols'] ),
		'rows'   => $rows,
	);
}

function ogc_lst_xlsx_response( $bytes, $file ) {
	$res = new WP_REST_Response( null, 200 );
	$res->header( 'Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' );
	$res->header( 'Content-Disposition', 'attachment; filename="' . str_replace( '"', '', sanitize_file_name( $file ) ) . '"' );
	$res->header( 'Cache-Control', 'no-store' );
	$res->header( 'X-Content-Type-Options', 'nosniff' );
	add_filter( 'rest_pre_serve_request', function ( $served, $result ) use ( $bytes, $res ) {
		if ( $result === $res ) {
			echo $bytes; // phpcs:ignore WordPress.Security.EscapeOutput -- a workbook's bytes, built above.
			return true;
		}
		return $served;
	}, 10, 2 );
	return $res;
}

/** "Mar 3, 2027, 4:20 PM" on the campus's clock: when a list was made. */
function ogc_lst_as_of_long( $year ) {
	$n = ogc_lst_now( $year );
	return date_i18n( 'M j, Y', strtotime( $n['date'] . ' 12:00:00' ) ) . ', ' . ogc_lst_hm( $n['min'] );
}

/** A list's file name: "2027 Meal counts.xlsx", the same every year but the year. */
function ogc_lst_file( $year, $title, $ext = 'xlsx' ) {
	return (int) $year . ' ' . $title . '.' . $ext;
}
