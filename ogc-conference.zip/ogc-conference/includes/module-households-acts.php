<?php
/**
 * A household's acts (Round 5, Oct 17; docs/27-back-end-map/area-households-money 5.8, 5.9, 6): what
 * the COA and Lodging do to one registration, on the server.
 *
 *   Change        the household's own form, "for a household" (register.js): GET reg/r/{id} opens it for
 *                 whoever ogc_reg_may lets in (module-registration-routes.php); the panel gets its address.
 *   Cancel        POST app/{y}/households/cancel {rid, how} → Cancelled (ogc_reg_cancel: rooms freed, the
 *                 check to come not needed, a refund less the gift asked until the refund date); its email
 *                 waits out Undo; {rid, undo} puts it back as it was, unless a room was given since.
 *   Offer place   POST app/{y}/households/offer {rid, how: email|phone, pay_by} → the offer kept on the
 *                 registration (data.offer), the place held (ogc_reg_usage counts it until it lapses or is
 *                 withdrawn: H7), "Offered · Pay by May 12" on the row, the email when by email (after
 *                 Undo's wait); {rid, withdraw: 1}; {rid, undo}.
 *
 * Who: ogc_access( y, 'households' ) (the COA, Lodging, the committee handed Households), the real viewer,
 * never while seeing as; a previewed date only in the shared prototype (the app's own rule). Every act
 * writes one History line with who and how ("Nathan K. · Phone") and is logged without personal data.
 * Nothing here reads a note (docs/25).
 */

defined( 'ABSPATH' ) || exit;

/* ================================================================== the offer */

/** The registration's offer of a place {at, uid, by, how, pay_by, withdrawn?}, or null. */
function ogc_hh_offer( $d ) {
	$o = isset( $d['offer'] ) && is_array( $d['offer'] ) ? $d['offer'] : null;
	return $o && ! empty( $o['pay_by'] ) && preg_match( '/^\d{4}-\d\d-\d\d$/', (string) $o['pay_by'] ) ? $o : null;
}

/** Is a place held for this household now (on the waiting list, offered, not withdrawn, not past its date)? */
function ogc_hh_offer_open( $d, $today ) {
	$o = ogc_hh_offer( $d );
	return $o && empty( $o['withdrawn'] ) && 'waitlist' === ( isset( $d['status'] ) ? $d['status'] : '' ) && (string) $o['pay_by'] >= (string) $today;
}

function ogc_hh_md( $iso ) {
	$t = strtotime( (string) $iso . ' 12:00:00 UTC' );
	return $t ? gmdate( 'M j', $t ) : '';
}

function ogc_hh_money( $cents ) {
	$c = (int) $cents;
	return '$' . number_format( $c / 100, $c % 100 ? 2 : 0 );
}

/* ================================================================== the panel's acts */

/**
 * What the household panel draws at its foot (GET app/{y}/households/{rid}): `can` gains change, cancel,
 * offer and withdraw, as the viewer's role would (greyed while seeing as; the routes refuse); `edit` the
 * form's address; `offer` the offer as words; `cancel_says` what Cancel does, line by line; `offer_says`
 * what Offer place shows.
 */
function ogc_hh_acts( $rec, $ctx, $out, $v ) {
	$y      = (int) $rec['year'];
	$d      = is_array( $rec['data'] ) ? $rec['data'] : array();
	$st     = $out['status'];
	$role   = ! empty( $v['coa'] ) || ogc_app_can_see( $v, 'households' ) || ogc_app_can_see( $v, 'lod-households' );
	$before = '' === $ctx['start'] || $ctx['today'] < $ctx['start'];
	$offer  = ogc_hh_offer( $d );
	$open   = ogc_hh_offer_open( $d, $ctx['today'] );
	$out['record'] = (int) $rec['id'];
	$out['edit']   = ogc_url( 'register', array( 'year' => $y, 'view' => 'edit', 'id' => (int) $rec['id'] ) );
	$out['offer']  = $offer && 'waitlist' === $st ? array(
		'how'       => (string) ( isset( $offer['how'] ) ? $offer['how'] : '' ),
		'pay_by'    => (string) $offer['pay_by'],
		'words'     => $open ? 'Offered · Pay by ' . ogc_hh_md( $offer['pay_by'] ) : ( empty( $offer['withdrawn'] ) ? 'Offer lapsed' : 'Offer withdrawn' ),
		'open'      => $open,
		'by'        => ! empty( $offer['uid'] ) ? ogc_rec_who( (int) $offer['uid'] ) : '',
	) : null;
	$out['can'] = array_merge( (array) $out['can'], array(
		'change'   => $role && ! in_array( $st, array( 'cancelled', 'checked_out' ), true ),
		'cancel'   => $role && $before && in_array( $st, array( 'waitlist', 'registered', 'placed' ), true ),
		'offer'    => $role && $before && 'waitlist' === $st && ! $open,
		'withdraw' => $role && $open,
	) );
	if ( $out['can']['cancel'] ) {
		$out['cancel_says'] = ogc_hh_cancel_says( $rec, $ctx, $v );
	}
	if ( $out['can']['offer'] ) {
		$stays = ogc_rec_stays();
		$cost  = (int) ( isset( $d['price']['total_cents'] ) ? $d['price']['total_cents'] : 0 );
		$sd    = isset( $out['stay_d'] ) ? $out['stay_d'] : array();
		$last  = '' !== $ctx['start'] ? ogc_lod_add_days( $ctx['start'], -1 ) : '';
		$by    = function ( $n ) use ( $ctx, $last ) {
			$x = ogc_lod_add_days( $ctx['today'], $n );
			return $last && $x > $last ? max( $ctx['today'], $last ) : $x;
		};
		$out['offer_says'] = array(
			'line'   => 'Waitlist · ' . $stays[ $out['stay'] ] . ' · Registered ' . ogc_hh_md( $out['registered'] ),
			'cost'   => implode( ' · ', array_filter( array(
				'dorm' === $out['stay'] && ! empty( $sd['rooms'] ) ? ogc_app_plural( (int) $sd['rooms'], 'room' ) : '',
				$out['span'],
				$cost ? ogc_hh_money( $cost ) : '',
			) ) ),
			'email'  => '' !== (string) ( isset( $d['household']['email'] ) ? $d['household']['email'] : '' ),
			'pay_by' => array( 'email' => $by( 7 ), 'phone' => $by( 14 ) ),
			'last'   => $last,
		);
	}
	return $out;
}

/** What Cancel does to this household, in a few lines (area-households-money 5.9.6). */
function ogc_hh_cancel_says( $rec, $ctx, $v ) {
	$y     = (int) $rec['year'];
	$d     = $rec['data'];
	$rid   = ogc_rec_rid( $rec );
	$m     = ogc_rec_money_of( $rec, $ctx );
	$cfg   = $ctx['cfg'];
	$rooms = ogc_hh_rooms_held( $y, $rid, $d );
	$out   = array();
	if ( $rooms ) {
		$out[] = ogc_app_can_see( $v, 'lod-rooms' ) || ! empty( $v['coa'] ) ? 'Frees ' . implode( ', ', array_map( 'ogc_lod_room_words', $rooms ) ) : 'Frees ' . ogc_app_plural( count( $rooms ), 'room' );
	}
	$gift = (int) $m['gift'];
	$sum  = function_exists( 'ogc_pay_sum' ) ? ogc_pay_sum( isset( $ctx['pay'][ (int) $rec['id'] ] ) ? $ctx['pay'][ (int) $rec['id'] ] : array() ) : array( 'paid' => 0, 'refund' => 0, 'check' => 0 );
	$back = max( 0, (int) $sum['paid'] - (int) $sum['refund'] - $gift );
	$by   = isset( $cfg['refunds_by'] ) ? (string) $cfg['refunds_by'] : '';
	if ( $back ) {
		$out[] = ! $by || $ctx['today'] <= $by ? 'Refund ' . ogc_hh_money( $back ) . ' asked' : 'No refund by itself · The treasurer decides';
	}
	if ( $gift && $sum['paid'] ) {
		$out[] = 'Gift ' . ogc_hh_money( $gift ) . ' kept';
	}
	if ( (int) $sum['check'] > 0 ) {
		$out[] = 'Check to come not needed';
	}
	if ( '' !== (string) ( isset( $d['household']['email'] ) ? $d['household']['email'] : '' ) && empty( $rec['sample'] ) ) {
		$out[] = 'Emails the household';
	}
	return $out;
}

/** The rooms a household holds now, its Youngfolks' hall rooms too (what Cancel frees): room ids. */
function ogc_hh_rooms_held( $y, $rid, $d ) {
	$rooms = ogc_lod_rooms( $y );
	$row   = ogc_lod_row( $y, 'hh:' . $rid );
	$out   = $row ? ogc_lod_real( isset( $row['data']['rooms'] ) ? $row['data']['rooms'] : array(), $rooms ) : array();
	foreach ( (array) ( isset( $d['people'] ) ? $d['people'] : array() ) as $p ) {
		if ( ! empty( $p['yf'] ) && ! empty( $p['pid'] ) ) {
			$yr = ogc_lod_row( $y, 'yf:' . $p['pid'] );
			if ( $yr && ! empty( $yr['data']['room'] ) && isset( $rooms[ (string) $yr['data']['room'] ] ) ) {
				$out[] = (string) $yr['data']['room'];
			}
		}
	}
	return $out;
}

/** The rooms a household holds, by place, for Cancel's Undo: array( hh => its row's rooms as listed (Room 1,
 * Room 2…), yf => pid => hall room ). */
function ogc_hh_rooms_had( $y, $rid, $d ) {
	$rooms = ogc_lod_rooms( $y );
	$row   = ogc_lod_row( $y, 'hh:' . $rid );
	$list  = $row && ogc_lod_real( isset( $row['data']['rooms'] ) ? $row['data']['rooms'] : array(), $rooms ) ? array_values( (array) $row['data']['rooms'] ) : array();
	$yf    = array();
	foreach ( (array) ( isset( $d['people'] ) ? $d['people'] : array() ) as $p ) {
		if ( ! empty( $p['yf'] ) && ! empty( $p['pid'] ) ) {
			$yr = ogc_lod_row( $y, 'yf:' . $p['pid'] );
			if ( $yr && ! empty( $yr['data']['room'] ) && isset( $rooms[ (string) $yr['data']['room'] ] ) ) {
				$yf[ (string) $p['pid'] ] = (string) $yr['data']['room'];
			}
		}
	}
	return array( 'hh' => $list, 'yf' => (object) $yf );
}

/* ================================================================== routes */

add_action( 'rest_api_init', function () {
	$Y = '(?P<year>\d{4})';
	register_rest_route( OGC_NS, "/app/$Y/households/cancel", array(
		array( 'methods' => 'POST', 'callback' => 'ogc_hh_rest_cancel', 'permission_callback' => 'ogc_hh_can' ),
	) );
	register_rest_route( OGC_NS, "/app/$Y/households/offer", array(
		array( 'methods' => 'POST', 'callback' => 'ogc_hh_rest_offer', 'permission_callback' => 'ogc_hh_can' ),
	) );
} );

/** The COA, Lodging, the committee handed Households: the real viewer, never while seeing as. */
function ogc_hh_can( WP_REST_Request $req ) {
	$y = (int) $req['year'];
	if ( ! ogc_valid_year( $y ) || ! is_user_logged_in() ) {
		return ogc_rest_denied( 'Sign in first.' );
	}
	if ( '' !== (string) $req->get_param( 'as' ) ) {
		return new WP_Error( 'ogc_read_only', 'Read only while seeing as', array( 'status' => 403 ) );
	}
	if ( ! function_exists( 'ogc_access' ) || ! ogc_access( $y, 'households' ) ) {
		return new WP_Error( 'ogc_forbidden', 'Not allowed', array( 'status' => 403 ) );
	}
	return null === ogc_year_get( $y ) ? new WP_Error( 'ogc_not_found', 'Not found.', array( 'status' => 404 ) ) : true;
}

/** The registration named by `rid` in the year, with the act's day set for its History line. */
function ogc_hh_record( WP_REST_Request $req ) {
	$y   = (int) $req['year'];
	$rid = is_scalar( $req->get_param( 'rid' ) ) ? (string) $req->get_param( 'rid' ) : '';
	$rec = preg_match( '/^R-\d{4}-\d{1,8}$/', $rid ) ? ogc_rec_by_rid( $y, $rid ) : null;
	$GLOBALS['ogc_reg_hist_day'] = ogc_app_today( $y );
	$how                         = $req->get_param( 'how' );
	$GLOBALS['ogc_reg_how']      = is_string( $how ) && in_array( $how, array( 'phone', 'paper', 'desk' ), true ) ? $how : '';
	return $rec;
}

/** POST app/{y}/households/cancel {rid, how} · {rid, undo}. */
function ogc_hh_rest_cancel( WP_REST_Request $req ) {
	$y   = (int) $req['year'];
	$rec = ogc_hh_record( $req );
	if ( ! $rec ) {
		return new WP_Error( 'ogc_not_found', 'Not found.', array( 'status' => 404 ) );
	}
	$undo = is_scalar( $req->get_param( 'undo' ) ) ? (string) $req->get_param( 'undo' ) : '';
	if ( '' !== $undo ) {
		return ogc_hh_undo( $y, $rec, $undo, 'cancel' );
	}
	$ctx = ogc_rec_ctx( $y );
	$row = ogc_rec_row( $rec, $ctx );
	if ( '' !== $ctx['start'] && $ctx['today'] >= $ctx['start'] ) {
		return new WP_Error( 'ogc_not_now', 'From ' . ogc_hh_md( $ctx['start'] ) . ' · Didn’t come or Leave early', array( 'status' => 409 ) );
	}
	if ( ! in_array( $row['status'], array( 'waitlist', 'registered', 'placed' ), true ) ) {
		return new WP_Error( 'ogc_not_now', 'Not for ' . $row['status_w'], array( 'status' => 409 ) );
	}
	if ( ! ogc_reg_lock( $y ) ) {
		return new WP_Error( 'ogc_busy', 'Busy · Try again', array( 'status' => 503 ) );
	}
	try {
		// As it is now, under the lock: Cancel pressed twice (or by Lodging and the COA at once) finds it
		// cancelled the second time, and says so (red team ATK1-cancel-twice: two History lines, two emails).
		$rec = ogc_record_get( (int) $rec['id'] );
		if ( ! $rec || 'cancelled' === ( isset( $rec['data']['status'] ) ? $rec['data']['status'] : '' ) ) {
			return new WP_Error( 'ogc_not_now', 'Cancelled already', array( 'status' => 409 ) );
		}
		$before = ogc_hh_snapshot( $rec );
		// What it holds, its Youngfolks' hall rooms too: Cancel frees them (ogc_reg_save → ogc_lod_reg_saved) and names them.
		$rooms = ogc_hh_rooms_held( $y, $row['rid'], $rec['data'] );
		// And where, for Undo: the freed notice on Lodging's rows may be marked seen (Looks right) before
		// Undo is pressed, and the rooms must still come back (red team round 2, ATK1-r2-cancel-undo-after-ack).
		$had = ogc_hh_rooms_had( $y, $row['rid'], $rec['data'] );
		$after = ogc_reg_cancel( $rec );
	} finally {
		ogc_reg_unlock( $y );
	}
	// Which rooms, only to those who may see rooms (the Privacy screen's Rooms rule: red team A4-16).
	$see   = function_exists( 'ogc_access' ) && ogc_access( $y, 'rooms' );
	$freed = $rooms ? ' · Frees ' . ( $see ? implode( ', ', array_map( 'ogc_lod_room_words', $rooms ) ) : ogc_app_plural( count( $rooms ), 'room' ) ) : '';
	$made  = ogc_hh_made( $rec, $before );
	$token = ogc_hh_undo_put( $y, array( 'kind' => 'cancel', 'rid' => $row['rid'], 'record' => (int) $rec['id'], 'before' => $before, 'made' => $made, 'had' => $had ) );
	ogc_hh_mail_hold( $y, $token, $after, 'cancelled' );
	ogc_rec_forget( $y );
	$ctx2  = ogc_rec_ctx( $y );
	ogc_log( 'records_cancel', $y, 'registrations', array( 'id' => (int) $rec['id'], 'how' => $GLOBALS['ogc_reg_how'] ) );
	return rest_ensure_response( array(
		'ok'    => true,
		'say'   => ogc_rec_short( $rec['data'] ) . ' · Cancelled' . $freed,
		'rooms' => $see ? array_map( 'ogc_lod_room_words', $rooms ) : array(),
		'undo'  => $token,
		'row'   => ogc_rec_row( ogc_record_get( (int) $rec['id'] ), $ctx2 ),
	) );
}

/** POST app/{y}/households/offer {rid, how, pay_by} · {rid, withdraw: 1} · {rid, undo}. */
function ogc_hh_rest_offer( WP_REST_Request $req ) {
	$y   = (int) $req['year'];
	$rec = ogc_hh_record( $req );
	if ( ! $rec ) {
		return new WP_Error( 'ogc_not_found', 'Not found.', array( 'status' => 404 ) );
	}
	$undo = is_scalar( $req->get_param( 'undo' ) ) ? (string) $req->get_param( 'undo' ) : '';
	if ( '' !== $undo ) {
		return ogc_hh_undo( $y, $rec, $undo, 'offer' );
	}
	$ctx  = ogc_rec_ctx( $y );
	$row  = ogc_rec_row( $rec, $ctx );
	$d    = $rec['data'];
	$name = ogc_rec_short( $d );
	if ( 'waitlist' !== $row['status'] ) {
		return new WP_Error( 'ogc_not_now', 'Not on the waiting list', array( 'status' => 409 ) );
	}
	$open = ogc_hh_offer_open( $d, $ctx['today'] );
	$before = ogc_hh_snapshot( $rec );
	if ( $req->get_param( 'withdraw' ) ) {
		if ( ! $open ) {
			return new WP_Error( 'ogc_not_now', 'No offer open', array( 'status' => 409 ) );
		}
		$d['offer']['withdrawn'] = array( 'at' => ogc_reg_hist_at(), 'uid' => get_current_user_id() );
		ogc_reg_note_history( $d, 'Offer withdrawn', 'committee' );
		$say = $name . ' · Offer withdrawn';
	} else {
		if ( $open ) {
			return new WP_Error( 'ogc_not_now', 'Offered already · Pay by ' . ogc_hh_md( $d['offer']['pay_by'] ), array( 'status' => 409 ) );
		}
		if ( '' !== $ctx['start'] && $ctx['today'] >= $ctx['start'] ) {
			return new WP_Error( 'ogc_not_now', 'From ' . ogc_hh_md( $ctx['start'] ) . ' · At the desk', array( 'status' => 409 ) );
		}
		$how   = in_array( $req->get_param( 'how' ), array( 'email', 'phone' ), true ) ? (string) $req->get_param( 'how' ) : '';
		$email = isset( $d['household']['email'] ) ? (string) $d['household']['email'] : '';
		if ( '' === $how ) {
			return new WP_Error( 'ogc_invalid', 'Choose how', array( 'status' => 400, 'field' => 'how' ) );
		}
		if ( 'email' === $how && '' === $email ) {
			return new WP_Error( 'ogc_invalid', 'No email · Offer by phone', array( 'status' => 400, 'field' => 'how' ) );
		}
		$pay_by = substr( (string) $req->get_param( 'pay_by' ), 0, 10 );
		$last   = '' !== $ctx['start'] ? ogc_lod_add_days( $ctx['start'], -1 ) : '';
		if ( ! preg_match( '/^\d{4}-\d\d-\d\d$/', $pay_by ) || $pay_by < $ctx['today'] || ( $last && $pay_by > $last ) ) {
			return new WP_Error( 'ogc_invalid', $last ? 'A day from today to ' . ogc_hh_md( $last ) : 'A day from today', array( 'status' => 400, 'field' => 'pay_by' ) );
		}
		$GLOBALS['ogc_reg_how'] = 'phone' === $how ? 'phone' : '';
		$d['offer'] = array( 'at' => ogc_reg_hist_at(), 'uid' => get_current_user_id(), 'how' => $how, 'pay_by' => $pay_by );
		ogc_reg_note_history( $d, 'Offered · Pay by ' . ogc_hh_md( $pay_by ), 'committee' );
		$say = 'Offered · ' . $name . ' · Pay by ' . ogc_hh_md( $pay_by );
	}
	if ( ! ogc_reg_lock( $y ) ) {
		return new WP_Error( 'ogc_busy', 'Busy · Try again', array( 'status' => 503 ) );
	}
	try {
		$after = ogc_reg_save( $rec, $d );
	} finally {
		ogc_reg_unlock( $y );
	}
	$token = ogc_hh_undo_put( $y, array( 'kind' => 'offer', 'rid' => $row['rid'], 'record' => (int) $rec['id'], 'before' => $before, 'made' => array() ) );
	if ( ! $req->get_param( 'withdraw' ) && 'email' === $d['offer']['how'] ) {
		ogc_hh_mail_hold( $y, $token, $after, 'offer' );
	}
	ogc_rec_forget( $y );
	ogc_log( $req->get_param( 'withdraw' ) ? 'records_offer_off' : 'records_offer', $y, 'registrations', array( 'id' => (int) $rec['id'] ) );
	return rest_ensure_response( array( 'ok' => true, 'say' => $say, 'undo' => $token, 'row' => ogc_rec_row( ogc_record_get( (int) $rec['id'] ), ogc_rec_ctx( $y ) ) ) );
}

/* ================================================================== undo */

/** What an act may need to put back: the status, the offer, History's length, every ledger line, credits. */
function ogc_hh_snapshot( $rec ) {
	$d       = $rec['data'];
	$lines   = function_exists( 'ogc_pay_rows' ) ? ogc_pay_rows( (int) $rec['id'] ) : array();
	$credits = array();
	foreach ( ogc_records( (int) $rec['year'], 'credits' ) as $c ) {
		$credits[] = (int) $c['id'];
	}
	return array(
		'status'  => isset( $d['status'] ) ? (string) $d['status'] : '',
		'offer'   => isset( $d['offer'] ) ? $d['offer'] : null,
		'hist'    => count( isset( $d['history'] ) ? (array) $d['history'] : array() ),
		'pending' => array_values( array_map( function ( $p ) { return (int) $p['id']; }, array_filter( $lines, function ( $p ) { return 'pending' === $p['status']; } ) ) ),
		'lines'   => array_map( function ( $p ) { return (int) $p['id']; }, $lines ),
		'credits' => $credits,
	);
}

/** The ledger lines and credit records an act made (by id). */
function ogc_hh_made( $rec, $before ) {
	$lines   = function_exists( 'ogc_pay_rows' ) ? ogc_pay_rows( (int) $rec['id'] ) : array();
	$credits = array();
	foreach ( ogc_records( (int) $rec['year'], 'credits' ) as $c ) {
		if ( ! in_array( (int) $c['id'], $before['credits'], true ) ) {
			$credits[] = (int) $c['id'];
		}
	}
	return array(
		'lines'   => array_values( array_map( function ( $p ) { return (int) $p['id']; }, array_filter( $lines, function ( $p ) use ( $before ) { return ! in_array( (int) $p['id'], $before['lines'], true ); } ) ) ),
		'credits' => $credits,
	);
}

/** How long an act may be undone: as long as its email waits (the ledger's receipt wait, 10 min). */
function ogc_hh_undo_wait() {
	return function_exists( 'ogc_ledger_receipt_wait' ) ? (int) ogc_ledger_receipt_wait() : 600;
}

/** Keep what an act did, for its Undo (state hh_undo {token: {...}}). Returns the token. */
function ogc_hh_undo_put( $y, $u ) {
	$token = 'u' . strtolower( wp_generate_password( 16, false, false ) );
	for ( $try = 0; $try < 3; $try++ ) {
		$cur = ogc_state_get( $y, 'hh_undo' );
		$all = $cur && is_array( $cur['value'] ) ? $cur['value'] : array();
		foreach ( $all as $k => $x ) {
			if ( ! is_array( $x ) || time() - (int) ( isset( $x['ts'] ) ? $x['ts'] : 0 ) > DAY_IN_SECONDS ) {
				unset( $all[ $k ] );
			}
		}
		$all[ $token ] = array_merge( $u, array( 'uid' => get_current_user_id(), 'ts' => time() ) );
		if ( ! is_wp_error( ogc_state_put( $y, 'hh_undo', (object) $all, $cur ? $cur['version'] : null ) ) ) {
			return $token;
		}
	}
	return '';
}

/** Put an act back: only its own member, within the wait, while nothing it touched has moved on since. */
function ogc_hh_undo( $y, $rec, $token, $kind ) {
	$cur = ogc_state_get( $y, 'hh_undo' );
	$all = $cur && is_array( $cur['value'] ) ? $cur['value'] : array();
	$u   = isset( $all[ $token ] ) && is_array( $all[ $token ] ) ? $all[ $token ] : null;
	$no  = function ( $msg ) {
		return new WP_Error( 'ogc_cant_undo', $msg, array( 'status' => 409 ) );
	};
	if ( ! $u || $u['kind'] !== $kind || (int) $u['record'] !== (int) $rec['id'] || (int) $u['uid'] !== get_current_user_id() || time() - (int) $u['ts'] > ogc_hh_undo_wait() ) {
		return $no( 'Can’t undo' );
	}
	if ( 'cancel' === $kind ) {
		// The room check, the putting back and the save, under the registration's lock and Lodging's, so a
		// room given meanwhile is never given twice (invariant 72).
		if ( ! ogc_reg_lock( $y ) ) {
			return new WP_Error( 'ogc_busy', 'Busy · Try again', array( 'status' => 503 ) );
		}
		if ( ! ogc_lod_lock( $y ) ) {
			ogc_reg_unlock( $y );
			return new WP_Error( 'ogc_busy', 'Busy · Try again', array( 'status' => 503 ) );
		}
		try {
			$rec = ogc_record_get( (int) $rec['id'] );
			$d   = $rec ? $rec['data'] : array();
			$b   = $u['before'];
			$rid = $rec ? ogc_rec_rid( $rec ) : '';
			if ( ! $rec || 'cancelled' !== ( isset( $d['status'] ) ? $d['status'] : '' ) ) {
				return $no( 'Changed since · Can’t undo' );
			}
			// The rooms Cancel freed (kept on Lodging's rows as freed), or still on its row from before: back
			// only if nobody was given them since. Otherwise it stays cancelled (Lodging places by hand).
			$ctx   = ogc_lod_ctx( $y );
			$see   = function_exists( 'ogc_access' ) && ogc_access( $y, 'rooms' );
			$given = function ( $id ) use ( $see ) {
				return ( $see ? ogc_lod_room_words( $id ) : 'A room' ) . ' given since · Can’t undo';
			};
			$put   = array();
			$lrow  = ogc_lod_row( $y, 'hh:' . $rid );
			$ld    = $lrow ? (array) $lrow['data'] : array();
			$had   = isset( $u['had'] ) ? (array) $u['had'] : array();
			$list  = ! empty( $ld['rooms'] ) ? array_values( (array) $ld['rooms'] ) : ( isset( $ld['freed']['why'] ) && 'Cancelled' === $ld['freed']['why'] ? array_values( (array) ( isset( $ld['freed']['list'] ) ? $ld['freed']['list'] : $ld['freed']['rooms'] ) ) : array() );
			// The freed notice already marked seen (Looks right): the rooms Cancel freed, as the household had them.
			if ( ! $list && empty( $ld['freed'] ) && ! empty( $had['hh'] ) ) {
				$list = array_values( (array) $had['hh'] );
			}
			$claim = ogc_lod_claims( $ctx, ogc_lod_claim_rows( $y, 'hh:' . $rid ) );
			foreach ( ogc_lod_real( $list, $ctx['rooms'] ) as $id ) {
				if ( ! empty( $claim[ $id ] ) ) {
					return $no( $given( $id ) );
				}
			}
			if ( $list && $lrow && empty( $ld['rooms'] ) ) {
				$nd          = $ld;
				$nd['rooms'] = $list;
				unset( $nd['freed'] );
				$put[ 'hh:' . $rid ] = array( $nd, $lrow['v'] );
			}
			$had_yf = isset( $had['yf'] ) ? (array) $had['yf'] : array();
			foreach ( (array) ( isset( $d['people'] ) ? $d['people'] : array() ) as $p ) {
				$yr = ! empty( $p['yf'] ) && ! empty( $p['pid'] ) ? ogc_lod_row( $y, 'yf:' . $p['pid'] ) : null;
				$id = $yr && ! empty( $yr['data']['freed']['room'] ) && 'Cancelled' === ( isset( $yr['data']['freed']['why'] ) ? $yr['data']['freed']['why'] : '' ) ? (string) $yr['data']['freed']['room'] : '';
				// The freed notice marked seen: the hall room Cancel freed, while the row holds none since.
				if ( '' === $id && $yr && empty( $yr['data']['room'] ) && empty( $yr['data']['freed'] ) && ! empty( $had_yf[ (string) $p['pid'] ] ) ) {
					$id = (string) $had_yf[ (string) $p['pid'] ];
				}
				if ( '' === $id ) {
					continue;
				}
				$cl = ogc_lod_claims( $ctx, ogc_lod_claim_rows( $y, 'yf:' . $p['pid'] ) );
				if ( isset( $ctx['rooms'][ $id ] ) && '' !== ogc_lod_room_wrong( $ctx, $id, array_merge( isset( $cl[ $id ] ) ? $cl[ $id ] : array(), array( 'yf:' . $p['pid'] ) ) ) ) {
					return $no( $given( $id ) );
				}
				$nd         = (array) $yr['data'];
				$nd['room'] = $id;
				unset( $nd['freed'] );
				$put[ 'yf:' . $p['pid'] ] = array( $nd, $yr['v'] );
			}
			// Everything the rooms going back would leave wrong, judged as Place judges it, with the household
			// as it will be again: a room no longer for families, fewer beds than its people, an under-18 and an
			// 18-and-up together (red team D1, D2, D3, ATK1-cancel-undo-ages).
			$back            = $d;
			$back['status']  = $b['status'];
			unset( $back['cancelled_at'] );
			$after = array();
			foreach ( $put as $k => $x ) {
				$after[ $k ] = $x[0];
			}
			$bad = ogc_lod_check_plan( $ctx, ogc_lod_claim_data( $y ), $after, ogc_lod_ctx_with( $ctx, array( $rid => $back ) ) );
			if ( is_wp_error( $bad ) ) {
				return $no( ( $see ? $bad->get_error_message() : 'Rooms changed since' ) . ' · Can’t undo' );
			}
			foreach ( $u['made']['lines'] as $id ) {
				$pl = ogc_pay_get( (int) $id );
				if ( $pl && 'requested' !== $pl['status'] ) {
					return $no( 'Refund ' . strtolower( ogc_pay_status_words( $pl ) ) . ' since · Can’t undo' );
				}
			}
			foreach ( $put as $k => $x ) {
				if ( is_wp_error( ogc_lod_put( $y, $k, $x[0], $x[1] ) ) ) {
					return $no( 'Changed since · Can’t undo' );
				}
			}
			global $wpdb;
			foreach ( $u['made']['lines'] as $id ) {
				$wpdb->delete( ogc_table( 'payments' ), array( 'id' => (int) $id, 'status' => 'requested' ), array( '%d', '%s' ) );
			}
			foreach ( $u['made']['credits'] as $id ) {
				ogc_record_delete( (int) $id );
			}
			foreach ( $b['pending'] as $id ) {
				ogc_pay_set_if( (int) $id, array( 'status' => 'pending' ), 'cancelled' );
			}
			$d['status'] = $b['status'];
			unset( $d['cancelled_at'] );
			$say          = ogc_rec_short( $d ) . ' · Cancel undone';
			$d['history'] = array_slice( (array) ( isset( $d['history'] ) ? $d['history'] : array() ), 0, (int) $b['hist'] );
			ogc_reg_save( $rec, $d );
		} finally {
			ogc_lod_unlock( $y );
			ogc_reg_unlock( $y );
		}
	} else {
		$d   = $rec['data'];
		$b   = $u['before'];
		if ( 'waitlist' !== ( isset( $d['status'] ) ? $d['status'] : '' ) ) {
			return $no( 'Changed since · Can’t undo' );
		}
		if ( null === $b['offer'] ) {
			unset( $d['offer'] );
		} else {
			$d['offer'] = $b['offer'];
		}
		$say          = ogc_rec_short( $d ) . ' · Undone';
		$d['history'] = array_slice( (array) ( isset( $d['history'] ) ? $d['history'] : array() ), 0, (int) $b['hist'] );
		if ( ! ogc_reg_lock( $y ) ) {
			return new WP_Error( 'ogc_busy', 'Busy · Try again', array( 'status' => 503 ) );
		}
		try {
			ogc_reg_save( $rec, $d );
		} finally {
			ogc_reg_unlock( $y );
		}
	}
	unset( $all[ $token ] );
	ogc_state_put( $y, 'hh_undo', (object) $all );
	ogc_hh_mail_drop( $y, $token );
	ogc_rec_forget( $y );
	ogc_log( 'records_' . $kind . '_undo', $y, 'registrations', array( 'id' => (int) $rec['id'] ) );
	return rest_ensure_response( array( 'ok' => true, 'say' => $say, 'row' => ogc_rec_row( ogc_record_get( (int) $rec['id'] ), ogc_rec_ctx( $y ) ) ) );
}

/* ================================================================== the emails wait out Undo */

/** Hold an act's email (state hh_mail {token: {after, record, kind}}) until Undo's time is over. */
function ogc_hh_mail_hold( $y, $token, $rec, $kind ) {
	if ( '' === $token || ! empty( $rec['sample'] ) ) {
		return;
	}
	$after = time() + ogc_hh_undo_wait();
	for ( $try = 0; $try < 3; $try++ ) {
		$cur          = ogc_state_get( $y, 'hh_mail' );
		$all          = $cur && is_array( $cur['value'] ) ? $cur['value'] : array();
		$all[ $token ] = array( 'after' => $after, 'record' => (int) $rec['id'], 'kind' => $kind );
		if ( ! is_wp_error( ogc_state_put( $y, 'hh_mail', (object) $all, $cur ? $cur['version'] : null ) ) ) {
			break;
		}
	}
	wp_schedule_single_event( $after + 5, 'ogc_hh_mail_send', array( (int) $y ) );
}

function ogc_hh_mail_drop( $y, $token ) {
	$cur = ogc_state_get( $y, 'hh_mail' );
	$all = $cur && is_array( $cur['value'] ) ? $cur['value'] : array();
	if ( isset( $all[ $token ] ) ) {
		unset( $all[ $token ] );
		ogc_state_put( $y, 'hh_mail', (object) $all );
	}
}

/** Send what has waited long enough: a cancel still cancelled, an offer still open. */
function ogc_hh_mail_due( $y, $force = false ) {
	$cur = ogc_state_get( (int) $y, 'hh_mail' );
	$all = $cur && is_array( $cur['value'] ) ? $cur['value'] : array();
	$due = array_filter( $all, function ( $m ) use ( $force ) { return is_array( $m ) && ( $force || (int) $m['after'] <= time() ); } );
	if ( ! $due || is_wp_error( ogc_state_put( (int) $y, 'hh_mail', (object) array_diff_key( $all, $due ), $cur['version'] ) ) ) {
		return 0;
	}
	$n = 0;
	foreach ( $due as $m ) {
		$rec = ogc_record_get( (int) $m['record'] );
		if ( ! $rec || ! empty( $rec['sample'] ) ) {
			continue;
		}
		$d = $rec['data'];
		if ( 'cancelled' === $m['kind'] && 'cancelled' === ( isset( $d['status'] ) ? $d['status'] : '' ) ) {
			ogc_reg_mail_receipt( $rec, 'cancelled' );
			$n++;
		} elseif ( 'offer' === $m['kind'] && ogc_hh_offer_open( $d, ogc_reg_today( (int) $y ) ) && function_exists( 'ogc_mail_send_kind' ) ) {
			$o = $d['offer'];
			$q = ogc_reg_c( ogc_reg_cfg( (int) $y ), 'questions_email' );
			foreach ( ogc_reg_recipients( $rec ) as $to ) {
				ogc_mail_send_kind( 'message', $to, array(
					'year'    => (int) $y,
					'subject' => 'A place is offered',
					'from'    => (int) $y . ' Annual Conference',
					'about'   => 'Pay by ' . ogc_hh_md( $o['pay_by'] ),
					'body'    => 'A place at the ' . (int) $y . ' Annual Conference is held for ' . ogc_rec_label( $d ) . ' until ' . ogc_hh_md( $o['pay_by'] ) . ".\nReply to this email, or call, to say yes.",
					'link'    => function_exists( 'ogc_mine_url' ) ? ogc_mine_url( $to, (int) $y ) : '',
				), array( 'year' => (int) $y, 'reply_to' => is_email( $q ) ? $q : '' ) );
				$n++;
			}
		}
	}
	return $n;
}

add_action( 'ogc_hh_mail_send', function ( $y ) {
	ogc_hh_mail_due( (int) $y );
} );

// The state values these acts keep are theirs alone: the generic state route gets 403.
add_filter( 'rest_request_before_callbacks', function ( $resp, $handler, $req ) {
	if ( ! is_wp_error( $resp ) && preg_match( '#^/' . preg_quote( OGC_NS, '#' ) . '/years/\d{4}/state/(hh_undo|hh_mail)$#', (string) $req->get_route() ) ) {
		return new WP_Error( 'ogc_forbidden', 'Not allowed.', array( 'status' => 403 ) );
	}
	return $resp;
}, 20, 3 );
