<?php
/**
 * Lodging, local only (OGC_DEV on a local address): the made-up Google Form export that Import's
 * "Mockup: sample file" reads. The file lives in seed/dev/ (never under assets/, so ogbbc.org has no
 * registration-shaped file at a public address; seed/dev/ also refuses direct requests), is made by
 * tools/lodging-sample-form.mjs, and every name in it is invented.
 *
 *   GET /years/{y}/lodging/sample   members of the year, OGC_DEV and a local address only
 */

defined( 'ABSPATH' ) || exit;

add_action( 'rest_api_init', function () {
	if ( ! OGC_DEV || ! function_exists( 'ogc_is_local_host' ) || ! ogc_is_local_host() ) {
		return;
	}
	register_rest_route( OGC_NS, '/years/(?P<year>\d{4})/lodging/sample', array(
		array(
			'methods'             => 'GET',
			'permission_callback' => 'ogc_lod_can',
			'callback'            => function () {
				$f = OGC_DIR . 'seed/dev/lodging-sample-form.csv';
				return rest_ensure_response( array( 'name' => 'Registration 2027 (Responses) - Form Responses 1.csv', 'text' => is_readable( $f ) ? (string) file_get_contents( $f ) : '' ) );
			},
		),
	) );
} );
