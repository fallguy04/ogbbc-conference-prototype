<?php
/**
 * Registration's REST routes (register area), /wp-json/ogc/v1/reg/…  Every change needs the wp_rest
 * nonce (OGC_WP.api sends it) and is logged; the household's own pages never see another household.
 *
 *   GET    reg/{y}/form           everyone   where registration stands, the prices, what's left, and
 *                                            for someone signed in: their registrations and last year's
 *   POST   reg/{y}/check          everyone   {data, id?} → the answers cleaned, the price, the problems
 *   POST   reg/{y}                signed in  {data, expect, idem} register (members: at the desk too)
 *   GET    reg/{y}/mine           signed in  the registrations this email owns or manages
 *   PUT    reg/r/{id}             its household or a member  {data, expect, v, idem, pay} change
 *   POST   reg/r/{id}/pay         its household  {method, idem} pay what's due
 *   POST   reg/r/{id}/cancel      its household or a member
 *   POST   reg/r/{id}/leave       its household or a member  {last, who?} leaving early, during the week
 *                                            (who: the people leaving, by pid; everyone when left out)
 *   POST   reg/r/{id}/approval    its household  ask the parent again
 *   POST   reg/r/{id}/ledger      money      {action, payment, cents, method, note} the treasurer and the desk
 *                                            (every member, until the COA names who handles money)
 *   GET    reg/approve/{token}    the parent's link   what they're approving
 *   POST   reg/approve/{token}    the parent's link   {decision: approve | decline}
 *   POST   reg/signout            signed in  "Not you?" on the form: signed out here, the form stays
 *   GET    reg/{y}/ledger         members    every payment line (?format=csv for the treasurer)
 *   DELETE reg/{y}/samples        members    clear the year's sample households
 *   DELETE reg/{y}/tests          local only: members  clear the year's test registrations (not samples)
 */

defined( 'ABSPATH' ) || exit;

// The request being answered, so a view of a registration sees the same "today" (?as_of= for members
// and locally) as the route did.
add_filter( 'rest_request_before_callbacks', function ( $res, $handler, $req ) {
	if ( 0 === strpos( (string) $req->get_route(), '/' . OGC_NS . '/reg/' ) ) {
		$GLOBALS['ogc_reg_req'] = $req;
	}
	return $res;
}, 10, 3 );

add_action( 'rest_api_init', function () {
	$Y  = '(?P<year>\d{4})';
	$ID = '(?P<id>\d+)';
	$r  = function ( $path, $methods, $cb, $perm ) {
		register_rest_route( OGC_NS, $path, array( 'methods' => $methods, 'callback' => $cb, 'permission_callback' => $perm ) );
	};
	$any      = '__return_true';
	$signedin = function () { return is_user_logged_in() ? true : new WP_Error( 'ogc_signin', 'Sign in first.', array( 'status' => 401 ) ); };
	$member   = function ( WP_REST_Request $q ) { return ogc_is_member( $q['year'] ) ? true : ogc_rest_denied(); };
	$theirs   = function ( WP_REST_Request $q ) {
		$rec = ogc_record_get( (int) $q['id'] );
		if ( ! $rec || 'registrations' !== $rec['kind'] ) {
			return new WP_Error( 'ogc_not_found', 'Not found.', array( 'status' => 404 ) );
		}
		if ( ogc_reg_may( $rec ) ) {
			return true;
		}
		return is_user_logged_in() ? new WP_Error( 'ogc_not_found', 'Not found.', array( 'status' => 404 ) ) : ogc_rest_denied( 'Sign in first.' );
	};
	// Every payment line (the treasurer's ledger): webmasters, the people the COA names for Payments, or
	// the COA's own members who handle money. Never another committee's helpers (docs/23; Oct 11 review).
	$ledger = function ( WP_REST_Request $q ) {
		$y = (int) $q['year'];
		if ( ogc_is_webmaster() || ( function_exists( 'ogc_lst_viewer' ) && ogc_lst_viewer( $y, 'payments' ) ) ) {
			return true;
		}
		$v = function_exists( 'ogc_app_viewer' ) ? ogc_app_viewer( $y ) : array( 'coa' => false );
		return $v['coa'] && ogc_reg_money_ok( $y ) ? true : ogc_rest_denied();
	};
	// Clearing samples or test registrations: the COA and webmasters only.
	$coa = function ( WP_REST_Request $q ) {
		$v = function_exists( 'ogc_app_viewer' ) ? ogc_app_viewer( (int) $q['year'] ) : array( 'coa' => false, 'webmaster' => ogc_is_webmaster() );
		return $v['coa'] || $v['webmaster'] ? true : ogc_rest_denied();
	};
	// Money (a desk payment, a check received, a refund): the members who handle money (ogc_reg_money_ok).
	$recmoney = function ( WP_REST_Request $q ) {
		$rec = ogc_record_get( (int) $q['id'] );
		return $rec && 'registrations' === $rec['kind'] && ogc_reg_money_ok( $rec['year'] ) ? true : ogc_rest_denied();
	};
	$r( "/reg/$Y/form", 'GET', 'ogc_reg_rest_form', $any );
	$r( "/reg/$Y/check", 'POST', 'ogc_reg_rest_check', $any );
	$r( "/reg/$Y", 'POST', 'ogc_reg_rest_create', $signedin );
	$r( "/reg/$Y/mine", 'GET', 'ogc_reg_rest_mine', $signedin );
	$r( "/reg/r/$ID", 'PUT', 'ogc_reg_rest_update', $theirs );
	$r( "/reg/r/$ID/pay", 'POST', 'ogc_reg_rest_pay', $theirs );
	$r( "/reg/r/$ID/cancel", 'POST', 'ogc_reg_rest_cancel', $theirs );
	$r( "/reg/r/$ID/leave", 'POST', 'ogc_reg_rest_leave', $theirs );
	$r( "/reg/r/$ID/approval", 'POST', 'ogc_reg_rest_resend', $theirs );
	$r( "/reg/r/$ID/ledger", 'POST', 'ogc_reg_rest_ledger', $recmoney );
	$r( '/reg/approve/(?P<token>\d{4}\.[a-z0-9]{32})', 'GET', 'ogc_reg_rest_approve_get', $any );
	$r( '/reg/approve/(?P<token>\d{4}\.[a-z0-9]{32})', 'POST', 'ogc_reg_rest_approve_post', $any );
	$r( '/reg/signout', 'POST', 'ogc_reg_rest_signout', $signedin );
	// A form not sent yet, once the email is confirmed: the person's own (never a member's to read).
	$r( "/reg/$Y/draft", 'GET', 'ogc_reg_rest_draft_get', $signedin );
	$r( "/reg/$Y/draft", 'PUT', 'ogc_reg_rest_draft_put', $signedin );
	$r( "/reg/$Y/draft", 'DELETE', 'ogc_reg_rest_draft_delete', $signedin );
	$r( "/reg/$Y/ledger", 'GET', 'ogc_reg_rest_ledger_list', $ledger );
	$r( "/reg/$Y/samples", 'DELETE', 'ogc_reg_rest_samples', $coa );
	// Local only: a walk-through's own registrations go, so "Reuse" and the Try-it addresses work again.
	if ( ogc_reg_local() ) {
		$r( "/reg/$Y/tests", 'DELETE', 'ogc_reg_rest_tests', $coa );
	}
} );

function ogc_reg_err( $code, $msg, $status, $extra = array() ) {
	return new WP_Error( $code, $msg, array_merge( array( 'status' => $status ), $extra ) );
}

/* ------------------------------------------------------------------ the form */

/** The settings the form may see (not the committee's own addresses). */
function ogc_reg_public_cfg( $cfg ) {
	unset( $cfg['lodging_email'], $cfg['money_email'], $cfg['money_notify_over'] );
	return $cfg;
}

/** Last year's registration made ready for this year: the same people a year older (and what that
 * changes), the same kind of stay, this year's nights. Never money, rooms, a parent's approval,
 * medical notes or emergency contacts. */
function ogc_reg_reuse( $rec, $year ) {
	$d       = $rec['data'];
	$cfg     = ogc_reg_cfg( $year );
	$changes = array();
	$people  = array();
	foreach ( (array) $d['people'] as $p ) {
		$q   = array_intersect_key( (array) $p, array_flip( array( 'pid', 'name', 'kind', 'age', 'yfHall', 'rooming', 'sleeps', 'linens', 'communing', 'ptOff' ) ) );
		$was = isset( $p['age'] ) && '' !== $p['age'] ? (int) $p['age'] : -1;
		if ( $was >= 0 ) {
			$now      = $was + 1;
			$q['age'] = (string) $now;
			$first    = ogc_reg_first( $p['name'] );
			if ( 'child' === $q['kind'] && $now >= 10 && $now <= 13 && ! ( $was >= 10 && $was <= 13 ) ) {
				$changes[] = array( 'pid' => $q['pid'], 'text' => $first . ' ' . $now . ' · Preteen program' );
			} elseif ( 'child' === $q['kind'] && $now >= 14 && $was <= 13 && $was >= 10 ) {
				$changes[] = array( 'pid' => $q['pid'], 'text' => $first . ' ' . $now . ' · Preteen program off' );
			} elseif ( 'child' === $q['kind'] && $now >= 18 ) {
				$changes[] = array( 'pid' => $q['pid'], 'text' => $first . ' ' . $now . ' · Adult or Young Folk?' );
			} elseif ( 'yf' === $q['kind'] && 18 === $now ) {
				$changes[] = array( 'pid' => $q['pid'], 'text' => $first . ' 18 · Under 18 off' );
			} elseif ( 'child' === $q['kind'] && $now < 3 !== $was < 3 ) {
				$changes[] = array( 'pid' => $q['pid'], 'text' => $first . ' ' . $now );
			}
		}
		$q['ptOff'] = false;
		$people[]   = $q;
	}
	$s      = (array) $d['stay'];
	// The household's note isn't carried: it may hold last year's medical needs, kept by accident.
	if ( ! empty( $s['needs'] ) ) {
		$changes[] = array( 'pid' => '', 'text' => 'Note from ' . (int) $rec['year'] . ' · Not carried' );
	}
	$main   = ogc_reg_main_nights( $cfg );
	$offer  = ogc_reg_nights( $cfg );
	$had    = (array) ( isset( $s['nights'] ) ? $s['nights'] : array() );
	$lastyr = ogc_reg_main_nights( ogc_reg_cfg( $rec['year'] ) );
	$all    = count( array_diff( $lastyr, $had ) ) === 0;
	$nights = array_values( array_filter( $offer, function ( $n ) use ( $had, $all ) {
		return ogc_reg_is_early( $n ) ? in_array( $n, $had, true ) : ( $all || in_array( $n, $had, true ) );
	} ) );
	if ( ! $nights ) {
		$nights = $main;
	}
	$draft = array(
		'household'   => $d['household'],
		'helper'      => $d['helper'],
		'people'      => $people,
		'stay'        => array_merge( array_intersect_key( $s, array_flip( array( 'type', 'rooms', 'roomsSet', 'linens', 'linenFor', 'mattresses', 'ground', 'walker', 'nearW', 'nearM', 'near', 'arrive', 'campers', 'camperLen' ) ) ), array( 'nights' => 'elsewhere' === ( isset( $s['type'] ) ? $s['type'] : '' ) ? array() : $nights, 'parentEmail' => isset( $s['parentEmail'] ) ? $s['parentEmail'] : '', 'linenChoice' => ! empty( $s['linenChoice'] ) ? $s['linenChoice'] : ( empty( $s['linens'] ) && ! array_filter( wp_list_pluck( $people, 'linens' ) ) ? 'own' : 'order' ) ) ),
		'pickupWho'   => isset( $d['pickupWho'] ) ? $d['pickupWho'] : array(),
		'pay'         => isset( $d['pay'] ) ? $d['pay'] : 'card',
		'gift'        => 0,
	);
	$clean = ogc_reg_clean( $draft, $year );
	$price = ogc_reg_price( $clean, $year );
	$st    = $clean['stay'];
	// What costs money and is carried over is named, never kept quietly (polish 2): "Kept from 2026:
	// 3 linen packets · 1 air mattress", with Change to Where you'll stay.
	$kept = array_values( array_filter( explode( ' · ', ogc_reg_linen_words( $clean ) ), function ( $w ) { return false !== stripos( $w, 'packet' ); } ) );
	if ( $st['mattresses'] ) {
		$kept[] = ogc_reg_plural( (int) $st['mattresses'], 'air mattress', 'air mattresses' );
	}
	if ( $kept ) {
		$changes[] = array( 'pid' => '', 'text' => 'Kept from ' . (int) $rec['year'] . ': ' . implode( ' · ', $kept ), 'open' => 'stay' );
	}
	$TY    = array( 'dorm' => ogc_reg_plural( (int) $st['rooms'], 'dorm room' ), 'camper' => 'Camper lot', 'elsewhere' => 'Off campus', 'yf' => ogc_reg_halls_words( $clean ) );
	return array(
		'key'     => isset( $d['rid'] ) ? $d['rid'] : (string) $rec['id'],
		'label'   => ogc_reg_label( $d ),
		'line'    => ogc_reg_plural( count( $clean['people'] ), 'person', 'people' ) . ' · ' . $TY[ $st['type'] ],
		'names'   => array_map( 'ogc_reg_first', wp_list_pluck( $clean['people'], 'name' ) ),
		'draft'   => $clean,
		'changes' => $changes,
		'was'     => (int) ( isset( $d['price']['lodging_cents'] ) ? $d['price']['lodging_cents'] : 0 ),
		'now'     => $price['lodging_cents'],
		'from'    => (int) $rec['year'],
		// Phones are cleared after a Conference (the security plan): the form asks for this year's.
		'cleared' => ! empty( $d['cleared'] ),
	);
}

function ogc_reg_rest_form( WP_REST_Request $req ) {
	$y     = (int) $req['year'];
	$row   = ogc_year_get( $y );
	$cfg   = ogc_reg_cfg( $y );
	$today = ogc_reg_today( $y, $req );
	$me      = ogc_current_email();
	$member  = ogc_is_member( $y );
	$phase   = $row ? ogc_reg_phase( $y, $today ) : 'none';
	$blocked = 'open' === $phase && ogc_reg_samples_block( $y, $req );
	if ( $blocked ) {
		$phase = 'none';
	}
	$set = ogc_reg_settings( $y );
	$out    = array(
		'year'    => $y,
		'phase'   => $phase,
		'today'   => $today,
		'start'   => $row && isset( $row['start'] ) ? $row['start'] : '',
		'end'     => $row && isset( $row['end'] ) ? $row['end'] : '',
		'cfg'     => ogc_reg_public_cfg( $cfg ),
		'left'    => ogc_reg_left( $y ),
		'card'    => (bool) ogc_pay_driver(),
		'dev'     => ogc_reg_local(),
		'member'  => $member,
		// Who does what is the COA's choice (owner_<part>); blank until they choose, never assumed.
		'owner'   => ogc_reg_c( $set, 'owner_registration' ),
		'yfOwner' => ogc_reg_c( $set, 'owner_youngfolks' ),
		'ptOwner' => ogc_reg_c( $set, 'owner_preteens' ),
		// Past check_by: no checks; the COA's late choice instead (late_pay: checkin or card).
		'late'    => ogc_reg_checks_closed( $y, $today ),
		'latePay' => 'card' === ogc_reg_c( $cfg, 'late_pay' ) ? 'card' : 'checkin',
		// For members only: why registration hasn't opened on its date.
		'blocked' => $member && $blocked ? 'samples' : '',
		'me'      => $me ? array( 'email' => $me, 'name' => wp_get_current_user()->display_name ) : null,
		'mine'    => array(),
		'reuse'   => array(),
		'taken'   => array(),
		'samples' => $member ? ogc_reg_has_samples( $y ) : false,
		// The days and the meals, from the server: the form needs them before the schedule is posted.
		'days'    => ogc_reg_days( $y ),
		'meals'   => ogc_reg_meals( $y ),
	);
	if ( $me ) {
		foreach ( ogc_reg_mine( $y, $me ) as $r ) {
			// Enough for the page's one status phrase (statusWords: "Paid $677", "Check to come"), the same
			// words as Your sign-ups.
			$ap            = isset( $r['data']['approval']['state'] ) ? array( 'state' => $r['data']['approval']['state'], 'at' => isset( $r['data']['approval']['at'] ) ? $r['data']['approval']['at'] : '', 'held' => ! empty( $r['data']['approval']['held'] ) ) : null;
			$r['data']    += array( 'rid' => '', 'status' => 'registered' );   // an older or partial record
			$out['mine'][] = array( 'id' => $r['id'], 'rid' => $r['data']['rid'], 'label' => ogc_reg_label( $r['data'] ), 'status' => $r['data']['status'], 'data' => array( 'status' => $r['data']['status'], 'money' => isset( $r['data']['money'] ) ? $r['data']['money'] : array(), 'pay' => isset( $r['data']['pay'] ) ? $r['data']['pay'] : '', 'approval' => $ap ), 'rooms' => ogc_reg_rooms_of( $r ) );
		}
		foreach ( ogc_reg_mine( $y - 1, $me ) as $r ) {
			if ( 'cancelled' !== ( isset( $r['data']['status'] ) ? $r['data']['status'] : '' ) && ( ! $r['sample'] || ogc_reg_local() ) && ! empty( $r['data']['people'] ) ) {
				$out['reuse'][] = ogc_reg_reuse( $r, $y );
			}
		}
	}
	// When households choose rooms on the map: the rooms already taken, never by whom.
	if ( 'households' === ogc_reg_c( $cfg, 'room_choice' ) ) {
		$t = array();
		$s = ogc_state_get( $y, 'rooms' );
		foreach ( $s && is_array( $s['value'] ) ? $s['value'] : array() as $list ) {
			foreach ( (array) $list as $id ) {
				$t[ $id ] = true;
			}
		}
		foreach ( ogc_records( $y, 'registrations' ) as $r ) {
			if ( ! ogc_reg_is_household( $r ) && 'cancelled' !== ( isset( $r['data']['status'] ) ? $r['data']['status'] : '' ) ) {
				foreach ( (array) ( isset( $r['data']['stay']['chosen'] ) ? $r['data']['stay']['chosen'] : array() ) as $id ) {
					$t[ $id ] = true;
				}
			}
		}
		$out['taken'] = array_keys( $t );
	}
	return rest_ensure_response( $out );
}

/** The answers cleaned, checked and priced (the form asks before Pay, and to show a change's balance). */
function ogc_reg_rest_check( WP_REST_Request $req ) {
	$y   = (int) $req['year'];
	$id  = (int) $req->get_param( 'id' );
	$rec = $id ? ogc_record_get( $id ) : null;
	if ( $rec && ( ! ogc_reg_may( $rec ) || (int) $rec['year'] !== $y ) ) {
		$rec = null;
	}
	$d    = ogc_reg_clean( $req->get_param( 'data' ), $y );
	$errs = ogc_reg_problems( $d, $y, ogc_is_member( $y ) );
	$errs = array_merge( $errs, ogc_reg_fit_stock( $d, $y, $rec ? $rec['id'] : 0 ), ogc_reg_fit_rooms( $d, $y, $rec ? $rec['id'] : 0 ) );
	$cfg  = $rec ? ogc_reg_cfg_for( $y, $rec['data'] ) : ogc_reg_cfg( $y );
	return rest_ensure_response( array( 'data' => $d, 'price' => ogc_reg_price( $d, $y, $cfg ), 'errors' => (object) $errs, 'left' => ogc_reg_left( $y, $rec ? $rec['id'] : 0 ) ) );
}

/* ------------------------------------------------------------------ registering */

/** Start a card payment for what's due: a pending charge, and the provider's checkout address. */
function ogc_reg_start_card( $rec, $cents, $idem, $then = 'mine' ) {
	$drv = ogc_pay_driver();
	if ( ! $drv ) {
		return ogc_reg_err( 'ogc_no_card', 'Card payment isn’t available · Pay by check', 400 );
	}
	$old = ogc_pay_by_idem( $rec['id'], $idem );
	if ( $old && 'pending' === $old['status'] && 'charge' === $old['kind'] && ! empty( $old['ref'] ) ) {
		return array( 'checkout' => $old['ref'], 'payment' => $old['id'] );
	}
	// A charge started before and never answered gives way to this one.
	foreach ( ogc_pay_rows( $rec['id'] ) as $p ) {
		if ( 'charge' === $p['kind'] && 'pending' === $p['status'] ) {
			ogc_pay_set( $p['id'], array( 'status' => 'cancelled' ) );
		}
	}
	$token = strtolower( wp_generate_password( 32, false, false ) );
	$pid   = ogc_pay_add( $rec, 'charge', 'card', $cents, 'pending', array( 'driver' => $drv['name'], 'idem' => $idem, 'token' => hash( 'sha256', $token ) ) );
	$p     = ogc_pay_get( $pid );
	// Where the provider sends the payer back: Registered (a new registration) or Your sign-ups, with
	// this charge named so the page can say Paid, Declined or Cancelled. Locally the preview date rides along.
	$back = array( 'year' => (int) $rec['year'], 'view' => 'done' === $then ? 'done' : 'mine', 'id' => (int) $rec['id'], 'paid' => $pid );
	$req  = isset( $GLOBALS['ogc_reg_req'] ) ? $GLOBALS['ogc_reg_req'] : null;
	if ( $req && ogc_pay_test_on() && preg_match( '/^\d{4}-\d\d-\d\d$/', (string) $req->get_param( 'as_of' ) ) ) {
		$back['as-of'] = (string) $req->get_param( 'as_of' );
	}
	$url = call_user_func( $drv['start'], array_merge( $p, array( 'token' => $token, 'currency' => ogc_pay_currency(), 'return' => ogc_url( 'register', $back ) ) ), $rec );
	if ( is_wp_error( $url ) ) {
		ogc_pay_set( $pid, array( 'status' => 'failed', 'note' => 'Not started' ) );
		return $url;
	}
	// The checkout address is kept as the charge's reference until the provider answers (a retry with
	// the same key goes back to the same checkout).
	ogc_pay_set( $pid, array( 'ref' => substr( $url, 0, 128 ) === $url ? $url : '' ) );
	return array( 'checkout' => $url, 'payment' => $pid );
}

/** A check to come for what's due: the check already coming grows, or one is added. */
function ogc_reg_check_to_come( $rec, $cents ) {
	foreach ( ogc_pay_rows( $rec['id'] ) as $p ) {
		if ( 'check' === $p['kind'] && 'pending' === $p['status'] ) {
			ogc_pay_set( $p['id'], array( 'cents' => $p['cents'] + $cents ) );
			return;
		}
	}
	ogc_pay_add( $rec, 'check', 'check', $cents, 'pending' );
}

function ogc_reg_idem( WP_REST_Request $req ) {
	$k = (string) $req->get_param( 'idem' );
	return preg_match( '/^[A-Za-z0-9_-]{8,64}$/', $k ) ? $k : '';
}

function ogc_reg_rest_create( WP_REST_Request $req ) {
	$y      = (int) $req['year'];
	$member = ogc_is_member( $y );
	$row    = ogc_year_get( $y );
	if ( ! $row ) {
		return ogc_reg_err( 'ogc_not_found', 'Not found.', 404 );
	}
	$today = ogc_reg_today( $y, $req );
	$phase = ogc_reg_phase( $y, $today );
	if ( 'open' === $phase && ogc_reg_samples_block( $y, $req ) ) {
		$phase = 'none';
	}
	if ( ! $member && 'open' !== $phase ) {
		return ogc_reg_err( 'ogc_closed', 'before' === $phase ? 'Not open yet' : 'Closed', 403, array( 'phase' => $phase ) );
	}
	$me   = ogc_current_email();
	$d    = ogc_reg_clean( $req->get_param( 'data' ), $y );
	$errs = array_merge( ogc_reg_problems( $d, $y, $member ), ogc_reg_pay_problems( $d, $y, $today, $member ), ogc_reg_fit_rooms( $d, $y, 0 ) );
	// A new registration says whether it brings its own linens or orders packets (asked once, for
	// everyone in a dorm room or a hall).
	if ( ! $member && ogc_reg_linen_unchosen( $d, ogc_reg_cfg( $y ) ) ) {
		$errs['stay.linenChoice'] = 'Choose linens';
	}
	// Not a member: the registration is theirs (their email), or they're the helper who made it.
	if ( ! $member ) {
		if ( $d['helper']['on'] ? $d['helper']['email'] !== $me : $d['household']['email'] !== $me ) {
			$errs[ $d['helper']['on'] ? 'helper.email' : 'household.email' ] = 'Use the email you confirmed';
		}
	}
	if ( $errs ) {
		return ogc_reg_err( 'ogc_invalid', 'Check the form', 400, array( 'errors' => $errs ) );
	}
	$idem     = ogc_reg_idem( $req );
	$waitlist = ogc_reg_bool( $req->get_param( 'waitlist' ) );
	$source   = $member && in_array( $req->get_param( 'source' ), array( 'desk', 'paper', 'phone', 'helper' ), true ) ? $req->get_param( 'source' ) : ( $d['helper']['on'] ? 'helper' : 'online' );
	if ( ! ogc_reg_lock( $y ) ) {
		return ogc_reg_err( 'ogc_busy', 'Busy · Try again', 503 );
	}
	try {
		// A retried Register (a double tap, a slow network) gets the same registration back.
		if ( $idem ) {
			foreach ( ogc_reg_mine( $y, $me ) as $r ) {
				if ( isset( $r['data']['idem'] ) && $r['data']['idem'] === $idem ) {
					$p = ogc_pay_by_idem( $r['id'], $idem );
					return rest_ensure_response( array( 'item' => ogc_reg_view( $r ), 'next' => $p && 'pending' === $p['status'] && 'charge' === $p['kind'] && $p['ref'] ? array( 'checkout' => $p['ref'] ) : null, 'again' => true ) );
				}
			}
		}
		$stock = ogc_reg_fit_stock( $d, $y, 0, $waitlist );
		if ( $stock ) {
			return ogc_reg_err( 'ogc_stock', 'Not enough left', 409, array( 'errors' => $stock, 'data' => $d ) );
		}
		$price = ogc_reg_price( $d, $y );
		if ( (int) $req->get_param( 'expect' ) !== $price['total_cents'] ) {
			return ogc_reg_err( 'ogc_total', 'Total updated to ' . ogc_reg_money( $price['total_cents'] ), 409, array( 'price' => $price ) );
		}
		$card = 'card' === $d['pay'] && $price['total_cents'] > 0;
		if ( $card && ! ogc_pay_driver() ) {
			return ogc_reg_err( 'ogc_no_card', 'Card payment isn’t available · Pay by check', 400 );
		}
		$owner           = '' !== $d['household']['email'] && ogc_reg_email_ok( $d['household']['email'] ) ? $d['household']['email'] : ( $d['helper']['on'] ? $d['helper']['email'] : '' );
		$data            = $d;
		$data['rid']     = $data['id'] = ogc_reg_next_rid( $y );
		$data['status']  = $waitlist ? 'waitlist' : 'registered';
		$data['price']   = array_merge( $price, array( 'prices' => ogc_reg_price_snapshot( ogc_reg_cfg( $y ) ), 'at' => ogc_reg_today( $y ) ) );
		$data['managers'] = $d['helper']['on'] && $d['helper']['email'] && $d['helper']['email'] !== $owner ? array( $d['helper']['email'] ) : array();
		$data['source']  = $source;
		$data['at']      = ogc_reg_today( $y );
		$data['created'] = ogc_now();
		$data['idem']    = $idem;
		$data['history'] = array();
		$data['flags']   = array( 'dup' => ogc_reg_dups( $y, $d, 0 ) );
		// Entered at the desk with a child and no grown-up on it: for Lodging's Review.
		if ( array_filter( $d['people'], function ( $p ) { return 'child' === $p['kind']; } ) && ! array_filter( $d['people'], function ( $p ) { return 'adult' === $p['kind']; } ) ) {
			$data['flags']['noAdult'] = true;
		}
		$token           = ogc_reg_needs_approval( $d ) ? ogc_reg_approval_start( $data, $y ) : '';
		$id              = ogc_record_insert( $y, 'registrations', $data, $owner, false, $source );
		if ( ! $id ) {
			return ogc_reg_err( 'ogc_db', 'Not saved · Try again', 500 );
		}
		$rec  = ogc_record_get( $id );
		$next = null;
		if ( ! $waitlist && $price['total_cents'] > 0 ) {
			$desk = $member ? (string) $req->get_param( 'desk_paid' ) : '';
			if ( in_array( $desk, array( 'cash', 'check', 'card' ), true ) ) {
				ogc_pay_add( $rec, 'desk', $desk, $price['total_cents'], 'paid', array( 'note' => 'At the desk' ) );
			} elseif ( $card && ! ( $token && 'yes' === ogc_reg_c( ogc_reg_cfg( $y ), 'approval_before_pay' ) ) ) {
				$next = ogc_reg_start_card( $rec, $price['total_cents'], $idem ? $idem : wp_generate_password( 16, false, false ), 'done' );
				if ( is_wp_error( $next ) ) {
					$next = null;
				}
			} elseif ( 'check' === $d['pay'] ) {
				ogc_pay_add( $rec, 'check', 'check', $price['total_cents'], 'pending' );
			}
			// 'checkin': nothing in the ledger; it's due at check-in (Payment due, "Due at check-in").
		}
		// Paying by card: the parent is asked once the card is answered as paid, never before.
		if ( $next && $token ) {
			$rec['data']['approval']['held']    = true;
			$rec['data']['approval']['sent_at'] = '';
			$token                              = '';
		}
		$rec = ogc_reg_save( $rec, $rec['data'] );
	} finally {
		ogc_reg_unlock( $y );
	}
	ogc_log( 'reg_add', $y, 'registrations', array( 'id' => $rec['id'], 'source' => $source ) );
	if ( 'desk' !== $source ) {
		ogc_reg_draft_drop( $y, $me );
	}
	do_action( 'ogc_record_saved', $rec, 'create', $req );
	if ( ! $next ) {
		ogc_reg_mail_receipt( $rec, 'new' );
	}
	if ( $token ) {
		ogc_reg_mail_parent( $rec, $token );
	}
	return new WP_REST_Response( array( 'item' => ogc_reg_view( $rec ), 'next' => $next ? array( 'checkout' => $next['checkout'] ) : null ), 201 );
}

function ogc_reg_rest_mine( WP_REST_Request $req ) {
	$y   = (int) $req['year'];
	$out = array();
	foreach ( ogc_reg_mine( $y, ogc_current_email() ) as $r ) {
		$out[] = ogc_reg_view( $r );
	}
	return rest_ensure_response( array( 'items' => $out, 'me' => array( 'email' => ogc_current_email(), 'name' => wp_get_current_user()->display_name ) ) );
}

/* ------------------------------------------------------------------ changing */

function ogc_reg_rest_update( WP_REST_Request $req ) {
	$rec    = ogc_record_get( (int) $req['id'] );
	$y      = (int) $rec['year'];
	$old    = $rec['data'];
	$member = ogc_is_member( $y );
	$today  = ogc_reg_today( $y, $req );
	$phase  = ogc_reg_phase( $y, $today );
	if ( 'cancelled' === $old['status'] ) {
		return ogc_reg_err( 'ogc_cancelled', 'Cancelled', 403 );
	}
	if ( ! $member && 'held' === $phase ) {
		return ogc_reg_err( 'ogc_closed', 'Held · No changes', 403 );
	}
	if ( (int) $req->get_param( 'v' ) !== (int) ( isset( $old['_v'] ) ? $old['_v'] : 0 ) ) {
		return ogc_reg_err( 'ogc_changed', 'Changed since you opened it', 409, array( 'item' => ogc_reg_view( $rec ) ) );
	}
	$in = (array) $req->get_param( 'data' );
	// After the form closes, a household changes only its contact and its preteens' details online
	// (the rest at the desk, or by asking Lodging).
	if ( ! $member && 'closed' === $phase ) {
		$keep = $old;
		foreach ( array( 'household', 'helper', 'contacts', 'preteens', 'pickupWho', 'pickupOther' ) as $k ) {
			if ( isset( $in[ $k ] ) ) {
				$keep[ $k ] = $in[ $k ];
			}
		}
		$in = $keep;
	}
	$d = ogc_reg_clean( $in, $y );
	// A gift already given isn't taken back by a change.
	$d['gift'] = max( $d['gift'], (int) ( isset( $old['gift'] ) ? $old['gift'] : 0 ) );
	// The owner stays the owner (a household changing its email asks Lodging).
	if ( ! $member ) {
		$d['household']['email'] = isset( $old['household']['email'] ) ? $old['household']['email'] : $d['household']['email'];
	}
	$how  = in_array( $req->get_param( 'pay' ), array( 'card', 'check', 'checkin' ), true ) ? $req->get_param( 'pay' ) : ( isset( $old['pay'] ) ? $old['pay'] : 'check' );
	$errs = array_merge( ogc_reg_problems( $d, $y, $member ), ogc_reg_fit_rooms( $d, $y, $rec['id'] ) );
	// Paying the difference by check after checks have closed (or at check-in before then) is refused,
	// unless that's how it was already being paid.
	if ( $how !== ( isset( $old['pay'] ) ? $old['pay'] : '' ) ) {
		$errs = array_merge( $errs, ogc_reg_pay_problems( array_merge( $d, array( 'pay' => $how ) ), $y, $today, $member ) );
	}
	if ( $errs ) {
		return ogc_reg_err( 'ogc_invalid', 'Check the form', 400, array( 'errors' => $errs ) );
	}
	$idem = ogc_reg_idem( $req );
	if ( ! ogc_reg_lock( $y ) ) {
		return ogc_reg_err( 'ogc_busy', 'Busy · Try again', 503 );
	}
	$next = null;
	try {
		$stock = ogc_reg_fit_stock( $d, $y, $rec['id'], 'waitlist' === $old['status'] );
		if ( $stock ) {
			return ogc_reg_err( 'ogc_stock', 'Not enough left', 409, array( 'errors' => $stock, 'data' => $d ) );
		}
		$price = ogc_reg_price( $d, $y, ogc_reg_cfg_for( $y, $old ) );
		if ( (int) $req->get_param( 'expect' ) !== $price['total_cents'] ) {
			return ogc_reg_err( 'ogc_total', 'Total updated to ' . ogc_reg_money( $price['total_cents'] ), 409, array( 'price' => $price ) );
		}
		$data = $d;
		foreach ( ogc_reg_server_keys() as $k ) {
			if ( array_key_exists( $k, $old ) ) {
				$data[ $k ] = $old[ $k ];
			}
		}
		// Lodging's own notes on the household stay.
		foreach ( $old as $k => $v ) {
			if ( ! array_key_exists( $k, $data ) ) {
				$data[ $k ] = $v;
			}
		}
		$data['price'] = array_merge( $price, array( 'prices' => isset( $old['price']['prices'] ) ? $old['price']['prices'] : ogc_reg_price_snapshot( ogc_reg_cfg( $y ) ), 'at' => isset( $old['price']['at'] ) ? $old['price']['at'] : '' ) );
		$diff          = ogc_reg_diff( $old, $data );
		if ( ! $diff ) {
			return rest_ensure_response( array( 'item' => ogc_reg_view( $rec ), 'next' => null, 'same' => true ) );
		}
		ogc_reg_note_history( $data, $diff );
		if ( ogc_reg_placed( $y, isset( $old['rid'] ) ? $old['rid'] : '' ) && preg_match( '/added|removed|night|Rooms|Dorm|Camper|Off campus/', $diff ) ) {
			$data['flags']            = isset( $data['flags'] ) ? (array) $data['flags'] : array();
			$data['flags']['changed'] = $today;
		}
		$data['flags']        = isset( $data['flags'] ) ? (array) $data['flags'] : array();
		$data['flags']['dup'] = ogc_reg_dups( $y, $d, $rec['id'] );
		// A parent's approval: asked again when a minor now comes alone, or the parent's email changed.
		$token = '';
		if ( ogc_reg_needs_approval( $d ) ) {
			$ap = isset( $old['approval'] ) ? $old['approval'] : null;
			if ( ! $ap || $ap['to'] !== $d['stay']['parentEmail'] || 'declined' === $ap['state'] ) {
				$token = ogc_reg_approval_start( $data, $y );
			}
		} else {
			unset( $data['approval'] );
		}
		$cfg         = ogc_reg_cfg( $y );
		$refund_ok   = ( ! ogc_reg_c( $cfg, 'refunds_by' ) || $today <= ogc_reg_c( $cfg, 'refunds_by' ) ) && 'waitlist' !== $old['status'];
		$owed        = ogc_reg_rebalance( $rec, $old, $price['total_cents'], $refund_ok, 'Change · ' . mb_substr( $diff, 0, 120 ) );
		$data['pay'] = $how;
		$rec         = ogc_reg_save( $rec, $data );
		if ( $owed > 0 && 'waitlist' !== $old['status'] ) {
			if ( 'card' === $how ) {
				$next = ogc_reg_start_card( $rec, $owed, $idem ? $idem : wp_generate_password( 16, false, false ) );
				if ( is_wp_error( $next ) ) {
					$next = null;
				}
			} elseif ( 'check' === $how ) {
				ogc_reg_check_to_come( $rec, $owed );
			}
			$rec = ogc_reg_refresh( $rec['id'] );
		}
	} finally {
		ogc_reg_unlock( $y );
	}
	ogc_log( 'reg_set', $y, 'registrations', array( 'id' => $rec['id'] ) );
	do_action( 'ogc_record_saved', $rec, 'update', $req );
	if ( ! $next ) {
		ogc_reg_mail_receipt( $rec, 'changed' );
	}
	// Paying the difference by card: the parent is asked once it's paid.
	if ( $token && $next ) {
		$data                             = $rec['data'];
		$data['approval']['held']         = true;
		$data['approval']['sent_at']      = '';
		$rec                              = ogc_reg_save( $rec, $data );
		$token                            = '';
	}
	if ( $token ) {
		ogc_reg_mail_parent( $rec, $token );
	}
	return rest_ensure_response( array( 'item' => ogc_reg_view( $rec ), 'next' => $next ? array( 'checkout' => $next['checkout'] ) : null, 'changed' => $diff ) );
}

/**
 * After a registration's total changed: what's paid or promised (card, a check to come) against the new
 * total. Less than before: a check still to come shrinks first; what's left over is refunded (until the
 * refund date), and a refund already asked for is made the right size. Returns what's still owed (paid
 * by card or added to the check by the caller); any refund still waiting is dropped first.
 */
function ogc_reg_rebalance( $rec, $old, $total, $refund_ok, $note ) {
	$m         = ogc_pay_sum( ogc_pay_rows( $rec['id'] ) );
	$committed = $m['paid'] + $m['check'] + $m['pending'];
	if ( $total < $committed && $m['check'] ) {
		$cut = min( $committed - $total, $m['check'] );
		foreach ( ogc_pay_rows( $rec['id'] ) as $p ) {
			if ( $cut > 0 && 'check' === $p['kind'] && 'pending' === $p['status'] ) {
				$c = min( $cut, $p['cents'] );
				ogc_pay_set( $p['id'], $c === $p['cents'] ? array( 'status' => 'cancelled' ) : array( 'cents' => $p['cents'] - $c ) );
				$cut -= $c;
			}
		}
		$m         = ogc_pay_sum( ogc_pay_rows( $rec['id'] ) );
		$committed = $m['paid'] + $m['check'] + $m['pending'];
	}
	$target = $refund_ok ? max( 0, $committed - $total ) : $m['refund'];
	if ( $target < $m['refund'] ) {
		$less = $m['refund'] - $target;
		foreach ( array_reverse( ogc_pay_rows( $rec['id'] ) ) as $p ) {
			if ( $less > 0 && 'refund' === $p['kind'] && in_array( $p['status'], array( 'requested', 'approved' ), true ) ) {
				$c = min( $less, $p['cents'] );
				ogc_pay_set( $p['id'], $c === $p['cents'] ? array( 'status' => 'cancelled', 'note' => 'Not needed after a change' ) : array( 'cents' => $p['cents'] - $c ) );
				$less -= $c;
			}
		}
	} elseif ( $target > $m['refund'] ) {
		ogc_pay_add( $rec, 'refund', 'check' === ( isset( $old['pay'] ) ? $old['pay'] : '' ) ? 'check' : 'card', $target - $m['refund'], 'requested', array( 'note' => $note ) );
	}
	return max( 0, $total - $committed );
}

/** Pay what's due: by card (to the provider's checkout) or a check to come (until checks close). */
function ogc_reg_rest_pay( WP_REST_Request $req ) {
	$rec = ogc_record_get( (int) $req['id'] );
	$v   = ogc_reg_view( $rec );
	if ( ! $v['can']['pay'] ) {
		return ogc_reg_err( 'ogc_nothing_due', 'Nothing due', 400 );
	}
	// As of today (a check past check_by no longer counts as coming).
	$due = (int) $v['data']['money']['due'] - (int) $v['data']['money']['check'];
	if ( 'check' === $req->get_param( 'method' ) ) {
		if ( ogc_reg_checks_closed( (int) $rec['year'], ogc_reg_today( (int) $rec['year'], $req ) ) && ! ogc_is_member( $rec['year'] ) ) {
			return ogc_reg_err( 'ogc_checks_closed', 'Checks closed · Pay by card', 400 );
		}
		ogc_reg_check_to_come( $rec, $due );
		$rec = ogc_reg_refresh( $rec['id'] );
		$rec = ogc_reg_approval_release( $rec );
		ogc_reg_mail_receipt( $rec, 'changed' );
		return rest_ensure_response( array( 'item' => ogc_reg_view( $rec ), 'next' => null ) );
	}
	$idem = ogc_reg_idem( $req );
	$next = ogc_reg_start_card( $rec, $due, $idem ? $idem : wp_generate_password( 16, false, false ) );
	if ( is_wp_error( $next ) ) {
		return $next;
	}
	return rest_ensure_response( array( 'item' => ogc_reg_view( ogc_reg_refresh( $rec['id'] ) ), 'next' => array( 'checkout' => $next['checkout'] ) ) );
}

/** A refund requested (and, for the lists' Payments view, a credit ask as v3 kept them). */
function ogc_reg_refund_ask( $rec, $cents, $note, $nights = array() ) {
	if ( $cents <= 0 ) {
		return;
	}
	ogc_pay_add( $rec, 'refund', 'check' === ( isset( $rec['data']['pay'] ) ? $rec['data']['pay'] : '' ) ? 'check' : 'card', $cents, 'requested', array( 'note' => $note ) );
	ogc_record_insert( $rec['year'], 'credits', array( 'id' => $rec['data']['rid'], 'household' => ogc_reg_label( $rec['data'] ), 'nights' => $nights, 'amount' => $cents / 100, 'at' => ogc_reg_today( $rec['year'] ), 'email' => $rec['email'], 'note' => $note ), $rec['email'], (bool) $rec['sample'], 'web' );
}

/** Cancel: kept as Cancelled (not erased); what's been paid comes back, but for a gift. */
function ogc_reg_cancel( $rec, $why = 'Cancelled' ) {
	$y    = (int) $rec['year'];
	$data = $rec['data'];
	$cfg  = ogc_reg_cfg( $y );
	foreach ( ogc_pay_rows( $rec['id'] ) as $p ) {
		if ( 'pending' === $p['status'] ) {
			ogc_pay_set( $p['id'], array( 'status' => 'cancelled' ) );
		}
	}
	$m    = ogc_pay_sum( ogc_pay_rows( $rec['id'] ) );
	$gift = (int) ( isset( $data['price']['gift_cents'] ) ? $data['price']['gift_cents'] : 0 );
	$back = max( 0, $m['paid'] - $m['refund'] - $gift );
	$ok   = ! ogc_reg_c( $cfg, 'refunds_by' ) || ogc_reg_today( $y ) <= ogc_reg_c( $cfg, 'refunds_by' );
	$data['status']       = 'cancelled';
	$data['cancelled_at'] = ogc_now();
	ogc_reg_note_history( $data, $why );
	$rec = ogc_reg_save( $rec, $data );
	if ( $back && $ok ) {
		ogc_reg_refund_ask( $rec, $back, $why );
		$rec = ogc_reg_refresh( $rec['id'] );
	}
	ogc_log( 'reg_cancel', $y, 'registrations', array( 'id' => $rec['id'] ) );
	return $rec;
}

function ogc_reg_rest_cancel( WP_REST_Request $req ) {
	$rec = ogc_record_get( (int) $req['id'] );
	$v   = ogc_reg_view( $rec );
	if ( ! $v['can']['cancel'] && ! ogc_is_member( $rec['year'] ) ) {
		// Who to ask is the COA's choice of owner, never assumed to be Lodging.
		$who = trim( ogc_reg_c( ogc_reg_settings( $rec['year'] ), 'owner_registration' ) );
		return ogc_reg_err( 'ogc_no_cancel', $who ? 'Ask the ' . $who . ' at check-in' : 'Ask at check-in', 403 );
	}
	$rec = ogc_reg_cancel( $rec );
	ogc_reg_mail_receipt( $rec, 'cancelled' );
	return rest_ensure_response( array( 'item' => ogc_reg_view( $rec ) ) );
}

/** Leaving early, during the week: the nights of the people leaving (everyone, unless `who` names some by
 * pid) end at the night chosen; what's not used comes back once the keys are back (a refund requested,
 * until the refund date). Harold may go home Sunday while Ruth stays. */
function ogc_reg_rest_leave( WP_REST_Request $req ) {
	$rec  = ogc_record_get( (int) $req['id'] );
	$v    = ogc_reg_view( $rec );
	$y    = (int) $rec['year'];
	$old  = $rec['data'];
	$last = (string) $req->get_param( 'last' );
	if ( ! $v['can']['leave'] && ! ogc_is_member( $y ) ) {
		return ogc_reg_err( 'ogc_no_leave', 'Only during the Conference', 403 );
	}
	$cfg    = ogc_reg_cfg( $y );
	$nights = ogc_reg_nights( $cfg );
	$at     = array_search( $last, $nights, true );
	if ( false === $at ) {
		return ogc_reg_err( 'ogc_bad_night', 'Choose a night', 400 );
	}
	// The last night is last night at the earliest (leaving this morning), never one already past.
	if ( ogc_reg_night_date( ogc_reg_days( $y ), $last ) < ogc_reg_add_days( ogc_reg_today( $y, $req ), -1 ) ) {
		return ogc_reg_err( 'ogc_bad_night', 'Choose a night from last night on', 400 );
	}
	$keep = array_slice( $nights, 0, $at + 1 );
	$pids = wp_list_pluck( $old['people'], 'pid' );
	$who  = $req->get_param( 'who' );
	$who  = is_array( $who ) ? array_values( array_intersect( $pids, array_map( 'strval', $who ) ) ) : $pids;
	if ( ! $who ) {
		return ogc_reg_err( 'ogc_bad_who', 'Choose who’s leaving', 400 );
	}
	// No child is left in a room with no grown-up.
	$stay = array_filter( $old['people'], function ( $p ) use ( $who ) { return ! in_array( $p['pid'], $who, true ); } );
	$grown = function ( $p ) { return 'adult' === $p['kind']; };
	if ( array_filter( $old['people'], $grown ) && ! array_filter( $stay, $grown ) ) {
		$alone = array_filter( $stay, function ( $p ) { return 'child' === $p['kind'] || ! empty( $p['minor'] ); } );
		if ( $alone ) {
			return ogc_reg_err( 'ogc_alone', implode( ' and ', array_map( 'ogc_reg_first', wp_list_pluck( $alone, 'name' ) ) ) . ' would stay with no grown-up', 400 );
		}
	}
	$in    = $old;
	$any   = false;
	$names = array();
	foreach ( $in['people'] as &$p ) {
		$mine        = ogc_reg_nights_for( $p, $old, $cfg );
		$p['nights'] = in_array( $p['pid'], $who, true ) ? array_values( array_intersect( $mine, $keep ) ) : $mine;
		if ( count( $p['nights'] ) < count( $mine ) ) {
			$any     = true;
			$names[] = ogc_reg_first( $p['name'] );
		}
	}
	unset( $p );
	// The household's nights follow its people (ogc_reg_clean: every night one of them is here).
	$in['stay']['perPerson'] = true;
	if ( ! $any ) {
		return ogc_reg_err( 'ogc_same', 'No change', 400 );
	}
	$d     = ogc_reg_clean( $in, $y );
	$d['gift'] = (int) ( isset( $old['gift'] ) ? $old['gift'] : 0 );
	$price = ogc_reg_price( $d, $y, ogc_reg_cfg_for( $y, $old ) );
	$data  = $d;
	foreach ( ogc_reg_server_keys() as $k ) {
		if ( array_key_exists( $k, $old ) ) {
			$data[ $k ] = $old[ $k ];
		}
	}
	$data['price'] = array_merge( $price, array( 'prices' => isset( $old['price']['prices'] ) ? $old['price']['prices'] : array(), 'at' => isset( $old['price']['at'] ) ? $old['price']['at'] : '' ) );
	$dropped       = array_values( array_diff( $old['stay']['nights'], $d['stay']['nights'] ) );
	ogc_reg_note_history( $data, ( count( $who ) < count( $pids ) ? implode( ', ', $names ) . ' leaving after ' : 'Leaving after ' ) . $last . ( $dropped ? ' · ' . ogc_reg_plural( count( $dropped ), 'night' ) . ' not used' : '' ) );
	$data['flags']            = isset( $data['flags'] ) ? (array) $data['flags'] : array();
	$data['flags']['changed'] = ogc_reg_today( $y );
	$rec                      = ogc_reg_save( $rec, $data );
	$back                     = (int) $old['price']['lodging_cents'] - (int) $price['lodging_cents'];
	$ok                       = ! ogc_reg_c( $cfg, 'refunds_by' ) || ogc_reg_today( $y, $req ) <= ogc_reg_c( $cfg, 'refunds_by' );
	if ( $back > 0 && $ok ) {
		ogc_reg_refund_ask( $rec, $back, 'Nights not used · after the keys are back' . ( count( $who ) < count( $pids ) ? ' · ' . implode( ', ', $names ) : '' ), $dropped );
		$rec = ogc_reg_refresh( $rec['id'] );
	}
	ogc_log( 'reg_leave', $y, 'registrations', array( 'id' => $rec['id'] ) );
	do_action( 'ogc_record_saved', $rec, 'update', $req );
	return rest_ensure_response( array( 'item' => ogc_reg_view( $rec ), 'refund' => $ok ? max( 0, $back ) : 0 ) );
}

function ogc_reg_rest_resend( WP_REST_Request $req ) {
	$rec  = ogc_record_get( (int) $req['id'] );
	$data = $rec['data'];
	if ( empty( $data['approval'] ) || 'waiting' !== $data['approval']['state'] ) {
		return ogc_reg_err( 'ogc_no_approval', 'Nothing to approve', 400 );
	}
	if ( ! empty( $data['approval']['held'] ) ) {
		return ogc_reg_err( 'ogc_held', 'Sent once paid', 400 );
	}
	// Change: the household fixes the parent's address (a typo); a new link goes to the new address and
	// the old link stops working.
	$to = strtolower( trim( (string) $req->get_param( 'to' ) ) );
	if ( '' !== $to && $to !== $data['approval']['to'] ) {
		$own = array_filter( array( strtolower( $data['household']['email'] ), strtolower( $data['helper']['email'] ), strtolower( $rec['email'] ) ) );
		if ( ! ogc_reg_email_ok( $to ) ) {
			return ogc_reg_err( 'ogc_bad_email', 'Enter an email like name@example.com', 400 );
		}
		if ( in_array( $to, $own, true ) ) {
			return ogc_reg_err( 'ogc_bad_email', 'Use a parent’s email', 400 );
		}
		if ( function_exists( 'ogc_throttle' ) && ogc_throttle( 'regap:' . $rec['id'], 5, DAY_IN_SECONDS ) ) {
			return ogc_reg_err( 'ogc_slow_down', 'Too many changes · Try tomorrow', 429 );
		}
		$data['stay']['parentEmail'] = $to;
		$token                        = ogc_reg_approval_start( $data, $rec['year'] );
		ogc_reg_note_history( $data, 'Parent’s email changed' );
		$rec = ogc_reg_save( $rec, $data );
		ogc_reg_mail_parent( $rec, $token );
		return rest_ensure_response( array( 'item' => ogc_reg_view( $rec ) ) );
	}
	if ( time() - strtotime( $data['approval']['sent_at'] . ' UTC' ) < 60 ) {
		return ogc_reg_err( 'ogc_slow_down', 'Sent · Wait a minute', 429 );
	}
	$n                             = (int) $data['approval']['reminders'];
	$token                         = ogc_reg_approval_start( $data, $rec['year'] );
	$data['approval']['reminders'] = $n;
	$rec                           = ogc_reg_save( $rec, $data );
	ogc_reg_mail_parent( $rec, $token, true );
	return rest_ensure_response( array( 'item' => ogc_reg_view( $rec ) ) );
}

/* ------------------------------------------------------------------ the committee's ledger */

/**
 * May this person record money for the year (a desk payment, a check received, a refund approved or
 * sent)? Every member, as decided Oct 6 ("one level of access"), until the COA names who handles money
 * in the year's state value money_people (a list of emails): then only they and the webmasters.
 * Whether money should be an exception to one level of access is Michael's and the Advisors' to decide
 * (NOTES/questions-register.md, for the Nov 6 security plan); this is off until money_people is set.
 */
function ogc_reg_money_ok( $year ) {
	if ( ogc_is_webmaster() ) {
		return true;
	}
	if ( ! ogc_is_member( $year ) ) {
		return false;
	}
	$s    = ogc_state_get( (int) $year, 'money_people' );
	$list = $s && is_array( $s['value'] ) ? array_filter( array_map( 'strtolower', array_map( 'strval', $s['value'] ) ) ) : array();
	if ( $list ) {
		return in_array( ogc_current_email(), $list, true );
	}
	// No one named yet: the COA, and Lodging, who take payments at the desk. Never another committee's
	// helpers (the Oct 11 review found a Food helper could read and record every payment).
	if ( function_exists( 'ogc_app_viewer' ) ) {
		$v = ogc_app_viewer( (int) $year );
		return $v['coa'] || in_array( 'lodging', (array) $v['committees'], true );
	}
	return true;
}

/** Tell the COA's money address (registration.csv money_email, a role address, never shown on the form)
 * of a refund approved or sent, and of a desk payment at or over money_notify_over (dollars; blank: every
 * one). Who did it is named as the site names people ("Ruth K."). Nothing when no address is set. */
function ogc_reg_money_notice( $rec, $what, $cents ) {
	$cfg = ogc_reg_cfg( $rec['year'] );
	$to  = ogc_reg_c( $cfg, 'money_email' );
	if ( ! is_email( $to ) || $rec['sample'] ) {
		return;
	}
	$over = ogc_reg_c( $cfg, 'money_notify_over' );
	if ( 0 === strpos( $what, 'Paid at the desk' ) && is_numeric( $over ) && $cents < (int) round( (float) $over * 100 ) ) {
		return;
	}
	$u   = wp_get_current_user();
	$who = function_exists( 'ogc_first_l' ) ? ogc_first_l( $u && $u->exists() ? $u->display_name : '' ) : '';
	ogc_reg_mail( $to, $rec['year'] . ' registrations · ' . $what . ' · ' . $rec['data']['rid'], array(
		$what . ' · ' . ogc_reg_money( $cents ),
		$rec['data']['rid'] . ' · ' . ogc_reg_label( $rec['data'] ),
		$who ? 'By ' . $who : '',
		'',
		ogc_url( 'lists', array( 'year' => (int) $rec['year'], 'view' => 'credits' ) ),
	), 'registration_changed', (int) $rec['year'] );
}

function ogc_reg_rest_ledger( WP_REST_Request $req ) {
	$rec    = ogc_record_get( (int) $req['id'] );
	$action = (string) $req->get_param( 'action' );
	$p      = $req->get_param( 'payment' ) ? ogc_pay_get( (int) $req->get_param( 'payment' ) ) : null;
	if ( $p && (int) $p['record_id'] !== (int) $rec['id'] ) {
		return ogc_reg_err( 'ogc_not_found', 'Not found.', 404 );
	}
	$note = ogc_reg_str( $req->get_param( 'note' ), 200 );
	$data = $rec['data'];
	switch ( $action ) {
		case 'check_received':
			if ( ! $p || 'check' !== $p['kind'] || 'pending' !== $p['status'] ) {
				return ogc_reg_err( 'ogc_bad_payment', 'No check to come', 400 );
			}
			ogc_pay_set( $p['id'], array( 'status' => 'paid', 'note' => $note ? $note : 'Received' ) );
			$data['checkGot'] = ogc_reg_today( $rec['year'] );
			ogc_reg_note_history( $data, 'Check received · ' . ogc_reg_money( $p['cents'] ), 'committee' );
			break;
		case 'refund_approved':
		case 'refund_sent':
			if ( ! $p || 'refund' !== $p['kind'] || 'sent' === $p['status'] ) {
				return ogc_reg_err( 'ogc_bad_payment', 'No refund to send', 400 );
			}
			// Approving a card refund sends it back through the provider when its driver can (the
			// driver's 'refund'); otherwise it stays approved for the treasurer to send ("manual").
			$via = 'refund_approved' === $action && 'card' === $p['method'] ? ogc_pay_refund_via( $p ) : 'manual';
			if ( is_wp_error( $via ) ) {
				return ogc_reg_err( 'ogc_refund_failed', 'Refund not sent · Try again', 502 );
			}
			if ( 'sent' !== $via ) {
				ogc_pay_set( $p['id'], array( 'status' => 'refund_sent' === $action ? 'sent' : 'approved', 'note' => $note ? $note : $p['note'] ) );
			}
			ogc_reg_note_history( $data, ( 'refund_sent' === $action || 'sent' === $via ? 'Refunded ' : 'Refund approved · ' ) . ogc_reg_money( $p['cents'] ), 'committee' );
			ogc_reg_money_notice( $rec, 'refund_sent' === $action || 'sent' === $via ? 'Refund sent' : 'Refund approved', $p['cents'] );
			break;
		case 'refund_declined':
			if ( ! $p || 'refund' !== $p['kind'] || 'sent' === $p['status'] ) {
				return ogc_reg_err( 'ogc_bad_payment', 'No refund to decline', 400 );
			}
			ogc_pay_set( $p['id'], array( 'status' => 'cancelled', 'note' => $note ? $note : 'Declined' ) );
			ogc_reg_note_history( $data, 'Refund declined', 'committee' );
			break;
		case 'desk_payment':
			$cents  = (int) $req->get_param( 'cents' );
			$method = in_array( $req->get_param( 'method' ), array( 'cash', 'check', 'card' ), true ) ? $req->get_param( 'method' ) : 'cash';
			if ( $cents <= 0 || $cents > 2000000 ) {
				return ogc_reg_err( 'ogc_bad_amount', 'Enter an amount', 400 );
			}
			ogc_pay_add( $rec, 'desk', $method, $cents, 'paid', array( 'note' => $note ? $note : 'At the desk' ) );
			ogc_reg_note_history( $data, 'Paid at the desk · ' . ogc_reg_money( $cents ), 'committee' );
			ogc_reg_money_notice( $rec, 'Paid at the desk · ' . ucfirst( $method ), $cents );
			break;
		default:
			return ogc_reg_err( 'ogc_bad_action', 'Unknown action', 400 );
	}
	$rec = ogc_reg_save( $rec, $data );
	ogc_log( 'reg_ledger', $rec['year'], 'registrations', array( 'id' => $rec['id'], 'action' => $action ) );
	return rest_ensure_response( array( 'item' => ogc_reg_view( $rec ) ) );
}

function ogc_reg_rest_ledger_list( WP_REST_Request $req ) {
	$y    = (int) $req['year'];
	$recs = array();
	foreach ( ogc_records( $y, 'registrations' ) as $r ) {
		$recs[ $r['id'] ] = $r;
	}
	$rows = array();
	$gift = array();
	foreach ( ogc_pay_year( $y ) as $p ) {
		$r     = isset( $recs[ $p['record_id'] ] ) ? $recs[ $p['record_id'] ] : null;
		$g     = $r && ! isset( $gift[ $p['record_id'] ] ) ? (int) $r['data']['price']['gift_cents'] : 0;
		$gift[ $p['record_id'] ] = true;
		$rows[] = array(
			'Registration' => $p['rid'],
			'Household'    => $r ? ogc_reg_label( $r['data'] ) : '',
			'Date'         => ogc_pay_day( $p['updated_at'], $y ),
			'Kind'         => $p['kind'],
			'Method'       => $p['method'],
			'Amount'       => number_format( ( 'refund' === $p['kind'] ? -1 : 1 ) * $p['cents'] / 100, 2, '.', '' ),
			'Status'       => $p['status'],
			'Gift'         => $g ? number_format( $g / 100, 2, '.', '' ) : '',
			'Reference'    => 'test' === $p['driver'] ? '' : $p['ref'],
			'Note'         => $p['note'],
			'Sample'       => $p['sample'] ? 'yes' : '',
		);
	}
	if ( 'csv' === $req->get_param( 'format' ) ) {
		return ogc_rest_csv( ogc_csv_write( $rows, array( 'Registration', 'Household', 'Date', 'Kind', 'Method', 'Amount', 'Status', 'Gift', 'Reference', 'Note', 'Sample' ) ) );
	}
	return rest_ensure_response( $rows );
}

function ogc_reg_rest_samples( WP_REST_Request $req ) {
	return rest_ensure_response( array( 'cleared' => ogc_reg_clear_samples( (int) $req['year'] ) ) );
}

/** Local only: the year's registrations that aren't samples (a walk-through's own), their ledger rows and
 * credit asks, removed; numbering starts again after the samples. */
function ogc_reg_rest_tests( WP_REST_Request $req ) {
	global $wpdb;
	$y = (int) $req['year'];
	$n = 0;
	foreach ( array( 'registrations', 'credits' ) as $kind ) {
		foreach ( ogc_records( $y, $kind ) as $r ) {
			if ( $r['sample'] ) {
				continue;
			}
			$wpdb->query( $wpdb->prepare( 'DELETE FROM ' . ogc_table( 'payments' ) . ' WHERE record_id = %d AND sample = 0', $r['id'] ) );
			ogc_record_delete( $r['id'] );
			$n += 'registrations' === $kind ? 1 : 0;
		}
	}
	ogc_state_put( $y, 'reg_seq', 0 );
	ogc_log( 'reg_tests_clear', $y, 'registrations', array( 'n' => $n ) );
	return rest_ensure_response( array( 'cleared' => $n ) );
}

/* ------------------------------------------------------------------ a parent's approval */

/** What the parent sees: who, which hall, the nights, who they're rooming with, the total. No one's
 * email or phone. */
function ogc_reg_rest_approve_get( WP_REST_Request $req ) {
	$rec = ogc_reg_by_approval( $req['token'] );
	if ( ! $rec ) {
		return ogc_reg_err( 'ogc_expired', 'Link expired', 410 );
	}
	$d    = $rec['data'];
	$y    = (int) $rec['year'];
	$cfg  = ogc_reg_cfg( $y );
	$days = ogc_reg_days( $y );
	$who  = array();
	$list = 'waiting' !== $d['approval']['state'] && ! empty( $d['approval']['who'] ) ? $d['approval']['who'] : ogc_reg_approval_people( $d );
	// The address was typed by a teenager: a mistyped one reaches a stranger. So the young person is
	// "First L." with no age, and a roommate is named only when they're of this household (another
	// family's child never is). Review, Oct 11.
	$ours = array_map( function ( $p ) {
		return strtolower( trim( (string) $p['name'] ) );
	}, (array) $d['people'] );
	foreach ( $list ? $list : $d['people'] as $p ) {
		$ns    = ogc_reg_nights_for( $p, $d, $cfg );
		$room  = trim( (string) ( isset( $p['rooming'] ) ? $p['rooming'] : '' ) );
		$mine  = '' !== $room && in_array( strtolower( $room ), $ours, true );
		$who[] = array(
			'name'          => function_exists( 'ogc_first_l' ) ? ogc_first_l( $p['name'] ) : $p['name'],
			'age'           => '',
			'hall'          => 'women' === $p['yfHall'] ? 'Young women’s hall' : 'Young men’s hall',
			'nights'        => $ns,
			'from'          => $ns ? ogc_reg_night_date( $days, $ns[0] ) : '',
			'to'            => $ns ? ogc_reg_add_days( ogc_reg_night_date( $days, $ns[ count( $ns ) - 1 ] ), 1 ) : '',
			'rooming'       => $mine && function_exists( 'ogc_first_l' ) ? ogc_first_l( $room ) : '',
			'rooming_other' => '' !== $room && ! $mine,
		);
	}
	$m     = isset( $d['money'] ) ? $d['money'] : array();
	$alone = ogc_reg_approval_alone( $d );
	$own   = ogc_reg_approval_lines( $d, $y );
	return rest_ensure_response( array(
		'year'      => $y,
		'rid'       => $d['rid'],
		'state'     => $d['approval']['state'],
		'at'        => $d['approval']['at'],
		'status'    => $d['status'],
		// Who registered them, as the site names people ("Esther B."): the parent knows who asked.
		'by'        => ogc_reg_approval_by( $d ),
		'who'       => $who,
		// The young person's own lines only (their hall share, their linen packet); the household's
		// other lines and total are another adult's business. A Young Folk alone: their registration.
		'alone'     => $alone,
		'lines'     => $own['lines'],
		'total'     => $own['total'],
		'paid'      => $alone ? (int) ( isset( $m['paid'] ) ? $m['paid'] : 0 ) : 0,
		'check'     => $alone ? (int) ( isset( $m['check'] ) ? $m['check'] : 0 ) : 0,
		'due'       => $alone ? (int) ( isset( $m['due'] ) ? $m['due'] : 0 ) : 0,
		'covered'   => ogc_reg_approval_covered( $d ),
		// After a decline, a Young Folk alone: the refund asked for (never "refunded" before it's sent).
		'refund'    => $alone ? (int) ( isset( $m['refund'] ) ? $m['refund'] : 0 ) : 0,
		'keys'      => ogc_reg_c( $cfg, 'yf_keys' ),
		'decline'   => ogc_reg_decline_preview( $rec ),
		// Who to ask, by role, and only with a way to reach them.
		'questions' => ogc_reg_questions_words( $y ),
	) );
}

/** A Young Folk (or a group of them) registering with no adult along. */
function ogc_reg_approval_alone( $d ) {
	return ! array_filter( (array) $d['people'], function ( $p ) { return 'adult' === $p['kind']; } );
}

/** "Esther B.": who registered (the helper who made it, else the household's contact). */
function ogc_reg_approval_by( $d ) {
	$n = ! empty( $d['helper']['on'] ) && ! empty( $d['helper']['name'] ) ? $d['helper']['name'] : ( isset( $d['household']['contact'] ) ? $d['household']['contact'] : '' );
	return function_exists( 'ogc_first_l' ) ? ogc_first_l( $n ) : ogc_reg_first( $n );
}

/** The lines a parent approves: for a Young Folk alone, the registration's; in a family's, only the
 * young people's own (their hall nights and their linen packet). Returns array( lines, total ). */
function ogc_reg_approval_lines( $d, $y ) {
	if ( ogc_reg_approval_alone( $d ) ) {
		return array( 'lines' => $d['price']['lines'], 'total' => (int) $d['price']['total_cents'] );
	}
	$cfg   = ogc_reg_cfg_for( $y, $d );
	$lines = array();
	foreach ( ogc_reg_approval_people( $d ) as $p ) {
		$own = false;
		foreach ( (array) $d['price']['lines'] as $l ) {
			if ( in_array( $l['key'], array( 'yf_' . $p['pid'], 'linen_' . $p['pid'] ), true ) ) {
				$lines[] = $l;
				$own     = $own || 'linen_' . $p['pid'] === $l['key'];
			}
		}
		// A registration priced before each packet had its own line.
		if ( ! empty( $p['linens'] ) && ! $own ) {
			$lines[] = array( 'key' => 'linen_' . $p['pid'], 'label' => ogc_reg_first( $p['name'] ) . ' · Linen packet × ' . ogc_reg_money( ogc_reg_cents( $cfg, 'linen_price' ) ), 'cents' => ogc_reg_cents( $cfg, 'linen_price' ) );
		}
	}
	return array( 'lines' => $lines, 'total' => array_sum( wp_list_pluck( $lines, 'cents' ) ) );
}

/** How the registration stands for money, in a parent's words: Paid by the registration, Check to come… */
function ogc_reg_approval_covered( $d ) {
	// Only what's true of the money (polish 3: "Paid by the registration" was said before anything was
	// paid): "Part of R-2027-0012 · Check to come", "… · Paid", "… · Due at check-in".
	$m   = isset( $d['money'] ) ? $d['money'] : array();
	$now = ! empty( $m['check'] ) ? 'Check to come' : ( empty( $m['due'] ) ? 'Paid' : ( 'checkin' === ( isset( $d['pay'] ) ? $d['pay'] : '' ) || ! empty( $m['late'] ) ? 'Due at check-in' : 'Payment due' ) );
	if ( ogc_reg_approval_alone( $d ) ) {
		return $now;
	}
	return 'Part of ' . ( isset( $d['rid'] ) ? $d['rid'] : 'the registration' ) . ' · ' . $now;
}

function ogc_reg_rest_approve_post( WP_REST_Request $req ) {
	$rec = ogc_reg_by_approval( $req['token'] );
	if ( ! $rec ) {
		return ogc_reg_err( 'ogc_expired', 'Link expired', 410 );
	}
	$decision = (string) $req->get_param( 'decision' );
	if ( ! in_array( $decision, array( 'approve', 'decline' ), true ) ) {
		return ogc_reg_err( 'ogc_bad_decision', 'Approve or Decline', 400 );
	}
	$d = $rec['data'];
	if ( 'waiting' !== $d['approval']['state'] || 'cancelled' === $d['status'] ) {
		return ogc_reg_rest_approve_get( $req );
	}
	// Who it was for, kept: after a decline in a family's registration they're no longer on it, and the
	// answer page still names them (not everyone else).
	$d['approval']['who']   = array_map( function ( $p ) { return array_intersect_key( $p, array_flip( array( 'pid', 'name', 'age', 'yfHall', 'nights', 'rooming', 'kind', 'minor', 'yf', 'sleeps' ) ) ); }, ogc_reg_approval_people( $d ) );
	$d['approval']['state'] = 'approve' === $decision ? 'approved' : 'declined';
	$d['approval']['at']    = ogc_reg_today( $rec['year'] );
	ogc_reg_note_history( $d, 'approve' === $decision ? 'Approved by parent' : 'Declined by parent', 'parent' );
	$rec = ogc_reg_save( $rec, $d );
	if ( 'decline' === $decision ) {
		// A Young Folk alone: the registration is cancelled. In a family's registration (grandparents
		// bringing a grandson): only the Young Folks needing approval come off it, and the rest stays.
		$whole = ! array_filter( $d['people'], function ( $p ) { return 'adult' === $p['kind']; } );
		$rec   = $whole ? ogc_reg_cancel( $rec, 'Declined by parent' ) : ogc_reg_decline_part( $rec );
		ogc_reg_mail_receipt( $rec, $whole ? 'cancelled' : 'changed' );
	} else {
		ogc_reg_mail_receipt( $rec, 'changed' );
	}
	ogc_log( 'reg_approval', $rec['year'], 'registrations', array( 'id' => $rec['id'], 'decision' => $decision ) );
	return ogc_reg_rest_approve_get( $req );
}

/** What Decline would do, for the parent's page: {whole, names, refund} (refund in cents). */
function ogc_reg_decline_preview( $rec ) {
	$d     = $rec['data'];
	$y     = (int) $rec['year'];
	$cfg   = ogc_reg_cfg( $y );
	$ok    = ! ogc_reg_c( $cfg, 'refunds_by' ) || ogc_reg_today( $y ) <= ogc_reg_c( $cfg, 'refunds_by' );
	$m     = isset( $d['money'] ) ? $d['money'] : array( 'paid' => 0, 'refund' => 0 );
	$whole = ! array_filter( $d['people'], function ( $p ) { return 'adult' === $p['kind']; } );
	$names = array_map( 'ogc_reg_first', wp_list_pluck( ogc_reg_approval_people( $d ), 'name' ) );
	$net   = (int) $m['paid'] - (int) $m['refund'];
	if ( $whole ) {
		$back = $net - (int) ( isset( $d['price']['gift_cents'] ) ? $d['price']['gift_cents'] : 0 );
	} else {
		$less = ogc_reg_price( ogc_reg_without_approval( $d, $y ), $y, ogc_reg_cfg_for( $y, $d ) );
		$back = $net - (int) $less['total_cents'];
	}
	return array( 'whole' => $whole, 'names' => $names, 'refund' => $ok ? max( 0, $back ) : 0 );
}

/** The answers without the Young Folks waiting for a parent's approval. */
function ogc_reg_without_approval( $d, $y ) {
	$drop         = wp_list_pluck( ogc_reg_approval_people( $d ), 'pid' );
	$in           = $d;
	$in['people'] = array_values( array_filter( $d['people'], function ( $p ) use ( $drop ) { return ! in_array( $p['pid'], $drop, true ); } ) );
	$in['stay']['ask'] = false;
	$out          = ogc_reg_clean( $in, $y );
	$out['gift']  = (int) ( isset( $d['gift'] ) ? $d['gift'] : 0 );
	return $out;
}

/** A parent declined in a family's registration: those Young Folks come off it; the money follows. */
function ogc_reg_decline_part( $rec ) {
	$y     = (int) $rec['year'];
	$old   = $rec['data'];
	$names = array_map( 'ogc_reg_first', wp_list_pluck( ogc_reg_approval_people( $old ), 'name' ) );
	$d     = ogc_reg_without_approval( $old, $y );
	$price = ogc_reg_price( $d, $y, ogc_reg_cfg_for( $y, $old ) );
	$data  = $d;
	foreach ( $old as $k => $v ) {
		if ( in_array( $k, ogc_reg_server_keys(), true ) || ! array_key_exists( $k, $data ) ) {
			$data[ $k ] = $v;
		}
	}
	$data['price'] = array_merge( $price, array( 'prices' => isset( $old['price']['prices'] ) ? $old['price']['prices'] : array(), 'at' => isset( $old['price']['at'] ) ? $old['price']['at'] : '' ) );
	ogc_reg_note_history( $data, 'Declined by parent · ' . implode( ', ', $names ) . ' removed', 'parent' );
	$rec = ogc_reg_save( $rec, $data );
	$cfg = ogc_reg_cfg( $y );
	$ok  = ! ogc_reg_c( $cfg, 'refunds_by' ) || ogc_reg_today( $y ) <= ogc_reg_c( $cfg, 'refunds_by' );
	ogc_reg_rebalance( $rec, $old, $price['total_cents'], $ok, 'Declined by parent' );
	ogc_log( 'reg_decline_part', $y, 'registrations', array( 'id' => $rec['id'] ) );
	return ogc_reg_refresh( $rec['id'] );
}

/* ------------------------------------------------------------------ checking an email */

// Confirming an email at Contact is the site's one sign-in (module-auth: auth/send with for=register,
// then auth/code): one limiter, one same-origin rule, one email. Polish 2 removed reg/code and
// reg/verify, the form's second sign-in system.

/** "Not you?": signed out on this device without leaving the form. The answer is a fresh nonce for the
 * visitor the page now is. */
function ogc_reg_rest_signout( WP_REST_Request $req ) {
	ogc_log( 'signout', 0, 'user:' . get_current_user_id() );
	wp_logout();
	wp_set_current_user( 0 );
	// The nonce is made from the session; this request still carries the old cookie.
	unset( $_COOKIE[ LOGGED_IN_COOKIE ] );
	return rest_ensure_response( array( 'me' => null, 'nonce' => wp_create_nonce( 'wp_rest' ) ) );
}

/* ------------------------------------------------------------------ a draft kept for its person */

// Polish 3: a draft lived only in the tab (sessionStorage), so a grandmother who left Safari to read the
// code, or closed the tab halfway, typed everything again. Once the email is confirmed, the draft is kept
// on the server as the person's own record (kind reg_draft, one per email and year). It isn't one of the
// record kinds (ogc_record_kinds), so no generic route, list or member ever reads it. It goes when they
// register or start over, and the daily round drops drafts a month old or past the Conference.

/** The top-level parts a draft may hold (the form's answers, and its own page state). */
function ogc_reg_draft_keys() {
	return array( 'household', 'helper', 'people', 'stay', 'meals', 'preteens', 'contacts', 'pickupWho', 'pickupOther', 'gift', 'pay', 'finished', 'from', 'changes', 'owner' );
}

function ogc_reg_draft_rec( $year, $email ) {
	$all = ogc_records( (int) $year, 'reg_draft', $email );
	return $all ? $all[0] : null;
}

function ogc_reg_rest_draft_get( WP_REST_Request $req ) {
	$y   = (int) $req['year'];
	$rec = ogc_reg_draft_rec( $y, ogc_current_email() );
	$res = rest_ensure_response( array( 'data' => $rec ? $rec['data'] : null, 'at' => $rec ? $rec['updated_at'] : '' ) );
	$res->header( 'Cache-Control', 'private, no-store, max-age=0' );
	return $res;
}

function ogc_reg_rest_draft_put( WP_REST_Request $req ) {
	$y  = (int) $req['year'];
	$me = ogc_current_email();
	if ( '' === $me || ! ogc_year_get( $y ) ) {
		return ogc_reg_err( 'ogc_not_found', 'Not found.', 404 );
	}
	$in = $req->get_param( 'data' );
	if ( ! is_array( $in ) ) {
		return ogc_reg_err( 'ogc_bad_draft', 'Not saved', 400 );
	}
	$data = array_intersect_key( $in, array_flip( ogc_reg_draft_keys() ) );
	$json = wp_json_encode( $data );
	if ( ! $json || strlen( $json ) > 60000 || count( (array) ( isset( $data['people'] ) ? $data['people'] : array() ) ) > 40 ) {
		return ogc_reg_err( 'ogc_bad_draft', 'Not saved', 400 );
	}
	// A draft is only ever its signed-in person's.
	$data['owner'] = $me;
	$rec           = ogc_reg_draft_rec( $y, $me );
	if ( $rec ) {
		ogc_record_update( $rec['id'], $data, $me );
	} else {
		ogc_record_insert( $y, 'reg_draft', $data, $me, false, 'web' );
	}
	// Their name on their account, the first time (the code doesn't carry it): never over one they have.
	$h    = isset( $data['household'] ) && is_array( $data['household'] ) ? $data['household'] : array();
	$x    = isset( $data['helper'] ) && is_array( $data['helper'] ) ? $data['helper'] : array();
	$name = ! empty( $x['on'] ) ? ( isset( $x['name'] ) ? $x['name'] : '' ) : ( isset( $h['contact'] ) ? $h['contact'] : '' );
	$mine = ! empty( $x['on'] ) ? ( isset( $x['email'] ) ? $x['email'] : '' ) : ( isset( $h['email'] ) ? $h['email'] : '' );
	if ( function_exists( 'ogc_person_name' ) && function_exists( 'ogc_person_set_name' ) && strtolower( trim( (string) $mine ) ) === $me && '' !== trim( (string) $name ) && '' === ogc_person_name( get_current_user_id() ) ) {
		ogc_person_set_name( get_current_user_id(), ogc_reg_str( $name ) );
	}
	return rest_ensure_response( array( 'saved' => true ) );
}

function ogc_reg_draft_drop( $year, $email ) {
	global $wpdb;
	if ( '' === (string) $email ) {
		return;
	}
	$wpdb->query( $wpdb->prepare( 'DELETE FROM ' . ogc_table( 'records' ) . " WHERE year = %d AND kind = 'reg_draft' AND email = %s", (int) $year, strtolower( (string) $email ) ) );
}

function ogc_reg_rest_draft_delete( WP_REST_Request $req ) {
	ogc_reg_draft_drop( (int) $req['year'], ogc_current_email() );
	return rest_ensure_response( array( 'deleted' => true ) );
}

// Drafts a month old, or of a Conference that's over, are erased (they hold a phone).
add_action( 'ogc_reg_daily', function () {
	global $wpdb;
	$wpdb->query( $wpdb->prepare( 'DELETE FROM ' . ogc_table( 'records' ) . " WHERE kind = 'reg_draft' AND updated_at < %s", gmdate( 'Y-m-d H:i:s', time() - 30 * DAY_IN_SECONDS ) ) );
	foreach ( ogc_years_list() as $y ) {
		$row = ogc_year_get( $y );
		if ( $row && ! empty( $row['end'] ) && ogc_reg_today( $y ) > $row['end'] ) {
			$wpdb->query( $wpdb->prepare( 'DELETE FROM ' . ogc_table( 'records' ) . " WHERE kind = 'reg_draft' AND year = %d", (int) $y ) );
		}
	}
}, 20 );
