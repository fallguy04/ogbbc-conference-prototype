<?php
/**
 * The editors area: what the full-screen editors (admin/?edit=…) and the webmasters' page (admin/?role=web)
 * need from the server.
 *
 *   Rows      every row of an editor's file has a lasting "_id"; changes go one row at a time
 *             (POST /years/{y}/rows/{name}), merged field by field: a field someone else changed since
 *             it was read comes back as a conflict, never overwritten.
 *   History   every change to a row is kept (who, when, before → after), from the editors and from any
 *             other page's save, so a row can be put back and "Changed by Ruth K. · Oct 12" is true.
 *   Checks    each editor file has its columns and values checked on the server (ogc_file_rows_valid).
 *   Held      a Conference that's over is read only, except to webmasters (a typo, logged).
 *   Public    a row marked "Committees only" never reaches anyone who isn't a member.
 *   Webmasters starting and removing a year, the webmasters list (two to add or remove one), exporting
 *             a year as CSVs, reading an .xlsx, the sermons waiting for their service.
 *
 * Members are the year area's list (coa/{y}/members); a shift's volunteers are told of a change by the
 * volunteer area; a published schedule's "Updated" and its changes are the year and conference areas'.
 * DEV.md lists the core routes; the ones here are in NOTES/editors.md.
 */

defined( 'ABSPATH' ) || exit;

/* ================================================================== the page */

add_filter( 'ogc_pages', function ( $p ) {
	if ( empty( $p['admin'] ) ) {
		return $p;
	}
	$js = array();
	foreach ( (array) $p['admin']['scripts'] as $s ) {
		if ( 'admin/admin.js' === $s ) {
			$js = array_merge( $js, array( 'admin/admin-read.js', 'admin/admin-rows.js', 'admin/admin-files.js', 'admin/admin-table.js', 'admin/admin-web.js' ) );
		}
		$js[] = $s;
	}
	$p['admin']['scripts']    = $js;
	$p['admin']['title']      = 'Conference editors';
	$p['admin']['html_class'] = 'adm-full';
	return $p;
} );

add_filter( 'ogc_client_config', function ( $cfg, $key ) {
	if ( 'admin' !== $key ) {
		return $cfg;
	}
	$held = array();
	foreach ( ogc_years_list() as $y ) {
		if ( ogc_ed_held( $y ) ) {
			$held[] = $y;
		}
	}
	$cfg['editors'] = array(
		'today'   => ogc_ed_today(),
		'held'    => $held,
		'prod'    => ! OGC_DEV && 'production' === wp_get_environment_type(),
		'short'   => is_user_logged_in() ? ogc_ed_short( get_current_user_id() ) : '',
		'signin'  => home_url( '/conference-sign-in' ),
		// years.csv as the public reads it, so the page needs no request for it.
		'years'   => array_values( ogc_years_public() ),
	);
	return $cfg;
}, 10, 2 );

/* ================================================================== helpers */

/** Today's date where Conference is (the venue's time zone). */
function ogc_ed_today( $year = null ) {
	$tz = 'America/Indiana/Indianapolis';
	if ( $year ) {
		$s = ogc_ed_settings( $year );
		if ( ! empty( $s['timezone'] ) ) {
			$tz = $s['timezone'];
		}
	}
	try {
		$d = new DateTime( 'now', new DateTimeZone( $tz ) );
	} catch ( Exception $e ) {
		$d = new DateTime( 'now' );
	}
	return $d->format( 'Y-m-d' );
}

/** A year's settings.csv as key → value. */
function ogc_ed_settings( $year ) {
	$f   = ogc_file_get( $year, 'settings' );
	$out = array();
	foreach ( $f ? $f['rows'] : array() as $r ) {
		if ( isset( $r['key'] ) && '' !== $r['key'] ) {
			$out[ $r['key'] ] = isset( $r['value'] ) ? (string) $r['value'] : '';
		}
	}
	return $out;
}

/** Held: the Conference is over (its last day has passed where it's held). */
function ogc_ed_held( $year ) {
	$y = ogc_year_get( $year );
	$end = $y && ! empty( $y['end'] ) ? $y['end'] : '';
	return $end && preg_match( '/^\d{4}-\d{2}-\d{2}$/', $end ) && $end < ogc_ed_today( $year );
}

/** "Ruth K." for a user: their display name as the site writes names (First L.). */
function ogc_ed_short( $uid ) {
	$u = $uid ? get_userdata( $uid ) : null;
	if ( ! $u ) {
		return '';
	}
	$n = trim( (string) $u->display_name );
	if ( '' === $n || false !== strpos( $n, '@' ) ) {
		$n = strstr( (string) $u->user_email, '@', true );
		return $n ? $n : 'Someone';
	}
	$w = preg_split( '/\s+/', $n );
	if ( count( $w ) > 1 ) {
		$last = end( $w );
		return $w[0] . ' ' . ( preg_match( '/^[A-Z]\.$/', $last ) ? $last : mb_strtoupper( mb_substr( $last, 0, 1 ) ) . '.' );
	}
	return $n;
}

/** The files the editors keep, row by row. */
function ogc_ed_files() {
	// Filter ogc_ed_files: another screen's file kept row by row too (the app's Packet: guide, menus).
	return (array) apply_filters( 'ogc_ed_files', array( 'schedule', 'shifts', 'tournaments', 'rooms', 'places', 'nearby', 'help', 'notices', 'contacts', 'committees', 'attachments' ) );
}

/** A new lasting row id. */
function ogc_ed_new_id( $taken ) {
	do {
		$id = 'k' . strtolower( wp_generate_password( 9, false, false ) );
	} while ( isset( $taken[ $id ] ) );
	return $id;
}

/* ================================================================== checks */

/** The columns each editor file may hold. An area adds its own with the ogc_file_columns filter. */
function ogc_ed_columns( $name ) {
	$c = array(
		'schedule'    => array( 'day', 'last_day', 'start', 'end', 'title', 'audience', 'kind', 'place', 'also', 'note', 'call_in', 'recorded', 'display', 'sort_time', 'print_note', 'guide', 'why' ),
		'shifts'      => array( 'committee', 'role', 'day', 'last_day', 'start', 'end', 'needed', 'place', 'note', 'rule', 'join', 'couples', 'uid', 'min_age' ),
		'tournaments' => array( 'id', 'name', 'schedule_title', 'schedule_id', 'min', 'max', 'solo', 'opens', 'closes_day', 'closes_time', 'rule', 'note', 'sample' ),
		'rooms'       => array( 'hall', 'first', 'last', 'floor', 'beds', 'for', 'share', 'note', 'closed' ),
		'places'      => array( 'code', 'name', 'building', 'map', 'x', 'y' ),
		'nearby'      => array( 'kind', 'name', 'address', 'phone', 'hours', 'distance', 'checked' ),
		'help'        => array( 'need', 'text', 'phone', 'pin', 'action', 'link', 'hours', 'open', 'kind', 'line', 'owner' ),
		'notices'     => array( 'from', 'to', 'text', 'url', 'until_time' ),
		'contacts'    => array( 'label', 'phone', 'pin', 'note', 'kind', 'hours', 'shows', 'line' ),
		'committees'  => array( 'name', 'owner', 'contact_email', 'contact_phone', 'heads', 'weekly', 'order' ),
	);
	$cols = isset( $c[ $name ] ) ? $c[ $name ] : null;
	return null === $cols ? null : (array) apply_filters( 'ogc_file_columns', $cols, $name );
}

/** Words or a clock time: a time field holds either. */
function ogc_ed_time_ok( $v ) {
	return '' === $v || mb_strlen( $v ) <= 60;
}

/** One value checked: null when fine, else what's wrong (said as a status, for the editor). */
function ogc_ed_value_problem( $name, $k, $v ) {
	$v  = (string) $v;
	$lv = strtolower( trim( $v ) );
	if ( preg_match( '/<\s*[a-z!\/?]/i', $v ) ) {
		return 'No HTML';
	}
	if ( '_' === $k[0] ) {
		return mb_strlen( $v ) > 40 ? 'Too long' : null;
	}
	$long = array( 'note', 'text', 'why', 'print_note', 'detail' );
	$max  = in_array( $k, $long, true ) ? 1500 : ( in_array( $k, array( 'title', 'role', 'name', 'need', 'label' ), true ) ? 200 : 300 );
	if ( mb_strlen( $v ) > $max ) {
		return 'Too long';
	}
	if ( '' === $lv ) {
		return null;
	}
	$days = array( 'sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday' );
	$day  = function ( $x ) use ( $days ) {
		foreach ( $days as $d ) {
			if ( $x === $d || $x === substr( $d, 0, 3 ) ) {
				return true;
			}
		}
		return false;
	};
	$yes  = array( 'yes', 'no', 'y', 'n', '1', '0', 'x', 'true', 'false' );
	switch ( $k ) {
		case 'audience':
			return in_array( $lv, array( 'conference', 'preteens', 'preteen', 'young folks', 'youngfolks', 'young folk', 'yf', 'all', 'everyone' ), true ) ? null : 'Unknown audience';
		case 'display':
			return in_array( $lv, array( 'all day', 'all_day', 'desk', 'nightly', 'timeline', 'private' ), true ) ? null : 'Unknown display';
		case 'call_in':
		case 'recorded':
		case 'solo':
		case 'couples':
		case 'sample':
			return in_array( $lv, $yes, true ) ? null : 'Yes or no';
		case 'day':
		case 'last_day':
		case 'closes_day':
			return $day( $lv ) ? null : 'Unknown day';
		case 'kind':
			if ( 'schedule' === $name || 'help' === $name ) {
				return preg_match( '/^[a-z_ -]{1,24}$/', $lv ) ? null : 'Unknown kind';
			}
			return null;
		case 'for':
			return in_array( $lv, array( 'families', 'young men', 'young women' ), true ) ? null : 'Unknown';
		case 'share':
			return in_array( $lv, array( 'pairs', 'private', 'hall' ), true ) ? null : 'Unknown';
		case 'join':
			return in_array( $lv, array( 'anyone', 'invited' ), true ) ? null : 'Unknown';
		case 'needed':
			// "any": a shift open to everyone (v3's data, e.g. Kit packing), not a number of people.
			if ( 'any' === $lv ) {
				return null;
			}
			// Falls through: otherwise a number, as below.
		case 'min':
		case 'max':
		case 'beds':
			return preg_match( '/^\d{1,3}$/', $lv ) && (int) $lv <= 500 ? null : 'A number';
		case 'floor':
			return preg_match( '/^-?\d{1,2}$|^[a-z]{1,3}$/', $lv ) ? null : 'A floor';
		case 'start':
		case 'end':
		case 'sort_time':
		case 'closes_time':
		case 'until_time':
		case 'moved_from':
			return ogc_ed_time_ok( $v ) ? null : 'Too long';
		case 'code':
		case 'place':
			return preg_match( '#^[A-Za-z0-9][A-Za-z0-9/ .&_-]{0,31}$#', trim( $v ) ) ? null : 'Not a place code';
		case 'also':
			foreach ( explode( '|', $v ) as $c ) {
				if ( '' !== trim( $c ) && ! preg_match( '#^[A-Za-z0-9][A-Za-z0-9/ .&_-]{0,31}$#', trim( $c ) ) ) {
					return 'Not a place code';
				}
			}
			return null;
		case 'from':
		case 'to':
		case 'opens':
		case 'checked':
		case 'changed':
			return preg_match( '/^\d{4}-\d{2}-\d{2}$/', $lv ) ? null : 'A date';
		case 'x':
		case 'y':
			return is_numeric( $lv ) ? null : 'A number';
		case 'phone':
			return preg_match( '/^[0-9+().\s-]{3,24}$/', $lv ) ? null : 'Not a phone number';
		case 'link':
		case 'url':
		case 'map':
			return ogc_ed_link_problem( $v );
	}
	if ( preg_match( '/(url|link)$/', $k ) ) {
		return ogc_ed_link_problem( $v );
	}
	return null;
}

/** A link a page may show: https, tel:, sms:, mailto: or this site; never an outside sermon platform. */
function ogc_ed_link_problem( $v ) {
	$v = trim( $v );
	if ( '' === $v ) {
		return null;
	}
	if ( preg_match( '#^(tel|sms):[0-9+().\s-]{3,30}(\?[^\s<>"]*)?$#i', $v ) || preg_match( '#^mailto:[^\s<>"]+@[^\s<>"]+$#i', $v ) ) {
		return null;
	}
	if ( preg_match( '#^/(?!/)#', $v ) ) {
		return null;
	}
	if ( ! preg_match( '#^https://[^\s<>"]+$#i', $v ) ) {
		return 'Link starts https://';
	}
	$host = strtolower( (string) wp_parse_url( $v, PHP_URL_HOST ) );
	foreach ( array( 'sermonaudio.com', 'youtube.com', 'youtu.be', 'facebook.com', 'fb.com', 'fb.watch' ) as $bad ) {
		if ( $host === $bad || substr( $host, -strlen( '.' . $bad ) ) === '.' . $bad ) {
			return 'No outside sermon links';
		}
	}
	return null;
}

/** The editor files are checked on every save, from any page. */
add_filter( 'ogc_file_rows_valid', function ( $ok, $rows, $year, $name ) {
	if ( is_wp_error( $ok ) ) {
		return $ok;
	}
	$cols = ogc_ed_columns( $name );
	if ( in_array( $name, ogc_ed_files(), true ) && ogc_ed_held( $year ) && ! ogc_is_webmaster() && ! defined( 'OGC_IMPORTING' ) ) {
		return new WP_Error( 'ogc_held', 'Held · Read only', array( 'status' => 423 ) );
	}
	if ( null === $cols ) {
		return $ok;
	}
	// Rows already kept as they are aren't checked again (what's there from before can't block a change
	// to another row); only new or changed rows are.
	$was = array();
	$cur = ogc_file_get( $year, $name );
	foreach ( $cur ? $cur['rows'] : array() as $r ) {
		unset( $r['_id'] );
		$was[ md5( ogc_json( $r ) ) ] = true;
	}
	foreach ( $rows as $i => $r ) {
		$plain = (array) $r;
		unset( $plain['_id'] );
		if ( isset( $was[ md5( ogc_json( $plain ) ) ] ) ) {
			continue;
		}
		foreach ( (array) $r as $k => $v ) {
			$k = (string) $k;
			// A column another area adds (the volunteer area's uid…) is allowed if it's a plain name;
			// its values get the general checks (no HTML, a length, a safe link).
			if ( '_' !== $k[0] && ! in_array( $k, $cols, true ) && ! preg_match( '/^[a-z][a-z0-9_]{0,31}$/', $k ) ) {
				return new WP_Error( 'ogc_bad_column', 'Unknown column: ' . $k, array( 'status' => 400, 'column' => $k ) );
			}
			if ( '_' === $k[0] && ! preg_match( '/^_[a-z]{1,15}$/', $k ) ) {
				return new WP_Error( 'ogc_bad_column', 'Unknown column: ' . $k, array( 'status' => 400, 'column' => $k ) );
			}
			$p = ogc_ed_value_problem( $name, $k, null === $v ? '' : $v );
			if ( $p ) {
				return new WP_Error( 'ogc_bad_value', $p, array( 'status' => 400, 'row' => $i, 'column' => $k, 'id' => isset( $r['_id'] ) ? $r['_id'] : '' ) );
			}
		}
	}
	return $ok;
}, 20, 4 );

/* ================================================================== what the public gets */

// Rows marked "Committees only" (display = private: set-up times, sound checks, committee meetings)
// never leave the server for anyone who isn't a member.
add_filter( 'ogc_file_rows_out', function ( $rows, $year, $name, $member ) {
	if ( $member || 'schedule' !== $name ) {
		return $rows;
	}
	$out = array();
	foreach ( (array) $rows as $r ) {
		if ( isset( $r['display'] ) && 'private' === strtolower( (string) $r['display'] ) ) {
			continue;
		}
		$out[] = $r;
	}
	return $out;
}, 10, 4 );

/* ================================================================== what the public sees of each editor */

/**
 * For each editor file, what someone who isn't a member gets right now, worked out with the same rules
 * that decide it (ogc_private_files, ogc_file_visible, ogc_file_rows_out, all with $member false), so the
 * line under an editor's title ("Public", "Committees only", "Shows with the schedule") is only ever
 * what's true. → { name: { private, visible, total, shown } } plus { _schedule: posted? }.
 */
function ogc_ed_public_lines( $y ) {
	$out = array();
	foreach ( array( 'schedule', 'shifts', 'tournaments', 'rooms', 'places', 'nearby', 'help', 'notices', 'contacts' ) as $name ) {
		$f    = ogc_file_get( $y, $name );
		$rows = $f ? array_values( (array) $f['rows'] ) : array();
		$priv = in_array( $name, ogc_private_files(), true );
		$vis  = ! $priv && (bool) apply_filters( 'ogc_file_visible', true, (int) $y, $name, false );
		$shown = $vis ? count( (array) apply_filters( 'ogc_file_rows_out', $rows, (int) $y, $name, false ) ) : 0;
		$out[ $name ] = array( 'private' => $priv, 'visible' => $vis, 'total' => count( $rows ), 'shown' => $shown );
	}
	$s                  = ogc_ed_settings( $y );
	$v                  = isset( $s['schedule_posted'] ) ? $s['schedule_posted'] : '';
	$out['_schedule']   = '' === $v || ( preg_match( '/^\d{4}-\d{2}-\d{2}$/', $v ) && '9999-12-31' !== $v && $v <= ogc_ed_today( $y ) );
	$out['_room_choice'] = '';
	$rf = ogc_file_get( $y, 'registration' );
	foreach ( $rf ? (array) $rf['rows'] : array() as $r ) {
		if ( isset( $r['key'] ) && 'room_choice' === $r['key'] ) {
			$out['_room_choice'] = isset( $r['value'] ) ? (string) $r['value'] : '';
		}
	}
	return $out;
}

// The editors' page carries it for the year it opens (members only), so no request is needed.
add_filter( 'ogc_client_config', function ( $cfg, $key ) {
	if ( 'admin' !== $key || empty( $_GET['edit'] ) ) {
		return $cfg;
	}
	$y = isset( $_GET['year'] ) ? (int) $_GET['year'] : 0;
	if ( $y && ogc_valid_year( $y ) && ogc_is_member( $y ) ) {
		$cfg['editors']['public'] = ogc_ed_public_lines( $y );
	}
	return $cfg;
}, 30, 2 );

/* ================================================================== history */

add_filter( 'ogc_schema', function ( $sql, $charset ) {
	// Every change to an editor file's row: who, when, the fields before and after (never people's
	// records: these files hold the year's events, shifts and places).
	$sql[] = 'CREATE TABLE ' . ogc_table( 'rowlog' ) . " (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  year smallint(5) unsigned NOT NULL,
  name varchar(48) NOT NULL,
  row_id varchar(48) NOT NULL DEFAULT '',
  at datetime NOT NULL,
  user bigint(20) unsigned NOT NULL DEFAULT 0,
  action varchar(16) NOT NULL,
  before_json longtext NULL,
  after_json longtext NULL,
  PRIMARY KEY  (id),
  KEY year_name (year,name),
  KEY row_id (row_id)
) $charset;";
	return $sql;
}, 10, 2 );

function ogc_ed_hist_add( $year, $name, $row_id, $action, $before, $after ) {
	global $wpdb;
	$wpdb->insert(
		ogc_table( 'rowlog' ),
		array(
			'year'        => (int) $year,
			'name'        => $name,
			'row_id'      => substr( (string) $row_id, 0, 48 ),
			'at'          => ogc_now(),
			'user'        => get_current_user_id(),
			'action'      => $action,
			'before_json' => null === $before ? null : ogc_json( $before ),
			'after_json'  => null === $after ? null : ogc_json( $after ),
		),
		array( '%d', '%s', '%s', '%s', '%d', '%s', '%s', '%s' )
	);
}

/** Who last changed each row: row id → { by, at }. */
function ogc_ed_meta( $year, $name ) {
	global $wpdb;
	$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT row_id, user, at FROM ' . ogc_table( 'rowlog' ) . ' WHERE year = %d AND name = %s ORDER BY id DESC LIMIT 3000', $year, $name ), ARRAY_A );
	$out  = array();
	$who  = array();
	foreach ( (array) $rows as $r ) {
		if ( isset( $out[ $r['row_id'] ] ) || '' === $r['row_id'] ) {
			continue;
		}
		$u = (int) $r['user'];
		if ( ! isset( $who[ $u ] ) ) {
			$who[ $u ] = ogc_ed_short( $u );
		}
		$out[ $r['row_id'] ] = array( 'by' => $who[ $u ], 'at' => $r['at'], 'me' => $u === get_current_user_id() );
	}
	return (object) $out;
}

// Saves from other pages (the year page saves whole files) are kept in the history too: the rows as
// they were are noted when a save is checked, and compared once it's saved.
$GLOBALS['ogc_ed_before'] = array();
$GLOBALS['ogc_ed_inside'] = false;
add_filter( 'ogc_file_rows_valid', function ( $ok, $rows, $year, $name ) {
	if ( ! is_wp_error( $ok ) && ! $GLOBALS['ogc_ed_inside'] && in_array( $name, ogc_ed_files(), true ) ) {
		$f = ogc_file_get( $year, $name );
		$GLOBALS['ogc_ed_before'][ $year . '/' . $name ] = $f ? $f['rows'] : array();
	}
	return $ok;
}, 99, 4 );

add_action( 'ogc_file_saved', function ( $year, $name, $version ) {
	$k = $year . '/' . $name;
	if ( isset( $GLOBALS['ogc_ed_before'][ $k ] ) ) {
		$before = $GLOBALS['ogc_ed_before'][ $k ];
		unset( $GLOBALS['ogc_ed_before'][ $k ] );
		$f = ogc_file_get( $year, $name );
		ogc_ed_hist_diff( $year, $name, $before, $f ? $f['rows'] : array() );
	}
}, 10, 3 );

/** The rows that changed between two copies of a file (by their _id), into the history. */
function ogc_ed_hist_diff( $year, $name, $before, $after ) {
	$b = array();
	foreach ( $before as $r ) {
		if ( ! empty( $r['_id'] ) ) {
			$b[ $r['_id'] ] = $r;
		}
	}
	$seen = array();
	foreach ( $after as $r ) {
		if ( empty( $r['_id'] ) ) {
			continue;
		}
		$id          = $r['_id'];
		$seen[ $id ] = true;
		if ( ! isset( $b[ $id ] ) ) {
			ogc_ed_hist_add( $year, $name, $id, 'add', null, $r );
			continue;
		}
		$was = array();
		$now = array();
		foreach ( array_unique( array_merge( array_keys( $b[ $id ] ), array_keys( $r ) ) ) as $f ) {
			$x = isset( $b[ $id ][ $f ] ) ? (string) $b[ $id ][ $f ] : '';
			$y = isset( $r[ $f ] ) ? (string) $r[ $f ] : '';
			if ( $x !== $y ) {
				$was[ $f ] = $x;
				$now[ $f ] = $y;
			}
		}
		if ( $now ) {
			ogc_ed_hist_add( $year, $name, $id, 'set', $was, $now );
		}
	}
	foreach ( $b as $id => $r ) {
		if ( ! isset( $seen[ $id ] ) ) {
			ogc_ed_hist_add( $year, $name, $id, 'remove', $r, null );
		}
	}
}

/* ================================================================== routes */

add_action( 'rest_api_init', 'ogc_ed_routes' );

function ogc_ed_routes() {
	$Y = '(?P<year>\d{4})';
	$N = '(?P<name>[a-z][a-z0-9_-]{0,47})';
	register_rest_route( OGC_NS, "/years/$Y/rows/$N", array(
		array( 'methods' => 'POST', 'callback' => 'ogc_ed_rest_rows', 'permission_callback' => 'ogc_can_member' ),
	) );
	register_rest_route( OGC_NS, "/years/$Y/sync/$N", array(
		array( 'methods' => 'POST', 'callback' => 'ogc_ed_rest_sync', 'permission_callback' => 'ogc_can_member' ),
	) );
	register_rest_route( OGC_NS, "/years/$Y/history/$N", array(
		array( 'methods' => 'GET', 'callback' => 'ogc_ed_rest_history', 'permission_callback' => 'ogc_can_member' ),
	) );
	register_rest_route( OGC_NS, "/years/$Y/recode", array(
		array( 'methods' => 'POST', 'callback' => 'ogc_ed_rest_recode', 'permission_callback' => 'ogc_can_member' ),
	) );
	register_rest_route( OGC_NS, "/years/$Y/export", array(
		array( 'methods' => 'GET', 'callback' => 'ogc_ed_rest_export', 'permission_callback' => 'ogc_can_member' ),
	) );
	register_rest_route( OGC_NS, "/years/$Y/started", array(
		array( 'methods' => 'POST', 'callback' => 'ogc_ed_rest_started', 'permission_callback' => 'ogc_can_webmaster' ),
		array( 'methods' => 'DELETE', 'callback' => 'ogc_ed_rest_unstart', 'permission_callback' => 'ogc_can_webmaster' ),
	) );
	register_rest_route( OGC_NS, "/years/$Y/sermons-waiting", array(
		array( 'methods' => 'GET', 'callback' => 'ogc_ed_rest_sermons', 'permission_callback' => 'ogc_can_member' ),
	) );
	register_rest_route( OGC_NS, "/years/$Y/webinfo", array(
		array( 'methods' => 'GET', 'callback' => 'ogc_ed_rest_webinfo', 'permission_callback' => 'ogc_can_webmaster' ),
	) );
	register_rest_route( OGC_NS, '/xlsx', array(
		array( 'methods' => 'POST', 'callback' => 'ogc_ed_rest_xlsx', 'permission_callback' => function () {
			return ogc_member_years() ? true : ogc_rest_denied();
		} ),
	) );
	register_rest_route( OGC_NS, '/webmasters', array(
		array( 'methods' => 'GET', 'callback' => 'ogc_ed_rest_webmasters', 'permission_callback' => 'ogc_can_webmaster' ),
		array( 'methods' => 'POST', 'callback' => 'ogc_ed_rest_webmaster_ask', 'permission_callback' => 'ogc_can_webmaster' ),
	) );
	register_rest_route( OGC_NS, '/webmasters/confirm', array(
		array( 'methods' => 'POST', 'callback' => 'ogc_ed_rest_webmaster_confirm', 'permission_callback' => 'ogc_can_webmaster' ),
	) );
}

/* ---------------------------------------------------------------- rows */

/**
 * Change rows of an editor file, one at a time, on the server's current copy:
 *   { op: 'set',    id, fields: {k: v}, base: {k: value when read} }   a field changed by someone else
 *                                                                    since (≠ base and ≠ mine) is left,
 *                                                                    and comes back in "conflicts"
 *   { op: 'add',    row (its _id, made here if missing or taken), before: id | '' }
 *   { op: 'remove', id }
 *   { op: 'move',   id, before: id | '' (the end) }
 *   { op: 'ids' }   every row gets a lasting _id
 * Answers { version, rows, cols, conflicts, ids: {asked: given}, meta }. (A shift's volunteers are told
 * of a change by the volunteer area, on ogc_file_saved.)
 */
function ogc_ed_rest_rows( WP_REST_Request $req ) {
	$y    = (int) $req['year'];
	$name = $req['name'];
	if ( ! in_array( $name, ogc_ed_files(), true ) ) {
		return new WP_Error( 'ogc_no_file', 'Not an editor file.', array( 'status' => 404 ) );
	}
	$ops = $req->get_param( 'ops' );
	if ( ! is_array( $ops ) || count( $ops ) > 500 ) {
		return new WP_Error( 'ogc_bad_ops', 'ops is a list.', array( 'status' => 400 ) );
	}
	$res = ogc_ed_apply( $y, $name, $ops );
	if ( is_wp_error( $res ) ) {
		return $res;
	}
	$res['meta'] = ogc_ed_meta( $y, $name );
	return rest_ensure_response( $res );
}

function ogc_ed_apply( $y, $name, $ops ) {
	$GLOBALS['ogc_ed_inside'] = true;
	$out                      = null;
	for ( $try = 0; $try < 6; $try++ ) {
		$cur   = ogc_file_get( $y, $name );
		$rows  = $cur ? array_values( $cur['rows'] ) : array();
		$taken = array();
		foreach ( $rows as $r ) {
			if ( ! empty( $r['_id'] ) ) {
				$taken[ $r['_id'] ] = true;
			}
		}
		foreach ( $rows as &$r ) {
			if ( empty( $r['_id'] ) ) {
				$r['_id']           = ogc_ed_new_id( $taken );
				$taken[ $r['_id'] ] = true;
			}
		}
		unset( $r );
		$before    = $rows;
		$conflicts = array();
		$ids       = array();
		$hist      = array();
		$at        = function ( $id ) use ( &$rows ) {
			foreach ( $rows as $i => $r ) {
				if ( isset( $r['_id'] ) && $r['_id'] === $id ) {
					return $i;
				}
			}
			return -1;
		};
		foreach ( $ops as $op ) {
			if ( ! is_array( $op ) || empty( $op['op'] ) ) {
				continue;
			}
			$kind = $op['op'];
			$id   = isset( $op['id'] ) ? (string) $op['id'] : '';
			if ( 'set' === $kind ) {
				$i = $at( $id );
				if ( $i < 0 ) {
					$conflicts[] = array( 'id' => $id, 'gone' => true );
					continue;
				}
				$fields = isset( $op['fields'] ) && is_array( $op['fields'] ) ? $op['fields'] : array();
				$base   = isset( $op['base'] ) && is_array( $op['base'] ) ? $op['base'] : array();
				$was    = array();
				$now    = array();
				foreach ( $fields as $k => $v ) {
					$k = (string) $k;
					if ( '_id' === $k || ( null !== $v && ! is_scalar( $v ) ) ) {
						continue;
					}
					$v    = null === $v ? '' : (string) $v;
					$curv = isset( $rows[ $i ][ $k ] ) ? (string) $rows[ $i ][ $k ] : '';
					if ( array_key_exists( $k, $base ) && (string) $base[ $k ] !== $curv && $curv !== $v ) {
						$conflicts[] = array( 'id' => $id, 'field' => $k, 'theirs' => $curv, 'mine' => $v );
						continue;
					}
					if ( $curv !== $v ) {
						$was[ $k ]          = $curv;
						$now[ $k ]          = $v;
						$rows[ $i ][ $k ]   = $v;
					}
				}
				if ( $now ) {
					$hist[] = array( $id, 'set', $was, $now );
				}
			} elseif ( 'add' === $kind ) {
				$row = isset( $op['row'] ) && is_array( $op['row'] ) ? $op['row'] : array();
				$ask = isset( $row['_id'] ) ? (string) $row['_id'] : '';
				$nid = preg_match( '/^[A-Za-z0-9_-]{1,40}$/', $ask ) && ! isset( $taken[ $ask ] ) ? $ask : ogc_ed_new_id( $taken );
				$taken[ $nid ] = true;
				$row['_id']    = $nid;
				if ( $ask ) {
					$ids[ $ask ] = $nid;
				}
				$b = isset( $op['before'] ) ? $at( (string) $op['before'] ) : -1;
				if ( $b < 0 ) {
					$rows[] = $row;
				} else {
					array_splice( $rows, $b, 0, array( $row ) );
				}
				$hist[] = array( $nid, 'add', null, $row );
			} elseif ( 'remove' === $kind ) {
				$i = $at( $id );
				if ( $i < 0 ) {
					continue;
				}
				$hist[] = array( $id, 'remove', $rows[ $i ], null );
				array_splice( $rows, $i, 1 );
			} elseif ( 'move' === $kind ) {
				$i = $at( $id );
				if ( $i < 0 ) {
					continue;
				}
				$row = $rows[ $i ];
				array_splice( $rows, $i, 1 );
				$b = isset( $op['before'] ) && '' !== $op['before'] ? $at( (string) $op['before'] ) : -1;
				if ( $b < 0 ) {
					$rows[] = $row;
				} else {
					array_splice( $rows, $b, 0, array( $row ) );
				}
			}
		}
		$ok = ogc_check_rows( $rows, $y, $name );
		if ( is_wp_error( $ok ) ) {
			$GLOBALS['ogc_ed_inside'] = false;
			return $ok;
		}
		$changed = $rows !== ( $cur ? array_values( $cur['rows'] ) : array() );
		$v       = $cur ? $cur['version'] : 0;
		if ( $changed ) {
			$v = ogc_file_put( $y, $name, $rows, $cur ? $cur['version'] : 0, $cur ? $cur['cols'] : array_keys( $rows ? $rows[0] : array() ) );
			if ( is_wp_error( $v ) ) {
				continue;   // someone saved in between: apply again on their copy
			}
		}
		foreach ( $hist as $h ) {
			ogc_ed_hist_add( $y, $name, $h[0], $h[1], $h[2], $h[3] );
		}
		if ( 'schedule' === $name ) {
			ogc_ed_carry_links( $y, $before, $rows );
		}
		if ( $changed ) {
			ogc_log( 'rows', $y, $name, array( 'version' => $v, 'ops' => count( $ops ) ) );
			do_action( 'ogc_file_saved', $y, $name, $v );
		}
		$f   = ogc_file_get( $y, $name );
		$out = array(
			'version'   => (int) $v,
			'rows'      => $f ? $f['rows'] : array(),
			'cols'      => $f ? $f['cols'] : array(),
			'conflicts' => $conflicts,
			'ids'       => (object) $ids,
		);
		break;
	}
	$GLOBALS['ogc_ed_inside'] = false;
	return $out ? $out : new WP_Error( 'ogc_busy', 'Busy · Retry', array( 'status' => 503 ) );
}

/* ---------------------------------------------------------------- what hangs on a row */

/**
 * A schedule row moved or renamed: what's pinned to it by value follows it. Sermons and recordings
 * (attachments.csv) are pinned by day and start (and the row's title); tournaments name their row by
 * title (and, from the editors, by its id). Late changes on the first day must never unpin a sermon.
 */
function ogc_ed_carry_links( $y, $before, $after ) {
	$was = array();
	foreach ( $before as $r ) {
		if ( ! empty( $r['_id'] ) ) {
			$was[ $r['_id'] ] = $r;
		}
	}
	$moves = array();
	foreach ( $after as $r ) {
		if ( empty( $r['_id'] ) || ! isset( $was[ $r['_id'] ] ) ) {
			continue;
		}
		$o = $was[ $r['_id'] ];
		$k = function ( $x, $f ) {
			return isset( $x[ $f ] ) ? (string) $x[ $f ] : '';
		};
		if ( $k( $o, 'day' ) !== $k( $r, 'day' ) || $k( $o, 'start' ) !== $k( $r, 'start' ) || $k( $o, 'title' ) !== $k( $r, 'title' ) ) {
			$moves[] = array( $o, $r );
		}
	}
	if ( ! $moves ) {
		return;
	}
	$t = function ( $v ) {
		$v = strtolower( trim( (string) $v ) );
		if ( 'noon' === $v ) {
			return 720;
		}
		if ( preg_match( '/^(\d{1,2})(?::(\d{2}))?\s*(am|pm)?$/', $v, $m ) ) {
			$h = (int) $m[1] % 12 + ( isset( $m[3] ) && 'pm' === $m[3] ? 12 : 0 );
			return $h * 60 + ( isset( $m[2] ) ? (int) $m[2] : 0 );
		}
		return $v;
	};
	$inside                   = $GLOBALS['ogc_ed_inside'];
	$GLOBALS['ogc_ed_inside'] = true;
	foreach ( array( 'attachments', 'tournaments' ) as $file ) {
		$f = ogc_file_get( $y, $file );
		if ( ! $f || ! $f['rows'] ) {
			continue;
		}
		$rows = $f['rows'];
		$hit  = false;
		foreach ( $rows as &$a ) {
			foreach ( $moves as $mv ) {
				list( $o, $n ) = $mv;
				if ( 'attachments' === $file ) {
					$same = strtolower( (string) ( isset( $a['day'] ) ? $a['day'] : '' ) ) === strtolower( (string) $o['day'] ) && $t( isset( $a['start'] ) ? $a['start'] : '' ) === $t( isset( $o['start'] ) ? $o['start'] : '' )
						&& ( empty( $a['match'] ) || strtolower( $a['match'] ) === strtolower( (string) $o['title'] ) );
					if ( $same ) {
						$a['day']   = $n['day'];
						$a['start'] = isset( $n['start'] ) ? $n['start'] : '';
						if ( ! empty( $a['match'] ) ) {
							$a['match'] = $n['title'];
						}
						$hit = true;
					}
				} elseif ( ( ! empty( $a['schedule_id'] ) && $a['schedule_id'] === $o['_id'] ) || ( ! empty( $a['schedule_title'] ) && strtolower( $a['schedule_title'] ) === strtolower( (string) $o['title'] ) ) ) {
					if ( (string) $a['schedule_title'] !== (string) $n['title'] || empty( $a['schedule_id'] ) ) {
						$a['schedule_title'] = $n['title'];
						$a['schedule_id']    = $n['_id'];
						$hit                 = true;
					}
				}
			}
		}
		unset( $a );
		if ( $hit && ! is_wp_error( ogc_file_put( $y, $file, $rows, $f['version'], $f['cols'] ) ) ) {
			ogc_log( 'links_carried', $y, $file, array() );
		}
	}
	$GLOBALS['ogc_ed_inside'] = $inside;
}

/* ---------------------------------------------------------------- sync, presence */

/** Every half minute an open editor asks: who else is here, and has the file changed? */
function ogc_ed_rest_sync( WP_REST_Request $req ) {
	$y    = (int) $req['year'];
	$name = $req['name'];
	$key  = 'ogc_ed_here_' . $y . '_' . $name;
	$here = get_transient( $key );
	$here = is_array( $here ) ? $here : array();
	$now  = time();
	$uid  = get_current_user_id();
	$grp  = substr( sanitize_text_field( (string) $req->get_param( 'group' ) ), 0, 60 );
	$row  = substr( sanitize_text_field( (string) $req->get_param( 'row' ) ), 0, 48 );
	if ( $req->get_param( 'leave' ) ) {
		unset( $here[ $uid ] );
	} else {
		$here[ $uid ] = array( 'name' => ogc_ed_short( $uid ), 'group' => $grp, 'row' => $row, 'at' => $now );
	}
	$others = array();
	foreach ( $here as $u => $h ) {
		if ( $h['at'] < $now - 75 ) {
			unset( $here[ $u ] );
		} elseif ( (int) $u !== $uid ) {
			$others[] = array( 'name' => $h['name'], 'group' => $h['group'], 'row' => $h['row'] );
		}
	}
	set_transient( $key, $here, 300 );
	$f   = ogc_file_get( $y, $name );
	$ver = $f ? (int) $f['version'] : 0;
	$out = array( 'here' => $others, 'version' => $ver );
	if ( $req->get_param( 'meta' ) ) {
		$out['meta'] = ogc_ed_meta( $y, $name );
	}
	if ( (int) $req->get_param( 'version' ) !== $ver ) {
		$out['rows'] = $f ? $f['rows'] : array();
		$out['cols'] = $f ? $f['cols'] : array();
		$out['meta'] = ogc_ed_meta( $y, $name );
	}
	return rest_ensure_response( $out );
}

/** A file's (or one row's) history, newest first. */
function ogc_ed_rest_history( WP_REST_Request $req ) {
	global $wpdb;
	$y     = (int) $req['year'];
	$limit = min( 300, max( 1, (int) ( $req->get_param( 'limit' ) ?: 80 ) ) );
	$row   = (string) $req->get_param( 'row' );
	if ( '' !== $row ) {
		$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . ogc_table( 'rowlog' ) . ' WHERE year = %d AND name = %s AND row_id = %s ORDER BY id DESC LIMIT %d', $y, $req['name'], $row, $limit ), ARRAY_A );
	} else {
		$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . ogc_table( 'rowlog' ) . ' WHERE year = %d AND name = %s ORDER BY id DESC LIMIT %d', $y, $req['name'], $limit ), ARRAY_A );
	}
	$who = array();
	$out = array();
	foreach ( (array) $rows as $r ) {
		$u = (int) $r['user'];
		if ( ! isset( $who[ $u ] ) ) {
			$who[ $u ] = ogc_ed_short( $u );
		}
		$out[] = array( 'id' => (int) $r['id'], 'at' => $r['at'], 'who' => $who[ $u ], 'row' => $r['row_id'], 'action' => $r['action'], 'before' => ogc_unjson( $r['before_json'] ), 'after' => ogc_unjson( $r['after_json'] ) );
	}
	return rest_ensure_response( $out );
}

/* ---------------------------------------------------------------- place codes */

/**
 * Codes renamed everywhere they're used, as one change: { map: { OLD: NEW } } (and the place itself
 * renamed in places, unless NEW is already there). Used by Buildings and rooms (a code changed) and by a
 * new campus (each old code matched to a place there).
 */
function ogc_ed_rest_recode( WP_REST_Request $req ) {
	$y   = (int) $req['year'];
	$map = $req->get_param( 'map' );
	if ( ! is_array( $map ) || ! $map || count( $map ) > 300 ) {
		return new WP_Error( 'ogc_bad_map', 'map is { old: new }.', array( 'status' => 400 ) );
	}
	$m = array();
	foreach ( $map as $a => $b ) {
		$a = strtoupper( trim( (string) $a ) );
		$b = trim( (string) $b );
		if ( '' === $a || ogc_ed_value_problem( 'places', 'code', $a ) || ( '' !== $b && ogc_ed_value_problem( 'places', 'code', $b ) ) ) {
			return new WP_Error( 'ogc_bad_map', 'Not a place code', array( 'status' => 400 ) );
		}
		$m[ $a ] = $b;
	}
	$swap = function ( $v ) use ( $m ) {
		$k = strtoupper( trim( (string) $v ) );
		return isset( $m[ $k ] ) ? $m[ $k ] : $v;
	};
	$out = array( 'files' => array() );
	foreach ( array( 'places', 'schedule', 'shifts' ) as $name ) {
		$f = ogc_file_get( $y, $name );
		if ( ! $f ) {
			continue;
		}
		// Rows without a lasting id get one first, so each can be changed by it.
		foreach ( $f['rows'] as $r ) {
			if ( empty( $r['_id'] ) ) {
				$res = ogc_ed_apply( $y, $name, array( array( 'op' => 'ids' ) ) );
				if ( is_wp_error( $res ) ) {
					return $res;
				}
				$f = ogc_file_get( $y, $name );
				break;
			}
		}
		$ops = array();
		if ( 'places' === $name ) {
			if ( ! $req->get_param( 'rename' ) ) {
				continue;
			}
			$have = array();
			foreach ( $f['rows'] as $r ) {
				$have[ strtoupper( (string) ( isset( $r['code'] ) ? $r['code'] : '' ) ) ] = true;
			}
			foreach ( $f['rows'] as $r ) {
				$c = strtoupper( (string) ( isset( $r['code'] ) ? $r['code'] : '' ) );
				if ( isset( $m[ $c ] ) && '' !== $m[ $c ] && empty( $have[ strtoupper( $m[ $c ] ) ] ) && ! empty( $r['_id'] ) ) {
					$ops[] = array( 'op' => 'set', 'id' => $r['_id'], 'fields' => array( 'code' => $m[ $c ] ) );
				}
			}
		} else {
			foreach ( $f['rows'] as $r ) {
				if ( empty( $r['_id'] ) ) {
					continue;
				}
				$set = array();
				if ( isset( $r['place'] ) && $swap( $r['place'] ) !== $r['place'] ) {
					$set['place'] = $swap( $r['place'] );
				}
				if ( ! empty( $r['also'] ) ) {
					$also = implode( '|', array_filter( array_map( $swap, explode( '|', $r['also'] ) ), 'strlen' ) );
					if ( $also !== $r['also'] ) {
						$set['also'] = $also;
					}
				}
				if ( $set ) {
					$ops[] = array( 'op' => 'set', 'id' => $r['_id'], 'fields' => $set );
				}
			}
		}
		if ( ! $ops ) {
			continue;
		}
		$res = ogc_ed_apply( $y, $name, $ops );
		if ( is_wp_error( $res ) ) {
			return $res;
		}
		$out['files'][ $name ] = array( 'version' => $res['version'], 'n' => count( $ops ) );
	}
	ogc_log( 'recode', $y, 'places', array( 'n' => count( $m ) ) );
	return rest_ensure_response( $out );
}

/* ---------------------------------------------------------------- export a year */

/** A cell safe to open in Excel: one starting =, +, -, @, a tab or a return is written with an
 * apostrophe first (times and numbers left alone). */
function ogc_ed_safe_cell( $v ) {
	$v = (string) $v;
	if ( '' !== $v && preg_match( '/^[=+\-@\t\r]/', $v ) && ! preg_match( '/^[+-]?\d[\d.,:]*$/', $v ) ) {
		return "'" . $v;
	}
	return $v;
}

/** Every part of a year as CSVs in one zip (never people's records). Written without ZipArchive. */
function ogc_ed_rest_export( WP_REST_Request $req ) {
	$y     = (int) $req['year'];
	$files = array();
	foreach ( array_keys( ogc_file_list( $y ) ) as $name ) {
		$f = ogc_file_get( $y, $name );
		$rows = array();
		foreach ( $f['rows'] as $r ) {
			$o = array();
			foreach ( $r as $k => $v ) {
				$o[ $k ] = ogc_ed_safe_cell( $v );
			}
			$rows[] = $o;
		}
		$files[ $y . '/' . $name . '.csv' ] = "\xEF\xBB\xBF" . ogc_csv_write( $rows, $f['cols'] );
	}
	$yr = ogc_year_get( $y );
	if ( $yr ) {
		$files[ $y . '/year.csv' ] = "\xEF\xBB\xBF" . ogc_csv_write( array( $yr ), ogc_year_columns() );
	}
	$zip = ogc_ed_zip( $files );
	ogc_log( 'export', $y, 'year', array( 'files' => count( $files ) ) );
	$prev = ogc_state_get( $y, 'exported' );
	ogc_state_put( $y, 'exported', array( 'at' => ogc_ed_today( $y ), 'by' => ogc_ed_short( get_current_user_id() ) ) );
	nocache_headers();
	header( 'Content-Type: application/zip' );
	header( 'Content-Disposition: attachment; filename="' . $y . ' Annual Conference.zip"' );
	header( 'Content-Length: ' . strlen( $zip ) );
	echo $zip; // phpcs:ignore WordPress.Security.EscapeOutput -- a zip file.
	exit;
}

/** A zip (stored, not compressed) of name → text. */
function ogc_ed_zip( $files ) {
	$data = '';
	$dir  = '';
	$n    = 0;
	$t    = getdate();
	$dt   = ( ( $t['hours'] << 11 ) | ( $t['minutes'] << 5 ) | ( $t['seconds'] >> 1 ) ) & 0xFFFF;
	$dd   = ( ( ( $t['year'] - 1980 ) << 9 ) | ( $t['mon'] << 5 ) | $t['mday'] ) & 0xFFFF;
	foreach ( $files as $name => $body ) {
		$crc  = crc32( $body );
		$len  = strlen( $body );
		$off  = strlen( $data );
		$head = pack( 'VvvvvvVVVvv', 0x04034b50, 20, 0x0800, 0, $dt, $dd, $crc, $len, $len, strlen( $name ), 0 );
		$data .= $head . $name . $body;
		$dir  .= pack( 'VvvvvvvVVVvvvvvVV', 0x02014b50, 20, 20, 0x0800, 0, $dt, $dd, $crc, $len, $len, strlen( $name ), 0, 0, 0, 0, 0, $off ) . $name;
		$n++;
	}
	return $data . $dir . pack( 'VvvvvVVv', 0x06054b50, 0, 0, $n, $n, strlen( $dir ), strlen( $data ), 0 );
}

/** The files inside a zip: name → bytes (stored or deflated entries). */
function ogc_ed_unzip( $bin ) {
	$out = array();
	$end = strrpos( $bin, "PK\x05\x06" );
	if ( false === $end ) {
		return $out;
	}
	$e   = unpack( 'vdisk/vstart/vn/vtotal/Vsize/Voffset', substr( $bin, $end + 4, 16 ) );
	$p   = $e['offset'];
	for ( $i = 0; $i < $e['total'] && $p < strlen( $bin ); $i++ ) {
		if ( "PK\x01\x02" !== substr( $bin, $p, 4 ) ) {
			break;
		}
		$c    = unpack( 'vmade/vneed/vflag/vmethod/vtime/vdate/Vcrc/Vcsize/Vsize/vnlen/vxlen/vclen/vdisk/vint/Vext/Voff', substr( $bin, $p + 4, 42 ) );
		$name = substr( $bin, $p + 46, $c['nlen'] );
		$p   += 46 + $c['nlen'] + $c['xlen'] + $c['clen'];
		$l    = unpack( 'vnlen/vxlen', substr( $bin, $c['off'] + 26, 4 ) );
		$raw  = substr( $bin, $c['off'] + 30 + $l['nlen'] + $l['xlen'], $c['csize'] );
		if ( 0 === $c['method'] ) {
			$out[ $name ] = $raw;
		} elseif ( 8 === $c['method'] && function_exists( 'gzinflate' ) ) {
			$d = @gzinflate( $raw ); // phpcs:ignore WordPress.PHP.NoSilencedErrors -- a bad entry is skipped.
			if ( false !== $d ) {
				$out[ $name ] = $d;
			}
		}
	}
	return $out;
}

/* ---------------------------------------------------------------- .xlsx */

/** The first sheet of an Excel file as rows of text (dates as YYYY-MM-DD, times as 7:00 PM). */
function ogc_ed_rest_xlsx( WP_REST_Request $req ) {
	$b64 = (string) $req->get_param( 'data' );
	if ( strlen( $b64 ) > 4 * 1024 * 1024 ) {
		return new WP_Error( 'ogc_too_big', 'Too big', array( 'status' => 413 ) );
	}
	$bin = base64_decode( $b64, true );
	if ( false === $bin || "PK" !== substr( $bin, 0, 2 ) ) {
		return new WP_Error( 'ogc_not_xlsx', 'Not an Excel file', array( 'status' => 400 ) );
	}
	$rows = ogc_ed_xlsx_rows( $bin );
	if ( is_wp_error( $rows ) ) {
		return $rows;
	}
	return rest_ensure_response( array( 'rows' => $rows ) );
}

function ogc_ed_xml( $text ) {
	if ( ! function_exists( 'simplexml_load_string' ) || '' === $text ) {
		return null;
	}
	$prev = libxml_use_internal_errors( true );
	$x    = simplexml_load_string( $text, 'SimpleXMLElement', LIBXML_NONET );
	libxml_use_internal_errors( $prev );
	return $x ? $x : null;
}

function ogc_ed_xlsx_rows( $bin ) {
	$z = ogc_ed_unzip( $bin );
	if ( ! isset( $z['xl/workbook.xml'] ) ) {
		return new WP_Error( 'ogc_not_xlsx', 'Not an Excel file', array( 'status' => 400 ) );
	}
	// Which file is the first sheet.
	$sheet = 'xl/worksheets/sheet1.xml';
	$wb    = ogc_ed_xml( $z['xl/workbook.xml'] );
	$rels  = isset( $z['xl/_rels/workbook.xml.rels'] ) ? ogc_ed_xml( $z['xl/_rels/workbook.xml.rels'] ) : null;
	if ( $wb && $rels && isset( $wb->sheets->sheet[0] ) ) {
		$rid = (string) $wb->sheets->sheet[0]->attributes( 'http://schemas.openxmlformats.org/officeDocument/2006/relationships' )->id;
		foreach ( $rels->Relationship as $r ) {
			if ( (string) $r['Id'] === $rid ) {
				$t     = ltrim( (string) $r['Target'], '/' );
				$sheet = 0 === strpos( $t, 'xl/' ) ? $t : 'xl/' . $t;
			}
		}
	}
	if ( ! isset( $z[ $sheet ] ) ) {
		return new WP_Error( 'ogc_not_xlsx', 'No sheet', array( 'status' => 400 ) );
	}
	$strings = array();
	if ( isset( $z['xl/sharedStrings.xml'] ) ) {
		$ss = ogc_ed_xml( $z['xl/sharedStrings.xml'] );
		foreach ( $ss ? $ss->si : array() as $si ) {
			if ( isset( $si->t ) ) {
				$strings[] = (string) $si->t;
			} else {
				$s = '';
				foreach ( $si->r as $run ) {
					$s .= (string) $run->t;
				}
				$strings[] = $s;
			}
		}
	}
	// Which styles are dates or times.
	$datey = array();
	if ( isset( $z['xl/styles.xml'] ) ) {
		$st     = ogc_ed_xml( $z['xl/styles.xml'] );
		$custom = array();
		foreach ( $st && isset( $st->numFmts ) ? $st->numFmts->numFmt : array() as $nf ) {
			$custom[ (int) $nf['numFmtId'] ] = (string) $nf['formatCode'];
		}
		$i = 0;
		foreach ( $st && isset( $st->cellXfs ) ? $st->cellXfs->xf : array() as $xf ) {
			$id   = (int) $xf['numFmtId'];
			$code = isset( $custom[ $id ] ) ? strtolower( preg_replace( '/"[^"]*"|\[[^\]]*\]/', '', $custom[ $id ] ) ) : '';
			$time = in_array( $id, array( 18, 19, 20, 21, 45, 46, 47 ), true ) || ( $code && preg_match( '/h/', $code ) );
			$date = in_array( $id, array( 14, 15, 16, 17, 22 ), true ) || ( $code && preg_match( '/[dy]|m{3,}/', $code ) );
			$datey[ $i ] = $time && ! $date ? 'time' : ( $date ? ( $time ? 'datetime' : 'date' ) : '' );
			$i++;
		}
	}
	$xml = ogc_ed_xml( $z[ $sheet ] );
	if ( ! $xml ) {
		return new WP_Error( 'ogc_not_xlsx', 'No sheet', array( 'status' => 400 ) );
	}
	$col  = function ( $ref ) {
		$l = preg_replace( '/\d+/', '', $ref );
		$n = 0;
		for ( $i = 0; $i < strlen( $l ); $i++ ) {
			$n = $n * 26 + ( ord( $l[ $i ] ) - 64 );
		}
		return $n - 1;
	};
	$time = function ( $f ) {
		$m  = (int) round( ( $f - floor( $f ) ) * 1440 );
		$h  = intdiv( $m, 60 ) % 24;
		$mm = $m % 60;
		return ( $h % 12 ? $h % 12 : 12 ) . ':' . str_pad( (string) $mm, 2, '0', STR_PAD_LEFT ) . ( $h < 12 ? ' AM' : ' PM' );
	};
	$out = array();
	foreach ( $xml->sheetData->row as $row ) {
		$line = array();
		foreach ( $row->c as $c ) {
			$i = $col( (string) $c['r'] );
			$t = (string) $c['t'];
			$v = isset( $c->v ) ? (string) $c->v : '';
			if ( 's' === $t ) {
				$v = isset( $strings[ (int) $v ] ) ? $strings[ (int) $v ] : '';
			} elseif ( 'inlineStr' === $t ) {
				$v = isset( $c->is->t ) ? (string) $c->is->t : '';
			} elseif ( '' === $t || 'n' === $t ) {
				$s = isset( $c['s'] ) ? (int) $c['s'] : -1;
				$k = isset( $datey[ $s ] ) ? $datey[ $s ] : '';
				if ( '' !== $v && is_numeric( $v ) && $k ) {
					$f = (float) $v;
					$d = gmdate( 'Y-m-d', (int) round( ( floor( $f ) - 25569 ) * 86400 ) );
					$v = 'time' === $k ? $time( $f ) : ( 'date' === $k ? $d : $d . ' ' . $time( $f ) );
				}
			}
			while ( count( $line ) < $i ) {
				$line[] = '';
			}
			$line[ $i ] = $v;
		}
		$out[] = $line;
		if ( count( $out ) > 5000 ) {
			break;
		}
	}
	return $out;
}

/* ---------------------------------------------------------------- starting a year */

/** Just started (and picked up): the file versions are noted, so it can be taken back while untouched. */
function ogc_ed_rest_started( WP_REST_Request $req ) {
	$y   = (int) $req['year'];
	$ver = array();
	foreach ( ogc_file_list( $y ) as $n => $f ) {
		$ver[ $n ] = $f['version'];
	}
	ogc_state_put( $y, 'started', array( 'at' => ogc_now(), 'by' => get_current_user_id(), 'versions' => $ver ) );
	return rest_ensure_response( array( 'ok' => true, 'untouched' => true ) );
}

/** Whether a started year is still as it was started (nothing changed, nobody invited, no records). */
function ogc_ed_untouched( $y ) {
	$s = ogc_state_get( $y, 'started' );
	if ( ! $s || ! is_array( $s['value'] ) ) {
		return false;
	}
	$was = (array) $s['value']['versions'];
	$now = ogc_file_list( $y );
	// Files another area writes on its own when the year is first opened (the app's committees.csv,
	// carried forward) don't count as someone's work: that area says so (filter ogc_untouched_skip).
	$skip = (array) apply_filters( 'ogc_untouched_skip', array(), $y );
	foreach ( $skip as $n ) {
		unset( $was[ $n ], $now[ $n ] );
	}
	if ( count( $was ) !== count( $now ) ) {
		return false;
	}
	foreach ( $now as $n => $f ) {
		if ( ! isset( $was[ $n ] ) || (int) $was[ $n ] !== (int) $f['version'] ) {
			return false;
		}
	}
	$m = ogc_state_get( $y, 'members' );
	if ( $m && ! empty( $m['value'] ) && (array) $m['value'] ) {
		return false;
	}
	foreach ( ogc_record_kinds() as $k ) {
		if ( ogc_records( $y, $k ) ) {
			return false;
		}
	}
	return true;
}

/** Take back a year started by mistake: only while untouched. Its years.csv row keeps its hosts. */
function ogc_ed_rest_unstart( WP_REST_Request $req ) {
	global $wpdb;
	$y = (int) $req['year'];
	if ( ! ogc_ed_untouched( $y ) ) {
		return new WP_Error( 'ogc_in_use', 'In use', array( 'status' => 409 ) );
	}
	$wpdb->query( $wpdb->prepare( 'DELETE FROM ' . ogc_table( 'files' ) . ' WHERE year = %d', $y ) );
	$wpdb->query( $wpdb->prepare( 'DELETE FROM ' . ogc_table( 'state' ) . ' WHERE year = %d', $y ) );
	ogc_store_forget();
	// Other areas' own rows for the year go too (the app's committees and tasks).
	do_action( 'ogc_year_unstart', $y );
	ogc_year_set( $y, array( 'data' => null ) );
	ogc_log( 'year_unstart', $y, 'years', array() );
	return rest_ensure_response( array( 'removed' => true ) );
}

add_filter( 'ogc_client_config', function ( $cfg, $key ) {
	if ( 'admin' === $key && ogc_is_webmaster() ) {
		$cfg['editors']['untouched'] = array();
		foreach ( ogc_years_list() as $y ) {
			if ( ogc_ed_untouched( $y ) ) {
				$cfg['editors']['untouched'][] = $y;
			}
		}
	}
	return $cfg;
}, 20, 2 );

/** What the webmasters' page shows of a year beyond its files: when it was exported, how long new
 * invites last, and whether it's a year just started that can still be taken back. */
function ogc_ed_rest_webinfo( WP_REST_Request $req ) {
	$y = (int) $req['year'];
	$e = ogc_state_get( $y, 'exported' );
	$i = ogc_state_get( $y, 'invite_years' );
	return rest_ensure_response( array( 'exported' => $e ? $e['value'] : null, 'invite_years' => $i ? (int) $i['value'] : 2, 'untouched' => ogc_ed_untouched( $y ) ) );
}

/* ---------------------------------------------------------------- sermons to link */

/** The year's sermons posted on the site and not yet pinned to a service (attachments.csv). Needs the
 * site's sermon post type; without it (locally) there are none. */
function ogc_ed_rest_sermons( WP_REST_Request $req ) {
	$y = (int) $req['year'];
	if ( ! post_type_exists( 'sermon' ) ) {
		return rest_ensure_response( array() );
	}
	$term = null;
	foreach ( get_object_taxonomies( 'sermon' ) as $tax ) {
		$t = get_term_by( 'slug', $y . '-annual-conference', $tax );
		if ( $t ) {
			$term = array( $tax, $t->term_id );
			break;
		}
	}
	if ( ! $term ) {
		return rest_ensure_response( array() );
	}
	$linked = array();
	$att    = ogc_file_get( $y, 'attachments' );
	foreach ( $att ? $att['rows'] : array() as $r ) {
		if ( ! empty( $r['url'] ) ) {
			$linked[ untrailingslashit( $r['url'] ) ] = true;
		}
	}
	$q   = new WP_Query( array( 'post_type' => 'sermon', 'posts_per_page' => 60, 'post_status' => 'publish', 'tax_query' => array( array( 'taxonomy' => $term[0], 'terms' => $term[1] ) ) ) );
	$out = array();
	foreach ( $q->posts as $p ) {
		$url = untrailingslashit( get_permalink( $p ) );
		if ( isset( $linked[ $url ] ) ) {
			continue;
		}
		$out[] = array( 'title' => get_the_title( $p ), 'url' => $url, 'date' => get_the_date( 'Y-m-d', $p ), 'time' => get_post_meta( $p->ID, 'recorded_at', true ), 'by' => (string) get_post_meta( $p->ID, 'speaker', true ) );
	}
	return rest_ensure_response( $out );
}

/* ---------------------------------------------------------------- webmasters */

function ogc_ed_last_signin( $uid ) {
	$t = get_user_meta( $uid, 'ogc_last_signin', true );
	if ( ! $t ) {
		$t = get_user_meta( $uid, 'ogc_signed_in_at', true );
	}
	if ( $t ) {
		return is_numeric( $t ) ? gmdate( 'Y-m-d H:i:s', (int) $t ) : (string) $t;
	}
	$best = 0;
	if ( class_exists( 'WP_Session_Tokens' ) ) {
		foreach ( WP_Session_Tokens::get_instance( $uid )->get_all() as $s ) {
			$best = max( $best, isset( $s['login'] ) ? (int) $s['login'] : 0 );
		}
	}
	return $best ? gmdate( 'Y-m-d H:i:s', $best ) : '';
}

/** The webmasters (every year's access), and what's waiting for a second webmaster. The one list and
 * the one rule are the signin area's (module-members.php: ogc_webmasters_payload, ogc_webmaster_ask,
 * ogc_webmaster_confirm), shared with Settings › Conference webmasters. */
function ogc_ed_rest_webmasters() {
	return rest_ensure_response( ogc_webmasters_payload() );
}

/** Ask to add or remove a webmaster: it waits for a second webmaster (no one person holds the keys). */
function ogc_ed_rest_webmaster_ask( WP_REST_Request $req ) {
	$r = $req->get_param( 'cancel' ) ? ogc_webmaster_cancel( (string) $req->get_param( 'email' ) ) : ogc_webmaster_ask( (string) $req->get_param( 'email' ), (string) $req->get_param( 'act' ), (string) $req->get_param( 'name' ) );
	return is_wp_error( $r ) ? $r : ogc_ed_rest_webmasters();
}

/** A second webmaster confirms. */
function ogc_ed_rest_webmaster_confirm( WP_REST_Request $req ) {
	$r = ogc_webmaster_confirm( (string) $req->get_param( 'email' ) );
	return is_wp_error( $r ) ? $r : ogc_ed_rest_webmasters();
}
