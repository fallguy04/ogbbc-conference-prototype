<?php
/**
 * The year's request round (night-requests, Oct 13; docs/scope/06 "Intake round", "Request to the
 * campus"; CHANGES/night-requests.md). Committees answer once a year, starting from last year's
 * answers, and the site does the copying, chasing and reissuing.
 *
 * One round a year. Each committee is asked, in one email with one link and one due date, for what it
 * tells the others:
 *   requests  its requests to the campus (needs.csv, carried from the last Conference at the campus)
 *   packet    its part of the information packet (guide.csv parts) and its Help card (help.csv)
 *   contact   who heads it (the members list, the COA's to change) and its role phone (committees.csv)
 * Each row is answered Keep · Change · Remove · Not sure. Not sure goes to the coordinator (the COA, or
 * the committee the COA hands Intake to), never to the webmasters.
 *
 * Screens:
 *   requests  every committee's own list (and the coordinator's view of any one): app/screens/coa-requests.js
 *   intake    the round: dates, Send, the board, Remind, To settle, Export for campus: app/screens/coa-intake.js
 *             The COA's screen, handable (the COA hands it to A/V on A/V's page, or from Intake's Run by).
 *
 * Kept:
 *   state "round" (per year)  send_off, due_off (days from the Conference's first day), remind (days
 *                             before the due date the one automatic reminder goes; 0 = off), asks, skip
 *                             (committee keys left out), owners ({item: committee key}: who answers for
 *                             each packet part and Help card), sent_at, sent_by, auto (the day the
 *                             automatic reminder went). A new year's is carried from last year's.
 *   table ogc_round_lines     one line a committee a year: sent, opened, started, returned, reminded
 *   table ogc_round_answers   the answer on a packet part, Help card or contact (requests keep theirs
 *                             on their own row in needs.csv, as before)
 *
 * Routes (/wp-json/ogc/v1/app/{y}/round…), each asking the screen's rule (ogc_app_can_see) and refusing
 * changes while seeing as (403) or previewing a date (the app's own guard):
 *   GET   round              the coordinator's board
 *   PATCH round              dates, reminder, asks, committees left out
 *   POST  round/send {c?}    email each committee its own link (never by itself)
 *   POST  round/remind {c?}  again, to those not returned (once a day a committee)
 *   GET   round/mine?c=      a committee's own round (its people, and the coordinator)
 *   POST  round/answer       {c, item, answer, note?, fields?}  a packet part, Help card or contact
 *   POST  round/return {c} · round/reopen {c}
 *   POST  round/assign       {item, c}  who answers for a packet part, Help card or unowned request
 *
 * Mechanical: nothing here reads a note or compares names. Owners are chosen by a person; an uploaded
 * sheet matches by ID, else by committee and item exactly (coa-requests.js).
 */

defined( 'ABSPATH' ) || exit;

/* ================================================================== tables */

add_filter( 'ogc_schema', function ( $sql, $charset ) {
	$sql[] = 'CREATE TABLE ' . ogc_table( 'round_lines' ) . " (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  year smallint(5) unsigned NOT NULL,
  ckey varchar(60) NOT NULL,
  sent_at datetime NULL,
  sent_n int(10) NOT NULL DEFAULT 0,
  opened_at datetime NULL,
  started_at datetime NULL,
  returned_at datetime NULL,
  returned_by bigint(20) unsigned NOT NULL DEFAULT 0,
  returned_name varchar(80) NOT NULL DEFAULT '',
  reminded_at datetime NULL,
  reminds int(10) NOT NULL DEFAULT 0,
  sample tinyint(1) NOT NULL DEFAULT 0,
  updated_at datetime NULL,
  PRIMARY KEY  (id),
  UNIQUE KEY year_ckey (year,ckey)
) $charset;";
	$sql[] = 'CREATE TABLE ' . ogc_table( 'round_answers' ) . " (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  year smallint(5) unsigned NOT NULL,
  ckey varchar(60) NOT NULL,
  item varchar(160) NOT NULL,
  answer varchar(12) NOT NULL DEFAULT '',
  note text NULL,
  by_user bigint(20) unsigned NOT NULL DEFAULT 0,
  by_name varchar(80) NOT NULL DEFAULT '',
  at datetime NULL,
  sample tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY  (id),
  UNIQUE KEY year_item (year,item)
) $charset;";
	return $sql;
}, 40, 2 );

function ogc_round_ready() {
	global $wpdb;
	if ( isset( $GLOBALS['ogc_round_ready'] ) ) {
		return $GLOBALS['ogc_round_ready'];
	}
	if ( ! function_exists( 'ogc_app_tables_ready' ) || ! ogc_app_tables_ready() ) {
		return false;
	}
	$wpdb->suppress_errors( true );
	$wpdb->get_var( 'SELECT id FROM ' . ogc_table( 'round_lines' ) . ' LIMIT 1' ); // phpcs:ignore -- no input.
	$ok = '' === $wpdb->last_error;
	$wpdb->get_var( 'SELECT id FROM ' . ogc_table( 'round_answers' ) . ' LIMIT 1' ); // phpcs:ignore -- no input.
	$ok = $ok && '' === $wpdb->last_error;
	$wpdb->suppress_errors( false );
	return $GLOBALS['ogc_round_ready'] = $ok;
}

/* ================================================================== the screens */

add_filter( 'ogc_app_screens', function ( $s, $year ) {
	// Requests: every committee's own list. The COA opens any committee's from Intake (coa_opens),
	// without a second entry in its sidebar.
	if ( isset( $s['requests'] ) ) {
		$s['requests']['who']       = array( 'committee' );
		$s['requests']['coa_opens'] = true;
		$s['requests']['handable']  = false;
	}
	// Intake: the round. The COA's, handable (A/V in 2027, if the COA agrees: docs/26 #14).
	$tail = array();
	foreach ( array( 'members', 'years' ) as $k ) {
		if ( isset( $s[ $k ] ) ) {
			$tail[ $k ] = $s[ $k ];
			unset( $s[ $k ] );
		}
	}
	$out = array();
	foreach ( $s as $id => $d ) {
		$out[ $id ] = $d;
		if ( 'requests' === $id ) {
			$out['intake'] = array( 'title' => 'Intake', 'section' => 'own', 'who' => array( 'coa' ), 'handable' => true );
		}
	}
	if ( ! isset( $out['intake'] ) ) {
		$out['intake'] = array( 'title' => 'Intake', 'section' => 'own', 'who' => array( 'coa' ), 'handable' => true );
	}
	return array_merge( $out, $tail );
}, 25, 2 );

add_filter( 'ogc_pages', function ( $p ) {
	if ( empty( $p['app'] ) ) {
		return $p;
	}
	$scripts = (array) $p['app']['scripts'];
	// After coa-requests.js (its helpers, window.OGC_REQ), whatever order other areas add theirs.
	$at = array_search( 'app/screens/coa-requests.js', $scripts, true );
	if ( false === $at ) {
		$scripts[] = 'app/screens/coa-requests.js';
		$at        = count( $scripts ) - 1;
	}
	if ( ! in_array( 'app/screens/coa-intake.js', $scripts, true ) ) {
		array_splice( $scripts, $at + 1, 0, array( 'app/screens/coa-intake.js' ) );
	}
	$p['app']['scripts'] = $scripts;
	$p['app']['styles']  = array_values( array_unique( array_merge( (array) $p['app']['styles'], array( 'app/screens/requests.css' ) ) ) );
	return $p;
}, 25 );

// Every request task follows the round: committees answer on Requests, the coordinator sends to the
// campus from Intake (so "Send requests to campus" goes with Intake when the COA hands it on).
add_filter( 'ogc_app_task_kinds', function ( $k ) {
	if ( isset( $k['requests_sent'] ) ) {
		$k['requests_sent'] = array( 'screen' => 'intake', 'from' => 'Intake' );
	}
	return $k;
} );

/* ================================================================== who's asking */

/** Does this viewer run the round? The COA (unless seeing as a committee), or the committee holding the
 * handed Intake. Webmasters only by See as. */
function ogc_round_coord( $v ) {
	return ! empty( $v['open'] ) && function_exists( 'ogc_app_can_see' ) && ogc_app_can_see( $v, 'intake' );
}

/** The same, for the signed-in person now (the COA's routes, which have no ?as=). */
function ogc_round_coord_now( $year ) {
	if ( ! function_exists( 'ogc_app_viewer' ) || ! ogc_app_tables_ready() ) {
		return false;
	}
	return ogc_round_coord( ogc_app_viewer( (int) $year ) );
}

/** Who holds the round this year: a committee key, or 'coa'. */
function ogc_round_holder( $year ) {
	$to = function_exists( 'ogc_app_handed_to' ) ? ogc_app_handed_to( (int) $year, 'intake' ) : '';
	return '' === $to ? 'coa' : $to;
}

function ogc_round_holder_name( $year ) {
	$h = ogc_round_holder( $year );
	if ( 'coa' === $h ) {
		return 'COA';
	}
	$c = ogc_app_committee( (int) $year, $h );
	return $c ? $c['name'] : 'COA';
}

/** The person acting, as the app names them ("Micah R."): their row on the year's members list, else
 * their account's name. Kept as words on what they did (as needs.csv keeps answered_by). */
function ogc_round_who( $year, $uid = 0 ) {
	$uid = $uid ? (int) $uid : get_current_user_id();
	$u   = $uid ? get_userdata( $uid ) : null;
	if ( $u && function_exists( 'ogc_member_find' ) ) {
		$m = ogc_member_find( (int) $year, strtolower( (string) $u->user_email ) );
		if ( $m && function_exists( 'ogc_app_person_name' ) ) {
			return ogc_app_person_name( $m );
		}
	}
	return function_exists( 'ogc_coa_first_l' ) ? ogc_coa_first_l( $uid ) : '';
}

/* ================================================================== settings */

function ogc_round_defaults() {
	return array(
		// 28 and 21 weeks before the Friday: Nov 13 and Jan 1 for 2027 (docs/26 #15, held loosely).
		// The reminder 14 days before (Dec 18 for 2027), never in the holidays (ogc_round_dates).
		'send_off' => -196,
		'due_off'  => -147,
		'remind'   => 14,
		// No reminder, by hand or by itself, within this many days of a committee's first email.
		'remind_gap' => 3,
		'asks'     => array( 'requests', 'packet', 'contact' ),
		'skip'     => array(),
		'owners'   => array(),
		'sent_at'  => '',
		'sent_by'  => '',
		'auto'     => '',
		// The last Export for campus (the campus's date, and who), until it's marked sent.
		'exported'    => '',
		'exported_by' => '',
	);
}

/** The year's round settings, carried from last year's the first time (owners, dates, reminder, asks;
 * never what was sent). */
function ogc_round_settings( $year ) {
	$year = (int) $year;
	if ( isset( $GLOBALS['ogc_round_s'][ $year ] ) ) {
		return $GLOBALS['ogc_round_s'][ $year ];
	}
	$st  = ogc_state_get( $year, 'round' );
	$val = $st && is_array( $st['value'] ) ? $st['value'] : null;
	if ( null === $val ) {
		$prev = ogc_state_get( $year - 1, 'round' );
		$val  = array();
		if ( $prev && is_array( $prev['value'] ) ) {
			foreach ( array( 'send_off', 'due_off', 'remind', 'remind_gap', 'asks', 'skip', 'owners' ) as $k ) {
				if ( isset( $prev['value'][ $k ] ) ) {
					$val[ $k ] = $prev['value'][ $k ];
				}
			}
			$val['from'] = $year - 1;
		}
	}
	$s = array_merge( ogc_round_defaults(), (array) $val );
	$s['asks']   = array_values( array_intersect( array( 'requests', 'packet', 'contact' ), (array) $s['asks'] ) );
	$s['skip']   = array_values( array_map( 'strval', (array) $s['skip'] ) );
	$s['owners'] = is_array( $s['owners'] ) ? $s['owners'] : array();
	$s['remind'] = max( 0, min( 30, (int) $s['remind'] ) );
	$s['remind_gap'] = max( 0, min( 14, (int) $s['remind_gap'] ) );
	return $GLOBALS['ogc_round_s'][ $year ] = $s;
}

/** Change the year's round settings: $fn( &$s ) on a fresh copy, kept with the version (retried). */
function ogc_round_update( $year, $fn ) {
	$year = (int) $year;
	for ( $try = 0; $try < 5; $try++ ) {
		unset( $GLOBALS['ogc_round_s'][ $year ] );
		$st = ogc_state_get( $year, 'round' );
		$s  = ogc_round_settings( $year );
		unset( $s['from'] );
		$fn( $s );
		$r = ogc_state_put( $year, 'round', $s, $st ? $st['version'] : 0 );
		unset( $GLOBALS['ogc_round_s'][ $year ] );
		if ( ! is_wp_error( $r ) ) {
			return ogc_round_settings( $year );
		}
	}
	return new WP_Error( 'ogc_busy', 'Busy · Retry', array( 'status' => 503 ) );
}

/** The round's dates: send, due, the automatic reminder ('' when the year has no dates). */
function ogc_round_dates( $year, $s = null ) {
	$s   = $s ? $s : ogc_round_settings( $year );
	$fri = function_exists( 'ogc_app_friday' ) ? ogc_app_friday( $year ) : 0;
	if ( ! $fri ) {
		return array( 'send' => '', 'due' => '', 'remind' => '', 'remind_moved' => false );
	}
	$send  = gmdate( 'Y-m-d', $fri + (int) $s['send_off'] * DAY_IN_SECONDS );
	$due   = gmdate( 'Y-m-d', $fri + (int) $s['due_off'] * DAY_IN_SECONDS );
	$rem   = $s['remind'] ? gmdate( 'Y-m-d', strtotime( $due . ' 12:00 UTC' ) - $s['remind'] * DAY_IN_SECONDS ) : '';
	$moved = false;
	// Never by itself from Christmas Eve to New Year's Day: Dec 23 instead (a fixed rule, shown on Intake).
	if ( $rem && ( substr( $rem, 5 ) >= '12-24' || '01-01' === substr( $rem, 5 ) ) ) {
		$rem   = ( (int) substr( $rem, 0, 4 ) - ( '01-01' === substr( $rem, 5 ) ? 1 : 0 ) ) . '-12-23';
		$moved = true;
	}
	return array( 'send' => $send, 'due' => $due, 'remind' => $rem, 'remind_moved' => $moved );
}

/** The first day a committee may be reminded: its first email's day plus the gap ('' if not sent). */
function ogc_round_remind_from( $year, $sent_day ) {
	if ( '' === (string) $sent_day ) {
		return '';
	}
	return gmdate( 'Y-m-d', strtotime( $sent_day . ' 12:00 UTC' ) + ogc_round_settings( $year )['remind_gap'] * DAY_IN_SECONDS );
}

/** A stored UTC time as the campus's date (for comparing with today, or a preview). */
function ogc_round_day( $year, $utc ) {
	if ( ! $utc ) {
		return '';
	}
	try {
		$d = new DateTime( $utc, new DateTimeZone( 'UTC' ) );
		$d->setTimezone( function_exists( 'ogc_coa_tz' ) ? ogc_coa_tz( $year ) : wp_timezone() );
		return $d->format( 'Y-m-d' );
	} catch ( Exception $e ) {
		return '';
	}
}

function ogc_round_today( $year ) {
	return function_exists( 'ogc_app_today' ) ? ogc_app_today( $year ) : wp_date( 'Y-m-d' );
}

/* ================================================================== lines */

/** The year's lines by committee key. */
function ogc_round_lines( $year, $reset = false ) {
	global $wpdb;
	$year = (int) $year;
	if ( ! $reset && isset( $GLOBALS['ogc_round_l'][ $year ] ) ) {
		return $GLOBALS['ogc_round_l'][ $year ];
	}
	$out = array();
	if ( ogc_round_ready() ) {
		foreach ( (array) $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . ogc_table( 'round_lines' ) . ' WHERE year = %d', $year ), ARRAY_A ) as $r ) {
			$out[ $r['ckey'] ] = $r;
		}
	}
	return $GLOBALS['ogc_round_l'][ $year ] = $out;
}

/** Set fields on a committee's line (made when it isn't there). $only_empty: only where still empty. */
function ogc_round_line_set( $year, $ckey, $fields, $only_empty = false ) {
	global $wpdb;
	$t = ogc_table( 'round_lines' );
	if ( ! $wpdb->get_var( $wpdb->prepare( "SELECT id FROM $t WHERE year = %d AND ckey = %s", $year, $ckey ) ) ) {
		$wpdb->suppress_errors( true );
		$wpdb->insert( $t, array( 'year' => (int) $year, 'ckey' => (string) $ckey, 'updated_at' => ogc_now() ) );
		$wpdb->suppress_errors( false );
	}
	foreach ( $fields as $k => $v ) {
		if ( ! in_array( $k, array( 'sent_at', 'sent_n', 'opened_at', 'started_at', 'returned_at', 'returned_by', 'returned_name', 'reminded_at', 'reminds', 'sample' ), true ) ) {
			continue;
		}
		if ( null === $v ) {
			$wpdb->query( $wpdb->prepare( "UPDATE $t SET $k = NULL, updated_at = %s WHERE year = %d AND ckey = %s", ogc_now(), $year, $ckey ) ); // phpcs:ignore -- $k is from the list above.
		} elseif ( $only_empty ) {
			$wpdb->query( $wpdb->prepare( "UPDATE $t SET $k = %s, updated_at = %s WHERE year = %d AND ckey = %s AND $k IS NULL", $v, ogc_now(), $year, $ckey ) ); // phpcs:ignore -- as above.
		} else {
			$wpdb->query( $wpdb->prepare( "UPDATE $t SET $k = %s, updated_at = %s WHERE year = %d AND ckey = %s", $v, ogc_now(), $year, $ckey ) ); // phpcs:ignore -- as above.
		}
	}
	unset( $GLOBALS['ogc_round_l'][ (int) $year ] );
}

/** A line's status as of today (or a previewed day): notsent · sent · opened · started · returned. */
function ogc_round_line_state( $year, $line, $today ) {
	$on = function ( $f ) use ( $year, $line, $today ) {
		$d = $line && ! empty( $line[ $f ] ) ? ogc_round_day( $year, $line[ $f ] ) : '';
		return '' !== $d && $d <= $today ? $d : '';
	};
	$st = array( 'sent' => $on( 'sent_at' ), 'opened' => $on( 'opened_at' ), 'started' => $on( 'started_at' ), 'returned' => $on( 'returned_at' ), 'reminded' => $on( 'reminded_at' ) );
	if ( ! $st['sent'] ) {
		$st['status'] = 'notsent';
	} elseif ( $st['returned'] ) {
		$st['status'] = 'returned';
	} elseif ( $st['started'] ) {
		$st['status'] = 'started';
	} elseif ( $st['opened'] ) {
		$st['status'] = 'opened';
	} else {
		$st['status'] = 'sent';
	}
	return $st;
}

function ogc_round_words( $status ) {
	$w = array( 'notsent' => 'Not sent', 'sent' => 'Not opened', 'opened' => 'Opened', 'started' => 'Started', 'returned' => 'Returned' );
	return isset( $w[ $status ] ) ? $w[ $status ] : '';
}

/** The committees in the round, in the COA's order (never the COA itself). */
function ogc_round_committees( $year, $with_skipped = false ) {
	$s   = ogc_round_settings( $year );
	$out = array();
	foreach ( ogc_app_committees( (int) $year ) as $c ) {
		if ( 'coa' === $c['ckey'] || ( ! $with_skipped && in_array( $c['ckey'], $s['skip'], true ) ) ) {
			continue;
		}
		$out[] = $c;
	}
	return $out;
}

/* ================================================================== what each committee answers */

/** A help card's lasting key: its need, as a slug ("First aid" → first-aid). */
function ogc_round_help_key( $need ) {
	return sanitize_title( (string) $need );
}

/** The packet's parts in order: id → {title, summary, paras, rows (indexes)}. */
function ogc_round_guide_parts( $year ) {
	$f     = ogc_file_get( (int) $year, 'guide' );
	$parts = array();
	foreach ( $f ? array_values( (array) $f['rows'] ) : array() as $i => $r ) {
		$id = isset( $r['id'] ) ? (string) $r['id'] : '';
		if ( '' === $id ) {
			continue;
		}
		if ( ! isset( $parts[ $id ] ) ) {
			$parts[ $id ] = array( 'id' => $id, 'title' => '', 'summary' => '', 'paras' => array(), 'rows' => array() );
		}
		if ( '' === $parts[ $id ]['title'] && ! empty( $r['title'] ) ) {
			$parts[ $id ]['title'] = (string) $r['title'];
		}
		if ( '' === $parts[ $id ]['summary'] && ! empty( $r['summary'] ) ) {
			$parts[ $id ]['summary'] = (string) $r['summary'];
		}
		$parts[ $id ]['paras'][] = isset( $r['text'] ) ? (string) $r['text'] : '';
		$parts[ $id ]['rows'][]  = $i;
	}
	return $parts;
}

/** The Help cards by key. */
function ogc_round_help_cards( $year ) {
	$f   = ogc_file_get( (int) $year, 'help' );
	$out = array();
	foreach ( $f ? (array) $f['rows'] : array() as $r ) {
		$need = isset( $r['need'] ) ? trim( (string) $r['need'] ) : '';
		if ( '' === $need ) {
			continue;
		}
		$k         = ogc_round_help_key( $need );
		$out[ $k ] = array(
			'key'    => $k,
			'need'   => $need,
			'text'   => isset( $r['text'] ) ? (string) $r['text'] : '',
			'phone'  => isset( $r['phone'] ) ? (string) $r['phone'] : '',
			'hours'  => isset( $r['hours'] ) ? (string) $r['hours'] : '',
			'action' => isset( $r['action'] ) ? (string) $r['action'] : '',
			'place'  => isset( $r['place'] ) ? (string) $r['place'] : '',
			'open'   => isset( $r['open'] ) ? (string) $r['open'] : '',
		);
	}
	return $out;
}

/** A committee's role phone (committees.csv). */
function ogc_round_phone( $year, $ckey ) {
	$f = ogc_file_get( (int) $year, 'committees' );
	foreach ( $f ? (array) $f['rows'] : array() as $r ) {
		if ( isset( $r['name'] ) && ogc_committee_key( $r['name'] ) === $ckey ) {
			return isset( $r['contact_phone'] ) ? (string) $r['contact_phone'] : '';
		}
	}
	return '';
}

/** The answers on packet parts, Help cards and contacts: item → row. */
function ogc_round_answers( $year ) {
	global $wpdb;
	$year = (int) $year;
	if ( isset( $GLOBALS['ogc_round_a'][ $year ] ) ) {
		return $GLOBALS['ogc_round_a'][ $year ];
	}
	$out = array();
	if ( ogc_round_ready() ) {
		$today = ogc_round_today( $year );
		foreach ( (array) $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . ogc_table( 'round_answers' ) . ' WHERE year = %d', $year ), ARRAY_A ) as $r ) {
			// A sample answered after the day previewed isn't counted yet.
			if ( ! empty( $r['sample'] ) && ogc_round_day( $year, $r['at'] ) > $today ) {
				continue;
			}
			$out[ $r['item'] ] = $r;
		}
	}
	return $GLOBALS['ogc_round_a'][ $year ] = $out;
}

function ogc_round_answer_out( $a, $year ) {
	if ( ! $a ) {
		return null;
	}
	return array(
		'answer' => (string) $a['answer'],
		'note'   => (string) $a['note'],
		'by'     => (string) $a['by_name'],
		'on'     => ogc_round_day( $year, $a['at'] ),
	);
}

/** Everything a committee is asked this year (without the requests' own rows): its packet parts,
 * Help cards, contact; with counts. */
function ogc_round_items( $year, $ckey ) {
	$s       = ogc_round_settings( $year );
	$ans     = ogc_round_answers( $year );
	$out     = array( 'packet' => array(), 'help' => array(), 'contact' => null );
	if ( in_array( 'packet', $s['asks'], true ) ) {
		foreach ( ogc_round_guide_parts( $year ) as $id => $p ) {
			$item = 'guide:' . $id;
			if ( isset( $s['owners'][ $item ] ) && $s['owners'][ $item ] === $ckey ) {
				unset( $p['rows'] );
				$p['item']       = $item;
				$p['answer']     = ogc_round_answer_out( isset( $ans[ $item ] ) ? $ans[ $item ] : null, $year );
				$out['packet'][] = $p;
			}
		}
		foreach ( ogc_round_help_cards( $year ) as $k => $hc ) {
			$item = 'help:' . $k;
			if ( isset( $s['owners'][ $item ] ) && $s['owners'][ $item ] === $ckey ) {
				$hc['item']    = $item;
				$hc['answer']  = ogc_round_answer_out( isset( $ans[ $item ] ) ? $ans[ $item ] : null, $year );
				$out['help'][] = $hc;
			}
		}
	}
	if ( in_array( 'contact', $s['asks'], true ) ) {
		$heads = array();
		foreach ( ogc_app_people( (int) $year, $ckey ) as $m ) {
			if ( ! empty( $m['head'] ) ) {
				$heads[] = ogc_app_person_name( $m );
			}
		}
		$heads          = array_values( array_unique( $heads ) );
		$item           = 'contact:' . $ckey;
		$out['contact'] = array( 'item' => $item, 'heads' => $heads, 'phone' => ogc_round_phone( $year, $ckey ), 'answer' => ogc_round_answer_out( isset( $ans[ $item ] ) ? $ans[ $item ] : null, $year ) );
	}
	return $out;
}

/** A committee's requests (needs.csv): n, left (to answer, or kept with no days or place), notsure, fix (those kept). */
function ogc_round_req_counts( $year, $ckey ) {
	$s = ogc_round_settings( $year );
	if ( ! in_array( 'requests', $s['asks'], true ) ) {
		return array( 'n' => 0, 'left' => 0, 'notsure' => 0, 'fix' => 0 );
	}
	$f   = ogc_file_get( (int) $year, 'needs' );
	$out = array( 'n' => 0, 'left' => 0, 'notsure' => 0, 'fix' => 0 );
	foreach ( $f ? (array) $f['rows'] : array() as $r ) {
		if ( ogc_committee_key( isset( $r['committee'] ) ? (string) $r['committee'] : '' ) !== $ckey ) {
			continue;
		}
		$a = isset( $r['answer'] ) ? (string) $r['answer'] : '';
		$out['n']++;
		$out['left']    += '' === $a ? 1 : 0;
		$out['notsure'] += 'notsure' === $a ? 1 : 0;
		// Kept with no days or no place (kept before that was asked): still to do before Return.
		$out['fix'] += ogc_round_need_incomplete( $r ) ? 1 : 0;
	}
	$out['left'] += $out['fix'];
	return $out;
}

/** How much a committee has left: requests to answer plus parts, cards and contact not answered. */
function ogc_round_left( $year, $ckey, $items = null ) {
	$items = $items ? $items : ogc_round_items( $year, $ckey );
	$req   = ogc_round_req_counts( $year, $ckey );
	$left  = array( 'requests' => $req['left'], 'packet' => 0, 'help' => 0, 'contact' => 0, 'notsure' => $req['notsure'] );
	foreach ( array( 'packet', 'help' ) as $k ) {
		foreach ( $items[ $k ] as $p ) {
			$left[ $k ] += $p['answer'] ? 0 : 1;
			$left['notsure'] += $p['answer'] && 'notsure' === $p['answer']['answer'] ? 1 : 0;
		}
	}
	if ( $items['contact'] ) {
		$left['contact']  = $items['contact']['answer'] ? 0 : 1;
		$left['notsure'] += $items['contact']['answer'] && 'notsure' === $items['contact']['answer']['answer'] ? 1 : 0;
	}
	$left['total'] = $left['requests'] + $left['packet'] + $left['help'] + $left['contact'];
	$left['n']     = $req['n'] + count( $items['packet'] ) + count( $items['help'] ) + ( $items['contact'] ? 1 : 0 );
	return $left;
}

/* ================================================================== REST */

add_action( 'rest_api_init', function () {
	$Y    = '/app/(?P<year>\d{4})/round';
	$year = function ( WP_REST_Request $req ) {
		return function_exists( 'ogc_app_req_viewer' ) && null !== ogc_year_get( (int) $req['year'] ) && ogc_round_ready();
	};
	// The coordinator: the COA, or the committee holding Intake. Writes refused while seeing as.
	$coord = function ( $write ) use ( $year ) {
		return function ( WP_REST_Request $req ) use ( $write, $year ) {
			if ( ! $year( $req ) ) {
				return new WP_Error( 'ogc_not_found', 'Not found.', array( 'status' => 404 ) );
			}
			$v = ogc_app_req_viewer( $req );
			if ( ! ogc_round_coord( $v ) ) {
				return ogc_rest_denied();
			}
			if ( $write && $v['as'] ) {
				return new WP_Error( 'ogc_read_only', 'Read only while seeing as', array( 'status' => 403 ) );
			}
			return true;
		};
	};
	// A committee's own (its people), or the coordinator for any committee.
	$theirs = function ( $write ) use ( $year ) {
		return function ( WP_REST_Request $req ) use ( $write, $year ) {
			if ( ! $year( $req ) ) {
				return new WP_Error( 'ogc_not_found', 'Not found.', array( 'status' => 404 ) );
			}
			$v = ogc_app_req_viewer( $req );
			$c = ogc_committee_key( (string) $req->get_param( 'c' ) );
			if ( '' === $c || 'coa' === $c || ! ogc_app_committee( (int) $req['year'], $c ) ) {
				return new WP_Error( 'ogc_not_found', 'Not found.', array( 'status' => 404 ) );
			}
			if ( ! ogc_round_coord( $v ) && ! ( ogc_app_can_see( $v, 'requests' ) && in_array( $c, (array) $v['committees'], true ) ) ) {
				// Another committee's round reads as missing, not forbidden.
				return new WP_Error( 'ogc_not_found', 'Not found.', array( 'status' => 404 ) );
			}
			if ( $write && $v['as'] ) {
				return new WP_Error( 'ogc_read_only', 'Read only while seeing as', array( 'status' => 403 ) );
			}
			return true;
		};
	};
	register_rest_route( OGC_NS, $Y, array(
		array( 'methods' => 'GET', 'callback' => 'ogc_round_rest_board', 'permission_callback' => $coord( false ) ),
		array( 'methods' => 'PATCH', 'callback' => 'ogc_round_rest_settings', 'permission_callback' => $coord( true ) ),
	) );
	register_rest_route( OGC_NS, $Y . '/send', array( array( 'methods' => 'POST', 'callback' => 'ogc_round_rest_send', 'permission_callback' => $coord( true ) ) ) );
	register_rest_route( OGC_NS, $Y . '/remind', array( array( 'methods' => 'POST', 'callback' => 'ogc_round_rest_remind', 'permission_callback' => $coord( true ) ) ) );
	register_rest_route( OGC_NS, $Y . '/assign', array( array( 'methods' => 'POST', 'callback' => 'ogc_round_rest_assign', 'permission_callback' => $coord( true ) ) ) );
	register_rest_route( OGC_NS, $Y . '/email', array( array( 'methods' => 'GET', 'callback' => 'ogc_round_rest_email', 'permission_callback' => $coord( false ) ) ) );
	register_rest_route( OGC_NS, $Y . '/mine', array( array( 'methods' => 'GET', 'callback' => 'ogc_round_rest_mine', 'permission_callback' => $theirs( false ) ) ) );
	register_rest_route( OGC_NS, $Y . '/answer', array( array( 'methods' => 'POST', 'callback' => 'ogc_round_rest_answer', 'permission_callback' => $theirs( true ) ) ) );
	register_rest_route( OGC_NS, $Y . '/return', array( array( 'methods' => 'POST', 'callback' => 'ogc_round_rest_return', 'permission_callback' => $theirs( true ) ) ) );
	register_rest_route( OGC_NS, $Y . '/reopen', array( array( 'methods' => 'POST', 'callback' => 'ogc_round_rest_reopen', 'permission_callback' => $theirs( true ) ) ) );
} );

function ogc_round_bad( $msg, $status = 400, $data = array() ) {
	return new WP_Error( 'ogc_round', $msg, array_merge( array( 'status' => $status ), $data ) );
}

/** One committee's line for the board (counts, never anyone's address). */
function ogc_round_board_line( $year, $c, $lines, $today, $dates ) {
	$k     = $c['ckey'];
	$st    = ogc_round_line_state( $year, isset( $lines[ $k ] ) ? $lines[ $k ] : null, $today );
	$items = ogc_round_items( $year, $k );
	$left  = ogc_round_left( $year, $k, $items );
	$heads = array();
	$ppl   = ogc_app_people( (int) $year, $k );
	foreach ( $ppl as $m ) {
		if ( ! empty( $m['head'] ) ) {
			$heads[] = ogc_app_person_name( $m );
		}
	}
	$heads = array_values( array_unique( $heads ) );
	$late = in_array( $st['status'], array( 'sent', 'opened', 'started' ), true ) && $dates['due'] && $today > $dates['due'];
	$l    = isset( $lines[ $k ] ) ? $lines[ $k ] : array();
	return array(
		'key'      => $k,
		'name'     => $c['name'],
		'status'   => $st['status'],
		'words'    => ogc_round_words( $st['status'] ),
		'late'     => $late,
		'sent'     => $st['sent'],
		'sent_n'   => ! empty( $l['sent_n'] ) ? (int) $l['sent_n'] : 0,
		'opened'   => $st['opened'],
		'started'  => $st['started'],
		'returned' => $st['returned'],
		'returned_by' => $st['returned'] && ! empty( $l['returned_name'] ) ? (string) $l['returned_name'] : '',
		'reminded' => $st['reminded'],
		'reminds'  => ! empty( $l['reminds'] ) ? (int) $l['reminds'] : 0,
		// Remind (by hand or by itself) only from here: never days after the first email.
		'remind_from' => ogc_round_remind_from( $year, $st['sent'] ),
		'heads'    => $heads,
		'people'   => count( $ppl ),
		'left'     => $left,
		'packet'   => count( $items['packet'] ),
		'help'     => count( $items['help'] ),
	);
}

/** The board: the round's settings and dates, each committee's line, and what's to settle. */
function ogc_round_rest_board( WP_REST_Request $req ) {
	$y     = (int) $req['year'];
	$v     = ogc_app_req_viewer( $req );
	$s     = ogc_round_settings( $y );
	$dates = ogc_round_dates( $y, $s );
	$today = ogc_round_today( $y );
	$lines = ogc_round_lines( $y );
	$out   = array();
	foreach ( ogc_round_committees( $y, true ) as $c ) {
		$row            = ogc_round_board_line( $y, $c, $lines, $today, $dates );
		$row['skipped'] = in_array( $c['ckey'], $s['skip'], true );
		$out[]          = $row;
	}
	$holder = ogc_round_holder( $y );
	$prev   = ogc_state_get( $y - 1, 'round' );
	$sentd  = ogc_round_day( $y, $s['sent_at'] );
	$coa    = function_exists( 'ogc_coa_state' ) ? ogc_coa_state( $y ) : array();
	return rest_ensure_response( array(
		'today'     => $today,
		'settings'  => array( 'send_off' => (int) $s['send_off'], 'due_off' => (int) $s['due_off'], 'remind' => (int) $s['remind'], 'remind_gap' => (int) $s['remind_gap'], 'asks' => $s['asks'], 'skip' => $s['skip'] ),
		'dates'     => $dates,
		'friday'    => function_exists( 'ogc_app_friday' ) && ogc_app_friday( $y ) ? gmdate( 'Y-m-d', ogc_app_friday( $y ) ) : '',
		'from'      => isset( $s['from'] ) ? (int) $s['from'] : 0,
		'last_year' => $prev ? $y - 1 : 0,
		'sent'      => $sentd && $sentd <= $today ? $sentd : '',
		'sent_by'   => $sentd && $sentd <= $today ? (string) $s['sent_by'] : '',
		'auto'      => (string) $s['auto'],
		'exported'  => (string) $s['exported'],
		'exported_by' => (string) $s['exported_by'],
		'run_by'    => array( 'key' => $holder, 'name' => ogc_round_holder_name( $y ) ),
		'can'       => array( 'hand' => (bool) $v['coa'] && ! $v['as'], 'write' => ! $v['as'] ),
		'campus'    => ! empty( $coa['sent']['needs']['at'] ) ? (string) $coa['sent']['needs']['at'] : '',
		'committees' => $out,
		'settle'    => ogc_round_settle_list( $y ),
		'parts'     => ogc_round_parts_list( $y ),
	) );
}

/** Every packet part and Help card with its owner ('' none yet; 'coa' the COA's own). */
function ogc_round_parts_list( $year ) {
	$s   = ogc_round_settings( $year );
	$out = array();
	foreach ( ogc_round_guide_parts( $year ) as $id => $p ) {
		$out[] = array( 'item' => 'guide:' . $id, 'kind' => 'packet', 'title' => '' !== $p['title'] ? $p['title'] : $id, 'owner' => isset( $s['owners'][ 'guide:' . $id ] ) ? (string) $s['owners'][ 'guide:' . $id ] : '' );
	}
	foreach ( ogc_round_help_cards( $year ) as $k => $hc ) {
		$out[] = array( 'item' => 'help:' . $k, 'kind' => 'help', 'title' => $hc['need'], 'owner' => isset( $s['owners'][ 'help:' . $k ] ) ? (string) $s['owners'][ 'help:' . $k ] : '' );
	}
	return $out;
}

/**
 * What the coordinator settles: rows marked Not sure, removals asked of the packet, requests whose
 * committee isn't on the list, and packet parts and Help cards nobody answers for.
 */
function ogc_round_settle_list( $year ) {
	$s     = ogc_round_settings( $year );
	$names = array();
	foreach ( ogc_app_committees( (int) $year ) as $c ) {
		$names[ $c['ckey'] ] = $c['name'];
	}
	$out = array();
	if ( in_array( 'requests', $s['asks'], true ) ) {
		$f = ogc_file_get( (int) $year, 'needs' );
		foreach ( $f ? (array) $f['rows'] : array() as $r ) {
			$k = ogc_committee_key( isset( $r['committee'] ) ? (string) $r['committee'] : '' );
			$a = isset( $r['answer'] ) ? (string) $r['answer'] : '';
			$t = trim( ( isset( $r['item'] ) ? (string) $r['item'] : '' ) . ( ! empty( $r['qty'] ) ? ' × ' . $r['qty'] : '' ) );
			if ( ! isset( $names[ $k ] ) || 'coa' === $k ) {
				$out[] = array( 'item' => 'need:' . ( isset( $r['id'] ) ? $r['id'] : '' ), 'id' => isset( $r['id'] ) ? (string) $r['id'] : '', 'kind' => 'request', 'why' => 'nocommittee', 'ckey' => '', 'committee' => isset( $r['committee'] ) ? (string) $r['committee'] : '', 'title' => $t, 'note' => '' );
			} elseif ( 'notsure' === $a ) {
				$out[] = array( 'item' => 'need:' . $r['id'], 'id' => (string) $r['id'], 'kind' => 'request', 'why' => 'notsure', 'ckey' => $k, 'committee' => $names[ $k ], 'title' => $t, 'note' => isset( $r['question'] ) ? (string) $r['question'] : '', 'by' => isset( $r['answered_by'] ) ? (string) $r['answered_by'] : '' );
			}
		}
	}
	$ans   = ogc_round_answers( $year );
	$parts = ogc_round_guide_parts( $year );
	$cards = ogc_round_help_cards( $year );
	$title = function ( $item ) use ( $parts, $cards ) {
		list( $kind, $id ) = array_pad( explode( ':', $item, 2 ), 2, '' );
		if ( 'guide' === $kind ) {
			return isset( $parts[ $id ] ) ? ( '' !== $parts[ $id ]['title'] ? $parts[ $id ]['title'] : $id ) : '';
		}
		if ( 'help' === $kind ) {
			return isset( $cards[ $id ] ) ? $cards[ $id ]['need'] : '';
		}
		return 'Contact';
	};
	foreach ( $ans as $item => $a ) {
		if ( ! in_array( $a['answer'], array( 'notsure', 'remove' ), true ) ) {
			continue;
		}
		$t = $title( $item );
		if ( '' === $t ) {
			continue;
		}
		$kind  = strtok( $item, ':' );
		$out[] = array( 'item' => $item, 'kind' => 'guide' === $kind ? 'packet' : $kind, 'why' => $a['answer'], 'ckey' => $a['ckey'], 'committee' => isset( $names[ $a['ckey'] ] ) ? $names[ $a['ckey'] ] : $a['ckey'], 'title' => $t, 'note' => (string) $a['note'], 'by' => (string) $a['by_name'] );
	}
	if ( in_array( 'packet', $s['asks'], true ) ) {
		foreach ( ogc_round_parts_list( $year ) as $p ) {
			$o = $p['owner'];
			if ( '' === $o || ( 'coa' !== $o && ! isset( $names[ $o ] ) ) ) {
				$out[] = array( 'item' => $p['item'], 'kind' => $p['kind'], 'why' => 'noowner', 'ckey' => '', 'committee' => '', 'title' => $p['title'], 'note' => '' );
			}
		}
	}
	return $out;
}

/** PATCH round: {send, due} (dates, kept as days from the Friday), remind, asks, skip. */
function ogc_round_rest_settings( WP_REST_Request $req ) {
	$y   = (int) $req['year'];
	$fri = function_exists( 'ogc_app_friday' ) ? ogc_app_friday( $y ) : 0;
	$p   = $req->get_json_params();
	$p   = is_array( $p ) ? $p : array();
	$off = function ( $iso ) use ( $fri ) {
		if ( ! $fri || ! is_string( $iso ) || ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $iso ) ) {
			return null;
		}
		return (int) round( ( strtotime( $iso . ' 12:00:00 UTC' ) - $fri ) / DAY_IN_SECONDS );
	};
	$set = array();
	foreach ( array( 'send', 'due' ) as $k ) {
		if ( isset( $p[ $k ] ) ) {
			$o = $off( $p[ $k ] );
			if ( null === $o || $o > 0 || $o < -400 ) {
				return ogc_round_bad( 'Not a date before the Conference' );
			}
			$set[ $k . '_off' ] = $o;
		}
	}
	if ( isset( $p['remind'] ) ) {
		$set['remind'] = max( 0, min( 30, (int) $p['remind'] ) );
	}
	if ( isset( $p['asks'] ) && is_array( $p['asks'] ) ) {
		$set['asks'] = array_values( array_intersect( array( 'requests', 'packet', 'contact' ), array_map( 'strval', $p['asks'] ) ) );
		if ( ! $set['asks'] ) {
			return ogc_round_bad( 'One or more' );
		}
	}
	if ( isset( $p['skip'] ) && is_array( $p['skip'] ) ) {
		$set['skip'] = array();
		foreach ( $p['skip'] as $k ) {
			$k = ogc_committee_key( (string) $k );
			if ( ogc_app_committee( $y, $k ) && 'coa' !== $k ) {
				$set['skip'][] = $k;
			}
		}
	}
	$cur = ogc_round_settings( $y );
	$send = isset( $set['send_off'] ) ? $set['send_off'] : (int) $cur['send_off'];
	$due  = isset( $set['due_off'] ) ? $set['due_off'] : (int) $cur['due_off'];
	if ( $due <= $send ) {
		return ogc_round_bad( 'Due after the send date', 400, array( 'field' => isset( $set['due_off'] ) ? 'due' : 'send' ) );
	}
	// A due date or reminder moved to later: the automatic reminder goes again on its new day.
	if ( isset( $set['due_off'] ) || isset( $set['remind'] ) ) {
		$rem = ogc_round_dates( $y, array_merge( $cur, $set ) )['remind'];
		if ( $rem && $rem > ogc_round_today( $y ) ) {
			$set['auto'] = '';
		}
	}
	// Export for campus downloaded (kept until it's marked sent, so Mark as sent stays on the page).
	if ( array_key_exists( 'exported', $p ) ) {
		$set['exported']    = rest_sanitize_boolean( $p['exported'] ) ? ogc_round_today( $y ) : '';
		$set['exported_by'] = $set['exported'] ? ogc_round_who( $y ) : '';
	}
	$s = ogc_round_update( $y, function ( &$s ) use ( $set ) {
		foreach ( $set as $k => $v ) {
			$s[ $k ] = $v;
		}
	} );
	if ( is_wp_error( $s ) ) {
		return $s;
	}
	ogc_log( 'round_set', $y, 'round', array( 'keys' => array_keys( $set ) ) );
	return ogc_round_rest_board( $req );
}

/* ------------------------------------------------------------------ sending */

/** Who a committee's round goes to: its heads, else everyone on it. [ member rows ] */
function ogc_round_to( $year, $ckey ) {
	$ppl   = ogc_app_people( (int) $year, $ckey );
	$heads = array_values( array_filter( $ppl, function ( $m ) {
		return ! empty( $m['head'] );
	} ) );
	return $heads ? $heads : $ppl;
}

/** The email's data for one committee. */
function ogc_round_mail_data( $year, $c, $again = false ) {
	$s     = ogc_round_settings( $year );
	$dates = ogc_round_dates( $year, $s );
	$items = ogc_round_items( $year, $c['ckey'] );
	$left  = ogc_round_left( $year, $c['ckey'], $items );
	$req   = ogc_round_req_counts( $year, $c['ckey'] );
	$row   = ogc_year_get( (int) $year );
	$asks  = array();
	if ( $req['n'] ) {
		$asks[] = array( 'Requests', ogc_app_plural( $req['n'], 'request' ) . ' to the campus' );
	}
	$pk = count( $items['packet'] ) + count( $items['help'] );
	if ( $pk ) {
		$asks[] = array( 'Packet', implode( ', ', array_merge( array_map( function ( $p ) {
			return '' !== $p['title'] ? $p['title'] : $p['id'];
		}, $items['packet'] ), array_map( function ( $hc ) {
			return 'Help · ' . $hc['need'];
		}, $items['help'] ) ) ) );
	}
	if ( $items['contact'] ) {
		$asks[] = array( 'Contact', 'Head and phone' );
	}
	$me = wp_get_current_user();
	return array(
		'year'      => (int) $year,
		'committee' => $c['name'],
		'due'       => $dates['due'],
		'left'      => $left['total'],
		'asks'      => $asks,
		'from'      => ogc_round_holder_name( $year ),
		'venue'     => $row && ! empty( $row['venue'] ) ? (string) $row['venue'] : '',
		'url'       => ogc_url( 'app', array( 'year' => (int) $year, 's' => 'requests', 'c' => $c['ckey'] ) ),
		'again'     => $again,
		'reply_to'  => $me && $me->exists() ? (string) $me->user_email : '',
	);
}

/** Send (or remind) one committee's people. Returns how many emails went. */
function ogc_round_mail( $year, $c, $again ) {
	$to = ogc_round_to( $year, $c['ckey'] );
	if ( ! $to ) {
		return 0;
	}
	$data = ogc_round_mail_data( $year, $c, $again );
	$n    = 0;
	foreach ( $to as $m ) {
		if ( empty( $m['email'] ) ) {
			continue;
		}
		ogc_mail_send_kind( $again ? 'round_remind' : 'round_ask', $m['email'], $data, array( 'to_member' => true ) );
		$n++;
	}
	return $n;
}

/** POST round/send {c?}: every committee in the round not sent yet (or the one named). */
function ogc_round_rest_send( WP_REST_Request $req ) {
	$y     = (int) $req['year'];
	$only  = ogc_committee_key( (string) $req->get_param( 'c' ) );
	$lines = ogc_round_lines( $y );
	if ( ! ogc_round_dates( $y )['due'] ) {
		return ogc_round_bad( 'Dates first · The Conference has no dates yet', 409 );
	}
	if ( ogc_throttle( 'round_send:' . $y, 30, HOUR_IN_SECONDS ) ) {
		return ogc_round_bad( 'Sent just now · Try in an hour', 429 );
	}
	$sent   = array();
	$nobody = array();
	$mails  = 0;
	foreach ( ogc_round_committees( $y ) as $c ) {
		$k = $c['ckey'];
		if ( '' !== $only && $only !== $k ) {
			continue;
		}
		if ( '' === $only && ! empty( $lines[ $k ]['sent_at'] ) ) {
			continue;
		}
		$n = ogc_round_mail( $y, $c, false );
		if ( ! $n ) {
			$nobody[] = $c['name'];
			continue;
		}
		$mails += $n;
		ogc_round_line_set( $y, $k, array( 'sent_at' => ogc_now(), 'sent_n' => $n ) );
		$sent[] = $c['name'];
	}
	if ( $sent ) {
		$me = ogc_round_who( $y );
		ogc_round_update( $y, function ( &$s ) use ( $me ) {
			if ( empty( $s['sent_at'] ) ) {
				$s['sent_at'] = ogc_now();
				$s['sent_by'] = $me;
			}
		} );
	}
	ogc_log( 'round_send', $y, 'round', array( 'committees' => count( $sent ), 'emails' => $mails, 'nobody' => count( $nobody ) ) );
	return rest_ensure_response( array( 'sent' => $sent, 'emails' => $mails, 'nobody' => $nobody ) );
}

/** Remind the committees sent and not returned (or the one named), once a day each. */
function ogc_round_remind( $year, $only = '', $auto = false ) {
	$today  = ogc_round_today( $year );
	$lines  = ogc_round_lines( $year );
	$out    = array( 'sent' => array(), 'already' => array(), 'early' => array(), 'nobody' => array(), 'emails' => 0 );
	foreach ( ogc_round_committees( $year ) as $c ) {
		$k = $c['ckey'];
		if ( '' !== $only && $only !== $k ) {
			continue;
		}
		$st = ogc_round_line_state( $year, isset( $lines[ $k ] ) ? $lines[ $k ] : null, $today );
		if ( ! in_array( $st['status'], array( 'sent', 'opened', 'started' ), true ) ) {
			continue;
		}
		if ( $st['reminded'] === $today ) {
			$out['already'][] = $c['name'];
			continue;
		}
		// Never days after the first email (the gap): two emails in a row read as nagging.
		if ( $today < ogc_round_remind_from( $year, $st['sent'] ) ) {
			$out['early'][] = $c['name'];
			continue;
		}
		$n = ogc_round_mail( $year, $c, true );
		if ( ! $n ) {
			$out['nobody'][] = $c['name'];
			continue;
		}
		$out['emails'] += $n;
		$out['sent'][]  = $c['name'];
		ogc_round_line_set( $year, $k, array( 'reminded_at' => ogc_now(), 'reminds' => ( isset( $lines[ $k ]['reminds'] ) ? (int) $lines[ $k ]['reminds'] : 0 ) + 1 ) );
	}
	ogc_log( $auto ? 'round_remind_auto' : 'round_remind', $year, 'round', array( 'committees' => count( $out['sent'] ), 'emails' => $out['emails'] ) );
	return $out;
}

function ogc_round_rest_remind( WP_REST_Request $req ) {
	$y = (int) $req['year'];
	if ( ogc_throttle( 'round_remind:' . $y, 20, DAY_IN_SECONDS ) ) {
		return ogc_round_bad( 'Sent today already · Try tomorrow', 429 );
	}
	return rest_ensure_response( ogc_round_remind( $y, ogc_committee_key( (string) $req->get_param( 'c' ) ) ) );
}

// The one automatic reminder: N days before the due date (Intake's setting; 0 = off), to every
// committee sent and not returned. Checked with the volunteer area's timed job (every five minutes),
// from 8 AM at the campus, once a round.
add_action( 'ogc_vol_tick', 'ogc_round_tick', 30 );

function ogc_round_tick() {
	if ( ! ogc_round_ready() || ! function_exists( 'ogc_years_list' ) ) {
		return;
	}
	// Simple mode (module-app-simple.php): the requests round is hidden, so it reminds no one.
	if ( function_exists( 'ogc_app_simple' ) && ogc_app_simple() ) {
		return;
	}
	foreach ( ogc_years_list() as $y ) {
		$s = ogc_round_settings( $y );
		if ( empty( $s['sent_at'] ) || ! $s['remind'] || ! empty( $s['auto'] ) ) {
			continue;
		}
		$d = ogc_round_dates( $y, $s );
		if ( ! $d['remind'] ) {
			continue;
		}
		// The round went out on (or just before) the reminder's day: the first email is the reminder.
		if ( ogc_round_remind_from( $y, ogc_round_day( $y, $s['sent_at'] ) ) > $d['remind'] ) {
			ogc_round_update( $y, function ( &$s ) {
				$s['auto'] = 'skip';
			} );
			continue;
		}
		$now = new DateTime( 'now', function_exists( 'ogc_coa_tz' ) ? ogc_coa_tz( $y ) : wp_timezone() );
		$day = $now->format( 'Y-m-d' );
		if ( $day < $d['remind'] || $day > $d['due'] || (int) $now->format( 'G' ) < 8 ) {
			continue;
		}
		ogc_round_update( $y, function ( &$s ) use ( $day ) {
			$s['auto'] = $day;
		} );
		ogc_round_remind( $y, '', true );
	}
}

/** GET round/email?c=: the email a committee gets, as sent (for Send's panel). */
function ogc_round_rest_email( WP_REST_Request $req ) {
	$y = (int) $req['year'];
	$k = ogc_committee_key( (string) $req->get_param( 'c' ) );
	$c = $k ? ogc_app_committee( $y, $k ) : null;
	if ( ! $c ) {
		foreach ( ogc_round_committees( $y ) as $x ) {
			$c = $x;
			break;
		}
	}
	if ( ! $c ) {
		return ogc_round_bad( 'No committees', 404 );
	}
	$d       = ogc_round_mail_data( $y, $c, 'remind' === (string) $req->get_param( 'kind' ) );
	$d['to'] = 'the head';
	$m       = ogc_mail_template( $d['again'] ? 'round_remind' : 'round_ask', $d );
	return rest_ensure_response( array( 'committee' => $c['name'], 'subject' => $m ? $m['subject'] : '', 'text' => $m ? $m['text'] : '' ) );
}

/* ------------------------------------------------------------------ a committee's own */

function ogc_round_rest_mine( WP_REST_Request $req ) {
	$y     = (int) $req['year'];
	$k     = ogc_committee_key( (string) $req->get_param( 'c' ) );
	$c     = ogc_app_committee( $y, $k );
	$v     = ogc_app_req_viewer( $req );
	$s     = ogc_round_settings( $y );
	$dates = ogc_round_dates( $y, $s );
	$today = ogc_round_today( $y );
	$lines = ogc_round_lines( $y );
	$st    = ogc_round_line_state( $y, isset( $lines[ $k ] ) ? $lines[ $k ] : null, $today );
	// Opened: the first time someone on the committee (never the coordinator, never seeing as) opens it
	// after it was sent; a preview never counts.
	if ( $st['sent'] && ! $st['opened'] && ! $v['as'] && in_array( $k, (array) $v['committees'], true ) && empty( $GLOBALS['ogc_app_as_of'] ) ) {
		ogc_round_line_set( $y, $k, array( 'opened_at' => ogc_now() ), true );
		$lines = ogc_round_lines( $y, true );
		$st    = ogc_round_line_state( $y, $lines[ $k ], $today );
	}
	$items = ogc_round_items( $y, $k );
	$left  = ogc_round_left( $y, $k, $items );
	// Last year's notes for this committee, not yet marked done.
	$notes = array();
	if ( function_exists( 'ogc_app_notes' ) ) {
		foreach ( ogc_app_notes( $y - 1, $k ) as $n ) {
			if ( ! $n['done'] ) {
				$notes[] = array( 'body' => $n['body'], 'on' => $n['on'] );
			}
		}
	}
	// Volunteer shifts are asked on the volunteer page (not in this round tonight): how many, and where.
	$shifts = 0;
	$sf     = ogc_file_get( $y, 'shifts' );
	foreach ( $sf ? (array) $sf['rows'] : array() as $r ) {
		$shifts += isset( $r['committee'] ) && ogc_committee_key( (string) $r['committee'] ) === $k ? 1 : 0;
	}
	$coord = ogc_round_coord( $v );
	$in    = ! in_array( $k, $s['skip'], true );
	return rest_ensure_response( array(
		'committee' => array( 'key' => $k, 'name' => $c['name'] ),
		'in'        => $in,
		'status'    => $st['status'],
		'words'     => ogc_round_words( $st['status'] ),
		'sent'      => $st['sent'],
		'returned'  => $st['returned'],
		'returned_by' => $st['returned'] && ! empty( $lines[ $k ]['returned_name'] ) ? (string) $lines[ $k ]['returned_name'] : '',
		'late'      => in_array( $st['status'], array( 'sent', 'opened', 'started' ), true ) && $dates['due'] && $today > $dates['due'],
		'due'       => $dates['due'],
		'today'     => $today,
		'from'      => ogc_round_holder_name( $y ),
		'asks'      => $s['asks'],
		'left'      => $left,
		'packet'    => $items['packet'],
		'help'      => $items['help'],
		'contact'   => $items['contact'],
		'notes'     => $notes,
		'shifts'    => array( 'n' => $shifts, 'screen' => function_exists( 'ogc_app_can_see' ) && ogc_app_can_see( $v, 'shifts' ) ? 'shifts' : '' ),
		'coord'     => $coord,
		// What this person may do here.
		'can'       => array(
			// Simple mode (module-app-simple.php): a committee's packet and Help text stays theirs to edit;
			// there's no round to return.
			'answer' => ! $v['as'] && ( ! $st['returned'] || ( function_exists( 'ogc_app_simple' ) && ogc_app_simple() ) ),
			'return' => ! $v['as'] && ! $st['returned'] && $st['sent'] && 0 === $left['total'],
			'reopen' => ! $v['as'] && (bool) $st['returned'],
		),
	) );
}

/** Ensure every row of an editor file has its lasting _id (so one row can be changed by id). */
function ogc_round_ids( $year, $name ) {
	$f = ogc_file_get( (int) $year, $name );
	foreach ( $f ? (array) $f['rows'] : array() as $r ) {
		if ( empty( $r['_id'] ) ) {
			if ( function_exists( 'ogc_ed_apply' ) ) {
				ogc_ed_apply( (int) $year, $name, array( array( 'op' => 'ids' ) ) );
			}
			return ogc_file_get( (int) $year, $name );
		}
	}
	return $f;
}

/** Write a committee's changed packet part, Help card or phone into its file (history kept). */
function ogc_round_write_change( $year, $item, $ckey, $fields ) {
	if ( ! function_exists( 'ogc_ed_apply' ) ) {
		return ogc_round_bad( 'Not available', 501 );
	}
	list( $kind, $id ) = array_pad( explode( ':', $item, 2 ), 2, '' );
	$clean = function ( $v, $max ) {
		$v = sanitize_textarea_field( (string) $v );
		return function_exists( 'mb_substr' ) ? mb_substr( trim( $v ), 0, $max ) : substr( trim( $v ), 0, $max );
	};
	if ( 'guide' === $kind ) {
		$f    = ogc_round_ids( $year, 'guide' );
		$rows = $f ? array_values( (array) $f['rows'] ) : array();
		$mine = array();
		foreach ( $rows as $i => $r ) {
			if ( isset( $r['id'] ) && (string) $r['id'] === $id ) {
				$mine[] = $i;
			}
		}
		if ( ! $mine ) {
			return ogc_round_bad( 'Not found', 404 );
		}
		$paras = array();
		foreach ( (array) ( isset( $fields['paras'] ) ? $fields['paras'] : array() ) as $p ) {
			$p = $clean( $p, 1500 );
			if ( '' !== $p ) {
				$paras[] = $p;
			}
		}
		if ( ! $paras ) {
			return ogc_round_bad( 'Text · One paragraph or more', 400, array( 'field' => 'paras' ) );
		}
		$ops   = array();
		$first = $rows[ $mine[0] ];
		$set   = array( 'text' => $paras[0] );
		if ( isset( $fields['title'] ) ) {
			$t = sanitize_text_field( (string) $fields['title'] );
			if ( '' === $t ) {
				return ogc_round_bad( 'Title', 400, array( 'field' => 'title' ) );
			}
			$set['title'] = mb_substr( $t, 0, 200 );
		}
		if ( isset( $fields['summary'] ) ) {
			$set['summary'] = mb_substr( sanitize_text_field( (string) $fields['summary'] ), 0, 300 );
		}
		$ops[] = array( 'op' => 'set', 'id' => $first['_id'], 'fields' => $set );
		$last  = end( $mine );
		$after = isset( $rows[ $last + 1 ] ) ? (string) $rows[ $last + 1 ]['_id'] : '';
		foreach ( $paras as $n => $p ) {
			if ( 0 === $n ) {
				continue;
			}
			if ( isset( $mine[ $n ] ) ) {
				$ops[] = array( 'op' => 'set', 'id' => $rows[ $mine[ $n ] ]['_id'], 'fields' => array( 'text' => $p ) );
			} else {
				$ops[] = array( 'op' => 'add', 'row' => array( 'id' => $id, 'title' => '', 'summary' => '', 'text' => $p ), 'before' => $after );
			}
		}
		for ( $n = count( $paras ); $n < count( $mine ); $n++ ) {
			$ops[] = array( 'op' => 'remove', 'id' => $rows[ $mine[ $n ] ]['_id'] );
		}
		$r = ogc_ed_apply( (int) $year, 'guide', $ops );
		return is_wp_error( $r ) ? $r : true;
	}
	if ( 'help' === $kind ) {
		$f = ogc_round_ids( $year, 'help' );
		foreach ( $f ? (array) $f['rows'] : array() as $r ) {
			if ( isset( $r['need'] ) && ogc_round_help_key( $r['need'] ) === $id ) {
				$set = array();
				if ( isset( $fields['text'] ) ) {
					$set['text'] = $clean( $fields['text'], 1500 );
				}
				if ( isset( $fields['phone'] ) ) {
					$set['phone'] = mb_substr( sanitize_text_field( (string) $fields['phone'] ), 0, 32 );
				}
				if ( isset( $fields['hours'] ) ) {
					$set['hours'] = mb_substr( sanitize_text_field( (string) $fields['hours'] ), 0, 300 );
				}
				if ( ! $set ) {
					return true;
				}
				$res = ogc_ed_apply( (int) $year, 'help', array( array( 'op' => 'set', 'id' => $r['_id'], 'fields' => $set ) ) );
				return is_wp_error( $res ) ? $res : true;
			}
		}
		return ogc_round_bad( 'Not found', 404 );
	}
	if ( 'contact' === $kind ) {
		if ( ! isset( $fields['phone'] ) ) {
			return true;
		}
		$phone = mb_substr( sanitize_text_field( (string) $fields['phone'] ), 0, 32 );
		if ( '' !== $phone && ! preg_match( '/^[0-9+().\-\s]{7,}$/', $phone ) ) {
			return ogc_round_bad( 'Not a phone number', 400, array( 'field' => 'phone' ) );
		}
		$f = ogc_round_ids( $year, 'committees' );
		foreach ( $f ? (array) $f['rows'] : array() as $r ) {
			if ( isset( $r['name'] ) && ogc_committee_key( $r['name'] ) === $ckey ) {
				$res = ogc_ed_apply( (int) $year, 'committees', array( array( 'op' => 'set', 'id' => $r['_id'], 'fields' => array( 'contact_phone' => $phone ) ) ) );
				return is_wp_error( $res ) ? $res : true;
			}
		}
		$c   = ogc_app_committee( (int) $year, $ckey );
		$res = ogc_ed_apply( (int) $year, 'committees', array( array( 'op' => 'add', 'row' => array( 'name' => $c ? $c['name'] : $ckey, 'contact_email' => '', 'contact_phone' => $phone, 'heads' => '', 'weekly' => 'yes', 'order' => '' ) ) ) );
		return is_wp_error( $res ) ? $res : true;
	}
	return ogc_round_bad( 'Not found', 404 );
}

/** POST round/answer {c, item, answer: keep|change|remove|notsure|'', note?, fields?} */
function ogc_round_rest_answer( WP_REST_Request $req ) {
	global $wpdb;
	$y      = (int) $req['year'];
	$k      = ogc_committee_key( (string) $req->get_param( 'c' ) );
	$v      = ogc_app_req_viewer( $req );
	$item   = (string) $req->get_param( 'item' );
	$answer = (string) $req->get_param( 'answer' );
	$note   = mb_substr( sanitize_textarea_field( (string) $req->get_param( 'note' ) ), 0, 500 );
	$fields = $req->get_param( 'fields' );
	if ( ! in_array( $answer, array( 'keep', 'change', 'remove', 'notsure', '' ), true ) ) {
		return ogc_round_bad( 'Keep · Change · Remove · Not sure' );
	}
	// The item must be this committee's (its packet parts, Help cards, contact).
	$items = ogc_round_items( $y, $k );
	$ok    = 'contact:' . $k === $item && $items['contact'];
	foreach ( array_merge( $items['packet'], $items['help'] ) as $p ) {
		$ok = $ok || $p['item'] === $item;
	}
	if ( ! $ok ) {
		return new WP_Error( 'ogc_not_found', 'Not found.', array( 'status' => 404 ) );
	}
	$coord = ogc_round_coord( $v );
	$st    = ogc_round_line_state( $y, ogc_round_lines( $y )[ $k ] ?? null, ogc_round_today( $y ) );
	if ( $st['returned'] && ! $coord && ! ( function_exists( 'ogc_app_simple' ) && ogc_app_simple() ) ) {
		return ogc_round_bad( 'Returned · Reopen to change', 423 );
	}
	if ( 'notsure' === $answer && '' === trim( $note ) ) {
		return ogc_round_bad( 'What’s unclear?', 400, array( 'field' => 'note' ) );
	}
	if ( 'change' === $answer && is_array( $fields ) ) {
		$w = ogc_round_write_change( $y, $item, $k, $fields );
		if ( is_wp_error( $w ) ) {
			return $w;
		}
	}
	$t = ogc_table( 'round_answers' );
	if ( '' === $answer ) {
		$wpdb->delete( $t, array( 'year' => $y, 'item' => $item ) );
	} else {
		$row = array( 'ckey' => $k, 'answer' => $answer, 'note' => $note, 'by_user' => get_current_user_id(), 'by_name' => ogc_round_who( $y ), 'at' => ogc_now(), 'sample' => 0 );
		if ( $wpdb->get_var( $wpdb->prepare( "SELECT id FROM $t WHERE year = %d AND item = %s", $y, $item ) ) ) {
			$wpdb->update( $t, $row, array( 'year' => $y, 'item' => $item ) );
		} else {
			$wpdb->insert( $t, array_merge( $row, array( 'year' => $y, 'item' => $item ) ) );
		}
		if ( $st['sent'] ) {
			ogc_round_line_set( $y, $k, array( 'started_at' => ogc_now() ), true );
		}
	}
	unset( $GLOBALS['ogc_round_a'][ $y ] );
	ogc_log( 'round_answer', $y, 'committee:' . $k, array( 'ckey' => $k, 'item' => substr( $item, 0, 80 ), 'answer' => $answer ) );
	return ogc_round_rest_mine( $req );
}

function ogc_round_rest_return( WP_REST_Request $req ) {
	$y    = (int) $req['year'];
	$k    = ogc_committee_key( (string) $req->get_param( 'c' ) );
	$left = ogc_round_left( $y, $k );
	if ( $left['total'] ) {
		return ogc_round_bad( ogc_app_plural( $left['total'], 'row' ) . ' to answer', 409, array( 'left' => $left['total'] ) );
	}
	$st = ogc_round_line_state( $y, ogc_round_lines( $y )[ $k ] ?? null, ogc_round_today( $y ) );
	if ( ! $st['sent'] ) {
		return ogc_round_bad( 'Not sent yet', 409 );
	}
	ogc_round_line_set( $y, $k, array( 'returned_at' => ogc_now(), 'returned_by' => get_current_user_id(), 'returned_name' => ogc_round_who( $y ) ) );
	// Started too, where it wasn't (a committee that kept everything at once).
	ogc_round_line_set( $y, $k, array( 'started_at' => ogc_now() ), true );
	ogc_log( 'round_return', $y, 'committee:' . $k, array( 'ckey' => $k ) );
	return ogc_round_rest_mine( $req );
}

function ogc_round_rest_reopen( WP_REST_Request $req ) {
	$y = (int) $req['year'];
	$k = ogc_committee_key( (string) $req->get_param( 'c' ) );
	ogc_round_line_set( $y, $k, array( 'returned_at' => null, 'returned_by' => 0, 'returned_name' => '' ) );
	ogc_log( 'round_reopen', $y, 'committee:' . $k, array( 'ckey' => $k ) );
	return ogc_round_rest_mine( $req );
}

/** POST round/assign {item, c}: who answers for a packet part or Help card ('coa': the COA's own; ''
 * nobody yet), or the committee of a request whose committee isn't on the list. */
function ogc_round_rest_assign( WP_REST_Request $req ) {
	$y    = (int) $req['year'];
	$item = (string) $req->get_param( 'item' );
	$to   = ogc_committee_key( (string) $req->get_param( 'c' ) );
	if ( '' !== $to && 'coa' !== $to && ! ogc_app_committee( $y, $to ) ) {
		return new WP_Error( 'ogc_not_found', 'Not found.', array( 'status' => 404 ) );
	}
	list( $kind, $id ) = array_pad( explode( ':', $item, 2 ), 2, '' );
	if ( 'need' === $kind ) {
		$c = ogc_app_committee( $y, $to );
		if ( ! $c || 'coa' === $to ) {
			return ogc_round_bad( 'A committee' );
		}
		for ( $try = 0; $try < 6; $try++ ) {
			$cur  = ogc_file_get( $y, 'needs' );
			$rows = $cur ? array_values( (array) $cur['rows'] ) : array();
			$hit  = false;
			foreach ( $rows as &$r ) {
				if ( isset( $r['id'] ) && (string) $r['id'] === $id ) {
					$r['committee'] = $c['name'];
					$hit            = true;
				}
			}
			unset( $r );
			if ( ! $hit ) {
				return new WP_Error( 'ogc_not_found', 'Not found.', array( 'status' => 404 ) );
			}
			$ver = ogc_file_put( $y, 'needs', $rows, $cur ? $cur['version'] : 0 );
			if ( ! is_wp_error( $ver ) ) {
				ogc_log( 'round_assign', $y, 'committee:' . $to, array( 'ckey' => $to, 'item' => 'request' ) );
				return ogc_round_rest_board( $req );
			}
		}
		return ogc_round_bad( 'Busy · Retry', 503 );
	}
	$known = false;
	foreach ( ogc_round_parts_list( $y ) as $p ) {
		$known = $known || $p['item'] === $item;
	}
	if ( ! $known ) {
		return new WP_Error( 'ogc_not_found', 'Not found.', array( 'status' => 404 ) );
	}
	$s = ogc_round_update( $y, function ( &$s ) use ( $item, $to ) {
		if ( '' === $to ) {
			unset( $s['owners'][ $item ] );
		} else {
			$s['owners'][ $item ] = $to;
		}
	} );
	if ( is_wp_error( $s ) ) {
		return $s;
	}
	ogc_log( 'round_assign', $y, 'committee:' . ( '' === $to ? 'none' : $to ), array( 'ckey' => $to, 'item' => substr( $item, 0, 80 ) ) );
	return ogc_round_rest_board( $req );
}

/* ================================================================== a request's fields: exact, never reread */

/*
 * coa/{y}/needs calls ogc_round_need_check() on every row it changes or adds (module-coa.php). What
 * people type is refused, never reinterpreted (docs/25): a quantity is a whole number of 1 or more;
 * days are one day name, or two joined by "–", "-", "to" or "through"; times read as times, both or
 * neither (All day); a request kept, changed or new has its days and its place.
 *
 * Undo goes back to what was carried: the first time a carried row's fields change, the values it had
 * are kept on the row (`was`, JSON with the year: {"in":2027,"qty":"2"}). Answering it again ('')
 * puts them back. A row whose fields differ from what was carried is Changed; one that matches again
 * is Kept. A row added this year (`added_in`) goes back to New, never to To answer.
 */
const OGC_ROUND_NEED_DAYS = array( 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday', 'Monday', 'Tuesday' );
const OGC_ROUND_NEED_TRACK = array( 'item', 'qty', 'detail', 'for', 'supplied_by', 'first_day', 'last_day', 'start', 'end', 'building', 'room', 'notes' );

/** A day name exactly (any case), or its usual short form: the day; '' for empty; null when it isn't one. */
function ogc_round_need_day( $v ) {
	$t = rtrim( strtolower( trim( (string) $v ) ), '.' );
	if ( '' === $t ) {
		return '';
	}
	$short = array( 'wed' => 'Wednesday', 'thu' => 'Thursday', 'thur' => 'Thursday', 'thurs' => 'Thursday', 'fri' => 'Friday', 'sat' => 'Saturday', 'sun' => 'Sunday', 'mon' => 'Monday', 'tue' => 'Tuesday', 'tues' => 'Tuesday' );
	foreach ( OGC_ROUND_NEED_DAYS as $d ) {
		if ( strtolower( $d ) === $t ) {
			return $d;
		}
	}
	return isset( $short[ $t ] ) ? $short[ $t ] : null;
}

/** A clock time as ogc-core.js parseTime reads it, written "9:00 AM"; '' for empty; null when it doesn't read. */
function ogc_round_need_time( $v ) {
	$t = strtolower( str_replace( '.', '', trim( (string) $v ) ) );
	if ( '' === $t ) {
		return '';
	}
	if ( preg_match( '/^(12(:00)?\s*)?noon$/', $t ) ) {
		$m = 720;
	} elseif ( preg_match( '/^(12(:00)?\s*)?midnight$/', $t ) ) {
		$m = 0;
	} elseif ( preg_match( '/^(\d{1,2})(?::(\d{2}))?\s*(am|pm|a|p)?$/', $t, $x ) ) {
		$h  = (int) $x[1];
		$mi = isset( $x[2] ) && '' !== $x[2] ? (int) $x[2] : 0;
		$ap = isset( $x[3] ) ? $x[3] : '';
		if ( $mi > 59 || $h > 24 ) {
			return null;
		}
		if ( $ap ) {
			if ( 0 === $h || $h > 12 ) {
				return null;
			}
			if ( 'p' === $ap[0] && 12 !== $h ) {
				$h += 12;
			}
			if ( 'a' === $ap[0] && 12 === $h ) {
				$h = 0;
			}
		}
		$m = ( $h * 60 + $mi ) % 1440;
	} else {
		return null;
	}
	return gmdate( 'g:i A', $m * 60 );
}

/** Kept, changed or new, with no days or no place: it can't go to the campus like that. */
function ogc_round_need_incomplete( $r ) {
	$a = isset( $r['answer'] ) ? (string) $r['answer'] : '';
	return in_array( $a, array( 'keep', 'change', 'new' ), true ) && ( '' === trim( (string) ( isset( $r['first_day'] ) ? $r['first_day'] : '' ) ) || '' === trim( (string) ( isset( $r['building'] ) ? $r['building'] : '' ) ) );
}

/** The values a row had when it was carried this year (field => value), from its `was`. */
function ogc_round_need_was( $year, $r ) {
	$w = isset( $r['was'] ) && is_string( $r['was'] ) && '' !== $r['was'] ? json_decode( $r['was'], true ) : null;
	if ( ! is_array( $w ) || ! isset( $w['in'] ) || (int) $w['in'] !== (int) $year ) {
		return array();
	}
	unset( $w['in'] );
	return array_intersect_key( $w, array_flip( OGC_ROUND_NEED_TRACK ) );
}

/**
 * Check one row after a change, and settle its answer. $before: the row as it was (null for a new one);
 * $keys: the fields this change set; $given: the answer asked for (null: none); $stamp: who and when,
 * for an answer this sets itself. Returns a WP_Error (400, with field and id) or null; $row is changed
 * in place (days and times written the one way, `was`, the answer).
 */
function ogc_round_need_check( $year, $before, &$row, $keys, $given, $stamp ) {
	$year  = (int) $year;
	$keys  = (array) $keys;
	$name  = trim( (string) ( isset( $row['item'] ) ? $row['item'] : '' ) );
	$label = '' !== $name ? $name . ' · ' : '';
	$bad   = function ( $field, $msg ) use ( $row, $label ) {
		return new WP_Error( 'ogc_need', $label . $msg, array( 'status' => 400, 'field' => $field, 'id' => isset( $row['id'] ) ? (string) $row['id'] : '' ) );
	};
	$is_new = null === $before;
	if ( ( $is_new || in_array( 'item', $keys, true ) ) && '' === $name ) {
		return $bad( 'item', 'An item' );
	}
	if ( $is_new || in_array( 'qty', $keys, true ) ) {
		$q = trim( (string) ( isset( $row['qty'] ) ? $row['qty'] : '' ) );
		if ( ! preg_match( '/^\d{1,4}$/', $q ) || (int) $q < 1 ) {
			return $bad( 'qty', 'Qty · A whole number, 1 or more' );
		}
		$row['qty'] = (string) (int) $q;
	}
	if ( $is_new || array_intersect( array( 'first_day', 'last_day' ), $keys ) ) {
		$a = ogc_round_need_day( isset( $row['first_day'] ) ? $row['first_day'] : '' );
		$b = ogc_round_need_day( isset( $row['last_day'] ) ? $row['last_day'] : '' );
		if ( null === $a || null === $b || ( '' === $a && '' !== $b ) ) {
			return $bad( 'days', 'Days · Day names, Friday–Tuesday' );
		}
		if ( '' !== $b && array_search( $b, OGC_ROUND_NEED_DAYS, true ) < array_search( $a, OGC_ROUND_NEED_DAYS, true ) ) {
			return $bad( 'days', 'Days · The last day after the first' );
		}
		$row['first_day'] = $a;
		$row['last_day']  = $b === $a ? '' : $b;
	}
	if ( $is_new || array_intersect( array( 'start', 'end' ), $keys ) ) {
		$s = ogc_round_need_time( isset( $row['start'] ) ? $row['start'] : '' );
		$e = ogc_round_need_time( isset( $row['end'] ) ? $row['end'] : '' );
		if ( null === $s ) {
			return $bad( 'start', 'Start · A time, 9:00 AM' );
		}
		if ( null === $e ) {
			return $bad( 'end', 'End · A time, 9:00 AM' );
		}
		if ( ( '' === $s ) !== ( '' === $e ) ) {
			return $bad( 'end', 'Start and end · Or neither for All day' );
		}
		$row['start'] = $s;
		$row['end']   = $e;
	}
	if ( $is_new ) {
		$row['added_in'] = (string) $year;
	}
	$added = ! empty( $row['added_in'] ) && (int) $row['added_in'] === $year;
	// What it had when carried: kept the first time a field moves away from it, dropped when it's back.
	if ( ! $is_new && ! $added ) {
		$was = ogc_round_need_was( $year, $before );
		if ( '' === $given ) {
			// Back to To answer: back to what was carried.
			foreach ( $was as $k => $v ) {
				$row[ $k ] = (string) $v;
			}
			$was = array();
		} else {
			foreach ( array_intersect( OGC_ROUND_NEED_TRACK, $keys ) as $k ) {
				$base = array_key_exists( $k, $was ) ? (string) $was[ $k ] : (string) ( isset( $before[ $k ] ) ? $before[ $k ] : '' );
				$now  = (string) ( isset( $row[ $k ] ) ? $row[ $k ] : '' );
				if ( trim( $now ) === trim( $base ) ) {
					unset( $was[ $k ] );
				} elseif ( ! array_key_exists( $k, $was ) ) {
					$was[ $k ] = $base;
				}
			}
		}
		$row['was'] = $was ? wp_json_encode( array_merge( array( 'in' => $year ), $was ) ) : '';
		// Changed means changed: values that differ from last year's are Changed, the same ones Kept.
		$a = isset( $row['answer'] ) ? (string) $row['answer'] : '';
		$to = $a;
		if ( $was && in_array( $a, array( '', 'keep' ), true ) && '' !== $given ) {
			$to = 'change';
		} elseif ( ! $was && 'change' === $a ) {
			$to = 'keep';
		}
		if ( $to !== $a ) {
			$row['answer'] = $to;
			if ( '' === $a ) {
				$row = array_merge( $row, (array) $stamp );
			}
		}
	} elseif ( $added && '' === $given ) {
		// A request added this year has nothing carried to go back to: it's New again.
		$row = array_merge( $row, array( 'answer' => 'new' ), (array) $stamp );
	}
	if ( ogc_round_need_incomplete( $row ) && ( $is_new || null !== $given || $keys ) ) {
		$day = '' === trim( (string) ( isset( $row['first_day'] ) ? $row['first_day'] : '' ) );
		return $bad( $day ? 'days' : 'where', $day ? 'Days first' : 'Place first' );
	}
	return null;
}

/* ================================================================== requests through the COA's route */

// Answering requests stays on coa/{y}/needs (its rows stamped there). Here: a returned committee's rows
// are locked for it until it reopens; Mark sent (coa/{y}/sent) is the coordinator's; a first answer
// starts the committee's line.
add_filter( 'rest_request_before_callbacks', function ( $resp, $handler, $req ) {
	if ( is_wp_error( $resp ) || ! preg_match( '#^/' . preg_quote( OGC_NS, '#' ) . '/coa/(\d{4})/(needs|sent)$#', $req->get_route(), $m ) || ! ogc_round_ready() ) {
		return $resp;
	}
	$y = (int) $m[1];
	if ( ogc_is_webmaster() || ogc_round_coord_now( $y ) ) {
		return $resp;
	}
	if ( 'sent' === $m[2] ) {
		return new WP_Error( 'ogc_not_yours', 'The coordinator’s · Intake', array( 'status' => 403 ) );
	}
	$keys  = ogc_round_req_keys( $y, $req );
	$lines = ogc_round_lines( $y );
	$today = ogc_round_today( $y );
	foreach ( $keys as $k ) {
		$st = ogc_round_line_state( $y, isset( $lines[ $k ] ) ? $lines[ $k ] : null, $today );
		if ( $st['returned'] ) {
			return new WP_Error( 'ogc_round', 'Returned · Reopen to change', array( 'status' => 423 ) );
		}
	}
	return $resp;
}, 8, 3 );

/** The committees a coa/{y}/needs request touches. */
function ogc_round_req_keys( $year, WP_REST_Request $req ) {
	$f  = ogc_file_get( (int) $year, 'needs' );
	$of = array();
	foreach ( $f ? (array) $f['rows'] : array() as $r ) {
		$of[ isset( $r['id'] ) ? (string) $r['id'] : '' ] = ogc_committee_key( isset( $r['committee'] ) ? (string) $r['committee'] : '' );
	}
	$keys = array();
	foreach ( (array) $req->get_param( 'ops' ) as $o ) {
		$id = is_array( $o ) && isset( $o['id'] ) ? (string) $o['id'] : '';
		if ( isset( $of[ $id ] ) ) {
			$keys[ $of[ $id ] ] = true;
		}
	}
	foreach ( (array) $req->get_param( 'add' ) as $a ) {
		if ( is_array( $a ) && isset( $a['committee'] ) ) {
			$keys[ ogc_committee_key( (string) $a['committee'] ) ] = true;
		}
	}
	return array_keys( $keys );
}

add_filter( 'rest_post_dispatch', function ( $res, $server, $req ) {
	if ( ! ( $res instanceof WP_REST_Response ) || $res->get_status() >= 300 || ! preg_match( '#^/' . preg_quote( OGC_NS, '#' ) . '/coa/(\d{4})/needs$#', $req->get_route(), $m ) || ! ogc_round_ready() ) {
		return $res;
	}
	$y     = (int) $m[1];
	$lines = ogc_round_lines( $y );
	foreach ( ogc_round_req_keys( $y, $req ) as $k ) {
		if ( ! empty( $lines[ $k ]['sent_at'] ) && empty( $lines[ $k ]['started_at'] ) ) {
			ogc_round_line_set( $y, $k, array( 'started_at' => ogc_now() ), true );
		}
	}
	return $res;
}, 5, 3 );

/* ================================================================== Home, tasks, the board's lines */

/** A kind's date from the round (Answer requests = the round's due date), or ''. */
function ogc_round_kind_due( $kind, $year ) {
	if ( 'requests_answer' !== $kind || ! ogc_round_ready() ) {
		return '';
	}
	return ogc_round_dates( $year )['due'];
}

/** Answer requests is done when the committee has returned its round: the day, '' if not yet, or null
 * when the round hasn't gone to it (the old rule then: every row answered). */
function ogc_round_returned_on( $year, $ckey, $today ) {
	if ( ! ogc_round_ready() ) {
		return null;
	}
	$lines = ogc_round_lines( $year );
	$st    = ogc_round_line_state( $year, isset( $lines[ $ckey ] ) ? $lines[ $ckey ] : null, $today );
	if ( ! $st['sent'] ) {
		return null;
	}
	return $st['returned'];
}

add_filter( 'ogc_app_needs', function ( $rows, $year, $ckey, $ctx ) {
	if ( ! ogc_round_ready() ) {
		return $rows;
	}
	// The round says it now: the old lines about requests (every committee's, and the COA's) go.
	$rows = array_values( array_filter( (array) $rows, function ( $r ) {
		$k = isset( $r['key'] ) ? (string) $r['key'] : '';
		return 'requests' !== $k && 0 !== strpos( $k, 'requests:' );
	} ) );
	if ( 'before' !== $ctx['phase'] ) {
		return $rows;
	}
	$today = $ctx['today'];
	$s     = ogc_round_settings( $year );
	$dates = ogc_round_dates( $year, $s );
	$lines = ogc_round_lines( $year );
	$from  = ogc_round_holder_name( $year );
	// A committee's own: once the round has gone to it, until it returns.
	if ( 'coa' !== $ckey && ! in_array( $ckey, $s['skip'], true ) ) {
		$st = ogc_round_line_state( $year, isset( $lines[ $ckey ] ) ? $lines[ $ckey ] : null, $today );
		if ( in_array( $st['status'], array( 'sent', 'opened', 'started' ), true ) ) {
			$left = ogc_round_left( $year, $ckey );
			$late = $dates['due'] && $today > $dates['due'];
			$rows[] = $left['total']
				? array( 'key' => 'round:' . $ckey, 'kind' => 'requests_answer', 'words' => 'Requests · ' . $left['total'] . ' to answer', 'why' => ( $dates['due'] ? 'Due ' . ogc_app_md( $dates['due'], $year ) . ( $late ? ' · Late' : '' ) . ' · ' : '' ) . 'From ' . $from, 'go' => array( 's' => 'requests', 'c' => $ckey ), 'button' => 'Answer ' . $left['total'], 'due' => $dates['due'], 'rank' => $late ? 0 : 2, 'tone' => $late ? 'late' : '' )
				: array( 'key' => 'round:' . $ckey, 'kind' => 'requests_answer', 'words' => 'Requests answered', 'why' => 'Not returned · ' . $from . ' waits for it', 'go' => array( 's' => 'requests', 'c' => $ckey ), 'button' => 'Return', 'due' => $dates['due'], 'rank' => $late ? 0 : 2, 'tone' => $late ? 'late' : '' );
		}
	}
	// The round's own work, for whoever holds it (the COA unless handed on).
	$holder = ogc_round_holder( $year );
	if ( $ckey === $holder && $dates['send'] ) {
		$cs      = ogc_round_committees( $year );
		$sentday = ogc_round_day( $year, $s['sent_at'] );
		if ( '' === $sentday || $sentday > $today ) {
			if ( ogc_app_days_to( $dates['send'], $today ) <= 30 ) {
				$late   = $today > $dates['send'];
				$rows[] = array( 'key' => 'round-send', 'kind' => 'requests_sent', 'words' => 'Send the intake', 'why' => ( $late ? 'Send date ' . ogc_app_md( $dates['send'], $year ) . ' · Late' : 'Send date ' . ogc_app_md( $dates['send'], $year ) ) . ' · ' . ogc_app_plural( count( $cs ), 'committee' ), 'go' => array( 's' => 'intake' ), 'button' => 'Open Intake', 'due' => $dates['send'], 'rank' => $late ? 0 : 3, 'tone' => $late ? 'late' : '' );
			}
		} else {
			$wait = 0;
			$back = 0;
			foreach ( $cs as $c ) {
				$st    = ogc_round_line_state( $year, isset( $lines[ $c['ckey'] ] ) ? $lines[ $c['ckey'] ] : null, $today );
				$wait += in_array( $st['status'], array( 'sent', 'opened', 'started' ), true ) ? 1 : 0;
				$back += 'returned' === $st['status'] ? 1 : 0;
			}
			$late   = $dates['due'] && $today > $dates['due'];
			$settle = count( ogc_round_settle_list( $year ) );
			if ( $wait ) {
				$rows[] = array( 'key' => 'round-wait', 'kind' => 'requests_sent', 'words' => 'Intake · ' . ogc_app_plural( $wait, 'committee' ) . ' to answer', 'why' => 'Due ' . ogc_app_md( $dates['due'], $year ) . ( $late ? ' · Late' : '' ) . ( $back ? ' · ' . $back . ' returned' : '' ), 'go' => array( 's' => 'intake', 'v' => 'waiting' ), 'button' => 'Open Intake', 'due' => $dates['due'], 'rank' => $late ? 0 : 3, 'tone' => $late ? 'late' : '' );
			}
			if ( $settle ) {
				$rows[] = array( 'key' => 'round-settle', 'words' => ogc_app_plural( $settle, 'row' ) . ' to settle', 'why' => 'Not sure, or no committee · Intake', 'go' => array( 's' => 'intake', 'v' => 'settle' ), 'button' => 'Settle ' . $settle, 'due' => '', 'rank' => 3 );
			}
			$campus = function_exists( 'ogc_app_requests_sent' ) ? ogc_app_requests_sent( $year ) : '';
			if ( ! $wait && ! $campus ) {
				$rows[] = array( 'key' => 'round-campus', 'kind' => 'requests_sent', 'words' => 'Every committee returned', 'why' => $s['exported'] ? 'Downloaded ' . ogc_app_md( $s['exported'], $year ) . ' · Mark as sent once it’s gone' : 'Export for campus · Then mark sent', 'go' => array( 's' => 'intake' ), 'button' => 'Open Intake', 'due' => '', 'rank' => 2 );
			}
		}
	}
	// The COA, when another committee holds the round: how it stands, once it's out.
	if ( 'coa' === $ckey && 'coa' !== $holder ) {
		$sentday = ogc_round_day( $year, $s['sent_at'] );
		if ( '' !== $sentday && $sentday <= $today ) {
			$cs   = ogc_round_committees( $year );
			$back = 0;
			foreach ( $cs as $c ) {
				$st    = ogc_round_line_state( $year, isset( $lines[ $c['ckey'] ] ) ? $lines[ $c['ckey'] ] : null, $today );
				$back += 'returned' === $st['status'] ? 1 : 0;
			}
			if ( $back < count( $cs ) ) {
				$rows[] = array( 'key' => 'round-coa', 'words' => 'Intake · ' . $back . ' of ' . count( $cs ) . ' returned', 'why' => 'Run by ' . $from . ' · Due ' . ogc_app_md( $dates['due'], $year ), 'go' => array( 's' => 'intake' ), 'button' => 'Open Intake', 'due' => '', 'rank' => 3, 'manual' => false );
			}
		}
	}
	return $rows;
}, 30, 4 );

// The board's line for a committee the round is waiting on (a more specific line from its own work
// still wins: this runs first).
add_filter( 'ogc_committee_status', function ( $line, $year, $ckey, $ctx ) {
	if ( 'coa' === $ckey || ! ogc_round_ready() ) {
		return $line;
	}
	$today = ogc_round_today( $year );
	$lines = ogc_round_lines( $year );
	$st    = ogc_round_line_state( $year, isset( $lines[ $ckey ] ) ? $lines[ $ckey ] : null, $today );
	if ( ! in_array( $st['status'], array( 'sent', 'opened', 'started' ), true ) ) {
		return $line;
	}
	$left = ogc_round_left( $year, $ckey );
	$due  = ogc_round_dates( $year )['due'];
	return 'Requests · ' . ( $left['total'] ? $left['total'] . ' to answer' : 'Not returned' ) . ( $due ? ' · Due ' . ogc_app_md( $due, $year ) : '' );
}, 5, 4 );

add_filter( 'ogc_committee_look', function ( $look, $year, $ckey, $ctx ) {
	if ( 'coa' === $ckey || ! ogc_round_ready() ) {
		return $look;
	}
	$today = ogc_round_today( $year );
	$lines = ogc_round_lines( $year );
	$st    = ogc_round_line_state( $year, isset( $lines[ $ckey ] ) ? $lines[ $ckey ] : null, $today );
	$due   = ogc_round_dates( $year )['due'];
	if ( in_array( $st['status'], array( 'sent', 'opened', 'started' ), true ) && $due && $today > $due ) {
		$look[] = 'Requests late';
	}
	return $look;
}, 10, 4 );

/* ================================================================== the emails */

add_filter( 'ogc_mail_kinds', function ( $k ) {
	$k['round_ask']    = 'Intake: a committee’s requests (Send)';
	$k['round_remind'] = 'Intake: reminder';
	return $k;
} );

add_filter( 'ogc_mail_samples', function ( $s ) {
	$d = array( 'committee' => 'Nursery', 'due' => '2027-01-01', 'left' => 9, 'from' => 'A/V', 'venue' => 'Indiana Wesleyan University', 'url' => ogc_url( 'app', array( 'year' => 2027, 's' => 'requests', 'c' => 'nursery' ) ), 'asks' => array( array( 'Requests', '6 requests to the campus' ), array( 'Packet', 'Help · Nursery' ), array( 'Contact', 'Head and phone' ) ) );
	$s['round_ask']    = $d;
	$s['round_remind'] = array_merge( $d, array( 'again' => true, 'left' => 4 ) );
	return $s;
} );

add_filter( 'ogc_mail_template_kind', function ( $m, $kind, $d, $base ) {
	if ( 'round_ask' !== $kind && 'round_remind' !== $kind ) {
		return $m;
	}
	$y     = isset( $d['year'] ) ? (int) $d['year'] : 0;
	$com   = isset( $d['committee'] ) ? wp_strip_all_tags( (string) $d['committee'] ) : '';
	// The due date with its year ("Jan 1, 2027"): the email is read in the year before the Conference.
	$due   = ! empty( $d['due'] ) && strtotime( (string) $d['due'] . ' 12:00 UTC' ) ? gmdate( 'M j, Y', strtotime( (string) $d['due'] . ' 12:00 UTC' ) ) : '';
	$again = 'round_remind' === $kind;
	$left  = isset( $d['left'] ) ? (int) $d['left'] : 0;
	$from  = ! empty( $d['from'] ) ? wp_strip_all_tags( (string) $d['from'] ) : 'the COA';
	$head  = $again ? 'Reminder · ' . $com . ' requests' : $com . ' requests for ' . ( $y ? $y : 'the Conference' );
	$facts = array();
	if ( $due ) {
		$facts[] = array( 'Due', $due );
	}
	foreach ( isset( $d['asks'] ) ? (array) $d['asks'] : array() as $a ) {
		if ( is_array( $a ) && isset( $a[0], $a[1] ) ) {
			$facts[] = array( (string) $a[0], (string) $a[1] );
		}
	}
	$lines = $again
		? array( $left ? ogc_app_plural( $left, 'row' ) . ' to answer' : 'Answered · Not returned' )
		: array( 'Filled in from last year' . ( ! empty( $d['venue'] ) ? ' at ' . wp_strip_all_tags( (string) $d['venue'] ) : '' ) . '. Answer each row Keep, Change, Remove or Not sure, then Return.' );
	$out = ogc_mail_compose( array_merge( $base, array(
		'subject'   => $head,
		'preheader' => $due ? 'Due ' . $due : '',
		'heading'   => $head,
		'lines'     => $lines,
		'facts'     => $facts,
		'button'    => ! empty( $d['url'] ) ? array( 'Open ' . $com . ' requests', (string) $d['url'] ) : null,
		'after'     => array( 'Not sure about a row? Mark it Not sure and say why. ' . $from . ' settles it.' ),
		'reason'    => 'You’re on the ' . ( $y ? $y . ' ' : '' ) . $com . ' committee.',
	) ) );
	if ( ! empty( $d['reply_to'] ) && is_email( $d['reply_to'] ) ) {
		$out['reply_to'] = (string) $d['reply_to'];
	}
	return $out;
}, 10, 4 );

/* ================================================================== local samples (OGC_DEV only) */

/**
 * 2027's round as A/V would be running it in mid-October on the local site: handed to A/V, sent Oct 2,
 * due Nov 13, the automatic reminder 7 days before; committees at every stage; a few rows Not sure;
 * one request whose committee isn't on the list; one Help card nobody answers for. Made up.
 */
function ogc_round_seed_samples( $year ) {
	global $wpdb;
	$year = (int) $year;
	if ( ! OGC_DEV || 2027 !== $year || ! ogc_round_ready() || ! ogc_year_get( $year ) || ! ogc_app_committee( $year, 'a/v' ) ) {
		return;
	}
	$wpdb->delete( ogc_table( 'round_lines' ), array( 'year' => $year, 'sample' => 1 ) );
	$wpdb->delete( ogc_table( 'round_answers' ), array( 'year' => $year, 'sample' => 1 ) );
	unset( $GLOBALS['ogc_round_l'][ $year ], $GLOBALS['ogc_round_a'][ $year ], $GLOBALS['ogc_round_s'][ $year ] );
	$owners = array(
		'guide:lodging' => 'lodging', 'guide:arriving' => 'lodging', 'guide:campers' => 'lodging', 'guide:meals' => 'food',
		'guide:youngfolks' => 'young folks', 'guide:preteens' => 'preteens', 'guide:getting-around' => 'transportation',
		'help:first-aid' => 'first aid', 'help:rides' => 'transportation', 'help:lodging' => 'lodging', 'help:lost-and-found' => 'lodging',
		'help:campers' => 'lodging', 'help:emergency' => 'coa', 'help:urgent-care' => 'first aid', 'help:campus-alerts' => 'coa',
	);
	// Last year's round (only what carries: owners and the reminder), then this year's, sent.
	$prev = ogc_state_get( $year - 1, 'round' );
	if ( ! $prev ) {
		ogc_state_put( $year - 1, 'round', array_merge( ogc_round_defaults(), array( 'owners' => $owners, 'sent_at' => '2025-11-14 14:00:00', 'sent_by' => 'Jonah W.' ) ) );
	}
	$cur = ogc_state_get( $year, 'round' );
	ogc_state_put( $year, 'round', array_merge( ogc_round_defaults(), array( 'send_off' => -238, 'due_off' => -196, 'remind' => 7, 'owners' => $owners, 'sent_at' => '2026-10-02 14:10:00', 'sent_by' => 'Micah R.', 'sample' => 1 ) ), $cur ? $cur['version'] : 0 );
	unset( $GLOBALS['ogc_round_s'][ $year ] );
	// The COA handed Intake to A/V (A/V offered on Oct 12; a sample of the choice, easily taken back).
	if ( ! ogc_app_handed_to( $year, 'intake' ) ) {
		$c = ogc_app_committee( $year, 'a/v' );
		$wpdb->update( ogc_table( 'committees' ), array( 'screens' => implode( ',', array_merge( $c['screens'], array( 'intake' ) ) ), 'updated_at' => ogc_now() ), array( 'id' => (int) $c['id'] ) );
		ogc_app_committees( $year, true );
		if ( function_exists( 'ogc_app_move_screen_tasks' ) ) {
			ogc_app_move_screen_tasks( $year, 'intake', 'a/v' );
		}
	}
	$who  = function ( $email ) {
		$u = get_user_by( 'email', $email );
		return $u ? (int) $u->ID : 0;
	};
	$name = function ( $email ) use ( $year ) {
		$m = function_exists( 'ogc_member_find' ) ? ogc_member_find( $year, $email, true ) : null;
		return $m ? ogc_app_person_name( $m ) : '';
	};
	$sent  = '2026-10-02 14:10:00';
	$lines = array(
		// ckey => [opened, started, returned, returned by, reminded]
		'a/v'              => array( '2026-10-03 19:02:00', '2026-10-03 19:05:00', '2026-10-06 20:40:00', 'micah.rhodes@example.com', null ),
		'lodging'          => array( '2026-10-04 13:20:00', '2026-10-04 13:31:00', '2026-10-09 15:12:00', 'ada.turner@example.com', null ),
		'first aid'        => array( '2026-10-05 22:41:00', '2026-10-05 22:44:00', '2026-10-10 01:15:00', 'rachel.owens@example.com', null ),
		'food'             => array( '2026-10-05 12:10:00', '2026-10-05 12:16:00', null, '', null ),
		'ushers'           => array( '2026-10-07 23:30:00', '2026-10-07 23:34:00', null, '', null ),
		'preteens'         => array( '2026-10-06 18:00:00', '2026-10-06 18:09:00', null, '', null ),
		'communion'        => array( '2026-10-08 16:45:00', null, null, '', null ),
		'nursery'          => array( null, null, null, '', null ),
		'transportation'   => array( null, null, null, '', '2026-10-09 15:00:00' ),
		'young folks'      => array( null, null, null, '', '2026-10-09 15:00:00' ),
	);
	foreach ( $lines as $k => $l ) {
		if ( ! ogc_app_committee( $year, $k ) ) {
			continue;
		}
		$n = count( ogc_round_to( $year, $k ) );
		if ( ! $n ) {
			continue;
		}
		$wpdb->delete( ogc_table( 'round_lines' ), array( 'year' => $year, 'ckey' => $k ) );
		$wpdb->insert( ogc_table( 'round_lines' ), array(
			'year' => $year, 'ckey' => $k, 'sent_at' => $sent, 'sent_n' => $n,
			'opened_at' => $l[0], 'started_at' => $l[1], 'returned_at' => $l[2], 'returned_by' => $l[3] ? $who( $l[3] ) : 0, 'returned_name' => $l[3] ? $name( $l[3] ) : '',
			'reminded_at' => $l[4], 'reminds' => $l[4] ? 1 : 0, 'sample' => 1, 'updated_at' => ogc_now(),
		) );
	}
	// Requests: the returned committees answered every row; the ones started, some.
	$f = ogc_file_get( $year, 'needs' );
	if ( $f ) {
		$rows  = array_values( (array) $f['rows'] );
		$names = array( 'a/v' => 'Micah R.', 'lodging' => 'Ada T.', 'first aid' => 'Rachel O.', 'food' => 'Martha B.', 'ushers' => 'Aaron W.', 'preteens' => 'Naomi R.' );
		$on    = array( 'a/v' => '2026-10-06', 'lodging' => '2026-10-09', 'first aid' => '2026-10-09', 'food' => '2026-10-05', 'ushers' => '2026-10-07', 'preteens' => '2026-10-06' );
		$count = array();
		$have  = false;
		foreach ( $rows as &$r ) {
			$k = ogc_committee_key( isset( $r['committee'] ) ? (string) $r['committee'] : '' );
			$have = $have || 'Parking' === ( isset( $r['committee'] ) ? $r['committee'] : '' );
			if ( ! isset( $names[ $k ] ) || ! empty( $r['answer'] ) ) {
				continue;
			}
			$count[ $k ] = ( isset( $count[ $k ] ) ? $count[ $k ] : 0 ) + 1;
			$i           = $count[ $k ];
			$a           = 'keep';
			if ( in_array( $k, array( 'food', 'preteens' ), true ) && $i > 3 ) {
				continue;   // started: the rest still to answer
			}
			if ( 'ushers' === $k && $i > 12 ) {
				continue;
			}
			if ( 'ushers' === $k && 2 === $i ) {
				$a               = 'notsure';
				$r['question']   = 'Eight, or six? Two ushers may not need one this year.';
			}
			if ( 'preteens' === $k && 3 === $i ) {
				$a             = 'notsure';
				$r['question'] = 'One, or two? A second teacher may lead the singing.';
			}
			if ( 'lodging' === $k && 1 === $i ) {
				$a        = 'change';
				$r['was'] = wp_json_encode( array( 'in' => $year, 'qty' => (string) $r['qty'] ) );
				$r['qty'] = (string) max( 1, (int) $r['qty'] + 1 );
			}
			if ( 'a/v' === $k && 2 === $i ) {
				$a = 'remove';
			}
			$r['answer']      = $a;
			$r['answered_by'] = $names[ $k ];
			$r['answered_as'] = '';
			$r['answered_at'] = $on[ $k ];
		}
		unset( $r );
		// One request whose committee isn't on 2027's list (a 2026 name): the coordinator assigns it.
		if ( ! $have ) {
			$rows[] = array( 'id' => 'N900', 'committee' => 'Parking', 'for' => '', 'item' => 'Traffic cone', 'qty' => '12', 'detail' => '', 'supplied_by' => 'IWU Facilities', 'first_day' => 'Friday', 'last_day' => 'Tuesday', 'start' => '', 'end' => '', 'building' => 'Multipurpose Field', 'room' => '', 'notes' => '', 'answer' => '' );
		}
		ogc_file_put( $year, 'needs', $rows, $f['version'] );
	}
	// Packet parts, Help cards and contacts: the returned committees kept theirs; one Not sure.
	$ans = array(
		array( 'lodging', 'guide:lodging', 'keep', '', '2026-10-09 15:05:00', 'ada.turner@example.com' ),
		array( 'lodging', 'guide:arriving', 'keep', '', '2026-10-09 15:06:00', 'ada.turner@example.com' ),
		array( 'lodging', 'guide:campers', 'keep', '', '2026-10-09 15:07:00', 'ada.turner@example.com' ),
		array( 'lodging', 'help:lodging', 'keep', '', '2026-10-09 15:08:00', 'ada.turner@example.com' ),
		array( 'lodging', 'help:lost-and-found', 'keep', '', '2026-10-09 15:08:00', 'ada.turner@example.com' ),
		array( 'lodging', 'help:campers', 'keep', '', '2026-10-09 15:09:00', 'ada.turner@example.com' ),
		array( 'lodging', 'contact:lodging', 'keep', '', '2026-10-09 15:10:00', 'ada.turner@example.com' ),
		array( 'first aid', 'help:first-aid', 'keep', '', '2026-10-10 01:10:00', 'rachel.owens@example.com' ),
		array( 'first aid', 'help:urgent-care', 'keep', '', '2026-10-10 01:11:00', 'rachel.owens@example.com' ),
		array( 'first aid', 'contact:first aid', 'keep', '', '2026-10-10 01:12:00', 'rachel.owens@example.com' ),
		array( 'a/v', 'contact:a/v', 'keep', '', '2026-10-06 20:30:00', 'micah.rhodes@example.com' ),
		array( 'food', 'guide:meals', 'notsure', 'The caterer may move breakfast to 6:30. We hear in March.', '2026-10-05 12:20:00', 'martha.brooks@example.com' ),
		array( 'preteens', 'contact:preteens', 'keep', '', '2026-10-06 18:12:00', 'naomi.reed@example.com' ),
	);
	foreach ( $ans as $a ) {
		$wpdb->delete( ogc_table( 'round_answers' ), array( 'year' => $year, 'item' => $a[1] ) );
		$wpdb->insert( ogc_table( 'round_answers' ), array( 'year' => $year, 'ckey' => $a[0], 'item' => $a[1], 'answer' => $a[2], 'note' => $a[3], 'by_user' => $who( $a[5] ), 'by_name' => $name( $a[5] ), 'at' => $a[4], 'sample' => 1 ) );
	}
	unset( $GLOBALS['ogc_round_l'][ $year ], $GLOBALS['ogc_round_a'][ $year ], $GLOBALS['ogc_round_s'][ $year ] );
	update_option( 'ogc_round_seeded_' . $year, 1, false );
}

// After a year's seed loads (reset, or a forced reload): its sample round again, after the app's
// committees and the sample people.
add_action( 'ogc_seed_year', function ( $year ) {
	if ( OGC_DEV && 2027 === (int) $year ) {
		delete_option( 'ogc_round_seeded_2027' );
		ogc_round_seed_samples( 2027 );
	}
}, 60 );

// A local site that had its seed before the round existed: once.
add_action( 'init', function () {
	if ( ! OGC_DEV || get_option( 'ogc_round_seeded_2027' ) || ! ogc_round_ready() ) {
		return;
	}
	ogc_round_seed_samples( 2027 );
}, 60 );
