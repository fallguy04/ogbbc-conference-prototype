<?php
/**
 * The map area's fixture page, local development only (polish 2): every hall and floor of a year's plans
 * drawn with every state a room can be in (free, taken, held, off, sel, mine, sug, other, plain), long
 * names and Lodging's walker and older marks, so tools/map-check.sh can say no word runs past its room
 * or reads under 11 px. Lodging 2026 had cleared its names by date, so the board it checked drew nothing.
 *   /annual-conference/dev-plans/?year=2026
 * The plans are the campus record's (sample geometry); no one's name or record is in it.
 */

defined( 'ABSPATH' ) || exit;

if ( ! OGC_DEV || ! function_exists( 'ogc_is_local_host' ) || ! ogc_is_local_host() ) {
	return;
}

add_filter( 'ogc_pages', function ( $p ) {
	$p['dev-plans'] = array(
		'path'        => 'dev-plans',
		'members'     => false,
		'folder'      => 'shared',
		'shell'       => 'bare',
		'template'    => 'dev-map-plans.php',
		'html_class'  => '',
		'header'      => array(),
		'noindex'     => true,
		'description' => '',
		'fonts'       => '',
		'head'        => '',
		'title'       => 'Floor plans (fixture)',
		'styles'      => array( 'shared/site-shell.css', 'shared/ogc-ui.css', 'shared/ogc-map.css' ),
		'scripts'     => array( 'shared/ogc-core.js', 'shared/ogc-map.js', 'shared/ogc-map-fixture.js' ),
	);
	return $p;
}, 30 );

/** The year's plans as the fixture draws them (sample geometry only). */
function ogc_map_dev_plans( $year ) {
	$rec = function_exists( 'ogc_map_record' ) ? ogc_map_record( $year ) : null;
	return $rec && $rec['plans'] ? $rec['plans']['rows'] : array();
}
