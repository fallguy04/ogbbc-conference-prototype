<?php
/**
 * Sermons from the site's own sermon posts (conference area). The webmasters already post every
 * Conference sermon as a `sermon` post in the series "<year>-annual-conference"; typing each one again
 * into attachments.csv is where the playback and title typos came from (docs/14). So:
 *
 *   - the sermon's edit screen gets one field, Service: a type-ahead of that year's published
 *     services ("Sat · 10:00 AM · Worship"), saved as the schedule row's id (post meta _ogc_service);
 *   - the year's recordings (attachments) are read from those posts, in the row's place, beside any
 *     rows typed into attachments.csv (the same post isn't listed twice);
 *   - the speaker is "First L." on the page, whatever the post says.
 *
 * The same for News: the year's Conference News category (ogc_pub_news_category: "<year>-conference-news"
 * unless the site names it otherwise) joins milestones.csv's rows, newest first on the page.
 * (The Resource Center's minutes and papers are next: their post type isn't known here yet.)
 *
 * The real theme's sermon fields (speaker, audio, length, Scripture) aren't known here: they're one
 * filter, ogc_pub_sermon_fields, for Corey to point at the theme's ACF fields. Locally (OGC_DEV, no theme)
 * a bare `sermon` type and `sermon_series` taxonomy stand in, so it can be tried.
 */

defined( 'ABSPATH' ) || exit;

/** Where a sermon post keeps its parts: post meta keys (or ACF field names) by part. */
function ogc_pub_sermon_fields() {
	return (array) apply_filters( 'ogc_pub_sermon_fields', array(
		'speaker'  => 'speaker',
		'audio'    => 'audio_url',
		'duration' => 'duration',
		'refs'     => 'scripture',
		'taxonomy' => 'sermon_series',
	) );
}

function ogc_pub_sermon_get( $post_id, $part ) {
	$f = ogc_pub_sermon_fields();
	$k = isset( $f[ $part ] ) ? $f[ $part ] : '';
	if ( ! $k ) {
		return '';
	}
	$v = function_exists( 'get_field' ) ? get_field( $k, $post_id ) : get_post_meta( $post_id, $k, true );
	return is_scalar( $v ) ? trim( (string) $v ) : '';
}

/** "Sheldon Bowman" → "Sheldon B." (the site's convention for names in public). */
function ogc_pub_first_l( $name ) {
	$w = preg_split( '/\s+/', trim( (string) $name ) );
	if ( count( $w ) < 2 ) {
		return (string) $w[0];
	}
	$last = end( $w );
	return $w[0] . ' ' . ( preg_match( '/^\p{L}\.$/u', $last ) ? $last : mb_substr( $last, 0, 1 ) . '.' );
}

// Locally only, with no theme to bring them: a bare sermon type and its series, to try the field.
add_action( 'init', function () {
	if ( ! OGC_DEV || post_type_exists( 'sermon' ) ) {
		return;
	}
	register_post_type( 'sermon', array( 'label' => 'Sermons', 'public' => true, 'show_in_rest' => true, 'supports' => array( 'title', 'editor', 'custom-fields' ) ) );
	register_taxonomy( 'sermon_series', 'sermon', array( 'label' => 'Sermon series', 'public' => true, 'show_in_rest' => true, 'hierarchical' => true ) );
}, 5 );

/** The year a sermon belongs to, from its series ("2027-annual-conference"), or 0. */
function ogc_pub_sermon_year( $post_id ) {
	$tax   = ogc_pub_sermon_fields()['taxonomy'];
	$terms = taxonomy_exists( $tax ) ? wp_get_post_terms( $post_id, $tax, array( 'fields' => 'slugs' ) ) : array();
	foreach ( is_wp_error( $terms ) ? array() : $terms as $slug ) {
		if ( preg_match( '/^(\d{4})-annual-conference$/', $slug, $m ) ) {
			return (int) $m[1];
		}
	}
	return 0;
}

/** The year's services as choices: row id → "Sat · 10:00 AM · Worship" (published rows only). */
function ogc_pub_sermon_services( $year ) {
	$f = ogc_file_get( $year, 'schedule' );
	if ( ! $f ) {
		return array();
	}
	$out = array();
	foreach ( ogc_pub_items( $year, $f['rows'] ) as $it ) {
		$k = isset( $it['kind'] ) ? strtolower( $it['kind'] ) : '';
		if ( empty( $it['_id'] ) || ! ( in_array( $k, array( 'worship', 'council', 'communion', 'singing', 'teaching', 'meeting' ), true ) || ! empty( $it['call_in'] ) ) ) {
			continue;
		}
		$out[ $it['id'] ] = gmdate( 'D', strtotime( $it['date'] ) ) . ' · ' . ( isset( $it['start'] ) ? $it['start'] : '' ) . ' · ' . $it['title'];
	}
	return $out;
}

// The Service field on the sermon's edit screen.
register_meta( 'post', '_ogc_service', array(
	'object_subtype'    => 'sermon',
	'type'              => 'string',
	'single'            => true,
	'show_in_rest'      => false,
	'sanitize_callback' => 'sanitize_key',
	'auth_callback'     => function ( $allowed, $key, $post_id ) {
		return current_user_can( 'edit_post', $post_id );
	},
) );

add_action( 'add_meta_boxes_sermon', function ( $post ) {
	add_meta_box( 'ogc-service', 'Service', 'ogc_pub_sermon_box', 'sermon', 'side', 'high' );
} );

function ogc_pub_sermon_box( $post ) {
	$year = ogc_pub_sermon_year( $post->ID );
	$cur  = (string) get_post_meta( $post->ID, '_ogc_service', true );
	wp_nonce_field( 'ogc_service_' . $post->ID, 'ogc_service_nonce' );
	if ( ! $year ) {
		echo '<p class="description">' . esc_html__( 'Choose the year’s Annual Conference series first.', 'ogc-conference' ) . '</p>';
		return;
	}
	$opts = ogc_pub_sermon_services( $year );
	$text = isset( $opts[ $cur ] ) ? $opts[ $cur ] : '';
	echo '<input type="text" class="widefat" name="ogc_service_text" list="ogc-services" value="' . esc_attr( $text ) . '" placeholder="' . esc_attr__( 'Search', 'ogc-conference' ) . '" autocomplete="off" title="' . esc_attr__( 'The service this sermon was preached in. It puts the recording in its place on the Conference page.', 'ogc-conference' ) . '">';
	echo '<datalist id="ogc-services">';
	foreach ( $opts as $label ) {
		echo '<option value="' . esc_attr( $label ) . '"></option>';
	}
	echo '</datalist>';
}

add_action( 'save_post_sermon', function ( $post_id ) {
	if ( ! isset( $_POST['ogc_service_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['ogc_service_nonce'] ) ), 'ogc_service_' . $post_id ) ) {
		return;
	}
	if ( ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}
	$text = isset( $_POST['ogc_service_text'] ) ? sanitize_text_field( wp_unslash( $_POST['ogc_service_text'] ) ) : '';
	$year = ogc_pub_sermon_year( $post_id );
	$id   = $year && '' !== $text ? array_search( $text, ogc_pub_sermon_services( $year ), true ) : false;
	if ( false === $id ) {
		delete_post_meta( $post_id, '_ogc_service' );
	} else {
		update_post_meta( $post_id, '_ogc_service', sanitize_key( $id ) );
	}
} );

/** The year's sermon posts that name a service, as attachments.csv rows. */
function ogc_pub_sermon_rows( $year ) {
	$tax = ogc_pub_sermon_fields()['taxonomy'];
	if ( ! post_type_exists( 'sermon' ) || ! taxonomy_exists( $tax ) ) {
		return array();
	}
	$q    = new WP_Query( array(
		'post_type'      => 'sermon',
		'post_status'    => 'publish',
		'posts_per_page' => 200,
		'no_found_rows'  => true,
		'meta_query'     => array( array( 'key' => '_ogc_service', 'compare' => 'EXISTS' ) ),
		'tax_query'      => array( array( 'taxonomy' => $tax, 'field' => 'slug', 'terms' => $year . '-annual-conference' ) ),
	) );
	$out = array();
	foreach ( $q->posts as $p ) {
		$svc = (string) get_post_meta( $p->ID, '_ogc_service', true );
		// A row id with its day ("r22-saturday") is that day of a row that repeats.
		$row = preg_replace( '/-(friday|saturday|sunday|monday|tuesday|wednesday|thursday)$/', '', $svc );
		$out[] = array(
			'row'      => $row,
			'day'      => '',
			'start'    => '',
			'kind'     => 'sermon',
			'title'    => get_the_title( $p ),
			'by'       => ogc_pub_first_l( ogc_pub_sermon_get( $p->ID, 'speaker' ) ),
			'url'      => get_permalink( $p ),
			'audio'    => ogc_pub_sermon_get( $p->ID, 'audio' ),
			'duration' => ogc_pub_sermon_get( $p->ID, 'duration' ),
			'refs'     => ogc_pub_sermon_get( $p->ID, 'refs' ),
			'note'     => '',
			'posted'   => get_post_time( 'Y-m-d\TH:i', false, $p ),
			'post'     => (string) $p->ID,
		);
	}
	return $out;
}

// Every reader's attachments: the typed rows, then the sermon posts not already among them.
add_filter( 'ogc_file_rows_out', function ( $rows, $year, $name, $member ) {
	if ( 'attachments' !== $name ) {
		return $rows;
	}
	$have = array();
	foreach ( $rows as $r ) {
		if ( ! empty( $r['url'] ) ) {
			$have[ untrailingslashit( $r['url'] ) ] = 1;
		}
	}
	foreach ( ogc_pub_sermon_rows( $year ) as $r ) {
		if ( isset( $have[ untrailingslashit( $r['url'] ) ] ) ) {
			continue;
		}
		// The same gates as typed rows: published, and only once the schedule is.
		$rows[] = $r;
	}
	return $rows;
}, 5, 4 );

/* ------------------------------------------------------------------ News from the site's posts */

/** The year's Conference News category (a child of Conference News, one per year). Its slug pattern
 * is a filter, for the real site's own naming. */
function ogc_pub_news_category( $year ) {
	$slug = (string) apply_filters( 'ogc_pub_news_category', $year . '-conference-news', $year );
	$t    = get_category_by_slug( $slug );
	return $t ? (int) $t->term_id : 0;
}

/** The year's News posts as milestones.csv rows: posted before the Conference's first day is "before",
 * after it "after"; the post itself is the link. */
function ogc_pub_news_rows( $year ) {
	$cat = ogc_pub_news_category( $year );
	if ( ! $cat ) {
		return array();
	}
	$y     = ogc_year_get( (int) $year );
	$start = $y && ! empty( $y['start'] ) ? $y['start'] : $year . '-05-01';
	$out   = array();
	foreach ( get_posts( array( 'cat' => $cat, 'post_status' => 'publish', 'numberposts' => 50, 'suppress_filters' => false ) ) as $p ) {
		$date  = get_post_time( 'Y-m-d', false, $p );
		$out[] = array(
			'phase' => $date < $start ? 'before' : 'after',
			'date'  => $date,
			'kind'  => 'notice',
			'title' => get_the_title( $p ),
			'url'   => get_permalink( $p ),
			'note'  => '',
			'post'  => (string) $p->ID,
		);
	}
	return $out;
}

// Every reader's News: the rows typed into milestones.csv, then the year's News posts not among them.
add_filter( 'ogc_file_rows_out', function ( $rows, $year, $name, $member ) {
	if ( 'milestones' !== $name ) {
		return $rows;
	}
	$have = array();
	foreach ( $rows as $r ) {
		if ( ! empty( $r['url'] ) ) {
			$have[ untrailingslashit( $r['url'] ) ] = 1;
		}
	}
	foreach ( ogc_pub_news_rows( $year ) as $r ) {
		if ( ! isset( $have[ untrailingslashit( $r['url'] ) ] ) ) {
			$rows[] = $r;
		}
	}
	return $rows;
}, 5, 4 );
