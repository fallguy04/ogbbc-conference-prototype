<?php
/**
 * Sample households and money for 2027 (night-records, Oct 13): local dev sites only (OGC_DEV on a local
 * address, with the seed's samples on). Made-up people, @example.com addresses, 555 phones.
 *
 * What it adds, so Households and Money show the treasurer's spring as it would be:
 *   - 48 households registered Feb 26 – Apr 12, 2027 (R-2027-2001…2048), every way in (online, a
 *     helper, paper, phone), every stay, need boxes and notes to Lodging;
 *   - their payment lines: cards paid and pending, checks to come and received (one short, one returned,
 *     one over), two districts' checks (Mill Creek's received for two households, Pine Grove's still to
 *     come for three: the walk-through's "one check for several households"), pay at check-in, refunds
 *     asked, approved, sent and declined, two waiting, two cancelled;
 *   - two bank deposits (Mar 22, and Apr 5 off by $20), the checks after them not deposited yet;
 *   - the 12 seed households priced, if this site's seed was loaded before they were.
 * Seen as of a date after they registered (?as-of=2027-04-15): a sample dated later isn't counted.
 *
 * When: whenever the seed loads 2027 (a new site, tools/wp-local.sh reset, Start over, POST /dev/import,
 * which first takes out the old samples), or on demand: POST /wp-json/ogc/v1/dev/records-samples as a
 * webmaster, which takes out the samples already there (and their payment lines) and makes them again.
 * Never by itself on a site already running (other areas' copies keep their numbers).
 */

defined( 'ABSPATH' ) || exit;

/** May this site have the samples? OGC_DEV, a local address, and the seed's samples on. */
function ogc_rec_dev_on() {
	return OGC_DEV && function_exists( 'ogc_is_local_host' ) && ogc_is_local_host() && ( ! function_exists( 'ogc_seed_samples' ) || ogc_seed_samples() );
}

add_action( 'ogc_seed_year', function ( $year ) {
	if ( 2027 === (int) $year && ogc_rec_dev_on() ) {
		ogc_rec_dev_samples( 2027 );
	}
}, 40 );

/**
 * The households, one line each:
 *   surname · adults (First|First) · others (Name:kind:age[:hall], comma) · stay · nights · options ·
 *   source · pay · what happened to the money · the day it was registered (MM-DD)
 * nights: all (Fri–Tue), fm (Fri–Mon), st (Sat–Tue), sm (Sat–Mon). options: ground, walker, restroom,
 * own (linens), mat, gift=N, late (arrives after 9 PM), rooms=N, note=words.
 */
function ogc_rec_dev_spec() {
	return array(
		array( 'Ackerman', 'Levi|Ruth', '', 'dorm', 'all', 'ground', 'online', 'card', 'card', '02-26' ),
		array( 'Bauman', 'Daniel|Esther', 'Joel:child:12,Anna:child:8', 'dorm', 'all', 'rooms=2', 'online', 'check', 'check_got:1042:9', '02-26' ),
		array( 'Brubaker', 'Aaron|Lois', 'Seth:yf:19:men,Grace:yf:17:women', 'dorm', 'all', 'gift=25', 'online', 'card', 'card', '02-27' ),
		array( 'Christner', 'Paul|Edna', '', 'dorm', 'fm', 'walker,note=Paul uses a walker · Near the elevator if there is one', 'helper', 'check', 'grpA', '02-27' ),
		array( 'Drescher', 'Mark|Julia', 'Ben:child:6,Clara:child:2', 'dorm', 'all', 'rooms=2,mat', 'online', 'card', 'refund_req', '02-28' ),
		array( 'Ebersole', 'Henry', '', 'camper', 'all', '', 'online', 'check', 'check', '03-01' ),
		array( 'Fahnestock', 'Isaac|Martha', 'Luke:yf:18:men', 'dorm', 'st', '', 'online', 'card', 'card', '03-01' ),
		array( 'Gehret', 'Philip|Sarah', 'Ruth:child:11,Amos:child:9,Leah:child:4', 'dorm', 'all', 'rooms=2,restroom', 'online', 'check', 'check_got:2271:12', '03-02' ),
		array( 'Habecker', 'Elam|Mary', '', 'elsewhere', 'sat-mon', '', 'online', 'card', 'none', '03-02' ),
		array( 'Heisey', 'Jacob|Anna', 'Micah:child:13', 'dorm', 'all', 'note=Would like to be near the Bowman household', 'helper', 'check', 'grpA', '03-03' ),
		array( 'Hostetler', 'Simon|Rachel', '', 'dorm', 'fm', 'ground,restroom', 'paper', 'checkin', 'checkin', '03-03' ),
		array( 'Kline', 'Nathan|Joy', 'Eli:child:7', 'dorm', 'all', '', 'online', 'card', 'card_due', '03-04' ),
		array( 'Lapp', 'Amos|Lydia', 'Hannah:yf:16:women', 'dorm', 'all', '', 'online', 'check', 'check', '03-05' ),
		array( 'Lehman', 'Peter|Naomi', '', 'camper', 'all', '', 'online', 'card', 'card', '03-05' ),
		array( 'Lutz', 'Owen|Faith', 'Jonas:child:5', 'dorm', 'all', 'own', 'online', 'check', 'check_short:30000:3318:16', '03-06' ),
		array( 'Martz', 'Caleb|Sharon', '', 'dorm', 'all', '', 'online', 'card', 'refund_appr', '03-07' ),
		array( 'Myer', 'Joseph|Ellen', 'Ruth:child:10,Abe:child:3', 'dorm', 'all', 'rooms=2', 'online', 'check', 'check_got:5120:10', '03-08' ),
		array( 'Oberly', 'Thomas|Alma', '', 'dorm', 'all', 'ground,walker,note=Alma uses a wheelchair', 'phone', 'checkin', 'checkin', '03-08' ),
		array( 'Plank', 'David|Irene', '', 'dorm', 'all', '', 'online', 'card', 'cancel_sent', '03-09' ),
		array( 'Rissler', 'Andrew|Joanna', 'Mark:yf:20:men', 'dorm', 'all', 'gift=50', 'online', 'card', 'card', '03-09' ),
		array( 'Sollenberger', 'Ezra|Miriam', '', 'dorm', 'fm', '', 'online', 'check', 'check_ret:6012:15', '03-10' ),
		array( 'Swartz', 'Moses|Ada', 'Paul:child:8,Abby:child:6', 'dorm', 'all', 'rooms=2,late,note=Arriving after 9 PM Friday', 'online', 'card', 'card', '03-11' ),
		array( 'Thomas', 'Ray|Evelyn', '', 'elsewhere', 'fri-tue', '', 'online', 'card', 'none', '03-12' ),
		array( 'Unger', 'Samuel|Vera', '', 'dorm', 'all', 'restroom', 'online', 'check', 'grpB', '03-12' ),
		array( 'Wagner', 'Harold|Betty', '', 'dorm', 'all', 'ground', 'helper', 'check', 'grpB', '03-13' ),
		array( 'Weber', 'Carl|Dorothy', 'Jesse:yf:17:men', 'dorm', 'all', '', 'helper', 'check', 'grpB', '03-13' ),
		array( 'Wolgemuth', 'Ivan|Lena', '', 'dorm', 'all', '', 'online', 'card', 'refund_decl', '03-14' ),
		array( 'Bair', 'Abram|Susan', 'Lucy:child:12', 'dorm', 'all', '', 'online', 'check', 'check_over:2000:4410:9', '03-15' ),
		array( 'Beiler', 'Dale|Kathryn', '', 'camper', 'fm', '', 'paper', 'checkin', 'checkin', '03-16' ),
		array( 'Bowman', 'Wayne|Nancy', 'Ella:child:9', 'dorm', 'all', 'note=Would like to be near the Heisey household', 'online', 'check', 'check_got:7735:8', '03-17' ),
		array( 'Burkhart', 'Glen|Rhoda', '', 'dorm', 'all', '', 'online', 'card', 'card', '03-18' ),
		array( 'Dourte', 'Allen|Mae', '', 'dorm', 'all', '', 'online', 'check', 'check', '03-19' ),
		array( 'Eberly', 'Roy|Ella', 'Tim:yf:18:men,Joy:yf:16:women', 'dorm', 'all', '', 'online', 'card', 'card', '03-20' ),
		array( 'Engle', 'Ira|Fern', '', 'dorm', 'st', '', 'online', 'card', 'waitlist', '03-21' ),
		array( 'Frantz', 'Earl|Doris', 'Kay:child:7', 'dorm', 'all', 'own', 'online', 'check', 'check_got:8890:6', '03-22' ),
		array( 'Garman', 'Ernest|Lillian', '', 'dorm', 'fm', 'walker', 'online', 'card', 'card', '03-23' ),
		array( 'Good', 'Lester|Arlene', 'Nora:child:11,Ben:child:9', 'dorm', 'all', 'rooms=2', 'online', 'check', 'check', '03-24' ),
		array( 'Hurst', 'Melvin|Jean', '', 'dorm', 'all', '', 'online', 'card', 'cancel_req', '03-25' ),
		array( 'Kuhns', 'Clair|Verna', '', 'camper', 'all', 'note=Bringing a second camper for our son', 'online', 'card', 'card', '03-26' ),
		array( 'Landes', 'Jay|Marie', '', 'dorm', 'all', '', 'online', 'check', 'check_got:9104:5', '03-28' ),
		array( 'Mast', 'Roman|Ida', 'Levi:child:4', 'dorm', 'all', 'ground', 'phone', 'checkin', 'checkin', '03-29' ),
		array( 'Moyer', 'Floyd|Ann', '', 'dorm', 'sm', '', 'online', 'card', 'card_none', '03-30' ),
		array( 'Ober', 'Leon|Grace', 'Ruth:yf:17:women', 'dorm', 'all', '', 'online', 'check', 'check', '04-01' ),
		array( 'Rudy', 'Elmer|Viola', '', 'dorm', 'all', 'restroom', 'paper', 'check', 'check', '04-02' ),
		array( 'Shirk', 'Ruth', 'Esther Shirk:yf:16:women', 'dorm', 'all', '', 'online', 'card', 'card', '04-04' ),
		array( 'Zeiset', 'Harvey|Edith', '', 'dorm', 'all', '', 'online', 'check', 'check', '04-06' ),
		array( 'Bowers', 'Kenneth|Lois', '', 'dorm', 'fm', '', 'online', 'card', 'waitlist', '04-09' ),
		array( 'Garber', 'Paul|Jane', 'Sam:child:10', 'dorm', 'all', '', 'online', 'check', 'check_got:9302:2', '04-12' ),
	);
}

/**
 * Make the samples (once per seed of the year). $fresh: take out the ones already here first (their
 * payment lines, Didn't come and notes on them, the undo and receipt lists), so the samples on a site
 * seeded before a change are made again as the code makes them now.
 */
function ogc_rec_dev_samples( $year, $fresh = false ) {
	global $wpdb;
	$year = (int) $year;
	if ( ! function_exists( 'ogc_reg_clean' ) || ! function_exists( 'ogc_pay_add' ) ) {
		return 0;
	}
	$here = array();
	foreach ( ogc_records_all_for_dev( $year ) as $r ) {
		if ( ! empty( $r['data']['sample_set'] ) && 'records' === $r['data']['sample_set'] ) {
			$here[ (int) $r['id'] ] = isset( $r['data']['rid'] ) ? (string) $r['data']['rid'] : '';
		}
	}
	if ( $here && ! $fresh ) {
		return 0;   // already here (a site seeded since): nothing to do
	}
	foreach ( $here as $id => $rid ) {
		$wpdb->delete( ogc_table( 'payments' ), array( 'record_id' => $id ), array( '%d' ) );
		$wpdb->delete( ogc_table( 'records' ), array( 'id' => $id ), array( '%d' ) );
	}
	if ( $here ) {
		foreach ( array( 'reg_marks', 'reg_notes' ) as $k ) {
			$cur = ogc_state_get( $year, $k );
			if ( $cur && is_array( $cur['value'] ) ) {
				ogc_state_put( $year, $k, (object) array_diff_key( $cur['value'], array_flip( array_filter( $here ) ) ) );
			}
		}
		foreach ( array( 'ledger_undo', 'ledger_receipts' ) as $k ) {
			if ( ogc_state_get( $year, $k ) ) {
				ogc_state_put( $year, $k, 'ledger_undo' === $k ? array() : (object) array() );
			}
		}
	}
	$prev = get_current_user_id();
	$who  = get_user_by( 'email', 'miriam.keller@example.com' );
	wp_set_current_user( $who ? $who->ID : 0 );
	ogc_rec_dev_make_true( $year );
	$wpdb->query( $wpdb->prepare( 'DELETE FROM ' . ogc_table( 'deposits' ) . ' WHERE year = %d AND sample = 1', $year ) );
	$cfg    = ogc_reg_cfg( $year );
	$all    = function_exists( 'ogc_reg_main_nights' ) ? ogc_reg_main_nights( $cfg ) : array( 'Friday', 'Saturday', 'Sunday', 'Monday', 'Tuesday' );
	$days   = function_exists( 'ogc_reg_days' ) ? ogc_reg_days( $year ) : array();
	$spans  = array( 'all' => $all, 'fm' => array_slice( $all, 0, 4 ), 'st' => array_slice( $all, 1 ), 'sm' => array_slice( $all, 1, 3 ) );
	$made   = 0;
	$paidat = array();   // line id => day received (for the deposits)
	$grpA   = 'gmillcreek01';
	foreach ( ogc_rec_dev_spec() as $i => $s ) {
		list( $sur, $adults, $others, $stay, $nights, $opts, $source, $pay, $money, $md ) = $s;
		$date  = $year . '-' . $md;
		$o     = array();
		foreach ( array_filter( explode( ',', $opts ) ) as $x ) {
			$kv          = explode( '=', $x, 2 );
			$o[ $kv[0] ] = isset( $kv[1] ) ? $kv[1] : true;
		}
		$people = array();
		foreach ( array_filter( explode( '|', $adults ) ) as $a ) {
			$people[] = array( 'name' => $a . ' ' . $sur, 'kind' => 'adult', 'communing' => true );
		}
		foreach ( array_filter( explode( ',', $others ) ) as $x ) {
			$p    = explode( ':', $x );
			$name = false === strpos( $p[0], ' ' ) ? $p[0] . ' ' . $sur : $p[0];
			$people[] = array( 'name' => $name, 'kind' => $p[1], 'age' => $p[2], 'yfHall' => isset( $p[3] ) ? $p[3] : '', 'sleeps' => 'hall', 'communing' => 'yf' === $p[1] && (int) $p[2] >= 18, 'linens' => 'yf' === $p[1] );
		}
		$first  = strtok( $adults, '|' );
		$email  = strtolower( $first . '.' . $sur ) . '@example.com';
		$helper = 'helper' === $source;
		$in     = array(
			'household' => array( 'name' => $sur, 'contact' => $first . ' ' . $sur, 'phone' => '555-03' . str_pad( (string) ( $i + 1 ), 2, '0', STR_PAD_LEFT ), 'email' => in_array( $source, array( 'paper', 'phone' ), true ) && 0 === $i % 2 ? '' : $email ),
			'helper'    => $helper ? array( 'on' => true, 'name' => 'Ruth Garman', 'phone' => '555-0390', 'email' => 'ruth.garman@example.com' ) : array( 'on' => false ),
			'people'    => $people,
			// The form asks an emergency contact when preteens come (ogc_reg_clean keeps it only then);
			// without one a sample household couldn't be saved by the COA (integration, Oct 14).
			'contacts'  => array( array( 'name' => 'Lydia Weaver', 'rel' => 'Neighbor', 'phone' => '555-04' . str_pad( (string) ( $i + 1 ), 2, '0', STR_PAD_LEFT ) ) ),
			'stay'      => array(
				'type'        => $stay,
				'nights'      => 'elsewhere' === $stay ? array() : $spans[ $nights ],
				'days'        => 'elsewhere' === $stay ? array_slice( wp_list_pluck( $days, 'date' ), 'sat-mon' === $nights ? 1 : 0, 'sat-mon' === $nights ? 3 : 5 ) : array(),
				'rooms'       => isset( $o['rooms'] ) ? (int) $o['rooms'] : 1,
				'roomsSet'    => true,
				'linenChoice' => isset( $o['own'] ) ? 'own' : 'order',
				'linens'      => isset( $o['own'] ) ? 0 : max( 1, count( $people ) - count( array_filter( $people, function ( $p ) { return 'yf' === $p['kind']; } ) ) ),
				'mattresses'  => isset( $o['mat'] ) ? 1 : 0,
				'ground'      => isset( $o['ground'] ),
				'walker'      => isset( $o['walker'] ),
				'nearW'       => isset( $o['restroom'] ),
				'arrive'      => isset( $o['late'] ) ? 'late' : '',
				'needs'       => isset( $o['note'] ) ? $o['note'] : '',
				'campers'     => 'camper' === $stay ? 1 : 0,
				'camperLen'   => 'camper' === $stay ? 'mid' : '',
				'yfOk'        => true,
			),
			'pay'       => $pay,
			'gift'      => isset( $o['gift'] ) ? (int) $o['gift'] : 0,
			'meals'     => array( 'off' => array(), 'who' => array() ),
		);
		// Leaving early (a refund asked or approved): the registration lost its last nights after it was
		// paid in full, so the refund is the difference, as the form's Leave early works it out.
		$m0   = strtok( $money, ':' );
		$drop = in_array( $m0, array( 'refund_req', 'refund_decl' ), true ) ? 1 : ( 'refund_appr' === $m0 ? 2 : 0 );
		$full = 0;
		$gone = array();
		if ( $drop ) {
			$full                   = (int) ogc_reg_price( ogc_reg_clean( $in, $year ), $year )['total_cents'];
			$gone                   = array_slice( $in['stay']['nights'], -$drop );
			$in['stay']['nights']   = array_slice( $in['stay']['nights'], 0, -$drop );
		}
		$data               = ogc_reg_clean( $in, $year );
		$rid                = 'R-' . $year . '-' . ( 2001 + $i );
		$data['rid']        = $rid;
		$data['id']         = $rid;
		$data['sample']     = true;
		$data['sample_set'] = 'records';
		$data['source']     = $helper ? 'online' : $source;
		$data['at']         = $date;
		$data['created']    = $date . ' 15:00:00';
		$data['price']      = array_merge( ogc_reg_price( $data, $year ), array( 'prices' => ogc_reg_price_snapshot( $cfg ), 'at' => $date ) );
		$data['status']     = 'waitlist' === $money ? 'waitlist' : ( 0 === strpos( $money, 'cancel_' ) ? 'cancelled' : 'registered' );
		$data['managers']   = $helper ? array( 'ruth.garman@example.com' ) : array();
		$data['history']    = array();
		if ( 'cancelled' === $data['status'] ) {
			$data['cancelled_at'] = $year . '-04-08 14:00:00';
		}
		$rec_id = ogc_record_insert( $year, 'registrations', $data, $in['household']['email'] ? $in['household']['email'] : ( $helper ? 'ruth.garman@example.com' : '' ), true, 'seed' );
		$rec    = ogc_record_get( $rec_id );
		if ( ! $rec ) {
			continue;
		}
		$made++;
		$total = (int) $data['price']['total_cents'];
		$at    = $date . ' 15:00:00';
		$plus  = function ( $n ) use ( $date ) { return gmdate( 'Y-m-d', strtotime( $date . ' 12:00 UTC' ) + $n * DAY_IN_SECONDS ); };
		$hist  = function ( $day, $what ) use ( &$data ) { $data['history'][] = array( 'at' => $day . ' 16:00:00', 'what' => $what, 'by' => 'committee' ); };
		$m     = explode( ':', $money );
		switch ( $m[0] ) {
			case 'card':
				ogc_pay_add( $rec, 'charge', 'card', $total, 'paid', array( 'at' => $at, 'driver' => 'test', 'day' => $date ) );
				break;
			case 'card_due':
				ogc_pay_add( $rec, 'charge', 'card', $total, 'pending', array( 'at' => $at, 'driver' => 'test' ) );
				break;
			case 'card_none':
			case 'none':
			case 'waitlist':
			case 'checkin':
				break;
			case 'check':
			case 'grpB':
				ogc_pay_add( $rec, 'check', 'check', $total, 'pending', array( 'at' => $at ) );
				break;
			case 'check_got':
			case 'check_ret':
			case 'check_over':
			case 'check_short':
				$ref   = 'check_short' === $m[0] ? $m[2] : $m[1];
				$after = (int) ( 'check_short' === $m[0] ? $m[3] : ( 'check_over' === $m[0] ? $m[3] : $m[2] ) );
				$got   = 'check_short' === $m[0] ? (int) $m[1] : ( 'check_over' === $m[0] ? $total + (int) $m[1] : $total );
				$day   = $plus( $after );
				$id    = ogc_pay_add( $rec, 'check', 'check', $got, 'check_ret' === $m[0] ? 'returned' : 'paid', array( 'at' => $at, 'ref' => $ref, 'day' => $day ) );
				$paidat[ $id ] = $day;
				// History in the plain words the ledger writes (amounts and numbers stay on the line).
				$hist( $day, 'Payment recorded' );
				if ( 'check_ret' === $m[0] ) {
					$hist( $plus( $after + 6 ), 'Payment changed' );
				}
				break;
			case 'grpA':
				$day = $year . '-03-18';
				$id  = ogc_pay_add( $rec, 'check', 'check', $total, 'paid', array( 'at' => $at, 'ref' => '1187', 'day' => $day, 'paid_by' => 'Mill Creek district', 'grp' => $grpA ) );
				$paidat[ $id ] = $day;
				$hist( $day, 'Payment recorded' );
				break;
			case 'refund_req':
			case 'refund_appr':
			case 'refund_decl':
				ogc_pay_add( $rec, 'charge', 'card', $full, 'paid', array( 'at' => $at, 'driver' => 'test', 'day' => $date ) );
				$back = $full - $total;
				$note = 'Nights not used · ' . implode( ', ', array_map( 'ogc_rec_night_short', $gone ) );
				$rst  = array( 'refund_req' => 'requested', 'refund_appr' => 'approved', 'refund_decl' => 'cancelled' );
				ogc_pay_add( $rec, 'refund', 'card', $back, $rst[ $m[0] ], array( 'at' => $year . '-04-10 14:00:00', 'note' => $note, 'day' => 'refund_decl' === $m[0] ? $year . '-04-11' : '' ) );
				$hist( $year . '-04-10', 'Leaving early · ' . $note );
				$hist( $year . '-04-10', 'Refund asked' );
				if ( 'refund_decl' === $m[0] ) {
					$hist( $year . '-04-11', 'Refund declined' );
				}
				break;
			case 'cancel_req':
			case 'cancel_sent':
				ogc_pay_add( $rec, 'charge', 'card', $total, 'paid', array( 'at' => $at, 'driver' => 'test', 'day' => $date ) );
				$refund = $total - (int) $data['price']['gift_cents'];
				ogc_pay_add( $rec, 'refund', 'card', $refund, 'cancel_sent' === $m[0] ? 'sent' : 'requested', array( 'at' => $year . '-04-08 14:00:00', 'note' => 'Cancelled', 'ref' => 'cancel_sent' === $m[0] ? 're_4471' : '', 'day' => 'cancel_sent' === $m[0] ? $year . '-04-11' : '' ) );
				$hist( $year . '-04-08', 'Cancelled · Refund asked' );
				if ( 'cancel_sent' === $m[0] ) {
					$hist( $year . '-04-11', 'Refund sent' );
				}
				break;
		}
		ogc_reg_save( $rec, $data );
	}
	// The deposits: Mar 22 (the checks received by then; the bank agreed), Apr 5 (the next ones; off by
	// $20, to check). The checks after Apr 5 aren't deposited yet.
	$deps = array( array( $year . '-03-22', $year . '-03-21', 0 ), array( $year . '-04-05', $year . '-04-04', -2000 ) );
	$from = '';
	foreach ( $deps as $d ) {
		$ids = array();
		$sum = 0;
		foreach ( $paidat as $id => $day ) {
			$p = ogc_pay_get( $id );
			if ( $p && 'paid' === $p['status'] && $day > $from && $day <= $d[1] ) {
				$ids[] = $id;
				$sum  += $p['cents'];
			}
		}
		$from = $d[1];
		if ( ! $ids ) {
			continue;
		}
		$wpdb->insert( ogc_table( 'deposits' ), array( 'year' => $year, 'day' => $d[0], 'kind' => 'checks', 'bank_cents' => $sum + $d[2], 'note' => '', 'sample' => 1, 'by_user' => get_current_user_id(), 'created_at' => $d[0] . ' 15:00:00', 'updated_at' => $d[0] . ' 15:00:00' ), array( '%d', '%s', '%s', '%d', '%s', '%d', '%d', '%s', '%s' ) );
		$dep = (int) $wpdb->insert_id;
		foreach ( $ids as $id ) {
			ogc_pay_set( $id, array( 'deposit_id' => $dep ) );
		}
	}
	// The COA's treasurer for the walk-through: Miriam K. handles money (the COA's tick on Members).
	if ( ! ogc_state_get( $year, 'payment_viewers' ) ) {
		ogc_state_put( $year, 'payment_viewers', array( 'miriam.keller@example.com' ) );
	}
	wp_set_current_user( $prev );
	ogc_log( 'records_samples', $year, 'registrations', array( 'n' => $made ) );
	return $made;
}

/*
 * The walk-through's household (Round 3, Oct 17): the made-up Hoovers, the form's sample family (they
 * came in 2026 and saved it for next year). In 2027 they registered on Mar 12, paid by two checks,
 * signed up for three shifts from their household's pills (each place keeps their registration number,
 * as the volunteer page now keeps it at join), and Lodging placed them in two rooms side by side. So
 * COA › Households › Hoovers shows every Linked line: Rooms · 2, Payments · 2, Shifts · 3.
 * Dated Mar 12 on: the Tour's Mar 2 scene (the form starts filled in from 2026) is as it was, and so is
 * tools/e2e.mjs part c (the Hoovers register as of Mar 1). Made once, when they aren't there: on 2027's
 * seed (Start over) and once on a site seeded before (the main site).
 */
function ogc_rec_dev_hoovers() {
	global $wpdb;
	$year = 2027;
	if ( ! ogc_rec_dev_on() || ! function_exists( 'ogc_reg_clean' ) || ! function_exists( 'ogc_pay_add' ) || ! function_exists( 'ogc_lod_put' ) || ! function_exists( 'ogc_vol_shifts' ) || ! ogc_year_get( $year ) ) {
		return false;
	}
	$rid  = 'R-2027-2049';
	$have = false;
	foreach ( ogc_records_all_for_dev( $year ) as $r ) {
		$have = $have || ( isset( $r['data']['rid'] ) && $rid === $r['data']['rid'] );
	}
	$shifts = ogc_vol_shifts( $year, true );
	$halls  = function_exists( 'ogc_lod_rooms' ) ? ogc_lod_rooms( $year ) : array();
	if ( ! $shifts || ! $halls ) {
		return false; // The year's files aren't in yet: the next request tries again.
	}
	$email = 'daniel.hoover@example.com';
	$prev  = get_current_user_id();
	if ( ! $have && ! ogc_rec_dev_hoovers_make( $year, $rid, $email, $halls ) ) {
		return false;
	}
	// Three shifts from their household's pills: Daniel twice, Esther once (Daniel signed her up, so she's
	// off the public list until shown). Shifts with room and no rule, on different days; each one only if
	// it isn't there yet.
	$t    = ogc_table( 'vol_seats' );
	$used = array();
	$held = array();
	foreach ( (array) $wpdb->get_results( $wpdb->prepare( 'SELECT data FROM ' . ogc_table( 'records' ) . " WHERE year = %d AND kind = 'signups' AND email = %s AND deleted_at IS NULL", $year, $email ), ARRAY_A ) as $row ) {
		$sd = (array) ogc_unjson( $row['data'], array() );
		if ( isset( $sd['reg'], $sd['id'], $shifts[ $sd['id'] ] ) && $rid === $sd['reg'] ) {
			$held[ $sd['name'] . '|' . $shifts[ $sd['id'] ]['committee'] ] = true;
			$used[] = $shifts[ $sd['id'] ]['date'];
		}
	}
	foreach ( array( array( 'Daniel Hoover', 'Ushers' ), array( 'Daniel Hoover', 'Lodging' ), array( 'Esther Hoover', 'Food' ) ) as $w ) {
		if ( isset( $held[ $w[0] . '|' . $w[1] ] ) ) {
			continue;
		}
		foreach ( $shifts as $id => $sh ) {
			if ( $sh['committee'] !== $w[1] || ! empty( $sh['allweek'] ) || ! empty( $sh['rule'] ) || ! empty( $sh['screening'] ) || ! empty( $sh['min_age'] ) || in_array( $sh['date'], $used, true ) ) {
				continue;
			}
			$n = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $t WHERE year = %d AND shift = %s", $year, $id ) );
			if ( ! $sh['unlimited'] && $n > (int) $sh['needed'] - 3 ) {
				continue;
			}
			$sd = array( 'id' => $id, 'name' => $w[0], 'phone' => '765-555-0142', 'email' => $email, 'confirmed' => true, 'by' => 'self', 'at' => $year . '-03-20T15:00:00+00:00', 'hide' => false, 'next_year' => false, 'reg' => $rid, 'sample' => true );
			if ( 'Daniel Hoover' !== $w[0] ) {
				$sd['for'] = true;
			}
			$sid = ogc_record_insert( $year, 'signups', $sd, $email, true, 'seed' );
			$max = (int) $wpdb->get_var( $wpdb->prepare( "SELECT MAX(seat_no) FROM $t WHERE year = %d AND shift = %s", $year, $id ) );
			$wpdb->insert( $t, array( 'year' => $year, 'shift' => $id, 'seat_no' => $max + 1, 'pkey' => ogc_vol_pkey( $email, $w[0] ), 'record_id' => $sid, 'created_at' => ogc_now() ), array( '%d', '%s', '%d', '%s', '%d', '%s' ) );
			$used[] = $sh['date'];
			break;
		}
	}
	wp_set_current_user( $prev );
	return true;
}

/** The Hoovers' registration, its two checks and Lodging's two rooms (ogc_rec_dev_hoovers). */
function ogc_rec_dev_hoovers_make( $year, $rid, $email, $halls ) {
	$cfg   = ogc_reg_cfg( $year );
	$all   = function_exists( 'ogc_reg_main_nights' ) ? ogc_reg_main_nights( $cfg ) : array( 'Friday', 'Saturday', 'Sunday', 'Monday', 'Tuesday' );
	$in    = array(
		'household' => array( 'name' => 'Hoover', 'contact' => 'Daniel Hoover', 'phone' => '765-555-0142', 'email' => $email ),
		'helper'    => array( 'on' => false ),
		'people'    => array(
			array( 'name' => 'Daniel Hoover', 'kind' => 'adult', 'communing' => true ),
			array( 'name' => 'Esther Hoover', 'kind' => 'adult', 'communing' => true ),
			array( 'name' => 'Samuel Hoover', 'kind' => 'yf', 'age' => '17', 'yfHall' => 'men', 'sleeps' => 'hall', 'linens' => true ),
			array( 'name' => 'Lydia Hoover', 'kind' => 'child', 'age' => '10' ),
			array( 'name' => 'Micah Hoover', 'kind' => 'child', 'age' => '6' ),
			array( 'name' => 'Anna Hoover', 'kind' => 'child', 'age' => '1' ),
		),
		'contacts'  => array( array( 'name' => 'Ruth Miller', 'rel' => 'Aunt', 'phone' => '765-555-0177' ) ),
		'stay'      => array( 'type' => 'dorm', 'nights' => $all, 'days' => array(), 'rooms' => 2, 'roomsSet' => true, 'linenChoice' => 'order', 'linens' => 3, 'mattresses' => 1, 'keys' => array( 'Daniel Hoover', 'Esther Hoover' ), 'needs' => 'Anna is one · A crib if there is one', 'yfOk' => true ),
		'pay'       => 'check',
		'gift'      => 0,
		'meals'     => array( 'off' => array(), 'who' => array() ),
	);
	$who  = get_user_by( 'email', 'miriam.keller@example.com' );
	wp_set_current_user( $who ? $who->ID : 0 );
	$data               = ogc_reg_clean( $in, $year );
	$data['rid']        = $rid;
	$data['id']         = $rid;
	$data['sample']     = true;
	$data['sample_set'] = 'walkthrough';
	$data['source']     = 'online';
	$data['at']         = $year . '-03-12';
	$data['created']    = $year . '-03-12 15:00:00';
	$data['price']      = array_merge( ogc_reg_price( $data, $year ), array( 'prices' => ogc_reg_price_snapshot( $cfg ), 'at' => $year . '-03-12' ) );
	$data['status']     = 'registered';
	$data['managers']   = array();
	$data['history']    = array();
	$rec_id = ogc_record_insert( $year, 'registrations', $data, $email, true, 'seed' );
	$rec    = ogc_record_get( $rec_id );
	if ( ! $rec ) {
		return false;
	}
	// Two checks: a first one with the form, the rest in April. Paid.
	$total = (int) $data['price']['total_cents'];
	$first = max( 100, (int) ( round( $total / 2 / 10000 ) * 10000 ) );
	$first = min( $first, max( 100, $total - 100 ) );
	foreach ( array( array( $first, '2051', $year . '-03-20' ), array( $total - $first, '2064', $year . '-04-22' ) ) as $c ) {
		ogc_pay_add( $rec, 'check', 'check', $c[0], 'paid', array( 'at' => $year . '-03-12 15:00:00', 'ref' => $c[1], 'day' => $c[2] ) );
		$data['history'][] = array( 'at' => $c[2] . ' 16:00:00', 'what' => 'Payment recorded', 'by' => 'committee' );
	}
	ogc_reg_save( $rec, $data );
	// Lodging placed them by hand on Apr 14: the first two family rooms side by side that no one has.
	$taken = array();
	foreach ( ogc_lod_rows( $year, 'hh:' ) as $row ) {
		foreach ( (array) ( isset( $row['data']['rooms'] ) ? $row['data']['rooms'] : array() ) as $id ) {
			$taken[ (string) $id ] = true;
		}
	}
	$pair = array();
	foreach ( $halls as $id => $room ) {
		$next = $room['hall'] . '|' . ( $room['num'] + 1 );
		if ( 'families' === $room['for'] && 1 === $room['num'] % 2 && isset( $halls[ $next ] ) && ! isset( $taken[ $id ] ) && ! isset( $taken[ $next ] ) ) {
			$pair = array( $id, $next );
			break;
		}
	}
	if ( $pair ) {
		ogc_lod_put( $year, 'hh:' . $rid, array( 'rooms' => $pair, 'given' => array( 'by' => 'Ada T.', 'at' => $year . '-04-14 15:00:00' ), 'snap' => ogc_lod_snap( $data ) ) );
	}
	ogc_log( 'records_samples', $year, 'registrations', array( 'n' => 1 ) );
	return true;
}
// Once on a local site seeded before (the main site), and again after 2027's seed reloads (Start over).
add_action( 'init', function () {
	if ( OGC_DEV && '2' !== get_option( 'ogc_rec_dev_hoovers' ) && function_exists( 'ogc_app_tables_ready' ) && ogc_app_tables_ready() && ogc_rec_dev_hoovers() ) {
		update_option( 'ogc_rec_dev_hoovers', '2', false );
	}
}, 49 );
add_action( 'ogc_seed_year', function ( $year ) {
	if ( 2027 === (int) $year ) {
		ogc_rec_dev_hoovers();
	}
}, 45 );

/** Every registration record of a year, samples dated later included (the dev builder's own read). */
function ogc_records_all_for_dev( $year ) {
	global $wpdb;
	$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT id, data FROM ' . ogc_table( 'records' ) . " WHERE year = %d AND kind = 'registrations' AND deleted_at IS NULL", $year ), ARRAY_A );
	$out  = array();
	foreach ( (array) $rows as $r ) {
		$out[] = array( 'id' => (int) $r['id'], 'data' => (array) ogc_unjson( $r['data'], array() ) );
	}
	return $out;
}

/** The seed's own sample households in today's shape with a price and a ledger, if this site's seed was
 * loaded before the register area priced them (as its ogc_seed_year hook does on a fresh seed). */
function ogc_rec_dev_make_true( $year ) {
	if ( ! function_exists( 'ogc_reg_from_v3' ) ) {
		return;
	}
	$cfg = ogc_reg_cfg( $year );
	foreach ( ogc_records_all_for_dev( $year ) as $row ) {
		$rec = ogc_record_get( $row['id'] );
		if ( ! $rec || ! $rec['sample'] || ! empty( $rec['data']['price'] ) || ! empty( $rec['data']['sample_set'] ) ) {
			continue;
		}
		$v3              = ogc_reg_from_v3( $rec['data'] );
		$data            = ogc_reg_clean( $v3, $year );
		$data['pay']     = ! empty( $v3['pay'] ) && 'check' === $v3['pay'] ? 'check' : 'card';
		$data['rid']     = $data['id'] = isset( $v3['id'] ) ? $v3['id'] : ogc_reg_next_rid( $year );
		$data['sample']  = true;
		$data['source']  = 'online';
		$data['at']      = isset( $v3['at'] ) ? $v3['at'] : '';
		$data['created'] = $data['at'] ? $data['at'] . ' 12:00:00' : ogc_now();
		$data['price']   = array_merge( ogc_reg_price( $data, $year ), array( 'prices' => ogc_reg_price_snapshot( $cfg ), 'at' => $data['at'] ) );
		$data['status']  = 'registered';
		$data['managers'] = array();
		$data['history'] = array();
		$total           = $data['price']['total_cents'];
		$rec['data']     = $data; // so each line carries its R-number
		if ( $total > 0 ) {
			if ( 'check' === $data['pay'] ) {
				ogc_pay_add( $rec, 'check', 'check', $total, 'pending', array( 'at' => $data['created'] ) );
			} else {
				ogc_pay_add( $rec, 'charge', 'card', $total, 'paid', array( 'at' => $data['created'], 'driver' => 'test', 'day' => $data['at'] ) );
			}
		}
		ogc_reg_save( $rec, $data );
	}
}

/* ------------------------------------------------------------------ a dev route, to make them again */

add_action( 'rest_api_init', function () {
	if ( ! ogc_rec_dev_on() ) {
		return;
	}
	register_rest_route( OGC_NS, '/dev/records-samples', array(
		'methods'             => 'POST',
		'permission_callback' => function () {
			return ogc_is_webmaster() ? true : ogc_rest_denied();
		},
		// Made again from scratch: the old ones (and their lines) out first.
		'callback'            => function () {
			return rest_ensure_response( array( 'made' => ogc_rec_dev_samples( 2027, true ) ) );
		},
	) );
	/*
	 * For testing receipts (a sample never gets one): {make: true} adds one made-up household that isn't
	 * a sample (R-2027-2099, "Tester", receipt-test@example.com, a check to come), or puts its check to
	 * come back as it was;
	 * {send: true} sends every receipt waiting, its wait over or not. Webmasters, local dev sites only.
	 */
	register_rest_route( OGC_NS, '/dev/records-receipts', array(
		'methods'             => 'POST',
		'permission_callback' => function () {
			return ogc_is_webmaster() ? true : ogc_rest_denied();
		},
		'callback'            => function ( WP_REST_Request $req ) {
			$out = array();
			if ( rest_sanitize_boolean( $req->get_param( 'make' ) ) ) {
				global $wpdb;
				$rec = function_exists( 'ogc_rec_by_rid' ) ? ogc_rec_by_rid( 2027, 'R-2027-2099' ) : null;
				if ( $rec ) {
					// Made again: its payment lines out, its check to come back.
					$wpdb->delete( ogc_table( 'payments' ), array( 'record_id' => (int) $rec['id'] ), array( '%d' ) );
					ogc_pay_add( $rec, 'check', 'check', (int) $rec['data']['price']['total_cents'], 'pending', array( 'at' => '2027-03-01 15:00:00' ) );
					$rec = ogc_reg_save( $rec, $rec['data'] );
				} else {
					$data = ogc_reg_clean( array(
						'household' => array( 'name' => 'Tester', 'contact' => 'Tess Tester', 'phone' => '555-0399', 'email' => 'receipt-test@example.com' ),
						'helper'    => array( 'on' => false ),
						'people'    => array( array( 'name' => 'Tess Tester', 'kind' => 'adult', 'communing' => true ) ),
						'stay'      => array( 'type' => 'dorm', 'nights' => array( 'Friday', 'Saturday' ), 'rooms' => 1, 'roomsSet' => true, 'linenChoice' => 'own', 'yfOk' => true ),
						'pay'       => 'check',
						'meals'     => array( 'off' => array(), 'who' => array() ),
					), 2027 );
					$data['rid']     = $data['id'] = 'R-2027-2099';
					$data['source']  = 'online';
					$data['at']      = '2027-03-01';
					$data['created'] = '2027-03-01 15:00:00';
					$data['price']   = array_merge( ogc_reg_price( $data, 2027 ), array( 'at' => '2027-03-01' ) );
					$data['status']  = 'registered';
					$data['history'] = array();
					$id              = ogc_record_insert( 2027, 'registrations', $data, 'receipt-test@example.com', false, 'dev' );
					$rec             = ogc_record_get( $id );
					ogc_pay_add( $rec, 'check', 'check', (int) $data['price']['total_cents'], 'pending', array( 'at' => '2027-03-01 15:00:00' ) );
					$rec = ogc_reg_save( $rec, $data );
				}
				$out['record'] = $rec ? (int) $rec['id'] : 0;
			}
			$w              = ogc_state_get( 2027, 'ledger_receipts' );
			$out['waiting'] = $w && is_array( $w['value'] ) ? count( $w['value'] ) : 0;
			if ( rest_sanitize_boolean( $req->get_param( 'send' ) ) && function_exists( 'ogc_ledger_receipts_due' ) ) {
				$out['sent'] = ogc_ledger_receipts_due( 2027, true );
			}
			return rest_ensure_response( $out );
		},
	) );
} );
