<?php
/**
 * Volunteer shifts: the server's half of /annual-conference/volunteer/ (replacing SignUpGenius).
 *
 * This file: the tables, a year's shifts as the server sees them (the same ids as the pages'
 * SU.expandShifts), who's on each (places, held atomically), the rules, the committees, what the
 * public may see, and the sample volunteers. The routes are in module-volunteer-rest.php (the public
 * page) and module-volunteer-lead.php (committee heads); emails, calendar files and the timed jobs in
 * module-volunteer-mail.php.
 *
 * The rules, all on the server:
 *   - a place is a row in ogc_vol_seats, unique per (year, shift, seat number) and per (year, shift,
 *     person): two people pressing Join for the last place can't both get it, and a double tap
 *     returns the first sign-up;
 *   - a shift must exist, be posted, not closed and not started; a person can't be on two shifts at
 *     once ("Busy"); a shift's rule is answered (and kept with the sign-up);
 *   - the public sees counts and "Ruth K." (or only counts), never an email or a phone.
 */

defined( 'ABSPATH' ) || exit;

/* ================================================================== tables */

add_filter( 'ogc_schema', function ( $sql, $charset ) {
	// One row a place taken on a shift. seat_no runs 1…needed; the two unique keys make taking a place
	// atomic on MySQL and SQLite alike (an insert that loses the race fails, and the next seat is tried).
	$sql[] = 'CREATE TABLE ' . ogc_table( 'vol_seats' ) . " (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  year smallint(5) unsigned NOT NULL,
  shift varchar(160) NOT NULL,
  seat_no int(10) unsigned NOT NULL,
  pkey varchar(190) NOT NULL,
  record_id bigint(20) unsigned NOT NULL DEFAULT 0,
  created_at datetime NULL,
  PRIMARY KEY  (id),
  UNIQUE KEY seat (year,shift,seat_no),
  UNIQUE KEY person (year,shift,pkey),
  KEY record_id (record_id)
) $charset;";
	// Emails waiting to go: a confirmation held for Undo, one per person for a head's message, the
	// reminders. Sent by the timed job (ogc_vol_tick), once each.
	$sql[] = 'CREATE TABLE ' . ogc_table( 'vol_outbox' ) . " (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  year smallint(5) unsigned NOT NULL,
  kind varchar(24) NOT NULL,
  email varchar(190) NOT NULL DEFAULT '',
  payload longtext NOT NULL,
  send_after datetime NULL,
  sent_at datetime NULL,
  created_at datetime NULL,
  PRIMARY KEY  (id),
  KEY due (sent_at,send_after),
  KEY email (email)
) $charset;";
	return $sql;
}, 20, 2 );

/* ================================================================== time */

/** Now, as a Unix time. Locally (OGC_DEV) a test may set another moment (ogc_vol_set_now). */
function ogc_vol_now() {
	return isset( $GLOBALS['ogc_vol_now'] ) ? (int) $GLOBALS['ogc_vol_now'] : time();
}

function ogc_vol_set_now( $ts ) {
	if ( OGC_DEV ) {
		$GLOBALS['ogc_vol_now'] = (int) $ts;
	}
}

/** A year's settings.csv as key → value. */
function ogc_vol_settings( $year ) {
	static $cache = array();
	if ( isset( $cache[ $year ] ) ) {
		return $cache[ $year ];
	}
	$f   = ogc_file_get( $year, 'settings' );
	$out = array();
	foreach ( $f ? $f['rows'] : array() as $r ) {
		if ( isset( $r['key'] ) && '' !== $r['key'] && '#' !== substr( $r['key'], 0, 1 ) ) {
			$out[ $r['key'] ] = isset( $r['value'] ) ? (string) $r['value'] : '';
		}
	}
	return $cache[ $year ] = $out;
}

function ogc_vol_tz( $year ) {
	$s = ogc_vol_settings( $year );
	try {
		return new DateTimeZone( ! empty( $s['timezone'] ) ? $s['timezone'] : 'America/Indiana/Indianapolis' );
	} catch ( Exception $e ) {
		return new DateTimeZone( 'America/Indiana/Indianapolis' );
	}
}

/** The venue's date (Y-m-d) and minutes after midnight at a moment. */
function ogc_vol_wall( $year, $ts = null ) {
	$d = ( new DateTimeImmutable( '@' . ( null === $ts ? ogc_vol_now() : (int) $ts ) ) )->setTimezone( ogc_vol_tz( $year ) );
	return array( 'date' => $d->format( 'Y-m-d' ), 'minutes' => (int) $d->format( 'G' ) * 60 + (int) $d->format( 'i' ) );
}

/** A venue date and minutes (may pass 1440) → a Unix time. */
function ogc_vol_ts( $year, $date, $minutes ) {
	$d = new DateTimeImmutable( $date . ' 00:00:00', ogc_vol_tz( $year ) );
	return $d->modify( '+' . (int) $minutes . ' minutes' )->getTimestamp();
}

/** "7:00 AM", "7 am", "noon", "19:30" → minutes after midnight (as ogc-core.js parseTime). */
function ogc_vol_parse_time( $s ) {
	$t = strtolower( str_replace( '.', '', trim( (string) $s ) ) );
	if ( '' === $t ) {
		return null;
	}
	if ( preg_match( '/^(12(:00)?\s*)?noon$/', $t ) ) {
		return 720;
	}
	if ( preg_match( '/^(12(:00)?\s*)?midnight$/', $t ) ) {
		return 1440;
	}
	if ( ! preg_match( '/^(\d{1,2})(?::(\d{2}))?\s*(am|pm|a|p)?$/', $t, $m ) ) {
		return null;
	}
	$h   = (int) $m[1];
	$min = isset( $m[2] ) && '' !== $m[2] ? (int) $m[2] : 0;
	$ap  = isset( $m[3] ) ? $m[3] : '';
	if ( $min > 59 || $h > 24 ) {
		return null;
	}
	if ( $ap ) {
		if ( 0 === $h || $h > 12 ) {
			return null;
		}
		if ( 'p' === $ap[0] && 12 !== $h ) {
			$h += 12;
		}
		if ( 'a' === $ap[0] && 12 === $h ) {
			$h = 0;
		}
	}
	return $h * 60 + $min;
}

/** "7–11 AM", "11:45 AM–2:15 PM", "10 PM–12 AM": one line, as the page shows it. */
function ogc_vol_span( $start, $end ) {
	$f    = function ( $m, $suffix ) {
		$m  = ( ( $m % 1440 ) + 1440 ) % 1440;
		$h  = intdiv( $m, 60 );
		$mm = $m % 60;
		$ap = $h >= 12 ? 'PM' : 'AM';
		$h  = $h % 12 ?: 12;
		return $h . ( $mm ? ':' . str_pad( (string) $mm, 2, '0', STR_PAD_LEFT ) : '' ) . ( $suffix ? ' ' . $ap : '' );
	};
	$same = intdiv( ( ( $start % 1440 ) + 1440 ) % 1440, 720 ) === intdiv( ( ( $end % 1440 ) + 1440 ) % 1440, 720 );
	return $f( $start, ! $same ) . '–' . $f( $end, true );
}

function ogc_vol_slug( $s ) {
	return trim( preg_replace( '/[^a-z0-9]+/', '_', strtolower( trim( (string) $s ) ) ), '_' );
}

/** The year's days: array( key, name, date ), from settings first_day and days (as ogc-core.js). */
function ogc_vol_days( $year ) {
	$s     = ogc_vol_settings( $year );
	$first = isset( $s['first_day'] ) ? $s['first_day'] : '';
	if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $first ) ) {
		return array();
	}
	$names = array_values( array_filter( array_map( 'trim', explode( '|', ! empty( $s['days'] ) ? $s['days'] : 'Friday|Saturday|Sunday|Monday|Tuesday|Wednesday' ) ), 'strlen' ) );
	$out   = array();
	$d     = new DateTimeImmutable( $first );
	foreach ( $names as $i => $n ) {
		$out[] = array( 'key' => ogc_vol_slug( $n ), 'name' => $n, 'date' => $d->modify( "+$i days" )->format( 'Y-m-d' ) );
	}
	return $out;
}

/** The last day of the Conference: years.csv's end, or the last day in settings. */
function ogc_vol_last_day( $year ) {
	$y = ogc_year_get( $year );
	if ( $y && ! empty( $y['end'] ) ) {
		return $y['end'];
	}
	$days = ogc_vol_days( $year );
	return $days ? $days[ count( $days ) - 1 ]['date'] : '';
}

function ogc_vol_find_day( $days, $v ) {
	$v = strtolower( trim( (string) $v ) );
	if ( '' === $v ) {
		return -1;
	}
	foreach ( $days as $i => $d ) {
		if ( 0 === strpos( strtolower( $d['name'] ), substr( $v, 0, 3 ) ) || $d['date'] === $v ) {
			return $i;
		}
	}
	return -1;
}

/* ================================================================== shifts */

/** A lasting id for a shift row, made from it the first time it's seen (the same row in two years
 * gets the same one, so "same as last year" is plain). */
function ogc_vol_new_uid( $r, $taken ) {
	$base = 's' . substr( md5( strtolower( implode( '|', array( isset( $r['committee'] ) ? $r['committee'] : '', isset( $r['role'] ) ? $r['role'] : '', isset( $r['day'] ) ? $r['day'] : '', isset( $r['start'] ) ? $r['start'] : '' ) ) ) ), 0, 9 );
	$uid  = $base;
	for ( $i = 2; isset( $taken[ $uid ] ); $i++ ) {
		$uid = $base . '-' . $i;
	}
	return $uid;
}

/** Each shifts.csv row keeps a uid through edits, imports and the pickup: one is filled in for a row
 * that has none, and a copied row (Duplicate) gets its own. */
add_filter( 'ogc_file_rows', 'ogc_vol_file_rows', 10, 4 );
function ogc_vol_file_rows( $rows, $year, $name, $cur ) {
	if ( 'shifts' !== $name ) {
		return $rows;
	}
	$taken = array();
	foreach ( $rows as $i => $r ) {
		if ( ! is_array( $r ) || empty( $r['role'] ) ) {
			continue;
		}
		$uid = isset( $r['uid'] ) ? preg_replace( '/[^A-Za-z0-9_-]/', '', (string) $r['uid'] ) : '';
		if ( '' === $uid || isset( $taken[ $uid ] ) ) {
			$uid = ogc_vol_new_uid( $r, $taken );
		}
		$taken[ $uid ]      = true;
		$rows[ $i ]['uid'] = $uid;
	}
	return $rows;
}

/** A rule's minimum age: the min_age column, or "21 or older" / "18+" in its words. */
function ogc_vol_min_age( $r ) {
	if ( isset( $r['min_age'] ) && is_numeric( $r['min_age'] ) && (int) $r['min_age'] > 0 ) {
		return (int) $r['min_age'];
	}
	if ( ! empty( $r['rule'] ) && preg_match( '/\b(\d{1,2})\s*(\+|or older|and older|and up)/i', $r['rule'], $m ) ) {
		return (int) $m[1];
	}
	return 0;
}

/** A rule asked as a choice (First Aid's certification): the question column ("Certified|With a
 * certified partner"), or a rule about being certified. */
function ogc_vol_question( $r ) {
	if ( ! empty( $r['question'] ) ) {
		return array_values( array_filter( array_map( 'trim', explode( '|', $r['question'] ) ), 'strlen' ) );
	}
	if ( ! empty( $r['rule'] ) && preg_match( '/certified/i', $r['rule'] ) && preg_match( '/partner/i', $r['rule'] ) ) {
		return array( 'Certified', 'With a certified partner' );
	}
	return array();
}

/**
 * The year's shifts, one a day, keyed by id (the same ids as SU.expandShifts in the pages):
 *   a row with a uid: the uid for a one-day row, uid|date for each day of a repeating row;
 *   a row without one (an old file): committee|role|day|start, as v3 made them.
 * A repeating row whose last day isn't in the year is cut at the year's last day (never dropped).
 */
function ogc_vol_shifts( $year, $fresh = false ) {
	static $cache = array();
	if ( ! $fresh && isset( $cache[ $year ] ) ) {
		return $cache[ $year ];
	}
	$f    = ogc_file_get( $year, 'shifts' );
	$days = ogc_vol_days( $year );
	$out  = array();
	foreach ( $f ? $f['rows'] : array() as $ri => $r ) {
		if ( empty( $r['role'] ) || empty( $r['day'] ) || 0 === strpos( (string) ( isset( $r['committee'] ) ? $r['committee'] : '' ), '#' ) ) {
			continue;
		}
		$a = ogc_vol_find_day( $days, $r['day'] );
		if ( $a < 0 ) {
			continue;
		}
		$b = ! empty( $r['last_day'] ) ? ogc_vol_find_day( $days, $r['last_day'] ) : $a;
		if ( $b < 0 ) {
			$b = count( $days ) - 1;
		}
		$start = ogc_vol_parse_time( isset( $r['start'] ) ? $r['start'] : '' );
		$end   = ogc_vol_parse_time( isset( $r['end'] ) ? $r['end'] : '' );
		if ( null === $start || null === $end ) {
			continue;
		}
		if ( $end <= $start ) {
			$end += 1440;
		}
		$raw       = isset( $r['needed'] ) ? trim( (string) $r['needed'] ) : '';
		$unlimited = (bool) preg_match( '/^(any|no limit|unlimited|0)$/i', $raw );
		$needed    = $unlimited ? 0 : max( 1, (int) $raw );
		$uid       = isset( $r['uid'] ) ? (string) $r['uid'] : '';
		$places    = ogc_vol_places( $year );
		for ( $i = $a; $i <= $b; $i++ ) {
			$d  = $days[ $i ];
			$id = '' !== $uid
				? ( $a === $b ? $uid : $uid . '|' . $d['date'] )
				: preg_replace( '/[^a-z0-9|]+/', '-', strtolower( implode( '|', array( $r['committee'], $r['role'], $d['key'], $r['start'] ) ) ) );
			$code         = isset( $r['place'] ) ? trim( (string) $r['place'] ) : '';
			$out[ $id ] = array(
				'id'        => $id,
				'uid'       => $uid,
				'row'       => $ri,
				'committee' => (string) $r['committee'],
				'role'      => (string) $r['role'],
				'date'      => $d['date'],
				'day'       => $d['name'],
				'start'     => $start,
				'end'       => $end,
				'needed'    => $needed,
				'unlimited' => $unlimited,
				'place'     => $code,
				'place_name' => '' === $code ? '' : ( isset( $places[ strtoupper( $code ) ] ) ? $places[ strtoupper( $code ) ] : $code ),
				'note'      => isset( $r['note'] ) ? (string) $r['note'] : '',
				'rule'      => isset( $r['rule'] ) ? (string) $r['rule'] : '',
				'min_age'   => ogc_vol_min_age( $r ),
				'question'  => ogc_vol_question( $r ),
				'screening' => ! empty( $r['screening'] ) && preg_match( '/^(y|yes|1|true)$/i', $r['screening'] ),
				'shown'     => isset( $r['shown'] ) && 'committee' === strtolower( trim( $r['shown'] ) ) ? 'committee' : 'public',
				'start_ts'  => ogc_vol_ts( $year, $d['date'], $start ),
				'end_ts'    => ogc_vol_ts( $year, $d['date'], $end ),
			);
		}
	}
	uasort( $out, function ( $x, $y ) {
		return $x['start_ts'] - $y['start_ts'] ?: strcmp( $x['role'], $y['role'] );
	} );
	return $cache[ $year ] = $out;
}

/** The year's place names by code. */
function ogc_vol_places( $year ) {
	static $cache = array();
	if ( isset( $cache[ $year ] ) ) {
		return $cache[ $year ];
	}
	$out = array();
	$f   = ogc_file_get( $year, 'places' );
	foreach ( $f ? $f['rows'] : array() as $p ) {
		if ( ! empty( $p['code'] ) ) {
			$out[ strtoupper( $p['code'] ) ] = ! empty( $p['name'] ) ? $p['name'] : $p['code'];
		}
	}
	return $cache[ $year ] = $out;
}

/** Saturday's 12–2 AM is Friday night: a shift from midnight to 5 AM belongs to the evening before. */
function ogc_vol_when( $year, $sh ) {
	$date = $sh['date'];
	$word = '';
	if ( $sh['start'] < 300 ) {
		$date = gmdate( 'Y-m-d', strtotime( $sh['date'] . ' 00:00:00 UTC' ) - 86400 );
		$word = ' night';
	}
	$day = gmdate( 'D, M j', strtotime( $date . ' 00:00:00 UTC' ) );
	return $day . $word . ' · ' . ogc_vol_span( $sh['start'], $sh['end'] );
}

/* ================================================================== the year's state */

/** Volunteer sign-ups are posted (settings signups_posted is today or before). */
function ogc_vol_posted( $year ) {
	$s = ogc_vol_settings( $year );
	$p = isset( $s['signups_posted'] ) ? trim( $s['signups_posted'] ) : '';
	// No date at all is an older year, posted as it was (as v3); the pickup holds a new year back with
	// 9999-12-31 until the COA publishes.
	if ( '' === $p ) {
		return (bool) ogc_vol_shifts( $year );
	}
	if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $p ) ) {
		return false;
	}
	return $p <= ogc_vol_wall( $year )['date'];
}

/** The day sign-ups open, when the COA has set a real one still ahead ('' otherwise). */
function ogc_vol_opens( $year ) {
	$s = ogc_vol_settings( $year );
	$p = isset( $s['signups_posted'] ) ? trim( $s['signups_posted'] ) : '';
	return preg_match( '/^\d{4}-\d{2}-\d{2}$/', $p ) && '9999-12-31' !== $p && $p > ogc_vol_wall( $year )['date'] ? $p : '';
}

/** The day sign-ups close, when the COA set one (settings signups_close). */
function ogc_vol_close_date( $year ) {
	$s = ogc_vol_settings( $year );
	$c = isset( $s['signups_close'] ) ? trim( $s['signups_close'] ) : '';
	return preg_match( '/^\d{4}-\d{2}-\d{2}$/', $c ) ? $c : '';
}

/** Closed: after the COA's close date, or once the Conference is over. */
function ogc_vol_closed( $year ) {
	$today = ogc_vol_wall( $year )['date'];
	$c     = ogc_vol_close_date( $year );
	$last  = ogc_vol_last_day( $year );
	return ( $c && $today > $c ) || ( $last && $today > $last );
}

/** A shift's state now: open, full, started, ended, closed or not_open. */
function ogc_vol_shift_state( $year, $sh, $filled ) {
	$now = ogc_vol_now();
	if ( ! ogc_vol_posted( $year ) ) {
		return 'not_open';
	}
	if ( $now >= $sh['end_ts'] ) {
		return 'ended';
	}
	if ( $now >= $sh['start_ts'] ) {
		return 'started';
	}
	if ( ogc_vol_closed( $year ) ) {
		return 'closed';
	}
	if ( 'committee' === $sh['shown'] ) {
		return 'committee';
	}
	return ( ! $sh['unlimited'] && $filled >= $sh['needed'] ) ? 'full' : 'open';
}

/* ================================================================== committees */

/** The year's committees (committees.csv, members only): name, contact_email, contact_phone, heads
 * (emails, "|"), weekly (yes/no), order. Every committee with shifts is listed, with or without a row. */
function ogc_vol_committees( $year ) {
	$f    = ogc_file_get( $year, 'committees' );
	$rows = array();
	foreach ( $f ? $f['rows'] : array() as $r ) {
		if ( ! empty( $r['name'] ) ) {
			$rows[ $r['name'] ] = array_merge( array( 'name' => '', 'contact_email' => '', 'contact_phone' => '', 'heads' => '', 'weekly' => 'yes', 'order' => '' ), $r );
		}
	}
	foreach ( ogc_vol_shifts( $year ) as $sh ) {
		if ( ! isset( $rows[ $sh['committee'] ] ) ) {
			$rows[ $sh['committee'] ] = array( 'name' => $sh['committee'], 'contact_email' => '', 'contact_phone' => '', 'heads' => '', 'weekly' => 'yes', 'order' => '' );
		}
	}
	// The COA's order, then by name.
	uasort( $rows, function ( $a, $b ) {
		$oa = '' === (string) $a['order'] ? 999 : (int) $a['order'];
		$ob = '' === (string) $b['order'] ? 999 : (int) $b['order'];
		return $oa - $ob ?: strcasecmp( $a['name'], $b['name'] );
	} );
	return $rows;
}

// The committees' contacts are the COA's, never shown on a public page (the public gets the role
// phone through the volunteer routes).
add_filter( 'ogc_private_files', function ( $names ) {
	$names[] = 'committees';
	return $names;
} );

/** The committees this signed-in person heads (committees.csv heads). */
function ogc_vol_headed( $year ) {
	$me = ogc_current_email();
	if ( ! $me ) {
		return array();
	}
	$out = array();
	foreach ( ogc_vol_committees( $year ) as $c ) {
		$heads = array_map( 'strtolower', array_map( 'trim', explode( '|', (string) $c['heads'] ) ) );
		if ( in_array( $me, $heads, true ) ) {
			$out[] = $c['name'];
		}
	}
	return $out;
}

/** May this person see a committee's list (names and phones)? The year's members see every committee;
 * a committee's own heads see theirs only. */
function ogc_vol_can_lead( $year, $committee = null ) {
	if ( ogc_vol_lead_all( $year ) ) {
		return true;
	}
	// The app (docs/23): a committee's people lead their own committee's shifts, never the rest.
	$mine = array_merge( ogc_vol_headed( $year ), ogc_is_member( $year ) && function_exists( 'ogc_appc_vol_scope' ) ? (array) ogc_appc_vol_scope( $year ) : array() );
	return null === $committee ? (bool) $mine : in_array( $committee, $mine, true );
}

/** May this person see every committee's list? The COA (and, before the app, every member). */
function ogc_vol_lead_all( $year ) {
	return ogc_is_member( $year ) && ( ! function_exists( 'ogc_appc_vol_scope' ) || null === ogc_appc_vol_scope( $year ) );
}

/* ================================================================== who's on a shift */

/** A person on a shift, as the place remembers them: their email and name, or (no email) their name
 * and phone. Spelling and case don't make two people. */
function ogc_vol_pkey( $email, $name, $phone = '' ) {
	$n = strtolower( preg_replace( '/\s+/', ' ', trim( (string) $name ) ) );
	$e = strtolower( trim( (string) $email ) );
	return substr( $e ? $e . '|' . $n : 'nomail|' . $n . '|' . preg_replace( '/\D+/', '', (string) $phone ), 0, 190 );
}

/** The year's live sign-ups (records) by id. */
function ogc_vol_records( $year, $kind = 'signups' ) {
	$out = array();
	foreach ( ogc_records( $year, $kind ) as $r ) {
		$out[ $r['id'] ] = $r;
	}
	return $out;
}

/** The places taken, by shift: shift → list of { seat_no, record } (records that still exist). */
function ogc_vol_seat_map( $year ) {
	global $wpdb;
	$rows = $wpdb->get_results( $wpdb->prepare(
		'SELECT s.shift, s.seat_no, s.record_id FROM ' . ogc_table( 'vol_seats' ) . ' s JOIN ' . ogc_table( 'records' ) . ' r ON r.id = s.record_id AND r.deleted_at IS NULL WHERE s.year = %d ORDER BY s.shift, s.seat_no',
		$year
	), ARRAY_A );
	$recs = ogc_vol_records( $year );
	$out  = array();
	foreach ( (array) $rows as $s ) {
		if ( isset( $recs[ (int) $s['record_id'] ] ) ) {
			$out[ $s['shift'] ][] = array( 'seat_no' => (int) $s['seat_no'], 'record' => $recs[ (int) $s['record_id'] ] );
		}
	}
	return $out;
}

/** Places whose sign-up is gone (removed through another page, or cleared samples), and places half
 * made more than a minute ago, are let go. */
function ogc_vol_seats_tidy( $year, $shift = null ) {
	global $wpdb;
	$t = ogc_table( 'vol_seats' );
	$r = ogc_table( 'records' );
	$where = $shift ? $wpdb->prepare( 'year = %d AND shift = %s', $year, $shift ) : $wpdb->prepare( 'year = %d', $year );
	$wpdb->query( "DELETE FROM $t WHERE $where AND record_id > 0 AND record_id NOT IN (SELECT id FROM $r WHERE deleted_at IS NULL)" ); // phpcs:ignore -- $where is prepared above.
	$wpdb->query( "DELETE FROM $t WHERE $where AND record_id = 0 AND created_at < '" . esc_sql( gmdate( 'Y-m-d H:i:s', time() - 60 ) ) . "'" ); // phpcs:ignore
}

/**
 * Take places on a shift for several people at once, all or none. Each taken place is a new row
 * whose unique keys refuse a second taker; the lowest free seat is tried first, then the next.
 * Returns array( pkey => seat row id ) or a WP_Error: ogc_full (with 'open'), ogc_dup (with 'pkey').
 * $over: a head may add past the count.
 */
function ogc_vol_take_seats( $year, $sh, $pkeys, $over = false ) {
	global $wpdb;
	$t = ogc_table( 'vol_seats' );
	ogc_vol_seats_tidy( $year, $sh['id'] );
	$got = array();
	$wpdb->suppress_errors( true );
	foreach ( $pkeys as $pk ) {
		// Already on it (a double tap, or two tabs): the one place they have.
		$have = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM $t WHERE year = %d AND shift = %s AND pkey = %s", $year, $sh['id'], $pk ) );
		if ( $have ) {
			ogc_vol_release( $got );
			$wpdb->suppress_errors( false );
			return new WP_Error( 'ogc_dup', 'Already on it.', array( 'status' => 409, 'pkey' => $pk ) );
		}
		$ok = false;
		for ( $try = 0; $try < 8 && ! $ok; $try++ ) {
			$used = array_map( 'intval', (array) $wpdb->get_col( $wpdb->prepare( "SELECT seat_no FROM $t WHERE year = %d AND shift = %s", $year, $sh['id'] ) ) );
			$cap  = $sh['unlimited'] ? count( $used ) + 1 : $sh['needed'];
			if ( ! $over && ! $sh['unlimited'] && count( $used ) >= $sh['needed'] ) {
				break;
			}
			$free = 0;
			for ( $n = 1; $n <= max( $cap, $over ? count( $used ) + 1 : 0 ); $n++ ) {
				if ( ! in_array( $n, $used, true ) ) {
					$free = $n;
					break;
				}
			}
			if ( ! $free ) {
				break;
			}
			$ins = $wpdb->insert( $t, array( 'year' => (int) $year, 'shift' => $sh['id'], 'seat_no' => $free, 'pkey' => $pk, 'record_id' => 0, 'created_at' => ogc_now() ), array( '%d', '%s', '%d', '%s', '%d', '%s' ) );
			if ( $ins ) {
				$got[ $pk ] = (int) $wpdb->insert_id;
				$ok         = true;
			} elseif ( $wpdb->get_var( $wpdb->prepare( "SELECT id FROM $t WHERE year = %d AND shift = %s AND pkey = %s", $year, $sh['id'], $pk ) ) ) {
				ogc_vol_release( $got );
				$wpdb->suppress_errors( false );
				return new WP_Error( 'ogc_dup', 'Already on it.', array( 'status' => 409, 'pkey' => $pk ) );
			}
			// else: someone took that seat a moment ago; try the next.
		}
		if ( ! $ok ) {
			ogc_vol_release( $got );
			$wpdb->suppress_errors( false );
			$open = $sh['unlimited'] ? 99 : max( 0, $sh['needed'] - (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $t WHERE year = %d AND shift = %s", $year, $sh['id'] ) ) );
			return new WP_Error( 'ogc_full', 'Full.', array( 'status' => 409, 'open' => $open ) );
		}
	}
	$wpdb->suppress_errors( false );
	return $got;
}

/** Let go of places by their row ids. */
function ogc_vol_release( $seat_ids ) {
	global $wpdb;
	foreach ( (array) $seat_ids as $id ) {
		$wpdb->delete( ogc_table( 'vol_seats' ), array( 'id' => (int) $id ), array( '%d' ) );
	}
}

/** The place a sign-up holds is let go. */
function ogc_vol_release_record( $record_id ) {
	global $wpdb;
	$wpdb->delete( ogc_table( 'vol_seats' ), array( 'record_id' => (int) $record_id ), array( '%d' ) );
}

/** A person's other places in the year that overlap a shift (Busy): returns the shift they're on, or
 * null. Overlaps of up to settings overlap_ok_minutes (default 0) are allowed. */
function ogc_vol_busy( $year, $sh, $pkey, $except_record = 0 ) {
	global $wpdb;
	$ids = (array) $wpdb->get_col( $wpdb->prepare( 'SELECT s.shift FROM ' . ogc_table( 'vol_seats' ) . ' s JOIN ' . ogc_table( 'records' ) . ' r ON r.id = s.record_id AND r.deleted_at IS NULL WHERE s.year = %d AND s.pkey = %s AND s.shift <> %s AND s.record_id <> %d', $year, $pkey, $sh['id'], (int) $except_record ) );
	return ogc_vol_overlap( $year, $sh, $ids );
}

/** After taking a place: an earlier place (a lower row) the same person holds at the same time,
 * including one another request is still making (no record yet). The later of two racing Joins loses. */
function ogc_vol_busy_race( $year, $sh, $pkey, $seat_id ) {
	global $wpdb;
	$t   = ogc_table( 'vol_seats' );
	$r   = ogc_table( 'records' );
	$ids = (array) $wpdb->get_col( $wpdb->prepare( "SELECT s.shift FROM $t s LEFT JOIN $r r ON r.id = s.record_id WHERE s.year = %d AND s.pkey = %s AND s.shift <> %s AND s.id < %d AND ( s.record_id = 0 OR ( r.id IS NOT NULL AND r.deleted_at IS NULL ) )", $year, $pkey, $sh['id'], (int) $seat_id ) );
	return ogc_vol_overlap( $year, $sh, $ids );
}

/** The first of these shifts that overlaps $sh by more than the COA allows, or null. */
function ogc_vol_overlap( $year, $sh, $ids ) {
	$all    = ogc_vol_shifts( $year );
	$s      = ogc_vol_settings( $year );
	$ok_min = isset( $s['overlap_ok_minutes'] ) ? max( 0, (int) $s['overlap_ok_minutes'] ) : 0;
	foreach ( $ids as $id ) {
		if ( ! isset( $all[ $id ] ) ) {
			continue;
		}
		$o       = $all[ $id ];
		$overlap = min( $o['end_ts'], $sh['end_ts'] ) - max( $o['start_ts'], $sh['start_ts'] );
		if ( $overlap > $ok_min * 60 ) {
			return $o;
		}
	}
	return null;
}

/* ================================================================== people the site knows */

/** This email's registration for the year (theirs, or one a helper filled in), or null. */
function ogc_vol_registration( $year, $email ) {
	$email = strtolower( trim( (string) $email ) );
	if ( ! $email ) {
		return null;
	}
	foreach ( ogc_records( $year, 'registrations' ) as $r ) {
		$d = $r['data'];
		if ( $r['email'] === $email || ( ! empty( $d['helper']['on'] ) && isset( $d['helper']['email'] ) && strtolower( $d['helper']['email'] ) === $email ) ) {
			return $d;
		}
	}
	return null;
}

/** What the registration says of a person's age: 'minor' (under 18), 'child', 'adult' or ''. */
function ogc_vol_age_of( $reg, $name ) {
	if ( ! $reg || empty( $reg['people'] ) ) {
		return '';
	}
	foreach ( (array) $reg['people'] as $p ) {
		if ( isset( $p['name'] ) && 0 === strcasecmp( trim( $p['name'] ), trim( $name ) ) ) {
			if ( ! empty( $p['minor'] ) || ( isset( $p['age'] ) && is_numeric( $p['age'] ) && $p['age'] < 18 ) || ! empty( $p['preteen'] ) ) {
				return 'minor';
			}
			if ( ( isset( $p['band'] ) && in_array( $p['band'], array( 'child', 'baby' ), true ) ) || ( isset( $p['kind'] ) && 'child' === $p['kind'] ) ) {
				return 'child';
			}
			return 'adult';
		}
	}
	return '';
}

/** A person's age in years when the registration gives one, else null. */
function ogc_vol_age_num( $reg, $name ) {
	foreach ( $reg && ! empty( $reg['people'] ) ? (array) $reg['people'] : array() as $p ) {
		if ( isset( $p['name'] ) && 0 === strcasecmp( trim( $p['name'] ), trim( $name ) ) ) {
			return isset( $p['age'] ) && is_numeric( $p['age'] ) ? (int) $p['age'] : null;
		}
	}
	return null;
}

/** "Ruth K." (the site's convention for names on a public page). */
function ogc_vol_first_l( $name ) {
	$w = preg_split( '/\s+/', trim( (string) $name ) );
	$w = array_values( array_filter( $w, 'strlen' ) );
	if ( count( $w ) > 1 ) {
		return $w[0] . ' ' . mb_substr( $w[ count( $w ) - 1 ], 0, 1 ) . '.';
	}
	return $w ? $w[0] : '';
}

/** A phone the one way: ten US digits as 765-555-0123 (a leading 1 dropped); anything else as typed. */
function ogc_vol_phone_shown( $s ) {
	$s    = trim( (string) $s );
	$d    = preg_replace( '/\D+/', '', $s );
	$intl = (bool) preg_match( '/^\+(?!1)/', $s );
	if ( 11 === strlen( $d ) && '1' === $d[0] && ! $intl ) {
		$d = substr( $d, 1 );
	}
	return 10 === strlen( $d ) && ! $intl ? substr( $d, 0, 3 ) . '-' . substr( $d, 3, 3 ) . '-' . substr( $d, 6 ) : $s;
}

/** How many different people helped (one person on three shifts is one): all, and per committee. */
function ogc_vol_people_counts( $year, $map = null ) {
	$map    = null === $map ? ogc_vol_seat_map( $year ) : $map;
	$shifts = ogc_vol_shifts( $year );
	$all    = array();
	$by     = array();
	foreach ( $map as $id => $seats ) {
		$c = isset( $shifts[ $id ] ) ? $shifts[ $id ]['committee'] : '';
		foreach ( $seats as $s ) {
			$d = $s['record']['data'];
			$k = ogc_vol_pkey( $s['record']['email'], isset( $d['name'] ) ? $d['name'] : '', isset( $d['phone'] ) ? $d['phone'] : '' );
			$all[ $k ] = 1;
			if ( '' !== $c ) {
				$by[ $c ][ $k ] = 1;
			}
		}
	}
	return array( 'total' => count( $all ), 'committees' => array_map( 'count', $by ) );
}

/** A closed year's counts as the public page says them: from the names while they're kept, then from
 * the numbers kept at the clearing (null for a year cleared before they were kept: the page then says
 * "places filled", which is what it has). */
function ogc_vol_people_shown( $year ) {
	if ( ogc_state_get( $year, 'vol-cleared' ) ) {
		$p = ogc_state_get( $year, 'vol-people' );
		if ( $p ) {
			return $p['value'];
		}
		// Cleared before the count was kept: only sample people remain (made up, never cleared).
		$c = ogc_vol_people_counts( $year );
		return $c['total'] ? $c : null;
	}
	return ogc_vol_people_counts( $year );
}

function ogc_vol_initials( $name ) {
	$w = array_values( array_filter( preg_split( '/\s+/', trim( (string) $name ) ), 'strlen' ) );
	if ( ! $w ) {
		return '';
	}
	return strtoupper( mb_substr( $w[0], 0, 1 ) . ( count( $w ) > 1 ? mb_substr( $w[ count( $w ) - 1 ], 0, 1 ) : '' ) );
}

/** Names on the public page ("Ruth K."), or only how many (settings volunteer_names = count). */
function ogc_vol_names_shown( $year ) {
	$s = ogc_vol_settings( $year );
	return 'count' !== ( isset( $s['volunteer_names'] ) ? $s['volunteer_names'] : '' );
}

/** Whether a sign-up's name may show on the public page: names are on; the person hasn't hidden it;
 * the email is confirmed; not a minor, nor signed up by someone else (unless shown on purpose); and, when the COA turned names on
 * after people signed up under "only how many", only those who said so since. */
function ogc_vol_label_ok( $year, $rec ) {
	$d = $rec['data'];
	if ( ! ogc_vol_names_shown( $year ) || ! empty( $d['hide'] ) || empty( $d['confirmed'] ) ) {
		return false;
	}
	if ( ( ! empty( $d['minor'] ) || ! empty( $d['for'] ) ) && empty( $d['show'] ) ) {
		return false;
	}
	// Read once a request (it was read once per sign-up: 454 queries for 2026's list).
	static $since_of = array();
	if ( ! array_key_exists( (int) $year, $since_of ) ) {
		$since_of[ (int) $year ] = ogc_state_get( $year, 'vol-names-since' );
	}
	$since = $since_of[ (int) $year ];
	if ( $since && ! empty( $since['value'] ) && $rec['created_at'] < $since['value'] && empty( $d['show'] ) ) {
		return false;
	}
	return true;
}

/** The redacted view of a sign-up anyone may see (the generic records routes): which shift, and the
 * name as "Ruth K." when it may show. Never an email, phone, household or note. Waits: nothing. */
add_filter( 'ogc_record_public', function ( $pub, $data, $kind, $year, $rec ) {
	if ( 'signups' !== $kind ) {
		return 'waits' === $kind ? null : $pub;
	}
	// Nothing before sign-ups are posted or after they close (as /vol/{y}): the names of a Conference
	// that's over aren't public (review, Oct 11).
	static $shown = array();
	if ( ! isset( $shown[ (int) $year ] ) ) {
		$shown[ (int) $year ] = ogc_vol_posted( $year ) && ! ogc_vol_closed( $year );
	}
	if ( ! $shown[ (int) $year ] ) {
		return null;
	}
	$ok = ogc_vol_label_ok( $year, $rec );
	return array(
		'id'       => isset( $data['id'] ) ? (string) $data['id'] : '',
		'label'    => $ok ? ogc_vol_first_l( $data['name'] ) : null,
		'initials' => $ok ? ogc_vol_initials( $data['name'] ) : null,
	);
}, 10, 5 );

/* ================================================================== the generic records routes */

// Sign-ups and waits are made only through the volunteer routes (where places are held atomically and
// the rules checked). The generic routes may still remove one (Your sign-ups' Leave shift), and an
// owner may change only whether their name shows.
// (Last, after the signin area's filter, which lets a visitor make other kinds of record.)
add_filter( 'ogc_record_can_write', function ( $allowed, $action, $kind, $year, $record, $data ) {
	if ( ( 'signups' === $kind || 'waits' === $kind ) && 'create' === $action ) {
		return false;
	}
	return $allowed;
}, 30, 6 );
add_filter( 'ogc_anon_kinds', function ( $kinds ) {
	return array_values( array_diff( (array) $kinds, array( 'signups', 'waits' ) ) );
}, 20 );

/** A visitor's sign-ups are this device's (the signin area's device link), so Your sign-ups and Leave
 * work here before the email is confirmed. */
function ogc_vol_device_link( $ids ) {
	global $wpdb;
	if ( is_user_logged_in() || ! function_exists( 'ogc_device_hash' ) ) {
		return;
	}
	$h = ogc_device_hash( true );
	foreach ( (array) $ids as $id ) {
		if ( $h ) {
			$wpdb->insert( ogc_table( 'devices' ), array( 'dhash' => $h, 'record_id' => (int) $id, 'created_at' => ogc_now() ) );
		}
	}
}

add_filter( 'ogc_record_validate', function ( $data, $kind, $year, $existing ) {
	if ( is_wp_error( $data ) || ! $existing || ( 'signups' !== $kind && 'waits' !== $kind ) ) {
		return $data;
	}
	$keep = $existing['data'];
	foreach ( array( 'hide', 'next_year', 'show' ) as $k ) {
		if ( array_key_exists( $k, (array) $data ) ) {
			$keep[ $k ] = (bool) $data[ $k ];
		}
	}
	// A member may also mark someone here (check-in), never move them by this route.
	if ( ogc_is_member( $year ) && array_key_exists( 'here', (array) $data ) ) {
		$keep['here'] = (bool) $data['here'];
	}
	return $keep;
}, 10, 4 );

// A sign-up removed through the generic route (Your sign-ups) lets its place go, and is a Leave: the
// person, the people waiting and the head are told.
add_action( 'ogc_record_saved', function ( $rec, $action ) {
	if ( 'delete' !== $action || ! in_array( $rec['kind'], array( 'signups', 'waits' ), true ) ) {
		return;
	}
	if ( 'signups' === $rec['kind'] ) {
		ogc_vol_after_leave( $rec['year'], $rec, 'self' );
	}
}, 10, 2 );

/* ================================================================== a year made ready */

/** Once per year: shifts carry uids, and there's a committees list. Run on the seed and on first use. */
function ogc_vol_prepare_year( $year ) {
	$f = ogc_file_get( $year, 'shifts' );
	if ( $f ) {
		$need = false;
		foreach ( $f['rows'] as $r ) {
			if ( ! empty( $r['role'] ) && empty( $r['uid'] ) ) {
				$need = true;
				break;
			}
		}
		if ( $need ) {
			ogc_file_put( $year, 'shifts', $f['rows'], $f['version'] );
			ogc_vol_shifts( $year, true );
		}
	}
	if ( ! ogc_state_get( $year, 'vol-snap' ) ) {
		ogc_vol_snapshot( $year );
	}
	// Once: sample sign-ups seeded before Oct 11 all carried one date; spread them as real ones are.
	if ( ! ogc_state_get( $year, 'vol-sample-at' ) ) {
		ogc_vol_sample_dates( $year );
	}
}

/** When a sample sign-up was made: between sign-ups opening and a week before the Conference (never
 * after today), most of them early, as sign-ups come in. $k spreads them. */
function ogc_vol_sample_at( $year, $k ) {
	$s     = ogc_vol_settings( $year );
	$days  = ogc_vol_days( $year );
	$first = $days ? strtotime( $days[0]['date'] . ' 12:00 UTC' ) : time();
	$p     = isset( $s['signups_posted'] ) ? trim( $s['signups_posted'] ) : '';
	$open  = preg_match( '/^\d{4}-\d{2}-\d{2}$/', $p ) && '9999-12-31' !== $p ? strtotime( $p . ' 09:00 UTC' ) : $first - 120 * DAY_IN_SECONDS;
	$end   = min( time() - HOUR_IN_SECONDS, $first - 7 * DAY_IN_SECONDS );
	if ( $end <= $open ) {
		$end = $open + DAY_IN_SECONDS;
	}
	$f = ( ( (int) $k * 7919 + 104729 ) % 1000 ) / 1000;
	return min( $end, $open + (int) ( ( $end - $open ) * $f * $f ) + ( (int) $k % 540 ) * 60 );
}

/** The sample sign-ups' dates, spread (the download's Signed up column, the date a shift filled). */
function ogc_vol_sample_dates( $year ) {
	foreach ( ogc_records( $year, 'signups' ) as $r ) {
		if ( ! $r['sample'] ) {
			continue;
		}
		$d       = $r['data'];
		$d['at'] = gmdate( 'c', ogc_vol_sample_at( $year, $r['id'] ) );
		ogc_record_update( $r['id'], $d, $r['email'] );
	}
	// The sample notes that said the place twice ("Carts and keys are at the Barnes Student Center"
	// under "Barnes Student Center"), as the seed now has them.
	$f = ogc_file_get( $year, 'shifts' );
	if ( $f ) {
		$rows = $f['rows'];
		$n    = 0;
		foreach ( $rows as &$row ) {
			if ( isset( $row['note'] ) && 'Drive guests around campus. Carts and keys are at the Barnes Student Center.' === $row['note'] ) {
				$row['note'] = 'Drive guests between the buildings and the parking lots.';
				$n++;
			}
		}
		unset( $row );
		if ( $n ) {
			ogc_file_put( $year, 'shifts', $rows, $f['version'] );
			ogc_vol_shifts( $year, true );
		}
	}
	ogc_state_put( $year, 'vol-sample-at', ogc_now() );
}

/** What each shift was, for telling its people when it changes: id → when, where, what. */
function ogc_vol_snapshot( $year ) {
	$snap = array();
	$old  = ogc_state_get( $year, 'vol-snap' );
	$old  = $old ? (array) $old['value'] : array();
	foreach ( ogc_vol_shifts( $year, true ) as $id => $sh ) {
		$snap[ $id ] = array( 'date' => $sh['date'], 'start' => $sh['start'], 'end' => $sh['end'], 'place' => $sh['place'], 'role' => $sh['role'], 'committee' => $sh['committee'], 'seq' => isset( $old[ $id ]['seq'] ) ? (int) $old[ $id ]['seq'] : 0 );
	}
	ogc_state_put( $year, 'vol-snap', $snap );
	return $snap;
}

// The COA changed the shifts: anyone on a shift whose day, time or place changed is told (with the
// updated calendar event); anyone on a shift that's gone is told and their sign-up ends.
add_action( 'ogc_file_saved', function ( $year, $name ) {
	if ( 'shifts' === $name ) {
		ogc_vol_shifts_changed( $year );
	}
	if ( 'settings' === $name ) {
		// Names turned on after people signed up under "only how many": only later sign-ups show.
		$mode = ogc_vol_names_shown( $year ) ? 'names' : 'count';
		$was  = ogc_state_get( $year, 'vol-names-mode' );
		if ( ! $was || $was['value'] !== $mode ) {
			ogc_state_put( $year, 'vol-names-mode', $mode );
			if ( $was && 'names' === $mode ) {
				ogc_state_put( $year, 'vol-names-since', ogc_now() );
			}
		}
	}
}, 10, 2 );

function ogc_vol_shifts_changed( $year ) {
	$old = ogc_state_get( $year, 'vol-snap' );
	$old = $old ? (array) $old['value'] : array();
	$new = ogc_vol_shifts( $year, true );
	$map = ogc_vol_seat_map( $year );
	foreach ( $old as $id => $o ) {
		if ( empty( $map[ $id ] ) ) {
			continue;
		}
		if ( ! isset( $new[ $id ] ) ) {
			foreach ( $map[ $id ] as $seat ) {
				$rec = $seat['record'];
				ogc_record_delete( $rec['id'] );
				ogc_vol_release_record( $rec['id'] );
				ogc_vol_queue_person( $year, $rec, 'removed', array( 'was' => $o ) );
			}
			ogc_log( 'vol_shift_gone', $year, $id, array( 'people' => count( $map[ $id ] ) ) );
			continue;
		}
		$n = $new[ $id ];
		if ( $n['date'] !== $o['date'] || $n['start'] !== $o['start'] || $n['end'] !== $o['end'] || $n['place'] !== $o['place'] ) {
			$old[ $id ]['seq'] = ( isset( $o['seq'] ) ? (int) $o['seq'] : 0 ) + 1;
			ogc_state_put( $year, 'vol-snap', $old );
			foreach ( $map[ $id ] as $seat ) {
				ogc_vol_queue_person( $year, $seat['record'], 'changed', array( 'was' => $o ) );
			}
			ogc_log( 'vol_shift_changed', $year, $id, array( 'people' => count( $map[ $id ] ) ) );
		}
	}
	ogc_vol_snapshot( $year );
}

/* ================================================================== samples */

// After the seed loads a year: shifts get uids, sample committees and made-up volunteers.
add_action( 'ogc_seed_year', 'ogc_vol_seed_year', 20 );

/** The size of a real year (docs/16: about 700 places in 2018: dining 260, dorm supervision 148, golf
 * carts 110, communion 100, First Aid 58, preteens 24): the sample shifts' counts, raised to match. */
function ogc_vol_sample_scale( $rows ) {
	$want = array(
		'server'           => 26,
		'clean-up'         => 10,
		'communion helper' => 50,
		'dorm chaperone'   => 6,
		'snack helper'     => 4,
		'usher'            => 8,
		'preteen helper'   => 6,
	);
	foreach ( $rows as &$r ) {
		$k = strtolower( isset( $r['role'] ) ? $r['role'] : '' );
		if ( isset( $want[ $k ] ) ) {
			$r['needed'] = (string) $want[ $k ];
		}
		// Kit packing takes everyone who comes (2,500 kits in 2022).
		if ( 'kit packing' === $k ) {
			$r['needed'] = 'any';
		}
	}
	unset( $r );
	return $rows;
}

function ogc_vol_seed_year( $year ) {
	// Places left from samples just erased go first.
	ogc_vol_seats_tidy( $year );
	$f = ogc_file_get( $year, 'shifts' );
	if ( ! $f ) {
		return;
	}
	// Off a local dev site: the shifts as written (their ids), and nothing made up (review, Oct 11).
	if ( function_exists( 'ogc_seed_samples' ) && ! ogc_seed_samples() ) {
		ogc_vol_shifts( $year, true );
		ogc_vol_snapshot( $year );
		return;
	}
	ogc_file_put( $year, 'shifts', ogc_vol_sample_scale( $f['rows'] ), $f['version'] );
	ogc_vol_shifts( $year, true );
	if ( ! ogc_file_get( $year, 'committees' ) ) {
		$rows = array();
		$i    = 0;
		foreach ( array_unique( wp_list_pluck( ogc_vol_shifts( $year ), 'committee' ) ) as $c ) {
			$slug   = trim( preg_replace( '/[^a-z0-9]+/', '-', strtolower( $c ) ), '-' );
			$rows[] = array(
				'name'          => $c,
				'contact_email' => $slug . '@conference.example.org',
				'contact_phone' => '765-555-' . str_pad( (string) ( 140 + $i ), 4, '0', STR_PAD_LEFT ),
				'heads'         => 'head.' . $slug . '@example.com',
				'weekly'        => 'yes',
				'order'         => '',
			);
			$i++;
		}
		ogc_file_put( $year, 'committees', $rows, 0, array( 'name', 'contact_email', 'contact_phone', 'heads', 'weekly', 'order' ) );
	}
	ogc_vol_seed_people( $year );
	ogc_vol_snapshot( $year );
	// Last year's heads left notes (made up), so a new head's list opens with "From 2026" on top.
	if ( 2026 === (int) $year && ! ogc_state_get( $year, 'vol-notes' ) ) {
		ogc_state_put( $year, 'vol-notes', array(
			'Food' => array( 'text' => "Sunday lunch needs two more servers than the other days.\nAsk the caterer for hairnets ahead; they ran out Saturday.", 'at' => '2026-06-12 15:00:00', 'by' => 'Ruth K.', 'sample' => true ),
			'Young Folks' => array( 'text' => 'Fill the 12–2 AM dorm shifts first; they were the last to fill.', 'at' => '2026-06-11 10:00:00', 'by' => 'Paul M.', 'sample' => true ),
		) );
	}
}

/** Made-up volunteers, seated as real sign-ups (sample = 1): couples sharing a surname and a phone;
 * each takes a shift or two a day and never two at once. A Conference long past is mostly full; the
 * next one is about a quarter full. Plus the cases a head meets: someone with no email, a swap open,
 * people waiting on a full shift, a shift over its count, a hidden name, one not yet confirmed. */
function ogc_vol_seed_people( $year ) {
	global $wpdb;
	$shifts = ogc_vol_shifts( $year, true );
	if ( ! $shifts ) {
		return;
	}
	$men   = array( 'John', 'Daniel', 'David', 'Samuel', 'Joseph', 'Paul', 'Aaron', 'Jonathan', 'Mark', 'Timothy', 'Stephen', 'Philip', 'James', 'Joel', 'Seth', 'Levi', 'Micah', 'Peter', 'Thomas', 'Matthew', 'Isaac', 'Benjamin', 'Jacob', 'Ethan', 'Josiah', 'Silas', 'Owen', 'Simon', 'Eli', 'Adam' );
	$women = array( 'Ruth', 'Esther', 'Mary', 'Anna', 'Sarah', 'Rebecca', 'Lydia', 'Miriam', 'Rachel', 'Hannah', 'Leah', 'Martha', 'Naomi', 'Lois', 'Grace', 'Joy', 'Faith', 'Ellen', 'Abigail', 'Elizabeth', 'Susanna', 'Deborah', 'Priscilla', 'Rosanna', 'Joanna', 'Julia', 'Phoebe', 'Eunice', 'Carol', 'Laura' );
	$surs  = array( 'Adams', 'Baker', 'Carter', 'Dean', 'Ellis', 'Ford', 'Grant', 'Hayes', 'Irwin', 'Jordan', 'Knight', 'Lane', 'Mason', 'Nash', 'Owens', 'Parker', 'Quinn', 'Rhodes', 'Stone', 'Turner', 'Vaughn', 'Walsh', 'Young', 'Barton', 'Cole', 'Drake', 'Fleming', 'Gates', 'Hart', 'Keller', 'Lowe', 'Marsh', 'Porter', 'Reed', 'Shaw', 'Tate', 'Ward', 'Wells', 'Brooks', 'Fisher', 'Moore', 'Clark', 'Evans', 'Hall', 'Abbott', 'Archer', 'Bell', 'Bishop', 'Blake', 'Bradley', 'Burke', 'Burton', 'Caldwell', 'Chapman', 'Cooper', 'Craig', 'Cross', 'Curtis', 'Dalton', 'Dawson', 'Dixon', 'Duncan', 'Eaton', 'Elliott', 'Emery', 'Farmer', 'Fields', 'Fletcher', 'Foster', 'Fuller', 'Gardner', 'Garrett', 'Gibson', 'Gilbert', 'Graves', 'Gray', 'Griffin', 'Hale', 'Hammond', 'Hardy', 'Harper', 'Hawkins', 'Hicks', 'Hill', 'Holland', 'Holt', 'Hopkins', 'Horton', 'Howell', 'Hudson', 'Hunt', 'Ingram', 'Jarvis', 'Kemp', 'Kirby', 'Lambert', 'Lawson', 'Lewis', 'Lloyd', 'Long', 'Lucas', 'Lyons', 'Manning', 'Maxwell', 'Meyer', 'Miles', 'Mills', 'Morgan', 'Morris', 'Newton', 'Noble', 'Norris', 'Oliver', 'Page', 'Palmer', 'Payne', 'Pearson', 'Perry', 'Pierce', 'Powell', 'Pratt', 'Preston', 'Price', 'Ramsey', 'Riley', 'Roberts', 'Rogers', 'Ross', 'Rowe', 'Russell', 'Sawyer', 'Sharp', 'Sims', 'Snyder', 'Spencer', 'Steele', 'Sutton', 'Thornton', 'Wade', 'Walton', 'Watts', 'Webb', 'Weaver', 'Wheeler' );
	// 150 couples; each is a household with one email (the first named).
	$pool = array();
	foreach ( range( 0, 149 ) as $k ) {
		$sur   = $surs[ ( $k * 17 ) % count( $surs ) ] ;
		$phone = '555-' . str_pad( (string) ( 1000 + $k ), 4, '0', STR_PAD_LEFT );
		$him   = $men[ ( $k * 7 ) % count( $men ) ] . ' ' . $sur;
		$her   = $women[ ( $k * 11 + 3 ) % count( $women ) ] . ' ' . $sur;
		$mail  = strtolower( str_replace( ' ', '.', $k % 2 ? $her : $him ) ) . ( $k > 43 ? '.' . $k : '' ) . '@example.com';
		$pool[] = array( 'name' => $him, 'phone' => $phone, 'email' => $mail );
		$pool[] = array( 'name' => $her, 'phone' => $phone, 'email' => $mail );
	}
	mt_srand( (int) $year * 7919 );
	$past  = ogc_vol_last_day( $year ) && ogc_vol_last_day( $year ) < gmdate( 'Y-m-d' );
	$busy  = array();
	$load  = array();
	$by_c  = array();
	$t     = ogc_table( 'vol_seats' );
	$made  = 0;
	$first = array();
	foreach ( $shifts as $id => $sh ) {
		$c = $sh['committee'];
		if ( ! isset( $by_c[ $c ] ) ) {
			$want         = 0;
			foreach ( $shifts as $x ) {
				$want += $x['committee'] === $c ? ( $x['unlimited'] ? 20 : $x['needed'] ) : 0;
			}
			$size         = min( count( $pool ), max( 10, (int) ceil( $want / 2.4 ) + 4 ) );
			$at           = mt_rand( 0, count( $pool ) - 1 );
			$by_c[ $c ] = array();
			for ( $k = 0; $k < $size; $k++ ) {
				$by_c[ $c ][] = ( $at + $k * 7 ) % count( $pool );
			}
		}
		$cap  = $sh['unlimited'] ? 30 : $sh['needed'];
		$r    = mt_rand( 0, 99 );
		$fill = $past ? ( $r < 55 ? $cap : (int) floor( $cap * ( 0.55 + $r / 250 ) ) ) : ( $r < 12 ? $cap : (int) floor( $cap * $r / 260 ) );
		$on   = 0;
		// Each shift starts at a different place in the committee's list, so the work is spread.
		$list = $by_c[ $c ];
		$rot  = ( count( $list ) ? ( crc32( $id ) % count( $list ) ) : 0 );
		$list = array_merge( array_slice( $list, $rot ), array_slice( $list, 0, $rot ) );
		foreach ( $list as $pi ) {
			if ( $on >= $fill ) {
				break;
			}
			$p  = $pool[ $pi ];
			$ld = isset( $load[ $pi ] ) ? $load[ $pi ] : array( 'week' => 0 );
			if ( ( isset( $ld[ $sh['date'] ] ) ? $ld[ $sh['date'] ] : 0 ) >= 2 || $ld['week'] >= 6 ) {
				continue;
			}
			$clash = false;
			foreach ( isset( $busy[ $pi ] ) ? $busy[ $pi ] : array() as $b ) {
				if ( $b[0] < $sh['end_ts'] && $sh['start_ts'] < $b[1] ) {
					$clash = true;
					break;
				}
			}
			if ( $clash ) {
				continue;
			}
			$data = array( 'id' => $id, 'name' => $p['name'], 'phone' => $p['phone'], 'email' => $p['email'], 'confirmed' => true, 'by' => 'self', 'at' => gmdate( 'c', ogc_vol_sample_at( $year, $made * 13 + mt_rand( 0, 12 ) ) ), 'sample' => true );
			if ( $sh['rule'] ) {
				$data['rule'] = array( 'text' => $sh['rule'], 'answer' => $sh['question'] ? $sh['question'][ mt_rand( 0, 9 ) < 8 ? 0 : 1 ] : 'yes', 'at' => $data['at'] );
			}
			if ( 0 === mt_rand( 0, 24 ) ) {
				$data['hide'] = true;
			}
			if ( 0 === mt_rand( 0, 14 ) ) {
				$data['next_year'] = true;
			}
			$rid = ogc_record_insert( $year, 'signups', $data, $p['email'], true, 'seed' );
			$wpdb->insert( $t, array( 'year' => (int) $year, 'shift' => $id, 'seat_no' => $on + 1, 'pkey' => ogc_vol_pkey( $p['email'], $p['name'] ), 'record_id' => $rid, 'created_at' => ogc_now() ), array( '%d', '%s', '%d', '%s', '%d', '%s' ) );
			$busy[ $pi ][] = array( $sh['start_ts'], $sh['end_ts'] );
			$ld[ $sh['date'] ] = ( isset( $ld[ $sh['date'] ] ) ? $ld[ $sh['date'] ] : 0 ) + 1;
			$ld['week']++;
			$load[ $pi ] = $ld;
			$on++;
			$made++;
			if ( 1 === $on ) {
				$first[ $id ] = $rid;
			}
		}
	}
	// The cases a head meets, on a few shifts.
	$ids  = array_keys( $shifts );
	$seat = function ( $id, $data, $email ) use ( $year, $wpdb, $t, $shifts ) {
		$n   = 1 + (int) $wpdb->get_var( $wpdb->prepare( "SELECT MAX(seat_no) FROM $t WHERE year = %d AND shift = %s", $year, $id ) );
		// Three days ago, or for a Conference already held, weeks before it (never after it began).
		$at  = min( time() - DAY_IN_SECONDS * 3, $shifts[ $id ]['start_ts'] - DAY_IN_SECONDS * 21 );
		$rid = ogc_record_insert( $year, 'signups', $data + array( 'id' => $id, 'sample' => true, 'at' => gmdate( 'c', $at ) ), $email, true, 'seed' );
		$wpdb->insert( $t, array( 'year' => (int) $year, 'shift' => $id, 'seat_no' => $n, 'pkey' => ogc_vol_pkey( $email, $data['name'], isset( $data['phone'] ) ? $data['phone'] : '' ), 'record_id' => $rid, 'created_at' => ogc_now() ), array( '%d', '%s', '%d', '%s', '%d', '%s' ) );
		return $rid;
	};
	$open_ids = array_values( array_filter( $ids, function ( $id ) use ( $shifts, $wpdb, $t, $year ) {
		return ! $shifts[ $id ]['unlimited'] && (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $t WHERE year = %d AND shift = %s", $year, $id ) ) < $shifts[ $id ]['needed'] - 1;
	} ) );
	$full_ids = array_values( array_filter( $ids, function ( $id ) use ( $shifts, $wpdb, $t, $year ) {
		return ! $shifts[ $id ]['unlimited'] && (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $t WHERE year = %d AND shift = %s", $year, $id ) ) >= $shifts[ $id ]['needed'];
	} ) );
	if ( $open_ids ) {
		// Signed up by phone call: no email, added by the head.
		$seat( $open_ids[0], array( 'name' => 'Lois Brenneman', 'phone' => '555-0190', 'email' => '', 'confirmed' => true, 'by' => 'head', 'note' => 'Called the head' ), '' );
		// Signed up but hasn't opened the email's link yet.
		if ( isset( $open_ids[2] ) ) {
			$seat( $open_ids[2], array( 'name' => 'Martha Quinn', 'phone' => '555-0191', 'email' => 'martha.quinn.2@example.com', 'confirmed' => false, 'by' => 'self' ), 'martha.quinn.2@example.com' );
		}
	}
	if ( $full_ids ) {
		// A swap open on a full shift: anyone with the link (or the page) may take the place.
		if ( isset( $first[ $full_ids[0] ] ) ) {
			$r = ogc_record_get( $first[ $full_ids[0] ] );
			if ( $r ) {
				$d         = $r['data'];
				$d['swap'] = wp_generate_password( 16, false );
				ogc_record_update( $r['id'], $d, $r['email'] );
			}
		}
		// Three people waiting on a full shift.
		foreach ( array( array( 'Joel Sawyer', 'joel.sawyer@example.com' ), array( 'Phoebe Sims', 'phoebe.sims@example.com' ), array( 'Owen Steele', 'owen.steele@example.com' ) ) as $k => $w ) {
			ogc_record_insert( $year, 'waits', array( 'id' => $full_ids[ min( 1, count( $full_ids ) - 1 ) ], 'name' => $w[0], 'email' => $w[1], 'phone' => '555-02' . $k . '0', 'at' => gmdate( 'c', time() - DAY_IN_SECONDS * ( 5 - $k ) ), 'sample' => true ), $w[1], true, 'seed' );
		}
		// A shift over its count (the COA lowered it after people signed up).
		if ( isset( $full_ids[2] ) ) {
			$seat( $full_ids[2], array( 'name' => 'Eunice Webb', 'phone' => '555-0192', 'email' => 'eunice.webb@example.com', 'confirmed' => true, 'by' => 'self' ), 'eunice.webb@example.com' );
		}
	}
	// The made-up Hoovers (the form's sample household) helped in 2026: Daniel drove a golf cart Saturday
	// morning and kept the Lodging desk Friday; Esther served Sunday lunch. "Your 2026 shifts" shows them.
	if ( 2026 === (int) $year ) {
		foreach ( $shifts as $id => $sh ) {
			$who = ( 'Golf cart driver' === $sh['role'] && 'Saturday' === $sh['day'] && 420 === $sh['start'] ) || ( 'Lodging desk' === $sh['role'] && 'Friday' === $sh['day'] && 840 === $sh['start'] ) ? 'Daniel Hoover' : ( 'Server' === $sh['role'] && 'Sunday' === $sh['day'] && 705 === $sh['start'] ? 'Esther Hoover' : '' );
			if ( $who ) {
				// Room for them: on a full shift, one made-up volunteer makes way.
				if ( (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $t WHERE year = %d AND shift = %s", $year, $id ) ) >= $sh['needed'] ) {
					$last = $wpdb->get_row( $wpdb->prepare( "SELECT id, record_id FROM $t WHERE year = %d AND shift = %s ORDER BY seat_no DESC LIMIT 1", $year, $id ), ARRAY_A );
					$wpdb->delete( ogc_table( 'records' ), array( 'id' => (int) $last['record_id'] ), array( '%d' ) );
					$wpdb->delete( $t, array( 'id' => (int) $last['id'] ), array( '%d' ) );
				}
				$seat( $id, array( 'name' => $who, 'phone' => '555-0100', 'email' => 'daniel.hoover@example.com', 'confirmed' => true, 'by' => 'self', 'next_year' => true ), 'daniel.hoover@example.com' );
			}
		}
	}
	ogc_state_put( $year, 'vol-sample-at', ogc_now() );
	ogc_log( 'vol_samples', $year, 'signups', array( 'n' => $made ) );
}

/* ================================================================== the page */

// The page is drawn by the server down to its header (the year, its dates and place: the same for
// everyone, so the page can be cached); counts, names and "you" come from GET vol/{y}, never cached.
add_filter( 'ogc_pages', function ( $p ) {
	if ( isset( $p['volunteer'] ) ) {
		$p['volunteer']['template']    = 'volunteer-v2.php';
		$p['volunteer']['description'] = 'Volunteer at the Annual Conference: the committees’ shifts, who’s helping, and a place for you.';
	}
	return $p;
} );

/** The year the page opens on with no ?year: the Conference page's own (core ogc_featured_year), so
 * the two never disagree; the latest year with shifts only if there's none. */
function ogc_vol_default_year() {
	$y = function_exists( 'ogc_featured_year' ) ? ogc_featured_year() : 0;
	if ( $y ) {
		return $y;
	}
	foreach ( ogc_years_public() as $r ) {
		if ( ! empty( $r['data'] ) && (int) $r['year'] > $y ) {
			$y = (int) $r['year'];
		}
	}
	return $y ? $y : (int) gmdate( 'Y' );
}
