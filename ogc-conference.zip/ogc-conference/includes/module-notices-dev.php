<?php
/**
 * Two made-up notices for the demo (round 3 of the Conference app's mobile polish; feedback 6e73e4c93bdc),
 * so the shared link's days show what a notice looks like:
 *   - "Lodging requests close April 15", Mar 1 – Apr 15, 2027 (the demo's Mar 2);
 *   - "Monday’s supper is in the Rec Center", May 28 – 31, 2027 (the demo's Sat May 29).
 * Plain and made up: no person, no link. 2027's own notices stay empty in the seed
 * (seed/2027/notices.csv is its header only).
 *
 * Only where the samples load (ogc_seed_samples: OGC_DEV on a local address, or the prototype on the
 * Playground); never on ogbbc.org, and tools/build-plugin.sh leaves module-*-dev.php out of its zip.
 * Added only if missing, by their fixed row ids: once per site on init, and again when the seed reloads
 * 2027 (Pages › Start over). A change or removal in the COA app stands until then.
 */

defined( 'ABSPATH' ) || exit;

/** The demo's notices, as rows of 2027's notices file. */
function ogc_dev_notices() {
	return array(
		array( '_id' => 'kdemonote1', 'from' => '2027-03-01', 'to' => '2027-04-15', 'text' => 'Lodging requests close April 15', 'url' => '', 'kind' => '' ),
		array( '_id' => 'kdemonote2', 'from' => '2027-05-28', 'to' => '2027-05-31', 'text' => 'Monday’s supper is in the Rec Center', 'url' => '', 'kind' => '' ),
	);
}

/** Add the demo's notices to 2027 where they're missing. True once they're there (or nothing to do). */
function ogc_dev_notices_seed() {
	if ( ! function_exists( 'ogc_seed_samples' ) || ! ogc_seed_samples() || ! function_exists( 'ogc_file_get' ) || ! function_exists( 'ogc_year_get' ) || ! ogc_year_get( 2027 ) ) {
		return false;
	}
	for ( $try = 0; $try < 3; $try++ ) {
		$cur  = ogc_file_get( 2027, 'notices' );
		$rows = $cur ? array_values( (array) $cur['rows'] ) : array();
		$have = array();
		foreach ( $rows as $r ) {
			if ( is_array( $r ) && ! empty( $r['_id'] ) ) {
				$have[ $r['_id'] ] = true;
			}
		}
		$add = array();
		foreach ( ogc_dev_notices() as $n ) {
			if ( empty( $have[ $n['_id'] ] ) ) {
				$add[] = $n;
			}
		}
		if ( ! $add ) {
			return true;
		}
		$v = ogc_file_put( 2027, 'notices', array_merge( $rows, $add ), $cur ? (int) $cur['version'] : 0, $cur ? $cur['cols'] : array( 'from', 'to', 'text', 'url' ) );
		if ( ! is_wp_error( $v ) ) {
			return true;
		}
	}
	return false;
}

// Once per site (after the seed's own init work).
add_action( 'init', function () {
	if ( '1' === get_option( 'ogc_dev_notices' ) ) {
		return;
	}
	if ( ogc_dev_notices_seed() ) {
		update_option( 'ogc_dev_notices', '1', false );
	}
}, 50 );

// The seed reloaded 2027 (Start over): the year's notices are the seed's again, so the demo's go back.
add_action( 'ogc_seed_year', function ( $year ) {
	if ( 2027 === (int) $year ) {
		ogc_dev_notices_seed();
	}
}, 30 );
