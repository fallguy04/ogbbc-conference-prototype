<?php
/**
 * Records (night-records, Oct 13): households and money as a CRM (docs/25 rule 5; docs/26 #2, #4).
 *
 *   The COA's Households   every registration as one list on fixed fields (status, money, stay, nights,
 *                          size, needs, source, registered on), searched by surname or R-number, a
 *                          household opened beside the list, ticked rows exported. The screen is
 *                          assets/app/screens/coa-households.js.
 *   Status                 one fixed list (ogc_rec_statuses): Waitlist · Registered · Placed · Checked in
 *                          · Checked out · Didn't come · Cancelled. Worked out from what's already kept
 *                          (the registration, Lodging's rooms and desk, the COA's Didn't come); never typed.
 *   Money                  one fixed list (ogc_rec_money_words), worked out from the payment lines only
 *                          (ogc_rec_money_of): Nothing due · Paid · Payment due · Balance due · Check to
 *                          come · Due at check-in · Refund due · Refunded.
 *   Handles money          the tick the COA sets on Members (the access area's: module-members.php,
 *                          ogc_access( y, 'money' ) in module-guard.php). Only people with it see each
 *                          payment line (module-payments-ledger.php); the rest of the COA sees totals
 *                          and each household's Money word.
 *
 * The registration's stored data isn't changed by anything here (the public form was just rebuilt):
 * status and money are read from it and from the ledger. The one thing kept here is Didn't come
 * (state reg_marks: {rid: {s, at, by}}), which no other part records yet.
 *
 * Nothing here reads a note (docs/25 rule 2): the note to Lodging is shown, never searched or sorted.
 */

defined( 'ABSPATH' ) || exit;

/* ================================================================== the fixed lists */

function ogc_rec_statuses() {
	return array(
		'waitlist'    => 'Waitlist',
		'registered'  => 'Registered',
		'placed'      => 'Placed',
		'checked_in'  => 'Checked in',
		'checked_out' => 'Checked out',
		'noshow'      => 'Didn’t come',
		'cancelled'   => 'Cancelled',
	);
}

function ogc_rec_money_words() {
	return array(
		'none'      => 'Nothing due',
		'paid'      => 'Paid',
		'due'       => 'Payment due',
		'balance'   => 'Balance due',
		'check'     => 'Check to come',
		'checkin'   => 'Due at check-in',
		'refund'    => 'Refund due',
		'refunded'  => 'Refunded',
		// A household imported from the Google Form: its payment was the Form's own (no amounts here),
		// so it has words of its own and "Payment due" always means money owed on this site.
		'form_due'  => 'Unpaid on the Form',
		'form_paid' => 'Paid on the Form',
		'form'      => 'On the Form',
	);
}

/** The Money words that mean "still owes", the same for Households, Money, Lodging and Export. */
function ogc_rec_owing_keys() {
	return array( 'due', 'balance', 'checkin', 'form_due' );
}

function ogc_rec_sources() {
	return array( 'online' => 'Online', 'helper' => 'Helper', 'paper' => 'Paper', 'phone' => 'Phone', 'desk' => 'Desk', 'form' => 'Form import' );
}

/** The need boxes (docs/25 rule 1; docs/26 #20 as recommended). The form's two restroom boxes are one. */
function ogc_rec_needs() {
	return array( 'ground' => 'Ground floor', 'stairs' => 'No stairs', 'restroom' => 'Near a restroom' );
}

function ogc_rec_stays() {
	return array( 'dorm' => 'Dorm', 'camper' => 'Camper', 'elsewhere' => 'Elsewhere' );
}

/** The flags a household may carry, one fixed list (area-households-money 5.10): key => words. */
function ogc_rec_flags() {
	return array(
		'changed'     => 'Changed since placed',
		'notapproved' => 'Not approved',
		'late'        => 'Check late',
		'unasked'     => 'Not asked',
	);
}

/* ================================================================== one count, one place (Round 3) */

/**
 * The Households views, one definition (README rule 10; area-households-money §3): the list's chips,
 * Money's tiles, the COA's Work row and Home's lines all count with these, and each row carries the
 * views that hold it (`in`), so a door never opens onto a different number. id => test on a row.
 */
function ogc_rec_view_tests() {
	static $t = null;
	if ( null === $t ) {
		$gone = function ( $r ) {
			return in_array( $r['status'], array( 'cancelled', 'waitlist' ), true );
		};
		$t = array(
			'owes'      => function ( $r ) { return in_array( $r['money'], ogc_rec_owing_keys(), true ); },
			'checks'    => function ( $r ) { return 'check' === $r['money']; },
			'refunds'   => function ( $r ) { return 'refund' === $r['money']; },
			'needs'     => function ( $r ) use ( $gone ) { return $r['needs'] && ! $gone( $r ); },
			'waitlist'  => function ( $r ) { return 'waitlist' === $r['status']; },
			'cancelled' => function ( $r ) { return 'cancelled' === $r['status']; },
			'paid'      => function ( $r ) { return in_array( $r['money'], array( 'paid', 'form_paid' ), true ); },
			'noshow'    => function ( $r ) { return 'noshow' === $r['status']; },
		);
	}
	return $t;
}

/** Every view, flag and Money word that holds a row: 'owes', 'flag:late', 'money:checkin'… */
function ogc_rec_in( $row ) {
	$in = array();
	foreach ( ogc_rec_view_tests() as $id => $test ) {
		if ( $test( $row ) ) {
			$in[] = $id;
		}
	}
	foreach ( $row['flag_keys'] as $k ) {
		$in[] = 'flag:' . $k;
	}
	$in[] = 'money:' . $row['money'];
	return $in;
}

/** What a view's amount adds up for one row (cents; a Form household's money is the Form's: none). */
function ogc_rec_view_cents( $k, $r ) {
	if ( $r['form'] ) {
		return 0;
	}
	switch ( $k ) {
		case 'owes':
			return (int) $r['balance'];
		case 'checks':
			return (int) $r['check'];
		case 'refunds':
			return (int) $r['refund'];
		case 'paid':
			return (int) $r['paid'];
		case 'flag:late':
			return (int) $r['late'];
		case 'flag:unasked':
			return (int) $r['unasked'];
	}
	if ( 0 === strpos( $k, 'money:' ) ) {
		$m = $r['money'];
		return (int) ( in_array( $m, array( 'due', 'balance', 'checkin' ), true ) ? $r['balance'] : ( 'check' === $m ? $r['check'] : ( 'refund' === $m ? $r['refund'] : $r['paid'] ) ) );
	}
	return 0;
}

/**
 * ogc_rec_views( $rows ): each view's count and amount, from the rows' own `in` (area-households-money
 * §3): { all: {n, cents}, owes: {n, cents}, 'flag:late': {n, cents}, 'money:paid': {n, cents}, … }.
 * $rows are ogc_rec_rows( $y ), the households this request may count.
 */
function ogc_rec_views( $rows ) {
	$out = array( 'all' => array( 'n' => count( $rows ), 'cents' => 0 ) );
	foreach ( $rows as $r ) {
		foreach ( $r['in'] as $k ) {
			if ( ! isset( $out[ $k ] ) ) {
				$out[ $k ] = array( 'n' => 0, 'cents' => 0 );
			}
			$out[ $k ]['n']++;
			$out[ $k ]['cents'] += ogc_rec_view_cents( $k, $r );
		}
	}
	return $out;
}

/** The head's counts (Households' title, the COA's Work row): coming, people, waiting, cancelled… */
function ogc_rec_counts( $rows ) {
	$c = array( 'all' => count( $rows ), 'coming' => 0, 'people' => 0, 'waiting' => 0, 'cancelled' => 0, 'noshow' => 0, 'checked_in' => 0 );
	foreach ( $rows as $r ) {
		if ( 'waitlist' === $r['status'] ) {
			$c['waiting']++;
		} elseif ( 'cancelled' === $r['status'] ) {
			$c['cancelled']++;
		} else {
			$c['coming']++;
			$c['people'] += (int) $r['size'];
		}
		$c['noshow']     += 'noshow' === $r['status'] ? 1 : 0;
		$c['checked_in'] += in_array( $r['status'], array( 'checked_in', 'checked_out' ), true ) ? 1 : 0;
	}
	return $c;
}

/* ================================================================== filters in the address (Round 3) */

/** Households' fixed fields a filter may name (area-shell 1.4): field => array( label, test ). */
function ogc_rec_f_fields() {
	$in = function ( $list ) {
		return function ( $v ) use ( $list ) {
			return isset( $list[ $v ] );
		};
	};
	return array(
		'status' => array( 'Status', $in( ogc_rec_statuses() ) ),
		'money'  => array( 'Money', $in( ogc_rec_money_words() ) ),
		'stay'   => array( 'Stay', $in( ogc_rec_stays() ) ),
		'nights' => array( 'Nights', function ( $v ) { return (bool) preg_match( '/^\d{1,2}$/', $v ); } ),
		'size'   => array( 'People', function ( $v ) { return (bool) preg_match( '/^[1-6]$/', $v ); } ),
		'needs'  => array( 'Needs', $in( ogc_rec_needs() ) ),
		'source' => array( 'Source', $in( ogc_rec_sources() ) ),
		'flag'   => array( 'Flag', $in( ogc_rec_flags() ) ),
	);
}

/** A row's values for each field a filter may name. */
function ogc_rec_f_of( $r ) {
	return array(
		'status' => array( $r['status'] ),
		'money'  => array( $r['money'] ),
		'stay'   => array( $r['stay'] ),
		'nights' => 'elsewhere' === $r['stay'] ? array() : array( (string) $r['nights'] ),
		'size'   => array( (string) min( 6, (int) $r['size'] ) ),
		'needs'  => $r['needs'],
		'source' => array( $r['source'] ),
		'flag'   => $r['flag_keys'],
	);
}

/** Does a row pass every filter (AND between fields, OR within one)? */
function ogc_rec_f_pass( $r, $f ) {
	if ( ! $f ) {
		return true;
	}
	$of = ogc_rec_f_of( $r );
	foreach ( $f as $k => $vals ) {
		if ( ! array_intersect( isset( $of[ $k ] ) ? $of[ $k ] : array(), $vals ) ) {
			return false;
		}
	}
	return true;
}

/** The filters as their pills say them: [{field, label, values: [{v, words}]}]. */
function ogc_rec_f_words( $f ) {
	$fields = ogc_rec_f_fields();
	$lists  = array( 'status' => ogc_rec_statuses(), 'money' => ogc_rec_money_words(), 'stay' => ogc_rec_stays(), 'needs' => ogc_rec_needs(), 'source' => ogc_rec_sources(), 'flag' => ogc_rec_flags() );
	$out    = array();
	foreach ( $f as $k => $vals ) {
		$out[] = array(
			'field'  => $k,
			'label'  => $fields[ $k ][0],
			'values' => array_map( function ( $v ) use ( $k, $lists ) {
				if ( isset( $lists[ $k ][ $v ] ) ) {
					$w = $lists[ $k ][ $v ];
				} elseif ( 'nights' === $k ) {
					$w = ogc_app_plural( (int) $v, 'night' );
				} else {
					$w = '6' === $v ? '6 or more' : ogc_app_plural( (int) $v, 'person', 'people' );
				}
				return array( 'v' => $v, 'words' => $w );
			}, $vals ),
		);
	}
	return $out;
}

/* ================================================================== who handles money */

/** The emails the COA ticked "Handles money" for (the access area's list: module-members.php). */
function ogc_money_handlers( $year ) {
	if ( function_exists( 'ogc_member_money_emails' ) ) {
		return ogc_member_money_emails( (int) $year );
	}
	$s = ogc_state_get( (int) $year, 'payment_viewers' );
	return $s ? array_values( array_unique( array_filter( array_map( 'strtolower', (array) $s['value'] ) ) ) ) : array();
}

/**
 * Does the signed-in person handle money for this year? The access area's one rule (module-guard.php,
 * ogc_access( y, 'money' ): ticked by the COA on Members, still on the year, never a webmaster for being
 * one), and never while seeing as (the tick is a person's, not a committee's).
 */
function ogc_money_is_handler( $year, $req = null ) {
	if ( $req instanceof WP_REST_Request && '' !== (string) $req->get_param( 'as' ) ) {
		return false;
	}
	if ( function_exists( 'ogc_access' ) ) {
		return ogc_access( (int) $year, 'money' );
	}
	$me = ogc_current_email();
	return '' !== $me && function_exists( 'ogc_member_me' ) && ogc_member_me( (int) $year ) && in_array( $me, ogc_money_handlers( $year ), true );
}

/** May this person set the tick? The year's COA (the access area's rule; the tick is on Members). */
function ogc_money_can_tick( $year, $req = null ) {
	if ( $req instanceof WP_REST_Request && '' !== (string) $req->get_param( 'as' ) ) {
		return false;
	}
	return function_exists( 'ogc_access_coa' ) ? ogc_access_coa( (int) $year ) : false;
}

/* ================================================================== a household, worked out */

/** What a year's lists share, read once a request: today, the check date, Lodging's rows, the ledger. */
function ogc_rec_ctx( $year ) {
	$year = (int) $year;
	$key  = $year . '|' . ( function_exists( 'ogc_app_today' ) ? ogc_app_today( $year ) : '' );
	if ( isset( $GLOBALS['ogc_rec_ctx'][ $key ] ) ) {
		return $GLOBALS['ogc_rec_ctx'][ $key ];
	}
	$today = function_exists( 'ogc_app_today' ) ? ogc_app_today( $year ) : wp_date( 'Y-m-d' );
	$cfg   = function_exists( 'ogc_reg_cfg' ) ? ogc_reg_cfg( $year ) : array();
	$by    = isset( $cfg['check_by'] ) && preg_match( '/^\d{4}-\d\d-\d\d$/', (string) $cfg['check_by'] ) ? (string) $cfg['check_by'] : '';
	$row   = ogc_year_get( $year );
	$pay   = array();
	if ( function_exists( 'ogc_pay_year' ) ) {
		foreach ( ogc_pay_year( $year ) as $p ) {
			$pay[ $p['record_id'] ][] = $p;
		}
	}
	$marks = ogc_state_get( $year, 'reg_marks' );
	$ctx   = array(
		'year'     => $year,
		'today'    => $today,
		'cfg'      => $cfg,
		'check_by' => $by,
		'closed'   => '' !== $by && $today > $by,
		'start'    => $row && ! empty( $row['start'] ) ? (string) $row['start'] : '',
		'end'      => $row && ! empty( $row['end'] ) ? (string) $row['end'] : '',
		'lod'      => function_exists( 'ogc_lod_rows' ) ? ogc_lod_rows( $year, 'hh:' ) : array(),
		'marks'    => $marks && is_array( $marks['value'] ) ? $marks['value'] : array(),
		'pay'      => $pay,
		'days'     => function_exists( 'ogc_reg_days' ) ? ogc_reg_days( $year ) : array(),
	);
	$GLOBALS['ogc_rec_ctx'][ $key ] = $ctx;
	return $ctx;
}

/** Forget the cached year after a change in this request. */
function ogc_rec_forget( $year ) {
	foreach ( array_keys( (array) ( isset( $GLOBALS['ogc_rec_ctx'] ) ? $GLOBALS['ogc_rec_ctx'] : array() ) ) as $k ) {
		if ( 0 === strpos( $k, (int) $year . '|' ) ) {
			unset( $GLOBALS['ogc_rec_ctx'][ $k ] );
		}
	}
}

function ogc_rec_rid( $rec ) {
	$d = is_array( $rec['data'] ) ? $rec['data'] : array();
	return isset( $d['rid'] ) && '' !== $d['rid'] ? (string) $d['rid'] : ( isset( $d['id'] ) ? (string) $d['id'] : '' );
}

/** The household's status, from the one fixed list. */
function ogc_rec_status_of( $rec, $ctx ) {
	$d   = is_array( $rec['data'] ) ? $rec['data'] : array();
	$st  = isset( $d['status'] ) ? (string) $d['status'] : '';
	$rid = ogc_rec_rid( $rec );
	if ( 'cancelled' === $st ) {
		return 'cancelled';
	}
	if ( 'waitlist' === $st ) {
		return 'waitlist';
	}
	if ( isset( $ctx['marks'][ $rid ]['s'] ) && 'noshow' === $ctx['marks'][ $rid ]['s'] ) {
		return 'noshow';
	}
	$row   = isset( $ctx['lod'][ 'hh:' . $rid ]['data'] ) ? (array) $ctx['lod'][ 'hh:' . $rid ]['data'] : array();
	$given = array_values( array_filter( (array) ( isset( $row['rooms'] ) ? $row['rooms'] : array() ) ) );
	if ( ! empty( $row['checkin']['at'] ) ) {
		$back = isset( $row['back'] ) ? (array) $row['back'] : array();
		$all  = (bool) $given;
		foreach ( $given as $id ) {
			$all = $all && ! empty( $back[ (string) $id ] );
		}
		return $all ? 'checked_out' : 'checked_in';
	}
	return $given ? 'placed' : 'registered';
}

/**
 * The household's money, worked out from its payment lines and its price (never typed, never the
 * page's own figure). Cents throughout:
 *   key       one of ogc_rec_money_words()
 *   total     what it costs (a cancelled one: only the gift it keeps; the waitlist: nothing yet), plus
 *             any refund the treasurer declined (money kept)
 *   paid      money in that counts, less refunds sent
 *   balance   still owed (0 when nothing is)
 *   refund    to give back: refunds asked for and not sent, or what was paid over the total
 *   unasked   paid over the total that no refund asks for yet (the treasurer's Ask refund)
 *   check     checks still to come (0 once the check date has passed: then it's due at check-in)
 */
function ogc_rec_money_of( $rec, $ctx ) {
	$d     = is_array( $rec['data'] ) ? $rec['data'] : array();
	$st    = isset( $d['status'] ) ? (string) $d['status'] : '';
	$rows  = isset( $ctx['pay'][ (int) $rec['id'] ] ) ? $ctx['pay'][ (int) $rec['id'] ] : array();
	$sum   = function_exists( 'ogc_pay_sum' ) ? ogc_pay_sum( $rows ) : array( 'paid' => 0, 'check' => 0, 'pending' => 0, 'refund' => 0, 'refunded' => 0 );
	$late  = 0;
	if ( $sum['check'] > 0 && $ctx['closed'] ) {
		$late         = $sum['check'];
		$sum['check'] = 0;
	}
	$price = (int) ( isset( $d['price']['total_cents'] ) ? $d['price']['total_cents'] : 0 );
	$gift  = (int) ( isset( $d['price']['gift_cents'] ) ? $d['price']['gift_cents'] : 0 );
	// A refund the treasurer declined is money kept: it stays part of what this household paid for (a
	// Leave early whose credit was declined owes nothing and is owed nothing).
	$kept  = 0;
	foreach ( $rows as $p ) {
		$kept += 'refund' === $p['kind'] && 'cancelled' === $p['status'] ? (int) $p['cents'] : 0;
	}
	$total = 'cancelled' === $st ? min( max( 0, $sum['paid'] ), $gift + $kept ) : ( 'waitlist' === $st ? 0 : $price + $kept );
	$paid  = (int) $sum['paid'];
	$bal   = $total - $paid;
	$form  = ! empty( $d['price']['form'] ) && ! $price && ! $paid;
	if ( $form ) {
		// Paid on the Google Form (its own payment add-on): what the Form said, no amount here. Lodging's
		// import keeps the Form's answer as paid · pending · other (its own words) · '' (none).
		$fp  = isset( $d['form']['pay'] ) ? (string) $d['form']['pay'] : '';
		$key = 'paid' === $fp ? 'form_paid' : ( 'pending' === $fp ? 'form_due' : 'form' );
	} elseif ( $sum['refund'] > 0 || $bal < 0 ) {
		$key = 'refund';
	} elseif ( $bal <= 0 ) {
		$key = $sum['refunded'] > 0 ? 'refunded' : ( $total > 0 ? 'paid' : 'none' );
	} elseif ( $sum['check'] > 0 && $sum['check'] >= $bal ) {
		$key = 'check';
	} elseif ( 'checkin' === ( isset( $d['pay'] ) ? $d['pay'] : '' ) || $late > 0 ) {
		$key = 'checkin';
	} elseif ( $paid > 0 ) {
		$key = 'balance';
	} else {
		$key = 'due';
	}
	$words = ogc_rec_money_words();
	return array(
		'key'      => $key,
		'words'    => $words[ $key ],
		'total'    => $total,
		'paid'     => $paid,
		'balance'  => max( 0, $bal ),
		// To give back: what refunds ask for, or what was paid over the total (one and the same money
		// once a refund asks for the overpayment; never added twice).
		'refund'   => max( (int) $sum['refund'], max( 0, -$bal ) ),
		// Paid over the total and not yet asked for by any refund line.
		'unasked'  => max( 0, max( 0, -$bal ) - (int) $sum['refund'] ),
		'refunded' => (int) $sum['refunded'],
		'check'    => (int) $sum['check'],
		'late'     => $late,
		'pending'  => (int) $sum['pending'],
		'gift'     => $gift,
		'form'     => $form,
	);
}

/**
 * What Lodging's screens show as owed (module-app-committees.php, ogc_appc_lod_households): the same
 * Money as Households, so the two lists never disagree. { due, check } in cents, or null when nothing
 * is owed or the household's money was the Form's (Lodging reads the Form's own answer then).
 */
function ogc_rec_money_lodging( $rec, $ctx = null ) {
	$ctx = $ctx ? $ctx : ogc_rec_ctx( (int) $rec['year'] );
	$m   = ogc_rec_money_of( $rec, $ctx );
	if ( in_array( $m['key'], array( 'none', 'form', 'form_due', 'form_paid' ), true ) ) {
		return null;
	}
	return array( 'due' => in_array( $m['key'], array( 'due', 'balance', 'checkin', 'check' ), true ) ? (int) $m['balance'] : 0, 'check' => (int) $m['check'] );
}

/**
 * A History line as someone who doesn't handle money may read it (docs/26 #25: each payment only for
 * Handles money). The lines are the code's own fixed words, never a person's note: a money act's line
 * becomes its plain word ("Payment recorded", "Payment changed", "Refund sent"), and any part naming an
 * amount, a check or card number or who paid is left out. Lines written since Oct 14 are plain already;
 * this covers the older ones and other areas' ("Paid $455 by card", "Paid at the desk · $50").
 */
function ogc_rec_hist_plain( $what ) {
	$w = (string) $what;
	$map = array(
		'Check received'        => 'Payment recorded',
		'Paid at the desk'      => 'Payment recorded',
		'Paid '                 => 'Payment recorded',
		'Check returned'        => 'Payment changed',
		'Card payment disputed' => 'Payment changed',
		'Refunded'              => 'Refund sent',
		'Refund sent'           => 'Refund sent',
		'Refund approved'       => 'Refund approved',
		'Refund asked'          => 'Refund asked',
		'Refund declined'       => 'Refund declined',
	);
	$out = array();
	foreach ( explode( ' · ', $w ) as $seg ) {
		$seg   = trim( $seg );
		$plain = null;
		if ( preg_match( '/^Paid by\s/u', $seg ) ) {
			continue;
		}
		foreach ( $map as $start => $word ) {
			if ( 0 === strpos( $seg, $start ) ) {
				$plain = $word;
				break;
			}
		}
		if ( null !== $plain ) {
			$seg = $plain;
		} elseif ( preg_match( '/\$\s?\d|^No\.\s|^Ref\.\s|^Paid by\s|\bstill owed\b|^of\s\$/u', $seg ) ) {
			continue;
		}
		if ( '' !== $seg && ( ! $out || end( $out ) !== $seg ) ) {
			$out[] = $seg;
		}
	}
	return $out ? implode( ' · ', $out ) : 'Payment changed';
}

/* ------------------------------------------------------------------ call notes (for people, never read) */

/** A household's notes from the COA (a phone call, a letter): state reg_notes {rid: [{id, at, by, uid, text}]}. */
function ogc_rec_notes( $year, $rid = null ) {
	$s = ogc_state_get( (int) $year, 'reg_notes' );
	$v = $s && is_array( $s['value'] ) ? $s['value'] : array();
	return null === $rid ? $v : ( isset( $v[ $rid ] ) && is_array( $v[ $rid ] ) ? $v[ $rid ] : array() );
}

/** The surname a household sorts by. */
function ogc_rec_surname( $d ) {
	$n = isset( $d['household']['name'] ) ? trim( preg_replace( '/^the\s+|\s+(family|household)$/i', '', (string) $d['household']['name'] ) ) : '';
	if ( '' === $n ) {
		$c = isset( $d['household']['contact'] ) ? trim( (string) $d['household']['contact'] ) : '';
		if ( '' === $c && ! empty( $d['people'][0]['name'] ) ) {
			$c = (string) $d['people'][0]['name'];
		}
		$w = preg_split( '/\s+/', $c );
		$n = $w ? (string) end( $w ) : '';
	}
	return $n;
}

/** "Hammond, Levi and Ruth": the surname, then the adults' first names (everyone's, for Young Folks alone). */
function ogc_rec_label( $d ) {
	$sur   = ogc_rec_surname( $d );
	$names = array();
	$all   = array();
	foreach ( isset( $d['people'] ) ? (array) $d['people'] : array() as $p ) {
		if ( empty( $p['name'] ) ) {
			continue;
		}
		$first = strtok( trim( (string) $p['name'] ), ' ' );
		$all[] = $first;
		$kind  = isset( $p['kind'] ) ? $p['kind'] : ( ! empty( $p['yf'] ) ? 'yf' : ( isset( $p['band'] ) && 'adult' === $p['band'] ? 'adult' : 'child' ) );
		if ( 'adult' === $kind ) {
			$names[] = $first;
		}
	}
	$names = $names ? $names : $all;
	if ( ! $names ) {
		return '' !== $sur ? $sur : 'Household';
	}
	$last = array_pop( $names );
	return ( '' !== $sur ? $sur . ', ' : '' ) . ( $names ? implode( ', ', $names ) . ' and ' : '' ) . $last;
}

/** Where they stay, as one of the fixed three (a Young Folk alone in a hall is Dorm: their hall beds). */
function ogc_rec_stay( $d ) {
	$t = isset( $d['stay']['type'] ) ? (string) $d['stay']['type'] : 'dorm';
	return 'yf' === $t ? 'dorm' : ( in_array( $t, array( 'dorm', 'camper', 'elsewhere' ), true ) ? $t : 'dorm' );
}

function ogc_rec_source( $d ) {
	$s = isset( $d['source'] ) ? strtolower( (string) $d['source'] ) : 'online';
	if ( 'online' === $s && ! empty( $d['helper']['on'] ) ) {
		$s = 'helper';
	}
	return array_key_exists( $s, ogc_rec_sources() ) ? $s : 'online';
}

/** The need boxes ticked: ground, stairs, restroom (keys of ogc_rec_needs). */
function ogc_rec_need_keys( $d ) {
	$s   = isset( $d['stay'] ) ? (array) $d['stay'] : array();
	$out = array();
	if ( ! empty( $s['ground'] ) ) {
		$out[] = 'ground';
	}
	if ( ! empty( $s['walker'] ) ) {
		$out[] = 'stairs';
	}
	if ( ! empty( $s['nearW'] ) || ! empty( $s['nearM'] ) || ! empty( $s['restroom'] ) ) {
		$out[] = 'restroom';
	}
	return $out;
}

/** "Fri", "Wed" for an early night. */
function ogc_rec_night_short( $n ) {
	$n = (string) $n;
	if ( 0 === strpos( $n, 'Early ' ) ) {
		$n = substr( $n, 6 );
	}
	return substr( $n, 0, 3 );
}

/** The nights as a few words: "Fri–Tue", or "Fri, Sun" when they skip. */
function ogc_rec_span( $nights, $cfg ) {
	$nights = array_values( (array) $nights );
	if ( ! $nights ) {
		return '';
	}
	$order = function_exists( 'ogc_reg_nights' ) ? ogc_reg_nights( $cfg ) : $nights;
	$idx   = array();
	foreach ( $nights as $n ) {
		$i = array_search( $n, $order, true );
		$idx[] = false === $i ? -1 : $i;
	}
	sort( $idx );
	$run = count( $idx ) > 1 && $idx[0] >= 0 && $idx[ count( $idx ) - 1 ] - $idx[0] === count( $idx ) - 1;
	if ( 1 === count( $nights ) ) {
		return ogc_rec_night_short( $nights[0] );
	}
	if ( $run ) {
		return ogc_rec_night_short( $order[ $idx[0] ] ) . '–' . ogc_rec_night_short( $order[ $idx[ count( $idx ) - 1 ] ] );
	}
	return implode( ', ', array_map( 'ogc_rec_night_short', $nights ) );
}

/** A household as the list draws it: fixed fields only (no email, no note's words). */
function ogc_rec_row( $rec, $ctx ) {
	$d      = is_array( $rec['data'] ) ? $rec['data'] : array();
	$rid    = ogc_rec_rid( $rec );
	$m      = ogc_rec_money_of( $rec, $ctx );
	$status = ogc_rec_status_of( $rec, $ctx );
	$st     = ogc_rec_statuses();
	$stay   = ogc_rec_stay( $d );
	$people = isset( $d['people'] ) ? (array) $d['people'] : array();
	$n      = array( 'adult' => 0, 'yf' => 0, 'child' => 0 );
	foreach ( $people as $p ) {
		$k = isset( $p['kind'] ) && isset( $n[ $p['kind'] ] ) ? $p['kind'] : ( ! empty( $p['yf'] ) ? 'yf' : ( isset( $p['band'] ) && 'adult' === $p['band'] ? 'adult' : 'child' ) );
		$n[ $k ]++;
	}
	$nights = 'elsewhere' === $stay ? (array) ( isset( $d['stay']['days'] ) ? $d['stay']['days'] : array() ) : (array) ( isset( $d['stay']['nights'] ) ? $d['stay']['nights'] : array() );
	$span   = 'elsewhere' === $stay
		? ( $nights ? implode( ', ', array_map( function ( $iso ) { return gmdate( 'D', strtotime( $iso . ' 12:00 UTC' ) ); }, $nights ) ) : '' )
		: ogc_rec_span( $nights, $ctx['cfg'] );
	$created = isset( $d['created'] ) && '' !== $d['created'] ? (string) $d['created'] : ( ! empty( $d['at'] ) ? (string) $d['at'] : (string) $rec['created_at'] );
	// Flags, from the one fixed list (5.10): a key each, and its words.
	$fk = array();
	if ( ! empty( $d['flags']['changed'] ) && 'placed' === $status ) {
		$fk[] = 'changed';
	}
	if ( isset( $d['approval']['state'] ) && 'waiting' === $d['approval']['state'] ) {
		$fk[] = 'notapproved';
	}
	if ( $m['late'] > 0 ) {
		$fk[] = 'late';
	}
	if ( $m['unasked'] > 0 ) {
		$fk[] = 'unasked';
	}
	$fw    = ogc_rec_flags();
	$flags = array_map( function ( $k ) use ( $fw ) { return $fw[ $k ]; }, $fk );
	$src   = ogc_rec_source( $d );
	$row   = array(
		'id'         => (int) $rec['id'],
		'rid'        => $rid,
		'label'      => ogc_rec_label( $d ),
		'sur'        => ogc_rec_surname( $d ),
		'status'     => $status,
		'status_w'   => $st[ $status ],
		'money'      => $m['key'],
		'money_w'    => $m['words'],
		'total'      => $m['total'],
		'paid'       => $m['paid'],
		'balance'    => $m['balance'],
		'refund'     => $m['refund'],
		'check'      => $m['check'],
		'form'       => $m['form'],
		'stay'       => $stay,
		'hall'       => 'yf' === ( isset( $d['stay']['type'] ) ? $d['stay']['type'] : '' ),
		'nights'     => count( $nights ),
		'span'       => $span,
		'size'       => count( $people ),
		'adults'     => $n['adult'],
		'yf'         => $n['yf'],
		'children'   => $n['child'],
		'needs'      => ogc_rec_need_keys( $d ),
		'note'       => '' !== trim( (string) ( isset( $d['stay']['needs'] ) ? $d['stay']['needs'] : '' ) ),
		'source'     => $src,
		'registered' => substr( str_replace( 'T', ' ', $created ), 0, 10 ),
		'contact'    => isset( $d['household']['contact'] ) ? (string) $d['household']['contact'] : '',
		'phone'      => isset( $d['household']['phone'] ) ? (string) $d['household']['phone'] : '',
		'flags'      => $flags,
		'flag_keys'  => $fk,
		'late'       => $m['late'],
		'unasked'    => $m['unasked'],
		'sample'     => ! empty( $rec['sample'] ),
	);
	$row['in'] = ogc_rec_in( $row );
	return $row;
}

/**
 * The household's short name, for the return chip and a filter's pill: "Hoovers" (the surname, as a
 * family is called), or the one person's own name ("Ruth Shirk"). Made from the stored surname only.
 */
function ogc_rec_short( $d ) {
	$sur = ogc_rec_surname( $d );
	$n   = 0;
	$one = '';
	foreach ( isset( $d['people'] ) ? (array) $d['people'] : array() as $p ) {
		if ( ! empty( $p['name'] ) ) {
			$n++;
			$one = (string) $p['name'];
		}
	}
	if ( 1 === $n || '' === $sur ) {
		return '' !== $one ? $one : ( '' !== $sur ? $sur : 'Household' );
	}
	return $sur . ( preg_match( '/(s|x|z|ch|sh)$/i', $sur ) ? 'es' : 's' );
}

/** Every household of a year (the registrations this request may count: a sample dated later isn't). */
function ogc_rec_rows( $year ) {
	$ctx = ogc_rec_ctx( $year );
	$out = array();
	foreach ( ogc_records( (int) $year, 'registrations' ) as $r ) {
		if ( '' === ogc_rec_rid( $r ) || empty( $r['data']['people'] ) ) {
			continue;
		}
		$out[] = ogc_rec_row( $r, $ctx );
	}
	usort( $out, function ( $a, $b ) {
		return strcasecmp( $a['label'], $b['label'] ) ?: strcmp( $a['rid'], $b['rid'] );
	} );
	return $out;
}

/** The registration with this R-number in the year, or null. */
function ogc_rec_by_rid( $year, $rid ) {
	foreach ( ogc_records( (int) $year, 'registrations' ) as $r ) {
		if ( ogc_rec_rid( $r ) === (string) $rid ) {
			return $r;
		}
	}
	return null;
}

/** A user's name as the app says it ("Ruth K."), or "Committee". */
function ogc_rec_who( $uid ) {
	static $memo = array();
	$uid = (int) $uid;
	if ( ! $uid ) {
		return '';
	}
	if ( ! isset( $memo[ $uid ] ) ) {
		$u            = get_userdata( $uid );
		$n            = $u ? trim( (string) $u->display_name ) : '';
		$memo[ $uid ] = '' !== $n && false === strpos( $n, '@' ) ? ( function_exists( 'ogc_first_l' ) ? ogc_first_l( $n ) : $n ) : 'A member';
	}
	return $memo[ $uid ];
}

/** One household whole, for the record panel. The ledger's lines only for someone who handles money. */
function ogc_rec_detail( $rec, $ctx, $handler ) {
	$d    = is_array( $rec['data'] ) ? $rec['data'] : array();
	$row  = ogc_rec_row( $rec, $ctx );
	$cfg  = $ctx['cfg'];
	$s    = isset( $d['stay'] ) ? (array) $d['stay'] : array();
	$rid  = $row['rid'];
	$per  = ! empty( $s['perPerson'] );
	$ppl  = array();
	foreach ( isset( $d['people'] ) ? (array) $d['people'] : array() as $p ) {
		if ( empty( $p['name'] ) ) {
			continue;
		}
		$k     = isset( $p['kind'] ) ? $p['kind'] : ( ! empty( $p['yf'] ) ? 'yf' : 'adult' );
		$ppl[] = array(
			'name'      => (string) $p['name'],
			'kind'      => 'yf' === $k ? 'Young Folk' : ( 'child' === $k ? 'Child' : 'Adult' ),
			'age'       => 'adult' === $k ? '' : (string) ( isset( $p['age'] ) ? $p['age'] : '' ),
			'hall'      => ! empty( $p['yf'] ) && 'family' !== ( isset( $p['sleeps'] ) ? $p['sleeps'] : 'hall' ) ? ( 'women' === ( isset( $p['yfHall'] ) ? $p['yfHall'] : '' ) ? 'Young women’s hall' : 'Young men’s hall' ) : '',
			'communing' => ! empty( $p['communing'] ),
			'preteen'   => ! empty( $p['preteen'] ),
			'nights'    => $per ? ogc_rec_span( isset( $p['nights'] ) ? $p['nights'] : array(), $cfg ) : '',
		);
	}
	$lrow  = isset( $ctx['lod'][ 'hh:' . $rid ]['data'] ) ? (array) $ctx['lod'][ 'hh:' . $rid ]['data'] : array();
	$rooms = array();
	foreach ( (array) ( isset( $lrow['rooms'] ) ? $lrow['rooms'] : array() ) as $id ) {
		$rooms[] = function_exists( 'ogc_lod_room_words' ) ? ogc_lod_room_words( $id ) : (string) $id;
	}
	$arrive = array( 'afternoon' => 'Afternoon', 'evening' => 'Evening', 'late' => 'After 9 PM' );
	$camlen = array( 'short' => 'Short', 'mid' => 'Mid', 'long' => 'Long' );
	$hist   = array();
	$n      = 0;
	$reg    = false;
	$srcw   = ogc_rec_sources();
	$srcw['form'] = 'Import';
	foreach ( (array) ( isset( $d['history'] ) ? $d['history'] : array() ) as $h ) {
		if ( ! is_array( $h ) || empty( $h['what'] ) ) {
			continue;
		}
		// Money acts' details (amounts, numbers, who paid, a returned check) only for who handles money.
		$what   = $handler ? (string) $h['what'] : ogc_rec_hist_plain( $h['what'] );
		$hb     = isset( $h['by'] ) ? (string) $h['by'] : '';
		// How it came, from the fixed list (H11): the household's own change was online.
		$how    = isset( $h['how'] ) && isset( $srcw[ $h['how'] ] ) ? $srcw[ $h['how'] ] : ( 'household' === $hb ? 'Online' : '' );
		$hist[] = array( 'at' => (string) ( isset( $h['at'] ) ? $h['at'] : '' ), 'what' => mb_substr( $what, 0, 160 ), 'by' => 'household' === $hb ? 'Household' : ( 'parent' === $hb ? 'Parent' : 'Committee' ), 'how' => $how, 'o' => $n++ );
		$reg    = $reg || 0 === strpos( (string) $h['what'], 'Registered' );
	}
	// Registered: the first line, from the stored date and how it came (Online · Helper · Paper · Phone ·
	// Desk · Import), when the history doesn't hold it already.
	if ( ! $reg ) {
		$src    = ogc_rec_source( $d );
		$hist[] = array( 'at' => $row['registered'] . ' 00:00:00', 'what' => 'Registered', 'by' => 'helper' === $src ? 'Helper' : ( in_array( $src, array( 'paper', 'phone', 'desk', 'form' ), true ) ? '' : 'Household' ), 'how' => 'form' === $src ? 'Import' : ( isset( $srcw[ $src ] ) ? $srcw[ $src ] : '' ), 'o' => -1 );
	}
	// Placed: Lodging's own record of giving the rooms (who and when it was given), in Lodging's words.
	if ( ! empty( $lrow['rooms'] ) && ! empty( $lrow['given']['at'] ) ) {
		$hist[] = array( 'at' => (string) $lrow['given']['at'], 'what' => 'Placed · ' . implode( ', ', $rooms ), 'by' => isset( $lrow['given']['by'] ) ? (string) $lrow['given']['by'] : '', 'how' => '', 'o' => $n++ );
	}
	if ( isset( $ctx['marks'][ $rid ]['s'] ) ) {
		$mk     = $ctx['marks'][ $rid ];
		$hist[] = array( 'at' => (string) $mk['at'], 'what' => 'Didn’t come', 'by' => isset( $mk['by'] ) ? (string) $mk['by'] : '', 'how' => '', 'o' => $n++ );
	}
	// The COA's own notes (a call, a letter): people's words, shown as written, never searched or read.
	$me = get_current_user_id();
	foreach ( ogc_rec_notes( (int) $rec['year'], $rid ) as $x ) {
		if ( is_array( $x ) && isset( $x['text'] ) ) {
			$hist[] = array( 'at' => (string) $x['at'], 'what' => (string) $x['text'], 'by' => (string) ( isset( $x['by'] ) ? $x['by'] : '' ), 'how' => '', 'note' => (string) $x['id'], 'mine' => (int) ( isset( $x['uid'] ) ? $x['uid'] : 0 ) === $me, 'o' => $n++ );
		}
	}
	// Newest first, by the day each thing happened (a check dated Mar 30 sits at Mar 30).
	usort( $hist, function ( $a, $b ) {
		return strcmp( $b['at'], $a['at'] ) ?: $b['o'] - $a['o'];
	} );
	foreach ( $hist as &$x ) {
		$x['at'] = substr( $x['at'], 0, 10 );
		unset( $x['o'] );
	}
	unset( $x );
	$price = array();
	foreach ( (array) ( isset( $d['price']['lines'] ) ? $d['price']['lines'] : array() ) as $l ) {
		if ( is_array( $l ) && isset( $l['label'] ) ) {
			$price[] = array( 'label' => (string) $l['label'], 'cents' => (int) ( isset( $l['cents'] ) ? $l['cents'] : 0 ) );
		}
	}
	$helper = ! empty( $d['helper']['on'] ) ? array( 'name' => (string) $d['helper']['name'], 'phone' => (string) $d['helper']['phone'], 'email' => (string) $d['helper']['email'] ) : null;
	$apw    = array( 'waiting' => 'Not approved', 'approved' => 'Approved by email', 'declined' => 'Declined' );
	$ap     = isset( $d['approval']['state'] ) ? (string) $d['approval']['state'] : '';
	$m      = ogc_rec_money_of( $rec, $ctx );
	$out    = array_merge( $row, array(
		'short'    => ogc_rec_short( $d ),
		'people'   => $ppl,
		'stay_d'   => array(
			'type'       => isset( $s['type'] ) ? (string) $s['type'] : '',
			'rooms'      => (int) ( isset( $s['rooms'] ) ? $s['rooms'] : 0 ),
			'keys'       => array_values( array_map( 'strval', (array) ( isset( $s['keys'] ) ? $s['keys'] : array() ) ) ),
			'linens'     => (int) ( isset( $s['linens'] ) ? $s['linens'] : 0 ),
			'mattresses' => (int) ( isset( $s['mattresses'] ) ? $s['mattresses'] : 0 ),
			'campers'    => (int) ( isset( $s['campers'] ) ? $s['campers'] : 0 ),
			'camper_len' => isset( $s['camperLen'] ) && isset( $camlen[ $s['camperLen'] ] ) ? $camlen[ $s['camperLen'] ] : '',
			'arrive'     => isset( $s['arrive'] ) && isset( $arrive[ $s['arrive'] ] ) ? $arrive[ $s['arrive'] ] : '',
			'per_person' => $per,
		),
		'rooms_given' => $rooms,
		'note_text'   => (string) ( isset( $s['needs'] ) ? $s['needs'] : '' ),
		'email'       => isset( $d['household']['email'] ) ? (string) $d['household']['email'] : '',
		'helper'      => $helper,
		'approval'    => isset( $apw[ $ap ] ) ? $apw[ $ap ] : '',
		'pay_by'      => isset( $d['pay'] ) && in_array( $d['pay'], array( 'card', 'check', 'checkin', 'form' ), true ) ? (string) $d['pay'] : '',
		'price'       => $price,
		'gift'        => $m['gift'],
		'unasked'     => $m['unasked'],
		'late'        => $m['late'],
		'history'     => array_slice( $hist, 0, 60 ),
		'ledger'      => $handler && function_exists( 'ogc_ledger_line' ) ? array_map( function ( $p ) use ( $ctx, $rid ) { $l = ogc_ledger_line( $p, $ctx ); $l['rid'] = '' !== $l['rid'] ? $l['rid'] : $rid; return $l; }, isset( $ctx['pay'][ (int) $rec['id'] ] ) ? $ctx['pay'][ (int) $rec['id'] ] : array() ) : null,
		'can'         => array(
			'noshow' => ogc_rec_can_mark( $row, $ctx ),
			'money'  => $handler,
			'note'   => true,
		),
	) );
	return $out;
}

/**
 * The household's Linked lines (README 2.7, 4.7; area-households-money 5.6): one per related kind, each
 * counted by stored IDs only, never by comparing names, and each a door to that list filtered to the
 * household with its first row open. A line with nothing, or a kind this viewer can't open, isn't sent.
 *   rooms     the rooms Lodging gave (Lodging's row, hh:<R>) → Rooms with the household open
 *   payments  its payment lines, refunds its refund lines (the ledger's record id) → Money, for whoever
 *             handles money
 *   shifts    the places its people hold, by the registration number each sign-up kept at join (`reg`;
 *             round-shifts R8) → Shifts (today's Helpers) filtered to the household, its first open
 * $v is the request's viewer (ogc_app_req_viewer), so See as gets the role's lines.
 */
function ogc_rec_linked( $rec, $ctx, $handler, $v ) {
	$y    = (int) $rec['year'];
	$rid  = ogc_rec_rid( $rec );
	$out  = array();
	$lrow = isset( $ctx['lod'][ 'hh:' . $rid ]['data'] ) ? (array) $ctx['lod'][ 'hh:' . $rid ]['data'] : array();
	$n    = count( array_filter( (array) ( isset( $lrow['rooms'] ) ? $lrow['rooms'] : array() ) ) );
	if ( $n && ogc_app_can_see( $v, 'lod-rooms' ) ) {
		$out[] = array( 'kind' => 'rooms', 'n' => $n, 'go' => array( 's' => 'lod-rooms', 'id' => $rid ) );
	}
	if ( $handler && ogc_app_can_see( $v, 'money' ) ) {
		$lines = isset( $ctx['pay'][ (int) $rec['id'] ] ) ? $ctx['pay'][ (int) $rec['id'] ] : array();
		usort( $lines, function ( $a, $b ) { return (int) $b['id'] - (int) $a['id']; } );
		$pay  = array_values( array_filter( $lines, function ( $p ) { return 'refund' !== $p['kind']; } ) );
		$back = array_values( array_filter( $lines, function ( $p ) { return 'refund' === $p['kind']; } ) );
		if ( $pay ) {
			$out[] = array( 'kind' => 'payments', 'n' => count( $pay ), 'go' => array( 's' => 'money', 'v' => 'all', 'f' => 'rid:' . $rid, 'id' => 'L' . (int) $pay[0]['id'] ) );
		}
		if ( $back ) {
			$out[] = array( 'kind' => 'refunds', 'n' => count( $back ), 'go' => array( 's' => 'money', 'v' => 'refunds', 'f' => 'rid:' . $rid, 'id' => 'L' . (int) $back[0]['id'] ) );
		}
	}
	if ( ! empty( $v['coa'] ) && ogc_app_can_see( $v, 'shifts' ) && function_exists( 'ogc_vol_household_seats' ) ) {
		$seats = ogc_vol_household_seats( $y, $rid );
		if ( $seats ) {
			$first = $seats[0];
			$out[] = array( 'kind' => 'shifts', 'n' => count( $seats ), 'go' => array( 's' => 'shifts', 'f' => 'household:' . $rid, 'id' => $first['shift'] ) );
		}
	}
	return $out;
}

/** Didn't come: from the Conference's first day, for a household not checked in (Lodging's call; the COA may). */
function ogc_rec_can_mark( $row, $ctx ) {
	return '' !== $ctx['start'] && $ctx['today'] >= $ctx['start'] && in_array( $row['status'], array( 'registered', 'placed', 'noshow' ), true );
}

/* ================================================================== the export (same columns every year) */

function ogc_rec_export_cols() {
	return array( 'Registration', 'Household', 'Status', 'Money', 'Total', 'Paid', 'Balance', 'Refund', 'Stay', 'Nights', 'Nights count', 'People', 'Adults', 'Young Folks', 'Children', 'Ground floor', 'No stairs', 'Near a restroom', 'Note to Lodging', 'Source', 'Registered on', 'Contact', 'Phone' );
}

function ogc_rec_export_row( $r ) {
	$stays = ogc_rec_stays();
	$src   = ogc_rec_sources();
	$d     = function ( $c ) { return number_format( $c / 100, 2, '.', '' ); };
	return array(
		$r['rid'], $r['label'], $r['status_w'], $r['money_w'], $r['form'] ? '' : $d( $r['total'] ), $r['form'] ? '' : $d( $r['paid'] ), $r['form'] ? '' : $d( $r['balance'] ), $r['refund'] ? $d( $r['refund'] ) : '',
		$stays[ $r['stay'] ] . ( $r['hall'] ? ' (hall)' : '' ), $r['span'], $r['nights'], $r['size'], $r['adults'], $r['yf'], $r['children'],
		in_array( 'ground', $r['needs'], true ) ? 'Yes' : '', in_array( 'stairs', $r['needs'], true ) ? 'Yes' : '', in_array( 'restroom', $r['needs'], true ) ? 'Yes' : '',
		$r['note'] ? 'Yes' : '', $src[ $r['source'] ], $r['registered'], $r['contact'], $r['phone'],
	);
}

/** A CSV for Excel: a BOM, and a cell that starts like a formula made harmless. */
function ogc_rec_csv( $cols, $rows ) {
	$cell = function ( $v ) {
		$v = (string) $v;
		if ( preg_match( '/^[=+\-@\t\r]/', $v ) && ! preg_match( '/^-?\d+(\.\d+)?$/', $v ) ) {
			$v = "'" . $v;
		}
		return '"' . str_replace( '"', '""', $v ) . '"';
	};
	$out = array( implode( ',', array_map( $cell, $cols ) ) );
	foreach ( $rows as $r ) {
		$out[] = implode( ',', array_map( $cell, $r ) );
	}
	return "\xEF\xBB\xBF" . implode( "\r\n", $out ) . "\r\n";
}

function ogc_rec_csv_response( $text, $file ) {
	$res = new WP_REST_Response( null, 200 );
	$res->header( 'Content-Type', 'text/csv; charset=utf-8' );
	$res->header( 'Content-Disposition', 'attachment; filename="' . preg_replace( '/[^A-Za-z0-9 ._-]/', '', $file ) . '"' );
	$res->header( 'Cache-Control', 'private, no-store, max-age=0' );
	$res->header( 'X-Content-Type-Options', 'nosniff' );
	add_filter( 'rest_pre_serve_request', function ( $served, $result ) use ( $text, $res ) {
		if ( $result === $res ) {
			echo $text; // phpcs:ignore WordPress.Security.EscapeOutput -- a CSV file, cells quoted above.
			return true;
		}
		return $served;
	}, 10, 2 );
	return $res;
}

/* ================================================================== the screen */

add_filter( 'ogc_app_screens', function ( $s, $year ) {
	// Households after Registration, before Money, in the COA's section.
	$out = array();
	$def = array( 'title' => 'Households', 'section' => 'own', 'who' => array( 'coa' ), 'handable' => true );
	foreach ( $s as $id => $d ) {
		if ( 'money' === $id && ! isset( $out['households'] ) ) {
			$out['households'] = $def;
		}
		$out[ $id ] = $d;
	}
	if ( ! isset( $out['households'] ) ) {
		$out['households'] = $def;
	}
	return $out;
}, 21, 2 );

add_filter( 'ogc_app_screen_opens', function ( $out ) {
	$out['households'] = isset( $out['money'] ) ? $out['money'] : '';
	return $out;
} );

add_filter( 'ogc_pages', function ( $p ) {
	if ( empty( $p['app'] ) ) {
		return $p;
	}
	$p['app']['scripts'][] = 'app/screens/coa-households.js';
	$p['app']['styles'][]  = 'app/screens/coa-records.css';
	return $p;
}, 21 );

/* ================================================================== what needs the treasurer (Home) */

add_filter( 'ogc_app_needs', function ( $rows, $year, $ckey, $ctx ) {
	if ( 'coa' !== $ckey || ! function_exists( 'ogc_pay_year' ) || ! function_exists( 'ogc_ledger_views' ) || ! ogc_money_is_handler( $year ) || ! empty( $ctx['viewer']['as'] ) ) {
		return $rows;
	}
	// One count, one place (Round 3): Money's own views count these lines, so each line's number is the
	// number its view shows ("3 refunds" opens Refunds with 3; "11 checks late" opens Late checks with 11).
	$c    = ogc_rec_ctx( $year );
	$hh   = ogc_rec_rows( $year );
	$lv   = ogc_ledger_views( ogc_ledger_lines( $year, $c, $hh ), $hh, array() );
	$back = $lv['refunds']['n'];
	$ask  = $lv['requested']['n'];
	$late = $lv['late']['n'];
	if ( $back ) {
		$rows[] = array( 'key' => 'money-refunds', 'ckey' => 'coa', 'words' => ogc_app_plural( $back, 'refund' ) . ( $ask ? ' · ' . $ask . ' to approve' : '' ), 'why' => 'Money · Approve, then send', 'go' => array( 's' => 'money', 'v' => 'refunds' ), 'button' => 'Review ' . $back, 'due' => '', 'rank' => 2 );
	}
	if ( $late ) {
		$rows[] = array( 'key' => 'money-late', 'ckey' => 'coa', 'words' => ogc_app_plural( $late, 'check' ) . ' late', 'why' => 'Due ' . ogc_app_md( $c['check_by'], $year ) . ' · Now due at check-in', 'go' => array( 's' => 'money', 'v' => 'late' ), 'button' => 'Open', 'due' => $c['check_by'], 'rank' => 3, 'tone' => 'look' );
	}
	return $rows;
}, 30, 4 );

/* ================================================================== routes */

add_action( 'rest_api_init', function () {
	$Y   = '(?P<year>\d{4})';
	$see = function ( $screen, $write = false ) {
		return function ( WP_REST_Request $req ) use ( $screen, $write ) {
			if ( ! function_exists( 'ogc_app_req_viewer' ) || ! ogc_app_tables_ready() || null === ogc_year_get( (int) $req['year'] ) ) {
				return new WP_Error( 'ogc_not_found', 'Not found.', array( 'status' => 404 ) );
			}
			$v = ogc_app_req_viewer( $req );
			if ( ! ogc_app_can_see( $v, $screen ) ) {
				return ogc_rest_denied();
			}
			if ( $write && $v['as'] ) {
				return new WP_Error( 'ogc_read_only', 'Read only while seeing as', array( 'status' => 403 ) );
			}
			return true;
		};
	};
	register_rest_route( OGC_NS, "/app/$Y/households", array(
		array( 'methods' => 'GET', 'callback' => 'ogc_rec_rest_list', 'permission_callback' => $see( 'households' ) ),
	) );
	register_rest_route( OGC_NS, "/app/$Y/households/(?P<rid>R-\d{4}-\d{1,8})", array(
		array( 'methods' => 'GET', 'callback' => 'ogc_rec_rest_one', 'permission_callback' => $see( 'households' ) ),
	) );
	register_rest_route( OGC_NS, "/app/$Y/households/mark", array(
		array( 'methods' => 'POST', 'callback' => 'ogc_rec_rest_mark', 'permission_callback' => $see( 'households', true ) ),
	) );
	register_rest_route( OGC_NS, "/app/$Y/households/note", array(
		array( 'methods' => 'POST', 'callback' => 'ogc_rec_rest_note', 'permission_callback' => $see( 'households', true ) ),
	) );
} );

/*
 * The state values this area keeps are written only by its own routes and read only through them:
 * reg_marks and reg_notes (the COA's, about households), ledger_undo and ledger_receipts (payment lines
 * as they were, the receipts waiting to go). The generic state route (any member of the year) gets 403.
 */
add_filter( 'rest_request_before_callbacks', function ( $resp, $handler, $req ) {
	if ( is_wp_error( $resp ) || ! preg_match( '#^/' . preg_quote( OGC_NS, '#' ) . '/years/(\d{4})/state/(reg_marks|reg_notes|ledger_undo|ledger_receipts)$#', (string) $req->get_route(), $m ) ) {
		return $resp;
	}
	if ( 'GET' === $req->get_method() && 0 === strpos( $m[2], 'reg_' ) && function_exists( 'ogc_access_coa' ) && ogc_access_coa( (int) $m[1] ) ) {
		return $resp;
	}
	return new WP_Error( 'ogc_forbidden', 'Not allowed.', array( 'status' => 403 ) );
}, 20, 3 );

/** GET app/{y}/households (?format=csv&rids=R-…,R-…) → the list, or its export. */
function ogc_rec_rest_list( WP_REST_Request $req ) {
	$y    = (int) $req['year'];
	$rows = ogc_rec_rows( $y );
	if ( 'csv' === $req->get_param( 'format' ) ) {
		$rids = $req->get_param( 'rids' );
		$want = array_filter( array_map( 'trim', is_array( $rids ) ? array_filter( $rids, 'is_scalar' ) : explode( ',', is_scalar( $rids ) ? (string) $rids : '' ) ), function ( $r ) { return (bool) preg_match( '/^R-\d{4}-\d{1,8}$/', $r ); } );
		if ( $want ) {
			$want = array_flip( array_slice( $want, 0, 5000 ) );
			$rows = array_values( array_filter( $rows, function ( $r ) use ( $want ) { return isset( $want[ $r['rid'] ] ); } ) );
		}
		ogc_log( 'records_export', $y, 'households', array( 'rows' => count( $rows ) ) );
		return ogc_rec_csv_response( ogc_rec_csv( ogc_rec_export_cols(), array_map( 'ogc_rec_export_row', $rows ) ), 'Households ' . $y . ' ' . gmdate( 'Y-m-d' ) . '.csv' );
	}
	$ctx     = ogc_rec_ctx( $y );
	$handler = ogc_money_is_handler( $y, $req );
	// One count, one place (Round 3): the views and the head's counts from every household this viewer
	// may see, before any filter; the filters (f, from the address) only narrow the rows sent, inside that
	// scope. A household named to open (`open`) that a filter would hide drops the filters (area-shell 1.3).
	$views  = ogc_rec_views( $rows );
	$counts = ogc_rec_counts( $rows );
	$f      = ogc_app_parse_f( is_scalar( $req->get_param( 'f' ) ) ? (string) $req->get_param( 'f' ) : '', ogc_rec_f_fields() );
	$open   = is_scalar( $req->get_param( 'open' ) ) ? (string) $req->get_param( 'open' ) : '';
	$kept   = $f ? array_values( array_filter( $rows, function ( $r ) use ( $f ) { return ogc_rec_f_pass( $r, $f ); } ) ) : $rows;
	$drop   = false;
	if ( $f && '' !== $open && ! in_array( $open, wp_list_pluck( $kept, 'rid' ), true ) && in_array( $open, wp_list_pluck( $rows, 'rid' ), true ) ) {
		$f    = array();
		$kept = $rows;
		$drop = true;
	}
	$rows   = $kept;
	// For who handles money: each household's checks still to come (line and amount), so Mark received
	// on ticked households can take each check's amount and number.
	$checks = array();
	if ( $handler ) {
		$ids = array();
		foreach ( $rows as $r ) {
			$ids[ $r['id'] ] = $r['rid'];
		}
		foreach ( $ctx['pay'] as $record => $lines ) {
			foreach ( $lines as $p ) {
				if ( isset( $ids[ $record ] ) && 'check' === $p['kind'] && 'pending' === $p['status'] ) {
					$checks[ $ids[ $record ] ][] = array( 'id' => (int) $p['id'], 'cents' => (int) $p['cents'] );
				}
			}
		}
	}
	if ( function_exists( 'ogc_ledger_receipts_due' ) ) {
		ogc_ledger_receipts_due( $y );
	}
	return rest_ensure_response( array(
		'rows'     => $rows,
		'views'    => $views,
		'counts'   => $counts,
		'filters'  => ogc_rec_f_words( $f ),
		'dropped'  => $drop,
		'today'    => $ctx['today'],
		'check_by' => $ctx['check_by'],
		'start'    => $ctx['start'],
		'end'      => $ctx['end'],
		'money'    => $handler,
		'checks'   => (object) $checks,
		'wait'     => function_exists( 'ogc_ledger_receipt_wait' ) ? (int) ceil( ogc_ledger_receipt_wait() / 60 ) : 0,
		'desk'     => function_exists( 'ogc_access' ) && ogc_access( $y, 'households' ) && '' === (string) $req->get_param( 'as' ) ? ogc_url( 'register', array( 'year' => $y, 'desk' => 1 ) ) : '',
		'lists'    => array(
			'status' => ogc_rec_statuses(),
			'money'  => ogc_rec_money_words(),
			'stay'   => ogc_rec_stays(),
			'needs'  => ogc_rec_needs(),
			'source' => ogc_rec_sources(),
			'flag'   => ogc_rec_flags(),
		),
	) );
}

/** GET app/{y}/households/{rid} → one household whole (the record panel), with its Linked lines. */
function ogc_rec_rest_one( WP_REST_Request $req ) {
	$y   = (int) $req['year'];
	$rec = ogc_rec_by_rid( $y, (string) $req['rid'] );
	if ( ! $rec ) {
		return new WP_Error( 'ogc_not_found', 'Not found.', array( 'status' => 404 ) );
	}
	$ctx            = ogc_rec_ctx( $y );
	$handler        = ogc_money_is_handler( $y, $req );
	$out            = ogc_rec_detail( $rec, $ctx, $handler );
	$out['linked']  = ogc_rec_linked( $rec, $ctx, $handler, ogc_app_req_viewer( $req ) );
	return rest_ensure_response( $out );
}

/** POST app/{y}/households/mark {rid, mark: 'noshow'|''} → Didn't come, or taken back. Logged. */
function ogc_rec_rest_mark( WP_REST_Request $req ) {
	$y    = (int) $req['year'];
	$rec  = ogc_rec_by_rid( $y, is_scalar( $req->get_param( 'rid' ) ) ? (string) $req->get_param( 'rid' ) : '' );
	$mark = is_scalar( $req->get_param( 'mark' ) ) ? (string) $req->get_param( 'mark' ) : 'x';
	if ( ! $rec ) {
		return new WP_Error( 'ogc_not_found', 'Not found.', array( 'status' => 404 ) );
	}
	if ( ! in_array( $mark, array( 'noshow', '' ), true ) ) {
		return new WP_Error( 'ogc_bad', 'Unknown mark', array( 'status' => 400 ) );
	}
	$ctx = ogc_rec_ctx( $y );
	$row = ogc_rec_row( $rec, $ctx );
	if ( ! ogc_rec_can_mark( $row, $ctx ) ) {
		return new WP_Error( 'ogc_not_now', '' === $ctx['start'] || $ctx['today'] < $ctx['start'] ? 'From ' . ogc_app_md( $ctx['start'], $y ) : 'Not for ' . $row['status_w'], array( 'status' => 409 ) );
	}
	$rid = $row['rid'];
	$who = ogc_rec_who( get_current_user_id() );
	$cur = ogc_state_get( $y, 'reg_marks' );
	$val = $cur && is_array( $cur['value'] ) ? $cur['value'] : array();
	if ( '' === $mark ) {
		unset( $val[ $rid ] );
	} else {
		$val[ $rid ] = array( 's' => $mark, 'at' => ogc_now(), 'by' => $who );
	}
	$ok = ogc_state_put( $y, 'reg_marks', (object) $val, $cur ? $cur['version'] : null );
	if ( is_wp_error( $ok ) ) {
		return new WP_Error( 'ogc_conflict', 'Changed since · Try again', array( 'status' => 409 ) );
	}
	ogc_log( '' === $mark ? 'records_unmark' : 'records_mark', $y, 'registrations', array( 'id' => (int) $rec['id'], 'mark' => $mark ) );
	ogc_rec_forget( $y );
	return rest_ensure_response( array( 'ok' => true, 'say' => $row['label'] . ' · ' . ( '' === $mark ? 'Marked back' : 'Didn’t come' ), 'row' => ogc_rec_row( $rec, ogc_rec_ctx( $y ) ) ) );
}

/** A moment in History: the day given (or the app's today, which a shared prototype sets) at this time. */
function ogc_rec_stamp( $year, $day = '' ) {
	$day = preg_match( '/^\d{4}-\d\d-\d\d$/', (string) $day ) ? (string) $day : ( function_exists( 'ogc_app_today' ) ? ogc_app_today( (int) $year ) : gmdate( 'Y-m-d' ) );
	return $day . substr( ogc_now(), 10 );
}

/**
 * POST app/{y}/households/note {rid, text} → a note on the household (a phone call, a letter), dated and
 * signed; {rid, undo: id} takes one's own note back (within a day). People's words: shown as written,
 * never searched, sorted or read by the site. Kept apart from the registration (state reg_notes), so the
 * household's own record and its version don't change. Logged without the words.
 */
function ogc_rec_rest_note( WP_REST_Request $req ) {
	$y    = (int) $req['year'];
	$rec  = ogc_rec_by_rid( $y, is_scalar( $req->get_param( 'rid' ) ) ? (string) $req->get_param( 'rid' ) : '' );
	$undo = is_scalar( $req->get_param( 'undo' ) ) ? (string) $req->get_param( 'undo' ) : '';
	$text = is_scalar( $req->get_param( 'text' ) ) ? trim( sanitize_text_field( (string) $req->get_param( 'text' ) ) ) : '';
	if ( ! $rec ) {
		return new WP_Error( 'ogc_not_found', 'Not found.', array( 'status' => 404 ) );
	}
	if ( '' === $undo && '' === $text ) {
		return new WP_Error( 'ogc_bad', 'Write the note', array( 'status' => 400, 'field' => 'text' ) );
	}
	$rid = ogc_rec_rid( $rec );
	$uid = get_current_user_id();
	for ( $try = 0; $try < 3; $try++ ) {
		$cur  = ogc_state_get( $y, 'reg_notes' );
		$all  = $cur && is_array( $cur['value'] ) ? $cur['value'] : array();
		$list = isset( $all[ $rid ] ) && is_array( $all[ $rid ] ) ? $all[ $rid ] : array();
		if ( '' !== $undo ) {
			$keep = array();
			$hit  = false;
			foreach ( $list as $x ) {
				if ( isset( $x['id'] ) && hash_equals( (string) $x['id'], $undo ) && (int) $x['uid'] === $uid && time() - (int) ( isset( $x['ts'] ) ? $x['ts'] : 0 ) < DAY_IN_SECONDS ) {
					$hit = true;
					continue;
				}
				$keep[] = $x;
			}
			if ( ! $hit ) {
				return new WP_Error( 'ogc_not_found', 'Can’t undo', array( 'status' => 409 ) );
			}
			$list = $keep;
			$say  = 'Note removed';
		} else {
			if ( count( $list ) >= 40 ) {
				return new WP_Error( 'ogc_full', 'Forty notes · The most kept', array( 'status' => 409 ) );
			}
			$note   = array( 'id' => 'n' . strtolower( wp_generate_password( 10, false, false ) ), 'at' => ogc_rec_stamp( $y ), 'ts' => time(), 'uid' => $uid, 'by' => ogc_rec_who( $uid ), 'text' => mb_substr( $text, 0, 400 ) );
			$list[] = $note;
			$say    = ogc_rec_label( $rec['data'] ) . ' · Note added';
		}
		if ( $list ) {
			$all[ $rid ] = $list;
		} else {
			unset( $all[ $rid ] );
		}
		$ok = ogc_state_put( $y, 'reg_notes', (object) $all, $cur ? $cur['version'] : null );
		if ( ! is_wp_error( $ok ) ) {
			ogc_log( '' !== $undo ? 'records_note_off' : 'records_note', $y, 'registrations', array( 'id' => (int) $rec['id'] ) );
			return rest_ensure_response( array( 'ok' => true, 'say' => $say, 'undo' => '' === $undo ? $note['id'] : '' ) );
		}
	}
	return new WP_Error( 'ogc_conflict', 'Changed since · Try again', array( 'status' => 409 ) );
}
