<?php
/**
 * Each committee gets its lists back (lists area, Oct 13 night). The lists are made from the
 * registrations and sign-ups on the server, for one committee and the COA, so nobody copies from a
 * Google Sheet or a SignUpGenius export again. This file adds:
 *
 *   ogc_lst_spec( $list )     every list's columns, fixed: the same every year, in the same order,
 *                             each with what it holds (the workbook's Columns sheet says it)
 *   GET lists/{y}/nursery     Nursery (and the COA): counts by day: under 3, 3 to 5, households with
 *                             one under 3. Counts only, no names.
 *   GET lists/{y}/halls       Youngfolks (and the COA): the Youngfolks in the halls, by hall: age,
 *                             under 18, nights, the room once Lodging has published rooms, and their
 *                             rooming note as typed (a note for people; the site never matches it)
 *   GET lists/{y}/meals/sent  Food (and the COA): every send to the caterer, kept as the record;
 *                             ?at=<when>&format=xlsx downloads one send exactly as it went
 *   ?format=xlsx on every list: the list, then Columns (what each column holds, As of, how many)
 *
 * Mechanical (docs/25): counts are plain sums of plain fields; ages as typed; notes shown as typed and
 * never read. Children's details stay with Preteens and the COA (module-lists.php).
 */

defined( 'ABSPATH' ) || exit;

/* ================================================================== the columns, fixed */

function ogc_lst_spec( $list ) {
	$s = array(
		'meals'     => array( 'title' => 'Meal counts', 'cols' => array(
			array( 'Date', 'The meal’s day, as year-month-day', 12 ),
			array( 'Day', 'Its weekday', 6 ),
			array( 'Meal', 'The meal’s title on the schedule. Communion meal: those communing, from the registrations', 24 ),
			array( 'Time', 'When it’s served, from the schedule', 18 ),
			array( '12 and up', 'People 12 and older here that day, Youngfolks included', 10 ),
			array( '3–11', 'Children 3 to 11 here that day', 8 ),
			array( 'Under 3', 'Children under 3 here that day', 9 ),
			array( 'Total', 'The three together', 8 ),
			array( 'Arriving or leaving', 'How many in the total arrive or leave that day. They’re counted for every meal that day: the form doesn’t ask their first and last meal', 11 ),
			array( 'Change', 'The total less the total in the send before; blank before the first send', 9 ),
			array( 'Note', 'New: not in the send before. Removed: gone from the schedule since. No time: the schedule row has no clock time. Not asked: households from the Lodging Form, which doesn’t ask about communion, so the communion meal leaves them out', 30 ),
		) ),
		'snacks'    => array( 'title' => 'Snacks', 'cols' => array(
			array( 'Date', 'The snack’s day, as year-month-day', 12 ),
			array( 'Day', 'Its weekday', 6 ),
			array( 'Snack', 'Its title on the schedule', 24 ),
			array( 'Time', 'When, from the schedule', 18 ),
			array( 'For', 'Everyone, Preteens or Youngfolks, from the schedule row', 12 ),
			array( 'Here that day', 'How many of them are here that day', 12 ),
		) ),
		'communion' => array( 'title' => 'Communing', 'cols' => array(
			array( 'Household', 'The household’s name', 22 ),
			array( 'Registration', 'The registration’s number', 14 ),
			array( 'Communing', 'How many from the household commune and are here that day', 11 ),
			array( 'Names', 'Who, as registered', 50 ),
		) ),
		'preteens'  => array( 'title' => 'Children', 'cols' => array(
			array( 'Preteen', 'The child’s name, as registered', 22 ),
			array( 'Age', 'As typed on the registration', 6 ),
			array( 'Days here', 'The preteen program’s days the child is here', 16 ),
			array( 'May pick up', 'Who may pick the child up, as the household chose. “Not asked”: the household came from the Lodging Form, which doesn’t ask; confirm with the parent at check-in', 40 ),
			array( 'Parent phone', 'The household’s phone', 14 ),
			array( 'Household', 'The household’s name', 18 ),
			array( 'Registration', 'The registration’s number', 14 ),
		) ),
		'nursery'   => array( 'title' => 'Counts by day', 'cols' => array(
			array( 'Date', 'A day with a service on the schedule (worship, council or communion), as year-month-day', 12 ),
			array( 'Day', 'Its weekday', 6 ),
			array( 'Under 3', 'Children under 3 here that day (the registration’s age group)', 9 ),
			array( '3–5', 'Children whose age is typed as 3, 4 or 5, here that day', 7 ),
			array( 'Households', 'Households with a child under 3 here that day', 11 ),
			array( 'Services', 'How many services that day: rows of kind Worship, Council or Communion for Everyone or Conference', 9 ),
			array( 'First starts', 'When the day’s first service starts', 11 ),
			array( 'Last ends', 'When the day’s last service ends; No end when the schedule gives none', 11 ),
		) ),
		'halls'     => array( 'title' => 'Halls', 'cols' => array(
			array( 'Hall', 'Young men’s or young women’s, as registered', 18 ),
			array( 'Room', 'The room Lodging gave, once Lodging has published rooms; blank before', 14 ),
			array( 'Youngfolk', 'The name, as registered', 22 ),
			array( 'Age', 'As typed on the registration', 6 ),
			array( 'Under 18', 'Yes when registered as under 18', 9 ),
			array( 'Nights', 'The nights in the hall', 14 ),
			array( 'Rooming note', 'Who they asked to room with, as typed. A note for people: the site never matches it', 30 ),
			array( 'Household', 'The household that registered them', 18 ),
			array( 'Registration', 'The registration’s number', 14 ),
		) ),
		'teams'     => array( 'title' => 'Teams', 'cols' => array(
			array( 'Tournament', 'The tournament’s name', 18 ),
			array( 'Team', 'The team’s name, when it gave one', 18 ),
			array( 'Kind', 'Team, or On their own', 12 ),
			array( 'Players', 'Everyone on the team, the captain first', 40 ),
			array( 'Captain', 'The first player', 18 ),
			array( 'Phone', 'The captain’s phone', 14 ),
			array( 'Email', 'The email that signed the team up', 26 ),
			array( 'Rule', 'Yes when the team ticked the tournament’s rule', 7 ),
			array( 'Status', 'Signed up, Late (after sign-ups closed), Withdrawn or Removed', 11 ),
			array( 'No-show', 'Yes when marked at the tournament', 9 ),
			array( 'Signed up', 'When, on the campus’s clock', 18 ),
		) ),
	);
	return isset( $s[ $list ] ) ? $s[ $list ] : null;
}

/** "Fri" for a date. */
function ogc_lst_wd( $iso ) {
	$t = strtotime( (string) $iso . ' 12:00:00 UTC' );
	return $t ? gmdate( 'D', $t ) : '';
}

/** The facts under the Columns: which list, which Conference, as of when, and the list's own. */
function ogc_lst_about( $year, $title, $facts = array() ) {
	return array_merge( array(
		'List'       => $title,
		'Conference' => (int) $year . ' Annual Conference',
		'As of'      => ogc_lst_as_of_long( $year ) . ' (campus time)',
	), array_filter( $facts, function ( $v ) { return '' !== (string) $v; } ) );
}

/**
 * The answer for ?format=xlsx: the list's sheet (and any more), then Columns. Logged, and kept as the
 * list's last download (so "changed since" can show). $more: array( array( list, rows ) ).
 */
function ogc_lst_xlsx_out( $year, $list, $rows, $facts = array(), $more = array(), $file = '', $mark = '' ) {
	// A list of people goes out only as its own committee or the COA, never while seeing as (L23): See as
	// is for checking what a role meets, not for taking names away.
	$as = isset( $_GET['as'] ) ? (string) $_GET['as'] : ''; // phpcs:ignore WordPress.Security.NonceVerification -- a read.
	if ( '' !== $as && in_array( $list, array( 'preteens', 'communion', 'halls', 'teams' ), true ) ) {
		return ogc_lst_err( 'Read only while seeing as', 403 );
	}
	$spec   = ogc_lst_spec( $list );
	$sheets = array( ogc_lst_list_sheet( $spec, $rows ) );
	$extra  = array();
	foreach ( $more as $m ) {
		$s        = ogc_lst_spec( $m[0] );
		$sheets[] = ogc_lst_list_sheet( $s, $m[1] );
		$extra[]  = $s;
	}
	$sheets[] = ogc_lst_columns_sheet( $spec, ogc_lst_about( $year, $spec['title'], $facts ), $extra );
	// A download is logged, never kept as printed: only a Print moves Since printed (Round 6, L8).
	ogc_log( 'list_download', (int) $year, $list, array( 'format' => 'xlsx' ) );
	return ogc_lst_xlsx_response( ogc_lst_xlsx( $sheets ), ogc_lst_file( $year, $file ? $file : $spec['title'] ) );
}

/* ================================================================== meal counts for Excel */

/** One meal as a row of the Meal counts sheet (the view's row). */
function ogc_lst_meal_xrow( $r, $has_last ) {
	$st   = isset( $r['status'] ) ? $r['status'] : '';
	$gone = 'removed' === $st;
	$note = $gone ? 'Removed' : implode( ' · ', array_filter( array( 'new' === $st ? 'New' : '', ! empty( $r['notime'] ) ? 'No time' : '', ! empty( $r['not_asked'] ) ? 'Not asked of ' . (int) $r['not_asked'] . ' households' : '' ) ) );
	$c    = $gone ? array( 'adult' => 0, 'child' => 0, 'baby' => 0 ) : $r['counts'];
	return array(
		(string) $r['date'], ogc_lst_wd( $r['date'] ), (string) $r['title'], (string) $r['when'],
		(int) $c['adult'], (int) $c['child'], (int) $c['baby'], $gone ? 0 : (int) $r['total'],
		$gone ? 0 : (int) ( isset( $r['est'] ) ? $r['est'] : 0 ),
		$has_last ? (int) ( isset( $r['change'] ) ? $r['change'] : $r['total'] ) : '',
		$note,
	);
}

function ogc_lst_snack_xrow( $s ) {
	$who = array( 'preteens' => 'Preteens', 'youngfolks' => 'Youngfolks', 'all' => 'Everyone' );
	return array( (string) $s['date'], ogc_lst_wd( $s['date'] ), (string) $s['title'], (string) $s['when'], isset( $who[ $s['aud'] ] ) ? $who[ $s['aud'] ] : '', (int) $s['count'] );
}

/** One send to the caterer, as it went: its counts, and the change from the send before it. */
function ogc_lst_sent_rows( $v, $before ) {
	$rows = array();
	$seen = array();
	foreach ( (array) $v['counts'] as $k => $c ) {
		$seen[ $k ] = true;
		$t          = (int) $c['adult'] + (int) $c['child'] + (int) $c['baby'];
		$w          = $before && isset( $before['counts'][ $k ] ) ? $before['counts'][ $k ] : null;
		$rows[]     = array(
			'date' => isset( $c['date'] ) ? (string) $c['date'] : substr( $k, 0, 10 ),
			'row'  => array(
				isset( $c['date'] ) ? (string) $c['date'] : substr( $k, 0, 10 ), ogc_lst_wd( isset( $c['date'] ) ? $c['date'] : substr( $k, 0, 10 ) ),
				isset( $c['title'] ) ? (string) $c['title'] : $k, isset( $c['when'] ) ? (string) $c['when'] : '',
				(int) $c['adult'], (int) $c['child'], (int) $c['baby'], $t, isset( $c['est'] ) ? (int) $c['est'] : '',
				$before ? $t - ( $w ? (int) $w['adult'] + (int) $w['child'] + (int) $w['baby'] : 0 ) : '',
				implode( ' · ', array_filter( array( $before && ! $w ? 'New' : '', ! empty( $c['not_asked'] ) ? 'Not asked of ' . (int) $c['not_asked'] . ' households' : '' ) ) ),
			),
		);
	}
	foreach ( $before ? (array) $before['counts'] : array() as $k => $w ) {
		if ( isset( $seen[ $k ] ) ) {
			continue;
		}
		$t      = (int) $w['adult'] + (int) $w['child'] + (int) $w['baby'];
		$d      = isset( $w['date'] ) ? (string) $w['date'] : substr( $k, 0, 10 );
		$rows[] = array( 'date' => $d, 'row' => array( $d, ogc_lst_wd( $d ), isset( $w['title'] ) ? (string) $w['title'] : $k, isset( $w['when'] ) ? (string) $w['when'] : '', 0, 0, 0, 0, '', -$t, 'Removed' ) );
	}
	usort( $rows, function ( $a, $b ) { return strcmp( $a['date'], $b['date'] ); } );
	return array_map( function ( $r ) { return $r['row']; }, $rows );
}

/** Every send, newest first, as the screen lists them (no counts per household). */
function ogc_lst_sends_summary( $year ) {
	$out  = array();
	$list = function_exists( 'ogc_lst_sent' ) ? ogc_lst_sent( $year ) : array();
	foreach ( $list as $i => $v ) {
		$plates = 0;
		$meals  = 0;
		foreach ( (array) $v['counts'] as $k => $c ) {
			if ( false !== strpos( (string) $k, ':communion-meal' ) ) {
				continue;
			}
			$plates += (int) $c['adult'] + (int) $c['child'] + (int) $c['baby'];
			$meals++;
		}
		$out[] = array(
			'at'     => (string) $v['at'],
			'day'    => (string) $v['day'],
			'by'     => (string) $v['by'],
			'how'    => (string) $v['how'],
			'to'     => isset( $v['to'] ) ? (string) $v['to'] : '',
			'final'  => ! empty( $v['final'] ),
			'meals'  => $meals,
			'plates' => $plates,
			'change' => isset( $list[ $i + 1 ] ) ? $plates - array_sum( array_map( function ( $c ) { return (int) $c['adult'] + (int) $c['child'] + (int) $c['baby']; }, array_filter( (array) $list[ $i + 1 ]['counts'], function ( $c, $k ) { return false === strpos( (string) $k, ':communion-meal' ); }, ARRAY_FILTER_USE_BOTH ) ) ) : null,
		);
	}
	return $out;
}

/** GET lists/{y}/meals/sent: every send; ?at=&format=xlsx one send as it went. */
function ogc_lst_rest_sent( WP_REST_Request $req ) {
	$y    = (int) $req['year'];
	$at   = (string) $req->get_param( 'at' );
	$list = ogc_lst_sent( $y );
	if ( '' === $at ) {
		return rest_ensure_response( array( 'sends' => ogc_lst_sends_summary( $y ) ) );
	}
	foreach ( $list as $i => $v ) {
		if ( (string) $v['at'] !== $at ) {
			continue;
		}
		$before = isset( $list[ $i + 1 ] ) ? $list[ $i + 1 ] : null;
		$rows   = ogc_lst_sent_rows( $v, $before );
		// Without ?format=xlsx: the same rows for the screen to print exactly what went.
		if ( 'xlsx' !== (string) $req->get_param( 'format' ) ) {
			ogc_log( 'list_view', $y, 'meals_sent', array( 'at' => $v['at'] ) );
			return rest_ensure_response( array(
				'cols'   => array_map( function ( $c ) { return $c[0]; }, ogc_lst_spec( 'meals' )['cols'] ),
				'rows'   => $rows,
				'before' => $before ? (string) $before['day'] : '',
			) );
		}
		$facts  = array(
			'Sent'       => date_i18n( 'M j, Y', strtotime( $v['day'] . ' 12:00:00' ) ) . ( $v['by'] ? ' by ' . $v['by'] : '' ),
			'How'        => 'email' === $v['how'] ? 'Emailed to ' . ( isset( $v['to'] ) ? $v['to'] : 'the caterer' ) : 'Marked as sent',
			'Final'      => ! empty( $v['final'] ) ? 'Yes' : 'No',
			'Change'     => $before ? 'Against the send of ' . date_i18n( 'M j', strtotime( $before['day'] . ' 12:00:00' ) ) : 'The first send',
		);
		ogc_log( 'list_download', $y, 'meals_sent', array( 'at' => $v['at'] ) );
		$spec   = ogc_lst_spec( 'meals' );
		$sheets = array( ogc_lst_list_sheet( $spec, $rows, 'Sent ' . date_i18n( 'M j', strtotime( $v['day'] . ' 12:00:00' ) ) ), ogc_lst_columns_sheet( $spec, ogc_lst_about( $y, 'Meal counts as sent', $facts ) ) );
		return ogc_lst_xlsx_response( ogc_lst_xlsx( $sheets ), ogc_lst_file( $y, 'Meal counts sent ' . $v['day'] ) );
	}
	return ogc_lst_err( 'No such send', 404 );
}

/* ================================================================== Nursery: counts by day */

/** Is this person under 3 (the registration's age group), or typed as 3 to 5? '' when neither. */
function ogc_lst_little( $p ) {
	$age = trim( (string) ( isset( $p['age'] ) ? $p['age'] : '' ) );
	$n   = is_numeric( $age ) ? (float) $age : null;
	if ( 'baby' === ( isset( $p['band'] ) ? $p['band'] : '' ) || ( null !== $n && $n < 3 && 'adult' !== ( isset( $p['kind'] ) ? $p['kind'] : '' ) ) ) {
		return 'under3';
	}
	if ( null !== $n && $n >= 3 && $n < 6 && 'child' === ( isset( $p['kind'] ) ? $p['kind'] : 'child' ) ) {
		return 'small';
	}
	return '';
}

/**
 * The Conference's days with a service on the schedule (a row of kind worship, council or communion for
 * everyone): the days the nursery is wanted. Not the check-out morning (critique: Wed Jun 2 was counted).
 * By the rows' kind, never their titles. No such row yet: every day.
 */
function ogc_lst_service_days( $year, $days ) {
	$f   = ogc_file_get( (int) $year, 'schedule' );
	$out = array();
	foreach ( $f ? $f['rows'] : array() as $r ) {
		$kind = strtolower( trim( isset( $r['kind'] ) ? (string) $r['kind'] : '' ) );
		$aud  = strtolower( trim( isset( $r['audience'] ) ? (string) $r['audience'] : '' ) );
		if ( ! in_array( $kind, array( 'worship', 'council', 'communion' ), true ) || 0 === strpos( $aud, 'pre' ) || 0 === strpos( $aud, 'young' ) || 'yf' === $aud ) {
			continue;
		}
		$i = ogc_lst_day_index( $days, isset( $r['day'] ) ? $r['day'] : '' );
		if ( $i >= 0 ) {
			$out[ $days[ $i ]['date'] ] = true;
		}
	}
	return $out ? array_values( array_filter( $days, function ( $d ) use ( $out ) { return isset( $out[ $d['date'] ] ); } ) ) : $days;
}

function ogc_lst_view_nursery( $year, $ctx, $req ) {
	$all    = function_exists( 'ogc_reg_days' ) ? ogc_reg_days( (int) $year ) : array();
	$days   = ogc_lst_service_days( $year, $all );
	$svc    = function_exists( 'ogc_lst_services' ) ? ogc_lst_services( $year ) : array();
	$prints = function_exists( 'ogc_lst_prints' ) ? ogc_lst_prints( $year, 'nursery' ) : array();
	$rows   = array();
	foreach ( $days as $d ) {
		$rows[ $d['date'] ] = array( 'date' => $d['date'], 'name' => $d['name'], 'under3' => 0, 'small' => 0, 'households' => 0 );
	}
	$tot  = array( 'under3' => 0, 'small' => 0, 'households' => 0 );
	$regs = ogc_lst_regs( $year );
	foreach ( $regs as $rec ) {
		$here = ogc_lst_here( $rec, $all );
		$hh   = array();
		$any  = false;
		foreach ( (array) $rec['data']['people'] as $p ) {
			$k = ogc_lst_little( $p );
			if ( '' === $k || empty( $p['pid'] ) ) {
				continue;
			}
			$tot[ $k ]++;
			$any = $any || 'under3' === $k;
			foreach ( isset( $here[ $p['pid'] ] ) ? (array) $here[ $p['pid'] ] : array() as $date ) {
				if ( isset( $rows[ $date ] ) ) {
					$rows[ $date ][ $k ]++;
					if ( 'under3' === $k ) {
						$hh[ $date ] = true;
					}
				}
			}
		}
		$tot['households'] += $any ? 1 : 0;
		foreach ( array_keys( $hh ) as $date ) {
			$rows[ $date ]['households']++;
		}
	}
	// Each day: its services (how many, first start to last end, each one), and against the paper:
	// Changed since printed when its numbers differ from the newest print (a counts list: no names).
	foreach ( $rows as $date => &$r ) {
		$list         = isset( $svc[ $date ] ) ? $svc[ $date ] : array();
		$r['key']     = $date;
		$r['services'] = $list;
		$r['span']    = function_exists( 'ogc_lst_services_span' ) ? ogc_lst_services_span( $list ) : '';
		$r['sig']     = $r['under3'] . '|' . $r['small'] . '|' . $r['households'];
		$r['since']   = function_exists( 'ogc_lst_since_of' ) ? ogc_lst_since_of( $prints, $date, $r['sig'] ) : '';
		$r['was']     = '';
		foreach ( $prints as $pp ) {
			if ( isset( $pp['sig'][ $date ] ) ) {
				$w        = explode( '|', $pp['sig'][ $date ] );
				$r['was'] = 'changed' === $r['since'] ? 'Was ' . (int) $w[0] . ' under 3 · ' . (int) $w[1] . ' ages 3–5' : '';
				break;
			}
		}
	}
	unset( $r );
	$rows = array_values( $rows );
	$fmt  = (string) $req->get_param( 'format' );
	if ( 'xlsx' === $fmt || 'csv' === $fmt ) {
		$x = array_map( function ( $r ) {
			$first = '';
			$last  = '';
			foreach ( $r['services'] as $s ) {
				$first = '' === $first && null !== $s['start'] ? ogc_lst_hm( $s['start'] ) : $first;
				$last  = null !== $s['end'] ? ogc_lst_hm( $s['end'] ) : 'No end';
			}
			return array( $r['date'], ogc_lst_wd( $r['date'] ), $r['under3'], $r['small'], $r['households'], count( $r['services'] ), $first, $last );
		}, $rows );
		if ( 'csv' === $fmt ) {
			ogc_log( 'list_download', (int) $year, 'nursery', array() );
			return ogc_lst_csv_response( ogc_lst_csv( array_map( function ( $c ) { return $c[0]; }, ogc_lst_spec( 'nursery' )['cols'] ), $x ), ogc_lst_file( $year, 'Counts by day', 'csv' ) );
		}
		return ogc_lst_xlsx_out( $year, 'nursery', $x, array( 'Under 3' => $tot['under3'], '3–5' => $tot['small'], 'Households' => $tot['households'] . ' with a child under 3', 'Days' => count( $days ) < count( $all ) ? 'Days with a service on the schedule' : '', 'From' => count( $regs ) . ' registrations' ), array(), 'Nursery counts by day' );
	}
	$out = array(
		'days'         => array_map( function ( $r ) use ( $req ) {
			if ( ! ( $req instanceof WP_REST_Request && $req->get_param( 'sigs' ) ) ) {
				unset( $r['sig'] );
			}
			return $r;
		}, $rows ),
		'under3'       => $tot['under3'],
		'small'        => $tot['small'],
		'households'   => $tot['households'],
		'service_days' => count( $days ) < count( $all ),
		'as_of'        => ogc_lst_as_of( $year ),
		'print'        => function_exists( 'ogc_lst_last_print' ) ? ogc_lst_last_print( $prints ) : null,
		'since'        => count( array_filter( $rows, function ( $r ) { return '' !== $r['since']; } ) ),
	);
	$out['fact'] = function_exists( 'ogc_lst_fact_words_nursery' ) ? ogc_lst_fact_words_nursery( $out, $ctx ) : null;
	return $out;
}

/* ================================================================== Youngfolks: the halls */

function ogc_lst_in_hall( $p, $d ) {
	return ! empty( $p['yf'] ) && ( 'yf' === ( isset( $d['stay']['type'] ) ? $d['stay']['type'] : '' ) || 'family' !== ( isset( $p['sleeps'] ) ? $p['sleeps'] : '' ) );
}

/** Nights as words: "Fri–Tue" when they run together, else "Fri, Sun"; an early night "Early Thu". */
function ogc_lst_night_words( $list, $order ) {
	$short = function ( $n ) {
		$n = (string) $n;
		return 0 === strpos( $n, 'Early ' ) ? 'Early ' . substr( $n, 6, 3 ) : substr( $n, 0, 3 );
	};
	$idx = array();
	foreach ( (array) $list as $n ) {
		$i = array_search( $n, $order, true );
		$idx[] = false === $i ? 999 : $i;
	}
	if ( ! $idx ) {
		return '';
	}
	array_multisort( $idx, $list );
	$run = count( $idx ) > 2 && end( $idx ) - $idx[0] === count( $idx ) - 1 && 999 !== end( $idx );
	return $run ? $short( $list[0] ) . '–' . $short( end( $list ) ) : implode( ', ', array_map( $short, $list ) );
}

function ogc_lst_hall_label( $k ) {
	return 'men' === $k ? 'Young men’s hall' : ( 'women' === $k ? 'Young women’s hall' : 'Hall not set' );
}

/** A Youngfolk's parent approval, in Lodging's words, from the registration's own fields ('' when none). */
function ogc_lst_approval_words( $p, $d ) {
	if ( empty( $p['minor'] ) ) {
		return '';
	}
	if ( ! empty( $d['stay']['yfOk'] ) ) {
		return 'Parent registered them';
	}
	$st = isset( $d['approval']['state'] ) ? (string) $d['approval']['state'] : '';
	$w  = array( 'waiting' => 'Waiting', 'approved' => 'Approved', 'declined' => 'Declined' );
	return isset( $w[ $st ] ) ? $w[ $st ] : '';
}

function ogc_lst_view_halls( $year, $ctx, $req ) {
	$pub    = function_exists( 'ogc_lod_summary' ) ? ogc_lod_summary( (int) $year )['published'] : '';
	// Each Youngfolk's room only to those who may see where Youngfolks sleep (ogc_access yf_rooms).
	$lrows  = $pub && function_exists( 'ogc_lod_rows' ) && function_exists( 'ogc_access' ) && ogc_access( (int) $year, 'yf_rooms' ) ? ogc_lod_rows( (int) $year, 'yf:' ) : array();
	$prints = function_exists( 'ogc_lst_prints' ) ? ogc_lst_prints( $year, 'halls' ) : array();
	$link   = function_exists( 'ogc_lst_hh_link' ) && ogc_lst_hh_link( $year, $req );
	$rows   = array();
	$fam    = 0;
	$regs   = ogc_lst_regs( $year );
	foreach ( $regs as $rec ) {
		$d     = $rec['data'];
		$cfg   = function_exists( 'ogc_reg_cfg_for' ) ? ogc_reg_cfg_for( (int) $year, $d ) : array();
		$order = function_exists( 'ogc_reg_nights' ) ? ogc_reg_nights( $cfg ) : array();
		foreach ( (array) $d['people'] as $p ) {
			if ( empty( $p['yf'] ) || empty( $p['name'] ) ) {
				continue;
			}
			if ( ! ogc_lst_in_hall( $p, $d ) ) {
				$fam++;
				continue;
			}
			$pid    = isset( $p['pid'] ) ? (string) $p['pid'] : '';
			$rid    = isset( $d['rid'] ) ? (string) $d['rid'] : '';
			$hall   = isset( $p['yfHall'] ) && in_array( $p['yfHall'], array( 'men', 'women' ), true ) ? $p['yfHall'] : '';
			$room   = $pid && isset( $lrows[ 'yf:' . $pid ]['data']['room'] ) && '' !== (string) $lrows[ 'yf:' . $pid ]['data']['room'] ? (string) $lrows[ 'yf:' . $pid ]['data']['room'] : '';
			$nights = function_exists( 'ogc_reg_nights_for' ) ? (array) ogc_reg_nights_for( $p, array_merge( array( 'stay' => array() ), $d ), $cfg ) : array();
			$note   = isset( $p['rooming'] ) ? (string) $p['rooming'] : '';
			$key    = $rid . ':' . $pid;
			$nw     = ogc_lst_night_words( $nights, $order );
			$sig    = function_exists( 'ogc_lst_row_sig' ) ? ogc_lst_row_sig( array( (string) $p['name'], isset( $p['age'] ) ? (string) $p['age'] : '', $hall, $nw, $room, ! empty( $p['minor'] ) ) ) : '';
			$hist   = function_exists( 'ogc_lst_hist_of' ) ? ogc_lst_hist_of( $prints, $key ) : array();
			$appr   = ogc_lst_approval_words( $p, $d );
			if ( function_exists( 'ogc_lst_registered' ) ) {
				$hist[] = ogc_lst_registered( $rec );
			}
			$rows[] = array(
				'key'       => $key,
				'pid'       => $pid,
				'name'      => (string) $p['name'],
				'age'       => isset( $p['age'] ) ? (string) $p['age'] : '',
				'minor'     => ! empty( $p['minor'] ),
				'hall'      => $hall,
				'room'      => $room ? ogc_lod_room_words( $room ) : '',
				'roomsort'  => $room,
				'nights'    => $nw,
				'nightsAll' => array_values( $nights ),
				'order'     => array_values( $order ),
				'some'      => $order && count( array_diff( function_exists( 'ogc_reg_main_nights' ) ? ogc_reg_main_nights( $cfg ) : array(), $nights ) ) > 0,
				'rooming'   => function_exists( 'ogc_appc_names_only' ) ? ogc_appc_names_only( $note ) : trim( wp_strip_all_tags( $note ) ),
				'approval'  => $appr,
				'household' => ogc_lst_label( $d ),
				'rid'       => $rid,
				'since'     => function_exists( 'ogc_lst_since_of' ) ? ogc_lst_since_of( $prints, $key, $sig ) : '',
				'hist'      => $hist,
				'linked'    => $link ? array( array( 'kind' => 'household', 'go' => array( 's' => 'households', 'id' => $rid ) ) ) : array(),
				'sig'       => $sig,
				'sort'      => ogc_lst_last_word( $p['name'] ) . ' ' . strtolower( (string) $p['name'] ),
			);
		}
	}
	$rank = array( 'men' => 0, 'women' => 1, '' => 2 );
	usort( $rows, function ( $a, $b ) use ( $rank ) {
		return ( $rank[ $a['hall'] ] - $rank[ $b['hall'] ] ) ?: ( strnatcasecmp( $a['roomsort'] ? $a['roomsort'] : '~', $b['roomsort'] ? $b['roomsort'] : '~' ) ?: strcmp( $a['sort'], $b['sort'] ) );
	} );
	$fmt = (string) $req->get_param( 'format' );
	if ( 'xlsx' === $fmt ) {
		$x = array_map( function ( $r ) {
			return array( ogc_lst_hall_label( $r['hall'] ), $r['room'], $r['name'], is_numeric( $r['age'] ) ? (int) $r['age'] : $r['age'], $r['minor'] ? 'Yes' : '', $r['nights'], $r['rooming'], $r['household'], $r['rid'] );
		}, function_exists( 'ogc_lst_only' ) ? ogc_lst_only( $rows, $req ) : $rows );
		$n = array( 'men' => 0, 'women' => 0 );
		foreach ( $rows as $r ) {
			if ( isset( $n[ $r['hall'] ] ) ) {
				$n[ $r['hall'] ]++;
			}
		}
		return ogc_lst_xlsx_out( $year, 'halls', $x, array(
			'Young men’s hall'   => $n['men'],
			'Young women’s hall' => $n['women'],
			'Rooms'              => $pub ? 'As Lodging published them, ' . date_i18n( 'M j', strtotime( $pub . ' 12:00:00' ) ) : 'Not published by Lodging yet',
			'With their family'  => $fam ? $fam . ' Youngfolks sleep in their family’s room (not listed)' : '',
		), array(), 'Youngfolks halls' );
	}
	$sigs  = $req instanceof WP_REST_Request && $req->get_param( 'sigs' );
	$halls = array();
	foreach ( array( 'men', 'women', '' ) as $k ) {
		$list = array_values( array_filter( $rows, function ( $r ) use ( $k ) { return $r['hall'] === $k; } ) );
		if ( ! $list ) {
			continue;
		}
		$halls[] = array(
			'key'    => '' === $k ? 'none' : $k,
			'label'  => ogc_lst_hall_label( $k ),
			'n'      => count( $list ),
			'minors' => count( array_filter( $list, function ( $r ) { return $r['minor']; } ) ),
			'rows'   => array_map( function ( $r ) use ( $sigs ) { unset( $r['sort'], $r['roomsort'] ); if ( ! $sigs ) { unset( $r['sig'] ); } return $r; }, $list ),
		);
	}
	if ( $rows && ! ( function_exists( 'ogc_lst_quiet' ) && ogc_lst_quiet( $req ) ) ) {
		static $logged = false;
		if ( ! $logged ) {
			$logged = true;
			ogc_log( 'list_view', (int) $year, 'halls', array( 'n' => count( $rows ) ) );
		}
	}
	$out = array(
		'halls'     => $halls,
		'total'     => count( $rows ),
		'family'    => $fam,
		'published' => $pub,
		'rooms'     => (bool) array_filter( $rows, function ( $r ) { return '' !== $r['room']; } ),
		'as_of'     => ogc_lst_as_of( $year ),
		'print'     => function_exists( 'ogc_lst_last_print' ) ? ogc_lst_last_print( $prints ) : null,
		'since'     => count( array_filter( $rows, function ( $r ) { return '' !== $r['since']; } ) ),
	);
	$out['fact'] = function_exists( 'ogc_lst_fact_words_halls' ) ? ogc_lst_fact_words_halls( $out, $ctx ) : null;
	return $out;
}

/* ================================================================== the routes, and who may */

/** Which app screen a list belongs to (its committee's; the COA opens every one). */
function ogc_lst_view_screen( $view ) {
	$m = array( 'meals' => 'food-meals', 'communion' => 'communion-list', 'preteens' => 'preteens-list', 'medical' => 'preteens-list', 'nursery' => 'nursery-list', 'halls' => 'yf-halls', 'payments' => 'money', 'callin' => 'callin' );
	return isset( $m[ $view ] ) ? $m[ $view ] : '';
}

add_action( 'rest_api_init', function () {
	$Y = '(?P<year>\d{4})';
	register_rest_route( OGC_NS, "/lists/$Y/(?P<view>nursery|halls)", array(
		'methods'             => 'GET',
		'callback'            => 'ogc_lst_rest_view',
		'permission_callback' => function ( WP_REST_Request $q ) {
			if ( ! ogc_valid_year( $q['year'] ) ) {
				return ogc_rest_denied();
			}
			if ( function_exists( 'ogc_appc_can' ) ) {
				return ogc_appc_can( $q, ogc_lst_view_screen( (string) $q['view'] ) );
			}
			return ogc_is_member( $q['year'] ) ? true : ogc_rest_denied();
		},
	) );
	// Every send to the caterer (the guard in module-app-committees.php gives /lists/{y}/meals… to Food
	// and the COA only).
	register_rest_route( OGC_NS, "/lists/$Y/meals/sent", array(
		'methods'             => 'GET',
		'callback'            => 'ogc_lst_rest_sent',
		'permission_callback' => function ( WP_REST_Request $q ) {
			if ( ! ogc_valid_year( $q['year'] ) ) {
				return ogc_rest_denied();
			}
			return function_exists( 'ogc_appc_can' ) ? ogc_appc_can( $q, 'food-meals' ) : ( ogc_is_member( $q['year'] ) ? true : ogc_rest_denied() );
		},
	) );
} );

/* ================================================================== the app: screens, seasons, lines */

add_filter( 'ogc_app_screens', function ( $s, $year ) {
	$own = function ( $title, $who, $icon ) {
		return array( 'title' => $title, 'section' => 'own', 'who' => (array) $who, 'handable' => false, 'coa_opens' => true, 'icon' => $icon );
	};
	$s['yf-halls']     = $own( 'Halls', 'young folks', 'bunk' );
	$s['nursery-list'] = $own( 'Counts by day', 'nursery', 'pram' );
	return $s;
}, 21, 2 );

// In season with the other lists: when registration opens (or once there's a registration).
add_filter( 'ogc_app_screen_opens', function ( $out ) {
	$at = isset( $out['preteens-list'] ) ? $out['preteens-list'] : '';
	$out['yf-halls']     = $at;
	$out['nursery-list'] = $at;
	return $out;
}, 10, 1 );

// The lists' own look (after the committees' styles).
add_filter( 'ogc_pages', function ( $p ) {
	if ( isset( $p['app'] ) ) {
		$p['app']['styles'][] = 'app/screens/committee-lists.css';
	}
	return $p;
}, 21 );

/** A committee page's line for each list ("60 preteens", "Sent Mar 3"). Counts only. */
add_filter( 'ogc_appc_work_line', function ( $line, $y, $id, $c ) {
	// The lists' own facts answer for their screens (Round 6, module-lists-facts.php).
	if ( '' !== $line || ! function_exists( 'ogc_lst_regs' ) || in_array( $id, array( 'food-meals', 'preteens-list', 'communion-list', 'nursery-list', 'yf-halls' ), true ) ) {
		return $line;
	}
	$n = function ( $key ) use ( $y ) {
		$k = 0;
		foreach ( ogc_lst_regs( $y ) as $r ) {
			foreach ( (array) $r['data']['people'] as $p ) {
				if ( 'little' === $key ) {
					$k += 'under3' === ogc_lst_little( $p ) ? 1 : 0;
				} elseif ( 'hall' === $key ) {
					$k += ogc_lst_in_hall( $p, $r['data'] ) ? 1 : 0;
				} else {
					$k += ! empty( $p[ $key ] ) ? 1 : 0;
				}
			}
		}
		return $k;
	};
	$cl = ogc_lst_state( $y, 'lists_cleared', null );
	if ( $cl && in_array( $id, array( 'food-meals', 'preteens-list', 'communion-list', 'nursery-list', 'yf-halls' ), true ) ) {
		return 'Counts only';
	}
	switch ( $id ) {
		case 'food-meals':
			$sent = ogc_lst_sent( $y );
			$set  = ogc_lst_state( $y, 'lists_settings' );
			if ( $sent ) {
				return ( ! empty( $sent[0]['final'] ) ? 'Final sent ' : 'Sent ' ) . ogc_lst_md( $sent[0]['day'] );
			}
			return ! empty( $set['counts_due'] ) ? 'Due ' . ogc_lst_md( $set['counts_due'] ) : ( ogc_lst_regs( $y ) ? 'Not sent' : '' );
		case 'preteens-list':
			$k = $n( 'preteen' );
			return $k ? $k . ' ' . ( 1 === $k ? 'preteen' : 'preteens' ) : '';
		case 'communion-list':
			$k = $n( 'communing' );
			return $k ? $k . ' communing' : '';
		case 'nursery-list':
			$k = $n( 'little' );
			return $k ? $k . ' under 3' : '';
		case 'yf-halls':
			$k = $n( 'hall' );
			return $k ? $k . ' in the halls' : '';
		case 'yf-teams':
			if ( function_exists( 'ogc_tn_teams' ) ) {
				$k = 0;
				foreach ( ogc_tn_teams( $y ) as $t ) {
					$k += 'active' === ( isset( $t['data']['status'] ) ? $t['data']['status'] : 'active' ) ? 1 : 0;
				}
				return $k ? $k . ' ' . ( 1 === $k ? 'team' : 'teams' ) : '';
			}
	}
	return $line;
}, 10, 4 );

function ogc_lst_md( $iso ) {
	$t = strtotime( (string) $iso . ' 12:00:00 UTC' );
	return $t ? gmdate( 'M j', $t ) : '';
}

// The year in counts, kept when its people are cleared, includes the new lists' numbers.
add_filter( 'ogc_lists_record', function ( $rec, $year ) {
	$u3   = 0;
	$hall = 0;
	foreach ( ogc_lst_regs( $year ) as $r ) {
		foreach ( (array) $r['data']['people'] as $p ) {
			$u3   += 'under3' === ogc_lst_little( $p ) ? 1 : 0;
			$hall += ogc_lst_in_hall( $p, $r['data'] ) ? 1 : 0;
		}
	}
	$rec['under3'] = $u3;
	$rec['halls']  = $hall;
	return $rec;
}, 10, 2 );

/*
 * What the caterer was sent (with how many from each registration), when each list was printed, and
 * the caterer's address: read through the lists' own routes (each list's committee and the COA). The
 * year's generic state route gave them to every member of the year.
 */
add_filter( 'rest_request_before_callbacks', function ( $res, $handler, $req ) {
	if ( is_wp_error( $res ) || 'GET' !== $req->get_method() ) {
		return $res;
	}
	if ( preg_match( '#^/' . preg_quote( OGC_NS, '#' ) . '/years/(\d{4})/state/(meals_sent|lists_printed|lists_prints|lists_settings)$#', (string) $req->get_route(), $m ) ) {
		$v = function_exists( 'ogc_app_viewer' ) ? ogc_app_viewer( (int) $m[1] ) : array( 'coa' => false );
		if ( ! $v['coa'] && ! ogc_is_webmaster() ) {
			return new WP_Error( 'ogc_forbidden', 'Not allowed.', array( 'status' => 403 ) );
		}
	}
	return $res;
}, 6, 3 );
