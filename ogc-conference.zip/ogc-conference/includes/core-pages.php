<?php
/**
 * The plugin's pages: which address, which template, which styles and scripts, and how each is drawn.
 *
 * Two shells, as in v3:
 *   theme  the site's own header and footer (get_header / get_footer): the Conference page, the
 *          printed schedule, the packet, the form, volunteering, tournaments;
 *   bare   a page of its own, no site header or footer: the guide (an app) and the back end (the
 *          COA's year, the editors, the committees' lists and Lodging), and sign-in.
 *
 * An area changes its page from its own module with the ogc_pages filter, e.g. adding a script:
 *   add_filter( 'ogc_pages', function ( $p ) { $p['volunteer']['scripts'][] = 'volunteer/extra.js'; return $p; } );
 * Asset paths are relative to assets/. ogc-wp.js is always loaded first, and the dev Pages button last
 * (only with OGC_DEV).
 */

defined( 'ABSPATH' ) || exit;

function ogc_pages() {
	// The theme draws the header, footer and base type of the theme pages; ogc-tokens.css adds the
	// site's colours and container. The bare pages get site-shell.css's base type as well.
	$css  = array( 'shared/ogc-tokens.css', 'shared/ogc-ui.css' );
	$week = array_merge( $css, array( 'schedule-hub/week.css' ) );
	$js   = array( 'shared/ogc-core.js', 'shared/ogc-store.js', 'shared/ogc-pickup.js' );
	$pages = array(
		'conference'  => array(
			'path'        => '',
			'folder'      => 'schedule-hub',
			'shell'       => 'theme',
			'title'       => 'Annual Conference',
			'description' => 'The Annual Conference, day by day: place, dates, hosts and call-in line, with every service\'s sermon in its place.',
			'styles'      => array_merge( $week, array( 'shared/ogc-map.css' ) ),
			'scripts'     => array_merge( $js, array( 'shared/ogc-signups.js', 'shared/ogc-map.js', 'schedule-hub/week.js' ) ),
			'header'      => array( 'topbar' => false, 'crumb' => false ),
		),
		'guide'       => array(
			'path'        => 'guide',
			'folder'      => 'guide',
			'shell'       => 'bare',
			'html_class'  => 'ogc-app',
			'title'       => 'Conference guide',
			'description' => 'The Annual Conference guide for the week on campus: today, the schedule, places and help. Works without signal once opened.',
			'head'        => 'guide-head.php',
			'styles'      => array_merge( $week, array( 'shared/ogc-map.css' ) ),
			'scripts'     => array_merge( $js, array( 'shared/ogc-signups.js', 'shared/ogc-map.js', 'schedule-hub/week.js' ) ),
		),
		'schedule'    => array(
			'path'        => 'schedule',
			'folder'      => 'schedule',
			'shell'       => 'theme',
			'title'       => 'Schedule',
			'description' => 'The Annual Conference schedule: worship services, meals, Preteen and Young Folks programs, places and phone numbers.',
			'fonts'       => 'family=Roboto+Condensed:wght@400;700',
			'styles'      => array_merge( $css, array( 'schedule/schedule.css' ) ),
			'scripts'     => array_merge( $js, array( 'schedule/schedule.js' ) ),
			'header'      => array( 'crumb' => 'Schedule', 'crumb_parent' => 'Annual Conference', 'crumb_parent_href' => '' ),
		),
		'packet'      => array(
			'path'        => 'packet',
			'folder'      => 'packet',
			'shell'       => 'theme',
			'title'       => 'Information packet',
			'description' => 'The Annual Conference information packet, to read or print.',
			'styles'      => array_merge( $week, array( 'shared/ogc-map.css', 'volunteer/volunteer.css', 'packet/packet.css' ) ),
			'scripts'     => array_merge( $js, array( 'shared/ogc-map.js', 'packet/packet.js' ) ),
			'header'      => array( 'topbar' => false, 'crumb' => false ),
		),
		'register'    => array(
			'path'        => 'register',
			'folder'      => 'register',
			'shell'       => 'theme',
			'title'       => 'Register',
			'description' => 'Register your household for the Annual Conference: lodging, meals, communion and preteens, in one short form.',
			'styles'      => array_merge( $week, array( 'volunteer/volunteer.css', 'shared/ogc-map.css', 'register/register.css' ) ),
			'scripts'     => array_merge( $js, array( 'shared/ogc-signups.js', 'shared/ogc-map.js', 'register/register.js' ) ),
			'header'      => array( 'topbar' => false, 'crumb' => false ),
		),
		'volunteer'   => array(
			'path'        => 'volunteer',
			'folder'      => 'volunteer',
			'shell'       => 'theme',
			'title'       => 'Volunteer',
			'description' => 'Sign up to help at the Annual Conference.',
			'styles'      => array_merge( $week, array( 'shared/ogc-map.css', 'shared/ogc-ws.css', 'volunteer/volunteer.css' ) ),
			'scripts'     => array_merge( $js, array( 'shared/ogc-signups.js', 'shared/ogc-map.js', 'volunteer/volunteer.js' ) ),
			'header'      => array( 'topbar' => false, 'crumb' => false ),
		),
		'tournaments' => array(
			'path'        => 'tournaments',
			'folder'      => 'tournaments',
			'shell'       => 'theme',
			'title'       => 'Tournaments',
			'description' => 'Young Folks tournaments at the Annual Conference.',
			'styles'      => array_merge( $week, array( 'shared/ogc-ws.css', 'volunteer/volunteer.css', 'tournaments/tournaments.css' ) ),
			'scripts'     => array_merge( $js, array( 'shared/ogc-signups.js', 'tournaments/tournaments.js' ) ),
			'header'      => array( 'topbar' => false, 'crumb' => false ),
		),
		'lists'       => array(
			'path'    => 'lists',
			'members' => true,
			'folder'  => 'lists',
			'shell'   => 'bare',
			'title'   => 'Lists',
			'noindex' => true,
			'styles'  => array_merge( $week, array( 'shared/ogc-ws.css', 'volunteer/volunteer.css', 'lodging/lodging.css', 'admin/admin.css', 'lists/lists.css' ) ),
			'scripts' => array_merge( $js, array( 'shared/ogc-signups.js', 'lists/lists.js' ) ),
		),
		'lodging'     => array(
			'path'    => 'lodging',
			'members' => true,
			'folder'  => 'lodging',
			'shell'   => 'bare',
			'title'   => 'Lodging',
			'noindex' => true,
			'styles'  => array_merge( $week, array( 'shared/ogc-ws.css', 'volunteer/volunteer.css', 'shared/ogc-map.css', 'lodging/lodging.css' ) ),
			'scripts' => array_merge( $js, array( 'shared/ogc-signups.js', 'shared/ogc-map.js', 'lodging/lodging.js' ) ),
		),
		'year'        => array(
			'path'       => 'year',
			'members'    => true,
			'folder'     => 'year',
			'shell'      => 'bare',
			'html_class' => 'adm-full',
			'title'      => 'The year',
			'noindex'    => true,
			'styles'     => array_merge( $week, array( 'shared/ogc-ws.css', 'shared/ogc-map.css', 'year/year.css' ) ),
			'scripts'    => array_merge( $js, array( 'shared/ogc-signups.js', 'shared/ogc-map.js', 'year/year.js' ) ),
		),
		'admin'       => array(
			'path'    => 'admin',
			'members' => true,
			'folder'  => 'admin',
			'shell'   => 'bare',
			'title'   => 'Committee of Arrangements',
			'noindex' => true,
			'styles'  => array_merge( $week, array( 'shared/ogc-ws.css', 'volunteer/volunteer.css', 'admin/admin.css' ) ),
			'scripts' => array_merge( $js, array( 'shared/ogc-signups.js', 'admin/admin.js' ) ),
		),
		'signin'      => array(
			'path'       => 'signin',
			'folder'     => 'signin',
			'shell'      => 'bare',
			'html_class' => 'adm-full',
			'title'   => 'Sign in',
			'noindex' => true,
			'styles'  => array_merge( $week, array( 'shared/ogc-ws.css', 'admin/admin.css', 'signin/signin.css' ) ),
			'scripts' => array( 'shared/ogc-core.js', 'signin/signin.js' ),
		),
	);
	foreach ( $pages as $k => &$p ) {
		if ( 'bare' === $p['shell'] ) {
			$p['styles'] = array_map( function ( $s ) { return 'shared/ogc-tokens.css' === $s ? 'shared/site-shell.css' : $s; }, $p['styles'] );
		}
		$p = array_merge( array( 'members' => false, 'template' => $k . '.php', 'html_class' => '', 'header' => array(), 'noindex' => false, 'description' => '', 'fonts' => '', 'head' => '' ), $p );
	}
	unset( $p );
	return ogc_pages_shared_css( (array) apply_filters( 'ogc_pages', $pages ) );
}

/** Every page, the committees' app and the pages an area adds with the ogc_pages filter included, loads
 * the one token set and the shared pieces before its own styles (docs/30, settle row 3): ogc-tokens.css
 * (after site-shell.css on a bare page that has it), then ogc-ui.css. */
function ogc_pages_shared_css( $pages ) {
	$shared = array( 'shared/ogc-tokens.css', 'shared/ogc-ui.css' );
	foreach ( $pages as $k => $p ) {
		if ( ! is_array( $p ) || ! isset( $p['styles'] ) ) {
			continue;
		}
		$s  = array_values( array_diff( (array) $p['styles'], $shared ) );
		$at = array_search( 'shared/site-shell.css', $s, true );
		array_splice( $s, false === $at ? 0 : $at + 1, 0, $shared );
		$pages[ $k ]['styles'] = $s;
	}
	return $pages;
}

/** The current page's key while one is being drawn. */
function ogc_current_page() {
	return isset( $GLOBALS['ogc_page'] ) ? $GLOBALS['ogc_page'] : '';
}

/** The asset's URL with its version (its file's time, so a changed file is never served stale). */
function ogc_asset( $path ) {
	$file = OGC_DIR . 'assets/' . $path;
	return file_exists( $file ) ? array( OGC_URL . 'assets/' . $path, OGC_VERSION . '.' . filemtime( $file ) ) : null;
}

function ogc_asset_handle( $path ) {
	return 'ogc-' . trim( preg_replace( '/[^a-z0-9]+/', '-', strtolower( preg_replace( '/\.(js|css)$/', '', $path ) ) ), '-' );
}

/** What the page's scripts are told about the site and the person (window.OGC_WP). An area adds to it
 * with the ogc_client_config filter. */
function ogc_client_config( $key ) {
	$pages = ogc_pages();
	$p     = isset( $pages[ $key ] ) ? $pages[ $key ] : array( 'folder' => $key );
	$uid   = get_current_user_id();
	$u     = $uid ? get_userdata( $uid ) : null;
	$here  = ( is_ssl() ? 'https://' : 'http://' ) . ( isset( $_SERVER['HTTP_HOST'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_HOST'] ) ) : '' ) . ( isset( $_SERVER['REQUEST_URI'] ) ? esc_url_raw( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : '' );
	$cfg   = array(
		'rest'      => esc_url_raw( rest_url( OGC_NS . '/' ) ),
		'nonce'     => wp_create_nonce( 'wp_rest' ),
		'base'      => wp_make_link_relative( ogc_url() ),
		'page'      => $key,
		'folder'    => $p['folder'],
		'assets'    => OGC_URL . 'assets/',
		'me'        => $u ? array( 'email' => strtolower( $u->user_email ), 'name' => $u->display_name ) : null,
		'member'    => ogc_member_years( $uid ),
		'webmaster' => ogc_is_webmaster( $uid ),
		// The pages' dev tools (the clock a preview sends, the samples): a local address only (M10).
		'dev'       => function_exists( 'ogc_dev_tools_on' ) && ogc_dev_tools_on(),
		// The shared prototype (WordPress Playground): its banner and tour (ogc-dev-nav.js).
		'prototype' => defined( 'OGC_PROTOTYPE' ) && OGC_PROTOTYPE,
		'home'      => wp_make_link_relative( home_url( '/' ) ),
		'signin'    => wp_make_link_relative( ogc_url( 'signin' ) ),
		'logout'    => $u ? wp_logout_url( $here ) : '',
		'version'   => OGC_VERSION,
	);
	return (array) apply_filters( 'ogc_client_config', $cfg, $key );
}

function ogc_client_config_js( $key ) {
	return 'window.OGC_WP = ' . wp_json_encode( ogc_client_config( $key ), JSON_HEX_TAG | JSON_HEX_AMP | JSON_UNESCAPED_SLASHES ) . ';';
}

/** The page's scripts in order: ogc-wp.js first, then the page's, then (dev or the shared prototype only)
 * the banner and the Tour. */
function ogc_page_scripts( $p ) {
	$list = array_merge( array( 'shared/ogc-wp.js' ), (array) $p['scripts'] );
	// Only on a local address (or the shared prototype, which counts as one): never on a copy elsewhere
	// with OGC_DEV left on (security pass, M10).
	if ( ( OGC_DEV || ( defined( 'OGC_PROTOTYPE' ) && OGC_PROTOTYPE ) ) && function_exists( 'ogc_is_local_host' ) && ogc_is_local_host() ) {
		$list[] = 'shared/ogc-dev-nav.js';
	}
	return array_values( array_unique( $list ) );
}

/** Google Fonts for the page. Noto Serif stands in for the theme's Typekit Droid Serif on the bare pages
 * (the theme loads its own on the others); a page may ask for more (the schedule's Roboto Condensed). */
function ogc_page_fonts_url( $p, $bare ) {
	$fam = array();
	if ( $bare ) {
		$fam[] = 'family=Noto+Serif:wght@400;700';
	}
	if ( $p['fonts'] ) {
		$fam[] = $p['fonts'];
	}
	return $fam ? 'https://fonts.googleapis.com/css2?' . implode( '&', $fam ) . '&display=swap' : '';
}

/** Does the fonts' stylesheet load without holding the page up? On the local site and the shared
 * prototype only (Oct 28 rehearsal: on Wi-Fi with no internet, every page stayed blank about 90 s
 * waiting for fonts.googleapis.com). On ogbbc.org the tag is as it was. */
function ogc_fonts_async() {
	return function_exists( 'ogc_is_local_host' ) && ogc_is_local_host();
}

/** The fonts' stylesheet tag. Where ogc_fonts_async(), it's fetched as a print stylesheet (which never
 * holds up drawing) and turned on when it arrives: the text draws at once in the fallback serif and takes
 * the font when it comes. Without scripts, the noscript copy loads it as before. The print pages wait for
 * it (print.js fontsReady, data-ogc-fonts) before they measure, at most 2.5 s. */
function ogc_fonts_tag( $url ) {
	$u = esc_url( $url );
	if ( ! ogc_fonts_async() ) {
		return '<link rel="stylesheet" href="' . $u . "\">\n";
	}
	return '<link rel="stylesheet" href="' . $u . '" media="print" onload="this.media=\'all\'" data-ogc-fonts>' . "\n" .
		'<noscript><link rel="stylesheet" href="' . $u . "\"></noscript>\n";
}

// The same for a page inside the theme (its fonts enqueued as ogc-fonts).
add_filter( 'style_loader_tag', function ( $tag, $handle, $href ) {
	return 'ogc-fonts' === $handle && ogc_fonts_async() ? ogc_fonts_tag( $href ) : $tag;
}, 10, 3 );

/** May this person open the page? A members' page (the back end) needs a member of the year in
 * ?year= (or of any year, without one); webmasters may open every page. The signin area may change
 * the rule with the ogc_page_allowed filter. */
function ogc_page_allowed( $key, $p ) {
	$ok = true;
	if ( ! empty( $p['members'] ) ) {
		// phpcs:ignore WordPress.Security.NonceVerification -- reading which year is asked for.
		$y  = isset( $_GET['year'] ) ? sanitize_text_field( wp_unslash( $_GET['year'] ) ) : '';
		$ok = ogc_is_webmaster() || ( ogc_valid_year( $y ) ? ogc_is_member( $y ) : (bool) ogc_member_years() );
	}
	return (bool) apply_filters( 'ogc_page_allowed', $ok, $key, $p );
}

/** Not signed in: to sign-in, coming back here after. Signed in but not on the year's list: 403. */
function ogc_page_refuse( $key ) {
	$here = isset( $_SERVER['REQUEST_URI'] ) ? esc_url_raw( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : '';
	if ( ! is_user_logged_in() ) {
		wp_safe_redirect( add_query_arg( 'return', rawurlencode( $here ), ogc_url( 'signin' ) ) );
		exit;
	}
	status_header( 403 );
	nocache_headers();
	$GLOBALS['ogc_refused'] = true;
	ogc_render_page( 'signin' );
}

/** Draw a page and stop. */
function ogc_render_page( $key ) {
	$pages = ogc_pages();
	if ( ! isset( $pages[ $key ] ) ) {
		return;
	}
	$p = $pages[ $key ];
	if ( ! ogc_page_allowed( $key, $p ) ) {
		ogc_page_refuse( $key );
	}
	$GLOBALS['ogc_page'] = $key;
	$template           = ogc_template_path( $p['template'] );
	if ( ! $template ) {
		return;
	}
	show_admin_bar( false );
	if ( empty( $GLOBALS['ogc_refused'] ) ) {
		status_header( 200 );
	}
	// What a page shows depends on who's signed in (OGC_WP.me, the nonce): never cached for them.
	if ( is_user_logged_in() ) {
		nocache_headers();
		if ( ! defined( 'DONOTCACHEPAGE' ) ) {
			define( 'DONOTCACHEPAGE', true );
		}
	}
	if ( 'theme' === $p['shell'] ) {
		ogc_render_theme_page( $key, $p, $template );
	} else {
		ogc_render_bare_page( $key, $p, $template );
	}
	exit;
}

function ogc_template_path( $name ) {
	$file = (string) apply_filters( 'ogc_template', OGC_DIR . 'templates/' . $name, $name );
	return file_exists( $file ) ? $file : '';
}

/** Inside the site's theme: its header and footer around the page's block. */
function ogc_render_theme_page( $key, $p, $template ) {
	add_action( 'wp_enqueue_scripts', function () use ( $key, $p ) {
		$fonts = ogc_page_fonts_url( $p, false );
		if ( $fonts ) {
			wp_enqueue_style( 'ogc-fonts', $fonts, array(), null );
		}
		foreach ( (array) $p['styles'] as $s ) {
			$a = ogc_asset( $s );
			if ( $a ) {
				wp_enqueue_style( ogc_asset_handle( $s ), $a[0], array(), $a[1] );
			}
		}
		$prev = array();
		foreach ( ogc_page_scripts( $p ) as $s ) {
			$a = ogc_asset( $s );
			if ( ! $a ) {
				continue;
			}
			$h = ogc_asset_handle( $s );
			wp_enqueue_script( $h, $a[0], $prev, $a[1], true );
			if ( 'shared/ogc-wp.js' === $s ) {
				wp_add_inline_script( $h, ogc_client_config_js( $key ), 'before' );
			}
			$prev = array( $h );
		}
	}, 20 );
	add_filter( 'pre_get_document_title', function () use ( $p ) {
		return $p['title'] . ' – ' . get_bloginfo( 'name' );
	} );
	add_action( 'wp_head', function () use ( $p ) {
		if ( $p['description'] ) {
			echo '<meta name="description" content="' . esc_attr( $p['description'] ) . "\">\n";
		}
		if ( $p['noindex'] ) {
			echo "<meta name=\"robots\" content=\"noindex\">\n";
		}
		if ( $p['head'] && ogc_template_path( $p['head'] ) ) {
			include ogc_template_path( $p['head'] );
		}
	}, 1 );
	// The plugin's address isn't a WordPress post, so WordPress took it for "not found": the theme, WP
	// Rocket and SEO plugins would treat the page as a 404. It's a page (register area, polish 1).
	global $wp_query;
	if ( $wp_query instanceof WP_Query ) {
		$wp_query->is_404  = false;
		$wp_query->is_page = true;
	}
	add_filter( 'body_class', function ( $c ) use ( $key ) {
		$c   = array_values( array_diff( $c, array( 'error404' ) ) );
		$c[] = 'ogc-page';
		$c[] = 'ogc-page--' . $key;
		return $c;
	} );
	// The stand-in theme (plugin/ogbbc-standin) reads these to leave out its announcement bar or
	// breadcrumb, as v3's site-shell.js did. The real theme ignores them.
	add_filter( 'ogbbc_standin_header', function ( $h ) use ( $p ) {
		$h = array_merge( (array) $h, (array) $p['header'] );
		if ( isset( $h['crumb_parent_href'] ) && '' === $h['crumb_parent_href'] ) {
			$h['crumb_parent_href'] = ogc_url();
		}
		return $h;
	} );
	get_header();
	include $template;
	get_footer();
}

/** A page of its own (the guide, the back end): the plugin writes the whole document. */
function ogc_render_bare_page( $key, $p, $template ) {
	$fonts = ogc_page_fonts_url( $p, true );
	echo "<!doctype html>\n<html lang=\"en\"" . ( $p['html_class'] ? ' class="' . esc_attr( $p['html_class'] ) . '"' : '' ) . ">\n<head>\n";
	echo "<meta charset=\"utf-8\">\n<meta name=\"viewport\" content=\"width=device-width, initial-scale=1, viewport-fit=cover\">\n";
	echo '<title>' . esc_html( $p['title'] . ' – ' . get_bloginfo( 'name' ) ) . "</title>\n";
	if ( $p['description'] ) {
		echo '<meta name="description" content="' . esc_attr( $p['description'] ) . "\">\n";
	}
	if ( $p['noindex'] ) {
		echo "<meta name=\"robots\" content=\"noindex\">\n";
	}
	if ( $fonts ) {
		echo "<link rel=\"preconnect\" href=\"https://fonts.googleapis.com\">\n<link rel=\"preconnect\" href=\"https://fonts.gstatic.com\" crossorigin>\n";
		echo ogc_fonts_tag( $fonts ); // phpcs:ignore WordPress.Security.EscapeOutput -- the URL is escaped inside.
	}
	foreach ( (array) $p['styles'] as $s ) {
		$a = ogc_asset( $s );
		if ( $a ) {
			echo '<link rel="stylesheet" id="' . esc_attr( ogc_asset_handle( $s ) ) . '-css" href="' . esc_url( add_query_arg( 'ver', $a[1], $a[0] ) ) . "\">\n";
		}
	}
	if ( $p['head'] && ogc_template_path( $p['head'] ) ) {
		include ogc_template_path( $p['head'] );
	}
	echo "</head>\n<body class=\"ogc-page ogc-page--" . esc_attr( $key ) . "\">\n";
	include $template;
	echo "\n";
	foreach ( ogc_page_scripts( $p ) as $s ) {
		$a = ogc_asset( $s );
		if ( ! $a ) {
			continue;
		}
		if ( 'shared/ogc-wp.js' === $s ) {
			echo '<script>' . ogc_client_config_js( $key ) . "</script>\n"; // phpcs:ignore -- JSON with tags and ampersands escaped.
		}
		echo '<script src="' . esc_url( add_query_arg( 'ver', $a[1], $a[0] ) ) . "\"></script>\n";
	}
	echo "</body>\n</html>\n";
}

/** The address the pages fetch the year's files from (answered by ogc-wp.js from the REST routes, or
 * by the server at the same address). */
function ogc_data_base() {
	return wp_make_link_relative( ogc_url( 'schedule/data' ) );
}
