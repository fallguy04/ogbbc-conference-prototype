<?php
/**
 * Payments (register area): the ledger and the payment provider's interface.
 *
 * No card number ever touches this code. Paying by card means: a pending charge is written to the
 * ledger, the person goes to the provider's own checkout page, and only the provider's answer (its
 * webhook) marks the charge paid. Which provider, and whose account, is the COA treasurer's choice
 * (docs/21), so the provider is a driver behind one small interface:
 *
 *   add_filter( 'ogc_payment_drivers', function ( $d ) {
 *       $d['acme'] = array(
 *           'label'   => 'Acme',
 *           // $payment has id, cents, currency, rid, and return (where the provider sends the payer
 *           // back: the registration's Registered page or Your sign-ups).
 *           'start'   => function ( $payment, $reg ) { … return $checkout_url; },   // or WP_Error
 *           // Checks the provider's signature itself, then says what was charged:
 *           'webhook' => function ( WP_REST_Request $req ) { … return array( 'id' => …, 'outcome' => 'paid'|'declined'|'cancelled',
 *                                                                              'cents' => …, 'currency' => 'USD', 'ref' => … ); },
 *           // Optional: send a refund back to the card. Without it, refunds are "manual": the
 *           // treasurer sends them and marks them sent (reg/r/{id}/ledger).
 *           'refund'  => function ( $charge, $cents ) { … return array( 'ref' => … ); },   // or WP_Error
 *       );
 *       return $d;
 *   } );
 *   and the option ogc_payment_driver = 'acme'.
 *
 * A charge is marked paid only when the provider's answer names the same amount and currency as the
 * ledger row; anything else is refused and logged (pay_mismatch) for the treasurer.
 *
 * Locally (OGC_DEV on a local address only) the "test" driver stands in: its checkout page is the
 * form's own ?checkout= view, which says the provider's page goes there and lets the tester pay,
 * decline or cancel. Anywhere else the test driver doesn't exist, and the option naming it is ignored.
 * On ogbbc.org with no driver set, card payment isn't offered at all (checks only).
 *
 * The ledger (ogc_payments): one row per charge, refund, check or desk payment, amounts in whole
 * cents. A registration's money (paid, due, refund pending) is always summed from it, never kept
 * as a number the page sent.
 */

defined( 'ABSPATH' ) || exit;

add_filter( 'ogc_schema', function ( $sql, $charset ) {
	// kind: charge (card) · check · desk (cash, check or card at the desk) · refund
	// status, one fixed list per kind (docs/scope/02 record 5; ogc_pay_status_words):
	//   charge  pending · paid · failed · cancelled · disputed
	//   check   pending (to come) · paid (received) · returned · cancelled
	//   desk    paid · cancelled
	//   refund  requested · approved · sent · cancelled (declined)
	// day: the day it was received, sent or taken (the venue's date), set by the person who marked it.
	// paid_by: the name on a check that paid for several households; grp: the lines of that one check.
	// deposit_id: the bank deposit it went in (ogc_deposits). fee: a card payment's fee, from the
	// provider's own answer (never typed).
	$sql[] = 'CREATE TABLE ' . ogc_table( 'payments' ) . " (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  year smallint(5) unsigned NOT NULL,
  record_id bigint(20) unsigned NOT NULL,
  rid varchar(24) NOT NULL DEFAULT '',
  kind varchar(16) NOT NULL,
  method varchar(16) NOT NULL DEFAULT '',
  cents int(11) NOT NULL DEFAULT 0,
  status varchar(16) NOT NULL,
  driver varchar(32) NOT NULL DEFAULT '',
  ref varchar(128) NOT NULL DEFAULT '',
  idem varchar(64) NOT NULL DEFAULT '',
  token varchar(64) NOT NULL DEFAULT '',
  note varchar(255) NOT NULL DEFAULT '',
  sample tinyint(1) NOT NULL DEFAULT 0,
  by_user bigint(20) unsigned NOT NULL DEFAULT 0,
  created_at datetime NULL,
  updated_at datetime NULL,
  day varchar(10) NOT NULL DEFAULT '',
  paid_by varchar(80) NOT NULL DEFAULT '',
  grp varchar(24) NOT NULL DEFAULT '',
  deposit_id bigint(20) unsigned NOT NULL DEFAULT 0,
  fee int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY  (id),
  KEY record_id (record_id),
  KEY year (year),
  KEY idem (idem)
) $charset;";
	// A bank deposit or a card payout (docs/scope/02 record 6): the lines in it are the payments whose
	// deposit_id is its id; its total is always added up from them. bank_cents is the bank statement's
	// figure, typed (-1: not typed yet). A removed deposit keeps its row (removed_at) and frees its lines.
	$sql[] = 'CREATE TABLE ' . ogc_table( 'deposits' ) . " (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  year smallint(5) unsigned NOT NULL,
  day varchar(10) NOT NULL DEFAULT '',
  kind varchar(16) NOT NULL DEFAULT '',
  bank_cents int(11) NOT NULL DEFAULT -1,
  note varchar(255) NOT NULL DEFAULT '',
  sample tinyint(1) NOT NULL DEFAULT 0,
  by_user bigint(20) unsigned NOT NULL DEFAULT 0,
  created_at datetime NULL,
  updated_at datetime NULL,
  removed_at datetime NULL,
  PRIMARY KEY  (id),
  KEY year (year)
) $charset;";
	return $sql;
}, 20, 2 );

/* ------------------------------------------------------------------ the drivers */

/** Every driver this site has: the test driver locally, and any a site plugin adds. */
function ogc_pay_drivers() {
	$d = array();
	if ( ogc_pay_test_on() ) {
		$d['test'] = array(
			'label'   => 'Test',
			'start'   => function ( $p ) {
				// The return address's preview date and next page ride along, so the stand-in checkout
				// sends the tester back where a provider would.
				$q = array( 'year' => (int) $p['year'], 'checkout' => (int) $p['id'], 't' => $p['token'] );
				$r = array();
				wp_parse_str( (string) wp_parse_url( isset( $p['return'] ) ? $p['return'] : '', PHP_URL_QUERY ), $r );
				foreach ( array( 'as-of', 'then' ) as $k ) {
					if ( ! empty( $r[ $k ] ) ) {
						$q[ $k ] = (string) $r[ $k ];
					}
				}
				if ( isset( $r['view'] ) ) {
					$q['then'] = 'done' === $r['view'] ? 'done' : 'mine';
				}
				return ogc_url( 'register', $q );
			},
			'webhook' => null, // the test page answers through /pay/test/{id}
		);
	}
	$d = (array) apply_filters( 'ogc_payment_drivers', $d );
	// Never a test driver outside a local dev site, whatever a plugin adds.
	if ( ! ogc_pay_test_on() ) {
		unset( $d['test'] );
	}
	return $d;
}

/** The test driver: OGC_DEV and a local address (127.0.0.1, localhost, *.test), never a staging copy. */
function ogc_pay_test_on() {
	return OGC_DEV && function_exists( 'ogc_is_local_host' ) && ogc_is_local_host();
}

/** The currency every charge is in (the option ogc_currency, a three-letter code). */
function ogc_pay_currency() {
	$c = strtoupper( (string) get_option( 'ogc_currency', 'USD' ) );
	return preg_match( '/^[A-Z]{3}$/', $c ) ? $c : 'USD';
}

/** Send a refund back through the provider when its driver can ('refund'); otherwise it's "manual" and
 * the treasurer sends it. Returns 'sent', 'manual', or WP_Error. */
function ogc_pay_refund_via( $refund ) {
	$charge = null;
	foreach ( ogc_pay_rows( $refund['record_id'] ) as $p ) {
		if ( 'charge' === $p['kind'] && 'paid' === $p['status'] && $p['cents'] >= $refund['cents'] ) {
			$charge = $p;
		}
	}
	$all = ogc_pay_drivers();
	$drv = $charge && isset( $all[ $charge['driver'] ] ) ? $all[ $charge['driver'] ] : null;
	if ( ! $drv || empty( $drv['refund'] ) || ! is_callable( $drv['refund'] ) ) {
		return 'manual';
	}
	$out = call_user_func( $drv['refund'], $charge, (int) $refund['cents'] );
	if ( is_wp_error( $out ) ) {
		ogc_log( 'pay_refund_failed', $refund['year'], 'payments', array( 'id' => $refund['id'] ) );
		return $out;
	}
	ogc_pay_set( $refund['id'], array( 'status' => 'sent', 'ref' => isset( $out['ref'] ) ? (string) $out['ref'] : '', 'driver' => $charge['driver'] ) );
	ogc_log( 'pay_refund_sent', $refund['year'], 'payments', array( 'id' => $refund['id'] ) );
	return 'sent';
}

/** The driver in use, or null: card payment is offered only when there is one. */
function ogc_pay_driver() {
	$all  = ogc_pay_drivers();
	$name = (string) get_option( 'ogc_payment_driver', ogc_pay_test_on() ? 'test' : '' );
	if ( 'test' === $name && ! ogc_pay_test_on() ) {
		return null;
	}
	return ( $name && isset( $all[ $name ] ) ) ? array_merge( array( 'name' => $name ), $all[ $name ] ) : null;
}

/* ------------------------------------------------------------------ the ledger */

function ogc_pay_row( $r ) {
	return array(
		'id'         => (int) $r['id'],
		'year'       => (int) $r['year'],
		'record_id'  => (int) $r['record_id'],
		'rid'        => $r['rid'],
		'kind'       => $r['kind'],
		'method'     => $r['method'],
		'cents'      => (int) $r['cents'],
		'status'     => $r['status'],
		'driver'     => $r['driver'],
		'ref'        => $r['ref'],
		'idem'       => $r['idem'],
		'token'      => $r['token'],
		'note'       => $r['note'],
		'sample'     => (bool) (int) $r['sample'],
		'by_user'    => (int) $r['by_user'],
		'created_at' => $r['created_at'],
		'updated_at' => $r['updated_at'],
		// The ledger's own facts (Oct 13, night-records); read with a default on a site whose table
		// dbDelta hasn't widened yet.
		'day'        => isset( $r['day'] ) ? (string) $r['day'] : '',
		'paid_by'    => isset( $r['paid_by'] ) ? (string) $r['paid_by'] : '',
		'grp'        => isset( $r['grp'] ) ? (string) $r['grp'] : '',
		'deposit_id' => isset( $r['deposit_id'] ) ? (int) $r['deposit_id'] : 0,
		'fee'        => isset( $r['fee'] ) ? (int) $r['fee'] : 0,
	);
}

/** A line's status in words, from the one fixed list for its kind (docs/scope/02 record 5). */
function ogc_pay_status_words( $p ) {
	$w = array(
		'charge' => array( 'pending' => 'Pending', 'paid' => 'Paid', 'failed' => 'Failed', 'cancelled' => 'Cancelled', 'disputed' => 'Disputed' ),
		'check'  => array( 'pending' => 'To come', 'paid' => 'Received', 'returned' => 'Returned', 'cancelled' => 'Cancelled' ),
		'desk'   => array( 'paid' => 'Paid', 'cancelled' => 'Cancelled' ),
		'refund' => array( 'requested' => 'Requested', 'approved' => 'Approved', 'sent' => 'Sent', 'cancelled' => 'Declined' ),
	);
	return isset( $w[ $p['kind'] ][ $p['status'] ] ) ? $w[ $p['kind'] ][ $p['status'] ] : ucfirst( (string) $p['status'] );
}

/** A line's kind in words: Card, Check, Cash (desk), Card at the desk, Check at the desk, Refund. */
function ogc_pay_kind_words( $p ) {
	if ( 'desk' === $p['kind'] ) {
		return 'card' === $p['method'] ? 'Card at the desk' : ( 'check' === $p['method'] ? 'Check at the desk' : 'Cash' );
	}
	$k = array( 'charge' => 'Card', 'check' => 'Check', 'refund' => 'Refund' );
	return isset( $k[ $p['kind'] ] ) ? $k[ $p['kind'] ] : ucfirst( (string) $p['kind'] );
}

/** Does this line count as money in? (A returned check or a disputed card payment stops counting.) */
function ogc_pay_counts( $p ) {
	return 'refund' !== $p['kind'] && 'paid' === $p['status'];
}

/**
 * A ledger line's time: now, or (a local site and the shared prototype only) the day the page previews,
 * at this time of day at the venue, when the registration request being answered carries ?as_of
 * (rehearsal, Oct 28: a card paid in the walk-through "on Mar 2, 2027" read "Wed Oct 28", today's date).
 * Never on ogbbc.org (ogc_reg_local), and never for a Conference already over (ogc_reg_today ignores the
 * preview then). $year, or the line's own ($id) when the caller has only that.
 */
function ogc_pay_now( $year = 0, $id = 0 ) {
	$req = isset( $GLOBALS['ogc_reg_req'] ) ? $GLOBALS['ogc_reg_req'] : null;
	if ( ! $req instanceof WP_REST_Request || '' === (string) $req->get_param( 'as_of' ) || ! function_exists( 'ogc_reg_local' ) || ! ogc_reg_local() || ! function_exists( 'ogc_reg_today' ) ) {
		return ogc_now();
	}
	if ( ! $year && $id ) {
		$p    = ogc_pay_get( $id );
		$year = $p ? (int) $p['year'] : 0;
	}
	$day = $year ? ogc_reg_today( (int) $year, $req ) : '';
	if ( '' === $day || ogc_reg_today( (int) $year ) === $day ) {
		return ogc_now();
	}
	$at = new DateTime( 'now', ogc_reg_tz( (int) $year ) );
	$at->setDate( (int) substr( $day, 0, 4 ), (int) substr( $day, 5, 2 ), (int) substr( $day, 8, 2 ) );
	$at->setTimezone( new DateTimeZone( 'UTC' ) );
	return $at->format( 'Y-m-d H:i:s' );
}

/**
 * Change a line only if it is still what the caller saw ($was: its status), so two people marking the
 * same check at once can't both do it. Returns true when this request changed it.
 */
function ogc_pay_set_if( $id, $fields, $was ) {
	global $wpdb;
	$allowed = array_intersect_key( (array) $fields, array_flip( ogc_pay_fields() ) );
	if ( ! $allowed ) {
		return false;
	}
	$allowed['updated_at'] = ogc_pay_now( 0, $id );
	$n = $wpdb->update( ogc_table( 'payments' ), $allowed, array( 'id' => (int) $id, 'status' => (string) $was ) );
	return 1 === (int) $n;
}

/** The fields a line may change after it's written. */
function ogc_pay_fields() {
	return array( 'status', 'cents', 'ref', 'note', 'method', 'driver', 'day', 'paid_by', 'grp', 'deposit_id', 'fee' );
}

function ogc_pay_get( $id ) {
	global $wpdb;
	$r = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . ogc_table( 'payments' ) . ' WHERE id = %d', $id ), ARRAY_A );
	return $r ? ogc_pay_row( $r ) : null;
}

/** A registration's ledger, oldest first. */
function ogc_pay_rows( $record_id ) {
	global $wpdb;
	$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . ogc_table( 'payments' ) . ' WHERE record_id = %d ORDER BY id', $record_id ), ARRAY_A );
	return array_map( 'ogc_pay_row', (array) $rows );
}

/** Every ledger row of a year (the treasurer's export). */
function ogc_pay_year( $year, $with_samples = true ) {
	global $wpdb;
	$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . ogc_table( 'payments' ) . ' WHERE year = %d' . ( $with_samples ? '' : ' AND sample = 0' ) . ' ORDER BY id', $year ), ARRAY_A );
	return array_map( 'ogc_pay_row', (array) $rows );
}

/** The row with this idempotency key, if any (a retried Pay gets the same payment). */
function ogc_pay_by_idem( $record_id, $idem ) {
	global $wpdb;
	if ( '' === (string) $idem ) {
		return null;
	}
	$r = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . ogc_table( 'payments' ) . ' WHERE record_id = %d AND idem = %s ORDER BY id DESC LIMIT 1', $record_id, $idem ), ARRAY_A );
	return $r ? ogc_pay_row( $r ) : null;
}

function ogc_pay_add( $rec, $kind, $method, $cents, $status, $extra = array() ) {
	global $wpdb;
	$now = ogc_pay_now( (int) $rec['year'] );
	$row = array(
		'year'       => (int) $rec['year'],
		'record_id'  => (int) $rec['id'],
		'rid'        => (string) ( isset( $rec['data']['rid'] ) ? $rec['data']['rid'] : '' ),
		'kind'       => $kind,
		'method'     => $method,
		'cents'      => (int) $cents,
		'status'     => $status,
		'driver'     => isset( $extra['driver'] ) ? (string) $extra['driver'] : '',
		'ref'        => isset( $extra['ref'] ) ? substr( (string) $extra['ref'], 0, 128 ) : '',
		'idem'       => isset( $extra['idem'] ) ? substr( (string) $extra['idem'], 0, 64 ) : '',
		'token'      => isset( $extra['token'] ) ? (string) $extra['token'] : '',
		'note'       => isset( $extra['note'] ) ? substr( sanitize_text_field( (string) $extra['note'] ), 0, 255 ) : '',
		'sample'     => ! empty( $rec['sample'] ) ? 1 : 0,
		'by_user'    => get_current_user_id(),
		'created_at' => isset( $extra['at'] ) ? $extra['at'] : $now,
		'updated_at' => $now,
	);
	$fmt = array( '%d', '%d', '%s', '%s', '%s', '%d', '%s', '%s', '%s', '%s', '%s', '%s', '%d', '%d', '%s', '%s' );
	// The ledger's own facts, only when given (an older table without them still takes the row).
	foreach ( array( 'day' => '%s', 'paid_by' => '%s', 'grp' => '%s', 'deposit_id' => '%d', 'fee' => '%d' ) as $k => $f ) {
		if ( isset( $extra[ $k ] ) && '' !== $extra[ $k ] ) {
			$row[ $k ] = '%d' === $f ? (int) $extra[ $k ] : substr( sanitize_text_field( (string) $extra[ $k ] ), 0, 'paid_by' === $k ? 80 : 24 );
			$fmt[]     = $f;
		}
	}
	$ok = $wpdb->insert( ogc_table( 'payments' ), $row, $fmt );
	return $ok ? (int) $wpdb->insert_id : 0;
}

function ogc_pay_set( $id, $fields ) {
	global $wpdb;
	$allowed = array_intersect_key( (array) $fields, array_flip( ogc_pay_fields() ) );
	if ( ! $allowed ) {
		return false;
	}
	$allowed['updated_at'] = ogc_pay_now( 0, $id );
	return false !== $wpdb->update( ogc_table( 'payments' ), $allowed, array( 'id' => (int) $id ) );
}

/** Erase a year's sample ledger rows (with Clear samples). */
function ogc_pay_clear_samples( $year ) {
	global $wpdb;
	$wpdb->query( $wpdb->prepare( 'DELETE FROM ' . ogc_table( 'deposits' ) . ' WHERE year = %d AND sample = 1', $year ) );
	return (int) $wpdb->query( $wpdb->prepare( 'DELETE FROM ' . ogc_table( 'payments' ) . ' WHERE year = %d AND sample = 1', $year ) );
}

/**
 * A registration's money, summed from its ledger (cents):
 *   paid     card charges, checks and desk payments received, less refunds sent
 *   check    checks still to come
 *   pending  card charges started and not yet answered
 *   refund   refunds asked for or approved, not yet sent
 */
function ogc_pay_sum( $rows ) {
	$m = array( 'paid' => 0, 'check' => 0, 'pending' => 0, 'refund' => 0, 'refunded' => 0 );
	foreach ( (array) $rows as $p ) {
		if ( 'refund' === $p['kind'] ) {
			if ( 'sent' === $p['status'] ) {
				$m['paid']     -= $p['cents'];
				$m['refunded'] += $p['cents'];
			} elseif ( in_array( $p['status'], array( 'requested', 'approved' ), true ) ) {
				$m['refund'] += $p['cents'];
			}
			continue;
		}
		if ( 'paid' === $p['status'] ) {
			$m['paid'] += $p['cents'];
		} elseif ( 'pending' === $p['status'] ) {
			if ( 'check' === $p['kind'] ) {
				$m['check'] += $p['cents'];
			} else {
				$m['pending'] += $p['cents'];
			}
		}
	}
	return $m;
}

/** A ledger row's day (Y-m-d) at the venue. Times are stored in UTC; the day is read in the year's time
 * zone (the one every date in this area uses), so a payment at 8:27 PM Pacific isn't dated the next day
 * on a receipt, Your sign-ups or the treasurer's CSV. */
function ogc_pay_day( $utc, $year ) {
	if ( ! $utc ) {
		return '';
	}
	try {
		$d = new DateTime( (string) $utc, new DateTimeZone( 'UTC' ) );
	} catch ( Exception $e ) {
		return substr( (string) $utc, 0, 10 );
	}
	$d->setTimezone( function_exists( 'ogc_reg_tz' ) ? ogc_reg_tz( $year ) : wp_timezone() );
	return $d->format( 'Y-m-d' );
}

/** A ledger row as the household sees it on Your sign-ups (no driver refs or tokens). */
function ogc_pay_public( $p ) {
	return array(
		'id'     => $p['id'],
		'at'     => ogc_pay_day( $p['updated_at'], $p['year'] ),
		'kind'   => $p['kind'],
		'method' => $p['method'],
		'cents'  => $p['cents'],
		'status' => $p['status'],
		'note'   => $p['note'],
	);
}

/* ------------------------------------------------------------------ the test driver's answer */

add_action( 'rest_api_init', function () {
	// A provider's webhook (a real driver checks the provider's signature itself).
	register_rest_route( OGC_NS, '/pay/webhook/(?P<driver>[a-z0-9_-]{1,32})', array(
		'methods'             => 'POST',
		'callback'            => 'ogc_pay_webhook',
		'permission_callback' => '__return_true',
	) );
	if ( ogc_pay_test_on() ) {
		// The test checkout page's buttons: paid, declined or cancelled. The token in the checkout's
		// address stands in for the provider's signature.
		register_rest_route( OGC_NS, '/pay/test/(?P<id>\d+)', array(
			array( 'methods' => 'GET', 'callback' => 'ogc_pay_test_get', 'permission_callback' => '__return_true' ),
			array( 'methods' => 'POST', 'callback' => 'ogc_pay_test_answer', 'permission_callback' => '__return_true' ),
		) );
	}
} );

function ogc_pay_webhook( WP_REST_Request $req ) {
	$all = ogc_pay_drivers();
	$d   = isset( $all[ $req['driver'] ] ) ? $all[ $req['driver'] ] : null;
	if ( ! $d || empty( $d['webhook'] ) || ! is_callable( $d['webhook'] ) ) {
		return new WP_Error( 'ogc_not_found', 'Not found.', array( 'status' => 404 ) );
	}
	$ans = call_user_func( $d['webhook'], $req );
	if ( is_wp_error( $ans ) ) {
		return $ans;
	}
	$p = ogc_pay_get( (int) $ans['id'] );
	if ( ! $p || $p['driver'] !== $req['driver'] ) {
		return new WP_Error( 'ogc_not_found', 'Not found.', array( 'status' => 404 ) );
	}
	$out = ogc_pay_answer( $p, $ans['outcome'], isset( $ans['ref'] ) ? $ans['ref'] : '', array(
		'cents'    => isset( $ans['cents'] ) ? $ans['cents'] : null,
		'currency' => isset( $ans['currency'] ) ? $ans['currency'] : null,
	) );
	if ( is_wp_error( $out ) ) {
		return $out;
	}
	return rest_ensure_response( array( 'ok' => true ) );
}

/**
 * The provider's answer to a charge: paid, declined or cancelled. Only a pending charge changes. A
 * "paid" must name the amount and currency charged ($got: cents, currency), and they must match the
 * ledger row; otherwise nothing changes, and pay_mismatch is logged for the treasurer.
 */
function ogc_pay_answer( $p, $outcome, $ref = '', $got = array() ) {
	if ( 'pending' !== $p['status'] || 'charge' !== $p['kind'] ) {
		return $p;
	}
	if ( 'paid' === $outcome ) {
		$cents = isset( $got['cents'] ) && is_numeric( $got['cents'] ) ? (int) $got['cents'] : null;
		$cur   = isset( $got['currency'] ) ? strtoupper( (string) $got['currency'] ) : null;
		if ( $cents !== (int) $p['cents'] || $cur !== ogc_pay_currency() ) {
			ogc_log( 'pay_mismatch', $p['year'], 'payments', array( 'id' => $p['id'], 'record' => $p['record_id'], 'want' => (int) $p['cents'], 'got' => $cents, 'currency' => $cur ) );
			return new WP_Error( 'ogc_pay_mismatch', 'Amount or currency doesn’t match', array( 'status' => 409 ) );
		}
	}
	$status = 'paid' === $outcome ? 'paid' : ( 'declined' === $outcome ? 'failed' : 'cancelled' );
	ogc_pay_set( $p['id'], array( 'status' => $status, 'ref' => $ref ) );
	ogc_log( 'pay_' . $status, $p['year'], 'payments', array( 'id' => $p['id'], 'record' => $p['record_id'] ) );
	do_action( 'ogc_payment_answered', ogc_pay_get( $p['id'] ), $outcome );
	return ogc_pay_get( $p['id'] );
}

function ogc_pay_test_check( WP_REST_Request $req ) {
	$p = ogc_pay_get( (int) $req['id'] );
	$t = (string) $req->get_param( 't' );
	if ( ! $p || 'test' !== $p['driver'] || '' === $t || ! hash_equals( $p['token'], hash( 'sha256', $t ) ) ) {
		return new WP_Error( 'ogc_not_found', 'Not found.', array( 'status' => 404 ) );
	}
	return $p;
}

function ogc_pay_test_get( WP_REST_Request $req ) {
	$p = ogc_pay_test_check( $req );
	if ( is_wp_error( $p ) ) {
		return $p;
	}
	return rest_ensure_response( array( 'id' => $p['id'], 'cents' => $p['cents'], 'status' => $p['status'], 'rid' => $p['rid'], 'year' => $p['year'] ) );
}

function ogc_pay_test_answer( WP_REST_Request $req ) {
	$p = ogc_pay_test_check( $req );
	if ( is_wp_error( $p ) ) {
		return $p;
	}
	$o = (string) $req->get_param( 'outcome' );
	if ( ! in_array( $o, array( 'paid', 'declined', 'cancelled' ), true ) ) {
		return new WP_Error( 'ogc_bad_outcome', 'outcome is paid, declined or cancelled.', array( 'status' => 400 ) );
	}
	// The checkout's preview date (?as_of, a local site only) dates the line and what follows from it, as on
	// the form's own requests (ogc_pay_now, ogc_reg_today).
	if ( empty( $GLOBALS['ogc_reg_req'] ) ) {
		$GLOBALS['ogc_reg_req'] = $req;
	}
	// The stand-in provider answers as a real one must: the amount and currency it charged.
	$p = ogc_pay_answer( $p, $o, 'test-' . $p['id'], array( 'cents' => $p['cents'], 'currency' => ogc_pay_currency() ) );
	if ( is_wp_error( $p ) ) {
		return $p;
	}
	return rest_ensure_response( array( 'id' => $p['id'], 'status' => $p['status'], 'year' => $p['year'], 'record' => $p['record_id'] ) );
}
