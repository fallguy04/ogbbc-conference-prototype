<?php
/**
 * Payments (register area): the ledger and the payment provider's interface.
 *
 * No card number ever touches this code. Paying by card means: a pending charge is written to the
 * ledger, the person goes to the provider's own checkout page, and only the provider's answer (its
 * webhook) marks the charge paid. Which provider, and whose account, is the COA treasurer's choice
 * (docs/21), so the provider is a driver behind one small interface:
 *
 *   add_filter( 'ogc_payment_drivers', function ( $d ) {
 *       $d['acme'] = array(
 *           'label'   => 'Acme',
 *           // $payment has id, cents, currency, rid, and return (where the provider sends the payer
 *           // back: the registration's Registered page or Your sign-ups).
 *           'start'   => function ( $payment, $reg ) { … return $checkout_url; },   // or WP_Error
 *           // Checks the provider's signature itself, then says what was charged:
 *           'webhook' => function ( WP_REST_Request $req ) { … return array( 'id' => …, 'outcome' => 'paid'|'declined'|'cancelled',
 *                                                                              'cents' => …, 'currency' => 'USD', 'ref' => … ); },
 *           // Optional: send a refund back to the card. Without it, refunds are "manual": the
 *           // treasurer sends them and marks them sent (reg/r/{id}/ledger).
 *           'refund'  => function ( $charge, $cents ) { … return array( 'ref' => … ); },   // or WP_Error
 *       );
 *       return $d;
 *   } );
 *   and the option ogc_payment_driver = 'acme'.
 *
 * A charge is marked paid only when the provider's answer names the same amount and currency as the
 * ledger row; anything else is refused and logged (pay_mismatch) for the treasurer.
 *
 * Locally (OGC_DEV on a local address only) the "test" driver stands in: its checkout page is the
 * form's own ?checkout= view, which says the provider's page goes there and lets the tester pay,
 * decline or cancel. Anywhere else the test driver doesn't exist, and the option naming it is ignored.
 * On ogbbc.org with no driver set, card payment isn't offered at all (checks only).
 *
 * The ledger (ogc_payments): one row per charge, refund, check or desk payment, amounts in whole
 * cents. A registration's money (paid, due, refund pending) is always summed from it, never kept
 * as a number the page sent.
 */

defined( 'ABSPATH' ) || exit;

add_filter( 'ogc_schema', function ( $sql, $charset ) {
	// kind: charge (card) · check · desk (cash or check at the desk) · refund
	// status: pending · paid · failed · cancelled (charges, checks) · requested · approved · sent (refunds)
	$sql[] = 'CREATE TABLE ' . ogc_table( 'payments' ) . " (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  year smallint(5) unsigned NOT NULL,
  record_id bigint(20) unsigned NOT NULL,
  rid varchar(24) NOT NULL DEFAULT '',
  kind varchar(16) NOT NULL,
  method varchar(16) NOT NULL DEFAULT '',
  cents int(11) NOT NULL DEFAULT 0,
  status varchar(16) NOT NULL,
  driver varchar(32) NOT NULL DEFAULT '',
  ref varchar(128) NOT NULL DEFAULT '',
  idem varchar(64) NOT NULL DEFAULT '',
  token varchar(64) NOT NULL DEFAULT '',
  note varchar(255) NOT NULL DEFAULT '',
  sample tinyint(1) NOT NULL DEFAULT 0,
  by_user bigint(20) unsigned NOT NULL DEFAULT 0,
  created_at datetime NULL,
  updated_at datetime NULL,
  PRIMARY KEY  (id),
  KEY record_id (record_id),
  KEY year (year),
  KEY idem (idem)
) $charset;";
	return $sql;
}, 20, 2 );

/* ------------------------------------------------------------------ the drivers */

/** Every driver this site has: the test driver locally, and any a site plugin adds. */
function ogc_pay_drivers() {
	$d = array();
	if ( ogc_pay_test_on() ) {
		$d['test'] = array(
			'label'   => 'Test',
			'start'   => function ( $p ) {
				// The return address's preview date and next page ride along, so the stand-in checkout
				// sends the tester back where a provider would.
				$q = array( 'year' => (int) $p['year'], 'checkout' => (int) $p['id'], 't' => $p['token'] );
				$r = array();
				wp_parse_str( (string) wp_parse_url( isset( $p['return'] ) ? $p['return'] : '', PHP_URL_QUERY ), $r );
				foreach ( array( 'as-of', 'then' ) as $k ) {
					if ( ! empty( $r[ $k ] ) ) {
						$q[ $k ] = (string) $r[ $k ];
					}
				}
				if ( isset( $r['view'] ) ) {
					$q['then'] = 'done' === $r['view'] ? 'done' : 'mine';
				}
				return ogc_url( 'register', $q );
			},
			'webhook' => null, // the test page answers through /pay/test/{id}
		);
	}
	$d = (array) apply_filters( 'ogc_payment_drivers', $d );
	// Never a test driver outside a local dev site, whatever a plugin adds.
	if ( ! ogc_pay_test_on() ) {
		unset( $d['test'] );
	}
	return $d;
}

/** The test driver: OGC_DEV and a local address (127.0.0.1, localhost, *.test), never a staging copy. */
function ogc_pay_test_on() {
	return OGC_DEV && function_exists( 'ogc_is_local_host' ) && ogc_is_local_host();
}

/** The currency every charge is in (the option ogc_currency, a three-letter code). */
function ogc_pay_currency() {
	$c = strtoupper( (string) get_option( 'ogc_currency', 'USD' ) );
	return preg_match( '/^[A-Z]{3}$/', $c ) ? $c : 'USD';
}

/** Send a refund back through the provider when its driver can ('refund'); otherwise it's "manual" and
 * the treasurer sends it. Returns 'sent', 'manual', or WP_Error. */
function ogc_pay_refund_via( $refund ) {
	$charge = null;
	foreach ( ogc_pay_rows( $refund['record_id'] ) as $p ) {
		if ( 'charge' === $p['kind'] && 'paid' === $p['status'] && $p['cents'] >= $refund['cents'] ) {
			$charge = $p;
		}
	}
	$all = ogc_pay_drivers();
	$drv = $charge && isset( $all[ $charge['driver'] ] ) ? $all[ $charge['driver'] ] : null;
	if ( ! $drv || empty( $drv['refund'] ) || ! is_callable( $drv['refund'] ) ) {
		return 'manual';
	}
	$out = call_user_func( $drv['refund'], $charge, (int) $refund['cents'] );
	if ( is_wp_error( $out ) ) {
		ogc_log( 'pay_refund_failed', $refund['year'], 'payments', array( 'id' => $refund['id'] ) );
		return $out;
	}
	ogc_pay_set( $refund['id'], array( 'status' => 'sent', 'ref' => isset( $out['ref'] ) ? (string) $out['ref'] : '', 'driver' => $charge['driver'] ) );
	ogc_log( 'pay_refund_sent', $refund['year'], 'payments', array( 'id' => $refund['id'] ) );
	return 'sent';
}

/** The driver in use, or null: card payment is offered only when there is one. */
function ogc_pay_driver() {
	$all  = ogc_pay_drivers();
	$name = (string) get_option( 'ogc_payment_driver', ogc_pay_test_on() ? 'test' : '' );
	if ( 'test' === $name && ! ogc_pay_test_on() ) {
		return null;
	}
	return ( $name && isset( $all[ $name ] ) ) ? array_merge( array( 'name' => $name ), $all[ $name ] ) : null;
}

/* ------------------------------------------------------------------ the ledger */

function ogc_pay_row( $r ) {
	return array(
		'id'         => (int) $r['id'],
		'year'       => (int) $r['year'],
		'record_id'  => (int) $r['record_id'],
		'rid'        => $r['rid'],
		'kind'       => $r['kind'],
		'method'     => $r['method'],
		'cents'      => (int) $r['cents'],
		'status'     => $r['status'],
		'driver'     => $r['driver'],
		'ref'        => $r['ref'],
		'idem'       => $r['idem'],
		'token'      => $r['token'],
		'note'       => $r['note'],
		'sample'     => (bool) (int) $r['sample'],
		'by_user'    => (int) $r['by_user'],
		'created_at' => $r['created_at'],
		'updated_at' => $r['updated_at'],
	);
}

function ogc_pay_get( $id ) {
	global $wpdb;
	$r = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . ogc_table( 'payments' ) . ' WHERE id = %d', $id ), ARRAY_A );
	return $r ? ogc_pay_row( $r ) : null;
}

/** A registration's ledger, oldest first. */
function ogc_pay_rows( $record_id ) {
	global $wpdb;
	$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . ogc_table( 'payments' ) . ' WHERE record_id = %d ORDER BY id', $record_id ), ARRAY_A );
	return array_map( 'ogc_pay_row', (array) $rows );
}

/** Every ledger row of a year (the treasurer's export). */
function ogc_pay_year( $year, $with_samples = true ) {
	global $wpdb;
	$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . ogc_table( 'payments' ) . ' WHERE year = %d' . ( $with_samples ? '' : ' AND sample = 0' ) . ' ORDER BY id', $year ), ARRAY_A );
	return array_map( 'ogc_pay_row', (array) $rows );
}

/** The row with this idempotency key, if any (a retried Pay gets the same payment). */
function ogc_pay_by_idem( $record_id, $idem ) {
	global $wpdb;
	if ( '' === (string) $idem ) {
		return null;
	}
	$r = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . ogc_table( 'payments' ) . ' WHERE record_id = %d AND idem = %s ORDER BY id DESC LIMIT 1', $record_id, $idem ), ARRAY_A );
	return $r ? ogc_pay_row( $r ) : null;
}

function ogc_pay_add( $rec, $kind, $method, $cents, $status, $extra = array() ) {
	global $wpdb;
	$now = ogc_now();
	$ok  = $wpdb->insert(
		ogc_table( 'payments' ),
		array(
			'year'       => (int) $rec['year'],
			'record_id'  => (int) $rec['id'],
			'rid'        => (string) ( isset( $rec['data']['rid'] ) ? $rec['data']['rid'] : '' ),
			'kind'       => $kind,
			'method'     => $method,
			'cents'      => (int) $cents,
			'status'     => $status,
			'driver'     => isset( $extra['driver'] ) ? (string) $extra['driver'] : '',
			'ref'        => isset( $extra['ref'] ) ? substr( (string) $extra['ref'], 0, 128 ) : '',
			'idem'       => isset( $extra['idem'] ) ? substr( (string) $extra['idem'], 0, 64 ) : '',
			'token'      => isset( $extra['token'] ) ? (string) $extra['token'] : '',
			'note'       => isset( $extra['note'] ) ? substr( sanitize_text_field( (string) $extra['note'] ), 0, 255 ) : '',
			'sample'     => ! empty( $rec['sample'] ) ? 1 : 0,
			'by_user'    => get_current_user_id(),
			'created_at' => isset( $extra['at'] ) ? $extra['at'] : $now,
			'updated_at' => $now,
		),
		array( '%d', '%d', '%s', '%s', '%s', '%d', '%s', '%s', '%s', '%s', '%s', '%s', '%d', '%d', '%s', '%s' )
	);
	return $ok ? (int) $wpdb->insert_id : 0;
}

function ogc_pay_set( $id, $fields ) {
	global $wpdb;
	$allowed = array_intersect_key( (array) $fields, array_flip( array( 'status', 'cents', 'ref', 'note', 'method', 'driver' ) ) );
	if ( ! $allowed ) {
		return false;
	}
	$allowed['updated_at'] = ogc_now();
	return false !== $wpdb->update( ogc_table( 'payments' ), $allowed, array( 'id' => (int) $id ) );
}

/** Erase a year's sample ledger rows (with Clear samples). */
function ogc_pay_clear_samples( $year ) {
	global $wpdb;
	return (int) $wpdb->query( $wpdb->prepare( 'DELETE FROM ' . ogc_table( 'payments' ) . ' WHERE year = %d AND sample = 1', $year ) );
}

/**
 * A registration's money, summed from its ledger (cents):
 *   paid     card charges, checks and desk payments received, less refunds sent
 *   check    checks still to come
 *   pending  card charges started and not yet answered
 *   refund   refunds asked for or approved, not yet sent
 */
function ogc_pay_sum( $rows ) {
	$m = array( 'paid' => 0, 'check' => 0, 'pending' => 0, 'refund' => 0, 'refunded' => 0 );
	foreach ( (array) $rows as $p ) {
		if ( 'refund' === $p['kind'] ) {
			if ( 'sent' === $p['status'] ) {
				$m['paid']     -= $p['cents'];
				$m['refunded'] += $p['cents'];
			} elseif ( in_array( $p['status'], array( 'requested', 'approved' ), true ) ) {
				$m['refund'] += $p['cents'];
			}
			continue;
		}
		if ( 'paid' === $p['status'] ) {
			$m['paid'] += $p['cents'];
		} elseif ( 'pending' === $p['status'] ) {
			if ( 'check' === $p['kind'] ) {
				$m['check'] += $p['cents'];
			} else {
				$m['pending'] += $p['cents'];
			}
		}
	}
	return $m;
}

/** A ledger row's day (Y-m-d) at the venue. Times are stored in UTC; the day is read in the year's time
 * zone (the one every date in this area uses), so a payment at 8:27 PM Pacific isn't dated the next day
 * on a receipt, Your sign-ups or the treasurer's CSV. */
function ogc_pay_day( $utc, $year ) {
	if ( ! $utc ) {
		return '';
	}
	try {
		$d = new DateTime( (string) $utc, new DateTimeZone( 'UTC' ) );
	} catch ( Exception $e ) {
		return substr( (string) $utc, 0, 10 );
	}
	$d->setTimezone( function_exists( 'ogc_reg_tz' ) ? ogc_reg_tz( $year ) : wp_timezone() );
	return $d->format( 'Y-m-d' );
}

/** A ledger row as the household sees it on Your sign-ups (no driver refs or tokens). */
function ogc_pay_public( $p ) {
	return array(
		'id'     => $p['id'],
		'at'     => ogc_pay_day( $p['updated_at'], $p['year'] ),
		'kind'   => $p['kind'],
		'method' => $p['method'],
		'cents'  => $p['cents'],
		'status' => $p['status'],
		'note'   => $p['note'],
	);
}

/* ------------------------------------------------------------------ the test driver's answer */

add_action( 'rest_api_init', function () {
	// A provider's webhook (a real driver checks the provider's signature itself).
	register_rest_route( OGC_NS, '/pay/webhook/(?P<driver>[a-z0-9_-]{1,32})', array(
		'methods'             => 'POST',
		'callback'            => 'ogc_pay_webhook',
		'permission_callback' => '__return_true',
	) );
	if ( ogc_pay_test_on() ) {
		// The test checkout page's buttons: paid, declined or cancelled. The token in the checkout's
		// address stands in for the provider's signature.
		register_rest_route( OGC_NS, '/pay/test/(?P<id>\d+)', array(
			array( 'methods' => 'GET', 'callback' => 'ogc_pay_test_get', 'permission_callback' => '__return_true' ),
			array( 'methods' => 'POST', 'callback' => 'ogc_pay_test_answer', 'permission_callback' => '__return_true' ),
		) );
	}
} );

function ogc_pay_webhook( WP_REST_Request $req ) {
	$all = ogc_pay_drivers();
	$d   = isset( $all[ $req['driver'] ] ) ? $all[ $req['driver'] ] : null;
	if ( ! $d || empty( $d['webhook'] ) || ! is_callable( $d['webhook'] ) ) {
		return new WP_Error( 'ogc_not_found', 'Not found.', array( 'status' => 404 ) );
	}
	$ans = call_user_func( $d['webhook'], $req );
	if ( is_wp_error( $ans ) ) {
		return $ans;
	}
	$p = ogc_pay_get( (int) $ans['id'] );
	if ( ! $p || $p['driver'] !== $req['driver'] ) {
		return new WP_Error( 'ogc_not_found', 'Not found.', array( 'status' => 404 ) );
	}
	$out = ogc_pay_answer( $p, $ans['outcome'], isset( $ans['ref'] ) ? $ans['ref'] : '', array(
		'cents'    => isset( $ans['cents'] ) ? $ans['cents'] : null,
		'currency' => isset( $ans['currency'] ) ? $ans['currency'] : null,
	) );
	if ( is_wp_error( $out ) ) {
		return $out;
	}
	return rest_ensure_response( array( 'ok' => true ) );
}

/**
 * The provider's answer to a charge: paid, declined or cancelled. Only a pending charge changes. A
 * "paid" must name the amount and currency charged ($got: cents, currency), and they must match the
 * ledger row; otherwise nothing changes, and pay_mismatch is logged for the treasurer.
 */
function ogc_pay_answer( $p, $outcome, $ref = '', $got = array() ) {
	if ( 'pending' !== $p['status'] || 'charge' !== $p['kind'] ) {
		return $p;
	}
	if ( 'paid' === $outcome ) {
		$cents = isset( $got['cents'] ) && is_numeric( $got['cents'] ) ? (int) $got['cents'] : null;
		$cur   = isset( $got['currency'] ) ? strtoupper( (string) $got['currency'] ) : null;
		if ( $cents !== (int) $p['cents'] || $cur !== ogc_pay_currency() ) {
			ogc_log( 'pay_mismatch', $p['year'], 'payments', array( 'id' => $p['id'], 'record' => $p['record_id'], 'want' => (int) $p['cents'], 'got' => $cents, 'currency' => $cur ) );
			return new WP_Error( 'ogc_pay_mismatch', 'Amount or currency doesn’t match', array( 'status' => 409 ) );
		}
	}
	$status = 'paid' === $outcome ? 'paid' : ( 'declined' === $outcome ? 'failed' : 'cancelled' );
	ogc_pay_set( $p['id'], array( 'status' => $status, 'ref' => $ref ) );
	ogc_log( 'pay_' . $status, $p['year'], 'payments', array( 'id' => $p['id'], 'record' => $p['record_id'] ) );
	do_action( 'ogc_payment_answered', ogc_pay_get( $p['id'] ), $outcome );
	return ogc_pay_get( $p['id'] );
}

function ogc_pay_test_check( WP_REST_Request $req ) {
	$p = ogc_pay_get( (int) $req['id'] );
	$t = (string) $req->get_param( 't' );
	if ( ! $p || 'test' !== $p['driver'] || '' === $t || ! hash_equals( $p['token'], hash( 'sha256', $t ) ) ) {
		return new WP_Error( 'ogc_not_found', 'Not found.', array( 'status' => 404 ) );
	}
	return $p;
}

function ogc_pay_test_get( WP_REST_Request $req ) {
	$p = ogc_pay_test_check( $req );
	if ( is_wp_error( $p ) ) {
		return $p;
	}
	return rest_ensure_response( array( 'id' => $p['id'], 'cents' => $p['cents'], 'status' => $p['status'], 'rid' => $p['rid'], 'year' => $p['year'] ) );
}

function ogc_pay_test_answer( WP_REST_Request $req ) {
	$p = ogc_pay_test_check( $req );
	if ( is_wp_error( $p ) ) {
		return $p;
	}
	$o = (string) $req->get_param( 'outcome' );
	if ( ! in_array( $o, array( 'paid', 'declined', 'cancelled' ), true ) ) {
		return new WP_Error( 'ogc_bad_outcome', 'outcome is paid, declined or cancelled.', array( 'status' => 400 ) );
	}
	// The stand-in provider answers as a real one must: the amount and currency it charged.
	$p = ogc_pay_answer( $p, $o, 'test-' . $p['id'], array( 'cents' => $p['cents'], 'currency' => ogc_pay_currency() ) );
	if ( is_wp_error( $p ) ) {
		return $p;
	}
	return rest_ensure_response( array( 'id' => $p['id'], 'status' => $p['status'], 'year' => $p['year'], 'record' => $p['record_id'] ) );
}
