<?php
/**
 * The committees' back end as one app (docs/23): /annual-conference/app/.
 *
 * The frame: who the viewer is in a year (the COA, a committee, a webmaster, or someone seeing as a
 * committee), which screens they may open (the screen registry), the committees and what each keeps
 * (tasks, files, notes for next year, a report), and a year carried forward from the last one.
 * DEV.md › App has the routes, the registry, the kit, the data and the permissions.
 *
 * Who is on which committee is the members list (module-members.php: ogc_members.committees and head),
 * never a second copy: the COA adds people on the app's Members screen, through the members routes.
 * The committees themselves (name, responsibilities, order, screens handed) are this file's table, and
 * the year's committees.csv is kept in step so the members' Invite pills show the same list.
 *
 * Files: module-app-seed.php (the committees and tasks a first year starts from, sample people on a
 * local site), module-app-rest.php (the routes).
 */

defined( 'ABSPATH' ) || exit;

/* ================================================================== tables */

add_filter( 'ogc_schema', 'ogc_app_schema', 30, 2 );

function ogc_app_schema( $sql, $charset ) {
	// A year's committees. ckey is ogc_committee_key( name ), the key ogc_members.committees holds;
	// 'coa' is the Committee of Arrangements itself (its people are the members whose role is coa).
	// screens: the screen ids the COA handed this committee (comma-separated).
	$sql[] = 'CREATE TABLE ' . ogc_table( 'committees' ) . " (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  year smallint(5) unsigned NOT NULL,
  ckey varchar(60) NOT NULL,
  name varchar(80) NOT NULL,
  duties longtext NULL,
  sort int(10) NOT NULL DEFAULT 0,
  screens varchar(255) NOT NULL DEFAULT '',
  link varchar(255) NOT NULL DEFAULT '',
  from_year smallint(5) unsigned NOT NULL DEFAULT 0,
  checked_at datetime NULL,
  created_at datetime NULL,
  updated_at datetime NULL,
  removed_at datetime NULL,
  PRIMARY KEY  (id),
  UNIQUE KEY year_ckey (year,ckey)
) $charset;";
	// What a committee does by a date. due_offset: days from the Conference's first day (its Friday);
	// due_date: a calendar date ('Y-m-d') instead. owner: a member id, when one person has it.
	$sql[] = 'CREATE TABLE ' . ogc_table( 'tasks' ) . " (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  year smallint(5) unsigned NOT NULL,
  ckey varchar(60) NOT NULL,
  title varchar(190) NOT NULL,
  note text NULL,
  due_offset int(11) NULL,
  due_date varchar(10) NOT NULL DEFAULT '',
  owner bigint(20) unsigned NOT NULL DEFAULT 0,
  sort int(10) NOT NULL DEFAULT 0,
  done_by bigint(20) unsigned NOT NULL DEFAULT 0,
  done_at datetime NULL,
  source varchar(16) NOT NULL DEFAULT 'added',
  kind varchar(32) NOT NULL DEFAULT '',
  carried_from bigint(20) unsigned NOT NULL DEFAULT 0,
  created_by bigint(20) unsigned NOT NULL DEFAULT 0,
  created_at datetime NULL,
  removed_at datetime NULL,
  PRIMARY KEY  (id),
  KEY year_ckey (year,ckey)
) $charset;";
	// A committee's files: kept outside the public uploads (ogc_app_private_dir), served only through
	// GET /app/files/{id} with a permission check. fkey is the stored file's random name (not "stored": a MySQL word); name is what it was called.
	$sql[] = 'CREATE TABLE ' . ogc_table( 'cfiles' ) . " (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  year smallint(5) unsigned NOT NULL,
  ckey varchar(60) NOT NULL,
  name varchar(190) NOT NULL,
  fkey varchar(64) NOT NULL,
  mime varchar(100) NOT NULL DEFAULT '',
  size bigint(20) unsigned NOT NULL DEFAULT 0,
  uploaded_by bigint(20) unsigned NOT NULL DEFAULT 0,
  carried_from bigint(20) unsigned NOT NULL DEFAULT 0,
  created_at datetime NULL,
  removed_at datetime NULL,
  PRIMARY KEY  (id),
  KEY year_ckey (year,ckey)
) $charset;";
	// Notes for next year, by committee: written in a year, read at the top of the next one, where
	// that year's committee marks each Done.
	$sql[] = 'CREATE TABLE ' . ogc_table( 'cnotes' ) . " (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  year smallint(5) unsigned NOT NULL,
  ckey varchar(60) NOT NULL,
  body text NOT NULL,
  author bigint(20) unsigned NOT NULL DEFAULT 0,
  source varchar(16) NOT NULL DEFAULT 'added',
  created_at datetime NULL,
  done_by bigint(20) unsigned NOT NULL DEFAULT 0,
  done_at datetime NULL,
  removed_at datetime NULL,
  PRIMARY KEY  (id),
  KEY year_ckey (year,ckey)
) $charset;";
	// A committee's report to the COA after the Conference: the answers to the COA's questions.
	$sql[] = 'CREATE TABLE ' . ogc_table( 'creports' ) . " (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  year smallint(5) unsigned NOT NULL,
  ckey varchar(60) NOT NULL,
  answers longtext NOT NULL,
  updated_by bigint(20) unsigned NOT NULL DEFAULT 0,
  updated_at datetime NULL,
  sent_at datetime NULL,
  PRIMARY KEY  (id),
  UNIQUE KEY year_ckey (year,ckey)
) $charset;";
	return $sql;
}

/* ================================================================== the page */

add_filter( 'ogc_pages', function ( $p ) {
	$p['app'] = array(
		'path'        => 'app',
		// A members' page: signed out → sign-in with a return; signed in but not on the year → the
		// No access card (ogc_page_refuse). Webmasters open every year.
		'members'     => true,
		'folder'      => 'app',
		'shell'       => 'bare',
		'template'    => 'app.php',
		'html_class'  => 'ogc-appshell',
		'title'       => 'Conference',
		'noindex'     => true,
		'description' => '',
		'header'      => array(),
		'fonts'       => '',
		'head'        => '',
		'styles'      => array( 'app/app.css' ),
		// The kit and shell first, then each screen file (a screen registers itself). The COA's and the
		// committees' screens add theirs with the ogc_pages filter (after app/app.js).
		'scripts'     => array( 'app/app.js', 'app/screen-home.js', 'app/screen-committees.js', 'app/screen-tasks.js', 'app/screen-members.js' ),
	);
	return $p;
}, 15 );

// The app's own page: no site stylesheet, its own type (system sans, the headline in Noto Serif).
add_filter( 'ogc_client_config', function ( $cfg, $key ) {
	if ( 'app' !== $key ) {
		return $cfg;
	}
	// phpcs:ignore WordPress.Security.NonceVerification -- which year to open.
	$y = isset( $_GET['year'] ) ? sanitize_text_field( wp_unslash( $_GET['year'] ) ) : '';
	$cfg['app'] = array(
		'year'  => ogc_valid_year( $y ) ? (int) $y : ogc_app_default_year(),
		'files' => esc_url_raw( rest_url( OGC_NS . '/app/files/' ) ),
		'mail'  => function_exists( 'ogc_mail_log_on' ) && ogc_mail_log_on() ? wp_make_link_relative( ogc_url( 'mail' ) ) : '',
	);
	return $cfg;
}, 10, 2 );

/** The year the app opens on with no ?year: the viewer's soonest Conference that hasn't ended, else
 * their newest; a webmaster's is the featured year. */
function ogc_app_default_year() {
	$years = ogc_member_years();
	if ( ogc_is_webmaster() ) {
		$f = ogc_featured_year();
		if ( $f ) {
			return $f;
		}
	}
	if ( ! $years ) {
		return (int) gmdate( 'Y' );
	}
	sort( $years );
	$today = wp_date( 'Y-m-d' );
	foreach ( $years as $y ) {
		$row = ogc_year_get( $y );
		if ( ! $row || empty( $row['end'] ) || $row['end'] >= $today ) {
			return (int) $y;
		}
	}
	return (int) end( $years );
}

/* ================================================================== who's looking */

/**
 * The viewer in a year, as every app route sees them:
 *   coa         on the year's COA (or a dev member on a local site, as ogc_member_can treats them)
 *   webmaster   a Conference webmaster (structure, Years and Access; names only by seeing as)
 *   committees  the committee keys they're on (never the COA's)
 *   head        heads their committee
 *   member_id   their row in the members list (0 for a webmaster or dev member)
 *   as          a committee key being seen as ('' when not): the COA and webmasters only; the rest of
 *               the array is then that committee's view, and 'real' keeps who they are.
 * $as comes from the request (?as=), never from storage, so another tab isn't changed.
 */
function ogc_app_viewer( $year, $as = '' ) {
	$year = (int) $year;
	// See as Head or Helper (Round 6b; README 2.6): ?as_role=helper sees the committee as a helper does.
	// phpcs:ignore WordPress.Security.NonceVerification -- which view to draw; every write is refused anyway.
	$role = isset( $_GET['as_role'] ) && 'helper' === sanitize_key( wp_unslash( $_GET['as_role'] ) ) ? 'helper' : 'head';
	$key  = $year . '|' . get_current_user_id() . '|' . $as . '|' . $role;
	if ( isset( $GLOBALS['ogc_app_v'][ $key ] ) ) {
		return $GLOBALS['ogc_app_v'][ $key ];
	}
	$wm  = ogc_is_webmaster();
	$m   = function_exists( 'ogc_member_me' ) ? ogc_member_me( $year ) : null;
	$dev = ! $m && ! $wm && function_exists( 'ogc_dev_tools_on' ) && ogc_dev_tools_on() && ogc_is_member( $year );
	$coa = ( $m && 'coa' === $m['role'] ) || $dev;
	$v   = array(
		'year'       => $year,
		'coa'        => $coa,
		'webmaster'  => $wm,
		'committees' => $m && 'coa' !== $m['role'] ? array_values( array_filter( ogc_member_committee_keys( $m ), function ( $k ) use ( $year ) {
			return (bool) ogc_app_committee( $year, $k );
		} ) ) : array(),
		'head'       => $m ? (bool) $m['head'] : false,
		'member_id'  => $m ? (int) $m['id'] : 0,
		'as'         => '',
		'open'       => $wm || ogc_is_member( $year ),
	);
	$as = ogc_committee_key( (string) $as );
	if ( '' !== $as && ( $v['coa'] || $v['webmaster'] ) ) {
		$c = ogc_app_committee( $year, $as );
		// Webmasters may see as the COA too (logged); the COA seeing as itself is just itself.
		if ( $c && ( 'coa' !== $as || ( $v['webmaster'] && ! $v['coa'] ) ) ) {
			$real = $v;
			$v    = array_merge( $v, array(
				'coa'        => 'coa' === $as,
				'webmaster'  => false,
				'committees' => 'coa' === $as ? array() : array( $as ),
				'head'       => 'coa' === $as || 'helper' !== $role,
				'member_id'  => 0,
				'as'         => $as,
				'as_role'    => 'coa' === $as ? '' : $role,
				'real'       => $real,
			) );
		}
	}
	$GLOBALS['ogc_app_v'][ $key ] = $v;
	return $v;
}

/** The viewer for a REST request: its year and ?as=. */
function ogc_app_req_viewer( WP_REST_Request $req, $year = null ) {
	return ogc_app_viewer( null === $year ? (int) $req['year'] : (int) $year, (string) $req->get_param( 'as' ) );
}

/** Is the viewer on this committee (or the COA, who see every committee whole)? */
function ogc_app_on_committee( $v, $ckey ) {
	if ( $v['coa'] ) {
		return true;
	}
	return in_array( (string) $ckey, (array) $v['committees'], true );
}

/* ================================================================== the screen registry */

/**
 * Every screen of the app: id → array( title, section, who ). The JS registry (OGC_APP.screen) draws
 * them; this is the rule, and a screen's data routes ask ogc_app_can_see() with the same id, so its data
 * goes only to who may see it.
 *   section  'main' (Home, Committees, Tasks: everyone) or 'own' (the section named for who you are)
 *   who      'all' (anyone who may open the year), 'coa', 'webmaster', 'committee' (anyone on a
 *            committee: their own committee's screen), or committee keys ('lodging')
 * A screen the COA hands to a committee (ogc_app_hand) is also that committee's, and leaves the COA's
 * own section (the COA still opens it from the committee's page or ⌘K).
 * An area adds its screens: add_filter( 'ogc_app_screens', fn( $s, $year ) … ).
 */
function ogc_app_screens( $year ) {
	$s = array(
		'home'       => array( 'title' => 'Home', 'section' => 'main', 'who' => array( 'all' ) ),
		'committees' => array( 'title' => 'Committees', 'section' => 'main', 'who' => array( 'all' ) ),
		'tasks'      => array( 'title' => 'Tasks', 'section' => 'main', 'who' => array( 'all' ) ),
		'overview'   => array( 'title' => 'Overview', 'section' => 'own', 'who' => array( 'committee' ) ),
		'members'    => array( 'title' => 'Members', 'section' => 'own', 'who' => array( 'coa', 'webmaster' ) ),
		'years'      => array( 'title' => 'Years', 'section' => 'own', 'who' => array( 'webmaster' ) ),
	);
	$s = (array) apply_filters( 'ogc_app_screens', $s, (int) $year );
	foreach ( $s as $id => &$d ) {
		$d = array_merge( array( 'title' => $id, 'section' => 'own', 'who' => array( 'coa' ), 'handable' => true ), (array) $d );
		$d['who'] = array_values( array_map( 'strval', (array) $d['who'] ) );
	}
	unset( $d );
	// The frame's own screens are never handed.
	foreach ( array( 'home', 'committees', 'tasks', 'overview', 'members', 'years' ) as $id ) {
		$s[ $id ]['handable'] = false;
	}
	return $s;
}

/** The committee a screen was handed to this year ('' if none). */
function ogc_app_handed_to( $year, $id ) {
	foreach ( ogc_app_committees( $year ) as $c ) {
		if ( in_array( $id, $c['screens'], true ) ) {
			return $c['ckey'];
		}
	}
	return '';
}

/** May this viewer see the screen (and so its data)? */
function ogc_app_can_see( $v, $id ) {
	if ( empty( $v['open'] ) ) {
		return false;
	}
	$all = ogc_app_screens( $v['year'] );
	if ( ! isset( $all[ $id ] ) ) {
		return false;
	}
	$who = $all[ $id ]['who'];
	if ( in_array( 'all', $who, true ) ) {
		return true;
	}
	if ( $v['coa'] && in_array( 'coa', $who, true ) ) {
		return true;
	}
	// A committee's own screen the COA may open too (from the committee's page or ⌘K), without it
	// joining the COA's sidebar (app-committees: Lodging's Rooms, Food's Meal counts…).
	if ( $v['coa'] && ! empty( $all[ $id ]['coa_opens'] ) ) {
		return true;
	}
	if ( $v['webmaster'] && in_array( 'webmaster', $who, true ) ) {
		return true;
	}
	if ( $v['committees'] && in_array( 'committee', $who, true ) ) {
		return true;
	}
	if ( array_intersect( (array) $v['committees'], $who ) ) {
		return true;
	}
	$to = ogc_app_handed_to( $v['year'], $id );
	return '' !== $to && in_array( $to, (array) $v['committees'], true );
}

/** The screens the viewer may see, as the shell draws them. */
function ogc_app_screens_for( $v ) {
	$out   = array();
	$opens = function_exists( 'ogc_app_screen_opens' ) ? ogc_app_screen_opens( $v['year'] ) : array();
	// Simple mode (module-app-simple.php) leaves some screens out of the app; their routes answer as before.
	$simple = function_exists( 'ogc_app_simple' ) && ogc_app_simple();
	$titles = $simple ? array( 'packet' => 'Packet and Help', 'help' => 'Help', 'requests' => 'Packet and Help' ) : array();
	foreach ( ogc_app_screens( $v['year'] ) as $id => $d ) {
		if ( ! ogc_app_can_see( $v, $id ) || ( $simple && ogc_app_simple_hides( $v, $id ) ) ) {
			continue;
		}
		$out[] = array(
			// When it comes into season ('' always): the sidebar shows it quietly before then.
			'opens'    => isset( $opens[ $id ] ) ? (string) $opens[ $id ] : '',
			'id'       => $id,
			'title'    => isset( $titles[ $id ] ) ? $titles[ $id ] : $d['title'],
			'section'  => $d['section'],
			'who'      => $d['who'],
			'handed'   => ogc_app_handed_to( $v['year'], $id ),
			'handable' => (bool) $d['handable'],
		);
	}
	return $out;
}

// The invite names a committee's screens ("Overview, Households, Rooms").
add_filter( 'ogc_committee_screens', function ( $words, $year, $key ) {
	if ( '' !== $words || ! $year ) {
		return $words;
	}
	$v     = array( 'year' => (int) $year, 'coa' => false, 'webmaster' => false, 'committees' => array( $key ), 'head' => false, 'member_id' => 0, 'as' => '', 'open' => true );
	$names = array();
	foreach ( ogc_app_screens_for( $v ) as $s ) {
		if ( 'own' === $s['section'] ) {
			$names[] = $s['title'];
		}
	}
	return implode( ', ', $names );
}, 10, 3 );

/* ================================================================== committees */

function ogc_app_committee_row( $r ) {
	if ( ! $r ) {
		return null;
	}
	$r['id']        = (int) $r['id'];
	$r['year']      = (int) $r['year'];
	$r['sort']      = (int) $r['sort'];
	$r['from_year'] = (int) $r['from_year'];
	$r['duties']    = (string) $r['duties'];
	$r['screens']   = array_values( array_filter( array_map( 'trim', explode( ',', (string) $r['screens'] ) ), 'strlen' ) );
	return $r;
}

/** A year's committees in the COA's order, the COA first. Read once a request. */
function ogc_app_committees( $year, $reset = false ) {
	global $wpdb;
	$year = (int) $year;
	if ( $reset || ! isset( $GLOBALS['ogc_app_c'][ $year ] ) ) {
		$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . ogc_table( 'committees' ) . ' WHERE year = %d AND removed_at IS NULL ORDER BY sort, id', $year ), ARRAY_A );
		$GLOBALS['ogc_app_c'][ $year ] = array_map( 'ogc_app_committee_row', (array) $rows );
	}
	return $GLOBALS['ogc_app_c'][ $year ];
}

function ogc_app_committee( $year, $ckey ) {
	foreach ( ogc_app_committees( $year ) as $c ) {
		if ( $c['ckey'] === (string) $ckey ) {
			return $c;
		}
	}
	return null;
}

/** The people on a committee this year (active rows of the members list): the COA's are its coa rows. */
function ogc_app_people( $year, $ckey ) {
	$out = array();
	foreach ( ogc_members_list( (int) $year ) as $m ) {
		if ( ! ogc_member_active( $m ) ) {
			continue;
		}
		if ( 'coa' === $ckey ? 'coa' === $m['role'] : ( 'coa' !== $m['role'] && in_array( $ckey, ogc_member_committee_keys( $m ), true ) ) ) {
			$out[] = $m;
		}
	}
	usort( $out, function ( $a, $b ) {
		return ( $b['head'] - $a['head'] ) ?: strcmp( (string) $a['name'], (string) $b['name'] );
	} );
	return $out;
}

/** A person as the app names them: "Ruth K.", else a masked address. */
function ogc_app_person_name( $m ) {
	return $m['name'] ? ogc_first_l( $m['name'] ) : ogc_mask_email( $m['email'] );
}

/** Someone by WordPress user id, as the app names them ("Ruth K.", "A webmaster", "Someone"). */
function ogc_app_user_name( $uid, $year = 0 ) {
	if ( ! $uid ) {
		return '';
	}
	$n = ogc_person_name( $uid );
	if ( $n ) {
		return ogc_first_l( $n );
	}
	$m = $year ? ogc_member_find( $year, ogc_user_email( $uid ), true ) : null;
	if ( $m ) {
		return ogc_app_person_name( $m );
	}
	return ogc_is_webmaster( $uid ) ? 'A webmaster' : 'Someone';
}

/** Add a committee to a year (and to committees.csv, so the members' pills list it). */
function ogc_app_committee_add( $year, $name, $duties = '', $a = array() ) {
	global $wpdb;
	$name = trim( preg_replace( '/\s+committee$/i', '', sanitize_text_field( (string) $name ) ) );
	$key  = ogc_committee_key( $name );
	if ( '' === $key || strlen( $name ) > 60 || strlen( $key ) > 60 ) {
		return new WP_Error( 'ogc_bad', 'Name needed', array( 'status' => 400 ) );
	}
	$had = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . ogc_table( 'committees' ) . ' WHERE year = %d AND ckey = %s', $year, $key ), ARRAY_A );
	if ( $had && ! $had['removed_at'] ) {
		return new WP_Error( 'ogc_exists', 'Already a committee', array( 'status' => 409 ) );
	}
	$sort = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT MAX(sort) FROM ' . ogc_table( 'committees' ) . ' WHERE year = %d', $year ) ) + 10;
	$row  = array(
		'name'       => $name,
		'duties'     => ogc_app_clean_text( $duties, 4000 ),
		'sort'       => isset( $a['sort'] ) ? (int) $a['sort'] : $sort,
		'screens'    => isset( $a['screens'] ) ? (string) $a['screens'] : '',
		'link'       => isset( $a['link'] ) ? (string) $a['link'] : '',
		'from_year'  => isset( $a['from_year'] ) ? (int) $a['from_year'] : 0,
		'updated_at' => ogc_now(),
		'removed_at' => null,
	);
	if ( $had ) {
		$wpdb->update( ogc_table( 'committees' ), $row, array( 'id' => (int) $had['id'] ) );
	} else {
		$wpdb->insert( ogc_table( 'committees' ), array_merge( $row, array( 'year' => (int) $year, 'ckey' => $key, 'created_at' => ogc_now() ) ) );
	}
	ogc_app_committees( $year, true );
	if ( 'coa' !== $key ) {
		ogc_app_sync_csv( $year );
	}
	return ogc_app_committee( $year, $key );
}

/** Plain text as typed: tags out, lines kept, at most $max characters. */
function ogc_app_clean_text( $t, $max = 4000 ) {
	$t = sanitize_textarea_field( (string) $t );
	return function_exists( 'mb_substr' ) ? mb_substr( $t, 0, $max ) : substr( $t, 0, $max );
}

/**
 * A list's filters from the address (area-shell 1.4; Round 3): "field:v,v;field:v". Only the list's own
 * fixed fields are kept, and only values that pass the field's test; anything else is dropped, never
 * trusted. Each list route applies what's left inside the viewer's own scope (area-shell 15).
 * $fields: field => array( label, test( $value ) → bool ). Returns field => list of values.
 */
function ogc_app_parse_f( $raw, $fields ) {
	$out = array();
	if ( ! is_string( $raw ) || '' === $raw || strlen( $raw ) > 600 ) {
		return $out;
	}
	foreach ( explode( ';', $raw ) as $part ) {
		$kv = explode( ':', $part, 2 );
		if ( 2 !== count( $kv ) || ! isset( $fields[ $kv[0] ] ) ) {
			continue;
		}
		$vals = array();
		foreach ( array_slice( explode( ',', $kv[1] ), 0, 20 ) as $v ) {
			$v = trim( $v );
			if ( '' !== $v && strlen( $v ) <= 80 && call_user_func( $fields[ $kv[0] ][1], $v ) ) {
				$vals[] = $v;
			}
		}
		if ( $vals ) {
			$out[ $kv[0] ] = array_values( array_unique( $vals ) );
		}
	}
	return $out;
}

/**
 * committees.csv follows the table: the members' Invite pills and the year page read it. Its other
 * columns (contact_email, heads, weekly…) are kept as they are; a name the CSV has and the table
 * doesn't (a "New committee" typed in Invite) comes into the table instead (ogc_app_reconcile).
 */
function ogc_app_sync_csv( $year ) {
	if ( ! function_exists( 'ogc_file_get' ) ) {
		return;
	}
	for ( $try = 0; $try < 3; $try++ ) {
		$cur  = ogc_file_get( (int) $year, 'committees' );
		$rows = $cur ? (array) $cur['rows'] : array();
		$by   = array();
		foreach ( $rows as $i => $r ) {
			if ( isset( $r['name'] ) ) {
				$by[ ogc_committee_key( $r['name'] ) ] = $i;
			}
		}
		$out  = array();
		$seen = array();
		foreach ( ogc_app_committees( $year ) as $c ) {
			$seen[ $c['ckey'] ] = true;
			if ( 'coa' === $c['ckey'] ) {
				continue;
			}
			$r          = isset( $by[ $c['ckey'] ] ) ? $rows[ $by[ $c['ckey'] ] ] : array( 'contact_email' => '', 'contact_phone' => '', 'heads' => '', 'weekly' => 'yes' );
			$r['name']  = $c['name'];
			$r['order'] = (string) $c['sort'];
			// The committee's contact (the volunteer shifts' Monday email) is its head on the members
			// list, not a second list kept by hand.
			foreach ( ogc_app_people( $year, $c['ckey'] ) as $m ) {
				if ( ! empty( $m['head'] ) ) {
					$r['contact_email'] = $m['email'];
					break;
				}
			}
			$out[]      = $r;
		}
		// A name only the CSV has stays (ogc_app_reconcile brings it in); one the app removed goes.
		global $wpdb;
		$gone = array_flip( (array) $wpdb->get_col( $wpdb->prepare( 'SELECT ckey FROM ' . ogc_table( 'committees' ) . ' WHERE year = %d AND removed_at IS NOT NULL', $year ) ) );
		foreach ( $rows as $r ) {
			$k = isset( $r['name'] ) ? ogc_committee_key( $r['name'] ) : '';
			if ( '' !== $k && ! isset( $seen[ $k ] ) && ! isset( $gone[ $k ] ) ) {
				$out[] = $r;
			}
		}
		if ( $cur && ogc_json( $cur['rows'] ) === ogc_json( $out ) ) {
			return;
		}
		$cols = array( 'name', 'contact_email', 'contact_phone', 'heads', 'weekly', 'order' );
		$r    = ogc_file_put( (int) $year, 'committees', $out, $cur ? $cur['version'] : 0, $cols );
		if ( ! is_wp_error( $r ) ) {
			return;
		}
	}
}

/** Names in committees.csv (or on a member's row) that the table hasn't got: added to it. */
function ogc_app_reconcile( $year ) {
	if ( ! function_exists( 'ogc_members_committee_list' ) ) {
		return;
	}
	$have = array();
	foreach ( ogc_app_committees( $year ) as $c ) {
		$have[ $c['ckey'] ] = true;
	}
	$f = ogc_file_get( (int) $year, 'committees' );
	// Only once the table has a year's list does the CSV's extra name count (before then, the members'
	// list falls back on the requests' and shifts' names, which are not committees the COA chose).
	if ( ! $have || ! $f ) {
		return;
	}
	foreach ( ogc_members_committee_list( $year ) as $k => $n ) {
		if ( ! isset( $have[ $k ] ) ) {
			ogc_app_committee_add( $year, $n );
		}
	}
}

/* ================================================================== a year, carried forward */

/**
 * Has the year been started (Years › Start, or the seed)? Its years.csv row has its data. A row with
 * only hosts (2028, once its hosts are named) or a past year before the site (2023) isn't started.
 */
if ( ! function_exists( 'ogc_year_started' ) ) {
	function ogc_year_started( $year ) {
		$r = ogc_year_get( (int) $year );
		return $r && isset( $r['data'] ) && '' !== trim( (string) $r['data'] );
	}
}

/**
 * Start a year in the app: its committees and tasks, carried from the year before (names,
 * responsibilities, order, screens handed, the folder link; every task undone; every file), else started
 * from the committees in docs/16 (module-app-seed.php). Only Years › Start (module-coa-pickup.php) and
 * the local seed call it: opening a year never sets it up (docs/27 area-shell 8.3; Oct 14, opening 2023
 * and 2028 by the year menu did). A year that already has committees is only kept (ogc_app_keep_year).
 */
function ogc_app_start_year( $year ) {
	global $wpdb;
	$year = (int) $year;
	if ( ! ogc_valid_year( $year ) || null === ogc_year_get( $year ) || ! ogc_app_tables_ready() ) {
		return;
	}
	$n = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM ' . ogc_table( 'committees' ) . ' WHERE year = %d', $year ) );
	if ( ! $n ) {
		// The year's committees.csv from before the app (the requests' and shifts' names, written as
		// a fallback) gives way to the app's list: only a name someone is on is kept.
		$before = ogc_file_get( $year, 'committees' );
		$prev   = ogc_app_prev_year( $year );
		if ( $prev && (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM ' . ogc_table( 'committees' ) . ' WHERE year = %d AND removed_at IS NULL', $prev ) ) ) {
			ogc_app_carry( $prev, $year );
		} elseif ( function_exists( 'ogc_app_seed_year' ) ) {
			ogc_app_seed_year( $year );
		}
		$used = array();
		foreach ( ogc_members_list( $year ) as $m ) {
			foreach ( ogc_member_committee_keys( $m ) as $k ) {
				$used[ $k ] = true;
			}
		}
		foreach ( $before ? (array) $before['rows'] : array() as $r ) {
			$k = isset( $r['name'] ) ? ogc_committee_key( $r['name'] ) : '';
			if ( '' === $k || ogc_app_committee( $year, $k ) ) {
				continue;
			}
			if ( isset( $used[ $k ] ) ) {
				ogc_app_committee_add( $year, $r['name'] );
			} else {
				// Kept as removed, so committees.csv drops it.
				$wpdb->insert( ogc_table( 'committees' ), array( 'year' => $year, 'ckey' => $k, 'name' => substr( (string) $r['name'], 0, 80 ), 'sort' => 9999, 'created_at' => ogc_now(), 'removed_at' => ogc_now() ) );
			}
		}
		ogc_app_committees( $year, true );
		ogc_app_sync_csv( $year );
	}
	ogc_app_keep_year( $year );
}

/**
 * What opening a year does, every time (boot): only for a year that already has its committees.
 * It reconciles them with committees.csv, keeps the contacts in step with Members, and brings the rest
 * of a partial carry once last year is over. It never creates a year's committees or tasks.
 */
function ogc_app_keep_year( $year ) {
	global $wpdb;
	$year = (int) $year;
	if ( isset( $GLOBALS['ogc_app_ensured'][ $year ] ) || ! ogc_app_tables_ready() ) {
		return;
	}
	if ( ! (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM ' . ogc_table( 'committees' ) . ' WHERE year = %d', $year ) ) ) {
		return;
	}
	$GLOBALS['ogc_app_ensured'][ $year ] = true;
	ogc_app_reconcile( $year );
	// Heads change on Members: the contacts follow (written only when something changed).
	ogc_app_sync_csv( $year );
	// A year started before the last one was over carried only what repeats; the rest comes once it is.
	ogc_app_carry_rest( $year );
}

/** Before Oct 14 the app's boot set a year up (now ogc_app_start_year, from Start only). Kept for any
 * caller outside the plugin: it starts and keeps, as before. */
function ogc_app_ensure_year( $year ) {
	ogc_app_start_year( $year );
}

/** Is a Conference over (by the campus's today)? */
function ogc_app_year_over( $year ) {
	$r = ogc_year_get( (int) $year );
	return $r && ! empty( $r['end'] ) && $r['end'] < ogc_app_today( (int) $year );
}

/**
 * The second half of a carry (Start before the last Conference was over): once it's over, its files
 * (by reference) and the tasks it added that are still undone come to this year. Once.
 */
function ogc_app_carry_rest( $year ) {
	global $wpdb;
	$prev = ogc_app_prev_year( $year );
	if ( ! $prev || ! ogc_app_year_over( $prev ) || ! function_exists( 'ogc_state_get' ) ) {
		return;
	}
	$st = ogc_state_get( (int) $year, 'app-carry' );
	$v  = $st ? (array) $st['value'] : array();
	if ( empty( $v['partial'] ) || ! empty( $v['rest'] ) ) {
		return;
	}
	ogc_app_carry_items( $prev, $year, true );
	$v['rest'] = ogc_now();
	ogc_state_put( (int) $year, 'app-carry', $v, $st['version'] );
}

/** The Conference before this one that has committees (years can skip: 2020–21). */
function ogc_app_prev_year( $year ) {
	global $wpdb;
	return (int) $wpdb->get_var( $wpdb->prepare( 'SELECT MAX(year) FROM ' . ogc_table( 'committees' ) . ' WHERE year < %d AND removed_at IS NULL', $year ) );
}

/**
 * Carry $from's committees, tasks (undone) and files into $to. Started before $from is over (Start
 * 2028 in October 2027's year), only what repeats comes now: the committees, their responsibilities
 * and their seeded or carried tasks; the files and the tasks added during $from follow once it's over
 * (ogc_app_carry_rest).
 */
function ogc_app_carry( $from, $to ) {
	global $wpdb;
	foreach ( ogc_app_committees( $from ) as $c ) {
		$wpdb->insert( ogc_table( 'committees' ), array(
			'year'       => (int) $to,
			'ckey'       => $c['ckey'],
			'name'       => $c['name'],
			'duties'     => $c['duties'],
			'sort'       => $c['sort'],
			// Handing doesn't carry: a new year starts with every screen at the COA, and Who runs what
			// shows last year's choice as a suggestion (area-committees 12.4).
			'screens'    => '',
			'link'       => $c['link'],
			'from_year'  => (int) $from,
			'created_at' => ogc_now(),
			'updated_at' => ogc_now(),
		) );
	}
	ogc_app_committees( $to, true );
	$over = ogc_app_year_over( $from );
	ogc_app_carry_items( $from, $to, false, $over );
	// The tasks that went with a handed screen come back to the COA with it.
	if ( function_exists( 'ogc_app_move_screen_tasks' ) ) {
		foreach ( ogc_app_committees( $from ) as $c ) {
			foreach ( $c['screens'] as $sid ) {
				ogc_app_move_screen_tasks( $to, $sid, '' );
			}
		}
	}
	if ( ! $over && function_exists( 'ogc_state_put' ) ) {
		ogc_state_put( (int) $to, 'app-carry', array( 'partial' => ogc_now(), 'from' => (int) $from ) );
	}
	ogc_app_sync_csv( $to );
	ogc_log( 'app_carry', $to, 'year:' . (int) $to, array( 'from' => (int) $from, 'partial' => $over ? 0 : 1 ) );
}

/** The tasks and files of a carry. $rest: only what a partial carry left (added tasks, files). */
function ogc_app_carry_items( $from, $to, $rest, $over = true ) {
	global $wpdb;
	$shift = function ( $d ) use ( $from, $to ) {
		if ( ! preg_match( '/^(\d{4})-(\d{2})-(\d{2})$/', (string) $d, $x ) ) {
			return '';
		}
		$y = (int) $x[1] + ( (int) $to - (int) $from );
		return sprintf( '%04d-%s-%s', $y, $x[2], '02' === $x[2] && '29' === $x[3] ? '28' : $x[3] );
	};
	$tasks = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . ogc_table( 'tasks' ) . ' WHERE year = %d AND removed_at IS NULL ORDER BY id', $from ), ARRAY_A );
	foreach ( (array) $tasks as $t ) {
		$added = 'added' === (string) $t['source'];
		// Now: what repeats. Later (or a year already over): what was added, still undone.
		if ( $rest ? ( ! $added || ! empty( $t['done_at'] ) ) : ( $added && ! $over ) ) {
			continue;
		}
		$wpdb->insert( ogc_table( 'tasks' ), array(
			'year'         => (int) $to,
			'ckey'         => $t['ckey'],
			'title'        => $t['title'],
			'note'         => $t['note'],
			'due_offset'   => null === $t['due_offset'] ? null : (int) $t['due_offset'],
			'due_date'     => $shift( $t['due_date'] ),
			'sort'         => (int) $t['sort'],
			'source'       => 'carried',
			'kind'         => isset( $t['kind'] ) ? (string) $t['kind'] : '',
			'carried_from' => (int) $t['id'],
			'created_at'   => ogc_now(),
		) );
	}
	if ( ! $rest && ! $over ) {
		return;
	}
	$files = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . ogc_table( 'cfiles' ) . ' WHERE year = %d AND removed_at IS NULL ORDER BY id', $from ), ARRAY_A );
	foreach ( (array) $files as $f ) {
		// A file its committee switched off for next year stays behind (module-handdown.php).
		if ( ! apply_filters( 'ogc_app_carry_file', true, $f, (int) $from, (int) $to ) ) {
			continue;
		}
		$wpdb->insert( ogc_table( 'cfiles' ), array(
			'year'         => (int) $to,
			'ckey'         => $f['ckey'],
			'name'         => $f['name'],
			'fkey'         => $f['fkey'],
			'mime'         => $f['mime'],
			'size'         => (int) $f['size'],
			'uploaded_by'  => (int) $f['uploaded_by'],
			'carried_from' => (int) $f['id'],
			'created_at'   => $f['created_at'],
		) );
	}
}

/* ================================================================== dates */

/** The Conference's first day (its Friday) as a timestamp at noon UTC, or 0 while it has no dates. */
function ogc_app_friday( $year ) {
	$y = ogc_year_get( (int) $year );
	return $y && ! empty( $y['start'] ) && preg_match( '/^\d{4}-\d{2}-\d{2}$/', $y['start'] ) ? strtotime( $y['start'] . ' 12:00:00 UTC' ) : 0;
}

/** A task's due date ('Y-m-d'), or '' when it counts from a Friday the year doesn't have yet. */
function ogc_app_task_due( $t, $friday ) {
	if ( '' !== (string) $t['due_date'] ) {
		return (string) $t['due_date'];
	}
	if ( null === $t['due_offset'] || '' === $t['due_offset'] || ! $friday ) {
		return '';
	}
	return gmdate( 'Y-m-d', $friday + (int) $t['due_offset'] * DAY_IN_SECONDS );
}

/** "6 weeks before", "3 days after", "On the Friday": an offset in words. */
function ogc_app_offset_words( $off ) {
	$off = (int) $off;
	if ( 0 === $off ) {
		return 'First day';
	}
	$a = abs( $off );
	$w = 0 === $a % 7 ? ( $a / 7 ) . ' week' . ( 7 === $a ? '' : 's' ) : ( $a >= 60 ? round( $a / 30 ) . ' months' : $a . ' day' . ( 1 === $a ? '' : 's' ) );
	return $w . ( $off < 0 ? ' before' : ' after' );
}

/** "Mar 1"; "Mar 1, 2025" only for a date outside the Conference's year and the one before. */
function ogc_app_date_words( $d, $year = 0 ) {
	return ogc_app_md( $d, $year );
}

/* ================================================================== tasks */

function ogc_app_task_row( $t, $friday, $year ) {
	$today = ogc_app_today( $year );
	$kind  = isset( $t['kind'] ) ? (string) $t['kind'] : '';
	$kinds = ogc_app_task_kinds();
	$k     = $kind && isset( $kinds[ $kind ] ) ? $kinds[ $kind ] : null;
	// A task tied to a setting takes its date (Registration opens = the day it opens).
	$own   = $k ? ogc_app_task_kind_due( $kind, $year ) : '';
	$due   = '' !== $own ? $own : ogc_app_task_due( $t, $friday );
	// A year without dates yet: a carried calendar date is only a guess (last year's, a year on), so
	// it's said as "Dates to come" rather than shown as if it were set.
	$guess = ! $friday && '' === $own && 'carried' === (string) $t['source'] && '' !== (string) $t['due_date'];
	if ( $guess ) {
		$due = '';
	}
	// A task tied to its screen ticks itself from the data ("Done · from Meal counts · May 12").
	$auto  = $k && empty( $t['done_at'] ) ? ogc_app_task_auto( $kind, $year, (string) $t['ckey'], $today ) : '';
	$done  = ! empty( $t['done_at'] ) || '' !== $auto;
	return array(
		'id'         => (int) $t['id'],
		'committee'  => (string) $t['ckey'],
		'title'      => (string) $t['title'],
		'note'       => (string) $t['note'],
		'due'        => $due,
		'due_words'  => $due ? ogc_app_date_words( $due, $year ) : ( $guess ? 'Dates to come' : ( null !== $t['due_offset'] && '' !== $t['due_offset'] ? ogc_app_offset_words( (int) $t['due_offset'] ) : '' ) ),
		'offset'     => null === $t['due_offset'] || '' === $t['due_offset'] ? null : (int) $t['due_offset'],
		'date'       => (string) $t['due_date'],
		// A date a setting decides (Answer requests: the round's due date) is the one shown everywhere,
		// the panel included, said as such ("Set on Intake"); the stored date is only a fallback.
		'due_from'   => '' !== $own ? ogc_app_task_due_from( $kind ) : '',
		'owner'      => (int) $t['owner'],
		'done'       => $done,
		'done_on'    => ! empty( $t['done_at'] ) ? ogc_app_date_words( wp_date( 'Y-m-d', strtotime( $t['done_at'] . ' UTC' ) ), $year ) : ( $auto ? ogc_app_date_words( $auto, $year ) : '' ),
		'done_by_id' => (int) $t['done_by'],
		'auto'       => $auto ? ( $k['from'] ? $k['from'] : 'the site' ) : '',
		'late'       => ! $done && $due && $due < $today,
		'source'     => (string) $t['source'],
		'kind'       => $kind,
		'screen'     => $k ? (string) $k['screen'] : '',
	);
}

/** A year's tasks (removed left out), each as ogc_app_task_row, sorted by when they're due. $ckeys
 * limits to those committees (null: all). */
function ogc_app_tasks( $year, $ckeys = null ) {
	global $wpdb;
	$rows   = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . ogc_table( 'tasks' ) . ' WHERE year = %d AND removed_at IS NULL ORDER BY sort, id', $year ), ARRAY_A );
	$friday = ogc_app_friday( $year );
	$out    = array();
	foreach ( (array) $rows as $t ) {
		if ( null !== $ckeys && ! in_array( $t['ckey'], (array) $ckeys, true ) ) {
			continue;
		}
		$out[] = ogc_app_task_row( $t, $friday, $year );
	}
	usort( $out, function ( $a, $b ) {
		// Dated first, by date; then by offset; undated last.
		$ka = $a['due'] ? '0' . $a['due'] : ( null !== $a['offset'] ? '1' . sprintf( '%06d', $a['offset'] + 100000 ) : '2' );
		$kb = $b['due'] ? '0' . $b['due'] : ( null !== $b['offset'] ? '1' . sprintf( '%06d', $b['offset'] + 100000 ) : '2' );
		return strcmp( $ka, $kb ) ?: $a['id'] - $b['id'];
	} );
	return $out;
}

/* ================================================================== status */

/**
 * Where a committee stands, in a few words, written from its data. The default is from its tasks
 * ("2 of 6 · Next: First meal count, Mar 1"); a committee's module writes its own from its work with
 * the filter: add_filter( 'ogc_committee_status', fn( $line, $year, $ckey, $ctx ) … ), $ctx holding
 * tasks, done, total, next (a task row or null), late (count), people (count), head (bool), after
 * (the Conference is over).
 */
function ogc_app_committee_status( $year, $c, $tasks = null, $people = null ) {
	$tasks  = null === $tasks ? ogc_app_tasks( $year, array( $c['ckey'] ) ) : $tasks;
	$people = null === $people ? ogc_app_people( $year, $c['ckey'] ) : $people;
	$done   = count( array_filter( $tasks, function ( $t ) {
		return $t['done'];
	} ) );
	$next   = null;
	$late   = 0;
	foreach ( $tasks as $t ) {
		if ( $t['done'] ) {
			continue;
		}
		if ( $t['late'] ) {
			$late++;
		}
		if ( ! $next ) {
			$next = $t;
		}
	}
	$y     = ogc_year_get( $year );
	$after = $y && ! empty( $y['end'] ) && $y['end'] < ogc_app_today( $year );
	$head  = (bool) array_filter( $people, function ( $m ) {
		return ! empty( $m['head'] );
	} );
	$total = count( $tasks );
	// The committee's one most pressing true thing: its work's own line when in season (the filter),
	// else what's next. Never "0 of 6".
	if ( ! $total ) {
		$line = '';
	} elseif ( ! ogc_app_friday( $year ) ) {
		// A year with no dates: every task counts from a day not chosen yet.
		$line = 'Dates to come';
	} elseif ( $done === $total ) {
		$line = 'All ' . $total . ' tasks done';
	} else {
		$line = $next ? 'Next: ' . $next['title'] . ( $next['due_words'] ? ' · ' . $next['due_words'] : '' ) : '';
	}
	$ctx  = compact( 'tasks', 'done', 'total', 'next', 'late', 'head', 'after' );
	$ctx['people'] = count( $people );
	$line = (string) apply_filters( 'ogc_committee_status', $line, (int) $year, $c['ckey'], $ctx );
	// Why it needs a look (the board's mark), most pressing first. Filter: ogc_committee_look.
	$look = array();
	if ( ! $people ) {
		$look[] = 'No one on it';
	} elseif ( ! $head && 'coa' !== $c['ckey'] ) {
		$look[] = 'No head';
	}
	if ( $late ) {
		$look[] = $late . ' late';
	}
	if ( $after && 'coa' !== $c['ckey'] && ! ogc_app_report_sent( $year, $c['ckey'] ) ) {
		$look[] = 'Report not in';
	}
	$look = array_values( (array) apply_filters( 'ogc_committee_look', $look, (int) $year, $c['ckey'], $ctx ) );
	return array( 'line' => $line, 'look' => $look, 'done' => $done, 'total' => $total, 'late' => $late, 'next' => $next );
}

/* ================================================================== reports */

/**
 * The COA's questions for a committee's report. Placeholders until the COA's own five are in hand
 * (docs/16 names them but no copy has been found): the COA may set its own wording in settings
 * (report_q1 … report_q5), and a site with the real ones uses the filter.
 */
function ogc_app_report_questions( $year ) {
	$q = array(
		'What went well?',
		'What went wrong, or took too long?',
		'What should next year’s committee change?',
		// "What we used" (docs/14 idea 7's one report form): supplies, borrowed equipment, and the cost.
		'What did you use, and what did it cost?',
		'What should next year’s committee know first?',
	);
	$s = function_exists( 'ogc_mail_settings' ) ? ogc_mail_settings( $year ) : array();
	foreach ( $q as $i => $text ) {
		$k = 'report_q' . ( $i + 1 );
		if ( ! empty( $s[ $k ] ) ) {
			$q[ $i ] = sanitize_text_field( $s[ $k ] );
		}
	}
	return array_values( (array) apply_filters( 'ogc_report_questions', $q, (int) $year ) );
}

function ogc_app_report( $year, $ckey ) {
	global $wpdb;
	$r = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . ogc_table( 'creports' ) . ' WHERE year = %d AND ckey = %s', $year, $ckey ), ARRAY_A );
	if ( ! $r ) {
		return null;
	}
	return array(
		'answers'    => array_values( array_map( 'strval', (array) ogc_unjson( $r['answers'], array() ) ) ),
		'updated'    => $r['updated_at'] ? ogc_app_date_words( wp_date( 'Y-m-d', strtotime( $r['updated_at'] . ' UTC' ) ) ) : '',
		'updated_by' => (int) $r['updated_by'],
		'sent'       => $r['sent_at'] ? ogc_app_date_words( wp_date( 'Y-m-d', strtotime( $r['sent_at'] . ' UTC' ) ) ) : '',
	);
}

function ogc_app_report_sent( $year, $ckey ) {
	$r = ogc_app_report( $year, $ckey );
	return $r && '' !== $r['sent'];
}

/* ================================================================== notes for next year */

/** Notes written in $year by a committee, oldest first. */
function ogc_app_notes( $year, $ckey ) {
	global $wpdb;
	$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . ogc_table( 'cnotes' ) . ' WHERE year = %d AND ckey = %s AND removed_at IS NULL ORDER BY id', $year, $ckey ), ARRAY_A );
	$out  = array();
	foreach ( (array) $rows as $n ) {
		$out[] = array(
			'id'      => (int) $n['id'],
			'year'    => (int) $n['year'],
			'body'    => (string) $n['body'],
			'author'  => (int) $n['author'],
			// A note is read a year later: its date says the year ("Jul 1, 2026").
			'on'      => $n['created_at'] ? wp_date( 'M j, Y', strtotime( $n['created_at'] . ' UTC' ) ) : '',
			'done'    => ! empty( $n['done_at'] ),
			'done_by' => (int) $n['done_by'],
		);
	}
	return $out;
}

// v3's notes for next year were kept by part (notes.csv: part,text). Once per site: each is moved to the
// committee that owns its part that year (settings owner_<part>, when it names a committee), else the
// COA's notes. notes.csv itself is left as it is.
add_action( 'init', function () {
	global $wpdb;
	if ( get_option( 'ogc_app_notes_moved' ) || ! function_exists( 'ogc_file_get' ) || ! ogc_app_tables_ready() ) {
		return;
	}
	foreach ( ogc_years_list() as $y ) {
		$f = ogc_file_get( $y, 'notes' );
		if ( ! $f ) {
			continue;
		}
		$s = ogc_mail_settings( $y );
		foreach ( (array) $f['rows'] as $r ) {
			$text = isset( $r['text'] ) ? trim( (string) $r['text'] ) : '';
			if ( '' === $text ) {
				continue;
			}
			$part = isset( $r['part'] ) ? sanitize_key( $r['part'] ) : '';
			$own  = $part && ! empty( $s[ 'owner_' . $part ] ) ? ogc_committee_key( $s[ 'owner_' . $part ] ) : '';
			$ckey = $own && 'committee of arrangements' !== $own ? $own : 'coa';
			$wpdb->insert( ogc_table( 'cnotes' ), array( 'year' => $y, 'ckey' => $ckey, 'body' => ogc_app_clean_text( $text, 2000 ), 'source' => 'notes.csv', 'created_at' => ogc_now() ) );
		}
	}
	update_option( 'ogc_app_notes_moved', 1, false );
}, 40 );

/** Have the app's tables been made (the schema runs on the first request after an update)? */
function ogc_app_tables_ready() {
	global $wpdb;
	if ( isset( $GLOBALS['ogc_app_ready'] ) ) {
		return $GLOBALS['ogc_app_ready'];
	}
	$wpdb->suppress_errors( true );
	$wpdb->get_var( 'SELECT id FROM ' . ogc_table( 'committees' ) . ' LIMIT 1' ); // phpcs:ignore -- no input.
	$wpdb->suppress_errors( false );
	$GLOBALS['ogc_app_ready'] = '' === $wpdb->last_error;
	return $GLOBALS['ogc_app_ready'];
}

/* ================================================================== private files */

/** Where committees' files are kept: outside the web root when the site says so (filter), else a folder
 * in uploads that refuses every request (deny rules for Apache and IIS; on nginx, Corey adds a
 * location rule, DEV.md). Files are stored under random names with no extension either way. */
/** May committees' files be kept here? On a local dev site, always. Elsewhere only in a folder set in
 * wp-config.php (OGC_PRIVATE_DIR): a local path, outside the web root. The uploads folder may be a
 * bucket (ogbbc.org's media is on DigitalOcean Spaces) and nginx ignores .htaccess (review, Oct 11). */
function ogc_app_private_ok() {
	if ( function_exists( 'ogc_is_local_host' ) && OGC_DEV && ogc_is_local_host() ) {
		return true;
	}
	if ( ! defined( 'OGC_PRIVATE_DIR' ) || ! OGC_PRIVATE_DIR ) {
		return false;
	}
	$d = wp_normalize_path( (string) OGC_PRIVATE_DIR );
	return false === strpos( $d, '://' ) && 0 !== strpos( trailingslashit( $d ), trailingslashit( wp_normalize_path( ABSPATH ) ) );
}

// Site Health says whether committees' files have a safe place.
add_filter( 'site_status_tests', function ( $t ) {
	$t['direct']['ogc_private_dir'] = array(
		'label' => 'Conference committees’ files',
		'test'  => function () {
			$ok = ogc_app_private_ok();
			return array(
				'label'       => $ok ? 'Committees’ files have a private folder' : 'Committees’ files are off',
				'status'      => $ok ? 'good' : 'recommended',
				'badge'       => array( 'label' => 'Conference', 'color' => 'blue' ),
				'description' => '<p>' . esc_html( $ok ? 'OGC_PRIVATE_DIR is a folder outside the web root.' : 'Define OGC_PRIVATE_DIR in wp-config.php as a folder outside the web root (not the uploads folder) to let committees keep files.' ) . '</p>',
				'test'        => 'ogc_private_dir',
			);
		},
	);
	return $t;
} );

function ogc_app_private_dir() {
	$up  = wp_upload_dir( null, false );
	// Best outside the web root: define( 'OGC_PRIVATE_DIR', '/home/…/ogc-private' ) in wp-config.php.
	$def = defined( 'OGC_PRIVATE_DIR' ) && OGC_PRIVATE_DIR ? (string) OGC_PRIVATE_DIR : trailingslashit( $up['basedir'] ) . 'ogc-private';
	$dir = (string) apply_filters( 'ogc_private_dir', $def );
	$dir = untrailingslashit( $dir );
	if ( ! is_dir( $dir ) ) {
		wp_mkdir_p( $dir );
	}
	if ( is_dir( $dir ) && ! file_exists( $dir . '/.htaccess' ) ) {
		// phpcs:disable WordPress.WP.AlternativeFunctions -- small fixed files.
		file_put_contents( $dir . '/.htaccess', "Require all denied\n<IfModule !mod_authz_core.c>\nDeny from all\n</IfModule>\n" );
		file_put_contents( $dir . '/index.php', "<?php\n// Silence is golden.\n" );
		file_put_contents( $dir . '/web.config', "<?xml version=\"1.0\"?>\n<configuration><system.webServer><authorization><deny users=\"*\" /></authorization></system.webServer></configuration>\n" );
		// phpcs:enable
	}
	return $dir;
}

/** The kinds of file a committee may keep (documents, spreadsheets, pictures), by extension. */
function ogc_app_file_types() {
	return (array) apply_filters( 'ogc_app_file_types', array(
		'pdf'  => 'application/pdf',
		'doc'  => 'application/msword',
		'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
		'xls'  => 'application/vnd.ms-excel',
		'xlsx' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
		'ppt'  => 'application/vnd.ms-powerpoint',
		'pptx' => 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
		'odt'  => 'application/vnd.oasis.opendocument.text',
		'ods'  => 'application/vnd.oasis.opendocument.spreadsheet',
		'rtf'  => 'application/rtf',
		'csv'  => 'text/csv',
		'txt'  => 'text/plain',
		'jpg'  => 'image/jpeg',
		'jpeg' => 'image/jpeg',
		'png'  => 'image/png',
		'heic' => 'image/heic',
	) );
}

/** A committee's files in a year. */
function ogc_app_files( $year, $ckey ) {
	global $wpdb;
	$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . ogc_table( 'cfiles' ) . ' WHERE year = %d AND ckey = %s AND removed_at IS NULL ORDER BY id DESC', $year, $ckey ), ARRAY_A );
	$out  = array();
	foreach ( (array) $rows as $f ) {
		$out[] = array(
			'id'      => (int) $f['id'],
			'name'    => (string) $f['name'],
			'size'    => (int) $f['size'],
			'type'    => strtoupper( (string) pathinfo( $f['name'], PATHINFO_EXTENSION ) ),
			'on'      => $f['created_at'] ? ogc_app_date_words( wp_date( 'Y-m-d', strtotime( $f['created_at'] . ' UTC' ) ) ) : '',
			'by_id'   => (int) $f['uploaded_by'],
			'carried' => (int) $f['carried_from'] > 0,
		);
	}
	return $out;
}

/* ================================================================== the log, in words */

/** One line of the change log in words, or '' when it isn't one the app shows. $v limits which a
 * committee sees: only its own committee's lines. */
function ogc_app_log_words( $r, $v ) {
	$d    = (array) ogc_unjson( $r['detail'], array() );
	$y    = (int) $r['year'];
	$who  = ogc_app_user_name( (int) $r['user'], $y );
	$who  = '' === $who ? 'Someone' : $who;
	$ckey = isset( $d['ckey'] ) ? (string) $d['ckey'] : ( preg_match( '/^committee:(.+)$/', $r['target'], $x ) ? $x[1] : '' );
	$mem  = preg_match( '/^member:(\d+)$/', $r['target'], $x ) ? ogc_member_get( (int) $x[1] ) : null;
	if ( $mem && '' === $ckey ) {
		$keys = ogc_member_committee_keys( $mem );
		$ckey = 'coa' === $mem['role'] ? 'coa' : ( $keys ? $keys[0] : '' );
	}
	if ( ! $v['coa'] && ! $v['webmaster'] && ! in_array( $ckey, (array) $v['committees'], true ) ) {
		return '';
	}
	$c    = $ckey ? ogc_app_committee( $y, $ckey ) : null;
	$cn   = $c ? $c['name'] : '';
	// Webmasters see the structure: someone on a committee is "A Food member" (their own committee,
	// not the one the line is about: "A Lodging member messaged Food").
	if ( $v['webmaster'] && ! $v['coa'] && (int) $r['user'] && ! ogc_is_webmaster( (int) $r['user'] ) ) {
		$am  = ogc_member_find( $y, ogc_user_email( (int) $r['user'] ), true );
		$ak  = $am ? ogc_member_committee_keys( $am ) : array();
		$ac  = $ak ? ogc_app_committee( $y, $ak[0] ) : null;
		$who = $am && 'coa' === $am['role'] ? $who : ( $ac ? 'A ' . $ac['name'] . ' member' : 'Someone' );
	}
	$t    = isset( $d['title'] ) ? (string) $d['title'] : '';
	// Webmasters see the structure: what a committee did, not its files' names.
	if ( $v['webmaster'] && ! $v['coa'] && 'app_file_add' === $r['action'] ) {
		$t = 'a file';
	}
	$name = $mem ? ogc_app_person_name( $mem ) : 'someone';
	// Webmasters see the structure, not names (except the COA's, whom they manage).
	if ( $v['webmaster'] && ! $v['coa'] && $mem && 'coa' !== $mem['role'] ) {
		$name = 'someone';
	}
	$w = array(
		'app_task_done'     => $who . ' marked ' . ( $t ? '“' . $t . '”' : 'a task' ) . ' done',
		'app_task_undone'   => $who . ' reopened ' . ( $t ? '“' . $t . '”' : 'a task' ),
		'app_task_add'      => $who . ' added the task ' . ( $t ? '“' . $t . '”' : '' ),
		'app_task_remove'   => $who . ' removed the task ' . ( $t ? '“' . $t . '”' : '' ),
		'app_note_add'      => $who . ' added a note for next year' . ( $cn ? ' · ' . $cn : '' ),
		'app_report_sent'   => $who . ' sent ' . ( $cn ? $cn . '’s' : 'the' ) . ' report',
		'app_file_add'      => $who . ' added ' . ( $t ? $t : 'a file' ) . ( $cn ? ' · ' . $cn : '' ),
		'app_committee_add' => $who . ' added the committee ' . $cn,
		'app_committee_edit' => $who . ' changed ' . $cn,
		'app_hand'          => $who . ' handed ' . ( $t ? $t : 'a screen' ) . ' to ' . $cn,
		'app_message'       => $who . ' messaged ' . ( $cn ? $cn : 'a member' ),
		// The system's own lines (the year carried forward) aren't anyone's activity.
		'app_carry'         => '',
		'member_invite'     => $who . ' added ' . $name . ( $cn ? ' to ' . $cn : '' ),
		'member_remove'     => $who . ' removed ' . $name . ( $cn ? ' from ' . $cn : '' ),
		'member_label'      => $who . ' changed ' . $name . '’s committee',
		'member_signin'     => ucfirst( $name ) . ' signed in for the first time',
	);
	// An area's own acts in words (the hand-down: module-handdown.php).
	$w = (array) apply_filters( 'ogc_app_log_words', $w, $who, $cn, $d, $r );
	if ( 'app_see_as' === $r['action'] ) {
		// Kept in the change log (the audit), not on Home.
		return '';
	}
	$out = isset( $w[ $r['action'] ] ) ? $w[ $r['action'] ] : '';
	// Named by the committee already ("A Lodging member added a file"): no " · Lodging" after it.
	if ( '' !== $cn && false !== strpos( $who, $cn ) && substr( $out, -strlen( ' · ' . $cn ) ) === ' · ' . $cn ) {
		$out = substr( $out, 0, -strlen( ' · ' . $cn ) );
	}
	return $out;
}

/** The year's latest lines in words for this viewer. */
function ogc_app_activity( $v, $limit = 12 ) {
	global $wpdb;
	$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . ogc_table( 'log' ) . " WHERE year = %d AND ( action LIKE 'app\\_%%' OR action IN ('member_invite','member_remove','member_label','member_signin') ) ORDER BY id DESC LIMIT 300", $v['year'] ), ARRAY_A );
	$out   = array();
	$at    = array();
	$today = wp_date( 'Y-m-d' );
	$yday  = wp_date( 'Y-m-d', time() - DAY_IN_SECONDS );
	$uid   = get_current_user_id();
	$me    = function_exists( 'ogc_member_me' ) ? ogc_member_me( (int) $v['year'] ) : null;
	foreach ( (array) $rows as $r ) {
		// What others did: your own changes (and your own first sign-in) aren't news to you.
		if ( (int) $r['user'] === $uid || ( $me && 'member:' . (int) $me['id'] === (string) $r['target'] && 'member_signin' === $r['action'] ) ) {
			continue;
		}
		$w = ogc_app_log_words( $r, $v );
		if ( '' === $w ) {
			continue;
		}
		$t   = strtotime( $r['at'] . ' UTC' );
		$day = wp_date( 'Y-m-d', $t );
		// The same line on the same day is one line ("· 2 times"), wherever it falls.
		$k = $day . '|' . $w;
		if ( isset( $at[ $k ] ) ) {
			$out[ $at[ $k ] ]['n']++;
			continue;
		}
		if ( count( $out ) >= $limit ) {
			continue;
		}
		$at[ $k ] = count( $out );
		$out[]    = array(
			'words' => $w,
			// Grouped by day on Home: "Today", "Yesterday", "Oct 9" (with its year when it isn't this one).
			'day'   => $day === $today ? 'Today' : ( $day === $yday ? 'Yesterday' : wp_date( 'D, M j', $t ) . ( wp_date( 'Y', $t ) !== wp_date( 'Y' ) ? wp_date( ', Y', $t ) : '' ) ),
			'at'    => wp_date( 'g:i A', $t ),
			'n'     => 1,
		);
	}
	return $out;
}
