<?php
/**
 * The COA's screens in the app (docs/23; DEV.md › App): Dates and place, Campus, Schedule, Requests,
 * Registration, Money, Packet, Help and notices, and the webmasters' Years. The drawing is
 * assets/app/screens/coa-*.js; this file holds the rules and the server's half:
 *
 *   - the screens (filter ogc_app_screens) and the page's scripts;
 *   - /year/… and /admin/… (the old year page and editors) land on the matching screen;
 *   - who may change what: a member who isn't on the COA changes a COA file, or acts on the COA's
 *     routes, only through a screen the COA handed to their committee (ogc_app_can_see);
 *   - the published copy: once the schedule or the packet is public, edits wait for Publish
 *     ("3 not live · Publish"), and visitors read the copy last published;
 *   - Money's totals (names and amounts stay with the treasurer, the lists area's payments);
 *   - what's public now, worked out by the same rules that decide it (never by the page's own idea).
 */

defined( 'ABSPATH' ) || exit;

/* ================================================================== the screens */

/** The COA's screens, in the order the year happens. */
function ogc_coa_app_screens() {
	return array(
		'dates'        => array( 'title' => 'Dates and place', 'who' => array( 'coa' ), 'handable' => false ),
		'campus'       => array( 'title' => 'Campus', 'who' => array( 'coa' ) ),
		'schedule'     => array( 'title' => 'Schedule', 'who' => array( 'coa' ) ),
		// Every committee answers its own requests; the COA sees them all.
		'requests'     => array( 'title' => 'Requests', 'who' => array( 'coa', 'committee' ), 'handable' => false ),
		'registration' => array( 'title' => 'Registration', 'who' => array( 'coa' ) ),
		'money'        => array( 'title' => 'Money', 'who' => array( 'coa' ) ),
		'packet'       => array( 'title' => 'Packet', 'who' => array( 'coa' ) ),
		'help'         => array( 'title' => 'Help and notices', 'who' => array( 'coa' ) ),
	);
}

add_filter( 'ogc_app_screens', function ( $s, $year ) {
	// Members (and Years) after the work, so the COA's section reads in the order the year happens.
	$tail = array();
	foreach ( array( 'members', 'years' ) as $k ) {
		if ( isset( $s[ $k ] ) ) {
			$tail[ $k ] = $s[ $k ];
			unset( $s[ $k ] );
		}
	}
	foreach ( ogc_coa_app_screens() as $id => $d ) {
		$s[ $id ] = array_merge( array( 'section' => 'own', 'handable' => true ), $d );
	}
	return array_merge( $s, $tail );
}, 20, 2 );

// The page's scripts: the shared helpers the screens use (dates, reading a typed line, saving row by
// row, files in and out), then the screens. Each script once, whatever order other areas add theirs.
add_filter( 'ogc_pages', function ( $p ) {
	if ( empty( $p['app'] ) ) {
		return $p;
	}
	$mine = array(
		'shared/ogc-core.js', 'year/year-xlsx.js',
		'admin/admin-read.js', 'admin/admin-rows.js', 'admin/admin-files.js',
		'app/screens/coa-kit.js', 'app/screens/coa-dates.js', 'app/screens/coa-campus.js', 'app/screens/coa-schedule.js',
		'app/screens/coa-requests.js', 'app/screens/coa-registration.js', 'app/screens/coa-money.js',
		'app/screens/coa-packet.js', 'app/screens/coa-help.js', 'app/screens/coa-years.js',
	);
	$p['app']['scripts'] = array_merge( (array) $p['app']['scripts'], $mine );
	$p['app']['styles']  = array_merge( (array) $p['app']['styles'], array( 'app/screens/coa.css' ) );
	return $p;
}, 20 );
add_filter( 'ogc_pages', function ( $p ) {
	if ( ! empty( $p['app'] ) ) {
		// ogc-core.js sets window.OGC whole: it must come before anything that adds to it, and only once.
		$s = array_values( array_unique( (array) $p['app']['scripts'] ) );
		$i = array_search( 'shared/ogc-core.js', $s, true );
		if ( false !== $i ) {
			array_splice( $s, $i, 1 );
			$at = array_search( 'app/app.js', $s, true );
			array_splice( $s, false === $at ? 0 : $at + 1, 0, array( 'shared/ogc-core.js' ) );
		}
		$p['app']['scripts'] = $s;
		$p['app']['styles']  = array_values( array_unique( (array) $p['app']['styles'] ) );
	}
	return $p;
}, 999 );

// The app loads nobody's records (counts come with GET coa/{y}; Money's names stay with the lists
// area's payments route, for the treasurer only).
add_filter( 'ogc_client_config', function ( $cfg, $key ) {
	if ( 'app' !== $key ) {
		return $cfg;
	}
	$cfg['recordKinds'] = array();
	$cfg['recordYears'] = 1;
	$cfg['coa']         = array(
		'data'   => trailingslashit( ogc_data_base() ),
		'public' => wp_make_link_relative( ogc_url( '' ) ),
	);
	return $cfg;
}, 30, 2 );

/* ================================================================== the old addresses */

/** Where an old year-page or editor address lands in the app. */
function ogc_coa_app_landing( $page, $q ) {
	$to = array();
	if ( 'year' === $page ) {
		$part = isset( $q['part'] ) ? (string) $q['part'] : '';
		$map  = array( 'conference' => 'dates', 'schedule' => 'schedule', 'requests' => 'requests', 'registration' => 'registration', 'packet' => 'packet' );
		$to['s'] = isset( $map[ $part ] ) ? $map[ $part ] : 'home';
		if ( 'conference' === $part && isset( $q['tool'] ) && 'pins' === $q['tool'] ) {
			$to = array( 's' => 'campus', 'v' => 'pins' );
		}
		if ( 'requests' === $part && ! empty( $q['open'] ) ) {
			$to['c'] = ogc_committee_key( (string) $q['open'] );
		}
	} elseif ( 'admin' === $page ) {
		$edit = isset( $q['edit'] ) ? (string) $q['edit'] : '';
		list( $k, $arg ) = array_pad( explode( ':', $edit, 2 ), 2, '' );
		$map = array(
			'schedule' => array( 's' => 'schedule' ), 'details' => array( 's' => 'dates' ), 'callin' => array( 's' => 'callin' ),
			'registration' => array( 's' => 'registration' ), 'packet' => array( 's' => 'packet' ), 'menus' => array( 's' => 'packet', 'v' => 'menus' ),
			'help' => array( 's' => 'help' ), 'notices' => array( 's' => 'help', 'v' => 'notices' ), 'numbers' => array( 's' => 'help', 'v' => 'numbers' ),
			'places' => array( 's' => 'campus' ), 'rooms' => array( 's' => 'campus', 'v' => 'halls' ), 'halls' => array( 's' => 'campus', 'v' => 'halls' ),
			'nearby' => array( 's' => 'campus', 'v' => 'nearby' ),
		);
		// The shift and tournament editors aren't in the app yet: they still open (integration, Oct 11),
		// from Helpers' and Teams' More menus.
		if ( in_array( $k, array( 'shifts', 'tournaments' ), true ) ) {
			return '';
		}
		if ( isset( $map[ $k ] ) ) {
			$to = $map[ $k ];
			if ( 'schedule' === $k && '' !== $arg ) {
				$to['v'] = strtolower( substr( sanitize_text_field( $arg ), 0, 12 ) );
			}
		} elseif ( isset( $q['role'] ) && 'web' === $q['role'] ) {
			$to = array( 's' => 'years' );
		} else {
			$to = array( 's' => 'home' );
		}
	}
	$y = isset( $q['year'] ) && ogc_valid_year( $q['year'] ) ? (int) $q['year'] : 0;
	$args = array_filter( array_merge( $y ? array( 'year' => $y ) : array(), $to ), 'strlen' );
	return add_query_arg( array_map( 'rawurlencode', $args ), ogc_url( 'app' ) );
}

add_action( 'ogc_before_page', function ( $page ) {
	if ( ! in_array( $page, array( 'year', 'admin' ), true ) ) {
		return;
	}
	// phpcs:ignore WordPress.Security.NonceVerification -- only where to go.
	$q = array_map( function ( $v ) {
		return is_string( $v ) ? sanitize_text_field( wp_unslash( $v ) ) : '';
	}, (array) $_GET );
	$to = ogc_coa_app_landing( $page, $q );
	if ( '' === $to ) {
		return;
	}
	// Signed out: to sign-in first, coming back to the app (one door, as every members' page).
	if ( ! is_user_logged_in() ) {
		$to = add_query_arg( 'return', rawurlencode( wp_make_link_relative( $to ) ), ogc_url( 'signin' ) );
	}
	wp_safe_redirect( $to, 302 );
	exit;
} );

/* ================================================================== who may change what */

/** The screen a year's file belongs to (its changes need that screen). Files not listed are other
 * areas' (shifts, tournaments, committees, attachments) and keep their own rules. */
function ogc_coa_app_file_screen( $name ) {
	$m = array(
		'schedule' => 'schedule', 'changes' => 'schedule',
		'guide' => 'packet', 'menus' => 'packet',
		'help' => 'help', 'notices' => 'help', 'contacts' => 'help',
		'places' => 'campus', 'rooms' => 'campus', 'nearby' => 'campus', 'plans' => 'campus', 'campus' => 'campus',
		'needs' => 'requests', 'registration' => 'registration',
	);
	return isset( $m[ $name ] ) ? $m[ $name ] : '';
}

/**
 * The screen that holds a part of the year: its steps, notes, owner and due date ('' = the COA itself).
 * Requests is every committee's screen, for its own rows only; the part itself (the round) is the
 * Intake holder's: the COA, or the committee the COA handed Intake to (security pass, M6).
 */
function ogc_coa_app_part_screen( $part ) {
	$parts = array( 'conference' => 'dates', 'schedule' => 'schedule', 'requests' => 'intake', 'registration' => 'registration', 'packet' => 'packet' );
	return isset( $parts[ $part ] ) ? $parts[ $part ] : '';
}

/** The screen a "Looks right" check belongs to, by its id's prefix ('' = the COA itself). */
function ogc_coa_app_check_screen( $id ) {
	$pre = strtok( is_scalar( $id ) ? (string) $id : '', ':' );
	$m   = array( 'reg' => 'registration', 'conf' => 'dates', 'help' => 'help', 'nearby' => 'campus', 'packet' => 'packet', 'campus' => 'campus', 'schedule' => 'schedule' );
	return false !== $pre && isset( $m[ $pre ] ) ? $m[ $pre ] : '';
}

/** The screen a COA action belongs to ('' = the COA itself). A check's screens are each id's own
 * (ogc_coa_app_check_screen, asked for every id where the action is guarded). */
function ogc_coa_app_act_screen( $act, WP_REST_Request $req ) {
	switch ( $act ) {
		case 'reg':
			return 'registration';
		case 'needs':
			return 'requests';
		case 'sent':
			return 'intake';
		case 'publish':
		case 'due':
		case 'owner':
			return ogc_coa_app_part_screen( (string) $req->get_param( 'part' ) );
		case 'step':
			// The step's own part is its id's prefix; a part sent that isn't it is the COA's (M6: a committee
			// sent part=requests to tick the COA's steps).
			$p   = (string) $req->get_param( 'part' );
			$pre = (string) strtok( (string) $req->get_param( 'id' ), ':' );
			return '' !== $p && $p !== $pre ? '' : ogc_coa_app_part_screen( $pre );
		case 'note':
			// The note's own part, found by its hash among the notes the year shows; anything else the COA's.
			$h   = (string) $req->get_param( 'hash' );
			$own = '';
			foreach ( function_exists( 'ogc_coa_earlier_notes' ) ? ogc_coa_earlier_notes( (int) $req['year'] ) : array() as $n ) {
				if ( isset( $n['hash'] ) && $h === (string) $n['hash'] ) {
					$own = (string) $n['part'];
					break;
				}
			}
			$p = (string) $req->get_param( 'part' );
			return '' === $own || ( '' !== $p && $p !== $own ) ? '' : ogc_coa_app_part_screen( $own );
		case 'check':
			$ids = $req->get_param( 'ids' );
			return ogc_coa_app_check_screen( is_array( $ids ) && $ids ? reset( $ids ) : $req->get_param( 'id' ) );
		case 'intro':
			return 'home';
	}
	return '';
}

/** May this person change what $screen holds in $year? The COA and webmasters may; anyone else only
 * through a screen they can see (handed to their committee, or Requests for their own rows). */
function ogc_coa_app_may( $year, $screen ) {
	if ( ogc_is_webmaster() ) {
		return true;
	}
	if ( ! function_exists( 'ogc_app_viewer' ) || ! ogc_app_tables_ready() ) {
		return ogc_is_member( $year );
	}
	$v = ogc_app_viewer( (int) $year );
	if ( $v['coa'] ) {
		return true;
	}
	return '' !== $screen && 'home' !== $screen ? ogc_app_can_see( $v, $screen ) : 'home' === $screen;
}

add_filter( 'rest_request_before_callbacks', function ( $resp, $handler, $req ) {
	if ( is_wp_error( $resp ) ) {
		return $resp;
	}
	$route = $req->get_route();
	$ns    = '#^/' . preg_quote( OGC_NS, '#' );
	$no    = function () {
		return new WP_Error( 'ogc_not_yours', 'The COA’s · Ask the COA to hand it to your committee', array( 'status' => 403 ) );
	};
	// A file's rows (whole, one row, or row by row) and its history.
	if ( preg_match( $ns . '/years/(\d{4})/(files|rows|sync|history)/([a-z][a-z0-9_-]*)$#', $route, $m ) ) {
		$write = 'files' === $m[2] ? in_array( $req->get_method(), array( 'PUT', 'PATCH' ), true ) : 'rows' === $m[2];
		$sc    = ogc_coa_app_file_screen( $m[3] );
		if ( '' === $sc || ( ! $write && 'needs' !== $m[3] ) ) {
			return $resp;
		}
		// Requests: a committee answers through coa/{y}/needs (its own rows, stamped); the file itself
		// is the COA's to change.
		if ( 'needs' === $m[3] && ( $write || 'sync' === $m[2] || 'history' === $m[2] ) ) {
			return ogc_coa_app_may( (int) $m[1], 'dates' ) ? $resp : $no();
		}
		// Menus are also Food's own screen (app-committees: Food › Menus).
		if ( 'menus' === $m[3] && $write && function_exists( 'ogc_app_viewer' ) && ogc_app_can_see( ogc_app_viewer( (int) $m[1], (string) $req->get_param( 'as' ) ), 'food-menus' ) && ! $req->get_param( 'as' ) ) {
			return $resp;
		}
		return $write && ! ogc_coa_app_may( (int) $m[1], $sc ) ? $no() : $resp;
	}
	// The COA's own routes.
	if ( preg_match( $ns . '/coa/(\d{4})(?:/([a-z-]+))?$#', $route, $m ) ) {
		$y   = (int) $m[1];
		$act = isset( $m[2] ) ? $m[2] : '';
		if ( '' === $act ) {
			// The overview: anyone who works on one of the COA's screens.
			$v = function_exists( 'ogc_app_viewer' ) && ogc_app_tables_ready() ? ogc_app_viewer( $y ) : null;
			if ( ! $v || $v['coa'] || $v['webmaster'] ) {
				return $resp;
			}
			foreach ( array_keys( ogc_coa_app_screens() ) as $id ) {
				if ( ogc_app_can_see( $v, $id ) ) {
					return $resp;
				}
			}
			return $no();
		}
		if ( in_array( $act, array( 'start', 'pickup', 'dates', 'campus', 'campus-restore' ), true ) ) {
			return ogc_coa_app_may( $y, '' ) ? $resp : $no();
		}
		$sc = ogc_coa_app_act_screen( $act, $req );
		if ( ! ogc_coa_app_may( $y, $sc ) ) {
			return $no();
		}
		// Every id of a check, not only the first (security pass, M6).
		if ( 'check' === $act ) {
			$ids = $req->get_param( 'ids' );
			foreach ( is_array( $ids ) ? $ids : array( $req->get_param( 'id' ) ) as $id ) {
				if ( ! ogc_coa_app_may( $y, ogc_coa_app_check_screen( $id ) ) ) {
					return $no();
				}
			}
		}
		// A committee answers only its own requests (and adds requests for itself). The committee that
		// runs the round (Intake, handed by the COA: module-requests.php) answers any committee's.
		if ( 'needs' === $act && ! ogc_coa_app_may( $y, 'dates' ) && ! ( function_exists( 'ogc_round_coord_now' ) && ogc_round_coord_now( $y ) ) ) {
			$mine = ogc_coa_app_my_committees( $y );
			$f    = ogc_file_get( $y, 'needs' );
			$of   = array();
			foreach ( $f ? $f['rows'] : array() as $r ) {
				$of[ isset( $r['id'] ) ? (string) $r['id'] : '' ] = ogc_committee_key( isset( $r['committee'] ) ? (string) $r['committee'] : '' );
			}
			foreach ( (array) $req->get_param( 'ops' ) as $o ) {
				$id = is_array( $o ) && isset( $o['id'] ) ? (string) $o['id'] : '';
				if ( ! isset( $of[ $id ] ) || ! in_array( $of[ $id ], $mine, true ) ) {
					return new WP_Error( 'ogc_not_found', 'Not found.', array( 'status' => 404 ) );
				}
				// A request stays with its committee: moving it to another is the COA's.
				if ( isset( $o['fields']['committee'] ) && ! in_array( ogc_committee_key( (string) $o['fields']['committee'] ), $mine, true ) ) {
					return $no();
				}
			}
			foreach ( (array) $req->get_param( 'add' ) as $a ) {
				$c = is_array( $a ) && isset( $a['committee'] ) ? ogc_committee_key( (string) $a['committee'] ) : '';
				if ( ! in_array( $c, $mine, true ) ) {
					return $no();
				}
			}
		}
	}
	return $resp;
}, 5, 3 );

// The year's settings that are the COA's to change (dates, place, the call-in line, what's public):
// a member who isn't on the COA can't change them through the files route.
function ogc_coa_app_settings_screen( $key ) {
	if ( preg_match( '/^(first_day|days|venue|city|address|hosts|timezone|timezone_label|directions|title|year)$/', $key ) ) {
		return 'dates';
	}
	// The call-in line is its own screen, handable on its own (night-schedule, module-schedule.php).
	if ( preg_match( '/^call_in_/', $key ) ) {
		return 'callin';
	}
	if ( preg_match( '/^(schedule_posted|revised)$/', $key ) ) {
		return 'schedule';
	}
	if ( preg_match( '/^(packet_posted)$/', $key ) ) {
		return 'packet';
	}
	if ( preg_match( '/^(registration_|tool_requests$|requests_url$)/', $key ) ) {
		// The round's own settings are the Intake holder's, not every committee's (security pass, M6).
		return 0 === strpos( $key, 'registration_' ) ? 'registration' : 'intake';
	}
	if ( preg_match( '/^(owner_|steps_|notes_|due_)/', $key ) ) {
		return 'dates';
	}
	return '';
}

add_filter( 'rest_request_before_callbacks', function ( $resp, $handler, $req ) {
	if ( is_wp_error( $resp ) || ! in_array( $req->get_method(), array( 'PUT', 'PATCH' ), true ) ) {
		return $resp;
	}
	if ( ! preg_match( '#^/' . preg_quote( OGC_NS, '#' ) . '/years/(\d{4})/files/settings$#', $req->get_route(), $m ) ) {
		return $resp;
	}
	$y    = (int) $m[1];
	$keys = array();
	if ( 'PATCH' === $req->get_method() ) {
		$keys[] = (string) $req->get_param( 'key' );
		$row    = $req->get_param( 'row' );
		if ( is_array( $row ) && isset( $row['key'] ) ) {
			$keys[] = (string) $row['key'];
		}
	} else {
		// A whole save: only the keys whose value it changes.
		$cur = function_exists( 'ogc_coa_kv' ) ? ogc_coa_kv( $y, 'settings' ) : array();
		foreach ( (array) $req->get_param( 'rows' ) as $r ) {
			if ( is_array( $r ) && isset( $r['key'] ) && ( ! isset( $cur[ $r['key'] ] ) || (string) $cur[ $r['key'] ] !== (string) ( isset( $r['value'] ) ? $r['value'] : '' ) ) ) {
				$keys[] = (string) $r['key'];
			}
		}
	}
	foreach ( array_filter( $keys ) as $k ) {
		$sc = ogc_coa_app_settings_screen( $k );
		if ( '' !== $sc && ! ogc_coa_app_may( $y, $sc ) ) {
			return new WP_Error( 'ogc_not_yours', 'The COA’s · Ask the COA to hand it to your committee', array( 'status' => 403 ) );
		}
	}
	return $resp;
}, 6, 3 );

// What a committee gets back from answering: its own rows, never the whole list.
add_filter( 'rest_post_dispatch', function ( $res, $server, $req ) {
	if ( ! preg_match( '#^/' . preg_quote( OGC_NS, '#' ) . '/coa/(\d{4})/needs$#', $req->get_route(), $m ) || ! ( $res instanceof WP_REST_Response ) ) {
		return $res;
	}
	$data = $res->get_data();
	if ( ! is_array( $data ) || ! isset( $data['rows'] ) || ogc_is_webmaster() || ! function_exists( 'ogc_app_viewer' ) ) {
		return $res;
	}
	$v = ogc_app_viewer( (int) $m[1] );
	// The COA, and the committee that runs the round (Intake: module-requests.php), get every row.
	if ( $v['coa'] || ( function_exists( 'ogc_round_coord' ) && ogc_round_coord( $v ) ) ) {
		return $res;
	}
	$mine         = (array) $v['committees'];
	$data['rows'] = array_values( array_filter( (array) $data['rows'], function ( $r ) use ( $mine ) {
		return in_array( ogc_committee_key( isset( $r['committee'] ) ? (string) $r['committee'] : '' ), $mine, true );
	} ) );
	$res->set_data( $data );
	return $res;
}, 10, 3 );

// A notice is a draft until Post: visitors never read a draft.
add_filter( 'ogc_file_rows_out', function ( $rows, $year, $name, $member ) {
	if ( 'notices' !== $name || $member ) {
		return $rows;
	}
	return array_values( array_filter( (array) $rows, function ( $r ) {
		return 'yes' !== ( isset( $r['draft'] ) ? (string) $r['draft'] : '' );
	} ) );
}, 15, 4 );

/** The committee keys someone is on this year (none for the COA). */
function ogc_coa_app_my_committees( $year ) {
	if ( ! function_exists( 'ogc_app_viewer' ) ) {
		return array();
	}
	$v = ogc_app_viewer( (int) $year );
	return (array) $v['committees'];
}

// A committee member reads only their own committee's requests (the COA, all of them).
add_filter( 'ogc_file_rows_out', function ( $rows, $year, $name, $member ) {
	if ( 'needs' !== $name || ! $member || ogc_is_webmaster() || ! function_exists( 'ogc_app_viewer' ) || ! ogc_app_tables_ready() ) {
		return $rows;
	}
	$v = ogc_app_viewer( (int) $year );
	// The COA, and the committee that runs the round (Intake: module-requests.php), read every row.
	if ( $v['coa'] || ( function_exists( 'ogc_round_coord' ) && ogc_round_coord( $v ) ) ) {
		return $rows;
	}
	$mine = (array) $v['committees'];
	return array_values( array_filter( (array) $rows, function ( $r ) use ( $mine ) {
		return in_array( ogc_committee_key( isset( $r['committee'] ) ? (string) $r['committee'] : '' ), $mine, true );
	} ) );
}, 40, 4 );

// The packet's parts and the menus are saved row by row too (the editors' rows route).
add_filter( 'ogc_ed_files', function ( $l ) {
	return array_values( array_unique( array_merge( (array) $l, array( 'guide', 'menus' ) ) ) );
} );

/* ================================================================== the published copy */

/** The files that wait for Publish once their part is public, and the setting that made it public. */
function ogc_coa_live_files() {
	return array( 'schedule' => 'schedule_posted', 'changes' => 'schedule_posted', 'guide' => 'packet_posted', 'menus' => 'packet_posted' );
}

/** The copy the public reads ({rows, at, by}), or null when the working copy is it. */
function ogc_coa_live_get( $year, $name ) {
	$s = ogc_state_get( (int) $year, 'live_' . $name );
	$v = $s ? $s['value'] : null;
	return is_array( $v ) && isset( $v['rows'] ) ? $v : null;
}

function ogc_coa_live_put( $year, $name, $rows ) {
	$cur = ogc_state_get( (int) $year, 'live_' . $name );
	$val = array( 'rows' => array_values( (array) $rows ), 'at' => ogc_now(), 'by' => get_current_user_id() );
	return ogc_state_put( (int) $year, 'live_' . $name, $val, $cur ? $cur['version'] : 0 );
}

function ogc_coa_live_clear( $year, $name ) {
	if ( ogc_state_get( (int) $year, 'live_' . $name ) ) {
		ogc_state_put( (int) $year, 'live_' . $name, array( 'cleared' => ogc_now() ) );
	}
}

/** Is the part that holds this file public now? */
function ogc_coa_live_on( $year, $name ) {
	$f = ogc_coa_live_files();
	return isset( $f[ $name ] ) && function_exists( 'ogc_coa_posted' ) && ogc_coa_posted( (int) $year, $f[ $name ] );
}

// Publish: what's there now is what the public reads. Unpublish: nothing is kept.
add_action( 'ogc_coa_published', function ( $year, $part, $act ) {
	$files = array( 'schedule' => array( 'schedule', 'changes' ), 'packet' => array( 'guide', 'menus' ) );
	if ( ! isset( $files[ $part ] ) ) {
		return;
	}
	foreach ( $files[ $part ] as $name ) {
		if ( 'unpublish' === $act ) {
			ogc_coa_live_clear( $year, $name );
			continue;
		}
		$f = ogc_file_get( (int) $year, $name );
		ogc_coa_live_put( $year, $name, $f ? $f['rows'] : array() );
	}
}, 10, 3 );

// The first change to a public file that has no published copy yet (a year public before the app):
// the copy is taken from what's there before the change, so the public keeps seeing it.
add_filter( 'ogc_file_rows', function ( $rows, $year, $name, $cur ) {
	if ( $cur && array_key_exists( $name, ogc_coa_live_files() ) && ogc_coa_live_on( $year, $name ) && ! ogc_coa_live_get( $year, $name ) ) {
		ogc_coa_live_put( $year, $name, $cur['rows'] );
	}
	return $rows;
}, 5, 4 );

// Visitors read the published copy (every later filter still applies to it).
add_filter( 'ogc_file_rows_out', function ( $rows, $year, $name, $member ) {
	if ( $member || ! array_key_exists( $name, ogc_coa_live_files() ) || ! ogc_coa_live_on( $year, $name ) ) {
		return $rows;
	}
	$live = ogc_coa_live_get( $year, $name );
	return $live ? $live['rows'] : $rows;
}, 1, 4 );

/** What isn't live yet: rows added, changed or removed since the last Publish. */
function ogc_coa_live_diff( $year, $name ) {
	$on   = ogc_coa_live_on( $year, $name );
	$live = $on ? ogc_coa_live_get( $year, $name ) : null;
	$f    = ogc_file_get( (int) $year, $name );
	$out  = array( 'public' => $on, 'at' => '', 'by' => '', 'added' => array(), 'changed' => array(), 'removed' => array() );
	if ( ! $on || ! $live ) {
		return $out;
	}
	$out['at'] = $live['at'];
	$out['by'] = function_exists( 'ogc_coa_first_l' ) ? ogc_coa_first_l( (int) $live['by'] ) : '';
	$key = function ( $r, $i ) {
		return ! empty( $r['_id'] ) ? (string) $r['_id'] : ( ! empty( $r['id'] ) ? (string) $r['id'] . '#' . $i : '#' . $i );
	};
	$clean = function ( $r ) {
		unset( $r['_look'], $r['_guess'] );
		ksort( $r );
		return wp_json_encode( $r );
	};
	$was = array();
	foreach ( array_values( (array) $live['rows'] ) as $i => $r ) {
		$was[ $key( $r, $i ) ] = $r;
	}
	$seen = array();
	foreach ( array_values( $f ? (array) $f['rows'] : array() ) as $i => $r ) {
		$k          = $key( $r, $i );
		$seen[ $k ] = 1;
		if ( ! isset( $was[ $k ] ) ) {
			$out['added'][] = $k;
		} elseif ( $clean( $was[ $k ] ) !== $clean( $r ) ) {
			$out['changed'][] = $k;
		}
	}
	foreach ( $was as $k => $r ) {
		if ( ! isset( $seen[ $k ] ) ) {
			$out['removed'][] = array( 'id' => $k, 'title' => isset( $r['title'] ) ? (string) $r['title'] : ( isset( $r['id'] ) ? (string) $r['id'] : '' ), 'day' => isset( $r['day'] ) ? (string) $r['day'] : '' );
		}
	}
	return $out;
}

/* ================================================================== the app's own routes */

add_action( 'rest_api_init', function () {
	$Y   = '(?P<year>\d{4})';
	$see = function ( $screens ) {
		return function ( WP_REST_Request $req ) use ( $screens ) {
			if ( ! function_exists( 'ogc_app_req_viewer' ) || null === ogc_year_get( (int) $req['year'] ) ) {
				return new WP_Error( 'ogc_not_found', 'Not found.', array( 'status' => 404 ) );
			}
			$v = ogc_app_req_viewer( $req );
			foreach ( (array) $screens as $s ) {
				if ( ogc_app_can_see( $v, $s ) ) {
					return true;
				}
			}
			return ogc_rest_denied();
		};
	};
	register_rest_route( OGC_NS, "/app/$Y/live", array(
		array( 'methods' => 'GET', 'callback' => 'ogc_coa_app_rest_live', 'permission_callback' => $see( array( 'schedule', 'packet' ) ) ),
	) );
	register_rest_route( OGC_NS, "/app/$Y/public", array(
		array( 'methods' => 'GET', 'callback' => 'ogc_coa_app_rest_public', 'permission_callback' => $see( array_keys( ogc_coa_app_screens() ) ) ),
	) );
	register_rest_route( OGC_NS, "/app/$Y/money", array(
		array( 'methods' => 'GET', 'callback' => 'ogc_coa_app_rest_money', 'permission_callback' => $see( array( 'money' ) ) ),
	) );
} );

/** GET app/{y}/live?f=schedule,changes → what isn't live of each. */
function ogc_coa_app_rest_live( WP_REST_Request $req ) {
	$y   = (int) $req['year'];
	$out = array();
	foreach ( array_filter( explode( ',', (string) $req->get_param( 'f' ) ) ) as $n ) {
		if ( array_key_exists( $n, ogc_coa_live_files() ) ) {
			$out[ $n ] = ogc_coa_live_diff( $y, $n );
		}
	}
	return rest_ensure_response( $out );
}

/**
 * GET app/{y}/public?f=help,nearby → for each file, what a visitor gets now, by the rules that decide
 * it (ogc_file_visible, the private files): { public: bool, rows: how many a visitor reads }.
 */
function ogc_coa_app_rest_public( WP_REST_Request $req ) {
	$y   = (int) $req['year'];
	$out = array();
	foreach ( array_slice( array_filter( explode( ',', (string) $req->get_param( 'f' ) ) ), 0, 12 ) as $n ) {
		if ( ! preg_match( '/^[a-z][a-z0-9_-]{0,47}$/', $n ) ) {
			continue;
		}
		$ok = ! in_array( $n, ogc_private_files(), true ) && (bool) apply_filters( 'ogc_file_visible', true, $y, $n, false );
		$f  = $ok ? apply_filters( 'ogc_file_out', ogc_file_get( $y, $n ), $y, $n ) : null;
		$rows = $f ? (array) apply_filters( 'ogc_file_rows_out', (array) $f['rows'], $y, $n, false ) : array();
		$out[ $n ] = array( 'public' => $ok && count( $rows ) > 0, 'rows' => count( $rows ) );
	}
	return rest_ensure_response( $out );
}

/**
 * GET app/{y}/money → the year's money in totals, no names: what's been paid, checks to come, refunds
 * asked, balances due, gifts. The treasurer (the lists area's payment viewers) also gets each payment
 * from lists/{y}/payments; `viewer` says whether this person is one, and `choose` whether they name them.
 */
function ogc_coa_app_rest_money( WP_REST_Request $req ) {
	$y   = (int) $req['year'];
	$tot = array( 'households' => 0, 'paid' => 0, 'paid_n' => 0, 'total' => 0, 'due' => 0, 'due_n' => 0, 'checks' => 0, 'checks_n' => 0, 'checks_late' => 0, 'refunds' => 0, 'refunds_n' => 0, 'refunded' => 0, 'gifts' => 0, 'gifts_n' => 0, 'card' => 0, 'desk' => 0, 'checks_in' => 0, 'credits_n' => 0 );
	$R   = function_exists( 'ogc_coa_kv' ) ? ogc_coa_kv( $y, 'registration' ) : array();
	$by  = isset( $R['check_by'] ) ? (string) $R['check_by'] : '';
	$today = function_exists( 'ogc_coa_today' ) ? ogc_coa_today( $y ) : gmdate( 'Y-m-d' );
	$regs  = array();
	foreach ( ogc_records( $y, 'registrations' ) as $r ) {
		$d  = (array) $r['data'];
		$st = isset( $d['status'] ) ? (string) $d['status'] : '';
		if ( 'cancelled' === $st || 'waitlist' === $st || empty( $d['people'] ) ) {
			continue;
		}
		$tot['households']++;
		$m    = isset( $d['money'] ) ? (array) $d['money'] : array();
		$paid = isset( $m['paid'] ) ? (int) $m['paid'] : 0;
		$all  = isset( $m['total'] ) ? (int) $m['total'] : 0;
		$tot['paid']  += $paid;
		$tot['total'] += $all;
		if ( $all > 0 && $paid >= $all ) {
			$tot['paid_n']++;
		}
		$owe = isset( $m['due'] ) ? (int) $m['due'] - (int) ( isset( $m['check'] ) ? $m['check'] : 0 ) - (int) ( isset( $m['pending'] ) ? $m['pending'] : 0 ) : 0;
		// Where each household stands, so every one is counted once: paid in full, a check to come,
		// owes, or nothing to pay.
		$regs[ (int) $r['id'] ] = $all > 0 && $paid >= $all ? 'full' : ( ! empty( $m['check'] ) || ! empty( $m['pending'] ) ? 'check' : ( $owe > 0 ? 'owes' : 'none' ) );
		if ( $owe > 0 ) {
			$tot['due'] += $owe;
			$tot['due_n']++;
		}
		$g = isset( $d['price']['gift_cents'] ) ? (int) $d['price']['gift_cents'] : 0;
		if ( $g ) {
			$tot['gifts'] += $g;
			$tot['gifts_n']++;
		}
	}
	if ( function_exists( 'ogc_pay_year' ) ) {
		foreach ( ogc_pay_year( $y ) as $p ) {
			if ( ! isset( $regs[ (int) $p['record_id'] ] ) ) {
				continue;
			}
			if ( 'check' === $p['kind'] && 'pending' === $p['status'] && 'full' !== $regs[ (int) $p['record_id'] ] ) {
				$regs[ (int) $p['record_id'] ] = 'check';
			}
			if ( 'check' === $p['kind'] && 'pending' === $p['status'] ) {
				$tot['checks'] += (int) $p['cents'];
				$tot['checks_n']++;
				if ( $by && $today > $by ) {
					$tot['checks_late']++;
				}
			} elseif ( 'refund' === $p['kind'] && in_array( $p['status'], array( 'requested', 'approved' ), true ) ) {
				$tot['refunds'] += (int) $p['cents'];
				$tot['refunds_n']++;
			} elseif ( 'refund' === $p['kind'] && 'sent' === $p['status'] ) {
				$tot['refunded'] += (int) $p['cents'];
			} elseif ( 'paid' === $p['status'] ) {
				$k = 'charge' === $p['kind'] ? 'card' : ( 'desk' === $p['kind'] ? 'desk' : ( 'check' === $p['kind'] ? 'checks_in' : '' ) );
				if ( $k ) {
					$tot[ $k ] += (int) $p['cents'];
				}
			}
		}
	}
	foreach ( ogc_records( $y, 'credits' ) as $r ) {
		if ( empty( $r['data']['given'] ) ) {
			$tot['credits_n']++;
		}
	}
	$tot['by'] = array( 'full' => 0, 'check' => 0, 'owes' => 0, 'none' => 0 );
	foreach ( $regs as $st ) {
		$tot['by'][ $st ]++;
	}
	$viewer = function_exists( 'ogc_lst_viewer' ) ? ogc_lst_viewer( $y, 'payments' ) : false;
	$choose = function_exists( 'ogc_lst_can_choose' ) ? ogc_lst_can_choose( $y ) : false;
	$names  = array();
	if ( $choose && function_exists( 'ogc_lst_viewers' ) ) {
		foreach ( ogc_lst_viewers( $y, 'payments' ) as $e ) {
			$m       = function_exists( 'ogc_member_find' ) ? ogc_member_find( $y, $e ) : null;
			$names[] = $m && ! empty( $m['name'] ) ? ogc_first_l( $m['name'] ) : ogc_mask_email( $e );
		}
	}
	return rest_ensure_response( array(
		'totals'     => $tot,
		'check_by'   => $by,
		'refunds_by' => isset( $R['refunds_by'] ) ? (string) $R['refunds_by'] : '',
		'payee'      => isset( $R['check_payee'] ) ? (string) $R['check_payee'] : '',
		'viewer'     => (bool) $viewer,
		'choose'     => (bool) $choose,
		'treasurers' => $names,
		'payments'   => function_exists( 'ogc_pay_year' ),
	) );
}
