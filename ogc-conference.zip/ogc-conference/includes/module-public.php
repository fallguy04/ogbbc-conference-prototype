<?php
/**
 * The Conference page and the guide (the conference area), on the server:
 *
 *   1. What the public may read of a year. A part's rows go out only once it's published, by the
 *      server's clock in the venue's time zone: the schedule (and its menus, recordings and change
 *      marks) after schedule_posted, the packet after packet_posted, Help with the schedule, News on
 *      its date, notices from their start. A carried-over year (picked up from the last one) keeps
 *      its call-in line, Help numbers and care nearby to itself until the COA confirms them. A year
 *      not yet announced isn't listed. Members of the year (and webmasters) read everything, and
 *      their pages draw the public's view unless they preview.
 *   2. Every link taken from data is http(s), tel, sms or mailto, or it's dropped (on the way out)
 *      and refused (on the way in).
 *   3. The year's calendar file, /annual-conference/2027.ics (and ?event=<row id> for one event).
 *   4. The schedule's change marks: once the schedule is published, each save that moves, changes
 *      or removes a row is kept in the year's "changes" file ("Moved · was 6:00 PM").
 *   5. The public's year bundle can be cached briefly (ETag, 60 s) and says it's public
 *      (X-OGC-Public), which is what the guide's service worker keeps for offline.
 *   6. The page itself: the facts drawn on the server (no JavaScript needed to read when and where),
 *      link previews (Open Graph) and the Event's structured data.
 *   7. The guide: signing out from a Conference page clears what this browser kept.
 */

defined( 'ABSPATH' ) || exit;

/* ------------------------------------------------------------------ the year's clock */

/** The year's settings as key → value (cached for the request). */
function ogc_pub_settings( $year ) {
	static $cache = array();
	if ( ! isset( $cache[ $year ] ) ) {
		$out = array();
		$f   = ogc_file_get( (int) $year, 'settings' );
		foreach ( $f ? (array) $f['rows'] : array() as $r ) {
			if ( isset( $r['key'] ) && '' !== $r['key'] ) {
				$out[ strtolower( trim( $r['key'] ) ) ] = isset( $r['value'] ) ? trim( (string) $r['value'] ) : '';
			}
		}
		$cache[ $year ] = $out;
	}
	return $cache[ $year ];
}

/** The venue's time zone (a valid IANA name), else Indiana's. */
function ogc_pub_tz( $year ) {
	$s  = ogc_pub_settings( $year );
	$tz = isset( $s['timezone'] ) ? $s['timezone'] : '';
	return $tz && in_array( $tz, timezone_identifiers_list(), true ) ? $tz : 'America/Indiana/Indianapolis';
}

/** Now at the venue, "YYYY-MM-DDTHH:MM". Locally (OGC_DEV only) the option ogc_dev_now sets it, to
 * try the gates at another time of year. */
function ogc_pub_now( $year ) {
	if ( function_exists( 'ogc_dev_tools_on' ) && ogc_dev_tools_on() ) {   // a local address only (M10)
		$dev = (string) get_option( 'ogc_dev_now', '' );
		if ( preg_match( '/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/', $dev ) ) {
			return $dev;
		}
	}
	$d = new DateTime( 'now', new DateTimeZone( ogc_pub_tz( $year ) ) );
	return $d->format( 'Y-m-d\TH:i' );
}

/** Is this Conference over (its word Past, by the site's own clock)? Then no preview date opens it. */
function ogc_pub_over( $year ) {
	$row = ogc_year_get( (int) $year );
	return $row && 'Past' === ogc_pub_status_word( $row, ogc_pub_now( (int) $year ) );
}

/** Now for the public's file gates: ogc_pub_now, or the day a local page previews (ogc_dev_preview_at). */
function ogc_pub_gate_now( $year ) {
	$at = ogc_dev_preview_at( $year );
	return '' !== $at ? $at : ogc_pub_now( $year );
}

/** Today at the venue of the latest Conference with data (one clock for the page, the years list and
 * the gates: the page used UTC−5 and the years list UTC). */
function ogc_pub_today() {
	static $today = null;
	if ( null === $today ) {
		$y = 0;
		foreach ( ogc_years_all() as $r ) {
			if ( ! empty( $r['data'] ) && (int) $r['year'] > $y ) {
				$y = (int) $r['year'];
			}
		}
		$today = substr( ogc_pub_now( $y ), 0, 10 );
	}
	return $today;
}

/** Is a date ("YYYY-MM-DD") real and not the "not yet" mark (9999-12-31)? */
function ogc_pub_iso( $v ) {
	return (bool) preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) $v ) && 0 !== strpos( (string) $v, '9999' );
}

/** A key/value file of a year (registration) as key → value. */
function ogc_pub_kv( $year, $name ) {
	$out = array();
	$f   = ogc_file_get( (int) $year, $name );
	foreach ( $f ? (array) $f['rows'] : array() as $r ) {
		if ( isset( $r['key'] ) && '' !== $r['key'] ) {
			$out[ strtolower( trim( $r['key'] ) ) ] = isset( $r['value'] ) ? trim( (string) $r['value'] ) : '';
		}
	}
	return $out;
}

/** Has this year's COA acted on registration itself (the year page's Schedule, Close or Reopen, or a
 * "Looks right" on its dates)? Until then, dates the pickup moved forward from last year are only a
 * suggestion. */
function ogc_pub_reg_confirmed( $year ) {
	$c   = ogc_state_get( (int) $year, 'coa' );
	$v   = $c ? (array) $c['value'] : array();
	$pub = isset( $v['pub']['registration'] ) ? (array) $v['pub']['registration'] : array();
	if ( ! empty( $pub['act'] ) && in_array( $pub['act'], array( 'schedule', 'close', 'reopen' ), true ) ) {
		return true;
	}
	return ! empty( $v['checks']['reg:dates'] );
}

/** How a year registers, as anyone outside the COA may know it (registration opened by
 * itself on a date carried from last year that nobody chose):
 *   mode    the COA's choice: 'site' (this site's form) or 'link' (another tool, registration_url),
 *           else 'none'. Never a default: an unchosen year has no Register button.
 *   opens   the day it opens, closes its last day online, closed the day the COA closed it early.
 *           A date the pickup moved forward and nobody has scheduled since reads '' (held).
 * One source for the years list (`open`, `reg_*`), the status word and the files the public gets. */
function ogc_pub_reg( $year ) {
	static $cache = array();
	$year = (int) $year;
	if ( isset( $cache[ $year ] ) ) {
		return $cache[ $year ];
	}
	$s   = ogc_pub_settings( $year );
	$reg = ogc_pub_kv( $year, 'registration' );
	$url = isset( $s['registration_url'] ) ? ogc_pub_safe_url( $s['registration_url'] ) : '';
	$m   = isset( $s['registration_mode'] ) ? strtolower( $s['registration_mode'] ) : '';
	if ( ! in_array( $m, array( 'site', 'link', 'none' ), true ) ) {
		// A year from before the year area (2026) named its own form's link; that link is its choice.
		$m = '' !== trim( $url ) ? 'link' : 'none';
	}
	if ( 'link' === $m && '' === trim( $url ) ) {
		$m = 'none';
	}
	$date  = function ( $k ) use ( $s, $reg ) {
		$v = isset( $s[ 'registration_' . $k ] ) ? $s[ 'registration_' . $k ] : '';
		if ( ! ogc_pub_iso( $v ) ) {
			$v = isset( $reg[ $k ] ) ? $reg[ $k ] : '';
		}
		return ogc_pub_iso( $v ) ? $v : '';
	};
	$out = array( 'mode' => $m, 'opens' => $date( 'opens' ), 'closes' => $date( 'closes' ), 'closed' => ogc_pub_iso( isset( $s['registration_closed'] ) ? $s['registration_closed'] : '' ) ? $s['registration_closed'] : '' );
	if ( ! ogc_pub_reg_confirmed( $year ) ) {
		$p     = ogc_state_get( $year, 'picked' );
		$p     = $p ? (array) $p['value'] : array();
		$moved = isset( $p['parts']['registration']['moved'] ) ? (array) $p['parts']['registration']['moved'] : array();
		foreach ( $moved as $mv ) {
			$k = isset( $mv['k'] ) ? (string) $mv['k'] : '';
			if ( in_array( $k, array( 'opens', 'closes' ), true ) && isset( $mv['to'] ) && $out[ $k ] === (string) $mv['to'] ) {
				$out[ $k ] = '';
			}
		}
		// A last day with no first day is no schedule at all.
		if ( '' === $out['opens'] ) {
			$out['closes'] = '';
		}
	}
	$cache[ $year ] = $out;
	return $out;
}

/** Is registration open online today, by the COA's tool and dates? */
function ogc_pub_reg_open( $reg, $today ) {
	return 'none' !== $reg['mode'] && $reg['opens'] && $reg['opens'] <= $today && ( ! $reg['closes'] || $today <= $reg['closes'] ) && ! ( $reg['closed'] && $reg['closed'] <= $today );
}

/** What a year asks people to do right now, by the server's clock: 'register' while registration is
 * open, 'volunteer' once its sign-ups are published (until it begins), else ''. Sent with the public
 * years (`open`), so the page can turn to a year people act on and say so from last year's header. */
function ogc_pub_year_open( $r, $today ) {
	if ( empty( $r['data'] ) || empty( $r['start'] ) || $r['start'] <= $today ) {
		return '';
	}
	$s = ogc_pub_settings( (int) $r['year'] );
	if ( ogc_pub_reg_open( ogc_pub_reg( (int) $r['year'] ), $today ) ) {
		return 'register';
	}
	if ( ogc_pub_iso( isset( $s['signups_posted'] ) ? $s['signups_posted'] : '' ) && $s['signups_posted'] <= $today && empty( $s['signups_closed'] ) ) {
		return 'volunteer';
	}
	return '';
}

/** The minute the last row of the Conference's last day ends (check-out morning), from the schedule
 * the public has: as week.js staying() reads it. */
function ogc_pub_leave( $year, $last ) {
	$sf    = ogc_file_get( (int) $year, 'schedule' );
	$rows  = ogc_pub_rows_out( $sf ? $sf['rows'] : array(), (int) $year, 'schedule', false );
	$leave = 0;
	foreach ( ogc_pub_items( (int) $year, $rows ) as $it ) {
		$disp = ogc_pub_slug( isset( $it['display'] ) ? $it['display'] : '' );
		if ( $it['date'] !== $last || in_array( $disp, array( 'all_day', 'desk', 'nightly' ), true ) ) {
			continue;
		}
		$a = ogc_pub_time( isset( $it['start'] ) ? $it['start'] : '' );
		$a = null === $a ? ogc_pub_time( isset( $it['sort_time'] ) ? $it['sort_time'] : '' ) : $a;
		$b = ogc_pub_time( isset( $it['end'] ) ? $it['end'] : '' );
		if ( null !== $a && null !== $b && $b <= $a ) {
			$b += 1440;
		}
		$leave = max( $leave, null !== $b ? $b : ( null !== $a ? $a : 0 ) );
	}
	return $leave;
}

/**
 * The time of year a Conference is in: the one word the page's header says (Luke, Oct 9). The same
 * rules as week.js status() and statusWord(), so the word never changes as the page loads
 * (tools/smoke-conference.sh compares the two):
 *   Postponed | Cancelled   the year's status, after it was announced
 *   Announced               hosts only, no dates yet (2028)
 *   This week               its first day through its last, and check-out morning until the last row
 *   Past                    after that
 *   Registration open       online, by the COA's tool and dates
 *   Next week               the seven days before it
 *   Upcoming                otherwise
 * (What to do once online registration closes, "Register at check-in", is a line under the buttons,
 * not the time of year.)
 */
function ogc_pub_status_word( $row, $now ) {
	if ( strlen( $now ) <= 10 ) {
		$now .= 'T00:00';
	}
	$today = substr( $now, 0, 10 );
	$min   = (int) substr( $now, 11, 2 ) * 60 + (int) substr( $now, 14, 2 );
	if ( ! empty( $row['status'] ) && in_array( strtolower( $row['status'] ), array( 'postponed', 'cancelled', 'canceled' ), true ) ) {
		return 'postponed' === strtolower( $row['status'] ) ? 'Postponed' : 'Cancelled';
	}
	if ( empty( $row['data'] ) || empty( $row['start'] ) ) {
		return 'Announced';
	}
	$y   = (int) $row['year'];
	$end = ! empty( $row['end'] ) ? $row['end'] : $row['start'];
	if ( $today >= $row['start'] && $today <= $end ) {
		return 'This week';
	}
	if ( $today > $end ) {
		$s     = ogc_pub_settings( $y );
		$names = array_values( array_filter( array_map( 'trim', explode( '|', ! empty( $s['days'] ) ? $s['days'] : 'Friday|Saturday|Sunday|Monday|Tuesday|Wednesday' ) ) ) );
		$first = ! empty( $s['first_day'] ) && ogc_pub_iso( $s['first_day'] ) ? $s['first_day'] : $row['start'];
		$last  = gmdate( 'Y-m-d', strtotime( $first . ' +' . max( 0, count( $names ) - 1 ) . ' days' ) );
		if ( $last > $end && $today <= $last && ( $today < $last || $min < ogc_pub_leave( $y, $last ) ) ) {
			return 'This week';
		}
		return 'Past';
	}
	if ( ogc_pub_reg_open( ogc_pub_reg( $y ), $today ) ) {
		return 'Registration open';
	}
	return ( strtotime( $row['start'] ) - strtotime( $today ) ) / 86400 <= 7 ? 'Next week' : 'Upcoming';
}

/** Has a part's "posted" time passed? Blank means posted (it shows once it has rows). A date alone
 * counts from the start of that day. */
function ogc_pub_posted( $when, $now ) {
	$when = trim( (string) $when );
	if ( '' === $when ) {
		return true;
	}
	if ( strlen( $when ) <= 10 ) {
		return $when <= substr( $now, 0, 10 );
	}
	return substr( str_replace( ' ', 'T', $when ), 0, 16 ) <= $now;
}

/** The year this one was picked up from ('' for a year made by hand, or the seed's own). */
function ogc_pub_carried( $year ) {
	$s = ogc_state_get( (int) $year, 'picked' );
	$v = $s ? (array) $s['value'] : array();
	return isset( $v['from'] ) ? (string) $v['from'] : '';
}

/** Has this year's COA confirmed a carried-over fact? The year area's "Looks right" when its pickup
 * lists what waits for one ('conf:callin', 'help:<need>', 'nearby:<name>'); before that, this
 * module's own marks: settings call_in_confirmed, a row's confirmed column. */
function ogc_pub_confirmed( $year, $id, $fallback ) {
	$p = ogc_state_get( (int) $year, 'picked' );
	$p = $p ? (array) $p['value'] : array();
	if ( isset( $p['confirm'] ) && is_array( $p['confirm'] ) && function_exists( 'ogc_coa_is_confirmed' ) ) {
		return ogc_coa_is_confirmed( (int) $year, $id );
	}
	return (bool) $fallback;
}

/* ------------------------------------------------------------------ 1. what the public reads */

add_filter( 'ogc_file_rows_out', 'ogc_pub_rows_out', 10, 4 );

/** Settings keys that are the COA's own bookkeeping, never shown. The one list (this module
 * and module-coa.php each had their own; ogc_coa_private_key() now asks this one). */
function ogc_pub_private_setting( $k ) {
	return (bool) preg_match( '/^(_|owner_|steps_|notes_|due_|tool_note)/', strtolower( (string) $k ) );
}

/**
 * One table of when the public may read each of a year's files (two modules each decided,
 * and disagreed on the menus). file → the setting that publishes it; the file is withheld whole until
 * that day (blank counts as published: a year made before the year area). Read by this module's
 * ogc_file_visible and rows filters, and by module-coa.php's. Besides the table:
 *   registration          once the COA has chosen this site's form and its opening day has come
 *   rooms, plans          only while households choose their rooms on the map and registration is open
 *   milestones, notices   each row from its own date (and until its "until" or "to")
 *   attachments           each row from its own "posted" too
 *   help, nearby          a row carried from last year once this year's COA confirms it (911 always)
 *   settings              the COA's own keys never; a carried call-in line once confirmed
 *   needs, notes          members only (core-rest.php ogc_private_files)
 */
function ogc_pub_gates() {
	return array(
		'schedule'    => 'schedule_posted',
		'changes'     => 'schedule_posted',
		'attachments' => 'schedule_posted',
		'help'        => 'schedule_posted',
		'nearby'      => 'schedule_posted',
		// The caterer's menus come in with the packet (the year page's The packet part).
		'menus'       => 'packet_posted',
		'guide'       => 'packet_posted',
		'shifts'      => 'signups_posted',
	);
}

/** Settings that are words the COA writes (not facts with their own Confirm), held when carried. */
function ogc_pub_carried_prose() {
	return (array) apply_filters( 'ogc_pub_carried_prose', array( 'preteen_note' ) );
}

/** May the public read this file of the year at all, now? (The whole-file half of the table.) */
function ogc_pub_file_open( $year, $name ) {
	$s     = ogc_pub_settings( $year );
	$now   = ogc_pub_gate_now( $year );
	$today = substr( $now, 0, 10 );
	$gates = ogc_pub_gates();
	if ( isset( $gates[ $name ] ) ) {
		return ogc_pub_posted( isset( $s[ $gates[ $name ] ] ) ? $s[ $gates[ $name ] ] : '', $now );
	}
	if ( 'registration' === $name ) {
		$reg = ogc_pub_reg( $year );
		return 'site' === $reg['mode'] && $reg['opens'] && $reg['opens'] <= $today;
	}
	if ( 'rooms' === $name || 'plans' === $name ) {
		$r = ogc_pub_kv( $year, 'registration' );
		return 'households' === ( isset( $r['room_choice'] ) ? strtolower( $r['room_choice'] ) : '' ) && ogc_pub_reg_open( ogc_pub_reg( $year ), $today );
	}
	return true;
}

add_filter( 'ogc_file_visible', function ( $ok, $year, $name, $member ) {
	return $ok && ( $member || ogc_pub_file_open( (int) $year, $name ) );
}, 15, 4 );

function ogc_pub_rows_out( $rows, $year, $name, $member ) {
	$rows = ogc_pub_safe_rows( $rows, $name );
	$s    = ogc_pub_settings( $year );
	$from = ogc_pub_carried( $year );
	if ( $member ) {
		// For the COA's own view (the public no longer gets carried_from): the year was picked
		// up, and whether its call-in line still waits for a Confirm.
		if ( 'settings' === $name && $from ) {
			$rows[] = array( 'key' => 'carried_from', 'value' => $from, 'help' => '' );
			if ( ! ogc_pub_confirmed( $year, 'conf:callin', ! empty( $s['call_in_confirmed'] ) ) ) {
				$rows[] = array( 'key' => 'call_in_held', 'value' => 'yes', 'help' => '' );
			}
		}
		return $rows;
	}
	if ( ! ogc_pub_file_open( $year, $name ) ) {
		return array();
	}
	// Every link the public gets that points at ogbbc.org (News, papers, the packet's links, recordings'
	// pages) points at this site instead, so a staging copy never sends people to the live one. Audio
	// and pictures stay where they're kept. (Members get the rows as saved, so an edit never writes
	// this site's address back.)
	$rows = array_map( function ( $r ) use ( $name ) {
		if ( ! is_array( $r ) ) {
			return $r;
		}
		foreach ( array( 'url', 'link', 'page', 'hosts_url' ) as $c ) {
			if ( isset( $r[ $c ] ) && '' !== $r[ $c ] ) {
				$r[ $c ] = ogc_pub_site_url( $r[ $c ] );
			}
		}
		if ( 'settings' === $name && isset( $r['key'], $r['value'] ) && preg_match( '/(^|_)url$/i', (string) $r['key'] ) && '' !== $r['value'] ) {
			$r['value'] = ogc_pub_site_url( $r['value'] );
		}
		return $r;
	}, $rows );
	$now   = ogc_pub_gate_now( $year );
	$today = substr( $now, 0, 10 );
	$keep  = function ( $fn ) use ( $rows ) {
		return array_values( array_filter( $rows, $fn ) );
	};
	// a key/value file's "help" column is the COA's own note ("Mockup: open, for the
	// walk-through", "Blank until confirmed"), never the public's; a part held with the "not yet" mark
	// (9999-12-31) reads "held" (still not posted to every page, and no made-up date in the network tab).
	if ( 'settings' === $name || 'registration' === $name ) {
		$rows = array_map( function ( $r ) {
			unset( $r['help'] );
			if ( isset( $r['value'] ) && 0 === strpos( (string) $r['value'], '9999-' ) ) {
				$r['value'] = 'held';
			}
			return $r;
		}, $rows );
	}
	switch ( $name ) {
		case 'settings':
			$confirmed = ! $from || ogc_pub_confirmed( $year, 'conf:callin', ! empty( $s['call_in_confirmed'] ) );
			// Registration's tool and dates as the COA chose them: a date the pickup carried
			// that nobody scheduled reads "held", so no page opens a form on it.
			$reg  = ogc_pub_reg( $year );
			$rows = array_map( function ( $r ) use ( $reg ) {
				$k = isset( $r['key'] ) ? strtolower( (string) $r['key'] ) : '';
				if ( 'registration_opens' === $k || 'registration_closes' === $k ) {
					$r['value'] = $reg[ substr( $k, 13 ) ] ? $reg[ substr( $k, 13 ) ] : 'held';
				} elseif ( 'registration_mode' === $k ) {
					$r['value'] = $reg['mode'];
				}
				return $r;
			}, $rows );
			// Words carried from last year (the preteen note: "No preteen program Monday or Tuesday") are
			// held like the call-in line: until this year's COA confirms them, or the packet is published.
			$prose_ok = ! $from || ogc_pub_posted( isset( $s['packet_posted'] ) ? $s['packet_posted'] : '', $now );
			return array_values( array_filter( $rows, function ( $r ) use ( $confirmed, $prose_ok, $year, $s ) {
				$k = isset( $r['key'] ) ? strtolower( (string) $r['key'] ) : '';
				if ( ogc_pub_private_setting( $k ) ) {
					return false;
				}
				if ( in_array( $k, ogc_pub_carried_prose(), true ) && ! $prose_ok && ! ogc_pub_confirmed( $year, 'conf:' . $k, ! empty( $s[ $k . '_confirmed' ] ) ) ) {
					return false;
				}
				return $confirmed || ! in_array( $k, array( 'call_in_number', 'call_in_pin' ), true );
			} ) );
		case 'attachments':
			return $keep( function ( $r ) use ( $now ) {
				return ogc_pub_posted( isset( $r['posted'] ) ? $r['posted'] : '', $now );
			} );
		case 'help':
		case 'nearby':
			// A carried-over row only once this year's COA has confirmed it. The 911 card is always true.
			return $keep( function ( $r ) use ( $from, $year, $name ) {
				if ( ! $from || ( isset( $r['kind'] ) && 'emergency' === $r['kind'] ) ) {
					return true;
				}
				$id = $name . ':' . ogc_pub_slug( 'help' === $name ? ( isset( $r['need'] ) ? $r['need'] : '' ) : ( isset( $r['name'] ) ? $r['name'] : '' ) );
				// The year area's pickup and the app's "Looks right" name a card by its row id ('help:<_id>').
				if ( 'help' === $name && ! empty( $r['_id'] ) && ! ogc_pub_confirmed( $year, 'help:' . $r['_id'], ! empty( $r['confirmed'] ) ) ) {
					return false;
				}
				return ogc_pub_confirmed( $year, $id, ! empty( $r['confirmed'] ) );
			} );
		case 'milestones':
			// From its date, and never after its "until" (the lost-and-found post, Sept 8).
			return $keep( function ( $r ) use ( $today ) {
				$d = isset( $r['date'] ) ? (string) $r['date'] : '';
				$u = isset( $r['until'] ) ? trim( (string) $r['until'] ) : '';
				return '' !== $d && $d <= $today && ( '' === $u || substr( $u, 0, 10 ) >= $today );
			} );
		case 'notices':
			return $keep( function ( $r ) use ( $now, $today ) {
				$to = isset( $r['to'] ) ? (string) $r['to'] : '';
				return ogc_pub_posted( isset( $r['from'] ) ? $r['from'] : '', $now ) && ( '' === $to || substr( $to, 0, 10 ) >= $today );
			} );
	}
	return $rows;
}

// the column list matches the rows the public gets (settings and registration lose "help").
add_filter( 'ogc_file_cols_out', function ( $cols, $year, $name, $member ) {
	if ( ! $member && ( 'settings' === $name || 'registration' === $name ) ) {
		$cols = array_values( array_diff( $cols, array( 'help' ) ) );
	}
	return $cols;
}, 10, 4 );

/** A link kept in years.csv, for this site: a site path ("/about/2026-annual-conference/") or an
 * ogbbc.org address becomes this site's own (on a staging copy the arrows and Earlier pages
 * left for the live site). Another site's address stays as it is. */
function ogc_pub_site_url( $v ) {
	$v = trim( ogc_pub_safe_url( $v ) );
	if ( '' === $v ) {
		return '';
	}
	if ( preg_match( '#^https?://(www\.)?ogbbc\.org(/.*)?$#i', $v, $m ) ) {
		$v = isset( $m[2] ) && '' !== $m[2] ? $m[2] : '/';
	}
	return 0 === strpos( $v, '/' ) && 0 !== strpos( $v, '//' ) ? home_url( $v ) : $v;
}

// A year isn't listed for the public before it's announced. Each says what it asks people to do now
// (`open`: register | volunteer), its time of year (`status`, the header's word, by the same rules as
// week.js), and how it registers (`reg_mode`, `reg_opens`, `reg_closes`, `reg_closed`: the COA's
// choice, never a date carried from last year that nobody scheduled), by the server's clock.
add_filter( 'ogc_years_public', function ( $rows, $is_webmaster ) {
	$today = ogc_pub_today();
	$rows  = array_map( function ( $r ) use ( $today ) {
		foreach ( array( 'page', 'hosts_url' ) as $k ) {
			if ( isset( $r[ $k ] ) ) {
				$r[ $k ] = ogc_pub_site_url( $r[ $k ] );
			}
		}
		$r['open'] = ogc_pub_year_open( $r, $today );
		if ( ! empty( $r['data'] ) ) {
			$reg = ogc_pub_reg( (int) $r['year'] );
			foreach ( $reg as $k => $v ) {
				$r[ 'reg_' . $k ] = $v;
			}
		}
		// Whether the year has recordings anyone may play now: the year list marks it, so the page
		// never fetches last year's whole bundle to find out.
		if ( ! empty( $r['data'] ) && ogc_pub_has_recordings( (int) $r['year'] ) ) {
			$r['recordings'] = '1';
		}
		$r['status'] = ! empty( $r['status'] ) && preg_match( '/^(postponed|cancell?ed|canceled)$/i', $r['status'] ) ? $r['status'] : '';
		$r['status_word'] = ! empty( $r['data'] ) || ( empty( $r['page'] ) && ! empty( $r['hosts'] ) ) ? ogc_pub_status_word( $r, ogc_pub_now( (int) $r['year'] ) ) : '';
		return $r;
	}, (array) $rows );
	if ( $is_webmaster ) {
		return $rows;
	}
	return array_values( array_filter( $rows, function ( $r ) use ( $today ) {
		return empty( $r['announced'] ) || (string) $r['announced'] <= $today;
	} ) );
}, 10, 2 );

/** Does the year have a recording with audio, posted by now and with its schedule published? */
function ogc_pub_has_recordings( $year ) {
	if ( ! ogc_pub_file_open( $year, 'attachments' ) ) {
		return false;
	}
	$f   = ogc_file_get( $year, 'attachments' );
	$now = ogc_pub_now( $year );
	foreach ( $f ? (array) $f['rows'] : array() as $r ) {
		$k = isset( $r['kind'] ) ? strtolower( (string) $r['kind'] ) : '';
		if ( ( 'sermon' === $k || 'recording' === $k ) && ! empty( $r['audio'] ) && ogc_pub_posted( isset( $r['posted'] ) ? $r['posted'] : '', $now ) ) {
			return true;
		}
	}
	return false;
}

/* ------------------------------------------------------------------ 2. links from data */

/** The columns that hold a link, by file ('*' for every file). */
function ogc_pub_url_cols( $name ) {
	$all = array( 'url', 'link', 'audio', 'page', 'photo', 'hosts_url' );
	return 'places' === $name ? array_merge( $all, array( 'map' ) ) : $all;
}

/** A settings key that holds a link. */
function ogc_pub_url_key( $k ) {
	return (bool) preg_match( '/(^|_)(url|pdf|photo|directions)$/', strtolower( (string) $k ) );
}

/** A link from data, or '' when it would run something (javascript:, data:…). http(s), tel, sms and
 * mailto pass, as do addresses on this site ("/…") and plain text (a place's map words). */
function ogc_pub_safe_url( $v ) {
	$v = (string) $v;
	if ( '' === trim( $v ) ) {
		return $v;
	}
	// Browsers ignore spaces and control characters inside a scheme ("java\tscript:").
	$chk = preg_replace( '/[\x00-\x20]+/', '', $v );
	if ( preg_match( '/^[a-z][a-z0-9+.\-]*:/i', $chk ) && ! preg_match( '/^(https?|tel|sms|mailto):/i', $chk ) ) {
		return '';
	}
	return $v;
}

function ogc_pub_bad_url( $v ) {
	return '' !== trim( (string) $v ) && '' === ogc_pub_safe_url( $v );
}

function ogc_pub_safe_rows( $rows, $name ) {
	$cols = ogc_pub_url_cols( $name );
	foreach ( $rows as &$r ) {
		if ( ! is_array( $r ) ) {
			continue;
		}
		if ( 'settings' === $name && isset( $r['key'], $r['value'] ) && ogc_pub_url_key( $r['key'] ) ) {
			$r['value'] = ogc_pub_safe_url( $r['value'] );
		}
		foreach ( $cols as $c ) {
			if ( isset( $r[ $c ] ) ) {
				$r[ $c ] = ogc_pub_safe_url( $r[ $c ] );
			}
		}
	}
	unset( $r );
	return $rows;
}

// On the way in: a link that would run something is refused, with a message the editor can show.
add_filter( 'ogc_file_rows_valid', function ( $ok, $rows, $year, $name ) {
	if ( is_wp_error( $ok ) ) {
		return $ok;
	}
	$cols = ogc_pub_url_cols( $name );
	foreach ( (array) $rows as $r ) {
		if ( 'settings' === $name && isset( $r['key'], $r['value'] ) && ogc_pub_url_key( $r['key'] ) && ogc_pub_bad_url( $r['value'] ) ) {
			return new WP_Error( 'ogc_bad_link', 'A link must start with https:, tel:, sms: or mailto:.', array( 'status' => 400, 'key' => $r['key'] ) );
		}
		foreach ( $cols as $c ) {
			if ( isset( $r[ $c ] ) && ogc_pub_bad_url( $r[ $c ] ) ) {
				return new WP_Error( 'ogc_bad_link', 'A link must start with https:, tel:, sms: or mailto:.', array( 'status' => 400, 'column' => $c ) );
			}
		}
	}
	return $ok;
}, 20, 4 );

/* ------------------------------------------------------------------ 5. caching the public bundle */

add_filter( 'rest_post_dispatch', function ( $res, $server, $req ) {
	if ( 'GET' !== $req->get_method() || ! ( $res instanceof WP_REST_Response ) || 200 !== $res->get_status() ) {
		return $res;
	}
	if ( ! preg_match( '#^/' . preg_quote( OGC_NS, '#' ) . '/years(?:/(\d{4})/bundle)?$#', (string) $req->get_route(), $m ) ) {
		return $res;
	}
	$public = isset( $m[1] ) ? ! ogc_is_member( $m[1] ) : ! ogc_is_webmaster();
	if ( $public ) {
		$res->header( 'X-OGC-Public', '1' );
	}
	if ( ! is_user_logged_in() ) {
		// The same for every visitor: cached for a minute, then checked again by its ETag.
		$etag = '"' . md5( (string) wp_json_encode( $res->get_data() ) ) . '"';
		$res->header( 'ETag', $etag );
		$res->header( 'Cache-Control', 'public, max-age=60' );
		$res->header( 'Vary', 'Cookie' );
		$inm = (string) $req->get_header( 'if_none_match' );
		if ( '' !== $inm && trim( $inm ) === $etag ) {
			$nm = new WP_REST_Response( null, 304 );
			foreach ( $res->get_headers() as $k => $v ) {
				$nm->header( $k, $v );
			}
			return $nm;
		}
	}
	return $res;
}, 20, 3 );

// A 304 has no body.
add_filter( 'rest_pre_serve_request', function ( $served, $result ) {
	return ( ! $served && $result instanceof WP_REST_Response && 304 === $result->get_status() ) ? true : $served;
}, 5, 2 );

/* ------------------------------------------------------------------ what the pages are told */

add_filter( 'ogc_client_config', function ( $cfg, $key ) {
	if ( in_array( $key, array( 'conference', 'guide' ), true ) ) {
		// ?as-of, ?tz and ?preview are for the year's members, webmasters and the local site only.
		$cfg['preview'] = OGC_DEV || ogc_is_webmaster() || (bool) ogc_member_years();
		$cfg['page_url'] = ogc_url();
		// nobody's records load with the page (not the public's "Ruth K." lists either).
		// week.js asks for the signed-in person's own (scope=mine), for the year on screen, itself.
		$cfg['recordKinds'] = array();
		$cfg['recordYears'] = 1;
		// Where a member's Edit on an event's sheet goes: a schedule row in the COA's editor. The
		// address is the back end's to choose (docs/21 moves it to one app), so it comes from a filter,
		// with {year} and {row} filled in by the page.
		$cfg['editRow'] = (string) apply_filters( 'ogc_edit_row_url', ogc_url( 'year' ) . '?year={year}&part=schedule&row={row}' );
		// The first answers inlined (as the register area does): the years and the opening year's files,
		// each the REST route's own answer run as this viewer, so the page draws without waiting on two
		// requests one after the other. ogc-store.js uses them once, and only while under 10 minutes old.
		$cfg['preload'] = ogc_pub_preload();
	}
	return $cfg;
}, 30, 2 );

/** The years list and the bundle of the year the page opens on, as this viewer would get them. */
function ogc_pub_preload() {
	$y = ogc_pub_page_year();
	if ( ! $y || empty( $y['row']['data'] ) ) {
		return null;
	}
	$call = function ( $route ) {
		$res = rest_do_request( new WP_REST_Request( 'GET', '/' . OGC_NS . $route ) );
		return $res->is_error() || 200 !== $res->get_status() ? null : rest_get_server()->response_to_data( $res, false );
	};
	$years = $call( '/years' );
	$b     = $call( '/years/' . (int) $y['year'] . '/bundle' );
	return $years && $b ? array( 'at' => time(), 'years' => $years, 'bundle' => array( (int) $y['year'] => $b ) ) : null;
}

// Locally only (OGC_DEV, a local address, a webmaster): set the server's clock for the gates, the
// years list and the status word (option ogc_dev_now, "YYYY-MM-DDTHH:MM"; empty for the real time),
// so tools/smoke-conference.sh can check them at any time of year.
add_action( 'rest_api_init', function () {
	if ( ! OGC_DEV || ! function_exists( 'ogc_is_local_host' ) || ! ogc_is_local_host() ) {
		return;
	}
	register_rest_route( OGC_NS, '/dev/now', array(
		'methods'             => 'POST',
		'callback'            => function ( WP_REST_Request $req ) {
			$at = (string) $req->get_param( 'at' );
			if ( '' !== $at && ! preg_match( '/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/', $at ) ) {
				return new WP_Error( 'ogc_bad_now', 'YYYY-MM-DDTHH:MM', array( 'status' => 400 ) );
			}
			update_option( 'ogc_dev_now', $at, false );
			// The gates table too, so the check can compare each file's public rows against it.
			return rest_ensure_response( array( 'now' => $at, 'gates' => ogc_pub_gates() ) );
		},
		'permission_callback' => 'ogc_can_webmaster',
	) );
} );

// The guide gets the signin area's account mark too (who's signed in · Your sign-ups · Sign out), in
// its top bar, so signing out (which clears this phone's offline copy) can be reached.
add_filter( 'ogc_pages', function ( $p ) {
	if ( isset( $p['guide'] ) && file_exists( OGC_DIR . 'assets/signin/ogc-account.js' ) ) {
		$p['guide']['scripts'][] = 'signin/ogc-account.js';
		$p['guide']['styles'][]  = 'signin/ogc-account.css';
	}
	return $p;
}, 30 );

// The guide's page for someone not signed in is the same for everyone: marked public, which is the one
// copy of the page its service worker keeps for offline (a signed-in page holds a name and a nonce).
add_action( 'ogc_before_page', function ( $page ) {
	if ( 'guide' === $page && ! is_user_logged_in() && ! headers_sent() ) {
		header( 'X-OGC-Public: 1' );
	}
} );

/* ------------------------------------------------------------------ 3. the calendar file */

add_action( 'ogc_rewrites', function ( $b ) {
	add_rewrite_rule( "^$b/(\\d{4})\\.ics$", 'index.php?ogc_page=conference&ogc_file=ics-$matches[1]', 'top' );
} );
// The core flushes the rules when its own pages change; this module's rule is flushed once here. And
// if the saved rules ever lose the Conference pages (rules rebuilt by something that ran before they
// were registered, which left every page a 404 on Oct 10), they're rebuilt on the next request.
add_action( 'init', function () {
	$stamp = 'public-1|' . ogc_base_path();
	$rules = get_option( 'rewrite_rules' );
	$lost  = is_array( $rules ) && $rules && ! isset( $rules[ '^' . preg_quote( ogc_base_path(), '' ) . '/?$' ] );
	if ( get_option( 'ogc_public_rewrites' ) !== $stamp || $lost ) {
		flush_rewrite_rules( false );
		update_option( 'ogc_public_rewrites', $stamp, true );
	}
}, 99 );

add_action( 'ogc_before_page', function ( $page ) {
	if ( 'conference' !== $page && 'guide' !== $page ) {
		return;
	}
	// Framed only by this site (the year page's See it), and no full address sent to other sites.
	// The Content-Security-Policy itself is planned with the core's nonce for the Nov 21–30 pass.
	if ( ! headers_sent() ) {
		header( "Content-Security-Policy: frame-ancestors 'self'" );
		header( 'X-Frame-Options: SAMEORIGIN' );
		header( 'Referrer-Policy: strict-origin-when-cross-origin' );
	}
	if ( 'conference' !== $page ) {
		return;
	}
	if ( preg_match( '/^ics-(\d{4})$/', (string) get_query_var( 'ogc_file' ), $m ) ) {
		ogc_pub_ics( (int) $m[1] );
	}
	// An old year asked for by ?year= (a link shared years ago) goes to its own page on the site,
	// rather than this page quietly showing another year.
	// phpcs:ignore WordPress.Security.NonceVerification -- reading which year is asked for.
	$ask = isset( $_GET['year'] ) ? sanitize_text_field( wp_unslash( $_GET['year'] ) ) : '';
	if ( preg_match( '/^\d{4}$/', $ask ) ) {
		foreach ( ogc_years_public() as $r ) {
			if ( (string) $r['year'] === $ask && empty( $r['data'] ) && ! empty( $r['page'] ) ) {
				wp_safe_redirect( $r['page'], 302 );
				exit;
			}
		}
	}
	$GLOBALS['ogc_pub_drawing'] = true;
	ogc_pub_page_head();
} );

// The page's title and description say the year: "2027 Annual Conference", the same words week.js
// sets, and the facts line (when, where, who hosts) rather than a sentence about the page.
add_filter( 'ogc_pages', function ( $p ) {
	if ( empty( $GLOBALS['ogc_pub_drawing'] ) || ! isset( $p['conference'] ) ) {
		return $p;
	}
	$y = ogc_pub_page_year();
	if ( $y ) {
		$p['conference']['title']       = $y['year'] . ' Annual Conference';
		$p['conference']['description'] = ogc_pub_facts_line( $y );
	}
	return $p;
}, 40 );

/** "Lord willing, May 28 – June 1 · Indiana Wesleyan University · Hosted by the California districts". */
function ogc_pub_facts_line( $y ) {
	return implode( ' · ', array_filter( array( $y['when'], $y['when'] ? $y['venue'] : '', $y['hosts'] ? 'Hosted by the ' . $y['hosts'] : '' ) ) );
}

/** "noon", "7:30 PM", "19:30" → minutes after midnight (as ogc-core.js parseTime), or null. */
function ogc_pub_time( $s ) {
	$t = strtolower( str_replace( '.', '', trim( (string) $s ) ) );
	if ( '' === $t ) {
		return null;
	}
	if ( preg_match( '/^(12(:00)?\s*)?noon$/', $t ) ) {
		return 720;
	}
	if ( preg_match( '/^(12(:00)?\s*)?midnight$/', $t ) ) {
		return 1440;
	}
	if ( ! preg_match( '/^(\d{1,2})(?::(\d{2}))?\s*(am|pm|a|p)?$/', $t, $m ) ) {
		return null;
	}
	$h   = (int) $m[1];
	$min = isset( $m[2] ) && '' !== $m[2] ? (int) $m[2] : 0;
	if ( $min > 59 || $h > 24 ) {
		return null;
	}
	if ( ! empty( $m[3] ) ) {
		if ( 0 === $h || $h > 12 ) {
			return null;
		}
		if ( 'p' === $m[3][0] && 12 !== $h ) {
			$h += 12;
		}
		if ( 'a' === $m[3][0] && 12 === $h ) {
			$h = 0;
		}
	}
	return $h * 60 + $min;
}

/** As ogc-core.js slug(). */
function ogc_pub_slug( $s ) {
	return trim( preg_replace( '/[^a-z0-9]+/', '_', strtolower( trim( (string) $s ) ) ), '_' );
}

/** The schedule's rows as the pages number them: one item per day, with the same stable id. */
function ogc_pub_items( $year, $rows ) {
	$s     = ogc_pub_settings( $year );
	$names = array_values( array_filter( array_map( 'trim', explode( '|', isset( $s['days'] ) && $s['days'] ? $s['days'] : 'Friday|Saturday|Sunday|Monday|Tuesday|Wednesday' ) ) ) );
	$first = isset( $s['first_day'] ) ? $s['first_day'] : '';
	if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $first ) ) {
		return array();
	}
	$days = array();
	foreach ( $names as $i => $n ) {
		$days[] = array( 'key' => ogc_pub_slug( $n ), 'name' => $n, 'date' => gmdate( 'Y-m-d', strtotime( $first . ' +' . $i . ' days' ) ) );
	}
	$find = function ( $v ) use ( $days ) {
		$k = ogc_pub_slug( $v );
		foreach ( $days as $i => $d ) {
			if ( $d['key'] === $k || $d['date'] === trim( (string) $v ) || ( '' !== $k && substr( $d['key'], 0, 3 ) === substr( $k, 0, 3 ) ) ) {
				return $i;
			}
		}
		return -1;
	};
	$out = array();
	$ids = array();
	$seq = 0;
	foreach ( $rows as $r ) {
		if ( empty( $r['title'] ) ) {
			continue;
		}
		$a = $find( isset( $r['day'] ) ? $r['day'] : '' );
		$b = ! empty( $r['last_day'] ) ? $find( $r['last_day'] ) : $a;
		if ( $a < 0 || $b < 0 ) {
			continue;
		}
		for ( $i = $a; $i <= $b; $i++ ) {
			$seq++;
			$d  = $days[ $i ];
			$id = ! empty( $r['_id'] ) ? $r['_id'] . ( $a !== $b ? '-' . $d['key'] : '' ) : 'x' . ogc_pub_slug( $d['key'] . ' ' . ( ! empty( $r['start'] ) ? $r['start'] : ( isset( $r['sort_time'] ) ? $r['sort_time'] : '' ) ) . ' ' . $r['title'] );
			if ( isset( $ids[ $id ] ) ) {
				$id .= '-' . $seq;
			}
			$ids[ $id ] = 1;
			$out[]      = array_merge( $r, array( 'id' => $id, 'date' => $d['date'] ) );
		}
	}
	return $out;
}

/** A PIN read out in groups, as the page writes it: 6883602 → "688 3602". */
function ogc_pub_pin_text( $pin ) {
	$d = preg_replace( '/\s+/', '', (string) $pin );
	return preg_match( '/^\d{6,}$/', $d ) ? substr( $d, 0, -4 ) . ' ' . substr( $d, -4 ) : $d;
}

/** A number a phone dials, with the PIN after two pauses: tel:+17179081961,,6883602. */
function ogc_pub_tel( $num, $pin ) {
	$d = preg_replace( '/\D+/', '', (string) $num );
	if ( 10 === strlen( $d ) ) {
		$d = '1' . $d;
	}
	return 'tel:+' . $d . ( $pin ? ',,' . $pin : '' );
}

/** One line of a calendar file, escaped and folded at 75 octets. */
function ogc_pub_ics_line( $k, $v ) {
	$v    = str_replace( array( '\\', ';', ',', "\r\n", "\n" ), array( '\\\\', '\\;', '\\,', '\\n', '\\n' ), (string) $v );
	$line = $k . ':' . $v;
	$out  = '';
	while ( strlen( $line ) > 74 ) {
		$cut  = 74;
		while ( $cut > 1 && ( ord( $line[ $cut ] ) & 0xC0 ) === 0x80 ) {
			$cut--; // never inside a multi-byte character
		}
		$out .= substr( $line, 0, $cut ) . "\r\n ";
		$line = substr( $line, $cut );
	}
	return $out . $line . "\r\n";
}

/** /annual-conference/2027.ics: the Conference as an all-day event; ?event=<id> one row of its
 * published schedule, with the call-in line when it's carried. Text/calendar, so a phone offers
 * Add to Calendar. */
function ogc_pub_ics( $year ) {
	$row = null;
	foreach ( ogc_years_public() as $r ) {
		if ( (int) $r['year'] === $year ) {
			$row = $r;
		}
	}
	if ( ! $row || empty( $row['start'] ) ) {
		status_header( 404 );
		nocache_headers();
		exit;
	}
	$set  = array();
	$sf   = ogc_file_get( $year, 'settings' );
	foreach ( ogc_pub_rows_out( $sf ? $sf['rows'] : array(), $year, 'settings', false ) as $r ) {
		$set[ strtolower( $r['key'] ) ] = isset( $r['value'] ) ? $r['value'] : '';
	}
	$host  = wp_parse_url( home_url(), PHP_URL_HOST );
	// The venue's name, then its address, so a phone's calendar names the place.
	$venue = ! empty( $set['venue'] ) ? $set['venue'] : ( isset( $row['venue'] ) ? $row['venue'] : '' );
	$where = implode( ', ', array_filter( array( $venue, ! empty( $set['address'] ) ? $set['address'] : ( isset( $row['city'] ) ? $row['city'] : '' ) ) ) );
	$out   = "BEGIN:VCALENDAR\r\nVERSION:2.0\r\nPRODID:-//" . $host . "//Annual Conference//EN\r\nCALSCALE:GREGORIAN\r\nMETHOD:PUBLISH\r\n";
	$name  = $year . '-annual-conference';
	// phpcs:ignore WordPress.Security.NonceVerification -- reading which event is asked for.
	$ev = isset( $_GET['event'] ) ? sanitize_key( wp_unslash( $_GET['event'] ) ) : '';
	if ( $ev ) {
		$sf    = ogc_file_get( $year, 'schedule' );
		$rows  = ogc_pub_rows_out( $sf ? $sf['rows'] : array(), $year, 'schedule', false );
		$hit   = null;
		foreach ( ogc_pub_items( $year, $rows ) as $it ) {
			if ( strtolower( $it['id'] ) === $ev ) {
				$hit = $it;
			}
		}
		$start = $hit ? ogc_pub_time( $hit['start'] ) : null;
		if ( ! $hit || null === $start ) {
			status_header( 404 );
			nocache_headers();
			exit;
		}
		$end = ogc_pub_time( isset( $hit['end'] ) ? $hit['end'] : '' );
		$end = null === $end ? $start + 60 : ( $end <= $start ? $end + 1440 : $end );
		$tz  = new DateTimeZone( ogc_pub_tz( $year ) );
		$at  = function ( $min ) use ( $hit, $tz ) {
			$d = new DateTime( $hit['date'] . ' 00:00', $tz );
			$d->modify( '+' . (int) $min . ' minutes' );
			$d->setTimezone( new DateTimeZone( 'UTC' ) );
			return $d->format( 'Ymd\THis\Z' );
		};
		$places = array();
		$pf     = ogc_file_get( $year, 'places' );
		foreach ( $pf ? $pf['rows'] : array() as $p ) {
			if ( ! empty( $p['code'] ) ) {
				$places[ strtoupper( $p['code'] ) ] = $p['name'];
			}
		}
		$place = ! empty( $hit['place'] ) && isset( $places[ strtoupper( $hit['place'] ) ] ) ? $places[ strtoupper( $hit['place'] ) ] . ', ' : '';
		$desc  = array();
		if ( ! empty( $hit['note'] ) ) {
			$desc[] = $hit['note'];
		}
		if ( ! empty( $hit['call_in'] ) && preg_match( '/^(y|yes|true|1|x)$/i', $hit['call_in'] ) && ! empty( $set['call_in_number'] ) ) {
			// Written as the page writes it, then a line a phone dials in one tap, PIN and all.
			$pin    = preg_replace( '/\D+/', '', isset( $set['call_in_pin'] ) ? $set['call_in_pin'] : '' );
			$desc[] = 'Call in · ' . $set['call_in_number'] . ( $pin ? ' · PIN ' . ogc_pub_pin_text( $pin ) : '' );
			$desc[] = ogc_pub_tel( $set['call_in_number'], $pin );
		}
		$desc[] = ogc_url( '', array( 'year' => $year, 'event' => $hit['id'] ) );
		$out   .= "BEGIN:VEVENT\r\n" . ogc_pub_ics_line( 'UID', $name . '-' . $hit['id'] . '@' . $host ) . ogc_pub_ics_line( 'DTSTAMP', gmdate( 'Ymd\THis\Z' ) ) .
			'DTSTART:' . $at( $start ) . "\r\nDTEND:" . $at( $end ) . "\r\n" .
			// Named for the Conference too, so it reads among a person's own appointments.
			ogc_pub_ics_line( 'SUMMARY', $hit['title'] . ' · ' . $year . ' Annual Conference' ) . ogc_pub_ics_line( 'LOCATION', $place . $where ) .
			ogc_pub_ics_line( 'DESCRIPTION', implode( "\n", $desc ) ) . "END:VEVENT\r\n";
		$name .= '-' . $hit['id'];
	} else {
		$end  = ! empty( $row['end'] ) ? $row['end'] : $row['start'];
		$out .= "BEGIN:VEVENT\r\n" . ogc_pub_ics_line( 'UID', $name . '@' . $host ) . ogc_pub_ics_line( 'DTSTAMP', gmdate( 'Ymd\THis\Z' ) ) .
			'DTSTART;VALUE=DATE:' . str_replace( '-', '', $row['start'] ) . "\r\n" .
			'DTEND;VALUE=DATE:' . gmdate( 'Ymd', strtotime( $end . ' +1 day' ) ) . "\r\n" .
			ogc_pub_ics_line( 'SUMMARY', $year . ' Annual Conference' ) . ogc_pub_ics_line( 'LOCATION', $where ) .
			ogc_pub_ics_line( 'DESCRIPTION', ( ! empty( $row['hosts'] ) ? 'Hosted by the ' . $row['hosts'] . ".\n" : '' ) . ogc_url( '', array( 'year' => $year ) ) ) .
			ogc_pub_ics_line( 'URL', ogc_url( '', array( 'year' => $year ) ) ) . "END:VEVENT\r\n";
	}
	$out .= "END:VCALENDAR\r\n";
	status_header( 200 );
	header( 'Content-Type: text/calendar; charset=utf-8' );
	header( 'Content-Disposition: inline; filename="' . $name . '.ics"' );
	header( 'Cache-Control: public, max-age=300' );
	header( 'X-Content-Type-Options: nosniff' );
	echo $out; // phpcs:ignore WordPress.Security.EscapeOutput -- a calendar file, escaped line by line above.
	exit;
}

/* ------------------------------------------------------------------ 4. the schedule's change marks */

/** A schedule row's key for comparing two saves: its _id, else its day and title. */
function ogc_pub_row_key( $r ) {
	return ! empty( $r['_id'] ) ? 'id:' . $r['_id'] : 'dt:' . strtolower( ( isset( $r['day'] ) ? $r['day'] : '' ) . '|' . ( isset( $r['title'] ) ? $r['title'] : '' ) );
}

// Before a save of a published schedule: what moved, changed room or went (kept until the save lands).
add_filter( 'ogc_file_rows_valid', function ( $ok, $rows, $year, $name ) {
	if ( is_wp_error( $ok ) || 'schedule' !== $name ) {
		return $ok;
	}
	$s = ogc_pub_settings( $year );
	if ( empty( $s['schedule_posted'] ) || ! ogc_pub_posted( $s['schedule_posted'], ogc_pub_now( $year ) ) ) {
		return $ok;
	}
	$cur = ogc_file_get( $year, 'schedule' );
	// A one-row change (PATCH) isn't a whole save; nothing to compare.
	if ( ! $cur || ( 1 === count( (array) $rows ) && count( $cur['rows'] ) > 1 ) ) {
		return $ok;
	}
	$old = array();
	foreach ( $cur['rows'] as $r ) {
		if ( ! empty( $r['title'] ) ) {
			$old[ ogc_pub_row_key( $r ) ] = $r;
		}
	}
	$new = array();
	foreach ( (array) $rows as $r ) {
		if ( ! empty( $r['title'] ) ) {
			$new[ ogc_pub_row_key( $r ) ] = $r;
		}
	}
	$v    = function ( $r, $k ) {
		return isset( $r[ $k ] ) ? trim( (string) $r[ $k ] ) : '';
	};
	$list = array();
	foreach ( $old as $k => $o ) {
		$base = array( 'row' => $v( $o, '_id' ), 'day' => $v( $o, 'day' ), 'last_day' => $v( $o, 'last_day' ), 'title' => $v( $o, 'title' ), 'audience' => $v( $o, 'audience' ) );
		if ( ! isset( $new[ $k ] ) ) {
			$list[] = array_merge( $base, array( 'what' => 'cancelled', 'was' => $v( $o, 'start' ), 'now' => '', 'start' => $v( $o, 'start' ), 'end' => $v( $o, 'end' ), 'place' => $v( $o, 'place' ), 'sort_time' => $v( $o, 'sort_time' ) ) );
			continue;
		}
		$n = $new[ $k ];
		if ( $v( $o, 'start' ) !== $v( $n, 'start' ) || $v( $o, 'day' ) !== $v( $n, 'day' ) ) {
			$list[] = array_merge( $base, array( 'what' => 'moved', 'was' => $v( $o, 'start' ), 'was_day' => $v( $o, 'day' ), 'now' => $v( $n, 'start' ), 'day' => $v( $n, 'day' ), 'title' => $v( $n, 'title' ) ) );
		}
		if ( $v( $o, 'place' ) !== $v( $n, 'place' ) ) {
			$list[] = array_merge( $base, array( 'what' => 'room', 'was' => $v( $o, 'place' ), 'now' => $v( $n, 'place' ), 'title' => $v( $n, 'title' ) ) );
		}
	}
	foreach ( $new as $k => $n ) {
		if ( ! isset( $old[ $k ] ) && ! empty( $n['_id'] ) ) {
			$list[] = array( 'row' => $v( $n, '_id' ), 'day' => $v( $n, 'day' ), 'last_day' => $v( $n, 'last_day' ), 'title' => $v( $n, 'title' ), 'audience' => $v( $n, 'audience' ), 'what' => 'added', 'was' => '', 'now' => $v( $n, 'start' ) );
		}
	}
	$GLOBALS['ogc_pub_changes'][ (int) $year ] = $list;
	return $ok;
}, 99, 4 );

// Once the save has landed: the changes join the year's "changes" file. Typing "6:0" on the way to
// "6:00 PM" is one change, not two; a time put back as it was is no change at all.
add_action( 'ogc_file_saved', function ( $year, $name ) {
	$year = (int) $year;
	if ( 'schedule' !== $name || empty( $GLOBALS['ogc_pub_changes'][ $year ] ) ) {
		return;
	}
	$list = $GLOBALS['ogc_pub_changes'][ $year ];
	unset( $GLOBALS['ogc_pub_changes'][ $year ] );
	$at = ogc_pub_now( $year );
	for ( $try = 0; $try < 4; $try++ ) {
		$cur  = ogc_file_get( $year, 'changes' );
		$rows = $cur ? $cur['rows'] : array();
		foreach ( $list as $c ) {
			$hit = -1;
			foreach ( $rows as $i => $r ) {
				$same = ( $c['row'] && $r['row'] === $c['row'] ) || ( ! $c['row'] && ! $r['row'] && strtolower( $r['day'] . '|' . $r['title'] ) === strtolower( $c['day'] . '|' . $c['title'] ) );
				if ( $same && $r['what'] === $c['what'] ) {
					$hit = $i;
				}
			}
			if ( $hit > -1 && 'cancelled' !== $c['what'] ) {
				$rows[ $hit ] = array_merge( $rows[ $hit ], array( 'now' => $c['now'], 'day' => $c['day'], 'title' => $c['title'], 'at' => $at ) );
				if ( $rows[ $hit ]['now'] === $rows[ $hit ]['was'] && ( empty( $rows[ $hit ]['was_day'] ) || $rows[ $hit ]['was_day'] === $rows[ $hit ]['day'] ) ) {
					array_splice( $rows, $hit, 1 );
				}
			} elseif ( 'cancelled' === $c['what'] && $c['row'] ) {
				// Removed after being added since publishing: it was never there.
				$added = -1;
				foreach ( $rows as $i => $r ) {
					if ( $r['row'] === $c['row'] && 'added' === $r['what'] ) {
						$added = $i;
					}
				}
				if ( $added > -1 ) {
					array_splice( $rows, $added, 1 );
				} else {
					$rows[] = array_merge( $c, array( 'at' => $at ) );
				}
			} else {
				$rows[] = array_merge( $c, array( 'at' => $at ) );
			}
		}
		$cols = array( 'at', 'what', 'row', 'day', 'last_day', 'title', 'audience', 'was', 'was_day', 'now', 'start', 'end', 'place', 'sort_time' );
		$ok   = ogc_file_put( $year, 'changes', array_slice( $rows, -500 ), $cur ? $cur['version'] : 0, $cols );
		if ( ! is_wp_error( $ok ) ) {
			return;
		}
	}
}, 10, 2 );

/* ------------------------------------------------------------------ 6. the page drawn on the server */

/** The year the page opens on, as week.js featuredYear() decides it: the one the webmasters set to
 * show first; else the latest whose COA announcement is out; else the latest that has begun; and
 * from Nov 1 after a Conference, the next year once it's announced. */
function ogc_pub_featured_year( $years, $today ) {
	$ys = array_values( array_filter( $years, function ( $r ) use ( $today ) {
		return ! empty( $r['data'] ) && ( empty( $r['announced'] ) || $r['announced'] <= $today );
	} ) );
	usort( $ys, function ( $a, $b ) {
		return (int) $b['year'] - (int) $a['year'];
	} );
	foreach ( $ys as $r ) {
		if ( ! empty( $r['featured'] ) && preg_match( '/^(y|yes|true|1|x)$/i', $r['featured'] ) ) {
			return $r;
		}
	}
	$pick = null;
	foreach ( $ys as $r ) {
		if ( ! empty( $r['coa_announced'] ) && $r['coa_announced'] <= $today ) {
			$pick = $r;
			break;
		}
	}
	if ( ! $pick ) {
		foreach ( $ys as $r ) {
			if ( ! empty( $r['start'] ) && $r['start'] <= $today ) {
				$pick = $r;
				break;
			}
		}
	}
	if ( ! $pick ) {
		$pick = $ys ? end( $ys ) : null;
	}
	// After a Conference, the next one once it asks people to do something (its sign-ups or registration
	// are open: `open`), or from Nov 1 once it's announced (Advisors, Oct 9: forward before Jan 1).
	if ( $pick && ! empty( $pick['end'] ) && $pick['end'] < $today ) {
		foreach ( array_reverse( $ys ) as $r ) {
			if ( (int) $r['year'] > (int) $pick['year'] && ( ! empty( $r['open'] ) || $today >= $pick['year'] . '-11-01' ) ) {
				return $r;
			}
		}
	}
	return $pick;
}

/** "May 28 – June 1, 2027" / "June 5–9, 2026" (as ogc-core.js fmtDateSpan). */
function ogc_pub_span( $a, $b ) {
	$ta = strtotime( $a . ' 12:00 UTC' );
	$tb = strtotime( ( $b ? $b : $a ) . ' 12:00 UTC' );
	if ( ! $ta ) {
		return '';
	}
	if ( gmdate( 'Y-m', $ta ) === gmdate( 'Y-m', $tb ) ) {
		return $a === $b || ! $b ? gmdate( 'F j, Y', $ta ) : gmdate( 'F j', $ta ) . '–' . gmdate( 'j, Y', $tb );
	}
	return gmdate( 'Y', $ta ) === gmdate( 'Y', $tb ) ? gmdate( 'F j', $ta ) . ' – ' . gmdate( 'F j, Y', $tb ) : gmdate( 'F j, Y', $ta ) . ' – ' . gmdate( 'F j, Y', $tb );
}

/** What the server knows about the year the page opens on: the row, its status and its facts. */
function ogc_pub_page_year() {
	static $cache = null;
	if ( null !== $cache ) {
		return $cache;
	}
	$years = ogc_years_public();
	$today = ogc_pub_today();
	// phpcs:ignore WordPress.Security.NonceVerification -- reading which year is asked for.
	$ask = isset( $_GET['year'] ) ? sanitize_text_field( wp_unslash( $_GET['year'] ) ) : '';
	$row = null;
	foreach ( $years as $r ) {
		if ( $ask && (string) $r['year'] === $ask && ( ! empty( $r['data'] ) || ( empty( $r['page'] ) && ! empty( $r['hosts'] ) ) ) ) {
			$row = $r;
		}
	}
	// The guide (a home-screen icon kept for years) opens on the next Conference whose dates are out.
	if ( ! $row && 'guide' === ogc_current_page() ) {
		foreach ( $years as $r ) {
			if ( ! empty( $r['data'] ) && ! empty( $r['start'] ) && ( empty( $r['announced'] ) || $r['announced'] <= $today ) && ( ! empty( $r['end'] ) ? $r['end'] : $r['start'] ) >= $today && ( ! $row || $r['start'] < $row['start'] ) ) {
				$row = $r;
			}
		}
	}
	if ( ! $row ) {
		$row = ogc_pub_featured_year( $years, $today );
	}
	if ( ! $row ) {
		$cache = array();
		return $cache;
	}
	$s      = ! empty( $row['data'] ) ? ogc_pub_settings( (int) $row['year'] ) : array();
	$word   = ogc_pub_status_word( $row, ogc_pub_now( (int) $row['year'] ) );
	$future = ! empty( $row['start'] ) && $row['start'] > $today;
	$cache  = array(
		'row'    => $row,
		'year'   => (string) $row['year'],
		'status' => $word,
		// As the page writes it: no year (the title is the year).
		'when'   => ! empty( $row['start'] ) ? ( $future ? 'Lord willing, ' : '' ) . preg_replace( '/, \d{4}$/', '', ogc_pub_span( $row['start'], isset( $row['end'] ) ? $row['end'] : '' ) ) : '',
		'venue'  => isset( $row['venue'] ) ? $row['venue'] : '',
		'city'   => ! empty( $s['city'] ) ? $s['city'] : ( isset( $row['city'] ) ? $row['city'] : '' ),
		'hosts'  => isset( $row['hosts'] ) ? $row['hosts'] : '',
		// A year with only its hosts (2028) has no picture: a photo would imply a place.
		'photo'  => ! empty( $s['photo'] ) ? ogc_pub_safe_url( $s['photo'] ) : ( ! empty( $row['data'] ) ? OGC_URL . 'assets/shared/img/conference-auditorium.jpg' : '' ),
		'address' => isset( $s['address'] ) ? $s['address'] : '',
	);
	return $cache;
}

/** The header's buttons as week.js action() draws them before a Conference (Register once registration
 * is open, Volunteer once sign-ups are published, else Add to calendar), so the first paint and the
 * drawn page agree. → array( 'btns' => html, 'sub' => html ) */
function ogc_pub_first_buttons( $y ) {
	$out = array( 'btns' => '', 'sub' => '' );
	$row = $y['row'];
	if ( empty( $row['data'] ) || empty( $row['start'] ) || ! in_array( $y['status'], array( 'Upcoming', 'Next week', 'Registration open' ), true ) ) {
		return $out;
	}
	$yr  = (int) $y['year'];
	$s   = ogc_pub_settings( $yr );
	$now = ogc_pub_now( $yr );
	$ics = ogc_url() . rawurlencode( $y['year'] ) . '.ics';
	$reg = '';
	if ( 'Registration open' === $y['status'] ) {
		$r   = ogc_pub_reg( $yr );
		$reg = 'link' === $r['mode'] ? ogc_pub_site_url( isset( $s['registration_url'] ) ? $s['registration_url'] : '' ) : ogc_url( 'register', array( 'year' => $yr ) );
	}
	$vol = ogc_pub_iso( isset( $s['signups_posted'] ) ? $s['signups_posted'] : '' ) && ogc_pub_posted( $s['signups_posted'], $now ) ? ogc_url( 'volunteer', array( 'year' => $yr ) ) : '';
	if ( $reg ) {
		$out['btns'] .= '<span class="wk-btnstack"><a class="wk-btn" href="' . esc_url( $reg ) . '">Register</a></span>';
	}
	if ( $vol ) {
		$out['btns'] .= '<a class="' . ( $reg ? 'wk-btn wk-btn--line' : 'wk-btn' ) . '" href="' . esc_url( $vol ) . '">Volunteer</a>';
	}
	if ( ! $out['btns'] ) {
		$out['btns'] = '<a class="wk-btn" href="' . esc_url( $ics ) . '">Add to calendar</a>';
	} elseif ( 'Next week' !== $y['status'] ) {
		$out['sub'] = '<p class="wk-sub wk-sub--quiet"><span></span><span><a href="' . esc_url( $ics ) . '">Add to calendar</a></span></p>';
	}
	return $out;
}

/** The next Conference after the year on the page, once announced, as week.js nextYearLine() writes
 * it ("2028 · Hosted by the Ohio and Tennessee districts"). Not on a past year's page. */
function ogc_pub_next_after( $y ) {
	if ( 'Past' === $y['status'] ) {
		return null;
	}
	$today = ogc_pub_today();
	$best  = null;
	foreach ( ogc_years_public() as $r ) {
		if ( (int) $r['year'] > (int) $y['year'] && ( ! $best || (int) $r['year'] < (int) $best['year'] ) && ( ! empty( $r['start'] ) ? ( ! empty( $r['end'] ) ? $r['end'] : $r['start'] ) >= $today : ! empty( $r['hosts'] ) ) ) {
			$best = $r;
		}
	}
	if ( ! $best || ( empty( $best['data'] ) && ! ( empty( $best['page'] ) && ! empty( $best['hosts'] ) ) ) ) {
		return null;
	}
	$text = ! empty( $best['start'] ) ? 'Lord willing, ' . preg_replace( '/, \d{4}$/', '', ogc_pub_span( $best['start'], isset( $best['end'] ) ? $best['end'] : '' ) ) : 'Hosted by the ' . $best['hosts'];
	return array( 'year' => (string) $best['year'], 'text' => $best['year'] . ' · ' . $text );
}

// The Conference page's own template: the same block, with the facts already in it.
add_filter( 'ogc_pages', function ( $p ) {
	if ( isset( $p['conference'] ) ) {
		$p['conference']['template'] = 'conference-public.php';
	}
	if ( isset( $p['guide'] ) ) {
		$p['guide']['template'] = 'guide-public.php';
	}
	return $p;
} );

/** Link previews (a link texted to family shows the year, its dates and picture) and the Event's
 * structured data. */
function ogc_pub_page_head() {
	add_action( 'wp_head', function () {
		$y = ogc_pub_page_year();
		if ( ! $y ) {
			return;
		}
		$title = $y['year'] . ' Annual Conference';
		$desc  = ogc_pub_facts_line( $y );
		$url   = ogc_url( '', array( 'year' => $y['year'] ) );
		echo '<meta property="og:type" content="website">' . "\n";
		echo '<meta property="og:title" content="' . esc_attr( $title ) . '">' . "\n";
		echo '<meta property="og:description" content="' . esc_attr( $desc ) . '">' . "\n";
		echo '<meta property="og:url" content="' . esc_url( $url ) . '">' . "\n";
		if ( $y['photo'] ) {
			echo '<meta property="og:image" content="' . esc_url( $y['photo'] ) . '">' . "\n";
			echo '<meta name="twitter:card" content="summary_large_image">' . "\n";
		}
		$row = $y['row'];
		if ( ! empty( $row['start'] ) ) {
			$ld = array(
				'@context'    => 'https://schema.org',
				'@type'       => 'Event',
				'name'        => $title,
				'startDate'   => $row['start'],
				'endDate'     => ! empty( $row['end'] ) ? $row['end'] : $row['start'],
				'eventStatus' => 'Cancelled' === $y['status'] ? 'https://schema.org/EventCancelled' : ( 'Postponed' === $y['status'] ? 'https://schema.org/EventPostponed' : 'https://schema.org/EventScheduled' ),
				'location'    => array( '@type' => 'Place', 'name' => $y['venue'], 'address' => $y['address'] ? $y['address'] : $y['city'] ),
				'organizer'   => array( '@type' => 'Organization', 'name' => get_bloginfo( 'name' ), 'url' => home_url( '/' ) ),
				'url'         => $url,
			);
			if ( $y['photo'] ) {
				$ld['image'] = $y['photo'];
			}
			echo '<script type="application/ld+json">' . wp_json_encode( $ld, JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP ) . "</script>\n";
		}
	}, 2 );
}

/* ------------------------------------------------------------------ 7. signing out */

// Signing out from a Conference page (a shared family phone): the browser drops what it kept for this
// site, the guide's offline copy included.
add_action( 'wp_logout', function () {
	// The signin area's Sign out (/annual-conference/signin/?signout=1) or WordPress's own with a
	// redirect back to a Conference page.
	// phpcs:ignore WordPress.Security.NonceVerification -- where the sign-out returns to.
	$to   = isset( $_REQUEST['redirect_to'] ) ? (string) wp_unslash( $_REQUEST['redirect_to'] ) : '';
	$here = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_unslash( $_SERVER['REQUEST_URI'] ) : ''; // phpcs:ignore -- compared only.
	$ours = '/' . ogc_base_path() . '/';
	if ( ( false !== strpos( $to, $ours ) || 0 === strpos( wp_parse_url( $here, PHP_URL_PATH ) . '', wp_make_link_relative( ogc_url() ) ) ) && ! headers_sent() ) {
		header( 'Clear-Site-Data: "cache", "storage"' );
	}
} );
