<?php
/**
 * Shifts in the app (Round 4, Oct 17, 2026; CHANGES/round4-shifts.md; docs/27-back-end-map/
 * area-round-shifts.md §6–9). One screen, s=shifts, for every committee: the COA, and the committee the
 * COA hands Shifts to, see every committee's shifts with a Committee filter; each committee sees its own
 * (&c=lodging, "Lodging / Shifts"). It replaces the Helpers screen (s=helpers is its old address).
 *
 *   The handing rule      ogc_shifts_hand_grants(): what a committee holding Shifts may do with another
 *                         committee's shifts (decision 4; built with the recommended answer, Michael to
 *                         confirm). ogc_shifts_may() reads it for every route here and for the heads'
 *                         routes (vol/{y}/lead…: ogc_shifts_lead_ok, ogc_shifts_withheld).
 *   One count, one place  ogc_shift_open_of() per shift and ogc_shift_counts() per committee or the year:
 *                         the screen's fact and chips, Home's "Shifts · N open", the Work rows.
 *   Routes (app/{y}/…)    GET shifts · POST shifts/save · shifts/remove · shifts/publish · shifts/check ·
 *                         shifts/called · GET shifts/phone
 *   Not public            a shift added after Publish keeps draft = yes (a column added to shifts.csv)
 *                         until Publish changes; the public never reads it and can't join it.
 *   A shift is one date   changing one day of a repeating row (Saturday–Tuesday) splits that row into
 *                         one-day rows first, each keeping the id it already had (uid|date becomes the
 *                         day's own uid), so nobody loses their place (round-shifts R2, done lazily).
 */

defined( 'ABSPATH' ) || exit;

/* ================================================================== the handing rule */

/**
 * What the committee the COA hands Shifts to (A/V in the 2027 sample) may do with another committee's
 * shifts. Decision 4 (README open question 1, round-shifts R9): Michael hasn't answered, so this is the
 * recommended answer, flagged in CHANGES/round4-shifts.md. One place: narrow it here (or with the filter
 * ogc_shifts_hand_grants) and every route follows.
 *   see      every committee's shifts, and the people on them by name
 *   people   Add person, Move, Remove (and Remove's Undo) on any committee's shift
 *   shifts   Add shift, and change a shift's fields, for any committee
 *   publish  Publish sign-ups, Publish changes, Close, Reopen
 *   phones   another committee's volunteers' phones and emails: 'acted' = only for the person being
 *            added (typed) or moved (shown in the Move ask, and logged); never in a list
 * Never granted to the holder for another committee: Message, Offer, Here, the committee's instruction,
 * Export of people, To call, the sign-in sheet with phones.
 */
function ogc_shifts_hand_grants() {
	return (array) apply_filters( 'ogc_shifts_hand_grants', array(
		'see'     => true,
		'people'  => true,
		'shifts'  => true,
		'publish' => true,
		'phones'  => 'acted',
	) );
}

/** Who runs what's words for Shifts (the Run by panel's "Handing gives"), from the rule above. */
function ogc_shifts_grant_words() {
	$g   = ogc_shifts_hand_grants();
	$out = array();
	if ( ! empty( $g['see'] ) ) {
		$out[] = 'Every committee’s shifts' . ( ! empty( $g['shifts'] ) ? ': add, change' : ': read' );
	}
	if ( ! empty( $g['people'] ) ) {
		$out[] = 'Add person · Move · Remove on any';
	}
	if ( ! empty( $g['publish'] ) ) {
		$out[] = 'Publish sign-ups · Publish changes';
	}
	$out[] = 'acted' === $g['phones'] ? 'A phone only on the person being added or moved' : 'No other committee’s phones';
	return $out;
}

/** "Food’s", "Ushers’": a committee's name as its owner, in the refusals' words. */
function ogc_shifts_poss( $name ) {
	return (string) $name . ( preg_match( '/s$/i', (string) $name ) ? '’' : '’s' );
}

/** The committee holding Shifts this year ('' = the COA). */
function ogc_shifts_holder( $y ) {
	return function_exists( 'ogc_app_handed_to' ) ? ogc_app_handed_to( (int) $y, 'shifts' ) : '';
}

/** The viewer's part on Shifts: coa | holder | member | ''. */
function ogc_shifts_role( $v ) {
	if ( empty( $v['open'] ) ) {
		return '';
	}
	if ( ! empty( $v['coa'] ) ) {
		return 'coa';
	}
	$h = ogc_shifts_holder( $v['year'] );
	if ( '' !== $h && in_array( $h, (array) $v['committees'], true ) ) {
		return 'holder';
	}
	return $v['committees'] ? 'member' : '';
}

/**
 * May this viewer do $act on one committee's shifts ($ckey: the committee's key)?
 *   see · phones · people · shifts · head (Message, Offer, Here, the instruction, Export, To call) · publish
 * The COA: everything. A committee's own people: everything for their own but publish. The holder:
 * what the grants say for another committee's, and publish. Nobody else: nothing.
 */
function ogc_shifts_may( $v, $ckey, $act ) {
	$role = ogc_shifts_role( $v );
	if ( 'coa' === $role ) {
		return true;
	}
	if ( 'publish' === $act ) {
		return 'holder' === $role && ! empty( ogc_shifts_hand_grants()['publish'] );
	}
	if ( '' !== (string) $ckey && in_array( (string) $ckey, (array) $v['committees'], true ) ) {
		return true;
	}
	if ( 'holder' !== $role ) {
		return false;
	}
	$g = ogc_shifts_hand_grants();
	switch ( $act ) {
		case 'see':
			return ! empty( $g['see'] );
		case 'people':
			return ! empty( $g['people'] );
		case 'shifts':
			return ! empty( $g['shifts'] );
		case 'phone_acted':
			return 'acted' === $g['phones'] && ! empty( $g['people'] );
	}
	return false;
}

/** The viewer of a heads' route (vol/{y}/lead…): the app's viewer, with its See as. */
function ogc_shifts_lead_viewer( $y ) {
	return ogc_app_viewer( (int) $y, isset( $GLOBALS['ogc_appc_vol_as'] ) ? (string) $GLOBALS['ogc_appc_vol_as'] : '' );
}

/**
 * The heads' routes for the holder on another committee (module-volunteer-lead.php asks this once the
 * route's own checks pass): the list and its print mark (see), Add, Move, Remove and its Undo (people).
 * Everything else there (Message, Offer, Here, the instruction, Export, the contact) is the committee's
 * own and the COA's: 403.
 */
function ogc_shifts_lead_ok( $y, $cname, WP_REST_Request $req ) {
	if ( null === $cname || '' === (string) $cname || ! function_exists( 'ogc_app_viewer' ) ) {
		return true;
	}
	$v = ogc_shifts_lead_viewer( $y );
	$k = ogc_committee_key( (string) $cname );
	if ( $v['coa'] || in_array( $k, (array) $v['committees'], true ) || in_array( (string) $cname, ogc_vol_headed( (int) $y ), true ) ) {
		return true;
	}
	if ( 'holder' !== ogc_shifts_role( $v ) ) {
		return true;   // ogc_vol_can_lead decided already (it refuses anyone else)
	}
	$act  = preg_match( '#/lead/([a-z]+)$#', (string) $req->get_route(), $m ) ? $m[1] : ( 'GET' === $req->get_method() ? 'list' : '' );
	$need = array( 'list' => 'see', 'printed' => 'see', 'add' => 'people', 'move' => 'people', 'remove' => 'people', 'restore' => 'people' );
	if ( isset( $need[ $act ] ) && ogc_shifts_may( $v, $k, $need[ $act ] ) ) {
		return true;
	}
	return new WP_Error( 'ogc_not_yours', ogc_shifts_poss( $cname ) . ' · Its own committee or the COA', array( 'status' => 403 ) );
}

/** Are this committee's people's phones and emails withheld from the viewer of a heads' route? */
function ogc_shifts_withheld( $y, $cname ) {
	if ( ! function_exists( 'ogc_app_viewer' ) || '' === (string) $cname ) {
		return false;
	}
	$v = ogc_shifts_lead_viewer( $y );
	return ! ogc_shifts_may( $v, ogc_committee_key( (string) $cname ), 'phones' ) && ! in_array( (string) $cname, ogc_vol_headed( (int) $y ), true );
}

/** One heads' list as the holder sees another committee's: names, never phones or emails (the grants). */
function ogc_shifts_withhold_lead( $out ) {
	$out['shifts'] = isset( $out['shifts'] ) ? (array) $out['shifts'] : array();
	foreach ( $out['shifts'] as &$s ) {
		foreach ( $s['people'] as &$p ) {
			$p['phone']    = '';
			$p['email']    = '';
			$p['note']     = '';
			$p['withheld'] = true;
		}
		unset( $p );
		foreach ( $s['waiting'] as &$w ) {
			$w['phone']    = '';
			$w['email']    = '';
			$w['withheld'] = true;
		}
		unset( $w );
	}
	unset( $s );
	$out['messages'] = array();
	$out['refused']  = array();
	unset( $out['yf'] );
	if ( isset( $out['setup'] ) ) {
		$out['setup']['can'] = false;
	}
	$out['withheld'] = true;
	return $out;
}

/* ================================================================== one count, one place */

/** A shift's open places as every count says them: public (not draft), not Committee only, a number,
 * not started yet. The rest have none (README rule 10; Home's "Shifts · N open" counts the same). */
function ogc_shift_open_of( $sh, $n ) {
	if ( ! empty( $sh['draft'] ) || ! empty( $sh['unlimited'] ) || 'committee' === $sh['shown'] || ogc_vol_now() >= (int) $sh['start_ts'] ) {
		return 0;
	}
	return max( 0, (int) $sh['needed'] - (int) $n );
}

/** The year's waitlist entries by shift. */
function ogc_shifts_waits( $y ) {
	$out = array();
	foreach ( ogc_records( (int) $y, 'waits' ) as $w ) {
		$id           = isset( $w['data']['id'] ) ? (string) $w['data']['id'] : '';
		$out[ $id ][] = $w;
	}
	return $out;
}

/**
 * The counts of one committee's shifts ($ckey), or every committee's (null): shifts, places (the Needed
 * of shifts with a number), filled (per shift, never past its Needed), over, nolimit, open (places, by
 * ogc_shift_open_of), short (shifts with open places), waiting, draft (not public yet). Read by the
 * screen, Home's need and the Work rows, so each says the number the screen shows.
 */
function ogc_shift_counts( $y, $ckey = null, $fresh = false ) {
	static $memo = array();
	$k = (int) $y . '|' . ( null === $ckey ? '*' : $ckey ) . '|' . ogc_vol_now();
	if ( ! $fresh && isset( $memo[ $k ] ) ) {
		return $memo[ $k ];
	}
	// The places and the waitlist read once a request for every committee's count (a write asks fresh).
	static $read = array();
	if ( $fresh || ! isset( $read[ (int) $y ] ) ) {
		$read[ (int) $y ] = array( ogc_vol_seat_map( (int) $y ), ogc_shifts_waits( $y ) );
	}
	list( $map, $waits ) = $read[ (int) $y ];
	$out   = array( 'shifts' => 0, 'places' => 0, 'filled' => 0, 'over' => 0, 'nolimit' => 0, 'open' => 0, 'short' => 0, 'waiting' => 0, 'draft' => 0 );
	foreach ( ogc_vol_shifts( (int) $y, $fresh ) as $id => $sh ) {
		if ( null !== $ckey && ogc_committee_key( $sh['committee'] ) !== $ckey ) {
			continue;
		}
		$n = isset( $map[ $id ] ) ? count( $map[ $id ] ) : 0;
		$out['shifts']++;
		$out['waiting'] += isset( $waits[ $id ] ) ? count( $waits[ $id ] ) : 0;
		$out['draft']   += ! empty( $sh['draft'] ) ? 1 : 0;
		if ( $sh['unlimited'] ) {
			$out['nolimit']++;
		} else {
			$out['places'] += (int) $sh['needed'];
			$out['filled'] += min( $n, (int) $sh['needed'] );
			$out['over']   += max( 0, $n - (int) $sh['needed'] );
		}
		$o = ogc_shift_open_of( $sh, $n );
		$out['open']  += $o;
		$out['short'] += $o ? 1 : 0;
	}
	return $memo[ $k ] = $out;
}

/** The counts in the screen's words, the same everywhere they're said: "18 of 24 filled" (never a zero:
 * "None of 24 filled"). */
function ogc_shift_filled_words( $c ) {
	return $c['places'] ? ( $c['filled'] ? $c['filled'] : 'None' ) . ' of ' . $c['places'] . ' filled' : '';
}

/* ================================================================== the screen */

add_filter( 'ogc_app_screens', function ( $s, $year ) {
	$keys = array();
	foreach ( function_exists( 'ogc_app_committees' ) ? ogc_app_committees( (int) $year ) : array() as $c ) {
		if ( 'coa' !== $c['ckey'] ) {
			$keys[] = $c['ckey'];
		}
	}
	unset( $s['helpers'] );
	$shift = array( 'title' => 'Shifts', 'section' => 'own', 'who' => array_merge( array( 'coa' ), $keys ), 'handable' => true, 'coa_opens' => true, 'icon' => 'members' );
	// In the COA's section in the year's order: after Money, before the packet (README 2.1).
	$out = array();
	foreach ( $s as $id => $d ) {
		$out[ $id ] = $d;
		if ( 'money' === $id ) {
			$out['shifts'] = $shift;
		}
	}
	if ( ! isset( $out['shifts'] ) ) {
		$out['shifts'] = $shift;
	}
	return $out;
}, 35, 2 );

/* ------------------------------------------------------------------ a shift as the screen reads it */

/** The fixed rules (docs/25; round-shifts R3): none · 18 · 21 · certified. Other words read as 'other'. */
function ogc_shifts_rule_key( $sh ) {
	if ( (int) $sh['min_age'] >= 21 ) {
		return '21';
	}
	if ( (int) $sh['min_age'] >= 18 ) {
		return '18';
	}
	if ( ! empty( $sh['question'] ) || preg_match( '/certif/i', (string) $sh['rule'] ) ) {
		return 'certified';
	}
	return '' === trim( (string) $sh['rule'] ) ? 'none' : 'other';
}

/** A person's key in the list: the volunteer (ogc_vol_pkey), as a short digest (never the email). */
function ogc_shifts_pk( $rec ) {
	$d = $rec['data'];
	return substr( md5( ogc_vol_pkey( $rec['email'], isset( $d['name'] ) ? $d['name'] : '', isset( $d['phone'] ) ? $d['phone'] : '' ) ), 0, 12 );
}

/** The year's places, by code: name and the Campus row's own id (its panel). */
function ogc_shifts_places( $y ) {
	$out = array();
	$f   = ogc_file_get( (int) $y, 'places' );
	foreach ( $f ? $f['rows'] : array() as $p ) {
		if ( ! empty( $p['code'] ) ) {
			$out[ strtoupper( (string) $p['code'] ) ] = array( 'code' => (string) $p['code'], 'name' => ! empty( $p['name'] ) ? (string) $p['name'] : (string) $p['code'], 'id' => isset( $p['_id'] ) ? (string) $p['_id'] : '' );
		}
	}
	return $out;
}

/** The schedule rows that overlap a shift on its own day (by their exact times; words-only rows aren't). */
function ogc_shifts_schedule_overlap( $y, $sh, $rows ) {
	if ( ! empty( $sh['allweek'] ) ) {
		return 0;
	}
	$n = 0;
	foreach ( $rows as $r ) {
		if ( empty( $r['day'] ) || strtolower( substr( (string) $r['day'], 0, 3 ) ) !== strtolower( substr( (string) $sh['day'], 0, 3 ) ) ) {
			continue;
		}
		$a = ogc_vol_parse_time( isset( $r['start'] ) ? $r['start'] : '' );
		$b = ogc_vol_parse_time( isset( $r['end'] ) ? $r['end'] : '' );
		if ( null === $a || null === $b ) {
			continue;
		}
		if ( $b <= $a ) {
			$b += 1440;
		}
		$n += $a < (int) $sh['end'] && $b > (int) $sh['start'] ? 1 : 0;
	}
	return $n;
}

/**
 * One shift as the screen draws it (the same words and keys as the heads' list, module-volunteer-lead.php,
 * so one drawing serves both), with what the panel needs besides: the place's code, the rule's key, the
 * draft mark, its open places, what this viewer may do on it, and each person's key and how they're reached.
 */
function ogc_shifts_row( $y, $sh, $ctx ) {
	$id     = $sh['id'];
	$k      = ogc_committee_key( $sh['committee'] );
	$v      = $ctx['v'];
	$phones = ogc_shifts_may( $v, $k, 'phones' );
	$seats  = isset( $ctx['map'][ $id ] ) ? $ctx['map'][ $id ] : array();
	$n      = count( $seats );
	$people = array();
	foreach ( $ctx['gone'] ? array() : $seats as $seat ) {
		$r  = $seat['record'];
		$pp = ogc_vol_lead_person( $r );
		$pp['pk']    = ogc_shifts_pk( $r );
		// How the site reaches them (round-shifts 3.4): their own email, a helper's, or a phone only.
		$pp['reach'] = $pp['via'] ? 'helper' : ( '' !== (string) $r['email'] ? 'email' : 'phone' );
		if ( ! $phones ) {
			$pp['phone']    = '';
			$pp['email']    = '';
			$pp['note']     = '';
			$pp['withheld'] = true;
		}
		// The household's registration number, kept at join (Round 3): the COA's Linked line only.
		if ( $v['coa'] && ! empty( $r['data']['reg'] ) ) {
			$pp['reg'] = (string) $r['data']['reg'];
		}
		$people[] = $pp;
	}
	$waiting = array();
	foreach ( $ctx['gone'] || ! isset( $ctx['waits'][ $id ] ) ? array() : $ctx['waits'][ $id ] as $w ) {
		$waiting[] = array( 'rid' => (int) $w['id'], 'name' => isset( $w['data']['name'] ) ? $w['data']['name'] : '', 'phone' => $phones && isset( $w['data']['phone'] ) ? (string) $w['data']['phone'] : '', 'email' => $phones ? (string) $w['email'] : '', 'at' => $w['created_at'], 'withheld' => ! $phones );
	}
	$code = (string) $sh['place'];
	$pl   = '' !== $code && isset( $ctx['places'][ strtoupper( $code ) ] ) ? $ctx['places'][ strtoupper( $code ) ] : null;
	return array(
		'id'         => $id,
		'uid'        => $sh['uid'],
		'c'          => $k,
		'committee'  => $sh['committee'],
		'on_year'    => (bool) ogc_app_committee( (int) $y, $k ),
		'role'       => $sh['role'],
		'day'        => $sh['day'],
		'date'       => $sh['date'],
		'start'      => $sh['start'],
		'end'        => $sh['end'],
		'allweek'    => ! empty( $sh['allweek'] ),
		'last_date'  => isset( $sh['last_date'] ) ? $sh['last_date'] : $sh['date'],
		'eve'        => ogc_vol_eve_date( $sh ),
		'night'      => ogc_vol_night_words( $sh ),
		'day_words'  => ogc_vol_subject_day( (int) $y, $sh ),
		'needed'     => $sh['needed'],
		'unlimited'  => $sh['unlimited'],
		'place'      => $sh['place_name'],
		'place_code' => $code,
		'place_ok'   => (bool) $pl,
		'place_id'   => $pl ? $pl['id'] : '',
		'rule'       => $sh['rule'] ? ogc_vol_rule_label( $sh ) : '',
		'rule_words' => ! $sh['rule'] ? '' : ( $sh['min_age'] && ! $sh['question'] ? 'For ' . $sh['min_age'] . ' or older' : ucfirst( trim( (string) $sh['rule'] ) ) ),
		'rule_key'   => ogc_shifts_rule_key( $sh ),
		'shown'      => $sh['shown'],
		'draft'      => ! empty( $sh['draft'] ),
		'note'       => $sh['note'],
		'people'     => $people,
		'n'          => $n,
		'waiting'    => $waiting,
		'over'       => $sh['unlimited'] ? 0 : max( 0, $n - $sh['needed'] ),
		'open'       => ogc_shift_open_of( $sh, $n ),
		'state'      => ogc_vol_shift_state( (int) $y, $sh, $n ),
		'sched'      => isset( $ctx['sched'] ) ? ogc_shifts_schedule_overlap( $y, $sh, $ctx['sched'] ) : 0,
		'can'        => array(
			'people' => ogc_shifts_may( $v, $k, 'people' ),
			'shifts' => ogc_shifts_may( $v, $k, 'shifts' ),
			'phones' => $phones,
			'head'   => ogc_shifts_may( $v, $k, 'head' ),
		),
	);
}

/* ------------------------------------------------------------------ To call (R21) */

/**
 * The people the email can't reach (a phone only, or through a helper), who should hear from the head by
 * phone: a shift tomorrow (the venue's date), or a shift whose day, time or place changed since they were
 * last marked Called. From Publish to the last day; only where the viewer sees phones.
 */
function ogc_shifts_to_call( $y, $rows ) {
	if ( ! ogc_vol_posted( (int) $y ) ) {
		return array();
	}
	$today = function_exists( 'ogc_app_today' ) ? ogc_app_today( (int) $y ) : ogc_vol_wall( (int) $y )['date'];
	$last  = ogc_vol_last_day( (int) $y );
	if ( $last && $today > $last ) {
		return array();
	}
	$tomorrow = gmdate( 'Y-m-d', strtotime( $today . ' 12:00:00 UTC' ) + DAY_IN_SECONDS );
	$snap     = ogc_state_get( (int) $y, 'vol-snap' );
	$snap     = $snap ? (array) $snap['value'] : array();
	$called   = ogc_state_get( (int) $y, 'shifts-called' );
	$called   = $called ? (array) $called['value'] : array();
	$out      = array();
	foreach ( $rows as $s ) {
		if ( empty( $s['can']['head'] ) || empty( $s['can']['phones'] ) ) {
			continue;
		}
		$seq = isset( $snap[ $s['id'] ]['seq'] ) ? (int) $snap[ $s['id'] ]['seq'] : 0;
		foreach ( $s['people'] as $p ) {
			if ( 'email' === $p['reach'] ) {
				continue;
			}
			$c    = isset( $called[ $p['rid'] ] ) ? (array) $called[ $p['rid'] ] : null;
			$why  = '';
			if ( $seq > ( $c ? (int) $c['seq'] : 0 ) ) {
				$why = 'Changed';
			} elseif ( $s['eve'] === $tomorrow && ! ( $c && (string) $c['on'] >= $today ) ) {
				$why = 'Tomorrow';
			}
			if ( '' === $why ) {
				continue;
			}
			$out[] = array( 'rid' => $p['rid'], 'name' => $p['name'], 'phone' => $p['phone'], 'helper' => $p['via'], 'shift' => $s['id'], 'c' => $s['c'], 'why' => $why, 'seq' => $seq );
		}
	}
	return $out;
}

/* ------------------------------------------------------------------ routes */

add_action( 'rest_api_init', function () {
	$Y   = '/app/(?P<year>\d{4})/shifts';
	$see = function ( WP_REST_Request $req ) {
		if ( ! function_exists( 'ogc_app_tables_ready' ) || ! ogc_app_tables_ready() || null === ogc_year_get( (int) $req['year'] ) ) {
			return new WP_Error( 'ogc_not_found', 'Not found.', array( 'status' => 404 ) );
		}
		$v = ogc_app_req_viewer( $req );
		return ogc_app_can_see( $v, 'shifts' ) ? true : ogc_rest_denied();
	};
	$write = function ( WP_REST_Request $req ) use ( $see ) {
		$ok = $see( $req );
		if ( true !== $ok ) {
			return $ok;
		}
		return ogc_app_req_viewer( $req )['as'] ? new WP_Error( 'ogc_read_only', 'Read only while seeing as', array( 'status' => 403 ) ) : true;
	};
	register_rest_route( OGC_NS, $Y, array( 'methods' => 'GET', 'callback' => 'ogc_shifts_rest_get', 'permission_callback' => $see ) );
	register_rest_route( OGC_NS, "$Y/phone", array( 'methods' => 'GET', 'callback' => 'ogc_shifts_rest_phone', 'permission_callback' => $write ) );
	foreach ( array( 'save', 'remove', 'publish', 'check', 'called' ) as $a ) {
		register_rest_route( OGC_NS, "$Y/$a", array( 'methods' => 'POST', 'callback' => 'ogc_shifts_rest_' . $a, 'permission_callback' => $write ) );
	}
} );

/** The days a shift may be on (the Conference's), and the year's places: the panel's choices. */
function ogc_shifts_choices( $y ) {
	$days = array();
	foreach ( ogc_vol_days( (int) $y ) as $d ) {
		$days[] = array( 'date' => $d['date'], 'name' => $d['name'] );
	}
	$places = array();
	foreach ( ogc_shifts_places( $y ) as $p ) {
		$places[] = array( 'code' => $p['code'], 'name' => $p['name'] );
	}
	return array( 'days' => $days, 'places' => $places );
}

/**
 * GET app/{y}/shifts[?household=R-…]: every shift this viewer may see (the COA and the holder: every
 * committee's; anyone else: their own committees'), each with its people (phones by the rule), the
 * counts per committee and in all, To call, the Publish panel's What's left, and the panel's choices.
 */
function ogc_shifts_rest_get( WP_REST_Request $req ) {
	$y    = (int) $req['year'];
	$v    = ogc_app_req_viewer( $req );
	$role = ogc_shifts_role( $v );
	ogc_vol_prepare_year( $y );
	$sched = ogc_file_get( $y, 'schedule' );
	$ctx  = array(
		'v'      => $v,
		'map'    => ogc_vol_seat_map( $y ),
		'waits'  => ogc_shifts_waits( $y ),
		'gone'   => ogc_vol_names_gone( $y ),
		'places' => ogc_shifts_places( $y ),
		'sched'  => $sched ? (array) $sched['rows'] : array(),
	);
	// One household's places only (its Linked "Shifts · 3", Round 3), inside the viewer's own reach.
	$hrid = is_scalar( $req->get_param( 'household' ) ) ? (string) $req->get_param( 'household' ) : '';
	$hset = null;
	if ( preg_match( '/^R-\d{4}-\d{1,8}$/', $hrid ) && function_exists( 'ogc_vol_household_seats' ) ) {
		$hset = array();
		foreach ( ogc_vol_household_seats( $y, $hrid ) as $hs ) {
			$hset[ $hs['shift'] ] = ( isset( $hset[ $hs['shift'] ] ) ? $hset[ $hs['shift'] ] : 0 ) + 1;
		}
	}
	$rows = array();
	foreach ( ogc_vol_shifts( $y ) as $sh ) {
		$k = ogc_committee_key( $sh['committee'] );
		if ( ! ogc_shifts_may( $v, $k, 'see' ) ) {
			continue;
		}
		$r = ogc_shifts_row( $y, $sh, $ctx );
		if ( null !== $hset ) {
			$r['hh'] = isset( $hset[ $sh['id'] ] ) ? $hset[ $sh['id'] ] : 0;
		}
		$rows[] = $r;
	}
	// The committees, in the board's order (those with no shifts too, so the holder sees who has none),
	// then shifts whose committee isn't on the year's list ("Kit packing": No committee, R26).
	$checked = ogc_state_get( $y, 'shifts-checked' );
	$checked = $checked ? (array) $checked['value'] : array();
	$picked  = ogc_state_get( $y, 'picked' );
	$from    = $picked && ! empty( $picked['value']['from'] ) ? (string) $picked['value']['from'] : '';
	$coms    = array();
	$seen    = array();
	foreach ( ogc_app_committees( $y ) as $c ) {
		if ( 'coa' === $c['ckey'] || ! ogc_shifts_may( $v, $c['ckey'], 'see' ) ) {
			continue;
		}
		$seen[ $c['ckey'] ] = true;
		$coms[]             = ogc_shifts_committee_row( $y, $c['ckey'], $c['name'], true, $checked, $v );
	}
	foreach ( $rows as $r ) {
		if ( ! isset( $seen[ $r['c'] ] ) ) {
			$seen[ $r['c'] ] = true;
			$coms[]          = ogc_shifts_committee_row( $y, $r['c'], $r['committee'], false, $checked, $v );
		}
	}
	$counts = $v['coa'] || 'holder' === $role ? ogc_shift_counts( $y ) : null;
	if ( null === $counts ) {
		$counts = array();
		foreach ( $coms as $c ) {
			foreach ( $c['counts'] as $kk => $n ) {
				$counts[ $kk ] = ( isset( $counts[ $kk ] ) ? $counts[ $kk ] : 0 ) + $n;
			}
		}
	}
	$holder = ogc_shifts_holder( $y );
	$hc     = '' !== $holder ? ogc_app_committee( $y, $holder ) : null;
	$s      = ogc_vol_settings( $y );
	$out    = array(
		'role'      => $role,
		'own'       => array_values( (array) $v['committees'] ),
		'holder'    => $hc ? array( 'key' => $holder, 'name' => $hc['name'] ) : null,
		'can'       => array( 'publish' => ogc_shifts_may( $v, '', 'publish' ) ),
		'posted'    => ogc_vol_posted( $y ),
		'posted_on' => isset( $s['signups_posted'] ) && preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) $s['signups_posted'] ) && '9999-12-31' !== $s['signups_posted'] ? (string) $s['signups_posted'] : '',
		'opens'     => ogc_vol_opens( $y ),
		'closed'    => ogc_vol_closed( $y ),
		'shut'      => ! empty( $s['signups_closed'] ) && preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) $s['signups_closed'] ) && $s['signups_closed'] <= ogc_vol_wall( $y )['date'],
		'begun'     => ( $days = ogc_vol_days( $y ) ) && ogc_vol_wall( $y )['date'] >= $days[0]['date'],
		'gone'      => $ctx['gone'],
		'from'      => $from,
		'committees' => $coms,
		'counts'    => $counts,
		'shifts'    => $rows,
		'tocall'    => ogc_shifts_to_call( $y, $rows ),
		'phone'     => isset( $s['volunteer_phone'] ) ? (string) $s['volunteer_phone'] : '',
		'choices'   => ogc_shifts_choices( $y ),
	);
	if ( null !== $hset ) {
		$out['household'] = array( 'rid' => $hrid, 'words' => function_exists( 'ogc_vol_household_words' ) ? ogc_vol_household_words( $y, $hrid ) : $hrid );
	}
	return rest_ensure_response( $out );
}

/** One committee's line on Shifts: its counts, its head, whether its carried shifts were checked. */
function ogc_shifts_committee_row( $y, $ckey, $name, $on_year, $checked, $v ) {
	$heads = array();
	if ( $on_year && function_exists( 'ogc_vol_heads_of' ) ) {
		foreach ( ogc_vol_heads_of( $y, $name ) as $hd ) {
			$heads[] = $hd['name'];
		}
	}
	$ck = isset( $checked[ $ckey ] ) ? (array) $checked[ $ckey ] : null;
	return array(
		'key'     => $ckey,
		'name'    => $name,
		'on_year' => $on_year,
		'heads'   => $heads,
		'counts'  => ogc_shift_counts( $y, $ckey ),
		'checked' => $ck ? array( 'by' => (string) $ck['by'], 'on' => (string) $ck['on'] ) : null,
		'can'     => array( 'people' => ogc_shifts_may( $v, $ckey, 'people' ), 'shifts' => ogc_shifts_may( $v, $ckey, 'shifts' ), 'phones' => ogc_shifts_may( $v, $ckey, 'phones' ), 'head' => ogc_shifts_may( $v, $ckey, 'head' ) ),
	);
}

/** "Ruth K.": who did it, as every stamp says it. */
function ogc_shifts_me() {
	$u = wp_get_current_user();
	return $u && $u->ID && function_exists( 'ogc_coa_first_l' ) ? ogc_coa_first_l( $u->ID ) : '';
}

/* ------------------------------------------------------------------ changing a shift */

/**
 * One field, checked: the value shifts.csv keeps, or a WP_Error with the reason at the field.
 *   committee (key) · role · date (one of the Conference's days) · start · end (a clock time in 5-minute
 *   steps, "11:45 AM") · place (a code at this campus, or blank) · needed (1–99, or nolimit) ·
 *   rule (none · 18 · 21 · certified) · note (the description, public)
 */
function ogc_shifts_clean_field( $y, $field, $value, $v ) {
	$bad = function ( $msg ) use ( $field ) {
		return new WP_Error( 'ogc_bad_field', $msg, array( 'status' => 400, 'field' => $field ) );
	};
	$value = is_scalar( $value ) ? trim( (string) $value ) : '';
	switch ( $field ) {
		case 'committee':
			$c = ogc_app_committee( (int) $y, ogc_committee_key( $value ) );
			if ( ! $c || 'coa' === $c['ckey'] ) {
				return $bad( 'Not a committee this year' );
			}
			if ( ! ogc_shifts_may( $v, $c['ckey'], 'shifts' ) ) {
				return $bad( ogc_shifts_poss( $c['name'] ) . ' · Ask the COA' );
			}
			return array( 'committee' => $c['name'] );
		case 'role':
			$t = mb_substr( preg_replace( '/\s+/', ' ', sanitize_text_field( $value ) ), 0, 61 );
			if ( '' === $t ) {
				return $bad( 'Name the job' );
			}
			if ( mb_strlen( $t ) > 60 ) {
				return $bad( '60 characters at most' );
			}
			return array( 'role' => $t );
		case 'date':
			foreach ( ogc_vol_days( (int) $y ) as $d ) {
				if ( $d['date'] === $value ) {
					return array( 'day' => $d['name'], 'last_day' => '' );
				}
			}
			return $bad( 'A day of the Conference' );
		case 'start':
		case 'end':
			if ( ! preg_match( '/^(\d{1,2})(?::(\d{2}))?\s*([AaPp])\.?\s*[Mm]?\.?$/', $value, $m ) || (int) $m[1] < 1 || (int) $m[1] > 12 || ( isset( $m[2] ) && '' !== $m[2] && (int) $m[2] > 59 ) ) {
				return $bad( 'A time, like 11:45 AM' );
			}
			$min = isset( $m[2] ) && '' !== $m[2] ? (int) $m[2] : 0;
			if ( $min % 5 ) {
				return $bad( '5-minute steps' );
			}
			return array( $field => (int) $m[1] . ':' . str_pad( (string) $min, 2, '0', STR_PAD_LEFT ) . ' ' . ( 'p' === strtolower( $m[3] ) ? 'PM' : 'AM' ) );
		case 'place':
			if ( '' === $value ) {
				return array( 'place' => '' );
			}
			$places = ogc_shifts_places( $y );
			if ( isset( $places[ strtoupper( $value ) ] ) ) {
				return array( 'place' => $places[ strtoupper( $value ) ]['code'] );
			}
			foreach ( $places as $p ) {
				if ( 0 === strcasecmp( $p['name'], $value ) ) {
					return array( 'place' => $p['code'] );
				}
			}
			return $bad( 'Not a place at this campus' );
		case 'needed':
			if ( 'nolimit' === strtolower( $value ) ) {
				return array( 'needed' => 'any' );
			}
			if ( ! preg_match( '/^\d{1,2}$/', $value ) || (int) $value < 1 ) {
				return $bad( 'A number, 1 to 99' );
			}
			return array( 'needed' => (string) (int) $value );
		case 'rule':
			$map = array( 'none' => '', '18' => '18 or older', '21' => '21 or older', 'certified' => 'Certified' );
			if ( ! isset( $map[ $value ] ) ) {
				return $bad( 'None, 18 or older, 21 or older, or Certified' );
			}
			return array( 'rule' => $map[ $value ], 'min_age' => '', 'question' => '' );
		case 'note':
			$t = sanitize_textarea_field( $value );
			if ( mb_strlen( $t ) > 600 ) {
				return $bad( '600 characters at most' );
			}
			return array( 'note' => $t );
	}
	return $bad( 'Not a field' );
}

/**
 * The shifts.csv row holding one shift, made its own row first when it's one day of a repeating row
 * (Saturday–Tuesday): that row becomes one row a day, each keeping the id it had (uid|date as the day's
 * uid), so the people on every day stay where they are. Returns array( rows, index ) or a WP_Error.
 */
function ogc_shifts_own_row( $y, $sh, $rows ) {
	$ri = (int) $sh['row'];
	if ( ! isset( $rows[ $ri ] ) || (string) ( isset( $rows[ $ri ]['role'] ) ? $rows[ $ri ]['role'] : '' ) !== $sh['role'] || (string) ( isset( $rows[ $ri ]['committee'] ) ? $rows[ $ri ]['committee'] : '' ) !== $sh['committee'] ) {
		return new WP_Error( 'ogc_conflict', 'Changed since it was opened · Reload', array( 'status' => 409 ) );
	}
	if ( ! empty( $sh['allweek'] ) ) {
		return array( $rows, $ri );
	}
	$days = ogc_vol_days( (int) $y );
	$row  = $rows[ $ri ];
	$a    = ogc_vol_find_day( $days, isset( $row['day'] ) ? $row['day'] : '' );
	$b    = ! empty( $row['last_day'] ) ? ogc_vol_find_day( $days, $row['last_day'] ) : $a;
	if ( $b < 0 ) {
		$b = count( $days ) - 1;
	}
	if ( $a < 0 || $a === $b ) {
		return array( $rows, $ri );
	}
	$uid   = isset( $row['uid'] ) ? (string) $row['uid'] : '';
	$taken = array();
	foreach ( $rows as $r ) {
		if ( ! empty( $r['_id'] ) ) {
			$taken[ $r['_id'] ] = true;
		}
	}
	$new  = array();
	$keep = 0;
	for ( $i = $a; $i <= $b; $i++ ) {
		$r             = $row;
		$r['day']      = $days[ $i ]['name'];
		$r['last_day'] = '';
		// The id this day already had (ogc_vol_shifts): uid|date, or an old file's committee|role|day|start.
		$r['uid'] = '' !== $uid ? $uid . '|' . $days[ $i ]['date'] : preg_replace( '/[^a-z0-9|]+/', '-', strtolower( implode( '|', array( $row['committee'], $row['role'], $days[ $i ]['key'], $row['start'] ) ) ) );
		if ( $i > $a && ! empty( $row['_id'] ) && function_exists( 'ogc_ed_new_id' ) ) {
			$r['_id']           = ogc_ed_new_id( $taken );
			$taken[ $r['_id'] ] = true;
		}
		if ( $days[ $i ]['date'] === $sh['date'] ) {
			$keep = $i - $a;
		}
		$new[] = $r;
	}
	array_splice( $rows, $ri, 1, $new );
	return array( $rows, $ri + $keep );
}

/** shifts.csv written back (only if nobody saved in between), then what follows a change: the people on a
 * shift whose day, time or place changed are told, a removed shift's are told (ogc_file_saved). */
function ogc_shifts_put( $y, $rows, $version, $why ) {
	$cur = ogc_file_get( (int) $y, 'shifts' );
	$ver = ogc_file_put( (int) $y, 'shifts', array_values( $rows ), (int) $version, $cur ? $cur['cols'] : null );
	if ( is_wp_error( $ver ) ) {
		return $ver;
	}
	ogc_log( 'shifts_' . $why['act'], (int) $y, 'shifts', array_merge( array( 'version' => $ver ), $why ) );
	do_action( 'ogc_file_saved', (int) $y, 'shifts', $ver );
	return $ver;
}

/**
 * POST app/{y}/shifts/save
 *   { id, field, value }       one field of one shift (Job, Day, Start, End, Place, Needed, Rule, Committee,
 *                              Description), saved when it's left; the server's reason at the field
 *   { id: 'new', fields: {} }  Add shift: committee, role, date, start, end, place, needed, rule. Added after
 *                              Publish it waits as Not public (draft) until Publish changes; from the
 *                              Conference's first day it's public at once (R6).
 */
function ogc_shifts_rest_save( WP_REST_Request $req ) {
	$y  = (int) $req['year'];
	$v  = ogc_app_req_viewer( $req );
	$id = (string) $req->get_param( 'id' );
	if ( ! ogc_vol_days( $y ) ) {
		return new WP_Error( 'ogc_no_dates', 'No dates yet · Dates and place', array( 'status' => 400 ) );
	}
	$f    = ogc_file_get( $y, 'shifts' );
	$rows = $f ? array_values( $f['rows'] ) : array();
	$ver  = $f ? (int) $f['version'] : 0;
	if ( 'new' === $id ) {
		$in  = (array) $req->get_param( 'fields' );
		$row = array( 'committee' => '', 'role' => '', 'day' => '', 'last_day' => '', 'start' => '', 'end' => '', 'needed' => '', 'place' => '', 'note' => '', 'rule' => '' );
		$errs = array();
		foreach ( array( 'committee', 'role', 'date', 'start', 'end', 'place', 'needed', 'rule' ) as $k ) {
			$val = isset( $in[ $k ] ) ? $in[ $k ] : ( 'rule' === $k ? 'none' : '' );
			if ( 'place' !== $k && '' === trim( (string) $val ) ) {
				$errs[ $k ] = array( 'committee' => 'Choose the committee', 'role' => 'Name the job', 'date' => 'Choose the day', 'start' => 'A time, like 11:45 AM', 'end' => 'A time, like 2:15 PM', 'needed' => 'A number, 1 to 99' )[ $k ];
				continue;
			}
			$c = ogc_shifts_clean_field( $y, $k, $val, $v );
			if ( is_wp_error( $c ) ) {
				$errs[ $k ] = $c->get_error_message();
				continue;
			}
			$row = array_merge( $row, $c );
		}
		if ( ! $errs && ogc_vol_parse_time( $row['start'] ) === ogc_vol_parse_time( $row['end'] ) ) {
			$errs['end'] = 'After the start';
		}
		if ( $errs ) {
			return new WP_Error( 'ogc_bad_field', reset( $errs ), array( 'status' => 400, 'fields' => $errs ) );
		}
		$days  = ogc_vol_days( $y );
		$begun = ogc_vol_wall( $y )['date'] >= $days[0]['date'];
		if ( ogc_vol_posted( $y ) && ! $begun ) {
			$row['draft'] = 'yes';
		}
		$rows[] = $row;
		$put    = ogc_shifts_put( $y, $rows, $ver, array( 'act' => 'add', 'committee' => ogc_committee_key( $row['committee'] ) ) );
		if ( is_wp_error( $put ) ) {
			return $put;
		}
		$all = ogc_vol_shifts( $y, true );
		$nid = '';
		foreach ( $all as $sid => $sh ) {
			if ( (int) $sh['row'] === count( $rows ) - 1 ) {
				$nid = $sid;
			}
		}
		return rest_ensure_response( array( 'id' => $nid, 'draft' => ! empty( $row['draft'] ) ) );
	}
	$all = ogc_vol_shifts( $y, true );
	if ( ! isset( $all[ $id ] ) ) {
		return new WP_Error( 'ogc_not_found', 'Not found · Reload', array( 'status' => 404 ) );
	}
	$sh = $all[ $id ];
	if ( ! ogc_shifts_may( $v, ogc_committee_key( $sh['committee'] ), 'shifts' ) ) {
		return new WP_Error( 'ogc_not_yours', ogc_shifts_poss( $sh['committee'] ) . ' · Its own committee or the COA', array( 'status' => 403 ) );
	}
	$field = (string) $req->get_param( 'field' );
	if ( ! empty( $sh['allweek'] ) && in_array( $field, array( 'date', 'start', 'end' ), true ) ) {
		return new WP_Error( 'ogc_bad_field', 'All week · No times', array( 'status' => 400, 'field' => $field ) );
	}
	$c = ogc_shifts_clean_field( $y, $field, $req->get_param( 'value' ), $v );
	if ( is_wp_error( $c ) ) {
		return $c;
	}
	$own = ogc_shifts_own_row( $y, $sh, $rows );
	if ( is_wp_error( $own ) ) {
		return $own;
	}
	list( $rows, $ri ) = $own;
	$was = $rows[ $ri ];
	$rows[ $ri ] = array_merge( $rows[ $ri ], $c );
	if ( in_array( $field, array( 'start', 'end' ), true ) && ogc_vol_parse_time( $rows[ $ri ]['start'] ) === ogc_vol_parse_time( $rows[ $ri ]['end'] ) ) {
		return new WP_Error( 'ogc_bad_field', 'start' === $field ? 'Before the end' : 'After the start', array( 'status' => 400, 'field' => $field ) );
	}
	if ( $rows[ $ri ] === $was ) {
		return rest_ensure_response( array( 'id' => $id, 'same' => true ) );
	}
	$put = ogc_shifts_put( $y, $rows, $ver, array( 'act' => 'change', 'id' => $id, 'field' => $field, 'committee' => ogc_committee_key( $sh['committee'] ) ) );
	if ( is_wp_error( $put ) ) {
		return $put;
	}
	$map = ogc_vol_seat_map( $y );
	$n   = isset( $map[ $id ] ) ? count( $map[ $id ] ) : 0;
	return rest_ensure_response( array( 'id' => $id, 'told' => in_array( $field, array( 'date', 'start', 'end', 'place' ), true ) && ogc_vol_posted( $y ) ? $n : 0 ) );
}

/** POST app/{y}/shifts/remove { id }: the shift goes; the people on it are told, as a removed shift's always
 * were (ogc_vol_shifts_changed). The client asks first. */
function ogc_shifts_rest_remove( WP_REST_Request $req ) {
	$y   = (int) $req['year'];
	$v   = ogc_app_req_viewer( $req );
	$id  = (string) $req->get_param( 'id' );
	$all = ogc_vol_shifts( $y, true );
	if ( ! isset( $all[ $id ] ) ) {
		return new WP_Error( 'ogc_not_found', 'Not found · Reload', array( 'status' => 404 ) );
	}
	$sh = $all[ $id ];
	if ( ! ogc_shifts_may( $v, ogc_committee_key( $sh['committee'] ), 'shifts' ) ) {
		return new WP_Error( 'ogc_not_yours', ogc_shifts_poss( $sh['committee'] ) . ' · Its own committee or the COA', array( 'status' => 403 ) );
	}
	$f   = ogc_file_get( $y, 'shifts' );
	$own = ogc_shifts_own_row( $y, $sh, array_values( $f['rows'] ) );
	if ( is_wp_error( $own ) ) {
		return $own;
	}
	list( $rows, $ri ) = $own;
	$map = ogc_vol_seat_map( $y );
	$n   = isset( $map[ $id ] ) ? count( $map[ $id ] ) : 0;
	array_splice( $rows, $ri, 1 );
	$put = ogc_shifts_put( $y, $rows, (int) $f['version'], array( 'act' => 'remove', 'id' => $id, 'committee' => ogc_committee_key( $sh['committee'] ) ) );
	return is_wp_error( $put ) ? $put : rest_ensure_response( array( 'removed' => $id, 'people' => $n ) );
}

/**
 * POST app/{y}/shifts/publish { act }: the holder's and the COA's (the grants).
 *   publish   sign-ups public today (settings signups_posted), every shift with it
 *   changes   the shifts added since (draft) public
 *   close · reopen   Join stops on the public page, or starts again; people keep their places
 * The year's own Publish (module-coa.php, part helping) does the setting, the stamp and the log.
 */
function ogc_shifts_rest_publish( WP_REST_Request $req ) {
	$y   = (int) $req['year'];
	$v   = ogc_app_req_viewer( $req );
	$act = (string) $req->get_param( 'act' );
	if ( ! ogc_shifts_may( $v, '', 'publish' ) ) {
		return new WP_Error( 'ogc_not_yours', 'The COA’s · Or whoever runs Shifts', array( 'status' => 403 ) );
	}
	if ( ! in_array( $act, array( 'publish', 'changes', 'close', 'reopen' ), true ) ) {
		return new WP_Error( 'ogc_bad_act', 'Not an action.', array( 'status' => 400 ) );
	}
	$n = 0;
	if ( in_array( $act, array( 'publish', 'changes' ), true ) ) {
		$f    = ogc_file_get( $y, 'shifts' );
		$rows = $f ? array_values( $f['rows'] ) : array();
		foreach ( $rows as &$r ) {
			if ( ! empty( $r['draft'] ) ) {
				$r['draft'] = '';
				$n++;
			}
		}
		unset( $r );
		if ( $n ) {
			$put = ogc_shifts_put( $y, $rows, (int) $f['version'], array( 'act' => 'publish_changes', 'n' => $n ) );
			if ( is_wp_error( $put ) ) {
				return $put;
			}
		}
		if ( 'changes' === $act ) {
			return rest_ensure_response( array( 'act' => $act, 'n' => $n ) );
		}
	}
	if ( ! function_exists( 'ogc_coa_rest_publish' ) ) {
		return new WP_Error( 'ogc_not_found', 'Not found.', array( 'status' => 404 ) );
	}
	$r = new WP_REST_Request( 'POST', '/' . OGC_NS . '/coa/' . $y . '/publish' );
	$r->set_url_params( array( 'year' => (string) $y ) );
	$r->set_param( 'year', (string) $y );
	$r->set_param( 'part', 'helping' );
	$r->set_param( 'act', $act );
	$res = ogc_coa_rest_publish( $r );
	if ( is_wp_error( $res ) ) {
		return $res;
	}
	return rest_ensure_response( array( 'act' => $act, 'n' => $n ) );
}

/** POST app/{y}/shifts/check { c, undo? }: "From 2026 · Looks right" on a committee's carried shifts (R28):
 * its own people, the holder and the COA. */
function ogc_shifts_rest_check( WP_REST_Request $req ) {
	$y = (int) $req['year'];
	$v = ogc_app_req_viewer( $req );
	$k = ogc_committee_key( (string) $req->get_param( 'c' ) );
	if ( '' === $k || ! ogc_app_committee( $y, $k ) || ! ogc_shifts_may( $v, $k, 'shifts' ) ) {
		return ogc_rest_denied();
	}
	$st  = ogc_state_get( $y, 'shifts-checked' );
	$val = $st ? (array) $st['value'] : array();
	if ( $req->get_param( 'undo' ) ) {
		unset( $val[ $k ] );
	} else {
		$val[ $k ] = array( 'by' => ogc_shifts_me(), 'on' => ogc_vol_wall( $y )['date'] );
	}
	ogc_state_put( $y, 'shifts-checked', $val );
	ogc_log( 'shifts_check', $y, 'shifts', array( 'c' => $k, 'undo' => (bool) $req->get_param( 'undo' ) ) );
	return rest_ensure_response( array( 'c' => $k, 'checked' => isset( $val[ $k ] ) ? $val[ $k ] : null ) );
}

/** POST app/{y}/shifts/called { rid, undo? }: To call's Called, stamped with who and when; a later change
 * to their shift puts them back. Their own committee and the COA. */
function ogc_shifts_rest_called( WP_REST_Request $req ) {
	$y   = (int) $req['year'];
	$v   = ogc_app_req_viewer( $req );
	$rid = (int) $req->get_param( 'rid' );
	$rec = ogc_record_get( $rid );
	$all = ogc_vol_shifts( $y );
	if ( ! $rec || 'signups' !== $rec['kind'] || (int) $rec['year'] !== $y || ! isset( $all[ $rec['data']['id'] ] ) ) {
		return new WP_Error( 'ogc_not_found', 'Not found', array( 'status' => 404 ) );
	}
	$sh = $all[ $rec['data']['id'] ];
	if ( ! ogc_shifts_may( $v, ogc_committee_key( $sh['committee'] ), 'head' ) ) {
		return ogc_rest_denied();
	}
	$snap = ogc_state_get( $y, 'vol-snap' );
	$seq  = $snap && isset( $snap['value'][ $sh['id'] ]['seq'] ) ? (int) $snap['value'][ $sh['id'] ]['seq'] : 0;
	$st   = ogc_state_get( $y, 'shifts-called' );
	$val  = $st ? (array) $st['value'] : array();
	if ( $req->get_param( 'undo' ) ) {
		unset( $val[ $rid ] );
	} else {
		$val[ $rid ] = array( 'by' => ogc_shifts_me(), 'on' => ogc_vol_wall( $y )['date'], 'seq' => $seq );
	}
	ogc_state_put( $y, 'shifts-called', $val );
	return rest_ensure_response( array( 'rid' => $rid, 'called' => isset( $val[ $rid ] ) ? $val[ $rid ] : null ) );
}

/** GET app/{y}/shifts/phone?rid=: the one person's phone for the holder's Move ask (the grants' "a phone
 * only on the person being moved"), logged. Their own committee and the COA see it anyway. */
function ogc_shifts_rest_phone( WP_REST_Request $req ) {
	$y   = (int) $req['year'];
	$v   = ogc_app_req_viewer( $req );
	$rec = ogc_record_get( (int) $req->get_param( 'rid' ) );
	$all = ogc_vol_shifts( $y );
	if ( ! $rec || 'signups' !== $rec['kind'] || (int) $rec['year'] !== $y || ! isset( $all[ $rec['data']['id'] ] ) ) {
		return new WP_Error( 'ogc_not_found', 'Not found', array( 'status' => 404 ) );
	}
	$k = ogc_committee_key( $all[ $rec['data']['id'] ]['committee'] );
	if ( ! ogc_shifts_may( $v, $k, 'phones' ) && ! ogc_shifts_may( $v, $k, 'phone_acted' ) ) {
		return ogc_rest_denied();
	}
	// "A phone only on the person being moved" is the holder's grant; the server can't see the Move, so
	// it can't be a way to read every committee's phones one by one (security pass, Oct 18). Its own
	// committee and the COA see the phone on the list anyway; anyone else here gets a few a day.
	if ( ! ogc_shifts_may( $v, $k, 'phones' ) ) {
		$per = (int) apply_filters( 'ogc_shifts_phone_per_day', 15 );
		if ( ogc_throttle( 'shp:' . get_current_user_id() . ':' . $y, max( 1, $per ), DAY_IN_SECONDS ) ) {
			return new WP_Error( 'ogc_rate', 'Too many phones today · Ask the committee’s head', array( 'status' => 429 ) );
		}
	}
	$p = ogc_vol_lead_person( $rec );
	ogc_log( 'shifts_phone_shown', $y, 'signups', array( 'id' => (int) $rec['id'], 'c' => $k, 'why' => 'move' ) );
	return rest_ensure_response( array( 'rid' => (int) $rec['id'], 'name' => $p['name'], 'phone' => $p['phone'] ) );
}

/* ================================================================== not public until Publish changes */

// The public never reads a draft shift (the page lists the rows it's given; members see them all).
add_filter( 'ogc_file_rows_out', function ( $rows, $year, $name, $member ) {
	if ( 'shifts' !== $name || $member ) {
		return $rows;
	}
	return array_values( array_filter( (array) $rows, function ( $r ) {
		return 'yes' !== ( isset( $r['draft'] ) ? (string) $r['draft'] : '' );
	} ) );
}, 16, 4 );

/* ================================================================== the samples: A/V runs Shifts */

/**
 * The walk-through's handing (Round 4): the COA handed Shifts to A/V, in 2027 as in 2026 (so Who runs
 * what's "Same as 2026" has nothing to change), the way it handed Intake. Local samples only; once on a
 * site seeded before (the main site), and after 2027's seed reloads (Start over).
 */
function ogc_shifts_seed_handing() {
	global $wpdb;
	if ( ! function_exists( 'ogc_seed_samples' ) || ! ogc_seed_samples() || ! function_exists( 'ogc_app_tables_ready' ) || ! ogc_app_tables_ready() ) {
		return false;
	}
	$done = false;
	foreach ( array( 2026, 2027 ) as $yr ) {
		$av = ogc_app_committee( $yr, 'a/v' );
		if ( ! $av ) {
			continue;
		}
		$done = true;
		if ( '' === ogc_app_handed_to( $yr, 'shifts' ) ) {
			$wpdb->update( ogc_table( 'committees' ), array( 'screens' => implode( ',', array_merge( $av['screens'], array( 'shifts' ) ) ), 'updated_at' => ogc_now() ), array( 'id' => (int) $av['id'] ) );
			ogc_app_committees( $yr, true );
			if ( 2027 === $yr && function_exists( 'ogc_app_move_screen_tasks' ) ) {
				ogc_app_move_screen_tasks( $yr, 'shifts', 'a/v' );
			}
		}
	}
	return $done;
}
add_action( 'init', function () {
	if ( OGC_DEV && '1' !== get_option( 'ogc_shifts_seed_handing' ) && ogc_shifts_seed_handing() ) {
		update_option( 'ogc_shifts_seed_handing', '1', false );
	}
}, 49 );
add_action( 'ogc_seed_year', function ( $year ) {
	if ( 2027 === (int) $year ) {
		ogc_shifts_seed_handing();
	}
}, 31 );
