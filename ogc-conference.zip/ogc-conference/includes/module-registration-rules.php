<?php
/**
 * Registration rules (register area): the year's registration settings, its dates, the nights and
 * meals, what a household's answers may be, what they cost, and what's left.
 *
 * The server is the only judge of a registration: the form shows the same rules for speed
 * (assets/register/register.js mirrors ogc_reg_clean and ogc_reg_price), but what is saved, and what
 * anyone pays, comes from here. Amounts are whole cents.
 *
 * The answers a household gives (the record's data) keep v3's shape, so Lodging and the lists read
 * them unchanged (household, people, stay, meals, communion, preteens, contacts, pickup, gift, pay);
 * each person also has a lasting id (pid), so a medical note or a meal answer stays with its person.
 */

defined( 'ABSPATH' ) || exit;

/* ================================================================== settings and dates */

/** A key/value file of the year (registration, settings) as an array. */
function ogc_reg_kv( $year, $name ) {
	$f   = ogc_file_get( (int) $year, $name );
	$out = array();
	foreach ( $f ? $f['rows'] : array() as $r ) {
		if ( isset( $r['key'] ) && '' !== $r['key'] && '#' !== substr( $r['key'], 0, 1 ) ) {
			$out[ trim( $r['key'] ) ] = isset( $r['value'] ) ? trim( (string) $r['value'] ) : '';
		}
	}
	return $out;
}

/** The year's registration settings (registration.csv), with the dates read from one place: its own
 * opens and closes, or the year page's registration_opens / _closes when it has none. */
function ogc_reg_cfg( $year ) {
	static $cache = array();
	if ( ! isset( $cache[ $year ] ) || ! empty( $GLOBALS['ogc_reg_cfg_stale'] ) ) {
		unset( $GLOBALS['ogc_reg_cfg_stale'] );
		$c = ogc_reg_kv( $year, 'registration' );
		$s = ogc_reg_kv( $year, 'settings' );
		foreach ( array( 'opens', 'closes' ) as $k ) {
			if ( empty( $c[ $k ] ) && ! empty( $s[ 'registration_' . $k ] ) ) {
				$c[ $k ] = $s[ 'registration_' . $k ];
			}
		}
		$cache[ $year ] = $c;
	}
	return $cache[ $year ];
}

function ogc_reg_settings( $year ) {
	return ogc_reg_kv( $year, 'settings' );
}

function ogc_reg_c( $cfg, $k, $default = '' ) {
	return isset( $cfg[ $k ] ) && '' !== $cfg[ $k ] ? $cfg[ $k ] : $default;
}

/** A setting in dollars, as cents. */
function ogc_reg_cents( $cfg, $k ) {
	$v = ogc_reg_c( $cfg, $k, '0' );
	return is_numeric( $v ) ? (int) round( (float) $v * 100 ) : 0;
}

/** A local dev site (OGC_DEV and a local address): never a staging copy with OGC_DEV left on. Every
 * dev-only thing in this area (the walk-through's code pill, Reuse from samples, opening with samples,
 * the test payment driver, as_of on writes) asks this. */
function ogc_reg_local() {
	return OGC_DEV && function_exists( 'ogc_is_local_host' ) && ogc_is_local_host();
}

function ogc_reg_tz( $year ) {
	$s = ogc_reg_settings( $year );
	$z = ogc_reg_c( $s, 'timezone', 'America/Indiana/Indianapolis' );
	try {
		return new DateTimeZone( $z );
	} catch ( Exception $e ) {
		return new DateTimeZone( 'America/Indiana/Indianapolis' );
	}
}

/** Today at the venue (YYYY-MM-DD). The Conference page's preview date (?as-of=) is honoured for a
 * year's members on a read only (a preview: GET), so a member can see the form as it will be; a write
 * (Register, Change, Leave early) always uses the real date, so it can't get around closes or refunds_by.
 * On a local dev site it's honoured on writes too, for the walk-through. Never for a Conference already
 * over (Oct 16): its registration doesn't open again by a preview. */
function ogc_reg_today( $year, $req = null ) {
	$as = $req instanceof WP_REST_Request ? (string) $req->get_param( 'as_of' ) : '';
	if ( preg_match( '/^\d{4}-\d\d-\d\d/', $as ) && ! ( function_exists( 'ogc_pub_over' ) && ogc_pub_over( $year ) ) ) {
		$local = ogc_reg_local();
		$read  = in_array( $req->get_method(), array( 'GET', 'HEAD' ), true );
		if ( $local || ( $read && ogc_is_member( $year ) ) ) {
			return substr( $as, 0, 10 );
		}
	}
	$d = new DateTime( 'now', ogc_reg_tz( $year ) );
	return $d->format( 'Y-m-d' );
}

function ogc_reg_add_days( $iso, $n ) {
	$d = DateTime::createFromFormat( '!Y-m-d', $iso, new DateTimeZone( 'UTC' ) );
	if ( ! $d ) {
		return '';
	}
	$d->modify( ( $n >= 0 ? '+' : '' ) . (int) $n . ' days' );
	return $d->format( 'Y-m-d' );
}

/** The Conference's days: array( array( name, date ) ), from the year's settings (first_day, days). */
function ogc_reg_days( $year ) {
	$s     = ogc_reg_settings( $year );
	$row   = ogc_year_get( $year );
	$first = ogc_reg_c( $s, 'first_day', $row ? (string) ( isset( $row['start'] ) ? $row['start'] : '' ) : '' );
	if ( ! preg_match( '/^\d{4}-\d\d-\d\d$/', $first ) ) {
		return array();
	}
	$names = array_values( array_filter( array_map( 'trim', explode( '|', ogc_reg_c( $s, 'days', 'Friday|Saturday|Sunday|Monday|Tuesday|Wednesday' ) ) ) ) );
	$out   = array();
	foreach ( $names as $i => $n ) {
		$out[] = array( 'name' => $n, 'date' => ogc_reg_add_days( $first, $i ) );
	}
	return $out;
}

/** The nights offered: early ones first ("Early Thursday"), then the Conference's (as v3: SU.nightsOf). */
function ogc_reg_nights( $cfg ) {
	$early = array_values( array_filter( array_map( 'trim', explode( '|', ogc_reg_c( $cfg, 'early_nights' ) ) ) ) );
	$main  = array_values( array_filter( array_map( 'trim', explode( '|', ogc_reg_c( $cfg, 'nights' ) ) ) ) );
	return array_merge( array_map( function ( $n ) { return 'Early ' . $n; }, $early ), $main );
}

function ogc_reg_is_early( $n ) {
	return 0 === strpos( (string) $n, 'Early ' );
}

function ogc_reg_main_nights( $cfg ) {
	return array_values( array_filter( ogc_reg_nights( $cfg ), function ( $n ) { return ! ogc_reg_is_early( $n ); } ) );
}

/** The index of a night's day among the Conference's days (by the first three letters), or -1. */
function ogc_reg_day_index( $days, $name ) {
	$k = strtolower( substr( trim( (string) $name ), 0, 3 ) );
	foreach ( $days as $i => $d ) {
		if ( strtolower( substr( $d['name'], 0, 3 ) ) === $k || $d['date'] === $name ) {
			return $i;
		}
	}
	return -1;
}

/** A night's date: a Conference night's day, or an early night's (the last day of that name before the first). */
function ogc_reg_night_date( $days, $n ) {
	if ( ! $days ) {
		return '';
	}
	if ( ogc_reg_is_early( $n ) ) {
		$want = strtolower( substr( $n, 6 ) );
		for ( $k = 1; $k < 7; $k++ ) {
			$d = ogc_reg_add_days( $days[0]['date'], -$k );
			if ( strtolower( gmdate( 'l', strtotime( $d . ' 00:00:00 UTC' ) ) ) === $want ) {
				return $d;
			}
		}
		return '';
	}
	$i = ogc_reg_day_index( $days, $n );
	return $i < 0 ? '' : $days[ $i ]['date'];
}

/**
 * Where registration stands for the year, from one source (registration.csv's opens and closes):
 *   none    not posted (no opening date, or the COA hasn't marked it ready: registration.csv ready ≠ yes)
 *   before  posted, not open yet
 *   open    open online
 *   closed  closed online; registering at check-in until the Conference ends
 *   held    the Conference is over
 */
function ogc_reg_phase( $year, $today ) {
	$c   = ogc_reg_cfg( $year );
	$row = ogc_year_get( $year );
	$end = $row && ! empty( $row['end'] ) ? $row['end'] : '';
	if ( $end && $today > $end ) {
		return 'held';
	}
	// One rule with the Conference page and the app (ogc_pub_reg): the form opens only when the COA chose
	// this site's form and scheduled its dates. A date carried from last year that nobody scheduled, or
	// another tool, keeps it shut (review, Oct 11: the form took registrations at 2026's prices).
	if ( function_exists( 'ogc_pub_reg' ) ) {
		$pub = ogc_pub_reg( $year );
		if ( 'site' !== $pub['mode'] || '' === $pub['opens'] ) {
			return 'none';
		}
		$c['opens']  = $pub['opens'];
		$c['closes'] = '' !== $pub['closes'] ? $pub['closes'] : ( isset( $c['closes'] ) ? $c['closes'] : '' );
		if ( '' !== $pub['closed'] && $pub['closed'] <= $today && $today >= $c['opens'] ) {
			return 'closed';
		}
	}
	if ( empty( $c['opens'] ) || ( array_key_exists( 'ready', $c ) && 'yes' !== strtolower( $c['ready'] ) ) ) {
		return 'none';
	}
	if ( $today < $c['opens'] ) {
		return 'before';
	}
	if ( ! empty( $c['closes'] ) && $today > $c['closes'] ) {
		return 'closed';
	}
	return 'open';
}

/* ================================================================== meals */

/** "Supper" → supper; a meal named otherwise keeps its own name as the key. */
function ogc_reg_meal_kind( $title ) {
	if ( preg_match( '/^\s*(breakfast|lunch|supper|dinner)/i', (string) $title, $m ) ) {
		$k = strtolower( $m[1] );
		return 'dinner' === $k ? 'supper' : $k;
	}
	return sanitize_title( (string) $title );
}

/**
 * The year's meals for the whole Conference, from the schedule (meal rows for everyone or the
 * Conference, with a time): array( key, date, title ). The key is the day's date and the meal
 * ("2027-05-30:supper"), so editing the schedule never moves a household's meal answers. The same
 * key is made in ogc-signups.js (SU.mealsOf).
 */
function ogc_reg_meals( $year ) {
	static $cache = array();
	if ( isset( $cache[ $year ] ) ) {
		return $cache[ $year ];
	}
	$days = ogc_reg_days( $year );
	$f    = ogc_file_get( (int) $year, 'schedule' );
	$out  = array();
	$seen = array();
	foreach ( $f ? $f['rows'] : array() as $r ) {
		if ( empty( $r['title'] ) || 'meal' !== strtolower( trim( isset( $r['kind'] ) ? $r['kind'] : '' ) ) || '' === trim( isset( $r['start'] ) ? $r['start'] : '' ) ) {
			continue;
		}
		$aud = strtolower( trim( isset( $r['audience'] ) ? $r['audience'] : '' ) );
		if ( 0 === strpos( $aud, 'pre' ) || 0 === strpos( $aud, 'young' ) || 'yf' === $aud || 'yfs' === $aud ) {
			continue;
		}
		$a = ogc_reg_day_index( $days, isset( $r['day'] ) ? $r['day'] : '' );
		$b = ! empty( $r['last_day'] ) ? ogc_reg_day_index( $days, $r['last_day'] ) : $a;
		if ( $a < 0 || $b < 0 ) {
			continue;
		}
		for ( $i = $a; $i <= $b; $i++ ) {
			$key = $days[ $i ]['date'] . ':' . ogc_reg_meal_kind( $r['title'] );
			$n   = isset( $seen[ $key ] ) ? ++$seen[ $key ] : ( $seen[ $key ] = 1 );
			$out[] = array( 'key' => $n > 1 ? $key . '-' . $n : $key, 'date' => $days[ $i ]['date'], 'title' => $r['title'] );
		}
	}
	usort( $out, function ( $x, $y ) { return strcmp( $x['date'], $y['date'] ); } );
	return $cache[ $year ] = $out;
}

/* ================================================================== the household's answers */

function ogc_reg_str( $v, $max = 80 ) {
	return mb_substr( trim( sanitize_text_field( is_scalar( $v ) ? (string) $v : '' ) ), 0, $max );
}

function ogc_reg_note( $v, $max = 500 ) {
	return mb_substr( trim( sanitize_textarea_field( is_scalar( $v ) ? (string) $v : '' ) ), 0, $max );
}

function ogc_reg_bool( $v ) {
	return true === $v || 1 === $v || '1' === $v || 'true' === $v || 'yes' === $v;
}

function ogc_reg_email_ok( $e ) {
	return '' !== $e && (bool) is_email( $e );
}

function ogc_reg_new_pid() {
	return 'p' . strtolower( wp_generate_password( 8, false, false ) );
}

/** A person's age groups, as the committees count them (v3): adult 12 and up, child 3–11, baby under 3. */
function ogc_reg_band( $p ) {
	if ( 'child' !== $p['kind'] ) {
		return 'adult';
	}
	if ( '' === $p['age'] ) {
		return 'child';
	}
	$a = (int) $p['age'];
	return $a < 3 ? 'baby' : ( $a <= 11 ? 'child' : 'adult' );
}

/** A person's nights: their own when not everyone is here every night, else the household's; a Young
 * Folk in the halls whose household isn't on campus has the Conference's nights (v3: SU.nightsFor). */
function ogc_reg_nights_for( $p, $d, $cfg ) {
	if ( ! empty( $p['nights'] ) ) {
		return $p['nights'];
	}
	if ( ! empty( $d['stay']['nights'] ) ) {
		return $d['stay']['nights'];
	}
	return ! empty( $p['yf'] ) ? ogc_reg_main_nights( $cfg ) : array();
}

/** Is this Young Folk in the Young Folks' halls (not with their family)? */
function ogc_reg_in_hall( $p, $d ) {
	return ! empty( $p['yf'] ) && ( 'yf' === $d['stay']['type'] || 'family' !== $p['sleeps'] );
}

/** The days a person is on campus (dates): their first night's day through the morning after their
 * last; an early night brings them from the first day; a household off campus, the days it chose. */
function ogc_reg_person_days( $p, $d, $cfg, $days ) {
	$off_campus = 'elsewhere' === $d['stay']['type'] && ! ogc_reg_in_hall( $p, $d );
	if ( $off_campus ) {
		return array_values( array_intersect( wp_list_pluck( $days, 'date' ), (array) $d['stay']['days'] ) );
	}
	$all   = ogc_reg_nights_for( $p, $d, $cfg );
	$main  = array_values( array_filter( $all, function ( $n ) { return ! ogc_reg_is_early( $n ); } ) );
	$early = count( $all ) > count( $main );
	if ( ! $main ) {
		return $early && $days ? array( $days[0]['date'] ) : array();
	}
	$a = $early ? 0 : ogc_reg_day_index( $days, $main[0] );
	$b = ogc_reg_day_index( $days, $main[ count( $main ) - 1 ] );
	if ( $a < 0 || $b < 0 ) {
		return array();
	}
	return wp_list_pluck( array_slice( $days, $a, $b - $a + 2 ), 'date' );
}

/** The people sleeping in the household's own rooms (or camper): not babies, not Young Folks in their halls. */
function ogc_reg_sleepers( $d ) {
	return array_values( array_filter( $d['people'], function ( $p ) use ( $d ) {
		return 'baby' !== $p['band'] && ! ogc_reg_in_hall( $p, $d );
	} ) );
}

/**
 * Who sleeps where, for anyone the form didn't place (samples, imports, older records), as the form's
 * placeRooms does (rehearsal, Oct 28: the couple was split, Daniel and Lydia in Room 1, Esther and Micah in
 * Room 2): the grown-ups fill the rooms in order, a room's beds ($cap) at a time, so a couple shares; then
 * the others, in the order listed, in the rooms no grown-up is in (the fewest so far), then any room with a
 * bed free; past the beds, the room with the fewest. A baby has no room of its own (it sleeps where the
 * first grown-up does), and a Young Folk in a hall none. Mechanical: a default the household changes.
 */
function ogc_reg_place_rooms( &$d, $cap ) {
	$n     = max( 1, (int) $d['stay']['rooms'] );
	$cap   = max( 1, (int) $cap );
	$count = array_fill( 0, $n, 0 );
	$grown = array_fill( 0, $n, false );
	$todo  = array();
	foreach ( $d['people'] as $i => &$p ) {
		if ( 'baby' === $p['band'] || ogc_reg_in_hall( $p, $d ) ) {
			$p['room'] = null;
			continue;
		}
		if ( null === $p['room'] || $p['room'] >= $n ) {
			$p['room'] = null;
			$todo[]    = $i;
		} else {
			$count[ $p['room'] ]++;
			$grown[ $p['room'] ] = $grown[ $p['room'] ] || 'adult' === $p['kind'];
		}
	}
	unset( $p );
	$fewest = function ( $ok ) use ( &$count, $n ) {
		$r = -1;
		for ( $j = 0; $j < $n; $j++ ) {
			if ( $ok( $j ) && ( $r < 0 || $count[ $j ] < $count[ $r ] ) ) {
				$r = $j;
			}
		}
		return $r;
	};
	foreach ( array( true, false ) as $adults ) {
		foreach ( $todo as $i ) {
			if ( ( 'adult' === $d['people'][ $i ]['kind'] ) !== $adults ) {
				continue;
			}
			if ( $adults ) {
				// The first room with a bed free.
				$r = -1;
				for ( $j = 0; $j < $n && $r < 0; $j++ ) {
					if ( $count[ $j ] < $cap ) {
						$r = $j;
					}
				}
			} else {
				$r = $fewest( function ( $j ) use ( &$count, &$grown, $cap ) { return ! $grown[ $j ] && $count[ $j ] < $cap; } );
				if ( $r < 0 ) {
					$r = $fewest( function ( $j ) use ( &$count, $cap ) { return $count[ $j ] < $cap; } );
				}
			}
			if ( $r < 0 ) {
				$r = $fewest( function () { return true; } );
			}
			$d['people'][ $i ]['room'] = $r;
			$count[ $r ]++;
			$grown[ $r ] = $grown[ $r ] || $adults;
		}
	}
}

/**
 * The household's answers, cleaned: only what the form asks, each within its bounds, with the parts
 * that follow from them worked out (age groups, preteens, nights, rooms' nights, keys, meal counts,
 * the communion count). Nothing about money or status: the server adds those.
 */
function ogc_reg_clean( $in, $year ) {
	$cfg    = ogc_reg_cfg( $year );
	$in     = is_array( $in ) ? $in : array();
	$nights = ogc_reg_nights( $cfg );
	$days   = ogc_reg_days( $year );
	$g      = function ( $a, $k, $def = '' ) { return is_array( $a ) && isset( $a[ $k ] ) ? $a[ $k ] : $def; };

	$h = $g( $in, 'household', array() );
	$x = $g( $in, 'helper', array() );
	$d = array(
		'household' => array(
			'name'    => ogc_reg_str( $g( $h, 'name' ), 60 ),
			'contact' => ogc_reg_str( $g( $h, 'contact' ) ),
			'phone'   => ogc_reg_str( $g( $h, 'phone' ), 30 ),
			'email'   => strtolower( ogc_reg_str( $g( $h, 'email' ), 120 ) ),
		),
		'helper'    => array(
			'on'    => ogc_reg_bool( $g( $x, 'on' ) ),
			'name'  => ogc_reg_str( $g( $x, 'name' ) ),
			'phone' => ogc_reg_str( $g( $x, 'phone' ), 30 ),
			'email' => strtolower( ogc_reg_str( $g( $x, 'email' ), 120 ) ),
		),
	);
	if ( ! $d['helper']['on'] ) {
		$d['helper'] = array( 'on' => false, 'name' => '', 'phone' => '', 'email' => '' );
	}

	// People: named ones only, each with a lasting id. Up to 40 are read so that more than 20 is a
	// problem the form shows ("Up to 20"), never a silent cut.
	$people = array();
	$pids   = array();
	// Who may be ticked communing: grown-ups, Young Folks, and children from the COA's communing_age (10
	// when blank; 0 for none), as the form offers (Caleb, Oct 31: a member younger than the Young Folks).
	$cmin = trim( (string) ogc_reg_c( $cfg, 'communing_age', '' ) );
	$cmin = '' === $cmin ? 10 : (int) $cmin;
	foreach ( array_slice( (array) $g( $in, 'people', array() ), 0, 40 ) as $p ) {
		if ( ! is_array( $p ) ) {
			continue;
		}
		$name = ogc_reg_str( $g( $p, 'name' ) );
		if ( '' === $name ) {
			continue;
		}
		$pid = (string) $g( $p, 'pid' );
		if ( ! preg_match( '/^p[a-z0-9]{1,16}$/', $pid ) || isset( $pids[ $pid ] ) ) {
			$pid = ogc_reg_new_pid();
		}
		$pids[ $pid ] = true;
		$kind         = in_array( $g( $p, 'kind' ), array( 'adult', 'yf', 'child' ), true ) ? $g( $p, 'kind' ) : 'adult';
		$age          = preg_match( '/^\d{1,3}$/', trim( (string) $g( $p, 'age' ) ) ) ? (string) (int) $g( $p, 'age' ) : '';
		$q            = array(
			'pid'       => $pid,
			'name'      => $name,
			'kind'      => $kind,
			'age'       => 'adult' === $kind ? '' : $age,
			'yf'        => 'yf' === $kind,
			'yfHall'    => 'yf' === $kind && in_array( $g( $p, 'yfHall' ), array( 'men', 'women' ), true ) ? $g( $p, 'yfHall' ) : '',
			'minor'     => false,
			'ptOff'     => ogc_reg_bool( $g( $p, 'ptOff' ) ),
			'nights'    => array_values( array_intersect( $nights, (array) $g( $p, 'nights', array() ) ) ),
			'rooming'   => 'yf' === $kind ? ogc_reg_str( $g( $p, 'rooming' ), 80 ) : '',
			'sleeps'    => 'yf' === $kind && 'family' === $g( $p, 'sleeps' ) ? 'family' : 'hall',
			'linens'    => 'yf' === $kind && ogc_reg_bool( $g( $p, 'linens' ) ),
			'communing' => ( 'child' !== $kind || ( $cmin > 0 && '' !== $age && (int) $age >= $cmin ) ) && ogc_reg_bool( $g( $p, 'communing' ) ),
			'room'      => is_numeric( $g( $p, 'room', '' ) ) ? max( 0, min( 5, (int) $g( $p, 'room' ) ) ) : null,
			// Each person's own need boxes (Oct 23, docs/25 rule 1): an adult's Ground floor, No stairs and
			// Near a restroom; a crib for a child under 3. Kept for a dorm room only (below).
			'ground'    => 'adult' === $kind && ogc_reg_bool( $g( $p, 'ground' ) ),
			'walker'    => 'adult' === $kind && ogc_reg_bool( $g( $p, 'walker' ) ),
			'restroom'  => 'adult' === $kind && ogc_reg_bool( $g( $p, 'restroom' ) ),
			'crib'      => 'child' === $kind && ogc_reg_bool( $g( $p, 'crib' ) ),
		);
		$q['band']    = ogc_reg_band( $q );
		if ( 'baby' !== $q['band'] ) {
			$q['crib'] = false;
		}
		$a            = '' === $q['age'] ? -1 : (int) $q['age'];
		$q['preteen'] = 'child' === $kind && $a >= 10 && $a <= 13 && ! $q['ptOff'];
		if ( ! ( 'child' === $kind && $a >= 10 && $a <= 13 ) ) {
			$q['ptOff'] = false;
		}
		$q['minor'] = 'yf' === $kind && $a >= 0 && $a < 18;
		$people[]   = $q;
		if ( count( $people ) >= 40 ) {
			break;
		}
	}
	$d['people'] = $people;
	$adults      = array_values( array_filter( $people, function ( $p ) { return 'adult' === $p['kind']; } ) );
	$yf_only     = $people && count( array_filter( $people, function ( $p ) { return $p['yf']; } ) ) === count( $people );

	// Where they'll stay. Young Folks on their own: their hall, a camper or off campus (a local Young
	// Folk sleeping at home); a family: a dorm room, a camper or off campus.
	$s    = $g( $in, 'stay', array() );
	$type = in_array( $g( $s, 'type' ), array( 'dorm', 'camper', 'elsewhere', 'yf' ), true ) ? $g( $s, 'type' ) : 'dorm';
	if ( $yf_only && 'dorm' === $type ) {
		$type = 'yf';
	} elseif ( ! $yf_only && 'yf' === $type ) {
		$type = 'dorm';
	}
	$stay = array(
		'type'        => $type,
		'nights'      => array_values( array_intersect( $nights, (array) $g( $s, 'nights', array() ) ) ),
		'days'        => 'elsewhere' === $type ? array_values( array_intersect( wp_list_pluck( $days, 'date' ), (array) $g( $s, 'days', array() ) ) ) : array(),
		'perPerson'   => ogc_reg_bool( $g( $s, 'perPerson' ) ),
		'rooms'       => 'dorm' === $type ? max( 1, min( 6, (int) $g( $s, 'rooms', 1 ) ) ) : 0,
		'roomsSet'    => ogc_reg_bool( $g( $s, 'roomsSet' ) ),
		// The rooms' packets (a count). Each Young Folk in a hall has their own (people[].linens).
		'linens'      => 'dorm' === $type ? max( 0, min( 24, (int) $g( $s, 'linens', 0 ) ) ) : 0,
		// Linens are asked once for the household (polish 2): '' (not yet), own (bring our own), order
		// (packets, for the sleepers chosen: the rooms' by pid in linenFor, each hall Young Folk's own).
		'linenChoice' => in_array( $g( $s, 'linenChoice' ), array( 'own', 'order' ), true ) ? $g( $s, 'linenChoice' ) : '',
		'mattresses'  => 'dorm' === $type && ogc_reg_c( $cfg, 'mattress_price' ) ? max( 0, min( 6, (int) $g( $s, 'mattresses', 0 ) ) ) : 0,
		// The household's boxes, which Lodging filters by: its own, or any of its people's (Oct 23). The form's
		// two restroom boxes are one now (decision 20 A): restroom; nearW and nearM are kept for older records.
		'ground'      => 'dorm' === $type && ( ogc_reg_bool( $g( $s, 'ground' ) ) || in_array( true, wp_list_pluck( $people, 'ground' ), true ) ),
		'walker'      => 'dorm' === $type && ( ogc_reg_bool( $g( $s, 'walker' ) ) || in_array( true, wp_list_pluck( $people, 'walker' ), true ) ),
		'restroom'    => 'dorm' === $type && ( ogc_reg_bool( $g( $s, 'restroom' ) ) || in_array( true, wp_list_pluck( $people, 'restroom' ), true ) ),
		'nearW'       => 'dorm' === $type && ogc_reg_bool( $g( $s, 'nearW' ) ),
		'nearM'       => 'dorm' === $type && ogc_reg_bool( $g( $s, 'nearM' ) ),
		'near'        => in_array( $type, array( 'dorm', 'camper' ), true ) ? ogc_reg_str( $g( $s, 'near' ), 60 ) : '',
		'arrive'      => in_array( $g( $s, 'arrive' ), array( 'afternoon', 'evening', 'late' ), true ) && 'elsewhere' !== $type ? $g( $s, 'arrive' ) : '',
		'yfOk'        => ogc_reg_bool( $g( $s, 'yfOk' ) ),
		// A grown-up who isn't the parent (a grandmother) asks a parent by email instead.
		'ask'         => ogc_reg_bool( $g( $s, 'ask' ) ),
		'keys'        => array(),
		'needs'       => 'elsewhere' !== $type ? ogc_reg_note( $g( $s, 'needs' ) ) : '',
		'parentEmail' => strtolower( ogc_reg_str( $g( $s, 'parentEmail' ), 120 ) ),
		// Children with no grown-up on the registration, when the COA allows it: the household they're with.
		'withHh'      => ogc_reg_str( $g( $s, 'withHh' ), 80 ),
		'chosen'      => array_values( array_slice( array_filter( array_map( function ( $r ) { return ogc_reg_str( $r, 40 ); }, (array) $g( $s, 'chosen', array() ) ) ), 0, 6 ) ),
		'campers'     => 'camper' === $type ? max( 1, min( 4, (int) $g( $s, 'campers', 1 ) ) ) : 0,
		'camperLen'   => 'camper' === $type && in_array( $g( $s, 'camperLen' ), array( 'short', 'mid', 'long' ), true ) ? $g( $s, 'camperLen' ) : '',
	);
	if ( 'elsewhere' === $type ) {
		$stay['nights'] = array();
	}
	if ( $adults ) {
		$stay['withHh'] = '';
	}
	$d['stay'] = $stay;
	// A Young Folk sleeping "with family" only means something when the family has rooms or a camper.
	foreach ( $d['people'] as &$p ) {
		// The need boxes are for a dorm room (a camper or off campus has none to place).
		if ( 'dorm' !== $type ) {
			$p['ground']   = false;
			$p['walker']   = false;
			$p['restroom'] = false;
			$p['crib']     = false;
		}
		if ( $p['yf'] && 'yf' === $type ) {
			$p['sleeps'] = 'hall';
		} elseif ( $p['yf'] && $yf_only ) {
			$p['sleeps'] = 'family';   // on their own, in a camper or off campus: not in the hall
		}
		if ( ! ogc_reg_in_hall( $p, $d ) ) {
			$p['linens'] = false;
		}
		if ( ! $stay['perPerson'] || ( 'elsewhere' === $type && ! ogc_reg_in_hall( $p, $d ) ) ) {
			$p['nights'] = array();
		}
	}
	unset( $p );
	// Not everyone every night: the household's nights are every night one of its stayers is here.
	if ( $stay['perPerson'] && 'elsewhere' !== $type ) {
		$set = array();
		foreach ( $d['people'] as $p ) {
			if ( 'yf' === $type || ! ogc_reg_in_hall( $p, $d ) ) {
				foreach ( $p['nights'] as $n ) {
					$set[ $n ] = true;
				}
			}
		}
		if ( $set ) {
			$d['stay']['nights'] = array_values( array_filter( $nights, function ( $n ) use ( $set ) { return isset( $set[ $n ] ); } ) );
		}
	}
	// Rooms follow the number sleeping until someone sets them; each person's room when nights differ.
	$beds     = max( 1, (int) ogc_reg_c( $cfg, 'room_beds', '2' ) ) + 1;
	$sleepers = ogc_reg_sleepers( $d );
	if ( 'dorm' === $type ) {
		if ( ! $d['stay']['roomsSet'] ) {
			$d['stay']['rooms'] = max( 1, min( 6, (int) ceil( count( $sleepers ) / $beds ) ) );
		}
		// Who sleeps where: a room the form sent stays; anyone without one is placed as the form does
		// (ogc_reg_place_rooms): the grown-ups together from Room 1, the children together after them.
		ogc_reg_place_rooms( $d, $beds - 1 );
		// Keys: only the person named for a room picks up its keys (2026 packet); a grown-up of the household.
		$names = wp_list_pluck( $adults, 'name' );
		$want  = (array) $g( $s, 'keys', array() );
		for ( $i = 0; $i < $d['stay']['rooms']; $i++ ) {
			$w                     = isset( $want[ $i ] ) ? ogc_reg_str( $want[ $i ] ) : '';
			$d['stay']['keys'][] = in_array( $w, $names, true ) ? $w : ( $names ? $names[ $i % count( $names ) ] : $d['household']['contact'] );
		}
	} else {
		foreach ( $d['people'] as &$p ) {
			$p['room'] = null;
		}
		unset( $p );
	}
	// Linens, asked once for the household: own (nobody's packets), or order (the rooms' packets for the
	// sleepers named in linenFor, when the form sends it; each hall Young Folk's own). Nothing to ask when
	// nobody sleeps in a dorm room or a hall.
	$room_sl = 'dorm' === $type ? wp_list_pluck( ogc_reg_sleepers( $d ), 'pid' ) : array();
	$hall_yf = array_filter( $d['people'], function ( $p ) use ( $d ) { return ogc_reg_in_hall( $p, $d ); } );
	$for     = $g( $s, 'linenFor', null );
	if ( ! $room_sl && ! $hall_yf ) {
		$d['stay']['linenChoice'] = '';
	} elseif ( 'own' === $d['stay']['linenChoice'] ) {
		$d['stay']['linens'] = 0;
		foreach ( $d['people'] as &$p ) {
			$p['linens'] = false;
		}
		unset( $p );
	} elseif ( '' === $d['stay']['linenChoice'] && ( $d['stay']['linens'] > 0 || array_filter( wp_list_pluck( $d['people'], 'linens' ) ) ) ) {
		$d['stay']['linenChoice'] = 'order';
	}
	if ( 'order' === $d['stay']['linenChoice'] && is_array( $for ) && 'yes' !== ogc_reg_c( $cfg, 'linens_required' ) ) {
		$d['stay']['linenFor'] = array_values( array_intersect( $room_sl, array_map( 'strval', $for ) ) );
		$d['stay']['linens']   = count( $d['stay']['linenFor'] );
	}
	// A parent's approval: by the grown-up registering ("I'm the parent", yfOk) or by email ("Ask a
	// parent", ask), for Young Folks under 18 in the halls; always by email for a minor with no adult.
	$hall_minors = array_filter( $d['people'], function ( $p ) use ( $d ) { return $p['minor'] && ogc_reg_in_hall( $p, $d ); } );
	$any_minors  = array_filter( $d['people'], function ( $p ) { return $p['minor']; } );
	if ( ! ( $adults && $hall_minors ) ) {
		$d['stay']['yfOk'] = false;
		$d['stay']['ask']  = false;
	}
	if ( $d['stay']['ask'] ) {
		$d['stay']['yfOk'] = false;
	}
	if ( ! ( ( ! $adults && $any_minors ) || $d['stay']['ask'] ) ) {
		$d['stay']['parentEmail'] = '';
	}

	// Meals: whole meals the household skips, and for a meal not everyone eats, who does (by pid).
	$keys  = wp_list_pluck( ogc_reg_meals( $year ), 'key' );
	$m     = $g( $in, 'meals', array() );
	$off   = array();
	$who   = array();
	foreach ( (array) $g( $m, 'off', array() ) as $k => $v ) {
		if ( in_array( (string) $k, $keys, true ) && ogc_reg_bool( $v ) ) {
			$off[ $k ] = true;
		}
	}
	$all_pids = wp_list_pluck( $d['people'], 'pid' );
	foreach ( (array) $g( $m, 'who', array() ) as $k => $list ) {
		if ( in_array( (string) $k, $keys, true ) && empty( $off[ $k ] ) && is_array( $list ) ) {
			$list = array_values( array_intersect( $all_pids, $list ) );
			if ( count( $list ) < count( $all_pids ) ) {
				if ( $list ) {
					$who[ $k ] = $list;
				} else {
					$off[ $k ] = true;
				}
			}
		}
	}
	$d['meals']     = array( 'off' => (object) $off, 'who' => (object) $who, 'custom' => (object) array() );
	$d['communion'] = count( array_filter( $d['people'], function ( $p ) { return $p['communing']; } ) );

	// Preteens: details only for preteens, and only when the COA collects them online.
	$online         = 'paper' !== ogc_reg_c( $cfg, 'preteen_details', 'online' );
	$pt             = array_values( array_filter( $d['people'], function ( $p ) { return $p['preteen']; } ) );
	$pt_days        = array_values( array_filter( array_map( 'trim', explode( '|', ogc_reg_c( $cfg, 'preteen_days' ) ) ) ) );
	$d['preteens']  = array();
	$d['contacts']  = array();
	$d['pickupWho'] = array();
	$d['pickupOther'] = '';
	$d['pickup']    = '';
	if ( $online && $pt ) {
		$inp = (array) $g( $in, 'preteens', array() );
		foreach ( $pt as $p ) {
			$o                          = isset( $inp[ $p['pid'] ] ) && is_array( $inp[ $p['pid'] ] ) ? $inp[ $p['pid'] ] : array();
			$d['preteens'][ $p['pid'] ] = array(
				'medical' => ogc_reg_note( $g( $o, 'medical' ) ),
				'days'    => array_values( array_intersect( $pt_days, (array) $g( $o, 'days', array() ) ) ),
			);
		}
		$d['preteens'] = (object) $d['preteens'];
		foreach ( array( 0, 1 ) as $j ) {
			$c               = (array) $g( (array) $g( $in, 'contacts', array() ), $j, array() );
			$d['contacts'][] = array( 'name' => ogc_reg_str( $g( $c, 'name' ) ), 'rel' => ogc_reg_str( $g( $c, 'rel' ), 40 ), 'phone' => ogc_reg_str( $g( $c, 'phone' ), 30 ) );
		}
		$names            = wp_list_pluck( $adults, 'name' );
		$d['pickupWho']   = array_values( array_intersect( $names, (array) $g( $in, 'pickupWho', array() ) ) );
		$d['pickupOther'] = ogc_reg_str( $g( $in, 'pickupOther' ), 120 );
		if ( ! $d['pickupWho'] && '' === $d['pickupOther'] ) {
			$d['pickupWho'] = $names;
		}
		$d['pickup'] = implode( ' or ', array_filter( array_merge( $d['pickupWho'], array( $d['pickupOther'] ) ) ) );
	} else {
		$d['preteens'] = (object) array();
	}

	if ( ! $d['household']['name'] && $d['household']['contact'] ) {
		$parts                    = preg_split( '/\s+/', $d['household']['contact'] );
		$d['household']['name'] = end( $parts );
	}
	$gift      = $g( $in, 'gift', 0 );
	$d['gift'] = 'none' === ogc_reg_c( $cfg, 'gift_for' ) ? 0 : max( 0, min( 5000, (int) ( is_numeric( $gift ) ? floor( (float) $gift ) : 0 ) ) );
	$d['pay']  = in_array( $g( $in, 'pay' ), array( 'card', 'checkin' ), true ) ? $g( $in, 'pay' ) : 'check';
	// "Save for next year" (Michael, Oct 13): opt-in, unticked by default. Only a registration with it
	// fills next year's form (ogc_reg_reuse); the clearing after the Conference must honour it.
	$d['keep_next_year'] = ogc_reg_bool( $g( $in, 'keep_next_year' ) );
	$d['meals']['custom'] = (object) ogc_reg_meal_counts( $d, $year );
	return $d;
}

/** Who eats each meal, by age group, for the caterer's counts (kept in meals.custom, which the lists
 * read through SU.eats): everyone on the days they're here, less the meals skipped. */
function ogc_reg_meal_counts( $d, $year ) {
	$cfg  = ogc_reg_cfg( $year );
	$days = ogc_reg_days( $year );
	$here = array();
	foreach ( $d['people'] as $p ) {
		$here[ $p['pid'] ] = array_flip( ogc_reg_person_days( $p, $d, $cfg, $days ) );
	}
	$off = (array) $d['meals']['off'];
	$who = (array) $d['meals']['who'];
	$out = array();
	foreach ( ogc_reg_meals( $year ) as $m ) {
		$c = array( 'adult' => 0, 'child' => 0, 'baby' => 0 );
		if ( empty( $off[ $m['key'] ] ) ) {
			foreach ( $d['people'] as $p ) {
				if ( isset( $here[ $p['pid'] ][ $m['date'] ] ) && ( ! isset( $who[ $m['key'] ] ) || in_array( $p['pid'], $who[ $m['key'] ], true ) ) ) {
					$c[ $p['band'] ]++;
				}
			}
		}
		$out[ $m['key'] ] = $c;
	}
	return $out;
}

/* ================================================================== the rules */

/** Is the email likely mistyped? ("gmial.com" → "gmail.com"), or ''. */
function ogc_reg_email_typo( $e ) {
	$fix = array( 'gmial.com' => 'gmail.com', 'gmal.com' => 'gmail.com', 'gmail.co' => 'gmail.com', 'gamil.com' => 'gmail.com', 'gnail.com' => 'gmail.com', 'yaho.com' => 'yahoo.com', 'yahoo.co' => 'yahoo.com', 'hotmal.com' => 'hotmail.com', 'outlok.com' => 'outlook.com', 'icloud.co' => 'icloud.com' );
	$at  = strrpos( (string) $e, '@' );
	if ( false === $at ) {
		return '';
	}
	$dom = substr( $e, $at + 1 );
	return isset( $fix[ $dom ] ) ? substr( $e, 0, $at + 1 ) . $fix[ $dom ] : '';
}

/**
 * What's wrong with a household's answers, by the field it belongs to (the same paths the form
 * shows errors at): array( 'household.phone' => 'Required', 'people.p3.age' => 'Enter an age', … ).
 * $member: a year's member entering a registration at the desk (no email needed).
 */
/**
 * Rooms a household chose on the map (only where households choose, room_choice = households): each a
 * real room of the year, a ground floor only when asked for, no more than the stay's rooms, and none
 * another household holds (chosen, or given by Lodging). $own: the registration's own record id.
 * Checked at check, create and update; the map's "taken" is only advisory (review, Oct 11).
 */
function ogc_reg_fit_rooms( $d, $year, $own = 0 ) {
	$cfg    = ogc_reg_cfg( $year );
	$chosen = isset( $d['stay']['chosen'] ) ? (array) $d['stay']['chosen'] : array();
	if ( 'households' !== ogc_reg_c( $cfg, 'room_choice' ) || ! $chosen || ! function_exists( 'ogc_map_rooms' ) ) {
		return array();
	}
	$rooms = ogc_map_rooms( $year );
	foreach ( $chosen as $r ) {
		if ( ! isset( $rooms[ (string) $r ] ) ) {
			return array( 'stay.chosen' => 'Choose the rooms again · One isn’t on the map' );
		}
		if ( 1 === (int) $rooms[ (string) $r ]['floor'] && empty( $d['stay']['ground'] ) && empty( $d['stay']['walker'] ) ) {
			return array( 'stay.chosen' => 'Ground floors are kept for those who ask' );
		}
	}
	if ( count( $chosen ) > max( 1, (int) $d['stay']['rooms'] ) ) {
		return array( 'stay.chosen' => 'Choose ' . (int) $d['stay']['rooms'] . ' ' . ( 1 === (int) $d['stay']['rooms'] ? 'room' : 'rooms' ) );
	}
	$taken  = array();
	$own_hh = '';
	foreach ( ogc_records( $year, 'registrations' ) as $rec ) {
		if ( (int) $rec['id'] === (int) $own ) {
			$own_hh = isset( $rec['data']['id'] ) ? (string) $rec['data']['id'] : '';
			continue;
		}
		if ( isset( $rec['data']['status'] ) && 'cancelled' === $rec['data']['status'] ) {
			continue;
		}
		foreach ( isset( $rec['data']['stay']['chosen'] ) ? (array) $rec['data']['stay']['chosen'] : array() as $r ) {
			$taken[ (string) $r ] = true;
		}
	}
	$st = ogc_state_get( $year, 'rooms' );
	foreach ( $st && is_array( $st['value'] ) ? $st['value'] : array() as $hid => $ids ) {
		if ( '' === $own_hh || (string) $hid !== $own_hh ) {
			foreach ( (array) $ids as $r ) {
				$taken[ (string) $r ] = true;
			}
		}
	}
	foreach ( $chosen as $r ) {
		if ( isset( $taken[ (string) $r ] ) ) {
			return array( 'stay.chosen' => 'Taken since you chose it · Choose again' );
		}
	}
	return array();
}

function ogc_reg_problems( $d, $year, $member = false ) {
	$cfg  = ogc_reg_cfg( $year );
	$e    = array();
	$need = function ( $path, $v ) use ( &$e ) {
		if ( '' === trim( (string) $v ) ) {
			$e[ $path ] = 'Required';
		}
	};
	$h = $d['household'];
	$x = $d['helper'];
	$need( 'household.contact', $h['contact'] );
	if ( $x['on'] ) {
		$need( 'helper.name', $x['name'] );
		// The household must be reachable (Lodging and the Preteens committee call them, not the helper):
		// its email or its phone. The helper's own phone is optional.
		if ( '' === $h['email'] && '' === $h['phone'] ) {
			$e['household.phone'] = 'Enter an email or a phone';
		}
		if ( ! ogc_reg_email_ok( $x['email'] ) && ! $member ) {
			$e['helper.email'] = '' === $x['email'] ? 'Required' : 'Enter an email like name@example.com';
		}
		if ( '' !== $h['email'] && ! ogc_reg_email_ok( $h['email'] ) ) {
			$e['household.email'] = 'Enter an email like name@example.com';
		}
	} else {
		$need( 'household.phone', $h['phone'] );
		if ( ! ogc_reg_email_ok( $h['email'] ) && ! ( $member && '' === $h['email'] ) ) {
			$e['household.email'] = '' === $h['email'] ? 'Required' : 'Enter an email like name@example.com';
		}
	}
	if ( ! $d['people'] ) {
		$e['people'] = 'Add who’s coming';
	} elseif ( count( $d['people'] ) > 20 ) {
		$e['people'] = 'Up to 20 · Register another for the rest';
	}
	$adults = 0;
	foreach ( $d['people'] as $p ) {
		$k = 'people.' . $p['pid'];
		if ( 'adult' === $p['kind'] ) {
			$adults++;
		}
		if ( 'adult' !== $p['kind'] && '' === $p['age'] ) {
			$e[ $k . '.age' ] = 'Enter an age';
		} elseif ( 'child' === $p['kind'] && (int) $p['age'] >= 18 ) {
			$e[ $k . '.age' ] = '18 and over · Choose Adult or Young Folk';
		} elseif ( '' !== $p['age'] && (int) $p['age'] > 110 ) {
			$e[ $k . '.age' ] = 'Enter an age';
		}
		if ( $p['yf'] && ! $p['yfHall'] && ogc_reg_in_hall( $p, $d ) ) {
			$e[ $k . '.yfHall' ] = 'Choose a hall';
		}
	}
	// Where people sleep must be safe (the Advisors, Oct 9): a Young Folk is the COA's age and up
	// (yf_min_age, 16 in the sample), and a child comes with a grown-up on the same registration. The
	// COA may allow children who come with another household (child_with_household = yes): then the
	// household they're with is named, for Lodging. At the desk (a member) a child with no grown-up may
	// be entered, and is flagged (flags.noAdult) for Lodging's Review.
	$min = (int) ogc_reg_c( $cfg, 'yf_min_age', '16' );
	foreach ( $d['people'] as $p ) {
		if ( $p['yf'] && '' !== $p['age'] && $min > 0 && (int) $p['age'] < $min && ! isset( $e[ 'people.' . $p['pid'] . '.age' ] ) ) {
			$e[ 'people.' . $p['pid'] . '.age' ] = $min . ' and up · Choose Child';
		}
	}
	$kids = array_filter( $d['people'], function ( $p ) { return 'child' === $p['kind']; } );
	if ( $kids && ! $adults && ! $member && ! isset( $e['people'] ) ) {
		if ( 'yes' !== ogc_reg_c( $cfg, 'child_with_household' ) ) {
			$e['people'] = 'A child needs a grown-up on this registration';
		} elseif ( '' === trim( (string) $d['stay']['withHh'] ) ) {
			$e['stay.withHh'] = 'Required';
		}
	}
	$s       = $d['stay'];
	$minors  = array_filter( $d['people'], function ( $p ) { return $p['minor'] && ! empty( $p['yf'] ); } );
	if ( 'elsewhere' === $s['type'] ) {
		if ( ! $s['days'] ) {
			$e['stay.days'] = 'Choose at least one day';
		}
	} elseif ( ! $s['nights'] ) {
		$e['stay.nights'] = 'Choose at least one night';
	}
	if ( $s['perPerson'] ) {
		foreach ( $d['people'] as $p ) {
			if ( ! $p['nights'] && ( 'elsewhere' !== $s['type'] || ogc_reg_in_hall( $p, $d ) ) ) {
				$e[ 'people.' . $p['pid'] . '.nights' ] = 'Choose at least one night';
			}
		}
	}
	if ( 'dorm' === $s['type'] ) {
		$beds = max( 1, (int) ogc_reg_c( $cfg, 'room_beds', '2' ) ) + 1;
		$n    = count( ogc_reg_sleepers( $d ) );
		if ( $n > $s['rooms'] * $beds ) {
			$need_rooms     = (int) ceil( $n / $beds );
			$e['stay.rooms'] = $n . ' people need ' . $need_rooms . ' rooms';
		}
	}
	$in_hall = array_filter( $minors, function ( $p ) use ( $d ) { return ogc_reg_in_hall( $p, $d ); } );
	if ( $minors && $adults && $in_hall && ! $s['yfOk'] && empty( $s['ask'] ) ) {
		$e['stay.yfOk'] = 'Choose one';
	}
	if ( $minors && ( ! $adults || ( $in_hall && ! empty( $s['ask'] ) ) ) && ! ogc_reg_email_ok( $s['parentEmail'] ) ) {
		$e['stay.parentEmail'] = '' === $s['parentEmail'] ? 'Required' : 'Enter an email like name@example.com';
	}
	if ( ogc_reg_email_ok( $s['parentEmail'] ) && in_array( $s['parentEmail'], array( strtolower( $d['household']['email'] ), strtolower( $d['helper']['email'] ) ), true ) ) {
		$e['stay.parentEmail'] = 'Use a parent’s email';
	}
	if ( 'yes' === ogc_reg_c( $cfg, 'linens_required' ) ) {
		$sl = count( ogc_reg_sleepers( $d ) );
		if ( 'dorm' === $s['type'] && $s['linens'] < $sl ) {
			$e['stay.linens'] = 'One for each person · ' . $sl;
		}
	}
	if ( ! empty( (array) $d['preteens'] ) ) {
		// One emergency contact is required; a second is optional (question 39 to the Preteens committee).
		foreach ( $d['contacts'] as $j => $c ) {
			if ( $j > 0 && '' === $c['name'] && '' === $c['phone'] ) {
				continue;
			}
			if ( '' === $c['name'] ) {
				$e[ 'contacts.' . $j . '.name' ] = 'Required';
			}
			if ( '' === $c['phone'] ) {
				$e[ 'contacts.' . $j . '.phone' ] = 'Required';
			}
		}
	}
	return $e;
}

/** Past the date a check must arrive by (check_by): checks are no longer offered. */
function ogc_reg_checks_closed( $year, $today ) {
	$by = ogc_reg_c( ogc_reg_cfg( $year ), 'check_by' );
	return '' !== $by && $today > $by;
}

/** How a household may pay today: a check until check_by; then the COA's late choice (late_pay: pay at
 * check-in, or card only). Members at the desk may record any. */
function ogc_reg_pay_problems( $d, $year, $today, $member = false ) {
	if ( $member ) {
		return array();
	}
	$late = ogc_reg_checks_closed( $year, $today );
	$card = 'card' === ogc_reg_c( ogc_reg_cfg( $year ), 'late_pay' );
	if ( 'check' === $d['pay'] && $late ) {
		return array( 'pay' => $card ? 'Checks closed · Pay by card' : 'Checks closed · Pay at check-in' );
	}
	if ( 'checkin' === $d['pay'] && ( ! $late || $card ) ) {
		return array( 'pay' => 'Choose how to pay' );
	}
	return array();
}

/** On ogbbc.org, registration doesn't open while sample households are in the year. Locally it does, so
 * the walk-through keeps its sample year; a member may see the block with ?samples=block. */
function ogc_reg_samples_block( $year, $req = null ) {
	if ( ! ogc_reg_has_samples( $year ) ) {
		return false;
	}
	if ( ! ogc_reg_local() ) {
		return true;
	}
	return $req && 'block' === $req->get_param( 'samples' ) && ogc_is_member( $year );
}

/* ================================================================== the price */

function ogc_reg_money( $cents ) {
	$cents = (int) $cents;
	$neg   = $cents < 0;
	$cents = abs( $cents );
	$s     = '$' . number_format( intdiv( $cents, 100 ) ) . ( $cents % 100 ? '.' . str_pad( (string) ( $cents % 100 ), 2, '0', STR_PAD_LEFT ) : '' );
	return ( $neg ? '−' : '' ) . $s;
}

function ogc_reg_plural( $n, $one, $many = '' ) {
	return $n . ' ' . ( 1 === (int) $n ? $one : ( $many ? $many : $one . 's' ) );
}

function ogc_reg_first( $name ) {
	$w = preg_split( '/\s+/', trim( (string) $name ) );
	return $w ? $w[0] : '';
}

/**
 * What a household pays (lines in cents). How the campus charges is the COA's setting
 * (registration.csv), so the same form works at either campus:
 *   charge = room (default): each dorm room, each night it's held (room_price);
 *            person: each person in the household's rooms, each night (person_price_adult, _child, _baby)
 *   yf_charge = share (default: a share of a room, room_price ÷ room_beds) · person (yf_price) · room
 *   linens (linen_price) for the household's rooms and each Young Folk who asks; air mattresses
 *   campers: camper_price each night, or once (camper_per = stay)
 *   meals: free unless meals_free = no (meal_price_adult, meal_price_child; babies free)
 *   the gift, its own line (it goes to its own fund, gift_for)
 * The prices used are kept with the registration, so a later price change never reprices it.
 */
function ogc_reg_price( $d, $year, $cfg = null ) {
	$cfg   = $cfg ? $cfg : ogc_reg_cfg( $year );
	$lines = array();
	$s     = $d['stay'];
	$add   = function ( $key, $label, $cents ) use ( &$lines ) {
		if ( $cents ) {
			$lines[] = array( 'key' => $key, 'label' => $label, 'cents' => (int) $cents );
		}
	};
	$room   = ogc_reg_cents( $cfg, 'room_price' );
	$beds   = max( 1, (int) ogc_reg_c( $cfg, 'room_beds', '2' ) );
	$charge = ogc_reg_c( $cfg, 'charge', 'room' );
	if ( 'dorm' === $s['type'] && $s['nights'] ) {
		if ( 'person' === $charge ) {
			foreach ( array( 'adult' => 'Adults', 'child' => 'Children', 'baby' => 'Under 3' ) as $b => $label ) {
				$price = ogc_reg_cents( $cfg, 'person_price_' . $b );
				$n     = 0;
				foreach ( $d['people'] as $p ) {
					if ( $p['band'] === $b && ! ogc_reg_in_hall( $p, $d ) ) {
						$n += count( ogc_reg_nights_for( $p, $d, $cfg ) );
					}
				}
				$add( 'person_' . $b, $label . ' · ' . ogc_reg_plural( $n, 'night' ) . ' × ' . ogc_reg_money( $price ), $n * $price );
			}
		} elseif ( $s['perPerson'] && $s['rooms'] > 1 ) {
			// Each room is held for its own sleepers' nights.
			for ( $i = 0; $i < $s['rooms']; $i++ ) {
				$set = array();
				foreach ( $d['people'] as $p ) {
					if ( $i === $p['room'] ) {
						foreach ( ogc_reg_nights_for( $p, $d, $cfg ) as $n ) {
							$set[ $n ] = true;
						}
					}
				}
				$n = $set ? count( $set ) : count( $s['nights'] );
				$add( 'room_' . $i, 'Room ' . ( $i + 1 ) . ' · ' . ogc_reg_plural( $n, 'night' ) . ' × ' . ogc_reg_money( $room ), $n * $room );
			}
		} else {
			$n = count( $s['nights'] );
			$add( 'rooms', ogc_reg_plural( $s['rooms'], 'dorm room' ) . ' · ' . ogc_reg_plural( $n, 'night' ) . ' × ' . ogc_reg_money( $room ), $s['rooms'] * $n * $room );
		}
		if ( $s['mattresses'] ) {
			$mp = ogc_reg_cents( $cfg, 'mattress_price' );
			$add( 'mattresses', ogc_reg_plural( $s['mattresses'], 'air mattress', 'air mattresses' ) . ' × ' . ogc_reg_money( $mp ), $s['mattresses'] * $mp );
		}
	}
	// Young Folks in their halls.
	$yfc = ogc_reg_c( $cfg, 'yf_charge', 'share' );
	$per = 'person' === $yfc ? ogc_reg_cents( $cfg, 'yf_price' ) : ( 'room' === $yfc ? $room : (int) round( $room / $beds ) );
	foreach ( $d['people'] as $p ) {
		if ( ogc_reg_in_hall( $p, $d ) ) {
			$n    = count( ogc_reg_nights_for( $p, $d, $cfg ) );
			$hall = 'women' === $p['yfHall'] ? 'Young women’s hall' : 'Young men’s hall';
			$add( 'yf_' . $p['pid'], ogc_reg_first( $p['name'] ) . ' · ' . $hall . ' · ' . ogc_reg_plural( $n, 'night' ) . ' × ' . ogc_reg_money( $per ), $n * $per );
		}
	}
	// Linens: every packet on one line, the rooms' and each Young Folk's in a hall (polish 3: two lines
	// for the same thing). Where a Young Folk sleeps is said in the stay's words; a parent's page still
	// shows their child's own packet (ogc_reg_approval_lines).
	$lp = ogc_reg_cents( $cfg, 'linen_price' );
	$rl = in_array( $s['type'], array( 'dorm', 'yf' ), true ) ? (int) $s['linens'] : 0;
	foreach ( $d['people'] as $p ) {
		if ( ! empty( $p['linens'] ) ) {
			$rl++;
		}
	}
	if ( $rl ) {
		$add( 'linens', ogc_reg_plural( $rl, 'linen packet' ) . ' × ' . ogc_reg_money( $lp ), $rl * $lp );
	}
	if ( 'camper' === $s['type'] && $s['nights'] ) {
		$cp = ogc_reg_cents( $cfg, 'camper_price' );
		$c  = max( 1, (int) $s['campers'] );
		if ( 'stay' === ogc_reg_c( $cfg, 'camper_per' ) ) {
			$add( 'camper', 'Camper lot · ' . ogc_reg_plural( $c, 'camper' ) . ' × ' . ogc_reg_money( $cp ), $c * $cp );
		} else {
			$n = count( $s['nights'] );
			$add( 'camper', 'Camper lot · ' . ( $c > 1 ? $c . ' campers · ' : '' ) . ogc_reg_plural( $n, 'night' ) . ' × ' . ogc_reg_money( $cp ), $c * $n * $cp );
		}
	}
	if ( 'no' === ogc_reg_c( $cfg, 'meals_free', 'yes' ) ) {
		$counts = (array) $d['meals']['custom'];
		foreach ( array( 'adult' => 'Meals, 12 and up', 'child' => 'Meals, 3 to 11' ) as $b => $label ) {
			$n = 0;
			foreach ( $counts as $c ) {
				$n += (int) ( is_array( $c ) ? $c[ $b ] : $c->$b );
			}
			$mp = ogc_reg_cents( $cfg, 'meal_price_' . $b );
			$add( 'meals_' . $b, $label . ' · ' . $n . ' × ' . ogc_reg_money( $mp ), $n * $mp );
		}
	}
	$lodging = array_sum( wp_list_pluck( $lines, 'cents' ) );
	$gift    = (int) $d['gift'] * 100;
	if ( $gift ) {
		$lines[] = array( 'key' => 'gift', 'label' => 'Gift · ' . ogc_reg_gift_for( $cfg ), 'cents' => $gift );
	}
	return array(
		'lines'         => $lines,
		'lodging_cents' => $lodging,
		'gift_cents'    => $gift,
		'total_cents'   => $lodging + $gift,
	);
}

/* ================================================================== what's left */

/** What every other registration of the year holds (samples and cancelled ones don't count). */
function ogc_reg_usage( $year, $except_id = 0 ) {
	$u     = array( 'rooms' => 0, 'linens' => 0, 'mattresses' => 0, 'campers' => 0, 'yf_men' => 0, 'yf_women' => 0 );
	$today = ogc_reg_today( $year );
	foreach ( ogc_records( (int) $year, 'registrations' ) as $r ) {
		$d = $r['data'];
		$st = isset( $d['status'] ) ? $d['status'] : '';
		// A place offered to a household on the waiting list is held for it until it lapses or is
		// withdrawn (Round 5; area-households-money H7): it counts like a registered one.
		$held = 'waitlist' === $st && function_exists( 'ogc_hh_offer_open' ) && ogc_hh_offer_open( $d, $today );
		if ( $r['sample'] || (int) $r['id'] === (int) $except_id || ( in_array( $st, array( 'cancelled', 'waitlist' ), true ) && ! $held ) || empty( $d['stay'] ) ) {
			continue;
		}
		$s = $d['stay'];
		if ( 'dorm' === ( isset( $s['type'] ) ? $s['type'] : '' ) ) {
			$u['rooms']      += (int) ( isset( $s['rooms'] ) ? $s['rooms'] : 0 );
			$u['mattresses'] += (int) ( isset( $s['mattresses'] ) ? $s['mattresses'] : 0 );
		}
		if ( in_array( isset( $s['type'] ) ? $s['type'] : '', array( 'dorm', 'yf' ), true ) ) {
			$u['linens'] += (int) ( isset( $s['linens'] ) ? $s['linens'] : 0 );
		}
		if ( 'camper' === ( isset( $s['type'] ) ? $s['type'] : '' ) ) {
			$u['campers'] += max( 1, (int) ( isset( $s['campers'] ) ? $s['campers'] : 1 ) );
		}
		foreach ( (array) ( isset( $d['people'] ) ? $d['people'] : array() ) as $p ) {
			if ( ! empty( $p['linens'] ) ) {
				$u['linens']++;
			}
			if ( ! empty( $p['yf'] ) && ( 'yf' === ( isset( $s['type'] ) ? $s['type'] : '' ) || 'family' !== ( isset( $p['sleeps'] ) ? $p['sleeps'] : '' ) ) ) {
				$u[ 'women' === ( isset( $p['yfHall'] ) ? $p['yfHall'] : '' ) ? 'yf_women' : 'yf_men' ]++;
			}
		}
	}
	return $u;
}

/** What's left of each limited thing (null: no limit set). Lodging sets the limits in registration.csv:
 * room_limit, linen_stock, mattress_stock, camper_limit, yf_beds_men, yf_beds_women. */
function ogc_reg_left( $year, $except_id = 0 ) {
	$cfg  = ogc_reg_cfg( $year );
	$used = ogc_reg_usage( $year, $except_id );
	$map  = array( 'rooms' => 'room_limit', 'linens' => 'linen_stock', 'mattresses' => 'mattress_stock', 'campers' => 'camper_limit', 'yf_men' => 'yf_beds_men', 'yf_women' => 'yf_beds_women' );
	$out  = array();
	foreach ( $map as $k => $key ) {
		$lim       = ogc_reg_c( $cfg, $key );
		$out[ $k ] = is_numeric( $lim ) ? max( 0, (int) $lim - $used[ $k ] ) : null;
	}
	if ( ! ogc_reg_c( $cfg, 'mattress_price' ) ) {
		$out['mattresses'] = 0;
	}
	return $out;
}

/**
 * Hold the answers to what's left: too many linens or mattresses come back set to what's left, with a
 * message at the field; rooms or beds that have run out are an error. Returns the problems.
 */
function ogc_reg_fit_stock( &$d, $year, $except_id = 0, $waitlist = false ) {
	$left = ogc_reg_left( $year, $except_id );
	$e    = array();
	$s    = &$d['stay'];
	$yfl  = count( array_filter( $d['people'], function ( $p ) { return ! empty( $p['linens'] ); } ) );
	if ( null !== $left['linens'] && $s['linens'] + $yfl > $left['linens'] ) {
		$s['linens']      = max( 0, $left['linens'] - $yfl );
		$e['stay.linens'] = $left['linens'] ? 'Only ' . $left['linens'] . ' left · Changed to ' . $left['linens'] : 'None left · Bring your own';
	}
	if ( 'dorm' === $s['type'] && null !== $left['mattresses'] && $s['mattresses'] > $left['mattresses'] ) {
		$s['mattresses']      = $left['mattresses'];
		$e['stay.mattresses'] = $left['mattresses'] ? 'Only ' . $left['mattresses'] . ' left · Changed to ' . $left['mattresses'] : 'None left';
	}
	if ( ! $waitlist && 'dorm' === $s['type'] && null !== $left['rooms'] && $s['rooms'] > $left['rooms'] ) {
		$e['stay.type'] = $left['rooms'] ? 'Only ' . ogc_reg_plural( $left['rooms'], 'room' ) . ' left' : 'Rooms full';
	}
	if ( ! $waitlist && 'camper' === $s['type'] && null !== $left['campers'] && $s['campers'] > $left['campers'] ) {
		$e['stay.type'] = $left['campers'] ? 'Only ' . ogc_reg_plural( $left['campers'], 'space' ) . ' left' : 'Camper lot full';
	}
	foreach ( array( 'men', 'women' ) as $hall ) {
		$want = count( array_filter( $d['people'], function ( $p ) use ( $d, $hall ) { return ogc_reg_in_hall( $p, $d ) && $p['yfHall'] === $hall; } ) );
		$l    = $left[ 'yf_' . $hall ];
		if ( $want && null !== $l && $want > $l ) {
			foreach ( $d['people'] as $p ) {
				if ( ogc_reg_in_hall( $p, $d ) && $p['yfHall'] === $hall ) {
					$e[ 'people.' . $p['pid'] . '.yfHall' ] = $l ? 'Only ' . ogc_reg_plural( $l, 'bed' ) . ' left' : 'Hall full';
				}
			}
		}
	}
	unset( $s );
	return $e;
}

/** What the gift is for, as a label ("Kit packing"): the COA's gift_for, its first letter capitalised. */
function ogc_reg_gift_for( $cfg ) {
	$g = preg_replace( '/^the\s+/i', '', trim( ogc_reg_c( $cfg, 'gift_for', 'the Conference fund' ) ) );
	return function_exists( 'mb_strtoupper' ) ? mb_strtoupper( mb_substr( $g, 0, 1 ) ) . mb_substr( $g, 1 ) : ucfirst( $g );
}

/** Linens in words, the same everywhere (form, Your sign-ups, emails): "Own linens", "2 linen packets",
 * each Young Folk's own ("Levi: linen packet"), joined with " · ". '' when nothing is asked. */
function ogc_reg_linen_words( $d ) {
	$s      = isset( $d['stay'] ) ? $d['stay'] : array();
	$choice = isset( $s['linenChoice'] ) ? $s['linenChoice'] : '';
	$rooms  = 'dorm' === ( isset( $s['type'] ) ? $s['type'] : '' );
	$hall   = array_filter( (array) ( isset( $d['people'] ) ? $d['people'] : array() ), function ( $p ) use ( $d ) { return ogc_reg_in_hall( $p, $d ); } );
	$yf     = array_filter( $hall, function ( $p ) { return ! empty( $p['linens'] ); } );
	// Every packet counted together, as on the price line ("4 linen packets"); one person: "Linen packet".
	$n = ( $rooms ? (int) ( isset( $s['linens'] ) ? $s['linens'] : 0 ) : 0 ) + count( $yf );
	if ( $n ) {
		return 1 === count( (array) $d['people'] ) && 1 === $n ? 'Linen packet' : ogc_reg_plural( $n, 'linen packet' );
	}
	return '' !== $choice && ( $rooms || $hall ) ? 'Own linens' : '';
}

/** Must the household still choose linens? Someone sleeps in a dorm room or a hall, and no choice is
 * made (unless the COA requires packets). */
function ogc_reg_linen_unchosen( $d, $cfg ) {
	if ( '' !== $d['stay']['linenChoice'] || ( 'yes' === ogc_reg_c( $cfg, 'linens_required' ) && 'dorm' === $d['stay']['type'] ) ) {
		return false;
	}
	if ( 'dorm' === $d['stay']['type'] && ogc_reg_sleepers( $d ) ) {
		return true;
	}
	return (bool) array_filter( $d['people'], function ( $p ) use ( $d ) { return ogc_reg_in_hall( $p, $d ); } );
}
