<?php
/**
 * Volunteer shifts: Who's signed up, the committees' side. /wp-json/ogc/v1/vol/{year}/lead…
 *
 * Who may: the year's members (every committee, and All), or a committee's own heads (committees.csv
 * heads: their committee only, never the rest of the year). Names, phones and emails go nowhere else.
 *
 *   GET  lead                 one committee's shifts with everyone on them (or All: each committee's numbers)
 *   GET  lead/export          the list for Excel (one committee, or all for members), built here
 *   POST lead/add             a person signed up by the head (by phone, on paper, at the desk)
 *   POST lead/move            to another of the committee's shifts (Busy checked)
 *   POST lead/remove          off a shift (Undo: lead/restore)
 *   POST lead/offer           email a waiting person a one-tap Join
 *   POST lead/here            ticked as here, during the week
 *   POST lead/message         an email to the committee's volunteers (queued, one per address): answers
 *                             people (each once), emails, queued, skipped, call ("First L. · phone")
 *   POST lead/contact         the committee's contact (role email and phone), heads, weekly email
 *   POST lead/printed         printed or downloaded now (what changed since is marked from here)
 *   POST lead/setup           the committee's instruction for every shift, and which reminders go
 *                             (its head or the COA; CHANGES/volunteer-vs-sug.md)
 */

defined( 'ABSPATH' ) || exit;

add_action( 'rest_api_init', function () {
	$Y = '/vol/(?P<year>\d{4})/lead';
	register_rest_route( OGC_NS, $Y, array( 'methods' => 'GET', 'callback' => 'ogc_vol_lead_get', 'permission_callback' => 'ogc_vol_can_lead_req' ) );
	register_rest_route( OGC_NS, "$Y/export", array( 'methods' => 'GET', 'callback' => 'ogc_vol_lead_export', 'permission_callback' => 'ogc_vol_can_lead_req' ) );
	foreach ( array( 'add', 'move', 'remove', 'restore', 'offer', 'here', 'message', 'contact', 'printed', 'remind', 'edit', 'resend', 'note', 'setup' ) as $a ) {
		register_rest_route( OGC_NS, "$Y/$a", array( 'methods' => 'POST', 'callback' => 'ogc_vol_lead_' . $a, 'permission_callback' => 'ogc_vol_can_lead_req' ) );
	}
} );

/** Signed in, and a member or a head of the committee asked for (or of any, for the list of them). */
function ogc_vol_can_lead_req( WP_REST_Request $req ) {
	if ( ! ogc_valid_year( $req['year'] ) || ! is_user_logged_in() ) {
		return ogc_rest_denied( 'Sign in first.' );
	}
	$c = $req->get_param( 'committee' );
	$c = is_string( $c ) && '' !== $c ? $c : null;
	// A shift or a sign-up named: its own committee decides, whatever committee the request says (a head
	// of Ushers can't remove someone from Dining hall by sending committee=Ushers).
	$of = null;
	if ( $req->get_param( 'shift' ) ) {
		$sh = ogc_vol_shifts( (int) $req['year'] );
		$of = isset( $sh[ (string) $req->get_param( 'shift' ) ] ) ? $sh[ (string) $req->get_param( 'shift' ) ]['committee'] : '';
	}
	if ( $req->get_param( 'id' ) ) {
		$rc = ogc_vol_committee_of_record( (int) $req['year'], (int) $req->get_param( 'id' ) );
		if ( null !== $of && $rc !== $of ) {
			return ogc_rest_denied();
		}
		$of = $rc;
	}
	if ( null !== $of ) {
		if ( '' === $of || ( null !== $c && $c !== $of ) ) {
			return ogc_rest_denied();
		}
		$c = $of;
	}
	// The contact and heads list: members only.
	if ( false !== strpos( $req->get_route(), '/lead/contact' ) && ! ogc_vol_lead_all( $req['year'] ) && ! ( $c && in_array( $c, ogc_vol_headed( (int) $req['year'] ), true ) && null === $req->get_param( 'heads' ) ) ) {
		return ogc_rest_denied();
	}
	if ( 'all' === $req->get_param( 'scope' ) ) {
		return ogc_vol_lead_all( $req['year'] ) ? true : ogc_rest_denied();
	}
	return ogc_vol_can_lead( (int) $req['year'], $c ) ? true : ogc_rest_denied();
}

function ogc_vol_committee_of_record( $year, $id ) {
	$r = ogc_record_get( $id, true );
	if ( ! $r || (int) $r['year'] !== $year || ! in_array( $r['kind'], array( 'signups', 'waits' ), true ) ) {
		return '';
	}
	$sh = ogc_vol_shifts( $year );
	return isset( $sh[ $r['data']['id'] ] ) ? $sh[ $r['data']['id'] ]['committee'] : '';
}

/** The committees this person may open, with their numbers. */
function ogc_vol_lead_committees( $year ) {
	$all  = ogc_vol_lead_all( $year );
	$mine = array_merge( ogc_vol_headed( $year ), function_exists( 'ogc_appc_vol_scope' ) && ogc_is_member( $year ) ? (array) ogc_appc_vol_scope( $year ) : array() );
	$map  = ogc_vol_seat_map( $year );
	$out  = array();
	// For the year's committee: whether each has a contact and heads, and last year's numbers (kept
	// after the clearing, else counted from last year's list), so a new COA sees what's usual.
	$prev  = ogc_state_get( $year - 1, 'vol-stats' );
	$prev  = $prev ? (array) $prev['value'] : array();
	$pmap  = $all && ! $prev ? ogc_vol_seat_map( $year - 1 ) : null;
	$pcoms = $all && ! $prev ? array_keys( ogc_vol_committees( $year - 1 ) ) : array();
	foreach ( ogc_vol_committees( $year ) as $c ) {
		if ( $all || in_array( $c['name'], $mine, true ) ) {
			$n   = ogc_vol_committee_numbers( $year, $c['name'], $map );
			$row = array( 'name' => $c['name'], 'needed' => $n['needed'], 'filled' => $n['filled'], 'open' => $n['open'], 'shifts' => $n['shifts'] );
			if ( $all ) {
				$row['contact'] = '' !== $c['contact_email'];
				// Who heads it, by name ("Ruth K."), from the year's Members (docs/23: the COA manages who's
				// on each committee there); committees.csv's old heads list only when Members has none.
				$hn             = ogc_vol_heads_of( $year, $c['name'] );
				$row['heads']   = count( $hn );
				$row['head_names'] = $hn;
				$last           = null;
				if ( $prev ) {
					foreach ( $prev as $p ) {
						if ( $p['committee'] === $c['name'] ) {
							$last = $last ? $last : array( 'filled' => 0, 'needed' => 0 );
							$last['filled'] += (int) $p['filled'];
							$last['needed'] += (int) $p['needed'];
						}
					}
				} elseif ( in_array( $c['name'], $pcoms, true ) ) {
					$pn   = ogc_vol_committee_numbers( $year - 1, $c['name'], $pmap );
					$last = $pn['shifts'] ? array( 'filled' => $pn['filled'], 'needed' => $pn['needed'] ) : null;
				}
				$row['last'] = $last;
			}
			$out[] = $row;
		}
	}
	return $out;
}

/** A person on a shift as the head sees them. */
function ogc_vol_lead_person( $rec, $flags = array() ) {
	$d = $rec['data'];
	// The phone: the one this place was given when they typed or chose it; otherwise (a phone carried over
	// from before) the person's phone for the year by an exact email match, this year's registration over
	// last year's sign-up (after the third critic, Oct 15). Unconfirmed places keep what was typed.
	$ph = isset( $d['phone'] ) ? (string) $d['phone'] : '';
	if ( empty( $d['phone_set'] ) && ! empty( $d['confirmed'] ) && empty( $rec['sample'] ) && ! empty( $rec['year'] ) && function_exists( 'ogc_vol_known_phone' ) ) {
		$ph = ogc_vol_known_phone( (int) $rec['year'], $rec['email'], true ) ?: $ph;
	}
	return array_merge( array(
		'rid'       => (int) $rec['id'],
		'name'      => isset( $d['name'] ) ? $d['name'] : '',
		'phone'     => '' !== $ph ? ogc_vol_phone_shown( $ph ) : '',
		'email'     => isset( $d['email'] ) ? $d['email'] : '',
		'by'        => isset( $d['by'] ) ? $d['by'] : 'self',
		'helper'    => isset( $d['helper'] ) ? $d['helper'] : '',
		// The phone and email are a contact's, who isn't on the shift (Oct 15): "via Martha Fry".
		'via'       => ! empty( $d['via'] ) && ! empty( $d['helper'] ) ? (string) $d['helper'] : '',
		'confirmed' => ! empty( $d['confirmed'] ),
		'hidden'    => ! empty( $d['hide'] ) || ! empty( $d['minor'] ),
		// Under 18 (the registration's age, or the box on the first-time form): the head sees it.
		'minor'     => ! empty( $d['minor'] ),
		// Added past the count by a head who chose it (lead/add or lead/move with over).
		'over'      => ! empty( $d['over'] ),
		'sample'    => ! empty( $rec['sample'] ),
		'note'      => isset( $d['note'] ) ? $d['note'] : '',
		'answer'    => isset( $d['rule']['answer'] ) ? $d['rule']['answer'] : '',
		'screened'  => isset( $d['screened'] ) ? $d['screened'] : '',
		'here'      => ! empty( $d['here'] ),
		'swap'      => ! empty( $d['swap'] ),
		'at'        => $rec['created_at'],
	), $flags );
}

/** People who may be one person on two shifts at once under two emails (same name and phone). */
function ogc_vol_double_booked( $year, $map ) {
	$shifts = ogc_vol_shifts( $year );
	$by     = array();
	foreach ( $map as $id => $seats ) {
		foreach ( $seats as $s ) {
			$d = $s['record']['data'];
			$k = strtolower( preg_replace( '/\s+/', ' ', trim( $d['name'] ) ) ) . '|' . preg_replace( '/\D+/', '', isset( $d['phone'] ) ? $d['phone'] : '' );
			$by[ $k ][] = array( $id, $s['record'] );
		}
	}
	$flag = array();
	foreach ( $by as $list ) {
		for ( $i = 0; $i < count( $list ); $i++ ) {
			for ( $j = $i + 1; $j < count( $list ); $j++ ) {
				list( $a, $ra ) = $list[ $i ];
				list( $b, $rb ) = $list[ $j ];
				if ( $ra['email'] === $rb['email'] || ! isset( $shifts[ $a ], $shifts[ $b ] ) ) {
					continue;
				}
				if ( $shifts[ $a ]['start_ts'] < $shifts[ $b ]['end_ts'] && $shifts[ $b ]['start_ts'] < $shifts[ $a ]['end_ts'] ) {
					$flag[ $ra['id'] ] = $shifts[ $b ]['role'];
					$flag[ $rb['id'] ] = $shifts[ $a ]['role'];
				}
			}
		}
	}
	return $flag;
}

/** Names are cleared for the year (or past the date they're due to be): lists are numbers only. */
function ogc_vol_names_gone( $y ) {
	if ( ogc_state_get( $y, 'vol-cleared' ) ) {
		return true;
	}
	$s     = ogc_vol_settings( $y );
	$after = isset( $s['clear_after_days'] ) && is_numeric( $s['clear_after_days'] ) ? (int) $s['clear_after_days'] : 60;
	$last  = ogc_vol_last_day( $y );
	return $last && ogc_vol_wall( $y )['date'] > gmdate( 'Y-m-d', strtotime( $last . ' UTC' ) + $after * DAY_IN_SECONDS );
}

function ogc_vol_lead_get( WP_REST_Request $req ) {
	$y = (int) $req['year'];
	ogc_vol_prepare_year( $y );
	$coms = ogc_vol_lead_committees( $y );
	$c    = (string) $req->get_param( 'committee' );
	$all  = ogc_vol_lead_all( $y );
	if ( '' === $c && ! $all && $coms ) {
		$c = $coms[0]['name'];
	}
	// Whose inbox a message's replies go to, by name ("Replies to Phoebe Lehman"; after the fifth critic).
	$meu = wp_get_current_user();
	$out = array( 'committees' => $coms, 'all' => $all, 'committee' => $c, 'posted' => ogc_vol_posted( $y ), 'now' => ogc_vol_wall( $y ), 'me' => ogc_current_email(), 'me_name' => $meu && $meu->ID && function_exists( 'ogc_person_name' ) ? ogc_person_name( $meu->ID ) : '', 'webmaster' => ogc_is_webmaster() );
	// When names are cleared (the date, as promised to the Advisors).
	$s     = ogc_vol_settings( $y );
	$after = isset( $s['clear_after_days'] ) && is_numeric( $s['clear_after_days'] ) ? (int) $s['clear_after_days'] : 60;
	$last  = ogc_vol_last_day( $y );
	$out['clears']  = $last ? gmdate( 'Y-m-d', strtotime( $last . ' UTC' ) + $after * DAY_IN_SECONDS ) : '';
	$cl             = ogc_state_get( $y, 'vol-cleared' );
	$out['cleared'] = $cl ? substr( (string) $cl['value'], 0, 10 ) : '';
	// Past that date the list is numbers only, samples too, as promised (the timed job clears the rows).
	$gone        = ogc_vol_names_gone( $y );
	$out['gone'] = $gone;
	if ( '' === $c ) {
		if ( $all ) {
			// How many a "Message all heads" reaches (each contact and head once).
			$out['heads_n'] = count( ogc_vol_heads_emails( $y ) );
			$out['msgs_left'] = ogc_vol_msgs_left( ogc_current_email() );
			$out['members_url'] = ogc_url( 'members', array( 'year' => $y ) );
		}
		return rest_ensure_response( $out );
	}
	$comm = ogc_vol_committees( $y );
	if ( ! isset( $comm[ $c ] ) ) {
		return new WP_Error( 'ogc_not_found', 'Not found.', array( 'status' => 404 ) );
	}
	$map    = ogc_vol_seat_map( $y );
	$double = ogc_vol_double_booked( $y, $map );
	// An email several people in a household share ("owen.gardner@…" for Esther too): said as the
	// household's beside the names it isn't.
	$names_of = array();
	foreach ( $map as $seats ) {
		foreach ( $seats as $st ) {
			$names_of[ $st['record']['email'] ][ strtolower( trim( $st['record']['data']['name'] ) ) ] = true;
		}
	}
	$waits  = array();
	foreach ( ogc_records( $y, 'waits' ) as $w ) {
		$waits[ $w['data']['id'] ][] = array( 'rid' => (int) $w['id'], 'name' => $w['data']['name'], 'email' => $w['email'], 'phone' => isset( $w['data']['phone'] ) ? $w['data']['phone'] : '', 'at' => $w['created_at'], 'sample' => ! empty( $w['sample'] ) );
	}
	// What changed since this person last printed or downloaded the list.
	$pr    = ogc_state_get( $y, 'vol-printed' );
	$pr    = $pr ? (array) $pr['value'] : array();
	$since = isset( $pr[ $c ][ ogc_current_email() ] ) ? $pr[ $c ][ ogc_current_email() ] : '';
	$left  = array();
	$ch    = ogc_state_get( $y, 'vol-changes' );
	// Who left lately, whether or not this person has printed (after the third critic, Oct 15: the line
	// showed only after a print, and without the shift's day and time): since they last printed or
	// downloaded, else the last seven days. Each with its shift's day and time ("Sat, May 29 · 3–7 PM").
	// After the fourth critic (Oct 15): a print or a download (even a cancelled print dialog) emptied the
	// list, and what left before it could no longer be seen anywhere. Now every leave the year's log keeps
	// comes back, each with when it happened (`on`, venue date) and its group: `new` since this person
	// last printed or downloaded (or, never printed, the last seven days), else `earlier` (behind a fold).
	$from   = $since ? $since : gmdate( 'Y-m-d H:i:s', time() - 7 * DAY_IN_SECONDS );
	$all_sh = ogc_vol_shifts( $y );
	foreach ( $ch ? (array) $ch['value'] : array() as $x ) {
		if ( $x['committee'] === $c && in_array( $x['act'], array( 'left', 'unconfirmed', 'notme', 'moved_out', 'removed', 'swap' ), true ) ) {
			$xs     = isset( $all_sh[ $x['shift'] ] ) ? $all_sh[ $x['shift'] ] : null;
			$at_ts  = strtotime( $x['at'] . ' UTC' );
			$left[] = array(
				'shift' => $x['shift'],
				'name'  => 'swap' === $x['act'] ? $x['from'] : $x['name'],
				'act'   => $x['act'],
				'at'    => $x['at'],
				'when'  => $xs ? ogc_vol_subject_day( $y, $xs ) . ' · ' . ogc_vol_span_of( $xs ) : '',
				// The shift short ("Sat 3–7 PM", "Fri night 12–2 AM", "All week") and its job.
				'shift_short' => $xs ? ogc_vol_shift_short( $y, $xs ) : '',
				'role'  => $xs ? $xs['role'] : '',
				// When they left, the venue's date ("Oct 14"), and with its time ("Oct 14 · 3:12 PM"; after the
				// ninth critic, Oct 16: the date alone didn't say whether it was before or after a call).
				'on'    => $at_ts ? ( new DateTimeImmutable( '@' . $at_ts ) )->setTimezone( ogc_vol_tz( $y ) )->format( 'M j' ) : '',
				'on_at' => $at_ts ? ( new DateTimeImmutable( '@' . $at_ts ) )->setTimezone( ogc_vol_tz( $y ) )->format( 'M j · g:i A' ) : '',
				'group' => $x['at'] > $from ? 'new' : 'earlier',
			);
		}
	}
	$shifts = array();
	$stats  = ogc_state_get( $y, 'vol-stats' );
	$stats  = $stats ? (array) $stats['value'] : array();
	$prevst = ogc_state_get( $y - 1, 'vol-stats' );
	$prevst = $prevst ? (array) $prevst['value'] : array();
	foreach ( ogc_vol_shifts( $y ) as $id => $sh ) {
		if ( $sh['committee'] !== $c ) {
			continue;
		}
		$people = array();
		$n      = isset( $map[ $id ] ) ? count( $map[ $id ] ) : 0;
		if ( isset( $stats[ $id ]['filled'] ) && $gone ) {
			$n = max( $n, (int) $stats[ $id ]['filled'] );
		}
		foreach ( $gone ? array() : ( isset( $map[ $id ] ) ? $map[ $id ] : array() ) as $seat ) {
			$r        = $seat['record'];
			$fn       = strtolower( strtok( trim( (string) $r['data']['name'] ), ' ' ) );
			$people[] = ogc_vol_lead_person( $r, array(
				'new'       => $since && $r['created_at'] > $since,
				'check'     => isset( $double[ $r['id'] ] ) ? $double[ $r['id'] ] : '',
				'household' => $r['email'] && isset( $names_of[ $r['email'] ] ) && count( $names_of[ $r['email'] ] ) > 1 && false === strpos( strtolower( strstr( $r['email'], '@', true ) ), $fn ),
			) );
		}
		// Last year's record for the same shift (by uid, else committee, job and weekday).
		$last = null;
		foreach ( $prevst as $pid => $p ) {
			if ( ( $sh['uid'] && 0 === strpos( $pid, $sh['uid'] ) && $p['day'] === $sh['day'] ) || ( $p['committee'] === $sh['committee'] && $p['role'] === $sh['role'] && $p['day'] === $sh['day'] && abs( $p['start'] - $sh['start'] ) < 90 ) ) {
				$last = $p;
				break;
			}
		}
		$shifts[] = array(
			'id'      => $id,
			// What the shift is, for the app's Helpers (it reads no shifts file of its own).
			'role'    => $sh['role'],
			'day'     => $sh['day'],
			'date'    => $sh['date'],
			'start'   => $sh['start'],
			'end'     => $sh['end'],
			'allweek' => ! empty( $sh['allweek'] ),
			'last_date' => isset( $sh['last_date'] ) ? $sh['last_date'] : $sh['date'],
			// The night it belongs to, as the volunteers see it (after the eighth critic, Oct 16): `eve` is
			// the evening's date (Helpers lists a shift under it), `night` "Fri night" for a shift from
			// midnight to 5 AM ('' otherwise), `day_words` "Fri night, May 28" / "Sat, May 29".
			'eve'     => ogc_vol_eve_date( $sh ),
			'night'   => ogc_vol_night_words( $sh ),
			'day_words' => ogc_vol_subject_day( $y, $sh ),
			'needed'  => $sh['needed'],
			'unlimited' => $sh['unlimited'],
			'place'   => $sh['place_name'],
			'rule'    => $sh['rule'] ? ogc_vol_rule_label( $sh ) : '',
			// The rule said plainly in the shift's panel ("For 21 or older", or the rule's own words).
			'rule_words' => ! $sh['rule'] ? '' : ( $sh['min_age'] && ! $sh['question'] ? 'For ' . $sh['min_age'] . ' or older' : ucfirst( trim( (string) $sh['rule'] ) ) ),
			'people'  => $people,
			'n'       => $n,
			'waiting' => $gone || ! isset( $waits[ $id ] ) ? array() : $waits[ $id ],
			'over'    => $sh['unlimited'] ? 0 : max( 0, $n - $sh['needed'] ),
			'state'   => ogc_vol_shift_state( $y, $sh, $n ),
			'last'    => $last,
		);
	}
	$mm       = ogc_state_get( $y, 'vol-msgs' );
	$messages = array();
	foreach ( $mm ? (array) $mm['value'] : array() as $m ) {
		if ( $m['committee'] === $c ) {
			$messages[] = $m;
		}
	}
	if ( preg_match( '/young folk/i', $c ) ) {
		$out['yf'] = ogc_vol_yf_households( $y, $c );
		unset( $out['yf']['emails'] );
	}
	// For a head new to it each year: last year's note on top, this year's for next year at the end, and
	// what's been done (What to do ticks itself from these).
	$notes          = ogc_state_get( $y, 'vol-notes' );
	$notes          = $notes ? (array) $notes['value'] : array();
	$pnotes         = ogc_state_get( $y - 1, 'vol-notes' );
	$pnotes         = $pnotes ? (array) $pnotes['value'] : array();
	$out['note']    = isset( $notes[ $c ] ) ? $notes[ $c ] : null;
	$out['last_note'] = isset( $pnotes[ $c ] ) ? $pnotes[ $c ] : null;
	// Printed is ticked by the head ("Printed" in the page after the print dialog), never by opening it.
	$pr2            = ogc_state_get( $y, 'vol-printed-done' );
	$out['printed'] = $pr2 && ! empty( ( (array) $pr2['value'] )[ $c ] );
	$out['messaged'] = (bool) $messages;
	$days           = ogc_vol_days( $y );
	$out['begun']   = $days && ogc_vol_wall( $y )['date'] >= $days[0]['date'];
	$out['contact']  = array( 'email' => $comm[ $c ]['contact_email'], 'phone' => ogc_vol_phone_shown( $comm[ $c ]['contact_phone'] ), 'weekly' => 'no' !== strtolower( (string) $comm[ $c ]['weekly'] ) );
	// The committee's one instruction and its reminders (the page and the emails read them).
	$out['setup']    = array(
		'instruction' => trim( (string) $comm[ $c ]['instruction'] ),
		'week'        => ogc_vol_remind_on( $y, $c, 'week' ),
		'day'         => ogc_vol_remind_on( $y, $c, 'day' ),
		'can'         => ogc_vol_setup_can( $y, $c ),
	);
	// Who heads it, from the year's Members (with their emails, for the year's committee).
	$out['heads']    = $all ? ogc_vol_heads_of( $y, $c ) : array();
	$out['members_url'] = $all ? ogc_url( 'members', array( 'year' => $y ) ) : '';
	// Volunteer emails the per-address limit held back (the Mail log isn't the only place to see it).
	$emails = array();
	foreach ( $shifts as $sx ) {
		foreach ( $sx['people'] as $pp ) {
			if ( $pp['email'] ) {
				$emails[ strtolower( $pp['email'] ) ] = $pp['name'];
			}
		}
	}
	$out['refused']  = ogc_vol_refused( $y, $emails );
	// Messages a day per sender (ogc_vol_msgs_per_day): how many are left today.
	$out['msgs_left'] = ogc_vol_msgs_left( ogc_current_email() );
	$out['msgs_per_day'] = ogc_vol_msgs_per_day();
	// Heads' messages one volunteer gets a day at most (the page says "Already 4 today" by it).
	$out['msgs_per_person'] = ogc_vol_msgs_per_person();
	$out['shifts']   = $shifts;
	$out['since']    = $since;
	$out['left']     = $left;
	$out['messages'] = array_reverse( $messages );
	return rest_ensure_response( $out );
}

/* ================================================================== the list for Excel */

/** A cell as Excel should read it: never a formula (a typed "=…" or "+…" starts with an apostrophe). */
function ogc_vol_cell( $v ) {
	$v = (string) $v;
	if ( '' !== $v && preg_match( '/^[=+\-@\t\r]/', $v ) ) {
		$v = "'" . $v;
	}
	return preg_match( '/[",\r\n]/', $v ) ? '"' . str_replace( '"', '""', $v ) . '"' : $v;
}

function ogc_vol_lead_export( WP_REST_Request $req ) {
	$y      = (int) $req['year'];
	$all    = 'all' === $req->get_param( 'scope' );
	$c      = (string) $req->get_param( 'committee' );
	$gone   = ogc_vol_names_gone( $y );
	$map    = $gone ? array() : ogc_vol_seat_map( $y );
	$waits  = array();
	foreach ( $gone ? array() : ogc_records( $y, 'waits' ) as $w ) {
		$waits[ $w['data']['id'] ][] = $w;
	}
	$hm     = function ( $m ) {
		$m = ( ( $m % 1440 ) + 1440 ) % 1440;
		return sprintf( '%d:%02d %s', ( intdiv( $m, 60 ) % 12 ) ?: 12, $m % 60, $m >= 720 ? 'PM' : 'AM' );
	};
	// The rule's column is named after its question ("21 or older", "Certification"), when the shifts
	// in the file ask one question; "Rule" when they ask several.
	$asks = array();
	foreach ( ogc_vol_shifts( $y ) as $sh ) {
		if ( ( $all || $sh['committee'] === $c ) && $sh['rule'] ) {
			$asks[ ogc_vol_rule_label( $sh ) ] = true;
		}
	}
	$ask    = 1 === count( $asks ) ? key( $asks ) : ( $asks ? 'Rule' : 'Rule' );
	// "Shift day" beside the true Date: the day a head lists it under, its night said ("Fri night, May 28"
	// for Saturday's 12–3 AM; after the eighth critic, Oct 16). Rows run in that order already.
	// The second column is the Date's own weekday ("Saturday" for 2027-05-29), so it's named "Weekday", not
	// "Day", which read against "Fri night, May 28" as a second day (after the ninth critic, Oct 16). Same
	// place, same values: the columns keep their order every year.
	$lines  = array( array( 'Committee', 'Weekday', 'Date', 'Shift day', 'Start', 'End', 'Shift', 'Place', 'Name', 'Phone', 'Email', 'Household contact', 'Signed up', $ask, 'Note', 'Status' ) );
	foreach ( ogc_vol_shifts( $y ) as $id => $sh ) {
		if ( ! $all && $sh['committee'] !== $c ) {
			continue;
		}
		// All week: Start says so (the fixed value), End is the last day it covers.
		$base  = ! empty( $sh['allweek'] ) ? array( $sh['committee'], $sh['day'], $sh['date'], 'All week', 'All week', $sh['last_date'], $sh['role'], $sh['place_name'] ) : array( $sh['committee'], $sh['day'], $sh['date'], ogc_vol_subject_day( $y, $sh ), $hm( $sh['start'] ), $hm( $sh['end'] ), $sh['role'], $sh['place_name'] );
		$on    = isset( $map[ $id ] ) ? $map[ $id ] : array();
		foreach ( $on as $i => $seat ) {
			$d       = $seat['record']['data'];
			$status  = ! empty( $d['swap'] ) ? 'Swap open' : ( ! $sh['unlimited'] && $i >= $sh['needed'] ? 'Over' : ( 'head' === ( isset( $d['by'] ) ? $d['by'] : '' ) ? 'Added by head' : 'Signed up' ) );
			$when    = ! empty( $d['at'] ) && strtotime( $d['at'] ) ? gmdate( 'Y-m-d', strtotime( $d['at'] ) ) : substr( $seat['record']['created_at'], 0, 10 );
			$answer  = isset( $d['rule']['answer'] ) ? ( 'yes' === $d['rule']['answer'] ? 'Yes' : $d['rule']['answer'] ) : '';
			// The same phone as the head's list (ogc_vol_lead_person).
			$lines[] = array_merge( $base, array( $d['name'], ogc_vol_lead_person( $seat['record'] )['phone'], isset( $d['email'] ) ? $d['email'] : '', ! empty( $d['helper'] ) ? $d['helper'] : '', $when, $answer, isset( $d['note'] ) ? $d['note'] : '', $status ) );
		}
		for ( $k = count( $on ); ! $sh['unlimited'] && $k < $sh['needed']; $k++ ) {
			$lines[] = array_merge( $base, array( '', '', '', '', '', '', '', 'Open' ) );
		}
		foreach ( isset( $waits[ $id ] ) ? $waits[ $id ] : array() as $w ) {
			$lines[] = array_merge( $base, array( $w['data']['name'], isset( $w['data']['phone'] ) ? ogc_vol_phone_shown( $w['data']['phone'] ) : '', $w['email'], '', substr( $w['created_at'], 0, 10 ), '', '', 'Waitlist' ) );
		}
	}
	$csv = "\xEF\xBB\xBF" . implode( "\r\n", array_map( function ( $l ) {
		return implode( ',', array_map( 'ogc_vol_cell', $l ) );
	}, $lines ) ) . "\r\n";
	ogc_log( 'vol_export', $y, $all ? 'all' : $c, array( 'rows' => count( $lines ) - 1 ) );
	$name = ( $all ? 'volunteers' : trim( preg_replace( '/[^a-z0-9]+/', '-', strtolower( $c ) ), '-' ) . '-volunteers' ) . '-' . $y . '.csv';
	$res  = new WP_REST_Response( $csv, 200 );
	$res->header( 'Content-Type', 'text/csv; charset=utf-8' );
	$res->header( 'Content-Disposition', 'attachment; filename="' . $name . '"' );
	$res->header( 'X-Content-Type-Options', 'nosniff' );
	$res->header( 'Cache-Control', 'no-store, private' );
	return $res;
}

/* ================================================================== the head's changes */

/** The shift asked for, if it's one of the committees this person may change. */
function ogc_vol_lead_shift( $y, $id ) {
	$all = ogc_vol_shifts( $y );
	if ( ! isset( $all[ $id ] ) || ! ogc_vol_can_lead( $y, $all[ $id ]['committee'] ) ) {
		return null;
	}
	return $all[ $id ];
}

/** More people on a shift than its count (its places, counted as the seats it holds). */
function ogc_vol_past_count( $y, $sh ) {
	global $wpdb;
	if ( $sh['unlimited'] ) {
		return false;
	}
	return (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM ' . ogc_table( 'vol_seats' ) . ' WHERE year = %d AND shift = %s', $y, $sh['id'] ) ) > (int) $sh['needed'];
}

/** Add someone the head signed up: name and phone; email when they have one. Works before Publish (a
 * committee's regulars) and after the start (a walk-up). The count holds unless the head says over. */
function ogc_vol_lead_add( WP_REST_Request $req ) {
	global $wpdb;
	$y  = (int) $req['year'];
	$sh = ogc_vol_lead_shift( $y, (string) $req->get_param( 'shift' ) );
	if ( ! $sh ) {
		return ogc_rest_denied();
	}
	$name  = ogc_vol_clean_name( $req->get_param( 'name' ) );
	$phone = ogc_vol_clean_phone( $req->get_param( 'phone' ) );
	$raw   = trim( (string) $req->get_param( 'email' ) );
	$email = strtolower( sanitize_email( $raw ) );
	// Typed but not an email ("nope") is named at the field, never dropped quietly.
	$errs  = array_filter( array( 'name' => false !== strpos( $name, ' ' ) ? '' : 'First and last name', 'phone' => $phone ? '' : 'Enter a phone number', 'email' => '' === $raw || is_email( $email ) ? '' : 'Check the email' ) );
	if ( $errs ) {
		return ogc_vol_no( 'fields', 'Check the form.', array( 'fields' => $errs ), 400 );
	}
	$pk = ogc_vol_pkey( $email, $name, $phone );
	$b  = ogc_vol_busy( $y, $sh, $pk );
	if ( $b && ! $req->get_param( 'force' ) ) {
		return ogc_vol_no( 'busy', 'Busy', array( 'busy' => array( 'shift' => $b['id'], 'role' => $b['role'], 'until' => $b['end'] ) ) );
	}
	$seats = ogc_vol_take_seats( $y, $sh, array( $pk ), (bool) $req->get_param( 'over' ) );
	if ( is_wp_error( $seats ) ) {
		return ogc_vol_no( 'ogc_dup' === $seats->get_error_code() ? 'dup' : 'full', 'Not added', (array) $seats->get_error_data() );
	}
	// Signed up by someone else (the head): off the public list until they choose Show (one rule on every
	// path, after the fifth critic, Oct 15).
	$data = array( 'id' => $sh['id'], 'name' => $name, 'phone' => $phone, 'email' => $email, 'confirmed' => true, 'by' => 'head', 'for' => true, 'at' => gmdate( 'c', ogc_vol_now() ) );
	// Past the count only when the head chose it (over): marked so on the place, which the head's list
	// says ("Added past the count"; after the seventh critic, Oct 15).
	if ( ogc_vol_past_count( $y, $sh ) ) {
		$data['over'] = true;
	}
	$note = mb_substr( sanitize_text_field( (string) $req->get_param( 'note' ) ), 0, 200 );
	if ( $note ) {
		$data['note'] = $note;
	}
	$rid = ogc_record_insert( $y, 'signups', $data, $email, false, 'head' );
	$wpdb->update( ogc_table( 'vol_seats' ), array( 'record_id' => $rid ), array( 'id' => reset( $seats ) ), array( '%d' ), array( '%d' ) );
	ogc_vol_change( $y, $sh, 'joined', $name );
	if ( $email && false !== $req->get_param( 'notify' ) ) {
		ogc_vol_queue_person( $y, ogc_record_get( $rid ), 'head_added' );
	}
	ogc_log( 'vol_head_add', $y, $sh['committee'], array( 'id' => $rid ) );
	return rest_ensure_response( array( 'rid' => $rid ) );
}

/** Move someone to another of the committee's shifts: the new place first (atomic), then the old one
 * is let go. They're emailed when they have an email. */
function ogc_vol_lead_move( WP_REST_Request $req ) {
	global $wpdb;
	$y   = (int) $req['year'];
	$rec = ogc_record_get( (int) $req->get_param( 'id' ) );
	if ( ! $rec || 'signups' !== $rec['kind'] || (int) $rec['year'] !== $y ) {
		return ogc_vol_no( 'gone', 'Not found', array(), 404 );
	}
	$all  = ogc_vol_shifts( $y );
	$from = isset( $all[ $rec['data']['id'] ] ) ? $all[ $rec['data']['id'] ] : null;
	$to   = ogc_vol_lead_shift( $y, (string) $req->get_param( 'to' ) );
	if ( ! $to || ! $from || ! ogc_vol_can_lead( $y, $from['committee'] ) ) {
		return ogc_rest_denied();
	}
	$pk = ogc_vol_pkey( $rec['email'], $rec['data']['name'], isset( $rec['data']['phone'] ) ? $rec['data']['phone'] : '' );
	$b  = ogc_vol_busy( $y, $to, $pk, $rec['id'] );
	if ( $b && $b['id'] !== $from['id'] ) {
		return ogc_vol_no( 'busy', 'Busy', array( 'busy' => array( 'shift' => $b['id'], 'role' => $b['role'], 'until' => $b['end'] ) ) );
	}
	$seats = ogc_vol_take_seats( $y, $to, array( $pk ), (bool) $req->get_param( 'over' ) );
	if ( is_wp_error( $seats ) ) {
		return ogc_vol_no( 'ogc_dup' === $seats->get_error_code() ? 'dup' : 'full', 'Not moved', (array) $seats->get_error_data() );
	}
	ogc_vol_release_record( $rec['id'] );
	$wpdb->update( ogc_table( 'vol_seats' ), array( 'record_id' => $rec['id'] ), array( 'id' => reset( $seats ) ), array( '%d' ), array( '%d' ) );
	$d         = $rec['data'];
	$d['id']   = $to['id'];
	unset( $d['reminded'], $d['swap'], $d['over'] );
	if ( ogc_vol_past_count( $y, $to ) ) {
		$d['over'] = true;
	}
	ogc_record_update( $rec['id'], $d, $rec['email'] );
	ogc_vol_change( $y, $from, 'moved_out', $d['name'] );
	ogc_vol_change( $y, $to, 'joined', $d['name'] );
	ogc_vol_notify_waitlist( $y, $from );
	if ( $rec['email'] && ! $rec['sample'] ) {
		ogc_vol_queue_person( $y, ogc_record_get( $rec['id'] ), 'changed', array( 'was' => array( 'date' => $from['date'], 'eve' => ogc_vol_eve_date( $from ), 'start' => $from['start'], 'end' => $from['end'], 'role' => $from['role'], 'committee' => $from['committee'] ) ) );
	}
	ogc_log( 'vol_head_move', $y, $from['committee'], array( 'id' => $rec['id'] ) );
	return rest_ensure_response( array( 'moved' => $rec['id'], 'from' => $from['id'] ) );
}

/** Off a shift (a duplicate, a jokester, someone who called). The person hears only when the head
 * says so; the people waiting do. Undo: lead/restore. */
function ogc_vol_lead_remove( WP_REST_Request $req ) {
	$y   = (int) $req['year'];
	$rec = ogc_record_get( (int) $req->get_param( 'id' ) );
	if ( ! $rec || (int) $rec['year'] !== $y ) {
		return ogc_vol_no( 'gone', 'Not found', array(), 404 );
	}
	ogc_record_delete( $rec['id'] );
	if ( 'waits' === $rec['kind'] ) {
		return rest_ensure_response( array( 'removed' => $rec['id'] ) );
	}
	ogc_vol_release_record( $rec['id'] );
	$all = ogc_vol_shifts( $y );
	if ( isset( $all[ $rec['data']['id'] ] ) ) {
		$sh = $all[ $rec['data']['id'] ];
		ogc_vol_change( $y, $sh, 'removed', $rec['data']['name'] );
		if ( ogc_vol_now() < $sh['start_ts'] ) {
			ogc_vol_notify_waitlist( $y, $sh );
		}
	}
	if ( $req->get_param( 'notify' ) ) {
		ogc_vol_queue_person( $y, $rec, 'left', array( 'by_head' => true ) );
	}
	ogc_log( 'vol_head_remove', $y, 'signups', array( 'id' => $rec['id'] ) );
	return rest_ensure_response( array( 'removed' => $rec['id'] ) );
}

/** Undo a Remove: the same person back in a place (if one is still free). */
function ogc_vol_lead_restore( WP_REST_Request $req ) {
	global $wpdb;
	$y   = (int) $req['year'];
	$rec = ogc_record_get( (int) $req->get_param( 'id' ), true );
	if ( ! $rec || (int) $rec['year'] !== $y || empty( $rec['deleted_at'] ) ) {
		return ogc_vol_no( 'gone', 'Not found', array(), 404 );
	}
	if ( 'signups' === $rec['kind'] ) {
		$all = ogc_vol_shifts( $y );
		$sh  = isset( $all[ $rec['data']['id'] ] ) ? $all[ $rec['data']['id'] ] : null;
		if ( ! $sh ) {
			return ogc_vol_no( 'gone', 'Not found', array(), 404 );
		}
		// Never past the count (after the seventh critic, Oct 15: an Undo of a head's Remove took the place
		// back even after someone else had it, so a shift read "5 of 4 · 1 over" with no one choosing it).
		$seats = ogc_vol_take_seats( $y, $sh, array( ogc_vol_pkey( $rec['email'], $rec['data']['name'], isset( $rec['data']['phone'] ) ? $rec['data']['phone'] : '' ) ), ! empty( $rec['data']['over'] ) );
		if ( is_wp_error( $seats ) ) {
			return ogc_vol_no( 'full', 'Full now · Not undone', (array) $seats->get_error_data() );
		}
		$wpdb->update( ogc_table( 'vol_seats' ), array( 'record_id' => $rec['id'] ), array( 'id' => reset( $seats ) ), array( '%d' ), array( '%d' ) );
	}
	$wpdb->query( $wpdb->prepare( 'UPDATE ' . ogc_table( 'records' ) . ' SET deleted_at = NULL WHERE id = %d', $rec['id'] ) );
	ogc_log( 'vol_head_restore', $y, $rec['kind'], array( 'id' => $rec['id'] ) );
	return rest_ensure_response( array( 'restored' => $rec['id'] ) );
}

/** Offer the place to one person waiting: an email with a one-tap Join. */
function ogc_vol_lead_offer( WP_REST_Request $req ) {
	$y = (int) $req['year'];
	$w = ogc_record_get( (int) $req->get_param( 'id' ) );
	if ( ! $w || 'waits' !== $w['kind'] || (int) $w['year'] !== $y ) {
		return ogc_vol_no( 'gone', 'Not found', array(), 404 );
	}
	ogc_vol_queue( $y, 'opened', $w['email'], array( 'shift' => $w['data']['id'], 'name' => $w['data']['name'], 'wait' => $w['id'] ) );
	ogc_log( 'vol_head_offer', $y, 'waits', array( 'id' => $w['id'] ) );
	return rest_ensure_response( array( 'offered' => $w['id'] ) );
}

/** Here: ticked by the head as people arrive. */
function ogc_vol_lead_here( WP_REST_Request $req ) {
	$rec = ogc_record_get( (int) $req->get_param( 'id' ) );
	if ( ! $rec || 'signups' !== $rec['kind'] || (int) $rec['year'] !== (int) $req['year'] ) {
		return ogc_vol_no( 'gone', 'Not found', array(), 404 );
	}
	$d         = $rec['data'];
	$d['here'] = (bool) $req->get_param( 'here' );
	ogc_record_update( $rec['id'], $d, $rec['email'] );
	return rest_ensure_response( array( 'here' => $d['here'] ) );
}

/** A message to the committee's volunteers: everyone, one day's, or one shift's. One email each (no
 * one sees another's address), replies to the sender, a copy to the sender. Kept in the committee's
 * Sent list. Twenty messages a day per sender, and no volunteer gets more than four heads' messages in
 * a day (2026: Transportation sent nine on May 28, one a shift, to 87 people; the old five a day would
 * have stopped it; a stolen sign-in still can't flood anyone's inbox). */
function ogc_vol_lead_message( WP_REST_Request $req ) {
	$y       = (int) $req['year'];
	$c       = (string) $req->get_param( 'committee' );
	$to      = (string) $req->get_param( 'to' );
	$subject = mb_substr( sanitize_text_field( (string) $req->get_param( 'subject' ) ), 0, 140 );
	$body    = mb_substr( sanitize_textarea_field( (string) $req->get_param( 'body' ) ), 0, 5000 );
	if ( '' === $subject || '' === $body ) {
		return ogc_vol_no( 'fields', 'Check the form.', array( 'fields' => array_filter( array( 'subject' => $subject ? '' : 'Add a subject', 'body' => $body ? '' : 'Write the message' ) ) ), 400 );
	}
	$me = ogc_current_email();
	if ( ! ogc_vol_rate( 'msg|' . $me . '|' . gmdate( 'Y-m-d' ), ogc_vol_msgs_per_day(), DAY_IN_SECONDS ) ) {
		return ogc_vol_no( 'slow', ogc_vol_msgs_per_day() . ' messages a day', array(), 429 );
	}
	$emails = array();
	$call   = array();
	// The people under each address (a couple under one email is two people, one email; a person on two
	// of the message's shifts is one), and who has no email, each once (after the ninth critic, Oct 16:
	// "Sent · 3 people" for four, and "To: 0 volunteers" with the one person to call unnamed).
	$names  = array();
	$callk  = array();
	// The year's committee to every committee's contact and heads (members only).
	if ( 'heads' === $to ) {
		if ( ! ogc_vol_lead_all( $y ) ) {
			return ogc_rest_denied();
		}
		$c = '';
		// The same list the All table shows: Members marked Head, and each committee's contact.
		foreach ( ogc_vol_heads_emails( $y ) as $e ) {
			$emails[ $e ] = true;
		}
	}
	foreach ( 'heads' === $to ? array() : ogc_vol_seat_map( $y ) as $id => $seats ) {
		$sh = ogc_vol_shifts( $y )[ $id ] ?? null;
		if ( ! $sh || $sh['committee'] !== $c ) {
			continue;
		}
		// A day is the day and its night: Message › Fri reaches Friday's 12–3 AM, never Saturday's (the
		// volunteers' rule, ogc_vol_eve_date; after the eighth critic, Oct 16).
		if ( 0 === strpos( $to, 'day:' ) && ogc_vol_eve_date( $sh ) !== substr( $to, 4 ) ) {
			continue;
		}
		if ( 0 === strpos( $to, 'shift:' ) && $id !== substr( $to, 6 ) ) {
			continue;
		}
		foreach ( $seats as $s ) {
			$d  = $s['record']['data'];
			$nm = strtolower( trim( preg_replace( '/\s+/', ' ', (string) ( isset( $d['name'] ) ? $d['name'] : '' ) ) ) );
			// Sample people count as reached (the page said "Send · 40 people") but get no mail.
			if ( ! empty( $d['email'] ) ) {
				$e = strtolower( $d['email'] );
				$emails[ $e ] = empty( $s['record']['sample'] ) || ! empty( $emails[ $e ] );
				$names[ $e ][ $nm ] = true;
			} else {
				// To call: "Lois B. · 555-0190" (the phone the head's list shows; no phone, the name alone),
				// each person once however many of the message's shifts they're on.
				$ph = ogc_vol_lead_person( $s['record'] )['phone'];
				$k  = $nm . '|' . preg_replace( '/\D+/', '', $ph );
				if ( ! isset( $callk[ $k ] ) ) {
					$callk[ $k ] = true;
					$call[]      = ogc_vol_first_l( isset( $d['name'] ) ? $d['name'] : '' ) . ( '' !== $ph ? ' · ' . $ph : '' );
				}
			}
		}
	}
	// Signed as the sender, by name and role: "Phoebe L. · Transportation head", "Nathan K. · Committee of Arrangements".
	$from = ogc_vol_sender_line( $y, $c );
	// Each volunteer: at most ogc_vol_msgs_per_person() heads' messages a day; past that, skipped (and said).
	$skipped = 0;
	$held    = array();
	foreach ( 'heads' === $to ? array() : array_keys( array_filter( $emails ) ) as $e ) {
		if ( ! ogc_vol_rate( 'msgto|' . $e . '|' . gmdate( 'Y-m-d' ), ogc_vol_msgs_per_person(), DAY_IN_SECONDS ) ) {
			$emails[ $e ] = false;
			$held[ $e ]   = true;
			$skipped++;
		}
	}
	// Reached by email: the addresses not held back (samples count, as the page counted them), and the
	// people under them, each by name once ("4 people · 3 emails").
	$n_emails = count( $emails ) - $skipped;
	$n_people = 0;
	foreach ( $emails as $e => $real ) {
		if ( ! isset( $held[ $e ] ) ) {
			$n_people += 'heads' === $to || empty( $names[ $e ] ) ? 1 : count( $names[ $e ] );
		}
	}
	// "4 people · 3 emails", "1 person", "4 people" when each has their own; '' when nobody had an email.
	$sent_words = ! $n_people ? '' : $n_people . ( 1 === $n_people ? ' person' : ' people' ) . ( $n_emails !== $n_people ? ' · ' . $n_emails . ( 1 === $n_emails ? ' email' : ' emails' ) : '' );
	foreach ( array_keys( array_filter( $emails ) ) as $e ) {
		if ( 'heads' === $to ) {
			ogc_vol_queue( $y, 'heads', $e, array( 'subject' => $subject, 'body' => $body, 'from' => $from, 'reply_to' => $me ) );
		} else {
			ogc_vol_queue( $y, 'message', $e, array( 'committee' => $c, 'to' => $to ?: 'all', 'subject' => $subject, 'body' => $body, 'from' => $from, 'reply_to' => $me ) );
		}
	}
	if ( false !== $req->get_param( 'copy' ) && $me ) {
		// Which of the committee's volunteers, said as the To was chosen (after the second critic, Oct 15):
		// a shift by its job, day and time ("Golf cart driver · Sat, May 29 · 11 AM–3 PM"), a day by its
		// date ("Transportation · Sat, May 29"; a night is its evening's day), everyone by the committee.
		$one  = 0 === strpos( $to, 'shift:' ) ? ( ogc_vol_shifts( $y )[ substr( $to, 6 ) ] ?? null ) : null;
		$what = $one ? $one['role'] . ' · ' . ( ! empty( $one['allweek'] ) ? 'All week · ' . ogc_vol_week_range( $one ) : ogc_vol_subject_day( $y, $one ) . ' · ' . ogc_vol_span_of( $one ) )
			: ( 0 === strpos( $to, 'day:' ) ? $c . ' · ' . gmdate( 'D, M j', strtotime( substr( $to, 4 ) . ' 12:00:00 UTC' ) ) : $c );
		// The Copy's facts (after the ninth critic, Oct 16: "To: 0 volunteers · …", and nobody to call named):
		// To says which only, Sent how many by email ("4 people · 3 emails"; nothing when nobody had an
		// email), Call each person with no email ("Lois B. · 555-0190"). Never a zero.
		ogc_vol_queue( $y, 'copy', $me, array(
			'subject' => $subject,
			'body'    => $body,
			'sent_to' => 'heads' === $to ? 'Committee heads and contacts' : $what,
			'sent'    => $sent_words,
			'call'    => array_slice( $call, 0, 50 ),
		) );
	}
	$mm   = ogc_state_get( $y, 'vol-msgs' );
	$list = $mm ? (array) $mm['value'] : array();
	$list[] = array( 'at' => ogc_now(), 'committee' => $c, 'to' => $to ?: 'all', 'n' => count( $emails ), 'people' => $n_people, 'subject' => $subject, 'by' => strtok( $from, '·' ) ? trim( strtok( $from, '·' ) ) : '' );
	ogc_state_put( $y, 'vol-msgs', array_slice( $list, -200 ) );
	ogc_log( 'vol_message', $y, $c, array( 'n' => count( $emails ) ) );
	// Real mail goes out in batches from the timed job; the page says how many and who to call.
	// queued: the addresses reached (as before); people: the people under them, each once; emails: the
	// addresses (= queued); call: "First L. · phone" for each person with no email.
	return rest_ensure_response( array( 'queued' => $n_emails, 'skipped' => $skipped, 'call' => array_slice( $call, 0, 50 ), 'left' => ogc_vol_msgs_left( $me ), 'people' => $n_people, 'emails' => $n_emails ) );
}

/** Messages a head may send a day (filter ogc_vol_messages_per_day). */
function ogc_vol_msgs_per_day() {
	return max( 1, (int) apply_filters( 'ogc_vol_messages_per_day', 20 ) );
}

/** Heads' messages one volunteer gets a day at most (filter ogc_vol_messages_per_person). */
function ogc_vol_msgs_per_person() {
	return max( 1, (int) apply_filters( 'ogc_vol_messages_per_person', 4 ) );
}

/** How many messages this sender has left today. */
function ogc_vol_msgs_left( $email ) {
	return max( 0, ogc_vol_msgs_per_day() - (int) get_transient( 'ogc_vol_rl_' . md5( 'msg|' . $email . '|' . gmdate( 'Y-m-d' ) ) ) );
}

/** The committee's contact: the role email (where notices go, the reply-to), the role phone (shown to
 * the public as the committee's), the heads who may open its list, and the weekly email. Members set
 * the heads; a head may set the rest for their own committee. */
function ogc_vol_lead_contact( WP_REST_Request $req ) {
	$y    = (int) $req['year'];
	$c    = (string) $req->get_param( 'committee' );
	$f    = ogc_file_get( $y, 'committees' );
	$rows = $f ? $f['rows'] : array();
	$at   = -1;
	foreach ( $rows as $i => $r ) {
		if ( isset( $r['name'] ) && $r['name'] === $c ) {
			$at = $i;
		}
	}
	if ( $at < 0 ) {
		$rows[] = array( 'name' => $c, 'contact_email' => '', 'contact_phone' => '', 'heads' => '', 'weekly' => 'yes', 'order' => '' );
		$at     = count( $rows ) - 1;
	}
	$email = $req->get_param( 'email' );
	if ( null !== $email ) {
		$email = strtolower( sanitize_email( (string) $email ) );
		if ( '' !== $email && ! is_email( $email ) ) {
			return ogc_vol_no( 'fields', 'Check the form.', array( 'fields' => array( 'email' => 'Check the email' ) ), 400 );
		}
		$rows[ $at ]['contact_email'] = $email;
	}
	if ( null !== $req->get_param( 'phone' ) ) {
		$rows[ $at ]['contact_phone'] = mb_substr( sanitize_text_field( (string) $req->get_param( 'phone' ) ), 0, 32 );
	}
	if ( null !== $req->get_param( 'weekly' ) ) {
		$rows[ $at ]['weekly'] = $req->get_param( 'weekly' ) ? 'yes' : 'no';
	}
	if ( null !== $req->get_param( 'heads' ) && ogc_is_member( $y ) ) {
		$hs = array_filter( array_map( function ( $e ) {
			$e = strtolower( sanitize_email( trim( $e ) ) );
			return is_email( $e ) ? $e : '';
		}, preg_split( '/[\s,|;]+/', (string) $req->get_param( 'heads' ) ) ) );
		$rows[ $at ]['heads'] = implode( '|', array_unique( $hs ) );
	}
	$v = ogc_file_put( $y, 'committees', $rows, $f ? $f['version'] : 0, array( 'name', 'contact_email', 'contact_phone', 'heads', 'weekly', 'order' ) );
	if ( is_wp_error( $v ) ) {
		return $v;
	}
	ogc_log( 'vol_contact', $y, $c, array( 'version' => $v ) );
	$cm = ogc_vol_committees( $y );
	return rest_ensure_response( array( 'email' => $cm[ $c ]['contact_email'], 'phone' => $cm[ $c ]['contact_phone'], 'weekly' => 'no' !== $cm[ $c ]['weekly'], 'heads' => ogc_is_member( $y ) ? $cm[ $c ]['heads'] : '' ) );
}

/** Printed (what: done, the head said so after the print dialog: What to do ticks), or seen (what:
 * seen, Downloaded or the changes line's Clear: what's new is marked from now on, for this person). */
function ogc_vol_lead_printed( WP_REST_Request $req ) {
	$y  = (int) $req['year'];
	$c  = (string) $req->get_param( 'committee' );
	if ( 'done' === $req->get_param( 'what' ) ) {
		$d       = ogc_state_get( $y, 'vol-printed-done' );
		$dv      = $d ? (array) $d['value'] : array();
		$dv[ $c ] = ogc_now();
		ogc_state_put( $y, 'vol-printed-done', $dv );
		return rest_ensure_response( array( 'printed' => true ) );
	}
	$s  = ogc_state_get( $y, 'vol-printed' );
	$pr = $s ? (array) $s['value'] : array();
	$pr[ $c ][ ogc_current_email() ] = ogc_now();
	ogc_state_put( $y, 'vol-printed', $pr );
	return rest_ensure_response( array( 'since' => $pr[ $c ][ ogc_current_email() ] ) );
}

/** Parents with Young Folks in the halls (docs/16: one supervision shift asked of each): how many
 * households, how many have someone on the committee's shifts, and (for Remind) who hasn't. */
function ogc_vol_yf_households( $y, $c ) {
	$on = array();
	foreach ( ogc_vol_seat_map( $y ) as $id => $seats ) {
		$sh = ogc_vol_shifts( $y )[ $id ] ?? null;
		if ( $sh && $sh['committee'] === $c ) {
			foreach ( $seats as $s ) {
				$on[ $s['record']['email'] ] = true;
			}
		}
	}
	$total  = 0;
	$signed = 0;
	$not    = array();
	foreach ( ogc_records( $y, 'registrations' ) as $r ) {
		$p      = isset( $r['data']['people'] ) ? (array) $r['data']['people'] : array();
		$yf     = array_filter( $p, function ( $x ) { return ! empty( $x['yf'] ) || ( isset( $x['kind'] ) && 'yf' === $x['kind'] ); } );
		$adults = array_filter( $p, function ( $x ) { return isset( $x['kind'] ) ? 'adult' === $x['kind'] : ( isset( $x['band'] ) && 'adult' === $x['band'] && empty( $x['yf'] ) ); } );
		if ( ! $yf || ! $adults ) {
			continue;
		}
		$total++;
		if ( isset( $on[ $r['email'] ] ) ) {
			$signed++;
		} elseif ( $r['email'] && ! $r['sample'] ) {
			$not[] = $r['email'];
		} else {
			$not[] = '';
		}
	}
	return array( 'total' => $total, 'signed' => $signed, 'not' => $total - $signed, 'emails' => array_values( array_filter( $not ) ) );
}

/** Remind the parents not yet on a shift: one email each, at most once a day. */
function ogc_vol_lead_remind( WP_REST_Request $req ) {
	$y = (int) $req['year'];
	$c = (string) $req->get_param( 'committee' );
	if ( ! preg_match( '/young folk/i', $c ) ) {
		return ogc_vol_no( 'gone', 'Not found', array(), 404 );
	}
	$k = 'vol-remind';
	$s = ogc_state_get( $y, $k );
	if ( $s && substr( (string) $s['value'], 0, 10 ) === gmdate( 'Y-m-d' ) ) {
		return ogc_vol_no( 'slow', 'Sent today', array(), 429 );
	}
	$h = ogc_vol_yf_households( $y, $c );
	foreach ( $h['emails'] as $e ) {
		ogc_vol_queue( $y, 'remind', $e, array( 'committee' => $c ) );
	}
	ogc_state_put( $y, $k, ogc_now() );
	ogc_log( 'vol_remind', $y, $c, array( 'n' => count( $h['emails'] ) ) );
	return rest_ensure_response( array( 'queued' => count( $h['emails'] ) ) );
}

/* ================================================================== heads, notes, a person put right */

/** Does a Members committee key mean this shift committee? The same key, or a name the year's
 * committees and Members spell differently (Food ↔ Dining hall; filter ogc_vol_committee_aliases). */
function ogc_vol_committee_is( $member_key, $committee ) {
	$k = function_exists( 'ogc_committee_key' ) ? ogc_committee_key( $committee ) : strtolower( trim( $committee ) );
	if ( $member_key === $k ) {
		return true;
	}
	$alias = (array) apply_filters( 'ogc_vol_committee_aliases', array( 'food' => 'dining hall', 'kitchen' => 'dining hall', 'meals' => 'dining hall', 'dining' => 'dining hall', 'transport' => 'transportation', 'medical' => 'first aid', 'nursing' => 'first aid' ) );
	return isset( $alias[ $member_key ] ) && $alias[ $member_key ] === $k;
}

/** The heads of a committee: the year's Members on that committee marked Head (docs/23: one place says
 * who runs a committee). Nobody marked: none (Add head), never "everyone on it". Each {name: "Ruth K."
 * (or the address masked when Members has no name), email}. */
function ogc_vol_heads_of( $year, $committee ) {
	$out = array();
	if ( ! function_exists( 'ogc_members_list' ) || ! function_exists( 'ogc_member_committee_keys' ) ) {
		return $out;
	}
	foreach ( ogc_members_list( $year ) as $m ) {
		if ( empty( $m['head'] ) || ( function_exists( 'ogc_member_active' ) && ! ogc_member_active( $m ) ) ) {
			continue;
		}
		foreach ( ogc_member_committee_keys( $m ) as $k ) {
			if ( ogc_vol_committee_is( $k, $committee ) ) {
				$out[] = array( 'name' => $m['name'] ? ogc_vol_first_l( $m['name'] ) : ( function_exists( 'ogc_mask_email' ) ? ogc_mask_email( $m['email'] ) : '' ), 'email' => $m['email'] );
				break;
			}
		}
	}
	return $out;
}

/** Everyone "Message all heads" reaches: each committee's heads (Members) and its role contact. */
function ogc_vol_heads_emails( $year ) {
	$out = array();
	foreach ( ogc_vol_committees( $year ) as $cm ) {
		foreach ( ogc_vol_heads_of( $year, $cm['name'] ) as $h ) {
			$out[ strtolower( $h['email'] ) ] = true;
		}
		if ( is_email( $cm['contact_email'] ) ) {
			$out[ strtolower( $cm['contact_email'] ) ] = true;
		}
	}
	return array_keys( $out );
}

/** Who a head's message is from: "Phoebe L. · Transportation head", "Nathan K. · Committee of
 * Arrangements" (the year's COA), else the name and committee. */
function ogc_vol_sender_line( $year, $committee ) {
	$me = ogc_current_email();
	$u  = wp_get_current_user();
	$n  = $u && $u->ID ? ( function_exists( 'ogc_person_name' ) ? ogc_person_name( $u->ID ) : $u->display_name ) : '';
	$n  = $n ? ogc_vol_first_l( $n ) : '';
	$m  = function_exists( 'ogc_member_find' ) ? ogc_member_find( (int) $year, $me ) : null;
	if ( $m && 'coa' === $m['role'] ) {
		$role = 'Committee of Arrangements';
	} elseif ( $committee && ( in_array( $me, wp_list_pluck( ogc_vol_heads_of( $year, $committee ), 'email' ), true ) || in_array( $committee, ogc_vol_headed( $year ), true ) ) ) {
		$role = $committee . ' head';
	} else {
		$role = $committee ? $committee . ' committee' : $year . ' Annual Conference';
	}
	return trim( $n . ( $n ? ' · ' : '' ) . $role );
}

/** The rule as a column's or a line's name: "21 or older", "Certification", "Agreed". */
function ogc_vol_rule_label( $sh ) {
	if ( $sh['question'] ) {
		// An age with it is said too ("21 or older · Certification"; after the eighth critic, Oct 16).
		return ( $sh['min_age'] ? $sh['min_age'] . ' or older · ' : '' ) . ( preg_match( '/certif/i', $sh['rule'] . ' ' . implode( ' ', $sh['question'] ) ) ? 'Certification' : 'Answer' );
	}
	return $sh['min_age'] ? $sh['min_age'] . ' or older' : 'Agreed';
}

/** Volunteer emails to these people the per-address limit refused in the last two weeks: by name. */
function ogc_vol_refused( $year, $emails ) {
	global $wpdb;
	if ( ! $emails || ! function_exists( 'ogc_mail_rows' ) ) {
		return array();
	}
	$keys = array_slice( array_keys( $emails ), 0, 500 );
	$ph   = implode( ',', array_fill( 0, count( $keys ), '%s' ) );
	$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT to_email, MAX(at) AS at, COUNT(*) AS n FROM ' . ogc_table( 'mail' ) . " WHERE status = 'refused' AND year = %d AND at > %s AND to_email IN ($ph) GROUP BY to_email", array_merge( array( (int) $year, gmdate( 'Y-m-d H:i:s', time() - 14 * DAY_IN_SECONDS ) ), $keys ) ), ARRAY_A ); // phpcs:ignore -- placeholders built above.
	$out  = array();
	foreach ( (array) $rows as $r ) {
		$out[] = array( 'name' => ogc_vol_first_l( $emails[ $r['to_email'] ] ), 'n' => (int) $r['n'], 'at' => $r['at'] );
	}
	return $out;
}

/** A note for next year's committee (one per committee a year, as its heads write it); '' removes it. */
function ogc_vol_lead_note( WP_REST_Request $req ) {
	$y    = (int) $req['year'];
	$c    = (string) $req->get_param( 'committee' );
	$text = mb_substr( sanitize_textarea_field( (string) $req->get_param( 'text' ) ), 0, 2000 );
	$s    = ogc_state_get( $y, 'vol-notes' );
	$n    = $s ? (array) $s['value'] : array();
	if ( '' === trim( $text ) ) {
		unset( $n[ $c ] );
	} else {
		$u       = wp_get_current_user();
		$n[ $c ] = array( 'text' => $text, 'at' => ogc_now(), 'by' => $u && $u->ID ? ogc_vol_first_l( $u->display_name ) : '' );
	}
	ogc_state_put( $y, 'vol-notes', $n );
	ogc_log( 'vol_note', $y, $c, array() );
	return rest_ensure_response( array( 'note' => isset( $n[ $c ] ) ? $n[ $c ] : null ) );
}

/** Edit: a person's name, phone or email put right by the head. A new email on an unconfirmed sign-up
 * gets the confirmation; the place stays the same. */
function ogc_vol_lead_edit( WP_REST_Request $req ) {
	global $wpdb;
	$y   = (int) $req['year'];
	$rec = ogc_record_get( (int) $req->get_param( 'id' ) );
	if ( ! $rec || 'signups' !== $rec['kind'] || (int) $rec['year'] !== $y ) {
		return ogc_vol_no( 'gone', 'Not found', array(), 404 );
	}
	$name  = ogc_vol_clean_name( $req->get_param( 'name' ) );
	$phone = ogc_vol_clean_phone( $req->get_param( 'phone' ) );
	$raw   = trim( (string) $req->get_param( 'email' ) );
	$email = strtolower( sanitize_email( $raw ) );
	// Typed but not an email ("nope") is named at the field, never dropped quietly.
	$errs  = array_filter( array( 'name' => false !== strpos( $name, ' ' ) ? '' : 'First and last name', 'phone' => $phone ? '' : 'Enter a phone number', 'email' => '' === $raw || is_email( $email ) ? '' : 'Check the email' ) );
	if ( $errs ) {
		return ogc_vol_no( 'fields', 'Check the form.', array( 'fields' => $errs ), 400 );
	}
	$d       = $rec['data'];
	$changed = $email !== $rec['email'];
	$d['name']  = $name;
	$d['phone'] = $phone;
	$d['email'] = $email;
	ogc_record_update( $rec['id'], $d, $email );
	$wpdb->update( ogc_table( 'vol_seats' ), array( 'pkey' => ogc_vol_pkey( $email, $name, $phone ) ), array( 'record_id' => (int) $rec['id'] ), array( '%s' ), array( '%d' ) );
	if ( $changed && $email ) {
		ogc_vol_outbox_drop( $rec['id'] );
		ogc_vol_queue_confirm( $y, $email, array( (int) $rec['id'] ), ! empty( $d['confirmed'] ), 0 );
	}
	ogc_log( 'vol_head_edit', $y, 'signups', array( 'id' => $rec['id'] ) );
	return rest_ensure_response( array( 'edited' => (int) $rec['id'] ) );
}

/** Resend: the confirmation (with its Confirm link while unconfirmed, and the calendar file) again. */
function ogc_vol_lead_resend( WP_REST_Request $req ) {
	$y   = (int) $req['year'];
	$rec = ogc_record_get( (int) $req->get_param( 'id' ) );
	if ( ! $rec || 'signups' !== $rec['kind'] || (int) $rec['year'] !== $y || ! is_email( $rec['email'] ) ) {
		return ogc_vol_no( 'gone', 'Not found', array(), 404 );
	}
	if ( ! ogc_vol_rate( 'leadresend|' . $rec['id'], 1, MINUTE_IN_SECONDS ) ) {
		return ogc_vol_no( 'slow', 'Sent · Just now', array(), 429 );
	}
	ogc_vol_queue_confirm( $y, $rec['email'], array( (int) $rec['id'] ), ! empty( $rec['data']['confirmed'] ), 0, true );
	ogc_log( 'vol_head_resend', $y, 'signups', array( 'id' => $rec['id'] ) );
	return rest_ensure_response( array( 'sent' => true ) );
}

/** May this person set the committee's instruction and reminders? The COA, and the committee's heads
 * (Members marked Head; committees.csv's old heads list too). The committee's other people see them. */
function ogc_vol_setup_can( $year, $committee ) {
	if ( ogc_vol_lead_all( $year ) ) {
		return true;
	}
	$me = ogc_current_email();
	if ( ! $me ) {
		return false;
	}
	foreach ( ogc_vol_heads_of( $year, $committee ) as $h ) {
		if ( strtolower( (string) $h['email'] ) === $me ) {
			return true;
		}
	}
	return in_array( $committee, ogc_vol_headed( $year ), true );
}

/**
 * The committee's one instruction for every shift, and which reminders go. Body: { committee,
 * instruction? (one line, at most 200 characters; empty takes it away), week?, day? (true or false) }.
 * Kept in committees.csv (columns instruction and remind: "week|day", "week", "day" or "none"), which the
 * pickup carries to next year's committee with the rest of the row.
 */
function ogc_vol_lead_setup( WP_REST_Request $req ) {
	$y = (int) $req['year'];
	$c = (string) $req->get_param( 'committee' );
	if ( '' === $c || ! ogc_vol_setup_can( $y, $c ) ) {
		return ogc_rest_denied();
	}
	for ( $try = 0; $try < 3; $try++ ) {
		$f    = ogc_file_get( $y, 'committees' );
		$rows = $f ? $f['rows'] : array();
		$at   = -1;
		foreach ( $rows as $i => $r ) {
			if ( isset( $r['name'] ) && $r['name'] === $c ) {
				$at = $i;
			}
		}
		if ( $at < 0 ) {
			$rows[] = array( 'name' => $c, 'contact_email' => '', 'contact_phone' => '', 'heads' => '', 'weekly' => 'yes', 'order' => '' );
			$at     = count( $rows ) - 1;
		}
		if ( null !== $req->get_param( 'instruction' ) ) {
			$t = trim( preg_replace( '/\s+/', ' ', sanitize_text_field( (string) $req->get_param( 'instruction' ) ) ) );
			if ( mb_strlen( $t ) > 200 ) {
				return ogc_vol_no( 'fields', 'Check the form.', array( 'fields' => array( 'instruction' => '200 characters at most' ) ), 400 );
			}
			$rows[ $at ]['instruction'] = $t;
		}
		$week = null !== $req->get_param( 'week' ) ? (bool) $req->get_param( 'week' ) : ogc_vol_remind_on( $y, $c, 'week' );
		$day  = null !== $req->get_param( 'day' ) ? (bool) $req->get_param( 'day' ) : ogc_vol_remind_on( $y, $c, 'day' );
		$rows[ $at ]['remind'] = $week && $day ? 'week|day' : ( $week ? 'week' : ( $day ? 'day' : 'none' ) );
		$v = ogc_file_put( $y, 'committees', $rows, $f ? $f['version'] : 0 );
		if ( ! is_wp_error( $v ) ) {
			ogc_log( 'vol_setup', $y, $c, array( 'remind' => $rows[ $at ]['remind'], 'instruction' => '' !== (string) ( isset( $rows[ $at ]['instruction'] ) ? $rows[ $at ]['instruction'] : '' ) ) );
			return rest_ensure_response( array(
				'instruction' => isset( $rows[ $at ]['instruction'] ) ? (string) $rows[ $at ]['instruction'] : '',
				'week'        => $week,
				'day'         => $day,
				'can'         => true,
			) );
		}
	}
	return $v;
}

/* ================================================================== Home: the volunteers, in the last weeks */

/**
 * A committee with shifts, from six weeks before the Conference: "Helpers · 38 open", and the day with
 * the most places open ("Tuesday short · 12 open"). In the last four weeks it leads a head's Home (the
 * requests went to the campus long before; after the critic, Oct 15). The COA gets every committee's,
 * not leading. Counted from the places, never guessed; nothing open, nothing said.
 */
function ogc_vol_home_need( $year, $ckey, $today ) {
	if ( ! function_exists( 'ogc_app_days_to' ) || ! ogc_vol_posted( $year ) || ogc_vol_closed( $year ) ) {
		return null;
	}
	$days = ogc_vol_days( $year );
	if ( ! $days ) {
		return null;
	}
	$to = ogc_app_days_to( $days[0]['date'], $today );
	if ( $to > 42 || $to < 0 ) {
		return null;
	}
	$names = array();
	foreach ( ogc_vol_committees( $year ) as $c ) {
		if ( 'coa' === $ckey || ogc_committee_key( $c['name'] ) === $ckey ) {
			$names[] = $c['name'];
		}
	}
	$map  = ogc_vol_seat_map( $year );
	$open = 0;
	$by   = array();
	foreach ( ogc_vol_shifts( $year ) as $id => $sh ) {
		if ( ! in_array( $sh['committee'], $names, true ) || $sh['unlimited'] || 'committee' === $sh['shown'] || ogc_vol_now() >= $sh['start_ts'] ) {
			continue;
		}
		$o = max( 0, $sh['needed'] - ( isset( $map[ $id ] ) ? count( $map[ $id ] ) : 0 ) );
		if ( ! $o ) {
			continue;
		}
		$open += $o;
		// A shift after midnight is the evening before's, as the page says it.
		$d        = ! empty( $sh['allweek'] ) ? 'week' : ogc_vol_eve_date( $sh );
		$by[ $d ] = ( isset( $by[ $d ] ) ? $by[ $d ] : 0 ) + $o;
	}
	if ( ! $open ) {
		return null;
	}
	unset( $by['week'] );
	arsort( $by );
	$day = $by ? (string) key( $by ) : '';
	$why = count( $by ) > 1 ? gmdate( 'l', strtotime( $day . ' 12:00 UTC' ) ) . ' short · ' . $by[ $day ] . ' open' : '';
	$cl  = ogc_vol_close_date( $year );
	return array(
		'key'    => 'helpers:' . $ckey,
		'words'  => 'Helpers · ' . $open . ' open',
		'why'    => trim( $why . ( $cl ? ( $why ? ' · ' : '' ) . 'Sign-ups close ' . gmdate( 'M j', strtotime( $cl . ' 12:00 UTC' ) ) : '' ) ),
		'go'     => 'coa' === $ckey ? array( 's' => 'helpers' ) : array( 's' => 'helpers', 'c' => $ckey ),
		'button' => 'Open Helpers',
		'tone'   => 'look',
		'due'    => '',
		'rank'   => 2,
		'first'  => 'coa' !== $ckey && $to <= 28,
	);
}
add_filter( 'ogc_app_needs', function ( $rows, $year, $ckey, $ctx ) {
	if ( 'before' !== $ctx['phase'] ) {
		return $rows;
	}
	// Only a committee whose key is a shift committee's (or the COA, for all of them).
	if ( 'coa' !== $ckey && ( ! function_exists( 'ogc_appc_shift_keys' ) || ! in_array( $ckey, ogc_appc_shift_keys( $year ), true ) ) ) {
		return $rows;
	}
	$n = ogc_vol_home_need( (int) $year, $ckey, $ctx['today'] );
	if ( $n ) {
		$rows[] = $n;
	}
	return $rows;
}, 12, 4 );
