<?php
/**
 * Volunteer shifts: Who's signed up, the committees' side. /wp-json/ogc/v1/vol/{year}/lead…
 *
 * Who may: the year's members (every committee, and All), or a committee's own heads (committees.csv
 * heads: their committee only, never the rest of the year). Names, phones and emails go nowhere else.
 *
 *   GET  lead                 one committee's shifts with everyone on them (or All: each committee's numbers)
 *   GET  lead/export          the list for Excel (one committee, or all for members), built here
 *   POST lead/add             a person signed up by the head (by phone, on paper, at the desk)
 *   POST lead/move            to another of the committee's shifts (Busy checked)
 *   POST lead/remove          off a shift (Undo: lead/restore)
 *   POST lead/offer           email a waiting person a one-tap Join
 *   POST lead/here            ticked as here, during the week
 *   POST lead/message         an email to the committee's volunteers (queued, one per person)
 *   POST lead/contact         the committee's contact (role email and phone), heads, weekly email
 *   POST lead/printed         printed or downloaded now (what changed since is marked from here)
 */

defined( 'ABSPATH' ) || exit;

add_action( 'rest_api_init', function () {
	$Y = '/vol/(?P<year>\d{4})/lead';
	register_rest_route( OGC_NS, $Y, array( 'methods' => 'GET', 'callback' => 'ogc_vol_lead_get', 'permission_callback' => 'ogc_vol_can_lead_req' ) );
	register_rest_route( OGC_NS, "$Y/export", array( 'methods' => 'GET', 'callback' => 'ogc_vol_lead_export', 'permission_callback' => 'ogc_vol_can_lead_req' ) );
	foreach ( array( 'add', 'move', 'remove', 'restore', 'offer', 'here', 'message', 'contact', 'printed', 'remind', 'edit', 'resend', 'note' ) as $a ) {
		register_rest_route( OGC_NS, "$Y/$a", array( 'methods' => 'POST', 'callback' => 'ogc_vol_lead_' . $a, 'permission_callback' => 'ogc_vol_can_lead_req' ) );
	}
} );

/** Signed in, and a member or a head of the committee asked for (or of any, for the list of them). */
function ogc_vol_can_lead_req( WP_REST_Request $req ) {
	if ( ! ogc_valid_year( $req['year'] ) || ! is_user_logged_in() ) {
		return ogc_rest_denied( 'Sign in first.' );
	}
	$c = $req->get_param( 'committee' );
	$c = is_string( $c ) && '' !== $c ? $c : null;
	// A shift or a sign-up named: its own committee decides, whatever committee the request says (a head
	// of Ushers can't remove someone from Dining hall by sending committee=Ushers).
	$of = null;
	if ( $req->get_param( 'shift' ) ) {
		$sh = ogc_vol_shifts( (int) $req['year'] );
		$of = isset( $sh[ (string) $req->get_param( 'shift' ) ] ) ? $sh[ (string) $req->get_param( 'shift' ) ]['committee'] : '';
	}
	if ( $req->get_param( 'id' ) ) {
		$rc = ogc_vol_committee_of_record( (int) $req['year'], (int) $req->get_param( 'id' ) );
		if ( null !== $of && $rc !== $of ) {
			return ogc_rest_denied();
		}
		$of = $rc;
	}
	if ( null !== $of ) {
		if ( '' === $of || ( null !== $c && $c !== $of ) ) {
			return ogc_rest_denied();
		}
		$c = $of;
	}
	// The contact and heads list: members only.
	if ( false !== strpos( $req->get_route(), '/lead/contact' ) && ! ogc_vol_lead_all( $req['year'] ) && ! ( $c && in_array( $c, ogc_vol_headed( (int) $req['year'] ), true ) && null === $req->get_param( 'heads' ) ) ) {
		return ogc_rest_denied();
	}
	if ( 'all' === $req->get_param( 'scope' ) ) {
		return ogc_vol_lead_all( $req['year'] ) ? true : ogc_rest_denied();
	}
	return ogc_vol_can_lead( (int) $req['year'], $c ) ? true : ogc_rest_denied();
}

function ogc_vol_committee_of_record( $year, $id ) {
	$r = ogc_record_get( $id, true );
	if ( ! $r || (int) $r['year'] !== $year || ! in_array( $r['kind'], array( 'signups', 'waits' ), true ) ) {
		return '';
	}
	$sh = ogc_vol_shifts( $year );
	return isset( $sh[ $r['data']['id'] ] ) ? $sh[ $r['data']['id'] ]['committee'] : '';
}

/** The committees this person may open, with their numbers. */
function ogc_vol_lead_committees( $year ) {
	$all  = ogc_vol_lead_all( $year );
	$mine = array_merge( ogc_vol_headed( $year ), function_exists( 'ogc_appc_vol_scope' ) && ogc_is_member( $year ) ? (array) ogc_appc_vol_scope( $year ) : array() );
	$map  = ogc_vol_seat_map( $year );
	$out  = array();
	// For the year's committee: whether each has a contact and heads, and last year's numbers (kept
	// after the clearing, else counted from last year's list), so a new COA sees what's usual.
	$prev  = ogc_state_get( $year - 1, 'vol-stats' );
	$prev  = $prev ? (array) $prev['value'] : array();
	$pmap  = $all && ! $prev ? ogc_vol_seat_map( $year - 1 ) : null;
	$pcoms = $all && ! $prev ? array_keys( ogc_vol_committees( $year - 1 ) ) : array();
	foreach ( ogc_vol_committees( $year ) as $c ) {
		if ( $all || in_array( $c['name'], $mine, true ) ) {
			$n   = ogc_vol_committee_numbers( $year, $c['name'], $map );
			$row = array( 'name' => $c['name'], 'needed' => $n['needed'], 'filled' => $n['filled'], 'open' => $n['open'], 'shifts' => $n['shifts'] );
			if ( $all ) {
				$row['contact'] = '' !== $c['contact_email'];
				// Who heads it, by name ("Ruth K."), from the year's Members (docs/23: the COA manages who's
				// on each committee there); committees.csv's old heads list only when Members has none.
				$hn             = ogc_vol_heads_of( $year, $c['name'] );
				$row['heads']   = count( $hn );
				$row['head_names'] = $hn;
				$last           = null;
				if ( $prev ) {
					foreach ( $prev as $p ) {
						if ( $p['committee'] === $c['name'] ) {
							$last = $last ? $last : array( 'filled' => 0, 'needed' => 0 );
							$last['filled'] += (int) $p['filled'];
							$last['needed'] += (int) $p['needed'];
						}
					}
				} elseif ( in_array( $c['name'], $pcoms, true ) ) {
					$pn   = ogc_vol_committee_numbers( $year - 1, $c['name'], $pmap );
					$last = $pn['shifts'] ? array( 'filled' => $pn['filled'], 'needed' => $pn['needed'] ) : null;
				}
				$row['last'] = $last;
			}
			$out[] = $row;
		}
	}
	return $out;
}

/** A person on a shift as the head sees them. */
function ogc_vol_lead_person( $rec, $flags = array() ) {
	$d = $rec['data'];
	return array_merge( array(
		'rid'       => (int) $rec['id'],
		'name'      => isset( $d['name'] ) ? $d['name'] : '',
		'phone'     => isset( $d['phone'] ) ? ogc_vol_phone_shown( $d['phone'] ) : '',
		'email'     => isset( $d['email'] ) ? $d['email'] : '',
		'by'        => isset( $d['by'] ) ? $d['by'] : 'self',
		'helper'    => isset( $d['helper'] ) ? $d['helper'] : '',
		'confirmed' => ! empty( $d['confirmed'] ),
		'hidden'    => ! empty( $d['hide'] ) || ( ! empty( $d['minor'] ) && empty( $d['show'] ) ),
		'sample'    => ! empty( $rec['sample'] ),
		'note'      => isset( $d['note'] ) ? $d['note'] : '',
		'answer'    => isset( $d['rule']['answer'] ) ? $d['rule']['answer'] : '',
		'screened'  => isset( $d['screened'] ) ? $d['screened'] : '',
		'here'      => ! empty( $d['here'] ),
		'swap'      => ! empty( $d['swap'] ),
		'at'        => $rec['created_at'],
	), $flags );
}

/** People who may be one person on two shifts at once under two emails (same name and phone). */
function ogc_vol_double_booked( $year, $map ) {
	$shifts = ogc_vol_shifts( $year );
	$by     = array();
	foreach ( $map as $id => $seats ) {
		foreach ( $seats as $s ) {
			$d = $s['record']['data'];
			$k = strtolower( preg_replace( '/\s+/', ' ', trim( $d['name'] ) ) ) . '|' . preg_replace( '/\D+/', '', isset( $d['phone'] ) ? $d['phone'] : '' );
			$by[ $k ][] = array( $id, $s['record'] );
		}
	}
	$flag = array();
	foreach ( $by as $list ) {
		for ( $i = 0; $i < count( $list ); $i++ ) {
			for ( $j = $i + 1; $j < count( $list ); $j++ ) {
				list( $a, $ra ) = $list[ $i ];
				list( $b, $rb ) = $list[ $j ];
				if ( $ra['email'] === $rb['email'] || ! isset( $shifts[ $a ], $shifts[ $b ] ) ) {
					continue;
				}
				if ( $shifts[ $a ]['start_ts'] < $shifts[ $b ]['end_ts'] && $shifts[ $b ]['start_ts'] < $shifts[ $a ]['end_ts'] ) {
					$flag[ $ra['id'] ] = $shifts[ $b ]['role'];
					$flag[ $rb['id'] ] = $shifts[ $a ]['role'];
				}
			}
		}
	}
	return $flag;
}

/** Names are cleared for the year (or past the date they're due to be): lists are numbers only. */
function ogc_vol_names_gone( $y ) {
	if ( ogc_state_get( $y, 'vol-cleared' ) ) {
		return true;
	}
	$s     = ogc_vol_settings( $y );
	$after = isset( $s['clear_after_days'] ) && is_numeric( $s['clear_after_days'] ) ? (int) $s['clear_after_days'] : 60;
	$last  = ogc_vol_last_day( $y );
	return $last && ogc_vol_wall( $y )['date'] > gmdate( 'Y-m-d', strtotime( $last . ' UTC' ) + $after * DAY_IN_SECONDS );
}

function ogc_vol_lead_get( WP_REST_Request $req ) {
	$y = (int) $req['year'];
	ogc_vol_prepare_year( $y );
	$coms = ogc_vol_lead_committees( $y );
	$c    = (string) $req->get_param( 'committee' );
	$all  = ogc_vol_lead_all( $y );
	if ( '' === $c && ! $all && $coms ) {
		$c = $coms[0]['name'];
	}
	$out = array( 'committees' => $coms, 'all' => $all, 'committee' => $c, 'posted' => ogc_vol_posted( $y ), 'now' => ogc_vol_wall( $y ), 'me' => ogc_current_email(), 'webmaster' => ogc_is_webmaster() );
	// When names are cleared (the date, as promised to the Advisors).
	$s     = ogc_vol_settings( $y );
	$after = isset( $s['clear_after_days'] ) && is_numeric( $s['clear_after_days'] ) ? (int) $s['clear_after_days'] : 60;
	$last  = ogc_vol_last_day( $y );
	$out['clears']  = $last ? gmdate( 'Y-m-d', strtotime( $last . ' UTC' ) + $after * DAY_IN_SECONDS ) : '';
	$cl             = ogc_state_get( $y, 'vol-cleared' );
	$out['cleared'] = $cl ? substr( (string) $cl['value'], 0, 10 ) : '';
	// Past that date the list is numbers only, samples too, as promised (the timed job clears the rows).
	$gone        = ogc_vol_names_gone( $y );
	$out['gone'] = $gone;
	if ( '' === $c ) {
		if ( $all ) {
			// How many a "Message all heads" reaches (each contact and head once).
			$out['heads_n'] = count( ogc_vol_heads_emails( $y ) );
			$out['msgs_left'] = max( 0, 5 - (int) get_transient( 'ogc_vol_rl_' . md5( 'msg|' . ogc_current_email() . '|' . gmdate( 'Y-m-d' ) ) ) );
			$out['members_url'] = ogc_url( 'members', array( 'year' => $y ) );
		}
		return rest_ensure_response( $out );
	}
	$comm = ogc_vol_committees( $y );
	if ( ! isset( $comm[ $c ] ) ) {
		return new WP_Error( 'ogc_not_found', 'Not found.', array( 'status' => 404 ) );
	}
	$map    = ogc_vol_seat_map( $y );
	$double = ogc_vol_double_booked( $y, $map );
	// An email several people in a household share ("owen.gardner@…" for Esther too): said as the
	// household's beside the names it isn't.
	$names_of = array();
	foreach ( $map as $seats ) {
		foreach ( $seats as $st ) {
			$names_of[ $st['record']['email'] ][ strtolower( trim( $st['record']['data']['name'] ) ) ] = true;
		}
	}
	$waits  = array();
	foreach ( ogc_records( $y, 'waits' ) as $w ) {
		$waits[ $w['data']['id'] ][] = array( 'rid' => (int) $w['id'], 'name' => $w['data']['name'], 'email' => $w['email'], 'phone' => isset( $w['data']['phone'] ) ? $w['data']['phone'] : '', 'at' => $w['created_at'], 'sample' => ! empty( $w['sample'] ) );
	}
	// What changed since this person last printed or downloaded the list.
	$pr    = ogc_state_get( $y, 'vol-printed' );
	$pr    = $pr ? (array) $pr['value'] : array();
	$since = isset( $pr[ $c ][ ogc_current_email() ] ) ? $pr[ $c ][ ogc_current_email() ] : '';
	$left  = array();
	$ch    = ogc_state_get( $y, 'vol-changes' );
	foreach ( $ch ? (array) $ch['value'] : array() as $x ) {
		if ( $since && $x['committee'] === $c && $x['at'] > $since && in_array( $x['act'], array( 'left', 'unconfirmed', 'notme', 'moved_out', 'removed', 'swap' ), true ) ) {
			$left[] = array( 'shift' => $x['shift'], 'name' => 'swap' === $x['act'] ? $x['from'] : $x['name'], 'act' => $x['act'], 'at' => $x['at'] );
		}
	}
	$shifts = array();
	$stats  = ogc_state_get( $y, 'vol-stats' );
	$stats  = $stats ? (array) $stats['value'] : array();
	$prevst = ogc_state_get( $y - 1, 'vol-stats' );
	$prevst = $prevst ? (array) $prevst['value'] : array();
	foreach ( ogc_vol_shifts( $y ) as $id => $sh ) {
		if ( $sh['committee'] !== $c ) {
			continue;
		}
		$people = array();
		$n      = isset( $map[ $id ] ) ? count( $map[ $id ] ) : 0;
		if ( isset( $stats[ $id ]['filled'] ) && $gone ) {
			$n = max( $n, (int) $stats[ $id ]['filled'] );
		}
		foreach ( $gone ? array() : ( isset( $map[ $id ] ) ? $map[ $id ] : array() ) as $seat ) {
			$r        = $seat['record'];
			$fn       = strtolower( strtok( trim( (string) $r['data']['name'] ), ' ' ) );
			$people[] = ogc_vol_lead_person( $r, array(
				'new'       => $since && $r['created_at'] > $since,
				'check'     => isset( $double[ $r['id'] ] ) ? $double[ $r['id'] ] : '',
				'household' => $r['email'] && isset( $names_of[ $r['email'] ] ) && count( $names_of[ $r['email'] ] ) > 1 && false === strpos( strtolower( strstr( $r['email'], '@', true ) ), $fn ),
			) );
		}
		// Last year's record for the same shift (by uid, else committee, job and weekday).
		$last = null;
		foreach ( $prevst as $pid => $p ) {
			if ( ( $sh['uid'] && 0 === strpos( $pid, $sh['uid'] ) && $p['day'] === $sh['day'] ) || ( $p['committee'] === $sh['committee'] && $p['role'] === $sh['role'] && $p['day'] === $sh['day'] && abs( $p['start'] - $sh['start'] ) < 90 ) ) {
				$last = $p;
				break;
			}
		}
		$shifts[] = array(
			'id'      => $id,
			// What the shift is, for the app's Helpers (it reads no shifts file of its own).
			'role'    => $sh['role'],
			'day'     => $sh['day'],
			'date'    => $sh['date'],
			'start'   => $sh['start'],
			'end'     => $sh['end'],
			'needed'  => $sh['needed'],
			'unlimited' => $sh['unlimited'],
			'place'   => $sh['place_name'],
			'rule'    => $sh['rule'] ? ogc_vol_rule_label( $sh ) : '',
			'people'  => $people,
			'n'       => $n,
			'waiting' => $gone || ! isset( $waits[ $id ] ) ? array() : $waits[ $id ],
			'over'    => $sh['unlimited'] ? 0 : max( 0, $n - $sh['needed'] ),
			'state'   => ogc_vol_shift_state( $y, $sh, $n ),
			'last'    => $last,
		);
	}
	$mm       = ogc_state_get( $y, 'vol-msgs' );
	$messages = array();
	foreach ( $mm ? (array) $mm['value'] : array() as $m ) {
		if ( $m['committee'] === $c ) {
			$messages[] = $m;
		}
	}
	if ( preg_match( '/young folk/i', $c ) ) {
		$out['yf'] = ogc_vol_yf_households( $y, $c );
		unset( $out['yf']['emails'] );
	}
	// For a head new to it each year: last year's note on top, this year's for next year at the end, and
	// what's been done (What to do ticks itself from these).
	$notes          = ogc_state_get( $y, 'vol-notes' );
	$notes          = $notes ? (array) $notes['value'] : array();
	$pnotes         = ogc_state_get( $y - 1, 'vol-notes' );
	$pnotes         = $pnotes ? (array) $pnotes['value'] : array();
	$out['note']    = isset( $notes[ $c ] ) ? $notes[ $c ] : null;
	$out['last_note'] = isset( $pnotes[ $c ] ) ? $pnotes[ $c ] : null;
	// Printed is ticked by the head ("Printed" in the page after the print dialog), never by opening it.
	$pr2            = ogc_state_get( $y, 'vol-printed-done' );
	$out['printed'] = $pr2 && ! empty( ( (array) $pr2['value'] )[ $c ] );
	$out['messaged'] = (bool) $messages;
	$days           = ogc_vol_days( $y );
	$out['begun']   = $days && ogc_vol_wall( $y )['date'] >= $days[0]['date'];
	$out['contact']  = array( 'email' => $comm[ $c ]['contact_email'], 'phone' => ogc_vol_phone_shown( $comm[ $c ]['contact_phone'] ), 'weekly' => 'no' !== strtolower( (string) $comm[ $c ]['weekly'] ) );
	// Who heads it, from the year's Members (with their emails, for the year's committee).
	$out['heads']    = $all ? ogc_vol_heads_of( $y, $c ) : array();
	$out['members_url'] = $all ? ogc_url( 'members', array( 'year' => $y ) ) : '';
	// Volunteer emails the per-address limit held back (the Mail log isn't the only place to see it).
	$emails = array();
	foreach ( $shifts as $sx ) {
		foreach ( $sx['people'] as $pp ) {
			if ( $pp['email'] ) {
				$emails[ strtolower( $pp['email'] ) ] = $pp['name'];
			}
		}
	}
	$out['refused']  = ogc_vol_refused( $y, $emails );
	// Five messages a day per sender: how many are left today.
	$out['msgs_left'] = max( 0, 5 - (int) get_transient( 'ogc_vol_rl_' . md5( 'msg|' . ogc_current_email() . '|' . gmdate( 'Y-m-d' ) ) ) );
	$out['shifts']   = $shifts;
	$out['since']    = $since;
	$out['left']     = $left;
	$out['messages'] = array_reverse( $messages );
	return rest_ensure_response( $out );
}

/* ================================================================== the list for Excel */

/** A cell as Excel should read it: never a formula (a typed "=…" or "+…" starts with an apostrophe). */
function ogc_vol_cell( $v ) {
	$v = (string) $v;
	if ( '' !== $v && preg_match( '/^[=+\-@\t\r]/', $v ) ) {
		$v = "'" . $v;
	}
	return preg_match( '/[",\r\n]/', $v ) ? '"' . str_replace( '"', '""', $v ) . '"' : $v;
}

function ogc_vol_lead_export( WP_REST_Request $req ) {
	$y      = (int) $req['year'];
	$all    = 'all' === $req->get_param( 'scope' );
	$c      = (string) $req->get_param( 'committee' );
	$gone   = ogc_vol_names_gone( $y );
	$map    = $gone ? array() : ogc_vol_seat_map( $y );
	$waits  = array();
	foreach ( $gone ? array() : ogc_records( $y, 'waits' ) as $w ) {
		$waits[ $w['data']['id'] ][] = $w;
	}
	$hm     = function ( $m ) {
		$m = ( ( $m % 1440 ) + 1440 ) % 1440;
		return sprintf( '%d:%02d %s', ( intdiv( $m, 60 ) % 12 ) ?: 12, $m % 60, $m >= 720 ? 'PM' : 'AM' );
	};
	// The rule's column is named after its question ("21 or older", "Certification"), when the shifts
	// in the file ask one question; "Rule" when they ask several.
	$asks = array();
	foreach ( ogc_vol_shifts( $y ) as $sh ) {
		if ( ( $all || $sh['committee'] === $c ) && $sh['rule'] ) {
			$asks[ ogc_vol_rule_label( $sh ) ] = true;
		}
	}
	$ask    = 1 === count( $asks ) ? key( $asks ) : ( $asks ? 'Rule' : 'Rule' );
	$lines  = array( array( 'Committee', 'Day', 'Date', 'Start', 'End', 'Shift', 'Place', 'Name', 'Phone', 'Email', 'Household contact', 'Signed up', $ask, 'Note', 'Status' ) );
	foreach ( ogc_vol_shifts( $y ) as $id => $sh ) {
		if ( ! $all && $sh['committee'] !== $c ) {
			continue;
		}
		$base  = array( $sh['committee'], $sh['day'], $sh['date'], $hm( $sh['start'] ), $hm( $sh['end'] ), $sh['role'], $sh['place_name'] );
		$on    = isset( $map[ $id ] ) ? $map[ $id ] : array();
		foreach ( $on as $i => $seat ) {
			$d       = $seat['record']['data'];
			$status  = ! empty( $d['swap'] ) ? 'Swap open' : ( ! $sh['unlimited'] && $i >= $sh['needed'] ? 'Over' : ( 'head' === ( isset( $d['by'] ) ? $d['by'] : '' ) ? 'Added by head' : 'Signed up' ) );
			$when    = ! empty( $d['at'] ) && strtotime( $d['at'] ) ? gmdate( 'Y-m-d', strtotime( $d['at'] ) ) : substr( $seat['record']['created_at'], 0, 10 );
			$answer  = isset( $d['rule']['answer'] ) ? ( 'yes' === $d['rule']['answer'] ? 'Yes' : $d['rule']['answer'] ) : '';
			$lines[] = array_merge( $base, array( $d['name'], isset( $d['phone'] ) ? ogc_vol_phone_shown( $d['phone'] ) : '', isset( $d['email'] ) ? $d['email'] : '', ! empty( $d['helper'] ) ? $d['helper'] : '', $when, $answer, isset( $d['note'] ) ? $d['note'] : '', $status ) );
		}
		for ( $k = count( $on ); ! $sh['unlimited'] && $k < $sh['needed']; $k++ ) {
			$lines[] = array_merge( $base, array( '', '', '', '', '', '', '', 'Open' ) );
		}
		foreach ( isset( $waits[ $id ] ) ? $waits[ $id ] : array() as $w ) {
			$lines[] = array_merge( $base, array( $w['data']['name'], isset( $w['data']['phone'] ) ? ogc_vol_phone_shown( $w['data']['phone'] ) : '', $w['email'], '', substr( $w['created_at'], 0, 10 ), '', '', 'Waitlist' ) );
		}
	}
	$csv = "\xEF\xBB\xBF" . implode( "\r\n", array_map( function ( $l ) {
		return implode( ',', array_map( 'ogc_vol_cell', $l ) );
	}, $lines ) ) . "\r\n";
	ogc_log( 'vol_export', $y, $all ? 'all' : $c, array( 'rows' => count( $lines ) - 1 ) );
	$name = ( $all ? 'volunteers' : trim( preg_replace( '/[^a-z0-9]+/', '-', strtolower( $c ) ), '-' ) . '-volunteers' ) . '-' . $y . '.csv';
	$res  = new WP_REST_Response( $csv, 200 );
	$res->header( 'Content-Type', 'text/csv; charset=utf-8' );
	$res->header( 'Content-Disposition', 'attachment; filename="' . $name . '"' );
	$res->header( 'X-Content-Type-Options', 'nosniff' );
	$res->header( 'Cache-Control', 'no-store, private' );
	return $res;
}

/* ================================================================== the head's changes */

/** The shift asked for, if it's one of the committees this person may change. */
function ogc_vol_lead_shift( $y, $id ) {
	$all = ogc_vol_shifts( $y );
	if ( ! isset( $all[ $id ] ) || ! ogc_vol_can_lead( $y, $all[ $id ]['committee'] ) ) {
		return null;
	}
	return $all[ $id ];
}

/** Add someone the head signed up: name and phone; email when they have one. Works before Publish (a
 * committee's regulars) and after the start (a walk-up). The count holds unless the head says over. */
function ogc_vol_lead_add( WP_REST_Request $req ) {
	global $wpdb;
	$y  = (int) $req['year'];
	$sh = ogc_vol_lead_shift( $y, (string) $req->get_param( 'shift' ) );
	if ( ! $sh ) {
		return ogc_rest_denied();
	}
	$name  = ogc_vol_clean_name( $req->get_param( 'name' ) );
	$phone = ogc_vol_clean_phone( $req->get_param( 'phone' ) );
	$raw   = trim( (string) $req->get_param( 'email' ) );
	$email = strtolower( sanitize_email( $raw ) );
	// Typed but not an email ("nope") is named at the field, never dropped quietly.
	$errs  = array_filter( array( 'name' => false !== strpos( $name, ' ' ) ? '' : 'First and last name', 'phone' => $phone ? '' : 'Enter a phone number', 'email' => '' === $raw || is_email( $email ) ? '' : 'Check the email' ) );
	if ( $errs ) {
		return ogc_vol_no( 'fields', 'Check the form.', array( 'fields' => $errs ), 400 );
	}
	$pk = ogc_vol_pkey( $email, $name, $phone );
	$b  = ogc_vol_busy( $y, $sh, $pk );
	if ( $b && ! $req->get_param( 'force' ) ) {
		return ogc_vol_no( 'busy', 'Busy', array( 'busy' => array( 'shift' => $b['id'], 'role' => $b['role'], 'until' => $b['end'] ) ) );
	}
	$seats = ogc_vol_take_seats( $y, $sh, array( $pk ), (bool) $req->get_param( 'over' ) );
	if ( is_wp_error( $seats ) ) {
		return ogc_vol_no( 'ogc_dup' === $seats->get_error_code() ? 'dup' : 'full', 'Not added', (array) $seats->get_error_data() );
	}
	$data = array( 'id' => $sh['id'], 'name' => $name, 'phone' => $phone, 'email' => $email, 'confirmed' => true, 'by' => 'head', 'at' => gmdate( 'c', ogc_vol_now() ) );
	$note = mb_substr( sanitize_text_field( (string) $req->get_param( 'note' ) ), 0, 200 );
	if ( $note ) {
		$data['note'] = $note;
	}
	$rid = ogc_record_insert( $y, 'signups', $data, $email, false, 'head' );
	$wpdb->update( ogc_table( 'vol_seats' ), array( 'record_id' => $rid ), array( 'id' => reset( $seats ) ), array( '%d' ), array( '%d' ) );
	ogc_vol_change( $y, $sh, 'joined', $name );
	if ( $email && false !== $req->get_param( 'notify' ) ) {
		ogc_vol_queue_person( $y, ogc_record_get( $rid ), 'head_added' );
	}
	ogc_log( 'vol_head_add', $y, $sh['committee'], array( 'id' => $rid ) );
	return rest_ensure_response( array( 'rid' => $rid ) );
}

/** Move someone to another of the committee's shifts: the new place first (atomic), then the old one
 * is let go. They're emailed when they have an email. */
function ogc_vol_lead_move( WP_REST_Request $req ) {
	global $wpdb;
	$y   = (int) $req['year'];
	$rec = ogc_record_get( (int) $req->get_param( 'id' ) );
	if ( ! $rec || 'signups' !== $rec['kind'] || (int) $rec['year'] !== $y ) {
		return ogc_vol_no( 'gone', 'Not found', array(), 404 );
	}
	$all  = ogc_vol_shifts( $y );
	$from = isset( $all[ $rec['data']['id'] ] ) ? $all[ $rec['data']['id'] ] : null;
	$to   = ogc_vol_lead_shift( $y, (string) $req->get_param( 'to' ) );
	if ( ! $to || ! $from || ! ogc_vol_can_lead( $y, $from['committee'] ) ) {
		return ogc_rest_denied();
	}
	$pk = ogc_vol_pkey( $rec['email'], $rec['data']['name'], isset( $rec['data']['phone'] ) ? $rec['data']['phone'] : '' );
	$b  = ogc_vol_busy( $y, $to, $pk, $rec['id'] );
	if ( $b && $b['id'] !== $from['id'] ) {
		return ogc_vol_no( 'busy', 'Busy', array( 'busy' => array( 'shift' => $b['id'], 'role' => $b['role'], 'until' => $b['end'] ) ) );
	}
	$seats = ogc_vol_take_seats( $y, $to, array( $pk ), (bool) $req->get_param( 'over' ) );
	if ( is_wp_error( $seats ) ) {
		return ogc_vol_no( 'ogc_dup' === $seats->get_error_code() ? 'dup' : 'full', 'Not moved', (array) $seats->get_error_data() );
	}
	ogc_vol_release_record( $rec['id'] );
	$wpdb->update( ogc_table( 'vol_seats' ), array( 'record_id' => $rec['id'] ), array( 'id' => reset( $seats ) ), array( '%d' ), array( '%d' ) );
	$d         = $rec['data'];
	$d['id']   = $to['id'];
	unset( $d['reminded'], $d['swap'] );
	ogc_record_update( $rec['id'], $d, $rec['email'] );
	ogc_vol_change( $y, $from, 'moved_out', $d['name'] );
	ogc_vol_change( $y, $to, 'joined', $d['name'] );
	ogc_vol_notify_waitlist( $y, $from );
	if ( $rec['email'] && ! $rec['sample'] ) {
		ogc_vol_queue_person( $y, ogc_record_get( $rec['id'] ), 'changed', array( 'was' => array( 'date' => $from['date'], 'start' => $from['start'], 'end' => $from['end'], 'role' => $from['role'], 'committee' => $from['committee'] ) ) );
	}
	ogc_log( 'vol_head_move', $y, $from['committee'], array( 'id' => $rec['id'] ) );
	return rest_ensure_response( array( 'moved' => $rec['id'], 'from' => $from['id'] ) );
}

/** Off a shift (a duplicate, a jokester, someone who called). The person hears only when the head
 * says so; the people waiting do. Undo: lead/restore. */
function ogc_vol_lead_remove( WP_REST_Request $req ) {
	$y   = (int) $req['year'];
	$rec = ogc_record_get( (int) $req->get_param( 'id' ) );
	if ( ! $rec || (int) $rec['year'] !== $y ) {
		return ogc_vol_no( 'gone', 'Not found', array(), 404 );
	}
	ogc_record_delete( $rec['id'] );
	if ( 'waits' === $rec['kind'] ) {
		return rest_ensure_response( array( 'removed' => $rec['id'] ) );
	}
	ogc_vol_release_record( $rec['id'] );
	$all = ogc_vol_shifts( $y );
	if ( isset( $all[ $rec['data']['id'] ] ) ) {
		$sh = $all[ $rec['data']['id'] ];
		ogc_vol_change( $y, $sh, 'removed', $rec['data']['name'] );
		if ( ogc_vol_now() < $sh['start_ts'] ) {
			ogc_vol_notify_waitlist( $y, $sh );
		}
	}
	if ( $req->get_param( 'notify' ) ) {
		ogc_vol_queue_person( $y, $rec, 'left', array( 'by_head' => true ) );
	}
	ogc_log( 'vol_head_remove', $y, 'signups', array( 'id' => $rec['id'] ) );
	return rest_ensure_response( array( 'removed' => $rec['id'] ) );
}

/** Undo a Remove: the same person back in a place (if one is still free). */
function ogc_vol_lead_restore( WP_REST_Request $req ) {
	global $wpdb;
	$y   = (int) $req['year'];
	$rec = ogc_record_get( (int) $req->get_param( 'id' ), true );
	if ( ! $rec || (int) $rec['year'] !== $y || empty( $rec['deleted_at'] ) ) {
		return ogc_vol_no( 'gone', 'Not found', array(), 404 );
	}
	if ( 'signups' === $rec['kind'] ) {
		$all = ogc_vol_shifts( $y );
		$sh  = isset( $all[ $rec['data']['id'] ] ) ? $all[ $rec['data']['id'] ] : null;
		if ( ! $sh ) {
			return ogc_vol_no( 'gone', 'Not found', array(), 404 );
		}
		$seats = ogc_vol_take_seats( $y, $sh, array( ogc_vol_pkey( $rec['email'], $rec['data']['name'], isset( $rec['data']['phone'] ) ? $rec['data']['phone'] : '' ) ), true );
		if ( is_wp_error( $seats ) ) {
			return ogc_vol_no( 'full', 'Full', (array) $seats->get_error_data() );
		}
		$wpdb->update( ogc_table( 'vol_seats' ), array( 'record_id' => $rec['id'] ), array( 'id' => reset( $seats ) ), array( '%d' ), array( '%d' ) );
	}
	$wpdb->query( $wpdb->prepare( 'UPDATE ' . ogc_table( 'records' ) . ' SET deleted_at = NULL WHERE id = %d', $rec['id'] ) );
	ogc_log( 'vol_head_restore', $y, $rec['kind'], array( 'id' => $rec['id'] ) );
	return rest_ensure_response( array( 'restored' => $rec['id'] ) );
}

/** Offer the place to one person waiting: an email with a one-tap Join. */
function ogc_vol_lead_offer( WP_REST_Request $req ) {
	$y = (int) $req['year'];
	$w = ogc_record_get( (int) $req->get_param( 'id' ) );
	if ( ! $w || 'waits' !== $w['kind'] || (int) $w['year'] !== $y ) {
		return ogc_vol_no( 'gone', 'Not found', array(), 404 );
	}
	ogc_vol_queue( $y, 'opened', $w['email'], array( 'shift' => $w['data']['id'], 'name' => $w['data']['name'], 'wait' => $w['id'] ) );
	ogc_log( 'vol_head_offer', $y, 'waits', array( 'id' => $w['id'] ) );
	return rest_ensure_response( array( 'offered' => $w['id'] ) );
}

/** Here: ticked by the head as people arrive. */
function ogc_vol_lead_here( WP_REST_Request $req ) {
	$rec = ogc_record_get( (int) $req->get_param( 'id' ) );
	if ( ! $rec || 'signups' !== $rec['kind'] || (int) $rec['year'] !== (int) $req['year'] ) {
		return ogc_vol_no( 'gone', 'Not found', array(), 404 );
	}
	$d         = $rec['data'];
	$d['here'] = (bool) $req->get_param( 'here' );
	ogc_record_update( $rec['id'], $d, $rec['email'] );
	return rest_ensure_response( array( 'here' => $d['here'] ) );
}

/** A message to the committee's volunteers: everyone, one day's, or one shift's. One email each (no
 * one sees another's address), replies to the sender, a copy to the sender. Kept in the committee's
 * Sent list. Five messages a day per sender. */
function ogc_vol_lead_message( WP_REST_Request $req ) {
	$y       = (int) $req['year'];
	$c       = (string) $req->get_param( 'committee' );
	$to      = (string) $req->get_param( 'to' );
	$subject = mb_substr( sanitize_text_field( (string) $req->get_param( 'subject' ) ), 0, 140 );
	$body    = mb_substr( sanitize_textarea_field( (string) $req->get_param( 'body' ) ), 0, 5000 );
	if ( '' === $subject || '' === $body ) {
		return ogc_vol_no( 'fields', 'Check the form.', array( 'fields' => array_filter( array( 'subject' => $subject ? '' : 'Add a subject', 'body' => $body ? '' : 'Write the message' ) ) ), 400 );
	}
	$me = ogc_current_email();
	if ( ! ogc_vol_rate( 'msg|' . $me . '|' . gmdate( 'Y-m-d' ), 5, DAY_IN_SECONDS ) ) {
		return ogc_vol_no( 'slow', 'Five messages a day', array(), 429 );
	}
	$emails = array();
	$call   = array();
	// The year's committee to every committee's contact and heads (members only).
	if ( 'heads' === $to ) {
		if ( ! ogc_vol_lead_all( $y ) ) {
			return ogc_rest_denied();
		}
		$c = '';
		// The same list the All table shows: Members marked Head, and each committee's contact.
		foreach ( ogc_vol_heads_emails( $y ) as $e ) {
			$emails[ $e ] = true;
		}
	}
	foreach ( 'heads' === $to ? array() : ogc_vol_seat_map( $y ) as $id => $seats ) {
		$sh = ogc_vol_shifts( $y )[ $id ] ?? null;
		if ( ! $sh || $sh['committee'] !== $c ) {
			continue;
		}
		if ( 0 === strpos( $to, 'day:' ) && $sh['date'] !== substr( $to, 4 ) ) {
			continue;
		}
		if ( 0 === strpos( $to, 'shift:' ) && $id !== substr( $to, 6 ) ) {
			continue;
		}
		foreach ( $seats as $s ) {
			$d = $s['record']['data'];
			// Sample people count as reached (the page said "Send · 40 people") but get no mail.
			if ( ! empty( $d['email'] ) ) {
				$emails[ strtolower( $d['email'] ) ] = empty( $s['record']['sample'] ) || ! empty( $emails[ strtolower( $d['email'] ) ] );
			} elseif ( empty( $d['email'] ) ) {
				$call[] = $d['name'] . ( ! empty( $d['phone'] ) ? ' · ' . $d['phone'] : '' );
			}
		}
	}
	// Signed as the sender, by name and role: "Phoebe L. · Transportation head", "Nathan K. · Committee of Arrangements".
	$from = ogc_vol_sender_line( $y, $c );
	foreach ( array_keys( array_filter( $emails ) ) as $e ) {
		if ( 'heads' === $to ) {
			ogc_vol_queue( $y, 'heads', $e, array( 'subject' => $subject, 'body' => $body, 'from' => $from, 'reply_to' => $me ) );
		} else {
			ogc_vol_queue( $y, 'message', $e, array( 'committee' => $c, 'to' => $to ?: 'all', 'subject' => $subject, 'body' => $body, 'from' => $from, 'reply_to' => $me ) );
		}
	}
	if ( false !== $req->get_param( 'copy' ) && $me ) {
		ogc_vol_queue( $y, 'copy', $me, array( 'subject' => $subject, 'body' => $body, 'sent_to' => 'heads' === $to ? count( $emails ) . ' committee heads and contacts' : count( $emails ) . ' volunteers · ' . $c ) );
	}
	$mm   = ogc_state_get( $y, 'vol-msgs' );
	$list = $mm ? (array) $mm['value'] : array();
	$list[] = array( 'at' => ogc_now(), 'committee' => $c, 'to' => $to ?: 'all', 'n' => count( $emails ), 'subject' => $subject, 'by' => strtok( $from, '·' ) ? trim( strtok( $from, '·' ) ) : '' );
	ogc_state_put( $y, 'vol-msgs', array_slice( $list, -200 ) );
	ogc_log( 'vol_message', $y, $c, array( 'n' => count( $emails ) ) );
	// Real mail goes out in batches from the timed job; the page says how many and who to call.
	return rest_ensure_response( array( 'queued' => count( $emails ), 'call' => array_slice( $call, 0, 50 ), 'left' => max( 0, 5 - (int) get_transient( 'ogc_vol_rl_' . md5( 'msg|' . $me . '|' . gmdate( 'Y-m-d' ) ) ) ) ) );
}

/** The committee's contact: the role email (where notices go, the reply-to), the role phone (shown to
 * the public as the committee's), the heads who may open its list, and the weekly email. Members set
 * the heads; a head may set the rest for their own committee. */
function ogc_vol_lead_contact( WP_REST_Request $req ) {
	$y    = (int) $req['year'];
	$c    = (string) $req->get_param( 'committee' );
	$f    = ogc_file_get( $y, 'committees' );
	$rows = $f ? $f['rows'] : array();
	$at   = -1;
	foreach ( $rows as $i => $r ) {
		if ( isset( $r['name'] ) && $r['name'] === $c ) {
			$at = $i;
		}
	}
	if ( $at < 0 ) {
		$rows[] = array( 'name' => $c, 'contact_email' => '', 'contact_phone' => '', 'heads' => '', 'weekly' => 'yes', 'order' => '' );
		$at     = count( $rows ) - 1;
	}
	$email = $req->get_param( 'email' );
	if ( null !== $email ) {
		$email = strtolower( sanitize_email( (string) $email ) );
		if ( '' !== $email && ! is_email( $email ) ) {
			return ogc_vol_no( 'fields', 'Check the form.', array( 'fields' => array( 'email' => 'Check the email' ) ), 400 );
		}
		$rows[ $at ]['contact_email'] = $email;
	}
	if ( null !== $req->get_param( 'phone' ) ) {
		$rows[ $at ]['contact_phone'] = mb_substr( sanitize_text_field( (string) $req->get_param( 'phone' ) ), 0, 32 );
	}
	if ( null !== $req->get_param( 'weekly' ) ) {
		$rows[ $at ]['weekly'] = $req->get_param( 'weekly' ) ? 'yes' : 'no';
	}
	if ( null !== $req->get_param( 'heads' ) && ogc_is_member( $y ) ) {
		$hs = array_filter( array_map( function ( $e ) {
			$e = strtolower( sanitize_email( trim( $e ) ) );
			return is_email( $e ) ? $e : '';
		}, preg_split( '/[\s,|;]+/', (string) $req->get_param( 'heads' ) ) ) );
		$rows[ $at ]['heads'] = implode( '|', array_unique( $hs ) );
	}
	$v = ogc_file_put( $y, 'committees', $rows, $f ? $f['version'] : 0, array( 'name', 'contact_email', 'contact_phone', 'heads', 'weekly', 'order' ) );
	if ( is_wp_error( $v ) ) {
		return $v;
	}
	ogc_log( 'vol_contact', $y, $c, array( 'version' => $v ) );
	$cm = ogc_vol_committees( $y );
	return rest_ensure_response( array( 'email' => $cm[ $c ]['contact_email'], 'phone' => $cm[ $c ]['contact_phone'], 'weekly' => 'no' !== $cm[ $c ]['weekly'], 'heads' => ogc_is_member( $y ) ? $cm[ $c ]['heads'] : '' ) );
}

/** Printed (what: done, the head said so after the print dialog: What to do ticks), or seen (what:
 * seen, Downloaded or the changes line's Clear: what's new is marked from now on, for this person). */
function ogc_vol_lead_printed( WP_REST_Request $req ) {
	$y  = (int) $req['year'];
	$c  = (string) $req->get_param( 'committee' );
	if ( 'done' === $req->get_param( 'what' ) ) {
		$d       = ogc_state_get( $y, 'vol-printed-done' );
		$dv      = $d ? (array) $d['value'] : array();
		$dv[ $c ] = ogc_now();
		ogc_state_put( $y, 'vol-printed-done', $dv );
		return rest_ensure_response( array( 'printed' => true ) );
	}
	$s  = ogc_state_get( $y, 'vol-printed' );
	$pr = $s ? (array) $s['value'] : array();
	$pr[ $c ][ ogc_current_email() ] = ogc_now();
	ogc_state_put( $y, 'vol-printed', $pr );
	return rest_ensure_response( array( 'since' => $pr[ $c ][ ogc_current_email() ] ) );
}

/** Parents with Young Folks in the halls (docs/16: one supervision shift asked of each): how many
 * households, how many have someone on the committee's shifts, and (for Remind) who hasn't. */
function ogc_vol_yf_households( $y, $c ) {
	$on = array();
	foreach ( ogc_vol_seat_map( $y ) as $id => $seats ) {
		$sh = ogc_vol_shifts( $y )[ $id ] ?? null;
		if ( $sh && $sh['committee'] === $c ) {
			foreach ( $seats as $s ) {
				$on[ $s['record']['email'] ] = true;
			}
		}
	}
	$total  = 0;
	$signed = 0;
	$not    = array();
	foreach ( ogc_records( $y, 'registrations' ) as $r ) {
		$p      = isset( $r['data']['people'] ) ? (array) $r['data']['people'] : array();
		$yf     = array_filter( $p, function ( $x ) { return ! empty( $x['yf'] ) || ( isset( $x['kind'] ) && 'yf' === $x['kind'] ); } );
		$adults = array_filter( $p, function ( $x ) { return isset( $x['kind'] ) ? 'adult' === $x['kind'] : ( isset( $x['band'] ) && 'adult' === $x['band'] && empty( $x['yf'] ) ); } );
		if ( ! $yf || ! $adults ) {
			continue;
		}
		$total++;
		if ( isset( $on[ $r['email'] ] ) ) {
			$signed++;
		} elseif ( $r['email'] && ! $r['sample'] ) {
			$not[] = $r['email'];
		} else {
			$not[] = '';
		}
	}
	return array( 'total' => $total, 'signed' => $signed, 'not' => $total - $signed, 'emails' => array_values( array_filter( $not ) ) );
}

/** Remind the parents not yet on a shift: one email each, at most once a day. */
function ogc_vol_lead_remind( WP_REST_Request $req ) {
	$y = (int) $req['year'];
	$c = (string) $req->get_param( 'committee' );
	if ( ! preg_match( '/young folk/i', $c ) ) {
		return ogc_vol_no( 'gone', 'Not found', array(), 404 );
	}
	$k = 'vol-remind';
	$s = ogc_state_get( $y, $k );
	if ( $s && substr( (string) $s['value'], 0, 10 ) === gmdate( 'Y-m-d' ) ) {
		return ogc_vol_no( 'slow', 'Sent today', array(), 429 );
	}
	$h = ogc_vol_yf_households( $y, $c );
	foreach ( $h['emails'] as $e ) {
		ogc_vol_queue( $y, 'remind', $e, array( 'committee' => $c ) );
	}
	ogc_state_put( $y, $k, ogc_now() );
	ogc_log( 'vol_remind', $y, $c, array( 'n' => count( $h['emails'] ) ) );
	return rest_ensure_response( array( 'queued' => count( $h['emails'] ) ) );
}

/* ================================================================== heads, notes, a person put right */

/** Does a Members committee key mean this shift committee? The same key, or a name the year's
 * committees and Members spell differently (Food ↔ Dining hall; filter ogc_vol_committee_aliases). */
function ogc_vol_committee_is( $member_key, $committee ) {
	$k = function_exists( 'ogc_committee_key' ) ? ogc_committee_key( $committee ) : strtolower( trim( $committee ) );
	if ( $member_key === $k ) {
		return true;
	}
	$alias = (array) apply_filters( 'ogc_vol_committee_aliases', array( 'food' => 'dining hall', 'kitchen' => 'dining hall', 'meals' => 'dining hall', 'dining' => 'dining hall', 'transport' => 'transportation', 'medical' => 'first aid', 'nursing' => 'first aid' ) );
	return isset( $alias[ $member_key ] ) && $alias[ $member_key ] === $k;
}

/** The heads of a committee: the year's Members on that committee marked Head (docs/23: one place says
 * who runs a committee). Nobody marked: none (Add head), never "everyone on it". Each {name: "Ruth K."
 * (or the address masked when Members has no name), email}. */
function ogc_vol_heads_of( $year, $committee ) {
	$out = array();
	if ( ! function_exists( 'ogc_members_list' ) || ! function_exists( 'ogc_member_committee_keys' ) ) {
		return $out;
	}
	foreach ( ogc_members_list( $year ) as $m ) {
		if ( empty( $m['head'] ) || ( function_exists( 'ogc_member_active' ) && ! ogc_member_active( $m ) ) ) {
			continue;
		}
		foreach ( ogc_member_committee_keys( $m ) as $k ) {
			if ( ogc_vol_committee_is( $k, $committee ) ) {
				$out[] = array( 'name' => $m['name'] ? ogc_vol_first_l( $m['name'] ) : ( function_exists( 'ogc_mask_email' ) ? ogc_mask_email( $m['email'] ) : '' ), 'email' => $m['email'] );
				break;
			}
		}
	}
	return $out;
}

/** Everyone "Message all heads" reaches: each committee's heads (Members) and its role contact. */
function ogc_vol_heads_emails( $year ) {
	$out = array();
	foreach ( ogc_vol_committees( $year ) as $cm ) {
		foreach ( ogc_vol_heads_of( $year, $cm['name'] ) as $h ) {
			$out[ strtolower( $h['email'] ) ] = true;
		}
		if ( is_email( $cm['contact_email'] ) ) {
			$out[ strtolower( $cm['contact_email'] ) ] = true;
		}
	}
	return array_keys( $out );
}

/** Who a head's message is from: "Phoebe L. · Transportation head", "Nathan K. · Committee of
 * Arrangements" (the year's COA), else the name and committee. */
function ogc_vol_sender_line( $year, $committee ) {
	$me = ogc_current_email();
	$u  = wp_get_current_user();
	$n  = $u && $u->ID ? ( function_exists( 'ogc_person_name' ) ? ogc_person_name( $u->ID ) : $u->display_name ) : '';
	$n  = $n ? ogc_vol_first_l( $n ) : '';
	$m  = function_exists( 'ogc_member_find' ) ? ogc_member_find( (int) $year, $me ) : null;
	if ( $m && 'coa' === $m['role'] ) {
		$role = 'Committee of Arrangements';
	} elseif ( $committee && ( in_array( $me, wp_list_pluck( ogc_vol_heads_of( $year, $committee ), 'email' ), true ) || in_array( $committee, ogc_vol_headed( $year ), true ) ) ) {
		$role = $committee . ' head';
	} else {
		$role = $committee ? $committee . ' committee' : $year . ' Annual Conference';
	}
	return trim( $n . ( $n ? ' · ' : '' ) . $role );
}

/** The rule as a column's or a line's name: "21 or older", "Certification", "Agreed". */
function ogc_vol_rule_label( $sh ) {
	if ( $sh['question'] ) {
		return preg_match( '/certif/i', $sh['rule'] . ' ' . implode( ' ', $sh['question'] ) ) ? 'Certification' : 'Answer';
	}
	return $sh['min_age'] ? $sh['min_age'] . ' or older' : 'Agreed';
}

/** Volunteer emails to these people the per-address limit refused in the last two weeks: by name. */
function ogc_vol_refused( $year, $emails ) {
	global $wpdb;
	if ( ! $emails || ! function_exists( 'ogc_mail_rows' ) ) {
		return array();
	}
	$keys = array_slice( array_keys( $emails ), 0, 500 );
	$ph   = implode( ',', array_fill( 0, count( $keys ), '%s' ) );
	$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT to_email, MAX(at) AS at, COUNT(*) AS n FROM ' . ogc_table( 'mail' ) . " WHERE status = 'refused' AND year = %d AND at > %s AND to_email IN ($ph) GROUP BY to_email", array_merge( array( (int) $year, gmdate( 'Y-m-d H:i:s', time() - 14 * DAY_IN_SECONDS ) ), $keys ) ), ARRAY_A ); // phpcs:ignore -- placeholders built above.
	$out  = array();
	foreach ( (array) $rows as $r ) {
		$out[] = array( 'name' => ogc_vol_first_l( $emails[ $r['to_email'] ] ), 'n' => (int) $r['n'], 'at' => $r['at'] );
	}
	return $out;
}

/** A note for next year's committee (one per committee a year, as its heads write it); '' removes it. */
function ogc_vol_lead_note( WP_REST_Request $req ) {
	$y    = (int) $req['year'];
	$c    = (string) $req->get_param( 'committee' );
	$text = mb_substr( sanitize_textarea_field( (string) $req->get_param( 'text' ) ), 0, 2000 );
	$s    = ogc_state_get( $y, 'vol-notes' );
	$n    = $s ? (array) $s['value'] : array();
	if ( '' === trim( $text ) ) {
		unset( $n[ $c ] );
	} else {
		$u       = wp_get_current_user();
		$n[ $c ] = array( 'text' => $text, 'at' => ogc_now(), 'by' => $u && $u->ID ? ogc_vol_first_l( $u->display_name ) : '' );
	}
	ogc_state_put( $y, 'vol-notes', $n );
	ogc_log( 'vol_note', $y, $c, array() );
	return rest_ensure_response( array( 'note' => isset( $n[ $c ] ) ? $n[ $c ] : null ) );
}

/** Edit: a person's name, phone or email put right by the head. A new email on an unconfirmed sign-up
 * gets the confirmation; the place stays the same. */
function ogc_vol_lead_edit( WP_REST_Request $req ) {
	global $wpdb;
	$y   = (int) $req['year'];
	$rec = ogc_record_get( (int) $req->get_param( 'id' ) );
	if ( ! $rec || 'signups' !== $rec['kind'] || (int) $rec['year'] !== $y ) {
		return ogc_vol_no( 'gone', 'Not found', array(), 404 );
	}
	$name  = ogc_vol_clean_name( $req->get_param( 'name' ) );
	$phone = ogc_vol_clean_phone( $req->get_param( 'phone' ) );
	$raw   = trim( (string) $req->get_param( 'email' ) );
	$email = strtolower( sanitize_email( $raw ) );
	// Typed but not an email ("nope") is named at the field, never dropped quietly.
	$errs  = array_filter( array( 'name' => false !== strpos( $name, ' ' ) ? '' : 'First and last name', 'phone' => $phone ? '' : 'Enter a phone number', 'email' => '' === $raw || is_email( $email ) ? '' : 'Check the email' ) );
	if ( $errs ) {
		return ogc_vol_no( 'fields', 'Check the form.', array( 'fields' => $errs ), 400 );
	}
	$d       = $rec['data'];
	$changed = $email !== $rec['email'];
	$d['name']  = $name;
	$d['phone'] = $phone;
	$d['email'] = $email;
	ogc_record_update( $rec['id'], $d, $email );
	$wpdb->update( ogc_table( 'vol_seats' ), array( 'pkey' => ogc_vol_pkey( $email, $name, $phone ) ), array( 'record_id' => (int) $rec['id'] ), array( '%s' ), array( '%d' ) );
	if ( $changed && $email ) {
		ogc_vol_outbox_drop( $rec['id'] );
		ogc_vol_queue_confirm( $y, $email, array( (int) $rec['id'] ), ! empty( $d['confirmed'] ), 0 );
	}
	ogc_log( 'vol_head_edit', $y, 'signups', array( 'id' => $rec['id'] ) );
	return rest_ensure_response( array( 'edited' => (int) $rec['id'] ) );
}

/** Resend: the confirmation (with its Confirm link while unconfirmed, and the calendar file) again. */
function ogc_vol_lead_resend( WP_REST_Request $req ) {
	$y   = (int) $req['year'];
	$rec = ogc_record_get( (int) $req->get_param( 'id' ) );
	if ( ! $rec || 'signups' !== $rec['kind'] || (int) $rec['year'] !== $y || ! is_email( $rec['email'] ) ) {
		return ogc_vol_no( 'gone', 'Not found', array(), 404 );
	}
	if ( ! ogc_vol_rate( 'leadresend|' . $rec['id'], 1, MINUTE_IN_SECONDS ) ) {
		return ogc_vol_no( 'slow', 'Sent · Just now', array(), 429 );
	}
	ogc_vol_queue_confirm( $y, $rec['email'], array( (int) $rec['id'] ), ! empty( $rec['data']['confirmed'] ), 0 );
	ogc_log( 'vol_head_resend', $y, 'signups', array( 'id' => $rec['id'] ) );
	return rest_ensure_response( array( 'sent' => true ) );
}
