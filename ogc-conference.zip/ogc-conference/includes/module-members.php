<?php
/**
 * Members: who may see and change a year (the COA and the helpers they add), and the Conference
 * webmasters (every year).
 *
 * One row a person a year (ogc_members): their email, role (coa | helper), the committees they're on
 * (keys of the year's committee list, committees.csv, which the COA writes and the pickup carries to
 * next year), whether they head it, a label in the COA's own words ("Lodging · Desk"), who invited
 * them, when they first signed in, and when access ends. The committee is what the app's screens follow
 * (docs/23: each person's screens follow from the committee the COA puts them on): ogc_member_committees().
 * Access is still one level a year on the server today; screens by committee are the app area's. Access ends on the Conference's last day plus 1–3 years (helpers 1, the COA 2 by default:
 * ogc_member_default_years), kept per person; while a year has no dates it reads "1 year after the
 * Conference" and becomes a date when the COA sets them.
 * ogc_is_member (core) asks this list on every request, so a removal or an end date takes effect on the
 * next page. It is the one rule: the members' routes ask it too (ogc_member_me), so a session older
 * than 30 days is asked to confirm everywhere. Removing someone ends their access at once and their
 * unused invite links; their sign-in stays (their household's Your sign-ups still opens).
 *
 * Who may do what (the screen never offers what the server refuses):
 *   webmasters   everything, every year; only they add COA members or remove the last one
 *   COA          invite, resend, renew and remove helpers; label anyone's "Helps with"
 *   helpers      see the list; change only their own name
 * Members' pages ask for a code again after 30 days on a device (module-auth.php).
 *
 * REST (DEV.md): GET/POST /years/{y}/members, PATCH/DELETE /members/{id}, POST /members/{id}/resend,
 * GET /years/{y}/members/history, GET /years/{y}/members/preview. Everything is logged by member id,
 * never by address.
 *
 * Webmasters: site admins (manage_options), and anyone given ogc_manage_all on Settings › Conference
 * webmasters.
 */

defined( 'ABSPATH' ) || exit;

// OGC_CAP_WEBMASTER ('ogc_manage_all') is defined in core.php, where ogc_is_webmaster reads it.
if ( ! defined( 'OGC_CAP_WEBMASTER' ) ) {
	define( 'OGC_CAP_WEBMASTER', 'ogc_manage_all' );
}

add_filter( 'ogc_schema', 'ogc_members_schema', 20, 2 );

function ogc_members_schema( $sql, $charset ) {
	$sql[] = 'CREATE TABLE ' . ogc_table( 'members' ) . " (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  year smallint(5) unsigned NOT NULL,
  email varchar(190) NOT NULL,
  role varchar(8) NOT NULL DEFAULT 'helper',
  name varchar(80) NOT NULL DEFAULT '',
  helps varchar(190) NOT NULL DEFAULT '',
  committees varchar(190) NOT NULL DEFAULT '',
  head tinyint(1) NOT NULL DEFAULT 0,
  invited_by bigint(20) unsigned NOT NULL DEFAULT 0,
  invited_at datetime NULL,
  signed_in_at datetime NULL,
  access_years tinyint(3) unsigned NOT NULL DEFAULT 2,
  expires_at datetime NULL,
  ending_sent datetime NULL,
  removed_at datetime NULL,
  removed_by bigint(20) unsigned NOT NULL DEFAULT 0,
  sample tinyint(1) NOT NULL DEFAULT 0,
  created_at datetime NOT NULL,
  PRIMARY KEY  (id),
  UNIQUE KEY year_email (year,email),
  KEY email (email)
) $charset;";
	return $sql;
}

/* ================================================================== reading */

function ogc_member_row( $r ) {
	if ( ! $r ) {
		return null;
	}
	foreach ( array( 'id', 'year', 'invited_by', 'access_years', 'removed_by', 'sample', 'head' ) as $k ) {
		$r[ $k ] = isset( $r[ $k ] ) ? (int) $r[ $k ] : 0;
	}
	$r['committees'] = isset( $r['committees'] ) ? (string) $r['committees'] : '';
	// "Lodging, Desk": a comma inside the value (the lists use " · " between fields).
	$r['helps'] = ogc_member_helps_clean( $r['helps'] );
	return $r;
}

/** What someone helps with, as the COA typed it: parts kept, joined with ", ". */
function ogc_member_helps_clean( $h ) {
	$parts = array_filter( array_map( 'trim', preg_split( '/\s*[·,;|]\s*/u', sanitize_text_field( (string) $h ) ) ), 'strlen' );
	return substr( implode( ', ', array_unique( $parts ) ), 0, 190 );
}

/** Rows already read in this request, by "year|email" (a page asks ogc_is_member many times). Cleared
 * whenever the list changes. */
function ogc_members_cache( $reset = false ) {
	if ( $reset || ! isset( $GLOBALS['ogc_members_c'] ) ) {
		$GLOBALS['ogc_members_c'] = array();
	}
	return $GLOBALS['ogc_members_c'];
}

function ogc_member_find( $year, $email, $with_removed = false ) {
	global $wpdb;
	$email = ogc_clean_email( $email );
	if ( '' === $email ) {
		return null;
	}
	ogc_members_cache();
	$k = (int) $year . '|' . $email;
	if ( ! array_key_exists( $k, $GLOBALS['ogc_members_c'] ) ) {
		$GLOBALS['ogc_members_c'][ $k ] = ogc_member_row( $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . ogc_table( 'members' ) . ' WHERE year = %d AND email = %s', $year, $email ), ARRAY_A ) );
	}
	$r = $GLOBALS['ogc_members_c'][ $k ];
	return $r && ( $with_removed || ! $r['removed_at'] ) ? $r : null;
}

/** How long access lasts after the Conference, by role, until the COA and Advisors say (questions-signin
 * Q16): helpers 1 year (a desk shift doesn't need two years of every list), the COA 2. */
function ogc_member_default_years( $role ) {
	$y = 'coa' === $role ? 2 : 1;
	return min( 3, max( 1, (int) apply_filters( 'ogc_member_default_years', $y, $role ) ) );
}

function ogc_member_get( $id ) {
	global $wpdb;
	return ogc_member_row( $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . ogc_table( 'members' ) . ' WHERE id = %d', $id ), ARRAY_A ) );
}

function ogc_members_list( $year, $with_removed = false ) {
	global $wpdb;
	$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . ogc_table( 'members' ) . ' WHERE year = %d' . ( $with_removed ? '' : ' AND removed_at IS NULL' ) . ' ORDER BY id', $year ), ARRAY_A );
	return array_map( 'ogc_member_row', (array) $rows );
}

/** Every unremoved row for an address, any year. */
function ogc_member_rows_for( $email ) {
	global $wpdb;
	$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . ogc_table( 'members' ) . ' WHERE email = %s AND removed_at IS NULL ORDER BY year DESC', ogc_clean_email( $email ) ), ARRAY_A );
	return array_map( 'ogc_member_row', (array) $rows );
}

/** When access ends ('Y-m-d H:i:s' UTC), or null while the year has no dates. */
function ogc_member_expiry( $m ) {
	if ( ! empty( $m['expires_at'] ) ) {
		return $m['expires_at'];
	}
	$y = ogc_year_get( (int) $m['year'] );
	if ( $y && ! empty( $y['end'] ) && preg_match( '/^\d{4}-\d{2}-\d{2}$/', $y['end'] ) ) {
		$t = strtotime( $y['end'] . ' 23:59:59 UTC' );
		return gmdate( 'Y-m-d H:i:s', strtotime( '+' . max( 1, (int) $m['access_years'] ) . ' years', $t ) );
	}
	return null;
}

function ogc_member_active( $m ) {
	if ( ! $m || $m['removed_at'] ) {
		return false;
	}
	$x = ogc_member_expiry( $m );
	return null === $x || strtotime( $x . ' UTC' ) > time();
}

/** "Oct 2, 2026" (or "Oct 2" this year). */
function ogc_member_date( $dt, $year_always = false ) {
	$t = strtotime( (string) $dt . ' UTC' );
	if ( ! $t ) {
		return '';
	}
	return wp_date( ( $year_always || wp_date( 'Y', $t ) !== wp_date( 'Y' ) ) ? 'M j, Y' : 'M j', $t );
}

/** A status's day: "today", "yesterday", else "Oct 2" (the site's clock, the live site's zone). */
function ogc_member_day( $dt ) {
	$t = strtotime( (string) $dt . ' UTC' );
	if ( ! $t ) {
		return '';
	}
	$d = wp_date( 'Y-m-d', $t );
	if ( wp_date( 'Y-m-d' ) === $d ) {
		return 'today';
	}
	if ( wp_date( 'Y-m-d', time() - DAY_IN_SECONDS ) === $d ) {
		return 'yesterday';
	}
	return ogc_member_date( $dt );
}

/** "Jun 1, 2029", or "1 year after the Conference" while the year has no dates. */
function ogc_member_until_label( $m ) {
	$x = ogc_member_expiry( $m );
	if ( $x ) {
		return ogc_member_date( $x, true );
	}
	$n = max( 1, (int) $m['access_years'] );
	return $n . ' year' . ( 1 === $n ? '' : 's' ) . ' after the Conference';
}

/* ================================================================== who is a member */

// The answer to core's ogc_is_member: an active row for this year and email. A member signed in more
// than 30 days ago on this device is asked to confirm (a code) before their pages open again.
add_filter( 'ogc_is_member', 'ogc_members_is_member', 10, 4 );

function ogc_members_is_member( $is, $year, $user_id, $email ) {
	if ( $is ) {
		return true;
	}
	$m = ogc_member_find( $year, $email );
	if ( ! ogc_member_active( $m ) ) {
		return false;
	}
	if ( (int) $user_id === get_current_user_id() && ogc_is_person_only( $user_id ) ) {
		$t = ogc_session_login_time( $user_id );
		if ( $t && $t < time() - (int) apply_filters( 'ogc_member_reauth_days', 30 ) * DAY_IN_SECONDS ) {
			$GLOBALS['ogc_reauth'] = true;
			return false;
		}
	}
	return true;
}

/** The viewer's own active row for a year, through the same rule as every page (ogc_is_member: removed,
 * expired, and a session older than 30 days all say no). */
function ogc_member_me( $year ) {
	if ( ! ogc_is_member( $year ) ) {
		return null;
	}
	$m = ogc_member_find( $year, ogc_current_email() );
	return ogc_member_active( $m ) ? $m : null;
}

/** A committee name as compared: lowercased, "committee" and "the" dropped ("The Lodging committee" →
 * "lodging"). */
function ogc_committee_key( $n ) {
	$n = strtolower( trim( preg_replace( '/\s+/', ' ', (string) $n ) ) );
	$n = preg_replace( '/^the\s+|\s+committee$/', '', $n );
	return trim( $n );
}

/** The year's committees in their own words: the shifts' committee column, the owners the COA chose
 * (owner_<part>), and what members already help with. Suggestions for "Helps with". */
function ogc_year_committees( $year ) {
	$out = array();
	$add = function ( $n ) use ( &$out ) {
		$n = trim( preg_replace( '/\s+committee$/i', '', trim( (string) $n ) ) );
		if ( '' !== $n && strlen( $n ) <= 60 && ! isset( $out[ ogc_committee_key( $n ) ] ) ) {
			$out[ ogc_committee_key( $n ) ] = $n;
		}
	};
	$f = function_exists( 'ogc_file_get' ) ? ogc_file_get( (int) $year, 'shifts' ) : null;
	foreach ( $f ? (array) $f['rows'] : array() as $r ) {
		if ( ! empty( $r['committee'] ) ) {
			$add( $r['committee'] );
		}
	}
	foreach ( ogc_mail_settings( $year ) as $k => $v ) {
		if ( 0 === strpos( $k, 'owner_' ) ) {
			$add( $v );
		}
	}
	foreach ( ogc_members_list( $year ) as $m ) {
		foreach ( explode( ',', $m['helps'] ) as $h ) {
			$add( $h );
		}
	}
	natcasesort( $out );
	return array_values( $out );
}

/**
 * The year's committees, key → name: the list the COA writes (committees.csv, in its order), else the
 * names its requests and shifts use, then any a member is already on. "Helps with" is chosen from
 * these (pills), and the app's screens follow them.
 */
function ogc_members_committee_list( $year ) {
	$out = array();
	$add = function ( $n ) use ( &$out ) {
		$n = trim( preg_replace( '/\s+committee$/i', '', trim( (string) $n ) ) );
		$k = ogc_committee_key( $n );
		if ( '' !== $k && strlen( $n ) <= 60 && ! isset( $out[ $k ] ) && 0 !== strpos( $n, '#' ) ) {
			$out[ $k ] = $n;
		}
	};
	$f = function_exists( 'ogc_file_get' ) ? ogc_file_get( (int) $year, 'committees' ) : null;
	foreach ( $f ? (array) $f['rows'] : array() as $r ) {
		$add( isset( $r['name'] ) ? $r['name'] : '' );
	}
	if ( ! $out ) {
		foreach ( array( 'needs', 'shifts' ) as $name ) {
			$g = function_exists( 'ogc_file_get' ) ? ogc_file_get( (int) $year, $name ) : null;
			foreach ( $g ? (array) $g['rows'] : array() as $r ) {
				$add( isset( $r['committee'] ) ? $r['committee'] : '' );
			}
		}
		// No list of the COA's own yet: A–Z, so a committee is found where it's looked for.
		uasort( $out, 'strnatcasecmp' );
	}
	foreach ( ogc_members_list( $year ) as $m ) {
		foreach ( ogc_member_committee_keys( $m ) as $k ) {
			if ( ! isset( $out[ $k ] ) ) {
				$out[ $k ] = ogc_member_committee_name( $m, $k );
			}
		}
	}
	return $out;
}

/** A row's committee keys ("lodging", "food"). */
function ogc_member_committee_keys( $m ) {
	return array_values( array_filter( array_map( 'trim', explode( ',', (string) ( isset( $m['committees'] ) ? $m['committees'] : '' ) ) ), 'strlen' ) );
}

/** A committee's name as the row's label spells it ("Lodging"), else the key in title case. */
function ogc_member_committee_name( $m, $key ) {
	foreach ( preg_split( '/\s*[·,;|]\s*/u', (string) $m['helps'] ) as $h ) {
		if ( ogc_committee_key( $h ) === $key ) {
			return trim( $h );
		}
	}
	return ucwords( $key );
}

/** The committees someone is on in a year (keys), for the app's screens: array() for the COA (who see
 * every screen) and for anyone not a member. */
function ogc_member_committees( $year, $email = '' ) {
	$m = ogc_member_find( (int) $year, $email ? $email : ogc_current_email() );
	return $m && ogc_member_active( $m ) && 'coa' !== $m['role'] ? ogc_member_committee_keys( $m ) : array();
}

/** Keys and new names → the committee keys for a row, adding any new committee to the year's list
 * (committees.csv; written the way the year page writes it, so its list and Members agree). */
function ogc_members_committees_in( $year, $given, $new = '' ) {
	$list = ogc_members_committee_list( $year );
	$keys = array();
	foreach ( (array) $given as $g ) {
		$k = ogc_committee_key( sanitize_text_field( (string) $g ) );
		if ( '' !== $k && isset( $list[ $k ] ) ) {
			$keys[] = $k;
		}
	}
	$new = trim( preg_replace( '/\s+committee$/i', '', sanitize_text_field( (string) $new ) ) );
	if ( '' !== $new && strlen( $new ) <= 60 ) {
		$k = ogc_committee_key( $new );
		if ( ! isset( $list[ $k ] ) ) {
			ogc_members_committee_add( $year, $new );
			ogc_log( 'committee_add', $year, 'committee', array( 'name' => $new ) );
		}
		$keys[] = $k;
	}
	return array_slice( array_values( array_unique( $keys ) ), 0, 4 );
}

/** Add a committee to the year's list (committees.csv). With no list kept yet, the names the year's
 * requests and shifts use come first, so the year page's list doesn't lose them. */
function ogc_members_committee_add( $year, $name ) {
	for ( $try = 0; $try < 4; $try++ ) {
		$cur  = ogc_file_get( (int) $year, 'committees' );
		$rows = $cur ? $cur['rows'] : array();
		if ( ! $cur ) {
			foreach ( ogc_members_committee_list( $year ) as $n ) {
				$rows[] = array( 'name' => $n, 'contact_email' => '', 'contact_phone' => '', 'heads' => '', 'weekly' => 'yes', 'order' => '' );
			}
		}
		foreach ( $rows as $r ) {
			if ( isset( $r['name'] ) && ogc_committee_key( $r['name'] ) === ogc_committee_key( $name ) ) {
				return true;
			}
		}
		$rows[] = array( 'name' => $name, 'contact_email' => '', 'contact_phone' => '', 'heads' => '', 'weekly' => 'yes', 'order' => '' );
		$v      = ogc_file_put( (int) $year, 'committees', $rows, $cur ? $cur['version'] : 0 );
		if ( ! is_wp_error( $v ) ) {
			return true;
		}
	}
	return false;
}

/** What a member is, in words: "Committee of Arrangements", "Lodging · Head", "Food". */
function ogc_member_role_words( $m ) {
	if ( 'coa' === $m['role'] ) {
		return 'Committee of Arrangements';
	}
	$names = array();
	foreach ( ogc_member_committee_keys( $m ) as $k ) {
		$names[] = ogc_member_committee_name( $m, $k );
	}
	if ( ! $names ) {
		return 'Helper';
	}
	return implode( ' · ', $names ) . ( ! empty( $m['head'] ) ? ' · Head' : '' );
}

/** A member's committees as an email or a card says them: "Committee of Arrangements", "Lodging
 * (Head)", "Lodging, Food"; '' for a helper on none. */
function ogc_member_committee_words( $m ) {
	if ( 'coa' === $m['role'] ) {
		return 'Committee of Arrangements';
	}
	$names = array();
	foreach ( ogc_member_committee_keys( $m ) as $k ) {
		$names[] = ogc_member_committee_name( $m, $k );
	}
	if ( ! $names ) {
		return trim( (string) $m['helps'] );
	}
	return implode( ', ', $names ) . ( ! empty( $m['head'] ) ? ' (Head)' : '' );
}

/** The one button that opens a member's year, named for where it lands: "Open Lodging" for a helper
 * who starts on their committee's page, "Open 2027" for the COA (and anyone who starts on the year). */
function ogc_member_open_label( $m, $landing = null ) {
	$y       = (int) $m['year'];
	$landing = null === $landing ? ogc_member_landing( $y, $m['email'] ) : $landing;
	if ( 'coa' === $m['role'] || wp_make_link_relative( ogc_url( 'year', array( 'year' => $y ) ) ) === $landing ) {
		return 'Open ' . $y;
	}
	$keys = ogc_member_committee_keys( $m );
	$name = $keys ? ogc_member_committee_name( $m, $keys[0] ) : ogc_member_landing_label( $landing );
	return 'Open ' . ( '' !== $name ? $name : $y );
}

/** A committee's own screens, in words, once the app names them ("Households, Rooms, Check-in"): the
 * invite says them. '' until an area fills the ogc_committee_screens filter. */
function ogc_committee_screens( $year, $key ) {
	return (string) apply_filters( 'ogc_committee_screens', '', (int) $year, (string) $key );
}

/**
 * Where a member lands when they follow their invite or sign in: a path. Nothing is assumed about who
 * does what (no-assumed-owners): a committee that has its own page or list (Lodging's page, the
 * Preteens list, a committee's volunteer list) when "Helps with" names it exactly; else the year's part
 * whose owner the COA chose (owner_<part>) is that committee; else the year's own page.
 */
function ogc_member_landing( $year, $email ) {
	$m = ogc_member_find( (int) $year, $email );
	return ogc_member_landing_for( (int) $year, $m ? $m['role'] : 'coa', $m ? ogc_member_landing_words( $m ) : '' );
}

/** What a row's landing is worked out from: its committees, else its label. */
function ogc_member_landing_words( $m ) {
	$k = ogc_member_committee_keys( $m );
	return $k ? implode( ',', $k ) : (string) $m['helps'];
}

/** The same, for a role and "Helps with" not yet saved (the Invite form, its Preview). */
function ogc_member_landing_for( $year, $role, $helps ) {
	$year = (int) $year;
	// An area that is the members' own place (the app) answers first.
	$pre = apply_filters( 'ogc_member_landing_pre', null, $year, $role, $helps );
	if ( is_string( $pre ) && '' !== $pre ) {
		return $pre;
	}
	$home = wp_make_link_relative( ogc_url( 'year', array( 'year' => $year ) ) );
	if ( 'coa' === $role || '' === trim( (string) $helps ) ) {
		return $home;
	}
	$want = array();
	foreach ( explode( ',', (string) $helps ) as $h ) {
		if ( '' !== ogc_committee_key( $h ) ) {
			$want[] = ogc_committee_key( $h );
		}
	}
	// The committees whose own page is named for them. An area adds its own with the filter.
	$pages = (array) apply_filters( 'ogc_member_landing_pages', array(
		'lodging'     => array( 'lodging', array() ),
		'preteens'    => array( 'lists', array( 'view' => 'preteens' ) ),
		'communion'   => array( 'lists', array( 'view' => 'communion' ) ),
		'young folks' => array( 'tournaments', array( 'view' => 'teams' ) ),
	), $year );
	foreach ( $want as $w ) {
		if ( isset( $pages[ $w ] ) ) {
			return wp_make_link_relative( ogc_url( $pages[ $w ][0], array_merge( array( 'year' => $year ), (array) $pages[ $w ][1] ) ) );
		}
	}
	// A committee with shifts this year: its list of who's signed up.
	$f = function_exists( 'ogc_file_get' ) ? ogc_file_get( $year, 'shifts' ) : null;
	foreach ( $f ? (array) $f['rows'] : array() as $r ) {
		if ( ! empty( $r['committee'] ) && in_array( ogc_committee_key( $r['committee'] ), $want, true ) ) {
			return wp_make_link_relative( ogc_url( 'volunteer', array( 'year' => $year, 'view' => 'lead', 'committee' => trim( $r['committee'] ) ) ) );
		}
	}
	foreach ( ogc_mail_settings( $year ) as $k => $v ) {
		if ( 0 === strpos( $k, 'owner_' ) && '' !== trim( $v ) && in_array( ogc_committee_key( $v ), $want, true ) ) {
			return wp_make_link_relative( ogc_url( 'year', array( 'year' => $year, 'part' => sanitize_key( substr( $k, 6 ) ) ) ) );
		}
	}
	return $home;
}

/** The words for where someone lands ("Lodging", "Preteens list", "The schedule"), shown in the invite
 * and beside "Helps with" in the Invite form; '' for the year's own page. */
function ogc_member_landing_label( $path ) {
	$q = array();
	wp_parse_str( (string) wp_parse_url( $path, PHP_URL_QUERY ), $q );
	$p = trim( (string) wp_parse_url( $path, PHP_URL_PATH ), '/' );
	$k = basename( $p );
	$parts = array( 'conference' => 'The Conference', 'schedule' => 'The schedule', 'requests' => 'Requests to the campus', 'registration' => 'Registration', 'helping' => 'Volunteer shifts', 'youngfolks' => 'Young Folks', 'packet' => 'The packet' );
	if ( 'lodging' === $k ) {
		return 'Lodging';
	}
	if ( 'lists' === $k ) {
		return isset( $q['view'] ) ? ucfirst( sanitize_key( $q['view'] ) ) . ' list' : 'Lists';
	}
	if ( 'tournaments' === $k ) {
		return 'Young Folks teams';
	}
	if ( 'volunteer' === $k ) {
		return isset( $q['committee'] ) ? 'Who’s signed up · ' . sanitize_text_field( $q['committee'] ) : 'Who’s signed up';
	}
	if ( 'year' === $k && ! empty( $q['part'] ) ) {
		return isset( $parts[ $q['part'] ] ) ? $parts[ $q['part'] ] : '';
	}
	return '';
}

/* ================================================================== Handles money (decision 4) */

/**
 * Handles money: a tick on a member of the year, set only by the year's COA (Members), logged and shown
 * on the member's row and the Money screen ("Treasurer"). Whoever has it sees each payment, marks checks
 * received and approves refunds (module-guard.php ogc_access 'money'); nobody else does, the COA and the
 * webmasters included, and with no one ticked, no one. It doesn't carry to next year.
 *
 * Kept as the year's state value payment_viewers (the emails ticked), the same list the Money screen's
 * Choose treasurer writes, so there is one list, not two. The registration area's older money_people
 * list is read as the same tick until it's emptied (Untick takes a person off both).
 */
function ogc_member_money_emails( $year ) {
	$out = array();
	foreach ( array( 'payment_viewers', 'money_people' ) as $k ) {
		$s = ogc_state_get( (int) $year, $k );
		foreach ( $s && is_array( $s['value'] ) ? $s['value'] : array() as $e ) {
			$e = strtolower( trim( (string) $e ) );
			if ( '' !== $e ) {
				$out[ $e ] = true;
			}
		}
	}
	return array_keys( $out );
}

function ogc_member_handles_money( $year, $email ) {
	$email = strtolower( trim( (string) $email ) );
	return '' !== $email && in_array( $email, ogc_member_money_emails( $year ), true );
}

/** Tick or untick a member's Handles money (the caller checks who may). */
function ogc_member_set_money( $year, $email, $on ) {
	$email = strtolower( trim( (string) $email ) );
	foreach ( array( 'payment_viewers', 'money_people' ) as $k ) {
		$s    = ogc_state_get( (int) $year, $k );
		$list = $s && is_array( $s['value'] ) ? array_values( array_filter( array_map( function ( $e ) { return strtolower( trim( (string) $e ) ); }, $s['value'] ), 'strlen' ) ) : array();
		$has  = in_array( $email, $list, true );
		if ( $on && 'payment_viewers' === $k && ! $has ) {
			$list[] = $email;
		} elseif ( ! $on && $has ) {
			$list = array_values( array_diff( $list, array( $email ) ) );
		} else {
			continue;
		}
		ogc_state_put( (int) $year, $k, array_slice( $list, 0, 20 ) );
	}
}

/** What the viewer may do in a year's list (and to one row). */
function ogc_member_can( $action, $year, $target = null ) {
	if ( ogc_is_webmaster() ) {
		// Never what decides their own access: their role, committees, end date or address on a year is
		// for another webmaster or the COA (critique, Oct 14: a webmaster put themselves on the COA and read
		// every child's medical note). They may take themselves off.
		$own = $target && '' !== ogc_current_email() && strtolower( (string) $target['email'] ) === ogc_current_email();
		return ! ( $own && in_array( $action, array( 'role', 'label', 'renew', 'email' ), true ) );
	}
	$me = ogc_member_me( $year );
	if ( ! $me && ogc_is_member( $year ) ) {
		// A member by another rule (on a local site, the dev sign-in's &member=): the COA's powers.
		$me = array( 'id' => 0, 'role' => OGC_DEV ? 'coa' : 'helper' );
	}
	if ( ! $me ) {
		return false;
	}
	$coa  = 'coa' === $me['role'];
	$self = $target && (int) $target['id'] === (int) $me['id'];
	switch ( $action ) {
		case 'read':
			return true;
		case 'invite':
		case 'label':
			return $coa;
		case 'resend':
			return $coa;
		case 'remove':
			// A webmaster on the COA, too: the COA can undo a webmaster joining (it shows on Privacy).
			return $coa && $target && ! $self && ( 'helper' === $target['role'] || ogc_member_is_webmaster_row( $target ) );
		case 'renew':
		case 'email':
			return $coa && $target && 'helper' === $target['role'] && ! $self;
		case 'name':
			return $coa || $self;
		case 'role':
		case 'invite_coa':
			return false;
	}
	return false;
}

/** Is this member row a webmaster's address (someone who keeps the website, on the year too)? */
function ogc_member_is_webmaster_row( $m ) {
	$u = $m && ! empty( $m['email'] ) ? get_user_by( 'email', (string) $m['email'] ) : null;
	return $u ? ogc_is_webmaster( (int) $u->ID ) : false;
}

/* ================================================================== changing */

/**
 * Addresses as people paste them: one a line, or separated by commas, semicolons or tabs;
 * "Daniel Hoover <dan@x.com>", "dan@x.com", or a spreadsheet's name and email columns.
 * Returns array( 'ok' => [[name, email]…], 'bad' => [text…] ).
 */
function ogc_members_parse( $raw ) {
	$ok   = array();
	$bad  = array();
	$seen = array();
	$raw  = is_array( $raw ) ? implode( "\n", array_map( 'strval', $raw ) ) : (string) $raw;
	// Lines, commas and semicolons separate people; a tab is a spreadsheet's next column (the name
	// beside the address), so it's only a space.
	// Outlook's "Wenger, Ezra <ezra@x.com>": a piece with no @ followed by a "First <address>" piece is
	// the surname, so the two are one person ("Ezra Wenger").
	$pieces = preg_split( '/[\r\n;,]+(?![^<]*>)/', $raw );
	for ( $i = 0; $i < count( $pieces ) - 1; $i++ ) {
		$a = trim( $pieces[ $i ] );
		if ( '' !== $a && false === strpos( $a, '@' ) && preg_match( '/^\s*([^@<]*?)\s*<[^>]+@[^>]+>\s*$/', $pieces[ $i + 1 ], $mm ) && '' !== $mm[1] ) {
			$next             = trim( $pieces[ $i + 1 ] );
			$pieces[ $i + 1 ] = trim( $mm[1] ) . ' ' . trim( $a, " \"'" ) . ' ' . substr( $next, strpos( $next, '<' ) );
			$pieces[ $i ]     = '';
		}
	}
	foreach ( $pieces as $piece ) {
		$piece = trim( str_replace( "\t", ' ', $piece ), " \"'" );
		if ( '' === $piece ) {
			continue;
		}
		$name  = '';
		$email = '';
		if ( preg_match( '/^(.*?)<\s*([^>]+?)\s*>\s*$/', $piece, $m ) ) {
			$name  = trim( $m[1], " \t\"'" );
			$email = $m[2];
		} else {
			$words = preg_split( '/\s+/', $piece );
			foreach ( $words as $i => $w ) {
				if ( false !== strpos( $w, '@' ) ) {
					$email = $w;
					unset( $words[ $i ] );
					break;
				}
			}
			$name = trim( implode( ' ', $words ) );
			if ( '' === $email ) {
				$email = $piece;
			}
		}
		$email = ogc_clean_email( preg_replace( '/^mailto:/i', '', trim( $email, " \t\"'()[]<>" ) ) );
		if ( ! is_email( $email ) ) {
			$bad[] = $piece;
			continue;
		}
		if ( isset( $seen[ $email ] ) ) {
			continue;
		}
		$seen[ $email ] = true;
		$ok[]           = array( ogc_mail_safe_name( $name ), $email );
	}
	return array( 'ok' => $ok, 'bad' => $bad );
}

/**
 * A likely typo in an invite ("lydia@gmial.com") goes to whoever owns that domain, with a link to the
 * year's lists: the server asks once, whichever page sent it. The first send with one is refused (409
 * ogc_typo, nothing added) and remembered for 15 minutes; sending the same address again, or with
 * typos_ok (the Members card has already asked), goes ahead. Returns null or WP_Error.
 */
function ogc_members_typo_check( $parsed, $typos_ok ) {
	$sus = array();
	foreach ( $parsed['ok'] as $p ) {
		$fix = ogc_email_suggest( $p[1] );
		if ( '' === $fix ) {
			continue;
		}
		$k = 'ogc_typo_' . md5( get_current_user_id() . '|' . $p[1] );
		if ( $typos_ok || get_transient( $k ) ) {
			continue;
		}
		set_transient( $k, 1, 15 * MINUTE_IN_SECONDS );
		$sus[] = array( 'email' => $p[1], 'fix' => $fix );
	}
	if ( ! $sus ) {
		return null;
	}
	$one = $sus[0];
	$msg = 'Check ' . $one['email'] . ' · Did you mean ' . substr( $one['fix'], strrpos( $one['fix'], '@' ) + 1 ) . '?' . ( count( $sus ) > 1 ? ' · ' . ( count( $sus ) - 1 ) . ' more' : '' ) . ' · Invite again to send as typed';
	return new WP_Error( 'ogc_typo', $msg, array( 'status' => 409, 'suspect' => $sus ) );
}

/** Email someone their own link for a year (an invite: one use, 7 days) and note when it went. The
 * inviter is named ("Nathan K. added you") and replies go to them: the person invited knows them, so
 * "Who is this?" reaches someone. */
function ogc_member_send_invite( $m, $by_user = 0, $queue = false ) {
	global $wpdb;
	$by   = $by_user ? ogc_person_name( $by_user ) : '';
	$ret  = ogc_member_landing( (int) $m['year'], $m['email'] );
	$url  = ogc_signin_link_for( $m['email'], $ret, 'invite', array( 'year' => (int) $m['year'], 'member' => (int) $m['id'], 'by' => (int) $by_user ) );
	$from = $by_user ? get_userdata( (int) $by_user ) : null;
	$byr  = $by_user ? ogc_member_find( (int) $m['year'], ogc_user_email( (int) $by_user ), true ) : null;
	ogc_mail_send_kind( 'invite', $m['email'], array(
		'year'            => (int) $m['year'],
		'by_name'         => $by,
		// A webmaster who isn't on the year is "the webmasters"; a COA member or head says their role.
		'by_webmaster'    => $by_user && ogc_is_webmaster( $by_user ) && ! $byr,
		'by_role'         => $byr ? ( 'coa' === $byr['role'] ? 'COA' : ogc_member_committee_words( $byr ) ) : '',
		'first'           => (string) apply_filters( 'ogc_member_first', '', $m ),
		'role'            => $m['role'],
		'committee_words' => ogc_member_committee_words( $m ),
		'access'          => (string) apply_filters( 'ogc_member_access', '', $m ),
		'open_label'      => ogc_member_open_label( $m, $ret ),
		'landing_url'     => home_url( $ret ),
		'until'           => ogc_member_until_label( $m ),
		'url'             => $url,
		'reply_by'        => $from && is_email( $from->user_email ),
	), array( 'reply_to' => $from && is_email( $from->user_email ) ? strtolower( $from->user_email ) : '', 'queue' => $queue, 'to_member' => true ) );
	$wpdb->update( ogc_table( 'members' ), array( 'invited_at' => ogc_now() ), array( 'id' => (int) $m['id'] ) );
	ogc_members_cache( true );
}

/**
 * Invite people to a year. $a: role (coa|helper), years (1–3; 0 for the role's default), committees
 * (keys), head (bool), new_committee (a name to add to the year's list), helps (a label; the committee
 * names when left empty).
 * Returns array( added => [rows], already => [rows], bad => [text] ).
 */
function ogc_members_invite( $year, $raw, $a = array() ) {
	global $wpdb;
	$a      = array_merge( array( 'role' => 'helper', 'years' => 0, 'helps' => '', 'committees' => array(), 'head' => false, 'new_committee' => '' ), (array) $a );
	$role   = 'coa' === $a['role'] ? 'coa' : 'helper';
	$years  = (int) $a['years'] ? min( 3, max( 1, (int) $a['years'] ) ) : ogc_member_default_years( $role );
	$keys   = 'coa' === $role ? array() : ogc_members_committees_in( $year, $a['committees'], $a['new_committee'] );
	$list   = ogc_members_committee_list( $year );
	$helps  = ogc_member_helps_clean( $a['helps'] );
	if ( '' === $helps && $keys ) {
		$helps = ogc_member_helps_clean( implode( ', ', array_map( function ( $k ) use ( $list ) {
			return isset( $list[ $k ] ) ? $list[ $k ] : $k;
		}, $keys ) ) );
	}
	$head   = $keys && ! empty( $a['head'] ) ? 1 : 0;
	$parsed = ogc_members_parse( $raw );
	// More than a handful: the invites go through the mail queue (WP-Cron, 25 at a time), so a slow mail
	// server can't time the request out halfway through a list.
	$queue  = count( $parsed['ok'] ) > 5;
	$out    = array( 'added' => array(), 'already' => array(), 'merged' => array(), 'bad' => $parsed['bad'] );
	$by     = get_current_user_id();
	foreach ( $parsed['ok'] as $p ) {
		list( $name, $email ) = $p;
		$m = ogc_member_find( $year, $email, true );
		if ( $m && ! $m['removed_at'] && ogc_member_active( $m ) ) {
			// Round 6b (P3): a helper already on the year gets the ticked committees added to theirs, one
			// row. Not a head: Head is one flag for all their committees until Head per committee (task 19),
			// so a head stays as they are ("already"), and so does the COA.
			$have = ogc_member_committee_keys( $m );
			$more = array_values( array_diff( $keys, $have ) );
			if ( 'helper' === $role && 'helper' === $m['role'] && $more && empty( $m['head'] ) ) {
				$all = array_merge( $have, $more );
				$wpdb->update( ogc_table( 'members' ), array( 'committees' => implode( ',', $all ), 'helps' => ogc_member_helps_clean( implode( ', ', array_map( function ( $k ) use ( $list ) {
					return isset( $list[ $k ] ) ? $list[ $k ] : $k;
				}, $all ) ) ), 'head' => 1 === count( $all ) && $head ? 1 : 0 ), array( 'id' => (int) $m['id'] ) );
				ogc_members_cache( true );
				ogc_log( 'member_label', $year, 'member:' . $m['id'], array() );
				$m = ogc_member_get( (int) $m['id'] );
				ogc_member_send_invite( $m, $by, $queue );
				$out['merged'][] = $m;
				continue;
			}
			$out['already'][] = $m;
			continue;
		}
		if ( $m ) {
			// Removed or expired before: back on the list, with a fresh start.
			$wpdb->update( ogc_table( 'members' ), array( 'role' => $role, 'removed_at' => null, 'removed_by' => 0, 'expires_at' => null, 'ending_sent' => null, 'access_years' => $years, 'invited_by' => $by, 'helps' => $helps ? $helps : $m['helps'], 'committees' => $keys ? implode( ',', $keys ) : $m['committees'], 'head' => $head, 'name' => $name ? $name : $m['name'] ), array( 'id' => $m['id'] ) );
			$id = (int) $m['id'];
		} else {
			$wpdb->insert( ogc_table( 'members' ), array(
				'year'         => (int) $year,
				'email'        => $email,
				'role'         => $role,
				'name'         => $name,
				'helps'        => $helps,
				'committees'   => implode( ',', $keys ),
				'head'         => $head,
				'invited_by'   => $by,
				'access_years' => $years,
				'created_at'   => ogc_now(),
			) );
			$id = (int) $wpdb->insert_id;
		}
		ogc_members_cache( true );
		$m = ogc_member_get( $id );
		if ( ! $m ) {
			continue;
		}
		$u = ogc_person_for_email( $email );
		if ( $u && $name && '' === ogc_person_name( $u->ID ) ) {
			ogc_person_set_name( $u->ID, $name );
		}
		ogc_member_send_invite( $m, $by, $queue );
		ogc_log( 'member_invite', $year, 'member:' . $id, array( 'role' => $role ) );
		$out['added'][] = ogc_member_get( $id );
	}
	return $out;
}

/** A member as History names them, at the time it's written: "Joel M.", else the masked address. */
function ogc_member_short( $m ) {
	return $m['name'] ? ogc_first_l( $m['name'] ) : ogc_mask_email( $m['email'] );
}

/** Remove someone from a year: access ends now (every members' page and route checks the list on each
 * request). Their sign-in stays, so their household's Your sign-ups still opens on their devices; their
 * unused invite links for the year end (one would still say "Nathan K. added you · Open 2027"). Undo
 * restores the row; a new invite is a Resend. */
function ogc_member_remove( $m ) {
	global $wpdb;
	$wpdb->update( ogc_table( 'members' ), array( 'removed_at' => ogc_now(), 'removed_by' => get_current_user_id() ), array( 'id' => (int) $m['id'] ) );
	ogc_members_cache( true );
	ogc_member_end_invites( $m );
	ogc_log( 'member_remove', (int) $m['year'], 'member:' . $m['id'], array() );
}

/** End someone's unused invite links for a year (removed, or a new address). */
function ogc_member_end_invites( $m ) {
	global $wpdb;
	$t = ogc_table( 'tokens' );
	foreach ( (array) $wpdb->get_results( $wpdb->prepare( "SELECT id, data FROM $t WHERE email = %s AND kind = 'invite' AND used_at IS NULL", $m['email'] ), ARRAY_A ) as $r ) {
		$d = (array) ogc_unjson( $r['data'], array() );
		if ( empty( $d['year'] ) || (int) $d['year'] === (int) $m['year'] ) {
			$wpdb->delete( $t, array( 'id' => (int) $r['id'] ), array( '%d' ) );
		}
	}
}

/** The last COA member of a year can be removed (or made a helper) only by a webmaster. */
function ogc_member_is_last_coa( $m ) {
	if ( 'coa' !== $m['role'] ) {
		return false;
	}
	$n = 0;
	foreach ( ogc_members_list( (int) $m['year'] ) as $x ) {
		if ( 'coa' === $x['role'] && ogc_member_active( $x ) ) {
			$n++;
		}
	}
	return $n <= 1;
}

// A member's sign-in: noted on each of their rows (the list's "Active · Signed in Oct 12"), and the
// first one logged for the year's History.
add_action( 'ogc_signed_in', function ( $user_id, $row ) {
	global $wpdb;
	$email = ogc_user_email( $user_id );
	foreach ( ogc_member_rows_for( $email ) as $m ) {
		if ( ! $m['signed_in_at'] ) {
			ogc_log( 'member_signin', (int) $m['year'], 'member:' . $m['id'], array() );
		}
		$wpdb->update( ogc_table( 'members' ), array( 'signed_in_at' => ogc_now() ), array( 'id' => (int) $m['id'] ) );
		if ( $m['name'] && '' === ogc_person_name( $user_id ) ) {
			ogc_person_set_name( $user_id, $m['name'] );
		}
	}
	ogc_members_cache( true );
}, 10, 2 );

// Older History lines kept the member's name in the log ("who"): taken out once, as the log now keeps
// ids only (DEV.md: detail never holds personal data).
add_action( 'init', function () {
	global $wpdb;
	if ( get_option( 'ogc_log_who_cleared' ) || ! function_exists( 'ogc_table' ) ) {
		return;
	}
	$t = ogc_table( 'log' );
	foreach ( (array) $wpdb->get_results( "SELECT id, detail FROM $t WHERE detail LIKE '%\"who\"%'", ARRAY_A ) as $r ) { // phpcs:ignore -- no input.
		$d = (array) ogc_unjson( $r['detail'], array() );
		unset( $d['who'] );
		$wpdb->update( $t, array( 'detail' => ogc_json( (object) $d ) ), array( 'id' => (int) $r['id'] ) );
	}
	update_option( 'ogc_log_who_cleared', 1, false );
}, 30 );

/* ================================================================== the Members page */

// /annual-conference/members/?year=2027: the year's members on a page of their own, built like the
// year's parts (the year page's side column shows a summary and Manage once the list is long).
add_filter( 'ogc_pages', function ( $p ) {
	$p['members'] = array(
		'path'        => 'members',
		'members'     => true,
		'folder'      => 'signin',
		'shell'       => 'bare',
		'template'    => 'signin-members.php',
		'html_class'  => 'adm-full',
		'title'       => 'Members',
		'noindex'     => true,
		'description' => '',
		'header'      => array(),
		'fonts'       => '',
		'head'        => '',
		'styles'      => array( 'shared/site-shell.css', 'shared/ogc-ui.css', 'schedule-hub/week.css', 'shared/ogc-ws.css' ),
		'scripts'     => array( 'shared/ogc-core.js' ),
	);
	return $p;
}, 15 );

/* ================================================================== REST */

add_action( 'rest_api_init', 'ogc_members_routes' );

function ogc_members_routes() {
	$Y = '(?P<year>\d{4})';
	register_rest_route( OGC_NS, "/years/$Y/members", array(
		array( 'methods' => 'GET', 'callback' => 'ogc_rest_members_get', 'permission_callback' => 'ogc_can_members_read' ),
		array( 'methods' => 'POST', 'callback' => 'ogc_rest_members_post', 'permission_callback' => 'ogc_can_members_invite' ),
	) );
	// Who did what, and the invite as it's sent: for those who invite (the COA, webmasters).
	register_rest_route( OGC_NS, "/years/$Y/members/history", array(
		array( 'methods' => 'GET', 'callback' => 'ogc_rest_members_history', 'permission_callback' => 'ogc_can_members_invite' ),
	) );
	register_rest_route( OGC_NS, "/years/$Y/members/preview", array(
		array( 'methods' => 'GET', 'callback' => 'ogc_rest_members_preview', 'permission_callback' => 'ogc_can_members_invite' ),
	) );
	register_rest_route( OGC_NS, '/members/(?P<id>\d+)', array(
		array( 'methods' => 'PATCH', 'callback' => 'ogc_rest_member_patch', 'permission_callback' => 'ogc_can_member_row' ),
		array( 'methods' => 'DELETE', 'callback' => 'ogc_rest_member_delete', 'permission_callback' => 'ogc_can_member_row' ),
	) );
	register_rest_route( OGC_NS, '/members/(?P<id>\d+)/resend', array(
		array( 'methods' => 'POST', 'callback' => 'ogc_rest_member_resend', 'permission_callback' => 'ogc_can_member_row' ),
	) );
}

function ogc_can_members_read( WP_REST_Request $req ) {
	if ( null === ogc_year_get( (int) $req['year'] ) ) {
		return new WP_Error( 'ogc_not_found', 'Not found.', array( 'status' => 404 ) );
	}
	return ogc_member_can( 'read', (int) $req['year'] ) ? true : ogc_rest_denied();
}

function ogc_can_members_invite( WP_REST_Request $req ) {
	if ( null === ogc_year_get( (int) $req['year'] ) ) {
		return new WP_Error( 'ogc_not_found', 'Not found.', array( 'status' => 404 ) );
	}
	if ( 'GET' !== $req->get_method() && '' !== (string) $req->get_param( 'as' ) ) {
		return new WP_Error( 'ogc_read_only', 'Read only while seeing as', array( 'status' => 403 ) );
	}
	if ( 'GET' === $req->get_method() && '' !== (string) $req->get_param( 'as' ) && function_exists( 'ogc_app_viewer' ) ) {
		// History and the invite's preview, seen as the COA: read only, as the COA would read them.
		return 'coa' === ogc_app_viewer( (int) $req['year'], (string) $req->get_param( 'as' ) )['as'] ? true : ogc_rest_denied();
	}
	return ogc_member_can( 'invite', (int) $req['year'] ) ? true : ogc_rest_denied();
}

/** The row must be in a year the viewer may read; what they may do to it is checked per action. */
function ogc_can_member_row( WP_REST_Request $req ) {
	$m = ogc_member_get( (int) $req['id'] );
	if ( ! $m || ! ogc_member_can( 'read', (int) $m['year'] ) ) {
		return new WP_Error( 'ogc_not_found', 'Not found.', array( 'status' => 404 ) );
	}
	// Every change to a member is refused while seeing as (Round 6b; README 2.6).
	if ( '' !== (string) $req->get_param( 'as' ) ) {
		return new WP_Error( 'ogc_read_only', 'Read only while seeing as', array( 'status' => 403 ) );
	}
	return true;
}

/** A row as the Members card draws it, with what this viewer may do to it. Helpers see who's on the
 * year and their committee; addresses, invite dates and sign-ins are for the COA and webmasters (and
 * each person's own row). */
function ogc_member_out( $m, $full = true ) {
	$me     = ogc_current_email();
	$you    = $me && $m['email'] === $me;
	$expiry = ogc_member_expiry( $m );
	$active = ogc_member_active( $m );
	$ending = $active && $expiry && strtotime( $expiry . ' UTC' ) < time() + 60 * DAY_IN_SECONDS;
	$keys   = ogc_member_committee_keys( $m );
	// One coarse state for every row, the only status a helper sees on others' rows (never a made-up
	// "Not invited"): active (has signed in), invited (not yet), expired.
	$state = $m['removed_at'] ? 'removed' : ( ! $active ? 'expired' : ( $m['signed_in_at'] ? 'active' : 'invited' ) );
	$out   = array(
		'id'         => (int) $m['id'],
		'email'      => $full || $you ? $m['email'] : '',
		'name'       => $m['name'] ? $m['name'] : ( $full || $you ? '' : ogc_mask_email( $m['email'] ) ),
		'role'       => $m['role'],
		'helps'      => $m['helps'],
		'committees' => $keys,
		'committee'  => $keys ? ogc_member_committee_name( $m, $keys[0] ) : '',
		'head'       => (bool) $m['head'],
		'state'      => $state,
		'until'      => ogc_member_until_label( $m ),
		'ending'     => $ending,
		// Ending soon (Round 6b, P9): within 30 days, or ended; one rule (module-people.php).
		'ending_soon' => function_exists( 'ogc_member_ending_soon' ) ? ogc_member_ending_soon( $m ) : $ending,
		'expired'    => ! $active && ! $m['removed_at'],
		'removed'    => (bool) $m['removed_at'],
		'you'        => $you,
	);
	if ( ! $full && ! $you ) {
		$out['can'] = array( 'remove' => false, 'resend' => false, 'renew' => false, 'label' => false, 'name' => false, 'role' => false, 'email' => false );
		return $out;
	}
	$by     = $m['invited_by'] ? ogc_person_name( $m['invited_by'] ) : '';
	$never  = ! $m['signed_in_at'];
	return array_merge( $out, array(
		'invited'   => $m['invited_at'] ? ogc_member_day( $m['invited_at'] ) : '',
		'signed_in' => $m['signed_in_at'] ? ogc_member_day( $m['signed_in_at'] ) : '',
		// An invite's link lasts 7 days: after that, unsigned-in, the row says so (and offers Resend).
		'invite_expired' => $never && $m['invited_at'] && strtotime( $m['invited_at'] . ' UTC' ) < time() - 7 * DAY_IN_SECONDS,
		// An address never signed in that looks mistyped ("gmial.com"): the row asks to check it.
		'suspect'   => $never && $full ? ogc_email_suggest( $m['email'] ) : '',
		'by'        => $by ? ogc_first_l( $by ) : '',
		// Handles money (decision 4): on the row for those who see it whole; changed only by the COA.
		'money'     => ogc_member_handles_money( (int) $m['year'], $m['email'] ),
		// A webmaster on the year too (Privacy lists them; the COA may remove them).
		'webmaster' => ogc_member_is_webmaster_row( $m ),
		'can'       => array(
			// A webmaster may take themselves off a year; anyone else is removed by someone else.
			'remove' => ogc_member_can( 'remove', (int) $m['year'], $m ) && ! ( ogc_member_is_last_coa( $m ) && ! ogc_is_webmaster() ) && ( ! $you || ogc_is_webmaster() ),
			'resend' => ogc_member_can( 'resend', (int) $m['year'], $m ),
			'renew'  => ogc_member_can( 'renew', (int) $m['year'], $m ),
			'label'  => ogc_member_can( 'label', (int) $m['year'], $m ),
			'name'   => ogc_member_can( 'name', (int) $m['year'], $m ),
			'role'   => ogc_member_can( 'role', (int) $m['year'], $m ),
			// The address, only while it has never been used to sign in (then it's proved).
			'email'  => $never && ogc_member_can( 'email', (int) $m['year'], $m ),
			// Never on one's own row (another COA member ticks it), except to untick.
			'money'  => function_exists( 'ogc_access_coa' ) && ogc_access_coa( (int) $m['year'] ) && ogc_member_active( $m ) && ! $m['removed_at'] && ( ! $you || ogc_member_handles_money( (int) $m['year'], $m['email'] ) ),
		),
	) );
}

function ogc_members_payload( $year, $extra = false ) {
	$y      = ogc_year_get( $year );
	$me     = ogc_member_me( $year );
	$full   = ogc_member_can( 'invite', $year );
	$rows   = array();
	$untils = array( 'coa' => array(), 'helper' => array() );
	foreach ( ogc_members_list( $year ) as $m ) {
		$o      = ogc_member_out( $m, $full );
		$rows[] = $o;
		if ( ! $o['expired'] ) {
			$r = 'coa' === $o['role'] ? 'coa' : 'helper';
			$untils[ $r ][ $o['until'] ] = isset( $untils[ $r ][ $o['until'] ] ) ? $untils[ $r ][ $o['until'] ] + 1 : 1;
		}
	}
	// The date most of each group shares: said with the group; a row shows its own only when it differs.
	$common = array();
	foreach ( $untils as $r => $u ) {
		arsort( $u );
		$common[ $r ] = $u ? (string) key( $u ) : '';
	}
	$coms = array();
	foreach ( ogc_members_committee_list( $year ) as $k => $n ) {
		$coms[] = array( 'key' => $k, 'name' => $n );
	}
	return array(
		'year'    => (int) $year,
		'dates'   => ! empty( $y['end'] ),
		'signin'  => preg_replace( '#^https?://#', '', untrailingslashit( ogc_url( 'signin' ) ) ),
		'viewer'  => array(
			'webmaster' => ogc_is_webmaster(),
			'coa'       => $me && 'coa' === $me['role'],
			'invite'    => $full,
			'roles'     => ogc_is_webmaster(),
			// Who ticks Handles money: the year's COA (never a webmaster for being one).
			'money'     => function_exists( 'ogc_access_coa' ) && ogc_access_coa( (int) $year ),
		),
		'until'   => $common,
		'years'   => array( 'coa' => ogc_member_default_years( 'coa' ), 'helper' => ogc_member_default_years( 'helper' ) ),
		// The year's committees (pills in Invite and Edit), and where a helper on each starts.
		'committees' => $coms,
		'landings'   => $full ? ogc_members_landings( $year ) : (object) array(),
		'page'       => wp_make_link_relative( ogc_url( 'members', array( 'year' => (int) $year ) ) ),
		'members'    => $rows,
		// Round 6b: for the COA (and a webmaster seeing as the COA) the people removed this year (Removed:
		// Restore within the hour, then Add again) and the open asks to add someone (Asked, P20).
		'removed_rows' => $extra ? ogc_members_removed_rows( $year ) : array(),
		'asks'         => $extra && function_exists( 'ogc_people_asks_open' ) ? ogc_people_asks_open( $year ) : array(),
	);
}

/** The people removed from a year, newest first, as Members' Removed view draws them. */
function ogc_members_removed_rows( $year ) {
	$out = array();
	foreach ( ogc_members_list( $year, true ) as $m ) {
		if ( ! $m['removed_at'] ) {
			continue;
		}
		$o           = ogc_member_out( $m, true );
		$o['removed_on'] = substr( (string) $m['removed_at'], 0, 10 );
		$o['removed_by'] = $m['removed_by'] ? ogc_app_user_name( (int) $m['removed_by'], (int) $year ) : '';
		// Undo is the hour's (as built); after it, Add again.
		$o['restore']    = strtotime( $m['removed_at'] . ' UTC' ) > time() - HOUR_IN_SECONDS && ogc_member_can( 'remove', (int) $year, $m );
		$out[]           = $o;
	}
	usort( $out, function ( $a, $b ) {
		return strcmp( $b['removed_on'], $a['removed_on'] );
	} );
	return $out;
}

/** committee key → where a helper who helps with it starts ("lodging" → "Lodging"). */
function ogc_members_landings( $year ) {
	$out = array();
	foreach ( ogc_members_committee_list( $year ) as $c ) {
		$l = ogc_member_landing_label( ogc_member_landing_for( $year, 'helper', $c ) );
		if ( '' !== $l ) {
			$out[ ogc_committee_key( $c ) ] = $l;
		}
	}
	foreach ( array( 'lodging', 'preteens', 'communion', 'young folks' ) as $c ) {
		if ( ! isset( $out[ $c ] ) ) {
			$out[ $c ] = ogc_member_landing_label( ogc_member_landing_for( $year, 'helper', $c ) );
		}
	}
	return (object) array_filter( $out, 'strlen' );
}

function ogc_rest_members_get( WP_REST_Request $req ) {
	$y  = (int) $req['year'];
	$as = (string) $req->get_param( 'as' );
	if ( '' !== $as ) {
		// See as (Round 6b; README 2.6): the list as the COA gets it, read only and logged. Only the COA
		// is seen as here: a committee never opens Members.
		$v = function_exists( 'ogc_app_viewer' ) ? ogc_app_viewer( $y, $as ) : array( 'as' => '' );
		if ( 'coa' !== $v['as'] ) {
			return ogc_rest_denied( 'Members · The COA’s' );
		}
		ogc_app_log_see_as( $v );
		$p = ogc_members_payload( $y, true );
		$p['members'] = array_map( function ( $m ) {
			$m['can'] = array_fill_keys( array_keys( (array) $m['can'] ), false );
			return $m;
		}, $p['members'] );
		$p['removed_rows'] = array_map( function ( $m ) {
			$m['restore'] = false;
			return $m;
		}, $p['removed_rows'] );
		$p['viewer'] = array_merge( $p['viewer'], array( 'webmaster' => false, 'coa' => true, 'invite' => false, 'roles' => false, 'money' => false, 'as' => 'coa', 'readonly' => true ) );
		return rest_ensure_response( $p );
	}
	$me = ogc_member_me( $y );
	$p  = ogc_members_payload( $y, $me && 'coa' === $me['role'] );
	if ( ogc_is_webmaster() && function_exists( 'ogc_year_coa_state' ) ) {
		// Access's fact (Round 6b, 8.5): the same words Years and the webmasters' Home say.
		$p['coa_state'] = ogc_year_coa_state( $y );
	}
	return rest_ensure_response( $p );
}

function ogc_rest_members_post( WP_REST_Request $req ) {
	$y    = (int) $req['year'];
	// People are added only to a started year (P17; README 2.4 rule 6): only Years › Start sets one up.
	if ( function_exists( 'ogc_year_started' ) && ! ogc_year_started( $y ) ) {
		return new WP_Error( 'ogc_not_started', 'Start ' . $y . ' first', array( 'status' => 409 ) );
	}
	$role = 'coa' === $req->get_param( 'role' ) ? 'coa' : 'helper';
	if ( 'coa' === $role && ! ogc_member_can( 'invite_coa', $y ) ) {
		return ogc_rest_denied();
	}
	$text = $req->get_param( 'emails' );
	if ( ! is_string( $text ) && ! is_array( $text ) ) {
		return new WP_Error( 'ogc_bad', 'emails is text.', array( 'status' => 400 ) );
	}
	if ( strlen( is_array( $text ) ? implode( "\n", array_map( 'strval', $text ) ) : $text ) > 20000 ) {
		return new WP_Error( 'ogc_too_big', 'Too many.', array( 'status' => 413 ) );
	}
	$until = ogc_throttle( 'inv:' . get_current_user_id(), 60, HOUR_IN_SECONDS, false );
	if ( $until ) {
		return new WP_Error( 'ogc_rate', 'Too many invites · Try in ' . ogc_wait_words( $until ), array( 'status' => 429 ) );
	}
	$parsed = ogc_members_parse( $text );
	if ( count( $parsed['ok'] ) > 40 ) {
		return new WP_Error( 'ogc_too_many', 'Up to 40 at once', array( 'status' => 400 ) );
	}
	// Nobody adds their own address to a year: a webmaster who belongs on it is added by another
	// webmaster (the COA) or by the COA (a committee), and Privacy lists it (critique, Oct 14).
	$me = ogc_current_email();
	if ( '' !== $me && in_array( $me, array_map( function ( $p ) { return strtolower( (string) $p[1] ); }, $parsed['ok'] ), true ) ) {
		return new WP_Error( 'ogc_self', ogc_is_webmaster() ? 'Not your own email · Another webmaster adds you' : 'Not your own email', array( 'status' => 403 ) );
	}
	$typo = ogc_members_typo_check( $parsed, (bool) $req->get_param( 'typos_ok' ) );
	if ( $typo ) {
		return $typo;
	}
	for ( $i = 0; $i < count( $parsed['ok'] ); $i++ ) {
		ogc_throttle( 'inv:' . get_current_user_id(), 60, HOUR_IN_SECONDS );
	}
	// Only webmasters choose how long; the COA's helpers get the helpers' default.
	$r = ogc_members_invite( $y, $text, array(
		'role'          => $role,
		'years'         => ogc_is_webmaster() ? (int) $req->get_param( 'years' ) : 0,
		'helps'         => (string) $req->get_param( 'helps' ),
		'committees'    => (array) $req->get_param( 'committees' ),
		'head'          => (bool) $req->get_param( 'head' ),
		'new_committee' => (string) $req->get_param( 'new_committee' ),
	) );
	// An ask answered by this Add (Members › Asked, P20): its address goes.
	$ask = (string) $req->get_param( 'ask' );
	if ( '' !== $ask && ( $r['added'] || ! empty( $r['merged'] ) ) && function_exists( 'ogc_people_ask_close' ) ) {
		if ( 'h' === $ask[0] ) {
			ogc_people_ask_close( $y, $ask, 'added' );
		}
	}
	$me = ogc_member_me( $y );
	return rest_ensure_response( array(
		'added'   => array_map( function ( $m ) { return (int) $m['id']; }, $r['added'] ),
		'already' => array_map( function ( $m ) { return (int) $m['id']; }, $r['already'] ),
		// Round 6b (P3): someone already on the year, given the ticked committees too.
		'merged'  => array_map( function ( $m ) { return (int) $m['id']; }, isset( $r['merged'] ) ? $r['merged'] : array() ),
		'bad'     => array_values( $r['bad'] ),
		'list'    => ogc_members_payload( $y, $me && 'coa' === $me['role'] ),
	) );
}

function ogc_rest_member_patch( WP_REST_Request $req ) {
	global $wpdb;
	$m   = ogc_member_get( (int) $req['id'] );
	$y   = (int) $m['year'];
	$set = array();
	$did = array();
	if ( $req->get_param( 'restore' ) ) {
		// Undo a removal, within the hour it was made.
		if ( ! $m['removed_at'] || ! ogc_member_can( 'remove', $y, $m ) || strtotime( $m['removed_at'] . ' UTC' ) < time() - HOUR_IN_SECONDS ) {
			return ogc_rest_denied();
		}
		$set['removed_at'] = null;
		$set['removed_by'] = 0;
		$did[]             = 'member_restore';
	} elseif ( $m['removed_at'] ) {
		return new WP_Error( 'ogc_not_found', 'Not found.', array( 'status' => 404 ) );
	}
	if ( null !== $req->get_param( 'name' ) ) {
		if ( ! ogc_member_can( 'name', $y, $m ) ) {
			return ogc_rest_denied();
		}
		$set['name'] = ogc_mail_safe_name( (string) $req->get_param( 'name' ) );
		$did[]       = 'member_name';
	}
	if ( null !== $req->get_param( 'helps' ) ) {
		if ( ! ogc_member_can( 'label', $y, $m ) ) {
			return ogc_rest_denied();
		}
		$set['helps'] = ogc_member_helps_clean( $req->get_param( 'helps' ) );
		$did[]        = 'member_label';
	}
	if ( null !== $req->get_param( 'committees' ) || null !== $req->get_param( 'new_committee' ) || null !== $req->get_param( 'head' ) ) {
		if ( ! ogc_member_can( 'label', $y, $m ) ) {
			return ogc_rest_denied();
		}
		$keys = null !== $req->get_param( 'committees' ) || null !== $req->get_param( 'new_committee' ) ? ogc_members_committees_in( $y, (array) $req->get_param( 'committees' ), (string) $req->get_param( 'new_committee' ) ) : ogc_member_committee_keys( $m );
		$set['committees'] = implode( ',', $keys );
		$set['head']       = $keys && $req->get_param( 'head' ) ? 1 : ( null === $req->get_param( 'head' ) && $keys ? (int) $m['head'] : 0 );
		if ( null === $req->get_param( 'helps' ) ) {
			// The label follows the committees unless the COA wrote its own words.
			$list         = ogc_members_committee_list( $y );
			$set['helps'] = ogc_member_helps_clean( implode( ', ', array_map( function ( $k ) use ( $list ) {
				return isset( $list[ $k ] ) ? $list[ $k ] : $k;
			}, $keys ) ) );
		}
		$did[] = 'member_label';
	}
	$new_email = '';
	if ( null !== $req->get_param( 'email' ) && ogc_clean_email( $req->get_param( 'email' ) ) !== $m['email'] ) {
		// A mistyped address, fixed before anyone has signed in with it: the old invite ends, the row
		// takes the new address, and the new address gets its own invite.
		if ( $m['signed_in_at'] || ! ogc_member_can( 'email', $y, $m ) ) {
			return ogc_rest_denied();
		}
		$new_email = ogc_clean_email( $req->get_param( 'email' ) );
		if ( ! is_email( $new_email ) ) {
			return new WP_Error( 'ogc_bad_email', 'Not an email', array( 'status' => 400 ) );
		}
		if ( ogc_member_find( $y, $new_email, true ) ) {
			return new WP_Error( 'ogc_exists', 'Already a member', array( 'status' => 409 ) );
		}
		$typo = ogc_members_typo_check( array( 'ok' => array( array( '', $new_email ) ) ), (bool) $req->get_param( 'typos_ok' ) );
		if ( $typo ) {
			return $typo;
		}
		$set['email'] = $new_email;
		$did[]        = 'member_email';
	}
	if ( null !== $req->get_param( 'role' ) ) {
		$role = 'coa' === $req->get_param( 'role' ) ? 'coa' : 'helper';
		if ( ! ogc_member_can( 'role', $y, $m ) ) {
			return ogc_rest_denied();
		}
		if ( 'helper' === $role && ogc_member_is_last_coa( $m ) ) {
			return new WP_Error( 'ogc_last_coa', 'The year needs one COA member', array( 'status' => 400 ) );
		}
		$set['role'] = $role;
		$did[]       = 'member_role';
	}
	if ( $req->get_param( 'renew' ) ) {
		if ( ! ogc_member_can( 'renew', $y, $m ) ) {
			return ogc_rest_denied();
		}
		$x                  = ogc_member_expiry( $m );
		$from               = $x && strtotime( $x . ' UTC' ) > time() ? strtotime( $x . ' UTC' ) : time();
		$yrs                = ogc_is_webmaster() && (int) $req->get_param( 'years' ) ? min( 3, max( 1, (int) $req->get_param( 'years' ) ) ) : 1;
		$set['expires_at']  = gmdate( 'Y-m-d H:i:s', strtotime( '+' . $yrs . ' year', $from ) );
		$set['ending_sent'] = null;
		$did[]              = 'member_renew';
	}
	// Handles money (decision 4): the year's COA ticks it, never a webmaster for being one. The first
	// tick asks whether only this person reads the address (docs/scope/06: a shared family address would
	// show every payment to whoever else reads it); the answer is logged with who gave it.
	$money = $req->get_param( 'money' );
	if ( null !== $money ) {
		if ( ! function_exists( 'ogc_access_coa' ) || ! ogc_access_coa( $y ) || ! ogc_member_active( $m ) ) {
			return ogc_rest_denied( 'The COA chooses' );
		}
		$on = in_array( $money, array( true, 1, '1', 'true', 'yes' ), true );
		// Never ticked on one's own row: another COA member does it (unticking oneself is fine).
		if ( $on && strtolower( (string) $m['email'] ) === ogc_current_email() && ! ogc_member_handles_money( $y, $m['email'] ) ) {
			return ogc_rest_denied( 'Another COA member ticks it' );
		}
		if ( $on && ! ogc_member_handles_money( $y, $m['email'] ) && ! $req->get_param( 'own_email' ) ) {
			return new WP_Error( 'ogc_own_email', 'Only this person reads this email?', array( 'status' => 409 ) );
		}
		if ( $on !== ogc_member_handles_money( $y, $m['email'] ) ) {
			ogc_member_set_money( $y, $m['email'], $on );
			ogc_log( $on ? 'member_money_on' : 'member_money_off', $y, 'member:' . $m['id'], $on ? array( 'own_email' => 1 ) : array() );
		}
		if ( ! $set ) {
			return rest_ensure_response( array( 'member' => ogc_member_out( ogc_member_get( (int) $m['id'] ) ), 'list' => ogc_members_payload( $y ) ) );
		}
	}
	if ( ! $set ) {
		return new WP_Error( 'ogc_bad', 'Nothing to change.', array( 'status' => 400 ) );
	}
	if ( $new_email ) {
		global $wpdb;
		$wpdb->query( $wpdb->prepare( 'DELETE FROM ' . ogc_table( 'tokens' ) . " WHERE email = %s AND kind = 'invite' AND used_at IS NULL", $m['email'] ) );
	}
	$wpdb->update( ogc_table( 'members' ), $set, array( 'id' => (int) $m['id'] ) );
	ogc_members_cache( true );
	foreach ( $did as $a ) {
		$detail = array();
		if ( isset( $set['role'] ) && 'member_role' === $a ) {
			$detail['role'] = $set['role'];
		}
		ogc_log( $a, $y, 'member:' . $m['id'], $detail );
	}
	if ( $new_email ) {
		ogc_member_send_invite( ogc_member_get( (int) $m['id'] ), get_current_user_id() );
	}
	$name = $req->get_param( 'name' );
	if ( null !== $name && '' !== $set['name'] ) {
		$u = ogc_person_for_email( $m['email'] );
		if ( $u && ( (int) $u->ID === get_current_user_id() || '' === ogc_person_name( $u->ID ) ) ) {
			ogc_person_set_name( $u->ID, $set['name'] );
		}
	}
	return rest_ensure_response( array( 'member' => ogc_member_out( ogc_member_get( (int) $m['id'] ) ), 'list' => ogc_members_payload( $y ) ) );
}

function ogc_rest_member_delete( WP_REST_Request $req ) {
	$m = ogc_member_get( (int) $req['id'] );
	if ( $m['removed_at'] ) {
		return rest_ensure_response( array( 'removed' => true ) );
	}
	if ( ! ogc_member_can( 'remove', (int) $m['year'], $m ) || ( $m['email'] === ogc_current_email() && ! ogc_is_webmaster() ) ) {
		return ogc_rest_denied();
	}
	if ( ogc_member_is_last_coa( $m ) && ! ogc_is_webmaster() ) {
		return new WP_Error( 'ogc_last_coa', 'The year needs one COA member', array( 'status' => 400 ) );
	}
	ogc_member_remove( $m );
	return rest_ensure_response( array( 'removed' => true, 'id' => (int) $m['id'], 'list' => ogc_members_payload( (int) $m['year'] ) ) );
}

function ogc_rest_member_resend( WP_REST_Request $req ) {
	$m = ogc_member_get( (int) $req['id'] );
	if ( $m['removed_at'] || ! ogc_member_can( 'resend', (int) $m['year'], $m ) ) {
		return ogc_rest_denied();
	}
	$until = ogc_throttle( 'resend:' . $m['id'], 1, MINUTE_IN_SECONDS );
	if ( $until ) {
		return new WP_Error( 'ogc_rate', 'Sent · Just now', array( 'status' => 429 ) );
	}
	ogc_member_send_invite( $m, get_current_user_id() );
	ogc_log( 'member_resend', (int) $m['year'], 'member:' . $m['id'], array() );
	return rest_ensure_response( array( 'member' => ogc_member_out( ogc_member_get( (int) $m['id'] ) ) ) );
}

/** The year's members' history, in words ("Nathan K. invited Joel M. · Oct 12", "· 3:40 PM" today).
 * The log keeps only who by id (DEV.md: detail never holds personal data); each line names the member
 * as they are when it's read, so a name cleared after Conference is gone from History too. The same
 * line again on the same day is one line with "× 3". */
function ogc_rest_members_history( WP_REST_Request $req ) {
	global $wpdb;
	$y    = (int) $req['year'];
	$one  = (int) $req->get_param( 'id' );
	$rows = $one
		? $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . ogc_table( 'log' ) . " WHERE year = %d AND target = %s AND action LIKE 'member%%' ORDER BY id DESC LIMIT 300", $y, 'member:' . $one ), ARRAY_A )
		: $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . ogc_table( 'log' ) . " WHERE year = %d AND action LIKE 'member%%' ORDER BY id DESC LIMIT 300", $y ), ARRAY_A );
	$who  = function ( $uid ) use ( $y ) {
		if ( ! $uid ) {
			return 'Someone';
		}
		$n = ogc_person_name( $uid );
		if ( $n ) {
			return ogc_first_l( $n );
		}
		$m = ogc_member_find( $y, ogc_user_email( $uid ), true );
		return $m ? ogc_member_short( $m ) : ( ogc_is_webmaster( $uid ) ? 'A webmaster' : 'Someone' );
	};
	$out   = array();
	$today = wp_date( 'Y-m-d' );
	foreach ( (array) $rows as $r ) {
		$d = (array) ogc_unjson( $r['detail'], array() );
		$m = preg_match( '/^member:(\d+)$/', $r['target'], $x ) ? ogc_member_get( (int) $x[1] ) : null;
		$t = $m ? ogc_member_short( $m ) : ( preg_match( '/^user:(\d+)$/', $r['target'], $x ) ? $who( (int) $x[1] ) : 'a member' );
		$b = $who( (int) $r['user'] );
		$w = array(
			'member_invite'  => $b . ' invited ' . $t,
			'member_resend'  => $b . ' sent ' . $t . ' a new link',
			'member_remove'  => $b . ' removed ' . $t,
			'member_restore' => $b . ' restored ' . $t,
			'member_signin'  => $t . ' signed in',
			'member_role'    => $b . ' made ' . $t . ' ' . ( isset( $d['role'] ) && 'coa' === $d['role'] ? 'COA' : 'a helper' ),
			'member_label'   => $b . ' changed ' . $t . '’s committee',
			'member_name'    => $b . ' changed ' . $t . '’s name',
			'member_email'   => $b . ' changed ' . $t . '’s address',
			'member_renew'   => $b . ' renewed ' . $t,
			'member_ending'  => $t . ' was told access ends soon',
			'member_ask'     => $t . ' asked for access',
			'member_money_on'  => $b . ' ticked Handles money for ' . $t,
			'member_money_off' => $b . ' took Handles money off ' . $t,
		);
		if ( ! isset( $w[ $r['action'] ] ) ) {
			continue;
		}
		$t0  = strtotime( $r['at'] . ' UTC' );
		$day = wp_date( 'Y-m-d', $t0 );
		$at  = $day === $today ? wp_date( 'g:i A', $t0 ) : ogc_member_date( $r['at'] );
		$last = $out ? count( $out ) - 1 : -1;
		if ( $last >= 0 && $out[ $last ]['words'] === $w[ $r['action'] ] && $out[ $last ]['day'] === $day ) {
			$out[ $last ]['n']++;
			continue;
		}
		$out[] = array( 'at' => $at, 'day' => $day, 'words' => $w[ $r['action'] ], 'n' => 1, 'id' => $m ? (int) $m['id'] : 0 );
	}
	return rest_ensure_response( array_map( function ( $o ) {
		return array( 'at' => $o['at'], 'words' => $o['words'], 'n' => $o['n'], 'id' => $o['id'] );
	}, $out ) );
}

/** The invite email exactly as it's sent (the same renderer as the Mail log). */
function ogc_rest_members_preview( WP_REST_Request $req ) {
	$y   = (int) $req['year'];
	$me  = get_current_user_id();
	$role = 'coa' === $req->get_param( 'role' ) ? 'coa' : 'helper';
	// The same rule as the invite itself: a webmaster's chosen years, else the role's default.
	$yrs  = ogc_is_webmaster() && (int) $req->get_param( 'years' ) ? min( 3, max( 1, (int) $req->get_param( 'years' ) ) ) : ogc_member_default_years( $role );
	$m    = array( 'year' => $y, 'role' => $role, 'access_years' => $yrs, 'expires_at' => null );
	$keys = array();
	$list = ogc_members_committee_list( $y );
	foreach ( (array) $req->get_param( 'committees' ) as $k ) {
		$k = ogc_committee_key( sanitize_text_field( (string) $k ) );
		if ( isset( $list[ $k ] ) ) {
			$keys[] = $k;
		}
	}
	$new = trim( sanitize_text_field( (string) $req->get_param( 'new_committee' ) ) );
	$fake = array( 'role' => $role, 'helps' => implode( ', ', array_merge( array_map( function ( $k ) use ( $list ) {
		return $list[ $k ];
	}, $keys ), $new ? array( $new ) : array() ) ), 'committees' => implode( ',', array_merge( $keys, $new ? array( ogc_committee_key( $new ) ) : array() ) ), 'head' => (int) (bool) $req->get_param( 'head' ) );
	$land = ogc_member_landing_for( $y, $role, ogc_member_landing_words( $fake ) );
	$byr  = ogc_member_find( $y, ogc_current_email(), true );
	$t    = ogc_mail_template( 'invite', array(
		'year'            => $y,
		'to'              => 'their address',
		'by_name'         => ogc_person_name( $me ),
		'by_webmaster'    => ogc_is_webmaster() && ! $byr,
		'by_role'         => $byr ? ( 'coa' === $byr['role'] ? 'COA' : ogc_member_committee_words( $byr ) ) : '',
		'first'           => (string) apply_filters( 'ogc_member_first', '', array_merge( $fake, array( 'year' => $y, 'email' => '' ) ) ),
		'role'            => $role,
		'committee_words' => ogc_member_committee_words( $fake ),
		'access'          => (string) apply_filters( 'ogc_member_access', '', array_merge( $fake, array( 'year' => $y, 'email' => '' ) ) ),
		'open_label'      => ogc_member_open_label( array_merge( $fake, array( 'year' => $y, 'email' => '' ) ), $land ),
		'reply_by'        => true,
		'landing_url'     => home_url( $land ),
		'until'           => ogc_member_until_label( $m ),
		'url'             => ogc_url( 'signin', array( 't' => 'their-own-link' ) ),
	) );
	$f = ogc_mail_from();
	return rest_ensure_response( array( 'from' => $f['name'] . ' <' . $f['email'] . '>', 'subject' => $t['subject'], 'html' => $t['html'], 'text' => $t['text'] ) );
}

/* ================================================================== access ending */

// Fourteen days before a member's access ends, they're told (once): the COA (who hand over to the next
// COA), and helpers who have used it in the last 90 days. Most helpers don't need it renewed, so they
// aren't invited to ask.
add_action( 'ogc_daily', function () {
	global $wpdb;
	$rows = $wpdb->get_results( 'SELECT * FROM ' . ogc_table( 'members' ) . ' WHERE removed_at IS NULL AND ending_sent IS NULL', ARRAY_A ); // phpcs:ignore -- no input.
	foreach ( array_map( 'ogc_member_row', (array) $rows ) as $m ) {
		$x = ogc_member_expiry( $m );
		if ( ! $x ) {
			continue;
		}
		$t = strtotime( $x . ' UTC' );
		if ( 'coa' !== $m['role'] && ( ! $m['signed_in_at'] || strtotime( $m['signed_in_at'] . ' UTC' ) < time() - 90 * DAY_IN_SECONDS ) ) {
			continue;
		}
		if ( $t > time() && $t < time() + 14 * DAY_IN_SECONDS ) {
			$land = ogc_member_landing( (int) $m['year'], $m['email'] );
			ogc_mail_send_kind( 'access_ending', $m['email'], array( 'year' => (int) $m['year'], 'until' => ogc_member_date( $x, true ), 'role' => $m['role'], 'committee_words' => ogc_member_committee_words( $m ), 'open_label' => ogc_member_open_label( $m, $land ), 'url' => home_url( $land ) ), array( 'to_member' => true ) );
			$wpdb->update( ogc_table( 'members' ), array( 'ending_sent' => ogc_now() ), array( 'id' => (int) $m['id'] ) );
			ogc_log( 'member_ending', (int) $m['year'], 'member:' . $m['id'], array() );
		}
	}
} );

/* ================================================================== asking for access */

/**
 * "Ask for access" on No access: the year's COA members are told who asked (each their own email),
 * or the webmasters when the year has no COA. Once a day per person and year; logged.
 */
function ogc_member_ask_access( $year ) {
	$uid   = get_current_user_id();
	$email = ogc_current_email();
	if ( ! $uid || ! $email || ! ogc_valid_year( $year ) || ogc_is_member( $year ) ) {
		return false;
	}
	if ( ogc_throttle( 'ask:' . $uid . ':' . $year, 1, DAY_IN_SECONDS ) ) {
		return false;
	}
	$m    = ogc_member_find( $year, $email, true );
	$was  = '';
	if ( $m && $m['removed_at'] ) {
		$was = 'Removed ' . ogc_member_date( $m['removed_at'] );
	} elseif ( $m ) {
		$x   = ogc_member_expiry( $m );
		$was = $x ? 'Access ended ' . ogc_member_date( $x ) : '';
	}
	$name = ogc_person_name( $uid );
	$to   = array();
	foreach ( ogc_members_list( $year ) as $c ) {
		if ( 'coa' === $c['role'] && ogc_member_active( $c ) ) {
			$to[] = $c['email'];
		}
	}
	if ( ! $to ) {
		foreach ( ogc_webmasters() as $w ) {
			$to[] = strtolower( $w['user']->user_email );
		}
	}
	foreach ( array_unique( $to ) as $t ) {
		ogc_mail_send_kind( 'access_asked', $t, array(
			'year'  => (int) $year,
			'name'  => $name,
			'email' => $email,
			'was'   => $was,
			// The Members page with their row open (the year page shows only a summary once the list is long).
			'url'   => ogc_url( 'members', array_filter( array( 'year' => (int) $year, 'open' => $m ? (int) $m['id'] : null ) ) ),
		) );
	}
	update_user_meta( $uid, 'ogc_asked_' . (int) $year, time() );
	ogc_log( 'member_ask', (int) $year, $m ? 'member:' . $m['id'] : 'user:' . $uid, array( 'told' => count( $to ) ) );
	return true;
}

/* ================================================================== webmasters */

// One name for the webmasters' capability (it was ogc_webmaster): anyone who had the old one gets the
// new one, once. Found by the capability itself, never "the first 500 users" (every household that
// signs in is a WordPress user).
add_action( 'init', function () {
	global $wpdb;
	if ( get_option( 'ogc_cap_migrated' ) ) {
		return;
	}
	foreach ( get_users( array( 'meta_key' => $wpdb->get_blog_prefix() . 'capabilities', 'meta_value' => '"ogc_webmaster"', 'meta_compare' => 'LIKE', 'fields' => 'all' ) ) as $u ) {
		if ( ! empty( $u->caps['ogc_webmaster'] ) ) {
			$u->add_cap( OGC_CAP_WEBMASTER );
			$u->remove_cap( 'ogc_webmaster' );
		}
	}
	update_option( 'ogc_cap_migrated', 1, true );
}, 6 );

/** The Conference webmasters: site admins (manage_options; fixed here) and those given the capability,
 * read by capability. */
function ogc_webmasters() {
	$out = array();
	foreach ( get_users( array( 'capability__in' => array( 'manage_options', OGC_CAP_WEBMASTER ), 'fields' => 'all', 'number' => 200, 'orderby' => 'ID' ) ) as $u ) {
		$out[] = array( 'user' => $u, 'kind' => user_can( $u, 'manage_options' ) ? 'admin' : 'added' );
	}
	return $out;
}

/** When a person last signed in: one source for every list (ogc_last_signin, which every sign-in sets,
 * the dev sign-in too), else their newest session. 'Y-m-d H:i:s' UTC or ''. */
function ogc_last_signin( $user_id ) {
	$t = get_user_meta( (int) $user_id, 'ogc_last_signin', true );
	if ( $t ) {
		return is_numeric( $t ) ? gmdate( 'Y-m-d H:i:s', (int) $t ) : (string) $t;
	}
	$best = 0;
	foreach ( WP_Session_Tokens::get_instance( (int) $user_id )->get_all() as $x ) {
		$best = max( $best, isset( $x['login'] ) ? (int) $x['login'] : 0 );
	}
	return $best ? gmdate( 'Y-m-d H:i:s', $best ) : '';
}

/**
 * The one rule for adding or removing a webmaster, wherever it's asked (the webmasters' page or
 * Settings › Conference webmasters): one webmaster asks, a second confirms, so no one person can hand
 * out every year's access. While there's only one webmaster, their ask goes ahead (someone has to be
 * first). Site admins are webmasters and can't be removed here.
 */
function ogc_webmaster_ask( $email, $act, $name = '' ) {
	$email = ogc_clean_email( $email );
	$act   = 'remove' === $act ? 'remove' : 'add';
	if ( ! is_email( $email ) ) {
		return new WP_Error( 'ogc_bad_email', 'Not an email', array( 'status' => 400 ) );
	}
	$u   = get_user_by( 'email', $email );
	$now = $u && ogc_is_webmaster( $u->ID );
	if ( 'add' === $act && $now ) {
		return new WP_Error( 'ogc_exists', 'Already a webmaster', array( 'status' => 409 ) );
	}
	if ( 'remove' === $act && ( ! $now || user_can( $u, 'manage_options' ) || (int) $u->ID === get_current_user_id() ) ) {
		return new WP_Error( 'ogc_denied', 'Not allowed', array( 'status' => 403 ) );
	}
	$asks = array_values( array_filter( (array) get_option( 'ogc_webmaster_asks', array() ), function ( $a ) use ( $email ) {
		return $a['email'] !== $email;
	} ) );
	if ( count( ogc_webmasters() ) < 2 ) {
		update_option( 'ogc_webmaster_asks', $asks, false );
		return ogc_webmaster_apply( array( 'email' => $email, 'act' => $act, 'by' => get_current_user_id(), 'name' => ogc_mail_safe_name( $name ) ) );
	}
	$asks[] = array( 'email' => $email, 'act' => $act, 'by' => get_current_user_id(), 'at' => ogc_now(), 'name' => ogc_mail_safe_name( $name ) );
	update_option( 'ogc_webmaster_asks', $asks, false );
	ogc_log( 'webmaster_ask', 0, $act, array() );
	return true;
}

function ogc_webmaster_cancel( $email ) {
	$email = ogc_clean_email( $email );
	update_option( 'ogc_webmaster_asks', array_values( array_filter( (array) get_option( 'ogc_webmaster_asks', array() ), function ( $a ) use ( $email ) {
		return ! ( $a['email'] === $email && ( (int) $a['by'] === get_current_user_id() || current_user_can( 'manage_options' ) ) );
	} ) ), false );
	return true;
}

/** A second webmaster confirms someone else's ask. */
function ogc_webmaster_confirm( $email ) {
	$email = ogc_clean_email( $email );
	$asks  = (array) get_option( 'ogc_webmaster_asks', array() );
	$hit   = null;
	foreach ( $asks as $i => $a ) {
		if ( $a['email'] === $email ) {
			$hit = $a;
			unset( $asks[ $i ] );
		}
	}
	if ( ! $hit ) {
		return new WP_Error( 'ogc_not_found', 'Not found', array( 'status' => 404 ) );
	}
	if ( (int) $hit['by'] === get_current_user_id() ) {
		return new WP_Error( 'ogc_second', 'Needs a second webmaster', array( 'status' => 403 ) );
	}
	update_option( 'ogc_webmaster_asks', array_values( $asks ), false );
	return ogc_webmaster_apply( $hit );
}

/** Carry out an ask: add (the plugin's own role, the capability, and an email from the one who asked,
 * replies to them) or remove (the capability, and every session). */
function ogc_webmaster_apply( $a ) {
	$u = get_user_by( 'email', $a['email'] );
	if ( 'add' === $a['act'] ) {
		$u = $u ? $u : ogc_person_for_email( $a['email'], true );
		if ( ! $u ) {
			return new WP_Error( 'ogc_bad_email', 'Not an email', array( 'status' => 400 ) );
		}
		if ( ! empty( $a['name'] ) && '' === ogc_person_name( $u->ID ) ) {
			ogc_person_set_name( $u->ID, $a['name'] );
		}
		$u->add_cap( OGC_CAP_WEBMASTER );
		$by   = (int) $a['by'];
		$from = $by ? get_userdata( $by ) : null;
		$url  = ogc_signin_link_for( $a['email'], wp_make_link_relative( ogc_url( 'admin', array( 'role' => 'web' ) ) ), 'webmaster', array( 'by' => $by ) );
		ogc_mail_send_kind( 'webmaster', $a['email'], array( 'by_name' => $by ? ogc_person_name( $by ) : '', 'url' => $url, 'reply_by' => (bool) $from ), array( 'reply_to' => $from ? strtolower( $from->user_email ) : '' ) );
		ogc_log( 'webmaster_add', 0, 'user:' . $u->ID );
	} elseif ( $u && ! user_can( $u, 'manage_options' ) ) {
		$u->remove_cap( OGC_CAP_WEBMASTER );
		WP_Session_Tokens::get_instance( $u->ID )->destroy_all();
		ogc_log( 'webmaster_remove', 0, 'user:' . $u->ID );
	}
	return true;
}

/** The webmasters as both screens draw them: names as "First L." (never a login), the one last sign-in,
 * and what's waiting for a second webmaster. */
function ogc_webmasters_payload() {
	$out = array( 'list' => array(), 'asks' => array(), 'alone' => false );
	foreach ( ogc_webmasters() as $w ) {
		$u             = $w['user'];
		$n             = ogc_person_name( $u->ID );
		$out['list'][] = array( 'email' => strtolower( $u->user_email ), 'name' => $n ? ogc_first_l( $n ) : '', 'last' => ogc_last_signin( $u->ID ), 'me' => (int) $u->ID === get_current_user_id(), 'admin' => 'admin' === $w['kind'] );
	}
	$out['alone'] = count( $out['list'] ) < 2;
	foreach ( (array) get_option( 'ogc_webmaster_asks', array() ) as $a ) {
		$n             = ogc_person_name( (int) $a['by'] );
		$out['asks'][] = array( 'email' => $a['email'], 'act' => $a['act'], 'by' => $n ? ogc_first_l( $n ) : 'A webmaster', 'mine' => (int) $a['by'] === get_current_user_id(), 'at' => $a['at'] );
	}
	return $out;
}

add_action( 'admin_menu', function () {
	add_options_page( 'Conference webmasters', 'Conference webmasters', 'manage_options', 'ogc-webmasters', 'ogc_webmasters_screen' );
} );

add_action( 'admin_post_ogc_webmasters', function () {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( 'Not allowed.', '', array( 'response' => 403 ) );
	}
	check_admin_referer( 'ogc_webmasters' );
	$do    = isset( $_POST['do'] ) ? sanitize_key( wp_unslash( $_POST['do'] ) ) : '';
	$back  = admin_url( 'options-general.php?page=ogc-webmasters' );
	$email = isset( $_POST['email'] ) ? ogc_clean_email( wp_unslash( $_POST['email'] ) ) : '';
	$said  = 'saved';
	if ( 'add' === $do || 'remove' === $do ) {
		$r = ogc_webmaster_ask( $email, $do, isset( $_POST['name'] ) ? wp_unslash( $_POST['name'] ) : '' );
		// Waiting for a second webmaster, or (the only one) done at once.
		$said = is_wp_error( $r ) ? 'bad' : ( in_array( $email, wp_list_pluck( (array) get_option( 'ogc_webmaster_asks', array() ), 'email' ), true ) ? 'asked' : 'done' );
	} elseif ( 'confirm' === $do ) {
		$said = is_wp_error( ogc_webmaster_confirm( $email ) ) ? 'bad' : 'done';
	} elseif ( 'cancel' === $do ) {
		ogc_webmaster_cancel( $email );
		$said = 'cancelled';
	} elseif ( 'reply' === $do ) {
		$r = isset( $_POST['reply_to'] ) ? ogc_clean_email( wp_unslash( $_POST['reply_to'] ) ) : '';
		update_option( 'ogc_mail_reply_to', is_email( $r ) ? $r : '', false );
	}
	wp_safe_redirect( add_query_arg( 'ogc', $said, $back ) );
	exit;
} );

/** Settings › Conference webmasters: the same list and the same rule as the webmasters' page
 * (ogc_webmaster_ask: a second webmaster confirms), in WordPress's own table styles. */
function ogc_webmasters_screen() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$w = ogc_webmasters_payload();
	// phpcs:ignore WordPress.Security.NonceVerification -- a status word after a redirect.
	$said = isset( $_GET['ogc'] ) ? sanitize_key( $_GET['ogc'] ) : '';
	$msg  = array( 'asked' => 'Requested · A second webmaster confirms', 'done' => 'Done', 'bad' => 'Check the email', 'saved' => 'Saved', 'cancelled' => 'Cancelled' );
	$form = function ( $do, $email, $label, $class = 'button-link' ) {
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="display:inline">';
		wp_nonce_field( 'ogc_webmasters' );
		echo '<input type="hidden" name="action" value="ogc_webmasters"><input type="hidden" name="do" value="' . esc_attr( $do ) . '"><input type="hidden" name="email" value="' . esc_attr( $email ) . '">';
		echo '<button type="submit" class="' . esc_attr( $class ) . '">' . esc_html( $label ) . '</button></form>';
	};
	echo '<div class="wrap"><h1>Conference webmasters</h1>';
	echo '<p class="description">Every year’s Conference: its members, its pages and its sign-ups · Adding or removing one needs a second webmaster, here or on the <a href="' . esc_url( ogc_url( 'admin', array( 'role' => 'web' ) ) ) . '">webmasters’ page</a></p>';
	if ( isset( $msg[ $said ] ) ) {
		echo '<div class="notice ' . ( 'bad' === $said ? 'notice-error' : 'notice-success' ) . ' is-dismissible"><p>' . esc_html( $msg[ $said ] ) . '</p></div>';
	}
	$added = count( array_filter( $w['list'], function ( $x ) {
		return ! $x['admin'];
	} ) );
	if ( $added < 2 ) {
		echo '<div class="notice notice-warning"><p>' . esc_html( $added ? 'One webmaster besides site admins · Add another, so no one person holds the only access' : 'No webmasters besides site admins' ) . '</p></div>';
	}
	echo '<table class="widefat striped" style="max-width:860px;margin-top:12px"><thead><tr><th>Name</th><th>Email</th><th>Last signed in</th><th></th><th></th></tr></thead><tbody>';
	foreach ( $w['list'] as $x ) {
		echo '<tr><td>' . esc_html( $x['name'] ? $x['name'] : '—' ) . ( $x['me'] ? ' <span class="description">(you)</span>' : '' ) . '</td><td>' . esc_html( $x['email'] ) . '</td><td>' . esc_html( $x['last'] ? ogc_member_date( $x['last'], true ) : '—' ) . '</td>';
		echo '<td>' . esc_html( $x['admin'] ? 'Site admin' : 'Added' ) . '</td><td>';
		if ( ! $x['admin'] && ! $x['me'] ) {
			$form( 'remove', $x['email'], 'Remove', 'button-link button-link-delete' );
		}
		echo '</td></tr>';
	}
	echo '</tbody></table>';
	if ( $w['asks'] ) {
		echo '<h2 style="margin-top:24px">Waiting</h2><table class="widefat striped" style="max-width:860px"><tbody>';
		foreach ( $w['asks'] as $a ) {
			echo '<tr><td>' . esc_html( ( 'add' === $a['act'] ? 'Add ' : 'Remove ' ) . $a['email'] ) . '</td><td>' . esc_html( 'Requested by ' . $a['by'] ) . '</td><td>';
			if ( $a['mine'] ) {
				echo '<span class="description">Waiting for a second webmaster</span> ';
				$form( 'cancel', $a['email'], 'Cancel' );
			} else {
				$form( 'confirm', $a['email'], 'Confirm', 'button button-primary' );
			}
			echo '</td></tr>';
		}
		echo '</tbody></table>';
	}
	echo '<h2 style="margin-top:28px">Add</h2><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
	wp_nonce_field( 'ogc_webmasters' );
	echo '<input type="hidden" name="action" value="ogc_webmasters"><input type="hidden" name="do" value="add">';
	echo '<table class="form-table" role="presentation"><tr><th scope="row"><label for="ogc-wm-email">Email</label></th><td><input id="ogc-wm-email" name="email" type="email" class="regular-text" autocomplete="off" required></td></tr>';
	echo '<tr><th scope="row"><label for="ogc-wm-name">Name</label></th><td><input id="ogc-wm-name" name="name" type="text" class="regular-text" autocomplete="off" required><p class="description">Shown to members as “First L.”, and named in the email they get</p></td></tr></table>';
	submit_button( $w['alone'] ? 'Add' : 'Request', 'primary', 'submit', false );
	echo '<p class="description" style="margin-top:8px">' . esc_html( $w['alone'] ? 'They get an email with a link that works for 7 days' : 'A second webmaster confirms · Then they get an email with a link that works for 7 days' ) . '</p></form>';
	echo '<h2 style="margin-top:28px">Email</h2><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
	wp_nonce_field( 'ogc_webmasters' );
	$from = ogc_mail_from();
	echo '<input type="hidden" name="action" value="ogc_webmasters"><input type="hidden" name="do" value="reply">';
	echo '<table class="form-table" role="presentation"><tr><th scope="row">From</th><td>' . esc_html( $from['name'] . ' <' . $from['email'] . '>' ) . '</td></tr>';
	echo '<tr><th scope="row"><label for="ogc-wm-reply">Replies to</label></th><td><input id="ogc-wm-reply" name="reply_to" type="email" class="regular-text" value="' . esc_attr( get_option( 'ogc_mail_reply_to', '' ) ) . '"><p class="description">A role address the webmasters read · Used when a kind of email has no committee to reply to</p></td></tr></table>';
	submit_button( 'Save', 'secondary', 'submit', false );
	echo '</form></div>';
}

/* ================================================================== committees from the label, once */

// Rows from before committees were kept: the first part of their label is their committee ("Lodging"
// of "Lodging · Desk"), if the year lists it or it's a name of its own. Once per site.
add_action( 'init', function () {
	global $wpdb;
	if ( get_option( 'ogc_members_committees_v1' ) || ! function_exists( 'ogc_file_get' ) ) {
		return;
	}
	$t = ogc_table( 'members' );
	// Not until the new column is there (the schema is applied first; try again next time if not).
	$wpdb->suppress_errors( true );
	$wpdb->get_var( "SELECT committees FROM $t LIMIT 1" ); // phpcs:ignore -- no input.
	$wpdb->suppress_errors( false );
	if ( $wpdb->last_error ) {
		return;
	}
	foreach ( (array) $wpdb->get_results( "SELECT id, helps, committees FROM $t WHERE role = 'helper'", ARRAY_A ) as $r ) { // phpcs:ignore -- no input.
		if ( isset( $r['committees'] ) && '' === $r['committees'] && '' !== trim( (string) $r['helps'] ) ) {
			$first = trim( preg_split( '/\s*[·,;|]\s*/u', (string) $r['helps'] )[0] );
			$k     = ogc_committee_key( $first );
			if ( '' !== $k ) {
				$wpdb->update( $t, array( 'committees' => $k ), array( 'id' => (int) $r['id'] ) );
			}
		}
	}
	ogc_members_cache( true );
	update_option( 'ogc_members_committees_v1', 1, false );
}, 30 );

/* ================================================================== the year area's first list */

// The year area kept a first list in its state ("members", until this one took over). This list is
// the one now: theirs is switched off, its people moved in once, and its routes (coa/{y}/members…)
// answered from here, in their shape, so a page still calling them keeps working.
add_filter( 'ogc_coa_members_builtin', '__return_false' );

add_action( 'init', function () {
	global $wpdb;
	if ( ! function_exists( 'ogc_state_get' ) || get_option( 'ogc_members_from_state' ) ) {
		return;
	}
	foreach ( ogc_years_list() as $y ) {
		$s = ogc_state_get( $y, 'members' );
		foreach ( $s && is_array( $s['value'] ) ? $s['value'] : array() as $email => $m ) {
			$email = ogc_clean_email( $email );
			if ( ! is_email( $email ) || ogc_member_find( $y, $email, true ) ) {
				continue;
			}
			$m = (array) $m;
			$wpdb->insert( ogc_table( 'members' ), array(
				'year'       => $y,
				'email'      => $email,
				'role'       => empty( $m['by'] ) || 'Webmasters' === $m['by'] ? 'coa' : 'helper',
				'name'       => isset( $m['name'] ) ? ogc_mail_safe_name( $m['name'] ) : '',
				'helps'      => isset( $m['committee'] ) ? ogc_member_helps_clean( $m['committee'] ) : '',
				'invited_at' => ! empty( $m['at'] ) ? $m['at'] . ' 12:00:00' : ogc_now(),
				'expires_at' => ! empty( $m['until'] ) && preg_match( '/^\d{4}-\d{2}-\d{2}$/', $m['until'] ) && $m['until'] !== $y . '-12-31' ? $m['until'] . ' 23:59:59' : null,
				'created_at' => ogc_now(),
			) );
		}
	}
	ogc_members_cache( true );
	update_option( 'ogc_members_from_state', 1, false );
}, 25 );

add_action( 'rest_api_init', function () {
	$Y   = '(?P<year>\d{4})';
	$old = function ( $year ) {
		$out = array();
		foreach ( ogc_members_list( $year ) as $m ) {
			$u     = get_user_by( 'email', $m['email'] );
			$x     = ogc_member_expiry( $m );
			$out[] = array(
				'email'     => $m['email'],
				'name'      => $m['name'],
				'committee' => $m['helps'],
				'by'        => $m['invited_by'] ? ogc_first_l( ogc_person_name( $m['invited_by'] ) ) : '',
				'at'        => substr( (string) $m['invited_at'], 0, 10 ),
				'resent'    => '',
				'until'     => $x ? substr( $x, 0, 10 ) : '',
				'seen'      => substr( (string) $m['signed_in_at'], 0, 10 ),
				'me'        => $m['email'] === ogc_current_email(),
				'dev'       => (bool) $m['sample'],
				'id'        => (int) $m['id'],
				'role'      => $m['role'],
			);
		}
		return $out;
	};
	$find = function ( WP_REST_Request $req ) {
		return ogc_member_find( (int) $req['year'], (string) $req->get_param( 'email' ) );
	};
	register_rest_route( OGC_NS, "/coa/$Y/members", array(
		array( 'methods' => 'GET', 'permission_callback' => 'ogc_can_members_read', 'callback' => function ( WP_REST_Request $req ) use ( $old ) {
			return rest_ensure_response( $old( (int) $req['year'] ) );
		} ),
		array( 'methods' => 'POST', 'permission_callback' => 'ogc_can_members_invite', 'callback' => function ( WP_REST_Request $req ) use ( $old ) {
			// The same route as Invite (its 40-at-once and 60-an-hour limits, the typo check), answered in
			// the old shape.
			$y   = (int) $req['year'];
			$new = new WP_REST_Request( 'POST', '/' . OGC_NS . '/years/' . $y . '/members' );
			$new->set_url_params( array( 'year' => $y ) );
			$new->set_body_params( array( 'emails' => (string) $req->get_param( 'emails' ), 'role' => 'helper', 'helps' => (string) $req->get_param( 'committee' ), 'typos_ok' => (bool) $req->get_param( 'typos_ok' ) ) );
			$r = ogc_rest_members_post( $new );
			if ( is_wp_error( $r ) ) {
				return $r;
			}
			$d     = $r->get_data();
			$email = function ( $ids ) {
				return array_values( array_filter( array_map( function ( $id ) {
					$m = ogc_member_get( (int) $id );
					return $m ? $m['email'] : '';
				}, (array) $ids ) ) );
			};
			return rest_ensure_response( array( 'added' => $email( $d['added'] ), 'already' => $email( $d['already'] ), 'bad' => $d['bad'], 'members' => $old( $y ) ) );
		} ),
	) );
	register_rest_route( OGC_NS, "/coa/$Y/members/resend", array( 'methods' => 'POST', 'permission_callback' => 'ogc_can_members_read', 'callback' => function ( WP_REST_Request $req ) use ( $old, $find ) {
		$m = $find( $req );
		if ( ! $m || ! ogc_member_can( 'resend', (int) $req['year'], $m ) ) {
			return new WP_Error( 'ogc_coa', 'Not a member', array( 'status' => 404 ) );
		}
		if ( ogc_throttle( 'resend:' . $m['id'], 1, MINUTE_IN_SECONDS ) ) {
			return new WP_Error( 'ogc_rate', 'Sent · Just now', array( 'status' => 429 ) );
		}
		ogc_member_send_invite( $m, get_current_user_id() );
		ogc_log( 'member_resend', (int) $m['year'], 'member:' . $m['id'] );
		return rest_ensure_response( $old( (int) $req['year'] ) );
	} ) );
	register_rest_route( OGC_NS, "/coa/$Y/members/remove", array( 'methods' => 'POST', 'permission_callback' => 'ogc_can_members_read', 'callback' => function ( WP_REST_Request $req ) use ( $old, $find ) {
		$m = $find( $req );
		if ( ! $m || ! ogc_member_can( 'remove', (int) $req['year'], $m ) || $m['email'] === ogc_current_email() || ( ogc_member_is_last_coa( $m ) && ! ogc_is_webmaster() ) ) {
			return new WP_Error( 'ogc_coa', 'Not allowed', array( 'status' => 403 ) );
		}
		ogc_member_remove( $m );
		return rest_ensure_response( $old( (int) $req['year'] ) );
	} ) );
	register_rest_route( OGC_NS, "/coa/$Y/members/set", array( 'methods' => 'POST', 'permission_callback' => 'ogc_can_members_read', 'callback' => function ( WP_REST_Request $req ) use ( $old, $find ) {
		global $wpdb;
		$m = $find( $req );
		if ( ! $m ) {
			return new WP_Error( 'ogc_coa', 'Not a member', array( 'status' => 404 ) );
		}
		$set = array();
		if ( null !== $req->get_param( 'name' ) && ogc_member_can( 'name', (int) $m['year'], $m ) ) {
			$set['name'] = ogc_mail_safe_name( (string) $req->get_param( 'name' ) );
		}
		if ( null !== $req->get_param( 'committee' ) && ogc_member_can( 'label', (int) $m['year'], $m ) ) {
			$set['helps'] = ogc_member_helps_clean( $req->get_param( 'committee' ) );
		}
		$until = (string) $req->get_param( 'until' );
		if ( '' !== $until && ogc_is_webmaster() && ogc_member_can( 'renew', (int) $m['year'], $m ) && preg_match( '/^\d{4}-\d{2}-\d{2}$/', $until ) ) {
			$set['expires_at'] = $until . ' 23:59:59';
		}
		if ( ! $set ) {
			return new WP_Error( 'ogc_coa', 'Not allowed', array( 'status' => 403 ) );
		}
		$wpdb->update( ogc_table( 'members' ), $set, array( 'id' => (int) $m['id'] ) );
		ogc_members_cache( true );
		ogc_log( isset( $set['helps'] ) ? 'member_label' : 'member_name', (int) $m['year'], 'member:' . $m['id'] );
		return rest_ensure_response( $old( (int) $req['year'] ) );
	} ) );
}, 20 );

/* ================================================================== sample members (local site only) */

/** seed/members.json: made-up members by year, for trying the pages (local site only). */
function ogc_members_seed_year( $year, $force = false ) {
	global $wpdb;
	if ( ! OGC_DEV ) {
		return 0;
	}
	$f   = ogc_seed_dir() . 'members.json';
	$all = file_exists( $f ) ? (array) ogc_unjson( file_get_contents( $f ), array() ) : array();
	if ( empty( $all[ (string) $year ] ) || null === ogc_year_get( (int) $year ) ) {
		return 0;
	}
	$has = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM ' . ogc_table( 'members' ) . ' WHERE year = %d AND sample = 1', $year ) );
	if ( $has && ! $force ) {
		return 0;
	}
	$wpdb->query( $wpdb->prepare( 'DELETE FROM ' . ogc_table( 'members' ) . ' WHERE year = %d AND sample = 1', $year ) );
	$n = 0;
	foreach ( (array) $all[ (string) $year ] as $m ) {
		if ( ! is_array( $m ) || empty( $m['email'] ) || ! is_email( $m['email'] ) ) {
			continue;
		}
		$email = ogc_clean_email( $m['email'] );
		$wpdb->delete( ogc_table( 'members' ), array( 'year' => (int) $year, 'email' => $email ) );
		$wpdb->insert( ogc_table( 'members' ), array(
			'year'         => (int) $year,
			'email'        => $email,
			'role'         => isset( $m['role'] ) && 'coa' === $m['role'] ? 'coa' : 'helper',
			'name'         => isset( $m['name'] ) ? ogc_mail_safe_name( $m['name'] ) : '',
			'helps'        => isset( $m['helps'] ) ? ogc_member_helps_clean( $m['helps'] ) : '',
			// The committee: the label's first part ("Lodging" of "Lodging · Desk").
			'committees'   => isset( $m['helps'] ) && 'coa' !== ( isset( $m['role'] ) ? $m['role'] : '' ) ? ogc_committee_key( preg_split( '/\s*[·,;|]\s*/u', (string) $m['helps'] )[0] ) : '',
			'head'         => ! empty( $m['head'] ) ? 1 : 0,
			'invited_at'   => isset( $m['invited'] ) ? $m['invited'] . ' 15:00:00' : ogc_now(),
			'signed_in_at' => ! empty( $m['signed_in'] ) ? $m['signed_in'] . ' 16:00:00' : null,
			'access_years' => isset( $m['years'] ) ? (int) $m['years'] : ogc_member_default_years( isset( $m['role'] ) ? $m['role'] : 'helper' ),
			'expires_at'   => ! empty( $m['expires'] ) ? $m['expires'] . ' 23:59:59' : null,
			'sample'       => 1,
			'created_at'   => ogc_now(),
		) );
		// Handles money (decision 4): a sample treasurer, so the Money screen and the ledger show full.
		if ( ! empty( $m['money'] ) ) {
			ogc_member_set_money( (int) $year, $email, true );
		}
		$n++;
	}
	ogc_members_cache( true );
	return $n;
}

// A local site seeded before Oct 13 gets the sample treasurer once (seed/members.json "money"), only
// while the year has no one ticked: nothing a person chose is changed.
add_action( 'init', function () {
	if ( ! OGC_DEV || get_option( 'ogc_money_sample' ) || ! function_exists( 'ogc_member_money_emails' ) || ! function_exists( 'ogc_seed_dir' ) ) {
		return;
	}
	update_option( 'ogc_money_sample', 1, false );
	$f   = ogc_seed_dir() . 'members.json';
	$all = file_exists( $f ) ? (array) ogc_unjson( file_get_contents( $f ), array() ) : array();
	foreach ( $all as $year => $rows ) {
		if ( ! ogc_valid_year( $year ) || ! is_array( $rows ) || ogc_member_money_emails( (int) $year ) ) {
			continue;
		}
		foreach ( $rows as $m ) {
			if ( is_array( $m ) && ! empty( $m['money'] ) && ! empty( $m['email'] ) && ogc_member_find( (int) $year, $m['email'] ) ) {
				ogc_member_set_money( (int) $year, $m['email'], true );
			}
		}
	}
}, 30 );

function ogc_members_seed_all( $force = false ) {
	foreach ( ogc_years_list() as $y ) {
		ogc_members_seed_year( $y, $force );
	}
}

// A forced reload of the seed (Pages › Start over) brings the sample members back too.
add_action( 'ogc_seed_year', function ( $year ) {
	ogc_members_seed_year( $year, true );
} );
add_action( 'init', function () {
	if ( ! OGC_DEV || get_option( 'ogc_members_seeded' ) ) {
		return;
	}
	ogc_members_seed_all();
	update_option( 'ogc_members_seeded', 1, false );
}, 20 );
