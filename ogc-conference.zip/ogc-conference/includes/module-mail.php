<?php
/**
 * Email: one way for every part of the plugin to send mail, ogc_send_mail(), and the Mail log.
 *
 *   ogc_send_mail( $to, $subject, $html, $context )   one message to each address (never To/CC lists)
 *   ogc_mail_send_kind( $kind, $to, $data, $context )  a designed email from the set (module-mail-templates.php)
 *   ogc_send_mail_many( $items )                       many at once: over 20 go through the queue (WP-Cron)
 *
 * $context: kind (signin, invite, signed_up…), year, text (the plain-text twin; made from the HTML when
 * left out), reply_to, ics + ics_name (a calendar file), delay (seconds), coalesce (a key: a later
 * message with the same key and address replaces a queued one, so three changes in ten minutes are one
 * email), batch (an id to count progress by).
 *
 * Every message is a row in ogc_mail: who, what kind, when, Sent or Failed ("Sent", never "Delivered":
 * wp_mail can't know). On ogbbc.org the body isn't kept once sent. With OGC_DEV nothing is sent: the
 * message is kept whole ("captured") and shown at /annual-conference/mail/ (webmasters, local only).
 * A staging copy defines OGC_MAIL_CAPTURE: mail is kept, not sent, with every one-time link and
 * sign-in code taken out (a webmaster reading the log can't sign in as anyone), except to the testers
 * OGC_MAIL_ALLOW names (addresses or @domains), whose mail really goes ("Sent (allowed)").
 * A sign-in code or a confirmation is tried once: never queued or retried, since by a retry the code
 * has nearly expired and its words would sit in the table meanwhile.
 *
 * Limits, for an address nobody has proved (the kind a stranger could type into a sign-up): at most 6
 * an hour and 20 a day of anything but sign-in codes (those have their own limits in module-auth.php).
 * Past the hour's 6, a message waits for the next hour, and a later one of the same kind takes its place
 * (gathered, never piled up); past the day's 20, it's refused: "Refused · limit" in the Mail log and in
 * the webmasters' Activity. Never capped: members and webmasters, role addresses (a committee's
 * contact, the webmasters' Replies to), and the signed-in person's own address. Kept 60 days.
 */

defined( 'ABSPATH' ) || exit;

add_filter( 'ogc_schema', 'ogc_mail_schema', 20, 2 );

function ogc_mail_schema( $sql, $charset ) {
	// One row a message. html/text are kept only while queued, and on a local site (to read in the
	// Mail log); on ogbbc.org a sent message keeps only who, what kind, when and whether it went.
	$sql[] = 'CREATE TABLE ' . ogc_table( 'mail' ) . " (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  at datetime NOT NULL,
  to_email varchar(190) NOT NULL,
  kind varchar(32) NOT NULL DEFAULT '',
  year smallint(5) unsigned NOT NULL DEFAULT 0,
  subject varchar(255) NOT NULL DEFAULT '',
  status varchar(12) NOT NULL DEFAULT '',
  html longtext NULL,
  text longtext NULL,
  meta longtext NULL,
  ckey varchar(64) NULL,
  batch varchar(32) NULL,
  send_after datetime NULL,
  tries tinyint(3) unsigned NOT NULL DEFAULT 0,
  sent_at datetime NULL,
  PRIMARY KEY  (id),
  KEY to_at (to_email,at),
  KEY status_after (status,send_after),
  KEY ckey (ckey),
  KEY batch (batch)
) $charset;";
	return $sql;
}

/** Messages kept whole and never sent: a local site (OGC_DEV), or a staging copy that defines
 * OGC_MAIL_CAPTURE (Corey's, for the COA's testing with sample data). */
function ogc_mail_capture() {
	return (bool) apply_filters( 'ogc_mail_capture', OGC_DEV || ( defined( 'OGC_MAIL_CAPTURE' ) && OGC_MAIL_CAPTURE ) );
}

/** May this address get real mail on a site that captures it (OGC_MAIL_ALLOW: "a@x.org, @church.org",
 * or an array)? Never on a local site. */
function ogc_mail_allowed( $to ) {
	if ( ! defined( 'OGC_MAIL_ALLOW' ) || ( function_exists( 'ogc_is_local_host' ) && ogc_is_local_host() ) ) {
		return false;
	}
	$list = is_array( OGC_MAIL_ALLOW ) ? OGC_MAIL_ALLOW : preg_split( '/[\s,;]+/', (string) OGC_MAIL_ALLOW );
	$to   = strtolower( trim( (string) $to ) );
	foreach ( array_filter( array_map( 'strtolower', array_map( 'trim', (array) $list ) ) ) as $a ) {
		$a = false === strpos( $a, '@' ) ? '@' . $a : $a;
		if ( $a === $to || ( '@' === $a[0] && substr( $to, -strlen( $a ) ) === $a ) ) {
			return true;
		}
	}
	return false;
}

/** On a site that captures mail but isn't this Mac (a staging copy), what the Mail log may keep: no
 * one-time link (?t=, ?h=) and, for the sign-in kinds, no words at all. Locally it's kept whole, so
 * a walk-through can sign in from the log. */
function ogc_mail_redact( $kind, $html, $text ) {
	if ( function_exists( 'ogc_is_local_host' ) && ogc_is_local_host() ) {
		return array( $html, $text );
	}
	if ( in_array( $kind, array( 'signin', 'confirm_email' ), true ) ) {
		return array( null, null );
	}
	$cut = function ( $s ) {
		if ( null === $s ) {
			return null;
		}
		$s = preg_replace( '/([?&](?:t|h|signin)=)[A-Za-z0-9_-]{12,}/', '$1link-removed', (string) $s );
		// Another area's own code email: a 6-digit code next to the word "code".
		return preg_match( '/\bcode\b/i', $s ) ? preg_replace( '/\b\d{3}\s?\d{3}\b/', '••• •••', $s ) : $s;
	};
	return array( $cut( $html ), $cut( $text ) );
}

/** Who the Conference emails come from: one role address, the same every year (Corey sets up SPF and
 * DKIM for it). An open question (NOTES/questions-signin.md); change with the ogc_mail_from filter. */
function ogc_mail_from() {
	$host = wp_parse_url( home_url(), PHP_URL_HOST );
	$host = $host && false === strpos( $host, '127.0.0.1' ) && 'localhost' !== $host ? preg_replace( '/^www\./', '', $host ) : 'ogbbc.org';
	return (array) apply_filters( 'ogc_mail_from', array( 'name' => 'ogbbc.org Annual Conference', 'email' => 'conference@' . $host ) );
}

/** Where replies go when a kind doesn't say: the webmasters' role address (option ogc_mail_reply_to). */
function ogc_mail_reply_default() {
	$r = get_option( 'ogc_mail_reply_to', '' );
	return is_email( $r ) ? $r : '';
}

/** The subject as the live site's log keeps it: a kind that carries a code or a name keeps only its
 * label ("Sign-in code", "Approval needed (a parent)"). */
function ogc_mail_log_subject( $kind, $subject ) {
	if ( function_exists( 'ogc_mail_private_kinds' ) && in_array( $kind, ogc_mail_private_kinds(), true ) ) {
		$k = ogc_mail_kinds();
		return isset( $k[ $kind ] ) ? $k[ $kind ] : $kind;
	}
	return $subject;
}

/** Sign-in codes and links have their own limits (module-auth.php) and skip the per-address cap. */
function ogc_mail_capped_kind( $kind ) {
	return ! in_array( $kind, array( 'signin', 'confirm_email' ), true );
}

/** Has this address had its fill of everything but sign-in? '' (no), 'hour' (6 in the last hour: the
 * message waits) or 'day' (20 in the last day: refused). */
function ogc_mail_over_cap( $to ) {
	global $wpdb;
	$t   = ogc_table( 'mail' );
	$sql = "SELECT COUNT(*) FROM $t WHERE to_email = %s AND at > %s AND status IN ('sent','captured','queued') AND kind NOT IN ('signin','confirm_email')";
	$h   = (int) $wpdb->get_var( $wpdb->prepare( $sql, $to, gmdate( 'Y-m-d H:i:s', time() - HOUR_IN_SECONDS ) ) );
	$d   = (int) $wpdb->get_var( $wpdb->prepare( $sql, $to, gmdate( 'Y-m-d H:i:s', time() - DAY_IN_SECONDS ) ) );
	$cap = (array) apply_filters( 'ogc_mail_caps', array( 'hour' => 6, 'day' => 20 ) );
	return $d >= (int) $cap['day'] ? 'day' : ( $h >= (int) $cap['hour'] ? 'hour' : '' );
}

/**
 * Addresses the cap never applies to: someone the site has given work (a member of any year, a
 * webmaster; context to_member), a role address (a committee's contact or a part's contact in a year's
 * settings or committees, the webmasters' Replies to), and the person signed in now writing to their own
 * address. Their notices and confirmations are never held back.
 */
function ogc_mail_cap_exempt( $to, $context = array() ) {
	if ( ! empty( $context['to_member'] ) || ( is_user_logged_in() && function_exists( 'ogc_current_email' ) && ogc_current_email() === $to ) ) {
		return true;
	}
	if ( function_exists( 'ogc_member_rows_for' ) && array_filter( ogc_member_rows_for( $to ), 'ogc_member_active' ) ) {
		return true;
	}
	$u = get_user_by( 'email', $to );
	if ( $u && user_can( $u, OGC_CAP_WEBMASTER ) ) {
		return true;
	}
	return in_array( $to, ogc_mail_role_addresses(), true );
}

/** The role addresses the Conference writes to: each recent year's contact_* settings and committees'
 * contact_email, and the webmasters' Replies to. */
function ogc_mail_role_addresses() {
	static $list = null;
	if ( null !== $list ) {
		return $list;
	}
	$list = array_filter( array( strtolower( ogc_mail_reply_default() ) ) );
	$years = function_exists( 'ogc_years_list' ) ? array_slice( (array) ogc_years_list(), -3 ) : array();
	foreach ( $years as $y ) {
		foreach ( ogc_mail_settings( (int) $y ) as $k => $v ) {
			if ( 0 === strpos( $k, 'contact_' ) && is_email( trim( $v ) ) ) {
				$list[] = strtolower( trim( $v ) );
			}
		}
		$f = function_exists( 'ogc_file_get' ) ? ogc_file_get( (int) $y, 'committees' ) : null;
		foreach ( $f ? (array) $f['rows'] : array() as $r ) {
			if ( ! empty( $r['contact_email'] ) && is_email( trim( $r['contact_email'] ) ) ) {
				$list[] = strtolower( trim( $r['contact_email'] ) );
			}
		}
	}
	$list = array_values( array_unique( $list ) );
	return $list;
}

/** HTML → the plain-text twin, when a caller gave none: links written out, tags dropped. */
function ogc_mail_html_to_text( $html ) {
	$t = preg_replace( '#<(style|head)[^>]*>.*?</\1>#is', '', (string) $html );
	$t = preg_replace_callback( '#<a\s[^>]*href="([^"]+)"[^>]*>(.*?)</a>#is', function ( $m ) {
		$label = trim( wp_strip_all_tags( $m[2] ) );
		return $label && $label !== $m[1] ? $label . ': ' . html_entity_decode( $m[1] ) : html_entity_decode( $m[1] );
	}, $t );
	$t = preg_replace( '#<br\s*/?>|</(p|div|tr|h[1-6]|li)>#i', "\n", $t );
	$t = html_entity_decode( wp_strip_all_tags( $t ), ENT_QUOTES, 'UTF-8' );
	$t = preg_replace( "/[ \t]+/", ' ', $t );
	return trim( preg_replace( "/\n\s*\n\s*\n+/", "\n\n", $t ) );
}

/**
 * Send one email to each address in $to. Returns the row id (one address) or a list of ids; 0 for a
 * message refused (bad address, over the cap).
 */
function ogc_send_mail( $to, $subject, $html, $context = array() ) {
	if ( is_array( $to ) ) {
		$out = array();
		foreach ( $to as $one ) {
			$out[] = ogc_send_mail( $one, $subject, $html, $context );
		}
		return $out;
	}
	global $wpdb;
	$to      = strtolower( trim( (string) $to ) );
	$kind    = isset( $context['kind'] ) ? substr( preg_replace( '/[^a-z0-9_]/', '', (string) $context['kind'] ), 0, 32 ) : 'other';
	$year    = isset( $context['year'] ) && ogc_valid_year( $context['year'] ) ? (int) $context['year'] : 0;
	$subject = trim( preg_replace( '/[\r\n\t]+/', ' ', (string) $subject ) );
	$subject = function_exists( 'mb_substr' ) ? mb_substr( $subject, 0, 200 ) : substr( $subject, 0, 200 );
	if ( ! is_email( $to ) ) {
		ogc_log( 'mail_refused', $year, $kind, array( 'why' => 'address' ) );
		return 0;
	}
	$over = ogc_mail_capped_kind( $kind ) && ! ogc_mail_cap_exempt( $to, $context ) ? ogc_mail_over_cap( $to ) : '';
	if ( 'day' === $over ) {
		$wpdb->insert( ogc_table( 'mail' ), array( 'at' => ogc_now(), 'to_email' => $to, 'kind' => $kind, 'year' => $year, 'subject' => ogc_mail_capture() ? $subject : ogc_mail_log_subject( $kind, $subject ), 'status' => 'refused', 'meta' => ogc_json( array( 'why' => 'limit' ) ) ) );
		ogc_log( 'mail_refused', $year, $kind, array( 'why' => 'cap', 'mail' => (int) $wpdb->insert_id ) );
		$GLOBALS['ogc_mail_refused'] = true;
		return 0;
	}
	if ( 'hour' === $over ) {
		// Gathered, not dropped: it waits for the next hour, and a later one of the same kind to the same
		// address takes its place (three changes in a busy evening are one email).
		$context = array_merge( $context, array( 'delay' => max( isset( $context['delay'] ) ? (int) $context['delay'] : 0, HOUR_IN_SECONDS ), 'coalesce' => isset( $context['coalesce'] ) && '' !== $context['coalesce'] ? $context['coalesce'] : 'cap|' . $kind ) );
	}
	// A parent's approval goes to an address a teenager typed, so it names no one: no name, no nights,
	// no hall, no money (the details are on the link's card once it's opened). One built any other way is
	// rebuilt here from the set, keeping only its link, and the change log says so.
	if ( 'parent_approval' === $kind && empty( $context['from_set'] ) ) {
		$link = preg_match( '#href="([^"]*[?&;](?:approve|t)=[A-Za-z0-9_%.-]+[^"]*)"#', (string) $html, $mm ) ? html_entity_decode( $mm[1] ) : '';
		$set  = $link ? ogc_mail_template( 'parent_approval', array( 'year' => $year, 'to' => $to, 'approve_url' => $link, 'again' => 0 === stripos( $subject, 'Reminder' ) ) ) : null;
		if ( ! $set ) {
			ogc_log( 'mail_refused', $year, $kind, array( 'why' => 'parent_approval' ) );
			return 0;
		}
		$subject = $set['subject'];
		$html    = $set['html'];
		$context = array_merge( $context, array( 'text' => $set['text'], 'reply_to' => ! empty( $context['reply_to'] ) ? $context['reply_to'] : $set['reply_to'] ) );
		ogc_log( 'mail_guarded', $year, $kind, array() );
	}
	$meta = array(
		'reply_to' => isset( $context['reply_to'] ) && is_email( $context['reply_to'] ) ? $context['reply_to'] : '',
		'ics'      => isset( $context['ics'] ) ? (string) $context['ics'] : '',
		'ics_name' => isset( $context['ics_name'] ) ? sanitize_file_name( (string) $context['ics_name'] ) : '',
	);
	// A plain-text body (some areas write their own words): laid out in the house style, words kept.
	if ( ! preg_match( '/<(html|p|div|table|br|a)\b/i', (string) $html ) ) {
		$plain   = (string) $html;
		$html    = ogc_mail_from_text( $subject, $plain, $year, $to );
		$context = array_merge( array( 'text' => $plain ), $context );
	}
	$text  = isset( $context['text'] ) && '' !== $context['text'] ? (string) $context['text'] : ogc_mail_html_to_text( $html );
	$delay = isset( $context['delay'] ) ? max( 0, (int) $context['delay'] ) : 0;
	$ckey  = isset( $context['coalesce'] ) && '' !== $context['coalesce'] ? substr( md5( (string) $context['coalesce'] ), 0, 32 ) : null;
	$batch = isset( $context['batch'] ) ? substr( preg_replace( '/[^a-z0-9_-]/i', '', (string) $context['batch'] ), 0, 32 ) : null;
	// A sign-in code or confirmation goes now, once, or not at all (ogc_mail_deliver).
	$once  = in_array( $kind, array( 'signin', 'confirm_email' ), true );
	$queue = ! $once && ( $delay || $ckey || ! empty( $context['queue'] ) );

	// A later change of the same thing, still waiting: the waiting one takes the new words.
	if ( $ckey ) {
		$id = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM ' . ogc_table( 'mail' ) . " WHERE ckey = %s AND to_email = %s AND status = 'queued' ORDER BY id DESC LIMIT 1", $ckey, $to ) );
		if ( $id ) {
			$wpdb->update( ogc_table( 'mail' ), array( 'subject' => $subject, 'html' => $html, 'text' => $text, 'meta' => ogc_json( $meta ) ), array( 'id' => $id ) );
			return $id;
		}
	}
	$wpdb->insert(
		ogc_table( 'mail' ),
		array(
			'at'         => ogc_now(),
			'to_email'   => $to,
			'kind'       => $kind,
			'year'       => $year,
			'subject'    => $subject,
			'status'     => 'queued',
			'html'       => (string) $html,
			'text'       => $text,
			'meta'       => ogc_json( $meta ),
			'ckey'       => $ckey,
			'batch'      => $batch,
			'send_after' => gmdate( 'Y-m-d H:i:s', time() + $delay ),
		)
	);
	$id = (int) $wpdb->insert_id;
	if ( ! $id ) {
		return 0;
	}
	if ( $queue ) {
		ogc_mail_schedule( time() + $delay );
		return $id;
	}
	ogc_mail_deliver( $id );
	return $id;
}

/** Many messages at once (Message them, Rooms posted, the weekly email): each item is
 * array( to, subject, html, context ). Up to 20 go now; more go through the queue in batches.
 * Returns the batch id, for "Sending · 120 of 412" (ogc_mail_batch_progress). */
function ogc_send_mail_many( $items ) {
	$batch = 'b' . strtolower( wp_generate_password( 12, false, false ) );
	$queue = count( (array) $items ) > (int) apply_filters( 'ogc_mail_queue_over', 20 );
	foreach ( (array) $items as $it ) {
		$ctx          = isset( $it[3] ) ? (array) $it[3] : array();
		$ctx['batch'] = $batch;
		$ctx['queue'] = $queue || ! empty( $ctx['queue'] );
		ogc_send_mail( $it[0], $it[1], $it[2], $ctx );
	}
	return $batch;
}

/** How far a batch has got: sent (or captured), failed, still to go. */
function ogc_mail_batch_progress( $batch ) {
	global $wpdb;
	$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT status, COUNT(*) n FROM ' . ogc_table( 'mail' ) . ' WHERE batch = %s GROUP BY status', $batch ), ARRAY_A );
	$o    = array( 'sent' => 0, 'failed' => 0, 'queued' => 0, 'refused' => 0 );
	foreach ( (array) $rows as $r ) {
		$k        = 'captured' === $r['status'] ? 'sent' : $r['status'];
		$o[ $k ] = ( isset( $o[ $k ] ) ? $o[ $k ] : 0 ) + (int) $r['n'];
	}
	$o['total'] = array_sum( $o );
	return $o;
}

function ogc_mail_schedule( $when ) {
	$next = wp_next_scheduled( 'ogc_mail_queue' );
	if ( ! $next || $next > $when + 30 ) {
		wp_schedule_single_event( max( time(), (int) $when ), 'ogc_mail_queue' );
	}
}

add_action( 'ogc_mail_queue', 'ogc_mail_run_queue' );

/** Send what's due, a batch at a time (Nexcess limits mail an hour), and come back for the rest. */
function ogc_mail_run_queue( $limit = 25 ) {
	global $wpdb;
	$t   = ogc_table( 'mail' );
	$ids = $wpdb->get_col( $wpdb->prepare( "SELECT id FROM $t WHERE status = 'queued' AND send_after <= %s ORDER BY id LIMIT %d", ogc_now(), (int) $limit ) );
	foreach ( (array) $ids as $id ) {
		ogc_mail_deliver( (int) $id );
	}
	$next = $wpdb->get_var( "SELECT MIN(send_after) FROM $t WHERE status = 'queued'" ); // phpcs:ignore -- no input.
	if ( $next ) {
		ogc_mail_schedule( max( time() + 60, strtotime( $next . ' UTC' ) ) );
	}
	return count( (array) $ids );
}

/** Send (or, locally, capture) one queued row. */
function ogc_mail_deliver( $id ) {
	global $wpdb;
	$t   = ogc_table( 'mail' );
	$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $t WHERE id = %d AND status = 'queued'", $id ), ARRAY_A );
	if ( ! $row ) {
		return false;
	}
	$allowed = ogc_mail_capture() && ogc_mail_allowed( $row['to_email'] );
	if ( ogc_mail_capture() && ! $allowed ) {
		list( $h, $x ) = ogc_mail_redact( $row['kind'], $row['html'], $row['text'] );
		$wpdb->update( $t, array( 'status' => 'captured', 'sent_at' => ogc_now(), 'html' => $h, 'text' => $x ), array( 'id' => $id ) );
		return true;
	}
	$meta    = (array) ogc_unjson( $row['meta'], array() );
	$from    = ogc_mail_from();
	$reply   = ! empty( $meta['reply_to'] ) ? $meta['reply_to'] : ogc_mail_reply_default();
	$headers = array(
		'Content-Type: text/html; charset=UTF-8',
		'From: ' . $from['name'] . ' <' . $from['email'] . '>',
	);
	if ( $reply ) {
		$headers[] = 'Reply-To: ' . $reply;
	}
	$files = array();
	if ( ! empty( $meta['ics'] ) ) {
		$dir  = trailingslashit( get_temp_dir() ) . 'ogc-mail-' . wp_generate_password( 8, false, false );
		wp_mkdir_p( $dir );
		$file = $dir . '/' . ( ! empty( $meta['ics_name'] ) ? $meta['ics_name'] : 'event.ics' );
		file_put_contents( $file, $meta['ics'] ); // phpcs:ignore -- a temp file for the attachment.
		$files[] = $file;
	}
	$text = (string) $row['text'];
	$alt  = function ( $phpmailer ) use ( $text ) {
		$phpmailer->AltBody = $text; // phpcs:ignore WordPress.NamingConventions -- PHPMailer's own name.
	};
	add_action( 'phpmailer_init', $alt );
	// A tester's address on a capturing copy: past the capture below, this once.
	$GLOBALS['ogc_mail_let_through'] = $allowed;
	$ok = wp_mail( $row['to_email'], $row['subject'], $row['html'], $headers, $files );
	$GLOBALS['ogc_mail_let_through'] = false;
	remove_action( 'phpmailer_init', $alt );
	foreach ( $files as $f ) {
		wp_delete_file( $f );
		@rmdir( dirname( $f ) ); // phpcs:ignore -- our own temp folder.
	}
	$tries = (int) $row['tries'] + 1;
	$once  = in_array( $row['kind'], array( 'signin', 'confirm_email' ), true );
	if ( $ok ) {
		// On the live site the words aren't kept once sent: only who, what kind and when (and for a code
		// or a name in the subject, only the kind's label).
		$wpdb->update( $t, array( 'status' => 'sent', 'sent_at' => ogc_now(), 'tries' => $tries, 'html' => null, 'text' => null, 'meta' => $allowed ? ogc_json( array( 'allowed' => 1 ) ) : null, 'subject' => ogc_mail_log_subject( $row['kind'], $row['subject'] ) ), array( 'id' => $id ) );
	} elseif ( $once || $tries >= 5 ) {
		$wpdb->update( $t, array( 'status' => 'failed', 'tries' => $tries, 'html' => null, 'text' => null, 'meta' => null, 'subject' => ogc_mail_log_subject( $row['kind'], $row['subject'] ) ), array( 'id' => $id ) );
		ogc_log( 'mail_failed', (int) $row['year'], $row['kind'], array( 'mail' => (int) $id ) );
	} else {
		// Try again in a few minutes, then less often.
		$wpdb->update( $t, array( 'tries' => $tries, 'send_after' => gmdate( 'Y-m-d H:i:s', time() + 300 * $tries ) ), array( 'id' => $id ) );
		ogc_mail_schedule( time() + 300 * $tries );
	}
	return (bool) $ok;
}

/* ------------------------------------------------------------------ keeping it small */

add_action( 'init', function () {
	if ( ! wp_next_scheduled( 'ogc_daily' ) ) {
		wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', 'ogc_daily' );
	}
} );
add_action( 'ogc_daily', 'ogc_mail_purge' );

/** The Mail log keeps 60 days. */
function ogc_mail_purge() {
	global $wpdb;
	$days = (int) apply_filters( 'ogc_mail_keep_days', 60 );
	$wpdb->query( $wpdb->prepare( 'DELETE FROM ' . ogc_table( 'mail' ) . " WHERE at < %s AND status <> 'queued'", gmdate( 'Y-m-d H:i:s', time() - $days * DAY_IN_SECONDS ) ) );
}

/* ------------------------------------------------------------------ one designed email */

/** A designed email from the set (ogc_mail_template) to one address. $context as ogc_send_mail's;
 * kind and year are filled from the template. */
function ogc_mail_send_kind( $kind, $to, $data = array(), $context = array() ) {
	$data = (array) $data;
	if ( empty( $data['to'] ) ) {
		$data['to'] = $to;
	}
	// "Calendar file attached" only when one is.
	if ( ! empty( $context['ics'] ) ) {
		$data['has_ics'] = true;
	}
	$m = ogc_mail_template( $kind, $data );
	if ( ! $m ) {
		return 0;
	}
	// Replies go to whoever the template says reads them (the part's contact, or the webmasters).
	$context = array_merge( array( 'kind' => $kind, 'year' => isset( $data['year'] ) ? $data['year'] : 0, 'text' => $m['text'], 'reply_to' => isset( $m['reply_to'] ) ? $m['reply_to'] : '' ), (array) $context, array( 'from_set' => true ) );
	return ogc_send_mail( $to, $m['subject'], $m['html'], $context );
}

/* ------------------------------------------------------------------ REST: a batch's progress */

add_action( 'rest_api_init', function () {
	register_rest_route( OGC_NS, '/mail/batches/(?P<id>b[a-z0-9]{12})', array(
		'methods'             => 'GET',
		'callback'            => function ( WP_REST_Request $req ) {
			return rest_ensure_response( ogc_mail_batch_progress( $req['id'] ) );
		},
		'permission_callback' => function () {
			return ( ogc_is_webmaster() || ogc_member_years() ) ? true : ogc_rest_denied();
		},
	) );
} );

/* ------------------------------------------------------------------ the Mail log (local only) */

/** The dev sign-in and its pills exist only on a local address (127.0.0.1, localhost, *.localhost,
 * *.test) with OGC_DEV: never on a staging copy, even with OGC_DEV on there. */
function ogc_dev_tools_on() {
	return OGC_DEV && function_exists( 'ogc_is_local_host' ) && ogc_is_local_host();
}

/** The Mail log (webmasters only): locally, or on a staging copy that captures mail (OGC_MAIL_CAPTURE).
 * Never where mail really goes out. */
function ogc_mail_log_on() {
	return ogc_mail_capture() && ( ogc_dev_tools_on() || ( defined( 'OGC_MAIL_CAPTURE' ) && OGC_MAIL_CAPTURE ) );
}

add_filter( 'ogc_pages', function ( $p ) {
	if ( ! ogc_mail_log_on() ) {
		return $p;
	}
	$p['mail'] = array(
		'path'        => 'mail',
		'folder'      => 'signin',
		'shell'       => 'bare',
		'members'     => false,
		'template'    => 'signin-mail.php',
		'html_class'  => 'adm-full',
		'title'       => 'Mail log',
		'noindex'     => true,
		'description' => '',
		'header'      => array(),
		'fonts'       => '',
		'head'        => '',
		'styles'      => array( 'shared/site-shell.css', 'shared/ogc-ui.css', 'schedule-hub/week.css', 'shared/ogc-ws.css', 'signin/signin.css', 'signin/mail.css' ),
		'scripts'     => array( 'signin/mail.js' ),
	);
	return $p;
}, 30 );

// Anyone but a webmaster gets the site's ordinary 404, as if the page weren't there.
add_action( 'ogc_before_page', function ( $page ) {
	if ( 'mail' !== $page ) {
		return;
	}
	if ( ! ogc_mail_log_on() || ! ogc_is_webmaster() ) {
		ogc_not_found();
	}
	nocache_headers();
	if ( ! defined( 'DONOTCACHEPAGE' ) ) {
		define( 'DONOTCACHEPAGE', true );
	}
	if ( 'POST' === ( isset( $_SERVER['REQUEST_METHOD'] ) ? $_SERVER['REQUEST_METHOD'] : '' ) && isset( $_POST['ogc_mail_do'] ) ) { // phpcs:ignore -- checked next.
		check_admin_referer( 'ogc_mail_log' );
		$do = sanitize_key( wp_unslash( $_POST['ogc_mail_do'] ) );
		global $wpdb;
		if ( 'clear' === $do ) {
			$wpdb->query( 'DELETE FROM ' . ogc_table( 'mail' ) . " WHERE status <> 'queued'" ); // phpcs:ignore -- no input.
		} elseif ( 'queue' === $do ) {
			// Locally WP-Cron may not fire on its own: send what's waiting, due or not.
			$wpdb->query( 'UPDATE ' . ogc_table( 'mail' ) . " SET send_after = '" . esc_sql( ogc_now() ) . "' WHERE status = 'queued'" ); // phpcs:ignore -- no input.
			ogc_mail_run_queue( 500 );
		}
		wp_safe_redirect( ogc_url( 'mail' ) );
		exit;
	}
	// Locally, whatever is due is sent when the log is opened.
	ogc_mail_run_queue( 100 );
}, 5 );

// Captured (locally, or a staging copy with OGC_MAIL_CAPTURE): every email any part of the plugin
// sends through wp_mail is kept in the Mail log too, and never sent.
add_filter( 'pre_wp_mail', function ( $short, $atts ) {
	if ( null !== $short || ! ogc_mail_capture() || ! empty( $GLOBALS['ogc_mail_let_through'] ) ) {
		return $short;
	}
	global $wpdb;
	$tos = array_filter( array_map( 'trim', (array) ( is_array( $atts['to'] ) ? $atts['to'] : explode( ',', (string) $atts['to'] ) ) ) );
	if ( $tos && count( array_filter( $tos, 'ogc_mail_allowed' ) ) === count( $tos ) ) {
		// Every recipient is a tester (OGC_MAIL_ALLOW): it goes, and the log says so.
		foreach ( $tos as $to ) {
			$wpdb->insert( ogc_table( 'mail' ), array( 'at' => ogc_now(), 'to_email' => strtolower( $to ), 'kind' => 'wp_mail', 'subject' => substr( (string) $atts['subject'], 0, 200 ), 'status' => 'sent', 'meta' => ogc_json( array( 'via' => 'wp_mail', 'allowed' => 1 ) ), 'sent_at' => ogc_now() ) );
		}
		return $short;
	}
	$plain = true;
	foreach ( (array) ( is_array( $atts['headers'] ) ? $atts['headers'] : explode( "\n", (string) $atts['headers'] ) ) as $h ) {
		if ( preg_match( '#content-type:\s*text/html#i', (string) $h ) ) {
			$plain = false;
		}
	}
	foreach ( (array) ( is_array( $atts['to'] ) ? $atts['to'] : explode( ',', (string) $atts['to'] ) ) as $to ) {
		$to = strtolower( trim( (string) $to ) );
		if ( ! is_email( $to ) ) {
			continue;
		}
		$body = (string) $atts['message'];
		list( $h, $x ) = ogc_mail_redact( 'wp_mail', $plain ? ogc_mail_from_text( (string) $atts['subject'], $body, 0, $to ) : $body, $plain ? $body : ogc_mail_html_to_text( $body ) );
		$wpdb->insert( ogc_table( 'mail' ), array(
			'at'      => ogc_now(),
			'to_email' => $to,
			'kind'    => 'wp_mail',
			'subject' => substr( (string) $atts['subject'], 0, 200 ),
			'status'  => 'captured',
			'html'    => $h,
			'text'    => $x,
			'meta'    => ogc_json( array( 'via' => 'wp_mail' ) ),
			'sent_at' => ogc_now(),
		) );
	}
	// Stopped here: nothing leaves a site that captures mail.
	return true;
}, 50, 2 );

/** The site's own 404, then stop. */
function ogc_not_found() {
	global $wp_query;
	if ( $wp_query ) {
		$wp_query->set_404();
	}
	status_header( 404 );
	nocache_headers();
	$t = get_404_template();
	if ( $t ) {
		include $t;
	} else {
		echo 'Not found';
	}
	exit;
}

/** The Mail log's rows, newest first, optionally for one address. */
function ogc_mail_rows( $to = '', $limit = 200 ) {
	global $wpdb;
	$t = ogc_table( 'mail' );
	if ( $to ) {
		return (array) $wpdb->get_results( $wpdb->prepare( "SELECT * FROM $t WHERE to_email LIKE %s ORDER BY id DESC LIMIT %d", '%' . $wpdb->esc_like( strtolower( $to ) ) . '%', $limit ), ARRAY_A );
	}
	return (array) $wpdb->get_results( $wpdb->prepare( "SELECT * FROM $t ORDER BY id DESC LIMIT %d", $limit ), ARRAY_A );
}
