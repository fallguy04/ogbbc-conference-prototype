<?php
/**
 * The committees' screens in the app (app-committees area, Oct 11; docs/23).
 *
 * Each committee's work is a set of screens in its own sidebar section, drawn by
 * assets/app/screens/committee-*.js with the app's kit:
 *
 *   Lodging       Households · Rooms · Check-in · Young Folks · Campers · Import
 *   Food          Meal counts · Menus
 *   Preteens      Children (who may pick each child up)
 *   Communion     Communing
 *   Young Folks   Teams (tournament teams, or "their own way")
 *   Every committee with volunteer shifts: Helpers (who's signed up: names, phones, add, move, remove)
 *
 * Who may see them is the app's one rule (ogc_app_can_see): the committee's own people, and the COA
 * (coa_opens: the COA opens them from the committee's page or ⌘K; they stay out of the COA's sidebar).
 * Webmasters only through See as, which is read-only and logged. Every data route these screens call
 * asks the same rule here (ogc_appc_can), and refuses a change while seeing as or previewing a date.
 *
 * The old pages (/lodging/, /lists/ meals·communion·preteens, the volunteer page's ?view=lead,
 * tournaments ?view=teams) send their visitors here.
 */

defined( 'ABSPATH' ) || exit;

/* ================================================================== the screens */

/** The committees whose volunteer shifts are in this year's shifts.csv, by app key ("first aid"). */
function ogc_appc_shift_keys( $year ) {
	static $cache = array();
	if ( isset( $cache[ $year ] ) ) {
		return $cache[ $year ];
	}
	$out = array();
	if ( function_exists( 'ogc_vol_shifts' ) ) {
		foreach ( ogc_vol_shifts( (int) $year ) as $sh ) {
			$k = ogc_committee_key( $sh['committee'] );
			if ( '' !== $k && ogc_app_committee( (int) $year, $k ) ) {
				$out[ $k ] = true;
			}
		}
	}
	return $cache[ $year ] = array_keys( $out );
}

add_filter( 'ogc_app_screens', function ( $s, $year ) {
	$own = function ( $title, $who, $icon ) {
		return array( 'title' => $title, 'section' => 'own', 'who' => (array) $who, 'handable' => false, 'coa_opens' => true, 'icon' => $icon );
	};
	$s['lod-households'] = $own( 'Households', 'lodging', 'members' );
	$s['lod-rooms']      = $own( 'Rooms', 'lodging', 'overview' );
	$s['lod-checkin']    = $own( 'Check-in', 'lodging', 'tasks' );
	$s['lod-yf']         = $own( 'Young Folks', 'lodging', 'committees' );
	$s['lod-campers']    = $own( 'Campers', 'lodging', 'file' );
	$s['lod-import']     = $own( 'Import', 'lodging', 'upload' );
	$s['food-meals']     = $own( 'Meal counts', 'food', 'report' );
	$s['food-menus']     = $own( 'Menus', 'food', 'note' );
	$s['preteens-list']  = $own( 'Children', 'preteens', 'members' );
	$s['communion-list'] = $own( 'Communing', 'communion', 'report' );
	$s['yf-teams']       = $own( 'Teams', 'young folks', 'committees' );
	$keys = ogc_appc_shift_keys( (int) $year );
	if ( $keys ) {
		$s['helpers'] = $own( 'Helpers', $keys, 'members' );
	}
	return $s;
}, 20, 2 );

// The page: the shared readers the screens use (dates, the sign-up helpers, floor plans), then the
// screens. ogc-store.js is left out on purpose: no screen here loads the year's records into the
// browser; each asks its own route for only what its committee needs.
add_filter( 'ogc_pages', function ( $p ) {
	if ( ! isset( $p['app'] ) ) {
		return $p;
	}
	$p['app']['styles'][] = 'shared/ogc-map.css';
	$p['app']['styles'][] = 'app/screens/committee.css';
	foreach ( array( 'shared/ogc-core.js', 'shared/ogc-signups.js', 'shared/ogc-map.js', 'app/screens/committee-kit.js', 'app/screens/committee-lodging.js', 'lodging/lodging-plan.js',
		'app/screens/committee-lodging-rooms.js', 'app/screens/committee-lodging-lists.js', 'app/screens/committee-lodging-import.js',
		'app/screens/committee-food.js', 'app/screens/committee-helpers.js', 'app/screens/committee-lists.js', 'app/screens/committee-teams.js' ) as $js ) {
		$p['app']['scripts'][] = $js;
	}
	return $p;
}, 20 );

// Another area may add the same shared readers: each loads once, in its first place.
add_filter( 'ogc_pages', function ( $p ) {
	if ( isset( $p['app'] ) ) {
		$p['app']['scripts'] = array_values( array_unique( $p['app']['scripts'] ) );
		$p['app']['styles']  = array_values( array_unique( $p['app']['styles'] ) );
	}
	return $p;
}, 99 );

/* ================================================================== the old pages send people here */

add_action( 'ogc_before_page', function ( $page ) {
	// phpcs:disable WordPress.Security.NonceVerification -- reading where to go, nothing changes.
	$g    = function ( $k ) {
		return isset( $_GET[ $k ] ) ? sanitize_text_field( wp_unslash( $_GET[ $k ] ) ) : '';
	};
	$year = $g( 'year' );
	$to   = null;
	if ( 'lodging' === $page ) {
		$map = array( 'yf' => 'lod-yf', 'campers' => 'lod-campers', 'checkin' => 'lod-checkin', 'import' => 'lod-import' );
		$v   = $g( 'view' );
		$to  = array( 's' => isset( $map[ $v ] ) ? $map[ $v ] : 'lod-rooms' );
	} elseif ( 'lists' === $page ) {
		$map = array( '' => 'food-meals', 'meals' => 'food-meals', 'communion' => 'communion-list', 'preteens' => 'preteens-list', 'payments' => 'money', 'credits' => 'money', 'callin' => 'callin' );
		$v   = $g( 'view' );
		// Payments are the COA's Money screen (integration, Oct 11); the call-in list stays on the lists
		// page until a screen takes it.
		if ( isset( $map[ $v ] ) ) {
			$to = array( 's' => $map[ $v ] );
		}
	} elseif ( 'volunteer' === $page && 'lead' === $g( 'view' ) ) {
		$c  = $g( 'committee' );
		$to = array( 's' => 'helpers', 'c' => '' !== $c ? ogc_committee_key( $c ) : '' );
	} elseif ( 'tournaments' === $page && 'teams' === $g( 'view' ) ) {
		$to = array( 's' => 'yf-teams' );
	}
	// phpcs:enable
	if ( null === $to ) {
		return;
	}
	if ( ogc_valid_year( $year ) ) {
		$to = array( 'year' => (int) $year ) + $to;
	}
	wp_safe_redirect( ogc_url( 'app', array_filter( $to, function ( $x ) { return '' !== (string) $x; } ) ), 302 );
	exit;
} );

/* ================================================================== who may */

/** The app's viewer for a REST request (?as= kept), for the year in the address or given. */
function ogc_appc_viewer( WP_REST_Request $req, $year = null ) {
	$y = null === $year ? (int) $req['year'] : (int) $year;
	return ogc_app_viewer( $y, (string) $req->get_param( 'as' ) );
}

/**
 * May this request use a committee screen's data? true, or a WP_Error. Reading needs the screen; a
 * change also needs a real viewer (never while seeing as) and today's date (never a preview's).
 */
function ogc_appc_can( WP_REST_Request $req, $screen, $year = null ) {
	$y = null === $year ? (int) $req['year'] : (int) $year;
	if ( ! ogc_valid_year( $y ) || ! is_user_logged_in() ) {
		return ogc_rest_denied( 'Sign in first.' );
	}
	$v = ogc_appc_viewer( $req, $y );
	if ( ! ogc_app_can_see( $v, $screen ) ) {
		return new WP_Error( 'ogc_forbidden', 'Not your committee’s', array( 'status' => 403 ) );
	}
	if ( 'GET' !== $req->get_method() ) {
		if ( $v['as'] ) {
			return new WP_Error( 'ogc_read_only', 'Read only while seeing as', array( 'status' => 403 ) );
		}
		if ( '' !== (string) $req->get_param( 'as_of' ) && ! ogc_proto_saves() ) {
			return new WP_Error( 'ogc_preview', 'Preview · Not saved', array( 'status' => 403 ) );
		}
	}
	return true;
}

/** May the viewer open any of these screens? (the first that answers true wins) */
function ogc_appc_can_any( WP_REST_Request $req, $screens, $year = null ) {
	$last = null;
	foreach ( (array) $screens as $s ) {
		$r = ogc_appc_can( $req, $s, $year );
		if ( true === $r ) {
			return true;
		}
		$last = $r;
	}
	return $last ? $last : ogc_rest_denied();
}

/* ================================================================== Lodging's data */

/** "Names only": a box someone typed into, without anything that looks like an email or a phone. */
function ogc_appc_names_only( $t ) {
	$t = preg_replace( '/\S+@\S+/', '', (string) $t );
	$t = preg_replace( '/\+?\d[\d\s().-]{5,}\d/', '', $t );
	return trim( mb_substr( wp_strip_all_tags( $t ), 0, 160 ) );
}

/**
 * The year's households as Lodging's screens need them, and nothing more: who's coming, where and
 * when they sleep, what they asked, what they owe (Lodging collects at the desk), the phone for the
 * desk. Never an email (a short key tells two registrations apart), money totals, medical notes,
 * emergency contacts or who may pick a child up.
 */
function ogc_appc_lod_households( $year ) {
	$out = array();
	foreach ( ogc_records( (int) $year, 'registrations' ) as $r ) {
		$d   = is_array( $r['data'] ) ? $r['data'] : array();
		$rid = isset( $d['rid'] ) ? (string) $d['rid'] : ( isset( $d['id'] ) ? (string) $d['id'] : '' );
		if ( '' === $rid ) {
			continue;
		}
		$s  = isset( $d['stay'] ) && is_array( $d['stay'] ) ? $d['stay'] : array();
		$hh = isset( $d['household'] ) && is_array( $d['household'] ) ? $d['household'] : array();
		$people = array();
		foreach ( isset( $d['people'] ) ? (array) $d['people'] : array() as $p ) {
			if ( ! is_array( $p ) || empty( $p['name'] ) ) {
				continue;
			}
			$people[] = array(
				'pid'     => isset( $p['pid'] ) ? (string) $p['pid'] : '',
				'name'    => (string) $p['name'],
				'kind'    => isset( $p['kind'] ) ? (string) $p['kind'] : '',
				'age'     => isset( $p['age'] ) ? (string) $p['age'] : '',
				'yf'      => ! empty( $p['yf'] ),
				'yfHall'  => isset( $p['yfHall'] ) ? (string) $p['yfHall'] : '',
				'minor'   => ! empty( $p['minor'] ),
				'nights'  => array_values( (array) ( isset( $p['nights'] ) ? $p['nights'] : array() ) ),
				'rooming' => ogc_appc_names_only( isset( $p['rooming'] ) ? $p['rooming'] : '' ),
				'sleeps'  => isset( $p['sleeps'] ) ? (string) $p['sleeps'] : '',
				'room'    => isset( $p['room'] ) && null !== $p['room'] && '' !== $p['room'] ? (int) $p['room'] : null,
				'band'    => isset( $p['band'] ) ? (string) $p['band'] : '',
				'preteen' => ! empty( $p['preteen'] ),
			);
		}
		$keep = array( 'type', 'nights', 'rooms', 'linens', 'mattresses', 'ground', 'walker', 'nearW', 'nearM', 'near', 'arrive', 'keys', 'needs', 'campers', 'camperLen', 'chosen' );
		$stay = array_intersect_key( $s, array_flip( $keep ) );
		$stay['parentEmail'] = ! empty( $s['parentEmail'] );
		$m     = isset( $d['money'] ) && is_array( $d['money'] ) ? $d['money'] : null;
		$email = isset( $hh['email'] ) ? strtolower( trim( (string) $hh['email'] ) ) : '';
		$hist  = array();
		foreach ( array_slice( (array) ( isset( $d['history'] ) ? $d['history'] : array() ), -6 ) as $x ) {
			if ( is_array( $x ) && ! empty( $x['what'] ) ) {
				// Money acts in plain words only (night-records: amounts, numbers, payers are Handles money's).
				$hist[] = array( 'at' => isset( $x['at'] ) ? (string) $x['at'] : '', 'what' => mb_substr( function_exists( 'ogc_rec_hist_plain' ) ? ogc_rec_hist_plain( $x['what'] ) : (string) $x['what'], 0, 120 ) );
			}
		}
		$form = isset( $d['form'] ) && is_array( $d['form'] ) ? array_intersect_key( $d['form'], array_flip( array( 'pay', 'payText', 'keys', 'group', 'choice', 'problems', 'oldest' ) ) ) : null;
		$out[] = array(
			'rid'       => $rid,
			'status'    => isset( $d['status'] ) ? (string) $d['status'] : 'registered',
			'source'    => isset( $d['source'] ) ? (string) $d['source'] : ( ! empty( $r['source'] ) && 'seed' !== $r['source'] ? (string) $r['source'] : 'online' ),
			// When it was registered: its own date (a household entered from paper keeps the form's date).
			'created'   => isset( $d['created'] ) ? (string) $d['created'] : ( ! empty( $d['at'] ) ? (string) $d['at'] : (string) $r['created_at'] ),
			'updated'   => (string) $r['updated_at'],
			'sample'    => ! empty( $r['sample'] ),
			'household' => array(
				'name'    => isset( $hh['name'] ) ? (string) $hh['name'] : '',
				'contact' => isset( $hh['contact'] ) ? (string) $hh['contact'] : '',
				'phone'   => isset( $hh['phone'] ) ? (string) $hh['phone'] : '',
			),
			'ek'        => '' !== $email ? substr( md5( wp_salt( 'auth' ) . $email ), 0, 12 ) : '',
			'people'    => $people,
			'stay'      => $stay,
			// What's owed, from the one function Households and Money use (night-records), so the lists agree.
			'money'     => function_exists( 'ogc_rec_money_lodging' ) ? ogc_rec_money_lodging( $r ) : ( $m ? array( 'due' => (int) ( isset( $m['due'] ) ? $m['due'] : 0 ), 'check' => (int) ( isset( $m['check'] ) ? $m['check'] : 0 ) ) : null ),
			'form'      => $form,
			'history'   => $hist,
			'approval'  => isset( $d['approval'] ) && is_array( $d['approval'] ) ? array_intersect_key( $d['approval'], array_flip( array( 'state', 'at', 'sent_at' ) ) ) : null,
		);
	}
	return $out;
}

/* ================================================================== status lines (the board writes itself) */

add_filter( 'ogc_committee_status', function ( $line, $year, $ckey, $ctx ) {
	$y = (int) $year;
	if ( 'lodging' === $ckey && function_exists( 'ogc_lod_summary' ) ) {
		$s = ogc_lod_summary( $y );
		if ( $s['dorm'] ) {
			if ( $s['waiting'] ) {
				return ogc_appc_n( $s['waiting'], 'household' ) . ' to place';
			}
			if ( ! $s['published'] ) {
				return 'All ' . $s['dorm'] . ' placed · Not published';
			}
			return 'Published ' . ogc_appc_md( $s['published'] ) . ( $s['changed'] ? ' · ' . $s['changed'] . ' changed since' : '' );
		}
	}
	if ( 'food' === $ckey && function_exists( 'ogc_lst_sent' ) ) {
		$sent = ogc_lst_sent( $y );
		$set  = ogc_lst_state( $y, 'lists_settings' );
		$due  = isset( $set['counts_due'] ) ? $set['counts_due'] : '';
		if ( $sent ) {
			return ( ! empty( $sent[0]['final'] ) ? 'Final counts sent ' : 'Counts sent ' ) . ogc_appc_md( $sent[0]['day'] ) . ( $due && empty( $sent[0]['final'] ) ? ' · Due ' . ogc_appc_md( $due ) : '' );
		}
		if ( $due ) {
			return 'Meal counts due ' . ogc_appc_md( $due );
		}
	}
	if ( in_array( $ckey, array( 'preteens', 'communion' ), true ) && function_exists( 'ogc_lst_regs' ) ) {
		$n = 0;
		foreach ( ogc_lst_regs( $y ) as $r ) {
			foreach ( (array) $r['data']['people'] as $p ) {
				$n += ! empty( $p[ 'preteens' === $ckey ? 'preteen' : 'communing' ] ) ? 1 : 0;
			}
		}
		if ( $n ) {
			// One number: who's coming (the shifts have their own screen).
			return 'preteens' === $ckey ? ogc_appc_n( $n, 'preteen' ) . ' registered' : $n . ' communing';
		}
	}
	if ( 'young folks' === $ckey && function_exists( 'ogc_tn_teams' ) ) {
		$s = function_exists( 'ogc_lst_kv' ) ? ogc_lst_kv( $y, 'settings' ) : array();
		if ( 'no' === ( isset( $s['tournaments_online'] ) ? $s['tournaments_online'] : '' ) ) {
			return 'Tournaments their own way';
		}
		$n = 0;
		foreach ( ogc_tn_teams( $y ) as $t ) {
			$n += 'active' === ( isset( $t['data']['status'] ) ? $t['data']['status'] : 'active' ) ? 1 : 0;
		}
		if ( $n ) {
			return ogc_appc_n( $n, 'team' ) . ' signed up';
		}
	}
	$help = ogc_appc_shift_line( $y, $ckey );
	return $help ? $help : $line;
}, 10, 4 );

/** "18 of 24 places filled" for a committee's shifts, once sign-ups are posted ('' when none). */
function ogc_appc_shift_line( $year, $ckey ) {
	if ( ! function_exists( 'ogc_vol_shifts' ) || ! in_array( $ckey, ogc_appc_shift_keys( $year ), true ) || ! ogc_vol_posted( $year ) ) {
		return '';
	}
	$map = ogc_vol_seat_map( $year );
	$n   = array( 'filled' => 0, 'needed' => 0 );
	foreach ( ogc_vol_committees( $year ) as $c ) {
		if ( ogc_committee_key( $c['name'] ) === $ckey ) {
			$x            = ogc_vol_committee_numbers( $year, $c['name'], $map );
			$n['filled'] += min( $x['filled'], $x['needed'] ? $x['needed'] : $x['filled'] );
			$n['needed'] += $x['needed'];
		}
	}
	return $n['needed'] ? $n['filled'] . ' of ' . $n['needed'] . ' shift places filled' : '';
}

function ogc_appc_n( $n, $one, $many = '' ) {
	return $n . ' ' . ( 1 === (int) $n ? $one : ( $many ? $many : $one . 's' ) );
}

function ogc_appc_md( $iso ) {
	$t = strtotime( (string) $iso . ' 12:00:00 UTC' );
	return $t ? gmdate( 'M j', $t ) : '';
}

/* ================================================================== a committee's work, on its page */

add_action( 'rest_api_init', function () {
	register_rest_route( OGC_NS, '/app/(?P<year>\d{4})/work', array(
		'methods'             => 'GET',
		'callback'            => 'ogc_appc_rest_work',
		'permission_callback' => function ( WP_REST_Request $req ) {
			$v = ogc_appc_viewer( $req );
			return ! empty( $v['open'] ) ? true : ogc_rest_denied();
		},
	) );
} );

/** The screens a committee works in, each with a line of fact, for its page (only those the viewer may open). */
function ogc_appc_rest_work( WP_REST_Request $req ) {
	$y   = (int) $req['year'];
	$v   = ogc_appc_viewer( $req );
	$c   = ogc_committee_key( (string) $req->get_param( 'c' ) );
	$out = array();
	// Every committee's own Requests (the year's round), first: the list each committee has its own of,
	// opened filtered to this one (Round 1, Oct 14: Nursery's page said "7 to answer" and led nowhere).
	if ( 'coa' !== $c && ogc_app_committee( $y, $c ) && ogc_app_can_see( $v, 'requests' ) && ogc_app_on_committee( $v, $c ) ) {
		$out[] = array( 'id' => 'requests', 'c' => $c, 'title' => 'Requests', 'line' => ogc_appc_requests_line( $y, $c ) );
	}
	foreach ( ogc_app_screens( $y ) as $id => $d ) {
		if ( empty( $d['coa_opens'] ) || ( ! in_array( $c, $d['who'], true ) ) || ! ogc_app_can_see( $v, $id ) ) {
			continue;
		}
		$out[] = array( 'id' => $id, 'title' => $d['title'], 'line' => ogc_appc_work_line( $y, $id, $c ) );
	}
	return rest_ensure_response( array( 'screens' => $out ) );
}

/** A committee's Requests in a few words, from the round itself: "7 to answer · Due Nov 13", "Returned Oct 9". */
function ogc_appc_requests_line( $y, $c ) {
	if ( ! function_exists( 'ogc_round_ready' ) || ! ogc_round_ready() || ! function_exists( 'ogc_round_line_state' ) ) {
		return '';
	}
	$lines = ogc_round_lines( $y );
	$st    = ogc_round_line_state( $y, isset( $lines[ $c ] ) ? $lines[ $c ] : null, ogc_round_today( $y ) );
	if ( 'returned' === $st['status'] ) {
		return 'Returned ' . ogc_app_md( $st['returned'], $y );
	}
	if ( 'notsent' === $st['status'] ) {
		return '';
	}
	$left = ogc_round_left( $y, $c );
	$due  = ogc_round_dates( $y )['due'];
	return ( $left['total'] ? $left['total'] . ' to answer' : 'Answered · Not returned' ) . ( $due ? ' · Due ' . ogc_app_md( $due, $y ) : '' );
}

function ogc_appc_work_line( $y, $id, $c ) {
	if ( 0 === strpos( $id, 'lod-' ) && function_exists( 'ogc_lod_summary' ) ) {
		$s = ogc_lod_summary( $y );
		if ( 'lod-rooms' === $id && $s['dorm'] ) {
			return $s['waiting'] ? $s['waiting'] . ' to place' : ( $s['published'] ? 'Published ' . ogc_appc_md( $s['published'] ) : 'All placed' );
		}
		if ( 'lod-households' === $id ) {
			$n = count( ogc_lod_households( $y ) );
			return $n ? ogc_appc_n( $n, 'household' ) : '';
		}
	}
	if ( 'helpers' === $id ) {
		return ogc_appc_shift_line( $y, $c );
	}
	// Another area's screens write their own line (lists area: "60 preteens", "Sent Mar 3").
	return (string) apply_filters( 'ogc_appc_work_line', '', $y, $id, $c );
}

/* ================================================================== Helpers: the volunteer heads' list */

/**
 * Which committees' shifts may this viewer lead? null = every committee (the COA); else the shift
 * committee names whose key is one of theirs. Read by module-volunteer.php's ogc_vol_can_lead and
 * ogc_vol_lead_committees through ogc_appc_vol_scope().
 */
function ogc_appc_vol_scope( $year ) {
	$as = isset( $GLOBALS['ogc_appc_vol_as'] ) ? (string) $GLOBALS['ogc_appc_vol_as'] : '';
	$v  = ogc_app_viewer( (int) $year, $as );
	if ( $v['coa'] ) {
		return null;
	}
	$names = array();
	if ( function_exists( 'ogc_vol_committees' ) ) {
		foreach ( ogc_vol_committees( (int) $year ) as $c ) {
			if ( in_array( ogc_committee_key( $c['name'] ), (array) $v['committees'], true ) ) {
				$names[] = $c['name'];
			}
		}
	}
	return $names;
}

/* ================================================================== Food, Preteens, Communion: the lists' routes */

/** Which screen answers for a lists route. */
function ogc_appc_list_screen( $route ) {
	if ( preg_match( '#/lists/\d{4}/(communion)#', $route ) ) {
		return 'communion-list';
	}
	if ( preg_match( '#/lists/\d{4}/(preteens)#', $route ) ) {
		return 'preteens-list';
	}
	if ( preg_match( '#/lists/\d{4}/(meals|settings)#', $route ) ) {
		return 'food-meals';
	}
	if ( preg_match( '#/lists/\d{4}/(printed|seen)#', $route ) ) {
		// Each list's own committee is checked again in the route (lists area, module-lists.php).
		return array( 'food-meals', 'communion-list', 'preteens-list', 'nursery-list', 'yf-halls' );
	}
	return '';
}

// Each list goes to its committee and the COA only (it was every member of the year). Payments, the
// call-in list and who-sees stay with the year's members until the COA's screens take them.
add_filter( 'rest_request_before_callbacks', function ( $res, $handler, $req ) {
	if ( is_wp_error( $res ) ) {
		return $res;
	}
	$route = (string) $req->get_route();
	if ( 0 === strpos( $route, '/' . OGC_NS . '/lists/' ) ) {
		$sc = ogc_appc_list_screen( $route );
		if ( $sc ) {
			$y  = preg_match( '#/lists/(\d{4})/#', $route, $m ) ? (int) $m[1] : 0;
			$ok = ogc_appc_can_any( $req, (array) $sc, $y );
			if ( true !== $ok ) {
				return $ok;
			}
		}
	}
	// Tournament teams: the Young Folks committee and the COA (the signer's own routes are untouched).
	if ( preg_match( '#^/' . preg_quote( OGC_NS, '#' ) . '/tn/(\d{4})/(teams|add|message)$#', $route, $m ) && ! ( 'teams' === $m[2] && 'POST' === $req->get_method() ) ) {
		$ok = ogc_appc_can( $req, 'yf-teams', (int) $m[1] );
		if ( true !== $ok ) {
			return $ok;
		}
	}
	if ( preg_match( '#^/' . preg_quote( OGC_NS, '#' ) . '/tn/r/(\d+)/flag$#', $route, $m ) ) {
		$r  = ogc_record_get( (int) $m[1] );
		$ok = $r ? ogc_appc_can( $req, 'yf-teams', (int) $r['year'] ) : ogc_rest_denied();
		if ( true !== $ok ) {
			return $ok;
		}
	}
	// The tournaments' own settings (their own way, the sign-up line): the Young Folks committee and the COA.
	if ( preg_match( '#^/' . preg_quote( OGC_NS, '#' ) . '/years/(\d{4})/files/settings$#', $route, $m ) && in_array( $req->get_method(), array( 'PATCH', 'PUT' ), true ) ) {
		$k = (string) $req->get_param( 'key' );
		if ( 0 === strpos( $k, 'tournaments_' ) ) {
			$ok = ogc_appc_can( $req, 'yf-teams', (int) $m[1] );
			if ( true !== $ok ) {
				return $ok;
			}
		}
	}
	// The volunteer heads' routes: remember who is asking as whom (See as), and refuse a change then.
	if ( preg_match( '#^/' . preg_quote( OGC_NS, '#' ) . '/vol/(\d{4})/lead#', $route, $m ) ) {
		$GLOBALS['ogc_appc_vol_as'] = (string) $req->get_param( 'as' );
		if ( 'GET' !== $req->get_method() && '' !== $GLOBALS['ogc_appc_vol_as'] ) {
			return new WP_Error( 'ogc_read_only', 'Read only while seeing as', array( 'status' => 403 ) );
		}
	}
	return $res;
}, 6, 3 );

// Children's details (names, ages, who may pick them up, medical notes, contacts): the COA and the
// Preteens committee (docs/23), as well as anyone the COA named before the app.
add_filter( 'ogc_reg_sensitive_viewer', function ( $ok, $year ) {
	if ( $ok || ! function_exists( 'ogc_app_viewer' ) ) {
		return $ok;
	}
	$v = ogc_app_viewer( (int) $year );
	return $v['coa'] || in_array( 'preteens', (array) $v['committees'], true );
}, 10, 2 );

/*
 * A whole registration read through the year's generic records route (any member): who may pick a
 * child up goes only to those who see children's details, and money only to the COA and those the
 * COA named for Payments. Lodging reads what each household owes through its own route.
 */
add_filter( 'ogc_record_whole', function ( $data, $rec ) {
	if ( 'registrations' !== $rec['kind'] || ! is_array( $data ) || ( function_exists( 'ogc_reg_is_household' ) && ogc_reg_is_household( $rec ) ) ) {
		return $data;
	}
	$y = (int) $rec['year'];
	if ( function_exists( 'ogc_reg_sensitive_viewer' ) && ! ogc_reg_sensitive_viewer( $y ) ) {
		foreach ( array( 'pickup', 'pickupWho', 'pickupOther' ) as $k ) {
			if ( isset( $data[ $k ] ) ) {
				$data[ $k ] = is_array( $data[ $k ] ) ? array() : '';
			}
		}
	}
	$v     = function_exists( 'ogc_app_viewer' ) ? ogc_app_viewer( $y ) : array( 'coa' => true );
	$money = $v['coa'] || ogc_is_webmaster() || ( function_exists( 'ogc_lst_viewer' ) && ogc_lst_viewer( $y, 'payments' ) );
	if ( ! $money ) {
		foreach ( array( 'money', 'paid', 'checkDue', 'checkGot', 'price', 'pay', 'creditAsk', 'unpaid' ) as $k ) {
			unset( $data[ $k ] );
		}
	}
	return $data;
}, 20, 2 );

// The lists' own state values (the ledger's marks, who sees what) are read through the lists' routes:
// the generic state route gave them to every member of the year.
add_filter( 'rest_request_before_callbacks', function ( $res, $handler, $req ) {
	if ( is_wp_error( $res ) || 'GET' !== $req->get_method() ) {
		return $res;
	}
	if ( preg_match( '#^/' . preg_quote( OGC_NS, '#' ) . '/years/(\d{4})/state/(pay_marks|pay_reminded|payment_viewers|preteen_viewers|lists_record)$#', (string) $req->get_route(), $m ) ) {
		$y = (int) $m[1];
		$v = function_exists( 'ogc_app_viewer' ) ? ogc_app_viewer( $y ) : array( 'coa' => false );
		if ( ! $v['coa'] && ! ogc_is_webmaster() && ! ( function_exists( 'ogc_lst_viewer' ) && ogc_lst_viewer( $y, 'payments' ) ) ) {
			return new WP_Error( 'ogc_forbidden', 'Not allowed.', array( 'status' => 403 ) );
		}
	}
	return $res;
}, 6, 3 );
