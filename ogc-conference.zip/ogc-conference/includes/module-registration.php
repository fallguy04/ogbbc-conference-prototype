<?php
/**
 * Registration (register area): a household's registration as a record (kind "registrations"), its
 * money from the ledger (module-payments.php), a parent's approval for a Young Folk under 18 coming
 * alone, and the page's settings. The routes are in module-registration-routes.php, the rules (prices,
 * what's allowed) in module-registration-rules.php, the emails and sign-in by code in
 * module-registration-mail.php.
 *
 * A registration's data is the household's answers (ogc_reg_clean) plus what only the server writes:
 *   rid / id      R-2027-0001, given in order (what people write on a check)
 *   status        registered · payment_due · balance_due · check_to_come · refund_due · waitlist · cancelled
 *   price         the lines and total charged, in cents, and the prices used (kept: a later price change
 *                 never reprices it)
 *   money         summed from the ledger (cents): total, paid, check, pending, refund, due
 *   paid, checkDue, checkGot   the same in dollars, for the committees' pages as v3 had them
 *   approval      a parent's approval (state, to, sent_at, at); the token itself is never kept
 *   managers      other emails that may see and change it (a helper)
 *   source        online · desk · paper · phone · helper
 *   history       short lines of what changed and when
 *   flags         changed (since Lodging gave rooms), dup (likely the same people twice)
 *   _v            its version (a change naming an older one is refused, 409)
 */

defined( 'ABSPATH' ) || exit;

/* ================================================================== the page */

add_filter( 'ogc_pages', function ( $p ) {
	if ( isset( $p['register'] ) ) {
		$p['register']['template'] = 'register-form.php';
		// The dashed card (ws-blank) and the editors' small parts are in ogc-ws.css.
		array_splice( $p['register']['styles'], count( $p['register']['styles'] ) - 1, 0, array( 'shared/ogc-ws.css' ) );
		$p['register']['description'] = 'Register for the Annual Conference: who’s coming, where you’ll stay, meals and preteens, in one form. Your sign-ups shows everything under your email.';
	}
	return $p;
} );

// Registered and Change, opened from an email on another device by someone not signed in: the one
// sign-in door, as Your sign-ups and the receipt (module-auth), coming back after. Not a "Not found" card.
add_action( 'ogc_before_page', function ( $page ) {
	// phpcs:disable WordPress.Security.NonceVerification -- which view; nothing is changed.
	$view = isset( $_GET['view'] ) ? sanitize_key( wp_unslash( $_GET['view'] ) ) : '';
	if ( 'register' !== $page || is_user_logged_in() || ! in_array( $view, array( 'done', 'edit' ), true ) ) {
		return;
	}
	// phpcs:enable
	$here = isset( $_SERVER['REQUEST_URI'] ) ? ogc_safe_return( esc_url_raw( wp_unslash( $_SERVER['REQUEST_URI'] ) ) ) : '';
	nocache_headers();
	wp_safe_redirect( ogc_url( 'signin', array_filter( array( 'return' => rawurlencode( $here ) ) ) ), 302 );
	exit;
}, 6 );

// The form and Your sign-ups read registrations through /reg routes; at load they need only this year's
// shifts and teams from the shared store (each record kind costs a request's time).
add_filter( 'ogc_client_config', function ( $cfg, $key ) {
	if ( 'register' === $key ) {
		$cfg['recordKinds'] = array( 'signups', 'teams' );
		$cfg['recordYears'] = 1;
		$cfg['preload']     = ogc_reg_preload();
	}
	return $cfg;
}, 10, 2 );

/**
 * The page's first answers, inlined (polish 1: four requests one after another took about 4 s before
 * anything drew): the years, the year's files, this person's shifts and teams, the form, and their own
 * registrations. Each is the REST route's own answer, run as this viewer, so nobody gets more than the
 * route would give them. A signed-in page is never cached (ogc_render_page); a visitor's may be, so
 * the scripts use it only while it's under 10 minutes old.
 */
function ogc_reg_preload() {
	$get  = wp_unslash( $_GET ); // phpcs:ignore WordPress.Security.NonceVerification -- a read.
	$y    = isset( $get['year'] ) && preg_match( '/^\d{4}$/', (string) $get['year'] ) ? (int) $get['year'] : 0;
	if ( ! $y || ! ogc_year_get( $y ) || ! empty( $get['approve'] ) || ! empty( $get['checkout'] ) ) {
		return null;
	}
	$asof = isset( $get['as-of'] ) && preg_match( '/^\d{4}-\d\d-\d\d/', (string) $get['as-of'] ) ? substr( (string) $get['as-of'], 0, 10 ) : '';
	$call = function ( $route, $params = array() ) {
		$r = new WP_REST_Request( 'GET', '/' . OGC_NS . $route );
		foreach ( $params as $k => $v ) {
			$r->set_param( $k, $v );
		}
		$res = rest_do_request( $r );
		return $res->is_error() ? null : rest_get_server()->response_to_data( $res, false );
	};
	$q   = $asof ? array( 'as_of' => $asof ) : array();
	$out = array(
		'at'      => time(),
		'years'   => $call( '/years' ),
		'bundle'  => array( $y => $call( '/years/' . $y . '/bundle' ) ),
		// Only this person's own shifts and teams (review, Oct 11: it inlined every public sign-up, and a
		// committee member's whole year).
		'records' => array( $y => $call( '/years/' . $y . '/records', array( 'kinds' => 'signups,teams', 'scope' => 'mine' ) ) ),
		'form'    => $call( '/reg/' . $y . '/form', $q ),
		'mine'    => is_user_logged_in() ? $call( '/reg/' . $y . '/mine', $q ) : null,
		'draft'   => is_user_logged_in() && empty( $get['view'] ) ? $call( '/reg/' . $y . '/draft' ) : null,
	);
	return $out;
}

/* ================================================================== who */

/** May the signed-in person see and change this registration? Its owner, a helper who manages it, or
 * those who enter and change households for its year (ogc_reg_enters). Never another committee's helper,
 * nor a webmaster for being one (decision 25, Oct 13: it was any member of the year). */
function ogc_reg_may( $rec ) {
	if ( ! $rec || 'registrations' !== $rec['kind'] ) {
		return false;
	}
	if ( ogc_reg_enters( $rec['year'] ) ) {
		return true;
	}
	$me = ogc_current_email();
	return '' !== $me && ( $rec['email'] === $me || in_array( $me, (array) ( isset( $rec['data']['managers'] ) ? $rec['data']['managers'] : array() ), true ) );
}

/** May the signed-in person enter households for the year (the desk, a paper form, a call) and open or
 * change any registration? The COA, Lodging and the committee the COA handed Registration
 * (module-guard.php ogc_access 'households'). */
function ogc_reg_enters( $year ) {
	return function_exists( 'ogc_access' ) ? ogc_access( (int) $year, 'households' ) : ogc_is_member( $year );
}

/** Only the owner or a helper (not a member acting for the committee). */
function ogc_reg_is_household( $rec ) {
	$me = ogc_current_email();
	return '' !== $me && ( $rec['email'] === $me || in_array( $me, (array) ( isset( $rec['data']['managers'] ) ? $rec['data']['managers'] : array() ), true ) );
}

/** The registrations this email owns or manages for a year. */
function ogc_reg_mine( $year, $email ) {
	$out = array();
	if ( '' === $email ) {
		return $out;
	}
	foreach ( ogc_records( (int) $year, 'registrations' ) as $r ) {
		if ( $r['email'] === $email || in_array( $email, (array) ( isset( $r['data']['managers'] ) ? $r['data']['managers'] : array() ), true ) ) {
			$out[] = $r;
		}
	}
	return $out;
}

/** May this member see children's medical notes, emergency contacts and who may pick a child up? The
 * COA and the Preteens committee (module-guard.php ogc_access 'children'). Not webmasters, not even
 * seeing as Preteens, and no longer anyone the COA named before the app (the year's preteen_viewers list
 * is kept but not read): decision 25, Oct 13. */
function ogc_reg_sensitive_viewer( $year ) {
	$me = ogc_current_email();
	if ( ! $me || ! ogc_is_member( $year ) ) {
		return false;
	}
	$ok = function_exists( 'ogc_access' ) ? ogc_access( (int) $year, 'children' ) : false;
	return (bool) apply_filters( 'ogc_reg_sensitive_viewer', $ok, (int) $year, $me );
}

/** A registration's data without its children's details: each preteen's days and "withheld", each
 * emergency contact blank and "withheld", nobody named to pick up (the same shapes the generic records
 * route sends, so a page treats both alike). */
function ogc_reg_withhold_children( $d ) {
	foreach ( (array) ( isset( $d['preteens'] ) ? $d['preteens'] : array() ) as $pid => $pt ) {
		$d['preteens'][ $pid ] = array( 'days' => is_array( $pt ) && isset( $pt['days'] ) ? $pt['days'] : array(), 'withheld' => true );
	}
	if ( ! empty( $d['contacts'] ) ) {
		$d['contacts'] = array_map( function () { return array( 'name' => '', 'rel' => '', 'phone' => '', 'withheld' => true ); }, (array) $d['contacts'] );
	}
	foreach ( array( 'pickup', 'pickupWho', 'pickupOther' ) as $k ) {
		if ( isset( $d[ $k ] ) ) {
			$d[ $k ] = is_array( $d[ $k ] ) ? array() : '';
		}
	}
	return $d;
}

/**
 * May the signed-in person see and change this registration's children's details (medical notes,
 * emergency contacts, who may pick up)? The household and its helper; the COA and Preteens (ogc_access
 * 'children'); and whoever entered it at the desk, on paper or by phone, the same day only, so what they
 * typed can be read back and corrected (critique, Oct 14). After that, Preteens or the COA change them.
 */
function ogc_reg_children_ok( $rec ) {
	if ( ogc_reg_is_household( $rec ) || ( function_exists( 'ogc_access' ) && ogc_access( (int) $rec['year'], 'children' ) ) ) {
		return true;
	}
	$d  = (array) $rec['data'];
	$me = ogc_current_email();
	return '' !== $me && ! empty( $d['entered_by'] ) && $d['entered_by'] === $me && ! empty( $d['at'] ) && $d['at'] === ogc_reg_today( (int) $rec['year'] ) && ogc_reg_enters( (int) $rec['year'] );
}

/**
 * The children's details a change tries to set that the person can't see: a medical note, a contact or a
 * pick-up name typed in (a blank or "withheld" is what they were shown, so it's no change). Returns the
 * field names as the form names them ("preteens.p2.medical", "contacts.0.phone", "pickupWho"); the days
 * a preteen comes aren't
 * withheld, so they're never in it.
 */
function ogc_reg_children_touched( $old, $in ) {
	$out = array();
	$opt = isset( $old['preteens'] ) ? (array) $old['preteens'] : array();
	foreach ( isset( $in['preteens'] ) && is_array( $in['preteens'] ) ? $in['preteens'] : array() as $pid => $pt ) {
		if ( ! is_array( $pt ) || ! empty( $pt['withheld'] ) ) {
			continue;
		}
		$was = isset( $opt[ $pid ]['medical'] ) ? trim( (string) $opt[ $pid ]['medical'] ) : '';
		$now = isset( $pt['medical'] ) && is_scalar( $pt['medical'] ) ? trim( (string) $pt['medical'] ) : '';
		if ( '' !== $now && $now !== $was ) {
			$out[] = 'preteens.' . $pid . '.medical';
		}
	}
	$oc = isset( $old['contacts'] ) ? array_values( (array) $old['contacts'] ) : array();
	foreach ( isset( $in['contacts'] ) && is_array( $in['contacts'] ) ? array_values( $in['contacts'] ) : array() as $j => $c ) {
		if ( ! is_array( $c ) || ! empty( $c['withheld'] ) ) {
			continue;
		}
		foreach ( array( 'name', 'rel', 'phone' ) as $f ) {
			$now = isset( $c[ $f ] ) && is_scalar( $c[ $f ] ) ? trim( (string) $c[ $f ] ) : '';
			$was = isset( $oc[ $j ][ $f ] ) ? trim( (string) $oc[ $j ][ $f ] ) : '';
			if ( '' !== $now && $now !== $was ) {
				$out[] = 'contacts.' . $j . '.' . $f;
			}
		}
	}
	$who = isset( $in['pickupWho'] ) && is_array( $in['pickupWho'] ) ? array_values( array_filter( array_map( 'strval', array_filter( $in['pickupWho'], 'is_scalar' ) ), 'strlen' ) ) : array();
	$was = isset( $old['pickupWho'] ) ? array_values( (array) $old['pickupWho'] ) : array();
	if ( $who && $who !== $was ) {
		$out[] = 'pickupWho';
	}
	$oth = isset( $in['pickupOther'] ) && is_scalar( $in['pickupOther'] ) ? trim( (string) $in['pickupOther'] ) : '';
	if ( '' !== $oth && $oth !== trim( (string) ( isset( $old['pickupOther'] ) ? $old['pickupOther'] : '' ) ) ) {
		$out[] = 'pickupOther';
	}
	return $out;
}

/** A change from someone who can't see the children's details: those stay as they were; each preteen's
 * days come from the change (Lodging may move a child's days). */
function ogc_reg_children_keep( $old, $in ) {
	$opt = isset( $old['preteens'] ) ? (array) $old['preteens'] : array();
	if ( isset( $in['preteens'] ) && is_array( $in['preteens'] ) ) {
		foreach ( $in['preteens'] as $pid => $pt ) {
			$in['preteens'][ $pid ] = array(
				'medical' => isset( $opt[ $pid ]['medical'] ) ? $opt[ $pid ]['medical'] : '',
				'days'    => is_array( $pt ) && isset( $pt['days'] ) && is_array( $pt['days'] ) ? $pt['days'] : ( isset( $opt[ $pid ]['days'] ) ? $opt[ $pid ]['days'] : array() ),
			);
		}
	}
	foreach ( array( 'contacts', 'pickup', 'pickupWho', 'pickupOther' ) as $k ) {
		if ( array_key_exists( $k, $old ) ) {
			$in[ $k ] = $old[ $k ];
		} else {
			unset( $in[ $k ] );
		}
	}
	return $in;
}

/* ================================================================== the record */

/** Fields only the server writes. A change from a page never touches them. */
function ogc_reg_server_keys() {
	return array( 'rid', 'id', 'status', 'price', 'money', 'paid', 'checkDue', 'checkGot', 'approval', 'managers', 'source', 'at', 'created', 'updated', 'history', 'flags', '_v', 'idem', 'sample', 'cancelled_at', 'creditAsk', 'unpaid', 'mailed', 'received', 'entered_by' );
}

/** The prices a registration was charged at (kept with it). */
function ogc_reg_price_keys() {
	return array( 'room_price', 'room_beds', 'charge', 'person_price_adult', 'person_price_child', 'person_price_baby', 'yf_charge', 'yf_price', 'linen_price', 'mattress_price', 'camper_price', 'camper_per', 'meals_free', 'meal_price_adult', 'meal_price_child', 'gift_for' );
}

/** The year's settings with a registration's own prices over them. */
function ogc_reg_cfg_for( $year, $data ) {
	$cfg = ogc_reg_cfg( $year );
	if ( ! empty( $data['price']['prices'] ) && is_array( $data['price']['prices'] ) ) {
		$cfg = array_merge( $cfg, $data['price']['prices'] );
	}
	return $cfg;
}

function ogc_reg_price_snapshot( $cfg ) {
	return array_intersect_key( $cfg, array_flip( ogc_reg_price_keys() ) );
}

/** The next registration number of the year (R-2027-0001…), never one in use. Call inside the lock. */
function ogc_reg_next_rid( $year ) {
	$s    = ogc_state_get( (int) $year, 'reg_seq' );
	$n    = $s ? (int) $s['value'] : 0;
	$used = array();
	foreach ( ogc_records( (int) $year, 'registrations' ) as $r ) {
		if ( ! empty( $r['data']['rid'] ) ) {
			$used[ $r['data']['rid'] ] = true;
		}
	}
	do {
		$n++;
		$rid = 'R-' . $year . '-' . str_pad( (string) $n, 4, '0', STR_PAD_LEFT );
	} while ( isset( $used[ $rid ] ) );
	ogc_state_put( (int) $year, 'reg_seq', $n );
	return $rid;
}

/**
 * One registration at a time per year (stock and numbers are checked and saved together). An option
 * row is the lock: adding it fails while another request holds it. Works on MySQL and SQLite alike.
 */
function ogc_reg_lock( $year ) {
	$key = 'ogc_reg_lock_' . (int) $year;
	for ( $i = 0; $i < 60; $i++ ) {
		if ( add_option( $key, time() + 20, '', 'no' ) ) {
			return true;
		}
		$t = (int) get_option( $key );
		if ( $t && $t < time() ) {
			delete_option( $key );
			continue;
		}
		usleep( 100000 );
	}
	return false;
}

function ogc_reg_unlock( $year ) {
	delete_option( 'ogc_reg_lock_' . (int) $year );
}

/** Sum the ledger into the record's money and status (and the v3 fields the committees' pages read). */
function ogc_reg_money_into( &$data, $record_id, $year = 0, $today = '' ) {
	$rows  = ogc_pay_rows( $record_id );
	$m     = ogc_pay_sum( $rows );
	// Past the date a check must arrive by (check_by), a check that hasn't come is no longer counted as
	// promised: what it was for is due at check-in (late_pay = checkin) or by card (late_pay = card).
	// The ledger row stays pending, so a check that does arrive is still marked received.
	if ( ! $year && preg_match( '/^R-(\d{4})-/', isset( $data['rid'] ) ? (string) $data['rid'] : '', $ym ) ) {
		$year = (int) $ym[1];
	}
	$late = 0;
	if ( $m['check'] > 0 && $year && ogc_reg_checks_closed( $year, $today ? $today : ogc_reg_today( $year, isset( $GLOBALS['ogc_reg_req'] ) ? $GLOBALS['ogc_reg_req'] : null ) ) ) {
		$late       = $m['check'];
		$m['check'] = 0;
	}
	$total = 'cancelled' === ( isset( $data['status'] ) ? $data['status'] : '' ) ? 0 : (int) ( isset( $data['price']['total_cents'] ) ? $data['price']['total_cents'] : 0 );
	if ( 'cancelled' === ( isset( $data['status'] ) ? $data['status'] : '' ) ) {
		// A cancelled registration keeps its gift (a gift isn't refunded), nothing else.
		$total = min( $m['paid'], (int) ( isset( $data['price']['gift_cents'] ) ? $data['price']['gift_cents'] : 0 ) );
	}
	$due              = max( 0, $total - $m['paid'] );
	$data['money']    = array(
		'total'   => $total,
		'paid'    => $m['paid'],
		'check'   => $m['check'],
		'pending' => $m['pending'],
		'refund'  => $m['refund'],
		'refunded' => $m['refunded'],
		'due'     => $due,
		// A check not received by check_by (cents): said as "Due at check-in", never "Check to come".
		'late'    => $late,
	);
	$data['paid']     = $m['paid'] / 100;
	$data['checkDue'] = $m['check'] ? $m['check'] / 100 : 0;
	$st               = isset( $data['status'] ) ? $data['status'] : '';
	if ( in_array( $st, array( 'cancelled', 'waitlist' ), true ) ) {
		return;
	}
	if ( $m['refund'] > 0 ) {
		$data['status'] = 'refund_due';
	} elseif ( $due <= 0 ) {
		$data['status'] = 'registered';
	} elseif ( $m['check'] >= $due ) {
		$data['status'] = 'check_to_come';
	} elseif ( $m['paid'] > 0 ) {
		$data['status'] = 'balance_due';
	} else {
		$data['status'] = 'payment_due';
	}
}

/** Save a registration's data (its version goes up), and its money from the ledger. */
function ogc_reg_save( $rec, $data ) {
	ogc_reg_money_into( $data, $rec['id'], (int) $rec['year'] );
	$data['_v']      = (int) ( isset( $data['_v'] ) ? $data['_v'] : 0 ) + 1;
	$data['updated'] = ogc_now();
	ogc_record_update( $rec['id'], $data, $rec['email'] );
	return ogc_record_get( $rec['id'] );
}

/** Work the money out again (after a payment is answered) and save. */
function ogc_reg_refresh( $record_id ) {
	$rec = ogc_record_get( $record_id );
	if ( ! $rec ) {
		return null;
	}
	return ogc_reg_save( $rec, $rec['data'] );
}

/** A line in the registration's history ("May 2 · Tuesday night removed · 1 room fewer"). */
function ogc_reg_note_history( &$data, $what, $by = '' ) {
	if ( ! $what ) {
		return;
	}
	$h    = isset( $data['history'] ) && is_array( $data['history'] ) ? $data['history'] : array();
	$who  = $by ? $by : ( ogc_reg_member_acting( $data ) ? 'committee' : 'household' );
	$line = array( 'at' => ogc_reg_hist_at(), 'what' => $what, 'by' => $who );
	// A member's act says who and how it came (Round 5; area-households-money H11): "Nathan K. · Phone".
	if ( 'committee' === $who && get_current_user_id() ) {
		$line['uid'] = get_current_user_id();
		$how         = isset( $GLOBALS['ogc_reg_how'] ) ? (string) $GLOBALS['ogc_reg_how'] : '';
		if ( in_array( $how, array( 'phone', 'paper', 'desk' ), true ) ) {
			$line['how'] = $how;
		}
	}
	$h[]             = $line;
	$data['history'] = array_slice( $h, -50 );
}

/**
 * When a History line happened: now, or (a local site and the shared prototype only) the day being
 * previewed, so a change made in the walk-through on May 5, 2027 reads "May 5", not today's date. An
 * app route that acts on a registration sets $GLOBALS['ogc_reg_hist_day'] to its own day.
 */
function ogc_reg_hist_at() {
	if ( ! empty( $GLOBALS['ogc_reg_hist_day'] ) && preg_match( '/^\d{4}-\d\d-\d\d$/', (string) $GLOBALS['ogc_reg_hist_day'] ) ) {
		return $GLOBALS['ogc_reg_hist_day'] . substr( ogc_now(), 10 );
	}
	$req = isset( $GLOBALS['ogc_reg_req'] ) ? $GLOBALS['ogc_reg_req'] : null;
	$as  = $req instanceof WP_REST_Request ? substr( (string) $req->get_param( 'as_of' ), 0, 10 ) : '';
	if ( preg_match( '/^\d{4}-\d\d-\d\d$/', $as ) && function_exists( 'ogc_reg_local' ) && ogc_reg_local() ) {
		return $as . substr( ogc_now(), 10 );
	}
	return ogc_now();
}

function ogc_reg_member_acting( $data ) {
	$me = ogc_current_email();
	if ( ! $me ) {
		return false;
	}
	$owner = strtolower( isset( $data['household']['email'] ) ? $data['household']['email'] : '' );
	return $me !== $owner && ! in_array( $me, (array) ( isset( $data['managers'] ) ? $data['managers'] : array() ), true );
}

/** What changed, in a few words ("Micah added · Tuesday night removed · Rooms 2 → 3"). */
function ogc_reg_diff( $a, $b ) {
	$out    = array();
	$names  = function ( $d ) { return wp_list_pluck( isset( $d['people'] ) ? (array) $d['people'] : array(), 'name' ); };
	$added  = array_diff( $names( $b ), $names( $a ) );
	$gone   = array_diff( $names( $a ), $names( $b ) );
	foreach ( $added as $n ) {
		$out[] = ogc_reg_first( $n ) . ' added';
	}
	foreach ( $gone as $n ) {
		$out[] = ogc_reg_first( $n ) . ' removed';
	}
	$sa = isset( $a['stay'] ) ? $a['stay'] : array();
	$sb = isset( $b['stay'] ) ? $b['stay'] : array();
	$TY = array( 'dorm' => 'Dorm room', 'camper' => 'Camper lot', 'elsewhere' => 'Off campus', 'yf' => 'Young Folks halls' );
	if ( ( isset( $sa['type'] ) ? $sa['type'] : '' ) !== $sb['type'] && isset( $sa['type'] ) ) {
		$out[] = ( isset( $TY[ $sa['type'] ] ) ? $TY[ $sa['type'] ] : $sa['type'] ) . ' → ' . $TY[ $sb['type'] ];
	}
	$na = isset( $sa['nights'] ) ? (array) $sa['nights'] : array();
	foreach ( array_diff( $na, $sb['nights'] ) as $n ) {
		$out[] = $n . ' night removed';
	}
	foreach ( array_diff( $sb['nights'], $na ) as $n ) {
		$out[] = $n . ' night added';
	}
	foreach ( array( 'rooms' => 'Rooms', 'linens' => 'Linen packets', 'mattresses' => 'Air mattresses', 'campers' => 'Campers' ) as $k => $label ) {
		$x = (int) ( isset( $sa[ $k ] ) ? $sa[ $k ] : 0 );
		$y = (int) ( isset( $sb[ $k ] ) ? $sb[ $k ] : 0 );
		if ( $x !== $y ) {
			$out[] = $label . ' ' . $x . ' → ' . $y;
		}
	}
	$pn = function ( $d ) { $o = array(); foreach ( isset( $d['people'] ) ? (array) $d['people'] : array() as $p ) { $o[ $p['name'] ] = implode( ',', (array) ( isset( $p['nights'] ) ? $p['nights'] : array() ) ); } return $o; };
	$pa = $pn( $a );
	foreach ( $pn( $b ) as $n => $v ) {
		if ( isset( $pa[ $n ] ) && $pa[ $n ] !== $v && ! in_array( ogc_reg_first( $n ) . ' added', $out, true ) ) {
			$out[] = ogc_reg_first( $n ) . '’s nights changed';
		}
	}
	$j = function ( $v ) { $v = (array) $v; ksort( $v ); return wp_json_encode( $v ); };
	if ( $j( isset( $a['meals']['off'] ) ? $a['meals']['off'] : array() ) . $j( isset( $a['meals']['who'] ) ? $a['meals']['who'] : array() ) !== $j( $b['meals']['off'] ) . $j( $b['meals']['who'] ) ) {
		$out[] = 'Meals changed';
	}
	// The need boxes, arriving, keys and the note: a change to only these is still a change (it was "No
	// changes", and nothing was saved).
	$need = function ( $s ) { return implode( ',', array_keys( array_filter( array_intersect_key( (array) $s, array_flip( array( 'ground', 'walker', 'nearW', 'nearM' ) ) ) ) ) ); };
	if ( $need( $sa ) !== $need( $sb ) ) {
		$out[] = 'Needs changed';
	}
	if ( ( isset( $sa['arrive'] ) ? $sa['arrive'] : '' ) !== ( isset( $sb['arrive'] ) ? $sb['arrive'] : '' ) ) {
		$out[] = 'Arriving changed';
	}
	if ( (array) ( isset( $sa['keys'] ) ? $sa['keys'] : array() ) !== (array) ( isset( $sb['keys'] ) ? $sb['keys'] : array() ) ) {
		$out[] = 'Keys changed';
	}
	if ( ( isset( $sa['needs'] ) ? $sa['needs'] : '' ) !== ( isset( $sb['needs'] ) ? $sb['needs'] : '' ) ) {
		$out[] = 'Note changed';
	}
	if ( ! empty( $a['keep_next_year'] ) !== ! empty( $b['keep_next_year'] ) ) {
		$out[] = ! empty( $b['keep_next_year'] ) ? 'Saved for next year' : 'Not saved for next year';
	}
	// Who's coming, beyond names and nights: kind, age, hall, rooming, communing, preteen.
	$pk = function ( $d ) { $o = array(); foreach ( isset( $d['people'] ) ? (array) $d['people'] : array() as $p ) { $o[ $p['name'] ] = wp_json_encode( array_intersect_key( (array) $p, array_flip( array( 'kind', 'age', 'yfHall', 'sleeps', 'rooming', 'communing', 'ptOff', 'linens' ) ) ) ); } return $o; };
	$ka = $pk( $a );
	foreach ( $pk( $b ) as $n => $v ) {
		if ( isset( $ka[ $n ] ) && $ka[ $n ] !== $v ) {
			$out[] = ogc_reg_first( $n ) . ' changed';
		}
	}
	if ( (int) ( isset( $a['gift'] ) ? $a['gift'] : 0 ) !== (int) $b['gift'] ) {
		$out[] = 'Gift ' . ogc_reg_money( (int) ( isset( $a['gift'] ) ? $a['gift'] : 0 ) * 100 ) . ' → ' . ogc_reg_money( (int) $b['gift'] * 100 );
	}
	if ( wp_json_encode( isset( $a['household'] ) ? $a['household'] : array() ) !== wp_json_encode( $b['household'] ) || wp_json_encode( isset( $a['helper'] ) ? $a['helper'] : array() ) !== wp_json_encode( $b['helper'] ) ) {
		$out[] = 'Contact changed';
	}
	if ( $j( isset( $a['preteens'] ) ? $a['preteens'] : array() ) . wp_json_encode( isset( $a['contacts'] ) ? $a['contacts'] : array() ) . ( isset( $a['pickup'] ) ? $a['pickup'] : '' ) !== $j( $b['preteens'] ) . wp_json_encode( $b['contacts'] ) . $b['pickup'] ) {
		$out[] = 'Preteen details changed';
	}
	return implode( ' · ', $out );
}

/** Removed Oct 13 (docs/26 decision 6, docs/25 rule 3): registrations are never compared by people's
 * names. Two households with a "Ruth Kinsey" are two households; Lodging reads its list and decides.
 * Kept as a function that finds nothing, for any caller not yet updated. */
function ogc_reg_dups( $year, $data, $except_id ) {
	return array();
}

/** The rooms Lodging has given this registration (once posted), or the ones it chose on the map. */
function ogc_reg_rooms_of( $rec ) {
	$cfg = ogc_reg_cfg( $rec['year'] );
	$d   = $rec['data'];
	if ( 'dorm' !== ( isset( $d['stay']['type'] ) ? $d['stay']['type'] : '' ) ) {
		return array();
	}
	$row     = ogc_year_get( $rec['year'] );
	$started = $row && ! empty( $row['start'] ) && ogc_reg_today( $rec['year'], isset( $GLOBALS['ogc_reg_req'] ) ? $GLOBALS['ogc_reg_req'] : null ) >= $row['start'];
	$posted  = ogc_reg_c( $cfg, 'rooms_posted' ) || 'households' === ogc_reg_c( $cfg, 'room_choice' ) || $started;
	if ( ! $posted ) {
		return array();
	}
	$s    = ogc_state_get( (int) $rec['year'], 'rooms' );
	$rid  = isset( $d['rid'] ) ? $d['rid'] : '';
	$mine = $s && is_array( $s['value'] ) && isset( $s['value'][ $rid ] ) ? (array) $s['value'][ $rid ] : array();
	if ( ! $mine && 'households' === ogc_reg_c( $cfg, 'room_choice' ) ) {
		$mine = (array) ( isset( $d['stay']['chosen'] ) ? $d['stay']['chosen'] : array() );
	}
	return array_values( array_filter( array_map( 'strval', $mine ) ) );
}

/**
 * Where a registration stands, for its own household's page (canonical, Oct 14: Your sign-ups' status
 * line): the records module's status and Money (module-records.php, one fixed list each, worked out
 * from the registration, Lodging's rooms and desk, the COA's Didn't come and the payment lines; never
 * typed), as of the day it's viewed, with the day the desk checked it in. null without that module.
 */
function ogc_reg_standing( $rec, $today ) {
	if ( ! function_exists( 'ogc_rec_status_of' ) || ! function_exists( 'ogc_rec_ctx' ) ) {
		return null;
	}
	$y    = (int) $rec['year'];
	$was  = isset( $GLOBALS['ogc_app_as_of'] ) ? $GLOBALS['ogc_app_as_of'] : null;
	$GLOBALS['ogc_app_as_of'] = $today;
	if ( 'GET' !== ( isset( $_SERVER['REQUEST_METHOD'] ) ? $_SERVER['REQUEST_METHOD'] : 'GET' ) ) {
		ogc_rec_forget( $y );   // a change in this request: read the ledger and Lodging again
	}
	$ctx = ogc_rec_ctx( $y );
	$st  = ogc_rec_status_of( $rec, $ctx );
	$m   = ogc_rec_money_of( $rec, $ctx );
	if ( null === $was ) {
		unset( $GLOBALS['ogc_app_as_of'] );
	} else {
		$GLOBALS['ogc_app_as_of'] = $was;
	}
	$rid = ogc_rec_rid( $rec );
	$at  = isset( $ctx['lod'][ 'hh:' . $rid ]['data']['checkin']['at'] ) ? (string) $ctx['lod'][ 'hh:' . $rid ]['data']['checkin']['at'] : '';
	if ( '' !== $at ) {
		try {
			$t  = new DateTime( $at, new DateTimeZone( 'UTC' ) );
			$at = $t->setTimezone( ogc_reg_tz( $y ) )->format( 'Y-m-d' );
		} catch ( Exception $e ) {
			$at = substr( $at, 0, 10 );
		}
	}
	$words = ogc_rec_statuses();
	return array(
		'status'       => $st,
		'status_words' => $words[ $st ],
		'money'        => $m['key'],
		'money_words'  => $m['words'],
		'total'        => $m['total'],
		'paid'         => $m['paid'],
		'balance'      => $m['balance'],
		'check'        => $m['check'],
		'late'         => $m['late'],
		'refund'       => $m['refund'],
		'refunded'     => $m['refunded'],
		'checked_in'   => in_array( $st, array( 'checked_in', 'checked_out' ), true ) ? $at : '',
	);
}

/** Has Lodging placed this household already? (a change after that is marked for Lodging) */
function ogc_reg_placed( $year, $rid ) {
	$s = ogc_state_get( (int) $year, 'rooms' );
	return $s && is_array( $s['value'] ) && ! empty( $s['value'][ $rid ] );
}

function ogc_reg_mask( $email ) {
	$at = strpos( (string) $email, '@' );
	return false === $at ? '' : substr( $email, 0, 1 ) . '•••' . substr( $email, $at );
}

/** A registration as its household (or a member) sees it on Your sign-ups. */
function ogc_reg_view( $rec, $today = '' ) {
	$d     = $rec['data'];
	$year  = (int) $rec['year'];
	$cfg   = ogc_reg_cfg( $year );
	$today = $today ? $today : ogc_reg_today( $year, isset( $GLOBALS['ogc_reg_req'] ) ? $GLOBALS['ogc_reg_req'] : null );
	$row   = ogc_year_get( $year );
	$start = $row && ! empty( $row['start'] ) ? $row['start'] : '';
	$end   = $row && ! empty( $row['end'] ) ? $row['end'] : '';
	$phase = ogc_reg_phase( $year, $today );
	// The money as of the day viewed (a check past check_by is due at check-in), without saving.
	if ( ! empty( $d['money'] ) && ( ! empty( $d['money']['check'] ) || ! empty( $d['money']['late'] ) ) ) {
		ogc_reg_money_into( $d, $rec['id'], $year, $today );
	}
	$st    = isset( $d['status'] ) ? $d['status'] : '';
	$ap    = isset( $d['approval'] ) && is_array( $d['approval'] ) ? $d['approval'] : null;
	$clean = $d;
	unset( $clean['idem'] );
	// Children's details (medical notes, emergency contacts, who may pick up) to the household and those
	// who see them (the COA, Preteens). Anyone else entering households (Lodging at the desk) sees that
	// there are some, not what they say; the change route keeps them as they were (decision 25).
	if ( ! ogc_reg_children_ok( $rec ) ) {
		$clean = ogc_reg_withhold_children( $clean );
	}
	unset( $clean['entered_by'] );
	if ( $ap ) {
		// The parent's address in full: the household typed it (a typo must be visible to fix), and the
		// registration's own data already holds it. held: not sent yet (a card payment still open).
		$clean['approval'] = array( 'state' => $ap['state'], 'to' => isset( $ap['to'] ) ? $ap['to'] : '', 'sent_at' => isset( $ap['sent_at'] ) ? $ap['sent_at'] : '', 'at' => isset( $ap['at'] ) ? $ap['at'] : '', 'held' => ! empty( $ap['held'] ) );
	}
	$live   = ! in_array( $st, array( 'cancelled' ), true ) && 'held' !== $phase;
	$during = $start && $today >= $start && $today <= $end;
	return array(
		'id'      => $rec['id'],
		'rid'     => isset( $d['rid'] ) ? $d['rid'] : '',
		'year'    => $year,
		'sample'  => $rec['sample'],
		'data'    => $clean,
		// Each payment line: the household's own, and Handles money (decision 25); others see the totals.
		'ledger'  => ogc_reg_is_household( $rec ) || ( function_exists( 'ogc_access' ) && ogc_access( $year, 'money' ) ) ? array_map( 'ogc_pay_public', ogc_pay_rows( $rec['id'] ) ) : array(),
		'rooms'   => ogc_reg_rooms_of( $rec ),
		// Its status and Money in the records' own words (canonical, Oct 14: Your sign-ups' status line).
		'standing' => ogc_reg_standing( $rec, $today ),
		'can'     => array(
			'change' => $live && ( 'open' === $phase || 'before' === $phase || ogc_reg_enters( $year ) || 'closed' === $phase ),
			'all'    => 'open' === $phase || 'before' === $phase || ogc_reg_enters( $year ),
			'cancel' => $live && ! $during && ( ! $start || $today < $start ),
			'leave'  => $live && $during && in_array( isset( $d['stay']['type'] ) ? $d['stay']['type'] : '', array( 'dorm', 'camper', 'yf' ), true ),
			'pay'    => $live && ! empty( $d['money']['due'] ) && $d['money']['check'] < $d['money']['due'] && ! ( $ap && 'waiting' === $ap['state'] && 'yes' === ogc_reg_c( $cfg, 'approval_before_pay' ) ),
			'card'   => (bool) ogc_pay_driver(),
			'check'  => ! ogc_reg_checks_closed( $year, $today ),
			'refund' => ! ogc_reg_c( $cfg, 'refunds_by' ) || $today <= ogc_reg_c( $cfg, 'refunds_by' ),
		),
		'phase'   => $phase,
	);
}

/* ================================================================== a parent's approval */

/** Start (or start again) a parent's approval: a new link, emailed. Returns the token for the email only. */
function ogc_reg_approval_start( &$data, $year ) {
	$token            = $year . '.' . strtolower( wp_generate_password( 32, false, false ) );
	$data['approval'] = array(
		'state'     => 'waiting',
		'to'        => $data['stay']['parentEmail'],
		'sent_at'   => ogc_now(),
		'at'        => '',
		'hash'      => hash( 'sha256', $token ),
		'reminders' => 0,
	);
	return $token;
}

/** A parent's approval held back while a card payment is open (polish 3: the parent was asked before
 * the card was answered, so the email said "Due" while the receipt said "Paid", and an abandoned card
 * still asked a parent). Sent now: a new link, emailed. Returns the record. */
function ogc_reg_approval_release( $rec ) {
	$ap = isset( $rec['data']['approval'] ) ? $rec['data']['approval'] : null;
	if ( ! $ap || empty( $ap['held'] ) || 'waiting' !== $ap['state'] || 'cancelled' === $rec['data']['status'] ) {
		return $rec;
	}
	$data  = $rec['data'];
	$token = ogc_reg_approval_start( $data, $rec['year'] );
	$rec   = ogc_reg_save( $rec, $data );
	ogc_reg_mail_parent( $rec, $token );
	return $rec;
}

/** The registration a parent's link belongs to. */
function ogc_reg_by_approval( $token ) {
	if ( ! preg_match( '/^(\d{4})\.[a-z0-9]{32}$/', (string) $token, $m ) ) {
		return null;
	}
	$h = hash( 'sha256', $token );
	foreach ( ogc_records( (int) $m[1], 'registrations' ) as $r ) {
		if ( ! empty( $r['data']['approval']['hash'] ) && hash_equals( $r['data']['approval']['hash'], $h ) ) {
			return $r;
		}
	}
	return null;
}

/** Does this registration need a parent's approval by email? A Young Folk under 18 with no adult along,
 * or one in the halls whose grown-up registering chose "Ask a parent" (a grandmother, an aunt). */
function ogc_reg_needs_approval( $data ) {
	return (bool) ogc_reg_approval_people( $data );
}

/** The people a parent's approval is for: everyone, when Young Folks come alone with a minor among them;
 * else the Young Folks under 18 in the halls, when the household asked a parent. */
function ogc_reg_approval_people( $data ) {
	$people = isset( $data['people'] ) ? (array) $data['people'] : array();
	$adults = array_filter( $people, function ( $p ) { return 'adult' === $p['kind']; } );
	if ( ! $adults ) {
		return array_filter( $people, function ( $p ) { return ! empty( $p['minor'] ); } ) ? array_values( $people ) : array();
	}
	if ( empty( $data['stay']['ask'] ) ) {
		return array();
	}
	return array_values( array_filter( $people, function ( $p ) use ( $data ) { return ! empty( $p['minor'] ) && ogc_reg_in_hall( $p, $data ); } ) );
}

/* ================================================================== the committees' pages (generic record routes) */

// Registrations are made and changed through the /reg routes, which check prices and stock. Through the
// generic record routes (the last word, after the signin area's anonymous and helper rules at 20), only
// a year's members may change one (Lodging, the treasurer), never create or remove one, and never its
// money or status (ogc_record_validate below).
add_filter( 'ogc_record_can_write', function ( $allowed, $action, $kind, $year ) {
	// Through the generic route only the COA (or who it handed Registration): a committee helper is a
	// member of the year but not of every household (review, Oct 11).
	if ( 'registrations' === $kind ) {
		return ogc_records_all_ok( $year, $kind ) && 'update' === $action;
	}
	if ( 'credits' === $kind ) {
		return ogc_records_all_ok( $year, $kind );
	}
	return $allowed;
}, 30, 4 );

add_filter( 'ogc_record_validate', function ( $data, $kind, $year, $existing, $req ) {
	if ( 'registrations' !== $kind || ! $existing || is_wp_error( $data ) ) {
		return $data;
	}
	$old = $existing['data'];
	// What this member couldn't see (children's medical notes, emergency contacts) stays as it was.
	if ( isset( $data['contacts'] ) && is_array( $data['contacts'] ) && array_filter( $data['contacts'], function ( $c ) { return is_array( $c ) && ! empty( $c['withheld'] ); } ) ) {
		$data['contacts'] = isset( $old['contacts'] ) ? $old['contacts'] : array();
	}
	if ( isset( $data['preteens'] ) && is_array( $data['preteens'] ) ) {
		foreach ( $data['preteens'] as $pid => $pt ) {
			if ( is_array( $pt ) && ! empty( $pt['withheld'] ) ) {
				// The medical note as it was; the days as sent (they're never withheld).
				$was                      = isset( $old['preteens'][ $pid ] ) ? (array) $old['preteens'][ $pid ] : array();
				$data['preteens'][ $pid ] = array_merge( $was, isset( $pt['days'] ) && is_array( $pt['days'] ) ? array( 'days' => $pt['days'] ) : array() );
			}
		}
	}
	// The answers as cleaned; the server's own fields as they were.
	$new = ogc_reg_clean( array_merge( $old, (array) $data ), $year );
	foreach ( $data as $k => $v ) {
		if ( ! array_key_exists( $k, $new ) && ! in_array( $k, ogc_reg_server_keys(), true ) && preg_match( '/^[a-z][A-Za-z0-9_]{0,31}$/', $k ) ) {
			$new[ $k ] = $v;   // a committee's own note on the household (Lodging's tags…)
		}
	}
	foreach ( ogc_reg_server_keys() as $k ) {
		if ( array_key_exists( $k, $old ) ) {
			$new[ $k ] = $old[ $k ];
		} else {
			unset( $new[ $k ] );
		}
	}
	// Whose registration it is stays theirs: a committee's change never moves the household's or the
	// helper's email (the record's owner); the household changes it through its own form.
	foreach ( array( 'household', 'helper' ) as $who ) {
		if ( isset( $old[ $who ]['email'] ) && isset( $new[ $who ] ) && is_array( $new[ $who ] ) ) {
			$new[ $who ]['email'] = $old[ $who ]['email'];
		}
	}
	// The treasurer's "Check received" (the lists' Payments view): the checks to come are paid.
	if ( ! empty( $data['checkGot'] ) && empty( $old['checkGot'] ) ) {
		foreach ( ogc_pay_rows( $existing['id'] ) as $p ) {
			if ( 'check' === $p['kind'] && 'pending' === $p['status'] ) {
				ogc_pay_set( $p['id'], array( 'status' => 'paid', 'note' => 'Received' ) );
			}
		}
		$new['checkGot'] = ogc_reg_str( $data['checkGot'], 10 );
		ogc_reg_note_history( $new, 'Check received', 'committee' );
	}
	$diff = ogc_reg_diff( $old, $new );
	if ( $diff ) {
		ogc_reg_note_history( $new, $diff, 'committee' );
	}
	ogc_reg_money_into( $new, $existing['id'], (int) $existing['year'] );
	$new['_v']      = (int) ( isset( $old['_v'] ) ? $old['_v'] : 0 ) + 1;
	$new['updated'] = ogc_now();
	return $new;
}, 10, 5 );

// What a whole record shows: never an approval's token hash; children's medical notes and emergency
// contacts only to their household and the members named to see them (each such view is logged).
add_filter( 'ogc_record_whole', function ( $data, $rec ) {
	if ( 'registrations' !== $rec['kind'] || ! is_array( $data ) ) {
		return $data;
	}
	unset( $data['idem'], $data['entered_by'] );
	if ( isset( $data['approval']['hash'] ) ) {
		unset( $data['approval']['hash'] );
	}
	if ( ogc_reg_is_household( $rec ) ) {
		return $data;
	}
	if ( ogc_reg_sensitive_viewer( $rec['year'] ) ) {
		static $logged = array();
		if ( ! isset( $logged[ $rec['year'] ] ) && ( ! empty( (array) ( isset( $data['preteens'] ) ? $data['preteens'] : array() ) ) ) ) {
			$logged[ $rec['year'] ] = true;
			ogc_log( 'sensitive_view', $rec['year'], 'registrations', array( 'what' => 'preteens' ) );
		}
		return $data;
	}
	foreach ( (array) ( isset( $data['preteens'] ) ? $data['preteens'] : array() ) as $pid => $pt ) {
		$data['preteens'][ $pid ] = array( 'days' => isset( $pt['days'] ) ? $pt['days'] : array(), 'withheld' => true );
	}
	if ( ! empty( $data['contacts'] ) ) {
		$data['contacts'] = array_map( function () { return array( 'name' => '', 'rel' => '', 'phone' => '', 'withheld' => true ); }, (array) $data['contacts'] );
	}
	return $data;
}, 10, 2 );

/* ================================================================== one source for the dates */

// registration.csv's opens and closes and the year page's registration_opens / _closes are the same
// dates: whichever is changed, the other follows.
add_action( 'ogc_file_saved', function ( $year, $name ) {
	$GLOBALS['ogc_reg_cfg_stale'] = true;
	if ( ! empty( $GLOBALS['ogc_reg_syncing'] ) || ! in_array( $name, array( 'registration', 'settings' ), true ) ) {
		return;
	}
	$GLOBALS['ogc_reg_syncing'] = true;
	$r = ogc_reg_kv( $year, 'registration' );
	$s = ogc_reg_kv( $year, 'settings' );
	foreach ( array( 'opens', 'closes' ) as $k ) {
		if ( 'registration' === $name && isset( $r[ $k ] ) && '' !== $r[ $k ] && ( isset( $s[ 'registration_' . $k ] ) ? $s[ 'registration_' . $k ] : '' ) !== $r[ $k ] ) {
			ogc_file_patch( $year, 'settings', array( 'op' => 'key', 'key' => 'registration_' . $k, 'value' => $r[ $k ] ) );
		}
		if ( 'settings' === $name && ! empty( $s[ 'registration_' . $k ] ) && ( isset( $r[ $k ] ) ? $r[ $k ] : '' ) !== $s[ 'registration_' . $k ] ) {
			ogc_file_patch( $year, 'registration', array( 'op' => 'key', 'key' => $k, 'value' => $s[ 'registration_' . $k ] ) );
		}
	}
	unset( $GLOBALS['ogc_reg_syncing'] );
	$GLOBALS['ogc_reg_cfg_stale'] = true;
}, 10, 2 );

/* ================================================================== a payment answered */

add_action( 'ogc_payment_answered', function ( $p, $outcome ) {
	$rec = ogc_reg_refresh( $p['record_id'] );
	if ( $rec && 'paid' === $outcome ) {
		$data = $rec['data'];
		ogc_reg_note_history( $data, 'Paid ' . ogc_reg_money( $p['cents'] ) . ' by card', 'household' );
		// Paid in full by card after a check was late: the check isn't needed (never paid twice).
		if ( ! empty( $data['money']['late'] ) && empty( $data['money']['due'] ) ) {
			foreach ( ogc_pay_rows( $rec['id'] ) as $c ) {
				if ( 'check' === $c['kind'] && 'pending' === $c['status'] ) {
					ogc_pay_set( $c['id'], array( 'status' => 'cancelled', 'note' => 'Paid by card' ) );
				}
			}
		}
		$rec = ogc_reg_save( $rec, $data );
		ogc_reg_approval_release( $rec );
		ogc_reg_mail_receipt( $rec, 'paid' );
	} elseif ( $rec && empty( $rec['data']['money']['paid'] ) && empty( $rec['data']['mailed'] ) ) {
		// Card not paid (cancelled or declined) on a new registration: it's still registered, with
		// the payment due, and the household gets its confirmation saying so.
		$data           = $rec['data'];
		$data['mailed'] = 1;
		$rec            = ogc_reg_save( $rec, $data );
		ogc_reg_mail_receipt( $rec, 'new' );
	}
	// The card was answered, but not paid (cancelled, declined): a parent's approval held for it goes
	// now, so the parent hears whichever way the family pays (review, Oct 11: a Young Folk who cancelled
	// checkout was moved to the waitlist without the parent ever being asked).
	if ( $rec && 'paid' !== $outcome ) {
		ogc_reg_approval_release( ogc_reg_refresh( $rec['id'] ) );
	}
}, 10, 2 );

/* ================================================================== samples */

/** v3's sample household (no pid, no kind) in today's shape. */
function ogc_reg_from_v3( $h ) {
	$ages = array( 'baby' => '1', 'child' => '7' );
	foreach ( $h['people'] as $i => &$p ) {
		if ( empty( $p['kind'] ) ) {
			$p['kind'] = ! empty( $p['yf'] ) ? 'yf' : ( ! empty( $p['preteen'] ) || 'adult' !== ( isset( $p['band'] ) ? $p['band'] : 'adult' ) ? 'child' : 'adult' );
		}
		if ( ! isset( $p['age'] ) || '' === $p['age'] ) {
			$p['age'] = 'yf' === $p['kind'] ? ( ! empty( $p['minor'] ) ? '16' : '19' ) : ( ! empty( $p['preteen'] ) ? (string) ( 10 + $i % 4 ) : ( 'child' === $p['kind'] ? $ages[ isset( $p['band'] ) && 'baby' === $p['band'] ? 'baby' : 'child' ] : '' ) );
		}
		if ( empty( $p['pid'] ) ) {
			$p['pid'] = 'p' . substr( md5( ( isset( $h['id'] ) ? $h['id'] : '' ) . '|' . $i . '|' . $p['name'] ), 0, 8 );
		}
		$p['communing'] = 'adult' === $p['kind'] && $i < (int) ( isset( $h['communion'] ) ? $h['communion'] : 0 );
	}
	unset( $p );
	return $h;
}

/** After the seed loads a year: its sample households get today's shape, a price and a ledger. */
add_action( 'ogc_seed_year', function ( $year ) {
	global $wpdb;
	// Sample ledger rows of sample households the seed just replaced go with them.
	$wpdb->query( $wpdb->prepare( 'DELETE FROM ' . ogc_table( 'payments' ) . ' WHERE year = %d AND sample = 1 AND record_id NOT IN (SELECT id FROM ' . ogc_table( 'records' ) . ' WHERE year = %d)', $year, $year ) );
	$cfg   = ogc_reg_cfg( $year );
	$row   = ogc_year_get( $year );
	$over  = $row && ! empty( $row['end'] ) && ogc_reg_today( $year ) > $row['end'];
	foreach ( ogc_records( (int) $year, 'registrations' ) as $rec ) {
		if ( ! $rec['sample'] || ! empty( $rec['data']['price'] ) ) {
			continue;
		}
		$v3   = ogc_reg_from_v3( $rec['data'] );
		$data = ogc_reg_clean( $v3, $year );
		if ( empty( $v3['pay'] ) || 'check' !== $v3['pay'] ) {
			$data['pay'] = 'card';
		}
		$data['rid']     = $data['id'] = isset( $v3['id'] ) ? $v3['id'] : ogc_reg_next_rid( $year );
		$data['sample']  = true;
		$data['source']  = 'online';
		$data['at']      = isset( $v3['at'] ) ? $v3['at'] : '';
		$data['created'] = $data['at'] ? $data['at'] . ' 12:00:00' : ogc_now();
		$data['price']   = array_merge( ogc_reg_price( $data, $year ), array( 'prices' => ogc_reg_price_snapshot( $cfg ), 'at' => $data['at'] ) );
		$data['status']  = 'registered';
		$data['managers'] = array();
		$data['history'] = array();
		$total           = $data['price']['total_cents'];
		$at              = $data['created'];
		if ( $total > 0 ) {
			if ( 'check' === $data['pay'] && ! $over ) {
				ogc_pay_add( $rec, 'check', 'check', $total, 'pending', array( 'at' => $at ) );
			} else {
				ogc_pay_add( $rec, 'check' === $data['pay'] ? 'check' : 'charge', $data['pay'], $total, 'paid', array( 'at' => $at, 'driver' => 'check' === $data['pay'] ? '' : 'test', 'ref' => 'sample' ) );
			}
		}
		if ( ! empty( $v3['creditAsk']['amount'] ) ) {
			ogc_pay_add( $rec, 'refund', 'card', (int) round( $v3['creditAsk']['amount'] * 100 ), 'requested', array( 'at' => $v3['creditAsk']['at'] . ' 12:00:00', 'note' => 'Nights not used · ' . $v3['creditAsk']['nights'] ) );
			$data['creditAsk'] = $v3['creditAsk'];
		}
		ogc_reg_save( $rec, $data );
	}
	$s = ogc_state_get( (int) $year, 'reg_seq' );
	if ( ! $s ) {
		ogc_state_put( (int) $year, 'reg_seq', 0 );
	}
} );

/** Clear a year's sample households, their ledger and their credit asks. */
function ogc_reg_clear_samples( $year ) {
	$n = ogc_records_clear_samples( (int) $year, 'registrations' );
	ogc_records_clear_samples( (int) $year, 'credits' );
	ogc_pay_clear_samples( (int) $year );
	ogc_log( 'samples_clear', (int) $year, 'registrations', array( 'n' => $n ) );
	return $n;
}

/** Are there sample households in the year? (On ogbbc.org, registration doesn't open while there are.) */
function ogc_reg_has_samples( $year ) {
	global $wpdb;
	return (bool) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM ' . ogc_table( 'records' ) . " WHERE year = %d AND kind = 'registrations' AND sample = 1 AND deleted_at IS NULL", $year ) );
}

/* ================================================================== the daily round */

add_action( 'init', function () {
	if ( ! wp_next_scheduled( 'ogc_reg_daily' ) ) {
		wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', 'ogc_reg_daily' );
	}
} );

// Once a day: a parent's approval asked again after 3 and 7 days; the day's changes to the committee
// giving rooms (registration.csv lodging_email, a role address), none sent on a day with none.
add_action( 'ogc_reg_daily', function () {
	foreach ( ogc_years_list() as $y ) {
		$row = ogc_year_get( $y );
		if ( ! $row || empty( $row['end'] ) || ogc_reg_today( $y ) > $row['end'] ) {
			continue;
		}
		$changes = array();
		$waiting = array();
		// From a week before: the Young Folks under 18 still waiting for a parent are listed every day,
		// to be settled at check-in.
		$near = ! empty( $row['start'] ) && ogc_reg_today( $y ) >= ogc_reg_add_days( $row['start'], -7 );
		foreach ( ogc_records( $y, 'registrations' ) as $rec ) {
			if ( $rec['sample'] ) {
				continue;
			}
			$d  = $rec['data'];
			$ap = isset( $d['approval'] ) ? $d['approval'] : null;
			// A check not received by check_by: the money is worked out again (Due at check-in), and
			// Lodging's list says so once.
			if ( ! empty( $d['money']['check'] ) && ogc_reg_checks_closed( $y, ogc_reg_today( $y ) ) && 'cancelled' !== $d['status'] ) {
				$rec = ogc_reg_refresh( $rec['id'] );
				$d   = $rec['data'];
				if ( ! empty( $d['money']['late'] ) && empty( $d['flags']['lateCheck'] ) ) {
					$d['flags']              = isset( $d['flags'] ) ? (array) $d['flags'] : array();
					$d['flags']['lateCheck'] = ogc_reg_today( $y );
					$rec                     = ogc_reg_save( $rec, $d );
					$by                      = ogc_reg_c( ogc_reg_cfg( $y ), 'check_by' );
					$changes[]               = ( isset( $d['rid'] ) ? $d['rid'] : '' ) . ' · ' . ogc_reg_label( $d ) . ' · No check by ' . ogc_reg_mail_date( $by ) . ' · ' . ( 'card' === ogc_reg_c( ogc_reg_cfg( $y ), 'late_pay' ) ? 'Due ' : 'Due at check-in ' ) . ogc_reg_money( (int) $d['money']['due'] );
				}
			}
			if ( $ap && ! empty( $ap['held'] ) ) {
				$ap = null;   // not sent yet (a card payment still open): no reminder, not listed
			}
			if ( $near && $ap && 'waiting' === $ap['state'] && 'cancelled' !== $d['status'] ) {
				$waiting[] = ( isset( $d['rid'] ) ? $d['rid'] : '' ) . ' · ' . implode( ', ', array_map( 'ogc_reg_first', wp_list_pluck( ogc_reg_approval_people( $d ), 'name' ) ) ) . ' · Approval needed at check-in';
			}
			// A card registration never paid (the household left the provider's checkout): reminded on day
			// 2 and day 5, then, after the COA's unpaid_days (blank: never), moved to the waitlist so its
			// rooms, linens and beds are free again, and Lodging is told in this list.
			$rel = ogc_reg_unpaid_round( $rec );
			if ( $rel ) {
				$changes[] = $rel;
				$d         = ogc_record_get( $rec['id'] )['data'];
			}
			if ( $ap && 'waiting' === $ap['state'] && 'cancelled' !== $d['status'] ) {
				$days = ( time() - strtotime( $ap['sent_at'] . ' UTC' ) ) / DAY_IN_SECONDS;
				$n    = (int) $ap['reminders'];
				if ( ( 0 === $n && $days >= 3 ) || ( 1 === $n && $days >= 7 ) ) {
					$token                         = ogc_reg_approval_start( $d, $y );
					$d['approval']['reminders']    = $n + 1;
					$rec                           = ogc_reg_save( $rec, $d );
					ogc_reg_mail_parent( $rec, $token, true );
				}
			}
			foreach ( (array) ( isset( $d['history'] ) ? $d['history'] : array() ) as $h ) {
				if ( strtotime( $h['at'] . ' UTC' ) > time() - DAY_IN_SECONDS && 'household' === $h['by'] ) {
					$changes[] = ( isset( $d['rid'] ) ? $d['rid'] : '' ) . ' · ' . ogc_reg_label( $d ) . ' · ' . $h['what'];
				}
			}
		}
		$to = ogc_reg_c( ogc_reg_cfg( $y ), 'lodging_email' );
		if ( ( $changes || $waiting ) && is_email( $to ) ) {
			$subject = $y . ' registrations · ' . implode( ' · ', array_filter( array( $changes ? ogc_reg_plural( count( $changes ), 'change' ) : '', $waiting ? ogc_reg_plural( count( $waiting ), 'approval', 'approvals' ) . ' needed' : '' ) ) );
			ogc_reg_mail( $to, $subject, array_merge( $changes, $waiting ? array_merge( array( '', 'Parent approval needed at check-in' ), $waiting ) : array(), array( '', ogc_url( 'lodging', array( 'year' => $y ) ) ) ), 'weekly', $y );
		}
	}
} );

/** "Hoover household"; one person registering alone is named ("Caleb Yoder"), never "Yoder household · 1 person". */
function ogc_reg_label( $d ) {
	$ppl = isset( $d['people'] ) ? (array) $d['people'] : array();
	if ( 1 === count( $ppl ) && ! empty( $ppl[0]['name'] ) ) {
		return trim( $ppl[0]['name'] );
	}
	$n = isset( $d['household']['name'] ) ? trim( $d['household']['name'] ) : '';
	if ( '' === $n ) {
		$n = isset( $d['household']['contact'] ) ? $d['household']['contact'] : '';
	}
	return preg_match( '/(household|family)$/i', $n ) ? $n : $n . ' household';
}

/**
 * The daily round for one card registration still unpaid (Payment due, nothing paid, no check coming):
 * a reminder on day 2 and day 5 ("Pay $677 · Your sign-ups"); on day unpaid_days (registration.csv,
 * blank: never) it moves to the waitlist, freeing its rooms and beds, and the household is told.
 * Returns the line for Lodging's daily list when it moved, else ''.
 */
function ogc_reg_unpaid_round( $rec, $now = null ) {
	$d = $rec['data'];
	if ( $rec['sample'] || 'payment_due' !== ( isset( $d['status'] ) ? $d['status'] : '' ) || 'card' !== ( isset( $d['pay'] ) ? $d['pay'] : '' ) || ! empty( $d['money']['paid'] ) || ! empty( $d['money']['check'] ) ) {
		return '';
	}
	$now  = null === $now ? time() : (int) $now;
	$days = ( $now - strtotime( ( isset( $d['created'] ) ? $d['created'] : ogc_now() ) . ' UTC' ) ) / DAY_IN_SECONDS;
	$cfg  = ogc_reg_cfg( $rec['year'] );
	$max  = (int) ogc_reg_c( $cfg, 'unpaid_days' );
	$u    = isset( $d['unpaid'] ) && is_array( $d['unpaid'] ) ? $d['unpaid'] : array( 'reminders' => 0 );
	if ( $max > 0 && $days >= $max ) {
		$d['status'] = 'waitlist';
		$d['unpaid'] = array_merge( $u, array( 'released' => ogc_now() ) );
		ogc_reg_note_history( $d, 'Moved to the waitlist · Not paid in ' . ogc_reg_plural( $max, 'day' ), 'committee' );
		foreach ( ogc_pay_rows( $rec['id'] ) as $p ) {
			if ( 'charge' === $p['kind'] && 'pending' === $p['status'] ) {
				ogc_pay_set( $p['id'], array( 'status' => 'cancelled', 'note' => 'Not paid' ) );
			}
		}
		$rec = ogc_reg_save( $rec, $d );
		ogc_reg_mail_receipt( $rec, 'changed' );
		ogc_log( 'reg_unpaid_released', $rec['year'], 'registrations', array( 'id' => $rec['id'] ) );
		return ( isset( $d['rid'] ) ? $d['rid'] : '' ) . ' · ' . ogc_reg_label( $d ) . ' · Moved to the waitlist · Not paid';
	}
	$n = (int) $u['reminders'];
	if ( ( 0 === $n && $days >= 2 ) || ( 1 === $n && $days >= 5 ) ) {
		$d['unpaid'] = array_merge( $u, array( 'reminders' => $n + 1, 'at' => ogc_now() ) );
		$rec         = ogc_reg_save( $rec, $d );
		ogc_reg_mail_unpaid( $rec, $max > 0 ? ogc_reg_add_days( substr( $d['created'], 0, 10 ), $max ) : '' );
	}
	return '';
}

/** "Payment due": the amount, the day it moves to the waitlist (when the COA set one), Your sign-ups. */
function ogc_reg_mail_unpaid( $rec, $until ) {
	$d = $rec['data'];
	$y = (int) $rec['year'];
	$q = ogc_reg_c( ogc_reg_cfg( $y ), 'questions_email' );
	foreach ( ogc_reg_recipients( $rec ) as $to ) {
		$link = function_exists( 'ogc_mine_url' ) ? ogc_mine_url( $to, $y ) : ogc_reg_mine_url( $y );
		ogc_reg_mail_send( $to, array(
			'subject'   => $y . ' Annual Conference · Payment due · ' . $d['rid'],
			'preheader' => 'Pay ' . ogc_reg_money( (int) $d['money']['due'] ) . ' · ' . $d['rid'],
			'heading'   => 'Payment due',
			'lines'     => array_values( array_filter( array( 'Pay ' . ogc_reg_money( (int) $d['money']['due'] ) . ' · ' . $d['rid'], $until ? 'Held until ' . ogc_reg_mail_date( $until ) . ' · Then moved to the waitlist' : '' ) ) ),
			'button'    => array( 'Your sign-ups', $link ),
			'questions' => ogc_reg_questions_words( $y ),
			'reason'    => 'You registered, or made this registration for someone.',
		), array(), 'registration_changed', $y, is_email( $q ) ? $q : '' );
	}
}
