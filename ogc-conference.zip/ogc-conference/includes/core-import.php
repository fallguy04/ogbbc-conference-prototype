<?php
/**
 * The seed: seed/years.csv and seed/<year>/<name>.csv (made from v3 by tools/seed-from-v3.mjs), loaded
 * into the tables for any year that isn't there yet. Runs on activation and from the dev import route.
 *
 *   seed/years.csv                 every Conference; a year already in the table is left as it is
 *   seed/<year>/<name>.csv         a year's files, header as the pages' keys (including "_id", "_look")
 *   seed/<year>/state.json         state values: { "picked": … }
 *   seed/<year>/records/<kind>.json  sample records (a list of data objects), marked sample; the
 *                                  volunteer and register areas add theirs here
 * After a year is loaded, the action ogc_seed_year( $year ) runs, for an area that seeds in code.
 */

defined( 'ABSPATH' ) || exit;

function ogc_seed_dir() {
	return (string) apply_filters( 'ogc_seed_dir', OGC_DIR . 'seed/' );
}

/** Made-up people (sample households, volunteers, members, notes) only on a local dev site: never on
 * ogbbc.org or a staging copy. Every area's sample seeding asks this one question. */
function ogc_seed_samples() {
	return (bool) apply_filters( 'ogc_seed_samples', OGC_DEV && function_exists( 'ogc_is_local_host' ) && ogc_is_local_host() );
}

/** Does activating (or upgrading) the plugin load the seed by itself? Only where samples load (a local
 * dev site). On ogbbc.org activation makes the tables only; a webmaster loads the reviewed years once
 * (POST /seed, ogc_seed_route), and nothing in them is public until the COA publishes it. */
function ogc_seed_on_activate() {
	return (bool) apply_filters( 'ogc_seed_on_activate', ogc_seed_samples() );
}

/** A year still to come, loaded without samples: whatever the seed's settings had posted (the
 * walk-through's sign-ups, schedule, packet) waits for the COA's Publish. */
function ogc_seed_hold_back( $year, $rows ) {
	$row = ogc_year_get( (int) $year );
	if ( ogc_seed_samples() || ( $row && ! empty( $row['end'] ) && $row['end'] < wp_date( 'Y-m-d' ) ) ) {
		return $rows;
	}
	$not_yet = defined( 'OGC_NOT_YET' ) ? OGC_NOT_YET : '9999-12-31';
	foreach ( $rows as &$r ) {
		if ( isset( $r['key'] ) && preg_match( '/^(schedule|packet|signups|rooms|menus)_posted$/', (string) $r['key'] ) ) {
			$r['value'] = $not_yet;
		}
	}
	unset( $r );
	return $rows;
}

/**
 * Load the seed. $force: a year (or true for all) whose files, state and sample records are replaced
 * from the seed (people's own records are never touched). Returns what was loaded, by year.
 */
function ogc_import_seed( $force = false ) {
	global $wpdb;
	$dir = ogc_seed_dir();
	if ( ! is_dir( $dir ) ) {
		return array();
	}
	$done = array();
	// Years.
	if ( file_exists( $dir . 'years.csv' ) ) {
		foreach ( ogc_csv_read( file_get_contents( $dir . 'years.csv' ) ) as $r ) {
			if ( empty( $r['year'] ) || ! ogc_valid_year( $r['year'] ) ) {
				continue;
			}
			$y   = (int) $r['year'];
			$hit = ogc_year_get( $y );
			if ( null === $hit || true === $force || $y === (int) $force ) {
				$fields = $r;
				unset( $fields['year'] );
				if ( $hit ) {
					$wpdb->delete( ogc_table( 'years' ), array( 'year' => $y ), array( '%d' ) );
					ogc_store_forget();
				}
				ogc_year_set( $y, $fields );
			}
		}
	}
	// Each year's folder.
	foreach ( (array) glob( $dir . '[0-9][0-9][0-9][0-9]', GLOB_ONLYDIR ) as $ydir ) {
		$y     = (int) basename( $ydir );
		$again = true === $force || $y === (int) $force;
		$has   = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM ' . ogc_table( 'files' ) . ' WHERE year = %d', $y ) );
		if ( $has && ! $again ) {
			continue;
		}
		if ( $again ) {
			$wpdb->delete( ogc_table( 'files' ), array( 'year' => $y ), array( '%d' ) );
			$wpdb->delete( ogc_table( 'state' ), array( 'year' => $y ), array( '%d' ) );
			ogc_store_forget();
			ogc_records_clear_samples( $y );
		}
		$n = 0;
		foreach ( (array) glob( $ydir . '/*.csv' ) as $f ) {
			$name = basename( $f, '.csv' );
			if ( ! ogc_valid_name( $name ) ) {
				continue;
			}
			$cols = array();
			$bad  = array();
			$rows = ogc_csv_read( file_get_contents( $f ), $cols, $bad );
			if ( $bad ) {
				// Flagged, not loaded quietly cut short: the log and the PHP error log say which lines.
				ogc_log( 'import_problem', $y, $name, array( 'lines' => array_slice( $bad, 0, 20 ) ) );
				error_log( 'ogc-conference seed ' . $y . '/' . $name . '.csv: ' . implode( '; ', $bad ) ); // phpcs:ignore -- a seed file to fix.
			}
			if ( 'settings' === $name ) {
				$rows = ogc_seed_hold_back( $y, $rows );
			}
			ogc_file_put( $y, $name, $rows, 0, $cols );
			$n++;
		}
		if ( file_exists( $ydir . '/state.json' ) ) {
			foreach ( (array) ogc_unjson( file_get_contents( $ydir . '/state.json' ), array() ) as $k => $v ) {
				if ( null !== $v && preg_match( '/^[a-z0-9][a-z0-9_.:-]{0,63}$/', (string) $k ) ) {
					ogc_state_put( $y, (string) $k, $v );
				}
			}
		}
		$recs = 0;
		// Sample records (made-up households and teams) only on a local dev site.
		foreach ( ogc_seed_samples() ? (array) glob( $ydir . '/records/*.json' ) : array() as $f ) {
			$kind = basename( $f, '.json' );
			foreach ( (array) ogc_unjson( file_get_contents( $f ), array() ) as $data ) {
				if ( is_array( $data ) ) {
					ogc_record_insert( $y, $kind, $data, ogc_record_owner( $kind, $data, $y ), true, 'seed' );
					$recs++;
				}
			}
		}
		do_action( 'ogc_seed_year', $y );
		$done[ $y ] = array( 'files' => $n, 'records' => $recs );
		ogc_log( 'import', $y, 'seed', $done[ $y ] );
	}
	return $done;
}
