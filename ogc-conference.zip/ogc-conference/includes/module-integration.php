<?php
/**
 * Integration (Oct 11): small joins between areas, kept in one place so no area's file grows a
 * second owner. Each says what it joins and why.
 */

defined( 'ABSPATH' ) || exit;

// The signin area's Members page (/annual-conference/members/) is the app's Members screen now: one
// list of who's on the year, drawn one way (docs/23). Old links (invites, the year page) still land.
add_action( 'ogc_before_page', function ( $page ) {
	if ( 'members' !== $page ) {
		return;
	}
	// phpcs:disable WordPress.Security.NonceVerification -- only where to go.
	$year = isset( $_GET['year'] ) ? (int) $_GET['year'] : 0;
	$open = isset( $_GET['open'] ) ? (int) $_GET['open'] : 0;
	// phpcs:enable
	$to = ogc_url( 'app', array_filter( array( 'year' => ogc_valid_year( $year ) ? $year : null, 's' => 'members', 'id' => $open ? $open : null ) ) );
	if ( ! is_user_logged_in() ) {
		$to = add_query_arg( 'return', rawurlencode( wp_make_link_relative( $to ) ), ogc_url( 'signin' ) );
	}
	wp_safe_redirect( $to, 302 );
	exit;
}, 5 );
