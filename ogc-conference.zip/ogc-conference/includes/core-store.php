<?php
/**
 * The data layer: the years, each year's files (its parts, as rows), small state values, and the
 * records people make. The REST routes (core-rest.php) check who may do what; these functions don't.
 */

defined( 'ABSPATH' ) || exit;

/* ================================================================== years */

/** years.csv's columns, in its order. Other fields follow. */
function ogc_year_columns() {
	return array( 'year', 'start', 'end', 'venue', 'city', 'hosts', 'data', 'page', 'coa_announced', 'announced' );
}

/** Every year as years.csv has it: array( 'year' => '2027', 'start' => …, … ), newest first. */
function ogc_years_all() {
	global $wpdb;
	$out = array();
	foreach ( (array) $wpdb->get_results( 'SELECT year, fields FROM ' . ogc_table( 'years' ) . ' ORDER BY year DESC', ARRAY_A ) as $r ) {
		$out[] = array_merge( array( 'year' => (string) $r['year'] ), (array) ogc_unjson( $r['fields'], array() ) );
	}
	return $out;
}

/** Just the year numbers, newest first. */
function ogc_years_list() {
	global $wpdb;
	return array_map( 'intval', (array) $wpdb->get_col( 'SELECT year FROM ' . ogc_table( 'years' ) . ' ORDER BY year DESC' ) );
}

/* A request's copies of what it has read (a year's row, its files, its state): each read once a
 * request; a write, or a write refused as stale, forgets it. The volunteer route read one state value
 * 154 times and the years row 77 times in one answer (review, Oct 11). */
function ogc_store_memo_get( $k ) {
	return isset( $GLOBALS['ogc_store_memo'] ) && array_key_exists( $k, $GLOBALS['ogc_store_memo'] ) ? array( $GLOBALS['ogc_store_memo'][ $k ] ) : null;
}
function ogc_store_memo_set( $k, $v ) {
	$GLOBALS['ogc_store_memo'][ $k ] = $v;
	return $v;
}
/** Forget the copies: one ('y|2027', 'f|2027|shifts', 's|2027|rooms'), or all of them. */
function ogc_store_forget( $k = null ) {
	if ( null === $k ) {
		$GLOBALS['ogc_store_memo'] = array();
	} else {
		unset( $GLOBALS['ogc_store_memo'][ $k ] );
	}
}

function ogc_year_get( $year ) {
	global $wpdb;
	$k = 'y|' . (int) $year;
	$m = ogc_store_memo_get( $k );
	if ( $m ) {
		return $m[0];
	}
	$f = $wpdb->get_var( $wpdb->prepare( 'SELECT fields FROM ' . ogc_table( 'years' ) . ' WHERE year = %d', $year ) );
	return ogc_store_memo_set( $k, null === $f ? null : array_merge( array( 'year' => (string) $year ), (array) ogc_unjson( $f, array() ) ) );
}

/** Set some of a year's fields (a null value removes one); makes the year if it's new. */
function ogc_year_set( $year, $fields ) {
	global $wpdb;
	ogc_store_forget( 'y|' . (int) $year );
	$cur = ogc_year_get( $year );
	$new = null === $cur ? array() : $cur;
	unset( $new['year'] );
	foreach ( (array) $fields as $k => $v ) {
		if ( 'year' === $k ) {
			continue;
		}
		if ( null === $v ) {
			unset( $new[ $k ] );
		} else {
			$new[ $k ] = (string) $v;
		}
	}
	if ( null === $cur ) {
		$wpdb->insert( ogc_table( 'years' ), array( 'year' => (int) $year, 'fields' => ogc_json( (object) $new ), 'updated_at' => ogc_now() ), array( '%d', '%s', '%s' ) );
	} else {
		$wpdb->update( ogc_table( 'years' ), array( 'fields' => ogc_json( (object) $new ), 'updated_at' => ogc_now() ), array( 'year' => (int) $year ), array( '%s', '%s' ), array( '%d' ) );
	}
	ogc_store_forget( 'y|' . (int) $year );
	return array_merge( array( 'year' => (string) $year ), $new );
}

/* ================================================================== files */

/** A year's file: array( rows, cols, version, updated_at, updated_by ), or null when there's none. */
function ogc_file_row_out( $r ) {
	return array(
		'rows'       => (array) ogc_unjson( $r['rows_json'], array() ),
		'cols'       => (array) ogc_unjson( $r['cols'], array() ),
		'version'    => (int) $r['version'],
		'updated_at' => $r['updated_at'],
		'updated_by' => (int) $r['updated_by'],
	);
}

function ogc_file_get( $year, $name ) {
	global $wpdb;
	$k = 'f|' . (int) $year . '|' . $name;
	$m = ogc_store_memo_get( $k );
	if ( $m ) {
		return $m[0];
	}
	$r = $wpdb->get_row( $wpdb->prepare( 'SELECT rows_json, cols, version, updated_at, updated_by FROM ' . ogc_table( 'files' ) . ' WHERE year = %d AND name = %s', $year, $name ), ARRAY_A );
	return ogc_store_memo_set( $k, $r ? ogc_file_row_out( $r ) : null );
}

/** The year's files: name → array( version, n (rows), updated_at ). One query, which also keeps each
 * file for this request (the bundle reads them all next). */
function ogc_file_list( $year ) {
	global $wpdb;
	$out = array();
	foreach ( (array) $wpdb->get_results( $wpdb->prepare( 'SELECT name, rows_json, cols, version, updated_at, updated_by FROM ' . ogc_table( 'files' ) . ' WHERE year = %d ORDER BY name', $year ), ARRAY_A ) as $r ) {
		$f                 = ogc_store_memo_set( 'f|' . (int) $year . '|' . $r['name'], ogc_file_row_out( $r ) );
		$out[ $r['name'] ] = array( 'version' => $f['version'], 'n' => count( $f['rows'] ), 'updated_at' => $f['updated_at'] );
	}
	return $out;
}

/** The columns of some rows: the ones given first, then every other key in the order first seen. */
function ogc_rows_cols( $rows, $cols = array() ) {
	$cols = array_values( array_map( 'strval', (array) $cols ) );
	foreach ( (array) $rows as $r ) {
		foreach ( array_keys( (array) $r ) as $k ) {
			if ( ! in_array( (string) $k, $cols, true ) ) {
				$cols[] = (string) $k;
			}
		}
	}
	return $cols;
}

/**
 * Replace a file's rows. $expect is the version the writer last saw (0 for a new file); when someone
 * else has changed it since, nothing is written and a 409 WP_Error comes back with the current
 * version. Returns the new version.
 */
function ogc_file_put( $year, $name, $rows, $expect, $cols = null ) {
	global $wpdb;
	$mk   = 'f|' . (int) $year . '|' . $name;
	ogc_store_forget( $mk );
	$cur  = ogc_file_get( $year, $name );
	ogc_store_forget( $mk );
	// An area may fill in its rows before they're kept (the volunteer area gives each shift a lasting uid).
	$rows = array_values( (array) apply_filters( 'ogc_file_rows', array_values( (array) $rows ), (int) $year, $name, $cur ) );
	$cols = ogc_rows_cols( $rows, null === $cols ? ( $cur ? $cur['cols'] : array() ) : $cols );
	$data = array(
		'rows_json'  => ogc_json( $rows ),
		'cols'       => ogc_json( $cols ),
		'updated_by' => get_current_user_id(),
		'updated_at' => ogc_now(),
	);
	if ( null === $cur ) {
		if ( (int) $expect !== 0 ) {
			return new WP_Error( 'ogc_conflict', 'Changed since it was opened.', array( 'status' => 409, 'version' => 0 ) );
		}
		$ok = $wpdb->insert( ogc_table( 'files' ), array_merge( array( 'year' => (int) $year, 'name' => $name, 'version' => 1 ), $data ), array( '%d', '%s', '%d', '%s', '%s', '%d', '%s' ) );
		if ( ! $ok ) {
			ogc_store_forget( $mk );
			$now = ogc_file_get( $year, $name );
			return new WP_Error( 'ogc_conflict', 'Changed since it was opened.', array( 'status' => 409, 'version' => $now ? $now['version'] : 0 ) );
		}
		return 1;
	}
	// Written only if the version is still the one the writer saw.
	$n = $wpdb->query( $wpdb->prepare(
		'UPDATE ' . ogc_table( 'files' ) . ' SET rows_json = %s, cols = %s, updated_by = %d, updated_at = %s, version = version + 1 WHERE year = %d AND name = %s AND version = %d',
		$data['rows_json'], $data['cols'], $data['updated_by'], $data['updated_at'], $year, $name, (int) $expect
	) );
	if ( 1 !== (int) $n ) {
		ogc_store_forget( $mk );
		$now = ogc_file_get( $year, $name );
		ogc_store_forget( $mk );
		return new WP_Error( 'ogc_conflict', 'Changed since it was opened.', array( 'status' => 409, 'version' => $now ? $now['version'] : 0 ) );
	}
	ogc_store_forget( $mk );
	return (int) $expect + 1;
}

/** Which column names a file's rows by (a saved row replaces the row with the same value). Matches
 * v3's ogc-local-edits.js; an area adds its own with the ogc_file_row_key filter. */
function ogc_file_row_key( $name ) {
	// Schedule rows by their lasting id: a one-row change (e2e's put-back) replaces its row, never adds a copy.
	$keys = apply_filters( 'ogc_file_row_keys', array( 'help' => 'need', 'places' => 'code', 'nearby' => 'name', 'schedule' => '_id' ) );
	return isset( $keys[ $name ] ) ? $keys[ $name ] : '';
}

/**
 * Change part of a file on the server's current copy, so two people changing different rows don't
 * collide (O.edits.saveRow / setKey):
 *   array( 'op' => 'row', 'row' => array(…) )      replace the row with the same key, or add it;
 *                                                    a row with "_gone" set is removed
 *   array( 'op' => 'key', 'key' => k, 'value' => v ) settings-style files: set one key's value
 * Returns the new version.
 */
function ogc_file_patch( $year, $name, $patch ) {
	for ( $try = 0; $try < 6; $try++ ) {
		$cur  = ogc_file_get( $year, $name );
		$rows = $cur ? $cur['rows'] : array();
		if ( 'key' === $patch['op'] ) {
			$hit = false;
			foreach ( $rows as &$r ) {
				if ( isset( $r['key'] ) && (string) $r['key'] === (string) $patch['key'] ) {
					$r['value'] = (string) $patch['value'];
					$hit        = true;
				}
			}
			unset( $r );
			if ( ! $hit ) {
				$rows[] = array( 'key' => (string) $patch['key'], 'value' => (string) $patch['value'], 'help' => '' );
			}
		} else {
			$row  = (array) $patch['row'];
			$k    = ogc_file_row_key( $name );
			$at   = -1;
			if ( $k && isset( $row[ $k ] ) ) {
				foreach ( $rows as $i => $r ) {
					if ( isset( $r[ $k ] ) && (string) $r[ $k ] === (string) $row[ $k ] ) {
						$at = $i;
						break;
					}
				}
			}
			$gone = ! empty( $row['_gone'] );
			unset( $row['_gone'] );
			if ( $at > -1 ) {
				if ( $gone ) {
					array_splice( $rows, $at, 1 );
				} else {
					$rows[ $at ] = array_merge( $rows[ $at ], $row );
				}
			} elseif ( ! $gone ) {
				$rows[] = $row;
			}
		}
		$v = ogc_file_put( $year, $name, $rows, $cur ? $cur['version'] : 0 );
		if ( ! is_wp_error( $v ) ) {
			return $v;
		}
	}
	return $v;
}

/* ================================================================== state */

function ogc_state_get( $year, $key ) {
	global $wpdb;
	$k = 's|' . (int) $year . '|' . $key;
	$m = ogc_store_memo_get( $k );
	if ( $m ) {
		return $m[0];
	}
	$r = $wpdb->get_row( $wpdb->prepare( 'SELECT value, version, updated_at FROM ' . ogc_table( 'state' ) . ' WHERE year = %d AND skey = %s', $year, $key ), ARRAY_A );
	return ogc_store_memo_set( $k, $r ? array( 'value' => ogc_unjson( $r['value'] ), 'version' => (int) $r['version'], 'updated_at' => $r['updated_at'] ) : null );
}

/** Set a state value. With $expect (the version last seen), a newer value isn't overwritten (409). */
function ogc_state_put( $year, $key, $value, $expect = null ) {
	global $wpdb;
	$mk   = 's|' . (int) $year . '|' . $key;
	ogc_store_forget( $mk );
	$cur  = ogc_state_get( $year, $key );
	ogc_store_forget( $mk );
	$json = ogc_json( $value );
	if ( null === $cur ) {
		if ( null !== $expect && (int) $expect !== 0 ) {
			return new WP_Error( 'ogc_conflict', 'Changed since it was opened.', array( 'status' => 409, 'version' => 0 ) );
		}
		$ok = $wpdb->insert( ogc_table( 'state' ), array( 'year' => (int) $year, 'skey' => $key, 'value' => $json, 'version' => 1, 'updated_by' => get_current_user_id(), 'updated_at' => ogc_now() ), array( '%d', '%s', '%s', '%d', '%d', '%s' ) );
		ogc_store_forget( $mk );
		return $ok ? 1 : new WP_Error( 'ogc_conflict', 'Changed since it was opened.', array( 'status' => 409 ) );
	}
	$want = null === $expect ? $cur['version'] : (int) $expect;
	$n    = $wpdb->query( $wpdb->prepare(
		'UPDATE ' . ogc_table( 'state' ) . ' SET value = %s, updated_by = %d, updated_at = %s, version = version + 1 WHERE year = %d AND skey = %s AND version = %d',
		$json, get_current_user_id(), ogc_now(), $year, $key, $want
	) );
	ogc_store_forget( $mk );
	if ( 1 !== (int) $n ) {
		$now = ogc_state_get( $year, $key );
		ogc_store_forget( $mk );
		return new WP_Error( 'ogc_conflict', 'Changed since it was opened.', array( 'status' => 409, 'version' => $now ? $now['version'] : 0 ) );
	}
	return $want + 1;
}

/* ================================================================== records */

/** The kinds of record the routes accept. An area adds its own with the ogc_record_kinds filter. */
function ogc_record_kinds() {
	return array_values( array_unique( (array) apply_filters( 'ogc_record_kinds', array( 'signups', 'registrations', 'credits', 'waits', 'teams' ) ) ) );
}

/** The email a record belongs to (lowercased): its "email", or its household's; an area says
 * otherwise for its kind with the ogc_record_email filter. */
function ogc_record_owner( $kind, $data, $year ) {
	$e = '';
	if ( isset( $data['email'] ) && is_string( $data['email'] ) ) {
		$e = $data['email'];
	} elseif ( isset( $data['household']['email'] ) && is_string( $data['household']['email'] ) ) {
		$e = $data['household']['email'];
	}
	$e = apply_filters( 'ogc_record_email', $e, $kind, $data, $year );
	return strtolower( trim( (string) $e ) );
}

/** A record row from the table, as the routes give it out (no deleted ones unless asked). */
function ogc_record_row( $r ) {
	return array(
		'id'         => (int) $r['id'],
		'year'       => (int) $r['year'],
		'kind'       => $r['kind'],
		'email'      => $r['email'],
		'data'       => ogc_unjson( $r['data'], array() ),
		'sample'     => (bool) (int) $r['sample'],
		'source'     => $r['source'],
		'created_at' => $r['created_at'],
		'updated_at' => $r['updated_at'],
		'deleted_at' => $r['deleted_at'],
	);
}

function ogc_record_get( $id, $with_deleted = false ) {
	global $wpdb;
	$r = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . ogc_table( 'records' ) . ' WHERE id = %d' . ( $with_deleted ? '' : ' AND deleted_at IS NULL' ), $id ), ARRAY_A );
	return $r ? ogc_record_row( $r ) : null;
}

/** A year's records of one kind; $email limits them to one person's. */
function ogc_records( $year, $kind, $email = null ) {
	global $wpdb;
	$sql = 'SELECT * FROM ' . ogc_table( 'records' ) . ' WHERE year = %d AND kind = %s AND deleted_at IS NULL';
	$arg = array( $year, $kind );
	if ( null !== $email ) {
		$sql  .= ' AND email = %s';
		$arg[] = strtolower( trim( $email ) );
	}
	$rows = $wpdb->get_results( $wpdb->prepare( $sql . ' ORDER BY id', $arg ), ARRAY_A );
	// Filter ogc_records: an area may leave some out (the app: a sample dated after today isn't true yet).
	return (array) apply_filters( 'ogc_records', array_map( 'ogc_record_row', (array) $rows ), (int) $year, $kind, $email );
}

function ogc_record_insert( $year, $kind, $data, $email, $sample = false, $source = 'web' ) {
	global $wpdb;
	$now = ogc_now();
	$ok  = $wpdb->insert(
		ogc_table( 'records' ),
		array(
			'year'       => (int) $year,
			'kind'       => $kind,
			'email'      => strtolower( trim( (string) $email ) ),
			'data'       => ogc_json( $data ),
			'sample'     => $sample ? 1 : 0,
			'source'     => substr( (string) $source, 0, 32 ),
			'created_at' => $now,
			'updated_at' => $now,
		),
		array( '%d', '%s', '%s', '%s', '%d', '%s', '%s', '%s' )
	);
	return $ok ? (int) $wpdb->insert_id : 0;
}

function ogc_record_update( $id, $data, $email ) {
	global $wpdb;
	return false !== $wpdb->update(
		ogc_table( 'records' ),
		array( 'data' => ogc_json( $data ), 'email' => strtolower( trim( (string) $email ) ), 'updated_at' => ogc_now() ),
		array( 'id' => (int) $id ),
		array( '%s', '%s', '%s' ),
		array( '%d' )
	);
}

/** Removed, not erased: deleted_at is set (cleared for good with the rest of a year's names). */
function ogc_record_delete( $id ) {
	global $wpdb;
	return false !== $wpdb->update( ogc_table( 'records' ), array( 'deleted_at' => ogc_now() ), array( 'id' => (int) $id ), array( '%s' ), array( '%d' ) );
}

/** Erase a year's sample records (made-up people), of one kind or all. Returns how many. */
function ogc_records_clear_samples( $year, $kind = null ) {
	global $wpdb;
	if ( $kind ) {
		return (int) $wpdb->query( $wpdb->prepare( 'DELETE FROM ' . ogc_table( 'records' ) . ' WHERE year = %d AND kind = %s AND sample = 1', $year, $kind ) );
	}
	return (int) $wpdb->query( $wpdb->prepare( 'DELETE FROM ' . ogc_table( 'records' ) . ' WHERE year = %d AND sample = 1', $year ) );
}
