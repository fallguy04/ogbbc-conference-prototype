<?php
/**
 * The REST routes, /wp-json/ogc/v1/… Every route has a real permission check; every change needs the
 * wp_rest nonce (WordPress refuses a cookie-signed-in change without it) and is logged. DEV.md lists
 * every route with who may use it.
 *
 * Areas shape the rules without editing this file, through filters:
 *   ogc_private_files    names only members may read (default: needs, notes)
 *   ogc_file_visible     withhold a file from the public (e.g. a schedule not yet published)
 *   ogc_file_rows_valid  check rows before they're saved (return WP_Error to refuse)
 *   ogc_years_public     what the public sees of years.csv
 *   ogc_record_kinds     the kinds of record
 *   ogc_record_validate  check and clean a record's data (return WP_Error to refuse)
 *   ogc_record_can_write who may create, change or remove a record
 *   ogc_record_public    the redacted view of a record that anyone may see (null: not shown)
 *   ogc_record_email     whose email a record belongs to
 * and the action ogc_record_saved (after a create, change or remove: emails and the like).
 */

defined( 'ABSPATH' ) || exit;

const OGC_NS = 'ogc/v1';

add_action( 'rest_api_init', 'ogc_rest_routes' );

function ogc_rest_routes() {
	$Y = '(?P<year>\d{4})';
	$N = '(?P<name>[a-z][a-z0-9_-]{0,47})';
	$K = '(?P<kind>[a-z][a-z0-9_-]{0,31})';

	register_rest_route( OGC_NS, '/years', array(
		array( 'methods' => 'GET', 'callback' => 'ogc_rest_years', 'permission_callback' => '__return_true' ),
	) );
	register_rest_route( OGC_NS, "/years/$Y", array(
		array( 'methods' => 'PATCH', 'callback' => 'ogc_rest_year_patch', 'permission_callback' => 'ogc_can_patch_year' ),
	) );
	register_rest_route( OGC_NS, "/years/$Y/files", array(
		array( 'methods' => 'GET', 'callback' => 'ogc_rest_file_list', 'permission_callback' => 'ogc_can_member' ),
	) );
	register_rest_route( OGC_NS, "/years/$Y/bundle", array(
		array( 'methods' => 'GET', 'callback' => 'ogc_rest_bundle', 'permission_callback' => 'ogc_can_read_bundle' ),
	) );
	register_rest_route( OGC_NS, "/years/$Y/files/$N", array(
		array( 'methods' => 'GET', 'callback' => 'ogc_rest_file_get', 'permission_callback' => 'ogc_can_read_file' ),
		array( 'methods' => 'PUT', 'callback' => 'ogc_rest_file_put', 'permission_callback' => 'ogc_can_member' ),
		array( 'methods' => 'PATCH', 'callback' => 'ogc_rest_file_patch', 'permission_callback' => 'ogc_can_member' ),
	) );
	register_rest_route( OGC_NS, "/years/$Y/state/(?P<key>[a-z0-9][a-z0-9_.:-]{0,63})", array(
		array( 'methods' => 'GET', 'callback' => 'ogc_rest_state_get', 'permission_callback' => 'ogc_can_member' ),
		array( 'methods' => 'PUT', 'callback' => 'ogc_rest_state_put', 'permission_callback' => 'ogc_can_member' ),
	) );
	register_rest_route( OGC_NS, "/years/$Y/records", array(
		array( 'methods' => 'GET', 'callback' => 'ogc_rest_records_bundle', 'permission_callback' => '__return_true' ),
	) );
	register_rest_route( OGC_NS, "/years/$Y/records/$K", array(
		array( 'methods' => 'GET', 'callback' => 'ogc_rest_records_get', 'permission_callback' => 'ogc_can_read_records' ),
		array( 'methods' => 'POST', 'callback' => 'ogc_rest_record_create', 'permission_callback' => 'ogc_can_create_record' ),
	) );
	register_rest_route( OGC_NS, '/records/(?P<id>\d+)', array(
		array( 'methods' => 'PUT', 'callback' => 'ogc_rest_record_update', 'permission_callback' => 'ogc_can_change_record' ),
		array( 'methods' => 'DELETE', 'callback' => 'ogc_rest_record_delete', 'permission_callback' => 'ogc_can_change_record' ),
	) );
	register_rest_route( OGC_NS, "/years/$Y/samples", array(
		array( 'methods' => 'DELETE', 'callback' => 'ogc_rest_samples_clear', 'permission_callback' => 'ogc_can_webmaster' ),
	) );
	register_rest_route( OGC_NS, '/log', array(
		array( 'methods' => 'GET', 'callback' => 'ogc_rest_log', 'permission_callback' => 'ogc_can_read_log' ),
	) );
}

/* ------------------------------------------------------------------ permissions */

function ogc_rest_denied( $msg = 'Not allowed.' ) {
	return new WP_Error( 'ogc_forbidden', $msg, array( 'status' => is_user_logged_in() ? 403 : 401 ) );
}

function ogc_can_member( WP_REST_Request $req ) {
	return ogc_is_member( $req['year'] ) ? true : ogc_rest_denied();
}

function ogc_can_webmaster( WP_REST_Request $req ) {
	return ogc_is_webmaster() ? true : ogc_rest_denied();
}

/** A year's fields: its members change them; only a webmaster starts a new year. */
function ogc_can_patch_year( WP_REST_Request $req ) {
	if ( null === ogc_year_get( (int) $req['year'] ) ) {
		return ogc_is_webmaster() ? true : ogc_rest_denied();
	}
	if ( ! ogc_is_member( $req['year'] ) ) {
		return ogc_rest_denied();
	}
	// An existing year's row is the public Conference (its dates, place, hosts, announced): the COA's
	// and the webmasters', or a committee handed the Conference's dates. Never any helper of the year.
	$dates = array( 'start', 'end', 'venue', 'city', 'hosts', 'hosts_url', 'address' );
	foreach ( array_keys( (array) $req->get_param( 'fields' ) ) as $k ) {
		$sc = in_array( (string) $k, $dates, true ) ? 'dates' : '';
		if ( function_exists( 'ogc_coa_app_may' ) && ! ogc_coa_app_may( (int) $req['year'], $sc ) ) {
			return ogc_rest_denied( 'The COA’s · Ask the COA to hand it to your committee' );
		}
	}
	return true;
}

/** Names only a year's members may read (the committees' requests, the notes for next year). */
function ogc_private_files() {
	return (array) apply_filters( 'ogc_private_files', array( 'needs', 'notes' ) );
}

/** May this person read this file? Members read everything of their year. Everyone else reads the
 * public files, unless an area withholds one (ogc_file_visible: e.g. a schedule not yet published). */
function ogc_file_readable( $year, $name ) {
	$member = ogc_is_member( $year );
	if ( $member ) {
		return true;
	}
	if ( in_array( $name, ogc_private_files(), true ) ) {
		return false;
	}
	return (bool) apply_filters( 'ogc_file_visible', true, (int) $year, $name, $member );
}

/** Anyone may ask for a file; what they get depends on who they are (ogc_file_response): a file they
 * may not read, or one that isn't there, answers as an empty file, so the public can't tell which. */
function ogc_can_read_file( WP_REST_Request $req ) {
	return ogc_valid_year( $req['year'] ) && ogc_valid_name( $req['name'] );
}

function ogc_can_read_log( WP_REST_Request $req ) {
	$y = $req->get_param( 'year' );
	if ( ogc_is_webmaster() ) {
		return true;
	}
	return ( ogc_valid_year( $y ) && ogc_is_member( $y ) ) ? true : ogc_rest_denied();
}

function ogc_kind_ok( $kind ) {
	return in_array( $kind, ogc_record_kinds(), true );
}

function ogc_can_read_records( WP_REST_Request $req ) {
	if ( ! ogc_kind_ok( $req['kind'] ) ) {
		return new WP_Error( 'ogc_no_kind', 'No such kind.', array( 'status' => 404 ) );
	}
	$scope = $req->get_param( 'scope' ) ?: 'mine';
	if ( 'public' === $scope ) {
		return true;
	}
	if ( 'mine' === $scope ) {
		return is_user_logged_in() ? true : ogc_rest_denied( 'Sign in first.' );
	}
	if ( 'all' === $scope ) {
		return ogc_records_all_ok( $req['year'], $req['kind'] ) ? true : ogc_rest_denied();
	}
	return new WP_Error( 'ogc_bad_scope', 'scope is mine, public or all.', array( 'status' => 400 ) );
}

/** May this person read and change every record of a kind in a year, not only their own? The COA and
 * the webmasters. A committee helper is a member of the year but gets only their own records here (each
 * committee reads its people through its own routes); an area may add one (ogc_records_all: the
 * committee handed Registration, the Young Folks committee for teams). */
function ogc_records_all_ok( $year, $kind ) {
	if ( ! ogc_is_member( $year ) ) {
		return false;
	}
	if ( ogc_is_webmaster() ) {
		return true;
	}
	$coa = true;
	if ( function_exists( 'ogc_app_viewer' ) && function_exists( 'ogc_app_tables_ready' ) && ogc_app_tables_ready() ) {
		$v   = ogc_app_viewer( (int) $year );
		$coa = ! empty( $v['coa'] );
	}
	return (bool) apply_filters( 'ogc_records_all', $coa, (int) $year, (string) $kind );
}

/** The default rule for changing records, before an area's ogc_record_can_write filter: the COA (and
 * webmasters) may change any of the year's records; anyone signed in may change their own (the email it
 * belongs to is theirs); no one else. */
function ogc_record_may( $action, $kind, $year, $record, $data, WP_REST_Request $req ) {
	$me      = ogc_current_email();
	$allowed = false;
	if ( ogc_records_all_ok( $year, $kind ) ) {
		$allowed = true;
	} elseif ( $me ) {
		$owner_now = $record ? $record['email'] : '';
		$owner_new = null === $data ? $owner_now : ogc_record_owner( $kind, $data, $year );
		if ( 'create' === $action ) {
			$allowed = '' === $owner_new || $owner_new === $me;
		} else {
			$allowed = $owner_now === $me && ( '' === $owner_new || $owner_new === $me );
		}
	}
	return (bool) apply_filters( 'ogc_record_can_write', $allowed, $action, $kind, (int) $year, $record, $data, $req );
}

function ogc_can_create_record( WP_REST_Request $req ) {
	if ( ! ogc_kind_ok( $req['kind'] ) ) {
		return new WP_Error( 'ogc_no_kind', 'No such kind.', array( 'status' => 404 ) );
	}
	$data = $req->get_param( 'data' );
	if ( ! is_array( $data ) ) {
		return new WP_Error( 'ogc_bad_data', 'data must be an object.', array( 'status' => 400 ) );
	}
	return ogc_record_may( 'create', $req['kind'], (int) $req['year'], null, $data, $req ) ? true : ogc_rest_denied();
}

function ogc_can_change_record( WP_REST_Request $req ) {
	$rec = ogc_record_get( (int) $req['id'] );
	if ( ! $rec ) {
		// The same answer whether it never existed or isn't theirs to see.
		return new WP_Error( 'ogc_not_found', 'Not found.', array( 'status' => 404 ) );
	}
	$data = 'DELETE' === $req->get_method() ? null : $req->get_param( 'data' );
	if ( 'PUT' === $req->get_method() && ! is_array( $data ) ) {
		return new WP_Error( 'ogc_bad_data', 'data must be an object.', array( 'status' => 400 ) );
	}
	$action = 'DELETE' === $req->get_method() ? 'delete' : 'update';
	if ( ogc_record_may( $action, $rec['kind'], $rec['year'], $rec, $data, $req ) ) {
		return true;
	}
	return is_user_logged_in() && ogc_record_owner( $rec['kind'], $rec['data'], $rec['year'] ) !== ogc_current_email()
		? new WP_Error( 'ogc_not_found', 'Not found.', array( 'status' => 404 ) )
		: ogc_rest_denied();
}

/* ------------------------------------------------------------------ responses */

/** CSV text as the response body (the files route's default). */
function ogc_rest_csv( $text, $status = 200 ) {
	$res = new WP_REST_Response( $text, $status );
	$res->header( 'Content-Type', 'text/csv; charset=utf-8' );
	$res->header( 'X-Content-Type-Options', 'nosniff' );
	return $res;
}

// Serve a CSV response as plain text, not JSON-encoded.
add_filter( 'rest_pre_serve_request', function ( $served, $result, $request ) {
	if ( $served || ! ( $result instanceof WP_REST_Response ) ) {
		return $served;
	}
	$h = $result->get_headers();
	if ( isset( $h['Content-Type'] ) && 0 === strpos( $h['Content-Type'], 'text/csv' ) && is_string( $result->get_data() ) && 0 === strpos( (string) $request->get_route(), '/' . OGC_NS . '/' ) ) {
		echo $result->get_data(); // phpcs:ignore WordPress.Security.EscapeOutput -- CSV text, served as text/csv with nosniff.
		return true;
	}
	return $served;
}, 10, 3 );

// Answers with someone's data are never kept by a browser or the guide's offline copy: a person's own
// (records, /me/, rooms/, state/, the log) and anything a member gets for their year (members read every
// record and private file). Sent private, no-store. (Moved here from the map module, Oct 10.)
add_filter( 'rest_post_dispatch', function ( $res, $server, $req ) {
	$route = (string) $req->get_route();
	if ( ! ( $res instanceof WP_REST_Response ) || 0 !== strpos( $route, '/' . OGC_NS . '/' ) ) {
		return $res;
	}
	$y = preg_match( '#/years/(\d{4})#', $route, $m ) ? (int) $m[1] : 0;
	if ( preg_match( '#/(records|me/|rooms/|state/|log)#', $route ) || ( $y && ogc_is_member( $y ) ) ) {
		$res->header( 'Cache-Control', 'private, no-store, max-age=0' );
	}
	return $res;
}, 10, 3 );

/* ------------------------------------------------------------------ years */

/** years.csv as the public sees it (an area may hide a year not yet announced). */
function ogc_years_public() {
	return (array) apply_filters( 'ogc_years_public', ogc_years_all(), ogc_is_webmaster() );
}

function ogc_rest_years( WP_REST_Request $req ) {
	$rows = ogc_years_public();
	if ( 'csv' === $req->get_param( 'format' ) ) {
		return ogc_rest_csv( ogc_csv_write( $rows, ogc_year_columns() ) );
	}
	return rest_ensure_response( array_values( $rows ) );
}

function ogc_rest_year_patch( WP_REST_Request $req ) {
	$y      = (int) $req['year'];
	$fields = $req->get_param( 'fields' );
	if ( ! is_array( $fields ) || ! $fields ) {
		return new WP_Error( 'ogc_bad_fields', 'fields must be an object.', array( 'status' => 400 ) );
	}
	$clean = array();
	foreach ( $fields as $k => $v ) {
		if ( ! preg_match( '/^[a-z][a-z0-9_]{0,31}$/', (string) $k ) || 'year' === $k ) {
			return new WP_Error( 'ogc_bad_field', 'Unknown field.', array( 'status' => 400 ) );
		}
		if ( null !== $v && ! is_scalar( $v ) ) {
			return new WP_Error( 'ogc_bad_field', 'A field is text.', array( 'status' => 400 ) );
		}
		$clean[ $k ] = null === $v ? null : sanitize_text_field( (string) $v );
	}
	$new  = null === ogc_year_get( $y );
	$row  = ogc_year_set( $y, $clean );
	ogc_log( $new ? 'year_start' : 'year_set', $y, 'years', array( 'fields' => array_keys( $clean ) ) );
	return rest_ensure_response( $row );
}

/* ------------------------------------------------------------------ files */

function ogc_rest_file_list( WP_REST_Request $req ) {
	return rest_ensure_response( (object) ogc_file_list( (int) $req['year'] ) );
}

/** Files as the pages read them: CSV text by default, or ?format=json for the rows, the columns and
 * the version (lossless: the pickup's "_id"/"_look" keep their underscore). A file this person may not
 * read, or one that isn't there, answers as an empty file (version 0): the pages treat both as
 * "nothing yet", and the public can't tell a withheld file from a missing one. */
function ogc_file_response( $year, $name, $format ) {
	// An area may answer for a file it keeps elsewhere (ogc_file_out; the map: the campus, kept per venue).
	$f = ogc_file_readable( $year, $name ) ? apply_filters( 'ogc_file_out', ogc_file_get( $year, $name ), (int) $year, $name ) : null;
	if ( null === $f ) {
		$f = array( 'rows' => array(), 'cols' => array(), 'version' => 0, 'updated_at' => null );
	} else {
		// The rows this reader gets (an area holds back rows not yet published: ogc_file_rows_out).
		$f['rows'] = (array) apply_filters( 'ogc_file_rows_out', $f['rows'], (int) $year, $name, ogc_is_member( $year ) );
		$f['cols'] = (array) apply_filters( 'ogc_file_cols_out', (array) $f['cols'], (int) $year, $name, ogc_is_member( $year ) );
	}
	if ( 'json' === $format ) {
		return rest_ensure_response( array( 'year' => (int) $year, 'name' => $name, 'rows' => $f['rows'], 'cols' => $f['cols'], 'version' => $f['version'], 'updated_at' => $f['updated_at'] ) );
	}
	return ogc_rest_csv( $f['rows'] || $f['cols'] ? ogc_csv_write( $f['rows'], $f['cols'] ) : '' );
}

/** Anyone may ask for a year's files at once; each is in it only if this person may read it. */
function ogc_can_read_bundle( WP_REST_Request $req ) {
	return ogc_valid_year( $req['year'] );
}

/** Every file of the year this person may read, in one answer: name → { rows, cols, version }.
 * (Each request costs a whole WordPress start, so the pages read a year this way: ogc-store.js.) */
function ogc_rest_bundle( WP_REST_Request $req ) {
	$y   = (int) $req['year'];
	$out = array();
	foreach ( array_keys( ogc_file_list( $y ) ) as $name ) {
		if ( ! ogc_file_readable( $y, $name ) ) {
			continue;
		}
		$f            = apply_filters( 'ogc_file_out', ogc_file_get( $y, $name ), $y, $name );
		$f['rows']    = (array) apply_filters( 'ogc_file_rows_out', $f['rows'], $y, $name, ogc_is_member( $y ) );
		$f['cols']    = (array) apply_filters( 'ogc_file_cols_out', (array) $f['cols'], $y, $name, ogc_is_member( $y ) );
		$out[ $name ] = array( 'rows' => $f['rows'], 'cols' => $f['cols'], 'version' => $f['version'], 'updated_at' => $f['updated_at'] );
	}
	return rest_ensure_response( (object) $out );
}

function ogc_rest_file_get( WP_REST_Request $req ) {
	return ogc_file_response( (int) $req['year'], $req['name'], $req->get_param( 'format' ) );
}

/** Rows must be a list of flat objects (text, numbers, true/false), within a size the pages use. */
function ogc_check_rows( $rows, $year, $name ) {
	if ( ! is_array( $rows ) || ( $rows && array_keys( $rows ) !== range( 0, count( $rows ) - 1 ) ) ) {
		return new WP_Error( 'ogc_bad_rows', 'rows must be a list.', array( 'status' => 400 ) );
	}
	if ( count( $rows ) > 5000 ) {
		return new WP_Error( 'ogc_too_big', 'Too many rows.', array( 'status' => 413 ) );
	}
	foreach ( $rows as $r ) {
		if ( ! is_array( $r ) ) {
			return new WP_Error( 'ogc_bad_rows', 'Each row is an object.', array( 'status' => 400 ) );
		}
		foreach ( $r as $k => $v ) {
			if ( ! preg_match( '/^[A-Za-z0-9_][A-Za-z0-9_ .-]{0,63}$/', (string) $k ) || ( null !== $v && ! is_scalar( $v ) ) ) {
				return new WP_Error( 'ogc_bad_rows', 'A row holds only text, by column.', array( 'status' => 400 ) );
			}
		}
	}
	if ( strlen( ogc_json( $rows ) ) > 2 * 1024 * 1024 ) {
		return new WP_Error( 'ogc_too_big', 'Too big.', array( 'status' => 413 ) );
	}
	$ok = apply_filters( 'ogc_file_rows_valid', true, $rows, (int) $year, $name );
	return is_wp_error( $ok ) ? $ok : true;
}

function ogc_rest_file_put( WP_REST_Request $req ) {
	$y    = (int) $req['year'];
	$name = $req['name'];
	$rows = $req->get_param( 'rows' );
	$ver  = $req->get_param( 'version' );
	if ( ! is_numeric( $ver ) ) {
		return new WP_Error( 'ogc_bad_version', 'version is the one last read (0 for a new file).', array( 'status' => 400 ) );
	}
	$ok = ogc_check_rows( $rows, $y, $name );
	if ( is_wp_error( $ok ) ) {
		return $ok;
	}
	$cols = $req->get_param( 'cols' );
	$cols = is_array( $cols ) ? array_values( array_filter( array_map( 'strval', $cols ), function ( $c ) { return (bool) preg_match( '/^[A-Za-z0-9_][A-Za-z0-9_ .-]{0,63}$/', $c ); } ) ) : null;
	$v    = ogc_file_put( $y, $name, $rows, (int) $ver, $cols );
	if ( is_wp_error( $v ) ) {
		return $v;
	}
	ogc_log( 'file_put', $y, $name, array( 'version' => $v, 'rows' => count( $rows ) ) );
	do_action( 'ogc_file_saved', $y, $name, $v );
	return rest_ensure_response( array( 'version' => $v ) );
}

function ogc_rest_file_patch( WP_REST_Request $req ) {
	$y    = (int) $req['year'];
	$name = $req['name'];
	$op   = $req->get_param( 'op' );
	if ( 'key' === $op ) {
		$k = $req->get_param( 'key' );
		$v = $req->get_param( 'value' );
		if ( ! is_string( $k ) || ! preg_match( '/^[A-Za-z0-9_][A-Za-z0-9_.-]{0,63}$/', $k ) || ( null !== $v && ! is_scalar( $v ) ) ) {
			return new WP_Error( 'ogc_bad_key', 'A key and its value.', array( 'status' => 400 ) );
		}
		$patch = array( 'op' => 'key', 'key' => $k, 'value' => null === $v ? '' : (string) $v );
	} elseif ( 'row' === $op ) {
		$row = $req->get_param( 'row' );
		$ok  = ogc_check_rows( array( $row ), $y, $name );
		if ( is_wp_error( $ok ) ) {
			return $ok;
		}
		$patch = array( 'op' => 'row', 'row' => $row );
	} else {
		return new WP_Error( 'ogc_bad_op', 'op is row or key.', array( 'status' => 400 ) );
	}
	$v = ogc_file_patch( $y, $name, $patch );
	if ( is_wp_error( $v ) ) {
		return $v;
	}
	ogc_log( 'file_' . $op, $y, $name, array( 'version' => $v, 'key' => 'key' === $op ? $patch['key'] : '' ) );
	do_action( 'ogc_file_saved', $y, $name, $v );
	return rest_ensure_response( array( 'version' => $v ) );
}

/* ------------------------------------------------------------------ state */

function ogc_rest_state_get( WP_REST_Request $req ) {
	$s = ogc_state_get( (int) $req['year'], $req['key'] );
	if ( ! $s ) {
		return new WP_Error( 'ogc_not_found', 'Not found.', array( 'status' => 404 ) );
	}
	return rest_ensure_response( $s );
}

function ogc_rest_state_put( WP_REST_Request $req ) {
	$y     = (int) $req['year'];
	$value = $req->get_param( 'value' );
	if ( strlen( ogc_json( $value ) ) > 1024 * 1024 ) {
		return new WP_Error( 'ogc_too_big', 'Too big.', array( 'status' => 413 ) );
	}
	$ver = $req->get_param( 'version' );
	$v   = ogc_state_put( $y, $req['key'], $value, is_numeric( $ver ) ? (int) $ver : null );
	if ( is_wp_error( $v ) ) {
		return $v;
	}
	ogc_log( 'state_put', $y, $req['key'], array( 'version' => $v ) );
	return rest_ensure_response( array( 'version' => $v ) );
}

/* ------------------------------------------------------------------ records */

/** A record as this person may see it: whole (their own, or any for a member) or the kind's public
 * view (ogc_record_public; null leaves it out). */
function ogc_record_out( $rec, $whole ) {
	$out = array( 'id' => $rec['id'], 'mine' => (bool) apply_filters( 'ogc_record_is_mine', '' !== ogc_current_email() && $rec['email'] === ogc_current_email(), $rec ) );
	if ( $whole ) {
		// ogc_record_whole: an area may leave parts of its kind out even of a whole record (register:
		// children's medical notes for members not named to see them; never a token's hash).
		$data = apply_filters( 'ogc_record_whole', $rec['data'], $rec );
		return array_merge( $out, array( 'data' => $data, 'sample' => $rec['sample'], 'created_at' => $rec['created_at'], 'updated_at' => $rec['updated_at'] ) );
	}
	$pub = apply_filters( 'ogc_record_public', null, $rec['data'], $rec['kind'], $rec['year'], $rec );
	return is_array( $pub ) ? array_merge( $out, array( 'data' => $pub, 'public' => true ) ) : null;
}

/** A year's records of one kind, as this person may see them. scope: mine | public | all. */
function ogc_records_for( $year, $kind, $scope ) {
	$out = array();
	if ( 'all' === $scope ) {
		foreach ( ogc_records( $year, $kind ) as $r ) {
			$out[] = ogc_record_out( $r, true );
		}
	} elseif ( 'mine' === $scope ) {
		// ogc_records_mine (signin area): also what this device made before its email was confirmed,
		// and records reached through a second email (a helper, a parent).
		$own = ogc_current_email() ? ogc_records( $year, $kind, ogc_current_email() ) : array();
		foreach ( (array) apply_filters( 'ogc_records_mine', $own, $year, $kind ) as $r ) {
			$out[] = ogc_record_out( $r, true );
		}
	} else {
		foreach ( ogc_records( $year, $kind ) as $r ) {
			$o = ogc_record_out( $r, false );
			if ( $o ) {
				$out[] = $o;
			}
		}
	}
	return $out;
}

function ogc_rest_records_get( WP_REST_Request $req ) {
	return rest_ensure_response( ogc_records_for( (int) $req['year'], $req['kind'], $req->get_param( 'scope' ) ?: 'mine' ) );
}

/** Everything this person may see of a year's records, several kinds at once (the pages load it at
 * O.ready): the COA gets every record; anyone else their own whole, and others' public views
 * (?scope=mine: only their own). */
function ogc_rest_records_bundle( WP_REST_Request $req ) {
	$y     = (int) $req['year'];
	$only  = 'mine' === $req->get_param( 'scope' );
	$kinds = array_filter( array_map( 'trim', explode( ',', (string) $req->get_param( 'kinds' ) ) ) );
	$kinds = $kinds ? array_values( array_intersect( $kinds, ogc_record_kinds() ) ) : ogc_record_kinds();
	$out   = array();
	foreach ( $kinds as $kind ) {
		if ( ! $only && ogc_records_all_ok( $y, $kind ) ) {
			$out[ $kind ] = ogc_records_for( $y, $kind, 'all' );
			continue;
		}
		$mine = ogc_records_for( $y, $kind, 'mine' );
		if ( $only ) {
			$out[ $kind ] = $mine;
			continue;
		}
		$ids  = wp_list_pluck( $mine, 'id' );
		$pub  = array_values( array_filter( ogc_records_for( $y, $kind, 'public' ), function ( $o ) use ( $ids ) { return ! in_array( $o['id'], $ids, true ); } ) );
		$out[ $kind ] = array_merge( $mine, $pub );
	}
	return rest_ensure_response( (object) $out );
}

/** The data a record keeps: what the page sent, without the page's own bookkeeping, checked by the
 * kind's validator. */
function ogc_record_clean( $data, $kind, $year, $existing, WP_REST_Request $req ) {
	unset( $data['_rid'], $data['_pub'], $data['mine'] );
	if ( strlen( ogc_json( $data ) ) > 64 * 1024 ) {
		return new WP_Error( 'ogc_too_big', 'Too big.', array( 'status' => 413 ) );
	}
	return apply_filters( 'ogc_record_validate', $data, $kind, (int) $year, $existing, $req );
}

function ogc_rest_record_create( WP_REST_Request $req ) {
	$y    = (int) $req['year'];
	$kind = $req['kind'];
	$data = ogc_record_clean( $req->get_param( 'data' ), $kind, $y, null, $req );
	if ( is_wp_error( $data ) ) {
		return $data;
	}
	$email = ogc_record_owner( $kind, $data, $y );
	if ( '' === $email ) {
		$email = ogc_current_email();
	}
	$id = ogc_record_insert( $y, $kind, $data, $email, false, 'web' );
	if ( ! $id ) {
		return new WP_Error( 'ogc_db', 'Not saved.', array( 'status' => 500 ) );
	}
	$rec = ogc_record_get( $id );
	ogc_log( 'record_add', $y, $kind, array( 'id' => $id ) );
	do_action( 'ogc_record_saved', $rec, 'create', $req );
	return new WP_REST_Response( ogc_record_out( $rec, true ), 201 );
}

function ogc_rest_record_update( WP_REST_Request $req ) {
	$rec  = ogc_record_get( (int) $req['id'] );
	$data = ogc_record_clean( $req->get_param( 'data' ), $rec['kind'], $rec['year'], $rec, $req );
	if ( is_wp_error( $data ) ) {
		return $data;
	}
	$email = ogc_record_owner( $rec['kind'], $data, $rec['year'] );
	// Whose record it is never moves through a change: only a webmaster may give it to another email.
	if ( '' !== $email && $email !== $rec['email'] && '' !== $rec['email'] && ! ogc_is_webmaster() ) {
		return new WP_Error( 'ogc_owner', 'The email is theirs to change.', array( 'status' => 403 ) );
	}
	ogc_record_update( $rec['id'], $data, '' === $email ? $rec['email'] : $email );
	$rec = ogc_record_get( $rec['id'] );
	ogc_log( 'record_set', $rec['year'], $rec['kind'], array( 'id' => $rec['id'] ) );
	do_action( 'ogc_record_saved', $rec, 'update', $req );
	return rest_ensure_response( ogc_record_out( $rec, true ) );
}

function ogc_rest_record_delete( WP_REST_Request $req ) {
	$rec = ogc_record_get( (int) $req['id'] );
	ogc_record_delete( $rec['id'] );
	ogc_log( 'record_remove', $rec['year'], $rec['kind'], array( 'id' => $rec['id'] ) );
	do_action( 'ogc_record_saved', $rec, 'delete', $req );
	return rest_ensure_response( array( 'id' => $rec['id'], 'deleted' => true ) );
}

function ogc_rest_samples_clear( WP_REST_Request $req ) {
	$kind = $req->get_param( 'kind' );
	$kind = is_string( $kind ) && ogc_kind_ok( $kind ) ? $kind : null;
	$n    = ogc_records_clear_samples( (int) $req['year'], $kind );
	// What the areas kept beside the sample records (places on shifts, ledger rows, sample notes).
	do_action( 'ogc_samples_cleared', (int) $req['year'], $kind );
	ogc_log( 'samples_clear', (int) $req['year'], $kind ?: 'all', array( 'n' => $n ) );
	return rest_ensure_response( array( 'cleared' => $n ) );
}

/* ------------------------------------------------------------------ the change log */

function ogc_rest_log( WP_REST_Request $req ) {
	global $wpdb;
	$y     = $req->get_param( 'year' );
	$limit = min( 500, max( 1, (int) ( $req->get_param( 'limit' ) ?: 100 ) ) );
	if ( ogc_valid_year( $y ) ) {
		$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . ogc_table( 'log' ) . ' WHERE year = %d ORDER BY id DESC LIMIT %d', $y, $limit ), ARRAY_A );
	} else {
		$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . ogc_table( 'log' ) . ' ORDER BY id DESC LIMIT %d', $limit ), ARRAY_A );
	}
	$names = array();
	$out   = array();
	foreach ( (array) $rows as $r ) {
		$uid = (int) $r['user'];
		if ( $uid && ! isset( $names[ $uid ] ) ) {
			$u              = get_userdata( $uid );
			$names[ $uid ] = $u ? $u->display_name : '';
		}
		$out[] = array( 'id' => (int) $r['id'], 'at' => $r['at'], 'who' => $uid ? $names[ $uid ] : '', 'year' => (int) $r['year'], 'action' => $r['action'], 'target' => $r['target'], 'detail' => ogc_unjson( $r['detail'], array() ) );
	}
	return rest_ensure_response( $out );
}
