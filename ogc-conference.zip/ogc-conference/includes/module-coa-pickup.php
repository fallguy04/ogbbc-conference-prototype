<?php
/**
 * Making a year on the server from the last one (v3's ogc-pickup.js, ported and tightened), moving
 * its dates, and changing its campus. Each is one action by a person, never a page load:
 *
 *   POST coa/{y}/start            webmasters: the year exists (its hosts, its parts empty). If the
 *                                 last Conference has ended, its parts are picked up at once.
 *   POST coa/{y}/pickup {force}   the year's parts from the last Conference "as held" (after it ends;
 *                                 with force, as it stands now). Once: a part the year already has is
 *                                 never overwritten.
 *   POST coa/{y}/dates {start, end, apply}   what moves with a new first day; with apply, moved
 *   POST coa/{y}/campus {venue | new:{name, city, address}, apply}   what a campus brings and
 *                                 replaces; with apply, changed, and the replaced set kept for Restore
 *   POST coa/{y}/campus-restore   the campus as it was before the last change
 *
 * The rules (docs/14, and the year area's audits):
 *   - most of the year is last year again: the week, registration, the packet, the shifts, the
 *     tournaments, every date moved with the Conference (same weekday, same distance from Friday);
 *   - what belongs to a campus comes from the last Conference there: buildings and rooms, halls and
 *     floor plans, the map, care nearby, Help, the campus's prices and rules, the requests, and the
 *     packet's campus parts; the week's and the shifts' places are matched to that campus;
 *   - nothing goes public by itself: the schedule, the packet and volunteer sign-ups wait for
 *     Publish; registration and the tournaments wait for Schedule; picked-up dates are suggestions;
 *   - a year with no dates yet copies no date: they're set once, with the dates;
 *   - not carried: the menus (they wait for the caterer), notices, notes (read live from last year),
 *     owners, ticks, members;
 *   - carried values that change by accident (the call-in line, prices, Help phones) wait for
 *     "Looks right" (picked.confirm) before the public sees them.
 */

defined( 'ABSPATH' ) || exit;

add_action( 'rest_api_init', function () {
	$Y = '(?P<year>\d{4})';
	register_rest_route( OGC_NS, "/coa/$Y/start", array(
		array( 'methods' => 'POST', 'callback' => 'ogc_coa_rest_start', 'permission_callback' => 'ogc_can_webmaster' ),
	) );
	foreach ( array( 'pickup', 'dates', 'campus', 'campus-restore' ) as $a ) {
		register_rest_route( OGC_NS, "/coa/$Y/$a", array(
			array( 'methods' => 'POST', 'callback' => 'ogc_coa_rest_' . str_replace( '-', '_', $a ), 'permission_callback' => 'ogc_can_member' ),
		) );
	}
} );

const OGC_COA_CAMPUS_PARTS = array( 'lodging', 'arriving', 'campers', 'getting-around' );
const OGC_COA_VENUE_KEYS   = array( 'room_price', 'room_beds', 'linen_price', 'mattress_price', 'camper_price', 'camper_per', 'key_fee', 'bed_fee', 'yf_age_split', 'price_basis', 'rooms_held' );
const OGC_COA_MONTHS       = array( 'January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December' );

/* ------------------------------------------------------------------ helpers */

/** Run $fn in one database transaction where the database allows it. */
function ogc_coa_tx( $fn ) {
	global $wpdb;
	$wpdb->query( 'START TRANSACTION' );
	try {
		$out = $fn();
	} catch ( Exception $e ) {
		$wpdb->query( 'ROLLBACK' );
		throw $e;
	}
	if ( is_wp_error( $out ) ) {
		$wpdb->query( 'ROLLBACK' );
	} else {
		$wpdb->query( 'COMMIT' );
	}
	return $out;
}

/** A year's files, as rows (missing ones empty). */
function ogc_coa_rows( $year, $name ) {
	$f = ogc_file_get( (int) $year, $name );
	return $f ? $f['rows'] : array();
}

/** The Friday a year starts (settings first_day, else years.csv start). */
function ogc_coa_first_day( $year ) {
	$s   = ogc_coa_kv( $year, 'settings' );
	$row = ogc_year_get( $year );
	$v   = ! empty( $s['first_day'] ) ? $s['first_day'] : ( $row && ! empty( $row['start'] ) ? $row['start'] : '' );
	return ogc_coa_iso( $v ) ? $v : '';
}

/** The last year before $year with the given venue and its own files. */
function ogc_coa_campus_year( $year, $venue ) {
	if ( '' === (string) $venue ) {
		return 0;
	}
	foreach ( ogc_years_all() as $r ) {
		if ( (int) $r['year'] < (int) $year && ! empty( $r['data'] ) && isset( $r['venue'] ) && strtolower( $r['venue'] ) === strtolower( $venue ) ) {
			return (int) $r['year'];
		}
	}
	return 0;
}

/** Has the year's Conference ended (at its campus)? */
function ogc_coa_is_over( $year ) {
	$row = ogc_year_get( $year );
	return $row && ! empty( $row['end'] ) && ogc_coa_today( $year ) > $row['end'];
}

/** The rows of the week that are the same every year (docs/14): by kind alone (services, Communion,
 * Council, meals). The rest varies, and is To check. */
function ogc_coa_standard( $r ) {
	// By kind only, never by words in the title (docs/26 #6, docs/scope/05 Q3 (b); night-schedule):
	// Worship, Communion, Council and Meal come over as they were, unless the row has a note or a
	// printout note (written for last year, so a person reads it). Everything else is To check.
	$k = strtolower( isset( $r['kind'] ) ? (string) $r['kind'] : '' );
	$k = function_exists( 'ogc_sched_kind_of' ) ? ogc_sched_kind_of( $k ) : $k;
	if ( '' !== trim( (string) ( isset( $r['note'] ) ? $r['note'] : '' ) ) || '' !== trim( (string) ( isset( $r['print_note'] ) ? $r['print_note'] : '' ) ) ) {
		return false;
	}
	return in_array( $k, array( 'worship', 'communion', 'council', 'meal' ), true );
}

/** "Friday, June 5" → "Friday, May 28"; "June 2–7" → "May 25–30". Returns array( text, moved ). */
function ogc_coa_move_text( $t, $from_year, $d ) {
	$moved = array();
	if ( ! $d ) {
		return array( (string) $t, $moved );
	}
	$re  = '/\b(' . implode( '|', OGC_COA_MONTHS ) . ')\s+(\d{1,2})(?:st|nd|rd|th)?(?:\s*[–-]\s*(\d{1,2})\b)?/u';
	$out = preg_replace_callback( $re, function ( $m ) use ( $from_year, $d, &$moved ) {
		$mon = array_search( $m[1], OGC_COA_MONTHS, true ) + 1;
		$iso = function ( $n ) use ( $from_year, $mon ) {
			return sprintf( '%04d-%02d-%02d', (int) $from_year, $mon, (int) $n );
		};
		if ( (int) $m[2] > 31 || ! ogc_coa_iso( $iso( $m[2] ) ) ) {
			return $m[0];
		}
		$a   = ogc_coa_add_days( $iso( $m[2] ), $d );
		$rep = ogc_coa_md( $a );
		if ( ! empty( $m[3] ) && ogc_coa_iso( $iso( $m[3] ) ) ) {
			$b    = ogc_coa_add_days( $iso( $m[3] ), $d );
			$rep .= '–' . ( substr( $b, 0, 7 ) === substr( $a, 0, 7 ) ? (string) (int) substr( $b, 8 ) : ogc_coa_md( $b ) );
		}
		if ( $rep !== $m[0] ) {
			$moved[] = array( 'from' => $m[0], 'to' => $rep );
		}
		return $rep;
	}, (string) $t );
	return array( $out, $moved );
}

/** The weekday names from the first day through the morning after the last (check-out). */
function ogc_coa_day_names( $start, $end ) {
	$out = array();
	$n   = ogc_coa_days_between( $start, $end ) + 1;
	for ( $i = 0; $i <= min( 12, $n ); $i++ ) {
		$d     = DateTime::createFromFormat( '!Y-m-d', ogc_coa_add_days( $start, $i ), new DateTimeZone( 'UTC' ) );
		$out[] = $d->format( 'l' );
	}
	return array_values( array_unique( $out ) );
}

/** Rows with an _id each (so two people's changes to different rows can be told apart). */
function ogc_coa_with_ids( $rows, $prefix ) {
	$i = 0;
	return array_map( function ( $r ) use ( $prefix, &$i ) {
		$i++;
		if ( empty( $r['_id'] ) ) {
			$r['_id'] = $prefix . $i;
		}
		unset( $r['_new'], $r['_chg'] );
		return $r;
	}, array_values( (array) $rows ) );
}

/** Each row's place matched to another campus: the same event (title) at that campus's last
 * Conference gives the place; a place that isn't there is marked to choose. */
function ogc_coa_match_places( $rows, $there_rows, $places, $keyfn ) {
	$codes = array();
	foreach ( $places as $p ) {
		if ( ! empty( $p['code'] ) ) {
			$codes[ strtoupper( $p['code'] ) ] = 1;
		}
	}
	$by = array();
	foreach ( $there_rows as $r ) {
		$k = $keyfn( $r );
		if ( $k && ! isset( $by[ $k ] ) && ! empty( $r['place'] ) ) {
			$by[ $k ] = $r['place'];
		}
	}
	$n = 0;
	foreach ( $rows as &$r ) {
		if ( empty( $r['place'] ) ) {
			continue;
		}
		$k = $keyfn( $r );
		if ( isset( $by[ $k ] ) ) {
			$r['place'] = $by[ $k ];
		} elseif ( ! isset( $codes[ strtoupper( strtok( $r['place'], '/' ) ) ] ) && ! isset( $codes[ strtoupper( $r['place'] ) ] ) ) {
			$r['_look'] = 'place';
			$n++;
		}
	}
	unset( $r );
	return array( $rows, $n );
}

/** The committees the year names (committees.csv, the volunteer area's columns: name, contact_email,
 * contact_phone, heads, weekly, order), carried as they were; or, the first time, the names its requests
 * and shifts use. Committee heads' own emails aren't carried: next year's heads are new people. */
function ogc_coa_committees_from( $year ) {
	$have = ogc_coa_rows( $year, 'committees' );
	if ( $have ) {
		// Each row keeps an id from the start ("co1", as the year page would give it), so History can
		// say "Renamed Food → Dining hall" rather than every committee removed and added.
		$i = 0;
		return array_map( function ( $r ) use ( &$i ) {
			$r['_id']   = 'co' . ( ++$i );
			$r['heads'] = '';
			return $r;
		}, $have );
	}
	$names = array();
	foreach ( array( 'needs', 'shifts' ) as $f ) {
		foreach ( ogc_coa_rows( $year, $f ) as $r ) {
			$c = trim( isset( $r['committee'] ) ? (string) $r['committee'] : '' );
			if ( '' !== $c && 0 !== strpos( $c, '#' ) && ! isset( $names[ strtolower( $c ) ] ) ) {
				$names[ strtolower( $c ) ] = $c;
			}
		}
	}
	$i = 0;
	return array_map( function ( $n ) use ( &$i ) {
		return array( '_id' => 'co' . ( ++$i ), 'name' => $n, 'contact_email' => '', 'contact_phone' => '', 'heads' => '', 'weekly' => 'yes', 'order' => '' );
	}, array_values( $names ) );
}

/* ------------------------------------------------------------------ the pickup */

/**
 * Fill a year's parts from the last Conference. Idempotent: a file the year already has is left as
 * it is. Returns the pickup log (also kept as the year's state "picked").
 */
function ogc_coa_pickup( $y, $force = false ) {
	$row  = ogc_year_get( $y );
	$prev = ogc_coa_prev_year( $y );
	if ( ! $row ) {
		return new WP_Error( 'ogc_coa', 'No such year', array( 'status' => 404 ) );
	}
	$have = ogc_state_get( $y, 'picked' );
	if ( $have && ! empty( $have['value']['from'] ) ) {
		return new WP_Error( 'ogc_coa', 'Already picked up from ' . $have['value']['from'], array( 'status' => 409 ) );
	}
	if ( ! $prev ) {
		return new WP_Error( 'ogc_coa', 'No earlier year', array( 'status' => 400 ) );
	}
	// A Conference that's over, or a year that already has its own schedule, is never filled from the
	// one before (a mis-tap on a finished year's record).
	if ( ogc_coa_is_over( $y ) ) {
		return new WP_Error( 'ogc_coa', 'The ' . $y . ' Conference is over', array( 'status' => 409, 'reason' => 'held' ) );
	}
	if ( ogc_coa_rows( $y, 'schedule' ) ) {
		return new WP_Error( 'ogc_coa', $y . ' has its own schedule', array( 'status' => 409, 'reason' => 'has_parts' ) );
	}
	$p = (int) $prev['year'];
	if ( ! $force && ! ogc_coa_is_over( $p ) ) {
		$pr = ogc_year_get( $p );
		return new WP_Error( 'ogc_coa', 'The ' . $p . ' Conference isn’t over', array( 'status' => 409, 'reason' => 'not_over', 'ends' => $pr ? $pr['end'] : '' ) );
	}
	$venue = isset( $row['venue'] ) ? (string) $row['venue'] : '';
	$c     = ogc_coa_campus_year( $y, $venue );
	$pf    = ogc_coa_first_day( $p );
	$yf    = ogc_coa_first_day( $y );
	$d     = $pf && $yf ? ogc_coa_days_between( $pf, $yf ) : 0;
	$log   = array( 'from' => (string) $p, 'campus' => $c ? (string) $c : '', 'd' => $d, 'undated' => ! $yf, 'early' => ! ogc_coa_is_over( $p ), 'at' => ogc_coa_today( $y ), 'by' => ogc_coa_first_l( get_current_user_id() ), 'parts' => array(), 'confirm' => array(), 'suggest' => array() );
	$PS    = ogc_coa_kv( $p, 'settings' );
	$PR    = ogc_coa_kv( $p, 'registration' );
	$CS    = $c ? ogc_coa_kv( $c, 'settings' ) : array();
	$CR    = $c ? ogc_coa_kv( $c, 'registration' ) : array();
	$YS    = ogc_coa_kv( $y, 'settings' );

	return ogc_coa_tx( function () use ( $y, $p, $c, $d, $row, $yf, $PS, $PR, $CS, $CR, $YS, &$log ) {
		$put = function ( $name, $rows ) use ( $y, &$log ) {
			if ( ! $rows || ogc_coa_rows( $y, $name ) ) {
				return false;
			}
			$v = ogc_file_put( $y, $name, array_values( $rows ), 0 );
			return ! is_wp_error( $v );
		};
		$setting = function ( $k, $v ) use ( $y, &$YS ) {
			if ( ! isset( $YS[ $k ] ) || '' === $YS[ $k ] ) {
				ogc_coa_set( $y, 'settings', $k, $v );
				$YS[ $k ] = $v;
			}
		};

		// Settings: the days, the campus's clock, the call-in line (to confirm), the printout's choices.
		$setting( 'title', $y . ' Annual Conference' );
		$setting( 'year', (string) $y );
		if ( ! empty( $row['hosts'] ) ) {
			$setting( 'hosts', $row['hosts'] );
		}
		$setting( 'days', ! empty( $row['start'] ) && ! empty( $row['end'] ) ? implode( '|', ogc_coa_day_names( $row['start'], $row['end'] ) ) : ( isset( $PS['days'] ) ? $PS['days'] : '' ) );
		if ( $yf ) {
			$setting( 'first_day', $yf );
		}
		$clock = $c ? $CS : $PS;
		foreach ( array( 'timezone', 'timezone_label' ) as $k ) {
			if ( ! empty( $clock[ $k ] ) ) {
				$setting( $k, $clock[ $k ] );
			}
		}
		if ( $c ) {
			// print_required: the line the campus asks for on printed materials (print area).
			foreach ( array( 'venue', 'city', 'address', 'directions', 'print_required' ) as $k ) {
				if ( ! empty( $CS[ $k ] ) ) {
					$setting( $k, $CS[ $k ] );
				}
			}
		}
		// The call-in line's provider, # after the PIN, account holder and trouble line carry with its
		// number (night-schedule); they wait for the same Looks right.
		foreach ( array( 'call_in_number', 'call_in_pin', 'call_in_provider', 'call_in_pin_hash', 'call_in_account', 'call_in_trouble_role', 'call_in_trouble_phone', 'preteen_note', 'print_layout', 'tournaments_online', 'volunteer_names' ) as $k ) {
			if ( ! empty( $PS[ $k ] ) ) {
				$setting( $k, $PS[ $k ] );
			}
		}
		if ( ! empty( $PS['call_in_number'] ) ) {
			$log['confirm'][] = 'conf:callin';
		}
		// Nothing public until a person publishes or schedules it.
		foreach ( array( 'schedule_posted', 'packet_posted', 'signups_posted', 'registration_opens' ) as $k ) {
			$setting( $k, OGC_NOT_YET );
		}
		$setting( 'tournaments_held', 'yes' );

		// Registration: last year's, the campus's prices from its last Conference; its dates suggested.
		if ( $PR && ! ogc_coa_rows( $y, 'registration' ) ) {
			$rows  = array();
			$moved = array();
			foreach ( ogc_coa_rows( $p, 'registration' ) as $r ) {
				$k = isset( $r['key'] ) ? $r['key'] : '';
				$v = isset( $r['value'] ) ? (string) $r['value'] : '';
				if ( $c && $c !== $p && in_array( $k, OGC_COA_VENUE_KEYS, true ) ) {
					$v = isset( $CR[ $k ] ) ? $CR[ $k ] : '';
				} elseif ( in_array( $k, array( 'opens', 'closes', 'refunds_by', 'cancel_by' ), true ) && ogc_coa_iso( $v ) ) {
					$to                     = $d ? ogc_coa_add_days( $v, $d ) : '';
					$log['suggest'][ $k ]   = array( 'from' => $v, 'to' => $to );
					$moved[]                = array( 'k' => $k, 'from' => $v, 'to' => $to );
					$v                      = 'opens' === $k ? OGC_NOT_YET : $to;
				}
				$rows[] = array( 'key' => $k, 'value' => $v, 'help' => isset( $r['help'] ) ? $r['help'] : '' );
			}
			if ( $c && $c !== $p ) {
				foreach ( $CR as $k => $v ) {
					if ( in_array( $k, OGC_COA_VENUE_KEYS, true ) && ! in_array( $k, wp_list_pluck( $rows, 'key' ), true ) ) {
						$rows[] = array( 'key' => $k, 'value' => $v, 'help' => '' );
					}
				}
			}
			$put( 'registration', $rows );
			if ( isset( $log['suggest']['closes']['to'] ) && $log['suggest']['closes']['to'] ) {
				ogc_coa_set( $y, 'settings', 'registration_closes', $log['suggest']['closes']['to'] );
			}
			$log['parts']['registration'] = array( 'moved' => $moved, 'campus' => $c && $c !== $p ? (string) $c : '' );
			$log['confirm'][]             = 'reg:prices';
		}

		$there_sched = $c && $c !== $p ? ogc_coa_rows( $c, 'schedule' ) : array();
		$new_places  = $c ? ogc_coa_rows( $c, 'places' ) : array();

		// The week: rows that vary from year to year marked to check; places matched to the campus.
		$sched = ogc_coa_rows( $p, 'schedule' );
		if ( $sched && ! ogc_coa_rows( $y, 'schedule' ) ) {
			$rows = array();
			foreach ( array_values( $sched ) as $i => $r ) {
				unset( $r['_new'], $r['_chg'], $r['_look'] );
				$r['_id'] = ! empty( $r['_id'] ) ? $r['_id'] : 'r' . ( $i + 1 );
				if ( ! ogc_coa_standard( $r ) ) {
					$r['_look'] = '1';
				}
				$rows[] = $r;
			}
			$unmatched = 0;
			if ( $c && $c !== $p ) {
				list( $rows, $unmatched ) = ogc_coa_match_places( $rows, $there_sched, $new_places, function ( $r ) {
					return strtolower( trim( ( isset( $r['title'] ) ? $r['title'] : '' ) ) );
				} );
			}
			$put( 'schedule', $rows );
			$look = count( array_filter( $rows, function ( $r ) {
				return ! empty( $r['_look'] );
			} ) );
			$log['parts']['schedule'] = array( 'n' => count( $rows ), 'look' => $look, 'places' => $unmatched );
		}

		// The packet, its dates moved in the text; a campus's own parts from the last Conference there.
		$guide = ogc_coa_rows( $p, 'guide' );
		if ( $guide && ! ogc_coa_rows( $y, 'guide' ) ) {
			$moved = array();
			$cg    = $c && $c !== $p ? ogc_coa_rows( $c, 'guide' ) : array();
			$cd    = $c && $yf && ogc_coa_first_day( $c ) ? ogc_coa_days_between( ogc_coa_first_day( $c ), $yf ) : 0;
			$swap  = array();
			foreach ( $cg as $r ) {
				if ( in_array( isset( $r['id'] ) ? $r['id'] : '', OGC_COA_CAMPUS_PARTS, true ) ) {
					$swap[ $r['id'] ][] = $r;
				}
			}
			$rows = array();
			$done = array();
			foreach ( $guide as $r ) {
				$id = isset( $r['id'] ) ? $r['id'] : '';
				if ( isset( $swap[ $id ] ) ) {
					if ( empty( $done[ $id ] ) ) {
						foreach ( $swap[ $id ] as $cr ) {
							list( $tx, $m1 ) = ogc_coa_move_text( isset( $cr['text'] ) ? $cr['text'] : '', $c, $cd );
							list( $sm, $m2 ) = ogc_coa_move_text( isset( $cr['summary'] ) ? $cr['summary'] : '', $c, $cd );
							foreach ( array_merge( $m1, $m2 ) as $m ) {
								$moved[] = array_merge( array( 'id' => $id ), $m );
							}
							$rows[] = array_merge( $cr, array( 'text' => $tx, 'summary' => $sm, '_from' => (string) $c ) );
						}
						$done[ $id ] = 1;
					}
					continue;
				}
				list( $tx, $m1 ) = ogc_coa_move_text( isset( $r['text'] ) ? $r['text'] : '', $p, $d );
				list( $sm, $m2 ) = ogc_coa_move_text( isset( $r['summary'] ) ? $r['summary'] : '', $p, $d );
				foreach ( array_merge( $m1, $m2 ) as $m ) {
					$moved[] = array_merge( array( 'id' => $id ), $m );
				}
				$rows[] = array_merge( $r, array( 'text' => $tx, 'summary' => $sm ) );
			}
			$put( 'guide', ogc_coa_with_ids( $rows, 'g' ) );
			$log['parts']['packet'] = array( 'moved' => $moved, 'campus' => $swap ? (string) $c : '' );
		}

		// The campus's own: from the last Conference there (Help from last year when the campus is new).
		$help_src = $c ? $c : $p;
		$help     = ogc_coa_rows( $help_src, 'help' );
		if ( $help && $put( 'help', ogc_coa_with_ids( $help, 'h' ) ) ) {
			$log['parts']['help'] = array( 'from' => (string) $help_src );
			foreach ( ogc_coa_with_ids( $help, 'h' ) as $h ) {
				// Every carried card but the 911 one: phones, hours and places change most years.
				if ( '911' !== ( isset( $h['phone'] ) ? (string) $h['phone'] : '' ) && 'emergency' !== ( isset( $h['kind'] ) ? (string) $h['kind'] : '' ) ) {
					$log['confirm'][] = 'help:' . $h['_id'];
				}
			}
		}
		if ( $c ) {
			foreach ( array( 'places', 'nearby', 'rooms', 'plans', 'campus' ) as $n ) {
				if ( $put( $n, ogc_coa_rows( $c, $n ) ) ) {
					$log['parts'][ $n ] = array( 'from' => (string) $c );
				}
			}
			// The requests: what each committee had there last time, every row to answer again.
			$needs = array_map( function ( $r ) {
				return array_merge( $r, array( 'answer' => '', 'answered_by' => '', 'answered_as' => '', 'answered_at' => '', 'question' => '' ) );
			}, ogc_coa_rows( $c, 'needs' ) );
			if ( $put( 'needs', $needs ) ) {
				$log['parts']['needs'] = array( 'from' => (string) $c, 'n' => count( $needs ) );
			}
		}

		// The committees' shifts (places matched to the campus) and the tournaments (held).
		$shifts = ogc_coa_rows( $p, 'shifts' );
		if ( $shifts && ! ogc_coa_rows( $y, 'shifts' ) ) {
			$shifts    = ogc_coa_with_ids( $shifts, 's' );
			$unmatched = 0;
			if ( $c && $c !== $p ) {
				list( $shifts, $unmatched ) = ogc_coa_match_places( $shifts, ogc_coa_rows( $c, 'shifts' ), $new_places, function ( $r ) {
					return strtolower( ( isset( $r['committee'] ) ? $r['committee'] : '' ) . '|' . ( isset( $r['role'] ) ? $r['role'] : '' ) );
				} );
			}
			$put( 'shifts', $shifts );
			$log['parts']['shifts'] = array( 'n' => count( $shifts ), 'places' => $unmatched );
		}
		$tour = ogc_coa_rows( $p, 'tournaments' );
		if ( $tour && ! ogc_coa_rows( $y, 'tournaments' ) ) {
			$tour = array_map( function ( $t ) use ( $d ) {
				if ( isset( $t['opens'] ) && ogc_coa_iso( $t['opens'] ) ) {
					$t['opens'] = $d ? ogc_coa_add_days( $t['opens'], $d ) : '';
				}
				return $t;
			}, $tour );
			$put( 'tournaments', ogc_coa_with_ids( $tour, 't' ) );
			$log['parts']['tournaments'] = array( 'n' => count( $tour ) );
		}

		// The year's committees: one list every part reads.
		$coms = ogc_coa_committees_from( $p );
		if ( $put( 'committees', $coms ) ) {
			$log['parts']['committees'] = array( 'n' => count( $coms ) );
		}

		// Last year's due dates, moved with the Conference.
		if ( $d ) {
			$pc  = ogc_coa_state( $p );
			$due = array();
			foreach ( $pc['due'] as $part => $iso ) {
				if ( ogc_coa_iso( $iso ) ) {
					$due[ $part ] = ogc_coa_add_days( $iso, $d );
				}
			}
			if ( $due ) {
				ogc_coa_update( $y, function ( &$s ) use ( $due ) {
					$s['due'] = array_merge( $due, $s['due'] );
				} );
			}
		}

		$log['confirm'] = array_values( array_unique( $log['confirm'] ) );
		$cur            = ogc_state_get( $y, 'picked' );
		$v              = ogc_state_put( $y, 'picked', $log, $cur ? $cur['version'] : 0 );
		if ( is_wp_error( $v ) ) {
			return $v;
		}
		$n = array();
		foreach ( $log['parts'] as $k => $x ) {
			$n[ $k ] = isset( $x['n'] ) ? $x['n'] : 1;
		}
		ogc_log( 'year_pickup', $y, 'year', array( 'from' => $log['from'], 'campus' => $log['campus'], 'd' => $d, 'parts' => $n, 'early' => $log['early'] ) );
		return $log;
	} );
}

function ogc_coa_rest_pickup( WP_REST_Request $req ) {
	$y   = (int) $req['year'];
	$log = ogc_coa_pickup( $y, (bool) $req->get_param( 'force' ) );
	return is_wp_error( $log ) ? $log : rest_ensure_response( $log );
}

/**
 * Start a year (webmasters): it exists with its hosts and its own settings; its parts come from the
 * last Conference once that one has ended (or when the COA asks, on the year page).
 */
function ogc_coa_rest_start( WP_REST_Request $req ) {
	$y   = (int) $req['year'];
	$row = ogc_year_get( $y );
	$new = null === $row;
	$f   = array( 'data' => (string) $y );
	$h   = sanitize_text_field( (string) $req->get_param( 'hosts' ) );
	if ( $h ) {
		$f['hosts'] = $h;
	}
	// What the public knew of the year when it was started (its hosts, from the last Conference's
	// announcement): all it gets until the COA announces it (module-coa.php, ogc_coa_held_back).
	if ( ! ogc_state_get( $y, 'public_row' ) && ( $new || empty( $row['coa_announced'] ) ) ) {
		$known = (array) $row;
		ogc_state_put( $y, 'public_row', array_intersect_key( $known, array_flip( array( 'year', 'start', 'end', 'venue', 'city', 'hosts', 'data' ) ) ), 0 );
	}
	$row  = ogc_year_set( $y, $f );
	$prev = ogc_coa_prev_year( $y );
	if ( ! ogc_coa_rows( $y, 'settings' ) ) {
		$ps   = $prev ? ogc_coa_kv( (int) $prev['year'], 'settings' ) : array();
		$rows = array(
			array( 'key' => 'title', 'value' => $y . ' Annual Conference', 'help' => '' ),
			array( 'key' => 'year', 'value' => (string) $y, 'help' => '' ),
			array( 'key' => 'hosts', 'value' => isset( $row['hosts'] ) ? $row['hosts'] : '', 'help' => '' ),
			array( 'key' => 'timezone', 'value' => isset( $ps['timezone'] ) ? $ps['timezone'] : 'America/Indiana/Indianapolis', 'help' => '' ),
			array( 'key' => 'schedule_posted', 'value' => OGC_NOT_YET, 'help' => '' ),
			array( 'key' => 'packet_posted', 'value' => OGC_NOT_YET, 'help' => '' ),
			array( 'key' => 'signups_posted', 'value' => OGC_NOT_YET, 'help' => '' ),
			array( 'key' => 'registration_opens', 'value' => OGC_NOT_YET, 'help' => '' ),
		);
		ogc_file_put( $y, 'settings', $rows, 0 );
	}
	ogc_log( 'year_start', $y, 'years', array( 'new' => $new ) );
	$out = array( 'year' => ogc_year_get( $y ), 'picked' => null );
	if ( $prev && ogc_coa_is_over( (int) $prev['year'] ) ) {
		$log = ogc_coa_pickup( $y, false );
		if ( ! is_wp_error( $log ) ) {
			$out['picked'] = $log;
		}
	}
	// The app's committees and tasks, carried from last year: here, and only here (opening a year in
	// the app never sets it up; module-app.php, ogc_app_start_year).
	if ( function_exists( 'ogc_app_start_year' ) ) {
		ogc_app_start_year( $y );
	}
	return rest_ensure_response( $out );
}

/* ------------------------------------------------------------------ dates */

/**
 * The year's dates. Everything counted from the Friday moves with it: registration's dates (or their
 * suggestions), the dates written in the packet, the tournaments' opening days, the due dates. A
 * year that had no dates moves them from last year's, once. Without apply, says what would move.
 */
function ogc_coa_rest_dates( WP_REST_Request $req ) {
	$y     = (int) $req['year'];
	$start = (string) $req->get_param( 'start' );
	$end   = (string) $req->get_param( 'end' );
	$apply = (bool) $req->get_param( 'apply' );
	$row   = ogc_year_get( $y );
	if ( ! $row ) {
		return ogc_coa_bad( 'No such year', 404 );
	}
	if ( ! ogc_coa_iso( $start ) ) {
		return ogc_coa_bad( 'Not a date', 400, array( 'field' => 'start' ) );
	}
	$pick = ogc_state_get( $y, 'picked' );
	$pick = $pick ? (array) $pick['value'] : array();
	$was  = ! empty( $row['start'] ) ? $row['start'] : '';
	$from = (string) $y;
	if ( $was ) {
		$d = ogc_coa_days_between( $was, $start );
	} elseif ( ! empty( $pick['from'] ) && ogc_coa_first_day( (int) $pick['from'] ) ) {
		// Picked up before its dates were known: the year still has last year's, unmoved.
		$d    = ogc_coa_days_between( ogc_coa_first_day( (int) $pick['from'] ), $start );
		$from = (string) $pick['from'];
	} else {
		$d = 0;
	}
	if ( ! ogc_coa_iso( $end ) ) {
		$prev = ogc_coa_prev_year( $y );
		$len  = $was && ! empty( $row['end'] ) ? ogc_coa_days_between( $was, $row['end'] ) : ( $prev && $prev['start'] && $prev['end'] ? ogc_coa_days_between( $prev['start'], $prev['end'] ) : 4 );
		$end  = ogc_coa_add_days( $start, $len );
	} elseif ( $end < $start ) {
		return ogc_coa_bad( 'After the first day', 400, array( 'field' => 'end' ) );
	} elseif ( $was && ! empty( $row['end'] ) && $d && $end === $row['end'] ) {
		$end = ogc_coa_add_days( $row['end'], $d );
	}

	$R      = ogc_coa_kv( $y, 'registration' );
	$reg    = array();
	foreach ( array( 'opens', 'closes', 'refunds_by', 'cancel_by' ) as $k ) {
		$cur = isset( $R[ $k ] ) ? $R[ $k ] : '';
		if ( ogc_coa_iso( $cur ) && OGC_NOT_YET !== $cur && $was ) {
			$reg[ $k ] = array( 'from' => $cur, 'to' => ogc_coa_add_days( $cur, $d ) );
		} elseif ( ! empty( $pick['suggest'][ $k ]['from'] ) ) {
			// Dated: the suggestion moves on from where it is; undated: from last year's own date.
			$base      = $was && ! empty( $pick['suggest'][ $k ]['to'] ) ? $pick['suggest'][ $k ]['to'] : $pick['suggest'][ $k ]['from'];
			$reg[ $k ] = array( 'from' => $base, 'to' => ogc_coa_add_days( $base, $d ), 'suggest' => true );
		}
	}
	$guide  = ogc_coa_rows( $y, 'guide' );
	$gm     = array();
	$gnew   = array();
	foreach ( $guide as $r ) {
		list( $tx, $m1 ) = ogc_coa_move_text( isset( $r['text'] ) ? $r['text'] : '', $from, $d );
		list( $sm, $m2 ) = ogc_coa_move_text( isset( $r['summary'] ) ? $r['summary'] : '', $from, $d );
		foreach ( array_merge( $m1, $m2 ) as $m ) {
			$gm[] = array_merge( array( 'id' => isset( $r['id'] ) ? $r['id'] : '' ), $m );
		}
		$gnew[] = array_merge( $r, array( 'text' => $tx, 'summary' => $sm ) );
	}
	$tour  = ogc_coa_rows( $y, 'tournaments' );
	$tn    = 0;
	$tnew  = array_map( function ( $t ) use ( $d, &$tn ) {
		if ( $d && isset( $t['opens'] ) && ogc_coa_iso( $t['opens'] ) ) {
			$t['opens'] = ogc_coa_add_days( $t['opens'], $d );
			$tn++;
		}
		return $t;
	}, $tour );
	$days     = ogc_coa_day_names( $start, $end );
	$sched    = ogc_coa_rows( $y, 'schedule' );
	$used     = array_unique( array_filter( wp_list_pluck( $sched, 'day' ) ) );
	$empty    = array_values( array_diff( $days, $used ) );
	$dropped  = array_values( array_diff( $used, $days ) );
	$summary  = array( 'd' => $d, 'start' => $start, 'end' => $end, 'registration' => count( $reg ), 'packet' => count( $gm ), 'tournaments' => $tn, 'days' => $days, 'empty_days' => $d || ! $was ? $empty : array(), 'dropped_days' => $dropped, 'reg' => $reg );
	if ( ! $apply ) {
		return rest_ensure_response( $summary );
	}

	$res = ogc_coa_tx( function () use ( $y, $start, $end, $d, $reg, $gnew, $gm, $tnew, $tn, $days, $guide, $pick, $was ) {
		ogc_year_set( $y, array( 'start' => $start, 'end' => $end ) );
		ogc_coa_set( $y, 'settings', 'first_day', $start );
		ogc_coa_set( $y, 'settings', 'days', implode( '|', $days ) );
		foreach ( $reg as $k => $m ) {
			if ( empty( $m['suggest'] ) ) {
				ogc_coa_set( $y, 'registration', $k, $m['to'] );
				if ( 'opens' === $k || 'closes' === $k ) {
					ogc_coa_set( $y, 'settings', 'registration_' . $k, $m['to'] );
				}
			} elseif ( 'opens' !== $k ) {
				// Closing and credit dates aren't public by themselves: set; opening stays a suggestion.
				ogc_coa_set( $y, 'registration', $k, $m['to'] );
				if ( 'closes' === $k ) {
					ogc_coa_set( $y, 'settings', 'registration_closes', $m['to'] );
				}
			}
		}
		if ( $gm ) {
			$f = ogc_file_get( $y, 'guide' );
			ogc_file_put( $y, 'guide', $gnew, $f ? $f['version'] : 0 );
		}
		if ( $tn ) {
			$f = ogc_file_get( $y, 'tournaments' );
			ogc_file_put( $y, 'tournaments', $tnew, $f ? $f['version'] : 0 );
		}
		if ( $d ) {
			ogc_coa_update( $y, function ( &$s ) use ( $d ) {
				foreach ( $s['due'] as $part => $iso ) {
					if ( ogc_coa_iso( $iso ) ) {
						$s['due'][ $part ] = ogc_coa_add_days( $iso, $d );
					}
				}
			} );
		}
		if ( $pick ) {
			$pick['d']       = ( isset( $pick['d'] ) ? (int) $pick['d'] : 0 ) + $d;
			$pick['undated'] = false;
			// "From" stays the source year's own date (what "2027: May 21" beside a field says), however
			// often the dates move again.
			$first = array();
			foreach ( isset( $pick['parts']['registration']['moved'] ) ? (array) $pick['parts']['registration']['moved'] : array() as $m0 ) {
				if ( isset( $m0['k'] ) && ! isset( $first[ $m0['k'] ] ) ) {
					$first[ $m0['k'] ] = isset( $m0['from'] ) ? $m0['from'] : '';
				}
			}
			foreach ( $reg as $k => $m ) {
				$src = ! empty( $pick['suggest'][ $k ]['from'] ) ? $pick['suggest'][ $k ]['from'] : ( ! empty( $first[ $k ] ) ? $first[ $k ] : $m['from'] );
				$pick['suggest'][ $k ] = array( 'from' => $src, 'to' => $m['to'] );
				$first[ $k ]           = $src;
			}
			$pick['parts']['registration']['moved'] = array_values( array_map( function ( $k, $m ) use ( $first ) {
				return array( 'k' => $k, 'from' => $first[ $k ], 'to' => $m['to'] );
			}, array_keys( $reg ), $reg ) );
			if ( $gm ) {
				$pick['parts']['packet']['moved'] = $gm;
			}
			$cur = ogc_state_get( $y, 'picked' );
			ogc_state_put( $y, 'picked', $pick, $cur ? $cur['version'] : 0 );
		}
		ogc_log( 'dates', $y, 'year', array( 'part' => 'conference', 'd' => $d, 'start' => $start, 'end' => $end, 'moved' => array( 'registration' => count( $reg ), 'packet' => count( $gm ), 'tournaments' => $tn ) ) );
		return true;
	} );
	if ( is_wp_error( $res ) ) {
		return $res;
	}
	$summary['applied'] = true;
	return rest_ensure_response( $summary );
}

/* ------------------------------------------------------------------ the campus */

const OGC_COA_CAMPUS_FILES = array( 'places', 'nearby', 'rooms', 'plans', 'campus', 'help' );

/** What changing the campus would bring and replace. */
function ogc_coa_campus_plan( $y, $venue, $new ) {
	$row   = ogc_year_get( $y );
	$c     = $new ? 0 : ogc_coa_campus_year( $y, $venue );
	$known = null;
	foreach ( ogc_years_all() as $r ) {
		if ( ! $new && isset( $r['venue'] ) && strtolower( $r['venue'] ) === strtolower( $venue ) ) {
			$known = $r;
			break;
		}
	}
	$places  = $c ? ogc_coa_rows( $c, 'places' ) : array();
	$needs   = ogc_coa_rows( $y, 'needs' );
	$answered = count( array_filter( $needs, function ( $r ) {
		return ! empty( $r['answer'] );
	} ) );
	$codes = array();
	foreach ( $places as $p ) {
		$codes[ strtoupper( isset( $p['code'] ) ? $p['code'] : '' ) ] = 1;
	}
	$unmatched = function ( $rows ) use ( $codes ) {
		$n = 0;
		foreach ( $rows as $r ) {
			if ( ! empty( $r['place'] ) && ! isset( $codes[ strtoupper( strtok( $r['place'], '/' ) ) ] ) && ! isset( $codes[ strtoupper( $r['place'] ) ] ) ) {
				$n++;
			}
		}
		return $n;
	};
	$cur_places = ogc_coa_rows( $y, 'places' );
	$halls      = function ( $rows ) {
		return count( array_unique( array_filter( wp_list_pluck( $rows, 'hall' ) ) ) );
	};
	$cparts = array();
	foreach ( $c ? ogc_coa_rows( $c, 'guide' ) : array() as $r ) {
		if ( in_array( isset( $r['id'] ) ? $r['id'] : '', OGC_COA_CAMPUS_PARTS, true ) && ! empty( $r['title'] ) ) {
			$cparts[] = $r['title'];
		}
	}
	$CR     = $c ? ogc_coa_kv( $c, 'registration' ) : array();
	$R      = ogc_coa_kv( $y, 'registration' );
	$prices = array();
	foreach ( OGC_COA_VENUE_KEYS as $k ) {
		if ( $c && ( isset( $CR[ $k ] ) ? $CR[ $k ] : '' ) !== ( isset( $R[ $k ] ) ? $R[ $k ] : '' ) ) {
			$prices[] = $k;
		}
	}
	return array(
		'venue'     => $new ? $new['name'] : ( $known ? $known['venue'] : $venue ),
		'city'      => $new ? $new['city'] : ( $known && isset( $known['city'] ) ? $known['city'] : '' ),
		'from'      => $c ? (string) $c : '',
		'new'       => ! $c,
		'brings'    => array( 'places' => count( $places ), 'halls' => $c ? $halls( ogc_coa_rows( $c, 'rooms' ) ) : 0, 'help' => $c ? count( ogc_coa_rows( $c, 'help' ) ) : 0, 'nearby' => $c ? count( ogc_coa_rows( $c, 'nearby' ) ) : 0, 'map' => $c && ogc_coa_rows( $c, 'campus' ) ? 1 : 0, 'prices' => $prices, 'needs' => $c && ! $answered ? count( ogc_coa_rows( $c, 'needs' ) ) : 0, 'packet' => $cparts ),
		'replaces'  => array( 'venue' => $row && isset( $row['venue'] ) ? $row['venue'] : '', 'places' => count( $cur_places ), 'halls' => $halls( ogc_coa_rows( $y, 'rooms' ) ), 'help' => count( ogc_coa_rows( $y, 'help' ) ), 'pins' => count( array_filter( $cur_places, function ( $r ) {
			return isset( $r['x'] ) && '' !== $r['x'];
		} ) ), 'needs_answered' => $answered, 'needs' => count( $needs ) ),
		'unmatched' => array( 'schedule' => $unmatched( ogc_coa_rows( $y, 'schedule' ) ), 'shifts' => $unmatched( ogc_coa_rows( $y, 'shifts' ) ) ),
	);
}

function ogc_coa_rest_campus( WP_REST_Request $req ) {
	$y     = (int) $req['year'];
	$row   = ogc_year_get( $y );
	$venue = trim( sanitize_text_field( (string) $req->get_param( 'venue' ) ) );
	$newp  = $req->get_param( 'new' );
	$new   = null;
	if ( is_array( $newp ) ) {
		$new = array(
			'name'    => mb_substr( trim( sanitize_text_field( isset( $newp['name'] ) ? (string) $newp['name'] : '' ) ), 0, 80 ),
			'city'    => mb_substr( trim( sanitize_text_field( isset( $newp['city'] ) ? (string) $newp['city'] : '' ) ), 0, 80 ),
			'address' => mb_substr( trim( sanitize_text_field( isset( $newp['address'] ) ? (string) $newp['address'] : '' ) ), 0, 160 ),
		);
		if ( '' === $new['name'] ) {
			return ogc_coa_bad( 'Name', 400, array( 'field' => 'name' ) );
		}
		// A campus the Conference has used is picked up from its last Conference after all.
		foreach ( ogc_years_all() as $r ) {
			if ( isset( $r['venue'] ) && strtolower( $r['venue'] ) === strtolower( $new['name'] ) ) {
				$venue = $r['venue'];
				$new   = null;
				break;
			}
		}
	}
	if ( ! $new && '' === $venue ) {
		return ogc_coa_bad( 'Choose a campus' );
	}
	$name = $new ? $new['name'] : $venue;
	if ( $row && isset( $row['venue'] ) && strtolower( $row['venue'] ) === strtolower( $name ) ) {
		return ogc_coa_bad( 'Already chosen', 409 );
	}
	$plan = ogc_coa_campus_plan( $y, $venue, $new );
	if ( ! $req->get_param( 'apply' ) ) {
		return rest_ensure_response( $plan );
	}
	$c = $plan['from'] ? (int) $plan['from'] : 0;
	$res = ogc_coa_tx( function () use ( $y, $row, $c, $plan, $new ) {
		// What's replaced is kept, so Restore can put it back.
		$snap = array( 'at' => ogc_coa_today( $y ), 'by' => ogc_coa_first_l( get_current_user_id() ), 'venue_from' => $row && isset( $row['venue'] ) ? $row['venue'] : '', 'venue_to' => $plan['venue'], 'row' => array( 'venue' => $row && isset( $row['venue'] ) ? $row['venue'] : '', 'city' => $row && isset( $row['city'] ) ? $row['city'] : '' ), 'files' => array(), 'settings' => array(), 'reg' => array() );
		foreach ( array_merge( OGC_COA_CAMPUS_FILES, array( 'needs', 'schedule', 'shifts', 'guide' ) ) as $n ) {
			$snap['files'][ $n ] = ogc_coa_rows( $y, $n );
		}
		$S = ogc_coa_kv( $y, 'settings' );
		foreach ( array( 'venue', 'city', 'address', 'directions', 'timezone', 'timezone_label', 'print_required' ) as $k ) {
			$snap['settings'][ $k ] = isset( $S[ $k ] ) ? $S[ $k ] : '';
		}
		$R = ogc_coa_kv( $y, 'registration' );
		foreach ( OGC_COA_VENUE_KEYS as $k ) {
			$snap['reg'][ $k ] = isset( $R[ $k ] ) ? $R[ $k ] : null;
		}
		$cur = ogc_state_get( $y, 'campus_undo' );
		ogc_state_put( $y, 'campus_undo', $snap, $cur ? $cur['version'] : 0 );

		$write = function ( $n, $rows ) use ( $y ) {
			$f = ogc_file_get( $y, $n );
			return ogc_file_put( $y, $n, array_values( $rows ), $f ? $f['version'] : 0 );
		};
		ogc_year_set( $y, array( 'venue' => $plan['venue'], 'city' => $plan['city'] ) );
		$CS = $c ? ogc_coa_kv( $c, 'settings' ) : array();
		ogc_coa_set( $y, 'settings', 'venue', $plan['venue'] );
		ogc_coa_set( $y, 'settings', 'city', $c && ! empty( $CS['city'] ) ? $CS['city'] : $plan['city'] );
		ogc_coa_set( $y, 'settings', 'address', $new ? $new['address'] : ( isset( $CS['address'] ) ? $CS['address'] : '' ) );
		ogc_coa_set( $y, 'settings', 'directions', $c && isset( $CS['directions'] ) ? $CS['directions'] : '' );
		// The campus's printed line goes with the campus (a new one starts with none).
		ogc_coa_set( $y, 'settings', 'print_required', $c && isset( $CS['print_required'] ) ? $CS['print_required'] : '' );
		foreach ( array( 'timezone', 'timezone_label' ) as $k ) {
			if ( ! empty( $CS[ $k ] ) ) {
				ogc_coa_set( $y, 'settings', $k, $CS[ $k ] );
			}
		}
		$places = $c ? ogc_coa_rows( $c, 'places' ) : array();
		foreach ( OGC_COA_CAMPUS_FILES as $n ) {
			$rows = $c ? ogc_coa_rows( $c, $n ) : array();
			if ( 'help' === $n ) {
				// A known campus brings its own Help cards; otherwise the cards stay, each to check.
				$rows = $rows ? ogc_coa_with_ids( $rows, 'h' ) : ogc_coa_rows( $y, 'help' );
			}
			$write( $n, $rows );
		}
		if ( $c ) {
			$CR = ogc_coa_kv( $c, 'registration' );
			foreach ( OGC_COA_VENUE_KEYS as $k ) {
				if ( isset( $CR[ $k ] ) ) {
					ogc_coa_set( $y, 'registration', $k, $CR[ $k ] );
				}
			}
		}
		// The packet's campus parts (staying, arriving, campers, getting around) from the last
		// Conference there, their dates moved to this year's.
		if ( $c && $plan['brings']['packet'] ) {
			$cd   = ogc_coa_first_day( $c ) && ogc_coa_first_day( $y ) ? ogc_coa_days_between( ogc_coa_first_day( $c ), ogc_coa_first_day( $y ) ) : 0;
			$swap = array();
			foreach ( ogc_coa_rows( $c, 'guide' ) as $r ) {
				if ( in_array( isset( $r['id'] ) ? $r['id'] : '', OGC_COA_CAMPUS_PARTS, true ) ) {
					list( $tx ) = ogc_coa_move_text( isset( $r['text'] ) ? $r['text'] : '', $c, $cd );
					list( $sm ) = ogc_coa_move_text( isset( $r['summary'] ) ? $r['summary'] : '', $c, $cd );
					$swap[ $r['id'] ][] = array_merge( $r, array( 'text' => $tx, 'summary' => $sm, '_from' => (string) $c ) );
				}
			}
			$out  = array();
			$done = array();
			foreach ( ogc_coa_rows( $y, 'guide' ) as $r ) {
				$id = isset( $r['id'] ) ? $r['id'] : '';
				if ( isset( $swap[ $id ] ) ) {
					if ( empty( $done[ $id ] ) ) {
						$out         = array_merge( $out, $swap[ $id ] );
						$done[ $id ] = 1;
					}
					continue;
				}
				$out[] = $r;
			}
			$write( 'guide', ogc_coa_with_ids( $out, 'g' ) );
		}
		// The requests come from the new campus while nobody has answered any here.
		if ( ! $plan['replaces']['needs_answered'] ) {
			$write( 'needs', array_map( function ( $r ) {
				return array_merge( $r, array( 'answer' => '', 'answered_by' => '', 'answered_as' => '', 'answered_at' => '', 'question' => '' ) );
			}, $c ? ogc_coa_rows( $c, 'needs' ) : array() ) );
		}
		// The week's and the shifts' places: matched at the new campus, or marked to choose.
		$cs = $c ? ogc_coa_rows( $c, 'schedule' ) : array();
		list( $sched ) = ogc_coa_match_places( ogc_coa_rows( $y, 'schedule' ), $cs, $places, function ( $r ) {
			return strtolower( trim( isset( $r['title'] ) ? $r['title'] : '' ) );
		} );
		$write( 'schedule', $sched );
		list( $shifts ) = ogc_coa_match_places( ogc_coa_rows( $y, 'shifts' ), $c ? ogc_coa_rows( $c, 'shifts' ) : array(), $places, function ( $r ) {
			return strtolower( ( isset( $r['committee'] ) ? $r['committee'] : '' ) . '|' . ( isset( $r['role'] ) ? $r['role'] : '' ) );
		} );
		$write( 'shifts', $shifts );
		// The pickup log says where each campus part came from now, and the prices wait to be checked.
		$pc   = ogc_state_get( $y, 'picked' );
		$pick = $pc ? (array) $pc['value'] : array( 'parts' => array() );
		foreach ( OGC_COA_CAMPUS_FILES as $n ) {
			$pick['parts'][ $n ] = array( 'from' => $c ? (string) $c : '' );
		}
		$pick['campus']    = $c ? (string) $c : '';
		$pick['confirm']   = array_values( array_unique( array_merge( isset( $pick['confirm'] ) ? (array) $pick['confirm'] : array(), array( 'reg:prices', 'conf:campus' ) ) ) );
		ogc_state_put( $y, 'picked', $pick, $pc ? $pc['version'] : 0 );
		ogc_coa_update( $y, function ( &$s ) {
			unset( $s['checks']['reg:prices'], $s['checks']['conf:campus'] );
		} );
		ogc_log( 'campus', $y, 'year', array( 'part' => 'conference', 'what' => 'change', 'to' => $plan['venue'], 'from_year' => $plan['from'] ) );
		return true;
	} );
	if ( is_wp_error( $res ) ) {
		return $res;
	}
	$plan['applied'] = true;
	return rest_ensure_response( $plan );
}

/** The campus as it was before the last change (one step back). */
function ogc_coa_rest_campus_restore( WP_REST_Request $req ) {
	$y    = (int) $req['year'];
	$s    = ogc_state_get( $y, 'campus_undo' );
	$snap = $s ? (array) $s['value'] : array();
	if ( empty( $snap['files'] ) ) {
		return ogc_coa_bad( 'Nothing to restore', 404 );
	}
	$res = ogc_coa_tx( function () use ( $y, $snap, $s ) {
		foreach ( $snap['files'] as $n => $rows ) {
			$f = ogc_file_get( $y, $n );
			ogc_file_put( $y, $n, array_values( (array) $rows ), $f ? $f['version'] : 0 );
		}
		foreach ( $snap['settings'] as $k => $v ) {
			ogc_coa_set( $y, 'settings', $k, (string) $v );
		}
		foreach ( $snap['reg'] as $k => $v ) {
			if ( null !== $v ) {
				ogc_coa_set( $y, 'registration', $k, (string) $v );
			}
		}
		ogc_year_set( $y, $snap['row'] );
		ogc_state_put( $y, 'campus_undo', null, $s['version'] );
		ogc_log( 'campus', $y, 'year', array( 'part' => 'conference', 'what' => 'restore', 'to' => $snap['venue_from'] ) );
		return true;
	} );
	return is_wp_error( $res ) ? $res : rest_ensure_response( array( 'restored' => $snap['venue_from'] ) );
}

/** The last campus change, for the page's Restore. */
function ogc_coa_undo_summary( $y ) {
	$s = ogc_state_get( $y, 'campus_undo' );
	$v = $s ? $s['value'] : null;
	return is_array( $v ) && ! empty( $v['files'] ) ? array( 'from' => $v['venue_from'], 'to' => $v['venue_to'], 'at' => $v['at'], 'by' => $v['by'] ) : null;
}
