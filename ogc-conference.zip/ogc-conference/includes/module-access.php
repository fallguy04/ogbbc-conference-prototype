<?php
/**
 * Privacy (access area, Oct 13–14): the app's screen that shows who sees people's details in a year,
 * worked out from the same rule every route asks (module-guard.php ogc_access_for), and that every See
 * as and privacy request is logged.
 *
 *   Who        the year's COA (names), and the webmasters (counts: they see structure, not people)
 *   Screen     app/?s=privacy (assets/app/screens/privacy.js, privacy.css)
 *   Route      GET app/{y}/privacy → {viewer, rules: [{key, what, detail, n, groups: [{label, n, names}]}],
 *              money: {n, names}, webmasters: {n, names}, on_year: [{who, as, by, when, id}] (webmasters
 *              who are on the year), seen_as: [{when, who, as}], requests: [{when, what, who}]}
 *
 * Nothing here changes anything; who is on which committee is the COA's (Members), and Handles money is
 * ticked there too (module-members.php).
 */

defined( 'ABSPATH' ) || exit;

add_filter( 'ogc_app_screens', function ( $s, $year ) {
	$s['privacy'] = array( 'title' => 'Privacy', 'section' => 'own', 'who' => array( 'coa', 'webmaster' ), 'handable' => false, 'icon' => 'eye' );
	return $s;
}, 40, 2 );

add_filter( 'ogc_pages', function ( $p ) {
	if ( isset( $p['app'] ) ) {
		$p['app']['styles'][]  = 'app/screens/privacy.css';
		$p['app']['scripts'][] = 'app/screens/privacy.js';
	}
	return $p;
}, 25 );

add_action( 'rest_api_init', function () {
	register_rest_route( OGC_NS, '/app/(?P<year>\d{4})/privacy', array(
		'methods'             => 'GET',
		'callback'            => 'ogc_access_rest_privacy',
		'permission_callback' => function ( WP_REST_Request $req ) {
			if ( ! function_exists( 'ogc_app_req_viewer' ) || ! is_user_logged_in() ) {
				return ogc_rest_denied( 'Sign in first.' );
			}
			return ogc_app_can_see( ogc_app_req_viewer( $req ), 'privacy' ) ? true : ogc_rest_denied();
		},
	) );
} );

/** A member of the year as the app's viewer would be (never a webmaster, never seeing as). */
function ogc_access_member_viewer( $year, $m ) {
	$keys = 'coa' === $m['role'] ? array() : array_values( array_filter( ogc_member_committee_keys( $m ), function ( $k ) use ( $year ) {
		return (bool) ogc_app_committee( (int) $year, $k );
	} ) );
	return array( 'year' => (int) $year, 'coa' => 'coa' === $m['role'], 'webmaster' => false, 'committees' => $keys, 'head' => (bool) $m['head'], 'member_id' => (int) $m['id'], 'as' => '', 'open' => true );
}

/** When, in the site's time zone: "Oct 13 · 9:14 PM". */
function ogc_access_when( $utc ) {
	$t = strtotime( (string) $utc . ' UTC' );
	return $t ? wp_date( 'M j · g:i A', $t ) : '';
}

function ogc_access_rest_privacy( WP_REST_Request $req ) {
	$y     = (int) $req['year'];
	$v     = ogc_app_req_viewer( $req );
	$names = ! empty( $v['coa'] );   // the COA sees who; a webmaster sees how many
	$out   = array();
	$mems  = array_values( array_filter( ogc_members_list( $y ), 'ogc_member_active' ) );
	foreach ( ogc_access_rules() as $rule ) {
		$groups = array();
		foreach ( $mems as $m ) {
			$mv = ogc_access_member_viewer( $y, $m );
			if ( ! ogc_access_for( $mv, $y, $rule['key'], $m['email'] ) ) {
				continue;
			}
			// The place that gives it: the COA, else each of their committees that does, else the tick.
			$labels = array();
			if ( $mv['coa'] ) {
				$labels[] = 'COA';
			} else {
				foreach ( $mv['committees'] as $k ) {
					if ( ogc_access_for( array_merge( $mv, array( 'committees' => array( $k ) ) ), $y, $rule['key'], '' ) ) {
						$c        = ogc_app_committee( $y, $k );
						$labels[] = $c ? $c['name'] : $k;
					}
				}
				if ( ! $labels ) {
					$labels[] = 'Handles money';
				}
			}
			if ( 'money' === $rule['key'] ) {
				$labels = array( 'Handles money' );
			}
			foreach ( $labels as $l ) {
				$groups[ $l ][] = ogc_app_person_name( $m );
			}
		}
		$list = array();
		foreach ( $groups as $label => $who ) {
			sort( $who );
			$list[] = array( 'label' => $label, 'n' => count( $who ), 'names' => $names ? $who : array() );
		}
		// The COA first, then the committees A–Z, then the tick.
		usort( $list, function ( $a, $b ) {
			$r = function ( $l ) {
				return 'COA' === $l ? 0 : ( 'Handles money' === $l ? 2 : 1 );
			};
			return $r( $a['label'] ) - $r( $b['label'] ) ?: strcmp( $a['label'], $b['label'] );
		} );
		$n = 0;
		foreach ( $list as $g ) {
			$n += $g['n'];
		}
		$out[] = array_merge( $rule, array( 'groups' => $list, 'n' => $n ) );
	}
	$money = array();
	foreach ( $mems as $m ) {
		if ( ogc_member_handles_money( $y, $m['email'] ) ) {
			$money[] = ogc_app_person_name( $m );
		}
	}
	$wms = array();
	if ( function_exists( 'ogc_webmasters' ) ) {
		foreach ( ogc_webmasters() as $w ) {
			$n     = ogc_person_name( $w['user']->ID );
			$wms[] = $n ? ogc_first_l( $n ) : ( $w['user']->display_name ? ogc_first_l( $w['user']->display_name ) : 'A webmaster' );
		}
	}
	// Webmasters who are on the year too (the COA, or a committee): they see what that place sees, not
	// only by See as. Nobody can add their own address; another webmaster or the COA added them, and the
	// COA can remove them on Members (critique, Oct 14).
	$on_year = array();
	foreach ( $mems as $m ) {
		if ( function_exists( 'ogc_member_is_webmaster_row' ) && ogc_member_is_webmaster_row( $m ) ) {
			$on_year[] = array(
				'who'  => ogc_app_person_name( $m ),
				'as'   => 'coa' === $m['role'] ? 'COA' : ogc_member_role_words( $m ),
				'by'   => $m['invited_by'] ? ogc_app_user_name( (int) $m['invited_by'], $y ) : '',
				'when' => $m['invited_at'] ? ogc_access_when( $m['invited_at'] ) : '',
				'id'   => (int) $m['id'],
			);
		}
	}
	// Every See as in the last 30 days, and every privacy request this year (who ran it, never whose).
	global $wpdb;
	$t    = ogc_table( 'log' );
	$seen = array();
	foreach ( (array) $wpdb->get_results( $wpdb->prepare( "SELECT at, user, target FROM $t WHERE year = %d AND action = 'app_see_as' AND at > %s ORDER BY id DESC LIMIT 20", $y, gmdate( 'Y-m-d H:i:s', time() - 30 * DAY_IN_SECONDS ) ), ARRAY_A ) as $r ) { // phpcs:ignore -- table name.
		$k      = preg_replace( '/^committee:/', '', (string) $r['target'] );
		$c      = 'coa' === $k ? null : ogc_app_committee( $y, $k );
		$seen[] = array( 'when' => ogc_access_when( $r['at'] ), 'who' => ogc_app_user_name( (int) $r['user'], $y ), 'as' => 'coa' === $k ? 'COA' : ( $c ? $c['name'] : $k ), 'wm' => ogc_is_webmaster( (int) $r['user'] ) );
	}
	$asks = array();
	foreach ( (array) $wpdb->get_results( $wpdb->prepare( "SELECT at, user, action FROM $t WHERE year = 0 AND action IN ('privacy_export','privacy_erase') AND at > %s ORDER BY id DESC LIMIT 20", gmdate( 'Y-m-d H:i:s', time() - 365 * DAY_IN_SECONDS ) ), ARRAY_A ) as $r ) { // phpcs:ignore -- table name.
		$asks[] = array( 'when' => ogc_access_when( $r['at'] ), 'what' => 'privacy_erase' === $r['action'] ? 'Erase' : 'Export', 'who' => ogc_app_user_name( (int) $r['user'], $y ) );
	}
	return rest_ensure_response( array(
		'viewer'     => array( 'coa' => ! empty( $v['coa'] ), 'webmaster' => ! empty( $v['webmaster'] ), 'names' => $names ),
		'rules'      => $out,
		'money'      => array( 'n' => count( $money ), 'names' => $names ? $money : array() ),
		'webmasters' => array( 'n' => count( $wms ), 'names' => $wms ),
		'on_year'    => $on_year,
		'seen_as'    => $seen,
		'requests'   => $asks,
	) );
}
