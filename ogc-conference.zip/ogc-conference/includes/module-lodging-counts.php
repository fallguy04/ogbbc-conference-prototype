<?php
/**
 * Lodging's Counts (Round 5, Oct 17; docs/27-back-end-map/area-lodging §8): what the campus needs two
 * weeks before (each night's rooms by hall, Young Folks by hall, campers, linens, mattresses, keys), the
 * rooming list and the room setup list, on one screen (assets/app/screens/committee-lodging-counts.js,
 * `lod-counts`), sent once with a kept copy.
 *
 *   Mark sent     POST years/{y}/lodging/sent {to, what: 'counts,rooming', day, copy} keeps a copy of what
 *                 was ticked, exactly as it was drawn (the counts, the rooming list with key holders only,
 *                 the setup list), as meta:sent:<n>. It emails no one: Lodging sends the file the way the
 *                 campus wants it. Every send is kept; a later one never replaces an earlier one.
 *   Undo          DELETE years/{y}/lodging/sent/{n}: the sender's own, the same day.
 *   Download      GET years/{y}/lodging/sent/{n}?format=xlsx: the copy as sent (and a Columns sheet).
 *
 * ogc_lod_sent( $y ) is the one place the sends are read: the screen (GET years/{y}/lodging `sent`), the
 * COA's Final counts line and Lodging's hand-off to the campus (module-app-line.php), Lodging's Work row
 * and need, and the task "Final counts and dorm keys" (lod_counts), which ticks itself from the newest.
 */

defined( 'ABSPATH' ) || exit;

/** Every send, newest first: [{n, day, by, to, what: [..], at, copy}]. */
function ogc_lod_sent( $y ) {
	$out = array();
	foreach ( ogc_lod_rows( (int) $y, 'meta:sent:' ) as $k => $r ) {
		$d     = (array) $r['data'];
		$out[] = array(
			'n'    => (int) substr( $k, 10 ),
			'day'  => isset( $d['day'] ) ? (string) $d['day'] : substr( (string) $r['at'], 0, 10 ),
			'by'   => isset( $d['by'] ) ? (string) $d['by'] : '',
			'uid'  => (int) $r['by'],
			'to'   => isset( $d['to'] ) ? (string) $d['to'] : '',
			'what' => array_values( (array) ( isset( $d['what'] ) ? $d['what'] : array() ) ),
			'at'   => (string) $r['at'],
			'copy' => isset( $d['copy'] ) ? $d['copy'] : null,
		);
	}
	usort( $out, function ( $a, $b ) { return $b['n'] - $a['n']; } );
	return $out;
}

/** When Lodging's counts are due: its task "Final counts and dorm keys", else two weeks before the first day. */
function ogc_lod_counts_due( $y ) {
	if ( function_exists( 'ogc_app_tasks' ) ) {
		foreach ( ogc_app_tasks( (int) $y, array( 'lodging' ) ) as $t ) {
			if ( 'lod_counts' === $t['kind'] && ! empty( $t['due'] ) ) {
				return (string) $t['due'];
			}
		}
	}
	$row = ogc_year_get( (int) $y );
	return $row && ! empty( $row['start'] ) ? ogc_lod_add_days( $row['start'], -14 ) : '';
}

/** Counts' season (area-lodging L19): from two weeks before they're due ("May 1" for May 14). */
function ogc_lod_counts_opens( $y ) {
	$due = ogc_lod_counts_due( $y );
	return $due ? ogc_lod_add_days( $due, -13 ) : '';
}

/** Where Counts stands, in words: "Due May 14 · Not sent", "Sent May 12". */
function ogc_lod_counts_line( $y ) {
	$sent = ogc_lod_sent( $y );
	if ( $sent ) {
		return 'Sent ' . ogc_lod_md( $sent[0]['day'] );
	}
	$due = ogc_lod_counts_due( $y );
	return ( $due ? 'Due ' . ogc_lod_md( $due ) . ' · ' : '' ) . 'Not sent';
}

function ogc_lod_md( $iso ) {
	$t = strtotime( (string) $iso . ' 12:00:00 UTC' );
	return $t ? gmdate( 'M j', $t ) : '';
}

/* ================================================================== routes */

add_action( 'rest_api_init', function () {
	$Y = '(?P<year>\d{4})';
	register_rest_route( OGC_NS, "/years/$Y/lodging/sent", array(
		array( 'methods' => 'POST', 'callback' => 'ogc_lod_rest_sent', 'permission_callback' => 'ogc_lod_can' ),
	) );
	register_rest_route( OGC_NS, "/years/$Y/lodging/sent/(?P<n>\d{1,4})", array(
		array( 'methods' => 'GET', 'callback' => 'ogc_lod_rest_sent_get', 'permission_callback' => 'ogc_lod_can' ),
		array( 'methods' => 'DELETE', 'callback' => 'ogc_lod_rest_sent_undo', 'permission_callback' => 'ogc_lod_can' ),
	) );
} );

/** A table as it was drawn: { head: [..], rows: [[..]..], totals?: [[label, n]..] }, cells plain text or numbers. */
function ogc_lod_copy_table( $t ) {
	if ( ! is_array( $t ) ) {
		return null;
	}
	$cell = function ( $v ) {
		if ( is_int( $v ) || is_float( $v ) ) {
			return $v;
		}
		return is_scalar( $v ) ? mb_substr( wp_strip_all_tags( (string) $v ), 0, 80 ) : '';
	};
	$rows = function ( $list, $max ) use ( $cell ) {
		$out = array();
		foreach ( array_slice( (array) $list, 0, $max ) as $r ) {
			$out[] = array_map( $cell, array_slice( array_values( (array) $r ), 0, 24 ) );
		}
		return $out;
	};
	$out = array(
		'head' => array_map( $cell, array_slice( array_values( (array) ( isset( $t['head'] ) ? $t['head'] : array() ) ), 0, 24 ) ),
		'rows' => $rows( isset( $t['rows'] ) ? $t['rows'] : array(), 800 ),
	);
	if ( isset( $t['totals'] ) ) {
		$out['totals'] = $rows( $t['totals'], 12 );
	}
	return $out;
}

/** POST years/{y}/lodging/sent {to, what, day, copy} → {send, sent}. */
function ogc_lod_rest_sent( WP_REST_Request $req ) {
	$y     = (int) $req['year'];
	$today = ogc_lod_today( $y, $req );
	$ph    = ogc_lod_phase( $y, $today );
	if ( $ph['cleared'] ) {
		return ogc_lod_err( 'ogc_held', 'Names cleared · No changes', 403 );
	}
	$to = mb_substr( trim( wp_strip_all_tags( (string) $req->get_param( 'to' ) ) ), 0, 80 );
	if ( '' === $to ) {
		return ogc_lod_err( 'ogc_invalid', 'Choose who', 400, array( 'field' => 'to' ) );
	}
	// One value (the plugin's params rule): "counts,rooming".
	$what = array_values( array_intersect( array( 'counts', 'rooming' ), array_map( 'trim', explode( ',', (string) $req->get_param( 'what' ) ) ) ) );
	if ( ! $what ) {
		return ogc_lod_err( 'ogc_invalid', 'Tick what was sent', 400, array( 'field' => 'what' ) );
	}
	$day = substr( (string) $req->get_param( 'day' ), 0, 10 );
	$day = preg_match( '/^\d{4}-\d\d-\d\d$/', $day ) && $day <= $today ? $day : $today;
	$in   = (array) $req->get_param( 'copy' );
	$copy = array();
	foreach ( array( 'counts', 'rooming', 'setup' ) as $k ) {
		// What was ticked, as it was drawn; the setup list goes with the counts (the set-up crew's).
		if ( ( in_array( $k, $what, true ) || ( 'setup' === $k && in_array( 'counts', $what, true ) ) ) && isset( $in[ $k ] ) ) {
			$copy[ $k ] = ogc_lod_copy_table( $in[ $k ] );
		}
	}
	if ( strlen( (string) wp_json_encode( $copy ) ) > 250000 ) {
		return ogc_lod_err( 'ogc_bad', 'Too big to keep', 400 );
	}
	$sent = ogc_lod_sent( $y );
	$n    = $sent ? $sent[0]['n'] + 1 : 1;
	$r    = ogc_lod_put( $y, 'meta:sent:' . $n, array( 'day' => $day, 'by' => ogc_lod_me(), 'to' => $to, 'what' => $what, 'copy' => $copy ), 0 );
	if ( is_wp_error( $r ) ) {
		return ogc_lod_err( 'ogc_conflict', 'Sent by another member just now · Reload', 409 );
	}
	ogc_log( 'lodging_sent', $y, 'counts', array( 'n' => $n, 'what' => $what ) );
	$all = ogc_lod_sent( $y );
	return rest_ensure_response( array( 'send' => $all[0], 'sent' => $all, 'say' => 'Marked sent · ' . $to ) );
}

/** DELETE years/{y}/lodging/sent/{n}: Undo, by its sender, the same day. */
function ogc_lod_rest_sent_undo( WP_REST_Request $req ) {
	$y   = (int) $req['year'];
	$n   = (int) $req['n'];
	$row = ogc_lod_row( $y, 'meta:sent:' . $n );
	if ( ! $row ) {
		return ogc_lod_err( 'ogc_gone', 'Nothing to undo', 404 );
	}
	if ( (int) $row['by'] !== get_current_user_id() || substr( (string) $row['at'], 0, 10 ) !== substr( ogc_now(), 0, 10 ) ) {
		return ogc_lod_err( 'ogc_cant_undo', 'Can’t undo · Kept', 409 );
	}
	ogc_lod_put( $y, 'meta:sent:' . $n, null );
	ogc_log( 'lodging_sent_undo', $y, 'counts', array( 'n' => $n ) );
	return rest_ensure_response( array( 'ok' => true, 'sent' => ogc_lod_sent( $y ), 'say' => 'Undone · Not sent' ) );
}

/** GET years/{y}/lodging/sent/{n}?format=xlsx: the copy as it was sent. */
function ogc_lod_rest_sent_get( WP_REST_Request $req ) {
	$y    = (int) $req['year'];
	$n    = (int) $req['n'];
	$send = null;
	foreach ( ogc_lod_sent( $y ) as $s ) {
		if ( $s['n'] === $n ) {
			$send = $s;
		}
	}
	if ( ! $send ) {
		return ogc_lod_err( 'ogc_not_found', 'Not found.', 404 );
	}
	if ( 'xlsx' !== $req->get_param( 'format' ) || ! function_exists( 'ogc_lst_xlsx' ) ) {
		return rest_ensure_response( $send );
	}
	$names  = array( 'counts' => 'Counts', 'rooming' => 'Rooming list', 'setup' => 'Room setup' );
	$sheets = array();
	foreach ( $names as $k => $title ) {
		$t = isset( $send['copy'][ $k ] ) ? $send['copy'][ $k ] : null;
		if ( ! $t ) {
			continue;
		}
		$rows = (array) $t['rows'];
		if ( ! empty( $t['totals'] ) ) {
			$rows[] = array();
			foreach ( $t['totals'] as $x ) {
				$rows[] = $x;
			}
		}
		$sheets[] = array( 'name' => $title, 'cols' => (array) $t['head'], 'rows' => $rows );
	}
	$sheets[] = array(
		'name'   => 'Columns',
		'cols'   => array( 'What', 'As sent' ),
		'filter' => false,
		'rows'   => array( array( 'Sent', ogc_lod_md( $send['day'] ) . ', ' . substr( $send['day'], 0, 4 ) ), array( 'By', $send['by'] ), array( 'To', $send['to'] ), array( 'What', implode( ' · ', array_map( function ( $k ) use ( $names ) { return $names[ $k ]; }, $send['what'] ) ) ), array( 'Kept', 'Exactly as it was on the screen when marked sent' ) ),
	);
	ogc_log( 'lodging_export', $y, 'counts-sent', array( 'n' => $n ) );
	return ogc_lst_xlsx_response( ogc_lst_xlsx( $sheets ), $y . ' Lodging counts · Sent ' . $send['day'] . '.xlsx' );
}

/* ================================================================== the screen, its line, its need */

add_filter( 'ogc_app_screens', function ( $s, $year ) {
	$s['lod-counts'] = array( 'title' => 'Counts', 'section' => 'own', 'who' => array( 'lodging' ), 'handable' => false, 'coa_opens' => true, 'icon' => 'report' );
	return $s;
}, 21, 2 );

add_filter( 'ogc_app_screen_opens', function ( $out, $year ) {
	// In season two weeks before it's due (area-lodging L19): its place on the year line, sent or not.
	$out['lod-counts'] = ogc_lod_counts_opens( $year );
	return $out;
}, 10, 2 );

add_filter( 'ogc_pages', function ( $p ) {
	if ( isset( $p['app'] ) ) {
		$p['app']['scripts'][] = 'app/screens/committee-lodging-counts.js';
	}
	return $p;
}, 21 );

add_filter( 'ogc_appc_work_line', function ( $line, $y, $id, $c ) {
	return 'lod-counts' === $id ? ogc_lod_counts_line( $y ) : $line;
}, 10, 4 );

// Lodging's need from its season until sent: "Counts due May 14 · Open Counts" (area-lodging 1.8).
add_filter( 'ogc_app_needs', function ( $rows, $year, $ckey, $ctx ) {
	if ( 'lodging' !== $ckey || ogc_lod_sent( $year ) ) {
		return $rows;
	}
	$due   = ogc_lod_counts_due( $year );
	$opens = ogc_lod_counts_opens( $year );
	$row   = ogc_year_get( (int) $year );
	if ( ! $due || ! $opens || $ctx['today'] < $opens || ( $row && ! empty( $row['start'] ) && $ctx['today'] >= $row['start'] ) ) {
		return $rows;
	}
	$late   = $ctx['today'] > $due;
	// Counts follow the rooms: until it's late, placing households stays Lodging's first need (its date is
	// in the words, not the ranking's `due`).
	$rows[] = array( 'key' => 'lod-counts', 'kind' => 'lod_counts', 'words' => 'Counts due ' . ogc_lod_md( $due ), 'why' => ( $late ? 'Late · ' : '' ) . 'To the campus · Rooms, linens, keys', 'go' => array( 's' => 'lod-counts' ), 'button' => 'Open Counts', 'due' => $late ? $due : '', 'rank' => $late ? 0 : 3, 'tone' => $late ? 'late' : '' );
	return $rows;
}, 12, 4 );
