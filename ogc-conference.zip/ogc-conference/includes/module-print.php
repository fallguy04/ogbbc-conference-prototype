<?php
/**
 * The print area: the printed schedule (/schedule/) and the information packet (/packet/).
 *
 * The server decides what each person gets, before anything is drawn:
 *   - which year: ?year= (v3's ?data= still works), or the Conference the Conference page shows;
 *   - a year that doesn't exist answers 404 ("No schedule for 2031"), drawn in the site's look;
 *   - a year not yet published: the public gets "Not posted yet", drawn here, and no rows at all;
 *     the year's members get the draft, marked Draft on screen and on paper (no URL flag needed:
 *     ?preview=1 alone does nothing);
 *   - the rows go into the page itself (OGC_WP.print), read through the same filters as the REST
 *     routes (ogc_file_readable, ogc_file_rows_out), so the page never carries more than the API
 *     would give this person, and the printout draws the moment the page opens.
 *
 * It also keeps, per year (state table):
 *   print_base    the schedule's rows as published, taken just before the first change after
 *                 Publish, so the paper can mark what changed since ("● Changed since May 19") and
 *                 keep a cancelled row, struck through;
 *   print_status  the last fit a member's browser measured (pages, type size, layout), for the
 *                 year page's "Made from it" card.
 * "Updated" on paper is the time of the last saved change after Publish (from the change log), kept
 * apart for the schedule and the packet.
 *
 * Route: GET /wp-json/ogc/v1/years/{y}/print-checks (members of y): the fit, and what to look at
 * before Publish (personal numbers or emails typed into printed text, unknown place codes, rows
 * twice, dates that disagree, words that only work on a screen).
 */

defined( 'ABSPATH' ) || exit;

/* ================================================================== small helpers */

/** A settings-style file as key → value. */
function ogc_print_kv( $year, $name = 'settings' ) {
	$f = ogc_file_get( $year, $name );
	$o = array();
	foreach ( $f ? $f['rows'] : array() as $r ) {
		if ( isset( $r['key'] ) && '' !== $r['key'] ) {
			$o[ $r['key'] ] = isset( $r['value'] ) ? (string) $r['value'] : '';
		}
	}
	return $o;
}

function ogc_print_tz( $s ) {
	try {
		return new DateTimeZone( ! empty( $s['timezone'] ) ? $s['timezone'] : 'America/Indiana/Indianapolis' );
	} catch ( Exception $e ) {
		return new DateTimeZone( 'America/Indiana/Indianapolis' );
	}
}

/** Today at the campus. Never from a browser's clock or ?as-of. */
function ogc_print_today( $s ) {
	$d = new DateTime( 'now', ogc_print_tz( $s ) );
	return $d->format( 'Y-m-d' );
}

function ogc_print_iso( $v ) {
	return is_string( $v ) && preg_match( '/^\d{4}-\d{2}-\d{2}$/', $v );
}

/** Is the year's schedule (schedule_posted) or packet (packet_posted) public today? The year area's
 * rule when it's loaded (blank counts as public, for years made before it); the same rule otherwise. */
function ogc_print_posted( $year, $key ) {
	if ( function_exists( 'ogc_coa_posted' ) ) {
		// A local page previewing a day (ogc_dev_preview_at) prints what's public that day.
		return ogc_coa_posted( $year, $key, substr( ogc_dev_preview_at( $year ), 0, 10 ) );
	}
	$s = ogc_print_kv( $year );
	$v = isset( $s[ $key ] ) ? $s[ $key ] : '';
	return '' === $v || ( ogc_print_iso( $v ) && '9999-12-31' !== $v && $v <= ogc_print_today( $s ) );
}

/** The Conference the Conference page shows: the conference area's own rule (ogc_pub_featured_year:
 * the year set to show first, the COA's announcement, and from Nov 1 the next one), so /schedule/,
 * /packet/ and the Conference page never name different years. The copy below is only a fallback
 * for a site without that module. */
function ogc_print_current_year() {
	if ( function_exists( 'ogc_pub_featured_year' ) && function_exists( 'ogc_pub_today' ) ) {
		$r = ogc_pub_featured_year( ogc_years_public(), ogc_pub_today() );
		return $r ? (int) $r['year'] : 0;
	}
	$today = ( new DateTime( 'now', new DateTimeZone( 'America/Indiana/Indianapolis' ) ) )->format( 'Y-m-d' );
	$ys    = array_values( array_filter( ogc_years_all(), function ( $y ) use ( $today ) {
		return ! empty( $y['data'] ) && ( empty( $y['announced'] ) || $y['announced'] <= $today );
	} ) );
	foreach ( $ys as $y ) {
		if ( ! empty( $y['coa_announced'] ) && $y['coa_announced'] <= $today ) {
			return (int) $y['year'];
		}
	}
	foreach ( $ys as $y ) {
		if ( ! empty( $y['start'] ) && $y['start'] <= $today ) {
			return (int) $y['year'];
		}
	}
	return $ys ? (int) end( $ys )['year'] : 0;
}

/** "June 5–9, 2026", "May 28 – June 1, 2027" (as ogc-core.js fmtDateSpan). */
function ogc_print_span( $a, $b ) {
	if ( ! ogc_print_iso( $a ) ) {
		return '';
	}
	$da = DateTime::createFromFormat( '!Y-m-d', $a );
	if ( ! ogc_print_iso( $b ) || $a === $b ) {
		return $da->format( 'F j, Y' );
	}
	$db = DateTime::createFromFormat( '!Y-m-d', $b );
	if ( $da->format( 'Y-m' ) === $db->format( 'Y-m' ) ) {
		return $da->format( 'F j' ) . '–' . $db->format( 'j, Y' );
	}
	if ( $da->format( 'Y' ) === $db->format( 'Y' ) ) {
		return $da->format( 'F j' ) . ' – ' . $db->format( 'F j, Y' );
	}
	return $da->format( 'F j, Y' ) . ' – ' . $db->format( 'F j, Y' );
}

/** The year asked for: ?year= (or v3's ?data=). 0 = asked for something that isn't a year. */
function ogc_print_asked_year() {
	// phpcs:disable WordPress.Security.NonceVerification -- reading which year is asked for.
	$raw = isset( $_GET['year'] ) ? $_GET['year'] : ( isset( $_GET['data'] ) ? $_GET['data'] : '' );
	// phpcs:enable
	$raw = is_string( $raw ) ? trim( sanitize_text_field( wp_unslash( $raw ) ) ) : '';
	if ( '' === $raw ) {
		return null;
	}
	return ogc_valid_year( $raw ) ? (int) $raw : 0;
}

/* ================================================================== who gets what */

/**
 * What this request may see on a print page ('schedule' or 'packet'):
 *   state   'ok' (draw it), 'wait' (not posted: the public's "Not posted yet"), 'missing' (404)
 *   draft   a member looking at a year not yet published
 */
function ogc_print_ctx( $page ) {
	static $cache = array();
	if ( isset( $cache[ $page ] ) ) {
		return $cache[ $page ];
	}
	$asked = ogc_print_asked_year();
	$y     = null === $asked ? ogc_print_current_year() : $asked;
	$row   = $y ? ogc_year_get( $y ) : null;
	$s     = $row ? ogc_print_kv( $y ) : array();
	$c     = array( 'page' => $page, 'year' => $y, 'state' => 'missing', 'draft' => false, 'member' => false, 'empty' => false, 'row' => $row, 'settings' => $s );
	if ( ! $row ) {
		$cache[ $page ] = $c;
		return $c;
	}
	$c['member'] = ogc_is_member( $y );
	$today       = ogc_print_today( $s );
	// A year not yet announced is no one's business but its committee's.
	if ( ! empty( $row['announced'] ) && $row['announced'] > $today && ! $c['member'] ) {
		$cache[ $page ] = $c;
		return $c;
	}
	// Over: its last day has passed (or, with no dates, its year has).
	$past = ! empty( $row['end'] ) ? $row['end'] < $today : (int) $y < (int) substr( $today, 0, 4 );
	if ( ! empty( $s['first_day'] ) && ogc_print_iso( $s['first_day'] ) ) {
		$main   = 'packet' === $page ? 'guide' : 'schedule';
		$f      = ogc_file_get( $y, $main );
		$has    = $f && $f['rows'];
		$posted = $has && ogc_print_posted( $y, 'packet' === $page ? 'packet_posted' : 'schedule_posted' );
		if ( $posted ) {
			$c['state'] = 'ok';
		} elseif ( $c['member'] && $has ) {
			$c['state'] = 'ok';
			$c['draft'] = true;
		} elseif ( ! $past ) {
			$c['state'] = 'wait';
			// A member of a year with nothing made yet gets the way to make it, not the public's words.
			$c['empty'] = $c['member'] && ! $has;
		}
		// A past Conference whose paper was never posted has none: 404, not "Not posted yet".
	} elseif ( ! $past ) {
		// A Conference to come with no dates yet (2028): its name and hosts, and "Not posted yet".
		$c['state'] = 'wait';
		$c['empty'] = $c['member'];
	}
	$cache[ $page ] = $c;
	return $c;
}

/** The settings each print page publishes ("assumed posted" in a member's draft). */
function ogc_print_gates_for( $page ) {
	return 'packet' === $page ? array( 'schedule_posted', 'packet_posted' ) : array( 'schedule_posted' );
}

/**
 * A file's rows as the public gets them: the REST routes' own rules with $member false, for everyone,
 * members too (week.js's rule: a member sees what the public will). In a member's draft, the gates in
 * $assume (the part being drawn: schedule_posted, packet_posted) count as published, and every other
 * rule still holds: a carried call-in line, Help and Care nearby rows wait for this year's Confirm;
 * "Committees only" rows never print; another part's gate (the packet's Preteens part on the sheet)
 * stays as it really is. What the draft holds back is listed by ogc_print_held().
 */
function ogc_print_rows( $year, $name, $assume = array() ) {
	// (The map area: the campus, its pins and plans are kept per campus and answered for by ogc_file_out.)
	$f = apply_filters( 'ogc_file_out', ogc_file_get( $year, $name ), (int) $year, $name );
	if ( ! $f || in_array( $name, ogc_private_files(), true ) ) {
		return array();
	}
	$rows  = $f['rows'];
	$gates = function_exists( 'ogc_pub_gates' ) ? ogc_pub_gates() : array();
	$open  = isset( $gates[ $name ] ) && in_array( $gates[ $name ], (array) $assume, true );
	if ( ! $open || ! function_exists( 'ogc_pub_rows_out' ) ) {
		if ( ! apply_filters( 'ogc_file_visible', true, (int) $year, $name, false ) ) {
			return array();
		}
		return array_values( (array) apply_filters( 'ogc_file_rows_out', $rows, (int) $year, $name, false ) );
	}
	// Published for this draft: every rule but the gate. (The conference area's filter holds the gate
	// and the row rules together, so it's set aside and its row rules applied here, with its helpers.)
	$pri = has_filter( 'ogc_file_rows_out', 'ogc_pub_rows_out' );
	if ( false !== $pri ) {
		remove_filter( 'ogc_file_rows_out', 'ogc_pub_rows_out', $pri );
	}
	$rows = (array) apply_filters( 'ogc_file_rows_out', $rows, (int) $year, $name, false );
	if ( false !== $pri ) {
		add_filter( 'ogc_file_rows_out', 'ogc_pub_rows_out', $pri, 4 );
	}
	$rows = ogc_pub_safe_rows( $rows, $name );
	$from = ogc_pub_carried( $year );
	if ( ( 'help' === $name || 'nearby' === $name ) && $from ) {
		$rows = array_filter( $rows, function ( $r ) use ( $year, $name ) {
			if ( isset( $r['kind'] ) && 'emergency' === $r['kind'] ) {
				return true;
			}
			$id = $name . ':' . ogc_pub_slug( 'help' === $name ? ( isset( $r['need'] ) ? $r['need'] : '' ) : ( isset( $r['name'] ) ? $r['name'] : '' ) );
			return ogc_pub_confirmed( $year, $id, ! empty( $r['confirmed'] ) );
		} );
	}
	return array_values( $rows );
}

/**
 * For a member: what the public's paper leaves out that the year's own rows have, each a line for
 * To check with where to confirm it. → [{key, part, what, where, tip, href}]
 */
function ogc_print_held( $y, $page, $files ) {
	$out  = array();
	$raw  = function ( $n ) use ( $y ) {
		$f = ogc_file_get( $y, $n );
		return $f ? $f['rows'] : array();
	};
	$from = function_exists( 'ogc_pub_carried' ) ? ogc_pub_carried( $y ) : '';
	$year = function ( $part, $sec ) use ( $y ) {
		return ogc_url( 'year', array( 'year' => $y, 'part' => $part ) ) . '#s-' . $sec;
	};
	$kv = array();
	foreach ( $files['settings'] as $r ) {
		$kv[ $r['key'] ] = $r['value'];
	}
	$s = ogc_print_kv( $y );
	if ( ! empty( $s['call_in_number'] ) && empty( $kv['call_in_number'] ) ) {
		$out[] = array( 'key' => 'callin', 'part' => $page, 'what' => 'Call-in line · Not confirmed', 'where' => 'Confirm', 'tip' => 'Carried from ' . ( $from ? $from : 'last year' ) . '. The paper leaves out the number and the phone marks until it’s confirmed', 'href' => $year( 'conference', 'conf' ) );
	}
	$count = function ( $rows ) {
		return count( array_filter( $rows, function ( $r ) {
			return ! ( isset( $r['kind'] ) && 'emergency' === $r['kind'] ) && ( ! empty( $r['phone'] ) || ! empty( $r['need'] ) || ! empty( $r['name'] ) );
		} ) );
	};
	$hn = $count( $raw( 'help' ) ) - $count( $files['help'] );
	if ( $hn > 0 ) {
		$out[] = array( 'key' => 'help', 'part' => $page, 'what' => 'Help · ' . $hn . ( 1 === $hn ? ' card' : ' cards' ) . ( $from ? ' from ' . $from : '' ), 'where' => 'Confirm', 'tip' => 'Left off the paper until they’re confirmed', 'href' => $year( 'packet', 'help' ) );
	}
	if ( 'packet' === $page && isset( $files['nearby'] ) ) {
		$nn = $count( $raw( 'nearby' ) ) - $count( $files['nearby'] );
		if ( $nn > 0 ) {
			$out[] = array( 'key' => 'nearby', 'part' => $page, 'what' => 'Care nearby · ' . $nn . ( 1 === $nn ? ' place' : ' places' ) . ( $from ? ' from ' . $from : '' ), 'where' => 'Confirm', 'tip' => 'Left off the paper until they’re confirmed', 'href' => $year( 'conference', 'campus' ) );
		}
	}
	$pre_out = array_filter( $files['guide'], function ( $g ) {
		return isset( $g['id'] ) && 'preteens' === strtolower( trim( (string) $g['id'] ) );
	} );
	if ( 'schedule' === $page && ! $pre_out ) {
		foreach ( $raw( 'guide' ) as $g ) {
			if ( isset( $g['id'] ) && 'preteens' === strtolower( trim( (string) $g['id'] ) ) ) {
				$out[] = array( 'key' => 'preteens', 'part' => $page, 'what' => 'Preteens box · Waits for the packet', 'where' => 'Packet', 'tip' => 'The sheet prints the packet’s Preteens summary once the packet is published', 'href' => ogc_url( 'year', array( 'year' => $y, 'part' => 'packet' ) ) . '#pp-preteens' );
				break;
			}
		}
	}
	return $out;
}

/** The time of the last saved change to what a part prints after it was published ('schedule' or
 * 'packet'), at the campus ("2026-06-05 14:10"), or '' when nothing has changed since. Kept by
 * ogc_print_watch() as each change is saved, whichever editor or route saved it. */
function ogc_print_updated( $year, $part, $s ) {
	$st  = ogc_state_get( $year, 'print_updated' );
	$v   = $st && is_array( $st['value'] ) && isset( $st['value'][ $part ] ) ? (array) $st['value'][ $part ] : array();
	$key = 'packet' === $part ? 'packet_posted' : 'schedule_posted';
	if ( empty( $v['at'] ) || ! isset( $v['posted'] ) || ! isset( $s[ $key ] ) || $v['posted'] !== $s[ $key ] ) {
		return '';
	}
	$d = new DateTime( $v['at'], new DateTimeZone( 'UTC' ) );
	$d->setTimezone( ogc_print_tz( $s ) );
	return $d->format( 'Y-m-d H:i' );
}

/** The schedule as published, while it's still the one on the public page. */
function ogc_print_base( $year, $s ) {
	$b = ogc_state_get( $year, 'print_base' );
	if ( ! $b || ! is_array( $b['value'] ) ) {
		return null;
	}
	$v = $b['value'];
	return ( isset( $v['posted'], $v['rows'] ) && isset( $s['schedule_posted'] ) && $v['posted'] === $s['schedule_posted'] ) ? $v : null;
}

/** The published copy as the public may see it: the same rules as the public's own rows (no
 * "Committees only" rows), and only the columns the paper compares, so a member's note or a "to check"
 * mark never reaches a visitor's page. */
function ogc_print_base_public( $year, $rows ) {
	$rows = (array) apply_filters( 'ogc_file_rows_out', (array) $rows, (int) $year, 'schedule', false );
	$keep = array_flip( array( '_id', 'day', 'last_day', 'start', 'end', 'title', 'place', 'audience', 'display', 'kind', 'print_note', 'sort_time' ) );
	$out  = array();
	foreach ( $rows as $r ) {
		if ( is_array( $r ) && ! ( isset( $r['display'] ) && 'private' === strtolower( trim( (string) $r['display'] ) ) ) ) {
			$out[] = array_intersect_key( $r, $keep );
		}
	}
	return $out;
}

/** The short address printed under the QR code ("ogbbc.org/annual-conference"). */
function ogc_print_short( $url ) {
	$u = preg_replace( '#^https?://(www\.)?#', '', untrailingslashit( preg_replace( '/\?.*$/', '', $url ) ) );
	return (string) apply_filters( 'ogc_print_short_url', $u, $url );
}

/* ================================================================== the page's data */

/** The files a print page is made from, as the public gets them; $draft: as they will be once the
 * page's part is published (a member's draft, or the checks before Publish). */
function ogc_print_files( $y, $page, $draft ) {
	$names = array( 'settings', 'schedule', 'places', 'help', 'notices', 'guide' );
	if ( 'packet' === $page ) {
		$names = array_merge( $names, array( 'tournaments', 'nearby', 'menus', 'campus', 'rooms' ) );
	}
	$files  = array();
	$assume = $draft ? ogc_print_gates_for( $page ) : array();
	foreach ( $names as $n ) {
		$files[ $n ] = ogc_print_rows( $y, $n, $assume );
	}
	return $files;
}

/** Everything the page draws from (OGC_WP.print). Nothing for 'wait' or 'missing'. */
function ogc_print_payload( $page ) {
	$c = ogc_print_ctx( $page );
	$y = $c['year'];
	$s = $c['settings'];
	$r = (array) $c['row'];
	$out = array(
		'page'   => $page,
		'year'   => $y,
		'state'  => $c['state'],
		'draft'  => $c['draft'],
		'member' => $c['member'],
	);
	if ( 'ok' !== $c['state'] ) {
		return $out;
	}
	$files = ogc_print_files( $y, $page, $c['draft'] );
	// A member's draft keeps the rows' "to check" marks (◆), which the public's rules leave off.
	if ( $c['draft'] ) {
		$look = array();
		$sf   = ogc_file_get( $y, 'schedule' );
		foreach ( $sf ? $sf['rows'] : array() as $sr ) {
			if ( ! empty( $sr['_id'] ) && ! empty( $sr['_look'] ) ) {
				$look[ $sr['_id'] ] = $sr['_look'];
			}
		}
		foreach ( $files['schedule'] as &$sr ) {
			if ( ! empty( $sr['_id'] ) && isset( $look[ $sr['_id'] ] ) ) {
				$sr['_look'] = $look[ $sr['_id'] ];
			}
		}
		unset( $sr );
	}
	// The sheet prints one line of the packet (the Preteens part's summary): only that part is sent.
	if ( 'schedule' === $page ) {
		$files['guide'] = array_values( array_filter( $files['guide'], function ( $g ) {
			return isset( $g['id'] ) && 'preteens' === strtolower( trim( (string) $g['id'] ) );
		} ) );
	}
	// Only what the paper prints. The halls' names for the map, never their floors, rooms or who
	// sleeps where (the Advisors: where people sleep is to be kept secure).
	if ( isset( $files['rooms'] ) ) {
		$halls = array();
		foreach ( $files['rooms'] as $rw ) {
			$h = isset( $rw['hall'] ) ? trim( (string) $rw['hall'] ) : '';
			if ( '' !== $h && '#' !== $h[0] ) {
				// Which halls the Conference uses is a sample until Lodging confirms them (a "confirmed"
				// column on the hall's rows): the paper's map names only confirmed ones.
				$ok          = ! empty( $rw['confirmed'] ) && preg_match( '/^(y|yes|true|1|x)$/i', (string) $rw['confirmed'] );
				$halls[ $h ] = array( 'hall' => $h, 'confirmed' => ( ! empty( $halls[ $h ]['confirmed'] ) || $ok ) ? '1' : '' );
			}
		}
		$files['rooms'] = array_values( $halls );
	}
	// Settings: the key and value only (the help column is editors' hints, not for the public). Once the
	// packet has a Preteens part, it's the one copy: the old preteen_note never stands in for it.
	$has_pre = false;
	$gf      = ogc_file_get( $y, 'guide' );
	foreach ( $gf ? $gf['rows'] : array() as $g ) {
		$has_pre = $has_pre || ( isset( $g['id'] ) && 'preteens' === strtolower( trim( (string) $g['id'] ) ) );
	}
	$files['settings'] = array_values( array_filter( array_map( function ( $rw ) {
		return array( 'key' => isset( $rw['key'] ) ? $rw['key'] : '', 'value' => isset( $rw['value'] ) ? $rw['value'] : '' );
	}, $files['settings'] ), function ( $rw ) use ( $has_pre ) {
		// Retired keys (the fit and the QR code decide these now) are never sent.
		return ! ( $has_pre && 'preteen_note' === $rw['key'] ) && ! in_array( $rw['key'], array( 'schedule_url', 'print_page_break_before', 'print_show_desk' ), true );
	} ) );
	$conf   = ogc_url( '', array( 'year' => $y ) );
	$base   = ogc_print_base( $y, $s );
	$posted = function ( $k ) use ( $s ) {
		$v = isset( $s[ $k ] ) ? $s[ $k ] : '';
		return ogc_print_iso( $v ) && '9999-12-31' !== $v ? $v : '';
	};
	$out += array(
		'files'   => $files,
		'yr'      => array_intersect_key( $r, array_flip( array( 'start', 'end', 'venue', 'city', 'hosts' ) ) ),
		'today'   => ogc_print_today( $s ),
		'posted'  => array( 'schedule' => $posted( 'schedule_posted' ), 'packet' => $posted( 'packet_posted' ) ),
		'updated' => $c['draft'] ? array() : array(
			'schedule' => ogc_print_updated( $y, 'schedule', $s ),
			'packet'   => ogc_print_updated( $y, 'packet', $s ),
		),
		'base'    => $base && ! $c['draft'] ? ogc_print_base_public( $y, $base['rows'] ) : null,
		'urls'    => array(
			'conference' => $conf,
			'short'      => ogc_print_short( ogc_url() ),
			'schedule'   => ogc_url( 'schedule', array( 'year' => $y ) ),
			'packet'     => ogc_url( 'packet', array( 'year' => $y ) ),
			'register'   => ogc_url( 'register', array( 'year' => $y ) ),
			'volunteer'  => ogc_url( 'volunteer', array( 'year' => $y ) ),
			'places'     => ogc_url( 'guide', array( 'year' => $y, 'view' => 'places' ) ),
		),
	);
	// "Read on screen", and what the sheet's QR code opens: the Conference page's full schedule.
	$out['urls']['full'] = ogc_url( '', array( 'year' => $y, 'view' => 'full' ) );
	// The packet's "Conference page" link opens the Conference page's own packet, at its first part,
	// only while that page shows the packet (published, and the Conference not over).
	$out['urls']['packetOnScreen'] = $conf;
	$out['urls']['packetShown']    = ! $c['draft'] && ogc_print_posted( $y, 'packet_posted' ) && ! ( ! empty( $r['end'] ) && $r['end'] < ogc_print_today( $s ) );
	// The packet's own short address, printed under its QR code ("ogbbc.org/annual-conference/packet").
	$out['urls']['packetShort'] = ogc_print_short( ogc_url( 'packet' ) );
	if ( $c['member'] ) {
		$st            = ogc_state_get( $y, 'print_status' );
		$out['status'] = $st ? $st['value'] : null;
		$out['held']   = ogc_print_held( $y, $page, $files );
		$out['checks'] = array_merge( $out['held'], ogc_print_checks( $y ) );
		// Every editor address the two pages use, in one place (the App phase will move them).
		$yp            = function ( $part, $extra = array() ) use ( $y ) {
			return ogc_url( 'year', array_merge( array( 'year' => $y, 'part' => $part ), $extra ) );
		};
		$out['urls'] += array(
			'edit'       => ogc_url( 'admin', array( 'role' => 'coa', 'year' => $y, 'edit' => 'schedule', 'back' => 'schedule' ) ),
			// On a phone, the year page's own check tool (the desktop editor is for a laptop).
			'checkPhone' => $yp( 'schedule', array( 'tool' => 'check' ) ),
			// The packet's Edit opens the year's Packet part at the part (#pp-<id>); the year page reads
			// return= for its Back.
			'packetPart' => $yp( 'packet' ),
			'conferencePart' => $yp( 'conference' ),
			'youngfolksPart' => $yp( 'youngfolks' ),
			'part'       => $yp( 'packet' === $page ? 'packet' : 'schedule' ),
		);
	}
	return $out;
}

/* ================================================================== checks before Publish */

/** What a member should look at before the paper goes out. Each: {part, where, what}. */
function ogc_print_checks( $year ) {
	$s      = ogc_print_kv( $year );
	$row    = (array) ogc_year_get( $year );
	$get    = function ( $n ) use ( $year ) {
		$f = ogc_file_get( $year, $n );
		return $f ? $f['rows'] : array();
	};
	$sched  = $get( 'schedule' );
	$guide  = $get( 'guide' );
	$help   = $get( 'help' );
	$places = $get( 'places' );
	$out    = array();

	// Role lines: the numbers the year publishes on purpose. Any other number typed into printed
	// text may be someone's own phone (the 2026 packet printed three).
	$digits = function ( $p ) {
		$d = preg_replace( '/\D/', '', (string) $p );
		return strlen( $d ) >= 10 ? substr( $d, -10 ) : $d;
	};
	$roles = array();
	foreach ( array_merge( $help, $get( 'nearby' ), $get( 'contacts' ) ) as $r ) {
		if ( ! empty( $r['phone'] ) ) {
			$roles[ $digits( $r['phone'] ) ] = 1;
		}
	}
	if ( ! empty( $s['call_in_number'] ) ) {
		$roles[ $digits( $s['call_in_number'] ) ] = 1;
	}
	$scan = function ( $part, $where, $text ) use ( &$out, $roles, $digits ) {
		$text = (string) $text;
		if ( preg_match( '/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i', $text ) ) {
			$out[] = array( 'part' => $part, 'where' => $where, 'what' => 'Email address', 'tip' => 'Use a role line from Help instead of a person’s email' );
		}
		if ( preg_match_all( '/(?<!\d)(?:\(?\d{3}\)?[\s.-]?)\d{3}[\s.-]\d{4}(?!\d)/', $text, $m ) ) {
			foreach ( $m[0] as $p ) {
				if ( ! isset( $roles[ $digits( $p ) ] ) ) {
					$out[] = array( 'part' => $part, 'where' => $where, 'what' => 'Personal number?', 'tip' => 'Not one of Help’s numbers. Use a role line' );
				}
			}
		}
	};
	$titles = array();
	foreach ( $guide as $g ) {
		if ( ! empty( $g['id'] ) && ! empty( $g['title'] ) ) {
			$titles[ $g['id'] ] = $g['title'];
		}
	}
	foreach ( $guide as $g ) {
		$where = isset( $titles[ isset( $g['id'] ) ? $g['id'] : '' ] ) ? $titles[ $g['id'] ] : 'Packet';
		foreach ( array( 'title', 'summary', 'text' ) as $k ) {
			$scan( 'packet', $where, isset( $g[ $k ] ) ? $g[ $k ] : '' );
		}
		// Words that only work on a screen read wrong on paper.
		if ( ! empty( $g['text'] ) && preg_match( '/\b(tap|tapping|click|below|above|on the schedule|scroll|in the guide|in the app|in the Conference app|near the end)\b/i', $g['text'], $w ) ) {
			$out[] = array( 'part' => 'packet', 'where' => $where, 'what' => 'Screen-only wording · “' . $w[1] . '”', 'tip' => 'These words print on paper too. Say where it is instead' );
		}
	}
	// A year picked up from the last: a price in a part that's the same as last year's is flagged once
	// a part ("Prices from 2026 · $27, $28"), until the part's "Looks right".
	$from = function_exists( 'ogc_pub_carried' ) ? ogc_pub_carried( $year ) : '';
	if ( $from && ogc_valid_year( $from ) ) {
		$old = array();
		$of  = ogc_file_get( (int) $from, 'guide' );
		foreach ( $of ? $of['rows'] : array() as $g ) {
			if ( ! empty( $g['id'] ) && preg_match_all( '/\$\s?\d+(?:\.\d\d)?/', (string) ( isset( $g['text'] ) ? $g['text'] : '' ) . ' ' . ( isset( $g['summary'] ) ? $g['summary'] : '' ), $mm ) ) {
				foreach ( $mm[0] as $p ) {
					$old[ $g['id'] ][ str_replace( ' ', '', $p ) ] = 1;
				}
			}
		}
		$coa  = function_exists( 'ogc_coa_state' ) ? ogc_coa_state( $year ) : array( 'checks' => array() );
		$same = array();
		foreach ( $guide as $g ) {
			$id = isset( $g['id'] ) ? $g['id'] : '';
			if ( '' === $id || ! empty( $coa['checks'][ 'packet:' . $id ] ) || ! preg_match_all( '/\$\s?\d+(?:\.\d\d)?/', (string) ( isset( $g['text'] ) ? $g['text'] : '' ) . ' ' . ( isset( $g['summary'] ) ? $g['summary'] : '' ), $mm ) ) {
				continue;
			}
			foreach ( $mm[0] as $p ) {
				$p = str_replace( ' ', '', $p );
				if ( isset( $old[ $id ][ $p ] ) ) {
					$same[ $id ][ $p ] = 1;
				}
			}
		}
		foreach ( $same as $id => $ps ) {
			$out[] = array( 'part' => 'packet', 'where' => isset( $titles[ $id ] ) ? $titles[ $id ] : 'Packet', 'what' => 'Prices from ' . $from . ' · ' . implode( ', ', array_keys( $ps ) ), 'tip' => 'The same as last year. Check them, then Looks right on the part' );
		}
	}
	foreach ( $help as $h ) {
		$scan( 'packet', 'Help · ' . ( isset( $h['need'] ) ? $h['need'] : '' ), isset( $h['text'] ) ? $h['text'] : '' );
	}
	// A part that repeats what Help already says (the same number or text code) prints it twice in
	// one packet: say it once, in Help.
	$help_keys = array();
	foreach ( $help as $h ) {
		foreach ( array( 'phone', 'text', 'link' ) as $k ) {
			if ( ! empty( $h[ $k ] ) && preg_match_all( '/\d{5,}|\d{3}[\s.-]\d{3}[\s.-]\d{4}/', (string) $h[ $k ], $mm ) ) {
				foreach ( $mm[0] as $num ) {
					$help_keys[ preg_replace( '/\D/', '', $num ) ] = isset( $h['need'] ) ? $h['need'] : 'Help';
				}
			}
		}
	}
	foreach ( $guide as $g ) {
		$where = isset( $titles[ isset( $g['id'] ) ? $g['id'] : '' ] ) ? $titles[ $g['id'] ] : 'Packet';
		if ( empty( $g['text'] ) || ! preg_match_all( '/\d{5,}|\d{3}[\s.-]\d{3}[\s.-]\d{4}/', (string) $g['text'], $mm ) ) {
			continue;
		}
		foreach ( $mm[0] as $num ) {
			$k = preg_replace( '/\D/', '', $num );
			if ( isset( $help_keys[ $k ] ) ) {
				$out[] = array( 'part' => 'packet', 'where' => $where, 'what' => 'Also in Help · ' . $help_keys[ $k ], 'tip' => 'The packet prints Help’s cards. Say it once, in Help' );
				break;
			}
		}
	}
	foreach ( $get( 'notices' ) as $n ) {
		$scan( 'schedule', 'Notice', isset( $n['text'] ) ? $n['text'] : '' );
	}
	$codes = array();
	foreach ( $places as $p ) {
		if ( ! empty( $p['code'] ) ) {
			$codes[ strtoupper( $p['code'] ) ] = 1;
		}
	}
	$seen = array();
	foreach ( $sched as $r ) {
		if ( empty( $r['title'] ) ) {
			continue;
		}
		$where = trim( ( isset( $r['day'] ) ? $r['day'] : '' ) . ' ' . ( isset( $r['start'] ) ? $r['start'] : '' ) ) . ' · ' . $r['title'];
		foreach ( array( 'title', 'note', 'print_note' ) as $k ) {
			$scan( 'schedule', $where, isset( $r[ $k ] ) ? $r[ $k ] : '' );
		}
		if ( ! empty( $r['place'] ) && ! isset( $codes[ strtoupper( $r['place'] ) ] ) ) {
			$out[] = array( 'part' => 'schedule', 'where' => $where, 'what' => $r['place'] . ' · Unknown place', 'tip' => 'Not one of this campus’s places. It prints as typed' );
		}
		$k = strtolower( implode( '|', array( isset( $r['day'] ) ? $r['day'] : '', isset( $r['start'] ) ? $r['start'] : '', $r['title'], isset( $r['audience'] ) ? $r['audience'] : '' ) ) );
		if ( isset( $seen[ $k ] ) ) {
			$out[] = array( 'part' => 'schedule', 'where' => $where, 'what' => 'Listed twice', 'tip' => 'The same day, time and title twice' );
		}
		$seen[ $k ] = 1;
	}
	// A campus that asks for a line on everything printed (IWU: "not a function of IWU"): when the last
	// Conference there printed one and this year has none, the paper would go out without it.
	$venue = isset( $s['venue'] ) ? (string) $s['venue'] : '';
	if ( '' !== $venue && empty( $s['print_required'] ) ) {
		$was = function_exists( 'ogc_coa_campus_year' ) ? (int) ogc_coa_campus_year( $year, $venue ) : 0;
		$ws  = $was ? ogc_print_kv( $was ) : array();
		if ( ! empty( $ws['print_required'] ) ) {
			$out[] = array( 'part' => 'schedule', 'key' => 'campus_line', 'where' => 'The Conference · Place', 'what' => 'Campus line · Missing', 'tip' => $venue . ' asks for “' . $ws['print_required'] . '” on printed materials (' . $was . ')', 'href' => ogc_url( 'year', array( 'year' => $year, 'part' => 'conference' ) ) . '#s-conf' );
			$out[] = array( 'part' => 'packet', 'key' => 'campus_line', 'where' => 'Cover', 'what' => 'Campus line · Missing', 'tip' => $venue . ' asks for “' . $ws['print_required'] . '” on printed materials (' . $was . ')', 'href' => ogc_url( 'year', array( 'year' => $year, 'part' => 'conference' ) ) . '#s-conf' );
		}
	}
	if ( ! empty( $row['start'] ) && ! empty( $s['first_day'] ) && $row['start'] !== $s['first_day'] ) {
		$out[] = array( 'part' => 'schedule', 'where' => 'Dates', 'what' => 'Dates differ', 'tip' => 'The schedule starts ' . $s['first_day'] . '; the Conference starts ' . $row['start'] );
	}
	return $out;
}

/**
 * What Publish should say first, for both printouts: the fit, what the public's paper will leave out
 * (held: a carried call-in line, Help or Care nearby cards not yet confirmed, the Preteens box waiting
 * for the packet; each once, with the parts it's left off), the checks, and how many schedule rows are
 * still marked to check. → {status, held: [{key, parts, what, where, tip, href}], checks, rows_to_check}
 */
function ogc_print_report( $y, $status ) {
	$held = array();
	foreach ( array( 'schedule', 'packet' ) as $page ) {
		$draft = ! ogc_print_posted( $y, 'packet' === $page ? 'packet_posted' : 'schedule_posted' );
		foreach ( ogc_print_held( $y, $page, ogc_print_files( $y, $page, $draft ) ) as $h ) {
			if ( isset( $held[ $h['key'] ] ) ) {
				$held[ $h['key'] ]['parts'][] = $page;
				continue;
			}
			$h['parts']          = array( $page );
			$held[ $h['key'] ] = $h;
		}
	}
	// Rows still marked to check, of those the paper prints as rows (a Committees-only row never prints;
	// the nights' line and the desk's hours carry no mark), as the printout's own To check counts them.
	$ids = array();
	foreach ( ogc_print_rows( $y, 'schedule', ogc_print_gates_for( 'schedule' ) ) as $r ) {
		if ( ! empty( $r['_id'] ) ) {
			$ids[ $r['_id'] ] = 1;
		}
	}
	$sf   = ogc_file_get( $y, 'schedule' );
	$look = 0;
	foreach ( $sf ? $sf['rows'] : array() as $r ) {
		$look += ( ! empty( $r['_look'] ) && '0' !== (string) $r['_look'] && ! empty( $r['title'] ) && ! empty( $r['_id'] ) && isset( $ids[ $r['_id'] ] ) && ! in_array( strtolower( trim( isset( $r['display'] ) ? (string) $r['display'] : '' ) ), array( 'nightly', 'desk' ), true ) ) ? 1 : 0;
	}
	return array( 'status' => $status, 'held' => array_values( $held ), 'checks' => ogc_print_checks( $y ), 'rows_to_check' => $look );
}

add_action( 'rest_api_init', function () {
	register_rest_route( OGC_NS, '/years/(?P<year>\d{4})/print-checks', array(
		'methods'             => 'GET',
		'callback'            => function ( WP_REST_Request $req ) {
			$y = (int) $req['year'];
			$st = ogc_state_get( $y, 'print_status' );
			return rest_ensure_response( ogc_print_report( $y, $st ? $st['value'] : null ) );
		},
		'permission_callback' => function ( WP_REST_Request $req ) {
			return ogc_is_member( $req['year'] ) ? true : new WP_Error( 'ogc_forbidden', 'Not allowed.', array( 'status' => is_user_logged_in() ? 403 : 401 ) );
		},
	) );
} );

/* ================================================================== the schedule as published */

// Every saved change goes through ogc_file_put(), whichever editor or route makes it (the schedule
// editor's rows and sync routes, the files routes, the year page, an import). Its ogc_file_rows filter
// sees the rows before and after, so here, after a part is published:
//   - just before the first change to the schedule, the schedule as it was is kept (print_base), so
//     the paper can mark what changed since ("● Changed since May 19") and keep a cancelled row;
//   - each change to what a part prints stamps when (print_updated), for "Updated" on paper.
// Settings count only for the keys the paper prints, not the COA's own bookkeeping; the sheet counts
// the packet's Preteens part only. Both are written once the request is over, and only if the
// file's version really moved (a write refused as a conflict changes nothing).
const OGC_PRINT_KEYS = array( 'call_in_number', 'call_in_pin', 'hosts', 'venue', 'address', 'timezone', 'timezone_label', 'print_required', 'print_layout', 'first_day' );

/** The files each part prints. */
function ogc_print_part_files( $part ) {
	return 'packet' === $part
		? array( 'guide', 'help', 'nearby', 'menus', 'places', 'notices', 'schedule', 'settings', 'tournaments', 'campus' )
		: array( 'schedule', 'places', 'help', 'notices', 'settings', 'guide' );
}

/** Do these rows differ in what the part prints? */
function ogc_print_differs( $part, $name, $a, $b ) {
	if ( 'settings' === $name ) {
		$kv = function ( $rows ) {
			$o = array();
			foreach ( (array) $rows as $r ) {
				if ( isset( $r['key'] ) && in_array( $r['key'], OGC_PRINT_KEYS, true ) ) {
					$o[ $r['key'] ] = isset( $r['value'] ) ? (string) $r['value'] : '';
				}
			}
			ksort( $o );
			return $o;
		};
		return $kv( $a ) !== $kv( $b );
	}
	if ( 'guide' === $name && 'schedule' === $part ) {
		$pre = function ( $rows ) {
			return array_values( array_filter( (array) $rows, function ( $g ) {
				return isset( $g['id'] ) && 'preteens' === strtolower( trim( (string) $g['id'] ) );
			} ) );
		};
		return wp_json_encode( $pre( $a ) ) !== wp_json_encode( $pre( $b ) );
	}
	return wp_json_encode( array_values( (array) $a ) ) !== wp_json_encode( array_values( (array) $b ) );
}

function ogc_print_watch( $rows, $year, $name, $cur ) {
	if ( ! $cur || ! ogc_valid_year( $year ) ) {
		return $rows;
	}
	$s = null;
	foreach ( array( 'schedule', 'packet' ) as $part ) {
		$key = 'packet' === $part ? 'packet_posted' : 'schedule_posted';
		if ( ! in_array( $name, ogc_print_part_files( $part ), true ) || ! ogc_print_differs( $part, $name, $cur['rows'], $rows ) ) {
			continue;
		}
		$s = null === $s ? ogc_print_kv( $year ) : $s;
		if ( empty( $s[ $key ] ) || ! ogc_print_iso( $s[ $key ] ) || ! ogc_print_posted( $year, $key ) ) {
			continue;
		}
		$GLOBALS['ogc_print_pending'][] = array( 'year' => (int) $year, 'name' => $name, 'version' => (int) $cur['version'], 'part' => $part, 'posted' => $s[ $key ], 'before' => 'schedule' === $name && 'schedule' === $part ? $cur['rows'] : null );
	}
	return $rows;
}
add_filter( 'ogc_file_rows', 'ogc_print_watch', 99, 4 );

add_action( 'shutdown', function () {
	if ( empty( $GLOBALS['ogc_print_pending'] ) ) {
		return;
	}
	foreach ( $GLOBALS['ogc_print_pending'] as $p ) {
		$now = ogc_file_get( $p['year'], $p['name'] );
		if ( ! $now || $now['version'] <= $p['version'] ) {
			continue;
		}
		$s = ogc_print_kv( $p['year'] );
		if ( null !== $p['before'] && ! ogc_print_base( $p['year'], $s ) ) {
			ogc_state_put( $p['year'], 'print_base', array( 'posted' => $p['posted'], 'at' => ogc_now(), 'rows' => $p['before'] ) );
		}
		$st = ogc_state_get( $p['year'], 'print_updated' );
		$v  = $st && is_array( $st['value'] ) ? $st['value'] : array();
		$v[ $p['part'] ] = array( 'posted' => $p['posted'], 'at' => ogc_now() );
		ogc_state_put( $p['year'], 'print_updated', $v );
	}
	$GLOBALS['ogc_print_pending'] = array();
} );

/* ================================================================== the pages */

add_filter( 'ogc_pages', function ( $p ) {
	$css = array( 'shared/ogc-tokens.css', 'shared/ogc-ui.css', 'schedule-hub/week.css' );
	if ( isset( $p['schedule'] ) ) {
		$p['schedule']['template'] = 'print-schedule.php';
		$p['schedule']['title']    = 'Printable schedule';
		$p['schedule']['fonts']    = 'family=Roboto+Condensed:wght@400;700';
		$p['schedule']['styles']   = array_merge( $css, array( 'schedule/print.css', 'schedule/schedule.css' ) );
		$p['schedule']['scripts']  = array( 'shared/ogc-core.js', 'schedule/vendor/qrcode.js', 'schedule/print.js', 'schedule/schedule.js' );
		$p['schedule']['header']   = array( 'topbar' => false, 'crumb' => 'Printable schedule', 'crumb_parent' => 'Annual Conference', 'crumb_parent_href' => '' );
	}
	if ( isset( $p['packet'] ) ) {
		$p['packet']['template'] = 'print-packet.php';
		$p['packet']['fonts']    = 'family=Roboto+Condensed:wght@400;700';
		$p['packet']['styles']   = array_merge( $css, array( 'shared/ogc-map.css', 'schedule/print.css', 'packet/packet.css' ) );
		// The floors (Nov 5, feedback 264bfe637ee3): the packet draws the floor plans of the buildings its
		// rooms are in, after the campus map, with the map's own floor code (no router).
		$p['packet']['scripts']  = array( 'shared/ogc-core.js', 'shared/ogc-map.js', 'shared/ogc-map-floors.js', 'schedule/vendor/qrcode.js', 'schedule/print.js', 'packet/packet.js' );
		$p['packet']['header']   = array( 'topbar' => false, 'crumb' => 'Information packet', 'crumb_parent' => 'Annual Conference', 'crumb_parent_href' => '' );
	}
	return $p;
}, 20 );

add_filter( 'ogc_client_config', function ( $cfg, $key ) {
	if ( 'schedule' === $key || 'packet' === $key ) {
		$cfg['print'] = ogc_print_payload( $key );
	}
	return $cfg;
}, 10, 2 );

// Before the page: its status (404 for no such year), and caching. The printouts change late (the
// last 2026 change came on the first day), so no page cache keeps them: WP Rocket is told to leave
// them alone, and a browser checks again each time (ETag: a 304 when nothing changed).
add_action( 'ogc_before_page', function ( $page ) {
	if ( 'schedule' !== $page && 'packet' !== $page ) {
		return;
	}
	$c = ogc_print_ctx( $page );
	// One title pattern for both: "Printable schedule – 2026 Annual Conference".
	// A year that doesn't exist is named as the page's heading names it: "No schedule for 2031".
	add_filter( 'pre_get_document_title', function () use ( $c, $page ) {
		if ( 'missing' === $c['state'] ) {
			return ( 'packet' === $page ? 'No packet' : 'No schedule' ) . ( $c['year'] ? ' for ' . $c['year'] : '' ) . ' – Annual Conference';
		}
		$what = 'packet' === $page ? 'Information packet' : 'Printable schedule';
		return $what . ' – ' . ( $c['year'] ? $c['year'] . ' ' : '' ) . 'Annual Conference';
	}, 20 );
	if ( ! defined( 'DONOTCACHEPAGE' ) ) {
		define( 'DONOTCACHEPAGE', true );
	}
	if ( 'missing' === $c['state'] ) {
		add_filter( 'status_header', function ( $h, $code, $desc, $proto ) {
			return 200 === (int) $code ? $proto . ' 404 Not Found' : $h;
		}, 10, 4 );
		add_filter( 'wp_robots', 'wp_robots_no_robots' );
		return;
	}
	// "Not posted yet" and a member's draft are never for a search engine.
	if ( 'wait' === $c['state'] || $c['draft'] ) {
		add_filter( 'wp_robots', 'wp_robots_no_robots' );
	}
	// The ETag covers everything the page is drawn from: the files' versions (read without their rows),
	// the Conference's own row (dates, venue, hosts, announced), the schedule as published, a member's
	// last fit, the person, today and the code.
	global $wpdb;
	$vers = $wpdb->get_results( $wpdb->prepare( 'SELECT name, version, updated_at FROM ' . ogc_table( 'files' ) . ' WHERE year = %d ORDER BY name', $c['year'] ), ARRAY_A );
	$base  = ogc_state_get( $c['year'], 'print_base' );
	$fit   = $c['member'] ? ogc_state_get( $c['year'], 'print_status' ) : null;
	$parts = array( $page, $c['year'], $c['state'], $c['member'], get_current_user_id(), wp_create_nonce( 'wp_rest' ), $vers, md5( wp_json_encode( $c['row'] ) ), $base ? $base['version'] : 0, $fit ? $fit['version'] : 0, OGC_VERSION, ogc_print_today( $c['settings'] ) );
	foreach ( array( 'schedule/print.js', 'schedule/print.css', 'schedule/schedule.js', 'schedule/schedule.css', 'packet/packet.js', 'packet/packet.css' ) as $a ) {
		$parts[] = @filemtime( OGC_DIR . 'assets/' . $a ); // phpcs:ignore -- a missing file just leaves false.
	}
	$etag = '"p' . md5( wp_json_encode( $parts ) ) . '"';
	header( 'ETag: ' . $etag );
	if ( ! is_user_logged_in() ) {
		header( 'Cache-Control: private, no-cache' );
	}
	$inm = isset( $_SERVER['HTTP_IF_NONE_MATCH'] ) ? trim( wp_unslash( $_SERVER['HTTP_IF_NONE_MATCH'] ) ) : ''; // phpcs:ignore -- compared, never printed.
	if ( $inm && $inm === $etag ) {
		status_header( 304 );
		exit;
	}
}, 5 );

add_filter( 'rocket_cache_reject_uri', function ( $uris ) {
	$b      = '/' . ogc_base_path();
	$uris[] = $b . '/schedule/(.*)';
	$uris[] = $b . '/packet/(.*)';
	return $uris;
} );
