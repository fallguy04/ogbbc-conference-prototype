<?php
/**
 * The COA's year (the year area): the server side of /annual-conference/year/.
 *
 * What it keeps (members only, in the state table, key "coa"): who ticked each step and when, the
 * "Looks right" checks, last year's notes marked Done, each part's publish stamp, what was last sent to
 * the campus, each part's due date. Owners stay in settings (owner_<part>) so the committees' pages
 * can read them, but the public never receives them.
 *
 * Routes (/wp-json/ogc/v1/coa/{year}…), each with a real permission check (members of that year;
 * webmasters for every year; Start is webmasters only) and the wp_rest nonce WordPress asks for:
 *   GET  coa/{y}                 the year at a glance: the COA state, the pickup log, last year's
 *                                notes, the history, members, the committees, the years (webmasters)
 *   POST coa/{y}/step            {id, done}         a step ticked by hand
 *   POST coa/{y}/check           {id, done}         "Looks right" on a thing (stamps who and when)
 *   POST coa/{y}/note            {hash, done}       last year's note marked Done (or brought back)
 *   POST coa/{y}/owner           {part, owner}      who does a part this year ('' for no one yet)
 *   POST coa/{y}/due             {part, date}       a part's due date
 *   POST coa/{y}/reg             {key, value}       a registration fact, checked here
 *   POST coa/{y}/publish         {part, act, …}     publish, unpublish, schedule, close, reopen
 *   POST coa/{y}/needs           {ops, add}         requests answered and changed, stamped
 *   POST coa/{y}/sent            {what, ids}        "Mark sent": what the campus has
 *   POST coa/{y}/intro           {}                 "How this works" closed (per member)
 * and in module-coa-pickup.php: start, pickup, dates, campus, campus-restore.
 *
 * It also writes a short "what changed" into the change log for every file a member saves, so each
 * part's History can say "Ruth K. · Room price 65 → 68" (never anyone's personal data).
 */

defined( 'ABSPATH' ) || exit;

const OGC_NOT_YET = '9999-12-31';

/* ================================================================== small helpers */

/** A year's settings-style file (settings, registration) as key → value. */
function ogc_coa_kv( $year, $name ) {
	$f   = ogc_file_get( $year, $name );
	$out = array();
	foreach ( $f ? $f['rows'] : array() as $r ) {
		if ( isset( $r['key'] ) ) {
			$out[ (string) $r['key'] ] = isset( $r['value'] ) ? (string) $r['value'] : '';
		}
	}
	return $out;
}

/** Set one key of a settings-style file (merged on the server's copy). */
function ogc_coa_set( $year, $name, $key, $value ) {
	return ogc_file_patch( $year, $name, array( 'op' => 'key', 'key' => (string) $key, 'value' => (string) $value ) );
}

/** The year's own time zone (the campus's), for "today" and every stamp. */
function ogc_coa_tz( $year ) {
	$s  = ogc_coa_kv( $year, 'settings' );
	$tz = ! empty( $s['timezone'] ) ? $s['timezone'] : 'America/Indiana/Indianapolis';
	try {
		return new DateTimeZone( $tz );
	} catch ( Exception $e ) {
		return new DateTimeZone( 'America/Indiana/Indianapolis' );
	}
}

/** Today at the campus. Stamps come from here, never from a browser's clock or ?as-of. */
function ogc_coa_today( $year ) {
	$d = new DateTime( 'now', ogc_coa_tz( $year ) );
	return $d->format( 'Y-m-d' );
}

function ogc_coa_iso( $v ) {
	return is_string( $v ) && preg_match( '/^\d{4}-\d{2}-\d{2}$/', $v ) && checkdate( (int) substr( $v, 5, 2 ), (int) substr( $v, 8, 2 ), (int) substr( $v, 0, 4 ) );
}

function ogc_coa_add_days( $iso, $n ) {
	$d = DateTime::createFromFormat( '!Y-m-d', $iso, new DateTimeZone( 'UTC' ) );
	$d->modify( ( $n >= 0 ? '+' : '' ) . (int) $n . ' days' );
	return $d->format( 'Y-m-d' );
}

function ogc_coa_days_between( $a, $b ) {
	$x = DateTime::createFromFormat( '!Y-m-d', $a, new DateTimeZone( 'UTC' ) );
	$y = DateTime::createFromFormat( '!Y-m-d', $b, new DateTimeZone( 'UTC' ) );
	return (int) round( ( $y->getTimestamp() - $x->getTimestamp() ) / 86400 );
}

/** "May 28" */
function ogc_coa_md( $iso ) {
	if ( ! ogc_coa_iso( $iso ) ) {
		return '';
	}
	$d = DateTime::createFromFormat( '!Y-m-d', $iso, new DateTimeZone( 'UTC' ) );
	return $d->format( 'F j' );
}

/** A person as the site shows names: "Ruth K." (from their display name). */
function ogc_coa_first_l( $user_id ) {
	$u = $user_id ? get_userdata( (int) $user_id ) : null;
	if ( ! $u ) {
		return '';
	}
	$n = trim( preg_replace( '/\s+/', ' ', (string) $u->display_name ) );
	if ( '' === $n || false !== strpos( $n, '@' ) ) {
		$n = ucfirst( strstr( (string) $u->user_email, '@', true ) );
	}
	$p = explode( ' ', $n );
	if ( count( $p ) < 2 ) {
		return $p[0];
	}
	$last = end( $p );
	return $p[0] . ' ' . ( preg_match( '/^\p{L}\.$/u', $last ) ? $last : mb_substr( $last, 0, 1 ) . '.' );
}

/** A setting that publishes something (schedule_posted…): is it public today? Blank counts as
 * public (years made before the year area, whose pages show what they have). */
function ogc_coa_posted( $year, $key ) {
	$s = ogc_coa_kv( $year, 'settings' );
	$v = isset( $s[ $key ] ) ? $s[ $key ] : '';
	if ( '' === $v ) {
		return true;
	}
	return ogc_coa_iso( $v ) && OGC_NOT_YET !== $v && $v <= ogc_coa_today( $year );
}

/** Is a thing confirmed this year ("Looks right": 'conf:callin', 'reg:prices', 'help:<id>'…)?
 * A year the year area didn't pick up has nothing waiting to be confirmed. */
function ogc_coa_is_confirmed( $year, $id ) {
	$c = ogc_coa_state( $year );
	if ( ! empty( $c['checks'][ $id ] ) ) {
		return true;
	}
	$p = ogc_state_get( $year, 'picked' );
	$p = $p ? (array) $p['value'] : array();
	return empty( $p['confirm'] ) || ! in_array( $id, (array) $p['confirm'], true );
}

/* ================================================================== the COA's state */

/** The year's COA state (members only). */
function ogc_coa_state( $year ) {
	$s = ogc_state_get( $year, 'coa' );
	$v = $s ? (array) $s['value'] : array();
	foreach ( array( 'steps', 'checks', 'notes_done', 'pub', 'sent', 'due' ) as $k ) {
		$v[ $k ] = isset( $v[ $k ] ) && is_array( $v[ $k ] ) ? $v[ $k ] : array();
	}
	return $v;
}

/** Change the COA state with $fn( &$state ), on the server's latest copy: two people ticking at
 * once both land (it retries on a version clash). */
function ogc_coa_update( $year, $fn ) {
	for ( $i = 0; $i < 8; $i++ ) {
		$cur = ogc_state_get( $year, 'coa' );
		$v   = ogc_coa_state( $year );
		$fn( $v );
		$r = ogc_state_put( $year, 'coa', $v, $cur ? $cur['version'] : 0 );
		if ( ! is_wp_error( $r ) ) {
			return $v;
		}
	}
	return new WP_Error( 'ogc_busy', 'Busy · Retry', array( 'status' => 503 ) );
}

/** Who and when, for a stamp. */
function ogc_coa_stamp( $year, $extra = array() ) {
	return array_merge( array( 'by' => ogc_coa_first_l( get_current_user_id() ), 'uid' => get_current_user_id(), 'at' => ogc_coa_today( $year ), 'ts' => ogc_now() ), $extra );
}

/* ================================================================== the public never gets these */

// The COA's working keys in settings (owners, the ticks v3 kept there): members only.
function ogc_coa_private_key( $k ) {
	// One list, the conference area's (module-public.php).
	if ( function_exists( 'ogc_pub_private_setting' ) ) {
		return ogc_pub_private_setting( $k );
	}
	return (bool) preg_match( '/^(owner_|steps_done$|notes_done$|due_|tool_note)/', (string) $k );
}

add_filter( 'ogc_file_rows_out', function ( $rows, $year, $name, $member ) {
	if ( $member ) {
		return $rows;
	}
	if ( 'settings' === $name ) {
		// An unannounced year: its name and hosts only.
		$held = null !== ogc_coa_held_back( $year );
		$rows = array_values( array_filter( (array) $rows, function ( $r ) use ( $held ) {
			$k = isset( $r['key'] ) ? (string) $r['key'] : '';
			return ! ogc_coa_private_key( $k ) && ( ! $held || in_array( $k, array( 'title', 'year', 'hosts' ), true ) );
		} ) );
	}
	// Carried prices nobody has checked aren't public until "Looks right", or until registration is
	// scheduled (scheduling is publishing them).
	if ( 'registration' === $name && ! ogc_coa_is_confirmed( $year, 'reg:prices' ) ) {
		$r0 = ogc_coa_kv( $year, 'registration' );
		if ( empty( $r0['opens'] ) || ! ogc_coa_iso( $r0['opens'] ) || OGC_NOT_YET === $r0['opens'] ) {
			$rows = array_values( array_filter( (array) $rows, function ( $r ) {
				return ! ( isset( $r['key'] ) && preg_match( '/_price$|_fee$|^rooms_held$|_stock$/', (string) $r['key'] ) );
			} ) );
		}
	}
	// The "to check" mark and the requests' answer stamps are the COA's.
	return array_map( function ( $r ) {
		unset( $r['_look'], $r['answered_by'], $r['answered_as'], $r['answered_at'], $r['question'] );
		return $r;
	}, (array) $rows );
}, 20, 4 );

// A part waiting for Publish isn't sent to the public at all (the page may draw nothing, but the file
// mustn't be fetchable either). Blank (an older year) counts as published.
add_filter( 'ogc_file_visible', function ( $ok, $year, $name, $member ) {
	if ( ! $ok || $member ) {
		return $ok;
	}
	// An unannounced year: nothing but its settings' name and hosts (filtered above).
	if ( null !== ogc_coa_held_back( $year ) && 'settings' !== $name ) {
		return false;
	}
	// Tournaments wait for Schedule (when teams sign up on the site; otherwise there's nothing to open).
	if ( 'tournaments' === $name ) {
		$s = ogc_coa_kv( $year, 'settings' );
		return 'no' === ( isset( $s['tournaments_online'] ) ? $s['tournaments_online'] : '' ) || 'yes' !== ( isset( $s['tournaments_held'] ) ? $s['tournaments_held'] : '' );
	}
	// One table of gates, the conference area's (module-public.php ogc_pub_gates()).
	$gate = function_exists( 'ogc_pub_gates' ) ? ogc_pub_gates() : array( 'schedule' => 'schedule_posted', 'guide' => 'packet_posted', 'menus' => 'packet_posted', 'shifts' => 'signups_posted' );
	return isset( $gate[ $name ] ) ? ogc_coa_posted( $year, $gate[ $name ] ) : $ok;
}, 10, 4 );

// Nothing opens to the public that nobody scheduled: a registration, a team or a shift sign-up from
// someone who isn't a member is refused while its part is held or closed.
add_filter( 'ogc_record_can_write', function ( $ok, $action, $kind, $year, $record, $data, $req ) {
	if ( ! $ok || 'create' !== $action || ogc_is_member( $year ) ) {
		return $ok;
	}
	$s     = ogc_coa_kv( $year, 'settings' );
	$today = ogc_coa_today( $year );
	$shut  = function ( $k ) use ( $s, $today ) {
		return ! empty( $s[ $k ] ) && ogc_coa_iso( $s[ $k ] ) && $s[ $k ] <= $today;
	};
	if ( 'registrations' === $kind ) {
		return ! ( isset( $s['registration_opens'] ) && OGC_NOT_YET === $s['registration_opens'] ) && ! $shut( 'registration_closed' );
	}
	if ( 'teams' === $kind ) {
		return 'yes' !== ( isset( $s['tournaments_held'] ) ? $s['tournaments_held'] : '' ) && ! $shut( 'tournaments_closed' );
	}
	if ( 'signups' === $kind ) {
		return ogc_coa_posted( $year, 'signups_posted' ) && ! $shut( 'signups_closed' );
	}
	return $ok;
}, 20, 7 );

// Rows saved one at a time are found by their own id (two committee heads answering different
// requests never clash): the requests by "id", the notes by "_id". ogc-store.js reads OGC_WP.rowKeys.
add_filter( 'ogc_file_row_keys', function ( $k ) {
	return array_merge( $k, array( 'needs' => 'id', 'notes' => '_id' ) );
} );
add_filter( 'ogc_client_config', function ( $cfg, $key ) {
	$cfg['rowKeys'] = array( 'needs' => 'id', 'notes' => '_id' );
	// The year page draws counts, never people: it loads no one's records (the counts come with
	// GET coa/{y}). Only the lists and Lodging, which show people, fetch them.
	if ( 'year' === $key ) {
		$cfg['recordKinds'] = array();
		$cfg['recordYears'] = 1;
	}
	return $cfg;
}, 10, 2 );

/* ------------------------------------------------------------------ a year not yet announced */

/**
 * A year the webmasters started on the site keeps, until its COA announces it, only what the public
 * already knew when it was started (the year and its hosts, from the last Conference's announcement):
 * the dates, campus and prices the COA works out aren't sent to anyone else before Announce.
 * Started years keep that first public row in the state "public_row"; older years (seeded, or
 * picked up before this) have none and aren't held.
 */
function ogc_coa_held_back( $year ) {
	static $memo = array();
	$year = (int) $year;
	if ( isset( $memo[ $year ] ) ) {
		return $memo[ $year ];
	}
	$snap = ogc_state_get( $year, 'public_row' );
	if ( ! $snap ) {
		return $memo[ $year ] = null;
	}
	$row = ogc_year_get( $year );
	$on  = $row && ! empty( $row['coa_announced'] ) ? (string) $row['coa_announced'] : '';
	if ( ogc_coa_iso( $on ) && $on <= ogc_coa_today( $year ) ) {
		return $memo[ $year ] = null;
	}
	return $memo[ $year ] = (array) $snap['value'];
}

// years.csv for anyone who isn't a member of that year: an unannounced year as it was first known.
add_filter( 'ogc_years_public', function ( $rows, $is_webmaster ) {
	return array_map( function ( $r ) {
		$y = isset( $r['year'] ) ? (int) $r['year'] : 0;
		if ( ! $y || ogc_is_member( $y ) ) {
			return $r;
		}
		$was = ogc_coa_held_back( $y );
		if ( null === $was ) {
			return $r;
		}
		foreach ( array( 'start', 'end', 'venue', 'city', 'data', 'coa_announced' ) as $k ) {
			$r[ $k ] = isset( $was[ $k ] ) ? (string) $was[ $k ] : '';
		}
		$r['open'] = '';
		return $r;
	}, (array) $rows );
}, 20, 2 );

// Only members read next year's notes and the committees' list (the volunteer area says so too).
add_filter( 'ogc_private_files', function ( $l ) {
	return array_values( array_unique( array_merge( (array) $l, array( 'notes', 'needs', 'committees' ) ) ) );
} );

/* ================================================================== the year page's own pages */

add_filter( 'ogc_pages', function ( $p ) {
	if ( isset( $p['year'] ) ) {
		$p['year']['scripts'] = array_values( array_unique( array_merge(
			array_diff( (array) $p['year']['scripts'], array( 'year/year.js' ) ),
			array( 'year/year-xlsx.js', 'year/year.js' )
		) ) );
		$p['year']['title'] = 'Committee of Arrangements';
	}
	return $p;
} );

// Not a member of the year asked for: the signin area's page says so ("No access to 2027").

/* ================================================================== REST */

add_action( 'rest_api_init', 'ogc_coa_routes' );

function ogc_coa_routes() {
	$Y = '(?P<year>\d{4})';
	register_rest_route( OGC_NS, "/coa/$Y", array(
		array( 'methods' => 'GET', 'callback' => 'ogc_coa_rest_overview', 'permission_callback' => 'ogc_can_member' ),
	) );
	$acts = array(
		'step'    => 'ogc_coa_rest_step',
		'check'   => 'ogc_coa_rest_check',
		'note'    => 'ogc_coa_rest_note',
		'owner'   => 'ogc_coa_rest_owner',
		'due'     => 'ogc_coa_rest_due',
		'reg'     => 'ogc_coa_rest_reg',
		'publish' => 'ogc_coa_rest_publish',
		'needs'   => 'ogc_coa_rest_needs',
		'sent'    => 'ogc_coa_rest_sent',
		'intro'   => 'ogc_coa_rest_intro',
	);
	foreach ( $acts as $a => $cb ) {
		register_rest_route( OGC_NS, "/coa/$Y/$a", array(
			array( 'methods' => 'POST', 'callback' => $cb, 'permission_callback' => 'ogc_can_member' ),
		) );
	}
}

function ogc_coa_bad( $msg, $status = 400, $data = array() ) {
	return new WP_Error( 'ogc_coa', $msg, array_merge( array( 'status' => $status ), $data ) );
}

/** The year's parts, in the order they happen. */
function ogc_coa_parts() {
	return array( 'conference', 'schedule', 'requests', 'registration', 'helping', 'youngfolks', 'packet' );
}

/** Which part a file belongs to (for History). */
function ogc_coa_part_of_file( $name ) {
	$m = array(
		'settings' => 'conference', 'places' => 'conference', 'nearby' => 'conference', 'rooms' => 'conference', 'plans' => 'conference', 'campus' => 'conference', 'notices' => 'conference', 'committees' => 'conference',
		'schedule' => 'schedule', 'attachments' => 'schedule',
		'needs' => 'requests',
		'registration' => 'registration',
		'shifts' => 'helping',
		'tournaments' => 'youngfolks',
		'guide' => 'packet', 'help' => 'packet', 'menus' => 'packet',
		'notes' => '',
	);
	return isset( $m[ $name ] ) ? $m[ $name ] : '';
}

/** The year at a glance, for the year page (one request, not fifteen). */
function ogc_coa_rest_overview( WP_REST_Request $req ) {
	$y    = (int) $req['year'];
	$row  = ogc_year_get( $y );
	$pick = ogc_state_get( $y, 'picked' );
	$uid  = get_current_user_id();
	$out  = array(
		'year'      => $row,
		'today'     => ogc_coa_today( $y ),
		'coa'       => ogc_coa_state( $y ),
		'picked'    => $pick ? $pick['value'] : null,
		'undo'      => ogc_coa_undo_summary( $y ),
		'notes'     => ogc_coa_earlier_notes( $y ),
		'history'   => ogc_coa_history( $y, 80 ),
		'me'        => array(
			'name'      => ogc_coa_first_l( $uid ),
			'email'     => ogc_current_email(),
			'intro'     => (bool) get_user_meta( $uid, 'ogc_coa_intro_seen', true ),
			'committee' => ogc_coa_member_committee( $y, ogc_current_email() ),
			'webmaster' => ogc_is_webmaster(),
		),
		'counts'    => ogc_coa_counts( $y ),
		'prev'      => ogc_coa_prev_year( $y ),
		'prevOwners' => ogc_coa_prev_owners( $y ),
		'years'     => ogc_is_webmaster() ? array_values( array_map( function ( $r ) { return array( 'year' => $r['year'], 'data' => isset( $r['data'] ) ? $r['data'] : '' ); }, ogc_years_all() ) ) : array_map( 'strval', ogc_member_years() ),
	);
	return rest_ensure_response( $out );
}

/**
 * How many, never who: what the year page prints ("12 households", "20 of 57", "6 teams") without
 * sending anyone's record to the browser. A sign-up's id is its shift's uid (the volunteer area),
 * with "|date" after it for a shift on several days; a team names its tournament.
 */
function ogc_coa_counts( $year ) {
	$out = array( 'registrations' => 0, 'signups' => 0, 'shifts' => array(), 'teams' => array(), 'credits' => 0 );
	foreach ( ogc_records( $year, 'registrations' ) as $r ) {
		$out['registrations']++;
	}
	foreach ( ogc_records( $year, 'signups' ) as $r ) {
		$d  = (array) ( isset( $r['data'] ) ? $r['data'] : array() );
		$id = strtok( (string) ( isset( $d['id'] ) ? $d['id'] : '' ), '|' );
		if ( '' === (string) $id ) {
			continue;
		}
		$out['signups']++;
		$out['shifts'][ $id ] = ( isset( $out['shifts'][ $id ] ) ? $out['shifts'][ $id ] : 0 ) + 1;
	}
	// Live teams only (the tournaments area's rule: not withdrawn or removed), by tournament id.
	$teams = function_exists( 'ogc_tn_teams' ) ? ogc_tn_teams( $year ) : ogc_records( $year, 'teams' );
	foreach ( $teams as $r ) {
		$d = (array) ( isset( $r['data'] ) ? $r['data'] : array() );
		$t = ! empty( $d['tid'] ) ? $d['tid'] : ( ! empty( $d['tournament'] ) ? $d['tournament'] : '' );
		if ( '' !== (string) $t ) {
			$out['teams'][ $t ] = ( isset( $out['teams'][ $t ] ) ? $out['teams'][ $t ] : 0 ) + 1;
		}
	}
	foreach ( ogc_records( $year, 'credits' ) as $r ) {
		$d = (array) ( isset( $r['data'] ) ? $r['data'] : array() );
		if ( empty( $d['given'] ) ) {
			$out['credits']++;
		}
	}
	$out['shifts'] = (object) $out['shifts'];
	$out['teams']  = (object) $out['teams'];
	return $out;
}

/** Last year's owners, offered as a suggestion when this year's COA chooses ("2026: Lodging committee"). */
function ogc_coa_prev_owners( $year ) {
	$p   = ogc_coa_prev_year( $year );
	$out = array();
	if ( $p ) {
		foreach ( ogc_coa_kv( (int) $p['year'], 'settings' ) as $k => $v ) {
			if ( 0 === strpos( $k, 'owner_' ) && '' !== $v ) {
				$out[ substr( $k, 6 ) ] = $p['year'] . ': ' . $v;
			}
		}
	}
	return (object) $out;
}

/** The last year before this one that had a Conference on the site (its files). */
function ogc_coa_prev_year( $year ) {
	foreach ( ogc_years_all() as $r ) {
		if ( (int) $r['year'] < (int) $year && ! empty( $r['data'] ) ) {
			return array( 'year' => $r['year'], 'start' => isset( $r['start'] ) ? $r['start'] : '', 'end' => isset( $r['end'] ) ? $r['end'] : '', 'venue' => isset( $r['venue'] ) ? $r['venue'] : '' );
		}
	}
	return null;
}

/** Notes for this year from the last one, and any older note nobody marked Done ("Still open from
 * 2025"). Read here, as a step of the server's own, so a member of 2027 never reads 2026's files. */
function ogc_coa_earlier_notes( $year ) {
	$p = ogc_coa_prev_year( $year );
	if ( ! $p ) {
		return array();
	}
	$out = array();
	$f   = ogc_file_get( (int) $p['year'], 'notes' );
	foreach ( $f ? $f['rows'] : array() as $n ) {
		if ( empty( $n['text'] ) ) {
			continue;
		}
		$out[] = array( 'year' => $p['year'], 'part' => isset( $n['part'] ) ? $n['part'] : '', 'text' => $n['text'], 'by' => isset( $n['by'] ) ? $n['by'] : '', 'at' => isset( $n['at'] ) ? $n['at'] : '', 'hash' => ogc_coa_hash( ( isset( $n['part'] ) ? $n['part'] : '' ) . $n['text'] ) );
	}
	// Notes carried from the year before that one, not marked Done there.
	$pp = ogc_coa_prev_year( (int) $p['year'] );
	if ( $pp ) {
		$done = ogc_coa_state( (int) $p['year'] );
		$done = $done['notes_done'];
		$old  = ogc_file_get( (int) $pp['year'], 'notes' );
		foreach ( $old ? $old['rows'] : array() as $n ) {
			if ( empty( $n['text'] ) ) {
				continue;
			}
			$h = ogc_coa_hash( ( isset( $n['part'] ) ? $n['part'] : '' ) . $n['text'] );
			if ( empty( $done[ $h ] ) ) {
				$out[] = array( 'year' => $pp['year'], 'part' => isset( $n['part'] ) ? $n['part'] : '', 'text' => $n['text'], 'by' => isset( $n['by'] ) ? $n['by'] : '', 'at' => isset( $n['at'] ) ? $n['at'] : '', 'hash' => $h, 'still' => true );
			}
		}
	}
	return $out;
}

/** The same short hash the page makes (djb2, base 36), so a note keeps its Done across devices. */
function ogc_coa_hash( $t ) {
	$h = 5381;
	foreach ( preg_split( '//u', (string) $t, -1, PREG_SPLIT_NO_EMPTY ) as $c ) {
		$code = mb_ord( $c, 'UTF-8' );
		// JS charCodeAt gives UTF-16 units: a character beyond the BMP counts as two.
		$units = $code > 0xFFFF ? array( 0xD800 + ( ( $code - 0x10000 ) >> 10 ), 0xDC00 + ( ( $code - 0x10000 ) & 0x3FF ) ) : array( $code );
		foreach ( $units as $u ) {
			$h = ( ( ( $h << 5 ) + $h ) + $u ) & 0xFFFFFFFF;
		}
	}
	return base_convert( (string) $h, 10, 36 );
}

/* ------------------------------------------------------------------ History */

/** The year's recent changes in a form the page words plainly: who (First L.), when, which part,
 * what (from the summaries this module writes). Members only (the route checks). */
function ogc_coa_history( $year, $limit = 80 ) {
	global $wpdb;
	$rows  = $wpdb->get_results( $wpdb->prepare(
		'SELECT * FROM ' . ogc_table( 'log' ) . " WHERE year = %d AND action IN ('change','coa','year_start','year_set','year_pickup','campus','dates','mail_invite','member') ORDER BY id DESC LIMIT %d",
		$year, $limit
	), ARRAY_A );
	$names = array();
	$as    = array();
	$out   = array();
	foreach ( (array) $rows as $r ) {
		$uid = (int) $r['user'];
		if ( ! isset( $names[ $uid ] ) ) {
			$names[ $uid ] = ogc_coa_first_l( $uid );
			// Someone who isn't on this year's Members list is named with why: a webmaster, or removed.
			$m  = $uid && function_exists( 'ogc_member_find' ) ? ogc_member_find( $year, ogc_user_email( $uid ), true ) : null;
			$on = ! $uid || ! function_exists( 'ogc_member_find' ) || ( $m && empty( $m['removed_at'] ) );
			$as[ $uid ] = $on ? '' : ( ogc_is_webmaster( $uid ) ? 'webmaster' : ( $m ? 'removed' : 'not on Members' ) );
		}
		$d = (array) ogc_unjson( $r['detail'], array() );
		if ( 'year_set' === $r['action'] ) {
			// Keep only the year's facts the page words (dates, campus, hosts, announced).
			$d = array( 'fields' => isset( $d['fields'] ) ? $d['fields'] : array() );
		}
		$out[] = array(
			'id'     => (int) $r['id'],
			'at'     => $r['at'],
			'who'    => $names[ $uid ],
			'as'     => $as[ $uid ],
			'mine'   => $uid && $uid === get_current_user_id(),
			'action' => $r['action'],
			'target' => $r['target'],
			'part'   => 'change' === $r['action'] ? ogc_coa_part_of_file( $r['target'] ) : ( isset( $d['part'] ) ? $d['part'] : '' ),
			'detail' => $d,
		);
	}
	return $out;
}

// Each member's save of a file: what it was before, so the log can say what changed.
add_filter( 'rest_request_before_callbacks', function ( $resp, $handler, $req ) {
	if ( is_wp_error( $resp ) || ! in_array( $req->get_method(), array( 'PUT', 'PATCH' ), true ) ) {
		return $resp;
	}
	if ( ! preg_match( '#^/' . preg_quote( OGC_NS, '#' ) . '/years/(\d{4})/files/([a-z][a-z0-9_-]*)$#', $req->get_route(), $m ) ) {
		return $resp;
	}
	// A registration fact is checked here too (the year page sends it through coa/{y}/reg, but the
	// files route takes the same key from any page).
	if ( 'registration' === $m[2] && 'PATCH' === $req->get_method() && 'key' === $req->get_param( 'op' ) ) {
		$bad = ogc_coa_reg_check( (int) $m[1], (string) $req->get_param( 'key' ), (string) $req->get_param( 'value' ) );
		if ( is_wp_error( $bad ) ) {
			return $bad;
		}
	}
	$f = ogc_file_get( (int) $m[1], $m[2] );
	$GLOBALS['ogc_coa_before'][ $m[1] . '/' . $m[2] ] = $f ? $f['rows'] : array();
	return $resp;
}, 10, 3 );

add_action( 'ogc_file_saved', function ( $year, $name, $version ) {
	$k = $year . '/' . $name;
	if ( ! isset( $GLOBALS['ogc_coa_before'][ $k ] ) ) {
		return;
	}
	$before = $GLOBALS['ogc_coa_before'][ $k ];
	unset( $GLOBALS['ogc_coa_before'][ $k ] );
	$after = ogc_file_get( $year, $name );
	$sum   = ogc_coa_diff( $name, $before, $after ? $after['rows'] : array() );
	if ( $sum ) {
		ogc_log( 'change', $year, $name, $sum );
	}
}, 10, 3 );

/** What changed in a file, short, with no one's personal data (no phones, no emails, no notes' text). */
function ogc_coa_diff( $name, $before, $after ) {
	$kv = in_array( $name, array( 'settings', 'registration' ), true );
	if ( $kv ) {
		$a = array();
		$b = array();
		foreach ( $before as $r ) {
			if ( isset( $r['key'] ) ) {
				$a[ $r['key'] ] = isset( $r['value'] ) ? (string) $r['value'] : '';
			}
		}
		foreach ( $after as $r ) {
			if ( isset( $r['key'] ) ) {
				$b[ $r['key'] ] = isset( $r['value'] ) ? (string) $r['value'] : '';
			}
		}
		$keys = array();
		foreach ( $b as $k => $v ) {
			$was = isset( $a[ $k ] ) ? $a[ $k ] : '';
			if ( $was !== $v ) {
				$short  = function ( $x ) {
					return mb_strlen( $x ) > 40 ? mb_substr( $x, 0, 38 ) . '…' : $x;
				};
				$hidden = (bool) preg_match( '/phone|email|pin|url|address|note$/', $k );
				$keys[] = $hidden ? array( $k ) : array( $k, $short( $was ), $short( $v ) );
			}
		}
		return $keys ? array( 'keys' => array_slice( $keys, 0, 8 ) ) : null;
	}
	// A row without an id is known by the one the year page gives it on loading (the file's first two
	// letters and its place: "co3"), so its first save isn't read as every row removed and added.
	$id    = function ( $r, $i ) use ( $name ) {
		foreach ( array( 'id', '_id' ) as $k ) {
			if ( ! empty( $r[ $k ] ) ) {
				return (string) $r[ $k ];
			}
		}
		return substr( $name, 0, 2 ) . ( $i + 1 );
	};
	$label = function ( $r ) use ( $name ) {
		if ( 'notes' === $name ) {
			return '';
		}
		foreach ( array( 'title', 'role', 'item', 'name', 'need', 'hall', 'code', 'text' ) as $k ) {
			if ( ! empty( $r[ $k ] ) ) {
				return mb_substr( (string) $r[ $k ], 0, 40 );
			}
		}
		return '';
	};
	$a = array();
	foreach ( array_values( (array) $before ) as $i => $r ) {
		$a[ $id( $r, $i ) ] = $r;
	}
	$out = array( 'added' => 0, 'removed' => 0, 'changed' => 0, 'labels' => array(), 'said' => array() );
	$seen = array();
	// What a row is called, compared without the id the page adds ("_id" isn't a change).
	$same = function ( $x, $y ) {
		unset( $x['_id'], $y['_id'] );
		return $x == $y; // phpcs:ignore Universal.Operators.StrictComparisonOperator -- same keys and values, any order.
	};
	foreach ( array_values( (array) $after ) as $i => $r ) {
		$k          = $id( $r, $i );
		$seen[ $k ] = 1;
		if ( ! isset( $a[ $k ] ) ) {
			$out['added']++;
			$out['labels'][] = $label( $r );
			$out['said'][]   = array( 'added', $label( $r ) );
		} elseif ( ! $same( $a[ $k ], $r ) ) {
			$out['changed']++;
			$out['labels'][] = $label( $r );
			$was             = $label( $a[ $k ] );
			$out['said'][]   = $was !== $label( $r ) && '' !== $was ? array( 'renamed', $was, $label( $r ) ) : array( 'changed', $label( $r ) );
		}
	}
	foreach ( $a as $k => $r ) {
		if ( ! isset( $seen[ $k ] ) ) {
			$out['removed']++;
			$out['labels'][] = $label( $r );
			$out['said'][]   = array( 'removed', $label( $r ) );
		}
	}
	if ( ! $out['added'] && ! $out['removed'] && ! $out['changed'] ) {
		return null;
	}
	$out['labels'] = array_slice( array_values( array_unique( array_filter( $out['labels'] ) ) ), 0, 3 );
	// Notes' text is never logged; the rest says what happened to each (up to four).
	$out['said'] = 'notes' === $name ? array() : array_slice( array_values( array_filter( $out['said'], function ( $s ) {
		return '' !== end( $s );
	} ) ), 0, 4 );
	return $out;
}

/* ------------------------------------------------------------------ the actions */

function ogc_coa_id_ok( $id ) {
	return is_string( $id ) && preg_match( '/^[A-Za-z0-9 _.:\/&()\'-]{1,80}$/u', $id );
}

function ogc_coa_rest_step( WP_REST_Request $req ) {
	$y    = (int) $req['year'];
	$id   = (string) $req->get_param( 'id' );
	$done = (bool) $req->get_param( 'done' );
	if ( ! ogc_coa_id_ok( $id ) ) {
		return ogc_coa_bad( 'Not a step.' );
	}
	$v = ogc_coa_update( $y, function ( &$s ) use ( $y, $id, $done ) {
		if ( $done ) {
			$s['steps'][ $id ] = ogc_coa_stamp( $y );
		} else {
			unset( $s['steps'][ $id ] );
		}
	} );
	if ( is_wp_error( $v ) ) {
		return $v;
	}
	ogc_log( 'coa', $y, 'step', array( 'what' => 'step', 'id' => $id, 'done' => $done, 'part' => strtok( $id, ':' ) ) );
	return rest_ensure_response( $v );
}

function ogc_coa_rest_check( WP_REST_Request $req ) {
	$y    = (int) $req['year'];
	$ids  = $req->get_param( 'ids' );
	$ids  = is_array( $ids ) ? $ids : array( (string) $req->get_param( 'id' ) );
	$done = (bool) $req->get_param( 'done' );
	foreach ( $ids as $id ) {
		if ( ! ogc_coa_id_ok( (string) $id ) ) {
			return ogc_coa_bad( 'Not a check.' );
		}
	}
	$v = ogc_coa_update( $y, function ( &$s ) use ( $y, $ids, $done ) {
		foreach ( $ids as $id ) {
			if ( $done ) {
				$s['checks'][ $id ] = ogc_coa_stamp( $y );
			} else {
				unset( $s['checks'][ $id ] );
			}
		}
	} );
	if ( is_wp_error( $v ) ) {
		return $v;
	}
	$part = (string) $req->get_param( 'part' );
	ogc_log( 'coa', $y, 'check', array( 'what' => 'check', 'id' => count( $ids ) === 1 ? $ids[0] : '', 'n' => count( $ids ), 'done' => $done, 'part' => in_array( $part, ogc_coa_parts(), true ) ? $part : '' ) );
	return rest_ensure_response( $v );
}

function ogc_coa_rest_note( WP_REST_Request $req ) {
	$y    = (int) $req['year'];
	$h    = (string) $req->get_param( 'hash' );
	$done = (bool) $req->get_param( 'done' );
	if ( ! preg_match( '/^[a-z0-9]{1,16}$/', $h ) ) {
		return ogc_coa_bad( 'Not a note.' );
	}
	$v = ogc_coa_update( $y, function ( &$s ) use ( $y, $h, $done ) {
		if ( $done ) {
			$s['notes_done'][ $h ] = ogc_coa_stamp( $y );
		} else {
			unset( $s['notes_done'][ $h ] );
		}
	} );
	if ( is_wp_error( $v ) ) {
		return $v;
	}
	$part = (string) $req->get_param( 'part' );
	ogc_log( 'coa', $y, 'note', array( 'what' => 'note', 'done' => $done, 'part' => in_array( $part, ogc_coa_parts(), true ) ? $part : '' ) );
	return rest_ensure_response( $v );
}

function ogc_coa_rest_owner( WP_REST_Request $req ) {
	$y     = (int) $req['year'];
	$part  = (string) $req->get_param( 'part' );
	$owner = trim( sanitize_text_field( (string) $req->get_param( 'owner' ) ) );
	if ( ! in_array( $part, ogc_coa_parts(), true ) || mb_strlen( $owner ) > 60 ) {
		return ogc_coa_bad( 'Not a part.' );
	}
	ogc_coa_set( $y, 'settings', 'owner_' . $part, $owner );
	ogc_log( 'coa', $y, 'owner', array( 'what' => 'owner', 'part' => $part, 'owner' => $owner ) );
	return rest_ensure_response( array( 'part' => $part, 'owner' => $owner ) );
}

function ogc_coa_rest_due( WP_REST_Request $req ) {
	$y    = (int) $req['year'];
	$part = (string) $req->get_param( 'part' );
	$date = (string) $req->get_param( 'date' );
	if ( ! in_array( $part, ogc_coa_parts(), true ) || ( '' !== $date && ! ogc_coa_iso( $date ) ) ) {
		return ogc_coa_bad( 'Not a date' );
	}
	$v = ogc_coa_update( $y, function ( &$s ) use ( $part, $date ) {
		if ( '' === $date ) {
			unset( $s['due'][ $part ] );
		} else {
			$s['due'][ $part ] = $date;
		}
	} );
	if ( is_wp_error( $v ) ) {
		return $v;
	}
	ogc_log( 'coa', $y, 'due', array( 'what' => 'due', 'part' => $part, 'date' => $date ) );
	return rest_ensure_response( $v );
}

function ogc_coa_rest_intro( WP_REST_Request $req ) {
	update_user_meta( get_current_user_id(), 'ogc_coa_intro_seen', ogc_now() );
	return rest_ensure_response( array( 'intro' => true ) );
}

/* ------------------------------------------------------------------ registration facts */

/** Prices are whole or cent amounts; counts are whole numbers; dates in order; the days names are
 * kept cleared on the webmasters' say. Returns WP_Error (status 400, with the words to show at the
 * field) or true. */
function ogc_coa_reg_check( $year, $key, $value ) {
	$money  = array( 'room_price', 'linen_price', 'mattress_price', 'camper_price', 'key_fee', 'bed_fee', 'yf_price' );
	$counts = array( 'room_beds', 'linen_stock', 'mattress_stock', 'rooms_held' );
	$dates  = array( 'opens', 'closes', 'refunds_by', 'cancel_by' );
	if ( ! preg_match( '/^[a-z][a-z0-9_]{0,40}$/', $key ) || mb_strlen( $value ) > 400 ) {
		return ogc_coa_bad( 'Not a fact.' );
	}
	if ( 'clear_after_days' === $key && ! ogc_is_webmaster() ) {
		return ogc_coa_bad( 'Set by the webmasters', 403 );
	}
	if ( in_array( $key, $money, true ) && '' !== $value && ! preg_match( '/^\d{1,4}(\.\d{2})?$/', $value ) ) {
		return ogc_coa_bad( 'Whole dollars, like 65' );
	}
	if ( in_array( $key, $money, true ) && '' !== $value && (float) $value <= 0 ) {
		return ogc_coa_bad( 'More than $0' );
	}
	if ( in_array( $key, $counts, true ) && '' !== $value && ! preg_match( '/^\d{1,5}$/', $value ) ) {
		return ogc_coa_bad( 'A number, like 120' );
	}
	if ( in_array( $key, $dates, true ) && '' !== $value ) {
		if ( ! ogc_coa_iso( $value ) && OGC_NOT_YET !== $value ) {
			return ogc_coa_bad( 'Not a date: try "May 21"' );
		}
		if ( OGC_NOT_YET === $value ) {
			return true;
		}
		$r   = ogc_coa_kv( $year, 'registration' );
		$row = ogc_year_get( $year );
		$r[ $key ] = $value;
		$first = $row && ! empty( $row['start'] ) ? $row['start'] : '';
		$last  = $row && ! empty( $row['end'] ) ? $row['end'] : '';
		$o = isset( $r['opens'] ) && ogc_coa_iso( $r['opens'] ) ? $r['opens'] : '';
		$c = isset( $r['closes'] ) && ogc_coa_iso( $r['closes'] ) ? $r['closes'] : '';
		if ( 'opens' === $key && $c && $value >= $c ) {
			return ogc_coa_bad( 'Before Closes' );
		}
		if ( 'closes' === $key && $o && $value <= $o ) {
			return ogc_coa_bad( 'After Opens' );
		}
		if ( 'closes' === $key && $first && $value > $first ) {
			return ogc_coa_bad( 'By the first day' );
		}
		if ( 'refunds_by' === $key && $last && $value < $last ) {
			return ogc_coa_bad( 'After the Conference' );
		}
	}
	return true;
}

function ogc_coa_rest_reg( WP_REST_Request $req ) {
	$y   = (int) $req['year'];
	$key = (string) $req->get_param( 'key' );
	$val = trim( sanitize_text_field( (string) $req->get_param( 'value' ) ) );
	$ok  = ogc_coa_reg_check( $y, $key, $val );
	if ( is_wp_error( $ok ) ) {
		return $ok;
	}
	$GLOBALS['ogc_coa_before'][ $y . '/registration' ] = ( $f = ogc_file_get( $y, 'registration' ) ) ? $f['rows'] : array();
	$v = ogc_coa_set( $y, 'registration', $key, $val );
	if ( is_wp_error( $v ) ) {
		return $v;
	}
	// The form opens and closes on registration's dates.
	if ( in_array( $key, array( 'closes' ), true ) ) {
		ogc_coa_set( $y, 'settings', 'registration_closes', $val );
	}
	do_action( 'ogc_file_saved', $y, 'registration', $v );
	return rest_ensure_response( array( 'key' => $key, 'value' => $val, 'version' => $v ) );
}

/* ------------------------------------------------------------------ publishing */

/**
 * One public act, stamped here (the campus's today, the person), logged, and undoable:
 *   conference   announce | unannounce
 *   schedule     publish | unpublish
 *   packet       publish | unpublish
 *   helping      publish | close | reopen | unpublish
 *   registration schedule {opens, closes} | close | reopen | unschedule
 *   youngfolks   schedule | close | reopen | unschedule
 */
function ogc_coa_rest_publish( WP_REST_Request $req ) {
	$y      = (int) $req['year'];
	$part   = (string) $req->get_param( 'part' );
	$act    = (string) $req->get_param( 'act' );
	$reason = mb_substr( sanitize_text_field( (string) $req->get_param( 'reason' ) ), 0, 140 );
	$today  = ogc_coa_today( $y );
	$row    = ogc_year_get( $y );
	if ( ! $row ) {
		return ogc_coa_bad( 'No such year', 404 );
	}
	$S     = ogc_coa_kv( $y, 'settings' );
	$extra = array();
	$set   = function ( $k, $v ) use ( $y ) {
		ogc_coa_set( $y, 'settings', $k, $v );
	};
	switch ( $part . ':' . $act ) {
		case 'conference:announce':
			if ( empty( $row['start'] ) || empty( $row['venue'] ) ) {
				return ogc_coa_bad( 'Set the dates and the campus first' );
			}
			// While an earlier Conference is still ahead, this one shows after it ends.
			$on = $today;
			foreach ( ogc_years_all() as $r ) {
				if ( (int) $r['year'] < $y && ! empty( $r['end'] ) && $r['end'] >= $today ) {
					$on = ogc_coa_add_days( $r['end'], 1 );
					break;
				}
			}
			ogc_year_set( $y, array( 'coa_announced' => $on ) );
			$extra['shows'] = $on;
			break;
		case 'conference:unannounce':
			ogc_year_set( $y, array( 'coa_announced' => '' ) );
			break;
		case 'schedule:publish':
			$set( 'schedule_posted', $today );
			$set( 'revised', $today );
			break;
		case 'schedule:unpublish':
			$set( 'schedule_posted', OGC_NOT_YET );
			break;
		// Already public: the changes made since go live (the app's "3 not live · Publish").
		case 'schedule:update':
			if ( ! ogc_coa_posted( $y, 'schedule_posted' ) ) {
				return ogc_coa_bad( 'Not public yet' );
			}
			$set( 'revised', $today );
			break;
		case 'packet:update':
			if ( ! ogc_coa_posted( $y, 'packet_posted' ) ) {
				return ogc_coa_bad( 'Not public yet' );
			}
			break;
		case 'packet:publish':
			$set( 'packet_posted', $today );
			break;
		case 'packet:unpublish':
			$set( 'packet_posted', OGC_NOT_YET );
			break;
		case 'helping:publish':
			$set( 'signups_posted', $today );
			$set( 'signups_closed', '' );
			break;
		case 'helping:unpublish':
			$set( 'signups_posted', OGC_NOT_YET );
			break;
		case 'helping:close':
			$set( 'signups_closed', $today );
			break;
		case 'helping:reopen':
			$set( 'signups_closed', '' );
			break;
		case 'registration:schedule':
			$o = (string) $req->get_param( 'opens' );
			$c = (string) $req->get_param( 'closes' );
			if ( ! ogc_coa_iso( $o ) ) {
				return ogc_coa_bad( 'Not a date: try "Feb 25"', 400, array( 'field' => 'opens' ) );
			}
			if ( ogc_coa_iso( $c ) && $c <= $o ) {
				return ogc_coa_bad( 'After Opens', 400, array( 'field' => 'closes' ) );
			}
			if ( ogc_coa_iso( $c ) && ! empty( $row['start'] ) && $c > $row['start'] ) {
				return ogc_coa_bad( 'By the first day', 400, array( 'field' => 'closes' ) );
			}
			ogc_coa_set( $y, 'registration', 'opens', $o );
			$set( 'registration_opens', $o );
			if ( ogc_coa_iso( $c ) ) {
				ogc_coa_set( $y, 'registration', 'closes', $c );
				$set( 'registration_closes', $c );
			}
			$set( 'registration_closed', '' );
			$extra['opens']  = $o;
			$extra['closes'] = $c;
			break;
		case 'registration:unschedule':
			ogc_coa_set( $y, 'registration', 'opens', OGC_NOT_YET );
			$set( 'registration_opens', OGC_NOT_YET );
			break;
		case 'registration:close':
			$set( 'registration_closed', $today );
			break;
		case 'registration:reopen':
			$set( 'registration_closed', '' );
			break;
		case 'youngfolks:schedule':
			$set( 'tournaments_held', '' );
			$set( 'tournaments_closed', '' );
			break;
		case 'youngfolks:unschedule':
			$set( 'tournaments_held', 'yes' );
			break;
		case 'youngfolks:close':
			$set( 'tournaments_closed', $today );
			break;
		case 'youngfolks:reopen':
			$set( 'tournaments_closed', '' );
			break;
		default:
			return ogc_coa_bad( 'Not an action.' );
	}
	$stamp = ogc_coa_stamp( $y, array_merge( array( 'act' => $act ), $reason ? array( 'reason' => $reason ) : array(), $extra ) );
	$v     = ogc_coa_update( $y, function ( &$s ) use ( $part, $stamp ) {
		$s['pub'][ $part ] = $stamp;
	} );
	ogc_log( 'coa', $y, 'publish', array( 'what' => 'publish', 'part' => $part, 'act' => $act, 'reason' => $reason ) );
	// What the public reads from now on (module-coa-app.php keeps the published copy).
	do_action( 'ogc_coa_published', $y, $part, $act );
	return rest_ensure_response( array( 'coa' => $v, 'year' => ogc_year_get( $y ), 'settings' => ogc_coa_kv( $y, 'settings' ), 'registration' => ogc_coa_kv( $y, 'registration' ), 'stamp' => $stamp ) );
}

/* ------------------------------------------------------------------ requests to the campus */

/**
 * Requests answered and changed, on the server's copy of the file, stamped with who and when:
 *   ops: [{ id, answer?: keep|change|remove|notsure|new|'' , question?: text, fields?: {qty, for, …} }]
 *   add: [{ committee, item, … }]   new requests (given an id here)
 * Two committee heads answering at the same time never undo each other.
 */
function ogc_coa_rest_needs( WP_REST_Request $req ) {
	$y   = (int) $req['year'];
	$ops = $req->get_param( 'ops' );
	$add = $req->get_param( 'add' );
	$ops = is_array( $ops ) ? $ops : array();
	$add = is_array( $add ) ? $add : array();
	if ( count( $ops ) + count( $add ) > 2000 ) {
		return ogc_coa_bad( 'Too many rows', 413 );
	}
	$fields = array( 'committee', 'for', 'item', 'qty', 'detail', 'supplied_by', 'first_day', 'last_day', 'start', 'end', 'building', 'room', 'notes' );
	$answers = array( 'keep', 'change', 'remove', 'notsure', 'new', '' );
	$clean  = function ( $f ) use ( $fields ) {
		$o = array();
		foreach ( $fields as $k ) {
			if ( isset( $f[ $k ] ) && is_scalar( $f[ $k ] ) ) {
				$o[ $k ] = mb_substr( sanitize_text_field( (string) $f[ $k ] ), 0, 200 );
			}
		}
		if ( isset( $o['qty'] ) ) {
			$o['qty'] = preg_replace( '/[^\d]/', '', $o['qty'] );
		}
		return $o;
	};
	$me     = ogc_coa_first_l( get_current_user_id() );
	$as     = ogc_coa_member_committee( $y, ogc_current_email() );
	$today  = ogc_coa_today( $y );
	$tally  = array();
	for ( $try = 0; $try < 8; $try++ ) {
		$cur   = ogc_file_get( $y, 'needs' );
		$rows  = $cur ? $cur['rows'] : array();
		$at    = array();
		$max   = 0;
		foreach ( $rows as $i => $r ) {
			if ( isset( $r['id'] ) ) {
				$at[ (string) $r['id'] ] = $i;
				if ( preg_match( '/^N(\d+)$/', (string) $r['id'], $mm ) ) {
					$max = max( $max, (int) $mm[1] );
				}
			}
		}
		$tally = array();
		$ids   = array();
		foreach ( $ops as $op ) {
			if ( ! is_array( $op ) || empty( $op['id'] ) || ! isset( $at[ (string) $op['id'] ] ) ) {
				continue;
			}
			$i = $at[ (string) $op['id'] ];
			if ( ! empty( $op['fields'] ) && is_array( $op['fields'] ) ) {
				$rows[ $i ] = array_merge( $rows[ $i ], $clean( $op['fields'] ) );
			}
			if ( array_key_exists( 'answer', $op ) && in_array( (string) $op['answer'], $answers, true ) ) {
				$a = (string) $op['answer'];
				$rows[ $i ]['answer']      = $a;
				$rows[ $i ]['answered_by'] = '' === $a ? '' : $me;
				$rows[ $i ]['answered_as'] = '' === $a ? '' : $as;
				$rows[ $i ]['answered_at'] = '' === $a ? '' : $today;
				if ( 'notsure' !== $a ) {
					$rows[ $i ]['question'] = '';
				}
				$c = isset( $rows[ $i ]['committee'] ) ? $rows[ $i ]['committee'] : '';
				if ( '' !== $a ) {
					$tally[ $c ][ $a ] = ( isset( $tally[ $c ][ $a ] ) ? $tally[ $c ][ $a ] : 0 ) + 1;
				}
			}
			if ( isset( $op['question'] ) && is_scalar( $op['question'] ) ) {
				$rows[ $i ]['question'] = mb_substr( sanitize_text_field( (string) $op['question'] ), 0, 200 );
			}
		}
		foreach ( $add as $n ) {
			if ( ! is_array( $n ) ) {
				continue;
			}
			$r = $clean( $n );
			if ( empty( $r['committee'] ) || empty( $r['item'] ) ) {
				continue;
			}
			$max++;
			$r = array_merge( array_fill_keys( $fields, '' ), $r, array( 'id' => 'N' . str_pad( (string) $max, 3, '0', STR_PAD_LEFT ), 'answer' => 'new', 'answered_by' => $me, 'answered_as' => $as, 'answered_at' => $today ) );
			$ids[]  = $r['id'];
			$rows[] = $r;
			$tally[ $r['committee'] ]['new'] = ( isset( $tally[ $r['committee'] ]['new'] ) ? $tally[ $r['committee'] ]['new'] : 0 ) + 1;
		}
		$v = ogc_file_put( $y, 'needs', $rows, $cur ? $cur['version'] : 0 );
		if ( ! is_wp_error( $v ) ) {
			ogc_log( 'coa', $y, 'needs', array( 'what' => 'needs', 'part' => 'requests', 'tally' => $tally ) );
			return rest_ensure_response( array( 'version' => $v, 'rows' => $rows, 'added' => $ids ) );
		}
	}
	return ogc_coa_bad( 'Busy · Retry', 503 );
}

/** "Mark sent": the requests as the campus now has them (ids and a fingerprint of each), so the page
 * can say what changed since. */
function ogc_coa_rest_sent( WP_REST_Request $req ) {
	$y    = (int) $req['year'];
	$what = (string) $req->get_param( 'what' );
	if ( 'needs' !== $what ) {
		return ogc_coa_bad( 'Not a list.' );
	}
	// Marked sent by mistake: taken back.
	if ( false === rest_sanitize_boolean( $req->get_param( 'done' ) ?? true ) ) {
		$v = ogc_coa_update( $y, function ( &$s ) {
			unset( $s['sent']['needs'] );
		} );
		ogc_log( 'coa', $y, 'sent', array( 'what' => 'sent', 'part' => 'requests', 'undone' => true ) );
		return is_wp_error( $v ) ? $v : rest_ensure_response( $v );
	}
	$f    = ogc_file_get( $y, 'needs' );
	$fp   = array();
	foreach ( $f ? $f['rows'] : array() as $r ) {
		if ( ! empty( $r['id'] ) && ( ! isset( $r['answer'] ) || 'remove' !== $r['answer'] ) ) {
			$fp[ $r['id'] ] = ogc_coa_need_fp( $r );
		}
	}
	$stamp = ogc_coa_stamp( $y, array( 'rows' => $fp, 'n' => count( $fp ) ) );
	$v     = ogc_coa_update( $y, function ( &$s ) use ( $stamp ) {
		$s['sent']['needs'] = $stamp;
	} );
	ogc_log( 'coa', $y, 'sent', array( 'what' => 'sent', 'part' => 'requests', 'n' => count( $fp ) ) );
	return is_wp_error( $v ) ? $v : rest_ensure_response( $v );
}

/** A request's fingerprint: what the campus would set up from it. The page makes the same one. */
function ogc_coa_need_fp( $r ) {
	$k = array( 'item', 'qty', 'for', 'first_day', 'last_day', 'start', 'end', 'building', 'room', 'notes' );
	$s = array();
	foreach ( $k as $x ) {
		$s[] = isset( $r[ $x ] ) ? trim( (string) $r[ $x ] ) : '';
	}
	return ogc_coa_hash( implode( '|', $s ) );
}

/* ================================================================== the committee a member is on */

/** What a member helps with (the signin area's members list, "Lodging · Desk"), or ''. */
function ogc_coa_member_committee( $year, $email ) {
	if ( ! function_exists( 'ogc_member_find' ) ) {
		return '';
	}
	$m = ogc_member_find( (int) $year, strtolower( (string) $email ) );
	return $m && ! empty( $m['helps'] ) ? trim( preg_split( '/\s*[·,;|]\s*/', $m['helps'] )[0] ) : '';
}
