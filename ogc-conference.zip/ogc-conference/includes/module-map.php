<?php
/**
 * The map area (Oct 10): the campus kept per campus, not per year.
 *
 * A pin dropped at a door on the 2027 walk-through, a door named, a hall's plan checked: each is done
 * once and is there for every later Conference at that campus (docs/14 "kept per campus"). A year
 * points to its campus by its venue (years.csv) and the pages go on reading campus.csv, places.csv and
 * plans.csv as before: this module answers for them (the ogc_file_out filter) from the campus record.
 *
 * The campus record is one table, a row a part:
 *   buildings  campus.csv's outlines (code, name, kind, short, points; aliases, address), from OpenStreetMap
 *   doors      id, building, label, x, y, step_free, open, key_only, checked
 *   places     code, name, building, x, y, floor, inside, door, outdoor, checked (the schedule's rooms, pinned)
 *   spots      id, kind (camper · parking · carts · desk · accessible · other), name, x, y, note
 *   halls      hall, status (sample · university · checked), checked_on, checked_by, uploaded_on, uploaded_by,
 *              elevator, step_free, ac, note. "university" is set only by uploading the university's plan
 *              (POST campus-plan); "checked" only on a plan that isn't a sample, with who and when (polish 2).
 *   plans      plans.csv (hall, floor, kind, label, x, y, w, h, note): each hall's floors in feet
 *   closures   id, x, y, from, to, note (a closed path or door, for some days)
 *
 * What the public gets: the buildings, named doors, pins, spots and closures (no one's data), and a hall's
 * floor plan only once Lodging marks it from the university or checked. Sample plans go to members only.
 *
 * Routes (each with its own permission check; changes need the wp_rest nonce and are logged):
 *   GET   /years/{y}/campus           members of y: every part, with versions (the pins tool)
 *   PUT   /years/{y}/campus/{part}    webmasters; members of y when y is the next Conference at that campus
 *                                     (buildings: webmasters only): replace a part (409 when stale)
 *   PATCH /years/{y}/campus/{part}    the same: one row by its key (_gone removes it)
 *   POST  /years/{y}/campus-import    webmasters: a new OpenStreetMap drawing, previewed, then applied; undo
 *   POST  /years/{y}/campus-plan      as PUT: a hall's plan from the university (plans.csv rows), previewed,
 *                                     then applied; the hall becomes "From the university"
 *   GET   /years/{y}/me/stay          signed in: where this person sleeps (their own registration only)
 *   GET   /years/{y}/rooms/taken      signed in, when households choose: taken room ids, no one's names
 */

defined( 'ABSPATH' ) || exit;

/** The parts of a campus record, and the column each part's rows are known by. */
function ogc_map_parts() {
	return array( 'buildings' => '', 'doors' => 'id', 'places' => 'code', 'spots' => 'id', 'halls' => 'hall', 'plans' => '', 'closures' => 'id' );
}

/* ------------------------------------------------------------------ the table */

add_filter( 'ogc_schema', function ( $sql, $charset ) {
	$sql[] = 'CREATE TABLE ' . ogc_table( 'campus' ) . " (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  campus varchar(64) NOT NULL,
  name varchar(32) NOT NULL,
  rows_json longtext NOT NULL,
  cols longtext NULL,
  version int(10) unsigned NOT NULL DEFAULT 1,
  updated_by bigint(20) unsigned NOT NULL DEFAULT 0,
  updated_at datetime NULL,
  PRIMARY KEY  (id),
  UNIQUE KEY campus_name (campus,name)
) $charset;";
	return $sql;
}, 10, 2 );

/** A campus's key, from its venue's name ("Indiana Wesleyan University" → indiana-wesleyan-university). */
function ogc_map_slug( $venue ) {
	// Typed a little differently, the same campus ("The Indiana Wesleyan Univ." is Indiana Wesleyan University).
	$v = preg_replace( array( '/^\s*the\s+/i', '/\buniv\b\.?/i', '/\s*&\s*/' ), array( '', 'University', ' and ' ), (string) $venue );
	return substr( sanitize_title( $v ), 0, 64 );
}

/** The campus a year is at: its venue in years.csv, else in its settings. '' when not chosen yet. */
function ogc_map_campus_of( $year ) {
	static $memo = array();
	$year = (int) $year;
	if ( isset( $memo[ $year ] ) ) {
		return $memo[ $year ];
	}
	$row   = ogc_year_get( $year );
	$venue = $row && ! empty( $row['venue'] ) ? $row['venue'] : '';
	if ( '' === $venue ) {
		$s = ogc_file_get( $year, 'settings' );
		foreach ( $s ? $s['rows'] : array() as $r ) {
			if ( isset( $r['key'] ) && 'venue' === $r['key'] ) {
				$venue = (string) $r['value'];
			}
		}
	}
	return $memo[ $year ] = ogc_map_slug( $venue );
}

function ogc_map_get( $campus, $name ) {
	global $wpdb;
	$r = $wpdb->get_row( $wpdb->prepare( 'SELECT rows_json, cols, version, updated_at FROM ' . ogc_table( 'campus' ) . ' WHERE campus = %s AND name = %s', $campus, $name ), ARRAY_A );
	if ( ! $r ) {
		return null;
	}
	return array( 'rows' => (array) ogc_unjson( $r['rows_json'], array() ), 'cols' => (array) ogc_unjson( $r['cols'], array() ), 'version' => (int) $r['version'], 'updated_at' => $r['updated_at'] );
}

/** Replace a part. $expect: the version last read (0 for new); a newer one isn't overwritten (409). */
function ogc_map_put( $campus, $name, $rows, $expect, $cols = null ) {
	global $wpdb;
	$rows = array_values( (array) $rows );
	$cur  = ogc_map_get( $campus, $name );
	$cols = ogc_rows_cols( $rows, null === $cols ? ( $cur ? $cur['cols'] : array() ) : $cols );
	$conf = function () use ( $campus, $name ) {
		$now = ogc_map_get( $campus, $name );
		return new WP_Error( 'ogc_conflict', 'Changed since it was opened.', array( 'status' => 409, 'version' => $now ? $now['version'] : 0 ) );
	};
	if ( null === $cur ) {
		if ( (int) $expect !== 0 ) {
			return $conf();
		}
		$ok = $wpdb->insert( ogc_table( 'campus' ), array( 'campus' => $campus, 'name' => $name, 'rows_json' => ogc_json( $rows ), 'cols' => ogc_json( $cols ), 'version' => 1, 'updated_by' => get_current_user_id(), 'updated_at' => ogc_now() ), array( '%s', '%s', '%s', '%s', '%d', '%d', '%s' ) );
		return $ok ? 1 : $conf();
	}
	$n = $wpdb->query( $wpdb->prepare(
		'UPDATE ' . ogc_table( 'campus' ) . ' SET rows_json = %s, cols = %s, updated_by = %d, updated_at = %s, version = version + 1 WHERE campus = %s AND name = %s AND version = %d',
		ogc_json( $rows ), ogc_json( $cols ), get_current_user_id(), ogc_now(), $campus, $name, (int) $expect
	) );
	return 1 === (int) $n ? (int) $expect + 1 : $conf();
}

/* ------------------------------------------------------------------ starting a campus record */

/**
 * The first time a campus is asked for, its record is made from the newest year there with a map:
 * its buildings and doors (campus.csv), its places (places.csv: the pins, and which are outdoors),
 * its halls (every one a sample until Lodging says otherwise) and their plans (plans.csv).
 */
function ogc_map_ensure( $campus ) {
	if ( '' === $campus || ogc_map_get( $campus, 'buildings' ) ) {
		return;
	}
	// The fullest drawing of the years there (a year picked up by an older page may have lost the
	// unnamed footpaths, and with them the routes), newest first among equals.
	$best = null;
	foreach ( ogc_years_all() as $y ) {
		if ( ogc_map_slug( isset( $y['venue'] ) ? $y['venue'] : '' ) !== $campus ) {
			continue;
		}
		$c = ogc_file_get( (int) $y['year'], 'campus' );
		if ( $c && $c['rows'] && ( ! $best || count( $c['rows'] ) > count( $best[1]['rows'] ) ) ) {
			$best = array( (int) $y['year'], $c );
		}
	}
	if ( $best ) {
		ogc_map_seed_from_year( $campus, $best[0], $best[1] );
	}
}

function ogc_map_seed_from_year( $campus, $year, $c ) {
	$buildings = array();
	$doors     = array();
	foreach ( $c['rows'] as $r ) {
		if ( isset( $r['kind'] ) && 'door' === $r['kind'] ) {
			$p = preg_split( '/[\s,]+/', trim( (string) $r['points'] ) );
			if ( count( $p ) >= 2 ) {
				// Entrances drawn in OpenStreetMap: real doors, not yet named or checked on the walk-through.
				$doors[] = array( 'id' => 'd' . ( count( $doors ) + 1 ), 'building' => (string) $r['name'], 'label' => (string) ( isset( $r['short'] ) ? $r['short'] : '' ), 'x' => (string) (float) $p[0], 'y' => (string) (float) $p[1], 'step_free' => '', 'open' => '', 'key_only' => '', 'checked' => '' );
			}
			continue;
		}
		$buildings[] = $r;
	}
	$places = array();
	$pf     = ogc_file_get( $year, 'places' );
	foreach ( $pf ? $pf['rows'] : array() as $r ) {
		if ( empty( $r['code'] ) || 0 === strpos( (string) $r['code'], '#' ) ) {
			continue;
		}
		$name     = (string) ( isset( $r['name'] ) ? $r['name'] : '' );
		$places[] = array(
			'code'     => (string) $r['code'],
			'name'     => $name,
			'building' => (string) ( isset( $r['building'] ) ? $r['building'] : '' ),
			'x'        => isset( $r['x'] ) ? (string) $r['x'] : '',
			'y'        => isset( $r['y'] ) ? (string) $r['y'] : '',
			'floor'    => '',
			'inside'   => '',
			'door'     => '',
			// Fields, greens and lots are outdoors: they're pinned, never sent to a building's door.
			'outdoor'  => preg_match( '/\b(field|green|lawn|lot|pavilion|outside|courts?)\b/i', $name ) ? 'yes' : '',
			'checked'  => '',
			'mapped'   => '',
		);
	}
	$halls = array();
	$plans = ogc_file_get( $year, 'plans' );
	$rooms = ogc_file_get( $year, 'rooms' );
	foreach ( array_merge( $plans ? $plans['rows'] : array(), $rooms ? $rooms['rows'] : array() ) as $r ) {
		$h = isset( $r['hall'] ) ? trim( (string) $r['hall'] ) : '';
		if ( '' !== $h && 0 !== strpos( $h, '#' ) && ! isset( $halls[ $h ] ) ) {
			$halls[ $h ] = array( 'hall' => $h, 'status' => 'sample', 'checked_on' => '', 'elevator' => '', 'step_free' => '', 'ac' => '', 'note' => '' );
		}
	}
	ogc_map_put( $campus, 'buildings', $buildings, 0, $c['cols'] );
	ogc_map_put( $campus, 'doors', $doors, 0, array( 'id', 'building', 'label', 'x', 'y', 'step_free', 'open', 'key_only', 'checked' ) );
	ogc_map_put( $campus, 'places', $places, 0, array( 'code', 'name', 'building', 'x', 'y', 'floor', 'inside', 'door', 'outdoor', 'checked', 'mapped' ) );
	ogc_map_put( $campus, 'spots', array(), 0, array( 'id', 'kind', 'name', 'x', 'y', 'note' ) );
	ogc_map_put( $campus, 'halls', array_values( $halls ), 0, array( 'hall', 'status', 'checked_on', 'elevator', 'step_free', 'ac', 'note' ) );
	ogc_map_put( $campus, 'plans', $plans ? $plans['rows'] : array(), 0, $plans ? $plans['cols'] : array( 'hall', 'floor', 'kind', 'label', 'x', 'y', 'w', 'h', 'note' ) );
	ogc_map_put( $campus, 'closures', array(), 0, array( 'id', 'x', 'y', 'from', 'to', 'note' ) );
	ogc_log( 'campus_start', $year, $campus, array( 'buildings' => count( $buildings ), 'doors' => count( $doors ), 'places' => count( $places ) ) );
}

/** Every part of a year's campus: name → { rows, cols, version } (made on first use). */
function ogc_map_record( $year ) {
	$campus = ogc_map_campus_of( $year );
	if ( '' === $campus ) {
		return null;
	}
	ogc_map_ensure( $campus );
	$out = array();
	foreach ( array_keys( ogc_map_parts() ) as $p ) {
		$out[ $p ] = ogc_map_get( $campus, $p );
	}
	return $out['buildings'] ? $out : null;
}

/** Which halls' plans the public may see: those Lodging has from the university, or has checked. */
function ogc_map_hall_status( $rec ) {
	$s = array();
	foreach ( $rec && $rec['halls'] ? $rec['halls']['rows'] : array() as $h ) {
		$s[ (string) $h['hall'] ] = in_array( $h['status'], array( 'university', 'checked' ), true ) ? $h['status'] : 'sample';
	}
	return $s;
}

/* ------------------------------------------------------------------ what the pages read */

/**
 * campus.csv: the buildings, then each door (kind door: name = its building, short = its name), each
 * spot (kind spot) and each closure (kind closed), in campus.csv's own shape, so every page that draws
 * the campus has them. places.csv: the year's places, with the campus's pins. plans.csv: each row with
 * its hall's status; the public gets only halls that aren't samples.
 */
add_filter( 'ogc_file_out', 'ogc_map_file_out', 10, 3 );
function ogc_map_file_out( $f, $year, $name ) {
	if ( ! in_array( $name, array( 'campus', 'places', 'plans' ), true ) ) {
		return $f;
	}
	$rec = ogc_map_record( $year );
	if ( ! $rec ) {
		// No campus record (a year with no venue yet): the year's own file, but never a sample plan for the public.
		if ( 'plans' === $name && $f && ! ogc_is_member( $year ) ) {
			$f['rows'] = array();
		}
		return $f;
	}
	$base = $f ? $f : array( 'rows' => array(), 'cols' => array(), 'version' => 0, 'updated_at' => null );
	if ( 'campus' === $name ) {
		$rows  = $rec['buildings']['rows'];
		$halls = array();
		foreach ( $rows as $b ) {
			if ( isset( $b['kind'] ) && 'hall' === $b['kind'] ) {
				$halls[ strtolower( (string) $b['name'] ) ] = true;
			}
		}
		$member = ogc_is_member( $year );
		// The halls with rooms this year (rooms.csv), so every map frames them (polish 2: Reed and Evans cut
		// off the packet's map). stay=yes once Lodging has confirmed the hall with the university (rooms.csv
		// confirmed, the print area's rule: only then is it named as the Conference's); stay=sample before
		// that, for members only, since which halls the Conference uses is Lodging's until then.
		$stay = array();
		$rf   = ogc_file_get( $year, 'rooms' );
		foreach ( $rf ? (array) $rf['rows'] : array() as $r ) {
			$h = isset( $r['hall'] ) ? strtolower( trim( (string) $r['hall'] ) ) : '';
			if ( '' === $h || 0 === strpos( $h, '#' ) ) {
				continue;
			}
			$ok         = isset( $r['confirmed'] ) && in_array( strtolower( (string) $r['confirmed'] ), array( 'yes', '1', 'true' ), true );
			$stay[ $h ] = $ok || ( isset( $stay[ $h ] ) && 'yes' === $stay[ $h ] ) ? 'yes' : 'sample';
		}
		foreach ( $rows as $i => $b ) {
			$k = isset( $b['name'] ) ? strtolower( (string) $b['name'] ) : '';
			if ( isset( $b['kind'] ) && 'hall' === $b['kind'] && isset( $stay[ $k ] ) && ( 'yes' === $stay[ $k ] || $member ) ) {
				$rows[ $i ]['stay'] = $stay[ $k ];
			}
			// Polish 3: one rule everywhere. A hall is drawn and named as a hall for the public only once
			// Lodging has confirmed it (the packet's rule); before that it's a building like any other, so
			// the public map can't show which halls the Conference sleeps in. Members see every hall.
			if ( ! $member && isset( $b['kind'] ) && 'hall' === $b['kind'] && ! ( isset( $stay[ $k ] ) && 'yes' === $stay[ $k ] ) ) {
				$rows[ $i ]['kind'] = 'other';
			}
		}
		foreach ( $rec['doors'] ? $rec['doors']['rows'] : array() as $d ) {
			// A hall's key-only door is for the people sleeping there (GET /me/stay), not for every visitor.
			if ( ! $member && 'yes' === $d['key_only'] && isset( $halls[ strtolower( (string) $d['building'] ) ] ) ) {
				continue;
			}
			$rows[] = array( 'code' => '', 'name' => $d['building'], 'kind' => 'door', 'short' => $d['label'], 'points' => $d['x'] . ' ' . $d['y'], 'door' => $d['id'], 'step_free' => $d['step_free'], 'open' => $d['open'], 'key_only' => $d['key_only'], 'checked' => $d['checked'] );
		}
		foreach ( $rec['spots'] ? $rec['spots']['rows'] : array() as $s ) {
			if ( '' !== (string) $s['x'] ) {
				$rows[] = array( 'code' => '', 'name' => $s['name'], 'kind' => 'spot', 'short' => '', 'points' => $s['x'] . ' ' . $s['y'], 'door' => $s['id'], 'spot' => $s['kind'], 'note' => $s['note'] );
			}
		}
		foreach ( $rec['closures'] ? $rec['closures']['rows'] : array() as $s ) {
			$rows[] = array( 'code' => '', 'name' => $s['note'], 'kind' => 'closed', 'short' => '', 'points' => $s['x'] . ' ' . $s['y'], 'door' => $s['id'], 'from' => $s['from'], 'to' => $s['to'] );
		}
		return array_merge( $base, array( 'rows' => $rows, 'cols' => ogc_rows_cols( $rows, $rec['buildings']['cols'] ) ) );
	}
	if ( 'places' === $name ) {
		$pins = array();
		foreach ( $rec['places'] ? $rec['places']['rows'] : array() as $p ) {
			$pins[ 'c:' . strtoupper( $p['code'] ) ] = $p;
			$pins[ 'n:' . strtolower( $p['name'] ) ]  = $p;
		}
		$rows = array();
		foreach ( $base['rows'] as $r ) {
			$p = isset( $r['code'], $pins[ 'c:' . strtoupper( (string) $r['code'] ) ] ) ? $pins[ 'c:' . strtoupper( (string) $r['code'] ) ] : ( isset( $r['name'], $pins[ 'n:' . strtolower( (string) $r['name'] ) ] ) ? $pins[ 'n:' . strtolower( (string) $r['name'] ) ] : null );
			if ( $p ) {
				// The campus record is the only source of a pin: an empty value there wins too (a pin
				// cleared on the walk-through stays cleared).
				foreach ( array( 'x', 'y', 'floor', 'inside', 'door', 'outdoor', 'checked' ) as $k ) {
					$r[ $k ] = isset( $p[ $k ] ) ? (string) $p[ $k ] : '';
				}
				// A building chosen on the map for a code the map didn't know (a new campus).
				if ( ! empty( $p['mapped'] ) ) {
					$r['building'] = (string) $p['mapped'];
				}
			}
			$rows[] = $r;
		}
		return array_merge( $base, array( 'rows' => $rows, 'cols' => ogc_rows_cols( $rows, $base['cols'] ) ) );
	}
	// plans: where people sleep (polish 1; the Advisors: "extremely secure"; IWU's permission to publish
	// isn't settled, questions-map #14). Members get every hall; someone signed in who sleeps in a hall
	// that year (or may choose a room, where households choose) gets the halls that aren't samples; the
	// public gets none (the campus outline only). Never kept by a browser or the guide's offline copy.
	$status = ogc_map_hall_status( $rec );
	$member = ogc_is_member( $year );
	$may    = $member ? '*' : ogc_map_plan_halls( $year );
	$rows   = array();
	foreach ( $may && $rec['plans'] ? $rec['plans']['rows'] : array() as $r ) {
		$h = isset( $r['hall'] ) ? (string) $r['hall'] : '';
		$s = isset( $status[ $h ] ) ? $status[ $h ] : 'sample';
		if ( '*' !== $may && ! in_array( strtolower( $h ), $may, true ) ) {
			continue;
		}
		if ( $member || 'sample' !== $s ) {
			$r['status'] = $s;
			$rows[]      = $r;
		}
	}
	if ( $rows ) {
		$GLOBALS['ogc_map_private'] = true;
	}
	return array_merge( $base, array( 'rows' => $rows, 'cols' => ogc_rows_cols( $rows, $rec['plans'] ? $rec['plans']['cols'] : array() ) ) );
}

/**
 * Which halls' plans a signed-in non-member may see (polish 2: "where people sleep" was the Advisors'
 * worry; before, anyone signed in got every hall while households chose, and a household got every hall
 * once it had a dorm stay). → '*' (every hall), a list of hall names (lower case), or null.
 *   - Households choose their rooms: someone whose own registration this year is a dorm stay gets every
 *     hall (they're choosing); anyone else, none.
 *   - Lodging gives rooms: a household gets the hall its published rooms are in; a Young Folk the Young
 *     Folks' halls. Nothing before Lodging publishes.
 */
function ogc_map_plan_halls( $year ) {
	$email = ogc_current_email();
	if ( ! $email ) {
		return null;
	}
	$cfg    = ogc_map_keys( $year, 'registration' );
	$choose = 'households' === ( isset( $cfg['room_choice'] ) ? $cfg['room_choice'] : '' );
	$posted = ! empty( $cfg['rooms_posted'] );
	$rooms  = null;
	$state  = null;
	$out    = array();
	foreach ( ogc_records( $year, 'registrations', $email ) as $rec ) {
		$d    = (array) $rec['data'];
		$type = isset( $d['stay']['type'] ) ? (string) $d['stay']['type'] : '';
		if ( 'dorm' === $type && $choose ) {
			return '*';
		}
		if ( 'dorm' === $type && $posted ) {
			$rooms  = null === $rooms ? ogc_map_rooms( $year ) : $rooms;
			$state  = null === $state ? ogc_state_get( $year, 'rooms' ) : $state;
			$assign = $state && is_array( $state['value'] ) ? $state['value'] : array();
			$id     = isset( $d['id'] ) ? (string) $d['id'] : '';
			foreach ( $id && isset( $assign[ $id ] ) ? (array) $assign[ $id ] : array() as $rid ) {
				if ( isset( $rooms[ (string) $rid ] ) ) {
					$out[] = strtolower( $rooms[ (string) $rid ]['hall'] );
				}
			}
		} elseif ( 'yf' === $type ) {
			$f = ogc_file_get( $year, 'rooms' );
			foreach ( $f ? $f['rows'] : array() as $r ) {
				if ( isset( $r['for'], $r['hall'] ) && preg_match( '/^young/i', (string) $r['for'] ) ) {
					$out[] = strtolower( (string) $r['hall'] );
				}
			}
		}
	}
	$out = array_values( array_unique( $out ) );
	return $out ? $out : null;
}
/** Kept for other areas that ask yes or no. */
function ogc_map_may_see_plans( $year ) {
	return null !== ogc_map_plan_halls( $year );
}

// An answer that carried floor plans to someone signed in is sent private, no-store (the file route,
// the year's bundle); the data CSV address already sends no-cache headers.
add_filter( 'rest_post_dispatch', function ( $res ) {
	if ( ! empty( $GLOBALS['ogc_map_private'] ) && $res instanceof WP_REST_Response ) {
		$res->header( 'Cache-Control', 'private, no-store, max-age=0' );
	}
	return $res;
}, 20 );

/** The fields of a place that belong to the campus, not the year (the pins tool writes them). */
function ogc_map_pin_keys() {
	return array( 'x', 'y', 'floor', 'inside', 'door', 'outdoor', 'checked', 'mapped' );
}

/**
 * A year's places.csv never keeps a pin. Pages read places with the campus's pins merged in, so a whole
 * row saved back by an editor carries them; kept in the year's file, they used to be copied back over
 * the campus record and undo a pin cleared on the walk-through (the critic, Oct 10). So the pin fields
 * are taken off every places row as it's saved. A code the campus record doesn't know yet (an older
 * page's pin for a new room) is carried into the record first, so nothing is lost; a code it knows is
 * never changed from here. With no campus record yet (the seed, a year with no venue) the rows are kept
 * as they are: the record is made from them when it's first read.
 */
add_filter( 'ogc_file_rows', function ( $rows, $year, $name ) {
	if ( 'places' !== $name ) {
		return $rows;
	}
	$campus = ogc_map_campus_of( $year );
	$cur    = '' !== $campus ? ogc_map_get( $campus, 'places' ) : null;
	if ( ! $cur || ! ogc_map_get( $campus, 'buildings' ) ) {
		return $rows;
	}
	$known = array();
	foreach ( $cur['rows'] as $p ) {
		$known[ strtoupper( (string) $p['code'] ) ] = true;
	}
	$add = array();
	foreach ( $rows as &$r ) {
		$code = is_array( $r ) && isset( $r['code'] ) ? strtoupper( (string) $r['code'] ) : '';
		if ( '' !== $code && 0 !== strpos( $code, '#' ) && ! isset( $known[ $code ] ) && isset( $r['x'], $r['y'] ) && is_numeric( $r['x'] ) && is_numeric( $r['y'] ) ) {
			$known[ $code ] = true;
			$add[]          = array( 'code' => $code, 'name' => (string) ( isset( $r['name'] ) ? $r['name'] : '' ), 'building' => (string) ( isset( $r['building'] ) ? $r['building'] : '' ), 'x' => (string) round( (float) $r['x'], 1 ), 'y' => (string) round( (float) $r['y'], 1 ), 'floor' => '', 'inside' => '', 'door' => '', 'outdoor' => isset( $r['outdoor'] ) && 'yes' === $r['outdoor'] ? 'yes' : '', 'checked' => '', 'mapped' => '' );
		}
		if ( is_array( $r ) ) {
			foreach ( ogc_map_pin_keys() as $k ) {
				unset( $r[ $k ] );
			}
		}
	}
	unset( $r );
	if ( $add ) {
		ogc_map_put( $campus, 'places', array_merge( $cur['rows'], $add ), $cur['version'] );
		ogc_log( 'campus_places_added', (int) $year, $campus . '/places', array( 'rows' => count( $add ) ) );
	}
	return $rows;
}, 20, 3 );

/** A year's campus saved by an older page, for a campus with no record yet: the record is made from it. */
add_action( 'ogc_file_saved', function ( $year, $name ) {
	if ( 'campus' !== $name ) {
		return;
	}
	$campus = ogc_map_campus_of( $year );
	if ( '' !== $campus && ! ogc_map_get( $campus, 'buildings' ) ) {
		ogc_map_ensure( $campus );
	}
}, 10, 2 );

/* ------------------------------------------------------------------ checking what's written */

/** The campus's extent in metres, and a margin: a pin or door outside it is refused. */
function ogc_map_bounds( $rec ) {
	$x0 = $y0 = INF;
	$x1 = $y1 = -INF;
	foreach ( $rec && $rec['buildings'] ? $rec['buildings']['rows'] : array() as $r ) {
		if ( isset( $r['kind'] ) && 'geo' === $r['kind'] ) {
			continue;
		}
		foreach ( explode( ';', (string) ( isset( $r['points'] ) ? $r['points'] : '' ) ) as $pt ) {
			$p = preg_split( '/[\s,]+/', trim( $pt ) );
			if ( count( $p ) >= 2 && is_numeric( $p[0] ) && is_numeric( $p[1] ) ) {
				$x0 = min( $x0, (float) $p[0] );
				$x1 = max( $x1, (float) $p[0] );
				$y0 = min( $y0, (float) $p[1] );
				$y1 = max( $y1, (float) $p[1] );
			}
		}
	}
	return is_finite( $x0 ) ? array( $x0 - 150, $y0 - 150, $x1 + 150, $y1 + 150 ) : null;
}

/** Clean one row of a part, or say what's wrong with it. */
function ogc_map_clean_row( $part, $r, $bounds ) {
	if ( ! is_array( $r ) ) {
		return new WP_Error( 'ogc_bad_row', 'A row is an object.', array( 'status' => 400 ) );
	}
	$t   = function ( $k, $max ) use ( $r ) {
		return isset( $r[ $k ] ) && is_scalar( $r[ $k ] ) ? mb_substr( sanitize_text_field( (string) $r[ $k ] ), 0, $max ) : '';
	};
	$yn  = function ( $k, $also = array() ) use ( $r ) {
		$v = isset( $r[ $k ] ) ? strtolower( (string) $r[ $k ] ) : '';
		return in_array( $v, array_merge( array( 'yes', 'no' ), $also ), true ) ? $v : '';
	};
	$day = function ( $k ) use ( $r ) {
		$v = isset( $r[ $k ] ) ? (string) $r[ $k ] : '';
		return preg_match( '/^\d{4}-\d{2}-\d{2}$/', $v ) ? $v : '';
	};
	$xy  = function () use ( $r, $bounds ) {
		$x = isset( $r['x'] ) ? (string) $r['x'] : '';
		$y = isset( $r['y'] ) ? (string) $r['y'] : '';
		if ( '' === $x && '' === $y ) {
			return array( '', '' );
		}
		if ( ! is_numeric( $x ) || ! is_numeric( $y ) ) {
			return new WP_Error( 'ogc_bad_point', 'A point is two numbers.', array( 'status' => 400 ) );
		}
		if ( $bounds && ( $x < $bounds[0] || $x > $bounds[2] || $y < $bounds[1] || $y > $bounds[3] ) ) {
			return new WP_Error( 'ogc_off_campus', 'Not on the campus.', array( 'status' => 400 ) );
		}
		return array( (string) round( (float) $x, 1 ), (string) round( (float) $y, 1 ) );
	};
	$id  = function () use ( $r ) {
		$v = isset( $r['id'] ) ? (string) $r['id'] : '';
		return preg_match( '/^[a-z0-9-]{1,24}$/', $v ) ? $v : '';
	};
	switch ( $part ) {
		case 'places':
			$code = isset( $r['code'] ) ? strtoupper( (string) $r['code'] ) : '';
			if ( ! preg_match( '#^[A-Z0-9][A-Z0-9/_.-]{0,23}$#', $code ) ) {
				return new WP_Error( 'ogc_bad_code', 'A place needs its code.', array( 'status' => 400 ) );
			}
			$p = $xy();
			if ( is_wp_error( $p ) ) {
				return $p;
			}
			$floor = $t( 'floor', 12 );
			return array( 'code' => $code, 'name' => $t( 'name', 120 ), 'building' => $t( 'building', 120 ), 'x' => $p[0], 'y' => $p[1], 'floor' => preg_match( '/^(Lower|Ground|[2-9](nd|rd|th)?)?$/', $floor ) ? $floor : '', 'inside' => $t( 'inside', 160 ), 'door' => $t( 'door', 24 ), 'outdoor' => 'yes' === $yn( 'outdoor' ) ? 'yes' : '', 'checked' => $day( 'checked' ), 'mapped' => $t( 'mapped', 120 ) );
		case 'doors':
			$p = $xy();
			if ( is_wp_error( $p ) ) {
				return $p;
			}
			if ( '' === $id() || '' === $p[0] ) {
				return new WP_Error( 'ogc_bad_door', 'A door needs its id and its place.', array( 'status' => 400 ) );
			}
			return array( 'id' => $id(), 'building' => $t( 'building', 120 ), 'label' => $t( 'label', 60 ), 'x' => $p[0], 'y' => $p[1], 'step_free' => $yn( 'step_free' ), 'open' => $t( 'open', 40 ), 'key_only' => 'yes' === $yn( 'key_only' ) ? 'yes' : '', 'checked' => $day( 'checked' ) );
		case 'spots':
			$p    = $xy();
			$kind = isset( $r['kind'] ) ? (string) $r['kind'] : '';
			if ( is_wp_error( $p ) ) {
				return $p;
			}
			if ( '' === $id() || ! in_array( $kind, array( 'camper', 'parking', 'carts', 'desk', 'accessible', 'other' ), true ) ) {
				return new WP_Error( 'ogc_bad_spot', 'A spot needs its id and kind.', array( 'status' => 400 ) );
			}
			return array( 'id' => $id(), 'kind' => $kind, 'name' => $t( 'name', 80 ), 'x' => $p[0], 'y' => $p[1], 'note' => $t( 'note', 160 ) );
		case 'halls':
			$s = isset( $r['status'] ) ? (string) $r['status'] : 'sample';
			if ( '' === $t( 'hall', 120 ) ) {
				return new WP_Error( 'ogc_bad_hall', 'A hall needs its name.', array( 'status' => 400 ) );
			}
			// Who checked and who uploaded are the server's to write (ogc_map_hall_rule); kept as read here.
			return array( 'hall' => $t( 'hall', 120 ), 'status' => in_array( $s, array( 'sample', 'university', 'checked' ), true ) ? $s : 'sample', 'checked_on' => $day( 'checked_on' ), 'checked_by' => $t( 'checked_by', 120 ), 'uploaded_on' => $day( 'uploaded_on' ), 'uploaded_by' => $t( 'uploaded_by', 120 ), 'elevator' => $yn( 'elevator' ), 'step_free' => $yn( 'step_free' ), 'ac' => $yn( 'ac' ), 'note' => $t( 'note', 160 ) );
		case 'closures':
			$p = $xy();
			if ( is_wp_error( $p ) ) {
				return $p;
			}
			if ( '' === $id() || '' === $p[0] ) {
				return new WP_Error( 'ogc_bad_closure', 'A closure needs its id and its place.', array( 'status' => 400 ) );
			}
			return array( 'id' => $id(), 'x' => $p[0], 'y' => $p[1], 'from' => $day( 'from' ), 'to' => $day( 'to' ), 'note' => $t( 'note', 160 ) );
		case 'plans':
			$kind = strtolower( $t( 'kind', 16 ) );
			if ( ! in_array( $kind, array( 'room', 'bath', 'restroom-w', 'restroom-m', 'stairs', 'elevator', 'corridor', 'lobby', 'lounge', 'laundry', 'entrance', 'outline', 'wing' ), true ) || '' === $t( 'hall', 120 ) ) {
				return new WP_Error( 'ogc_bad_shape', 'A shape needs its hall and kind.', array( 'status' => 400 ) );
			}
			$n = function ( $k ) use ( $r ) {
				return isset( $r[ $k ] ) && is_numeric( $r[ $k ] ) ? (string) round( (float) $r[ $k ], 1 ) : '0';
			};
			return array( 'hall' => $t( 'hall', 120 ), 'floor' => (string) max( 0, (int) ( isset( $r['floor'] ) ? $r['floor'] : 1 ) ), 'kind' => $kind, 'label' => $t( 'label', 24 ), 'x' => $n( 'x' ), 'y' => $n( 'y' ), 'w' => $n( 'w' ), 'h' => $n( 'h' ), 'note' => $t( 'note', 120 ) );
		case 'buildings':
			$kind = strtolower( $t( 'kind', 16 ) );
			$pts  = isset( $r['points'] ) ? (string) $r['points'] : '';
			if ( ! preg_match( '/^[a-z]{2,16}$/', $kind ) || ! preg_match( '/^[-0-9. ;,]{3,60000}$/', $pts ) ) {
				return new WP_Error( 'ogc_bad_shape', 'A building needs its kind and outline.', array( 'status' => 400 ) );
			}
			return array( 'code' => strtoupper( $t( 'code', 12 ) ), 'name' => $t( 'name', 120 ), 'kind' => $kind, 'short' => $t( 'short', 40 ), 'points' => $pts, 'aliases' => $t( 'aliases', 240 ), 'address' => $t( 'address', 160 ) );
	}
	return new WP_Error( 'ogc_bad_part', 'No such part.', array( 'status' => 404 ) );
}

function ogc_map_clean_rows( $part, $rows, $rec ) {
	if ( ! is_array( $rows ) || ( $rows && array_keys( $rows ) !== range( 0, count( $rows ) - 1 ) ) ) {
		return new WP_Error( 'ogc_bad_rows', 'rows must be a list.', array( 'status' => 400 ) );
	}
	if ( count( $rows ) > 5000 ) {
		return new WP_Error( 'ogc_too_big', 'Too many rows.', array( 'status' => 413 ) );
	}
	$b   = 'buildings' === $part ? null : ogc_map_bounds( $rec );
	$out = array();
	foreach ( $rows as $r ) {
		$c = ogc_map_clean_row( $part, $r, $b );
		if ( is_wp_error( $c ) ) {
			return $c;
		}
		$out[] = $c;
	}
	return $out;
}

/* ------------------------------------------------------------------ the routes */

add_action( 'rest_api_init', function () {
	$Y = '(?P<year>\d{4})';
	$P = '(?P<part>buildings|doors|places|spots|halls|plans|closures)';
	register_rest_route( OGC_NS, "/years/$Y/campus", array(
		array( 'methods' => 'GET', 'callback' => 'ogc_map_rest_get', 'permission_callback' => 'ogc_can_member' ),
	) );
	register_rest_route( OGC_NS, "/years/$Y/campus/$P", array(
		array( 'methods' => 'PUT', 'callback' => 'ogc_map_rest_put', 'permission_callback' => 'ogc_map_can_write' ),
		array( 'methods' => 'PATCH', 'callback' => 'ogc_map_rest_patch', 'permission_callback' => 'ogc_map_can_write' ),
	) );
	register_rest_route( OGC_NS, "/years/$Y/campus-plan", array(
		array( 'methods' => 'POST', 'callback' => 'ogc_map_rest_plan', 'permission_callback' => 'ogc_map_can_write_plans' ),
	) );
	register_rest_route( OGC_NS, "/years/$Y/campus-import", array(
		array( 'methods' => 'POST', 'callback' => 'ogc_map_rest_import', 'permission_callback' => 'ogc_can_webmaster' ),
	) );
	register_rest_route( OGC_NS, "/years/$Y/me/stay", array(
		array( 'methods' => 'GET', 'callback' => 'ogc_map_rest_stay', 'permission_callback' => 'ogc_map_can_self' ),
	) );
	register_rest_route( OGC_NS, "/years/$Y/rooms/taken", array(
		array( 'methods' => 'GET', 'callback' => 'ogc_map_rest_taken', 'permission_callback' => 'ogc_map_can_self' ),
	) );
} );

/**
 * The year a campus is changed by: the next Conference there (the soonest at that venue whose last day
 * hasn't passed; a year with no dates yet counts as to come, unless its year has passed). 0 when none is to come. A campus is shared
 * by every year at the venue, and a past COA keeps its access for 1–3 years, so a past year's members
 * must never change it (the critic, Oct 10: a 2026-only member moved 2027's pins and plan status).
 */
function ogc_map_next_year( $campus ) {
	if ( '' === $campus ) {
		return 0;
	}
	$today = current_time( 'Y-m-d' );
	$next  = 0;
	foreach ( ogc_years_all() as $y ) {
		if ( ogc_map_slug( isset( $y['venue'] ) ? $y['venue'] : '' ) !== $campus ) {
			continue;
		}
		$last = ! empty( $y['end'] ) ? (string) $y['end'] : ( ! empty( $y['start'] ) ? (string) $y['start'] : '' );
		// Over: its last day has passed, or (an old year kept without dates) its year has.
		if ( '' !== $last ? $last < $today : (int) $y['year'] < (int) substr( $today, 0, 4 ) ) {
			continue;
		}
		if ( ! $next || (int) $y['year'] < $next ) {
			$next = (int) $y['year'];
		}
	}
	return $next;
}

/** May the signed-in person change this year's campus? Webmasters; else members of the next Conference
 * there, writing through that year. Only webmasters replace the buildings (a new drawing). */
function ogc_map_may_write( $year, $part ) {
	if ( ogc_is_webmaster() ) {
		return true;
	}
	if ( 'buildings' === $part ) {
		return false;
	}
	$next = ogc_map_next_year( ogc_map_campus_of( $year ) );
	if ( ! ( $next && (int) $year === $next && ogc_is_member( $next ) ) ) {
		return false;
	}
	return ogc_map_is_owner( $next, $part );
}

/**
 * Polish 3: doors, closures and halls (what every later year at the campus inherits) are changed by the
 * owner the COA picks for the campus map (settings owner_campus: a committee's name, as the COA typed it)
 * and the COA themselves; anyone else of the year still pins rooms and spots. No owner picked: every member.
 */
function ogc_map_is_owner( $year, $part ) {
	if ( ! in_array( $part, array( 'doors', 'closures', 'halls', 'plans' ), true ) || ! function_exists( 'ogc_member_find' ) ) {
		return true;
	}
	$s     = ogc_map_keys( $year, 'settings' );
	$owner = isset( $s['owner_campus'] ) ? strtolower( trim( preg_replace( '/\s+committee$/i', '', (string) $s['owner_campus'] ) ) ) : '';
	if ( '' === $owner ) {
		return true;
	}
	$m = ogc_member_find( (int) $year, ogc_current_email() );
	// (No row: a local dev member, signed in as one without the members list.)
	if ( ! $m || 'coa' === $m['role'] ) {
		return true;
	}
	$names = array_map( function ( $k ) use ( $m ) { return strtolower( (string) ogc_member_committee_name( $m, $k ) ); }, ogc_member_committee_keys( $m ) );
	$names[] = strtolower( (string) $m['helps'] );
	foreach ( $names as $n ) {
		if ( '' !== $n && ( false !== strpos( $n, $owner ) || false !== strpos( $owner, $n ) ) ) {
			return true;
		}
	}
	return false;
}
function ogc_map_can_write( WP_REST_Request $req ) {
	if ( ogc_map_may_write( (int) $req['year'], (string) $req['part'] ) ) {
		return true;
	}
	$s = ogc_map_keys( (int) $req['year'], 'settings' );
	return ogc_rest_denied( ! empty( $s['owner_campus'] ) && ogc_is_member( (int) $req['year'] ) ? 'Changed by ' . sanitize_text_field( $s['owner_campus'] ) : 'Only the next Conference at this campus changes its map.' );
}

/** Signed in, for a year that exists: their own answer only. */
function ogc_map_can_self( WP_REST_Request $req ) {
	if ( ! is_user_logged_in() || '' === ogc_current_email() ) {
		return ogc_rest_denied( 'Sign in first.' );
	}
	return null !== ogc_year_get( (int) $req['year'] ) ? true : new WP_Error( 'ogc_none', 'No such year.', array( 'status' => 404 ) );
}

function ogc_map_rest_get( WP_REST_Request $req ) {
	$y   = (int) $req['year'];
	$rec = ogc_map_record( $y );
	if ( ! $rec ) {
		return rest_ensure_response( array( 'campus' => '', 'parts' => (object) array() ) );
	}
	$parts = array();
	foreach ( $rec as $k => $f ) {
		$parts[ $k ] = $f ? array( 'rows' => $f['rows'], 'cols' => $f['cols'], 'version' => $f['version'] ) : array( 'rows' => array(), 'cols' => array(), 'version' => 0 );
	}
	// Who uploaded or checked a hall's plan, as the site writes names ("Sarah C."), for the Halls tab (polish 3).
	foreach ( $parts['halls']['rows'] as $i => $h ) {
		foreach ( array( 'uploaded', 'checked' ) as $w ) {
			$u = ! empty( $h[ $w . '_by' ] ) ? get_user_by( 'email', (string) $h[ $w . '_by' ] ) : null;
			$parts['halls']['rows'][ $i ][ $w . '_name' ] = $u ? ( function_exists( 'ogc_ed_short' ) ? ogc_ed_short( $u->ID ) : ogc_first_l( $u->display_name ) ) : '';
		}
	}
	// Who may change the campus's doors, closures and halls this year (owner_campus), for the tool to say so.
	return rest_ensure_response( array( 'campus' => ogc_map_campus_of( $y ), 'bounds' => ogc_map_bounds( $rec ), 'parts' => $parts, 'may' => array( 'doors' => ogc_map_may_write( $y, 'doors' ), 'places' => ogc_map_may_write( $y, 'places' ) ) ) );
}

function ogc_map_rest_put( WP_REST_Request $req ) {
	$y    = (int) $req['year'];
	$part = $req['part'];
	$rec  = ogc_map_record( $y );
	if ( ! $rec ) {
		return new WP_Error( 'ogc_no_campus', 'The year has no campus yet.', array( 'status' => 409 ) );
	}
	$ver = $req->get_param( 'version' );
	if ( ! is_numeric( $ver ) ) {
		return new WP_Error( 'ogc_bad_version', 'version is the one last read.', array( 'status' => 400 ) );
	}
	$rows = ogc_map_clean_rows( $part, $req->get_param( 'rows' ), $rec );
	if ( is_wp_error( $rows ) ) {
		return $rows;
	}
	$campus = ogc_map_campus_of( $y );
	$old    = $rec[ $part ] ? $rec[ $part ]['rows'] : array();
	if ( 'halls' === $part ) {
		$by = array();
		foreach ( $old as $h ) {
			$by[ strtolower( (string) $h['hall'] ) ] = $h;
		}
		foreach ( $rows as $i => $h ) {
			$r = ogc_map_hall_rule( $h, isset( $by[ strtolower( $h['hall'] ) ] ) ? $by[ strtolower( $h['hall'] ) ] : array() );
			if ( is_wp_error( $r ) ) {
				return $r;
			}
			$rows[ $i ] = $r;
		}
	}
	$v      = ogc_map_put( $campus, $part, $rows, (int) $ver );
	if ( is_wp_error( $v ) ) {
		return $v;
	}
	ogc_log( 'campus_put', $y, $campus . '/' . $part, array( 'version' => $v, 'rows' => count( $rows ) ) );
	if ( 'halls' === $part ) {
		$was = array();
		foreach ( $old as $h ) {
			$was[ (string) $h['hall'] ] = (string) $h['status'];
		}
		foreach ( $rows as $h ) {
			$from = isset( $was[ $h['hall'] ] ) ? $was[ $h['hall'] ] : '';
			if ( $from !== $h['status'] ) {
				ogc_log( 'campus_hall_status', $y, $campus . '/halls', array( 'hall' => $h['hall'], 'from' => $from, 'to' => $h['status'] ) );
			}
		}
	}
	return rest_ensure_response( array( 'version' => $v ) );
}

/**
 * A hall's plan status, as it may change (polish 2: any member could mark IWU's sample geometry "From the
 * university", and households would then see a sample as fact). From the university: only by uploading
 * the plan (ogc_map_rest_plan). Checked: only a plan that isn't a sample, with who and when. Back to
 * sample: any time. Who checked and who uploaded are written here, never taken from the request.
 */
function ogc_map_hall_rule( $new, $old ) {
	$from = isset( $old['status'] ) ? (string) $old['status'] : 'sample';
	$to   = isset( $new['status'] ) ? (string) $new['status'] : $from;
	foreach ( array( 'checked_on', 'checked_by', 'uploaded_on', 'uploaded_by' ) as $k ) {
		$new[ $k ] = isset( $old[ $k ] ) ? (string) $old[ $k ] : '';
	}
	if ( $to === $from ) {
		return $new;
	}
	if ( 'university' === $to && 'checked' !== $from ) {
		return new WP_Error( 'ogc_plan_upload', 'Upload the university’s plan first.', array( 'status' => 400 ) );
	}
	if ( 'checked' === $to ) {
		if ( 'university' !== $from ) {
			return new WP_Error( 'ogc_plan_upload', 'Upload the university’s plan first.', array( 'status' => 400 ) );
		}
		$new['checked_on'] = current_time( 'Y-m-d' );
		$new['checked_by'] = ogc_current_email();
	}
	if ( 'sample' === $to ) {
		$new['checked_on'] = $new['checked_by'] = $new['uploaded_on'] = $new['uploaded_by'] = '';
	}
	if ( 'university' === $to ) {
		// Un-checking a checked plan: still the university's.
		$new['checked_on'] = $new['checked_by'] = '';
	}
	return $new;
}

function ogc_map_can_write_plans( WP_REST_Request $req ) {
	return ogc_map_may_write( (int) $req['year'], 'plans' ) ? true : ogc_rest_denied( 'Only the next Conference at this campus changes its map.' );
}

/**
 * A hall's plan from the university: plans.csv rows for that hall (hall, floor, kind, label, x, y, w, h,
 * note; feet). preview (apply false): what it holds, floor by floor. apply: the hall's rows replaced, the
 * hall marked From the university (uploaded by, on), its Checked cleared. Logged.
 */
function ogc_map_rest_plan( WP_REST_Request $req ) {
	$y    = (int) $req['year'];
	$hall = sanitize_text_field( (string) $req->get_param( 'hall' ) );
	$rec  = ogc_map_record( $y );
	if ( ! $rec ) {
		return new WP_Error( 'ogc_no_campus', 'The year has no campus yet.', array( 'status' => 409 ) );
	}
	$known = null;
	foreach ( $rec['halls'] ? $rec['halls']['rows'] : array() as $h ) {
		if ( strtolower( (string) $h['hall'] ) === strtolower( $hall ) ) {
			$known = (string) $h['hall'];
		}
	}
	if ( null === $known ) {
		return new WP_Error( 'ogc_bad_hall', 'No such hall.', array( 'status' => 404 ) );
	}
	$in = $req->get_param( 'rows' );
	if ( ! is_array( $in ) ) {
		return new WP_Error( 'ogc_bad_rows', 'rows must be a list.', array( 'status' => 400 ) );
	}
	// Rows for another hall are a different file: said, not mixed in.
	foreach ( $in as $i => $r ) {
		if ( ! is_array( $r ) ) {
			return new WP_Error( 'ogc_bad_rows', 'A row is an object.', array( 'status' => 400 ) );
		}
		$h = isset( $r['hall'] ) ? trim( (string) $r['hall'] ) : '';
		if ( '' !== $h && strtolower( $h ) !== strtolower( $known ) ) {
			return new WP_Error( 'ogc_other_hall', 'Row ' . ( $i + 2 ) . ' is for ' . sanitize_text_field( $h ) . '.', array( 'status' => 400 ) );
		}
		$in[ $i ]['hall'] = $known;
	}
	$rows = ogc_map_clean_rows( 'plans', array_values( $in ), $rec );
	if ( is_wp_error( $rows ) ) {
		return $rows;
	}
	$floors = array();
	foreach ( $rows as $r ) {
		$f = (int) $r['floor'];
		if ( ! isset( $floors[ $f ] ) ) {
			$floors[ $f ] = 0;
		}
		if ( 'room' === $r['kind'] ) {
			$floors[ $f ]++;
		}
	}
	ksort( $floors );
	if ( ! array_sum( $floors ) ) {
		return new WP_Error( 'ogc_no_rooms', 'No rooms in the file.', array( 'status' => 400 ) );
	}
	$sum = array( 'hall' => $known, 'floors' => $floors, 'rooms' => array_sum( $floors ), 'shapes' => count( $rows ) );
	if ( ! $req->get_param( 'apply' ) ) {
		return rest_ensure_response( $sum );
	}
	$campus = ogc_map_campus_of( $y );
	for ( $try = 0; $try < 6; $try++ ) {
		$cur  = ogc_map_get( $campus, 'plans' );
		$keep = array();
		foreach ( $cur ? $cur['rows'] : array() as $r ) {
			if ( strtolower( (string) $r['hall'] ) !== strtolower( $known ) ) {
				$keep[] = $r;
			}
		}
		$v = ogc_map_put( $campus, 'plans', array_merge( $keep, $rows ), $cur ? $cur['version'] : 0, array( 'hall', 'floor', 'kind', 'label', 'x', 'y', 'w', 'h', 'note' ) );
		if ( ! is_wp_error( $v ) ) {
			break;
		}
	}
	if ( is_wp_error( $v ) ) {
		return $v;
	}
	for ( $try = 0; $try < 6; $try++ ) {
		$hs = ogc_map_get( $campus, 'halls' );
		$hr = $hs ? $hs['rows'] : array();
		foreach ( $hr as $i => $h ) {
			if ( strtolower( (string) $h['hall'] ) === strtolower( $known ) ) {
				$hr[ $i ] = array_merge( $h, array( 'status' => 'university', 'uploaded_on' => current_time( 'Y-m-d' ), 'uploaded_by' => ogc_current_email(), 'checked_on' => '', 'checked_by' => '' ) );
			}
		}
		$hv = ogc_map_put( $campus, 'halls', $hr, $hs ? $hs['version'] : 0, array( 'hall', 'status', 'checked_on', 'checked_by', 'uploaded_on', 'uploaded_by', 'elevator', 'step_free', 'ac', 'note' ) );
		if ( ! is_wp_error( $hv ) ) {
			break;
		}
	}
	ogc_log( 'campus_plan_upload', $y, $campus . '/plans', array( 'hall' => $known, 'rooms' => $sum['rooms'], 'version' => $v ) );
	ogc_log( 'campus_hall_status', $y, $campus . '/halls', array( 'hall' => $known, 'to' => 'university' ) );
	return rest_ensure_response( array_merge( $sum, array( 'applied' => true, 'version' => $v ) ) );
}

/** One row, changed on the server's current copy (two people pinning different rooms never collide). */
function ogc_map_rest_patch( WP_REST_Request $req ) {
	$y    = (int) $req['year'];
	$part = $req['part'];
	$key  = ogc_map_parts()[ $part ];
	$rec  = ogc_map_record( $y );
	if ( ! $rec ) {
		return new WP_Error( 'ogc_no_campus', 'The year has no campus yet.', array( 'status' => 409 ) );
	}
	if ( '' === $key ) {
		return new WP_Error( 'ogc_bad_op', 'This part is changed whole (PUT).', array( 'status' => 400 ) );
	}
	$row  = (array) $req->get_param( 'row' );
	$gone = ! empty( $row['_gone'] );
	unset( $row['_gone'] );
	$clean = $gone ? array( $key => isset( $row[ $key ] ) ? (string) $row[ $key ] : '' ) : ogc_map_clean_row( $part, $row, ogc_map_bounds( $rec ) );
	if ( is_wp_error( $clean ) ) {
		return $clean;
	}
	// Only the columns sent are changed (a pin leaves the place's name and building as they are).
	$clean = array_intersect_key( $clean, $row + array( $key => 1 ) );
	if ( '' === (string) $clean[ $key ] ) {
		return new WP_Error( 'ogc_bad_row', 'The row needs its ' . $key . '.', array( 'status' => 400 ) );
	}
	$campus = ogc_map_campus_of( $y );
	$match  = function ( $a, $b ) use ( $key ) {
		return 'code' === $key ? strtoupper( (string) $a ) === strtoupper( (string) $b ) : (string) $a === (string) $b;
	};
	for ( $try = 0; $try < 6; $try++ ) {
		$cur  = ogc_map_get( $campus, $part );
		$rows = $cur ? $cur['rows'] : array();
		$at   = -1;
		$was  = array();
		foreach ( $rows as $i => $r ) {
			if ( isset( $r[ $key ] ) && $match( $r[ $key ], $clean[ $key ] ) ) {
				$at = $i;
				break;
			}
		}
		if ( $gone ) {
			if ( $at > -1 ) {
				array_splice( $rows, $at, 1 );
			}
		} elseif ( $at > -1 ) {
			$was         = $rows[ $at ];
			$rows[ $at ] = array_merge( $rows[ $at ], $clean );
		} else {
			$rows[] = $clean;
		}
		if ( 'halls' === $part && ! $gone ) {
			$i = $at > -1 ? $at : count( $rows ) - 1;
			$r = ogc_map_hall_rule( $rows[ $i ], $was );
			if ( is_wp_error( $r ) ) {
				return $r;
			}
			$rows[ $i ] = $r;
		}
		$v = ogc_map_put( $campus, $part, $rows, $cur ? $cur['version'] : 0 );
		if ( ! is_wp_error( $v ) ) {
			ogc_log( 'campus_row', $y, $campus . '/' . $part, array( 'version' => $v, 'key' => (string) $clean[ $key ], 'gone' => $gone ) );
			// A hall's plan status decides whether households see its plan: the old and new value, kept.
			if ( 'halls' === $part && isset( $clean['status'] ) ) {
				ogc_log( 'campus_hall_status', $y, $campus . '/halls', array( 'hall' => (string) $clean['hall'], 'from' => isset( $was['status'] ) ? (string) $was['status'] : '', 'to' => (string) $clean['status'] ) );
			}
			return rest_ensure_response( array( 'version' => $v, 'row' => $gone ? null : ( $at > -1 ? $rows[ $at ] : $clean ) ) );
		}
	}
	return $v;
}

/**
 * A new drawing of the campus from OpenStreetMap (made by tools/osm-campus.mjs from an extract the
 * webmaster downloads; nothing here calls another site). preview: what would change, building by
 * building, with the doors and pins kept. apply: replace the buildings, keeping the last drawing for
 * Undo, and add the drawing's new entrances as doors to check. undo: put the last drawing back.
 */
function ogc_map_rest_import( WP_REST_Request $req ) {
	$y      = (int) $req['year'];
	$rec    = ogc_map_record( $y );
	$campus = ogc_map_campus_of( $y );
	if ( '' === $campus ) {
		return new WP_Error( 'ogc_no_campus', 'Choose the year’s campus first.', array( 'status' => 409 ) );
	}
	$mode = (string) $req->get_param( 'mode' );
	if ( 'undo' === $mode ) {
		$prev = ogc_map_get( $campus, 'buildings_prev' );
		$cur  = ogc_map_get( $campus, 'buildings' );
		if ( ! $prev || ! $cur ) {
			return new WP_Error( 'ogc_nothing', 'Nothing to undo.', array( 'status' => 409 ) );
		}
		$v = ogc_map_put( $campus, 'buildings', $prev['rows'], $cur['version'], $prev['cols'] );
		ogc_log( 'campus_undo', $y, $campus, array( 'version' => $v ) );
		return rest_ensure_response( array( 'version' => $v ) );
	}
	$in = $req->get_param( 'rows' );
	if ( ! is_array( $in ) ) {
		return new WP_Error( 'ogc_bad_rows', 'rows must be a list.', array( 'status' => 400 ) );
	}
	$doors_in = array();
	$build_in = array();
	foreach ( $in as $r ) {
		if ( is_array( $r ) && isset( $r['kind'] ) && 'door' === $r['kind'] ) {
			$doors_in[] = $r;
		} else {
			$build_in[] = $r;
		}
	}
	$rows = ogc_map_clean_rows( 'buildings', $build_in, $rec );
	if ( is_wp_error( $rows ) ) {
		return $rows;
	}
	$old = $rec ? $rec['buildings']['rows'] : array();
	// A building already on the campus keeps what the campus says of it: its kind (hall, dining…), code,
	// short name, other names and street address. OpenStreetMap only says "building".
	$known = array();
	foreach ( $old as $r ) {
		if ( ! empty( $r['name'] ) && ! in_array( $r['kind'], array( 'path', 'road', 'steps', 'highway', 'parking', 'green', 'water', 'geo' ), true ) ) {
			$known[ strtolower( $r['name'] ) ] = $r;
		}
	}
	foreach ( $rows as &$r ) {
		$k = strtolower( $r['name'] );
		if ( isset( $known[ $k ] ) && in_array( $r['kind'], array( 'other', 'hall', 'worship' ), true ) ) {
			foreach ( array( 'kind', 'code', 'short', 'aliases', 'address' ) as $f ) {
				if ( isset( $known[ $k ][ $f ] ) && '' !== (string) $known[ $k ][ $f ] ) {
					$r[ $f ] = (string) $known[ $k ][ $f ];
				}
			}
		}
	}
	unset( $r );
	$key = function ( $r ) {
		return strtolower( $r['kind'] . '|' . $r['name'] . '|' . $r['code'] );
	};
	$was   = array();
	$now   = array();
	foreach ( $old as $r ) {
		$was[ $key( $r ) ][] = (string) $r['points'];
	}
	foreach ( $rows as $r ) {
		$now[ $key( $r ) ][] = (string) $r['points'];
	}
	$named = function ( $k ) {
		return '' !== explode( '|', $k )[1];
	};
	$diff  = array( 'added' => array(), 'changed' => array(), 'removed' => array() );
	foreach ( $now as $k => $pts ) {
		if ( ! isset( $was[ $k ] ) ) {
			$diff['added'][] = $k;
		} elseif ( $was[ $k ] !== $pts ) {
			$diff['changed'][] = $k;
		}
	}
	foreach ( $was as $k => $pts ) {
		if ( ! isset( $now[ $k ] ) ) {
			$diff['removed'][] = $k;
		}
	}
	$sum = array();
	foreach ( $diff as $w => $ks ) {
		$sum[ $w ] = array(
			'n'     => count( $ks ),
			'names' => array_values( array_unique( array_map( function ( $k ) {
				return explode( '|', $k )[1];
			}, array_filter( $ks, $named ) ) ) ),
		);
	}
	$sum['kept'] = array(
		'doors'  => $rec && $rec['doors'] ? count( $rec['doors']['rows'] ) : 0,
		'places' => $rec && $rec['places'] ? count( array_filter( $rec['places']['rows'], function ( $p ) { return '' !== (string) $p['x']; } ) ) : 0,
	);
	if ( 'apply' !== $mode ) {
		return rest_ensure_response( $sum );
	}
	if ( $rec ) {
		ogc_map_put( $campus, 'buildings_prev', $rec['buildings']['rows'], ( ogc_map_get( $campus, 'buildings_prev' ) ?: array( 'version' => 0 ) )['version'], $rec['buildings']['cols'] );
	}
	$cur = ogc_map_get( $campus, 'buildings' );
	$v   = ogc_map_put( $campus, 'buildings', $rows, $cur ? $cur['version'] : 0 );
	if ( is_wp_error( $v ) ) {
		return $v;
	}
	// The drawing's entrances that aren't already doors (within 4 m) come in to be checked.
	$doors = ogc_map_get( $campus, 'doors' );
	$list  = $doors ? $doors['rows'] : array();
	$added = 0;
	foreach ( $doors_in as $d ) {
		$p = preg_split( '/[\s,]+/', trim( (string) ( isset( $d['points'] ) ? $d['points'] : '' ) ) );
		if ( count( $p ) < 2 || ! is_numeric( $p[0] ) || ! is_numeric( $p[1] ) ) {
			continue;
		}
		$near = false;
		foreach ( $list as $o ) {
			$near = $near || hypot( (float) $o['x'] - (float) $p[0], (float) $o['y'] - (float) $p[1] ) < 4;
		}
		if ( ! $near ) {
			$list[] = array( 'id' => 'd' . substr( md5( $p[0] . ',' . $p[1] ), 0, 8 ), 'building' => sanitize_text_field( (string) $d['name'] ), 'label' => '', 'x' => (string) round( (float) $p[0], 1 ), 'y' => (string) round( (float) $p[1], 1 ), 'step_free' => '', 'open' => '', 'key_only' => '', 'checked' => '' );
			$added++;
		}
	}
	if ( $added ) {
		ogc_map_put( $campus, 'doors', $list, $doors ? $doors['version'] : 0 );
	}
	$sum['doors_added'] = $added;
	$sum['version']     = $v;
	ogc_log( 'campus_import', $y, $campus, array( 'version' => $v, 'added' => $sum['added']['n'], 'changed' => $sum['changed']['n'], 'removed' => $sum['removed']['n'] ) );
	return rest_ensure_response( $sum );
}

/* ------------------------------------------------------------------ where I sleep (my own only) */

/** A year's registration settings (registration.csv) as key → value. */
function ogc_map_keys( $year, $name ) {
	$out = array();
	$f   = ogc_file_get( $year, $name );
	foreach ( $f ? $f['rows'] : array() as $r ) {
		if ( isset( $r['key'] ) ) {
			$out[ (string) $r['key'] ] = (string) ( isset( $r['value'] ) ? $r['value'] : '' );
		}
	}
	return $out;
}

/** Each room of the year (rooms.csv ranges): "Hall|num" → { hall, num, floor }. */
function ogc_map_rooms( $year ) {
	$out = array();
	$f   = ogc_file_get( $year, 'rooms' );
	foreach ( $f ? $f['rows'] : array() as $r ) {
		$h = isset( $r['hall'] ) ? trim( (string) $r['hall'] ) : '';
		if ( '' === $h || 0 === strpos( $h, '#' ) ) {
			continue;
		}
		if ( isset( $r['room'] ) && '' !== (string) $r['room'] ) {
			$out[ $h . '|' . $r['room'] ] = array( 'hall' => $h, 'num' => (string) $r['room'], 'floor' => (int) ( isset( $r['floor'] ) ? $r['floor'] : 1 ) );
			continue;
		}
		for ( $n = (int) ( isset( $r['first'] ) ? $r['first'] : 0 ); $n > 0 && $n <= (int) $r['last'] && $n < 100000; $n++ ) {
			$out[ $h . '|' . $n ] = array( 'hall' => $h, 'num' => (string) $n, 'floor' => (int) ( isset( $r['floor'] ) ? $r['floor'] : 1 ) );
		}
	}
	return $out;
}

/**
 * The signed-in person's stay, from their own registration and Lodging's rooms: a dorm's rooms once
 * Lodging has published them (or the household chose them, where households choose), a Young Folk's
 * halls, or the camper lot. Never anyone else's; never cached (no-store).
 */
function ogc_map_rest_stay( WP_REST_Request $req ) {
	$y    = (int) $req['year'];
	$regs = ogc_records( $y, 'registrations', ogc_current_email() );
	$out  = array( 'type' => '' );
	if ( ! $regs ) {
		return ogc_map_private( $out );
	}
	$cfg    = ogc_map_keys( $y, 'registration' );
	$rooms  = ogc_map_rooms( $y );
	$state  = ogc_state_get( $y, 'rooms' );
	$assign = $state && is_array( $state['value'] ) ? $state['value'] : array();
	// Only what Lodging has published (or what the household chose, where households choose): the
	// Conference having begun doesn't publish a working assignment (the critic, Oct 10).
	$posted = ! empty( $cfg['rooms_posted'] ) || 'households' === ( isset( $cfg['room_choice'] ) ? $cfg['room_choice'] : '' );
	foreach ( $regs as $rec ) {
		$d    = (array) $rec['data'];
		$stay = isset( $d['stay'] ) ? (array) $d['stay'] : array();
		$type = isset( $stay['type'] ) ? (string) $stay['type'] : '';
		if ( 'dorm' === $type ) {
			$id   = isset( $d['id'] ) ? (string) $d['id'] : '';
			$ids  = $id && isset( $assign[ $id ] ) ? (array) $assign[ $id ] : ( isset( $stay['chosen'] ) ? (array) $stay['chosen'] : array() );
			$list = array();
			foreach ( $ids as $rid ) {
				if ( isset( $rooms[ (string) $rid ] ) ) {
					$list[] = $rooms[ (string) $rid ];
				}
			}
			$out = array( 'type' => 'dorm', 'posted' => (bool) $posted, 'rooms' => $posted ? $list : array(), 'doors' => $posted && $list ? ogc_map_key_doors( $y, array( $list[0]['hall'] ) ) : array() );
		} elseif ( 'yf' === $type && '' === $out['type'] ) {
			$halls = array();
			$f     = ogc_file_get( $y, 'rooms' );
			foreach ( $f ? $f['rows'] : array() as $r ) {
				if ( isset( $r['for'] ) && preg_match( '/^young/i', (string) $r['for'] ) && ! in_array( $r['hall'], $halls, true ) ) {
					$halls[] = (string) $r['hall'];
				}
			}
			$out = array( 'type' => 'yf', 'halls' => $halls, 'doors' => count( $halls ) === 1 ? ogc_map_key_doors( $y, $halls ) : array() );
		} elseif ( 'camper' === $type && '' === $out['type'] ) {
			$out = array( 'type' => 'camper' );
		}
	}
	return ogc_map_private( $out );
}

/** Taken rooms while households choose: ids only (no household, no name), the asker's own left out. */
function ogc_map_rest_taken( WP_REST_Request $req ) {
	$y   = (int) $req['year'];
	$cfg = ogc_map_keys( $y, 'registration' );
	if ( 'households' !== ( isset( $cfg['room_choice'] ) ? $cfg['room_choice'] : '' ) ) {
		return ogc_map_private( array( 'choosing' => false, 'ids' => array() ) );
	}
	$mine  = array();
	$taken = array();
	foreach ( ogc_records( $y, 'registrations' ) as $rec ) {
		$d  = (array) $rec['data'];
		$id = isset( $d['id'] ) ? (string) $d['id'] : '';
		if ( $rec['email'] === ogc_current_email() ) {
			$mine[ $id ] = true;
			continue;
		}
		foreach ( isset( $d['stay']['chosen'] ) ? (array) $d['stay']['chosen'] : array() as $r ) {
			$taken[ (string) $r ] = true;
		}
	}
	$state = ogc_state_get( $y, 'rooms' );
	foreach ( $state && is_array( $state['value'] ) ? $state['value'] : array() as $hid => $ids ) {
		if ( ! isset( $mine[ (string) $hid ] ) ) {
			foreach ( (array) $ids as $r ) {
				$taken[ (string) $r ] = true;
			}
		}
	}
	return ogc_map_private( array( 'choosing' => true, 'ids' => array_keys( $taken ) ) );
}

/** A hall's key-only doors (left out of the public campus.csv), for the people sleeping there. */
function ogc_map_key_doors( $year, $halls ) {
	$rec = ogc_map_record( $year );
	$out = array();
	foreach ( $rec && $rec['doors'] ? $rec['doors']['rows'] : array() as $d ) {
		if ( 'yes' === $d['key_only'] && in_array( strtolower( (string) $d['building'] ), array_map( 'strtolower', $halls ), true ) ) {
			$out[] = array( 'id' => $d['id'], 'building' => $d['building'], 'label' => $d['label'], 'x' => $d['x'], 'y' => $d['y'], 'step_free' => $d['step_free'], 'open' => $d['open'] );
		}
	}
	return $out;
}

function ogc_map_private( $data ) {
	$res = rest_ensure_response( $data );
	$res->header( 'Cache-Control', 'private, no-store, max-age=0' );
	return $res;
}

/* ------------------------------------------------------------------ the pages */

/** The guide's maps app on the Conference page and the guide; the pins tool on the COA's year. */
add_filter( 'ogc_pages', function ( $p ) {
	$before = function ( $list, $file, $add ) {
		$list = (array) $list;
		$at   = array_search( $file, $list, true );
		if ( false === $at ) {
			$list[] = $add;
		} elseif ( ! in_array( $add, $list, true ) ) {
			array_splice( $list, $at, 0, array( $add ) );
		}
		return $list;
	};
	foreach ( array( 'conference', 'guide' ) as $k ) {
		if ( isset( $p[ $k ] ) ) {
			$p[ $k ]['scripts'] = $before( $p[ $k ]['scripts'], 'schedule-hub/week.js', 'shared/ogc-map-app.js' );
		}
	}
	if ( isset( $p['year'] ) ) {
		$p['year']['scripts'] = $before( $p['year']['scripts'], 'year/year.js', 'shared/ogc-map-pins.js' );
	}
	return $p;
} );

// The app's Campus › Pins draws the same walk-through (the year page that loaded it now opens the
// app): the pins tool right after the map it builds on (added at 20 by the committees' screens).
add_filter( 'ogc_pages', function ( $p ) {
	if ( ! isset( $p['app'] ) ) {
		return $p;
	}
	$s  = array_values( array_diff( (array) $p['app']['scripts'], array( 'shared/ogc-map-pins.js' ) ) );
	$at = array_search( 'shared/ogc-map.js', $s, true );
	if ( false === $at ) {
		return $p;
	}
	array_splice( $s, $at + 1, 0, array( 'shared/ogc-map-pins.js' ) );
	$p['app']['scripts'] = $s;
	return $p;
}, 30 );
