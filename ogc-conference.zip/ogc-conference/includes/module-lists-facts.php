<?php
/**
 * Round 6, "the committees' own lists" (Oct 17, 2026; docs/27-back-end-map/area-committee-lists 10.2):
 * one count, one function, for every number these lists show (README rule 10). Each list's view works
 * out its own fact from the rows it draws (`fact`: { line, head, n }); the committee's Work row, Home
 * and the COA's Final counts line read the same `line`, the screen's title row shows `head`, which
 * always starts with `line` word for word.
 *
 *   ogc_lst_fact( $y, $view )        the fact of meals · preteens · communion · nursery · halls, as the
 *                                    list itself works it out (memoised per request and previewed date)
 *   ogc_lst_meals_due( $y )          Meal counts' one due date: the task "Final meal counts to the
 *                                    caterer" (L3; the Caterer panel's Counts due moves the task)
 *   ogc_lst_services( $y, $public )  the services (rows of kind Worship, Council or Communion, for
 *                                    Everyone or Conference) by day: Ushers' Services, Nursery's days
 *   GET app/{y}/services             Ushers' Services: the services as the public schedule has them
 *
 * Mechanical (docs/25): plain sums of plain fields; nothing reads a note.
 */

defined( 'ABSPATH' ) || exit;

/* ================================================================== small words */

function ogc_lst_n( $n, $one, $many = '' ) {
	return (int) $n . ' ' . ( 1 === (int) $n ? $one : ( '' !== $many ? $many : $one . 's' ) );
}

/** "Sun May 30". */
function ogc_lst_dmd( $iso ) {
	$t = strtotime( (string) $iso . ' 12:00:00 UTC' );
	return $t ? gmdate( 'D M j', $t ) : '';
}

/** "As of May 5, 12:00 PM" on the campus's clock (the list's own day, previewed or not). */
function ogc_lst_asof_words( $ctx ) {
	return 'As of ' . ogc_lst_md( $ctx['now']['date'] ) . ', ' . ogc_lst_hm( $ctx['now']['min'] );
}

/** A place code → its name ("J" → "Jackson Library"), else the code as written. */
function ogc_lst_place_name( $year, $code ) {
	static $memo = array();
	$c = strtoupper( trim( (string) $code ) );
	if ( '' === $c ) {
		return '';
	}
	if ( ! isset( $memo[ $year ] ) ) {
		$memo[ $year ] = function_exists( 'ogc_sched_places' ) ? ogc_sched_places( (int) $year ) : array();
	}
	return isset( $memo[ $year ][ $c ]['name'] ) && '' !== $memo[ $year ][ $c ]['name'] ? $memo[ $year ][ $c ]['name'] : (string) $code;
}

/** Why a meal's count moved, as counts by reason (Food's view, L5): [{ what, households, change }]. */
function ogc_lst_why_counts( $why ) {
	$order = array( 'New' => 0, 'Changed' => 1, 'Leaving early' => 2, 'Cancelled' => 3 );
	$out   = array();
	foreach ( (array) $why as $w ) {
		$k = (string) $w['what'];
		if ( ! isset( $out[ $k ] ) ) {
			$out[ $k ] = array( 'what' => $k, 'households' => 0, 'change' => 0 );
		}
		$out[ $k ]['households']++;
		$out[ $k ]['change'] += (int) $w['now'] - (int) $w['was'];
	}
	uasort( $out, function ( $a, $b ) use ( $order ) {
		return ( isset( $order[ $a['what'] ] ) ? $order[ $a['what'] ] : 9 ) - ( isset( $order[ $b['what'] ] ) ? $order[ $b['what'] ] : 9 );
	} );
	return array_values( $out );
}

/* ================================================================== Meal counts' due date (L3) */

function ogc_lst_meals_due( $year ) {
	if ( function_exists( 'ogc_app_tasks' ) && function_exists( 'ogc_app_tables_ready' ) && ogc_app_tables_ready() ) {
		foreach ( ogc_app_tasks( (int) $year, array( 'food' ) ) as $t ) {
			if ( 'meals_sent' === $t['kind'] && ! empty( $t['due'] ) ) {
				return (string) $t['due'];
			}
		}
	}
	$set = ogc_lst_state( $year, 'lists_settings' );
	if ( ! empty( $set['counts_due'] ) ) {
		return (string) $set['counts_due'];
	}
	$row = ogc_year_get( (int) $year );
	return $row && ! empty( $row['start'] ) ? ogc_lst_add_days( $row['start'], -14 ) : '';
}

/* ================================================================== each list's fact, from its rows */

/**
 * Meal counts (area-committee-lists 2.8). n: meals changed since the last send (the Changed since
 * sent view holds exactly these). done: a Final was sent and nothing changed since (the COA's Final
 * counts line counts Food as sent then).
 */
function ogc_lst_fact_words_meals( $d, $ctx ) {
	$last  = $d['sent'];
	$final = $d['final'];
	$n     = (int) $d['changed'];
	$due   = (string) $d['due'];
	$big   = $d['busiest'] && $d['busiest']['total'] ? ' · ' . $d['busiest']['total'] . ' at the busiest meal' : '';
	if ( ! $d['regs'] && ! $last ) {
		return array( 'line' => '', 'head' => '', 'n' => 0, 'state' => 'Not sent', 'done' => false );
	}
	if ( $ctx['held'] ) {
		$line = $final ? 'Final sent ' . ogc_lst_md( $final['day'] ) : ( $last ? 'Last sent ' . ogc_lst_md( $last['day'] ) : 'Never sent' );
		return array( 'line' => $line, 'head' => $line, 'n' => 0, 'state' => $line, 'done' => (bool) $final );
	}
	$changed = $n ? ' · ' . ogc_lst_n( $n, 'meal' ) . ' changed' : '';
	if ( ! $last ) {
		$line = ( $due ? 'Due ' . ogc_lst_md( $due ) . ' · ' : '' ) . 'Not sent';
		return array( 'line' => $line, 'head' => $line . $big, 'n' => 0, 'state' => 'Not sent', 'done' => false );
	}
	$line = ! empty( $last['final'] ) ? 'Final sent ' . ogc_lst_md( $last['day'] ) . $changed : 'Sent ' . ogc_lst_md( $last['day'] ) . ( $changed ? $changed : ' · No changes' );
	$head = $line . $big . ( ! $final && $due ? ' · Due ' . ogc_lst_md( $due ) : '' );
	return array( 'line' => $line, 'head' => $head, 'n' => $n, 'state' => $line, 'done' => $final && ! $n );
}

function ogc_lst_fact_words_preteens( $d, $ctx ) {
	if ( ! $d['count'] ) {
		return array( 'line' => '', 'head' => '', 'n' => 0 );
	}
	$line = ogc_lst_n( $d['count'], 'preteen' ) . ( $d['since'] ? ' · ' . $d['since'] . ' since printed' : '' );
	return array( 'line' => $line, 'head' => $line . ' · ' . ogc_lst_asof_words( $ctx ), 'n' => (int) $d['since'] );
}

function ogc_lst_fact_words_communion( $d, $ctx ) {
	if ( ! $d['total'] ) {
		return array( 'line' => '', 'head' => '', 'n' => 0 );
	}
	$line = $d['total'] . ' communing' . ( $d['date'] ? ' · ' . ogc_lst_dmd( $d['date'] ) : '' );
	$head = $line . ' · ' . ogc_lst_n( count( $d['households'] ), 'household' ) . ( $d['since'] ? ' · ' . $d['since'] . ' since printed' : '' ) . ' · ' . ogc_lst_asof_words( $ctx );
	return array( 'line' => $line, 'head' => $head, 'n' => (int) $d['since'] );
}

/** Counts by day: the busiest day (L15), under 3 first, else 3 to 5. */
function ogc_lst_fact_words_nursery( $d, $ctx ) {
	if ( ! $d['under3'] && ! $d['small'] ) {
		return array( 'line' => '', 'head' => '', 'n' => 0 );
	}
	$k   = $d['under3'] ? 'under3' : 'small';
	$top = null;
	foreach ( $d['days'] as $x ) {
		if ( ! $top || $x[ $k ] > $top[ $k ] ) {
			$top = $x;
		}
	}
	$line = $top && $top[ $k ] ? $top[ $k ] . ( 'under3' === $k ? ' under 3' : ' ages 3–5' ) . ' on ' . ogc_lst_dmd( $top['date'] ) : '';
	$head = $line . ( $d['since'] ? ' · ' . ogc_lst_n( $d['since'], 'day' ) . ' changed since printed' : '' ) . ' · ' . ogc_lst_asof_words( $ctx );
	return array( 'line' => $line, 'head' => $head, 'n' => (int) $d['since'] );
}

function ogc_lst_fact_words_halls( $d, $ctx ) {
	if ( ! $d['total'] ) {
		return array( 'line' => '', 'head' => '', 'n' => 0 );
	}
	$line  = $d['total'] . ' in the halls' . ( $d['since'] ? ' · ' . $d['since'] . ' since printed' : '' );
	$halls = array();
	foreach ( $d['halls'] as $h ) {
		$halls[] = $h['n'] . ' ' . ( 'men' === $h['key'] ? 'young men' : ( 'women' === $h['key'] ? 'young women' : 'hall not set' ) );
	}
	return array( 'line' => $line, 'head' => $line . ' · ' . implode( ' · ', $halls ) . ' · ' . ogc_lst_asof_words( $ctx ), 'n' => (int) $d['since'] );
}

/**
 * A list's fact as its own view works it out, for the Work rows, Home and the Final counts line. The
 * app's previewed day (?as_of) is the list's day too. A cleared year: its counts only.
 */
function ogc_lst_fact( $year, $view ) {
	static $memo = array();
	$as  = ! empty( $GLOBALS['ogc_app_as_of'] ) ? (string) $GLOBALS['ogc_app_as_of'] : '';
	$key = (int) $year . '|' . $view . '|' . $as;
	if ( isset( $memo[ $key ] ) ) {
		return $memo[ $key ];
	}
	$fn = 'ogc_lst_view_' . $view;
	if ( ! function_exists( $fn ) || ! in_array( $view, array( 'meals', 'preteens', 'communion', 'nursery', 'halls' ), true ) ) {
		return array( 'line' => '', 'head' => '', 'n' => 0 );
	}
	$req = new WP_REST_Request( 'GET' );
	$req->set_param( 'fact', 1 );
	if ( '' !== $as ) {
		$req->set_param( 'as_of', $as );
	}
	$ctx = ogc_lst_ctx( $year, $req );
	if ( $ctx['cleared'] ) {
		return $memo[ $key ] = array( 'line' => 'Counts only', 'head' => 'Counts only', 'n' => 0, 'state' => 'Counts only', 'done' => true );
	}
	$d = $fn( (int) $year, $ctx, $req );
	return $memo[ $key ] = is_array( $d ) && isset( $d['fact'] ) ? $d['fact'] : array( 'line' => '', 'head' => '', 'n' => 0 );
}

/* ================================================================== services (Ushers; Nursery's days) */

/**
 * The services by date: rows of kind Worship, Council or Communion, for Everyone or Conference (never
 * Preteens' or Young Folks' own), by the row's kind and For only, never its title. $public: as a visitor
 * reads the schedule (Ushers' Services: once the COA has published it); else the schedule as kept
 * (Nursery's days, which the lists have always read). Returns { date: [ row… ] } in time order.
 */
function ogc_lst_services( $year, $public = false ) {
	$days = function_exists( 'ogc_reg_days' ) ? ogc_reg_days( (int) $year ) : array();
	$f    = ogc_file_get( (int) $year, 'schedule' );
	$rows = $f ? (array) $f['rows'] : array();
	if ( $public ) {
		// Public from its Publish day (the app's day, so a previewed date reads as it will), then the copy
		// the public reads (changes since wait for Publish changes).
		$s    = function_exists( 'ogc_coa_kv' ) ? ogc_coa_kv( (int) $year, 'settings' ) : array();
		$on   = isset( $s['schedule_posted'] ) ? (string) $s['schedule_posted'] : '';
		$day  = function_exists( 'ogc_app_today' ) ? ogc_app_today( (int) $year ) : gmdate( 'Y-m-d' );
		$live = function_exists( 'ogc_coa_live_get' ) ? ogc_coa_live_get( (int) $year, 'schedule' ) : null;
		$rows = preg_match( '/^\d{4}-\d{2}-\d{2}$/', $on ) && '9999-12-31' !== $on && $on <= $day ? ( $live ? (array) $live['rows'] : $rows ) : array();
	}
	$out = array();
	foreach ( $rows as $r ) {
		$kind = strtolower( trim( isset( $r['kind'] ) ? (string) $r['kind'] : '' ) );
		$aud  = strtolower( trim( isset( $r['audience'] ) ? (string) $r['audience'] : '' ) );
		if ( ! in_array( $kind, array( 'worship', 'council', 'communion' ), true ) || ! in_array( $aud, array( 'all', 'everyone', 'conference', '' ), true ) ) {
			continue;
		}
		$i = ogc_lst_day_index( $days, isset( $r['day'] ) ? $r['day'] : '' );
		if ( $i < 0 ) {
			continue;
		}
		$a = ogc_lst_min( isset( $r['start'] ) ? $r['start'] : '' );
		$b = ogc_lst_min( isset( $r['end'] ) ? $r['end'] : '' );
		$out[ $days[ $i ]['date'] ][] = array(
			'id'    => isset( $r['_id'] ) ? (string) $r['_id'] : '',
			'date'  => $days[ $i ]['date'],
			'title' => (string) $r['title'],
			'when'  => ogc_lst_when( $r ),
			'start' => $a,
			'end'   => $b,
			'kind'  => ucfirst( $kind ),
			'for'   => in_array( $aud, array( 'all', 'everyone', '' ), true ) ? 'Everyone' : 'Conference',
			'place' => ogc_lst_place_name( $year, isset( $r['place'] ) ? $r['place'] : '' ),
			'call_in' => ogc_lst_yes( isset( $r['call_in'] ) ? $r['call_in'] : '' ),
		);
	}
	ksort( $out );
	foreach ( $out as &$list ) {
		usort( $list, function ( $x, $y ) { return ( null === $x['start'] ? 9999 : $x['start'] ) - ( null === $y['start'] ? 9999 : $y['start'] ); } );
	}
	unset( $list );
	return $out;
}

/** A day's services in words: "2 · 10:00 AM – 4:00 PM", or "From 2:00 PM · No end" when the last has none. */
function ogc_lst_services_span( $list ) {
	if ( ! $list ) {
		return '';
	}
	$first = null;
	$lastn = null;
	$open  = false;
	foreach ( $list as $s ) {
		if ( null !== $s['start'] && ( null === $first || $s['start'] < $first ) ) {
			$first = $s['start'];
		}
		if ( null === $s['end'] ) {
			$open = true;
		} elseif ( null === $lastn || $s['end'] > $lastn ) {
			$lastn = $s['end'];
		}
	}
	$end = $open || null === $lastn ? 'No end' : ogc_lst_hm( $lastn );
	return ( null === $first ? '' : ogc_lst_hm( $first ) ) . ( $open ? ' · No end' : ' – ' . $end );
}

/** Ushers' Services, as the screen and its Work row say it (one function). */
function ogc_lst_services_view( $year ) {
	$by    = ogc_lst_services( $year, true );
	$n     = 0;
	foreach ( $by as $list ) {
		$n += count( $list );
	}
	$dates = array_keys( $by );
	$s     = function_exists( 'ogc_coa_kv' ) ? ogc_coa_kv( (int) $year, 'settings' ) : array();
	$on    = isset( $s['schedule_posted'] ) ? (string) $s['schedule_posted'] : '';
	$line  = $n ? ogc_lst_n( $n, 'service' ) . ' · ' . ogc_lst_dmd( $dates[0] ) . ( count( $dates ) > 1 ? ' – ' . ogc_lst_dmd( end( $dates ) ) : '' ) : 'Schedule not public';
	$days  = array();
	foreach ( $by as $date => $list ) {
		$days[] = array( 'date' => $date, 'n' => count( $list ), 'span' => ogc_lst_services_span( $list ), 'rows' => $list );
	}
	return array( 'public' => (bool) $n, 'posted' => preg_match( '/^\d{4}-\d{2}-\d{2}$/', $on ) && '9999-12-31' !== $on ? $on : '', 'n' => $n, 'days' => $days, 'fact' => array( 'line' => $line, 'head' => $line, 'n' => $n ) );
}

/* ================================================================== the app: Services, and the lines */

add_filter( 'ogc_app_screens', function ( $s, $year ) {
	// Ushers' Services (area-committee-lists 9): the week's services, read only. Schedule (read) for every
	// committee isn't built yet (coa-year), so Ushers get their own read-only list of exactly those rows.
	$s['services'] = array( 'title' => 'Services', 'section' => 'own', 'who' => array( 'ushers' ), 'handable' => false, 'coa_opens' => true, 'icon' => 'clock' );
	return $s;
}, 21, 2 );

add_action( 'rest_api_init', function () {
	register_rest_route( OGC_NS, '/app/(?P<year>\d{4})/services', array(
		'methods'             => 'GET',
		'callback'            => function ( WP_REST_Request $req ) {
			return rest_ensure_response( ogc_lst_services_view( (int) $req['year'] ) );
		},
		'permission_callback' => function ( WP_REST_Request $req ) {
			return function_exists( 'ogc_appc_can' ) ? ogc_appc_can( $req, 'services' ) : ogc_rest_denied();
		},
	) );
} );

// The Work rows' lines are the lists' own facts (README rule 10). Runs before the older lines
// (module-lists-more.php) and answers for every list it knows.
add_filter( 'ogc_appc_work_line', function ( $line, $y, $id, $c ) {
	if ( '' !== $line ) {
		return $line;
	}
	$map = array( 'food-meals' => 'meals', 'preteens-list' => 'preteens', 'communion-list' => 'communion', 'nursery-list' => 'nursery', 'yf-halls' => 'halls' );
	if ( isset( $map[ $id ] ) ) {
		return ogc_lst_fact( (int) $y, $map[ $id ] )['line'];
	}
	if ( 'services' === $id ) {
		return ogc_lst_services_view( (int) $y )['fact']['line'];
	}
	return $line;
}, 5, 4 );
