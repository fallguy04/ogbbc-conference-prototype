<?php
/**
 * People's data after the Conference, and a person's own "send me / remove me" (review, Oct 11).
 *
 *   clearing   when the lists clear a year's names (module-lists.php, clear_after_days after the
 *              Conference: ogc_year_people_cleared), this clears what the lists' pass left: records
 *              removed or cancelled before (gone for good, with their links), what Reuse doesn't need
 *              (a Youngfolk's roommate, the rooms chosen, walker and ground-floor asks, who communed),
 *              the year's state that holds people (Lodging's rooms, the COA's phone list, heads'
 *              messages) and the year's queued and sent volunteer emails.
 *   daily      sent volunteer emails older than 30 days, and links to records that are gone.
 *   privacy    WordPress's Tools › Export / Erase Personal Data find a person's sign-ups by email.
 *
 * Kept on purpose (Nov 6 security plan, for the Advisors): a registration's household email, names and
 * ages (Reuse next year: everyone a year older), the counts each list keeps, the change log (no
 * personal data by its rule), and the WordPress user of someone who signed in.
 *
 * Oct 13 (decision 24, opt-in): Reuse is offered only to a household that ticked "Save for next year"
 * (module-registration-routes.php ogc_reg_kept). The clearing still keeps every household's names and
 * ages, ticked or not: clearing the others is a change that can't be undone, so it waits for the
 * Advisors (decisions 24 and 27, NOTES/security-plan.md). A privacy request (Tools › Export or Erase
 * Personal Data) is logged with who ran it (privacy_export, privacy_erase).
 */

defined( 'ABSPATH' ) || exit;

add_action( 'ogc_year_people_cleared', 'ogc_priv_clear_year', 20 );

function ogc_priv_clear_year( $year ) {
	global $wpdb;
	$year = (int) $year;
	$rt   = ogc_table( 'records' );
	// Removed and cancelled records of the year: gone for good, with what pointed at them.
	$gone = array_map( 'intval', (array) $wpdb->get_col( $wpdb->prepare( "SELECT id FROM $rt WHERE year = %d AND deleted_at IS NOT NULL", $year ) ) );
	if ( $gone ) {
		$in = implode( ',', $gone );
		$wpdb->query( "DELETE FROM $rt WHERE id IN ($in)" ); // phpcs:ignore -- integers.
		$wpdb->query( 'DELETE FROM ' . ogc_table( 'record_links' ) . " WHERE record_id IN ($in)" ); // phpcs:ignore -- integers.
		$wpdb->query( 'DELETE FROM ' . ogc_table( 'devices' ) . " WHERE record_id IN ($in)" ); // phpcs:ignore -- integers.
	}
	// What Reuse doesn't need from a registration.
	foreach ( ogc_records( $year, 'registrations' ) as $r ) {
		$d = $r['data'];
		foreach ( isset( $d['people'] ) ? (array) $d['people'] : array() as $i => $p ) {
			if ( is_array( $p ) ) {
				$d['people'][ $i ]['rooming']   = '';
				$d['people'][ $i ]['communing'] = false;
				unset( $d['people'][ $i ]['room'] );
			}
		}
		if ( isset( $d['stay'] ) && is_array( $d['stay'] ) ) {
			foreach ( array( 'chosen', 'walker', 'ground', 'near', 'nearW', 'nearM', 'nearWho' ) as $k ) {
				unset( $d['stay'][ $k ] );
			}
		}
		unset( $d['approval'], $d['history'] );
		ogc_record_update( $r['id'], $d, $r['email'] );
	}
	// The year's values that hold people.
	$st = ogc_table( 'state' );
	$wpdb->query( $wpdb->prepare( "DELETE FROM $st WHERE year = %d AND skey IN ('rooms','app-phones','vol-msgs','vol-notify','vol-opened-sent')", $year ) ); // phpcs:ignore -- table name.
	ogc_store_forget();
	// The year's volunteer emails, queued or sent (they carry names, phones and heads' messages).
	$wpdb->query( $wpdb->prepare( 'DELETE FROM ' . ogc_table( 'vol_outbox' ) . ' WHERE year = %d', $year ) ); // phpcs:ignore -- table name.
	ogc_priv_tidy_links();
	ogc_log( 'people_cleared_more', $year, 'privacy', array( 'gone' => count( $gone ) ) );
}

/** Links (a helper's, a device's) to records that are gone. */
function ogc_priv_tidy_links() {
	global $wpdb;
	$rt = ogc_table( 'records' );
	foreach ( array( 'record_links', 'devices' ) as $t ) {
		$wpdb->query( 'DELETE FROM ' . ogc_table( $t ) . " WHERE record_id > 0 AND record_id NOT IN (SELECT id FROM $rt)" ); // phpcs:ignore -- table names.
	}
}

// Once a day: sent volunteer emails are kept 30 days (a head may ask what went), then go.
add_action( 'ogc_daily', function () {
	global $wpdb;
	$wpdb->query( $wpdb->prepare( 'DELETE FROM ' . ogc_table( 'vol_outbox' ) . ' WHERE sent_at IS NOT NULL AND sent_at < %s', gmdate( 'Y-m-d H:i:s', time() - 30 * DAY_IN_SECONDS ) ) ); // phpcs:ignore -- table name.
	ogc_priv_tidy_links();
} );

/* ================================================================== export and erase, by email */

add_filter( 'wp_privacy_personal_data_exporters', function ( $e ) {
	$e['ogc-conference'] = array( 'exporter_friendly_name' => 'Annual Conference sign-ups', 'callback' => 'ogc_priv_export' );
	return $e;
} );
add_filter( 'wp_privacy_personal_data_erasers', function ( $e ) {
	$e['ogc-conference'] = array( 'eraser_friendly_name' => 'Annual Conference sign-ups', 'callback' => 'ogc_priv_erase' );
	return $e;
} );

/** Everything kept under an email (registrations, shifts, teams, waits, credits), a page at a time. */
function ogc_priv_export( $email, $page = 1 ) {
	global $wpdb;
	$email = strtolower( trim( (string) $email ) );
	$per   = 50;
	$rows  = (array) $wpdb->get_results( $wpdb->prepare( 'SELECT id, year, kind, data, created_at FROM ' . ogc_table( 'records' ) . ' WHERE email = %s ORDER BY id LIMIT %d OFFSET %d', $email, $per, ( max( 1, (int) $page ) - 1 ) * $per ), ARRAY_A );
	// A privacy request is the one way outside See as that someone at the site reads a person's records:
	// logged with who ran it (the log's user), never the address (decision 25; docs/scope/08).
	if ( 1 === max( 1, (int) $page ) ) {
		ogc_log( 'privacy_export', 0, 'records', array( 'n' => count( $rows ) ) );
	}
	$out   = array();
	foreach ( $rows as $r ) {
		$out[] = array(
			'group_id'    => 'ogc-conference',
			'group_label' => 'Annual Conference',
			'item_id'     => 'ogc-record-' . $r['id'],
			'data'        => array(
				array( 'name' => 'Conference', 'value' => (string) $r['year'] ),
				array( 'name' => 'What', 'value' => (string) $r['kind'] ),
				array( 'name' => 'Made', 'value' => (string) $r['created_at'] ),
				array( 'name' => 'Details', 'value' => wp_json_encode( ogc_unjson( $r['data'], array() ) ) ),
			),
		);
	}
	return array( 'data' => $out, 'done' => count( $rows ) < $per );
}

/** Remove what's kept under an email: shifts, waits, teams and credit asks go; a registration keeps only
 * its number and status (the treasurer's ledger points at it), with no names or contacts. */
function ogc_priv_erase( $email, $page = 1 ) {
	global $wpdb;
	$email    = strtolower( trim( (string) $email ) );
	$rt       = ogc_table( 'records' );
	$rows     = (array) $wpdb->get_results( $wpdb->prepare( "SELECT id, year, kind, data FROM $rt WHERE email = %s", $email ), ARRAY_A );
	$removed  = false;
	$retained = false;
	$years    = array();
	foreach ( $rows as $r ) {
		$years[ (int) $r['year'] ] = true;
		if ( 'registrations' === $r['kind'] ) {
			$d = ogc_unjson( $r['data'], array() );
			ogc_record_update( (int) $r['id'], array( 'rid' => isset( $d['rid'] ) ? $d['rid'] : '', 'status' => isset( $d['status'] ) ? $d['status'] : '', 'erased' => ogc_now() ), '' );
			$retained = true;
		} else {
			$wpdb->delete( $rt, array( 'id' => (int) $r['id'] ), array( '%d' ) );
		}
		$removed = true;
	}
	$wpdb->delete( ogc_table( 'record_links' ), array( 'email' => $email ), array( '%s' ) );
	ogc_priv_tidy_links();
	foreach ( array_keys( $years ) as $y ) {
		if ( function_exists( 'ogc_vol_seats_tidy' ) ) {
			ogc_vol_seats_tidy( $y );
		}
	}
	$wpdb->query( $wpdb->prepare( 'DELETE FROM ' . ogc_table( 'vol_outbox' ) . ' WHERE email = %s', $email ) ); // phpcs:ignore -- table name.
	ogc_log( 'privacy_erase', 0, 'records', array( 'n' => count( $rows ) ) );
	return array(
		'items_removed'  => $removed,
		'items_retained' => $retained,
		'messages'       => $retained ? array( 'A registration keeps its number and status for the treasurer’s ledger, with no names or contacts.' ) : array(),
		'done'           => true,
	);
}
