<?php
/**
 * The ledger as the treasurer works it (night-records, Oct 13; docs/scope/02 flow E and Q, records 5–6).
 *
 * Only people the COA ticked "Handles money" on Members (ogc_money_is_handler, module-records.php) see
 * a payment line or change one. The rest of the COA gets the year's totals and no names.
 *
 *   GET  app/{y}/ledger                 totals (anyone who may open Money); for a handler also every line,
 *                                       each household's money, the deposits (?format=csv: every line)
 *   POST app/{y}/ledger/received        {lines[], day?, ref?, cents?, paid_by?}  checks to come, received
 *                                       (one or many; one may carry its amount and number)
 *   POST app/{y}/ledger/check           {ref, cents, paid_by, day, parts: [{record, cents}]}  one check for
 *                                       several households: the parts must add up to the check
 *   POST app/{y}/ledger/add             {record, how: check|cash|card, cents, ref?, day?}  money taken
 *                                       without a line waiting for it (a check that came unannounced, the desk)
 *   POST app/{y}/ledger/refund          {lines[], action: approve|send|decline, ref?, day?}
 *   POST app/{y}/ledger/refund/ask      {record, cents, note}  a refund of what was paid over the total
 *   POST app/{y}/ledger/mark            {line, action: returned|disputed}  a check bounced, a card disputed
 *   POST app/{y}/ledger/edit            {line, ref?, note?, paid_by?}  the check number typed later
 *   POST app/{y}/ledger/remind          {line, preview?}  a check that hasn't come: a short email, once a week
 *   POST app/{y}/ledger/deposits        {lines[], day, kind?, bank?}  a bank deposit (or a card payout)
 *   PATCH/DELETE app/{y}/ledger/deposits/{id}   its bank figure and day; remove (its lines are free again)
 *   POST app/{y}/ledger/undo            {token}  the last action as it was (24 hours)
 *
 * Every change: the line only moves from the state the treasurer saw (two people can't both mark one
 * check), the registration's money is worked out again and its History gets a line, and the action is
 * logged without names or amounts' owners. The site never sends money: a refund is sent in the payment
 * company's dashboard or by check, and its number typed here (docs/scope/02 Q67, as recommended).
 */

defined( 'ABSPATH' ) || exit;

/* ================================================================== lines and words */

/** A ledger line as the screens draw it. */
function ogc_ledger_line( $p, $ctx ) {
	$created = function_exists( 'ogc_pay_day' ) ? ogc_pay_day( $p['created_at'], $p['year'] ) : substr( (string) $p['created_at'], 0, 10 );
	$moved   = function_exists( 'ogc_pay_day' ) ? ogc_pay_day( $p['updated_at'], $p['year'] ) : substr( (string) $p['updated_at'], 0, 10 );
	$open    = ( 'check' === $p['kind'] && 'pending' === $p['status'] ) || ( 'refund' === $p['kind'] && in_array( $p['status'], array( 'requested', 'approved' ), true ) ) || ( 'charge' === $p['kind'] && 'pending' === $p['status'] );
	$day     = '' !== $p['day'] ? $p['day'] : ( $open ? $created : $moved );
	return array(
		'id'       => (int) $p['id'],
		'record'   => (int) $p['record_id'],
		'rid'      => (string) $p['rid'],
		'kind'     => $p['kind'],
		'method'   => $p['method'],
		'kind_w'   => ogc_pay_kind_words( $p ),
		'cents'    => (int) $p['cents'],
		'status'   => $p['status'],
		'status_w' => ogc_pay_status_words( $p ),
		'day'      => $day,
		'created'  => $created,
		'ref'      => preg_replace( '/^Check\s+/i', '', (string) $p['ref'] ),
		'paid_by'  => (string) $p['paid_by'],
		'grp'      => (string) $p['grp'],
		'deposit'  => (int) $p['deposit_id'],
		'fee'      => (int) $p['fee'],
		'note'     => (string) $p['note'],
		'by'       => function_exists( 'ogc_rec_who' ) ? ogc_rec_who( $p['by_user'] ) : '',
		'waiting'  => 'check' === $p['kind'] && 'pending' === $p['status'] && $created ? max( 0, (int) round( ( strtotime( $ctx['today'] . ' 12:00 UTC' ) - strtotime( $created . ' 12:00 UTC' ) ) / DAY_IN_SECONDS ) ) : 0,
		'late'     => 'check' === $p['kind'] && 'pending' === $p['status'] && ! empty( $ctx['closed'] ),
		'sample'   => (bool) $p['sample'],
	);
}

function ogc_ledger_money( $c ) {
	return function_exists( 'ogc_reg_money' ) ? ogc_reg_money( $c ) : '$' . number_format( $c / 100, 2 );
}

/** One value from the request ('' for a list or an object where one value belongs). */
function ogc_ledger_s( $req, $key ) {
	$v = $req->get_param( $key );
	return is_scalar( $v ) ? (string) $v : '';
}

function ogc_ledger_err( $msg, $status = 400, $extra = array() ) {
	return new WP_Error( 'ogc_ledger', $msg, array_merge( array( 'status' => $status, 'message' => $msg ), $extra ) );
}

/** The day a treasurer gave ("2027-03-15"), never after today; else today. */
function ogc_ledger_day( $req, $ctx ) {
	$d = ogc_ledger_s( $req, 'day' );
	return preg_match( '/^\d{4}-\d\d-\d\d$/', $d ) && checkdate( (int) substr( $d, 5, 2 ), (int) substr( $d, 8, 2 ), (int) substr( $d, 0, 4 ) ) && $d <= $ctx['today'] ? $d : $ctx['today'];
}

/** Dollars or cents from the page: whole cents, 1 cent to $20,000. */
function ogc_ledger_cents( $v ) {
	$c = is_numeric( $v ) ? (int) round( (float) $v ) : 0;
	return $c > 0 && $c <= 2000000 ? $c : 0;
}

function ogc_ledger_ref( $v ) {
	return mb_substr( sanitize_text_field( (string) $v ), 0, 40 );
}

/** A line of this year's ledger whose registration this request may count, or null. */
function ogc_ledger_get( $year, $id ) {
	$p = function_exists( 'ogc_pay_get' ) ? ogc_pay_get( (int) $id ) : null;
	if ( ! $p || (int) $p['year'] !== (int) $year ) {
		return null;
	}
	$rec = ogc_record_get( (int) $p['record_id'] );
	return $rec && 'registrations' === $rec['kind'] && (int) $rec['year'] === (int) $year ? $p : null;
}

/** A registration of this year by its record id, or null. */
function ogc_ledger_reg( $year, $id ) {
	$rec = ogc_record_get( (int) $id );
	return $rec && 'registrations' === $rec['kind'] && (int) $rec['year'] === (int) $year ? $rec : null;
}

/* ================================================================== an action, kept so it can be undone */

/**
 * An action in progress: the lines as they were before it touched them, the lines and deposit it added,
 * and the registrations whose money and History change. ogc_ledger_done() saves the registrations and
 * keeps the undo (state ledger_undo, the last 300, 24 hours).
 */
function ogc_ledger_begin( $year, $say ) {
	// word: the act's plain History word (no amounts, numbers or payers: docs/26 #25); day: the day it
	// happened (the Received or Sent date typed), which History is stamped with; mail: record id => the
	// lines that became money in, for the receipt sent once Undo has had its time.
	return array( 'y' => (int) $year, 'say' => $say, 'word' => '', 'day' => '', 'before' => array(), 'added' => array(), 'dep' => array(), 'recs' => array(), 'notes' => array(), 'mail' => array() );
}

/**
 * The plain words a money act leaves in a household's History, one fixed list. Everyone who may open the
 * household reads History (the COA, Lodging's data), so the amounts, check numbers, who paid and a
 * returned check stay on the payment lines, which only Handles money sees.
 */
function ogc_ledger_words() {
	return array(
		'paid'     => 'Payment recorded',
		'changed'  => 'Payment changed',
		'asked'    => 'Refund asked',
		'approve'  => 'Refund approved',
		'send'     => 'Refund sent',
		'decline'  => 'Refund declined',
	);
}

/** A History line for a money act, stamped with the day it happened (not the server's clock). */
function ogc_ledger_hist( &$data, $what, $year, $day = '' ) {
	$h               = isset( $data['history'] ) && is_array( $data['history'] ) ? $data['history'] : array();
	$h[]             = array( 'at' => function_exists( 'ogc_rec_stamp' ) ? ogc_rec_stamp( $year, $day ) : ogc_now(), 'what' => (string) $what, 'by' => 'committee' );
	$data['history'] = array_slice( $h, -50 );
}

function ogc_ledger_snap( &$act, $p ) {
	if ( ! isset( $act['before'][ $p['id'] ] ) ) {
		$act['before'][ $p['id'] ] = array_intersect_key( $p, array_flip( ogc_pay_fields() ) );
	}
	$act['recs'][ (int) $p['record_id'] ] = true;
}

/** A household's History gets the act's plain word (one per act, however many lines it touched). */
function ogc_ledger_note( &$act, $record_id, $what = '' ) {
	$act['recs'][ (int) $record_id ] = true;
	$act['notes'][ (int) $record_id ][] = '' !== $what ? $what : $act['word'];
}

function ogc_ledger_done( $act, $log ) {
	$token = 'u' . strtolower( wp_generate_password( 12, false, false ) );
	foreach ( array_keys( $act['recs'] ) as $rid ) {
		$rec = ogc_record_get( $rid );
		if ( ! $rec ) {
			continue;
		}
		$data = $rec['data'];
		foreach ( isset( $act['notes'][ $rid ] ) ? array_unique( $act['notes'][ $rid ] ) : array() as $what ) {
			ogc_ledger_hist( $data, $what, $act['y'], $act['day'] );
		}
		ogc_reg_save( $rec, $data );
	}
	// Money received: the household's receipt, as when a card is paid, but not at once: it waits out
	// Undo's time, and an undone act's receipt never goes (ogc_ledger_receipts_*). Never for a sample.
	if ( $act['mail'] ) {
		ogc_ledger_receipts_add( $act['y'], $act['mail'], $token );
	}
	// Every line as the act left it, so a later Undo can tell whether anything has changed since.
	$after = array();
	foreach ( array_merge( array_keys( $act['before'] ), $act['added'] ) as $id ) {
		$p                   = ogc_pay_get( (int) $id );
		$after[ (int) $id ] = $p ? array_intersect_key( $p, array_flip( ogc_pay_fields() ) ) : null;
	}
	$keep  = array( 't' => $token, 'at' => ogc_now(), 'uid' => get_current_user_id(), 'say' => $act['say'], 'word' => $act['word'], 'before' => $act['before'], 'after' => $after, 'added' => $act['added'], 'dep' => $act['dep'], 'recs' => array_keys( $act['recs'] ) );
	$cur   = ogc_state_get( $act['y'], 'ledger_undo' );
	$list  = $cur && is_array( $cur['value'] ) ? $cur['value'] : array();
	$list[] = $keep;
	ogc_state_put( $act['y'], 'ledger_undo', array_slice( $list, -300 ) );
	ogc_log( 'ledger_' . $log, $act['y'], 'payments', array( 'lines' => array_keys( $act['before'] ), 'added' => $act['added'] ) );
	if ( function_exists( 'ogc_rec_forget' ) ) {
		ogc_rec_forget( $act['y'] );
	}
	return array( 'ok' => true, 'say' => $act['say'], 'undo' => $token );
}

/* ================================================================== receipts, after Undo's time */

/** How long a receipt waits (seconds): Undo's time, so a wrong tick never tells a family it has paid. */
function ogc_ledger_receipt_wait() {
	return max( 0, (int) apply_filters( 'ogc_ledger_receipt_wait', 10 * MINUTE_IN_SECONDS ) );
}

/**
 * Hold the receipts of an act: state ledger_receipts {record id: {after, acts: {token: [line ids]}}}.
 * Two acts on one household within the wait are one receipt (it goes once, saying where things stand).
 */
function ogc_ledger_receipts_add( $year, $mail, $token ) {
	if ( ! function_exists( 'ogc_reg_mail_receipt' ) || ! apply_filters( 'ogc_ledger_receipts', true, $year ) ) {
		return;
	}
	$after = time() + ogc_ledger_receipt_wait();
	$mail  = array_filter( $mail, function ( $lines, $rec ) {
		$r = ogc_record_get( (int) $rec );
		return $r && empty( $r['sample'] );   // a sample never gets a receipt
	}, ARRAY_FILTER_USE_BOTH );
	if ( ! $mail ) {
		return;
	}
	for ( $try = 0; $try < 3; $try++ ) {
		$cur  = ogc_state_get( $year, 'ledger_receipts' );
		$list = $cur && is_array( $cur['value'] ) ? $cur['value'] : array();
		foreach ( $mail as $rec => $lines ) {
			$k                     = (string) (int) $rec;
			$e                     = isset( $list[ $k ] ) && is_array( $list[ $k ] ) ? $list[ $k ] : array( 'acts' => array() );
			$e['after']            = $after;
			$e['acts'][ $token ]   = array_values( array_unique( array_map( 'intval', (array) $lines ) ) );
			$list[ $k ]            = $e;
		}
		if ( ! is_wp_error( ogc_state_put( $year, 'ledger_receipts', (object) $list, $cur ? $cur['version'] : null ) ) ) {
			break;
		}
	}
	wp_schedule_single_event( $after + 5, 'ogc_ledger_receipts_send', array( (int) $year ) );
	$ys = array_map( 'intval', (array) get_option( 'ogc_ledger_receipt_years', array() ) );
	if ( ! in_array( (int) $year, $ys, true ) ) {
		$ys[] = (int) $year;
		update_option( 'ogc_ledger_receipt_years', $ys, false );
	}
}

/** Undo: that act's receipts don't go (another act on the same household still sends its own). */
function ogc_ledger_receipts_drop( $year, $token ) {
	for ( $try = 0; $try < 3; $try++ ) {
		$cur = ogc_state_get( $year, 'ledger_receipts' );
		if ( ! $cur || ! is_array( $cur['value'] ) ) {
			return;
		}
		$list = $cur['value'];
		$hit  = false;
		foreach ( $list as $k => $e ) {
			if ( isset( $e['acts'][ $token ] ) ) {
				unset( $list[ $k ]['acts'][ $token ] );
				$hit = true;
				if ( empty( $list[ $k ]['acts'] ) ) {
					unset( $list[ $k ] );
				}
			}
		}
		if ( ! $hit || ! is_wp_error( ogc_state_put( $year, 'ledger_receipts', (object) $list, $cur['version'] ) ) ) {
			return;
		}
	}
}

/**
 * Send the receipts whose wait is over ($force: all of them; tests). Each is taken off the list first
 * (against the version read), so two requests can't both send it; it goes only while one of its lines is
 * still money in (a check returned in the meantime sends nothing). Runs on its own scheduled event, on
 * the five-minute tick, and whenever Money or Households is opened (locally WP-Cron may not fire).
 */
function ogc_ledger_receipts_due( $year, $force = false ) {
	$cur = ogc_state_get( (int) $year, 'ledger_receipts' );
	if ( ! $cur || empty( $cur['value'] ) || ! is_array( $cur['value'] ) || ! function_exists( 'ogc_reg_mail_receipt' ) ) {
		return 0;
	}
	$list = $cur['value'];
	$due  = array();
	foreach ( $list as $k => $e ) {
		if ( $force || (int) ( isset( $e['after'] ) ? $e['after'] : 0 ) <= time() ) {
			$due[ $k ] = $e;
		}
	}
	if ( ! $due || is_wp_error( ogc_state_put( (int) $year, 'ledger_receipts', (object) array_diff_key( $list, $due ), $cur['version'] ) ) ) {
		return 0;
	}
	$sent = 0;
	foreach ( $due as $k => $e ) {
		$rec = ogc_record_get( (int) $k );
		if ( ! $rec || 'registrations' !== $rec['kind'] || (int) $rec['year'] !== (int) $year || ! empty( $rec['sample'] ) ) {
			continue;
		}
		$still = false;
		foreach ( (array) ( isset( $e['acts'] ) ? $e['acts'] : array() ) as $lines ) {
			foreach ( (array) $lines as $id ) {
				$p     = ogc_pay_get( (int) $id );
				$still = $still || ( $p && (int) $p['record_id'] === (int) $k && 'paid' === $p['status'] );
			}
		}
		if ( $still && apply_filters( 'ogc_ledger_receipts', true, (int) $year ) ) {
			ogc_reg_mail_receipt( $rec, 'paid' );
			$sent++;
		}
	}
	return $sent;
}

// The scheduled event's own name (the filter ogc_ledger_receipts turns receipts off).
add_action( 'ogc_ledger_receipts_send', function ( $year ) {
	ogc_ledger_receipts_due( (int) $year );
} );
add_action( 'ogc_vol_tick', function () {
	foreach ( (array) get_option( 'ogc_ledger_receipt_years', array() ) as $y ) {
		if ( (int) $y > 2000 ) {
			ogc_ledger_receipts_due( (int) $y );
		}
	}
}, 40 );

/* ================================================================== the same check twice */

/**
 * A check already received this year with exactly this number and this amount (one line, or one
 * check's lines added up), or null: a reload or two people entering one envelope. An exact match on what
 * was typed, said to the treasurer, who may save again (two families' checks can share a number).
 */
function ogc_ledger_dup( $year, $ref, $cents ) {
	$ref = trim( preg_replace( '/^(Check\s+|No\.\s*|#)/i', '', (string) $ref ) );
	if ( '' === $ref || $cents <= 0 ) {
		return null;
	}
	$groups = array();
	foreach ( ogc_pay_year( (int) $year ) as $p ) {
		$check = 'check' === $p['kind'] || ( 'desk' === $p['kind'] && 'check' === $p['method'] );
		if ( ! $check || ! in_array( $p['status'], array( 'paid', 'returned' ), true ) ) {
			continue;
		}
		if ( 0 !== strcasecmp( trim( preg_replace( '/^(Check\s+|No\.\s*|#)/i', '', (string) $p['ref'] ) ), $ref ) ) {
			continue;
		}
		$g = '' !== $p['grp'] ? $p['grp'] : 'l' . $p['id'];
		if ( ! isset( $groups[ $g ] ) ) {
			$groups[ $g ] = array( 'cents' => 0, 'p' => $p );
		}
		$groups[ $g ]['cents'] += (int) $p['cents'];
	}
	foreach ( $groups as $g ) {
		if ( (int) $g['cents'] === (int) $cents ) {
			$p   = $g['p'];
			$rec = ogc_record_get( (int) $p['record_id'] );
			$who = '' !== $p['paid_by'] ? $p['paid_by'] : ( $rec ? ogc_rec_label( $rec['data'] ) : '' );
			$day = '' !== $p['day'] ? $p['day'] : ogc_pay_day( $p['updated_at'], (int) $year );
			return array( 'words' => 'No. ' . $ref . ' already received · ' . ( function_exists( 'ogc_app_md' ) ? ogc_app_md( $day, (int) $year ) : $day ) . ( '' !== $who ? ' · ' . $who : '' ) . ' · Save again to keep both' );
		}
	}
	return null;
}

/* ================================================================== routes */

add_action( 'rest_api_init', function () {
	$Y    = '(?P<year>\d{4})';
	$gate = function ( $write, $money ) {
		return function ( WP_REST_Request $req ) use ( $write, $money ) {
			if ( ! function_exists( 'ogc_app_req_viewer' ) || ! function_exists( 'ogc_pay_year' ) || ! ogc_app_tables_ready() || null === ogc_year_get( (int) $req['year'] ) ) {
				return new WP_Error( 'ogc_not_found', 'Not found.', array( 'status' => 404 ) );
			}
			$v = ogc_app_req_viewer( $req );
			if ( ! ogc_app_can_see( $v, 'money' ) ) {
				return ogc_rest_denied();
			}
			if ( $write && $v['as'] ) {
				return new WP_Error( 'ogc_read_only', 'Read only while seeing as', array( 'status' => 403 ) );
			}
			if ( $money && ! ogc_money_is_handler( (int) $req['year'], $req ) ) {
				return new WP_Error( 'ogc_money_only', 'Handles money only', array( 'status' => 403 ) );
			}
			return true;
		};
	};
	$routes = array(
		'ledger'            => array( 'GET', 'ogc_ledger_rest_get', $gate( false, false ) ),
		'ledger/received'   => array( 'POST', 'ogc_ledger_rest_received', $gate( true, true ) ),
		'ledger/check'      => array( 'POST', 'ogc_ledger_rest_check', $gate( true, true ) ),
		'ledger/add'        => array( 'POST', 'ogc_ledger_rest_add', $gate( true, true ) ),
		'ledger/refund'     => array( 'POST', 'ogc_ledger_rest_refund', $gate( true, true ) ),
		'ledger/refund/ask' => array( 'POST', 'ogc_ledger_rest_refund_ask', $gate( true, true ) ),
		'ledger/mark'       => array( 'POST', 'ogc_ledger_rest_mark', $gate( true, true ) ),
		'ledger/edit'       => array( 'POST', 'ogc_ledger_rest_edit', $gate( true, true ) ),
		'ledger/remind'     => array( 'POST', 'ogc_ledger_rest_remind', $gate( true, true ) ),
		'ledger/deposits'   => array( 'POST', 'ogc_ledger_rest_deposit_add', $gate( true, true ) ),
		'ledger/undo'       => array( 'POST', 'ogc_ledger_rest_undo', $gate( true, true ) ),
	);
	foreach ( $routes as $path => $r ) {
		register_rest_route( OGC_NS, "/app/$Y/$path", array( array( 'methods' => $r[0], 'callback' => $r[1], 'permission_callback' => $r[2] ) ) );
	}
	register_rest_route( OGC_NS, "/app/$Y/ledger/deposits/(?P<id>\d+)", array(
		array( 'methods' => 'PATCH', 'callback' => 'ogc_ledger_rest_deposit_patch', 'permission_callback' => $gate( true, true ) ),
		array( 'methods' => 'DELETE', 'callback' => 'ogc_ledger_rest_deposit_delete', 'permission_callback' => $gate( true, true ) ),
	) );
} );

/* ------------------------------------------------------------------ reading */

/** The year's money in totals (no names): what the COA sees, and the head of the treasurer's screen. */
function ogc_ledger_totals( $year, $rows, $ctx ) {
	$t = array( 'households' => 0, 'form' => 0, 'total' => 0, 'paid' => 0, 'by' => array(), 'card' => 0, 'checks_in' => 0, 'desk' => 0, 'checks' => 0, 'checks_n' => 0, 'checks_late' => 0, 'refunds' => 0, 'refunds_n' => 0, 'refunded' => 0, 'gifts' => 0, 'gifts_n' => 0, 'fees' => 0 );
	foreach ( array_keys( ogc_rec_money_words() ) as $k ) {
		$t['by'][ $k ] = array( 'n' => 0, 'cents' => 0 );
	}
	$alive = array();
	foreach ( $rows as $r ) {
		$alive[ $r['id'] ] = true;
		if ( in_array( $r['status'], array( 'cancelled', 'waitlist' ), true ) && ! in_array( $r['money'], array( 'refund', 'refunded' ), true ) ) {
			continue;
		}
		if ( ! in_array( $r['status'], array( 'cancelled', 'waitlist' ), true ) ) {
			$t['households']++;
		}
		// Paid on the Google Form: counted by its own Money words, but its money is the Form's (no
		// amounts here).
		if ( $r['form'] ) {
			$t['form']++;
			$t['by'][ $r['money'] ]['n']++;
			continue;
		}
		$t['total'] += $r['total'];
		$t['paid']  += $r['paid'];
		$amt = in_array( $r['money'], array( 'due', 'balance', 'checkin' ), true ) ? $r['balance'] : ( 'check' === $r['money'] ? $r['check'] : ( 'refund' === $r['money'] ? $r['refund'] : $r['paid'] ) );
		$t['by'][ $r['money'] ]['n']++;
		$t['by'][ $r['money'] ]['cents'] += $amt;
	}
	foreach ( $ctx['pay'] as $rid => $lines ) {
		if ( ! isset( $alive[ $rid ] ) ) {
			continue;
		}
		foreach ( $lines as $p ) {
			if ( 'paid' === $p['status'] && 'refund' !== $p['kind'] ) {
				$k        = 'charge' === $p['kind'] ? 'card' : ( 'desk' === $p['kind'] ? 'desk' : 'checks_in' );
				$t[ $k ] += $p['cents'];
				$t['fees'] += (int) $p['fee'];
			} elseif ( 'check' === $p['kind'] && 'pending' === $p['status'] ) {
				$t['checks'] += $p['cents'];
				$t['checks_n']++;
				$t['checks_late'] += $ctx['closed'] ? 1 : 0;
			} elseif ( 'refund' === $p['kind'] && in_array( $p['status'], array( 'requested', 'approved' ), true ) ) {
				$t['refunds'] += $p['cents'];
				$t['refunds_n']++;
			} elseif ( 'refund' === $p['kind'] && 'sent' === $p['status'] ) {
				$t['refunded'] += $p['cents'];
			}
		}
	}
	foreach ( ogc_records( (int) $year, 'registrations' ) as $r ) {
		$g = (int) ( isset( $r['data']['price']['gift_cents'] ) ? $r['data']['price']['gift_cents'] : 0 );
		if ( $g && 'cancelled' !== ( isset( $r['data']['status'] ) ? $r['data']['status'] : '' ) ) {
			$t['gifts'] += $g;
			$t['gifts_n']++;
		}
	}
	return $t;
}

/** The names of those who handle money ("Miriam K."), for the line that says who does. */
function ogc_ledger_handler_names( $year ) {
	$out = array();
	foreach ( ogc_money_handlers( $year ) as $e ) {
		$m     = function_exists( 'ogc_member_find' ) ? ogc_member_find( (int) $year, $e ) : null;
		$out[] = $m && ! empty( $m['name'] ) ? ( function_exists( 'ogc_first_l' ) ? ogc_first_l( $m['name'] ) : $m['name'] ) : ( function_exists( 'ogc_mask_email' ) ? ogc_mask_email( $e ) : '' );
	}
	return array_values( array_filter( $out ) );
}

function ogc_ledger_deposit_kinds() {
	return array( 'checks' => 'Checks', 'cash' => 'Desk cash', 'card' => 'Card payout' );
}

/** A year's deposits, each with its lines added up. */
function ogc_ledger_deposits( $year, $ctx ) {
	global $wpdb;
	$rows  = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . ogc_table( 'deposits' ) . ' WHERE year = %d AND removed_at IS NULL ORDER BY day DESC, id DESC', $year ), ARRAY_A );
	$sum   = array();
	foreach ( $ctx['pay'] as $lines ) {
		foreach ( $lines as $p ) {
			if ( $p['deposit_id'] ) {
				$d = (int) $p['deposit_id'];
				if ( ! isset( $sum[ $d ] ) ) {
					$sum[ $d ] = array( 'n' => 0, 'lines' => 0, 'cents' => 0, 'fees' => 0, 'grp' => array() );
				}
				// What the bank saw: one check that paid for three households is one check.
				if ( '' === $p['grp'] || ! isset( $sum[ $d ]['grp'][ $p['grp'] ] ) ) {
					$sum[ $d ]['n']++;
				}
				if ( '' !== $p['grp'] ) {
					$sum[ $d ]['grp'][ $p['grp'] ] = true;
				}
				$sum[ $d ]['lines']++;
				$sum[ $d ]['cents'] += $p['cents'];
				$sum[ $d ]['fees']  += (int) $p['fee'];
			}
		}
	}
	$kinds = ogc_ledger_deposit_kinds();
	$out   = array();
	foreach ( (array) $rows as $r ) {
		$s     = isset( $sum[ (int) $r['id'] ] ) ? $sum[ (int) $r['id'] ] : array( 'n' => 0, 'lines' => 0, 'cents' => 0, 'fees' => 0 );
		$total = $s['cents'] - ( 'card' === $r['kind'] ? $s['fees'] : 0 );
		$bank  = (int) $r['bank_cents'];
		$out[] = array(
			'id'     => (int) $r['id'],
			'day'    => (string) $r['day'],
			'kind'   => (string) $r['kind'],
			'kind_w' => isset( $kinds[ $r['kind'] ] ) ? $kinds[ $r['kind'] ] : (string) $r['kind'],
			'n'      => $s['n'],
			'lines'  => $s['lines'],
			'total'  => $total,
			'bank'   => $bank >= 0 ? $bank : null,
			'off'    => $bank >= 0 ? $bank - $total : 0,
			'note'   => (string) $r['note'],
			'by'     => ogc_rec_who( $r['by_user'] ),
			'sample' => (bool) (int) $r['sample'],
		);
	}
	return $out;
}

/** GET app/{y}/ledger → totals; and for a handler every line, each household's money, the deposits. */
function ogc_ledger_rest_get( WP_REST_Request $req ) {
	$y       = (int) $req['year'];
	ogc_ledger_receipts_due( $y );
	$ctx     = ogc_rec_ctx( $y );
	$rows    = ogc_rec_rows( $y );
	$handler = ogc_money_is_handler( $y, $req );
	$cfg     = $ctx['cfg'];
	$out     = array(
		'handler'    => $handler,
		'can_tick'   => ogc_money_can_tick( $y, $req ),
		'handlers'   => ogc_ledger_handler_names( $y ),
		'today'      => $ctx['today'],
		'check_by'   => $ctx['check_by'],
		'closed'     => $ctx['closed'],
		'payee'      => isset( $cfg['check_payee'] ) ? (string) $cfg['check_payee'] : '',
		'refunds_by' => isset( $cfg['refunds_by'] ) ? (string) $cfg['refunds_by'] : '',
		'gift_for'   => isset( $cfg['gift_for'] ) && 'none' !== $cfg['gift_for'] ? (string) $cfg['gift_for'] : '',
		'totals'     => ogc_ledger_totals( $y, $rows, $ctx ),
		// Minutes a receipt waits after money is marked in (Undo's time).
		'wait'       => (int) ceil( ogc_ledger_receipt_wait() / 60 ),
	);
	if ( ! $handler ) {
		if ( 'csv' === $req->get_param( 'format' ) ) {
			return new WP_Error( 'ogc_money_only', 'Handles money only', array( 'status' => 403 ) );
		}
		return rest_ensure_response( $out );
	}
	$by_rec = array();
	foreach ( $rows as $r ) {
		$by_rec[ $r['id'] ] = $r;
	}
	$lines = array();
	foreach ( $ctx['pay'] as $rid => $ls ) {
		if ( ! isset( $by_rec[ $rid ] ) ) {
			continue;
		}
		foreach ( $ls as $p ) {
			$l          = ogc_ledger_line( $p, $ctx );
			$l['label'] = $by_rec[ $rid ]['label'];
			// A line written before its registration had its number (the seed's own samples): the record's.
			$l['rid']   = '' !== $l['rid'] ? $l['rid'] : $by_rec[ $rid ]['rid'];
			$lines[]    = $l;
		}
	}
	usort( $lines, function ( $a, $b ) { return strcmp( $b['day'], $a['day'] ) ?: $b['id'] - $a['id']; } );
	$deps = ogc_ledger_deposits( $y, $ctx );
	if ( 'csv' === $req->get_param( 'format' ) ) {
		$dw   = array();
		foreach ( $deps as $d ) {
			$dw[ $d['id'] ] = $d['day'] . ' · ' . $d['kind_w'];
		}
		$csv = array();
		foreach ( $lines as $l ) {
			$neg   = 'refund' === $l['kind'];
			$csv[] = array( $l['day'], $l['rid'], $l['label'], $l['kind_w'], $l['status_w'], number_format( ( $neg ? -1 : 1 ) * $l['cents'] / 100, 2, '.', '' ), $l['fee'] ? number_format( $l['fee'] / 100, 2, '.', '' ) : '', $l['ref'], $l['paid_by'], $l['deposit'] && isset( $dw[ $l['deposit'] ] ) ? $dw[ $l['deposit'] ] : '', $l['note'], $l['by'] );
		}
		ogc_log( 'ledger_export', $y, 'payments', array( 'rows' => count( $csv ) ) );
		return ogc_rec_csv_response( ogc_rec_csv( array( 'Date', 'Registration', 'Household', 'Kind', 'Status', 'Amount', 'Fee', 'Reference', 'Paid by', 'Deposit', 'Note', 'By' ), $csv ), 'Payments ' . $y . ' ' . gmdate( 'Y-m-d' ) . '.csv' );
	}
	$hh = array();
	foreach ( $rows as $r ) {
		$hh[] = array_intersect_key( $r, array_flip( array( 'id', 'rid', 'label', 'status', 'status_w', 'money', 'money_w', 'total', 'paid', 'balance', 'refund', 'check', 'form', 'contact', 'phone', 'sample' ) ) );
	}
	$out['lines']      = $lines;
	$out['households'] = $hh;
	$out['deposits']   = $deps;
	$out['kinds']      = ogc_ledger_deposit_kinds();
	return rest_ensure_response( $out );
}

/* ------------------------------------------------------------------ checks */

/**
 * POST ledger/received → checks to come, received. Which ones, any of:
 *   items[]    {line, cents?, ref?}: each its own amount (blank: what was expected) and number
 *   lines[]    each at its expected amount, no number
 *   records[]  ticked households: each one's checks still to come
 *   one line with cents, ref, paid_by as their own fields (the one-check panel)
 * day? (the day received, for all), again? (save though a check with the same number and amount was
 * received already). Less than expected leaves the rest as a check still to come (a second line), the
 * same rule as one check for several households.
 */
function ogc_ledger_rest_received( WP_REST_Request $req ) {
	$y     = (int) $req['year'];
	$ctx   = ogc_rec_ctx( $y );
	$items = array();
	foreach ( array_slice( (array) $req->get_param( 'items' ), 0, 60 ) as $x ) {
		if ( ! is_array( $x ) || ! isset( $x['line'] ) || ! is_scalar( $x['line'] ) ) {
			continue;
		}
		$c = isset( $x['cents'] ) && is_scalar( $x['cents'] ) && '' !== (string) $x['cents'] ? ogc_ledger_cents( $x['cents'] ) : null;
		if ( 0 === $c ) {
			return ogc_ledger_err( 'Enter an amount', 400, array( 'field' => 'cents', 'line' => (int) $x['line'] ) );
		}
		$items[ (int) $x['line'] ] = array( 'cents' => $c, 'ref' => isset( $x['ref'] ) && is_scalar( $x['ref'] ) ? ogc_ledger_ref( $x['ref'] ) : '', 'by' => '' );
	}
	foreach ( array_slice( array_map( 'intval', array_filter( (array) $req->get_param( 'lines' ), 'is_scalar' ) ), 0, 60 ) as $id ) {
		if ( ! isset( $items[ $id ] ) ) {
			$items[ $id ] = array( 'cents' => null, 'ref' => '', 'by' => '' );
		}
	}
	// Households ticked on Households: each one's checks still to come.
	foreach ( array_slice( array_map( 'intval', array_filter( (array) $req->get_param( 'records' ), 'is_scalar' ) ), 0, 60 ) as $rid ) {
		if ( ogc_ledger_reg( $y, $rid ) ) {
			foreach ( ogc_pay_rows( $rid ) as $p ) {
				if ( 'check' === $p['kind'] && 'pending' === $p['status'] && ! isset( $items[ (int) $p['id'] ] ) ) {
					$items[ (int) $p['id'] ] = array( 'cents' => null, 'ref' => '', 'by' => '' );
				}
			}
		}
	}
	$items = array_slice( $items, 0, 60, true );
	if ( ! $items ) {
		return ogc_ledger_err( 'Choose a check' );
	}
	// One line with its fields given on their own (the one-check panel).
	if ( 1 === count( $items ) ) {
		$id  = (int) key( $items );
		$raw = $req->get_param( 'cents' );
		if ( null !== $raw && '' !== $raw ) {
			$c = ogc_ledger_cents( ogc_ledger_s( $req, 'cents' ) );
			if ( ! $c ) {
				return ogc_ledger_err( 'Enter an amount', 400, array( 'field' => 'cents' ) );
			}
			$items[ $id ]['cents'] = $c;
		}
		if ( '' === $items[ $id ]['ref'] ) {
			$items[ $id ]['ref'] = ogc_ledger_ref( ogc_ledger_s( $req, 'ref' ) );
		}
		$items[ $id ]['by'] = mb_substr( sanitize_text_field( ogc_ledger_s( $req, 'paid_by' ) ), 0, 80 );
	}
	$day   = ogc_ledger_day( $req, $ctx );
	$again = rest_sanitize_boolean( $req->get_param( 'again' ) );
	if ( ! $again ) {
		foreach ( $items as $id => $it ) {
			$p   = ogc_ledger_get( $y, $id );
			$dup = $p && '' !== $it['ref'] ? ogc_ledger_dup( $y, $it['ref'], null !== $it['cents'] ? $it['cents'] : $p['cents'] ) : null;
			if ( $dup ) {
				return ogc_ledger_err( $dup['words'], 409, array( 'dup' => true, 'line' => (int) $id ) );
			}
		}
	}
	$act         = ogc_ledger_begin( $y, '' );
	$act['word'] = ogc_ledger_words()['paid'];
	$act['day']  = $day;
	$done        = 0;
	$sum         = 0;
	$last        = '';
	foreach ( $items as $id => $it ) {
		$p = ogc_ledger_get( $y, $id );
		if ( ! $p || 'check' !== $p['kind'] || 'pending' !== $p['status'] ) {
			continue;
		}
		$got = null !== $it['cents'] ? $it['cents'] : $p['cents'];
		ogc_ledger_snap( $act, $p );
		if ( ! ogc_pay_set_if( $p['id'], array( 'status' => 'paid', 'cents' => $got, 'ref' => $it['ref'], 'day' => $day, 'paid_by' => $it['by'] ), 'pending' ) ) {
			unset( $act['before'][ $p['id'] ] );
			continue;
		}
		// Less than expected: the rest is still to come (a second check), as the treasurer can see.
		if ( $got < $p['cents'] ) {
			$new = ogc_pay_add( ogc_record_get( $p['record_id'] ), 'check', 'check', $p['cents'] - $got, 'pending', array( 'note' => 'Rest of check' ) );
			if ( $new ) {
				$act['added'][] = $new;
			}
		}
		ogc_ledger_note( $act, $p['record_id'] );
		$act['mail'][ (int) $p['record_id'] ][] = (int) $p['id'];
		$done++;
		$sum += $got;
		$last = ogc_rec_label( ogc_record_get( $p['record_id'] )['data'] );
	}
	if ( ! $done ) {
		return ogc_ledger_err( 'Already received', 409 );
	}
	$act['say'] = 1 === $done ? $last . ' · Check received · ' . ogc_ledger_money( $sum ) : 'Received · ' . ogc_app_plural( $done, 'check' ) . ' · ' . ogc_ledger_money( $sum );
	return rest_ensure_response( ogc_ledger_done( $act, 'received' ) );
}

/**
 * POST ledger/check {ref, cents, paid_by, day, parts: [{record, cents}], again?} → one check for one or
 * several households (a district's, a family's). Each part becomes that household's received check: a
 * check it had to come is marked received with its part (a part less than it leaves the rest as a check
 * still to come, as Mark received does); a household with none gets a received line. The parts must add
 * up to the check.
 */
function ogc_ledger_rest_check( WP_REST_Request $req ) {
	$y     = (int) $req['year'];
	$ctx   = ogc_rec_ctx( $y );
	$cents = ogc_ledger_cents( ogc_ledger_s( $req, 'cents' ) );
	$ref   = ogc_ledger_ref( ogc_ledger_s( $req, 'ref' ) );
	$by    = mb_substr( sanitize_text_field( ogc_ledger_s( $req, 'paid_by' ) ), 0, 80 );
	$day   = ogc_ledger_day( $req, $ctx );
	$parts = array();
	if ( ! $cents ) {
		return ogc_ledger_err( 'Enter the check’s amount', 400, array( 'field' => 'cents' ) );
	}
	foreach ( array_slice( (array) $req->get_param( 'parts' ), 0, 40 ) as $x ) {
		$rid = is_array( $x ) && isset( $x['record'] ) && is_scalar( $x['record'] ) ? (int) $x['record'] : 0;
		$c   = is_array( $x ) && isset( $x['cents'] ) && is_scalar( $x['cents'] ) ? ogc_ledger_cents( $x['cents'] ) : 0;
		$rec = $rid ? ogc_ledger_reg( $y, $rid ) : null;
		if ( ! $rec ) {
			return ogc_ledger_err( 'Choose the households', 400, array( 'field' => 'parts' ) );
		}
		if ( ! $c ) {
			return ogc_ledger_err( 'Enter an amount for each household', 400, array( 'field' => 'parts' ) );
		}
		$parts[ $rid ] = isset( $parts[ $rid ] ) ? $parts[ $rid ] + $c : $c;
	}
	if ( ! $parts ) {
		return ogc_ledger_err( 'Choose the households', 400, array( 'field' => 'parts' ) );
	}
	$left = $cents - array_sum( $parts );
	if ( 0 !== $left ) {
		return ogc_ledger_err( ( $left > 0 ? 'Not yet assigned ' : 'Over by ' ) . ogc_ledger_money( abs( $left ) ), 400, array( 'field' => 'parts', 'left' => $left ) );
	}
	if ( ! rest_sanitize_boolean( $req->get_param( 'again' ) ) ) {
		$dup = ogc_ledger_dup( $y, $ref, $cents );
		if ( $dup ) {
			return ogc_ledger_err( $dup['words'], 409, array( 'dup' => true ) );
		}
	}
	$grp         = 'g' . strtolower( wp_generate_password( 10, false, false ) );
	$n           = count( $parts );
	$act         = ogc_ledger_begin( $y, ( $by ? $by : 'Check' ) . ' · ' . ogc_ledger_money( $cents ) . ' · ' . ogc_app_plural( $n, 'household' ) );
	$act['word'] = ogc_ledger_words()['paid'];
	$act['day']  = $day;
	foreach ( $parts as $rid => $c ) {
		$rec     = ogc_record_get( $rid );
		$pending = null;
		foreach ( ogc_pay_rows( $rid ) as $p ) {
			if ( 'check' === $p['kind'] && 'pending' === $p['status'] ) {
				$pending = $p;
				break;
			}
		}
		if ( $pending ) {
			ogc_ledger_snap( $act, $pending );
			if ( ogc_pay_set_if( $pending['id'], array( 'status' => 'paid', 'cents' => $c, 'ref' => $ref, 'day' => $day, 'paid_by' => $by, 'grp' => $grp ), 'pending' ) ) {
				if ( $c < $pending['cents'] ) {
					$new = ogc_pay_add( $rec, 'check', 'check', $pending['cents'] - $c, 'pending', array( 'note' => 'Rest of check' ) );
					if ( $new ) {
						$act['added'][] = $new;
					}
				}
				ogc_ledger_note( $act, $rid );
				$act['mail'][ $rid ][] = (int) $pending['id'];
				continue;
			}
			unset( $act['before'][ $pending['id'] ] );
		}
		$new = ogc_pay_add( $rec, 'check', 'check', $c, 'paid', array( 'ref' => $ref, 'day' => $day, 'paid_by' => $by, 'grp' => $grp ) );
		if ( $new ) {
			$act['added'][] = $new;
			ogc_ledger_note( $act, $rid );
			$act['mail'][ $rid ][] = (int) $new;
		}
	}
	return rest_ensure_response( ogc_ledger_done( $act, 'check' ) );
}

/** POST ledger/add {record, how: check|cash|card, cents, ref?, day?, again?} → money taken with no line waiting. */
function ogc_ledger_rest_add( WP_REST_Request $req ) {
	$y     = (int) $req['year'];
	$ctx   = ogc_rec_ctx( $y );
	$rec   = ogc_ledger_reg( $y, (int) ogc_ledger_s( $req, 'record' ) );
	$how   = ogc_ledger_s( $req, 'how' );
	$cents = ogc_ledger_cents( ogc_ledger_s( $req, 'cents' ) );
	if ( ! $rec ) {
		return new WP_Error( 'ogc_not_found', 'Not found.', array( 'status' => 404 ) );
	}
	if ( ! in_array( $how, array( 'check', 'cash', 'card' ), true ) ) {
		return ogc_ledger_err( 'Choose how it was paid', 400, array( 'field' => 'how' ) );
	}
	if ( ! $cents ) {
		return ogc_ledger_err( 'Enter an amount', 400, array( 'field' => 'cents' ) );
	}
	$ref  = ogc_ledger_ref( ogc_ledger_s( $req, 'ref' ) );
	$day  = ogc_ledger_day( $req, $ctx );
	$desk = 'check' !== $how || rest_sanitize_boolean( $req->get_param( 'desk' ) );
	if ( 'check' === $how && ! rest_sanitize_boolean( $req->get_param( 'again' ) ) ) {
		$dup = ogc_ledger_dup( $y, $ref, $cents );
		if ( $dup ) {
			return ogc_ledger_err( $dup['words'], 409, array( 'dup' => true ) );
		}
	}
	$id   = 'check' === $how && ! $desk
		? ogc_pay_add( $rec, 'check', 'check', $cents, 'paid', array( 'ref' => $ref, 'day' => $day ) )
		: ogc_pay_add( $rec, 'desk', $how, $cents, 'paid', array( 'ref' => $ref, 'day' => $day, 'note' => 'At the desk' ) );
	if ( ! $id ) {
		return ogc_ledger_err( 'Not saved', 500 );
	}
	$label          = ogc_rec_label( $rec['data'] );
	$act            = ogc_ledger_begin( $y, $label . ' · Paid ' . ogc_ledger_money( $cents ) );
	$act['word']    = ogc_ledger_words()['paid'];
	$act['day']     = $day;
	$act['added'][] = $id;
	ogc_ledger_note( $act, $rec['id'] );
	$act['mail'][ (int) $rec['id'] ][] = (int) $id;
	return rest_ensure_response( ogc_ledger_done( $act, 'add' ) );
}

/** POST ledger/mark {line, action: returned|disputed} → a received check bounced, a card payment disputed. */
function ogc_ledger_rest_mark( WP_REST_Request $req ) {
	$y      = (int) $req['year'];
	$p      = ogc_ledger_get( $y, (int) ogc_ledger_s( $req, 'line' ) );
	$action = ogc_ledger_s( $req, 'action' );
	if ( ! $p ) {
		return new WP_Error( 'ogc_not_found', 'Not found.', array( 'status' => 404 ) );
	}
	$ok = ( 'returned' === $action && 'paid' === $p['status'] && ( 'check' === $p['kind'] || ( 'desk' === $p['kind'] && 'check' === $p['method'] ) ) )
		|| ( 'disputed' === $action && 'paid' === $p['status'] && 'charge' === $p['kind'] );
	if ( ! $ok ) {
		return ogc_ledger_err( 'returned' === $action ? 'Only a received check' : 'Only a paid card payment', 409 );
	}
	$label = ogc_rec_label( ogc_record_get( $p['record_id'] )['data'] );
	$act         = ogc_ledger_begin( $y, $label . ' · ' . ( 'returned' === $action ? 'Check returned' : 'Disputed' ) . ' · ' . ogc_ledger_money( $p['cents'] ) );
	$act['word'] = ogc_ledger_words()['changed'];
	ogc_ledger_snap( $act, $p );
	if ( ! ogc_pay_set_if( $p['id'], array( 'status' => 'returned' === $action ? 'returned' : 'disputed' ), 'paid' ) ) {
		return ogc_ledger_err( 'Changed since · Reload', 409 );
	}
	ogc_ledger_note( $act, $p['record_id'] );
	return rest_ensure_response( ogc_ledger_done( $act, $action ) );
}

/** POST ledger/edit {line, ref?, note?, paid_by?} → the check number or a few words, typed later. */
function ogc_ledger_rest_edit( WP_REST_Request $req ) {
	$y = (int) $req['year'];
	$p = ogc_ledger_get( $y, (int) ogc_ledger_s( $req, 'line' ) );
	if ( ! $p ) {
		return new WP_Error( 'ogc_not_found', 'Not found.', array( 'status' => 404 ) );
	}
	$set = array();
	if ( null !== $req->get_param( 'ref' ) ) {
		$set['ref'] = ogc_ledger_ref( ogc_ledger_s( $req, 'ref' ) );
	}
	if ( null !== $req->get_param( 'note' ) ) {
		$set['note'] = mb_substr( sanitize_text_field( ogc_ledger_s( $req, 'note' ) ), 0, 120 );
	}
	if ( null !== $req->get_param( 'paid_by' ) ) {
		$set['paid_by'] = mb_substr( sanitize_text_field( ogc_ledger_s( $req, 'paid_by' ) ), 0, 80 );
	}
	if ( ! $set ) {
		return ogc_ledger_err( 'Nothing to save' );
	}
	ogc_pay_set( $p['id'], $set );
	ogc_log( 'ledger_edit', $y, 'payments', array( 'line' => $p['id'], 'fields' => array_keys( $set ) ) );
	ogc_rec_forget( $y );
	return rest_ensure_response( array( 'ok' => true, 'say' => 'Saved', 'line' => ogc_ledger_line( ogc_pay_get( $p['id'] ), ogc_rec_ctx( $y ) ) ) );
}

/** POST ledger/remind {line, preview?} → a short email to a household whose check hasn't come (once a week). */
function ogc_ledger_rest_remind( WP_REST_Request $req ) {
	$y   = (int) $req['year'];
	$p   = ogc_ledger_get( $y, (int) ogc_ledger_s( $req, 'line' ) );
	$rec = $p ? ogc_record_get( $p['record_id'] ) : null;
	if ( ! $p || ! $rec || 'check' !== $p['kind'] || 'pending' !== $p['status'] ) {
		return ogc_ledger_err( 'No check to come', 409 );
	}
	$ctx  = ogc_rec_ctx( $y );
	$cfg  = $ctx['cfg'];
	$rid  = isset( $rec['data']['rid'] ) ? $rec['data']['rid'] : '';
	$addr = isset( $cfg['check_address'] ) ? str_replace( '|', "\n", $cfg['check_address'] ) : '';
	$body = implode( "\n", array_filter( array(
		'Check to come · ' . ogc_ledger_money( $p['cents'] ),
		'Registration ' . $rid,
		'',
		! empty( $cfg['check_payee'] ) ? 'Payable to ' . $cfg['check_payee'] : '',
		$addr ? "Mail to\n" . $addr : '',
		$ctx['check_by'] ? 'By ' . gmdate( 'F j', strtotime( $ctx['check_by'] . ' 12:00 UTC' ) ) : '',
		'',
		'Please write ' . $rid . ' on the check.',
	), function ( $l ) { return null !== $l; } ) );
	$subject = $y . ' Annual Conference · Check to come';
	if ( rest_sanitize_boolean( $req->get_param( 'preview' ) ) ) {
		return rest_ensure_response( array( 'to' => $rec['email'] && function_exists( 'ogc_reg_mask' ) ? ogc_reg_mask( $rec['email'] ) : '', 'subject' => $subject, 'body' => $body, 'email' => (bool) $rec['email'] ) );
	}
	if ( ! $rec['email'] || ! function_exists( 'ogc_send_mail' ) ) {
		return ogc_ledger_err( 'No email · Call them', 400 );
	}
	$sent = ogc_state_get( $y, 'pay_reminded' );
	$val  = $sent && is_array( $sent['value'] ) ? $sent['value'] : array();
	if ( isset( $val[ $p['id'] ] ) && time() - strtotime( $val[ $p['id'] ] . ' UTC' ) < 7 * DAY_IN_SECONDS ) {
		return ogc_ledger_err( 'Reminded · This week', 429 );
	}
	if ( ! $rec['sample'] ) {
		ogc_send_mail( $rec['email'], $subject, $body, array( 'kind' => 'reminder', 'year' => $y ) );
	}
	$val[ $p['id'] ] = ogc_now();
	ogc_state_put( $y, 'pay_reminded', (object) $val );
	ogc_log( 'ledger_remind', $y, 'payments', array( 'line' => $p['id'] ) );
	return rest_ensure_response( array( 'ok' => true, 'say' => ogc_rec_label( $rec['data'] ) . ' · Reminder sent' ) );
}

/* ------------------------------------------------------------------ refunds */

/** POST ledger/refund {lines[], action: approve|send|decline, ref?, day?, note?} */
function ogc_ledger_rest_refund( WP_REST_Request $req ) {
	$y      = (int) $req['year'];
	$ctx    = ogc_rec_ctx( $y );
	$action = ogc_ledger_s( $req, 'action' );
	$ids    = array_slice( array_values( array_unique( array_map( 'intval', array_filter( (array) $req->get_param( 'lines' ), 'is_scalar' ) ) ) ), 0, 60 );
	if ( ! in_array( $action, array( 'approve', 'send', 'decline' ), true ) ) {
		return ogc_ledger_err( 'Unknown action' );
	}
	$one  = 1 === count( $ids );
	$ref  = $one ? ogc_ledger_ref( ogc_ledger_s( $req, 'ref' ) ) : '';
	$note = $one ? mb_substr( sanitize_text_field( ogc_ledger_s( $req, 'note' ) ), 0, 120 ) : '';
	$day  = ogc_ledger_day( $req, $ctx );
	$from = 'approve' === $action ? array( 'requested' ) : array( 'requested', 'approved' );
	$to   = array( 'approve' => 'approved', 'send' => 'sent', 'decline' => 'cancelled' );
	$word = array( 'approve' => 'Refund approved', 'send' => 'Refunded', 'decline' => 'Refund declined' );
	$act         = ogc_ledger_begin( $y, '' );
	$act['word'] = ogc_ledger_words()[ $action ];
	$act['day']  = 'approve' === $action ? '' : $day;
	$done        = 0;
	$sum         = 0;
	$last        = '';
	foreach ( $ids as $id ) {
		$p = ogc_ledger_get( $y, $id );
		if ( ! $p || 'refund' !== $p['kind'] || ! in_array( $p['status'], $from, true ) ) {
			continue;
		}
		ogc_ledger_snap( $act, $p );
		$set = array( 'status' => $to[ $action ] );
		if ( 'approve' !== $action ) {
			$set['day'] = $day;
		}
		if ( '' !== $ref ) {
			$set['ref'] = $ref;
		}
		if ( '' !== $note ) {
			$set['note'] = $note;
		}
		if ( ! ogc_pay_set_if( $p['id'], $set, $p['status'] ) ) {
			unset( $act['before'][ $p['id'] ] );
			continue;
		}
		ogc_ledger_note( $act, $p['record_id'] );
		$done++;
		$sum += $p['cents'];
		$last = ogc_rec_label( ogc_record_get( $p['record_id'] )['data'] );
	}
	if ( ! $done ) {
		return ogc_ledger_err( 'Changed since · Reload', 409 );
	}
	$many       = array( 'approve' => 'approved', 'send' => 'sent', 'decline' => 'declined' );
	$act['say'] = ( 1 === $done ? $last . ' · ' . $word[ $action ] : ogc_app_plural( $done, 'refund' ) . ' ' . $many[ $action ] ) . ' · ' . ogc_ledger_money( $sum );
	return rest_ensure_response( ogc_ledger_done( $act, 'refund_' . $action ) );
}

/** POST ledger/refund/ask {record, cents, note} → a refund of what was paid over the total, to approve. */
function ogc_ledger_rest_refund_ask( WP_REST_Request $req ) {
	$y     = (int) $req['year'];
	$rec   = ogc_ledger_reg( $y, (int) ogc_ledger_s( $req, 'record' ) );
	$cents = ogc_ledger_cents( ogc_ledger_s( $req, 'cents' ) );
	if ( ! $rec ) {
		return new WP_Error( 'ogc_not_found', 'Not found.', array( 'status' => 404 ) );
	}
	if ( ! $cents ) {
		return ogc_ledger_err( 'Enter an amount', 400, array( 'field' => 'cents' ) );
	}
	// Only what was paid over the total and no refund asks for yet: a change of nights or a cancelling
	// goes through the registration, which works out its own refund (docs/scope/02 flow H).
	$m = ogc_rec_money_of( $rec, ogc_rec_ctx( $y ) );
	if ( ! $m['unasked'] ) {
		return ogc_ledger_err( 'Nothing paid over · Change the registration first', 409 );
	}
	if ( $cents > $m['unasked'] ) {
		return ogc_ledger_err( 'More than was paid over · ' . ogc_ledger_money( $m['unasked'] ), 400, array( 'field' => 'cents' ) );
	}
	$method = 'check';
	foreach ( ogc_pay_rows( $rec['id'] ) as $p ) {
		$method = 'charge' === $p['kind'] && 'paid' === $p['status'] ? 'card' : $method;
	}
	$note = mb_substr( sanitize_text_field( ogc_ledger_s( $req, 'note' ) ), 0, 120 );
	$id = ogc_pay_add( $rec, 'refund', $method, $cents, 'requested', array( 'note' => $note ) );
	if ( ! $id ) {
		return ogc_ledger_err( 'Not saved', 500 );
	}
	$act            = ogc_ledger_begin( $y, ogc_rec_label( $rec['data'] ) . ' · Refund asked · ' . ogc_ledger_money( $cents ) );
	$act['word']    = ogc_ledger_words()['asked'];
	$act['added'][] = $id;
	ogc_ledger_note( $act, $rec['id'] );
	return rest_ensure_response( ogc_ledger_done( $act, 'refund_ask' ) );
}

/* ------------------------------------------------------------------ deposits */

/** POST ledger/deposits {lines[], day, kind?, bank?} → a deposit of received lines not yet in one. */
function ogc_ledger_rest_deposit_add( WP_REST_Request $req ) {
	global $wpdb;
	$y     = (int) $req['year'];
	$ctx   = ogc_rec_ctx( $y );
	$ids   = array_slice( array_values( array_unique( array_map( 'intval', array_filter( (array) $req->get_param( 'lines' ), 'is_scalar' ) ) ) ), 0, 400 );
	$day   = ogc_ledger_day( $req, $ctx );
	$lines = array();
	foreach ( $ids as $id ) {
		$p = ogc_ledger_get( $y, $id );
		if ( $p && 'refund' !== $p['kind'] && 'paid' === $p['status'] && ! $p['deposit_id'] ) {
			$lines[] = $p;
		}
	}
	if ( ! $lines ) {
		return ogc_ledger_err( 'Choose money received, not yet deposited' );
	}
	$kinds = array_unique( array_map( function ( $p ) { return 'charge' === $p['kind'] ? 'card' : ( 'desk' === $p['kind'] && 'cash' === $p['method'] ? 'cash' : 'checks' ); }, $lines ) );
	$kind  = ogc_ledger_s( $req, 'kind' );
	$kind  = array_key_exists( $kind, ogc_ledger_deposit_kinds() ) ? $kind : ( 1 === count( $kinds ) ? reset( $kinds ) : 'checks' );
	$bank  = $req->get_param( 'bank' );
	$bank  = null !== $bank && '' !== $bank && is_numeric( $bank ) && (int) $bank >= 0 && (int) $bank <= 100000000 ? (int) $bank : -1;
	$wpdb->insert( ogc_table( 'deposits' ), array( 'year' => $y, 'day' => $day, 'kind' => $kind, 'bank_cents' => $bank, 'note' => '', 'sample' => 0, 'by_user' => get_current_user_id(), 'created_at' => ogc_now(), 'updated_at' => ogc_now() ), array( '%d', '%s', '%s', '%d', '%s', '%d', '%d', '%s', '%s' ) );
	$dep = (int) $wpdb->insert_id;
	if ( ! $dep ) {
		return ogc_ledger_err( 'Not saved', 500 );
	}
	$sum = 0;
	$act = ogc_ledger_begin( $y, '' );
	foreach ( $lines as $p ) {
		ogc_ledger_snap( $act, $p );
		ogc_pay_set( $p['id'], array( 'deposit_id' => $dep ) );
		$sum += $p['cents'];
	}
	// A deposit doesn't change what a household owes: no History lines, no receipts.
	$act['recs'] = array();
	$act['dep']  = array( 'added' => $dep );
	$kw          = ogc_ledger_deposit_kinds();
	$grps        = array();
	foreach ( $lines as $p ) {
		$grps[ '' !== $p['grp'] ? $p['grp'] : 'l' . $p['id'] ] = true;
	}
	$act['say']  = 'Deposit · ' . $kw[ $kind ] . ' · ' . ogc_app_plural( count( $grps ), 'checks' === $kind ? 'check' : 'payment' ) . ' · ' . ogc_ledger_money( $sum );
	$out         = ogc_ledger_done( $act, 'deposit' );
	$out['id']   = $dep;
	return rest_ensure_response( $out );
}

function ogc_ledger_dep_row( $year, $id ) {
	global $wpdb;
	return $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . ogc_table( 'deposits' ) . ' WHERE id = %d AND year = %d AND removed_at IS NULL', $id, $year ), ARRAY_A );
}

/** PATCH ledger/deposits/{id} {bank?, day?, note?} → the bank statement's figure and day. */
function ogc_ledger_rest_deposit_patch( WP_REST_Request $req ) {
	global $wpdb;
	$y   = (int) $req['year'];
	$ctx = ogc_rec_ctx( $y );
	$d   = ogc_ledger_dep_row( $y, (int) $req['id'] );
	if ( ! $d ) {
		return new WP_Error( 'ogc_not_found', 'Not found.', array( 'status' => 404 ) );
	}
	$set = array();
	if ( null !== $req->get_param( 'bank' ) ) {
		$b                 = $req->get_param( 'bank' );
		$set['bank_cents'] = '' === $b ? -1 : ( is_numeric( $b ) && (int) $b >= 0 && (int) $b <= 100000000 ? (int) $b : null );
		if ( null === $set['bank_cents'] ) {
			return ogc_ledger_err( 'Enter the bank’s amount', 400, array( 'field' => 'bank' ) );
		}
	}
	if ( null !== $req->get_param( 'day' ) ) {
		$set['day'] = ogc_ledger_day( $req, $ctx );
	}
	if ( null !== $req->get_param( 'note' ) ) {
		$set['note'] = mb_substr( sanitize_text_field( ogc_ledger_s( $req, 'note' ) ), 0, 120 );
	}
	if ( ! $set ) {
		return ogc_ledger_err( 'Nothing to save' );
	}
	$set['updated_at'] = ogc_now();
	$wpdb->update( ogc_table( 'deposits' ), $set, array( 'id' => (int) $d['id'] ) );
	ogc_log( 'ledger_deposit_edit', $y, 'payments', array( 'deposit' => (int) $d['id'], 'fields' => array_keys( $set ) ) );
	ogc_rec_forget( $y );
	foreach ( ogc_ledger_deposits( $y, ogc_rec_ctx( $y ) ) as $x ) {
		if ( $x['id'] === (int) $d['id'] ) {
			return rest_ensure_response( array( 'ok' => true, 'say' => 'Saved', 'deposit' => $x ) );
		}
	}
	return rest_ensure_response( array( 'ok' => true, 'say' => 'Saved' ) );
}

/** DELETE ledger/deposits/{id} → removed (kept, marked removed); its lines are free to deposit again. */
function ogc_ledger_rest_deposit_delete( WP_REST_Request $req ) {
	global $wpdb;
	$y = (int) $req['year'];
	$d = ogc_ledger_dep_row( $y, (int) $req['id'] );
	if ( ! $d ) {
		return new WP_Error( 'ogc_not_found', 'Not found.', array( 'status' => 404 ) );
	}
	$act = ogc_ledger_begin( $y, 'Deposit removed · ' . ( function_exists( 'ogc_app_md' ) ? ogc_app_md( $d['day'], $y ) : $d['day'] ) );
	foreach ( ogc_pay_year( $y ) as $p ) {
		if ( (int) $p['deposit_id'] === (int) $d['id'] ) {
			ogc_ledger_snap( $act, $p );
			ogc_pay_set( $p['id'], array( 'deposit_id' => 0 ) );
		}
	}
	$wpdb->update( ogc_table( 'deposits' ), array( 'removed_at' => ogc_now() ), array( 'id' => (int) $d['id'] ) );
	$act['recs'] = array();
	$act['dep']  = array( 'removed' => (int) $d['id'] );
	return rest_ensure_response( ogc_ledger_done( $act, 'deposit_remove' ) );
}

/* ------------------------------------------------------------------ undo */

/** Is the line as the act left it? (A line the act left and that is gone since is not.) */
function ogc_ledger_same( $p, $was ) {
	if ( null === $was || ! is_array( $was ) ) {
		return null === $p;
	}
	if ( ! $p ) {
		return false;
	}
	foreach ( $was as $k => $v ) {
		if ( (string) ( isset( $p[ $k ] ) ? $p[ $k ] : '' ) !== (string) $v ) {
			return false;
		}
	}
	return true;
}

/** POST ledger/undo {token} → the lines and deposit as they were before that action (24 hours). */
function ogc_ledger_rest_undo( WP_REST_Request $req ) {
	global $wpdb;
	$y     = (int) $req['year'];
	$token = ogc_ledger_s( $req, 'token' );
	$cur   = ogc_state_get( $y, 'ledger_undo' );
	$list  = $cur && is_array( $cur['value'] ) ? $cur['value'] : array();
	$found = null;
	foreach ( $list as $i => $u ) {
		if ( is_array( $u ) && isset( $u['t'] ) && hash_equals( (string) $u['t'], $token ) ) {
			$found = $i;
		}
	}
	if ( null === $found || ! empty( $list[ $found ]['undone'] ) || time() - strtotime( $list[ $found ]['at'] . ' UTC' ) > DAY_IN_SECONDS ) {
		return ogc_ledger_err( 'Can’t undo', 409 );
	}
	$u = $list[ $found ];
	// Only while every line it touched is still as it left it: a check received and then deposited, or a
	// rest of a check that has come since, is undone line by line (never taken back silently).
	foreach ( (array) ( isset( $u['after'] ) ? $u['after'] : array() ) as $id => $was ) {
		if ( ! ogc_ledger_same( ogc_pay_get( (int) $id ), $was ) ) {
			return ogc_ledger_err( 'Changed since · Can’t undo', 409 );
		}
	}
	// Mark it undone first, against the version read, so a double tap can't undo twice.
	$list[ $found ]['undone'] = ogc_now();
	if ( is_wp_error( ogc_state_put( $y, 'ledger_undo', $list, $cur['version'] ) ) ) {
		return ogc_ledger_err( 'Can’t undo', 409 );
	}
	$recs = array();
	foreach ( (array) $u['before'] as $id => $fields ) {
		$p = ogc_pay_get( (int) $id );
		if ( $p && (int) $p['year'] === $y ) {
			ogc_pay_set( (int) $id, (array) $fields );
			$recs[ (int) $p['record_id'] ] = true;
		}
	}
	// A line the action added is taken out again (it existed only for that action).
	foreach ( (array) $u['added'] as $id ) {
		$p = ogc_pay_get( (int) $id );
		if ( $p && (int) $p['year'] === $y ) {
			$wpdb->delete( ogc_table( 'payments' ), array( 'id' => (int) $id ), array( '%d' ) );
			$recs[ (int) $p['record_id'] ] = true;
		}
	}
	if ( ! empty( $u['dep']['added'] ) ) {
		$wpdb->update( ogc_table( 'deposits' ), array( 'removed_at' => ogc_now() ), array( 'id' => (int) $u['dep']['added'], 'year' => $y ) );
	}
	if ( ! empty( $u['dep']['removed'] ) ) {
		$wpdb->query( $wpdb->prepare( 'UPDATE ' . ogc_table( 'deposits' ) . ' SET removed_at = NULL WHERE id = %d AND year = %d', (int) $u['dep']['removed'], $y ) );
	}
	$touch = empty( $u['dep'] );
	$word  = ! empty( $u['word'] ) ? (string) $u['word'] : ogc_ledger_words()['changed'];
	foreach ( array_keys( $recs ) as $rid ) {
		$rec = ogc_record_get( $rid );
		if ( ! $rec ) {
			continue;
		}
		$data = $rec['data'];
		if ( $touch ) {
			ogc_ledger_hist( $data, 'Undone · ' . $word, $y );
		}
		ogc_reg_save( $rec, $data );
	}
	// Its receipts, still waiting, don't go.
	ogc_ledger_receipts_drop( $y, (string) $u['t'] );
	ogc_log( 'ledger_undo', $y, 'payments', array( 'lines' => array_keys( (array) $u['before'] ) ) );
	ogc_rec_forget( $y );
	return rest_ensure_response( array( 'ok' => true, 'say' => 'Undone' ) );
}
