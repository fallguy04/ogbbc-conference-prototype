<?php
/**
 * The year's lists (lists area): what the caterer, the communion and preteen committees, the treasurer
 * and the call-in line each need from the registrations and the schedule, worked out on the server.
 *
 * The browser never gets the year's households: each list is one route that answers with that list
 * only, for a member of the year. Two lists hold more than counts, and only the people the COA names
 * see them (the year's state values, as the register area reads them too):
 *   preteen_viewers   children's names, ages, who may pick them up, medical notes, emergency contacts
 *   payment_viewers   the ledger: who owes, checks to come, refunds
 * Webmasters see both. Everyone else in the year gets the count.
 *
 *   GET  lists/{y}/{view}         view: meals · communion · preteens · payments · callin  (?format=csv)
 *   POST lists/{y}/meals/send     {how: email|mark, final}  counts to the caterer, kept as a version
 *   POST lists/{y}/meals/undo     the last "Mark as sent", within the hour
 *   PUT  lists/{y}/settings       {caterer_email, counts_due, communion_supper}  the lists' own settings
 *   GET  lists/{y}/access         who sees Preteens and Payments (and the year's members, to choose)
 *   PUT  lists/{y}/access         {list, emails}   the COA and webmasters
 *   POST lists/{y}/pay            {payment, action: received|refunded|declined, cents, ref, date}
 *   POST lists/{y}/pay/undo       {mark}
 *   POST lists/{y}/pay/add        {record, cents, method}   a payment at the desk
 *   POST lists/{y}/pay/remind     {payment}  a reminder to a household whose check hasn't come
 *   POST lists/{y}/printed        {view, what}   kept, so changes since show (and logged)
 *   POST lists/{y}/seen           {view}   this member's "New since you looked"
 *
 * After the Conference plus clear_after_days (registration.csv), the year's people are cleared: the
 * lists keep their counts (state lists_record) and show nothing else.
 */

defined( 'ABSPATH' ) || exit;

/* ================================================================== the page */

add_filter( 'ogc_pages', function ( $p ) {
	if ( isset( $p['lists'] ) ) {
		// Its own styles (not Lodging's tables), and no records loaded into the browser.
		$p['lists']['title']   = 'Lists';
		$p['lists']['styles']  = array( 'shared/ogc-tokens.css', 'shared/ogc-ui.css', 'schedule-hub/week.css', 'shared/ogc-ws.css', 'lists/lists.css' );
		$p['lists']['scripts'] = array( 'shared/ogc-core.js', 'shared/ogc-store.js', 'shared/ogc-signups.js', 'lists/lists.js' );
	}
	return $p;
} );

add_filter( 'ogc_client_config', function ( $cfg, $key ) {
	if ( 'lists' === $key ) {
		$cfg['recordKinds'] = array( 'none' );
		$cfg['recordYears'] = 1;
	}
	return $cfg;
}, 10, 2 );

/* ================================================================== small helpers */

function ogc_lst_kv( $year, $name ) {
	$f   = ogc_file_get( (int) $year, $name );
	$out = array();
	foreach ( $f ? $f['rows'] : array() as $r ) {
		if ( isset( $r['key'] ) && '' !== $r['key'] ) {
			$out[ trim( $r['key'] ) ] = isset( $r['value'] ) ? trim( (string) $r['value'] ) : '';
		}
	}
	return $out;
}

function ogc_lst_tz( $year ) {
	$s = ogc_lst_kv( $year, 'settings' );
	try {
		return new DateTimeZone( ! empty( $s['timezone'] ) ? $s['timezone'] : 'America/Indiana/Indianapolis' );
	} catch ( Exception $e ) {
		return new DateTimeZone( 'America/Indiana/Indianapolis' );
	}
}

/** The campus's date and minute now. A local site honours ?as_of= (the walk-through); ogbbc.org never. */
function ogc_lst_now( $year, $req = null ) {
	$as = $req instanceof WP_REST_Request ? (string) $req->get_param( 'as_of' ) : '';
	if ( OGC_DEV && preg_match( '/^(\d{4}-\d\d-\d\d)(?:[T ](\d\d):(\d\d))?/', $as, $m ) ) {
		return array( 'date' => $m[1], 'min' => isset( $m[2] ) ? (int) $m[2] * 60 + (int) $m[3] : 720 );
	}
	$d = new DateTime( 'now', ogc_lst_tz( $year ) );
	return array( 'date' => $d->format( 'Y-m-d' ), 'min' => (int) $d->format( 'G' ) * 60 + (int) $d->format( 'i' ) );
}

function ogc_lst_add_days( $iso, $n ) {
	$d = DateTime::createFromFormat( '!Y-m-d', (string) $iso, new DateTimeZone( 'UTC' ) );
	if ( ! $d ) {
		return '';
	}
	$d->modify( ( $n >= 0 ? '+' : '' ) . (int) $n . ' days' );
	return $d->format( 'Y-m-d' );
}

function ogc_lst_days_between( $a, $b ) {
	$x = strtotime( $a . ' 00:00:00 UTC' );
	$y = strtotime( $b . ' 00:00:00 UTC' );
	return ( $x && $y ) ? (int) round( ( $y - $x ) / DAY_IN_SECONDS ) : 0;
}

/** "7:00 AM", "7 am", "noon", "19:30" → minutes after midnight, or null (words: "After Communion"). */
function ogc_lst_min( $s ) {
	$t = strtolower( trim( str_replace( '.', '', (string) $s ) ) );
	if ( '' === $t ) {
		return null;
	}
	if ( preg_match( '/^(12(:00)?\s*)?noon$/', $t ) ) {
		return 720;
	}
	if ( preg_match( '/^(12(:00)?\s*)?midnight$/', $t ) ) {
		return 1440;
	}
	if ( ! preg_match( '/^(\d{1,2})(?::(\d{2}))?\s*(am|pm|a|p)?$/', $t, $m ) ) {
		return null;
	}
	$h  = (int) $m[1];
	$mi = isset( $m[2] ) && '' !== $m[2] ? (int) $m[2] : 0;
	$ap = isset( $m[3] ) ? $m[3] : '';
	if ( $mi > 59 || $h > 24 ) {
		return null;
	}
	if ( $ap ) {
		if ( 0 === $h || $h > 12 ) {
			return null;
		}
		if ( 'p' === $ap[0] && 12 !== $h ) {
			$h += 12;
		}
		if ( 'a' === $ap[0] && 12 === $h ) {
			$h = 0;
		}
	}
	return $h * 60 + $mi;
}

function ogc_lst_hm( $m, $suffix = true ) {
	$m = ( ( $m % 1440 ) + 1440 ) % 1440;
	$h = (int) floor( $m / 60 );
	$t = ( $h % 12 ? $h % 12 : 12 ) . ':' . str_pad( (string) ( $m % 60 ), 2, '0', STR_PAD_LEFT );
	return $suffix ? $t . ( $h >= 12 ? ' PM' : ' AM' ) : $t;
}

/** "12:05–2:15 PM", "10:00 AM–12:15 PM", "5:00 PM", or the row's own words. */
function ogc_lst_when( $r ) {
	$a = ogc_lst_min( isset( $r['start'] ) ? $r['start'] : '' );
	$b = ogc_lst_min( isset( $r['end'] ) ? $r['end'] : '' );
	if ( null === $a ) {
		return trim( (string) ( isset( $r['start'] ) ? $r['start'] : '' ) );
	}
	if ( null === $b ) {
		return ogc_lst_hm( $a );
	}
	$same = (int) floor( ( $a % 1440 ) / 720 ) === (int) floor( ( $b % 1440 ) / 720 );
	return ogc_lst_hm( $a, ! $same ) . '–' . ogc_lst_hm( $b );
}

/** "Ruth K." for a user. */
function ogc_lst_who( $uid ) {
	if ( function_exists( 'ogc_coa_first_l' ) && $uid ) {
		return ogc_coa_first_l( $uid );
	}
	$u = $uid ? get_userdata( $uid ) : null;
	if ( ! $u ) {
		return '';
	}
	$p = preg_split( '/\s+/', trim( (string) $u->display_name ) );
	return count( $p ) > 1 ? $p[0] . ' ' . mb_substr( end( $p ), 0, 1 ) . '.' : $p[0];
}

function ogc_lst_err( $msg, $status = 400, $extra = array() ) {
	return new WP_Error( 'ogc_lists', $msg, array_merge( array( 'status' => $status ), $extra ) );
}

function ogc_lst_state( $year, $key, $fallback = array() ) {
	$s = ogc_state_get( (int) $year, $key );
	return $s && is_array( $s['value'] ) ? $s['value'] : $fallback;
}

/** Change a state value on the server's latest copy (retries on a version clash). */
function ogc_lst_state_update( $year, $key, $fn ) {
	for ( $i = 0; $i < 8; $i++ ) {
		$cur = ogc_state_get( (int) $year, $key );
		$v   = $cur && is_array( $cur['value'] ) ? $cur['value'] : array();
		$v   = $fn( $v );
		$r   = ogc_state_put( (int) $year, $key, $v, $cur ? (int) $cur['version'] : 0 );
		if ( ! is_wp_error( $r ) ) {
			return $v;
		}
	}
	return ogc_lst_err( 'Busy · Retry', 503 );
}

/** A CSV the committees open in Excel: a UTF-8 mark first (accents show), every typed cell that starts
 * like a formula (= + - @) written as text, numbers left as numbers. */
function ogc_lst_csv( $cols, $rows ) {
	$cell = function ( $v ) {
		if ( is_bool( $v ) ) {
			$v = $v ? 'yes' : '';
		}
		$v = (string) $v;
		if ( preg_match( '/^[=+\-@\t\r]/', $v ) && ! preg_match( '/^-?\d+(\.\d+)?$/', $v ) ) {
			$v = "'" . $v;
		}
		return preg_match( '/[",\r\n]/', $v ) ? '"' . str_replace( '"', '""', $v ) . '"' : $v;
	};
	$out = array( implode( ',', array_map( $cell, $cols ) ) );
	foreach ( $rows as $r ) {
		$out[] = implode( ',', array_map( $cell, $r ) );
	}
	return "\xEF\xBB\xBF" . implode( "\r\n", $out ) . "\r\n";
}

function ogc_lst_csv_response( $text, $file ) {
	$res = new WP_REST_Response( null, 200 );
	$res->header( 'Content-Type', 'text/csv; charset=utf-8' );
	$res->header( 'Content-Disposition', 'attachment; filename="' . sanitize_file_name( $file ) . '"' );
	$res->header( 'Cache-Control', 'no-store' );
	// WordPress would JSON-encode a body: send the text as it is.
	add_filter( 'rest_pre_serve_request', function ( $served, $result ) use ( $text, $res ) {
		if ( $result === $res ) {
			echo $text; // phpcs:ignore WordPress.Security.EscapeOutput -- a CSV file, made cell-safe above.
			return true;
		}
		return $served;
	}, 10, 2 );
	return $res;
}

/* ================================================================== the year and who may see what */

/** Where the year stands, for every list. */
function ogc_lst_ctx( $year, $req = null ) {
	$row   = ogc_year_get( (int) $year );
	$cfg   = function_exists( 'ogc_reg_cfg' ) ? ogc_reg_cfg( (int) $year ) : ogc_lst_kv( $year, 'registration' );
	$now   = ogc_lst_now( $year, $req );
	$end   = $row && ! empty( $row['end'] ) ? $row['end'] : '';
	$days  = isset( $cfg['clear_after_days'] ) && is_numeric( $cfg['clear_after_days'] ) ? max( 1, (int) $cfg['clear_after_days'] ) : 60;
	$clear = $end ? ogc_lst_add_days( $end, $days ) : '';
	$cl    = ogc_lst_state( $year, 'lists_cleared', null );
	return array(
		'year'     => (int) $year,
		'row'      => $row,
		'cfg'      => $cfg,
		'now'      => $now,
		'today'    => $now['date'],
		'start'    => $row && ! empty( $row['start'] ) ? $row['start'] : '',
		'end'      => $end,
		'held'     => $end && $now['date'] > $end,
		'clear_on' => $clear,
		'cleared'  => $cl ? $cl : null,
		'phase'    => function_exists( 'ogc_reg_phase' ) ? ogc_reg_phase( (int) $year, $now['date'] ) : '',
		'opens'    => isset( $cfg['opens'] ) ? $cfg['opens'] : '',
	);
}

/** The state value naming who sees a list's people (preteens) or money (payments). */
function ogc_lst_viewers_key( $list ) {
	return 'preteens' === $list ? 'preteen_viewers' : ( 'payments' === $list ? 'payment_viewers' : '' );
}

function ogc_lst_viewers( $year, $list ) {
	$k = ogc_lst_viewers_key( $list );
	$s = $k ? ogc_state_get( (int) $year, $k ) : null;
	return $s ? array_values( array_filter( array_map( 'strtolower', (array) $s['value'] ) ) ) : array();
}

/** May this person see a list's people or money? Webmasters, and the members the COA names. */
function ogc_lst_viewer( $year, $list ) {
	if ( ! in_array( $list, array( 'preteens', 'payments' ), true ) ) {
		return ogc_is_member( $year );
	}
	// The one rule (module-guard.php ogc_access, decision 25, Oct 13): children's details to the COA and
	// Preteens; each payment to Handles money. Webmasters no longer pass for being webmasters.
	if ( function_exists( 'ogc_access' ) ) {
		return ogc_access( (int) $year, 'preteens' === $list ? 'children' : 'money' );
	}
	if ( 'preteens' === $list && function_exists( 'ogc_reg_sensitive_viewer' ) ) {
		return ogc_reg_sensitive_viewer( (int) $year );
	}
	$me = ogc_current_email();
	return $me && ogc_is_member( $year ) && in_array( $me, ogc_lst_viewers( $year, $list ), true );
}

/** Only the COA (and webmasters) choose who sees Preteens and Payments. */
function ogc_lst_can_choose( $year ) {
	if ( ogc_is_webmaster() ) {
		return true;
	}
	return function_exists( 'ogc_member_can' ) ? ogc_member_can( 'invite', (int) $year ) : false;
}

/* ================================================================== the registrations */

/** The year's households that count: not cancelled, not waiting for a place. */
function ogc_lst_regs( $year, $with_gone = false ) {
	$out = array();
	foreach ( ogc_records( (int) $year, 'registrations' ) as $r ) {
		$st = isset( $r['data']['status'] ) ? $r['data']['status'] : '';
		if ( ! $with_gone && in_array( $st, array( 'cancelled', 'waitlist' ), true ) ) {
			continue;
		}
		if ( empty( $r['data']['people'] ) || ! is_array( $r['data']['people'] ) ) {
			continue;
		}
		$out[] = $r;
	}
	return $out;
}

function ogc_lst_label( $d ) {
	$n = isset( $d['household']['name'] ) ? trim( (string) $d['household']['name'] ) : '';
	if ( '' === $n ) {
		$n = isset( $d['household']['contact'] ) ? (string) $d['household']['contact'] : '';
	}
	return preg_replace( '/^the\s+/i', '', $n );
}

function ogc_lst_last_word( $name ) {
	$w = preg_split( '/\s+/', trim( (string) $name ) );
	return strtolower( (string) end( $w ) );
}

function ogc_lst_surname( $d ) {
	$n = ogc_lst_label( $d );
	$n = preg_replace( '/\s+(household|family)$/i', '', $n );
	$p = preg_split( '/\s+/', trim( $n ) );
	return strtolower( end( $p ) );
}

/** Each person's days on campus (dates), as the register area counts them. */
function ogc_lst_here( $rec, $days ) {
	$d   = $rec['data'];
	$cfg = function_exists( 'ogc_reg_cfg_for' ) ? ogc_reg_cfg_for( $rec['year'], $d ) : array();
	$out = array();
	foreach ( (array) $d['people'] as $p ) {
		if ( empty( $p['pid'] ) ) {
			continue;
		}
		$list = function_exists( 'ogc_reg_person_days' ) && isset( $d['stay']['type'] ) ? ogc_reg_person_days( $p, $d, $cfg, $days ) : wp_list_pluck( $days, 'date' );
		// Off campus with no days chosen (v3's households, an older form): any day, as v3 counted them,
		// rather than dropping them from the caterer's count.
		if ( ! $list && 'elsewhere' === ( isset( $d['stay']['type'] ) ? $d['stay']['type'] : '' ) && empty( $d['stay']['days'] ) ) {
			$list = wp_list_pluck( $days, 'date' );
		}
		$out[ $p['pid'] ] = $list;
	}
	return $out;
}

function ogc_lst_band( $p ) {
	if ( ! empty( $p['band'] ) ) {
		return $p['band'];
	}
	return 'adult';
}

/* ================================================================== meals */

function ogc_lst_meal_kind( $title ) {
	if ( function_exists( 'ogc_reg_meal_kind' ) ) {
		return ogc_reg_meal_kind( $title );
	}
	return sanitize_title( (string) $title );
}

function ogc_lst_day_index( $days, $name ) {
	if ( function_exists( 'ogc_reg_day_index' ) ) {
		return ogc_reg_day_index( $days, $name );
	}
	return -1;
}

/**
 * Every meal for the whole Conference in the schedule, in order: those with a clock time keyed as the
 * register area keys them ("2027-05-30:supper", ogc_reg_meals: households' answers point at these),
 * and a meal written in words ("After Communion") too, so nothing quietly drops off the caterer's list.
 */
function ogc_lst_meals( $year ) {
	$days = function_exists( 'ogc_reg_days' ) ? ogc_reg_days( (int) $year ) : array();
	$f    = ogc_file_get( (int) $year, 'schedule' );
	$out  = array();
	$seen = array();
	foreach ( $f ? $f['rows'] : array() as $r ) {
		if ( empty( $r['title'] ) || 'meal' !== strtolower( trim( isset( $r['kind'] ) ? $r['kind'] : '' ) ) ) {
			continue;
		}
		$aud = strtolower( trim( isset( $r['audience'] ) ? $r['audience'] : '' ) );
		if ( 0 === strpos( $aud, 'pre' ) || 0 === strpos( $aud, 'young' ) || 'yf' === $aud || 'yfs' === $aud ) {
			continue;
		}
		$a = ogc_lst_day_index( $days, isset( $r['day'] ) ? $r['day'] : '' );
		$b = ! empty( $r['last_day'] ) ? ogc_lst_day_index( $days, $r['last_day'] ) : $a;
		if ( $a < 0 || $b < 0 ) {
			continue;
		}
		$timed = '' !== trim( isset( $r['start'] ) ? (string) $r['start'] : '' );
		$start = ogc_lst_min( isset( $r['start'] ) ? $r['start'] : '' );
		$sort  = null !== $start ? $start : ogc_lst_min( isset( $r['sort_time'] ) ? $r['sort_time'] : '' );
		for ( $i = $a; $i <= $b; $i++ ) {
			$base = $days[ $i ]['date'] . ':' . ogc_lst_meal_kind( $r['title'] ) . ( $timed ? '' : ':words' );
			$n    = isset( $seen[ $base ] ) ? ++$seen[ $base ] : ( $seen[ $base ] = 1 );
			$out[] = array(
				'key'   => $n > 1 ? $base . '-' . $n : $base,
				'date'  => $days[ $i ]['date'],
				'day'   => $days[ $i ]['name'],
				'title' => (string) $r['title'],
				'kind'  => ogc_lst_meal_kind( $r['title'] ),
				'when'  => ogc_lst_when( $r ),
				'sort'  => null === $sort ? 9999 : $sort,
				'end'   => ogc_lst_min( isset( $r['end'] ) ? $r['end'] : '' ),
				'notime' => null === $sort,
			);
		}
	}
	usort( $out, function ( $x, $y ) {
		return strcmp( $x['date'], $y['date'] ) ?: ( $x['sort'] - $y['sort'] );
	} );
	return $out;
}

/** The day and end of the communion service (for the communion meal and Sunday supper). */
function ogc_lst_communion_row( $year ) {
	$days = function_exists( 'ogc_reg_days' ) ? ogc_reg_days( (int) $year ) : array();
	$f    = ogc_file_get( (int) $year, 'schedule' );
	foreach ( $f ? $f['rows'] : array() as $r ) {
		if ( 'communion' === strtolower( trim( isset( $r['kind'] ) ? $r['kind'] : '' ) ) ) {
			$i = ogc_lst_day_index( $days, isset( $r['day'] ) ? $r['day'] : '' );
			if ( $i >= 0 ) {
				return array( 'date' => $days[ $i ]['date'], 'start' => ogc_lst_min( isset( $r['start'] ) ? $r['start'] : '' ), 'title' => $r['title'] );
			}
		}
	}
	return null;
}

/**
 * Who eats each meal, from every counted household: everyone on the days they're here, less the meals
 * a household skips (meals.off) or eats only some of (meals.who). A count resting on an arrival or
 * leaving day is a guess (the form doesn't ask the first and last meal), so it's marked.
 * Returns array( meals, per ) where per[key][rid] = how many of that household.
 */
function ogc_lst_meal_counts( $year, $regs = null ) {
	$days   = function_exists( 'ogc_reg_days' ) ? ogc_reg_days( (int) $year ) : array();
	$meals  = ogc_lst_meals( $year );
	$regs   = null === $regs ? ogc_lst_regs( $year ) : $regs;
	$set    = ogc_lst_state( $year, 'lists_settings' );
	$cm     = ogc_lst_communion_row( $year );
	$skip   = 'skip' === ( isset( $set['communion_supper'] ) ? $set['communion_supper'] : '' );
	$per    = array();
	$counts = array();
	$est    = array();
	$commun = 0;
	foreach ( $meals as $m ) {
		$counts[ $m['key'] ] = array( 'adult' => 0, 'child' => 0, 'baby' => 0 );
		$est[ $m['key'] ]    = 0;
	}
	foreach ( $regs as $rec ) {
		$d    = $rec['data'];
		$rid  = isset( $d['rid'] ) ? $d['rid'] : (string) $rec['id'];
		$here = ogc_lst_here( $rec, $days );
		$off  = isset( $d['meals']['off'] ) ? (array) $d['meals']['off'] : array();
		$who  = isset( $d['meals']['who'] ) ? (array) $d['meals']['who'] : array();
		foreach ( (array) $d['people'] as $p ) {
			if ( ! empty( $p['communing'] ) && $cm && isset( $here[ $p['pid'] ] ) && in_array( $cm['date'], $here[ $p['pid'] ], true ) ) {
				$commun++;
			}
		}
		foreach ( $meals as $m ) {
			$k = $m['key'];
			if ( ! empty( $off[ $k ] ) ) {
				continue;
			}
			$n = 0;
			foreach ( (array) $d['people'] as $p ) {
				$pd = isset( $here[ $p['pid'] ] ) ? $here[ $p['pid'] ] : array();
				if ( ! in_array( $m['date'], $pd, true ) ) {
					continue;
				}
				if ( isset( $who[ $k ] ) && ! in_array( $p['pid'], (array) $who[ $k ], true ) ) {
					continue;
				}
				// Communion's supper (when the COA says so): those communing eat the communion meal.
				if ( $skip && $cm && $m['date'] === $cm['date'] && 'supper' === $m['kind'] && ! empty( $p['communing'] ) ) {
					continue;
				}
				$counts[ $k ][ ogc_lst_band( $p ) ]++;
				$n++;
				if ( $pd && ( $m['date'] === $pd[0] || $m['date'] === end( $pd ) ) ) {
					$est[ $k ]++;
				}
			}
			if ( $n ) {
				$per[ $k ][ $rid ] = $n;
			}
		}
	}
	foreach ( $meals as &$m ) {
		$m['counts'] = $counts[ $m['key'] ];
		$m['total']  = array_sum( $counts[ $m['key'] ] );
		$m['est']    = $est[ $m['key'] ];
	}
	unset( $m );
	// The communion meal: the number communing, set with the food service, as its own line.
	if ( $cm && $commun ) {
		$meals[] = array(
			'key'    => $cm['date'] . ':communion-meal',
			'date'   => $cm['date'],
			'day'    => '',
			'title'  => 'Communion meal',
			'kind'   => 'communion-meal',
			'when'   => null !== $cm['start'] ? ogc_lst_hm( $cm['start'] ) : '',
			'sort'   => null !== $cm['start'] ? $cm['start'] : 1300,
			'end'    => null,
			'notime' => false,
			'counts' => array( 'adult' => $commun, 'child' => 0, 'baby' => 0 ),
			'total'  => $commun,
			'est'    => 0,
			'from'   => 'communion',
		);
		usort( $meals, function ( $x, $y ) {
			return strcmp( $x['date'], $y['date'] ) ?: ( $x['sort'] - $y['sort'] );
		} );
	}
	return array( $meals, $per, $commun );
}

/** Snacks (Preteens, Young Folks, after Communion): how many of their audience are here that day. */
function ogc_lst_snacks( $year, $regs ) {
	$days = function_exists( 'ogc_reg_days' ) ? ogc_reg_days( (int) $year ) : array();
	$f    = ogc_file_get( (int) $year, 'schedule' );
	$rows = array();
	foreach ( $f ? $f['rows'] : array() as $r ) {
		$k = strtolower( trim( isset( $r['kind'] ) ? $r['kind'] : '' ) );
		if ( empty( $r['title'] ) || ! ( 'snack' === $k || preg_match( '/\bsnacks?\b/i', $r['title'] ) ) ) {
			continue;
		}
		$i = ogc_lst_day_index( $days, isset( $r['day'] ) ? $r['day'] : '' );
		if ( $i < 0 ) {
			continue;
		}
		$aud  = strtolower( trim( isset( $r['audience'] ) ? $r['audience'] : '' ) );
		$aud  = 0 === strpos( $aud, 'pre' ) ? 'preteens' : ( 0 === strpos( $aud, 'young' ) || 'yf' === $aud ? 'youngfolks' : 'all' );
		$rows[] = array( 'date' => $days[ $i ]['date'], 'title' => $r['title'], 'when' => ogc_lst_when( $r ), 'aud' => $aud, 'sort' => (int) ogc_lst_min( isset( $r['start'] ) ? $r['start'] : '' ), 'count' => 0 );
	}
	if ( ! $rows ) {
		return array();
	}
	foreach ( $regs as $rec ) {
		$here = ogc_lst_here( $rec, $days );
		foreach ( (array) $rec['data']['people'] as $p ) {
			$pd = isset( $here[ $p['pid'] ] ) ? $here[ $p['pid'] ] : array();
			foreach ( $rows as &$s ) {
				$fits = 'all' === $s['aud'] || ( 'preteens' === $s['aud'] && ! empty( $p['preteen'] ) ) || ( 'youngfolks' === $s['aud'] && ! empty( $p['yf'] ) );
				if ( $fits && in_array( $s['date'], $pd, true ) ) {
					$s['count']++;
				}
			}
			unset( $s );
		}
	}
	usort( $rows, function ( $x, $y ) {
		return strcmp( $x['date'], $y['date'] ) ?: ( $x['sort'] - $y['sort'] );
	} );
	return $rows;
}

/** What the caterer was last sent (newest first), each: at, day, by, how, final, counts, per. */
function ogc_lst_sent( $year ) {
	$s = ogc_lst_state( $year, 'meals_sent' );
	return isset( $s['v'] ) && is_array( $s['v'] ) ? $s['v'] : array();
}

/** Did this household leave early (its last history line says so)? */
function ogc_lst_left_early( $d ) {
	foreach ( array_reverse( isset( $d['history'] ) ? (array) $d['history'] : array() ) as $h ) {
		if ( is_array( $h ) && isset( $h['what'] ) && 0 === strpos( (string) $h['what'], 'Leaving after' ) ) {
			return true;
		}
	}
	return false;
}

/** How many households came from the Lodging Form, which asks no communion question (source: form). */
function ogc_lst_not_asked( $regs ) {
	return count( array_filter( (array) $regs, function ( $r ) { return 'form' === ( isset( $r['data']['source'] ) ? $r['data']['source'] : '' ); } ) );
}

function ogc_lst_view_meals( $year, $ctx, $req ) {
	$regs = ogc_lst_regs( $year );
	list( $meals, $per ) = ogc_lst_meal_counts( $year, $regs );
	$unasked = ogc_lst_not_asked( $regs );
	$sent  = ogc_lst_sent( $year );
	$last  = $sent ? $sent[0] : null;
	$final = null;
	foreach ( $sent as $v ) {
		if ( ! empty( $v['final'] ) ) {
			$final = $v;
			break;
		}
	}
	$labels = array();
	foreach ( ogc_lst_regs( $year, true ) as $r ) {
		$st = isset( $r['data']['status'] ) ? $r['data']['status'] : '';
		$labels[ isset( $r['data']['rid'] ) ? $r['data']['rid'] : (string) $r['id'] ] = array(
			'label'   => ogc_lst_label( $r['data'] ),
			'status'  => $st,
			'created' => substr( (string) $r['created_at'], 0, 10 ),
			'left'    => ogc_lst_left_early( $r['data'] ),
		);
	}
	$now   = $ctx['now'];
	$out   = array();
	$keys  = array();
	$net   = 0;
	$chg   = 0;
	foreach ( $meals as $m ) {
		$keys[ $m['key'] ] = true;
		// A meal already served (during the week) is greyed and leaves the change out.
		$served = $m['date'] < $now['date'] || ( $m['date'] === $now['date'] && null !== $m['end'] && $m['end'] <= $now['min'] );
		$row    = array(
			'key'    => $m['key'],
			'date'   => $m['date'],
			'title'  => $m['title'],
			'when'   => $m['when'],
			'notime' => $m['notime'],
			'counts' => $m['counts'],
			'total'  => $m['total'],
			'est'    => $m['est'],
			'served' => $served,
			'from'   => isset( $m['from'] ) ? $m['from'] : '',
		);
		// The communion meal's number leaves out the households the Lodging Form never asked: said on it.
		if ( 'communion' === $row['from'] && $unasked ) {
			$row['not_asked'] = $unasked;
		}
		if ( $last ) {
			$w = isset( $last['counts'][ $m['key'] ] ) ? $last['counts'][ $m['key'] ] : null;
			if ( ! $w ) {
				$row['status'] = 'new';
			} else {
				$row['was']    = array( 'adult' => (int) $w['adult'], 'child' => (int) $w['child'], 'baby' => (int) $w['baby'] );
				$row['change'] = $m['total'] - ( (int) $w['adult'] + (int) $w['child'] + (int) $w['baby'] );
			}
			// Who's behind a change: the households whose number for this meal moved.
			$a   = isset( $last['per'][ $m['key'] ] ) ? (array) $last['per'][ $m['key'] ] : array();
			$b   = isset( $per[ $m['key'] ] ) ? $per[ $m['key'] ] : array();
			$why = array();
			foreach ( array_unique( array_merge( array_keys( $a ), array_keys( $b ) ) ) as $rid ) {
				$x = isset( $a[ $rid ] ) ? (int) $a[ $rid ] : 0;
				$y = isset( $b[ $rid ] ) ? (int) $b[ $rid ] : 0;
				if ( $x === $y ) {
					continue;
				}
				$l     = isset( $labels[ $rid ] ) ? $labels[ $rid ] : array( 'label' => $rid, 'status' => '', 'left' => false );
				$what  = 'cancelled' === $l['status'] ? 'Cancelled' : ( 0 === $x ? 'New' : ( ! empty( $l['left'] ) ? 'Leaving early' : 'Changed' ) );
				$why[] = array( 'rid' => (string) $rid, 'label' => $l['label'], 'was' => $x, 'now' => $y, 'what' => $what );
			}
			usort( $why, function ( $p, $q ) { return abs( $q['now'] - $q['was'] ) - abs( $p['now'] - $p['was'] ); } );
			$row['why'] = array_slice( $why, 0, 40 );
			if ( ! $served && ( isset( $row['change'] ) ? $row['change'] : $m['total'] ) ) {
				$chg++;
				$net += isset( $row['change'] ) ? $row['change'] : $m['total'];
			}
			if ( $final && $last !== $final && isset( $row['change'] ) && $row['change'] ) {
				$row['after_final'] = true;
			}
		}
		$out[] = $row;
	}
	// A meal sent before and gone from the schedule since: kept, struck, with what was sent.
	if ( $last ) {
		foreach ( (array) $last['counts'] as $k => $w ) {
			if ( isset( $keys[ $k ] ) ) {
				continue;
			}
			$t     = (int) $w['adult'] + (int) $w['child'] + (int) $w['baby'];
			$out[] = array( 'key' => $k, 'date' => isset( $w['date'] ) ? $w['date'] : substr( $k, 0, 10 ), 'title' => isset( $w['title'] ) ? $w['title'] : $k, 'when' => isset( $w['when'] ) ? $w['when'] : '', 'counts' => array( 'adult' => 0, 'child' => 0, 'baby' => 0 ), 'total' => 0, 'est' => 0, 'status' => 'removed', 'was' => array( 'adult' => (int) $w['adult'], 'child' => (int) $w['child'], 'baby' => (int) $w['baby'] ), 'change' => -$t, 'served' => false, 'notime' => false );
			$chg++;
			$net -= $t;
		}
		usort( $out, function ( $x, $y ) { return strcmp( $x['date'], $y['date'] ); } );
	}
	$busiest = null;
	$week    = 0;
	foreach ( $out as $r ) {
		if ( 'communion' === ( isset( $r['from'] ) ? $r['from'] : '' ) ) {
			continue;
		}
		$week += $r['total'];
		if ( ! $busiest || $r['total'] > $busiest['total'] ) {
			$busiest = array( 'title' => $r['title'], 'date' => $r['date'], 'total' => $r['total'] );
		}
	}
	$set  = ogc_lst_state( $year, 'lists_settings' );
	$cm   = ogc_lst_communion_row( $year );
	$data = array(
		'meals'    => $out,
		'snacks'   => ogc_lst_snacks( $year, $regs ),
		'week'     => $week,
		'busiest'  => $busiest,
		'people'   => array_sum( array_map( function ( $r ) { return count( (array) $r['data']['people'] ); }, $regs ) ),
		'households' => count( $regs ),
		'elsewhere' => count( array_filter( $regs, function ( $r ) { return 'elsewhere' === ( isset( $r['data']['stay']['type'] ) ? $r['data']['stay']['type'] : '' ); } ) ),
		'sent'     => $last ? array( 'day' => $last['day'], 'at' => $last['at'], 'by' => $last['by'], 'how' => $last['how'], 'final' => ! empty( $last['final'] ), 'to' => isset( $last['to'] ) ? $last['to'] : '', 'mine' => (int) $last['uid'] === get_current_user_id(), 'undo' => 'mark' === $last['how'] && time() - strtotime( $last['at'] . ' UTC' ) < HOUR_IN_SECONDS ) : null,
		'final'    => $final ? array( 'day' => $final['day'], 'by' => $final['by'] ) : null,
		'versions' => count( $sent ),
		'changed'  => $chg,
		'net'      => $net,
		'settings' => array(
			'caterer_email'    => isset( $set['caterer_email'] ) ? $set['caterer_email'] : '',
			'counts_due'       => isset( $set['counts_due'] ) ? $set['counts_due'] : '',
			'communion_supper' => isset( $set['communion_supper'] ) ? $set['communion_supper'] : 'all',
			'suggest_due'      => $ctx['start'] ? ogc_lst_add_days( $ctx['start'], -14 ) : '',
		),
		'communion' => $cm ? array( 'date' => $cm['date'] ) : null,
		// Every send, newest first: the record of what the caterer was told (module-lists-more.php).
		'sends'    => function_exists( 'ogc_lst_sends_summary' ) ? ogc_lst_sends_summary( $year ) : array(),
	);
	if ( 'xlsx' === $req->get_param( 'format' ) && function_exists( 'ogc_lst_xlsx_out' ) ) {
		return ogc_lst_xlsx_out( $year, 'meals', array_map( function ( $r ) use ( $last ) { return ogc_lst_meal_xrow( $r, (bool) $last ); }, $out ), array(
			'From'       => count( $regs ) . ' registrations · ' . $data['people'] . ' people',
			'Last sent'  => $last ? date_i18n( 'M j, Y', strtotime( $last['day'] . ' 12:00:00' ) ) . ( $last['by'] ? ' by ' . $last['by'] : '' ) . ( ! empty( $last['final'] ) ? ' · Final' : '' ) : 'Not sent',
			'Change'     => $last ? 'Against the last send' : '',
		), $data['snacks'] ? array( array( 'snacks', array_map( 'ogc_lst_snack_xrow', $data['snacks'] ) ) ) : array(), '', 'meals' );
	}
	if ( 'csv' === $req->get_param( 'format' ) ) {
		$rows = array();
		foreach ( $out as $r ) {
			if ( 'removed' === ( isset( $r['status'] ) ? $r['status'] : '' ) ) {
				$rows[] = array( $r['date'], $r['title'], $r['when'], 0, 0, 0, 0, $last ? -( (int) $r['was']['adult'] + (int) $r['was']['child'] + (int) $r['was']['baby'] ) : '', 'Removed' );
				continue;
			}
			$rows[] = array( $r['date'], $r['title'], $r['when'], $r['counts']['adult'], $r['counts']['child'], $r['counts']['baby'], $r['total'], $last ? ( isset( $r['change'] ) ? $r['change'] : $r['total'] ) : '', trim( ( 'new' === ( isset( $r['status'] ) ? $r['status'] : '' ) ? 'New ' : '' ) . ( $r['est'] ? 'Estimate' : '' ) ) );
		}
		foreach ( $data['snacks'] as $s ) {
			$rows[] = array( $s['date'], $s['title'], $s['when'], '', '', '', $s['count'], '', 'Snack' );
		}
		if ( '' === (string) $req->get_param( 'as_of' ) ) {
			ogc_lst_printed_mark( $year, 'meals', 'download' );
		}
		return ogc_lst_csv_response( ogc_lst_csv( array( 'Date', 'Meal', 'Time', '12 and up', '3-11', 'Under 3', 'Total', $last ? 'Change since ' . $last['day'] : 'Change', 'Note' ), $rows ), 'meal-counts-' . $year . '.csv' );
	}
	return $data;
}

/* ================================================================== communion */

function ogc_lst_view_communion( $year, $ctx, $req ) {
	$days    = function_exists( 'ogc_reg_days' ) ? ogc_reg_days( (int) $year ) : array();
	$cm      = ogc_lst_communion_row( $year );
	$printed = ogc_lst_printed_at( $year, 'communion' );
	$seen    = ogc_lst_seen_at( $year, 'communion' );
	$rows    = array();
	$total   = 0;
	$away    = 0;
	foreach ( ogc_lst_regs( $year ) as $rec ) {
		$d    = $rec['data'];
		$here = ogc_lst_here( $rec, $days );
		$n    = 0;
		$out  = 0;
		$who  = array();
		foreach ( (array) $d['people'] as $p ) {
			if ( empty( $p['communing'] ) ) {
				continue;
			}
			if ( $cm && isset( $here[ $p['pid'] ] ) && ! in_array( $cm['date'], $here[ $p['pid'] ], true ) ) {
				$out++;
				continue;
			}
			$n++;
			$who[] = (string) $p['name'];
		}
		$away += $out;
		if ( ! $n ) {
			continue;
		}
		$total += $n;
		$rows[] = array(
			'rid'     => isset( $d['rid'] ) ? $d['rid'] : '',
			'label'   => ogc_lst_label( $d ),
			'sort'    => ogc_lst_surname( $d ),
			'n'       => $n,
			'names'   => $who,
			// Not on the list when it was printed: New (not "Changed"); on it, and different: Changed.
			'added'   => ogc_lst_added_since( $printed, $rec ),
			'new'     => ( $seen && $rec['created_at'] > $seen ) || ogc_lst_added_since( $printed, $rec ),
			'changed' => ! ogc_lst_added_since( $printed, $rec ) && ogc_lst_changed_since( $printed, 'communion', $rec ),
			'sample'  => $rec['sample'],
		);
	}
	usort( $rows, function ( $a, $b ) { return strcmp( $a['sort'], $b['sort'] ); } );
	if ( 'xlsx' === $req->get_param( 'format' ) && function_exists( 'ogc_lst_xlsx_out' ) ) {
		return ogc_lst_xlsx_out( $year, 'communion', array_map( function ( $r ) { return array( $r['label'], $r['rid'], $r['n'], implode( ', ', $r['names'] ) ); }, $rows ), array(
			'Communing'  => $total . ( $cm ? ' on ' . date_i18n( 'D, M j', strtotime( $cm['date'] . ' 12:00:00' ) ) : '' ),
			'Households' => count( $rows ),
			'Not here'   => $away ? $away . ' communing but not here that day (not counted)' : '',
		), array(), '', 'communion' );
	}
	if ( 'csv' === $req->get_param( 'format' ) ) {
		if ( '' === (string) $req->get_param( 'as_of' ) ) {
			ogc_lst_printed_mark( $year, 'communion', 'download' );
		}
		return ogc_lst_csv_response( ogc_lst_csv( array( 'Household', 'Registration', 'Communing' ), array_map( function ( $r ) { return array( $r['label'], $r['rid'], $r['n'] ); }, $rows ) ), 'communion-' . $year . '.csv' );
	}
	return array(
		'total'      => $total,
		'households' => $rows,
		'away'       => $away,
		'date'       => $cm ? $cm['date'] : '',
		'printed'    => $printed,
		'new'        => count( array_filter( $rows, function ( $r ) { return $r['new']; } ) ),
		'changed'    => count( array_filter( $rows, function ( $r ) { return $r['changed'] || $r['added']; } ) ),
	);
}

/* ================================================================== preteens */

function ogc_lst_view_preteens( $year, $ctx, $req ) {
	$days    = function_exists( 'ogc_reg_days' ) ? ogc_reg_days( (int) $year ) : array();
	$paper   = 'paper' === ( isset( $ctx['cfg']['preteen_details'] ) ? $ctx['cfg']['preteen_details'] : '' );
	$ptdays  = array_values( array_filter( array_map( 'trim', explode( '|', isset( $ctx['cfg']['preteen_days'] ) ? $ctx['cfg']['preteen_days'] : '' ) ) ) );
	$viewer  = ogc_lst_viewer( $year, 'preteens' );
	$printed = ogc_lst_printed_at( $year, 'preteens' );
	$seen    = ogc_lst_seen_at( $year, 'preteens' );
	$rows    = array();
	$before  = 0;
	foreach ( ogc_lst_regs( $year ) as $rec ) {
		$d    = $rec['data'];
		$here = ogc_lst_here( $rec, $days );
		$pts  = isset( $d['preteens'] ) ? (array) $d['preteens'] : array();
		$any  = false;
		foreach ( (array) $d['people'] as $p ) {
			if ( empty( $p['preteen'] ) ) {
				continue;
			}
			$any = true;
			if ( ! $viewer ) {
				$rows[] = array();
				continue;
			}
			// The program's days the child is here (only said when not every one of them).
			$on = array();
			foreach ( $days as $dd ) {
				if ( ( ! $ptdays || in_array( $dd['name'], $ptdays, true ) ) && in_array( $dd['date'], isset( $here[ $p['pid'] ] ) ? $here[ $p['pid'] ] : array(), true ) ) {
					$on[] = substr( $dd['name'], 0, 3 );
				}
			}
			$all = $ptdays ? count( $ptdays ) : count( $days );
			$pt  = isset( $pts[ $p['pid'] ] ) ? (array) $pts[ $p['pid'] ] : array();
			$at  = array();
			foreach ( $days as $dd ) {
				if ( ( ! $ptdays || in_array( $dd['name'], $ptdays, true ) ) && in_array( $dd['date'], isset( $here[ $p['pid'] ] ) ? $here[ $p['pid'] ] : array(), true ) ) {
					$at[] = $dd['date'];
				}
			}
			$rows[] = array(
				'pid'      => $p['pid'],
				'name'     => (string) $p['name'],
				'sort'     => ogc_lst_last_word( $p['name'] ) . ' ' . strtolower( (string) $p['name'] ),
				'age'      => isset( $p['age'] ) ? (string) $p['age'] : '',
				'days'     => count( $on ) < $all ? ( $on ? ( count( $on ) > 2 ? $on[0] . '–' . end( $on ) : implode( ', ', $on ) ) : 'Not here' ) : '',
				'on'       => $at,
				'daysAll'  => implode( ', ', $on ),
				'household' => ogc_lst_label( $d ),
				'rid'      => isset( $d['rid'] ) ? $d['rid'] : '',
				'pickup'   => $paper ? '' : ( isset( $d['pickup'] ) ? (string) $d['pickup'] : '' ),
				// From the Lodging Form, which doesn't ask who may pick up: the household's adults are filled
				// in (ogc_reg_clean), so the screen, the paper and the file say "Not asked".
				'unasked'  => ! $paper && 'form' === ( isset( $d['source'] ) ? $d['source'] : '' ),
				'phone'    => isset( $d['household']['phone'] ) ? (string) $d['household']['phone'] : '',
				'medical'  => $paper ? '' : ( isset( $pt['medical'] ) ? (string) $pt['medical'] : '' ),
				'contacts' => $paper ? array() : array_values( array_filter( array_map( function ( $c ) {
					return is_array( $c ) && ! empty( $c['name'] ) ? array( 'name' => (string) $c['name'], 'rel' => isset( $c['rel'] ) ? (string) $c['rel'] : '', 'phone' => isset( $c['phone'] ) ? (string) $c['phone'] : '' ) : null;
				}, isset( $d['contacts'] ) ? (array) $d['contacts'] : array() ) ) ),
				'added'    => ogc_lst_added_since( $printed, $rec ),
				'new'      => ( $seen && $rec['created_at'] > $seen ) || ogc_lst_added_since( $printed, $rec ),
				'changed'  => ! ogc_lst_added_since( $printed, $rec ) && ogc_lst_changed_since( $printed, 'preteens', $rec ),
				'sample'   => $rec['sample'],
			);
		}
		// Registered before the COA put the details online: their rows have none.
		if ( $any && ! $paper && $viewer && empty( $d['contacts'][0]['name'] ) && ! array_filter( $pts, function ( $x ) { return ! empty( $x['medical'] ); } ) && empty( $d['pickupWho'] ) ) {
			$before++;
		}
	}
	if ( $viewer ) {
		usort( $rows, function ( $a, $b ) { return strcmp( $a['sort'], $b['sort'] ); } );
		static $logged = false;
		if ( ! $logged && $rows ) {
			$logged = true;
			ogc_log( 'list_view', $year, 'preteens', array( 'n' => count( $rows ) ) );
		}
	}
	if ( 'xlsx' === $req->get_param( 'format' ) && function_exists( 'ogc_lst_xlsx_out' ) ) {
		if ( ! $viewer ) {
			return ogc_lst_err( 'Preteen committee only', 403 );
		}
		// The check-in sheet: never the medical notes or emergency contacts (those print apart).
		return ogc_lst_xlsx_out( $year, 'preteens', array_map( function ( $r ) {
			return array( $r['name'], is_numeric( $r['age'] ) ? (int) $r['age'] : $r['age'], $r['daysAll'], ( $r['unasked'] ? 'Not asked · Adults: ' : '' ) . $r['pickup'], $r['phone'], $r['household'], $r['rid'] );
		}, $rows ), array(
			'Preteens'      => count( $rows ),
			'Program days'  => implode( ', ', $ptdays ? $ptdays : wp_list_pluck( $days, 'name' ) ),
			'Not in the file' => 'Medical notes and emergency contacts: Print medical, on the Children screen',
		), array(), 'Preteens check-in', 'preteens' );
	}
	if ( 'csv' === $req->get_param( 'format' ) ) {
		if ( ! $viewer ) {
			return ogc_lst_err( 'Preteen committee only', 403 );
		}
		if ( '' === (string) $req->get_param( 'as_of' ) ) {
			ogc_lst_printed_mark( $year, 'preteens', 'download' );
		}
		// The download is the check-in sheet: never the medical notes or emergency contacts.
		return ogc_lst_csv_response( ogc_lst_csv( array( 'Preteen', 'Age', 'Days', 'May pick up', 'Parent phone', 'Household', 'Registration' ), array_map( function ( $r ) {
			return array( $r['name'], $r['age'], $r['days'] ? $r['days'] : 'All', ( $r['unasked'] ? 'Not asked · Adults: ' : '' ) . $r['pickup'], $r['phone'], $r['household'], $r['rid'] );
		}, $rows ) ), 'preteens-checkin-' . $year . '.csv' );
	}
	$program = array();
	foreach ( $days as $dd ) {
		if ( ! $ptdays || in_array( $dd['name'], $ptdays, true ) ) {
			$program[] = array( 'date' => $dd['date'], 'name' => $dd['name'], 'n' => count( array_filter( $rows, function ( $r ) use ( $dd ) { return ! empty( $r['on'] ) && in_array( $dd['date'], $r['on'], true ); } ) ) );
		}
	}
	return array(
		'count'   => count( $rows ),
		'viewer'  => $viewer,
		'paper'   => $paper,
		'rows'    => $viewer ? $rows : array(),
		'days'    => $ptdays,
		'program' => $viewer ? $program : array(),
		'printed' => $printed,
		'before'  => $before,
		'new'     => $viewer ? count( array_filter( $rows, function ( $r ) { return ! empty( $r['new'] ); } ) ) : 0,
		'changed' => $viewer ? count( array_filter( $rows, function ( $r ) { return ! empty( $r['changed'] ) || ! empty( $r['added'] ); } ) ) : 0,
	);
}

/* ================================================================== payments */

function ogc_lst_money( $cents ) {
	return '$' . number_format( $cents / 100, $cents % 100 ? 2 : 0 );
}

function ogc_lst_view_payments( $year, $ctx, $req ) {
	$viewer = ogc_lst_viewer( $year, 'payments' );
	$regs   = array();
	foreach ( ogc_lst_regs( $year, true ) as $r ) {
		$regs[ (int) $r['id'] ] = $r;
	}
	if ( ! $viewer ) {
		return array( 'viewer' => false, 'households' => count( $regs ) );
	}
	if ( ! function_exists( 'ogc_pay_year' ) ) {
		return array( 'viewer' => true, 'none' => true );
	}
	$marks   = ogc_lst_state( $year, 'pay_marks' );
	$marks   = isset( $marks['m'] ) ? (array) $marks['m'] : array();
	$by_pay  = array();
	foreach ( $marks as $mk ) {
		$by_pay[ (int) $mk['payment'] ] = $mk;
	}
	$cfg      = $ctx['cfg'];
	$check_by = isset( $cfg['check_by'] ) ? $cfg['check_by'] : '';
	$ref_by   = isset( $cfg['refunds_by'] ) ? $cfg['refunds_by'] : '';
	$checks   = array();
	$refunds  = array();
	$done     = array();
	$due      = array();
	$tot      = array( 'paid' => 0, 'paid_n' => 0, 'check' => 0, 'refund' => 0, 'refunded' => 0, 'gifts' => 0, 'gifts_n' => 0, 'due' => 0, 'card' => 0, 'desk' => 0, 'checks_in' => 0 );
	$row_of   = function ( $r ) {
		return array( 'record' => (int) $r['id'], 'rid' => isset( $r['data']['rid'] ) ? $r['data']['rid'] : '', 'label' => ogc_lst_label( $r['data'] ), 'sample' => $r['sample'] );
	};
	foreach ( ogc_pay_year( $year ) as $p ) {
		$r = isset( $regs[ $p['record_id'] ] ) ? $regs[ $p['record_id'] ] : null;
		if ( ! $r ) {
			continue;
		}
		$base = $row_of( $r );
		$mk   = isset( $by_pay[ $p['id'] ] ) ? $by_pay[ $p['id'] ] : null;
		if ( 'check' === $p['kind'] && 'pending' === $p['status'] ) {
			$since    = substr( (string) $r['created_at'], 0, 10 );
			$checks[] = array_merge( $base, array(
				'payment' => $p['id'],
				'cents'   => $p['cents'],
				'since'   => $since,
				'waiting' => ogc_lst_days_between( $since, $ctx['today'] ),
				'late'    => $check_by && $ctx['today'] > $check_by,
				'email'   => (bool) $r['email'],
			) );
			$tot['check'] += $p['cents'];
			continue;
		}
		if ( 'refund' === $p['kind'] && in_array( $p['status'], array( 'requested', 'approved' ), true ) ) {
			$asked     = substr( (string) $p['created_at'], 0, 10 );
			$refunds[] = array_merge( $base, array(
				'payment'  => $p['id'],
				'cents'    => $p['cents'],
				'asked'    => $asked,
				'method'   => $p['method'],
				'note'     => $p['note'],
				'approved' => 'approved' === $p['status'],
				'late'     => $ref_by && $asked > $ref_by,
			) );
			$tot['refund'] += $p['cents'];
			continue;
		}
		if ( 'paid' === $p['status'] && in_array( $p['kind'], array( 'charge', 'check', 'desk' ), true ) ) {
			$tot[ 'charge' === $p['kind'] ? 'card' : ( 'desk' === $p['kind'] ? 'desk' : 'checks_in' ) ] += $p['cents'];
		}
		if ( 'refund' === $p['kind'] && 'sent' === $p['status'] ) {
			$tot['refunded'] += $p['cents'];
		}
		// The history: what the committee marked (checks in, refunds sent, desk payments), newest first.
		if ( $mk || 'desk' === $p['kind'] || ( 'check' === $p['kind'] && 'paid' === $p['status'] && ! $p['sample'] ) || ( 'refund' === $p['kind'] && in_array( $p['status'], array( 'sent', 'cancelled' ), true ) ) ) {
			$done[] = array_merge( $base, array(
				'payment' => $p['id'],
				'kind'    => $p['kind'],
				'status'  => $p['status'],
				'cents'   => $p['cents'],
				'method'  => $p['method'],
				'day'     => $mk && ! empty( $mk['date'] ) ? $mk['date'] : substr( (string) $p['updated_at'], 0, 10 ),
				'by'      => $mk ? $mk['by'] : ( $p['by_user'] ? ogc_lst_who( $p['by_user'] ) : '' ),
				'ref'     => $mk && ! empty( $mk['ref'] ) ? $mk['ref'] : '',
				'mark'    => $mk && empty( $mk['undone'] ) && time() - strtotime( $mk['ts'] . ' UTC' ) < DAY_IN_SECONDS ? $mk['id'] : '',
			) );
		}
	}
	foreach ( $regs as $r ) {
		$d  = $r['data'];
		$m  = isset( $d['money'] ) ? (array) $d['money'] : array();
		$st = isset( $d['status'] ) ? $d['status'] : '';
		if ( 'cancelled' === $st ) {
			continue;
		}
		$paid = isset( $m['paid'] ) ? (int) $m['paid'] : 0;
		$tot['paid'] += $paid;
		if ( isset( $m['total'] ) && $paid >= (int) $m['total'] && (int) $m['total'] > 0 ) {
			$tot['paid_n']++;
		}
		$g = isset( $d['price']['gift_cents'] ) ? (int) $d['price']['gift_cents'] : 0;
		if ( $g ) {
			$tot['gifts'] += $g;
			$tot['gifts_n']++;
		}
		$owe = isset( $m['due'] ) ? (int) $m['due'] - (int) ( isset( $m['check'] ) ? $m['check'] : 0 ) - (int) ( isset( $m['pending'] ) ? $m['pending'] : 0 ) : 0;
		if ( $owe > 0 ) {
			$due[]       = array_merge( $row_of( $r ), array( 'cents' => $owe, 'total' => (int) $m['total'], 'paid' => $paid ) );
			$tot['due'] += $owe;
		}
	}
	$by = function ( $k ) { return function ( $a, $b ) use ( $k ) { return strcmp( (string) $a[ $k ], (string) $b[ $k ] ); }; };
	usort( $checks, $by( 'since' ) );
	usort( $refunds, $by( 'asked' ) );
	usort( $done, function ( $a, $b ) { return strcmp( $b['day'], $a['day'] ) ?: $b['payment'] - $a['payment']; } );
	if ( 'csv' === $req->get_param( 'format' ) ) {
		ogc_lst_printed_mark( $year, 'payments', 'download' );
		$rows = array();
		foreach ( $checks as $c ) {
			$rows[] = array( 'Checks due', $c['label'], $c['rid'], number_format( $c['cents'] / 100, 2, '.', '' ), $c['since'], $c['late'] ? 'Overdue' : 'Waiting', '', '' );
		}
		foreach ( $refunds as $c ) {
			$rows[] = array( 'Refunds', $c['label'], $c['rid'], number_format( -$c['cents'] / 100, 2, '.', '' ), $c['asked'], $c['approved'] ? 'Approved' : 'Asked', $c['note'], '' );
		}
		foreach ( $due as $c ) {
			$rows[] = array( 'Balance due', $c['label'], $c['rid'], number_format( $c['cents'] / 100, 2, '.', '' ), '', 'Due', '', '' );
		}
		foreach ( $done as $c ) {
			$neg    = 'refund' === $c['kind'];
			$rows[] = array( 'Received', $c['label'], $c['rid'], number_format( ( $neg ? -1 : 1 ) * $c['cents'] / 100, 2, '.', '' ), $c['day'], $neg ? ( 'sent' === $c['status'] ? 'Refunded' : 'Declined' ) : ucfirst( $c['kind'] === 'desk' ? 'Desk · ' . $c['method'] : 'Check' ), $c['ref'], $c['by'] );
		}
		return ogc_lst_csv_response( ogc_lst_csv( array( 'Section', 'Household', 'Registration', 'Amount', 'Date', 'Status', 'Note', 'By' ), $rows ), 'payments-' . $year . '.csv' );
	}
	$refund_open = ! $ref_by || $ctx['today'] <= ogc_lst_add_days( $ref_by, 14 );
	return array(
		'viewer'   => true,
		'checks'   => $checks,
		'refunds'  => $refunds,
		'due'      => $due,
		'done'     => array_slice( $done, 0, 200 ),
		'totals'   => $tot,
		'check_by' => $check_by,
		'refunds_by' => $ref_by,
		'gift_for' => isset( $cfg['gift_for'] ) ? $cfg['gift_for'] : '',
		'can'      => array(
			'mark'   => ! $ctx['held'] || $refund_open,
			'checks' => ! $ctx['held'],
			'refund' => $refund_open,
			'remind' => ! $ctx['held'] && function_exists( 'ogc_send_mail' ),
		),
		'households' => count( $regs ),
	);
}

/** One mark the committee made (received, refunded, declined, desk), kept so it can be undone. */
function ogc_lst_mark_keep( $year, $mark ) {
	return ogc_lst_state_update( $year, 'pay_marks', function ( $v ) use ( $mark ) {
		$m   = isset( $v['m'] ) ? (array) $v['m'] : array();
		$m[] = $mark;
		return array( 'm' => array_slice( $m, -500 ) );
	} );
}

function ogc_lst_rest_pay( WP_REST_Request $req ) {
	$y   = (int) $req['year'];
	$ctx = ogc_lst_ctx( $y, $req );
	if ( ! ogc_lst_viewer( $y, 'payments' ) ) {
		return ogc_lst_err( 'Treasurer only', 403 );
	}
	if ( ! function_exists( 'ogc_pay_get' ) || ! function_exists( 'ogc_reg_save' ) ) {
		return ogc_lst_err( 'Not available', 501 );
	}
	$p = ogc_pay_get( (int) $req->get_param( 'payment' ) );
	if ( ! $p || (int) $p['year'] !== $y ) {
		return ogc_lst_err( 'Not found', 404 );
	}
	$rec = ogc_record_get( (int) $p['record_id'] );
	if ( ! $rec || 'registrations' !== $rec['kind'] ) {
		return ogc_lst_err( 'Not found', 404 );
	}
	$action = (string) $req->get_param( 'action' );
	$ref    = mb_substr( sanitize_text_field( (string) $req->get_param( 'ref' ) ), 0, 40 );
	$date   = (string) $req->get_param( 'date' );
	$date   = preg_match( '/^\d{4}-\d\d-\d\d$/', $date ) && $date <= $ctx['today'] ? $date : $ctx['today'];
	$data   = $rec['data'];
	$mark   = array( 'id' => 'm' . strtolower( wp_generate_password( 8, false, false ) ), 'payment' => $p['id'], 'action' => $action, 'prev' => array( 'status' => $p['status'], 'cents' => $p['cents'], 'note' => $p['note'] ), 'by' => ogc_lst_who( get_current_user_id() ), 'uid' => get_current_user_id(), 'ts' => ogc_now(), 'date' => $date, 'ref' => $ref );
	$who    = ogc_lst_label( $data );
	switch ( $action ) {
		case 'received':
			if ( 'check' !== $p['kind'] || 'pending' !== $p['status'] ) {
				return ogc_lst_err( 'No check to come', 409 );
			}
			if ( $ctx['held'] ) {
				return ogc_lst_err( 'Held · Read only', 423 );
			}
			$cents = $req->get_param( 'cents' ) !== null && '' !== $req->get_param( 'cents' ) ? (int) $req->get_param( 'cents' ) : $p['cents'];
			if ( $cents <= 0 || $cents > 2000000 ) {
				return ogc_lst_err( 'Enter an amount', 400, array( 'field' => 'cents' ) );
			}
			ogc_pay_set( $p['id'], array( 'status' => 'paid', 'cents' => $cents, 'ref' => $ref ? 'Check ' . $ref : '', 'note' => 'Received ' . $date ) );
			// Less than the check expected: the rest is still to come.
			if ( $cents < $p['cents'] ) {
				$mark['rest'] = ogc_pay_add( $rec, 'check', 'check', $p['cents'] - $cents, 'pending', array( 'note' => 'Rest of check' ) );
			}
			$data['checkGot'] = $date;
			ogc_reg_note_history( $data, 'Check received · ' . ogc_lst_money( $cents ) . ( $ref ? ' · No. ' . $ref : '' ), 'committee' );
			$say = $who . ' · Check received · ' . ogc_lst_money( $cents );
			break;
		case 'refunded':
		case 'declined':
			if ( 'refund' !== $p['kind'] || ! in_array( $p['status'], array( 'requested', 'approved' ), true ) ) {
				return ogc_lst_err( 'No refund open', 409 );
			}
			$open = empty( $ctx['cfg']['refunds_by'] ) || $ctx['today'] <= ogc_lst_add_days( $ctx['cfg']['refunds_by'], 14 );
			if ( ! $open ) {
				return ogc_lst_err( 'Held · Read only', 423 );
			}
			ogc_pay_set( $p['id'], array( 'status' => 'refunded' === $action ? 'sent' : 'cancelled', 'ref' => $ref ? ( 'card' === $p['method'] ? $ref : 'Check ' . $ref ) : $p['ref'], 'note' => ( 'refunded' === $action ? 'Refunded ' : 'Declined ' ) . $date ) );
			ogc_reg_note_history( $data, ( 'refunded' === $action ? 'Refunded ' : 'Refund declined · ' ) . ogc_lst_money( $p['cents'] ), 'committee' );
			$say = $who . ' · ' . ( 'refunded' === $action ? 'Refunded ' : 'Declined ' ) . ogc_lst_money( $p['cents'] );
			break;
		default:
			return ogc_lst_err( 'Unknown action' );
	}
	ogc_reg_save( $rec, $data );
	ogc_lst_mark_keep( $y, $mark );
	ogc_log( 'pay_mark', $y, 'payments', array( 'payment' => $p['id'], 'action' => $action ) );
	return rest_ensure_response( array( 'ok' => true, 'mark' => $mark['id'], 'say' => $say ) );
}

/** Undo a mark (the toast's Undo, or within a day from Received): the payment as it was. */
function ogc_lst_rest_pay_undo( WP_REST_Request $req ) {
	$y = (int) $req['year'];
	if ( ! ogc_lst_viewer( $y, 'payments' ) ) {
		return ogc_lst_err( 'Treasurer only', 403 );
	}
	$id    = (string) $req->get_param( 'mark' );
	$marks = ogc_lst_state( $y, 'pay_marks' );
	$found = null;
	foreach ( isset( $marks['m'] ) ? (array) $marks['m'] : array() as $mk ) {
		if ( $mk['id'] === $id ) {
			$found = $mk;
		}
	}
	if ( ! $found || ! empty( $found['undone'] ) || time() - strtotime( $found['ts'] . ' UTC' ) > DAY_IN_SECONDS ) {
		return ogc_lst_err( 'Can’t undo', 409 );
	}
	$p   = ogc_pay_get( (int) $found['payment'] );
	$rec = $p ? ogc_record_get( (int) $p['record_id'] ) : null;
	if ( ! $p || ! $rec ) {
		return ogc_lst_err( 'Not found', 404 );
	}
	if ( 'desk' === $found['action'] ) {
		ogc_pay_set( $p['id'], array( 'status' => 'cancelled', 'note' => 'Undone' ) );
	} else {
		ogc_pay_set( $p['id'], array( 'status' => $found['prev']['status'], 'cents' => (int) $found['prev']['cents'], 'note' => (string) $found['prev']['note'], 'ref' => '' ) );
	}
	if ( ! empty( $found['rest'] ) ) {
		ogc_pay_set( (int) $found['rest'], array( 'status' => 'cancelled', 'note' => 'Undone' ) );
	}
	$data = $rec['data'];
	if ( 'received' === $found['action'] ) {
		unset( $data['checkGot'] );
	}
	ogc_reg_note_history( $data, 'Undone · ' . ( isset( $found['action'] ) ? $found['action'] : '' ), 'committee' );
	ogc_reg_save( $rec, $data );
	ogc_lst_state_update( $y, 'pay_marks', function ( $v ) use ( $id ) {
		foreach ( $v['m'] as &$mk ) {
			if ( $mk['id'] === $id ) {
				$mk['undone'] = ogc_now();
			}
		}
		unset( $mk );
		return $v;
	} );
	ogc_log( 'pay_undo', $y, 'payments', array( 'payment' => $p['id'] ) );
	return rest_ensure_response( array( 'ok' => true, 'say' => 'Undone' ) );
}

/** A payment taken at the desk (cash or check): into the same ledger. */
function ogc_lst_rest_pay_add( WP_REST_Request $req ) {
	$y = (int) $req['year'];
	if ( ! ogc_lst_viewer( $y, 'payments' ) ) {
		return ogc_lst_err( 'Treasurer only', 403 );
	}
	$rec = ogc_record_get( (int) $req->get_param( 'record' ) );
	if ( ! $rec || 'registrations' !== $rec['kind'] || (int) $rec['year'] !== $y || ! function_exists( 'ogc_pay_add' ) ) {
		return ogc_lst_err( 'Not found', 404 );
	}
	$cents  = (int) $req->get_param( 'cents' );
	$method = in_array( $req->get_param( 'method' ), array( 'cash', 'check' ), true ) ? $req->get_param( 'method' ) : 'cash';
	if ( $cents <= 0 || $cents > 2000000 ) {
		return ogc_lst_err( 'Enter an amount', 400, array( 'field' => 'cents' ) );
	}
	$ref  = mb_substr( sanitize_text_field( (string) $req->get_param( 'ref' ) ), 0, 40 );
	$id   = ogc_pay_add( $rec, 'desk', $method, $cents, 'paid', array( 'note' => 'At the desk', 'ref' => $ref ? 'Check ' . $ref : '' ) );
	$data = $rec['data'];
	ogc_reg_note_history( $data, 'Paid at the desk · ' . ogc_lst_money( $cents ), 'committee' );
	ogc_reg_save( $rec, $data );
	$mark = array( 'id' => 'm' . strtolower( wp_generate_password( 8, false, false ) ), 'payment' => $id, 'action' => 'desk', 'prev' => array(), 'by' => ogc_lst_who( get_current_user_id() ), 'uid' => get_current_user_id(), 'ts' => ogc_now(), 'date' => ogc_lst_now( $y )['date'], 'ref' => $ref );
	ogc_lst_mark_keep( $y, $mark );
	ogc_log( 'pay_desk', $y, 'payments', array( 'payment' => $id ) );
	return rest_ensure_response( array( 'ok' => true, 'mark' => $mark['id'], 'say' => ogc_lst_label( $data ) . ' · Paid ' . ogc_lst_money( $cents ) ) );
}

/** A short reminder to a household whose check hasn't come (once a week at most). */
function ogc_lst_rest_pay_remind( WP_REST_Request $req ) {
	$y = (int) $req['year'];
	if ( ! ogc_lst_viewer( $y, 'payments' ) ) {
		return ogc_lst_err( 'Treasurer only', 403 );
	}
	$p   = function_exists( 'ogc_pay_get' ) ? ogc_pay_get( (int) $req->get_param( 'payment' ) ) : null;
	$rec = $p ? ogc_record_get( (int) $p['record_id'] ) : null;
	if ( ! $p || ! $rec || (int) $p['year'] !== $y || 'check' !== $p['kind'] || 'pending' !== $p['status'] ) {
		return ogc_lst_err( 'No check to come', 409 );
	}
	$cfg   = ogc_lst_ctx( $y )['cfg'];
	$text  = ogc_lst_remind_text( $y, $rec, $p, $cfg );
	if ( $req->get_param( 'preview' ) ) {
		return rest_ensure_response( array( 'to' => function_exists( 'ogc_reg_mask' ) ? ogc_reg_mask( $rec['email'] ) : '', 'subject' => $text[0], 'body' => $text[1] ) );
	}
	$sent = ogc_lst_state( $y, 'pay_reminded' );
	if ( isset( $sent[ $p['id'] ] ) && time() - strtotime( $sent[ $p['id'] ] . ' UTC' ) < 7 * DAY_IN_SECONDS ) {
		return ogc_lst_err( 'Reminded · This week', 429 );
	}
	if ( ! $rec['email'] || ! function_exists( 'ogc_send_mail' ) ) {
		return ogc_lst_err( 'No email', 400 );
	}
	ogc_send_mail( $rec['email'], $text[0], $text[1], array( 'kind' => 'reminder', 'year' => $y ) );
	ogc_lst_state_update( $y, 'pay_reminded', function ( $v ) use ( $p ) {
		$v[ $p['id'] ] = ogc_now();
		return $v;
	} );
	ogc_log( 'pay_remind', $y, 'payments', array( 'payment' => $p['id'] ) );
	return rest_ensure_response( array( 'ok' => true, 'say' => ogc_lst_label( $rec['data'] ) . ' · Reminder sent' ) );
}

function ogc_lst_remind_text( $y, $rec, $p, $cfg ) {
	$rid   = isset( $rec['data']['rid'] ) ? $rec['data']['rid'] : '';
	$payee = isset( $cfg['check_payee'] ) ? $cfg['check_payee'] : '';
	$addr  = isset( $cfg['check_address'] ) ? str_replace( '|', "\n", $cfg['check_address'] ) : '';
	$by    = ! empty( $cfg['check_by'] ) ? date_i18n( 'F j', strtotime( $cfg['check_by'] . ' 12:00:00' ) ) : '';
	$body  = implode( "\n", array_filter( array(
		'Check to come · ' . ogc_lst_money( $p['cents'] ),
		'Registration ' . $rid,
		'',
		$payee ? 'Payable to ' . $payee : '',
		$addr ? "Mail to\n" . $addr : '',
		$by ? 'By ' . $by : '',
		'',
		'Please write ' . $rid . ' on the check.',
	), function ( $l ) { return null !== $l; } ) );
	return array( $y . ' Annual Conference · Check to come', $body );
}

/* ================================================================== the call-in line */

/** A schedule row's lasting key (its id, or its day and title). */
function ogc_lst_row_key( $r ) {
	if ( ! empty( $r['_id'] ) ) {
		return (string) $r['_id'];
	}
	return 'k' . substr( md5( strtolower( ( isset( $r['day'] ) ? $r['day'] : '' ) . '|' . ( isset( $r['title'] ) ? $r['title'] : '' ) . '|' . ( isset( $r['start'] ) ? $r['start'] : '' ) ) ), 0, 10 );
}

function ogc_lst_yes( $v ) {
	return (bool) preg_match( '/^(y|yes|true|1|x|✓|on)$/i', trim( (string) $v ) );
}

/**
 * The call-in line's list from the schedule: what's live on the line, and what's recorded for playback.
 * A playback number is given once, the first time its row is seen recorded, and kept (state
 * callin_ids): a row added later gets the next free number of its day, and a removed row's number is
 * retired, so a number printed in The Testimony never moves.
 */
function ogc_lst_view_callin( $year, $ctx, $req ) {
	$days = function_exists( 'ogc_reg_days' ) ? ogc_reg_days( (int) $year ) : array();
	$f    = ogc_file_get( (int) $year, 'schedule' );
	$set  = ogc_lst_kv( $year, 'settings' );
	$rows = $f ? $f['rows'] : array();
	// Older years kept one mark for both: with no "recorded" column used, what's on the line is recorded.
	$uses = (bool) array_filter( $rows, function ( $r ) { return isset( $r['recorded'] ) && '' !== trim( (string) $r['recorded'] ); } );
	$list = array();
	foreach ( $rows as $r ) {
		$live = ogc_lst_yes( isset( $r['call_in'] ) ? $r['call_in'] : '' );
		$rec  = $uses ? ogc_lst_yes( isset( $r['recorded'] ) ? $r['recorded'] : '' ) : $live;
		if ( ! $live && ! $rec ) {
			continue;
		}
		$i = ogc_lst_day_index( $days, isset( $r['day'] ) ? $r['day'] : '' );
		if ( $i < 0 ) {
			continue;
		}
		$s      = ogc_lst_min( isset( $r['start'] ) ? $r['start'] : '' );
		$list[] = array( 'key' => ogc_lst_row_key( $r ), 'date' => $days[ $i ]['date'], 'title' => (string) $r['title'], 'when' => ogc_lst_when( $r ), 'sort' => null !== $s ? $s : (int) ogc_lst_min( isset( $r['sort_time'] ) ? $r['sort_time'] : '' ), 'place' => isset( $r['place'] ) ? (string) $r['place'] : '', 'live' => $live, 'recorded' => $rec );
	}
	usort( $list, function ( $a, $b ) { return strcmp( $a['date'], $b['date'] ) ?: $a['sort'] - $b['sort']; } );
	// Numbers: given once, kept.
	$ids     = ogc_lst_state( $year, 'callin_ids' );
	$map     = isset( $ids['map'] ) ? (array) $ids['map'] : array();
	$missing = array_filter( $list, function ( $r ) use ( $map ) { return $r['recorded'] && empty( $map[ $r['key'] ] ); } );
	if ( $missing && ogc_is_member( $year ) ) {
		$ids = ogc_lst_state_update( $year, 'callin_ids', function ( $v ) use ( $list ) {
			$map = isset( $v['map'] ) ? (array) $v['map'] : array();
			$at  = isset( $v['at'] ) ? (array) $v['at'] : array();
			$max = array();
			foreach ( $map as $id ) {
				list( $md, $n ) = array_pad( explode( '-', $id['id'] ), 2, 0 );
				$max[ $md ]     = max( isset( $max[ $md ] ) ? $max[ $md ] : 0, (int) $n );
			}
			foreach ( $list as $r ) {
				if ( $r['recorded'] && empty( $map[ $r['key'] ] ) ) {
					$md               = substr( str_replace( '-', '', $r['date'] ), 4 );
					$max[ $md ]       = ( isset( $max[ $md ] ) ? $max[ $md ] : 0 ) + 1;
					$map[ $r['key'] ] = array( 'id' => $md . '-' . $max[ $md ], 'at' => ogc_now() );
				}
			}
			return array( 'map' => $map );
		} );
		$map = is_wp_error( $ids ) ? $map : $ids['map'];
	}
	$printed = ogc_lst_printed_at( $year, 'callin' );
	$named   = array();
	$pl      = ogc_file_get( (int) $year, 'places' );
	foreach ( $pl ? $pl['rows'] : array() as $p ) {
		if ( ! empty( $p['code'] ) ) {
			$named[ strtoupper( $p['code'] ) ] = isset( $p['name'] ) ? $p['name'] : '';
		}
	}
	foreach ( $list as &$r ) {
		$id            = $r['recorded'] && ! empty( $map[ $r['key'] ] ) ? $map[ $r['key'] ] : null;
		$r['playback'] = $id ? $id['id'] : '';
		$r['new']      = $printed && $id && $id['at'] > $printed['at'];
		$code          = strtoupper( trim( $r['place'] ) );
		$r['where']    = isset( $named[ $code ] ) && $named[ $code ] ? $named[ $code ] : $r['place'];
		unset( $r['sort'] );
	}
	unset( $r );
	$posted = function_exists( 'ogc_coa_posted' ) ? ogc_coa_posted( $year, 'schedule_posted' ) : true;
	if ( 'csv' === $req->get_param( 'format' ) ) {
		ogc_lst_printed_mark( $year, 'callin', 'download' );
		return ogc_lst_csv_response( ogc_lst_csv( array( 'Date', 'Time', 'What', 'Where', 'Live', 'Playback' ), array_map( function ( $r ) {
			return array( $r['date'], $r['when'], $r['title'], $r['where'], $r['live'] ? 'yes' : '', $r['playback'] );
		}, $list ) ), 'call-in-' . $year . '.csv' );
	}
	return array(
		'rows'    => $list,
		'number'  => isset( $set['call_in_number'] ) ? $set['call_in_number'] : '',
		'pin'     => isset( $set['call_in_pin'] ) ? $set['call_in_pin'] : '',
		'zone'    => isset( $set['timezone_label'] ) ? $set['timezone_label'] : '',
		'posted'  => $posted,
		'printed' => $printed,
		'split'   => $uses,
		'new'     => count( array_filter( $list, function ( $r ) { return $r['new']; } ) ),
	);
}

/* ================================================================== printed, seen */

function ogc_lst_printed_at( $year, $view ) {
	$p = ogc_lst_state( $year, 'lists_printed' );
	return isset( $p[ $view ] ) ? $p[ $view ] : null;
}

/** What a household is on a list (communion: who communes; preteens: each child's name, age, days and
 * who may pick up), so "Changed" means the list changed, not any save to the registration. */
function ogc_lst_sig( $view, $d ) {
	$out = array();
	foreach ( (array) ( isset( $d['people'] ) ? $d['people'] : array() ) as $p ) {
		if ( 'communion' === $view && ! empty( $p['communing'] ) ) {
			$out[] = array( isset( $p['pid'] ) ? $p['pid'] : '', isset( $p['nights'] ) ? $p['nights'] : array() );
		} elseif ( 'preteens' === $view && ! empty( $p['preteen'] ) ) {
			$out[] = array( isset( $p['name'] ) ? $p['name'] : '', isset( $p['age'] ) ? $p['age'] : '', isset( $p['nights'] ) ? $p['nights'] : array() );
		}
	}
	if ( 'preteens' === $view ) {
		$out[] = array( isset( $d['pickup'] ) ? $d['pickup'] : '', isset( $d['household']['phone'] ) ? $d['household']['phone'] : '' );
	}
	return substr( md5( wp_json_encode( $out ) ), 0, 12 );
}

/** Added since printed: the print kept who was on the list, and this household wasn't. */
function ogc_lst_added_since( $printed, $rec ) {
	$rid = isset( $rec['data']['rid'] ) ? (string) $rec['data']['rid'] : '';
	return $printed && isset( $printed['sig'] ) && is_array( $printed['sig'] ) && $printed['sig'] && '' !== $rid && ! isset( $printed['sig'][ $rid ] );
}

/** Changed since printed: by the list's own fields when the print kept them, else by the date. */
function ogc_lst_changed_since( $printed, $view, $rec ) {
	if ( ! $printed ) {
		return false;
	}
	$rid = isset( $rec['data']['rid'] ) ? (string) $rec['data']['rid'] : '';
	if ( isset( $printed['sig'] ) && is_array( $printed['sig'] ) ) {
		return ! isset( $printed['sig'][ $rid ] ) || $printed['sig'][ $rid ] !== ogc_lst_sig( $view, $rec['data'] );
	}
	return $rec['updated_at'] > $printed['at'];
}

/** A list printed or downloaded: kept (changes since are marked), and logged. */
function ogc_lst_printed_mark( $year, $view, $what ) {
	$sig = array();
	if ( in_array( $view, array( 'communion', 'preteens' ), true ) ) {
		foreach ( ogc_lst_regs( $year ) as $r ) {
			if ( ! empty( $r['data']['rid'] ) ) {
				$sig[ (string) $r['data']['rid'] ] = ogc_lst_sig( $view, $r['data'] );
			}
		}
	}
	ogc_lst_state_update( $year, 'lists_printed', function ( $v ) use ( $view, $what, $sig ) {
		$v[ $view ] = array( 'at' => ogc_now(), 'by' => ogc_lst_who( get_current_user_id() ), 'what' => $what, 'sig' => $sig );
		return $v;
	} );
	ogc_log( 'list_' . ( 'print' === $what ? 'print' : 'download' ), (int) $year, $view, array() );
}

function ogc_lst_seen_at( $year, $view ) {
	$uid = get_current_user_id();
	if ( ! $uid ) {
		return '';
	}
	$m = get_user_meta( $uid, 'ogc_lists_seen_' . (int) $year, true );
	return is_array( $m ) && isset( $m[ $view ] ) ? $m[ $view ] : '';
}

/* ================================================================== a year's people cleared */

/** The year as counts, kept when its people are cleared (the year's record). */
function ogc_lst_record_counts( $year ) {
	$regs = ogc_lst_regs( $year );
	list( $meals, , $commun ) = ogc_lst_meal_counts( $year, $regs );
	$sent  = ogc_lst_sent( $year );
	$pre   = 0;
	$ppl   = 0;
	$comm  = 0;
	foreach ( $regs as $r ) {
		foreach ( (array) $r['data']['people'] as $p ) {
			$ppl++;
			$pre  += ! empty( $p['preteen'] ) ? 1 : 0;
			$comm += ! empty( $p['communing'] ) ? 1 : 0;
		}
	}
	$money = array();
	if ( function_exists( 'ogc_pay_year' ) ) {
		foreach ( ogc_pay_year( $year ) as $p ) {
			$k           = $p['kind'] . ':' . $p['status'];
			$money[ $k ] = ( isset( $money[ $k ] ) ? $money[ $k ] : 0 ) + $p['cents'];
		}
	}
	return apply_filters( 'ogc_lists_record', array(
		'meals'      => array_map( function ( $m ) { return array( 'key' => $m['key'], 'date' => $m['date'], 'title' => $m['title'], 'when' => $m['when'], 'counts' => $m['counts'], 'total' => $m['total'] ); }, $meals ),
		'sent'       => $sent ? array( 'day' => $sent[0]['day'], 'by' => $sent[0]['by'], 'final' => ! empty( $sent[0]['final'] ) ) : null,
		'communion'  => $commun ? $commun : $comm,
		'households' => count( $regs ),
		'people'     => $ppl,
		'preteens'   => $pre,
		'money'      => $money,
	), $year );
}

/** Clear a year's people (the security plan: 60 days after the Conference). What goes: phones, medical
 * notes, emergency contacts, who may pick up, teams' players and phones, credit asks. The households'
 * names and emails stay for next year's Reuse until the Advisors decide (NOTES/questions-lists.md). */
function ogc_lst_clear_year( $year ) {
	$year = (int) $year;
	if ( ogc_lst_state( $year, 'lists_cleared', null ) ) {
		return false;
	}
	ogc_state_put( $year, 'lists_record', ogc_lst_record_counts( $year ) );
	$n = 0;
	foreach ( ogc_records( $year, 'registrations' ) as $r ) {
		$d = $r['data'];
		unset( $d['contacts'], $d['pickup'], $d['pickupWho'], $d['pickupOther'] );
		foreach ( isset( $d['preteens'] ) ? (array) $d['preteens'] : array() as $pid => $pt ) {
			$d['preteens'][ $pid ] = array( 'cleared' => true );
		}
		if ( isset( $d['household']['phone'] ) ) {
			$d['household']['phone'] = '';
		}
		if ( isset( $d['helper']['phone'] ) ) {
			$d['helper']['phone'] = '';
		}
		if ( isset( $d['stay']['needs'] ) ) {
			$d['stay']['needs'] = '';
		}
		$d['cleared'] = ogc_now();
		ogc_record_update( $r['id'], $d, $r['email'] );
		$n++;
	}
	foreach ( array( 'teams', 'credits' ) as $kind ) {
		foreach ( ogc_records( $year, $kind ) as $r ) {
			$keep = 'teams' === $kind ? array( 'tid' => isset( $r['data']['tid'] ) ? $r['data']['tid'] : '', 'size' => count( (array) ( isset( $r['data']['players'] ) ? $r['data']['players'] : array() ) ), 'status' => isset( $r['data']['status'] ) ? $r['data']['status'] : '' ) : array( 'amount' => isset( $r['data']['amount'] ) ? $r['data']['amount'] : 0 );
			ogc_record_update( $r['id'], array_merge( $keep, array( 'cleared' => true ) ), '' );
		}
	}
	do_action( 'ogc_year_people_cleared', $year );
	ogc_state_put( $year, 'lists_cleared', array( 'at' => ogc_now(), 'day' => ogc_lst_now( $year )['date'], 'households' => $n ) );
	ogc_log( 'people_cleared', $year, 'lists', array( 'n' => $n ) );
	return true;
}

/** Is it time? (the day after end + clear_after_days, the campus's clock; never a preview date) */
function ogc_lst_clear_due( $year ) {
	$ctx = ogc_lst_ctx( $year );
	return $ctx['clear_on'] && $ctx['today'] > $ctx['clear_on'] && ! $ctx['cleared'];
}

add_action( 'ogc_daily', function () {
	foreach ( ogc_years_list() as $y ) {
		if ( ogc_lst_clear_due( $y ) ) {
			ogc_lst_clear_year( $y );
		}
	}
} );

/* ================================================================== the routes */

add_action( 'rest_api_init', function () {
	$Y      = '(?P<year>\d{4})';
	$member = function ( WP_REST_Request $q ) {
		return ogc_valid_year( $q['year'] ) && ogc_is_member( $q['year'] ) ? true : ogc_rest_denied();
	};
	$r = function ( $path, $methods, $cb ) use ( $member ) {
		register_rest_route( OGC_NS, $path, array( 'methods' => $methods, 'callback' => $cb, 'permission_callback' => $member ) );
	};
	$r( "/lists/$Y/(?P<view>meals|communion|preteens|payments|callin)", 'GET', 'ogc_lst_rest_view' );
	$r( "/lists/$Y/meals/send", 'POST', 'ogc_lst_rest_send' );
	$r( "/lists/$Y/meals/undo", 'POST', 'ogc_lst_rest_send_undo' );
	$r( "/lists/$Y/settings", 'PUT', 'ogc_lst_rest_settings' );
	$r( "/lists/$Y/access", 'GET', 'ogc_lst_rest_access' );
	$r( "/lists/$Y/access", 'PUT', 'ogc_lst_rest_access_set' );
	$r( "/lists/$Y/pay", 'POST', 'ogc_lst_rest_pay' );
	$r( "/lists/$Y/pay/undo", 'POST', 'ogc_lst_rest_pay_undo' );
	$r( "/lists/$Y/pay/add", 'POST', 'ogc_lst_rest_pay_add' );
	$r( "/lists/$Y/pay/remind", 'POST', 'ogc_lst_rest_pay_remind' );
	$r( "/lists/$Y/printed", 'POST', 'ogc_lst_rest_printed' );
	$r( "/lists/$Y/seen", 'POST', 'ogc_lst_rest_seen' );
} );

/** What every view's answer starts with: where the year stands, which lists have something, who you are. */
function ogc_lst_head( $year, $ctx ) {
	$regs = ogc_lst_regs( $year );
	$pre  = 0;
	$com  = 0;
	foreach ( $regs as $r ) {
		foreach ( (array) $r['data']['people'] as $p ) {
			$pre += ! empty( $p['preteen'] ) ? 1 : 0;
			$com += ! empty( $p['communing'] ) ? 1 : 0;
		}
	}
	$pay = function_exists( 'ogc_pay_year' ) ? count( ogc_pay_year( $year ) ) : 0;
	$s   = ogc_lst_kv( $year, 'settings' );
	$cl  = $ctx['cleared'];
	return array(
		'year'     => (int) $year,
		'today'    => $ctx['today'],
		'start'    => $ctx['start'],
		'end'      => $ctx['end'],
		'held'     => $ctx['held'],
		'phase'    => $ctx['phase'],
		'opens'    => isset( $ctx['cfg']['opens'] ) && '9999-12-31' !== $ctx['cfg']['opens'] ? $ctx['cfg']['opens'] : '',
		'set_up'   => ! empty( $ctx['cfg']['nights'] ),
		'clear_on' => $ctx['clear_on'],
		'cleared'  => $cl ? $cl['day'] : '',
		'regs'     => count( $regs ),
		// Households imported from the Lodging Form: it asks no communion, preteen or meal questions,
		// so the lists say so rather than count them as answers.
		'from_form' => count( array_filter( $regs, function ( $r ) { return 'form' === ( isset( $r['data']['source'] ) ? $r['data']['source'] : '' ); } ) ),
		'samples'  => (bool) array_filter( $regs, function ( $r ) { return $r['sample']; } ),
		'has'      => array( 'meals' => true, 'communion' => $com > 0 || $cl, 'preteens' => $pre > 0 || $cl, 'payments' => $pay > 0 || $cl, 'callin' => true ),
		'viewer'   => array( 'preteens' => ogc_lst_viewer( $year, 'preteens' ), 'payments' => ogc_lst_viewer( $year, 'payments' ) ),
		'choose'   => ogc_lst_can_choose( $year ),
		'webmaster' => ogc_is_webmaster(),
		'owners'   => array_filter( array(
			'registration' => isset( $s['owner_registration'] ) ? $s['owner_registration'] : '',
			'schedule'     => isset( $s['owner_schedule'] ) ? $s['owner_schedule'] : '',
		) ),
		'tz'       => isset( $s['timezone'] ) ? $s['timezone'] : 'America/Indiana/Indianapolis',
		'now'      => $ctx['now'],
		// "Oct 13, 9:40 PM" on the campus's clock: every list says when it was made.
		'as_of'    => date_i18n( 'M j', strtotime( $ctx['now']['date'] . ' 12:00:00' ) ) . ', ' . ogc_lst_hm( $ctx['now']['min'] ),
	);
}

function ogc_lst_rest_view( WP_REST_Request $req ) {
	$y    = (int) $req['year'];
	$view = (string) $req['view'];
	if ( ! ogc_year_get( $y ) ) {
		return ogc_lst_err( 'No such year', 404 );
	}
	// Clearing waits for no one: a list opened after the day clears the year first.
	if ( ogc_lst_clear_due( $y ) ) {
		ogc_lst_clear_year( $y );
	}
	$ctx  = ogc_lst_ctx( $y, $req );
	$head = ogc_lst_head( $y, $ctx );
	if ( $ctx['cleared'] && 'callin' !== $view ) {
		if ( 'csv' === $req->get_param( 'format' ) ) {
			$rec  = ogc_lst_state( $y, 'lists_record' );
			$rows = array_map( function ( $m ) { return array( $m['date'], $m['title'], $m['when'], $m['counts']['adult'], $m['counts']['child'], $m['counts']['baby'], $m['total'] ); }, isset( $rec['meals'] ) ? $rec['meals'] : array() );
			return ogc_lst_csv_response( ogc_lst_csv( array( 'Date', 'Meal', 'Time', '12 and up', '3-11', 'Under 3', 'Total' ), $rows ), 'meal-counts-' . $y . '.csv' );
		}
		$rec = ogc_lst_state( $y, 'lists_record' );
		if ( 'payments' === $view && ! $head['viewer']['payments'] ) {
			unset( $rec['money'] );
		}
		return rest_ensure_response( array( 'head' => $head, 'record' => $rec ) );
	}
	$fn  = 'ogc_lst_view_' . $view;
	$out = $fn( $y, $ctx, $req );
	// "New since you looked": this view is marked with the marker as it was; the next one starts from now.
	// Not while seeing as, previewing a date, or downloading: those aren't this person looking now.
	if ( in_array( $view, array( 'communion', 'preteens' ), true ) && is_array( $out ) && get_current_user_id() && ! $req->get_param( 'as' ) && ! $req->get_param( 'as_of' ) && ! $req->get_param( 'format' ) ) {
		$m          = get_user_meta( get_current_user_id(), 'ogc_lists_seen_' . $y, true );
		$m          = is_array( $m ) ? $m : array();
		$m[ $view ] = ogc_now();
		update_user_meta( get_current_user_id(), 'ogc_lists_seen_' . $y, $m );
	}
	if ( $out instanceof WP_REST_Response || is_wp_error( $out ) ) {
		return $out;
	}
	return rest_ensure_response( array( 'head' => $head, 'list' => $out ) );
}

function ogc_lst_rest_send( WP_REST_Request $req ) {
	$y   = (int) $req['year'];
	$ctx = ogc_lst_ctx( $y, $req );
	if ( $ctx['held'] ) {
		return ogc_lst_err( 'Held · Read only', 423 );
	}
	$how   = 'email' === $req->get_param( 'how' ) ? 'email' : 'mark';
	$set   = ogc_lst_state( $y, 'lists_settings' );
	$to    = isset( $set['caterer_email'] ) ? $set['caterer_email'] : '';
	if ( 'email' === $how && ! is_email( $to ) ) {
		return ogc_lst_err( 'Add the caterer’s email', 400, array( 'field' => 'caterer_email' ) );
	}
	$regs    = ogc_lst_regs( $y );
	list( $meals, $per ) = ogc_lst_meal_counts( $y, $regs );
	$unasked = ogc_lst_not_asked( $regs );
	$all     = ogc_lst_sent( $y );
	$last    = $all ? $all[0] : null;
	$counts  = array();
	foreach ( $meals as $m ) {
		$counts[ $m['key'] ] = array_merge( $m['counts'], array( 'title' => $m['title'], 'date' => $m['date'], 'when' => $m['when'], 'est' => (int) $m['est'] ) );
		if ( 'communion' === ( isset( $m['from'] ) ? $m['from'] : '' ) && $unasked ) {
			$counts[ $m['key'] ]['not_asked'] = $unasked;
		}
	}
	$v = array(
		'at'     => ogc_now(),
		'day'    => $ctx['today'],
		'by'     => ogc_lst_who( get_current_user_id() ),
		'uid'    => get_current_user_id(),
		'how'    => $how,
		'final'  => (bool) $req->get_param( 'final' ),
		'to'     => 'email' === $how ? $to : '',
		'counts' => $counts,
		'per'    => $per,
	);
	if ( 'email' === $how ) {
		$me   = ogc_current_email();
		// Who it's from, so the caterer can answer a person (critique: no name, no way to reply).
		$vw   = function_exists( 'ogc_app_viewer' ) ? ogc_app_viewer( $y ) : array( 'coa' => false, 'committees' => array() );
		$comm = in_array( 'food', (array) ( isset( $vw['committees'] ) ? $vw['committees'] : array() ), true ) ? 'Food committee' : ( ! empty( $vw['coa'] ) ? 'Committee of Arrangements' : '' );
		$o    = array(
			'from'      => trim( $v['by'] . ( $comm ? ', ' . $comm : '' ), ', ' ) . ( $me ? ' · Reply to this email' : '' ),
			'not_asked' => $unasked,
		);
		$html = ogc_lst_caterer_html( $y, $meals, $last, $v['final'], $o );
		$text = ogc_lst_caterer_text( $y, $meals, $last, $v['final'], $o );
		// "Meal counts · May 21 · Update 2": the day, and which one it is, so the newest is plain in an inbox.
		$n    = count( $all );
		$subj = $y . ' Annual Conference · Meal counts · ' . date_i18n( 'M j', strtotime( $v['day'] . ' 12:00:00' ) ) . ( $v['final'] ? ' · Final' : ( $n ? ' · Update ' . $n : '' ) );
		ogc_send_mail( $to, $subj, $html, array( 'kind' => 'caterer', 'year' => $y, 'reply_to' => $me, 'text' => $text ) );
		if ( $me && $me !== strtolower( $to ) ) {
			ogc_send_mail( $me, $subj . ' · Copy', $html, array( 'kind' => 'caterer', 'year' => $y, 'text' => $text ) );
		}
	}
	$r = ogc_lst_state_update( $y, 'meals_sent', function ( $s ) use ( $v ) {
		$list = isset( $s['v'] ) ? (array) $s['v'] : array();
		array_unshift( $list, $v );
		// Every send is kept as the record (up to 60); who's behind each count only on the newest two,
		// which is all the change panel compares.
		$list = array_slice( $list, 0, 60 );
		foreach ( $list as $i => &$x ) {
			if ( $i > 1 ) {
				unset( $x['per'] );
			}
		}
		unset( $x );
		return array( 'v' => $list );
	} );
	if ( is_wp_error( $r ) ) {
		return $r;
	}
	ogc_log( 'meals_sent', $y, 'meals', array( 'how' => $how, 'final' => $v['final'] ) );
	return rest_ensure_response( array( 'ok' => true, 'say' => 'email' === $how ? 'Sent · ' . $to : 'Marked as sent' ) );
}

/** The sheet the caterer gets: the counts, and what changed since the last one. */
function ogc_lst_caterer_html( $y, $meals, $last, $final, $o = array() ) {
	$unasked = isset( $o['not_asked'] ) ? (int) $o['not_asked'] : 0;
	$e    = function ( $s ) { return esc_html( (string) $s ); };
	$th   = 'style="text-align:left;padding:6px 10px;border-bottom:2px solid #333;font:600 13px Arial,sans-serif"';
	$tdn  = 'style="text-align:right;padding:6px 10px;border-bottom:1px solid #ddd;font:14px Arial,sans-serif"';
	$td   = 'style="padding:6px 10px;border-bottom:1px solid #ddd;font:14px Arial,sans-serif"';
	$rows = '';
	$prev = '';
	foreach ( $meals as $m ) {
		$w    = $last && isset( $last['counts'][ $m['key'] ] ) ? $last['counts'][ $m['key'] ] : null;
		$chg  = $last ? ( $w ? $m['total'] - ( (int) $w['adult'] + (int) $w['child'] + (int) $w['baby'] ) : $m['total'] ) : null;
		$day  = $m['date'] !== $prev ? date_i18n( 'D, M j', strtotime( $m['date'] . ' 12:00:00' ) ) : '';
		$prev = $m['date'];
		$note  = 'communion' === ( isset( $m['from'] ) ? $m['from'] : '' ) && $unasked ? '<br><span style="font-size:12px;color:#8a5a00">Not asked of ' . $unasked . ' households</span>' : '';
		$rows .= '<tr><td ' . $td . '>' . $e( $day ) . '</td><td ' . $td . '>' . $e( $m['title'] ) . $note . '</td><td ' . $td . '>' . $e( $m['when'] ) . '</td><td ' . $tdn . '>' . (int) $m['counts']['adult'] . '</td><td ' . $tdn . '>' . (int) $m['counts']['child'] . '</td><td ' . $tdn . '>' . (int) $m['counts']['baby'] . '</td><td ' . $tdn . '><b>' . (int) $m['total'] . '</b></td>' . ( $last ? '<td ' . $tdn . '>' . ( $chg ? ( $chg > 0 ? '+' : '−' ) . abs( $chg ) : '' ) . '</td>' : '' ) . '</tr>';
	}
	$head = '<tr><th ' . $th . '>Day</th><th ' . $th . '>Meal</th><th ' . $th . '>Time</th><th ' . $th . '>12 and up</th><th ' . $th . '>3–11</th><th ' . $th . '>Under 3</th><th ' . $th . '>Total</th>' . ( $last ? '<th ' . $th . '>Since ' . $e( date_i18n( 'M j', strtotime( $last['day'] . ' 12:00:00' ) ) ) . '</th>' : '' ) . '</tr>';
	return '<div><p style="font:16px Georgia,serif;margin:0 0 4px">' . $e( $y . ' Annual Conference · Meal counts' . ( $final ? ' · Final' : '' ) ) . '</p>' .
		'<p style="font:13px Arial,sans-serif;color:#555;margin:0 0 14px">As of ' . $e( ogc_lst_as_of( $y ) ) . ( ! empty( $o['from'] ) ? '<br>From ' . $e( $o['from'] ) : '' ) . '</p>' .
		'<table style="border-collapse:collapse">' . $head . $rows . '</table></div>';
}

/** "Oct 10, 4:20 PM" on the campus's clock (never the server's). */
function ogc_lst_as_of( $y ) {
	$n = ogc_lst_now( $y );
	return date_i18n( 'M j', strtotime( $n['date'] . ' 12:00:00' ) ) . ', ' . ogc_lst_hm( $n['min'] );
}

/** The same sheet as plain text, one meal a line (mail programs that don't show the table). */
function ogc_lst_caterer_text( $y, $meals, $last, $final, $o = array() ) {
	$unasked = isset( $o['not_asked'] ) ? (int) $o['not_asked'] : 0;
	$out  = array_merge( array( $y . ' Annual Conference · Meal counts' . ( $final ? ' · Final' : '' ), 'As of ' . ogc_lst_as_of( $y ) ), ! empty( $o['from'] ) ? array( 'From ' . $o['from'] ) : array(), array( '', 'Meal: 12 and up / 3–11 / Under 3 = Total' ) );
	$prev = '';
	foreach ( $meals as $m ) {
		if ( $m['date'] !== $prev ) {
			$out[] = '';
			$out[] = date_i18n( 'l, M j', strtotime( $m['date'] . ' 12:00:00' ) );
			$prev  = $m['date'];
		}
		$w     = $last && isset( $last['counts'][ $m['key'] ] ) ? $last['counts'][ $m['key'] ] : null;
		$chg   = $last ? ( $w ? $m['total'] - ( (int) $w['adult'] + (int) $w['child'] + (int) $w['baby'] ) : $m['total'] ) : 0;
		$out[] = $m['title'] . ' ' . $m['when'] . ': ' . (int) $m['counts']['adult'] . ' / ' . (int) $m['counts']['child'] . ' / ' . (int) $m['counts']['baby'] . ' = ' . (int) $m['total'] . ( $chg ? ' (' . ( $chg > 0 ? '+' : '−' ) . abs( $chg ) . ' since ' . date_i18n( 'M j', strtotime( $last['day'] . ' 12:00:00' ) ) . ')' : '' )
			. ( 'communion' === ( isset( $m['from'] ) ? $m['from'] : '' ) && $unasked ? ' · Not asked of ' . $unasked . ' households' : '' );
	}
	return implode( "\n", $out ) . "\n";
}

function ogc_lst_rest_send_undo( WP_REST_Request $req ) {
	$y    = (int) $req['year'];
	$list = ogc_lst_sent( $y );
	if ( ! $list || 'mark' !== $list[0]['how'] || time() - strtotime( $list[0]['at'] . ' UTC' ) > HOUR_IN_SECONDS ) {
		return ogc_lst_err( 'Can’t undo', 409 );
	}
	ogc_lst_state_update( $y, 'meals_sent', function ( $s ) {
		$l = isset( $s['v'] ) ? (array) $s['v'] : array();
		array_shift( $l );
		return array( 'v' => $l );
	} );
	ogc_log( 'meals_sent_undo', $y, 'meals', array() );
	return rest_ensure_response( array( 'ok' => true, 'say' => 'Undone' ) );
}

function ogc_lst_rest_settings( WP_REST_Request $req ) {
	$y   = (int) $req['year'];
	$in  = (array) $req->get_json_params();
	$out = ogc_lst_state_update( $y, 'lists_settings', function ( $v ) use ( $in ) {
		if ( array_key_exists( 'caterer_email', $in ) ) {
			$e = strtolower( trim( sanitize_text_field( (string) $in['caterer_email'] ) ) );
			$v['caterer_email'] = is_email( $e ) ? $e : '';
		}
		if ( array_key_exists( 'counts_due', $in ) ) {
			$d = (string) $in['counts_due'];
			$v['counts_due'] = preg_match( '/^\d{4}-\d\d-\d\d$/', $d ) ? $d : '';
		}
		if ( array_key_exists( 'communion_supper', $in ) ) {
			$v['communion_supper'] = 'skip' === $in['communion_supper'] ? 'skip' : 'all';
		}
		return $v;
	} );
	if ( is_wp_error( $out ) ) {
		return $out;
	}
	if ( array_key_exists( 'caterer_email', $in ) && '' !== trim( (string) $in['caterer_email'] ) && '' === $out['caterer_email'] ) {
		return ogc_lst_err( 'Not an email', 400, array( 'field' => 'caterer_email' ) );
	}
	ogc_log( 'lists_settings', $y, 'lists', array( 'keys' => array_keys( $in ) ) );
	return rest_ensure_response( array( 'settings' => $out ) );
}

function ogc_lst_rest_access( WP_REST_Request $req ) {
	$y      = (int) $req['year'];
	$choose = ogc_lst_can_choose( $y );
	$names  = array();
	$people = array();
	if ( function_exists( 'ogc_members_list' ) ) {
		foreach ( ogc_members_list( $y ) as $m ) {
			$names[ $m['email'] ] = $m['name'];
			$people[]             = array( 'email' => $m['email'], 'name' => $m['name'], 'role' => $m['role'], 'helps' => $m['helps'] );
		}
	}
	$out = array();
	foreach ( array( 'preteens', 'payments' ) as $l ) {
		// Addresses only to those who choose (the COA, webmasters); the rest get the names.
		$out[ $l ] = array_map( function ( $e ) use ( $names, $choose ) { return array( 'email' => $choose ? $e : '', 'name' => isset( $names[ $e ] ) ? $names[ $e ] : '' ); }, ogc_lst_viewers( $y, $l ) );
	}
	return rest_ensure_response( array( 'choose' => $choose, 'lists' => $out, 'members' => $choose ? $people : array() ) );
}

function ogc_lst_rest_access_set( WP_REST_Request $req ) {
	$y    = (int) $req['year'];
	$list = (string) $req->get_param( 'list' );
	if ( ! ogc_lst_can_choose( $y ) ) {
		return ogc_lst_err( 'The COA chooses', 403 );
	}
	$key = ogc_lst_viewers_key( $list );
	if ( ! $key ) {
		return ogc_lst_err( 'Unknown list' );
	}
	$emails = array();
	foreach ( (array) $req->get_param( 'emails' ) as $e ) {
		$e = strtolower( trim( sanitize_text_field( (string) $e ) ) );
		// Only members of the year can be named.
		if ( is_email( $e ) && ( ! function_exists( 'ogc_member_find' ) || ogc_member_find( $y, $e ) ) ) {
			$emails[] = $e;
		}
	}
	$emails = array_values( array_unique( array_slice( $emails, 0, 20 ) ) );
	ogc_state_put( $y, $key, $emails );
	ogc_log( 'list_access', $y, $list, array( 'n' => count( $emails ) ) );
	return ogc_lst_rest_access( $req );
}

function ogc_lst_rest_printed( WP_REST_Request $req ) {
	$y    = (int) $req['year'];
	$view = (string) $req->get_param( 'view' );
	if ( ! in_array( $view, array( 'meals', 'communion', 'preteens', 'payments', 'callin', 'medical', 'nursery', 'halls' ), true ) ) {
		return ogc_lst_err( 'Unknown list' );
	}
	// A list's own committee (and the COA) marks it printed: Food can't mark the Preteens list. Payments:
	// the Money screen's, or whoever the COA named to see payments; the call-in list: its screen's.
	$sc = function_exists( 'ogc_lst_view_screen' ) ? ogc_lst_view_screen( $view ) : '';
	if ( ! $sc ) {
		return ogc_lst_err( 'Unknown list' );
	}
	if ( function_exists( 'ogc_appc_can' ) ) {
		$ok = ogc_appc_can( $req, $sc, $y );
		if ( true !== $ok && 'payments' === $view && ogc_lst_viewer( $y, 'payments' ) && ! $req->get_param( 'as' ) ) {
			$ok = true;
		}
		if ( true !== $ok ) {
			return $ok;
		}
	}
	// Printed while previewing a date: a look, not the list going out. Logged, never kept as printed
	// (critique: a demo's print marked the real Children list).
	if ( '' !== (string) $req->get_param( 'as_of' ) ) {
		ogc_log( 'list_print_preview', $y, $view, array( 'as_of' => substr( sanitize_text_field( (string) $req->get_param( 'as_of' ) ), 0, 20 ) ) );
		return rest_ensure_response( array( 'ok' => true, 'kept' => false ) );
	}
	ogc_lst_printed_mark( $y, 'medical' === $view ? 'preteens' : $view, 'print' );
	if ( 'medical' === $view ) {
		ogc_log( 'list_print_medical', $y, 'preteens', array() );
	}
	return rest_ensure_response( array( 'ok' => true ) );
}

function ogc_lst_rest_seen( WP_REST_Request $req ) {
	$y    = (int) $req['year'];
	$view = (string) $req->get_param( 'view' );
	if ( ! in_array( $view, array( 'communion', 'preteens', 'payments' ), true ) ) {
		return ogc_lst_err( 'Unknown list' );
	}
	$m          = get_user_meta( get_current_user_id(), 'ogc_lists_seen_' . $y, true );
	$m          = is_array( $m ) ? $m : array();
	$m[ $view ] = ogc_now();
	update_user_meta( get_current_user_id(), 'ogc_lists_seen_' . $y, $m );
	return rest_ensure_response( array( 'ok' => true ) );
}

/** The lists' own state values. Written only through the routes above (which check who may): the
 * generic state route (any member) would let a helper name themselves to see children's medical
 * notes or the ledger, or rewrite what the caterer was sent. Reading them stays members-only. */
function ogc_lst_state_keys() {
	return array( 'preteen_viewers', 'payment_viewers', 'meals_sent', 'lists_settings', 'pay_marks', 'pay_reminded', 'callin_ids', 'lists_printed', 'lists_cleared', 'lists_record' );
}

add_filter( 'rest_request_before_callbacks', function ( $res, $handler, $req ) {
	if ( is_wp_error( $res ) || 'GET' === $req->get_method() ) {
		return $res;
	}
	if ( preg_match( '#^/' . preg_quote( OGC_NS, '#' ) . '/years/\d{4}/state/([a-z0-9][a-z0-9_.:-]{0,63})$#', (string) $req->get_route(), $m ) && in_array( $m[1], ogc_lst_state_keys(), true ) ) {
		return new WP_Error( 'ogc_forbidden', 'Not allowed.', array( 'status' => 403 ) );
	}
	return $res;
}, 5, 3 );
