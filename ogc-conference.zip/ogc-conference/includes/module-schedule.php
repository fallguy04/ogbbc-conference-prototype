<?php
/**
 * The schedule, mechanical, and the call-in line (night-schedule, Oct 13; docs/25 rule 4,
 * docs/scope/05-schedule.md, docs/24-av-oct12.md). The drawing is assets/app/screens/coa-schedule.js
 * (the rows), coa-schedule-read.js (the one strict format) and coa-callin.js (the line).
 *
 *   - Time is exact: a schedule row's start and end, when they're typed or changed, are clock times in
 *     5-minute steps ("7:30 PM"). Words ("After Communion"), "until finished" and a separate sort time
 *     are refused for anything new; rows that still have them are kept as they are and the screen flags
 *     them "Set exact time" for a person to fix. "noon" and "midnight" are the only words that become a
 *     clock by themselves (12:00 PM, 12:00 AM), on the next save of their row.
 *   - The kind is one of a fixed list (ogc_sched_kinds). The kinds the older editor offered are read as
 *     one of the list by a fixed table (ogc_sched_kind_old), shown on the row, and never rewritten until
 *     a person chooses. How a row is listed follows its kind (Open hours, Desk hours, Every night).
 *   - Export: the same columns every year (ogc_sched_export_spec), as Excel or CSV, the first twelve in
 *     the order tools/export-schedule.py wrote them for A/V's layout work (Oct 12).
 *   - The call-in line is its own screen (`callin`, handable on its own: docs/scope/05 Q17): the
 *     provider, number, PIN, # after the PIN, who holds the account (a role address), the trouble line,
 *     and "Not used this year". The provider decides how playback is numbered: FreeConferenceCall
 *     numbers recordings 1, 2, 3 in the order they're made; Midwest Conference Online by date. The site
 *     shows the number to expect by that rule, and A/V types the number the provider gave; the typed
 *     number is the one that counts (docs/scope/05 Q21).
 *   - The two ticks on a row (On the call-in line, Recorded) and the playback numbers go public when
 *     saved (docs/26 #3's one exception): they're whoever runs the line's, who may not hold Publish.
 *   - Public pages read only call_in_number and call_in_pin; every other call_in_ key stays with members,
 *     and "Not used this year" takes the number off the public pages.
 */

defined( 'ABSPATH' ) || exit;

/* ================================================================== the fixed lists */

/**
 * The kinds, one list (docs/scope/05 record 1; held loosely, docs/26: change it here, once).
 * key => array( label, how it's listed: '' in the day · 'all day' Open hours · 'desk' · 'nightly' ).
 */
function ogc_sched_kinds() {
	return (array) apply_filters( 'ogc_sched_kinds', array(
		'worship'    => array( 'Worship', '' ),
		'communion'  => array( 'Communion', '' ),
		'council'    => array( 'Council', '' ),
		'meal'       => array( 'Meal', '' ),
		'teaching'   => array( 'Teaching', '' ),
		'singing'    => array( 'Singing', '' ),
		'prayer'     => array( 'Prayer', '' ),
		'meeting'    => array( 'Meeting', '' ),
		'activity'   => array( 'Activity', '' ),
		'tournament' => array( 'Tournament', '' ),
		'open'       => array( 'Open hours', 'all day' ),
		'desk'       => array( 'Desk', 'desk' ),
		'quiet'      => array( 'Quiet time', 'nightly' ),
		'checkin'    => array( 'Check-in', '' ),
	) );
}

/** The older editor's kinds, read as one of the list (a fixed table; the row keeps its word until a
 * person chooses). "lodging" was the editor's "Lodging desk". signup, notice and deadline have no kind
 * on the list: a deadline is News, a notice is Notices (docs/scope/05). */
function ogc_sched_kind_old() {
	return (array) apply_filters( 'ogc_sched_kind_old', array(
		'devotion' => 'worship', 'snack' => 'meal', 'social' => 'activity', 'free' => 'activity',
		'display' => 'open', 'lodging' => 'desk', 'on_call' => 'desk', 'registration' => 'checkin', 'pickup' => 'checkin',
	) );
}

/** A row's kind on the list ('' when it has none). */
function ogc_sched_kind_of( $k ) {
	$k = strtolower( trim( (string) $k ) );
	$l = ogc_sched_kinds();
	if ( isset( $l[ $k ] ) ) {
		return $k;
	}
	$o = ogc_sched_kind_old();
	return isset( $o[ $k ] ) ? $o[ $k ] : '';
}

/** How a row is listed, in words ('display' as stored). */
function ogc_sched_listed_words( $display ) {
	$m = array( '' => 'In the day', 'all day' => 'Open hours', 'desk' => 'Desk hours', 'nightly' => 'Every night', 'private' => 'Committees only', 'timeline' => 'In the day' );
	$d = strtolower( trim( (string) $display ) );
	return isset( $m[ $d ] ) ? $m[ $d ] : $d;
}

/** The call-in providers. playback: order (1, 2, 3 as recorded) · date · none. */
function ogc_sched_providers() {
	return (array) apply_filters( 'ogc_sched_providers', array(
		'fcc'     => array( 'name' => 'FreeConferenceCall', 'playback' => 'order', 'words' => 'Numbered 1, 2, 3 in the order recorded' ),
		'midwest' => array( 'name' => 'Midwest Conference Online', 'playback' => 'date', 'words' => 'Numbered by date' ),
		'other'   => array( 'name' => 'Other', 'playback' => 'none', 'words' => 'Typed from the provider' ),
	) );
}

/** The settings the Call-in screen keeps (key => what). Only number and PIN are ever public. */
function ogc_sched_line_keys() {
	return array(
		'provider'      => 'call_in_provider',
		'number'        => 'call_in_number',
		'pin'           => 'call_in_pin',
		'hash'          => 'call_in_pin_hash',
		'account'       => 'call_in_account',
		'trouble_role'  => 'call_in_trouble_role',
		'trouble_phone' => 'call_in_trouble_phone',
		'first'         => 'call_in_first',
		'off'           => 'call_in_off',
	);
}

/* ================================================================== time, exactly */

/**
 * A clock time as the schedule keeps it, or as someone types it in a spreadsheet: "7:30 PM", "7 PM",
 * "19:30", "noon", "midnight". → minutes (0–1439) or null. Words are never a time.
 */
function ogc_sched_clock( $v ) {
	$s = strtolower( trim( str_replace( '.', '', (string) $v ) ) );
	if ( '' === $s ) {
		return null;
	}
	if ( preg_match( '/^(12(:00)?\s*)?noon$/', $s ) ) {
		return 720;
	}
	if ( preg_match( '/^(12(:00)?\s*)?midnight$/', $s ) ) {
		return 0;
	}
	if ( preg_match( '/^(\d{1,2})(?::(\d{2}))?(?::00)?\s*(am|pm|a|p)$/', $s, $m ) ) {
		$h  = (int) $m[1];
		$mi = isset( $m[2] ) && '' !== $m[2] ? (int) $m[2] : 0;
		if ( $h < 1 || $h > 12 || $mi > 59 ) {
			return null;
		}
		return ( ( $h % 12 ) + ( 'p' === $m[3][0] ? 12 : 0 ) ) * 60 + $mi;
	}
	if ( preg_match( '/^(\d{1,2}):(\d{2})(?::00)?$/', $s, $m ) ) {
		$h  = (int) $m[1];
		$mi = (int) $m[2];
		if ( $h > 23 || $mi > 59 ) {
			return null;
		}
		return $h * 60 + $mi;
	}
	return null;
}

/** Minutes → the stored form ("7:30 PM", "12:00 AM"). */
function ogc_sched_clock_text( $m ) {
	$m = ( ( (int) $m % 1440 ) + 1440 ) % 1440;
	$h = intdiv( $m, 60 );
	return ( $h % 12 ? $h % 12 : 12 ) . ':' . str_pad( (string) ( $m % 60 ), 2, '0', STR_PAD_LEFT ) . ( $h < 12 ? ' AM' : ' PM' );
}

/** Does this row have an exact start and end? */
function ogc_sched_exact( $r ) {
	return null !== ogc_sched_clock( isset( $r['start'] ) ? $r['start'] : '' ) && null !== ogc_sched_clock( isset( $r['end'] ) ? $r['end'] : '' );
}

/** What's wrong with a new or changed value of one field, or null. */
function ogc_sched_value_problem( $k, $v ) {
	$v = trim( (string) $v );
	switch ( $k ) {
		case 'start':
		case 'end':
			if ( '' === $v ) {
				return null;
			}
			$m = ogc_sched_clock( $v );
			if ( null === $m ) {
				return 'Set exact time · Not a clock time: ' . mb_substr( $v, 0, 30 );
			}
			return 0 === $m % 5 ? null : 'Use 5-minute steps';
		case 'sort_time':
			return '' === $v ? null : 'No sort time · Set an exact start';
		case 'kind':
			return '' === $v || isset( ogc_sched_kinds()[ strtolower( $v ) ] ) ? null : 'Not a kind on the list';
		case 'recorded':
			return '' === $v || in_array( strtolower( $v ), array( 'yes', 'no' ), true ) ? null : 'Yes or no';
	}
	return null;
}

/**
 * Is $v exactly what this row had in field $k before its last change of $k? (⌘Z after a time was typed
 * on a row that had words: the words go back as they were, and nothing else that isn't a clock.)
 */
function ogc_sched_was_before( $year, $id, $k, $v ) {
	global $wpdb;
	if ( '' === (string) $id || ! function_exists( 'ogc_table' ) ) {
		return false;
	}
	$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT before_json, after_json FROM ' . ogc_table( 'rowlog' ) . ' WHERE year = %d AND name = %s AND row_id = %s ORDER BY id DESC LIMIT 20', (int) $year, 'schedule', (string) $id ), ARRAY_A );
	foreach ( (array) $rows as $r ) {
		$a = ogc_unjson( $r['after_json'] );
		if ( is_array( $a ) && array_key_exists( $k, $a ) ) {
			$b = ogc_unjson( $r['before_json'] );
			return is_array( $b ) && isset( $b[ $k ] ) && trim( (string) $b[ $k ] ) === trim( (string) $v );
		}
	}
	return false;
}

// Every new or changed schedule value is checked (the Schedule screen's rows route, the files route):
// rows kept as they were are never refused, so a row with old words can still be renamed.
add_filter( 'ogc_file_rows_valid', function ( $ok, $rows, $year, $name ) {
	if ( is_wp_error( $ok ) || 'schedule' !== $name || defined( 'OGC_IMPORTING' ) ) {
		return $ok;
	}
	$was = array();
	$cur = ogc_file_get( $year, 'schedule' );
	foreach ( $cur ? (array) $cur['rows'] : array() as $r ) {
		if ( ! empty( $r['_id'] ) ) {
			$was[ (string) $r['_id'] ] = $r;
		}
	}
	$places = null;
	foreach ( (array) $rows as $i => $r ) {
		$r   = (array) $r;
		$id  = isset( $r['_id'] ) ? (string) $r['_id'] : '';
		$old = '' !== $id && isset( $was[ $id ] ) ? $was[ $id ] : null;
		// A new row has an exact start and end (docs/25 rule 4); only rows carried with words wait.
		if ( ! $old ) {
			foreach ( array( 'start', 'end' ) as $k ) {
				if ( ! isset( $r[ $k ] ) || '' === trim( (string) $r[ $k ] ) ) {
					return new WP_Error( 'ogc_bad_value', 'Set exact time · A start and an end', array( 'status' => 400, 'row' => $i, 'column' => $k, 'id' => $id ) );
				}
			}
		}
		// A new or changed place is one of the campus's places, by its code (or none).
		$pl = isset( $r['place'] ) ? strtoupper( trim( (string) $r['place'] ) ) : '';
		if ( '' !== $pl && ! ( $old && strtoupper( trim( (string) ( isset( $old['place'] ) ? $old['place'] : '' ) ) ) === $pl ) ) {
			if ( null === $places ) {
				$places = ogc_sched_places( $year );
			}
			if ( ! isset( $places[ $pl ] ) ) {
				return new WP_Error( 'ogc_bad_value', 'Not a place at this campus · Add it on Campus', array( 'status' => 400, 'row' => $i, 'column' => 'place', 'id' => $id ) );
			}
		}
		foreach ( array( 'start', 'end', 'sort_time', 'kind', 'recorded' ) as $k ) {
			if ( ! array_key_exists( $k, $r ) ) {
				continue;
			}
			$v = null === $r[ $k ] ? '' : (string) $r[ $k ];
			if ( $old && trim( (string) ( isset( $old[ $k ] ) ? $old[ $k ] : '' ) ) === trim( $v ) ) {
				continue;
			}
			// The same clock time written another way ("noon" saved as "12:00 PM") isn't a change.
			if ( $old && in_array( $k, array( 'start', 'end' ), true ) && null !== ogc_sched_clock( $v ) && ogc_sched_clock( $v ) === ogc_sched_clock( isset( $old[ $k ] ) ? $old[ $k ] : '' ) ) {
				continue;
			}
			$p = ogc_sched_value_problem( $k, $v );
			// Undo: the exact value this row had before its last change of the field is put back.
			if ( $p && $old && in_array( $k, array( 'start', 'end', 'sort_time' ), true ) && ogc_sched_was_before( $year, $id, $k, $v ) ) {
				$p = null;
			}
			if ( $p ) {
				return new WP_Error( 'ogc_bad_value', $p, array( 'status' => 400, 'row' => $i, 'column' => $k, 'id' => $id ) );
			}
		}
	}
	return $ok;
}, 25, 4 );

// A row being saved keeps its times in one form: "noon" → "12:00 PM", "19:30" → "7:30 PM". Only rows
// that are new or changed in this save (so nothing else is marked changed since Publish); never the seed.
add_filter( 'ogc_file_rows', function ( $rows, $year, $name, $cur ) {
	if ( 'schedule' !== $name || defined( 'OGC_IMPORTING' ) ) {
		return $rows;
	}
	$was = array();
	foreach ( $cur ? (array) $cur['rows'] : array() as $r ) {
		if ( ! empty( $r['_id'] ) ) {
			$was[ (string) $r['_id'] ] = ogc_json( $r );
		}
	}
	foreach ( $rows as &$r ) {
		if ( ! is_array( $r ) ) {
			continue;
		}
		$id = isset( $r['_id'] ) ? (string) $r['_id'] : '';
		if ( '' !== $id && isset( $was[ $id ] ) && $was[ $id ] === ogc_json( $r ) ) {
			continue;
		}
		foreach ( array( 'start', 'end' ) as $k ) {
			if ( isset( $r[ $k ] ) && '' !== trim( (string) $r[ $k ] ) ) {
				$m = ogc_sched_clock( $r[ $k ] );
				if ( null !== $m ) {
					$r[ $k ] = ogc_sched_clock_text( $m );
				}
			}
		}
	}
	unset( $r );
	return $rows;
}, 8, 4 );

/* ================================================================== the year's days and rows */

/** The year's days: array( array( name, date ) ). */
function ogc_sched_days( $year ) {
	if ( function_exists( 'ogc_reg_days' ) ) {
		return ogc_reg_days( (int) $year );
	}
	return array();
}

/** A year's settings as key => value. */
function ogc_sched_settings( $year ) {
	$f   = ogc_file_get( (int) $year, 'settings' );
	$out = array();
	foreach ( $f ? (array) $f['rows'] : array() as $r ) {
		if ( isset( $r['key'] ) ) {
			$out[ (string) $r['key'] ] = isset( $r['value'] ) ? (string) $r['value'] : '';
		}
	}
	return $out;
}

/** The rows in the order they happen: by day, then start. A row with no clock start yet sits where its
 * old sort time puts it (kept from before, never new), so the Export keeps it in place as A/V's Oct 12
 * file had it; with none, first in its day. (The Schedule screen lists such rows first, to be seen.) */
function ogc_sched_sorted( $rows, $days ) {
	$di = array();
	foreach ( $days as $i => $d ) {
		$di[ strtolower( $d['name'] ) ] = $i;
	}
	$rows = array_values( (array) $rows );
	$idx  = array_keys( $rows );
	usort( $idx, function ( $a, $b ) use ( $rows, $di ) {
		$da = isset( $di[ strtolower( (string) ( isset( $rows[ $a ]['day'] ) ? $rows[ $a ]['day'] : '' ) ) ] ) ? $di[ strtolower( (string) $rows[ $a ]['day'] ) ] : 99;
		$db = isset( $di[ strtolower( (string) ( isset( $rows[ $b ]['day'] ) ? $rows[ $b ]['day'] : '' ) ) ] ) ? $di[ strtolower( (string) $rows[ $b ]['day'] ) ] : 99;
		if ( $da !== $db ) {
			return $da - $db;
		}
		$at = function ( $r ) {
			$m = ogc_sched_clock( isset( $r['start'] ) ? $r['start'] : '' );
			$m = null === $m ? ogc_sched_clock( isset( $r['sort_time'] ) ? $r['sort_time'] : '' ) : $m;
			return null === $m ? -1 : $m;
		};
		$sa = $at( $rows[ $a ] );
		$sb = $at( $rows[ $b ] );
		return $sa !== $sb ? $sa - $sb : $a - $b;
	} );
	return array_map( function ( $i ) use ( $rows ) {
		return $rows[ $i ];
	}, $idx );
}

/** "7–9:45 PM", "Noon–1:45 PM", "11 PM–1 AM", or the words a row still has. */
function ogc_sched_when( $r ) {
	$a = ogc_sched_clock( isset( $r['start'] ) ? $r['start'] : '' );
	$b = ogc_sched_clock( isset( $r['end'] ) ? $r['end'] : '' );
	if ( null === $a ) {
		return trim( (string) ( isset( $r['start'] ) ? $r['start'] : '' ) );
	}
	$f = function ( $m ) {
		if ( 720 === $m ) {
			return 'Noon';
		}
		if ( 0 === $m ) {
			return 'Midnight';
		}
		$h = intdiv( $m, 60 );
		return ( $h % 12 ? $h % 12 : 12 ) . ( $m % 60 ? ':' . str_pad( (string) ( $m % 60 ), 2, '0', STR_PAD_LEFT ) : '' ) . ( $h < 12 ? ' AM' : ' PM' );
	};
	if ( null === $b ) {
		return $f( $a );
	}
	$x = $f( $a );
	$y = $f( $b );
	if ( substr( $x, -2 ) === substr( $y, -2 ) && preg_match( '/[AP]M$/', $x ) ) {
		$x = substr( $x, 0, -3 );
	}
	return $x . '–' . $y;
}

/** A place code → its name and building, for a year. */
function ogc_sched_places( $year ) {
	$f   = ogc_file_get( (int) $year, 'places' );
	$out = array();
	foreach ( $f ? (array) $f['rows'] : array() as $p ) {
		if ( ! empty( $p['code'] ) ) {
			$out[ strtoupper( trim( (string) $p['code'] ) ) ] = array( 'name' => isset( $p['name'] ) ? (string) $p['name'] : '', 'building' => isset( $p['building'] ) ? (string) $p['building'] : '' );
		}
	}
	return $out;
}

/* ================================================================== Export, the same columns every year */

function ogc_sched_export_spec() {
	$kinds = implode( ', ', array_map( function ( $k ) {
		return $k[0];
	}, ogc_sched_kinds() ) );
	return array(
		'title' => 'Schedule',
		'cols'  => array(
			array( 'Day', 'The day of Conference, by name. A day can also be written as its date (2027-05-29) when importing.', 11 ),
			array( 'Start', 'The start, a clock time ("7:30 PM"). Words left from an older year are kept until someone sets an exact time.', 10 ),
			array( 'End', 'The end, a clock time. An end earlier than the start means after midnight.', 10 ),
			array( 'What', 'The title as people see it.', 38 ),
			array( 'Where', 'The room or place, by its name.', 30 ),
			array( 'Building', 'The building it is in, for the campus map.', 22 ),
			array( 'For', 'Everyone, Conference, Preteens or Youngfolks. A printout can show one group.', 13 ),
			array( 'Kind', 'One of a fixed list, the same every year: ' . $kinds . '.', 12 ),
			array( 'Note', 'Shown under the title, for people. The site never reads it.', 50 ),
			array( 'Call-in', 'Yes when it goes out live on the phone call-in line.', 9 ),
			array( 'Shown as', 'In the day, Open hours, Desk hours or Every night (from the kind), or Committees only (never on a public page or paper).', 15 ),
			array( 'Place code', 'Before the slash is the building (B = Barnes), after it the room.', 11 ),
			array( 'Date', 'The day as a date.', 11 ),
			array( 'Recorded', 'Yes when a row on the line is recorded for playback; No when it is on the line but not recorded.', 10 ),
			array( 'Through', 'For a row that repeats each day: the last day it runs.', 11 ),
			array( 'Printout note', 'Only on the printed schedule.', 30 ),
			array( 'ID', 'The row\'s lasting ID. Keep it: an import matches rows by their ID, and only by it.', 12 ),
		),
	);
}

/** The export's rows, in the spec's order. */
function ogc_sched_export_rows( $year ) {
	$f      = ogc_file_get( (int) $year, 'schedule' );
	$days   = ogc_sched_days( $year );
	$dates  = array();
	foreach ( $days as $d ) {
		$dates[ strtolower( $d['name'] ) ] = $d['date'];
	}
	$places = ogc_sched_places( $year );
	$kinds  = ogc_sched_kinds();
	$out    = array();
	foreach ( ogc_sched_sorted( $f ? $f['rows'] : array(), $days ) as $r ) {
		$g    = function ( $k ) use ( $r ) {
			return isset( $r[ $k ] ) ? trim( (string) $r[ $k ] ) : '';
		};
		$code = strtoupper( $g( 'place' ) );
		$kind = ogc_sched_kind_of( $g( 'kind' ) );
		$aud  = $g( 'audience' );
		$on   = (bool) preg_match( '/^(y|yes|true|1|x)$/i', $g( 'call_in' ) );
		$out[] = array(
			$g( 'day' ),
			null !== ogc_sched_clock( $g( 'start' ) ) ? ogc_sched_clock_text( ogc_sched_clock( $g( 'start' ) ) ) : $g( 'start' ),
			null !== ogc_sched_clock( $g( 'end' ) ) ? ogc_sched_clock_text( ogc_sched_clock( $g( 'end' ) ) ) : $g( 'end' ),
			$g( 'title' ),
			isset( $places[ $code ] ) && '' !== $places[ $code ]['name'] ? $places[ $code ]['name'] : $g( 'place' ),
			isset( $places[ $code ] ) ? $places[ $code ]['building'] : '',
			'all' === strtolower( $aud ) ? 'Everyone' : $aud,
			'' !== $kind ? $kinds[ $kind ][0] : $g( 'kind' ),
			$g( 'note' ),
			$on ? 'Yes' : '',
			ogc_sched_listed_words( $g( 'display' ) ),
			$g( 'place' ),
			isset( $dates[ strtolower( $g( 'day' ) ) ] ) ? $dates[ strtolower( $g( 'day' ) ) ] : '',
			$on ? ( 'no' === strtolower( $g( 'recorded' ) ) ? 'No' : 'Yes' ) : '',
			$g( 'last_day' ),
			$g( 'print_note' ),
			$g( '_id' ),
		);
	}
	return $out;
}

/** A CSV that opens in Excel: a BOM, and a cell that would run as a formula written as words. */
function ogc_sched_csv( $head, $rows ) {
	$cell = function ( $v ) {
		$v = (string) $v;
		if ( preg_match( '/^[=+\-@\t\r]/', $v ) && ! preg_match( '/^[+-]?\d[\d.,:]*$/', $v ) ) {
			$v = "'" . $v;
		}
		return preg_match( '/[",\r\n]|^\s|\s$/', $v ) ? '"' . str_replace( '"', '""', $v ) . '"' : $v;
	};
	$lines = array( implode( ',', array_map( $cell, $head ) ) );
	foreach ( $rows as $r ) {
		$lines[] = implode( ',', array_map( $cell, $r ) );
	}
	return "\xEF\xBB\xBF" . implode( "\r\n", $lines ) . "\r\n";
}

function ogc_sched_file_response( $body, $file, $type ) {
	$res = new WP_REST_Response( null, 200 );
	$res->header( 'Content-Type', $type );
	$res->header( 'Content-Disposition', 'attachment; filename="' . str_replace( '"', '', sanitize_file_name( $file ) ) . '"' );
	$res->header( 'Cache-Control', 'no-store' );
	$res->header( 'X-Content-Type-Options', 'nosniff' );
	add_filter( 'rest_pre_serve_request', function ( $served, $result ) use ( $body, $res ) {
		if ( $result === $res ) {
			echo $body; // phpcs:ignore WordPress.Security.EscapeOutput -- a file's bytes, built above.
			return true;
		}
		return $served;
	}, 10, 2 );
	return $res;
}

/** A list as the asked format: xlsx (a workbook with the list, then Columns) or csv. */
function ogc_sched_send( $year, $spec, $rows, $title, $format, $about = array() ) {
	$head = array_map( function ( $c ) {
		return $c[0];
	}, $spec['cols'] );
	if ( 'xlsx' === $format && function_exists( 'ogc_lst_xlsx' ) ) {
		$sheets = array( ogc_lst_list_sheet( $spec, $rows, $year . ' ' . $title ), ogc_lst_columns_sheet( $spec, $about ) );
		$sheets[0]['first'] = true;
		return ogc_sched_file_response( ogc_lst_xlsx( $sheets ), (int) $year . ' ' . $title . '.xlsx', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' );
	}
	return ogc_sched_file_response( ogc_sched_csv( $head, $rows ), (int) $year . ' ' . $title . '.csv', 'text/csv; charset=utf-8' );
}

/* ================================================================== the call-in line */

/** The line as the screen shows it. */
function ogc_sched_line( $year ) {
	$s   = ogc_sched_settings( $year );
	$out = array();
	foreach ( ogc_sched_line_keys() as $k => $sk ) {
		$out[ $k ] = isset( $s[ $sk ] ) ? (string) $s[ $sk ] : '';
	}
	$picked = ogc_state_get( (int) $year, 'picked' );
	$from   = $picked && ! empty( $picked['value']['from'] ) ? (string) $picked['value']['from'] : '';
	$conf   = function_exists( 'ogc_coa_is_confirmed' ) ? ogc_coa_is_confirmed( (int) $year, 'conf:callin' ) : true;
	$st     = function_exists( 'ogc_coa_state' ) ? ogc_coa_state( (int) $year ) : array( 'checks' => array() );
	$out['from']      = $from;
	$out['confirmed'] = isset( $st['checks']['conf:callin'] ) ? array( 'by' => (string) $st['checks']['conf:callin']['by'], 'at' => (string) $st['checks']['conf:callin']['at'] ) : null;
	$out['status']    = 'yes' === $out['off'] ? 'off' : ( '' === $out['number'] ? 'none' : ( $conf ? 'confirmed' : 'check' ) );
	return $out;
}

/** Is a row on the line, and recorded for playback (on the line unless marked No)? */
function ogc_sched_on_line( $r ) {
	return (bool) preg_match( '/^(y|yes|true|1|x)$/i', trim( (string) ( isset( $r['call_in'] ) ? $r['call_in'] : '' ) ) );
}
function ogc_sched_recorded( $r ) {
	return ogc_sched_on_line( $r ) && 'no' !== strtolower( trim( (string) ( isset( $r['recorded'] ) ? $r['recorded'] : '' ) ) );
}

/**
 * The playback number each recorded row should get by the provider's rule: FreeConferenceCall, in the
 * order the recordings are made, from the first number (1 unless A/V says the account starts higher);
 * Midwest, by date (the date, and the order that day). id => text. Only what to expect: the number
 * A/V types from the provider is the one that counts, so the count goes on from a typed number (a
 * typed 7 makes the next recording 8), and a row marked Not recorded takes no number.
 */
function ogc_sched_expected( $year, $rows = null, $line = null, $pb = null ) {
	$line = $line ? $line : ogc_sched_line( $year );
	$pb   = null === $pb ? ogc_sched_playback( $year ) : (array) $pb;
	$p    = ogc_sched_providers();
	$how  = isset( $p[ $line['provider'] ] ) ? $p[ $line['provider'] ]['playback'] : '';
	if ( ! in_array( $how, array( 'order', 'date' ), true ) ) {
		return array();
	}
	$days = ogc_sched_days( $year );
	if ( null === $rows ) {
		$f    = ogc_file_get( (int) $year, 'schedule' );
		$rows = $f ? $f['rows'] : array();
	}
	$dates = array();
	foreach ( $days as $d ) {
		$dates[ strtolower( $d['name'] ) ] = $d['date'];
	}
	$n     = max( 1, (int) ( '' !== $line['first'] ? $line['first'] : 1 ) );
	$per   = array();
	$out   = array();
	foreach ( ogc_sched_sorted( $rows, $days ) as $r ) {
		if ( empty( $r['_id'] ) || ! ogc_sched_recorded( $r ) ) {
			continue;
		}
		$date  = isset( $dates[ strtolower( (string) $r['day'] ) ] ) ? $dates[ strtolower( (string) $r['day'] ) ] : '';
		$e     = isset( $pb[ $r['_id'] ] ) ? (array) $pb[ $r['_id'] ] : array();
		$typed = isset( $e['n'] ) ? trim( (string) $e['n'] ) : '';
		if ( isset( $e['st'] ) && 'not' === $e['st'] ) {
			continue;
		}
		if ( 'order' === $how ) {
			$out[ $r['_id'] ] = (string) $n;
			$n                = preg_match( '/^\d{1,6}$/', $typed ) ? (int) $typed + 1 : $n + 1;
		} elseif ( '' !== $date ) {
			$mmdd             = substr( str_replace( '-', '', $date ), 4 );
			$per[ $date ]     = isset( $per[ $date ] ) ? $per[ $date ] + 1 : 1;
			$out[ $r['_id'] ] = $mmdd . '-' . $per[ $date ];
			if ( preg_match( '/^' . $mmdd . '-(\d{1,3})$/', $typed, $tm ) ) {
				$per[ $date ] = (int) $tm[1];
			}
		}
	}
	return $out;
}

/** The typed playback numbers: id => { n, st (numbered|not), note, by, at }. */
function ogc_sched_playback( $year ) {
	$s = ogc_state_get( (int) $year, 'callin_playback' );
	$v = $s && is_array( $s['value'] ) ? $s['value'] : array();
	return isset( $v['rows'] ) && is_array( $v['rows'] ) ? $v['rows'] : array();
}

/** A time in another zone, for a row on a date: "7:30 PM". */
function ogc_sched_in_zone( $date, $min, $from_tz, $to_tz ) {
	if ( ! preg_match( '/^\d{4}-\d\d-\d\d$/', (string) $date ) || null === $min ) {
		return '';
	}
	try {
		$d = new DateTime( $date . ' ' . sprintf( '%02d:%02d', intdiv( $min, 60 ), $min % 60 ), new DateTimeZone( $from_tz ) );
		$d->setTimezone( new DateTimeZone( $to_tz ) );
		return $d->format( 'g:i A' );
	} catch ( Exception $e ) {
		return '';
	}
}

/** The five zones listeners at home read (docs/scope/05 Q25), the same columns every year. */
function ogc_sched_zones() {
	return array( 'Eastern' => 'America/New_York', 'Central' => 'America/Chicago', 'Mountain' => 'America/Denver', 'Pacific' => 'America/Los_Angeles', 'Arizona' => 'America/Phoenix' );
}

function ogc_sched_callin_spec() {
	return array(
		'title' => 'Call-in line',
		'cols'  => array(
			array( 'Date', 'The day as a date.', 11 ),
			array( 'Day', 'The day of Conference.', 10 ),
			array( 'Start', 'At the campus, on its own clock.', 9 ),
			array( 'End', 'At the campus.', 9 ),
			array( 'What', 'The title as people see it.', 36 ),
			array( 'Where', 'The room.', 26 ),
			array( 'Eastern', 'The start in Eastern time.', 9 ),
			array( 'Central', 'The start in Central time.', 9 ),
			array( 'Mountain', 'The start in Mountain time.', 9 ),
			array( 'Pacific', 'The start in Pacific time.', 9 ),
			array( 'Arizona', 'The start in Arizona, which keeps standard time all year.', 9 ),
			array( 'Recorded', 'Yes when it is recorded for playback.', 9 ),
			array( 'Expected', 'The playback number to expect by the provider\'s rule. Only a guide: a test call or a restarted recording moves it.', 10 ),
			array( 'Playback', 'The number the provider gave, typed by whoever runs the line. Blank until then.', 10 ),
			array( 'Status', 'Expected, Numbered or Not recorded.', 13 ),
			array( 'Note', 'For people.', 30 ),
		),
	);
}

/** The screen's rows: every row of the week, in order, with what the line needs. */
function ogc_sched_callin_rows( $year ) {
	$f      = ogc_file_get( (int) $year, 'schedule' );
	$rows   = $f ? (array) $f['rows'] : array();
	$days   = ogc_sched_days( $year );
	$dates  = array();
	foreach ( $days as $d ) {
		$dates[ strtolower( $d['name'] ) ] = $d['date'];
	}
	$places = ogc_sched_places( $year );
	$out    = array();
	foreach ( ogc_sched_sorted( $rows, $days ) as $r ) {
		if ( empty( $r['_id'] ) ) {
			continue;
		}
		$code  = strtoupper( trim( (string) ( isset( $r['place'] ) ? $r['place'] : '' ) ) );
		$out[] = array(
			'id'       => (string) $r['_id'],
			'day'      => isset( $r['day'] ) ? (string) $r['day'] : '',
			'date'     => isset( $dates[ strtolower( (string) ( isset( $r['day'] ) ? $r['day'] : '' ) ) ] ) ? $dates[ strtolower( (string) $r['day'] ) ] : '',
			'when'     => ogc_sched_when( $r ),
			'start'    => ogc_sched_clock( isset( $r['start'] ) ? $r['start'] : '' ),
			'exact'    => ogc_sched_exact( $r ),
			'title'    => isset( $r['title'] ) ? (string) $r['title'] : '',
			'where'    => isset( $places[ $code ] ) && '' !== $places[ $code ]['name'] ? $places[ $code ]['name'] : ( isset( $r['place'] ) ? (string) $r['place'] : '' ),
			'audience' => isset( $r['audience'] ) ? (string) $r['audience'] : '',
			'kind'     => ogc_sched_kind_of( isset( $r['kind'] ) ? $r['kind'] : '' ),
			'private'  => isset( $r['display'] ) && 'private' === strtolower( (string) $r['display'] ),
			'call_in'  => ogc_sched_on_line( $r ),
			'recorded' => ogc_sched_recorded( $r ),
		);
	}
	return $out;
}

function ogc_sched_callin_payload( $year, WP_REST_Request $req ) {
	$line  = ogc_sched_line( $year );
	$rows  = ogc_sched_callin_rows( $year );
	$exp   = ogc_sched_expected( $year, null, $line );
	$pb    = ogc_sched_playback( $year );
	$s     = ogc_sched_settings( $year );
	$v     = ogc_app_req_viewer( $req );
	$may   = ! $v['as'] && '' === (string) $req->get_param( 'as_of' );
	$hand  = function_exists( 'ogc_app_handed_to' ) ? ogc_app_handed_to( (int) $year, 'callin' ) : '';
	$c     = '' !== $hand && function_exists( 'ogc_app_committee' ) ? ogc_app_committee( (int) $year, $hand ) : null;
	return array(
		'line'      => $line,
		'providers' => ogc_sched_providers(),
		'rows'      => $rows,
		'expected'  => (object) $exp,
		'playback'  => (object) $pb,
		'zone'      => isset( $s['timezone_label'] ) ? (string) $s['timezone_label'] : '',
		'today'     => function_exists( 'ogc_app_today' ) ? ogc_app_today( (int) $year ) : gmdate( 'Y-m-d' ),
		'public'    => function_exists( 'ogc_coa_posted' ) ? ogc_coa_posted( (int) $year, 'schedule_posted' ) && '' !== ( isset( $s['schedule_posted'] ) ? $s['schedule_posted'] : '' ) : false,
		'held'      => function_exists( 'ogc_ed_held' ) && ogc_ed_held( (int) $year ),
		'handed'    => $c ? (string) $c['name'] : '',
		'can'       => array(
			'edit'     => $may && ! ( function_exists( 'ogc_ed_held' ) && ogc_ed_held( (int) $year ) && ! ogc_is_webmaster() ),
			'schedule' => function_exists( 'ogc_app_can_see' ) && ogc_app_can_see( $v, 'schedule' ),
		),
	);
}

/* ================================================================== routes */

add_action( 'rest_api_init', function () {
	$Y   = '(?P<year>\d{4})';
	$can = function ( $screens ) {
		return function ( WP_REST_Request $req ) use ( $screens ) {
			if ( ! function_exists( 'ogc_appc_can_any' ) || null === ogc_year_get( (int) $req['year'] ) ) {
				return new WP_Error( 'ogc_not_found', 'Not found.', array( 'status' => 404 ) );
			}
			return ogc_appc_can_any( $req, $screens );
		};
	};
	// The whole schedule to Excel: any member of the year (night-schedule critique, Oct 13: Jamin's
	// layout work shouldn't wait on the COA). They read the same working rows through
	// years/{y}/files/schedule already, so this holds nothing back; it only saves the copying.
	$screens = $can( array( 'schedule', 'callin' ) );
	register_rest_route( OGC_NS, "/app/$Y/schedule/export", array(
		array( 'methods' => 'GET', 'callback' => 'ogc_sched_rest_export', 'permission_callback' => function ( WP_REST_Request $req ) use ( $screens ) {
			$r = $screens( $req );
			if ( true === $r || ( is_wp_error( $r ) && 404 === (int) ( $r->get_error_data()['status'] ?? 0 ) ) ) {
				return $r;
			}
			return ogc_is_member( (int) $req['year'] ) || ogc_is_webmaster() ? true : $r;
		} ),
	) );
	register_rest_route( OGC_NS, "/app/$Y/callin", array(
		array( 'methods' => 'GET', 'callback' => 'ogc_sched_rest_callin', 'permission_callback' => $can( array( 'callin', 'schedule' ) ) ),
		array( 'methods' => 'PATCH', 'callback' => 'ogc_sched_rest_line', 'permission_callback' => $can( array( 'callin' ) ) ),
	) );
	register_rest_route( OGC_NS, "/app/$Y/callin/rows", array(
		array( 'methods' => 'POST', 'callback' => 'ogc_sched_rest_ticks', 'permission_callback' => $can( array( 'callin', 'schedule' ) ) ),
	) );
	register_rest_route( OGC_NS, "/app/$Y/callin/playback", array(
		array( 'methods' => 'POST', 'callback' => 'ogc_sched_rest_playback', 'permission_callback' => $can( array( 'callin' ) ) ),
	) );
	register_rest_route( OGC_NS, "/app/$Y/callin/confirm", array(
		array( 'methods' => 'POST', 'callback' => 'ogc_sched_rest_confirm', 'permission_callback' => $can( array( 'callin' ) ) ),
	) );
} );

function ogc_sched_held_refusal( $year ) {
	if ( function_exists( 'ogc_ed_held' ) && ogc_ed_held( (int) $year ) && ! ogc_is_webmaster() ) {
		return new WP_Error( 'ogc_held', 'Held · Read only', array( 'status' => 423 ) );
	}
	return null;
}

function ogc_sched_rest_export( WP_REST_Request $req ) {
	$y = (int) $req['year'];
	$f = (string) $req->get_param( 'format' );
	$n = count( ogc_sched_export_rows( $y ) );
	ogc_log( 'schedule_export', $y, 'schedule', array( 'format' => 'xlsx' === $f ? 'xlsx' : 'csv', 'n' => $n ) );
	$about = array(
		'Made' => function_exists( 'ogc_lst_as_of_long' ) ? ogc_lst_as_of_long( $y ) : gmdate( 'M j, Y' ),
		'Rows' => (string) $n,
		'From' => 'The site\'s own schedule, the same rows the Conference page, the Conference app and the printout use. Change it there, then export again.',
	);
	return ogc_sched_send( $y, ogc_sched_export_spec(), ogc_sched_export_rows( $y ), 'Conference schedule', 'xlsx' === $f ? 'xlsx' : 'csv', $about );
}

function ogc_sched_rest_callin( WP_REST_Request $req ) {
	$y   = (int) $req['year'];
	$fmt = (string) $req->get_param( 'format' );
	if ( 'xlsx' === $fmt || 'csv' === $fmt ) {
		$line  = ogc_sched_line( $y );
		$s     = ogc_sched_settings( $y );
		$tz    = ! empty( $s['timezone'] ) ? $s['timezone'] : 'America/Indiana/Indianapolis';
		$exp   = ogc_sched_expected( $y, null, $line );
		$pb    = ogc_sched_playback( $y );
		$f     = ogc_file_get( $y, 'schedule' );
		$byid  = array();
		foreach ( $f ? $f['rows'] : array() as $r ) {
			if ( ! empty( $r['_id'] ) ) {
				$byid[ $r['_id'] ] = $r;
			}
		}
		$rows = array();
		foreach ( ogc_sched_callin_rows( $y ) as $r ) {
			if ( ! $r['call_in'] || $r['private'] ) {
				continue;
			}
			$raw  = $byid[ $r['id'] ];
			$p    = isset( $pb[ $r['id'] ] ) ? (array) $pb[ $r['id'] ] : array();
			$num  = isset( $p['n'] ) ? (string) $p['n'] : '';
			$not  = isset( $p['st'] ) && 'not' === $p['st'];
			$row  = array( $r['date'], $r['day'],
				null !== ogc_sched_clock( isset( $raw['start'] ) ? $raw['start'] : '' ) ? ogc_sched_clock_text( ogc_sched_clock( $raw['start'] ) ) : (string) ( isset( $raw['start'] ) ? $raw['start'] : '' ),
				null !== ogc_sched_clock( isset( $raw['end'] ) ? $raw['end'] : '' ) ? ogc_sched_clock_text( ogc_sched_clock( $raw['end'] ) ) : (string) ( isset( $raw['end'] ) ? $raw['end'] : '' ),
				$r['title'], $r['where'] );
			foreach ( ogc_sched_zones() as $zone ) {
				$row[] = ogc_sched_in_zone( $r['date'], $r['start'], $tz, $zone );
			}
			$row[] = $r['recorded'] ? 'Yes' : 'No';
			$row[] = $r['recorded'] && isset( $exp[ $r['id'] ] ) ? $exp[ $r['id'] ] : '';
			$row[] = $r['recorded'] && ! $not ? $num : '';
			$row[] = ! $r['recorded'] ? '' : ( $not ? 'Not recorded' : ( '' !== $num ? 'Numbered' : 'Expected' ) );
			$row[] = isset( $p['note'] ) ? (string) $p['note'] : '';
			$rows[] = $row;
		}
		$prov  = ogc_sched_providers();
		$about = array(
			'Made'      => function_exists( 'ogc_lst_as_of_long' ) ? ogc_lst_as_of_long( $y ) : gmdate( 'M j, Y' ),
			'Number'    => $line['number'] . ( '' !== $line['pin'] ? ' · PIN ' . $line['pin'] . ( 'yes' === $line['hash'] ? ' then #' : '' ) : '' ),
			'Provider'  => isset( $prov[ $line['provider'] ] ) ? $prov[ $line['provider'] ]['name'] . ' · ' . $prov[ $line['provider'] ]['words'] : 'Not set',
			'Times'     => 'The campus\'s clock is ' . ( ! empty( $s['timezone_label'] ) ? $s['timezone_label'] : $tz ) . '.',
		);
		ogc_log( 'callin_export', $y, 'callin', array( 'format' => $fmt, 'n' => count( $rows ) ) );
		return ogc_sched_send( $y, ogc_sched_callin_spec(), $rows, 'Call-in line', $fmt, $about );
	}
	return rest_ensure_response( ogc_sched_callin_payload( $y, $req ) );
}

/** A US phone number as typed: "717-908-1961", "(717) 908-1961", "+1 717 908 1961". → digits or null. */
function ogc_sched_phone_ok( $v ) {
	$d = preg_replace( '/\D+/', '', (string) $v );
	if ( 11 === strlen( $d ) && '1' === $d[0] ) {
		$d = substr( $d, 1 );
	}
	return 10 === strlen( $d ) && preg_match( '/^[0-9+().\s-]{10,20}$/', trim( (string) $v ) ) ? $d : null;
}

function ogc_sched_rest_line( WP_REST_Request $req ) {
	$y = (int) $req['year'];
	$h = ogc_sched_held_refusal( $y );
	if ( $h ) {
		return $h;
	}
	$fields = $req->get_param( 'fields' );
	if ( ! is_array( $fields ) || ! $fields ) {
		return new WP_Error( 'ogc_bad', 'Nothing to change.', array( 'status' => 400 ) );
	}
	$keys = ogc_sched_line_keys();
	$set  = array();
	foreach ( $fields as $k => $v ) {
		if ( ! isset( $keys[ $k ] ) || ( null !== $v && ! is_scalar( $v ) ) ) {
			return new WP_Error( 'ogc_bad', 'Not a field of the line.', array( 'status' => 400, 'field' => (string) $k ) );
		}
		$v = trim( sanitize_text_field( (string) $v ) );
		$p = null;
		switch ( $k ) {
			case 'provider':
				$p = '' === $v || isset( ogc_sched_providers()[ $v ] ) ? null : 'Not a provider on the list';
				break;
			case 'number':
			case 'trouble_phone':
				if ( '' !== $v && null === ogc_sched_phone_ok( $v ) ) {
					$p = 'Not a phone number · Try 717-908-1961';
				}
				break;
			case 'pin':
				$p = '' === $v || preg_match( '/^\d{1,12}$/', $v ) ? null : 'Digits only';
				break;
			case 'hash':
			case 'off':
				$v = in_array( strtolower( $v ), array( 'yes', '1', 'true' ), true ) ? 'yes' : '';
				break;
			case 'account':
				if ( '' !== $v && ! is_email( $v ) ) {
					$p = 'Not an email address';
				}
				$v = strtolower( $v );
				break;
			case 'trouble_role':
				$p = mb_strlen( $v ) <= 60 ? null : 'Too long';
				break;
			case 'first':
				$p = '' === $v || ( preg_match( '/^\d{1,4}$/', $v ) && (int) $v >= 1 ) ? null : 'A number from 1';
				break;
		}
		if ( $p ) {
			return new WP_Error( 'ogc_bad_value', $p, array( 'status' => 400, 'field' => (string) $k ) );
		}
		$set[ $keys[ $k ] ] = $v;
	}
	foreach ( $set as $sk => $v ) {
		$ver = ogc_file_patch( $y, 'settings', array( 'op' => 'key', 'key' => $sk, 'value' => $v ) );
		if ( is_wp_error( $ver ) ) {
			return $ver;
		}
		do_action( 'ogc_file_saved', $y, 'settings', $ver );
	}
	// What changed, never the values (the account address is a role's, but a log keeps none).
	ogc_log( 'callin_line', $y, 'callin', array( 'fields' => array_keys( $fields ) ) );
	return rest_ensure_response( ogc_sched_callin_payload( $y, $req ) );
}

/**
 * Tick rows on the line, or mark them recorded or not: { ids: [], call_in?: bool, recorded?: bool }.
 * Saved through the editors' rows (history, the same checks), and on the copy the public reads at once
 * when the schedule is public (docs/26 #3: the ticks and numbers are the one exception to Publish).
 */
function ogc_sched_rest_ticks( WP_REST_Request $req ) {
	$y = (int) $req['year'];
	$h = ogc_sched_held_refusal( $y );
	if ( $h ) {
		return $h;
	}
	$ids = $req->get_param( 'ids' );
	$ids = is_array( $ids ) ? array_values( array_unique( array_map( 'strval', $ids ) ) ) : array();
	if ( ! $ids || count( $ids ) > 300 ) {
		return new WP_Error( 'ogc_bad', 'ids is a list of rows.', array( 'status' => 400 ) );
	}
	$fields = array();
	if ( null !== $req->get_param( 'call_in' ) ) {
		$fields['call_in'] = rest_sanitize_boolean( $req->get_param( 'call_in' ) ) ? 'yes' : '';
	}
	if ( null !== $req->get_param( 'recorded' ) ) {
		$fields['recorded'] = rest_sanitize_boolean( $req->get_param( 'recorded' ) ) ? '' : 'no';
	}
	if ( ! $fields ) {
		return new WP_Error( 'ogc_bad', 'call_in or recorded.', array( 'status' => 400 ) );
	}
	if ( ! function_exists( 'ogc_ed_apply' ) ) {
		return new WP_Error( 'ogc_busy', 'Not ready', array( 'status' => 503 ) );
	}
	$f     = ogc_file_get( $y, 'schedule' );
	$known = array();
	foreach ( $f ? $f['rows'] : array() as $r ) {
		if ( ! empty( $r['_id'] ) ) {
			$known[ (string) $r['_id'] ] = true;
		}
	}
	$ops = array();
	foreach ( $ids as $id ) {
		if ( ! isset( $known[ $id ] ) ) {
			return new WP_Error( 'ogc_not_found', 'Not found.', array( 'status' => 404 ) );
		}
		$ops[] = array( 'op' => 'set', 'id' => $id, 'fields' => $fields );
	}
	$res = ogc_ed_apply( $y, 'schedule', $ops );
	if ( is_wp_error( $res ) ) {
		return $res;
	}
	// The copy the public reads takes the same two fields now.
	if ( function_exists( 'ogc_coa_live_on' ) && ogc_coa_live_on( $y, 'schedule' ) ) {
		$live = ogc_coa_live_get( $y, 'schedule' );
		if ( $live ) {
			$hit = false;
			foreach ( $live['rows'] as &$r ) {
				if ( ! empty( $r['_id'] ) && in_array( (string) $r['_id'], $ids, true ) ) {
					foreach ( $fields as $k => $v ) {
						$r[ $k ] = $v;
					}
					$hit = true;
				}
			}
			unset( $r );
			if ( $hit ) {
				$cur = ogc_state_get( $y, 'live_schedule' );
				ogc_state_put( $y, 'live_schedule', $live, $cur ? $cur['version'] : 0 );
			}
		}
	}
	ogc_log( 'callin_ticks', $y, 'schedule', array( 'n' => count( $ids ), 'fields' => array_keys( $fields ) ) );
	return rest_ensure_response( array( 'version' => $res['version'], 'rows' => ogc_sched_callin_rows( $y ), 'expected' => (object) ogc_sched_expected( $y ) ) );
}

/** A playback number from the provider: { id, number?, status? ('numbered'|'not'|''), note? }. */
function ogc_sched_rest_playback( WP_REST_Request $req ) {
	$y  = (int) $req['year'];
	$h  = ogc_sched_held_refusal( $y );
	if ( $h ) {
		return $h;
	}
	$id = (string) $req->get_param( 'id' );
	$ok = false;
	foreach ( ogc_sched_callin_rows( $y ) as $r ) {
		$ok = $ok || ( $r['id'] === $id && $r['call_in'] );
	}
	if ( ! $ok ) {
		return new WP_Error( 'ogc_not_found', 'Not on the line.', array( 'status' => 404 ) );
	}
	$num  = $req->get_param( 'number' );
	$st   = $req->get_param( 'status' );
	$note = $req->get_param( 'note' );
	if ( null !== $num && ( ! is_scalar( $num ) || ! preg_match( '/^[A-Za-z0-9 #.-]{0,16}$/', trim( (string) $num ) ) ) ) {
		return new WP_Error( 'ogc_bad_value', 'Letters, digits and dashes · 16 at most', array( 'status' => 400, 'field' => 'number' ) );
	}
	if ( null !== $st && ! in_array( (string) $st, array( '', 'numbered', 'not' ), true ) ) {
		return new WP_Error( 'ogc_bad_value', 'Not a status', array( 'status' => 400, 'field' => 'status' ) );
	}
	if ( null !== $note && ( ! is_scalar( $note ) || mb_strlen( (string) $note ) > 300 ) ) {
		return new WP_Error( 'ogc_bad_value', 'Too long', array( 'status' => 400, 'field' => 'note' ) );
	}
	for ( $try = 0; $try < 6; $try++ ) {
		$cur  = ogc_state_get( $y, 'callin_playback' );
		$val  = $cur && is_array( $cur['value'] ) ? $cur['value'] : array();
		$rows = isset( $val['rows'] ) && is_array( $val['rows'] ) ? $val['rows'] : array();
		$e    = isset( $rows[ $id ] ) ? (array) $rows[ $id ] : array( 'n' => '', 'st' => '', 'note' => '' );
		if ( null !== $num ) {
			$e['n']  = trim( (string) $num );
			$e['st'] = '' === $e['n'] ? ( 'not' === ( isset( $e['st'] ) ? $e['st'] : '' ) ? 'not' : '' ) : 'numbered';
		}
		if ( null !== $st ) {
			$e['st'] = 'numbered' === $st && '' === (string) ( isset( $e['n'] ) ? $e['n'] : '' ) ? '' : (string) $st;
		}
		if ( null !== $note ) {
			$e['note'] = sanitize_textarea_field( (string) $note );
		}
		$e['by'] = function_exists( 'ogc_coa_first_l' ) ? ogc_coa_first_l( get_current_user_id() ) : '';
		$e['at'] = ogc_now();
		if ( '' === (string) $e['n'] && '' === (string) $e['st'] && '' === (string) ( isset( $e['note'] ) ? $e['note'] : '' ) ) {
			unset( $rows[ $id ] );
		} else {
			$rows[ $id ] = $e;
		}
		$val['rows'] = $rows;
		$v           = ogc_state_put( $y, 'callin_playback', $val, $cur ? $cur['version'] : 0 );
		if ( ! is_wp_error( $v ) ) {
			ogc_log( 'callin_playback', $y, 'schedule:' . $id, array( 'status' => isset( $rows[ $id ] ) ? $rows[ $id ]['st'] : '' ) );
			return rest_ensure_response( array( 'playback' => (object) $rows, 'expected' => (object) ogc_sched_expected( $y, null, null, $rows ) ) );
		}
	}
	return new WP_Error( 'ogc_busy', 'Busy · Retry', array( 'status' => 503 ) );
}

/** Looks right: the line carried from last year, checked with the provider. { done } */
function ogc_sched_rest_confirm( WP_REST_Request $req ) {
	$y = (int) $req['year'];
	if ( ! function_exists( 'ogc_coa_update' ) ) {
		return new WP_Error( 'ogc_busy', 'Not ready', array( 'status' => 503 ) );
	}
	$done = rest_sanitize_boolean( $req->get_param( 'done' ) );
	$v    = ogc_coa_update( $y, function ( &$s ) use ( $y, $done ) {
		if ( $done ) {
			$s['checks']['conf:callin'] = ogc_coa_stamp( $y );
		} else {
			unset( $s['checks']['conf:callin'] );
		}
	} );
	if ( is_wp_error( $v ) ) {
		return $v;
	}
	ogc_log( 'coa', $y, 'check', array( 'what' => 'check', 'id' => 'conf:callin', 'n' => 1, 'done' => $done, 'part' => 'schedule' ) );
	return rest_ensure_response( ogc_sched_callin_payload( $y, $req ) );
}

/* ================================================================== who may, elsewhere */

// The playback numbers change only through the Call-in screen's route (the general state route would
// let any member of the year write them). The line's settings keys are guarded by module-coa-app.php's
// one rule (call_in_* belongs to the Call-in screen).
add_filter( 'rest_request_before_callbacks', function ( $resp, $handler, $req ) {
	if ( is_wp_error( $resp ) || 'GET' === $req->get_method() ) {
		return $resp;
	}
	if ( preg_match( '#^/' . preg_quote( OGC_NS, '#' ) . '/years/(\d{4})/state/callin_playback$#', $req->get_route() ) ) {
		return ogc_is_webmaster() ? $resp : new WP_Error( 'ogc_not_yours', 'On the Call-in screen', array( 'status' => 403 ) );
	}
	return $resp;
}, 7, 3 );

/* ================================================================== what the public reads */

// The public gets the number and the PIN only; the provider, the account, the trouble line and the
// rest stay with members. "Not used this year" takes the number off every public page too.
add_filter( 'ogc_file_rows_out', function ( $rows, $year, $name, $member ) {
	if ( 'settings' !== $name ) {
		return $rows;
	}
	$off = false;
	foreach ( (array) $rows as $r ) {
		if ( isset( $r['key'] ) && 'call_in_off' === $r['key'] && 'yes' === ( isset( $r['value'] ) ? (string) $r['value'] : '' ) ) {
			$off = true;
		}
	}
	if ( $member ) {
		// A member's own look at the Conference page treats a line not used this year as held.
		if ( $off ) {
			$rows[] = array( 'key' => 'call_in_held', 'value' => 'yes', 'help' => '' );
		}
		return $rows;
	}
	return array_values( array_filter( (array) $rows, function ( $r ) use ( $off ) {
		$k = isset( $r['key'] ) ? (string) $r['key'] : '';
		if ( 0 !== strpos( $k, 'call_in_' ) ) {
			return true;
		}
		return ! $off && in_array( $k, array( 'call_in_number', 'call_in_pin' ), true );
	} ) );
}, 30, 4 );

/* ================================================================== the app: screens, scripts, words */

add_filter( 'ogc_app_screens', function ( $s, $year ) {
	if ( ! isset( $s['schedule'] ) ) {
		return $s;
	}
	$out = array();
	foreach ( $s as $id => $d ) {
		$out[ $id ] = $d;
		if ( 'schedule' === $id ) {
			$out['callin'] = array( 'title' => 'Call-in', 'section' => 'own', 'who' => array( 'coa' ), 'handable' => true );
		}
	}
	return $out;
}, 21, 2 );

add_filter( 'ogc_pages', function ( $p ) {
	if ( empty( $p['app'] ) ) {
		return $p;
	}
	$s  = array_values( (array) $p['app']['scripts'] );
	$at = array_search( 'app/screens/coa-schedule.js', $s, true );
	// The strict reader before the screen that uses it; the line's screen after.
	array_splice( $s, false === $at ? count( $s ) : $at, 0, array( 'app/screens/coa-schedule-read.js' ) );
	$s[]                    = 'app/screens/coa-callin.js';
	$p['app']['scripts']    = $s;
	$p['app']['styles'][]   = 'app/screens/coa-schedule.css';
	return $p;
}, 21 );

// The fixed lists, for the screens (one place: this file).
add_filter( 'ogc_client_config', function ( $cfg, $key ) {
	if ( 'app' !== $key ) {
		return $cfg;
	}
	$kinds = array();
	foreach ( ogc_sched_kinds() as $k => $d ) {
		$kinds[] = array( $k, $d[0], $d[1] );
	}
	$prov = array();
	foreach ( ogc_sched_providers() as $k => $d ) {
		$prov[] = array( $k, $d['name'], $d['playback'], $d['words'] );
	}
	$cfg['sched'] = array( 'kinds' => $kinds, 'old' => (object) ogc_sched_kind_old(), 'providers' => $prov );
	return $cfg;
}, 30, 2 );

// What the schedule and the line still need, on Home (docs/23: the one thing first).
add_filter( 'ogc_app_needs', function ( $rows, $year, $ckey, $ctx ) {
	if ( ! function_exists( 'ogc_app_handed_to' ) ) {
		return $rows;
	}
	$owner = ogc_app_handed_to( $year, 'schedule' );
	if ( ( '' === $owner ? 'coa' : $owner ) === $ckey && 'nodates' !== $ctx['phase'] ) {
		$f = ogc_file_get( $year, 'schedule' );
		$n = 0;
		foreach ( $f ? $f['rows'] : array() as $r ) {
			$n += ogc_sched_exact( $r ) ? 0 : 1;
		}
		if ( $n ) {
			$rows[] = array( 'key' => 'schedule-time', 'kind' => 'schedule_time', 'words' => ( 1 === $n ? '1 schedule row' : $n . ' schedule rows' ) . ' without an exact time', 'why' => 'Words or no end · A start and end for each', 'go' => array( 's' => 'schedule', 'v' => 'time' ), 'button' => 'Set times', 'due' => '', 'rank' => 3 );
		}
	}
	$line_owner = ogc_app_handed_to( $year, 'callin' );
	if ( ( '' === $line_owner ? 'coa' : $line_owner ) === $ckey ) {
		$days  = ogc_sched_days( $year );
		$today = $ctx['today'];
		if ( $days && $today >= $days[0]['date'] ) {
			$pb   = ogc_sched_playback( $year );
			$left = 0;
			$date = array();
			foreach ( $days as $d ) {
				$date[ strtolower( $d['name'] ) ] = $d['date'];
			}
			$f = ogc_file_get( $year, 'schedule' );
			foreach ( $f ? $f['rows'] : array() as $r ) {
				$d = isset( $date[ strtolower( (string) ( isset( $r['day'] ) ? $r['day'] : '' ) ) ] ) ? $date[ strtolower( (string) $r['day'] ) ] : '';
				if ( '' !== $d && $d <= $today && ! empty( $r['_id'] ) && ogc_sched_recorded( $r ) && empty( $pb[ $r['_id'] ]['st'] ) ) {
					$left++;
				}
			}
			if ( $left ) {
				$rows[] = array( 'key' => 'callin-numbers', 'kind' => 'callin_numbers', 'words' => ( 1 === $left ? '1 playback number' : $left . ' playback numbers' ) . ' to type', 'why' => 'From the provider\'s account, after each recorded service', 'go' => array( 's' => 'callin', 'v' => 'playback' ), 'button' => 'Type numbers', 'due' => $today, 'rank' => 2 );
			}
		}
	}
	return $rows;
}, 20, 4 );
