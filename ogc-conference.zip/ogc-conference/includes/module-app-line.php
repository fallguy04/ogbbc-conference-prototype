<?php
/**
 * Round 2, "the year as a line" (Oct 16, 2026; docs/27-back-end-map README 12, area-committees,
 * area-home-tasks). A committee's page and Home draw the year as one vertical line with Today marked;
 * this file gives them their rows, each written from the same functions the screens they open use
 * (README rule 10: one count, one place). Nothing here reads a note or guesses (docs/25).
 *
 *   ogc_app_committee_needs( $y, $k )     what needs a committee, as its head would see it (memoised)
 *   ogc_app_work_rows( $y, $k, $v )       its Work rows: line, need, season (on), holder, done
 *   ogc_app_line_tasks( $y, $k )          its open tasks for the line
 *   ogc_app_next_rows( $y, $k, $v )       For next year: Notes for 2028, Report, How we work, Files, Folder
 *   ogc_app_committee_fact( $y, $k )      its one fact (area-committees 2.1)
 *   ogc_app_committee_marks( $y, $k )     its marks: nobody, nohead, late, unchecked, soon (2.2)
 *   ogc_app_handoffs(), ogc_app_works_with()   the fixed hand-off table (section 15), states only
 *   ogc_app_first_steps( $y )             the COA's five first steps (area-home-tasks 1.4)
 *   ogc_app_final_counts( $y )            the Final counts line (1.6)
 *   ogc_app_home_committees( $y, $steps ) Home's Committees block (1.7)
 *   ogc_app_handing( $y )                 Who runs what (area-committees 12.2), and its routes
 */

defined( 'ABSPATH' ) || exit;

/* ================================================================== the viewer a committee is */

/** A committee as its head sees it (the weekly note's viewer): for its needs and its rows. */
function ogc_app_as_head( $year, $ckey ) {
	return array(
		'year'       => (int) $year,
		'coa'        => 'coa' === $ckey,
		'webmaster'  => false,
		'committees' => 'coa' === $ckey ? array() : array( $ckey ),
		'head'       => true,
		'member_id'  => 0,
		'as'         => '',
		'open'       => true,
	);
}

/** What needs a committee now, ranked (ogc_app_needs as its head would see it). Once a request. */
function ogc_app_committee_needs( $year, $ckey ) {
	$k = (int) $year . '|' . $ckey . '|' . ogc_app_today( $year );
	if ( ! isset( $GLOBALS['ogc_app_cneeds'][ $k ] ) ) {
		$GLOBALS['ogc_app_cneeds'][ $k ] = ogc_app_needs( (int) $year, ogc_app_as_head( $year, $ckey ) );
	}
	return $GLOBALS['ogc_app_cneeds'][ $k ];
}

/** A need that speaks for the committee's work (not a person's first step, not someone else's people). */
function ogc_app_need_counts( $n ) {
	$k = isset( $n['key'] ) ? (string) $n['key'] : '';
	if ( 0 === strpos( $k, 'first:' ) || 0 === strpos( $k, 'lod-new' ) || 0 === strpos( $k, 'nobody' ) || 0 === strpos( $k, 'nohead' ) || 'round-coa' === $k ) {
		return false;
	}
	return empty( $n['manual'] ) && empty( $n['ask'] );
}

/* ================================================================== Work rows */

/** The order the year uses its screens (README 2.1; area-committees 11). Anything else goes last. */
function ogc_app_work_order() {
	return array(
		'requests', 'shifts',
		'lod-households', 'lod-rooms', 'lod-yf', 'lod-campers', 'lod-counts', 'lod-checkin',
		'food-meals', 'food-menus', 'preteens-list', 'communion-list', 'nursery-list', 'yf-teams', 'yf-halls',
		'dates', 'campus', 'intake', 'schedule', 'callin', 'registration', 'households', 'money', 'packet', 'help', 'members', 'privacy',
	);
}

/** A COA screen's line, from that screen's own state (never a count it doesn't keep). */
function ogc_app_coa_screen_line( $y, $id ) {
	$row   = ogc_year_get( $y );
	$today = ogc_app_today( $y );
	$s     = function_exists( 'ogc_coa_kv' ) ? ogc_coa_kv( $y, 'settings' ) : array();
	$pub   = function ( $key ) use ( $s, $today, $y ) {
		$v = isset( $s[ $key ] ) ? (string) $s[ $key ] : '';
		return preg_match( '/^\d{4}-\d{2}-\d{2}$/', $v ) && '9999-12-31' !== $v && $v <= $today ? 'Published ' . ogc_app_md( $v, $y ) : 'Not public';
	};
	switch ( $id ) {
		case 'dates':
			$on = $row && ! empty( $row['coa_announced'] ) ? (string) $row['coa_announced'] : '';
			return ogc_app_range_words( $row ) . ' · ' . ( preg_match( '/^\d{4}-\d{2}-\d{2}$/', $on ) && $on <= $today ? 'Announced ' . ogc_app_md( $on, $y ) : 'Not announced' );
		case 'campus':
			return $row && ! empty( $row['venue'] ) ? (string) $row['venue'] : '';
		case 'intake':
			if ( ! function_exists( 'ogc_round_ready' ) || ! ogc_round_ready() ) {
				return '';
			}
			$st   = ogc_round_settings( $y );
			$sent = ogc_round_day( $y, $st['sent_at'] );
			$d    = ogc_round_dates( $y, $st );
			if ( '' === $sent || $sent > $today ) {
				return $d['send'] ? 'Send date ' . ogc_app_md( $d['send'], $y ) : '';
			}
			$cs    = ogc_round_committees( $y );
			$lines = ogc_round_lines( $y );
			$back  = 0;
			foreach ( $cs as $c ) {
				$ls    = ogc_round_line_state( $y, isset( $lines[ $c['ckey'] ] ) ? $lines[ $c['ckey'] ] : null, $today );
				$back += 'returned' === $ls['status'] ? 1 : 0;
			}
			return 'Sent ' . ogc_app_md( $sent, $y ) . ' · ' . $back . ' of ' . count( $cs ) . ' returned';
		case 'schedule':
			return $pub( 'schedule_posted' );
		case 'packet':
			return $pub( 'packet_posted' );
		case 'shifts':
			// Every committee's shifts, counted as the screen counts them (Round 4).
			if ( ! function_exists( 'ogc_shift_counts' ) ) {
				return '';
			}
			$sc = ogc_shift_counts( $y );
			if ( ! $sc['shifts'] ) {
				return '';
			}
			return ogc_vol_posted( $y ) ? ogc_shift_filled_words( $sc ) : 'Not public · ' . $sc['shifts'] . ' ' . ( 1 === $sc['shifts'] ? 'shift' : 'shifts' );
		case 'registration':
			$r = function_exists( 'ogc_coa_kv' ) ? ogc_coa_kv( $y, 'registration' ) : array();
			$o = isset( $r['opens'] ) ? (string) $r['opens'] : '';
			$c = isset( $r['closes'] ) ? (string) $r['closes'] : '';
			if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $o ) || '9999-12-31' === $o ) {
				return 'Not scheduled';
			}
			if ( $today < $o ) {
				return 'Opens ' . ogc_app_md( $o, $y );
			}
			return preg_match( '/^\d{4}-\d{2}-\d{2}$/', $c ) && $today > $c ? 'Closed ' . ogc_app_md( $c, $y ) : 'Open' . ( $c ? ' · Closes ' . ogc_app_md( $c, $y ) : '' );
		case 'households':
			// The same counts as Households' own title (ogc_rec_counts: one count, one place).
			if ( ! function_exists( 'ogc_rec_counts' ) ) {
				return '';
			}
			$c = ogc_rec_counts( ogc_rec_rows( $y ) );
			return implode( ' · ', array_filter( array( $c['coming'] ? $c['coming'] . ' coming' : '', $c['waiting'] ? $c['waiting'] . ' waiting' : '' ) ) );
		case 'members':
			$n = 0;
			foreach ( ogc_members_list( $y ) as $m ) {
				$n += ogc_member_active( $m ) ? 1 : 0;
			}
			return $n ? ogc_app_plural( $n, 'person', 'people' ) : '';
	}
	return '';
}

/** The round's dates for the line: when Requests come into season and when they're due. */
function ogc_app_round_span( $y ) {
	if ( ! function_exists( 'ogc_round_ready' ) || ! ogc_round_ready() ) {
		return array( 'on' => '', 'until' => '' );
	}
	$st   = ogc_round_settings( $y );
	$d    = ogc_round_dates( $y, $st );
	$sent = ogc_round_day( $y, $st['sent_at'] );
	return array( 'on' => '' !== $sent ? $sent : (string) $d['send'], 'until' => (string) $d['due'] );
}

/**
 * A committee's Work rows, in the year's order (area-committees 2.3): Requests and Shifts always, then
 * its own screens, then the screens the COA handed it (tagged). On the COA's own page: the COA's screens,
 * each handed one with its holder's name. Each row:
 *   id, c (the committee a shared screen opens filtered to), title, line, on (the day it comes into
 *   season, '' = all year), until, done, handed ('' | 'Handed' | the holder's name), need (or null).
 * A row's need is the committee's own need that opens that screen (ogc_app_needs: the same count the
 * screen shows); top marks the committee's first need, the one filled button.
 */
function ogc_app_work_rows( $year, $ckey, $v = null ) {
	$y      = (int) $year;
	$all    = ogc_app_screens( $y );
	$opens  = function_exists( 'ogc_app_screen_opens' ) ? ogc_app_screen_opens( $y ) : array();
	$c      = ogc_app_committee( $y, $ckey );
	if ( ! $c ) {
		return array();
	}
	$coa    = 'coa' === $ckey;
	$span   = ogc_app_round_span( $y );
	// A screen's day on the line is the day its season starts, also once it's in season: the lists that
	// follow registration keep registration's opening day (ogc_app_screen_opens gives '' once there's
	// work in them, for the sidebar).
	$reg    = function_exists( 'ogc_coa_kv' ) ? ogc_coa_kv( $y, 'registration' ) : array();
	$rday   = isset( $reg['opens'] ) && preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) $reg['opens'] ) && '9999-12-31' !== $reg['opens'] ? (string) $reg['opens'] : '';
	foreach ( array( 'lod-households', 'lod-rooms', 'lod-yf', 'lod-campers', 'food-meals', 'preteens-list', 'communion-list', 'nursery-list', 'yf-halls', 'households', 'money' ) as $rid ) {
		if ( isset( $opens[ $rid ] ) && '' === (string) $opens[ $rid ] && '' !== $rday ) {
			$opens[ $rid ] = $rday;
		}
	}
	$rows   = array();
	$add    = function ( $id, $o ) use ( &$rows, $all, $opens ) {
		$rows[ $id ] = array_merge( array(
			'id'     => $id,
			'c'      => '',
			'title'  => isset( $all[ $id ] ) ? $all[ $id ]['title'] : $id,
			'line'   => '',
			'on'     => isset( $opens[ $id ] ) ? (string) $opens[ $id ] : '',
			'until'  => '',
			'done'   => false,
			'handed' => '',
			'need'   => null,
		), $o );
	};
	if ( ! $coa ) {
		// Requests: every committee's own part of the round, from the round's own words.
		$rs = function_exists( 'ogc_round_ready' ) && ogc_round_ready() ? ogc_round_line_state( $y, isset( ogc_round_lines( $y )[ $ckey ] ) ? ogc_round_lines( $y )[ $ckey ] : null, ogc_round_today( $y ) ) : array( 'status' => '' );
		$add( 'requests', array( 'c' => $ckey, 'line' => function_exists( 'ogc_appc_requests_line' ) ? ogc_appc_requests_line( $y, $ckey ) : '', 'on' => $span['on'], 'until' => $span['until'], 'done' => 'returned' === $rs['status'] ) );
		// Shifts, filtered to this committee (Round 4: one screen for every committee). A committee the COA
		// handed Shifts to gets the whole list instead, below (README 2.1: it takes the place of its own).
		$sl = function_exists( 'ogc_appc_shift_line' ) ? ogc_appc_shift_line( $y, $ckey ) : '';
		$add( 'shifts', array( 'c' => $ckey, 'title' => 'Shifts', 'line' => $sl ? str_replace( ' shift places filled', ' filled', $sl ) : ( in_array( $ckey, function_exists( 'ogc_appc_shift_keys' ) ? ogc_appc_shift_keys( $y ) : array(), true ) ? '' : 'No shifts' ) ) );
		// Its own screens.
		foreach ( $all as $id => $d ) {
			if ( ! empty( $d['coa_opens'] ) && in_array( $ckey, $d['who'], true ) && ! in_array( $id, array( 'shifts', 'requests', 'lod-import' ), true ) ) {
				$add( $id, array( 'line' => function_exists( 'ogc_appc_work_line' ) ? ogc_appc_work_line( $y, $id, $ckey ) : '' ) );
			}
		}
		// The screens the COA handed it.
		foreach ( $c['screens'] as $id ) {
			if ( isset( $all[ $id ] ) ) {
				$add( $id, array( 'line' => ogc_app_coa_screen_line( $y, $id ), 'handed' => 'Handed', 'on' => 'intake' === $id ? $span['on'] : ( isset( $opens[ $id ] ) ? (string) $opens[ $id ] : '' ), 'until' => 'intake' === $id ? $span['until'] : '' ) );
			}
		}
	} else {
		// The COA's own page: its screens, Shifts for every committee among them (Round 4), each handed one
		// with who holds it.
		foreach ( $all as $id => $d ) {
			if ( 'own' !== $d['section'] || ! in_array( 'coa', $d['who'], true ) || 'requests' === $id ) {
				continue;
			}
			$to = ogc_app_handed_to( $y, $id );
			$hc = '' !== $to ? ogc_app_committee( $y, $to ) : null;
			$add( $id, array(
				'line'   => ogc_app_coa_screen_line( $y, $id ),
				'handed' => $hc ? $hc['name'] : '',
				'on'     => 'intake' === $id ? $span['on'] : ( isset( $opens[ $id ] ) ? (string) $opens[ $id ] : '' ),
				'until'  => 'intake' === $id ? $span['until'] : '',
			) );
		}
	}
	// In the year's order.
	$order = array_flip( ogc_app_work_order() );
	uasort( $rows, function ( $a, $b ) use ( $order ) {
		$x = isset( $order[ $a['id'] ] ) ? $order[ $a['id'] ] : 99;
		$z = isset( $order[ $b['id'] ] ) ? $order[ $b['id'] ] : 99;
		return $x - $z;
	} );
	// Each row's need: the committee's own need that opens it (a handed screen's from its holder).
	$needs = ogc_app_committee_needs( $y, $ckey );
	$top   = null;
	foreach ( $needs as $n ) {
		if ( ogc_app_need_counts( $n ) ) {
			$top = $n;
			break;
		}
	}
	foreach ( $rows as $id => &$r ) {
		if ( ! empty( $r['nocount'] ) ) {
			$r['open'] = null === $v || ogc_app_can_see( $v, $id );
			continue;
		}
		$list = $needs;
		if ( $coa && '' !== $r['handed'] ) {
			$list = ogc_app_committee_needs( $y, ogc_app_handed_to( $y, $id ) );
		}
		foreach ( $list as $n ) {
			$go = isset( $n['go'] ) ? (array) $n['go'] : array();
			if ( ! ogc_app_need_counts( $n ) || ! isset( $go['s'] ) || $go['s'] !== $id ) {
				continue;
			}
			if ( ! empty( $go['c'] ) && '' !== $r['c'] && $go['c'] !== $r['c'] ) {
				continue;
			}
			// A shared list's act opens it filtered to this row's committee, as the row does (Round 3: the
			// COA's "Open Requests" on Public Relations' page went to Requests unfiltered, which is Intake).
			if ( empty( $go['c'] ) && '' !== $r['c'] ) {
				$go['c'] = $r['c'];
			}
			// While the dates aren't checked, Announce waits for them, as on Home (area-home-tasks 1.3).
			$wait = isset( $n['kind'] ) && 'announce' === $n['kind'] && ! ogc_app_dates_checked( $y );
			$r['need'] = array(
				'words'  => (string) $n['words'],
				'why'    => isset( $n['why'] ) ? (string) $n['why'] : '',
				'button' => $wait ? 'Check dates' : ( isset( $n['button'] ) ? (string) $n['button'] : '' ),
				'go'     => $go,
				'tone'   => isset( $n['tone'] ) ? (string) $n['tone'] : '',
				'top'    => $top && isset( $top['key'] ) && isset( $n['key'] ) && $top['key'] === $n['key'] && ( ! $coa || '' === $r['handed'] ),
			);
			break;
		}
		// Only what this viewer may open is a door (a webmaster's structure page has none).
		$r['open'] = null === $v || ogc_app_can_see( $v, $id );
	}
	unset( $r );
	return array_values( $rows );
}

/** A committee's open tasks for the line: each with its due date (For next year's own are folded there). */
function ogc_app_line_tasks( $year, $ckey ) {
	$out = array();
	foreach ( ogc_app_tasks( (int) $year, array( $ckey ) ) as $t ) {
		if ( $t['done'] || in_array( $t['kind'], array( 'notes_next', 'report_sent' ), true ) ) {
			continue;
		}
		$out[] = array(
			'id'     => $t['id'],
			'title'  => $t['title'],
			'due'    => $t['due'],
			'when'   => $t['due_words'],
			'late'   => $t['late'],
			'screen' => $t['screen'],
			'auto'   => '' !== $t['screen'],
		);
	}
	return $out;
}

/** For next year (area-committees 7.8): one row each, with where it stands. Its day is the day after
 * the Conference; a task of its kind (Notes for next year, Report to the COA) gives its due date. */
function ogc_app_next_rows( $year, $ckey ) {
	$y     = (int) $year;
	$row   = ogc_year_get( $y );
	$after = $row && ! empty( $row['end'] ) ? gmdate( 'Y-m-d', strtotime( $row['end'] . ' 12:00 UTC' ) + DAY_IN_SECONDS ) : '';
	$due   = array();
	foreach ( ogc_app_tasks( $y, array( $ckey ) ) as $t ) {
		if ( in_array( $t['kind'], array( 'notes_next', 'report_sent' ), true ) ) {
			$due[ $t['kind'] ] = $t;
		}
	}
	$notes = ogc_app_notes( $y, $ckey );
	$hd    = function_exists( 'ogc_hd_field' ) && function_exists( 'ogc_hd_ready' ) && ogc_hd_ready() ? ogc_hd_field( $y, $ckey, 'how' ) : null;
	$files = ogc_app_files( $y, $ckey );
	$c     = ogc_app_committee( $y, $ckey );
	$rep   = ogc_app_report( $y, $ckey );
	$phase = ogc_app_phase( $y )['phase'];
	$dw    = function ( $k ) use ( $due, $y ) {
		return isset( $due[ $k ] ) && $due[ $k ]['due'] ? ' · Due ' . ogc_app_md( $due[ $k ]['due'], $y ) : '';
	};
	$rows   = array();
	$rows[] = array( 'id' => 'notes', 'title' => 'Notes for ' . ( $y + 1 ), 'line' => ( $notes ? ogc_app_plural( count( $notes ), 'note' ) : 'None yet' ) . $dw( 'notes_next' ), 'on' => $after, 'until' => isset( $due['notes_next'] ) ? $due['notes_next']['due'] : '', 'act' => 'Add note' );
	if ( 'coa' !== $ckey ) {
		$rl = $rep && ! empty( $rep['sent'] ) ? 'Sent ' . $rep['sent'] : ( $rep && array_filter( (array) $rep['answers'] ) ? 'Draft' . ( ! empty( $rep['updated'] ) ? ' · Saved ' . $rep['updated'] : '' ) : ( 'after' === $phase ? 'Not started' : 'After the Conference' ) );
		$rows[] = array( 'id' => 'report', 'title' => 'Report', 'line' => $rl . ( $rep && ! empty( $rep['sent'] ) ? '' : $dw( 'report_sent' ) ), 'on' => $after, 'until' => isset( $due['report_sent'] ) ? $due['report_sent']['due'] : '', 'act' => 'after' === $phase ? ( $rep && ! empty( $rep['sent'] ) ? 'Open' : 'Write' ) : ( $rep && array_filter( (array) $rep['answers'] ) ? 'Open' : '' ) );
	}
	$how    = $hd && '' !== (string) $hd['value'] ? ( (int) $hd['year'] !== $y ? 'From ' . (int) $hd['year'] : 'Written' ) : 'Not written';
	$rows[] = array( 'id' => 'how', 'title' => 'How we work', 'line' => $how, 'on' => $after, 'until' => '', 'act' => 'Not written' === $how ? 'Write' : 'Edit' );
	$carried = count( array_filter( $files, function ( $f ) {
		return ! empty( $f['carried'] );
	} ) );
	$rows[] = array( 'id' => 'files', 'title' => 'Files', 'line' => $files ? ogc_app_plural( count( $files ), 'file' ) . ( $carried ? ' · ' . $carried . ' from ' . ( $y - 1 ) : '' ) : 'None yet', 'on' => $after, 'until' => '', 'act' => 'Upload' );
	$rows[] = array( 'id' => 'folder', 'title' => 'Folder', 'line' => $c && $c['link'] ? preg_replace( '#^https?://#', '', substr( $c['link'], 0, 40 ) ) . ( strlen( $c['link'] ) > 40 ? '…' : '' ) : 'None · Optional', 'on' => $after, 'until' => '', 'act' => $c && $c['link'] ? 'Change' : 'Add link' );
	return $rows;
}

/* ================================================================== the fact and the marks */

/**
 * A committee's one fact (area-committees 2.1), the first true one: no one on it; its first need (as
 * its head would see it); one of its own lists in season; its shifts; its next task; all done. The
 * board, the page's title row and Home's Committees block all say this one.
 *   { words, due, tone ('' | 'look' | 'late'), go, button, source }
 */
function ogc_app_committee_fact( $year, $ckey ) {
	$y   = (int) $year;
	$out = array( 'words' => '', 'due' => '', 'tone' => '', 'go' => null, 'button' => '', 'source' => '' );
	if ( 'coa' !== $ckey && ! ogc_app_people( $y, $ckey ) ) {
		return array_merge( $out, array( 'words' => 'No one on it', 'tone' => 'late', 'go' => array( 's' => 'members', 'id' => 'new', 'c' => $ckey, 'at' => 'head' ), 'button' => 'Add head', 'source' => 'nobody' ) );
	}
	$row   = ogc_year_get( $y );
	$today = ogc_app_today( $y );
	foreach ( ogc_app_committee_needs( $y, $ckey ) as $n ) {
		if ( ! ogc_app_need_counts( $n ) ) {
			continue;
		}
		$w    = (string) $n['words'];
		$due  = ! empty( $n['due'] ) ? (string) $n['due'] : '';
		$late = ( $due && $due < $today ) || ( isset( $n['tone'] ) && 'late' === $n['tone'] );
		if ( $due && false === strpos( $w, ogc_app_md( $due, $y ) ) ) {
			$w .= ' · Due ' . ogc_app_md( $due, $y );
		}
		if ( $late && false === strpos( $w, 'Late' ) ) {
			$w .= ' · Late';
		}
		$go = isset( $n['go'] ) ? (array) $n['go'] : array();
		return array_merge( $out, array( 'words' => $w, 'due' => $due, 'tone' => $late ? 'late' : ( $due && ogc_app_days_to( $due, $today ) <= 14 ? 'look' : '' ), 'go' => $go, 'button' => (string) $n['button'], 'source' => 'need' ) );
	}
	$rows = ogc_app_work_rows( $y, $ckey );
	foreach ( $rows as $r ) {
		if ( in_array( $r['id'], array( 'requests', 'shifts' ), true ) || '' !== $r['handed'] || '' === $r['line'] || ( $r['on'] && $r['on'] > $today ) ) {
			continue;
		}
		return array_merge( $out, array( 'words' => $r['line'], 'go' => array( 's' => $r['id'] ), 'source' => 'work' ) );
	}
	foreach ( $rows as $r ) {
		if ( 'shifts' === $r['id'] && '' !== $r['line'] && 'No shifts' !== $r['line'] ) {
			return array_merge( $out, array( 'words' => $r['line'], 'go' => array( 's' => 'shifts', 'c' => 'coa' === $ckey || '' !== $r['handed'] ? '' : $ckey ), 'source' => 'shifts' ) );
		}
	}
	if ( ! ogc_app_friday( $y ) ) {
		return array_merge( $out, array( 'words' => 'Dates to come', 'source' => 'task' ) );
	}
	$tasks = ogc_app_tasks( $y, array( $ckey ) );
	foreach ( $tasks as $t ) {
		if ( ! $t['done'] ) {
			return array_merge( $out, array( 'words' => 'Next: ' . $t['title'] . ( $t['due_words'] ? ' · ' . $t['due_words'] : '' ), 'due' => $t['due'], 'go' => array( 's' => 'tasks', 'c' => 'coa' === $ckey ? '' : $ckey, 'id' => $t['id'] ), 'source' => 'task' ) );
		}
	}
	if ( $tasks ) {
		return array_merge( $out, array( 'words' => 'All ' . count( $tasks ) . ' tasks done', 'go' => array( 's' => 'tasks', 'c' => 'coa' === $ckey ? '' : $ckey ), 'source' => 'done' ) );
	}
	unset( $row );
	return $out;
}

/** The COA's own check of each committee's responsibilities and tasks this year: ckey → 'Y-m-d'. */
function ogc_app_duties_checked( $year ) {
	$s = function_exists( 'ogc_state_get' ) ? ogc_state_get( (int) $year, 'app-duties-checked' ) : null;
	return $s && is_array( $s['value'] ) ? $s['value'] : array();
}

function ogc_app_set_duties_checked( $year, $ckey, $on ) {
	for ( $i = 0; $i < 6; $i++ ) {
		$cur = ogc_state_get( (int) $year, 'app-duties-checked' );
		$v   = $cur && is_array( $cur['value'] ) ? $cur['value'] : array();
		if ( $on ) {
			$v[ $ckey ] = ogc_app_today( $year );
		} else {
			unset( $v[ $ckey ] );
		}
		if ( ! is_wp_error( ogc_state_put( (int) $year, 'app-duties-checked', (object) $v, $cur ? $cur['version'] : 0 ) ) ) {
			return true;
		}
	}
	return false;
}

/**
 * A committee's marks (area-committees 2.2), from fixed fields only. Each:
 *   { key: nobody|nohead|late|unchecked|soon, words, tone, go, reasons: [ { kind, words, n, due, go } ] }
 */
function ogc_app_committee_marks( $year, $ckey ) {
	$y     = (int) $year;
	$today = ogc_app_today( $y );
	$out   = array();
	if ( 'coa' !== $ckey ) {
		$people = ogc_app_people( $y, $ckey );
		$add    = array( 's' => 'members', 'id' => 'new', 'c' => $ckey, 'at' => 'head' );
		if ( ! $people ) {
			$out[] = array( 'key' => 'nobody', 'words' => 'No one on it', 'tone' => 'late', 'go' => $add, 'reasons' => array() );
		} elseif ( ! array_filter( $people, function ( $m ) {
			return ! empty( $m['head'] );
		} ) ) {
			$out[] = array( 'key' => 'nohead', 'words' => 'No head', 'tone' => 'late', 'go' => $add, 'reasons' => array() );
		}
	}
	$late = array();
	$soon = array();
	$lt   = array_values( array_filter( ogc_app_tasks( $y, array( $ckey ) ), function ( $t ) {
		return $t['late'];
	} ) );
	if ( $lt ) {
		$late[] = array( 'kind' => 'tasks', 'words' => ogc_app_plural( count( $lt ), 'task' ) . ' late', 'n' => count( $lt ), 'due' => $lt[0]['due'], 'go' => array( 's' => 'tasks', 'c' => 'coa' === $ckey ? '' : $ckey, 'v' => 'late' ) );
	}
	foreach ( ogc_app_committee_needs( $y, $ckey ) as $n ) {
		if ( ! ogc_app_need_counts( $n ) || 0 === strpos( (string) $n['key'], 'task:' ) ) {
			continue;
		}
		$due  = ! empty( $n['due'] ) ? (string) $n['due'] : '';
		$kind = 0 === strpos( (string) $n['key'], 'round:' ) ? 'requests' : ( 0 === strpos( (string) $n['key'], 'report:' ) ? 'report' : 'need' );
		$r    = array( 'kind' => $kind, 'words' => 'requests' === $kind ? 'Requests late' : (string) $n['words'], 'n' => 0, 'due' => $due, 'go' => (array) $n['go'] );
		if ( ( $due && $due < $today ) || ( isset( $n['tone'] ) && 'late' === $n['tone'] ) ) {
			$late[] = $r;
		} elseif ( $due && ogc_app_days_to( $due, $today ) <= 14 ) {
			$soon[] = $r;
		}
	}
	if ( $late ) {
		$out[] = array( 'key' => 'late', 'words' => count( $late ) > 1 ? count( $late ) . ' late' : $late[0]['words'], 'tone' => 'late', 'go' => $late[0]['go'], 'reasons' => $late );
	}
	$dc = ogc_app_duties_checked( $y );
	if ( empty( $dc[ $ckey ] ) ) {
		$c     = ogc_app_committee( $y, $ckey );
		$out[] = array( 'key' => 'unchecked', 'words' => 'Not checked', 'tone' => 'look', 'go' => array( 's' => 'committees', 'c' => $ckey, 'v' => 'from' ), 'reasons' => array(), 'source' => $c && $c['from_year'] ? 'carried' : 'seeded' );
	}
	if ( $soon && ! $late ) {
		$out[] = array( 'key' => 'soon', 'words' => 'Due soon', 'tone' => 'look', 'go' => $soon[0]['go'], 'reasons' => $soon );
	}
	return $out;
}

/* ================================================================== Works with: the fixed hand-off table */

/** Who holds a handable screen this year: a committee key, or 'coa'. */
function ogc_app_holder( $year, $screen ) {
	$to = ogc_app_handed_to( (int) $year, $screen );
	return '' !== $to ? $to : 'coa';
}

function ogc_app_holder_name( $year, $ckey ) {
	if ( 'coa' === $ckey ) {
		return 'the COA';
	}
	$c = ogc_app_committee( (int) $year, $ckey );
	return $c ? $c['name'] : $ckey;
}

/**
 * The fixed hand-off table (area-committees 15): each hand-off whose two ends are screens. Parties are
 * committee keys, holder:<screen> (looked up, never written down), or outside parties in words.
 */
function ogc_app_handoffs() {
	return array(
		array( 'n' => 1, 'from' => 'holder:intake', 'to' => 'every', 'what' => 'The round', 'short' => 'Sends you the round' ),
		array( 'n' => 4, 'from' => 'holder:intake', 'to' => 'campus', 'what' => 'The campus list', 'go_from' => 'intake' ),
		array( 'n' => 5, 'from' => 'holder:registration', 'to' => array( 'lodging', 'food', 'preteens', 'nursery', 'communion', 'young folks' ), 'what' => 'Their lists', 'go_from' => 'registration',
			'their' => array( 'lodging' => array( 'Households', 'lod-households' ), 'food' => array( 'Meal counts', 'food-meals' ), 'preteens' => array( 'Children', 'preteens-list' ), 'nursery' => array( 'Counts by day', 'nursery-list' ), 'communion' => array( 'Communing', 'communion-list' ), 'young folks' => array( 'Halls', 'yf-halls' ) ) ),
		array( 'n' => 6, 'from' => 'lodging', 'to' => 'young folks', 'what' => 'Rooms in the halls', 'go_from' => 'lod-rooms', 'go_to' => 'yf-halls' ),
		array( 'n' => 7, 'from' => 'lodging', 'to' => 'campus', 'what' => 'Final counts', 'go_from' => 'lod-counts' ),
		array( 'n' => 8, 'from' => 'food', 'to' => 'caterer', 'what' => 'Meal counts', 'go_from' => 'food-meals' ),
		array( 'n' => 9, 'from' => 'communion', 'to' => 'food', 'what' => 'Communion meal count', 'go_from' => 'communion-list', 'go_to' => 'food-meals' ),
		array( 'n' => 10, 'from' => 'holder:households', 'to' => array( 'lodging', 'food' ), 'what' => 'Didn’t come', 'go_from' => 'households', 'their' => array( 'lodging' => array( 'Didn’t come', 'lod-households' ), 'food' => array( 'Didn’t come', 'food-meals' ) ) ),
		array( 'n' => 11, 'from' => 'holder:schedule', 'to' => 'every', 'what' => 'The week', 'short' => 'Publishes the schedule' ),
		array( 'n' => 12, 'from' => 'holder:schedule', 'to' => 'holder:callin', 'what' => 'Rows on the call-in line', 'go_from' => 'schedule', 'go_to' => 'callin' ),
		array( 'n' => 13, 'from' => 'holder:callin', 'to' => 'testimony', 'what' => 'Number and times', 'go_from' => 'callin' ),
		array( 'n' => 14, 'from' => 'holder:shifts', 'to' => 'every', 'what' => 'Published sign-ups', 'short' => 'Publishes sign-ups' ),
	);
}

/** One end of a hand-off as committee keys (holders looked up), or the outside party's words. */
function ogc_app_handoff_end( $year, $end ) {
	if ( is_array( $end ) ) {
		return $end;
	}
	if ( 0 === strpos( $end, 'holder:' ) ) {
		$s = substr( $end, 7 );
		// Shifts isn't handable yet (Round 4): the COA publishes sign-ups.
		return array( 'shifts' === $s ? 'coa' : ogc_app_holder( $year, $s ) );
	}
	return in_array( $end, array( 'every', 'campus', 'caterer', 'testimony' ), true ) ? $end : array( $end );
}

/** A hand-off's state, in words only (never the other committee's numbers). */
function ogc_app_handoff_state( $year, $row ) {
	$y     = (int) $year;
	$today = ogc_app_today( $y );
	$md    = function ( $d ) use ( $y ) {
		return ogc_app_md( $d, $y );
	};
	$task  = function ( $ckey, $kind, $title = '' ) use ( $y ) {
		foreach ( ogc_app_tasks( $y, array( $ckey ) ) as $t ) {
			if ( ( $kind && $t['kind'] === $kind ) || ( ! $kind && $title && $t['title'] === $title ) ) {
				return $t;
			}
		}
		return null;
	};
	switch ( $row['n'] ) {
		case 1:
			$sp = ogc_app_round_span( $y );
			return $sp['until'] ? 'Due ' . $md( $sp['until'] ) : '';
		case 4:
			$s = function_exists( 'ogc_app_requests_sent' ) ? ogc_app_requests_sent( $y ) : '';
			return $s && substr( $s, 0, 10 ) <= $today ? 'Sent ' . $md( substr( $s, 0, 10 ) ) : 'Not sent';
		case 5:
			$r = function_exists( 'ogc_coa_kv' ) ? ogc_coa_kv( $y, 'registration' ) : array();
			$o = isset( $r['opens'] ) ? (string) $r['opens'] : '';
			$c = isset( $r['closes'] ) ? (string) $r['closes'] : '';
			if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $o ) || '9999-12-31' === $o ) {
				return 'Not scheduled';
			}
			return $today < $o ? 'Opens ' . $md( $o ) : ( $c && $today > $c ? 'Closed ' . $md( $c ) : 'Open' );
		case 6:
			$s = function_exists( 'ogc_lod_summary' ) ? ogc_lod_summary( $y ) : array( 'published' => '' );
			return $s['published'] ? 'Published ' . $md( substr( $s['published'], 0, 10 ) ) : 'Not yet';
		case 7:
			// Counts' own sends (Round 5, module-lodging-counts.php): the newest one's day.
			$sent = function_exists( 'ogc_lod_sent' ) ? ogc_lod_sent( $y ) : array();
			if ( $sent ) {
				return 'Sent ' . $md( $sent[0]['day'] );
			}
			$t = $task( 'lodging', 'lod_counts', 'Final counts and dorm keys' );
			return ( $t && $t['due'] ? 'Due ' . $md( $t['due'] ) . ' · ' : '' ) . 'Not sent';
		case 8:
			// Meal counts' own fact (Round 6, module-lists-facts.php): the same words its screen says.
			if ( function_exists( 'ogc_lst_fact' ) ) {
				$f = ogc_lst_fact( $y, 'meals' );
				return '' !== $f['line'] ? $f['line'] : 'Not sent';
			}
			$sent = function_exists( 'ogc_lst_sent' ) ? ogc_lst_sent( $y ) : array();
			if ( $sent ) {
				return ( ! empty( $sent[0]['final'] ) ? 'Final sent ' : 'Sent ' ) . $md( $sent[0]['day'] );
			}
			$due = ogc_app_task_kind_due( 'meals_sent', $y );
			return ( $due ? 'Due ' . $md( $due ) . ' · ' : '' ) . 'Not sent';
		case 9:
			return 'From registrations';
		case 10:
			$row = ogc_year_get( $y );
			return $row && ! empty( $row['start'] ) ? ( $today < $row['start'] ? 'From ' . $md( $row['start'] ) : 'Marked' ) : '';
		case 11:
		case 12:
			$s = function_exists( 'ogc_coa_kv' ) ? ogc_coa_kv( $y, 'settings' ) : array();
			$v = isset( $s['schedule_posted'] ) ? (string) $s['schedule_posted'] : '';
			return preg_match( '/^\d{4}-\d{2}-\d{2}$/', $v ) && '9999-12-31' !== $v && $v <= $today ? 'Published ' . $md( $v ) : 'Not public';
		case 13:
			$t = $task( ogc_app_holder( $y, 'callin' ), '', 'Call-in number to The Testimony' );
			if ( $t && $t['done'] ) {
				return 'Done' . ( $t['done_on'] ? ' ' . $t['done_on'] : '' );
			}
			return $t && $t['due'] ? 'Due ' . $md( $t['due'] ) : '';
		case 14:
			$s = function_exists( 'ogc_coa_kv' ) ? ogc_coa_kv( $y, 'settings' ) : array();
			$v = isset( $s['signups_posted'] ) ? (string) $s['signups_posted'] : '';
			return preg_match( '/^\d{4}-\d{2}-\d{2}$/', $v ) && '9999-12-31' !== $v ? ( $v <= $today ? 'Published ' . $md( $v ) : 'Opens ' . $md( $v ) ) : 'Not public';
	}
	return '';
}

/**
 * Works with, for a committee's page (decision 5: only the pairs; the round, the published schedule and
 * sign-ups are its Work rows). With $other (a reader on another committee): Works with you, only the
 * rows whose two ends are these two, read from the reader's side, rows 1, 11 and 14 included when this
 * committee holds them. Each line: { dir: gives|gets|sends, other: [ {key, name} ], what, state, go }.
 */
function ogc_app_works_with( $year, $ckey, $other = '' ) {
	$y      = (int) $year;
	$out    = array();
	$outside = array( 'campus' => 'the campus', 'caterer' => 'the caterer', 'testimony' => 'The Testimony' );
	foreach ( ogc_app_handoffs() as $h ) {
		$from = ogc_app_handoff_end( $y, $h['from'] );
		$to   = ogc_app_handoff_end( $y, $h['to'] );
		if ( '' === $other ) {
			if ( 'every' === $h['to'] ) {
				continue;
			}
			$gives = is_array( $from ) && in_array( $ckey, $from, true );
			$gets  = is_array( $to ) && in_array( $ckey, $to, true );
			if ( ! $gives && ! $gets ) {
				continue;
			}
			// A row whose two ends are the same committee isn't drawn (the COA holding Schedule and Call-in).
			if ( $gives && $gets ) {
				continue;
			}
			if ( $gives ) {
				$names = is_array( $to ) ? array_map( function ( $k ) use ( $y ) {
					return array( 'key' => $k, 'name' => 'coa' === $k ? 'the COA' : ogc_app_holder_name( $y, $k ) );
				}, array_values( array_filter( $to, function ( $k ) use ( $y ) {
					return (bool) ogc_app_committee( $y, $k );
				} ) ) ) : array( array( 'key' => '', 'name' => $outside[ $to ] ) );
				if ( ! $names ) {
					continue;
				}
				$out[] = array( 'n' => $h['n'], 'dir' => 'gives', 'other' => $names, 'what' => $h['what'], 'state' => ogc_app_handoff_state( $y, $h ), 'go' => isset( $h['go_from'] ) ? array( 's' => $h['go_from'] ) : null );
			} else {
				$giver = $from[0];
				$what  = isset( $h['their'][ $ckey ] ) ? $h['their'][ $ckey ][0] : $h['what'];
				$go    = isset( $h['their'][ $ckey ] ) ? $h['their'][ $ckey ][1] : ( isset( $h['go_to'] ) ? $h['go_to'] : '' );
				$out[] = array( 'n' => $h['n'], 'dir' => 'gets', 'other' => array( array( 'key' => $giver, 'name' => ogc_app_holder_name( $y, $giver ) ) ), 'what' => $what, 'state' => ogc_app_handoff_state( $y, $h ), 'go' => $go ? array( 's' => $go ) : null );
			}
			continue;
		}
		// Works with you: this committee ($ckey) and the reader's ($other) at the two ends.
		$from_this = is_array( $from ) && in_array( $ckey, $from, true );
		$to_other  = 'every' === $to ? 'coa' !== $other : ( is_array( $to ) && in_array( $other, $to, true ) );
		$from_other = is_array( $from ) && in_array( $other, $from, true );
		$to_this    = is_array( $to ) && in_array( $ckey, $to, true );
		if ( $from_this && $to_other && $ckey !== $other ) {
			$words = isset( $h['short'] ) ? $h['short'] : 'Gives you';
			$what  = isset( $h['short'] ) ? '' : ( isset( $h['their'][ $other ] ) ? $h['their'][ $other ][0] : $h['what'] );
			$go    = isset( $h['their'][ $other ] ) ? $h['their'][ $other ][1] : ( isset( $h['go_to'] ) ? $h['go_to'] : '' );
			if ( 1 === $h['n'] ) {
				$go = 'requests';
			}
			$out[] = array( 'n' => $h['n'], 'dir' => 'sends', 'words' => $words, 'what' => $what, 'state' => ogc_app_handoff_state( $y, $h ), 'go' => $go ? array( 's' => $go, 'c' => 'requests' === $go ? $other : '' ) : null );
		} elseif ( $from_other && $to_this && 'every' !== $h['to'] ) {
			$out[] = array( 'n' => $h['n'], 'dir' => 'sends', 'words' => 'Gets from you', 'what' => $h['what'], 'state' => ogc_app_handoff_state( $y, $h ), 'go' => isset( $h['go_from'] ) ? array( 's' => $h['go_from'] ) : null );
		}
	}
	return $out;
}

/* ================================================================== Home: First steps, Final counts, Committees */

/** The year's first-steps state: { step: 'Y-m-d' } the first day each was done (kept, so a head who
 * steps down in March doesn't reopen "Add heads"). */
function ogc_app_first_state( $year ) {
	$s = function_exists( 'ogc_state_get' ) ? ogc_state_get( (int) $year, 'app-first-steps' ) : null;
	return $s && is_array( $s['value'] ) ? $s['value'] : array();
}

/**
 * Is a stamp done by today? A COA check (`{ at: 'Y-m-d', … }`) or a kept first step ('Y-m-d') counts from
 * its own day, as a sample record does (Oct 16: the sample 2027's dates are checked on Nov 1, so a
 * preview of Oct 15 still asks to check them). A stamp with no day counts.
 */
function ogc_app_done_by( $stamp, $today ) {
	if ( empty( $stamp ) ) {
		return false;
	}
	$at = is_array( $stamp ) ? ( isset( $stamp['at'] ) ? (string) $stamp['at'] : '' ) : ( is_string( $stamp ) ? $stamp : '' );
	return ! preg_match( '/^\d{4}-\d{2}-\d{2}/', $at ) || substr( $at, 0, 10 ) <= $today;
}

/** Are the year's dates checked by today ("From 2026 · Looks right" on Dates and place)? */
function ogc_app_dates_checked( $year ) {
	$c = function_exists( 'ogc_coa_state' ) ? ogc_coa_state( (int) $year ) : array( 'checks' => array() );
	return ogc_app_done_by( isset( $c['checks']['conf:dates'] ) ? $c['checks']['conf:dates'] : null, ogc_app_today( $year ) );
}

function ogc_app_first_mark( $year, $step, $on = true ) {
	for ( $i = 0; $i < 6; $i++ ) {
		$cur = ogc_state_get( (int) $year, 'app-first-steps' );
		$v   = $cur && is_array( $cur['value'] ) ? $cur['value'] : array();
		if ( $on && ! empty( $v[ $step ] ) ) {
			return true;
		}
		if ( $on ) {
			$v[ $step ] = ogc_app_today( $year );
		} else {
			unset( $v[ $step ] );
		}
		if ( ! is_wp_error( ogc_state_put( (int) $year, 'app-first-steps', (object) $v, $cur ? $cur['version'] : 0 ) ) ) {
			return true;
		}
	}
	return false;
}

/**
 * The COA's five first steps (area-home-tasks 1.4), each ticking itself when its work is done:
 * Check dates · Check committees · Who runs what · Add heads · Handles money. null once all five are done
 * (or in the week and after).
 *   [ { key, words, line, act, go, done, on } ]
 */
function ogc_app_first_steps( $year ) {
	$y     = (int) $year;
	$phase = ogc_app_phase( $y )['phase'];
	// A step kept on a day after today (a preview of an earlier day) isn't done yet.
	$today = ogc_app_today( $y );
	$kept  = array_filter( ogc_app_first_state( $y ), function ( $d ) use ( $today ) {
		return ogc_app_done_by( $d, $today );
	} );
	$row   = ogc_year_get( $y );
	$coms  = array_values( array_filter( ogc_app_committees( $y ), function ( $c ) {
		return 'coa' !== $c['ckey'];
	} ) );
	$dc    = ogc_app_duties_checked( $y );
	$all   = ogc_app_committees( $y );
	$unch  = count( array_filter( $all, function ( $c ) use ( $dc ) {
		return empty( $dc[ $c['ckey'] ] );
	} ) );
	$nohead = array();
	foreach ( $coms as $c ) {
		if ( ! array_filter( ogc_app_people( $y, $c['ckey'] ), function ( $m ) {
			return ! empty( $m['head'] );
		} ) ) {
			$nohead[] = $c;
		}
	}
	$money = function_exists( 'ogc_member_money_emails' ) ? ogc_member_money_emails( $y ) : array();
	// Who runs what: last year's choice, or this year's.
	$prev   = ogc_app_prev_year( $y );
	$handed = array();
	foreach ( ogc_app_committees( $y ) as $c ) {
		foreach ( $c['screens'] as $s ) {
			$handed[ $c['name'] ][] = ogc_app_screen_title( $y, $s );
		}
	}
	$last = array();
	if ( $prev ) {
		foreach ( ogc_app_committees( $prev ) as $c ) {
			foreach ( $c['screens'] as $s ) {
				$last[ $c['name'] ][] = ogc_app_screen_title( $prev, $s );
			}
		}
	}
	$runs = function ( $list, $past ) {
		$bits = array();
		foreach ( $list as $name => $ss ) {
			$bits[] = $name . ( $past ? ' ran ' : ' runs ' ) . implode( ' and ', $ss );
		}
		return implode( ' · ', $bits );
	};
	$same = function_exists( 'ogc_app_handing' ) ? count( array_filter( ogc_app_handing( $y ), function ( $r ) {
		return ! empty( $r['differs'] );
	} ) ) : 0;
	$dates  = $row && ! empty( $row['start'] );
	$steps  = array(
		array(
			'key'   => 'dates',
			'words' => $dates ? 'Check dates' : 'Set dates',
			'line'  => $dates ? str_replace( ', ' . $y, '', ogc_app_range_words( $row ) ) . ( ! empty( $row['venue'] ) ? ' · ' . ogc_app_venue_short( $row['venue'] ) : '' ) : 'Dates to come',
			'act'   => $dates ? 'Check' : 'Set dates',
			'go'    => array( 's' => 'dates' ),
			'done'  => ! empty( $kept['dates'] ) || ogc_app_dates_checked( $y ),
		),
		array(
			'key'   => 'committees',
			'words' => 'Check committees',
			'line'  => ogc_app_plural( count( $all ), 'committee' ) . ( $unch ? ' · ' . $unch . ' not checked' : '' ),
			'act'   => 'Check ' . $unch,
			'go'    => array( 's' => 'committees', 'v' => 'from' ),
			'done'  => ! empty( $kept['committees'] ) || ! $unch,
		),
		array(
			'key'   => 'who',
			'words' => 'Who runs what',
			'line'  => $handed ? $runs( $handed, false ) : ( $last ? $prev . ': ' . $runs( $last, true ) : 'All with the COA' ),
			'act'   => $same && $last && ! $handed ? 'Same' : 'Looks right',
			'go'    => array( 's' => 'committees', 'c' => 'coa', 'at' => 'who' ),
			'done'  => ! empty( $kept['who'] ),
		),
		array(
			'key'   => 'heads',
			'words' => 'Add heads',
			'line'  => 1 === count( $nohead ) ? $nohead[0]['name'] . ' · ' . ( ogc_app_people( $y, $nohead[0]['ckey'] ) ? 'No head' : 'No one on it' ) : ( $nohead ? count( $nohead ) . ' committees with no head' : 'Every committee has a head' ),
			'act'   => 1 === count( $nohead ) ? 'Add head' : 'Add heads',
			'go'    => 1 === count( $nohead ) ? array( 's' => 'members', 'id' => 'new', 'c' => $nohead[0]['ckey'], 'at' => 'head' ) : array( 's' => 'committees', 'v' => 'nohead' ),
			'done'  => ! empty( $kept['heads'] ) || ! $nohead,
		),
		array(
			'key'   => 'money',
			'words' => 'Handles money',
			'line'  => $money ? implode( ', ', array_map( function ( $e ) use ( $y ) {
				$m = ogc_app_member_by_email( $y, $e );
				return $m ? ogc_app_person_name( $m ) : 'Ticked';
			}, array_slice( $money, 0, 2 ) ) ) : 'No one yet · Before registration opens',
			'act'   => 'Choose',
			'go'    => array( 's' => 'members', 'at' => 'money' ),
			'done'  => ! empty( $kept['money'] ) || (bool) $money,
		),
	);
	// What's done is read live from the data (no write on a read); Who runs what's answer is the one kept,
	// by the act that gives it (Same, Looks right, or a hand on Who runs what).
	foreach ( $steps as &$s ) {
		$s['on'] = ! empty( $kept[ $s['key'] ] ) ? ogc_app_md( $kept[ $s['key'] ], $y ) : '';
	}
	unset( $s );
	$done = count( array_filter( $steps, function ( $s ) {
		return $s['done'];
	} ) );
	if ( 5 === $done || ! in_array( $phase, array( 'before', 'nodates' ), true ) ) {
		return null;
	}
	return $steps;
}

/** A member by email for the year (the Handles money line names them, "Miriam K."). */
if ( ! function_exists( 'ogc_app_member_by_email' ) ) {
	function ogc_app_member_by_email( $year, $email ) {
		foreach ( ogc_members_list( (int) $year ) as $m ) {
			if ( strtolower( (string) $m['email'] ) === strtolower( (string) $email ) && ogc_member_active( $m ) ) {
				return $m;
			}
		}
		return null;
	}
}

/**
 * The Final counts line (area-home-tasks 1.6): the three sends the campus and the caterer need, from
 * two weeks before they're due until the first day. null outside that time.
 *   { words, due, late, go, parts: [ { name, state, tone, go } ] }
 */
function ogc_app_final_counts( $year ) {
	$y     = (int) $year;
	$today = ogc_app_today( $y );
	$row   = ogc_year_get( $y );
	if ( ! $row || empty( $row['start'] ) || $today >= $row['start'] ) {
		return null;
	}
	$due  = '';
	$task = null;
	foreach ( ogc_app_tasks( $y, array( 'coa' ) ) as $t ) {
		if ( 'final_counts' === $t['kind'] ) {
			$task = $t;
			$due  = $t['due'];
		}
	}
	if ( ! $due ) {
		$due = gmdate( 'Y-m-d', strtotime( $row['start'] . ' 12:00 UTC' ) - 14 * DAY_IN_SECONDS );
	}
	if ( ogc_app_days_to( $due, $today ) > 14 ) {
		return null;
	}
	$h     = ogc_app_handoffs();
	$state = function ( $n ) use ( $y, $h ) {
		foreach ( $h as $r ) {
			if ( $n === $r['n'] ) {
				return ogc_app_handoff_state( $y, $r );
			}
		}
		return '';
	};
	$parts = array();
	$c4    = $state( 4 );
	$parts[] = array( 'name' => 'Campus list', 'state' => $c4, 'tone' => 0 === strpos( $c4, 'Sent' ) ? '' : 'need', 'go' => array( 's' => 'intake' ) );
	$c7    = preg_replace( '/^Due [^·]+ · /u', '', $state( 7 ) );
	// Lodging's Counts (Round 5): "Not sent" opens it, "Sent May 12" its Sent list.
	$parts[] = array( 'name' => 'Lodging', 'state' => $c7, 'tone' => 0 === strpos( $c7, 'Sent' ) ? '' : 'need', 'go' => 0 === strpos( $c7, 'Sent' ) ? array( 's' => 'lod-counts', 'at' => 'sent' ) : array( 's' => 'lod-counts' ) );
	// Food's Meal counts (Round 6): its own fact. "Not sent" opens the send panel; sent, the Sent list. A
	// part is done once a send went and nothing has changed since it (Lodging's rule: any send counts).
	$c8    = preg_replace( '/^Due [^·]+ · /u', '', $state( 8 ) );
	$f8    = function_exists( 'ogc_lst_fact' ) ? ogc_lst_fact( $y, 'meals' ) : array( 'n' => 0 );
	$sent8 = 0 !== strpos( $c8, 'Not' ) && false !== strpos( $c8, 'ent ' );
	$done8 = $sent8 && empty( $f8['n'] );
	$parts[] = array( 'name' => 'Food', 'state' => $c8, 'tone' => $done8 ? '' : 'need', 'go' => $sent8 ? array( 's' => 'food-meals', 'at' => $done8 ? 'sent' : 'send' ) : array( 's' => 'food-meals', 'at' => 'send' ) );
	$all  = ! array_filter( $parts, function ( $p ) {
		return 'need' === $p['tone'];
	} );
	$late = ! $all && $due < $today;
	return array(
		'words' => 'Final counts · ' . ( $all ? 'All sent' : 'Due ' . ogc_app_md( $due, $y ) . ( $late ? ' · Late' : '' ) ),
		'due'   => $due,
		'late'  => $late,
		'go'    => $task ? array( 's' => 'tasks', 'id' => $task['id'] ) : array( 's' => 'tasks' ),
		'parts' => $parts,
		'kind'  => 'final_counts',
	);
}

/**
 * Home's Committees block (area-home-tasks 1.7): at most five lines, only committees late or needing a
 * look, from the board's own marks. While First steps asks for heads or checks, those aren't said twice.
 * Three or more with one reason fold into one line that opens the view holding them, with its count.
 */
function ogc_app_home_committees( $year, $steps ) {
	$y      = (int) $year;
	$ask    = array();
	foreach ( (array) $steps as $s ) {
		if ( ! $s['done'] ) {
			$ask[ $s['key'] ] = true;
		}
	}
	$groups = array( 'nobody' => array(), 'requests' => array(), 'tasks' => array(), 'report' => array(), 'need' => array(), 'unchecked' => array() );
	foreach ( ogc_app_committees( $y ) as $c ) {
		// The COA's own late work is in its Needs you; the block is the other committees (1.7).
		if ( 'coa' === $c['ckey'] ) {
			continue;
		}
		foreach ( ogc_app_committee_marks( $y, $c['ckey'] ) as $m ) {
			if ( in_array( $m['key'], array( 'nobody', 'nohead' ), true ) && empty( $ask['heads'] ) ) {
				$groups['nobody'][] = array( 'c' => $c, 'm' => $m );
			} elseif ( 'late' === $m['key'] ) {
				// One line a committee for each reason (two late needs are one "Late").
				$seen = array();
				foreach ( $m['reasons'] as $r ) {
					if ( isset( $seen[ $r['kind'] ] ) ) {
						continue;
					}
					$seen[ $r['kind'] ] = true;
					$groups[ $r['kind'] ][] = array( 'c' => $c, 'm' => $m, 'r' => $r );
				}
			} elseif ( 'unchecked' === $m['key'] && empty( $ask['committees'] ) ) {
				$groups['unchecked'][] = array( 'c' => $c, 'm' => $m );
			}
		}
	}
	$lines = array();
	$names = function ( $list ) {
		$n = array_map( function ( $x ) {
			return $x['c']['name'];
		}, $list );
		return count( $n ) > 3 ? implode( ', ', array_slice( $n, 0, 3 ) ) . ' and ' . ( count( $n ) - 3 ) . ' more' : implode( ', ', $n );
	};
	foreach ( $groups as $kind => $list ) {
		if ( ! $list ) {
			continue;
		}
		if ( count( $list ) >= 3 ) {
			if ( 'nobody' === $kind ) {
				$lines[] = array( 'words' => 'Need a head · ' . count( $list ) . ' committees', 'why' => $names( $list ), 'act' => 'Add heads', 'go' => array( 's' => 'committees', 'v' => 'nohead' ) );
			} elseif ( 'tasks' === $kind ) {
				$n = 0;
				foreach ( $list as $x ) {
					$n += (int) $x['r']['n'];
				}
				$lines[] = array( 'words' => ogc_app_plural( $n, 'task' ) . ' late · ' . count( $list ) . ' committees', 'why' => $names( $list ), 'act' => 'Open', 'go' => array( 's' => 'tasks', 'v' => 'late' ) );
			} elseif ( 'requests' === $kind ) {
				$lines[] = array( 'words' => 'Requests late · ' . count( $list ) . ' committees', 'why' => $names( $list ), 'act' => 'Open', 'go' => array( 's' => 'intake', 'v' => 'waiting' ) );
			} elseif ( 'unchecked' === $kind ) {
				$lines[] = array( 'words' => 'Not checked · ' . count( $list ) . ' committees', 'why' => $names( $list ), 'act' => 'Check', 'go' => array( 's' => 'committees', 'v' => 'from' ) );
			} else {
				$lines[] = array( 'words' => 'Late · ' . count( $list ) . ' committees', 'why' => $names( $list ), 'act' => 'Open', 'go' => array( 's' => 'committees', 'v' => 'late' ) );
			}
			continue;
		}
		foreach ( $list as $x ) {
			$c = $x['c'];
			if ( 'nobody' === $kind ) {
				$lines[] = array( 'words' => $c['name'] . ' · ' . $x['m']['words'], 'why' => trim( strtok( (string) $c['duties'], "\n" ) ), 'act' => 'Add head', 'go' => $x['m']['go'], 'c' => $c['ckey'] );
			} elseif ( 'unchecked' === $kind ) {
				$lines[] = array( 'words' => $c['name'] . ' · Not checked', 'why' => $c['from_year'] ? 'From ' . $c['from_year'] : 'Written for ' . $y, 'act' => 'Check', 'go' => array( 's' => 'committees', 'c' => $c['ckey'], 'v' => 'from' ), 'c' => $c['ckey'] );
			} else {
				$r       = $x['r'];
				$lines[] = array( 'words' => $c['name'] . ' · ' . ( 'requests' === $kind ? 'Requests late' : $r['words'] ), 'why' => $r['due'] ? 'Due ' . ogc_app_md( $r['due'], $y ) : '', 'act' => 'Open', 'go' => $r['go'], 'c' => $c['ckey'] );
			}
		}
	}
	if ( count( $lines ) > 5 ) {
		$look = 0;
		foreach ( ogc_app_committees( $y ) as $c ) {
			$look += 'coa' !== $c['ckey'] && array_filter( ogc_app_committee_marks( $y, $c['ckey'] ), function ( $m ) {
				return 'soon' !== $m['key'];
			} ) ? 1 : 0;
		}
		$lines    = array_slice( $lines, 0, 4 );
		$lines[] = array( 'words' => 'Needs a look · ' . $look . ' committees', 'why' => '', 'act' => 'Open', 'go' => array( 's' => 'committees', 'v' => 'look' ) );
	}
	return $lines;
}

/* ================================================================== Who runs what */

/**
 * The rows of Who runs what (area-committees 12.2): one per screen the COA may hand, with who runs it
 * now, last year's holder beside it (a suggestion, never a fact), what handing grants, and the tasks that
 * move with it.
 */
function ogc_app_hand_grants() {
	return array(
		'campus'       => array( 'Buildings, rooms, pins and care nearby: add, change, remove', 'Dorm halls too' ),
		'intake'       => array( 'Every committee’s requests: read', 'Settle · Send · Remind · Export for campus · Mark sent' ),
		'schedule'     => array( 'Every row: add, change, remove', 'Publish · Publish changes' ),
		'callin'       => array( 'The line’s number and PIN · Rows on the line · Playback numbers' ),
		'registration' => array( 'Prices, dates and the form’s switches', 'Close · Reopen · Never a household' ),
		'households'   => array( 'Every household: open, New household, Change, Cancel', 'Names, phones, emails' ),
		'packet'       => array( 'Every part: change · Publish' ),
		'help'         => array( 'Help cards, notices · Publish' ),
		// The handing rule, from its one place (module-shifts.php ogc_shifts_hand_grants).
		'shifts'       => function_exists( 'ogc_shifts_grant_words' ) ? ogc_shifts_grant_words() : array(),
	);
}

function ogc_app_handing( $year ) {
	$y     = (int) $year;
	$prev  = ogc_app_prev_year( $y );
	$all   = ogc_app_screens( $y );
	$grant = ogc_app_hand_grants();
	$ppl   = function_exists( 'ogc_access_hand_people' ) ? ogc_access_hand_people() : array();
	$kinds = ogc_app_task_kinds();
	$out   = array();
	foreach ( $all as $id => $d ) {
		if ( empty( $d['handable'] ) || ! in_array( 'coa', $d['who'], true ) ) {
			continue;
		}
		$to   = ogc_app_handed_to( $y, $id );
		$last = null;
		if ( $prev ) {
			$lt   = ogc_app_handed_to( $prev, $id );
			$here = '' === $lt || (bool) ogc_app_committee( $y, $lt );
			$lc   = '' !== $lt ? ogc_app_committee( $prev, $lt ) : null;
			$last = array( 'to' => $lt, 'name' => '' === $lt ? 'COA' : ( $lc ? $lc['name'] : $lt ), 'here' => $here );
		}
		$tasks = array();
		foreach ( ogc_app_tasks( $y ) as $t ) {
			if ( ! $t['done'] && $t['kind'] && isset( $kinds[ $t['kind'] ] ) && $kinds[ $t['kind'] ]['screen'] === $id ) {
				$tasks[] = array( 'id' => $t['id'], 'title' => $t['title'], 'when' => $t['due_words'] );
			}
		}
		$tc    = '' !== $to ? ogc_app_committee( $y, $to ) : null;
		$out[] = array(
			'id'      => $id,
			'title'   => $d['title'],
			'to'      => $to,
			'to_name' => $tc ? $tc['name'] : 'COA',
			'last'    => $last,
			'differs' => $last && $last['here'] && $last['to'] !== $to,
			'grants'  => isset( $grant[ $id ] ) ? $grant[ $id ] : array(),
			'people'  => isset( $ppl[ $id ] ) ? $ppl[ $id ] : '',
			'tasks'   => $tasks,
		);
	}
	return $out;
}

add_action( 'rest_api_init', function () {
	$see = function ( $write ) {
		return function ( WP_REST_Request $req ) use ( $write ) {
			if ( ! ogc_app_tables_ready() || null === ogc_year_get( (int) $req['year'] ) ) {
				return new WP_Error( 'ogc_not_found', 'Not found.', array( 'status' => 404 ) );
			}
			$v = ogc_app_req_viewer( $req );
			if ( ! $v['coa'] ) {
				return ogc_rest_denied();
			}
			if ( $write && $v['as'] ) {
				return new WP_Error( 'ogc_read_only', 'Read only while seeing as', array( 'status' => 403 ) );
			}
			return true;
		};
	};
	register_rest_route( OGC_NS, '/app/(?P<year>\d{4})/handing', array( 'methods' => 'GET', 'callback' => 'ogc_app_rest_handing', 'permission_callback' => $see( false ) ) );
	register_rest_route( OGC_NS, '/app/(?P<year>\d{4})/handing/same', array( 'methods' => 'POST', 'callback' => 'ogc_app_rest_handing_same', 'permission_callback' => $see( true ) ) );
	register_rest_route( OGC_NS, '/app/(?P<year>\d{4})/first-steps', array( 'methods' => 'POST', 'callback' => 'ogc_app_rest_first_steps', 'permission_callback' => $see( true ) ) );
} );

function ogc_app_rest_handing( WP_REST_Request $req ) {
	$y = (int) $req['year'];
	return rest_ensure_response( array( 'rows' => ogc_app_handing( $y ), 'prev' => ogc_app_prev_year( $y ) ) );
}

/** Same as last year: hands each screen whose last holder differs and still exists. Households asks first
 * (409 ogc_hand_people with the list). Answers what changed, for Undo. */
function ogc_app_rest_handing_same( WP_REST_Request $req ) {
	global $wpdb;
	$y    = (int) $req['year'];
	$rows = array_values( array_filter( ogc_app_handing( $y ), function ( $r ) {
		return ! empty( $r['differs'] );
	} ) );
	$warn = array_values( array_filter( $rows, function ( $r ) {
		return '' !== $r['people'] && '' !== $r['last']['to'];
	} ) );
	if ( $warn && ! $req->get_param( 'confirm' ) ) {
		return new WP_Error( 'ogc_hand_people', $warn[0]['title'] . ' · ' . $warn[0]['people'], array( 'status' => 409, 'rows' => $rows ) );
	}
	$changed = array();
	foreach ( $rows as $r ) {
		$to = $r['last']['to'];
		foreach ( ogc_app_committees( $y ) as $c ) {
			$list = array_values( array_diff( $c['screens'], array( $r['id'] ) ) );
			if ( $c['ckey'] === $to ) {
				$list[] = $r['id'];
			}
			if ( $list !== $c['screens'] ) {
				$wpdb->update( ogc_table( 'committees' ), array( 'screens' => implode( ',', $list ), 'updated_at' => ogc_now() ), array( 'id' => (int) $c['id'] ) );
			}
		}
		ogc_app_committees( $y, true );
		ogc_app_move_screen_tasks( $y, $r['id'], $to );
		$changed[] = array( 'id' => $r['id'], 'title' => $r['title'], 'from' => $r['to'], 'to' => $to, 'to_name' => $r['last']['name'] );
	}
	ogc_app_first_mark( $y, 'who' );
	ogc_log( 'app_hand_same', $y, 'year:' . $y, array( 'ckey' => 'coa', 'title' => implode( ', ', wp_list_pluck( $changed, 'title' ) ), 'n' => count( $changed ) ) );
	return rest_ensure_response( array( 'changed' => $changed ) );
}

/** First steps' Looks right (Who runs what as it stands), or its Undo. */
function ogc_app_rest_first_steps( WP_REST_Request $req ) {
	$y    = (int) $req['year'];
	$step = sanitize_key( (string) $req->get_param( 'step' ) );
	if ( ! in_array( $step, array( 'who', 'dates' ), true ) ) {
		return new WP_Error( 'ogc_bad', 'Not a step', array( 'status' => 400 ) );
	}
	ogc_app_first_mark( $y, $step, false !== $req->get_param( 'done' ) && 'false' !== (string) $req->get_param( 'done' ) );
	return rest_ensure_response( array( 'step' => $step, 'done' => ! empty( ogc_app_first_state( $y )[ $step ] ) ) );
}

/* ================================================================== small agreements with the rest */

// Two kinds that only identify (Round 2): the COA's Final counts and Lodging's counts, so the Final counts
// line stands for its task (never said twice) and the hand-off table reads Lodging's due date.
add_filter( 'ogc_app_task_kinds', function ( $k ) {
	$k['final_counts'] = array( 'screen' => '', 'from' => 'Final counts' );
	$k['lod_counts']   = array( 'screen' => 'lod-counts', 'from' => 'Counts' );
	return $k;
} );

// The COA's Final counts ticks itself once every part drawn is sent (area-home-tasks 1.6).
add_filter( 'ogc_app_task_auto', function ( $done, $kind, $year, $ckey, $today ) {
	if ( 'final_counts' === $kind ) {
		// The line reads the task's own date (ogc_app_tasks), which asks this again: once is enough.
		static $busy = false;
		if ( $busy ) {
			return $done;
		}
		$busy = true;
		$f    = ogc_app_final_counts( $year );
		$busy = false;
		return $f && 0 === strpos( $f['words'], 'Final counts · All sent' ) ? $today : $done;
	}
	// Lodging's task ticks itself with its newest send (Round 5: Counts' Mark sent).
	if ( 'lod_counts' === $kind && function_exists( 'ogc_lod_sent' ) ) {
		$sent = ogc_lod_sent( (int) $year );
		return $sent ? $sent[0]['day'] : $done;
	}
	return $done;
}, 10, 5 );

// Once per site: the two seeded titles get their kinds, from the plugin's own seed (never anyone's typing).
add_action( 'init', function () {
	global $wpdb;
	if ( '4' !== (string) get_option( 'ogc_app_task_kinds' ) || ! function_exists( 'ogc_app_tables_ready' ) || ! ogc_app_tables_ready() ) {
		return;
	}
	foreach ( array( 'Final counts and keys to the campus' => 'final_counts', 'Final counts and dorm keys' => 'lod_counts' ) as $title => $kind ) {
		$wpdb->query( $wpdb->prepare( 'UPDATE ' . ogc_table( 'tasks' ) . " SET kind = %s WHERE title = %s AND kind = '' AND source IN ('seed','carried')", $kind, $title ) );
	}
	update_option( 'ogc_app_task_kinds', '5', false );
}, 48 );

// The invite names a committee's screens: its own page by the committee's name, never "Overview".
add_filter( 'ogc_committee_screens', function ( $words, $year, $key ) {
	$c = $year ? ogc_app_committee( (int) $year, $key ) : null;
	return $c ? preg_replace( '/^Overview\b/', $c['name'], (string) $words ) : $words;
}, 20, 3 );

// The registry, after every area has added its screens (README 2.1, area-committees decision 8):
// every committee has Shifts (module-shifts.php registers it: Round 4), and Money isn't handable (the
// Handles money tick brings it).
add_filter( 'ogc_app_screens', function ( $s, $year ) {
	if ( isset( $s['money'] ) ) {
		$s['money']['handable'] = false;
	}
	return $s;
}, 30, 2 );

// The line's kit and look, for the committee's page and Home.
add_filter( 'ogc_pages', function ( $p ) {
	if ( isset( $p['app'] ) ) {
		$p['app']['styles'][]  = 'app/screens/year-line.css';
		$p['app']['scripts'][] = 'app/screens/year-line.js';
	}
	return $p;
}, 21 );
