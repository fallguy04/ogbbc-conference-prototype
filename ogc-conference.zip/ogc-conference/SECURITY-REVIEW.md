# Security review: the Annual Conference plugin (Oct 18, 2026)

For Michael to bring to the Website Advisors (Nov 6), and for Corey to act on before go-live. Line numbers are as of this review.

## Summary

The plugin is in good shape. The server decides who sees what, and the core is sound: sign-in, the generic routes, uploads, and the dev-only switches. Five reviewers (me plus four focused passes) read every route, and we tried the important ones on a throwaway copy holding only made-up people.

We found **6 High** problems. Each let someone inside the year do more than the rules allow:
- a webmaster could put themselves on the COA;
- someone without Handles money could mark money paid;
- a registered 16-year-old could be named on the public volunteer page;
- a committee helper could read every committee head's email and phone, or look up any volunteer's phone.

**All six are fixed**, each with a test. One of the six, the phone look-up, is limited rather than closed; its proper fix is in the Medium table.

A second pass fixed the **six Medium findings that had one right answer**, each with a test: M3, M4, M5, M6, M10, and the counting half of M8. What's left is **8 Medium** and **23 Low**. Five of the eight are decisions, each with a recommendation under [Decisions left](#decisions-left). Mostly what's left is:
- sign-up abuse limits;
- what leaks when someone types another person's email;
- decisions for Michael, the Advisors or Corey.

Nothing found lets a stranger read a household's details, a child's notes or anyone's payments. The most a stranger can learn is M7: which shift a person holds, if they already know that person's email and full name.

## What was fixed

### High

| # | The hole | Where (fix) | Test |
|---|---|---|---|
| H1 | **A webmaster could put themselves on the COA.** They invited a placeholder address as COA, then changed that row's email to their own. That gave every household and every child's medical notes. The same trick worked for the COA on a helper's row. | `includes/module-members.php:1285-1291`: changing a row to your own address is refused (403 `ogc_self`), the same rule as inviting yourself. | `tools/sec-test.php` › Members |
| H2 | **A webmaster the COA removed could put themselves back** with Undo (restore) within the hour. | `includes/module-members.php:1231-1236`: nobody restores their own row. | › Members |
| H3 | **Money marked paid without Handles money.** (a) The COA, or a committee handed Households, could mark a check received through the generic records route (`checkGot`). (b) A committee handed Households could enter a desk registration as "Paid at the desk". | (a) `includes/module-registration.php:810-815` needs Handles money. (b) `includes/module-registration-routes.php:519-523` needs the desk rule (Handles money, or Lodging's Check-in), as the ledger's own desk payment already did. | › Money |
| H4 | **A registered under-18 could be named publicly.** When a head added a registered 16-year-old to a shift (or a name was edited), the sign-up had no "minor" mark. Once the household chose Show, the public page said "Timmy T.". | `includes/module-volunteer.php:1078-1106` and `:1118-1124`: the one naming rule (`ogc_vol_label_ok`) also reads the sign-up's own age and the household's registration (exact email and name, read once a request). The public page and the records route both use it. Checked on the copy: the name is gone. | › Volunteers |
| H5 | **Any helper could read every committee head's email and phone.** It came from `committees.csv` through the editors' `sync` and `history` routes, which skipped the read filter that the files route applies. | `includes/module-editors.php:852-855`: `sync` uses the same read filters. `:867-871`: the history of `committees` is the COA's and webmasters'. | › Committees' contacts |
| H6 | **A helper on the committee holding Shifts could look up any volunteer's phone, one by one, across every committee.** The grant is "a phone only on the person being moved", but the server can't see a Move. | `includes/module-shifts.php:1029-1037`: such look-ups are capped at 15 a day per person (filter `ogc_shifts_phone_per_day`). They were already logged. The committee's own people and the COA aren't limited. The proper fix is M13 below. | › Shifts' holder |

### Medium (second pass)

| # | The hole | Where (fix) | Test |
|---|---|---|---|
| M3 | **Lodging or the COA could move a minor's parent-approval email to their own address, then approve it.** | The rule: **only the household changes the parent's address. Someone entering a household for it (the COA, Lodging, a committee handed Households) may give one only where there was none, and never their own address or a committee's role address.** `includes/module-registration-routes.php:1044`: Change on the approval is 403 `ogc_parent_email` for anyone but the household; Resend to the address the household gave still works. `:720`: the form's Change, the same. `:533`: a desk, phone or paper entry with the person's own or a role address is refused at the field. `includes/module-registration.php:804`: the records route keeps the address as it was. `:133`: `ogc_reg_committee_address()` (the person typing, or `ogc_mail_role_addresses()`). | `tools/sec-test.php` › A parent's approval |
| M4 | **The treasurer's old ledger CSV kept a typed formula live.** | `includes/module-registration-routes.php:1200`: written by `ogc_rec_csv()`, the main exports' writer (an apostrophe before `=`, `+`, `-`, `@`; numbers left alone). `ogc_csv_write()` itself is unchanged (L20). | › The treasurer's old ledger CSV |
| M5 | **Any member could run `recode`**, rewriting the schedule's and every committee's shift places, each changed shift emailing its volunteers. | `includes/module-editors.php:897` (`ogc_ed_can_recode`): the COA and webmasters, or the committee the COA handed Campus to (the screen that calls it, `coa-campus.js`). Any request carrying `?as=` gets 403 `ogc_read_only`. A held year was already refused by the editors' own check. | › Place codes renamed |
| M6 | **Any committee could tick the COA's steps, mark notes Done, and set the requests' owner and due date** by sending `part=requests`, and `check` judged only its first id. | `includes/module-coa-app.php:185` (`ogc_coa_app_part_screen`): each part belongs to its screen, and the Requests part (the round) to Intake's holder, not to every committee. A step's part is its id's prefix and a note's is found by its hash; a `part` sent that doesn't match is the COA's. `:305`: every id of a check is judged. `:361`: the round's two settings, `tool_requests` and `requests_url`, follow the same rule through the files route. Mark sent was already the coordinator's (`module-requests.php:1597`). | › The COA's parts |
| M10 | **With `OGC_DEV` left on away from this Mac, one header (`X-OGC-Now`) set the volunteer clock for anyone.** | Every `OGC_DEV` check a request can reach now also needs a local address (`ogc_dev_tools_on()`): the header and `vol/dev/tick` (`module-volunteer-mail.php:1942`, `:1952`), `ogc_vol_set_now` (`module-volunteer.php:67`), `as_of` on the lists and Lodging (`module-lists.php:77`, `module-lodging.php:272`), the public pages' dev clock (`module-public.php:54`), the Tour script and the pages' `dev` flag (`core-pages.php:193`, `:214`), a member with no row counted as the COA (`module-members.php:574`, `module-app.php:206`), and the sample committee people (`module-app-seed.php:202`, `:238`). The other seeding steps still read `OGC_DEV` alone. They only add made-up rows, and `OGC_DEV` must still never be defined off the Mac. | › Dev time and switches |
| M8 (counting) | **The volunteer limits counted by `REMOTE_ADDR`**, so behind Nexcess's proxy, or on the campus wifi, the whole site shared one count. | `includes/module-auth.php:206` (`ogc_client_ip`): `X-Forwarded-For` is read only when the request comes from a proxy that `OGC_TRUSTED_PROXIES` names (README, for Corey). It takes the last address that isn't a proxy, so an address the visitor wrote in is never used. `includes/module-volunteer-rest.php:303` (`ogc_vol_rate_for`): each limit counts per email, per shift for a join (60 an hour) and the waitlist, and by address only where the site knows each visitor's (the constant, or the `ogc_client_ip` filter). Used by join `:1556`, Add someone `:1527`, unconfirmed places `:1597`, waitlist `:2187`, Email me `:2431` and Wrong email `:2501`. The numbers and their filters are as before. Still transients, not `ogc_throttle()`, because the tests reset them by name. Letting go of unconfirmed places is a decision (below). | › The visitor's address, › Volunteer limits |

`tools/sec-test.php` also checks the dev gates: with the site address on ogbbc.org, a `Host: localhost` or `X-Forwarded-*` header opens nothing. Run it on a copy:

```
FORCE=1 tools/wp-local.sh clone sec
PORT=<port> SITE=.wp-local/sec tools/wp-local.sh php tools/sec-test.php
```

It passes 89 of 89 checks with both passes' fixes. Against the plugin before the High fixes, 15 of the first 41 fail. Against the plugin with only the second pass's fixes taken out, 26 of the new checks fail, and the M8 section stops at a function that didn't exist yet. So each test catches its hole.

`tools/build-plugin.sh` now also leaves this file out of the zip for ogbbc.org, since it lists open weaknesses.

## Open findings

"Us" is the plugin (Michael and Claude); Corey reviews it. "Corey" is the server or hosting. "Advisors" is a decision.

### Medium

| # | Finding | Where | Recommended fix | Who |
|---|---|---|---|---|
| M1 | **Registering "for someone else" makes the helper a permanent manager of any email they name.** Nobody accepts. The named household's Your sign-ups then shows it as theirs. Whatever they add later, children's notes included, the helper can read. There's no way to remove a helper. | `module-registration-routes.php:537-542`, `:579` | The named household accepts by email before the helper manages it, and can remove a helper. A decision: see Decisions left. | Michael, then us |
| M2 | **Unpaid registrations hold linens, mattresses and rooms forever.** There is no per-email or per-day limit on registering. | `ogc_reg_rest_create` (`module-registration-routes.php:504`); only card holds are let go (`ogc_reg_unpaid_round`, `module-registration.php:1102`) | A per-email/day cap. Let go of unpaid check registrations after `check_by`. | Us |
| M7 | **A stranger who types someone's email and full name on the volunteer form learns things.** The refusals say which shift that person already holds at that time (Busy, with role and end), that they're already on the shift, or that they're under a shift's age rule. | `module-volunteer-rest.php:1742`, `:1792`, `:1799`, `:1809` | For an email this device hasn't proved, answer with a plain refusal ("Check your email"). Do the clash and age checks when the email confirms. A decision: see Decisions left. | Michael, then us |
| M8 | **Unconfirmed volunteer places are never let go** by default (`confirm_hours` 0), so a script can fill shifts with made-up names. (The counting half is fixed, above.) | `module-volunteer-mail.php:28`, `:1466-1470`, `:1552` | A decision: see M8 under Decisions left. | Michael, then us |
| M9 | **Leave and join loops send "Place open" emails to everyone waiting, and "Late" notices to heads, with no limit.** Members and role addresses skip the mail cap. Not measured. | `module-volunteer-rest.php:1957` (leave), `:2157` (wait); `module-volunteer-mail.php:199`; `module-mail.php:154` | Gather "Place open" per shift for an hour. Limit leaves per device. Cap even members' notices per kind. | Us |
| M11 | **`wp-login.php` tells anyone whether an email belongs to someone the site knows.** Both the password form and Lost password answer differently. That undoes the sign-in page's "same answer for every address". | WordPress core, plus `module-auth.php:600-622` | Filter `login_errors` and `lostpassword_errors` to one message for unknown and known people. Or a login-hardening plugin. See Decisions left. | Corey |
| M12 | **Webmasters sign in with the same emailed code as everyone.** Their mailbox reaches every year's structure and See as. | `module-auth.php:504-512`, `:624-634` | Advisors' open item 3: wp-login with a second step for `ogc_manage_all`. | Advisors, then Corey |
| M13 | **H6's proper fix.** The holder's phone look-up is still allowed 15 times a day for anyone on the holding committee. | `module-shifts.php:1017` | Tie the phone to the act. Return it in the Move's own answer, or with a one-use token the Move panel gets. Or limit it to heads. | Us |

### Low

| # | Finding | Where | Fix |
|---|---|---|---|
| L1 | A webmaster who isn't seeing as gets every member's email. | `GET years/{y}/members` (`module-members.php:1044`), `GET lists/{y}/access` (`module-lists.php:2038`) | Advisors' item 4: limit to the COA rows, as `app/{y}/person` does. |
| L2 | Plus-address aliases get around "nobody adds themselves" and "nobody ticks their own Handles money". A webmaster can do the same with the COA invite, and Privacy doesn't flag the alias. | `module-members.php` (`ogc_self`, money tick) | Compare addresses with `+tag` (and Gmail dots) removed. |
| L3 | Writes that carry `?as=` outside `/app/` aren't refused. They run with the person's own powers, so there's no gain, but the "read only" rule isn't enforced there. | `/reg/*`, `/coa/{y}/*`, `/years/{y}/files\|rows`, `/lists/{y}/*` (`recode` refuses it since M5) | One `rest_request_before_callbacks` filter: any non-GET under `ogc/v1` with `as` gets 403. |
| L4 | A rooming list downloads as Excel while seeing as. | `module-lodging-counts.php:175-205` | Refuse `format=xlsx` while seeing as. |
| L5 | A committee the COA names "Webmaster" would open the webmasters' screens. | `module-app.php:327`, `:445-450` | Reserve the keys `coa`, `webmaster`, `committee` and `all`. |
| L6 | Hall rows carry `uploaded_by` and `checked_by` emails to every member at that campus. | `module-map.php:566`, `:831`, `:927` | Drop them after working out the names. |
| L7 | Any committee reads the COA overview's 80 change-log lines. | `module-coa.php:530`, `module-coa-app.php:285` | Send the history only to the COA. |
| L8 | A date preview (`as_of` on boot) can carry last year's files early. | `module-app-rest.php:213`, `module-app.php:675-708` | Use the real date when deciding to carry. |
| L9 | The Excel import inflates zip entries with no size limit, so a member's crafted file uses up memory. | `module-editors.php:1083-1084` | `gzinflate( $raw, 32 * MB_IN_BYTES )`. |
| L10 | Food can set the caterer's email to any address and send counts repeatedly. Capped at 20 a day. | `lists/{y}/settings`, `meals/send` | Throttle `meals/send`. |
| L11 | `app/{y}/work?c=<other>` shows another committee's shift counts. | `module-app-committees.php:354-370` | Scope to one's own committees. |
| L12 | Webmasters can read people through the generic state route: `vol-return` (volunteers' emails and first names), `vol-head-digest` (who left), `member_asks` (names). | `module-guard.php:230-232` | Add them to `ogc_guard_state_people`. |
| L13 | Clearing after the Conference leaves things behind: `reg_notes`, the ledger's `paid_by` and `note`, and `managers`, `helper.email`, `stay.parentEmail`, `entered_by`. The privacy erase misses records where the person is the helper or the parent. | `module-privacy.php:61` (`ogc_priv_clear_year`, `ogc_priv_erase`) | Clear and erase those too. This goes with the Advisors' open item 1. |
| L14 | Medical notes read through `/reg/r/{id}` aren't logged as a sensitive view. The generic route does log it. | `ogc_reg_view` | Log `sensitive_view` there too. |
| L15 | The approval email's own builder still names the minor and their hall. The mail layer rebuilds it with no name (`mail_guarded`; checked: the sent subject was "Approval needed"), so the guard is load-bearing. The approval link never expires. | `module-registration-mail.php:560-563`; `module-mail.php:244` | Build it from the set. Give the link 14 days. |
| L16 | Three sign-in filters sign someone in with no proof, if any future code ever applies them. Nothing does today. | `module-auth.php:1166-1206` (`ogc_vol_signin`, `ogc_vol_link_signs_in`, `ogc_reg_sign_in`) | Remove them. |
| L17 | The parent-approval cookie is readable by scripts. | `module-guard.php:471` (`'httponly' => false`) | Make it HttpOnly, if the page doesn't read it. |
| L18 | The 30-day "Confirm it's you" applies only to `ogc_person` users. A site subscriber on a year keeps a year-long session. | `module-members.php:208` | Ask every member. |
| L19 | Withdrawing a team emails the typed team name to the typed mates' addresses. The signer must be signed in, and each address is capped. | `module-tournaments.php:660-664` | Leave the typed name out of mail to unproved addresses. |
| L20 | `ogc_csv_write` has no formula guard. Today only COA-typed files use it (the old ledger moved to `ogc_rec_csv`, M4). `committee-kit.js:102` has a guard-free fallback. | `includes/core.php:186` | Guard it there too, or move the remaining exports to `ogc_rec_csv`. |
| L21 | Card payments: no provider yet. Once one is added, the webhook is open to anyone and trusts the driver. `ogc_pay_answer` can flip a paid charge on a retry. | `module-payments.php:403-433` | Refuse a driver without a signature check. Use `ogc_pay_set_if(…, 'pending')`. |
| L22 | File downloads while seeing as aren't logged as See as. They are logged as downloads. | `module-guard.php:698-713` | Match `app/files/` too. |
| L23 | See as is logged once per committee per 30 minutes, not per household opened. | `module-app-rest.php:168-181` | Enough for now. Say so in the Nov 6 plan. |

## Decisions left

Each of these trades one good against another, so it isn't ours to settle in code. Each has a recommendation.

- **M1 · Registering "for someone else."** The helper manages the household they name for good, and that household never agreed. Recommendation: email the named household ("Ruth K. registered your household", with Accept and Not me). The helper manages it only once it's accepted; until then the helper sees what they entered and nothing added later, children's notes included. Give Your sign-ups a Remove beside each helper. *Michael decides, then us.*
- **M7 · What the volunteer form tells a stranger.** Typing someone's email and full name shows whether they hold another shift at that time, are on this one already, or are under its age rule. Recommendation: for an email this device hasn't proved, answer all three with the same "Check your email", and run the clash, already-on and age checks when the email's link is opened. A first-time volunteer then hears of a clash one step later, in the email. Signed-in volunteers see no change. *Michael decides, then us.*
- **M8 · Letting go of unconfirmed volunteer places.** A place whose email never confirms is held forever (`confirm_hours` 0), so a script can fill shifts with made-up names. Recommendation: hold a place a visitor made for 48 hours, then let it go. The reminder after a day already goes, and the head is already told by name and phone when a place opens. Say so in the confirmation email ("Held 2 days · Confirm"). Leave alone the places a committee head added, since the head vouches for them; today the release would take those too, so that's one line of code. *Michael decides (the COA's question 22), then us.*
- **M11 · What `wp-login.php` reveals.** Recommendation: Corey adds a small mu-plugin that filters `login_errors` and `lostpassword_errors` so a known and an unknown email get the same words, or uses a login-hardening plugin he trusts. It's the server's, not the plugin's. *Corey.*
- **M12 · How webmasters sign in.** Their mailbox reaches every year's structure and See as. Recommendation: webmasters sign in through wp-login with a second step, as site administrators already should. It's the Advisors' open item 3; Corey sets it up. *Advisors, then Corey.*

## What the server must provide (Corey)

- **HTTPS everywhere, and detected by WordPress behind the proxy.** Secure cookies follow `is_ssl()` (`module-auth.php:274`, and WordPress's own cookies). Set `$_SERVER['HTTPS']` from the proxy's header, use `FORCE_SSL_ADMIN`, and send HSTS.
- **Fixed site addresses.** Define `WP_HOME` and `WP_SITEURL` as `https://ogbbc.org`, never built from the Host header. "Local" is judged from `home_url()` (`core-dev.php:20-28`). Don't run any plugin that rewrites `home_url` per request.
- **Never `OGC_DEV` or `OGC_PROTOTYPE` on ogbbc.org or staging.** Staging uses `OGC_MAIL_CAPTURE` and `OGC_MAIL_ALLOW` (README).
- **The visitor's real address.** Define `OGC_TRUSTED_PROXIES` in wp-config.php with Nexcess's proxy addresses or ranges (README). The plugin then reads `X-Forwarded-For` from those proxies only. If Nexcess uses another header, return the address through the `ogc_client_ip` filter instead. Until one is set, the volunteer limits count per email and shift but never by address, and the sign-in's 300 an hour per address is one count for the whole site.
- **A real cron.** `define( 'DISABLE_WP_CRON', true );` and `*/5 * * * * curl -s https://ogbbc.org/wp-cron.php?doing_wp_cron`. The volunteer emails, reminders, the queue, and the clearing of names after the Conference all run on it.
- **No caching of the plugin's answers.** In WP Rocket, Nexcess's page cache and any CDN, never cache `/wp-json/ogc/` (including `/wp-json/ogc/v1/vol/`) or `/annual-conference/`. The plugin tells WP Rocket itself (`module-cache.php`), but the server and edge caches need it set by hand. Answers with people already send `no-store`.
- **`OGC_PRIVATE_DIR` outside the web root,** for committees' files (README). Without it, uploads are off.
- **nginx denies** for the plugin's `.md/.csv/.json/.sh` files and its `seed`, `templates` and `includes` folders (README; Apache uses the plugin's `.htaccess`).
- **Backups:**
  - the `<prefix>ogc_*` tables and `OGC_PRIVATE_DIR`;
  - encrypted, with access limited to who holds the hosting account;
  - a retention period that doesn't outlive the clearing of names (Advisors' item 1).
- **Accounts:**
  - site administrators use a second step;
  - no shared admin logins;
  - leave role `ogc_person` out of any user-syncing plugin (newsletters);
  - `WP_DEBUG_DISPLAY` off.
- **Mail:** SPF and DKIM for the From address (`ogc_mail_from`).

## What wasn't checked

- **Outside the plugin:**
  - the ogbbc theme and the site's other plugins;
  - WordPress core and wp-admin hardening;
  - Nexcess's own settings, caches and proxy headers.
- **Things that don't exist yet:**
  - real mail delivery;
  - a real card provider (none is wired up);
  - load, and denial of service beyond the sign-up limits above.
- **Rendering:** every screen in a browser for script injection. This was done by reading all the drawing code, plus end-to-end tries as a stranger on the volunteer page and the app's Helpers screen, which found nothing.
- **Other places:**
  - the shared prototype on WordPress Playground (each visitor's own copy, made-up data);
  - the guide's offline copy on real phones;
  - the sermon editor (`~/Developer/ogbbc-sermons`);
  - the mockups in `annual-conference/` and `v3/`.
- **Partly:** the tournaments module had a lighter pass than the rest.

## How it was checked

- Every REST route (230) by reading. A sweep of every GET route as seven kinds of people, with six committee values each, looking for emails, phones and children's fields. A sweep of every write while seeing as.
- A copy started at a non-local address, with and without `OGC_DEV`. The build script was run, and its zip read.
- The four focused passes: volunteers; registration, money and people; the app and committees; escaping and exports.
- The second pass: each Medium fix has its checks in `tools/sec-test.php`, run once against the plugin with only those fixes taken out (they fail) and once with them (they pass), each time on a throwaway copy.
- Every probe ran on throwaway copies of the local site with made-up people only.

## Test runs after the second pass (main site unless named)

- `bash tools/smoke.sh`: all passed (165).
- `node tools/route-check.mjs`: 0 dead ends (8 people, 477 addresses).
- `node tools/r3-test.mjs`: 53 passed, 0 failed.
- `node tools/r4-test.mjs`: 32 passed, 0 failed.
- `node tools/r5-test.mjs`: 62 passed, 0 failed (it saves, so on its own copy started with `PROTOTYPE=1`).
- `node tools/r6-test.mjs`: 131 passed, 0 failed.
- `node tools/r6b-test.mjs`: 87 passed, 0 failed.
- `tools/wp-local.sh php tools/vol-critic-test.php`: 264 ok, 0 failed.
- `tools/sec-test.php` on the `sec` copy: 89 ok, 0 failed (twice in a row).
