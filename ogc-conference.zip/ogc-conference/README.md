# OGBBC Annual Conference: install and run

The plugin behind ogbbc.org's Annual Conference: the Conference page, the guide, the printed schedule
and packet, registration, volunteer shifts, tournaments, Your sign-ups, and the committees' app at
`/annual-conference/app/`. It is a plugin only: nothing in the theme or wp-admin is changed, and it
draws its own pages at its own addresses. This file is the hand-off for whoever installs and runs it
(Corey). How to develop it is in `DEV.md` (in the repository, not in the release zip).

## Requirements

- WordPress 6.5 or newer (developed on 7.1).
- PHP 7.4 or newer. Every file parses on 7.4; it has been run on PHP 8.3–8.5 only. Run it once on
  Nexcess's PHP version on staging before go-live.
- PHP extensions: `zlib` and `SimpleXML` (reading Excel files the committees upload), `mbstring`.
- MySQL 8 or MariaDB 10.2+ (a unique key is about 1.4 KB in utf8mb4). All local testing is on SQLite:
  run the smoke checklist below once on staging's MySQL before go-live.

## Install

1. Build the zip from the repository: `tools/build-plugin.sh` writes `dist/ogc-conference-<version>.zip`.
   It leaves out the development notes, the made-up people and the dev-only pages.
2. Set the wp-config.php constants below (at least `OGC_PRIVATE_DIR`).
3. Upload and activate the plugin.

**What activation does:** makes the plugin's tables (`<prefix>ogc_*`, about 20), the `ogc_person`
role, five scheduled events, and the addresses under `/annual-conference/`. It loads **no data and no
made-up people.**

**Loading the years:** once, as a webmaster, `POST /wp-json/ogc/v1/seed` (with the wp_rest nonce; for
example from the browser console on any plugin page: `OGC_WP.api('POST', 'seed')`). It loads the
release's `seed/years.csv` and each year's files (the past years' schedules and sermons, 2027 as the
COA's working copy). A year still to come comes in with every "posted" setting held, so nothing of it
is public until the COA publishes it. A year already in the tables is never touched. Review
`seed/years.csv` before loading.

## wp-config.php

| Constant | What it does |
|---|---|
| `OGC_PRIVATE_DIR` | **Required for committees' files.** A folder outside the web root (not uploads: media is on DigitalOcean Spaces, and nginx ignores `.htaccess`). Without it, uploading is off and Site Health says so. Example: `define( 'OGC_PRIVATE_DIR', '/home/ogbbc/ogc-private' );` |
| `OGC_MAIL_CAPTURE` | Staging only: every email is kept in the Mail log (`/annual-conference/mail/`, webmasters) and none is sent. One-time links are removed from what's kept. |
| `OGC_MAIL_ALLOW` | Staging only, with capture: addresses that do get real mail (`'a@x.org, @church.org'`). |
| `OGC_TRUSTED_PROXIES` | **Set before go-live.** The proxy in front of the site (Nexcess's), so the sign-in and sign-up limits count each visitor, not the proxy: its addresses or ranges, comma-separated, e.g. `define( 'OGC_TRUSTED_PROXIES', '10.0.0.0/8, 192.0.2.10' );`. A request from one of them is read from `X-Forwarded-For` (the last address that isn't a proxy); from anywhere else the header is ignored, since anyone can write it. `'none'` says there's no proxy. Until it's set, nothing is counted by the address alone (one address behind the proxy is everyone). |
| `OGC_UNINSTALL_ERASE` | Set to `true` only when deleting the plugin should erase its tables and options (see Uninstall). |
| `OGC_DEV` | Never on ogbbc.org or staging. Local development only. |

## Filters to set (in a small mu-plugin)

- `ogc_client_ip`: the visitor's address, if Nexcess's proxy needs more than `OGC_TRUSTED_PROXIES`
  (another header). The sign-in and sign-up limits count by it.
- `ogc_mail_from`: the From name and address (default `conference@<site host>`). It must be allowed by
  the domain's SPF and signed by DKIM.
- `ogc_base_path`: the address under the site (default `annual-conference`).
- `ogc_pub_sermon_fields`, `ogc_pub_news_category`: how the theme's sermons and Conference News are
  found, if they differ from the defaults.
- `ogc_subscribers_are_people`: true only if the site's existing subscribers should be treated as the
  plugin's people (kept out of wp-admin, no password reset). Default: off.

## Server

- **nginx** (Apache uses the plugin's own `.htaccess`): deny the plugin's non-web files:
  `location ~* /wp-content/plugins/ogc-conference/.*\.(md|csv|json|sh)$ { deny all; }` and
  `location ~* /wp-content/plugins/ogc-conference/(seed|templates|includes)/ { deny all; }`.
- For `/annual-conference/`: `Content-Security-Policy: frame-ancestors 'self'`,
  `X-Frame-Options: SAMEORIGIN`, `Referrer-Policy: strict-origin-when-cross-origin` (PHP sends them on
  the Conference page and the guide; set them in the server too, so a cached copy has them).
- **Cron:** the volunteer emails run every five minutes. Set `define( 'DISABLE_WP_CRON', true );` and a
  real crontab: `*/5 * * * * curl -s https://ogbbc.org/wp-cron.php?doing_wp_cron > /dev/null`.

## WP Rocket

The plugin tells WP Rocket itself (`includes/module-cache.php`): its pages are never cached; its
scripts and styles are never delayed, deferred, combined, minified or reduced by Remove Unused CSS.
Nothing to set by hand. Check after install: Settings › WP Rocket › Advanced Rules shows nothing of
the plugin's, but a cached copy of `/annual-conference/` should never exist
(`wp-content/cache/wp-rocket/ogbbc.org/annual-conference/`).

## Mail

Every email goes through `wp_mail`. Use the site's SMTP plugin, with SPF and DKIM set for the From
domain. On staging, use `OGC_MAIL_CAPTURE` so nothing reaches real people.

## Samples

The release has none. A staging copy may load the made-up households and volunteers for the COA's
walk-through only on a local address (`OGC_DEV`); `DELETE /wp-json/ogc/v1/years/{year}/samples`
(webmasters) removes any sample records, their places on shifts, their ledger rows and sample notes.
Registration doesn't open and volunteer sign-ups can't be published while sample records are in a
year.

## People's data

- Names and contacts are cleared `clear_after_days` (default 60) after each Conference: phones,
  contacts, children's details, rooming, rooms chosen, walker and ground-floor asks, cancelled
  registrations, Lodging's rooms, the COA's phone list and the year's volunteer emails. Counts stay.
  Kept on purpose, for the Advisors' Nov 6 decision: a registration's household email, names and
  ages (Reuse next year), the change log (no personal data by rule) and the WordPress users.
- Tools › Export Personal Data and Erase Personal Data find a person's sign-ups by email.
- Tables that grow: `ogc_log` and `ogc_rowlog` (kept: the history of changes, no personal data),
  `ogc_vol_outbox` (sent emails go after 30 days), `ogc_hits` (sign-in limits).

## Upgrade, rollback, backups

- Bump `OGC_VERSION` in `ogc-conference.php` with every release (the addresses are refreshed by it),
  and `OGC_DB_VERSION` when a table changes. A changed schema is applied on the next request, by one
  request at a time; the stamp is saved only when every table exists (failures go to the PHP error
  log).
- Rollback: install the previous zip. Tables are only ever added to, never dropped, so an older
  version runs on a newer database.
- Back up the `<prefix>ogc_*` tables with the site, and the `OGC_PRIVATE_DIR` folder.

## Deactivate and uninstall

- Deactivating stops the timers and removes the addresses; all data stays.
- Deleting the plugin keeps all data too, unless `OGC_UNINSTALL_ERASE` is `true`: then its tables,
  options, user meta, the private files folder and the `ogc_person` role go (its users stay, as
  subscribers).

## Ten-minute check after install or upgrade

1. `/annual-conference/` answers, signed out, with no console error.
2. `/wp-json/ogc/v1/years` lists the years; `/wp-json/ogc/v1/years/2027/records?kinds=signups` signed
   out shows no emails or phones.
3. `/annual-conference/app/` sends a visitor to sign-in; a webmaster signs in by emailed link or code.
4. As a webmaster, the app's Years screen lists the years; Site Health shows "Committees' files have a
   private folder".
5. `/?author=2` (any plugin person's id) answers 404.
6. A test volunteer sign-up on staging (with `OGC_MAIL_CAPTURE`) shows its confirmation in the Mail log.
7. Tools › Site Health has no new critical issue; the PHP error log has no `ogc-conference` lines.
