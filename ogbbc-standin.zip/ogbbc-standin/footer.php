<?php
/**
 * The stand-in footer (v3 site-shell.js).
 */
defined( 'ABSPATH' ) || exit;
$logo = get_template_directory_uri() . '/img/logo-dark-bg.png';
?>
<footer class="shell-footer"><div class="shell-container shell-footer__grid">
	<div class="shell-footer__about">
		<div class="shell-footer__logo"><img src="<?php echo esc_url( $logo ); ?>" width="700" height="120" alt="Old German Baptist Brethren Church, New Conference"></div>
		<p>Seeking closer relationship with God through His Word and Holy Spirit, learning to love like Jesus in close-knit church communities, and doing good to all men as we have opportunity.</p>
		<a class="shell-btn-outline" href="#">More about the Brethren</a>
	</div>
	<div><h2>Get Our Newsletter</h2>
		<form class="shell-news" onsubmit="return false"><input type="email" placeholder="Enter your email address" aria-label="Email address"><button type="submit">Submit</button></form>
		<p class="shell-fine">We never sell your information. No more than 2 or 3 emails a quarter.</p>
		<div class="shell-footer__cols">
			<div><h3>Explore</h3><a href="#">Who We Are</a><a href="#">Beliefs</a><a href="#">Outreach</a></div>
			<div><h3>Connect</h3><a href="#">Congregations</a><a href="#">Contact Us</a></div>
			<div><h3>Engage</h3><a href="#">Sunday Services</a><a href="#">News</a><a href="#">Calendar</a><a href="#">Sermons</a><a href="#">Resources</a><a href="<?php echo esc_url( home_url( '/annual-conference/' ) ); ?>">Annual Conference</a></div>
		</div>
	</div>
</div></footer>
<div class="shell-bottom"><div class="shell-container shell-bottom__grid">
	<div><nav aria-label="Legal"><a href="#">Privacy Policy</a><a href="#">Polity Statement</a><a href="#">Contact</a></nav>
	<p>The official website of the Old German Baptist Brethren Church, New Conference</p></div>
	<div><nav aria-label="Submit"><a href="#">Submit a Sermon</a><a href="#">Submit an Event</a><a href="#">Submit News</a></nav><p>© <?php echo esc_html( gmdate( 'Y' ) ); ?>. All rights reserved.</p></div>
</div></div>
<?php wp_footer(); ?>
</body>
</html>
