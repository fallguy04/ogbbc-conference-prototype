<?php
/**
 * The stand-in header: announcement bar, the site's header and the breadcrumb (v3 site-shell.js).
 */
defined( 'ABSPATH' ) || exit;
$h       = ogbbc_standin_header();
$chevron = ogbbc_standin_svg( 'chevron' );
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="shell-skip" href="#main">Skip to content</a>
<?php if ( ! empty( $h['topbar'] ) ) : ?>
<div class="shell-topbar"><a id="shell-topbar-link" href="<?php echo esc_url( isset( $h['topbar_href'] ) ? $h['topbar_href'] : '#' ); ?>"><?php echo esc_html( $h['topbar'] ); ?></a></div>
<?php endif; ?>
<header class="shell-header"><div class="shell-container shell-header__inner">
	<a class="shell-logo" href="<?php echo esc_url( home_url( '/' ) ); ?>"><img src="<?php echo esc_url( get_template_directory_uri() . '/img/logo-light-bg.png' ); ?>" width="700" height="120" alt="Old German Baptist Brethren Church, New Conference"></a>
	<nav class="shell-nav" aria-label="Main"><button type="button">Explore <?php echo $chevron; // phpcs:ignore -- fixed SVG. ?></button><button type="button">Connect <?php echo $chevron; // phpcs:ignore ?></button><button type="button">Engage <?php echo $chevron; // phpcs:ignore ?></button></nav>
	<a class="shell-cta" href="#">Find a congregation</a>
	<button class="shell-search" type="button" aria-label="Search"><?php echo ogbbc_standin_svg( 'magnifier' ); // phpcs:ignore ?></button>
	<button class="shell-burger" type="button" aria-label="Menu and search"><?php echo ogbbc_standin_svg( 'burger' ); // phpcs:ignore ?></button>
</div></header>
<?php if ( ! empty( $h['crumb'] ) ) : ?>
<nav class="shell-crumbs" aria-label="Breadcrumb"><div class="shell-container">
	<a href="#">About Us</a> /
	<?php if ( ! empty( $h['crumb_parent'] ) ) : ?><a href="<?php echo esc_url( isset( $h['crumb_parent_href'] ) ? $h['crumb_parent_href'] : '#' ); ?>"><?php echo esc_html( $h['crumb_parent'] ); ?></a> / <?php endif; ?>
	<span aria-current="page"><?php echo esc_html( $h['crumb'] ); ?></span>
</div></nav>
<?php endif; ?>
