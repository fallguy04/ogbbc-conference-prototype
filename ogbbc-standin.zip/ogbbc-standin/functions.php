<?php
/**
 * ogbbc.org stand-in theme (local only). The real site uses its own theme; this one draws the same
 * header and footer as v3's site-shell.js, server-side, so the plugin's pages can be judged in context.
 */

defined( 'ABSPATH' ) || exit;

add_action( 'after_setup_theme', function () {
	add_theme_support( 'title-tag' );
} );

add_action( 'wp_enqueue_scripts', function () {
	// The theme loads Droid Serif from Typekit; Noto Serif is its open successor.
	wp_enqueue_style( 'ogbbc-standin-fonts', 'https://fonts.googleapis.com/css2?family=Noto+Serif:wght@400;700&display=swap', array(), null );
	wp_enqueue_style( 'ogbbc-standin', get_template_directory_uri() . '/site-shell.css', array(), filemtime( get_template_directory() . '/site-shell.css' ) );
}, 5 );

/**
 * What the header shows. A plugin page says, through the ogbbc_standin_header filter, whether to leave
 * out the announcement bar (topbar => false) or the breadcrumb (crumb => false), or what they say
 * (crumb, crumb_parent, crumb_parent_href, topbar, topbar_href), as v3's data-topbar/data-crumb did.
 */
function ogbbc_standin_header() {
	return (array) apply_filters( 'ogbbc_standin_header', array(
		'topbar'      => 'Information about our Annual Conference',
		'topbar_href' => home_url( '/annual-conference/' ),
		'crumb'       => is_singular() ? get_the_title() : '',
	) );
}

function ogbbc_standin_svg( $which ) {
	$svg = array(
		'chevron'   => '<svg viewBox="0 0 10.5 5.9" aria-hidden="true"><path d="M10.48.64c0 .16-.06.33-.19.45l-4.6 4.6a.63.63 0 0 1-.9 0L.19 1.09A.64.64 0 0 1 1.09.19l4.15 4.15L9.39.19a.64.64 0 0 1 1.09.45Z" fill="currentColor"/></svg>',
		'magnifier' => '<svg viewBox="0 0 32 32" aria-hidden="true"><circle cx="13" cy="13" r="10.5" fill="none" stroke="currentColor" stroke-width="2"/><path d="m21 21 9 9" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>',
		'burger'    => '<svg viewBox="0 0 46 26" aria-hidden="true"><path d="M1 3h18M1 13h14M1 23h18" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><circle cx="33" cy="11" r="8.5" fill="none" stroke="currentColor" stroke-width="2"/><path d="m39 17 6 6" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>',
	);
	return $svg[ $which ];
}
