<?php
/**
 * Any other page on the local site: its title and content, in the stand-in header and footer.
 */
defined( 'ABSPATH' ) || exit;
get_header();
?>
<main id="main" class="shell-container" style="padding:48px 16px">
<?php
if ( have_posts() ) {
	while ( have_posts() ) {
		the_post();
		the_title( '<h1>', '</h1>' );
		the_content();
	}
} else {
	echo '<h1>Not found</h1><p><a href="' . esc_url( home_url( '/annual-conference/' ) ) . '">Annual Conference</a></p>';
}
?>
</main>
<?php
get_footer();
